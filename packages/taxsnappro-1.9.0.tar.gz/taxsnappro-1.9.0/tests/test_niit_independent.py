"""Tests for NIIT Independent Capital Gain Base (Phase 1, Task 1.3)."""

from decimal import Decimal

import pytest

from src.computation.form_8960 import compute_form_8960_capital_gain_base, compute_niit
from src.core.tax_constants import get_constants


class TestForm8960CapitalGainBase:
    """Form 8960 uses its own gains/losses worksheet, NOT Schedule D's $3K-limited number."""

    def test_no_loss_limitation(self):
        """Form 8960 does NOT apply the $3K loss cap."""
        result = compute_form_8960_capital_gain_base(
            short_term_gains=Decimal("-10000"),
            long_term_gains=Decimal("0"),
        )
        # Full -10000, not capped at -3000
        assert result == Decimal("-10000")

    def test_with_carryovers(self):
        """Carryovers are applied independently."""
        result = compute_form_8960_capital_gain_base(
            short_term_gains=Decimal("2000"),
            long_term_gains=Decimal("1000"),
            prior_st_carryover=Decimal("-5000"),
            prior_lt_carryover=Decimal("-3000"),
        )
        assert result == Decimal("-5000")

    def test_positive_gains(self):
        """Net gain passes through directly."""
        result = compute_form_8960_capital_gain_base(
            short_term_gains=Decimal("5000"),
            long_term_gains=Decimal("10000"),
        )
        assert result == Decimal("15000")

    def test_zero_gains(self):
        result = compute_form_8960_capital_gain_base(
            short_term_gains=Decimal("0"),
            long_term_gains=Decimal("0"),
        )
        assert result == Decimal("0")


class TestNIITWithIndependentBase:
    """Test that NIIT uses Form 8960's independent capital gain base."""

    def test_niit_uses_form_8960_base_not_schedule_d(self):
        """When form_8960_capital_gain_base is provided, NIIT uses it instead of capital_gains."""
        tc = get_constants(2024)
        # Schedule D capped number: -3000, but Form 8960 base: -10000
        niit_with_sched_d = compute_niit(
            interest=Decimal("50000"),
            dividends=Decimal("50000"),
            capital_gains=Decimal("-3000"),
            rental_income=Decimal("0"),
            agi=Decimal("400000"),
            filing_status="married_filing_jointly",
            tc=tc,
        )
        niit_with_8960 = compute_niit(
            interest=Decimal("50000"),
            dividends=Decimal("50000"),
            capital_gains=Decimal("-3000"),
            rental_income=Decimal("0"),
            agi=Decimal("400000"),
            filing_status="married_filing_jointly",
            tc=tc,
            form_8960_capital_gain_base=Decimal("-10000"),
        )
        # Form 8960 base: -10000 means lower NII → lower NIIT
        assert niit_with_8960 < niit_with_sched_d

    def test_niit_nii_floor_at_zero(self):
        """Even with large negative Form 8960 base, NII is floored at $0."""
        tc = get_constants(2024)
        niit = compute_niit(
            interest=Decimal("5000"),
            dividends=Decimal("5000"),
            capital_gains=Decimal("-3000"),
            rental_income=Decimal("0"),
            agi=Decimal("300000"),
            filing_status="married_filing_jointly",
            tc=tc,
            form_8960_capital_gain_base=Decimal("-50000"),
        )
        # NII = max(5000 + 5000 + (-50000) + 0, 0) = max(-40000, 0) = 0
        assert niit == Decimal("0")

    def test_niit_below_threshold(self):
        """NIIT is zero when AGI is below threshold regardless of gains."""
        tc = get_constants(2024)
        niit = compute_niit(
            interest=Decimal("10000"),
            dividends=Decimal("10000"),
            capital_gains=Decimal("5000"),
            rental_income=Decimal("0"),
            agi=Decimal("200000"),
            filing_status="married_filing_jointly",
            tc=tc,
            form_8960_capital_gain_base=Decimal("5000"),
        )
        assert niit == Decimal("0")

    def test_niit_exact_difference_matters(self):
        """Demonstrate the dollar difference between Schedule D and Form 8960 bases."""
        tc = get_constants(2024)
        # Scenario: $20K loss, Schedule D caps at -$3K, Form 8960 uses -$20K
        # High-income MFJ with lots of interest
        niit_sched_d = compute_niit(
            interest=Decimal("100000"),
            dividends=Decimal("50000"),
            capital_gains=Decimal("-3000"),
            rental_income=Decimal("20000"),
            agi=Decimal("500000"),
            filing_status="married_filing_jointly",
            tc=tc,
        )
        niit_8960 = compute_niit(
            interest=Decimal("100000"),
            dividends=Decimal("50000"),
            capital_gains=Decimal("-3000"),
            rental_income=Decimal("20000"),
            agi=Decimal("500000"),
            filing_status="married_filing_jointly",
            tc=tc,
            form_8960_capital_gain_base=Decimal("-20000"),
        )
        # NII with Sched D: 100000 + 50000 + (-3000) + 20000 = 167000
        # NII with 8960:    100000 + 50000 + (-20000) + 20000 = 150000
        # MAGI excess: 500000 - 250000 = 250000
        # NIIT(sched_d) = 0.038 * min(167000, 250000) = 0.038 * 167000 = 6346
        # NIIT(8960)    = 0.038 * min(150000, 250000) = 0.038 * 150000 = 5700
        assert niit_sched_d == Decimal("6346")
        assert niit_8960 == Decimal("5700")
        assert niit_sched_d - niit_8960 == Decimal("646")
