"""Tests for ReviewAnnotation System (Phase 1, Task 1.6)."""

from decimal import Decimal
from typing import Optional

import pytest

from src.core.return_processor import ReturnProcessor
from src.models.prior_year import PriorYearData
from src.models.review import ReviewAnnotation


def _make_proc(**kwargs) -> ReturnProcessor:
    """Create a ReturnProcessor with sensible defaults."""
    proc = ReturnProcessor(tax_year=kwargs.get("tax_year", 2024))
    proc.set_filing_status(kwargs.get("filing_status", "married_filing_jointly"))
    proc.add_w2(
        wages=kwargs.get("wages", Decimal("100000")),
        federal_withheld=kwargs.get("fed_wh", Decimal("15000")),
        medicare_wages=kwargs.get("medicare_wages", Decimal("100000")),
        ss_wages=kwargs.get("ss_wages", Decimal("100000")),
        ss_tax=kwargs.get("ss_tax", Decimal("6200")),
    )
    return proc


def _find_annotation(result, category: str = None, source: str = None) -> Optional[ReviewAnnotation]:
    for a in result.annotations:
        if category and a.category != category:
            continue
        if source and a.source != source:
            continue
        return a
    return None


class TestReviewAnnotationModel:
    def test_default_severity_info(self):
        a = ReviewAnnotation()
        assert a.severity == "info"
        assert a.action_required is False
        assert a.confidence == 1.0

    def test_fields(self):
        a = ReviewAnnotation(
            category="carryover",
            severity="warning",
            message="Test",
            form_line="Schedule D, Line 6",
            action_required=True,
            confidence=0.8,
            impact=Decimal("5000"),
            source="test",
        )
        assert a.category == "carryover"
        assert a.severity == "warning"
        assert a.impact == Decimal("5000")


class TestAnnotationGeneration:
    def test_carryover_applied_annotation(self):
        """When prior year carryover is applied, info annotation is generated."""
        proc = _make_proc()
        proc.set_capital_gains(short_term=Decimal("5000"), long_term=Decimal("0"))
        proc.set_prior_year_data(PriorYearData(
            tax_year=2023,
            capital_loss_carryover_st=Decimal("-10000"),
        ))
        result = proc.calculate()
        ann = _find_annotation(result, source="prior_year_data")
        assert ann is not None
        assert ann.severity == "info"
        assert "$10,000" in ann.message

    def test_no_prior_year_warning(self):
        """When no prior year data and capital gains exist, warning is generated."""
        proc = _make_proc()
        proc.set_capital_gains(short_term=Decimal("-5000"), long_term=Decimal("0"))
        result = proc.calculate()
        ann = _find_annotation(result, source="missing_prior_year")
        assert ann is not None
        assert ann.severity == "warning"
        assert ann.action_required is True

    def test_no_warning_when_prior_data_provided(self):
        """No missing-prior-year warning when PriorYearData is set."""
        proc = _make_proc()
        proc.set_capital_gains(short_term=Decimal("-5000"), long_term=Decimal("0"))
        proc.set_prior_year_data(PriorYearData(
            tax_year=2023,
            capital_loss_carryover_st=Decimal("0"),
        ))
        result = proc.calculate()
        ann = _find_annotation(result, source="missing_prior_year")
        assert ann is None

    def test_carryover_generated_annotation(self):
        """When next-year carryover is generated, info annotation appears."""
        proc = _make_proc()
        proc.set_capital_gains(short_term=Decimal("-10000"), long_term=Decimal("0"))
        result = proc.calculate()
        ann = _find_annotation(result, source="schedule_d")
        assert ann is not None
        assert "next year" in ann.message

    def test_pal_suspended_annotation(self):
        """When rental losses are suspended, info annotation appears."""
        proc = _make_proc()
        proc.set_rental_income(Decimal("-30000"))
        result = proc.calculate()
        ann = _find_annotation(result, source="pal_limitation")
        assert ann is not None
        assert ann.category == "rental"

    def test_niit_base_difference_annotation(self):
        """When Form 8960 base differs from Schedule D, info annotation appears."""
        proc = _make_proc(wages=Decimal("300000"), fed_wh=Decimal("60000"),
                          medicare_wages=Decimal("300000"))
        proc.set_capital_gains(short_term=Decimal("-10000"), long_term=Decimal("0"))
        result = proc.calculate()
        # Schedule D caps at -3000, Form 8960 uses -10000
        ann = _find_annotation(result, source="form_8960_worksheet")
        assert ann is not None
        assert ann.category == "niit"

    def test_excess_fica_annotation(self):
        """When excess FICA is detected (one person, multiple W-2s), info annotation appears."""
        proc = ReturnProcessor(tax_year=2024)
        proc.set_filing_status("married_filing_jointly")
        max_ss = Decimal("168600") * Decimal("0.062")
        # Primary has 2 employers both maxing SS → excess for primary
        proc.add_w2(wages=Decimal("170000"), federal_withheld=Decimal("30000"),
                     ss_wages=Decimal("168600"), ss_tax=max_ss,
                     medicare_wages=Decimal("170000"))
        proc.add_w2(wages=Decimal("50000"), federal_withheld=Decimal("5000"),
                     ss_wages=Decimal("50000"), ss_tax=Decimal("3100"),
                     medicare_wages=Decimal("50000"))
        result = proc.calculate()
        ann = _find_annotation(result, source="excess_fica")
        assert ann is not None
        assert ann.category == "credit"

    def test_ma_stcg_rate_annotation(self):
        """When MA resident has ST gains, 12% rate info annotation appears."""
        proc = _make_proc()
        proc.set_state("MA")
        proc.set_capital_gains(short_term=Decimal("5000"), long_term=Decimal("0"))
        result = proc.calculate()
        ann = _find_annotation(result, source="ma_stcg_rate")
        assert ann is not None
        assert "12%" in ann.message

    def test_no_annotations_for_simple_return(self):
        """Simple W-2-only return with no special situations → minimal annotations."""
        proc = _make_proc()
        result = proc.calculate()
        # Should have no carryover, no PAL, no excess FICA, no NIIT base diff
        sources = {a.source for a in result.annotations}
        assert "prior_year_data" not in sources
        assert "pal_limitation" not in sources
        assert "excess_fica" not in sources
        assert "schedule_d" not in sources
