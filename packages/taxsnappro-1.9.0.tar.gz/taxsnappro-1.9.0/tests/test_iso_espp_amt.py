"""
Test ISO, ESPP, and AMT calculations.

These are critical for Silicon Valley IT families.
"""
import sys
sys.path.insert(0, '.')

from decimal import Decimal
from datetime import date
from src.core.modules.iso_espp import (
    ISOExercise, ISOSale, ESPPPurchase, ESPPSale, 
    DispositionType, calculate_iso_amt_preference
)
from src.core.modules.amt import (
    AMTPreferenceItems, AMTConstants2024, 
    calculate_amt, calculate_amt_exemption
)


def test_iso_qualifying_disposition():
    """Test ISO with qualifying disposition (favorable tax treatment)."""
    # Grant: Jan 2020, Exercise: Mar 2024, Sell: Apr 2026 (>2yr from grant, >1yr from exercise)
    iso = ISOExercise(
        grant_date=date(2020, 1, 15),
        exercise_date=date(2024, 3, 1),
        exercise_price=Decimal("10.00"),
        fmv_at_exercise=Decimal("50.00"),
        shares=1000
    )
    
    sale = ISOSale(
        sale_date=date(2026, 4, 1),  # >2yr from grant, >1yr from exercise
        sale_price=Decimal("60.00"),
        shares=1000,
        iso_exercise=iso
    )
    
    assert sale.disposition_type() == DispositionType.QUALIFYING
    treatment = sale.calculate_tax_treatment()
    
    # Qualifying: All gain is LTCG, no ordinary income
    assert treatment["ordinary_income"] == Decimal("0")
    assert treatment["capital_gain"] == Decimal("50000")  # (60-10) * 1000
    assert treatment["capital_gain_type"] == "long_term"
    print("✅ ISO qualifying disposition test passed")


def test_iso_disqualifying_disposition():
    """Test ISO with disqualifying disposition (sold too early)."""
    iso = ISOExercise(
        grant_date=date(2024, 1, 15),
        exercise_date=date(2024, 6, 1),
        exercise_price=Decimal("10.00"),
        fmv_at_exercise=Decimal("50.00"),
        shares=1000
    )
    
    sale = ISOSale(
        sale_date=date(2024, 9, 1),  # <1yr from exercise = disqualifying
        sale_price=Decimal("55.00"),
        shares=1000,
        iso_exercise=iso
    )
    
    assert sale.disposition_type() == DispositionType.DISQUALIFYING
    treatment = sale.calculate_tax_treatment()
    
    # Disqualifying: Spread becomes ordinary income
    # Ordinary income = min(spread at exercise, actual gain)
    # Spread = (50-10) * 1000 = 40,000
    # Actual gain = (55-10) * 1000 = 45,000
    # Ordinary = min(40000, 45000) = 40,000
    assert treatment["ordinary_income"] == Decimal("40000")
    assert treatment["capital_gain"] == Decimal("5000")  # 45000 - 40000
    assert treatment["capital_gain_type"] == "short_term"
    print("✅ ISO disqualifying disposition test passed")


def test_iso_amt_preference():
    """Test ISO AMT preference calculation at exercise."""
    iso = ISOExercise(
        grant_date=date(2020, 1, 15),
        exercise_date=date(2024, 3, 1),
        exercise_price=Decimal("10.00"),
        fmv_at_exercise=Decimal("50.00"),
        shares=1000
    )
    
    # Spread = (50-10) * 1000 = $40,000
    assert iso.spread_per_share == Decimal("40.00")
    assert iso.total_spread == Decimal("40000")
    print("✅ ISO AMT preference test passed")


def test_espp_qualifying():
    """Test ESPP qualifying disposition."""
    espp = ESPPPurchase(
        grant_date=date(2022, 1, 1),  # Offering period start
        purchase_date=date(2022, 6, 30),
        fmv_grant_date=Decimal("100.00"),
        fmv_purchase_date=Decimal("120.00"),
        purchase_price=Decimal("85.00"),  # 15% discount from min(grant, purchase) FMV
        shares=100
    )
    
    sale = ESPPSale(
        sale_date=date(2024, 7, 1),  # >2yr from grant, >1yr from purchase
        sale_price=Decimal("150.00"),
        shares=100,
        espp_purchase=espp
    )
    
    assert sale.disposition_type() == DispositionType.QUALIFYING
    treatment = sale.calculate_tax_treatment()
    
    # Qualifying: Ordinary income = lesser of (actual gain, grant date discount)
    # Actual gain = (150-85) * 100 = 6,500
    # Grant date discount = 100 * 0.15 * 100 = 1,500
    # Ordinary = min(6500, 1500) = 1,500
    assert treatment["ordinary_income"] == Decimal("1500")
    assert treatment["capital_gain"] == Decimal("5000")  # 6500 - 1500
    print("✅ ESPP qualifying disposition test passed")


def test_espp_disqualifying():
    """Test ESPP disqualifying disposition."""
    espp = ESPPPurchase(
        grant_date=date(2024, 1, 1),
        purchase_date=date(2024, 6, 30),
        fmv_grant_date=Decimal("100.00"),
        fmv_purchase_date=Decimal("120.00"),
        purchase_price=Decimal("85.00"),
        shares=100
    )
    
    sale = ESPPSale(
        sale_date=date(2024, 8, 1),  # <1yr from purchase = disqualifying
        sale_price=Decimal("130.00"),
        shares=100,
        espp_purchase=espp
    )
    
    assert sale.disposition_type() == DispositionType.DISQUALIFYING
    treatment = sale.calculate_tax_treatment()
    
    # Disqualifying: Ordinary income = full bargain at purchase
    # Bargain = (120-85) * 100 = 3,500
    assert treatment["ordinary_income"] == Decimal("3500")
    # Capital gain = actual gain - ordinary = (130-85)*100 - 3500 = 4500 - 3500 = 1000
    assert treatment["capital_gain"] == Decimal("1000")
    print("✅ ESPP disqualifying disposition test passed")


def test_amt_calculation():
    """Test full AMT calculation with ISO."""
    # Scenario: High earner with ISO exercise
    prefs = AMTPreferenceItems(
        taxable_income=Decimal("300000"),
        standard_deduction=Decimal("29200"),  # MFJ standard (added back for AMT)
        state_local_taxes=Decimal("10000"),  # SALT cap
        iso_spread=Decimal("100000"),  # Big ISO exercise
    )
    
    result = calculate_amt(
        preferences=prefs,
        regular_tax=Decimal("52000"),
        filing_status="married_filing_jointly"
    )
    
    # AMTI = 300000 + 29200 + 10000 + 100000 = 439,200
    assert result.amti == Decimal("439200")
    
    # Exemption for MFJ with AMTI $439,200
    # Base exemption: $133,300
    # Phase-out threshold: $1,218,700
    # Since AMTI < threshold, full exemption
    assert result.exemption == Decimal("133300")
    
    # AMT base = AMTI - exemption = 439,200 - 133,300 = 305,900
    assert result.amt_base == Decimal("305900")
    
    # TMT: 26% on first $220,700 + 28% on rest
    # = 220,700 * 0.26 + 85,200 * 0.28
    # = 57,382 + 23,856 = 81,238
    assert result.tentative_minimum_tax == Decimal("81238")
    
    # AMT liability = TMT - regular tax = 81,238 - 52,000 = 29,238
    assert result.amt_liability == Decimal("29238")
    
    print("✅ AMT calculation test passed")
    print(f"   AMTI: ${result.amti:,.0f}")
    print(f"   AMT Exemption: ${result.exemption:,.0f}")
    print(f"   Tentative Min Tax: ${result.tentative_minimum_tax:,.0f}")
    print(f"   Regular Tax: ${result.regular_tax:,.0f}")
    print(f"   AMT Liability: ${result.amt_liability:,.0f}")


def test_amt_exemption_phaseout():
    """Test AMT exemption phase-out at high income."""
    # Single filer with very high AMTI
    amti = Decimal("800000")
    exemption = calculate_amt_exemption(amti, "single")
    
    # Base exemption: $85,700
    # Threshold: $609,350
    # Excess: 800,000 - 609,350 = 190,650
    # Reduction: 190,650 * 0.25 = 47,662.50 -> 47,663
    # Exemption: 85,700 - 47,663 = 38,037
    expected = Decimal("85700") - (Decimal("190650") * Decimal("0.25"))
    assert abs(exemption - expected) < 2  # Allow small rounding
    print(f"✅ AMT exemption phase-out test passed (exemption: ${exemption:,.0f})")


def test_silicon_valley_scenario():
    """Realistic Silicon Valley IT family scenario."""
    print("\n=== Silicon Valley IT Family Scenario ===")
    print("Dual income: $600k W-2 wages")
    print("ISO exercise: 5000 shares, strike $20, FMV $100")
    print()
    
    # ISO exercise
    iso = ISOExercise(
        grant_date=date(2020, 1, 1),
        exercise_date=date(2024, 6, 1),
        exercise_price=Decimal("20.00"),
        fmv_at_exercise=Decimal("100.00"),
        shares=5000
    )
    
    iso_spread = iso.total_spread  # (100-20) * 5000 = $400,000
    print(f"ISO Spread (AMT preference): ${iso_spread:,.0f}")
    
    # AMT calculation
    # Assuming $600k wages, MFJ, standard deduction
    taxable_income = Decimal("600000") - Decimal("29200")  # ~570,800
    
    prefs = AMTPreferenceItems(
        taxable_income=taxable_income,
        standard_deduction=Decimal("29200"),
        iso_spread=iso_spread,
    )
    
    # Regular tax on $570,800 MFJ
    # Simplified: ~$140,000
    regular_tax = Decimal("140000")
    
    result = calculate_amt(prefs, regular_tax, "married_filing_jointly")
    
    print(f"AMTI: ${result.amti:,.0f}")
    print(f"Regular Tax: ${result.regular_tax:,.0f}")
    print(f"Tentative Min Tax: ${result.tentative_minimum_tax:,.0f}")
    print(f"AMT Liability: ${result.amt_liability:,.0f}")
    print()
    
    if result.amt_liability > 0:
        print(f"⚠️  Additional AMT owed: ${result.amt_liability:,.0f}")
        print(f"   This creates AMT credit for future years")
    else:
        print("✅ No AMT liability (regular tax >= AMT)")
    
    print("✅ Silicon Valley scenario test passed")


if __name__ == "__main__":
    test_iso_qualifying_disposition()
    test_iso_disqualifying_disposition()
    test_iso_amt_preference()
    test_espp_qualifying()
    test_espp_disqualifying()
    test_amt_calculation()
    test_amt_exemption_phaseout()
    test_silicon_valley_scenario()
    print("\n🎉 All tests passed!")


def test_amt_credit_carryforward():
    """Test Form 8801 AMT credit carryforward."""
    from src.core.modules.amt import calculate_form_8801, AMTPreferenceItems
    
    # Scenario: Last year paid $50k AMT from ISO exercise
    # This year: regular tax > TMT, can use some credit
    
    prior_credit = Decimal("50000")
    current_regular_tax = Decimal("80000")
    
    # Current year - no ISO, lower AMTI
    current_prefs = AMTPreferenceItems(
        taxable_income=Decimal("250000"),
        standard_deduction=Decimal("29200"),
        state_local_taxes=Decimal("10000"),
        iso_spread=Decimal("0"),  # No ISO this year
    )
    
    result = calculate_form_8801(
        prior_credit, 
        current_regular_tax, 
        current_prefs, 
        "married_filing_jointly"
    )
    
    print("=== Form 8801 AMT Credit Test ===")
    print(f"Prior year AMT credit: ${prior_credit:,.0f}")
    print(f"Current year regular tax: ${current_regular_tax:,.0f}")
    print(f"Current year TMT: ${result['current_tmt']:,.0f}")
    print(f"Credit used this year: ${result['credit_used']:,.0f}")
    print(f"Carryforward to next year: ${result['carryforward']:,.0f}")
    
    # Verify: credit_used + carryforward = prior_credit
    assert result['credit_used'] + result['carryforward'] == prior_credit
    # Verify: credit_used <= prior_credit
    assert result['credit_used'] <= prior_credit
    # Verify: credit_used <= (regular_tax - TMT)
    assert result['credit_used'] <= max(current_regular_tax - result['current_tmt'], Decimal("0"))
    
    print("✅ Form 8801 AMT credit test passed")


if __name__ == "__main__":
    test_iso_qualifying_disposition()
    test_iso_disqualifying_disposition()
    test_iso_amt_preference()
    test_espp_qualifying()
    test_espp_disqualifying()
    test_amt_calculation()
    test_amt_exemption_phaseout()
    test_silicon_valley_scenario()
    test_amt_credit_carryforward()  # New test
    print("\n🎉 All tests passed!")
