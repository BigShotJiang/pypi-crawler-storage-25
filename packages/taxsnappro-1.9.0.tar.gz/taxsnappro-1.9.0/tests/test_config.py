"""
Test suite for config.py completeness and consistency.

Ensures all required tax constants are defined and accessible.
"""
import pytest
from ui.aitax import config


def test_config_constants_exist():
    """Verify all required constants exist in config module."""
    # Top-level constants (added in Phase 2)
    required_top_level = [
        'CHILD_TAX_CREDIT',
        'DEPENDENT_CREDIT',
        'CAPITAL_LOSS_LIMIT',
        'SALT_CAP',
        'PASSIVE_LOSS_ALLOWANCE',
        'PASSIVE_LOSS_PHASEOUT',
    ]
    
    for constant in required_top_level:
        assert hasattr(config, constant), f"Missing constant: {constant}"
    
    # Nested constants in TAX_CONSTANTS_2024
    required_nested = [
        'standard_deduction',
        'brackets',
        'capital_gains_brackets',
        'social_security_wage_base',
        'medicare_additional_threshold',
        'niit_threshold',
        'amt_exemption',
        'amt_phaseout_start',
        'amt_26_percent_limit',
    ]
    
    for key in required_nested:
        assert key in config.TAX_CONSTANTS_2024, f"Missing TAX_CONSTANTS_2024 key: {key}"


def test_config_values_valid():
    """Verify config values are reasonable and non-zero."""
    # Top-level constants
    assert config.CHILD_TAX_CREDIT == 2000
    assert config.DEPENDENT_CREDIT == 500
    assert config.CAPITAL_LOSS_LIMIT == 3000
    assert config.SALT_CAP == 10000
    
    # Passive loss allowance
    assert config.PASSIVE_LOSS_ALLOWANCE["base"] == 25000
    assert config.PASSIVE_LOSS_ALLOWANCE["married_filing_separately"] == 12500
    
    assert config.PASSIVE_LOSS_PHASEOUT["start"] == 100000
    assert config.PASSIVE_LOSS_PHASEOUT["end"] == 150000
    assert config.PASSIVE_LOSS_PHASEOUT["start_mfs"] == 50000
    assert config.PASSIVE_LOSS_PHASEOUT["end_mfs"] == 75000
    assert config.PASSIVE_LOSS_PHASEOUT["reduction_rate"] == 0.50


def test_filing_statuses_complete():
    """Verify all filing statuses are covered in bracket structures."""
    expected_statuses = [
        "single",
        "married_filing_jointly",
        "married_filing_separately",
        "head_of_household",
        "qualifying_widow",
    ]
    
    # Check standard deduction
    for status in expected_statuses:
        assert status in config.TAX_CONSTANTS_2024["standard_deduction"], \
            f"Missing standard deduction for {status}"
    
    # Check tax brackets
    for status in expected_statuses:
        assert status in config.TAX_CONSTANTS_2024["brackets"], \
            f"Missing tax brackets for {status}"
    
    # Check capital gains brackets
    for status in expected_statuses:
        assert status in config.TAX_CONSTANTS_2024["capital_gains_brackets"], \
            f"Missing capital gains brackets for {status}"
    
    # Check AMT exemption
    for status in expected_statuses:
        assert status in config.TAX_CONSTANTS_2024["amt_exemption"], \
            f"Missing AMT exemption for {status}"


def test_bracket_structure():
    """Verify tax brackets are properly structured."""
    for filing_status, brackets in config.TAX_CONSTANTS_2024["brackets"].items():
        # Should have 7 brackets
        assert len(brackets) == 7, f"Expected 7 brackets for {filing_status}, got {len(brackets)}"
        
        # Last bracket should be infinity
        assert brackets[-1][0] == float("inf"), \
            f"Last bracket should be infinity for {filing_status}"
        
        # Rates should be monotonically increasing
        rates = [b[1] for b in brackets]
        assert rates == sorted(rates), f"Tax rates not increasing for {filing_status}"
        
        # All brackets should be tuples of (threshold, rate)
        for bracket in brackets:
            assert len(bracket) == 2, "Each bracket should be (threshold, rate)"
            assert isinstance(bracket[1], float), "Tax rate should be a float"


def test_capital_gains_bracket_structure():
    """Verify capital gains brackets are properly structured."""
    for filing_status, brackets in config.TAX_CONSTANTS_2024["capital_gains_brackets"].items():
        # Should have 3 brackets (0%, 15%, 20%)
        assert len(brackets) == 3, \
            f"Expected 3 capital gains brackets for {filing_status}, got {len(brackets)}"
        
        # Last bracket should be infinity
        assert brackets[-1][0] == float("inf"), \
            f"Last bracket should be infinity for {filing_status}"
        
        # Rates should be 0.0, 0.15, 0.20
        rates = [b[1] for b in brackets]
        assert rates == [0.0, 0.15, 0.20], \
            f"Expected capital gains rates [0.0, 0.15, 0.20] for {filing_status}, got {rates}"


def test_amt_exemption_phaseout_consistency():
    """Verify AMT exemption and phase-out values are consistent."""
    for status in config.TAX_CONSTANTS_2024["amt_exemption"].keys():
        exemption = config.TAX_CONSTANTS_2024["amt_exemption"][status]
        phaseout_start = config.TAX_CONSTANTS_2024["amt_phaseout_start"][status]
        
        # Exemption should be positive
        assert exemption > 0, f"AMT exemption should be positive for {status}"
        
        # Phase-out start should be positive
        assert phaseout_start > 0, f"AMT phase-out start should be positive for {status}"
        
        # MFJ/QW should have higher exemption than others
        if status in ["married_filing_jointly", "qualifying_widow"]:
            assert exemption > 100000, f"MFJ/QW should have exemption > 100k"
        
        # MFS should have half the exemption of MFJ
        if status == "married_filing_separately":
            mfj_exemption = config.TAX_CONSTANTS_2024["amt_exemption"]["married_filing_jointly"]
            assert exemption == mfj_exemption / 2, \
                "MFS exemption should be half of MFJ"


def test_api_settings():
    """Verify API settings are defined and reasonable."""
    assert hasattr(config, 'REQUEST_DELAY_SECONDS')
    assert hasattr(config, 'MAX_RETRIES')
    assert hasattr(config, 'RETRY_DELAY_SECONDS')
    
    assert config.REQUEST_DELAY_SECONDS > 0
    assert config.MAX_RETRIES > 0
    assert config.RETRY_DELAY_SECONDS > 0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
