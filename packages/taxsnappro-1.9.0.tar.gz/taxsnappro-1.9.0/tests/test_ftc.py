"""Tests for Foreign Tax Credit simplified election."""

from decimal import Decimal

from src.computation.ftc import (
    check_ftc_simplified_eligibility,
    compute_ftc,
    compute_ftc_simplified,
    generate_ftc_annotations,
)


class TestCheckEligibility:
    def test_single_under_300_eligible(self):
        eligible, reasons = check_ftc_simplified_eligibility(
            foreign_taxes=Decimal("200"),
            filing_status="single",
        )
        assert eligible is True
        assert reasons == []

    def test_mfj_under_600_eligible(self):
        eligible, reasons = check_ftc_simplified_eligibility(
            foreign_taxes=Decimal("500"),
            filing_status="married_filing_jointly",
        )
        assert eligible is True

    def test_single_over_300_ineligible(self):
        eligible, reasons = check_ftc_simplified_eligibility(
            foreign_taxes=Decimal("301"),
            filing_status="single",
        )
        assert eligible is False
        assert any("exceed" in r for r in reasons)

    def test_mfj_over_600_ineligible(self):
        eligible, reasons = check_ftc_simplified_eligibility(
            foreign_taxes=Decimal("601"),
            filing_status="married_filing_jointly",
        )
        assert eligible is False

    def test_mfs_always_ineligible(self):
        eligible, reasons = check_ftc_simplified_eligibility(
            foreign_taxes=Decimal("100"),
            filing_status="married_filing_separately",
        )
        assert eligible is False
        assert any("MFS" in r for r in reasons)

    def test_not_all_passive_ineligible(self):
        eligible, reasons = check_ftc_simplified_eligibility(
            foreign_taxes=Decimal("200"),
            filing_status="single",
            all_passive_category=False,
        )
        assert eligible is False
        assert any("passive" in r for r in reasons)

    def test_not_on_qualified_statements_ineligible(self):
        eligible, reasons = check_ftc_simplified_eligibility(
            foreign_taxes=Decimal("200"),
            filing_status="single",
            all_on_qualified_statements=False,
        )
        assert eligible is False
        assert any("qualified" in r.lower() for r in reasons)

    def test_with_carryover_ineligible(self):
        eligible, reasons = check_ftc_simplified_eligibility(
            foreign_taxes=Decimal("200"),
            filing_status="single",
            has_carryover=True,
        )
        assert eligible is False
        assert any("carryforward" in r for r in reasons)

    def test_zero_taxes_ineligible(self):
        eligible, reasons = check_ftc_simplified_eligibility(
            foreign_taxes=Decimal("0"),
            filing_status="single",
        )
        assert eligible is False
        assert any("No foreign" in r for r in reasons)

    def test_exact_threshold_eligible(self):
        """$300 exactly for single should be eligible."""
        eligible, _ = check_ftc_simplified_eligibility(
            foreign_taxes=Decimal("300"),
            filing_status="single",
        )
        assert eligible is True

    def test_hoh_uses_300_threshold(self):
        eligible, _ = check_ftc_simplified_eligibility(
            foreign_taxes=Decimal("300"),
            filing_status="head_of_household",
        )
        assert eligible is True


class TestComputeFTCSimplified:
    def test_returns_total_paid(self):
        assert compute_ftc_simplified(Decimal("250")) == Decimal("250")

    def test_negative_returns_zero(self):
        assert compute_ftc_simplified(Decimal("-50")) == Decimal("0")


class TestComputeFTC:
    def test_eligible_returns_credit(self):
        result = compute_ftc(Decimal("200"), "single")
        assert result.eligible_for_simplified is True
        assert result.credit_amount == Decimal("200")

    def test_ineligible_returns_zero_credit(self):
        result = compute_ftc(Decimal("500"), "single")
        assert result.eligible_for_simplified is False
        assert result.credit_amount == Decimal("0")
        assert len(result.ineligibility_reasons) > 0


class TestAnnotations:
    def test_eligible_annotation(self):
        result = compute_ftc(Decimal("200"), "single")
        annotations = generate_ftc_annotations(result)
        assert len(annotations) == 1
        assert annotations[0].category == "ftc"
        assert annotations[0].severity == "info"
        assert "no Form 1116" in annotations[0].message

    def test_ineligible_annotation(self):
        result = compute_ftc(Decimal("500"), "single")
        annotations = generate_ftc_annotations(result)
        assert len(annotations) == 1
        assert annotations[0].severity == "warning"
        assert "Form 1116 required" in annotations[0].message
        assert annotations[0].action_required is True

    def test_no_foreign_tax_no_annotation(self):
        result = compute_ftc(Decimal("0"), "single")
        annotations = generate_ftc_annotations(result)
        assert len(annotations) == 0
