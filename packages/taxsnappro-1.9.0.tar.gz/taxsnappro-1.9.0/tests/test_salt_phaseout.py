from decimal import Decimal

from src.computation.federal_tax import compute_itemized_deduction
from src.core.tax_constants import get_constants


def _itemized_with_large_salt() -> dict[str, Decimal]:
    return {
        "state_tax": Decimal("100000"),
        "property_tax": Decimal("100000"),
    }


def test_salt_cap_below_phaseout_threshold_keeps_full_cap():
    tc = get_constants(2025)
    deduction = compute_itemized_deduction(
        agi=Decimal("400000"),
        itemized=_itemized_with_large_salt(),
        mortgages=[],
        tc=tc,
        filing_status="married_filing_jointly",
    )

    assert deduction == Decimal("40000")


def test_salt_cap_at_phaseout_threshold_keeps_full_cap():
    tc = get_constants(2025)
    deduction = compute_itemized_deduction(
        agi=Decimal("500000"),
        itemized=_itemized_with_large_salt(),
        mortgages=[],
        tc=tc,
        filing_status="married_filing_jointly",
    )

    assert deduction == Decimal("40000")


def test_salt_cap_at_six_hundred_thousand_reaches_floor_under_enacted_rate():
    tc = get_constants(2025)
    deduction = compute_itemized_deduction(
        agi=Decimal("600000"),
        itemized=_itemized_with_large_salt(),
        mortgages=[],
        tc=tc,
        filing_status="married_filing_jointly",
    )

    assert deduction == Decimal("10000")


def test_salt_cap_at_eight_hundred_thousand_stays_at_floor():
    tc = get_constants(2025)
    deduction = compute_itemized_deduction(
        agi=Decimal("800000"),
        itemized=_itemized_with_large_salt(),
        mortgages=[],
        tc=tc,
        filing_status="married_filing_jointly",
    )

    assert deduction == Decimal("10000")


def test_salt_cap_at_one_million_stays_at_floor():
    tc = get_constants(2025)
    deduction = compute_itemized_deduction(
        agi=Decimal("1000000"),
        itemized=_itemized_with_large_salt(),
        mortgages=[],
        tc=tc,
        filing_status="married_filing_jointly",
    )

    assert deduction == Decimal("10000")


def test_mfs_salt_cap_below_phaseout_threshold_keeps_half_cap():
    tc = get_constants(2025)
    deduction = compute_itemized_deduction(
        agi=Decimal("250000"),
        itemized=_itemized_with_large_salt(),
        mortgages=[],
        tc=tc,
        filing_status="married_filing_separately",
    )

    assert deduction == Decimal("20000")


def test_mfs_salt_cap_uses_half_threshold_and_floor():
    tc = get_constants(2025)
    deduction = compute_itemized_deduction(
        agi=Decimal("300000"),
        itemized=_itemized_with_large_salt(),
        mortgages=[],
        tc=tc,
        filing_status="married_filing_separately",
    )

    assert deduction == Decimal("5000")
