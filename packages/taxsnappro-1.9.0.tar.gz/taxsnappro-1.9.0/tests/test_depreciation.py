"""Tests for Depreciation Engine (Phase 2).

Covers:
- Residential rental 27.5yr mid-month convention (various placed-in-service months)
- Commercial 39yr
- Final year disposal
- Conversion from personal use
- Multiple assets per property
- Integration with ReturnProcessor auto-depreciation
"""

from datetime import date
from decimal import Decimal

import pytest

from src.computation.depreciation import (
    compute_annual_depreciation,
    compute_conversion_basis,
    compute_property_depreciation,
)
from src.models.depreciation import DepreciationAsset, RentalActivity
from src.core.return_processor import ReturnProcessor
from src.models.review import ReviewAnnotation


def _make_residential_asset(
    placed_month: int = 1,
    placed_year: int = 2020,
    original_basis: Decimal = Decimal("275000"),
    land_basis: Decimal = Decimal("0"),
    prior_accumulated: Decimal = Decimal("0"),
    disposed_date=None,
    asset_id: str = "bldg-1",
    activity_id: str = "prop-1",
    business_use_pct: Decimal = Decimal("100"),
) -> DepreciationAsset:
    return DepreciationAsset(
        asset_id=asset_id,
        activity_id=activity_id,
        category="building",
        description="Residential rental building",
        placed_in_service_date=date(placed_year, placed_month, 15),
        disposed_date=disposed_date,
        recovery_period_years=Decimal("27.5"),
        method="straight_line",
        convention="mid_month",
        original_basis=original_basis,
        land_basis=land_basis,
        prior_accumulated=prior_accumulated,
        business_use_pct=business_use_pct,
    )


class TestResidential275Year:
    """Residential rental property: 27.5yr straight-line, mid-month."""

    def test_full_year_depreciation(self):
        """Full year = basis / (27.5 * 12) * 12 = basis / 27.5."""
        asset = _make_residential_asset(placed_year=2020, placed_month=1)
        depr = compute_annual_depreciation(asset, 2021)
        expected = (Decimal("275000") / Decimal("27.5")).quantize(Decimal("0.01"))
        assert depr == expected  # $10,000.00

    def test_first_year_jan(self):
        """Placed in service January: 11.5 months of depreciation."""
        asset = _make_residential_asset(placed_month=1, placed_year=2024)
        depr = compute_annual_depreciation(asset, 2024)
        monthly = Decimal("275000") / (Decimal("27.5") * 12)
        expected = (monthly * Decimal("11.5")).quantize(Decimal("0.01"))
        assert depr == expected

    def test_first_year_june(self):
        """Placed in service June: 6.5 months of depreciation."""
        asset = _make_residential_asset(placed_month=6, placed_year=2024)
        depr = compute_annual_depreciation(asset, 2024)
        monthly = Decimal("275000") / (Decimal("27.5") * 12)
        expected = (monthly * Decimal("6.5")).quantize(Decimal("0.01"))
        assert depr == expected

    def test_first_year_december(self):
        """Placed in service December: 0.5 months of depreciation."""
        asset = _make_residential_asset(placed_month=12, placed_year=2024)
        depr = compute_annual_depreciation(asset, 2024)
        monthly = Decimal("275000") / (Decimal("27.5") * 12)
        expected = (monthly * Decimal("0.5")).quantize(Decimal("0.01"))
        assert depr == expected

    def test_first_year_july(self):
        """Placed in service July: 5.5 months."""
        asset = _make_residential_asset(placed_month=7, placed_year=2024)
        depr = compute_annual_depreciation(asset, 2024)
        monthly = Decimal("275000") / (Decimal("27.5") * 12)
        expected = (monthly * Decimal("5.5")).quantize(Decimal("0.01"))
        assert depr == expected

    def test_not_yet_in_service(self):
        """No depreciation before placed-in-service year."""
        asset = _make_residential_asset(placed_year=2025)
        depr = compute_annual_depreciation(asset, 2024)
        assert depr == Decimal("0")

    def test_land_basis_excluded(self):
        """Land portion is not depreciable."""
        asset = _make_residential_asset(
            original_basis=Decimal("300000"),
            land_basis=Decimal("50000"),
        )
        depr = compute_annual_depreciation(asset, 2021)
        expected = (Decimal("250000") / Decimal("27.5")).quantize(Decimal("0.01"))
        assert depr == expected


class TestCommercial39Year:
    """Nonresidential real property: 39yr straight-line, mid-month."""

    def test_full_year(self):
        asset = DepreciationAsset(
            asset_id="comm-1",
            activity_id="prop-2",
            category="building",
            placed_in_service_date=date(2020, 3, 1),
            recovery_period_years=Decimal("39"),
            method="straight_line",
            convention="mid_month",
            original_basis=Decimal("390000"),
        )
        depr = compute_annual_depreciation(asset, 2021)
        expected = (Decimal("390000") / Decimal("39")).quantize(Decimal("0.01"))
        assert depr == expected  # $10,000.00

    def test_first_year_march(self):
        """Commercial property placed in service March: 9.5 months."""
        asset = DepreciationAsset(
            asset_id="comm-2",
            activity_id="prop-2",
            category="building",
            placed_in_service_date=date(2024, 3, 1),
            recovery_period_years=Decimal("39"),
            method="straight_line",
            convention="mid_month",
            original_basis=Decimal("390000"),
        )
        depr = compute_annual_depreciation(asset, 2024)
        monthly = Decimal("390000") / (Decimal("39") * 12)
        expected = (monthly * Decimal("9.5")).quantize(Decimal("0.01"))
        assert depr == expected


class TestFinalYearDisposal:
    """Disposition year depreciation with mid-month convention."""

    def test_disposal_june(self):
        """Disposed in June: 5.5 months of depreciation."""
        asset = _make_residential_asset(
            placed_year=2020,
            placed_month=1,
            disposed_date=date(2024, 6, 15),
        )
        depr = compute_annual_depreciation(asset, 2024)
        monthly = Decimal("275000") / (Decimal("27.5") * 12)
        expected = (monthly * Decimal("5.5")).quantize(Decimal("0.01"))
        assert depr == expected

    def test_disposal_january(self):
        """Disposed in January: 0.5 months."""
        asset = _make_residential_asset(
            placed_year=2020,
            disposed_date=date(2024, 1, 10),
        )
        depr = compute_annual_depreciation(asset, 2024)
        monthly = Decimal("275000") / (Decimal("27.5") * 12)
        expected = (monthly * Decimal("0.5")).quantize(Decimal("0.01"))
        assert depr == expected

    def test_no_depreciation_after_disposal(self):
        """No depreciation in years after disposal."""
        asset = _make_residential_asset(
            placed_year=2020,
            disposed_date=date(2023, 6, 15),
        )
        depr = compute_annual_depreciation(asset, 2024)
        assert depr == Decimal("0")


class TestConversionFromPersonalUse:
    """Converted personal residence to rental — basis = min(adjusted, FMV)."""

    def test_fmv_lower_than_basis(self):
        """FMV at conversion is lower — use FMV as depreciable basis."""
        basis = compute_conversion_basis(
            adjusted_basis=Decimal("400000"),
            fmv_at_conversion=Decimal("350000"),
        )
        assert basis == Decimal("350000")

    def test_basis_lower_than_fmv(self):
        """Adjusted basis is lower — use adjusted basis."""
        basis = compute_conversion_basis(
            adjusted_basis=Decimal("300000"),
            fmv_at_conversion=Decimal("400000"),
        )
        assert basis == Decimal("300000")

    def test_equal_values(self):
        """Equal basis and FMV."""
        basis = compute_conversion_basis(
            adjusted_basis=Decimal("350000"),
            fmv_at_conversion=Decimal("350000"),
        )
        assert basis == Decimal("350000")

    def test_conversion_asset_depreciation(self):
        """Full test: conversion basis feeds into depreciation calc."""
        conv_basis = compute_conversion_basis(
            adjusted_basis=Decimal("400000"),
            fmv_at_conversion=Decimal("330000"),
        )
        # Create asset with the conversion basis (minus land)
        land = Decimal("80000")
        asset = DepreciationAsset(
            asset_id="conv-1",
            activity_id="prop-conv",
            category="building",
            placed_in_service_date=date(2024, 4, 1),
            recovery_period_years=Decimal("27.5"),
            method="straight_line",
            convention="mid_month",
            original_basis=conv_basis,
            land_basis=land,
        )
        depr = compute_annual_depreciation(asset, 2024)
        depreciable = conv_basis - land  # 250000
        monthly = depreciable / (Decimal("27.5") * 12)
        expected = (monthly * Decimal("8.5")).quantize(Decimal("0.01"))  # April: 8.5 months
        assert depr == expected


class TestMultipleAssetsPerProperty:
    """Multiple assets (building, appliances, improvements) for one property."""

    def test_aggregate_depreciation(self):
        """compute_property_depreciation sums all assets for the activity."""
        activity = RentalActivity(
            activity_id="prop-multi",
            address="456 Oak St",
        )
        building = DepreciationAsset(
            asset_id="bldg-m",
            activity_id="prop-multi",
            category="building",
            placed_in_service_date=date(2020, 1, 15),
            recovery_period_years=Decimal("27.5"),
            convention="mid_month",
            original_basis=Decimal("275000"),
        )
        appliance = DepreciationAsset(
            asset_id="appl-m",
            activity_id="prop-multi",
            category="appliance",
            placed_in_service_date=date(2024, 6, 1),
            recovery_period_years=Decimal("5"),
            convention="half_year",
            original_basis=Decimal("5000"),
        )
        assets = [building, appliance]
        total = compute_property_depreciation(activity, assets, 2024)

        bldg_depr = compute_annual_depreciation(building, 2024)
        appl_depr = compute_annual_depreciation(appliance, 2024)
        expected = (bldg_depr + appl_depr).quantize(Decimal("0.01"))
        assert total == expected

    def test_ignores_other_activity_assets(self):
        """Only assets matching activity_id are included."""
        activity = RentalActivity(activity_id="prop-a")
        asset_a = DepreciationAsset(
            asset_id="a1", activity_id="prop-a",
            placed_in_service_date=date(2020, 1, 15),
            recovery_period_years=Decimal("27.5"), convention="mid_month",
            original_basis=Decimal("275000"),
        )
        asset_b = DepreciationAsset(
            asset_id="b1", activity_id="prop-b",
            placed_in_service_date=date(2020, 1, 15),
            recovery_period_years=Decimal("27.5"), convention="mid_month",
            original_basis=Decimal("275000"),
        )
        total = compute_property_depreciation(activity, [asset_a, asset_b], 2021)
        expected = compute_annual_depreciation(asset_a, 2021)
        assert total == expected

    def test_ownership_pct(self):
        """50% ownership reduces depreciation proportionally."""
        activity = RentalActivity(
            activity_id="prop-half",
            ownership_pct=Decimal("50"),
        )
        asset = DepreciationAsset(
            asset_id="h1", activity_id="prop-half",
            placed_in_service_date=date(2020, 1, 15),
            recovery_period_years=Decimal("27.5"), convention="mid_month",
            original_basis=Decimal("275000"),
        )
        total = compute_property_depreciation(activity, [asset], 2021)
        full = compute_annual_depreciation(asset, 2021)
        expected = (full * Decimal("0.5")).quantize(Decimal("0.01"))
        assert total == expected


class TestEdgeCases:
    """Edge cases and guard rails."""

    def test_fully_depreciated(self):
        """No depreciation when fully depreciated."""
        asset = _make_residential_asset(
            original_basis=Decimal("275000"),
            prior_accumulated=Decimal("275000"),
        )
        depr = compute_annual_depreciation(asset, 2024)
        assert depr == Decimal("0")

    def test_remaining_basis_cap(self):
        """Depreciation capped at remaining basis."""
        asset = _make_residential_asset(
            original_basis=Decimal("275000"),
            prior_accumulated=Decimal("274999"),
        )
        depr = compute_annual_depreciation(asset, 2021)
        assert depr == Decimal("1")

    def test_no_placed_date(self):
        """No depreciation without placed-in-service date."""
        asset = DepreciationAsset(
            asset_id="nodate",
            original_basis=Decimal("100000"),
        )
        depr = compute_annual_depreciation(asset, 2024)
        assert depr == Decimal("0")

    def test_business_use_pct(self):
        """75% business use reduces depreciation proportionally."""
        asset = _make_residential_asset(business_use_pct=Decimal("75"))
        full = compute_annual_depreciation(
            _make_residential_asset(business_use_pct=Decimal("100")), 2021
        )
        partial = compute_annual_depreciation(asset, 2021)
        expected = (full * Decimal("0.75")).quantize(Decimal("0.01"))
        assert partial == expected


class TestReturnProcessorIntegration:
    """Integration: auto-depreciation in ReturnProcessor."""

    def test_auto_depreciation_overrides_manual(self):
        """When assets exist, auto-computed depreciation replaces manual."""
        proc = ReturnProcessor(tax_year=2024)
        proc.set_filing_status("married_filing_jointly")
        proc.add_w2(wages=Decimal("200000"), federal_withheld=Decimal("40000"),
                     medicare_wages=Decimal("200000"))

        # Add property with manual depreciation of $5000
        proc.add_schedule_e(
            address="123 Main St",
            rental_income=Decimal("24000"),
            depreciation=Decimal("5000"),
            activity_id="prop-test",
        )

        # Add rental activity and asset
        activity = RentalActivity(activity_id="prop-test", address="123 Main St")
        proc.add_rental_activity(activity)

        asset = DepreciationAsset(
            asset_id="bldg-test",
            activity_id="prop-test",
            category="building",
            placed_in_service_date=date(2024, 1, 15),
            recovery_period_years=Decimal("27.5"),
            convention="mid_month",
            original_basis=Decimal("275000"),
        )
        proc.add_depreciation_asset(asset)

        result = proc.calculate()

        # Auto-computed depreciation should differ from manual $5000
        auto_depr = compute_annual_depreciation(asset, 2024)
        assert auto_depr != Decimal("5000")

        # The property should show auto-computed depreciation
        prop = result.schedule_e_properties[0]
        assert prop["depreciation"] == auto_depr
        assert "depreciation_auto" in prop

    def test_depreciation_annotation_generated(self):
        """Auto-depreciation generates a review annotation."""
        proc = ReturnProcessor(tax_year=2024)
        proc.set_filing_status("married_filing_jointly")
        proc.add_w2(wages=Decimal("200000"), federal_withheld=Decimal("40000"),
                     medicare_wages=Decimal("200000"))

        proc.add_schedule_e(
            address="789 Elm Ave",
            rental_income=Decimal("20000"),
            depreciation=Decimal("3000"),
            activity_id="prop-ann",
        )
        activity = RentalActivity(activity_id="prop-ann", address="789 Elm Ave")
        proc.add_rental_activity(activity)
        asset = DepreciationAsset(
            asset_id="bldg-ann",
            activity_id="prop-ann",
            category="building",
            placed_in_service_date=date(2020, 6, 15),
            recovery_period_years=Decimal("27.5"),
            convention="mid_month",
            original_basis=Decimal("275000"),
        )
        proc.add_depreciation_asset(asset)

        result = proc.calculate()
        depr_annotations = [a for a in result.annotations if a.source == "depreciation_auto"]
        assert len(depr_annotations) == 1
        assert "auto-computed" in depr_annotations[0].message

    def test_no_assets_uses_manual_depreciation(self):
        """Without depreciation assets, manual scalar is used."""
        proc = ReturnProcessor(tax_year=2024)
        proc.set_filing_status("married_filing_jointly")
        proc.add_w2(wages=Decimal("100000"), federal_withheld=Decimal("15000"),
                     medicare_wages=Decimal("100000"))
        proc.add_schedule_e(
            address="555 Pine St",
            rental_income=Decimal("18000"),
            depreciation=Decimal("8000"),
        )
        result = proc.calculate()
        prop = result.schedule_e_properties[0]
        assert prop["depreciation"] == Decimal("8000")
        assert "depreciation_auto" not in prop
