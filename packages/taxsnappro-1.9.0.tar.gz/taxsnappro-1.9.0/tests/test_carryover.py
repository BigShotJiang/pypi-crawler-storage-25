"""Tests for ST/LT Capital Loss Carryover (Phase 1, Task 1.2)."""

from decimal import Decimal

import pytest

from src.computation.schedule_d import ScheduleDResult, compute_schedule_d
from src.core.return_processor import ReturnProcessor
from src.models.prior_year import PriorYearData


class TestScheduleDCarryoverWorksheet:
    """Test the Capital Loss Carryover Worksheet logic."""

    def test_net_loss_under_3k_no_carryover(self):
        """Net loss < $3K → fully deductible, no carryover."""
        result = compute_schedule_d(
            short_term_gains=Decimal("-2000"),
            long_term_gains=Decimal("0"),
        )
        assert result.capital_gain_for_1040 == Decimal("-2000")
        assert result.capital_loss_carryover_st == Decimal("0")
        assert result.capital_loss_carryover_lt == Decimal("0")

    def test_net_loss_exactly_3k_no_carryover(self):
        """Net loss == $3K → fully deductible, no carryover."""
        result = compute_schedule_d(
            short_term_gains=Decimal("-3000"),
            long_term_gains=Decimal("0"),
        )
        assert result.capital_gain_for_1040 == Decimal("-3000")
        assert result.capital_loss_carryover_st == Decimal("0")
        assert result.capital_loss_carryover_lt == Decimal("0")

    def test_st_loss_10k_no_lt_carryover_7k_st(self):
        """Net ST loss $10K, no LT → $3K deducted, $7K ST carryover."""
        result = compute_schedule_d(
            short_term_gains=Decimal("-10000"),
            long_term_gains=Decimal("0"),
        )
        assert result.capital_gain_for_1040 == Decimal("-3000")
        assert result.capital_loss_carryover_st == Decimal("-7000")
        assert result.capital_loss_carryover_lt == Decimal("0")

    def test_lt_loss_10k_no_st_carryover_7k_lt(self):
        """Net LT loss $10K, no ST → $3K deducted, $7K LT carryover."""
        result = compute_schedule_d(
            short_term_gains=Decimal("0"),
            long_term_gains=Decimal("-10000"),
        )
        assert result.capital_gain_for_1040 == Decimal("-3000")
        assert result.capital_loss_carryover_st == Decimal("0")
        assert result.capital_loss_carryover_lt == Decimal("-7000")

    def test_mixed_st_loss_5k_lt_gain_1k(self):
        """ST loss $5K + LT gain $1K → net loss $4K, $3K deducted.
        ST carryover: -5000 + 3000(deduction) + 1000(LT offset) = -1000
        LT carryover: 0 (LT is positive)
        """
        result = compute_schedule_d(
            short_term_gains=Decimal("-5000"),
            long_term_gains=Decimal("1000"),
        )
        assert result.net_short_term == Decimal("-5000")
        assert result.net_long_term == Decimal("1000")
        assert result.capital_gain_for_1040 == Decimal("-3000")
        assert result.capital_loss_carryover_st == Decimal("-1000")
        assert result.capital_loss_carryover_lt == Decimal("0")

    def test_both_st_and_lt_losses(self):
        """ST loss $8K + LT loss $5K → net $13K loss.
        $3K deduction: absorbed by ST first ($3K from ST).
        ST carryover: -8000 + 3000 = -5000
        LT carryover: -5000 + 0 = -5000
        """
        result = compute_schedule_d(
            short_term_gains=Decimal("-8000"),
            long_term_gains=Decimal("-5000"),
        )
        assert result.capital_gain_for_1040 == Decimal("-3000")
        assert result.capital_loss_carryover_st == Decimal("-5000")
        assert result.capital_loss_carryover_lt == Decimal("-5000")
        assert result.capital_loss_carryover_total == Decimal("-10000")

    def test_mfs_1500_limit(self):
        """MFS filing status uses $1,500 loss limit."""
        result = compute_schedule_d(
            short_term_gains=Decimal("-5000"),
            long_term_gains=Decimal("0"),
            filing_status="married_filing_separately",
        )
        assert result.capital_gain_for_1040 == Decimal("-1500")
        assert result.capital_loss_carryover_st == Decimal("-3500")

    def test_prior_year_st_carryover_applied(self):
        """Prior year ST carryover combines with current year gains."""
        result = compute_schedule_d(
            short_term_gains=Decimal("2000"),
            long_term_gains=Decimal("0"),
            prior_st_carryover=Decimal("-5000"),
        )
        # Net ST = 2000 + (-5000) = -3000, net total = -3000
        assert result.net_short_term == Decimal("-3000")
        assert result.capital_gain_for_1040 == Decimal("-3000")
        assert result.capital_loss_carryover_st == Decimal("0")

    def test_prior_year_both_carryovers(self):
        """Prior ST and LT carryovers with current year gains."""
        result = compute_schedule_d(
            short_term_gains=Decimal("1000"),
            long_term_gains=Decimal("2000"),
            prior_st_carryover=Decimal("-6000"),
            prior_lt_carryover=Decimal("-4000"),
        )
        # Net ST = 1000 + (-6000) = -5000
        # Net LT = 2000 + (-4000) = -2000
        # Net total = -7000, deduct $3K, carryover $4K
        assert result.net_short_term == Decimal("-5000")
        assert result.net_long_term == Decimal("-2000")
        assert result.capital_gain_for_1040 == Decimal("-3000")
        # ST carryover: -5000 + 3000(deduction) = -2000 (no LT gain to offset)
        assert result.capital_loss_carryover_st == Decimal("-2000")
        # LT carryover: -2000 + 0(deduction left) = -2000 (no ST gain to offset)
        assert result.capital_loss_carryover_lt == Decimal("-2000")

    def test_net_gain_no_carryover(self):
        """Net gain → no loss limitation, no carryover."""
        result = compute_schedule_d(
            short_term_gains=Decimal("5000"),
            long_term_gains=Decimal("10000"),
        )
        assert result.capital_gain_for_1040 == Decimal("15000")
        assert result.capital_loss_carryover_st == Decimal("0")
        assert result.capital_loss_carryover_lt == Decimal("0")


class TestReturnProcessorCarryover:
    """Test carryover wiring through ReturnProcessor."""

    def test_set_prior_year_data_wires_carryover(self):
        proc = ReturnProcessor(tax_year=2024)
        proc.set_filing_status("married_filing_jointly")
        proc.add_w2(wages=Decimal("100000"), federal_withheld=Decimal("15000"),
                     medicare_wages=Decimal("100000"))
        proc.set_capital_gains(short_term=Decimal("2000"), long_term=Decimal("0"))
        proc.set_prior_year_data(PriorYearData(
            tax_year=2023,
            capital_loss_carryover_st=Decimal("-8000"),
        ))
        result = proc.calculate()
        # Net ST = 2000 + (-8000) = -6000, capped at -3000 for 1040
        assert result.capital_gains == Decimal("-3000")
        # Carryover: -6000 + 3000 = -3000
        assert result.capital_loss_carryover_st_next == Decimal("-3000")
        assert result.capital_loss_carryover_lt_next == Decimal("0")

    def test_no_prior_year_data_works(self):
        """Without prior year data, behaves identically to before."""
        proc = ReturnProcessor(tax_year=2024)
        proc.set_filing_status("single")
        proc.add_w2(wages=Decimal("50000"), federal_withheld=Decimal("5000"),
                     medicare_wages=Decimal("50000"))
        proc.set_capital_gains(short_term=Decimal("-1000"), long_term=Decimal("500"))
        result = proc.calculate()
        assert result.capital_gains == Decimal("-500")
        assert result.capital_loss_carryover_st_next == Decimal("0")
        assert result.capital_loss_carryover_lt_next == Decimal("0")
