from __future__ import annotations

import asyncio
import json
from datetime import date
from pathlib import Path

import pandas as pd

from src.taxsnappro.portfolio import advisor, backtest, screenshot


class _FakeBlock:
    def __init__(self, text: str):
        self.text = text


class _FakeResponse:
    def __init__(self, text: str):
        self.content = [_FakeBlock(text)]


class _FakeMessages:
    def __init__(self, text: str):
        self.text = text
        self.calls = []

    def create(self, **kwargs):
        self.calls.append(kwargs)
        return _FakeResponse(self.text)


class _FakeAnthropicClient:
    def __init__(self, text: str):
        self.messages = _FakeMessages(text)


def test_recognize_screenshot_parses_mock_claude_response(monkeypatch):
    payload = {
        "broker": "Robinhood",
        "confidence": 0.91,
        "raw_text": "2 holdings visible",
        "holdings": [
            {
                "ticker": "AAPL",
                "shares": 10,
                "cost_basis": 1500,
                "market_value": 1900,
                "current_price": 190,
                "confidence": 0.95,
            },
            {
                "ticker": "MSFT",
                "shares": 5,
                "cost_basis": 1200,
                "market_value": 1500,
                "current_price": 300,
                "confidence": 0.9,
            },
        ],
    }
    fake_client = _FakeAnthropicClient(json.dumps(payload))
    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")
    monkeypatch.setattr(screenshot, "Anthropic", lambda api_key: fake_client)

    portfolio = asyncio.run(screenshot.recognize_screenshot(b"png-bytes"))

    assert portfolio.broker == "Robinhood"
    assert portfolio.confidence == 0.91
    assert [holding.ticker for holding in portfolio.holdings] == ["AAPL", "MSFT"]
    assert "Portfolio recognition" in screenshot.format_for_confirmation(portfolio)
    assert fake_client.messages.calls[0]["messages"][0]["content"][1]["source"]["data"]


def test_build_diagnosis_prompt_includes_backtest_and_tax_context():
    portfolio = screenshot.Portfolio(
        holdings=[
            screenshot.Holding(ticker="AAPL", shares=10, cost_basis=2000, market_value=1700, current_price=170),
            screenshot.Holding(ticker="MSFT", shares=5, cost_basis=1000, market_value=1500, current_price=300),
        ],
        broker="Schwab",
        confidence=0.8,
    )
    result = backtest.BacktestResult(
        start_date=date(2024, 1, 1),
        end_date=date(2024, 12, 31),
        cagr=0.12,
        sharpe=1.1,
        sortino=1.4,
        max_drawdown=-0.18,
        volatility=0.22,
        benchmark_cagr=0.1,
        alpha=0.02,
        beta=0.95,
    )
    tax_opportunities = ["AAPL: harvest about $300.00 of losses."]

    prompt = advisor._build_diagnosis_prompt(portfolio, result, tax_opportunities)

    assert "Portfolio holdings:" in prompt
    assert '"ticker": "AAPL"' in prompt
    assert '"cagr": 0.12' in prompt
    assert "Tax-loss harvesting context:" in prompt
    assert "AAPL: harvest about $300.00 of losses." in prompt


def test_diagnose_portfolio_parses_mock_claude_response(monkeypatch):
    portfolio = screenshot.Portfolio(
        holdings=[
            screenshot.Holding(ticker="TSLA", shares=10, cost_basis=2500, market_value=2000, current_price=200),
            screenshot.Holding(ticker="VOO", shares=4, cost_basis=1500, market_value=1800, current_price=450),
        ]
    )
    payload = {
        "summary": "Moderate risk with one concentrated growth position.",
        "risk_level": "Medium",
        "concentration_warning": "TSLA is more than one third of the portfolio.",
        "sector_exposure": {"Technology": 0.55, "ETF": 0.45},
        "suggestions": ["Trim TSLA gradually", "Increase diversification"],
    }
    fake_client = _FakeAnthropicClient(json.dumps(payload))
    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")
    monkeypatch.setattr(advisor, "Anthropic", lambda api_key: fake_client)

    diagnosis = asyncio.run(advisor.diagnose_portfolio(portfolio, include_tax_analysis=True))

    assert diagnosis.risk_level == "Medium"
    assert diagnosis.suggestions == ["Trim TSLA gradually", "Increase diversification"]
    assert diagnosis.tax_opportunities
    formatted = advisor.format_diagnosis(diagnosis)
    assert "Portfolio diagnosis" in formatted
    assert "Tax opportunities:" in formatted


def test_run_backtest_uses_mock_yfinance_data(monkeypatch):
    dates = pd.date_range("2024-01-01", periods=6, freq="D")
    prices = pd.DataFrame(
        {
            ("Close", "AAPL"): [100, 102, 101, 104, 106, 107],
            ("Close", "MSFT"): [200, 201, 203, 202, 205, 208],
        },
        index=dates,
    )
    benchmark_prices = pd.DataFrame({("Close", "SPY"): [300, 301, 302, 303, 305, 307]}, index=dates)

    def fake_download(tickers, start=None, progress=False, auto_adjust=True):
        if tickers == ["SPY"]:
            return benchmark_prices
        return prices

    monkeypatch.setattr(backtest, "yf", type("FakeYF", (), {"download": staticmethod(fake_download)}))

    result = backtest.run_backtest(["AAPL", "MSFT"], [0.6, 0.4], start_date="2024-01-01")

    assert result.start_date == date(2024, 1, 1)
    assert result.end_date == date(2024, 1, 6)
    assert result.cagr != 0
    assert result.sharpe != 0
    assert result.benchmark_cagr is not None
    assert result.beta is not None


def test_generate_tearsheet_writes_html(monkeypatch, tmp_path: Path):
    result = backtest.BacktestResult(
        start_date=date(2024, 1, 1),
        end_date=date(2024, 1, 5),
        cagr=0.1,
        sharpe=1.2,
        sortino=1.5,
        max_drawdown=-0.08,
        volatility=0.2,
        benchmark_cagr=0.09,
        alpha=0.01,
        beta=0.95,
    )
    dates = pd.date_range("2024-01-01", periods=5, freq="D")
    returns = pd.Series([0.01, -0.005, 0.012, 0.004, 0.003], index=dates)
    benchmark_returns = pd.Series([0.008, 0.001, 0.009, 0.002, 0.004], index=dates)

    monkeypatch.setattr(backtest, "run_backtest", lambda *args, **kwargs: result)
    monkeypatch.setattr(backtest, "_portfolio_return_series", lambda *args, **kwargs: (returns, pd.DataFrame()))
    monkeypatch.setattr(
        backtest,
        "_download_prices",
        lambda *args, **kwargs: pd.DataFrame({"SPY": [300, 301, 304, 305, 307]}, index=dates),
    )
    monkeypatch.setattr(backtest, "_build_chart_base64", lambda *args, **kwargs: "ZmFrZS1jaGFydA==")

    output_path = tmp_path / "tearsheet.html"
    written = backtest.generate_tearsheet(["AAPL"], [1.0], output_path=str(output_path))

    html = output_path.read_text(encoding="utf-8")
    assert written == str(output_path)
    assert "Portfolio Tearsheet" in html
    assert "data:image/png;base64" in html
