"""Tests for Form 2210 estimated tax penalty detection."""

from decimal import Decimal

from src.computation.form_2210 import check_underpayment, generate_2210_annotations


class TestSafeHarborMinTax:
    def test_balance_under_1000_no_penalty(self):
        result = check_underpayment(
            total_tax=Decimal("10000"),
            total_withheld=Decimal("9500"),
            total_estimated_payments=Decimal("0"),
            prior_year_tax=Decimal("8000"),
        )
        assert result.penalty_likely is False
        assert result.safe_harbor_met == "min_tax"

    def test_exact_1000_shortfall_no_penalty(self):
        """$999 owed — still under $1000 threshold."""
        result = check_underpayment(
            total_tax=Decimal("10000"),
            total_withheld=Decimal("9001"),
            total_estimated_payments=Decimal("0"),
            prior_year_tax=Decimal("8000"),
        )
        assert result.penalty_likely is False
        assert result.safe_harbor_met == "min_tax"


class TestSafeHarbor90Percent:
    def test_90_pct_current_year_no_penalty(self):
        result = check_underpayment(
            total_tax=Decimal("20000"),
            total_withheld=Decimal("18000"),
            total_estimated_payments=Decimal("0"),
            prior_year_tax=None,
        )
        assert result.penalty_likely is False
        assert result.safe_harbor_met == "current_year"

    def test_89_pct_current_year_penalty(self):
        """Just under 90% — penalty likely."""
        result = check_underpayment(
            total_tax=Decimal("20000"),
            total_withheld=Decimal("17000"),
            total_estimated_payments=Decimal("0"),
            prior_year_tax=None,
        )
        assert result.penalty_likely is True


class TestSafeHarborPriorYear:
    def test_100_pct_prior_year_no_penalty(self):
        result = check_underpayment(
            total_tax=Decimal("25000"),
            total_withheld=Decimal("15000"),
            total_estimated_payments=Decimal("5000"),
            prior_year_tax=Decimal("20000"),
            prior_year_agi=Decimal("100000"),
        )
        assert result.penalty_likely is False
        assert result.safe_harbor_met == "prior_year"

    def test_110_pct_high_income_no_penalty(self):
        """AGI > $150K requires 110% of prior year tax."""
        result = check_underpayment(
            total_tax=Decimal("50000"),
            total_withheld=Decimal("22000"),
            total_estimated_payments=Decimal("0"),
            prior_year_tax=Decimal("20000"),
            prior_year_agi=Decimal("200000"),
        )
        assert result.penalty_likely is False
        assert result.safe_harbor_met == "prior_year"
        assert "110%" in result.recommendation

    def test_high_income_under_110_pct_penalty(self):
        """AGI > $150K and only paid 100% of prior — penalty."""
        result = check_underpayment(
            total_tax=Decimal("50000"),
            total_withheld=Decimal("20000"),
            total_estimated_payments=Decimal("0"),
            prior_year_tax=Decimal("20000"),
            prior_year_agi=Decimal("200000"),
        )
        assert result.penalty_likely is True
        assert result.shortfall > Decimal("0")

    def test_mfs_75k_threshold(self):
        """MFS uses $75K threshold for 110% rule."""
        result = check_underpayment(
            total_tax=Decimal("30000"),
            total_withheld=Decimal("11000"),
            total_estimated_payments=Decimal("0"),
            prior_year_tax=Decimal("10000"),
            prior_year_agi=Decimal("80000"),
            filing_status="married_filing_separately",
        )
        assert result.penalty_likely is False
        assert result.safe_harbor_met == "prior_year"
        assert "110%" in result.recommendation


class TestPenaltyEstimation:
    def test_penalty_amount_positive(self):
        result = check_underpayment(
            total_tax=Decimal("30000"),
            total_withheld=Decimal("10000"),
            total_estimated_payments=Decimal("0"),
            prior_year_tax=None,
        )
        assert result.penalty_likely is True
        assert result.estimated_penalty > Decimal("0")
        assert result.shortfall > Decimal("0")

    def test_recommendation_mentions_w4(self):
        result = check_underpayment(
            total_tax=Decimal("30000"),
            total_withheld=Decimal("15000"),
            total_estimated_payments=Decimal("0"),
            prior_year_tax=None,
        )
        assert "W-4" in result.recommendation or "1040-ES" in result.recommendation


class TestAnnotations:
    def test_penalty_annotation(self):
        result = check_underpayment(
            total_tax=Decimal("30000"),
            total_withheld=Decimal("10000"),
            total_estimated_payments=Decimal("0"),
            prior_year_tax=None,
        )
        annotations = generate_2210_annotations(result)
        assert len(annotations) == 1
        assert annotations[0].severity == "warning"
        assert annotations[0].action_required is True
        assert annotations[0].category == "estimated_tax"

    def test_no_penalty_annotation(self):
        result = check_underpayment(
            total_tax=Decimal("10000"),
            total_withheld=Decimal("10000"),
            total_estimated_payments=Decimal("0"),
            prior_year_tax=Decimal("8000"),
        )
        annotations = generate_2210_annotations(result)
        assert len(annotations) == 1
        assert annotations[0].severity == "info"
