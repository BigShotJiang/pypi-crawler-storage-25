"""Tests for Tax Loss Harvesting planning module."""

from datetime import date, timedelta
from decimal import Decimal

from src.planning.tlh import (
    PortfolioPosition,
    TaxLot,
    TLHCandidate,
    check_wash_sale_window,
    estimate_tax_benefit,
    identify_tlh_candidates,
)


def _lot(
    purchase_date: date,
    shares: Decimal,
    cost: Decimal,
    current: Decimal,
) -> TaxLot:
    return TaxLot(
        purchase_date=purchase_date,
        shares=shares,
        cost_basis_per_share=cost,
        current_price_per_share=current,
    )


class TestCheckWashSaleWindow:
    def test_purchase_within_30_days_after(self):
        sell = date(2025, 6, 15)
        purchases = [date(2025, 7, 1)]  # 16 days after
        assert check_wash_sale_window(sell, purchases) is True

    def test_purchase_within_30_days_before(self):
        sell = date(2025, 6, 15)
        purchases = [date(2025, 5, 20)]  # 26 days before
        assert check_wash_sale_window(sell, purchases) is True

    def test_purchase_outside_window(self):
        sell = date(2025, 6, 15)
        purchases = [date(2025, 8, 1)]  # 47 days after
        assert check_wash_sale_window(sell, purchases) is False

    def test_no_purchases(self):
        assert check_wash_sale_window(date(2025, 6, 15), []) is False

    def test_exact_boundary(self):
        """Exactly 30 days — still within window."""
        sell = date(2025, 6, 15)
        purchases = [date(2025, 7, 15)]  # exactly 30 days
        assert check_wash_sale_window(sell, purchases) is True


class TestIdentifyTLHCandidates:
    def test_finds_loss_position(self):
        positions = [
            PortfolioPosition(
                symbol="AAPL",
                lots=[_lot(date(2024, 1, 1), Decimal("10"), Decimal("200"), Decimal("150"))],
            )
        ]
        candidates = identify_tlh_candidates(
            positions, Decimal("0.24"), reference_date=date(2025, 6, 15)
        )
        assert len(candidates) == 1
        assert candidates[0].symbol == "AAPL"
        assert candidates[0].total_unrealized_loss == Decimal("-500")

    def test_skips_gain_position(self):
        positions = [
            PortfolioPosition(
                symbol="MSFT",
                lots=[_lot(date(2024, 1, 1), Decimal("10"), Decimal("100"), Decimal("150"))],
            )
        ]
        candidates = identify_tlh_candidates(
            positions, Decimal("0.24"), reference_date=date(2025, 6, 15)
        )
        assert len(candidates) == 0

    def test_skips_below_threshold(self):
        positions = [
            PortfolioPosition(
                symbol="XYZ",
                lots=[_lot(date(2024, 1, 1), Decimal("1"), Decimal("110"), Decimal("100"))],
            )
        ]
        # Loss is only $10, below default $100 threshold
        candidates = identify_tlh_candidates(
            positions, Decimal("0.24"), reference_date=date(2025, 6, 15)
        )
        assert len(candidates) == 0

    def test_wash_sale_risk_flagged(self):
        positions = [
            PortfolioPosition(
                symbol="TSLA",
                lots=[_lot(date(2024, 1, 1), Decimal("10"), Decimal("300"), Decimal("200"))],
                recent_purchase_dates=[date(2025, 6, 10)],
            )
        ]
        candidates = identify_tlh_candidates(
            positions, Decimal("0.24"), reference_date=date(2025, 6, 15)
        )
        assert len(candidates) == 1
        assert candidates[0].wash_sale_risk is True

    def test_sorted_by_largest_loss(self):
        positions = [
            PortfolioPosition(
                symbol="A",
                lots=[_lot(date(2024, 1, 1), Decimal("10"), Decimal("200"), Decimal("190"))],
            ),
            PortfolioPosition(
                symbol="B",
                lots=[_lot(date(2024, 1, 1), Decimal("100"), Decimal("200"), Decimal("150"))],
            ),
        ]
        candidates = identify_tlh_candidates(
            positions, Decimal("0.24"), reference_date=date(2025, 6, 15)
        )
        assert candidates[0].symbol == "B"  # -5000 loss
        assert candidates[1].symbol == "A"  # -100 loss


class TestEstimateTaxBenefit:
    def test_basic_benefit(self):
        candidate = TLHCandidate(
            symbol="AAPL",
            lots=[_lot(date(2024, 1, 1), Decimal("100"), Decimal("200"), Decimal("150"))],
        )
        # Loss = $5000, fed rate 24%, state 5% = 29% combined
        benefit = estimate_tax_benefit(candidate, Decimal("0.24"), Decimal("0.05"))
        assert benefit == Decimal("1450.00")  # 5000 * 0.29

    def test_no_loss_no_benefit(self):
        candidate = TLHCandidate(
            symbol="MSFT",
            lots=[_lot(date(2024, 1, 1), Decimal("100"), Decimal("100"), Decimal("150"))],
        )
        benefit = estimate_tax_benefit(candidate, Decimal("0.24"))
        assert benefit == Decimal("0.00")
