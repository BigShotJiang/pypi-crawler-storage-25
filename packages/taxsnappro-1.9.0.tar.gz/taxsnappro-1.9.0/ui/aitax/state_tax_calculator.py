"""
State Tax Calculator Module

Supports: California (CA), Massachusetts (MA)
Based on 2024 tax rules.

References:
- CA: FTB Form 540, Schedule CA, Schedule P (AMT)
- MA: Form 1, Schedule B
"""

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any


# ========== California Tax Constants (2024) ==========

CA_BRACKETS_SINGLE = [
    (10756, 0.01),
    (25499, 0.02),
    (40245, 0.04),
    (55866, 0.06),
    (70606, 0.08),
    (360659, 0.093),
    (432787, 0.103),
    (721314, 0.113),
    (1000000, 0.123),
    (float('inf'), 0.133),
]

CA_BRACKETS_MFJ = [
    (21512, 0.01),
    (50998, 0.02),
    (80490, 0.04),
    (111732, 0.06),
    (141732, 0.08),
    (721318, 0.093),
    (865574, 0.103),
    (1000000, 0.113),
    (1442628, 0.123),
    (float('inf'), 0.133),
]

CA_BRACKETS_HOH = [
    (21527, 0.01),
    (50998, 0.02),
    (65744, 0.04),
    (81364, 0.06),
    (96107, 0.08),
    (490493, 0.093),
    (588593, 0.103),
    (980987, 0.113),
    (1000000, 0.123),
    (float('inf'), 0.133),
]

CA_STANDARD_DEDUCTION = {
    "single": 5540,
    "married_filing_jointly": 11080,
    "married_filing_separately": 5540,
    "head_of_household": 11080,
    "qualifying_widow": 11080,
}

# California uses exemption CREDITS, not deductions
CA_EXEMPTION_CREDIT = {
    "personal": 149,  # Per filer
    "dependent": 461,  # Per dependent
}

# California AMT (2024) - Form 540 Schedule P
CA_AMT_EXEMPTION = {
    "single": 95251,
    "married_filing_jointly": 127044,
    "married_filing_separately": 63522,
    "head_of_household": 95251,
    "qualifying_widow": 127044,
}

CA_AMT_PHASEOUT_START = {
    "single": 357022,
    "married_filing_jointly": 476027,
    "married_filing_separately": 238014,
    "head_of_household": 357022,
    "qualifying_widow": 476027,
}

CA_AMT_RATE = 0.07  # California AMT is flat 7%


# ========== Massachusetts Tax Constants (2024) ==========

MA_RATE = 0.05  # Flat 5% rate
MA_MILLIONAIRE_THRESHOLD = 1083150  # 2024 threshold (indexed for inflation)
MA_MILLIONAIRE_SURTAX = 0.04  # Additional 4% on income over threshold

MA_PERSONAL_EXEMPTION = {
    "single": 4400,
    "married_filing_jointly": 8800,
    "married_filing_separately": 4400,
    "head_of_household": 4400,
    "qualifying_widow": 4400,
}

MA_DEPENDENT_EXEMPTION = 1000  # Per dependent

# Massachusetts capital gains rates
MA_SHORT_TERM_CG_RATE = 0.12  # 12% on short-term gains
MA_LONG_TERM_CG_RATE = 0.05   # 5% on long-term gains (same as regular)


# ========== Result Data Classes ==========

@dataclass
class StateAGIAdjustments:
    """Adjustments to convert Federal AGI to State AGI"""
    federal_agi: float = 0
    additions: float = 0  # Add to federal AGI
    subtractions: float = 0  # Subtract from federal AGI
    state_agi: float = 0
    
    # Detail items
    other_state_bond_interest: float = 0  # Add
    home_state_bond_interest: float = 0  # Subtract
    social_security_adjustment: float = 0  # Usually subtract (not taxed by CA/MA)


@dataclass
class StateTaxResult:
    """State tax calculation result"""
    state: str = ""
    filing_status: str = ""
    
    # Income
    federal_agi: float = 0
    state_agi: float = 0
    state_taxable_income: float = 0
    
    # Deductions & Exemptions
    standard_deduction: float = 0
    itemized_deduction: float = 0
    deduction_used: float = 0
    personal_exemption: float = 0
    dependent_exemption: float = 0
    
    # Tax Calculation
    regular_tax: float = 0
    capital_gains_tax: float = 0  # MA only (different rates)
    amt_tax: float = 0  # CA only
    millionaire_surtax: float = 0  # MA only
    
    # Credits
    exemption_credits: float = 0  # CA exemption credits
    other_credits: float = 0
    
    # Final
    total_state_tax: float = 0
    effective_rate: float = 0


# ========== California Tax Calculator ==========

def calculate_ca_tax(
    federal_agi: float,
    filing_status: str,
    wages: float = 0,
    interest_income: float = 0,
    dividend_income: float = 0,
    qualified_dividends: float = 0,
    short_term_gains: float = 0,
    long_term_gains: float = 0,
    rental_income: float = 0,
    itemized_deductions: float = 0,
    num_dependents: int = 0,
    num_filers: int = 1,  # 1 for single, 2 for MFJ
    iso_bargain_element: float = 0,
    other_state_bond_interest: float = 0,
    ca_bond_interest: float = 0,
    social_security: float = 0,
) -> StateTaxResult:
    """
    Calculate California state income tax.
    
    Key differences from Federal:
    1. Capital gains taxed as ordinary income (no preferential rate)
    2. Exemptions are TAX CREDITS, not deductions
    3. Lower standard deduction
    4. Has California AMT (7% flat rate)
    5. Mental Health Services Tax included in top rate (13.3%)
    """
    result = StateTaxResult(state="CA", filing_status=filing_status)
    result.federal_agi = federal_agi
    
    # ===== Step 1: Calculate California AGI =====
    # Start with Federal AGI, then make CA-specific adjustments
    
    additions = 0
    subtractions = 0
    
    # Add: Interest from bonds of other states
    additions += other_state_bond_interest
    
    # Subtract: Interest from CA municipal bonds
    subtractions += ca_bond_interest
    
    # Subtract: Social Security (not taxed in CA)
    subtractions += social_security
    
    state_agi = federal_agi + additions - subtractions
    result.state_agi = state_agi
    
    # ===== Step 2: Deductions =====
    
    # California standard deduction
    ca_std_ded = CA_STANDARD_DEDUCTION.get(filing_status, 5540)
    result.standard_deduction = ca_std_ded
    
    # California itemized deductions (simplified - use federal with adjustments)
    # Note: CA doesn't have SALT cap, but also can't deduct CA state tax
    ca_itemized = itemized_deductions  # Simplified for now
    result.itemized_deduction = ca_itemized
    
    # Use greater of standard or itemized
    deduction = max(ca_std_ded, ca_itemized)
    result.deduction_used = deduction
    
    # ===== Step 3: Calculate Taxable Income =====
    
    taxable_income = max(0, state_agi - deduction)
    result.state_taxable_income = taxable_income
    
    # ===== Step 4: Calculate Regular Tax =====
    
    # Get appropriate brackets
    if filing_status == "married_filing_jointly" or filing_status == "qualifying_widow":
        brackets = CA_BRACKETS_MFJ
    elif filing_status == "head_of_household":
        brackets = CA_BRACKETS_HOH
    else:
        brackets = CA_BRACKETS_SINGLE
    
    # Calculate tax using brackets
    # Note: Capital gains are taxed as ordinary income in CA!
    tax = 0
    prev_bracket = 0
    for bracket_top, rate in brackets:
        if taxable_income <= prev_bracket:
            break
        taxable_in_bracket = min(taxable_income, bracket_top) - prev_bracket
        tax += taxable_in_bracket * rate
        prev_bracket = bracket_top
    
    result.regular_tax = round(tax, 2)
    
    # ===== Step 5: California AMT (Schedule P) =====
    
    if iso_bargain_element > 0:
        # Calculate CA AMT
        # CA AMT is simpler than federal - flat 7% rate
        
        # AMTI = Taxable income + ISO bargain element (and other preferences)
        ca_amti = taxable_income + iso_bargain_element
        
        # AMT exemption with phase-out
        exemption = CA_AMT_EXEMPTION.get(filing_status, 95251)
        phaseout_start = CA_AMT_PHASEOUT_START.get(filing_status, 357022)
        
        if ca_amti > phaseout_start:
            reduction = (ca_amti - phaseout_start) * 0.25
            exemption = max(0, exemption - reduction)
        
        # AMT base
        amt_base = max(0, ca_amti - exemption)
        
        # Tentative minimum tax (flat 7%)
        tentative_amt = amt_base * CA_AMT_RATE
        
        # CA AMT = max(0, tentative AMT - regular tax)
        if tentative_amt > result.regular_tax:
            result.amt_tax = round(tentative_amt - result.regular_tax, 2)
    
    # ===== Step 6: Exemption Credits =====
    
    # California personal exemption is a TAX CREDIT
    personal_credit = CA_EXEMPTION_CREDIT["personal"] * num_filers
    dependent_credit = CA_EXEMPTION_CREDIT["dependent"] * num_dependents
    
    result.exemption_credits = personal_credit + dependent_credit
    result.personal_exemption = personal_credit
    result.dependent_exemption = dependent_credit
    
    # ===== Step 7: Total Tax =====
    
    total_tax = result.regular_tax + result.amt_tax - result.exemption_credits
    total_tax = max(0, total_tax)  # Can't be negative
    
    result.total_state_tax = round(total_tax, 2)
    
    # Calculate effective rate
    if state_agi > 0:
        result.effective_rate = round(result.total_state_tax / state_agi * 100, 2)
    
    return result


# ========== Massachusetts Tax Calculator ==========

def calculate_ma_tax(
    federal_agi: float,
    filing_status: str,
    wages: float = 0,
    interest_income: float = 0,
    dividend_income: float = 0,
    short_term_gains: float = 0,
    long_term_gains: float = 0,
    rental_income: float = 0,
    num_dependents: int = 0,
    other_state_bond_interest: float = 0,
    ma_bond_interest: float = 0,
    social_security: float = 0,
    ss_medicare_paid: float = 0,  # Social Security and Medicare taxes paid (MA deductible)
) -> StateTaxResult:
    """
    Calculate Massachusetts state income tax.
    
    Key features:
    1. Mostly flat 5% rate
    2. "Millionaire Tax" - 4% surtax on income over ~$1.08M
    3. Short-term capital gains: 12%
    4. Long-term capital gains: 5% (same as regular)
    5. No standard deduction, uses personal exemption
    6. No state AMT
    """
    result = StateTaxResult(state="MA", filing_status=filing_status)
    result.federal_agi = federal_agi
    
    # ===== Step 1: Calculate Massachusetts AGI =====
    
    additions = 0
    subtractions = 0
    
    # Add: Interest from bonds of other states
    additions += other_state_bond_interest
    
    # Subtract: Interest from MA municipal bonds
    subtractions += ma_bond_interest
    
    # Subtract: Social Security (not taxed in MA)
    subtractions += social_security
    
    state_agi = federal_agi + additions - subtractions
    result.state_agi = state_agi
    
    # ===== Step 2: Deductions (MA has no standard deduction) =====
    
    result.standard_deduction = 0  # MA doesn't have standard deduction
    
    # MA Line 11a/11b: Deduction for Social Security, Medicare, RR, US/MA Retirement paid
    # This is deductible from MA income
    ss_medicare_deduction = ss_medicare_paid
    
    # Personal exemption
    personal_exemption = MA_PERSONAL_EXEMPTION.get(filing_status, 4400)
    dependent_exemption = MA_DEPENDENT_EXEMPTION * num_dependents
    
    total_exemption = personal_exemption + dependent_exemption
    result.personal_exemption = personal_exemption
    result.dependent_exemption = dependent_exemption
    result.deduction_used = total_exemption + ss_medicare_deduction
    
    # ===== Step 3: Calculate Taxable Income =====
    
    # MA Form 1 logic:
    # Line 10: Total 5.0% Income (wages, business income, etc. - NOT interest/dividends)
    # Line 17: After SS/Medicare deduction
    # Line 19: After exemptions (exemptions only apply to Line 10 income!)
    # Line 20: Interest and Dividend Income (added AFTER exemptions)
    # Line 21: Total Taxable 5.0% Income = Line 19 + Line 20
    
    # Wages and similar 5.0% income (exemption applies)
    line_10_income = wages + rental_income  # 5.0% income
    line_17 = line_10_income - ss_medicare_deduction
    line_19 = max(0, line_17 - total_exemption)
    
    # Interest and dividends (added after exemption, taxed at 5% but no exemption applies)
    line_20 = interest_income + dividend_income
    
    # Total taxable 5.0% income
    taxable_ordinary = line_19 + line_20
    
    result.state_taxable_income = taxable_ordinary + short_term_gains + long_term_gains
    
    # ===== Step 4: Calculate Regular Tax (5% flat) =====
    
    regular_tax = taxable_ordinary * MA_RATE
    result.regular_tax = round(regular_tax, 2)
    
    # ===== Step 5: Capital Gains Tax =====
    
    # Short-term gains: 12%
    st_gains_tax = short_term_gains * MA_SHORT_TERM_CG_RATE
    
    # Long-term gains: 5% (same as regular rate)
    lt_gains_tax = long_term_gains * MA_LONG_TERM_CG_RATE
    
    result.capital_gains_tax = round(st_gains_tax + lt_gains_tax, 2)
    
    # ===== Step 6: Millionaire Surtax =====
    
    # 4% additional tax on income over threshold
    total_income = taxable_ordinary + short_term_gains + long_term_gains
    
    if total_income > MA_MILLIONAIRE_THRESHOLD:
        excess = total_income - MA_MILLIONAIRE_THRESHOLD
        result.millionaire_surtax = round(excess * MA_MILLIONAIRE_SURTAX, 2)
    
    # ===== Step 7: Total Tax =====
    
    total_tax = (
        result.regular_tax + 
        result.capital_gains_tax + 
        result.millionaire_surtax
    )
    
    result.total_state_tax = round(total_tax, 2)
    
    # Calculate effective rate
    if state_agi > 0:
        result.effective_rate = round(result.total_state_tax / state_agi * 100, 2)
    
    return result


# ========== Main Interface ==========

def calculate_state_tax(
    state: str,
    federal_agi: float,
    filing_status: str,
    **kwargs
) -> StateTaxResult:
    """
    Calculate state income tax.
    
    Args:
        state: State code (CA, MA)
        federal_agi: Federal Adjusted Gross Income
        filing_status: Filing status (single, married_filing_jointly, etc.)
        **kwargs: Additional parameters passed to state-specific calculator
    
    Returns:
        StateTaxResult with all tax calculations
    """
    state = state.upper()
    
    if state == "CA":
        return calculate_ca_tax(federal_agi, filing_status, **kwargs)
    elif state == "MA":
        return calculate_ma_tax(federal_agi, filing_status, **kwargs)
    else:
        raise ValueError(f"Unsupported state: {state}. Currently supported: CA, MA")


# ========== Testing ==========

if __name__ == "__main__":
    # Test scenarios
    
    print("=" * 60)
    print("California Tax Test")
    print("=" * 60)
    
    ca_result = calculate_ca_tax(
        federal_agi=400000,
        filing_status="married_filing_jointly",
        wages=380000,
        qualified_dividends=10000,
        long_term_gains=10000,
        num_dependents=2,
        num_filers=2,
    )
    
    print(f"Federal AGI:      ${ca_result.federal_agi:,.0f}")
    print(f"CA AGI:           ${ca_result.state_agi:,.0f}")
    print(f"Deduction:        ${ca_result.deduction_used:,.0f}")
    print(f"Taxable Income:   ${ca_result.state_taxable_income:,.0f}")
    print(f"Regular Tax:      ${ca_result.regular_tax:,.2f}")
    print(f"AMT:              ${ca_result.amt_tax:,.2f}")
    print(f"Exemption Credit: ${ca_result.exemption_credits:,.2f}")
    print(f"TOTAL CA TAX:     ${ca_result.total_state_tax:,.2f}")
    print(f"Effective Rate:   {ca_result.effective_rate:.2f}%")
    
    print("\n" + "=" * 60)
    print("Massachusetts Tax Test")
    print("=" * 60)
    
    ma_result = calculate_ma_tax(
        federal_agi=400000,
        filing_status="married_filing_jointly",
        wages=380000,
        short_term_gains=5000,
        long_term_gains=15000,
        num_dependents=2,
    )
    
    print(f"Federal AGI:      ${ma_result.federal_agi:,.0f}")
    print(f"MA AGI:           ${ma_result.state_agi:,.0f}")
    print(f"Exemption:        ${ma_result.deduction_used:,.0f}")
    print(f"Taxable Income:   ${ma_result.state_taxable_income:,.0f}")
    print(f"Regular Tax:      ${ma_result.regular_tax:,.2f}")
    print(f"Capital Gains:    ${ma_result.capital_gains_tax:,.2f}")
    print(f"Millionaire Tax:  ${ma_result.millionaire_surtax:,.2f}")
    print(f"TOTAL MA TAX:     ${ma_result.total_state_tax:,.2f}")
    print(f"Effective Rate:   {ma_result.effective_rate:.2f}%")
    
    print("\n" + "=" * 60)
    print("ISO Exercise Test (CA AMT)")
    print("=" * 60)
    
    ca_iso = calculate_ca_tax(
        federal_agi=400000,
        filing_status="married_filing_jointly",
        wages=400000,
        iso_bargain_element=200000,
        num_filers=2,
    )
    
    print(f"Taxable Income:   ${ca_iso.state_taxable_income:,.0f}")
    print(f"Regular Tax:      ${ca_iso.regular_tax:,.2f}")
    print(f"CA AMT:           ${ca_iso.amt_tax:,.2f}")
    print(f"TOTAL CA TAX:     ${ca_iso.total_state_tax:,.2f}")
