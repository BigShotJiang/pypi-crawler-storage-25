"""
TaxSnapPro Test Runner - Run tax calculations directly from JSON scenarios.

Usage:
    taxsnappro test scenario.json           # Run single scenario
    taxsnappro test --all                   # Run all built-in scenarios
    taxsnappro test --compare scenario.json # Compare with expected results
"""

import json
from pathlib import Path
from typing import Dict, Any, List, Optional


# Built-in test scenarios
SILICON_VALLEY_SCENARIOS = [
    # ===== COMPLEX SCENARIOS =====
    {
        "name": "Scenario 5: ISO Exercise (AMT Trigger)",
        "description": "Staff Engineer 行权 ISO，触发 AMT",
        "inputs": {
            "filing_status": "married_filing_jointly",
            "w2_list": [
                {"wages": 250000, "medicare_wages": 280000, "federal_withheld": 55000},
                {"wages": 150000, "medicare_wages": 160000, "federal_withheld": 30000},
            ],
            "form_1099_list": [
                {"form_type": "1099-INT", "amount": 5000},
                {"form_type": "1099-DIV", "amount": 10000, "qualified_dividends": 8000},
            ],
            "form_1098_list": [
                {"mortgage_interest": 30000, "property_taxes": 20000},
            ],
            # ISO exercise - bargain element is AMT preference item
            "iso_exercises": [
                {"bargain_element": 200000, "shares": 5000, "exercise_price": 10, "fmv": 50},
            ],
        },
    },
    {
        "name": "Scenario 6: Large Capital Loss Carryover",
        "description": "去年亏了 $50k，今年继续用",
        "inputs": {
            "filing_status": "married_filing_jointly",
            "w2_list": [
                {"wages": 180000, "medicare_wages": 190000, "federal_withheld": 35000},
                {"wages": 160000, "medicare_wages": 170000, "federal_withheld": 30000},
            ],
            "form_1099_list": [
                {"form_type": "1099-INT", "amount": 8000},
                {"form_type": "1099-DIV", "amount": 12000, "qualified_dividends": 10000},
                {"form_type": "1099-B", "amount": 15000, "is_short_term": False},  # This year's gain
            ],
            "form_1098_list": [
                {"mortgage_interest": 25000, "property_taxes": 15000},
            ],
            # Prior year carryover
            "capital_loss_carryover_long": 50000,
        },
    },
    {
        "name": "Scenario 7: Self-Employment + W-2",
        "description": "一人大厂，一人自由职业顾问",
        "inputs": {
            "filing_status": "married_filing_jointly",
            "w2_list": [
                {"wages": 220000, "medicare_wages": 240000, "federal_withheld": 48000},
            ],
            "form_1099_list": [
                {"form_type": "1099-INT", "amount": 3000},
                {"form_type": "1099-NEC", "amount": 120000},  # Consulting income
            ],
            "business_income": [
                {"description": "Consulting LLC", "gross_receipts": 120000, "expenses": 25000, "net_profit": 95000},
            ],
            "form_1098_list": [
                {"mortgage_interest": 22000, "property_taxes": 18000},
            ],
            "form_5498_list": [
                {"contribution": 8300},  # HSA
            ],
        },
    },
    {
        "name": "Scenario 8: Three Rentals (Mixed Profit/Loss)",
        "description": "三套出租房：一套盈利，两套亏损",
        "inputs": {
            "filing_status": "married_filing_jointly",
            "w2_list": [
                {"wages": 140000, "medicare_wages": 150000, "federal_withheld": 25000},
                {"wages": 130000, "medicare_wages": 140000, "federal_withheld": 22000},
            ],
            "form_1099_list": [
                {"form_type": "1099-INT", "amount": 4000},
                {"form_type": "1099-DIV", "amount": 6000, "qualified_dividends": 5000},
            ],
            "rental_properties": [
                {"address": "123 Profit St", "net_income": 12000},   # Profit
                {"address": "456 Loss Ave", "net_income": -8000},    # Loss
                {"address": "789 Loss Blvd", "net_income": -15000},  # Loss
            ],
            "form_1098_list": [
                {"mortgage_interest": 20000, "property_taxes": 12000},
            ],
        },
    },
    {
        "name": "Scenario 9: Millionaire (Max Brackets)",
        "description": "$1.2M 收入，触发所有高收入税",
        "inputs": {
            "filing_status": "married_filing_jointly",
            "w2_list": [
                {"wages": 600000, "medicare_wages": 750000, "federal_withheld": 180000},
                {"wages": 350000, "medicare_wages": 400000, "federal_withheld": 95000},
            ],
            "form_1099_list": [
                {"form_type": "1099-INT", "amount": 50000},
                {"form_type": "1099-DIV", "amount": 80000, "qualified_dividends": 70000},
                {"form_type": "1099-B", "amount": 100000, "is_short_term": True},
                {"form_type": "1099-B", "amount": 150000, "is_short_term": False},
            ],
            "form_1098_list": [
                {"mortgage_interest": 60000, "property_taxes": 40000},
            ],
        },
    },
    {
        "name": "Scenario 10: Real Estate Professional",
        "description": "配偶是房产经纪，可以全额抵扣 rental loss",
        "inputs": {
            "filing_status": "married_filing_jointly",
            "is_real_estate_professional": True,
            "w2_list": [
                {"wages": 200000, "medicare_wages": 220000, "federal_withheld": 40000},
            ],
            "form_1099_list": [
                {"form_type": "1099-INT", "amount": 5000},
            ],
            "rental_properties": [
                {"address": "Property 1", "net_income": -25000},
                {"address": "Property 2", "net_income": -30000},
                {"address": "Property 3", "net_income": -20000},
            ],
            "form_1098_list": [
                {"mortgage_interest": 18000, "property_taxes": 15000},
            ],
        },
    },
    {
        "name": "Scenario 11: Rental with Depreciation (AMT Adjustment)",
        "description": "出租房有折旧，触发 AMT 折旧调整",
        "inputs": {
            "filing_status": "married_filing_jointly",
            "w2_list": [
                {"wages": 120000, "medicare_wages": 125000, "federal_withheld": 20000},
            ],
            "form_1099_list": [
                {"form_type": "1099-INT", "amount": 3000},
            ],
            "rental_properties": [
                {
                    "address": "123 Rental Ave",
                    "net_income": -5000,  # Loss after depreciation
                    "depreciation": 12000,  # Annual depreciation (MACRS 27.5 yr)
                    "building_cost": 330000,  # Cost basis for building (excl land)
                },
            ],
            "form_1098_list": [
                {"mortgage_interest": 15000, "property_taxes": 8000},
            ],
        },
    },
    {
        "name": "Scenario 12: High Income with Passive Loss (AMT Passive Adjustment)",
        "description": "高收入 + 被动亏损，AMT 完全不允许亏损抵扣",
        "inputs": {
            "filing_status": "married_filing_jointly",
            "w2_list": [
                {"wages": 300000, "medicare_wages": 320000, "federal_withheld": 70000},
                {"wages": 250000, "medicare_wages": 270000, "federal_withheld": 55000},
            ],
            "form_1099_list": [
                {"form_type": "1099-INT", "amount": 10000},
                {"form_type": "1099-DIV", "amount": 20000, "qualified_dividends": 15000},
            ],
            # ISO exercise that increases AMTI
            "iso_exercises": [
                {"bargain_element": 100000},
            ],
            "rental_properties": [
                {"address": "Property 1", "net_income": -15000, "depreciation": 8000, "building_cost": 220000},
            ],
            "form_1098_list": [
                {"mortgage_interest": 40000, "property_taxes": 25000},
            ],
        },
    },
    # ===== BASIC SCENARIOS =====
    {
        "name": "Scenario 1: Senior Engineer Couple",
        "description": "两个 L5 SWE (Meta + Google), 无出租房",
        "expected_total_tax": 72319,  # Will verify against this
        "inputs": {
            "filing_status": "married_filing_jointly",
            "w2_list": [
                {
                    "description": "Meta L5",
                    "wages": 185000,
                    "medicare_wages": 195000,
                    "federal_withheld": 38000,
                },
                {
                    "description": "Google L5",
                    "wages": 175000,
                    "medicare_wages": 185000,
                    "federal_withheld": 35000,
                },
            ],
            "form_1099_list": [
                {"form_type": "1099-INT", "description": "HYSA", "amount": 3500},
                {"form_type": "1099-DIV", "description": "Index Funds", "amount": 9500, "qualified_dividends": 8000},
                {"form_type": "1099-B", "description": "RSU Sales (ST)", "amount": 5000, "is_short_term": True},
                {"form_type": "1099-B", "description": "Stock Sales (LT)", "amount": 25000, "is_short_term": False},
            ],
            "form_1098_list": [
                {"description": "Primary Home", "mortgage_interest": 28000, "property_taxes": 18000},
            ],
        },
    },
    {
        "name": "Scenario 2: Staff Engineer + PM + Rental",
        "description": "Staff + Senior PM, 有一套出租房",
        "expected_total_tax": 107871,
        "inputs": {
            "filing_status": "married_filing_jointly",
            "w2_list": [
                {
                    "description": "Staff Engineer",
                    "wages": 280000,
                    "medicare_wages": 320000,
                    "federal_withheld": 65000,
                },
                {
                    "description": "Senior PM",
                    "wages": 195000,
                    "medicare_wages": 210000,
                    "federal_withheld": 42000,
                },
            ],
            "form_1099_list": [
                {"form_type": "1099-INT", "amount": 8000},
                {"form_type": "1099-DIV", "amount": 18000, "qualified_dividends": 15000},
                {"form_type": "1099-B", "amount": 12000, "is_short_term": True},
                {"form_type": "1099-B", "amount": 45000, "is_short_term": False},
            ],
            "form_1098_list": [
                {"mortgage_interest": 35000, "property_taxes": 22000},
            ],
            "form_5498_list": [
                {"contribution": 8300},  # HSA family max
            ],
            "rental_properties": [
                {
                    "address": "123 Rental St",
                    "gross_rent": 36000,
                    "expenses": 42000,  # Net loss of $6k
                    "net_income": -6000,
                },
            ],
        },
    },
    {
        "name": "Scenario 3: Principal Engineer + Stay-at-Home",
        "description": "高收入单 W-2，配偶在家带娃",
        "expected_total_tax": 110397,
        "inputs": {
            "filing_status": "married_filing_jointly",
            "w2_list": [
                {
                    "description": "Principal Engineer",
                    "wages": 420000,
                    "medicare_wages": 520000,
                    "federal_withheld": 110000,
                },
            ],
            "form_1099_list": [
                {"form_type": "1099-INT", "amount": 15000},
                {"form_type": "1099-DIV", "amount": 43000, "qualified_dividends": 35000},
                {"form_type": "1099-B", "amount": 30000, "is_short_term": True},
                {"form_type": "1099-B", "amount": 80000, "is_short_term": False},
            ],
            "form_1098_list": [
                {"mortgage_interest": 45000, "property_taxes": 28000},
            ],
        },
    },
    {
        "name": "Scenario 4: Dual SWE + Two Rentals",
        "description": "双码农 + 两套出租房",
        "expected_total_tax": 73052,
        "inputs": {
            "filing_status": "married_filing_jointly",
            "w2_list": [
                {
                    "wages": 200000,
                    "medicare_wages": 220000,
                    "federal_withheld": 45000,
                },
                {
                    "wages": 180000,
                    "medicare_wages": 195000,
                    "federal_withheld": 40000,
                },
            ],
            "form_1099_list": [
                {"form_type": "1099-INT", "amount": 5000},
                {"form_type": "1099-DIV", "amount": 14000, "qualified_dividends": 12000},
                {"form_type": "1099-B", "amount": 20000, "is_short_term": False},
            ],
            "form_1098_list": [
                {"mortgage_interest": 32000, "property_taxes": 25000},
            ],
            "rental_properties": [
                {"address": "Property 1", "net_income": -5000},
                {"address": "Property 2", "net_income": -4000},
            ],
        },
    },
]


def run_calculation(scenario_inputs: Dict[str, Any]):
    """Run tax calculation using the standalone calculator."""
    from aitax.tax_calculator import calculate_taxes
    return calculate_taxes(scenario_inputs)


def run_scenario(scenario: Dict[str, Any], verbose: bool = True) -> Dict[str, Any]:
    """Run a single test scenario and return results."""
    name = scenario.get("name", "Unknown")
    description = scenario.get("description", "")
    expected = scenario.get("expected_total_tax")
    
    if verbose:
        print(f"\n{'='*70}")
        print(f"📊 {name}")
        print(f"   {description}")
        print(f"{'='*70}")
    
    # Run calculation using standalone calculator
    calc = run_calculation(scenario["inputs"])
    
    results = {
        "name": name,
        "total_wages": calc.total_wages,
        "total_interest": calc.total_interest,
        "total_dividends": calc.total_dividends,
        "qualified_dividends": calc.qualified_dividends,
        "short_term_gains": calc.short_term_capital_gains,
        "long_term_gains": calc.long_term_capital_gains,
        "total_capital_gains": calc.total_capital_gains,
        "total_rental_income": calc.total_rental_income,
        "total_business_income": calc.total_business_income,
        "total_income": calc.total_income,
        "adjusted_gross_income": calc.adjusted_gross_income,
        "standard_deduction": calc.standard_deduction,
        "itemized_deductions": calc.itemized_deductions,
        "total_deductions": calc.total_deductions,
        "qbi_deduction": calc.qbi_deduction,
        "taxable_income": calc.taxable_income,
        "ordinary_tax": calc.ordinary_tax,
        "capital_gains_tax": calc.capital_gains_tax,
        "additional_medicare_tax": calc.additional_medicare_tax,
        "niit": calc.net_investment_income_tax,
        "self_employment_tax": calc.self_employment_tax,
        "amt_income": calc.amt_income,
        "amt_tax": calc.amt_tax,
        "iso_bargain_element": calc.iso_bargain_element,
        "amt_depreciation_adjustment": calc.amt_depreciation_adjustment,
        "amt_passive_adjustment": calc.amt_passive_adjustment,
        "total_tax": calc.total_tax,
        "total_withholding": calc.total_withholding,
        "refund_or_owe": calc.refund_or_owe,
        "effective_rate": calc.effective_rate,
    }
    
    if verbose:
        print(f"  Total Wages:          ${results['total_wages']:>12,.2f}")
        print(f"  Interest Income:      ${results['total_interest']:>12,.2f}")
        print(f"  Dividend Income:      ${results['total_dividends']:>12,.2f}")
        print(f"    (Qualified):        ${results['qualified_dividends']:>12,.2f}")
        print(f"  Capital Gains (ST):   ${results['short_term_gains']:>12,.2f}")
        print(f"  Capital Gains (LT):   ${results['long_term_gains']:>12,.2f}")
        print(f"  Rental Income:        ${results['total_rental_income']:>12,.2f}")
        print(f"  ───────────────────────────────────────────")
        print(f"  Total Income:         ${results['total_income']:>12,.2f}")
        print(f"  AGI:                  ${results['adjusted_gross_income']:>12,.2f}")
        print(f"  Deductions:           ${results['total_deductions']:>12,.2f}")
        print(f"  QBI Deduction:        ${results['qbi_deduction']:>12,.2f}")
        print(f"  Taxable Income:       ${results['taxable_income']:>12,.2f}")
        print(f"  ───────────────────────────────────────────")
        print(f"  Capital Gains Tax:    ${results['capital_gains_tax']:>12,.2f}")
        print(f"  Additional Medicare:  ${results['additional_medicare_tax']:>12,.2f}")
        print(f"  NIIT:                 ${results['niit']:>12,.2f}")
        if (results.get('iso_bargain_element', 0) > 0 or results.get('amt_tax', 0) > 0 or
            results.get('amt_depreciation_adjustment', 0) > 0 or results.get('amt_passive_adjustment', 0) > 0):
            print(f"  ───────────────────────────────────────────")
            print(f"  AMT Adjustments:")
            if results.get('iso_bargain_element', 0) > 0:
                print(f"    ISO Bargain:        ${results.get('iso_bargain_element', 0):>12,.2f}")
            if results.get('amt_depreciation_adjustment', 0) > 0:
                print(f"    Depreciation Diff:  ${results.get('amt_depreciation_adjustment', 0):>12,.2f}")
            if results.get('amt_passive_adjustment', 0) > 0:
                print(f"    Passive Activity:   ${results.get('amt_passive_adjustment', 0):>12,.2f}")
            print(f"  AMTI:                 ${results.get('amt_income', 0):>12,.2f}")
            print(f"  AMT:                  ${results.get('amt_tax', 0):>12,.2f}")
        print(f"  ───────────────────────────────────────────")
        print(f"  💰 TOTAL TAX:         ${results['total_tax']:>12,.2f}")
        print(f"  📈 Effective Rate:    {results['effective_rate']:>12.2f}%")
        
        if expected:
            diff = results['total_tax'] - expected
            pct_diff = abs(diff) / expected * 100 if expected > 0 else 0
            if abs(diff) < 10:
                print(f"  ✅ Expected: ${expected:,.2f} (diff: ${diff:+,.2f})")
            elif pct_diff < 1:
                print(f"  ⚠️ Expected: ${expected:,.2f} (diff: ${diff:+,.2f}, {pct_diff:.2f}%)")
            else:
                print(f"  ❌ Expected: ${expected:,.2f} (diff: ${diff:+,.2f}, {pct_diff:.2f}%)")
    
    results["expected"] = expected
    results["diff"] = results['total_tax'] - expected if expected else None
    
    return results


def run_all_scenarios(verbose: bool = True) -> List[Dict[str, Any]]:
    """Run all built-in test scenarios."""
    results = []
    passed = 0
    failed = 0
    
    for scenario in SILICON_VALLEY_SCENARIOS:
        result = run_scenario(scenario, verbose=verbose)
        results.append(result)
        
        if result.get("diff") is not None:
            if abs(result["diff"]) < 100:  # Within $100 tolerance
                passed += 1
            else:
                failed += 1
    
    if verbose:
        print(f"\n{'='*70}")
        print(f"📋 Test Summary: {passed} passed, {failed} failed out of {len(results)}")
        print(f"{'='*70}")
    
    return results


def run_from_file(filepath: str, verbose: bool = True) -> Dict[str, Any]:
    """Run a scenario from a JSON file."""
    path = Path(filepath)
    if not path.exists():
        raise FileNotFoundError(f"Scenario file not found: {filepath}")
    
    with open(path) as f:
        scenario = json.load(f)
    
    return run_scenario(scenario, verbose=verbose)


def export_scenarios(output_dir: str = "."):
    """Export built-in scenarios to JSON files."""
    out = Path(output_dir)
    out.mkdir(exist_ok=True)
    
    for i, scenario in enumerate(SILICON_VALLEY_SCENARIOS, 1):
        filename = out / f"scenario_{i}.json"
        with open(filename, 'w') as f:
            json.dump(scenario, f, indent=2)
        print(f"✅ Exported: {filename}")
    
    print(f"\n📁 {len(SILICON_VALLEY_SCENARIOS)} scenarios exported to {out}")


def main(args: List[str]):
    """Main entry point for test runner."""
    if not args:
        print("Usage:")
        print("  taxsnappro test --all              Run all built-in scenarios")
        print("  taxsnappro test scenario.json      Run single scenario from file")
        print("  taxsnappro test --export [dir]     Export built-in scenarios to JSON")
        return 0
    
    if args[0] == "--all":
        run_all_scenarios(verbose=True)
        return 0
    
    if args[0] == "--export":
        output_dir = args[1] if len(args) > 1 else "."
        export_scenarios(output_dir)
        return 0
    
    # Assume it's a file path
    try:
        run_from_file(args[0], verbose=True)
        return 0
    except FileNotFoundError as e:
        print(f"❌ {e}")
        return 1
    except json.JSONDecodeError as e:
        print(f"❌ Invalid JSON: {e}")
        return 1


if __name__ == "__main__":
    import sys
    sys.exit(main(sys.argv[1:]))
