"""TaxSnapPro - AI-powered tax preparation"""

__version__ = "1.8.0"

def __getattr__(name):
    if name == "app":
        from .aitax import app
        return app
    raise AttributeError(name)


__all__ = ["app", "__version__"]
