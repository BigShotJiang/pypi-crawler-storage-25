"""
TaxSnapPro - Centralized Configuration Constants

This module contains all configuration constants used throughout the application.
Centralizes tax constants, API settings, and other configuration to avoid duplication.
"""

# ===== 2024 Tax Constants =====
# Based on IRS 2024 tax year (returns filed in 2025)

TAX_CONSTANTS_2024 = {
    # Standard deduction by filing status
    "standard_deduction": {
        "single": 14600,
        "married_filing_jointly": 29200,
        "married_filing_separately": 14600,
        "head_of_household": 21900,
        "qualifying_widow": 29200,
    },
    
    # Federal income tax brackets (marginal rates)
    # Format: (upper_limit, rate) - last bracket has float('inf') as upper limit
    "brackets": {
        "single": [
            (11600, 0.10),
            (47150, 0.12),
            (100525, 0.22),
            (191950, 0.24),
            (243725, 0.32),
            (609350, 0.35),
            (float("inf"), 0.37),
        ],
        "married_filing_jointly": [
            (23200, 0.10),
            (94300, 0.12),
            (201050, 0.22),
            (383900, 0.24),
            (487450, 0.32),
            (731200, 0.35),
            (float("inf"), 0.37),
        ],
        "married_filing_separately": [
            (11600, 0.10),
            (47150, 0.12),
            (100525, 0.22),
            (191950, 0.24),
            (243725, 0.32),
            (365600, 0.35),
            (float("inf"), 0.37),
        ],
        "head_of_household": [
            (16550, 0.10),
            (63100, 0.12),
            (100500, 0.22),
            (191950, 0.24),
            (243700, 0.32),
            (609350, 0.35),
            (float("inf"), 0.37),
        ],
        "qualifying_widow": [
            (23200, 0.10),
            (94300, 0.12),
            (201050, 0.22),
            (383900, 0.24),
            (487450, 0.32),
            (731200, 0.35),
            (float("inf"), 0.37),
        ],
    },
    
    # Long-term capital gains tax brackets (0%, 15%, 20%)
    "capital_gains_brackets": {
        "single": [
            (47025, 0.0),
            (518900, 0.15),
            (float("inf"), 0.20),
        ],
        "married_filing_jointly": [
            (94050, 0.0),
            (583750, 0.15),
            (float("inf"), 0.20),
        ],
        "married_filing_separately": [
            (47025, 0.0),
            (291850, 0.15),
            (float("inf"), 0.20),
        ],
        "head_of_household": [
            (63000, 0.0),
            (551350, 0.15),
            (float("inf"), 0.20),
        ],
        "qualifying_widow": [
            (94050, 0.0),
            (583750, 0.15),
            (float("inf"), 0.20),
        ],
    },
    
    # Social Security wage base for FICA tax
    "social_security_wage_base": 168600,
    
    # Additional Medicare Tax (0.9%) threshold
    "medicare_additional_threshold": {
        "married_filing_jointly": 250000,
        "qualifying_widow": 250000,
        "single": 200000,
        "head_of_household": 200000,
        "married_filing_separately": 125000,
    },
    
    # Net Investment Income Tax (NIIT) 3.8% threshold
    "niit_threshold": {
        "married_filing_jointly": 250000,
        "qualifying_widow": 250000,
        "single": 200000,
        "head_of_household": 200000,
        "married_filing_separately": 125000,
    },
    
    # ===== Alternative Minimum Tax (AMT) Constants =====
    # Form 6251 - flat structure (not nested)
    
    # AMT exemption amounts
    "amt_exemption": {
        "married_filing_jointly": 133300,
        "qualifying_widow": 133300,
        "single": 85700,
        "head_of_household": 85700,
        "married_filing_separately": 66650,
    },
    
    # AMT exemption phase-out start thresholds
    # Exemption reduces by 25% of AMTI above this threshold
    "amt_phaseout_start": {
        "married_filing_jointly": 1218700,
        "qualifying_widow": 1218700,
        "single": 609350,
        "head_of_household": 609350,
        "married_filing_separately": 609350,
    },
    
    # AMT rate thresholds (26% up to limit, 28% above)
    "amt_26_percent_limit": {
        "married_filing_jointly": 220700,
        "qualifying_widow": 220700,
        "single": 110350,
        "head_of_household": 110350,
        "married_filing_separately": 110350,
    },
}

# ===== 2025 Tax Constants =====
# Based on IRS 2025 tax year (returns filed in 2026)
# Source: Revenue Procedure 2024-40 + OBBBA update

TAX_CONSTANTS_2025 = {
    "standard_deduction": {
        "single": 15750,
        "married_filing_jointly": 31500,
        "married_filing_separately": 15750,
        "head_of_household": 23625,
        "qualifying_widow": 31500,
    },
    "brackets": {
        "single": [
            (11925, 0.10),
            (48475, 0.12),
            (103350, 0.22),
            (197300, 0.24),
            (250525, 0.32),
            (626350, 0.35),
            (float("inf"), 0.37),
        ],
        "married_filing_jointly": [
            (23850, 0.10),
            (96950, 0.12),
            (206700, 0.22),
            (394600, 0.24),
            (501050, 0.32),
            (751600, 0.35),
            (float("inf"), 0.37),
        ],
        "married_filing_separately": [
            (11925, 0.10),
            (48475, 0.12),
            (103350, 0.22),
            (197300, 0.24),
            (250525, 0.32),
            (375800, 0.35),
            (float("inf"), 0.37),
        ],
        "head_of_household": [
            (17000, 0.10),
            (64850, 0.12),
            (103350, 0.22),
            (197300, 0.24),
            (250500, 0.32),
            (626350, 0.35),
            (float("inf"), 0.37),
        ],
        "qualifying_widow": [
            (23850, 0.10),
            (96950, 0.12),
            (206700, 0.22),
            (394600, 0.24),
            (501050, 0.32),
            (751600, 0.35),
            (float("inf"), 0.37),
        ],
    },
    "capital_gains_brackets": {
        "single": [
            (48350, 0.0),
            (533400, 0.15),
            (float("inf"), 0.20),
        ],
        "married_filing_jointly": [
            (96700, 0.0),
            (600050, 0.15),
            (float("inf"), 0.20),
        ],
        "married_filing_separately": [
            (48350, 0.0),
            (300000, 0.15),
            (float("inf"), 0.20),
        ],
        "head_of_household": [
            (64750, 0.0),
            (566700, 0.15),
            (float("inf"), 0.20),
        ],
        "qualifying_widow": [
            (96700, 0.0),
            (600050, 0.15),
            (float("inf"), 0.20),
        ],
    },
    "social_security_wage_base": 176100,
    "medicare_additional_threshold": {
        "married_filing_jointly": 250000,
        "qualifying_widow": 250000,
        "single": 200000,
        "head_of_household": 200000,
        "married_filing_separately": 125000,
    },
    "niit_threshold": {
        "married_filing_jointly": 250000,
        "qualifying_widow": 250000,
        "single": 200000,
        "head_of_household": 200000,
        "married_filing_separately": 125000,
    },
    "amt_exemption": {
        "married_filing_jointly": 137000,
        "qualifying_widow": 137000,
        "single": 88100,
        "head_of_household": 88100,
        "married_filing_separately": 68500,
    },
    "amt_phaseout_start": {
        "married_filing_jointly": 1252700,
        "qualifying_widow": 1252700,
        "single": 626350,
        "head_of_household": 626350,
        "married_filing_separately": 626350,
    },
    "amt_26_percent_limit": {
        "married_filing_jointly": 232600,
        "qualifying_widow": 232600,
        "single": 116300,
        "head_of_household": 116300,
        "married_filing_separately": 116300,
    },
}


def _tc_to_dict(tc) -> dict:
    """Convert a TaxYearConstants dataclass to the UI dict format.
    
    This is the ONLY place tax numbers should be defined — everything
    derives from src/core/tax_constants.py (the single source of truth).
    """
    def _f(d):
        """Decimal -> float."""
        return float(d)
    
    def _brackets(tuples):
        """Convert (upper, rate, base_tax, base_income) to [(upper, rate)]."""
        if not tuples:
            return []
        result = []
        for t in tuples:
            upper = float(t[0]) if t[0] is not None else float("inf")
            rate = float(t[1]) if t[1] is not None else 0.0
            result.append((upper if upper < 999999990 else float("inf"), rate))
        return result
    
    return {
        "standard_deduction": {
            "single": _f(tc.std_deduction_single),
            "married_filing_jointly": _f(tc.std_deduction_mfj),
            "married_filing_separately": _f(tc.std_deduction_mfs),
            "head_of_household": _f(tc.std_deduction_hoh),
            "qualifying_widow": _f(tc.std_deduction_qss),
        },
        "brackets": {
            "single": _brackets(tc.brackets_single),
            "married_filing_jointly": _brackets(tc.brackets_mfj),
            "married_filing_separately": _brackets(tc.brackets_mfs),
            "head_of_household": _brackets(tc.brackets_hoh),
            "qualifying_widow": _brackets(tc.brackets_mfj),  # Same as MFJ
        },
        # LTCG brackets by filing status — all from tax_constants.py (single source)
        "capital_gains_brackets": {
            "married_filing_jointly": _brackets(tc.ltcg_brackets_mfj),
            "single": _brackets(tc.ltcg_brackets_single),
            "married_filing_separately": _brackets(tc.ltcg_brackets_mfs),
            "head_of_household": _brackets(tc.ltcg_brackets_hoh),
            "qualifying_widow": _brackets(tc.ltcg_brackets_mfj),  # Same as MFJ
        },
        "social_security_wage_base": _f(tc.ss_wage_base),
        "medicare_additional_threshold": {
            "married_filing_jointly": _f(tc.medicare_threshold_mfj),
            "qualifying_widow": _f(tc.medicare_threshold_mfj),
            "single": _f(tc.medicare_threshold_other),
            "head_of_household": _f(tc.medicare_threshold_other),
            "married_filing_separately": _f(tc.medicare_threshold_mfs),
        },
        "niit_threshold": {
            "married_filing_jointly": _f(tc.niit_threshold_mfj),
            "qualifying_widow": _f(tc.niit_threshold_mfj),
            "single": _f(tc.niit_threshold_other),
            "head_of_household": _f(tc.niit_threshold_other),
            "married_filing_separately": _f(tc.niit_threshold_mfs),
        },
        "salt_cap": _f(tc.salt_cap),
        "salt_cap_phaseout_start": _f(tc.salt_cap_phaseout_start),
        "salt_cap_phaseout_rate": _f(tc.salt_cap_phaseout_rate),
        # Statutory constants (not inflation-adjusted)
        "additional_medicare_rate": _f(tc.additional_medicare_rate),
        "niit_rate": _f(tc.niit_rate),
        "capital_loss_limit": _f(tc.capital_loss_limit),
        "capital_loss_limit_mfs": _f(tc.capital_loss_limit_mfs),
        "acquisition_debt_limit": _f(tc.acquisition_debt_limit),
        "acquisition_debt_limit_grandfathered": _f(tc.acquisition_debt_limit_grandfathered),
        # AMT values — not yet in TaxYearConstants, using IRS published values
        # TODO: move these to tax_constants.py when AMT computation is added to engine
        "amt_exemption": {
            "married_filing_jointly": 137000 if tc.year >= 2025 else 133300,
            "qualifying_widow": 137000 if tc.year >= 2025 else 133300,
            "single": 88100 if tc.year >= 2025 else 85700,
            "head_of_household": 88100 if tc.year >= 2025 else 85700,
            "married_filing_separately": 68500 if tc.year >= 2025 else 66650,
        },
        "amt_phaseout_start": {
            "married_filing_jointly": 1252700 if tc.year >= 2025 else 1218700,
            "qualifying_widow": 1252700 if tc.year >= 2025 else 1218700,
            "single": 626350 if tc.year >= 2025 else 609350,
            "head_of_household": 626350 if tc.year >= 2025 else 609350,
            "married_filing_separately": 626350 if tc.year >= 2025 else 609350,
        },
        "amt_26_percent_limit": {
            "married_filing_jointly": 232600 if tc.year >= 2025 else 220700,
            "qualifying_widow": 232600 if tc.year >= 2025 else 220700,
            "single": 116300 if tc.year >= 2025 else 110350,
            "head_of_household": 116300 if tc.year >= 2025 else 110350,
            "married_filing_separately": 116300 if tc.year >= 2025 else 110350,
        },
    }


def get_tax_constants(tax_year: int = 2024) -> dict:
    """Get tax constants for the given year.
    
    Uses src/core/tax_constants.py as the single source of truth.
    Falls back to the hardcoded dicts if import fails (e.g. test environments).
    """
    try:
        import sys, os
        src_path = os.path.join(os.path.dirname(__file__), '..', '..', 'src')
        if src_path not in sys.path:
            sys.path.insert(0, os.path.abspath(src_path))
        from core.tax_constants import get_constants
        tc = get_constants(max(2024, min(tax_year, 2025)))
        return _tc_to_dict(tc)
    except (ImportError, ValueError):
        # Fallback to hardcoded dicts if core module unavailable
        if tax_year >= 2025:
            return TAX_CONSTANTS_2025
        return TAX_CONSTANTS_2024


# ===== Tax Credits and Limits =====

# Child Tax Credit per qualifying child (under 17)
CHILD_TAX_CREDIT = 2000

# Credit for Other Dependents (not qualifying for CTC)
DEPENDENT_CREDIT = 500

# Capital loss deduction limit (Schedule D, IRC §1211(b))
# Used by tax_calculator.py — for year-aware computation, use get_tax_constants()
CAPITAL_LOSS_LIMIT = 3000

# State and Local Tax (SALT) deduction cap (TCJA base)
# Used by tax_calculator.py — for year-aware computation, use get_tax_constants()
SALT_CAP = 10000

# ===== Passive Activity Loss Allowance =====
# For rental real estate activities (special $25k allowance)

# Base passive loss allowance
PASSIVE_LOSS_ALLOWANCE = {
    "base": 25000,
    "married_filing_separately": 12500,
}

# Passive loss allowance phase-out thresholds
PASSIVE_LOSS_PHASEOUT = {
    "start": 100000,
    "end": 150000,
    "start_mfs": 50000,  # Married Filing Separately
    "end_mfs": 75000,    # Married Filing Separately
    "reduction_rate": 0.50,  # $0.50 reduction per $1 over start threshold
}

# ===== API Settings =====
# Configuration for document extraction and AI services

# Delay between API requests to avoid rate limiting (seconds)
REQUEST_DELAY_SECONDS = 5.0

# Maximum number of retry attempts for failed API calls
MAX_RETRIES = 5

# Initial retry delay (will use exponential backoff: delay * 2^attempt)
RETRY_DELAY_SECONDS = 10
