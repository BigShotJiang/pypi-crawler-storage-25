#!/usr/bin/env python3
"""
Regression: post-generation summary block in `souleyez report generate`
called rg.collect_data() which doesn't exist on ReportGenerator. Ship
crashed AFTER successfully writing the report file, polluting the
output with a confusing traceback.

This test verifies the public API the CLI calls is actually present.
"""

from souleyez.reporting.generator import ReportGenerator


def test_report_generator_has_data_gathering_method():
    """The CLI's post-generation summary needs a callable method that
    returns the same data structure used to build the report. v3.0.62
    fix uses _gather_report_data; if someone renames it, this test
    will catch it before users see another `AttributeError` post-success."""
    rg = ReportGenerator()
    assert hasattr(rg, "_gather_report_data")
    assert callable(rg._gather_report_data)


def test_report_generator_does_not_have_collect_data():
    """Negative regression: the bad name `collect_data` was the v3.0.61
    crash. If someone re-introduces a method by that name without
    updating the CLI, fine — but flag it so we revisit the CLI call site."""
    rg = ReportGenerator()
    # If this fails (collect_data exists), update the CLI call site
    # in souleyez/main.py:report_generate to use it deliberately.
    assert not hasattr(rg, "collect_data"), (
        "ReportGenerator now has collect_data() — verify CLI summary "
        "block in main.py uses it intentionally"
    )
