#!/usr/bin/env python3
"""
Tests for origin_check plugin and related helpers.

Covers:
- CDN range filtering (utils.cdn_ranges)
- Plugin args parsing
- Hostname extraction
- Response shape comparison
- Plugin handle exposed at module level (loader convention)
"""

from souleyez.plugins.origin_check import (OriginCheckPlugin, _hostname_from_target,
                                           _parse_args, _shapes_match,
                                           _content_signature)
from souleyez.utils.cdn_ranges import filter_cdn_ips, is_cdn_edge

# =============================================================================
# CDN range filter
# =============================================================================


def test_is_cdn_edge_cloudfront():
    is_cdn, provider = is_cdn_edge("18.238.192.94")
    assert is_cdn is True
    assert "CloudFront" in provider


def test_is_cdn_edge_cloudfront_known_range():
    # 3.168.86.4 — one of the IPs from engagement #11 that triggered v3.0.72
    is_cdn, provider = is_cdn_edge("3.168.86.4")
    assert is_cdn is True
    assert "CloudFront" in provider


def test_is_cdn_edge_cloudflare():
    is_cdn, provider = is_cdn_edge("104.16.5.5")
    assert is_cdn is True
    assert provider == "Cloudflare"


def test_is_cdn_edge_non_cdn():
    # AWS EC2 (random origin), not in any tracked CDN range
    is_cdn, provider = is_cdn_edge("54.10.1.2")
    assert is_cdn is False
    assert provider is None


def test_is_cdn_edge_invalid():
    assert is_cdn_edge("not-an-ip") == (False, None)
    assert is_cdn_edge("") == (False, None)
    assert is_cdn_edge(None) == (False, None)


def test_filter_cdn_ips_partitions():
    ips = ["18.238.192.94", "54.10.1.2", "104.16.5.5", "1.2.3.4"]
    non_cdn, filtered = filter_cdn_ips(ips)
    assert "54.10.1.2" in non_cdn
    assert "1.2.3.4" in non_cdn
    assert len(filtered) == 2
    cdn_ips = [ip for ip, _ in filtered]
    assert "18.238.192.94" in cdn_ips
    assert "104.16.5.5" in cdn_ips


# =============================================================================
# Plugin args + hostname parsing
# =============================================================================


def test_parse_args_ips_csv():
    out = _parse_args(["--ips", "1.1.1.1,2.2.2.2,3.3.3.3"])
    assert out["ips"] == ["1.1.1.1", "2.2.2.2", "3.3.3.3"]


def test_parse_args_timeout_and_scheme():
    out = _parse_args(["--timeout", "30", "--scheme", "http"])
    assert out["timeout"] == 30
    assert out["scheme"] == "http"


def test_parse_args_invalid_scheme_falls_back():
    out = _parse_args(["--scheme", "ftp"])
    assert out["scheme"] == "https"  # default kept


def test_parse_args_defaults():
    out = _parse_args([])
    assert out["ips"] == []
    assert out["timeout"] == 10
    assert out["scheme"] == "https"


def test_hostname_from_url():
    assert _hostname_from_target("https://app.freshpaint.io/") == "app.freshpaint.io"
    assert _hostname_from_target("http://API.example.com:8080") == "api.example.com"


def test_hostname_from_bare_host():
    assert _hostname_from_target("api.freshpaint.io") == "api.freshpaint.io"


def test_hostname_from_empty():
    assert _hostname_from_target("") is None
    assert _hostname_from_target(None) is None


# =============================================================================
# Response shape comparator
# =============================================================================


def test_shapes_match_identical_head():
    sig_a = _content_signature(b"hello world" + b"x" * 100)
    sig_b = _content_signature(b"hello world" + b"x" * 100)
    is_match, reason = _shapes_match(sig_a, sig_b)
    assert is_match is True
    assert "identical" in reason


def test_shapes_match_size_within_tolerance():
    # Different head bytes but sizes within 15%
    sig_a = {"size": 1000, "head_sha256": "aaaa"}
    sig_b = {"size": 950, "head_sha256": "bbbb"}
    is_match, reason = _shapes_match(sig_a, sig_b)
    assert is_match is True
    assert "size within" in reason


def test_shapes_match_size_diverges():
    sig_a = {"size": 1000, "head_sha256": "aaaa"}
    sig_b = {"size": 200, "head_sha256": "bbbb"}
    is_match, _ = _shapes_match(sig_a, sig_b)
    assert is_match is False


def test_shapes_match_missing_signature():
    is_match, _ = _shapes_match({}, {"size": 100, "head_sha256": "x"})
    assert is_match is False


# =============================================================================
# Plugin loader convention
# =============================================================================


def test_plugin_module_handle_is_lowercase_instance():
    """
    The plugin loader scans for `mod.plugin` (lowercase, instance), not
    `Plugin` (uppercase, class). Same regression we hit on s3_check;
    asserting it here so origin_check doesn't repeat it.
    """
    from souleyez.plugins import origin_check as mod

    assert hasattr(mod, "plugin")
    assert isinstance(mod.plugin, OriginCheckPlugin)


def test_plugin_metadata():
    from souleyez.plugins import origin_check as mod

    assert mod.plugin.tool == "origin_check"
    assert mod.plugin.category == "reconnaissance"
