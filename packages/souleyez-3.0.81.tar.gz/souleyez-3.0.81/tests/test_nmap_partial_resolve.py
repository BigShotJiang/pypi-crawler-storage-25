#!/usr/bin/env python3
"""
Tests for nmap handler status when one or more multi-target hostnames
fail to resolve.

Background: scanning a list of 10 hostnames where 9 resolve cleanly
and 1 doesn't ('Failed to resolve' line in nmap output) used to mark
the entire job as ERROR. That suppressed every downstream chain
(http_fingerprint, gobuster, nuclei, etc.) for the 9 hosts that were
scanned successfully — same anti-pattern as the v3.0.66 nuclei and
v3.0.67 katana false-error regressions.

Findings-first: if any host came up, the scan was successful for
those hosts; partial-resolve is a warning, not a fatal error.
WARNING status is chainable, so chains fire as expected.
"""

from souleyez.engine.job_status import (CHAINABLE_STATUSES, STATUS_DONE,
                                        STATUS_ERROR, STATUS_NO_RESULTS,
                                        STATUS_WARNING, is_chainable)


def test_warning_status_is_chainable():
    """
    Locks in the design contract: WARNING must trigger auto-chain so
    that nmap partial-resolve scans still fan out to http_fingerprint
    et al.
    """
    assert STATUS_WARNING in CHAINABLE_STATUSES
    assert is_chainable(STATUS_WARNING) is True


def test_error_status_is_not_chainable():
    """ERROR remains the hard kill-switch for chaining."""
    assert STATUS_ERROR not in CHAINABLE_STATUSES
    assert is_chainable(STATUS_ERROR) is False


def test_done_and_no_results_chainable():
    """Sanity: existing status semantics unchanged."""
    assert is_chainable(STATUS_DONE) is True
    assert is_chainable(STATUS_NO_RESULTS) is True


# ---------------------------------------------------------------------------
# nmap handler status decision (the fix)
# ---------------------------------------------------------------------------


def _decide_status(hosts_up: int, nmap_error):
    """
    Mirrors the v3.0.75 logic in NmapHandler.parse_job. Lifted into a
    helper so we can unit-test the decision without spinning up the
    full handler + log file plumbing.
    """
    if hosts_up > 0:
        return STATUS_WARNING if nmap_error else STATUS_DONE
    if nmap_error:
        return STATUS_ERROR
    return STATUS_NO_RESULTS


def test_partial_resolve_with_findings_is_warning():
    """
    The exact engagement #11 scenario: 9 of 10 multi-target hostnames
    resolved and got scanned, 1 ('staging.freshpaint-proxy.com') didn't
    exist in DNS, nmap printed 'Failed to resolve ...', exit code 0,
    real findings stored. Status must be WARNING (chainable), not
    ERROR (suppresses chains).
    """
    assert _decide_status(hosts_up=9, nmap_error="failed to resolve") == STATUS_WARNING
    assert is_chainable(_decide_status(9, "failed to resolve")) is True


def test_total_resolve_failure_is_error():
    """
    Inverse case: zero hosts came up AND error pattern detected ->
    real failure, no chains.
    """
    assert _decide_status(hosts_up=0, nmap_error="failed to resolve") == STATUS_ERROR
    assert is_chainable(_decide_status(0, "failed to resolve")) is False


def test_clean_scan_is_done():
    """No errors and hosts up — vanilla success."""
    assert _decide_status(hosts_up=5, nmap_error=None) == STATUS_DONE


def test_no_hosts_no_error_is_no_results():
    """All hosts down or filtered, no error pattern — no_results."""
    assert _decide_status(hosts_up=0, nmap_error=None) == STATUS_NO_RESULTS
