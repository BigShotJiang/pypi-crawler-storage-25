#!/usr/bin/env python3
"""
Tests for v3.0.76: nmap chain dispatch should preserve canonical
hostnames instead of replacing them with the resolved IP, and should
dedup multi-port web hosts to a single chain per logical URL.

Background: when scanning hostnames behind a CDN (e.g.,
api.freshpaint-staging.com -> CloudFront edge IPs), nmap captures
both the hostname and the resolved IP. Earlier code constructed
chain targets like https://18.155.202.87 (the edge IP), which hits
CloudFront with no Host: header and dead-ends — every downstream
chain (http_fingerprint, nuclei, gobuster, nikto, ffuf, origin_check)
landed on a CDN default response instead of the real backend.

Two related fixes covered here:
1. URL-format chain targets prefer canonical hostname over IP.
2. Multi-port hosts (80 + 443) dedup on normalized URL so we don't
   queue two identical chain jobs for the same logical target.
"""

from souleyez.utils.hostname_quality import is_generic_hostname

# ---------------------------------------------------------------------------
# IP -> hostname mapping derived from parse_results["hosts"]
# ---------------------------------------------------------------------------


def _build_ip_to_hostname(hosts):
    """
    Mirrors the v3.0.76 logic in auto_chain. Skip hostname when it's
    empty, equal to the IP, or matches the generic-PTR allowlist
    (CDN edge names that won't help us route).
    """
    out = {}
    for h in hosts:
        ip = (h.get("ip") or "").strip()
        hn = (h.get("hostname") or "").strip()
        if ip and hn and not is_generic_hostname(hn) and ip != hn:
            out[ip] = hn
    return out


def test_ip_to_hostname_keeps_canonical():
    hosts = [
        {"ip": "18.155.202.87", "hostname": "api.freshpaint-staging.com"},
        {"ip": "13.249.74.33", "hostname": "app.freshpaint-staging.com"},
    ]
    out = _build_ip_to_hostname(hosts)
    assert out["18.155.202.87"] == "api.freshpaint-staging.com"
    assert out["13.249.74.33"] == "app.freshpaint-staging.com"


def test_ip_to_hostname_drops_cdn_ptr():
    """
    CloudFront PTR resolved on the same IP should not be used as a
    chain target — defeats the purpose of preserving hostnames.
    """
    hosts = [
        {
            "ip": "108.139.10.17",
            "hostname": "server-108-139-10-17.sfo5.r.cloudfront.net",
        },
    ]
    out = _build_ip_to_hostname(hosts)
    assert "108.139.10.17" not in out


def test_ip_to_hostname_drops_ip_as_hostname():
    """
    When the parser fell back to using the IP as hostname, treat as
    empty for chain-target purposes.
    """
    hosts = [{"ip": "100.22.35.129", "hostname": "100.22.35.129"}]
    out = _build_ip_to_hostname(hosts)
    assert out == {}


def test_ip_to_hostname_handles_missing_fields():
    hosts = [
        {"ip": "1.1.1.1"},  # no hostname
        {"hostname": "orphan.example.com"},  # no ip
        {"ip": "", "hostname": ""},
        None,  # bad entry shouldn't crash
    ]
    # None entries would crash _build_ip_to_hostname — emulate the
    # production guard which filters falsy entries first
    safe_hosts = [h for h in hosts if isinstance(h, dict)]
    out = _build_ip_to_hostname(safe_hosts)
    assert out == {}


# ---------------------------------------------------------------------------
# URL-format chain target prefers hostname over IP
# ---------------------------------------------------------------------------


def _resolve_url_host(ip, ip_to_hostname):
    """
    Mirrors the v3.0.76 url_host computation in _expand_web_commands.
    Hostname when known, IP as fallback.
    """
    return ip_to_hostname.get(ip) or ip


def test_url_host_prefers_hostname_when_known():
    mapping = {"18.155.202.87": "api.freshpaint-staging.com"}
    assert (
        _resolve_url_host("18.155.202.87", mapping) == "api.freshpaint-staging.com"
    )


def test_url_host_falls_back_to_ip():
    """
    No hostname known (CDN edge IP w/o canonical mapping) -> use IP.
    Chain still fires, just doesn't get the Host: header benefit.
    """
    assert _resolve_url_host("8.8.8.8", {}) == "8.8.8.8"


# ---------------------------------------------------------------------------
# Per-URL dedup for multi-port web hosts
# ---------------------------------------------------------------------------


def _dedup_urls(urls):
    """
    Mirrors the seen_urls dedup in _expand_web_commands. Same
    normalization as v3.0.72 chain-side dedup: rstrip slash, lowercase.
    """
    seen = set()
    kept = []
    for u in urls:
        normalized = u.rstrip("/").lower()
        if normalized in seen:
            continue
        seen.add(normalized)
        kept.append(u)
    return kept


def test_dedup_collapses_trailing_slash_and_case():
    urls = [
        "https://api.freshpaint-staging.com",
        "https://api.freshpaint-staging.com/",
        "HTTPS://API.FRESHPAINT-STAGING.COM",
    ]
    assert _dedup_urls(urls) == ["https://api.freshpaint-staging.com"]


def test_dedup_keeps_distinct_ports():
    urls = [
        "https://api.freshpaint-staging.com",
        "https://api.freshpaint-staging.com:8443",
        "http://api.freshpaint-staging.com",
    ]
    # All three are distinct logical targets, kept
    assert _dedup_urls(urls) == urls


def test_dedup_blocks_repeat_per_service_emission():
    """
    Engagement #11 scenario: a host with both port 80 and 443
    detected used to queue TWO http_fingerprint chains pointing at
    the same https://hostname (after URL upgrade). v3.0.76 dedup
    keeps one.
    """
    urls = [
        "http://api.freshpaint-staging.com",
        "https://api.freshpaint-staging.com",
        # Hypothetical second-pass duplicate from another code path
        "https://api.freshpaint-staging.com",
        "https://api.freshpaint-staging.com/",
    ]
    out = _dedup_urls(urls)
    assert out == [
        "http://api.freshpaint-staging.com",
        "https://api.freshpaint-staging.com",
    ]


# ---------------------------------------------------------------------------
# Composed end-to-end: hostname + dedup together
# ---------------------------------------------------------------------------


def test_engagement_11_scenario_end_to_end():
    """
    Replays the exact engagement #11 staging scan input and asserts
    the v3.0.76 output: one chain per host, hostname-targeted, no
    duplicates.
    """
    hosts = [
        {"ip": "18.155.202.87", "hostname": "api.freshpaint-staging.com"},
        {"ip": "13.249.74.33", "hostname": "app.freshpaint-staging.com"},
        {"ip": "65.8.180.18", "hostname": "freshpaint-cdn-staging.com"},
        # CDN PTR — should NOT be used as chain hostname
        {
            "ip": "108.139.10.17",
            "hostname": "server-108-139-10-17.sfo5.r.cloudfront.net",
        },
    ]
    mapping = _build_ip_to_hostname(hosts)

    # Each host has port 80 and 443 detected, so the per-port loop
    # emits both http://X and https://X. Dedup runs over the result.
    candidate_urls = []
    for h in hosts:
        ip = h["ip"]
        host = _resolve_url_host(ip, mapping)
        candidate_urls.append(f"http://{host}")
        candidate_urls.append(f"https://{host}")

    kept = _dedup_urls(candidate_urls)

    # 4 hosts × 2 schemes = 8 candidates, all distinct after
    # deduplication (different host strings). The CDN-PTR host falls
    # back to its IP since the hostname was rejected as generic.
    assert len(kept) == 8
    assert "http://api.freshpaint-staging.com" in kept
    assert "https://api.freshpaint-staging.com" in kept
    assert "https://freshpaint-cdn-staging.com" in kept
    # The CDN-PTR host targets the IP (no canonical hostname known)
    assert "https://108.139.10.17" in kept
    assert "https://server-108-139-10-17.sfo5.r.cloudfront.net" not in kept
