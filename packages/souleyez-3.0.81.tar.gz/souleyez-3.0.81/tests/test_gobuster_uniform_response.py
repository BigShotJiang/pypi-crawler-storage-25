#!/usr/bin/env python3
"""
Tests for v3.0.79: gobuster handler uniform-response false-positive
guard.

Background: CloudFront and similar edge servers return an identical
response for every unknown path. Gobuster reports each path as a hit
(non-404 status code) and the handler's path-name regex tags each
.bak/.zip/.old/.env as a high-severity finding — even though the
response is just a CDN default page, not an actual backup file.

Engagement #11 staging scan: gobuster on
freshpaint-impression-staging.com produced 4900 false-positive
"Backup/archive file" findings, all with identical status+size
signatures from the CloudFront default response.

Same false-positive class as ffuf v3.0.51 fix and http_fingerprint
v3.0.72 fix. Threshold: >=90% of paths share dominant signature.
"""

from souleyez.handlers.gobuster_handler import GobusterHandler


# ---------------------------------------------------------------------------
# Signature detection
# ---------------------------------------------------------------------------


def test_uniform_response_detected_at_90_percent():
    """All 10 paths return identical (403, 1234) — clear uniform-response."""
    paths = [
        {"path": p, "status_code": 403, "size": 1234}
        for p in [".bak", ".zip", ".old", ".env", "config.php",
                  "backup", "admin/", ".git", ".htaccess", "wp-admin"]
    ]
    sig = GobusterHandler._uniform_response_signature(paths)
    # 1234 // 1024 = 1 (v3.0.81 bucketed signature)
    assert sig == (403, 1)


def test_uniform_response_detected_with_one_outlier():
    """
    9 of 10 share a signature, 1 is a real find. >=90% threshold met
    by the noise; the outlier is a true discovery worth keeping as
    a finding.
    """
    paths = [
        {"path": p, "status_code": 403, "size": 1234}
        for p in [".bak", ".zip", ".old", ".env", "config.php",
                  "backup", ".git", ".htaccess", "wp-admin"]
    ]
    paths.append({"path": "real-app", "status_code": 200, "size": 4567})
    sig = GobusterHandler._uniform_response_signature(paths)
    # 1234 // 1024 = 1 (v3.0.81 bucketed signature)
    assert sig == (403, 1)


def test_no_uniform_response_when_responses_vary():
    """
    Genuine app responses vary by path — different sizes and codes.
    Filter must NOT fire (would silently drop real findings).
    """
    paths = [
        {"path": "admin", "status_code": 200, "size": 4500},
        {"path": "config.php", "status_code": 403, "size": 250},
        {"path": "robots.txt", "status_code": 200, "size": 89},
        {"path": "api/v1", "status_code": 401, "size": 32},
        {"path": "login", "status_code": 200, "size": 8400},
        {"path": "static/", "status_code": 301, "size": 0},
    ]
    sig = GobusterHandler._uniform_response_signature(paths)
    assert sig is None


def test_too_few_paths_for_detection():
    """
    With <5 paths we can't tell uniform-response from coincidence.
    Don't fire the filter on small result sets.
    """
    paths = [
        {"path": "a.bak", "status_code": 403, "size": 1234},
        {"path": "b.bak", "status_code": 403, "size": 1234},
        {"path": "c.bak", "status_code": 403, "size": 1234},
    ]
    sig = GobusterHandler._uniform_response_signature(paths)
    assert sig is None


def test_below_90_percent_does_not_fire():
    """
    8 of 10 share a signature (80%). Below threshold → no filtering.
    Some false positives slip through but we don't risk dropping
    real findings on hosts with mixed but not uniform behavior.
    """
    paths = [
        {"path": p, "status_code": 403, "size": 1234}
        for p in [".bak", ".zip", ".old", ".env", "a", "b", "c", "d"]
    ]
    paths.append({"path": "real1", "status_code": 200, "size": 5000})
    paths.append({"path": "real2", "status_code": 200, "size": 6000})
    sig = GobusterHandler._uniform_response_signature(paths)
    assert sig is None


def test_empty_paths_returns_none():
    assert GobusterHandler._uniform_response_signature([]) is None


# ---------------------------------------------------------------------------
# Finding creation respects the filter
# ---------------------------------------------------------------------------


class _RecordingFindingsManager:
    def __init__(self):
        self.added = []

    def add_finding(self, **kwargs):
        self.added.append(kwargs)


def test_engagement_11_scenario_drops_all_uniform_response_findings():
    """
    Replays engagement #11: 100 paths from a CloudFront-fronted host,
    all returning (403, 1234). v3.0.78 (and earlier) created 100
    findings; v3.0.79 creates zero.
    """
    handler = GobusterHandler()
    fm = _RecordingFindingsManager()

    # 100 wordlist hits all returning identical CDN default response
    paths = [
        {
            "path": f"/file{i}.bak",
            "url": f"https://impression-staging.example.com/file{i}.bak",
            "status_code": 403,
            "size": 1234,
        }
        for i in range(100)
    ]
    handler._create_findings_for_sensitive_paths(
        engagement_id=99, host_id=1, paths=paths, findings_manager=fm
    )
    assert fm.added == [], "Uniform-response filter must drop all"


def test_real_finding_among_uniform_responses_is_kept():
    """
    9 paths return CDN default (403, 1234); 1 path (a real backup
    file at /db-backup.zip) returns (200, 8MB) — that one stands
    out and SHOULD become a finding.
    """
    handler = GobusterHandler()
    fm = _RecordingFindingsManager()

    paths = [
        {
            "path": f"/{p}",
            "url": f"https://x.example.com/{p}",
            "status_code": 403,
            "size": 1234,
        }
        for p in ["a.bak", "b.bak", "c.bak", "d.zip", "e.old",
                  "f.bak", "g.bak", "h.zip", "i.old"]
    ]
    paths.append(
        {
            "path": "/db-backup.zip",
            "url": "https://x.example.com/db-backup.zip",
            "status_code": 200,
            "size": 8_000_000,
        }
    )
    handler._create_findings_for_sensitive_paths(
        engagement_id=99, host_id=1, paths=paths, findings_manager=fm
    )
    # Filter dropped the 9 uniform 403s; the (200, 8MB) outlier survives.
    assert len(fm.added) == 1
    assert "db-backup.zip" in fm.added[0]["title"]


def test_varied_responses_all_findings_kept():
    """
    No uniform-response signature → filter doesn't fire → every
    sensitive-path match becomes a finding (existing behavior, no
    regression).
    """
    handler = GobusterHandler()
    fm = _RecordingFindingsManager()

    paths = [
        {
            "path": "/admin.bak",
            "url": "https://x.example.com/admin.bak",
            "status_code": 200,
            "size": 4500,
        },
        {
            "path": "/.env",
            "url": "https://x.example.com/.env",
            "status_code": 200,
            "size": 250,
        },
        {
            "path": "/config.php",
            "url": "https://x.example.com/config.php",
            "status_code": 403,
            "size": 100,
        },
        {
            "path": "/db.zip",
            "url": "https://x.example.com/db.zip",
            "status_code": 200,
            "size": 999_000,
        },
        {
            "path": "/robots.txt",
            "url": "https://x.example.com/robots.txt",
            "status_code": 200,
            "size": 80,
        },
    ]
    handler._create_findings_for_sensitive_paths(
        engagement_id=99, host_id=1, paths=paths, findings_manager=fm
    )
    # admin.bak / .env / config.php / db.zip all match patterns; robots.txt
    # may or may not. Just assert >=2 findings to confirm filter didn't fire.
    assert len(fm.added) >= 2


# ---------------------------------------------------------------------------
# v3.0.81 size-bucket tolerance: real engagement #11 distribution
# ---------------------------------------------------------------------------


def test_engagement_11_real_distribution_clustered():
    """
    Real distribution from engagement #11
    freshpaint-impression-staging.com: 17180 paths at 255 bytes,
    11183 at 263, 9064 at 275 — all CloudFront 403 defaults that
    vary slightly per request.

    v3.0.79/v3.0.80 used exact-match — never fired (largest exact
    cluster = 46%). v3.0.81 first attempt at 64-byte buckets still
    didn't cluster (largest bucket = 54%). v3.0.81 final at 1024-byte
    buckets puts all three sizes in bucket 0 → 100% match → filter
    fires. This is the test that proves the chosen bucket size
    handles real CDN data.
    """
    paths = []
    paths.extend([{"path": f"/a{i}", "status_code": 403, "size": 255}
                  for i in range(17180)])
    paths.extend([{"path": f"/b{i}", "status_code": 403, "size": 263}
                  for i in range(11183)])
    paths.extend([{"path": f"/c{i}", "status_code": 403, "size": 275}
                  for i in range(9064)])

    sig = GobusterHandler._uniform_response_signature(paths)
    # 255, 263, 275 all // 1024 = 0. All cluster into bucket 0.
    assert sig == (403, 0)


def test_1024byte_bucket_clusters_sub_kilobyte_responses():
    """
    Any path with size < 1024 lands in bucket 0 — the typical CDN
    default range.
    """
    paths = [
        {"path": f"/a{i}", "status_code": 403, "size": 200 + i * 5}
        for i in range(50)
    ]
    # Sizes 200..445, all in bucket 0
    sig = GobusterHandler._uniform_response_signature(paths)
    assert sig == (403, 0)


def test_bucket_separates_cdn_default_from_real_page():
    """
    A 256-byte CDN default vs a 5KB real page must land in different
    buckets so the real one survives the filter.
    """
    cdn = {"path": "/cdn", "status_code": 200, "size": 256}
    real = {"path": "/real", "status_code": 200, "size": 5000}
    sig_cdn = GobusterHandler._signature_for_path(cdn)
    sig_real = GobusterHandler._signature_for_path(real)
    # 256//1024 = 0, 5000//1024 = 4
    assert sig_cdn[1] == 0
    assert sig_real[1] == 4
    assert sig_cdn != sig_real
