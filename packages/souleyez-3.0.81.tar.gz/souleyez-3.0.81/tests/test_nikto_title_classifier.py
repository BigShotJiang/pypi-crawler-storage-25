#!/usr/bin/env python3
"""
Tests for the Nikto finding-title classifier.

Replaces the old "Nikto: <path> - <truncated raw line>..." format with
human-readable classified titles. Each test case is a real Nikto
description string that previously produced an unreadable title.
"""

from souleyez.parsers.nikto_parser import classify_finding_title

# =============================================================================
# Missing security headers
# =============================================================================


def test_missing_x_content_type_options():
    desc = (
        "The X-Content-Type-Options header is not set. This could allow the "
        "user agent to render the content of the site in a different fashion "
        "to the MIME type."
    )
    assert (
        classify_finding_title(desc, path="/")
        == "Missing X-Content-Type-Options header"
    )


def test_missing_x_frame_options():
    desc = "The anti-clickjacking X-Frame-Options header is not present."
    assert classify_finding_title(desc) == "Missing X-Frame-Options header"


def test_missing_hsts():
    desc = "The site uses HTTPS but the Strict-Transport-Security header is not set."
    assert (
        classify_finding_title(desc)
        == "Missing Strict-Transport-Security (HSTS) header"
    )


def test_missing_csp():
    desc = "The Content-Security-Policy header is not set, increasing XSS risk."
    assert classify_finding_title(desc) == "Missing Content-Security-Policy header"


# =============================================================================
# Information disclosure
# =============================================================================


def test_via_header_disclosure():
    desc = (
        "Retrieved via header: 1.1 773f6821b053a13ecc63d604feb07cb4."
        "cloudfront.net (CloudFront)."
    )
    title = classify_finding_title(desc, path="/")
    assert "Information disclosure" in title
    assert "Via" in title


def test_uncommon_header_disclosure():
    desc = (
        "Uncommon header 'reporting-endpoints' found, with contents: "
        'csp-endpoint="https://o334625.ingest.us.sentry.io/..."'
    )
    title = classify_finding_title(desc, path="/")
    assert "Information disclosure" in title
    assert "reporting-endpoints" in title


def test_etag_inode_leak():
    desc = "Server may leak inodes via ETags, header found with file /, fields: 0x..."
    assert classify_finding_title(desc) == "Information disclosure: ETag inode leak"


# =============================================================================
# Insecure cookies
# =============================================================================


def test_insecure_cookie_missing_secure_flag():
    desc = "Cookie session_id created without the secure flag, value: ..."
    title = classify_finding_title(desc)
    assert "Insecure cookie" in title
    assert "Secure" in title or "secure" in title


def test_insecure_cookie_missing_httponly():
    desc = "Cookie auth_token created without the HttpOnly flag."
    title = classify_finding_title(desc)
    assert "Insecure cookie" in title
    assert "HttpOnly" in title


# =============================================================================
# Directory listing
# =============================================================================


def test_directory_listing_at_path():
    desc = "Directory indexing found."
    title = classify_finding_title(desc, path="/backup/")
    assert title == "Directory listing enabled at /backup/"


def test_directory_listing_default_path():
    desc = "Directory indexing found."
    title = classify_finding_title(desc, path="/")
    assert title == "Directory listing enabled"


# =============================================================================
# Robots.txt
# =============================================================================


def test_robots_txt_with_entry_count():
    desc = "robots.txt contains 14 entries which should be manually viewed."
    title = classify_finding_title(desc)
    assert "robots.txt" in title.lower()
    assert "14" in title


# =============================================================================
# Risky HTTP methods
# =============================================================================


def test_options_method_exposed():
    desc = "OPTIONS method is enabled, allowing methods: GET POST PUT DELETE."
    title = classify_finding_title(desc)
    assert "OPTIONS" in title or "method" in title.lower()


# =============================================================================
# Title regression: the v3.0.60 bad shape never reappears
# =============================================================================


def test_title_does_not_start_with_nikto_path_dash():
    """Regression: titles must NOT have the format
    'Nikto: <path> - <truncated description>...' that v3.0.60 produced."""
    descriptions = [
        "Retrieved via header: 1.1 cloudfront.net",
        "Uncommon header 'reporting-endpoints' found",
        "The X-Content-Type-Options header is not set",
        "Some unrecognized random nikto output",
    ]
    for desc in descriptions:
        title = classify_finding_title(desc, path="/")
        assert not title.startswith(
            "Nikto: /"
        ), f"title regressed to old format: {title!r}"
        assert "..." not in title or title.endswith(
            "..."
        ), f"title has truncation marker mid-title: {title!r}"


def test_unrecognized_finding_falls_back_to_clean_first_clause():
    """Unrecognized findings should produce a clean title from the first
    sentence/clause, not the raw nikto line dumped verbatim."""
    desc = "Some unusual nikto observation that doesn't match any known pattern."
    title = classify_finding_title(desc, path="/")
    # Should not contain path-prefix junk
    assert not title.startswith("Nikto: /")
    # Should be reasonable length
    assert len(title) < 100


def test_osvdb_reference_preserved_for_searchability():
    desc = "Some uncategorized finding."
    title = classify_finding_title(desc, path="/", osvdb="OSVDB-3268")
    assert "OSVDB-3268" in title


# =============================================================================
# Backfill helper: reclassify_existing_finding_titles
# =============================================================================


def test_reclassify_only_touches_old_format_titles(monkeypatch):
    """Backfill helper should only update findings whose titles look
    like the old 'Nikto: <path> - ...' dump format, leaving any titles
    that were already classified (or hand-edited) alone."""
    from unittest.mock import MagicMock

    from souleyez.parsers import nikto_parser

    fake_findings = [
        {
            "id": 1,
            "title": "Nikto: / - The X-Content-Type-Options header is not se...",
            "description": "The X-Content-Type-Options header is not set.",
            "path": "/",
        },
        {
            "id": 2,
            "title": "Missing X-Frame-Options header",  # already clean
            "description": "X-Frame-Options header is not present.",
            "path": "/",
        },
        {
            "id": 3,
            "title": "Nikto Finding: Some uncommon header...",
            "description": "Uncommon header 'reporting-endpoints' found",
            "path": "/",
        },
    ]
    fake_fm = MagicMock()
    fake_fm.list_findings.return_value = fake_findings

    # FindingsManager is imported lazily inside the function. Patch the
    # symbol on its source module so the lazy import resolves to our mock.
    import souleyez.storage.findings as findings_module

    monkeypatch.setattr(findings_module, "FindingsManager", lambda *a, **kw: fake_fm)

    result = nikto_parser.reclassify_existing_finding_titles(engagement_id=1)

    # Two updates (the two Nikto:-prefixed ones), one skip (the clean one)
    assert result["updated"] == 2
    assert result["skipped"] == 1
    assert result.get("deleted", 0) == 0
    update_calls = fake_fm.update_finding.call_args_list
    assert len(update_calls) == 2
    # Verify the new titles are the classified versions
    update_titles = [call.kwargs.get("title") for call in update_calls]
    assert "Missing X-Content-Type-Options header" in update_titles
    assert any(
        "reporting-endpoints" in t and "Information disclosure" in t
        for t in update_titles
    )


# =============================================================================
# v3.0.63 fixes: parser skips, classifier fallback, bogus-finding cleanup
# =============================================================================


def test_parser_skips_end_of_scan_stats_line():
    """Regression: nikto end-of-scan stats line was parsed as a finding,
    producing titles like '0 error(s) and 1 item(s) reported on remote
    host'. Not a finding."""
    from souleyez.parsers.nikto_parser import _parse_finding_line

    line = "+ 26662 requests: 0 error(s) and 1 item(s) reported on remote host"
    assert _parse_finding_line(line) is None


def test_parser_skips_cgi_discovery_warning():
    """Regression: nikto's 'All CGI directories found' warning was being
    stored as a finding. It's a CDN-detection diagnostic, not a vuln."""
    from souleyez.parsers.nikto_parser import _parse_finding_line

    line = "+ All CGI directories 'found', use '-C none' to test none"
    assert _parse_finding_line(line) is None


def test_classifier_fallback_does_not_grab_appended_server_value():
    """Regression: handler appends '\\n\\nServer: <name>' to descriptions
    before storing. Classifier fallback used split(':', 1)[-1] which
    grabbed everything after the FIRST colon (= 'cloudflare') as the
    title. Should use the first sentence of the first line, ignoring
    the appended Server: line."""
    desc = (
        "All CGI directories 'found', use '-C none' to test none\n"
        "\n"
        "Server: cloudflare"
    )
    title = classify_finding_title(desc, path="/")
    assert title != "cloudflare", f"classifier still grabs Server: value: {title!r}"
    assert "CGI" in title or "cgi" in title.lower()


def test_classifier_fallback_strips_appended_path_line():
    """Same regression class — handler appends '\\nPath: /' too. Title
    should not include the path artifact."""
    desc = "Some unrecognized nikto observation\n" "\n" "Server: nginx\n" "Path: /admin"
    title = classify_finding_title(desc, path="/admin")
    assert "Path:" not in title
    assert "Server:" not in title


def test_is_bogus_nikto_finding_detects_stats_line():
    from souleyez.parsers.nikto_parser import _is_bogus_nikto_finding

    assert _is_bogus_nikto_finding(
        "26662 requests: 0 error(s) and 1 item(s) reported on remote host"
    )
    assert _is_bogus_nikto_finding(
        "0 error(s) and 3 item(s) reported on remote host\n\nServer: CloudFront"
    )
    # Real findings don't match
    assert not _is_bogus_nikto_finding("The X-Content-Type-Options header is not set.")
    assert not _is_bogus_nikto_finding("")


def test_is_bogus_nikto_finding_detects_cgi_warning():
    from souleyez.parsers.nikto_parser import _is_bogus_nikto_finding

    assert _is_bogus_nikto_finding(
        "All CGI directories 'found', use '-C none' to test none\n\nServer: cloudflare"
    )


def test_classifier_root_page_redirect():
    """Real engagement description: 'Root page / redirects to: https://...'.
    Classifier had been producing titles like 'https://52' (truncating at
    first colon)."""
    desc = (
        "Root page / redirects to: https://52.89.252.97:443/\n\n" "Server: awselb/2.0"
    )
    title = classify_finding_title(desc)
    assert title.startswith("Root page redirects to")
    assert "https://52.89.252.97:443/" in title


def test_classifier_multiple_ips():
    """Real engagement description: 'Multiple IPs found: 65.8.54.77, ...'.
    Classifier had been producing titles like '65' (first IP digit)."""
    desc = (
        "Multiple IPs found: 65.8.54.77, 65.8.54.11, 65.8.54.115\n\n"
        "Server: CloudFront"
    )
    title = classify_finding_title(desc)
    assert "Multiple IPs" in title
    assert "DNS" in title or "load balancer" in title.lower()


def test_classifier_cors_wildcard():
    """Real engagement description: 'Retrieved access-control-allow-origin
    header: *'. Classifier had been producing title '*'."""
    desc = "Retrieved access-control-allow-origin header: *.\n\nServer: None"
    title = classify_finding_title(desc)
    assert "CORS" in title
    assert "*" in title


def test_classifier_server_banner_changed():
    desc = ": Server banner changed from 'None' to 'CloudFront'.\n\nServer: None"
    title = classify_finding_title(desc)
    assert "Server banner" in title


# =============================================================================
# v3.0.65: per-classified-title remediation
# =============================================================================


def test_remediation_for_missing_x_content_type_options():
    from souleyez.parsers.nikto_parser import classify_finding_remediation

    rem = classify_finding_remediation("Missing X-Content-Type-Options header")
    assert rem  # non-empty
    assert "nosniff" in rem
    # Must include actionable server-config syntax for at least one server
    assert "Nginx" in rem or "Apache" in rem
    # Should not be the generic boilerplate
    assert "regular maintenance windows" not in rem.lower()


def test_remediation_for_missing_csp():
    from souleyez.parsers.nikto_parser import classify_finding_remediation

    rem = classify_finding_remediation("Missing Content-Security-Policy header")
    assert "report-only" in rem.lower() or "Content-Security-Policy-Report-Only" in rem
    assert "default-src" in rem.lower()


def test_remediation_for_cors_wildcard():
    from souleyez.parsers.nikto_parser import classify_finding_remediation

    rem = classify_finding_remediation(
        "CORS wildcard: Access-Control-Allow-Origin set to '*'"
    )
    assert rem
    assert "allowlist" in rem.lower() or "explicit" in rem.lower()
    # The "never combine ACAO:* with credentials" rule is critical and must be there
    assert "Access-Control-Allow-Credentials" in rem


def test_remediation_for_insecure_cookie_secure():
    from souleyez.parsers.nikto_parser import classify_finding_remediation

    rem = classify_finding_remediation(
        "Insecure cookie: 'session_id' missing Secure flag"
    )
    assert rem
    assert "Secure" in rem
    assert "HTTPS" in rem


def test_remediation_for_insecure_cookie_httponly():
    from souleyez.parsers.nikto_parser import classify_finding_remediation

    rem = classify_finding_remediation(
        "Insecure cookie: 'auth_token' missing HttpOnly flag"
    )
    assert rem
    assert "HttpOnly" in rem
    assert "XSS" in rem or "JavaScript" in rem


def test_remediation_for_directory_listing():
    from souleyez.parsers.nikto_parser import classify_finding_remediation

    rem = classify_finding_remediation("Directory listing enabled at /backup/")
    assert rem
    assert "Indexes" in rem or "autoindex" in rem


def test_remediation_for_informational_categories_explicit_no_action():
    """Informational findings (multiple IPs, server banner change, root
    redirect) should still produce a remediation paragraph that
    explicitly says 'no action needed' rather than generic filler.
    Auditors then know the report author considered it."""
    from souleyez.parsers.nikto_parser import classify_finding_remediation

    for title in (
        "Multiple IPs returned for hostname (DNS round-robin / load balancer)",
        "Server banner changed during scan",
        "Root page redirects to https://example.com/",
    ):
        rem = classify_finding_remediation(title)
        assert rem, f"informational title {title!r} got empty remediation"
        assert "informational" in rem.lower()


def test_remediation_for_csp_unsafe_inline_script():
    from souleyez.parsers.nikto_parser import classify_finding_remediation

    rem = classify_finding_remediation("CSP allows 'unsafe-inline' in script-src")
    assert rem
    assert "nonce" in rem.lower()
    assert "report-only" in rem.lower() or "Report-Only" in rem


def test_remediation_for_csp_unsafe_eval():
    from souleyez.parsers.nikto_parser import classify_finding_remediation

    rem = classify_finding_remediation("CSP allows 'unsafe-eval' in script-src")
    assert rem
    assert "eval()" in rem
    assert "JSON.parse" in rem


def test_remediation_for_csp_unsafe_inline_style():
    from souleyez.parsers.nikto_parser import classify_finding_remediation

    rem = classify_finding_remediation("CSP allows 'unsafe-inline' in style-src")
    assert rem
    assert "external" in rem.lower() or "nonces" in rem.lower()


def test_remediation_for_csp_bare_wildcard():
    from souleyez.parsers.nikto_parser import classify_finding_remediation

    rem = classify_finding_remediation("CSP uses bare wildcard (*) in img-src")
    assert rem
    assert "allowlist" in rem.lower() or "explicit" in rem.lower()


def test_remediation_for_s3_listable_with_objects():
    from souleyez.parsers.nikto_parser import classify_finding_remediation

    rem = classify_finding_remediation(
        "Public S3 bucket listable with 42 object(s): my-bucket"
    )
    assert rem
    # Critical incident language
    assert "Block public access" in rem or "Block Public Access" in rem
    assert "incident" in rem.lower() or "leaked" in rem.lower()


def test_remediation_for_s3_listable_empty():
    from souleyez.parsers.nikto_parser import classify_finding_remediation

    rem = classify_finding_remediation("Public S3 bucket listable (empty): my-bucket")
    assert rem
    assert "Block Public Access" in rem or "block public access" in rem.lower()


def test_remediation_for_s3_public_not_listable():
    from souleyez.parsers.nikto_parser import classify_finding_remediation

    rem = classify_finding_remediation(
        "Public S3 bucket (read, not listable): my-bucket"
    )
    assert rem
    assert "signed URLs" in rem or "Origin Access Identity" in rem


def test_remediation_for_slowloris_cve():
    from souleyez.parsers.nikto_parser import classify_finding_remediation

    rem = classify_finding_remediation("CVE-2007-6750 - Slowloris DOS attack")
    assert rem
    assert "mod_reqtimeout" in rem
    assert "Apache" in rem


def test_remediation_for_unencrypted_http_service():
    from souleyez.parsers.nikto_parser import classify_finding_remediation

    rem = classify_finding_remediation("Unencrypted HTTP Service")
    assert rem
    assert "HTTPS" in rem
    assert "HSTS" in rem or "301" in rem


def test_no_remediation_entry_starts_with_redundant_header():
    """v3.0.70 regression: every classifier remediation entry must NOT
    embed its own '**Remediation:**' header. The formatter already wraps
    the remediation block with a `<strong>Remediation:</strong>` label;
    if entries also start with their own, the rendered output shows two
    stacked 'Remediation:' headers per finding."""
    from souleyez.parsers.nikto_parser import _CLASSIFIED_REMEDIATIONS

    for predicate, remediation_text in _CLASSIFIED_REMEDIATIONS:
        assert "**Remediation:**" not in remediation_text, (
            f"remediation entry contains a redundant '**Remediation:**' "
            f"header — formatter already provides one. Entry starts: "
            f"{remediation_text[:80]!r}"
        )
        # Also catch the variant without the bold markers
        first_line = remediation_text.split("\n", 1)[0]
        assert not first_line.lower().startswith("remediation:"), (
            f"remediation entry's first line starts with 'Remediation:' — "
            f"formatter already provides that header. Entry starts: "
            f"{first_line!r}"
        )


def test_remediation_returns_empty_for_unknown_title():
    """Unknown titles should return empty string so callers can fall
    back to existing generic logic."""
    from souleyez.parsers.nikto_parser import classify_finding_remediation

    assert classify_finding_remediation("Some completely unknown finding") == ""
    assert classify_finding_remediation("") == ""


def test_remediation_generic_filler_no_longer_used_for_classified_findings(monkeypatch):
    """End-to-end: the formatter's _generate_default_remediation must
    return the SPECIFIC remediation for classified findings, not the
    generic per-severity bullets."""
    from souleyez.reporting.formatters import HTMLFormatter

    fmt = HTMLFormatter()
    finding = {
        "title": "Missing X-Content-Type-Options header",
        "severity": "low",
        "tool": "nikto",
    }
    rem = fmt._generate_default_remediation(finding, "low")
    # Old generic Low-severity filler:
    assert "regular maintenance windows" not in rem.lower()
    # New specific guidance:
    assert "nosniff" in rem


def test_reclassify_self_heals_across_classifier_versions(monkeypatch):
    """v3.0.64 backfill: re-title ANY finding whose current title doesn't
    match the latest classifier output, regardless of whether the title
    looks like the old 'Nikto: /' format. Self-healing across upgrades."""
    from unittest.mock import MagicMock

    from souleyez.parsers import nikto_parser

    fake_findings = [
        # Bad title from earlier classifier (v3.0.61 split-on-colon bug)
        {
            "id": 200,
            "title": "https://52",
            "description": "Root page / redirects to: https://52.89.252.97:443/",
            "path": "/",
        },
        # Bad title from same bug
        {
            "id": 201,
            "title": "65",
            "description": "Multiple IPs found: 65.8.54.77, 65.8.54.11",
            "path": "/",
        },
        # Already correctly classified — must NOT be re-titled
        {
            "id": 202,
            "title": "Missing X-Frame-Options header",
            "description": "X-Frame-Options header is not present.",
            "path": "/",
        },
    ]
    fake_fm = MagicMock()
    fake_fm.list_findings.return_value = fake_findings

    import souleyez.storage.findings as findings_module

    monkeypatch.setattr(findings_module, "FindingsManager", lambda *a, **kw: fake_fm)

    result = nikto_parser.reclassify_existing_finding_titles(engagement_id=1)
    assert result["updated"] == 2
    assert result["skipped"] == 1
    update_titles = [
        c.kwargs.get("title") for c in fake_fm.update_finding.call_args_list
    ]
    assert any("Root page redirects to" in t for t in update_titles)
    assert any("Multiple IPs" in t for t in update_titles)


def test_reclassify_deletes_bogus_findings(monkeypatch):
    """Backfill helper should DELETE findings that were never real
    findings — re-classifying stats lines just produces confusing
    titles like 'cloudflare'."""
    from unittest.mock import MagicMock

    from souleyez.parsers import nikto_parser

    fake_findings = [
        {
            "id": 100,
            "title": "cloudflare",
            "description": (
                "All CGI directories 'found', use '-C none' to test none"
                "\n\nServer: cloudflare"
            ),
            "path": "/",
        },
        {
            "id": 101,
            "title": "0 error(s) and 1 item(s) reported on remote host",
            "description": (
                "26662 requests: 0 error(s) and 1 item(s) reported on remote host"
                "\n\nServer: cloudflare"
            ),
            "path": "/",
        },
        {
            "id": 102,
            "title": "Nikto: / - The X-Content-Type-Options header is not se...",
            "description": "The X-Content-Type-Options header is not set.",
            "path": "/",
        },
    ]
    fake_fm = MagicMock()
    fake_fm.list_findings.return_value = fake_findings

    import souleyez.storage.findings as findings_module

    monkeypatch.setattr(findings_module, "FindingsManager", lambda *a, **kw: fake_fm)

    result = nikto_parser.reclassify_existing_finding_titles(engagement_id=1)

    # 2 deletes (the bogus ones), 1 update (the real Nikto: title)
    assert result["deleted"] == 2
    assert result["updated"] == 1
    delete_ids = [c.args[0] for c in fake_fm.delete_finding.call_args_list]
    assert 100 in delete_ids
    assert 101 in delete_ids
    # The real finding was retitled, not deleted
    assert 102 not in delete_ids
    update_call = fake_fm.update_finding.call_args
    assert update_call.kwargs.get("title") == "Missing X-Content-Type-Options header"
