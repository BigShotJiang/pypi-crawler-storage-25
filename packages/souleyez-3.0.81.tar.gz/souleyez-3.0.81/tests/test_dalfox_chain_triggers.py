#!/usr/bin/env python3
"""
Tests for v3.0.78: dalfox chain triggers fire when their parent tools
actually find something.

Background: four dalfox chain rules (off gobuster, ffuf, nikto, wpscan)
were defined with trigger_condition='has:results'. The has:<key>
condition evaluator does bool(context.get(<key>)). None of those four
parent tools ever produces a context["results"] key — gobuster sets
paths_found, ffuf sets results_found, nikto sets findings_count,
wpscan sets findings_added. The condition was unmatchable. Fix:
each rule now uses the field its parent actually populates.
"""

from souleyez.core.tool_chaining import ChainRule, ToolChaining


def _find_rule(tool: str, target: str) -> ChainRule:
    """Return the dalfox chain rule for a given parent tool."""
    chaining = ToolChaining()
    for r in chaining.rules:
        if r.trigger_tool == tool and r.target_tool == target:
            return r
    raise AssertionError(
        f"No chain rule found: {tool} -> {target}"
    )


# ---------------------------------------------------------------------------
# Rule conditions match the fields each parent tool actually produces
# ---------------------------------------------------------------------------


def test_gobuster_dalfox_uses_paths_found():
    rule = _find_rule("gobuster", "dalfox")
    assert rule.trigger_condition == "has:paths_found", (
        "v3.0.78 fix: gobuster's count field is paths_found, not results"
    )


def test_ffuf_dalfox_uses_results_found():
    rule = _find_rule("ffuf", "dalfox")
    assert rule.trigger_condition == "has:results_found"


def test_nikto_dalfox_uses_findings_count():
    rule = _find_rule("nikto", "dalfox")
    assert rule.trigger_condition == "has:findings_count"


def test_wpscan_dalfox_uses_findings_added():
    rule = _find_rule("wpscan", "dalfox")
    assert rule.trigger_condition == "has:findings_added"


# ---------------------------------------------------------------------------
# matches() actually fires for each tool's real output shape
# ---------------------------------------------------------------------------


def _ctx_with(**overrides):
    """Minimal chain context. The has:<key> evaluator does
    bool(context.get(<key>)), so non-zero/non-empty values trigger."""
    base = {
        "target": "https://example.com",
        "tool": "test",
        "services": [],
        "findings": [],
    }
    base.update(overrides)
    return base


def test_gobuster_dalfox_fires_on_paths_found_count():
    rule = _find_rule("gobuster", "dalfox")
    assert rule.matches(_ctx_with(paths_found=5)) is True
    assert rule.matches(_ctx_with(paths_found=0)) is False
    assert rule.matches(_ctx_with()) is False


def test_ffuf_dalfox_fires_on_results_found_count():
    rule = _find_rule("ffuf", "dalfox")
    assert rule.matches(_ctx_with(results_found=12)) is True
    assert rule.matches(_ctx_with(results_found=0)) is False


def test_nikto_dalfox_fires_on_findings_count():
    """
    Engagement #11 scenario: nikto found vulns on 5 hosts, none
    triggered dalfox. After v3.0.78 they will.
    """
    rule = _find_rule("nikto", "dalfox")
    assert rule.matches(_ctx_with(findings_count=3)) is True
    assert rule.matches(_ctx_with(findings_count=0)) is False
    assert rule.matches(_ctx_with()) is False


def test_wpscan_dalfox_fires_on_findings_added_count():
    rule = _find_rule("wpscan", "dalfox")
    assert rule.matches(_ctx_with(findings_added=1)) is True
    assert rule.matches(_ctx_with(findings_added=0)) is False


# ---------------------------------------------------------------------------
# Regression guard: the OLD has:results condition would never match
# ---------------------------------------------------------------------------


def test_old_has_results_would_never_match():
    """
    Locks in the bug semantics so we don't accidentally roll back to
    has:results. None of the four parent tools sets context['results'],
    so a rule with that condition is silently dead.
    """
    fake_rule = ChainRule(
        trigger_tool="nikto",
        trigger_condition="has:results",
        target_tool="dalfox",
        priority=6,
        args_template=[],
    )
    # Even with realistic nikto output, the broken condition fails
    assert (
        fake_rule.matches(_ctx_with(findings_count=3, findings_added=3))
        is False
    )
