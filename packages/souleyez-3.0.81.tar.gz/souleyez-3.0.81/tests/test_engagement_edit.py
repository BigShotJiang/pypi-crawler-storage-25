#!/usr/bin/env python3
"""
Tests for the engagement edit flow (v3.0.59).

Covers the `souleyez engagement edit` CLI command and verifies that
EngagementManager.update correctly persists the audit-evidence metadata
fields added in v3.0.58.
"""

from unittest.mock import MagicMock, patch

from click.testing import CliRunner


def test_cli_non_interactive_updates_only_provided_fields():
    """`engagement edit -e ID --tester-name X` should update only
    tester_name and leave other fields untouched."""
    from souleyez.main import engagement_edit

    runner = CliRunner()
    fake_em = MagicMock()
    fake_em.get_by_id.return_value = {
        "id": 1,
        "name": "Test Engagement",
        "tester_name": "Old Name",
        "tester_role": "Old Role",
        "scope_summary": "Old scope",
        "methodology_summary": "Old methodology",
    }
    with patch("souleyez.main.EngagementManager", return_value=fake_em):
        result = runner.invoke(
            engagement_edit,
            ["-e", "1", "--tester-name", "New Name"],
        )
    assert result.exit_code == 0, result.output
    fake_em.update.assert_called_once()
    eng_id, updates = fake_em.update.call_args[0]
    assert eng_id == 1
    assert updates == {"tester_name": "New Name"}


def test_cli_non_interactive_can_set_multiple_fields():
    from souleyez.main import engagement_edit

    runner = CliRunner()
    fake_em = MagicMock()
    fake_em.get_by_id.return_value = {
        "id": 7,
        "name": "X",
        "tester_name": None,
        "tester_role": None,
        "scope_summary": None,
        "methodology_summary": None,
    }
    with patch("souleyez.main.EngagementManager", return_value=fake_em):
        result = runner.invoke(
            engagement_edit,
            [
                "-e",
                "7",
                "--tester-name",
                "y0d8",
                "--tester-role",
                "SecOps Lead",
                "--scope-summary",
                "Web app + cloud infra",
                "--methodology-summary",
                "Automated + targeted",
            ],
        )
    assert result.exit_code == 0
    updates = fake_em.update.call_args[0][1]
    assert updates == {
        "tester_name": "y0d8",
        "tester_role": "SecOps Lead",
        "scope_summary": "Web app + cloud infra",
        "methodology_summary": "Automated + targeted",
    }


def test_cli_falls_back_to_current_engagement():
    from souleyez.main import engagement_edit

    runner = CliRunner()
    fake_em = MagicMock()
    fake_em.get_current.return_value = {
        "id": 42,
        "name": "Current Eng",
        "tester_name": None,
        "tester_role": None,
        "scope_summary": None,
        "methodology_summary": None,
    }
    with patch("souleyez.main.EngagementManager", return_value=fake_em):
        result = runner.invoke(engagement_edit, ["--tester-name", "Z"])
    assert result.exit_code == 0
    assert fake_em.update.call_args[0][0] == 42


def test_cli_errors_when_engagement_not_found():
    from souleyez.main import engagement_edit

    runner = CliRunner()
    fake_em = MagicMock()
    fake_em.get_by_id.return_value = None
    with patch("souleyez.main.EngagementManager", return_value=fake_em):
        result = runner.invoke(engagement_edit, ["-e", "999", "--tester-name", "X"])
    assert "not found" in result.output.lower()
    fake_em.update.assert_not_called()


def test_cli_errors_when_no_current_engagement():
    from souleyez.main import engagement_edit

    runner = CliRunner()
    fake_em = MagicMock()
    fake_em.get_current.return_value = None
    with patch("souleyez.main.EngagementManager", return_value=fake_em):
        result = runner.invoke(engagement_edit, ["--tester-name", "X"])
    assert "no current engagement" in result.output.lower()
    fake_em.update.assert_not_called()


def test_cli_no_changes_does_not_call_update():
    """Running with no flags AND skipping every interactive prompt
    should result in zero updates, not an empty-dict update."""
    from souleyez.main import engagement_edit

    runner = CliRunner()
    fake_em = MagicMock()
    fake_em.get_by_id.return_value = {
        "id": 1,
        "name": "X",
        "tester_name": "existing",
        "tester_role": "existing",
        "scope_summary": "existing",
        "methodology_summary": "existing",
    }
    with patch("souleyez.main.EngagementManager", return_value=fake_em):
        # 4 empty prompt responses
        result = runner.invoke(engagement_edit, ["-e", "1"], input="\n\n\n\n")
    assert "no changes" in result.output.lower()
    fake_em.update.assert_not_called()


def test_cli_interactive_updates_only_changed_fields():
    """In interactive mode, fields where the user typed something get
    updated; fields where they pressed Enter (empty) do not."""
    from souleyez.main import engagement_edit

    runner = CliRunner()
    fake_em = MagicMock()
    fake_em.get_by_id.return_value = {
        "id": 5,
        "name": "X",
        "tester_name": "old",
        "tester_role": "old",
        "scope_summary": "old",
        "methodology_summary": "old",
    }
    # Provide values for tester_name and scope_summary; skip the others
    user_input = "Alex\n\nNew scope wording\n\n"
    with patch("souleyez.main.EngagementManager", return_value=fake_em):
        result = runner.invoke(engagement_edit, ["-e", "5"], input=user_input)
    assert result.exit_code == 0
    updates = fake_em.update.call_args[0][1]
    assert updates == {
        "tester_name": "Alex",
        "scope_summary": "New scope wording",
    }


def test_engagement_manager_update_persists_audit_fields(tmp_path, monkeypatch):
    """End-to-end: real EngagementManager + real DB. Confirms the v3.0.58
    schema migration stuck and update() round-trips the new fields."""
    # Use a temp DB location to avoid touching the real one
    db_path = tmp_path / "test.db"
    monkeypatch.setattr(
        "souleyez.config.get",
        lambda key, default=None: (str(db_path) if key == "database.path" else default),
    )
    # Force re-init of the global db with the new path
    from souleyez.storage import database as db_module

    monkeypatch.setattr(db_module, "_db_instance", None, raising=False)

    from souleyez.storage.engagements import EngagementManager

    em = EngagementManager()
    eng_id = em.create("Test EE", "desc")
    em.update(
        eng_id,
        {
            "tester_name": "Alex",
            "tester_role": "SecOps",
            "scope_summary": "All the things",
            "methodology_summary": "Various tools",
        },
    )
    eng = em.get_by_id(eng_id)
    assert eng["tester_name"] == "Alex"
    assert eng["tester_role"] == "SecOps"
    assert eng["scope_summary"] == "All the things"
    assert eng["methodology_summary"] == "Various tools"
