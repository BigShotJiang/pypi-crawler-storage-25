#!/usr/bin/env python3
"""
Tests for the uniform-response false-positive guard in the HTTP
fingerprint plugin's API endpoint discovery.

Background: CloudFront, AWS API Gateway, and similar edge servers
return an identical response (same status + Content-Length) for
every unknown path. Without filtering, every host fronted by such
a server appears to expose 5+ "real" API endpoints, each one
triggering a downstream ffuf scan against a fake target. Same root
cause as the v3.0.51 ffuf uniform-response fix.
"""

from unittest.mock import patch

from souleyez.plugins.http_fingerprint import HttpFingerprintPlugin

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


class _MockHeaders:
    def __init__(self, content_length=""):
        self._cl = content_length

    def get(self, key, default=""):
        if key.lower() == "content-length":
            return self._cl
        return default


class _MockResponse:
    def __init__(self, status, content_length=""):
        self._status = status
        self.headers = _MockHeaders(content_length)

    def getcode(self):
        return self._status

    def __enter__(self):
        return self

    def __exit__(self, *_):
        return False

    def read(self, *_):
        return b""


def _make_urlopen(status_by_path, length_by_path=None):
    """
    Build a fake urlopen that returns a controlled (status, length)
    per path so we can simulate uniform-response edges.
    """
    length_by_path = length_by_path or {}

    def _fake_urlopen(req, **_kwargs):
        url = req.full_url if hasattr(req, "full_url") else str(req)
        path = "/" + url.split("/", 3)[-1] if "://" in url else url
        # Match longest registered path first so /api/v1/ wins over /api/
        match = None
        for p in sorted(status_by_path.keys(), key=len, reverse=True):
            if path.startswith(p):
                match = p
                break
        status = status_by_path.get(match, 404)
        length = length_by_path.get(match, "0")
        if status >= 400:
            import urllib.error

            err = urllib.error.HTTPError(url, status, "err", _MockHeaders(length), None)
            raise err
        return _MockResponse(status, length)

    return _fake_urlopen


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


def test_uniform_response_drops_unconfirmed_api_endpoints():
    """
    When 50%+ of probed API paths return identical (status, length),
    every unconfirmed endpoint with that signature is dropped.
    """
    plugin = HttpFingerprintPlugin()

    # Every API path returns 403 with length 162 (CloudFront default).
    status_map = {
        "/api/": 403,
        "/api/v1/": 403,
        "/api/v2/": 403,
        "/graphql": 403,
        "/swagger.json": 403,
        "/swagger/": 403,
        "/openapi.json": 403,
        "/api-docs/": 403,
        "/v1/": 403,
        "/rest/": 403,
        # Admin paths return 404 so they don't bias results.
        "/admin/": 404,
        "/wp-admin/": 404,
    }
    length_map = {p: "162" for p in status_map}

    with patch(
        "urllib.request.urlopen",
        side_effect=_make_urlopen(status_map, length_map),
    ):
        result = plugin._quick_path_probe("https://cloudfront.example.com")

    assert result.get("uniform_response_filter_applied") is True
    assert result.get("uniform_response_dropped", 0) >= 3
    # All unconfirmed API endpoints with the dominant signature
    # should be filtered out.
    assert result["api_endpoints"] == []


def test_uniform_response_keeps_confirmed_endpoints():
    """
    Confirmed endpoints (deep-probe verified) are always kept even
    when a uniform-response signature is detected.
    """
    plugin = HttpFingerprintPlugin()

    # We can't easily fake a deep-probe via urlopen alone, so build the
    # post-pass scenario directly by constructing a result and re-running
    # just the filter logic. Use a public helper: invoke the probe with
    # an injected confirmed entry by patching the api_endpoints list
    # before the post-pass runs.
    fake_endpoints = [
        {
            "path": "/api/",
            "status": 403,
            "content_length": "162",
            "url": "https://x/api/",
            "confirmed": False,
            "details": None,
            "type": "api",
        },
        {
            "path": "/api/v1/",
            "status": 403,
            "content_length": "162",
            "url": "https://x/api/v1/",
            "confirmed": False,
            "details": None,
            "type": "api",
        },
        {
            "path": "/api/v2/",
            "status": 403,
            "content_length": "162",
            "url": "https://x/api/v2/",
            "confirmed": False,
            "details": None,
            "type": "api",
        },
        {
            "path": "/graphql",
            "status": 200,
            "content_length": "512",
            "url": "https://x/graphql",
            "confirmed": True,
            "details": {"introspection_enabled": True},
            "type": "api",
        },
    ]

    # Re-run the same post-pass logic the plugin uses.
    from collections import Counter

    api_endpoints = list(fake_endpoints)
    sig_counts = Counter((ep["status"], ep["content_length"]) for ep in api_endpoints)
    most_common_sig, count = sig_counts.most_common(1)[0]
    kept = []
    dropped = 0
    for ep in api_endpoints:
        sig = (ep["status"], ep["content_length"])
        if ep["confirmed"]:
            kept.append(ep)
        elif sig == most_common_sig:
            dropped += 1
        else:
            kept.append(ep)

    assert dropped == 3
    assert len(kept) == 1
    assert kept[0]["path"] == "/graphql"
    assert kept[0]["confirmed"] is True


def test_no_filter_when_responses_vary():
    """
    Genuine APIs return different status/length per path. The filter
    must NOT fire — we'd be silently dropping real endpoints.
    """
    plugin = HttpFingerprintPlugin()

    # Each path returns a distinct response — no uniform signature.
    status_map = {
        "/api/": 200,
        "/api/v1/": 200,
        "/graphql": 200,
        "/swagger.json": 200,
        "/swagger/": 301,
        "/openapi.json": 404,
        "/api-docs/": 404,
        "/v1/": 404,
        "/rest/": 404,
        "/api/v2/": 404,
        "/admin/": 404,
        "/wp-admin/": 404,
    }
    length_map = {
        "/api/": "120",
        "/api/v1/": "350",
        "/graphql": "1024",
        "/swagger.json": "8000",
        "/swagger/": "0",
    }

    with patch(
        "urllib.request.urlopen",
        side_effect=_make_urlopen(status_map, length_map),
    ):
        result = plugin._quick_path_probe("https://realapi.example.com")

    assert result.get("uniform_response_filter_applied") is not True
    # Expect to see the genuinely-discovered endpoints retained.
    paths = {ep["path"] for ep in result.get("api_endpoints", [])}
    assert "/api/" in paths
    assert "/graphql" in paths


def test_graphql_trailing_slash_not_probed():
    """
    The /graphql/ trailing-slash variant was redundant on every web
    server we tested and queued duplicate downstream nuclei scans.
    Confirm only canonical /graphql is in the indicator list.
    """
    # Read the source rather than running the probe — the indicator
    # list is a local literal inside _quick_path_probe.
    import inspect

    src = inspect.getsource(HttpFingerprintPlugin._quick_path_probe)
    assert '("/graphql"' in src
    assert '("/graphql/"' not in src
