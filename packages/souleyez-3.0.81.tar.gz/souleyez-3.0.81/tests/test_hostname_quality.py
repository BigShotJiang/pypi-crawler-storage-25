#!/usr/bin/env python3
"""
Tests for hostname quality classification.

Background: nmap and other tools do reverse-DNS by default and store
the resulting PTR as the host's hostname. When the IP is a CDN edge
(CloudFront, Cloudflare, Fastly), the PTR overwrites the real
application hostname captured earlier — silently breaking the
IP→hostname mapping. is_better_hostname blocks that downgrade.
"""

import pytest

from souleyez.utils.hostname_quality import is_better_hostname, is_generic_hostname

# =============================================================================
# Generic-PTR detection
# =============================================================================


@pytest.mark.parametrize(
    "hostname",
    [
        # CloudFront — exact PTRs from engagement #11 that triggered the fix
        "server-108-139-10-25.sfo5.r.cloudfront.net",
        "server-18-238-192-94.sfo53.r.cloudfront.net",
        "server-3-168-86-29.sfo5.r.cloudfront.net",
        "d2a3b4c.cloudfront.net",
        # AWS EC2 / compute generic PTRs
        "ec2-54-10-1-2.us-west-2.compute.amazonaws.com",
        "ec2-3-101-22-5.us-east-1.compute.amazonaws.com",
        "ip-10-1-2-3.us-west-2.compute.internal",
        # Cloudflare edges
        "104.16.5.5.cloudflare.com",
        "edge-01.cloudflare.com",
        # Fastly
        "edge-fra-01.fastly.net",
        # Akamai
        "a1.akamaitechnologies.com",
        "edge.akamaiedge.net",
        # Google / Azure
        "1.2.3.4.bc.googleusercontent.com",
        "myapp.eastus.cloudapp.azure.com",
    ],
)
def test_generic_hostname_detected(hostname):
    assert is_generic_hostname(hostname), f"Expected generic: {hostname}"


@pytest.mark.parametrize(
    "hostname",
    [
        "app.freshpaint.io",
        "api.freshpaint.io",
        "auth.freshpaint.io",
        "www.example.com",
        "vagrant-2008r2",  # legitimate Windows hostname from nmap service info
        "internal-app-01.corp.example.com",
        "github.com",
        "",  # empty is not generic
    ],
)
def test_canonical_hostname_not_flagged_generic(hostname):
    assert not is_generic_hostname(hostname), f"Should not be generic: {hostname}"


def test_generic_hostname_handles_none():
    assert is_generic_hostname(None) is False


# =============================================================================
# Upgrade decision
# =============================================================================


def test_better_hostname_fills_empty_slot():
    assert is_better_hostname("anything.example.com", "") is True
    assert is_better_hostname("anything.example.com", None) is True


def test_better_hostname_same_value_is_noop():
    assert is_better_hostname("app.freshpaint.io", "app.freshpaint.io") is False


def test_better_hostname_blocks_canonical_to_generic_downgrade():
    """
    The v3.0.74 fix: don't let a CloudFront PTR overwrite a real app
    hostname. This is the exact scenario from engagement #11.
    """
    assert (
        is_better_hostname(
            "server-108-139-10-25.sfo5.r.cloudfront.net",
            "app.freshpaint.io",
        )
        is False
    )
    assert (
        is_better_hostname(
            "ec2-54-10-1-2.us-west-2.compute.amazonaws.com",
            "api.freshpaint.io",
        )
        is False
    )


def test_better_hostname_allows_generic_to_canonical_upgrade():
    """
    If we accidentally captured a generic PTR first (e.g., scan started
    from the IP), we should let a later real hostname overwrite it.
    """
    assert (
        is_better_hostname(
            "app.freshpaint.io",
            "server-108-139-10-25.sfo5.r.cloudfront.net",
        )
        is True
    )


def test_better_hostname_does_not_churn_canonical_to_canonical():
    """
    Two real hostnames for the same IP — keep what we have, don't churn
    on every chain step.
    """
    assert (
        is_better_hostname("api.freshpaint.io", "app.freshpaint.io") is False
    )


def test_better_hostname_blocks_generic_to_generic():
    """
    Don't churn between two generic PTRs either — first one wins.
    """
    assert (
        is_better_hostname(
            "server-18-238-192-94.sfo53.r.cloudfront.net",
            "server-108-139-10-25.sfo5.r.cloudfront.net",
        )
        is False
    )


def test_better_hostname_empty_new_value():
    """An empty new value is never an upgrade."""
    assert is_better_hostname("", "app.freshpaint.io") is False
    assert is_better_hostname(None, "app.freshpaint.io") is False


# =============================================================================
# Integration test against the actual storage layer
# =============================================================================


@pytest.fixture
def storage_engagement(isolated_db, monkeypatch):
    """
    Self-contained fixture: spin up an isolated DB, create an engagement
    via raw insert, and return its id. Avoids the conftest.test_engagement
    fixture which imports a missing create_engagement symbol.
    """
    import souleyez.storage.database as db_module

    monkeypatch.setattr(db_module, "_db", isolated_db)
    eng_id = isolated_db.insert(
        "engagements",
        {"name": "test-eng", "description": "hostname quality test"},
    )
    return eng_id


def test_storage_blocks_cdn_ptr_overwrite(storage_engagement):
    """
    End-to-end check: after capturing app.freshpaint.io as the hostname
    for an IP, a second add_or_update_host call carrying the CloudFront
    PTR for that IP must NOT overwrite the canonical hostname.
    """
    from souleyez.storage.hosts import HostManager

    eng_id = storage_engagement
    hm = HostManager()

    # First scan: user-supplied hostname captured correctly
    hm.add_or_update_host(
        eng_id,
        {
            "ip": "108.139.10.25",
            "hostname": "app.freshpaint.io",
            "status": "up",
        },
    )
    found = hm.get_host_by_ip(eng_id, "108.139.10.25")
    assert found["hostname"] == "app.freshpaint.io"

    # Second scan: nmap rDNS returns CloudFront PTR — must not clobber
    hm.add_or_update_host(
        eng_id,
        {
            "ip": "108.139.10.25",
            "hostname": "server-108-139-10-25.sfo5.r.cloudfront.net",
            "status": "up",
        },
    )
    found = hm.get_host_by_ip(eng_id, "108.139.10.25")
    assert found["hostname"] == "app.freshpaint.io", (
        "CDN PTR overwrote canonical hostname — fix regressed"
    )


def test_storage_allows_canonical_upgrade_over_generic(storage_engagement):
    """
    The reverse direction: if we accidentally captured a generic PTR
    first (scan started from the IP), a later real hostname must be
    able to overwrite it.
    """
    from souleyez.storage.hosts import HostManager

    eng_id = storage_engagement
    hm = HostManager()

    hm.add_or_update_host(
        eng_id,
        {
            "ip": "108.139.10.25",
            "hostname": "server-108-139-10-25.sfo5.r.cloudfront.net",
            "status": "up",
        },
    )
    hm.add_or_update_host(
        eng_id,
        {
            "ip": "108.139.10.25",
            "hostname": "app.freshpaint.io",
            "status": "up",
        },
    )
    found = hm.get_host_by_ip(eng_id, "108.139.10.25")
    assert found["hostname"] == "app.freshpaint.io"


def test_storage_fills_empty_hostname(storage_engagement):
    """
    If the host was created without a hostname, any first hostname
    (even generic) is an upgrade.
    """
    from souleyez.storage.hosts import HostManager

    eng_id = storage_engagement
    hm = HostManager()

    hm.add_or_update_host(
        eng_id,
        {"ip": "108.139.10.25", "status": "up"},
    )
    hm.add_or_update_host(
        eng_id,
        {
            "ip": "108.139.10.25",
            "hostname": "server-108-139-10-25.sfo5.r.cloudfront.net",
            "status": "up",
        },
    )
    found = hm.get_host_by_ip(eng_id, "108.139.10.25")
    # Generic is fine when the field was empty before
    assert (
        found["hostname"]
        == "server-108-139-10-25.sfo5.r.cloudfront.net"
    )
