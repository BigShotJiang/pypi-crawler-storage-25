#!/usr/bin/env python3
"""
Tests for v3.0.77 findings display: prefer hostname (affected_target)
over ip_address in UI rendering.

Background: list_findings SQL already does
COALESCE(h.hostname, h.ip_address) AS affected_target, but four
render sites in interactive.py were reading finding["ip_address"]
directly, bypassing the COALESCE. Result: findings linked to a host
with a real hostname (e.g., freshpaint-cdn-staging.com) still
displayed the IP (65.8.180.18). Fixed by reading affected_target
first with ip_address as fallback.
"""


def _resolve_finding_host(finding):
    """
    Mirrors the v3.0.77 render logic in interactive.py — used in 4
    places: list view, detail view, export, paginated row.
    """
    return (
        finding.get("affected_target")
        or finding.get("ip_address")
        or "N/A"
    )


def test_prefers_hostname_when_available():
    """affected_target is the COALESCE'd hostname-or-IP from SQL."""
    finding = {
        "ip_address": "65.8.180.18",
        "hostname": "freshpaint-cdn-staging.com",
        "affected_target": "freshpaint-cdn-staging.com",
    }
    assert _resolve_finding_host(finding) == "freshpaint-cdn-staging.com"


def test_falls_back_to_ip_when_no_hostname():
    """Host has no hostname captured — display the IP."""
    finding = {
        "ip_address": "65.8.180.18",
        "hostname": None,
        "affected_target": "65.8.180.18",  # COALESCE returned IP
    }
    assert _resolve_finding_host(finding) == "65.8.180.18"


def test_legacy_finding_without_affected_target_falls_back():
    """
    Defensive: if affected_target is missing entirely (older finding
    fetched from a code path that didn't go through list_findings),
    fall back to ip_address rather than crash or render N/A.
    """
    finding = {"ip_address": "10.0.0.5"}
    assert _resolve_finding_host(finding) == "10.0.0.5"


def test_completely_empty_finding_renders_na():
    """Edge case: no host data at all."""
    assert _resolve_finding_host({}) == "N/A"
    assert _resolve_finding_host({"ip_address": None, "affected_target": None}) == "N/A"


def test_engagement_11_scenario():
    """
    Replays exactly what the user reported: nmap finding tied to a
    host where the v3.0.74 storage layer had captured the canonical
    hostname, but the UI was rendering the IP.
    """
    finding = {
        "id": 24441,
        "severity": "medium",
        "finding_type": "misconfiguration",
        "tool": "nmap",
        "ip_address": "65.8.180.18",
        "hostname": "freshpaint-cdn-staging.com",
        "affected_target": "freshpaint-cdn-staging.com",
        "title": "Unencrypted HTTP Service",
    }
    rendered = _resolve_finding_host(finding)
    assert rendered == "freshpaint-cdn-staging.com"
    assert rendered != "65.8.180.18"
