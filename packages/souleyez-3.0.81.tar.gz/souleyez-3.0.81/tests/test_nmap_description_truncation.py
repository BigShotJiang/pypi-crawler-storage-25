#!/usr/bin/env python3
"""
Regression: nmap vulnerability descriptions were stored truncated to
the first 3 lines (description_parts[:3]). Multi-paragraph CVE
descriptions like Slowloris (CVE-2007-6750) ended mid-sentence in
audit-evidence reports — '...By doing so, it starves' with no
continuation.

v3.0.70 removed the [:3] cap and replaced it with a 4000-char limit
that no real vuln description hits.
"""

from souleyez.parsers.nmap_parser import _parse_vuln_script_block


def test_long_vuln_description_not_truncated_to_3_lines():
    """Real Slowloris script output spans 4-5 lines. Pre-3.0.70 the
    parser kept only the first 3, cutting the description mid-sentence."""
    block = """| http-slowloris-check:
|   VULNERABLE:
|   Slowloris DOS attack
|     State: VULNERABLE
|     IDs: CVE:CVE-2007-6750
|     Description:
|       Slowloris tries to keep many connections to the target web server open.
|       It accomplishes this by opening connections and sending partial requests.
|       By doing so, it starves the resources allocated for client connections.
|       Apache mpm_prefork, mpm_worker, and mpm_event are all vulnerable to some degree.
|     References:
|       http://ha.ckers.org/slowloris/
|_      https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2007-6750"""

    vulns = _parse_vuln_script_block(
        "http-slowloris-check", block, host_ip="1.2.3.4", port=80
    )

    assert len(vulns) >= 1
    desc = vulns[0]["description"]
    # The full description should include all four content lines, not
    # just the first three.
    assert "starves" in desc
    assert "Apache mpm_prefork" in desc, (
        f"description truncated before 4th paragraph line. "
        f"Stored description was: {desc!r}"
    )


def test_short_vuln_description_passes_through_unchanged():
    """Short descriptions (under the 4000-char cap) should not be
    truncated or get a '...' suffix."""
    block = """| http-csrf:
|   VULNERABLE:
|   Cross-Site Request Forgery
|     State: VULNERABLE
|     Description:
|       The application is vulnerable to CSRF.
|     References:
|_      http://example.com"""

    vulns = _parse_vuln_script_block("http-csrf", block, host_ip="1.2.3.4", port=80)
    assert len(vulns) >= 1
    desc = vulns[0]["description"]
    assert not desc.endswith(
        "..."
    ), f"short description should not have truncation marker: {desc!r}"
