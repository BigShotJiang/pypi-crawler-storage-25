#!/usr/bin/env python3
"""
Regression tests for v3.0.66: remediation paragraphs in HTML reports
must have markdown processed (bold, code spans, lists) instead of
showing literal `**asterisks**` and ` `backticks` ` to the reader.
"""

from souleyez.reporting.formatters import HTMLFormatter


def _render_finding(title: str, severity: str = "low") -> str:
    """Render the collapsible-findings HTML for a single finding to verify
    its remediation block is markdown-processed."""
    fmt = HTMLFormatter()
    findings = {
        "critical": [],
        "high": [],
        "medium": [],
        "low": [],
        "info": [],
    }
    finding = {
        "title": title,
        "severity": severity,
        "ip_address": "1.2.3.4",
        "tool": "nikto",
        "description": "test description",
    }
    findings[severity] = [finding]
    return fmt.detailed_findings_collapsible(findings)


def test_remediation_bold_renders_as_html_strong_not_asterisks():
    """Pre-3.0.66: remediation containing **bold** rendered as literal
    asterisks because the formatter wrapped it in <p>...</p> which
    suppressed markdown processing."""
    out = _render_finding("Missing X-Content-Type-Options header", severity="low")
    # The remediation map has `**Nginx:**` etc. Should render as <strong>.
    assert "<strong>Nginx:</strong>" in out, (
        f"bold not rendered — markdown was suppressed. "
        f"Excerpt around remediation: "
        f"{out[out.find('Remediation:'): out.find('Remediation:') + 600]!r}"
    )
    # And NO literal `**Nginx:**` in the output
    assert "**Nginx:**" not in out


def test_remediation_code_span_renders_as_html_code_not_backticks():
    out = _render_finding("Missing X-Content-Type-Options header", severity="low")
    # Has `X-Content-Type-Options: nosniff` in backticks → should be <code>
    assert "<code>X-Content-Type-Options: nosniff</code>" in out
    # Backticks shouldn't render as literal text
    assert "`X-Content-Type-Options: nosniff`" not in out


def test_remediation_bullet_list_renders_as_html_ul():
    """The remediation for several categories uses markdown bullet lists."""
    out = _render_finding("Missing X-Content-Type-Options header", severity="low")
    # Markdown `- ` bullets → <ul><li>
    assert "<ul>" in out and "</ul>" in out
    assert "<li>" in out and "</li>" in out


def test_remediation_numbered_list_renders_as_html_ol():
    """S3 critical remediation uses 1. 2. 3. — should render as <ol>."""
    out = _render_finding(
        "Public S3 bucket listable with 5 object(s): my-bucket", severity="critical"
    )
    assert "<ol>" in out and "</ol>" in out


def test_remediation_no_bare_asterisks_for_classified_findings():
    """Sweep: any remediation rendered for classified findings should
    not contain literal `**` (the markdown-not-processed regression)."""
    titles_to_check = [
        ("Missing X-Content-Type-Options header", "low"),
        ("Missing X-Frame-Options header", "low"),
        ("Missing Content-Security-Policy header", "low"),
        ("CORS wildcard: Access-Control-Allow-Origin set to '*'", "medium"),
        ("CSP allows 'unsafe-inline' in script-src", "medium"),
        ("Public S3 bucket listable with 1 object(s): x", "critical"),
        ("CVE-2007-6750 - Slowloris DOS attack", "high"),
        ("Unencrypted HTTP Service", "medium"),
    ]
    for title, severity in titles_to_check:
        out = _render_finding(title, severity=severity)
        # Find the remediation div and check it specifically
        marker = '<div class="finding-remediation">'
        if marker not in out:
            continue
        rem_start = out.index(marker) + len(marker)
        rem_end = out.index("</div>", rem_start)
        rem_html = out[rem_start:rem_end]
        assert "**" not in rem_html, (
            f"remediation for {title!r} still has literal `**`: " f"{rem_html[:200]!r}"
        )
