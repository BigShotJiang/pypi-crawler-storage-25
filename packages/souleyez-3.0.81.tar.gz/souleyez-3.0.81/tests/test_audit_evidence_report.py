#!/usr/bin/env python3
"""
Tests for the audit-evidence report mode (v3.0.58).

The audit-evidence report is an internal evidence-of-testing artifact
intended to support SOC 2 and HITRUST CSF assessments. It must:

- Identify itself clearly (cover header, period, tester, generated date)
- Document scope (in-scope assets + out-of-scope statement)
- Reference testing methodology and frameworks
- Include tester information + independence statement
- Render findings with full detail (severity, description, evidence, etc.)
- NOT include the speculative "Est. Breach Risk" dollar number
"""

from datetime import datetime

from souleyez.reporting.formatters import HTMLFormatter


def _engagement_full():
    return {
        "id": 1,
        "name": "Internal Quarterly Assessment Q2 2026",
        "tester_name": "Alex SecOps",
        "tester_role": "SecOps Lead",
        "scope_summary": (
            "Q2 internal assessment covering production web application "
            "and AWS infrastructure assets."
        ),
        "methodology_summary": (
            "Mixed automated scanning + targeted exploitation against "
            "in-scope assets."
        ),
        "created_at": "2026-04-01T00:00:00Z",
    }


def _metrics():
    return {
        "risk_level": "MEDIUM",
        "critical_findings": 0,
        "high_findings": 2,
        "medium_findings": 6,
        "low_findings": 17,
        "total_hosts": 14,
    }


def _hosts():
    return [
        {"ip_address": "10.0.0.1", "hostname": "web-01.internal"},
        {"ip_address": "10.0.0.2", "hostname": "web-02.internal"},
        {"ip_address": "10.0.0.3", "hostname": ""},
    ]


# =============================================================================
# audit_evidence_cover
# =============================================================================


def test_cover_includes_required_identity_fields():
    fmt = HTMLFormatter()
    out = fmt.audit_evidence_cover(
        _engagement_full(), _metrics(), datetime(2026, 5, 4, 12, 0, 0)
    )
    # v3.0.67: title split into title-case primary + subtitle
    assert "Internal Security Assessment" in out
    assert "Evidence of Testing" in out
    assert _engagement_full()["name"] in out
    assert "Alex SecOps" in out
    assert "SecOps Lead" in out
    assert "2026-04-01" in out  # period start from created_at
    assert "2026-05-04" in out  # period end / generated date


def test_cover_omits_speculative_breach_cost():
    """The audit-evidence cover must NOT include the
    `Est. Breach Risk` dollar number from executive_one_pager."""
    fmt = HTMLFormatter()
    out = fmt.audit_evidence_cover(_engagement_full(), _metrics(), datetime(2026, 5, 4))
    assert "Est. Breach Risk" not in out
    assert "$200K" not in out
    assert "$" not in out  # no dollar amounts at all in audit cover


def test_cover_handles_missing_tester_metadata_gracefully():
    eng = {
        "name": "Test",
        "created_at": "2026-04-01T00:00:00Z",
        "tester_name": None,
        "tester_role": None,
    }
    fmt = HTMLFormatter()
    out = fmt.audit_evidence_cover(eng, _metrics(), datetime(2026, 5, 4))
    assert "[Tester not specified]" in out
    assert "[Role not specified]" in out


def test_cover_uses_table_layout_not_flexbox():
    """v3.0.67: cover must use real <table> elements (not <div> styled
    as tables) so WeasyPrint PDF rendering aligns columns correctly.
    Flexbox-based layouts collapse weirdly in PDF — that was the v3.0.66
    bug the user reported as 'looks ok in browser, but in pdf not so good'."""
    fmt = HTMLFormatter()
    out = fmt.audit_evidence_cover(_engagement_full(), _metrics(), datetime(2026, 5, 4))
    # Real HTML <table> elements
    assert '<table class="audit-cover-meta">' in out
    assert '<table class="audit-stats-grid">' in out
    # NOT the old flexbox classes
    assert "exec-hero" not in out
    assert "exec-key-stats" not in out
    assert "exec-stat-card" not in out
    assert "exec-one-pager" not in out


def test_cover_has_page_break_via_class():
    """The cover has a class hook (audit-cover) that the CSS targets
    with `page-break-after: always`, so the rest of the report renders
    on page 2 in PDF. Verify the class is on the wrapping div so the
    CSS rule has something to match."""
    fmt = HTMLFormatter()
    out = fmt.audit_evidence_cover(_engagement_full(), _metrics(), datetime(2026, 5, 4))
    assert '<div class="audit-cover">' in out


def test_cover_metadata_has_proper_table_rows():
    """Each piece of cover metadata renders as its own <tr><th>label</th>
    <td>value</td></tr> for guaranteed alignment."""
    fmt = HTMLFormatter()
    out = fmt.audit_evidence_cover(_engagement_full(), _metrics(), datetime(2026, 5, 4))
    for label in ("Engagement", "Period", "Tester", "Classification", "Generated"):
        assert f"<th>{label}</th>" in out, f"missing <th>{label}</th> in cover"


def test_cover_stats_grid_has_four_cells():
    """4 stat columns: Critical, High, Medium/Low, Hosts. Each renders
    as its own <td> in a single <tr> so they all line up at the same
    Y coordinate in the PDF."""
    fmt = HTMLFormatter()
    out = fmt.audit_evidence_cover(_engagement_full(), _metrics(), datetime(2026, 5, 4))
    # Locate the stats grid block and count <td> elements within it
    start = out.index('<table class="audit-stats-grid">')
    end = out.index("</table>", start)
    grid = out[start:end]
    assert (
        grid.count("<td") == 4
    ), f"expected 4 <td> cells in stats grid, got {grid.count('<td')}: {grid!r}"


def test_cover_title_split_into_title_and_subtitle():
    """v3.0.66 had one long h1 'INTERNAL SECURITY ASSESSMENT — EVIDENCE
    OF TESTING' that wrapped awkwardly in PDF. v3.0.67 splits it into
    a primary title + subtitle so it lays out cleanly."""
    fmt = HTMLFormatter()
    out = fmt.audit_evidence_cover(_engagement_full(), _metrics(), datetime(2026, 5, 4))
    assert '<h1 class="audit-cover-title">Internal Security Assessment</h1>' in out
    assert '<p class="audit-cover-subtitle">Evidence of Testing</p>' in out
    # Old combined header should not appear
    assert "INTERNAL SECURITY ASSESSMENT — EVIDENCE OF TESTING" not in out


def test_cover_uses_risk_posture_not_risk_score():
    """Cover should label the risk indicator as 'RISK POSTURE'
    (qualitative tier) rather than the numeric 'RISK SCORE' from the
    executive one-pager — the numeric score is sensitive to changes in
    weighting and isn't a defensible audit metric."""
    fmt = HTMLFormatter()
    out = fmt.audit_evidence_cover(_engagement_full(), _metrics(), datetime(2026, 5, 4))
    assert "RISK POSTURE" in out
    assert "RISK SCORE" not in out


# =============================================================================
# audit_evidence_scope_section
# =============================================================================


def test_scope_section_uses_engagement_summary_when_provided():
    fmt = HTMLFormatter()
    out = fmt.audit_evidence_scope_section(_engagement_full(), _hosts())
    assert "Q2 internal assessment" in out
    assert "AWS infrastructure" in out


def test_scope_section_falls_back_to_default_when_summary_missing():
    eng = {"name": "X", "created_at": "2026-04-01"}
    fmt = HTMLFormatter()
    out = fmt.audit_evidence_scope_section(eng, _hosts())
    assert "web application and" in out
    assert "cloud infrastructure" in out


def test_scope_section_splits_ips_from_hostnames():
    """Mixed IP/hostname asset list should be rendered as two distinct
    sections — IPs and hostnames are different artifact classes and an
    audit reviewer needs to scan them separately."""
    fmt = HTMLFormatter()
    hosts = [
        {"ip_address": "10.0.0.1", "hostname": "web-01.internal"},
        {"ip_address": "10.0.0.2", "hostname": ""},
        {"ip_address": "", "hostname": "web-02.internal"},
        {"ip_address": "app.example.com", "hostname": ""},  # hostname-as-ip
    ]
    out = fmt.audit_evidence_scope_section(_engagement_full(), hosts)
    assert "In-Scope IP Addresses" in out
    assert "In-Scope Hosts" in out
    # IPs in IP block
    assert "10.0.0.1" in out
    assert "10.0.0.2" in out
    # Hostnames in hostname block (incl. one stored in ip_address column)
    assert "web-01.internal" in out
    assert "web-02.internal" in out
    assert "app.example.com" in out


def test_scope_section_skips_unknown_hosts():
    """Hosts where both ip_address and hostname are empty should be
    dropped from the listing — they're noise and confuse audit reviewers."""
    fmt = HTMLFormatter()
    hosts = [
        {"ip_address": "10.0.0.1", "hostname": "real-host"},
        {"ip_address": "", "hostname": ""},  # should be dropped
        {"ip_address": None, "hostname": None},  # should be dropped
    ]
    out = fmt.audit_evidence_scope_section(_engagement_full(), hosts)
    assert "unknown" not in out.lower() or "Unknown" not in out
    # Counts should reflect real entries only
    assert "In-Scope IP Addresses (1)" in out
    assert "In-Scope Hosts (1)" in out


def test_scope_section_dedupes_repeated_assets():
    """Duplicate hosts (same IP listed twice) should only render once."""
    fmt = HTMLFormatter()
    hosts = [
        {"ip_address": "10.0.0.1", "hostname": "h1"},
        {"ip_address": "10.0.0.1", "hostname": "h1"},
        {"ip_address": "10.0.0.1", "hostname": ""},
    ]
    out = fmt.audit_evidence_scope_section(_engagement_full(), hosts)
    assert "In-Scope IP Addresses (1)" in out
    assert "In-Scope Hosts (1)" in out


def test_scope_section_includes_out_of_scope_statement():
    fmt = HTMLFormatter()
    out = fmt.audit_evidence_scope_section(_engagement_full(), _hosts())
    assert "Out-of-scope" in out


def test_format_affected_host_no_duplication_when_path_is_hostname():
    """Regression: csp_misconfiguration findings store the target URL in
    `path` (e.g. 'app.freshpaint.io'), and the host record had both
    ip_address and hostname set to the same value. Old formatter
    produced 'app.freshpaint.ioapp.freshpaint.io' by appending path
    directly. Path values that don't start with '/' are NOT real paths
    and must not be appended."""
    fmt = HTMLFormatter()
    finding = {
        "ip_address": None,
        "hostname": "app.freshpaint.io",
        "port": None,
        "path": "app.freshpaint.io",  # not a path — a hostname
    }
    result = fmt._format_affected_host(finding)
    assert result == "app.freshpaint.io", f"affected host duplicated: {result!r}"


def test_format_affected_host_dedupes_when_ip_equals_hostname():
    """Regression: when ip_address and hostname are both set to the same
    value (e.g. external web targets with no real IP), the formatter
    used to render '65.8.54.48 (65.8.54.48):80'. Should render '65.8.54.48:80'."""
    fmt = HTMLFormatter()
    finding = {
        "ip_address": "65.8.54.48",
        "hostname": "65.8.54.48",
        "port": 80,
    }
    assert fmt._format_affected_host(finding) == "65.8.54.48:80"


def test_format_affected_host_keeps_real_path_appended():
    """Real URL paths (starting with '/') should still be appended."""
    fmt = HTMLFormatter()
    finding = {
        "ip_address": "10.0.0.1",
        "hostname": "web-01",
        "port": 8080,
        "path": "/admin/login",
    }
    assert fmt._format_affected_host(finding) == "10.0.0.1 (web-01):8080/admin/login"


def test_format_affected_host_skips_non_path_values():
    """A 'path' that is just '/' or doesn't start with '/' is skipped."""
    fmt = HTMLFormatter()
    assert (
        fmt._format_affected_host({"ip_address": "1.2.3.4", "path": "/"}) == "1.2.3.4"
    )
    assert (
        fmt._format_affected_host({"ip_address": "1.2.3.4", "path": "https://x.com/y"})
        == "1.2.3.4"
    )


def test_scope_section_truncates_long_host_lists():
    """Each section (IPs, hostnames) truncates independently at 20."""
    many_hosts = [
        {"ip_address": f"10.0.0.{i}", "hostname": f"h{i}.example.com"}
        for i in range(50)
    ]
    fmt = HTMLFormatter()
    out = fmt.audit_evidence_scope_section(_engagement_full(), many_hosts)
    assert "In-Scope IP Addresses (50)" in out
    assert "In-Scope Hosts (50)" in out
    assert "Showing first 20 of 50" in out


# =============================================================================
# audit_evidence_methodology_section
# =============================================================================


def test_methodology_uses_engagement_summary_when_provided():
    fmt = HTMLFormatter()
    out = fmt.audit_evidence_methodology_section(_engagement_full())
    assert "Mixed automated scanning" in out


def test_methodology_falls_back_to_default():
    eng = {"name": "X"}
    fmt = HTMLFormatter()
    out = fmt.audit_evidence_methodology_section(eng)
    assert "structured methodology" in out


def test_methodology_includes_required_framework_references():
    """SOC 2 and HITRUST evidence reports should cite their methodology
    framework. Auditors look for these by name."""
    fmt = HTMLFormatter()
    out = fmt.audit_evidence_methodology_section(_engagement_full())
    assert "PTES" in out
    assert "NIST SP 800-115" in out
    assert "OWASP" in out
    assert "CVSS" in out


# =============================================================================
# audit_evidence_tester_section
# =============================================================================


def test_tester_section_renders_name_and_role():
    fmt = HTMLFormatter()
    out = fmt.audit_evidence_tester_section(_engagement_full())
    assert "Alex SecOps" in out
    assert "SecOps Lead" in out


def test_tester_section_includes_independence_statement():
    """SOC 2 and HITRUST require an independence statement when the
    testing is performed by an internal team."""
    fmt = HTMLFormatter()
    out = fmt.audit_evidence_tester_section(_engagement_full())
    assert "Independence Statement" in out
    assert "independent" in out.lower()


def test_tester_section_handles_missing_metadata():
    eng = {"name": "X"}
    fmt = HTMLFormatter()
    out = fmt.audit_evidence_tester_section(eng)
    assert "[Tester name not specified]" in out


# =============================================================================
# audit_evidence_footer
# =============================================================================


def test_footer_frames_document_for_soc2_hitrust():
    fmt = HTMLFormatter()
    out = fmt.audit_evidence_footer(datetime(2026, 5, 4))
    assert "SOC 2" in out
    assert "HITRUST" in out
    assert "internal" in out.lower()


def test_footer_disclaims_specific_control_mapping():
    """Per design, the report does NOT map findings to specific
    controls; the footer should make that explicit so auditors know
    the mapping is their responsibility."""
    fmt = HTMLFormatter()
    out = fmt.audit_evidence_footer(datetime(2026, 5, 4))
    assert "audit firm" in out.lower() or "authorized assessor" in out.lower()


def test_footer_includes_generation_date():
    fmt = HTMLFormatter()
    out = fmt.audit_evidence_footer(datetime(2026, 5, 4))
    assert "2026-05-04" in out


# =============================================================================
# Generator integration
# =============================================================================


def test_generator_accepts_audit_evidence_report_type():
    """Verify report_type='audit-evidence' passes the valid_types check."""
    from souleyez.reporting.generator import ReportGenerator

    g = ReportGenerator()
    # Calling generate_report against a non-existent engagement should fail
    # later (not at validation), proving 'audit-evidence' is accepted as a
    # valid report_type.
    try:
        g.generate_report(engagement_id=999999, report_type="audit-evidence")
    except ValueError as e:
        # If the ValueError is about report type, the test fails
        assert "Invalid report_type" not in str(
            e
        ), f"audit-evidence rejected as invalid report_type: {e}"
    except Exception:
        # Any other exception (engagement not found, DB error, etc.) is fine —
        # we only care that the type validation passed.
        pass


def test_assemble_html_helper_exists():
    """The audit-evidence branch uses _assemble_html — ensure the helper
    is present so the branch doesn't break at runtime."""
    from souleyez.reporting.generator import ReportGenerator

    assert hasattr(ReportGenerator, "_assemble_html")


def test_audit_evidence_uses_collapsible_findings():
    """v3.0.60: audit-evidence findings should render as
    severity-grouped collapsible <details> sections, not a flat list.
    Auditors scan long findings lists by tier, and a 50-finding flat
    list is unreadable as a deliverable."""
    fmt = HTMLFormatter()
    findings = {
        "critical": [],
        "high": [
            {
                "title": "Slowloris DoS",
                "severity": "high",
                "ip_address": "1.2.3.4",
                "tool": "nmap",
                "description": "Test",
            }
        ],
        "medium": [
            {
                "title": "CSP unsafe-inline",
                "severity": "medium",
                "hostname": "app.example.com",
                "tool": "http_fingerprint",
                "description": "Test",
            }
        ],
        "low": [],
        "info": [],
    }
    out = fmt.detailed_findings_collapsible(findings)

    # Severity-grouped <details> sections present
    assert '<details id="findings-high"' in out
    assert '<details id="findings-medium"' in out
    # Empty severities (critical/low/info) are NOT rendered as sections
    assert '<details id="findings-critical"' not in out
    assert '<details id="findings-low"' not in out
    assert '<details id="findings-info"' not in out

    # Each rendered section labels the severity tier and finding count
    assert "HIGH SEVERITY FINDINGS" in out
    assert "MEDIUM SEVERITY FINDINGS" in out
    assert "1 finding" in out

    # High severity is auto-expanded for visibility
    assert '<details id="findings-high" open' in out
    # Medium is collapsed by default
    assert '<details id="findings-medium" open' not in out
    # The string "findings-medium" should still appear (just without "open")
    assert '<details id="findings-medium"' in out

    # Expand All / Collapse All controls present
    assert "expandAll()" in out
    assert "collapseAll()" in out
