#!/usr/bin/env python3
"""
Tests for v3.0.80: gobuster uniform-response filter applied at the
parser-output stage so every downstream consumer (web-path storage,
chain dispatch context, php/asp/high-value-dir extraction, and the
existing v3.0.79 finding-creation guard) sees only the outliers.

Background: v3.0.79 filtered findings but not paths. On a CDN-fronted
host returning a uniform default response, gobuster reported
thousands of phantom paths; only the high-severity findings were
suppressed. The chain dispatcher still read php_files, asp_files,
high_value_dirs, paths_with_params from the polluted parsed output
and fired ffuf/nuclei/sqlmap/katana per phantom path — engagement
#11 saw 41 wasted chain jobs from a single gobuster invocation
against freshpaint-impression-staging.com.

Fix: drop dominant-signature paths from parsed["paths"] before any
downstream consumer reads. One point of leverage instead of
scattered guards.
"""

from souleyez.handlers.gobuster_handler import GobusterHandler


def _path(name, status, size):
    return {
        "path": f"/{name}",
        "url": f"https://x.example.com/{name}",
        "status_code": status,
        "size": size,
    }


# ---------------------------------------------------------------------------
# Filter applied at parser-output level
# ---------------------------------------------------------------------------


def test_uniform_response_drops_paths_from_parsed():
    """
    100 wordlist hits all returning identical CDN default. The filter
    should drop them all from parsed["paths"] so downstream consumers
    don't see phantom paths.
    """
    paths = [_path(f"file{i}.bak", 403, 1234) for i in range(100)]

    sig = GobusterHandler._uniform_response_signature(paths)
    # 1234 // 1024 = 1 (v3.0.81 bucketed signature)
    assert sig == (403, 1)

    # Simulate the v3.0.80 filter step
    kept = [p for p in paths if GobusterHandler._signature_for_path(p) != sig]
    assert kept == []


def test_uniform_response_keeps_outliers():
    """
    99 phantom CDN responses + 1 real outlier (200, 8MB). After
    filtering, only the outlier survives — that's the genuine
    discovery worth scanning further.
    """
    paths = [_path(f"file{i}.bak", 403, 1234) for i in range(99)]
    paths.append(_path("db-backup.zip", 200, 8_000_000))

    sig = GobusterHandler._uniform_response_signature(paths)
    kept = [p for p in paths if GobusterHandler._signature_for_path(p) != sig]

    assert len(kept) == 1
    assert kept[0]["path"] == "/db-backup.zip"


def test_no_filter_when_responses_vary():
    """
    Genuine app: every path gets a different response shape. Filter
    must NOT fire — would drop real findings.
    """
    paths = [
        _path("admin", 200, 4500),
        _path("config.php", 403, 250),
        _path("robots.txt", 200, 89),
        _path("api/v1", 401, 32),
        _path("login", 200, 8400),
        _path("static", 301, 0),
    ]
    sig = GobusterHandler._uniform_response_signature(paths)
    assert sig is None  # Filter doesn't fire; all paths kept


def test_filter_applied_above_90_percent_only():
    """
    8 of 10 share signature (80%) — below threshold. Don't filter;
    accept some noise rather than risk silently dropping real
    findings on hosts with mixed-but-not-uniform behavior.
    """
    paths = [_path(f"a{i}.bak", 403, 1234) for i in range(8)]
    paths.append(_path("real1", 200, 5000))
    paths.append(_path("real2", 200, 6000))

    sig = GobusterHandler._uniform_response_signature(paths)
    assert sig is None


# ---------------------------------------------------------------------------
# Downstream consumers see only the filtered list
# ---------------------------------------------------------------------------


def test_php_files_extraction_uses_filtered_paths():
    """
    The chain dispatcher reads php_files from parsed["paths"]. After
    v3.0.80 the filter runs upstream, so php_files only contains
    real .php paths, not phantom CDN responses for /xerces.php-style
    wordlist entries.
    """
    paths = [_path(f"phantom{i}.php", 403, 1234) for i in range(20)]
    paths.append(_path("real-app.php", 200, 5000))

    # Mirror the v3.0.80 filter step
    sig = GobusterHandler._uniform_response_signature(paths)
    if sig:
        paths = [p for p in paths if GobusterHandler._signature_for_path(p) != sig]

    # Now extract php files like the handler does
    php_files = [
        (p.get("url"), p.get("status_code"))
        for p in paths
        if p.get("url", "").endswith(".php")
        and p.get("status_code") in [200, 401, 403]
    ]
    assert len(php_files) == 1
    assert "real-app.php" in php_files[0][0]


def test_engagement_11_chain_explosion_prevented():
    """
    Replays the engagement #11 freshpaint-impression-staging.com
    explosion: gobuster reports 50 paths matching .bak/.zip/.old
    patterns plus a few categories that previously triggered the
    rule_id #68-201 chain fan-out. After v3.0.80 the filter eats
    them upstream so the chain dispatcher never sees the polluted
    list.
    """
    # 50 phantom paths matching various wordlist categories that
    # previously fired chain rules per category
    paths = []
    for i in range(50):
        for ext in ("bak", "zip", "old", "env", "config.php", "admin", "git"):
            paths.append(
                _path(
                    f"wordlist{i}-{ext}",
                    403,
                    1234,
                )
            )

    sig = GobusterHandler._uniform_response_signature(paths)
    # 1234 // 1024 = 1 (v3.0.81 bucketed signature)
    assert sig == (403, 1)
    # After filter, downstream sees an empty list — no chain explosion
    kept = [p for p in paths if GobusterHandler._signature_for_path(p) != sig]
    assert kept == []


# ---------------------------------------------------------------------------
# Filter is idempotent and survives missing fields
# ---------------------------------------------------------------------------


def test_filter_handles_missing_size():
    """
    Some parsers may not capture size on every path (e.g., 301
    redirects with empty body). Filter should handle gracefully.
    """
    paths = [
        {"path": "/a", "url": "x", "status_code": 301, "size": None},
        {"path": "/b", "url": "x", "status_code": 200, "size": 5000},
        {"path": "/c", "url": "x", "status_code": 403, "size": 1234},
    ]
    # Just don't crash
    sig = GobusterHandler._uniform_response_signature(paths)
    # Not enough paths to fire; that's fine
    assert sig is None


def test_filter_idempotent_on_already_filtered():
    """
    Running the filter twice on the same list shouldn't change
    anything on the second pass.
    """
    paths = [_path("real1", 200, 5000), _path("real2", 200, 6000)]
    sig1 = GobusterHandler._uniform_response_signature(paths)
    assert sig1 is None
    # Running again on the same list — still no signature
    sig2 = GobusterHandler._uniform_response_signature(paths)
    assert sig2 is None
