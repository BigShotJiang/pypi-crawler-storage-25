"""
Migration 029: Add audit-evidence metadata fields to engagements.

Adds optional fields used by the audit-evidence report mode:
- tester_name           : person who performed the testing
- tester_role           : their role at the time (e.g. "SecOps Lead")
- scope_summary         : explicit in-scope statement (web app + cloud infra etc.)
- methodology_summary   : brief methodology description / framework references

All fields are TEXT NULL — existing engagements remain valid; the
audit-evidence report renders empty placeholders if values are missing.
"""


def _column_exists(db, table: str, column: str) -> bool:
    rows = db.execute(f"PRAGMA table_info({table})").fetchall()
    return any((r[1] if not isinstance(r, dict) else r["name"]) == column for r in rows)


def upgrade(db):
    """Add audit-evidence metadata columns to engagements."""
    columns = [
        ("tester_name", "TEXT"),
        ("tester_role", "TEXT"),
        ("scope_summary", "TEXT"),
        ("methodology_summary", "TEXT"),
    ]
    for name, type_ in columns:
        if not _column_exists(db, "engagements", name):
            db.execute(f"ALTER TABLE engagements ADD COLUMN {name} {type_}")


def downgrade(db):
    """SQLite doesn't support DROP COLUMN cleanly pre-3.35; left as no-op."""
    pass
