#!/usr/bin/env python3
"""
souleyez.parsers.nikto_parser

Parses Nikto web server scanner output into structured data.
"""

import re
from typing import Any, Dict, List


def parse_nikto_output(output: str, target: str = "") -> Dict[str, Any]:
    """
    Parse Nikto output and extract findings.

    Nikto output format:
    - Nikto v2.5.0
    ---------------------------------------------------------------------------
    + Target IP:          1.2.3.4
    + Target Hostname:    example.com
    + Target Port:        80
    + Start Time:         2025-01-01 12:00:00 (GMT0)
    ---------------------------------------------------------------------------
    + Server: Apache/2.4.41 (Ubuntu)
    + /: The anti-clickjacking X-Frame-Options header is not present.
    + /admin/: Directory indexing found.
    + OSVDB-3092: /admin/: This might be interesting...
    + /config.php.bak: Backup file found.
    ---------------------------------------------------------------------------
    + 1 host(s) tested

    Returns:
        Dict with structure:
        {
            'target': str,
            'target_ip': str,
            'target_port': int,
            'server': str,
            'findings': [
                {
                    'osvdb': str or None,
                    'path': str,
                    'description': str,
                    'severity': str  # 'info', 'low', 'medium', 'high'
                },
                ...
            ],
            'stats': {
                'total': int,
                'by_severity': {'high': int, 'medium': int, 'low': int, 'info': int}
            }
        }
    """
    result = {
        "target": target,
        "target_ip": "",
        "target_hostname": "",
        "target_port": 80,
        "server": "",
        "findings": [],
        "stats": {
            "total": 0,
            "by_severity": {"high": 0, "medium": 0, "low": 0, "info": 0},
        },
    }

    lines = output.split("\n")

    for line in lines:
        line = line.strip()

        # Skip empty lines and dividers
        if not line or line.startswith("---") or line.startswith("==="):
            continue

        # Parse target info
        if line.startswith("+ Target IP:"):
            match = re.search(r"\+ Target IP:\s+(.+)", line)
            if match:
                result["target_ip"] = match.group(1).strip()

        elif line.startswith("+ Target Hostname:"):
            match = re.search(r"\+ Target Hostname:\s+(.+)", line)
            if match:
                result["target_hostname"] = match.group(1).strip()

        elif line.startswith("+ Target Port:"):
            match = re.search(r"\+ Target Port:\s+(\d+)", line)
            if match:
                result["target_port"] = int(match.group(1))

        elif line.startswith("+ Server:"):
            match = re.search(r"\+ Server:\s+(.+)", line)
            if match:
                result["server"] = match.group(1).strip()

        # Parse findings (any line starting with + that isn't metadata)
        elif line.startswith("+"):
            finding = _parse_finding_line(line)
            if finding:
                result["findings"].append(finding)
                severity = finding.get("severity", "info")
                result["stats"]["by_severity"][severity] = (
                    result["stats"]["by_severity"].get(severity, 0) + 1
                )
                result["stats"]["total"] += 1

    return result


def _parse_finding_line(line: str) -> Dict[str, Any]:
    """
    Parse a single Nikto finding line.

    Formats:
    + OSVDB-3092: /admin/: This might be interesting...
    + /admin/: Directory indexing found.
    + /: The anti-clickjacking X-Frame-Options header is not present.
    + Server: Apache/2.4.41 (Ubuntu)  <- Skip these
    """
    # Skip metadata lines
    if line.startswith("+ Server:") or line.startswith("+ Start Time:"):
        return None
    if line.startswith("+ Target"):
        return None
    if line.startswith("+ End Time:"):
        return None
    if line.startswith("+ No CGI"):
        return None
    if "host(s) tested" in line:
        return None
    if "items checked:" in line:
        return None
    # End-of-scan stats line:
    #   "+ 26662 requests: 0 error(s) and 1 item(s) reported on remote host"
    # Not a finding — just nikto telling us the run completed.
    if re.search(r"\d+\s+error\(s\)\s+and\s+\d+\s+item\(s\)\s+reported", line):
        return None
    # CGI-discovery warning: nikto found that the server returns 200 for
    # arbitrary CGI paths (e.g. behind a CDN that serves a default page),
    # so all CGI checks would false-positive. Diagnostic, not a finding.
    if "all cgi directories 'found'" in line.lower():
        return None

    try:
        # Remove leading +
        content = line.lstrip("+ ").strip()

        osvdb = None
        path = ""
        description = ""

        # Check for OSVDB reference
        osvdb_match = re.match(r"(OSVDB-\d+):\s*(.+)", content)
        if osvdb_match:
            osvdb = osvdb_match.group(1)
            content = osvdb_match.group(2)

        # Extract path and description
        # Format: /path/: Description or /path: Description
        path_match = re.match(r"(/[^:]*):?\s*(.+)", content)
        if path_match:
            path = path_match.group(1).rstrip(":").strip()
            description = path_match.group(2).strip()
        else:
            description = content

        # Skip if no meaningful content
        if not description or description.startswith("Target"):
            return None

        # Determine severity based on keywords
        severity = _determine_severity(description, osvdb)

        return {
            "osvdb": osvdb,
            "path": path,
            "description": description,
            "severity": severity,
        }

    except Exception:
        return None


def classify_finding_title(
    description: str, path: str = None, osvdb: str = None
) -> str:
    """
    Build a human-readable, classified title for a Nikto finding.

    Replaces the previous "Nikto: <path> - <truncated raw line>..." format,
    which dumped raw output into the title and was unreadable in reports.

    Strategy:
    1. Detect well-known Nikto finding categories by keyword (missing
       security headers, information disclosure, insecure cookies, etc.)
       and emit a clean classified title.
    2. For unrecognized findings, return a sentence-style title built
       from the first clause of the description, dropping the root-path
       prefix that adds no signal.
    """
    desc = (description or "").strip()
    desc_lower = desc.lower()

    # ---- Missing security headers ----
    missing_header_map = [
        ("x-content-type-options header", "Missing X-Content-Type-Options header"),
        ("x-frame-options header", "Missing X-Frame-Options header"),
        ("x-xss-protection header", "Missing X-XSS-Protection header"),
        (
            "strict-transport-security header",
            "Missing Strict-Transport-Security (HSTS) header",
        ),
        (
            "content-security-policy header",
            "Missing Content-Security-Policy header",
        ),
        ("referrer-policy header", "Missing Referrer-Policy header"),
        ("permissions-policy header", "Missing Permissions-Policy header"),
    ]
    for needle, title in missing_header_map:
        if needle in desc_lower and (
            "is not set" in desc_lower or "is not present" in desc_lower
        ):
            return title

    # ---- Information disclosure via Via / Server / X-* headers ----
    if "retrieved via header" in desc_lower:
        return "Information disclosure: Via header reveals upstream infrastructure"
    if "server may leak inodes via etags" in desc_lower:
        return "Information disclosure: ETag inode leak"

    # ---- CORS wildcard ----
    if "access-control-allow-origin" in desc_lower:
        # Common pattern: "Retrieved access-control-allow-origin header: *"
        if "*" in desc:
            return "CORS wildcard: Access-Control-Allow-Origin set to '*'"
        return "Permissive CORS: Access-Control-Allow-Origin header observed"

    # ---- Root-page redirect (info-disclosure / scope-discovery) ----
    redirect_match = re.search(r"root page\s+/?\s+redirects to:?\s*(\S+)", desc_lower)
    if redirect_match:
        # Pull the actual URL out of the original (case-preserved) string
        url_match = re.search(r"redirects to:?\s*(\S+)", desc, re.IGNORECASE)
        target = url_match.group(1).rstrip(".,") if url_match else ""
        return (
            f"Root page redirects to {target}"
            if target
            else "Root page redirect detected"
        )

    # ---- Multiple IPs / DNS round-robin ----
    if "multiple ips found" in desc_lower or "multiple ip addresses" in desc_lower:
        return "Multiple IPs returned for hostname (DNS round-robin / load balancer)"

    # ---- Server banner changes (informational, possible env change) ----
    if "server banner changed" in desc_lower:
        return "Server banner changed during scan"

    # ---- Uncommon / unexpected header found ----
    uncommon_match = re.search(r"uncommon header ['\"]([^'\"]+)['\"]", desc_lower)
    if uncommon_match:
        header_name = uncommon_match.group(1)
        return f"Information disclosure: uncommon '{header_name}' header observed"

    # ---- Insecure cookies ----
    if "cookie" in desc_lower and "secure flag" in desc_lower:
        cookie_match = re.search(r"cookie\s+['\"]?([\w\-]+)['\"]?", desc_lower)
        if cookie_match:
            return f"Insecure cookie: '{cookie_match.group(1)}' missing Secure flag"
        return "Insecure cookie: missing Secure flag"
    if "cookie" in desc_lower and "httponly" in desc_lower:
        cookie_match = re.search(r"cookie\s+['\"]?([\w\-]+)['\"]?", desc_lower)
        if cookie_match:
            return f"Insecure cookie: '{cookie_match.group(1)}' missing HttpOnly flag"
        return "Insecure cookie: missing HttpOnly flag"

    # ---- Directory indexing / listing ----
    if "directory indexing" in desc_lower or "directory listing" in desc_lower:
        if path and path != "/":
            return f"Directory listing enabled at {path}"
        return "Directory listing enabled"

    # ---- Allowed HTTP methods ----
    if "options method" in desc_lower or "trace method" in desc_lower:
        return "Risky HTTP method exposed (OPTIONS / TRACE)"

    # ---- Robots.txt disclosure ----
    if "robots.txt" in desc_lower:
        entries_match = re.search(r"contains (\d+)\s*entries", desc_lower)
        if entries_match:
            return f"robots.txt disclosure: {entries_match.group(1)} entries"
        return "robots.txt disclosure"

    # ---- Default credentials / admin pages ----
    if "default credentials" in desc_lower:
        return "Default credentials accepted"
    if "admin" in desc_lower and ("default" in desc_lower or "exposed" in desc_lower):
        return (
            f"Exposed admin interface{(' at ' + path) if path and path != '/' else ''}"
        )

    # ---- Generic fallback: first sentence of the original description ----
    # Handler appends "\n\nServer: <name>" / "\nPath: /" to descriptions
    # before storing — strip that off before deriving a title from the
    # first real sentence, otherwise we end up with titles like just
    # "cloudflare" (the value of the appended Server: line).
    first_line = desc.split("\n", 1)[0].strip() if desc else ""
    first_sentence = first_line.split(".", 1)[0].strip() if first_line else ""
    if first_sentence:
        snippet = (
            first_sentence if len(first_sentence) <= 80 else first_sentence[:77] + "..."
        )
        # If we have an OSVDB reference, lead with it for searchability
        if osvdb:
            return f"{osvdb}: {snippet}"
        return snippet

    # ---- Last resort ----
    return f"Nikto finding{(' at ' + path) if path and path != '/' else ''}"


_CLASSIFIED_REMEDIATIONS = [
    # ---- Missing security headers ----
    (
        lambda t: t == "Missing X-Content-Type-Options header",
        (
            "Set the `X-Content-Type-Options: nosniff` HTTP response header on "
            "all endpoints. This prevents MIME-type sniffing-based attacks.\n\n"
            '- **Nginx:** `add_header X-Content-Type-Options "nosniff" always;` '
            "in the server block.\n"
            '- **Apache:** `Header always set X-Content-Type-Options "nosniff"`.\n'
            "- **CloudFront:** configure a Response Headers Policy with "
            "`X-Content-Type-Options: nosniff`.\n"
            "- **AWS ALB / API Gateway:** add to default response header "
            "overrides.\n\n"
            "Verify with `curl -I <url> | grep -i nosniff`."
        ),
    ),
    (
        lambda t: t == "Missing X-Frame-Options header",
        (
            "Set `X-Frame-Options: DENY` (or `SAMEORIGIN` if you embed your own "
            "pages in iframes) to prevent clickjacking.\n\n"
            "**Modern alternative:** `Content-Security-Policy: frame-ancestors "
            "'none'` (or `'self'`) — supersedes X-Frame-Options on modern browsers.\n\n"
            '- **Nginx:** `add_header X-Frame-Options "DENY" always;`\n'
            "- **CloudFront:** Response Headers Policy with the header set.\n\n"
            "If you set both X-Frame-Options and CSP frame-ancestors, browsers "
            "that support CSP use it and ignore X-Frame-Options."
        ),
    ),
    (
        lambda t: t == "Missing Strict-Transport-Security (HSTS) header",
        (
            "Set `Strict-Transport-Security: max-age=31536000; includeSubDomains; "
            "preload` on all HTTPS responses to force browsers to use HTTPS for "
            "the domain.\n\n"
            "**Prerequisites before enabling HSTS:**\n"
            "- All HTTP traffic must already redirect to HTTPS.\n"
            "- All resources (images, scripts, APIs) must be served over HTTPS.\n"
            "- Verify on every subdomain that will inherit the policy via "
            "`includeSubDomains`.\n\n"
            "Once stable, submit the domain to <https://hstspreload.org> for "
            "browser-bundled preload list inclusion. Note: removing HSTS later "
            "from the preload list takes months — verify thoroughly first."
        ),
    ),
    (
        lambda t: t == "Missing Content-Security-Policy header",
        (
            "Define and deploy a Content-Security-Policy. Start in report-only "
            "mode to discover violations without breaking the site, then "
            "promote to enforcing once clean.\n\n"
            "**Baseline policy to start with:**\n\n"
            "    Content-Security-Policy-Report-Only: default-src 'self'; "
            "object-src 'none'; base-uri 'self'; frame-ancestors 'none'; "
            "report-uri /csp-report\n\n"
            "**Critical:** avoid `'unsafe-inline'` and `'unsafe-eval'`. Use "
            "nonces or hashes for any required inline scripts.\n\n"
            "Test the policy at <https://csp-evaluator.withgoogle.com>. "
            "Promote to `Content-Security-Policy:` (enforcing) only after "
            "report-only logs are clean for 1-2 weeks."
        ),
    ),
    (
        lambda t: t == "Missing Referrer-Policy header",
        (
            "Set `Referrer-Policy: strict-origin-when-cross-origin` to limit "
            "the information leaked in the Referer header on cross-origin "
            "navigations.\n\n"
            "Higher-privacy alternatives if your application doesn't need "
            "Referer for analytics: `no-referrer` or `same-origin`."
        ),
    ),
    (
        lambda t: t == "Missing Permissions-Policy header",
        (
            "Define a Permissions-Policy header to disable browser features "
            "your site doesn't use. Example baseline disabling commonly-abused "
            "features:\n\n"
            "    Permissions-Policy: geolocation=(), microphone=(), camera=(), "
            "payment=(), usb=(), magnetometer=()\n\n"
            "Add or remove entries based on which Web APIs your application "
            "legitimately uses."
        ),
    ),
    # ---- CORS ----
    (
        lambda t: t.startswith("CORS wildcard:"),
        (
            "Replace the `*` wildcard in `Access-Control-Allow-Origin` with an "
            "explicit allowlist of trusted origins. Validate the request's "
            "`Origin` header against your allowlist and echo it back, or "
            "maintain a fixed list of permitted origins.\n\n"
            "**Critical security rule:** never combine "
            "`Access-Control-Allow-Origin: *` with "
            "`Access-Control-Allow-Credentials: true` — browsers reject this "
            "combination, but if disabled it bypasses the same-origin policy "
            "for authenticated requests.\n\n"
            "If the endpoint genuinely must serve any origin (e.g. a public "
            "CDN-style API), confirm it never exposes authenticated user data "
            "or allows authenticated requests."
        ),
    ),
    # ---- Information disclosure ----
    (
        lambda t: t.startswith("Information disclosure: Via header"),
        (
            "Strip or rewrite the `Via` header at your edge to avoid leaking "
            "upstream infrastructure details (CloudFront PoPs, proxy versions, "
            "internal hostnames).\n\n"
            "- **CloudFront:** configure a Response Headers Policy that removes "
            "the `Via` header.\n"
            "- **Nginx:** `proxy_hide_header Via;` in the location block.\n"
            "- **AWS ALB:** ALB doesn't set Via by default; check upstream.\n\n"
            "Severity is informational — disclosure of CDN identity is rarely "
            "operationally damaging, but cleaning it up is good hygiene."
        ),
    ),
    (
        lambda t: t == "Information disclosure: ETag inode leak",
        (
            "Configure the web server to remove inode information from ETags.\n\n"
            "- **Apache:** `FileETag MTime Size` in `httpd.conf` (default "
            "includes inode, which can leak filesystem layout in cluster "
            "scenarios).\n"
            "- **Nginx:** ETags don't include inodes by default; if seeing this "
            "review any custom ETag configuration."
        ),
    ),
    (
        lambda t: t.startswith("Information disclosure: uncommon"),
        (
            "Review whether the uncommon header is necessary for your "
            "application's functionality. If it leaks infrastructure details "
            "(software versions, internal hostnames, vendor identification), "
            "strip it at the edge.\n\n"
            "- **CloudFront:** Response Headers Policy → Remove headers.\n"
            "- **Nginx:** `proxy_hide_header <Header-Name>;`\n\n"
            "If the header is required (e.g. CSP `report-to` configurations), "
            "document its purpose and accept the disclosure."
        ),
    ),
    # ---- Cookies ----
    (
        lambda t: t.startswith("Insecure cookie:") and "Secure" in t,
        (
            "Set the `Secure` attribute on all cookies so they're only "
            "transmitted over HTTPS connections, never over plaintext HTTP.\n\n"
            "**Application code examples:**\n\n"
            "    # Express.js\n"
            "    res.cookie('name', 'value', { secure: true });\n\n"
            "    // Django\n"
            "    SESSION_COOKIE_SECURE = True\n"
            "    CSRF_COOKIE_SECURE = True\n\n"
            "Prerequisite: the site must be HTTPS-only — cookies with the "
            "Secure flag will not be set over HTTP at all. If running behind a "
            "reverse proxy that terminates TLS, ensure your application "
            "trusts the `X-Forwarded-Proto` header."
        ),
    ),
    (
        lambda t: t.startswith("Insecure cookie:") and "HttpOnly" in t,
        (
            "Set the `HttpOnly` attribute on cookies that should not be "
            "accessible to client-side JavaScript — typically session and "
            "authentication tokens. This prevents XSS-based cookie theft.\n\n"
            "**Application code examples:**\n\n"
            "    # Express.js\n"
            "    res.cookie('session_id', token, { httpOnly: true, secure: true });\n\n"
            "    // Django (default for SESSIONID)\n"
            "    SESSION_COOKIE_HTTPONLY = True  # default\n\n"
            "**Don't** set HttpOnly on cookies that the client legitimately "
            "needs to read (e.g., a CSRF token your JS code sends as a header)."
        ),
    ),
    # ---- Other ----
    (
        lambda t: t.startswith("Directory listing enabled"),
        (
            "Disable directory indexing in your web server configuration.\n\n"
            "- **Apache:** `Options -Indexes` in the server or directory block.\n"
            "- **Nginx:** `autoindex off;` (this is the default).\n\n"
            "Add an `index.html` placeholder for directories that should "
            "render but have no natural index file, so they don't 403 "
            "awkwardly."
        ),
    ),
    (
        lambda t: t.startswith("robots.txt disclosure"),
        (
            "Review the contents of robots.txt — entries document paths you "
            "don't want crawlers indexing, which often telegraphs their "
            "importance to attackers.\n\n"
            "**Don't use robots.txt to hide sensitive paths.** Use "
            "authentication, authorization, and proper access controls "
            "instead. Robots.txt should only contain entries for paths whose "
            "existence is already public knowledge."
        ),
    ),
    (
        lambda t: t.startswith("Risky HTTP method"),
        (
            "**TRACE method:** disable entirely. TRACE enables Cross-Site "
            "Tracing (XST) attacks and is rarely required.\n\n"
            "- Apache: `TraceEnable off`\n"
            "- Nginx: doesn't support TRACE (no action needed)\n\n"
            "**OPTIONS method:** typically required for CORS preflight; ensure "
            "the response is controlled (only documented endpoints, no "
            "internal paths exposed) and rate-limited."
        ),
    ),
    (
        lambda t: t == "Default credentials accepted",
        (
            "**Change the default credentials immediately.** Generate a strong "
            "unique password using a password manager and rotate any "
            "secrets/keys that may have been exposed under the default "
            "credentials.\n\n"
            "Audit your environment for other systems with default credentials "
            "(routers, IoT devices, admin panels). Default credentials are "
            "the #1 cause of preventable compromise."
        ),
    ),
    # ---- Informational categories: explicit no-action notes ----
    (
        lambda t: t.startswith("Multiple IPs returned for hostname"),
        (
            "**Informational.** Multiple IPs typically indicate load balancing "
            "(round-robin DNS, ELB, CloudFront edge locations) — expected for "
            "production services. No remediation needed unless the IPs reveal "
            "internal infrastructure that should be hidden behind the edge."
        ),
    ),
    (
        lambda t: t == "Server banner changed during scan",
        (
            "**Informational.** Server banner change during a scan typically "
            "indicates a load balancer rotating between origin servers with "
            "different software, OR a deployment occurred mid-scan. Re-run if "
            "the behavior is unexpected; otherwise no remediation needed."
        ),
    ),
    (
        lambda t: t.startswith("Root page redirects to"),
        (
            "**Informational.** Documents the redirect destination (typically "
            "HTTPS upgrade or canonical hostname enforcement). Verify the "
            "redirect target is correct and doesn't expose internal "
            "infrastructure (e.g., load balancer hostnames). No remediation "
            "needed if the redirect is intentional."
        ),
    ),
    # ---- CSP misconfigurations (from http_fingerprint CSP parser) ----
    (
        lambda t: t == "CSP allows 'unsafe-inline' in script-src",
        (
            "The Content-Security-Policy `script-src` directive includes "
            "`'unsafe-inline'`, permitting inline `<script>` tags and "
            "`onclick=` event handlers. This nullifies CSP's primary defense "
            "against XSS — any reflected or stored injection becomes "
            "executable.\n\n"
            "Remove `'unsafe-inline'` from `script-src`. "
            "For required inline scripts, use one of:\n\n"
            "- **Nonces** — generate a random nonce per request, attach to "
            "the CSP header (`script-src 'nonce-abc123'`) and to each "
            '`<script nonce="abc123">`. Best for server-rendered apps.\n'
            "- **Hashes** — compute SHA-256 of each inline script and add "
            "to CSP (`script-src 'sha256-...'`). Best when scripts are static.\n"
            "- **External files** — move inline scripts to `.js` files "
            "served from `'self'` or a trusted CDN.\n\n"
            "Test the new policy in `Content-Security-Policy-Report-Only` "
            "mode for ~1 week before enforcing."
        ),
    ),
    (
        lambda t: t == "CSP allows 'unsafe-eval' in script-src",
        (
            "The `script-src` directive includes `'unsafe-eval'`, allowing "
            "`eval()`, `new Function()`, `setTimeout(string)`, and similar "
            "string-to-code APIs. Expands the XSS attack surface and bypasses "
            "CSP's defense.\n\n"
            "Remove `'unsafe-eval'`. Audit your codebase "
            "and dependencies for `eval()` usage:\n\n"
            "- **Templating libraries** — older Vue/Angular/AlpineJS require "
            "eval. Upgrade to current versions which support CSP-friendly "
            "modes.\n"
            "- **Application code** — replace `eval(jsonStr)` with "
            "`JSON.parse(jsonStr)`. Replace `new Function(code)` with "
            "named/imported functions.\n"
            "- **WebAssembly** — if you need wasm execution, use the more "
            "granular `'wasm-unsafe-eval'` directive instead."
        ),
    ),
    (
        lambda t: t == "CSP allows 'unsafe-inline' in style-src",
        (
            "The `style-src` directive includes `'unsafe-inline'`, allowing "
            'inline `<style>` blocks and `style="..."` attributes. Less '
            "severe than script-src unsafe-inline but enables CSS-injection "
            "data exfiltration and assists XSS chains.\n\n"
            "Move inline styles to external `.css` files, "
            "or use nonces/hashes the same way as scripts. CSS-in-JS "
            "frameworks support nonce attribution."
        ),
    ),
    (
        lambda t: t.startswith("CSP uses bare wildcard"),
        (
            "A CSP directive contains a bare `*` wildcard, allowing "
            "resources from ANY origin. This effectively disables that "
            "directive's policy enforcement.\n\n"
            "Replace `*` with an explicit allowlist of "
            "origins. For directives that genuinely need broad scope (e.g., "
            "`img-src` for user avatars), prefer `'self' https:` over `*` "
            "to at least require HTTPS transport."
        ),
    ),
    # ---- S3 misconfigurations (from s3_check) ----
    (
        lambda t: t.startswith("Public S3 bucket listable with"),
        (
            "**Anyone on the internet can list and download every object in "
            "this S3 bucket.** Treat as a data-exposure incident.\n\n"
            "**Immediate action:**\n\n"
            "1. **Block public access** at the bucket level: AWS Console → "
            "S3 → Bucket → Permissions → Block all public access → enable "
            "all four toggles.\n"
            "2. **Audit bucket contents** — note what was exposed and "
            "treat any sensitive data as already leaked. Notify legal / "
            "privacy / regulators if the data includes PII, PHI, or "
            "regulated content.\n"
            "3. **Review bucket policy and IAM** to confirm only authorized "
            "principals have access going forward.\n"
            "4. **Enable S3 server access logging** or CloudTrail data "
            "events for the bucket so future access is auditable.\n"
            "5. **Rotate any secrets** (API keys, tokens, credentials) that "
            "may have been stored in or referenced by the bucket."
        ),
    ),
    (
        lambda t: t.startswith("Public S3 bucket listable (empty)"),
        (
            "The S3 bucket is currently empty but **publicly listable**. "
            "Misconfiguration is exploitable as soon as objects are added "
            "— and 'empty' doesn't necessarily mean it was always empty "
            "(could indicate prior incident with cleanup).\n\n"
            ""
            "1. Apply Block Public Access at the bucket level.\n"
            "2. Audit bucket policy — confirm public access wasn't "
            "intentional.\n"
            "3. Review CloudTrail logs to confirm no historical objects "
            "existed and no unexpected access occurred.\n"
            "4. Add monitoring (e.g., AWS Config rule "
            "`s3-bucket-public-read-prohibited`) to alert on future "
            "public-access regressions."
        ),
    ),
    (
        lambda t: t.startswith("Public S3 bucket (read, not listable)"),
        (
            "The bucket responds HTTP 200 to anonymous HEAD requests but "
            "rejects directory-style listing. Individual objects may still "
            "be retrievable if their keys are guessed, leaked via logs, or "
            "discovered through other channels.\n\n"
            ""
            "1. Apply Block Public Access at the bucket level.\n"
            "2. If specific objects need to be public (e.g., website "
            "assets), prefer signed URLs or CloudFront with an Origin "
            "Access Identity instead of bucket-level public read."
        ),
    ),
    # ---- Slowloris CVE ----
    (
        lambda t: "Slowloris" in t or "CVE-2007-6750" in t,
        (
            "Slowloris is a denial-of-service attack that holds many slow "
            "HTTP connections open to exhaust the server's connection pool. "
            "Affects Apache (mpm_prefork), older Tomcat, and various legacy "
            "web servers.\n\n"
            ""
            "- **Apache:** install/enable `mod_reqtimeout` (default in 2.4+) "
            "and configure: `RequestReadTimeout header=20-40,minrate=500 "
            "body=20,minrate=500`\n"
            "- **Apache:** consider switching from `mpm_prefork` to "
            "`mpm_event` for connection scalability.\n"
            "- **Front with a CDN/WAF** — CloudFront, Cloudflare, or AWS "
            "WAF absorbs slow connections and forwards only complete "
            "requests to the origin.\n"
            "- **Migration:** Nginx has built-in slow-client mitigation "
            "and is not vulnerable to classic Slowloris."
        ),
    ),
    # ---- Unencrypted HTTP service ----
    (
        lambda t: t == "Unencrypted HTTP Service" or t.startswith("Unencrypted HTTP"),
        (
            "Service is reachable over plaintext HTTP. All traffic — "
            "including credentials, session tokens, and request payloads — "
            "is observable to anyone on the network path (ISPs, public "
            "Wi-Fi networks, intermediate routers).\n\n"
            ""
            "1. **Enable HTTPS** with a valid certificate. Let's Encrypt "
            "is free and automatable; commercial CAs for EV / wildcard "
            "certs.\n"
            "2. **Redirect all HTTP to HTTPS** via 301 permanent redirect "
            "(`return 301 https://$host$request_uri;` in nginx).\n"
            "3. **Enable HSTS** once stable on HTTPS: "
            "`Strict-Transport-Security: max-age=31536000; "
            "includeSubDomains`.\n"
            "4. **Audit clients** that connect to this endpoint to ensure "
            "they upgrade to HTTPS too — old hardcoded HTTP URLs in apps, "
            "scripts, or webhooks will break."
        ),
    ),
]


def classify_finding_remediation(title: str) -> str:
    """
    Return a specific remediation paragraph for a classified finding title.

    Matched against the output of `classify_finding_title`. Returns an
    empty string when no specific remediation is registered for the
    title; callers should fall back to a generic per-severity default.
    """
    if not title:
        return ""
    for predicate, remediation in _CLASSIFIED_REMEDIATIONS:
        try:
            if predicate(title):
                return remediation
        except Exception:
            continue
    return ""


def _is_bogus_nikto_finding(description: str) -> bool:
    """
    Detect findings that should never have been stored — nikto's
    end-of-scan stats line and the "All CGI directories 'found'"
    diagnostic warning. The parser now skips these for new scans;
    this helper is for cleaning up data stored by older versions.
    """
    if not description:
        return False
    desc = description.lower()
    if re.search(r"\d+\s+error\(s\)\s+and\s+\d+\s+item\(s\)\s+reported", desc):
        return True
    if "all cgi directories 'found'" in desc:
        return True
    return False


def reclassify_existing_finding_titles(engagement_id: int) -> Dict[str, int]:
    """
    Backfill helper for nikto findings stored under older versions.

    Two cleanup passes:
    1. DELETE bogus findings — nikto end-of-scan stats lines and the
       "All CGI directories 'found'" diagnostic — that the parser now
       correctly skips but were previously stored as findings.
    2. UPDATE titles that look like the old "Nikto: <path> - ..." dump
       format, using the v3.0.61+ classifier.

    Idempotent — running it twice on the same data is a no-op.

    Returns:
        Dict with 'updated', 'deleted', and 'skipped' counts.
    """
    from souleyez.storage.findings import FindingsManager

    fm = FindingsManager()
    findings = fm.list_findings(engagement_id, tool="nikto")
    updated = 0
    deleted = 0
    skipped = 0
    for f in findings:
        description = f.get("description") or ""
        title = f.get("title") or ""

        # Pass 1: delete obvious non-findings
        if _is_bogus_nikto_finding(description):
            try:
                fm.delete_finding(f["id"])
                deleted += 1
                continue
            except Exception:
                # If delete API isn't available, fall through and
                # at least re-title so the bogus entry is identifiable
                pass

        # Pass 2: re-title any finding whose current title doesn't match
        # what the v3.0.64 classifier produces from its description. This
        # is self-healing across classifier improvements: every backfill
        # run brings titles forward to whatever the latest classifier
        # produces, regardless of what intermediate classifier version
        # last touched them. Old-format raw-dump titles, hand-truncated
        # garbage, and stale single-word titles like "cloudflare" all
        # converge to the current classified output.
        new_title = classify_finding_title(
            description,
            path=f.get("path") or "/",
            osvdb=None,  # OSVDB not stored separately in findings table
        )
        if new_title != title:
            fm.update_finding(f["id"], title=new_title)
            updated += 1
        else:
            skipped += 1
    return {"updated": updated, "deleted": deleted, "skipped": skipped}


def _determine_severity(description: str, osvdb: str = None) -> str:
    """
    Determine finding severity based on description and OSVDB reference.
    """
    desc_lower = description.lower()

    # High severity indicators
    high_keywords = [
        "remote code execution",
        "rce",
        "command execution",
        "shell",
        "sql injection",
        "file inclusion",
        "lfi",
        "rfi",
        "arbitrary file",
        "password",
        "credentials",
        "authentication bypass",
        "backdoor",
    ]
    for keyword in high_keywords:
        if keyword in desc_lower:
            return "high"

    # Medium severity indicators
    medium_keywords = [
        "directory indexing",
        "directory listing",
        "backup file",
        "config file",
        "sensitive",
        "exposure",
        "disclosure",
        "xss",
        "cross-site",
        "injection",
        "traversal",
        "default",
        "admin",
        ".bak",
        ".old",
        ".swp",
    ]
    for keyword in medium_keywords:
        if keyword in desc_lower:
            return "medium"

    # Low severity indicators
    low_keywords = [
        "header",
        "x-frame",
        "x-content-type",
        "x-xss",
        "cookie",
        "httponly",
        "secure flag",
        "hsts",
        "content-security-policy",
        "csp",
        "clickjacking",
    ]
    for keyword in low_keywords:
        if keyword in desc_lower:
            return "low"

    # OSVDB references often indicate real issues
    if osvdb:
        return "medium"

    return "info"


def get_findings_by_severity(
    parsed: Dict[str, Any], severity: str
) -> List[Dict[str, Any]]:
    """
    Filter findings by severity level.
    """
    return [f for f in parsed.get("findings", []) if f.get("severity") == severity]


def get_high_value_findings(parsed: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Get findings that are high or medium severity.
    """
    return [
        f for f in parsed.get("findings", []) if f.get("severity") in ("high", "medium")
    ]


def generate_next_steps(
    parsed: Dict[str, Any], target: str = ""
) -> List[Dict[str, Any]]:
    """
    Generate suggested next steps based on nikto findings.

    Translates cryptic OSVDB references and generic findings into
    actionable exploitation steps.

    Args:
        parsed: Output from parse_nikto_output()
        target: Target URL for command examples

    Returns:
        List of next step dicts with title, commands, reason
    """
    next_steps = []
    findings = parsed.get("findings", [])
    base_url = target.rstrip("/") or f"http://{parsed.get('target_hostname', 'target')}"

    if not findings:
        return next_steps

    # Categorize findings
    dir_indexing = []
    backup_files = []
    config_exposure = []
    outdated_server = []
    missing_headers = []
    cgi_vulns = []
    file_inclusion = []
    injection_vulns = []
    auth_issues = []

    server = parsed.get("server", "")

    for finding in findings:
        desc = finding.get("description", "").lower()
        path = finding.get("path", "")
        osvdb = finding.get("osvdb", "")
        severity = finding.get("severity", "info")

        # Directory indexing
        if "directory indexing" in desc or "directory listing" in desc:
            dir_indexing.append({"path": path, "osvdb": osvdb})
        # Backup files
        elif any(
            kw in desc
            for kw in ["backup", ".bak", ".old", ".orig", ".save", "configuration file"]
        ):
            backup_files.append({"path": path, "desc": finding.get("description", "")})
        # Config files
        elif any(
            kw in desc
            for kw in ["config", "phpinfo", ".htaccess", ".htpasswd", "web.config"]
        ):
            config_exposure.append(
                {"path": path, "desc": finding.get("description", "")}
            )
        # Outdated server
        elif "outdated" in desc or "appears to be" in desc:
            outdated_server.append(
                {"desc": finding.get("description", ""), "server": server}
            )
        # Missing security headers
        elif any(
            kw in desc
            for kw in [
                "x-frame",
                "x-xss",
                "x-content-type",
                "httponly",
                "secure flag",
                "hsts",
                "csp",
            ]
        ):
            missing_headers.append({"desc": finding.get("description", "")})
        # CGI vulnerabilities
        elif "/cgi-bin/" in path or ".cgi" in path or "cgi" in desc:
            cgi_vulns.append(
                {"path": path, "desc": finding.get("description", ""), "osvdb": osvdb}
            )
        # File inclusion
        elif any(
            kw in desc
            for kw in ["file inclusion", "lfi", "rfi", "traversal", "arbitrary file"]
        ):
            file_inclusion.append(
                {"path": path, "desc": finding.get("description", ""), "osvdb": osvdb}
            )
        # Injection
        elif any(kw in desc for kw in ["injection", "xss", "sql", "command execution"]):
            injection_vulns.append(
                {"path": path, "desc": finding.get("description", ""), "osvdb": osvdb}
            )
        # Auth issues
        elif any(
            kw in desc
            for kw in ["authentication", "bypass", "default", "password", "credential"]
        ):
            auth_issues.append({"path": path, "desc": finding.get("description", "")})

    # Directory indexing - browse for sensitive files
    if dir_indexing:
        paths = [d["path"] for d in dir_indexing[:3]]
        next_steps.append(
            {
                "title": "Browse indexed directories for sensitive files",
                "commands": [f'curl -s "{base_url}{p}"' for p in paths]
                + [f"# Look for: passwords, configs, source code, database files"],
                "reason": f"Found {len(dir_indexing)} directory with indexing enabled - may expose sensitive files",
            }
        )

    # Backup files - download and analyze
    if backup_files:
        next_steps.append(
            {
                "title": "Download and review backup files",
                "commands": [
                    f'curl -s "{base_url}{b["path"]}" -o backup_file'
                    for b in backup_files[:3]
                ],
                "reason": f"Found {len(backup_files)} backup file(s) - may contain source code, credentials",
            }
        )

    # Config exposure - extract credentials
    if config_exposure:
        next_steps.append(
            {
                "title": "Extract credentials from exposed configs",
                "commands": [
                    f'curl -s "{base_url}{c["path"]}"' for c in config_exposure[:3]
                ],
                "reason": f"Found {len(config_exposure)} config file(s) - check for database passwords, API keys",
            }
        )

    # Outdated server - searchsploit
    if outdated_server or server:
        server_info = (
            server or outdated_server[0].get("desc", "") if outdated_server else ""
        )
        if server_info:
            next_steps.append(
                {
                    "title": f"Search for exploits for {server_info[:40]}",
                    "commands": [
                        f'searchsploit "{server_info}"',
                        f'# Or: searchsploit -w "{server_info}" for web links',
                    ],
                    "reason": f"Server version detected - check for known CVEs and public exploits",
                }
            )

    # CGI vulnerabilities
    if cgi_vulns:
        cgi_path = cgi_vulns[0]["path"]
        full_url = f"{base_url}{cgi_path}"
        next_steps.append(
            {
                "title": "Test CGI scripts for command injection",
                "commands": [
                    f'curl "{full_url}?cmd=id"',
                    f'curl "{full_url}?file=/etc/passwd"',
                    f"curl -A '() {{ :; }}; echo; /bin/id' \"{full_url}\"",
                ],
                "reason": f"Nikto found {len(cgi_vulns)} CGI issue(s) - test for injection and Shellshock",
            }
        )

    # File inclusion
    if file_inclusion:
        lfi_path = file_inclusion[0]["path"]
        next_steps.append(
            {
                "title": "Exploit file inclusion vulnerability",
                "commands": [
                    f'curl "{base_url}{lfi_path}?file=../../../etc/passwd"',
                    f'curl "{base_url}{lfi_path}?page=php://filter/convert.base64-encode/resource=index.php"',
                ],
                "reason": f"File inclusion detected - test path traversal and PHP wrappers",
            }
        )

    # Injection vulnerabilities
    if injection_vulns:
        inj = injection_vulns[0]
        next_steps.append(
            {
                "title": "Test injection vulnerability",
                "commands": [
                    f'sqlmap -u "{base_url}{inj["path"]}" --batch --risk=3 --level=5',
                ],
                "reason": f'Injection point found at {inj["path"]} - run automated testing',
            }
        )

    # Auth issues
    if auth_issues:
        next_steps.append(
            {
                "title": "Test authentication bypass",
                "commands": [
                    f"# Try: admin/admin, admin/password, root/root",
                    f'hydra -L data/wordlists/usernames_common.txt -P data/wordlists/top20_quick.txt {base_url.replace("http://", "").replace("https://", "").split("/")[0]} http-get /',
                ],
                "reason": f"Authentication issue detected - test default credentials",
            }
        )

    # Missing headers - only include if high severity findings exist
    # (headers alone are low value, but good to mention for completeness)
    high_severity = [f for f in findings if f.get("severity") in ("high", "medium")]
    if missing_headers and not high_severity:
        next_steps.append(
            {
                "title": "Report missing security headers",
                "commands": [
                    f'curl -I "{base_url}" | grep -i "x-frame\\|x-xss\\|x-content\\|strict-transport"',
                ],
                "reason": f"{len(missing_headers)} security header(s) missing - low risk but worth documenting",
            }
        )

    # If OSVDB references exist, suggest looking them up
    osvdb_refs = [f.get("osvdb") for f in findings if f.get("osvdb")]
    if osvdb_refs:
        unique_osvdb = list(set(osvdb_refs))[:3]
        next_steps.append(
            {
                "title": "Look up OSVDB references",
                "commands": [
                    f"# OSVDB is deprecated, use CVE/NVD instead",
                    f"# Search: https://cve.mitre.org/cve/search_cve_list.html",
                    f"searchsploit --cve <CVE-XXXX-XXXXX>",
                ],
                "reason": f'Found {len(unique_osvdb)} OSVDB reference(s): {", ".join(unique_osvdb)} - cross-reference with CVE database',
            }
        )

    return next_steps
