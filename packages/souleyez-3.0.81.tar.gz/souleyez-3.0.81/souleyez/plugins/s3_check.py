#!/usr/bin/env python3
"""
souleyez.plugins.s3_check - AWS S3 bucket public-access detection

Probes an S3 bucket for public read / public list misconfigurations
without using the AWS SDK or credentials. Pure HTTP only.

Probe sequence:
1. HEAD https://<bucket>.s3.<region>.amazonaws.com/
   - 200    -> bucket exists and is publicly readable
   - 403    -> bucket exists, requires auth (typical, no finding)
   - 404    -> bucket does not exist (stale CSP reference)
   - 301    -> wrong region (Location header has correct one)
2. If HEAD == 200:
   GET https://<bucket>.s3.<region>.amazonaws.com/?list-type=2
   - 200    -> publicly listable (severity scales with object count)
   - 403    -> public read of objects but listing denied

This is intentionally non-invasive: HEAD + at most one GET, no
object retrieval, no key sampling. Object names from a listable
bucket may be added in a future version.
"""

import json
import re
import time
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import urlparse

try:
    import requests
except ImportError:  # pragma: no cover - requests is a hard dep, but be defensive
    requests = None  # type: ignore

from .plugin_base import PluginBase

HELP = {
    "name": "S3 Bucket Check - Public Access Detection",
    "description": (
        "Probes an AWS S3 bucket URL for public read and public list "
        "misconfigurations using HTTP only (no AWS credentials needed).\n\n"
        "Auto-triggered when http_fingerprint extracts S3 bucket names "
        "from CSP headers. Can also be run manually against any S3 "
        "bucket URL.\n\n"
        "Findings:\n"
        "- Listable bucket with objects -> CRITICAL\n"
        "- Listable bucket but empty   -> HIGH\n"
        "- Public read, listing denied -> MEDIUM\n"
        "- Stale reference (404)       -> INFO\n"
    ),
    "usage": "souleyez jobs enqueue s3_check <bucket-url-or-hostname>",
    "examples": [
        "souleyez jobs enqueue s3_check my-bucket.s3.amazonaws.com",
        "souleyez jobs enqueue s3_check https://my-bucket.s3.us-west-2.amazonaws.com",
    ],
    "flags": [
        ["--timeout <sec>", "Request timeout per probe (default: 5)"],
    ],
    "presets": [
        {"name": "Quick S3 Check", "args": [], "desc": "HEAD + list probe"},
    ],
}

# bucket.s3.<region>.amazonaws.com  (modern)
_RE_DOTTED_REGION = re.compile(
    r"^(?P<bucket>[a-z0-9.\-]+)\.s3\.(?P<region>[a-z0-9\-]+)\.amazonaws\.com$",
    re.IGNORECASE,
)
# bucket.s3-<region>.amazonaws.com  (older)
_RE_DASH_REGION = re.compile(
    r"^(?P<bucket>[a-z0-9.\-]+)\.s3-(?P<region>[a-z0-9\-]+)\.amazonaws\.com$",
    re.IGNORECASE,
)
# bucket.s3.amazonaws.com  (legacy us-east-1)
_RE_LEGACY = re.compile(
    r"^(?P<bucket>[a-z0-9.\-]+)\.s3\.amazonaws\.com$",
    re.IGNORECASE,
)


def parse_bucket_target(target: str) -> Optional[Tuple[str, str]]:
    """
    Extract (bucket, region) from a target URL or hostname.

    Returns None if the target does not look like an S3 virtual-hosted URL.
    """
    if not target:
        return None
    s = target.strip()
    # Strip scheme if present
    parsed = urlparse(s if "://" in s else f"http://{s}")
    host = parsed.hostname or s
    host = host.lower()

    m = _RE_DOTTED_REGION.match(host)
    if m:
        return m.group("bucket"), m.group("region")
    m = _RE_DASH_REGION.match(host)
    if m:
        return m.group("bucket"), m.group("region")
    m = _RE_LEGACY.match(host)
    if m:
        return m.group("bucket"), "us-east-1"
    return None


def _classify_listing(body: str) -> Tuple[int, List[str]]:
    """
    Parse an S3 ListObjectsV2 XML response.

    Returns (object_count, sample_keys[:5]). Defensive against malformed XML —
    we don't want a parse error to mask a confirmed-public bucket.
    """
    if not body:
        return 0, []
    try:
        keys = re.findall(r"<Key>([^<]+)</Key>", body)
    except Exception:
        keys = []
    return len(keys), keys[:5]


class S3CheckPlugin(PluginBase):
    name = "S3 Check"
    tool = "s3_check"
    category = "scanning"
    HELP = HELP

    def check_tool_available(self) -> tuple:
        """Pure-Python plugin; available wherever requests is installed."""
        if requests is None:
            return False, "requests library not available"
        return True, None

    def build_command(
        self,
        target: str,
        args: List[str] = None,
        label: str = "",
        log_path: str = None,
    ):
        # Pure-Python plugin — falls through to run().
        return None

    def run(
        self,
        target: str,
        args: List[str] = None,
        label: str = "",
        log_path: str = None,
    ) -> int:
        args = args or []
        timeout = 5
        for i, arg in enumerate(args):
            if arg == "--timeout" and i + 1 < len(args):
                try:
                    timeout = max(1, int(args[i + 1]))
                except ValueError:
                    pass

        result: Dict[str, Any] = {
            "target": target,
            "bucket": None,
            "region": None,
            "head_status": None,
            "list_status": None,
            "public": False,
            "listable": False,
            "object_count": 0,
            "sample_keys": [],
            "error": None,
            "elapsed": 0.0,
        }

        parsed_target = parse_bucket_target(target)
        if not parsed_target:
            result["error"] = (
                f"Target does not look like an S3 virtual-hosted URL: {target}"
            )
            self._write_log(log_path, target, result, label)
            return 0

        bucket, region = parsed_target
        result["bucket"] = bucket
        result["region"] = region

        url = f"https://{bucket}.s3.{region}.amazonaws.com/"
        list_url = f"{url}?list-type=2"

        start = time.time()
        if requests is None:
            result["error"] = "requests library not installed"
            self._write_log(log_path, target, result, label)
            return 0

        try:
            head_resp = requests.head(
                url,
                timeout=timeout,
                allow_redirects=False,
                headers={"User-Agent": "souleyez/s3-check"},
            )
            result["head_status"] = head_resp.status_code

            if head_resp.status_code == 301:
                # Wrong region — surface the correct one for follow-up runs.
                # Modern S3 returns x-amz-bucket-region; older returns Location.
                hinted_region = head_resp.headers.get("x-amz-bucket-region")
                if hinted_region:
                    result["error"] = (
                        f"Bucket lives in region '{hinted_region}', not "
                        f"'{region}'. Re-run targeting the correct region."
                    )
                else:
                    result["error"] = (
                        "Bucket exists but in a different region (HTTP 301). "
                        "Re-run with the correct s3.<region> hostname."
                    )
            elif head_resp.status_code == 403:
                # Normal case — bucket exists and rejects anonymous access.
                result["public"] = False
            elif head_resp.status_code == 404:
                # Stale reference — CSP pointed at a non-existent bucket.
                result["public"] = False
                result["error"] = "Bucket does not exist (HTTP 404)"
            elif head_resp.status_code == 200:
                result["public"] = True
                # Try a list probe to upgrade severity
                list_resp = requests.get(
                    list_url,
                    timeout=timeout,
                    allow_redirects=False,
                    headers={"User-Agent": "souleyez/s3-check"},
                )
                result["list_status"] = list_resp.status_code
                if list_resp.status_code == 200:
                    result["listable"] = True
                    count, sample = _classify_listing(list_resp.text)
                    result["object_count"] = count
                    result["sample_keys"] = sample
            else:
                result["error"] = f"Unexpected HEAD status: {head_resp.status_code}"
        except requests.Timeout:
            result["error"] = f"Probe timed out after {timeout}s"
        except requests.RequestException as e:
            result["error"] = f"Probe failed: {e}"
        except Exception as e:
            result["error"] = f"Unexpected error: {e}"

        result["elapsed"] = round(time.time() - start, 2)
        self._write_log(log_path, target, result, label)
        return 0

    def _write_log(
        self,
        log_path: Optional[str],
        target: str,
        result: Dict[str, Any],
        label: str,
    ) -> None:
        if not log_path:
            return
        lines = [
            "=== Plugin: S3 Check ===",
            f"Target: {target}",
            f"Label: {label or ''}",
            f"Bucket: {result.get('bucket') or '(unparsed)'}",
            f"Region: {result.get('region') or '(unknown)'}",
            f"HEAD Status: {result.get('head_status')}",
        ]
        if result.get("list_status") is not None:
            lines.append(f"LIST Status: {result.get('list_status')}")
        lines.append(f"Public: {result.get('public')}")
        lines.append(f"Listable: {result.get('listable')}")
        if result.get("listable"):
            lines.append(f"Object Count: {result.get('object_count')}")
            if result.get("sample_keys"):
                lines.append("Sample Keys:")
                for k in result["sample_keys"]:
                    lines.append(f"  - {k}")
        if result.get("error"):
            lines.append(f"ERROR: {result['error']}")
        lines.append(f"Elapsed: {result.get('elapsed')}s")
        lines.append("")
        lines.append("=== JSON_RESULT ===")
        lines.append(json.dumps(result, indent=2))
        lines.append("=== END_JSON_RESULT ===")
        lines.append("")
        try:
            with open(log_path, "a", encoding="utf-8", errors="replace") as fh:
                fh.write("\n".join(lines))
        except Exception:
            pass


plugin = S3CheckPlugin()
