#!/usr/bin/env python3
"""
souleyez.plugins.origin_check - origin IP discovery / CDN bypass detection.

Probes a list of candidate IPs with a Host: header matching an in-scope
hostname, looking for IPs that respond directly with the application's
content. A direct response from a non-CDN IP means an attacker can
bypass CloudFront / WAF entirely — pure HTTP findings, no CDN protection,
DDoS amenable, exploit-payload-pass-through.

Probe sequence:
1. Baseline: GET https://<hostname>/ to capture status, content size,
   first response bytes (for shape comparison).
2. For each candidate IP that is NOT in a known CDN range:
   GET https://<ip>/ with Host: <hostname> header, TLS verify off,
   no redirect-follow.
3. Compare each probe response to baseline:
   - Same status + size within ~10% + content shape match -> CONFIRMED LEAK
   - 200/3xx but doesn't match baseline -> SUSPICIOUS (different app on
     same IP, e.g., shared hosting)
   - 403/421/connection-refused -> healthy (origin properly restricted)

This plugin is intentionally narrow: it only confirms origin reachability,
it does not exploit. Findings are evidence for the operator to remediate
(restrict origin SG to CloudFront prefix list `pl-CFCDN`).

The plugin runs in two modes:
- Manual: operator passes --ips with explicit candidate IPs.
- Auto-chain: tool_chaining gathers candidate IPs from engagement OSINT
  data and passes them via --ips.
"""

import json
import time
from hashlib import sha256
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import urlparse

try:
    import requests
    import urllib3
except ImportError:  # pragma: no cover - requests is a hard dep
    requests = None  # type: ignore
    urllib3 = None  # type: ignore

from souleyez.utils.cdn_ranges import filter_cdn_ips

from .plugin_base import PluginBase

HELP = {
    "name": "Origin IP Discovery - CDN/WAF Bypass Detection",
    "description": (
        "Probes candidate IPs with a Host: header matching the target "
        "hostname to detect IPs that respond directly with the "
        "application's content (bypassing CloudFront / WAF).\n\n"
        "Auto-triggered when http_fingerprint detects a CDN. Can also "
        "be run manually with --ips to test specific candidates.\n\n"
        "Findings:\n"
        "- Origin IP confirmed (matches baseline) -> CRITICAL\n"
        "- Suspicious response (200/3xx, different shape) -> MEDIUM\n"
        "- All candidates restricted (403/421) -> no finding\n"
    ),
    "usage": "souleyez jobs enqueue origin_check <hostname> --ips IP1,IP2,...",
    "examples": [
        "souleyez jobs enqueue origin_check api.freshpaint.io "
        "--ips 54.10.1.2,54.10.1.3",
        "souleyez jobs enqueue origin_check app.example.com --timeout 15",
    ],
    "flags": [
        ["--ips IP1,IP2,...", "Comma-separated candidate IPs to probe"],
        ["--timeout <sec>", "Request timeout per probe (default: 10)"],
        ["--scheme http|https", "Probe scheme (default: https)"],
    ],
    "presets": [
        {
            "name": "Origin Discovery",
            "args": [],
            "desc": "Host-header probe of candidate IPs",
        },
    ],
}


def _parse_args(args: List[str]) -> Dict[str, Any]:
    out: Dict[str, Any] = {
        "ips": [],
        "timeout": 10,
        "scheme": "https",
    }
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--ips" and i + 1 < len(args):
            out["ips"] = [
                ip.strip() for ip in args[i + 1].split(",") if ip.strip()
            ]
            i += 2
        elif a == "--timeout" and i + 1 < len(args):
            try:
                out["timeout"] = max(1, int(args[i + 1]))
            except ValueError:
                pass
            i += 2
        elif a == "--scheme" and i + 1 < len(args):
            v = args[i + 1].lower()
            if v in ("http", "https"):
                out["scheme"] = v
            i += 2
        else:
            i += 1
    return out


def _hostname_from_target(target: str) -> Optional[str]:
    """Extract a hostname from a target string (URL or bare hostname)."""
    if not target:
        return None
    s = target.strip()
    parsed = urlparse(s if "://" in s else f"http://{s}")
    host = parsed.hostname
    return host.lower() if host else None


def _content_signature(body: bytes, max_bytes: int = 4096) -> Dict[str, Any]:
    """
    Build a comparable signature from a response body.

    We use size + sha256 of the first 4KB. Two responses with the same
    sha256 are byte-identical at the start; close-but-not-identical
    sizes still let us detect "same app, slight variance" via a tolerance
    band in the comparator.
    """
    if not body:
        return {"size": 0, "head_sha256": ""}
    head = body[:max_bytes]
    return {
        "size": len(body),
        "head_sha256": sha256(head).hexdigest()[:32],
    }


def _shapes_match(
    baseline_sig: Dict[str, Any], probe_sig: Dict[str, Any]
) -> Tuple[bool, str]:
    """
    Decide whether a probe response matches the baseline closely enough
    to call it a confirmed origin leak.

    Returns (is_match, reason).
    """
    if not baseline_sig or not probe_sig:
        return False, "missing signature"
    if baseline_sig.get("head_sha256") and (
        baseline_sig["head_sha256"] == probe_sig.get("head_sha256")
    ):
        return True, "identical head bytes"
    b_size = baseline_sig.get("size") or 0
    p_size = probe_sig.get("size") or 0
    if b_size > 0 and p_size > 0:
        ratio = min(b_size, p_size) / max(b_size, p_size)
        if ratio >= 0.85:
            return True, f"size within 15% ({b_size} vs {p_size})"
    return False, "shape diverges"


class OriginCheckPlugin(PluginBase):
    name = "Origin Check"
    tool = "origin_check"
    category = "reconnaissance"
    HELP = HELP

    def check_tool_available(self) -> tuple:
        if requests is None:
            return False, "requests library not available"
        return True, None

    def build_command(
        self,
        target: str,
        args: List[str] = None,
        label: str = "",
        log_path: str = None,
    ):
        return None  # pure-Python plugin

    def run(
        self,
        target: str,
        args: List[str] = None,
        label: str = "",
        log_path: str = None,
    ) -> int:
        args = args or []
        opts = _parse_args(args)

        result: Dict[str, Any] = {
            "target": target,
            "hostname": None,
            "scheme": opts["scheme"],
            "candidates_supplied": len(opts["ips"]),
            "candidates_after_cdn_filter": 0,
            "cdn_filtered": [],
            "baseline": None,
            "probes": [],
            "leaks": [],
            "suspicious": [],
            "error": None,
            "elapsed": 0.0,
        }

        hostname = _hostname_from_target(target)
        if not hostname:
            result["error"] = f"Target is not a hostname or URL: {target}"
            self._write_log(log_path, result)
            return 0
        result["hostname"] = hostname

        if requests is None:
            result["error"] = "requests library not installed"
            self._write_log(log_path, result)
            return 0

        if urllib3 is not None:
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

        if not opts["ips"]:
            result["error"] = (
                "No candidate IPs supplied. Pass --ips IP1,IP2,... "
                "or invoke via auto-chain."
            )
            self._write_log(log_path, result)
            return 0

        non_cdn, cdn_filtered = filter_cdn_ips(opts["ips"])
        result["candidates_after_cdn_filter"] = len(non_cdn)
        result["cdn_filtered"] = [
            {"ip": ip, "provider": prov} for ip, prov in cdn_filtered
        ]

        start = time.time()

        baseline_url = f"{opts['scheme']}://{hostname}/"
        try:
            r = requests.get(
                baseline_url,
                timeout=opts["timeout"],
                allow_redirects=False,
                verify=False,
                headers={"User-Agent": "souleyez/origin-check"},
            )
            sig = _content_signature(r.content)
            result["baseline"] = {
                "url": baseline_url,
                "status": r.status_code,
                **sig,
            }
        except requests.RequestException as e:
            result["baseline"] = {"url": baseline_url, "error": str(e)}

        if not non_cdn:
            result["elapsed"] = round(time.time() - start, 2)
            self._write_log(log_path, result)
            return 0

        baseline_sig = result.get("baseline") or {}
        for ip in non_cdn:
            probe = {
                "ip": ip,
                "status": None,
                "size": None,
                "head_sha256": None,
                "matches_baseline": False,
                "match_reason": "",
                "error": None,
            }
            probe_url = f"{opts['scheme']}://{ip}/"
            try:
                r = requests.get(
                    probe_url,
                    timeout=opts["timeout"],
                    allow_redirects=False,
                    verify=False,
                    headers={
                        "Host": hostname,
                        "User-Agent": "souleyez/origin-check",
                    },
                )
                sig = _content_signature(r.content)
                probe["status"] = r.status_code
                probe["size"] = sig["size"]
                probe["head_sha256"] = sig["head_sha256"]
                if r.status_code in (200, 301, 302, 307, 308):
                    is_match, reason = _shapes_match(baseline_sig, sig)
                    probe["matches_baseline"] = is_match
                    probe["match_reason"] = reason
                    if is_match:
                        result["leaks"].append({**probe})
                    else:
                        result["suspicious"].append({**probe})
            except requests.Timeout:
                probe["error"] = f"Timeout after {opts['timeout']}s"
            except requests.RequestException as e:
                probe["error"] = str(e)
            except Exception as e:
                probe["error"] = f"Unexpected: {e}"
            result["probes"].append(probe)

        result["elapsed"] = round(time.time() - start, 2)
        self._write_log(log_path, result)
        return 0

    def _write_log(self, log_path: Optional[str], result: Dict[str, Any]) -> None:
        if not log_path:
            return
        lines = [
            "=== Plugin: Origin Check ===",
            f"Target hostname: {result.get('hostname') or '(unparsed)'}",
            f"Scheme: {result.get('scheme')}",
            f"Candidates supplied: {result.get('candidates_supplied')}",
            f"After CDN filter: {result.get('candidates_after_cdn_filter')}",
        ]
        if result.get("cdn_filtered"):
            lines.append("CDN-filtered IPs:")
            for entry in result["cdn_filtered"]:
                lines.append(f"  - {entry['ip']} ({entry['provider']})")
        bl = result.get("baseline") or {}
        if bl:
            lines.append(
                f"Baseline {bl.get('url')}: "
                f"status={bl.get('status')} size={bl.get('size')}"
                + (f" error={bl['error']}" if bl.get("error") else "")
            )
        if result.get("leaks"):
            lines.append("CONFIRMED ORIGIN LEAKS:")
            for leak in result["leaks"]:
                lines.append(
                    f"  - {leak['ip']} status={leak['status']} "
                    f"size={leak['size']} match={leak['match_reason']}"
                )
        if result.get("suspicious"):
            lines.append("Suspicious responses (200/3xx, divergent shape):")
            for s in result["suspicious"]:
                lines.append(
                    f"  - {s['ip']} status={s['status']} size={s['size']} "
                    f"reason={s['match_reason']}"
                )
        if result.get("error"):
            lines.append(f"ERROR: {result['error']}")
        lines.append(f"Elapsed: {result.get('elapsed')}s")
        lines.append("")
        lines.append("=== JSON_RESULT ===")
        lines.append(json.dumps(result, indent=2))
        lines.append("=== END_JSON_RESULT ===")
        lines.append("")
        try:
            with open(log_path, "a", encoding="utf-8", errors="replace") as fh:
                fh.write("\n".join(lines))
        except Exception:
            pass


plugin = OriginCheckPlugin()
