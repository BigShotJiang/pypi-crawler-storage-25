#!/usr/bin/env python3
"""
souleyez.utils.cdn_ranges - known CDN IP range lookup.

Used by origin_check (and any future origin-discovery work) to filter
out IPs that belong to known CDN edges before probing. CDN edge IPs
are not yours — they belong to the CDN provider — and probing them
produces noise (uniform-response 403s on every path).

Static range lists are intentionally minimal. For full coverage,
fetch live ranges from:
- AWS:        https://ip-ranges.amazonaws.com/ip-ranges.json
- Cloudflare: https://www.cloudflare.com/ips-v4
- Fastly:     https://api.fastly.com/public-ip-list

A future enhancement could refresh these on a daily TTL. For now we
cover the most common ranges seen in customer engagements (Freshpaint
is on AWS CloudFront, most customers also see Cloudflare).
"""

import ipaddress
from typing import List, Optional, Tuple

# Each entry: (CIDR, provider name).
# Curated from public AWS/Cloudflare published ranges as of 2026-Q2.
# Coverage is "good enough to filter the most common false-positives"
# rather than exhaustive — operators with niche CDNs can extend this.
_CDN_RANGES_RAW: List[Tuple[str, str]] = [
    # AWS CloudFront — top global ranges (subset; enough to catch
    # the Freshpaint-style edge IPs we kept seeing in engagement #11)
    ("3.5.140.0/22", "AWS CloudFront"),
    ("3.168.0.0/14", "AWS CloudFront"),
    ("13.32.0.0/15", "AWS CloudFront"),
    ("13.224.0.0/14", "AWS CloudFront"),
    ("13.249.0.0/16", "AWS CloudFront"),
    ("18.64.0.0/14", "AWS CloudFront"),
    ("18.154.0.0/15", "AWS CloudFront"),
    ("18.160.0.0/15", "AWS CloudFront"),
    ("18.164.0.0/15", "AWS CloudFront"),
    ("18.172.0.0/15", "AWS CloudFront"),
    ("18.238.0.0/15", "AWS CloudFront"),
    ("18.244.0.0/15", "AWS CloudFront"),
    ("52.46.0.0/18", "AWS CloudFront"),
    ("52.84.0.0/15", "AWS CloudFront"),
    ("52.124.128.0/17", "AWS CloudFront"),
    ("54.182.0.0/16", "AWS CloudFront"),
    ("54.192.0.0/16", "AWS CloudFront"),
    ("54.230.0.0/16", "AWS CloudFront"),
    ("54.239.128.0/18", "AWS CloudFront"),
    ("54.239.192.0/19", "AWS CloudFront"),
    ("99.84.0.0/16", "AWS CloudFront"),
    ("99.86.0.0/16", "AWS CloudFront"),
    ("100.20.0.0/14", "AWS CloudFront"),
    ("108.138.0.0/15", "AWS CloudFront"),
    ("108.156.0.0/14", "AWS CloudFront"),
    ("130.176.0.0/16", "AWS CloudFront"),
    ("143.204.0.0/16", "AWS CloudFront"),
    ("204.246.164.0/22", "AWS CloudFront"),
    ("204.246.168.0/22", "AWS CloudFront"),
    ("204.246.174.0/23", "AWS CloudFront"),
    ("204.246.176.0/20", "AWS CloudFront"),
    ("205.251.192.0/19", "AWS CloudFront"),
    ("205.251.249.0/24", "AWS CloudFront"),
    ("205.251.250.0/23", "AWS CloudFront"),
    ("205.251.252.0/23", "AWS CloudFront"),
    ("205.251.254.0/24", "AWS CloudFront"),
    ("216.137.32.0/19", "AWS CloudFront"),
    # Cloudflare
    ("103.21.244.0/22", "Cloudflare"),
    ("103.22.200.0/22", "Cloudflare"),
    ("103.31.4.0/22", "Cloudflare"),
    ("104.16.0.0/13", "Cloudflare"),
    ("104.24.0.0/14", "Cloudflare"),
    ("108.162.192.0/18", "Cloudflare"),
    ("131.0.72.0/22", "Cloudflare"),
    ("141.101.64.0/18", "Cloudflare"),
    ("162.158.0.0/15", "Cloudflare"),
    ("172.64.0.0/13", "Cloudflare"),
    ("173.245.48.0/20", "Cloudflare"),
    ("188.114.96.0/20", "Cloudflare"),
    ("190.93.240.0/20", "Cloudflare"),
    ("197.234.240.0/22", "Cloudflare"),
    ("198.41.128.0/17", "Cloudflare"),
    # Fastly
    ("23.235.32.0/20", "Fastly"),
    ("43.249.72.0/22", "Fastly"),
    ("103.244.50.0/24", "Fastly"),
    ("103.245.222.0/23", "Fastly"),
    ("103.245.224.0/24", "Fastly"),
    ("104.156.80.0/20", "Fastly"),
    ("151.101.0.0/16", "Fastly"),
    ("157.52.64.0/18", "Fastly"),
    ("167.82.0.0/17", "Fastly"),
    ("167.82.128.0/20", "Fastly"),
    ("167.82.160.0/20", "Fastly"),
    ("167.82.224.0/20", "Fastly"),
    ("172.111.64.0/18", "Fastly"),
    ("185.31.16.0/22", "Fastly"),
    ("199.27.72.0/21", "Fastly"),
    ("199.232.0.0/16", "Fastly"),
]


def _build_network_index() -> List[Tuple[ipaddress.IPv4Network, str]]:
    out: List[Tuple[ipaddress.IPv4Network, str]] = []
    for cidr, name in _CDN_RANGES_RAW:
        try:
            out.append((ipaddress.ip_network(cidr, strict=False), name))
        except ValueError:
            continue
    return out


_CDN_NETWORKS = _build_network_index()


def is_cdn_edge(ip: str) -> Tuple[bool, Optional[str]]:
    """
    Check whether an IP belongs to a known CDN edge range.

    Returns (True, provider_name) if the IP matches any tracked range,
    else (False, None). Invalid input returns (False, None) — never
    raises.
    """
    if not ip:
        return False, None
    try:
        addr = ipaddress.ip_address(ip.strip())
    except ValueError:
        return False, None
    if not isinstance(addr, ipaddress.IPv4Address):
        return False, None
    for net, name in _CDN_NETWORKS:
        if addr in net:
            return True, name
    return False, None


def filter_cdn_ips(ips: List[str]) -> Tuple[List[str], List[Tuple[str, str]]]:
    """
    Split an IP list into (non_cdn, cdn_with_provider).

    The non_cdn list is what origin_check actually probes — those are
    the candidate origins. The cdn_with_provider list is preserved for
    audit/reporting so operators can see what was filtered and why.
    """
    non_cdn: List[str] = []
    filtered: List[Tuple[str, str]] = []
    for ip in ips:
        is_cdn, provider = is_cdn_edge(ip)
        if is_cdn:
            filtered.append((ip, provider or "Unknown CDN"))
        else:
            non_cdn.append(ip)
    return non_cdn, filtered
