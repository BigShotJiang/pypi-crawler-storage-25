#!/usr/bin/env python3
"""
Origin Check handler.

Parses origin_check plugin output and creates findings for confirmed
or suspicious CDN-bypass origin IPs. Mirrors the s3_check handler shape
since both are pure-Python plugins emitting JSON_RESULT blocks.

Severity mapping:
- Confirmed leak (matches_baseline=true)  -> critical
- Suspicious response (200/3xx divergent) -> medium
- All candidates restricted               -> no finding
"""

import json
import logging
import os
import re
from typing import Any, Dict, Optional

import click

from souleyez.engine.job_status import (STATUS_DONE, STATUS_ERROR,
                                        STATUS_NO_RESULTS, STATUS_WARNING)
from souleyez.handlers.base import BaseToolHandler

logger = logging.getLogger(__name__)


def _parse_log(log_path: str) -> Dict[str, Any]:
    if not log_path or not os.path.exists(log_path):
        return {}
    try:
        with open(log_path, "r", encoding="utf-8", errors="replace") as f:
            text = f.read()
    except Exception:
        return {}
    m = re.search(
        r"=== JSON_RESULT ===\n(.+?)\n=== END_JSON_RESULT ===",
        text,
        re.DOTALL,
    )
    if not m:
        return {}
    try:
        return json.loads(m.group(1))
    except json.JSONDecodeError:
        return {}


class OriginCheckHandler(BaseToolHandler):
    """Handler for origin_check plugin jobs."""

    tool_name = "origin_check"
    display_name = "Origin Check"

    has_error_handler = True
    has_warning_handler = True
    has_no_results_handler = True
    has_done_handler = True

    def parse_job(
        self,
        engagement_id: int,
        log_path: str,
        job: Dict[str, Any],
        host_manager: Optional[Any] = None,
        findings_manager: Optional[Any] = None,
        credentials_manager: Optional[Any] = None,
    ) -> Dict[str, Any]:
        try:
            if (
                not log_path
                or not os.path.exists(log_path)
                or os.path.getsize(log_path) == 0
            ):
                return {
                    "tool": self.tool_name,
                    "status": STATUS_NO_RESULTS,
                    "summary": "Empty output (plugin produced no log)",
                }

            parsed = _parse_log(log_path)
            target = job.get("target", "")
            hostname = parsed.get("hostname")

            if not parsed or not hostname:
                err = parsed.get("error") if parsed else "Unparseable origin_check output"
                return {
                    "tool": self.tool_name,
                    "status": STATUS_WARNING,
                    "target": target,
                    "summary": err or "Could not parse target as hostname",
                }

            err = parsed.get("error")
            leaks = parsed.get("leaks") or []
            suspicious = parsed.get("suspicious") or []
            probes = parsed.get("probes") or []
            candidates_after_filter = int(
                parsed.get("candidates_after_cdn_filter") or 0
            )

            from souleyez.storage.findings import FindingsManager

            fm = findings_manager or FindingsManager()
            findings_added = 0

            host_id = self._upsert_host(engagement_id, hostname, host_manager)

            for leak in leaks:
                evidence = self._format_evidence(
                    parsed, leak, severity="confirmed"
                )
                title = (
                    f"CDN bypass: origin IP {leak['ip']} serves {hostname} "
                    f"directly"
                )
                description = (
                    f"IP {leak['ip']} responded to a Host: {hostname} probe "
                    f"with content matching the baseline response from "
                    f"{hostname} (reason: {leak.get('match_reason')}). "
                    f"This means the origin server accepts requests directly, "
                    f"bypassing CloudFront/WAF protections. An attacker can "
                    f"DDoS the origin, send WAF-blocked payloads, or scan it "
                    f"without rate limiting. Restrict the origin's security "
                    f"group / firewall to the CloudFront managed prefix list "
                    f"(`com.amazonaws.global.cloudfront.origin-facing`) and "
                    f"rotate any leaked TLS certificate."
                )
                if host_id:
                    fm.add_finding(
                        engagement_id=engagement_id,
                        host_id=host_id,
                        title=title,
                        finding_type="cdn_bypass",
                        severity="critical",
                        description=description,
                        tool=self.tool_name,
                        path=f"{leak['ip']} (Host: {hostname})",
                        evidence=evidence,
                    )
                    findings_added += 1

            for s in suspicious:
                evidence = self._format_evidence(parsed, s, severity="suspicious")
                title = (
                    f"Suspicious response from {s['ip']} for Host: {hostname}"
                )
                description = (
                    f"IP {s['ip']} responded HTTP {s['status']} to a "
                    f"Host: {hostname} probe but the response shape did not "
                    f"match the baseline ({s.get('match_reason')}). Likely a "
                    f"shared host serving a different application, but worth "
                    f"a manual review — the IP is reachable from the public "
                    f"internet and accepts arbitrary Host: headers."
                )
                if host_id:
                    fm.add_finding(
                        engagement_id=engagement_id,
                        host_id=host_id,
                        title=title,
                        finding_type="cdn_bypass_suspicious",
                        severity="medium",
                        description=description,
                        tool=self.tool_name,
                        path=f"{s['ip']} (Host: {hostname})",
                        evidence=evidence,
                    )
                    findings_added += 1

            if err and not leaks and not suspicious:
                return {
                    "tool": self.tool_name,
                    "status": STATUS_WARNING,
                    "target": target,
                    "summary": err,
                    "findings_added": findings_added,
                }

            if leaks:
                summary = (
                    f"{len(leaks)} confirmed origin leak(s), "
                    f"{len(suspicious)} suspicious, "
                    f"{candidates_after_filter} candidate(s) probed"
                )
                status = STATUS_DONE
            elif suspicious:
                summary = (
                    f"{len(suspicious)} suspicious response(s), "
                    f"no confirmed leak; "
                    f"{candidates_after_filter} candidate(s) probed"
                )
                status = STATUS_DONE
            elif candidates_after_filter == 0:
                summary = (
                    "All candidates filtered as CDN edges; "
                    "no probes performed"
                )
                status = STATUS_NO_RESULTS
            elif probes and all(
                p.get("status") in (403, 421) or p.get("error") for p in probes
            ):
                summary = (
                    f"{candidates_after_filter} candidate(s) probed; "
                    "all properly restricted (403/421/refused)"
                )
                status = STATUS_NO_RESULTS
            else:
                summary = (
                    f"{candidates_after_filter} candidate(s) probed; "
                    "no leaks detected"
                )
                status = STATUS_NO_RESULTS

            return {
                "tool": self.tool_name,
                "status": status,
                "target": target,
                "hostname": hostname,
                "leaks_count": len(leaks),
                "suspicious_count": len(suspicious),
                "candidates_probed": candidates_after_filter,
                "findings_added": findings_added,
                "summary": summary,
            }

        except Exception as e:
            logger.error(f"Error parsing origin_check job: {e}")
            return {
                "tool": self.tool_name,
                "status": STATUS_ERROR,
                "error": str(e),
                "summary": f"Parse error: {e}",
            }

    def _upsert_host(
        self, engagement_id: int, hostname: str, host_manager: Optional[Any]
    ) -> Optional[int]:
        if host_manager is None:
            from souleyez.storage.hosts import HostManager

            host_manager = HostManager()
        try:
            rec = host_manager.add_or_update_host(
                engagement_id,
                {
                    "ip": hostname,
                    "hostname": hostname,
                    "status": "up",
                    "notes": "Hostname tested for CDN bypass via origin_check",
                },
            )
            if isinstance(rec, int):
                return rec
            if isinstance(rec, dict):
                return rec.get("id")
            found = host_manager.get_host_by_ip(engagement_id, hostname)
            return found["id"] if found else None
        except Exception as e:
            logger.debug(f"Origin check: host upsert failed: {e}")
            return None

    def _format_evidence(
        self, parsed: Dict[str, Any], probe: Dict[str, Any], severity: str
    ) -> str:
        baseline = parsed.get("baseline") or {}
        lines = [
            f"Hostname: {parsed.get('hostname')}",
            f"Probed IP: {probe.get('ip')}",
            f"Probe status: {probe.get('status')}",
            f"Probe size: {probe.get('size')} bytes",
            f"Match reason: {probe.get('match_reason')}",
            f"Baseline status: {baseline.get('status')}",
            f"Baseline size: {baseline.get('size')} bytes",
            f"Severity: {severity}",
        ]
        cdn_filtered = parsed.get("cdn_filtered") or []
        if cdn_filtered:
            lines.append(f"CDN-filtered IPs (not probed): {len(cdn_filtered)}")
        return "\n".join(lines)

    def display_done(
        self,
        job: Dict[str, Any],
        log_path: str,
        show_all: bool = False,
        show_passwords: bool = False,
    ) -> None:
        parsed = _parse_log(log_path)
        click.echo(click.style("=" * 70, fg="cyan"))
        click.echo(click.style("ORIGIN IP DISCOVERY", bold=True, fg="cyan"))
        click.echo(click.style("=" * 70, fg="cyan"))
        click.echo()
        click.echo(f"  Hostname: {parsed.get('hostname')}")
        click.echo(
            f"  Candidates supplied: {parsed.get('candidates_supplied')} "
            f"(after CDN filter: {parsed.get('candidates_after_cdn_filter')})"
        )
        leaks = parsed.get("leaks") or []
        suspicious = parsed.get("suspicious") or []
        if leaks:
            click.echo(
                click.style(
                    f"  CONFIRMED ORIGIN LEAKS: {len(leaks)}",
                    fg="red",
                    bold=True,
                )
            )
            for leak in leaks:
                click.echo(
                    f"    - {leak['ip']} status={leak['status']} "
                    f"size={leak['size']} ({leak['match_reason']})"
                )
        if suspicious:
            click.echo(
                click.style(
                    f"  Suspicious: {len(suspicious)}", fg="yellow", bold=True
                )
            )
            for s in suspicious:
                click.echo(
                    f"    - {s['ip']} status={s['status']} size={s['size']}"
                )
        if not leaks and not suspicious:
            click.echo(click.style("  No origin leaks detected", fg="green"))
        click.echo()

    def display_warning(
        self,
        job: Dict[str, Any],
        log_path: str,
        log_content: Optional[str] = None,
    ) -> None:
        parsed = _parse_log(log_path)
        click.echo(click.style("=" * 70, fg="yellow"))
        click.echo(click.style("[WARNING] ORIGIN CHECK", bold=True, fg="yellow"))
        click.echo(click.style("=" * 70, fg="yellow"))
        click.echo()
        if parsed.get("error"):
            click.echo(f"  {parsed['error']}")
        else:
            click.echo("  Probe completed with warnings. Check raw logs.")
        click.echo()

    def display_error(
        self,
        job: Dict[str, Any],
        log_path: str,
        log_content: Optional[str] = None,
    ) -> None:
        click.echo(click.style("=" * 70, fg="red"))
        click.echo(click.style("[ERROR] ORIGIN CHECK FAILED", bold=True, fg="red"))
        click.echo(click.style("=" * 70, fg="red"))
        click.echo("  Probe failed - see raw logs for details (press 'r')")
        click.echo()

    def display_no_results(
        self,
        job: Dict[str, Any],
        log_path: str,
    ) -> None:
        parsed = _parse_log(log_path)
        click.echo(click.style("=" * 70, fg="cyan"))
        click.echo(click.style("ORIGIN IP DISCOVERY", bold=True, fg="cyan"))
        click.echo(click.style("=" * 70, fg="cyan"))
        click.echo()
        click.echo(f"  Hostname: {parsed.get('hostname') or '(unknown)'}")
        click.echo(
            click.style(
                "  Result: no origin leaks detected", fg="green", bold=True
            )
        )
        click.echo()
