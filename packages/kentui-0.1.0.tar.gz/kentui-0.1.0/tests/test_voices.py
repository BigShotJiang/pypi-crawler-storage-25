"""Tests for kentui.cli.voices — voice subcommands (mocking kenkui library)."""

from __future__ import annotations

from argparse import Namespace
from io import StringIO
from unittest.mock import MagicMock, patch

import pytest


def _make_voice_info(name="alba", source="builtin", gender="Female", accent="British",
                     dataset=None, speaker_id=None, excluded=False, description=None):
    from kenkui.services.voice_service import VoiceInfo
    return VoiceInfo(
        name=name,
        source=source,
        gender=gender,
        accent=accent,
        dataset=dataset,
        speaker_id=speaker_id,
        description=description or f"{name} ({source})",
        display_label=f"{name} ({source})",
        excluded=excluded,
    )


# ---------------------------------------------------------------------------
# cmd_voices_list
# ---------------------------------------------------------------------------


class TestCmdVoicesList:
    def test_prints_table_with_voices(self, capsys):
        from kentui.cli.voices import cmd_voices_list

        voices = [
            _make_voice_info("alba", "builtin", "Female", "British"),
            _make_voice_info("cosette", "builtin", "Female", "American"),
        ]

        with patch("kenkui.list_voices", return_value=voices):
            cmd_voices_list(Namespace(gender=None, accent=None, dataset=None, source=None))

        out, _ = capsys.readouterr()
        assert "alba" in out
        assert "cosette" in out

    def test_no_voices_prints_warning(self, capsys):
        from kentui.cli.voices import cmd_voices_list

        with patch("kenkui.list_voices", return_value=[]):
            cmd_voices_list(Namespace(gender=None, accent=None, dataset=None, source=None))

        out, _ = capsys.readouterr()
        assert "No voices match" in out

    def test_passes_filters_to_kenkui(self):
        from kentui.cli.voices import cmd_voices_list

        with patch("kenkui.list_voices", return_value=[]) as mock_list:
            cmd_voices_list(Namespace(gender="Female", accent="British", dataset=None, source="builtin"))

        mock_list.assert_called_once_with(gender="Female", accent="British", dataset=None, source="builtin")


# ---------------------------------------------------------------------------
# cmd_voices_exclude / include
# ---------------------------------------------------------------------------


class TestCmdVoicesExclude:
    def test_exclude_prints_confirmation(self, capsys):
        from kentui.cli.voices import cmd_voices_exclude
        from kenkui.services.voice_service import ExcludeResult

        mock_result = ExcludeResult(excluded_voices=["alba"], warning=None)

        with patch("kenkui.exclude_voice", return_value=mock_result):
            cmd_voices_exclude(Namespace(voice="alba"))

        out, _ = capsys.readouterr()
        assert "alba" in out
        assert "excluded" in out.lower()

    def test_exclude_prints_warning_when_pool_depleted(self, capsys):
        from kentui.cli.voices import cmd_voices_exclude
        from kenkui.services.voice_service import ExcludeResult

        mock_result = ExcludeResult(
            excluded_voices=["alba"],
            warning="All Female voices have been excluded from the pool.",
        )

        with patch("kenkui.exclude_voice", return_value=mock_result):
            cmd_voices_exclude(Namespace(voice="alba"))

        out, _ = capsys.readouterr()
        assert "Warning" in out or "warning" in out.lower() or "All Female" in out


class TestCmdVoicesInclude:
    def test_include_prints_confirmation(self, capsys):
        from kentui.cli.voices import cmd_voices_include
        from kenkui.services.voice_service import IncludeResult

        mock_result = IncludeResult(excluded_voices=[])

        with patch("kenkui.include_voice", return_value=mock_result):
            cmd_voices_include(Namespace(voice="alba"))

        out, _ = capsys.readouterr()
        assert "alba" in out
        assert "restored" in out.lower()


# ---------------------------------------------------------------------------
# cmd_voices_audition
# ---------------------------------------------------------------------------


class TestCmdVoicesAudition:
    def test_audition_calls_kenkui_and_opens_player(self):
        from kentui.cli.voices import cmd_voices_audition
        from kenkui.services.voice_service import AudioPreviewResult

        mock_result = AudioPreviewResult(audio_path="/tmp/preview.wav", duration_ms=3000)

        with (
            patch("kenkui.audition_voice", return_value=mock_result),
            patch("subprocess.Popen") as mock_popen,
        ):
            cmd_voices_audition(Namespace(voice="alba", text=None))

        mock_popen.assert_called_once()
        call_args = mock_popen.call_args[0][0]
        assert "/tmp/preview.wav" in call_args

    def test_audition_uses_custom_text(self):
        from kentui.cli.voices import cmd_voices_audition
        from kenkui.services.voice_service import AudioPreviewResult

        mock_result = AudioPreviewResult(audio_path="/tmp/preview.wav", duration_ms=1000)
        custom_text = "Hello world, this is a test."

        with (
            patch("kenkui.audition_voice", return_value=mock_result) as mock_aud,
            patch("subprocess.Popen"),
        ):
            cmd_voices_audition(Namespace(voice="cosette", text=custom_text))

        mock_aud.assert_called_once()
        assert mock_aud.call_args[1]["text"] == custom_text or mock_aud.call_args[0][1] == custom_text


# ---------------------------------------------------------------------------
# _voices_interactive
# ---------------------------------------------------------------------------


class TestVoicesInteractive:
    def test_displays_table_without_client_arg(self, capsys):
        from kentui.cli.voices import _voices_interactive

        voices = [_make_voice_info("alba"), _make_voice_info("cosette")]

        with patch("kenkui.list_voices", return_value=voices):
            _voices_interactive()

        out, _ = capsys.readouterr()
        assert "alba" in out

    def test_shows_dim_message_when_no_voices(self, capsys):
        from kentui.cli.voices import _voices_interactive

        with patch("kenkui.list_voices", return_value=[]):
            _voices_interactive()

        out, _ = capsys.readouterr()
        assert "No voices available" in out

    def test_handles_kenkui_exception_gracefully(self, capsys):
        from kentui.cli.voices import _voices_interactive

        with patch("kenkui.list_voices", side_effect=RuntimeError("disk failure")):
            _voices_interactive()

        out, _ = capsys.readouterr()
        assert "Could not load voices" in out or "disk failure" in out


# ---------------------------------------------------------------------------
# cmd_voices_download
# ---------------------------------------------------------------------------


class TestCmdVoicesDownload:
    def test_returns_0_on_success(self):
        from kentui.cli.voices import cmd_voices_download
        from kenkui.services.download_service import DownloadResult

        mock_result = DownloadResult(success=True, path="/voices", message="Download complete")

        with patch("kenkui.download_voice", return_value=mock_result):
            result = cmd_voices_download(Namespace(force=False))

        assert result == 0

    def test_returns_1_on_failure(self, capsys):
        from kentui.cli.voices import cmd_voices_download
        from kenkui.services.download_service import DownloadResult

        mock_result = DownloadResult(success=False, path="/voices", message="Network error")

        with patch("kenkui.download_voice", return_value=mock_result):
            result = cmd_voices_download(Namespace(force=False))

        assert result == 1
        out, _ = capsys.readouterr()
        assert "Network error" in out
