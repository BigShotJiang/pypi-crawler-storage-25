"""Tests for kentui.cli.add — _build_processing_config, _load_config, _run_job_with_progress."""

from __future__ import annotations

from argparse import Namespace
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest


# ---------------------------------------------------------------------------
# _load_config
# ---------------------------------------------------------------------------


class TestLoadConfig:
    def test_returns_app_config(self, default_app_config, fake_epub):
        from kentui.cli.add import _load_config
        import kenkui

        with patch("kenkui.load_config", return_value=default_app_config):
            args = Namespace(config=None, output=None, apostrophe_mode=None)
            cfg = _load_config(args)

        assert cfg is default_app_config

    def test_output_override_updates_default_output_dir(self, default_app_config, tmp_path):
        from kentui.cli.add import _load_config

        with patch("kenkui.load_config", return_value=default_app_config):
            args = Namespace(config=None, output=str(tmp_path), apostrophe_mode=None)
            cfg = _load_config(args)

        assert cfg.default_output_dir == tmp_path

    def test_apostrophe_mode_override(self, default_app_config):
        from kentui.cli.add import _load_config
        from kenkui.utils import ApostropheMode

        with patch("kenkui.load_config", return_value=default_app_config):
            args = Namespace(config=None, output=None, apostrophe_mode="keep")
            cfg = _load_config(args)

        assert cfg.apostrophe_mode == ApostropheMode.KEEP

    def test_no_override_leaves_config_unchanged(self, default_app_config):
        from kentui.cli.add import _load_config

        with patch("kenkui.load_config", return_value=default_app_config) as mock_load:
            args = Namespace(config="myconfig", output=None, apostrophe_mode=None)
            cfg = _load_config(args)

        mock_load.assert_called_once_with("myconfig")


# ---------------------------------------------------------------------------
# _build_processing_config
# ---------------------------------------------------------------------------


def _make_job_kwargs(ebook_path, **overrides) -> dict:
    """Minimal valid job_kwargs for _build_processing_config."""
    base = {
        "ebook_path": str(ebook_path),
        "output_path": None,
        "voice": "alba",
        "chapter_selection": {"preset": "content-only", "included": []},
        "speaker_voices": {},
        "annotated_chapters_path": None,
        "chapter_voices": {},
    }
    base.update(overrides)
    return base


class TestBuildProcessingConfig:
    def test_basic_single_voice_job(self, default_app_config, fake_epub):
        from kentui.cli.add import _build_processing_config

        job_kwargs = _make_job_kwargs(fake_epub)
        cfg = _build_processing_config(job_kwargs, default_app_config)

        assert cfg.voice == "alba"
        assert cfg.ebook_path == fake_epub
        assert cfg.speaker_voices == {}
        assert cfg.annotated_chapters_path is None

    def test_voice_from_job_kwargs(self, default_app_config, fake_epub):
        from kentui.cli.add import _build_processing_config

        job_kwargs = _make_job_kwargs(fake_epub, voice="cosette")
        cfg = _build_processing_config(job_kwargs, default_app_config)

        assert cfg.voice == "cosette"

    def test_voice_falls_back_to_app_config_default(self, tmp_path):
        from kentui.cli.add import _build_processing_config
        from kenkui.models import AppConfig

        ebook = tmp_path / "book.epub"
        ebook.write_bytes(b"fake")
        app_config = AppConfig(default_voice="fantine")
        job_kwargs = _make_job_kwargs(ebook, voice=None)
        cfg = _build_processing_config(job_kwargs, app_config)

        assert cfg.voice == "fantine"

    def test_preset_chapter_filter_content_only(self, default_app_config, fake_epub):
        from kentui.cli.add import _build_processing_config
        from kenkui.chapter_filter import FilterOperation

        job_kwargs = _make_job_kwargs(fake_epub, chapter_selection={"preset": "content-only", "included": []})
        cfg = _build_processing_config(job_kwargs, default_app_config)

        assert len(cfg.chapter_filters) == 1
        assert cfg.chapter_filters[0].type == "preset"
        assert cfg.chapter_filters[0].value == "content-only"

    def test_manual_chapter_selection_uses_index_filters(self, default_app_config, fake_epub):
        from kentui.cli.add import _build_processing_config
        from kenkui.chapter_filter import FilterOperation

        job_kwargs = _make_job_kwargs(fake_epub, chapter_selection={
            "preset": "custom",
            "included": [0, 2, 5],
        })
        cfg = _build_processing_config(job_kwargs, default_app_config)

        assert all(f.type == "index" for f in cfg.chapter_filters)
        values = {f.value for f in cfg.chapter_filters}
        assert values == {"0", "2", "5"}

    def test_annotated_chapters_path_set(self, default_app_config, fake_epub, tmp_path):
        from kentui.cli.add import _build_processing_config

        cache_file = tmp_path / "nlp.json"
        cache_file.write_text("{}")
        job_kwargs = _make_job_kwargs(fake_epub, annotated_chapters_path=str(cache_file))
        cfg = _build_processing_config(job_kwargs, default_app_config)

        assert cfg.annotated_chapters_path == cache_file

    def test_speaker_voices_passed_through(self, default_app_config, fake_epub):
        from kentui.cli.add import _build_processing_config

        job_kwargs = _make_job_kwargs(fake_epub, speaker_voices={"Alice": "cosette", "Bob": "jean"})
        cfg = _build_processing_config(job_kwargs, default_app_config)

        assert cfg.speaker_voices == {"Alice": "cosette", "Bob": "jean"}

    def test_job_quality_overrides_app_config(self, fake_epub):
        from kentui.cli.add import _build_processing_config
        from kenkui.models import AppConfig

        app_config = AppConfig(pause_line_ms=800, temp=0.7)
        job_kwargs = _make_job_kwargs(fake_epub, job_pause_line_ms=1200, job_temp=0.9)
        cfg = _build_processing_config(job_kwargs, app_config)

        assert cfg.pause_line_ms == 1200
        assert cfg.temp == 0.9

    def test_apostrophe_mode_from_job_kwargs(self, default_app_config, fake_epub):
        from kentui.cli.add import _build_processing_config
        from kenkui.utils import ApostropheMode

        job_kwargs = _make_job_kwargs(fake_epub, job_apostrophe_mode="keep")
        cfg = _build_processing_config(job_kwargs, default_app_config)

        assert cfg.apostrophe_mode == ApostropheMode.KEEP

    def test_apostrophe_mode_defaults_to_expand_contractions(self, default_app_config, fake_epub):
        from kentui.cli.add import _build_processing_config
        from kenkui.utils import ApostropheMode

        job_kwargs = _make_job_kwargs(fake_epub)
        cfg = _build_processing_config(job_kwargs, default_app_config)

        assert cfg.apostrophe_mode == ApostropheMode.EXPAND_CONTRACTIONS

    def test_output_path_defaults_to_ebook_parent(self, default_app_config, fake_epub):
        from kentui.cli.add import _build_processing_config

        job_kwargs = _make_job_kwargs(fake_epub, output_path=None)
        cfg = _build_processing_config(job_kwargs, default_app_config)

        assert cfg.output_path == fake_epub.parent

    def test_explicit_output_path_used(self, default_app_config, fake_epub, tmp_path):
        from kentui.cli.add import _build_processing_config

        out_dir = tmp_path / "audiobooks"
        job_kwargs = _make_job_kwargs(fake_epub, output_path=str(out_dir))
        cfg = _build_processing_config(job_kwargs, default_app_config)

        assert cfg.output_path == out_dir


# ---------------------------------------------------------------------------
# _run_job_with_progress
# ---------------------------------------------------------------------------


class TestRunJobWithProgress:
    def _make_config(self, fake_epub):
        config = MagicMock()
        config.output_path = fake_epub.parent
        return config

    def test_returns_0_on_success(self, fake_epub):
        from kentui.cli.add import _run_job_with_progress

        config = self._make_config(fake_epub)

        with patch("kenkui.run_job", return_value=True) as mock_run:
            result = _run_job_with_progress(config)

        assert result == 0
        mock_run.assert_called_once()

    def test_returns_1_on_failure(self, fake_epub):
        from kentui.cli.add import _run_job_with_progress

        config = self._make_config(fake_epub)

        with patch("kenkui.run_job", return_value=False):
            result = _run_job_with_progress(config)

        assert result == 1

    def test_returns_1_on_exception(self, fake_epub):
        from kentui.cli.add import _run_job_with_progress

        config = self._make_config(fake_epub)

        with patch("kenkui.run_job", side_effect=RuntimeError("TTS failed")):
            result = _run_job_with_progress(config)

        assert result == 1


# ---------------------------------------------------------------------------
# cmd_add — headless mode
# ---------------------------------------------------------------------------


class TestCmdAddHeadless:
    def test_headless_runs_job_and_returns_exit_code(self, tmp_path, default_app_config):
        from kentui.cli.add import cmd_add

        ebook = tmp_path / "book.epub"
        ebook.write_bytes(b"fake")
        args = Namespace(config="myconfig", output=None, apostrophe_mode=None, book=ebook)

        with (
            patch("kenkui.load_config", return_value=default_app_config),
            patch("kenkui.services.job_service.build_headless_job_kwargs", return_value={
                "ebook_path": str(ebook),
                "output_path": None,
                "voice": "alba",
                "chapter_selection": {"preset": "content-only", "included": []},
                "speaker_voices": {},
                "annotated_chapters_path": None,
                "chapter_voices": {},
            }),
            patch("kenkui.run_job", return_value=True),
        ):
            result = cmd_add(args)

        assert result == 0

    def test_headless_returns_1_on_failure(self, tmp_path, default_app_config):
        from kentui.cli.add import cmd_add

        ebook = tmp_path / "book.epub"
        ebook.write_bytes(b"fake")
        args = Namespace(config="myconfig", output=None, apostrophe_mode=None, book=ebook)

        with (
            patch("kenkui.load_config", return_value=default_app_config),
            patch("kenkui.services.job_service.build_headless_job_kwargs", return_value={
                "ebook_path": str(ebook),
                "output_path": None,
                "voice": "alba",
                "chapter_selection": {"preset": "content-only", "included": []},
                "speaker_voices": {},
                "annotated_chapters_path": None,
                "chapter_voices": {},
            }),
            patch("kenkui.run_job", return_value=False),
        ):
            result = cmd_add(args)

        assert result == 1
