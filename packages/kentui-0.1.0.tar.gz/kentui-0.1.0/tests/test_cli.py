"""Tests for the kentui CLI entry point (help, version, subcommands)."""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

EBOOK_EXTENSIONS = {".epub", ".mobi", ".fb2", ".azw", ".azw3", ".azw4"}

_PROJECT_ROOT = Path(__file__).parent.parent
_SRC_DIR = _PROJECT_ROOT / "src"


def _run(*args, **kwargs) -> subprocess.CompletedProcess:
    env = os.environ.copy()
    existing = env.get("PYTHONPATH", "")
    env["PYTHONPATH"] = f"{_SRC_DIR}:{existing}" if existing else str(_SRC_DIR)
    return subprocess.run(
        [sys.executable, "-m", "kentui", *args],
        capture_output=True, text=True,
        env=env,
        cwd=str(_PROJECT_ROOT),
        **kwargs,
    )


class TestHelpAndVersion:
    def test_help_exits_0(self):
        r = _run("--help")
        assert r.returncode == 0
        assert "kentui" in r.stdout.lower()

    def test_help_shows_key_flags(self):
        r = _run("--help")
        for flag in ("--config", "--output", "--verbose"):
            assert flag in r.stdout, f"{flag} missing from --help"

    def test_version_exits_0(self):
        r = _run("--version")
        assert r.returncode == 0
        combined = r.stdout + r.stderr
        assert "kentui" in combined.lower()

    def test_subcommands_shown_in_help(self):
        r = _run("--help")
        for cmd in ("add", "config", "voices", "cache"):
            assert cmd in r.stdout, f"Sub-command '{cmd}' missing from --help"

    def test_add_help_exits_0(self):
        r = _run("add", "--help")
        assert r.returncode == 0

    def test_config_help_exits_0(self):
        r = _run("config", "--help")
        assert r.returncode == 0

    def test_voices_help_exits_0(self):
        r = _run("voices", "--help")
        assert r.returncode == 0

    def test_cache_help_exits_0(self):
        r = _run("cache", "--help")
        assert r.returncode == 0

    def test_voices_list_help_exits_0(self):
        r = _run("voices", "list", "--help")
        assert r.returncode == 0


class TestEbookExtensions:
    def test_ebook_extension_set(self):
        from kentui.__main__ import EBOOK_EXTENSIONS
        assert ".epub" in EBOOK_EXTENSIONS
        assert ".mobi" in EBOOK_EXTENSIONS

    def test_bare_epub_detected_as_book_invocation(self):
        import sys
        from unittest.mock import patch
        from kentui.__main__ import _is_bare_book_invocation

        with patch.object(sys, "argv", ["kentui", "book.epub"]):
            assert _is_bare_book_invocation() is True

    def test_subcommand_not_detected_as_book_invocation(self):
        import sys
        from unittest.mock import patch
        from kentui.__main__ import _is_bare_book_invocation

        with patch.object(sys, "argv", ["kentui", "add", "book.epub"]):
            assert _is_bare_book_invocation() is False

    def test_txt_file_not_detected_as_book(self):
        import sys
        from unittest.mock import patch
        from kentui.__main__ import _is_bare_book_invocation

        with patch.object(sys, "argv", ["kentui", "notes.txt"]):
            assert _is_bare_book_invocation() is False
