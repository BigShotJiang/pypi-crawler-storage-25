"""CLI subcommand: ``kentui voices`` — list and manage available voices."""

from __future__ import annotations

import sys
from pathlib import Path

from rich.console import Console
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn
from rich.table import Table

console = Console()

DEFAULT_AUDITION_TEXT = (
    "The rain in Spain stays mainly in the plain. "
    "How wonderful it is to simply speak and be heard."
)


def _player_command() -> str:
    return "open" if sys.platform == "darwin" else "xdg-open"


def _preview_path(voice_name: str) -> Path:
    return Path(f"/tmp/kenkui-{voice_name}-preview.wav")


def _voice_table(voices) -> Table:
    """Build a Rich table from a list of VoiceInfo objects."""
    table = Table(title="Available Voices", show_header=True, header_style="bold cyan")
    table.add_column("Name", style="bold", min_width=20)
    table.add_column("Source", min_width=12)
    table.add_column("Gender", min_width=8)
    table.add_column("Accent", min_width=22)
    table.add_column("Dataset", min_width=6)

    source_style = {
        "compiled": "green",
        "builtin": "blue",
        "uncompiled": "yellow",
    }

    for v in voices:
        src = v.source
        style = source_style.get(src, "")
        table.add_row(
            v.name,
            f"[{style}]{src}[/{style}]" if style else src,
            v.gender or "—",
            v.accent or "—",
            v.dataset or "—",
        )

    return table


# ---------------------------------------------------------------------------
# Top-level subcommands
# ---------------------------------------------------------------------------


def cmd_voices_list(args) -> None:
    """List all available voices with metadata."""
    import kenkui

    voices = kenkui.list_voices(
        gender=getattr(args, "gender", None),
        accent=getattr(args, "accent", None),
        dataset=getattr(args, "dataset", None),
        source=getattr(args, "source", None),
    )

    if not voices:
        console.print("[yellow]No voices match the specified filters.[/yellow]")
        return

    console.print(_voice_table(voices))
    console.print(f"\n[dim]{len(voices)} voice(s) listed.[/dim]")


def cmd_voices_fetch(args) -> None:
    """Download uncompiled custom voices from a HuggingFace repo."""
    import os
    import kenkui

    hf_repo = getattr(args, "repo", None) or os.environ.get("KENKUI_VOICES_REPO", "")
    if not hf_repo:
        console.print(
            "[red]No HuggingFace repo specified.[/red]\n"
            "Set KENKUI_VOICES_REPO env var or pass --repo <user/repo-name>."
        )
        sys.exit(1)

    patterns = getattr(args, "patterns", None)

    console.print(f"Fetching voices from [bold]{hf_repo}[/bold]…")

    with Progress(SpinnerColumn(), TextColumn("{task.description}"), console=console) as prog:
        task = prog.add_task("Downloading…", total=None)

        def _cb(pct: int, msg: str) -> None:
            prog.update(task, description=msg)

        result = kenkui.fetch_voice(repo_id=hf_repo, patterns=patterns, progress_callback=_cb)

    if not result.success:
        console.print(f"[red]Fetch failed: {result.message}[/red]")
        sys.exit(1)

    console.print(f"[green]Done! Run [bold]kentui voices list[/bold] to see the new voices.[/green]")


def cmd_voices_download(args) -> int:
    """Download compiled voices from HuggingFace."""
    import kenkui

    force = getattr(args, "force", False)
    console.print("Downloading voices from HuggingFace…")

    with Progress(SpinnerColumn(), BarColumn(), TextColumn("{task.description}"), console=console) as prog:
        task = prog.add_task("Starting…", total=100)

        def _cb(pct: int, msg: str) -> None:
            prog.update(task, completed=pct, description=msg)

        result = kenkui.download_voice(force=force, progress_callback=_cb)

    if not result.success:
        console.print(f"[red]Download failed: {result.message}[/red]")
        return 1

    console.print("[green]Done.[/green]")
    return 0


def cmd_voices_exclude(args) -> None:
    """Add a voice to the excluded-from-auto-assignment list."""
    import kenkui

    voice_name: str = args.voice
    result = kenkui.exclude_voice(voice_name)
    if result.warning:
        console.print(f"[yellow]Warning: {result.warning}[/yellow]")
    console.print(f"[green]'{voice_name}' excluded from auto-assignment pool.[/green]")


def cmd_voices_include(args) -> None:
    """Remove a voice from the excluded list, restoring it to auto-assignment."""
    import kenkui

    voice_name: str = args.voice
    kenkui.include_voice(voice_name)
    console.print(f"[green]'{voice_name}' restored to auto-assignment pool.[/green]")


def cmd_voices_cast(args) -> None:
    """Display character roster for a book from the NLP cache (fuzzy title match)."""
    import json
    from kenkui.config import CONFIG_DIR

    query: str = getattr(args, "title", "").lower().strip()
    cache_dir = CONFIG_DIR / "nlp_cache"

    if not cache_dir.exists():
        console.print("[yellow]No NLP cache found. Run a multi-voice job first.[/yellow]")
        return

    cache_files = list(cache_dir.glob("*.json"))
    if not cache_files:
        console.print("[yellow]No NLP cache entries found.[/yellow]")
        return

    # Score each cache file by title match against the first chapter's title
    best_file = None
    best_score = -1

    for cf in cache_files:
        try:
            data = json.loads(cf.read_text())
        except Exception:
            continue
        chapters = data.get("chapters", [])
        title_text = " ".join(
            ch.get("title", "") for ch in chapters[:5]
        ).lower()
        if query and query in title_text:
            score = title_text.count(query)
            if score > best_score:
                best_score = score
                best_file = (cf, data)

    if best_file is None:
        # Fall back: show most recent
        if not query:
            cache_files.sort(key=lambda p: p.stat().st_mtime, reverse=True)
            try:
                data = json.loads(cache_files[0].read_text())
                best_file = (cache_files[0], data)
            except Exception:
                pass

    if best_file is None:
        console.print(f"[yellow]No NLP cache entry matching '{query}'.[/yellow]")
        return

    _, data = best_file
    characters = data.get("characters", [])
    chapters = data.get("chapters", [])
    book_label = chapters[0].get("title", "Unknown") if chapters else "Unknown"

    if not characters:
        console.print(f"[yellow]No characters found in cache for '{book_label}'.[/yellow]")
        return

    table = Table(title=f"Character Roster — {book_label}", show_header=True, box=None)
    table.add_column("Character", style="bold", min_width=30)
    table.add_column("Mentions", min_width=10)

    for char in sorted(characters, key=lambda c: -(c.get("mention_count") or 0)):
        char_id = char.get("character_id") or char.get("display_name", "")
        display = char.get("display_name") or char_id
        count = char.get("mention_count") or 0
        table.add_row(display, str(count))

    console.print(table)
    console.print(f"\n[dim]{len(characters)} character(s) in NLP cache.[/dim]")


def cmd_voices_audition(args) -> None:
    """Synthesize a short voice preview and open it in the system audio player."""
    import subprocess
    import kenkui

    voice_name: str = args.voice
    text: str = getattr(args, "text", None) or DEFAULT_AUDITION_TEXT

    preview_text = text[:60] + ("…" if len(text) > 60 else "")
    console.print(
        f"Synthesizing preview for [bold]{voice_name}[/bold]: [dim]\"{preview_text}\"[/dim]"
    )

    with Progress(SpinnerColumn(), TextColumn("{task.description}"), console=console) as prog:
        task = prog.add_task("Synthesizing…", total=None)

        def _cb(pct: int, msg: str) -> None:
            prog.update(task, description=msg)

        try:
            result = kenkui.audition_voice(voice_name, text=text, progress_callback=_cb)
        except Exception as exc:
            console.print(f"[red]Audition failed: {exc}[/red]")
            return

    console.print(f"[green]Preview saved to {result.audio_path}[/green]")

    player = _player_command()
    try:
        subprocess.Popen([player, result.audio_path])
    except Exception as exc:
        console.print(
            f"[yellow]Could not open system player ({exc}). Play manually: {result.audio_path}[/yellow]"
        )


# ---------------------------------------------------------------------------
# TUI — interactive voice manager
# ---------------------------------------------------------------------------


def _voices_interactive() -> None:
    """Display voice list inline (no sys.exit). Called from confirmation screen."""
    import kenkui

    try:
        voices = kenkui.list_voices()
    except Exception as exc:
        console.print(f"[red]Could not load voices: {exc}[/red]")
        return

    if not voices:
        console.print("[dim]No voices available.[/dim]")
        return

    console.print(_voice_table(voices))
    console.print(f"\n[dim]{len(voices)} voice(s) listed.[/dim]")


def _tui_execute(prompt):
    """Execute an InquirerPy prompt. Extracted for test monkeypatching."""
    return prompt.execute()


def _do_tui_audition(voice_name: str) -> None:
    """Synthesize a preview from within the TUI."""
    import subprocess
    import kenkui

    console.print(f"\n[yellow]Synthesizing preview for [bold]{voice_name}[/bold]…[/yellow]")

    with Progress(SpinnerColumn(), TextColumn("{task.description}"), console=console) as prog:
        task = prog.add_task("Synthesizing…", total=None)

        def _cb(pct: int, msg: str) -> None:
            prog.update(task, description=msg)

        try:
            result = kenkui.audition_voice(voice_name, text=DEFAULT_AUDITION_TEXT, progress_callback=_cb)
        except Exception as exc:
            console.print(f"[red]Audition failed: {exc}[/red]")
            return

    console.print(f"[green]Saved to {result.audio_path}[/green]")
    try:
        subprocess.run([_player_command(), result.audio_path], check=False)
    except Exception as exc:
        console.print(f"[yellow]Could not play audio: {exc}[/yellow]")


def _tui_voice_actions(voice_name: str) -> None:
    """Per-voice action sub-menu. Loops until user chooses Back."""
    from InquirerPy import inquirer
    import kenkui

    while True:
        meta = kenkui.get_voice(voice_name)
        excluded = meta.excluded if meta else False

        console.print()
        console.rule(f"[bold]{voice_name}[/bold]", style="dim")
        if meta:
            table = Table(show_header=False, box=None, padding=(0, 2))
            table.add_column("Field", style="dim", width=14)
            table.add_column("Value")
            table.add_row("Source", meta.source or "?")
            table.add_row("Gender", meta.gender or "?")
            table.add_row("Accent", meta.accent or "?")
            if meta.dataset:
                table.add_row("Dataset", meta.dataset)
            if meta.speaker_id:
                table.add_row("Speaker ID", meta.speaker_id)
            pool_status = "[yellow]excluded[/yellow]" if excluded else "[green]in pool[/green]"
            table.add_row("Pool status", pool_status)
            console.print(table)
        console.print()

        in_pool = not excluded
        pool_label = "Exclude from pool" if in_pool else "Include in pool"

        choices = [
            {"name": "Audition  (play preview)", "value": "audition"},
            {"name": pool_label, "value": "toggle"},
            {"name": "← Back to browse list", "value": "back"},
        ]

        action = _tui_execute(inquirer.select(
            message=f"Action for {voice_name}",
            choices=choices,
            instruction="(↑↓ to move, Enter to confirm)",
        ))

        if action == "audition":
            _do_tui_audition(voice_name)
            return

        elif action == "toggle":
            if in_pool:
                try:
                    result = kenkui.exclude_voice(voice_name)
                    console.print(f"[yellow]'{voice_name}' excluded from pool.[/yellow]")
                    if result.warning:
                        console.print(f"[yellow]{result.warning}[/yellow]")
                except Exception as exc:
                    console.print(f"[red]Failed to exclude: {exc}[/red]")
            else:
                try:
                    kenkui.include_voice(voice_name)
                    console.print(f"[green]'{voice_name}' restored to pool.[/green]")
                except Exception as exc:
                    console.print(f"[red]Failed to include: {exc}[/red]")

        elif action == "back":
            return


def _tui_browse() -> None:
    """Browse all voices with fuzzy search; drill into action sub-menu on select."""
    from InquirerPy import inquirer
    import kenkui

    while True:
        try:
            voices = kenkui.list_voices()
        except Exception as exc:
            console.print(f"[red]Failed to load voices: {exc}[/red]")
            return

        choices = []
        for v in sorted(voices, key=lambda x: x.name.lower()):
            pool_tag = " [excl]" if v.excluded else ""
            desc = v.description or f"{v.gender or '?'} · {v.accent or '?'}"
            label = f"{v.name:<22} {desc}{pool_tag}"
            choices.append({"name": label, "value": v.name})
        choices.append({"name": "← Back to main menu", "value": "__back__"})

        selected = _tui_execute(inquirer.fuzzy(
            message="Browse voices  (type to filter by name / accent / gender)",
            choices=choices,
            instruction="(type to filter, Enter to select, Ctrl-C to cancel)",
        ))

        if selected == "__back__":
            return

        _tui_voice_actions(selected)


def _tui_pool() -> None:
    """Show excluded voices and offer bulk-restore via checkbox."""
    from InquirerPy import inquirer
    import kenkui

    try:
        voices = kenkui.list_voices()
    except Exception as exc:
        console.print(f"[red]Failed to load voices: {exc}[/red]")
        return

    excluded = [v.name for v in voices if v.excluded]

    console.print()
    if not excluded:
        console.print("[green]No voices are currently excluded from the pool.[/green]")
        console.print("[dim]Use Browse & audition to exclude individual voices.[/dim]")
        console.print()
        return

    console.print(f"[bold]Excluded voices ({len(excluded)}):[/bold]")
    for v in excluded:
        console.print(f"  • {v}")
    console.print()

    choices = [{"name": v, "value": v, "enabled": False} for v in excluded]
    to_restore = _tui_execute(inquirer.checkbox(
        message="Select voices to restore to pool (Space to toggle, Enter to confirm):",
        choices=choices,
        instruction="(Space=toggle, Enter=confirm, Ctrl-C=cancel)",
    ))

    if not to_restore:
        return

    for v in sorted(to_restore):
        try:
            kenkui.include_voice(v)
            console.print(f"[green]'{v}' restored to pool.[/green]")
        except Exception as exc:
            console.print(f"[red]Failed to restore '{v}': {exc}[/red]")
    console.print()


def _tui_cast_lookup() -> None:
    """Interactive cast lookup — prompt for book title, display character roster."""
    from InquirerPy import inquirer
    from argparse import Namespace

    title = _tui_execute(inquirer.text(
        message="Book title (fuzzy match):",
        instruction="(enter part of the book title)",
    )).strip()

    if not title:
        return

    console.print()
    cmd_voices_cast(Namespace(title=title))
    console.print()


def cmd_voices_tui(args) -> None:
    """Interactive TUI for voice management (launched by `kentui voices` with no subcommand)."""
    from InquirerPy import inquirer

    console.rule("[bold]kentui — Voice Manager[/bold]")
    console.print()

    while True:
        action = _tui_execute(inquirer.select(
            message="What would you like to do?",
            choices=[
                {"name": "Browse & audition voices", "value": "browse"},
                {"name": "Manage exclusion pool", "value": "pool"},
                {"name": "Look up book cast", "value": "cast"},
                {"name": "Exit", "value": "exit"},
            ],
            instruction="(↑↓ to move, Enter to select)",
        ))

        if action == "browse":
            _tui_browse()
        elif action == "pool":
            _tui_pool()
        elif action == "cast":
            _tui_cast_lookup()
        elif action == "exit":
            break

    console.print()
    console.print("[dim]Bye.[/dim]")


__all__ = [
    "cmd_voices_list",
    "cmd_voices_fetch",
    "cmd_voices_download",
    "cmd_voices_exclude",
    "cmd_voices_include",
    "cmd_voices_cast",
    "cmd_voices_audition",
    "cmd_voices_tui",
    "DEFAULT_AUDITION_TEXT",
    "_player_command",
    "_preview_path",
    "_tui_execute",
    "_voices_interactive",
]
