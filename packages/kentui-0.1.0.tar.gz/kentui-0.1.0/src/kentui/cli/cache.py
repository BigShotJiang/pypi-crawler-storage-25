"""Cache management CLI commands."""
from __future__ import annotations

import shutil
from pathlib import Path


def _get_cache_dirs() -> list[Path]:
    """Return the list of kenkui cache directories to manage."""
    import os
    xdg_cache = os.environ.get("XDG_CACHE_HOME", "")
    base = Path(xdg_cache) if xdg_cache else Path.home() / ".cache"
    return [base / "kenkui"]


def cmd_cache(args) -> None:
    """Clear kenkui cache files."""
    from rich.console import Console
    from rich.prompt import Confirm

    console = Console()
    confirmed = getattr(args, "yes", False)
    dirs = [d for d in _get_cache_dirs() if d.exists()]

    if not dirs:
        console.print("[dim]No cache directories found.[/dim]")
        return

    total_size = sum(
        f.stat().st_size
        for d in dirs
        for f in d.rglob("*")
        if f.is_file()
    )
    size_mb = total_size / (1024 * 1024)

    console.print(f"Cache directories: {', '.join(str(d) for d in dirs)}")
    console.print(f"Total size: [bold]{size_mb:.1f} MB[/bold]")

    if not confirmed:
        confirmed = Confirm.ask("Clear all cache files?", default=False)

    if confirmed:
        for d in dirs:
            shutil.rmtree(d, ignore_errors=True)
        console.print("[green]✓ Cache cleared.[/green]")
    else:
        console.print("[dim]Cancelled.[/dim]")
