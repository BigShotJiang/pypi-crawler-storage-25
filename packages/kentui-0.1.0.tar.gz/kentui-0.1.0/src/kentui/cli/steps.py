"""Steps CLI — parse / attribute / generate pipeline commands calling kenkui directly."""
from __future__ import annotations

import sys
from pathlib import Path


def cmd_step(command: str, args) -> int:
    """Dispatch a single pipeline step command."""
    book: Path = args.book
    if not book.exists():
        print(f"Error: file not found: {book}", file=sys.stderr)
        return 1

    config_path = getattr(args, "config", None)
    output = getattr(args, "output", None)

    if command == "parse":
        return _cmd_parse(book, config_path)
    elif command == "attribute":
        return _cmd_attribute(book, config_path)
    elif command == "generate":
        return _cmd_generate(book, config_path, output)
    else:
        print(f"Unknown step: {command}", file=sys.stderr)
        return 1


def _cmd_parse(book: Path, config_path: str | None) -> int:
    """Stage 1-2: scan entities and cache the character roster."""
    from rich.console import Console
    from rich.progress import Progress, SpinnerColumn, TextColumn
    import kenkui

    console = Console()
    received: list[tuple[int, str]] = []

    def _cb(pct: int, msg: str) -> None:
        received.append((pct, msg))

    with Progress(SpinnerColumn(), TextColumn("{task.description}"), console=console) as prog:
        task = prog.add_task("Scanning…", total=None)
        try:
            result = kenkui.fast_scan(str(book), config_path=config_path, progress_callback=_cb)
        except FileNotFoundError as exc:
            console.print(f"[red]{exc}[/red]")
            return 1
        prog.update(task, description=f"[green]Done — {len(result.characters)} characters found[/green]")

    console.print(f"[bold]Characters found:[/bold] {len(result.characters)}")
    for c in result.characters[:10]:
        console.print(f"  {c.display_name} ({c.mention_count} mentions)")
    if len(result.characters) > 10:
        console.print(f"  … and {len(result.characters) - 10} more")
    return 0


def _cmd_attribute(book: Path, config_path: str | None) -> int:
    """Stage 3-4: run quote attribution using a cached roster."""
    from rich.console import Console
    from rich.progress import Progress, SpinnerColumn, TextColumn
    import kenkui

    console = Console()

    def _cb(pct: int, msg: str) -> None:
        pass

    with Progress(SpinnerColumn(), TextColumn("{task.description}"), console=console) as prog:
        task = prog.add_task("Attributing dialogue…", total=None)
        try:
            # fast_scan with full attribution — uses cached roster if available
            result = kenkui.fast_scan(str(book), config_path=config_path, progress_callback=_cb)
        except FileNotFoundError as exc:
            console.print(f"[red]{exc}[/red]")
            return 1
        prog.update(task, description="[green]Attribution complete[/green]")

    console.print(f"[bold]Characters attributed:[/bold] {len(result.characters)}")
    return 0


def _cmd_generate(book: Path, config_path: str | None, output: str | None) -> int:
    """TTS + stitch: generate the audiobook from a cached NLP result."""
    from rich.console import Console
    from rich.progress import Progress, BarColumn, TextColumn, TimeRemainingColumn
    import kenkui

    console = Console()
    config = kenkui.load_config(config_path)

    output_path = Path(output) if output else None

    from kenkui.models import ProcessingConfig, FilterOperation

    cfg = ProcessingConfig(
        voice=config.default_voice,
        ebook_path=book,
        output_path=output_path or book.parent,
        workers=config.workers,
        m4b_bitrate=config.m4b_bitrate,
        verbose=config.verbose,
    )

    with Progress(
        TextColumn("[bold blue]{task.description}"),
        BarColumn(),
        TextColumn("{task.percentage:>3.0f}%"),
        TimeRemainingColumn(),
        console=console,
    ) as prog:
        task = prog.add_task("Generating audiobook…", total=100)

        def _progress(pct: float, chapter: str, eta: int) -> None:
            prog.update(task, completed=pct, description=chapter or "Processing…")

        success = kenkui.run_job(cfg, progress_callback=_progress)

    if success:
        console.print("[bold green]✓ Audiobook generated successfully.[/bold green]")
        return 0
    else:
        console.print("[red]✗ Generation failed.[/red]")
        return 1
