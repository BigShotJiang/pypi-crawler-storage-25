"""kentui add — interactive wizard and in-process job runner.

Entry points
------------
cmd_add(args)   kentui add book.epub [-c config]

Modes
-----
Interactive  book given, no -c:
    Wizard walks through chapters → narration mode → voice → output dir,
    then runs the job in-process with a Rich progress bar.

Headless  book given AND -c given:
    Loads config, runs job using defaults with a Rich progress bar.
    Exit 0 on success, 1 on failure.
"""

from __future__ import annotations

import sys
from pathlib import Path



# ---------------------------------------------------------------------------
# Back-navigation support
# ---------------------------------------------------------------------------


def _wizard_execute(prompt):
    """Execute an InquirerPy prompt and return its value."""
    return prompt.execute()

from rich.console import Console
from rich.progress import BarColumn, Progress, SpinnerColumn, TextColumn, TimeElapsedColumn
from rich.table import Table

console = Console()


# ---------------------------------------------------------------------------
# Validator (replaces InquirerPy NumberValidator to fix cursor-positioning bug)
# ---------------------------------------------------------------------------


class _RangeValidator:
    """Validate numeric text input within optional min/max bounds.

    Implements both __call__ (so InquirerPy 0.3.x's Validator.from_callable
    path works) and validate(document) for prompt_toolkit duck-typing.
    prompt_toolkit re-raises ValidationError raised inside from_callable, so
    custom per-value messages are preserved.
    """

    def __init__(self, min_val=None, max_val=None, float_ok=False, allow_blank=False):
        self._min = min_val
        self._max = max_val
        self._float_ok = float_ok
        self._allow_blank = allow_blank

    def __call__(self, value: str) -> bool:
        from prompt_toolkit.validation import ValidationError as _PTKValidationError
        text = (value or "").strip()
        if not text:
            if self._allow_blank:
                return True
            raise _PTKValidationError(message="Value is required.", cursor_position=0)
        try:
            val = float(text) if self._float_ok else int(text)
        except ValueError:
            raise _PTKValidationError(
                message=f"Enter a {'decimal' if self._float_ok else 'whole'} number.",
                cursor_position=len(value or ""),
            )
        if self._min is not None and val < self._min:
            raise _PTKValidationError(message=f"Minimum value is {self._min}.", cursor_position=len(value or ""))
        if self._max is not None and val > self._max:
            raise _PTKValidationError(message=f"Maximum value is {self._max}.", cursor_position=len(value or ""))
        return True

    def validate(self, document) -> None:
        self(document.text)


# ---------------------------------------------------------------------------
# Config loading
# ---------------------------------------------------------------------------


def _load_config(args):
    """Load AppConfig from args, applying any CLI flag overrides."""
    import kenkui

    config_name = getattr(args, "config", None)
    cfg = kenkui.load_config(config_name)

    output = getattr(args, "output", None)
    if output:
        cfg = cfg.model_copy(update={"default_output_dir": Path(output).expanduser().resolve()})

    apostrophe_mode = getattr(args, "apostrophe_mode", None)
    if apostrophe_mode is not None:
        from kenkui.utils import ApostropheMode
        cfg = cfg.model_copy(update={"apostrophe_mode": ApostropheMode(apostrophe_mode)})

    return cfg


# ---------------------------------------------------------------------------
# Voice helpers
# ---------------------------------------------------------------------------


def _build_voice_choices() -> list[dict]:
    """Return InquirerPy-compatible choice list for voice selection (local registry)."""
    from kenkui.voice_registry import get_registry

    choices: list[dict] = []
    registry = get_registry()

    compiled = registry.filter(source="compiled")
    if compiled:
        choices.append({"name": "── Compiled voices ──────────────────────", "value": "__sep__", "disabled": True})
        for v in compiled:
            choices.append({"name": v.display_label, "value": v.name})

    builtins = registry.filter(source="builtin")
    if builtins:
        choices.append({"name": "── Built-in voices ──────────────────────", "value": "__sep__", "disabled": True})
        for v in builtins:
            choices.append({"name": v.display_label, "value": v.name})

    uncompiled = registry.filter(source="uncompiled")
    if uncompiled:
        choices.append({"name": "── Custom voices ────────────────────────", "value": "__sep__", "disabled": True})
        for v in uncompiled:
            choices.append({"name": v.display_label, "value": v.name})

    choices.append({"name": "Custom path or hf:// URL…", "value": "__custom__"})
    return choices


def _prompt_voice(default: str = "alba", message: str = "Select voice:") -> str:
    """Prompt the user to select a voice; returns voice string."""
    from InquirerPy import inquirer

    choices = _build_voice_choices()
    voice = _wizard_execute(inquirer.fuzzy(
        message=message,
        choices=choices,
        default=default,
        max_height="40%",
    ))

    if voice == "__custom__":
        voice = _wizard_execute(
            inquirer.text(message="Enter file path or hf:// URL:")
        ).strip()

    return voice


def _check_hf_auth(voice: str) -> None:
    """If the voice requires HuggingFace auth, prompt for token if needed."""
    from kenkui.huggingface_auth import is_custom_voice
    from InquirerPy import inquirer

    if not is_custom_voice(voice):
        return

    HF_TOKEN_URL = "https://huggingface.co/settings/tokens"

    try:
        from kenkui.services.auth_service import get_hf_status
        import kenkui

        status = get_hf_status()
        if status.get("authenticated"):
            return

        console.print()
        console.print("[yellow]This voice requires a free HuggingFace account.[/yellow]")
        console.print(f"  Token page: [link={HF_TOKEN_URL}]{HF_TOKEN_URL}[/link]")
        console.print()

        for attempt in range(3):
            token = _wizard_execute(inquirer.secret(message="Paste your HuggingFace token (hf_…):")).strip()
            result = kenkui.authenticate_huggingface(token)
            if getattr(result, "authenticated", False):
                username = getattr(result, "username", "")
                console.print(f"[green]Logged in as {username}[/green]")
                return
            err = getattr(result, "error", "Authentication failed.")
            console.print(f"[red]{err}[/red]")
            if attempt < 2:
                console.print("Please try again.")

        console.print("[red]Could not authenticate. Custom voices may not work.[/red]")
    except Exception as exc:
        console.print(f"[yellow]HuggingFace auth check failed ({exc}). Continuing without auth.[/yellow]")


# ---------------------------------------------------------------------------
# Chapter selection
# ---------------------------------------------------------------------------


def _prompt_chapter_preset_and_selection(book_path: Path) -> dict:
    """Return a ChapterSelection.to_dict() based on user input (local ebook reader)."""
    from InquirerPy import inquirer
    from kenkui.models import ChapterPreset, ChapterSelection

    preset_choices = [
        {"name": "Content Only  (body chapters, skip front/back matter)", "value": "content-only"},
        {"name": "Main Chapters  (titled chapters only)", "value": "chapters-only"},
        {"name": "With Parts  (chapters + part headings)", "value": "with-parts"},
        {"name": "All  (every item in the ebook)", "value": "all"},
        {"name": "None  (skip all chapters)", "value": "none"},
    ]

    preset_val = _wizard_execute(inquirer.select(
        message="Chapter selection:",
        choices=preset_choices,
    ))

    try:
        preset_enum = ChapterPreset(preset_val)
    except ValueError:
        preset_enum = ChapterPreset.CONTENT_ONLY

    from kenkui.chapter_filter import ChapterFilter
    from kenkui.readers import get_reader

    console.print("Loading chapters…", end=" ")
    try:
        reader = get_reader(book_path, verbose=False)
        chapters = reader.get_chapters()
        console.print(f"[green]{len(chapters)} found[/green]")
    except Exception as exc:
        console.print(f"[red]Failed to load chapters: {exc}[/red]")
        return ChapterSelection(preset=preset_enum).to_dict()

    if preset_val == "none":
        default_included: set[int] = set()
    else:
        filtered = ChapterFilter.apply_preset(chapters, preset_val)
        default_included = {ch.index for ch in filtered}

    chapter_choices = [
        {
            "name": f"[{ch.index:>3}]  {ch.title or '(untitled)'}",
            "value": ch.index,
            "enabled": ch.index in default_included,
        }
        for ch in chapters
    ]

    included = _wizard_execute(inquirer.checkbox(
        message=f"Select chapters to include (preset: {preset_val}):",
        choices=chapter_choices,
        instruction="(Space to toggle, Enter to confirm)",
    ))

    return ChapterSelection(
        preset=ChapterPreset.MANUAL if set(included) != default_included else preset_enum,
        included=included,
    ).to_dict()


# ---------------------------------------------------------------------------
# NLP scan helpers
# ---------------------------------------------------------------------------


def _run_fast_scan(
    book_path: Path,
    nlp_model: str,
    nlp_provider: str | None = None,
    series_slug: str | None = None,
):
    """Run Stage 1-2 NLP character scan. Returns FastScanResult or None."""
    import kenkui

    console.print(f"[cyan]Scanning characters in '{book_path.name}'…[/cyan]")

    with Progress(
        SpinnerColumn(),
        TextColumn("{task.description}"),
        TimeElapsedColumn(),
        console=console,
    ) as prog:
        prog_task = prog.add_task("Scanning characters…", total=None)
        try:
            result = kenkui.fast_scan(
                str(book_path),
                nlp_model=nlp_model,
                nlp_provider=nlp_provider,
                series_slug=series_slug,
                progress_callback=lambda pct, msg: prog.update(prog_task, description=msg or "Scanning…"),
            )
            prog.update(prog_task, description="Character scan complete")
            return result
        except Exception as exc:
            console.print(f"[red]Character scan failed: {exc}[/red]")
            return None


def _run_full_analysis(
    book_path: Path,
    nlp_model: str,
    nlp_provider: str | None = None,
    series_slug: str | None = None,
) -> "tuple[object | None, Path | None]":
    """Run full NLP attribution pipeline. Returns (NLPResult, cache_path) or (None, None)."""
    import kenkui
    from kenkui.nlp import cache_result

    console.print(f"[cyan]Running NLP attribution on '{book_path.name}'…[/cyan]")

    with Progress(
        SpinnerColumn(),
        TextColumn("{task.description}"),
        TimeElapsedColumn(),
        console=console,
    ) as prog:
        prog_task = prog.add_task("Running attribution…", total=None)
        try:
            result = kenkui.full_analysis(
                str(book_path),
                nlp_model=nlp_model,
                series_slug=series_slug,
                progress_callback=lambda pct, msg: prog.update(prog_task, description=msg or "Attributing…"),
            )
            prog.update(prog_task, description="Attribution complete")
        except Exception as exc:
            console.print(f"[red]NLP attribution failed: {exc}[/red]")
            return None, None

    try:
        cache_path = cache_result(result, book_path, provider=nlp_provider)
        return result, cache_path
    except Exception as exc:
        console.print(f"[yellow]Could not cache NLP result: {exc}[/yellow]")
        return result, None


# ---------------------------------------------------------------------------
# Multi-voice helpers
# ---------------------------------------------------------------------------


def _top_gender_matched_voice(characters, default_voice: str) -> str:
    """Return a voice that matches the gender dominant in the top roles."""
    from kenkui.services.voice_service import top_gender_matched_voice as _recommend_local
    return _recommend_local(characters, excluded=[], default_voice=default_voice)


def _auto_assign_voices(
    characters,
    narrator_voice: str,
    excluded_voices: "list[str] | None" = None,
) -> "tuple[dict[str, str], list[tuple[str, str]]]":
    """Auto-assign voices using local suggest_cast. Returns (speaker_voices, unresolved_conflicts)."""
    from kenkui.services.voice_service import suggest_cast

    try:
        local_result = suggest_cast(
            roster=characters,
            excluded_voices=excluded_voices or [],
            default_voice=narrator_voice,
        )
        speaker_voices = local_result.speaker_voices
        warnings = local_result.warnings
        for w in warnings:
            console.print(f"[yellow]Warning:[/yellow] {w}")
        return speaker_voices, []
    except Exception as exc:
        console.print(f"[red]Could not auto-assign voices: {exc}[/red]")
        return {}, []


def _make_character_review_label(
    ch,
    voice: str,
    pinned: "set[str]",
    series_name: "str | None" = None,
) -> str:
    """Build a display label for the character review list."""
    from kenkui.services.voice_service import format_character_review_label
    return format_character_review_label(ch, voice, pinned=pinned, series_name=series_name)


def _prompt_character_voice_review(
    speaker_voices: dict[str, str],
    characters,
    narrator_voice: str,
    pinned: "set[str] | None" = None,
    series_name: "str | None" = None,
    unresolved_conflicts: "list[tuple[str, str]] | None" = None,
) -> dict[str, str]:
    """Show a reference table, then review each character via an InquirerPy list."""
    from InquirerPy import inquirer
    from kenkui.services.voice_service import (
        annotate_voice_choices,
        build_character_review_choices,
        format_character_review_label,
        build_voice_users,
        format_unresolved_conflict_warnings,
    )

    _pinned = pinned or set()
    for warning in format_unresolved_conflict_warnings(unresolved_conflicts, _pinned):
        console.print(f"[yellow]⚠ {warning}[/yellow]")
    if unresolved_conflicts:
        console.print()

    all_voice_choices = _build_voice_choices()
    voice_choices = [c for c in all_voice_choices if c.get("value") != narrator_voice]
    if not voice_choices:
        voice_choices = all_voice_choices

    tbl = Table(title="Characters", show_header=True)
    tbl.add_column("Character ID", style="dim")
    tbl.add_column("Name")
    tbl.add_column("Mentions", justify="right")
    tbl.add_column("Gender")
    tbl.add_column("Voice", style="bold cyan")

    def _annotated_voice_choices(exclude_char_name: str | None = None) -> list[dict]:
        voice_users = build_voice_users(speaker_voices, characters)
        return annotate_voice_choices(
            voice_choices,
            voice_users,
            exclude_char_name=exclude_char_name,
        )

    review_choices = build_character_review_choices(
        characters,
        speaker_voices,
        narrator_voice,
        pinned=_pinned,
        series_name=series_name,
    )

    while True:
        accept = _wizard_execute(inquirer.confirm(
            message="Accept these voice assignments?",
            default=True,
        ))
        if accept:
            break

        chosen = _wizard_execute(inquirer.select(
            message="Select a character to re-assign:",
            choices=review_choices,
            max_height="40%",
        ))

        ch = next((c for c in characters if c.character_id == chosen), None)
        exclude_name = ch.display_name if ch else chosen

        new_voice = _wizard_execute(inquirer.fuzzy(
            message=f"Voice for {chosen}:",
            choices=_annotated_voice_choices(exclude_char_name=exclude_name),
            default=speaker_voices.get(chosen, narrator_voice),
            max_height="40%",
        ))

        if new_voice == "__custom__":
            new_voice = _wizard_execute(
                inquirer.text(message="Enter path or hf:// URL:")
            ).strip()

        speaker_voices[chosen] = new_voice

        for rc in review_choices:
            if rc["value"] == chosen:
                if ch is not None:
                    rc["name"] = format_character_review_label(
                        ch,
                        new_voice,
                        pinned=_pinned,
                        series_name=series_name,
                    )
                break

    return speaker_voices


def _prompt_multivoice_character_voices(
    scan_result,
    default_voice: str,
    inherited_voices: "dict[str, str] | None" = None,
    pinned: "set[str] | None" = None,
    series_name: "str | None" = None,
    excluded_voices: "list[str] | None" = None,
) -> dict[str, str]:
    """Run the full multi-voice character assignment flow.

    Returns a dict mapping character_id (including "NARRATOR") to voice name.
    """
    from InquirerPy import inquirer
    from kenkui.services.voice_service import merge_speaker_voices

    characters = scan_result.characters
    if not characters:
        console.print(
            "[yellow]No characters found by the NLP pipeline. Using narrator voice for all.[/yellow]"
        )
        narrator_voice = _prompt_voice(default=default_voice, message="Fallback voice for NARRATOR:")
        return {"NARRATOR": narrator_voice}

    console.print("[bold]Select fallback voice for NARRATOR:[/bold]")
    narrator_default = _top_gender_matched_voice(characters, default_voice)
    narrator_voice = _prompt_voice(default=narrator_default, message="NARRATOR fallback voice:")
    _check_hf_auth(narrator_voice)

    assignment_mode = _wizard_execute(inquirer.select(
        message="Character voice assignment mode:",
        choices=[
            {
                "name": "Simple   — all males → one voice, all females → another",
                "value": "simple",
            },
            {
                "name": "Advanced — individual voice per character",
                "value": "advanced",
            },
        ],
    ))

    if assignment_mode == "simple":
        return _prompt_simple_voice_assignment(characters, narrator_voice)

    speaker_voices, unresolved_conflicts = _auto_assign_voices(
        characters, narrator_voice, excluded_voices=excluded_voices
    )

    speaker_voices = merge_speaker_voices(speaker_voices, inherited_voices)

    speaker_voices = _prompt_character_voice_review(
        speaker_voices, characters, narrator_voice,
        pinned=pinned or set(),
        series_name=series_name,
        unresolved_conflicts=unresolved_conflicts,
    )

    return speaker_voices


def _run_series_setup(
    fast_result=None,
    mode: str = "multi",
    prompts: "list | None" = None,
    _roster_candidates: "list | None" = None,
) -> "tuple":
    """Prompt for series selection and compute inherited voice assignments.

    Returns (manifest, inherited_voices, pinned).
    """
    from kenkui.series import (
        SeriesCharacter,
        SeriesManifest,
        build_manifest_from_predecessor,
        list_roster_candidates,
        load_series,
        match_characters,
        save_series,
        slugify,
    )

    if mode != "multi":
        return None, {}, set()

    if prompts is None:
        from InquirerPy import inquirer

        console.print()
        wants_series = _wizard_execute(inquirer.confirm(
            message="Is this book part of a series?",
            default=False,
        ))
        if not wants_series:
            return None, {}, set()

        from kenkui.series import list_series as _local_list_series
        series_choices = [{"name": s.name, "value": s.slug} for s in _local_list_series()]
        series_choices.append({"name": "[ + New series ]", "value": "__new__"})

        chosen_slug = _wizard_execute(inquirer.select(
            message="Select series:",
            choices=series_choices,
        ))

        if chosen_slug != "__new__":
            manifest = load_series(chosen_slug)
        else:
            candidates = list_roster_candidates()
            seed_idx: int | None = None
            if candidates:
                candidate_choices = [
                    {"name": "[ Fresh start — no predecessor ]", "value": -1},
                ] + [
                    {"name": c["title"] or c["hash"][:8], "value": i}
                    for i, c in enumerate(candidates)
                ]
                seed_idx = _wizard_execute(inquirer.select(
                    message="Seed from a previously processed book? (optional)",
                    choices=candidate_choices,
                ))

            series_name = _wizard_execute(inquirer.text(
                message="Series name:",
                default=candidates[seed_idx]["title"] if seed_idx is not None and seed_idx >= 0 else "",
            )).strip()

            if seed_idx is not None and seed_idx >= 0:
                manifest = build_manifest_from_predecessor(candidates[seed_idx], series_name)
            else:
                manifest = SeriesManifest(
                    name=series_name,
                    slug=slugify(series_name),
                    updated_at="",
                    characters=[],
                )

        save_series(manifest)

    else:
        _p = iter(prompts)
        wants_series_val = next(_p, None)
        if wants_series_val != "yes":
            return None, {}, set()

        chosen = next(_p, None)
        if chosen == "new":
            candidates = _roster_candidates or list_roster_candidates()
            idx = next(_p, -1)
            series_name = next(_p, "Test Series")
            if candidates and idx >= 0:
                manifest = build_manifest_from_predecessor(candidates[idx], series_name)
            else:
                manifest = SeriesManifest(
                    name=series_name,
                    slug=slugify(series_name),
                    updated_at="",
                    characters=[],
                )
        else:
            manifest = load_series(chosen)

        if manifest is None:
            return None, {}, set()
        save_series(manifest)

    if fast_result is not None:
        inherited_voices, pinned = match_characters(fast_result.characters, fast_result, manifest)
    else:
        inherited_voices, pinned = {}, set()
    return manifest, inherited_voices, pinned


# ---------------------------------------------------------------------------
# Multi-voice requirements check
# ---------------------------------------------------------------------------


def _check_multivoice_requirements(app_config=None) -> bool:
    """Check multivoice readiness locally and show status table.

    Returns True if all requirements are met or the user chooses to continue anyway.
    """
    from InquirerPy import inquirer
    from rich.table import Table
    from rich.text import Text

    nlp_provider = getattr(app_config, "nlp_provider", "ollama") if app_config else "ollama"

    if nlp_provider != "ollama":
        from kenkui.config import load_provider_credentials
        creds = load_provider_credentials()
        provider_cred = creds.get(nlp_provider)
        cred_ok = bool(provider_cred and provider_cred.api_key)

        checks: list[tuple[str, bool, str]] = [
            (
                f"{nlp_provider} API key",
                cred_ok,
                "Run: kentui configure-provider" if not cred_ok else "",
            ),
        ]
        tbl = Table(title=f"Multi-Voice Requirements ({nlp_provider})", show_header=True, header_style="bold")
        tbl.add_column("Requirement", min_width=30)
        tbl.add_column("Status", width=10)
        tbl.add_column("Fix", overflow="fold")
        for name, ok, fix in checks:
            row_status = Text("✓ Ready", style="green") if ok else Text("✗ Missing", style="red bold")
            tbl.add_row(name, row_status, fix)
        console.print(tbl)

        all_ok = all(ok for _, ok, _ in checks)
        if all_ok:
            return True

        proceed = _wizard_execute(inquirer.confirm(
            message="Continue anyway? (will fail at runtime without a valid API key)",
            default=False,
        ))
        return proceed

    # Ollama provider: check spaCy + Ollama server locally.
    spacy_ok = False
    ollama_ok = False
    message = ""

    try:
        import spacy
        spacy.load("en_core_web_sm")
        spacy_ok = True
    except Exception:
        pass

    try:
        import urllib.request
        urllib.request.urlopen("http://localhost:11434/api/tags", timeout=2)
        ollama_ok = True
    except Exception:
        pass

    ollama_checks: list[tuple[str, bool, str]] = [
        (
            "spaCy model (en_core_web_sm)",
            spacy_ok,
            "python -m spacy download en_core_web_sm" if not spacy_ok else "",
        ),
        (
            "Ollama server",
            ollama_ok,
            "Start with: ollama serve" if not ollama_ok else "",
        ),
    ]

    tbl = Table(title="Multi-Voice Requirements", show_header=True, header_style="bold")
    tbl.add_column("Requirement", min_width=30)
    tbl.add_column("Status", width=10)
    tbl.add_column("Fix", overflow="fold")
    for name, ok, fix in ollama_checks:
        row_status = Text("✓ Ready", style="green") if ok else Text("✗ Missing", style="red bold")
        tbl.add_row(name, row_status, fix)
    console.print(tbl)

    if message:
        console.print(f"[dim]{message}[/dim]")

    all_ok = all(ok for _, ok, _ in ollama_checks)
    if all_ok:
        return True

    proceed = _wizard_execute(inquirer.confirm(
        message="Continue anyway? (the job will attempt to satisfy missing requirements at runtime)",
        default=False,
    ))
    return proceed


def _prompt_simple_voice_assignment(characters, narrator_voice: str) -> dict[str, str]:
    """Simple mode: all males → one voice, all females → another."""
    from kenkui.voice_registry import get_registry
    from kenkui.services.voice_service import assign_simple_cast

    registry = get_registry()
    male_voices = [v.name for v in registry.filter(gender="Male")]
    female_voices = [v.name for v in registry.filter(gender="Female")]

    male_pool = [v for v in male_voices if v != narrator_voice] or male_voices
    female_pool = [v for v in female_voices if v != narrator_voice] or female_voices

    male_voice = _prompt_voice(
        default=male_pool[0] if male_pool else "alba",
        message="Voice for all male characters:",
    )
    female_voice = _prompt_voice(
        default=female_pool[0] if female_pool else "alba",
        message="Voice for all female characters:",
    )

    return assign_simple_cast(
        roster=characters,
        narrator_voice=narrator_voice,
        male_voice=male_voice,
        female_voice=female_voice,
    )


def _prompt_chapter_voices(chapters, default_voice: str) -> dict[str, str]:
    """Chapter-voice mode: assign a voice per chapter.

    Returns {str(chapter_index): voice_name}.
    """
    from rich.rule import Rule

    console.print()
    console.print(Rule("[bold]Chapter Voice Assignment[/bold]"))
    console.print("[dim]Assign a voice for each chapter. Press Enter to accept the default.[/dim]")
    console.print()

    chapter_voices: dict[str, str] = {}
    for ch in chapters:
        voice = _prompt_voice(
            default=default_voice,
            message=f"Voice for '{ch.title[:50]}':",
        )
        chapter_voices[str(ch.index)] = voice

    return chapter_voices


def _prompt_quality_overrides(app_config) -> dict:
    """Optionally override TTS quality settings for this specific job.

    Returns a dict of job_* override fields (only keys where user changed the value).
    """
    from InquirerPy import inquirer

    want = _wizard_execute(inquirer.confirm(
        message="Customize audio quality for this job? (defaults come from your config)",
        default=False,
    ))
    if not want:
        return {}

    overrides: dict = {}

    temp = _wizard_execute(inquirer.text(
        message=f"Temperature (0.0–1.5, current default {app_config.temp}):",
        default=str(app_config.temp),
        validate=_RangeValidator(min_val=0.0, max_val=1.5, float_ok=True),
        filter=lambda x: float(x.strip()),
    ))
    if float(temp) != app_config.temp:
        overrides["job_temp"] = float(temp)

    lsd = _wizard_execute(inquirer.text(
        message=f"LSD decode steps (1–50, current default {app_config.lsd_decode_steps}):",
        default=str(app_config.lsd_decode_steps),
        validate=_RangeValidator(min_val=1, max_val=50),
        filter=lambda x: int(x.strip()),
    ))
    if int(lsd) != app_config.lsd_decode_steps:
        overrides["job_lsd_decode_steps"] = int(lsd)

    noise_default = app_config.noise_clamp or 0.0
    noise = _wizard_execute(inquirer.text(
        message=f"Noise clamp (0=off, ~3.0=reduce glitches, current default {noise_default}):",
        default=str(noise_default),
        validate=_RangeValidator(min_val=0.0, max_val=10.0, float_ok=True),
        filter=lambda x: float(x.strip()),
    ))
    noise_val = float(noise)
    if noise_val != noise_default:
        overrides["job_noise_clamp"] = noise_val if noise_val > 0 else None

    fae = _wizard_execute(inquirer.text(
        message=f"Frames after EoS cutoff (0=suppress noise, current default {app_config.frames_after_eos}):",
        default=str(app_config.frames_after_eos),
        validate=_RangeValidator(min_val=0, max_val=50),
        filter=lambda x: int(x.strip()),
    ))
    if int(fae) != app_config.frames_after_eos:
        overrides["job_frames_after_eos"] = int(fae)

    bitrate_choices = [
        {"name": "64k  (small file, lower quality)", "value": "64k"},
        {"name": "96k  (default)", "value": "96k"},
        {"name": "128k", "value": "128k"},
        {"name": "192k", "value": "192k"},
        {"name": "256k  (large file, higher quality)", "value": "256k"},
    ]
    bitrate = _wizard_execute(inquirer.select(
        message=f"Output bitrate (current default {app_config.m4b_bitrate}):",
        choices=bitrate_choices,
        default=app_config.m4b_bitrate,
    ))
    if bitrate != app_config.m4b_bitrate:
        overrides["job_m4b_bitrate"] = bitrate

    pause_line = _wizard_execute(inquirer.text(
        message=f"Silence between lines in ms (current default {app_config.pause_line_ms}):",
        default=str(app_config.pause_line_ms),
        validate=_RangeValidator(min_val=0, max_val=5000),
        filter=lambda x: int(x.strip()),
    ))
    if int(pause_line) != app_config.pause_line_ms:
        overrides["job_pause_line_ms"] = int(pause_line)

    pause_chapter = _wizard_execute(inquirer.text(
        message=f"Silence between chapters in ms (current default {app_config.pause_chapter_ms}):",
        default=str(app_config.pause_chapter_ms),
        validate=_RangeValidator(min_val=0, max_val=30000),
        filter=lambda x: int(x.strip()),
    ))
    if int(pause_chapter) != app_config.pause_chapter_ms:
        overrides["job_pause_chapter_ms"] = int(pause_chapter)

    apostrophe_default = getattr(app_config, "apostrophe_mode", None)
    apostrophe_default_val = apostrophe_default.value if apostrophe_default is not None else "expand_contractions"
    apostrophe_choices = [
        {"name": "expand_contractions  (expand contractions — default)", "value": "expand_contractions"},
        {"name": "keep  (pass text unchanged)", "value": "keep"},
        {"name": "remove_contractions  (strip apostrophe from contractions only)", "value": "remove_contractions"},
        {"name": "always_remove  (strip every apostrophe, including names)", "value": "always_remove"},
    ]
    apostrophe = _wizard_execute(inquirer.select(
        message=f"Apostrophe/contraction mode (current default {apostrophe_default_val}):",
        choices=apostrophe_choices,
        default=apostrophe_default_val,
    ))
    if apostrophe != apostrophe_default_val:
        from kenkui.utils import ApostropheMode
        overrides["job_apostrophe_mode"] = ApostropheMode(apostrophe)

    return overrides


# ---------------------------------------------------------------------------
# Hub-and-spoke confirmation screen
# ---------------------------------------------------------------------------


def _init_state_from_profile(book_path, app_config, profile: dict) -> dict:
    """Build initial wizard state from last profile, falling back to app_config defaults."""
    from kenkui.services.confirmation_service import init_confirmation_state
    return init_confirmation_state(book_path, app_config, profile)


def _state_to_profile(state: dict) -> dict:
    """Extract saveable profile keys from wizard state."""
    from kenkui.services.confirmation_service import confirmation_state_to_profile
    return confirmation_state_to_profile(state)


def _print_status_panel(state: dict, app_config) -> None:
    """Print a read-only Rich panel showing current job settings above the hub menu."""
    from rich.panel import Panel

    mode = state.get("narration_mode", "single")
    voice = state.get("voice", getattr(app_config, "default_voice", "alba"))
    chapter_selection = state.get("chapter_selection", {})
    preset = chapter_selection.get("preset", getattr(app_config, "default_chapter_preset", "content-only"))
    included = chapter_selection.get("included", [])
    chapter_count = f"{len(included)} selected" if included else "preset"
    quality_overrides = state.get("quality_overrides") or {}

    if state.get("chapter_voices"):
        mode_str = "Chapter-voice"
        nlp_str = "—"
    elif mode == "multi":
        nlp_provider = state.get("job_nlp_provider") or getattr(app_config, "nlp_provider", "ollama")
        nlp_model = state.get("job_nlp_model") or getattr(app_config, "nlp_model", "llama3.2")
        mode_str = "Multi-voice"
        nlp_str = f"{nlp_provider} · {nlp_model}"
    else:
        mode_str = "Single narrator"
        nlp_str = "—"

    temp = quality_overrides.get("job_temp") or getattr(app_config, "temp", 0.7)
    steps = quality_overrides.get("job_lsd_decode_steps") or getattr(app_config, "lsd_decode_steps", 1)
    bitrate = getattr(app_config, "m4b_bitrate", "96k")
    series_slug = state.get("series_slug")
    series_manifest = state.get("_series_manifest")
    series_label = getattr(series_manifest, "name", None) or series_slug or "None"

    book_path_obj = state.get("_book_path")
    output_dir = state.get("output_dir") or (str(book_path_obj.parent) if book_path_obj and hasattr(book_path_obj, "parent") else "")

    lines = [
        f"  [bold]Mode:[/bold]          {mode_str}",
        f"  [bold]NLP:[/bold]           {nlp_str}",
        f"  [bold]TTS Provider:[/bold]  pocket-tts · local",
        f"  [bold]Output:[/bold]        {output_dir}",
        f"  [bold]Narrator:[/bold]      {voice}",
        f"  [bold]Series:[/bold]        {series_label}",
        f"  [bold]Chapters:[/bold]      {preset} ({chapter_count})",
        f"  [bold]Quality:[/bold]       temp {temp} · {steps} LSD steps · {bitrate}",
    ]

    panel = Panel(
        "\n".join(lines),
        title="Current Settings",
        expand=False,
        border_style="dim",
    )
    console.print(panel)


def _build_confirmation_choices(state: dict, app_config) -> list:
    """Build InquirerPy select choices for the confirmation screen."""
    from InquirerPy.base.control import Choice

    voice = state.get("voice", getattr(app_config, "default_voice", "alba"))
    default_voice = getattr(app_config, "default_voice", "alba")
    mode = state.get("narration_mode", "single")
    has_chapter_voices = bool(state.get("chapter_voices"))
    voice_tag = (
        "[DEFAULT]"
        if (voice == default_voice and mode == "single" and not has_chapter_voices)
        else "[CUSTOM]"
    )
    series_slug = state.get("series_slug")
    series_manifest = state.get("_series_manifest")
    series_name = getattr(series_manifest, "name", None) or series_slug or "None"

    chapter_selection = state.get("chapter_selection", {})
    chapter_preset = chapter_selection.get("preset", getattr(app_config, "default_chapter_preset", "content-only"))
    default_preset = getattr(app_config, "default_chapter_preset", "content-only")
    chapter_tag = "[DEFAULT]" if chapter_preset == default_preset else "[CUSTOM]"

    return [
        Choice(value="submit",    name="  Submit Job"),
        Choice(value="voice",     name=f"  Narrator Voice              {voice}  {voice_tag} →"),
        Choice(value="chapters",  name=f"  Chapters                    {chapter_preset}  {chapter_tag} →"),
        Choice(value="narration", name="  Narration Mode →"),
        Choice(value="series",    name=f"  Series                      {series_name} →"),
        Choice(value="advanced",  name="  Advanced Options →"),
        Choice(value="cancel",    name="  Cancel"),
    ]


def _submenu_chapters(state: dict, app_config) -> dict:
    """Chapter selection submenu. Returns updated state."""
    from InquirerPy import inquirer
    from kenkui.services.workflow_service import reset_chapter_selection

    action = _wizard_execute(inquirer.select(
        message="Chapters",
        choices=[
            {"name": f"Keep current ({state['chapter_selection'].get('preset', 'content-only')})", "value": "keep"},
            {"name": "Select chapters...", "value": "select"},
            {"name": "Reset to defaults", "value": "reset"},
            {"name": "Back", "value": "back"},
        ],
    ))
    if action == "reset":
        state = reset_chapter_selection(state, app_config)
    elif action == "select":
        book_path = state["_book_path"]
        try:
            chapter_selection = _prompt_chapter_preset_and_selection(book_path)
            state = {**state, "chapter_selection": chapter_selection}
        except (KeyboardInterrupt, EOFError):
            raise
        except Exception as exc:
            console.print(f"[yellow]Could not load chapter list: {exc}[/yellow]")
    return state


def _submenu_narration_mode(state: dict, app_config) -> dict:
    """Narration Mode top-level submenu. Returns updated state."""
    from InquirerPy import inquirer
    from kenkui.services.workflow_service import reset_voice_mode, set_single_voice_mode

    mode_label = _describe_mode_for_menu(state, app_config)

    action = _wizard_execute(inquirer.select(
        message="Narration Mode",
        choices=[
            {"name": f"Keep current ({mode_label})", "value": "keep"},
            {"name": "Change mode / provider…", "value": "mode"},
            {"name": "Reset to defaults (single narrator)", "value": "reset"},
            {"name": "Back", "value": "back"},
        ],
    ))
    if action == "reset":
        state = reset_voice_mode(state, app_config)
    elif action == "mode":
        mode = _wizard_execute(inquirer.select(
            message="Narration mode:",
            choices=[
                {"name": "Single narrator  — one voice reads everything", "value": "single"},
                {"name": "Multi-voice (NLP) — voice per character (scan runs before job)", "value": "multi"},
                {"name": "Chapter-voice    — assign a voice per chapter", "value": "chapter"},
            ],
        ))
        if mode == "single":
            state = set_single_voice_mode(state)
        elif mode == "multi":
            state = _setup_multi_voice(state, app_config)
        elif mode == "chapter":
            state = _setup_chapter_voice(state)
    return state


def _edit_narrator_voice(state: dict, app_config) -> dict:
    """Prompt for the job's narrator/fallback voice and update state."""
    voice = _prompt_voice(
        default=state.get("voice", app_config.default_voice),
        message="Select narrator / fallback voice:",
    )
    new_state = {**state, "voice": voice}
    if state.get("narration_mode") == "multi":
        speaker_voices = dict(state.get("speaker_voices") or {})
        speaker_voices["NARRATOR"] = voice
        new_state["speaker_voices"] = speaker_voices
    return new_state


def _describe_mode_for_menu(state: dict, app_config) -> str:
    """Short label for current narration mode shown in the Narration Mode submenu."""
    mode = state.get("narration_mode", "single")
    if state.get("chapter_voices"):
        return "chapter-voice"
    if mode == "multi":
        provider = state.get("job_nlp_provider") or getattr(app_config, "nlp_provider", "ollama")
        model = state.get("job_nlp_model") or getattr(app_config, "nlp_model", "llama3.2")
        return f"multi-voice · {provider} · {model}"
    return "single narrator"


def _submenu_advanced(state: dict, app_config) -> dict:
    """Advanced Options — organized by pipeline stage."""
    from InquirerPy import inquirer

    while True:
        action = _wizard_execute(inquirer.select(
            message="Advanced Options",
            choices=[
                {"name": "pocket-tts Quality        temp, generation steps, EOS, noise clamp →", "value": "tts_quality"},
                {"name": "Audio Encoding            bitrate, pauses, chapter titles →", "value": "encoding"},
                {"name": "Audio Post-Processing     enable/disable effects chain →", "value": "postprocessing"},
                {"name": "Text Preprocessing        apostrophe/contraction handling →", "value": "text_prep"},
                {"name": "Output Location           where the audiobook file goes →", "value": "output"},
                {"name": "NLP Settings              model and provider for character scan →", "value": "nlp_settings"},
                {"name": "Voice Management          browse, audition, exclude voices →", "value": "voices"},
                {"name": "Back", "value": "back"},
            ],
        ))
        if action == "tts_quality":
            state = _submenu_tts_quality(state, app_config)
        elif action == "encoding":
            state = _submenu_audio_encoding(state, app_config)
        elif action == "postprocessing":
            state = _submenu_post_processing(state, app_config)
        elif action == "text_prep":
            state = _submenu_text_preprocessing(state, app_config)
        elif action == "output":
            state = _submenu_output_location(state, app_config)
        elif action == "nlp_settings":
            state = _submenu_nlp_settings(state, app_config)
        elif action == "voices":
            _submenu_manage_voices(state, app_config)
        else:
            break
    return state


def _submenu_nlp_settings(state: dict, app_config) -> dict:
    """NLP provider/model settings for multi-voice jobs."""
    from InquirerPy import inquirer

    if state.get("narration_mode") != "multi":
        console.print("[dim]NLP settings only apply in Multi-voice mode.[/dim]")
        return state

    provider, nlp_model = _prompt_nlp_provider(app_config)
    state["job_nlp_provider"] = provider
    state["job_nlp_model"] = nlp_model
    return state


_CLOUD_PROVIDER_MODELS: dict[str, list[str]] = {
    "anthropic": [
        "claude-haiku-4-5-20251001",
        "claude-sonnet-4-6",
        "claude-opus-4-6",
    ],
    "openai": [
        "gpt-4o-mini",
        "gpt-4o",
        "gpt-4.1-mini",
        "gpt-4.1",
    ],
    "google": [
        "gemini/gemini-2.0-flash",
        "gemini/gemini-2.5-flash-preview-04-17",
        "gemini/gemini-2.5-pro-preview-03-25",
    ],
}


def _prompt_nlp_model(provider: str, current_model: str) -> str:
    """Prompt the user to pick or enter an NLP model for *provider*."""
    from InquirerPy import inquirer

    if provider == "ollama":
        return _wizard_execute(inquirer.text(
            message=f"Ollama model (current: {current_model}):",
            default=current_model,
        )).strip() or current_model

    known = _CLOUD_PROVIDER_MODELS.get(provider, [])
    choices = [{"name": m, "value": m} for m in known]
    choices.append({"name": "Custom model ID…", "value": "__custom__"})

    default_choice = current_model if current_model in known else (known[0] if known else current_model)
    selected = _wizard_execute(inquirer.select(
        message=f"Model for {provider}:",
        choices=choices,
        default=default_choice,
    ))

    if selected == "__custom__":
        return _wizard_execute(inquirer.text(
            message="Enter model ID:",
            default=current_model,
        )).strip() or current_model

    return selected


def _prompt_nlp_provider(app_config) -> tuple[str, str]:
    """Let the user pick an NLP provider and model. Returns (provider_name, model_name)."""
    from InquirerPy import inquirer
    from kenkui.config import load_provider_credentials

    default_provider = getattr(app_config, "nlp_provider", "ollama")
    default_model = getattr(app_config, "nlp_model", "llama3.2")

    creds = load_provider_credentials()
    provider_choices = [{"name": "Ollama (local)", "value": "ollama"}]
    model_defaults: dict[str, str] = {"ollama": default_model}
    for provider, c in creds.items():
        if c.api_key:
            provider_choices.append({"name": provider, "value": provider})
            model_defaults[provider] = c.default_model or (_CLOUD_PROVIDER_MODELS.get(provider) or [provider])[0]

    if len(provider_choices) == 1:
        chosen_provider = provider_choices[0]["value"]
    else:
        current_provider = default_provider if default_provider in model_defaults else "ollama"
        chosen_provider = _wizard_execute(inquirer.select(
            message="NLP provider for this scan:",
            choices=provider_choices,
            default=current_provider,
        ))

    current_model = model_defaults.get(chosen_provider, default_model)
    chosen_model = _prompt_nlp_model(chosen_provider, current_model)
    return chosen_provider, chosen_model


def _setup_multi_voice(state: dict, app_config) -> dict:
    """Configure multi-voice mode with deferred NLP scan. Returns updated state.

    The character scan and voice assignment happen at job submission time (after
    the wizard) in cmd_add. This function only collects NLP provider/model,
    narrator fallback voice, and optional series slug.
    """
    from kenkui.services.workflow_service import apply_multi_voice_setup

    provider, nlp_model = _prompt_nlp_provider(app_config)
    scan_config = app_config.model_copy(update={"nlp_provider": provider, "nlp_model": nlp_model})

    if not _check_multivoice_requirements(scan_config):
        return state

    voice = state.get("voice", getattr(app_config, "default_voice", "alba"))
    console.print()
    console.print("[bold]Select fallback narrator voice:[/bold]")
    narrator_voice = _prompt_voice(default=voice, message="NARRATOR fallback voice:")
    _check_hf_auth(narrator_voice)

    manifest, series_slug = _prompt_series_slug()

    return apply_multi_voice_setup(
        {**state, "voice": narrator_voice},
        speaker_voices={"NARRATOR": narrator_voice},
        roster_cache_path=None,
        manifest=manifest,
        nlp_provider=provider,
        nlp_model=nlp_model,
    )


def _prompt_series_slug() -> "tuple[object | None, str | None]":
    """Prompt for series membership without running a character scan.

    Returns (manifest_or_None, slug_or_None).
    """
    from InquirerPy import inquirer
    from kenkui.series import SeriesManifest, slugify, list_series as _local_list_series

    console.print()
    wants_series = _wizard_execute(inquirer.confirm(
        message="Is this book part of a series?",
        default=False,
    ))
    if not wants_series:
        return None, None

    series_choices = [{"name": s.name, "value": s.slug} for s in _local_list_series()]
    series_choices.append({"name": "[ + New series ]", "value": "__new__"})

    chosen_slug = _wizard_execute(inquirer.select(
        message="Select series:",
        choices=series_choices,
    ))

    if chosen_slug == "__new__":
        series_name = _wizard_execute(inquirer.text(message="Series name:")).strip()
        if not series_name:
            return None, None
        slug = slugify(series_name)
        manifest = SeriesManifest(name=series_name, slug=slug, updated_at="", characters=[])
        return manifest, slug

    return None, chosen_slug


def _edit_series(state: dict) -> dict:
    """Top-level series editor for the confirmation screen."""
    from InquirerPy import inquirer

    current_slug = state.get("series_slug")
    current_manifest = state.get("_series_manifest")
    current_name = getattr(current_manifest, "name", None) or current_slug or "None"

    choices = []
    if current_slug:
        choices.extend([
            {"name": f"Keep current ({current_name})", "value": "keep"},
            {"name": "Change series…", "value": "change"},
            {"name": "Remove series link", "value": "clear"},
            {"name": "Back", "value": "back"},
        ])
    else:
        choices.extend([
            {"name": "Set series…", "value": "change"},
            {"name": "Back", "value": "back"},
        ])

    action = _wizard_execute(inquirer.select(
        message="Series",
        choices=choices,
    ))

    if action == "clear":
        return {**state, "series_slug": None, "_series_manifest": None}
    if action == "change":
        manifest, series_slug = _prompt_series_slug()
        return {**state, "series_slug": series_slug, "_series_manifest": manifest}
    return state


def _setup_chapter_voice(state: dict) -> dict:
    """Run chapter-voice assignment flow. Returns updated state."""
    import kenkui
    from kenkui.services.setup_service import build_chapter_prompt_items
    from kenkui.services.workflow_service import apply_chapter_voice_setup

    book_path = state["_book_path"]
    voice = state.get("voice", "alba")

    try:
        parsed = kenkui.parse_book(str(book_path))
    except Exception as exc:
        console.print(f"[red]Could not load chapter list: {exc}[/red]")
        return state

    chapters = build_chapter_prompt_items(parsed)
    if not chapters:
        console.print("[yellow]No chapters found.[/yellow]")
        return state

    chapter_voices = _prompt_chapter_voices(chapters, default_voice=voice)
    return apply_chapter_voice_setup(state, chapter_voices)


def _submenu_tts_quality(state: dict, app_config) -> dict:
    """pocket-tts quality overrides: temp, LSD steps, EOS threshold, noise clamp, frames after EOS."""
    from InquirerPy import inquirer
    from kenkui.services.workflow_service import reset_quality_overrides

    action = _wizard_execute(inquirer.select(
        message="pocket-tts Quality",
        choices=[
            {"name": f"Keep current ({'custom' if state.get('quality_overrides') else 'defaults'})", "value": "keep"},
            {"name": "Edit quality overrides…", "value": "edit"},
            {"name": "Reset to defaults (clear overrides)", "value": "reset"},
            {"name": "Back", "value": "back"},
        ],
    ))
    if action == "reset":
        state = reset_quality_overrides(state)
    elif action == "edit":
        overrides = dict(state.get("quality_overrides") or {})

        cfg_temp = getattr(app_config, "temp", 0.7)
        cfg_steps = getattr(app_config, "lsd_decode_steps", 1)
        cfg_eos = getattr(app_config, "eos_threshold", -4.0)
        cfg_noise = getattr(app_config, "noise_clamp", None)
        cfg_frames = getattr(app_config, "frames_after_eos", None)

        temp_str = _wizard_execute(inquirer.text(
            message=f"Temperature [0.0-1.5] (blank = {cfg_temp}, inherited from config):",
            default=str(overrides.get("job_temp", "")),
            validate=_RangeValidator(min_val=0.0, max_val=1.5, float_ok=True, allow_blank=True),
        )).strip()
        if temp_str:
            overrides["job_temp"] = float(temp_str)
        elif "job_temp" in overrides:
            del overrides["job_temp"]

        steps_str = _wizard_execute(inquirer.text(
            message=f"Generation steps [1-50] (blank = {cfg_steps}, inherited from config):",
            default=str(overrides.get("job_lsd_decode_steps", "")),
            validate=_RangeValidator(min_val=1, max_val=50, float_ok=False, allow_blank=True),
        )).strip()
        if steps_str:
            overrides["job_lsd_decode_steps"] = int(steps_str)
        elif "job_lsd_decode_steps" in overrides:
            del overrides["job_lsd_decode_steps"]

        eos_str = _wizard_execute(inquirer.text(
            message=f"EOS threshold [-10.0–0.0] (blank = {cfg_eos}, inherited from config; -2.0=later cutoff, -6.0=earlier):",
            default=str(overrides.get("job_eos_threshold", "")),
            validate=_RangeValidator(min_val=-10.0, max_val=0.0, float_ok=True, allow_blank=True),
        )).strip()
        if eos_str:
            overrides["job_eos_threshold"] = float(eos_str)
        elif "job_eos_threshold" in overrides:
            del overrides["job_eos_threshold"]

        noise_cfg_label = "disabled" if cfg_noise is None else str(cfg_noise)
        noise_str = _wizard_execute(inquirer.text(
            message=f"Noise clamp [0.0–10.0] (0=disabled, ~3.0 reduces glitches; blank = {noise_cfg_label}, inherited from config):",
            default=str(overrides.get("job_noise_clamp", "")),
            validate=_RangeValidator(min_val=0.0, max_val=10.0, float_ok=True, allow_blank=True),
        )).strip()
        if noise_str:
            val = float(noise_str)
            if val == 0.0:
                if "job_noise_clamp" in overrides:
                    del overrides["job_noise_clamp"]
            else:
                overrides["job_noise_clamp"] = val
        elif "job_noise_clamp" in overrides:
            del overrides["job_noise_clamp"]

        frames_cfg_label = "auto" if cfg_frames is None else str(cfg_frames)
        frames_str = _wizard_execute(inquirer.text(
            message=f"Frames after EOS [0–50] (0=auto; blank = {frames_cfg_label}, inherited from config):",
            default=str(overrides.get("job_frames_after_eos", "")),
            validate=_RangeValidator(min_val=0, max_val=50, float_ok=False, allow_blank=True),
        )).strip()
        if frames_str:
            overrides["job_frames_after_eos"] = int(frames_str)
        elif "job_frames_after_eos" in overrides:
            del overrides["job_frames_after_eos"]

        state = {**state, "quality_overrides": overrides}
    return state


def _submenu_audio_encoding(state: dict, app_config) -> dict:
    """Audio encoding overrides: bitrate, pauses, chapter title speech."""
    from InquirerPy import inquirer

    overrides = dict(state.get("quality_overrides") or {})
    has_overrides = any(k in overrides for k in ("job_m4b_bitrate", "job_pause_line_ms", "job_pause_chapter_ms"))

    action = _wizard_execute(inquirer.select(
        message="Audio Encoding",
        choices=[
            {"name": f"Keep current ({'custom' if has_overrides else 'defaults'})", "value": "keep"},
            {"name": "Edit encoding settings…", "value": "edit"},
            {"name": "Back", "value": "back"},
        ],
    ))
    if action == "edit":
        cfg_bitrate = getattr(app_config, "m4b_bitrate", "96k")
        cfg_pause_line = getattr(app_config, "pause_line_ms", 800)
        cfg_pause_chap = getattr(app_config, "pause_chapter_ms", 2000)

        bitrate_choices = [
            {"name": f"{cfg_bitrate}  (inherited from config)", "value": None},
            {"name": "64k  (small files)", "value": "64k"},
            {"name": "96k", "value": "96k"},
            {"name": "128k", "value": "128k"},
            {"name": "192k", "value": "192k"},
            {"name": "256k  (high quality)", "value": "256k"},
        ]
        bitrate = _wizard_execute(inquirer.select(
            message="M4B bitrate:",
            choices=bitrate_choices,
            default=overrides.get("job_m4b_bitrate"),
        ))
        if bitrate is not None:
            overrides["job_m4b_bitrate"] = bitrate
        elif "job_m4b_bitrate" in overrides:
            del overrides["job_m4b_bitrate"]

        pause_line_str = _wizard_execute(inquirer.text(
            message=f"Pause between lines ms [0–5000] (blank = {cfg_pause_line}, inherited from config):",
            default=str(overrides.get("job_pause_line_ms", "")),
            validate=_RangeValidator(min_val=0, max_val=5000, allow_blank=True),
        )).strip()
        if pause_line_str:
            overrides["job_pause_line_ms"] = int(pause_line_str)
        elif "job_pause_line_ms" in overrides:
            del overrides["job_pause_line_ms"]

        pause_chap_str = _wizard_execute(inquirer.text(
            message=f"Pause between chapters ms [0–30000] (blank = {cfg_pause_chap}, inherited from config):",
            default=str(overrides.get("job_pause_chapter_ms", "")),
            validate=_RangeValidator(min_val=0, max_val=30000, allow_blank=True),
        )).strip()
        if pause_chap_str:
            overrides["job_pause_chapter_ms"] = int(pause_chap_str)
        elif "job_pause_chapter_ms" in overrides:
            del overrides["job_pause_chapter_ms"]

        state = {**state, "quality_overrides": overrides}
    return state


def _submenu_post_processing(state: dict, app_config) -> dict:
    """Per-job post-processing: enable or disable the effects chain for this job."""
    from InquirerPy import inquirer

    current_override = state.get("pp_enabled_override")
    pp_cfg = getattr(app_config, "post_processing", None)
    global_enabled = getattr(pp_cfg, "enabled", True) if pp_cfg else True

    if current_override is False:
        current_label = "disabled for this job"
    elif current_override is True:
        current_label = "enabled for this job"
    else:
        current_label = f"inherit from config ({'on' if global_enabled else 'off'})"

    action = _wizard_execute(inquirer.select(
        message=f"Audio Post-Processing  [{current_label}]",
        choices=[
            {"name": f"Keep current ({current_label})", "value": "keep"},
            {"name": "Enable for this job (override config)", "value": "enable"},
            {"name": "Disable for this job (override config)", "value": "disable"},
            {"name": f"{'on' if global_enabled else 'off'}  (inherited from config, clear override)", "value": "inherit"},
            {"name": "Back", "value": "back"},
        ],
    ))
    if action == "enable":
        state = {**state, "pp_enabled_override": True}
    elif action == "disable":
        state = {**state, "pp_enabled_override": False}
    elif action == "inherit":
        state = {**state, "pp_enabled_override": None}
    return state


def _submenu_text_preprocessing(state: dict, app_config) -> dict:
    """Text preprocessing overrides: apostrophe/contraction handling."""
    from InquirerPy import inquirer

    overrides = dict(state.get("quality_overrides") or {})

    cfg_apostrophe = getattr(app_config, "apostrophe_mode", "expand_contractions")
    cfg_apostrophe_str = cfg_apostrophe.value if hasattr(cfg_apostrophe, "value") else str(cfg_apostrophe)
    apostrophe_choices = [
        {"name": f"{cfg_apostrophe_str}  (inherited from config)", "value": None},
        {"name": "expand_contractions  (expand: don’t → do not)", "value": "expand_contractions"},
        {"name": "keep  (pass text unchanged)", "value": "keep"},
        {"name": "remove_contractions  (strip apostrophe from contractions only)", "value": "remove_contractions"},
        {"name": "always_remove  (strip every apostrophe, including names)", "value": "always_remove"},
    ]
    apostrophe_mode = _wizard_execute(inquirer.select(
        message="Apostrophe/contraction mode:",
        choices=apostrophe_choices,
        default=overrides.get("job_apostrophe_mode"),
    ))
    if apostrophe_mode is not None:
        from kenkui.utils import ApostropheMode
        overrides["job_apostrophe_mode"] = ApostropheMode(apostrophe_mode)
    elif "job_apostrophe_mode" in overrides:
        del overrides["job_apostrophe_mode"]
    return {**state, "quality_overrides": overrides}


def _submenu_output_location(state: dict, app_config) -> dict:
    """Set per-job output directory."""
    from InquirerPy import inquirer
    from kenkui.services.workflow_service import reset_output_location

    current = state.get("output_dir") or str(Path(state["_book_path"]).parent)

    action = _wizard_execute(inquirer.select(
        message=f"Output Location  [{current}]",
        choices=[
            {"name": f"Keep current ({current})", "value": "keep"},
            {"name": "Edit output directory…", "value": "edit"},
            {"name": "Reset to default", "value": "reset"},
            {"name": "Back", "value": "back"},
        ],
    ))
    if action == "reset":
        state = reset_output_location(state, app_config)
    elif action == "edit":
        new_dir = _wizard_execute(inquirer.text(
            message="Output directory (absolute path, or blank to reset to default):",
            default=current,
        )).strip()
        if new_dir:
            state = {**state, "output_dir": new_dir}
        else:
            state = reset_output_location(state, app_config)
    return state


def _submenu_manage_voices(state: dict, app_config) -> None:
    """Voice management submenu (list/filter voices). Does not modify job state."""
    from InquirerPy import inquirer
    from .voices import _voices_interactive

    _voices_interactive()
    _wizard_execute(inquirer.text(message="Press Enter to return to job setup..."))


def _state_to_job_kwargs(state: dict) -> dict:
    """Convert hub-and-spoke state dict to job kwargs."""
    from kenkui.services.job_service import build_job_kwargs_from_state
    return build_job_kwargs_from_state(state)


def _run_confirmation_screen(book_path: Path, app_config) -> "dict | None":
    """Hub-and-spoke confirmation screen. Returns job kwargs or None if cancelled."""
    from InquirerPy import inquirer
    from .add_profile import load_last_profile, save_last_profile

    profile = load_last_profile()
    state = _init_state_from_profile(book_path, app_config, profile)

    while True:
        _print_status_panel(state, app_config)
        choices = _build_confirmation_choices(state, app_config)
        action = _wizard_execute(inquirer.select(
            message=f"kentui — {book_path.name}",
            choices=choices,
            max_height="60%",
        ))

        if action == "submit":
            save_last_profile(_state_to_profile(state))
            return _state_to_job_kwargs(state)
        elif action == "voice":
            state = _edit_narrator_voice(state, app_config)
        elif action == "chapters":
            state = _submenu_chapters(state, app_config)
        elif action == "series":
            state = _edit_series(state)
        elif action == "narration":
            state = _submenu_narration_mode(state, app_config)
        elif action == "advanced":
            state = _submenu_advanced(state, app_config)
        elif action is None or action == "cancel":
            return None


# ---------------------------------------------------------------------------
# ProcessingConfig builder
# ---------------------------------------------------------------------------


def _build_processing_config(job_kwargs: dict, app_config) -> "ProcessingConfig":
    """Convert wizard job_kwargs + AppConfig into a ProcessingConfig for kenkui.run_job()."""
    from kenkui.models import (
        ChapterPreset,
        ChapterSelection,
        PostProcessingConfig,
        ProcessingConfig,
    )
    from kenkui.chapter_filter import ChapterFilter, FilterOperation
    from kenkui.utils import ApostropheMode

    ebook_path = Path(job_kwargs["ebook_path"])
    output_path = Path(job_kwargs.get("output_path") or str(ebook_path.parent))

    # Chapter selection → filter operations
    chapter_sel_dict = job_kwargs.get("chapter_selection") or {}
    chapter_selection = ChapterSelection.from_dict(chapter_sel_dict)

    if chapter_selection.preset in (ChapterPreset.MANUAL, ChapterPreset.CUSTOM) and chapter_selection.included:
        chapter_filters = [FilterOperation(type="index", value=str(idx)) for idx in chapter_selection.included]
    elif chapter_selection.preset.value in ChapterFilter.PRESETS:
        chapter_filters = [FilterOperation(type="preset", value=chapter_selection.preset.value)]
    else:
        chapter_filters = [FilterOperation(type="preset", value="content-only")]

    def _pick(job_key, cfg_attr, default=None):
        v = job_kwargs.get(job_key)
        return v if v is not None else getattr(app_config, cfg_attr, default)

    # Post-processing config
    app_pp = getattr(app_config, "post_processing", None)
    if app_pp is not None:
        pp_dict = app_pp.to_dict() if hasattr(app_pp, "to_dict") else app_pp.model_dump(mode="json", exclude_none=True)
        pp_config = PostProcessingConfig.from_dict(pp_dict)
    else:
        pp_config = PostProcessingConfig()

    job_pp_enabled = job_kwargs.get("job_post_processing_enabled")
    if job_pp_enabled is not None:
        pp_config = PostProcessingConfig.from_dict({**pp_config.to_dict(), "enabled": job_pp_enabled})

    apostrophe_mode = job_kwargs.get("job_apostrophe_mode") or getattr(app_config, "apostrophe_mode", None)
    if apostrophe_mode is None:
        apostrophe_mode = ApostropheMode.EXPAND_CONTRACTIONS
    elif isinstance(apostrophe_mode, str):
        apostrophe_mode = ApostropheMode(apostrophe_mode)

    annotated_chapters_path = (
        Path(job_kwargs["annotated_chapters_path"])
        if job_kwargs.get("annotated_chapters_path")
        else None
    )

    return ProcessingConfig(
        voice=job_kwargs.get("voice") or getattr(app_config, "default_voice", "alba"),
        ebook_path=ebook_path,
        output_path=output_path,
        pause_line_ms=_pick("job_pause_line_ms", "pause_line_ms", 800),
        pause_chapter_ms=_pick("job_pause_chapter_ms", "pause_chapter_ms", 2000),
        workers=getattr(app_config, "workers", 2),
        m4b_bitrate=job_kwargs.get("job_m4b_bitrate") or getattr(app_config, "m4b_bitrate", "96k"),
        keep_temp=getattr(app_config, "keep_temp", False),
        debug_html=False,
        chapter_filters=chapter_filters,
        speak_chapter_titles=_pick("job_speak_chapter_titles", "speak_chapter_titles", True),
        pause_before_chapter_title_ms=_pick("job_pause_before_chapter_title_ms", "pause_before_chapter_title_ms", 2000),
        pause_after_chapter_title_ms=_pick("job_pause_after_chapter_title_ms", "pause_after_chapter_title_ms", 3000),
        temp=_pick("job_temp", "temp", 0.7),
        lsd_decode_steps=_pick("job_lsd_decode_steps", "lsd_decode_steps", 1),
        noise_clamp=_pick("job_noise_clamp", "noise_clamp", None),
        eos_threshold=_pick("job_eos_threshold", "eos_threshold", -4.0),
        frames_after_eos=_pick("job_frames_after_eos", "frames_after_eos", None),
        speaker_voices=job_kwargs.get("speaker_voices") or {},
        annotated_chapters_path=annotated_chapters_path,
        chapter_voices=job_kwargs.get("chapter_voices") or {},
        post_processing=pp_config,
        _included_indices=chapter_selection.included or [],
        apostrophe_mode=apostrophe_mode,
    )


# ---------------------------------------------------------------------------
# Job runner
# ---------------------------------------------------------------------------


def _run_job_with_progress(config) -> int:
    """Call kenkui.run_job() with a Rich progress bar. Returns 0 on success, 1 on failure."""
    import kenkui

    with Progress(
        SpinnerColumn(),
        BarColumn(),
        TextColumn("[progress.percentage]{task.percentage:>5.1f}%"),
        TextColumn("{task.description}"),
        TimeElapsedColumn(),
        console=console,
    ) as prog:
        task = prog.add_task("Starting…", total=100)

        def _on_progress(percent: float, chapter: str, eta: int):
            desc = chapter[:60] if chapter else "Processing…"
            prog.update(task, completed=percent, description=desc)

        try:
            ok = kenkui.run_job(config, progress_callback=_on_progress)
        except Exception as exc:
            console.print(f"\n[red]Job failed: {exc}[/red]")
            return 1

    if ok:
        out = str(config.output_path) if config.output_path else "(see output dir)"
        console.print(f"\n[green]Done! Output: {out}[/green]")
        return 0
    else:
        console.print("\n[red]Job failed.[/red]")
        return 1


# ---------------------------------------------------------------------------
# Multi-voice pre-processing (scan + assignment before job)
# ---------------------------------------------------------------------------


def _prepare_multi_voice(job_kwargs: dict, book_path: Path, app_config) -> dict:
    """For multi-voice jobs: run fast_scan, prompt voice assignments, run attribution.

    Returns updated job_kwargs with speaker_voices and annotated_chapters_path set.
    Falls back to single-voice on failure.
    """
    nlp_provider = job_kwargs.get("job_nlp_provider") or getattr(app_config, "nlp_provider", "ollama")
    nlp_model = job_kwargs.get("job_nlp_model") or getattr(app_config, "nlp_model", "llama3.2")
    series_slug = job_kwargs.get("series_slug")
    narrator_voice = job_kwargs.get("voice", "alba")

    # Stage 1-2: character scan
    scan_result = _run_fast_scan(book_path, nlp_model, nlp_provider=nlp_provider, series_slug=series_slug)
    if scan_result is None:
        console.print("[yellow]NLP scan failed. Falling back to single-voice mode.[/yellow]")
        job_kwargs = {**job_kwargs, "narration_mode": "single"}
        job_kwargs.pop("speaker_voices", None)
        return job_kwargs

    # Interactive voice assignment
    speaker_voices = _prompt_multivoice_character_voices(
        scan_result,
        narrator_voice,
        excluded_voices=[narrator_voice],
    )
    job_kwargs = {**job_kwargs, "speaker_voices": speaker_voices}

    # Stage 3-4: full attribution (needed for per-segment speaker labels)
    _, cache_path = _run_full_analysis(book_path, nlp_model, nlp_provider=nlp_provider, series_slug=series_slug)
    if cache_path:
        job_kwargs = {**job_kwargs, "annotated_chapters_path": str(cache_path)}
    else:
        console.print("[yellow]Attribution failed. Multi-voice may not work correctly.[/yellow]")

    return job_kwargs


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------


def cmd_add(args) -> int:
    """Handle 'kentui add book.epub [-c config] [--flag overrides]'."""
    book_path: Path = args.book
    if not book_path.exists():
        console.print(f"[red]Error: file not found: {book_path}[/red]")
        return 1
    if book_path.suffix.lower() not in {".epub", ".mobi", ".fb2", ".azw", ".azw3", ".azw4"}:
        console.print(f"[red]Error: unrecognised ebook format: {book_path.suffix}[/red]")
        return 1

    try:
        app_config = _load_config(args)

        if getattr(args, "config", None):
            # Headless mode: run with config defaults, no wizard.
            from kenkui.services.job_service import build_headless_job_kwargs
            job_kwargs = build_headless_job_kwargs(args, app_config)
            console.print(f"[bold]Book:[/bold]    {book_path}")
            config = _build_processing_config(job_kwargs, app_config)
            return _run_job_with_progress(config)

        # Interactive wizard
        job_kwargs = _run_confirmation_screen(book_path, app_config)
        if job_kwargs is None:
            return 0  # User cancelled

        # Multi-voice: run NLP scan + voice assignment + attribution before main job
        if job_kwargs.get("narration_mode") == "multi":
            job_kwargs = _prepare_multi_voice(job_kwargs, book_path, app_config)

        config = _build_processing_config(job_kwargs, app_config)
        return _run_job_with_progress(config)

    except (KeyboardInterrupt, EOFError):
        console.print("\n[dim]Cancelled.[/dim]")
        return 0


# Backwards-compat alias
cmd_convert = cmd_add


def configure_provider() -> None:
    """Interactive wizard to configure a cloud NLP provider and save credentials."""
    from InquirerPy import inquirer
    from kenkui.config import (
        CREDENTIALS_PATH,
        ProviderCredentials,
        load_provider_credentials,
        save_provider_credentials,
    )

    _PROVIDER_MODELS = {
        "anthropic": "claude-sonnet-4-6",
        "openai": "gpt-4o",
        "google": "gemini/gemini-2.0-flash",
    }

    provider = inquirer.select(
        message="Select NLP provider:",
        choices=["anthropic", "openai", "google"],
    ).execute()

    api_key = inquirer.secret(
        message=f"Enter your {provider} API key:",
    ).execute()

    default_model = inquirer.text(
        message="Default model (press Enter to use recommended):",
        default=_PROVIDER_MODELS.get(provider, ""),
    ).execute()

    existing = load_provider_credentials()
    existing[provider] = ProviderCredentials(
        api_key=api_key,
        default_model=default_model or _PROVIDER_MODELS.get(provider, ""),
    )
    save_provider_credentials(existing)

    print(f"\nCredentials for '{provider}' saved to {CREDENTIALS_PATH}")
    print(f"  Set nlp_provider = \"{provider}\" in your kenkui config to use it.\n")
