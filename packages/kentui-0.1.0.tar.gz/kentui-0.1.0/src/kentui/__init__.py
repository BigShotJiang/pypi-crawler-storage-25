"""kentui — Interactive CLI for kenkui ebook-to-audiobook conversion."""

import importlib.metadata

try:
    __version__ = importlib.metadata.version("kentui")
except importlib.metadata.PackageNotFoundError:
    __version__ = "0.1.0"

__author__ = "Sumner MacArthur"
__license__ = "GPL-3.0"
