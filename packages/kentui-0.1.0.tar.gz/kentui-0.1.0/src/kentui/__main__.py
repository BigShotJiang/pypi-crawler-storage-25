"""
kentui — Ebook to Audiobook Converter (local, in-process)
Entry point / sub-command dispatcher.

Sub-commands
------------
  kentui book.epub                    Interactive wizard → run_job() in-process
  kentui book.epub -c config.toml     Headless: run_job() → Rich progress → exit 0/1

  kentui add book.epub                Interactive wizard → run_job() in-process
  kentui add book.epub -c config.toml Headless: run_job()

  kentui config [name]                Create/edit a named config
  kentui voices                       Interactive voice TUI
  kentui voices list / fetch / download / exclude / include / audition
  kentui cache                        Clear cache files

  kentui parse book.epub              Stage 1-2 NLP only (entity scan)
  kentui attribute book.epub          Stage 3-4 NLP attribution only
  kentui generate book.epub           TTS + stitch only (requires prior NLP cache)
"""

from __future__ import annotations

import logging
import multiprocessing
import sys
from pathlib import Path

# MUST set multiprocessing start method BEFORE any multiprocessing usage.
if __name__ == "__main__":
    try:
        multiprocessing.set_start_method("spawn", force=True)
    except RuntimeError:
        pass

import argparse

DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = 45365

EBOOK_EXTENSIONS = {".epub", ".mobi", ".fb2", ".azw", ".azw3", ".azw4"}


# ---------------------------------------------------------------------------
# Argument parser
# ---------------------------------------------------------------------------


def _build_parser() -> argparse.ArgumentParser:
    from . import __version__

    parser = argparse.ArgumentParser(
        prog="kentui",
        description=(
            "kentui — Ebook to Audiobook Converter (local, in-process).\n\n"
            "Pass an ebook path directly to run the interactive wizard.\n\n"
            "Sub-commands: add, config, voices, cache, parse, attribute, generate"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    parser.add_argument("--verbose", action="store_true", help="Enable DEBUG logging.")
    parser.add_argument("--log-file", default=None, metavar="PATH")
    parser.add_argument(
        "-c",
        "--config",
        default=None,
        metavar="PATH_OR_NAME",
        help="Config file path or bare name. Triggers headless mode when combined with a book path.",
    )
    parser.add_argument("-o", "--output", default=None, metavar="DIR")

    sub = parser.add_subparsers(dest="command")

    # ---- kentui add --------------------------------------------------------
    add_p = sub.add_parser("add", help="Convert a book (interactive wizard).")
    add_p.add_argument("book", type=Path, help="Path to the ebook file.")
    add_p.add_argument("-c", "--config", default=None, metavar="PATH_OR_NAME")
    add_p.add_argument("-o", "--output", default=None, metavar="DIR")
    add_p.add_argument(
        "--apostrophe-mode",
        choices=["keep", "always_remove", "remove_contractions", "expand_contractions"],
        default=None,
        dest="apostrophe_mode",
        metavar="MODE",
    )

    # ---- kentui config -----------------------------------------------------
    cfg_p = sub.add_parser("config", help="Create or edit a config file.")
    cfg_p.add_argument(
        "path",
        nargs="?",
        default=None,
        metavar="PATH_OR_NAME",
        help="Destination name (no .toml) or full path. Defaults to 'default'.",
    )

    # ---- kentui voices -----------------------------------------------------
    voices_p = sub.add_parser("voices", help="List and manage available voices.")
    voices_sub = voices_p.add_subparsers(dest="voices_command")

    voices_list_p = voices_sub.add_parser("list", help="List available voices.")
    voices_list_p.add_argument("--gender", default=None)
    voices_list_p.add_argument("--accent", default=None)
    voices_list_p.add_argument("--dataset", default=None)
    voices_list_p.add_argument(
        "--source", default=None, choices=["compiled", "builtin", "uncompiled"]
    )

    voices_sub.add_parser("fetch", help="Download uncompiled voices from HuggingFace.")

    voices_dl = voices_sub.add_parser("download", help="Download compiled voices from HuggingFace.")
    voices_dl.add_argument("--force", action="store_true")

    voices_exc = voices_sub.add_parser("exclude", help="Exclude a voice from auto-assignment.")
    voices_exc.add_argument("voice", help="Voice name to exclude.")

    voices_inc = voices_sub.add_parser("include", help="Re-include a previously excluded voice.")
    voices_inc.add_argument("voice", help="Voice name to re-include.")

    voices_cast = voices_sub.add_parser("cast", help="Show character→voice cast for a book.")
    voices_cast.add_argument("title", help="Book title (fuzzy matched).")

    voices_aud = voices_sub.add_parser("audition", help="Synthesize a voice preview.")
    voices_aud.add_argument("voice", help="Voice name to audition.")
    voices_aud.add_argument("--text", default=None, metavar="TEXT")

    # ---- kentui cache -------------------------------------------------------
    cache_p = sub.add_parser("cache", help="Clear kenkui cache files.")
    cache_p.add_argument("-y", "--yes", action="store_true", help="Skip confirmation prompt.")

    # ---- kentui parse / attribute / generate --------------------------------
    for cmd, help_text in [
        ("parse", "Run Stage 1-2 NLP (entity scan) and cache the roster."),
        ("attribute", "Run Stage 3-4 NLP attribution using a cached roster."),
        ("generate", "Run TTS + stitch using a cached NLP result."),
    ]:
        step_p = sub.add_parser(cmd, help=help_text)
        step_p.add_argument("book", type=Path, help="Path to the ebook file.")
        step_p.add_argument("-c", "--config", default=None, metavar="PATH_OR_NAME")
        step_p.add_argument("-o", "--output", default=None, metavar="DIR")

    return parser


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def _is_bare_book_invocation() -> bool:
    for arg in sys.argv[1:]:
        if arg.startswith("-"):
            continue
        return Path(arg).suffix.lower() in EBOOK_EXTENSIONS
    return False


def _ensure_voices() -> None:
    """Download compiled voices on first run if not present."""
    from rich.console import Console
    from rich.panel import Panel
    from kenkui.voice_download import voices_are_present, download_voices

    console = Console()
    try:
        if not voices_are_present():
            console.print(Panel(
                "[bold]Voice files not found.[/bold]\n"
                "Downloading compiled voices from HuggingFace (~440 MB)…\n"
                "[dim]This only happens once. Use 'kentui voices download' to re-download.[/dim]",
                title="First Run Setup",
                border_style="cyan",
            ))
            download_voices()
            console.print("[green]✓ Voices downloaded successfully.[/green]")
    except Exception as exc:
        console.print(f"[yellow]Warning: Could not download voices: {exc}[/yellow]")
        console.print("[dim]8 built-in voices are still available. Run 'kentui voices download' later.[/dim]")


def main() -> None:
    if _is_bare_book_invocation():
        # Treat as implicit `kentui add <book>`
        parser = _build_parser()
        args = parser.parse_args(["add"] + sys.argv[1:])
        args.command = "add"
    else:
        parser = _build_parser()
        args = parser.parse_args()

    handlers: list[logging.Handler] = [logging.StreamHandler(sys.stderr)]
    if getattr(args, "log_file", None):
        handlers.append(logging.FileHandler(args.log_file))
    logging.basicConfig(
        level=logging.DEBUG if getattr(args, "verbose", False) else logging.WARNING,
        format="%(levelname)s [%(name)s] %(message)s",
        handlers=handlers,
    )

    command = getattr(args, "command", None)
    voices_cmd = getattr(args, "voices_command", None)

    if not (command == "voices" and voices_cmd == "download"):
        _ensure_voices()

    if command == "add" or command is None:
        from .cli.add import cmd_add

        book = getattr(args, "book", None)
        if book is None:
            parser.print_help()
            sys.exit(0)
        sys.exit(cmd_add(args))

    elif command == "config":
        from .cli.config import cmd_config

        sys.exit(cmd_config(args))

    elif command == "voices":
        from .cli.voices import (
            cmd_voices_list,
            cmd_voices_fetch,
            cmd_voices_download,
            cmd_voices_exclude,
            cmd_voices_include,
            cmd_voices_cast,
            cmd_voices_audition,
            cmd_voices_tui,
        )

        if voices_cmd == "list":
            cmd_voices_list(args)
        elif voices_cmd == "fetch":
            cmd_voices_fetch(args)
        elif voices_cmd == "download":
            sys.exit(cmd_voices_download(args))
        elif voices_cmd == "exclude":
            cmd_voices_exclude(args)
        elif voices_cmd == "include":
            cmd_voices_include(args)
        elif voices_cmd == "cast":
            cmd_voices_cast(args)
        elif voices_cmd == "audition":
            cmd_voices_audition(args)
        else:
            cmd_voices_tui(args)
        sys.exit(0)

    elif command == "cache":
        from .cli.cache import cmd_cache

        cmd_cache(args)
        sys.exit(0)

    elif command in ("parse", "attribute", "generate"):
        from .cli.steps import cmd_step

        sys.exit(cmd_step(command, args))

    else:
        parser.print_help()
        sys.exit(0)


if __name__ == "__main__":
    main()
