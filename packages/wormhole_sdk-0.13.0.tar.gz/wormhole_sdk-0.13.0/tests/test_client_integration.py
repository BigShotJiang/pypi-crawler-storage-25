"""Integration tests for external tool registration in SDK client."""

from __future__ import annotations

from typing import Any, AsyncGenerator

from wormhole_sdk.adapter.events import FinishReason, ModelEvent, ModelEventType
from wormhole_sdk.client import WormholeClient
from wormhole_sdk.config import SDKConfig
from wormhole_sdk.tools import TOOL_BASH


class FakeAdapter:
    @property
    def provider_name(self: Any) -> str:
        return "fake"

    @property
    def model_id(self: Any) -> str:
        return "fake-model"

    async def stream(
        self: Any,
        messages: Any,
        tools: Any = None,
        system_prompt: Any = None,
        max_tokens: Any = None,
    ) -> AsyncGenerator[Any, None]:
        yield ModelEvent(
            ModelEventType.STOP, {"finish_reason": FinishReason.END_TURN.value}
        )

    async def count_tokens(self: Any, messages: Any) -> int:
        return len(messages)


def test_external_tool_registration_flow() -> None:
    config = SDKConfig(
        adapter=FakeAdapter(),
        tools=[TOOL_BASH, "sample_echo"],
        tool_config_paths=["tests.fixtures.sample_tools.single_tool"],
        persist_sessions=False,
    )
    client = WormholeClient(config)
    registered = {tool.tool_id for tool in client.list_tools()}
    assert TOOL_BASH in registered
    assert "sample_echo" in registered


def test_backward_compatibility_empty_tool_config_paths() -> None:
    config = SDKConfig(
        adapter=FakeAdapter(),
        tools=[TOOL_BASH],
        tool_config_paths=[],
        persist_sessions=False,
    )
    client = WormholeClient(config)
    registered = {tool.tool_id for tool in client.list_tools()}
    assert registered == {TOOL_BASH}
