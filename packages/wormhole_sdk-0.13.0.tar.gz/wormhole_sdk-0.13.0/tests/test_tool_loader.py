"""Tests for external tool loader helpers."""

import sys
from pathlib import Path
from types import ModuleType
from typing import Any, cast

import pytest
from wormhole_core.schemas.tools import ToolDefinition

from wormhole_sdk.errors import ToolErrorCode, ToolLoadError
from wormhole_sdk.tool_loader import (
    ToolFactoryProtocol,
    ToolHandlerContext,
    _load_module,
    create_external_handlers,
    discover_external_tools,
    validate_tool_config,
)
from wormhole_sdk.tools import TOOL_BASH


def test_discover_single_tool() -> None:
    discovered = discover_external_tools(["tests.fixtures.sample_tools.single_tool"])
    assert "sample_echo" in discovered
    tool = discovered["sample_echo"]
    assert tool.module_path == "tests.fixtures.sample_tools.single_tool"
    assert tool.definition.tool_id == "sample_echo"


def test_discover_multi_tool() -> None:
    discovered = discover_external_tools(["tests.fixtures.sample_tools.multi_tool"])
    assert set(discovered.keys()) == {"sample_alpha", "sample_beta"}


def test_create_handlers_for_selected_tools() -> None:
    discovered = discover_external_tools(["tests.fixtures.sample_tools.multi_tool"])
    context = ToolHandlerContext(root_dir=Path.cwd())
    handlers = create_external_handlers(
        discovered,
        ["sample_alpha"],
        context,
    )
    assert set(handlers.keys()) == {"sample_alpha"}


def test_mixed_builtin_and_external_tools() -> None:
    validate_tool_config(
        tools=[TOOL_BASH, "sample_echo"],
        tool_config_paths=["tests.fixtures.sample_tools.single_tool"],
        builtin_tool_ids={TOOL_BASH},
    )


def test_protocol_compliance() -> None:
    module = _load_module("tests.fixtures.sample_tools.with_metadata")
    assert isinstance(module, ToolFactoryProtocol)


def test_api_version_captured() -> None:
    discovered = discover_external_tools(["tests.fixtures.sample_tools.with_metadata"])
    assert discovered["sample_meta"].api_version == "1.0.0"


def test_import_error_message() -> None:
    with pytest.raises(ToolLoadError) as excinfo:
        discover_external_tools(["tests.fixtures.sample_tools.does_not_exist"])
    err = excinfo.value
    assert err.error_code == ToolErrorCode.TOOL_IMPORT_ERROR
    assert "does_not_exist" in str(err)


def test_missing_factory_error_message() -> None:
    with pytest.raises(ToolLoadError) as excinfo:
        discover_external_tools(["tests.fixtures.sample_tools.missing_create_tools"])
    err = excinfo.value
    assert err.error_code == ToolErrorCode.TOOL_MISSING_FACTORY
    assert "create_tools" in str(err)


def test_validation_error_message() -> None:
    with pytest.raises(ToolLoadError) as excinfo:
        discover_external_tools(["tests.fixtures.sample_tools.invalid_definition"])
    err = excinfo.value
    assert err.error_code == ToolErrorCode.TOOL_VALIDATION_ERROR
    assert "invalid_definition_tool" in str(err)


def test_api_version_mismatch_error_message() -> None:
    with pytest.raises(ToolLoadError) as excinfo:
        discover_external_tools(["tests.fixtures.sample_tools.incompatible_version"])
    err = excinfo.value
    assert err.error_code == ToolErrorCode.TOOL_API_VERSION_MISMATCH
    assert "API version mismatch" in str(err)


def test_empty_tools_list() -> None:
    validate_tool_config(
        tools=[],
        tool_config_paths=[],
        builtin_tool_ids={TOOL_BASH},
    )
    handlers = create_external_handlers(
        discovered_tools={},
        tool_ids=[],
        context=ToolHandlerContext(root_dir=Path.cwd()),
    )
    assert handlers == {}


def test_tool_not_in_registration_list() -> None:
    discovered = discover_external_tools(["tests.fixtures.sample_tools.multi_tool"])
    handlers = create_external_handlers(
        discovered_tools=discovered,
        tool_ids=["sample_alpha"],
        context=ToolHandlerContext(root_dir=Path.cwd()),
    )
    assert set(handlers.keys()) == {"sample_alpha"}
    assert "sample_beta" not in handlers


def test_duplicate_tool_config_paths() -> None:
    with pytest.raises(ToolLoadError) as excinfo:
        discover_external_tools(
            [
                "tests.fixtures.sample_tools.single_tool",
                "tests.fixtures.sample_tools.single_tool",
            ]
        )
    err = excinfo.value
    assert err.error_code == ToolErrorCode.TOOL_LOAD_ERROR
    assert "Duplicate module paths" in err.message


def test_handler_only_for_selected_tools() -> None:
    module = ModuleType("tests.dynamic.partial_handlers")

    def create_tools() -> list[ToolDefinition]:
        return [
            ToolDefinition(
                tool_id="partial_one",
                name="partial_one",
                schema={"type": "object"},
            ),
            ToolDefinition(
                tool_id="partial_two",
                name="partial_two",
                schema={"type": "object"},
            ),
        ]

    async def partial_one_handler(args: dict[str, object]) -> str:
        return str(args)

    def create_handlers(context: ToolHandlerContext) -> dict[str, object]:
        _ = context
        return {"partial_one": partial_one_handler}

    module_any = cast(Any, module)
    module_any.create_tools = create_tools
    module_any.create_handlers = create_handlers
    sys.modules[module.__name__] = module
    discovered = discover_external_tools([module.__name__])
    handlers = create_external_handlers(
        discovered_tools=discovered,
        tool_ids=["partial_one"],
        context=ToolHandlerContext(root_dir=Path.cwd()),
    )
    assert set(handlers.keys()) == {"partial_one"}
    with pytest.raises(ToolLoadError) as excinfo:
        create_external_handlers(
            discovered_tools=discovered,
            tool_ids=["partial_two"],
            context=ToolHandlerContext(root_dir=Path.cwd()),
        )
    assert excinfo.value.error_code == ToolErrorCode.TOOL_HANDLER_ERROR


def test_order_independent_registration() -> None:
    discovered = discover_external_tools(["tests.fixtures.sample_tools.multi_tool"])
    forward = create_external_handlers(
        discovered_tools=discovered,
        tool_ids=["sample_alpha", "sample_beta"],
        context=ToolHandlerContext(root_dir=Path.cwd()),
    )
    reverse = create_external_handlers(
        discovered_tools=discovered,
        tool_ids=["sample_beta", "sample_alpha"],
        context=ToolHandlerContext(root_dir=Path.cwd()),
    )
    assert (
        set(forward.keys())
        == set(reverse.keys())
        == {
            "sample_alpha",
            "sample_beta",
        }
    )
