"""Adapter event types and payloads for streaming responses."""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Mapping

from wormhole_core.logging import log_parameter


class ModelEventType(str, Enum):
    """Streaming event types from model adapters.

    >>> ModelEventType.TEXT_DELTA.value
    'text_delta'
    """

    TEXT_DELTA = "text_delta"
    TOOL_CALL = "tool_call"
    TOOL_CALL_DELTA = "tool_call_delta"
    TOOL_RESULT = "tool_result"
    USAGE = "usage"
    STOP = "stop"
    ERROR = "error"


class FinishReason(str, Enum):
    """Finish reasons for model generation.

    >>> FinishReason.END_TURN.value
    'end_turn'
    >>> FinishReason.STOP_SEQUENCE.value
    'stop'
    """

    END_TURN = "end_turn"
    TOOL_USE = "tool_use"
    MAX_TOKENS = "max_tokens"
    STOP_SEQUENCE = "stop"


@dataclass(frozen=True)
class ModelEvent:
    """Streaming event emitted by a model adapter.

    >>> event = ModelEvent(type=ModelEventType.TEXT_DELTA, payload={"text": "hi"})
    >>> event.type
    <ModelEventType.TEXT_DELTA: 'text_delta'>
    >>> event.payload["text"]
    'hi'
    """

    type: ModelEventType
    payload: Mapping[str, Any]
    timestamp: float = field(default_factory=lambda: time.time())

    def __post_init__(self) -> None:
        log_parameter(
            "ModelEvent.__init__",
            event_type=self.type.value,
        )


__all__ = ["FinishReason", "ModelEvent", "ModelEventType"]
