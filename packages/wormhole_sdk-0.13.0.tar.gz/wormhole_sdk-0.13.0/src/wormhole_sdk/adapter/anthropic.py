"""Anthropic adapter implementation."""

from __future__ import annotations

import time
from typing import TYPE_CHECKING, Any, AsyncIterator, Mapping

from wormhole_core.logging import (
    log_branch,
    log_loop_iteration,
    log_parameter,
    log_timing,
)
from wormhole_core.schemas.messages import Message, PartType
from wormhole_core.schemas.tools import ToolDefinition

from ..errors import (
    AuthenticationError,
    InvalidRequestError,
    ModelError,
    ProviderError,
    RateLimitError,
)
from .events import FinishReason, ModelEvent, ModelEventType

if TYPE_CHECKING:  # pragma: no cover
    from anthropic import AsyncAnthropic as _AsyncAnthropicType
else:
    _AsyncAnthropicType = object

try:  # pragma: no cover - depends on optional dependency for tests
    from anthropic import AsyncAnthropic
except ImportError:  # pragma: no cover - optional dependency
    AsyncAnthropic = None  # type: ignore[misc,assignment]


class AnthropicAdapter:
    """Adapter for Anthropic Claude models.

    >>> adapter = AnthropicAdapter(api_key="sk-test", _client=object())
    >>> adapter.provider_name
    'anthropic'
    """

    def __init__(
        self,
        *,
        api_key: str | None = None,
        model_name: str = "claude-sonnet-4-20250514",
        base_url: str | None = None,
        _client: object | None = None,
    ) -> None:
        self._api_key = api_key
        self._model_name = model_name
        self._base_url = base_url
        self._client: _AsyncAnthropicType
        if _client is not None:
            self._client = _client  # type: ignore[assignment]
        else:
            if AsyncAnthropic is None:
                raise ImportError("anthropic is required for AnthropicAdapter")
            self._client = AsyncAnthropic(api_key=api_key, base_url=base_url)
        self._tool_call_ids_by_index: dict[int, str] = {}

    @property
    def provider_name(self) -> str:
        return "anthropic"

    @property
    def model_id(self) -> str:
        return self._model_name

    def with_model(self, model_name: str) -> "AnthropicAdapter":
        return AnthropicAdapter(
            api_key=self._api_key,
            model_name=model_name,
            base_url=self._base_url,
            _client=self._client,
        )

    async def stream(
        self,
        messages: list[Message],
        tools: list[ToolDefinition] | None = None,
        system_prompt: str | None = None,
        max_tokens: int | None = None,
    ) -> AsyncIterator[ModelEvent]:
        """Stream a completion from Anthropic."""
        if AsyncAnthropic is None:
            log_branch(
                "AnthropicAdapter.stream",
                "dependency_missing",
                call_id=self._model_name,
            )
            yield self._error_event(
                ProviderError("anthropic is not installed", retryable=False)
            )
            return
        try:
            log_parameter(
                "AnthropicAdapter.stream",
                model=self._model_name,
                message_count=len(messages),
                tool_count=len(tools) if tools else 0,
                has_system_prompt=system_prompt is not None,
                call_id=self._model_name,
            )
            started = time.monotonic()
            anthropic_messages = self._convert_messages(messages)
            anthropic_tools = self._convert_tools(tools) if tools else None
            async with self._client.messages.stream(
                model=self._model_name,
                messages=anthropic_messages,  # type: ignore[arg-type]
                system=system_prompt,  # type: ignore[arg-type]
                tools=anthropic_tools,  # type: ignore[arg-type]
                max_tokens=max_tokens or 4096,
            ) as stream:
                iteration = 0
                async for event in stream:
                    iteration += 1
                    log_loop_iteration(
                        "AnthropicAdapter.stream",
                        "events",
                        iteration,
                        call_id=self._model_name,
                    )
                    mapped = self._convert_event(event)
                    if mapped is not None:
                        log_parameter(
                            "AnthropicAdapter.stream",
                            event_type=mapped.type.value,
                            call_id=self._model_name,
                        )
                        yield mapped
            elapsed_ms = (time.monotonic() - started) * 1000
            log_timing("AnthropicAdapter.stream", elapsed_ms, call_id=self._model_name)
        except Exception as exc:
            log_branch("AnthropicAdapter.stream", "exception", call_id=self._model_name)
            error = self._map_error(exc)
            yield self._error_event(error)

    async def count_tokens(self, messages: list[Message]) -> int:
        log_parameter(
            "AnthropicAdapter.count_tokens",
            model=self._model_name,
            message_count=len(messages),
            call_id=self._model_name,
        )
        result = await self._client.messages.count_tokens(
            model=self._model_name,
            messages=self._convert_messages(messages),  # type: ignore[arg-type]
        )
        if isinstance(result, Mapping):
            return int(result.get("input_tokens", 0))
        return int(getattr(result, "input_tokens", 0))

    def _convert_messages(self, messages: list[Message]) -> list[dict[str, Any]]:
        converted: list[dict[str, Any]] = []
        for msg in messages:
            content: list[dict[str, Any]] = []
            for part in msg.parts:
                if part.type is PartType.TEXT:
                    text = (
                        part.payload.get("text")
                        if isinstance(part.payload, dict)
                        else part.payload
                    )
                    content.append({"type": "text", "text": text})
                elif part.type is PartType.TOOL_CALL:
                    payload = part.payload if isinstance(part.payload, dict) else {}
                    content.append(
                        {
                            "type": "tool_use",
                            "id": payload.get("tool_call_id"),
                            "name": payload.get("tool_name"),
                            "input": payload.get("arguments", {}),
                        }
                    )
                elif part.type is PartType.TOOL_OUTPUT:
                    payload = part.payload if isinstance(part.payload, dict) else {}
                    status = payload.get("status", "")
                    error = payload.get("error")
                    is_error = status == "failed"

                    if is_error and error:
                        # Include error message so LLM can self-correct
                        output_content = f"Error: {error}"
                    else:
                        output_content = str(payload.get("output", ""))

                    tool_result: dict[str, Any] = {
                        "type": "tool_result",
                        "tool_use_id": payload.get("tool_call_id"),
                        "content": output_content,
                    }
                    if is_error:
                        tool_result["is_error"] = True
                    content.append(tool_result)
            converted.append({"role": msg.role.value, "content": content})
        return converted

    def _convert_tools(self, tools: list[ToolDefinition]) -> list[dict[str, Any]]:
        return [
            {
                "name": tool.tool_id,
                "description": tool.description,
                "input_schema": dict(tool.schema),
            }
            for tool in tools
        ]

    def _convert_event(self, event: object) -> ModelEvent | None:
        event_type = self._get_attr(event, "type")
        if event_type == "content_block_start":
            content_block = self._get_attr(event, "content_block") or {}
            block_type = self._get_attr(content_block, "type")
            if block_type == "tool_use":
                tool_call_id = self._get_attr(content_block, "id") or self._get_attr(
                    content_block, "tool_call_id"
                )
                tool_name = self._get_attr(content_block, "name") or self._get_attr(
                    content_block, "tool_name"
                )
                arguments = self._get_attr(content_block, "input") or {}
                index = self._get_attr(event, "index")
                if isinstance(index, int) and tool_call_id:
                    self._tool_call_ids_by_index[index] = str(tool_call_id)
                return ModelEvent(
                    type=ModelEventType.TOOL_CALL,
                    payload={
                        "tool_call_id": str(tool_call_id),
                        "tool_name": tool_name,
                        "arguments": arguments,
                    },
                )
            return None

        if event_type == "content_block_delta":
            delta = self._get_attr(event, "delta") or {}
            delta_type = self._get_attr(delta, "type")
            if delta_type == "text_delta" or self._get_attr(delta, "text") is not None:
                text = self._get_attr(delta, "text") or ""
                return ModelEvent(
                    type=ModelEventType.TEXT_DELTA, payload={"text": text}
                )
            if (
                delta_type == "input_json_delta"
                or self._get_attr(delta, "partial_json") is not None
            ):
                index = self._get_attr(event, "index")
                tool_call_id = None
                if isinstance(index, int):
                    tool_call_id = self._tool_call_ids_by_index.get(index)
                tool_call_id = tool_call_id or self._get_attr(delta, "tool_call_id")
                arguments_delta = self._get_attr(delta, "partial_json") or ""
                return ModelEvent(
                    type=ModelEventType.TOOL_CALL_DELTA,
                    payload={
                        "tool_call_id": tool_call_id,
                        "arguments_delta": arguments_delta,
                    },
                )
            return None

        if event_type == "message_delta":
            usage = self._get_attr(event, "usage")
            if usage is None:
                delta = self._get_attr(event, "delta") or {}
                usage = self._get_attr(delta, "usage")
            if isinstance(usage, dict):
                return ModelEvent(
                    type=ModelEventType.USAGE,
                    payload={
                        "input_tokens": int(usage.get("input_tokens", 0)),
                        "output_tokens": int(usage.get("output_tokens", 0)),
                    },
                )
            return None

        if event_type == "message_stop":
            stop_reason = self._get_attr(event, "stop_reason")
            finish = self._map_stop_reason(stop_reason)
            return ModelEvent(
                type=ModelEventType.STOP, payload={"finish_reason": finish.value}
            )

        return None

    def _map_stop_reason(self, stop_reason: object | None) -> FinishReason:
        reason = str(stop_reason) if stop_reason is not None else ""
        mapping = {
            "end_turn": FinishReason.END_TURN,
            "tool_use": FinishReason.TOOL_USE,
            "max_tokens": FinishReason.MAX_TOKENS,
            "stop_sequence": FinishReason.STOP_SEQUENCE,
            "stop": FinishReason.STOP_SEQUENCE,
        }
        return mapping.get(reason, FinishReason.STOP_SEQUENCE)

    def _map_error(self, exc: Exception) -> ModelError:
        status = self._extract_status_code(exc)
        log_parameter(
            "AnthropicAdapter._map_error",
            status_code=status,
            error_type=exc.__class__.__name__,
            call_id=self._model_name,
        )
        if status in (401, 403):
            return AuthenticationError(str(exc), {"status_code": status})
        if status == 429:
            return RateLimitError(str(exc), {"status_code": status})
        if status == 400:
            return InvalidRequestError(str(exc), {"status_code": status})
        return ProviderError(str(exc), {"status_code": status})

    def _error_event(self, error: ModelError) -> ModelEvent:
        return ModelEvent(
            type=ModelEventType.ERROR,
            payload={
                "code": error.code.value,
                "message": error.message,
                "retryable": error.retryable,
            },
        )

    @staticmethod
    def _get_attr(value: object, name: str) -> object | None:
        if isinstance(value, dict):
            return value.get(name)
        return getattr(value, name, None)

    @staticmethod
    def _extract_status_code(exc: Exception) -> int | None:
        for attr in ("status_code", "status", "http_status"):
            value = getattr(exc, attr, None)
            if isinstance(value, int):
                return value
        return None


__all__ = ["AnthropicAdapter"]
