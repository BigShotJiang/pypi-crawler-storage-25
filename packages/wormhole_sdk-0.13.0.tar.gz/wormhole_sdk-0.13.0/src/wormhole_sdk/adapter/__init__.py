"""Adapter interfaces and events."""

from .anthropic import AnthropicAdapter
from .base import AdapterRegistry, ModelAdapter
from .events import FinishReason, ModelEvent, ModelEventType

AdapterRegistry.default().register("anthropic", AnthropicAdapter, replace=True)

__all__ = [
    "AdapterRegistry",
    "AnthropicAdapter",
    "FinishReason",
    "ModelAdapter",
    "ModelEvent",
    "ModelEventType",
]
