"""Model adapter protocol and registry."""

from __future__ import annotations

from typing import Any, AsyncIterator, Protocol

from wormhole_core.logging import log_branch, log_parameter
from wormhole_core.schemas.messages import Message
from wormhole_core.schemas.tools import ToolDefinition

from .events import ModelEvent


class ModelAdapter(Protocol):
    """Protocol for LLM provider adapters.

    >>> class DemoAdapter:
    ...     def __init__(self, model: str) -> None:
    ...         self._model = model
    ...     @property
    ...     def provider_name(self) -> str:
    ...         return "demo"
    ...     @property
    ...     def model_id(self) -> str:
    ...         return self._model
    ...     async def stream(
    ...         self,
    ...         messages: list[Message],
    ...         tools: list[ToolDefinition] | None = None,
    ...         system_prompt: str | None = None,
    ...         max_tokens: int | None = None,
    ...     ) -> AsyncIterator[ModelEvent]:
    ...         if messages or tools or system_prompt or max_tokens:
    ...             return
    ...         yield ModelEvent(type=ModelEventType.TEXT_DELTA, payload={"text": ""})  # pragma: no cover
    ...     async def count_tokens(self, messages: list[Message]) -> int:
    ...         return len(messages)
    >>> DemoAdapter("demo-model").provider_name
    'demo'
    """

    @property
    def provider_name(self) -> str:
        """Return provider identifier (e.g., 'anthropic')."""

    @property
    def model_id(self) -> str:
        """Return model identifier (e.g., 'claude-sonnet-4-20250514')."""

    def stream(
        self,
        messages: list[Message],
        tools: list[ToolDefinition] | None = None,
        system_prompt: str | None = None,
        max_tokens: int | None = None,
    ) -> AsyncIterator[ModelEvent]:
        """Stream completion events.

        Implementations should be async generators (async def with yield).
        The protocol uses a non-async signature because Pyright distinguishes
        between coroutines returning AsyncIterator and async generators.
        """

    async def count_tokens(self, messages: list[Message]) -> int:
        """Count tokens for the given messages."""


class AdapterRegistry:
    """Registry for model adapters.

    >>> class DemoAdapter:
    ...     def __init__(self, model: str = "demo") -> None:
    ...         self._model = model
    ...     @property
    ...     def provider_name(self) -> str:
    ...         return "demo"
    ...     @property
    ...     def model_id(self) -> str:
    ...         return self._model
    ...     async def stream(
    ...         self,
    ...         messages: list[Message],
    ...         tools: list[ToolDefinition] | None = None,
    ...         system_prompt: str | None = None,
    ...         max_tokens: int | None = None,
    ...     ) -> AsyncIterator[ModelEvent]:
    ...         return
    ...         yield ModelEvent(type=ModelEventType.TEXT_DELTA, payload={"text": ""})  # pragma: no cover
    ...     async def count_tokens(self, messages: list[Message]) -> int:
    ...         return len(messages)
    >>> registry = AdapterRegistry()
    >>> registry.register("demo", DemoAdapter)
    >>> adapter = registry.create("demo", model="alpha")
    >>> adapter.model_id
    'alpha'
    >>> registry.list_providers()
    ['demo']
    """

    _default_instance: AdapterRegistry | None = None

    def __init__(self) -> None:
        self._providers: dict[str, type[ModelAdapter]] = {}

    def register(
        self, provider: str, adapter_class: type[ModelAdapter], *, replace: bool = False
    ) -> None:
        """Register a provider adapter class."""
        key = provider.strip().lower()
        if not key:
            log_branch("AdapterRegistry.register", "missing_provider")
            raise ValueError("provider name is required")
        if key in self._providers and not replace:
            log_branch("AdapterRegistry.register", "duplicate_provider", call_id=key)
            raise ValueError(f"adapter already registered for {key}")
        log_parameter(
            "AdapterRegistry.register", provider=key, replace=replace, call_id=key
        )
        self._providers[key] = adapter_class

    def create(self, provider: str, **config: Any) -> ModelAdapter:
        """Instantiate a provider adapter with the given config."""
        key = provider.strip().lower()
        adapter_class = self._providers.get(key)
        if adapter_class is None:
            log_branch("AdapterRegistry.create", "missing_provider", call_id=key)
            raise ValueError(f"no adapter registered for {key}")
        log_parameter("AdapterRegistry.create", provider=key, call_id=key)
        return adapter_class(**config)

    def list_providers(self) -> list[str]:
        """Return registered provider identifiers."""
        log_parameter("AdapterRegistry.list_providers")
        return sorted(self._providers.keys())

    @classmethod
    def default(cls) -> "AdapterRegistry":
        """Return the default registry instance."""
        log_parameter("AdapterRegistry.default")
        if cls._default_instance is None:
            cls._default_instance = cls()
        return cls._default_instance


__all__ = ["AdapterRegistry", "ModelAdapter"]
