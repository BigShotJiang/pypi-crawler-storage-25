"""Default tool handler factory for built-in SDK tools.

Provides a single factory function that creates handlers for bash, file_read,
file_edit, and file_write tools. Approval is handled separately by ApprovalManager.

>>> from wormhole_sdk.tool_handlers import create_default_tool_handlers
>>> from wormhole_sdk.tools import create_default_tools
>>> tools = create_default_tools()
>>> handlers = create_default_tool_handlers(tools={t.tool_id: t for t in tools})
>>> sorted(handlers.keys())
['bash', 'file_edit', 'file_read', 'file_write']
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Awaitable, Callable

from wormhole_core.schemas.tools import ToolDefinition

from .tools import (
    BashToolInput,
    FileEditInput,
    FileReadCache,
    FileReadInput,
    FileWriteInput,
    execute_bash,
    execute_file_edit,
    execute_file_read,
    execute_file_write,
)


def _resolve_path(raw: str, root_dir: Path) -> Path:
    """Resolve a path relative to root_dir.

    Always returns an absolute, resolved path for consistent cache keys.

    >>> _resolve_path("/abs/path.py", Path("/root"))
    PosixPath('/abs/path.py')
    >>> _resolve_path("rel/path.py", Path("/root"))
    PosixPath('/root/rel/path.py')
    """
    path = Path(raw)
    if not path.is_absolute():
        path = root_dir / path
    return path.resolve()


def create_default_tool_handlers(
    *,
    tools: dict[str, ToolDefinition] | None = None,
    root_dir: Path | None = None,
    boundary: Path | None = None,
    file_cache: FileReadCache | None = None,
    task_handler: Callable[[dict[str, Any]], Awaitable[Any]] | None = None,
) -> dict[str, Callable[[dict[str, Any]], Awaitable[Any]]]:
    """Create handlers for all built-in tools.

    Approval is handled separately by ApprovalManager - these handlers are pure
    executors that don't check permissions.

    Args:
        tools: Tool definitions keyed by tool_id. If None, creates defaults.
        root_dir: Working directory for path resolution and bash execution. Defaults to cwd.
        boundary: Security boundary for file operations. If None, no boundary restriction
            is applied (relies on ApprovalManager for access control). Set to root_dir if you
            want to restrict file access to the working directory even after approval.
        file_cache: Shared file read cache for edit staleness detection.
            Created automatically if not provided.

    Returns:
        Dict mapping tool_id to async handler callable.

    >>> handlers = create_default_tool_handlers()
    >>> "bash" in handlers and "file_read" in handlers
    True
    """
    root = root_dir or Path.cwd().resolve()
    # boundary=None means no restriction (approval handles access control)
    file_boundary = boundary
    cache = file_cache or FileReadCache()
    resolved_tools = tools or {}

    # --- Preparers (validate/resolve args before approval) ---

    def _prepare_bash(args: dict[str, Any]) -> dict[str, Any]:
        return {
            "command": args.get("command", ""),
            "timeout": args.get("timeout", 120.0),
            "working_directory": str(root),
        }

    def _prepare_file_read(args: dict[str, Any]) -> dict[str, Any]:
        return {
            "file_path": str(_resolve_path(args.get("file_path", ""), root)),
            "offset": args.get("offset", 0),
            "limit": args.get("limit", 2000),
        }

    def _prepare_file_edit(args: dict[str, Any]) -> dict[str, Any]:
        file_path = _resolve_path(args.get("file_path", ""), root)
        cached_state = cache.get(file_path)
        if cached_state is None:
            raise ValueError(f"file not read yet - use file_read first: {file_path}")
        if file_path.exists():
            current_mtime = file_path.stat().st_mtime
            if current_mtime != cached_state.mtime:
                raise ValueError(
                    f"file changed since last read - use file_read again: {file_path}"
                )
        return {
            "file_path": str(file_path),
            "old_string": args.get("old_string", ""),
            "new_string": args.get("new_string", ""),
            "replace_all": args.get("replace_all", False),
        }

    def _prepare_file_write(args: dict[str, Any]) -> dict[str, Any]:
        return {
            "file_path": str(_resolve_path(args.get("file_path", ""), root)),
            "content": args.get("content", ""),
            "overwrite": args.get("overwrite", False),
            "create_parents": args.get("create_parents", False),
        }

    # --- Handlers (execute tool after approval) ---

    async def _handle_bash(prepared: dict[str, Any]) -> str:
        try:
            tool_input = BashToolInput(
                command=prepared.get("command", ""),
                timeout=prepared.get("timeout", 120.0),
                working_directory=root,
            )
            result = await execute_bash(tool_input)
            output = ""
            if result.stdout:
                output += result.stdout
            if result.stderr:
                output += f"\n[stderr]\n{result.stderr}"
            if result.timed_out:
                output += "\n[timed out]"
            output += f"\n[exit code: {result.exit_code}]"
            return output.strip()
        except Exception as e:
            return f"Error: {e}"

    async def _handle_file_read(prepared: dict[str, Any]) -> str:
        try:
            tool_input = FileReadInput(
                file_path=Path(prepared.get("file_path", "")),
                offset=prepared.get("offset", 0),
                limit=prepared.get("limit", 2000),
            )
            result = await execute_file_read(
                tool_input, boundary=file_boundary, cache=cache
            )
            return result.content
        except Exception as e:
            return f"Error: {e}"

    async def _handle_file_edit(prepared: dict[str, Any]) -> str:
        try:
            tool_input = FileEditInput(
                file_path=Path(prepared.get("file_path", "")),
                old_string=prepared.get("old_string", ""),
                new_string=prepared.get("new_string", ""),
                replace_all=prepared.get("replace_all", False),
            )
            result = await execute_file_edit(
                tool_input, boundary=file_boundary, read_cache=cache
            )
            return f"Edited {result.file_path}\nReplacements: {result.occurrences_replaced}\nDiff:\n{result.diff_summary}"
        except Exception as e:
            return f"Error: {e}"

    async def _handle_file_write(prepared: dict[str, Any]) -> str:
        try:
            tool_input = FileWriteInput(
                file_path=Path(prepared.get("file_path", "")),
                content=prepared.get("content", ""),
                overwrite=prepared.get("overwrite", False),
                create_parents=prepared.get("create_parents", False),
            )
            result = await execute_file_write(tool_input, boundary=file_boundary)
            action = "Created" if result.created else "Overwrote"
            return f"{action} {result.file_path} ({result.bytes_written} bytes)"
        except Exception as e:
            return f"Error: {e}"

    # --- Create wrapped handlers that prepare args then execute ---

    async def bash_handler(args: dict[str, Any]) -> str:
        try:
            prepared = _prepare_bash(args)
            return await _handle_bash(prepared)
        except Exception as e:
            return f"Error: {e}"

    async def file_read_handler(args: dict[str, Any]) -> str:
        try:
            prepared = _prepare_file_read(args)
            return await _handle_file_read(prepared)
        except Exception as e:
            return f"Error: {e}"

    async def file_edit_handler(args: dict[str, Any]) -> str:
        try:
            prepared = _prepare_file_edit(args)
            return await _handle_file_edit(prepared)
        except Exception as e:
            return f"Error: {e}"

    async def file_write_handler(args: dict[str, Any]) -> str:
        try:
            prepared = _prepare_file_write(args)
            return await _handle_file_write(prepared)
        except Exception as e:
            return f"Error: {e}"

    handlers: dict[str, Callable[[dict[str, Any]], Awaitable[Any]]] = {
        "bash": bash_handler,
        "file_read": file_read_handler,
        "file_edit": file_edit_handler,
        "file_write": file_write_handler,
    }
    if "task" in resolved_tools and task_handler is not None:
        handlers["task"] = task_handler
    return handlers


__all__ = ["create_default_tool_handlers"]
