"""SDK logging redaction helpers for structured `extra` payloads."""

from __future__ import annotations

import logging
import os
import re
from dataclasses import asdict, is_dataclass
from enum import Enum
from typing import Any, Mapping

REDACTED = "REDACTED"

_SENSITIVE_KEY_MARKERS = {
    "password",
    "passphrase",
    "token",
    "secret",
    "credential",
    "key",
    "api_key",
    "apikey",
    "access_key",
    "private_key",
    "email",
    "phone",
    "ssn",
}

_EMAIL_PATTERN = re.compile(r"\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b")
_CLI_FLAG_PATTERN = re.compile(
    r"(?i)(--(?:password|passphrase|token|api-key|api_key|secret|credential|"
    r"access-key|access_key|private-key|private_key|email|key))([= ]+)(\S+)"
)
_ASSIGNMENT_PATTERN = re.compile(
    r"(?i)\b(password|passphrase|token|api[_-]?key|secret|credential|"
    r"access[_-]?key|private[_-]?key|email|phone|ssn)\b(\s*[:=]\s*)(\S+)"
)
_BEARER_PATTERN = re.compile(r"(?i)(authorization\s*:\s*bearer\s+)(\S+)")


def is_release_build() -> bool:
    """Return True when running in release mode with debug paths disabled."""
    return os.getenv("WORMHOLE_RELEASE") == "1"


def debug_logging_enabled(logger: logging.Logger) -> bool:
    """Return True when DEBUG logging should be emitted."""
    return logger.isEnabledFor(logging.DEBUG) and not is_release_build()


def sanitize_log_extra(extra: Mapping[str, Any] | None) -> dict[str, Any]:
    """Redact sensitive values from structured logging `extra` payloads."""
    redacted = redact_log_data(dict(extra or {}))
    if isinstance(redacted, dict):
        return {str(key): value for key, value in redacted.items()}
    return {"value": redacted}


def redact_log_data(value: Any) -> Any:
    """Recursively redact known sensitive/PII values from arbitrary payloads."""
    normalized = _jsonify(value)
    if isinstance(normalized, dict):
        redacted: dict[str, Any] = {}
        for key, item in normalized.items():
            key_text = str(key)
            if _is_sensitive_key(key_text):
                redacted[key_text] = REDACTED
            else:
                redacted[key_text] = redact_log_data(item)
        return redacted
    if isinstance(normalized, list):
        return [redact_log_data(item) for item in normalized]
    if isinstance(normalized, str):
        return _redact_string(normalized)
    return normalized


def _is_sensitive_key(key: str) -> bool:
    lowered = key.lower()
    return any(marker in lowered for marker in _SENSITIVE_KEY_MARKERS)


def _redact_string(text: str) -> str:
    redacted = _EMAIL_PATTERN.sub(REDACTED, text)
    redacted = _CLI_FLAG_PATTERN.sub(
        lambda match: f"{match.group(1)}{match.group(2)}{REDACTED}",
        redacted,
    )
    redacted = _ASSIGNMENT_PATTERN.sub(
        lambda match: f"{match.group(1)}{match.group(2)}{REDACTED}",
        redacted,
    )
    redacted = _BEARER_PATTERN.sub(
        lambda match: f"{match.group(1)}{REDACTED}",
        redacted,
    )
    return redacted


def _jsonify(value: Any) -> Any:
    if is_dataclass(value) and not isinstance(value, type):
        return _jsonify(asdict(value))
    if isinstance(value, Enum):
        return value.value
    if isinstance(value, dict):
        return {str(key): _jsonify(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_jsonify(item) for item in value]
    if isinstance(value, tuple):
        return [_jsonify(item) for item in value]
    if isinstance(value, set):
        return [_jsonify(item) for item in value]
    if isinstance(value, bytes):
        try:
            return value.decode("utf-8")
        except UnicodeDecodeError:
            return value.hex()
    if isinstance(value, Exception):
        return {"error": value.__class__.__name__, "message": str(value)}
    if hasattr(value, "__fspath__"):
        return str(value)
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return repr(value)
