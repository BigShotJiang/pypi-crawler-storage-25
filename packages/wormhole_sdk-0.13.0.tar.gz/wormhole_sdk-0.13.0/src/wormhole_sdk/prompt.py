"""Prompt builder utilities for layered system prompts."""

from __future__ import annotations

import datetime as dt
import hashlib
import logging
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from wormhole_core.errors import PromptLayerLockViolationError, ValidationError
from wormhole_core.logging import log_branch, log_parameter, log_timing
from wormhole_core.schemas.tools import ToolDefinition

from .log_redaction import debug_logging_enabled, sanitize_log_extra

LOGGER = logging.getLogger("wormhole_sdk.prompt")


def _log_debug(message: str, *, extra: dict[str, Any] | None = None) -> None:
    if not debug_logging_enabled(LOGGER):
        return
    LOGGER.debug(message, extra=sanitize_log_extra(extra))


def _log_warning(message: str, *, extra: dict[str, Any] | None = None) -> None:
    LOGGER.warning(message, extra=sanitize_log_extra(extra))


DEFAULT_IDENTITY = """You are Wormhole, an AI coding assistant.
You help developers with software engineering tasks including writing code,
debugging, refactoring, and explaining codebases."""

DEFAULT_MANDATES = """## Core Rules
- Read files before modifying them
- Prefer editing existing files over creating new ones
- Use tools to complete tasks; don't just describe what to do
- Be concise and direct in responses"""

DEFAULT_SAFETY = """## Safety Reminders
- Never execute destructive commands without explicit confirmation
- Do not expose secrets, API keys, or credentials
- Respect file permissions and access controls
- When uncertain, ask for clarification"""


@dataclass
class PromptLayer:
    """Single prompt layer."""

    name: str
    content: str
    priority: int = 0
    enabled: bool = True
    locked: bool = False
    lock_source: str | None = None
    lock_reason: str | None = None


@dataclass
class EnvironmentContext:
    """Runtime environment context for prompts.

    >>> ctx = EnvironmentContext()
    >>> ctx.cwd.is_dir()
    True
    """

    cwd: Path = field(default_factory=Path.cwd)
    platform: str = field(default_factory=lambda: sys.platform)
    python_version: str = field(default_factory=lambda: sys.version.split()[0])
    date: str = field(
        default_factory=lambda: dt.datetime.now(dt.timezone.utc).date().isoformat()
    )
    os_version: str | None = None
    git_branch: str | None = None
    git_status: str | None = None
    timestamp: str | None = None
    custom: dict[str, str] = field(default_factory=dict)


@dataclass
class ProjectContext:
    """Project-specific context."""

    agents_file: str | None = None
    workspace_config: dict[str, Any] = field(default_factory=dict)
    custom_instructions: str | None = None


@dataclass
class _AgentCache:
    mtime: float
    lines: list[str]


class PromptBuilder:
    """Build layered system prompts.

    >>> builder = PromptBuilder()
    >>> _ = builder.set_identity("You are Wormhole.")
    >>> _ = builder.set_environment(EnvironmentContext())
    >>> prompt = builder.build()
    >>> "<env>" in prompt
    True
    """

    def __init__(self) -> None:
        self._layers: dict[str, PromptLayer] = {}
        self._agents_cache: dict[Path, _AgentCache] = {}
        self._canonical_aliases: dict[str, set[str]] = {
            "identity": {"identity", "identity preamble"},
            "mandates": {"mandates", "core mandates"},
            "environment": {"environment", "environment context"},
            "project": {"project", "project instructions"},
            "tools": {"tools", "tool documentation", "tool docs"},
            "safety": {"safety", "safety reminders"},
        }
        self._default_priorities: dict[str, int] = {
            "identity": 100,
            "mandates": 90,
            "environment": 80,
            "project": 70,
            "tools": 60,
            "safety": 50,
        }

    def set_identity(self, content: str) -> "PromptBuilder":
        self._assert_layer_unlocked("identity", "set_identity")
        self._layers["identity"] = PromptLayer("identity", content, priority=100)
        return self

    def set_mandates(self, content: str) -> "PromptBuilder":
        self._assert_layer_unlocked("mandates", "set_mandates")
        self._layers["mandates"] = PromptLayer("mandates", content, priority=90)
        return self

    def set_environment(self, env: EnvironmentContext) -> "PromptBuilder":
        self._assert_layer_unlocked("environment", "set_environment")
        content = self._format_environment(env)
        self._layers["environment"] = PromptLayer("environment", content, priority=80)
        return self

    def set_project(self, project: ProjectContext | Path) -> "PromptBuilder":
        self._assert_layer_unlocked("project", "set_project")
        context = (
            project
            if isinstance(project, ProjectContext)
            else self._load_project_context(Path(project))
        )
        content = self._format_project(context)
        if content:
            self._layers["project"] = PromptLayer("project", content, priority=70)
        return self

    def set_tools(self, tools: list[ToolDefinition]) -> "PromptBuilder":
        self._assert_layer_unlocked("tools", "set_tools")
        content = self._format_tools(tools)
        if content:
            self._layers["tools"] = PromptLayer("tools", content, priority=60)
        return self

    def set_safety(self, content: str) -> "PromptBuilder":
        self._assert_layer_unlocked("safety", "set_safety")
        self._layers["safety"] = PromptLayer("safety", content, priority=50)
        return self

    def add_layer(self, name: str, content: str, priority: int = 0) -> "PromptBuilder":
        if name in self._layers:
            self._assert_layer_unlocked(name, "add_layer")
        self._layers[name] = PromptLayer(name, content, priority=priority)
        return self

    def lock_layer(
        self,
        name: str,
        *,
        source: str = "unknown",
        reason: str = "",
    ) -> "PromptBuilder":
        """Lock a layer by canonical name or display-label alias.

        >>> pb = PromptBuilder()
        >>> _ = pb.set_safety("stay safe")
        >>> _ = pb.lock_layer("safety", source="policy", reason="required")
        >>> pb.is_locked("safety")
        True
        """

        key = self._normalize_layer_key(name)
        layer = self._layers.get(key)
        if layer is None:
            raise KeyError(f"Layer '{key}' not found in PromptBuilder")
        if layer.locked:
            _log_debug(
                "Prompt layer already locked",
                extra={"layer_name": key, "source": source},
            )
            return self
        layer.locked = True
        layer.lock_source = source
        layer.lock_reason = reason
        _log_debug(
            "Prompt layer locked",
            extra={
                "layer_name": key,
                "lock_source": source,
                "lock_reason": reason,
            },
        )
        return self

    def unlock_layer(
        self,
        name: str,
        *,
        source: str,
        force: bool = False,
    ) -> "PromptBuilder":
        """Unlock a locked layer if source matches lock owner.

        >>> pb = PromptBuilder()
        >>> _ = pb.set_safety("stay safe")
        >>> _ = pb.lock_layer("safety", source="policy")
        >>> _ = pb.unlock_layer("safety", source="policy")
        >>> pb.is_locked("safety")
        False
        """

        key = self._normalize_layer_key(name)
        layer = self._layers.get(key)
        if layer is None:
            raise KeyError(f"Layer '{key}' not found in PromptBuilder")
        if not layer.locked:
            _log_debug(
                "Prompt layer already unlocked",
                extra={"layer_name": key, "source": source, "force": force},
            )
            return self
        lock_source = layer.lock_source or "unknown"
        if not force and lock_source != source:
            raise PromptLayerLockViolationError(
                layer_name=key,
                operation="unlock",
                lock_source=lock_source,
            )
        layer.locked = False
        layer.lock_source = None
        layer.lock_reason = None
        _log_debug(
            "Prompt layer unlocked",
            extra={"layer_name": key, "source": source, "force": force},
        )
        return self

    def is_locked(self, name: str) -> bool:
        """Check whether a layer is locked.

        >>> pb = PromptBuilder()
        >>> _ = pb.set_identity("id")
        >>> pb.is_locked("identity")
        False
        """

        key = self._normalize_layer_key(name)
        layer = self._layers.get(key)
        if layer is None:
            raise KeyError(f"Layer '{key}' not found in PromptBuilder")
        _log_debug(
            "Prompt layer lock checked",
            extra={"layer_name": key, "locked": bool(layer.locked)},
        )
        return bool(layer.locked)

    def for_child(
        self,
        *,
        custom_system_prompt: str | None = None,
        custom_layer_name: str = "project",
    ) -> "PromptBuilder":
        """Clone the prompt builder for child sessions.

        Locks are preserved. Custom prompt can only target unlocked layers.

        >>> parent = PromptBuilder().set_identity("id").set_safety("safe")
        >>> _ = parent.lock_layer("safety", source="parent")
        >>> child = parent.for_child(custom_system_prompt="custom", custom_layer_name="project")
        >>> child.is_locked("safety")
        True
        """

        child = PromptBuilder()
        child._agents_cache = dict(self._agents_cache)
        for name, source_layer in self._layers.items():
            child._layers[name] = PromptLayer(
                name=source_layer.name,
                content=source_layer.content,
                priority=source_layer.priority,
                enabled=source_layer.enabled,
                locked=source_layer.locked,
                lock_source=source_layer.lock_source,
                lock_reason=source_layer.lock_reason,
            )
        if custom_system_prompt:
            key = self._normalize_layer_key(custom_layer_name)
            layer = child._layers.get(key)
            if layer is None:
                child._layers[key] = PromptLayer(
                    name=key,
                    content=custom_system_prompt,
                    priority=self._default_priorities.get(key, 0),
                )
            elif layer.locked:
                lock_source = layer.lock_source or "unknown"
                attempted_hash = hashlib.sha256(
                    custom_system_prompt.encode("utf-8")
                ).hexdigest()
                _log_warning(
                    "TaskTool custom prompt attempted on locked layer; ignored",
                    extra={
                        "layer_name": key,
                        "operation": "set_custom_system_prompt",
                        "lock_source": lock_source,
                        "attempted_content_hash": attempted_hash,
                    },
                )
            else:
                layer.content = custom_system_prompt
        _log_debug(
            "PromptBuilder.for_child created",
            extra={
                "layer_count": len(child._layers),
                "custom_prompt_applied": bool(custom_system_prompt),
                "custom_layer_name": custom_layer_name,
            },
        )
        return child

    def build(self) -> str:
        started = dt.datetime.now(dt.timezone.utc)
        log_parameter("PromptBuilder.build", layer_count=len(self._layers))
        if "identity" not in self._layers and "mandates" not in self._layers:
            log_branch("PromptBuilder.build", "missing_identity_or_mandates")
            raise ValidationError("prompt must include identity or mandates", {})
        prompt = "\n\n".join(self.get_layers())
        elapsed_ms = (dt.datetime.now(dt.timezone.utc) - started).total_seconds() * 1000
        log_timing("PromptBuilder.build", elapsed_ms)
        return prompt

    def get_layers(self) -> list[str]:
        sorted_layers = sorted(
            [layer for layer in self._layers.values() if layer.enabled],
            key=lambda layer: -layer.priority,
        )
        return [layer.content for layer in sorted_layers]

    def _format_environment(self, env: EnvironmentContext) -> str:
        lines = [
            "<env>",
            f"Working directory: {env.cwd}",
            f"Platform: {env.platform}",
            f"Python: {env.python_version}",
            f"Date: {env.date}",
        ]
        if env.os_version:
            lines.append(f"OS Version: {env.os_version}")
        if env.git_branch:
            lines.append(f"Git branch: {env.git_branch}")
        if env.git_status:
            lines.append(f"Git status: {env.git_status}")
        if env.timestamp:
            lines.append(f"Timestamp: {env.timestamp}")
        for key, value in env.custom.items():
            lines.append(f"{key}: {value}")
        lines.append("</env>")
        return "\n".join(lines)

    def _format_project(self, project: ProjectContext) -> str:
        parts: list[str] = []
        if project.agents_file:
            parts.append(
                f"<project-instructions>\n{project.agents_file}\n</project-instructions>"
            )
        if project.custom_instructions:
            parts.append(
                f"<custom-instructions>\n{project.custom_instructions}\n</custom-instructions>"
            )
        return "\n\n".join(parts)

    def _format_tools(self, tools: list[ToolDefinition]) -> str:
        if not tools:
            return ""
        lines = ["<available-tools>"]
        for tool in tools:
            lines.append(f"- {tool.name}: {tool.description}".rstrip())
        lines.append("</available-tools>")
        return "\n".join(lines)

    def _load_project_context(self, root: Path) -> ProjectContext:
        agents_path = self._discover_agents_file(root)
        agents_contents = self._read_agents_file(agents_path) if agents_path else None
        return ProjectContext(agents_file=agents_contents)

    def _normalize_layer_key(self, name: str) -> str:
        cleaned = name.strip().lower()
        if not cleaned:
            raise ValidationError("layer name must be non-empty", {})
        matches = [
            canonical
            for canonical, aliases in self._canonical_aliases.items()
            if cleaned == canonical or cleaned in aliases
        ]
        if len(matches) == 1:
            return matches[0]
        allowed = sorted(self._canonical_aliases.keys())
        if not matches:
            raise ValidationError(
                "unknown prompt layer key",
                {"layer_name": name, "allowed_layers": allowed},
            )
        raise ValidationError(
            "ambiguous prompt layer key",
            {"layer_name": name, "allowed_layers": allowed, "matches": matches},
        )

    def _assert_layer_unlocked(self, name: str, operation: str) -> None:
        layer = self._layers.get(name)
        if layer is None or not layer.locked:
            return
        _log_warning(
            "Prompt layer mutation attempted on locked layer",
            extra={
                "layer_name": name,
                "operation": operation,
                "lock_source": layer.lock_source or "unknown",
            },
        )
        raise PromptLayerLockViolationError(
            layer_name=name,
            operation=operation,
            lock_source=layer.lock_source or "unknown",
        )

    def _discover_agents_file(self, root: Path) -> Path | None:
        candidates = [
            root / "AGENTS.md",
            root / ".wormhole" / "instructions.md",
            root / "CLAUDE.md",
        ]
        for candidate in candidates:
            if candidate.exists():
                return candidate
        return None

    def _read_agents_file(self, path: Path) -> str:
        stat = path.stat()
        cached = self._agents_cache.get(path)
        if cached and cached.mtime == stat.st_mtime:
            log_branch("PromptBuilder._read_agents_file", "cache_hit")
            return "".join(cached.lines)
        log_branch("PromptBuilder._read_agents_file", "cache_miss")
        lines: list[str] = []
        with path.open("r", encoding="utf-8") as handle:
            for line in handle:
                lines.append(line)
        self._agents_cache[path] = _AgentCache(mtime=stat.st_mtime, lines=lines)
        return "".join(lines)


__all__ = [
    "DEFAULT_IDENTITY",
    "DEFAULT_MANDATES",
    "DEFAULT_SAFETY",
    "EnvironmentContext",
    "ProjectContext",
    "PromptBuilder",
    "PromptLayer",
]
