"""Deprecation helpers for SDK APIs."""

from __future__ import annotations

import warnings


def deprecated(
    message: str, *, remove_in: str | None = None, stacklevel: int = 2
) -> None:
    """Emit a DeprecationWarning with a removal timeline.

    >>> import warnings as _warnings
    >>> with _warnings.catch_warnings(record=True) as captured:
    ...     _warnings.simplefilter("always")
    ...     deprecated("Use new_api()", remove_in="0.3.0")
    ...     captured[0].category.__name__
    'DeprecationWarning'
    """

    suffix = f" Removal planned in {remove_in}." if remove_in else ""
    warnings.warn(f"{message}{suffix}", DeprecationWarning, stacklevel=stacklevel)


__all__ = ["deprecated"]
