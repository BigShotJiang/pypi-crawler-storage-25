"""External tool loading utilities for the Wormhole SDK."""

from __future__ import annotations

import importlib
from dataclasses import dataclass
from pathlib import Path
from types import ModuleType
from typing import Any, Awaitable, Callable, Protocol, runtime_checkable

from wormhole_core.errors import ValidationError
from wormhole_core.logging import log_branch, log_parameter
from wormhole_core.schemas.tools import ToolDefinition
from wormhole_core.tools.schema import validate_tool_definition

from .errors import (
    ConfigurationError,
    DuplicateToolError,
    ToolErrorCode,
    ToolLoadError,
    api_version_error,
    handler_error,
    import_error,
    missing_factory_error,
    validation_error,
)

TOOL_API_VERSION = "1.0.0"
"""Current tool API version. External tools declare compatibility via this."""


@dataclass(frozen=True)
class ToolHandlerContext:
    """Runtime context passed to external tool handler factories."""

    root_dir: Path
    file_cache: Any | None = None
    boundary: Path | None = None


@runtime_checkable
class ToolFactoryProtocol(Protocol):
    """Protocol that external tool modules must implement.

    >>> class _ExampleModule:
    ...     def create_tools(self):
    ...         return []
    ...     def create_handlers(self, context):
    ...         return {}
    >>> isinstance(_ExampleModule(), ToolFactoryProtocol)
    True
    """

    def create_tools(self) -> list[ToolDefinition]:
        """Create tool definitions for this module."""
        ...

    def create_handlers(
        self, context: ToolHandlerContext
    ) -> dict[str, Callable[[dict[str, Any]], Awaitable[Any]]]:
        """Create handlers for the tools in this module."""
        ...


@dataclass(frozen=True)
class DiscoveredTool:
    """Internal representation of a discovered external tool."""

    tool_id: str
    definition: ToolDefinition
    module_path: str
    api_version: str | None = None


def _load_module(module_path: str) -> ModuleType:
    """Import a tool module by path.

    >>> _load_module("types").__name__
    'types'
    """
    log_parameter("tool_loader._load_module", module_path=module_path)
    try:
        module = importlib.import_module(module_path)
    except ImportError as exc:
        log_branch("tool_loader._load_module", "import_error")
        raise import_error(module_path, exc) from exc
    log_branch("tool_loader._load_module", "import_ok")
    return module


def _parse_major_version(version: str) -> int | None:
    """Parse the major version from a SemVer string.

    >>> _parse_major_version("1.2.3")
    1
    >>> _parse_major_version("invalid") is None
    True
    """
    log_parameter("tool_loader._parse_major_version", version=version)
    if not version:
        log_branch("tool_loader._parse_major_version", "empty_version")
        return None
    parts = version.split(".")
    if not parts or not parts[0]:
        log_branch("tool_loader._parse_major_version", "missing_major")
        return None
    try:
        major = int(parts[0])
    except ValueError:
        log_branch("tool_loader._parse_major_version", "invalid_major")
        return None
    return major


def _validate_api_version(module_path: str, module: ModuleType) -> None:
    """Validate external tool API version compatibility.

    >>> import types as _types
    >>> mod = _types.SimpleNamespace(TOOL_API_VERSION="1.0.0")
    >>> _validate_api_version("my_tools.ok", mod) is None
    True
    """
    declared_version = getattr(module, "TOOL_API_VERSION", None)
    log_parameter(
        "tool_loader._validate_api_version",
        module_path=module_path,
        declared_version=declared_version,
    )
    if declared_version is None:
        log_branch("tool_loader._validate_api_version", "version_missing")
        return
    expected_major = _parse_major_version(TOOL_API_VERSION)
    actual_major = _parse_major_version(declared_version)
    if expected_major is None or actual_major is None:
        log_branch("tool_loader._validate_api_version", "version_unparseable")
        raise ToolLoadError(
            message=(
                f"API version is not SemVer: module '{module_path}' declares "
                f"'{declared_version}'."
            ),
            error_code=ToolErrorCode.TOOL_API_VERSION_MISMATCH,
            module_path=module_path,
            context={"declared_version": declared_version},
        )
    if expected_major != actual_major:
        log_branch("tool_loader._validate_api_version", "major_mismatch")
        raise api_version_error(
            module_path,
            declared_version,
            expected_major,
            actual_major,
        )
    log_branch("tool_loader._validate_api_version", "major_match")


def _validate_factories(module_path: str, module: ModuleType) -> None:
    """Validate required factory functions on module.

    >>> import types as _types
    >>> mod = _types.SimpleNamespace(create_tools=lambda: [], create_handlers=lambda ctx: {})
    >>> _validate_factories("my_tools.ok", mod) is None
    True
    """
    log_parameter("tool_loader._validate_factories", module_path=module_path)
    if not hasattr(module, "create_tools"):
        log_branch("tool_loader._validate_factories", "missing_create_tools")
        raise missing_factory_error(module_path, "create_tools")
    if not hasattr(module, "create_handlers"):
        log_branch("tool_loader._validate_factories", "missing_create_handlers")
        raise missing_factory_error(module_path, "create_handlers")
    log_branch("tool_loader._validate_factories", "factories_ok")


def discover_external_tools(tool_config_paths: list[str]) -> dict[str, DiscoveredTool]:
    """Discover external tools from module paths.

    >>> import sys
    >>> from types import ModuleType
    >>> module = ModuleType("sample_tool_mod")
    >>> module.TOOL_API_VERSION = "1.0.0"
    >>> def _create_tools():
    ...     return [ToolDefinition(tool_id="t1", name="t1", schema={"type": "object"})]
    >>> def _create_handlers(context):
    ...     return {"t1": lambda args: "ok"}
    >>> module.create_tools = _create_tools
    >>> module.create_handlers = _create_handlers
    >>> sys.modules["sample_tool_mod"] = module
    >>> tools = discover_external_tools(["sample_tool_mod"])
    >>> sorted(tools.keys())
    ['t1']
    """
    log_parameter(
        "tool_loader.discover_external_tools",
        tool_config_paths=tool_config_paths,
    )
    if not tool_config_paths:
        log_branch("tool_loader.discover_external_tools", "no_paths")
        return {}

    seen_paths: set[str] = set()
    duplicate_list: list[str] = []
    for path in tool_config_paths:
        if path in seen_paths:
            duplicate_list.append(path)
            continue
        seen_paths.add(path)
    if duplicate_list:
        log_branch("tool_loader.discover_external_tools", "duplicate_paths")
        duplicate_list = sorted(set(duplicate_list))
        raise ToolLoadError(
            message=f"Duplicate module paths in tool_config_paths: {duplicate_list}",
            error_code=ToolErrorCode.TOOL_LOAD_ERROR,
            module_path=duplicate_list[0],
            context={"duplicates": duplicate_list},
        )

    log_branch("tool_loader.discover_external_tools", "discovery_start")
    discovered: dict[str, DiscoveredTool] = {}
    for module_path in tool_config_paths:
        log_parameter(
            "tool_loader.discover_external_tools",
            module_path=module_path,
        )
        module = _load_module(module_path)
        log_branch("tool_loader.discover_external_tools", "module_loaded")
        _validate_factories(module_path, module)
        _validate_api_version(module_path, module)
        api_version = getattr(module, "TOOL_API_VERSION", None)
        tool_metadata = getattr(module, "__tool_metadata__", None)
        log_parameter(
            "tool_loader.discover_external_tools",
            module_path=module_path,
            api_version=api_version,
            has_tool_metadata=tool_metadata is not None,
        )
        if tool_metadata is not None:
            log_branch("tool_loader.discover_external_tools", "metadata_captured")
        try:
            tool_definitions = module.create_tools()
        except Exception as exc:  # pragma: no cover - defensive
            log_branch("tool_loader.discover_external_tools", "create_tools_error")
            raise ToolLoadError(
                message=f"Failed to create tools from module '{module_path}'.",
                error_code=ToolErrorCode.TOOL_LOAD_ERROR,
                module_path=module_path,
                cause=exc,
            ) from exc
        for tool in tool_definitions:
            log_parameter(
                "tool_loader.discover_external_tools",
                tool_id=getattr(tool, "tool_id", None),
            )
            try:
                validate_tool_definition(tool)
            except ValidationError as exc:
                log_branch("tool_loader.discover_external_tools", "validation_error")
                raise validation_error(module_path, tool.tool_id, exc.message) from exc
            if tool.tool_id in discovered:
                log_branch("tool_loader.discover_external_tools", "duplicate_tool_id")
                raise DuplicateToolError(
                    "tool already registered",
                    {"tool_id": tool.tool_id, "module_path": module_path},
                )
            discovered[tool.tool_id] = DiscoveredTool(
                tool_id=tool.tool_id,
                definition=tool,
                module_path=module_path,
                api_version=api_version,
            )
            log_branch("tool_loader.discover_external_tools", "tool_discovered")
    log_branch("tool_loader.discover_external_tools", "discovery_complete")
    return discovered


def create_external_handlers(
    discovered_tools: dict[str, DiscoveredTool],
    tool_ids: list[str],
    context: ToolHandlerContext,
) -> dict[str, Callable[[dict[str, Any]], Awaitable[Any]]]:
    """Create handlers for selected external tools.

    >>> import sys
    >>> from types import ModuleType
    >>> module = ModuleType("handler_mod")
    >>> def _create_tools():
    ...     return [ToolDefinition(tool_id="t1", name="t1", schema={"type": "object"})]
    >>> def _create_handlers(ctx):
    ...     return {"t1": lambda args: "ok"}
    >>> module.create_tools = _create_tools
    >>> module.create_handlers = _create_handlers
    >>> sys.modules["handler_mod"] = module
    >>> discovered = {
    ...     "t1": DiscoveredTool(
    ...         tool_id="t1",
    ...         definition=_create_tools()[0],
    ...         module_path="handler_mod",
    ...         api_version="1.0.0",
    ...     )
    ... }
    >>> handlers = create_external_handlers(
    ...     discovered, ["t1"], ToolHandlerContext(root_dir=Path.cwd())
    ... )
    >>> sorted(handlers.keys())
    ['t1']
    """
    log_parameter(
        "tool_loader.create_external_handlers",
        num_discovered_tools=len(discovered_tools),
        num_requested_tool_ids=len(tool_ids),
        has_file_cache=context.file_cache is not None,
    )
    selected_external_tool_ids = {
        tool_id for tool_id in tool_ids if tool_id in discovered_tools
    }
    if not selected_external_tool_ids:
        log_branch("tool_loader.create_external_handlers", "no_external_selected")
        return {}

    module_to_tool_ids: dict[str, set[str]] = {}
    for tool_id in selected_external_tool_ids:
        module_path = discovered_tools[tool_id].module_path
        module_to_tool_ids.setdefault(module_path, set()).add(tool_id)

    handlers: dict[str, Callable[[dict[str, Any]], Awaitable[Any]]] = {}
    for module_path in sorted(module_to_tool_ids):
        selected_ids_for_module = sorted(module_to_tool_ids[module_path])
        log_parameter(
            "tool_loader.create_external_handlers",
            module_path=module_path,
            selected_tool_ids=selected_ids_for_module,
        )
        module = _load_module(module_path)
        _validate_factories(module_path, module)
        try:
            module_handlers = module.create_handlers(context)
        except Exception as exc:
            log_branch("tool_loader.create_external_handlers", "create_handlers_error")
            raise handler_error(module_path, selected_ids_for_module[0], exc) from exc

        if not isinstance(module_handlers, dict):
            log_branch("tool_loader.create_external_handlers", "invalid_handlers_type")
            raise ToolLoadError(
                message=(
                    f"Module '{module_path}' create_handlers() returned "
                    f"'{type(module_handlers).__name__}', expected dict."
                ),
                error_code=ToolErrorCode.TOOL_HANDLER_ERROR,
                module_path=module_path,
                factory_name="create_handlers",
                context={"selected_tool_ids": selected_ids_for_module},
            )

        for tool_id in selected_ids_for_module:
            if tool_id not in module_handlers:
                log_branch("tool_loader.create_external_handlers", "missing_handler")
                raise handler_error(module_path, tool_id)
            handler = module_handlers[tool_id]
            if not callable(handler):
                log_branch(
                    "tool_loader.create_external_handlers",
                    "handler_not_callable",
                )
                raise ToolLoadError(
                    message=(
                        f"Handler for tool '{tool_id}' from module "
                        f"'{module_path}' is not callable."
                    ),
                    error_code=ToolErrorCode.TOOL_HANDLER_ERROR,
                    module_path=module_path,
                    factory_name="create_handlers",
                    context={"tool_id": tool_id},
                )
            handlers[tool_id] = handler
            log_branch("tool_loader.create_external_handlers", "handler_selected")

    log_branch("tool_loader.create_external_handlers", "handlers_complete")
    return handlers


def validate_tool_config(
    tools: list[str],
    tool_config_paths: list[str],
    builtin_tool_ids: set[str],
) -> None:
    """Validate tool configuration before discovery.

    >>> validate_tool_config(["bash"], [], {"bash"}) is None
    True
    """
    log_parameter(
        "tool_loader.validate_tool_config",
        num_tools=len(tools),
        num_tool_config_paths=len(tool_config_paths),
        num_builtin_tool_ids=len(builtin_tool_ids),
    )

    seen_tool_ids: set[str] = set()
    duplicate_tool_ids: set[str] = set()
    for index, tool_id in enumerate(tools):
        if not isinstance(tool_id, str) or not tool_id.strip():
            log_branch("tool_loader.validate_tool_config", "invalid_tool_id")
            raise ConfigurationError(
                "SDKConfig.tools must contain non-empty tool_id strings.",
                {"index": index, "value": tool_id},
            )
        if tool_id in seen_tool_ids:
            duplicate_tool_ids.add(tool_id)
        else:
            seen_tool_ids.add(tool_id)
    if duplicate_tool_ids:
        log_branch("tool_loader.validate_tool_config", "duplicate_tool_ids")
        raise ConfigurationError(
            "Duplicate tool_id entries in SDKConfig.tools.",
            {"duplicate_tool_ids": sorted(duplicate_tool_ids)},
        )

    seen_paths: set[str] = set()
    duplicate_paths: set[str] = set()
    for index, module_path in enumerate(tool_config_paths):
        if not isinstance(module_path, str) or not module_path.strip():
            log_branch("tool_loader.validate_tool_config", "invalid_module_path")
            raise ConfigurationError(
                "SDKConfig.tool_config_paths must contain non-empty module paths.",
                {"index": index, "value": module_path},
            )
        if module_path in seen_paths:
            duplicate_paths.add(module_path)
        else:
            seen_paths.add(module_path)
    if duplicate_paths:
        log_branch("tool_loader.validate_tool_config", "duplicate_module_paths")
        raise ConfigurationError(
            "Duplicate module paths in SDKConfig.tool_config_paths.",
            {"duplicate_module_paths": sorted(duplicate_paths)},
        )

    if not tool_config_paths:
        unknown_without_discovery = sorted(
            tool_id for tool_id in tools if tool_id not in builtin_tool_ids
        )
        if unknown_without_discovery:
            log_branch(
                "tool_loader.validate_tool_config",
                "unknown_without_discovery",
            )
            raise ConfigurationError(
                "Unknown tool_id(s) in SDKConfig.tools without tool discovery configured.",
                {"unknown_tool_ids": unknown_without_discovery},
            )

    log_branch("tool_loader.validate_tool_config", "config_valid")


__all__ = [
    "DiscoveredTool",
    "TOOL_API_VERSION",
    "ToolFactoryProtocol",
    "ToolHandlerContext",
    "_load_module",
    "_parse_major_version",
    "_validate_api_version",
    "_validate_factories",
    "create_external_handlers",
    "discover_external_tools",
    "validate_tool_config",
]
