"""File edit tool implementation.

>>> import asyncio
>>> import tempfile
>>> from pathlib import Path
>>> async def _edit_example():
...     with tempfile.TemporaryDirectory() as tmp:
...         path = Path(tmp) / "a.txt"
...         path.write_text("hello")
...         out = await execute_file_edit(
...             FileEditInput(file_path=path, old_string="hello", new_string="hi"),
...             boundary=Path(tmp),
...         )
...         return out.success, "hi" in path.read_text()
>>> asyncio.run(_edit_example())
(True, True)
>>> async def _ambiguity_example():
...     with tempfile.TemporaryDirectory() as tmp:
...         path = Path(tmp) / "a.txt"
...         path.write_text("foo foo")
...         try:
...             await execute_file_edit(
...                 FileEditInput(file_path=path, old_string="foo", new_string="bar"),
...                 boundary=Path(tmp),
...             )
...         except ValidationError:
...             return True
...         return False
>>> asyncio.run(_ambiguity_example())
True
>>> async def _conflict_example():
...     with tempfile.TemporaryDirectory() as tmp:
...         path = Path(tmp) / "a.txt"
...         path.write_text("hello")
...         loop = asyncio.get_running_loop()
...         loop.call_soon(path.write_text, "hello changed")
...         try:
...             await execute_file_edit(
...                 FileEditInput(file_path=path, old_string="hello", new_string="hi"),
...                 boundary=Path(tmp),
...             )
...         except ValidationError:
...             return True
...         return False
>>> asyncio.run(_conflict_example())
True
>>> async def _fallback_example():
...     with tempfile.TemporaryDirectory() as tmp:
...         path = Path(tmp) / "a.txt"
...         path.write_text("hello")
...         loop = asyncio.get_running_loop()
...         loop.call_soon(path.write_text, "hello changed")
...         out = await execute_file_edit(
...             FileEditInput(file_path=path, old_string="hello", new_string="hi"),
...             allow_full_rewrite=True,
...             boundary=Path(tmp),
...         )
...         return out.success and "hi" in path.read_text()
>>> asyncio.run(_fallback_example())
True
"""

from __future__ import annotations

import asyncio
import hashlib
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

from wormhole_core.errors import ValidationError
from wormhole_core.schemas.tools import (
    ApprovalPayload,
    RiskLevel,
    ToolCapabilities,
    ToolDefinition,
)
from wormhole_core.tools.path_utils import (
    ensure_within_boundary,
    normalize_path_pattern,
)

from .file_read import CachedFileState, FileReadCache

TOOL_ID = "file_edit"


@dataclass(frozen=True)
class FileEditInput:
    """Input for file edit operations."""

    file_path: Path
    old_string: str
    new_string: str
    replace_all: bool = False

    def __post_init__(self) -> None:
        if not self.file_path.is_absolute():
            raise ValidationError("file_path must be absolute")
        if not self.old_string:
            raise ValidationError("old_string must not be empty")
        if self.old_string == self.new_string:
            raise ValidationError("old_string must differ from new_string")


@dataclass(frozen=True)
class FileEditOutput:
    """Output from file edit operations."""

    success: bool
    file_path: Path
    lines_changed: int
    occurrences_replaced: int
    diff_summary: str
    content_hash_before: str
    content_hash_after: str


def parse_file_edit_input(arguments: Mapping[str, Any]) -> FileEditInput:
    return FileEditInput(
        file_path=Path(arguments["file_path"]),
        old_string=str(arguments.get("old_string", "")),
        new_string=str(arguments.get("new_string", "")),
        replace_all=bool(arguments.get("replace_all", False)),
    )


def create_file_edit_tool() -> ToolDefinition:
    schema = {
        "type": "object",
        "properties": {
            "file_path": {"type": "string"},
            "old_string": {"type": "string"},
            "new_string": {"type": "string"},
            "replace_all": {"type": "boolean"},
        },
        "required": ["file_path", "old_string", "new_string"],
    }

    def _approval_payload(arguments: Mapping[str, Any]) -> ApprovalPayload:
        inp = parse_file_edit_input(arguments)
        content = inp.file_path.read_text(encoding="utf-8", errors="replace")
        updated, diff_summary, occurrences = _apply_edit(
            content, inp.old_string, inp.new_string, inp.replace_all
        )
        target = normalize_path_pattern(str(inp.file_path))
        return ApprovalPayload(
            input_summary=f"edit {inp.file_path}",
            risk_assessment=RiskLevel.MEDIUM,
            preview={"diff": diff_summary},
            target_context={"target": target, "occurrences": occurrences},
        )

    return ToolDefinition(
        tool_id=TOOL_ID,
        name="file_edit",
        schema=schema,
        description="Edit file contents with diff preview",
        capabilities=ToolCapabilities(approval_required=True),
        approval_payload=_approval_payload,
    )


def _hash_content(content: str) -> str:
    return hashlib.sha256(content.encode("utf-8")).hexdigest()


def _apply_edit(
    content: str, old: str, new: str, replace_all: bool
) -> tuple[str, str, int]:
    occurrences = content.count(old)
    if occurrences == 0:
        raise ValidationError("old_string not found", {"occurrences": 0})
    if not replace_all and occurrences > 1:
        raise ValidationError("old_string not unique", {"occurrences": occurrences})
    updated = content.replace(old, new) if replace_all else content.replace(old, new, 1)
    diff = _diff_summary(content, updated)
    return updated, diff, occurrences if replace_all else 1


def _diff_summary(before: str, after: str) -> str:
    import difflib

    return "\n".join(
        difflib.unified_diff(
            before.splitlines(),
            after.splitlines(),
            fromfile="before",
            tofile="after",
            lineterm="",
        )
    )


def _atomic_write(path: Path, content: str) -> None:
    directory = path.parent
    with tempfile.NamedTemporaryFile(
        "w", delete=False, dir=directory, encoding="utf-8"
    ) as handle:
        handle.write(content)
        temp_path = Path(handle.name)
    temp_path.replace(path)


def build_file_edit_approval_payload(
    file_path: Path, diff_summary: str, occurrences: int
) -> ApprovalPayload:
    target = normalize_path_pattern(str(file_path))
    return ApprovalPayload(
        input_summary=f"edit {file_path}",
        risk_assessment=RiskLevel.MEDIUM,
        preview={"diff": diff_summary},
        target_context={"target": target, "occurrences": occurrences},
    )


async def execute_file_edit(
    tool_input: FileEditInput,
    *,
    boundary: Path | None = None,
    allow_full_rewrite: bool = False,
    read_cache: FileReadCache | None = None,
) -> FileEditOutput:
    """Apply a file edit with conflict detection.

    If read_cache is provided, checks that the file hasn't changed since
    the agent last read it. If the file was modified externally or never
    read, raises ValidationError telling the agent to read the file first.
    """
    if boundary is not None:
        ensure_within_boundary(tool_input.file_path, boundary)
    if not tool_input.file_path.exists():
        raise ValidationError("file_path does not exist")

    # Check if file was read and hasn't changed since
    if read_cache is not None:
        cached_state = read_cache.get(tool_input.file_path)
        if cached_state is None:
            raise ValidationError(
                "file not read yet - use file_read first to see current content before editing",
                {"file_path": str(tool_input.file_path)},
            )
        current_mtime = tool_input.file_path.stat().st_mtime
        if current_mtime != cached_state.mtime:
            raise ValidationError(
                "file changed since last read - use file_read again to see current content",
                {
                    "file_path": str(tool_input.file_path),
                    "cached_mtime": cached_state.mtime,
                    "current_mtime": current_mtime,
                },
            )

    content = tool_input.file_path.read_text(encoding="utf-8", errors="replace")
    content_hash_before = _hash_content(content)
    updated, diff_summary, occurrences = _apply_edit(
        content, tool_input.old_string, tool_input.new_string, tool_input.replace_all
    )
    await asyncio.sleep(0)
    latest = tool_input.file_path.read_text(encoding="utf-8", errors="replace")
    if _hash_content(latest) != content_hash_before and not allow_full_rewrite:
        raise ValidationError(
            "file changed during edit", {"file_path": str(tool_input.file_path)}
        )
    if _hash_content(latest) != content_hash_before and allow_full_rewrite:
        updated, diff_summary, occurrences = _apply_edit(
            latest, tool_input.old_string, tool_input.new_string, tool_input.replace_all
        )
    _atomic_write(tool_input.file_path, updated)
    content_hash_after = _hash_content(updated)
    lines_changed = abs(len(updated.splitlines()) - len(content.splitlines())) or 1

    # Update cache so sequential edits work without re-reading
    if read_cache is not None:
        stat = tool_input.file_path.stat()
        read_cache.update(
            CachedFileState(
                path=tool_input.file_path,
                mtime=stat.st_mtime,
                size=stat.st_size,
                content_hash=content_hash_after,
            )
        )

    return FileEditOutput(
        success=True,
        file_path=tool_input.file_path,
        lines_changed=lines_changed,
        occurrences_replaced=occurrences,
        diff_summary=diff_summary,
        content_hash_before=content_hash_before,
        content_hash_after=content_hash_after,
    )
