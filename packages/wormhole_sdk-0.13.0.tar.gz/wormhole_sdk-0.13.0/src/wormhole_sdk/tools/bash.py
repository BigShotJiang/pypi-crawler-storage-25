"""Bash tool implementation with permission gating and output capture.

>>> from pathlib import Path
>>> build_bash_permission_target("git status", Path("/project"))
'git * @ /project/*'
>>> import asyncio, sys
>>> async def _happy():
...     result = await execute_bash(BashToolInput(command=f\"{sys.executable} -c \\\"print('ok')\\\"\"))
...     return \"ok\" in result.stdout
>>> asyncio.run(_happy())
True
>>> async def _timeout():
...     try:
...         await execute_bash(BashToolInput(command=f\"{sys.executable} -c \\\"import time; time.sleep(0.2)\\\"\", timeout=0.01))
...     except ToolExecutionTimeoutError:
...         return True
...     return False
>>> asyncio.run(_timeout())
True
>>> async def _denied():
...     try:
...         await execute_bash(BashToolInput(command=\"rm -rf /tmp\"), banned_patterns=[\"rm -rf *\"])
...     except PermissionDeniedError:
...         return True
...     return False
>>> asyncio.run(_denied())
True
"""

from __future__ import annotations

import asyncio
import os
import shlex
import time
from dataclasses import dataclass
from fnmatch import fnmatchcase
from pathlib import Path
from typing import Any, Mapping, Sequence

from wormhole_core.errors import (
    PermissionDeniedError,
    ToolExecutionTimeoutError,
    ValidationError,
)
from wormhole_core.schemas.tools import (
    ApprovalPayload,
    ToolCapabilities,
    ToolDefinition,
)
from wormhole_core.tools.dangerous_commands import (
    assess_risk_level,
    detect_dangerous_patterns,
    detect_directory_escape,
    detect_shell_injection,
)
from wormhole_core.tools.output_utils import truncate_output
from wormhole_core.tools.permission_cache import build_bash_permission_target
from wormhole_core.tools.shell_utils import needs_shell

DEFAULT_TIMEOUT_SECONDS = 120.0
DEFAULT_OUTPUT_LIMIT = 30_000
TOOL_ID = "bash"


@dataclass(frozen=True)
class BashToolInput:
    """Input for bash command execution."""

    command: str
    timeout: float = DEFAULT_TIMEOUT_SECONDS
    working_directory: Path | None = None
    environment: dict[str, str] | None = None

    def __post_init__(self) -> None:
        if not self.command.strip():
            raise ValidationError("command must not be empty")
        if self.timeout <= 0:
            raise ValidationError("timeout must be > 0")


@dataclass(frozen=True)
class BashToolOutput:
    """Output from bash command execution."""

    exit_code: int
    stdout: str
    stderr: str
    duration_seconds: float
    stdout_lines: int
    stderr_lines: int
    truncated: bool
    timed_out: bool


def build_bash_approval_payload(
    command: str, cwd: Path, boundary: Path | None = None
) -> ApprovalPayload:
    target = build_bash_permission_target(command, cwd)
    boundary = boundary or cwd
    dangerous = detect_dangerous_patterns(command)
    shell_injection = detect_shell_injection(command)
    directory_escape = detect_directory_escape(command, cwd, boundary)
    risk = assess_risk_level(
        command,
        dangerous_patterns=dangerous,
        shell_injection=shell_injection,
        directory_escape=directory_escape,
    )
    return ApprovalPayload(
        input_summary=command,
        risk_assessment=risk,
        preview={
            "command": command,
            "dangerous_patterns": dangerous,
            "shell_injection": shell_injection,
            "directory_escape": directory_escape,
        },
        target_context={"cwd": str(cwd), "target": target},
    )


def _matches_banned_patterns(command: str, patterns: Sequence[str]) -> str | None:
    for pattern in patterns:
        if fnmatchcase(command, pattern):
            return pattern
    return None


def parse_bash_input(arguments: Mapping[str, Any]) -> BashToolInput:
    return BashToolInput(
        command=str(arguments.get("command", "")),
        timeout=float(arguments.get("timeout", DEFAULT_TIMEOUT_SECONDS)),
        working_directory=Path(arguments["working_directory"])
        if "working_directory" in arguments
        else None,
        environment=dict(arguments.get("environment") or {}) or None,
    )


def create_bash_tool() -> ToolDefinition:
    schema = {
        "type": "object",
        "properties": {
            "command": {"type": "string"},
            "timeout": {"type": "number"},
            "working_directory": {"type": "string"},
            "environment": {
                "type": "object",
                "additionalProperties": {"type": "string"},
            },
        },
        "required": ["command"],
    }

    def _approval_payload(arguments: Mapping[str, Any]) -> ApprovalPayload:
        inp = parse_bash_input(arguments)
        cwd = inp.working_directory or Path.cwd()
        return build_bash_approval_payload(inp.command, cwd, boundary=cwd)

    return ToolDefinition(
        tool_id=TOOL_ID,
        name="bash",
        schema=schema,
        description="Execute shell commands with approval",
        capabilities=ToolCapabilities(approval_required=True),
        approval_payload=_approval_payload,
    )


async def execute_bash(
    tool_input: BashToolInput,
    *,
    cwd: Path | None = None,
    banned_patterns: Sequence[str] | None = None,
    output_limit: int = DEFAULT_OUTPUT_LIMIT,
) -> BashToolOutput:
    """Execute a bash command with output capture."""
    working_dir = tool_input.working_directory or cwd or Path.cwd()
    banned_patterns = banned_patterns or []
    matched_banned = _matches_banned_patterns(tool_input.command, banned_patterns)
    if matched_banned:
        raise PermissionDeniedError(
            "command matches banned pattern",
            {"tool_id": TOOL_ID, "pattern": matched_banned},
        )

    env = os.environ.copy()
    if tool_input.environment:
        env.update(tool_input.environment)

    start = time.monotonic()
    timed_out = False
    stdout_text = ""
    stderr_text = ""
    if needs_shell(tool_input.command):
        process = await asyncio.create_subprocess_shell(
            tool_input.command,
            stdin=asyncio.subprocess.DEVNULL,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=str(working_dir),
            env=env,
        )
    else:
        args = shlex.split(tool_input.command)
        if not args:
            raise ValidationError("command must not be empty")
        process = await asyncio.create_subprocess_exec(
            *args,
            stdin=asyncio.subprocess.DEVNULL,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=str(working_dir),
            env=env,
        )
    try:
        stdout_bytes, stderr_bytes = await asyncio.wait_for(
            process.communicate(),
            timeout=tool_input.timeout,
        )
        stdout_text = (
            stdout_bytes.decode("utf-8", errors="replace") if stdout_bytes else ""
        )
        stderr_text = (
            stderr_bytes.decode("utf-8", errors="replace") if stderr_bytes else ""
        )
    except asyncio.TimeoutError as exc:
        timed_out = True
        if process.returncode is None:
            try:
                process.terminate()
            except ProcessLookupError:
                pass
            try:
                await asyncio.wait_for(process.wait(), timeout=1.0)
            except asyncio.TimeoutError:
                if process.returncode is None:
                    try:
                        process.kill()
                    except ProcessLookupError:
                        pass
                try:
                    await process.wait()
                except ProcessLookupError:
                    pass
        raise ToolExecutionTimeoutError(
            "tool execution timed out",
            tool_id=TOOL_ID,
            tool_call_id=None,
            timeout=tool_input.timeout,
        ) from exc

    duration = time.monotonic() - start
    stdout_trimmed, stdout_lines, stdout_truncated = truncate_output(
        stdout_text, output_limit
    )
    stderr_trimmed, stderr_lines, stderr_truncated = truncate_output(
        stderr_text, output_limit
    )
    return BashToolOutput(
        exit_code=process.returncode or 0,
        stdout=stdout_trimmed,
        stderr=stderr_trimmed,
        duration_seconds=duration,
        stdout_lines=stdout_lines,
        stderr_lines=stderr_lines,
        truncated=stdout_truncated or stderr_truncated,
        timed_out=timed_out,
    )
