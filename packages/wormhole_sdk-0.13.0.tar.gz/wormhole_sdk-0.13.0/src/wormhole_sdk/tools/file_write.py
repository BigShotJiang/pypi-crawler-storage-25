"""File write tool implementation.

>>> import asyncio
>>> import tempfile
>>> from pathlib import Path
>>> async def _write_example():
...     with tempfile.TemporaryDirectory() as tmp:
...         path = Path(tmp) / "new.txt"
...         out = await execute_file_write(
...             FileWriteInput(file_path=path, content="hello"),
...             boundary=Path(tmp),
...         )
...         return out.created and path.read_text() == "hello"
>>> asyncio.run(_write_example())
True
>>> with tempfile.TemporaryDirectory() as tmp:
...     path = Path(tmp) / "existing.txt"
...     _ = path.write_text("old")
...     payload = build_file_write_approval_payload(path, "new", "utf-8")
...     "diff" in payload.preview
True
>>> async def _parents_example():
...     with tempfile.TemporaryDirectory() as tmp:
...         path = Path(tmp) / "a" / "b" / "c.txt"
...         out = await execute_file_write(
...             FileWriteInput(file_path=path, content="x", create_parents=True),
...             boundary=Path(tmp),
...         )
...         return len(out.directories_created) > 0 and path.exists()
>>> asyncio.run(_parents_example())
True
"""

from __future__ import annotations

import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, Sequence

from wormhole_core.errors import ValidationError
from wormhole_core.schemas.tools import (
    ApprovalPayload,
    RiskLevel,
    ToolCapabilities,
    ToolDefinition,
)
from wormhole_core.tools.path_utils import (
    ensure_within_boundary,
    normalize_path_pattern,
)

TOOL_ID = "file_write"


@dataclass(frozen=True)
class FileWriteInput:
    """Input for file write operations."""

    file_path: Path
    content: str
    create_parents: bool = False
    overwrite: bool = False
    encoding: str = "utf-8"

    def __post_init__(self) -> None:
        if not self.file_path.is_absolute():
            raise ValidationError("file_path must be absolute")


@dataclass(frozen=True)
class FileWriteOutput:
    """Output from file write operations."""

    success: bool
    file_path: Path
    bytes_written: int
    created: bool
    overwritten: bool
    directories_created: Sequence[Path]


def parse_file_write_input(arguments: Mapping[str, Any]) -> FileWriteInput:
    return FileWriteInput(
        file_path=Path(arguments["file_path"]),
        content=str(arguments.get("content", "")),
        create_parents=bool(arguments.get("create_parents", False)),
        overwrite=bool(arguments.get("overwrite", False)),
        encoding=str(arguments.get("encoding", "utf-8")),
    )


def create_file_write_tool() -> ToolDefinition:
    schema = {
        "type": "object",
        "properties": {
            "file_path": {"type": "string"},
            "content": {"type": "string"},
            "create_parents": {"type": "boolean"},
            "overwrite": {"type": "boolean"},
            "encoding": {"type": "string"},
        },
        "required": ["file_path", "content"],
    }

    def _approval_payload(arguments: Mapping[str, Any]) -> ApprovalPayload:
        inp = parse_file_write_input(arguments)
        diff_summary = _diff_summary(inp.file_path, inp.content, inp.encoding)
        target = normalize_path_pattern(str(inp.file_path))
        preview = {"content": inp.content}
        if diff_summary:
            preview["diff"] = diff_summary
        return ApprovalPayload(
            input_summary=f"write {inp.file_path}",
            risk_assessment=RiskLevel.MEDIUM,
            preview=preview,
            target_context={"target": target},
        )

    return ToolDefinition(
        tool_id=TOOL_ID,
        name="file_write",
        schema=schema,
        description="Create or overwrite files with approval",
        capabilities=ToolCapabilities(approval_required=True),
        approval_payload=_approval_payload,
    )


def _diff_summary(path: Path, content: str, encoding: str) -> str | None:
    if not path.exists():
        return None
    import difflib

    before = path.read_text(encoding=encoding, errors="replace")
    return "\n".join(
        difflib.unified_diff(
            before.splitlines(),
            content.splitlines(),
            fromfile="before",
            tofile="after",
            lineterm="",
        )
    )


def _atomic_write(path: Path, content: str, encoding: str) -> None:
    directory = path.parent
    with tempfile.NamedTemporaryFile(
        "w", delete=False, dir=directory, encoding=encoding
    ) as handle:
        handle.write(content)
        temp_path = Path(handle.name)
    temp_path.replace(path)


def build_file_write_approval_payload(
    file_path: Path, content: str, encoding: str
) -> ApprovalPayload:
    diff_summary = _diff_summary(file_path, content, encoding)
    target = normalize_path_pattern(str(file_path))
    preview = {"content": content}
    if diff_summary:
        preview["diff"] = diff_summary
    return ApprovalPayload(
        input_summary=f"write {file_path}",
        risk_assessment=RiskLevel.MEDIUM,
        preview=preview,
        target_context={"target": target},
    )


async def execute_file_write(
    tool_input: FileWriteInput,
    *,
    boundary: Path | None = None,
) -> FileWriteOutput:
    """Write file contents."""
    if boundary is not None:
        ensure_within_boundary(tool_input.file_path, boundary)

    directories_created: list[Path] = []
    if tool_input.create_parents:
        parent = tool_input.file_path.parent
        missing: list[Path] = []
        current = parent
        while not current.exists():
            missing.append(current)
            if current.parent == current:
                break
            current = current.parent
        parent.mkdir(parents=True, exist_ok=True)
        directories_created = list(reversed(missing))

    exists = tool_input.file_path.exists()
    if exists and not tool_input.overwrite:
        raise ValidationError(
            "file exists and overwrite is false",
            {"file_path": str(tool_input.file_path)},
        )

    _atomic_write(tool_input.file_path, tool_input.content, tool_input.encoding)
    return FileWriteOutput(
        success=True,
        file_path=tool_input.file_path,
        bytes_written=len(tool_input.content.encode(tool_input.encoding)),
        created=not exists,
        overwritten=exists,
        directories_created=directories_created,
    )
