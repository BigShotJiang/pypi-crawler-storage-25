"""TaskTool implementation for delegated child-agent execution.

>>> inp = TaskToolInput(task="Summarize file")
>>> inp.max_steps
25
>>> out = TaskToolOutput(
...     status="success",
...     result="done",
...     child_session_id="child-1",
...     tool_summary=[],
... )
>>> "status: success" in out.to_text()
True
"""

from __future__ import annotations

import asyncio
import hashlib
import inspect
import logging
import time
from dataclasses import dataclass, field, replace
from typing import Any, Awaitable, Callable, Mapping, Sequence
from uuid import uuid4

from wormhole_core.errors import (
    ChildSessionFailedError,
    ChildSessionTimeoutError,
    DelegationDepthExceededError,
    TaskToolError,
    ValidationError,
)
from wormhole_core.schemas.delegation import DelegationContext
from wormhole_core.schemas.tools import ToolCapabilities, ToolDefinition
from wormhole_core.storage.session_store import SessionRecord

from ..config import SDKConfig
from ..hooks import HookRegistry, SessionHooks
from ..log_redaction import (
    REDACTED as LOG_REDACTED,
)
from ..log_redaction import (
    debug_logging_enabled,
    sanitize_log_extra,
)
from ..prompt import PromptBuilder
from ..termination import ContinuationMode

LOGGER = logging.getLogger("wormhole_sdk.task_tool")

TOOL_TASK = "task"

TASK_TOOL_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "task": {
            "type": "string",
            "description": "Task description for delegated child session",
        },
        "system_prompt": {
            "type": "string",
            "description": "Optional custom system prompt for child session",
        },
        "tools": {
            "type": "array",
            "items": {"type": "string"},
            "description": "Optional child-tool allowlist",
        },
        "context_limit": {
            "type": "integer",
            "minimum": 1,
            "description": "Optional child context limit override",
        },
        "max_steps": {
            "type": "integer",
            "minimum": 1,
            "description": "Max model round-trips for child",
        },
        "timeout_seconds": {
            "type": "number",
            "exclusiveMinimum": 0,
            "description": "Optional wall-clock timeout for child execution",
        },
    },
    "required": ["task"],
}

RECOVERY_TURN_PROMPT = """MAXIMUM STEPS OR TIME LIMIT REACHED

You are in recovery mode and tools are disabled.

Respond with:
1. Summary of completed work
2. Remaining work
3. Recommended next steps"""

TIMEOUT_GRACE_SECONDS = 60.0
DEFAULT_MAX_STEPS = 25
DEFAULT_MAX_DEPTH = 3
DEFAULT_LOCKED_LAYERS = ("identity", "mandates", "safety")
REDACTED = LOG_REDACTED
_LAYER_ALIASES: dict[str, set[str]] = {
    "identity": {"identity", "identity preamble"},
    "mandates": {"mandates", "core mandates"},
    "environment": {"environment", "environment context"},
    "project": {"project", "project instructions"},
    "tools": {"tools", "tool documentation", "tool docs"},
    "safety": {"safety", "safety reminders"},
}


@dataclass(frozen=True)
class TaskToolInput:
    """Validated TaskTool input."""

    task: str
    system_prompt: str | None = None
    tools: list[str] | None = None
    context_limit: int | None = None
    max_steps: int = DEFAULT_MAX_STEPS
    timeout_seconds: float | None = None

    def __post_init__(self) -> None:
        if not self.task.strip():
            raise ValueError("task must be a non-empty string")
        if self.max_steps < 1:
            raise ValueError(f"max_steps must be >= 1, got {self.max_steps}")
        if self.timeout_seconds is not None and self.timeout_seconds <= 0:
            raise ValueError(
                f"timeout_seconds must be > 0 when set, got {self.timeout_seconds}"
            )
        if self.context_limit is not None and self.context_limit < 1:
            raise ValueError(
                f"context_limit must be >= 1 when set, got {self.context_limit}"
            )
        if self.tools is not None:
            if not isinstance(self.tools, list):
                raise ValueError("tools must be a list[str] when provided")
            normalized: list[str] = []
            for tool_id in self.tools:
                if not isinstance(tool_id, str) or not tool_id.strip():
                    raise ValueError("tools entries must be non-empty strings")
                normalized.append(tool_id.strip())
            object.__setattr__(self, "tools", normalized)

    @classmethod
    def from_args(cls, args: Mapping[str, Any]) -> "TaskToolInput":
        """Parse TaskToolInput from raw arguments mapping."""
        return cls(
            task=str(args.get("task", "")),
            system_prompt=_to_optional_str(args.get("system_prompt")),
            tools=_to_optional_str_list(args.get("tools")),
            context_limit=_to_optional_int(args.get("context_limit")),
            max_steps=int(args.get("max_steps", DEFAULT_MAX_STEPS)),
            timeout_seconds=_to_optional_float(args.get("timeout_seconds")),
        )


@dataclass(frozen=True)
class ToolCallSummary:
    """Tool-call summary captured from child execution stream."""

    tool_id: str
    call_id: str
    status: str
    title: str | None = None


@dataclass(frozen=True)
class TaskToolOutput:
    """Structured TaskTool output delivered back to parent."""

    status: str
    result: str
    child_session_id: str
    tool_summary: list[ToolCallSummary]

    def to_text(self) -> str:
        """Serialize output as text payload for model tool output parsing."""
        lines = [self.result, "", "<task_metadata>"]
        lines.append(f"status: {self.status}")
        lines.append(f"child_session_id: {self.child_session_id}")
        lines.append(f"tool_calls: {len(self.tool_summary)}")
        for summary in self.tool_summary:
            title = f" - {summary.title}" if summary.title else ""
            lines.append(f"  {summary.tool_id} [{summary.status}]{title}")
        lines.append("</task_metadata>")
        return "\n".join(lines)


@dataclass(frozen=True)
class TaskToolConfig:
    """Configuration defaults for TaskTool behavior."""

    max_depth: int = DEFAULT_MAX_DEPTH
    default_max_steps: int = DEFAULT_MAX_STEPS
    default_timeout_seconds: float | None = None
    default_context_limit: int | None = None
    default_tools: list[str] | None = None
    default_locked_layers: list[str] | None = None
    allow_recursive_task: bool = False

    def __post_init__(self) -> None:
        if self.max_depth < 1:
            raise ValueError(f"max_depth must be >= 1, got {self.max_depth}")
        if self.default_max_steps < 1:
            raise ValueError(
                f"default_max_steps must be >= 1, got {self.default_max_steps}"
            )
        if (
            self.default_timeout_seconds is not None
            and self.default_timeout_seconds <= 0
        ):
            raise ValueError("default_timeout_seconds must be > 0 when provided")
        if self.default_context_limit is not None and self.default_context_limit < 1:
            raise ValueError("default_context_limit must be >= 1 when provided")
        if self.default_tools is not None:
            normalized = [tool_id.strip() for tool_id in self.default_tools if tool_id]
            object.__setattr__(self, "default_tools", normalized)
        if self.default_locked_layers is not None:
            normalized_layers = [
                _normalize_layer_key(layer) for layer in self.default_locked_layers
            ]
            object.__setattr__(self, "default_locked_layers", normalized_layers)


@dataclass(frozen=True)
class TaskToolHandlerContext:
    """Runtime context used by TaskTool handler."""

    delegation_context: DelegationContext
    parent_session_id: str
    parent_config: SDKConfig
    parent_hooks: HookRegistry
    parent_prompt_builder: PromptBuilder
    parent_storage_provider: Any | None
    parent_tools: list[ToolDefinition]
    parent_tool_handlers: Mapping[str, Callable[[dict[str, Any]], Awaitable[Any] | Any]]
    parent_client: Any
    task_tool_config: TaskToolConfig


def create_task_tool(config: TaskToolConfig | None = None) -> ToolDefinition:
    """Create TaskTool definition.

    >>> tool = create_task_tool()
    >>> tool.tool_id
    'task'
    >>> tool.capabilities.approval_required
    False
    """
    _ = config
    return ToolDefinition(
        tool_id=TOOL_TASK,
        name=TOOL_TASK,
        description=(
            "Delegate a sub-task to a child agent session and return structured "
            "completion metadata."
        ),
        schema=TASK_TOOL_SCHEMA,
        capabilities=ToolCapabilities(
            approval_required=False,
            concurrency_safe=False,
            read_only=False,
        ),
    )


def _log_debug(message: str, *, extra: Mapping[str, Any] | None = None) -> None:
    if not debug_logging_enabled(LOGGER):
        return
    LOGGER.debug(message, extra=sanitize_log_extra(extra))


def _log_warning(message: str, *, extra: Mapping[str, Any] | None = None) -> None:
    LOGGER.warning(message, extra=sanitize_log_extra(extra))


def _build_task_invocation_payload(
    *, task_input: TaskToolInput, parent_session_id: str
) -> dict[str, Any]:
    return {
        "event_type": "task_invocation",
        "task_hash": _hash_task_for_log(task_input.task),
        "has_system_prompt": bool(task_input.system_prompt),
        "tools": list(task_input.tools or []),
        "max_steps": task_input.max_steps,
        "timeout_seconds": task_input.timeout_seconds,
        "context_limit": task_input.context_limit,
        "parent_session_id": parent_session_id,
    }


def _build_child_context_payload(
    *, child_session_id: str, parent_session_id: str, context: DelegationContext
) -> dict[str, Any]:
    return {
        "event_type": "task_child_context",
        "child_session_id": child_session_id,
        "parent_session_id": parent_session_id,
        "root_session_id": context.root_session_id,
        "current_depth": context.current_depth,
        "max_depth": context.max_depth,
    }


def _build_effective_config_payload(
    *,
    child_session_id: str,
    max_steps: int,
    timeout_seconds: float | None,
    context_limit: int | None,
    selected_tools: Sequence[str],
) -> dict[str, Any]:
    return {
        "event_type": "task_effective_child_config",
        "child_session_id": child_session_id,
        "max_steps": max_steps,
        "timeout_seconds": timeout_seconds,
        "context_limit": context_limit,
        "tools": list(selected_tools),
    }


def _build_timeout_payload(
    *,
    event_type: str,
    child_session_id: str,
    timeout_seconds: float,
    active_elapsed_ms: int,
    total_paused_ms: int,
) -> dict[str, Any]:
    return {
        "event_type": event_type,
        "child_session_id": child_session_id,
        "timeout_seconds": timeout_seconds,
        "active_elapsed_ms": active_elapsed_ms,
        "total_paused_ms": total_paused_ms,
    }


def _build_timeout_grace_payload(
    *,
    event_type: str,
    child_session_id: str,
    grace_seconds: float,
    grace_started_at: float,
) -> dict[str, Any]:
    return {
        "event_type": event_type,
        "child_session_id": child_session_id,
        "grace_seconds": grace_seconds,
        "grace_started_at": grace_started_at,
        "grace_expires_at": grace_started_at + grace_seconds,
    }


def _build_recovery_mode_payload(
    *,
    child_session_id: str,
    trigger: str,
    tools_disabled: bool,
) -> dict[str, Any]:
    return {
        "event_type": "recovery_mode_activated",
        "child_session_id": child_session_id,
        "recovery_trigger": trigger,
        "tools_disabled": tools_disabled,
    }


def _build_approval_wait_start_payload(
    *,
    child_session_id: str,
    tool_id: str,
    tool_call_id: str,
    paused_at: float,
) -> dict[str, Any]:
    return {
        "event_type": "approval_wait_started",
        "child_session_id": child_session_id,
        "tool_id": tool_id,
        "tool_call_id": tool_call_id,
        "paused_at": paused_at,
        "approval_wait_start": paused_at,
    }


def _build_approval_wait_end_payload(
    *,
    child_session_id: str,
    tool_id: str,
    tool_call_id: str,
    resumed_at: float,
    decision: str | None,
    mode: str | None,
    match_outcome: str,
    wait_duration_ms: int,
    total_paused_ms: int,
) -> dict[str, Any]:
    return {
        "event_type": "approval_wait_ended",
        "child_session_id": child_session_id,
        "tool_id": tool_id,
        "tool_call_id": tool_call_id,
        "resumed_at": resumed_at,
        "approval_wait_end": resumed_at,
        "decision": decision,
        "mode": mode,
        "match_outcome": match_outcome,
        "wait_duration_ms": wait_duration_ms,
        "total_paused_ms": total_paused_ms,
    }


def create_task_handler(
    *,
    client: Any,
    task_tool_config: TaskToolConfig | None = None,
) -> Callable[[dict[str, Any]], Awaitable[str]]:
    """Create TaskTool handler bound to a parent client instance."""
    config = task_tool_config or TaskToolConfig()

    async def _handler(args: dict[str, Any]) -> str:
        context = _build_handler_context(client=client, task_tool_config=config)
        return await execute_task(args, context=context)

    return _handler


async def execute_task(
    args: Mapping[str, Any], *, context: TaskToolHandlerContext
) -> str:
    """Execute TaskTool by running a delegated child session."""
    started = time.monotonic()
    child_client: Any | None = None
    child_context: DelegationContext | None = None
    final_status: str | None = None
    approval_wait_tracker: _ApprovalWaitTracker | None = None
    approval_handler_patches: list[_ApprovalHandlerPatch] = []
    child_session_id = f"child-{uuid4().hex[:12]}"
    tool_summaries: list[ToolCallSummary] = []
    try:
        task_input = TaskToolInput.from_args(args)
        _log_debug(
            "TaskTool invocation",
            extra=_build_task_invocation_payload(
                task_input=task_input,
                parent_session_id=context.parent_session_id,
            ),
        )
        _validate_tool_subset(task_input.tools, context.parent_tools)
        child_context = context.delegation_context.for_child(
            parent_session_id=context.parent_session_id
        )
        _log_debug(
            "TaskTool child context derived",
            extra=_build_child_context_payload(
                child_session_id=child_session_id,
                parent_session_id=context.parent_session_id,
                context=child_context,
            ),
        )
        _emit_session_event(
            context.parent_hooks,
            {
                "type": "task_child_created",
                "parent_session_id": context.parent_session_id,
                "child_session_id": child_session_id,
                "root_session_id": child_context.root_session_id,
                "current_depth": child_context.current_depth,
                "max_depth": child_context.max_depth,
            },
        )
        _log_debug(
            "TaskTool lineage creation event",
            extra={
                "event_type": "task_child_event_emitted",
                "child_session_id": child_session_id,
                "parent_session_id": context.parent_session_id,
                "root_session_id": child_context.root_session_id,
                "status": "created",
            },
        )

        child_hooks = _build_child_hook_registry(context.parent_hooks)
        approval_wait_tracker = _ApprovalWaitTracker(child_session_id=child_session_id)
        approval_handler_patches = _install_approval_wait_tracking(
            child_hooks, approval_wait_tracker
        )
        child_prompt_builder = _build_child_prompt_builder(
            parent_builder=context.parent_prompt_builder,
            task_input=task_input,
            config=context.task_tool_config,
        )
        has_invocation_max_steps = "max_steps" in args
        effective_max_steps = _effective_max_steps(
            invocation_max_steps=(
                task_input.max_steps if has_invocation_max_steps else None
            ),
            config=context.task_tool_config,
            parent=context.parent_config,
        )
        effective_timeout = _effective_timeout_seconds(
            invocation_timeout=task_input.timeout_seconds,
            config=context.task_tool_config,
        )
        effective_context_limit = _effective_context_limit(
            invocation_context_limit=task_input.context_limit,
            config=context.task_tool_config,
            parent=context.parent_config,
        )
        selected_tool_ids = _resolve_child_tool_ids(
            task_input=task_input,
            config=context.task_tool_config,
            parent_tools=context.parent_tools,
            child_context=child_context,
        )
        _log_debug(
            "TaskTool effective child configuration",
            extra=_build_effective_config_payload(
                child_session_id=child_session_id,
                max_steps=effective_max_steps,
                timeout_seconds=effective_timeout,
                context_limit=effective_context_limit,
                selected_tools=selected_tool_ids,
            ),
        )

        child_config = _build_child_sdk_config(
            parent=context.parent_config,
            parent_client=context.parent_client,
            child_hooks=child_hooks,
            effective_max_steps=effective_max_steps,
            effective_context_limit=effective_context_limit,
            storage_provider=context.parent_storage_provider,
        )
        child_client = _create_child_client(child_config)
        child_client._prompt_builder = child_prompt_builder  # noqa: SLF001
        _ensure_delegation_map(child_client)[child_session_id] = child_context

        await _register_child_tools(
            child_client=child_client,
            parent_tools=context.parent_tools,
            parent_handlers=context.parent_tool_handlers,
            selected_tool_ids=selected_tool_ids,
            task_tool_config=context.task_tool_config,
        )

        outcome = await _run_child_with_limits(
            child_client=child_client,
            child_session_id=child_session_id,
            task_input=task_input,
            child_prompt_builder=child_prompt_builder,
            timeout_seconds=effective_timeout,
            tool_summaries=tool_summaries,
            approval_wait_tracker=approval_wait_tracker,
        )

        await _persist_lineage(
            child_client=child_client,
            child_session_id=child_session_id,
            parent_session_id=context.parent_session_id,
            child_context=child_context,
        )
        final_status = outcome.status
        output = TaskToolOutput(
            status=outcome.status,
            result=outcome.result,
            child_session_id=child_session_id,
            tool_summary=list(tool_summaries),
        )
        _log_debug(
            "TaskTool child execution completed",
            extra={
                "event_type": "task_child_completed",
                "child_session_id": child_session_id,
                "status": outcome.status,
                "tool_call_count": len(tool_summaries),
            },
        )
        return output.to_text()
    except DelegationDepthExceededError as exc:
        final_status = "failure"
        output = TaskToolOutput(
            status="failure",
            result=_format_task_error(exc),
            child_session_id=child_session_id,
            tool_summary=list(tool_summaries),
        )
        return output.to_text()
    except asyncio.CancelledError:
        final_status = "cancelled"
        output = TaskToolOutput(
            status="cancelled",
            result="Task delegation cancelled by parent session",
            child_session_id=child_session_id,
            tool_summary=list(tool_summaries),
        )
        return output.to_text()
    except ValidationError as exc:
        final_status = "failure"
        message = f"{exc.code.value}: {exc.message}"
        if exc.context:
            message = f"{message} ({exc.context})"
        output = TaskToolOutput(
            status="failure",
            result=message,
            child_session_id=child_session_id,
            tool_summary=list(tool_summaries),
        )
        return output.to_text()
    except TaskToolError as exc:
        final_status = "failure"
        output = TaskToolOutput(
            status="failure",
            result=_format_task_error(exc),
            child_session_id=child_session_id,
            tool_summary=list(tool_summaries),
        )
        return output.to_text()
    except Exception as exc:  # pragma: no cover - defensive path
        final_status = "failure"
        wrapped = ChildSessionFailedError(
            child_session_id=child_session_id,
            cause=str(exc),
        )
        output = TaskToolOutput(
            status="failure",
            result=_format_task_error(wrapped),
            child_session_id=child_session_id,
            tool_summary=list(tool_summaries),
        )
        return output.to_text()
    finally:
        if child_context is not None and final_status is not None:
            _log_debug(
                "TaskTool lineage completion event",
                extra={
                    "event_type": "task_child_event_emitted",
                    "child_session_id": child_session_id,
                    "parent_session_id": context.parent_session_id,
                    "root_session_id": child_context.root_session_id,
                    "status": final_status,
                },
            )
            _emit_session_event(
                context.parent_hooks,
                {
                    "type": f"task_child_{final_status}",
                    "parent_session_id": context.parent_session_id,
                    "child_session_id": child_session_id,
                    "root_session_id": child_context.root_session_id,
                    "status": final_status,
                },
            )
        _restore_approval_handlers(approval_handler_patches)
        elapsed_ms = int((time.monotonic() - started) * 1000)
        _log_debug(
            "TaskTool execution complete",
            extra={
                "event_type": "task_execution_complete",
                "elapsed_ms": elapsed_ms,
                "child_session_id": child_session_id,
            },
        )
        if child_client is not None:
            await child_client.close()


@dataclass(frozen=True)
class _ChildOutcome:
    status: str
    result: str


@dataclass
class _ApprovalWaitTracker:
    child_session_id: str
    total_paused_seconds: float = 0.0
    _active_waits: int = 0
    _pause_started_monotonic: float | None = None

    def on_wait_start(self, *, tool_id: str, tool_call_id: str) -> None:
        self._active_waits += 1
        if self._active_waits != 1:
            return
        self._pause_started_monotonic = time.monotonic()
        paused_at = time.time()
        _log_debug(
            "TaskTool approval wait started",
            extra=_build_approval_wait_start_payload(
                child_session_id=self.child_session_id,
                tool_id=tool_id,
                tool_call_id=tool_call_id,
                paused_at=paused_at,
            ),
        )

    def on_wait_end(
        self,
        *,
        tool_id: str,
        tool_call_id: str,
        decision: str | None,
        scope: str | None,
    ) -> None:
        if self._active_waits > 0:
            self._active_waits -= 1
        if self._active_waits != 0:
            return
        paused_start = self._pause_started_monotonic
        self._pause_started_monotonic = None
        if paused_start is None:
            return
        paused_duration = max(0.0, time.monotonic() - paused_start)
        self.total_paused_seconds += paused_duration
        resumed_at = time.time()
        _log_debug(
            "TaskTool approval wait ended",
            extra=_build_approval_wait_end_payload(
                child_session_id=self.child_session_id,
                tool_id=tool_id,
                tool_call_id=tool_call_id,
                resumed_at=resumed_at,
                decision=decision,
                mode=scope,
                match_outcome="prompted",
                wait_duration_ms=int(paused_duration * 1000),
                total_paused_ms=int(self.total_paused_seconds * 1000),
            ),
        )

    def active_paused_seconds(self) -> float:
        if self._pause_started_monotonic is None:
            return 0.0
        return max(0.0, time.monotonic() - self._pause_started_monotonic)

    def total_paused_seconds_including_active(self) -> float:
        return self.total_paused_seconds + self.active_paused_seconds()


@dataclass
class _ApprovalHandlerPatch:
    hook: Any
    original_handler: Any


async def _run_child_with_limits(
    *,
    child_client: Any,
    child_session_id: str,
    task_input: TaskToolInput,
    child_prompt_builder: PromptBuilder,
    timeout_seconds: float | None,
    tool_summaries: list[ToolCallSummary],
    approval_wait_tracker: _ApprovalWaitTracker | None,
) -> _ChildOutcome:
    if timeout_seconds is None:
        status, text = await _run_child_once(
            child_client=child_client,
            child_session_id=child_session_id,
            task=task_input.task,
            tool_summaries=tool_summaries,
            tools=None,
            system_prompt=None,
            continuation_mode=ContinuationMode.AUTOMATIC,
        )
        if status == "step-limit-reached":
            _log_debug(
                "TaskTool recovery mode activated",
                extra=_build_recovery_mode_payload(
                    child_session_id=child_session_id,
                    trigger="step_limit",
                    tools_disabled=True,
                ),
            )
            recovery = await _run_recovery_turn(
                child_client=child_client,
                child_session_id=child_session_id,
                child_prompt_builder=child_prompt_builder,
                tool_summaries=tool_summaries,
                timeout_seconds=TIMEOUT_GRACE_SECONDS,
            )
            return _ChildOutcome(status="step-limit-reached", result=recovery or text)
        if status == "failure":
            raise ChildSessionFailedError(child_session_id=child_session_id, cause=text)
        return _ChildOutcome(status="success", result=text)

    status, text, timed_out = await _run_child_with_pausable_timeout(
        child_client=child_client,
        child_session_id=child_session_id,
        task_input=task_input,
        tool_summaries=tool_summaries,
        timeout_seconds=timeout_seconds,
        approval_wait_tracker=approval_wait_tracker,
    )
    if timed_out:
        grace_started_at = time.time()
        _log_debug(
            "TaskTool recovery mode activated",
            extra=_build_recovery_mode_payload(
                child_session_id=child_session_id,
                trigger="timeout",
                tools_disabled=True,
            ),
        )
        _log_debug(
            "TaskTool timeout grace period started",
            extra=_build_timeout_grace_payload(
                event_type="timeout_grace_started",
                child_session_id=child_session_id,
                grace_seconds=TIMEOUT_GRACE_SECONDS,
                grace_started_at=grace_started_at,
            ),
        )
        recovery = await _run_recovery_turn(
            child_client=child_client,
            child_session_id=child_session_id,
            child_prompt_builder=child_prompt_builder,
            tool_summaries=tool_summaries,
            timeout_seconds=TIMEOUT_GRACE_SECONDS,
        )
        if recovery:
            _log_debug(
                "TaskTool timeout grace period completed",
                extra=_build_timeout_grace_payload(
                    event_type="timeout_grace_completed",
                    child_session_id=child_session_id,
                    grace_seconds=TIMEOUT_GRACE_SECONDS,
                    grace_started_at=grace_started_at,
                ),
            )
        else:
            _log_warning(
                "TaskTool timeout grace expired; hard-kill marker emitted",
                extra={
                    **_build_timeout_grace_payload(
                        event_type="timeout_grace_expired",
                        child_session_id=child_session_id,
                        grace_seconds=TIMEOUT_GRACE_SECONDS,
                        grace_started_at=grace_started_at,
                    ),
                    "hard_kill": True,
                },
            )
        timeout_error = ChildSessionTimeoutError(
            child_session_id=child_session_id,
            timeout_seconds=timeout_seconds,
        )
        result = recovery or _format_task_error(timeout_error)
        return _ChildOutcome(status="timeout", result=result)
    if status == "step-limit-reached":
        _log_debug(
            "TaskTool recovery mode activated",
            extra=_build_recovery_mode_payload(
                child_session_id=child_session_id,
                trigger="step_limit",
                tools_disabled=True,
            ),
        )
        recovery = await _run_recovery_turn(
            child_client=child_client,
            child_session_id=child_session_id,
            child_prompt_builder=child_prompt_builder,
            tool_summaries=tool_summaries,
            timeout_seconds=TIMEOUT_GRACE_SECONDS,
        )
        return _ChildOutcome(status="step-limit-reached", result=recovery or text)
    if status == "failure":
        raise ChildSessionFailedError(child_session_id=child_session_id, cause=text)
    return _ChildOutcome(status="success", result=text)


async def _run_child_with_pausable_timeout(
    *,
    child_client: Any,
    child_session_id: str,
    task_input: TaskToolInput,
    tool_summaries: list[ToolCallSummary],
    timeout_seconds: float,
    approval_wait_tracker: _ApprovalWaitTracker | None,
) -> tuple[str, str, bool]:
    run_task = asyncio.create_task(
        _run_child_once(
            child_client=child_client,
            child_session_id=child_session_id,
            task=task_input.task,
            tool_summaries=tool_summaries,
            tools=None,
            system_prompt=None,
            continuation_mode=ContinuationMode.AUTOMATIC,
        )
    )
    started = time.monotonic()
    while True:
        paused_seconds = (
            approval_wait_tracker.total_paused_seconds_including_active()
            if approval_wait_tracker is not None
            else 0.0
        )
        active_elapsed_seconds = max(0.0, (time.monotonic() - started) - paused_seconds)
        remaining_seconds = timeout_seconds - active_elapsed_seconds
        if remaining_seconds <= 0:
            _log_warning(
                "TaskTool child timed out",
                extra=_build_timeout_payload(
                    event_type="timeout_triggered",
                    child_session_id=child_session_id,
                    timeout_seconds=timeout_seconds,
                    active_elapsed_ms=int(active_elapsed_seconds * 1000),
                    total_paused_ms=int(paused_seconds * 1000),
                ),
            )
            run_task.cancel()
            try:
                await run_task
            except (asyncio.CancelledError, Exception):
                pass
            return ("timeout", "", True)
        poll_timeout = min(remaining_seconds, 0.05)
        try:
            status, text = await asyncio.wait_for(
                asyncio.shield(run_task), timeout=poll_timeout
            )
            return (status, text, False)
        except asyncio.TimeoutError:
            continue


def _install_approval_wait_tracking(
    hooks: HookRegistry, tracker: _ApprovalWaitTracker
) -> list[_ApprovalHandlerPatch]:
    patches: list[_ApprovalHandlerPatch] = []
    for hook in hooks._hooks:  # noqa: SLF001
        handler = getattr(hook, "handler", None)
        permission_cache = getattr(hook, "permission_cache", None)
        if permission_cache is None or handler is None:
            continue
        if not callable(handler):
            continue

        async def _wrapped(request: Any, *, _orig: Any = handler) -> Any:
            tool_id = str(getattr(request, "tool_id", "unknown"))
            tool_call_id = str(getattr(request, "tool_call_id", ""))
            tracker.on_wait_start(tool_id=tool_id, tool_call_id=tool_call_id)
            decision: str | None = None
            scope: str | None = None
            try:
                result = _orig(request)
                if inspect.isawaitable(result):
                    result = await result
                decision = str(getattr(result, "decision", "")) or None
                scope = str(getattr(result, "scope", "")) or None
                return result
            finally:
                tracker.on_wait_end(
                    tool_id=tool_id,
                    tool_call_id=tool_call_id,
                    decision=decision,
                    scope=scope,
                )

        patches.append(_ApprovalHandlerPatch(hook=hook, original_handler=handler))
        setattr(hook, "handler", _wrapped)
    return patches


def _restore_approval_handlers(patches: Sequence[_ApprovalHandlerPatch]) -> None:
    for patch in patches:
        setattr(patch.hook, "handler", patch.original_handler)


async def _run_child_once(
    *,
    child_client: Any,
    child_session_id: str,
    task: str,
    tool_summaries: list[ToolCallSummary],
    tools: Sequence[ToolDefinition] | None,
    system_prompt: str | None,
    continuation_mode: ContinuationMode,
) -> tuple[str, str]:
    text_fragments: list[str] = []
    failure_text: str | None = None
    step_limited = False
    tool_call_count = 0
    async for event in child_client.send_message(
        task,
        session_id=child_session_id,
        tools=list(tools) if tools is not None else None,
        continuation_mode=continuation_mode,
        system_prompt=system_prompt,
    ):
        event_type = getattr(event.type, "value", str(event.type))
        payload = dict(event.payload)
        if event_type == "text_delta":
            text_fragments.append(str(payload.get("text", "")))
        elif event_type == "tool_result":
            summary = _summarize_tool_result(payload)
            tool_summaries.append(summary)
            tool_call_count += 1
            _log_debug(
                "TaskTool child tool call observed",
                extra={
                    "event_type": "child_tool_result",
                    "child_session_id": child_session_id,
                    "tool_id": summary.tool_id,
                    "tool_call_id": summary.call_id,
                    "status": summary.status,
                    "title": summary.title,
                },
            )
        elif event_type == "error":
            message = str(payload.get("message", "child session failed"))
            if "max_consecutive_steps exceeded" in message:
                step_limited = True
            else:
                failure_text = message
    _log_debug(
        "TaskTool child loop completed",
        extra={
            "event_type": "child_loop_completed",
            "child_session_id": child_session_id,
            "step_limited": step_limited,
            "failed": failure_text is not None,
            "tool_call_count": tool_call_count,
        },
    )
    text = "".join(text_fragments).strip()
    if step_limited:
        return ("step-limit-reached", text or "Child hit step limit")
    if failure_text:
        return ("failure", failure_text)
    return ("success", text or "Child session completed")


async def _run_recovery_turn(
    *,
    child_client: Any,
    child_session_id: str,
    child_prompt_builder: PromptBuilder,
    tool_summaries: list[ToolCallSummary],
    timeout_seconds: float,
) -> str:
    try:
        base_prompt = child_prompt_builder.build()
    except Exception:
        base_prompt = ""
    system_prompt = f"{base_prompt}\n\n{RECOVERY_TURN_PROMPT}".strip()
    try:
        _, text = await asyncio.wait_for(
            _run_child_once(
                child_client=child_client,
                child_session_id=child_session_id,
                task="Provide recovery summary.",
                tool_summaries=tool_summaries,
                tools=[],
                system_prompt=system_prompt,
                continuation_mode=ContinuationMode.FORCE_STOP,
            ),
            timeout=timeout_seconds,
        )
    except asyncio.TimeoutError:
        return ""
    return text


def _build_child_hook_registry(parent: HookRegistry) -> HookRegistry:
    child = HookRegistry()
    for hook in parent._hooks:  # noqa: SLF001
        if (
            hook.__class__.transform_system_prompt
            is not SessionHooks.transform_system_prompt
        ):
            continue
        child.add(hook)
    return child


def _build_child_prompt_builder(
    *,
    parent_builder: PromptBuilder,
    task_input: TaskToolInput,
    config: TaskToolConfig,
) -> PromptBuilder:
    builder = parent_builder.for_child(custom_system_prompt=task_input.system_prompt)
    layers = (
        list(config.default_locked_layers)
        if config.default_locked_layers is not None
        else list(DEFAULT_LOCKED_LAYERS)
    )
    for layer in layers:
        try:
            builder.lock_layer(layer, source="task_tool_config", reason="delegation")
        except KeyError:
            # Missing layers are ignored so callers can lock optional layers.
            continue
    return builder


def _effective_max_steps(
    *,
    invocation_max_steps: int | None,
    config: TaskToolConfig,
    parent: SDKConfig,
) -> int:
    requested = invocation_max_steps or config.default_max_steps or DEFAULT_MAX_STEPS
    return min(requested, parent.max_consecutive_steps)


def _effective_timeout_seconds(
    *,
    invocation_timeout: float | None,
    config: TaskToolConfig,
) -> float | None:
    if invocation_timeout is not None:
        return invocation_timeout
    return config.default_timeout_seconds


def _effective_context_limit(
    *,
    invocation_context_limit: int | None,
    config: TaskToolConfig,
    parent: SDKConfig,
) -> int | None:
    if invocation_context_limit is not None:
        return invocation_context_limit
    if config.default_context_limit is not None:
        return config.default_context_limit
    return parent.compaction_context_limit


def _resolve_child_tool_ids(
    *,
    task_input: TaskToolInput,
    config: TaskToolConfig,
    parent_tools: Sequence[ToolDefinition],
    child_context: DelegationContext,
) -> list[str]:
    parent_ids = [tool.tool_id for tool in parent_tools]
    if task_input.tools is not None:
        return list(task_input.tools)
    if config.default_tools is not None:
        return list(config.default_tools)
    selected = list(parent_ids)
    if TOOL_TASK in selected:
        if not config.allow_recursive_task or not child_context.can_delegate():
            selected = [tool_id for tool_id in selected if tool_id != TOOL_TASK]
    return selected


def _build_child_sdk_config(
    *,
    parent: SDKConfig,
    parent_client: Any,
    child_hooks: HookRegistry,
    effective_max_steps: int,
    effective_context_limit: int | None,
    storage_provider: Any | None,
) -> SDKConfig:
    return SDKConfig(
        adapter=getattr(parent_client, "_adapter", parent.adapter),
        api_key=parent.api_key,
        model=parent.model,
        hooks=list(child_hooks._hooks),  # noqa: SLF001
        tools=[],
        tool_config_paths=list(parent.tool_config_paths),
        root_dir=parent.root_dir,
        timeout_seconds=parent.timeout_seconds,
        max_consecutive_steps=effective_max_steps,
        continue_on_max_tokens=parent.continue_on_max_tokens,
        retry_policy=parent.retry_policy,
        default_allowlist=list(parent.default_allowlist),
        storage_provider=storage_provider,
        storage_provider_hooks=list(parent.storage_provider_hooks),
        persist_sessions=parent.persist_sessions,
        auto_save=parent.auto_save,
        auto_compaction_enabled=parent.auto_compaction_enabled,
        compaction_trigger_threshold=parent.compaction_trigger_threshold,
        compaction_prune_target=parent.compaction_prune_target,
        compaction_protected_rounds=parent.compaction_protected_rounds,
        compaction_context_limit=effective_context_limit,
        compaction_max_summary_tokens=parent.compaction_max_summary_tokens,
    )


def _create_child_client(config: SDKConfig) -> Any:
    from ..client import WormholeClient  # noqa: PLC0415

    return WormholeClient(config)


async def _register_child_tools(
    *,
    child_client: Any,
    parent_tools: Sequence[ToolDefinition],
    parent_handlers: Mapping[str, Callable[[dict[str, Any]], Awaitable[Any] | Any]],
    selected_tool_ids: Sequence[str],
    task_tool_config: TaskToolConfig,
) -> None:
    parent_tool_map = {tool.tool_id: tool for tool in parent_tools}
    for tool_id in selected_tool_ids:
        tool = parent_tool_map.get(tool_id)
        if tool is None:
            raise ValidationError(
                "requested child tool is not registered on parent",
                {"tool_id": tool_id},
            )
        if tool_id == TOOL_TASK:
            await child_client.register_tool(
                tool,
                create_task_handler(
                    client=child_client, task_tool_config=task_tool_config
                ),
            )
            continue
        handler = parent_handlers.get(tool_id)
        if handler is None:
            raise ValidationError(
                "requested child tool handler is not registered on parent",
                {"tool_id": tool_id},
            )
        await child_client.register_tool(tool, handler)


async def _persist_lineage(
    *,
    child_client: Any,
    child_session_id: str,
    parent_session_id: str,
    child_context: DelegationContext,
) -> None:
    provider = child_client.storage_provider
    if provider is None:
        return
    try:
        record = await provider.session_store.load(child_session_id)
    except Exception:
        return
    messages = list(record.messages)
    existing_metadata: dict[str, Any] = {}
    if messages:
        existing_metadata = dict(messages[0].metadata)
    delegation_metadata = {
        "current_depth": child_context.current_depth,
        "max_depth": child_context.max_depth,
        "parent_session_id": child_context.parent_session_id,
        "root_session_id": child_context.root_session_id,
    }
    metadata_unchanged = (
        existing_metadata.get("delegation_context") == delegation_metadata
    )
    if record.session.parent_session_id == parent_session_id and metadata_unchanged:
        return
    if messages:
        first_message = messages[0]
        merged_metadata = dict(existing_metadata)
        merged_metadata["delegation_context"] = delegation_metadata
        messages[0] = replace(first_message, metadata=merged_metadata)
    updated = SessionRecord(
        session=replace(record.session, parent_session_id=parent_session_id),
        config=record.config,
        state=record.state,
        messages=messages,
        compaction_snapshot_id=record.compaction_snapshot_id,
    )
    await provider.session_store.save(updated)


def _validate_tool_subset(
    requested_tool_ids: Sequence[str] | None,
    parent_tools: Sequence[ToolDefinition],
) -> None:
    if requested_tool_ids is None:
        return
    parent_ids = {tool.tool_id for tool in parent_tools}
    unknown = sorted(set(requested_tool_ids).difference(parent_ids))
    if unknown:
        raise ValidationError(
            "requested tools must be a subset of parent tools",
            {"unknown_tools": unknown, "parent_tools": sorted(parent_ids)},
        )


def _build_handler_context(
    *,
    client: Any,
    task_tool_config: TaskToolConfig,
) -> TaskToolHandlerContext:
    parent_session_id = getattr(client, "_active_external_session_id", None) or getattr(
        client, "_default_session_id", None
    )
    if not isinstance(parent_session_id, str) or not parent_session_id:
        raise ValidationError("TaskTool requires an active parent session", {})
    contexts = _ensure_delegation_map(client)
    delegation_context = contexts.get(parent_session_id)
    if delegation_context is None:
        delegation_context = DelegationContext(
            current_depth=0,
            max_depth=task_tool_config.max_depth,
            parent_session_id=None,
            root_session_id=parent_session_id,
        )
        contexts[parent_session_id] = delegation_context
    return TaskToolHandlerContext(
        delegation_context=delegation_context,
        parent_session_id=parent_session_id,
        parent_config=client._config,  # noqa: SLF001
        parent_hooks=client._session_hooks,  # noqa: SLF001
        parent_prompt_builder=client._prompt_builder,  # noqa: SLF001
        parent_storage_provider=client.storage_provider,
        parent_tools=client.list_tools(),
        parent_tool_handlers=dict(client._tool_handlers),  # noqa: SLF001
        parent_client=client,
        task_tool_config=task_tool_config,
    )


def _ensure_delegation_map(client: Any) -> dict[str, DelegationContext]:
    mapping = getattr(client, "_delegation_context_by_session", None)
    if isinstance(mapping, dict):
        return mapping
    mapping = {}
    setattr(client, "_delegation_context_by_session", mapping)
    return mapping


def _format_task_error(error: TaskToolError) -> str:
    context_pairs = ", ".join(
        f"{key}={value}" for key, value in sorted(error.context.items())
    )
    context_suffix = f" ({context_pairs})" if context_pairs else ""
    return f"{error.code}: {error}{context_suffix}"


def _summarize_tool_result(payload: Mapping[str, Any]) -> ToolCallSummary:
    call_id = str(payload.get("tool_call_id", ""))
    tool_id = str(payload.get("tool_name") or payload.get("tool_id") or "unknown")
    status = str(payload.get("status", "completed"))
    title = _build_tool_title(payload)
    result = payload.get("result")
    error = payload.get("error")
    if status == "skipped":
        text = f"{result or ''} {error or ''}".lower()
        status = "approval_denied" if "denied" in text else "skipped"
    elif status == "failed":
        status = "error"
    return ToolCallSummary(tool_id=tool_id, call_id=call_id, status=status, title=title)


def _build_tool_title(payload: Mapping[str, Any]) -> str | None:
    args = payload.get("arguments")
    if not isinstance(args, Mapping):
        return None
    if "command" in args:
        return str(args.get("command"))
    if "file_path" in args:
        return str(args.get("file_path"))
    return None


def _emit_session_event(hooks: HookRegistry, event: Mapping[str, Any]) -> None:
    async def _emit() -> None:
        await hooks.run_on_session_event(dict(event))

    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        return
    loop.create_task(_emit())


def _to_optional_int(value: Any) -> int | None:
    if value is None:
        return None
    return int(value)


def _to_optional_float(value: Any) -> float | None:
    if value is None:
        return None
    return float(value)


def _to_optional_str(value: Any) -> str | None:
    if value is None:
        return None
    rendered = str(value)
    return rendered if rendered else None


def _to_optional_str_list(value: Any) -> list[str] | None:
    if value is None:
        return None
    if not isinstance(value, list):
        raise ValueError("tools must be a list[str] when provided")
    return [str(item) for item in value]


def _normalize_layer_key(name: str) -> str:
    cleaned = name.strip().lower()
    if not cleaned:
        raise ValueError("layer name must be non-empty")
    matches = [
        canonical
        for canonical, aliases in _LAYER_ALIASES.items()
        if cleaned == canonical or cleaned in aliases
    ]
    if len(matches) == 1:
        return matches[0]
    allowed = sorted(_LAYER_ALIASES.keys())
    if not matches:
        raise ValueError(
            f"unknown layer name '{name}'. allowed canonical keys: {allowed}"
        )
    raise ValueError(
        f"ambiguous layer name '{name}'. matches={matches}. allowed={allowed}"
    )


def _hash_task_for_log(task: str) -> str:
    return hashlib.sha256(task.encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class TaskToolFactory:
    """ToolFactoryProtocol-compatible TaskTool factory."""

    config: TaskToolConfig = field(default_factory=TaskToolConfig)

    def create_tools(self) -> list[ToolDefinition]:
        return [create_task_tool(self.config)]

    def create_handlers(
        self, context: Any
    ) -> dict[str, Callable[[dict[str, Any]], Awaitable[Any]]]:
        client = getattr(context, "client", None)
        if client is not None:
            return {
                TOOL_TASK: create_task_handler(
                    client=client,
                    task_tool_config=self.config,
                )
            }

        async def _unbound(_: dict[str, Any]) -> str:
            raise RuntimeError(
                "TaskToolFactory.create_handlers requires context.client to bind "
                "a WormholeClient"
            )

        return {TOOL_TASK: _unbound}


__all__ = [
    "DEFAULT_LOCKED_LAYERS",
    "RECOVERY_TURN_PROMPT",
    "TASK_TOOL_SCHEMA",
    "TIMEOUT_GRACE_SECONDS",
    "TOOL_TASK",
    "TaskToolConfig",
    "TaskToolFactory",
    "TaskToolHandlerContext",
    "TaskToolInput",
    "TaskToolOutput",
    "ToolCallSummary",
    "create_task_handler",
    "create_task_tool",
    "execute_task",
]
