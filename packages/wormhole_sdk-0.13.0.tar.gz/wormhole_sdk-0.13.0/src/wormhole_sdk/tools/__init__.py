"""Concrete tool implementations shipped with the SDK.

Tool ID constants for selective registration:

    from wormhole_sdk.tools import TOOL_BASH, TOOL_FILE_READ

    await client.register_default_tools(
        approval_manager,
        tools=[TOOL_BASH, TOOL_FILE_READ],  # only these two
    )
"""

from wormhole_core.schemas.tools import ToolDefinition

from .bash import (
    BashToolInput,
    BashToolOutput,
    build_bash_approval_payload,
    create_bash_tool,
    execute_bash,
)
from .binary_handlers import (
    BinaryHandler,
    BinaryHandlerRegistry,
    HandlerResult,
    ImageHandler,
    LLMCapabilities,
)
from .file_edit import (
    FileEditInput,
    FileEditOutput,
    build_file_edit_approval_payload,
    create_file_edit_tool,
    execute_file_edit,
)
from .file_read import (
    FileReadCache,
    FileReadInput,
    FileReadOutput,
    create_file_read_tool,
    execute_file_read,
)
from .file_write import (
    FileWriteInput,
    FileWriteOutput,
    build_file_write_approval_payload,
    create_file_write_tool,
    execute_file_write,
)
from .task import (
    RECOVERY_TURN_PROMPT,
    TASK_TOOL_SCHEMA,
    TOOL_TASK,
    TaskToolConfig,
    TaskToolFactory,
    TaskToolHandlerContext,
    TaskToolInput,
    TaskToolOutput,
    ToolCallSummary,
    create_task_handler,
    create_task_tool,
    execute_task,
)

# Tool ID constants for selective registration
TOOL_BASH = "bash"
TOOL_FILE_READ = "file_read"
TOOL_FILE_EDIT = "file_edit"
TOOL_FILE_WRITE = "file_write"


def create_default_tools() -> list[ToolDefinition]:
    """Create the default set of SDK-provided tool definitions."""
    return [
        create_bash_tool(),
        create_file_read_tool(),
        create_file_edit_tool(),
        create_file_write_tool(),
        create_task_tool(),
    ]


__all__ = [
    # Tool ID constants
    "TOOL_BASH",
    "TOOL_FILE_READ",
    "TOOL_FILE_EDIT",
    "TOOL_FILE_WRITE",
    "TOOL_TASK",
    "TASK_TOOL_SCHEMA",
    "RECOVERY_TURN_PROMPT",
    # Input/Output types
    "BashToolInput",
    "BashToolOutput",
    "BinaryHandler",
    "BinaryHandlerRegistry",
    "FileEditInput",
    "FileEditOutput",
    "FileReadCache",
    "FileReadInput",
    "FileReadOutput",
    "FileWriteInput",
    "FileWriteOutput",
    "TaskToolConfig",
    "TaskToolFactory",
    "TaskToolHandlerContext",
    "TaskToolInput",
    "TaskToolOutput",
    "ToolCallSummary",
    "HandlerResult",
    "ImageHandler",
    "LLMCapabilities",
    # Approval payloads
    "build_bash_approval_payload",
    "build_file_edit_approval_payload",
    "build_file_write_approval_payload",
    # Tool factories
    "create_bash_tool",
    "create_default_tools",
    "create_file_edit_tool",
    "create_file_read_tool",
    "create_file_write_tool",
    "create_task_handler",
    "create_task_tool",
    # Executors
    "execute_bash",
    "execute_file_edit",
    "execute_file_read",
    "execute_file_write",
    "execute_task",
]
