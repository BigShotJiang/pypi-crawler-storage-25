"""File read tool implementation.

>>> import asyncio
>>> import tempfile
>>> from pathlib import Path
>>> async def _read_example():
...     with tempfile.TemporaryDirectory() as tmp:
...         path = Path(tmp) / "a.txt"
...         path.write_text("hello\\nworld")
...         out = await execute_file_read(FileReadInput(file_path=path), boundary=Path(tmp))
...         return out.lines_read, out.has_more
>>> asyncio.run(_read_example())
(2, False)
>>> async def _change_example():
...     with tempfile.TemporaryDirectory() as tmp:
...         path = Path(tmp) / "a.txt"
...         cache = FileReadCache()
...         path.write_text("one")
...         await execute_file_read(FileReadInput(file_path=path), cache=cache, boundary=Path(tmp))
...         path.write_text("two")
...         out = await execute_file_read(FileReadInput(file_path=path), cache=cache, boundary=Path(tmp))
...         return out.changed_since_last_read
>>> asyncio.run(_change_example())
True
>>> async def _binary_example():
...     with tempfile.TemporaryDirectory() as tmp:
...         path = Path(tmp) / "bin.dat"
...         path.write_bytes(b"\\x00\\x01\\x02")
...         out = await execute_file_read(FileReadInput(file_path=path), boundary=Path(tmp))
...         return out.is_binary
>>> asyncio.run(_binary_example())
True
>>> async def _boundary_example():
...     with tempfile.TemporaryDirectory() as tmp1, tempfile.TemporaryDirectory() as tmp2:
...         path = Path(tmp2) / "a.txt"
...         path.write_text("x")
...         try:
...             await execute_file_read(FileReadInput(file_path=path), boundary=Path(tmp1))
...         except ValidationError:
...             return True
...         return False
>>> asyncio.run(_boundary_example())
True
"""

from __future__ import annotations

import hashlib
import mimetypes
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, Sequence

from wormhole_core.errors import ValidationError
from wormhole_core.schemas.tools import (
    ApprovalPayload,
    RiskLevel,
    ToolCapabilities,
    ToolDefinition,
)
from wormhole_core.tools.path_utils import ensure_within_boundary

from .binary_handlers import BinaryHandlerRegistry, HandlerResult, LLMCapabilities

DEFAULT_LIMIT = 2000
TOOL_ID = "file_read"


@dataclass(frozen=True)
class FileReadInput:
    """Input for file read operations."""

    file_path: Path
    offset: int = 0
    limit: int = DEFAULT_LIMIT

    def __post_init__(self) -> None:
        if not self.file_path.is_absolute():
            raise ValidationError("file_path must be absolute")
        if self.offset < 0:
            raise ValidationError("offset must be >= 0")
        if self.limit <= 0:
            raise ValidationError("limit must be > 0")


@dataclass(frozen=True)
class FileReadOutput:
    """Output from file read operations."""

    content: str
    encoding: str
    total_lines: int
    lines_read: int
    offset: int
    has_more: bool
    is_binary: bool
    binary_handler_result: HandlerResult | None = None
    changed_since_last_read: bool = False
    previous_mtime: float | None = None
    previous_size: int | None = None
    previous_hash: str | None = None


@dataclass
class CachedFileState:
    path: Path
    mtime: float
    size: int
    content_hash: str


class FileReadCache:
    """In-memory cache of file read state."""

    def __init__(self) -> None:
        self._states: dict[Path, CachedFileState] = {}

    def get(self, path: Path) -> CachedFileState | None:
        return self._states.get(path)

    def update(self, state: CachedFileState) -> None:
        self._states[state.path] = state


def _detect_mime_type(path: Path, data: bytes) -> str | None:
    if data.startswith(b"%PDF"):
        return "application/pdf"
    if data.startswith(b"\x89PNG"):
        return "image/png"
    if data.startswith(b"\xff\xd8"):
        return "image/jpeg"
    if data.startswith(b"ID3"):
        return "audio/mpeg"
    guessed, _ = mimetypes.guess_type(path.as_posix())
    return guessed


def _is_binary(data: bytes, mime_type: str | None) -> bool:
    if mime_type and not mime_type.startswith("text/"):
        return True
    return b"\x00" in data


def _detect_encoding(data: bytes) -> str:
    for encoding in ("utf-8", "utf-16", "latin-1"):
        try:
            data.decode(encoding)
            return encoding
        except UnicodeDecodeError:
            continue
    return "utf-8"


def _format_lines(lines: Sequence[str], offset: int) -> str:
    formatted = []
    for index, line in enumerate(lines, start=offset + 1):
        formatted.append(f"{index:>6}→{line}")
    return "\n".join(formatted)


def parse_file_read_input(arguments: Mapping[str, Any]) -> FileReadInput:
    return FileReadInput(
        file_path=Path(arguments["file_path"]),
        offset=int(arguments.get("offset", 0)),
        limit=int(arguments.get("limit", DEFAULT_LIMIT)),
    )


def build_file_read_approval_payload(file_path: Path) -> ApprovalPayload:
    """Build approval payload for file read operations."""
    return ApprovalPayload(
        input_summary=f"read {file_path}",
        risk_assessment=RiskLevel.LOW,
        preview={"file_path": str(file_path)},
        target_context={"target": str(file_path)},
    )


def create_file_read_tool() -> ToolDefinition:
    schema = {
        "type": "object",
        "properties": {
            "file_path": {"type": "string"},
            "offset": {"type": "integer"},
            "limit": {"type": "integer"},
        },
        "required": ["file_path"],
    }

    def _approval_payload(arguments: Mapping[str, Any]) -> ApprovalPayload:
        file_path = Path(arguments.get("file_path", ""))
        return build_file_read_approval_payload(file_path)

    return ToolDefinition(
        tool_id=TOOL_ID,
        name="file_read",
        schema=schema,
        description="Read file contents with line numbers",
        capabilities=ToolCapabilities(
            read_only=True, concurrency_safe=True, approval_required=True
        ),
        approval_payload=_approval_payload,
    )


async def execute_file_read(
    tool_input: FileReadInput,
    *,
    boundary: Path | None = None,
    cache: FileReadCache | None = None,
    binary_registry: BinaryHandlerRegistry | None = None,
    llm_capabilities: LLMCapabilities | None = None,
) -> FileReadOutput:
    """Read file contents with line numbers and pagination."""
    if boundary is not None:
        ensure_within_boundary(tool_input.file_path, boundary)
    if not tool_input.file_path.exists():
        raise ValidationError("file_path does not exist")

    data = tool_input.file_path.read_bytes()
    mime_type = _detect_mime_type(tool_input.file_path, data)
    is_binary = _is_binary(data, mime_type)

    previous_state = cache.get(tool_input.file_path) if cache else None
    current_state = CachedFileState(
        path=tool_input.file_path,
        mtime=tool_input.file_path.stat().st_mtime,
        size=tool_input.file_path.stat().st_size,
        content_hash=hashlib.sha256(data).hexdigest(),
    )
    changed = False
    if previous_state is not None:
        if (
            previous_state.mtime != current_state.mtime
            or previous_state.size != current_state.size
            or previous_state.content_hash != current_state.content_hash
        ):
            changed = True
    if cache:
        cache.update(current_state)

    handler_result: HandlerResult | None = None
    if is_binary and binary_registry is not None:
        capabilities = llm_capabilities or LLMCapabilities(multimodal=False)
        handler_result = binary_registry.dispatch(
            data, mime_type or "application/octet-stream", capabilities
        )

    if is_binary:
        return FileReadOutput(
            content="",
            encoding="binary",
            total_lines=0,
            lines_read=0,
            offset=tool_input.offset,
            has_more=False,
            is_binary=True,
            binary_handler_result=handler_result,
            changed_since_last_read=changed,
            previous_mtime=previous_state.mtime if previous_state else None,
            previous_size=previous_state.size if previous_state else None,
            previous_hash=previous_state.content_hash if previous_state else None,
        )

    encoding = _detect_encoding(data)
    text = data.decode(encoding, errors="replace")
    lines = text.splitlines()
    total_lines = len(lines)
    slice_lines = lines[tool_input.offset : tool_input.offset + tool_input.limit]
    content = _format_lines(slice_lines, tool_input.offset)
    has_more = tool_input.offset + len(slice_lines) < total_lines
    return FileReadOutput(
        content=content,
        encoding=encoding,
        total_lines=total_lines,
        lines_read=len(slice_lines),
        offset=tool_input.offset,
        has_more=has_more,
        is_binary=False,
        changed_since_last_read=changed,
        previous_mtime=previous_state.mtime if previous_state else None,
        previous_size=previous_state.size if previous_state else None,
        previous_hash=previous_state.content_hash if previous_state else None,
    )
