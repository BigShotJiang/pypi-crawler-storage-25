"""Binary handler registry and default handlers.

>>> caps = LLMCapabilities(multimodal=True)
>>> handler = ImageHandler()
>>> result = handler.process(b"\\x89PNG\\r\\n\\x1a\\n", "image/png", caps)
>>> result.success
True
"""

from __future__ import annotations

import base64
from dataclasses import dataclass, field
from typing import Any, Callable, Protocol


@dataclass(frozen=True)
class LLMCapabilities:
    """LLM capability declaration for handler selection."""

    multimodal: bool
    max_image_size: int | None = None
    supported_image_formats: list[str] | None = None


@dataclass(frozen=True)
class HandlerResult:
    """Result from binary handler processing."""

    success: bool
    content_type: str
    content: str | None = None
    mime_type: str | None = None
    error: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


class BinaryHandler(Protocol):
    """Protocol for binary file handlers."""

    def can_handle(self, mime_type: str) -> bool:
        """Check if handler supports the given mime type."""

    def process(
        self, content: bytes, mime_type: str, capabilities: LLMCapabilities
    ) -> HandlerResult:
        """Process binary content and return result."""


class BinaryHandlerRegistry:
    """Registry for binary handlers."""

    def __init__(self) -> None:
        self._handlers: list[BinaryHandler] = []

    def register(self, handler: BinaryHandler) -> None:
        self._handlers.append(handler)

    def unregister(self, handler: BinaryHandler) -> None:
        self._handlers = [item for item in self._handlers if item is not handler]

    def dispatch(
        self, content: bytes, mime_type: str, capabilities: LLMCapabilities
    ) -> HandlerResult:
        for handler in self._handlers:
            if handler.can_handle(mime_type):
                return handler.process(content, mime_type, capabilities)
        return HandlerResult(
            success=False,
            content_type="error",
            error="no handler registered",
            mime_type=mime_type,
        )


class ImageHandler:
    """Image handler with capability-aware output."""

    SUPPORTED_MIMES = {"image/png", "image/jpeg", "image/gif", "image/webp"}

    def __init__(self, ocr_func: Callable[[bytes], str] | None = None) -> None:
        self._ocr = ocr_func

    def can_handle(self, mime_type: str) -> bool:
        return mime_type in self.SUPPORTED_MIMES

    def process(
        self, content: bytes, mime_type: str, capabilities: LLMCapabilities
    ) -> HandlerResult:
        if (
            capabilities.supported_image_formats
            and mime_type not in capabilities.supported_image_formats
        ):
            return HandlerResult(
                success=False,
                content_type="error",
                mime_type=mime_type,
                error="image format not supported by model",
            )
        if capabilities.multimodal:
            encoded = base64.b64encode(content).decode("ascii")
            return HandlerResult(
                success=True,
                content_type="base64",
                content=encoded,
                mime_type=mime_type,
            )
        if self._ocr is None:
            return HandlerResult(
                success=False,
                content_type="error",
                mime_type=mime_type,
                error="ocr unavailable for text-only model",
            )
        text = self._ocr(content)
        return HandlerResult(
            success=True, content_type="text", content=text, mime_type=mime_type
        )
