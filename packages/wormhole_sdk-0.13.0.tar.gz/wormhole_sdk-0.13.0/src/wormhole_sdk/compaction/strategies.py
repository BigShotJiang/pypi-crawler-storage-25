"""SDK compaction strategies."""

from __future__ import annotations

from typing import Sequence

from wormhole_core.compaction.context import CompactionContext
from wormhole_core.compaction.protocols import SummarizationStrategy
from wormhole_core.schemas.messages import Message, MessageRole, Part, PartType

from wormhole_sdk.adapter.base import ModelAdapter
from wormhole_sdk.adapter.events import ModelEventType

DEFAULT_SUMMARY_PROMPT = (
    "You are a compaction summarizer. Compress conversation history into a factual context summary "
    "for the next model turn. Do not chat with the user. Do not answer the last user request directly. "
    "Keep key goals, decisions, tool outcomes, and open tasks."
)

SUMMARY_TASK_TEXT = (
    "Summarize the full history above for context compaction. "
    "Output plain text only. Include: objectives, important facts, decisions, and pending actions."
)


class LLMSummarizationStrategy(SummarizationStrategy):
    """Summarize messages using the configured model adapter."""

    def __init__(
        self,
        adapter: ModelAdapter,
        *,
        system_prompt: str | None = None,
        max_tokens: int | None = None,
    ) -> None:
        self._adapter = adapter
        self._system_prompt = system_prompt or DEFAULT_SUMMARY_PROMPT
        self._max_tokens = max_tokens

    async def summarize(
        self, messages: Sequence[Message], context: CompactionContext
    ) -> str:
        max_tokens = context.config.max_summary_tokens
        if max_tokens is None:
            max_tokens = self._max_tokens
        summary_messages = list(messages)
        summary_messages.append(
            Message(
                id="msg-compaction-summary-task",
                role=MessageRole.USER,
                parts=[
                    Part(
                        id="part-compaction-summary-task",
                        type=PartType.TEXT,
                        payload={"text": SUMMARY_TASK_TEXT},
                    )
                ],
                metadata={"compaction_instruction": True},
            )
        )
        chunks: list[str] = []
        async for event in self._adapter.stream(
            summary_messages,
            tools=None,
            system_prompt=self._system_prompt,
            max_tokens=max_tokens,
        ):
            if event.type is ModelEventType.TEXT_DELTA:
                chunks.append(str(event.payload.get("text", "")))
            elif event.type is ModelEventType.ERROR:
                raise RuntimeError(str(event.payload))
            elif event.type is ModelEventType.STOP:
                break
        return "".join(chunks).strip()
