"""Shared SDK data carriers."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class StageMessageResult:
    """Result of a stage_message() enqueue attempt.

    >>> StageMessageResult(status="accepted").status
    'accepted'
    """

    status: str
