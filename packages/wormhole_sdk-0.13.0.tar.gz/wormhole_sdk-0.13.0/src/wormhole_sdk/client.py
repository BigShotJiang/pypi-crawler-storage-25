"""SDK client for model interactions."""

from __future__ import annotations

import asyncio
import hashlib
import inspect
import json
import logging
import os
import time
from dataclasses import dataclass, replace
from pathlib import Path
from types import TracebackType
from typing import Any, AsyncIterator, Callable, Sequence, cast
from uuid import uuid4

from wormhole_core.compaction.protocols import SummarizationStrategy
from wormhole_core.compaction.types import CompactionResult
from wormhole_core.errors import (
    BackpressureError,
    NotFoundError,
    PermissionDeniedError,
    PersistenceError,
    ValidationError,
)
from wormhole_core.events.stream import EventStream
from wormhole_core.events.types import EventType
from wormhole_core.hooks.registry import HookRegistry as CoreHookRegistry
from wormhole_core.logging import (
    log_branch,
    log_loop_iteration,
    log_parameter,
    log_timing,
    log_variable_change,
)
from wormhole_core.loop.compaction import (
    _estimate_token_count,
    build_reconstructed_context,
    should_compact,
)
from wormhole_core.loop.compaction import (
    compact_session as core_compact_session,
)
from wormhole_core.loop.session_api import SessionHandle, SessionManager
from wormhole_core.schemas.messages import Message, MessageRole, Part, PartType
from wormhole_core.schemas.session import (
    CompactionConfig,
    CompactionSnapshot,
    Session,
    SessionConfig,
    SessionStatus,
)
from wormhole_core.schemas.tools import ToolCall, ToolDefinition
from wormhole_core.session.fork import fork_session as core_fork_session
from wormhole_core.session.types import ForkRequest, ForkResult
from wormhole_core.storage.session_store import SessionRecord, SessionSummary
from wormhole_core.tools.registry import ToolRegistry

from .adapter import AdapterRegistry
from .adapter.base import ModelAdapter
from .adapter.events import FinishReason, ModelEvent, ModelEventType
from .compaction import LLMSummarizationStrategy
from .config import SDKConfig
from .errors import (
    ConfigurationError,
    DuplicateToolError,
    ProviderError,
    SafetyLimitError,
)
from .hooks import HookRegistry as SessionHookRegistry
from .prompt import (
    DEFAULT_IDENTITY,
    DEFAULT_MANDATES,
    DEFAULT_SAFETY,
    EnvironmentContext,
    PromptBuilder,
)
from .storage import (
    STORAGE_API_VERSION,
    StorageProvider,
    create_default_storage_provider,
)
from .termination import ContinuationMode
from .types import StageMessageResult

LOGGER = logging.getLogger("wormhole_sdk")


@dataclass
class _Envelope:
    session_id: str
    event: ModelEvent | None


class _MemoryCompactionStore:
    def __init__(self) -> None:
        self._snapshots: dict[str, CompactionSnapshot] = {}

    async def save(self, snapshot: CompactionSnapshot) -> None:
        self._snapshots[snapshot.snapshot_id] = snapshot

    async def load(self, snapshot_id: str) -> CompactionSnapshot:
        return self._snapshots[snapshot_id]


def _default_storage_root(root_dir: Path | None = None) -> Path:
    """Resolve the default storage root for file-based persistence.

    >>> _default_storage_root(Path("/tmp")).name
    '.wormhole'
    """
    base = root_dir or Path.cwd()
    return base / ".wormhole"


def _parse_major_version(version: str) -> int | None:
    """Parse a SemVer major version.

    >>> _parse_major_version("1.2.3")
    1
    >>> _parse_major_version("bad") is None
    True
    """
    if not version:
        return None
    parts = version.split(".")
    if not parts:
        return None
    try:
        return int(parts[0])
    except ValueError:
        return None


class WormholeClient:
    """Primary SDK entry point.

    Example:
        from wormhole_sdk import (
            SDKConfig, WormholeClient, AnthropicAdapter, ApprovalManager,
            TOOL_BASH, TOOL_FILE_READ, TOOL_FILE_EDIT, TOOL_FILE_WRITE,
        )

        config = SDKConfig(
            adapter=AnthropicAdapter(api_key="..."),
            hooks=[ApprovalManager(handler=my_handler)],
            tools=[TOOL_BASH, TOOL_FILE_READ, TOOL_FILE_EDIT, TOOL_FILE_WRITE],
        )
        client = WormholeClient(config)

    >>> import asyncio
    >>> class DemoAdapter:
    ...     @property
    ...     def provider_name(self) -> str:
    ...         return "demo"
    ...     @property
    ...     def model_id(self) -> str:
    ...         return "demo-model"
    ...     async def stream(self, messages, tools=None, system_prompt=None, max_tokens=None):
    ...         yield ModelEvent(ModelEventType.STOP, {"finish_reason": "end_turn"})
    ...     async def count_tokens(self, messages) -> int:
    ...         return len(messages)
    >>> async def demo() -> ModelEventType:
    ...     from wormhole_sdk import SDKConfig
    ...     client = WormholeClient(SDKConfig(adapter=DemoAdapter()))
    ...     events = [event async for event in client.send_message("hi")]
    ...     return events[-1].type
    >>> asyncio.run(demo())
    <ModelEventType.STOP: 'stop'>
    """

    def __init__(self, config: SDKConfig | None = None) -> None:
        """Initialize WormholeClient.

        Args:
            config: SDK configuration containing adapter, hooks, tools, etc.
                    If None, uses defaults (requires ANTHROPIC_API_KEY env var).
        """
        self._config = config or SDKConfig()
        log_parameter(
            "WormholeClient.__init__",
            model=self._config.model,
            has_adapter=self._config.adapter is not None,
            persist_sessions=self._config.persist_sessions,
            auto_save=self._config.auto_save,
            call_id="init",
        )

        self._default_model = self._config.model
        self._root_dir = self._config.root_dir or Path.cwd().resolve()

        self._prompt_builder = (
            PromptBuilder()
            .set_identity(DEFAULT_IDENTITY)
            .set_mandates(DEFAULT_MANDATES)
            .set_safety(DEFAULT_SAFETY)
        )

        self._tool_registry = ToolRegistry()
        self._core_hooks = CoreHookRegistry()
        self._session_hooks = SessionHookRegistry()

        # Register hooks from config
        for hook in self._config.hooks:
            self._session_hooks.add(hook)

        self._session_handles: dict[str, SessionHandle] = {}
        self._session_aliases: dict[str, str] = {}
        self._session_messages: dict[str, list[Message]] = {}
        self._staged_queues: dict[str, asyncio.Queue[str]] = {}
        self._active_sessions: dict[str, bool] = {}
        self._delegation_context_by_session: dict[str, Any] = {}
        self._default_session_id: str | None = None
        self._active_external_session_id: str | None = None
        self._tool_handlers: dict[str, Callable[[dict[str, Any]], Any]] = {}
        self._tool_cache_hash: str | None = None
        self._tool_cache_payload: list[dict[str, Any]] | None = None
        self._tool_cache_version = 0
        self._persist_sessions = self._config.persist_sessions
        self._auto_save = self._config.auto_save
        self._compaction_config = CompactionConfig(
            trigger_threshold=self._config.compaction_trigger_threshold,
            prune_target_ratio=self._config.compaction_prune_target,
            protected_rounds=self._config.compaction_protected_rounds,
            auto_enabled=self._config.auto_compaction_enabled,
            max_summary_tokens=self._config.compaction_max_summary_tokens,
        )
        self._compaction_context_limit = self._config.compaction_context_limit
        self._storage_provider: StorageProvider | None = None
        self._storage_degraded = False

        # Setup adapter
        api_key = self._config.api_key or os.getenv("ANTHROPIC_API_KEY")
        self._adapter_factory: Callable[[str], ModelAdapter] | None = None
        if self._config.adapter is None:
            if not api_key:
                raise ConfigurationError(
                    "missing ANTHROPIC_API_KEY", {"env": "ANTHROPIC_API_KEY"}
                )
            registry = AdapterRegistry.default()

            def _factory(model_name: str) -> ModelAdapter:
                return registry.create(
                    "anthropic", api_key=api_key, model_name=model_name
                )

            self._adapter_factory = _factory
            self._adapter = _factory(self._default_model)
        else:
            self._adapter = self._config.adapter

        if (
            self._config.persist_sessions
            and self._config.auto_compaction_enabled
            and self._config.compaction_context_limit is None
            and getattr(self._adapter, "provider_name", "") == "anthropic"
        ):
            raise ConfigurationError(
                "compaction_context_limit is required for anthropic persistence with auto compaction",
                {
                    "persist_sessions": True,
                    "auto_compaction_enabled": True,
                    "provider": "anthropic",
                },
            )

        if self._persist_sessions:
            storage_root = _default_storage_root(self._root_dir)
            self._storage_provider = create_default_storage_provider(
                storage_root,
                hooks=self._config.storage_provider_hooks,
                provider=self._config.storage_provider,
            )
            self._warn_on_storage_version_mismatch(self._storage_provider)
            execution_store = self._storage_provider.execution_state_store
            event_log_store = self._storage_provider.event_log_store
            log_branch("WormholeClient.__init__", "persistence_enabled", call_id="init")
        else:
            execution_store = None
            event_log_store = None
            log_branch(
                "WormholeClient.__init__", "persistence_disabled", call_id="init"
            )
        self._session_manager = SessionManager(
            tool_registry=self._tool_registry,
            execution_state_store=execution_store,
            event_log_store=event_log_store,
            hook_registry=self._core_hooks,
        )
        log_variable_change(
            "WormholeClient.__init__", "default_model", None, self._default_model
        )

        # Register configured tools from config (built-in + external)
        if self._config.tools or self._config.tool_config_paths:
            self._register_builtin_tools(self._config.tools)

    @property
    def storage_provider(self) -> StorageProvider | None:
        """Return the active storage provider (if any)."""
        return self._storage_provider

    def _warn_on_storage_version_mismatch(self, provider: StorageProvider) -> None:
        log_parameter(
            "WormholeClient._warn_on_storage_version_mismatch",
            provider_version=provider.api_version,
            expected_version=STORAGE_API_VERSION,
            call_id="init",
        )
        expected_major = _parse_major_version(STORAGE_API_VERSION)
        actual_major = _parse_major_version(provider.api_version)
        if expected_major is None or actual_major is None:
            log_branch(
                "WormholeClient._warn_on_storage_version_mismatch",
                "version_unparseable",
                call_id="init",
            )
            LOGGER.warning(
                "Storage provider api_version is not SemVer: expected=%s actual=%s",
                STORAGE_API_VERSION,
                provider.api_version,
            )
            return
        if expected_major != actual_major:
            log_branch(
                "WormholeClient._warn_on_storage_version_mismatch",
                "major_mismatch",
                call_id="init",
            )
            LOGGER.warning(
                "Storage provider api_version mismatch: expected=%s actual=%s",
                STORAGE_API_VERSION,
                provider.api_version,
            )
        else:
            log_branch(
                "WormholeClient._warn_on_storage_version_mismatch",
                "major_match",
                call_id="init",
            )

    async def send_message(
        self,
        message: str,
        *,
        session_id: str | None = None,
        tools: list[ToolDefinition] | None = None,
        model: str | None = None,
        allowlist: list[str] | None = None,
        continuation_mode: ContinuationMode = ContinuationMode.AUTOMATIC,
        system_prompt: str | None = None,
    ) -> AsyncIterator[ModelEvent]:
        """Send a message and stream model events from graph execution."""
        log_parameter(
            "WormholeClient.send_message",
            message_length=len(message),
            session_id=session_id,
            model=model,
            has_tools=tools is not None,
            call_id=session_id or "pending",
        )

        external_session_id, internal_session_id = await self._ensure_session(
            session_id
        )
        if self._active_sessions.get(external_session_id, False):
            yield ModelEvent(
                ModelEventType.ERROR,
                {
                    "event_type": EventType.SESSION_BUSY.value.upper(),
                    "level": "info",
                    "code": "session_busy",
                    "session_id": external_session_id,
                    "message": "session already has an active send_message call",
                    "timestamp": time.time(),
                },
            )
            return
        self._active_sessions[external_session_id] = True

        started = time.monotonic()
        save_on_exit = True
        runtime = self._session_manager._sessions.get(internal_session_id)
        if runtime is None:
            self._active_sessions[external_session_id] = False
            yield ModelEvent(
                ModelEventType.ERROR,
                {
                    "code": "WH-SDK-001",
                    "message": "session runtime missing",
                    "retryable": False,
                },
            )
            return

        log_branch(
            "WormholeClient.send_message",
            "session_override" if session_id else "session_default",
            call_id=external_session_id,
        )
        staged_queue = self._get_staged_queue(external_session_id)
        history = self._session_messages.setdefault(external_session_id, [])
        prepared_history = self._prepare_model_messages(history)
        runtime.messages = list(prepared_history)
        history[:] = list(prepared_history)

        adapter = self._resolve_adapter(model)
        graph_adapter = self._wrap_adapter_for_graph(adapter, external_session_id)
        tools_for_llm = tools if tools is not None else self._tool_registry.list_tools()
        _ = self._get_tool_metadata()
        system_prompt_value = await self._resolve_system_prompt(
            system_prompt,
            tools_for_llm,
            external_session_id,
        )
        event_stream = cast(EventStream[object], runtime.stream)
        event_queue: asyncio.Queue[object] = asyncio.Queue()
        runtime.loop_context.update(
            {
                "staged_queue": staged_queue,
                "stream_queue": event_queue,
                "session_hooks": self._session_hooks,
                "continuation_mode": continuation_mode.value,
                "max_consecutive_steps": int(self._config.max_consecutive_steps),
                "main_loop_unbounded": bool(self._config.main_loop_unbounded),
                "is_sub_agent": False,
                "session_type": "main",
                "model_adapter": graph_adapter,
                "tools": tools_for_llm,
                "tool_handlers": dict(self._tool_handlers),
                "root_dir": str(self._root_dir),
                "system_prompt": system_prompt_value,
                "allowlist": list(allowlist) if allowlist is not None else None,
                "last_output": None,
            }
        )

        step_error: BaseException | None = None
        stream_error: Exception | None = None
        cancellation_requested = False
        self._active_external_session_id = external_session_id
        try:
            await self._maybe_auto_compact(external_session_id, internal_session_id)

            async def _run_step() -> None:
                nonlocal step_error
                try:
                    await self._session_manager.step_session(
                        internal_session_id, input=message
                    )
                except (
                    BaseException
                ) as exc:  # pragma: no cover - propagated to caller flow
                    step_error = exc

            step_task = asyncio.create_task(_run_step())

            while True:
                if step_task.done() and event_queue.empty():
                    break
                try:
                    event = await asyncio.wait_for(event_queue.get(), timeout=0.05)
                except asyncio.TimeoutError:
                    continue
                except asyncio.CancelledError:
                    cancellation_requested = True
                    if not step_task.done():
                        step_task.cancel()
                    current = asyncio.current_task()
                    if current is not None and hasattr(current, "uncancel"):
                        cast(Any, current).uncancel()
                    continue
                model_event = self._coerce_stream_event(event)
                if model_event is None:
                    continue
                try:
                    await event_stream.publish(
                        _Envelope(session_id=external_session_id, event=model_event)
                    )
                except Exception as exc:
                    stream_error = exc
                    if not step_task.done():
                        step_task.cancel()
                    break
                log_parameter(
                    "WormholeClient.send_message",
                    event_type=model_event.type.value,
                    call_id=external_session_id,
                )
                yield model_event

            await step_task
            if cancellation_requested:
                log_branch(
                    "WormholeClient.send_message",
                    "caller_cancelled_continue_until_step_done",
                    call_id=external_session_id,
                )
            if isinstance(stream_error, BackpressureError):
                raise stream_error
            if step_error is not None:
                if cancellation_requested and isinstance(
                    step_error, asyncio.CancelledError
                ):
                    save_on_exit = False
                    return
                if isinstance(step_error, PermissionDeniedError):
                    raise step_error
                save_on_exit = False
                provider_error = ProviderError(
                    str(step_error),
                    {"session_id": external_session_id},
                    retryable=False,
                )
                yield ModelEvent(
                    ModelEventType.ERROR,
                    {
                        "code": provider_error.code.value,
                        "message": provider_error.message,
                        "retryable": provider_error.retryable,
                    },
                )
                return

            history[:] = list(runtime.messages)
            await self._maybe_auto_compact(external_session_id, internal_session_id)

            last_output = runtime.loop_context.get("last_output")
            if isinstance(last_output, dict) and str(last_output.get("outcome")) == (
                "max_steps_reached"
            ):
                error = SafetyLimitError(
                    "max_consecutive_steps exceeded",
                    {"max_consecutive_steps": self._config.max_consecutive_steps},
                )
                yield ModelEvent(
                    ModelEventType.ERROR,
                    {
                        "code": error.code.value,
                        "message": error.message,
                        "retryable": error.retryable,
                    },
                )
        finally:
            if self._active_external_session_id == external_session_id:
                self._active_external_session_id = None
            runtime.loop_context.pop("stream_queue", None)
            runtime.loop_context.pop("model_event_queue", None)
            elapsed_ms = (time.monotonic() - started) * 1000
            log_timing(
                "WormholeClient.send_message", elapsed_ms, call_id=external_session_id
            )
            self._active_sessions[external_session_id] = False

        if self._persist_sessions and self._auto_save and save_on_exit:
            await self._save_session_messages(external_session_id, internal_session_id)
        elif self._persist_sessions and not self._auto_save:
            log_branch(
                "WormholeClient.send_message",
                "auto_save_disabled",
                call_id=external_session_id,
            )

        _ = internal_session_id

    async def compact_session(
        self,
        session_id: str | None = None,
        *,
        summarization_strategy: SummarizationStrategy | None = None,
    ) -> CompactionResult:
        """Compact a session history in-place."""
        call_id = session_id or self._default_session_id or "pending"
        log_parameter(
            "WormholeClient.compact_session", session_id=session_id, call_id=call_id
        )
        external_session_id, internal_session_id = await self._ensure_session(
            session_id
        )

        if self._persist_sessions:
            await self._load_session_messages(external_session_id)

        history = self._session_messages.setdefault(external_session_id, [])
        adapter = self._resolve_adapter(None)
        context_limit = self._compaction_context_limit
        if context_limit is None:
            try:
                context_limit = await adapter.count_tokens(list(history))
            except Exception:
                log_branch(
                    "WormholeClient.compact_session",
                    "count_tokens_failed",
                    call_id=external_session_id,
                )
                context_limit = _estimate_token_count(history)
                log_branch(
                    "WormholeClient.compact_session",
                    "count_tokens_fallback",
                    call_id=external_session_id,
                )
            if context_limit <= 0:
                context_limit = 1

        strategy = summarization_strategy or LLMSummarizationStrategy(adapter)
        compaction_store = (
            self._storage_provider.compaction_store
            if self._storage_provider is not None
            else _MemoryCompactionStore()
        )
        handle = self._session_handles.get(internal_session_id)
        event_stream = handle.stream if handle is not None else None

        result = await core_compact_session(
            session_id=external_session_id,
            messages=history,
            compaction_store=compaction_store,
            summarization_strategy=strategy,
            config=self._compaction_config,
            context_limit=context_limit,
            hooks=self._core_hooks,
            event_stream=event_stream,
            correlation_id=external_session_id,
        )
        self._session_manager.set_compaction_snapshot(
            internal_session_id, result.snapshot_id
        )

        if self._persist_sessions and self._auto_save:
            await self._save_session_messages(external_session_id, internal_session_id)
        elif self._persist_sessions and not self._auto_save:
            log_branch(
                "WormholeClient.compact_session",
                "auto_save_disabled",
                call_id=external_session_id,
            )

        return result

    async def fork_session(
        self,
        parent_session_id: str,
        *,
        new_session_id: str | None = None,
        context_limit: int | None = None,
    ) -> ForkResult:
        """Fork a session by copying full history into a child session."""
        log_parameter(
            "WormholeClient.fork_session",
            parent_session_id=parent_session_id,
            call_id=parent_session_id,
        )
        if self._storage_provider is None:
            raise PersistenceError(
                "storage provider unavailable", {"session_id": parent_session_id}
            )

        adapter = self._resolve_adapter(None)
        strategy = LLMSummarizationStrategy(adapter)
        resolved_context_limit = (
            context_limit
            if context_limit is not None
            else self._compaction_context_limit
        )
        internal_parent = self._session_aliases.get(parent_session_id)
        handle = self._session_handles.get(internal_parent) if internal_parent else None
        event_stream = handle.stream if handle is not None else None

        result = await core_fork_session(
            ForkRequest(
                parent_session_id=parent_session_id, new_session_id=new_session_id
            ),
            session_store=self._storage_provider.session_store,
            compaction_store=self._storage_provider.compaction_store,
            context_limit=resolved_context_limit,
            summarization_strategy=strategy,
            compaction_config=self._compaction_config,
            hooks=self._core_hooks,
            event_stream=event_stream,
        )

        return result

    async def _maybe_auto_compact(
        self, external_session_id: str, internal_session_id: str
    ) -> None:
        call_id = external_session_id
        log_parameter(
            "WormholeClient._maybe_auto_compact",
            session_id=external_session_id,
            call_id=call_id,
        )
        if not self._compaction_config.auto_enabled:
            log_branch(
                "WormholeClient._maybe_auto_compact",
                "auto_compaction_disabled",
                call_id=call_id,
            )
            return
        context_limit = self._compaction_context_limit
        if context_limit is None:
            log_branch(
                "WormholeClient._maybe_auto_compact",
                "missing_context_limit",
                call_id=call_id,
            )
            return
        history = self._session_messages.get(external_session_id, [])
        if not history:
            log_branch(
                "WormholeClient._maybe_auto_compact", "empty_history", call_id=call_id
            )
            return
        adapter = self._resolve_adapter(None)
        reconstructed, _, _ = build_reconstructed_context(
            history,
            protected_rounds=self._compaction_config.protected_rounds,
        )
        try:
            token_count = await adapter.count_tokens(list(reconstructed))
        except Exception:
            log_branch(
                "WormholeClient._maybe_auto_compact",
                "count_tokens_failed",
                call_id=call_id,
            )
            token_count = _estimate_token_count(reconstructed)
            log_branch(
                "WormholeClient._maybe_auto_compact",
                "count_tokens_fallback",
                call_id=call_id,
            )
        log_variable_change(
            "WormholeClient._maybe_auto_compact",
            "context_token_count",
            None,
            token_count,
            call_id=call_id,
        )
        log_variable_change(
            "WormholeClient._maybe_auto_compact",
            "context_limit",
            None,
            context_limit,
            call_id=call_id,
        )
        context_ratio = token_count / context_limit if context_limit > 0 else 0.0
        log_variable_change(
            "WormholeClient._maybe_auto_compact",
            "context_ratio",
            None,
            context_ratio,
            call_id=call_id,
        )
        if not should_compact(context_ratio, self._compaction_config):
            log_branch(
                "WormholeClient._maybe_auto_compact", "below_threshold", call_id=call_id
            )
            return
        strategy = LLMSummarizationStrategy(adapter)
        compaction_store = (
            self._storage_provider.compaction_store
            if self._storage_provider is not None
            else _MemoryCompactionStore()
        )
        handle = self._session_handles.get(internal_session_id)
        event_stream = handle.stream if handle is not None else None
        result = await core_compact_session(
            session_id=external_session_id,
            messages=history,
            compaction_store=compaction_store,
            summarization_strategy=strategy,
            config=self._compaction_config,
            context_limit=context_limit,
            hooks=self._core_hooks,
            event_stream=event_stream,
            correlation_id=external_session_id,
        )
        self._session_manager.set_compaction_snapshot(
            internal_session_id, result.snapshot_id
        )
        log_branch(
            "WormholeClient._maybe_auto_compact",
            "compaction_completed",
            call_id=call_id,
        )

    async def _save_session_messages(
        self, external_session_id: str, internal_session_id: str
    ) -> None:
        log_parameter(
            "WormholeClient._save_session_messages",
            session_id=external_session_id,
            call_id=external_session_id,
        )
        if self._storage_provider is None:
            log_branch(
                "WormholeClient._save_session_messages",
                "no_provider",
                call_id=external_session_id,
            )
            return
        if self._storage_degraded:
            log_branch(
                "WormholeClient._save_session_messages",
                "degraded_mode",
                call_id=external_session_id,
            )
            return
        started = time.monotonic()
        messages = list(self._session_messages.get(external_session_id, []))
        handle = self._session_handles.get(internal_session_id)
        if handle is None:
            session = Session(
                session_id=external_session_id, status=SessionStatus.RUNNING
            )
        else:
            session = handle.session
            if session.session_id != external_session_id:
                session = replace(session, session_id=external_session_id)
        session = replace(session, updated_at=time.time())
        record = SessionRecord(
            session=session,
            config=SessionConfig(),
            state=None,
            messages=messages,
            compaction_snapshot_id=None,
        )
        try:
            await self._storage_provider.session_store.save(record)
            log_branch(
                "WormholeClient._save_session_messages",
                "save_ok",
                call_id=external_session_id,
            )
        except PersistenceError as exc:
            log_branch(
                "WormholeClient._save_session_messages",
                "save_error",
                call_id=external_session_id,
            )
            LOGGER.warning(
                "Storage persistence degraded; operation=save session_id=%s error=%s",
                external_session_id,
                exc,
            )
            self._storage_degraded = True
            return
        finally:
            log_timing(
                "WormholeClient._save_session_messages",
                (time.monotonic() - started) * 1000,
                call_id=external_session_id,
            )

    async def _load_session_messages(self, session_id: str) -> None:
        log_parameter(
            "WormholeClient._load_session_messages",
            session_id=session_id,
            call_id=session_id,
        )
        if self._storage_provider is None:
            log_branch(
                "WormholeClient._load_session_messages",
                "no_provider",
                call_id=session_id,
            )
            return
        if self._storage_degraded:
            log_branch(
                "WormholeClient._load_session_messages",
                "degraded_mode",
                call_id=session_id,
            )
            return
        started = time.monotonic()
        try:
            try:
                record = await self._storage_provider.session_store.load(session_id)
            except NotFoundError:
                log_branch(
                    "WormholeClient._load_session_messages",
                    "session_missing",
                    call_id=session_id,
                )
                return
            except PersistenceError as exc:
                log_branch(
                    "WormholeClient._load_session_messages",
                    "load_error",
                    call_id=session_id,
                )
                LOGGER.warning(
                    "Storage persistence degraded; operation=load session_id=%s error=%s",
                    session_id,
                    exc,
                )
                self._storage_degraded = True
                return
            self._session_messages[session_id] = list(record.messages)
            log_branch(
                "WormholeClient._load_session_messages", "load_ok", call_id=session_id
            )
        finally:
            log_timing(
                "WormholeClient._load_session_messages",
                (time.monotonic() - started) * 1000,
                call_id=session_id,
            )

    async def save_session(self, session_id: str | None = None) -> bool:
        """Persist session messages explicitly.

        >>> import asyncio
        >>> class DemoAdapter:
        ...     @property
        ...     def provider_name(self) -> str:
        ...         return "demo"
        ...     @property
        ...     def model_id(self) -> str:
        ...         return "demo-model"
        ...     async def stream(self, messages, tools=None, system_prompt=None, max_tokens=None):
        ...         return
        ...         yield ModelEvent(ModelEventType.STOP, {"finish_reason": "end_turn"})
        ...     async def count_tokens(self, messages) -> int:
        ...         return len(messages)
        >>> async def demo() -> bool:
        ...     client = WormholeClient(SDKConfig(adapter=DemoAdapter(), persist_sessions=False))
        ...     return await client.save_session("s1")
        >>> asyncio.run(demo())
        False
        """
        call_id = session_id or self._default_session_id or "pending"
        log_parameter(
            "WormholeClient.save_session", session_id=session_id, call_id=call_id
        )
        started = time.monotonic()
        try:
            if not self._persist_sessions:
                log_branch(
                    "WormholeClient.save_session",
                    "persistence_disabled",
                    call_id=call_id,
                )
                return False
            if self._storage_provider is None:
                log_branch(
                    "WormholeClient.save_session", "no_provider", call_id=call_id
                )
                return False
            if self._storage_degraded:
                log_branch(
                    "WormholeClient.save_session", "degraded_mode", call_id=call_id
                )
                return False
            external_session_id, internal_session_id = await self._ensure_session(
                session_id
            )
            call_id = external_session_id
            await self._save_session_messages(external_session_id, internal_session_id)
            if self._storage_degraded:
                log_branch(
                    "WormholeClient.save_session", "save_degraded", call_id=call_id
                )
                return False
            log_branch("WormholeClient.save_session", "save_ok", call_id=call_id)
            return True
        finally:
            log_timing(
                "WormholeClient.save_session",
                (time.monotonic() - started) * 1000,
                call_id=call_id,
            )

    async def load_session(self, session_id: str) -> int:
        """Load a session from storage into memory.

        >>> import asyncio
        >>> class DemoAdapter:
        ...     @property
        ...     def provider_name(self) -> str:
        ...         return "demo"
        ...     @property
        ...     def model_id(self) -> str:
        ...         return "demo-model"
        ...     async def stream(self, messages, tools=None, system_prompt=None, max_tokens=None):
        ...         return
        ...         yield ModelEvent(ModelEventType.STOP, {"finish_reason": "end_turn"})
        ...     async def count_tokens(self, messages) -> int:
        ...         return len(messages)
        >>> async def demo() -> int:
        ...     client = WormholeClient(SDKConfig(adapter=DemoAdapter(), persist_sessions=False))
        ...     return await client.load_session("s1")
        >>> asyncio.run(demo())
        0
        """
        log_parameter(
            "WormholeClient.load_session", session_id=session_id, call_id=session_id
        )
        started = time.monotonic()
        try:
            if not self._persist_sessions:
                log_branch(
                    "WormholeClient.load_session",
                    "persistence_disabled",
                    call_id=session_id,
                )
                return 0
            if self._storage_provider is None:
                log_branch(
                    "WormholeClient.load_session", "no_provider", call_id=session_id
                )
                return 0
            if self._storage_degraded:
                log_branch(
                    "WormholeClient.load_session", "degraded_mode", call_id=session_id
                )
                return 0
            await self._load_session_messages(session_id)
            count = len(self._session_messages.get(session_id, []))
            log_branch(
                "WormholeClient.load_session",
                "load_ok" if count else "load_empty",
                call_id=session_id,
            )
            return count
        finally:
            log_timing(
                "WormholeClient.load_session",
                (time.monotonic() - started) * 1000,
                call_id=session_id,
            )

    async def delete_session(self, session_id: str) -> None:
        """Delete a session from storage and memory.

        >>> import asyncio
        >>> class DemoAdapter:
        ...     @property
        ...     def provider_name(self) -> str:
        ...         return "demo"
        ...     @property
        ...     def model_id(self) -> str:
        ...         return "demo-model"
        ...     async def stream(self, messages, tools=None, system_prompt=None, max_tokens=None):
        ...         return
        ...         yield ModelEvent(ModelEventType.STOP, {"finish_reason": "end_turn"})
        ...     async def count_tokens(self, messages) -> int:
        ...         return len(messages)
        >>> async def demo() -> None:
        ...     client = WormholeClient(SDKConfig(adapter=DemoAdapter(), persist_sessions=False))
        ...     await client.delete_session("s1")
        >>> asyncio.run(demo()) is None
        True
        """
        log_parameter(
            "WormholeClient.delete_session", session_id=session_id, call_id=session_id
        )
        started = time.monotonic()
        try:
            if not self._persist_sessions:
                log_branch(
                    "WormholeClient.delete_session",
                    "persistence_disabled",
                    call_id=session_id,
                )
                return
            if self._storage_provider is None:
                log_branch(
                    "WormholeClient.delete_session", "no_provider", call_id=session_id
                )
                return
            if self._storage_degraded:
                log_branch(
                    "WormholeClient.delete_session", "degraded_mode", call_id=session_id
                )
                return
            try:
                await self._storage_provider.session_store.delete(session_id)
            except PersistenceError as exc:
                log_branch(
                    "WormholeClient.delete_session", "delete_error", call_id=session_id
                )
                LOGGER.warning(
                    "Storage persistence degraded; operation=delete session_id=%s error=%s",
                    session_id,
                    exc,
                )
                self._storage_degraded = True
                return
            log_branch("WormholeClient.delete_session", "delete_ok", call_id=session_id)
            self._session_messages.pop(session_id, None)
            internal_session_id = self._session_aliases.pop(session_id, None)
            if internal_session_id is not None:
                self._session_handles.pop(internal_session_id, None)
            if self._default_session_id == session_id:
                log_variable_change(
                    "WormholeClient.delete_session",
                    "default_session_id",
                    self._default_session_id,
                    None,
                    call_id=session_id,
                )
                self._default_session_id = None
        finally:
            log_timing(
                "WormholeClient.delete_session",
                (time.monotonic() - started) * 1000,
                call_id=session_id,
            )

    async def list_sessions(
        self, parent_session_id: str | None = None
    ) -> Sequence[SessionSummary]:
        """List persisted sessions without loading message contents.

        >>> import asyncio
        >>> class DemoAdapter:
        ...     @property
        ...     def provider_name(self) -> str:
        ...         return "demo"
        ...     @property
        ...     def model_id(self) -> str:
        ...         return "demo-model"
        ...     async def stream(self, messages, tools=None, system_prompt=None, max_tokens=None):
        ...         return
        ...         yield ModelEvent(ModelEventType.STOP, {"finish_reason": "end_turn"})
        ...     async def count_tokens(self, messages) -> int:
        ...         return len(messages)
        >>> async def demo() -> list[SessionSummary]:
        ...     client = WormholeClient(SDKConfig(adapter=DemoAdapter(), persist_sessions=False))
        ...     return await client.list_sessions()
        >>> asyncio.run(demo())
        []
        """
        call_id = "list_sessions"
        log_parameter(
            "WormholeClient.list_sessions",
            parent_session_id=parent_session_id,
            call_id=call_id,
        )
        started = time.monotonic()
        try:
            if not self._persist_sessions:
                log_branch(
                    "WormholeClient.list_sessions",
                    "persistence_disabled",
                    call_id=call_id,
                )
                return []
            if self._storage_provider is None:
                log_branch(
                    "WormholeClient.list_sessions", "no_provider", call_id=call_id
                )
                return []
            if self._storage_degraded:
                log_branch(
                    "WormholeClient.list_sessions", "degraded_mode", call_id=call_id
                )
                return []
            try:
                summaries = await self._storage_provider.session_store.list(
                    parent_session_id=parent_session_id
                )
            except PersistenceError as exc:
                log_branch(
                    "WormholeClient.list_sessions", "list_error", call_id=call_id
                )
                LOGGER.warning(
                    "Storage persistence degraded; operation=list error=%s",
                    exc,
                )
                self._storage_degraded = True
                return []
            log_branch("WormholeClient.list_sessions", "list_ok", call_id=call_id)
            return list(summaries)
        finally:
            log_timing(
                "WormholeClient.list_sessions",
                (time.monotonic() - started) * 1000,
                call_id=call_id,
            )

    async def register_tool(
        self,
        tool: ToolDefinition,
        handler: Callable[[dict[str, Any]], Any],
    ) -> None:
        """Register a tool with its handler.

        >>> import asyncio
        >>> from wormhole_sdk import ToolDefinition
        >>> from wormhole_sdk.config import SDKConfig
        >>> class DemoAdapter:
        ...     @property
        ...     def provider_name(self) -> str:
        ...         return "demo"
        ...     @property
        ...     def model_id(self) -> str:
        ...         return "demo-model"
        ...     async def stream(self, messages, tools=None, system_prompt=None, max_tokens=None):
        ...         return
        ...         yield ModelEvent(ModelEventType.STOP, {"finish_reason": "end_turn"})
        ...     async def count_tokens(self, messages) -> int:
        ...         return len(messages)
        >>> async def demo() -> list[str]:
        ...     client = WormholeClient(SDKConfig(adapter=DemoAdapter()))
        ...     tool = ToolDefinition(tool_id="echo", name="Echo", schema={"type": "object"})
        ...     async def handler(args: dict[str, Any]) -> str:
        ...         return str(args.get("text", ""))
        ...     await client.register_tool(tool, handler)
        ...     return [t.tool_id for t in client.list_tools()]
        >>> asyncio.run(demo())
        ['echo']
        """

        log_parameter(
            "WormholeClient.register_tool", tool_id=tool.tool_id, call_id="tool"
        )
        try:
            self._tool_registry.register(tool)
        except ValidationError as exc:
            message = getattr(exc, "message", str(exc))
            if "already registered" in message:
                raise DuplicateToolError(
                    "tool already registered", {"tool_id": tool.tool_id}
                ) from exc
            raise
        self._tool_handlers[tool.tool_id] = handler
        self._invalidate_tool_cache()

    def _register_builtin_tools(self, tool_ids: list[str]) -> None:
        """Register configured tools synchronously during __init__.

        Args:
            tool_ids: Tool IDs to register (built-in + discovered external).
        """
        from .tool_handlers import create_default_tool_handlers
        from .tool_loader import (
            ToolHandlerContext,
            create_external_handlers,
            discover_external_tools,
            validate_tool_config,
        )
        from .tools import FileReadCache, create_default_tools
        from .tools.task import TaskToolConfig, create_task_handler

        log_branch(
            "WormholeClient._register_builtin_tools",
            "registration_start",
            call_id="tool",
        )
        log_parameter(
            "WormholeClient._register_builtin_tools",
            num_requested_tool_ids=len(tool_ids),
            num_tool_config_paths=len(self._config.tool_config_paths),
            call_id="tool",
        )

        builtin_tools = {tool.tool_id: tool for tool in create_default_tools()}
        builtin_tool_ids = set(builtin_tools.keys())
        validate_tool_config(
            tools=tool_ids,
            tool_config_paths=self._config.tool_config_paths,
            builtin_tool_ids=builtin_tool_ids,
        )

        discovered_external = discover_external_tools(self._config.tool_config_paths)
        if discovered_external:
            log_parameter(
                "WormholeClient._register_builtin_tools",
                discovered_external_tool_ids=sorted(discovered_external.keys()),
                call_id="tool",
            )

        collisions = sorted(set(discovered_external).intersection(builtin_tool_ids))
        if collisions:
            log_branch(
                "WormholeClient._register_builtin_tools",
                "builtin_external_collision",
                call_id="tool",
            )
            raise ConfigurationError(
                "External tool_id(s) collide with built-in tool_ids.",
                {"colliding_tool_ids": collisions},
            )

        known_tool_ids = builtin_tool_ids | set(discovered_external.keys())
        unknown_tool_ids = sorted(set(tool_ids).difference(known_tool_ids))
        if unknown_tool_ids:
            log_branch(
                "WormholeClient._register_builtin_tools",
                "unknown_tool_id",
                call_id="tool",
            )
            raise ConfigurationError(
                "SDKConfig.tools contains unknown tool_id(s).",
                {"unknown_tool_ids": unknown_tool_ids},
            )

        file_cache = FileReadCache()
        task_handler = create_task_handler(
            client=self,
            task_tool_config=TaskToolConfig(),
        )
        builtin_handlers = create_default_tool_handlers(
            tools=builtin_tools,
            root_dir=self._root_dir,
            boundary=None,  # Rely on ApprovalManager for access control
            file_cache=file_cache,
            task_handler=task_handler,
        )
        external_handlers = create_external_handlers(
            discovered_tools=discovered_external,
            tool_ids=tool_ids,
            context=ToolHandlerContext(
                root_dir=self._root_dir,
                file_cache=file_cache,
                boundary=None,
            ),
        )

        for tool_id in sorted(set(tool_ids)):
            source = "builtin"
            if tool_id in builtin_tools:
                tool = builtin_tools[tool_id]
                handler = builtin_handlers[tool_id]
                log_branch(
                    "WormholeClient._register_builtin_tools",
                    "builtin_registered",
                    call_id="tool",
                )
            else:
                source = "external"
                tool = discovered_external[tool_id].definition
                handler = external_handlers[tool_id]
                log_branch(
                    "WormholeClient._register_builtin_tools",
                    "external_registered",
                    call_id="tool",
                )
            log_parameter(
                "WormholeClient._register_builtin_tools",
                tool_id=tool_id,
                source=source,
                call_id="tool",
            )
            try:
                self._tool_registry.register(tool)
            except ValidationError as exc:
                message = getattr(exc, "message", str(exc))
                if "already registered" in message:
                    raise DuplicateToolError(
                        "tool already registered", {"tool_id": tool_id}
                    ) from exc
                raise
            self._tool_handlers[tool_id] = handler

        log_variable_change(
            "WormholeClient._register_builtin_tools",
            "registered_tool_count",
            0,
            len(self._tool_handlers),
            call_id="tool",
        )
        self._invalidate_tool_cache()
        log_branch(
            "WormholeClient._register_builtin_tools",
            "registration_complete",
            call_id="tool",
        )

    def list_tools(self) -> list[ToolDefinition]:
        """List all registered tools.

        >>> from wormhole_sdk.config import SDKConfig
        >>> class DemoAdapter:
        ...     @property
        ...     def provider_name(self) -> str:
        ...         return "demo"
        ...     @property
        ...     def model_id(self) -> str:
        ...         return "demo-model"
        ...     async def stream(self, messages, tools=None, system_prompt=None, max_tokens=None):
        ...         return
        ...         yield ModelEvent(ModelEventType.STOP, {"finish_reason": "end_turn"})
        ...     async def count_tokens(self, messages) -> int:
        ...         return len(messages)
        >>> client = WormholeClient(SDKConfig(adapter=DemoAdapter()))
        >>> client.list_tools()
        []
        """

        return self._tool_registry.list_tools()

    async def close(self) -> None:
        """Clean up resources and stop active sessions."""
        for internal_id in list(self._session_handles.keys()):
            await self._session_manager.stop_session(internal_id)
        self._session_handles.clear()
        self._active_sessions.clear()
        self._staged_queues.clear()

        close_method = getattr(self._adapter, "close", None)
        if close_method is None:
            return
        result = close_method()
        if inspect.isawaitable(result):
            await result

    async def __aenter__(self) -> "WormholeClient":
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        await self.close()

    def _build_user_message(self, text: str) -> Message:
        part = Part(
            id=f"part-{uuid4().hex[:8]}", type=PartType.TEXT, payload={"text": text}
        )
        return Message(id=f"msg-{uuid4().hex[:8]}", role=MessageRole.USER, parts=[part])

    def _build_tool_result_message(self, results: list[ToolCall]) -> Message:
        parts: list[Part] = []
        for call in results:
            part = Part(
                id=f"part-{call.tool_call_id}",
                type=PartType.TOOL_OUTPUT,
                payload={
                    "tool_call_id": call.tool_call_id,
                    "tool_id": call.tool_id,
                    "output": call.result,
                    "status": call.status.value
                    if hasattr(call.status, "value")
                    else str(call.status),
                    "error": call.error,
                },
            )
            parts.append(part)
        return Message(
            id=f"msg-tool-results-{uuid4().hex[:8]}",
            role=MessageRole.USER,
            parts=parts,
        )

    def _append_assistant_text(self, external_session_id: str, text: str) -> None:
        if not text:
            return
        history = self._session_messages.setdefault(external_session_id, [])
        if history and history[-1].role is MessageRole.ASSISTANT:
            last = history[-1]
            parts = list(last.parts)
            if parts and parts[-1].type is PartType.TEXT:
                merged = dict(parts[-1].payload)
                merged["text"] = f"{merged.get('text', '')}{text}"
                parts[-1] = Part(id=parts[-1].id, type=PartType.TEXT, payload=merged)
                history[-1] = Message(
                    id=last.id, role=last.role, parts=parts, created_at=last.created_at
                )
                return
        part = Part(
            id=f"part-{uuid4().hex[:8]}", type=PartType.TEXT, payload={"text": text}
        )
        history.append(
            Message(
                id=f"msg-{uuid4().hex[:8]}", role=MessageRole.ASSISTANT, parts=[part]
            )
        )

    def _append_assistant_tool_calls(
        self, external_session_id: str, calls: list[ToolCall]
    ) -> None:
        if not calls:
            return
        history = self._session_messages.setdefault(external_session_id, [])
        tool_parts = [
            Part(
                id=f"part-tc-{call.tool_call_id}",
                type=PartType.TOOL_CALL,
                payload={
                    "tool_call_id": call.tool_call_id,
                    "tool_name": call.tool_id,
                    "arguments": dict(call.arguments),
                },
            )
            for call in calls
        ]
        if history and history[-1].role is MessageRole.ASSISTANT:
            # Append tool call parts to existing assistant message
            last = history[-1]
            parts = list(last.parts) + tool_parts
            history[-1] = Message(
                id=last.id, role=last.role, parts=parts, created_at=last.created_at
            )
        else:
            # Create new assistant message with tool calls
            history.append(
                Message(
                    id=f"msg-{uuid4().hex[:8]}",
                    role=MessageRole.ASSISTANT,
                    parts=tool_parts,
                )
            )

    def _prepare_model_messages(self, history: Sequence[Message]) -> list[Message]:
        reconstructed, _, _ = build_reconstructed_context(
            history,
            protected_rounds=self._compaction_config.protected_rounds,
        )
        prepared: list[Message] = []
        for message in reconstructed:
            if self._is_empty_compaction_message(message):
                repaired = self._repair_compaction_message(message)
                prepared.append(repaired)
                continue
            prepared.append(message)
        return prepared

    def _is_empty_compaction_message(self, message: Message) -> bool:
        metadata = message.metadata or {}
        if metadata.get("compaction") is not True:
            return False
        if message.role is not MessageRole.SYSTEM:
            return False
        for part in message.parts:
            if part.type is not PartType.TEXT:
                continue
            payload = part.payload
            if isinstance(payload, dict):
                text = str(payload.get("text", ""))
            else:
                text = str(payload)
            if text.strip():
                return False
        return True

    def _repair_compaction_message(self, message: Message) -> Message:
        snapshot_id = (message.metadata or {}).get("snapshot_id", "unknown")
        payload = {"text": f"Compaction checkpoint (legacy snapshot={snapshot_id})."}
        part = Part(id=f"part-{uuid4().hex[:8]}", type=PartType.TEXT, payload=payload)
        return Message(
            id=message.id,
            role=message.role,
            parts=[part],
            created_at=message.created_at,
            metadata=dict(message.metadata),
        )

    def _invalidate_tool_cache(self) -> None:
        self._tool_cache_hash = None
        self._tool_cache_payload = None

    def _get_tool_metadata(self) -> list[dict[str, Any]]:
        tools = self._tool_registry.list_tools()
        payload = [self._tool_definition_to_metadata(tool) for tool in tools]
        digest = self._tool_digest(payload)
        if digest != self._tool_cache_hash:
            self._tool_cache_hash = digest
            self._tool_cache_payload = payload
            self._tool_cache_version += 1
        return list(self._tool_cache_payload or [])

    async def _resolve_system_prompt(
        self,
        system_prompt: str | None,
        tools: list[ToolDefinition],
        session_id: str,
    ) -> str | None:
        if system_prompt is not None:
            return system_prompt
        if not isinstance(self._prompt_builder, PromptBuilder):
            return None
        builder = self._prompt_builder
        builder.set_environment(EnvironmentContext())
        builder.set_project(Path.cwd())
        builder.set_tools(tools)
        layers = builder.get_layers()
        session_context = {
            "session_id": session_id,
            "cwd": str(Path.cwd()),
        }
        layers = await self._session_hooks.run_transform_system_prompt(
            layers, session_context
        )
        return "\n\n".join(layers)

    def _tool_definition_to_metadata(self, tool: ToolDefinition) -> dict[str, Any]:
        capabilities = getattr(tool, "capabilities", None)
        return {
            "tool_id": tool.tool_id,
            "name": tool.name,
            "description": tool.description,
            "schema": dict(tool.schema),
            "capabilities": {
                "read_only": bool(getattr(capabilities, "read_only", False)),
                "concurrency_safe": bool(
                    getattr(capabilities, "concurrency_safe", False)
                ),
                "approval_required": bool(
                    getattr(capabilities, "approval_required", False)
                ),
            },
            "permission_kind": getattr(
                tool.permission_kind, "value", tool.permission_kind
            ),
        }

    def _tool_digest(self, payload: list[dict[str, Any]]) -> str:
        encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode(
            "utf-8"
        )
        return hashlib.sha256(encoded).hexdigest()

    def _to_tool_call(self, event: ModelEvent) -> ToolCall:
        payload = dict(event.payload)
        tool_call_id = (
            payload.get("tool_call_id") or payload.get("id") or uuid4().hex[:8]
        )
        tool_id = (
            payload.get("tool_name") or payload.get("tool_id") or payload.get("name")
        )
        arguments = payload.get("arguments") or {}
        return ToolCall(
            tool_call_id=str(tool_call_id), tool_id=str(tool_id), arguments=arguments
        )

    def _apply_tool_call_deltas(
        self,
        calls: list[ToolCall],
        deltas: dict[str, str],
    ) -> list[ToolCall]:
        updated: list[ToolCall] = []
        for call in calls:
            delta = deltas.get(call.tool_call_id)
            if not delta:
                updated.append(call)
                continue
            try:
                parsed = json.loads(delta)
            except json.JSONDecodeError:
                updated.append(call)
                continue
            arguments = parsed if isinstance(parsed, dict) else dict(call.arguments)
            updated.append(
                ToolCall(
                    tool_call_id=call.tool_call_id,
                    tool_id=call.tool_id,
                    arguments=arguments,
                    status=call.status,
                    result=call.result,
                    error=call.error,
                )
            )
        return updated

    def _parse_finish_reason(self, value: object | None) -> FinishReason | None:
        if value is None:
            return None
        try:
            return FinishReason(str(value))
        except ValueError:
            return None

    async def _ensure_session(self, session_id: str | None) -> tuple[str, str]:
        log_parameter(
            "WormholeClient._ensure_session",
            session_id=session_id,
            call_id=session_id or "pending",
        )
        if session_id is None:
            if self._default_session_id is not None:
                log_branch(
                    "WormholeClient._ensure_session",
                    "reuse_default",
                    call_id=self._default_session_id,
                )
                internal = self._session_aliases[self._default_session_id]
                runtime = self._session_manager._sessions.get(internal)
                if runtime is not None:
                    runtime.loop_context["staged_queue"] = self._get_staged_queue(
                        self._default_session_id
                    )
                    runtime.messages = list(
                        self._session_messages.get(
                            self._default_session_id, runtime.messages
                        )
                    )
                return self._default_session_id, internal
            handle = await self._session_manager.start_session()
            internal = handle.session.session_id
            external = internal
            self._session_handles[internal] = handle
            self._session_aliases[external] = internal
            self._default_session_id = external
            log_variable_change(
                "WormholeClient._ensure_session", "default_session_id", None, external
            )
            if self._persist_sessions:
                await self._load_session_messages(external)
            runtime = self._session_manager._sessions.get(internal)
            if runtime is not None:
                runtime.loop_context["staged_queue"] = self._get_staged_queue(external)
                runtime.messages = list(
                    self._session_messages.get(external, runtime.messages)
                )
            return external, internal

        if session_id in self._session_aliases:
            log_branch(
                "WormholeClient._ensure_session", "reuse_override", call_id=session_id
            )
            internal = self._session_aliases[session_id]
            runtime = self._session_manager._sessions.get(internal)
            if runtime is not None:
                runtime.loop_context["staged_queue"] = self._get_staged_queue(
                    session_id
                )
                runtime.messages = list(
                    self._session_messages.get(session_id, runtime.messages)
                )
            return session_id, internal

        handle = await self._session_manager.start_session()
        internal = handle.session.session_id
        self._session_handles[internal] = handle
        self._session_aliases[session_id] = internal
        log_branch(
            "WormholeClient._ensure_session", "create_override", call_id=session_id
        )
        if self._persist_sessions:
            await self._load_session_messages(session_id)
        runtime = self._session_manager._sessions.get(internal)
        if runtime is not None:
            runtime.loop_context["staged_queue"] = self._get_staged_queue(session_id)
            runtime.messages = list(
                self._session_messages.get(session_id, runtime.messages)
            )
        return session_id, internal

    def _get_staged_queue(self, session_id: str) -> asyncio.Queue[str]:
        queue = self._staged_queues.get(session_id)
        if queue is None:
            queue = asyncio.Queue(maxsize=self._config.max_staged_messages)
            self._staged_queues[session_id] = queue
        return queue

    def _drain_staged_snapshot(self, queue: asyncio.Queue[str]) -> list[str]:
        snapshot_size = queue.qsize()
        drained: list[str] = []
        for _ in range(snapshot_size):
            try:
                drained.append(queue.get_nowait())
            except asyncio.QueueEmpty:
                break
        return drained

    async def stage_message(
        self, message: str, *, session_id: str | None = None
    ) -> StageMessageResult:
        log_parameter(
            "WormholeClient.stage_message",
            session_id=session_id,
            message_length=len(message),
            call_id=session_id or "pending",
        )
        external_session_id, _ = await self._ensure_session(session_id)
        queue = self._get_staged_queue(external_session_id)
        try:
            queue.put_nowait(message)
        except asyncio.QueueFull:
            log_branch(
                "WormholeClient.stage_message",
                "queue_full",
                call_id=external_session_id,
            )
            return StageMessageResult(status="queue_full")
        log_branch(
            "WormholeClient.stage_message",
            "accepted",
            call_id=external_session_id,
        )
        return StageMessageResult(status="accepted")

    def _resolve_adapter(self, model: str | None) -> ModelAdapter:
        if model is None:
            return self._adapter
        if self._adapter_factory is not None:
            return self._adapter_factory(model)
        with_model = getattr(self._adapter, "with_model", None)
        if callable(with_model):
            return cast(ModelAdapter, with_model(model))
        return self._adapter

    def _coerce_stream_event(self, event: object) -> ModelEvent | None:
        if isinstance(event, ModelEvent):
            return event

        stream_type_source: object | None = None
        stream_payload: object | None = None
        if isinstance(event, dict):
            stream_type_source = event.get("type")
            stream_payload = event.get("payload")
        else:
            payload = getattr(event, "payload", None)
            if isinstance(payload, dict) and isinstance(
                payload.get("stream_event"), dict
            ):
                stream_event = cast(dict[str, Any], payload["stream_event"])
                stream_type_source = stream_event.get("type")
                stream_payload = stream_event.get("payload")
            else:
                stream_type_source = getattr(event, "type", None)
                stream_payload = payload

        stream_type = (
            str(getattr(stream_type_source, "value", stream_type_source or ""))
            .strip()
            .lower()
        )
        if isinstance(stream_payload, dict):
            normalized_payload: dict[str, Any] = dict(stream_payload)
        else:
            normalized_payload = {"value": stream_payload}
        type_map = {
            "text_delta": ModelEventType.TEXT_DELTA,
            "tool_call": ModelEventType.TOOL_CALL,
            "tool_call_delta": ModelEventType.TOOL_CALL_DELTA,
            "tool_result": ModelEventType.TOOL_RESULT,
            "usage": ModelEventType.USAGE,
            "stop": ModelEventType.STOP,
            "error": ModelEventType.ERROR,
        }
        model_event_type = type_map.get(stream_type)
        if model_event_type is None:
            return None
        return ModelEvent(model_event_type, normalized_payload)

    def _wrap_adapter_for_graph(
        self, adapter: ModelAdapter, call_id: str
    ) -> ModelAdapter:
        client = self

        class _GraphAdapter:
            @property
            def provider_name(self) -> str:
                return str(getattr(adapter, "provider_name", "wrapped"))

            @property
            def model_id(self) -> str:
                return str(getattr(adapter, "model_id", "wrapped-model"))

            async def count_tokens(self, messages: Any) -> int:
                return await adapter.count_tokens(messages)

            def stream(
                self,
                messages: Any,
                tools: Any = None,
                system_prompt: Any = None,
                max_tokens: Any = None,
            ) -> AsyncIterator[ModelEvent]:
                _ = max_tokens
                tool_list = list(tools or [])
                return client._adapter_events(
                    adapter,
                    list(messages),
                    tool_list,
                    system_prompt,
                    call_id=call_id,
                )

        return cast(ModelAdapter, _GraphAdapter())

    async def _adapter_events(
        self,
        adapter: ModelAdapter,
        messages: list[Message],
        tools: list[ToolDefinition],
        system_prompt: str | None,
        call_id: str,
    ) -> AsyncIterator[ModelEvent]:
        policy = self._config.retry_policy
        attempts = 0

        while True:
            emitted = False
            should_retry = False
            log_loop_iteration(
                "WormholeClient._adapter_events",
                "attempts",
                attempts + 1,
                call_id=call_id,
            )
            source = adapter.stream(messages, tools=tools, system_prompt=system_prompt)
            try:
                async for event in self._iter_with_timeout(
                    source, self._config.timeout_seconds
                ):
                    if event.type is ModelEventType.ERROR:
                        retryable = bool(event.payload.get("retryable", False))
                        if (
                            policy
                            and retryable
                            and not emitted
                            and attempts < policy.max_retries
                        ):
                            attempts += 1
                            await asyncio.sleep(policy.delay_for_attempt(attempts))
                            should_retry = True
                            log_branch(
                                "WormholeClient._adapter_events",
                                "retry_error",
                                call_id=call_id,
                            )
                            break
                        yield event
                        return
                    emitted = True
                    yield event
                if should_retry:
                    continue
                return
            except asyncio.TimeoutError as exc:
                error = ProviderError(
                    f"model request timed out: {exc}",
                    {"timeout": self._config.timeout_seconds},
                )
                if (
                    policy
                    and error.retryable
                    and not emitted
                    and attempts < policy.max_retries
                ):
                    attempts += 1
                    await asyncio.sleep(policy.delay_for_attempt(attempts))
                    log_branch(
                        "WormholeClient._adapter_events",
                        "retry_timeout",
                        call_id=call_id,
                    )
                    continue
                yield ModelEvent(
                    ModelEventType.ERROR,
                    {
                        "code": error.code.value,
                        "message": error.message,
                        "retryable": error.retryable,
                    },
                )
                return
            except Exception as exc:
                error = ProviderError(str(exc))
                if (
                    policy
                    and error.retryable
                    and not emitted
                    and attempts < policy.max_retries
                ):
                    attempts += 1
                    await asyncio.sleep(policy.delay_for_attempt(attempts))
                    log_branch(
                        "WormholeClient._adapter_events",
                        "retry_exception",
                        call_id=call_id,
                    )
                    continue
                yield ModelEvent(
                    ModelEventType.ERROR,
                    {
                        "code": error.code.value,
                        "message": error.message,
                        "retryable": error.retryable,
                    },
                )
                return
            finally:
                aclose = getattr(source, "aclose", None)
                if callable(aclose):
                    await aclose()

    async def _iter_with_timeout(
        self,
        source: AsyncIterator[ModelEvent],
        timeout_seconds: float | None,
    ) -> AsyncIterator[ModelEvent]:
        if timeout_seconds is None:
            async for event in source:
                yield event
            return

        deadline = time.monotonic() + timeout_seconds
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise asyncio.TimeoutError("stream timed out")
            try:
                event = await asyncio.wait_for(source.__anext__(), timeout=remaining)
            except StopAsyncIteration:
                return
            yield event


__all__ = ["WormholeClient"]
