"""SDK and model error taxonomy."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Mapping

from wormhole_core.logging import log_parameter


class SDKErrorCode(str, Enum):
    """Stable error codes for SDK-level failures."""

    CONFIGURATION_ERROR = "WH-SDK-001"
    DUPLICATE_TOOL = "WH-SDK-002"
    SAFETY_LIMIT = "WH-SDK-003"


class ModelErrorCode(str, Enum):
    """Stable error codes for provider failures."""

    RATE_LIMIT = "WH-MODEL-001"
    AUTHENTICATION_ERROR = "WH-MODEL-002"
    PROVIDER_ERROR = "WH-MODEL-003"
    INVALID_REQUEST = "WH-MODEL-004"
    TOKEN_LIMIT = "WH-MODEL-010"
    CONTENT_FILTER = "WH-MODEL-011"


class ToolErrorCode(str, Enum):
    """Error codes for tool loading failures.

    >>> ToolErrorCode.TOOL_IMPORT_ERROR.value
    'WH-SDK-TOOL-002'
    """

    TOOL_LOAD_ERROR = "WH-SDK-TOOL-001"
    TOOL_IMPORT_ERROR = "WH-SDK-TOOL-002"
    TOOL_API_VERSION_MISMATCH = "WH-SDK-TOOL-003"
    TOOL_VALIDATION_ERROR = "WH-SDK-TOOL-004"
    TOOL_MISSING_FACTORY = "WH-SDK-TOOL-005"
    TOOL_HANDLER_ERROR = "WH-SDK-TOOL-006"


@dataclass(frozen=True)
class SDKError(Exception):
    """Base SDK error with stable code and context.

    >>> err = SDKError(SDKErrorCode.CONFIGURATION_ERROR, "missing key", {"env": "ANTHROPIC_API_KEY"})
    >>> err.code
    <SDKErrorCode.CONFIGURATION_ERROR: 'WH-SDK-001'>
    >>> err.to_dict()["code"]
    'WH-SDK-001'
    """

    code: SDKErrorCode
    message: str
    context: Mapping[str, Any] = field(default_factory=dict)
    retryable: bool = False

    def __post_init__(self) -> None:
        log_parameter(
            "SDKError.__init__",
            code=self.code.value,
            message=self.message,
            retryable=self.retryable,
        )

    def __str__(self) -> str:
        return f"{self.code.value}: {self.message}"

    def to_dict(self) -> dict[str, Any]:
        return {
            "code": self.code.value,
            "message": self.message,
            "context": dict(self.context),
            "retryable": self.retryable,
        }

    def is_retryable(self) -> bool:
        return self.retryable


@dataclass(frozen=True)
class ModelError(Exception):
    """Base error for model adapter failures.

    >>> err = ModelError(ModelErrorCode.PROVIDER_ERROR, "timeout", retryable=True)
    >>> err.code
    <ModelErrorCode.PROVIDER_ERROR: 'WH-MODEL-003'>
    >>> err.is_retryable()
    True
    """

    code: ModelErrorCode
    message: str
    context: Mapping[str, Any] = field(default_factory=dict)
    retryable: bool = False

    def __post_init__(self) -> None:
        log_parameter(
            "ModelError.__init__",
            code=self.code.value,
            message=self.message,
            retryable=self.retryable,
        )

    def __str__(self) -> str:
        return f"{self.code.value}: {self.message}"

    def to_dict(self) -> dict[str, Any]:
        return {
            "code": self.code.value,
            "message": self.message,
            "context": dict(self.context),
            "retryable": self.retryable,
        }

    def is_retryable(self) -> bool:
        return self.retryable


class ConfigurationError(SDKError):
    """SDK configuration error."""

    def __init__(self, message: str, context: Mapping[str, Any] | None = None) -> None:
        super().__init__(SDKErrorCode.CONFIGURATION_ERROR, message, context or {})


class DuplicateToolError(SDKError):
    """Tool registration conflict."""

    def __init__(self, message: str, context: Mapping[str, Any] | None = None) -> None:
        super().__init__(SDKErrorCode.DUPLICATE_TOOL, message, context or {})


class SafetyLimitError(SDKError):
    """Safety limit exceeded error."""

    def __init__(self, message: str, context: Mapping[str, Any] | None = None) -> None:
        super().__init__(SDKErrorCode.SAFETY_LIMIT, message, context or {})


class RateLimitError(ModelError):
    """Rate limit error from provider."""

    def __init__(self, message: str, context: Mapping[str, Any] | None = None) -> None:
        super().__init__(
            ModelErrorCode.RATE_LIMIT, message, context or {}, retryable=True
        )


class AuthenticationError(ModelError):
    """Authentication error from provider."""

    def __init__(self, message: str, context: Mapping[str, Any] | None = None) -> None:
        super().__init__(ModelErrorCode.AUTHENTICATION_ERROR, message, context or {})


class ProviderError(ModelError):
    """Provider API error."""

    def __init__(
        self,
        message: str,
        context: Mapping[str, Any] | None = None,
        retryable: bool = True,
    ) -> None:
        super().__init__(
            ModelErrorCode.PROVIDER_ERROR, message, context or {}, retryable=retryable
        )


class InvalidRequestError(ModelError):
    """Invalid request error from provider."""

    def __init__(self, message: str, context: Mapping[str, Any] | None = None) -> None:
        super().__init__(ModelErrorCode.INVALID_REQUEST, message, context or {})


class TokenLimitError(ModelError):
    """Model context length exceeded."""

    def __init__(self, message: str, context: Mapping[str, Any] | None = None) -> None:
        super().__init__(ModelErrorCode.TOKEN_LIMIT, message, context or {})


class ContentFilterError(ModelError):
    """Content blocked by provider safety filters."""

    def __init__(self, message: str, context: Mapping[str, Any] | None = None) -> None:
        super().__init__(ModelErrorCode.CONTENT_FILTER, message, context or {})


@dataclass(frozen=True)
class ToolLoadError(Exception):
    """Error loading an external tool module.

    >>> err = ToolLoadError(
    ...     message="import failed",
    ...     error_code=ToolErrorCode.TOOL_IMPORT_ERROR,
    ...     module_path="my_tools.bad_tool",
    ... )
    >>> err.error_code
    <ToolErrorCode.TOOL_IMPORT_ERROR: 'WH-SDK-TOOL-002'>
    >>> "my_tools.bad_tool" in str(err)
    True
    """

    message: str
    error_code: ToolErrorCode
    module_path: str
    factory_name: str | None = None
    cause: Exception | None = None
    context: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        log_parameter(
            "ToolLoadError.__init__",
            error_code=self.error_code.value,
            module_path=self.module_path,
            factory_name=self.factory_name,
        )

    def __str__(self) -> str:
        parts = [
            f"[{self.error_code.value}] {self.message}",
            f"  module: {self.module_path}",
        ]
        if self.factory_name:
            parts.append(f"  factory: {self.factory_name}")
        if self.cause:
            parts.append(f"  cause: {type(self.cause).__name__}: {self.cause}")
        return "\n".join(parts)


def import_error(module_path: str, cause: Exception) -> ToolLoadError:
    """Create error for module import failure.

    >>> err = import_error("missing.module", ModuleNotFoundError("missing.module"))
    >>> err.error_code
    <ToolErrorCode.TOOL_IMPORT_ERROR: 'WH-SDK-TOOL-002'>
    """
    log_parameter("import_error", module_path=module_path)
    return ToolLoadError(
        message=f"Failed to import module '{module_path}'. "
        "Check that the module path is correct and the module is installed.",
        error_code=ToolErrorCode.TOOL_IMPORT_ERROR,
        module_path=module_path,
        cause=cause,
    )


def missing_factory_error(module_path: str, factory_name: str) -> ToolLoadError:
    """Create error for missing factory function.

    >>> err = missing_factory_error("my_tools.bad", "create_tools")
    >>> err.factory_name
    'create_tools'
    """
    log_parameter(
        "missing_factory_error", module_path=module_path, factory_name=factory_name
    )
    return ToolLoadError(
        message=f"Module '{module_path}' does not expose required function '{factory_name}'.",
        error_code=ToolErrorCode.TOOL_MISSING_FACTORY,
        module_path=module_path,
        factory_name=factory_name,
    )


def api_version_error(
    module_path: str,
    declared_version: str,
    expected_major: int,
    actual_major: int,
) -> ToolLoadError:
    """Create error for API version mismatch.

    >>> err = api_version_error("my_tools.bad", "2.0.0", 1, 2)
    >>> err.error_code
    <ToolErrorCode.TOOL_API_VERSION_MISMATCH: 'WH-SDK-TOOL-003'>
    """
    log_parameter(
        "api_version_error",
        module_path=module_path,
        declared_version=declared_version,
        expected_major=expected_major,
        actual_major=actual_major,
    )
    return ToolLoadError(
        message=(
            "API version mismatch: module "
            f"'{module_path}' declares version '{declared_version}' "
            f"(major {actual_major}), but SDK requires major version {expected_major}."
        ),
        error_code=ToolErrorCode.TOOL_API_VERSION_MISMATCH,
        module_path=module_path,
        context={
            "declared_version": declared_version,
            "expected_major": expected_major,
            "actual_major": actual_major,
        },
    )


def validation_error(
    module_path: str,
    tool_id: str,
    validation_message: str,
) -> ToolLoadError:
    """Create error for tool definition validation failure.

    >>> err = validation_error("my_tools.bad", "bad_tool", "missing schema")
    >>> err.context["tool_id"]
    'bad_tool'
    """
    log_parameter(
        "validation_error",
        module_path=module_path,
        tool_id=tool_id,
    )
    return ToolLoadError(
        message=f"Tool '{tool_id}' from '{module_path}' failed validation: {validation_message}",
        error_code=ToolErrorCode.TOOL_VALIDATION_ERROR,
        module_path=module_path,
        context={"tool_id": tool_id, "validation_message": validation_message},
    )


def handler_error(
    module_path: str,
    tool_id: str,
    cause: Exception | None = None,
) -> ToolLoadError:
    """Create error for handler creation failure.

    >>> err = handler_error("my_tools.bad", "bad_tool")
    >>> err.error_code
    <ToolErrorCode.TOOL_HANDLER_ERROR: 'WH-SDK-TOOL-006'>
    """
    log_parameter("handler_error", module_path=module_path, tool_id=tool_id)
    return ToolLoadError(
        message=f"Failed to create handler for tool '{tool_id}' from '{module_path}'.",
        error_code=ToolErrorCode.TOOL_HANDLER_ERROR,
        module_path=module_path,
        factory_name="create_handlers",
        cause=cause,
        context={"tool_id": tool_id},
    )


__all__ = [
    "AuthenticationError",
    "ConfigurationError",
    "ContentFilterError",
    "DuplicateToolError",
    "InvalidRequestError",
    "ModelError",
    "ModelErrorCode",
    "ProviderError",
    "RateLimitError",
    "SafetyLimitError",
    "SDKError",
    "SDKErrorCode",
    "TokenLimitError",
    "ToolErrorCode",
    "ToolLoadError",
    "api_version_error",
    "handler_error",
    "import_error",
    "missing_factory_error",
    "validation_error",
]
