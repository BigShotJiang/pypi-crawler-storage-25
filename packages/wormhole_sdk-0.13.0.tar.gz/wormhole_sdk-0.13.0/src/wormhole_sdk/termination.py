"""Loop continuation helpers."""

from __future__ import annotations

from enum import Enum
from typing import Protocol, Sequence

from wormhole_core.logging import log_branch, log_parameter

from .adapter.events import FinishReason
from .config import SDKConfig


class ContinuationMode(str, Enum):
    """Continuation overrides for loop execution.

    >>> ContinuationMode.AUTOMATIC.value
    'automatic'
    """

    AUTOMATIC = "automatic"
    FORCE_CONTINUE = "force_continue"
    FORCE_STOP = "force_stop"


class _StateLike(Protocol):
    @property
    def continuation_mode(self) -> object: ...
    @property
    def pending_tool_calls(self) -> Sequence[str]: ...
    @property
    def last_finish_reason(self) -> object | None: ...
    @property
    def next_speaker(self) -> str: ...


def _coerce_value(value: object | None) -> str | None:
    if value is None:
        return None
    if isinstance(value, Enum):
        return str(value.value)
    return str(value)


def should_continue(state: _StateLike, config: SDKConfig) -> bool:
    """Decide whether the agent loop should continue.

    >>> from dataclasses import dataclass
    >>> @dataclass
    ... class DemoState:
    ...     continuation_mode: ContinuationMode
    ...     pending_tool_calls: list[str]
    ...     last_finish_reason: FinishReason | None
    ...     next_speaker: str
    >>> cfg = SDKConfig()
    >>> state = DemoState(ContinuationMode.AUTOMATIC, ["tc1"], FinishReason.TOOL_USE, "assistant")
    >>> should_continue(state, cfg)
    True
    >>> state = DemoState(ContinuationMode.AUTOMATIC, [], FinishReason.END_TURN, "user")
    >>> should_continue(state, cfg)
    False
    """

    mode = _coerce_value(state.continuation_mode)
    log_parameter(
        "should_continue",
        continuation_mode=mode,
        pending_tool_calls=len(state.pending_tool_calls),
        last_finish_reason=_coerce_value(state.last_finish_reason),
        next_speaker=state.next_speaker,
        continue_on_max_tokens=config.continue_on_max_tokens,
    )
    if mode == ContinuationMode.FORCE_CONTINUE.value:
        log_branch("should_continue", "force_continue")
        return True
    if mode == ContinuationMode.FORCE_STOP.value:
        log_branch("should_continue", "force_stop")
        return False

    if state.pending_tool_calls:
        log_branch("should_continue", "pending_tool_calls")
        return True

    finish = _coerce_value(state.last_finish_reason)
    if finish == FinishReason.END_TURN.value:
        log_branch("should_continue", "finish_end_turn")
        return False
    if finish == FinishReason.TOOL_USE.value:
        log_branch("should_continue", "finish_tool_use")
        return True
    if finish == FinishReason.MAX_TOKENS.value:
        log_branch("should_continue", "finish_max_tokens")
        return bool(config.continue_on_max_tokens)
    if finish == FinishReason.STOP_SEQUENCE.value:
        log_branch("should_continue", "finish_stop_sequence")
        return False

    log_branch("should_continue", "fallback_next_speaker")
    return state.next_speaker == "assistant"


__all__ = ["ContinuationMode", "should_continue"]
