"""Storage provider utilities for the Wormhole SDK."""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Protocol, Sequence, runtime_checkable

from wormhole_core.logging import (
    log_branch,
    log_loop_iteration,
    log_parameter,
    log_timing,
)
from wormhole_core.storage import (
    CompactionStore,
    CompactionStoreProtocol,
    EventLogStore,
    EventLogStoreProtocol,
    ExecutionStateStore,
    ExecutionStateStoreProtocol,
    SessionStore,
    SessionStoreProtocol,
)

STORAGE_API_VERSION = "1.0.0"


@dataclass(frozen=True)
class StorageProvider:
    """Aggregates all storage protocol implementations.

    >>> import tempfile
    >>> root = Path(tempfile.mkdtemp())
    >>> provider = StorageProvider(
    ...     session_store=SessionStore(root / "sessions"),
    ...     execution_state_store=ExecutionStateStore(root / "execution_state"),
    ...     event_log_store=EventLogStore(root / "event_logs"),
    ...     compaction_store=CompactionStore(root / "compaction"),
    ... )
    >>> provider.api_version
    '1.0.0'
    """

    session_store: SessionStoreProtocol
    execution_state_store: ExecutionStateStoreProtocol
    event_log_store: EventLogStoreProtocol
    compaction_store: CompactionStoreProtocol
    api_version: str = STORAGE_API_VERSION


@runtime_checkable
class StorageProviderHook(Protocol):
    """Hook protocol for storage provider registration."""

    def __call__(self, provider: StorageProvider | None) -> StorageProvider | None:
        """Process the current provider and return a (possibly modified) provider."""


@dataclass
class StorageProviderRegistry:
    """Registry for storage provider hooks."""

    hooks: list[StorageProviderHook] = field(default_factory=list)

    def add(self, hook: StorageProviderHook) -> None:
        """Register a storage provider hook.

        >>> registry = StorageProviderRegistry()
        >>> registry.add(lambda provider: provider)
        >>> len(registry.hooks)
        1
        """
        self.hooks.append(hook)

    def remove(self, hook: StorageProviderHook) -> None:
        """Remove a storage provider hook.

        >>> registry = StorageProviderRegistry()
        >>> hook = lambda provider: provider
        >>> registry.add(hook)
        >>> registry.remove(hook)
        >>> len(registry.hooks)
        0
        """
        self.hooks.remove(hook)

    def apply(
        self, provider: StorageProvider | None, call_id: str = "storage_provider"
    ) -> StorageProvider | None:
        """Apply hooks in registration order with failure isolation.

        >>> registry = StorageProviderRegistry()
        >>> registry.add(lambda current: current)
        >>> registry.apply(None) is None
        True
        """
        log_parameter(
            "StorageProviderRegistry.apply",
            hook_count=len(self.hooks),
            has_provider=provider is not None,
            call_id=call_id,
        )
        started = time.monotonic()
        current = provider
        for index, hook in enumerate(self.hooks, start=1):
            log_loop_iteration(
                "StorageProviderRegistry.apply", "hooks", index, call_id=call_id
            )
            hook_name = getattr(hook, "__name__", hook.__class__.__name__)
            try:
                result = hook(current)
            except Exception as exc:
                log_branch(
                    "StorageProviderRegistry.apply", "hook_failed", call_id=call_id
                )
                log_parameter(
                    "StorageProviderRegistry.apply",
                    hook=hook_name,
                    error=exc,
                    call_id=call_id,
                )
                continue
            current = result
            log_branch(
                "StorageProviderRegistry.apply",
                "hook_returned_none" if result is None else "hook_applied",
                call_id=call_id,
            )
        log_timing(
            "StorageProviderRegistry.apply",
            (time.monotonic() - started) * 1000,
            call_id=call_id,
        )
        return current


def create_default_storage_provider(
    storage_root: Path,
    hooks: Sequence[StorageProviderHook] | None = None,
    provider: StorageProvider | None = None,
) -> StorageProvider:
    """Create a storage provider with file-based fallback.

    >>> import tempfile
    >>> from pathlib import Path
    >>> provider = create_default_storage_provider(Path(tempfile.mkdtemp()))
    >>> provider.api_version
    '1.0.0'
    """
    call_id = "storage_provider"
    log_parameter(
        "create_default_storage_provider",
        storage_root=str(storage_root),
        has_provider=provider is not None,
        hook_count=len(hooks or []),
        call_id=call_id,
    )
    started = time.monotonic()
    registry = StorageProviderRegistry(list(hooks or []))
    resolved = registry.apply(provider, call_id=call_id)
    if resolved is None:
        if provider is not None:
            log_branch(
                "create_default_storage_provider", "provider_fallback", call_id=call_id
            )
            resolved = provider
        else:
            log_branch(
                "create_default_storage_provider", "provider_default", call_id=call_id
            )
            base_root = Path(storage_root)
            base_root.mkdir(parents=True, exist_ok=True)
            resolved = StorageProvider(
                session_store=SessionStore(base_root / "sessions"),
                execution_state_store=ExecutionStateStore(
                    base_root / "execution_state"
                ),
                event_log_store=EventLogStore(base_root / "event_logs"),
                compaction_store=CompactionStore(base_root / "compaction"),
                api_version=STORAGE_API_VERSION,
            )
    else:
        log_branch(
            "create_default_storage_provider", "provider_resolved", call_id=call_id
        )
    log_timing(
        "create_default_storage_provider",
        (time.monotonic() - started) * 1000,
        call_id=call_id,
    )
    return resolved


__all__ = [
    "STORAGE_API_VERSION",
    "StorageProvider",
    "StorageProviderHook",
    "StorageProviderRegistry",
    "create_default_storage_provider",
]
