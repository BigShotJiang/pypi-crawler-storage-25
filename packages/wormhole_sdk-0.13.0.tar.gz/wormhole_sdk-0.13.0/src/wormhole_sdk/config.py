"""SDK configuration defaults and validation."""

from dataclasses import dataclass, field
from pathlib import Path

from wormhole_core.errors import ValidationError
from wormhole_core.logging import log_branch, log_parameter
from wormhole_core.retry import RetryPolicy
from wormhole_core.schemas.session import CompactionConfig

from .adapter.base import ModelAdapter
from .hooks import SessionHooks
from .storage import StorageProvider, StorageProviderHook


@dataclass
class SDKConfig:
    """SDK configuration - all settings in one place.

    Args:
        adapter: Model adapter (e.g., AnthropicAdapter). If None, creates default.
        api_key: API key for default adapter. Falls back to ANTHROPIC_API_KEY env var.
        model: Default model name.
        hooks: Session hooks (e.g., ApprovalManager for permission gating).
        tools: List of tool IDs to register (built-in + external).
        tool_config_paths: Module paths for external tool discovery.
        root_dir: Working directory for tool path resolution. Defaults to cwd.
        timeout_seconds: LLM API request timeout.
        max_consecutive_steps: Max tool execution loops before stopping.
        continue_on_max_tokens: Continue if LLM response hits token limit.
        retry_policy: Retry policy for API errors.
        storage_provider: Custom storage provider for persistence.
        storage_provider_hooks: Hooks to resolve/modify storage providers.
        persist_sessions: Enable persistence for session messages.
        auto_save: Auto-save sessions after message exchange.
        auto_compaction_enabled: Enable auto compaction after each exchange.
        compaction_trigger_threshold: Context usage ratio that triggers compaction.
        compaction_prune_target: Target ratio after pruning tool outputs.
        compaction_protected_rounds: Number of recent rounds protected from pruning.
        compaction_context_limit: Model context limit for auto compaction (required to auto-trigger).
        compaction_max_summary_tokens: Max tokens for summary generation.

    Example:
        from wormhole_sdk import (
            SDKConfig, AnthropicAdapter, ApprovalManager,
            TOOL_BASH, TOOL_FILE_READ, TOOL_FILE_EDIT, TOOL_FILE_WRITE,
        )

        config = SDKConfig(
            adapter=AnthropicAdapter(api_key="..."),
            hooks=[ApprovalManager(handler=my_handler)],
            tools=[TOOL_BASH, TOOL_FILE_READ, TOOL_FILE_EDIT, TOOL_FILE_WRITE],
            root_dir=Path.cwd(),
        )
        client = WormholeClient(config)

    >>> cfg = SDKConfig()
    >>> cfg.model
    'claude-sonnet-4-20250514'
    >>> cfg.timeout_seconds
    120.0
    """

    # Adapter and model
    adapter: ModelAdapter | None = None
    api_key: str | None = None
    model: str = "claude-sonnet-4-20250514"

    # Hooks and tools
    hooks: list[SessionHooks] = field(default_factory=list)
    tools: list[str] = field(default_factory=list)
    tool_config_paths: list[str] = field(default_factory=list)
    root_dir: Path | None = None

    # Timeouts and limits
    timeout_seconds: float = 120.0
    max_consecutive_steps: int = 100
    continue_on_max_tokens: bool = True
    main_loop_unbounded: bool = False
    max_staged_messages: int = 100

    # Retry and allowlist
    retry_policy: RetryPolicy | None = None
    default_allowlist: list[str] = field(default_factory=list)

    # Storage provider configuration
    storage_provider: StorageProvider | None = None
    storage_provider_hooks: list[StorageProviderHook] = field(default_factory=list)
    persist_sessions: bool = True
    auto_save: bool = True

    # Compaction configuration (SDK-level auto compaction)
    auto_compaction_enabled: bool = True
    compaction_trigger_threshold: float = 0.9
    compaction_prune_target: float = 0.5
    compaction_protected_rounds: int = 2
    compaction_context_limit: int | None = None
    compaction_max_summary_tokens: int | None = None

    def __post_init__(self) -> None:
        log_parameter(
            "SDKConfig.__post_init__",
            model=self.model,
            timeout_seconds=self.timeout_seconds,
            max_consecutive_steps=self.max_consecutive_steps,
            main_loop_unbounded=self.main_loop_unbounded,
            max_staged_messages=self.max_staged_messages,
            num_hooks=len(self.hooks),
            num_tools=len(self.tools),
            num_tool_config_paths=len(self.tool_config_paths),
            persist_sessions=self.persist_sessions,
            auto_save=self.auto_save,
            storage_provider_configured=self.storage_provider is not None,
            storage_provider_hooks=len(self.storage_provider_hooks),
            auto_compaction_enabled=self.auto_compaction_enabled,
            compaction_trigger_threshold=self.compaction_trigger_threshold,
            compaction_prune_target=self.compaction_prune_target,
            compaction_protected_rounds=self.compaction_protected_rounds,
            compaction_context_limit=self.compaction_context_limit,
            compaction_max_summary_tokens=self.compaction_max_summary_tokens,
        )
        if not self.model:
            log_branch("SDKConfig.__post_init__", "missing_model")
            raise ValidationError("model is required", {})
        if self.timeout_seconds <= 0:
            log_branch("SDKConfig.__post_init__", "invalid_timeout")
            raise ValidationError("timeout_seconds must be > 0", {})
        if self.max_consecutive_steps < 1:
            log_branch("SDKConfig.__post_init__", "invalid_max_steps")
            raise ValidationError("max_consecutive_steps must be >= 1", {})
        if self.max_staged_messages < 1:
            log_branch("SDKConfig.__post_init__", "invalid_max_staged_messages")
            raise ValidationError("max_staged_messages must be >= 1", {})
        if (
            self.compaction_context_limit is not None
            and self.compaction_context_limit <= 0
        ):
            log_branch("SDKConfig.__post_init__", "invalid_compaction_context_limit")
            raise ValidationError("compaction_context_limit must be > 0 or None", {})
        if (
            self.compaction_max_summary_tokens is not None
            and self.compaction_max_summary_tokens <= 0
        ):
            log_branch("SDKConfig.__post_init__", "invalid_compaction_summary_tokens")
            raise ValidationError(
                "compaction_max_summary_tokens must be > 0 or None", {}
            )
        CompactionConfig(
            trigger_threshold=self.compaction_trigger_threshold,
            prune_target_ratio=self.compaction_prune_target,
            protected_rounds=self.compaction_protected_rounds,
            auto_enabled=self.auto_compaction_enabled,
            max_summary_tokens=self.compaction_max_summary_tokens,
        )


__all__ = ["SDKConfig"]
