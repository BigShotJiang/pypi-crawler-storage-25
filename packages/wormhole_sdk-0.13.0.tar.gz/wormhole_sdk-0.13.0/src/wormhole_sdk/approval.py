"""SDK Approval - unified approval engine for tool execution.

This module centralizes approval in ApprovalManager. The manager implements
SessionHooks.before_tool_execute and can also be called directly via request().

Architecture:
- ApprovalManager is the single approval engine (cache + prompt + timeout)
- ApprovalManager implements SessionHooks.before_tool_execute
- Tools define approval_payload() to generate approval request data

Usage:
    from wormhole_sdk import WormholeClient, ApprovalManager

    client = WormholeClient(
        adapter=adapter,
        hooks=[ApprovalManager(handler=my_approval_handler)],
    )
    await client.register_default_tools(root_dir=ROOT_DIR)

>>> from wormhole_sdk.approval import ApprovalManager
>>> manager = ApprovalManager()
>>> manager.permission_cache is not None
True
"""

from __future__ import annotations

import asyncio
import inspect
import logging
import time
from dataclasses import dataclass, field
from typing import Any, Awaitable, Literal, Protocol
from uuid import uuid4

from wormhole_core.errors import PermissionDeniedError
from wormhole_core.schemas.tools import (
    ApprovalDecisionRecord,
    ApprovalPayload,
    ApprovalRequest,
    PermissionAction,
    PermissionRule,
    PermissionScope,
    RiskLevel,
    ToolCall,
    ToolDefinition,
)
from wormhole_core.tools.path_utils import normalize_path_pattern
from wormhole_core.tools.permission_cache import PermissionCache

from .hooks import SessionHooks
from .log_redaction import debug_logging_enabled, sanitize_log_extra

LOGGER = logging.getLogger("wormhole_sdk.approval")


def _log_debug(message: str, *, extra: dict[str, Any] | None = None) -> None:
    if not debug_logging_enabled(LOGGER):
        return
    LOGGER.debug(message, extra=sanitize_log_extra(extra))


def _fallback_target_from_input(tool_id: str, tool_input: dict[str, Any]) -> str:
    """Extract a best-effort target string from raw tool input.

    >>> _fallback_target_from_input("file_write", {"file_path": "/tmp/x.py"})
    '/tmp/x.py'
    >>> _fallback_target_from_input("bash", {"command": "ls -la"})
    'ls -la'
    >>> _fallback_target_from_input("unknown", {})
    '*'
    """
    if tool_id.startswith("file_"):
        file_path = tool_input.get("file_path")
        if isinstance(file_path, str) and file_path.strip():
            return normalize_path_pattern(file_path)
    if tool_id == "bash":
        command = tool_input.get("command")
        if isinstance(command, str) and command.strip():
            return command
    return "*"


def _fallback_payload_for_failed_generation(
    *,
    tool_id: str,
    tool_input: dict[str, Any],
    error: Exception,
) -> ApprovalPayload:
    """Build a conservative ApprovalPayload when the tool's generator fails.

    >>> payload = _fallback_payload_for_failed_generation(
    ...     tool_id="bash", tool_input={"command": "rm -rf /"}, error=RuntimeError("boom"),
    ... )
    >>> payload.risk_assessment
    <RiskLevel.HIGH: 'high'>
    >>> "boom" in payload.preview["payload_error"]
    True
    >>> payload = _fallback_payload_for_failed_generation(
    ...     tool_id="file_read", tool_input={}, error=ValueError("x"),
    ... )
    >>> payload.risk_assessment
    <RiskLevel.MEDIUM: 'medium'>
    """
    target = _fallback_target_from_input(tool_id, tool_input)
    risk = RiskLevel.HIGH if tool_id == "bash" else RiskLevel.MEDIUM
    return ApprovalPayload(
        input_summary=f"{tool_id} (fallback approval)",
        risk_assessment=risk,
        preview={"tool_input": dict(tool_input), "payload_error": str(error)},
        target_context={"target": target},
    )


class ApprovalHandler(Protocol):
    """Protocol for approval handlers that prompt users for permission.

    Implementations can be:
    - Terminal-based (input() prompts)
    - GUI-based (dialog boxes)
    - Programmatic (auto-approve for testing)
    """

    def __call__(
        self, request: ApprovalRequest
    ) -> ApprovalDecisionRecord | Awaitable[ApprovalDecisionRecord]:
        """Request approval from the user.

        Args:
            request: The approval request with tool info and risk assessment.

        Returns:
            ApprovalDecisionRecord with the decision (allow/deny) and scope.
        """
        ...


@dataclass
class ApprovalManager(SessionHooks):
    """Unified approval engine (cache + prompt + timeout + hook integration).

    `ApprovalManager` can be used directly in two ways:
    1. As a standalone approval service via `request(...)`
    2. As a session hook via `before_tool_execute(...)`

    >>> manager = ApprovalManager()
    >>> manager.permission_cache is not None
    True
    """

    permission_cache: PermissionCache = field(default_factory=PermissionCache)
    handler: ApprovalHandler | None = None
    approval_timeout: float = 60.0
    session_id: str = field(default_factory=lambda: f"session-{uuid4().hex[:8]}")
    auto_approve_tools: set[str] = field(default_factory=set)

    @property
    def approval_handler(self) -> ApprovalHandler | None:
        """Backward-compatible alias for older call sites."""
        return self.handler

    @approval_handler.setter
    def approval_handler(self, value: ApprovalHandler | None) -> None:
        self.handler = value

    def set_approval_handler(self, handler: ApprovalHandler) -> None:
        """Register an approval handler."""
        self.handler = handler

    def to_hook(self) -> "ApprovalManager":
        """Return self; ApprovalManager already implements SessionHooks."""
        return self

    def _skip(self, call: ToolCall, reason: str) -> ToolCall:
        from wormhole_core.schemas.tools import ToolCallStatus

        return ToolCall(
            tool_call_id=call.tool_call_id,
            tool_id=call.tool_id,
            arguments=call.arguments,
            status=ToolCallStatus.SKIPPED,
            result=reason,
        )

    def _build_payload(
        self, *, tool: ToolDefinition, call: ToolCall
    ) -> ApprovalPayload | None:
        """Generate an ApprovalPayload from the tool's generator, with fallback.

        Returns ``None`` when the tool has no ``approval_payload`` callable.
        If the callable raises, a conservative fallback payload is returned
        instead of bypassing approval.

        >>> from wormhole_core.schemas.tools import ToolCall, ToolDefinition
        >>> manager = ApprovalManager()
        >>> tool = ToolDefinition(tool_id="t", name="t", schema={"type": "object"})
        >>> call = ToolCall(tool_call_id="c", tool_id="t", arguments={})
        >>> manager._build_payload(tool=tool, call=call) is None
        True
        """
        if tool.approval_payload is None:
            return None
        try:
            return tool.approval_payload(dict(call.arguments))
        except Exception as exc:
            # Never bypass approval for approval-required tools.
            _log_debug(
                "Approval payload generation failed; using fallback approval payload",
                extra={
                    "event_type": "approval_payload_error",
                    "tool_id": tool.tool_id,
                    "tool_call_id": call.tool_call_id,
                    "error": str(exc),
                },
            )
            return _fallback_payload_for_failed_generation(
                tool_id=tool.tool_id,
                tool_input=dict(call.arguments),
                error=exc,
            )

    async def authorize_tool_call(
        self, *, call: ToolCall, tool: ToolDefinition
    ) -> None:
        """Check approval for a single tool call via ``request()``.

        Raises ``PermissionDeniedError`` if approval is denied or no handler
        is configured.

        >>> import asyncio
        >>> from wormhole_core.schemas.tools import ToolCall, ToolDefinition
        >>> manager = ApprovalManager()
        >>> tool = ToolDefinition(tool_id="t", name="t", schema={"type": "object"})
        >>> call = ToolCall(tool_call_id="c", tool_id="t", arguments={})
        >>> try:
        ...     asyncio.run(manager.authorize_tool_call(call=call, tool=tool))
        ... except Exception as exc:
        ...     "No approval handler" in str(exc)
        True
        """
        payload = self._build_payload(tool=tool, call=call)
        target = _target_from_payload(payload) or "*"
        await self.request(
            tool_id=tool.tool_id,
            target=target,
            session_id=self.session_id,
            tool_call_id=call.tool_call_id,
            input_summary=payload.input_summary if payload else "",
            risk_assessment=payload.risk_assessment if payload else None,
            preview=dict(payload.preview) if payload and payload.preview else None,
            tool_input=dict(call.arguments),
            target_context=(
                dict(payload.target_context)
                if payload and payload.target_context
                else None
            ),
        )

    async def before_tool_execute(
        self, call: ToolCall, tool: ToolDefinition
    ) -> ToolCall | None:
        if not getattr(getattr(tool, "capabilities", None), "approval_required", False):
            return call
        try:
            await self.authorize_tool_call(call=call, tool=tool)
        except PermissionDeniedError as exc:
            return self._skip(call, exc.message)
        return call

    async def after_tool_execute(
        self, call: ToolCall, result: Any, error: Exception | None
    ) -> Any:
        return result

    async def request(
        self,
        tool_id: str,
        target: str,
        *,
        session_id: str | None = None,
        tool_call_id: str | None = None,
        input_summary: str = "",
        risk_assessment: Any = None,
        preview: dict[str, Any] | None = None,
        tool_input: dict[str, Any] | None = None,
        target_context: dict[str, Any] | None = None,
    ) -> None:
        """Request approval for a tool operation (legacy API)."""
        session_id = session_id or self.session_id
        tool_call_id = tool_call_id or f"call-{uuid4().hex[:8]}"

        if tool_id in self.auto_approve_tools:
            _log_debug(
                "Approval bypassed by auto-approve list",
                extra={
                    "event_type": "approval_match",
                    "tool_id": tool_id,
                    "tool_call_id": tool_call_id,
                    "match_outcome": "auto_approved",
                },
            )
            return

        decision = self.permission_cache.check(tool_id, target)

        if decision == PermissionAction.ALLOW:
            _log_debug(
                "Approval cache matched allow rule",
                extra={
                    "event_type": "approval_match",
                    "tool_id": tool_id,
                    "tool_call_id": tool_call_id,
                    "match_outcome": "cached_allow",
                    "target": target,
                },
            )
            return

        if decision == PermissionAction.DENY:
            _log_debug(
                "Approval cache matched deny rule",
                extra={
                    "event_type": "approval_match",
                    "tool_id": tool_id,
                    "tool_call_id": tool_call_id,
                    "match_outcome": "cached_deny",
                    "target": target,
                },
            )
            raise PermissionDeniedError(
                "Permission denied by cached rule.",
                {"tool_id": tool_id, "target": target},
            )

        if self.handler is None:
            _log_debug(
                "Approval required but no handler configured",
                extra={
                    "event_type": "approval_request_routed",
                    "tool_id": tool_id,
                    "tool_call_id": tool_call_id,
                    "match_outcome": "prompted",
                    "routing_channel": "none",
                },
            )
            raise PermissionDeniedError(
                "No approval handler configured.",
                {"tool_id": tool_id, "target": target},
            )

        approval_id = f"approval-{uuid4().hex[:8]}"
        request = ApprovalRequest(
            approval_id=approval_id,
            session_id=session_id,
            tool_id=tool_id,
            tool_call_id=tool_call_id,
            tool_input=tool_input or {},
            input_summary=input_summary,
            risk_assessment=risk_assessment,
            preview=preview,
            target_context=target_context,
            timeout=self.approval_timeout,
        )

        handler_name = getattr(
            self.handler, "__name__", self.handler.__class__.__name__
        )
        _log_debug(
            "Approval request routed to handler",
            extra={
                "event_type": "approval_request_routed",
                "approval_id": approval_id,
                "session_id": request.session_id,
                "tool_id": tool_id,
                "tool_call_id": tool_call_id,
                "match_outcome": "prompted",
                "routing_channel": handler_name,
                "input_summary": request.input_summary,
                "tool_input": request.tool_input,
                "target_context": request.target_context,
            },
        )
        result = self.handler(request)
        if inspect.isawaitable(result):
            try:
                record = await asyncio.wait_for(result, timeout=self.approval_timeout)
            except asyncio.TimeoutError as exc:
                raise PermissionDeniedError(
                    "approval request timed out",
                    {"tool_id": tool_id, "target": target},
                ) from exc
        else:
            record = result

        _log_debug(
            "Approval decision received",
            extra={
                "event_type": "approval_decision",
                "approval_id": approval_id,
                "session_id": request.session_id,
                "tool_id": tool_id,
                "tool_call_id": tool_call_id,
                "decision": record.decision,
                "mode": record.scope,
                "match_outcome": "prompted",
            },
        )
        if record.decision != "allow":
            raise PermissionDeniedError(
                "User denied permission for this operation.",
                {"tool_id": tool_id, "target": target, "reason": record.reason},
            )

        if record.scope == "always":
            cache_target = generalize_target_for_always(tool_id, target)
            self.permission_cache.add_rule(
                PermissionRule(
                    rule_id=f"rule-{uuid4().hex[:8]}",
                    tool_pattern=tool_id,
                    target_pattern=cache_target,
                    action=PermissionAction.ALLOW,
                    scope=PermissionScope.ALWAYS,
                    created_at=time.time(),
                )
            )
            _log_debug(
                "Approval allow_always cached",
                extra={
                    "event_type": "approval_cache_update",
                    "tool_id": tool_id,
                    "tool_call_id": tool_call_id,
                    "mode": "allow_always",
                    "target": cache_target,
                },
            )


def generalize_target_for_always(tool_id: str, target: str) -> str:
    """Generalize a target pattern for 'always' scope caching/display.

    For bash commands with format "cmd * @ /path/*", we keep the command
    prefix and generalize the path. This ensures "always" for "python"
    only approves python commands, not arbitrary commands in that directory.

    For file tools with just a path, we generalize to the parent directory.

    >>> generalize_target_for_always("bash", "python * @ /project/*")
    'python * @ /project/*'
    >>> generalize_target_for_always("bash", "ls * @ /home/user/*")
    'ls * @ /home/user/*'
    >>> generalize_target_for_always("file_write", "/project/src/main.py")
    '/project/src/*'
    >>> generalize_target_for_always("file_read", "/project/README.md")
    '/project/*'
    """
    if tool_id == "bash" and " @ " in target:
        # Bash target format: "command * @ /path/*"
        # Keep command prefix, only the path is already generalized
        # e.g., "python * @ /project/*" stays as-is
        return target
    elif tool_id.startswith("file_"):
        # File tools: generalize to parent directory pattern
        from pathlib import Path

        path = Path(target)
        return f"{path.parent}/*"
    else:
        # Default: return as-is
        return target


def _target_from_payload(payload: ApprovalPayload | None) -> str | None:
    if payload is None:
        return None
    if isinstance(payload.target_context, dict):
        target = payload.target_context.get("target") or payload.target_context.get(
            "path"
        )
        if isinstance(target, str):
            return target
    return None


def resolve_approval_choice(
    choice: str,
    request: ApprovalRequest,
    *,
    user_id: str = "local-user",
) -> ApprovalDecisionRecord:
    """Map a user choice string to an ApprovalDecisionRecord.

    Pure logic — no I/O. UI layers call this after collecting user input.

    Args:
        choice: User choice string (e.g. "y", "yes", "a", "always", "n", "no").
        request: The approval request being decided on.
        user_id: Identifier for the user making the decision.

    Returns:
        ApprovalDecisionRecord with decision, scope, and reason.

    >>> from wormhole_core.schemas.tools import ApprovalRequest
    >>> req = ApprovalRequest(
    ...     approval_id="a1", session_id="s1", tool_id="bash",
    ...     tool_call_id="c1", tool_input={}, input_summary="run ls",
    ... )
    >>> rec = resolve_approval_choice("y", req)
    >>> rec.decision, rec.scope
    ('allow', 'once')
    >>> rec = resolve_approval_choice("a", req)
    >>> rec.decision, rec.scope
    ('allow', 'always')
    >>> rec = resolve_approval_choice("n", req)
    >>> rec.decision, rec.scope, rec.reason
    ('deny', 'once', 'user denied')
    """
    choice = choice.strip().lower()
    decision: Literal["allow", "deny", "pending"]
    scope: Literal["once", "always"] | None
    reason: str | None
    if choice in {"a", "always"}:
        decision = "allow"
        scope = "always"
        reason = None
    elif choice in {"y", "yes"}:
        decision = "allow"
        scope = "once"
        reason = None
    else:
        decision = "deny"
        scope = "once"
        reason = "user denied"

    return ApprovalDecisionRecord(
        approval_id=request.approval_id,
        session_id=request.session_id,
        tool_id=request.tool_id,
        tool_call_id=request.tool_call_id,
        decision=decision,
        user_id=user_id,
        scope=scope,
        timestamp=time.time(),
        reason=reason,
    )


__all__ = [
    "ApprovalHandler",
    "ApprovalManager",
    "generalize_target_for_always",
    "resolve_approval_choice",
]
