"""SDK hook protocols and registry."""

from __future__ import annotations

import inspect
from dataclasses import dataclass, field
from typing import Any

from wormhole_core.schemas.messages import Message
from wormhole_core.schemas.session import CompactionSnapshot
from wormhole_core.schemas.tools import ToolCall, ToolDefinition


class SessionHooks:
    """Base class for SDK hook implementations.

    Subclasses override only the hooks they need. All methods have
    default no-op implementations so partial hooks are valid.
    """

    async def before_tool_execute(
        self, call: ToolCall, tool: ToolDefinition
    ) -> ToolCall | None:
        return call

    async def after_tool_execute(
        self, call: ToolCall, result: Any, error: Exception | None
    ) -> Any:
        return result

    async def on_compaction(
        self, snapshot: CompactionSnapshot, messages: list[Message]
    ) -> CompactionSnapshot:
        return snapshot

    async def transform_system_prompt(
        self, layers: list[str], session_context: dict[str, Any]
    ) -> list[str]:
        return layers

    async def on_session_event(self, event: object) -> None:
        pass


@dataclass
class HookRegistry:
    """Registry for session hooks."""

    _hooks: list[SessionHooks] = field(default_factory=list)

    def add(self, hooks: SessionHooks) -> None:
        self._hooks.append(hooks)

    def remove(self, hooks: SessionHooks) -> None:
        self._hooks.remove(hooks)

    async def run_before_tool_execute(
        self, call: ToolCall, tool: ToolDefinition
    ) -> ToolCall | None:
        current: ToolCall | None = call
        for hook in self._hooks:
            callback = getattr(hook, "before_tool_execute", None)
            if callback is None:
                continue
            result = callback(current, tool)
            if inspect.isawaitable(result):
                result = await result
            if result is None:
                return None
            current = result
        return current

    async def run_after_tool_execute(
        self, call: ToolCall, result: Any, error: Exception | None
    ) -> Any:
        current = result
        for hook in self._hooks:
            callback = getattr(hook, "after_tool_execute", None)
            if callback is None:
                continue
            updated = callback(call, current, error)
            if inspect.isawaitable(updated):
                updated = await updated
            current = updated
        return current

    async def run_on_compaction(
        self, snapshot: CompactionSnapshot, messages: list[Message]
    ) -> CompactionSnapshot:
        current = snapshot
        for hook in self._hooks:
            callback = getattr(hook, "on_compaction", None)
            if callback is None:
                continue
            updated = callback(current, messages)
            if inspect.isawaitable(updated):
                updated = await updated
            current = updated
        return current

    async def run_transform_system_prompt(
        self,
        layers: list[str],
        session_context: dict[str, Any],
    ) -> list[str]:
        current = layers
        for hook in self._hooks:
            callback = getattr(hook, "transform_system_prompt", None)
            if callback is None:
                continue
            updated = callback(current, session_context)
            if inspect.isawaitable(updated):
                updated = await updated
            current = updated
        return current

    async def run_on_session_event(self, event: object) -> None:
        for hook in self._hooks:
            callback = getattr(hook, "on_session_event", None)
            if callback is None:
                continue
            result = callback(event)
            if inspect.isawaitable(result):
                await result


__all__ = ["HookRegistry", "SessionHooks"]
