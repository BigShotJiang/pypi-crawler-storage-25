"""Wormhole SDK public API."""

# Explicit `as X` re-exports so Pyright/Pylance treats them as public symbols.

from wormhole_core.retry import RetryPolicy as RetryPolicy
from wormhole_core.schemas.tools import ToolCapabilities as ToolCapabilities
from wormhole_core.schemas.tools import ToolDefinition as ToolDefinition

from . import errors as errors
from .adapter import AdapterRegistry as AdapterRegistry
from .adapter import FinishReason as FinishReason
from .adapter import ModelAdapter as ModelAdapter
from .adapter import ModelEvent as ModelEvent
from .adapter import ModelEventType as ModelEventType
from .adapter.anthropic import AnthropicAdapter as AnthropicAdapter
from .approval import ApprovalHandler as ApprovalHandler
from .approval import ApprovalManager as ApprovalManager
from .approval import generalize_target_for_always as generalize_target_for_always
from .approval import resolve_approval_choice as resolve_approval_choice
from .client import WormholeClient as WormholeClient
from .config import SDKConfig as SDKConfig
from .deprecation import deprecated as deprecated
from .errors import ToolErrorCode as ToolErrorCode
from .errors import ToolLoadError as ToolLoadError
from .storage import StorageProvider as StorageProvider
from .storage import StorageProviderHook as StorageProviderHook
from .storage import create_default_storage_provider as create_default_storage_provider
from .termination import ContinuationMode as ContinuationMode
from .tool_handlers import create_default_tool_handlers as create_default_tool_handlers
from .tool_loader import TOOL_API_VERSION as TOOL_API_VERSION
from .tool_loader import ToolHandlerContext as ToolHandlerContext
from .tools import TOOL_BASH as TOOL_BASH
from .tools import TOOL_FILE_EDIT as TOOL_FILE_EDIT
from .tools import TOOL_FILE_READ as TOOL_FILE_READ
from .tools import TOOL_FILE_WRITE as TOOL_FILE_WRITE
from .tools import TOOL_TASK as TOOL_TASK
from .tools import create_default_tools as create_default_tools
from .types import StageMessageResult as StageMessageResult

__version__ = "0.1.0"

__all__ = [
    "AdapterRegistry",
    "AnthropicAdapter",
    "ApprovalHandler",
    "ApprovalManager",
    "ContinuationMode",
    "FinishReason",
    "ModelAdapter",
    "ModelEvent",
    "ModelEventType",
    "WormholeClient",
    "RetryPolicy",
    "SDKConfig",
    "StorageProvider",
    "StorageProviderHook",
    "StageMessageResult",
    "ToolCapabilities",
    "ToolDefinition",
    "ToolErrorCode",
    "ToolHandlerContext",
    "ToolLoadError",
    "TOOL_API_VERSION",
    "create_default_storage_provider",
    "create_default_tool_handlers",
    "generalize_target_for_always",
    "resolve_approval_choice",
    "create_default_tools",
    "TOOL_BASH",
    "TOOL_FILE_EDIT",
    "TOOL_FILE_READ",
    "TOOL_FILE_WRITE",
    "TOOL_TASK",
    "deprecated",
    "errors",
]
