"""Yandex Passport authentication flows."""
