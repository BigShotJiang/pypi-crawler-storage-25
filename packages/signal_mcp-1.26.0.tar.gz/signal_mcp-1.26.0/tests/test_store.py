"""Tests for local SQLite message store."""

import pytest
from datetime import datetime
from pathlib import Path

from signal_mcp.models import Message, Attachment
from signal_mcp import store


@pytest.fixture(autouse=True)
def temp_db(tmp_path, monkeypatch):
    """Redirect DB to a temp file and reset init flag for each test."""
    monkeypatch.setattr(store, "DB_PATH", tmp_path / "test_messages.db")
    monkeypatch.setattr(store, "_initialized_paths", set())
    if getattr(store._thread_local, "conn", None) is not None:
        store._thread_local.conn.close()
        store._thread_local.conn = None


def make_msg(id="1", sender="+1", body="hello", group_id=None, recipient=None,
             ts=None):
    return Message(
        id=id,
        sender=sender,
        recipient=recipient,
        body=body,
        timestamp=ts or datetime(2024, 6, 1, 12, 0, 0),
        group_id=group_id,
    )


# ── save / dedup ──────────────────────────────────────────────────────────────

def test_save_and_retrieve():
    msg = make_msg(id="100", sender="+11111", body="test message")
    assert store.save_message(msg) is True
    results = store.get_conversation("+11111")
    assert len(results) == 1
    assert results[0].body == "test message"


def test_duplicate_not_saved():
    msg = make_msg(id="200")
    assert store.save_message(msg) is True
    assert store.save_message(msg) is False
    results = store.get_conversation("+1")
    assert len(results) == 1


def test_outgoing_message_marked_read():
    """Messages saved with recipient (outgoing) should be is_read=1."""
    store.save_message(make_msg(id="out1", sender="+me", recipient="+other"))
    msgs = store.get_conversation("+other")
    assert msgs[0].is_read is True


def test_incoming_message_unread():
    store.save_message(make_msg(id="in1", sender="+other"))
    msgs = store.get_conversation("+other")
    assert msgs[0].is_read is False


# ── get_conversation ──────────────────────────────────────────────────────────

def test_get_conversation_by_sender():
    store.save_message(make_msg(id="100", sender="+2", body="hi"))
    results = store.get_conversation("+2")
    assert len(results) == 1


def test_get_conversation_outgoing_dm_included():
    """Outgoing DMs must appear in the conversation with the recipient."""
    store.save_message(make_msg(id="out1", sender="+me", recipient="+other", body="hey"))
    results = store.get_conversation("+other")
    assert len(results) == 1
    assert results[0].body == "hey"


def test_get_conversation_both_directions():
    store.save_message(make_msg(id="in1", sender="+2", body="yo"))
    store.save_message(make_msg(id="out1", sender="+1", recipient="+2", body="sup"))
    results = store.get_conversation("+2")
    assert len(results) == 2


def test_get_conversation_by_group():
    msg = make_msg(id="300", sender="+2", group_id="group-abc")
    store.save_message(msg)
    results = store.get_conversation("group-abc")
    assert len(results) == 1
    assert results[0].group_id == "group-abc"


def test_conversation_limit():
    for i in range(10):
        store.save_message(make_msg(id=str(800 + i), sender="+4", body=f"msg {i}",
                                   ts=datetime(2024, 1, i + 1)))
    results = store.get_conversation("+4", limit=5)
    assert len(results) == 5


def test_get_conversation_since():
    cutoff = datetime(2024, 6, 1)
    store.save_message(make_msg(id="old", sender="+2", ts=datetime(2024, 1, 1)))
    store.save_message(make_msg(id="new", sender="+2", ts=datetime(2024, 7, 1)))
    results = store.get_conversation("+2", since=cutoff)
    assert len(results) == 1
    assert results[0].id == "new"


def test_get_conversation_oldest_first():
    store.save_message(make_msg(id="m1", sender="+2", ts=datetime(2024, 1, 1)))
    store.save_message(make_msg(id="m2", sender="+2", ts=datetime(2024, 1, 2)))
    msgs = store.get_conversation("+2")
    assert msgs[0].id == "m1"
    assert msgs[1].id == "m2"


# ── search_messages ───────────────────────────────────────────────────────────

def test_search_messages():
    store.save_message(make_msg(id="400", body="hello world"))
    store.save_message(make_msg(id="401", body="goodbye moon"))
    results = store.search_messages("hello")
    assert len(results) == 1
    assert results[0].body == "hello world"


def test_search_no_results():
    store.save_message(make_msg(id="500", body="nothing here"))
    results = store.search_messages("xyz")
    assert results == []


def test_search_special_chars_dont_crash():
    store.save_message(make_msg(id="501", body="call +491234567890 tomorrow"))
    for query in ["+491234567890", "OR", "AND NOT", "hello AND"]:
        results = store.search_messages(query)
        assert isinstance(results, list)


# ── get_unread_messages ───────────────────────────────────────────────────────

def test_get_unread_returns_incoming():
    store.save_message(make_msg(id="in1", sender="+2", body="unread"))
    msgs = store.get_unread_messages(own_number="+1")
    assert len(msgs) == 1


def test_get_unread_excludes_own_sent():
    store.save_message(make_msg(id="out1", sender="+1", recipient="+2"))
    assert store.get_unread_messages(own_number="+1") == []


def test_get_unread_excludes_already_read():
    store.save_message(make_msg(id="in1", sender="+2"))
    store.mark_as_read(["in1"])
    assert store.get_unread_messages(own_number="+1") == []


# ── mark_as_read ──────────────────────────────────────────────────────────────

def test_mark_as_read():
    store.save_message(make_msg(id="in1", sender="+2"))
    store.mark_as_read(["in1"])
    assert store.get_unread_messages(own_number="+1") == []


def test_mark_as_read_empty_list_no_error():
    store.mark_as_read([])


# ── attachments ───────────────────────────────────────────────────────────────

def test_save_with_attachment():
    msg = Message(
        id="600",
        sender="+3",
        body="check this out",
        timestamp=datetime(2024, 6, 1),
        attachments=[Attachment(content_type="image/jpeg", filename="photo.jpg", size=12345)],
    )
    store.save_message(msg)
    results = store.get_conversation("+3")
    assert len(results[0].attachments) == 1
    assert results[0].attachments[0].filename == "photo.jpg"


# ── list_conversations ────────────────────────────────────────────────────────

def test_list_conversations_empty():
    assert store.list_conversations() == []


def test_list_conversations_direct():
    store.save_message(make_msg(id="900", sender="+5", body="hello"))
    store.save_message(make_msg(id="901", sender="+6", body="hi"))
    results = store.list_conversations()
    ids = [r["id"] for r in results]
    assert "+5" in ids
    assert "+6" in ids
    assert all(r["type"] == "direct" for r in results)


def test_list_conversations_outgoing_dm_appears():
    """Outgoing DMs must create a conversation entry."""
    store.save_message(make_msg(id="out1", sender="+me", recipient="+other"))
    results = store.list_conversations(own_number="+me")
    assert len(results) == 1
    assert results[0]["id"] == "+other"


def test_list_conversations_group():
    store.save_message(make_msg(id="910", sender="+7", group_id="grp-1"))
    store.save_message(make_msg(id="911", sender="+8", group_id="grp-1"))
    results = store.list_conversations()
    groups = [r for r in results if r["type"] == "group"]
    assert len(groups) == 1
    assert groups[0]["id"] == "grp-1"
    assert groups[0]["message_count"] == 2


def test_list_conversations_excludes_own_number():
    store.save_message(make_msg(id="920", sender="+me", body="I sent this"))
    store.save_message(make_msg(id="921", sender="+other", body="they replied"))
    results = store.list_conversations(own_number="+me")
    ids = [r["id"] for r in results]
    assert "+me" not in ids
    assert "+other" in ids


def test_list_conversations_ordered_by_recency():
    store.save_message(Message(id="930", sender="+a", body="old",
                               timestamp=datetime(2024, 1, 1)))
    store.save_message(Message(id="931", sender="+b", body="new",
                               timestamp=datetime(2024, 6, 1)))
    results = store.list_conversations()
    ids = [r["id"] for r in results]
    assert ids.index("+b") < ids.index("+a")


def test_list_conversations_deduped():
    store.save_message(make_msg(id="m1", sender="+2", ts=datetime(2024, 1, 1)))
    store.save_message(make_msg(id="m2", sender="+2", ts=datetime(2024, 1, 2)))
    results = store.list_conversations()
    assert len(results) == 1
    assert results[0]["message_count"] == 2


def test_list_conversations_unread_count():
    # 2 unread from +2, 1 read
    store.save_message(Message(id="u1", sender="+2", body="a", timestamp=datetime(2024, 1, 1), is_read=False))
    store.save_message(Message(id="u2", sender="+2", body="b", timestamp=datetime(2024, 1, 2), is_read=False))
    store.save_message(Message(id="u3", sender="+2", body="c", timestamp=datetime(2024, 1, 3), is_read=True))
    results = store.list_conversations()
    assert results[0]["unread_count"] == 2


def test_list_conversations_unread_count_excludes_own_sent():
    # Outgoing messages should not count as unread
    store.save_message(make_msg(id="out1", sender="+me", recipient="+other"))
    results = store.list_conversations(own_number="+me")
    assert results[0]["unread_count"] == 0


def test_list_conversations_last_message():
    store.save_message(Message(id="lm1", sender="+3", body="first", timestamp=datetime(2024, 1, 1)))
    store.save_message(Message(id="lm2", sender="+3", body="last one", timestamp=datetime(2024, 1, 2)))
    results = store.list_conversations()
    assert results[0]["last_message"] == "last one"


# ── get_stats ─────────────────────────────────────────────────────────────────

def test_get_stats_empty():
    stats = store.get_stats()
    assert stats["total_messages"] == 0
    assert stats["unread_messages"] == 0
    assert stats["oldest"] is None
    assert "db_size_bytes" in stats


def test_get_stats_with_data():
    store.save_message(make_msg(id="700"))
    stats = store.get_stats()
    assert stats["total_messages"] == 1
    assert stats["oldest"] is not None
    assert stats["newest"] is not None


def test_get_stats_unread_count():
    # Incoming (no recipient) → unread; outgoing (recipient set) → read
    store.save_message(make_msg(id="u_in",  sender="+1", recipient=None))
    store.save_message(make_msg(id="u_out", sender="+1", recipient="+2"))
    stats = store.get_stats()
    assert stats["unread_messages"] == 1


# ── init_db migration ─────────────────────────────────────────────────────────

def test_init_db_idempotent():
    """Calling init_db twice must not raise."""
    store.init_db()
    store.init_db()


def test_migration_adds_recipient_column(tmp_path, monkeypatch):
    """Simulate upgrading from pre-1.1 schema (no recipient column)."""
    import sqlite3
    db_path = tmp_path / "old.db"
    monkeypatch.setattr(store, "DB_PATH", db_path)
    monkeypatch.setattr(store, "_initialized_paths", set())
    if getattr(store._thread_local, "conn", None) is not None:
        store._thread_local.conn.close()
        store._thread_local.conn = None

    # Create old-style schema without recipient column
    conn = sqlite3.connect(str(db_path))
    conn.execute("""CREATE TABLE messages (
        id TEXT PRIMARY KEY, sender TEXT NOT NULL, body TEXT NOT NULL DEFAULT '',
        timestamp INTEGER NOT NULL, group_id TEXT, quote_id TEXT, is_read INTEGER NOT NULL DEFAULT 0
    )""")
    conn.execute("INSERT INTO messages VALUES ('m1','+1','hi',1700000000000,NULL,NULL,0)")
    conn.commit()
    conn.close()

    # init_db should run migration without error
    monkeypatch.setattr(store, "_initialized_paths", set())
    if getattr(store._thread_local, "conn", None) is not None:
        store._thread_local.conn.close()
        store._thread_local.conn = None
    store.init_db()

    # Old data still readable
    msgs = store.get_conversation("+1")
    assert len(msgs) == 1


# ── update_message_body ───────────────────────────────────────────────────────

def test_update_message_body_changes_body():
    ts = datetime(2024, 6, 1, 12, 0, 0)
    ts_ms = int(ts.timestamp() * 1000)
    store.save_message(make_msg(id="edit1", sender="+1", body="original", ts=ts))
    store.update_message_body(ts_ms, "edited")
    msgs = store.get_conversation("+1")
    assert msgs[0].body == "edited"


def test_update_message_body_noop_on_unknown_ts():
    # Should not raise even if timestamp doesn't match any message
    store.update_message_body(9999999999999, "ghost")


def test_update_message_body_syncs_fts():
    ts = datetime(2024, 6, 1, 12, 0, 0)
    ts_ms = int(ts.timestamp() * 1000)
    store.save_message(make_msg(id="fts1", sender="+1", body="findme original", ts=ts))
    store.update_message_body(ts_ms, "findme edited")
    # FTS should find new text, not old
    results = store.search_messages("edited")
    assert len(results) == 1
    assert results[0].body == "findme edited"
    results_old = store.search_messages("original")
    assert results_old == []


# ── search_messages sender filter ────────────────────────────────────────────

def test_search_messages_sender_filter():
    store.save_message(make_msg(id="sf1", sender="+1", body="hello from one"))
    store.save_message(make_msg(id="sf2", sender="+2", body="hello from two"))
    results = store.search_messages("hello", sender="+1")
    assert len(results) == 1
    assert results[0].sender == "+1"


def test_search_messages_sender_filter_no_match():
    store.save_message(make_msg(id="sf3", sender="+1", body="hello"))
    results = store.search_messages("hello", sender="+9")
    assert results == []


def test_search_messages_sender_none_returns_all():
    store.save_message(make_msg(id="sf4", sender="+1", body="hello"))
    store.save_message(make_msg(id="sf5", sender="+2", body="hello"))
    results = store.search_messages("hello")
    assert len(results) == 2


def test_search_messages_like_fallback_sender_filter(monkeypatch):
    """LIKE fallback must use unaliased column name (no 'm.sender') when sender is given.

    Simulate FTS failure by making _safe_fts_query return a string that causes a
    parse error in FTS5 — this forces the LIKE fallback branch.
    """
    import signal_mcp.store as store_mod
    store.save_message(make_msg(id="fb1", sender="+1", body="fallback hello"))
    store.save_message(make_msg(id="fb2", sender="+2", body="fallback hello"))
    # Force the FTS branch to throw by injecting a broken query string
    original = store_mod._safe_fts_query
    monkeypatch.setattr(store_mod, "_safe_fts_query", lambda q: "INVALID FTS SYNTAX !!!@#")
    results = store.search_messages("fallback", sender="+1")
    monkeypatch.setattr(store_mod, "_safe_fts_query", original)
    assert len(results) == 1
    assert results[0].sender == "+1"


def test_search_messages_like_fallback_wildcard_literal(monkeypatch):
    """LIKE fallback must escape % and _ so they match literally."""
    import signal_mcp.store as store_mod
    store.save_message(make_msg(id="wc1", sender="+1", body="price 100% off"))
    store.save_message(make_msg(id="wc2", sender="+1", body="price 100x off"))
    monkeypatch.setattr(store_mod, "_safe_fts_query", lambda q: "INVALID FTS SYNTAX !!!@#")
    results = store.search_messages("100%", sender=None)
    monkeypatch.setattr(store_mod, "_safe_fts_query", store_mod._safe_fts_query)
    # "100%" should only match the message with literal "%"
    assert len(results) == 1
    assert results[0].id == "wc1"


# ── export_messages ───────────────────────────────────────────────────────────

def test_export_messages_json_all():
    import json
    store.save_message(make_msg(id="ex1", sender="+1", body="exported"))
    data = store.export_messages(fmt="json")
    parsed = json.loads(data)
    assert len(parsed) == 1
    assert parsed[0]["body"] == "exported"
    assert parsed[0]["sender"] == "+1"


def test_export_messages_csv_all():
    store.save_message(make_msg(id="ex2", sender="+1", body="csv export"))
    data = store.export_messages(fmt="csv")
    assert "csv export" in data
    assert "id,timestamp,sender" in data


def test_export_messages_filter_recipient():
    import json
    store.save_message(make_msg(id="ex3", sender="+1", body="msg from 1"))
    store.save_message(make_msg(id="ex4", sender="+2", body="msg from 2"))
    data = store.export_messages(fmt="json", recipient="+1")
    parsed = json.loads(data)
    assert len(parsed) == 1
    assert parsed[0]["sender"] == "+1"


def test_export_messages_filter_since():
    import json
    ts_early = datetime(2024, 1, 1, 0, 0, 0)
    ts_late = datetime(2024, 6, 1, 0, 0, 0)
    store.save_message(make_msg(id="ex5", sender="+1", body="early", ts=ts_early))
    store.save_message(make_msg(id="ex6", sender="+1", body="late", ts=ts_late))
    data = store.export_messages(fmt="json", since=datetime(2024, 3, 1))
    parsed = json.loads(data)
    assert len(parsed) == 1
    assert parsed[0]["body"] == "late"


def test_export_messages_empty_store():
    import json
    data = store.export_messages(fmt="json")
    assert json.loads(data) == []


# ── count_conversation ────────────────────────────────────────────────────────

def test_count_conversation_direct():
    store.save_message(make_msg(id="cc1", sender="+1"))
    store.save_message(make_msg(id="cc2", sender="+1"))
    assert store.count_conversation("+1") == 2


def test_count_conversation_no_match():
    store.save_message(make_msg(id="cc3", sender="+1"))
    assert store.count_conversation("+99") == 0


def test_count_conversation_since():
    ts_old = datetime(2024, 1, 1)
    ts_new = datetime(2024, 6, 1)
    store.save_message(make_msg(id="cc4", sender="+1", ts=ts_old))
    store.save_message(make_msg(id="cc5", sender="+1", ts=ts_new))
    assert store.count_conversation("+1", since=datetime(2024, 3, 1)) == 1


def test_count_conversation_group():
    store.save_message(make_msg(id="cc6", sender="+1", group_id="g1"))
    store.save_message(make_msg(id="cc7", sender="+2", group_id="g1"))
    assert store.count_conversation("g1") == 2


# ── search_messages offset ────────────────────────────────────────────────────

def test_search_messages_offset():
    store.save_message(make_msg(id="o1", sender="+1", body="needle first"))
    store.save_message(make_msg(id="o2", sender="+1", body="needle second",
                                ts=datetime(2024, 6, 1, 11, 0, 0)))
    all_results = store.search_messages("needle", limit=10)
    assert len(all_results) == 2
    offset_results = store.search_messages("needle", limit=10, offset=1)
    assert len(offset_results) == 1
    # With offset=0 should equal all
    assert store.search_messages("needle", limit=10, offset=0) == all_results


def test_search_messages_offset_beyond_end():
    store.save_message(make_msg(id="o3", sender="+1", body="thing"))
    assert store.search_messages("thing", limit=10, offset=99) == []


# ── mark_as_unread ────────────────────────────────────────────────────────────

def test_mark_as_unread():
    store.save_message(make_msg(id="u1", sender="+1"))
    store.mark_as_read(["u1"])
    msgs = store.search_messages("hello")
    assert msgs[0].is_read is True
    store.mark_as_unread(["u1"])
    msgs = store.search_messages("hello")
    assert msgs[0].is_read is False


def test_mark_as_unread_noop_empty():
    store.init_db()
    store.mark_as_unread([])  # should not raise


# ── prune_old_messages ────────────────────────────────────────────────────────

def test_prune_removes_old_messages():
    from datetime import timedelta
    now_ms = int(datetime.now().timestamp() * 1000)
    old_ms = int((datetime.now() - timedelta(days=200)).timestamp() * 1000)

    # Save one old and one recent message
    old = make_msg(id="old1", sender="+1", body="old message")
    old.timestamp = datetime.fromtimestamp(old_ms / 1000)
    recent = make_msg(id="new1", sender="+1", body="recent message")
    recent.timestamp = datetime.fromtimestamp(now_ms / 1000)
    store.save_message(old)
    store.save_message(recent)

    deleted = store.prune_old_messages(days=180)
    assert deleted == 1

    remaining = store.search_messages("message")
    assert len(remaining) == 1
    assert remaining[0].id == "new1"


def test_prune_returns_zero_when_nothing_old():
    from datetime import timedelta
    # Use a timestamp from today — should survive a 180-day prune
    now_ms = int(datetime.now().timestamp() * 1000)
    recent = make_msg(id="fresh1", sender="+1", body="fresh")
    recent.timestamp = datetime.fromtimestamp(now_ms / 1000)
    store.save_message(recent)
    deleted = store.prune_old_messages(days=180)
    assert deleted == 0


def test_prune_rejects_invalid_days():
    import pytest
    with pytest.raises(ValueError):
        store.prune_old_messages(days=0)
    with pytest.raises(ValueError):
        store.prune_old_messages(days=-5)


# ── Bug-fix regression tests ──────────────────────────────────────────────────

# Bug 1: outgoing group messages were stored as is_read=0
def test_save_group_message_with_is_read_true():
    """Outgoing group messages saved with is_read=True must not appear as unread."""
    from signal_mcp.models import Message
    msg = Message(
        id="grp_sent_1",
        sender="+10000000000",
        body="hello group",
        timestamp=datetime(2024, 6, 1, 12, 0, 0),
        group_id="group==abc",
        is_read=True,
    )
    store.save_message(msg)
    unread = store.get_unread_messages(own_number="+10000000000")
    assert unread == [], "Outgoing group messages must not appear as unread"


def test_save_incoming_group_message_is_unread():
    """Incoming group messages (sender != own) must start as unread."""
    msg = Message(
        id="grp_in_1",
        sender="+12223334444",
        body="from a friend",
        timestamp=datetime(2024, 6, 1, 12, 0, 0),
        group_id="group==abc",
        is_read=False,
    )
    store.save_message(msg)
    unread = store.get_unread_messages(own_number="+10000000000")
    assert len(unread) == 1


# Bug 3: update_message_body matched by timestamp — non-unique, could corrupt sibling
def test_update_message_body_with_sender_is_unique():
    """update_message_body with sender must only update the matching message."""
    ts = datetime(2024, 6, 1, 12, 0, 0)
    ts_ms = int(ts.timestamp() * 1000)
    # Two messages with identical millisecond timestamps (different senders)
    store.save_message(make_msg(id="dup_a", sender="+1", body="original A", ts=ts))
    store.save_message(make_msg(id="dup_b", sender="+2", body="original B", ts=ts))
    store.update_message_body(ts_ms, "edited A", sender="+1")
    msgs = store.get_conversation("+1")
    assert msgs[0].body == "edited A"
    msgs_b = store.get_conversation("+2")
    assert msgs_b[0].body == "original B", "Sibling message must not be touched"


def test_update_message_body_uses_id_not_timestamp():
    """After edit, WHERE id = ? means only the single matched row changes."""
    ts = datetime(2024, 6, 1, 12, 0, 0)
    ts_ms = int(ts.timestamp() * 1000)
    store.save_message(make_msg(id="edit_uniq", sender="+1", body="before", ts=ts))
    store.update_message_body(ts_ms, "after")
    msgs = store.get_conversation("+1")
    assert msgs[0].body == "after"


# Bug 4: get_stats unread count was inconsistent with get_unread_messages
def test_get_stats_unread_uses_own_number():
    """get_stats unread count must match get_unread_messages when own_number is provided."""
    own = "+10000000000"
    # Outgoing: sender=own — should NOT count as unread
    store.save_message(make_msg(id="sent1", sender=own, recipient="+2"))
    # Incoming direct: sender=other, recipient=None
    store.save_message(make_msg(id="recv1", sender="+2", recipient=None))
    # Incoming group: sender=other, group_id set
    store.save_message(make_msg(id="grp1", sender="+2", group_id="g==1"))

    stats = store.get_stats(own_number=own)
    unread_list = store.get_unread_messages(own_number=own)
    assert stats["unread_messages"] == len(unread_list), (
        "get_stats unread count must match get_unread_messages count"
    )
    assert stats["unread_messages"] == 2  # recv1 + grp1


def test_get_stats_own_sent_group_not_counted():
    """After fix: outgoing group messages stored with is_read=True don't inflate unread."""
    from signal_mcp.models import Message
    own = "+10000000000"
    msg = Message(
        id="my_grp_msg",
        sender=own,
        body="my group post",
        timestamp=datetime(2024, 6, 1),
        group_id="g==1",
        is_read=True,
    )
    store.save_message(msg)
    stats = store.get_stats(own_number=own)
    assert stats["unread_messages"] == 0


# Bug 7: search_messages("") returned ALL messages via LIKE %%
def test_search_messages_empty_query_returns_nothing():
    """Empty search query must return [] rather than all messages."""
    store.save_message(make_msg(id="s1", sender="+1", body="hello"))
    store.save_message(make_msg(id="s2", sender="+2", body="world"))
    assert store.search_messages("") == []
    assert store.search_messages("   ") == []


# Bug 8: mark_as_read/mark_as_unread overflowed SQLite 999-variable limit
def test_mark_as_read_large_batch():
    """mark_as_read must handle > 500 IDs without SQLite variable overflow."""
    ids = [f"bulk_{i}" for i in range(600)]
    for mid in ids:
        store.save_message(make_msg(id=mid, sender="+1", body="bulk"))
    store.mark_as_read(ids)
    unread = store.get_unread_messages(own_number="+99")  # own_number not in senders
    assert unread == []


def test_mark_as_unread_large_batch():
    """mark_as_unread must handle > 500 IDs without SQLite variable overflow."""
    ids = [f"ubulk_{i}" for i in range(600)]
    for mid in ids:
        store.save_message(make_msg(id=mid, sender="+1", body="bulk"))
    # Mark all read first
    store.mark_as_read(ids)
    # Now unmark
    store.mark_as_unread(ids)
    unread = store.get_unread_messages(own_number="+99", limit=700)
    assert len(unread) == 600


# ── delete_conversation_messages / FTS consistency ────────────────────────────

def test_delete_conversation_messages_removes_from_fts():
    """After delete_conversation_messages, FTS must not return deleted content."""
    store.save_message(make_msg(id="del1", sender="+1", body="findme gone"))
    store.save_message(make_msg(id="del2", sender="+2", body="findme stays"))
    # Verify both searchable before deletion
    assert len(store.search_messages("findme")) == 2
    store.delete_conversation_messages("+1")
    results = store.search_messages("findme")
    assert len(results) == 1
    assert results[0].id == "del2"


def test_delete_conversation_messages_returns_count():
    store.save_message(make_msg(id="dc1", sender="+1", body="a"))
    store.save_message(make_msg(id="dc2", sender="+1", body="b"))
    store.save_message(make_msg(id="dc3", sender="+2", body="c"))
    count = store.delete_conversation_messages("+1")
    assert count == 2
    assert len(store.get_conversation("+1")) == 0
    assert len(store.get_conversation("+2")) == 1


def test_delete_conversation_messages_group():
    """delete_conversation_messages with a group_id removes all group messages."""
    store.save_message(make_msg(id="gd1", sender="+1", group_id="grp==X", body="group msg"))
    store.save_message(make_msg(id="gd2", sender="+2", group_id="grp==X", body="group msg 2"))
    store.save_message(make_msg(id="gd3", sender="+1", body="direct msg"))  # different conv
    count = store.delete_conversation_messages("grp==X")
    assert count == 2
    assert store.get_conversation("grp==X") == []
    assert len(store.get_conversation("+1")) == 1


def test_delete_conversation_messages_no_match_returns_zero():
    count = store.delete_conversation_messages("+nobody")
    assert count == 0


# ── _initialized_paths — path-keyed init flag ────────────────────────────────

def test_init_db_reinitializes_after_path_change(tmp_path, monkeypatch):
    """init_db must fully initialize a new DB when DB_PATH changes."""
    db_a = tmp_path / "a.db"
    db_b = tmp_path / "b.db"
    # Init with path A
    monkeypatch.setattr(store, "DB_PATH", db_a)
    monkeypatch.setattr(store, "_initialized_paths", set())
    if getattr(store._thread_local, "conn", None):
        store._thread_local.conn.close()
        store._thread_local.conn = None
    store.init_db()
    store.save_message(make_msg(id="a1", sender="+1", body="in A"))
    # Switch to path B
    monkeypatch.setattr(store, "DB_PATH", db_b)
    if getattr(store._thread_local, "conn", None):
        store._thread_local.conn.close()
        store._thread_local.conn = None
    store.init_db()  # must initialize B, not skip because A was done
    # B must be empty
    assert store.get_conversation("+1") == []
    # A still has the message
    monkeypatch.setattr(store, "DB_PATH", db_a)
    if getattr(store._thread_local, "conn", None):
        store._thread_local.conn.close()
        store._thread_local.conn = None
    assert len(store.get_conversation("+1")) == 1
