from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ("endoreg_db", "0035_videostate_processing_error"),
    ]

    operations = [
        migrations.AddField(
            model_name="anonymizationvalidationmetric",
            name="missing_sensitive_meta_deletion_count",
            field=models.PositiveIntegerField(default=0),
        ),
        migrations.AddField(
            model_name="anonymizationvalidationmetric",
            name="phi_region_false_negative_count",
            field=models.PositiveIntegerField(default=0),
        ),
        migrations.AddField(
            model_name="anonymizationvalidationmetric",
            name="raw_artifact_residual_count",
            field=models.PositiveIntegerField(default=0),
        ),
        migrations.AddField(
            model_name="anonymizationvalidationmetric",
            name="residual_ocr_match_count",
            field=models.PositiveIntegerField(default=0),
        ),
        migrations.AddField(
            model_name="anonymizationvalidationmetric",
            name="residual_phi_detected",
            field=models.BooleanField(default=False),
        ),
        migrations.AddField(
            model_name="anonymizationvalidationmetric",
            name="sensitive_meta_deletion_status",
            field=models.CharField(blank=True, default="", max_length=64),
        ),
        migrations.AddField(
            model_name="anonymizationvalidationmetric",
            name="sensitive_meta_policy",
            field=models.CharField(blank=True, default="", max_length=64),
        ),
        migrations.AddField(
            model_name="sensitivemeta",
            name="direct_identifier_policy",
            field=models.CharField(blank=True, default="", max_length=64),
        ),
        migrations.AddField(
            model_name="sensitivemeta",
            name="direct_identifier_tombstone",
            field=models.JSONField(blank=True, default=dict),
        ),
        migrations.AddField(
            model_name="sensitivemeta",
            name="direct_identifiers_cleared_at",
            field=models.DateTimeField(blank=True, null=True),
        ),
    ]
