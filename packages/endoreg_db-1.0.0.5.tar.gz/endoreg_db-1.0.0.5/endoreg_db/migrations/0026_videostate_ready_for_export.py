from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ("endoreg_db", "0025_alter_rawpdffile_file_and_more"),
    ]

    operations = [
        migrations.AddField(
            model_name="videostate",
            name="outside_segments_removed",
            field=models.BooleanField(
                default=False,
                help_text=(
                    "True if outside-labelled segments have been removed or "
                    "blackened in the managed processed artifact."
                ),
            ),
        ),
        migrations.AddField(
            model_name="videostate",
            name="ready_for_export",
            field=models.BooleanField(
                default=False,
                help_text=(
                    "True if the managed processed artifact passed explicit "
                    "clinical ready-for-export validation."
                ),
            ),
        ),
        migrations.AddField(
            model_name="videostate",
            name="ready_for_export_at",
            field=models.DateTimeField(
                blank=True,
                help_text=("Server-side timestamp for the ready-for-export promotion."),
                null=True,
            ),
        ),
        migrations.AddField(
            model_name="videostate",
            name="ready_for_export_by",
            field=models.CharField(
                blank=True,
                default="",
                help_text=("Authenticated user or service that promoted this video."),
                max_length=255,
            ),
        ),
        migrations.AddField(
            model_name="videostate",
            name="processed_file_sha256",
            field=models.CharField(
                blank=True,
                default="",
                help_text=(
                    "SHA-256 digest of the processed artifact at promotion time."
                ),
                max_length=64,
            ),
        ),
    ]
