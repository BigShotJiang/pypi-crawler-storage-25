"""Frame-oriented service helpers."""
