"""Application settings service helpers."""
