"""通过 SAP GUI Scripting API 自动登录 SAP 系统

前提：SAP Logon 已打开，且已双击系统条目进入登录界面
"""
import sys
import os
import time
sys.path.insert(0, os.path.dirname(__file__))

import win32com.client

print("=" * 50)
print("  SAP GUI 自动登录")
print("=" * 50)

# Step 1: 连接 SAP GUI
print("\n1. 连接 SAP GUI...")
try:
    sap_gui = win32com.client.GetObject("SAPGUI")
    application = sap_gui.GetScriptingEngine
    print(f"   ✅ 连接成功，活动连接数: {application.Children.Count}")
except Exception as e:
    print(f"   ❌ 连接失败: {e}")
    sys.exit(1)

if application.Children.Count == 0:
    print("   ❌ 没有活动连接，请先双击 SAP Logon 中的系统条目")
    sys.exit(1)

# Step 2: 获取 session
print("\n2. 获取 session...")
try:
    connection = application.Children(0)
    session = connection.Children(0)
    print(f"   ✅ 获取到 session")
except Exception as e:
    print(f"   ❌ 获取 session 失败: {e}")
    sys.exit(1)

# Step 3: 检查当前界面状态
print("\n3. 检查界面状态...")
try:
    window_title = session.findById("wnd[0]").Text
    print(f"   窗口标题: {window_title}")
except Exception as e:
    print(f"   窗口标题读取失败: {e}")
    window_title = ""

# Step 4: 尝试登录
print("\n4. 执行登录...")

# 检查是否在登录界面（通常有 Client/User/Password 字段）
try:
    # 尝试填写客户端
    try:
        client_field = session.findById("wnd[0]/usr/txtRSYST-MANDT")
        client_field.text = "100"
        print("   ✅ 客户端: 100")
    except Exception:
        print("   ⚠️ 客户端字段未找到（可能已预填）")

    # 填写用户名
    try:
        user_field = session.findById("wnd[0]/usr/txtRSYST-BNAME")
        user_field.text = "ZHOUXINYIN"
        print("   ✅ 用户名: ZHOUXINYIN")
    except Exception as e:
        print(f"   ⚠️ 用户名字段未找到: {e}")

    # 填写密码
    try:
        pwd_field = session.findById("wnd[0]/usr/pwdRSYST-BCODE")
        pwd_field.text = "Ssrw2102!!"
        print("   ✅ 密码: ********")
    except Exception as e:
        print(f"   ⚠️ 密码字段未找到: {e}")

    # 填写语言（可选）
    try:
        lang_field = session.findById("wnd[0]/usr/txtRSYST-LANGU")
        lang_field.text = "ZH"
        print("   ✅ 语言: ZH")
    except Exception:
        print("   ⚠️ 语言字段未找到（使用默认）")

    # 按回车登录
    print("\n   按回车登录...")
    session.findById("wnd[0]").sendVKey(0)
    time.sleep(3)  # 等待登录响应

    # 检查是否有弹窗（如多重登录警告）
    try:
        dialog = session.findById("wnd[1]")
        dialog_text = ""
        try:
            dialog_text = dialog.Text
        except:
            pass
        print(f"   ⚠️ 检测到弹窗: {dialog_text}")
        # 点击确认（通常是"继续"按钮）
        try:
            session.findById("wnd[1]/tbar[0]/btn[0]").press()
            print("   ✅ 已确认弹窗")
            time.sleep(2)
        except:
            pass
    except:
        pass  # 没有弹窗，正常

    # Step 5: 验证登录结果
    print("\n5. 验证登录结果...")
    try:
        sys_name = session.Info.SystemName
        client = session.Info.Client
        user = session.Info.User
        lang = session.Info.Language
        print(f"   ✅ 登录成功！")
        print(f"   系统: {sys_name}")
        print(f"   客户端: {client}")
        print(f"   用户: {user}")
        print(f"   语言: {lang}")

        # 读取状态栏
        try:
            sbar = session.findById("wnd[0]/sbar")
            if sbar.Text:
                print(f"   状态栏: [{sbar.MessageType}] {sbar.Text}")
        except:
            pass

        # 读取窗口标题
        try:
            title = session.findById("wnd[0]").Text
            print(f"   窗口标题: {title}")
        except:
            pass

    except Exception as e:
        print(f"   ❌ 登录验证失败: {e}")
        # 检查状态栏错误
        try:
            sbar = session.findById("wnd[0]/sbar")
            if sbar.Text:
                print(f"   状态栏: [{sbar.MessageType}] {sbar.Text}")
        except:
            pass

except Exception as e:
    print(f"   ❌ 登录过程异常: {e}")
    import traceback
    traceback.print_exc()

print("\n" + "=" * 50)
print("  登录测试完成")
print("=" * 50)
