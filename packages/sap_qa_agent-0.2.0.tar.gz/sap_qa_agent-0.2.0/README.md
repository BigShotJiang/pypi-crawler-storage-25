# SAP QA Agent

基于 AI 驱动的 SAP GUI 自动化测试引擎，支持测试用例解析、智能执行、AI 自愈和操作录制。

## 快速开始

```bash
# 安装
pip install sap-qa-agent

# 启动 FastAPI 后端（配合 Vue 前端使用）
sap-qa-backend

# 或启动 MCP Server（配合 Claude Desktop / Kiro / Cursor 使用）
uvx --from sap-qa-agent sap-qa-mcp
```

## 核心功能

- **测试用例解析** — 支持 Excel (.xlsx) 和 Markdown 格式
- **SAP GUI 自动化** — 基于 COM Scripting API 驱动 SAP 操作
- **AI 自愈** — 执行失败时自动分析并修复（基于智谱 GLM）
- **知识库复用** — 积累脚本模板，加速后续执行
- **操作录制** — 记录手动操作转化为可复用步骤

## 两种使用方式

### 1. Web 界面（FastAPI + Vue）

```bash
pip install sap-qa-agent[backend]
sap-qa-backend
# 访问 http://localhost:8000
```

### 2. 作为 MCP Server 被使用

SAP QA Agent 可作为 MCP (Model Context Protocol) Server，被 Claude Desktop、Kiro、Cursor 等 AI Agent 直接调用。

```bash
pip install sap-qa-agent
uvx --from sap-qa-agent sap-qa-mcp
```

详细接入指南请参阅 **[docs/mcp-integration.md](docs/mcp-integration.md)**，包含：

- Claude Desktop / Kiro / Cursor 三种宿主的配置示例
- SAP Scripting 启用步骤
- GLM API Key 配置方式
- 端到端使用示例
- 可用工具列表与故障排查

## 项目结构

```
ui_test_python/
├── app/                    # 应用代码
│   ├── main.py             # FastAPI 入口
│   ├── mcp_server/         # MCP Server 实现
│   ├── core/               # 核心引擎（解析、执行、自愈）
│   ├── sap/                # SAP GUI 封装
│   ├── ai/                 # GLM AI 客户端
│   └── data/               # 数据模型与知识库
├── mcp_skills/             # MCP Skills 包
├── knowledge_base/         # 脚本模板知识库
├── tests/                  # 测试套件
├── examples/mcp/           # MCP 配置示例
├── docs/                   # 文档
│   └── mcp-integration.md  # MCP 接入指南
└── pyproject.toml          # 项目配置
```

## 可用的 MCP Skills

SAP QA Agent 提供 5 个预置 Skills：

| Skill ID | 功能 |
|----------|------|
| `sap-parse-and-execute` | 解析并执行 SAP 测试用例 |
| `sap-session-bootstrap` | SAP 会话连接引导 |
| `sap-self-healing-playbook` | AI 自愈故障排查手册 |
| `sap-knowledge-base-reuse` | 复用知识库模板执行测试 |
| `sap-recording-to-testcase` | 将录制操作转换为测试用例 |

## 可用的 MCP Tools

- `parse_test_case` - 解析测试用例文件
- `sap_connect` - 连接 SAP GUI
- `sap_disconnect` - 断开 SAP GUI 连接
- `sap_session_status` - 检查 SAP 会话状态
- `execute_test_case` - 执行测试用例
- `get_task_status` - 获取任务状态
- `list_tasks` - 列出任务
- `stop_task` - 停止任务
- `capture_screen` - 截取屏幕
- `list_skills` - 列出 Skills
- `get_skill` - 获取 Skill 详情
- `list_templates` - 列出模板
- `get_template` - 获取模板详情
- `start_recording` - 开始录制
- `stop_recording` - 停止录制
- `atomic.*` - 原子化操作工具

## 环境要求

- Python 3.12+
- Windows 10/11
- SAP GUI（已启用 Scripting）

## 使用方式

### 通过 PyPI 安装

```bash
pip install sap-qa-agent
```

### 通过 uvx 直接运行（无需安装）

```bash
uvx --from sap-qa-agent sap-qa-mcp
```

### 本地开发安装

```bash
pip install -e .
```

## 许可证

Private

## 版本历史

- **0.1.1** (2026-05-09) - 修复描述为 "for SAP GUI"
- **0.1.0** (2026-05-09) - 初始版本发布到 PyPI
