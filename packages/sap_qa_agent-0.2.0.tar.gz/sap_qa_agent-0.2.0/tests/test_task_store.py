"""VlmTaskStore 单元测试"""

import uuid

from app.models import StepInfo, TaskStatus
from app.task_store import VlmTaskStore as TaskStore


class TestCreateTask:
    def test_returns_task_with_unique_uuid(self):
        store = TaskStore()
        task = store.create_task("test.xlsx")
        # task_id 应为合法 UUID
        uuid.UUID(task.task_id)

    def test_sets_filename(self):
        store = TaskStore()
        task = store.create_task("report.xlsx")
        assert task.filename == "report.xlsx"

    def test_initial_status_is_created(self):
        store = TaskStore()
        task = store.create_task("test.xlsx")
        assert task.status == TaskStatus.CREATED

    def test_sets_created_at(self):
        store = TaskStore()
        task = store.create_task("test.xlsx")
        assert task.created_at is not None

    def test_multiple_tasks_have_unique_ids(self):
        store = TaskStore()
        ids = {store.create_task("f.xlsx").task_id for _ in range(100)}
        assert len(ids) == 100


class TestGetTask:
    def test_returns_existing_task(self):
        store = TaskStore()
        created = store.create_task("test.xlsx")
        fetched = store.get_task(created.task_id)
        assert fetched is not None
        assert fetched.task_id == created.task_id

    def test_returns_none_for_missing_id(self):
        store = TaskStore()
        assert store.get_task("nonexistent") is None


class TestUpdateTask:
    def test_updates_status(self):
        store = TaskStore()
        task = store.create_task("test.xlsx")
        updated = store.update_task(task.task_id, status=TaskStatus.RUNNING)
        assert updated is not None
        assert updated.status == TaskStatus.RUNNING

    def test_returns_none_for_missing_id(self):
        store = TaskStore()
        assert store.update_task("nonexistent", status=TaskStatus.RUNNING) is None

    def test_auto_sets_completed_at_on_completed(self):
        store = TaskStore()
        task = store.create_task("test.xlsx")
        store.update_task(task.task_id, status=TaskStatus.RUNNING)
        updated = store.update_task(task.task_id, status=TaskStatus.COMPLETED)
        assert updated is not None
        assert updated.completed_at is not None

    def test_auto_sets_completed_at_on_failed(self):
        store = TaskStore()
        task = store.create_task("test.xlsx")
        store.update_task(task.task_id, status=TaskStatus.RUNNING)
        updated = store.update_task(task.task_id, status=TaskStatus.FAILED)
        assert updated is not None
        assert updated.completed_at is not None

    def test_updates_steps(self):
        store = TaskStore()
        task = store.create_task("test.xlsx")
        steps = [StepInfo(index=1, description="Step 1")]
        updated = store.update_task(task.task_id, steps=steps)
        assert updated is not None
        assert len(updated.steps) == 1
        assert updated.steps[0].description == "Step 1"

    def test_updates_error_field(self):
        store = TaskStore()
        task = store.create_task("test.xlsx")
        updated = store.update_task(task.task_id, error="something went wrong")
        assert updated is not None
        assert updated.error == "something went wrong"
