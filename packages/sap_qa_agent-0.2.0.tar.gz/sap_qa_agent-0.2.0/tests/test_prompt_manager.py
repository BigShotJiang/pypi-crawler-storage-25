"""Tests for PromptManager and prompt templates."""

import pytest
from app.ai.prompt_manager import PromptManager


@pytest.fixture
def pm():
    return PromptManager()


class TestPromptManager:
    """Unit tests for PromptManager render methods."""

    def test_render_step_split(self, pm: PromptManager):
        result = pm.render_step_split(
            transaction_code="VA01",
            steps_text="输入销售订单类型",
            test_data="销售组织: 1000",
        )
        assert "事务代码：VA01" in result
        assert "操作步骤：输入销售订单类型" in result
        assert "测试数据：销售组织: 1000" in result

    def test_render_script_generate(self, pm: PromptManager):
        steps_json = '[{"index": 1, "action_type": "input"}]'
        result = pm.render_script_generate(test_steps_json=steps_json)
        assert steps_json in result
        assert "session.findById" in result

    def test_render_element_match(self, pm: PromptManager):
        result = pm.render_element_match(
            target_description="销售组织",
            step_context="输入销售组织字段",
            window_context="wnd[0]",
            candidates_json="[]",
        )
        assert "目标字段描述：销售组织" in result
        assert "当前操作步骤：输入销售组织字段" in result
        assert "当前标签页/窗口：wnd[0]" in result

    def test_render_exception_handle(self, pm: PromptManager):
        result = pm.render_exception_handle(
            error_info="element not found",
            current_step="Step 3: 输入物料号",
            ui_state="主窗口",
            status_bar_message="",
            dialog_content="确认保存？",
        )
        assert "异常信息：element not found" in result
        assert "当前步骤：Step 3: 输入物料号" in result
        assert "弹窗内容（如有）：确认保存？" in result

    def test_render_failure_analysis(self, pm: PromptManager):
        result = pm.render_failure_analysis(
            step_description="输入售达方客户编号",
            error_message="GuiCTextField not found",
            status_bar_message="输入无效",
            screenshot_description="界面显示错误弹窗",
        )
        assert "失败步骤：输入售达方客户编号" in result
        assert "错误信息：GuiCTextField not found" in result
        assert "状态栏消息：输入无效" in result

    def test_render_step_split_with_empty_values(self, pm: PromptManager):
        """Ensure templates work with empty strings."""
        result = pm.render_step_split(
            transaction_code="",
            steps_text="",
            test_data="",
        )
        assert "事务代码：" in result

    def test_render_exception_handle_json_braces_preserved(self, pm: PromptManager):
        """Ensure literal JSON braces in the template are preserved after formatting."""
        result = pm.render_exception_handle(
            error_info="test",
            current_step="test",
            ui_state="test",
            status_bar_message="test",
            dialog_content="test",
        )
        # The template contains literal { } for the JSON example
        assert '"action"' in result
        assert '"reason"' in result

    def test_render_recovery_plan(self, pm: PromptManager):
        """Test render_recovery_plan substitutes all placeholders."""
        result = pm.render_recovery_plan(
            step_description="[INPUT] 输入销售组织",
            error_info="GuiCTextField not found",
            screen_snapshot="窗口标题: 创建销售订单",
            retry_history="attempt 1: failed",
        )
        assert "[INPUT] 输入销售组织" in result
        assert "GuiCTextField not found" in result
        assert "窗口标题: 创建销售订单" in result
        assert "attempt 1: failed" in result

    def test_render_recovery_plan_json_braces_preserved(self, pm: PromptManager):
        """Ensure literal JSON braces in recovery_plan template are preserved."""
        result = pm.render_recovery_plan(
            step_description="test",
            error_info="test",
            screen_snapshot="test",
            retry_history="test",
        )
        assert '"action"' in result
        assert '"confidence"' in result

    def test_render_dialog_analyze(self, pm: PromptManager):
        """Test render_dialog_analyze substitutes dialog title and text."""
        result = pm.render_dialog_analyze(
            dialog_title="信息",
            dialog_text="凭证 4500012345 已保存",
        )
        assert "信息" in result
        assert "凭证 4500012345 已保存" in result

    def test_render_dialog_analyze_json_braces_preserved(self, pm: PromptManager):
        """Ensure literal JSON braces in dialog_analyze template are preserved."""
        result = pm.render_dialog_analyze(
            dialog_title="test",
            dialog_text="test",
        )
        assert '"action"' in result
        assert '"reason"' in result
