"""Unit tests for ScreenMatcher."""

from datetime import datetime

from app.core.screen_matcher import ScreenMatcher, TCODE_TITLE_MAP
from app.data.models import (
    MessageType,
    ScreenSnapshot,
    StepActionType,
    TestStep,
)


def _make_snapshot(window_title: str = "") -> ScreenSnapshot:
    return ScreenSnapshot(
        window_title=window_title,
        status_bar_text="",
        status_bar_type=MessageType.INFO,
        active_window_id="wnd[0]",
        element_tree_summary="",
        timestamp=datetime.now(),
    )


class TestCheckScreen:
    """Tests for ScreenMatcher.check_screen."""

    def test_matching_title_returns_true(self):
        matcher = ScreenMatcher()
        snapshot = _make_snapshot("创建销售订单: 初始屏幕")
        step = TestStep(
            index=0,
            action_type=StepActionType.NAVIGATE,
            target_description="输入事务码",
            value="/nVA01",
        )
        assert matcher.check_screen(snapshot, step) is True

    def test_mismatched_title_returns_false(self):
        matcher = ScreenMatcher()
        snapshot = _make_snapshot("SAP Easy Access")
        step = TestStep(
            index=0,
            action_type=StepActionType.NAVIGATE,
            target_description="输入事务码",
            value="VA01",
        )
        assert matcher.check_screen(snapshot, step) is False

    def test_no_tcode_inferred_returns_true(self):
        matcher = ScreenMatcher()
        snapshot = _make_snapshot("SAP Easy Access")
        step = TestStep(
            index=0,
            action_type=StepActionType.INPUT,
            target_description="输入客户编号",
            value="12345",
        )
        assert matcher.check_screen(snapshot, step) is True

    def test_english_keyword_match(self):
        matcher = ScreenMatcher()
        snapshot = _make_snapshot("Create Sales Order: Initial Screen")
        step = TestStep(
            index=0,
            action_type=StepActionType.NAVIGATE,
            target_description="navigate",
            value="VA01",
        )
        assert matcher.check_screen(snapshot, step) is True

    def test_all_tcode_keywords_configured(self):
        """Verify all 8 required tcodes are in the map."""
        expected = {"VA01", "VA02", "VL01N", "VL02N", "VF01", "FB01", "MM01", "ME21N"}
        assert set(TCODE_TITLE_MAP.keys()) == expected


class TestInferTransactionCode:
    """Tests for ScreenMatcher.infer_transaction_code."""

    def test_navigate_step_with_slash_n(self):
        step = TestStep(
            index=0,
            action_type=StepActionType.NAVIGATE,
            target_description="输入事务码",
            value="/nVA01",
        )
        assert ScreenMatcher.infer_transaction_code(step) == "VA01"

    def test_navigate_step_with_slash_o(self):
        step = TestStep(
            index=0,
            action_type=StepActionType.NAVIGATE,
            target_description="输入事务码",
            value="/oME21N",
        )
        assert ScreenMatcher.infer_transaction_code(step) == "ME21N"

    def test_navigate_step_plain_tcode(self):
        step = TestStep(
            index=0,
            action_type=StepActionType.NAVIGATE,
            target_description="输入事务码",
            value="VL01N",
        )
        assert ScreenMatcher.infer_transaction_code(step) == "VL01N"

    def test_infer_from_target_description(self):
        step = TestStep(
            index=0,
            action_type=StepActionType.INPUT,
            target_description="在 VA02 修改销售订单界面输入订单号",
            value="100001",
        )
        assert ScreenMatcher.infer_transaction_code(step) == "VA02"

    def test_no_tcode_returns_none(self):
        step = TestStep(
            index=0,
            action_type=StepActionType.CLICK,
            target_description="点击保存按钮",
        )
        assert ScreenMatcher.infer_transaction_code(step) is None

    def test_navigate_empty_value_returns_none(self):
        step = TestStep(
            index=0,
            action_type=StepActionType.NAVIGATE,
            target_description="导航",
            value="",
        )
        assert ScreenMatcher.infer_transaction_code(step) is None

    def test_navigate_none_value_returns_none(self):
        step = TestStep(
            index=0,
            action_type=StepActionType.NAVIGATE,
            target_description="导航",
            value=None,
        )
        assert ScreenMatcher.infer_transaction_code(step) is None
