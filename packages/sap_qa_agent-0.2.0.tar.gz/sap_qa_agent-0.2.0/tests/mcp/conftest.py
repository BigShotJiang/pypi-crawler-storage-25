"""Common fixtures and settings for MCP test suite.

Scaffolding created in Task 0.5:
- `mock_sap_wrapper` : MagicMock(spec=SapGuiWrapper) pre-wired for happy path
- `tmp_mcp_server`   : spins up a ServerContext + FastMCP app with isolated
  artifacts_dir / knowledge_base_dir; lazy-imports the MCP server modules so
  this fixture degrades gracefully to `pytest.skip(...)` before Phase 1 lands.
- Hypothesis profile `mcp` registered/loaded with max_examples=50, deadline=None
  (Design §16.3, R21.2).
"""
from __future__ import annotations

import argparse
from pathlib import Path
from unittest.mock import MagicMock

import pytest

# ---------------------------------------------------------------------------
# Hypothesis profile registration (best-effort — hypothesis is optional until
# property tests land; skip silently if the library isn't installed yet)
# ---------------------------------------------------------------------------
try:
    from hypothesis import settings as _hyp_settings

    if "mcp" not in _hyp_settings._profiles:  # type: ignore[attr-defined]
        _hyp_settings.register_profile("mcp", max_examples=50, deadline=None)
    _hyp_settings.load_profile("mcp")
except Exception:  # pragma: no cover - hypothesis not installed yet
    pass


# ---------------------------------------------------------------------------
# mock_sap_wrapper
# ---------------------------------------------------------------------------
@pytest.fixture
def mock_sap_wrapper():
    """MagicMock(spec=SapGuiWrapper) preset for happy-path SAP operations."""
    try:
        from app.sap.sap_gui_wrapper import SapGuiWrapper
    except Exception:  # pragma: no cover - safety net for early scaffolding
        pytest.skip("SapGuiWrapper not importable in current environment")

    try:
        from app.data.models import MessageType, StatusBarMessage
    except Exception:  # pragma: no cover
        StatusBarMessage = None  # type: ignore[assignment]
        MessageType = None  # type: ignore[assignment]

    wrapper = MagicMock(spec=SapGuiWrapper)
    wrapper.is_connected.return_value = True
    wrapper.connect.return_value = True
    if StatusBarMessage is not None and MessageType is not None:
        wrapper.read_status_bar.return_value = StatusBarMessage(
            text="", message_type=MessageType.INFO
        )
    wrapper.screenshot.side_effect = lambda p: (Path(p).touch(), p)[1]
    return wrapper


# ---------------------------------------------------------------------------
# tmp_mcp_server
# ---------------------------------------------------------------------------
def _build_args(**overrides) -> argparse.Namespace:
    """Minimal argparse.Namespace stand-in for load_config(args)."""
    defaults = dict(
        transport="stdio",
        host="127.0.0.1",
        port=8100,
        auth_token=None,
        config=None,
        log_level="INFO",
        log_file=None,
        artifacts_root=None,
        allow_path=[],
        enable_atomic_tools=False,
        mcp_skills_dir=None,
    )
    defaults.update(overrides)
    return argparse.Namespace(**defaults)


@pytest.fixture
def tmp_mcp_server(tmp_path, mock_sap_wrapper, monkeypatch):
    """Spin up an isolated ServerContext + FastMCP for contract / tool tests.

    Skips when the MCP server modules are not yet present (pre-Phase 1)."""
    monkeypatch.setenv("SAP_QA_MCP_ARTIFACTS_DIR", str(tmp_path / "artifacts"))
    monkeypatch.setenv("SAP_QA_MCP_KNOWLEDGE_BASE_DIR", str(tmp_path / "kb"))
    monkeypatch.setenv("SAP_QA_MCP_UPLOAD_DIR", str(tmp_path / "upload"))

    try:
        from app.mcp_server.config import load_config
        from app.mcp_server.context import ServerContext
        from app.mcp_server.server import build_mcp
    except Exception as exc:  # pragma: no cover - pre-Phase 1 scaffolding
        pytest.skip(f"MCP server modules not available yet: {exc}")

    cfg = load_config(_build_args())
    ctx = ServerContext(cfg)
    ctx.sap_wrapper = mock_sap_wrapper
    mcp = build_mcp(ctx)
    try:
        yield mcp, ctx
    finally:
        shutdown = getattr(ctx, "shutdown", None)
        if callable(shutdown):
            try:
                shutdown()
            except Exception:
                pass
