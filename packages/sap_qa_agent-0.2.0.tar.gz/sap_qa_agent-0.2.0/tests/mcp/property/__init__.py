"""Property-based tests (Hypothesis) for MCP correctness properties P1-P8."""
