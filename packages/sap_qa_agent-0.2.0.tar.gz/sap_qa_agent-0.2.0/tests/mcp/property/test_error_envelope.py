"""Property P3: every error response has ok=false / valid code / correlation_id (Phase 4.5)."""
import pytest

pytest.skip("pending implementation (Phase 4.5)", allow_module_level=True)
