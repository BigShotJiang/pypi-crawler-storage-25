"""Property P5 + P6: skill required_tools subset + skills id = kebab-case directories (Phase 3.6)."""
import pytest

pytest.skip("pending implementation (Phase 3.6)", allow_module_level=True)
