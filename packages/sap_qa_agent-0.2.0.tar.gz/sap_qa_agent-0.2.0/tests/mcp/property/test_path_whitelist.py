"""Property P4: any out-of-whitelist path yields PATH_NOT_ALLOWED (Phase 4.5 + 5.4)."""
import pytest

pytest.skip("pending implementation (Phase 4.5 / 5.4)", allow_module_level=True)
