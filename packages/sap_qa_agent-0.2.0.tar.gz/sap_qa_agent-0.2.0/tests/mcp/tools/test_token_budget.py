"""Unit tests for app.mcp_server.token_budget (Task 9.1).

Covers:
- _estimate_tokens approximation
- apply_token_budget no-op when under budget
- apply_token_budget strips fields in priority order when over budget
- Persistence of full payload to $ARTIFACTS_DIR/mcp-truncated/{cid}.json
- _token_budget_override per-call override (capped at token_budget_max)
- _inline_image_requested prevents stripping image_base64
- truncated=True and truncation_ref are set on the response
"""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock

import pytest

from app.mcp_server.config import ConfigProfile
from app.mcp_server.context import ServerContext
from app.mcp_server.errors import correlation_id_var
from app.mcp_server.token_budget import (
    _estimate_tokens,
    _persist_full_payload,
    apply_token_budget,
)


@pytest.fixture
def ctx(tmp_path: Path) -> ServerContext:
    """Create a ServerContext with a small token budget for testing."""
    cfg = ConfigProfile(
        knowledge_base_dir=str(tmp_path / "kb"),
        artifacts_dir=str(tmp_path / "artifacts"),
        upload_dir=str(tmp_path / "upload"),
        token_budget=100,  # very small for testing
        token_budget_max=500,
    )
    return ServerContext(cfg)


class TestEstimateTokens:
    """Tests for _estimate_tokens."""

    def test_empty_dict(self):
        result = {}
        est = _estimate_tokens(result)
        # json.dumps({}) == "{}" → 2 chars → 2 // 4 == 0
        assert est == 0

    def test_simple_payload(self):
        result = {"ok": True, "data": "hello world"}
        json_str = json.dumps(result, ensure_ascii=False)
        expected = len(json_str) // 4
        assert _estimate_tokens(result) == expected

    def test_large_payload(self):
        result = {"data": "x" * 4000}
        est = _estimate_tokens(result)
        # Should be roughly 4000/4 = 1000 plus some overhead for keys
        assert est > 900

    def test_non_serializable_returns_large_number(self):
        # An object that can't be serialized even with default=str
        # shouldn't happen in practice, but the function should be safe
        result = {"ok": True, "data": "normal"}
        # Normal case works fine
        assert _estimate_tokens(result) > 0


class TestPersistFullPayload:
    """Tests for _persist_full_payload."""

    def test_creates_file(self, tmp_path: Path):
        result = {"ok": True, "data": {"key": "value"}}
        cid = "abc123"
        ref = _persist_full_payload(result, cid, str(tmp_path))

        expected_path = tmp_path / "mcp-truncated" / "abc123.json"
        assert expected_path.exists()
        content = json.loads(expected_path.read_text(encoding="utf-8"))
        assert content == result

    def test_returns_sap_qa_uri(self, tmp_path: Path):
        result = {"ok": True}
        ref = _persist_full_payload(result, "xyz789", str(tmp_path))
        assert ref == "sap-qa://artifacts/mcp-truncated/xyz789.json"

    def test_creates_directory_if_missing(self, tmp_path: Path):
        artifacts = tmp_path / "deep" / "nested"
        result = {"data": "test"}
        _persist_full_payload(result, "cid1", str(artifacts))
        assert (artifacts / "mcp-truncated" / "cid1.json").exists()


class TestApplyTokenBudget:
    """Tests for apply_token_budget."""

    def test_no_op_when_under_budget(self, ctx: ServerContext):
        """Small response should pass through unchanged."""
        result = {"ok": True, "data": {"msg": "hi"}}
        original = result.copy()
        apply_token_budget(result, ctx)
        # No truncation markers added
        assert "truncated" not in result
        assert "truncation_ref" not in result

    def test_strips_fields_when_over_budget(self, ctx: ServerContext):
        """Large response should have fields stripped."""
        # Create a response that exceeds the 100-token budget
        result = {
            "ok": True,
            "data": "x",
            "logs_tail": ["log"] * 200,
            "step_results": [{"step": i} for i in range(100)],
            "elements_text": "e" * 2000,
            "image_base64": "i" * 2000,
            "correlation_id": "test-cid",
        }
        token = correlation_id_var.set("test-cid")
        try:
            apply_token_budget(result, ctx)
        finally:
            correlation_id_var.reset(token)

        # All strippable fields should be removed
        assert "logs_tail" not in result
        assert "step_results" not in result
        assert "elements_text" not in result
        assert "image_base64" not in result
        # Truncation markers should be present
        assert result["truncated"] is True
        assert "truncation_ref" in result
        assert result["truncation_ref"].startswith("sap-qa://")

    def test_persists_full_payload(self, ctx: ServerContext):
        """Full payload should be written to disk before stripping."""
        result = {
            "ok": True,
            "logs_tail": ["log"] * 200,
            "correlation_id": "persist-test",
        }
        token = correlation_id_var.set("persist-test")
        try:
            apply_token_budget(result, ctx)
        finally:
            correlation_id_var.reset(token)

        # Check the file was written
        persisted_path = (
            Path(ctx.config.artifacts_dir) / "mcp-truncated" / "persist-test.json"
        )
        assert persisted_path.exists()
        content = json.loads(persisted_path.read_text(encoding="utf-8"))
        # The persisted version should contain the original logs_tail
        assert "logs_tail" in content
        assert len(content["logs_tail"]) == 200

    def test_token_budget_override(self, ctx: ServerContext):
        """Per-call _token_budget_override should be honoured."""
        # With a large override, the response should NOT be truncated
        result = {
            "ok": True,
            "logs_tail": ["log"] * 50,
            "_token_budget_override": 50000,
        }
        apply_token_budget(result, ctx)
        # Override is large enough, no truncation
        assert "truncated" not in result
        # The sentinel key should be removed
        assert "_token_budget_override" not in result

    def test_token_budget_override_capped_at_max(self, ctx: ServerContext):
        """Override cannot exceed token_budget_max."""
        # ctx.config.token_budget_max is 500
        # Create a payload that's > 500 tokens but < 999999
        big_data = "x" * 3000  # ~750 tokens
        result = {
            "ok": True,
            "logs_tail": [big_data],
            "_token_budget_override": 999999,  # exceeds max of 500
        }
        token = correlation_id_var.set("cap-test")
        try:
            apply_token_budget(result, ctx)
        finally:
            correlation_id_var.reset(token)

        # Should be truncated because effective budget is capped at 500
        assert result.get("truncated") is True

    def test_inline_image_requested_preserves_image_base64(
        self, ctx: ServerContext
    ):
        """_inline_image_requested=True prevents stripping image_base64."""
        result = {
            "ok": True,
            "logs_tail": ["log"] * 200,
            "image_base64": "img_data_here",
            "_inline_image_requested": True,
            "correlation_id": "inline-test",
        }
        token = correlation_id_var.set("inline-test")
        try:
            apply_token_budget(result, ctx)
        finally:
            correlation_id_var.reset(token)

        # image_base64 should be preserved
        assert result.get("image_base64") == "img_data_here"
        # But logs_tail should still be stripped
        assert "logs_tail" not in result
        # Sentinel removed
        assert "_inline_image_requested" not in result

    def test_sentinel_keys_always_removed(self, ctx: ServerContext):
        """_token_budget_override and _inline_image_requested are always popped."""
        result = {
            "ok": True,
            "data": "small",
            "_token_budget_override": 50000,
            "_inline_image_requested": False,
        }
        apply_token_budget(result, ctx)
        assert "_token_budget_override" not in result
        assert "_inline_image_requested" not in result
