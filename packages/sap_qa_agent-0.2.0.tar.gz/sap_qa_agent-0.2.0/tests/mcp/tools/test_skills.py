"""Tests for `list_skills` / `get_skill` tools (Phase 4)."""
import pytest

pytest.skip("pending implementation (Phase 4)", allow_module_level=True)
