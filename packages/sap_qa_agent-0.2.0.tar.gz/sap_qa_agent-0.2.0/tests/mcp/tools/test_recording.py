"""Tests for `start_recording` / `stop_recording` tools (Phase 7)."""
import pytest

pytest.skip("pending implementation (Phase 7)", allow_module_level=True)
