"""Per-tool tests for MCP Server."""
