"""Tests for `parse_test_case` tool (Phase 4)."""
import pytest

pytest.skip("pending implementation (Phase 4)", allow_module_level=True)
