"""Tests for knowledge base tools: list_templates / get_template (Phase 4)."""
import pytest

pytest.skip("pending implementation (Phase 4)", allow_module_level=True)
