"""Tests for task management tools: get_task_status / list_tasks / stop_task (Phase 6)."""
import pytest

pytest.skip("pending implementation (Phase 6)", allow_module_level=True)
