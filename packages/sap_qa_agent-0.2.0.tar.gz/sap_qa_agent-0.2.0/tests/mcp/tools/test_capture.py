"""Tests for `capture_screen` tool (Phase 6)."""
import pytest

pytest.skip("pending implementation (Phase 6)", allow_module_level=True)
