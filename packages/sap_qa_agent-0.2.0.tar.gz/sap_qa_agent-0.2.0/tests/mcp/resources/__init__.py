"""Resource URI router tests."""
