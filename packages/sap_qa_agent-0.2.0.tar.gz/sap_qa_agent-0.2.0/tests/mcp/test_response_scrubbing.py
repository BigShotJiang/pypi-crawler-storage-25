"""Unit tests for response scrubbing hook (Task 9.4).

Validates that the middleware pipeline calls ``safety.scrub_sensitive(result)``
before returning, ensuring ``glm_api_key`` and ``auth_token`` values are never
leaked — even if a tool handler manually injects them into the response.

Requirements: R13.4
Design: §10.5
"""

from __future__ import annotations

import argparse
from unittest.mock import MagicMock

import pytest

from app.mcp_server.safety import SENSITIVE_KEYS, scrub_sensitive


# ---------------------------------------------------------------------------
# Direct scrub_sensitive tests
# ---------------------------------------------------------------------------


class TestScrubSensitiveDirect:
    """Verify scrub_sensitive catches glm_api_key / auth_token in any shape."""

    def test_top_level_keys_scrubbed(self):
        data = {
            "ok": True,
            "data": {"result": "success"},
            "glm_api_key": "sk-secret-123",
            "auth_token": "bearer-xyz",
        }
        scrub_sensitive(data)
        assert data["glm_api_key"] == "***"
        assert data["auth_token"] == "***"
        # Non-sensitive fields untouched
        assert data["ok"] is True
        assert data["data"]["result"] == "success"

    def test_nested_keys_scrubbed(self):
        data = {
            "ok": True,
            "data": {
                "config": {
                    "glm_api_key": "my-secret-key",
                    "model": "GLM-4",
                },
                "auth_token": "token-value",
            },
        }
        scrub_sensitive(data)
        assert data["data"]["config"]["glm_api_key"] == "***"
        assert data["data"]["config"]["model"] == "GLM-4"
        assert data["data"]["auth_token"] == "***"

    def test_deeply_nested_in_list(self):
        data = {
            "ok": True,
            "data": {
                "items": [
                    {"name": "safe", "value": 1},
                    {"glm_api_key": "leaked!", "info": "ok"},
                    {"nested": {"auth_token": "also-leaked"}},
                ]
            },
        }
        scrub_sensitive(data)
        assert data["data"]["items"][1]["glm_api_key"] == "***"
        assert data["data"]["items"][1]["info"] == "ok"
        assert data["data"]["items"][2]["nested"]["auth_token"] == "***"

    def test_case_insensitive_matching(self):
        data = {
            "GLM_API_KEY": "secret",
            "Auth_Token": "token",
            "Glm_Api_Key": "another",
        }
        scrub_sensitive(data)
        assert data["GLM_API_KEY"] == "***"
        assert data["Auth_Token"] == "***"
        assert data["Glm_Api_Key"] == "***"

    def test_none_values_preserved(self):
        data = {"glm_api_key": None, "auth_token": None}
        scrub_sensitive(data)
        assert data["glm_api_key"] is None
        assert data["auth_token"] is None

    def test_non_string_sensitive_values_scrubbed(self):
        """Even numeric or dict values under sensitive keys get replaced."""
        data = {
            "glm_api_key": 12345,
            "auth_token": {"nested": "structure"},
        }
        scrub_sensitive(data)
        assert data["glm_api_key"] == "***"
        assert data["auth_token"] == "***"

    def test_empty_dict_passthrough(self):
        data: dict = {}
        result = scrub_sensitive(data)
        assert result == {}

    def test_scalar_passthrough(self):
        assert scrub_sensitive("hello") == "hello"
        assert scrub_sensitive(42) == 42
        assert scrub_sensitive(None) is None


# ---------------------------------------------------------------------------
# Middleware integration: verify _post_process calls scrub_sensitive
# ---------------------------------------------------------------------------


class TestMiddlewareScrubIntegration:
    """Verify the middleware pipeline scrubs sensitive keys from tool results."""

    @pytest.fixture
    def middleware_ctx(self, tmp_path, monkeypatch):
        """Build a minimal ServerContext for middleware testing."""
        monkeypatch.setenv("SAP_QA_MCP_ARTIFACTS_DIR", str(tmp_path / "artifacts"))
        monkeypatch.setenv("SAP_QA_MCP_KNOWLEDGE_BASE_DIR", str(tmp_path / "kb"))
        monkeypatch.setenv("SAP_QA_MCP_UPLOAD_DIR", str(tmp_path / "upload"))

        from app.mcp_server.config import load_config
        from app.mcp_server.context import ServerContext

        args = argparse.Namespace(
            transport="stdio",
            host="127.0.0.1",
            port=8100,
            auth_token=None,
            config=None,
            log_level="INFO",
            log_file=None,
            artifacts_root=None,
            allow_path=[],
            enable_atomic_tools=False,
            mcp_skills_dir=None,
        )
        cfg = load_config(args)
        ctx = ServerContext(cfg)
        return ctx

    def test_sync_tool_response_scrubbed(self, middleware_ctx):
        """A sync tool that returns sensitive keys gets them scrubbed."""
        from app.mcp_server.middleware import bind_middleware

        ctx = middleware_ctx
        mw = bind_middleware(ctx)

        @mw
        def leaky_tool():
            return {
                "ok": True,
                "data": {
                    "glm_api_key": "sk-leaked-value",
                    "auth_token": "bearer-leaked",
                    "safe_field": "visible",
                },
            }

        result = leaky_tool()
        assert result["data"]["glm_api_key"] == "***"
        assert result["data"]["auth_token"] == "***"
        assert result["data"]["safe_field"] == "visible"
        assert result["ok"] is True
        assert "correlation_id" in result

    def test_async_tool_response_scrubbed(self, middleware_ctx):
        """An async tool that returns sensitive keys gets them scrubbed."""
        import asyncio

        from app.mcp_server.middleware import bind_middleware

        ctx = middleware_ctx
        mw = bind_middleware(ctx)

        @mw
        async def async_leaky_tool():
            return {
                "ok": True,
                "data": {
                    "glm_api_key": "async-secret",
                    "auth_token": "async-token",
                    "info": "public",
                },
            }

        result = asyncio.run(async_leaky_tool())
        assert result["data"]["glm_api_key"] == "***"
        assert result["data"]["auth_token"] == "***"
        assert result["data"]["info"] == "public"

    def test_nested_sensitive_in_response_scrubbed(self, middleware_ctx):
        """Sensitive keys buried deep in response structure are still caught."""
        from app.mcp_server.middleware import bind_middleware

        ctx = middleware_ctx
        mw = bind_middleware(ctx)

        @mw
        def deeply_nested_tool():
            return {
                "ok": True,
                "data": {
                    "config_dump": {
                        "server": {
                            "glm_api_key": "deep-secret",
                            "port": 8100,
                        },
                        "auth": [
                            {"auth_token": "list-token", "user": "admin"}
                        ],
                    }
                },
            }

        result = deeply_nested_tool()
        assert result["data"]["config_dump"]["server"]["glm_api_key"] == "***"
        assert result["data"]["config_dump"]["server"]["port"] == 8100
        assert result["data"]["config_dump"]["auth"][0]["auth_token"] == "***"
        assert result["data"]["config_dump"]["auth"][0]["user"] == "admin"
