"""Unit tests for app.mcp_server.metrics.Metrics.

Validates:
- tool_call_count / tool_error_count accumulation
- duration_ms_sum / duration_ms_count per-tool tracking
- active_tasks increment/decrement lifecycle
- snapshot() produces correct avg_duration_ms_by_tool
- Thread safety (basic concurrent access)
"""

from __future__ import annotations

import threading

import pytest

from app.mcp_server.metrics import Metrics


class TestMetricsRecord:
    """Tests for Metrics.record() and counter accumulation."""

    def test_initial_state(self):
        m = Metrics()
        assert m.tool_call_count == 0
        assert m.tool_error_count == 0
        assert m.active_tasks == 0
        assert dict(m.duration_ms_sum) == {}
        assert dict(m.duration_ms_count) == {}

    def test_record_success_increments_counters(self):
        m = Metrics()
        m.tool_started()
        m.record("parse_test_case", 0.15, ok=True)

        assert m.tool_call_count == 1
        assert m.tool_error_count == 0
        assert m.duration_ms_sum["parse_test_case"] == 150
        assert m.duration_ms_count["parse_test_case"] == 1
        assert m.active_tasks == 0

    def test_record_failure_increments_error_count(self):
        m = Metrics()
        m.tool_started()
        m.record("sap_connect", 2.0, ok=False)

        assert m.tool_call_count == 1
        assert m.tool_error_count == 1
        assert m.duration_ms_sum["sap_connect"] == 2000
        assert m.duration_ms_count["sap_connect"] == 1

    def test_multiple_records_accumulate(self):
        m = Metrics()
        m.tool_started()
        m.record("parse_test_case", 0.1, ok=True)
        m.tool_started()
        m.record("parse_test_case", 0.2, ok=True)
        m.tool_started()
        m.record("sap_connect", 1.5, ok=False)

        assert m.tool_call_count == 3
        assert m.tool_error_count == 1
        assert m.duration_ms_sum["parse_test_case"] == 300
        assert m.duration_ms_count["parse_test_case"] == 2
        assert m.duration_ms_sum["sap_connect"] == 1500
        assert m.duration_ms_count["sap_connect"] == 1

    def test_active_tasks_does_not_go_negative(self):
        m = Metrics()
        # record without prior tool_started — should clamp to 0
        m.record("some_tool", 0.01, ok=True)
        assert m.active_tasks == 0


class TestMetricsToolStarted:
    """Tests for Metrics.tool_started() and active_tasks tracking."""

    def test_tool_started_increments_active(self):
        m = Metrics()
        m.tool_started()
        assert m.active_tasks == 1
        m.tool_started()
        assert m.active_tasks == 2

    def test_record_decrements_active(self):
        m = Metrics()
        m.tool_started()
        m.tool_started()
        assert m.active_tasks == 2
        m.record("t1", 0.01, ok=True)
        assert m.active_tasks == 1
        m.record("t2", 0.02, ok=True)
        assert m.active_tasks == 0


class TestMetricsSnapshot:
    """Tests for Metrics.snapshot() output shape and avg computation."""

    def test_empty_snapshot(self):
        m = Metrics()
        snap = m.snapshot()
        assert snap == {
            "tool_call_count": 0,
            "tool_error_count": 0,
            "avg_duration_ms_by_tool": {},
            "active_tasks": 0,
        }

    def test_snapshot_computes_avg(self):
        m = Metrics()
        # Two calls to parse_test_case: 100ms and 200ms → avg 150ms
        m.tool_started()
        m.record("parse_test_case", 0.1, ok=True)
        m.tool_started()
        m.record("parse_test_case", 0.2, ok=True)
        # One call to sap_connect: 2000ms
        m.tool_started()
        m.record("sap_connect", 2.0, ok=True)

        snap = m.snapshot()
        assert snap["tool_call_count"] == 3
        assert snap["tool_error_count"] == 0
        assert snap["avg_duration_ms_by_tool"]["parse_test_case"] == 150
        assert snap["avg_duration_ms_by_tool"]["sap_connect"] == 2000
        assert snap["active_tasks"] == 0

    def test_snapshot_reflects_active_tasks(self):
        m = Metrics()
        m.tool_started()
        m.tool_started()
        snap = m.snapshot()
        assert snap["active_tasks"] == 2

    def test_snapshot_with_errors(self):
        m = Metrics()
        m.tool_started()
        m.record("t1", 0.05, ok=True)
        m.tool_started()
        m.record("t1", 0.03, ok=False)

        snap = m.snapshot()
        assert snap["tool_call_count"] == 2
        assert snap["tool_error_count"] == 1


class TestMetricsThreadSafety:
    """Basic concurrency test for Metrics."""

    def test_concurrent_records(self):
        m = Metrics()
        n_threads = 10
        calls_per_thread = 100

        def worker():
            for _ in range(calls_per_thread):
                m.tool_started()
                m.record("concurrent_tool", 0.001, ok=True)

        threads = [threading.Thread(target=worker) for _ in range(n_threads)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert m.tool_call_count == n_threads * calls_per_thread
        assert m.active_tasks == 0
        assert m.duration_ms_count["concurrent_tool"] == n_threads * calls_per_thread
