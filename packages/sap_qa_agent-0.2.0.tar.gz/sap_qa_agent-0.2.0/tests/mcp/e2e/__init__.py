"""End-to-end tests that require a real SAP GUI (SAP_QA_MCP_E2E=1)."""
