"""End-to-end smoke test requiring a real SAP GUI session (Phase 11.1).

Only runs when SAP_QA_MCP_E2E=1 (Design §16.4). Placeholder tests will be
filled in by Phase 11 tasks.
"""
import os

import pytest

pytestmark = pytest.mark.skipif(
    os.environ.get("SAP_QA_MCP_E2E") != "1",
    reason="requires real SAP GUI (set SAP_QA_MCP_E2E=1 to enable)",
)


def test_placeholder():
    """Placeholder — replaced by Phase 11.1 with the full connect→parse→execute flow."""
    pytest.skip("pending implementation (Phase 11.1)")
