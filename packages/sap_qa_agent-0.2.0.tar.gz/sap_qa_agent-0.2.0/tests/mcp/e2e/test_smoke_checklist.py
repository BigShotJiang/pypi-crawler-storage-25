"""Programmatic smoke test checklist for MCP Server integration (Task 11.3).

Verifies the MCP server can start and respond to basic requests without
requiring a real SAP GUI connection. This covers the subset of the smoke
checklist that can be validated programmatically:

1. Server builds successfully (initialize handshake equivalent)
2. list_skills returns 5 skills
3. parse_test_case can parse a sample markdown test case
4. All expected tools are registered

Full E2E testing with real SAP GUI requires SAP_QA_MCP_E2E=1.

Requirements: R17.5, R21.5
"""

from __future__ import annotations

import argparse
import os
from pathlib import Path
from unittest.mock import MagicMock

import pytest


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def smoke_server(tmp_path, monkeypatch):
    """Build an isolated MCP server for smoke testing.

    Sets up temporary directories and mocks the SAP wrapper so we can
    test everything except actual SAP GUI interaction.
    """
    artifacts_dir = tmp_path / "artifacts"
    artifacts_dir.mkdir()
    kb_dir = tmp_path / "kb"
    kb_dir.mkdir()
    upload_dir = tmp_path / "upload"
    upload_dir.mkdir()

    monkeypatch.setenv("SAP_QA_MCP_ARTIFACTS_DIR", str(artifacts_dir))
    monkeypatch.setenv("SAP_QA_MCP_KNOWLEDGE_BASE_DIR", str(kb_dir))
    monkeypatch.setenv("SAP_QA_MCP_UPLOAD_DIR", str(upload_dir))

    from app.mcp_server.config import load_config
    from app.mcp_server.context import ServerContext
    from app.mcp_server.server import build_mcp

    args = argparse.Namespace(
        transport="stdio",
        host="127.0.0.1",
        port=8100,
        auth_token=None,
        config=None,
        log_level="INFO",
        log_file=None,
        artifacts_root=None,
        allow_path=[str(upload_dir)],
        enable_atomic_tools=False,
        mcp_skills_dir=None,
    )

    cfg = load_config(args)
    ctx = ServerContext(cfg)

    # Mock SAP wrapper so SAP-dependent tools don't crash
    mock_sap = MagicMock()
    mock_sap.is_connected.return_value = False
    ctx.sap_wrapper = mock_sap

    mcp = build_mcp(ctx)
    yield mcp, ctx, tmp_path


# ---------------------------------------------------------------------------
# Smoke Checklist Tests
# ---------------------------------------------------------------------------


class TestSmokeChecklist:
    """Smoke test checklist — programmatic verification of MCP server health."""

    def test_01_server_builds_successfully(self, smoke_server):
        """Smoke #1: Server builds and initialize handshake would succeed.

        Verifies that build_mcp() completes without error and the
        resulting FastMCP instance has the expected server name.
        """
        mcp, ctx, _ = smoke_server
        assert mcp is not None
        # FastMCP stores the name; verify it matches config
        assert ctx.config.server_name == "sap-qa-agent"
        assert ctx.config.server_version == "0.1.0"

    def test_02_list_skills_returns_5(self, smoke_server):
        """Smoke #2: list_skills returns exactly 5 built-in skills.

        Expected skills:
        - sap-parse-and-execute
        - sap-self-healing-playbook
        - sap-recording-to-testcase
        - sap-knowledge-base-reuse
        - sap-session-bootstrap
        """
        mcp, ctx, _ = smoke_server

        from app.mcp_server.skills_loader.cache import SkillCache
        from app.mcp_server.safety import _mcp_skills_dir

        cache = SkillCache(_mcp_skills_dir())
        skills = cache.all()

        expected_ids = {
            "sap-parse-and-execute",
            "sap-self-healing-playbook",
            "sap-recording-to-testcase",
            "sap-knowledge-base-reuse",
            "sap-session-bootstrap",
        }

        actual_ids = {pkg.metadata.id for pkg in skills}
        assert actual_ids == expected_ids, (
            f"Expected 5 skills {expected_ids}, got {actual_ids}"
        )
        assert len(skills) == 5

    def test_03_parse_test_case_markdown(self, smoke_server):
        """Smoke #3: parse_test_case successfully parses a sample markdown.

        Creates a minimal markdown test case fixture in the key-value
        table format that TestCaseParser expects, and verifies the
        parse tool can process it without errors.
        """
        mcp, ctx, tmp_path = smoke_server

        # Create a sample markdown test case in the upload directory
        # using the key-value table format the parser expects
        upload_dir = Path(ctx.config.upload_dir)
        sample_md = upload_dir / "smoke_test_case.md"
        sample_md.write_text(
            """# SAP 登录测试

| 测试项 | 测试内容 |
|---|---|
| 用例编号 | SMOKE-001 |
| 测试目的 | 验证 SAP 系统登录功能 |
| 前置条件 | SAP GUI 已安装并启动 |
| 操作步骤 | 1. 打开 SAP Logon; 2. 输入用户名 TESTUSER; 3. 输入密码; 4. 点击登录 |
| 测试数据 | 用户名：TESTUSER；密码：Test1234 |
| 预期结果 | 1. 成功进入 SAP Easy Access 主界面; 2. 状态栏显示用户名 |
| AI执行备注 | 无 |
""",
            encoding="utf-8",
        )

        # Use the parse tool's internal logic directly
        from app.core.test_case_parser import TestCaseParser

        parser = TestCaseParser()
        cases = parser.parse_markdown(str(sample_md))

        assert len(cases) >= 1, "Should parse at least 1 test case"
        # Verify the case has basic structure
        first_case = cases[0]
        assert first_case.case_id == "SMOKE-001"
        assert first_case.purpose, "Parsed case should have purpose"
        assert first_case.steps_text, "Parsed case should have steps"

    def test_04_all_expected_tools_registered(self, smoke_server):
        """Smoke #4: All expected MCP tools are registered.

        Verifies the tool list contains the core tools that should
        always be available regardless of SAP connection state.
        """
        import asyncio

        mcp, ctx, _ = smoke_server

        # Use FastMCP's async list_tools() API
        tools = asyncio.run(mcp.list_tools())
        tool_names = {t.name for t in tools}

        # Core tools that should always be registered
        expected_core_tools = {
            "parse_test_case",
            "list_skills",
            "get_skill",
            "list_templates",
            "get_template",
            "sap_connect",
            "sap_disconnect",
            "sap_session_status",
            "execute_test_case",
            "get_task_status",
            "list_tasks",
            "stop_task",
            "capture_screen",
            "start_recording",
            "stop_recording",
        }

        missing = expected_core_tools - tool_names
        assert not missing, (
            f"Missing expected tools: {missing}. "
            f"Registered tools: {sorted(tool_names)}"
        )

    def test_05_skills_have_required_metadata(self, smoke_server):
        """Smoke #5: Each skill has valid front-matter and required sections.

        Validates that validate-skills would pass for all 5 built-in skills.
        """
        from app.mcp_server.skills_loader.cache import SkillCache
        from app.mcp_server.safety import _mcp_skills_dir

        cache = SkillCache(_mcp_skills_dir())
        skills = cache.all()

        for pkg in skills:
            meta = pkg.metadata
            # Required front-matter fields
            assert meta.id, f"Skill missing id"
            assert meta.title, f"Skill {meta.id} missing title"
            assert meta.description, f"Skill {meta.id} missing description"
            assert meta.version, f"Skill {meta.id} missing version"
            assert meta.keywords, f"Skill {meta.id} missing keywords"
            assert meta.required_tools, f"Skill {meta.id} missing required_tools"

            # Required sections in body
            body = pkg.content_md
            for section in (
                "## When to use",
                "## Inputs",
                "## Tool sequence",
                "## Success criteria",
                "## Failure handling",
            ):
                assert section in body, (
                    f"Skill {meta.id} missing section: {section}"
                )
