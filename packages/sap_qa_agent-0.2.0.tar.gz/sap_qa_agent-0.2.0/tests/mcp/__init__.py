"""MCP server test suite."""
