"""Contract tests for MCP `tools/list` (Phase 1.8)."""
import pytest

pytest.skip("pending implementation (Phase 1.8)", allow_module_level=True)
