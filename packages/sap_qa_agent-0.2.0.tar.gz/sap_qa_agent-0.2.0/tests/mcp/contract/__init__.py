"""Contract tests for MCP initialize / tools/list / resources/list / prompts/list."""
