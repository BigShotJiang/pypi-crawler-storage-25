"""Contract tests for MCP `resources/list` (Phase 1.8)."""
import pytest

pytest.skip("pending implementation (Phase 1.8)", allow_module_level=True)
