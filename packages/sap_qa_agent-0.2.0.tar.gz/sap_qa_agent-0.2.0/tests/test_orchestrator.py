"""Tests for DependencyGraph and TestOrchestrator."""

from __future__ import annotations

import pytest
from datetime import datetime
from unittest.mock import AsyncMock, MagicMock, patch

from app.core.orchestrator import DependencyGraph, TestOrchestrator
from app.data.flow_variable import FlowVariableContext
from app.data.models import (
    ExecutionMode,
    FlowVariableDef,
    StepActionType,
    StepResult,
    TestCase,
    TestCaseResult,
    TestCaseType,
    TestStep,
    TestSuite,
    TestSuiteResult,
    VerificationResult,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_case(
    case_id: str,
    deps: list[str] | None = None,
    tcode: str | None = None,
    flow_var_defs: list[FlowVariableDef] | None = None,
) -> TestCase:
    return TestCase(
        case_id=case_id,
        purpose=f"Test {case_id}",
        preconditions="",
        steps_text="step 1",
        test_data={},
        expected_results=["success"],
        ai_notes="",
        transaction_code=tcode,
        dependencies=deps or [],
        flow_variable_defs=flow_var_defs or [],
    )


def _make_suite(cases: list[TestCase], suite_id: str = "S1") -> TestSuite:
    return TestSuite(suite_id=suite_id, name="Suite", test_cases=cases)


# ===================================================================
# DependencyGraph tests
# ===================================================================


class TestDependencyGraph:
    """Tests for DependencyGraph."""

    def test_build_empty_suite(self):
        suite = _make_suite([])
        dg = DependencyGraph(suite)
        assert dg.validate() == []
        assert dg.get_execution_order() == []

    def test_no_dependencies(self):
        suite = _make_suite([_make_case("A"), _make_case("B"), _make_case("C")])
        dg = DependencyGraph(suite)
        assert dg.validate() == []
        order = dg.get_execution_order()
        assert set(order) == {"A", "B", "C"}

    def test_linear_chain(self):
        suite = _make_suite([
            _make_case("A"),
            _make_case("B", deps=["A"]),
            _make_case("C", deps=["B"]),
        ])
        dg = DependencyGraph(suite)
        assert dg.validate() == []
        order = dg.get_execution_order()
        assert order.index("A") < order.index("B") < order.index("C")

    def test_diamond_dependency(self):
        suite = _make_suite([
            _make_case("A"),
            _make_case("B", deps=["A"]),
            _make_case("C", deps=["A"]),
            _make_case("D", deps=["B", "C"]),
        ])
        dg = DependencyGraph(suite)
        assert dg.validate() == []
        order = dg.get_execution_order()
        assert order.index("A") < order.index("B")
        assert order.index("A") < order.index("C")
        assert order.index("B") < order.index("D")
        assert order.index("C") < order.index("D")

    def test_cycle_detected(self):
        suite = _make_suite([
            _make_case("A", deps=["C"]),
            _make_case("B", deps=["A"]),
            _make_case("C", deps=["B"]),
        ])
        dg = DependencyGraph(suite)
        errors = dg.validate()
        assert len(errors) > 0
        assert any("Cycle" in e or "cycle" in e.lower() for e in errors)

    def test_missing_dependency(self):
        suite = _make_suite([
            _make_case("A", deps=["MISSING"]),
        ])
        dg = DependencyGraph(suite)
        errors = dg.validate()
        assert any("MISSING" in e for e in errors)

    def test_get_dependents_direct(self):
        suite = _make_suite([
            _make_case("A"),
            _make_case("B", deps=["A"]),
            _make_case("C", deps=["A"]),
        ])
        dg = DependencyGraph(suite)
        dependents = set(dg.get_dependents("A"))
        assert dependents == {"B", "C"}

    def test_get_dependents_transitive(self):
        suite = _make_suite([
            _make_case("A"),
            _make_case("B", deps=["A"]),
            _make_case("C", deps=["B"]),
        ])
        dg = DependencyGraph(suite)
        dependents = set(dg.get_dependents("A"))
        assert dependents == {"B", "C"}

    def test_get_dependents_no_dependents(self):
        suite = _make_suite([
            _make_case("A"),
            _make_case("B"),
        ])
        dg = DependencyGraph(suite)
        assert dg.get_dependents("A") == []

    def test_self_cycle(self):
        suite = _make_suite([_make_case("A", deps=["A"])])
        dg = DependencyGraph(suite)
        errors = dg.validate()
        assert len(errors) > 0


# ===================================================================
# TestOrchestrator tests
# ===================================================================


def _build_orchestrator(
    *,
    match_mode: str = "exploration",
    explore_success: bool = True,
    reuse_success: bool = True,
    reuse_needs_fallback: bool = False,
    step_results: list[StepResult] | None = None,
    template_solidified: bool = False,
    doc_number: str | None = None,
) -> TestOrchestrator:
    """Build a TestOrchestrator with mocked dependencies."""
    default_step_results = step_results or [
        StepResult(
            step_index=0,
            success=explore_success if match_mode == "exploration" else reuse_success,
            status_bar_message=f"销售订单 {doc_number} 已创建" if doc_number else None,
            extracted_document_number=doc_number,
        )
    ]

    # StepSplitter mock
    step_splitter = AsyncMock()
    step_splitter.split.return_value = [
        TestStep(index=0, action_type=StepActionType.NAVIGATE,
                 target_description="命令输入框", value="/nVA01"),
    ]

    # TemplateMatcher mock
    template_matcher = MagicMock()
    match_result = MagicMock()
    match_result.mode = match_mode
    match_result.template = MagicMock() if match_mode == "reuse" else None
    template_matcher.match.return_value = match_result

    # ExplorationEngine mock
    exploration_engine = AsyncMock()
    explore_result = MagicMock()
    explore_result.success = explore_success
    explore_result.step_results = default_step_results
    explore_result.template_solidified = template_solidified
    exploration_engine.explore.return_value = explore_result

    # ReuseEngine mock
    reuse_engine = AsyncMock()
    reuse_result = MagicMock()
    reuse_result.success = reuse_success
    reuse_result.step_results = default_step_results
    reuse_result.needs_fallback = reuse_needs_fallback
    reuse_engine.execute_with_template.return_value = reuse_result

    # ResultVerifier mock
    result_verifier = MagicMock()
    all_ok = all(sr.success for sr in default_step_results)
    result_verifier.verify_expected_results.return_value = [
        VerificationResult(description="check", passed=all_ok),
    ]

    # ScriptExecutor mock
    script_executor = MagicMock()
    script_executor.extract_document_number.return_value = doc_number
    script_executor.is_on_login_screen.return_value = False
    script_executor.is_logged_in.return_value = True
    script_executor.get_current_screen.return_value = {
        "window_title": "SAP 轻松访问",
        "transaction": "",
        "status_bar": "",
    }
    script_executor.collect_screen_elements_text.return_value = ""

    return TestOrchestrator(
        step_splitter=step_splitter,
        template_matcher=template_matcher,
        exploration_engine=exploration_engine,
        reuse_engine=reuse_engine,
        result_verifier=result_verifier,
        script_executor=script_executor,
    )


class TestTestOrchestrator:
    """Tests for TestOrchestrator."""

    @pytest.mark.asyncio
    async def test_execute_case_exploration_success(self):
        orch = _build_orchestrator(match_mode="exploration", explore_success=True)
        tc = _make_case("TC1", tcode="VA01")
        ctx = FlowVariableContext()
        result = await orch.execute_test_case(tc, ctx)
        assert result.success is True
        assert result.execution_mode == ExecutionMode.EXPLORATION

    @pytest.mark.asyncio
    async def test_execute_case_reuse_success(self):
        orch = _build_orchestrator(match_mode="reuse", reuse_success=True)
        tc = _make_case("TC1", tcode="VA01")
        ctx = FlowVariableContext()
        result = await orch.execute_test_case(tc, ctx)
        assert result.success is True
        assert result.execution_mode == ExecutionMode.REUSE

    @pytest.mark.asyncio
    async def test_execute_case_reuse_fallback_to_exploration(self):
        orch = _build_orchestrator(
            match_mode="reuse",
            reuse_success=False,
            reuse_needs_fallback=True,
            explore_success=True,
        )
        tc = _make_case("TC1", tcode="VA01")
        ctx = FlowVariableContext()
        result = await orch.execute_test_case(tc, ctx)
        assert result.execution_mode == ExecutionMode.EXPLORATION

    @pytest.mark.asyncio
    async def test_execute_case_extracts_flow_variable(self):
        orch = _build_orchestrator(
            match_mode="exploration",
            explore_success=True,
            doc_number="0000012345",
        )
        tc = _make_case(
            "TC1",
            tcode="VA01",
            flow_var_defs=[FlowVariableDef(name="ORDER_NO", source="status bar")],
        )
        ctx = FlowVariableContext()
        result = await orch.execute_test_case(tc, ctx)
        assert result.flow_variables_extracted.get("ORDER_NO") == "0000012345"
        assert ctx.get("ORDER_NO") == "0000012345"

    @pytest.mark.asyncio
    async def test_execute_suite_linear_chain(self):
        orch = _build_orchestrator(match_mode="exploration", explore_success=True)
        suite = _make_suite([
            _make_case("A"),
            _make_case("B", deps=["A"]),
            _make_case("C", deps=["B"]),
        ])
        result = await orch.execute_test_suite(suite)
        assert result.total_cases == 3
        assert result.passed_cases == 3
        assert result.skipped_cases == 0

    @pytest.mark.asyncio
    async def test_execute_suite_cascade_skip(self):
        """When A fails, B and C (which depend on A) should be skipped."""
        orch = _build_orchestrator(
            match_mode="exploration",
            explore_success=False,
            step_results=[StepResult(step_index=0, success=False, error_message="fail")],
        )
        suite = _make_suite([
            _make_case("A"),
            _make_case("B", deps=["A"]),
            _make_case("C", deps=["B"]),
        ])
        result = await orch.execute_test_suite(suite)
        assert result.total_cases == 3
        # A failed, B and C skipped
        assert result.skipped_cases == 2
        # Check that B and C have the skip marker
        skipped_results = [r for r in result.case_results if r.case_id in ("B", "C")]
        for sr in skipped_results:
            assert sr.success is False
            assert any("跳过" in vr.description for vr in sr.verification_results)

    @pytest.mark.asyncio
    async def test_execute_suite_flow_variable_chain(self):
        """Flow variables should be available in the suite result."""
        orch = _build_orchestrator(
            match_mode="exploration",
            explore_success=True,
            doc_number="9999999999",
        )
        suite = _make_suite([
            _make_case(
                "A",
                flow_var_defs=[FlowVariableDef(name="ORDER_NO", source="status")],
            ),
            _make_case("B", deps=["A"]),
        ])
        result = await orch.execute_test_suite(suite)
        assert result.flow_variable_chain.get("ORDER_NO") == "9999999999"

    def test_build_dependency_graph(self):
        orch = _build_orchestrator()
        suite = _make_suite([
            _make_case("A"),
            _make_case("B", deps=["A"]),
        ])
        dg = orch.build_dependency_graph(suite)
        assert isinstance(dg, DependencyGraph)
        assert dg.validate() == []
