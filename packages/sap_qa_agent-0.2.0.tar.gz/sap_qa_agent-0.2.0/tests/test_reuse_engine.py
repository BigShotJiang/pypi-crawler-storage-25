"""Tests for ReuseEngine."""

import pytest
from unittest.mock import AsyncMock, MagicMock

from app.core.reuse_engine import ReuseEngine, ReuseResult
from app.data.models import ScriptTemplate, StepResult, TemplateConfidence


def _make_template() -> ScriptTemplate:
    return ScriptTemplate(
        template_id="tpl_test_001",
        transaction_code="VA01",
        scenario_type="标准订单",
        script_content='session.findById("${销售组织}").text = params["销售组织"]',
        element_path_map={"销售组织": "wnd[0]/usr/ctxtVBAK-VKORG"},
        parameters=["销售组织"],
        confidence=TemplateConfidence.DRAFT,
    )


def _make_engine(step_results: list[StepResult] | None = None):
    executor = AsyncMock()
    if step_results is None:
        step_results = [
            StepResult(step_index=0, success=True),
            StepResult(step_index=1, success=True),
            StepResult(step_index=2, success=True),
        ]
    executor.execute_script.return_value = step_results

    kb = MagicMock()
    engine = ReuseEngine(executor, kb)
    return engine, executor, kb


@pytest.mark.asyncio
async def test_execute_with_template_success():
    engine, executor, kb = _make_engine()
    template = _make_template()
    test_data = {"销售组织": "1000"}

    result = await engine.execute_with_template(template, test_data, flow_context=None)

    assert result.success
    assert result.template_updated
    assert not result.needs_fallback
    kb.update_confidence.assert_called_once_with("tpl_test_001", success=True)


@pytest.mark.asyncio
async def test_execute_with_template_failure_triggers_fallback():
    failed_results = [
        StepResult(step_index=0, success=True),
        StepResult(step_index=1, success=False, error_message="Field not found"),
    ]
    engine, executor, kb = _make_engine(step_results=failed_results)
    template = _make_template()
    test_data = {"销售组织": "1000"}

    result = await engine.execute_with_template(template, test_data, flow_context=None)

    assert not result.success
    assert result.needs_fallback
    kb.update_confidence.assert_called_once_with("tpl_test_001", success=False)


def test_fill_template_replaces_placeholders():
    engine, _, _ = _make_engine()
    template = ScriptTemplate(
        template_id="tpl_fill",
        transaction_code="VA01",
        scenario_type="test",
        script_content='session.findById("path").text = "${销售组织}"',
        element_path_map={},
        parameters=["销售组织"],
    )
    test_data = {"销售组织": "2000"}

    filled = engine.fill_template(template, test_data, flow_context=None)

    assert "2000" in filled
    assert "${销售组织}" not in filled


def test_fill_template_with_flow_context():
    engine, _, _ = _make_engine()
    from app.data.flow_variable import FlowVariableContext

    flow = FlowVariableContext()
    flow.set("ORDER_NO", "0000012345")

    template = ScriptTemplate(
        template_id="tpl_flow",
        transaction_code="VA02",
        scenario_type="test",
        script_content='session.findById("path").text = "${ORDER_NO}"',
        element_path_map={},
        parameters=[],
    )

    filled = engine.fill_template(template, {}, flow)

    assert "0000012345" in filled
    assert "${ORDER_NO}" not in filled
