"""Excel 解析器单元测试"""

import os
import tempfile

import pandas as pd
import pytest

from app.excel_parser import (
    EmptyDataError,
    ExcelParser,
    InvalidFormatError,
    MissingColumnsError,
)


@pytest.fixture
def parser():
    return ExcelParser()


def _create_excel(data: dict, filename: str = "test.xlsx") -> str:
    """辅助函数：创建临时 Excel 文件并返回路径。"""
    tmp = tempfile.NamedTemporaryFile(suffix=".xlsx", delete=False)
    df = pd.DataFrame(data)
    df.to_excel(tmp.name, index=False)
    tmp.close()
    return tmp.name


class TestExcelParserNormal:
    """正常解析场景"""

    def test_parse_basic(self, parser):
        path = _create_excel({"步骤序号": [1, 2, 3], "步骤描述": ["打开浏览器", "点击登录", "输入密码"]})
        try:
            steps = parser.parse(path)
            assert len(steps) == 3
            assert steps[0].index == 1
            assert steps[0].description == "打开浏览器"
            assert steps[2].index == 3
            assert steps[2].description == "输入密码"
        finally:
            os.unlink(path)

    def test_parse_sorts_by_index(self, parser):
        path = _create_excel({"步骤序号": [3, 1, 2], "步骤描述": ["第三步", "第一步", "第二步"]})
        try:
            steps = parser.parse(path)
            assert [s.index for s in steps] == [1, 2, 3]
            assert steps[0].description == "第一步"
            assert steps[1].description == "第二步"
            assert steps[2].description == "第三步"
        finally:
            os.unlink(path)

    def test_parse_skips_empty_rows(self, parser):
        path = _create_excel({
            "步骤序号": [1, None, 2, None],
            "步骤描述": ["步骤一", None, "步骤二", None],
        })
        try:
            steps = parser.parse(path)
            assert len(steps) == 2
        finally:
            os.unlink(path)

    def test_parse_strips_description_whitespace(self, parser):
        path = _create_excel({"步骤序号": [1], "步骤描述": ["  打开浏览器  "]})
        try:
            steps = parser.parse(path)
            assert steps[0].description == "打开浏览器"
        finally:
            os.unlink(path)


class TestExcelParserErrors:
    """错误场景"""

    def test_corrupted_file(self, parser):
        tmp = tempfile.NamedTemporaryFile(suffix=".xlsx", delete=False)
        tmp.write(b"this is not an excel file")
        tmp.close()
        try:
            with pytest.raises(InvalidFormatError):
                parser.parse(tmp.name)
        finally:
            os.unlink(tmp.name)

    def test_missing_step_index_column(self, parser):
        path = _create_excel({"步骤描述": ["打开浏览器"]})
        try:
            with pytest.raises(MissingColumnsError) as exc_info:
                parser.parse(path)
            assert "步骤序号" in str(exc_info.value)
        finally:
            os.unlink(path)

    def test_missing_step_desc_column(self, parser):
        path = _create_excel({"步骤序号": [1]})
        try:
            with pytest.raises(MissingColumnsError) as exc_info:
                parser.parse(path)
            assert "步骤描述" in str(exc_info.value)
        finally:
            os.unlink(path)

    def test_missing_both_columns(self, parser):
        path = _create_excel({"其他列": ["数据"]})
        try:
            with pytest.raises(MissingColumnsError):
                parser.parse(path)
        finally:
            os.unlink(path)

    def test_empty_data_after_filtering(self, parser):
        path = _create_excel({"步骤序号": [None], "步骤描述": [None]})
        try:
            with pytest.raises(EmptyDataError):
                parser.parse(path)
        finally:
            os.unlink(path)

    def test_all_blank_descriptions(self, parser):
        path = _create_excel({"步骤序号": [1, 2], "步骤描述": ["  ", ""]})
        try:
            with pytest.raises(EmptyDataError):
                parser.parse(path)
        finally:
            os.unlink(path)

    def test_nonexistent_file(self, parser):
        with pytest.raises(InvalidFormatError):
            parser.parse("/nonexistent/path/file.xlsx")
