"""TestCaseParser 单元测试"""

import os
import tempfile

import openpyxl
import pytest

from app.core.test_case_parser import TestCaseParser
from app.data.models import TestCase, TestCaseType


@pytest.fixture
def parser():
    return TestCaseParser()


def _create_test_excel(rows: list[list[str | None]], filename: str = "test.xlsx") -> str:
    """创建测试用 Excel 文件。第一行为表头，后续为数据行。"""
    tmp = tempfile.NamedTemporaryFile(suffix=".xlsx", delete=False)
    tmp.close()
    wb = openpyxl.Workbook()
    ws = wb.active
    for row in rows:
        ws.append(row)
    wb.save(tmp.name)
    wb.close()
    return tmp.name


def _create_test_markdown(content: str) -> str:
    """创建测试用 Markdown 文件。"""
    tmp = tempfile.NamedTemporaryFile(suffix=".md", delete=False, mode="w", encoding="utf-8")
    tmp.write(content)
    tmp.close()
    return tmp.name


# ---- Excel 解析测试 ----


class TestParseExcel:
    def test_basic_excel_parsing(self, parser):
        path = _create_test_excel([
            ["用例编号", "测试目的", "前置条件", "操作步骤", "测试数据", "预期结果", "AI执行备注"],
            ["BD9-001", "测试创建", "", '输入事务码"VA01"', "销售组织：1310", "1. 订单已创建", "记录订单号"],
        ])
        try:
            cases = parser.parse_excel(path)
            assert len(cases) == 1
            tc = cases[0]
            assert tc.case_id == "BD9-001"
            assert tc.purpose == "测试创建"
            assert "VA01" in tc.steps_text
            assert tc.test_data.get("销售组织") == "1310"
            assert len(tc.expected_results) >= 1
        finally:
            os.unlink(path)

    def test_multiple_rows(self, parser):
        path = _create_test_excel([
            ["用例编号", "测试目的", "前置条件", "操作步骤", "测试数据", "预期结果", "AI执行备注"],
            ["BD9-001", "创建订单", "", "步骤1", "", "1. 结果1", ""],
            ["BD9-002", "修改订单", "", "步骤2", "", "1. 结果2", ""],
        ])
        try:
            cases = parser.parse_excel(path)
            assert len(cases) == 2
            assert cases[0].case_id == "BD9-001"
            assert cases[1].case_id == "BD9-002"
        finally:
            os.unlink(path)

    def test_skips_rows_without_case_id(self, parser):
        path = _create_test_excel([
            ["用例编号", "测试目的", "前置条件", "操作步骤", "测试数据", "预期结果", "AI执行备注"],
            ["BD9-001", "创建", "", "步骤", "", "1. 结果", ""],
            [None, "", "", "", "", "", ""],
            ["BD9-002", "修改", "", "步骤", "", "1. 结果", ""],
        ])
        try:
            cases = parser.parse_excel(path)
            assert len(cases) == 2
        finally:
            os.unlink(path)

    def test_empty_excel(self, parser):
        path = _create_test_excel([])
        try:
            cases = parser.parse_excel(path)
            assert cases == []
        finally:
            os.unlink(path)

    def test_transaction_code_extraction_from_excel(self, parser):
        path = _create_test_excel([
            ["用例编号", "测试目的", "前置条件", "操作步骤", "测试数据", "预期结果", "AI执行备注"],
            ["BD9-001", "创建", "", '输入事务码"VA01"进入界面', "", "1. 成功", ""],
        ])
        try:
            cases = parser.parse_excel(path)
            assert cases[0].transaction_code == "VA01"
        finally:
            os.unlink(path)


# ---- Markdown 解析测试 ----


class TestParseMarkdown:
    def test_kv_table_format(self, parser):
        """测试键值对表格格式（如示例文件中的格式）。"""
        content = """## 用例1

|测试项|测试内容|
|---|---|
|用例编号|BD9-2602-001|
|测试目的|验证销售订单创建|
|前置条件||
|操作步骤|输入事务码"VA01"，创建订单|
|测试数据|销售组织：1310；分销渠道：10|
|预期结果|1. 订单已创建|
|AI执行备注|记录生成的销售订单号|
"""
        path = _create_test_markdown(content)
        try:
            cases = parser.parse_markdown(path)
            assert len(cases) == 1
            tc = cases[0]
            assert tc.case_id == "BD9-2602-001"
            assert tc.purpose == "验证销售订单创建"
            assert tc.transaction_code == "VA01"
            assert len(tc.flow_variable_defs) >= 1
        finally:
            os.unlink(path)

    def test_multiple_kv_tables(self, parser):
        content = """## 用例1

|测试项|测试内容|
|---|---|
|用例编号|BD9-001|
|测试目的|创建|
|操作步骤|步骤1|
|预期结果|1. 结果1|

## 用例2

|测试项|测试内容|
|---|---|
|用例编号|BD9-002|
|测试目的|修改|
|操作步骤|步骤2|
|预期结果|1. 结果2|
"""
        path = _create_test_markdown(content)
        try:
            cases = parser.parse_markdown(path)
            assert len(cases) == 2
        finally:
            os.unlink(path)

    def test_standard_table_format(self, parser):
        content = """| 用例编号 | 测试目的 | 前置条件 | 操作步骤 | 测试数据 | 预期结果 | AI执行备注 |
|---|---|---|---|---|---|---|
| BD9-001 | 创建订单 | | 输入VA01 | 组织：1310 | 1. 成功 | 记录订单号 |
"""
        path = _create_test_markdown(content)
        try:
            cases = parser.parse_markdown(path)
            assert len(cases) == 1
            assert cases[0].case_id == "BD9-001"
        finally:
            os.unlink(path)


# ---- 验证测试 ----


class TestValidate:
    def test_valid_case(self, parser):
        tc = TestCase(
            case_id="BD9-001",
            purpose="test",
            preconditions="",
            steps_text="step 1",
            test_data={},
            expected_results=["result 1"],
            ai_notes="",
        )
        assert parser.validate(tc) == []

    def test_missing_case_id(self, parser):
        tc = TestCase(
            case_id="",
            purpose="test",
            preconditions="",
            steps_text="step 1",
            test_data={},
            expected_results=["result 1"],
            ai_notes="",
        )
        assert "case_id" in parser.validate(tc)

    def test_missing_steps(self, parser):
        tc = TestCase(
            case_id="BD9-001",
            purpose="test",
            preconditions="",
            steps_text="",
            test_data={},
            expected_results=["result 1"],
            ai_notes="",
        )
        assert "steps_text" in parser.validate(tc)

    def test_missing_expected_results(self, parser):
        tc = TestCase(
            case_id="BD9-001",
            purpose="test",
            preconditions="",
            steps_text="step 1",
            test_data={},
            expected_results=[],
            ai_notes="",
        )
        assert "expected_results" in parser.validate(tc)

    def test_multiple_missing(self, parser):
        tc = TestCase(
            case_id="",
            purpose="",
            preconditions="",
            steps_text="",
            test_data={},
            expected_results=[],
            ai_notes="",
        )
        missing = parser.validate(tc)
        assert "case_id" in missing
        assert "steps_text" in missing
        assert "expected_results" in missing


# ---- 事务代码提取测试 ----


class TestExtractTransactionCode:
    def test_quoted_tcode(self, parser):
        assert parser.extract_transaction_code('输入事务码"VA01"') == "VA01"

    def test_tcode_with_number_suffix(self, parser):
        assert parser.extract_transaction_code('事务码"VL01N"') == "VL01N"

    def test_tcode_with_hyphen(self, parser):
        assert parser.extract_transaction_code('事务码"F-02"') == "F-02"

    def test_tcode_me21n(self, parser):
        assert parser.extract_transaction_code("使用事务代码ME21N创建采购订单") == "ME21N"

    def test_tcode_migo(self, parser):
        assert parser.extract_transaction_code("事务码MIGO收货") == "MIGO"

    def test_tcode_fb01(self, parser):
        assert parser.extract_transaction_code('输入事务码"FB01"') == "FB01"

    def test_no_tcode(self, parser):
        assert parser.extract_transaction_code("点击保存按钮") is None

    def test_empty_input(self, parser):
        assert parser.extract_transaction_code("") is None
        assert parser.extract_transaction_code(None) is None


# ---- Flow_Variable 提取测试 ----


class TestExtractFlowVariables:
    def test_order_no(self, parser):
        notes = "需自动捕捉系统提示信息，记录生成的销售订单号，用于后续用例关联"
        vars_ = parser.extract_flow_variables(notes)
        assert len(vars_) >= 1
        assert any(v.name == "ORDER_NO" for v in vars_)

    def test_delivery_no(self, parser):
        notes = "记录生成的交货单号，用于后续开票用例"
        vars_ = parser.extract_flow_variables(notes)
        assert any(v.name == "DELIVERY_NO" for v in vars_)

    def test_explicit_variable(self, parser):
        notes = "变量名: ORDER_NO"
        vars_ = parser.extract_flow_variables(notes)
        assert any(v.name == "ORDER_NO" for v in vars_)

    def test_no_variables(self, parser):
        notes = "无特殊备注"
        vars_ = parser.extract_flow_variables(notes)
        assert vars_ == []

    def test_empty_input(self, parser):
        assert parser.extract_flow_variables("") == []
        assert parser.extract_flow_variables(None) == []


# ---- 依赖提取测试 ----


class TestExtractDependencies:
    def test_case_id_reference(self, parser):
        preconditions = "用例1执行成功，已生成有效销售订单（订单号：XXXXXXXX，记录为变量ORDER_NO）"
        deps = parser.extract_dependencies(preconditions)
        assert any("ORDER_NO" in d for d in deps)

    def test_explicit_dependency(self, parser):
        preconditions = "依赖 BD9-2602-001 完成"
        deps = parser.extract_dependencies(preconditions)
        assert "BD9-2602-001" in deps

    def test_case_id_in_precondition(self, parser):
        preconditions = "用例2执行成功，销售订单（BD9-2602-001）已修改完成"
        deps = parser.extract_dependencies(preconditions)
        assert "BD9-2602-001" in deps

    def test_no_dependencies(self, parser):
        assert parser.extract_dependencies("") == []
        assert parser.extract_dependencies(None) == []
