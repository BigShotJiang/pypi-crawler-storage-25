"""Tests for FlowVariableContext document number extraction.

Covers:
- extract_document_number with patterns.json patterns
- extract_document_number fallback to default regex
- extract_document_number with explicit variable_name override
- extract_document_number with empty/no-match text
- Integration with ExecutionEngine._extract_document_number
"""

from __future__ import annotations

import json
import os
import tempfile

import pytest

from app.data.flow_variable import FlowVariableContext


# ---- Helpers ----

def _make_patterns_file(patterns: list[dict]) -> str:
    """Create a temporary patterns.json and return its path."""
    tmp = tempfile.NamedTemporaryFile(
        mode="w", suffix=".json", delete=False, encoding="utf-8"
    )
    json.dump({"patterns": patterns, "language": "zh_CN"}, tmp, ensure_ascii=False)
    tmp.close()
    return tmp.name


@pytest.fixture()
def ctx_with_patterns(tmp_path):
    """FlowVariableContext loaded with the real patterns.json."""
    real_patterns = os.path.join(
        os.path.dirname(os.path.dirname(__file__)),
        "knowledge_base",
        "patterns.json",
    )
    return FlowVariableContext(patterns_path=real_patterns)


@pytest.fixture()
def ctx_no_patterns(tmp_path):
    """FlowVariableContext with an empty patterns file (fallback only)."""
    p = tmp_path / "empty_patterns.json"
    p.write_text('{"patterns": []}', encoding="utf-8")
    return FlowVariableContext(patterns_path=str(p))


# ---- Tests: pattern-based extraction ----


def test_extract_sales_order(ctx_with_patterns):
    text = "销售订单 0000012345 已创建"
    result = ctx_with_patterns.extract_document_number(text)
    assert result == "0000012345"
    assert ctx_with_patterns.get("ORDER_NO") == "0000012345"


def test_extract_delivery(ctx_with_patterns):
    text = "外向交货单 0080012345 已创建"
    result = ctx_with_patterns.extract_document_number(text)
    assert result == "0080012345"
    assert ctx_with_patterns.get("DELIVERY_NO") == "0080012345"


def test_extract_billing_document(ctx_with_patterns):
    text = "Billing Document 9000054321 has been saved"
    result = ctx_with_patterns.extract_document_number(text)
    assert result == "9000054321"
    assert ctx_with_patterns.get("INVOICE_NO") == "9000054321"


def test_extract_generic_doc_number(ctx_with_patterns):
    text = "1234567890 已保存"
    result = ctx_with_patterns.extract_document_number(text)
    assert result == "1234567890"
    assert ctx_with_patterns.get("DOC_NO") == "1234567890"


# ---- Tests: variable_name override ----


def test_extract_with_explicit_variable_name(ctx_with_patterns):
    text = "销售订单 0000099999 已创建"
    result = ctx_with_patterns.extract_document_number(text, variable_name="MY_ORDER")
    assert result == "0000099999"
    assert ctx_with_patterns.get("MY_ORDER") == "0000099999"
    # Should NOT be stored under the pattern's default variable
    assert ctx_with_patterns.get("ORDER_NO") is None


# ---- Tests: fallback regex ----


def test_fallback_extracts_8_digit(ctx_no_patterns):
    text = "Document 12345678 processed"
    result = ctx_no_patterns.extract_document_number(text)
    assert result == "12345678"
    assert ctx_no_patterns.get("DOC_NO") == "12345678"


def test_fallback_extracts_10_digit(ctx_no_patterns):
    text = "Reference number is 1234567890 ok"
    result = ctx_no_patterns.extract_document_number(text)
    assert result == "1234567890"
    assert ctx_no_patterns.get("DOC_NO") == "1234567890"


# ---- Tests: no match / empty ----


def test_extract_returns_none_for_empty_text(ctx_with_patterns):
    assert ctx_with_patterns.extract_document_number("") is None
    assert ctx_with_patterns.extract_document_number("") is None


def test_extract_returns_none_when_no_digits(ctx_with_patterns):
    assert ctx_with_patterns.extract_document_number("No numbers here") is None


def test_extract_returns_none_for_short_digits(ctx_no_patterns):
    """Digits shorter than 8 should not match."""
    assert ctx_no_patterns.extract_document_number("Code 1234567 done") is None


# ---- Tests: patterns file missing ----


def test_missing_patterns_file_uses_fallback():
    ctx = FlowVariableContext(patterns_path="/nonexistent/patterns.json")
    text = "Document 12345678 saved"
    result = ctx.extract_document_number(text)
    assert result == "12345678"
    assert ctx.get("DOC_NO") == "12345678"


# ---- Tests: backward compatibility ----


def test_existing_resolve_still_works():
    ctx = FlowVariableContext(patterns_path="/nonexistent/patterns.json")
    ctx.set("ORDER_NO", "0000012345")
    assert ctx.resolve("Order: ${ORDER_NO}") == "Order: 0000012345"


def test_existing_set_get_still_works():
    ctx = FlowVariableContext(patterns_path="/nonexistent/patterns.json")
    ctx.set("X", "val")
    assert ctx.get("X") == "val"
    assert ctx.has("X")
    assert not ctx.has("Y")
