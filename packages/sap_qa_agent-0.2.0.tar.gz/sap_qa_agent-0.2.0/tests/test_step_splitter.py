"""StepSplitter 单元测试"""

import asyncio
from unittest.mock import AsyncMock, MagicMock

import pytest

from app.ai.glm_client import GlmClient
from app.ai.prompt_manager import PromptManager
from app.core.step_splitter import StepSplitter, _dedup_navigate_enter
from app.data.models import StepActionType, TestCase, TestStep


@pytest.fixture
def mock_glm_client():
    client = MagicMock(spec=GlmClient)
    client.split_steps = AsyncMock()
    return client


@pytest.fixture
def prompt_manager():
    return PromptManager()


@pytest.fixture
def splitter(mock_glm_client, prompt_manager):
    return StepSplitter(mock_glm_client, prompt_manager)


def _make_test_case(
    case_id: str = "BD9-001",
    steps_text: str = "输入销售组织1310",
    transaction_code: str | None = None,
) -> TestCase:
    return TestCase(
        case_id=case_id,
        purpose="test",
        preconditions="",
        steps_text=steps_text,
        test_data={},
        expected_results=["result"],
        ai_notes="",
        transaction_code=transaction_code,
    )


class TestStepSplitterNavigation:
    """事务代码导航步骤测试"""

    @pytest.mark.asyncio
    async def test_glm_navigate_without_enter(self, splitter, mock_glm_client):
        """GLM 返回 navigate（不带回车）时，步骤应原样保留。"""
        mock_glm_client.split_steps.return_value = [
            TestStep(index=1, action_type=StepActionType.NAVIGATE, target_description="命令输入框", value="/nVA01"),
            TestStep(index=2, action_type=StepActionType.INPUT, target_description="销售组织", value="1310"),
        ]
        tc = _make_test_case(transaction_code="VA01")

        steps = await splitter.split(tc)

        assert len(steps) == 2
        assert steps[0].action_type == StepActionType.NAVIGATE
        assert steps[1].action_type == StepActionType.INPUT

    @pytest.mark.asyncio
    async def test_glm_navigate_with_redundant_enter_deduped(self, splitter, mock_glm_client):
        """GLM 返回 navigate + 回车时，多余回车应被去重。"""
        mock_glm_client.split_steps.return_value = [
            TestStep(index=1, action_type=StepActionType.NAVIGATE, target_description="命令输入框", value="/nVA01"),
            TestStep(index=2, action_type=StepActionType.CLICK, target_description="回车"),
            TestStep(index=3, action_type=StepActionType.INPUT, target_description="销售组织", value="1310"),
        ]
        tc = _make_test_case(transaction_code="VA01")

        steps = await splitter.split(tc)

        # 回车被去重，只剩 2 步
        assert len(steps) == 2
        assert steps[0].index == 1
        assert steps[0].action_type == StepActionType.NAVIGATE
        assert steps[1].index == 2
        assert steps[1].action_type == StepActionType.INPUT

    @pytest.mark.asyncio
    async def test_no_navigation_without_tcode(self, splitter, mock_glm_client):
        """无事务代码时，不插入导航步骤。"""
        mock_glm_client.split_steps.return_value = [
            TestStep(index=1, action_type=StepActionType.INPUT, target_description="字段", value="值"),
        ]
        tc = _make_test_case(transaction_code=None)

        steps = await splitter.split(tc)

        assert len(steps) == 1
        assert steps[0].index == 1
        assert steps[0].action_type == StepActionType.INPUT


class TestDedupNavigateEnter:
    """_dedup_navigate_enter 去重逻辑专项测试"""

    def test_removes_enter_after_navigate(self):
        """navigate 后紧跟的回车应被移除。"""
        steps = [
            TestStep(index=1, action_type=StepActionType.NAVIGATE, target_description="命令输入框", value="/nVA01"),
            TestStep(index=2, action_type=StepActionType.CLICK, target_description="回车"),
            TestStep(index=3, action_type=StepActionType.INPUT, target_description="订单类型", value="OR"),
        ]
        result = _dedup_navigate_enter(steps)

        assert len(result) == 2
        assert result[0].action_type == StepActionType.NAVIGATE
        assert result[1].action_type == StepActionType.INPUT
        assert result[0].index == 1
        assert result[1].index == 2

    def test_removes_english_enter_after_navigate(self):
        """navigate 后紧跟的 'enter' 也应被移除。"""
        steps = [
            TestStep(index=1, action_type=StepActionType.NAVIGATE, target_description="命令输入框", value="/nME21N"),
            TestStep(index=2, action_type=StepActionType.CLICK, target_description="enter"),
            TestStep(index=3, action_type=StepActionType.INPUT, target_description="物料", value="100"),
        ]
        result = _dedup_navigate_enter(steps)

        assert len(result) == 2
        assert result[1].action_type == StepActionType.INPUT

    def test_keeps_enter_not_after_navigate(self):
        """非 navigate 后的回车应保留。"""
        steps = [
            TestStep(index=1, action_type=StepActionType.INPUT, target_description="物料", value="100"),
            TestStep(index=2, action_type=StepActionType.CLICK, target_description="回车"),
            TestStep(index=3, action_type=StepActionType.INPUT, target_description="数量", value="10"),
        ]
        result = _dedup_navigate_enter(steps)

        assert len(result) == 3

    def test_keeps_non_enter_after_navigate(self):
        """navigate 后紧跟非回车的步骤应保留。"""
        steps = [
            TestStep(index=1, action_type=StepActionType.NAVIGATE, target_description="命令输入框", value="/nVA01"),
            TestStep(index=2, action_type=StepActionType.INPUT, target_description="订单类型", value="OR"),
        ]
        result = _dedup_navigate_enter(steps)

        assert len(result) == 2

    def test_handles_multiple_navigates(self):
        """多个 navigate 各自去重紧跟的回车。"""
        steps = [
            TestStep(index=1, action_type=StepActionType.NAVIGATE, target_description="命令输入框", value="/nVA01"),
            TestStep(index=2, action_type=StepActionType.CLICK, target_description="回车"),
            TestStep(index=3, action_type=StepActionType.INPUT, target_description="字段", value="值"),
            TestStep(index=4, action_type=StepActionType.NAVIGATE, target_description="命令输入框", value="/nVA02"),
            TestStep(index=5, action_type=StepActionType.CLICK, target_description="回车"),
        ]
        result = _dedup_navigate_enter(steps)

        assert len(result) == 3
        assert [s.index for s in result] == [1, 2, 3]

    def test_empty_list(self):
        """空列表不报错。"""
        assert _dedup_navigate_enter([]) == []

    def test_navigate_at_end(self):
        """navigate 在末尾（无后续步骤）不报错。"""
        steps = [
            TestStep(index=1, action_type=StepActionType.INPUT, target_description="字段", value="值"),
            TestStep(index=2, action_type=StepActionType.NAVIGATE, target_description="命令输入框", value="/nVA01"),
        ]
        result = _dedup_navigate_enter(steps)

        assert len(result) == 2


class TestStepSplitterFlowVariables:
    """Flow_Variable 占位符保留测试"""

    @pytest.mark.asyncio
    async def test_preserves_flow_variable_placeholder(self, splitter, mock_glm_client):
        """步骤值中的 ${VAR_NAME} 占位符应被保留。"""
        mock_glm_client.split_steps.return_value = [
            TestStep(
                index=1,
                action_type=StepActionType.INPUT,
                target_description="订单号",
                value="${ORDER_NO}",
            ),
        ]
        tc = _make_test_case()

        steps = await splitter.split(tc)

        assert steps[0].value == "${ORDER_NO}"
        assert steps[0].flow_variable_ref == "ORDER_NO"

    @pytest.mark.asyncio
    async def test_preserves_existing_flow_variable_ref(self, splitter, mock_glm_client):
        """如果 AI 已设置 flow_variable_ref，应保留。"""
        mock_glm_client.split_steps.return_value = [
            TestStep(
                index=1,
                action_type=StepActionType.INPUT,
                target_description="订单号",
                value="${ORDER_NO}",
                flow_variable_ref="ORDER_NO",
            ),
        ]
        tc = _make_test_case()

        steps = await splitter.split(tc)

        assert steps[0].flow_variable_ref == "ORDER_NO"


class TestStepSplitterReindexing:
    """步骤重新编号测试"""

    @pytest.mark.asyncio
    async def test_reindexes_after_dedup(self, splitter, mock_glm_client):
        """去重后步骤应重新编号。"""
        mock_glm_client.split_steps.return_value = [
            TestStep(index=1, action_type=StepActionType.NAVIGATE, target_description="命令输入框", value="/nVF01"),
            TestStep(index=2, action_type=StepActionType.CLICK, target_description="回车"),  # 会被去重
            TestStep(index=3, action_type=StepActionType.INPUT, target_description="a", value="1"),
            TestStep(index=4, action_type=StepActionType.CLICK, target_description="b"),
        ]
        tc = _make_test_case(transaction_code="VF01")

        steps = await splitter.split(tc)

        assert [s.index for s in steps] == [1, 2, 3]

    @pytest.mark.asyncio
    async def test_reindexes_without_navigation(self, splitter, mock_glm_client):
        """无导航步骤时，AI 步骤从 1 开始编号。"""
        mock_glm_client.split_steps.return_value = [
            TestStep(index=5, action_type=StepActionType.INPUT, target_description="a", value="1"),
            TestStep(index=10, action_type=StepActionType.CLICK, target_description="b"),
        ]
        tc = _make_test_case(transaction_code=None)

        steps = await splitter.split(tc)

        assert [s.index for s in steps] == [1, 2]


class TestStepSplitterGlmCall:
    """GLM 调用测试"""

    @pytest.mark.asyncio
    async def test_calls_glm_with_steps_text(self, splitter, mock_glm_client):
        """应将 test_case.steps_text 传递给 glm_client.split_steps()。"""
        mock_glm_client.split_steps.return_value = []
        tc = _make_test_case(steps_text="输入销售组织1310，点击保存")

        await splitter.split(tc)

        mock_glm_client.split_steps.assert_called_once_with("输入销售组织1310，点击保存", test_data={})

    @pytest.mark.asyncio
    async def test_empty_glm_response(self, splitter, mock_glm_client):
        """GLM 返回空列表时，结果为空。"""
        mock_glm_client.split_steps.return_value = []
        tc = _make_test_case(transaction_code="VA01")

        steps = await splitter.split(tc)

        assert len(steps) == 0
