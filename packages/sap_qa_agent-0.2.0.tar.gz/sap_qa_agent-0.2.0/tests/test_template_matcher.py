"""Tests for TemplateMatcher."""

from unittest.mock import MagicMock

from app.core.template_matcher import MatchResult, TemplateMatcher
from app.data.models import ScriptTemplate, TemplateConfidence


def _make_template(confidence: TemplateConfidence) -> ScriptTemplate:
    return ScriptTemplate(
        template_id="tpl_test",
        transaction_code="VA01",
        scenario_type="标准订单",
        script_content="# script",
        element_path_map={},
        parameters=[],
        confidence=confidence,
    )


class TestTemplateMatcher:
    def test_no_match_returns_exploration(self):
        kb = MagicMock()
        kb.match_template.return_value = None
        matcher = TemplateMatcher(kb)

        result = matcher.match("VA01", "标准订单")

        assert not result.matched
        assert result.mode == "exploration"
        assert result.template is None

    def test_stable_match_returns_reuse(self):
        tpl = _make_template(TemplateConfidence.STABLE)
        kb = MagicMock()
        kb.match_template.return_value = tpl
        matcher = TemplateMatcher(kb)

        result = matcher.match("VA01", "标准订单")

        assert result.matched
        assert result.mode == "reuse"
        assert result.template is tpl
        assert result.confidence_warning is None

    def test_draft_match_returns_reuse_with_warning(self):
        tpl = _make_template(TemplateConfidence.DRAFT)
        kb = MagicMock()
        kb.match_template.return_value = tpl
        matcher = TemplateMatcher(kb)

        result = matcher.match("VA01", "标准订单")

        assert result.matched
        assert result.mode == "reuse"
        assert result.confidence_warning is not None

    def test_needs_fix_returns_exploration(self):
        tpl = _make_template(TemplateConfidence.NEEDS_FIX)
        kb = MagicMock()
        kb.match_template.return_value = tpl
        matcher = TemplateMatcher(kb)

        result = matcher.match("VA01", "标准订单")

        assert result.matched
        assert result.mode == "exploration"
        assert result.confidence_warning is not None
