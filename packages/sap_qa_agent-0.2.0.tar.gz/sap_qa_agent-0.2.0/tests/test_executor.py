"""Agent TARS 执行器单元测试"""

import asyncio
import json
from unittest.mock import AsyncMock, patch, MagicMock

import pytest

from app.executor import AgentTarsExecutor, ExecutionResult
from app.models import StepInfo


class TestBuildPrompt:
    """测试 build_prompt 指令拼接方法"""

    def setup_method(self):
        self.executor = AgentTarsExecutor()

    def test_single_step(self):
        steps = [StepInfo(index=1, description="打开浏览器")]
        result = self.executor.build_prompt(steps)
        assert result == "请依次完成以下操作：\n1. 打开浏览器"

    def test_multiple_steps(self):
        steps = [
            StepInfo(index=1, description="打开浏览器"),
            StepInfo(index=2, description="点击登录按钮"),
            StepInfo(index=3, description="输入用户名"),
        ]
        result = self.executor.build_prompt(steps)
        assert "请依次完成以下操作：" in result
        assert "1. 打开浏览器" in result
        assert "2. 点击登录按钮" in result
        assert "3. 输入用户名" in result

    def test_empty_steps(self):
        result = self.executor.build_prompt([])
        assert result == ""

    def test_preserves_order(self):
        steps = [
            StepInfo(index=1, description="第一步"),
            StepInfo(index=2, description="第二步"),
            StepInfo(index=3, description="第三步"),
        ]
        result = self.executor.build_prompt(steps)
        idx_first = result.index("第一步")
        idx_second = result.index("第二步")
        idx_third = result.index("第三步")
        assert idx_first < idx_second < idx_third

    def test_all_descriptions_included(self):
        steps = [
            StepInfo(index=1, description="访问网站"),
            StepInfo(index=2, description="填写表单"),
        ]
        result = self.executor.build_prompt(steps)
        for step in steps:
            assert step.description in result


class TestParseOutput:
    """测试 _parse_json_output 输出解析方法"""

    def setup_method(self):
        self.executor = AgentTarsExecutor()

    def test_parse_valid_json_output(self):
        import json
        data = {
            "sessionId": "abc123",
            "result": {"content": "任务完成", "finishReason": "stop"},
            "logs": ["log1", "log2"],
        }
        stdout = json.dumps(data)
        result = self.executor._parse_json_output(stdout)
        assert result.success is True
        assert result.session_id == "abc123"
        assert result.result_content == "任务完成"
        assert result.step_logs == ["log1", "log2"]

    def test_parse_non_json_fallback(self):
        stdout = "Step 1 completed\nStep 2 completed\nDone\n"
        result = self.executor._parse_json_output(stdout)
        assert result.success is True
        assert result.stdout == stdout
        assert len(result.step_logs) == 3

    def test_parse_empty_output(self):
        result = self.executor._parse_json_output("")
        assert result.success is True
        assert result.step_logs == []

    def test_parse_json_output_returns_execution_result(self):
        result = self.executor._parse_json_output("some output")
        assert isinstance(result, ExecutionResult)


class TestExecute:
    """测试 execute 异步执行方法"""

    def setup_method(self):
        self.executor = AgentTarsExecutor()

    def _make_mock_process(self, returncode=0):
        """创建一个 mock 进程，returncode 在 _kill_process 后设置。"""
        mock_process = AsyncMock()
        mock_process.returncode = returncode
        mock_process.terminate = MagicMock()
        mock_process.kill = MagicMock()
        mock_process.wait = AsyncMock()
        return mock_process

    @pytest.mark.asyncio
    async def test_successful_execution(self):
        mock_process = self._make_mock_process(returncode=0)

        with patch("app.executor.asyncio.create_subprocess_exec", return_value=mock_process), \
             patch.object(self.executor, "_read_until_json_complete", return_value=("output\n", "")):
            result = await self.executor.execute("task-1", "test prompt")

        assert result.success is True
        assert result.return_code == 0
        assert "output" in result.stdout

    @pytest.mark.asyncio
    async def test_failed_execution(self):
        mock_process = self._make_mock_process(returncode=1)

        with patch("app.executor.asyncio.create_subprocess_exec", return_value=mock_process), \
             patch.object(self.executor, "_read_until_json_complete", return_value=("partial output", "error msg")):
            result = await self.executor.execute("task-1", "test prompt")

        assert result.success is False
        assert result.return_code == 1
        assert "error msg" in result.error

    @pytest.mark.asyncio
    async def test_command_not_found(self):
        with patch("app.executor.asyncio.create_subprocess_exec", side_effect=FileNotFoundError):
            result = await self.executor.execute("task-1", "test prompt")

        assert result.success is False
        assert "agent-tars" in result.error

    @pytest.mark.asyncio
    async def test_timeout(self):
        mock_process = self._make_mock_process()
        mock_process.kill = MagicMock()

        with patch("app.executor.asyncio.create_subprocess_exec", return_value=mock_process), \
             patch.object(self.executor, "_read_until_json_complete", side_effect=asyncio.TimeoutError):
            result = await self.executor.execute("task-1", "test prompt")

        assert result.success is False
        assert "超时" in result.error
        mock_process.kill.assert_called_once()

    def test_build_cmd_includes_model_params(self):
        """Verify _build_cmd includes model provider/id/apiKey/baseURL."""
        cmd = self.executor._build_cmd("test prompt")
        assert "--model.provider" in cmd
        assert "--model.id" in cmd
        assert "--model.apiKey" in cmd
        assert "--model.baseURL" in cmd
        assert "--input" in cmd
        assert "test prompt" in cmd

    @pytest.mark.asyncio
    async def test_uses_list_args_no_shell(self):
        """Verify CLI args are passed as list (no shell injection)"""
        mock_process = self._make_mock_process(returncode=0)

        with patch("app.executor.asyncio.create_subprocess_exec", return_value=mock_process) as mock_exec, \
             patch.object(self.executor, "_read_until_json_complete", return_value=("", "")):
            await self.executor.execute("task-1", "some; rm -rf /")

        call_args = mock_exec.call_args[0]
        assert call_args[0] == "agent-tars"
        assert call_args[1] == "run"
        assert call_args[2] == "--headless"
        assert call_args[3] == "--input"
        assert call_args[4] == "some; rm -rf /"


class TestReadUntilJsonComplete:
    """测试 _read_until_json_complete 方法"""

    def setup_method(self):
        self.executor = AgentTarsExecutor()

    @pytest.mark.asyncio
    async def test_detects_complete_json(self):
        """完整 JSON 输出后应立即返回。"""
        import json
        data = {"sessionId": "abc", "result": {"content": "done"}}
        json_str = json.dumps(data) + "\n"

        mock_stdout = AsyncMock()
        lines = [line.encode() for line in json_str.splitlines(keepends=True)]
        lines.append(b"")  # EOF sentinel
        mock_stdout.readline = AsyncMock(side_effect=lines)

        mock_stderr = AsyncMock()
        mock_stderr.read = AsyncMock(return_value=b"")

        mock_process = AsyncMock()
        mock_process.stdout = mock_stdout
        mock_process.stderr = mock_stderr

        stdout, stderr = await self.executor._read_until_json_complete(mock_process)
        assert "sessionId" in stdout
        assert "abc" in stdout

    @pytest.mark.asyncio
    async def test_handles_multiline_json(self):
        """多行 JSON 也能正确检测闭合。"""
        json_lines = '{\n  "sessionId": "x",\n  "result": {}\n}\n'

        mock_stdout = AsyncMock()
        lines = [line.encode() for line in json_lines.splitlines(keepends=True)]
        lines.append(b"")
        mock_stdout.readline = AsyncMock(side_effect=lines)

        mock_stderr = AsyncMock()
        mock_stderr.read = AsyncMock(return_value=b"")

        mock_process = AsyncMock()
        mock_process.stdout = mock_stdout
        mock_process.stderr = mock_stderr

        stdout, _ = await self.executor._read_until_json_complete(mock_process)
        parsed = json.loads(stdout)
        assert parsed["sessionId"] == "x"

    @pytest.mark.asyncio
    async def test_handles_eof_without_json(self):
        """进程直接 EOF（非 JSON 输出）也能正常返回。"""
        mock_stdout = AsyncMock()
        mock_stdout.readline = AsyncMock(side_effect=[b"some text\n", b"more\n", b""])

        mock_stderr = AsyncMock()
        mock_stderr.read = AsyncMock(return_value=b"err")

        mock_process = AsyncMock()
        mock_process.stdout = mock_stdout
        mock_process.stderr = mock_stderr

        stdout, stderr = await self.executor._read_until_json_complete(mock_process)
        assert "some text" in stdout
        assert stderr == "err"
