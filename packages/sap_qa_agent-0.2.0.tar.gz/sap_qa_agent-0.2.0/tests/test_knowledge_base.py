"""KnowledgeBase 单元测试"""

import json
import os
import tempfile

import pytest

from app.data.knowledge_base import KnowledgeBase, TemplateInfo
from app.data.models import ScriptTemplate, TemplateConfidence


def _make_template(
    template_id: str = "tpl_001",
    transaction_code: str = "VA01",
    scenario_type: str = "标准订单",
    confidence: TemplateConfidence = TemplateConfidence.DRAFT,
    consecutive_success_count: int = 0,
) -> ScriptTemplate:
    return ScriptTemplate(
        template_id=template_id,
        transaction_code=transaction_code,
        scenario_type=scenario_type,
        script_content="# test script",
        element_path_map={"字段A": "wnd[0]/usr/ctxtA"},
        parameters=["字段A"],
        confidence=confidence,
        consecutive_success_count=consecutive_success_count,
    )


@pytest.fixture()
def kb(tmp_path):
    """Create a KnowledgeBase backed by a temp directory."""
    return KnowledgeBase(storage_path=str(tmp_path))


# ---- match_template ----


class TestMatchTemplate:
    def test_no_match_returns_none(self, kb: KnowledgeBase):
        assert kb.match_template("VA01", "标准订单") is None

    def test_exact_match(self, kb: KnowledgeBase):
        tpl = _make_template()
        kb.save_template(tpl)
        result = kb.match_template("VA01", "标准订单")
        assert result is not None
        assert result.template_id == "tpl_001"
        assert result.transaction_code == "VA01"

    def test_different_scenario_no_match(self, kb: KnowledgeBase):
        kb.save_template(_make_template(scenario_type="标准订单"))
        assert kb.match_template("VA01", "退货订单") is None

    def test_different_transaction_no_match(self, kb: KnowledgeBase):
        kb.save_template(_make_template(transaction_code="VA01"))
        assert kb.match_template("VA02", "标准订单") is None


# ---- save_template ----


class TestSaveTemplate:
    def test_save_persists_to_file(self, kb: KnowledgeBase, tmp_path):
        kb.save_template(_make_template())
        file_path = os.path.join(str(tmp_path), "templates.json")
        assert os.path.exists(file_path)
        with open(file_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        assert "VA01_标准订单" in data["templates"]
        assert data["metadata"]["total_templates"] == 1

    def test_save_overwrites_existing(self, kb: KnowledgeBase):
        kb.save_template(_make_template(consecutive_success_count=0))
        kb.save_template(_make_template(consecutive_success_count=5))
        result = kb.match_template("VA01", "标准订单")
        assert result is not None
        assert result.consecutive_success_count == 5

    def test_save_multiple_templates(self, kb: KnowledgeBase):
        kb.save_template(_make_template(template_id="t1", transaction_code="VA01"))
        kb.save_template(_make_template(template_id="t2", transaction_code="VA02"))
        assert len(kb.list_templates()) == 2


# ---- update_confidence ----


class TestUpdateConfidence:
    def test_draft_success_increments_count(self, kb: KnowledgeBase):
        kb.save_template(_make_template(confidence=TemplateConfidence.DRAFT))
        kb.update_confidence("tpl_001", success=True)
        tpl = kb.match_template("VA01", "标准订单")
        assert tpl is not None
        assert tpl.consecutive_success_count == 1
        assert tpl.confidence == TemplateConfidence.DRAFT

    def test_draft_promotes_to_stable_at_threshold(self, kb: KnowledgeBase):
        kb.save_template(
            _make_template(
                confidence=TemplateConfidence.DRAFT,
                consecutive_success_count=2,
            )
        )
        # 3rd consecutive success → should promote (threshold=3)
        kb.update_confidence("tpl_001", success=True)
        tpl = kb.match_template("VA01", "标准订单")
        assert tpl is not None
        assert tpl.confidence == TemplateConfidence.STABLE

    def test_stable_failure_demotes_to_draft(self, kb: KnowledgeBase):
        kb.save_template(_make_template(confidence=TemplateConfidence.STABLE))
        kb.update_confidence("tpl_001", success=False)
        tpl = kb.match_template("VA01", "标准订单")
        assert tpl is not None
        assert tpl.confidence == TemplateConfidence.DRAFT
        assert tpl.consecutive_success_count == 0

    def test_draft_failure_demotes_to_needs_fix(self, kb: KnowledgeBase):
        kb.save_template(_make_template(confidence=TemplateConfidence.DRAFT))
        kb.update_confidence("tpl_001", success=False)
        tpl = kb.match_template("VA01", "标准订单")
        assert tpl is not None
        assert tpl.confidence == TemplateConfidence.NEEDS_FIX

    def test_needs_fix_failure_stays_needs_fix(self, kb: KnowledgeBase):
        kb.save_template(_make_template(confidence=TemplateConfidence.NEEDS_FIX))
        kb.update_confidence("tpl_001", success=False)
        tpl = kb.match_template("VA01", "标准订单")
        assert tpl is not None
        assert tpl.confidence == TemplateConfidence.NEEDS_FIX

    def test_needs_fix_success_resets_to_draft(self, kb: KnowledgeBase):
        kb.save_template(_make_template(confidence=TemplateConfidence.NEEDS_FIX))
        kb.update_confidence("tpl_001", success=True)
        tpl = kb.match_template("VA01", "标准订单")
        assert tpl is not None
        assert tpl.confidence == TemplateConfidence.DRAFT
        assert tpl.consecutive_success_count == 1

    def test_unknown_template_id_is_noop(self, kb: KnowledgeBase):
        kb.save_template(_make_template())
        kb.update_confidence("nonexistent", success=True)
        # original template unchanged
        tpl = kb.match_template("VA01", "标准订单")
        assert tpl is not None
        assert tpl.consecutive_success_count == 0

    def test_success_updates_last_success_at(self, kb: KnowledgeBase):
        kb.save_template(_make_template())
        kb.update_confidence("tpl_001", success=True)
        tpl = kb.match_template("VA01", "标准订单")
        assert tpl is not None
        assert tpl.last_success_at is not None


# ---- update_element_paths ----


class TestRecordPathCorrection:
    def test_records_correction(self, kb: KnowledgeBase):
        kb.save_template(_make_template())
        correction = {
            "step_description": "[input] 销售组织",
            "original_path": "wnd[0]/usr/ctxtOld",
            "corrected_path": "wnd[0]/usr/ctxtNew",
            "match_method": "retry",
            "screen_context": "创建销售订单",
        }
        kb.record_path_correction("tpl_001", correction)
        tpl = kb.match_template("VA01", "标准订单")
        assert tpl is not None
        assert len(tpl.path_corrections) == 1
        pc = tpl.path_corrections[0]
        assert pc.original_path == "wnd[0]/usr/ctxtOld"
        assert pc.corrected_path == "wnd[0]/usr/ctxtNew"
        assert pc.match_method == "retry"
        assert pc.context == "创建销售订单"

    def test_appends_multiple_corrections(self, kb: KnowledgeBase):
        kb.save_template(_make_template())
        for i in range(3):
            kb.record_path_correction("tpl_001", {
                "original_path": f"old_{i}",
                "corrected_path": f"new_{i}",
                "match_method": "retry",
                "screen_context": "ctx",
            })
        tpl = kb.match_template("VA01", "标准订单")
        assert tpl is not None
        assert len(tpl.path_corrections) == 3

    def test_unknown_template_id_is_noop(self, kb: KnowledgeBase):
        kb.save_template(_make_template())
        kb.record_path_correction("nonexistent", {
            "original_path": "a",
            "corrected_path": "b",
            "match_method": "retry",
            "screen_context": "",
        })
        tpl = kb.match_template("VA01", "标准订单")
        assert tpl is not None
        assert len(tpl.path_corrections) == 0

    def test_persists_to_disk(self, tmp_path):
        kb1 = KnowledgeBase(storage_path=str(tmp_path))
        kb1.save_template(_make_template())
        kb1.record_path_correction("tpl_001", {
            "original_path": "old",
            "corrected_path": "new",
            "match_method": "retry",
            "screen_context": "ctx",
        })
        kb2 = KnowledgeBase(storage_path=str(tmp_path))
        tpl = kb2.match_template("VA01", "标准订单")
        assert tpl is not None
        assert len(tpl.path_corrections) == 1
        assert tpl.path_corrections[0].corrected_path == "new"


class TestUpdateElementPaths:
    def test_updates_paths(self, kb: KnowledgeBase):
        kb.save_template(_make_template())
        kb.update_element_paths("tpl_001", {"字段B": "wnd[0]/usr/ctxtB"})
        tpl = kb.match_template("VA01", "标准订单")
        assert tpl is not None
        assert tpl.element_path_map["字段B"] == "wnd[0]/usr/ctxtB"
        # original path preserved
        assert tpl.element_path_map["字段A"] == "wnd[0]/usr/ctxtA"

    def test_overwrites_existing_path(self, kb: KnowledgeBase):
        kb.save_template(_make_template())
        kb.update_element_paths("tpl_001", {"字段A": "wnd[0]/usr/newA"})
        tpl = kb.match_template("VA01", "标准订单")
        assert tpl is not None
        assert tpl.element_path_map["字段A"] == "wnd[0]/usr/newA"

    def test_unknown_template_id_is_noop(self, kb: KnowledgeBase):
        kb.save_template(_make_template())
        kb.update_element_paths("nonexistent", {"x": "y"})
        tpl = kb.match_template("VA01", "标准订单")
        assert tpl is not None
        assert "x" not in tpl.element_path_map


# ---- list_templates ----


class TestListTemplates:
    def test_empty_kb(self, kb: KnowledgeBase):
        assert kb.list_templates() == []

    def test_returns_template_info(self, kb: KnowledgeBase):
        kb.save_template(_make_template())
        infos = kb.list_templates()
        assert len(infos) == 1
        info = infos[0]
        assert isinstance(info, TemplateInfo)
        assert info.template_id == "tpl_001"
        assert info.transaction_code == "VA01"
        assert info.scenario_type == "标准订单"
        assert info.confidence == TemplateConfidence.DRAFT


# ---- persistence round-trip ----


class TestPersistence:
    def test_reload_from_disk(self, tmp_path):
        kb1 = KnowledgeBase(storage_path=str(tmp_path))
        kb1.save_template(_make_template())

        kb2 = KnowledgeBase(storage_path=str(tmp_path))
        result = kb2.match_template("VA01", "标准订单")
        assert result is not None
        assert result.template_id == "tpl_001"

    def test_corrupted_file_falls_back_to_empty(self, tmp_path):
        file_path = os.path.join(str(tmp_path), "templates.json")
        os.makedirs(str(tmp_path), exist_ok=True)
        with open(file_path, "w") as f:
            f.write("not valid json{{{")
        kb = KnowledgeBase(storage_path=str(tmp_path))
        assert kb.list_templates() == []
