"""Tests for ExplorationEngine."""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from app.core.exploration_engine import ExplorationEngine, ExplorationResult
from app.data.models import (
    ElementInfo,
    ElementMatchResult,
    StepActionType,
    StepResult,
    TemplateConfidence,
    TestStep,
)


def _make_steps() -> list[TestStep]:
    return [
        TestStep(index=0, action_type=StepActionType.NAVIGATE, target_description="命令输入框", value="/nVA01"),
        TestStep(index=1, action_type=StepActionType.INPUT, target_description="销售组织", value="1000"),
    ]


def _make_engine(step_results: list[StepResult] | None = None):
    glm = AsyncMock()
    glm.generate_script.return_value = "# generated script"
    glm.analyze_exception.return_value = {"action": "abort", "reason": "test"}

    executor = AsyncMock()
    if step_results is None:
        step_results = [
            StepResult(step_index=0, success=True),
            StepResult(step_index=1, success=True),
        ]
    executor.execute_script.return_value = step_results

    element_finder = MagicMock()
    element_finder.find_element_by_description.return_value = ElementMatchResult(found=False)

    kb = MagicMock()

    engine = ExplorationEngine(glm, executor, element_finder, kb)
    return engine, glm, executor, element_finder, kb


@pytest.mark.asyncio
async def test_explore_success_solidifies_template():
    engine, glm, executor, _, kb = _make_engine()
    steps = _make_steps()

    result = await engine.explore(steps, flow_context=None)

    assert result.success
    assert result.template_solidified
    assert kb.save_template.called


@pytest.mark.asyncio
async def test_explore_failure_no_template():
    failed_results = [
        StepResult(step_index=0, success=True),
        StepResult(step_index=1, success=False, error_message="Click failed"),
    ]
    engine, glm, executor, _, kb = _make_engine(step_results=failed_results)
    steps = _make_steps()

    result = await engine.explore(steps, flow_context=None)

    assert not result.success
    assert not result.template_solidified
    assert not kb.save_template.called


@pytest.mark.asyncio
async def test_explore_script_generation_failure():
    engine, glm, executor, _, kb = _make_engine()
    glm.generate_script.side_effect = RuntimeError("GLM unavailable")
    steps = _make_steps()

    result = await engine.explore(steps, flow_context=None)

    assert not result.success
    assert len(result.step_results) == 1
    assert "Script generation failed" in result.step_results[0].error_message


@pytest.mark.asyncio
async def test_explore_path_correction():
    failed_results = [
        StepResult(step_index=0, success=True),
        StepResult(step_index=1, success=False, error_message="Element not found: xyz"),
    ]
    engine, glm, executor, element_finder, kb = _make_engine(step_results=failed_results)

    found_element = ElementInfo(
        id_path="wnd[0]/usr/ctxtVBAK-VKORG",
        element_type="GuiCTextField",
        tooltip="Sales Org",
        label_text="销售组织",
        current_value="",
    )
    element_finder.find_element_by_description.return_value = ElementMatchResult(
        found=True, element=found_element, match_method="label_exact"
    )

    steps = _make_steps()
    result = await engine.explore(steps, flow_context=None)

    assert len(result.path_corrections) == 1
    assert result.path_corrections[0].corrected_path == "wnd[0]/usr/ctxtVBAK-VKORG"


@pytest.mark.asyncio
async def test_solidify_template_creates_draft():
    engine, _, _, _, kb = _make_engine()
    steps = _make_steps()

    template = await engine.solidify_template("# script", [], steps)

    assert template.confidence == TemplateConfidence.DRAFT
    assert template.consecutive_success_count == 1
    assert template.transaction_code == "VA01"
    assert kb.save_template.called
