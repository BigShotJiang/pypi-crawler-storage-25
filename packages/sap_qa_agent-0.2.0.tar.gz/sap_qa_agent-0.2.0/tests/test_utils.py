"""文件名清理与校验工具函数单元测试"""

from app.utils import sanitize_filename, validate_file_extension


class TestSanitizeFilename:
    def test_normal_filename_unchanged(self):
        assert sanitize_filename("report.xlsx") == "report.xlsx"

    def test_removes_dot_dot(self):
        result = sanitize_filename("..report.xlsx")
        assert ".." not in result

    def test_removes_forward_slash(self):
        result = sanitize_filename("path/to/report.xlsx")
        assert "/" not in result
        assert result == "report.xlsx"

    def test_removes_backslash(self):
        result = sanitize_filename("path\\to\\report.xlsx")
        assert "\\" not in result

    def test_removes_path_traversal_sequence(self):
        result = sanitize_filename("../../etc/passwd")
        assert ".." not in result
        assert "/" not in result

    def test_complex_traversal(self):
        result = sanitize_filename("../../../uploads/../secret.xlsx")
        assert ".." not in result
        assert "/" not in result

    def test_empty_string(self):
        result = sanitize_filename("")
        assert result == ""

    def test_only_traversal_chars(self):
        result = sanitize_filename("../../")
        assert ".." not in result
        assert "/" not in result

    def test_mixed_separators(self):
        result = sanitize_filename("..\\..\\uploads/file.xlsx")
        assert ".." not in result
        assert "/" not in result
        assert "\\" not in result


class TestValidateFileExtension:
    def test_xlsx_accepted(self):
        assert validate_file_extension("report.xlsx") is True

    def test_xls_accepted(self):
        assert validate_file_extension("report.xls") is True

    def test_uppercase_xlsx_accepted(self):
        assert validate_file_extension("report.XLSX") is True

    def test_uppercase_xls_accepted(self):
        assert validate_file_extension("report.XLS") is True

    def test_csv_rejected(self):
        assert validate_file_extension("data.csv") is False

    def test_txt_rejected(self):
        assert validate_file_extension("notes.txt") is False

    def test_no_extension_rejected(self):
        assert validate_file_extension("noext") is False

    def test_empty_string_rejected(self):
        assert validate_file_extension("") is False

    def test_pdf_rejected(self):
        assert validate_file_extension("doc.pdf") is False

    def test_double_extension_uses_last(self):
        assert validate_file_extension("file.csv.xlsx") is True

    def test_dot_only_rejected(self):
        assert validate_file_extension(".") is False
