"""Tests for ResultVerifier."""

from unittest.mock import MagicMock

from app.core.result_verifier import ResultVerifier
from app.data.models import StepResult, TestCase, TestCaseType


def _make_normal_case(expected_results: list[str] | None = None) -> TestCase:
    return TestCase(
        case_id="TC-001",
        purpose="Test",
        preconditions="",
        steps_text="Step 1",
        test_data={},
        expected_results=expected_results if expected_results is not None else ["已保存"],
        ai_notes="",
        case_type=TestCaseType.NORMAL,
    )


def _make_expected_failure_case(expected_results: list[str] | None = None) -> TestCase:
    return TestCase(
        case_id="TC-002",
        purpose="Expected failure test",
        preconditions="",
        steps_text="Step 1",
        test_data={},
        expected_results=expected_results if expected_results is not None else ["交货单未发货"],
        ai_notes="",
        case_type=TestCaseType.EXPECTED_FAILURE,
    )


class TestResultVerifierNormal:
    def test_status_bar_exact_match(self):
        verifier = ResultVerifier(MagicMock())
        case = _make_normal_case(["已保存"])
        step_results = [StepResult(step_index=0, success=True, status_bar_message="已保存")]

        results = verifier.verify_expected_results(case, step_results)

        assert len(results) == 1
        assert results[0].passed

    def test_status_bar_contains_match(self):
        verifier = ResultVerifier(MagicMock())
        case = _make_normal_case(["已保存"])
        step_results = [StepResult(step_index=0, success=True, status_bar_message="凭证 12345 已保存")]

        results = verifier.verify_expected_results(case, step_results)

        assert len(results) == 1
        assert results[0].passed

    def test_status_bar_no_match(self):
        verifier = ResultVerifier(MagicMock())
        case = _make_normal_case(["已保存"])
        step_results = [StepResult(step_index=0, success=True, status_bar_message="输入无效")]

        results = verifier.verify_expected_results(case, step_results)

        assert len(results) == 1
        assert not results[0].passed

    def test_no_status_messages(self):
        verifier = ResultVerifier(MagicMock())
        case = _make_normal_case(["已保存"])
        step_results = [StepResult(step_index=0, success=True)]

        results = verifier.verify_expected_results(case, step_results)

        assert len(results) == 1
        assert not results[0].passed

    def test_no_expected_results_all_success(self):
        verifier = ResultVerifier(MagicMock())
        case = _make_normal_case([])
        step_results = [StepResult(step_index=0, success=True)]

        results = verifier.verify_expected_results(case, step_results)

        assert len(results) == 1
        assert results[0].passed


class TestResultVerifierExpectedFailure:
    def test_failure_occurred_is_pass(self):
        """Expected_Failure: error occurred → PASS"""
        verifier = ResultVerifier(MagicMock())
        case = _make_expected_failure_case(["交货单未发货"])
        step_results = [
            StepResult(step_index=0, success=False, error_message="交货单未发货，无法创建开票文档"),
        ]

        results = verifier.verify_expected_results(case, step_results)

        assert len(results) == 1
        assert results[0].passed

    def test_success_is_fail(self):
        """Expected_Failure: operation succeeded → FAIL"""
        verifier = ResultVerifier(MagicMock())
        case = _make_expected_failure_case(["交货单未发货"])
        step_results = [
            StepResult(step_index=0, success=True, status_bar_message="开票文档已创建"),
        ]

        results = verifier.verify_expected_results(case, step_results)

        assert len(results) == 1
        assert not results[0].passed

    def test_no_expected_results_failure_is_pass(self):
        """Expected_Failure with no specific expected results: any failure → PASS"""
        verifier = ResultVerifier(MagicMock())
        case = _make_expected_failure_case([])
        step_results = [StepResult(step_index=0, success=False, error_message="Some error")]

        results = verifier.verify_expected_results(case, step_results)

        assert len(results) == 1
        assert results[0].passed

    def test_no_expected_results_success_is_fail(self):
        """Expected_Failure with no specific expected results: success → FAIL"""
        verifier = ResultVerifier(MagicMock())
        case = _make_expected_failure_case([])
        step_results = [StepResult(step_index=0, success=True)]

        results = verifier.verify_expected_results(case, step_results)

        assert len(results) == 1
        assert not results[0].passed


class TestResultVerifierDataConsistency:
    def test_data_consistency_match(self):
        verifier = ResultVerifier(MagicMock())
        expected = {"field_a": "100", "field_b": "200"}
        actual = {"field_a": "100", "field_b": "200"}

        results = verifier.verify_data_consistency(expected, actual)

        assert len(results) == 2
        assert all(r.passed for r in results)

    def test_data_consistency_mismatch(self):
        verifier = ResultVerifier(MagicMock())
        expected = {"field_a": "100"}
        actual = {"field_a": "999"}

        results = verifier.verify_data_consistency(expected, actual)

        assert len(results) == 1
        assert not results[0].passed
