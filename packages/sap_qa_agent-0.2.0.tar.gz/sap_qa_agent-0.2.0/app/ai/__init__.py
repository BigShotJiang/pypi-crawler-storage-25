"""AI layer modules for GLM integration."""
