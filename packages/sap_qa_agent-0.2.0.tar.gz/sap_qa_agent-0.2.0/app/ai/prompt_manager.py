"""Prompt 模板管理器 — 统一管理和渲染所有 AI Prompt 模板。"""

from app.prompts.step_split import STEP_SPLIT_PROMPT
from app.prompts.script_generate import SCRIPT_GENERATE_PROMPT
from app.prompts.element_match import ELEMENT_MATCH_PROMPT
from app.prompts.exception_handle import EXCEPTION_HANDLE_PROMPT
from app.prompts.failure_analysis import FAILURE_ANALYSIS_PROMPT
from app.prompts.recovery_plan import RECOVERY_PLAN_PROMPT
from app.prompts.dialog_analyze import DIALOG_ANALYZE_PROMPT
from app.prompts.recovery_script import RECOVERY_SCRIPT_PROMPT
from app.prompts.batch_recovery import BATCH_RECOVERY_PROMPT
from app.prompts.verify_result import VERIFY_RESULT_PROMPT
from app.prompts.step_adjust import STEP_ADJUST_PROMPT


class PromptManager:
    """统一管理和渲染 Prompt 模板。

    每个 render_* 方法使用 str.format() 将变量填充到对应模板中。
    """

    def render_step_split(
        self,
        transaction_code: str,
        steps_text: str,
        test_data: str,
    ) -> str:
        """渲染步骤拆分 Prompt。"""
        return STEP_SPLIT_PROMPT.format(
            transaction_code=transaction_code,
            steps_text=steps_text,
            test_data=test_data,
        )

    def render_script_generate(self, test_steps_json: str, screen_elements: str = "") -> str:
        """渲染脚本生成 Prompt。"""
        return SCRIPT_GENERATE_PROMPT.format(
            test_steps_json=test_steps_json,
            screen_elements=screen_elements or "（未采集，请根据 SAP 标准命名规则推测）",
        )

    def render_element_match(
        self,
        target_description: str,
        step_context: str,
        window_context: str,
        candidates_json: str,
    ) -> str:
        """渲染元素匹配 Prompt。"""
        return ELEMENT_MATCH_PROMPT.format(
            target_description=target_description,
            step_context=step_context,
            window_context=window_context,
            candidates_json=candidates_json,
        )

    def render_exception_handle(
        self,
        error_info: str,
        current_step: str,
        ui_state: str,
        status_bar_message: str,
        dialog_content: str,
    ) -> str:
        """渲染异常处理 Prompt。"""
        return EXCEPTION_HANDLE_PROMPT.format(
            error_info=error_info,
            current_step=current_step,
            ui_state=ui_state,
            status_bar_message=status_bar_message,
            dialog_content=dialog_content,
        )

    def render_failure_analysis(
        self,
        step_description: str,
        error_message: str,
        status_bar_message: str,
        screenshot_description: str,
    ) -> str:
        """渲染失败根因分析 Prompt。"""
        return FAILURE_ANALYSIS_PROMPT.format(
            step_description=step_description,
            error_message=error_message,
            status_bar_message=status_bar_message,
            screenshot_description=screenshot_description,
        )

    def render_recovery_plan(
        self,
        step_description: str,
        error_info: str,
        screen_snapshot: str,
        retry_history: str,
    ) -> str:
        """渲染 Recovery_Plan 生成 Prompt。"""
        return RECOVERY_PLAN_PROMPT.format(
            step_description=step_description,
            error_info=error_info,
            screen_snapshot=screen_snapshot,
            retry_history=retry_history,
        )

    def render_dialog_analyze(
        self,
        dialog_title: str,
        dialog_text: str,
    ) -> str:
        """渲染弹窗分析 Prompt。"""
        return DIALOG_ANALYZE_PROMPT.format(
            dialog_title=dialog_title,
            dialog_text=dialog_text,
        )

    def render_recovery_script(
        self,
        test_case_context: str,
        step_index: int,
        action_type: str,
        target_description: str,
        value: str,
        error_message: str,
        completed_steps: str,
        window_title: str,
        status_bar: str,
        screen_elements: str,
        fingerprint_info: str = "",
    ) -> str:
        """渲染修复脚本生成 Prompt。"""
        return RECOVERY_SCRIPT_PROMPT.format(
            test_case_context=test_case_context,
            step_index=step_index,
            action_type=action_type,
            target_description=target_description,
            value=value or "",
            error_message=error_message,
            completed_steps=completed_steps,
            window_title=window_title,
            status_bar=status_bar,
            screen_elements=screen_elements,
            fingerprint_info=fingerprint_info or "无指纹信息",
        )

    def render_batch_recovery(
        self,
        test_case_context: str,
        batch_steps: str,
        completed_steps: str,
        window_title: str,
        status_bar: str,
        screen_elements: str,
    ) -> str:
        """渲染批量修复脚本生成 Prompt。"""
        return BATCH_RECOVERY_PROMPT.format(
            test_case_context=test_case_context,
            batch_steps=batch_steps,
            completed_steps=completed_steps,
            window_title=window_title,
            status_bar=status_bar,
            screen_elements=screen_elements,
        )

    def render_verify_result(
        self,
        expected: str,
        window_title: str,
        status_bar: str,
        screen_elements: str,
    ) -> str:
        """渲染验证结果判断 Prompt。"""
        return VERIFY_RESULT_PROMPT.format(
            expected=expected,
            window_title=window_title,
            status_bar=status_bar,
            screen_elements=screen_elements or "（未采集）",
        )

    def render_step_adjust(
        self,
        test_case_context: str,
        window_title: str,
        status_bar: str,
        screen_elements: str,
        original_steps: str,
    ) -> str:
        """渲染步骤动态调整 Prompt。"""
        return STEP_ADJUST_PROMPT.format(
            test_case_context=test_case_context,
            window_title=window_title,
            status_bar=status_bar,
            screen_elements=screen_elements or "（未采集）",
            original_steps=original_steps,
        )
