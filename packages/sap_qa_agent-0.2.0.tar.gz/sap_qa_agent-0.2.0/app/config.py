"""应用配置常量"""

import os

# 上传文件存储目录
UPLOAD_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "uploads")

# 执行产物存储目录（截图、日志等）
ARTIFACTS_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "artifacts")

# 上传文件大小限制（10MB）
MAX_FILE_SIZE = 10 * 1024 * 1024

# 允许的文件扩展名
ALLOWED_EXTENSIONS = {".xlsx", ".xls"}

# Agent TARS 执行超时时间（秒）
AGENT_TARS_TIMEOUT = 600

# Agent TARS 模型配置
# AGENT_TARS_PROVIDER = "volcengine"
# AGENT_TARS_MODEL = "doubao-seed-2-0-pro-260215"
# AGENT_TARS_API_KEY = "3953ba73-9928-45c9-ad63-38b7cb388ded"
# AGENT_TARS_BASE_URL = "https://ark.cn-beijing.volces.com/api/v3"

# AGENT_TARS_PROVIDER = "volcengine"
# AGENT_TARS_MODEL = "doubao-1-5-ui-tars-250428"
# AGENT_TARS_API_KEY = "3953ba73-9928-45c9-ad63-38b7cb388ded"

AGENT_TARS_PROVIDER = "openai"
AGENT_TARS_MODEL = "qwen3-vl-30b-a3b-instruct"
AGENT_TARS_API_KEY = "not-needed"
# AGENT_TARS_MODEL = "ui-tars-7b-dpo"
# AGENT_TARS_API_KEY = "not-needed"
# AGENT_TARS_PROVIDER = "volcengine"
# AGENT_TARS_MODEL = "ui-tars-1.5-7b"
# AGENT_TARS_API_KEY = "not-needed"
# AGENT_TARS_PROVIDER = "openai"
# AGENT_TARS_MODEL = "ui-tars-1.5-7b"
# AGENT_TARS_API_KEY = "not-needed"
AGENT_TARS_BASE_URL = "http://localhost:8001/v1"

# AGENT_TARS_MODEL = "glm-4.7"
# AGENT_TARS_API_KEY = "b263f9b767af4608803d03cfed0c4cde.LaJz20qMqF5vlbE2"
# AGENT_TARS_BASE_URL = "https://open.bigmodel.cn/api/coding/paas/v4"
# 浏览器控制模式: "dom" | "visual-grounding" | "hybrid"

# AGENT_TARS_MODEL = "qwen3.5-plus"
# AGENT_TARS_BASE_URL = "https://dashscope.aliyuncs.com/compatible-mode/v1"
# AGENT_TARS_API_KEY = "sk-a23b847f06a74ab99f33f92c9924f0b3"

AGENT_TARS_BROWSER_CONTROL = "dom"



# 最大并发执行任务数（agent-tars 会占用浏览器，通常只能串行）
MAX_CONCURRENT_TASKS = 1

# ---- VLM 自研执行器配置 ----
# 每个步骤最大重试次数（VLM 返回动作后执行，未 done 则重试）
VLM_MAX_RETRIES_PER_STEP = 15
# 执行动作后等待时间（秒），等界面响应
VLM_ACTION_DELAY = 1.5
# 截屏前等待时间（秒）
VLM_SCREENSHOT_DELAY = 0.5
# 单步超时（秒）
VLM_STEP_TIMEOUT = 120

# 前端开发服务器地址（CORS 配置用）
FRONTEND_DEV_URL = "http://localhost:5173"

# FastAPI 后端（`sap-qa-backend` 脚本入口 / Uvicorn）启动参数
BACKEND_HOST = "0.0.0.0"
BACKEND_PORT = 8000

# ---- 目标客户端配置 ----
# 切换测试目标时只需修改这里
TARGET_APP_PROCESS = "SAPGUI"       # macOS 进程名，用于窗口激活
TARGET_APP_LABEL = "sap"            # 用于加载对应的 prompt 文件（sap / car）
TARGET_SAVE_HOTKEY = ["ctrl", "s"]  # 保存快捷键（SAP macOS 用 Ctrl+S）

# ---- UI-TARS Grounding 配置 ----
# 主定位策略：
#   "uitars" → UI-TARS 优先定位，OCR 作为备选
#   "ocr"    → OCR+YOLO 优先定位，UI-TARS/VLM 作为 fallback（原方案）
#   "vlm"    → VLM page_map 定位，OCR/UI-TARS 作为 fallback
GROUNDING_MODE = "ocr"
UITARS_BASE_URL = "http://localhost:8001/v1"
UITARS_MODEL = "ui-tars-7b-dpo"
UITARS_API_KEY = "not-needed"


# ---- SAP GUI 自动化测试框架配置 ----

# SAP GUI 安装路径
SAP_GUI_PATH = r"C:\Program Files (x86)\SAP\FrontEnd\SAPgui"
SAP_LOGON_EXE = os.path.join(SAP_GUI_PATH, "saplogon.exe")

# 知识库存储目录
KNOWLEDGE_BASE_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "knowledge_base")

# GLM（智谱 AI）模型配置 -sip for xshe
GLM_API_KEY = os.environ.get("GLM_API_KEY", "a441c9d847774293bb483be1a336627a.LxPy0EYzbJ19PDzQ")
# xshe
# GLM_API_KEY = os.environ.get("GLM_API_KEY", "50d220ce59dd4c17ac8f7312f930e111.aqkYia9LSlPBE04v")
GLM_BASE_URL = os.environ.get("GLM_BASE_URL", "https://open.bigmodel.cn/api/coding/paas/v4")
GLM_MODEL = os.environ.get("GLM_MODEL", "GLM-4")
# GLM 调用超时（秒）
GLM_TIMEOUT = 60

# GLM 异常处理推理超时（秒）
GLM_EXCEPTION_TIMEOUT = 10

# 模板置信度升级阈值（连续成功次数）
TEMPLATE_CONFIDENCE_THRESHOLD = 3

# 元素树最大遍历深度
MAX_ELEMENT_TREE_DEPTH = 20

# AI 干预连续失败最大次数（超过则暂停等待人工介入）
MAX_AI_INTERVENTION_FAILURES = 3

# 步骤拆分超时（秒）
STEP_SPLIT_TIMEOUT = 60

# 步骤执行等待间隔（秒）
STEP_WAIT_INTERVAL = 1.0
