"""文件名清理与校验工具函数"""

import os

from app.config import ALLOWED_EXTENSIONS


def sanitize_filename(filename: str) -> str:
    """对上传文件名进行清理，移除路径遍历字符。

    - 移除路径遍历序列 ``..``
    - 移除目录分隔符 ``/`` 和 ``\\``
    - 返回清理后的安全文件名

    Args:
        filename: 原始文件名

    Returns:
        清理后的文件名
    """
    # 先取 basename，去掉任何目录前缀
    name = os.path.basename(filename)
    # 移除路径遍历字符
    name = name.replace("..", "")
    name = name.replace("/", "")
    name = name.replace("\\", "")
    return name


def validate_file_extension(filename: str) -> bool:
    """校验文件扩展名是否为允许的 Excel 格式。

    Args:
        filename: 文件名

    Returns:
        True 表示扩展名合法，False 表示不合法
    """
    _, ext = os.path.splitext(filename)
    return ext.lower() in ALLOWED_EXTENSIONS
