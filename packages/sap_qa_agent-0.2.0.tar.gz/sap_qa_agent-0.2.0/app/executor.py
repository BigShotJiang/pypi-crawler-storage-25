"""Agent TARS 执行器 - 指令拼接、异步执行与输出解析"""

import asyncio
import base64
import json
import logging
import os
from dataclasses import dataclass, field

from app.config import (
    AGENT_TARS_API_KEY,
    AGENT_TARS_BASE_URL,
    AGENT_TARS_BROWSER_CONTROL,
    AGENT_TARS_MODEL,
    AGENT_TARS_PROVIDER,
    AGENT_TARS_TIMEOUT,
    ARTIFACTS_DIR,
    MAX_CONCURRENT_TASKS,
)
from app.models import StepInfo
from app.recorder import ScreenRecorder

logger = logging.getLogger(__name__)

# 并发控制信号量（agent-tars 占用浏览器，需要限制并发）
_semaphore = asyncio.Semaphore(MAX_CONCURRENT_TASKS)


@dataclass
class ExecutionResult:
    """Agent TARS 执行结果"""

    success: bool
    stdout: str = ""
    stderr: str = ""
    return_code: int | None = None
    error: str | None = None
    session_id: str | None = None
    result_content: str | None = None
    step_logs: list[str] = field(default_factory=list)


class AgentTarsExecutor:
    """Agent TARS 执行器 - 负责指令拼接、CLI 调用和输出解析"""

    def __init__(self) -> None:
        # 记录正在运行的进程，key 为 task_id
        self._running_processes: dict[str, asyncio.subprocess.Process] = {}
        self._recorder = ScreenRecorder()

    async def stop(self, task_id: str) -> bool:
        """停止指定任务的 agent-tars 进程。返回是否成功停止。"""
        process = self._running_processes.pop(task_id, None)
        if process is None:
            return False
        await self._recorder.stop()
        await self._kill_process(process)
        logger.info("Task %s stopped by user", task_id)
        return True

    def build_prompt(self, steps: list[StepInfo]) -> str:
        """将步骤列表拼接为一条结构化自然语言指令。"""
        if not steps:
            return ""
        lines = [f"{i}. {step.description}" for i, step in enumerate(steps, 1)]
        return "请依次完成以下操作：\n" + "\n".join(lines)

    def _build_cmd(self, prompt: str) -> list[str]:
        """从配置统一构建 CLI 参数列表。"""
        cmd = [
            "agent-tars", "run", "--headless",
            "--input", prompt,
            "--model.provider", AGENT_TARS_PROVIDER,
            "--model.id", AGENT_TARS_MODEL,
            "--model.apiKey", AGENT_TARS_API_KEY,
            "--model.baseURL", AGENT_TARS_BASE_URL,
            "--browser.control", AGENT_TARS_BROWSER_CONTROL,
            "--snapshot.enable",
            "--format", "json",
            "--include-logs",
        ]
        return cmd

    async def execute(self, task_id: str, prompt: str) -> ExecutionResult:
        """调用 agent-tars run，带并发控制和超时。"""
        async with _semaphore:
            return await self._do_execute(task_id, prompt)

    async def _monitor_loops(self, task_work_dir: str, stop_event: asyncio.Event) -> None:
        """后台协程：实时监控 snapshot 目录，每当新 loop 产生时打印关键信息到控制台。"""
        seen_loops: set[int] = set()
        snapshot_dir: str | None = None

        while not stop_event.is_set():
            await asyncio.sleep(2)

            # 首次发现 snapshot 目录
            if snapshot_dir is None:
                snapshot_dir = self._find_snapshot_dir(task_work_dir)
                if snapshot_dir:
                    logger.info("━━━ 检测到 session 目录: %s", os.path.basename(snapshot_dir))
                continue

            # 扫描新 loop
            try:
                entries = os.listdir(snapshot_dir)
            except OSError:
                continue

            for name in entries:
                if not name.startswith("loop-"):
                    continue
                try:
                    n = int(name.split("-")[1])
                except (IndexError, ValueError):
                    continue
                if n in seen_loops:
                    continue

                es_path = os.path.join(snapshot_dir, name, "event-stream.jsonl")
                if not os.path.isfile(es_path):
                    continue

                seen_loops.add(n)
                self._print_loop_summary(n, es_path)

    def _print_loop_summary(self, loop_n: int, event_stream_path: str) -> None:
        """解析一个 loop 的 event-stream.jsonl，打印关键信息。"""
        try:
            with open(event_stream_path, "r", encoding="utf-8") as f:
                events = json.load(f)
        except Exception:
            logger.info("  [Loop %d] (event-stream 解析失败)", loop_n)
            return

        header = f"━━━ Loop {loop_n} "
        parts: list[str] = []

        for event in events:
            etype = event.get("type", "")

            if etype == "assistant_message":
                content = event.get("content", "").strip()
                if content:
                    # 截取前 120 字符
                    preview = content[:120].replace("\n", " ")
                    if len(content) > 120:
                        preview += "..."
                    parts.append(f"  🤖 思考: {preview}")

                # 打印 tool calls
                for tc in event.get("toolCalls", []):
                    fn = tc.get("function", {})
                    tool_name = fn.get("name", "?")
                    args_str = fn.get("arguments", "")
                    # 截取参数前 80 字符
                    if len(args_str) > 80:
                        args_str = args_str[:80] + "..."
                    parts.append(f"  🔧 调用: {tool_name}({args_str})")

            elif etype == "tool_result":
                name = event.get("name", "?")
                result = event.get("result", "")
                if isinstance(result, str) and len(result) > 100:
                    result = result[:100] + "..."
                elif isinstance(result, dict):
                    result = json.dumps(result, ensure_ascii=False)[:100] + "..."
                parts.append(f"  ✅ 结果: {name} → {result}")

        logger.info("%s%s", header, "━" * max(1, 50 - len(header)))
        for line in parts:
            logger.info(line)

    async def _do_execute(self, task_id: str, prompt: str) -> ExecutionResult:
        """实际执行逻辑。

        agent-tars run 完成任务后进程可能不会自动退出，
        因此采用逐行读取 stdout 的方式，检测到完整 JSON 输出后主动终止进程。
        执行过程中会启动后台监控协程，实时打印每个 loop 的关键信息到控制台。
        """
        task_work_dir = os.path.join(ARTIFACTS_DIR, task_id)
        os.makedirs(task_work_dir, exist_ok=True)

        cmd = self._build_cmd(prompt)
        logger.info("Executing agent-tars for task %s", task_id)
        logger.info("Prompt: %s", prompt[:200])

        # 启动 loop 监控协程
        stop_monitor = asyncio.Event()
        monitor_task = asyncio.create_task(self._monitor_loops(task_work_dir, stop_monitor))

        # 启动录屏
        video_path = os.path.join(task_work_dir, "recording.mp4")
        await self._recorder.start(video_path)

        try:
            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=task_work_dir,
            )
            self._running_processes[task_id] = process

            try:
                stdout, stderr = await asyncio.wait_for(
                    self._read_until_json_complete(process),
                    timeout=AGENT_TARS_TIMEOUT,
                )
            except asyncio.TimeoutError:
                stop_monitor.set()
                monitor_task.cancel()
                await self._recorder.stop()
                self._running_processes.pop(task_id, None)
                process.kill()
                await process.wait()
                logger.error("Task %s timed out after %ds", task_id, AGENT_TARS_TIMEOUT)
                return ExecutionResult(
                    success=False,
                    return_code=-1,
                    error=f"执行超时（超过 {AGENT_TARS_TIMEOUT} 秒）",
                )

            # 停止监控协程
            stop_monitor.set()
            monitor_task.cancel()

            # 停止录屏
            await self._recorder.stop()

            # 清理进程引用
            self._running_processes.pop(task_id, None)

            # 确保进程已终止
            await self._kill_process(process)
            return_code = process.returncode or 0

            logger.info("Task %s finished with code %d", task_id, return_code)
            self._save_debug_output(task_id, stdout)

            result = self._parse_json_output(stdout)
            result.stderr = stderr
            result.return_code = return_code

            # 任务结束后从顶层 event-stream 提取截图
            # 如果 stdout 没有解析到 session_id，从文件系统 fallback 查找
            if result.session_id:
                self.extract_screenshots(task_id, result.session_id)
            else:
                snapshot_dir = self._find_snapshot_dir(task_work_dir)
                if snapshot_dir:
                    session_id = os.path.basename(snapshot_dir)
                    result.session_id = session_id
                    logger.info(
                        "session_id not found in stdout, detected from filesystem: %s",
                        session_id,
                    )
                    self.extract_screenshots(task_id, session_id)

            if return_code != 0:
                result.success = False
                result.error = result.error or stderr or f"agent-tars 退出码: {return_code}"

            return result

        except FileNotFoundError:
            stop_monitor.set()
            monitor_task.cancel()
            await self._recorder.stop()
            logger.error("agent-tars command not found")
            return ExecutionResult(
                success=False,
                error="未找到 agent-tars 命令，请确认已安装 Agent TARS CLI（需要 Node.js >= 22）",
            )
        except Exception as e:
            stop_monitor.set()
            monitor_task.cancel()
            await self._recorder.stop()
            logger.exception("Unexpected error executing task %s: %s", task_id, e)
            return ExecutionResult(success=False, error=f"执行异常: {str(e)}")

    async def _read_until_json_complete(
        self, process: asyncio.subprocess.Process
    ) -> tuple[str, str]:
        """逐行读取 stdout，检测到完整 JSON 对象后立即返回。

        agent-tars --format json 输出一个完整的 JSON 对象后进程可能不退出，
        这里通过跟踪花括号嵌套深度来判断 JSON 是否完整。
        """
        stdout_lines: list[str] = []
        brace_depth = 0
        json_started = False

        assert process.stdout is not None
        while True:
            line_bytes = await process.stdout.readline()
            if not line_bytes:
                # EOF — 进程已关闭 stdout
                break

            line = line_bytes.decode("utf-8", errors="replace")
            stdout_lines.append(line)

            # 跟踪 JSON 花括号深度
            for ch in line:
                if ch == "{":
                    brace_depth += 1
                    json_started = True
                elif ch == "}":
                    brace_depth -= 1

            # JSON 对象完整闭合 — 任务输出已完成
            if json_started and brace_depth == 0:
                logger.info("Detected complete JSON output, terminating agent-tars process")
                break

        stdout = "".join(stdout_lines)

        # 读取已有的 stderr（非阻塞）
        stderr = ""
        if process.stderr:
            try:
                stderr_bytes = await asyncio.wait_for(process.stderr.read(), timeout=2)
                stderr = stderr_bytes.decode("utf-8", errors="replace")
            except asyncio.TimeoutError:
                pass

        return stdout, stderr

    @staticmethod
    async def _kill_process(process: asyncio.subprocess.Process) -> None:
        """安全终止进程。"""
        if process.returncode is not None:
            return
        try:
            process.terminate()
            try:
                await asyncio.wait_for(process.wait(), timeout=5)
            except asyncio.TimeoutError:
                process.kill()
                await process.wait()
        except ProcessLookupError:
            pass

    def _save_debug_output(self, task_id: str, stdout: str) -> None:
        """保存原始输出到文件。"""
        path = os.path.join(ARTIFACTS_DIR, task_id, "raw_output.txt")
        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write(stdout)
        except Exception as e:
            logger.warning("Failed to save debug output: %s", e)

    def _parse_json_output(self, stdout: str) -> ExecutionResult:
        """解析 agent-tars --format json 的结构化输出。

        agent-tars 的 stdout 可能在 JSON 前后混入非 JSON 内容（日志、终端提示符等），
        因此先尝试直接解析，失败后再尝试从中提取 JSON 子串。
        """
        data = self._extract_json(stdout)
        if data is None:
            logger.warning("Output is not valid JSON, falling back to raw text")
            return ExecutionResult(
                success=True,
                stdout=stdout,
                step_logs=[line for line in stdout.strip().splitlines() if line.strip()],
            )

        session_id = data.get("sessionId")
        result_obj = data.get("result", {})
        logs = data.get("logs", [])

        return ExecutionResult(
            success=True,
            stdout=stdout,
            session_id=session_id,
            result_content=result_obj.get("content"),
            step_logs=logs if isinstance(logs, list) else [],
        )

    @staticmethod
    def _extract_json(text: str) -> dict | None:
        """从文本中提取 JSON 对象。先尝试整体解析，失败后定位第一个 '{' 到最后一个 '}'。"""
        # 1. 直接解析
        try:
            data = json.loads(text)
            if isinstance(data, dict):
                return data
        except (json.JSONDecodeError, ValueError):
            pass

        # 2. 提取第一个 '{' 到最后一个 '}' 之间的子串
        first_brace = text.find("{")
        last_brace = text.rfind("}")
        if first_brace == -1 or last_brace <= first_brace:
            return None

        try:
            data = json.loads(text[first_brace : last_brace + 1])
            if isinstance(data, dict):
                return data
        except (json.JSONDecodeError, ValueError):
            pass

        return None

    # ---- 截图提取 ----

    def extract_screenshots(self, task_id: str, session_id: str) -> int:
        """任务结束后从所有 loop 的 event-stream.jsonl 提取截图。"""
        snapshot_dir = os.path.join(ARTIFACTS_DIR, task_id, session_id)
        target_dir = os.path.join(ARTIFACTS_DIR, task_id)

        if not os.path.isdir(snapshot_dir):
            return 0

        # 收集所有 loop 的截图
        all_images: list[tuple[str, str]] = []
        seen: set[str] = set()

        loop_nums: list[int] = []
        for name in os.listdir(snapshot_dir):
            if name.startswith("loop-"):
                try:
                    loop_nums.append(int(name.split("-")[1]))
                except (IndexError, ValueError):
                    pass
        loop_nums.sort()

        for n in loop_nums:
            es_path = os.path.join(snapshot_dir, f"loop-{n}", "event-stream.jsonl")
            if not os.path.isfile(es_path):
                continue
            try:
                with open(es_path, "r", encoding="utf-8") as f:
                    events = json.load(f)
            except Exception:
                continue

            for event in events:
                if event.get("type") != "tool_result":
                    continue
                extra = event.get("_extra", {})
                if not isinstance(extra, dict):
                    continue
                screenshot = extra.get("currentScreenshot", "")
                if not screenshot or not screenshot.startswith("data:"):
                    continue
                sig = screenshot[:100]
                if sig in seen:
                    continue
                seen.add(sig)
                b64data, ext = self._parse_data_url(screenshot)
                if b64data:
                    all_images.append((b64data, ext))

        # 写入磁盘
        os.makedirs(target_dir, exist_ok=True)
        for i, (b64data, ext) in enumerate(all_images, 1):
            filepath = os.path.join(target_dir, f"step_{i:03d}.{ext}")
            if os.path.exists(filepath):
                continue
            try:
                with open(filepath, "wb") as f:
                    f.write(base64.b64decode(b64data))
            except Exception as e:
                logger.warning("Failed to save screenshot %s: %s", filepath, e)

        logger.info("Extracted %d screenshots for task %s", len(all_images), task_id)
        return len(all_images)

    def extract_live_screenshots(self, task_id: str) -> int:
        """实时提取截图，前端轮询时调用。"""
        task_dir = os.path.join(ARTIFACTS_DIR, task_id)
        snapshot_dir = self._find_snapshot_dir(task_dir)
        if not snapshot_dir:
            return 0
        session_id = os.path.basename(snapshot_dir)
        return self.extract_screenshots(task_id, session_id)

    def _extract_from_event_stream(self, event_stream_path: str, target_dir: str) -> int:
        """从一个 event-stream.jsonl 文件提取截图写入 target_dir。"""
        if not os.path.isfile(event_stream_path):
            return 0
        try:
            with open(event_stream_path, "r", encoding="utf-8") as f:
                events = json.load(f)
        except Exception as e:
            logger.warning("Failed to parse %s: %s", event_stream_path, e)
            return 0
        return self._save_images(target_dir, events)

    def _find_snapshot_dir(self, task_dir: str) -> str | None:
        """在 task 目录下找到 snapshot 子目录（包含 loop-1 的目录）。"""
        for name in os.listdir(task_dir):
            sub = os.path.join(task_dir, name)
            if os.path.isdir(sub) and os.path.isdir(os.path.join(sub, "loop-1")):
                return sub
        return None

    def get_loop_summaries(self, task_id: str) -> list[dict]:
        """提取所有 loop 的摘要信息，每个 loop 返回一行操作描述。"""
        task_dir = os.path.join(ARTIFACTS_DIR, task_id)
        if not os.path.isdir(task_dir):
            return []

        snapshot_dir = self._find_snapshot_dir(task_dir)
        if not snapshot_dir:
            return []

        summaries: list[dict] = []
        # 收集所有 loop 编号
        loop_nums: list[int] = []
        for name in os.listdir(snapshot_dir):
            if name.startswith("loop-"):
                try:
                    loop_nums.append(int(name.split("-")[1]))
                except (IndexError, ValueError):
                    pass
        loop_nums.sort()

        for n in loop_nums:
            es_path = os.path.join(snapshot_dir, f"loop-{n}", "event-stream.jsonl")
            summary = self._extract_loop_summary(n, es_path)
            if summary:
                summaries.append(summary)

        return summaries

    def _extract_loop_summary(self, loop_n: int, event_stream_path: str) -> dict | None:
        """从单个 loop 的 event-stream 提取摘要：最后一个 assistant_message 的动作。"""
        if not os.path.isfile(event_stream_path):
            return None
        try:
            with open(event_stream_path, "r", encoding="utf-8") as f:
                events = json.load(f)
        except Exception:
            return None

        # 从后往前找最后一个 assistant_message
        for event in reversed(events):
            if event.get("type") != "assistant_message":
                continue

            thought = ""
            content = event.get("content", "").strip()
            if content:
                thought = content.split("\n")[0][:100]

            actions: list[str] = []
            for tc in event.get("toolCalls", []):
                fn = tc.get("function", {})
                name = fn.get("name", "?")
                args_raw = fn.get("arguments", "")
                # 尝试提取关键参数值
                try:
                    args_obj = json.loads(args_raw) if args_raw else {}
                    # 取第一个参数值作为简要展示
                    vals = list(args_obj.values())
                    arg_preview = str(vals[0])[:60] if vals else ""
                except Exception:
                    arg_preview = args_raw[:60] if args_raw else ""
                actions.append({"tool": name, "args": arg_preview})

            return {
                "loop": loop_n,
                "thought": thought,
                "actions": actions,
            }

        return {"loop": loop_n, "thought": "", "actions": []}

    def _find_latest_loop_event_stream(self, snapshot_dir: str) -> str | None:
        """找到编号最大的 loop-N/event-stream.jsonl。"""
        max_n = 0
        result = None
        for name in os.listdir(snapshot_dir):
            if not name.startswith("loop-"):
                continue
            try:
                n = int(name.split("-")[1])
            except (IndexError, ValueError):
                continue
            es = os.path.join(snapshot_dir, name, "event-stream.jsonl")
            if os.path.isfile(es) and n > max_n:
                max_n = n
                result = es
        return result

    def _save_images(self, target_dir: str, events: list[dict]) -> int:
        """从事件列表提取截图写入磁盘，已存在则跳过。返回截图总数。"""
        images = self._collect_images(events)
        for i, (b64data, ext) in enumerate(images, 1):
            filepath = os.path.join(target_dir, f"step_{i:03d}.{ext}")
            if os.path.exists(filepath):
                continue
            try:
                with open(filepath, "wb") as f:
                    f.write(base64.b64decode(b64data))
            except Exception as e:
                logger.warning("Failed to save screenshot %s: %s", filepath, e)
        return len(images)

    def _collect_images(self, events: list[dict]) -> list[tuple[str, str]]:
        """从事件列表中收集截图。

        截图位于 tool_result 事件的 _extra.currentScreenshot 字段，
        格式为 data:image/png;base64,...
        """
        images: list[tuple[str, str]] = []
        seen: set[str] = set()
        for event in events:
            if event.get("type") != "tool_result":
                continue
            extra = event.get("_extra", {})
            if not isinstance(extra, dict):
                continue
            screenshot = extra.get("currentScreenshot", "")
            if not screenshot or not screenshot.startswith("data:"):
                continue
            # 去重（同一张截图可能在累积的 event-stream 中重复出现）
            sig = screenshot[:100]
            if sig in seen:
                continue
            seen.add(sig)
            b64data, ext = self._parse_data_url(screenshot)
            if b64data:
                images.append((b64data, ext))
        return images

    @staticmethod
    def _parse_data_url(data_url: str) -> tuple[str, str]:
        """解析 data URL，返回 (base64_data, extension)。"""
        if not data_url.startswith("data:"):
            return "", ""
        try:
            header, b64data = data_url.split(",", 1)
            mime = header.split(";")[0].replace("data:", "")
            ext_map = {"image/png": "png", "image/jpeg": "jpg", "image/webp": "webp"}
            return b64data, ext_map.get(mime, "png")
        except (ValueError, IndexError):
            return "", ""
