"""FastAPI 路由定义"""

import asyncio
import os
from datetime import datetime, timezone

from fastapi import APIRouter, HTTPException, UploadFile

from .config import ARTIFACTS_DIR, MAX_FILE_SIZE, UPLOAD_DIR
from .excel_parser import EmptyDataError, ExcelParseError, ExcelParser
from .vlm_executor import VLMExecutor
from .models import (
    ExecuteRequest,
    ExecuteResponse,
    ScreenshotInfo,
    TaskStatus,
    TaskStatusResponse,
    UploadResponse,
)
from .task_store import VlmTaskStore
from .utils import sanitize_filename, validate_file_extension

router = APIRouter(prefix="/api")

# 模块级单例
task_store = VlmTaskStore()
excel_parser = ExcelParser()
executor = VLMExecutor()


@router.post("/upload", response_model=UploadResponse)
async def upload_excel(file: UploadFile):
    """上传 Excel 文件，校验、保存、解析步骤并创建任务。"""
    # 校验文件名存在
    if not file.filename:
        raise HTTPException(status_code=400, detail="未提供文件名")

    # 校验文件扩展名
    if not validate_file_extension(file.filename):
        raise HTTPException(status_code=400, detail="不支持的文件格式，请上传 Excel 文件")

    # 读取文件内容并校验大小
    content = await file.read()
    if len(content) > MAX_FILE_SIZE:
        raise HTTPException(status_code=400, detail="文件大小超过 10MB 限制")

    # 清理文件名并保存到磁盘
    safe_name = sanitize_filename(file.filename)
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    file_path = os.path.join(UPLOAD_DIR, safe_name)
    with open(file_path, "wb") as f:
        f.write(content)

    # 解析 Excel 步骤
    try:
        steps = excel_parser.parse(file_path)
    except EmptyDataError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except ExcelParseError as e:
        raise HTTPException(status_code=400, detail=str(e))

    # 创建任务记录
    task = task_store.create_task(filename=safe_name)
    task_store.update_task(task.task_id, steps=steps)

    return UploadResponse(
        task_id=task.task_id,
        filename=task.filename,
        step_count=len(steps),
        steps=steps,
    )


async def _run_task(task_id: str, prompt: str):
    """后台协程：执行 agent-tars 并在完成后更新任务状态。"""
    import logging
    logger = logging.getLogger(__name__)

    logger.info("_run_task started for task %s", task_id)
    try:
        result = await executor.execute(task_id, prompt)
        logger.info("_run_task got result for task %s: success=%s, return_code=%s, error=%s",
                     task_id, result.success, result.return_code, result.error)

        if result.success:
            task_store.update_task(
                task_id,
                status=TaskStatus.COMPLETED,
                raw_output=result.stdout,
                prompt=prompt,
            )
            logger.info("Task %s status updated to COMPLETED", task_id)
        else:
            task_store.update_task(
                task_id,
                status=TaskStatus.FAILED,
                raw_output=result.stdout,
                error=result.error,
                prompt=prompt,
            )
            logger.info("Task %s status updated to FAILED", task_id)
    except Exception as e:
        logger.exception("_run_task exception for task %s: %s", task_id, e)
        task_store.update_task(
            task_id,
            status=TaskStatus.FAILED,
            error=f"后台执行异常: {str(e)}",
        )


@router.post("/tasks/{task_id}/execute", response_model=ExecuteResponse)
async def execute_task(task_id: str, body: ExecuteRequest):
    """接收编辑后的步骤列表，拼接指令并启动异步执行。"""
    task = task_store.get_task(task_id)
    if task is None:
        raise HTTPException(status_code=404, detail="任务不存在")

    if task.status == TaskStatus.RUNNING:
        raise HTTPException(status_code=400, detail="任务正在执行中")

    # 拼接指令
    prompt = executor.build_prompt(body.steps)

    # 更新任务状态为 RUNNING
    task_store.update_task(
        task_id,
        steps=body.steps,
        status=TaskStatus.RUNNING,
        started_at=datetime.now(timezone.utc),
    )

    # 启动异步执行（不阻塞响应）
    asyncio.create_task(_run_task(task_id, prompt))

    return ExecuteResponse(
        task_id=task_id,
        message="Agent TARS 已开始执行，请勿操作鼠标键盘",
    )


@router.post("/tasks/{task_id}/stop")
async def stop_task(task_id: str):
    """停止正在执行的任务。"""
    task = task_store.get_task(task_id)
    if task is None:
        raise HTTPException(status_code=404, detail="任务不存在")

    if task.status != TaskStatus.RUNNING:
        raise HTTPException(status_code=400, detail="任务未在执行中")

    stopped = await executor.stop(task_id)
    if stopped:
        task_store.update_task(
            task_id,
            status=TaskStatus.FAILED,
            error="用户手动停止执行",
        )

    return {"task_id": task_id, "stopped": stopped}


@router.get("/tasks/{task_id}/status", response_model=TaskStatusResponse)
async def get_task_status(task_id: str):
    """查询任务状态。"""
    task = task_store.get_task(task_id)
    if task is None:
        raise HTTPException(status_code=404, detail="任务不存在")

    return TaskStatusResponse(
        task_id=task.task_id,
        filename=task.filename,
        status=task.status,
        steps=task.steps,
        prompt=task.prompt,
        error=task.error,
        created_at=task.created_at,
        started_at=task.started_at,
        completed_at=task.completed_at,
    )


@router.get("/tasks/{task_id}/recording")
async def get_recording(task_id: str):
    """返回录屏文件信息。"""
    task = task_store.get_task(task_id)
    if task is None:
        raise HTTPException(status_code=404, detail="任务不存在")

    video_path = os.path.join(ARTIFACTS_DIR, task_id, "recording.mp4")
    if not os.path.isfile(video_path):
        return {"available": False}

    return {
        "available": True,
        "filepath": f"/artifacts/{task_id}/recording.mp4",
    }


@router.get("/tasks/{task_id}/loops")
async def get_loop_summaries(task_id: str):
    """返回任务的 loop 摘要列表。"""
    task = task_store.get_task(task_id)
    if task is None:
        raise HTTPException(status_code=404, detail="任务不存在")
    return executor.get_loop_summaries(task_id)


@router.get("/tasks/{task_id}/screenshots", response_model=list[ScreenshotInfo])
async def get_screenshots(task_id: str):
    """返回该任务的截图列表（实时提取，执行过程中也能看到）。"""
    task = task_store.get_task(task_id)
    if task is None:
        raise HTTPException(status_code=404, detail="任务不存在")

    # 实时从 snapshot 目录提取截图到磁盘
    executor.extract_live_screenshots(task_id)

    # 扫描已提取的截图文件
    screenshots: list[ScreenshotInfo] = []
    task_artifacts_dir = os.path.join(ARTIFACTS_DIR, task_id)

    if not os.path.isdir(task_artifacts_dir):
        return screenshots

    for fname in sorted(os.listdir(task_artifacts_dir)):
        if not fname.lower().endswith((".png", ".jpg", ".jpeg", ".webp")):
            continue

        fpath = os.path.join(task_artifacts_dir, fname)
        mtime = os.path.getmtime(fpath)
        timestamp = datetime.fromtimestamp(mtime, tz=timezone.utc)

        step_index = None
        if fname.startswith("step_"):
            parts = fname.split("_")
            if len(parts) >= 2 and parts[1].isdigit():
                step_index = int(parts[1])

        screenshots.append(
            ScreenshotInfo(
                step_index=step_index,
                filepath=f"/artifacts/{task_id}/{fname}",
                timestamp=timestamp,
            )
        )

    return screenshots
