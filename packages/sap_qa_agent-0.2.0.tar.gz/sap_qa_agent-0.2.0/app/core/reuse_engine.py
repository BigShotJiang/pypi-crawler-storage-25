"""ReuseEngine - 复用模式引擎

匹配到已有模板时的执行引擎，负责数据填充、脚本执行和模板加固。
成功执行后更新模板置信度和路径映射，失败时触发回退到探索模式。
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Any

from app.data.knowledge_base import KnowledgeBase
from app.data.models import ExecutionCallbacks, ScriptTemplate, StepResult

logger = logging.getLogger(__name__)


@dataclass
class ReuseResult:
    """复用模式执行结果"""
    success: bool
    step_results: list[StepResult] = field(default_factory=list)
    needs_fallback: bool = False
    template_updated: bool = False


class ReuseEngine:
    """复用模式引擎。

    使用已有模板执行测试：填充数据 → 执行脚本 → 加固模板或回退到探索模式。
    """

    def __init__(
        self,
        script_executor: Any,
        knowledge_base: KnowledgeBase,
    ) -> None:
        self._executor = script_executor
        self._kb = knowledge_base

    async def execute_with_template(
        self,
        template: ScriptTemplate,
        test_data: dict[str, str],
        flow_context: Any,
        callbacks: ExecutionCallbacks | None = None,
    ) -> ReuseResult:
        """使用模板执行测试。

        1. 填充模板参数（测试数据 + 流程变量）
        2. 执行脚本
        3. 成功: 更新模板（成功次数+1、置信度升级、路径更新）
        4. 失败: 返回 needs_fallback=True 供调用方切换到探索模式
        """
        result = ReuseResult(success=False)

        # Step 1: Fill template with test data and flow variables
        try:
            filled_script = self.fill_template(template, test_data, flow_context)
            logger.info(
                "Template %s filled with %d data params",
                template.template_id, len(test_data),
            )
        except KeyError as exc:
            logger.warning("Parameter mismatch in template %s: %s", template.template_id, exc)
            result.needs_fallback = True
            return result

        # Notify callback that script has been generated
        if callbacks and callbacks.on_script_generated:
            callbacks.on_script_generated(filled_script)

        # Step 2: Execute the filled script
        # Convert template steps back to TestStep-like objects for executor
        from app.data.models import StepActionType, TestStep

        # We execute the template's steps via the executor
        # The script_executor expects TestStep list; we reconstruct from template parameters
        # For reuse mode, we pass the filled script content to executor
        step_results = await self._executor.execute_script(
            self._build_steps_from_template(template, test_data),
            flow_context,
            step_callback=callbacks.on_step_result if callbacks else None,
            log_callback=callbacks.on_log if callbacks else None,
        )
        result.step_results = step_results

        # Step 3 & 4: Update template or trigger fallback
        all_success = all(sr.success for sr in step_results)

        if all_success:
            result.success = True
            # Update template: success count +1, confidence upgrade, path updates
            self._kb.update_confidence(template.template_id, success=True)
            result.template_updated = True
            logger.info(
                "Template %s execution succeeded, confidence updated",
                template.template_id,
            )
        else:
            # Execution failed → mark for fallback to exploration
            result.needs_fallback = True
            self._kb.update_confidence(template.template_id, success=False)
            logger.warning(
                "Template %s execution failed, needs fallback to exploration",
                template.template_id,
            )

        return result

    def fill_template(
        self,
        template: ScriptTemplate,
        test_data: dict[str, str],
        flow_context: Any,
    ) -> str:
        """将测试数据和流程变量填充到模板脚本中。

        替换 ${PARAM_NAME} 和 params["param_name"] 风格的占位符。
        """
        script = template.script_content

        # Replace ${VAR_NAME} placeholders with flow variables first
        if flow_context is not None:
            try:
                script = flow_context.resolve(script)
            except KeyError:
                pass  # Some variables may not be available yet

        # Replace parameter placeholders with test data
        for param_name in template.parameters:
            if param_name in test_data:
                value = test_data[param_name]
                # Replace ${param_name} style
                script = script.replace(f"${{{param_name}}}", value)
                # Replace params["param_name"] and params.get("param_name", "") style
                script = re.sub(
                    rf'params\.get\(\s*["\']' + re.escape(param_name) + rf'["\'].*?\)',
                    f'"{value}"',
                    script,
                )
                script = re.sub(
                    rf'params\[\s*["\']' + re.escape(param_name) + rf'["\']\s*\]',
                    f'"{value}"',
                    script,
                )

        return script

    @staticmethod
    def _build_steps_from_template(
        template: ScriptTemplate,
        test_data: dict[str, str],
    ) -> list[Any]:
        """从模板重建 TestStep 列表用于执行。

        优先使用模板中保存的原始步骤（保留完整的 action_type），
        只在没有保存步骤时才从参数重建。
        """
        from app.data.models import StepActionType, TestStep

        # 优先使用保存的原始步骤
        if template.steps:
            steps: list[TestStep] = []
            for s in template.steps:
                action_type = StepActionType(s["action_type"])
                value = s.get("value") or ""
                target = s.get("target_description", "")

                # 对 input 步骤，用 test_data 中的值替换
                if action_type == StepActionType.INPUT and target in test_data:
                    value = test_data[target]

                steps.append(TestStep(
                    index=s.get("index", len(steps)),
                    action_type=action_type,
                    target_description=target,
                    value=value,
                    flow_variable_ref=s.get("flow_variable_ref"),
                ))
            return steps

        # 兜底：从参数重建（旧模板没有 steps 字段）
        steps = []
        idx = 0

        if template.transaction_code:
            steps.append(TestStep(
                index=idx, action_type=StepActionType.NAVIGATE,
                target_description="命令输入框",
                value=f"/n{template.transaction_code}",
            ))
            idx += 1
            steps.append(TestStep(
                index=idx, action_type=StepActionType.CLICK,
                target_description="回车",
            ))
            idx += 1

        for param_name in template.parameters:
            value = test_data.get(param_name, "")
            target = template.element_path_map.get(param_name, param_name)
            steps.append(TestStep(
                index=idx, action_type=StepActionType.INPUT,
                target_description=target, value=value,
            ))
            idx += 1

        return steps
