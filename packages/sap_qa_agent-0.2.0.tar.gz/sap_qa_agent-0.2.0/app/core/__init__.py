"""Core engine layer modules for SAP GUI automation testing framework."""
