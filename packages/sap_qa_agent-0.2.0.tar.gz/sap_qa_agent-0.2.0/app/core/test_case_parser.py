"""测试用例解析器 — 支持 Excel 和 Markdown 格式的测试用例导入。"""

from __future__ import annotations

import re
from typing import Any

import openpyxl

from app.data.models import FlowVariableDef, TestCase, TestCaseType


# Excel / Markdown 列名常量（中文）
COL_CASE_ID = "用例编号"
COL_PURPOSE = "测试目的"
COL_PRECONDITIONS = "前置条件"
COL_STEPS = "操作步骤"
COL_TEST_DATA = "测试数据"
COL_EXPECTED = "预期结果"
COL_AI_NOTES = "AI执行备注"

# 所有可识别的列名（用于灵活匹配）
_COLUMN_ALIASES: dict[str, list[str]] = {
    COL_CASE_ID: ["用例编号", "编号", "case_id", "id", "用例ID", "用例id"],
    COL_PURPOSE: ["测试目的", "目的", "purpose", "用例名称", "名称"],
    COL_PRECONDITIONS: ["前置条件", "前提条件", "preconditions", "precondition"],
    COL_STEPS: ["操作步骤", "步骤", "操作步骤（AI自动执行）", "steps", "测试步骤"],
    COL_TEST_DATA: ["测试数据", "数据", "test_data"],
    COL_EXPECTED: ["预期结果", "期望结果", "expected_results", "expected"],
    COL_AI_NOTES: ["AI执行备注", "AI备注", "执行备注", "ai_notes"],
}

# SAP 事务代码正则：如 VA01, VL01N, VF01, ME21N, MIGO, FB01, F-02
_TCODE_PATTERN = re.compile(r"\b([A-Z][A-Z0-9]{0,4}(?:-[A-Z0-9]{1,4})?[A-Z0-9]?)\b")

# 常见 SAP 事务代码前缀（用于过滤误匹配）
_KNOWN_TCODE_PREFIXES = {
    "VA", "VL", "VF", "ME", "MI", "MB", "MM", "FB", "FK", "FV",
    "XK", "XD", "CO", "KS", "KB", "SM", "SE", "SU", "SP",
}

# Flow_Variable 提取模式
_FLOW_VAR_PATTERNS: list[tuple[str, str, str]] = [
    # (regex_pattern, variable_name, source_description)
    (r"记录.*?销售订单号", "ORDER_NO", "状态栏消息中的销售订单号"),
    (r"记录.*?订单号", "ORDER_NO", "状态栏消息中的订单号"),
    (r"记录.*?交货单号", "DELIVERY_NO", "状态栏消息中的交货单号"),
    (r"记录.*?发票号", "INVOICE_NO", "状态栏消息中的发票号"),
    (r"记录.*?开票.*?号", "INVOICE_NO", "状态栏消息中的开票文档号"),
    (r"记录.*?物料凭证号", "MAT_DOC_NO", "状态栏消息中的物料凭证号"),
    (r"记录.*?会计凭证号", "ACC_DOC_NO", "状态栏消息中的会计凭证号"),
    (r"记录.*?凭证号", "DOC_NO", "状态栏消息中的凭证号"),
]

# 显式变量定义模式：变量名: ORDER_NO 或 变量名：ORDER_NO
_EXPLICIT_VAR_PATTERN = re.compile(r"变量名\s*[:：]\s*([A-Z_][A-Z0-9_]*)")

# 依赖用例编号模式：如 BD9-2602-001
_DEPENDENCY_CASE_PATTERN = re.compile(
    r"(?:依赖|需要|前置|关联)\s*(?:用例\s*)?([A-Z0-9]+-\d+-\d+)"
)

# 前置条件中引用的用例编号（更宽泛）
_PRECONDITION_CASE_REF = re.compile(r"用例\s*\d+\s*执行成功")
_PRECONDITION_CASE_ID = re.compile(r"([A-Z0-9]+-\d+-\d+)")

# Flow_Variable 引用模式
_FLOW_VAR_REF_PATTERN = re.compile(r"(?:变量|记录为变量)\s*([A-Z_][A-Z0-9_]*)")



class TestCaseParser:
    """测试用例解析器，支持 Excel 和 Markdown 格式。"""

    # ------------------------------------------------------------------
    # Excel 解析
    # ------------------------------------------------------------------

    def parse_excel(self, file_path: str) -> list[TestCase]:
        """从 Excel 文件解析测试用例列表。

        使用 openpyxl 直接读取。第一行为表头，数据从第二行开始。

        Args:
            file_path: Excel 文件路径。

        Returns:
            解析后的 TestCase 列表。
        """
        wb = openpyxl.load_workbook(file_path, read_only=True, data_only=True)
        ws = wb.active

        rows = list(ws.iter_rows(values_only=True))
        wb.close()

        if not rows:
            return []

        header = [str(c).strip() if c is not None else "" for c in rows[0]]
        col_map = self._build_column_map(header)

        test_cases: list[TestCase] = []
        for row in rows[1:]:
            cells = list(row)
            raw = self._extract_row(cells, col_map)
            if not raw.get("case_id"):
                continue
            tc = self._build_test_case(raw)
            test_cases.append(tc)

        return test_cases

    # ------------------------------------------------------------------
    # Markdown 解析
    # ------------------------------------------------------------------

    def parse_markdown(self, file_path: str) -> list[TestCase]:
        """从 Markdown 文件解析测试用例列表。

        支持两种格式：
        1. 标准 Markdown 表格（| 列1 | 列2 | ... |）
        2. 键值对表格（| 测试项 | 测试内容 |），每个用例一个表格块

        Args:
            file_path: Markdown 文件路径。

        Returns:
            解析后的 TestCase 列表。
        """
        with open(file_path, "r", encoding="utf-8") as f:
            content = f.read()

        # 尝试解析键值对表格格式（如示例文件中的格式）
        test_cases = self._parse_markdown_kv_tables(content)
        if test_cases:
            return test_cases

        # 回退到标准表格格式
        return self._parse_markdown_standard_table(content)

    def _parse_markdown_kv_tables(self, content: str) -> list[TestCase]:
        """解析键值对格式的 Markdown 表格。

        每个用例是一个独立的表格，格式如：
        |测试项|测试内容|
        |---|---|
        |用例编号|BD9-2602-001|
        |测试目的|...|
        """
        test_cases: list[TestCase] = []
        lines = content.split("\n")

        current_kv: dict[str, str] = {}
        in_table = False

        for line in lines:
            stripped = line.strip()
            # 检测表格行
            if stripped.startswith("|"):
                # 兼容末尾没有 | 的表格行
                if not stripped.endswith("|"):
                    stripped = stripped + "|"
                parts = [p.strip() for p in stripped.split("|")]
                parts = [p for p in parts if p]  # 去除空字符串

                # 跳过分隔行
                if len(parts) >= 2 and all(
                    set(p) <= {"-", ":"} for p in parts
                ):
                    in_table = True
                    continue

                if len(parts) >= 2 and in_table:
                    key = parts[0].strip().strip("*").strip()
                    value = parts[1].strip()
                    current_kv[key] = value
            else:
                # 非表格行 → 如果有积累的 kv 数据且包含用例编号，生成 TestCase
                if current_kv and self._has_case_id(current_kv):
                    tc = self._build_test_case_from_kv(current_kv)
                    if tc:
                        test_cases.append(tc)
                    current_kv = {}
                in_table = False

        # 处理最后一个表格
        if current_kv and self._has_case_id(current_kv):
            tc = self._build_test_case_from_kv(current_kv)
            if tc:
                test_cases.append(tc)

        return test_cases

    def _parse_markdown_standard_table(self, content: str) -> list[TestCase]:
        """解析标准 Markdown 表格格式。

        | 用例编号 | 测试目的 | 前置条件 | 操作步骤 | 测试数据 | 预期结果 | AI执行备注 |
        """
        lines = content.split("\n")
        test_cases: list[TestCase] = []

        header_line: str | None = None
        col_map: dict[str, int] = {}

        for line in lines:
            stripped = line.strip()
            if not stripped.startswith("|") or not stripped.endswith("|"):
                continue

            parts = [p.strip() for p in stripped.split("|")]
            parts = [p for p in parts if p]

            # 跳过分隔行
            if all(set(p) <= {"-", ":"} for p in parts):
                continue

            # 检测表头行
            if header_line is None and any(
                self._match_column_name(p) for p in parts
            ):
                header_line = stripped
                for i, p in enumerate(parts):
                    canonical = self._canonicalize_column(p)
                    if canonical:
                        col_map[canonical] = i
                continue

            # 数据行
            if col_map:
                raw = self._extract_md_row(parts, col_map)
                if raw.get("case_id"):
                    tc = self._build_test_case(raw)
                    test_cases.append(tc)

        return test_cases

    # ------------------------------------------------------------------
    # 验证
    # ------------------------------------------------------------------

    def validate(self, test_case: TestCase) -> list[str]:
        """验证必填字段，返回缺失字段名列表。

        必填字段：case_id, steps_text, expected_results
        """
        missing: list[str] = []
        if not test_case.case_id or not test_case.case_id.strip():
            missing.append("case_id")
        if not test_case.steps_text or not test_case.steps_text.strip():
            missing.append("steps_text")
        if not test_case.expected_results:
            missing.append("expected_results")
        return missing

    # ------------------------------------------------------------------
    # 事务代码提取
    # ------------------------------------------------------------------

    def extract_transaction_code(self, steps_text: str) -> str | None:
        """从操作步骤文本中提取 SAP 事务代码。

        匹配模式：VA01, VL01N, VF01, ME21N, MIGO, FB01, F-02 等。
        优先匹配引号内的事务代码，其次匹配已知前缀的事务代码。
        """
        if not steps_text:
            return None

        # 优先匹配"事务码"/"事务代码"后面引号内的代码
        tcode_quoted = re.findall(
            r'事务[码代码]*\s*["""\u201c\u201d]([A-Z][A-Z0-9]{0,4}(?:-[A-Z0-9]{1,4})?)["""\u201c\u201d]',
            steps_text,
        )
        for candidate in tcode_quoted:
            if self._is_valid_tcode(candidate):
                return candidate

        # 匹配引号内的事务代码（如 "VA01"、"VL01N"）
        quoted = re.findall(r'["""\u201c]([A-Z][A-Z0-9]{0,4}(?:-[A-Z0-9]{1,4})?)["""\u201d]', steps_text)
        for candidate in quoted:
            if self._is_valid_tcode(candidate):
                return candidate

        # 匹配"事务码"/"事务代码"后面不带引号的代码
        tcode_context = re.findall(
            r'事务[码代码]*\s*([A-Z][A-Z0-9]{0,4}(?:-[A-Z0-9]{1,4})?)',
            steps_text,
        )
        for candidate in tcode_context:
            if self._is_valid_tcode(candidate):
                return candidate

        # 通用匹配
        for match in _TCODE_PATTERN.finditer(steps_text):
            candidate = match.group(1)
            if self._is_valid_tcode(candidate):
                return candidate

        return None

    # ------------------------------------------------------------------
    # Flow_Variable 提取
    # ------------------------------------------------------------------

    def extract_flow_variables(self, ai_notes: str) -> list[FlowVariableDef]:
        """从 AI 执行备注中提取 FlowVariableDef 列表。

        识别模式：
        - "记录...订单号" → ORDER_NO
        - "记录...交货单号" → DELIVERY_NO
        - 显式定义 "变量名: ORDER_NO"
        """
        if not ai_notes:
            return []

        result: list[FlowVariableDef] = []
        seen_names: set[str] = set()

        # 显式变量定义
        for match in _EXPLICIT_VAR_PATTERN.finditer(ai_notes):
            name = match.group(1)
            if name not in seen_names:
                result.append(FlowVariableDef(name=name, source=ai_notes))
                seen_names.add(name)

        # 模式匹配
        for pattern, var_name, source_desc in _FLOW_VAR_PATTERNS:
            if var_name not in seen_names and re.search(pattern, ai_notes):
                result.append(FlowVariableDef(name=var_name, source=source_desc))
                seen_names.add(var_name)

        return result

    # ------------------------------------------------------------------
    # 依赖提取
    # ------------------------------------------------------------------

    def extract_dependencies(self, preconditions: str) -> list[str]:
        """从前置条件中提取依赖的用例编号。

        识别模式：
        - "依赖 BD9-2602-001" 或 "需要 BD9-2602-001 完成"
        - "用例N执行成功" → 提取关联的用例编号
        - 前置条件中出现的用例编号（如 BD9-2602-001）

        注意：FlowVariable 引用（如 ORDER_NO）不作为依赖返回，
        它们会在执行时通过 FlowVariableContext 解析。
        """
        if not preconditions:
            return []

        deps: list[str] = []
        seen: set[str] = set()

        # 显式依赖声明
        for match in _DEPENDENCY_CASE_PATTERN.finditer(preconditions):
            case_id = match.group(1)
            if case_id not in seen:
                deps.append(case_id)
                seen.add(case_id)

        # 用例编号引用（如 BD9-2602-001）
        for match in _PRECONDITION_CASE_ID.finditer(preconditions):
            case_id = match.group(1)
            if case_id not in seen:
                deps.append(case_id)
                seen.add(case_id)

        # "用例N执行成功" 模式 — 提取用例序号，后续由编排器映射到实际 case_id
        for match in re.finditer(r"用例\s*(\d+)\s*执行成功", preconditions):
            case_num = match.group(1)
            # 存储为 "用例N" 标记，编排器会解析
            ref = f"__case_ref_{case_num}"
            if ref not in seen:
                deps.append(ref)
                seen.add(ref)

        return deps

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _build_column_map(header: list[str]) -> dict[str, int]:
        """建立规范列名 → 列索引的映射。"""
        col_map: dict[str, int] = {}
        for idx, col_name in enumerate(header):
            for canonical, aliases in _COLUMN_ALIASES.items():
                if col_name in aliases or col_name.lower() in [a.lower() for a in aliases]:
                    col_map[canonical] = idx
                    break
        return col_map

    @staticmethod
    def _extract_row(cells: list[Any], col_map: dict[str, int]) -> dict[str, str]:
        """从 Excel 行中按列映射提取字段值。"""
        raw: dict[str, str] = {}

        def _get(key: str) -> str:
            idx = col_map.get(key)
            if idx is not None and idx < len(cells) and cells[idx] is not None:
                return str(cells[idx]).strip()
            return ""

        raw["case_id"] = _get(COL_CASE_ID)
        raw["purpose"] = _get(COL_PURPOSE)
        raw["preconditions"] = _get(COL_PRECONDITIONS)
        raw["steps_text"] = _get(COL_STEPS)
        raw["test_data_text"] = _get(COL_TEST_DATA)
        raw["expected_text"] = _get(COL_EXPECTED)
        raw["ai_notes"] = _get(COL_AI_NOTES)
        return raw

    @staticmethod
    def _extract_md_row(parts: list[str], col_map: dict[str, int]) -> dict[str, str]:
        """从 Markdown 表格行中按列映射提取字段值。"""
        raw: dict[str, str] = {}

        def _get(key: str) -> str:
            idx = col_map.get(key)
            if idx is not None and idx < len(parts):
                return parts[idx].strip()
            return ""

        raw["case_id"] = _get(COL_CASE_ID)
        raw["purpose"] = _get(COL_PURPOSE)
        raw["preconditions"] = _get(COL_PRECONDITIONS)
        raw["steps_text"] = _get(COL_STEPS)
        raw["test_data_text"] = _get(COL_TEST_DATA)
        raw["expected_text"] = _get(COL_EXPECTED)
        raw["ai_notes"] = _get(COL_AI_NOTES)
        return raw

    def _build_test_case(self, raw: dict[str, str]) -> TestCase:
        """从原始字段字典构建 TestCase。"""
        steps_text = raw.get("steps_text", "")
        ai_notes = raw.get("ai_notes", "")
        preconditions = raw.get("preconditions", "")

        return TestCase(
            case_id=raw.get("case_id", ""),
            purpose=raw.get("purpose", ""),
            preconditions=preconditions,
            steps_text=steps_text,
            test_data=self._parse_test_data(raw.get("test_data_text", "")),
            expected_results=self._parse_expected_results(raw.get("expected_text", "")),
            ai_notes=ai_notes,
            transaction_code=self.extract_transaction_code(steps_text),
            flow_variable_defs=self.extract_flow_variables(ai_notes),
            dependencies=self.extract_dependencies(preconditions),
        )

    def _build_test_case_from_kv(self, kv: dict[str, str]) -> TestCase | None:
        """从键值对字典构建 TestCase。"""
        raw: dict[str, str] = {}
        for canonical, aliases in _COLUMN_ALIASES.items():
            for alias in aliases:
                if alias in kv:
                    field_key = self._canonical_to_raw_key(canonical)
                    raw[field_key] = kv[alias]
                    break
        if not raw.get("case_id"):
            return None
        return self._build_test_case(raw)

    @staticmethod
    def _canonical_to_raw_key(canonical: str) -> str:
        """将规范列名映射到 raw dict 的 key。"""
        mapping = {
            COL_CASE_ID: "case_id",
            COL_PURPOSE: "purpose",
            COL_PRECONDITIONS: "preconditions",
            COL_STEPS: "steps_text",
            COL_TEST_DATA: "test_data_text",
            COL_EXPECTED: "expected_text",
            COL_AI_NOTES: "ai_notes",
        }
        return mapping.get(canonical, canonical)

    @staticmethod
    def _parse_test_data(text: str) -> dict[str, str]:
        """解析测试数据文本为字典。

        支持格式：
        - "字段名：值" 或 "字段名: 值"（分号/换行分隔）
        - "字段名=值"
        """
        if not text:
            return {}

        data: dict[str, str] = {}
        # 按分号、换行、中文分号分割
        items = re.split(r"[;\n；]", text)
        for item in items:
            item = item.strip()
            if not item:
                continue
            # 匹配 "key：value" 或 "key: value"
            match = re.match(r"(.+?)\s*[:：]\s*(.+)", item)
            if match:
                key = match.group(1).strip()
                value = match.group(2).strip()
                data[key] = value
        return data

    @staticmethod
    def _parse_expected_results(text: str) -> list[str]:
        """解析预期结果文本为列表。

        支持格式：
        - 编号列表 "1. xxx; 2. xxx"
        - 换行分隔
        """
        if not text:
            return []

        results: list[str] = []
        # 按编号分割（1. xxx 2. xxx）
        items = re.split(r"\d+\.\s*", text)
        for item in items:
            cleaned = item.strip().rstrip(";；")
            if cleaned:
                results.append(cleaned)

        if not results:
            # 回退到换行分割
            for line in text.split("\n"):
                cleaned = line.strip()
                if cleaned:
                    results.append(cleaned)

        return results

    @staticmethod
    def _is_valid_tcode(candidate: str) -> bool:
        """检查候选字符串是否为有效的 SAP 事务代码。"""
        if len(candidate) < 2 or len(candidate) > 8:
            return False
        # 检查是否以已知前缀开头
        prefix2 = candidate[:2]
        if prefix2 in _KNOWN_TCODE_PREFIXES:
            return True
        # 带连字符的事务代码（如 F-02）
        if "-" in candidate and len(candidate) >= 3:
            return True
        # 全大写字母+数字，至少包含一个字母和一个数字
        if re.match(r"^[A-Z][A-Z0-9]+$", candidate):
            has_digit = any(c.isdigit() for c in candidate)
            has_alpha = sum(1 for c in candidate if c.isalpha()) >= 1
            if has_digit and has_alpha:
                return True
        return False

    @staticmethod
    def _has_case_id(kv: dict[str, str]) -> bool:
        """检查键值对字典中是否包含用例编号。"""
        for alias in _COLUMN_ALIASES[COL_CASE_ID]:
            if alias in kv and kv[alias].strip():
                return True
        return False

    @staticmethod
    def _match_column_name(name: str) -> bool:
        """检查名称是否匹配任何已知列名。"""
        name = name.strip("*").strip()
        for aliases in _COLUMN_ALIASES.values():
            if name in aliases or name.lower() in [a.lower() for a in aliases]:
                return True
        return False

    @staticmethod
    def _canonicalize_column(name: str) -> str | None:
        """将列名规范化为标准列名。"""
        name = name.strip("*").strip()
        for canonical, aliases in _COLUMN_ALIASES.items():
            if name in aliases or name.lower() in [a.lower() for a in aliases]:
                return canonical
        return None
