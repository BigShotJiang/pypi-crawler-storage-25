"""屏幕状态匹配器 — 验证当前屏幕是否符合步骤预期，支持自适应导航。"""

from __future__ import annotations

import logging

from app.data.models import ScreenSnapshot, StepActionType, TestStep

logger = logging.getLogger(__name__)

# 事务码 → 窗口标题关键词映射
TCODE_TITLE_MAP: dict[str, list[str]] = {
    "VA01": ["创建销售订单", "Create Sales Order"],
    "VA02": ["修改销售订单", "Change Sales Order", "显示销售订单"],
    "VL01N": ["创建外向交货", "Create Outbound Delivery"],
    "VL02N": ["修改外向交货", "Change Outbound Delivery"],
    "VF01": ["创建开票凭证", "Create Billing Document"],
    "FB01": ["输入凭证", "Enter Document"],
    "MM01": ["创建物料", "Create Material"],
    "ME21N": ["创建采购订单", "Create Purchase Order"],
}


class ScreenMatcher:
    """屏幕状态匹配器 — 验证当前屏幕是否符合步骤预期。"""

    def check_screen(
        self, snapshot: ScreenSnapshot, step: TestStep
    ) -> bool:
        """比较当前屏幕与步骤预期。

        Returns:
            True 如果屏幕匹配或无法推断预期（默认通过）
        """
        expected_tcode = self.infer_transaction_code(step)
        if not expected_tcode:
            return True  # 无法推断预期，默认通过

        keywords = TCODE_TITLE_MAP.get(expected_tcode.upper(), [])
        if not keywords:
            return True  # 未配置关键词，默认通过

        title = snapshot.window_title
        matched = any(kw in title for kw in keywords)

        if not matched:
            logger.warning(
                "屏幕不匹配: 预期事务码 %s (关键词 %s)，实际标题 '%s'",
                expected_tcode,
                keywords,
                title,
            )

        return matched

    @staticmethod
    def infer_transaction_code(step: TestStep) -> str | None:
        """从步骤推断预期事务码。

        优先从 NAVIGATE 步骤的 value 中提取事务码，
        其次从 target_description 中搜索已知事务码模式。
        """
        # NAVIGATE 步骤直接从 value 提取
        if step.action_type == StepActionType.NAVIGATE and step.value:
            tcode = step.value.replace("/n", "").replace("/o", "").strip()
            return tcode if tcode else None

        # 从 target_description 搜索已知事务码
        desc = step.target_description.upper()
        for tcode in TCODE_TITLE_MAP:
            if tcode in desc:
                return tcode

        return None
