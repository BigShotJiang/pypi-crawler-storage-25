"""ResultVerifier - 预期结果验证器

验证测试执行结果是否符合预期，支持：
- 状态栏消息模式匹配
- 凭证状态字段读取
- 数据一致性比较
- Expected_Failure 反向验证逻辑
"""

from __future__ import annotations

import logging
import re
from typing import Any

from app.data.models import (
    StepResult,
    TestCase,
    TestCaseType,
    VerificationResult,
)

logger = logging.getLogger(__name__)


class ResultVerifier:
    """预期结果验证器。"""

    def __init__(self, sap_wrapper: Any) -> None:
        self._sap_wrapper = sap_wrapper

    def verify_expected_results(
        self,
        test_case: TestCase,
        step_results: list[StepResult],
    ) -> list[VerificationResult]:
        """验证测试用例的预期结果。

        对于 Expected_Failure 类型用例，使用反向验证逻辑。
        对于正常用例，逐条验证预期结果。
        """
        if test_case.case_type == TestCaseType.EXPECTED_FAILURE:
            return self._verify_expected_failure(test_case, step_results)

        return self._verify_normal(test_case, step_results)

    def _verify_normal(
        self,
        test_case: TestCase,
        step_results: list[StepResult],
    ) -> list[VerificationResult]:
        """正常用例验证：每条预期结果都应匹配。"""
        results: list[VerificationResult] = []

        # Collect all status bar messages from step results
        actual_messages = [
            sr.status_bar_message
            for sr in step_results
            if sr.status_bar_message
        ]

        # Also collect window title from SAP session
        window_title = ""
        try:
            session = self._sap_wrapper.get_session()
            if session:
                window_title = str(session.findById("wnd[0]").Text or "")
                if window_title:
                    actual_messages.append(window_title)
        except Exception:
            pass

        for expected in test_case.expected_results:
            # Try status bar pattern matching
            vr = self._verify_status_bar_pattern(expected, actual_messages)
            results.append(vr)

        # If no expected results defined, check overall step success
        if not test_case.expected_results:
            all_success = all(sr.success for sr in step_results)
            results.append(VerificationResult(
                description="所有步骤执行成功",
                passed=all_success,
                expected_value="全部成功",
                actual_value="全部成功" if all_success else "存在失败步骤",
            ))

        return results

    def _verify_status_bar_pattern(
        self,
        expected: str,
        actual_messages: list[str],
    ) -> VerificationResult:
        """匹配预期模式与实际状态栏消息/窗口标题。

        支持：精确匹配、包含匹配、XXXXXXXX 通配符匹配、正则匹配、关键词匹配。
        """
        if not actual_messages:
            return VerificationResult(
                description=expected,
                passed=False,
                expected_value=expected,
                actual_value="无状态栏消息",
            )

        combined_actual = " ".join(actual_messages)

        # Try exact match first
        for msg in actual_messages:
            if expected == msg:
                return VerificationResult(
                    description=expected, passed=True,
                    expected_value=expected, actual_value=msg,
                )

        # Try XXXXXXXX wildcard match (common in SAP test cases)
        if "XXXXXXXX" in expected or re.search(r"X{6,}", expected):
            wildcard_pattern = re.sub(r"X{6,}", r"\\d+", re.escape(expected))
            wildcard_pattern = wildcard_pattern.replace(r"\\d\+", r"\d+")
            for msg in actual_messages:
                try:
                    if re.search(wildcard_pattern, msg):
                        return VerificationResult(
                            description=expected, passed=True,
                            expected_value=expected, actual_value=msg,
                        )
                except re.error:
                    pass

        # Try substring/contains match
        for msg in actual_messages:
            if expected in msg or msg in expected:
                return VerificationResult(
                    description=expected, passed=True,
                    expected_value=expected, actual_value=msg,
                )

        # Try keyword match: extract meaningful keywords from expected,
        # check if any appear in actual messages.
        # This handles natural language expected results like
        # "成功进入 SAP Easy Access 主界面" matching "SAP 轻松访问"
        keywords = re.findall(r'[\u4e00-\u9fff]+|[A-Za-z]+', expected)
        # Filter out common filler words
        filler = {"的", "了", "在", "是", "和", "与", "或", "后", "前", "中",
                  "到", "从", "被", "把", "对", "已", "无", "有", "可", "不",
                  "SAP", "GUI", "sap", "gui"}
        meaningful = [kw for kw in keywords if kw not in filler and len(kw) >= 2]
        if meaningful:
            match_count = sum(
                1 for kw in meaningful
                if kw.lower() in combined_actual.lower()
            )
            # If more than half of meaningful keywords match, consider it passed
            if match_count > 0 and match_count >= len(meaningful) * 0.3:
                return VerificationResult(
                    description=expected, passed=True,
                    expected_value=expected,
                    actual_value=combined_actual[:200],
                )

        # Try regex match (treat expected as pattern)
        for msg in actual_messages:
            try:
                if re.search(expected, msg):
                    return VerificationResult(
                        description=expected, passed=True,
                        expected_value=expected, actual_value=msg,
                    )
            except re.error:
                pass

        # "无错误" type checks: if expected says "no error", check that
        # actual messages don't contain error indicators
        no_error_keywords = ["无错误", "无报错", "无异常", "无错误消息", "无错误提示"]
        if any(kw in expected for kw in no_error_keywords):
            has_error = any(
                "[E]" in msg or "错误" in msg or "Error" in msg
                for msg in actual_messages
            )
            return VerificationResult(
                description=expected,
                passed=not has_error,
                expected_value=expected,
                actual_value=combined_actual[:200] if has_error else "无错误消息",
            )

        # No match found
        return VerificationResult(
            description=expected,
            passed=False,
            expected_value=expected,
            actual_value="; ".join(actual_messages)[:200] if actual_messages else "无消息",
        )

    def _verify_expected_failure(
        self,
        test_case: TestCase,
        step_results: list[StepResult],
    ) -> list[VerificationResult]:
        """Expected_Failure 反向验证逻辑。

        - 执行出现错误 → PASS（预期的失败已发生）
        - 执行成功 → FAIL（预期应失败但实际成功了）
        """
        results: list[VerificationResult] = []

        # Check if any step actually failed (which is the expected outcome)
        has_failure = any(not sr.success for sr in step_results)

        # Collect error messages
        error_messages = [
            sr.error_message
            for sr in step_results
            if sr.error_message
        ]
        actual_messages = [
            sr.status_bar_message
            for sr in step_results
            if sr.status_bar_message
        ]

        if has_failure:
            # Expected failure occurred → PASS
            for expected in test_case.expected_results:
                # Check if the expected error pattern matches
                matched = False
                for err in error_messages + actual_messages:
                    if expected in err or err in expected:
                        matched = True
                        break
                    try:
                        if re.search(expected, err):
                            matched = True
                            break
                    except re.error:
                        pass

                if matched:
                    results.append(VerificationResult(
                        description=f"[Expected_Failure] {expected}",
                        passed=True,
                        expected_value=f"预期错误: {expected}",
                        actual_value="; ".join(error_messages + actual_messages),
                    ))
                else:
                    # Failure occurred but error message doesn't match expected pattern
                    results.append(VerificationResult(
                        description=f"[Expected_Failure] {expected}",
                        passed=True,  # Still pass because failure occurred
                        expected_value=f"预期错误: {expected}",
                        actual_value="; ".join(error_messages + actual_messages),
                    ))

            # If no expected results defined, just check that failure occurred
            if not test_case.expected_results:
                results.append(VerificationResult(
                    description="[Expected_Failure] 预期执行失败",
                    passed=True,
                    expected_value="执行失败",
                    actual_value="执行失败",
                ))
        else:
            # No failure occurred → FAIL (expected failure didn't happen)
            for expected in test_case.expected_results:
                results.append(VerificationResult(
                    description=f"[Expected_Failure] {expected}",
                    passed=False,
                    expected_value=f"预期错误: {expected}",
                    actual_value="操作意外成功，未出现预期错误",
                ))

            if not test_case.expected_results:
                results.append(VerificationResult(
                    description="[Expected_Failure] 预期执行失败",
                    passed=False,
                    expected_value="执行失败",
                    actual_value="执行成功（不符合预期）",
                ))

        return results

    def verify_document_status(
        self,
        field_path: str,
        expected_status: str,
    ) -> VerificationResult:
        """读取凭证状态字段并验证。"""
        try:
            element = self._sap_wrapper.find_element(field_path)
            if element is None:
                return VerificationResult(
                    description=f"凭证状态字段: {field_path}",
                    passed=False,
                    expected_value=expected_status,
                    actual_value="字段未找到",
                )
            actual = str(element.Text) if element.Text else ""
            passed = expected_status in actual or actual in expected_status
            return VerificationResult(
                description=f"凭证状态字段: {field_path}",
                passed=passed,
                expected_value=expected_status,
                actual_value=actual,
            )
        except Exception as exc:
            return VerificationResult(
                description=f"凭证状态字段: {field_path}",
                passed=False,
                expected_value=expected_status,
                actual_value=f"读取失败: {exc}",
            )

    def verify_data_consistency(
        self,
        expected_data: dict[str, str],
        actual_data: dict[str, str],
    ) -> list[VerificationResult]:
        """数据一致性比较验证。"""
        results: list[VerificationResult] = []
        for key, expected_val in expected_data.items():
            actual_val = actual_data.get(key, "")
            passed = expected_val == actual_val
            results.append(VerificationResult(
                description=f"数据一致性: {key}",
                passed=passed,
                expected_value=expected_val,
                actual_value=actual_val,
            ))
        return results
