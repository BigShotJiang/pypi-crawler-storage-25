"""规则引擎 — 对已知的 SAP 标准操作直接生成步骤，不调用 GLM。

支持的场景：
- 纯登录用例
- 包含登录的业务用例（登录 + 导航 + 剩余业务步骤交给 GLM）

返回 RuleEngineResult，包含规则生成的步骤和需要 GLM 继续拆分的剩余文本。
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Any

from app.data.models import StepActionType, TestCase, TestStep

logger = logging.getLogger(__name__)

_LOGIN_KEYWORDS = ("登录", "login", "logon", "登入", "sign in", "输入密码", "输入登录")


@dataclass
class RuleEngineResult:
    """规则引擎结果"""
    steps: list[TestStep]
    remaining_text: str = ""  # 需要 GLM 继续拆分的剩余业务步骤文本
    fully_handled: bool = False  # 是否完全处理（不需要 GLM）


def _has_login_steps(test_case: TestCase) -> bool:
    text = (test_case.steps_text + test_case.purpose).lower()
    return any(kw in text for kw in _LOGIN_KEYWORDS)


def _is_pure_login_case(test_case: TestCase) -> bool:
    text = (test_case.purpose + test_case.case_id).lower()
    has_login = any(kw in text for kw in ("登录", "login", "logon"))
    has_tcode = bool(test_case.transaction_code and
                     test_case.transaction_code.upper() not in ("", "SE80", "SU01"))
    # 也检查 steps_text 里是否有事务码之后的业务操作
    has_business = bool(re.search(r'(输入.*类型|筛选|执行|保存|创建|修改|删除)', test_case.steps_text))
    return has_login and not has_tcode and not has_business


def _extract_login_data(test_case: TestCase) -> dict[str, str]:
    data = test_case.test_data
    text = test_case.steps_text

    client = data.get("客户端", data.get("client", ""))
    user = (data.get("用户", "") or data.get("用户名", "")
            or data.get("user", "") or data.get("username", ""))
    password = data.get("密码", data.get("password", ""))
    language = data.get("语言", data.get("language", "ZH"))

    if not user:
        m = re.search(r'(?:账号|用户|用户名)[：:\s]*(\S+)', text)
        if m:
            user = m.group(1).rstrip("，,。.")
    if not password:
        m = re.search(r'(?:密码|口令)[：:\s]*(\S+)', text)
        if m:
            password = m.group(1).rstrip("，,。.")
    if not client:
        m = re.search(r'(?:客户端)[：:\s]*(\d+)', text)
        if m:
            client = m.group(1)
        else:
            client = "100"

    return {"客户端": client, "用户": user, "密码": password, "语言": language}


def _extract_transaction_code(test_case: TestCase) -> str | None:
    if test_case.transaction_code:
        return test_case.transaction_code
    m = re.search(r'\b([A-Z]{2,4}\d{2,4}[A-Z]?)\b', test_case.steps_text)
    return m.group(1) if m else None


def _extract_remaining_business_text(test_case: TestCase, tcode: str | None) -> str:
    """提取登录和导航之后的业务操作步骤文本。"""
    text = test_case.steps_text

    # 按步骤编号分割
    parts = re.split(r'(?:\d+\.\s*)', text)
    remaining_parts = []
    found_tcode = False

    for part in parts:
        part = part.strip()
        if not part:
            continue
        # 跳过登录相关步骤
        if any(kw in part.lower() for kw in ("打开sap", "登录", "输入登录", "输入密码", "回车")):
            continue
        # 跳过事务码输入步骤
        if tcode and tcode.upper() in part.upper() and not found_tcode:
            found_tcode = True
            continue
        # 剩余的就是业务步骤
        remaining_parts.append(part)

    return "\n".join(f"{i+1}. {p}" for i, p in enumerate(remaining_parts)) if remaining_parts else ""


def generate_login_steps(test_case: TestCase, start_index: int = 1) -> list[TestStep]:
    login_data = _extract_login_data(test_case)
    steps: list[TestStep] = []
    idx = start_index

    for field_name, value in [
        ("客户端", login_data["客户端"]),
        ("用户", login_data["用户"]),
        ("密码", login_data["密码"]),
        ("语言", login_data["语言"]),
    ]:
        if value:
            steps.append(TestStep(
                index=idx, action_type=StepActionType.INPUT,
                target_description=field_name, value=value,
            ))
            idx += 1

    steps.append(TestStep(
        index=idx, action_type=StepActionType.CLICK,
        target_description="回车",
    ))
    idx += 1
    steps.append(TestStep(
        index=idx, action_type=StepActionType.WAIT,
        target_description="等待系统响应", value="3",
    ))
    return steps


def generate_navigate_steps(tcode: str, start_index: int) -> list[TestStep]:
    # navigate 执行时已自带 sendVKey(0)（即回车），无需额外生成回车步骤
    return [
        TestStep(
            index=start_index, action_type=StepActionType.NAVIGATE,
            target_description="命令输入框", value=f"/n{tcode}",
        ),
    ]


def try_rule_engine(test_case: TestCase) -> RuleEngineResult | None:
    """尝试用规则引擎生成步骤。

    Returns:
        RuleEngineResult（包含步骤和剩余文本），或 None（完全交给 GLM）。
    """
    has_login = _has_login_steps(test_case)
    tcode = _extract_transaction_code(test_case)

    # 场景 1: 包含登录 + 事务码（如"登录后打开 VA05 并操作"）
    if has_login and tcode:
        steps: list[TestStep] = []
        login_steps = generate_login_steps(test_case, start_index=1)
        steps.extend(login_steps)
        next_idx = len(steps) + 1

        nav_steps = generate_navigate_steps(tcode, start_index=next_idx)
        steps.extend(nav_steps)

        # 提取剩余业务步骤文本
        remaining = _extract_remaining_business_text(test_case, tcode)

        logger.info(
            "规则引擎: 登录+导航 %s，生成 %d 个步骤，剩余业务文本: %s",
            tcode, len(steps), remaining[:100] if remaining else "无",
        )
        return RuleEngineResult(
            steps=steps,
            remaining_text=remaining,
            fully_handled=not bool(remaining),
        )

    # 场景 2: 纯登录用例
    if _is_pure_login_case(test_case):
        steps = generate_login_steps(test_case, start_index=1)
        next_idx = len(steps) + 1
        steps.append(TestStep(
            index=next_idx, action_type=StepActionType.VERIFY,
            target_description="验证窗口标题", value="轻松访问",
        ))
        logger.info("规则引擎: 纯登录用例，生成 %d 个步骤", len(steps))
        return RuleEngineResult(steps=steps, fully_handled=True)

    return None
