"""统一执行引擎 — 替代 sap_routes.py 中的分离逻辑。

对每个步骤执行完整循环：
采集快照 → 处理弹窗 → 匹配屏幕 → 执行操作 → 采集后快照 → 验证 → 错误处理
"""

from __future__ import annotations

import logging
import time
from typing import Any

from app.config import STEP_WAIT_INTERVAL
from app.data.models import (
    RecoveryAction,
    ScreenSnapshot,
    StepActionType,
    StepResult,
    TestCase,
    TestStep,
)

logger = logging.getLogger(__name__)

# 特殊 CLICK 目标 → SAP GUI 路径/VKey 映射
_CLICK_MAP: dict[str, str] = {
    "回车": "vkey:0",
    "enter": "vkey:0",
    "保存": "wnd[0]/tbar[0]/btn[11]",
    "save": "wnd[0]/tbar[0]/btn[11]",
    "保存按钮": "wnd[0]/tbar[0]/btn[11]",
    "返回": "wnd[0]/tbar[0]/btn[3]",
    "back": "wnd[0]/tbar[0]/btn[3]",
}


class ExecutionEngine:
    """统一执行引擎 — 替代 sap_routes.py 中的分离逻辑。

    对每个步骤执行完整循环：
    采集快照 → 处理弹窗 → 匹配屏幕 → 执行操作 → 采集后快照 → 验证 → 错误处理
    """

    def __init__(
        self,
        sap_wrapper: Any,
        element_finder: Any,
        screen_collector: Any,
        dialog_handler: Any,
        screen_matcher: Any,
        self_healing: Any,
        flow_context: Any,
        knowledge_base: Any,
        step_splitter: Any,
        log_fn: Any = None,
    ) -> None:
        self._sap = sap_wrapper
        self._finder = element_finder
        self._collector = screen_collector
        self._dialog_handler = dialog_handler
        self._matcher = screen_matcher
        self._healing = self_healing
        self._flow_ctx = flow_context
        self._kb = knowledge_base
        self._splitter = step_splitter
        self._log = log_fn or (lambda msg: logger.info(msg))

    async def execute_test_case(
        self, test_case: TestCase
    ) -> list[StepResult]:
        """执行单个测试用例的完整流程。"""
        # 1. 拆分步骤
        test_steps = await self._splitter.split(test_case)
        self._log(f"拆分为 {len(test_steps)} 个步骤")

        # 2. 逐步执行
        results: list[StepResult] = []
        for idx, step in enumerate(test_steps, 1):
            self._log(
                f"▶ [{idx}/{len(test_steps)}] "
                f"{step.action_type.value}: {step.target_description}"
                f"{(' = ' + step.value) if step.value else ''}"
            )
            result = await self._execute_step(step)
            icon = "✅" if result.success else "❌"
            detail = result.status_bar_message or result.error_message or ""
            self._log(
                f"  {icon} Step {step.index} ({result.execution_time_ms}ms)"
                f"{(' ' + detail) if detail else ''}"
            )
            results.append(result)
            if not result.success and result.healing_action == RecoveryAction.ABORT:
                break

        # 3. 用例全部成功后更新知识库置信度
        all_success = all(r.success for r in results)
        if all_success and self._kb and test_case.transaction_code:
            template = self._kb.match_template(
                test_case.transaction_code,
                getattr(test_case, "scenario_type", "default"),
            )
            if template:
                self._kb.update_confidence(template.template_id, success=True)
                self._log(f"知识库置信度已更新: {template.template_id}")

        return results

    async def _execute_step(self, step: TestStep) -> StepResult:
        """执行单步 — 精简模式。

        只做核心操作：解析变量 → 执行 → 失败时自愈。
        弹窗检测和屏幕匹配不在每步执行，由调用方按需触发。
        """
        start_time = time.time()

        # 1. 解析流程变量
        resolved_step = self._resolve_variables(step)

        # 2. 直接执行操作
        try:
            exec_result = self._do_action(resolved_step)
        except Exception as exc:
            exec_result = StepResult(
                step_index=resolved_step.index,
                success=False,
                error_message=str(exc),
            )

        # 3. 失败时触发自愈（仅对可修复错误）
        if not exec_result.success and self._is_healable_error(
            exec_result.error_message
        ):
            self._log(f"  🔧 触发自愈: {exec_result.error_message}")
            full_snapshot = self._collector.collect_snapshot(
                include_element_tree=True
            )
            healing = await self._healing.handle_failure(
                step=resolved_step,
                error_message=exec_result.error_message or "",
                before_snapshot=full_snapshot,
                execute_fn=self._retry_action,
            )
            exec_result.success = healing.success
            exec_result.ai_intervention_records = healing.records

            if healing.success and healing.final_plan and self._kb:
                self._record_healing_correction(
                    resolved_step, healing.final_plan, full_snapshot
                )

        # 4. 步骤成功后提取凭证号
        if exec_result.success and self._flow_ctx:
            try:
                after_snapshot = self._collector.collect_snapshot(
                    include_element_tree=False
                )
                self._extract_document_number(after_snapshot, resolved_step)
            except Exception:
                pass

        # 5. 记录耗时
        exec_result.execution_time_ms = int(
            (time.time() - start_time) * 1000
        )

        return exec_result

    @staticmethod
    def _is_healable_error(error_message: str | None) -> bool:
        """判断错误是否值得触发 AI 自愈。

        对于明确无法通过 AI 修复的错误（如元素路径不存在、无 session），
        跳过自愈以节省时间和 Token。
        """
        if not error_message:
            return False

        # 这些错误 AI 有可能通过修正路径/参数来修复
        _HEALABLE_PATTERNS = (
            "字段未找到",       # ElementPathFinder 未匹配到
            "导航失败",         # 事务码导航异常
            "element not found",
        )
        # 这些错误 AI 无法修复，跳过自愈
        _SKIP_PATTERNS = (
            "无活动 session",
            "未知操作类型",
        )

        msg_lower = error_message.lower()
        for skip in _SKIP_PATTERNS:
            if skip in error_message:
                return False

        # "control could not be found by id" — SAP GUI 找不到控件
        # 这种情况 AI 可以尝试推荐替代路径
        if "could not be found by id" in msg_lower:
            return True

        for pattern in _HEALABLE_PATTERNS:
            if pattern in error_message:
                return True

        # 默认：触发自愈
        return True

    def _do_action(self, step: TestStep) -> StepResult:
        """根据 action_type 执行具体操作。"""
        session = self._sap.get_session()
        if not session:
            return StepResult(
                step_index=step.index, success=False,
                error_message="无活动 session",
            )

        if step.action_type == StepActionType.NAVIGATE:
            return self._do_navigate(session, step)
        elif step.action_type == StepActionType.INPUT:
            return self._do_input(session, step)
        elif step.action_type == StepActionType.CLICK:
            return self._do_click(session, step)
        elif step.action_type == StepActionType.SELECT:
            return self._do_select(session, step)
        elif step.action_type == StepActionType.VERIFY:
            return self._do_verify(session, step)
        elif step.action_type == StepActionType.WAIT:
            time.sleep(float(step.value or STEP_WAIT_INTERVAL))
            return StepResult(step_index=step.index, success=True)
        else:
            return StepResult(
                step_index=step.index, success=False,
                error_message=f"未知操作类型: {step.action_type}",
            )

    def _do_navigate(self, session: Any, step: TestStep) -> StepResult:
        """执行事务码导航。"""
        try:
            tcode = step.value or ""
            session.findById("wnd[0]/tbar[0]/okcd").text = tcode
            session.findById("wnd[0]").sendVKey(0)
            time.sleep(STEP_WAIT_INTERVAL)
            return StepResult(step_index=step.index, success=True)
        except Exception as exc:
            return StepResult(
                step_index=step.index, success=False,
                error_message=f"导航失败: {exc}",
            )

    def _do_input(self, session: Any, step: TestStep) -> StepResult:
        """执行输入操作 — 通过 ElementPathFinder 定位字段。"""
        match_result = self._finder.find_element_by_description(
            step.target_description
        )
        if match_result.found and match_result.element:
            try:
                self._sap.set_text(
                    match_result.element.id_path, step.value or ""
                )
                return StepResult(step_index=step.index, success=True)
            except Exception as exc:
                return StepResult(
                    step_index=step.index, success=False,
                    error_message=str(exc),
                )
        else:
            return StepResult(
                step_index=step.index, success=False,
                error_message=f"字段未找到: {step.target_description}",
            )

    def _do_click(self, session: Any, step: TestStep) -> StepResult:
        """执行点击操作 — 映射特殊目标到标准路径。"""
        target_lower = step.target_description.lower().strip()
        mapped = _CLICK_MAP.get(target_lower)

        try:
            if mapped:
                if mapped.startswith("vkey:"):
                    vkey = int(mapped.split(":")[1])
                    session.findById("wnd[0]").sendVKey(vkey)
                else:
                    session.findById(mapped).press()
            else:
                session.findById(step.target_description).press()
            return StepResult(step_index=step.index, success=True)
        except Exception as exc:
            return StepResult(
                step_index=step.index, success=False,
                error_message=f"点击失败: {exc}",
            )

    def _do_select(self, session: Any, step: TestStep) -> StepResult:
        """执行选择操作。"""
        try:
            self._sap.set_selected(
                step.target_description,
                step.value not in ("false", "0", "no"),
            )
            return StepResult(step_index=step.index, success=True)
        except Exception as exc:
            return StepResult(
                step_index=step.index, success=False,
                error_message=str(exc),
            )

    def _do_verify(self, session: Any, step: TestStep) -> StepResult:
        """执行验证操作 — 读取状态栏。"""
        sbar = self._sap.read_status_bar()
        return StepResult(
            step_index=step.index, success=True,
            status_bar_message=sbar.text,
        )

    def _resolve_variables(self, step: TestStep) -> TestStep:
        """解析步骤中的流程变量引用。"""
        if not step.value or not self._flow_ctx:
            return step
        try:
            resolved = self._flow_ctx.resolve(step.value)
            if resolved != step.value:
                logger.info("变量解析: '%s' → '%s'", step.value, resolved)
            return TestStep(
                index=step.index,
                action_type=step.action_type,
                target_description=step.target_description,
                value=resolved,
                flow_variable_ref=step.flow_variable_ref,
                row=step.row,
                column=step.column,
            )
        except KeyError as exc:
            logger.error("变量解析失败: %s", exc)
            raise

    def _extract_document_number(
        self, snapshot: ScreenSnapshot, step: TestStep
    ) -> None:
        """步骤成功后从状态栏提取凭证号并存入 FlowVariableContext。"""
        if not snapshot or not snapshot.status_bar_text:
            return
        variable_name = step.flow_variable_ref or None
        doc_no = self._flow_ctx.extract_document_number(
            snapshot.status_bar_text, variable_name
        )
        if doc_no:
            self._log(f"提取凭证号: {doc_no}")

    def _auto_navigate(self, step: TestStep) -> bool:
        """自动导航到正确屏幕。"""
        tcode = self._matcher.infer_transaction_code(step)
        if not tcode:
            return False
        session = self._sap.get_session()
        if not session:
            return False
        try:
            session.findById("wnd[0]/tbar[0]/okcd").text = f"/n{tcode}"
            session.findById("wnd[0]").sendVKey(0)
            time.sleep(STEP_WAIT_INTERVAL)
            return True
        except Exception as exc:
            logger.error("自动导航失败: %s", exc)
            return False

    async def _retry_action(
        self, step: TestStep,
        corrected_target: str | None,
        corrected_value: str | None,
    ) -> StepResult:
        """自愈重试回调。"""
        modified = TestStep(
            index=step.index,
            action_type=step.action_type,
            target_description=corrected_target or step.target_description,
            value=corrected_value or step.value,
            flow_variable_ref=step.flow_variable_ref,
            row=step.row,
            column=step.column,
        )
        return self._do_action(modified)

    def _record_healing_correction(
        self,
        step: TestStep,
        plan: Any,
        before_snapshot: ScreenSnapshot,
    ) -> None:
        """自愈成功后记录路径修正到知识库。"""
        if not plan.corrected_target:
            return
        tcode = self._matcher.infer_transaction_code(step)
        if not tcode:
            return
        template = self._kb.match_template(
            tcode, getattr(step, "scenario_type", "default")
        )
        if not template:
            return
        correction = {
            "step_description": f"[{step.action_type.value}] {step.target_description}",
            "original_path": step.target_description,
            "corrected_path": plan.corrected_target,
            "match_method": plan.action.value if hasattr(plan.action, "value") else str(plan.action),
            "screen_context": before_snapshot.window_title if before_snapshot else "",
        }
        self._kb.record_path_correction(template.template_id, correction)
        self._log(f"路径修正已记录: {step.target_description} → {plan.corrected_target}")
