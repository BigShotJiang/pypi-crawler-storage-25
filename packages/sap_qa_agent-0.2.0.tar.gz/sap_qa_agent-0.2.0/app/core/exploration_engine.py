"""ExplorationEngine - 探索模式引擎

首次执行事务码时的核心引擎，协调 AI 脚本生成、逐步执行和路径修正。
遇到路径错误时调用 ElementPathFinder 修正，遇到异常时调用 GLM 决策。
全部成功后将修正后的脚本固化为模板存入知识库。
"""

from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from app.config import MAX_AI_INTERVENTION_FAILURES
from app.data.knowledge_base import KnowledgeBase
from app.data.models import (
    AiIntervention,
    ExecutionCallbacks,
    PathCorrection,
    ScriptTemplate,
    StepResult,
    TemplateConfidence,
    TestStep,
)

logger = logging.getLogger(__name__)


@dataclass
class ExplorationResult:
    """探索模式执行结果"""
    success: bool
    step_results: list[StepResult] = field(default_factory=list)
    template_solidified: bool = False
    path_corrections: list[PathCorrection] = field(default_factory=list)
    ai_interventions: list[AiIntervention] = field(default_factory=list)


class ExplorationEngine:
    """探索模式引擎。

    协调 GLM 脚本生成 → ScriptExecutor 逐步执行 → ElementPathFinder 路径修正
    → GLM 异常处理 → 模板固化。
    """

    def __init__(
        self,
        glm_client: Any,
        script_executor: Any,
        element_finder: Any,
        knowledge_base: KnowledgeBase,
    ) -> None:
        self._glm = glm_client
        self._executor = script_executor
        self._element_finder = element_finder
        self._kb = knowledge_base

    async def explore(
        self,
        test_steps: list[TestStep],
        flow_context: Any,
        callbacks: ExecutionCallbacks | None = None,
        test_case_context: str = "",
    ) -> ExplorationResult:
        """执行探索流程。

        直接通过 ScriptExecutor 逐步执行 TestStep 列表，
        每步通过 ElementPathFinder 定位元素，失败时调用 GLM recovery。
        全部成功后固化为模板。
        """
        result = ExplorationResult(success=False)

        # 直接逐步执行（不再生成完整脚本，省掉 GLM 调用）
        skip_idx = getattr(self._executor, '_skip_before_index', 0)
        step_results = await self._executor.execute_script(
            test_steps,
            flow_context,
            step_callback=callbacks.on_step_result if callbacks else None,
            log_callback=callbacks.on_log if callbacks else None,
            test_case_context=test_case_context,
            skip_before_index=skip_idx,
        )
        result.step_results = step_results

        # Determine overall success
        all_success = all(sr.success for sr in step_results)
        result.success = all_success

        # Solidify template on success
        if all_success:
            try:
                template = await self.solidify_template(
                    "", result.path_corrections, test_steps,
                )
                result.template_solidified = True
                logger.info("Template solidified: %s", template.template_id)
            except Exception as exc:
                logger.error("Template solidification failed: %s", exc)

        return result

    async def _try_path_correction(
        self, step: TestStep, step_result: StepResult,
    ) -> PathCorrection | None:
        """尝试通过 ElementPathFinder 修正路径错误。"""
        error_msg = step_result.error_message or ""
        if "not found" not in error_msg.lower() and "element" not in error_msg.lower():
            return None

        try:
            match_result = self._element_finder.find_element_by_description(
                step.target_description
            )
            if match_result.found and match_result.element:
                correction = PathCorrection(
                    step_description=step.target_description,
                    original_path=step.target_description,
                    corrected_path=match_result.element.id_path,
                    match_method=match_result.match_method,
                    context="exploration",
                )
                logger.info(
                    "Path corrected for step %d: %s → %s (method: %s)",
                    step.index, step.target_description,
                    match_result.element.id_path, match_result.match_method,
                )
                return correction

            # If multiple candidates, try AI disambiguation
            if match_result.candidates:
                resolved = await self._element_finder.resolve_ambiguity(
                    match_result.candidates, step.target_description,
                )
                return PathCorrection(
                    step_description=step.target_description,
                    original_path=step.target_description,
                    corrected_path=resolved.id_path,
                    match_method="ai_disambiguation",
                    context="exploration",
                )
        except Exception as exc:
            logger.debug("Path correction attempt failed: %s", exc)

        return None

    async def _try_ai_recovery(self, step_result: StepResult) -> AiIntervention | None:
        """尝试通过 GLM 分析异常并恢复。"""
        error_msg = step_result.error_message or ""
        if not error_msg:
            return None

        try:
            recovery_plan = await self._glm.analyze_exception(
                error_info=error_msg,
                element_tree_snapshot="",
            )
            action = recovery_plan.get("action", "abort")
            reason = recovery_plan.get("reason", "")

            intervention = AiIntervention(
                exception_type="execution_error",
                ui_state=error_msg,
                ai_decision=action,
                result="recovered" if action in ("retry", "confirm", "skip") else "failed",
            )
            logger.info(
                "AI recovery for step %d: action=%s, reason=%s",
                step_result.step_index, action, reason,
            )
            return intervention
        except Exception as exc:
            logger.error("AI recovery failed: %s", exc)
            return None

    async def solidify_template(
        self,
        script: str,
        path_corrections: list[PathCorrection],
        test_steps: list[TestStep],
    ) -> ScriptTemplate:
        """将修正后的脚本固化为 ScriptTemplate 并存入知识库（DRAFT 置信度）。"""
        # Extract transaction code from steps
        transaction_code = ""
        scenario_type = "default"
        for step in test_steps:
            if step.value and step.value.startswith("/n"):
                transaction_code = step.value.replace("/n", "")
                break

        # Build element path map from corrections
        element_path_map: dict[str, str] = {}
        for pc in path_corrections:
            element_path_map[pc.step_description] = pc.corrected_path

        # Extract parameter names from steps
        parameters = []
        for step in test_steps:
            if step.value and not step.value.startswith("/n"):
                parameters.append(step.target_description)

        # Save original steps for reuse (preserving action_type, target, value)
        steps_dicts = [
            {
                "index": s.index,
                "action_type": s.action_type.value,
                "target_description": s.target_description,
                "value": s.value,
                "flow_variable_ref": s.flow_variable_ref,
            }
            for s in test_steps
        ]

        template = ScriptTemplate(
            template_id=f"tpl_{uuid.uuid4().hex[:12]}",
            transaction_code=transaction_code,
            scenario_type=scenario_type,
            script_content=script,
            element_path_map=element_path_map,
            parameters=parameters,
            confidence=TemplateConfidence.DRAFT,
            consecutive_success_count=1,
            created_at=datetime.now(),
            last_success_at=datetime.now(),
            path_corrections=path_corrections,
            steps=steps_dicts,
        )

        self._kb.save_template(template)
        return template
