"""步骤拆分器 — 调用 GLM 模型将自然语言操作步骤拆分为结构化 TestStep。"""

from __future__ import annotations

import logging
import re

from app.ai.glm_client import GlmClient
from app.ai.prompt_manager import PromptManager
from app.config import STEP_SPLIT_TIMEOUT
from app.data.models import StepActionType, TestCase, TestStep

logger = logging.getLogger(__name__)

_FLOW_VAR_PLACEHOLDER = re.compile(r"\$\{([A-Z_][A-Z0-9_]*)\}")

_ENTER_DESCRIPTIONS = {"回车", "enter"}


def _dedup_navigate_enter(steps: list[TestStep]) -> list[TestStep]:
    """过滤 navigate 步骤之后紧跟的冗余回车步骤。

    navigate 执行时已自带 sendVKey(0)（回车），如果下一步是 click 回车，
    则该回车步骤是多余的，会跳过初始界面。
    """
    if not steps:
        return steps

    filtered: list[TestStep] = []
    skip_next_enter = False

    for step in steps:
        if skip_next_enter:
            if (step.action_type == StepActionType.CLICK
                    and step.target_description.lower().strip() in _ENTER_DESCRIPTIONS):
                logger.info(
                    "跳过冗余回车步骤: Step %d (navigate 已自带回车)",
                    step.index,
                )
                skip_next_enter = False
                continue
            skip_next_enter = False

        filtered.append(step)

        if step.action_type == StepActionType.NAVIGATE:
            skip_next_enter = True

    # 重新编号
    for i, step in enumerate(filtered, 1):
        step.index = i

    return filtered


class StepSplitter:
    """AI 驱动的测试步骤拆分器。全部由 GLM 大模型拆分。"""

    def __init__(self, glm_client: GlmClient, prompt_manager: PromptManager) -> None:
        self._glm_client = glm_client
        self._prompt_manager = prompt_manager

    async def split(self, test_case: TestCase) -> list[TestStep]:
        """将 TestCase 的操作步骤拆分为结构化 TestStep 列表。全部由 GLM 完成。"""
        steps: list[TestStep] = []
        next_index = 1

        logger.info("Calling GLM to split steps for case %s", test_case.case_id)
        ai_steps = await self._glm_client.split_steps(
            test_case.steps_text, test_data=test_case.test_data,
        )

        for ai_step in ai_steps:
            step = TestStep(
                index=next_index,
                action_type=ai_step.action_type,
                target_description=ai_step.target_description,
                value=ai_step.value,
                flow_variable_ref=ai_step.flow_variable_ref,
                row=ai_step.row,
                column=ai_step.column,
            )
            if step.value and _FLOW_VAR_PLACEHOLDER.search(step.value):
                if not step.flow_variable_ref:
                    match = _FLOW_VAR_PLACEHOLDER.search(step.value)
                    if match:
                        step.flow_variable_ref = match.group(1)
            steps.append(step)
            next_index += 1

        logger.info("Split case %s into %d steps (before dedup)", test_case.case_id, len(steps))

        # 后处理：过滤 navigate 之后紧跟的冗余回车步骤
        steps = _dedup_navigate_enter(steps)

        logger.info("Split case %s into %d steps (after dedup)", test_case.case_id, len(steps))
        return steps
