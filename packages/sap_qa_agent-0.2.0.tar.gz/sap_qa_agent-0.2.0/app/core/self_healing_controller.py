"""AI 自愈控制器 — 步骤失败时调用 GLM 生成修正方案并执行。

在步骤执行失败时，采集当前屏幕快照，将失败信息发送给 GLM 获取
RecoveryPlan，按动作类型（retry/navigate/skip/abort）执行修正操作。
最多重试 MAX_AI_INTERVENTION_FAILURES 次，每次重试前等待并重新采集快照。
"""

from __future__ import annotations

import logging
import time
from typing import Any

from app.config import MAX_AI_INTERVENTION_FAILURES, STEP_WAIT_INTERVAL
from app.data.models import (
    HealingRecord,
    HealingResult,
    RecoveryAction,
    RecoveryPlan,
    ScreenSnapshot,
    TestStep,
)

logger = logging.getLogger(__name__)

CONFIDENCE_THRESHOLD = 0.3


class SelfHealingController:
    """AI 自愈控制器 — 步骤失败时调用 GLM 生成修正方案并执行。"""

    def __init__(
        self,
        glm_client: Any,
        screen_collector: Any,
        sap_wrapper: Any,
    ) -> None:
        self._glm = glm_client
        self._collector = screen_collector
        self._sap = sap_wrapper

    async def handle_failure(
        self,
        step: TestStep,
        error_message: str,
        before_snapshot: ScreenSnapshot,
        execute_fn: Any,
    ) -> HealingResult:
        """处理步骤失败，最多重试 MAX_AI_INTERVENTION_FAILURES 次。

        Args:
            step: 失败的测试步骤
            error_message: 错误消息
            before_snapshot: 执行前的屏幕快照
            execute_fn: 步骤执行回调函数 (step, corrected_target, corrected_value) -> StepResult

        Returns:
            HealingResult 包含最终结果和完整重试历史
        """
        healing_records: list[HealingRecord] = []
        context_history: list[dict] = []
        max_retries = MAX_AI_INTERVENTION_FAILURES

        for attempt in range(1, max_retries + 1):
            # 重试前等待并重新采集快照
            time.sleep(STEP_WAIT_INTERVAL)
            current_snapshot = self._collector.collect_snapshot()

            # 构建上下文（包含历史失败信息）
            context_history.append({
                "attempt": attempt,
                "error": error_message,
                "snapshot": _snapshot_to_str(current_snapshot),
            })

            # 调用 GLM 获取 Recovery_Plan
            try:
                plan = await self._request_recovery_plan(
                    step, error_message, current_snapshot, context_history
                )
            except Exception as exc:
                logger.error("GLM 调用失败 (attempt %d): %s", attempt, exc)
                healing_records.append(HealingRecord(
                    attempt=attempt,
                    snapshot=current_snapshot,
                    plan=None,
                    result_success=False,
                    error=str(exc),
                ))
                continue

            # 置信度检查
            if plan.confidence < CONFIDENCE_THRESHOLD:
                logger.warning(
                    "Recovery_Plan 置信度 %.2f < %.2f，降级为 abort",
                    plan.confidence, CONFIDENCE_THRESHOLD,
                )
                plan = RecoveryPlan(
                    action=RecoveryAction.ABORT,
                    reason=f"低置信度 ({plan.confidence:.2f})，原方案: {plan.reason}",
                    confidence=plan.confidence,
                )

            # 按动作类型执行
            if plan.action == RecoveryAction.ABORT:
                healing_records.append(HealingRecord(
                    attempt=attempt, snapshot=current_snapshot,
                    plan=plan, result_success=False, error="AI 建议终止",
                ))
                return HealingResult(
                    success=False, action_taken=RecoveryAction.ABORT,
                    records=healing_records, final_plan=plan,
                )

            if plan.action == RecoveryAction.SKIP:
                healing_records.append(HealingRecord(
                    attempt=attempt, snapshot=current_snapshot,
                    plan=plan, result_success=True, error=None,
                ))
                return HealingResult(
                    success=True, action_taken=RecoveryAction.SKIP,
                    records=healing_records, final_plan=plan,
                )

            if plan.action == RecoveryAction.NAVIGATE:
                nav_ok = await self._execute_navigation(plan.navigation_steps)
                if not nav_ok:
                    healing_records.append(HealingRecord(
                        attempt=attempt, snapshot=current_snapshot,
                        plan=plan, result_success=False, error="导航失败",
                    ))
                    continue

            # retry 或 navigate 后重试
            retry_result = await execute_fn(
                step,
                plan.corrected_target,
                plan.corrected_value,
            )

            healing_records.append(HealingRecord(
                attempt=attempt, snapshot=current_snapshot,
                plan=plan, result_success=retry_result.success,
                error=retry_result.error_message,
            ))

            if retry_result.success:
                return HealingResult(
                    success=True, action_taken=plan.action,
                    records=healing_records, final_plan=plan,
                )

            error_message = retry_result.error_message or error_message

        # 所有重试均失败
        return HealingResult(
            success=False, action_taken=RecoveryAction.ABORT,
            records=healing_records, final_plan=None,
        )

    async def _request_recovery_plan(
        self,
        step: TestStep,
        error_message: str,
        snapshot: ScreenSnapshot,
        context_history: list[dict],
    ) -> RecoveryPlan:
        """调用 GLM 获取 Recovery_Plan。"""
        raw = await self._glm.analyze_exception_v2(
            error_info=error_message,
            step_description=f"[{step.action_type.value}] {step.target_description}",
            screen_snapshot=_snapshot_to_str(snapshot),
            retry_history=context_history,
        )
        return RecoveryPlan.from_dict(raw)

    async def _execute_navigation(
        self, navigation_steps: list[dict] | None
    ) -> bool:
        """执行导航步骤序列。"""
        if not navigation_steps:
            return False
        session = self._sap.get_session()
        if not session:
            return False
        try:
            for nav in navigation_steps:
                tcode = nav.get("transaction_code", "")
                if tcode:
                    session.findById("wnd[0]/tbar[0]/okcd").text = tcode
                    session.findById("wnd[0]").sendVKey(0)
                    time.sleep(STEP_WAIT_INTERVAL)
            return True
        except Exception as exc:
            logger.error("导航执行失败: %s", exc)
            return False


def _snapshot_to_str(snapshot: ScreenSnapshot) -> str:
    """将 ScreenSnapshot 转为 GLM 可读的文本摘要。"""
    return (
        f"窗口标题: {snapshot.window_title}\n"
        f"状态栏: [{snapshot.status_bar_type.value}] {snapshot.status_bar_text}\n"
        f"活动窗口: {snapshot.active_window_id}\n"
        f"元素树: {snapshot.element_tree_summary}"
    )
