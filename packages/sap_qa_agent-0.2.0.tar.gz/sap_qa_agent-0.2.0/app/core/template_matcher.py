"""TemplateMatcher - 模板匹配器

根据事务码和场景类型查询知识库，决定进入探索模式还是复用模式。
"""

from __future__ import annotations

import logging
from dataclasses import dataclass

from app.data.knowledge_base import KnowledgeBase
from app.data.models import ScriptTemplate, TemplateConfidence

logger = logging.getLogger(__name__)


@dataclass
class MatchResult:
    """模板匹配结果"""
    matched: bool
    template: ScriptTemplate | None = None
    mode: str = "exploration"  # "exploration" or "reuse"
    confidence_warning: str | None = None  # Warning if template is DRAFT


class TemplateMatcher:
    """模板匹配器，查询知识库决定探索/复用模式。"""

    def __init__(self, knowledge_base: KnowledgeBase) -> None:
        self._kb = knowledge_base

    def match(self, transaction_code: str, scenario_type: str) -> MatchResult:
        """查询 KnowledgeBase 匹配模板。

        - 无匹配: mode="exploration"
        - 匹配且 STABLE: mode="reuse"
        - 匹配且 DRAFT: mode="reuse" + confidence_warning
        - 匹配且 NEEDS_FIX: mode="exploration" (重新探索)
        """
        template = self._kb.match_template(transaction_code, scenario_type)

        if template is None:
            logger.info(
                "No template found for %s/%s → exploration mode",
                transaction_code, scenario_type,
            )
            return MatchResult(matched=False, mode="exploration")

        if template.confidence == TemplateConfidence.NEEDS_FIX:
            logger.info(
                "Template %s has NEEDS_FIX confidence → exploration mode (re-explore)",
                template.template_id,
            )
            return MatchResult(
                matched=True,
                template=template,
                mode="exploration",
                confidence_warning="模板标记为待修复，将重新探索",
            )

        if template.confidence == TemplateConfidence.DRAFT:
            logger.info(
                "Template %s has DRAFT confidence → reuse mode with warning",
                template.template_id,
            )
            return MatchResult(
                matched=True,
                template=template,
                mode="reuse",
                confidence_warning="模板尚为草稿状态，执行结果可能不稳定",
            )

        # STABLE
        logger.info(
            "Template %s has STABLE confidence → reuse mode",
            template.template_id,
        )
        return MatchResult(
            matched=True,
            template=template,
            mode="reuse",
        )
