"""TestOrchestrator & DependencyGraph - 端到端测试编排

DependencyGraph: 用例依赖关系有向无环图，支持环检测、拓扑排序和级联跳过。
TestOrchestrator: 顶层编排器，协调步骤拆分、模板匹配、探索/复用执行、
                  结果验证和 FlowVariable 传递。
"""

from __future__ import annotations

import logging
import re
from collections import deque
from typing import Any

from app.data.flow_variable import FlowVariableContext
from app.data.models import (
    ExecutionCallbacks,
    ExecutionMode,
    StepActionType,
    StepResult,
    TestCase,
    TestCaseResult,
    TestStep,
    TestSuite,
    TestSuiteResult,
    VerificationResult,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# DependencyGraph
# ---------------------------------------------------------------------------


class DependencyGraph:
    """用例依赖关系有向无环图"""

    def __init__(self, test_suite: TestSuite) -> None:
        # case_id → list of dependency case_ids (prerequisites)
        self._graph: dict[str, list[str]] = {}
        self._build(test_suite)

    # -- construction -------------------------------------------------------

    def _build(self, test_suite: TestSuite) -> None:
        """Build DAG from TestCase dependencies.

        Resolves __case_ref_N references (from "用例N执行成功" patterns)
        to actual case_ids based on the position in the test suite.
        """
        # Build index: case number (1-based position) → case_id
        case_by_index: dict[str, str] = {}
        for i, tc in enumerate(test_suite.test_cases, 1):
            case_by_index[str(i)] = tc.case_id

        for tc in test_suite.test_cases:
            resolved_deps: list[str] = []
            for dep in tc.dependencies:
                if dep.startswith("__case_ref_"):
                    # Resolve "用例N" reference to actual case_id
                    ref_num = dep.replace("__case_ref_", "")
                    actual_id = case_by_index.get(ref_num)
                    if actual_id:
                        resolved_deps.append(actual_id)
                    else:
                        logger.warning(
                            "Case %s references 用例%s but no case at that position",
                            tc.case_id, ref_num,
                        )
                else:
                    resolved_deps.append(dep)
            self._graph[tc.case_id] = resolved_deps

    # -- validation ---------------------------------------------------------

    def validate(self) -> list[str]:
        """Validate DAG has no cycles. Return list of error messages."""
        errors: list[str] = []

        # Check that all referenced dependencies actually exist in the graph
        all_ids = set(self._graph.keys())
        for case_id, deps in self._graph.items():
            for dep in deps:
                if dep not in all_ids:
                    errors.append(
                        f"Case '{case_id}' depends on '{dep}' which is not in the suite"
                    )

        # Cycle detection via DFS colouring
        WHITE, GRAY, BLACK = 0, 1, 2
        colour: dict[str, int] = {cid: WHITE for cid in self._graph}

        def _dfs(node: str, path: list[str]) -> None:
            colour[node] = GRAY
            path.append(node)
            for dep in self._graph.get(node, []):
                if dep not in colour:
                    continue
                if colour[dep] == GRAY:
                    # Found a cycle – extract the cycle portion
                    cycle_start = path.index(dep)
                    cycle = path[cycle_start:] + [dep]
                    errors.append(
                        f"Cycle detected: {' → '.join(cycle)}"
                    )
                elif colour[dep] == WHITE:
                    _dfs(dep, path)
            path.pop()
            colour[node] = BLACK

        for cid in self._graph:
            if colour[cid] == WHITE:
                _dfs(cid, [])

        return errors

    # -- topological sort ---------------------------------------------------

    def get_execution_order(self) -> list[str]:
        """Topological sort, return execution order of case_ids.

        Uses Kahn's algorithm (BFS). If the graph has a cycle the returned
        list will be shorter than the number of nodes – callers should
        validate() first.
        """
        # Build in-degree map (how many prerequisites each case has)
        in_degree: dict[str, int] = {cid: 0 for cid in self._graph}
        for case_id, deps in self._graph.items():
            for dep in deps:
                if dep in in_degree:
                    # dep is a prerequisite of case_id, but in_degree
                    # counts how many prereqs *case_id* has – already
                    # counted via len(deps). We need reverse edges.
                    pass

        # Reverse: for each case, count how many other cases list it as dep
        in_degree = {cid: len(deps) for cid, deps in self._graph.items()}

        queue: deque[str] = deque()
        for cid, deg in in_degree.items():
            if deg == 0:
                queue.append(cid)

        order: list[str] = []
        while queue:
            node = queue.popleft()
            order.append(node)
            # Find all cases that depend on *node* and decrement their in-degree
            for cid, deps in self._graph.items():
                if node in deps:
                    in_degree[cid] -= 1
                    if in_degree[cid] == 0:
                        queue.append(cid)

        return order

    # -- cascade helpers ----------------------------------------------------

    def get_dependents(self, case_id: str) -> list[str]:
        """Get all case_ids that (transitively) depend on *case_id*."""
        dependents: set[str] = set()
        queue: deque[str] = deque([case_id])
        while queue:
            current = queue.popleft()
            for cid, deps in self._graph.items():
                if current in deps and cid not in dependents:
                    dependents.add(cid)
                    queue.append(cid)
        return list(dependents)


# ---------------------------------------------------------------------------
# TestOrchestrator
# ---------------------------------------------------------------------------


# Regex for extracting document numbers from step results (fallback)
_DOC_NUMBER_RE = re.compile(r"(\d{8,10})")


class TestOrchestrator:
    """端到端测试编排器"""

    def __init__(
        self,
        step_splitter: Any,
        template_matcher: Any,
        exploration_engine: Any,
        reuse_engine: Any,
        result_verifier: Any,
        script_executor: Any,
    ) -> None:
        self._step_splitter = step_splitter
        self._template_matcher = template_matcher
        self._exploration_engine = exploration_engine
        self._reuse_engine = reuse_engine
        self._result_verifier = result_verifier
        self._script_executor = script_executor

    # ------------------------------------------------------------------
    # Single test case execution
    # ------------------------------------------------------------------

    async def execute_test_case(
        self,
        test_case: TestCase,
        flow_context: FlowVariableContext,
        callbacks: ExecutionCallbacks | None = None,
    ) -> TestCaseResult:
        """Execute single test case:

        1. Split steps via StepSplitter
        2. Query template via TemplateMatcher → decide exploration/reuse
        3. Execute via ExplorationEngine or ReuseEngine
        4. Verify expected results via ResultVerifier
        5. Extract document numbers and store in FlowVariableContext
        """
        logger.info("Executing test case %s: %s", test_case.case_id, test_case.purpose)

        # Helper to push log if callback available
        def _log(msg: str):
            if callbacks and callbacks.on_log:
                callbacks.on_log(msg)

        # 1. Split steps
        _log("🤖 AI 拆分测试步骤...")
        test_steps = await self._step_splitter.split(test_case)
        logger.info("Case %s split into %d steps", test_case.case_id, len(test_steps))
        _log(f"✅ 拆分为 {len(test_steps)} 个步骤")

        # Push steps plan via callback
        if callbacks and callbacks.on_steps_plan:
            steps_plan_dicts = [
                {
                    "index": step.index,
                    "action": step.action_type.value if hasattr(step.action_type, 'value') else str(step.action_type),
                    "target": step.target_description,
                    "value": step.value,
                    "row": step.row,
                    "column": step.column,
                }
                for step in test_steps
            ]
            callbacks.on_steps_plan(steps_plan_dicts)

        # 1.5 Screen-aware step adjustment
        _log("🔍 屏幕感知：检查当前状态，动态调整步骤...")

        # 快速预过滤：如果已登录，直接移除登录步骤（不依赖 GLM）
        already_logged_in = (
            not self._script_executor.is_on_login_screen()
            or self._script_executor.is_logged_in()
        )
        if already_logged_in:
            login_targets = {"客户端", "用户", "密码", "语言"}
            # 也匹配包含这些关键词的描述（如"客户端号"、"用户名"等）
            login_keywords = ("客户端", "用户", "密码", "语言", "client", "user", "password", "language")
            before_count = len(test_steps)
            filtered = []
            skip_next_enter = False
            for step in test_steps:
                # 跳过登录字段输入
                if step.action_type == StepActionType.INPUT:
                    target_lower = step.target_description.lower().strip()
                    is_login_field = (
                        step.target_description in login_targets
                        or any(kw in target_lower for kw in login_keywords)
                    )
                    if is_login_field:
                        skip_next_enter = True
                        continue
                # 跳过登录后的回车和等待
                if skip_next_enter and step.action_type in (StepActionType.CLICK, StepActionType.WAIT):
                    if step.target_description in ("回车", "等待系统响应") or "等待" in step.target_description:
                        skip_next_enter = False
                        continue
                skip_next_enter = False
                filtered.append(step)

            if len(filtered) < before_count:
                # 重新编号
                for i, s in enumerate(filtered):
                    s.index = i + 1
                test_steps = filtered
                _log(f"  🔐 已登录，跳过登录步骤: {before_count} → {len(test_steps)} 步")
                # 推送更新后的步骤
                if callbacks and callbacks.on_steps_plan:
                    callbacks.on_steps_plan([
                        {"index": s.index, "action": s.action_type.value,
                         "target": s.target_description, "value": s.value}
                        for s in test_steps
                    ])

        original_step_count = len(test_steps)
        test_steps = await self._adjust_steps_for_screen(
            test_case, test_steps, callbacks, _log,
        )
        steps_adjusted = len(test_steps) != original_step_count

        # 2. Query template (skip reuse if steps were adjusted)
        transaction_code = test_case.transaction_code or ""
        scenario_type = "default"

        # 检查是否应该跳过复用模式
        skip_reuse = steps_adjusted
        if not skip_reuse and self._script_executor.is_on_login_screen():
            skip_reuse = True
            _log("  🔐 当前在登录界面，跳过模板复用")

        if skip_reuse:
            _log("  📝 跳过模板复用，直接执行当前步骤")

        match_result = self._template_matcher.match(transaction_code, scenario_type)

        # 3. Execute via exploration or reuse
        execution_mode: ExecutionMode
        step_results: list[StepResult] = []
        template_solidified = False

        if not skip_reuse and match_result.mode == "reuse" and match_result.template is not None:
            execution_mode = ExecutionMode.REUSE
            _log(f"📦 复用模式 (模板 {match_result.template.template_id})")
            logger.info("Case %s → reuse mode (template %s)",
                        test_case.case_id, match_result.template.template_id)
            reuse_result = await self._reuse_engine.execute_with_template(
                match_result.template,
                test_case.test_data,
                flow_context,
                callbacks=callbacks,
            )
            step_results = reuse_result.step_results

            # Fallback to exploration if reuse failed
            if reuse_result.needs_fallback:
                _log("⚠️ 复用失败，切换到探索模式")
                # Reset step results for the new attempt
                if callbacks and callbacks.on_steps_plan:
                    callbacks.on_steps_plan([])  # Clear steps_plan to signal reset
                logger.info("Case %s reuse failed, falling back to exploration",
                            test_case.case_id)
                execution_mode = ExecutionMode.EXPLORATION
                explore_result = await self._exploration_engine.explore(
                    test_steps, flow_context, callbacks=callbacks,
                    test_case_context=f"{test_case.case_id}: {test_case.purpose}\n步骤: {test_case.steps_text[:300]}",
                )
                step_results = explore_result.step_results
                template_solidified = explore_result.template_solidified
        else:
            execution_mode = ExecutionMode.EXPLORATION
            _log("🔍 探索模式 — AI 生成脚本...")
            logger.info("Case %s → exploration mode", test_case.case_id)
            explore_result = await self._exploration_engine.explore(
                test_steps, flow_context, callbacks=callbacks,
                test_case_context=f"{test_case.case_id}: {test_case.purpose}\n步骤: {test_case.steps_text[:300]}",
            )
            step_results = explore_result.step_results
            template_solidified = explore_result.template_solidified

        # 4. Verify expected results
        verification_results: list[VerificationResult] = (
            self._result_verifier.verify_expected_results(test_case, step_results)
        )

        # 5. Extract document numbers → store in FlowVariableContext
        flow_vars_extracted: dict[str, str] = {}
        for sr in step_results:
            doc_no = sr.extracted_document_number
            if not doc_no and sr.status_bar_message:
                doc_no = self._script_executor.extract_document_number(
                    sr.status_bar_message,
                )
            if doc_no:
                # Map to flow variable definitions from the test case
                for fv_def in test_case.flow_variable_defs:
                    if not flow_context.has(fv_def.name):
                        flow_context.set(fv_def.name, doc_no)
                        flow_vars_extracted[fv_def.name] = doc_no
                        logger.info(
                            "Flow variable %s = %s (case %s)",
                            fv_def.name, doc_no, test_case.case_id,
                        )
                        break

        # Determine overall success
        all_steps_ok = all(sr.success for sr in step_results) if step_results else False

        # If steps include verify-type steps that passed, trust the step results.
        # ResultVerifier's pattern matching on natural language expected_results
        # is supplementary — it should not override step-level verification.
        has_verify_steps = any(
            s.action_type == StepActionType.VERIFY
            for s in test_steps
        )
        if all_steps_ok and has_verify_steps:
            # Steps already include verification, trust them
            success = True
        else:
            all_verifications_ok = all(vr.passed for vr in verification_results) if verification_results else all_steps_ok
            success = all_steps_ok and all_verifications_ok

        return TestCaseResult(
            case_id=test_case.case_id,
            success=success,
            execution_mode=execution_mode,
            step_results=step_results,
            verification_results=verification_results,
            template_solidified=template_solidified,
            flow_variables_extracted=flow_vars_extracted,
        )

    # ------------------------------------------------------------------
    # Screen-aware step adjustment
    # ------------------------------------------------------------------

    async def _adjust_steps_for_screen(
        self,
        test_case: TestCase,
        test_steps: list[TestStep],
        callbacks: ExecutionCallbacks | None,
        _log,
    ) -> list[TestStep]:
        """根据当前屏幕状态动态调整步骤列表。

        采集当前屏幕 → 发给 GLM 一次性判断 → 返回调整后的步骤。
        """
        glm_client = getattr(self._script_executor, '_glm_client', None)
        element_finder = getattr(self._script_executor, '_element_finder', None)

        if glm_client is None:
            return test_steps

        # 采集当前屏幕状态（统一方法）
        screen = self._script_executor.get_current_screen()
        window_title = screen["window_title"]
        status_bar = screen["status_bar"]
        screen_elements = self._script_executor.collect_screen_elements_text(max_elements=40)

        _log(f"  📍 当前界面: {window_title}")

        # 构建原始步骤列表
        original_steps = [
            {
                "index": s.index,
                "action_type": s.action_type.value,
                "target_description": s.target_description,
                "value": s.value,
            }
            for s in test_steps
        ]

        try:
            adjusted = await glm_client.adjust_steps(
                test_case_context=f"{test_case.case_id}: {test_case.purpose}",
                window_title=window_title,
                status_bar=status_bar,
                screen_elements=screen_elements,
                original_steps=original_steps,
            )

            if not adjusted or not isinstance(adjusted, list):
                _log("  ⚠️ 步骤调整返回为空，使用原始步骤")
                return test_steps

            # 转换为 TestStep 对象
            new_steps: list[TestStep] = []
            for item in adjusted:
                target = (item.get("target_description")
                          or item.get("target") or "")
                action = item.get("action_type") or item.get("action") or "input"
                new_steps.append(TestStep(
                    index=item.get("index", len(new_steps) + 1),
                    action_type=StepActionType(action),
                    target_description=target,
                    value=item.get("value"),
                ))

            _log(f"  ✅ 步骤调整: {len(test_steps)} → {len(new_steps)} 步")

            # 推送调整后的步骤到前端
            if callbacks and callbacks.on_steps_plan:
                plan = [
                    {
                        "index": s.index,
                        "action": s.action_type.value,
                        "target": s.target_description,
                        "value": s.value,
                    }
                    for s in new_steps
                ]
                callbacks.on_steps_plan(plan)

            return new_steps

        except Exception as exc:
            logger.warning("Step adjustment failed: %s, using original steps", exc)
            _log(f"  ⚠️ 步骤调整失败: {exc}，使用原始步骤")
            return test_steps

    # ------------------------------------------------------------------
    # Test suite execution
    # ------------------------------------------------------------------

    async def execute_test_suite(self, test_suite: TestSuite) -> TestSuiteResult:
        """Execute test suite:

        1. Build dependency graph and validate
        2. Get execution order via topological sort
        3. Execute cases in order, maintaining FlowVariableContext
        4. On failure: cascade skip dependent cases
        5. Collect results and generate TestSuiteResult
        """
        logger.info("Executing test suite %s (%d cases)",
                     test_suite.suite_id, len(test_suite.test_cases))

        # 1. Build and validate dependency graph
        dep_graph = self.build_dependency_graph(test_suite)
        errors = dep_graph.validate()
        if errors:
            logger.error("Dependency graph validation errors: %s", errors)

        # 2. Get execution order
        execution_order = dep_graph.get_execution_order()
        logger.info("Execution order: %s", execution_order)

        # Build lookup
        case_map: dict[str, TestCase] = {
            tc.case_id: tc for tc in test_suite.test_cases
        }

        # 3. Execute in order
        flow_context = FlowVariableContext()
        case_results: list[TestCaseResult] = []
        skipped_ids: set[str] = set()
        new_templates = 0
        template_upgrades = 0

        for case_id in execution_order:
            tc = case_map.get(case_id)
            if tc is None:
                logger.warning("Case %s in execution order but not in suite", case_id)
                continue

            # 4. Check if this case should be skipped
            if case_id in skipped_ids:
                logger.info("Skipping case %s (dependency failure)", case_id)
                case_results.append(TestCaseResult(
                    case_id=case_id,
                    success=False,
                    execution_mode=ExecutionMode.EXPLORATION,
                    step_results=[],
                    verification_results=[
                        VerificationResult(
                            description="跳过（依赖失败）",
                            passed=False,
                            expected_value=None,
                            actual_value="跳过（依赖失败）",
                        )
                    ],
                ))
                continue

            # Execute the case
            result = await self.execute_test_case(tc, flow_context)
            case_results.append(result)

            # Track template metrics
            if result.template_solidified:
                new_templates += 1

            # On failure: cascade skip dependents
            if not result.success:
                dependents = dep_graph.get_dependents(case_id)
                for dep_id in dependents:
                    skipped_ids.add(dep_id)
                if dependents:
                    logger.info(
                        "Case %s failed → skipping dependents: %s",
                        case_id, dependents,
                    )

        # 5. Collect results
        passed = sum(1 for r in case_results if r.success)
        failed = sum(1 for r in case_results if not r.success and r.case_id not in skipped_ids)
        skipped = sum(1 for r in case_results if r.case_id in skipped_ids)

        return TestSuiteResult(
            suite_id=test_suite.suite_id,
            case_results=case_results,
            flow_variable_chain=flow_context.to_dict(),
            total_cases=len(case_results),
            passed_cases=passed,
            failed_cases=failed,
            skipped_cases=skipped,
            new_templates=new_templates,
            template_upgrades=template_upgrades,
        )

    # ------------------------------------------------------------------
    # Dependency graph builder
    # ------------------------------------------------------------------

    def build_dependency_graph(self, test_suite: TestSuite) -> DependencyGraph:
        """Build dependency graph for the test suite."""
        return DependencyGraph(test_suite)
