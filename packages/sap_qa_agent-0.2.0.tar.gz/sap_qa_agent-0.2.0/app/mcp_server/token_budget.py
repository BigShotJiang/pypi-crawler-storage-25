"""Token budget enforcement and truncation persistence.

Implements design §10.3 and requirements R14.1–R14.4:

* R14.1 — estimate token count as ``len(json_bytes) // 4``.
* R14.2 — when estimated tokens exceed ``token_budget``, strip large
  fields in priority order (``logs_tail`` → ``step_results`` →
  ``elements_text`` → ``image_base64``), persist the full payload to
  ``$ARTIFACTS_DIR/mcp-truncated/{cid}.json``, and mark the response
  with ``truncated=True`` + ``truncation_ref``.
* R14.3 — honour per-call ``_token_budget_override`` (capped at
  ``token_budget_max``, default 64000).
* R14.4 — ``inline_image=true`` in the tool input overrides the
  default URI-only behaviour; the budget logic does NOT strip
  ``image_base64`` when the caller explicitly requested it via the
  ``_inline_image_requested`` sentinel in the result dict.

The module exposes a single public function :func:`apply_token_budget`
which is imported by :mod:`app.mcp_server.middleware` in the
``_post_process`` hook. It receives the mutable result dict and the
:class:`~app.mcp_server.context.ServerContext` (for config access).
"""

from __future__ import annotations

import json
import logging
import os
from pathlib import Path
from typing import Any

from .context import ServerContext
from .errors import correlation_id_var

__all__ = ["apply_token_budget"]

logger = logging.getLogger(__name__)

# Fields stripped in priority order when the response exceeds the token
# budget. The order is chosen so that the least critical (verbose logs)
# are removed first and the most expensive (base64 images) last.
_STRIPPABLE_FIELDS: tuple[str, ...] = (
    "logs_tail",
    "step_results",
    "elements_text",
    "image_base64",
)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _estimate_tokens(result: dict[str, Any]) -> int:
    """Estimate token count for a response dict.

    Uses the simple heuristic from design §10.3: serialise to JSON,
    then divide byte length by 4 (≈ 4 characters per token for mixed
    CJK/ASCII content). This is intentionally approximate — the goal
    is to stay within a budget, not to produce an exact count.
    """
    try:
        payload_json = json.dumps(result, ensure_ascii=False, default=str)
    except (TypeError, ValueError):
        # If serialisation fails for some reason, return a large number
        # so the budget logic triggers and the caller gets a safe
        # truncated response rather than an oversized one.
        return 999_999
    return len(payload_json) // 4


def _persist_full_payload(
    result: dict[str, Any],
    cid: str,
    artifacts_dir: str,
) -> str:
    """Write the full (pre-truncation) payload to disk and return a ref URI.

    The file is written to ``$ARTIFACTS_DIR/mcp-truncated/{cid}.json``.
    The returned string is a ``sap-qa://`` URI that the host agent can
    later read via ``resources/read`` to retrieve the untruncated data.

    Parameters
    ----------
    result:
        The complete response dict *before* any fields are stripped.
    cid:
        The correlation id for this request (used as filename).
    artifacts_dir:
        Absolute path to the artifacts root directory.

    Returns
    -------
    str
        A ``sap-qa://artifacts/mcp-truncated/{cid}.json`` URI.
    """
    truncated_dir = Path(artifacts_dir) / "mcp-truncated"
    truncated_dir.mkdir(parents=True, exist_ok=True)

    out_path = truncated_dir / f"{cid}.json"
    try:
        out_path.write_text(
            json.dumps(result, ensure_ascii=False, indent=2, default=str),
            encoding="utf-8",
        )
    except OSError as exc:
        logger.warning(
            "Failed to persist truncated payload to %s: %s", out_path, exc
        )
        # Even if persistence fails, we still return the URI so the
        # response structure is consistent. The host will get a
        # RESOURCE_NOT_FOUND if it tries to read it later.

    return f"sap-qa://artifacts/mcp-truncated/{cid}.json"


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------


def apply_token_budget(result: dict[str, Any], ctx: ServerContext) -> None:
    """Enforce the token budget on a tool response, mutating it in place.

    Called by :func:`~app.mcp_server.middleware._post_process` after
    response scrubbing. If the estimated token count exceeds the
    effective budget, the full payload is persisted to disk and large
    fields are stripped from the in-memory dict.

    The effective budget is determined by:

    1. A per-call override via ``result.pop("_token_budget_override")``
       (set by tools that accept a ``token_budget`` input parameter).
    2. Capped at ``ctx.config.token_budget_max`` (default 64000).
    3. Falls back to ``ctx.config.token_budget`` (default 16000).

    The ``_inline_image_requested`` sentinel (set by tools like
    ``capture_screen`` when ``inline_image=True``) prevents stripping
    of ``image_base64`` even when the budget is exceeded — the caller
    explicitly asked for inline data (R14.4).

    Parameters
    ----------
    result:
        The mutable response dict. Modified in place.
    ctx:
        The server context providing config access.
    """
    # Pop internal sentinel keys that tools may have set.
    override = result.pop("_token_budget_override", None)
    inline_image_requested = result.pop("_inline_image_requested", False)

    # Determine effective budget.
    budget_max = ctx.config.token_budget_max
    if override is not None:
        try:
            effective_budget = int(override)
        except (TypeError, ValueError):
            effective_budget = ctx.config.token_budget
        # Cap at the configured maximum (R14.3).
        effective_budget = min(effective_budget, budget_max)
    else:
        effective_budget = ctx.config.token_budget

    # Estimate current size.
    est = _estimate_tokens(result)
    if est <= effective_budget:
        return

    # Budget exceeded — persist full payload before stripping.
    cid = correlation_id_var.get() or "unknown"
    ref = _persist_full_payload(result, cid, ctx.config.artifacts_dir)

    # Strip fields in priority order until under budget (or all gone).
    for key in _STRIPPABLE_FIELDS:
        # Honour inline_image override (R14.4): skip image_base64 if
        # the caller explicitly requested inline images.
        if key == "image_base64" and inline_image_requested:
            continue
        result.pop(key, None)

    # Mark the response as truncated.
    result["truncated"] = True
    result["truncation_ref"] = ref
