"""``capture_screen`` MCP tool — SAP GUI screen state capture.

Implements design §4.7 (screen capture tool). Provides the host agent
with a snapshot of the current SAP GUI screen including window title,
status bar, transaction code, a screenshot URI, and optionally the
formatted element tree text.

Key design decisions:

* **Screenshot persistence**: The PNG is written to
  ``$ARTIFACTS_DIR/mcp-captures/{timestamp}.png`` so it can be
  retrieved later via the ``sap-qa://artifacts/mcp-captures/...``
  resource URI without re-capturing.

* **Default no inline**: Per R14.4, the base64-encoded image is NOT
  included in the response by default. Only when the host agent
  explicitly passes ``inline_image=True`` is the image inlined. This
  keeps the default response well within the token budget.

* **Element text**: When ``include_elements=True`` (the default), the
  response includes ``elements_text`` produced by
  ``ScriptExecutor.collect_screen_elements_text(max_elements)``. This
  gives the host agent's LLM a textual description of the screen
  without needing to process the screenshot image.

Requirements covered: R9.1, R9.2, R9.3, R9.4, R9.5, R14.4.
"""

from __future__ import annotations

import base64
import logging
import os
import time
from pathlib import Path
from typing import Any

from fastmcp import FastMCP

from ..context import ServerContext
from ..errors import ErrorCode, fail, ok
from ..middleware import bind_middleware

__all__ = ["register"]

logger = logging.getLogger(__name__)


def register(mcp: FastMCP, ctx: ServerContext) -> None:
    """Register the ``capture_screen`` tool against *mcp*.

    The tool closes over ``ctx`` to access the shared SAP wrapper,
    script executor, and configuration (artifacts directory).
    """
    wrap = bind_middleware(ctx)

    @mcp.tool(name="capture_screen")
    @wrap
    def capture_screen(
        include_elements: bool = True,
        max_elements: int = 60,
        inline_image: bool = False,
    ) -> dict[str, Any]:
        """Capture the current SAP GUI screen state (R9.1).

        Returns window title, status bar info, transaction code, and a
        URI pointing to the saved screenshot. Optionally includes a
        textual summary of on-screen elements and/or the base64-encoded
        screenshot image.

        Parameters
        ----------
        include_elements:
            When ``True`` (default), the response includes
            ``elements_text`` — a formatted listing of up to
            ``max_elements`` screen elements produced by
            ``ScriptExecutor.collect_screen_elements_text``.
        max_elements:
            Maximum number of elements to include in
            ``elements_text``. Defaults to 60 (R9.1).
        inline_image:
            When ``True``, the response includes ``image_base64`` with
            the full PNG screenshot encoded as base64. Defaults to
            ``False`` to keep responses within the token budget (R14.4).

        Returns
        -------
        dict
            Success: ``{window_title, status_bar_text, status_bar_type,
            transaction_code, screenshot_uri, [elements_text],
            [image_base64]}``
            Failure: error envelope with ``SAP_NOT_CONNECTED``.
        """
        sap = ctx.sap_wrapper

        # R9.4: SAP must be connected
        if not sap.is_connected():
            return fail(
                ErrorCode.SAP_NOT_CONNECTED,
                message="尚未连接到 SAP 会话。请先调用 sap_connect 建立连接。",
            )

        # Generate timestamp for the screenshot filename
        timestamp = int(time.time() * 1000)

        # Build the output path: $ARTIFACTS_DIR/mcp-captures/{ts}.png (R9.5)
        captures_dir = os.path.join(
            ctx.config.artifacts_dir, "mcp-captures"
        )
        png_path = os.path.join(captures_dir, f"{timestamp}.png")

        # Take the screenshot — SapGuiWrapper.screenshot handles
        # directory creation internally via os.makedirs
        sap.screenshot(png_path)

        # Collect screen state via ScriptExecutor (R9.2)
        executor = ctx.sap_executor
        screen = executor.get_current_screen()

        # Read status bar with type info
        status_bar = sap.read_status_bar()

        # Build the response payload (R9.2)
        payload: dict[str, Any] = {
            "window_title": screen.get("window_title", ""),
            "status_bar_text": status_bar.text if status_bar else "",
            "status_bar_type": (
                status_bar.message_type.value if status_bar else "I"
            ),
            "transaction_code": screen.get("transaction", None),
            "screenshot_uri": (
                f"sap-qa://artifacts/mcp-captures/{timestamp}.png"
            ),
        }

        # R9.3: include elements text when requested
        if include_elements:
            payload["elements_text"] = (
                executor.collect_screen_elements_text(max_elements)
            )

        # R14.4: only inline base64 when explicitly requested
        if inline_image:
            screenshot_file = Path(png_path)
            if screenshot_file.exists():
                payload["image_base64"] = base64.b64encode(
                    screenshot_file.read_bytes()
                ).decode()
            else:
                logger.warning(
                    "Screenshot file not found for inline: %s", png_path
                )

        return ok(payload)
