"""``sap_connect`` / ``sap_disconnect`` / ``sap_session_status`` MCP tools.

Implements design §4.2 (session control tools) and §6.3 (channel lock
trigger timing). These tools manage the SAP GUI COM session lifecycle
within the MCP server process.

Key design decisions:

* **Channel lock on connect**: ``sap_connect`` acquires the channel lock
  (``channel_lock.acquire("mcp")``) *after* a successful COM connection.
  This ensures we only hold the lock when we actually have a live session.
  If the lock is already held by another channel, we return
  ``SAP_SESSION_OWNED_BY_OTHER_CHANNEL`` with the owner's details.

* **Singleton wrapper**: ``ServerContext.sap_wrapper`` is a lazy singleton
  (R3.6). Once connected, the same instance is reused for the entire
  stdio connection lifetime. ``sap_disconnect`` releases COM resources
  and the channel lock but does NOT destroy the wrapper instance — it
  can be reconnected later.

* **Error mapping**: COM exceptions from ``SapGuiWrapper.connect()`` are
  mapped to specific error codes:
  - ``hresult == -2147221020`` (MK_E_SYNTAX) → ``SAP_GUI_NOT_RUNNING``
  - ``GetScriptingEngine`` returns None → ``SCRIPTING_DISABLED``
  - ``ChannelLockedError`` → ``SAP_SESSION_OWNED_BY_OTHER_CHANNEL``

Requirements covered: R3.1, R3.2, R3.3, R3.4, R3.5, R3.6, R18.3.
"""

from __future__ import annotations

import logging
from typing import Any, Optional

from fastmcp import FastMCP

from ..channel_lock import ChannelLockedError
from ..context import ServerContext
from ..errors import ErrorCode, fail, ok
from ..middleware import bind_middleware

__all__ = ["register"]

logger = logging.getLogger(__name__)


def register(mcp: FastMCP, ctx: ServerContext) -> None:
    """Register SAP session control tools against *mcp*.

    Tools close over ``ctx`` to access the shared ``sap_wrapper`` and
    ``channel_lock``. The wrapper is lazily instantiated on first
    access (see :mod:`app.mcp_server.context`).
    """
    wrap = bind_middleware(ctx)

    @mcp.tool(name="sap_connect")
    @wrap
    def sap_connect(max_retries: Optional[int] = None) -> dict[str, Any]:
        """Connect to an existing SAP GUI session (R3.1).

        Attempts to attach to a running SAP GUI via COM Scripting API.
        On success, acquires the channel lock so that the FastAPI
        backend (if started later) knows the MCP channel owns the
        session.

        Parameters
        ----------
        max_retries:
            Override the default retry count (3) for COM connection
            attempts. Each retry waits 2 seconds.

        Returns
        -------
        dict
            Success: ``{connected: True, system_name, user, window_title}``
            Failure: error envelope with one of:
            - ``SAP_GUI_NOT_RUNNING`` — no SAP GUI process detected
            - ``SCRIPTING_DISABLED`` — SAP GUI found but scripting API
              is not enabled
            - ``SAP_SESSION_OWNED_BY_OTHER_CHANNEL`` — another channel
              (e.g. FastAPI backend) already holds the lock
        """
        sap = ctx.sap_wrapper

        # If already connected, just return current state (R3.6 singleton)
        if sap.is_connected():
            return _build_connect_response(sap)

        # Attempt COM connection
        retries = max_retries if max_retries is not None else 3
        try:
            success = sap.connect(max_retries=retries)
        except Exception as exc:
            return _map_connect_exception(exc)

        if not success:
            # connect() returned False — determine the reason
            return _diagnose_connect_failure(sap)

        # Connection succeeded — acquire the channel lock (design §6.3)
        try:
            ctx.channel_lock.acquire("mcp")
        except ChannelLockedError as exc:
            # Another channel owns the session. Release our COM
            # connection since we can't safely use it.
            _release_com(sap)
            return fail(
                ErrorCode.SAP_SESSION_OWNED_BY_OTHER_CHANNEL,
                message=(
                    "SAP 会话被其他通道占用。"
                    f"占用方: {exc.owner.channel} (PID {exc.owner.pid}, "
                    f"启动于 {exc.owner.started_at})"
                ),
                details={
                    "other_channel": exc.owner.channel,
                    "other_pid": exc.owner.pid,
                    "started_at": exc.owner.started_at,
                },
            )

        return _build_connect_response(sap)

    @mcp.tool(name="sap_disconnect")
    @wrap
    def sap_disconnect() -> dict[str, Any]:
        """Disconnect from the SAP GUI session and release resources (R3.2).

        Releases the COM session held by ``SapGuiWrapper`` and the
        channel lock so that other processes can take over. Safe to
        call even if not currently connected (idempotent).

        Returns
        -------
        dict
            ``{disconnected: True}``
        """
        sap = ctx.sap_wrapper

        # Release COM resources
        _release_com(sap)

        # Release the channel lock
        try:
            ctx.channel_lock.release()
        except Exception as exc:  # noqa: BLE001 - best-effort
            logger.warning("channel_lock.release() failed: %s", exc)

        return ok({"disconnected": True})

    @mcp.tool(name="sap_session_status")
    @wrap
    def sap_session_status() -> dict[str, Any]:
        """Return the current SAP session state (R3.3).

        Always succeeds — returns connection status and, when connected,
        additional session metadata (login screen detection, transaction
        code, window title).

        Returns
        -------
        dict
            ``{connected, on_login_screen, transaction_code, window_title}``
        """
        sap = ctx.sap_wrapper
        connected = sap.is_connected()

        if not connected:
            return ok({
                "connected": False,
                "on_login_screen": False,
                "transaction_code": None,
                "window_title": None,
            })

        # Read session info from the COM object
        session = sap.get_session()
        transaction_code = None
        window_title = None
        on_login_screen = False

        if session is not None:
            try:
                info = session.Info
                transaction_code = getattr(info, "Transaction", None)
                system_name = getattr(info, "SystemName", None)
                window_title = _get_window_title(session)

                # Detect login screen: transaction is typically empty or
                # "S000" on the login screen
                on_login_screen = transaction_code in (
                    None, "", "S000", "S001",
                )
            except Exception as exc:
                logger.debug(
                    "Failed to read session info: %s", exc
                )

        return ok({
            "connected": True,
            "on_login_screen": on_login_screen,
            "transaction_code": transaction_code,
            "window_title": window_title,
        })


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _build_connect_response(sap: Any) -> dict[str, Any]:
    """Build the success response for ``sap_connect`` (R3.1).

    Reads system_name, user, and window_title from the active session.
    Gracefully handles missing attributes so a partially-connected
    session still returns useful data.
    """
    session = sap.get_session()
    system_name = None
    user = None
    window_title = None

    if session is not None:
        try:
            info = session.Info
            system_name = getattr(info, "SystemName", None)
            user = getattr(info, "User", None)
            window_title = _get_window_title(session)
        except Exception as exc:
            logger.debug("Failed to read session info for connect response: %s", exc)

    return ok({
        "connected": True,
        "system_name": system_name,
        "user": user,
        "window_title": window_title,
    })


def _get_window_title(session: Any) -> Optional[str]:
    """Extract the active window title from a SAP session.

    Tries ``session.ActiveWindow.Text`` which is the standard
    SAP GUI Scripting property for the window title bar text.
    Falls back to ``session.Info.SystemName`` if unavailable.
    """
    try:
        active_window = session.ActiveWindow
        if active_window is not None:
            return getattr(active_window, "Text", None)
    except Exception:
        pass
    return None


def _map_connect_exception(exc: Exception) -> dict[str, Any]:
    """Map a COM exception from ``SapGuiWrapper.connect()`` to an error envelope.

    The hresult code ``-2147221020`` (MK_E_SYNTAX) indicates SAP GUI
    is not registered in the Running Object Table — meaning it's not
    running or not in a connectable state.
    """
    hresult = getattr(exc, "hresult", None)
    if hresult is None and exc.args:
        hresult = exc.args[0] if isinstance(exc.args[0], int) else None

    if hresult == -2147221020:
        # MK_E_SYNTAX — SAP GUI not running / not registered
        return fail(
            ErrorCode.SAP_GUI_NOT_RUNNING,
            message=(
                "SAP GUI 未运行或未就绪。请确认 SAP GUI 窗口已打开"
                "（不仅是 SAP Logon Pad，需要已连接到服务器）。"
                "启动 saplogon.exe 并连接到目标系统后重试。"
            ),
            details={"hresult": hresult},
        )

    # Generic COM failure — could be scripting disabled or other issue
    return fail(
        ErrorCode.SAP_GUI_NOT_RUNNING,
        message=f"连接 SAP GUI 失败: {str(exc)[:200]}",
        details={"exception": type(exc).__name__},
    )


def _diagnose_connect_failure(sap: Any) -> dict[str, Any]:
    """Determine why ``connect()`` returned False and return the right error.

    Checks whether SAP GUI is running at all vs. scripting being
    disabled. The distinction matters for the guidance text returned
    to the host agent (R3.4 vs R3.5).
    """
    # Check if SAP GUI is at least detectable
    scripting_ok = False
    try:
        scripting_ok = sap.ensure_scripting_enabled()
    except Exception:
        pass

    if not scripting_ok:
        # Could be either "not running" or "scripting disabled".
        # If ensure_scripting_enabled can't even find the process,
        # it's "not running". If it finds the process but can't get
        # the scripting engine, it's "disabled".
        #
        # Since ensure_scripting_enabled() tries GetObject("SAPGUI")
        # and returns False on failure, we can't easily distinguish
        # the two cases from its return value alone. Use a heuristic:
        # if the wrapper's _application is None, SAP GUI wasn't found.
        if getattr(sap, "_application", None) is None:
            return fail(
                ErrorCode.SAP_GUI_NOT_RUNNING,
                message=(
                    "SAP GUI 未运行。请启动 saplogon.exe 并连接到目标系统。"
                    "确保 SAP GUI 窗口已打开（不仅是 SAP Logon Pad）。"
                ),
            )
        else:
            return fail(
                ErrorCode.SCRIPTING_DISABLED,
                message=(
                    "SAP GUI Scripting 未启用。请按以下步骤开启：\n"
                    "1. 打开 SAP GUI → Options → Accessibility & Scripting → Scripting\n"
                    "2. 勾选 'Enable Scripting'\n"
                    "3. 取消勾选 'Notify When a Script Attaches' 和 "
                    "'Notify When a Script Opens a Connection'\n"
                    "4. 确认服务端参数 sapgui/user_scripting = TRUE"
                ),
            )

    # Scripting is enabled but connect still failed — unexpected state
    return fail(
        ErrorCode.SAP_GUI_NOT_RUNNING,
        message=(
            "SAP GUI Scripting 可用但连接失败。"
            "请确认至少有一个活动的 SAP 连接和会话。"
        ),
    )


def _release_com(sap: Any) -> None:
    """Release COM resources held by the SAP wrapper.

    Resets the internal state of ``SapGuiWrapper`` so it can be
    reconnected later. Uses direct attribute access since the wrapper
    doesn't expose a formal ``disconnect()`` method — it only has
    ``connect()`` and ``is_connected()``.
    """
    try:
        # Reset internal state to allow reconnection
        sap._session = None
        sap._connected = False
        sap._application = None
        sap._connection = None
    except Exception as exc:  # noqa: BLE001 - best-effort cleanup
        logger.warning("Failed to release SAP COM resources: %s", exc)
