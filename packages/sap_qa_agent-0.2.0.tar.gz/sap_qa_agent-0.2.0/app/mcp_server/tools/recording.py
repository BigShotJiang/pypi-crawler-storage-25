"""``start_recording`` / ``stop_recording`` MCP tools.

Implements design §4.8 (recording tools). These tools manage screen
recording sessions for capturing SAP GUI operations as video.

Key design decisions:

* **stdio transport blocked**: Recording installs global keyboard/mouse
  hooks that conflict with the host agent's input focus in stdio mode
  (R10.6, A13). Both tools return ``RECORDING_NOT_AVAILABLE_IN_STDIO``
  immediately when ``ctx.config.transport == "stdio"``.

* **Single active recording**: Only one recording session is allowed at
  a time (R10.3). ``ctx.recorder_state.active_id`` tracks the current
  session. Attempting to start a second recording returns
  ``RECORDING_IN_PROGRESS``.

* **FFMPEG graceful degradation**: When ffmpeg is not available,
  ``start_recording`` still succeeds (recording events only, no video)
  and responds with ``video_available=false`` (R10.5).

* **Recording ID**: A short UUID hex (12 chars) uniquely identifies
  each recording session.

* **Output path**: Video files are written to
  ``$ARTIFACTS_DIR/recordings/{recording_id}.mp4``.

Requirements covered: R10.1, R10.2, R10.3, R10.4, R10.5, R10.6, R10.7.
"""

from __future__ import annotations

import asyncio
import logging
from datetime import datetime
from pathlib import Path
from typing import Any, Optional
from uuid import uuid4

from fastmcp import FastMCP

from ..context import ServerContext
from ..errors import ErrorCode, fail, ok
from ..middleware import bind_middleware

__all__ = ["register"]

logger = logging.getLogger(__name__)


def register(mcp: FastMCP, ctx: ServerContext) -> None:
    """Register recording tools against *mcp*.

    Tools close over ``ctx`` to access the shared ``screen_recorder``,
    ``recorder_state``, and ``config`` (for transport mode detection).
    """
    wrap = bind_middleware(ctx)

    @mcp.tool(name="start_recording")
    @wrap
    def start_recording() -> dict[str, Any]:
        """Start screen recording of SAP GUI operations (R10.1).

        Begins capturing the screen to a video file. Only available in
        streamable-http transport mode — stdio mode returns an error
        because the recording module's global keyboard/mouse hooks
        conflict with the host agent's input focus.

        Returns
        -------
        dict
            Success: ``{recording_id, video_available}``
            Failure: error envelope with one of:
            - ``RECORDING_NOT_AVAILABLE_IN_STDIO`` — called in stdio mode
            - ``RECORDING_IN_PROGRESS`` — another recording is active
        """
        # R10.6: stdio transport blocks recording
        if ctx.config.transport == "stdio":
            return fail(
                ErrorCode.RECORDING_NOT_AVAILABLE_IN_STDIO,
                message=(
                    "录制功能在 stdio 传输模式下不可用。"
                    "录制模块会安装全局键鼠钩子，与宿主 Agent 的输入焦点冲突。"
                    "请使用 streamable-http 传输模式启动 MCP Server。"
                ),
            )

        # R10.3: only one recording at a time
        if ctx.recorder_state.active_id is not None:
            return fail(
                ErrorCode.RECORDING_IN_PROGRESS,
                message="已有录制任务在进行中，请先停止当前录制。",
                details={"active_recording_id": ctx.recorder_state.active_id},
            )

        # Generate a unique recording ID
        rec_id = uuid4().hex[:12]

        # Prepare output path
        recordings_dir = Path(ctx.config.artifacts_dir) / "recordings"
        recordings_dir.mkdir(parents=True, exist_ok=True)
        out_path = recordings_dir / f"{rec_id}.mp4"

        # Attempt to start the screen recorder (R10.5: ffmpeg graceful degradation)
        video_available = _run_async_start(ctx.screen_recorder, str(out_path))

        # Update recorder state
        ctx.recorder_state.active_id = rec_id
        ctx.recorder_state.started_at = datetime.now()

        return ok({
            "recording_id": rec_id,
            "video_available": video_available,
            "message": (
                "录制已开始。" if video_available
                else "录制已开始（仅记录事件，FFMPEG 不可用，无视频输出）。"
            ),
        })

    @mcp.tool(name="stop_recording")
    @wrap
    def stop_recording(recording_id: str) -> dict[str, Any]:
        """Stop an active screen recording session (R10.2).

        Stops the recording identified by ``recording_id`` and returns
        the URI to the recorded video file along with any captured
        structured steps.

        Parameters
        ----------
        recording_id:
            The recording ID returned by ``start_recording``.

        Returns
        -------
        dict
            Success: ``{recording_id, raw_events_uri, steps, duration_seconds}``
            Failure: error envelope with one of:
            - ``RECORDING_NOT_AVAILABLE_IN_STDIO`` — called in stdio mode
            - ``RECORDING_NOT_FOUND`` — unknown or already-stopped recording
        """
        # R10.6: stdio transport blocks recording
        if ctx.config.transport == "stdio":
            return fail(
                ErrorCode.RECORDING_NOT_AVAILABLE_IN_STDIO,
                message=(
                    "录制功能在 stdio 传输模式下不可用。"
                    "录制模块会安装全局键鼠钩子，与宿主 Agent 的输入焦点冲突。"
                    "请使用 streamable-http 传输模式启动 MCP Server。"
                ),
            )

        # R10.4: unknown or already-stopped recording
        if ctx.recorder_state.active_id != recording_id:
            return fail(
                ErrorCode.RECORDING_NOT_FOUND,
                message=f"未找到活动录制 '{recording_id}'。可能已停止或 ID 无效。",
                details={
                    "requested_id": recording_id,
                    "active_id": ctx.recorder_state.active_id,
                },
            )

        # Calculate duration
        duration_seconds: Optional[float] = None
        if ctx.recorder_state.started_at is not None:
            delta = datetime.now() - ctx.recorder_state.started_at
            duration_seconds = round(delta.total_seconds(), 1)

        # Stop the screen recorder
        _run_async_stop(ctx.screen_recorder)

        # Clear recorder state
        ctx.recorder_state.active_id = None
        ctx.recorder_state.started_at = None

        return ok({
            "recording_id": recording_id,
            "raw_events_uri": f"sap-qa://artifacts/recordings/{recording_id}.mp4",
            "steps": [],  # First version only records video; structured steps are future work
            "duration_seconds": duration_seconds,
        })


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _run_async_start(screen_recorder: Any, output_path: str) -> bool:
    """Run the async ``screen_recorder.start()`` from a sync context.

    The ScreenRecorder's ``start`` method is async (it spawns an ffmpeg
    subprocess). Since MCP tool handlers may be called from a sync
    context, we need to bridge the async gap. If an event loop is
    already running (e.g. under fastmcp's async runtime), we create a
    new thread to run the coroutine. Otherwise we use ``asyncio.run``.

    Returns True if video recording started successfully, False if
    ffmpeg is unavailable or failed to start (R10.5).
    """
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None

    coro = screen_recorder.start(output_path)

    if loop is not None and loop.is_running():
        # We're inside an async context — run in a new thread
        import concurrent.futures
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            future = pool.submit(asyncio.run, coro)
            try:
                return future.result(timeout=10)
            except Exception as exc:
                logger.warning("screen_recorder.start() failed: %s", exc)
                return False
    else:
        try:
            return asyncio.run(coro)
        except Exception as exc:
            logger.warning("screen_recorder.start() failed: %s", exc)
            return False


def _run_async_stop(screen_recorder: Any) -> Optional[str]:
    """Run the async ``screen_recorder.stop()`` from a sync context.

    Similar bridging logic as ``_run_async_start``. Returns the output
    file path on success, None on failure.
    """
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None

    coro = screen_recorder.stop()

    if loop is not None and loop.is_running():
        import concurrent.futures
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            future = pool.submit(asyncio.run, coro)
            try:
                return future.result(timeout=15)
            except Exception as exc:
                logger.warning("screen_recorder.stop() failed: %s", exc)
                return None
    else:
        try:
            return asyncio.run(coro)
        except Exception as exc:
            logger.warning("screen_recorder.stop() failed: %s", exc)
            return None
