"""``list_skills`` / ``get_skill`` MCP tools.

Implements design §4.9 and §8.5. Both tools are read-only and never
touch SAP COM, so they're always available regardless of the
``enable_atomic_tools`` flag or the current session state.

Requirements covered: R11.1, R11.2, R11.3.
"""

from __future__ import annotations

import logging
import re
from typing import Any

from fastmcp import FastMCP

from ..context import ServerContext
from ..errors import ErrorCode, fail, ok
from ..middleware import bind_middleware
from ..skills_loader.cache import SkillCache

__all__ = ["register"]

logger = logging.getLogger(__name__)


# Matches backtick-wrapped snake_case identifiers in SKILL.md bodies.
# Intersected with the set of registered tools to produce
# ``referenced_tools`` in the ``get_skill`` response (design §8.5).
_TOOL_REF_RE = re.compile(r"`([a-z][a-z0-9_]+)`")


def register(mcp: FastMCP, ctx: ServerContext) -> None:
    """Register Skills tools against *mcp*.

    Each tool closes over a single :class:`SkillCache` built from
    ``cfg.allow_paths`` / the bundled ``mcp_skills/`` directory. The
    cache is attached to ``ctx`` so other modules (e.g.
    :mod:`app.mcp_server.prompts`) can share it.
    """
    cache = _get_or_create_cache(ctx)
    wrap = bind_middleware(ctx)

    @mcp.tool(name="list_skills")
    @wrap
    def list_skills() -> dict[str, Any]:
        """Return every valid Skill's metadata (R11.1).

        The response includes ``skills`` as a list of
        :class:`SkillMetadata.to_dict()` payloads. Empty when no Skills
        are installed — that's valid (``tools=[]`` is explicitly
        allowed by R21.4 and the same shape applies here).
        """
        packages = cache.all()
        return ok(
            {
                "skills": [pkg.metadata.to_dict() for pkg in packages],
            }
        )

    @mcp.tool(name="get_skill")
    @wrap
    def get_skill(skill_id: str) -> dict[str, Any]:
        """Return a single Skill's full payload or ``SKILL_NOT_FOUND``.

        Response fields (R11.2):
        - ``metadata`` — same dict shape as ``list_skills`` entries.
        - ``content`` — ``SKILL.md`` body (without front-matter).
        - ``referenced_tools`` — tool names mentioned in the body
          (intersected with the actually-registered tool set so typos
          don't leak; see design §8.5).
        - ``prompts`` — optional ``prompts/*.md`` contents as a
          filename → text map.
        """
        pkg = cache.get(skill_id)
        if pkg is None:
            return fail(
                ErrorCode.SKILL_NOT_FOUND,
                details={"skill_id": skill_id},
            )

        registered = _registered_tool_names(mcp)
        mentioned = {m.group(1) for m in _TOOL_REF_RE.finditer(pkg.content_md)}
        referenced = sorted(mentioned & registered)

        return ok(
            {
                "metadata": pkg.metadata.to_dict(),
                "content": pkg.content_md,
                "referenced_tools": referenced,
                "prompts": dict(pkg.prompts),
            }
        )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_or_create_cache(ctx: ServerContext) -> SkillCache:
    """Return the shared :class:`SkillCache`, creating it if needed.

    Lives on ``ctx.skill_cache`` so other modules (Prompts registration
    in Task 5.2) can reuse it instead of re-scanning the filesystem.
    """
    existing = getattr(ctx, "skill_cache", None)
    if existing is not None:
        return existing

    from ..safety import _mcp_skills_dir  # local import to avoid cycle at module load

    skills_dir = _mcp_skills_dir()
    cache = SkillCache(skills_dir)
    # Attribute assignment on ServerContext is allowed (it's a regular class,
    # not a Pydantic model); lets other tool modules share the cache.
    ctx.skill_cache = cache  # type: ignore[attr-defined]
    return cache


def _registered_tool_names(mcp: FastMCP) -> set[str]:
    """Best-effort enumeration of currently-registered tool names.

    ``fastmcp`` versions differ on the manager attribute name; try the
    common ones and fall back to an empty set rather than crashing.
    The intersection with the tool names mentioned in a SKILL.md is
    only a quality-of-life feature; losing it silently is better than
    breaking ``get_skill``.
    """
    candidates = (
        "_tool_manager",
        "tool_manager",
        "tools",
    )
    for attr in candidates:
        manager = getattr(mcp, attr, None)
        if manager is None:
            continue
        tools = getattr(manager, "_tools", None) or getattr(manager, "tools", None)
        if isinstance(tools, dict):
            return set(tools.keys())
        if hasattr(tools, "keys"):
            try:
                return set(tools.keys())  # type: ignore[arg-type]
            except Exception:  # noqa: BLE001
                continue
    return set()
