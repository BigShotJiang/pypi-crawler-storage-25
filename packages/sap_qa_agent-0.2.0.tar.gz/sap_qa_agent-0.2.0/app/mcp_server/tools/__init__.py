"""Per-category Tool modules.

Each module exposes a module-level ``register(mcp, ctx)`` function that
the :mod:`app.mcp_server.server.register_all` walker calls during
``build_mcp``. The convention lets phases 4–7 deliver their tools
without touching :mod:`app.mcp_server.server`.
"""
