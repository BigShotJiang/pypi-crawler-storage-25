"""Atomic SAP operation tools — single-step ``sap_input`` / ``sap_click`` / etc.

Implements design §4.6 (optional atomic tools gated by
``ConfigProfile.enable_atomic_tools``). When enabled, eight tools are
registered that each construct a :class:`~app.data.models.TestStep` and
delegate to :meth:`ScriptExecutor.execute_step`. When disabled, a single
placeholder tool ``sap_atomic_disabled`` is registered that returns
``ATOMIC_TOOLS_DISABLED`` so the host agent can discover the capability
is present but inactive.

Key design decisions:

* **Shared SAP session**: All atomic tools use the same
  ``ServerContext.sap_wrapper`` instance (R8.5). They never reconnect
  COM — if the session is not connected, they return
  ``SAP_NOT_CONNECTED``.

* **Self-healing**: When ``with_self_healing=True``, the tool invokes
  :class:`~app.core.self_healing_controller.SelfHealingController` for
  up to 3 retry attempts. The response includes ``healing_records``
  with the full retry history. If GLM is not configured, self-healing
  is silently disabled and a ``warnings`` field is added.

* **FlowVariableContext**: Atomic tools pass ``None`` as the flow
  context since they operate on individual steps without a surrounding
  test case flow.

Requirements covered: R8.1, R8.2, R8.3, R8.4, R8.5.
"""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Any, Optional

from fastmcp import FastMCP

from app.data.models import (
    HealingRecord,
    ScreenSnapshot,
    StepActionType,
    StepResult,
    TestStep,
)

from ..context import ServerContext
from ..errors import ErrorCode, fail, ok
from ..middleware import bind_middleware

__all__ = ["register"]

logger = logging.getLogger(__name__)

# Maximum self-healing retry attempts (design §4.6)
_MAX_HEALING_ATTEMPTS = 3


def register(mcp: FastMCP, ctx: ServerContext) -> None:
    """Register atomic SAP tools or the disabled placeholder.

    When ``ctx.config.enable_atomic_tools`` is ``True``, registers the
    eight atomic operation tools. Otherwise registers only the
    ``sap_atomic_disabled`` placeholder (R8.3).
    """
    if not ctx.config.enable_atomic_tools:
        _register_disabled_placeholder(mcp, ctx)
    else:
        _register_atomic_tools(mcp, ctx)


# ---------------------------------------------------------------------------
# Disabled placeholder (R8.3)
# ---------------------------------------------------------------------------


def _register_disabled_placeholder(mcp: FastMCP, ctx: ServerContext) -> None:
    """Register a single placeholder tool when atomic tools are off."""
    wrap = bind_middleware(ctx)

    @mcp.tool(name="sap_atomic_disabled")
    @wrap
    def sap_atomic_disabled() -> dict[str, Any]:
        """Atomic tools are disabled in this server configuration.

        Enable them by setting ``enable_atomic_tools=true`` in the
        config file or passing ``--enable-atomic-tools`` on the CLI.
        """
        return fail(
            ErrorCode.ATOMIC_TOOLS_DISABLED,
            message=(
                "原子操作工具已禁用。请在配置中设置 "
                "enable_atomic_tools=true 或启动时传入 "
                "--enable-atomic-tools 参数。"
            ),
        )


# ---------------------------------------------------------------------------
# Atomic tool registration (R8.1, R8.2)
# ---------------------------------------------------------------------------


def _register_atomic_tools(mcp: FastMCP, ctx: ServerContext) -> None:
    """Register all eight atomic SAP operation tools."""
    wrap = bind_middleware(ctx)

    @mcp.tool(name="sap_input")
    @wrap
    def sap_input(
        target: str,
        value: str,
        row: Optional[int] = None,
        column: Optional[str] = None,
        with_self_healing: bool = False,
    ) -> dict[str, Any]:
        """Input a value into a SAP GUI field (R8.1).

        Parameters
        ----------
        target:
            Description or path of the target field.
        value:
            The text value to input.
        row:
            Table row number (1-based) for table operations.
        column:
            Table column name for table operations.
        with_self_healing:
            Enable AI self-healing on failure (max 3 retries).
        """
        step = TestStep(
            index=0,
            action_type=StepActionType.INPUT,
            target_description=target,
            value=value,
            row=row,
            column=column,
        )
        return _execute_atomic(ctx, step, with_self_healing)

    @mcp.tool(name="sap_click")
    @wrap
    def sap_click(
        target: str,
        row: Optional[int] = None,
        column: Optional[str] = None,
        with_self_healing: bool = False,
    ) -> dict[str, Any]:
        """Click a SAP GUI element (R8.1).

        Parameters
        ----------
        target:
            Description or path of the element to click.
        row:
            Table row number (1-based) for table operations.
        column:
            Table column name for table operations.
        with_self_healing:
            Enable AI self-healing on failure (max 3 retries).
        """
        step = TestStep(
            index=0,
            action_type=StepActionType.CLICK,
            target_description=target,
            row=row,
            column=column,
        )
        return _execute_atomic(ctx, step, with_self_healing)

    @mcp.tool(name="sap_double_click")
    @wrap
    def sap_double_click(
        target: str,
        row: Optional[int] = None,
        column: Optional[str] = None,
        with_self_healing: bool = False,
    ) -> dict[str, Any]:
        """Double-click a SAP GUI element (R8.1).

        Parameters
        ----------
        target:
            Description or path of the element to double-click.
        row:
            Table row number (1-based) for table operations.
        column:
            Table column name for table operations.
        with_self_healing:
            Enable AI self-healing on failure (max 3 retries).
        """
        step = TestStep(
            index=0,
            action_type=StepActionType.DOUBLE_CLICK,
            target_description=target,
            row=row,
            column=column,
        )
        return _execute_atomic(ctx, step, with_self_healing)

    @mcp.tool(name="sap_select")
    @wrap
    def sap_select(
        target: str,
        value: Optional[str] = None,
        row: Optional[int] = None,
        column: Optional[str] = None,
        with_self_healing: bool = False,
    ) -> dict[str, Any]:
        """Select an item in a SAP GUI dropdown or list (R8.1).

        Parameters
        ----------
        target:
            Description or path of the selection control.
        value:
            The value/option to select.
        row:
            Table row number (1-based) for table operations.
        column:
            Table column name for table operations.
        with_self_healing:
            Enable AI self-healing on failure (max 3 retries).
        """
        step = TestStep(
            index=0,
            action_type=StepActionType.SELECT,
            target_description=target,
            value=value,
            row=row,
            column=column,
        )
        return _execute_atomic(ctx, step, with_self_healing)

    @mcp.tool(name="sap_verify")
    @wrap
    def sap_verify(
        target: str,
        value: Optional[str] = None,
        row: Optional[int] = None,
        column: Optional[str] = None,
        with_self_healing: bool = False,
    ) -> dict[str, Any]:
        """Verify a value or state in a SAP GUI element (R8.1).

        Parameters
        ----------
        target:
            Description or path of the element to verify.
        value:
            Expected value to verify against.
        row:
            Table row number (1-based) for table operations.
        column:
            Table column name for table operations.
        with_self_healing:
            Enable AI self-healing on failure (max 3 retries).
        """
        step = TestStep(
            index=0,
            action_type=StepActionType.VERIFY,
            target_description=target,
            value=value,
            row=row,
            column=column,
        )
        return _execute_atomic(ctx, step, with_self_healing)

    @mcp.tool(name="sap_read")
    @wrap
    def sap_read(
        target: str,
        row: Optional[int] = None,
        column: Optional[str] = None,
        with_self_healing: bool = False,
    ) -> dict[str, Any]:
        """Read a value from a SAP GUI element (R8.1).

        Parameters
        ----------
        target:
            Description or path of the element to read.
        row:
            Table row number (1-based) for table operations.
        column:
            Table column name for table operations.
        with_self_healing:
            Enable AI self-healing on failure (max 3 retries).
        """
        step = TestStep(
            index=0,
            action_type=StepActionType.READ,
            target_description=target,
            row=row,
            column=column,
        )
        return _execute_atomic(ctx, step, with_self_healing)

    @mcp.tool(name="sap_navigate")
    @wrap
    def sap_navigate(
        target: str,
        value: Optional[str] = None,
        with_self_healing: bool = False,
    ) -> dict[str, Any]:
        """Navigate to a transaction code or menu path (R8.1).

        Parameters
        ----------
        target:
            Transaction code (e.g. "VA01") or menu path description.
        value:
            Optional additional navigation parameter.
        with_self_healing:
            Enable AI self-healing on failure (max 3 retries).
        """
        step = TestStep(
            index=0,
            action_type=StepActionType.NAVIGATE,
            target_description=target,
            value=value,
        )
        return _execute_atomic(ctx, step, with_self_healing)

    @mcp.tool(name="sap_wait")
    @wrap
    def sap_wait(
        target: str,
        value: Optional[str] = None,
        with_self_healing: bool = False,
    ) -> dict[str, Any]:
        """Wait for a SAP GUI condition to be met (R8.1).

        Parameters
        ----------
        target:
            Description of the condition to wait for (e.g. a status
            bar message or window title).
        value:
            Optional expected value to wait for.
        with_self_healing:
            Enable AI self-healing on failure (max 3 retries).
        """
        step = TestStep(
            index=0,
            action_type=StepActionType.WAIT,
            target_description=target,
            value=value,
        )
        return _execute_atomic(ctx, step, with_self_healing)


# ---------------------------------------------------------------------------
# Core execution logic
# ---------------------------------------------------------------------------


def _execute_atomic(
    ctx: ServerContext,
    step: TestStep,
    with_self_healing: bool,
) -> dict[str, Any]:
    """Execute a single atomic step, optionally with self-healing.

    This is the shared implementation for all eight atomic tools.
    It checks SAP connectivity, runs the step via ScriptExecutor,
    and optionally invokes SelfHealingController on failure.

    Parameters
    ----------
    ctx:
        The server context providing sap_wrapper, sap_executor, etc.
    step:
        The constructed TestStep to execute.
    with_self_healing:
        Whether to attempt AI-driven self-healing on failure.

    Returns
    -------
    dict
        Success envelope with ``StepResult`` data and optional
        ``healing_records``, or a failure envelope.
    """
    sap = ctx.sap_wrapper

    # Pre-check: SAP must be connected (R8.5)
    if not sap.is_connected():
        return fail(
            ErrorCode.SAP_NOT_CONNECTED,
            message="SAP 未连接。请先调用 sap_connect 建立会话。",
        )

    # Execute the step via ScriptExecutor
    executor = ctx.sap_executor
    result: StepResult = _run_step_sync(executor, step)

    # If successful, return immediately
    if result.success:
        return _build_step_response(result)

    # If self-healing is disabled, return the failure
    if not with_self_healing:
        return _build_step_response(result)

    # Check GLM availability for self-healing
    warnings: list[str] = []
    glm_available = _is_glm_configured(ctx)
    if not glm_available:
        warnings.append(
            "GLM API Key 未配置，自愈功能已自动禁用。"
            "请设置 GLM_API_KEY 环境变量以启用 AI 自愈。"
        )
        response = _build_step_response(result)
        if warnings:
            response["data"]["warnings"] = warnings
        return response

    # Attempt self-healing (R8.4) — up to 3 retries
    healing_records = _attempt_self_healing(ctx, step, result)

    # Check if healing succeeded (last record is success)
    healed = bool(healing_records and healing_records[-1].result_success)

    if healed:
        # Re-execute the step to get the final result
        final_result = _run_step_sync(executor, step)
        response = _build_step_response(final_result)
    else:
        response = _build_step_response(result)

    # Attach healing records to the response
    response["data"]["healing_records"] = [
        _serialize_healing_record(r) for r in healing_records
    ]
    if warnings:
        response["data"]["warnings"] = warnings

    return response


def _run_step_sync(executor: Any, step: TestStep) -> StepResult:
    """Run ScriptExecutor.execute_step synchronously.

    ScriptExecutor.execute_step is an async method; we run it in
    an event loop since MCP tool handlers are synchronous.
    """
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            # We're inside an existing event loop (e.g. fastmcp's async
            # context). Use a new thread to avoid nested loop issues.
            import concurrent.futures

            with concurrent.futures.ThreadPoolExecutor(1) as pool:
                future = pool.submit(asyncio.run, executor.execute_step(step))
                return future.result(timeout=60)
        else:
            return loop.run_until_complete(executor.execute_step(step))
    except RuntimeError:
        # No event loop exists — create one
        return asyncio.run(executor.execute_step(step))


def _attempt_self_healing(
    ctx: ServerContext,
    step: TestStep,
    initial_result: StepResult,
) -> list[HealingRecord]:
    """Invoke SelfHealingController for up to 3 retries.

    Constructs a SelfHealingController using the shared GLM client
    and SAP wrapper, then delegates failure handling.

    Returns the list of HealingRecord from the healing attempt.
    """
    from app.core.self_healing_controller import SelfHealingController

    try:
        # Build a screen collector that captures the current state
        collector = _ScreenCollector(ctx)
        before_snapshot = collector.collect_snapshot()

        controller = SelfHealingController(
            glm_client=ctx.glm_client,
            screen_collector=collector,
            sap_wrapper=ctx.sap_wrapper,
        )

        # The execute_fn callback for the healing controller
        async def _execute_fn(
            s: TestStep,
            corrected_target: str | None,
            corrected_value: str | None,
        ) -> StepResult:
            """Re-execute the step with optional corrections."""
            corrected_step = TestStep(
                index=s.index,
                action_type=s.action_type,
                target_description=corrected_target or s.target_description,
                value=corrected_value if corrected_value is not None else s.value,
                row=s.row,
                column=s.column,
            )
            return await ctx.sap_executor.execute_step(corrected_step)

        error_msg = initial_result.error_message or "步骤执行失败"

        # Run the async healing handler synchronously
        healing_result = _run_async_sync(
            controller.handle_failure(
                step=step,
                error_message=error_msg,
                before_snapshot=before_snapshot,
                execute_fn=_execute_fn,
            )
        )

        return healing_result.records

    except Exception as exc:
        logger.warning("Self-healing attempt failed: %s", exc)
        # Return a single failed record indicating the healing itself failed
        return [
            HealingRecord(
                attempt=1,
                snapshot=None,
                plan=None,
                result_success=False,
                error=f"自愈过程异常: {str(exc)[:200]}",
            )
        ]


def _run_async_sync(coro: Any) -> Any:
    """Run an async coroutine synchronously, handling nested loops."""
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            import concurrent.futures

            with concurrent.futures.ThreadPoolExecutor(1) as pool:
                future = pool.submit(asyncio.run, coro)
                return future.result(timeout=120)
        else:
            return loop.run_until_complete(coro)
    except RuntimeError:
        return asyncio.run(coro)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


class _ScreenCollector:
    """Minimal screen collector for SelfHealingController.

    Wraps the SAP executor's screen collection capabilities into the
    interface expected by SelfHealingController (a ``collect_snapshot``
    method returning a ScreenSnapshot).
    """

    def __init__(self, ctx: ServerContext) -> None:
        self._ctx = ctx

    def collect_snapshot(self) -> ScreenSnapshot:
        """Collect current screen state as a ScreenSnapshot."""
        from datetime import datetime

        from app.data.models import MessageType

        sap = self._ctx.sap_wrapper
        session = sap.get_session()

        window_title = ""
        status_bar_text = ""
        status_bar_type = MessageType.INFO
        active_window_id = ""
        element_tree_summary = ""

        if session is not None:
            try:
                active_window = session.ActiveWindow
                if active_window:
                    window_title = getattr(active_window, "Text", "") or ""
                    active_window_id = getattr(active_window, "Id", "") or ""
            except Exception:
                pass

            try:
                sbar = session.findById("wnd[0]/sbar")
                if sbar:
                    status_bar_text = getattr(sbar, "Text", "") or ""
                    msg_type = getattr(sbar, "MessageType", "I") or "I"
                    try:
                        status_bar_type = MessageType(msg_type)
                    except ValueError:
                        status_bar_type = MessageType.INFO
            except Exception:
                pass

            # Collect element summary (limited)
            try:
                executor = self._ctx.sap_executor
                elements = executor.collect_screen_elements_text(max_elements=30)
                if elements:
                    element_tree_summary = "\n".join(elements[:30])
            except Exception:
                pass

        return ScreenSnapshot(
            window_title=window_title,
            status_bar_text=status_bar_text,
            status_bar_type=status_bar_type,
            active_window_id=active_window_id,
            element_tree_summary=element_tree_summary,
            timestamp=datetime.now(),
        )


def _is_glm_configured(ctx: ServerContext) -> bool:
    """Check if GLM API key is configured."""
    api_key = ctx.config.glm_api_key
    return bool(api_key and api_key.strip())


def _build_step_response(result: StepResult) -> dict[str, Any]:
    """Build the ok/fail response envelope from a StepResult."""
    data: dict[str, Any] = {
        "success": result.success,
        "step_index": result.step_index,
        "execution_time_ms": result.execution_time_ms,
    }

    if result.error_message:
        data["error_message"] = result.error_message
    if result.status_bar_message:
        data["status_bar_message"] = result.status_bar_message
    if result.screenshot_path:
        data["screenshot_path"] = result.screenshot_path
    if result.extracted_document_number:
        data["extracted_document_number"] = result.extracted_document_number

    return ok(data)


def _serialize_healing_record(record: HealingRecord) -> dict[str, Any]:
    """Serialize a HealingRecord to a JSON-friendly dict."""
    result: dict[str, Any] = {
        "attempt": record.attempt,
        "result_success": record.result_success,
        "elapsed_ms": record.elapsed_ms,
    }
    if record.error:
        result["error"] = record.error
    if record.snapshot:
        result["snapshot"] = record.snapshot.to_dict()
    if record.plan:
        result["plan"] = record.plan.to_dict()
    return result
