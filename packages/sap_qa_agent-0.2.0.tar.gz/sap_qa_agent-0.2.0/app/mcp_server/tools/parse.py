"""``parse_test_case`` MCP tool.

Implements design §4.1 and R2.1–R2.6. Accepts either an absolute
``file_path`` or inline ``content`` and produces a JSON envelope of
normalised ``TestCase`` objects plus optional summary statistics.

The tool writes one ``case_{i}.json`` artifact per case under
``$ARTIFACTS_DIR/mcp-parsed/{hash}/`` so that expensive parse work
doesn't have to be repeated; each file is reachable via the
``sap-qa://parsed/{hash}/case_{i}.json`` URI (design §5.2).

Requirements covered: R2.1, R2.2, R2.3, R2.4, R2.5, R2.6, R20.1, R20.2.
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
from pathlib import Path
from typing import Any, Literal, Optional

from fastmcp import FastMCP

from ...config import MAX_FILE_SIZE
from ...core.test_case_parser import TestCaseParser
from ...data.models import TestCase
from ..context import ServerContext
from ..errors import ErrorCode, fail, ok
from ..middleware import bind_middleware
from ..safety import PathNotAllowedError, ensure_path_allowed

__all__ = ["register"]

logger = logging.getLogger(__name__)


_ALLOWED_EXTENSIONS: frozenset[str] = frozenset(
    {".xlsx", ".xls", ".md", ".markdown"}
)


def register(mcp: FastMCP, ctx: ServerContext) -> None:
    """Register the ``parse_test_case`` tool."""
    wrap = bind_middleware(ctx)
    parser = TestCaseParser()

    @mcp.tool(name="parse_test_case")
    @wrap
    def parse_test_case(
        file_path: Optional[str] = None,
        content: Optional[str] = None,
        format: Literal["excel", "markdown", "auto"] = "auto",
    ) -> dict[str, Any]:
        """Parse an Excel or Markdown test-case document.

        Exactly one of ``file_path`` / ``content`` must be supplied.
        Extension-based format detection kicks in when ``format=auto``.
        Content-mode parsing still materialises a file on disk (under
        ``$ARTIFACTS_DIR/mcp-parsed/{hash}/``) so downstream tools can
        reach it via the same ``sap-qa://parsed/...`` URIs.
        """
        if bool(file_path) == bool(content):
            return fail(
                ErrorCode.INVALID_PARAM,
                message="exactly one of file_path / content must be provided",
            )

        # ----------------------------------------------------------------
        # Materialise the physical file on disk for the parser.
        # ----------------------------------------------------------------
        try:
            target_path, resolved_format = _resolve_source(
                file_path=file_path,
                content=content,
                format_hint=format,
                ctx=ctx,
            )
        except PathNotAllowedError as exc:
            return fail(
                ErrorCode.PATH_NOT_ALLOWED,
                details={"path": exc.path},
            )
        except _UnsupportedFormatError as exc:
            return fail(
                ErrorCode.UNSUPPORTED_FORMAT,
                message=str(exc),
                details={"allowed": sorted(_ALLOWED_EXTENSIONS)},
            )
        except _FileTooLargeError as exc:
            return fail(
                ErrorCode.FILE_TOO_LARGE,
                message=str(exc),
                details={"max_file_size": MAX_FILE_SIZE},
            )

        # ----------------------------------------------------------------
        # Parse and persist per-case artifacts.
        # ----------------------------------------------------------------
        try:
            if resolved_format == "excel":
                cases = parser.parse_excel(str(target_path))
            else:
                cases = parser.parse_markdown(str(target_path))
        except Exception as exc:  # noqa: BLE001 - return parse errors as envelopes
            logger.exception("parse_test_case failed on %s", target_path)
            return fail(
                ErrorCode.INVALID_PARAM,
                message=f"parse failed: {exc}",
            )

        artifacts_hash = _hash_for_source(target_path, content)
        out_dir = Path(ctx.config.artifacts_dir) / "mcp-parsed" / artifacts_hash
        out_dir.mkdir(parents=True, exist_ok=True)

        refs: list[str] = []
        case_dicts: list[dict[str, Any]] = []
        for idx, case in enumerate(cases):
            case_dict = case.to_dict()
            case_dicts.append(case_dict)

            case_path = out_dir / f"case_{idx}.json"
            try:
                case_path.write_text(
                    json.dumps(case_dict, ensure_ascii=False, indent=2),
                    encoding="utf-8",
                )
            except OSError as exc:
                logger.warning("Failed to persist parsed case %s: %s", case_path, exc)
            refs.append(f"sap-qa://parsed/{artifacts_hash}/case_{idx}.json")

        summary = _summarise(cases)

        return ok(
            {
                "cases": case_dicts,
                "summary": summary,
                "refs": refs,
            }
        )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


class _UnsupportedFormatError(Exception):
    """Raised when the extension / format hint pair is unsupported."""


class _FileTooLargeError(Exception):
    """Raised when the source exceeds :data:`app.config.MAX_FILE_SIZE`."""


def _resolve_source(
    *,
    file_path: Optional[str],
    content: Optional[str],
    format_hint: Literal["excel", "markdown", "auto"],
    ctx: ServerContext,
) -> tuple[Path, Literal["excel", "markdown"]]:
    """Return the physical path and resolved format for parsing.

    Two modes:

    * **file_path** — validate against the path whitelist (R20.1/R20.2),
      size limit (R2.4), and extension (R2.3). Returns the path
      unchanged.
    * **content** — hash the content, materialise under
      ``$ARTIFACTS_DIR/mcp-parsed/{hash}/input.(xlsx|md)``, still run
      the whitelist check against the computed path. The choice of
      extension is driven by ``format_hint``; ``auto`` means Markdown
      (Excel cannot be safely reconstructed from a text blob).
    """
    cfg = ctx.config

    if file_path is not None:
        resolved = ensure_path_allowed(file_path, cfg)
        if not resolved.is_file():
            raise _UnsupportedFormatError(
                f"not a regular file: {resolved}"
            )

        size = resolved.stat().st_size
        if size > MAX_FILE_SIZE:
            raise _FileTooLargeError(
                f"file size {size} bytes exceeds limit {MAX_FILE_SIZE}"
            )

        fmt = _pick_format(resolved.suffix, format_hint)
        return resolved, fmt

    # content mode --------------------------------------------------------
    assert content is not None  # guaranteed by the caller branch
    if len(content.encode("utf-8")) > MAX_FILE_SIZE:
        raise _FileTooLargeError(
            f"content size exceeds limit {MAX_FILE_SIZE} bytes"
        )

    if format_hint == "excel":
        raise _UnsupportedFormatError(
            "inline content mode does not support format=excel; "
            "use markdown or pass file_path instead"
        )

    # auto + markdown both land on .md for inline content.
    suffix = ".md"

    digest = hashlib.sha256(content.encode("utf-8")).hexdigest()[:12]
    out_dir = Path(cfg.artifacts_dir) / "mcp-parsed" / digest
    out_dir.mkdir(parents=True, exist_ok=True)
    target = out_dir / f"input{suffix}"
    target.write_text(content, encoding="utf-8")

    # Still run the whitelist check in case ``artifacts_dir`` was
    # somehow excluded from allow_paths (defence-in-depth for R20.6).
    ensure_path_allowed(target, cfg)

    return target, "markdown"


def _pick_format(
    suffix: str,
    hint: Literal["excel", "markdown", "auto"],
) -> Literal["excel", "markdown"]:
    """Decide between excel / markdown based on hint + extension."""
    normalised = suffix.lower()
    if normalised not in _ALLOWED_EXTENSIONS:
        raise _UnsupportedFormatError(
            f"unsupported extension {suffix!r}; allowed: "
            f"{sorted(_ALLOWED_EXTENSIONS)}"
        )

    if hint == "excel":
        if normalised in {".xlsx", ".xls"}:
            return "excel"
        raise _UnsupportedFormatError(
            f"format=excel requires .xlsx/.xls extension, got {suffix!r}"
        )
    if hint == "markdown":
        if normalised in {".md", ".markdown"}:
            return "markdown"
        raise _UnsupportedFormatError(
            f"format=markdown requires .md/.markdown extension, got {suffix!r}"
        )

    # auto
    if normalised in {".xlsx", ".xls"}:
        return "excel"
    return "markdown"


def _hash_for_source(path: Path, content: Optional[str]) -> str:
    """Return a stable 12-hex digest identifying the source."""
    if content is not None:
        return hashlib.sha256(content.encode("utf-8")).hexdigest()[:12]
    hasher = hashlib.sha256()
    hasher.update(str(path).encode("utf-8"))
    try:
        hasher.update(str(path.stat().st_mtime).encode("utf-8"))
    except OSError:
        pass
    return hasher.hexdigest()[:12]


def _summarise(cases: list[TestCase]) -> dict[str, int]:
    """Return the ``summary`` payload per R2.5."""
    return {
        "case_count": len(cases),
        "with_transaction_code_count": sum(
            1 for c in cases if c.transaction_code
        ),
        "with_flow_variable_count": sum(
            1 for c in cases if c.flow_variable_defs
        ),
    }
