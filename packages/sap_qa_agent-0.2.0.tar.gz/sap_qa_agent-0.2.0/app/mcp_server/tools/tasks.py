"""``get_task_status`` / ``list_tasks`` / ``stop_task`` MCP tools.

Implements design §4.4 (task management tools). These tools allow the
host agent to poll execution progress, list recent tasks, and cancel
running executions.

Key design decisions:

* **Truncation at 50**: ``get_task_status`` returns at most 50
  ``step_results`` and 50 ``logs`` entries. When the full list exceeds
  50, the response carries ``truncated=true`` and an ``artifact_uri``
  pointing to the complete data persisted on disk (design §10.3, R5.3).

* **Terminal-state report**: When a task reaches ``completed``,
  ``failed``, or ``cancelled``, the response includes ``report_uri``
  pointing to ``sap-qa://artifacts/{task_id}/report.json``. The report
  is generated lazily by :class:`ReportGenerator` on first terminal
  query (design §4.4, R5.6).

* **AI intervention records (R19.2)**: Failed steps that went through
  the self-healing pipeline carry ``ai_intervention_records`` in their
  step result dicts. These are passed through as-is from the task store.

* **stop_task**: Pops the executor from the task store and calls
  ``.stop()`` on it, then sets the task status to ``cancelled``.
  If no executor is registered (task already finished or never started),
  we still mark it cancelled if it's in a non-terminal state.

Requirements covered: R5.1, R5.2, R5.3, R5.4, R5.5, R5.6, R19.2.
"""

from __future__ import annotations

import json
import logging
import os
from datetime import datetime
from typing import Any, Optional

from fastmcp import FastMCP

from ..context import ServerContext
from ..errors import ErrorCode, fail, ok
from ..middleware import bind_middleware

__all__ = ["register"]

logger = logging.getLogger(__name__)

# Maximum items returned inline before truncation kicks in (R5.3)
_MAX_INLINE_ITEMS = 50

# Terminal task statuses that trigger report_uri inclusion (R5.6)
_TERMINAL_STATUSES = frozenset({"completed", "failed", "cancelled"})


def register(mcp: FastMCP, ctx: ServerContext) -> None:
    """Register task management tools against *mcp*.

    Tools close over ``ctx`` to access the shared ``task_store`` and
    config (for artifacts directory path).
    """
    wrap = bind_middleware(ctx)

    @mcp.tool(name="get_task_status")
    @wrap
    def get_task_status(task_id: str) -> dict[str, Any]:
        """Query the current status of an execution task (R5.1).

        Returns the task's status, execution plan, step results,
        recent logs, timing information, and error details. When the
        task is in a terminal state, also returns a ``report_uri``.

        Parameters
        ----------
        task_id:
            The unique identifier returned by ``execute_test_case``.

        Returns
        -------
        dict
            Success: task status envelope with fields per design §4.4.
            Failure: ``TASK_NOT_FOUND`` if the task_id doesn't exist.
        """
        task = ctx.task_store.get_task(task_id)
        if task is None:
            return fail(
                ErrorCode.TASK_NOT_FOUND,
                message=f"未找到任务: {task_id}",
                details={"task_id": task_id},
            )

        status = task.get("status", "unknown")
        step_results = task.get("step_results") or []
        logs = task.get("logs") or []

        # --- Truncation logic (R5.3) ---
        truncated = False
        artifact_uri: Optional[str] = None

        # Truncate step_results to last 50
        if len(step_results) > _MAX_INLINE_ITEMS:
            truncated = True
            step_results_out = step_results[-_MAX_INLINE_ITEMS:]
        else:
            step_results_out = step_results

        # Truncate logs to last 50
        if len(logs) > _MAX_INLINE_ITEMS:
            truncated = True
            logs_tail = logs[-_MAX_INLINE_ITEMS:]
        else:
            logs_tail = logs

        # When truncated, provide artifact URI for full data
        if truncated:
            artifact_uri = f"sap-qa://artifacts/{task_id}/full_status.json"
            # Persist full payload to disk for later retrieval
            _persist_full_status(ctx, task_id, task)

        # --- Build response payload ---
        data: dict[str, Any] = {
            "task_id": task_id,
            "status": status,
            "steps_plan": task.get("steps_plan") or [],
            "step_results": step_results_out,
            "logs_tail": logs_tail,
            "started_at": task.get("started_at"),
            "completed_at": task.get("completed_at"),
            "error": task.get("error"),
        }

        # Attach truncation metadata (R5.3)
        if truncated:
            data["truncated"] = True
            data["artifact_uri"] = artifact_uri

        # --- Terminal state: attach report_uri (R5.6) ---
        if status in _TERMINAL_STATUSES:
            report_uri = f"sap-qa://artifacts/{task_id}/report.json"
            # Generate report if not already on disk
            _ensure_report_generated(ctx, task_id, task)
            data["report_uri"] = report_uri

        # --- AI intervention records for failed steps (R19.2) ---
        _attach_ai_intervention_records(data, step_results_out)

        return ok(data)

    @mcp.tool(name="list_tasks")
    @wrap
    def list_tasks(limit: int = 20) -> dict[str, Any]:
        """List recent execution tasks (R5.5).

        Returns summaries of the most recent tasks, ordered by
        creation time (newest first).

        Parameters
        ----------
        limit:
            Maximum number of tasks to return. Defaults to 20.

        Returns
        -------
        dict
            ``{tasks: [{task_id, case_id, status, success_count,
            step_count, created_at}, ...]}``
        """
        # Clamp limit to a reasonable range
        if limit < 1:
            limit = 1
        if limit > 100:
            limit = 100

        recent = ctx.task_store.list_recent(limit=limit)
        tasks_summary: list[dict[str, Any]] = []

        for task in recent:
            step_results = task.get("step_results") or []
            success_count = sum(
                1 for sr in step_results if sr.get("success")
            )
            tasks_summary.append({
                "task_id": task.get("task_id"),
                "case_id": task.get("case_id"),
                "status": task.get("status"),
                "success_count": success_count,
                "step_count": len(step_results),
                "created_at": task.get("created_at"),
            })

        return ok({"tasks": tasks_summary})

    @mcp.tool(name="stop_task")
    @wrap
    def stop_task(task_id: str) -> dict[str, Any]:
        """Stop a running execution task (R5.2).

        Retrieves the executor associated with the task, calls
        ``.stop()`` on it, and sets the task status to ``cancelled``.

        Parameters
        ----------
        task_id:
            The unique identifier of the task to stop.

        Returns
        -------
        dict
            Success: ``{task_id, stopped: True}``
            Failure: ``TASK_NOT_FOUND`` if the task_id doesn't exist.
        """
        task = ctx.task_store.get_task(task_id)
        if task is None:
            return fail(
                ErrorCode.TASK_NOT_FOUND,
                message=f"未找到任务: {task_id}",
                details={"task_id": task_id},
            )

        # Pop the executor and stop it (design §4.4)
        executor = ctx.task_store.pop_executor(task_id)
        if executor is not None:
            try:
                stop_fn = getattr(executor, "stop", None)
                if callable(stop_fn):
                    stop_fn()
            except Exception as exc:  # noqa: BLE001 - best-effort stop
                logger.warning(
                    "executor.stop() failed for task %s: %s", task_id, exc
                )

        # Update task status to cancelled (R5.2)
        current_status = task.get("status")
        if current_status not in _TERMINAL_STATUSES:
            ctx.task_store.update_task(
                task_id,
                status="cancelled",
                completed_at=datetime.now().isoformat(),
            )

        return ok({"task_id": task_id, "stopped": True})


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _attach_ai_intervention_records(
    data: dict[str, Any],
    step_results: list[dict[str, Any]],
) -> None:
    """Attach ai_intervention_records to failed steps in the response (R19.2).

    Scans step_results for entries that have ``ai_intervention_records``
    and ensures they are included in the response. The records are
    already present in the step_result dicts if the self-healing
    controller populated them during execution.
    """
    # The ai_intervention_records are already embedded in step_results
    # by the execution engine. We just need to ensure they're visible
    # at the top level for easy access by the host agent.
    ai_records: list[dict[str, Any]] = []
    for sr in step_results:
        if not sr.get("success", True):
            records = sr.get("ai_intervention_records")
            if records:
                ai_records.append({
                    "step_index": sr.get("index"),
                    "records": records,
                })

    if ai_records:
        data["ai_intervention_records"] = ai_records


def _persist_full_status(
    ctx: ServerContext,
    task_id: str,
    task: dict[str, Any],
) -> None:
    """Persist the full task status to disk for artifact retrieval.

    Called when step_results or logs exceed the 50-item inline limit.
    The file is written to ``$ARTIFACTS_DIR/{task_id}/full_status.json``.
    """
    try:
        artifacts_dir = ctx.config.artifacts_dir
        task_dir = os.path.join(artifacts_dir, task_id)
        os.makedirs(task_dir, exist_ok=True)
        output_path = os.path.join(task_dir, "full_status.json")

        # Build a serializable snapshot (exclude non-serializable fields)
        snapshot = {
            "task_id": task.get("task_id"),
            "case_id": task.get("case_id"),
            "status": task.get("status"),
            "steps_plan": task.get("steps_plan") or [],
            "step_results": task.get("step_results") or [],
            "logs": task.get("logs") or [],
            "started_at": task.get("started_at"),
            "completed_at": task.get("completed_at"),
            "error": task.get("error"),
        }

        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(snapshot, f, ensure_ascii=False, indent=2)
    except Exception as exc:  # noqa: BLE001 - persistence is best-effort
        logger.warning(
            "Failed to persist full status for task %s: %s", task_id, exc
        )


def _ensure_report_generated(
    ctx: ServerContext,
    task_id: str,
    task: dict[str, Any],
) -> None:
    """Generate the task report JSON if it doesn't already exist on disk.

    Called when a task is in a terminal state and the host agent
    queries its status. The report is written to
    ``$ARTIFACTS_DIR/{task_id}/report.json`` (design §4.4, R5.6).

    Uses :class:`ReportGenerator` to produce the report data. If the
    generator is not available or the task data is insufficient, the
    report is a minimal JSON summary.
    """
    try:
        artifacts_dir = ctx.config.artifacts_dir
        task_dir = os.path.join(artifacts_dir, task_id)
        report_path = os.path.join(task_dir, "report.json")

        # Skip if already generated
        if os.path.exists(report_path):
            return

        os.makedirs(task_dir, exist_ok=True)

        # Try to use ReportGenerator for rich report
        report_data = _build_report_data(task)

        with open(report_path, "w", encoding="utf-8") as f:
            json.dump(report_data, f, ensure_ascii=False, indent=2)

    except Exception as exc:  # noqa: BLE001 - report generation is best-effort
        logger.warning(
            "Failed to generate report for task %s: %s", task_id, exc
        )


def _build_report_data(task: dict[str, Any]) -> dict[str, Any]:
    """Build report data dict from a task's stored state.

    Produces a JSON-serializable summary suitable for the host agent
    to consume via ``resources/read``.
    """
    step_results = task.get("step_results") or []
    success_count = sum(1 for sr in step_results if sr.get("success"))
    total_steps = len(step_results)

    return {
        "task_id": task.get("task_id"),
        "case_id": task.get("case_id"),
        "status": task.get("status"),
        "success": task.get("status") == "completed",
        "summary": {
            "total_steps": total_steps,
            "success_count": success_count,
            "failure_count": total_steps - success_count,
        },
        "steps_plan": task.get("steps_plan") or [],
        "step_results": step_results,
        "started_at": task.get("started_at"),
        "completed_at": task.get("completed_at"),
        "error": task.get("error"),
        "generated_at": datetime.now().isoformat(),
    }
