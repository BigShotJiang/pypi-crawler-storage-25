"""``execute_test_case`` MCP tool.

Implements design §4.3 (execution tool) — accepts a TestCase dict,
validates it, checks concurrency limits, and launches asynchronous
execution in a background thread. Returns within 2 seconds with a
``task_id`` and ``status: "queued"`` so the host agent can poll via
``get_task_status``.

Key design decisions:

* **Async via threading.Thread**: Execution runs in a daemon thread
  (replicating the pattern from ``sap_routes._run_case_sync``) so the
  MCP tool returns immediately. The thread creates its own COM context
  via ``pythoncom.CoInitialize()`` to avoid conflicts with the main
  thread's event loop.

* **GLM degradation (R19.4)**: When ``GLM_API_KEY`` is not configured,
  ``enable_self_healing`` is forced to ``False`` and a warning is
  included in the response. The tool does NOT fail — it proceeds
  without AI self-healing.

* **Concurrency guard (R4.5)**: Before creating the task, we check
  ``task_store.count_running() >= max_concurrent_tasks``. If at limit,
  we return ``CONCURRENCY_LIMIT`` with the running task IDs in details.

* **max_healing_attempts cap**: The design specifies an upper bound of
  5 (``Field(3, le=5)``). We enforce this at the tool level.

Requirements covered: R4.1, R4.2, R4.3, R4.4, R4.5, R4.6, R19.1,
R19.3, R19.4.
"""

from __future__ import annotations

import logging
import os
import threading
from datetime import datetime
from typing import Any, Literal, Optional

from fastmcp import FastMCP

from ..context import ServerContext
from ..errors import ErrorCode, fail, ok
from ..middleware import bind_middleware

__all__ = ["register"]

logger = logging.getLogger(__name__)


def register(mcp: FastMCP, ctx: ServerContext) -> None:
    """Register the ``execute_test_case`` tool against *mcp*.

    The tool closes over ``ctx`` to access the shared task store,
    config (for concurrency limits and GLM key), and SAP executor.
    """
    wrap = bind_middleware(ctx)

    @mcp.tool(name="execute_test_case")
    @wrap
    def execute_test_case(
        case_data: dict[str, Any],
        mode: Literal["auto", "exploration", "reuse"] = "auto",
        retry_from_step: Optional[int] = None,
        enable_self_healing: bool = True,
        max_healing_attempts: int = 3,
    ) -> dict[str, Any]:
        """Submit a TestCase for asynchronous execution (R4.1).

        Validates the case data, checks concurrency limits, and spawns
        a background thread to drive the SAP GUI automation pipeline.
        Returns within 2 seconds with a task_id for status polling.

        Parameters
        ----------
        case_data:
            A dict that can be deserialized via ``TestCase.from_dict()``.
        mode:
            Execution mode — ``"auto"`` lets the orchestrator decide,
            ``"exploration"`` forces exploration, ``"reuse"`` forces
            template reuse.
        retry_from_step:
            If provided (positive int), reuse the previous steps_plan
            and resume from this step index.
        enable_self_healing:
            Whether to engage the AI self-healing controller on step
            failures. Automatically forced to ``False`` when GLM is
            not configured (R19.4).
        max_healing_attempts:
            Maximum self-healing retries per step (default 3, cap 5).

        Returns
        -------
        dict
            Success: ``{task_id, status: "queued", started_at, mode_resolved}``
            with optional ``warnings`` list.
            Failure: error envelope with one of:
            - ``INVALID_CASE_DATA`` — case_data cannot be parsed
            - ``CONCURRENCY_LIMIT`` — too many running tasks
        """
        warnings: list[str] = []

        # --- 1. Validate case_data via TestCase.from_dict (R4.4) ---
        try:
            from app.data.models import TestCase

            test_case = TestCase.from_dict(case_data)
        except Exception as exc:
            return fail(
                ErrorCode.INVALID_CASE_DATA,
                message=f"测试用例数据无效: {str(exc)[:200]}",
                details={"error": str(exc)[:500]},
            )

        # --- 2. Enforce max_healing_attempts cap (design §4.3: le=5) ---
        if max_healing_attempts > 5:
            max_healing_attempts = 5
        if max_healing_attempts < 0:
            max_healing_attempts = 0

        # --- 3. Check concurrency limit (R4.5) ---
        max_tasks = ctx.config.max_concurrent_tasks
        running_count = ctx.task_store.count_running()
        if running_count >= max_tasks:
            # Collect running task IDs for the details payload
            running_ids = [
                t["task_id"]
                for t in ctx.task_store.list_recent(limit=50)
                if t.get("status") == "running"
            ]
            return fail(
                ErrorCode.CONCURRENCY_LIMIT,
                message=(
                    f"已达到并发任务上限 ({max_tasks})。"
                    f"当前有 {running_count} 个任务正在执行。"
                ),
                details={"running_task_ids": running_ids},
            )

        # --- 4. GLM key check → force disable self-healing (R19.4) ---
        glm_configured = bool(ctx.config.glm_api_key)
        if not glm_configured and enable_self_healing:
            enable_self_healing = False
            warnings.append(
                "GLM_API_KEY 未配置，已自动禁用 AI 自愈能力 (enable_self_healing=False)"
            )

        # --- 5. Resolve execution mode ---
        mode_resolved = mode

        # --- 6. Create task in store (R4.6) ---
        case_id = str(case_data.get("case_id", "") or test_case.case_id)
        task_id = ctx.task_store.create_task(
            case_id=case_id,
            case_data=case_data,
            task_type="case",
        )

        # Store retry info if provided (R4.3)
        if retry_from_step is not None and retry_from_step > 0:
            task = ctx.task_store.get_task(task_id)
            if task is not None:
                task["_retry_from_step"] = retry_from_step

        # --- 7. Launch async execution thread (R4.2) ---
        thread = threading.Thread(
            target=_run_case_sync,
            args=(ctx, task_id, case_data, mode_resolved, enable_self_healing, max_healing_attempts),
            daemon=True,
        )
        thread.start()

        # --- 8. Return immediately with task_id (R4.2: within 2s) ---
        started_at = datetime.now().isoformat()
        response_data: dict[str, Any] = {
            "task_id": task_id,
            "status": "queued",
            "started_at": started_at,
            "mode_resolved": mode_resolved,
        }
        if warnings:
            response_data["warnings"] = warnings

        return ok(response_data)


# ---------------------------------------------------------------------------
# Background execution (runs in a daemon thread)
# ---------------------------------------------------------------------------


def _run_case_sync(
    ctx: ServerContext,
    task_id: str,
    case_data: dict[str, Any],
    mode: str,
    enable_self_healing: bool,
    max_healing_attempts: int,
) -> None:
    """Synchronous execution in an isolated thread — ALL COM calls happen here.

    Replicates the structure of ``sap_routes._run_case_sync`` but uses
    the MCP ServerContext for dependency access. Creates its own COM
    context via ``pythoncom.CoInitialize()`` to avoid conflicts.
    """
    task = ctx.task_store.get_task(task_id)
    if task is None:
        logger.error("Task %s not found in store at execution start", task_id)
        return

    task["status"] = "running"
    task["started_at"] = datetime.now().isoformat()

    def _log(msg: str) -> None:
        task.setdefault("logs", []).append({
            "timestamp": datetime.now().isoformat(),
            "time": datetime.now().strftime("%H:%M:%S"),
            "message": msg,
        })
        logger.info("[%s] %s", task_id, msg)

    try:
        import pythoncom
        pythoncom.CoInitialize()
    except ImportError:
        # Non-Windows or pywin32 not installed — log and continue
        # (tests may run without COM)
        logger.debug("pythoncom not available; skipping CoInitialize")
        pythoncom = None  # type: ignore[assignment]

    try:
        _log("📋 解析测试用例...")
        from app.data.models import TestCase

        tc = TestCase.from_dict(case_data)
        _log(f"用例: {tc.case_id} — {tc.purpose[:60]}")

        # Initialize components via ServerContext
        _log("🔌 初始化组件...")
        sap_wrapper = ctx.sap_wrapper
        if not sap_wrapper.is_connected():
            raise RuntimeError("SAP GUI 未连接，请先调用 sap_connect")

        session = sap_wrapper.get_session()
        sys_name = user = ""
        try:
            if session:
                sys_name = getattr(session.Info, "SystemName", "") or ""
                user = getattr(session.Info, "User", "") or ""
        except Exception:
            pass
        _log(f"✅ SAP 已连接: 系统={sys_name or '(未知)'}, 用户={user or '(未知)'}")

        # Build the orchestrator pipeline
        from app.ai.glm_client import GlmClient
        from app.ai.prompt_manager import PromptManager
        from app.config import ARTIFACTS_DIR, KNOWLEDGE_BASE_DIR
        from app.core.exploration_engine import ExplorationEngine
        from app.core.orchestrator import TestOrchestrator
        from app.core.result_verifier import ResultVerifier
        from app.core.reuse_engine import ReuseEngine
        from app.core.step_splitter import StepSplitter
        from app.core.template_matcher import TemplateMatcher
        from app.data.flow_variable import FlowVariableContext
        from app.data.knowledge_base import KnowledgeBase
        from app.data.models import ExecutionCallbacks, ExecutionMode, TestCaseResult
        from app.sap.element_path_finder import ElementPathFinder
        from app.sap.script_executor import ScriptExecutor
        from app.sap.vlm_fallback import VlmFallbackExecutor

        glm_client = GlmClient() if enable_self_healing else None
        prompt_manager = PromptManager()
        element_finder = ElementPathFinder(sap_wrapper, glm_client)
        knowledge_base = KnowledgeBase(KNOWLEDGE_BASE_DIR)
        step_splitter = StepSplitter(glm_client or GlmClient(), prompt_manager)
        template_matcher = TemplateMatcher(knowledge_base)
        vlm_fallback = VlmFallbackExecutor()
        script_executor = ScriptExecutor(
            sap_wrapper, vlm_fallback,
            element_finder=element_finder,
            glm_client=glm_client,
        )
        ctx.task_store.register_executor(task_id, script_executor)

        exploration_engine = ExplorationEngine(
            glm_client=glm_client or GlmClient(),
            script_executor=script_executor,
            element_finder=element_finder,
            knowledge_base=knowledge_base,
        )
        reuse_engine = ReuseEngine(
            script_executor=script_executor,
            knowledge_base=knowledge_base,
        )
        result_verifier = ResultVerifier(sap_wrapper)
        flow_context = FlowVariableContext()

        orchestrator = TestOrchestrator(
            step_splitter=step_splitter,
            template_matcher=template_matcher,
            exploration_engine=exploration_engine,
            reuse_engine=reuse_engine,
            result_verifier=result_verifier,
            script_executor=script_executor,
        )

        # Execution callbacks for real-time task updates
        def _on_step_result(sr: Any) -> None:
            screenshot_url = ""
            if sr.screenshot_path:
                rel = os.path.relpath(sr.screenshot_path, ARTIFACTS_DIR).replace("\\", "/")
                screenshot_url = f"/artifacts/{rel}"
            task["step_results"].append({
                "index": sr.step_index,
                "action": "",
                "target": "",
                "value": "",
                "success": sr.success,
                "status_bar": sr.status_bar_message or "",
                "error": sr.error_message or "",
                "time_ms": sr.execution_time_ms or 0,
                "screenshot_url": screenshot_url,
            })

        def _on_steps_plan(steps: list[dict]) -> None:
            task["steps_plan"] = steps
            task["step_results"] = []

        callbacks = ExecutionCallbacks(
            on_steps_plan=_on_steps_plan,
            on_script_generated=lambda script: task.update({"generated_script": script}),
            on_step_result=_on_step_result,
            on_log=lambda msg: _log(msg),
        )

        # Handle retry_from_step (R4.3)
        retry_from = task.pop("_retry_from_step", 0)
        if retry_from and retry_from > 0:
            script_executor._skip_before_index = retry_from
            _log(f"🔄 从 Step {retry_from} 开始重试")
        else:
            script_executor._skip_before_index = 0

        # Execute
        _log("▶️ 开始执行...")
        result: TestCaseResult = _run_coroutine_sync(
            orchestrator.execute_test_case(tc, flow_context, callbacks)
        )

        # Update task with results
        task["status"] = "completed" if result.success else "failed"
        task["completed_at"] = datetime.now().isoformat()

        ok_count = sum(1 for sr in result.step_results if sr.success)
        total = len(result.step_results)
        _log(
            f"{'🎉 执行完成！' if result.success else '❌ 部分步骤失败'} "
            f"({ok_count}/{total} 步成功)"
        )

    except Exception as exc:
        logger.exception("Task %s execution error: %s", task_id, exc)
        task["status"] = "failed"
        task["completed_at"] = datetime.now().isoformat()
        task["error"] = str(exc)
        _log(f"💥 执行异常: {exc}")

    finally:
        # Clean up executor reference
        ctx.task_store.pop_executor(task_id)
        # Release COM
        if pythoncom is not None:
            try:
                pythoncom.CoUninitialize()
            except Exception:
                pass


def _run_coroutine_sync(coro: Any) -> Any:
    """Synchronously drive a coroutine without creating an event loop.

    Replicates the pattern from ``sap_routes._run_coroutine_sync``:
    all async methods in the orchestrator pipeline are internally
    synchronous (GLM calls are sync), so we manually drive the
    coroutine's send/throw protocol without needing asyncio.
    """
    result = None
    try:
        result = coro.send(None)
        while True:
            if hasattr(result, "send"):
                inner_result = _run_coroutine_sync(result)
                result = coro.send(inner_result)
            else:
                result = coro.send(result)
    except StopIteration as e:
        return e.value
