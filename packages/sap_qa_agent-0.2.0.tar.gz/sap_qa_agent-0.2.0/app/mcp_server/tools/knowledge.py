"""``list_templates`` / ``get_template`` MCP tools.

Implements design §4.5 (knowledge-base read surface) and R7.1–R7.5.
Read-only, no SAP COM dependency.

Response envelope uses :func:`~app.mcp_server.errors.ok` /
:func:`~app.mcp_server.errors.fail` so middleware can attach the
correlation id and run token-budget / scrub passes uniformly.
"""

from __future__ import annotations

import logging
from typing import Any, Optional

from fastmcp import FastMCP

from ...data.knowledge_base import KnowledgeBase, TemplateInfo
from ...data.models import TemplateConfidence
from ..context import ServerContext
from ..errors import ErrorCode, fail, ok
from ..middleware import bind_middleware

__all__ = ["register"]

logger = logging.getLogger(__name__)


# R7.3: >100 truncated
_LIST_TEMPLATES_LIMIT = 100


def register(mcp: FastMCP, ctx: ServerContext) -> None:
    """Register ``list_templates`` / ``get_template`` tools.

    Both tools re-use the shared :class:`KnowledgeBase` instance on
    ``ctx.kb`` (lazy-constructed on first access, see
    :mod:`app.mcp_server.context`). Tests can inject a mock via the
    ``ctx.kb = ...`` setter before ``build_mcp`` is called.
    """
    wrap = bind_middleware(ctx)

    @mcp.tool(name="list_templates")
    @wrap
    def list_templates(
        transaction_code: Optional[str] = None,
        confidence: Optional[str] = None,
    ) -> dict[str, Any]:
        """Return template summaries, optionally filtered (R7.1, R7.3).

        Parameters
        ----------
        transaction_code:
            Exact match on ``ScriptTemplate.transaction_code`` (e.g.
            ``"VA01"``). Case-sensitive to match SAP's own convention.
        confidence:
            Either the enum **name** (``"DRAFT"`` / ``"STABLE"`` /
            ``"NEEDS_FIX"``) or the enum **value** (``"草稿"`` /
            ``"稳定"`` / ``"待修复"``). Invalid inputs return
            ``INVALID_PARAM`` so a typo surfaces immediately.
        """
        kb = _get_kb(ctx)

        confidence_enum: Optional[TemplateConfidence] = None
        if confidence is not None:
            confidence_enum = _parse_confidence(confidence)
            if confidence_enum is None:
                return fail(
                    ErrorCode.INVALID_PARAM,
                    message=(
                        "confidence must be one of DRAFT / STABLE / NEEDS_FIX "
                        "(or their Chinese equivalents 草稿 / 稳定 / 待修复)"
                    ),
                    details={"received": confidence},
                )

        infos: list[TemplateInfo] = kb.list_templates()
        filtered = [
            info
            for info in infos
            if (
                transaction_code is None
                or info.transaction_code == transaction_code
            )
            and (confidence_enum is None or info.confidence == confidence_enum)
        ]

        truncated = len(filtered) > _LIST_TEMPLATES_LIMIT
        limited = filtered[:_LIST_TEMPLATES_LIMIT]

        payload = {
            "count": len(limited),
            "total": len(filtered),
            "templates": [_template_info_to_dict(info) for info in limited],
        }

        # Attach meta only when truncation kicked in so the common
        # response stays small (aligns with the R14 token budget).
        meta: dict[str, Any] = {}
        if truncated:
            meta["truncated"] = True

        return ok(payload, **meta)

    @mcp.tool(name="get_template")
    @wrap
    def get_template(template_id: str) -> dict[str, Any]:
        """Return a single template or ``TEMPLATE_NOT_FOUND`` (R7.2, R7.4)."""
        kb = _get_kb(ctx)
        # ``KnowledgeBase`` doesn't expose a direct "get by id" method
        # publicly; scan its list to honour the public surface and
        # avoid reaching into ``_find_by_id`` (which returns internal
        # dicts rather than validated ``ScriptTemplate``s).
        for info in kb.list_templates():
            if info.template_id == template_id:
                full = kb.match_template(info.transaction_code, info.scenario_type)
                if full is not None:
                    return ok(full.to_dict())
                break  # inconsistent KB — fall through to not-found

        return fail(
            ErrorCode.TEMPLATE_NOT_FOUND,
            details={"template_id": template_id},
        )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_kb(ctx: ServerContext) -> KnowledgeBase:
    """Return the ``KnowledgeBase`` attached to ``ctx``.

    ``ctx.kb`` is declared as a lazy property in
    :mod:`app.mcp_server.context`. We access it through ``ctx`` so
    tests can inject a mock via ``ctx.kb = mock_kb`` before the tool
    registration (the property setter handles that path).
    """
    return ctx.kb


def _template_info_to_dict(info: TemplateInfo) -> dict[str, Any]:
    """Serialise a :class:`TemplateInfo` for the tool response."""
    return {
        "template_id": info.template_id,
        "transaction_code": info.transaction_code,
        "scenario_type": info.scenario_type,
        "confidence": info.confidence.value,
        "last_success_at": (
            info.last_success_at.isoformat() if info.last_success_at else None
        ),
    }


def _parse_confidence(raw: str) -> Optional[TemplateConfidence]:
    """Accept either the enum name or value; return ``None`` on miss.

    The enum uses Chinese strings as values (``"草稿"``) but MCP callers
    tend to prefer stable English identifiers. Supporting both keeps
    the API approachable without renaming the existing enum.
    """
    # Try as value first (``"草稿"`` etc.)
    try:
        return TemplateConfidence(raw)
    except ValueError:
        pass
    # Fall back to name (``"DRAFT"`` etc., case-insensitive)
    try:
        return TemplateConfidence[raw.upper()]
    except KeyError:
        return None
