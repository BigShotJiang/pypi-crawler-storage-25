"""``sap-qa-mcp validate-skills`` subcommand (design §8.4).

Re-uses :func:`app.mcp_server.skills_loader.loader.load_one` so a
Skill that passes here is guaranteed to load cleanly at server
start-up. Exit code is 0 when every Skill passes, 1 on any error
(requirement R12.6 / R21.3).
"""

from __future__ import annotations

import logging
import re
import sys
from pathlib import Path
from typing import Optional

from .loader import SkillMetadataInvalid, load_one

__all__ = ["validate_all"]

logger = logging.getLogger(__name__)


_KEBAB_RE = re.compile(r"^[a-z][a-z0-9]*(-[a-z0-9]+)*$")


def _default_skills_dir() -> Path:
    """Return the bundled ``mcp_skills/`` directory.

    ``validator.py`` lives at
    ``app/mcp_server/skills_loader/validator.py``; four ``.parent``
    hops lift us to ``ui_test_python/`` where ``mcp_skills/`` lives
    (the same heuristic used by :func:`app.mcp_server.safety._mcp_skills_dir`).
    """
    return Path(__file__).resolve().parent.parent.parent.parent / "mcp_skills"


def validate_all(mcp_skills_dir: Optional[str | Path] = None) -> int:
    """Validate every Skill under ``mcp_skills_dir``.

    Returns the exit code (0 on success, 1 on any failure) so the
    calling CLI can forward it with :func:`sys.exit`.

    Output format per design §8.4::

        ✓ sap-parse-and-execute
        ✗ xyz: missing required_tools in front-matter
    """
    base = Path(mcp_skills_dir) if mcp_skills_dir else _default_skills_dir()

    if not base.is_dir():
        print(f"mcp_skills directory not found: {base}", file=sys.stderr)
        return 1

    successes: list[str] = []
    failures: list[tuple[str, str]] = []

    for child in sorted(base.iterdir()):
        if not child.is_dir():
            continue
        if not _KEBAB_RE.match(child.name):
            failures.append((child.name, "directory name is not kebab-case"))
            continue
        skill_md = child / "SKILL.md"
        if not skill_md.is_file():
            failures.append((child.name, "missing SKILL.md"))
            continue
        try:
            load_one(child)
        except SkillMetadataInvalid as exc:
            failures.append((child.name, exc.reason))
            continue
        except Exception as exc:  # noqa: BLE001 - surface any unexpected error
            failures.append((child.name, f"unexpected error: {exc}"))
            continue
        successes.append(child.name)

    for name in successes:
        print(f"✓ {name}")
    for name, reason in failures:
        print(f"✗ {name}: {reason}")

    total = len(successes) + len(failures)
    print(
        f"\n{len(successes)}/{total} skills valid",
        file=sys.stderr,
    )

    return 0 if not failures else 1
