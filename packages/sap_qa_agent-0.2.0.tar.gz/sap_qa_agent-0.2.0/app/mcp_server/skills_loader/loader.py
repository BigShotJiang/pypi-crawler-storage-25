"""Scan ``mcp_skills/`` and parse ``SKILL.md`` packages.

Implements design §8.1 (directory scan), §8.2 (front-matter parsing),
and the data model in design §3.4. Every ``SKILL.md`` must declare a
YAML front-matter block with the seven required keys (``id``, ``title``,
``description``, ``version``, ``keywords``, ``required_tools``,
``language``) and contain the five required sections (``## When to use``,
``## Inputs``, ``## Tool sequence``, ``## Success criteria``,
``## Failure handling``).

Requirements covered: R11.1, R11.2, R12.1, R12.2, R12.3, R12.4.

Failure policy
--------------

A malformed Skill **never** aborts server start-up (design §8.1). Each
error is logged at WARNING, the offending directory is skipped, and
:func:`scan_all` returns the list of valid packages. The
``validate-skills`` CLI subcommand (task 3.3) reuses the same loader
but surfaces errors as exit codes.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable

import yaml

__all__ = [
    "SkillMetadata",
    "SkillMetadataInvalid",
    "SkillPackage",
    "load_one",
    "scan_all",
    "REQUIRED_FRONTMATTER_KEYS",
    "REQUIRED_SECTIONS",
]

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------


#: Keys every ``SKILL.md`` front-matter must declare (R12.2).
REQUIRED_FRONTMATTER_KEYS: tuple[str, ...] = (
    "id",
    "title",
    "description",
    "version",
    "keywords",
    "required_tools",
    "language",
)

#: Markdown section headings every Skill must include (R12.4).
REQUIRED_SECTIONS: tuple[str, ...] = (
    "## When to use",
    "## Inputs",
    "## Tool sequence",
    "## Success criteria",
    "## Failure handling",
)

# Matches kebab-case ids: starts with a lowercase letter, followed by
# lowercase letters/digits/``-``, no consecutive ``--`` or trailing ``-``.
_KEBAB_RE = re.compile(r"^[a-z][a-z0-9]*(-[a-z0-9]+)*$")


# ---------------------------------------------------------------------------
# Exceptions & data classes
# ---------------------------------------------------------------------------


class SkillMetadataInvalid(Exception):
    """Raised when a ``SKILL.md`` file fails validation.

    Carries the offending directory name + a human-readable reason so
    the validator CLI can print a precise ``✗ <id>: <reason>`` line.
    """

    def __init__(self, skill_id: str, reason: str) -> None:
        super().__init__(f"{skill_id}: {reason}")
        self.skill_id = skill_id
        self.reason = reason


@dataclass(frozen=True)
class SkillMetadata:
    """Parsed front-matter (design §3.4)."""

    id: str
    title: str
    description: str
    version: str
    keywords: list[str]
    required_tools: list[str]
    language: str = "zh-CN"

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "title": self.title,
            "description": self.description,
            "version": self.version,
            "keywords": list(self.keywords),
            "required_tools": list(self.required_tools),
            "language": self.language,
        }


@dataclass
class SkillPackage:
    """A fully-loaded Skill: metadata + body + optional prompts."""

    metadata: SkillMetadata
    content_md: str
    prompts: dict[str, str] = field(default_factory=dict)
    source_dir: Path = field(default_factory=Path)
    loaded_mtime: float = 0.0


# ---------------------------------------------------------------------------
# Scanner
# ---------------------------------------------------------------------------


def scan_all(mcp_skills_dir: Path | str) -> list[SkillPackage]:
    """Return every valid Skill found under ``mcp_skills_dir``.

    Walk is non-recursive at the top level — only the direct children
    of ``mcp_skills_dir`` that (a) are directories, (b) have
    kebab-case names, and (c) contain ``SKILL.md`` are considered.
    Anything else is silently ignored (design §8.1).

    Invalid Skills emit a WARNING log line and are omitted from the
    result, keeping the loader resilient against partially-edited
    files during development.
    """
    base = Path(mcp_skills_dir)
    if not base.is_dir():
        logger.debug("mcp_skills dir %s does not exist", base)
        return []

    results: list[SkillPackage] = []
    for child in sorted(base.iterdir()):
        if not child.is_dir():
            continue
        if not _KEBAB_RE.match(child.name):
            logger.debug("Skipping non-kebab directory: %s", child.name)
            continue
        skill_md = child / "SKILL.md"
        if not skill_md.is_file():
            logger.debug("Skipping directory without SKILL.md: %s", child.name)
            continue
        try:
            pkg = load_one(child)
        except SkillMetadataInvalid as exc:
            logger.warning("Skill %s is invalid, skipped: %s", child.name, exc.reason)
            continue
        except Exception as exc:  # noqa: BLE001 - robustness at start-up
            logger.warning(
                "Skill %s could not be loaded, skipped: %s",
                child.name,
                exc,
            )
            continue
        results.append(pkg)

    return results


def load_one(skill_dir: Path | str) -> SkillPackage:
    """Load and validate a single Skill directory.

    Raises :class:`SkillMetadataInvalid` on any structural problem:

    * missing / malformed front-matter
    * missing required keys
    * ``id`` that doesn't match the directory name
    * any of the five required markdown sections missing

    Other OS errors (e.g. permission denied) propagate unchanged —
    they're exceptional and should surface to the caller.
    """
    skill_dir = Path(skill_dir)
    skill_id = skill_dir.name

    skill_md = skill_dir / "SKILL.md"
    raw = skill_md.read_text(encoding="utf-8")

    front_matter, body = _split_frontmatter(raw, skill_id)
    metadata = _build_metadata(front_matter, skill_id)
    _validate_sections(body, skill_id)

    prompts = _load_prompts(skill_dir)

    mtime = skill_md.stat().st_mtime
    return SkillPackage(
        metadata=metadata,
        content_md=body.strip(),
        prompts=prompts,
        source_dir=skill_dir,
        loaded_mtime=mtime,
    )


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _split_frontmatter(raw: str, skill_id: str) -> tuple[dict[str, Any], str]:
    """Split ``raw`` into (front-matter dict, body markdown).

    Accepts either Windows (``\\r\\n``) or POSIX (``\\n``) line endings.
    The file must start with ``---`` on its first line; a second
    ``---`` terminates the YAML block.
    """
    text = raw.lstrip("\ufeff")  # drop a BOM if present
    if not text.startswith("---"):
        raise SkillMetadataInvalid(skill_id, "missing YAML front-matter")

    # Split on the first two lines of ``---``. Using splitlines keeps
    # things portable across line endings; we rebuild body text with
    # ``\n`` so downstream section checks are deterministic.
    lines = text.splitlines()
    if len(lines) < 2 or lines[0].strip() != "---":
        raise SkillMetadataInvalid(skill_id, "missing front-matter opening delimiter")

    closing_idx: int | None = None
    for idx in range(1, len(lines)):
        if lines[idx].strip() == "---":
            closing_idx = idx
            break
    if closing_idx is None:
        raise SkillMetadataInvalid(skill_id, "missing front-matter closing delimiter")

    yaml_text = "\n".join(lines[1:closing_idx])
    body = "\n".join(lines[closing_idx + 1 :])

    try:
        loaded = yaml.safe_load(yaml_text) or {}
    except yaml.YAMLError as exc:
        raise SkillMetadataInvalid(skill_id, f"front-matter YAML error: {exc}") from exc

    if not isinstance(loaded, dict):
        raise SkillMetadataInvalid(
            skill_id,
            "front-matter must be a YAML mapping at the top level",
        )

    return loaded, body


def _build_metadata(front_matter: dict[str, Any], skill_id: str) -> SkillMetadata:
    """Validate required keys and coerce types."""
    missing = [k for k in REQUIRED_FRONTMATTER_KEYS if k not in front_matter]
    if missing:
        raise SkillMetadataInvalid(
            skill_id,
            f"missing required front-matter keys: {', '.join(missing)}",
        )

    declared_id = str(front_matter["id"])
    if declared_id != skill_id:
        raise SkillMetadataInvalid(
            skill_id,
            f"front-matter id {declared_id!r} does not match directory name {skill_id!r}",
        )

    keywords = _coerce_str_list(front_matter["keywords"], "keywords", skill_id)
    required_tools = _coerce_str_list(
        front_matter["required_tools"], "required_tools", skill_id
    )

    return SkillMetadata(
        id=declared_id,
        title=str(front_matter["title"]),
        description=str(front_matter["description"]),
        version=str(front_matter["version"]),
        keywords=keywords,
        required_tools=required_tools,
        language=str(front_matter["language"]),
    )


def _coerce_str_list(value: Any, field_name: str, skill_id: str) -> list[str]:
    """Ensure ``value`` is a list of strings or raise a clear error."""
    if not isinstance(value, list):
        raise SkillMetadataInvalid(
            skill_id,
            f"front-matter {field_name!r} must be a YAML list, got {type(value).__name__}",
        )
    out: list[str] = []
    for item in value:
        if not isinstance(item, str):
            raise SkillMetadataInvalid(
                skill_id,
                f"front-matter {field_name!r} must contain only strings, "
                f"got item of type {type(item).__name__}",
            )
        out.append(item)
    return out


def _validate_sections(body: str, skill_id: str) -> None:
    """Confirm every required ``## …`` header is present."""
    missing = [section for section in REQUIRED_SECTIONS if section not in body]
    if missing:
        raise SkillMetadataInvalid(
            skill_id,
            f"missing required markdown sections: {', '.join(missing)}",
        )


def _load_prompts(skill_dir: Path) -> dict[str, str]:
    """Load optional ``prompts/*.md`` files into a filename → content map."""
    prompts_dir = skill_dir / "prompts"
    if not prompts_dir.is_dir():
        return {}

    out: dict[str, str] = {}
    for prompt_file in sorted(prompts_dir.glob("*.md")):
        try:
            out[prompt_file.name] = prompt_file.read_text(encoding="utf-8")
        except OSError as exc:
            logger.warning(
                "Failed to read prompt %s: %s", prompt_file, exc
            )
    return out


def dir_latest_mtime(base: Path) -> float:
    """Return the latest mtime across ``base`` (non-recursive top-level).

    Used by :class:`.cache.SkillCache` to decide whether to re-scan.
    Non-recursive is enough because any change to a nested file (e.g.
    ``prompts/kickoff.md``) bubbles up to its parent's mtime on every
    platform the project targets.
    """
    if not base.is_dir():
        return 0.0
    mtimes: Iterable[float] = (
        child.stat().st_mtime for child in base.iterdir() if child.exists()
    )
    return max(mtimes, default=0.0)
