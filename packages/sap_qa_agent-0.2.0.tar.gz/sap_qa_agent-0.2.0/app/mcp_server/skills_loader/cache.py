"""mtime-based cache layer in front of :mod:`.loader`.

Implements design §8.3. The MCP server calls :meth:`SkillCache.all` /
:meth:`SkillCache.get` on every ``list_skills`` / ``get_skill`` tool
invocation; the cache skips re-scanning the filesystem unless the
non-recursive directory mtime has advanced. This keeps the hot path
cheap (a single ``stat`` per child directory) while still picking up
edits without a server restart (R11.6).
"""

from __future__ import annotations

import logging
import threading
from pathlib import Path
from typing import Optional

from .loader import SkillPackage, dir_latest_mtime, scan_all

__all__ = ["SkillCache"]

logger = logging.getLogger(__name__)


class SkillCache:
    """Caches :class:`SkillPackage` instances with mtime-based invalidation.

    Concurrency: the cache is used from FastMCP's async tool handlers,
    which may run on different threads under streamable-http. A simple
    :class:`~threading.Lock` serialises cache rebuilds; reads take the
    lock for the shortest possible interval to copy out the current
    view.
    """

    def __init__(self, base_dir: Path | str) -> None:
        self._base = Path(base_dir)
        self._cache: dict[str, SkillPackage] = {}
        self._last_scan_mtime: float = -1.0
        self._lock = threading.Lock()

    @property
    def base_dir(self) -> Path:
        """Return the directory this cache watches."""
        return self._base

    def all(self) -> list[SkillPackage]:
        """Return every valid Skill, re-scanning if the dir has changed."""
        self._refresh_if_stale()
        with self._lock:
            return list(self._cache.values())

    def get(self, skill_id: str) -> Optional[SkillPackage]:
        """Return a single Skill by id, or ``None`` if missing."""
        self._refresh_if_stale()
        with self._lock:
            return self._cache.get(skill_id)

    def invalidate(self) -> None:
        """Force the next access to re-scan (useful for tests)."""
        with self._lock:
            self._last_scan_mtime = -1.0
            self._cache = {}

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _refresh_if_stale(self) -> None:
        """Re-scan ``base`` when its latest child-mtime has advanced."""
        latest = dir_latest_mtime(self._base)
        with self._lock:
            if latest <= self._last_scan_mtime:
                return
            packages = scan_all(self._base)
            self._cache = {pkg.metadata.id: pkg for pkg in packages}
            self._last_scan_mtime = latest
            logger.debug(
                "SkillCache refreshed: %d skill(s) loaded from %s",
                len(self._cache),
                self._base,
            )
