"""Unified response envelope and error codes for the MCP server.

This module defines the single source of truth for how MCP Tools report
success and failure. Every Tool MUST return a dict produced by
:func:`ok` or :func:`fail` so that:

* The structure matches design §3.2 (``ok``/``data`` or ``ok``/``error``).
* A ``correlation_id`` is always attached (populated by middleware).
* Error codes are drawn from the closed set in :class:`ErrorCode`
  (design §3.3, aligning with requirement R15.2).

The ``correlation_id_var`` :class:`~contextvars.ContextVar` is exposed
here (rather than in ``middleware.py``) so that it can be imported by
both the envelope helpers and the middleware layer without creating a
circular dependency. Middleware sets the value per request; these
helpers read it.
"""

from __future__ import annotations

from contextvars import ContextVar
from enum import Enum
from typing import Any

__all__ = [
    "ErrorCode",
    "correlation_id_var",
    "correlation_id",
    "ok",
    "fail",
]


# ---------------------------------------------------------------------------
# Error codes (design §3.3, requirement R15.2)
# ---------------------------------------------------------------------------


class ErrorCode(str, Enum):
    """Closed set of error codes surfaced through MCP Tool responses.

    Inheriting from ``str`` makes every member JSON-serialisable as its
    string value, which is what the transport layer ultimately emits.
    """

    # generic
    INTERNAL_ERROR = "INTERNAL_ERROR"
    INVALID_PARAM = "INVALID_PARAM"

    # parse
    UNSUPPORTED_FORMAT = "UNSUPPORTED_FORMAT"
    FILE_TOO_LARGE = "FILE_TOO_LARGE"
    PATH_NOT_ALLOWED = "PATH_NOT_ALLOWED"

    # sap session
    SAP_GUI_NOT_RUNNING = "SAP_GUI_NOT_RUNNING"
    SCRIPTING_DISABLED = "SCRIPTING_DISABLED"
    SAP_NOT_CONNECTED = "SAP_NOT_CONNECTED"
    SAP_SESSION_OWNED_BY_OTHER_CHANNEL = "SAP_SESSION_OWNED_BY_OTHER_CHANNEL"

    # exec
    INVALID_CASE_DATA = "INVALID_CASE_DATA"
    CONCURRENCY_LIMIT = "CONCURRENCY_LIMIT"
    TASK_NOT_FOUND = "TASK_NOT_FOUND"

    # resources
    RESOURCE_TOO_LARGE = "RESOURCE_TOO_LARGE"
    RESOURCE_NOT_FOUND = "RESOURCE_NOT_FOUND"

    # knowledge
    TEMPLATE_NOT_FOUND = "TEMPLATE_NOT_FOUND"

    # atomic
    ATOMIC_TOOLS_DISABLED = "ATOMIC_TOOLS_DISABLED"

    # recording
    RECORDING_IN_PROGRESS = "RECORDING_IN_PROGRESS"
    RECORDING_NOT_FOUND = "RECORDING_NOT_FOUND"
    RECORDING_NOT_AVAILABLE_IN_STDIO = "RECORDING_NOT_AVAILABLE_IN_STDIO"

    # skills
    SKILL_NOT_FOUND = "SKILL_NOT_FOUND"
    SKILL_METADATA_INVALID = "SKILL_METADATA_INVALID"

    # glm
    GLM_NOT_CONFIGURED = "GLM_NOT_CONFIGURED"


# Default human-readable messages per error code. Used when a caller of
# :func:`fail` does not provide an explicit ``message``. Kept short and
# neutral; callers should override with context-specific text whenever
# possible. Messages are in zh-CN to match the design example in §3.2.
_DEFAULT_MESSAGES: dict[ErrorCode, str] = {
    # generic
    ErrorCode.INTERNAL_ERROR: "服务器内部错误",
    ErrorCode.INVALID_PARAM: "请求参数无效",
    # parse
    ErrorCode.UNSUPPORTED_FORMAT: "不支持的文件格式",
    ErrorCode.FILE_TOO_LARGE: "文件大小超过限制",
    ErrorCode.PATH_NOT_ALLOWED: "路径不在允许的白名单内",
    # sap session
    ErrorCode.SAP_GUI_NOT_RUNNING: "SAP GUI 未运行",
    ErrorCode.SCRIPTING_DISABLED: "SAP GUI Scripting 未启用",
    ErrorCode.SAP_NOT_CONNECTED: "尚未连接到 SAP 会话",
    ErrorCode.SAP_SESSION_OWNED_BY_OTHER_CHANNEL: "SAP 会话被其他通道占用",
    # exec
    ErrorCode.INVALID_CASE_DATA: "测试用例数据无效",
    ErrorCode.CONCURRENCY_LIMIT: "已达到并发任务上限",
    ErrorCode.TASK_NOT_FOUND: "未找到指定任务",
    # resources
    ErrorCode.RESOURCE_TOO_LARGE: "资源内容超过大小上限",
    ErrorCode.RESOURCE_NOT_FOUND: "未找到指定资源",
    # knowledge
    ErrorCode.TEMPLATE_NOT_FOUND: "未找到指定脚本模板",
    # atomic
    ErrorCode.ATOMIC_TOOLS_DISABLED: "原子工具已被禁用",
    # recording
    ErrorCode.RECORDING_IN_PROGRESS: "已有录制任务在进行中",
    ErrorCode.RECORDING_NOT_FOUND: "未找到指定录制",
    ErrorCode.RECORDING_NOT_AVAILABLE_IN_STDIO: "stdio 传输模式下不支持录制",
    # skills
    ErrorCode.SKILL_NOT_FOUND: "未找到指定 Skill",
    ErrorCode.SKILL_METADATA_INVALID: "Skill 元数据无效",
    # glm
    ErrorCode.GLM_NOT_CONFIGURED: "未配置 GLM API Key",
}


# ---------------------------------------------------------------------------
# Correlation id context variable
# ---------------------------------------------------------------------------

# Populated by the MCP middleware (Task 1.5) on every incoming Tool
# invocation. Default is empty string so that envelope helpers remain
# callable during unit tests without an active request scope.
correlation_id_var: ContextVar[str] = ContextVar("correlation_id", default="")


def correlation_id() -> str:
    """Return the current correlation id, or an empty string if unset."""
    return correlation_id_var.get()


# ---------------------------------------------------------------------------
# Envelope factories (design §3.2)
# ---------------------------------------------------------------------------


def ok(data: Any, **meta: Any) -> dict[str, Any]:
    """Build a success envelope.

    Parameters
    ----------
    data:
        Tool-specific payload. Usually a ``dict``; other JSON-serialisable
        values are accepted for Tools that legitimately return a list or
        scalar.
    **meta:
        Optional top-level metadata merged into the envelope. Known keys
        include ``truncated`` and ``truncation_ref`` (design §3.2), but
        callers may pass any future additions without modifying this
        helper.

    Returns
    -------
    dict
        ``{"ok": True, "data": data, "correlation_id": cid, **meta}``.
    """
    envelope: dict[str, Any] = {
        "ok": True,
        "data": data,
        "correlation_id": correlation_id(),
    }
    if meta:
        envelope.update(meta)
    return envelope


def fail(
    code: ErrorCode | str,
    message: str | None = None,
    details: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Build a failure envelope.

    Parameters
    ----------
    code:
        Either an :class:`ErrorCode` member or its string value. String
        inputs are normalised to the enum when possible so that the
        emitted ``code`` is always the canonical value. Unknown string
        codes are preserved verbatim (they will still serialise), but
        callers should prefer :class:`ErrorCode` members.
    message:
        Human-readable message. If ``None``, a default is looked up in
        :data:`_DEFAULT_MESSAGES`. Falls back to the code itself when no
        default is registered (e.g. an unknown string code).
    details:
        Optional structured diagnostic payload (design §3.2). Passed
        through unchanged. ``None`` is preserved as-is so that clients
        can distinguish "no details" from "empty details".

    Returns
    -------
    dict
        ``{"ok": False, "error": {...}, "correlation_id": cid}``.
    """
    # Normalise the code: accept raw strings but prefer enum members.
    if isinstance(code, ErrorCode):
        code_value = code.value
        resolved_code: ErrorCode | None = code
    else:
        code_value = code
        try:
            resolved_code = ErrorCode(code)
        except ValueError:
            resolved_code = None

    if message is None:
        if resolved_code is not None:
            message = _DEFAULT_MESSAGES.get(resolved_code, code_value)
        else:
            message = code_value

    error_obj: dict[str, Any] = {
        "code": code_value,
        "message": message,
        "details": details,
    }

    return {
        "ok": False,
        "error": error_obj,
        "correlation_id": correlation_id(),
    }
