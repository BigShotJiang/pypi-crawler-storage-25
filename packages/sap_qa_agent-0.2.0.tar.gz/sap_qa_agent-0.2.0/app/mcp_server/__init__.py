"""MCP Server package for SAP QA Agent.

This package wraps the existing FastAPI engine (``app/``) into an MCP
(Model Context Protocol) server that exposes Tools, Resources and Skills
to MCP-compatible clients.

Modules are added incrementally through the mcp-skills-packaging spec:

* :mod:`app.mcp_server.errors` — unified response envelope and error codes.
* :mod:`app.mcp_server.config` — configuration profile + loader (Phase 1).
* :mod:`app.mcp_server.context` — process-wide :class:`ServerContext` (Phase 1).
* :mod:`app.mcp_server.middleware` — correlation_id / logging / metrics (Phase 1).
* :mod:`app.mcp_server.server` — FastMCP assembly + ``build_mcp`` (Phase 1).
* :mod:`app.mcp_server.cli` — ``sap-qa-mcp`` entry point (Phase 8).
"""
