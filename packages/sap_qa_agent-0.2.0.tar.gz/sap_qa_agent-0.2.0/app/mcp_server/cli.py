"""Command-line entry point for ``sap-qa-mcp`` (design §9.1 / §9.4).

The ``[project.scripts]`` entry ``sap-qa-mcp = "app.mcp_server.cli:main"``
in ``pyproject.toml`` dispatches here. This module is deliberately thin:

1. :func:`build_parser` declares every flag documented in design §9.1.
2. :func:`main` merges CLI args with env / file / defaults via
   :func:`app.mcp_server.config.load_config` (four-tier, R13.1), builds
   the :class:`ServerContext`, installs signal handlers and starts the
   selected transport.
3. :func:`_install_signal_handlers` implements the graceful-shutdown
   sketch from design §9.4 (set ``shutdown_event`` → wait for inflight
   Tools ≤ 10 s → release COM / channel lock → exit).

Lazy imports
------------

Task 1.7 runs in Phase 1 but references modules that land later:

* :mod:`app.mcp_server.transport.stdio` — Phase 8.1
* :mod:`app.mcp_server.transport.http` — Phase 8.2
* :mod:`app.mcp_server.skills_loader.validator` — Phase 3.3

Each of those is imported inside the function that uses it and guarded
with :class:`ImportError`. When the module is missing:

* stdio falls back to :meth:`FastMCP.run` directly (so Phase 1 can still
  start the server and answer ``initialize`` for contract tests);
* streamable-http logs an error and returns exit code 2;
* ``validate-skills`` prints "not yet implemented" and returns exit
  code 2.

This matches the spec's staged-delivery model: the CLI is written once,
and later phases drop in their implementations without touching this
file.

Argparse defaults
-----------------

Every flag that participates in the four-tier merge uses
``default=None`` so :func:`_cli_overrides` in :mod:`.config` can tell
"user did not pass it" apart from "user passed the documented default".
``--enable-atomic-tools`` is ``store_true`` (default ``False``) and
``--allow-path`` accumulates into a list (default ``[]``) — the config
loader has special cases for both.

Exit codes
----------

* ``0``  — clean shutdown (SIGTERM or main loop returned normally).
* ``1``  — inflight tools failed to drain within the 10 s grace window,
           or a subcommand returned failure.
* ``2``  — transport not implemented, config file malformed (via
           :func:`load_config`), or subcommand not yet wired.
* ``130`` — SIGINT (POSIX convention: 128 + SIGINT's signal number 2).
"""

from __future__ import annotations

import argparse
import logging
import signal
import sys
from logging.handlers import RotatingFileHandler
from typing import Optional

from .config import load_config
from .context import ServerContext
from .server import build_mcp

__all__ = ["VERSION", "build_parser", "main"]

logger = logging.getLogger(__name__)

# Keep in sync with ``pyproject.toml::project.version`` and
# ``ConfigProfile.server_version``. Bumping this string is the single
# source of truth for ``sap-qa-mcp --version``.
VERSION = "0.1.0"

# Exit code constants (see module docstring for the full table).
_EXIT_OK = 0
_EXIT_DRAIN_TIMEOUT = 1
_EXIT_NOT_IMPLEMENTED = 2
_EXIT_SIGINT = 130


# ---------------------------------------------------------------------------
# Argparse
# ---------------------------------------------------------------------------


def build_parser() -> argparse.ArgumentParser:
    """Build the top-level :class:`argparse.ArgumentParser` (design §9.1).

    All flags participating in the four-tier config merge carry
    ``default=None`` so :func:`_cli_overrides` in :mod:`.config` treats
    them as "not passed" unless the user explicitly provided a value.
    The two exceptions are ``--allow-path`` (list accumulator, empty
    list means not passed) and ``--enable-atomic-tools``
    (``store_true``, only ``True`` counts as an override).
    """
    parser = argparse.ArgumentParser(
        prog="sap-qa-mcp",
        description="SAP QA Agent — MCP Server for SAP Public Cloud UI automation.",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"sap-qa-mcp {VERSION}",
    )

    # --- R1: transport & networking ----------------------------------------
    parser.add_argument(
        "--transport",
        choices=["stdio", "streamable-http"],
        default=None,
        help="Transport layer (default: stdio).",
    )
    parser.add_argument(
        "--host",
        default=None,
        help="Host to bind in streamable-http mode (default: 127.0.0.1).",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=None,
        help="Port to bind in streamable-http mode (default: 8100).",
    )
    parser.add_argument(
        "--auth-token",
        default=None,
        help="Bearer token required in streamable-http mode.",
    )

    # --- R13: config & paths -----------------------------------------------
    parser.add_argument(
        "--config",
        default=None,
        help="Path to a JSON or TOML config file (four-tier loader).",
    )
    parser.add_argument(
        "--artifacts-root",
        default=None,
        help="Override ARTIFACTS_DIR for screenshots, recordings and truncated payloads.",
    )
    parser.add_argument(
        "--allow-path",
        action="append",
        default=[],
        help="Additional filesystem path(s) permitted for file-based tools; may be repeated.",
    )
    parser.add_argument(
        "--enable-atomic-tools",
        action="store_true",
        default=False,
        help="Enable the sap_input/sap_click/... atomic tool family (default: off).",
    )
    parser.add_argument(
        "--mcp-skills-dir",
        default=None,
        help="Directory to scan for SKILL.md packages (default: <pkg>/mcp_skills).",
    )

    # --- R16: logging ------------------------------------------------------
    parser.add_argument(
        "--log-level",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        default=None,
        help="Root log level (default: INFO).",
    )
    parser.add_argument(
        "--log-file",
        default=None,
        help="Write rotating logs to this file (10 MB × 5 backups).",
    )

    # --- Subcommands -------------------------------------------------------
    # ``dest="subcommand"`` lets :func:`main` branch on which one (if
    # any) was chosen. ``required=False`` so the bare invocation starts
    # the server. ``validate-skills`` takes no extra positional args in
    # Phase 1; Phase 3.3 may extend it.
    subparsers = parser.add_subparsers(dest="subcommand", required=False)
    subparsers.add_parser(
        "validate-skills",
        help="Validate mcp_skills/*/SKILL.md files and exit.",
    )

    return parser


# ---------------------------------------------------------------------------
# Logging bootstrap
# ---------------------------------------------------------------------------


class _McpLogFormatter(logging.Formatter):
    """Custom formatter implementing design §10.2 structured log format.

    The format includes ``[%(cid)s] tool=%(tool)s duration_ms=%(dur)d
    ok=%(ok)s`` fields that are populated by the middleware for
    tool-call log lines. For general application log lines (which lack
    these extra fields), sensible defaults are substituted so the
    formatter never raises on missing attributes.
    """

    _FORMAT = (
        "%(asctime)s [%(levelname)s] [%(cid)s] "
        "tool=%(tool)s duration_ms=%(dur)d ok=%(ok)s msg=%(message)s"
    )
    _DATEFMT = "%Y-%m-%d %H:%M:%S"

    # Defaults for non-tool log records (general app logging).
    _DEFAULTS = {"cid": "-", "tool": "-", "dur": 0, "ok": "-"}

    def __init__(self) -> None:
        super().__init__(fmt=self._FORMAT, datefmt=self._DATEFMT)

    def format(self, record: logging.LogRecord) -> str:  # noqa: A003
        for key, default in self._DEFAULTS.items():
            if not hasattr(record, key):
                setattr(record, key, default)
        return super().format(record)


def _configure_logging(level: str, log_file: Optional[str]) -> None:
    """Configure the root logger with design §10.2 format (R16.2, R16.3).

    Sets up the root logger at the requested level. When ``--log-file``
    is specified, a :class:`~logging.handlers.RotatingFileHandler` with
    10 MB rotation and 5 backups is attached (R16.3). A stderr
    :class:`~logging.StreamHandler` is always present for interactive
    diagnostics.

    Both handlers use :class:`_McpLogFormatter` which outputs the
    structured format from design §10.2::

        %(asctime)s [%(levelname)s] [%(cid)s] tool=%(tool)s duration_ms=%(dur)d ok=%(ok)s msg=%(message)s

    For non-tool log lines the extra fields default to ``-`` / ``0``
    so the formatter never raises.

    Using ``force=True`` makes the call idempotent so repeated
    invocations (e.g. from the test suite) don't stack handlers.
    """
    formatter = _McpLogFormatter()

    stderr_handler = logging.StreamHandler(sys.stderr)
    stderr_handler.setFormatter(formatter)
    handlers: list[logging.Handler] = [stderr_handler]

    if log_file:
        # 10 MB × 5 backups per R16.3 / design §10.2.
        file_handler = RotatingFileHandler(
            log_file,
            maxBytes=10 * 1024 * 1024,
            backupCount=5,
            encoding="utf-8",
        )
        file_handler.setFormatter(formatter)
        handlers.append(file_handler)

    logging.basicConfig(
        level=level,
        handlers=handlers,
        force=True,
    )


# ---------------------------------------------------------------------------
# Signal handling (design §9.4, R1.7)
# ---------------------------------------------------------------------------


def _install_signal_handlers(ctx: ServerContext) -> None:
    """Install SIGINT / SIGTERM handlers for graceful shutdown.

    Sequence on signal (design §9.4):

    1. Set ``ctx.shutdown_event`` so any polling tool can bail out
       early.
    2. Wait up to 10 seconds on ``ctx.tool_inflight`` — the event is
       cleared by :meth:`ServerContext.mark_tool_start` while at least
       one Tool is running, so ``wait`` returns ``True`` as soon as the
       last Tool finishes.
    3. Call :meth:`ServerContext.shutdown` to release the SAP COM
       connection and the cross-process channel lock.
    4. Exit with the appropriate code: ``130`` for SIGINT (POSIX
       convention), ``0`` for SIGTERM, and ``1`` if inflight Tools
       failed to drain within the 10 s budget (R1.7).

    SIGTERM may be absent on Windows; the ``hasattr`` guard keeps
    ``sap-qa-mcp --help`` working on hosts that only expose SIGINT.
    """
    sigterm = getattr(signal, "SIGTERM", None)

    def _handler(signum: int, _frame) -> None:
        logger.info("Received signal %d, shutting down...", signum)
        ctx.shutdown_event.set()

        # ``wait`` returns True if the event was already set or becomes
        # set within the timeout. ``tool_inflight`` is kept "set" while
        # no tool is running, so draining == "event is set".
        drained = ctx.tool_inflight.wait(timeout=10)

        try:
            ctx.shutdown()
        except Exception as exc:  # noqa: BLE001 — best-effort at exit
            logger.warning("ServerContext.shutdown() raised: %s", exc)

        if not drained:
            logger.warning(
                "Inflight tools did not drain within 10s; forcing exit",
            )
            sys.exit(_EXIT_DRAIN_TIMEOUT)

        # SIGINT → 130, SIGTERM → 0. Any other signal we happen to be
        # installed on would be unusual; default to 0 so we don't
        # fabricate a failure status.
        if signum == signal.SIGINT:
            sys.exit(_EXIT_SIGINT)
        sys.exit(_EXIT_OK)

    signal.signal(signal.SIGINT, _handler)
    if sigterm is not None:
        signal.signal(sigterm, _handler)


# ---------------------------------------------------------------------------
# Subcommand dispatch
# ---------------------------------------------------------------------------


def _run_server(args: argparse.Namespace) -> int:
    """Default subcommand: start the MCP server.

    The function is split out of :func:`main` so unit tests can
    exercise parsing and dispatch independently. It returns an exit
    code rather than calling :func:`sys.exit` directly because the
    signal handler owns the "hard exit" path — a normal return from
    the transport (e.g. stdin closed) should propagate as ``0``.
    """
    cfg = load_config(args)
    _configure_logging(cfg.log_level, cfg.log_file)

    ctx = ServerContext(cfg)
    _install_signal_handlers(ctx)

    mcp = build_mcp(ctx)

    try:
        if cfg.transport == "stdio":
            return _run_stdio(mcp, ctx)
        if cfg.transport == "streamable-http":
            return _run_http(mcp, ctx)
        logger.error("Unknown transport: %s", cfg.transport)
        return _EXIT_NOT_IMPLEMENTED
    finally:
        # Idempotent — the signal handler may have called shutdown
        # already; ServerContext.shutdown is written to tolerate both.
        try:
            ctx.shutdown()
        except Exception as exc:  # noqa: BLE001 — best-effort at exit
            logger.warning("ServerContext.shutdown() raised in finally: %s", exc)


def _run_stdio(mcp, ctx: ServerContext) -> int:
    """Run the stdio transport.

    Phase 8.1 will supply :mod:`app.mcp_server.transport.stdio` with a
    richer adapter. Until then we fall back to :meth:`FastMCP.run` so
    the server is usable for Phase 1 contract tests.
    """
    try:
        from .transport.stdio import run_stdio
    except ImportError:
        logger.debug(
            "transport.stdio not available yet; using FastMCP.run(transport='stdio')",
        )
        mcp.run(transport="stdio")
        return _EXIT_OK

    run_stdio(mcp, ctx)
    return _EXIT_OK


def _run_http(mcp, ctx: ServerContext) -> int:
    """Run the streamable-http transport (Phase 8.2).

    The adapter is not yet implemented; returning exit code 2 keeps
    the contract documented in the module docstring ("transport not
    implemented" → 2). Phase 8.2 drops in the real implementation and
    this branch becomes a simple delegation.
    """
    try:
        from .transport.http import run_http  # type: ignore[import-not-found]
    except ImportError:
        logger.error(
            "streamable-http transport not yet implemented (Phase 8.2)",
        )
        return _EXIT_NOT_IMPLEMENTED

    run_http(mcp, ctx)
    return _EXIT_OK


def _run_validate_skills(args: argparse.Namespace) -> int:
    """``validate-skills`` subcommand (design §9.1, Phase 3.3).

    Delegates to :func:`app.mcp_server.skills_loader.validator.validate_all`
    when that module exists. Before Phase 3.3 lands we report "not
    implemented" and exit ``2`` so CI doesn't silently pass on a
    missing validator (R21.3).
    """
    try:
        from .skills_loader.validator import validate_all  # type: ignore[import-not-found]
    except ImportError:
        print(
            "validate-skills is not yet implemented (Phase 3.3).",
            file=sys.stderr,
        )
        return _EXIT_NOT_IMPLEMENTED

    skills_dir = getattr(args, "mcp_skills_dir", None)
    return int(validate_all(skills_dir))


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------


def main(argv: Optional[list[str]] = None) -> int:
    """CLI entry point.

    ``argv`` is optional so tests can pass a synthetic list of tokens
    instead of manipulating :data:`sys.argv`. Returns the process exit
    code — the ``if __name__ == "__main__"`` hook below forwards it to
    :func:`sys.exit`.
    """
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.subcommand == "validate-skills":
        return _run_validate_skills(args)
    return _run_server(args)


if __name__ == "__main__":  # pragma: no cover - convenience entry
    sys.exit(main())
