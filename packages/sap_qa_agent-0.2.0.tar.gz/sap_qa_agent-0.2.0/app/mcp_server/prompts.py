"""Register ``skill:{id}`` MCP Prompts (design §4.10).

For every installed Skill we expose a Prompt named ``skill:{skill_id}``
whose body is the Skill's front-matter ``description`` followed by the
``## When to use`` section extracted from the ``SKILL.md`` body. This
lets host agents hook the Skills directly into their UI's prompt
library without having to read the whole markdown.

Requirement: R11.5.
"""

from __future__ import annotations

import logging
import re
from typing import Callable

from fastmcp import FastMCP

from .context import ServerContext
from .safety import _mcp_skills_dir

__all__ = ["register"]

logger = logging.getLogger(__name__)

# Matches the "## When to use" section up to the next "## " header
# (non-greedy, multiline). If the section is missing the Prompt body
# falls back to just the description.
_WHEN_TO_USE_RE = re.compile(
    r"##\s*When to use\s*\n(.*?)(?:\n##\s|\Z)",
    re.DOTALL,
)


def register(mcp: FastMCP, ctx: ServerContext) -> None:
    """Walk the Skill cache and register one Prompt per Skill.

    Skill changes at runtime are picked up on the next
    :meth:`SkillCache.all` call (Task 3.2); new / removed Skills
    between calls do not automatically re-register against fastmcp
    (it only supports static registration). R11.6's "next list_skills
    refresh" covers the dynamic-discovery path via tools; Prompts are
    effectively snapshot at server start-up.
    """
    cache = _get_skill_cache(ctx)

    for pkg in cache.all():
        meta = pkg.metadata
        body = _prompt_body(meta.description, pkg.content_md)

        # Close over ``body`` so every registered prompt returns its
        # own text; a default arg avoids the late-binding gotcha.
        def _handler(_body: str = body) -> str:
            return _body

        _handler.__name__ = f"prompt_{meta.id.replace('-', '_')}"
        prompt_name = f"skill:{meta.id}"

        try:
            _register_prompt(mcp, prompt_name, meta.description, _handler)
        except Exception as exc:  # noqa: BLE001 - keep other prompts alive
            logger.warning(
                "failed to register prompt %s: %s", prompt_name, exc
            )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _prompt_body(description: str, content_md: str) -> str:
    """Build the prompt body per design §4.10."""
    when_to_use = _extract_when_to_use(content_md)
    if when_to_use:
        return f"{description}\n\n## When to use\n{when_to_use}"
    return description


def _extract_when_to_use(content_md: str) -> str:
    """Return the body of the ``## When to use`` section, or empty string."""
    match = _WHEN_TO_USE_RE.search(content_md)
    if not match:
        return ""
    return match.group(1).strip()


def _get_skill_cache(ctx: ServerContext):
    """Return the shared SkillCache, creating it if the first caller is us."""
    cache = getattr(ctx, "skill_cache", None)
    if cache is not None:
        return cache
    from .skills_loader.cache import SkillCache

    cache = SkillCache(_mcp_skills_dir())
    ctx.skill_cache = cache  # type: ignore[attr-defined]
    return cache


def _register_prompt(
    mcp: FastMCP,
    name: str,
    description: str,
    handler: Callable[[], str],
) -> None:
    """Register a handler with the widest-compatible fastmcp surface.

    Newer releases accept ``@mcp.prompt(name=..., description=...)``;
    some older ones only accept positional ``name``. We try the rich
    form first and degrade on :class:`TypeError`.
    """
    try:
        mcp.prompt(name=name, description=description)(handler)
        return
    except TypeError:
        pass
    try:
        mcp.prompt(name)(handler)
        return
    except TypeError:
        pass
    # As a last resort, register without a name and rely on the
    # handler's ``__name__``. This keeps the prompt addressable even
    # on SDK versions where the decorator has a different signature.
    mcp.prompt()(handler)
