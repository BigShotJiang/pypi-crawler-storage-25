"""URI router for ``sap-qa://`` resources.

Implements design §5.1 / §5.2 / §5.3 — the ``sap-qa://`` scheme is
partitioned into categories (``artifacts`` / ``parsed`` /
``knowledge-base`` / ``skills`` / ``server``) and each category maps
to either a physical path inside a whitelisted directory or a
dynamic in-memory payload.

Requirements covered: R6.1–R6.6, R16.4, R20.5.

FastMCP's ``@mcp.resource("uri")`` decorator only supports a single
concrete URI per registration, so this module registers **template**
resources where FastMCP supports placeholders (artifacts /
knowledge-base / parsed / skills) and explicit handlers for the
always-present roots (``sap-qa://server/metrics``,
``sap-qa://knowledge-base/templates``, ``sap-qa://skills/index``).

The 5 MB cap from R6.4 applies to every file-backed resource; larger
payloads return a JSON envelope with ``error.code=RESOURCE_TOO_LARGE``
so clients can surface the size + ``local_path`` without reading the
file into memory.
"""

from __future__ import annotations

import json
import logging
import mimetypes
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Optional
from urllib.parse import unquote

from fastmcp import FastMCP

from .context import ServerContext
from .errors import ErrorCode, fail, ok
from .safety import PathNotAllowedError, _mcp_skills_dir, ensure_path_allowed

__all__ = ["register", "resolve", "UriResolution"]

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Constants (design §5.1 / §5.2)
# ---------------------------------------------------------------------------


#: Max size allowed for binary / text payload inlined in a
#: ``resources/read`` response (R6.4). Larger resources return a
#: ``RESOURCE_TOO_LARGE`` envelope.
MAX_RESOURCE_SIZE: int = 5 * 1024 * 1024


@dataclass
class UriResolution:
    """Resolution result for an incoming ``sap-qa://`` URI."""

    scheme: str
    category: str
    params: dict[str, str]
    physical_path: Optional[Path] = None
    dynamic_loader: Optional[Callable[[ServerContext], Any]] = None
    mime_type: str = "application/octet-stream"


# ---------------------------------------------------------------------------
# URI resolver
# ---------------------------------------------------------------------------


def resolve(uri: str, ctx: ServerContext) -> UriResolution:
    """Parse a ``sap-qa://`` URI into a :class:`UriResolution`.

    Raises :class:`ValueError` on an unrecognised shape so the caller
    can emit ``RESOURCE_NOT_FOUND`` without having to branch on the
    error message.
    """
    if not uri.startswith("sap-qa://"):
        raise ValueError(f"unsupported scheme: {uri!r}")

    path = uri[len("sap-qa://") :]
    path = unquote(path)
    parts = path.split("/")
    category = parts[0] if parts else ""

    cfg = ctx.config
    artifacts_root = Path(cfg.artifacts_dir)

    if category == "artifacts":
        # sap-qa://artifacts/{task_id}/{filename...}
        if len(parts) < 2:
            raise ValueError("artifacts URI missing task_id")
        physical = artifacts_root.joinpath(*parts[1:])
        return UriResolution(
            scheme="sap-qa",
            category="artifacts",
            params={"task_id": parts[1], "filename": "/".join(parts[2:])},
            physical_path=physical,
            mime_type=_guess_mime(physical),
        )

    if category == "parsed":
        # sap-qa://parsed/{hash}/case_{i}.json
        if len(parts) < 3:
            raise ValueError("parsed URI missing hash or filename")
        physical = artifacts_root / "mcp-parsed" / parts[1] / parts[2]
        return UriResolution(
            scheme="sap-qa",
            category="parsed",
            params={"hash": parts[1], "filename": parts[2]},
            physical_path=physical,
            mime_type="application/json",
        )

    if category == "knowledge-base":
        # sap-qa://knowledge-base/templates           — dynamic index
        # sap-qa://knowledge-base/templates/{id}      — dynamic single template
        if len(parts) >= 2 and parts[1] == "templates":
            if len(parts) == 2:
                return UriResolution(
                    scheme="sap-qa",
                    category="knowledge-base",
                    params={"kind": "index"},
                    dynamic_loader=_load_kb_index,
                    mime_type="application/json",
                )
            template_id = parts[2]
            return UriResolution(
                scheme="sap-qa",
                category="knowledge-base",
                params={"kind": "template", "template_id": template_id},
                dynamic_loader=lambda c, tid=template_id: _load_kb_template(c, tid),
                mime_type="application/json",
            )

    if category == "skills":
        # sap-qa://skills/index          — dynamic index
        # sap-qa://skills/{skill_id}     — SKILL.md body (text/markdown)
        if len(parts) >= 2:
            if parts[1] == "index":
                return UriResolution(
                    scheme="sap-qa",
                    category="skills",
                    params={"kind": "index"},
                    dynamic_loader=_load_skills_index,
                    mime_type="application/json",
                )
            skill_id = parts[1]
            physical = _mcp_skills_dir() / skill_id / "SKILL.md"
            return UriResolution(
                scheme="sap-qa",
                category="skills",
                params={"skill_id": skill_id},
                physical_path=physical,
                mime_type="text/markdown",
            )

    if category == "server":
        # sap-qa://server/metrics
        if len(parts) >= 2 and parts[1] == "metrics":
            return UriResolution(
                scheme="sap-qa",
                category="server",
                params={"kind": "metrics"},
                dynamic_loader=_load_metrics,
                mime_type="application/json",
            )

    raise ValueError(f"unknown sap-qa URI category: {uri!r}")


# ---------------------------------------------------------------------------
# Dynamic loaders
# ---------------------------------------------------------------------------


def _load_kb_index(ctx: ServerContext) -> str:
    """Dump every template summary as JSON."""
    kb = ctx.kb
    infos = kb.list_templates()
    payload = {
        "count": len(infos),
        "templates": [
            {
                "template_id": info.template_id,
                "transaction_code": info.transaction_code,
                "scenario_type": info.scenario_type,
                "confidence": info.confidence.value,
                "last_success_at": (
                    info.last_success_at.isoformat()
                    if info.last_success_at
                    else None
                ),
            }
            for info in infos
        ],
    }
    return json.dumps(payload, ensure_ascii=False, indent=2)


def _load_kb_template(ctx: ServerContext, template_id: str) -> Optional[str]:
    """Return a single template as JSON, or ``None`` if not found."""
    kb = ctx.kb
    for info in kb.list_templates():
        if info.template_id == template_id:
            full = kb.match_template(info.transaction_code, info.scenario_type)
            if full is not None:
                return json.dumps(full.to_dict(), ensure_ascii=False, indent=2)
            return None
    return None


def _load_skills_index(ctx: ServerContext) -> str:
    """Dump every Skill's metadata as JSON."""
    cache = _get_skill_cache(ctx)
    return json.dumps(
        {
            "skills": [pkg.metadata.to_dict() for pkg in cache.all()],
        },
        ensure_ascii=False,
        indent=2,
    )


def _load_metrics(ctx: ServerContext) -> str:
    """Serialise the in-memory metrics snapshot (R16.4)."""
    snapshot = ctx.metrics.snapshot() if ctx.metrics is not None else {}
    return json.dumps(snapshot, ensure_ascii=False, indent=2)


def _get_skill_cache(ctx: ServerContext):
    """Return the shared SkillCache, creating it on the fly if needed."""
    cache = getattr(ctx, "skill_cache", None)
    if cache is not None:
        return cache
    from .skills_loader.cache import SkillCache

    cache = SkillCache(_mcp_skills_dir())
    ctx.skill_cache = cache  # type: ignore[attr-defined]
    return cache


# ---------------------------------------------------------------------------
# MIME helpers
# ---------------------------------------------------------------------------


def _guess_mime(path: Path) -> str:
    """Best-effort MIME type lookup."""
    mime, _ = mimetypes.guess_type(str(path))
    return mime or "application/octet-stream"


# ---------------------------------------------------------------------------
# Read pipeline (shared between template handlers and contract tests)
# ---------------------------------------------------------------------------


def read_uri(uri: str, ctx: ServerContext) -> dict[str, Any]:
    """Resolve and read a ``sap-qa://`` URI into a response envelope.

    The return shape is the ``ok()`` / ``fail()`` envelope so callers
    that need to bridge into MCP's ``resources/read`` format can do so
    with a single adapter pass.
    """
    try:
        resolution = resolve(uri, ctx)
    except ValueError as exc:
        return fail(
            ErrorCode.RESOURCE_NOT_FOUND,
            message=str(exc),
            details={"uri": uri},
        )

    # Dynamic payloads first — they're always in-memory and already
    # size-bounded by the underlying data sources.
    if resolution.dynamic_loader is not None:
        try:
            payload = resolution.dynamic_loader(ctx)
        except Exception as exc:  # noqa: BLE001 - dynamic loaders are user-facing
            logger.exception("dynamic loader for %s failed", uri)
            return fail(
                ErrorCode.INTERNAL_ERROR,
                message=f"dynamic loader failed: {exc}",
            )
        if payload is None:
            return fail(
                ErrorCode.RESOURCE_NOT_FOUND,
                details={"uri": uri},
            )
        return ok(
            {
                "uri": uri,
                "mime_type": resolution.mime_type,
                "text": payload,
            }
        )

    # File-backed payloads: run whitelist + size checks before reading.
    assert resolution.physical_path is not None  # resolver guarantees one or the other
    physical = resolution.physical_path

    try:
        resolved_path = ensure_path_allowed(physical, ctx.config)
    except PathNotAllowedError as exc:
        return fail(
            ErrorCode.PATH_NOT_ALLOWED,
            details={"path": exc.path, "uri": uri},
        )

    if not resolved_path.exists():
        return fail(
            ErrorCode.RESOURCE_NOT_FOUND,
            details={"uri": uri},
        )

    try:
        size = resolved_path.stat().st_size
    except OSError as exc:
        logger.warning("stat failed for %s: %s", resolved_path, exc)
        return fail(
            ErrorCode.INTERNAL_ERROR,
            message=f"stat failed: {exc}",
        )

    if size > MAX_RESOURCE_SIZE:
        return fail(
            ErrorCode.RESOURCE_TOO_LARGE,
            message=(
                f"resource size {size} bytes exceeds inline limit "
                f"{MAX_RESOURCE_SIZE}; read directly from local_path"
            ),
            details={
                "uri": uri,
                "size": size,
                "local_path": str(resolved_path),
            },
        )

    # Text vs. binary — keep markdown / json / text/* inline as text,
    # everything else gets base64-encoded so image callers still get
    # usable bytes.
    text_like = resolution.mime_type.startswith("text/") or resolution.mime_type in {
        "application/json",
        "application/markdown",
    }

    if text_like:
        try:
            body = resolved_path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            body = resolved_path.read_bytes().decode("utf-8", errors="replace")
        return ok(
            {
                "uri": uri,
                "mime_type": resolution.mime_type,
                "text": body,
                "size": size,
            }
        )

    # Binary: return base64
    import base64

    raw = resolved_path.read_bytes()
    return ok(
        {
            "uri": uri,
            "mime_type": resolution.mime_type,
            "data": base64.b64encode(raw).decode("ascii"),
            "size": size,
        }
    )


# ---------------------------------------------------------------------------
# FastMCP registration
# ---------------------------------------------------------------------------


def register(mcp: FastMCP, ctx: ServerContext) -> None:
    """Register resource handlers against *mcp*.

    Strategy:

    * The two always-present roots (``sap-qa://knowledge-base/templates``
      and ``sap-qa://skills/index``, R6.6) get explicit decorators so
      they show up in ``resources/list`` without the caller having to
      guess the URI.
    * ``sap-qa://server/metrics`` gets its own handler (R16.4).
    * Everything else is reachable via :func:`read_uri`. Some fastmcp
      releases support ``@mcp.resource("sap-qa://artifacts/{path}")``
      templates; for broad version compatibility we expose the generic
      reader through an explicit template when available and otherwise
      rely on the static roots (file-backed URIs are still reachable
      via the direct ``read_uri`` call in tool implementations).
    """

    @mcp.resource("sap-qa://knowledge-base/templates")
    def kb_templates() -> str:
        return _load_kb_index(ctx)

    @mcp.resource("sap-qa://skills/index")
    def skills_index() -> str:
        return _load_skills_index(ctx)

    @mcp.resource("sap-qa://server/metrics")
    def server_metrics() -> str:
        return _load_metrics(ctx)

    # Template handlers — registered when fastmcp supports them.
    # Any failure (old SDK version, unknown kwarg) is downgraded to
    # DEBUG because the explicit roots above still cover the R6.6
    # requirement.
    for template, loader in _template_handlers(ctx):
        try:
            mcp.resource(template)(loader)
        except Exception as exc:  # noqa: BLE001 - registration is best-effort
            logger.debug(
                "Could not register template resource %s: %s", template, exc
            )


def _template_handlers(
    ctx: ServerContext,
) -> list[tuple[str, Callable[..., str]]]:
    """Build the (uri_template, handler) pairs registered above."""

    def artifacts_handler(task_id: str, filename: str) -> str:  # noqa: ARG001
        uri = f"sap-qa://artifacts/{task_id}/{filename}"
        envelope = read_uri(uri, ctx)
        return _envelope_to_text(envelope)

    def parsed_handler(hash: str, filename: str) -> str:  # noqa: A002
        uri = f"sap-qa://parsed/{hash}/{filename}"
        envelope = read_uri(uri, ctx)
        return _envelope_to_text(envelope)

    def skill_handler(skill_id: str) -> str:
        uri = f"sap-qa://skills/{skill_id}"
        envelope = read_uri(uri, ctx)
        return _envelope_to_text(envelope)

    def kb_template_handler(template_id: str) -> str:
        uri = f"sap-qa://knowledge-base/templates/{template_id}"
        envelope = read_uri(uri, ctx)
        return _envelope_to_text(envelope)

    return [
        ("sap-qa://artifacts/{task_id}/{filename}", artifacts_handler),
        ("sap-qa://parsed/{hash}/{filename}", parsed_handler),
        ("sap-qa://skills/{skill_id}", skill_handler),
        ("sap-qa://knowledge-base/templates/{template_id}", kb_template_handler),
    ]


def _envelope_to_text(envelope: dict[str, Any]) -> str:
    """Convert a read_uri envelope into the text that FastMCP expects.

    FastMCP's string-return resources flatten to the response's text
    field; we serialise the envelope directly so clients see the same
    ``ok``/``fail`` shape used by tools. Binary payloads still round-
    trip because the envelope embeds the base64-encoded bytes.
    """
    return json.dumps(envelope, ensure_ascii=False)
