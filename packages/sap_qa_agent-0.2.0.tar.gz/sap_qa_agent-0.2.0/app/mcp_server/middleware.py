"""Middleware wiring correlation_id, logging, metrics, token budget, and
response scrubbing for every MCP Tool invocation.

Implements design §10.1 (the ``correlation_id`` contextvar + the
``with_middleware`` decorator) and §10.2 (the per-call log line with
``[cid] tool=... duration_ms=... ok=...``). The token-budget hook
(§10.3) and the response-scrubbing pass (§10.5) are wired through lazy
imports so this module can land in Phase 1 before Phase 2.1 (safety)
and Phase 9.1 (token budget) exist.

The module exposes a single public entry point, :func:`bind_middleware`,
which returns a decorator closed over a :class:`ServerContext`. Each
tool module applies the returned decorator to its handler before
registering it with :class:`fastmcp.FastMCP`. Going through a factory
(rather than a module-level decorator) keeps ``ctx.metrics`` /
``ctx.mark_tool_start`` etc. reachable without turning ``ServerContext``
into a global.

Key behaviours:

* A fresh ``uuid.uuid4().hex`` correlation id is minted for every call,
  stored in :data:`~app.mcp_server.errors.correlation_id_var`, and
  copied into the response envelope. The response will already carry
  the correct id if the handler used :func:`~app.mcp_server.errors.ok`
  / :func:`~app.mcp_server.errors.fail` (since they read the contextvar
  eagerly); ``setdefault`` only fills in callers that built the dict
  themselves.

* Unhandled exceptions are logged with traceback via ``logger.exception``
  and converted into an ``INTERNAL_ERROR`` envelope (design §10.1, R15.5).
  Only the first 200 characters of ``str(exc)`` are surfaced so stack
  traces and secrets don't leak to the client.

* Inflight tracking (``ctx.mark_tool_start`` / ``ctx.mark_tool_end``)
  wraps the whole call including post-processing, so the signal
  handler (Task 1.7) waits until the response has been fully prepared
  before declaring drain complete (R1.7 / R1.8).

* Both sync and async handlers are supported. :mod:`fastmcp` accepts
  either, and our tools module mix both styles (parse tools are sync,
  execution tools are async), so the decorator inspects the wrapped
  function once and returns the matching wrapper.

* Non-dict return values are wrapped in ``{"ok": True, "data": ...}``
  defensively. This should never happen for well-behaved tools using
  the envelope helpers, but guarding against it ensures the token
  budget / scrub pass downstream always operates on a ``dict``.
"""

from __future__ import annotations

import asyncio
import functools
import logging
import time
import uuid
from typing import Any, Callable

from .context import ServerContext
from .errors import ErrorCode, correlation_id_var, fail

__all__ = ["bind_middleware"]

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Public factory
# ---------------------------------------------------------------------------


def bind_middleware(ctx: ServerContext) -> Callable[[Callable], Callable]:
    """Return a decorator that applies the MCP middleware stack.

    The returned decorator is applied once per tool handler at
    registration time (see design §2.3 — registration walks each
    ``tools/*.py`` module and calls ``@bind_middleware(ctx)`` before
    handing the callable to :class:`fastmcp.FastMCP`). It closes over
    ``ctx`` so each tool invocation can record metrics, track the
    inflight counter, and look up the token budget from the same
    :class:`~app.mcp_server.context.ServerContext`.

    Parameters
    ----------
    ctx:
        The process-wide :class:`ServerContext`. Must provide
        ``metrics``, ``mark_tool_start`` and ``mark_tool_end``.

    Returns
    -------
    Callable
        A decorator. Applied to a sync function it returns a sync
        wrapper; applied to a coroutine function it returns an async
        wrapper. In both cases the wrapper is marked with
        :func:`functools.wraps` so FastMCP sees the original name,
        docstring and signature.
    """

    def with_middleware(fn: Callable) -> Callable:
        tool_name = fn.__name__

        if asyncio.iscoroutinefunction(fn):

            @functools.wraps(fn)
            async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                cid = uuid.uuid4().hex
                token = correlation_id_var.set(cid)
                ctx.mark_tool_start()
                _metrics_tool_started(ctx)
                t0 = time.monotonic()
                ok_flag = False
                try:
                    result = await fn(*args, **kwargs)
                    result = _coerce_dict(result)
                    ok_flag = bool(result.get("ok", True))
                    result.setdefault("correlation_id", cid)
                    _post_process(result, ctx)
                    return result
                except Exception as exc:  # noqa: BLE001 - envelope all failures
                    logger.exception(
                        "tool call failed: %s",
                        exc,
                        extra={"cid": cid, "tool": tool_name, "dur": 0, "ok": False},
                    )
                    failure = fail(
                        ErrorCode.INTERNAL_ERROR, message=str(exc)[:200]
                    )
                    failure.setdefault("correlation_id", cid)
                    return failure
                finally:
                    elapsed = time.monotonic() - t0
                    _emit_log(cid, tool_name, elapsed, ok_flag)
                    _record_metric(ctx, tool_name, elapsed, ok_flag)
                    correlation_id_var.reset(token)
                    ctx.mark_tool_end()

            return async_wrapper

        @functools.wraps(fn)
        def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
            cid = uuid.uuid4().hex
            token = correlation_id_var.set(cid)
            ctx.mark_tool_start()
            _metrics_tool_started(ctx)
            t0 = time.monotonic()
            ok_flag = False
            try:
                result = fn(*args, **kwargs)
                result = _coerce_dict(result)
                ok_flag = bool(result.get("ok", True))
                result.setdefault("correlation_id", cid)
                _post_process(result, ctx)
                return result
            except Exception as exc:  # noqa: BLE001 - envelope all failures
                logger.exception(
                    "tool call failed: %s",
                    exc,
                    extra={"cid": cid, "tool": tool_name, "dur": 0, "ok": False},
                )
                failure = fail(ErrorCode.INTERNAL_ERROR, message=str(exc)[:200])
                failure.setdefault("correlation_id", cid)
                return failure
            finally:
                elapsed = time.monotonic() - t0
                _emit_log(cid, tool_name, elapsed, ok_flag)
                _record_metric(ctx, tool_name, elapsed, ok_flag)
                correlation_id_var.reset(token)
                ctx.mark_tool_end()

        return sync_wrapper

    return with_middleware


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _coerce_dict(result: Any) -> dict[str, Any]:
    """Ensure the tool result is a ``dict`` before post-processing.

    Well-behaved tools always return the envelope produced by
    :func:`~app.mcp_server.errors.ok` / :func:`~app.mcp_server.errors.fail`,
    which is a ``dict``. A third-party decorator or a hand-rolled tool
    might return a list or a scalar; wrap those so downstream token
    budget / scrub passes don't have to special-case every type.
    """
    if isinstance(result, dict):
        return result
    return {"ok": True, "data": result}


def _emit_log(cid: str, tool: str, elapsed_s: float, ok: bool) -> None:
    """Emit the per-call summary line (design §10.2 / R16.1).

    Passes ``cid``, ``tool``, ``dur``, and ``ok`` as ``extra`` fields
    so the :class:`~app.mcp_server.cli._McpLogFormatter` can render
    the full §10.2 structured format. The message itself is kept
    minimal since the formatter already includes all structured fields.
    """
    logger.info(
        "tool call completed",
        extra={"cid": cid, "tool": tool, "dur": int(elapsed_s * 1000), "ok": ok},
    )


def _record_metric(
    ctx: ServerContext, tool: str, elapsed_s: float, ok: bool
) -> None:
    """Best-effort metrics recording.

    ``ctx.metrics`` is either the real :class:`Metrics` (Phase 9.2) or
    the no-op stub from :mod:`app.mcp_server.context`. Either way,
    ``record`` should never raise; we still guard against a faulty
    injected mock so a metrics bug can't break tool responses.
    """
    try:
        ctx.metrics.record(tool, elapsed_s, ok)
    except Exception as exc:  # noqa: BLE001 - metrics must never break tools
        logger.debug("metrics.record failed for tool=%s: %s", tool, exc)


def _metrics_tool_started(ctx: ServerContext) -> None:
    """Best-effort metrics active_tasks increment.

    Signals to the :class:`Metrics` instance that a new tool
    invocation has begun, incrementing the ``active_tasks`` counter.
    """
    try:
        tool_started = getattr(ctx.metrics, "tool_started", None)
        if callable(tool_started):
            tool_started()
    except Exception as exc:  # noqa: BLE001 - metrics must never break tools
        logger.debug("metrics.tool_started failed: %s", exc)


def _post_process(result: dict[str, Any], ctx: ServerContext) -> None:
    """Apply response scrubbing and token-budget truncation in order.

    Both passes are wired through lazy imports so this middleware
    module can land before Phase 2.1 (``safety.scrub_sensitive``) and
    Phase 9.1 (token budget). When the target module isn't importable,
    the step is a silent no-op; once the real module lands, no change
    here is required.
    """
    # Response scrubbing — design §10.5 / R20.5. Runs before the token
    # budget pass so that if scrubbing replaces a big secret with
    # ``"***"`` it also shrinks the payload the budget is applied to.
    try:
        from .safety import scrub_sensitive  # type: ignore[import-not-found]
    except ImportError:
        pass
    else:
        try:
            scrub_sensitive(result)
        except Exception as exc:  # noqa: BLE001 - safety must not break tools
            logger.warning("scrub_sensitive failed: %s", exc)

    # Token budget — design §10.3 / R14. The real implementation lives
    # in Phase 9.1; until then the call is skipped.
    try:
        from .token_budget import apply_token_budget  # type: ignore[import-not-found]
    except ImportError:
        pass
    else:
        try:
            apply_token_budget(result, ctx)
        except Exception as exc:  # noqa: BLE001 - budget must not break tools
            logger.warning("apply_token_budget failed: %s", exc)
