"""In-memory metrics collector for the MCP server.

Implements design §10.4 — lightweight counters that track tool call
volume, error rate, per-tool latency, and active (inflight) tool count.

The :class:`Metrics` instance lives on :attr:`ServerContext.metrics` and
is consumed by:

* **middleware.py** — calls :meth:`tool_started` at the beginning of
  each tool invocation and :meth:`record` in the ``finally`` block.
* **resources.py** — the ``sap-qa://server/metrics`` handler calls
  :meth:`snapshot` to produce the JSON payload (R16.4).

Thread safety: all mutations use a single :class:`threading.Lock` so
concurrent tool invocations (possible in streamable-http mode) don't
corrupt the counters.

Requirements: R16.1, R16.4.
"""

from __future__ import annotations

import threading
from collections import defaultdict
from typing import Any

__all__ = ["Metrics"]


class Metrics:
    """Accumulates per-tool call metrics in memory.

    Attributes
    ----------
    tool_call_count : int
        Total number of tool invocations (success + failure).
    tool_error_count : int
        Number of tool invocations that returned ``ok=False``.
    duration_ms_sum : dict[str, int]
        Cumulative elapsed milliseconds per tool name.
    duration_ms_count : dict[str, int]
        Number of completed calls per tool name (denominator for avg).
    active_tasks : int
        Number of tool invocations currently in-flight.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self.tool_call_count: int = 0
        self.tool_error_count: int = 0
        self.duration_ms_sum: dict[str, int] = defaultdict(int)
        self.duration_ms_count: dict[str, int] = defaultdict(int)
        self.active_tasks: int = 0

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def tool_started(self) -> None:
        """Signal that a tool invocation has begun.

        Called by the middleware at the top of each tool wrapper,
        before the handler executes. Increments :attr:`active_tasks`.
        """
        with self._lock:
            self.active_tasks += 1

    def record(self, tool: str, elapsed_s: float, ok: bool) -> None:
        """Record the outcome of a completed tool invocation.

        Called by the middleware in the ``finally`` block after the
        tool handler returns (or raises). Decrements
        :attr:`active_tasks` and accumulates the duration and
        success/failure counters.

        Parameters
        ----------
        tool:
            The tool function name (e.g. ``"parse_test_case"``).
        elapsed_s:
            Wall-clock seconds the tool took to execute.
        ok:
            Whether the tool returned a success envelope.
        """
        elapsed_ms = int(elapsed_s * 1000)
        with self._lock:
            self.active_tasks = max(0, self.active_tasks - 1)
            self.tool_call_count += 1
            if not ok:
                self.tool_error_count += 1
            self.duration_ms_sum[tool] += elapsed_ms
            self.duration_ms_count[tool] += 1

    def snapshot(self) -> dict[str, Any]:
        """Return a JSON-serialisable metrics snapshot.

        The shape matches design §10.4 / R16.4::

            {
                "tool_call_count": 42,
                "tool_error_count": 3,
                "avg_duration_ms_by_tool": {
                    "parse_test_case": 150,
                    "sap_connect": 2000
                },
                "active_tasks": 1
            }
        """
        with self._lock:
            avg_by_tool: dict[str, int] = {}
            for tool, total_ms in self.duration_ms_sum.items():
                count = self.duration_ms_count.get(tool, 0)
                avg_by_tool[tool] = int(total_ms / count) if count > 0 else 0

            return {
                "tool_call_count": self.tool_call_count,
                "tool_error_count": self.tool_error_count,
                "avg_duration_ms_by_tool": avg_by_tool,
                "active_tasks": self.active_tasks,
            }
