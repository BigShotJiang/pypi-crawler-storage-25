"""Path whitelist + sensitive-key scrubbing for MCP responses.

Implements design §5.3 (whitelist check before file I/O) and §10.5
(recursive JSON scrub for sensitive keys). Both helpers are consumed by
the middleware pipeline (Task 1.5) and by file-based tools
(``parse_test_case``, the resource router, etc.).

Requirements covered:

* R13.4 — never echo ``glm_api_key`` / ``auth_token`` values in responses.
* R20.1 / R20.2 — file paths must resolve under an allowed base; otherwise
  raise :class:`PathNotAllowedError` so the caller can emit
  ``PATH_NOT_ALLOWED``.
* R20.5 — ``resources/read`` uses the same gate before serving bytes.
* R20.6 — the gate is transport-agnostic (no special-case for stdio vs
  streamable-http).
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Optional

from .config import ConfigProfile

__all__ = [
    "PathNotAllowedError",
    "SENSITIVE_KEYS",
    "ensure_path_allowed",
    "scrub_sensitive",
]


class PathNotAllowedError(Exception):
    """Raised when ``ensure_path_allowed`` rejects a target.

    Tool-level code catches this and converts it into a
    :class:`~app.mcp_server.errors.ErrorCode.PATH_NOT_ALLOWED` envelope
    via :func:`~app.mcp_server.errors.fail`. The attached ``path``
    attribute carries the canonicalised target (after ``Path.resolve``)
    so the error details can surface the exact location that was
    rejected rather than whatever the caller typed.
    """

    def __init__(self, path: str, reason: str = "path not in whitelist") -> None:
        super().__init__(f"{reason}: {path}")
        self.path = path


# ---------------------------------------------------------------------------
# Whitelist check
# ---------------------------------------------------------------------------


def _mcp_skills_dir() -> Path:
    """Return the workspace-level ``mcp_skills/`` directory.

    Layout:
        ui_test_python/
        ├── app/mcp_server/safety.py   ← __file__
        ├── app/mcp_server/
        ├── app/
        └── mcp_skills/

    ``Path(__file__).resolve()`` lands on ``safety.py``; three
    ``.parent`` hops lift us to ``ui_test_python/`` where
    ``mcp_skills/`` lives. This matches the path used by
    ``[tool.hatch.build.targets.wheel]`` in ``pyproject.toml``.
    """
    return Path(__file__).resolve().parent.parent.parent / "mcp_skills"


def _get_allowed_bases(cfg: ConfigProfile) -> list[str]:
    """Return the allowed base directories for file-based tools.

    The five categories come from design §5.3. Duplicates are dropped
    while preserving insertion order so error messages stay readable
    when ``allow_paths`` overlaps one of the defaults.
    """
    bases: list[str] = [
        cfg.upload_dir,
        cfg.artifacts_dir,
        cfg.knowledge_base_dir,
        str(_mcp_skills_dir()),
        *cfg.allow_paths,
    ]

    seen: dict[str, None] = {}
    for base in bases:
        if base:
            seen[base] = None
    return list(seen.keys())


def ensure_path_allowed(path: str | Path, cfg: ConfigProfile) -> Path:
    """Raise :class:`PathNotAllowedError` if ``path`` is outside the whitelist.

    ``Path.resolve(strict=False)`` canonicalises the target: it collapses
    ``..`` components, follows symlinks where possible, and on Windows
    normalises casing to whatever the filesystem reports. That catches
    both of the common bypass shapes:

    * ``allowed/../etc/passwd`` — collapses to ``/etc/passwd`` and falls
      outside every base.
    * ``UPLOADS\\file.xlsx`` vs. ``uploads\\file.xlsx`` — both resolve to
      the same canonical form so casing games don't defeat the check.

    The target does **not** need to exist (``strict=False``). Write-
    before-existence tools (e.g. ``parse_test_case`` with ``content``
    mode) can validate the destination before creating it.

    Returns the resolved target so callers don't have to re-resolve.
    """
    target = Path(path).resolve(strict=False)
    bases = _get_allowed_bases(cfg)

    for base in bases:
        try:
            base_resolved = Path(base).resolve(strict=False)
        except (OSError, RuntimeError):
            # A base that can't be resolved (e.g. permission denied on
            # a parent) is skipped rather than aborting the whole
            # check; the other bases still participate.
            continue
        try:
            target.relative_to(base_resolved)
        except ValueError:
            continue
        return target

    raise PathNotAllowedError(
        str(target),
        reason=f"path not under any allowed base (bases={bases})",
    )


# ---------------------------------------------------------------------------
# Sensitive-key scrubbing
# ---------------------------------------------------------------------------


# Kept in sync with :data:`ConfigProfile.SENSITIVE_KEYS`. The middleware
# imports ``scrub_sensitive`` from this module; the set is also exported
# so other callers (e.g. a future ``server/config`` resource) can apply
# the same mask.
SENSITIVE_KEYS: frozenset[str] = frozenset({"glm_api_key", "auth_token"})

_SCRUB_PLACEHOLDER = "***"


def scrub_sensitive(
    obj: Any,
    *,
    keys: Optional[frozenset[str]] = None,
) -> Any:
    """Recursively replace sensitive values with ``"***"``.

    * Dicts are mutated **in place** so middleware can pass the tool's
      return envelope directly.
    * Lists are walked item by item (no replacement at the list level —
      sensitive data lives under keys, not in bare list positions).
    * Key matching is case-insensitive, so ``Glm_Api_Key`` /
      ``AUTH_TOKEN`` are both redacted.
    * ``None`` values are preserved because they indicate "field not
      set" rather than a leaked secret. Any non-None value (string,
      number, nested structure) is replaced with the placeholder.

    Parameters
    ----------
    obj:
        Typically a dict (the tool response envelope). Scalars pass
        through unchanged.
    keys:
        Override the default :data:`SENSITIVE_KEYS` (useful for tests
        that want to exercise the recursion with a custom alphabet).

    Returns
    -------
    The same object passed in (mutated for dicts/lists, unchanged for
    scalars) so callers can chain.
    """
    k_set = keys if keys is not None else SENSITIVE_KEYS
    # Pre-lower once; callers pass a frozenset that's rarely large, so
    # this is cheap but avoids lowering every lookup inside the loop.
    k_lower = {k.lower() for k in k_set}

    _scrub(obj, k_lower)
    return obj


def _scrub(obj: Any, k_lower: set[str]) -> None:
    """Inner recursion helper used by :func:`scrub_sensitive`."""
    if isinstance(obj, dict):
        for key in list(obj.keys()):
            if str(key).lower() in k_lower:
                if obj[key] is not None:
                    obj[key] = _SCRUB_PLACEHOLDER
            else:
                _scrub(obj[key], k_lower)
    elif isinstance(obj, list):
        for item in obj:
            _scrub(item, k_lower)
    # Scalars (str/int/float/bool/None) pass through unchanged.
