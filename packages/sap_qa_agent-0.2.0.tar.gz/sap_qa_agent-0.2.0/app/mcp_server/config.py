"""Config profile and loader for the MCP server.

Implements design §3.1 (the :class:`ConfigProfile` data model) and
§11.1–§11.3 (four-tier loading: defaults → config file → environment →
CLI args). Precedence is enforced by writing each source into a plain
``dict`` in ascending priority, then constructing the Pydantic model
once at the end so validation runs on the fully merged result.

Requirements covered:

* R13.1 — defaults / file / env / CLI precedence (four-tier).
* R13.2 — all documented keys are modelled.
* R13.5 — config file format errors exit with code 2 and write the
  error location to stderr.

Environment variable names follow design §11.2 exactly:

* ``GLM_API_KEY`` / ``GLM_BASE_URL`` / ``GLM_MODEL`` (shared with
  :mod:`app.config` so the existing FastAPI process and the MCP process
  pick up the same credentials).
* ``SAP_QA_MCP_ARTIFACTS_DIR`` / ``SAP_QA_MCP_KNOWLEDGE_BASE_DIR`` /
  ``SAP_QA_MCP_UPLOAD_DIR``.
* ``SAP_QA_MCP_AUTH_TOKEN``.
* ``SAP_QA_MCP_ALLOW_PATHS`` (``;``-separated, also accepts the host
  ``os.pathsep`` for convenience).
* ``SAP_QA_MCP_ENABLE_ATOMIC_TOOLS`` (truthy: ``1``/``true``/``yes``/``on``).
* ``SAP_QA_MCP_TOKEN_BUDGET`` (integer).

The CLI layer (task 1.7) is expected to use ``default=None`` for any
argparse flag that should participate in the four-tier merge, since
this loader treats ``None`` as "user did not pass it".
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import tomllib
from pathlib import Path
from typing import Any, ClassVar, Literal

from pydantic import BaseModel, Field

from app import config as _app_config

__all__ = ["ConfigProfile", "load_config"]


# ---------------------------------------------------------------------------
# Data model (design §3.1)
# ---------------------------------------------------------------------------


class ConfigProfile(BaseModel):
    """Runtime configuration for the MCP server process.

    All fields carry defaults so the model can be instantiated without
    arguments (useful for unit tests and for the "defaults" tier of
    :func:`load_config`). The three directory fields fall back to the
    same paths the FastAPI backend uses (see :mod:`app.config`) so both
    channels operate on a consistent filesystem layout — see design
    §13.1 on shared ``ARTIFACTS_DIR`` / ``KNOWLEDGE_BASE_DIR`` /
    ``UPLOAD_DIR``.
    """

    # GLM
    glm_api_key: str | None = None
    glm_base_url: str = "https://open.bigmodel.cn/api/coding/paas/v4"
    glm_model: str = "GLM-4"

    # Paths
    knowledge_base_dir: str = _app_config.KNOWLEDGE_BASE_DIR
    artifacts_dir: str = _app_config.ARTIFACTS_DIR
    upload_dir: str = _app_config.UPLOAD_DIR
    allow_paths: list[str] = Field(default_factory=list)

    # Server
    transport: Literal["stdio", "streamable-http"] = "stdio"
    port: int = 8100
    host: str = "127.0.0.1"
    auth_token: str | None = None

    # Behavior
    max_concurrent_tasks: int = 1
    enable_atomic_tools: bool = False
    token_budget: int = 16000
    token_budget_max: int = 64000

    # Observability
    log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR"] = "INFO"
    log_file: str | None = None

    # Meta
    server_name: str = "sap-qa-agent"
    server_version: str = "0.1.0"

    # Sensitive fields that must never appear in tool responses
    # (consumed by :mod:`app.mcp_server.safety` in task 2.1). Declared
    # as ``ClassVar`` so Pydantic treats it as a class-level constant
    # rather than a model field.
    SENSITIVE_KEYS: ClassVar[frozenset[str]] = frozenset(
        {"glm_api_key", "auth_token"}
    )


# ---------------------------------------------------------------------------
# Loader helpers
# ---------------------------------------------------------------------------

_TRUTHY = frozenset({"1", "true", "yes", "on"})
_FALSY = frozenset({"0", "false", "no", "off", ""})


def _parse_bool(value: str) -> bool:
    """Parse a truthy/falsy env value.

    Unknown strings fall back to ``False`` so a typo in an env var
    doesn't silently enable a feature flag. Callers should log when
    they pass something outside the documented set.
    """
    v = value.strip().lower()
    if v in _TRUTHY:
        return True
    if v in _FALSY:
        return False
    return False


def _parse_allow_paths(raw: str) -> list[str]:
    """Split an allow-paths env value on ``;`` or the host ``os.pathsep``.

    Design §11.2 documents ``;`` as the separator. On POSIX hosts the
    native ``os.pathsep`` is ``:``, so we accept that too to avoid
    surprising users who mix the two. Empty tokens (from trailing or
    doubled separators) are dropped.
    """
    separators: set[str] = {";"}
    if os.pathsep:
        separators.add(os.pathsep)
    tokens: list[str] = [raw]
    for sep in separators:
        tokens = [piece for chunk in tokens for piece in chunk.split(sep)]
    return [t for t in (tok.strip() for tok in tokens) if t]


def _load_file(path: str) -> dict[str, Any]:
    """Parse ``path`` into a dict. Exits with code 2 on failure (R13.5).

    The extension selects the parser:

    * ``.json`` → :func:`json.loads`
    * ``.toml`` → :func:`tomllib.loads` (stdlib on Python 3.11+)

    On any parse or I/O error the function writes a message describing
    the error *location* to ``stderr`` and calls ``sys.exit(2)`` so the
    wrapping CLI exits with the documented status code.
    """
    p = Path(path)
    if not p.is_file():
        print(f"config file not found: {path}", file=sys.stderr)
        sys.exit(2)

    suffix = p.suffix.lower()
    if suffix not in {".json", ".toml"}:
        print(
            f"unsupported config file extension {suffix!r} at {path}; "
            f"expected .json or .toml",
            file=sys.stderr,
        )
        sys.exit(2)

    try:
        raw = p.read_text(encoding="utf-8")
    except OSError as exc:
        print(f"failed to read config file {path}: {exc}", file=sys.stderr)
        sys.exit(2)

    try:
        if suffix == ".json":
            data = json.loads(raw)
        else:  # .toml
            data = tomllib.loads(raw)
    except json.JSONDecodeError as exc:
        # json.JSONDecodeError exposes the exact line/column; surface it
        # so users can jump to the offending character.
        print(
            f"config JSON parse error at {path}:{exc.lineno}:{exc.colno}: "
            f"{exc.msg}",
            file=sys.stderr,
        )
        sys.exit(2)
    except tomllib.TOMLDecodeError as exc:
        # tomllib's message already contains the line/column; forward it
        # verbatim with the file path for context.
        print(f"config TOML parse error at {path}: {exc}", file=sys.stderr)
        sys.exit(2)

    if not isinstance(data, dict):
        print(
            f"config file {path} must contain a top-level "
            f"object/table, got {type(data).__name__}",
            file=sys.stderr,
        )
        sys.exit(2)

    return data


def _env_overrides() -> dict[str, Any]:
    """Map environment variables (design §11.2) to ConfigProfile fields.

    Only keys explicitly present in :data:`os.environ` are returned so
    downstream ``dict.update`` does not clobber lower-priority sources
    with absent-env defaults.
    """
    env = os.environ
    out: dict[str, Any] = {}

    # GLM (shared with app/config.py so both channels agree)
    if "GLM_API_KEY" in env:
        out["glm_api_key"] = env["GLM_API_KEY"]
    if "GLM_BASE_URL" in env:
        out["glm_base_url"] = env["GLM_BASE_URL"]
    if "GLM_MODEL" in env:
        out["glm_model"] = env["GLM_MODEL"]

    # Paths
    if "SAP_QA_MCP_ARTIFACTS_DIR" in env:
        out["artifacts_dir"] = env["SAP_QA_MCP_ARTIFACTS_DIR"]
    if "SAP_QA_MCP_KNOWLEDGE_BASE_DIR" in env:
        out["knowledge_base_dir"] = env["SAP_QA_MCP_KNOWLEDGE_BASE_DIR"]
    if "SAP_QA_MCP_UPLOAD_DIR" in env:
        out["upload_dir"] = env["SAP_QA_MCP_UPLOAD_DIR"]
    if "SAP_QA_MCP_ALLOW_PATHS" in env:
        out["allow_paths"] = _parse_allow_paths(env["SAP_QA_MCP_ALLOW_PATHS"])

    # Server auth
    if "SAP_QA_MCP_AUTH_TOKEN" in env:
        out["auth_token"] = env["SAP_QA_MCP_AUTH_TOKEN"]

    # Behavior flags
    if "SAP_QA_MCP_ENABLE_ATOMIC_TOOLS" in env:
        out["enable_atomic_tools"] = _parse_bool(
            env["SAP_QA_MCP_ENABLE_ATOMIC_TOOLS"]
        )
    if "SAP_QA_MCP_TOKEN_BUDGET" in env:
        raw = env["SAP_QA_MCP_TOKEN_BUDGET"]
        try:
            out["token_budget"] = int(raw)
        except ValueError:
            # An invalid number here is a config error analogous to a
            # malformed file (R13.5), so use the same exit semantics.
            print(
                f"SAP_QA_MCP_TOKEN_BUDGET must be an integer, got {raw!r}",
                file=sys.stderr,
            )
            sys.exit(2)

    return out


# argparse Namespace attribute name → ConfigProfile field name.
# Straight pass-through fields only; ``allow_path`` / ``enable_atomic_tools``
# are handled separately because their CLI shape differs from the
# model's shape (list accumulator, store_true).
_CLI_FIELD_MAP: dict[str, str] = {
    "transport": "transport",
    "host": "host",
    "port": "port",
    "auth_token": "auth_token",
    "log_level": "log_level",
    "log_file": "log_file",
    "artifacts_root": "artifacts_dir",
    "mcp_skills_dir": "mcp_skills_dir",  # forward-compat; silently dropped if not modelled
}

# Subset of _CLI_FIELD_MAP entries whose target actually exists on
# ConfigProfile. Computed once at import so unknown attrs (e.g.
# ``mcp_skills_dir``, which is a CLI-only concern handled elsewhere)
# are filtered without per-call overhead.
_VALID_CLI_FIELDS: dict[str, str] = {
    src: dst
    for src, dst in _CLI_FIELD_MAP.items()
    if dst in ConfigProfile.model_fields
}


def _cli_overrides(args: argparse.Namespace | Any) -> dict[str, Any]:
    """Extract CLI overrides from an argparse ``Namespace``.

    A value of ``None`` means "user did not pass this flag" and is
    skipped so env / file values aren't clobbered. Callers must
    therefore configure argparse with ``default=None`` for any flag
    that should participate in the four-tier merge.

    Special cases:

    * ``--allow-path`` accumulates into a list; an empty list is
      treated as "not passed".
    * ``--enable-atomic-tools`` is ``store_true``; only ``True`` counts
      as an explicit override, so that the bare invocation without the
      flag doesn't force the value back to ``False``.
    * ``--artifacts-root`` maps to the ``artifacts_dir`` field.
    """
    out: dict[str, Any] = {}

    for attr, field in _VALID_CLI_FIELDS.items():
        value = getattr(args, attr, None)
        if value is not None:
            out[field] = value

    allow_path = getattr(args, "allow_path", None)
    if allow_path:
        out["allow_paths"] = list(allow_path)

    enable_atomic = getattr(args, "enable_atomic_tools", None)
    if enable_atomic:
        out["enable_atomic_tools"] = True

    return out


def _defaults_dict() -> dict[str, Any]:
    """Return the built-in defaults as a plain dict."""
    return ConfigProfile().model_dump()


# ---------------------------------------------------------------------------
# Public entry point (design §11.1)
# ---------------------------------------------------------------------------


def load_config(args: argparse.Namespace | Any = None) -> ConfigProfile:
    """Load a :class:`ConfigProfile` using the four-tier precedence.

    Order (low → high priority): defaults → ``--config`` file → environment
    → CLI args. Each source only sets keys it actually carries, so a
    higher tier leaves untouched keys to fall through to the next lower
    tier.

    Parameters
    ----------
    args:
        An argparse ``Namespace`` produced by :mod:`app.mcp_server.cli`
        (task 1.7). ``None`` is accepted for unit tests that want the
        defaults + env behaviour without constructing a fake namespace.

    Exits with status 2 via :func:`sys.exit` when the config file is
    malformed (R13.5).
    """
    data: dict[str, Any] = _defaults_dict()

    config_path = getattr(args, "config", None) if args is not None else None
    if config_path:
        data.update(_load_file(config_path))

    data.update(_env_overrides())

    if args is not None:
        data.update(_cli_overrides(args))

    return ConfigProfile(**data)
