"""Transport adapters for the SAP QA Agent MCP Server.

This package provides two transport modes:

* :mod:`.stdio` — local stdio pipe (default), used by Claude Desktop
  and similar host agents that spawn the server as a child process.
* :mod:`.http` — streamable-http with optional Bearer auth, used for
  remote or multi-host scenarios.
"""
