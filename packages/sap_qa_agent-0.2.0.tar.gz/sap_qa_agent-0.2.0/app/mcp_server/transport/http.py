"""Streamable-HTTP transport adapter (design §9.3, R1.2, R1.6, R20.4).

This module provides the HTTP transport for the MCP server, including:

* :class:`BearerAuthMiddleware` — enforces ``Authorization: Bearer <token>``
  when ``--auth-token`` is configured; returns 401 on mismatch.
* :func:`run_http` — assembles the Starlette ASGI app from
  :meth:`FastMCP.streamable_http_app`, attaches the auth middleware,
  and starts Uvicorn.

Security (R20.4): when no ``--auth-token`` is configured the server
binds exclusively to ``127.0.0.1`` regardless of the ``--host`` flag,
preventing accidental exposure on ``0.0.0.0`` without authentication.

Usage from ``cli.py``::

    from .transport.http import run_http
    run_http(mcp, ctx)
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import uvicorn
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse

if TYPE_CHECKING:
    from starlette.types import ASGIApp

    from fastmcp import FastMCP

    from ..config import ConfigProfile
    from ..context import ServerContext

__all__ = ["BearerAuthMiddleware", "run_http"]

logger = logging.getLogger(__name__)


class BearerAuthMiddleware(BaseHTTPMiddleware):
    """Enforce Bearer token authentication on every HTTP request.

    When ``token`` is not ``None``, every incoming request must carry
    an ``Authorization: Bearer <token>`` header whose value matches
    exactly. Mismatches (including missing header) receive a 401
    JSON response.

    When ``token`` is ``None`` (no ``--auth-token`` configured), the
    middleware is a pass-through — all requests proceed without auth
    checks. In this scenario the caller (:func:`run_http`) is
    responsible for binding to ``127.0.0.1`` only (R20.4).
    """

    def __init__(self, app: "ASGIApp", token: str | None = None) -> None:
        super().__init__(app)
        self._token = token

    async def dispatch(self, request: Request, call_next):
        """Check the Authorization header if a token is configured."""
        if self._token:
            header = request.headers.get("authorization", "")
            if header != f"Bearer {self._token}":
                return JSONResponse(
                    {"error": "unauthorized"}, status_code=401
                )
        return await call_next(request)


def run_http(mcp: "FastMCP", ctx: "ServerContext") -> None:
    """Start the MCP server over streamable-HTTP with Uvicorn.

    Parameters
    ----------
    mcp:
        The fully-assembled :class:`FastMCP` instance with all tools,
        resources, and prompts registered.
    ctx:
        The :class:`ServerContext` providing access to the merged
        :class:`ConfigProfile` and shutdown coordination primitives.

    Notes
    -----
    * R20.4: If ``auth_token`` is not configured, the server is forced
      to bind to ``127.0.0.1`` regardless of the ``--host`` flag. This
      prevents accidental unauthenticated exposure on all interfaces.
    * R1.6: When ``auth_token`` is set, every request without a valid
      ``Authorization: Bearer <token>`` header receives a 401 response.
    * The Uvicorn ``log_level`` is derived from the config's
      ``log_level`` field (lowercased to match Uvicorn's expectations).
    """
    cfg: ConfigProfile = ctx.config

    # R20.4: force localhost binding when no auth token is configured
    host = cfg.host if cfg.auth_token else "127.0.0.1"

    app = mcp.streamable_http_app()
    app.add_middleware(BearerAuthMiddleware, token=cfg.auth_token)

    logger.info(
        "Starting MCP server on streamable-http transport at %s:%d",
        host,
        cfg.port,
    )

    uvicorn.run(app, host=host, port=cfg.port, log_level=cfg.log_level.lower())
