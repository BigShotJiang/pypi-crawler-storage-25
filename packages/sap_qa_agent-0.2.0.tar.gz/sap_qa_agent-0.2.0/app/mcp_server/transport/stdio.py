"""stdio transport adapter (design §9.2, R1.1, R1.7).

This module is intentionally minimal. The graceful-shutdown signal
handler is installed by :func:`app.mcp_server.cli._install_signal_handlers`
in Phase 1.7 — it sets ``ctx.shutdown_event``, waits for inflight tools
to drain, releases the channel lock, and exits. The ``fastmcp`` library
internally handles SIGINT propagation within its event loop, so the
transport layer's only job is to delegate to :meth:`FastMCP.run`.

Usage from ``cli.py``::

    from .transport.stdio import run_stdio
    run_stdio(mcp, ctx)
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from fastmcp import FastMCP

    from ..context import ServerContext

__all__ = ["run_stdio"]

logger = logging.getLogger(__name__)


def run_stdio(mcp: "FastMCP", ctx: "ServerContext") -> None:
    """Start the MCP server over stdio.

    Parameters
    ----------
    mcp:
        The fully-assembled :class:`FastMCP` instance with all tools,
        resources, and prompts registered.
    ctx:
        The :class:`ServerContext` — not directly used here but
        accepted so the call-site in ``cli.py`` has a uniform
        signature across transports. The signal handler (already
        installed before this function is called) references ``ctx``
        for shutdown coordination.

    Notes
    -----
    ``mcp.run(transport="stdio")`` blocks until stdin is closed or a
    signal is received. On SIGINT/SIGTERM the signal handler installed
    by ``cli._install_signal_handlers`` takes over, drains inflight
    tools, and calls ``sys.exit``.
    """
    logger.info("Starting MCP server on stdio transport")
    mcp.run(transport="stdio")
