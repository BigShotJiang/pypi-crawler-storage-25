"""Cross-process channel lock for SAP GUI COM session ownership.

Implements design §6 (SAP Session 冲突检测). Because SAP GUI Scripting
COM is a process-singleton that two independent processes can each
call ``GetObject("SAPGUI")`` on, we need an early-detection mechanism
before the second process reaches the actual COM operation. The lock
file at ``$ARTIFACTS_DIR/.sap-channel.lock`` acts as that gate.

Design-level notes:

* **Atomicity**: ``O_CREAT | O_EXCL`` on POSIX and :func:`msvcrt.locking`
  on Windows give us an atomic "create-or-fail" semantic. If two
  processes race the ``acquire`` call, exactly one wins.

* **Stale detection**: the lock payload carries the owner's PID and
  start time. If :func:`psutil.pid_exists` reports the owner is gone,
  we treat the lock as stale and overwrite — covering the "last run
  crashed without releasing" scenario.

* **Release paths**: :meth:`ChannelLock.release` is idempotent and is
  additionally invoked via :mod:`atexit`, so a normal Python exit path
  (``sys.exit``, uncaught exception) still clears the lock.

* **Scope**: this module only covers mutual exclusion on the SAP COM
  session. It is **not** a general-purpose file lock — callers must
  not store non-session state in the payload.

Requirements covered: R18.2, R18.3.
"""

from __future__ import annotations

import atexit
import contextlib
import json
import logging
import os
import socket
import sys
import threading
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Literal, Optional

__all__ = [
    "ChannelLock",
    "ChannelLockedError",
    "LockInfo",
]

logger = logging.getLogger(__name__)


ChannelName = Literal["mcp", "backend"]


# ---------------------------------------------------------------------------
# Lock payload
# ---------------------------------------------------------------------------


@dataclass
class LockInfo:
    """Metadata written into ``$ARTIFACTS_DIR/.sap-channel.lock``.

    Stays JSON-serialisable so the lock file is human-readable when an
    operator needs to investigate "who owns the session right now".
    """

    pid: int
    channel: str
    started_at: str
    host: str

    def to_json(self) -> str:
        return json.dumps(asdict(self), ensure_ascii=False)

    @classmethod
    def from_json(cls, raw: str) -> "LockInfo":
        data = json.loads(raw)
        return cls(
            pid=int(data["pid"]),
            channel=str(data["channel"]),
            started_at=str(data["started_at"]),
            host=str(data.get("host", "")),
        )


class ChannelLockedError(Exception):
    """Raised by :meth:`ChannelLock.acquire` when the session is taken.

    Carries the owner :class:`LockInfo` so callers can surface it in the
    ``SAP_SESSION_OWNED_BY_OTHER_CHANNEL`` error details (R18.3).
    """

    def __init__(self, owner: LockInfo) -> None:
        super().__init__(
            f"SAP channel already owned by {owner.channel} pid={owner.pid}"
        )
        self.owner = owner


# ---------------------------------------------------------------------------
# ChannelLock
# ---------------------------------------------------------------------------


LOCK_FILENAME = ".sap-channel.lock"


class ChannelLock:
    """File-based mutex for SAP COM session ownership.

    Not a singleton — :class:`~app.mcp_server.context.ServerContext`
    instantiates one; the FastAPI backend instantiates another. Both
    target the same path on disk, which is the whole point.

    The class is reentrant within a single process: calling
    :meth:`acquire` twice from the same thread returns the existing
    :class:`LockInfo` without touching the filesystem. This lets
    multiple call sites (e.g. the CLI at startup + the first
    ``sap_connect`` tool call) guard themselves defensively.
    """

    def __init__(self, artifacts_dir: str | os.PathLike[str]) -> None:
        self._path = Path(artifacts_dir) / LOCK_FILENAME
        self._owned: Optional[LockInfo] = None
        self._lock = threading.Lock()
        self._atexit_registered = False

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    @property
    def path(self) -> Path:
        """Absolute path of the lock file (useful for tests/logging)."""
        return self._path

    def is_owned(self) -> bool:
        """True if this instance currently holds the lock."""
        return self._owned is not None

    def acquire(self, channel: ChannelName | str) -> LockInfo:
        """Acquire the lock for ``channel``.

        Parameters
        ----------
        channel:
            ``"mcp"`` or ``"backend"`` (design §6.3). Any string is
            accepted but the two documented values are the only ones
            used in-tree.

        Returns
        -------
        LockInfo
            The payload that was written.

        Raises
        ------
        ChannelLockedError
            When a live process already holds the lock. The error's
            :attr:`~ChannelLockedError.owner` attribute carries the
            other party's :class:`LockInfo` so the caller can build
            ``SAP_SESSION_OWNED_BY_OTHER_CHANNEL`` details.
        """
        with self._lock:
            if self._owned is not None:
                # Re-entrant acquisition — same channel or not,
                # treat as a no-op so optional safety calls are cheap.
                return self._owned

            self._path.parent.mkdir(parents=True, exist_ok=True)

            info = LockInfo(
                pid=os.getpid(),
                channel=channel,
                started_at=datetime.now().isoformat(timespec="seconds"),
                host=socket.gethostname(),
            )

            # Try to create exclusively. On conflict, inspect the
            # existing owner; stale → overwrite, live → raise.
            try:
                self._write_exclusive(info)
            except FileExistsError:
                existing = self._read_existing()
                if existing is not None and _pid_alive(existing.pid):
                    raise ChannelLockedError(existing) from None
                # Stale (or unreadable): replace it.
                logger.info(
                    "Replacing stale channel lock (previous owner: %s)",
                    existing,
                )
                self._write_over(info)

            self._owned = info
            self._register_atexit()
            return info

    def release(self) -> None:
        """Release the lock if this process holds it. Idempotent.

        Safe to call from :mod:`atexit` — the internal state flag
        suppresses duplicate unlink attempts and any IO error is
        logged rather than raised because shutdown is the wrong time
        to complain.
        """
        with self._lock:
            if self._owned is None:
                return
            try:
                self._path.unlink()
            except FileNotFoundError:
                # Another shutdown path already deleted it.
                pass
            except OSError as exc:
                logger.warning(
                    "Failed to delete channel lock %s: %s",
                    self._path,
                    exc,
                )
            finally:
                self._owned = None

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _write_exclusive(self, info: LockInfo) -> None:
        """Atomic create-or-fail write of the lock payload."""
        flags = os.O_CREAT | os.O_EXCL | os.O_WRONLY
        if hasattr(os, "O_CLOEXEC"):  # POSIX
            flags |= os.O_CLOEXEC
        fd = os.open(str(self._path), flags, 0o644)
        try:
            # On Windows, additionally take an advisory region lock so
            # that an in-between reader sees either the full payload
            # or nothing. ``msvcrt.locking`` is unavailable on POSIX.
            if sys.platform == "win32":  # pragma: no cover - platform-specific
                with contextlib.suppress(OSError):
                    import msvcrt  # type: ignore[import-not-found]

                    msvcrt.locking(fd, msvcrt.LK_NBLCK, 1)
            os.write(fd, info.to_json().encode("utf-8"))
        finally:
            os.close(fd)

    def _write_over(self, info: LockInfo) -> None:
        """Overwrite an existing stale lock file."""
        self._path.write_text(info.to_json(), encoding="utf-8")

    def _read_existing(self) -> Optional[LockInfo]:
        """Best-effort read of the current lock payload.

        Returns ``None`` on missing file or parse error so the caller
        can decide whether to treat the situation as stale.
        """
        try:
            raw = self._path.read_text(encoding="utf-8")
        except FileNotFoundError:
            return None
        except OSError as exc:
            logger.debug("Could not read channel lock %s: %s", self._path, exc)
            return None
        try:
            return LockInfo.from_json(raw)
        except (json.JSONDecodeError, KeyError, ValueError) as exc:
            logger.warning(
                "Channel lock %s is malformed (%s); treating as stale",
                self._path,
                exc,
            )
            return None

    def _register_atexit(self) -> None:
        """Register a single ``atexit`` callback per instance."""
        if self._atexit_registered:
            return
        atexit.register(self.release)
        self._atexit_registered = True


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _pid_alive(pid: int) -> bool:
    """Return True if ``pid`` still refers to a running process.

    Uses :func:`psutil.pid_exists` when available (the project already
    depends on psutil for other modules). On the rare host where
    psutil isn't importable we fall back to ``os.kill(pid, 0)`` which
    is reliable on POSIX and a reasonable best-effort on Windows.
    """
    try:
        import psutil  # type: ignore[import-not-found]
    except ImportError:
        return _pid_alive_fallback(pid)

    try:
        return bool(psutil.pid_exists(pid))
    except Exception as exc:  # noqa: BLE001 - psutil can raise on exotic hosts
        logger.debug("psutil.pid_exists(%d) raised %s; using fallback", pid, exc)
        return _pid_alive_fallback(pid)


def _pid_alive_fallback(pid: int) -> bool:
    """psutil-free liveness check."""
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        # Process exists but we can't signal it (different user).
        return True
    except OSError:
        # On Windows, ``os.kill(pid, 0)`` may raise with an opaque
        # errno; be conservative and assume the process is alive so
        # we don't clobber a lock held by another user.
        return True
    return True
