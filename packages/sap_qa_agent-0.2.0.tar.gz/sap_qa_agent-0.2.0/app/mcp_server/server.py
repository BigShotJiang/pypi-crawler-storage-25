"""FastMCP server assembly for SAP QA Agent (design §2.2 / §2.3).

This module wires the three pieces the MCP protocol requires into a
single :class:`fastmcp.FastMCP` instance:

* **Tools** (`tools/*.py`)       — invocable actions (parse, execute, …).
* **Resources** (`resources.py`) — read-only URIs (`sap-qa://…`).
* **Prompts** (`prompts.py`)     — ``skill:{id}`` prompt templates.

The single public entry point is :func:`build_mcp`, consumed by the
CLI (Task 1.7) and by the ``tmp_mcp_server`` pytest fixture in
``tests/mcp/conftest.py``. Construction is idempotent and does **not**
start any transport — the caller chooses between ``mcp.run(transport=
"stdio")`` and the streamable-http wiring that Task 8.2 will add.

Phase-1 reality check
---------------------

When this file first lands, only Phase 1 modules exist. The
per-category tool modules, :mod:`app.mcp_server.resources` and
:mod:`app.mcp_server.prompts` arrive in Phase 4–7. Each registration
helper therefore wraps its import in ``try`` / ``ImportError`` so
that:

* the contract tests in Task 1.8 can bring up a fully functional but
  empty server (``tools=[]`` is explicitly accepted by R21.4);
* no code change is required here when those modules finally land —
  they are picked up automatically on the next :func:`build_mcp` call.

Capabilities in the ``initialize`` handshake (R1.3) come from
:class:`fastmcp.FastMCP` itself: it always constructs managers for
tools, resources and prompts, so all three capability kinds are
advertised regardless of whether any handlers are registered.

FastMCP version tolerance
-------------------------

Different ``fastmcp`` releases accept slightly different constructor
kwargs (some expose ``version``, others only ``name`` + ``instructions``).
:func:`_construct_fastmcp` tries the most informative form first and
falls back progressively so the server still starts on a release
where a kwarg was renamed. The server name is always
``cfg.server_name`` (``"sap-qa-agent"`` per design §3.1) and the
version is always ``cfg.server_version``.
"""

from __future__ import annotations

import importlib
import logging
from typing import TYPE_CHECKING

from fastmcp import FastMCP

from .context import ServerContext

if TYPE_CHECKING:  # pragma: no cover - imported for type checking only
    from .config import ConfigProfile  # noqa: F401

__all__ = ["build_mcp", "register_all"]

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Tool module registry
#
# Listed in the order Phase 4–7 bring them online. ``build_mcp`` attempts
# to import each one; anything not yet present is logged at DEBUG and
# silently skipped (see :func:`_register_tool_modules`). The bare module
# names are resolved under the ``app.mcp_server.tools`` package.
# ---------------------------------------------------------------------------

_TOOL_MODULES: tuple[str, ...] = (
    # Phase 4 — filesystem / knowledge-base tools (no SAP dependency)
    "skills",
    "knowledge",
    "parse",
    # Phase 6 — SAP session-dependent tools
    "session",
    "execution",
    "tasks",
    "capture",
    # Phase 7 — conditional tools
    "atomic",
    "recording",
)


# ---------------------------------------------------------------------------
# Public entry points
# ---------------------------------------------------------------------------


def build_mcp(ctx: ServerContext) -> FastMCP:
    """Construct and fully wire a :class:`FastMCP` instance.

    Returns an instance whose ``initialize`` handshake advertises
    ``server_info.name == cfg.server_name`` (``"sap-qa-agent"`` by
    default), ``server_info.version == cfg.server_version``, and
    ``capabilities`` spanning tools / resources / prompts (R1.3). No
    transport is started — the caller chooses between the stdio and
    streamable-http adapters in Task 8.1 / 8.2.

    Parameters
    ----------
    ctx:
        Process-wide :class:`ServerContext`. Passed to every
        registration helper so tools close over the shared task
        store, SAP wrapper, metrics, etc.
    """
    cfg = ctx.config
    mcp = _construct_fastmcp(cfg.server_name, cfg.server_version)
    register_all(mcp, ctx)
    return mcp


def register_all(mcp: FastMCP, ctx: ServerContext) -> None:
    """Register every tool / resource / prompt module against *mcp*.

    Called by :func:`build_mcp` and by integration tests that want to
    re-register against an externally-constructed :class:`FastMCP`.
    Each category is registered independently so that a failure in
    one branch doesn't prevent the others from coming up — important
    during incremental phase delivery.

    In Phase 1 all real registrars are absent and this is effectively
    a no-op; Phase 4+ drops real ``register(mcp, ctx)`` entry points
    into the ``tools/`` / ``resources`` / ``prompts`` modules and they
    get picked up automatically.
    """
    _register_tool_modules(mcp, ctx)
    _register_module(mcp, ctx, "app.mcp_server.resources", "resources")
    _register_module(mcp, ctx, "app.mcp_server.prompts", "prompts")


# ---------------------------------------------------------------------------
# FastMCP construction
# ---------------------------------------------------------------------------


def _construct_fastmcp(name: str, version: str) -> FastMCP:
    """Instantiate :class:`FastMCP` with the best-match kwargs.

    ``fastmcp`` went through minor-version churn around the
    constructor signature. We try the richest form (``name`` +
    ``version``) first; if the installed release doesn't accept
    ``version`` we fall back to ``name`` alone. Any other
    ``TypeError`` is re-raised because it signals a real API
    mismatch the caller needs to see.
    """
    try:
        return FastMCP(name=name, version=version)
    except TypeError as exc:
        # Only swallow the specific "unexpected keyword argument
        # 'version'" shape; anything else is a genuine contract
        # violation and should propagate.
        if "version" not in str(exc):
            raise
        logger.debug(
            "FastMCP does not accept 'version' kwarg (%s); "
            "falling back to name-only constructor",
            exc,
        )
    return FastMCP(name=name)


# ---------------------------------------------------------------------------
# Internal registration helpers
# ---------------------------------------------------------------------------


def _register_tool_modules(mcp: FastMCP, ctx: ServerContext) -> None:
    """Import each ``app.mcp_server.tools.<name>`` and call ``register``.

    The registration convention for per-category tool modules (see
    design §2.3) is a module-level ``register(mcp, ctx)`` function.
    Any module that raises :class:`ImportError` is treated as "not
    yet implemented" and logged at DEBUG. Other exceptions from a
    concrete ``register`` are logged at WARNING so Phase-4+ bugs are
    visible without breaking the rest of the server.
    """
    for mod_name in _TOOL_MODULES:
        fq_name = f"app.mcp_server.tools.{mod_name}"
        _register_module(mcp, ctx, fq_name, mod_name)


def _register_module(
    mcp: FastMCP,
    ctx: ServerContext,
    fq_name: str,
    short_name: str,
) -> None:
    """Import *fq_name* and invoke its ``register(mcp, ctx)``.

    Shared helper for tool / resource / prompt modules. Silent on
    :class:`ImportError` (the module simply hasn't been written yet),
    verbose on any other failure so integration bugs surface loudly
    without bringing down the whole server.
    """
    try:
        module = importlib.import_module(fq_name)
    except ImportError as exc:
        logger.debug(
            "module %s not available yet: %s", fq_name, exc
        )
        return

    register = getattr(module, "register", None)
    if not callable(register):
        logger.debug(
            "module %s has no register(mcp, ctx); skipped", fq_name
        )
        return

    try:
        register(mcp, ctx)
    except Exception as exc:  # noqa: BLE001 - one bad module must not kill the server
        logger.warning(
            "module %s register() failed: %s", fq_name, exc
        )
