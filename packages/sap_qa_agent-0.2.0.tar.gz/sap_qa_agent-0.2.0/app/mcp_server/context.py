"""Process-wide dependency container for the MCP server.

Implements design §2.2 / §2.3: ``ServerContext`` is the single
dependency-injection hub consumed by every Tool. It owns the long-lived
core objects (config, task store, SAP wrapper, knowledge base, GLM
client, screen recorder, metrics, channel lock) so that Tools don't
instantiate them themselves and so that a SIGINT/SIGTERM can cleanly
close them.

Key design decisions:

* **Lazy instantiation** for every module that imports heavy optional
  dependencies (``SapGuiWrapper`` → ``pywin32``, ``GlmClient`` →
  ``zhipuai``, ``ScreenRecorder`` → ``ffmpeg``). This keeps
  ``initialize`` / ``tools/list`` responsive even when SAP GUI isn't
  installed, and lets unit tests import the context module on non-
  Windows hosts without touching COM.

* **Single SAP wrapper per stdio connection** (R3.6): once
  :attr:`sap_wrapper` is first touched, the same instance is reused
  for the entire server lifetime.

* **Graceful degradation** when Phase-later modules aren't yet wired
  in: :attr:`metrics` and :attr:`channel_lock` fall back to no-op
  stubs if their real implementations aren't importable. This lets
  Phase 1 Tools run before Phase 2.2 / 9.2 land.

* **Testability**: every lazy handle exposes a setter so tests can
  inject a mock without monkey-patching private attributes.

The ``shutdown()`` method is signalled by the CLI signal handler
(Task 1.7) once inflight tools have drained; it releases COM and the
channel lock and is safe to call multiple times.
"""

from __future__ import annotations

import logging
import threading
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Optional

from .config import ConfigProfile

__all__ = ["RecorderState", "ServerContext"]

logger = logging.getLogger(__name__)


@dataclass
class RecorderState:
    """Tracks the active recording session for streamable-http transport.

    Only one recording is allowed at a time (R10.3). ``active_id`` is
    ``None`` when no recording is in progress; otherwise it holds the
    12-hex recording id returned by ``start_recording``. ``started_at``
    is a timezone-naive :class:`datetime` matching the rest of the
    codebase's logging timestamps.
    """

    active_id: Optional[str] = None
    started_at: Optional[datetime] = None


# ---------------------------------------------------------------------------
# Graceful-degradation stubs for modules that aren't yet implemented.
# These let Phase 1 Tools run before Phase 2.2 (channel_lock) and
# Phase 9.2 (metrics) land. Both stubs expose the minimum surface the
# rest of the code paths touch; real implementations will replace them
# transparently because the lazy accessors re-import on first access.
# ---------------------------------------------------------------------------


class _MetricsStub:
    """No-op metrics until Phase 9.2 wires :class:`Metrics`."""

    def record(self, tool: str, elapsed_s: float, ok: bool) -> None:
        return None

    def snapshot(self) -> dict[str, Any]:
        return {}


class _ChannelLockStub:
    """No-op channel lock until Phase 2.2 wires :class:`ChannelLock`."""

    def acquire(self, channel: str) -> Any:
        return None

    def release(self) -> None:
        return None


# ---------------------------------------------------------------------------
# ServerContext
# ---------------------------------------------------------------------------


class ServerContext:
    """Dependency container shared by every MCP Tool.

    Construction is cheap: only the config, in-memory task store, the
    recorder state dataclass and two threading events are created
    eagerly. Every other handle is materialised on first access so
    that importing this module on a machine without SAP GUI, ffmpeg
    or a GLM key still works for unit tests and ``--help``.
    """

    def __init__(self, config: ConfigProfile) -> None:
        # Eager, cheap state --------------------------------------------------
        self.config = config

        # The task store is always live so that ``list_tasks`` works
        # immediately even before any execution has started. It is
        # per-process and not shared with the FastAPI backend (R18.7).
        from ..task_store import InMemoryTaskStore

        self.task_store = InMemoryTaskStore()
        self.recorder_state = RecorderState()

        # ``shutdown_event`` is set by the CLI signal handler
        # (Task 1.7). ``tool_inflight`` is set when there are no tools
        # currently executing; middleware clears it while at least one
        # tool is running so the signal handler can wait for drain.
        self.shutdown_event = threading.Event()
        self.tool_inflight = threading.Event()
        self.tool_inflight.set()  # starts in "no inflight tools" state
        self._inflight_count = 0
        self._inflight_lock = threading.Lock()

        # Lazy handles -------------------------------------------------------
        # ``None`` means "not yet constructed". Setters allow tests to
        # inject mocks before first access without triggering import of
        # the real module (which would require pywin32, zhipuai, etc.).
        self._sap_wrapper: Optional[Any] = None
        self._sap_executor: Optional[Any] = None
        self._kb: Optional[Any] = None
        self._glm_client: Optional[Any] = None
        self._screen_recorder: Optional[Any] = None
        self._metrics: Optional[Any] = None
        self._channel_lock: Optional[Any] = None

    # ------------------------------------------------------------------
    # Lazy accessors
    # ------------------------------------------------------------------

    @property
    def sap_wrapper(self) -> Any:
        """Return the shared :class:`SapGuiWrapper` instance (R3.6).

        Instantiated on first access and reused for the lifetime of
        the server process so that every Tool drives the same COM
        session (see design §4.2 and R3.6).
        """
        if self._sap_wrapper is None:
            from ..sap.sap_gui_wrapper import SapGuiWrapper

            self._sap_wrapper = SapGuiWrapper()
        return self._sap_wrapper

    @sap_wrapper.setter
    def sap_wrapper(self, value: Any) -> None:
        self._sap_wrapper = value

    @property
    def sap_executor(self) -> Any:
        """Return the shared :class:`ScriptExecutor` instance.

        Instantiated on first access using the shared ``sap_wrapper``
        and ``glm_client``. Used by ``capture_screen`` (design §4.7)
        and ``execute_test_case`` (design §4.3) for screen state
        collection and step execution.
        """
        if self._sap_executor is None:
            from ..sap.script_executor import ScriptExecutor

            self._sap_executor = ScriptExecutor(
                sap_wrapper=self.sap_wrapper,
                vlm_fallback=None,
                element_finder=None,
                glm_client=self._glm_client,
            )
        return self._sap_executor

    @sap_executor.setter
    def sap_executor(self, value: Any) -> None:
        self._sap_executor = value

    @property
    def kb(self) -> Any:
        """Return the shared :class:`KnowledgeBase` instance."""
        if self._kb is None:
            from ..data.knowledge_base import KnowledgeBase

            self._kb = KnowledgeBase(self.config.knowledge_base_dir)
        return self._kb

    @kb.setter
    def kb(self, value: Any) -> None:
        self._kb = value

    @property
    def glm_client(self) -> Any:
        """Return the shared :class:`GlmClient` instance.

        ``GlmClient.__init__`` reads ``GLM_API_KEY`` from
        :mod:`app.config` at import time; the config-level enforcement
        (R19.4: auto-disable self-healing when the key is missing)
        lives in the execution Tool, not here.
        """
        if self._glm_client is None:
            from ..ai.glm_client import GlmClient

            self._glm_client = GlmClient()
        return self._glm_client

    @glm_client.setter
    def glm_client(self, value: Any) -> None:
        self._glm_client = value

    @property
    def screen_recorder(self) -> Any:
        """Return the shared :class:`ScreenRecorder` instance."""
        if self._screen_recorder is None:
            from ..recorder import ScreenRecorder

            self._screen_recorder = ScreenRecorder()
        return self._screen_recorder

    @screen_recorder.setter
    def screen_recorder(self, value: Any) -> None:
        self._screen_recorder = value

    @property
    def metrics(self) -> Any:
        """Return the shared metrics collector.

        Falls back to a :class:`_MetricsStub` when
        :mod:`app.mcp_server.metrics` isn't yet implemented (Phase 9.2).
        This lets Phase 1 middleware call ``metrics.record(...)``
        unconditionally.
        """
        if self._metrics is None:
            try:
                from .metrics import Metrics  # type: ignore[import-not-found]

                self._metrics = Metrics()
            except ImportError:
                logger.debug(
                    "mcp_server.metrics not available yet; using stub"
                )
                self._metrics = _MetricsStub()
        return self._metrics

    @metrics.setter
    def metrics(self, value: Any) -> None:
        self._metrics = value

    @property
    def channel_lock(self) -> Any:
        """Return the shared channel lock.

        Falls back to a :class:`_ChannelLockStub` when
        :mod:`app.mcp_server.channel_lock` isn't yet implemented
        (Phase 2.2). Real acquisition/release semantics arrive in
        Task 2.2.
        """
        if self._channel_lock is None:
            try:
                from .channel_lock import ChannelLock  # type: ignore[import-not-found]

                self._channel_lock = ChannelLock(self.config.artifacts_dir)
            except ImportError:
                logger.debug(
                    "mcp_server.channel_lock not available yet; using stub"
                )
                self._channel_lock = _ChannelLockStub()
        return self._channel_lock

    @channel_lock.setter
    def channel_lock(self, value: Any) -> None:
        self._channel_lock = value

    # ------------------------------------------------------------------
    # Inflight tracking (consumed by middleware / signal handler)
    # ------------------------------------------------------------------

    def mark_tool_start(self) -> None:
        """Signal that a Tool invocation has begun.

        The CLI signal handler (Task 1.7) calls
        ``ctx.tool_inflight.wait(timeout=10)`` after setting
        ``shutdown_event`` so that running Tools drain before exit.
        Clearing on the first start (count 1) and setting again at
        count 0 keeps the event semantics "set ⇔ no inflight work".
        """
        with self._inflight_lock:
            self._inflight_count += 1
            if self._inflight_count == 1:
                self.tool_inflight.clear()

    def mark_tool_end(self) -> None:
        """Signal that a Tool invocation has finished."""
        with self._inflight_lock:
            self._inflight_count = max(0, self._inflight_count - 1)
            if self._inflight_count == 0:
                self.tool_inflight.set()

    # ------------------------------------------------------------------
    # Shutdown
    # ------------------------------------------------------------------

    def shutdown(self) -> None:
        """Release COM and the channel lock. Idempotent.

        Called by the CLI signal handler once ``tool_inflight`` has
        drained (or the 10 s grace window expired). Each release step
        is wrapped in its own ``try`` so that a failure in one branch
        doesn't block the other — at shutdown time best-effort cleanup
        is preferable to re-raising.
        """
        self.shutdown_event.set()

        # Release SAP COM. ``SapGuiWrapper`` exposes ``disconnect``
        # when present; guard with getattr so tests that inject a bare
        # Mock don't crash here.
        if self._sap_wrapper is not None:
            try:
                disconnect = getattr(self._sap_wrapper, "disconnect", None)
                if callable(disconnect):
                    disconnect()
            except Exception as exc:  # noqa: BLE001 - best-effort cleanup
                logger.warning("SAP disconnect during shutdown failed: %s", exc)

        # Release the channel lock so the FastAPI backend (if any) can
        # take over the SAP session after this process exits.
        if self._channel_lock is not None:
            try:
                release = getattr(self._channel_lock, "release", None)
                if callable(release):
                    release()
            except Exception as exc:  # noqa: BLE001 - best-effort cleanup
                logger.warning(
                    "channel_lock release during shutdown failed: %s", exc
                )
