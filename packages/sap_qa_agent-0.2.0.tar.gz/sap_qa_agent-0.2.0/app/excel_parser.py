"""Excel 解析器 - 读取并解析 Excel 文件中的步骤内容"""

import pandas as pd

from .models import StepInfo


# Excel 列名常量
COL_STEP_INDEX = "步骤序号"
COL_STEP_DESC = "步骤描述"
REQUIRED_COLUMNS = {COL_STEP_INDEX, COL_STEP_DESC}


class ExcelParseError(Exception):
    """Excel 解析错误基类"""


class InvalidFormatError(ExcelParseError):
    """文件损坏或格式无法解析"""

    def __init__(self, message: str = "不支持的文件格式，请上传 Excel 文件"):
        super().__init__(message)


class MissingColumnsError(ExcelParseError):
    """缺少必填列"""

    def __init__(self, missing: set[str]):
        self.missing = missing
        super().__init__(f"Excel 缺少必填列: {', '.join(sorted(missing))}")


class EmptyDataError(ExcelParseError):
    """没有有效步骤数据"""

    def __init__(self, message: str = "Excel 中未找到有效步骤"):
        super().__init__(message)


class ExcelParser:
    """Excel 文件解析器。

    解析 Excel 文件，提取步骤信息。
    期望 Excel 格式：
    - 列 A: 步骤序号（整数）
    - 列 B: 步骤描述（文本）
    - 第一行为表头，从第二行开始读取数据
    """

    def parse(self, file_path: str) -> list[StepInfo]:
        """解析 Excel 文件，返回按步骤序号排序的步骤列表。

        Args:
            file_path: Excel 文件路径。

        Returns:
            按 index 升序排列的 StepInfo 列表。

        Raises:
            InvalidFormatError: 文件损坏或无法解析。
            MissingColumnsError: 缺少必填列。
            EmptyDataError: 没有有效步骤数据。
        """
        df = self._read_excel(file_path)
        self._validate_columns(df)
        df = self._clean_data(df)

        if df.empty:
            raise EmptyDataError()

        return self._to_step_list(df)

    def _read_excel(self, file_path: str) -> pd.DataFrame:
        """读取 Excel 文件，处理文件损坏场景。"""
        try:
            return pd.read_excel(file_path)
        except Exception:
            raise InvalidFormatError()

    def _validate_columns(self, df: pd.DataFrame) -> None:
        """校验必填列是否存在。"""
        columns = set(df.columns.astype(str))
        missing = REQUIRED_COLUMNS - columns
        if missing:
            raise MissingColumnsError(missing)

    def _clean_data(self, df: pd.DataFrame) -> pd.DataFrame:
        """过滤空行并清洗数据。"""
        # 仅保留必填列都非空的行
        df = df.dropna(subset=[COL_STEP_INDEX, COL_STEP_DESC])
        # 过滤描述为空字符串的行
        df = df[df[COL_STEP_DESC].astype(str).str.strip().astype(bool)]
        return df

    def _to_step_list(self, df: pd.DataFrame) -> list[StepInfo]:
        """将 DataFrame 转换为按序号排序的 StepInfo 列表。"""
        steps: list[StepInfo] = []
        for _, row in df.iterrows():
            index_val = int(row[COL_STEP_INDEX])
            desc_val = str(row[COL_STEP_DESC]).strip()
            steps.append(StepInfo(index=index_val, description=desc_val))

        steps.sort(key=lambda s: s.index)
        return steps
