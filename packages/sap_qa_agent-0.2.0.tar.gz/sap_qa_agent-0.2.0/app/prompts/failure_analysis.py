"""失败根因分析 Prompt 模板"""

FAILURE_ANALYSIS_PROMPT = """你是一个 SAP 测试分析专家。请分析以下测试步骤失败的根本原因，用自然语言给出简洁的分析报告。

失败步骤：{step_description}
错误信息：{error_message}
状态栏消息：{status_bar_message}
截图描述：{screenshot_description}

请用中文输出 2-3 句话的分析报告，包含：
1. 失败的直接原因
2. 可能的根本原因
3. 建议的修复方向"""
