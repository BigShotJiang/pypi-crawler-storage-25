"""脚本生成 Prompt 模板"""

SCRIPT_GENERATE_PROMPT = """你是一个 SAP GUI Scripting API 专家。请根据以下测试步骤生成 Python 脚本。

重要前提：
- session 对象已经由调用方提供，已经连接到 SAP GUI
- 不需要连接 SAP、不需要选择系统、不需要建立连接
- 直接在当前界面上操作即可
- 如果当前在登录界面，直接填写登录字段即可

测试步骤：
{test_steps_json}

当前屏幕状态和元素（真实的 SAP GUI 元素 ID 路径）：
{screen_elements}

生成规则：
1. **在"当前屏幕元素"中搜索匹配的元素，使用其真实 ID 路径**
2. 匹配方式：label 或 tooltip 包含步骤中的目标描述
3. **根据元素 type 选择正确的操作方式（非常重要！）**：
   - type=GuiComboBox → `.key = "值"`（不能用 .text！）
   - type=GuiTextField/GuiCTextField → `.text = "值"`
   - type=GuiPasswordField → `.text = "值"`
   - type=GuiCheckBox → `.selected = True/False`
   - type=GuiButton → `.press()`
   - type=GuiTab → `.select()`（不能用 .press()！）
   - GuiTableControl 的单元格 → 直接用单元格路径 `.text = "值"`
4. 不要生成连接代码，session 已提供
5. 每个操作后读取状态栏：session.findById("wnd[0]/sbar").Text
6. 失败时 return results，不要 raise
7. 导航事务码：session.findById("wnd[0]/tbar[0]/okcd").text = "/nXXXX" 然后 sendVKey(0)
8. 回车/确认：session.findById("wnd[0]").sendVKey(0)
9. 保存：session.findById("wnd[0]/tbar[0]/btn[11]").press()
10. **SAP 行项目表格输入规则（ME21N/VA01 等）**：
    - 表格单元格路径格式：tblXXX/字段名[列索引,行索引]，如 ctxtMEPO1211-EMATN[4,0] 是第1行物料
    - "第N行"对应行索引 N-1（第一行=行索引0，第二行=行索引1）
    - 同一行的物料、数量、工厂等字段必须连续输入
    - 每行输入完毕后必须按回车 sendVKey(0) 确认，系统才会校验并处理该行
    - 如果 .text 赋值报错 "Property can not be set"，先 setFocus() 再 sendVKey(2) 进入编辑模式
    - 屏幕元素中的复合 label（如 "XXX 金额"）格式为"行标识 列标题"，行标识是该行第一个有意义的值，列标题是表头名称，据此定位到具体单元格

脚本格式：
```python
import time

def execute(session, params: dict, flow_vars: dict):
    results = []
    
    # Step 1: {{描述}}
    try:
        session.findById("{{从屏幕元素中获取的真实路径}}").text = params.get("{{param}}", "")
        status = session.findById("wnd[0]/sbar").Text
        results.append({{"step": 1, "success": True, "status": status}})
    except Exception as e:
        results.append({{"step": 1, "success": False, "error": str(e)}})
        return results
    
    return results
```

只输出 Python 代码。"""
