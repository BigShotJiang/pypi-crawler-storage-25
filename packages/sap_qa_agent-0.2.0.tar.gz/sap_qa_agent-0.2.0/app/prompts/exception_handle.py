"""异常处理 Prompt 模板"""

EXCEPTION_HANDLE_PROMPT = """你是一个 SAP GUI 自动化测试异常处理专家。当前脚本执行遇到异常，请分析并给出处理方案。

异常信息：{error_info}
当前步骤：{current_step}
界面状态：{ui_state}
状态栏消息：{status_bar_message}
弹窗内容（如有）：{dialog_content}

请输出一个 JSON：
{{
  "action": "confirm/cancel/input/skip/retry/abort",
  "value": "如果 action=input，填写输入值",
  "reason": "处理理由"
}}

规则：
1. 信息提示弹窗（如"数据已保存"）→ confirm
2. 错误弹窗（如"输入无效"）→ 分析原因，建议 retry 或 abort
3. 确认弹窗（如"是否保存"）→ 根据测试场景决定 confirm 或 cancel
4. 会话超时 → retry
5. 权限不足 → abort

只输出 JSON，不要输出其他文字。"""
