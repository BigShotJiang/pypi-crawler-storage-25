"""步骤拆分 Prompt 模板"""

STEP_SPLIT_PROMPT = """你是一个 SAP GUI 自动化测试专家，拥有丰富的 SAP 用户操作经验。请将以下测试用例的操作步骤拆分为结构化的测试步骤列表。

测试用例：
- 事务代码：{transaction_code}
- 操作步骤：{steps_text}
- 测试数据：{test_data}

请输出 JSON 数组，每个步骤包含：
- index: 步骤序号（从1开始）
- action_type: 操作类型（input/click/double_click/select/verify/navigate/wait/read）
- target_description: 目标字段的业务描述（如"客户端"、"用户"、"密码"、"订单类型"）
- value: 输入值（必须使用测试数据中的真实值）
- flow_variable_ref: 如果值引用了流程变量，填写变量名
- row: 行号（仅表格操作需要，从1开始，如"第一行"=1，非表格操作不输出此字段）
- column: 列名（仅表格操作需要，如"物料"、"数量"、"工厂"，非表格操作不输出此字段）

关键规则（必须严格遵守）：

1. 步骤顺序：如果包含登录操作，必须先登录再做其他操作
   正确顺序：登录字段输入 → 回车 → 等待 → 事务码导航 → 业务操作
   错误顺序：事务码导航 → 登录（❌ 这是错的！）

2. 登录步骤（SAP 领域知识）：
   - SAP 登录界面有4个字段，按此顺序输入：客户端、用户、密码、语言
   - 客户端默认值是 100（不是 001！）
   - 语言默认值是 ZH（中文，不是 EN！）
   - 登录是按回车键：action_type=click，target_description="回车"
   - SAP 没有"登录按钮"，登录就是按回车
   - 登录后必须加 wait 步骤等待系统响应

3. 事务码导航：
   - action_type=navigate，target_description="命令输入框"，value="/n{{事务码}}"
   - navigate 执行时会自动按回车提交事务码，不要在导航后额外添加回车步骤

4. value 取值规则：
   - 必须从"测试数据"和"操作步骤"中提取真实值
   - 不要用描述性文字（如"登录密码"、"输入密码"）作为 value
   - 如果操作步骤中写了具体值（如"ZHOUXINYIN"、"Ssrw2102!!"），直接使用

5. 跳过以下步骤（不要生成）：
   - 打开 SAP GUI / SAP Logon
   - 选择系统 / 双击系统条目（仅限 SAP Logon 登录界面的系统选择）
   这些由系统自动处理
   ⚠️ 注意：业务操作中的"双击"不能跳过！例如"双击行项目进入详情"、"双击单元格编辑"等必须生成步骤。
   ⚠️ 注意："系统自动带出/显示XX"属于预期结果描述，不是操作步骤，不要生成。

6. 验证步骤：
   - action_type=verify，value 填写期望在屏幕上看到的文字

7. 执行/F8 按钮：
   - action_type=click，target_description="执行"

8. 读取/获取数据步骤：
   - "获取数据"、"读取数据"、"获取清单数据"、"导出数据"等 → action_type=read，target_description 描述要获取的内容
   - read 类型会从当前屏幕的表格/清单中读取所有行数据并记录

9. 双击操作（double_click）：
   - 当测试用例提到"双击行项目"、"双击单元格"、"双击某行进入详情"等操作时，必须生成 double_click 步骤
   - action_type=double_click，target_description 描述双击的目标（如"第一行项目"、"第二行项目"）
   - double_click 后通常需要加 wait 步骤等待页面跳转
   - ⚠️ 双击行项目进入详情是业务操作，绝对不能跳过！

10. ⭐ 复合句拆分规则（最重要！）：
    测试用例经常在一句话中包含多个操作，必须逐个拆分为独立步骤：

    a) 逗号分隔的多个"输入"→ 每个输入单独一步：
       "输入订单类型：OR1，销售组织：ZY11，分销渠道：01"
       → input(订单类型, OR1) + input(销售组织, ZY11) + input(分销渠道, 01)

    b) "输入A：X，B：Y"模式（无动词重复）→ 每个字段单独一步：
       "销售组织：ZY11, 分销渠道：01，产品组：01"
       → input(销售组织, ZY11) + input(分销渠道, 01) + input(产品组, 01)

    c) "XX，然后/并 YY" → 两个独立操作步骤

    d) "XX进入YY页面" → XX操作 + wait 等待页面变化：
       "回车进入到下一页面" → click(回车) + wait(等待页面加载)
       "双击该行项目进入详情" → double_click(该行项目) + wait(等待详情页)

    e) "保存XX，记录/生成XX号" → click(保存) + verify(订单号)：
       "保存销售订单，记录生成订单号码" → click(保存) + verify(订单号码生成)

    f) "到/去 条件页签 修改/输入XX" → 切页签 + 输入值：
       "到条件页签修改PB00价格为20" → click(条件页签) + input(PB00条件类型价格, 20)
       "点击条件页签，输入条件类型：PR00, 输入金额：100" → click(条件页签) + input(PR00条件类型价格, 100)

    g) "回退到上一页面" / "返回" → click(返回) + wait：
       "回退到上一页面" → click(返回) + wait(等待返回)

    h) 一句话中既有导航又有输入 → 先导航再输入：
       "回车进入到下一页面,输入售达方：400169" → click(回车) + wait(等待页面加载) + input(售达方, 400169)

    i) "进入行项目数据" → 这是描述性文字，不是操作。如果后面跟着"双击"，则只生成双击步骤。

11. ⭐ 操作模式映射表：
    以下是测试用例中常见的中文描述及其对应的原子步骤（左侧=原文模式，右侧=应生成的步骤）：

    | 原文模式 | → 生成的步骤 |
    |---------|------------|
    | 输入A：X | → input(A, X) |
    | 输入第一行A：X | → input(第一行A, X) row=1 column=A |
    | 点击"回车" / 按回车 | → click(回车) |
    | 点击"执行" / 点击执行 | → click(执行) |
    | 点击"保存" / 保存XX | → click(保存) |
    | 点击"检查" | → click(检查) |
    | 点击"登录"按钮 | → click(回车)（SAP 登录就是回车） |
    | 回车进入到下一页面 | → click(回车) + wait(等待页面加载) |
    | 双击XX进入详情 | → double_click(XX) + wait(等待详情页) |
    | 回退到/返回上一页面 | → click(返回) + wait(等待返回) |
    | 到/进入条件页签 | → click(条件页签) |
    | 点击条件页签 | → click(条件页签) |
    | 到条件页签修改X价格为Y | → click(条件页签) + input(X价格, Y) |
    | 保存XX，记录/生成XX号 | → click(保存) + verify(XX号生成) |
    | 输入事务代码"VA01" | → navigate(命令输入框, /nVA01) |
    | 显示/查看XX | → verify(XX显示) |
    | 系统自动带出/显示XX | → 不生成步骤（非操作） |
    | 获取清单数据/读取数据 | → read(清单数据) |
    | 进入行项目数据 | → 不生成步骤（描述性文字） |
    | 进入第二行项目数据 | → 不生成步骤（描述性文字，后续操作会处理） |

12. SAP 行项目表格输入（非常重要！）：
    在 ME21N/VA01/MM01 等事务中，行项目表格（物料、数量、工厂等）的输入规则：
    - 同一行的所有字段必须连续输入，不要穿插其他操作
    - 每行输入完毕后，必须加一个 click 回车步骤，让系统确认并处理该行
    - 然后再输入下一行
    - target_description 用"第N行物料"、"第N行数量"、"第N行工厂"来区分行
    - **必须同时填写 row 和 column 字段**：
      - row: 行号（数字），第一行=1，第二行=2
      - column: 列的业务名称，如"物料"、"数量"、"工厂"、"条件类型价格"
      - 条件页签中的价格输入也要填 row 和 column（column="条件类型价格"）
    - 非表格操作（如点击回车、切换页签、输入头部字段）**不要**输出 row 和 column
    - 条件页签（定价条件）始终显示当前选中行项目的条件，不需要加"第N行"前缀

13. 页签切换：
    - 切换到某个页签：action_type=click，target_description="条件页签"（或"物料数据页签"等）
    - 页签内的操作紧跟在页签切换之后
    - 条件/定价页签始终显示当前选中行项目的条件，切换行项目后需要重新点击条件页签

--- 完整示例 ---

### 示例A：VA01 创建销售订单（含双击行项目进入详情改价格）

输入操作步骤：
1. 打开SAPGUI
2. 输入登录集团：400， 输入登录账号： 127936，输入密码： Ssrw2102!，点击"回车"按钮
3. 输入事务代码"VA01"
4. 输入订单类型：OR1
5. 输入销售组织:ZY11, 分销渠道：01，产品组：01
6. 回车进入到下一页面,输入售达方：400169
7. 填入第一行物料：602748，数量：20
8. 进入行项目数据，双击该行项目进入详情，点击条件页签，输入条件类型：PR00, 输入金额：100
9. 回退到上一页面，输入第二行物料： 602748， 数量：100
10. 进入第二行项目数据，点击条件页签，输入条件类型：PR00, 输入金额：200
11. 保存销售订单，记录生成订单号码

测试数据：{{"客户端":"400","用户":"127936","密码":"Ssrw2102!","语言":"ZH","订单类型":"OR1","销售组织":"ZY11","分销渠道":"01","产品组":"01","售达方":"400169","物料":"602748","数量1":"20","数量2":"100","条件类型":"PR00","价格1":"100","价格2":"200"}}

输出：
```json
[
  {{"index":1, "action_type":"input", "target_description":"客户端", "value":"400"}},
  {{"index":2, "action_type":"input", "target_description":"用户", "value":"127936"}},
  {{"index":3, "action_type":"input", "target_description":"密码", "value":"Ssrw2102!"}},
  {{"index":4, "action_type":"click", "target_description":"回车"}},
  {{"index":5, "action_type":"wait", "target_description":"等待登录完成"}},
  {{"index":6, "action_type":"navigate", "target_description":"命令输入框", "value":"/nVA01"}},
  {{"index":7, "action_type":"input", "target_description":"订单类型", "value":"OR1"}},
  {{"index":8, "action_type":"input", "target_description":"销售组织", "value":"ZY11"}},
  {{"index":9, "action_type":"input", "target_description":"分销渠道", "value":"01"}},
  {{"index":10, "action_type":"input", "target_description":"产品组", "value":"01"}},
  {{"index":11, "action_type":"click", "target_description":"回车"}},
  {{"index":12, "action_type":"wait", "target_description":"等待页面加载"}},
  {{"index":13, "action_type":"input", "target_description":"售达方", "value":"400169"}},
  {{"index":14, "action_type":"click", "target_description":"回车"}},
  {{"index":15, "action_type":"wait", "target_description":"等待物料行显示"}},
  {{"index":16, "action_type":"input", "target_description":"第一行物料", "value":"602748", "row":1, "column":"物料"}},
  {{"index":17, "action_type":"input", "target_description":"第一行数量", "value":"20", "row":1, "column":"数量"}},
  {{"index":18, "action_type":"click", "target_description":"回车"}},
  {{"index":19, "action_type":"wait", "target_description":"等待第一行处理完成"}},
  {{"index":20, "action_type":"double_click", "target_description":"第一行项目"}},
  {{"index":21, "action_type":"wait", "target_description":"等待详情页加载"}},
  {{"index":22, "action_type":"click", "target_description":"条件页签"}},
  {{"index":23, "action_type":"input", "target_description":"PR00条件类型价格", "value":"100", "row":1, "column":"条件类型价格"}},
  {{"index":24, "action_type":"click", "target_description":"返回"}},
  {{"index":25, "action_type":"wait", "target_description":"等待返回"}},
  {{"index":26, "action_type":"input", "target_description":"第二行物料", "value":"602748", "row":2, "column":"物料"}},
  {{"index":27, "action_type":"input", "target_description":"第二行数量", "value":"100", "row":2, "column":"数量"}},
  {{"index":28, "action_type":"click", "target_description":"回车"}},
  {{"index":29, "action_type":"wait", "target_description":"等待第二行处理完成"}},
  {{"index":30, "action_type":"double_click", "target_description":"第二行项目"}},
  {{"index":31, "action_type":"wait", "target_description":"等待详情页加载"}},
  {{"index":32, "action_type":"click", "target_description":"条件页签"}},
  {{"index":33, "action_type":"input", "target_description":"PR00条件类型价格", "value":"200", "row":2, "column":"条件类型价格"}},
  {{"index":34, "action_type":"click", "target_description":"保存"}},
  {{"index":35, "action_type":"verify", "target_description":"订单号码生成", "value":"订单号码显示"}}
]
```

### 示例B：ME21N 创建采购订单（直接切条件页签改价格，不需要双击）

输入操作步骤：
1. 打开SAPGUI
2. 输入登录集团：400， 输入登录账号： 127936，输入密码： Ssrw2102!，点击"回车"按钮
3. 输入事务代码"ME21N"
4. 输入订单类型：NB
5. 输入供应商1006
6. 在采购订单抬头输入采购组织：HK01， 采购组：101， 公司代码C001
7. 输入第一行物料： 347， 数量：100， 工厂: HK01
8. 到条件页签修改第一行物料PBXX条件类型的价格为：20
9. 输入第二行物料：347， 数量: 200，工厂: HK01
10. 到条件页签修改第二行物料的价格为：30
11. 保存采购订单，生成订单号码

测试数据：{{"客户端":"400","用户":"127936","密码":"Ssrw2102!","语言":"ZH","订单类型":"NB","供应商":"1006","采购组织":"HK01","采购组":"101","公司代码":"C001","物料":"347","数量1":"100","数量2":"200","工厂":"HK01","条件类型":"PBXX","价格1":"20","价格2":"30"}}

输出：
```json
[
  {{"index":1, "action_type":"input", "target_description":"客户端", "value":"400"}},
  {{"index":2, "action_type":"input", "target_description":"用户", "value":"127936"}},
  {{"index":3, "action_type":"input", "target_description":"密码", "value":"Ssrw2102!"}},
  {{"index":4, "action_type":"click", "target_description":"回车"}},
  {{"index":5, "action_type":"wait", "target_description":"等待登录完成"}},
  {{"index":6, "action_type":"navigate", "target_description":"命令输入框", "value":"/nME21N"}},
  {{"index":7, "action_type":"input", "target_description":"订单类型", "value":"NB"}},
  {{"index":8, "action_type":"input", "target_description":"供应商", "value":"1006"}},
  {{"index":9, "action_type":"input", "target_description":"采购组织", "value":"HK01"}},
  {{"index":10, "action_type":"input", "target_description":"采购组", "value":"101"}},
  {{"index":11, "action_type":"input", "target_description":"公司代码", "value":"C001"}},
  {{"index":12, "action_type":"input", "target_description":"第一行物料", "value":"347", "row":1, "column":"物料"}},
  {{"index":13, "action_type":"input", "target_description":"第一行数量", "value":"100", "row":1, "column":"数量"}},
  {{"index":14, "action_type":"input", "target_description":"第一行工厂", "value":"HK01", "row":1, "column":"工厂"}},
  {{"index":15, "action_type":"click", "target_description":"回车"}},
  {{"index":16, "action_type":"wait", "target_description":"等待第一行处理完成"}},
  {{"index":17, "action_type":"click", "target_description":"条件页签"}},
  {{"index":18, "action_type":"input", "target_description":"PBXX条件类型价格", "value":"20", "row":1, "column":"条件类型价格"}},
  {{"index":19, "action_type":"input", "target_description":"第二行物料", "value":"347", "row":2, "column":"物料"}},
  {{"index":20, "action_type":"input", "target_description":"第二行数量", "value":"200", "row":2, "column":"数量"}},
  {{"index":21, "action_type":"input", "target_description":"第二行工厂", "value":"HK01", "row":2, "column":"工厂"}},
  {{"index":22, "action_type":"click", "target_description":"回车"}},
  {{"index":23, "action_type":"wait", "target_description":"等待第二行处理完成"}},
  {{"index":24, "action_type":"click", "target_description":"条件页签"}},
  {{"index":25, "action_type":"input", "target_description":"PBXX条件类型价格", "value":"30", "row":2, "column":"条件类型价格"}},
  {{"index":26, "action_type":"click", "target_description":"保存"}},
  {{"index":27, "action_type":"verify", "target_description":"采购订单号生成", "value":"订单号码显示"}}
]
```

### 示例C：VA05 销售订单报表查询（含执行+读取）

输入操作步骤：
1. 打开SAPGUI
2. 输入登录账号 ZHOUXINYIN，输入密码 Ssrw2102!!，点击"回车"按钮
3. 输入"VA05"
4. 在筛选界面输入订单类型：OR1，并点击执行
5. 显示销售订单报表
6. 获取清单上所有行数据并写入到日志

测试数据：{{"客户端":"100","用户":"ZHOUXINYIN","密码":"Ssrw2102!!","语言":"ZH","订单类型":"OR1"}}

输出：
```json
[
  {{"index":1, "action_type":"input", "target_description":"客户端", "value":"100"}},
  {{"index":2, "action_type":"input", "target_description":"用户", "value":"ZHOUXINYIN"}},
  {{"index":3, "action_type":"input", "target_description":"密码", "value":"Ssrw2102!!"}},
  {{"index":4, "action_type":"input", "target_description":"语言", "value":"ZH"}},
  {{"index":5, "action_type":"click", "target_description":"回车"}},
  {{"index":6, "action_type":"wait", "target_description":"等待登录完成"}},
  {{"index":7, "action_type":"navigate", "target_description":"命令输入框", "value":"/nVA05"}},
  {{"index":8, "action_type":"input", "target_description":"订单类型", "value":"OR1"}},
  {{"index":9, "action_type":"click", "target_description":"执行"}},
  {{"index":10, "action_type":"wait", "target_description":"等待报表加载"}},
  {{"index":11, "action_type":"verify", "target_description":"销售订单报表显示", "value":"销售订单报表"}},
  {{"index":12, "action_type":"read", "target_description":"清单数据"}}
]
```

只输出 JSON，不要输出其他文字。"""
