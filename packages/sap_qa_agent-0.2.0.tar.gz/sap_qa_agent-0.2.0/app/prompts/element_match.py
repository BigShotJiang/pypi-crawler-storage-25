"""元素匹配 Prompt 模板"""

ELEMENT_MATCH_PROMPT = """你是一个 SAP GUI 界面分析专家。请从以下元素列表中选择与目标字段最匹配的元素。

目标字段描述：{target_description}
当前操作步骤：{step_context}
当前标签页/窗口：{window_context}

候选元素列表：
{candidates_json}

每个候选元素包含：id_path、element_type、tooltip、label_text、current_value

请输出一个 JSON：
{{
  "selected_index": 候选元素的索引（从0开始），
  "reason": "选择理由"
}}

只输出 JSON，不要输出其他文字。"""
