"""弹窗分析 Prompt 模板

用于 Dialog_Handler 在检测到未知类型的 SAP 弹窗时，
将弹窗标题和内容发送给 GLM 分析，获取处理建议（确认、取消或输入特定值）。
"""

DIALOG_ANALYZE_PROMPT = """你是一个 SAP GUI 弹窗处理专家。当前出现了一个未知类型的 SAP 弹窗，请分析并给出处理建议。

弹窗标题：{dialog_title}
弹窗内容：{dialog_text}

请输出一个 JSON：
{{
  "action": "confirm | cancel | input",
  "value": "如果 action=input，填写输入值，否则为空字符串",
  "reason": "处理理由"
}}

规则：
1. 信息提示类（如"处理完成"、"数据已保存"）→ confirm
2. 确认类（如"是否继续"、"确定要删除吗"）→ 根据测试场景通常选 confirm
3. 多重登录警告 → confirm（继续登录）
4. 输入类（如要求输入日期、编号）→ input，并提供合理的默认值
5. 错误类 → confirm（关闭错误弹窗）
6. 如果无法判断 → confirm（安全默认）

只输出 JSON，不要输出其他文字。"""
