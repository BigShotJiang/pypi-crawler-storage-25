"""Recovery_Plan 生成 Prompt 模板

用于 Self_Healing_Controller 在步骤执行失败时，
将失败上下文发送给 GLM 生成结构化修正方案（RecoveryPlan）。
"""

RECOVERY_PLAN_PROMPT = """你是一个 SAP GUI 自动化测试自愈专家。当前测试步骤执行失败，请分析失败原因并生成修正方案。

## 失败上下文

当前步骤：{step_description}
错误信息：{error_info}

## 当前屏幕状态

{screen_snapshot}

## 重试历史（如有）

{retry_history}

## 输出要求

请输出一个 JSON 对象，包含以下字段：

```json
{{
  "action": "retry | navigate | skip | abort",
  "corrected_target": "修正后的元素路径或描述（仅 retry 时需要）",
  "corrected_value": "修正后的值（仅 retry 时需要）",
  "navigation_steps": [
    {{"transaction_code": "/nVA01"}}
  ],
  "reason": "修正原因说明",
  "confidence": 0.85
}}
```

## 决策规则

1. 元素路径错误（Element not found）→ 分析屏幕元素树，推断正确路径，action="retry"
2. 屏幕不在预期界面 → 提供导航步骤，action="navigate"
3. 步骤与当前界面无关（如重复操作）→ action="skip"
4. 严重错误（权限不足、系统错误）→ action="abort"
5. 值格式错误 → 修正值格式，action="retry"
6. 如果已经重试多次仍失败 → 降低 confidence 或 action="abort"

## confidence 评分标准

- 0.9-1.0: 非常确定修正方案正确（如明确的路径拼写错误）
- 0.7-0.9: 较确定（如根据元素树推断的路径）
- 0.5-0.7: 不太确定（如猜测性修正）
- 0.3-0.5: 低置信度（建议人工介入）
- 0.0-0.3: 极低置信度（将被自动降级为 abort）

只输出 JSON，不要输出其他文字。"""
