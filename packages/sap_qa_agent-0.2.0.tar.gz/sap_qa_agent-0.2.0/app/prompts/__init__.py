"""VLM Prompt 加载器 — 根据 TARGET_APP_LABEL 加载对应客户端的 prompt 文件。"""

import importlib
from app.config import TARGET_APP_LABEL

# 客户端标签 → 模块名映射
_MODULE_MAP = {
    "sap": "app.prompts.sap",
    "car": "app.prompts.car",
}


def _load_prompts(app_label: str) -> tuple[str, str, str]:
    module_name = _MODULE_MAP.get(app_label)
    if module_name is None:
        raise ValueError(
            f"未知的目标客户端: '{app_label}'，"
            f"可选值: {list(_MODULE_MAP.keys())}"
        )
    mod = importlib.import_module(module_name)
    return mod.PAGE_ANALYZE_PROMPT, mod.FALLBACK_PROMPT, mod.ERROR_CHECK_PROMPT


PAGE_ANALYZE_PROMPT, FALLBACK_PROMPT, ERROR_CHECK_PROMPT = _load_prompts(TARGET_APP_LABEL)
