"""步骤动态调整 Prompt — 根据当前屏幕状态调整执行步骤"""

STEP_ADJUST_PROMPT = """你是 SAP GUI 自动化测试专家。请根据当前屏幕状态，调整测试步骤列表。

## 测试用例
{test_case_context}

## 当前屏幕状态
窗口标题: {window_title}
状态栏: {status_bar}

## 当前屏幕元素
{screen_elements}

## 原始步骤列表
{original_steps}

## 调整规则

判断当前状态的方法（看屏幕元素，不要猜）：
- 屏幕元素中有 RSYST-BNAME（用户名字段）→ 当前在登录界面，未登录
- 屏幕元素中没有 RSYST-BNAME → 当前已登录
- 窗口标题包含"轻松访问"或"Easy Access" → 当前已登录，在主界面

根据当前状态调整步骤：
1. 如果当前在登录界面（有 RSYST-BNAME），必须保留所有登录步骤（客户端/用户/密码/语言/回车/等待）
2. 如果当前已登录（没有 RSYST-BNAME），**必须删除所有登录相关步骤**：
   - 删除 target_description 包含"客户端"、"用户"、"密码"、"语言"的 input 步骤
   - 删除登录后的"回车"和"等待系统响应"步骤
   - 只保留业务操作步骤
3. 如果当前已经在目标事务码界面，跳过导航步骤
4. 如果当前在结果列表页面但需要回到筛选界面，在前面插入导航步骤（如 /nVA05 重新进入）
5. 保留所有业务操作步骤（输入字段、点击按钮、验证、读取数据）
6. 如果需要插入额外步骤（如处理弹窗、回到筛选界面），直接加入
7. 重新编号（index 从 1 开始）

## 输出格式
输出调整后的 JSON 数组，每个步骤包含：
- index: 步骤序号（从1开始）
- action_type: 操作类型（input/click/select/verify/navigate/wait/read）
- target_description: 目标描述
- value: 值（如果有）

只输出 JSON，不要输出其他文字。"""
