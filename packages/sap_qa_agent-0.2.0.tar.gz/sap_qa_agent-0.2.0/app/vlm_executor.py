"""VLM 自研执行器 - 页面预处理模式：截屏 → OCR+VLM 分析页面 → PyAutoGUI 执行"""

import asyncio
import base64
import io
import json
import logging
import os
import re
import time
from dataclasses import dataclass, field

import httpx
import mss
import pyautogui
from PIL import Image

from app.config import (
    AGENT_TARS_API_KEY,
    AGENT_TARS_BASE_URL,
    AGENT_TARS_MODEL,
    AGENT_TARS_TIMEOUT,
    ARTIFACTS_DIR,
    GROUNDING_MODE,
    MAX_CONCURRENT_TASKS,
    TARGET_APP_PROCESS,
    TARGET_SAVE_HOTKEY,
    UITARS_API_KEY,
    UITARS_BASE_URL,
    UITARS_MODEL,
    VLM_ACTION_DELAY,
    VLM_MAX_RETRIES_PER_STEP,
    VLM_SCREENSHOT_DELAY,
    VLM_STEP_TIMEOUT,
)
from app.models import StepInfo
from app.recorder import ScreenRecorder

logger = logging.getLogger(__name__)

pyautogui.FAILSAFE = True
pyautogui.PAUSE = 0.3

_semaphore = asyncio.Semaphore(MAX_CONCURRENT_TASKS)

AUTO_SCROLL_AMOUNT = 5
AUTO_SCROLL_MAX = 2

# 页面稳定检测参数
PAGE_STABLE_INTERVAL = 1.0   # 每次截图间隔（秒）
PAGE_STABLE_THRESHOLD = 0.98  # SSIM 阈值，高于此值视为稳定
PAGE_STABLE_MAX_WAIT = 10.0   # 最长等待时间（秒）

# OCR 优先模式：True 用 OCR 直接定位字段，False 用 VLM+OCR 原有逻辑
USE_OCR_PRIMARY = True

# 主定位策略，由 config.GROUNDING_MODE 控制："uitars" | "ocr" | "vlm"
USE_OCR_PRIMARY = (GROUNDING_MODE == "ocr")
USE_UITARS_PRIMARY = (GROUNDING_MODE == "uitars")
USE_UITARS_GROUNDING = (GROUNDING_MODE in ("uitars", "ocr"))  # 两种模式都用 UI-TARS 作 fallback

# 延迟加载 OCR
_ocr_reader = None


def _get_ocr_reader():
    global _ocr_reader
    if _ocr_reader is None:
        from rapidocr_onnxruntime import RapidOCR
        _ocr_reader = RapidOCR()
        logger.info("RapidOCR (ONNX) reader initialized")
    return _ocr_reader


# 延迟加载 OmniParser YOLO 模型
_yolo_model = None
_YOLO_MODEL_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
    "OmniParser", "weights", "icon_detect", "model.pt",
)


def _get_yolo_model():
    global _yolo_model
    if _yolo_model is None:
        from ultralytics import YOLO
        _yolo_model = YOLO(_YOLO_MODEL_PATH)
        logger.info("OmniParser YOLO model loaded from %s", _YOLO_MODEL_PATH)
    return _yolo_model


# ---- VLM Prompt：从 prompts 子模块按客户端配置加载 ----
from app.prompts import PAGE_ANALYZE_PROMPT, FALLBACK_PROMPT, ERROR_CHECK_PROMPT


@dataclass
class ExecutionResult:
    success: bool
    stdout: str = ""
    stderr: str = ""
    return_code: int | None = None
    error: str | None = None
    session_id: str | None = None
    result_content: str | None = None
    step_logs: list[str] = field(default_factory=list)


class VLMExecutor:
    def __init__(self) -> None:
        self._stopped: dict[str, bool] = {}
        self._recorder = ScreenRecorder()
        self._http_client = httpx.AsyncClient(timeout=120.0)
        self._uitars_client = httpx.AsyncClient(timeout=120.0)
        self._screen_w, self._screen_h = pyautogui.size()

    # ---- 公开接口 ----

    def build_prompt(self, steps: list[StepInfo]) -> str:
        if not steps:
            return ""
        lines = [f"{i}. {step.description}" for i, step in enumerate(steps, 1)]
        return "请依次完成以下操作：\n" + "\n".join(lines)

    async def execute(self, task_id: str, prompt: str) -> ExecutionResult:
        async with _semaphore:
            return await self._do_execute(task_id, prompt)

    async def stop(self, task_id: str) -> bool:
        self._stopped[task_id] = True
        await self._recorder.stop()
        return True

    # ---- 目标窗口激活 ----

    @staticmethod
    async def _activate_sap_window() -> None:
        """将目标客户端窗口激活到前台。"""
        script = f'''
tell application "System Events"
    try
        set targetProc to first process whose name is "{TARGET_APP_PROCESS}"
        set frontmost of targetProc to true
    end try
end tell
'''
        try:
            proc = await asyncio.create_subprocess_exec(
                "osascript", "-e", script,
                stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
            )
            await asyncio.wait_for(proc.communicate(), timeout=10)
        except Exception as e:
            logger.warning("activate %s window failed: %s", TARGET_APP_PROCESS, e)
        await asyncio.sleep(1.0)
        logger.info("%s window activation attempted", TARGET_APP_PROCESS)

    # ---- 截屏 ----

    @staticmethod
    def _get_sap_window_rect() -> tuple[int, int, int, int] | None:
        """获取目标客户端窗口位置和大小，返回 (x, y, w, h) 或 None。"""
        import subprocess
        try:
            script = (
                'tell application "System Events"\n'
                f'  set targetProc to first process whose name is "{TARGET_APP_PROCESS}"\n'
                '  set targetWin to first window of targetProc\n'
                '  set {x, y} to position of targetWin\n'
                '  set {w, h} to size of targetWin\n'
                '  return (x as text) & "," & (y as text) & "," & (w as text) & "," & (h as text)\n'
                'end tell'
            )
            result = subprocess.run(
                ['osascript', '-e', script],
                capture_output=True, text=True, timeout=3)
            if result.returncode == 0 and result.stdout.strip():
                parts = result.stdout.strip().split(',')
                if len(parts) == 4:
                    return int(parts[0]), int(parts[1]), int(parts[2]), int(parts[3])
        except Exception:
            pass
        return None

    @staticmethod
    def _screenshot() -> Image.Image:
        """全屏截图。"""
        with mss.mss() as sct:
            monitor = sct.monitors[1]
            img = sct.grab(monitor)
            return Image.frombytes("RGB", img.size, img.bgra, "raw", "BGRX")

    @staticmethod
    def _image_to_base64(img: Image.Image) -> str:
        buf = io.BytesIO()
        img.save(buf, format="PNG", optimize=True)
        return base64.b64encode(buf.getvalue()).decode("utf-8")

    async def _wait_page_stable(self, step_logs: list[str], after_enter: bool = False) -> None:
        """等待页面加载稳定：先等页面开始响应，再等稳定。
        after_enter=True 时，如果检测不到变化会一直等（Enter 后一定有响应）。
        """
        import cv2
        import numpy as np

        # Phase 1: 等页面开始变化（最多等3s，检测到变化立即进入Phase 2）
        await asyncio.sleep(0.3)
        baseline = await asyncio.to_thread(self._screenshot)
        baseline_gray = cv2.cvtColor(np.array(baseline), cv2.COLOR_RGB2GRAY)
        page_started_changing = False
        for _ in range(10):  # 最多等 0.3 + 10*0.5 = 5.3s
            await asyncio.sleep(0.5)
            curr = await asyncio.to_thread(self._screenshot)
            curr_gray = cv2.cvtColor(np.array(curr), cv2.COLOR_RGB2GRAY)
            diff = cv2.absdiff(baseline_gray, curr_gray)
            if np.mean(diff) / 255.0 > 0.005:  # 页面开始变化（降低阈值）
                page_started_changing = True
                break

        if not page_started_changing:
            if after_enter:
                # Enter 后一定有页面变化，一直等直到检测到变化
                step_logs.append("  Enter后未检测到页面变化，继续等待...")
                while True:
                    await asyncio.sleep(0.5)
                    curr = await asyncio.to_thread(self._screenshot)
                    curr_gray = cv2.cvtColor(np.array(curr), cv2.COLOR_RGB2GRAY)
                    diff = cv2.absdiff(baseline_gray, curr_gray)
                    if np.mean(diff) / 255.0 > 0.005:
                        step_logs.append("  页面开始变化，继续等待稳定")
                        break
            else:
                # 非 Enter 操作，页面没变化可能是正常的（如点击标签页）
                step_logs.append("  page no change detected, proceeding")
                return

        # Phase 2: 等页面稳定
        prev = await asyncio.to_thread(self._screenshot)
        prev_gray = cv2.cvtColor(np.array(prev), cv2.COLOR_RGB2GRAY)
        prev_ocr = await asyncio.to_thread(self._ocr_detect_raw, prev)
        prev_texts = {item["text"] for item in prev_ocr}

        waited = 0.0
        while waited < PAGE_STABLE_MAX_WAIT:
            await asyncio.sleep(PAGE_STABLE_INTERVAL)
            waited += PAGE_STABLE_INTERVAL
            curr = await asyncio.to_thread(self._screenshot)
            curr_gray = cv2.cvtColor(np.array(curr), cv2.COLOR_RGB2GRAY)

            curr_ocr = await asyncio.to_thread(self._ocr_detect_raw, curr)
            curr_texts = {item["text"] for item in curr_ocr}

            if prev_texts and curr_texts:
                changed = len(prev_texts ^ curr_texts)
                total = len(prev_texts | curr_texts)
                text_change = changed / total if total else 0
            else:
                text_change = 0

            if text_change > 0.3:
                step_logs.append(f"  page changing ({waited:.1f}s, text_change={text_change:.2f})")
                prev_texts = curr_texts
                prev_gray = curr_gray
                continue

            diff = cv2.absdiff(prev_gray, curr_gray)
            similarity = 1.0 - (np.mean(diff) / 255.0)

            if similarity >= PAGE_STABLE_THRESHOLD:
                step_logs.append(f"  page stable ({waited:.1f}s, sim={similarity:.4f})")
                return
            prev_gray = curr_gray
            prev_texts = curr_texts

        step_logs.append(f"  page wait timeout ({waited:.1f}s)")

    def _save_image(self, task_dir: str, name: str, b64: str) -> str:
        os.makedirs(task_dir, exist_ok=True)
        filepath = os.path.join(task_dir, name)
        with open(filepath, "wb") as f:
            f.write(base64.b64decode(b64))
        return filepath

    def _norm_to_screen(self, nx: int | float, ny: int | float) -> tuple[int, int]:
        """归一化坐标 (0~1000) → 实际屏幕像素。"""
        if isinstance(nx, (list, tuple)):
            nx = nx[0] if nx else 500
        if isinstance(ny, (list, tuple)):
            ny = ny[0] if ny else 500
        x = int(float(nx) / 1000.0 * self._screen_w)
        y = int(float(ny) / 1000.0 * self._screen_h)
        x = max(0, min(x, self._screen_w - 1))
        y = max(0, min(y, self._screen_h - 1))
        return x, y

    # ---- OCR ----

    def _ocr_detect_raw(self, pil_img: Image.Image) -> list[dict]:
        """RapidOCR detect, returns structured results.
        Each item: {"text", "conf", "nx", "ny", "x_min", "x_max", "y_min", "y_max"} (normalized 0~1000)
        图片先 2x 放大再 OCR，提高小字体检测率。
        """
        import numpy as np
        try:
            reader = _get_ocr_reader()
            # 2x 放大提高小字体检测率
            upscaled = pil_img.resize((pil_img.width * 2, pil_img.height * 2), Image.LANCZOS)
            img_arr = np.array(upscaled.convert('RGB') if upscaled.mode == 'RGBA' else upscaled)
            results, _ = reader(img_arr)
        except Exception as e:
            logger.warning("OCR failed: %s", e)
            return []

        if not results:
            return []

        # 坐标基于放大后的图，归一化时用放大后的尺寸（等价于原图归一化）
        up_w, up_h = upscaled.size
        items: list[dict] = []
        for bbox, text, conf in results:
            if conf < 0.5 or not text.strip():
                continue
            xs = [p[0] for p in bbox]
            ys = [p[1] for p in bbox]
            nx = int(((min(xs) + max(xs)) / 2) / up_w * 1000)
            ny = int(((min(ys) + max(ys)) / 2) / up_h * 1000)
            items.append({
                "text": text.strip(),
                "conf": round(float(conf), 3),
                "nx": nx,
                "ny": ny,
                "x_min": int(min(xs) / up_w * 1000),
                "x_max": int(max(xs) / up_w * 1000),
                "y_min": int(min(ys) / up_h * 1000),
                "y_max": int(max(ys) / up_h * 1000),
            })
        return items

    @staticmethod
    def _detect_input_boxes(pil_img: Image.Image) -> list[dict]:
        """YOLO 检测 UI 元素，返回所有检测框。
        Returns list of {"x_min", "x_max", "y_min", "y_max", "cx", "cy"} (normalized 0~1000).
        """
        img_w, img_h = pil_img.size
        model = _get_yolo_model()
        result = model.predict(source=pil_img, conf=0.05, iou=0.7)
        raw_boxes = result[0].boxes.xyxy.tolist()
        confs = result[0].boxes.conf.tolist()

        boxes: list[dict] = []
        for (x1, y1, x2, y2), conf in zip(raw_boxes, confs):
            boxes.append({
                "x_min": int(x1 / img_w * 1000),
                "x_max": int(x2 / img_w * 1000),
                "y_min": int(y1 / img_h * 1000),
                "y_max": int(y2 / img_h * 1000),
                "cx": int((x1 + x2) / 2 / img_w * 1000),
                "cy": int((y1 + y2) / 2 / img_h * 1000),
                "_src": "yolo",
                "_conf": round(conf, 3),
            })

        logger.info("YOLO detected %d UI elements", len(boxes))
        return boxes

    def _ocr_to_text(self, ocr_items: list[dict]) -> str:
        """OCR 结果转文本（给 VLM 用）。"""
        if not ocr_items:
            return "(未检测到文字)"
        return "\n".join(f'"{it["text"]}" → ({it["nx"]}, {it["ny"]})' for it in ocr_items)

    # ---- 页面预处理：OCR + VLM 同时分析 ----

    async def _analyze_page(self, img_b64: str, ocr_items: list[dict],
                           input_boxes: list[dict] | None = None) -> dict:
        """用 VLM 分析页面结构，返回 {"fields": [...], "buttons": [...], "page_title": "..."}。
        fields 按 Tab 顺序排列，每项有 label, input_x, input_y。
        """
        ocr_text = self._ocr_to_text(ocr_items)

        user_content = [
            {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{img_b64}"}},
            {"type": "text", "text": (
                f"OCR 识别到的文字列表（归一化坐标 0~1000）：\n{ocr_text}\n\n"
                f"请分析界面并输出 JSON。"
            )},
        ]

        messages = [
            {"role": "system", "content": PAGE_ANALYZE_PROMPT},
            {"role": "user", "content": user_content},
        ]

        payload = {
            "model": AGENT_TARS_MODEL,
            "messages": messages,
            "max_tokens": 1024,
            "temperature": 0.0,
        }

        headers = {"Content-Type": "application/json"}
        if AGENT_TARS_API_KEY and AGENT_TARS_API_KEY != "not-needed":
            headers["Authorization"] = f"Bearer {AGENT_TARS_API_KEY}"

        url = f"{AGENT_TARS_BASE_URL}/chat/completions"
        resp = await self._http_client.post(url, json=payload, headers=headers)
        resp.raise_for_status()

        content = resp.json()["choices"][0]["message"]["content"].strip()
        logger.info("VLM page analysis raw: %s", content[:800])

        parsed = self._parse_json_response(content)
        if not parsed or "fields" not in parsed:
            logger.warning("Page analysis parse failed, returning empty")
            return {"fields": [], "buttons": [], "page_title": "unknown"}

        # 用 OCR + OpenCV 坐标修正 VLM 给的坐标
        self._refine_with_ocr(parsed, ocr_items, input_boxes)
        return parsed

    def _refine_with_ocr(self, page_info: dict, ocr_items: list[dict],
                        input_boxes: list[dict] | None = None) -> None:
        """以 VLM 坐标为参考区域，用 OCR + OpenCV 校准精确位置。

        策略：
        1. VLM 给了输入框大致坐标 (input_x, input_y)
        2. OCR 找到标签 → 用标签的 y 对齐
        3. OpenCV 找到标签右边同行最近的输入框 → 用输入框中心作为 x
        4. 如果 OpenCV 没找到，用 VLM 的 x 做兜底（检查是否指偏到文字上）
        5. 按钮坐标直接用 OCR 精确匹配
        """
        ROW_THRESHOLD = 25

        for fld in page_info.get("fields", []):
            label = fld.get("label", "")
            if not label:
                continue
            # 确保坐标是数字
            for key in ("input_x", "input_y"):
                v = fld.get(key)
                if isinstance(v, (list, tuple)):
                    fld[key] = v[0] if v else 0
                elif not isinstance(v, (int, float)):
                    fld[key] = 0

            vlm_x = fld["input_x"]
            vlm_y = fld["input_y"]

            # 找 OCR 中匹配的标签（用于 y 对齐）
            label_item, label_score = None, 0
            for item in ocr_items:
                score = self._fuzzy_match_score(label, item["text"])
                if score > label_score:
                    label_score = score
                    label_item = item

            # 用 OCR 标签的 y 坐标对齐（OCR 的 y 比 VLM 准）
            if label_item and label_score >= 50:
                fld["input_y"] = label_item["ny"]

            # 优先用 OpenCV 输入框定位
            if label_item and label_score >= 50 and input_boxes:
                label_x_max = label_item["x_max"]
                label_y = label_item["ny"]
                best_box, best_dist = None, 9999
                for box in input_boxes:
                    if abs(box["cy"] - label_y) > ROW_THRESHOLD:
                        continue
                    if box["x_min"] < label_x_max - 10:
                        continue
                    dist = box["x_min"] - label_x_max
                    if dist < best_dist:
                        best_dist = dist
                        best_box = box
                if best_box is not None:
                    fld["input_x"] = best_box["cx"]
                    fld["input_y"] = best_box["cy"]
                    fld["_ocr_verified"] = True
                    continue

            # OpenCV 没找到，用 VLM 的 x 做兜底
            hit_item = None
            for item in ocr_items:
                if abs(item["ny"] - fld["input_y"]) > ROW_THRESHOLD:
                    continue
                if item["x_min"] <= vlm_x <= item["x_max"]:
                    hit_item = item
                    break

            if hit_item:
                if label_item and hit_item is label_item:
                    fld["input_x"] = hit_item["x_max"] + 20
                else:
                    fld["input_x"] = hit_item["nx"]
                fld["_ocr_verified"] = True
            else:
                if label_item and label_score >= 50:
                    if vlm_x <= label_item["x_max"] + 5:
                        fld["input_x"] = label_item["x_max"] + 20
                fld["_ocr_verified"] = True

        for btn in page_info.get("buttons", []):
            label = btn.get("label", "")
            if not label:
                continue
            for key in ("x", "y"):
                v = btn.get(key)
                if isinstance(v, (list, tuple)):
                    btn[key] = v[0] if v else 0
                elif not isinstance(v, (int, float)):
                    btn[key] = 0

            for item in ocr_items:
                txt = item["text"]
                if txt == label or label in txt or (txt in label and len(txt) >= 2):
                    btn["x"] = item["nx"]
                    btn["y"] = item["ny"]
                    btn["_ocr_verified"] = True
                    break

    # ---- 从页面地图中查找字段/按钮 ----

    @staticmethod
    def _fuzzy_match_score(target: str, ocr_text: str) -> int:
        """模糊匹配评分。处理 OCR 识别错误（如"日期"→"曰期"，"类型"→"粪型"）。
        返回 0~100 的分数，0 表示不匹配。
        """
        if ocr_text == target:
            return 100
        if target in ocr_text and len(target) >= 2:
            # target 完整出现在 ocr_text 中，长度越接近分越高
            ratio = len(target) / len(ocr_text)
            if ratio < 0.5:
                # target 只是 ocr_text 的一小部分（如"科目" in "暂存的凭证科目模型"），低分
                return int(30 + ratio * 40)  # 30~50
            return int(85 + ratio * 10)  # 85~95
        # 逐字符匹配：允许个别字 OCR 识别错误，且长度要接近
        if len(target) >= 2 and len(ocr_text) >= 2:
            matches = sum(1 for a, b in zip(target, ocr_text) if a == b)
            len_diff = abs(len(target) - len(ocr_text))
            ratio = matches / max(len(target), len(ocr_text))
            if ratio >= 0.5 and len_diff <= 1:
                return int(ratio * 80)
        # 短文字包含在长文字里 — 大幅降低分数，避免"日期"匹配到"凭证日期"
        if ocr_text in target and len(ocr_text) >= 2:
            ratio = len(ocr_text) / len(target)
            return int(30 + ratio * 20)  # 30~50, 越短分越低
        return 0

    @staticmethod
    def _find_field_in_map(page_map: dict, field_name: str) -> dict | None:
        """在页面地图中找到指定字段。"""
        best, best_score = None, 0
        for fld in page_map.get("fields", []):
            label = fld.get("label", "")
            score = VLMExecutor._fuzzy_match_score(field_name, label)
            if score > best_score:
                best_score = score
                best = fld
        return best if best_score >= 50 else None

    @staticmethod
    def _find_button_in_map(page_map: dict, button_name: str) -> dict | None:
        """在页面地图中找到指定按钮。"""
        for btn in page_map.get("buttons", []):
            label = btn.get("label", "")
            if label == button_name or button_name in label or label in button_name:
                return btn
        return None

    @staticmethod
    def _is_next_field(page_map: dict, current_field: str, next_field: str) -> bool:
        """判断 next_field 是否是 current_field 在 Tab 顺序中的下一个。
        使用严格匹配，避免"过账日期"和"过账期间"这类相似字段名误判。
        """
        fields = page_map.get("fields", [])
        for i, fld in enumerate(fields):
            label = fld.get("label", "")
            if VLMExecutor._fuzzy_match_score(current_field, label) >= 80:
                if i + 1 < len(fields):
                    next_label = fields[i + 1].get("label", "")
                    return VLMExecutor._fuzzy_match_score(next_field, next_label) >= 80
        return False

    # ---- 步骤解析 ----

    @staticmethod
    def _parse_step(step_desc: str) -> dict:
        """解析步骤描述，返回 {"type": "input"|"hotkey"|"click"|"wait", ...}。"""
        # 返回 → F3
        if step_desc.strip() in ("返回", "点击返回", "返回上一页"):
            return {"type": "hotkey", "keys": ["f3"]}

        # 纯按键
        if "点击" not in step_desc and not re.search(r'输入\s*["""x{201c}x{201d}]', step_desc):
            key_match = re.search(r'按\s*(Tab|Enter|回车|F\d+|Ctrl\+S)\s*键', step_desc, re.I)
            if key_match:
                key_raw = key_match.group(1).lower()
                key_map = {"tab": ["tab"], "enter": ["enter"], "回车": ["enter"],
                           "ctrl+s": ["command", "s"]}
                keys = key_map.get(key_raw)
                if keys is None and key_raw.startswith("f"):
                    keys = [key_raw]
                if keys:
                    return {"type": "hotkey", "keys": keys}

        # 输入类: 在 "字段名" 输入框输入 "值"
        m = re.search(r'[在往].*?["""x{201c}x{201d}]([^"""]+)["""x{201c}x{201d}].*?输入.*?["""x{201c}x{201d}]([^"""]+)["""x{201c}x{201d}]', step_desc)
        if m:
            return {
                "type": "input",
                "field": m.group(1),
                "value": m.group(2),
                "enter": bool(re.search(r'按.{0,2}(Enter|回车).{0,2}键', step_desc, re.I)),
            }

        # 输入类: 定位 "字段名" 输入框，输入 "值"
        m = re.search(r'定位.*?["""x{201c}x{201d}]([^"""]+)["""x{201c}x{201d}].*?输入.*?["""x{201c}x{201d}]([^"""]+)["""x{201c}x{201d}]', step_desc)
        if m:
            return {
                "type": "input",
                "field": m.group(1),
                "value": m.group(2),
                "enter": bool(re.search(r'按.{0,2}(Enter|回车).{0,2}键', step_desc, re.I)),
            }

        # 搜索类（需要 VLM 定位搜索框）: 在搜索框输入 "值"  — 必须在 m2 之前
        m3 = re.search(r'输入\s*["""x{201c}x{201d}]([^"""]+)["""x{201c}x{201d}]', step_desc)
        if m3 and "搜索" in step_desc:
            return {
                "type": "click_and_input",
                "target": "搜索框",
                "value": m3.group(1),
                "enter": bool(re.search(r'按.{0,2}(Enter|回车).{0,2}键', step_desc, re.I)),
            }

        # 输入类（无字段名）: 在命令输入框中输入 "值"
        m2 = re.search(r'在.*?输入框.*?输入\s*["""x{201c}x{201d}]([^"""]+)["""x{201c}x{201d}]', step_desc)
        if m2:
            return {
                "type": "input",
                "field": None,
                "value": m2.group(1),
                "enter": bool(re.search(r'按.{0,2}(Enter|回车).{0,2}键', step_desc, re.I)),
            }

        # 双击类
        if "双击" in step_desc:
            btn_match = re.search(r'[\u201c\u300c"]([^\u201d\u300d"]+)[\u201d\u300d"]', step_desc)
            target = btn_match.group(1) if btn_match else re.sub(r'^双击\s*', '', step_desc).strip()
            return {"type": "double_click", "target": target}

        # 点击类
        if "点击" in step_desc:
            # "保存"按钮 → 配置的保存快捷键
            if re.search(r'点击.*保存', step_desc):
                return {"type": "hotkey", "keys": list(TARGET_SAVE_HOTKEY)}
            # 提取引号内的目标名（兼容各种引号）
            btn_match = re.search(r'[\"\"\u201c\u300c]([^\"\"\u201d\u300d]+)[\"\"\u201d\u300d]', step_desc)
            target = btn_match.group(1) if btn_match else step_desc
            # 菜单项点击后不等页面稳定（弹出菜单会因等待而消失）
            is_menu = "菜单" in step_desc
            return {"type": "click", "target": target, "no_wait": is_menu}

        # 定位类（定位"xxx"按钮/标签页/图标）
        locate_match = re.search(r'[\"\"\u201c\u300c]([^\"\"\u201d\u300d]+)[\"\"\u201d\u300d]', step_desc)
        if locate_match and "定位" in step_desc:
            return {"type": "click", "target": locate_match.group(1)}

        # 等待/确认类
        return {"type": "wait", "desc": step_desc}

    # ---- VLM 错误检测 ----

    async def _check_for_error(self, task_dir: str, step_idx: int,
                               step_logs: list[str]) -> dict | None:
        """截屏 → VLM 检查界面是否有错误提示。
        返回 {"has_error": True, "error_message": "...", "related_field": "..."} 或 None（无错误）。
        """
        await asyncio.sleep(0.5)  # 等界面渲染错误提示
        pil_img = await asyncio.to_thread(self._screenshot)
        img_b64 = self._image_to_base64(pil_img)
        self._save_image(task_dir, f"step_{step_idx:03d}_errchk.png", img_b64)

        ocr_items = await asyncio.to_thread(self._ocr_detect_raw, pil_img)
        ocr_text = self._ocr_to_text(ocr_items)

        user_content = [
            {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{img_b64}"}},
            {"type": "text", "text": f"OCR 文字列表：\n{ocr_text}\n\n请检查界面是否有错误提示。"},
        ]

        payload = {
            "model": AGENT_TARS_MODEL,
            "messages": [
                {"role": "system", "content": ERROR_CHECK_PROMPT},
                {"role": "user", "content": user_content},
            ],
            "max_tokens": 256,
            "temperature": 0.0,
        }

        headers = {"Content-Type": "application/json"}
        if AGENT_TARS_API_KEY and AGENT_TARS_API_KEY != "not-needed":
            headers["Authorization"] = f"Bearer {AGENT_TARS_API_KEY}"

        try:
            url = f"{AGENT_TARS_BASE_URL}/chat/completions"
            resp = await self._http_client.post(url, json=payload, headers=headers)
            resp.raise_for_status()
            content = resp.json()["choices"][0]["message"]["content"].strip()
            logger.info("VLM error check raw: %s", content[:300])
            result = self._parse_json_response(content)
            if result and result.get("has_error"):
                return result
        except Exception as e:
            logger.warning("Error check failed: %s", e)

        return None

    @staticmethod
    def _find_step_for_field(steps: list[str], field_name: str) -> int | None:
        """在步骤列表中找到操作指定字段的步骤索引（0-based）。"""
        if not field_name:
            return None
        for i, step in enumerate(steps):
            if field_name in step:
                return i
        return None

    # ---- VLM 兜底调用 ----

    async def _ask_vlm_fallback(self, img_b64: str, step_desc: str,
                                ocr_text: str) -> dict:
        """VLM 兜底：OCR/页面地图都搞不定时，让 VLM 直接给操作指令。"""
        user_content = [
            {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{img_b64}"}},
            {"type": "text", "text": (
                f"当前步骤：{step_desc}\n\n"
                f"OCR 识别到的文字列表（归一化坐标 0~1000）：\n{ocr_text}\n\n"
                f"请输出一个 JSON 动作。"
            )},
        ]

        payload = {
            "model": AGENT_TARS_MODEL,
            "messages": [
                {"role": "system", "content": FALLBACK_PROMPT},
                {"role": "user", "content": user_content},
            ],
            "max_tokens": 256,
            "temperature": 0.0,
        }

        headers = {"Content-Type": "application/json"}
        if AGENT_TARS_API_KEY and AGENT_TARS_API_KEY != "not-needed":
            headers["Authorization"] = f"Bearer {AGENT_TARS_API_KEY}"

        url = f"{AGENT_TARS_BASE_URL}/chat/completions"
        resp = await self._http_client.post(url, json=payload, headers=headers)
        resp.raise_for_status()

        content = resp.json()["choices"][0]["message"]["content"].strip()
        logger.info("VLM fallback raw: %s", content[:500])
        return self._parse_json_response(content) or {"action": "failed", "reason": "VLM 解析失败"}

    async def _ask_uitars_grounding(self, img_b64: str, task_desc: str) -> dict:
        """UI-TARS grounding：给截图和任务描述，返回标准 {"action":"click","x":...,"y":...} 格式。
        坐标为归一化 0~1000，与现有 _norm_to_screen 兼容。
        """
        _UITARS_SYSTEM = (
            "You are a GUI agent. Given a screenshot and a task, output the next action.\n\n"
            "## Output Format\n"
            "Thought: <brief reasoning>\n"
            "Action: action_type(param)\n\n"
            "## Action Space\n"
            "click(start_box='<|box_start|>(x,y)<|box_end|>')  # x,y in 0~1000\n"
            "type(content='text')\n"
            "key(key='Return')\n"
            "finished(content='done')\n"
        )
        messages = [
            {"role": "system", "content": _UITARS_SYSTEM},
            {"role": "user", "content": [
                {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{img_b64}"}},
                {"type": "text", "text": f"Task: {task_desc}"},
            ]},
        ]
        headers = {"Content-Type": "application/json"}
        if UITARS_API_KEY and UITARS_API_KEY != "not-needed":
            headers["Authorization"] = f"Bearer {UITARS_API_KEY}"

        payload = {"model": UITARS_MODEL, "messages": messages,
                   "temperature": 0.0, "max_tokens": 256}
        url = f"{UITARS_BASE_URL}/chat/completions"
        resp = await self._uitars_client.post(url, json=payload, headers=headers)
        resp.raise_for_status()

        raw = resp.json()["choices"][0]["message"]["content"].strip()
        logger.info("UI-TARS raw: %s", raw[:300])

        # 解析 Action: click(start_box='<|box_start|>(x,y)<|box_end|>')
        action_m = re.search(r"Action:\s*(\w+)\((.+)\)\s*$", raw, re.M)
        if not action_m:
            return {"action": "failed", "reason": f"UI-TARS 无法解析: {raw[:100]}"}

        action_type = action_m.group(1)
        params_raw = action_m.group(2)

        if action_type == "click":
            coord_m = re.search(r"\((\d+),\s*(\d+)\)", params_raw)
            if coord_m:
                return {"action": "click",
                        "x": int(coord_m.group(1)),
                        "y": int(coord_m.group(2))}
        elif action_type == "type":
            content_m = re.search(r"content='([^']*)'", params_raw)
            if content_m:
                return {"action": "type", "text": content_m.group(1)}
        elif action_type == "key":
            key_m = re.search(r"key='([^']*)'", params_raw)
            if key_m:
                key = key_m.group(1).lower()
                key_map = {"return": ["enter"], "escape": ["esc"]}
                return {"action": "hotkey", "keys": key_map.get(key, [key])}
        elif action_type == "finished":
            return {"action": "done"}

        return {"action": "failed", "reason": f"UI-TARS 未知动作: {action_type}"}

    async def _execute_click_step_uitars(
        self, parsed: dict, task_dir: str, step_idx: int, step_logs: list[str],
        *, double_click: bool = False,
    ) -> None:
        """UI-TARS 优先 click：直接截图发给 UI-TARS 定位，失败则 OCR 兜底。"""
        target = parsed.get("target", "")
        action_label = "double-click" if double_click else "click"
        click_fn = pyautogui.doubleClick if double_click else pyautogui.click
        pil_img = await asyncio.to_thread(self._screenshot)
        img_b64 = self._image_to_base64(pil_img)
        self._save_image(task_dir, f"step_{step_idx:03d}_uitars.png", img_b64)

        action = await self._ask_uitars_grounding(img_b64, f"{'双击' if double_click else '点击'} \"{target}\"")
        if action.get("action") == "click":
            desc = await asyncio.to_thread(self._perform_action, action)
            step_logs.append(f"  UI-TARS {action_label} \"{target}\" → {desc}")
            if double_click:
                # UI-TARS 返回单次 click，需要再点一次实现双击
                await asyncio.to_thread(self._perform_action, action)
            return

        # OCR 兜底
        step_logs.append(f"  UI-TARS miss \"{target}\", OCR fallback")
        ocr_items = await asyncio.to_thread(self._ocr_detect_raw, pil_img)
        best_item, best_score = None, 0
        for item in ocr_items:
            score = self._fuzzy_match_score(target, item["text"])
            if score > best_score:
                best_score, best_item = score, item
        if best_item and best_score >= 60:
            sx, sy = self._norm_to_screen(best_item["nx"], best_item["ny"])
            step_logs.append(f"  OCR fallback {action_label} \"{target}\" ({best_score}) → ({sx},{sy})")
            await asyncio.to_thread(click_fn, sx, sy)
        else:
            step_logs.append(f"  ❌ 无法定位 \"{target}\"")

    async def _execute_input_step_uitars(
        self, parsed: dict, task_dir: str, step_idx: int, step_logs: list[str],
    ) -> None:
        """UI-TARS 优先 input：截图发给 UI-TARS 定位输入框，失败则 OCR+YOLO 兜底。"""
        field_name = parsed.get("field")
        value = parsed["value"]
        press_enter = parsed.get("enter", False)

        pil_img = await asyncio.to_thread(self._screenshot)
        img_b64 = self._image_to_base64(pil_img)
        self._save_image(task_dir, f"step_{step_idx:03d}_uitars.png", img_b64)

        task_desc = f"点击 \"{field_name}\" 输入框" if field_name else "点击命令输入框（屏幕上方）"
        action = await self._ask_uitars_grounding(img_b64, task_desc)

        if action.get("action") == "click":
            desc = await asyncio.to_thread(self._perform_action, action)
            step_logs.append(f"  UI-TARS input \"{field_name}\" → {desc}")
        else:
            # OCR+YOLO 兜底
            step_logs.append(f"  UI-TARS miss \"{field_name}\", OCR+YOLO fallback")
            ocr_items = await asyncio.to_thread(self._ocr_detect_raw, pil_img)
            input_boxes = await asyncio.to_thread(self._detect_input_boxes, pil_img)
            pos = self._find_field_by_ocr(ocr_items, field_name, input_boxes) if field_name else None
            if pos:
                nx, ny = pos
                sx, sy = self._norm_to_screen(nx, ny)
                step_logs.append(f"  OCR fallback \"{field_name}\" → ({sx},{sy})")
                await asyncio.to_thread(pyautogui.click, sx, sy)
            else:
                step_logs.append(f"  ❌ 无法定位 \"{field_name}\"")
                return

        await asyncio.sleep(0.3)
        await asyncio.to_thread(pyautogui.hotkey, "command", "a")
        await asyncio.sleep(0.1)
        await asyncio.to_thread(self._perform_action, {"action": "type", "text": value})
        step_logs.append(f"  输入: \"{value}\"")

        if press_enter:
            await asyncio.sleep(0.3)
            await asyncio.to_thread(self._perform_action, {"action": "hotkey", "keys": ["enter"]})
            step_logs.append("  执行: hotkey(enter)")

    @staticmethod
    def _parse_json_response(text: str) -> dict | None:
        """从 VLM 响应中提取 JSON。"""
        text = re.sub(r'<think>.*?</think>', '', text, flags=re.DOTALL).strip()

        def _try_parse(s: str) -> dict | None:
            try:
                obj = json.loads(s)
                return obj if isinstance(obj, dict) else None
            except (json.JSONDecodeError, ValueError):
                return None

        # 1. 直接解析
        result = _try_parse(text)
        if result:
            return result

        # 2. 代码块
        m = re.search(r'```(?:json)?\s*(\{.*?\})\s*```', text, re.DOTALL)
        if m:
            result = _try_parse(m.group(1))
            if result:
                return result

        # 3. 花括号提取
        first = text.find("{")
        last = text.rfind("}")
        if first != -1 and last > first:
            snippet = text[first:last + 1]
            result = _try_parse(snippet)
            if result:
                return result

            # 4. 容错修复：VLM 常见的 JSON 畸形
            #    - 多余的尾部大括号: {"a":1}}  → {"a":1}
            #    - 缺少属性名引号:  { x":1}   → {"x":1}
            #    - 单引号:          {'a': 1}  → {"a": 1}
            fixed = snippet
            # 去掉多余的尾部 }
            while fixed.count("}") > fixed.count("{"):
                fixed = fixed[:fixed.rfind("}")]  + ""
            # 修复缺少左引号的 key:  , x": 或 { x":
            fixed = re.sub(r'([{,]\s*)(\w+)"(\s*:)', r'\1"\2"\3', fixed)
            # 单引号 → 双引号
            fixed = fixed.replace("'", '"')
            result = _try_parse(fixed)
            if result:
                logger.debug("JSON fixed: %s → %s", snippet[:100], fixed[:100])
                return result

        return None

    # ---- 动作执行 ----

    def _perform_action(self, action: dict) -> str:
        act = action.get("action", "")

        if act == "click":
            x, y = self._norm_to_screen(action["x"], action["y"])
            pyautogui.click(x, y)
            return f"click({x}, {y}) [norm: {action['x']},{action['y']}]"

        elif act == "double_click":
            x, y = self._norm_to_screen(action["x"], action["y"])
            pyautogui.doubleClick(x, y)
            return f"double_click({x}, {y})"

        elif act == "type":
            text = action.get("text", "")
            import pyperclip
            pyperclip.copy(text)
            pyautogui.hotkey("command", "v")
            return f"type('{text}')"

        elif act == "hotkey":
            keys = action.get("keys", [])
            pyautogui.hotkey(*keys)
            return f"hotkey({', '.join(keys)})"

        elif act == "scroll":
            direction = action.get("direction", "down")
            amount = int(action.get("amount", 3))
            clicks = -amount if direction == "down" else amount
            pyautogui.scroll(clicks)
            return f"scroll({direction}, {amount})"

        elif act in ("done", "failed", "retry", "not_found"):
            return act

        return f"unknown: {act}"

    # ---- 主循环 ----

    async def _do_execute(self, task_id: str, prompt: str) -> ExecutionResult:
        self._stopped[task_id] = False
        task_dir = os.path.join(ARTIFACTS_DIR, task_id)
        os.makedirs(task_dir, exist_ok=True)

        steps = self._parse_steps_from_prompt(prompt)
        if not steps:
            return ExecutionResult(success=False, error="未解析到有效步骤")

        logger.info("Task %s: %d steps", task_id, len(steps))

        await self._activate_sap_window()

        video_path = os.path.join(task_dir, "recording.mp4")
        await self._recorder.start(video_path)

        step_logs: list[str] = []
        all_start = time.time()

        # 当前页面地图（预处理结果），页面切换时重新分析
        page_map: dict | None = None
        # OCR 模式：字段映射表和当前滚动偏移
        field_map: dict | None = None  # {field_name: {"nx", "ny", "scroll_offset"}}
        current_scroll: int = 0
        last_field: str | None = None  # 上一步操作的字段名，用于判断 Tab 连续性
        # OCR+YOLO 缓存：同页面连续输入步骤复用
        cached_ocr: list | None = None
        cached_boxes: list | None = None
        cached_img: Image.Image | None = None
        max_error_retries = 2  # 同一个错误最多重试几次
        error_retry_count: dict[int, int] = {}  # step_idx → 已重试次数

        try:
            step_idx = 0
            while step_idx < len(steps):
                step_idx += 1
                if self._stopped.get(task_id):
                    break
                if time.time() - all_start > AGENT_TARS_TIMEOUT:
                    step_logs.append("⏰ 总超时")
                    break

                step_desc = steps[step_idx - 1]
                logger.info("━━━ Step %d/%d: %s", step_idx, len(steps), step_desc[:80])
                step_logs.append(f"[Step {step_idx}] {step_desc}")

                parsed = self._parse_step(step_desc)
                step_type = parsed["type"]

                # ---- 纯按键：直接执行 ----
                if step_type == "hotkey":
                    desc = await asyncio.to_thread(
                        self._perform_action, {"action": "hotkey", "keys": parsed["keys"]})
                    step_logs.append(f"  ⚡ {desc}")
                    if parsed["keys"] == ["enter"]:
                        page_map = None
                        field_map = None
                        current_scroll = 0
                        last_field = None
                        cached_ocr = cached_boxes = cached_img = None
                        await self._wait_page_stable(step_logs, after_enter=True)
                    else:
                        await asyncio.sleep(0.5)
                    continue

                # ---- 需要页面地图的步骤：确保已预处理 ----
                needs_map = not USE_OCR_PRIMARY and not USE_UITARS_PRIMARY and (
                    step_type == "click" or
                    (step_type == "input" and parsed.get("field") is not None)
                )
                if needs_map and page_map is None:
                    page_map, step_logs = await self._do_page_analysis(
                        task_dir, step_idx, step_logs)

                # ---- 输入类步骤 ----
                if step_type == "input":
                    if USE_UITARS_PRIMARY:
                        # UI-TARS 优先定位
                        await self._execute_input_step_uitars(
                            parsed, task_dir, step_idx, step_logs,
                        )
                    elif USE_OCR_PRIMARY and parsed.get("field") is None:
                        # 搜索框/命令框：VLM 定位
                        await self._execute_input_step_vlm(
                            parsed, task_dir, step_idx, step_logs,
                        )
                    elif USE_OCR_PRIMARY and parsed.get("field") is not None:
                        cached_ocr, cached_boxes, cached_img = await self._execute_input_step_ocr(
                            parsed, task_dir, step_idx, step_logs,
                            cached_ocr, cached_boxes, cached_img,
                        )
                    else:
                        await self._execute_input_step(
                            parsed, page_map, last_field,
                            task_dir, step_idx, step_logs,
                        )
                    last_field = parsed.get("field")

                    if parsed.get("enter"):
                        await self._wait_page_stable(step_logs, after_enter=True)
                        # ---- 错误检测 + 重试 ----
                        error_info = await self._check_for_error(
                            task_dir, step_idx, step_logs)
                        if error_info:
                            err_msg = error_info.get("error_message", "未知错误")
                            err_field = error_info.get("related_field")
                            step_logs.append(f"  🚨 检测到错误: {err_msg}")
                            step_logs.append(f"     相关字段: {err_field or '未知'}")
                            logger.warning("Error detected: %s, field: %s", err_msg, err_field)

                            # 找到出错字段对应的步骤，回退重新执行
                            retry_idx = self._find_step_for_field(steps, err_field)
                            if retry_idx is not None and retry_idx < step_idx:
                                count = error_retry_count.get(retry_idx, 0)
                                if count < max_error_retries:
                                    error_retry_count[retry_idx] = count + 1
                                    step_logs.append(
                                        f"  🔄 回退到 Step {retry_idx + 1} 重新执行 (第{count+1}次)")
                                    step_idx = retry_idx  # while 循环会 +1
                                    page_map = None
                                    field_map = None
                                    current_scroll = 0
                                    last_field = None
                                    continue

                            # 无法恢复（找不到字段 或 重试次数用完），停止执行
                            step_logs.append(f"  ❌ 无法恢复，停止执行")
                            await self._finish(task_dir, step_logs)
                            await self._recorder.stop()
                            return ExecutionResult(
                                success=False, stdout="\n".join(step_logs),
                                error=f"Step {step_idx} 错误: {err_msg}",
                                step_logs=step_logs, return_code=1,
                            )

                        page_map = None
                        field_map = None
                        current_scroll = 0
                        last_field = None
                        cached_ocr = cached_boxes = cached_img = None
                    else:
                        await asyncio.sleep(0.3)
                    continue

                # ---- 点击类步骤 ----
                if step_type == "click":
                    if USE_UITARS_PRIMARY:
                        await self._execute_click_step_uitars(
                            parsed, task_dir, step_idx, step_logs)
                    else:
                        await self._execute_click_step(
                            parsed, task_dir, step_idx, step_logs)
                    page_map = None
                    field_map = None
                    current_scroll = 0
                    last_field = None
                    cached_ocr = cached_boxes = cached_img = None
                    if parsed.get("no_wait"):
                        # 菜单弹出类：等待足够时间让菜单完全渲染
                        await asyncio.sleep(1.5)
                        step_logs.append("  (menu click, wait 1.5s for menu render)")
                    else:
                        # 先固定等待让弹出菜单/对话框有时间渲染，再检测稳定
                        await asyncio.sleep(0.8)
                        await self._wait_page_stable(step_logs)
                    continue

                # ---- 双击类步骤 ----
                if step_type == "double_click":
                    if USE_UITARS_PRIMARY:
                        await self._execute_click_step_uitars(
                            parsed, task_dir, step_idx, step_logs,
                            double_click=True)
                    else:
                        await self._execute_click_step(
                            parsed, task_dir, step_idx, step_logs,
                            double_click=True)
                    page_map = None
                    field_map = None
                    current_scroll = 0
                    last_field = None
                    cached_ocr = cached_boxes = cached_img = None
                    await asyncio.sleep(0.8)
                    await self._wait_page_stable(step_logs)
                    continue

                # ---- 搜索类步骤：定位搜索框 → 点击 → 输入 ----
                if step_type == "click_and_input":
                    if USE_UITARS_PRIMARY:
                        # 复用 uitars input 逻辑
                        await self._execute_input_step_uitars(
                            parsed, task_dir, step_idx, step_logs)
                    else:
                        await self._execute_click_and_input_step(
                            parsed, task_dir, step_idx, step_logs)
                    if parsed.get("enter"):
                        page_map = None
                        field_map = None
                        current_scroll = 0
                        last_field = None
                        cached_ocr = cached_boxes = cached_img = None
                        await self._wait_page_stable(step_logs)
                    else:
                        await asyncio.sleep(0.5)
                    continue

                # ---- 等待/确认类步骤 ----
                if step_type == "wait":
                    await self._execute_wait_step(
                        step_desc, task_dir, step_idx, step_logs)
                    continue

        except Exception as e:
            logger.exception("Error in task %s: %s", task_id, e)
            step_logs.append(f"\n❌ 异常: {str(e)}")

        await self._recorder.stop()
        self._stopped.pop(task_id, None)
        await self._finish(task_dir, step_logs)

        has_error = any("❌" in l for l in step_logs)
        return ExecutionResult(
            success=not has_error, stdout="\n".join(step_logs),
            step_logs=step_logs, return_code=1 if has_error else 0,
        )

    # ---- 页面分析 ----

    async def _do_page_analysis(self, task_dir: str, step_idx: int,
                                step_logs: list[str]) -> tuple[dict, list[str]]:
        """截屏 → OCR + VLM 同时分析页面，返回页面地图。"""
        step_logs.append("  📸 页面预处理...")
        logger.info("Page analysis for step %d", step_idx)

        await asyncio.sleep(VLM_SCREENSHOT_DELAY)
        pil_img = await asyncio.to_thread(self._screenshot)
        img_b64 = self._image_to_base64(pil_img)
        self._save_image(task_dir, f"page_analysis_step{step_idx:03d}.png", img_b64)

        # OCR
        ocr_items = await asyncio.to_thread(self._ocr_detect_raw, pil_img)
        logger.info("OCR found %d items", len(ocr_items))

        # OpenCV 输入框检测
        input_boxes = await asyncio.to_thread(self._detect_input_boxes, pil_img)

        # VLM 分析页面结构（用 OCR + OpenCV 校准坐标）
        try:
            page_map = await self._analyze_page(img_b64, ocr_items, input_boxes)
        except Exception as e:
            logger.warning("VLM page analysis failed: %s", e)
            page_map = {"fields": [], "buttons": [], "page_title": "unknown"}

        fields = page_map.get("fields", [])
        buttons = page_map.get("buttons", [])
        title = page_map.get("page_title", "")
        step_logs.append(
            f"  📋 页面: {title} | {len(fields)} 个字段, {len(buttons)} 个按钮")
        for f in fields:
            verified = "✓" if f.get("_ocr_verified") else "?"
            step_logs.append(
                f"     [{verified}] {f.get('label', '?')} → ({f.get('input_x', '?')}, {f.get('input_y', '?')})")
        logger.info("Page map: %d fields, %d buttons", len(fields), len(buttons))

        # 缓存 OCR 结果供后续使用
        page_map["_ocr_items"] = ocr_items
        page_map["_img_b64"] = img_b64
        return page_map, step_logs

    # ---- OCR 模式：预扫描页面字段（支持多屏滚动） ----

    async def _scan_page_fields(
        self, task_dir: str, step_idx: int, step_logs: list[str],
        target_fields: list[str],
    ) -> dict:
        """OCR + YOLO 扫描页面字段，支持多屏滚动。
        Returns field_map: {field_name: {"nx", "ny", "scroll_offset"}}
        """
        step_logs.append(f"  scan page: {len(target_fields)} fields")
        field_map: dict[str, dict] = {}
        found = set()

        # ---- 第一屏 ----
        await asyncio.sleep(VLM_SCREENSHOT_DELAY)
        pil_img = await asyncio.to_thread(self._screenshot)
        img_b64 = self._image_to_base64(pil_img)
        self._save_image(task_dir, f"scan_step{step_idx:03d}_s0.png", img_b64)
        ocr_items = await asyncio.to_thread(self._ocr_detect_raw, pil_img)
        input_boxes = await asyncio.to_thread(self._detect_input_boxes, pil_img)

        for fname in target_fields:
            if fname in found:
                continue
            pos = self._find_field_by_ocr(ocr_items, fname, input_boxes)
            if pos:
                field_map[fname] = {"nx": pos[0], "ny": pos[1], "scroll_offset": 0}
                found.add(fname)

        # ---- 滚动查找剩余字段 ----
        scroll_offset = 0
        while len(found) < len(target_fields) and scroll_offset < AUTO_SCROLL_MAX:
            scroll_offset += 1
            step_logs.append(f"  scan scroll down (offset {scroll_offset})")
            await asyncio.to_thread(pyautogui.scroll, -AUTO_SCROLL_AMOUNT)
            await asyncio.sleep(0.5)

            pil_img = await asyncio.to_thread(self._screenshot)
            img_b64 = self._image_to_base64(pil_img)
            self._save_image(task_dir, f"scan_step{step_idx:03d}_s{scroll_offset}.png", img_b64)
            ocr_items = await asyncio.to_thread(self._ocr_detect_raw, pil_img)
            input_boxes = await asyncio.to_thread(self._detect_input_boxes, pil_img)

            for fname in target_fields:
                if fname in found:
                    continue
                pos = self._find_field_by_ocr(ocr_items, fname, input_boxes)
                if pos:
                    field_map[fname] = {"nx": pos[0], "ny": pos[1], "scroll_offset": scroll_offset}
                    found.add(fname)

        # Scroll back to top
        if scroll_offset > 0:
            for _ in range(scroll_offset):
                await asyncio.to_thread(pyautogui.scroll, AUTO_SCROLL_AMOUNT)
                await asyncio.sleep(0.3)
            step_logs.append("  scrolled back to top")

        missing = [f for f in target_fields if f not in found]
        if missing:
            step_logs.append(f"  scan missed: {missing}")

        step_logs.append(f"  scan done: {len(found)}/{len(target_fields)} fields")
        for fname, info in field_map.items():
            step_logs.append(
                f"     {fname} -> ({info['nx']},{info['ny']}) scroll={info['scroll_offset']}")

        return field_map

    # ---- VLM 定位搜索框/命令框（无字段名） ----

    async def _execute_input_step_vlm(
        self, parsed: dict, task_dir: str, step_idx: int, step_logs: list[str],
    ) -> None:
        """无字段名的输入步骤：用 VLM 定位搜索框/命令框，点击后输入。"""
        value = parsed["value"]
        press_enter = parsed.get("enter", False)

        pil_img = await asyncio.to_thread(self._screenshot)
        img_b64 = self._image_to_base64(pil_img)
        self._save_image(task_dir, f"step_{step_idx:03d}_vlm.png", img_b64)
        ocr_items = await asyncio.to_thread(self._ocr_detect_raw, pil_img)
        ocr_text = self._ocr_to_text(ocr_items)

        try:
            if USE_UITARS_GROUNDING:
                action = await self._ask_uitars_grounding(
                    img_b64, "点击屏幕上方的命令输入框")
            else:
                action = await self._ask_vlm_fallback(
                    img_b64, "请点击命令输入框（屏幕上方的输入框）", ocr_text)
        except Exception as e:
            step_logs.append(f"  ❌ VLM定位命令输入框失败: {e}")
            return

        if action.get("action") == "click":
            desc = await asyncio.to_thread(self._perform_action, action)
            step_logs.append(f"  🎯 VLM定位命令输入框: {desc}")
            await asyncio.sleep(0.3)
        else:
            step_logs.append(f"  ❌ VLM定位命令输入框失败: {action}")
            return

        # 全选清空 + 输入
        await asyncio.to_thread(pyautogui.hotkey, "command", "a")
        await asyncio.sleep(0.1)
        await asyncio.to_thread(
            self._perform_action, {"action": "type", "text": value})
        step_logs.append(f"  输入: \"{value}\"")

        if press_enter:
            await asyncio.sleep(0.3)
            await asyncio.to_thread(
                self._perform_action, {"action": "hotkey", "keys": ["enter"]})
            step_logs.append("  执行: hotkey(enter)")

    async def _execute_input_step_ocr(
        self, parsed: dict, task_dir: str, step_idx: int,
        step_logs: list[str],
        cached_ocr: list[dict] | None = None,
        cached_boxes: list[dict] | None = None,
        cached_img: Image.Image | None = None,
    ) -> tuple[list[dict] | None, list[dict] | None, Image.Image | None]:
        """OCR + YOLO 定位字段输入框。支持缓存复用，返回 (ocr_items, input_boxes, pil_img) 供后续步骤复用。"""
        field_name = parsed["field"]
        value = parsed["value"]
        press_enter = parsed.get("enter", False)

        # 复用缓存或重新截图
        if cached_ocr is not None and cached_boxes is not None and cached_img is not None:
            pil_img = cached_img
            ocr_items = cached_ocr
            input_boxes = cached_boxes
            step_logs.append(f"  (reuse cached OCR+YOLO)")
        else:
            pil_img = await asyncio.to_thread(self._screenshot)
            img_b64 = self._image_to_base64(pil_img)
            self._save_image(task_dir, f"step_{step_idx:03d}_ocr.png", img_b64)
            ocr_items = await asyncio.to_thread(self._ocr_detect_raw, pil_img)
            input_boxes = await asyncio.to_thread(self._detect_input_boxes, pil_img)

        pos = self._find_field_by_ocr(ocr_items, field_name, input_boxes)

        # 找不到就滚动查找（滚动后缓存失效）
        if pos is None:
            for scroll_i in range(1, AUTO_SCROLL_MAX + 1):
                step_logs.append(f"  \"{field_name}\" not found, scroll down ({scroll_i})")
                await asyncio.to_thread(pyautogui.scroll, -AUTO_SCROLL_AMOUNT)
                await asyncio.sleep(0.5)
                pil_img = await asyncio.to_thread(self._screenshot)
                ocr_items = await asyncio.to_thread(self._ocr_detect_raw, pil_img)
                input_boxes = await asyncio.to_thread(self._detect_input_boxes, pil_img)
                pos = self._find_field_by_ocr(ocr_items, field_name, input_boxes)
                if pos:
                    break

        if pos:
            nx, ny = pos
            sx, sy = self._norm_to_screen(nx, ny)
            step_logs.append(f"  \"{field_name}\" -> ({sx},{sy}) [norm:{nx},{ny} img:{pil_img.size}]")
            await asyncio.to_thread(pyautogui.click, sx, sy)
            await asyncio.sleep(0.3)
        else:
            # VLM fallback — 缓存失效
            step_logs.append(f"  OCR+YOLO miss \"{field_name}\", {'UI-TARS' if USE_UITARS_GROUNDING else 'VLM'} fallback")
            img_b64 = self._image_to_base64(pil_img)
            ocr_text = self._ocr_to_text(ocr_items)
            try:
                if USE_UITARS_GROUNDING:
                    action = await self._ask_uitars_grounding(
                        img_b64, f"点击 \"{field_name}\" 输入框")
                else:
                    action = await self._ask_vlm_fallback(
                        img_b64, f"please click \"{field_name}\" input box", ocr_text)
                if action.get("action") == "click":
                    desc = await asyncio.to_thread(self._perform_action, action)
                    step_logs.append(f"  fallback: {desc}")
                    await asyncio.sleep(0.3)
                else:
                    step_logs.append(f"  fallback failed: {action}")
                    return None, None, None
            except Exception as e:
                step_logs.append(f"  fallback error: {e}")
                return None, None, None

        # 全选 + 输入
        await asyncio.to_thread(pyautogui.hotkey, "command", "a")
        await asyncio.sleep(0.1)
        await asyncio.to_thread(
            self._perform_action, {"action": "type", "text": value})
        step_logs.append(f"  typed: \"{value}\"")

        if press_enter:
            await asyncio.sleep(0.3)
            await asyncio.to_thread(
                self._perform_action, {"action": "hotkey", "keys": ["enter"]})
            step_logs.append("  hotkey(enter)")
            return None, None, None  # Enter 后页面变化，缓存失效

        return ocr_items, input_boxes, pil_img

    # ---- 执行输入步骤（原有逻辑） ----

    async def _execute_input_step(
        self, parsed: dict, page_map: dict, last_field: str | None,
        task_dir: str, step_idx: int, step_logs: list[str],
    ) -> None:
        field_name = parsed.get("field")
        value = parsed["value"]
        press_enter = parsed.get("enter", False)

        # 无字段名（如"命令输入框"）：直接输入
        if field_name is None:
            step_logs.append(f"  ⚡ 直接输入 \"{value}\"")
            await asyncio.to_thread(
                self._perform_action, {"action": "type", "text": value})
            if press_enter:
                await asyncio.sleep(0.3)
                await asyncio.to_thread(
                    self._perform_action, {"action": "hotkey", "keys": ["enter"]})
                step_logs.append("  执行: hotkey(enter)")
            return

        # 判断是否可以用 Tab（上一步字段的下一个就是当前字段）
        use_tab = False
        if last_field and self._is_next_field(page_map, last_field, field_name):
            use_tab = True

        if use_tab:
            # Tab 到下一个字段
            step_logs.append(f"  ⏭️ Tab（{last_field} → {field_name}）")
            await asyncio.to_thread(
                self._perform_action, {"action": "hotkey", "keys": ["tab"]})
            await asyncio.sleep(0.3)
        else:
            # 从页面地图中找字段坐标，点击定位
            fld = self._find_field_in_map(page_map, field_name)
            if fld and fld.get("input_x") is not None:
                nx, ny = fld["input_x"], fld["input_y"]
                sx, sy = self._norm_to_screen(nx, ny)
                step_logs.append(
                    f"  🎯 点击定位 \"{field_name}\" → ({sx},{sy}) [norm:{nx},{ny}]")
                await asyncio.to_thread(pyautogui.click, sx, sy)
                await asyncio.sleep(0.3)
            else:
                # 页面地图里没有，用 OCR 直接找
                ocr_items = page_map.get("_ocr_items", [])
                pil_img_cached = page_map.get("_pil_img")
                pos = self._find_field_by_ocr(ocr_items, field_name, pil_img=pil_img_cached)
                if pos:
                    nx, ny = pos
                    sx, sy = self._norm_to_screen(nx, ny)
                    step_logs.append(
                        f"  🎯 OCR定位 \"{field_name}\" → ({sx},{sy}) [norm:{nx},{ny}]")
                    await asyncio.to_thread(pyautogui.click, sx, sy)
                    await asyncio.sleep(0.3)
                else:
                    # 尝试滚动查找：字段可能在滚动区域下方
                    found_by_scroll = False
                    for scroll_attempt in range(1, AUTO_SCROLL_MAX + 1):
                        step_logs.append(f"  🔽 滚动查找 \"{field_name}\"（第{scroll_attempt}次）")
                        await asyncio.to_thread(
                            pyautogui.scroll, -AUTO_SCROLL_AMOUNT)
                        await asyncio.sleep(0.5)

                        pil_img = await asyncio.to_thread(self._screenshot)
                        scroll_ocr = await asyncio.to_thread(
                            self._ocr_detect_raw, pil_img)
                        pos = self._find_field_by_ocr(scroll_ocr, field_name, pil_img=pil_img)
                        if pos:
                            nx, ny = pos
                            sx, sy = self._norm_to_screen(nx, ny)
                            step_logs.append(
                                f"  🎯 滚动后OCR定位 \"{field_name}\" → ({sx},{sy})")
                            await asyncio.to_thread(pyautogui.click, sx, sy)
                            await asyncio.sleep(0.3)
                            found_by_scroll = True
                            # 更新 page_map 缓存
                            page_map["_ocr_items"] = scroll_ocr
                            page_map["_img_b64"] = self._image_to_base64(pil_img)
                            break

                    if not found_by_scroll:
                        # 滚动也找不到，grounding 兜底
                        mode = "UI-TARS" if USE_UITARS_GROUNDING else "VLM"
                        step_logs.append(
                            f"  ⚠️ 地图/OCR/滚动都找不到 \"{field_name}\"，{mode}兜底")
                        img_b64 = page_map.get("_img_b64", "")
                        try:
                            if USE_UITARS_GROUNDING:
                                pil_snap = await asyncio.to_thread(self._screenshot)
                                img_b64 = self._image_to_base64(pil_snap)
                                action = await self._ask_uitars_grounding(
                                    img_b64, f"点击 \"{field_name}\" 输入框")
                            else:
                                ocr_text = self._ocr_to_text(
                                    page_map.get("_ocr_items", []))
                                action = await self._ask_vlm_fallback(
                                    img_b64,
                                    f"请点击 \"{field_name}\" 输入框",
                                    ocr_text,
                                )
                            if action.get("action") == "click":
                                desc = await asyncio.to_thread(
                                    self._perform_action, action)
                                step_logs.append(f"  {mode}兜底: {desc}")
                                await asyncio.sleep(0.3)
                            else:
                                step_logs.append(
                                    f"  ❌ {mode}兜底失败: {action}")
                                return
                        except Exception as e:
                            step_logs.append(f"  ❌ {mode}兜底异常: {e}")
                            return

        # 全选清空 + 输入
        await asyncio.to_thread(pyautogui.hotkey, "command", "a")
        await asyncio.sleep(0.1)
        await asyncio.to_thread(
            self._perform_action, {"action": "type", "text": value})
        step_logs.append(f"  输入: \"{value}\"")

        if press_enter:
            await asyncio.sleep(0.3)
            await asyncio.to_thread(
                self._perform_action, {"action": "hotkey", "keys": ["enter"]})
            step_logs.append("  执行: hotkey(enter)")

    @staticmethod
    def _find_field_by_ocr(
        ocr_items: list[dict], field_name: str,
        input_boxes: list[dict] | None = None,
        pil_img: Image.Image | None = None,
    ) -> tuple[int, int] | None:
        """OCR 找标签 + YOLO 框匹配输入框。

        1. OCR fuzzy match 找到标签位置
        2. 在 YOLO 框里找同行右侧最近的框 → 点击框左侧
        3. Fallback: OCR 文本布局估算
        """
        ROW_THRESHOLD = 30

        # Step 1: fuzzy match — 收集所有高分候选
        best, best_score = None, 0
        candidates: list[dict] = []
        for item in ocr_items:
            score = VLMExecutor._fuzzy_match_score(field_name, item["text"])
            if score > best_score:
                best_score = score
                best = item
                candidates = [item]
            elif score == best_score and best is not None:
                candidates.append(item)
                if abs(len(item["text"]) - len(field_name)) < abs(len(best["text"]) - len(field_name)):
                    best = item

        # 同分多候选：OCR 无法可靠区分，返回 None 让上层走 VLM/UI-TARS fallback
        if len(candidates) > 1 and best_score >= 50:
            logger.info("OCR match '%s': %d candidates with same score=%d, defer to VLM",
                        field_name, len(candidates), best_score)
            return None

        logger.info("OCR match '%s': best='%s' score=%d (candidates=%d)",
                    field_name, best["text"] if best else "None", best_score, len(candidates))

        # Step 1b: merge adjacent items on same row to handle split labels
        if best_score < 50:
            sorted_items = sorted(ocr_items, key=lambda it: (it["ny"], it["x_min"]))
            for i, a in enumerate(sorted_items):
                for j in range(i + 1, min(i + 3, len(sorted_items))):
                    b = sorted_items[j]
                    if abs(a["ny"] - b["ny"]) > ROW_THRESHOLD:
                        break
                    gap = b["x_min"] - a["x_max"]
                    if gap < -10 or gap > 50:
                        continue
                    merged_text = a["text"] + b["text"]
                    score = VLMExecutor._fuzzy_match_score(field_name, merged_text)
                    if score > best_score:
                        best_score = score
                        best = {
                            "text": merged_text,
                            "nx": (a["nx"] + b["nx"]) // 2,
                            "ny": (a["ny"] + b["ny"]) // 2,
                            "x_min": a["x_min"],
                            "x_max": b["x_max"],
                            "y_min": min(a["y_min"], b["y_min"]),
                            "y_max": max(a["y_max"], b["y_max"]),
                        }

        if best is None or best_score < 50:
            return None

        label_x_max = best["x_max"]
        label_y = best["ny"]
        logger.info("  label '%s' pos: x_max=%d, y=%d", best["text"], label_x_max, label_y)

        # Step 2: YOLO 框匹配 — 同行右侧最近的框，且宽度足够（排除小图标）
        if input_boxes:
            best_box, best_dist, best_dy = None, 9999, 9999
            for box in input_boxes:
                bw = box["x_max"] - box["x_min"]
                if bw < 40:  # 过滤宽度太小的框（图标、复选框等）
                    continue
                dy = abs(box["cy"] - label_y)
                if dy > ROW_THRESHOLD:
                    continue
                if box["x_min"] < label_x_max - 10:
                    continue
                dist = box["x_min"] - label_x_max
                if dist < best_dist or (dist == best_dist and dy < best_dy):
                    best_dist = dist
                    best_dy = dy
                    best_box = box
            if best_box is not None:
                click_x = best_box["x_min"] + 15
                logger.info("  YOLO match: box x=%d~%d cy=%d → click(%d,%d)",
                            best_box["x_min"], best_box["x_max"], best_box["cy"],
                            click_x, best_box["cy"])
                return click_x, best_box["cy"]

        # Step 3: fallback — estimate from OCR text layout
        next_x_min = 990
        for item in ocr_items:
            if item is best:
                continue
            if abs(item["ny"] - label_y) < 20 and item["x_min"] > label_x_max + 5:
                if item["x_min"] < next_x_min:
                    next_x_min = item["x_min"]

        label_width = label_x_max - best["x_min"]
        if next_x_min >= 900:
            input_x = label_x_max + max(label_width, 40)
        else:
            gap = next_x_min - label_x_max
            if gap <= 60:
                input_x = label_x_max + gap // 3
            else:
                input_x = (label_x_max + next_x_min) // 2
        return input_x, label_y

    # ---- 执行点击类步骤 ----

    async def _execute_click_and_input_step(
        self, parsed: dict, task_dir: str, step_idx: int, step_logs: list[str],
    ) -> None:
        """OCR+OpenCV 优先定位搜索框/命令框 → 点击 → 输入 → 可选 Enter。
        策略：取 OpenCV 检测到的最顶部输入框（y_min 最小），VLM fallback。
        """
        target = parsed.get("target", "搜索框")
        value = parsed["value"]
        press_enter = parsed.get("enter", False)

        pil_img = await asyncio.to_thread(self._screenshot)
        img_b64 = self._image_to_base64(pil_img)
        self._save_image(task_dir, f"step_{step_idx:03d}_search.png", img_b64)
        ocr_items = await asyncio.to_thread(self._ocr_detect_raw, pil_img)
        ocr_text = self._ocr_to_text(ocr_items)

        # 定位目标（UI-TARS 或 VLM）
        mode = "UI-TARS" if USE_UITARS_GROUNDING else "VLM"
        step_logs.append(f"  {mode} 定位 \"{target}\"")
        try:
            if USE_UITARS_GROUNDING:
                action = await self._ask_uitars_grounding(img_b64, f"点击 \"{target}\"")
            else:
                action = await self._ask_vlm_fallback(
                    img_b64, f"请点击 \"{target}\"", ocr_text)
        except Exception as e:
            step_logs.append(f"  ❌ {mode}定位 \"{target}\" 失败: {e}")
            return
        if action.get("action") == "click":
            desc = await asyncio.to_thread(self._perform_action, action)
            step_logs.append(f"  {mode}: {desc}")
        else:
            step_logs.append(f"  ❌ {mode}定位 \"{target}\" 失败: {action}")
            return

        await asyncio.sleep(0.3)

        # 全选清空 + 输入
        await asyncio.to_thread(pyautogui.hotkey, "command", "a")
        await asyncio.sleep(0.1)
        await asyncio.to_thread(
            self._perform_action, {"action": "type", "text": value})
        step_logs.append(f"  输入: \"{value}\"")

        if press_enter:
            await asyncio.sleep(0.3)
            await asyncio.to_thread(
                self._perform_action, {"action": "hotkey", "keys": ["enter"]})
            step_logs.append("  执行: hotkey(enter)")

    # ---- 执行点击步骤 ----

    async def _execute_click_step(
        self, parsed: dict, task_dir: str, step_idx: int,
        step_logs: list[str], *, double_click: bool = False,
    ) -> None:
        """OCR-first click: fresh screenshot + OCR to locate target, VLM fallback."""
        target = parsed.get("target", "")
        click_fn = pyautogui.doubleClick if double_click else pyautogui.click
        action_label = "double-click" if double_click else "click"

        pil_img = await asyncio.to_thread(self._screenshot)
        img_b64 = self._image_to_base64(pil_img)
        ocr_items = await asyncio.to_thread(self._ocr_detect_raw, pil_img)

        # Exact OCR match — 优先完全匹配，再选最短的包含匹配
        exact_matches = [item for item in ocr_items if item["text"] == target]
        contain_matches = [item for item in ocr_items if target in item["text"] and item["text"] != target]

        matched = None
        if exact_matches:
            matched = min(exact_matches, key=lambda i: (i["ny"], i["nx"]))
            sx, sy = self._norm_to_screen(matched["nx"], matched["ny"])
            step_logs.append(f"  OCR {action_label} \"{target}\" ~ \"{matched['text']}\" -> ({sx},{sy})")
            await asyncio.to_thread(click_fn, sx, sy)
            return
        elif contain_matches:
            # 包含匹配：按目标在文本中的位置比例推算坐标
            matched = min(contain_matches, key=lambda i: len(i["text"]))
            text = matched["text"]
            pos = text.find(target)
            ratio = (pos + len(target) / 2) / len(text)
            # 用文本框的左右边界插值
            nx = int(matched["x_min"] + ratio * (matched["x_max"] - matched["x_min"]))
            ny = matched["ny"]
            sx, sy = self._norm_to_screen(nx, ny)
            step_logs.append(f"  OCR {action_label} \"{target}\" in \"{text}\" ratio={ratio:.2f} -> ({sx},{sy})")
            await asyncio.to_thread(click_fn, sx, sy)
            return

        # Fuzzy OCR match
        best_item, best_score = None, 0
        for item in ocr_items:
            score = self._fuzzy_match_score(target, item["text"])
            if score > best_score:
                best_score = score
                best_item = item
        if best_item and best_score >= 60:
            sx, sy = self._norm_to_screen(best_item["nx"], best_item["ny"])
            step_logs.append(
                f"  OCR fuzzy {action_label} \"{target}\" ~ \"{best_item['text']}\" ({best_score}) -> ({sx},{sy})")
            await asyncio.to_thread(click_fn, sx, sy)
            return

        # VLM fallback
        step_logs.append(f"  OCR miss \"{target}\", {'UI-TARS' if USE_UITARS_GROUNDING else 'VLM'} fallback")
        ocr_text = self._ocr_to_text(ocr_items)
        try:
            if USE_UITARS_GROUNDING:
                action = await self._ask_uitars_grounding(img_b64, f"点击 \"{target}\"")
            else:
                action = await self._ask_vlm_fallback(
                    img_b64, f"click \"{target}\"", ocr_text)
            if action.get("action") == "click":
                desc = await asyncio.to_thread(self._perform_action, action)
                step_logs.append(f"  fallback: {desc}")
            else:
                step_logs.append(f"  fallback failed: {action}")
        except Exception as e:
            step_logs.append(f"  fallback error: {e}")

    # ---- 执行等待/确认步骤 ----

    async def _execute_wait_step(
        self, step_desc: str, task_dir: str, step_idx: int, step_logs: list[str],
    ) -> None:
        """等待类步骤：截屏 + OCR 检查目标文字是否出现。"""
        # 提取引号内的目标文字
        m = re.search(r'[\"\"\u201c]([^\"\"\u201d]+)[\"\"\u201d]', step_desc)
        target_text = m.group(1) if m else ""

        # 没有引号时，从描述里提取关键词
        if not target_text:
            for kw in ["已保存", "保存成功", "已更新", "成功", "完成"]:
                if kw in step_desc:
                    target_text = kw
                    break

        for attempt in range(1, 6):  # 最多等 5 次
            await asyncio.sleep(1.5)
            pil_img = await asyncio.to_thread(self._screenshot)
            img_b64 = self._image_to_base64(pil_img)
            self._save_image(task_dir, f"step_{step_idx:03d}_wait{attempt:02d}.png", img_b64)

            ocr_items = await asyncio.to_thread(self._ocr_detect_raw, pil_img)
            all_text = " ".join(it["text"] for it in ocr_items)

            if target_text and target_text in all_text:
                step_logs.append(f"  ✅ 检测到 \"{target_text}\"")
                return

            step_logs.append(f"  ⏳ 等待中... (第{attempt}次)")

        step_logs.append(f"  ⚠️ 等待超时，未检测到 \"{target_text}\"")

    # ---- 辅助 ----

    async def _finish(self, task_dir: str, step_logs: list[str]) -> None:
        try:
            with open(os.path.join(task_dir, "raw_output.txt"), "w", encoding="utf-8") as f:
                f.write("\n".join(step_logs))
        except Exception:
            pass

    @staticmethod
    def _parse_steps_from_prompt(prompt: str) -> list[str]:
        steps = []
        for line in prompt.strip().splitlines():
            line = line.strip()
            if line and len(line) > 2 and line[0].isdigit():
                for i, ch in enumerate(line):
                    if ch in ".、):：" or (ch == " " and i > 0):
                        steps.append(line[i + 1:].strip())
                        break
                else:
                    steps.append(line)
        return steps

    # ---- 兼容接口 ----

    def extract_screenshots(self, task_id: str, session_id: str) -> int:
        return 0

    def extract_live_screenshots(self, task_id: str) -> int:
        return 0

    def get_loop_summaries(self, task_id: str) -> list[dict]:
        task_dir = os.path.join(ARTIFACTS_DIR, task_id)
        log_path = os.path.join(task_dir, "raw_output.txt")
        if not os.path.isfile(log_path):
            return []
        try:
            with open(log_path, "r", encoding="utf-8") as f:
                content = f.read()
            return [
                {"loop": i + 1, "thought": line, "actions": []}
                for i, line in enumerate(content.splitlines())
                if line.startswith("[Step")
            ]
        except Exception:
            return []
