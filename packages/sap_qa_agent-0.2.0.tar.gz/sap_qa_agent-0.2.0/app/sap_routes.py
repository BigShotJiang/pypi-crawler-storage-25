"""SAP 自动化测试 API 路由

通过 TestOrchestrator 管线执行测试用例：
StepSplitter → TemplateMatcher → ExplorationEngine/ReuseEngine → ResultVerifier。
支持屏幕状态感知、AI 自愈、弹窗自动处理和流程变量传递。
"""

from __future__ import annotations

import asyncio
import logging
import os
import threading
import uuid
from datetime import datetime
from typing import Any

from fastapi import APIRouter, HTTPException, UploadFile
from pydantic import BaseModel

from .ai.glm_client import GlmClient
from .ai.prompt_manager import PromptManager
from .config import ARTIFACTS_DIR, KNOWLEDGE_BASE_DIR, MAX_FILE_SIZE, UPLOAD_DIR
from .core.exploration_engine import ExplorationEngine
from .core.orchestrator import TestOrchestrator
from .core.result_verifier import ResultVerifier
from .core.reuse_engine import ReuseEngine
from .core.screen_matcher import ScreenMatcher
from .core.self_healing_controller import SelfHealingController
from .core.step_splitter import StepSplitter
from .core.template_matcher import TemplateMatcher
from .core.test_case_parser import TestCaseParser
from .data.flow_variable import FlowVariableContext
from .data.fingerprint_store import FingerprintStore
from .data.knowledge_base import KnowledgeBase
from .data.models import (
    ExecutionCallbacks,
    RecoveryAction,
    StepResult,
    TestCase,
    TestCaseResult,
)
from .data.report_generator import ReportGenerator
from .sap.dialog_handler import DialogHandler
from .sap.dialog_watchdog import DialogWatchdog
from .sap.element_path_finder import ElementPathFinder
from .sap.sap_gui_wrapper import SapGuiWrapper
from .sap.screen_state_collector import ScreenStateCollector
from .sap.script_executor import ScriptExecutor
from .sap.vlm_fallback import VlmFallbackExecutor
from .task_store import InMemoryTaskStore

logger = logging.getLogger(__name__)
sap_router = APIRouter(prefix="/api/sap", tags=["SAP Automation"])
_parser = TestCaseParser()

# 进程内任务存储（SAP 路由私有，不跨进程共享；见 design.md §7.2、R18.7）。
_store = InMemoryTaskStore()


def _make_log_fn(task: dict):
    """Create a log callback that pushes messages to task['logs'] in real-time."""
    def log_fn(msg: str):
        task.setdefault("logs", []).append({
            "timestamp": datetime.now().isoformat(),
            "time": datetime.now().strftime("%H:%M:%S"),
            "message": msg,
        })
        logger.info("[%s] %s", task["task_id"], msg)
    return log_fn


def _log(task: dict, msg: str):
    """Legacy log helper — delegates to the same format."""
    task.setdefault("logs", []).append({
        "timestamp": datetime.now().isoformat(),
        "time": datetime.now().strftime("%H:%M:%S"),
        "message": msg,
    })
    logger.info("[%s] %s", task["task_id"], msg)


# =====================================================================
# StepResult → task dict conversion
# =====================================================================

def _step_result_to_dict(sr: StepResult, step_action: str, target: str, value: str | None) -> dict:
    """Convert an ExecutionEngine StepResult to the existing task['step_results'] dict format."""
    return {
        "index": sr.step_index,
        "action": step_action,
        "target": target,
        "value": value,
        "success": sr.success,
        "status_bar": sr.status_bar_message or "",
        "error": sr.error_message or "",
        "time_ms": sr.execution_time_ms,
    }


# =====================================================================
# Main execution coroutine
# =====================================================================

async def _run_case_execution(task_id: str, case_data: dict[str, Any]) -> None:
    """Kick off execution in a completely separate thread.

    Using threading.Thread (not asyncio.to_thread) to ensure the child
    thread's event loop is fully isolated from FastAPI's main loop.
    This avoids the 'Task object is not callable' selector conflict on Windows.
    """
    task = _store.get_task(task_id)
    if task is None:
        # 理论上不会触发：任务在 sap_execute_case 中创建后立即调度本函数。
        raise KeyError(task_id)
    task["status"] = "running"
    task["started_at"] = datetime.now().isoformat()

    def _worker():
        _run_case_sync(task, case_data)

    t = threading.Thread(target=_worker, daemon=True)
    t.start()


def _run_case_sync(
    task: dict[str, Any],
    case_data: dict[str, Any],
) -> None:
    """Synchronous execution in isolated thread — ALL COM calls happen here.

    Creates its own event loop (fully isolated from FastAPI's main loop).
    Uses TestOrchestrator pipeline: StepSplitter → TemplateMatcher →
    ExplorationEngine/ReuseEngine → ResultVerifier.
    """
    import pythoncom
    pythoncom.CoInitialize()

    log_fn = _make_log_fn(task)
    watchdog: DialogWatchdog | None = None

    try:
        # ---- Start DialogWatchdog FIRST (before any SAP GUI access) ----
        watchdog = DialogWatchdog()
        watchdog.start()
        log_fn("🐕 弹窗看门狗已启动")

        log_fn("📋 解析测试用例...")
        tc = TestCase.from_dict(case_data)
        log_fn(f"用例: {tc.case_id} — {tc.purpose[:60]}")

        # ---- Initialize all dependency components ----
        log_fn("🔌 初始化组件...")
        sap_wrapper = SapGuiWrapper()
        connected = sap_wrapper.connect()
        if not connected:
            raise RuntimeError("无法连接 SAP GUI")

        session = sap_wrapper.get_session()
        sys_name = user = ""
        try:
            if session:
                sys_name = session.Info.SystemName or ""
                user = session.Info.User or ""
        except Exception:
            pass
        title = ""
        try:
            if session:
                title = str(session.findById("wnd[0]").Text or "")
        except Exception:
            pass
        log_fn(f"✅ 已连接: 系统={sys_name or '(登录界面)'}, 用户={user or '(未登录)'}, 界面={title}")

        # ---- Transaction code case: Orchestrator pipeline ----

        glm_client = GlmClient()
        prompt_manager = PromptManager()
        element_finder = ElementPathFinder(sap_wrapper, glm_client)
        screen_collector = ScreenStateCollector(sap_wrapper, element_finder)
        knowledge_base = KnowledgeBase(KNOWLEDGE_BASE_DIR)
        fingerprint_store = FingerprintStore(KNOWLEDGE_BASE_DIR)
        step_splitter = StepSplitter(glm_client, prompt_manager)
        template_matcher = TemplateMatcher(knowledge_base)
        vlm_fallback = VlmFallbackExecutor()
        script_executor = ScriptExecutor(sap_wrapper, vlm_fallback, element_finder=element_finder, glm_client=glm_client, fingerprint_store=fingerprint_store)
        _store.register_executor(task["task_id"], script_executor)  # Store for stop signal
        exploration_engine = ExplorationEngine(
            glm_client=glm_client,
            script_executor=script_executor,
            element_finder=element_finder,
            knowledge_base=knowledge_base,
        )
        reuse_engine = ReuseEngine(
            script_executor=script_executor,
            knowledge_base=knowledge_base,
        )
        result_verifier = ResultVerifier(sap_wrapper)
        flow_context = FlowVariableContext()

        orchestrator = TestOrchestrator(
            step_splitter=step_splitter,
            template_matcher=template_matcher,
            exploration_engine=exploration_engine,
            reuse_engine=reuse_engine,
            result_verifier=result_verifier,
            script_executor=script_executor,
        )

        # ---- Define execution callbacks for real-time task updates ----
        def _on_step_result(sr):
            """Convert StepResult to frontend-compatible dict and append."""
            # Convert absolute screenshot path to URL path for frontend access
            screenshot_url = ""
            if sr.screenshot_path:
                rel = os.path.relpath(sr.screenshot_path, ARTIFACTS_DIR).replace("\\", "/")
                screenshot_url = f"/artifacts/{rel}"
            task["step_results"].append({
                "index": sr.step_index,
                "action": "",
                "target": "",
                "value": "",
                "success": sr.success,
                "status_bar": sr.status_bar_message or "",
                "error": sr.error_message or "",
                "time_ms": sr.execution_time_ms or 0,
                "screenshot_url": screenshot_url,
            })

        def _on_steps_plan(steps):
            """Update steps_plan and reset step_results for new execution attempt."""
            task["steps_plan"] = steps
            task["step_results"] = []  # Clear results from previous attempt

        callbacks = ExecutionCallbacks(
            on_steps_plan=_on_steps_plan,
            on_script_generated=lambda script: _update_task(task, "generated_script", script),
            on_step_result=_on_step_result,
            on_log=lambda msg: _log(task, msg),
        )

        # ---- Set retry info if retrying from a specific step ----
        retry_from = task.pop("_retry_from_step", 0)
        if retry_from > 0:
            script_executor._skip_before_index = retry_from
            log_fn(f"🔄 从 Step {retry_from} 开始重试")
        else:
            script_executor._skip_before_index = 0

        # ---- Execute ----
        log_fn("▶️ 开始执行...")

        if retry_from > 0 and task.get("steps_plan"):
            # 重试模式：跳过拆分和调整，直接用已有步骤执行
            from app.data.models import StepActionType, TestStep as _TS
            existing_steps = [
                _TS(
                    index=sp.get("index", i + 1),
                    action_type=StepActionType(sp.get("action", "input")),
                    target_description=sp.get("target", ""),
                    value=sp.get("value"),
                    row=sp.get("row"),
                    column=sp.get("column"),
                )
                for i, sp in enumerate(task["steps_plan"])
            ]
            log_fn(f"  📋 使用已有 {len(existing_steps)} 个步骤，从 Step {retry_from} 开始")

            step_results = _run_coroutine_sync(
                script_executor.execute_script(
                    existing_steps, flow_context,
                    step_callback=callbacks.on_step_result,
                    log_callback=callbacks.on_log,
                    test_case_context=f"{tc.case_id}: {tc.purpose}",
                    skip_before_index=retry_from,
                )
            )

            # 构建简化的结果
            from app.data.models import ExecutionMode, TestCaseResult as _TCR, VerificationResult
            all_ok = all(sr.success for sr in step_results)
            result = _TCR(
                case_id=tc.case_id,
                success=all_ok,
                execution_mode=ExecutionMode.EXPLORATION,
                step_results=step_results,
                verification_results=[],
                template_solidified=False,
            )
        else:
            # 正常模式：完整的 Orchestrator 流程
            result: TestCaseResult = _run_coroutine_sync(
                orchestrator.execute_test_case(tc, flow_context, callbacks)
            )

        # ---- Convert result to task dict format ----
        task["result"] = _convert_result(result, flow_context)
        task["status"] = "completed" if result.success else "failed"
        task["completed_at"] = datetime.now().isoformat()

        ok_count = sum(1 for sr in result.step_results if sr.success)
        total = len(result.step_results)
        log_fn(f"{'🎉 执行完成！' if result.success else '❌ 部分步骤失败'} ({ok_count}/{total} 步成功)")

    except Exception as exc:
        logger.exception("Task %s sync error: %s", task["task_id"], exc)
        task["status"] = "failed"
        task["completed_at"] = datetime.now().isoformat()
        task["error"] = str(exc)
        _log(task, f"💥 执行异常: {exc}")

    finally:
        if watchdog is not None:
            watchdog.stop()
            _log(task, f"🐕 弹窗看门狗已停止 (累计处理 {watchdog.handled_count} 个 OS 弹窗)")
        try:
            pythoncom.CoUninitialize()
        except Exception:
            pass
        # Clean up executor reference
        _store.pop_executor(task["task_id"])


def _update_task(task: dict[str, Any], key: str, value: Any) -> None:
    """Helper to update a task dict field (used by callbacks)."""
    task[key] = value


def _run_coroutine_sync(coro):
    """同步运行协程，不创建 event loop。

    因为所有 async 方法内部都是同步的（GLM 调用已改为同步），
    这里只需要手动驱动 coroutine 的 send/throw 协议。
    不创建 event loop 就不会和 uvicorn 的 loop 冲突。
    """
    result = None
    try:
        result = coro.send(None)
        while True:
            # 如果 yield 了一个 coroutine（await 语句），递归执行它
            if hasattr(result, 'send'):
                inner_result = _run_coroutine_sync(result)
                result = coro.send(inner_result)
            else:
                result = coro.send(result)
    except StopIteration as e:
        return e.value


def _convert_result(result: TestCaseResult, flow_context: FlowVariableContext) -> dict[str, Any]:
    """Convert TestCaseResult to the frontend-consumable task['result'] dict format."""
    steps = []
    for sr in result.step_results:
        screenshot_url = ""
        if sr.screenshot_path:
            rel = os.path.relpath(sr.screenshot_path, ARTIFACTS_DIR).replace("\\", "/")
            screenshot_url = f"/artifacts/{rel}"
        steps.append({
            "index": sr.step_index,
            "success": sr.success,
            "status_bar": sr.status_bar_message or "",
            "error": sr.error_message or "",
            "time_ms": sr.execution_time_ms,
            "screenshot_url": screenshot_url,
        })

    # Derive final_status_bar from the last step's status bar message
    final_status_bar = ""
    if result.step_results:
        final_status_bar = result.step_results[-1].status_bar_message or ""

    return {
        "case_id": result.case_id,
        "success": result.success,
        "execution_mode": result.execution_mode.value,
        "step_count": len(result.step_results),
        "success_count": sum(1 for sr in result.step_results if sr.success),
        "steps": steps,
        "final_status_bar": final_status_bar,
        "final_window_title": "",
        "flow_variables": flow_context.to_dict(),
        "template_solidified": result.template_solidified,
    }


# =====================================================================
# Routes
# =====================================================================

class ExecuteCaseRequest(BaseModel):
    case_data: dict[str, Any]

@sap_router.post("/upload")
async def sap_upload(file: UploadFile):
    if not file.filename:
        raise HTTPException(status_code=400, detail="未提供文件名")
    ext = os.path.splitext(file.filename)[1].lower()
    if ext not in {".xlsx", ".xls", ".md", ".markdown"}:
        raise HTTPException(status_code=400, detail="不支持的文件格式")
    content = await file.read()
    if len(content) > MAX_FILE_SIZE:
        raise HTTPException(status_code=400, detail="文件大小超过限制")
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    safe_name = f"{uuid.uuid4().hex[:8]}_{file.filename}"
    file_path = os.path.join(UPLOAD_DIR, safe_name)
    with open(file_path, "wb") as f:
        f.write(content)
    try:
        test_cases = _parser.parse_excel(file_path) if ext in {".xlsx", ".xls"} else _parser.parse_markdown(file_path)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"解析失败: {e}")
    return {"filename": file.filename, "case_count": len(test_cases), "cases": [tc.to_dict() for tc in test_cases]}

@sap_router.post("/execute/case")
async def sap_execute_case(body: ExecuteCaseRequest):
    case_id = str(body.case_data.get("case_id", "") or "")
    task_id = _store.create_task(case_id=case_id, case_data=body.case_data, task_type="case")
    asyncio.create_task(_run_case_execution(task_id, body.case_data))
    return {"task_id": task_id, "status": "queued"}

@sap_router.post("/execute/stop")
async def sap_stop(task_id: str | None = None):
    if task_id:
        task = _store.get_task(task_id)
        if task is not None:
            task["status"] = "cancelled"
            # Signal the executor to stop
            executor = _store.pop_executor(task_id)
            if executor and hasattr(executor, 'stop'):
                executor.stop()
            _log(task, "⏹ 用户请求停止执行")
            return {"task_id": task_id, "stopped": True}
    return {"stopped_tasks": []}


class RetryFromStepRequest(BaseModel):
    task_id: str
    from_step_index: int


@sap_router.post("/execute/retry-from-step")
async def sap_retry_from_step(body: RetryFromStepRequest):
    """从指定步骤开始重试执行（保留之前成功的步骤结果）。"""
    task = _store.get_task(body.task_id)
    if not task:
        raise HTTPException(status_code=404, detail="任务不存在")

    # 保留 from_step_index 之前的成功结果
    task["step_results"] = [
        r for r in task["step_results"] if r.get("index", 0) < body.from_step_index
    ]
    task["status"] = "running"
    task["error"] = None
    task["result"] = None
    task["started_at"] = datetime.now().isoformat()
    task["completed_at"] = None
    task["_retry_from_step"] = body.from_step_index
    _log(task, f"🔄 从 Step {body.from_step_index} 开始重试")

    # 启动重试执行
    asyncio.create_task(_run_case_execution(body.task_id, task["case_data"]))
    return {"task_id": body.task_id, "status": "running", "retry_from": body.from_step_index}


@sap_router.get("/tasks/{task_id}")
async def sap_get_task(task_id: str):
    task = _store.get_task(task_id)
    if not task:
        raise HTTPException(status_code=404, detail="任务不存在")
    return task

@sap_router.get("/templates")
async def sap_list_templates():
    kb = KnowledgeBase(KNOWLEDGE_BASE_DIR)
    templates = kb.list_templates()
    return {"count": len(templates), "templates": [
        {"template_id": t.template_id, "transaction_code": t.transaction_code,
         "scenario_type": t.scenario_type, "confidence": t.confidence.value,
         "last_success_at": t.last_success_at.isoformat() if t.last_success_at else None}
        for t in templates
    ]}

@sap_router.get("/report/{task_id}")
async def sap_get_report(task_id: str):
    task = _store.get_task(task_id)
    if not task:
        raise HTTPException(status_code=404, detail="任务不存在")
    return {"task_id": task_id, "status": task["status"], "result": task.get("result"), "error": task.get("error")}
