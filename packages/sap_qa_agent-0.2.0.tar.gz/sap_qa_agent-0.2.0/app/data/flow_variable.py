"""FlowVariableContext - Test_Suite 级别的流程变量上下文

管理端到端流程中用例间传递的动态数据，如凭证号、订单号等。
变量通过 ${VAR_NAME} 占位符在文本中引用，resolve() 方法负责替换。
"""

from __future__ import annotations

import json
import logging
import os
import re
from typing import Any

logger = logging.getLogger(__name__)

# 默认正则：匹配 8-10 位连续数字
_DEFAULT_DOC_NUMBER_PATTERN = re.compile(r"\b(\d{8,10})\b")


def _load_patterns(patterns_path: str | None = None) -> list[dict[str, Any]]:
    """从 knowledge_base/patterns.json 加载凭证号提取模式。

    Returns:
        模式列表，每项包含 name、regex（已编译）、variable 字段。
        加载失败时返回空列表。
    """
    if patterns_path is None:
        patterns_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
            "knowledge_base",
            "patterns.json",
        )

    try:
        with open(patterns_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        raw_patterns = data.get("patterns", [])
        compiled: list[dict[str, Any]] = []
        for p in raw_patterns:
            try:
                compiled.append({
                    "name": p["name"],
                    "regex": re.compile(p["regex"]),
                    "variable": p["variable"],
                })
            except (re.error, KeyError) as exc:
                logger.warning("跳过无效模式 %s: %s", p.get("name", "?"), exc)
        return compiled
    except (OSError, json.JSONDecodeError) as exc:
        logger.warning("加载 patterns.json 失败: %s", exc)
        return []


class FlowVariableContext:
    """Test_Suite 级别的流程变量上下文"""

    _PLACEHOLDER_PATTERN = re.compile(r"\$\{([^}]+)\}")

    def __init__(self, patterns_path: str | None = None) -> None:
        self._variables: dict[str, str] = {}
        self._patterns = _load_patterns(patterns_path)

    def set(self, name: str, value: str) -> None:
        """写入变量（如 ORDER_NO = "0000012345"）"""
        self._variables[name] = value

    def get(self, name: str) -> str | None:
        """读取变量，不存在时返回 None"""
        return self._variables.get(name)

    def resolve(self, text: str) -> str:
        """替换文本中的所有 ${VAR_NAME} 占位符为实际值。

        当引用的变量不存在时抛出 KeyError。
        """
        def _replace(match: re.Match) -> str:
            var_name = match.group(1)
            if var_name not in self._variables:
                raise KeyError(
                    f"Flow variable '{var_name}' not found in context. "
                    f"Available variables: {list(self._variables.keys())}"
                )
            return self._variables[var_name]

        return self._PLACEHOLDER_PATTERN.sub(_replace, text)

    def has(self, name: str) -> bool:
        """检查变量是否存在"""
        return name in self._variables

    def to_dict(self) -> dict[str, str]:
        """导出所有变量（用于报告和持久化）"""
        return dict(self._variables)

    def extract_document_number(
        self,
        status_bar_text: str,
        variable_name: str | None = None,
    ) -> str | None:
        """从状态栏消息中提取凭证号并存储到上下文。

        优先使用 knowledge_base/patterns.json 中的正则模式按顺序匹配。
        如果所有模式均未命中，则使用默认正则提取 8-10 位数字。

        Args:
            status_bar_text: SAP 状态栏消息文本
            variable_name: 强制指定存储的变量名。为 None 时使用模式中
                           定义的 variable 字段，或默认 "DOC_NO"。

        Returns:
            提取到的凭证号字符串，未提取到时返回 None。
        """
        if not status_bar_text:
            return None

        # 1. 尝试 patterns.json 中的模式（按顺序）
        for pattern in self._patterns:
            match = pattern["regex"].search(status_bar_text)
            if match:
                doc_number = match.group(1)
                var_name = variable_name or pattern["variable"]
                self._variables[var_name] = doc_number
                logger.info(
                    "凭证号提取成功 [%s]: %s=%s (来源: %s)",
                    pattern["name"], var_name, doc_number, status_bar_text,
                )
                return doc_number

        # 2. 回退到默认正则（8-10 位数字）
        fallback_match = _DEFAULT_DOC_NUMBER_PATTERN.search(status_bar_text)
        if fallback_match:
            doc_number = fallback_match.group(1)
            var_name = variable_name or "DOC_NO"
            self._variables[var_name] = doc_number
            logger.info(
                "凭证号提取成功 [默认模式]: %s=%s (来源: %s)",
                var_name, doc_number, status_bar_text,
            )
            return doc_number

        return None
