"""SAP GUI 自动化测试框架 - 数据模型定义

包含所有 dataclass 和 Enum 定义，用于测试用例、测试步骤、元素路径、
脚本模板、执行结果等核心数据结构。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Callable


# ---- 测试用例相关 ----


class TestCaseType(str, Enum):
    """测试用例类型"""
    NORMAL = "normal"
    EXPECTED_FAILURE = "expected_failure"


@dataclass
class FlowVariableDef:
    """Flow_Variable 定义"""
    name: str
    source: str
    pattern: str | None = None


@dataclass
class TestCase:
    """标准化测试用例"""
    case_id: str
    purpose: str
    preconditions: str
    steps_text: str
    test_data: dict[str, str]
    expected_results: list[str]
    ai_notes: str
    case_type: TestCaseType = TestCaseType.NORMAL
    transaction_code: str | None = None
    flow_variable_defs: list[FlowVariableDef] = field(default_factory=list)
    dependencies: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """序列化为字典，支持 JSON 持久化"""
        return {
            "case_id": self.case_id,
            "purpose": self.purpose,
            "preconditions": self.preconditions,
            "steps_text": self.steps_text,
            "test_data": self.test_data,
            "expected_results": self.expected_results,
            "ai_notes": self.ai_notes,
            "case_type": self.case_type.value,
            "transaction_code": self.transaction_code,
            "flow_variable_defs": [
                {"name": fv.name, "source": fv.source, "pattern": fv.pattern}
                for fv in self.flow_variable_defs
            ],
            "dependencies": self.dependencies,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TestCase:
        """从字典反序列化"""
        return cls(
            case_id=data["case_id"],
            purpose=data["purpose"],
            preconditions=data["preconditions"],
            steps_text=data["steps_text"],
            test_data=data.get("test_data", {}),
            expected_results=data.get("expected_results", []),
            ai_notes=data.get("ai_notes", ""),
            case_type=TestCaseType(data.get("case_type", "normal")),
            transaction_code=data.get("transaction_code"),
            flow_variable_defs=[
                FlowVariableDef(
                    name=fv["name"],
                    source=fv["source"],
                    pattern=fv.get("pattern"),
                )
                for fv in data.get("flow_variable_defs", [])
            ],
            dependencies=data.get("dependencies", []),
        )


@dataclass
class TestSuite:
    """测试套件"""
    suite_id: str
    name: str
    test_cases: list[TestCase]
    created_at: datetime = field(default_factory=datetime.now)


# ---- 测试步骤相关 ----


class StepActionType(str, Enum):
    """步骤操作类型"""
    INPUT = "input"
    CLICK = "click"
    DOUBLE_CLICK = "double_click"
    SELECT = "select"
    VERIFY = "verify"
    NAVIGATE = "navigate"
    WAIT = "wait"
    READ = "read"


@dataclass
class TestStep:
    """结构化测试步骤"""
    index: int
    action_type: StepActionType
    target_description: str
    value: str | None = None
    flow_variable_ref: str | None = None
    row: int | None = None       # 表格行号（1-based，非表格操作为 None）
    column: str | None = None    # 表格列名（"物料"/"数量"/"工厂"等，非表格操作为 None）


# ---- 页面指纹相关 ----


class ViewType(str, Enum):
    """页面视图类型"""
    TABLE = "table"      # 表格视图（GuiTableControl / GuiGridView）
    DETAIL = "detail"    # 详情视图（单行，需翻页导航）
    FORM = "form"        # 表单视图（无表格，多个输入字段）
    UNKNOWN = "unknown"


@dataclass
class TableSchema:
    """表格结构指纹 — 记录 SAP 表格控件的列映射信息"""
    table_path: str                                        # 表格控件完整 SAP 路径
    table_type: str                                        # "GuiTableControl" | "GuiGridView"
    columns: list[dict[str, Any]]                          # [{"name":"物料","tech_name":"RV45A-MABNR","col_index":1}, ...]
    visible_rows: int = 0
    row_path_template: str = ""                            # 行路径模板

    def to_dict(self) -> dict[str, Any]:
        return {
            "table_path": self.table_path,
            "table_type": self.table_type,
            "columns": self.columns,
            "visible_rows": self.visible_rows,
            "row_path_template": self.row_path_template,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TableSchema:
        return cls(
            table_path=data["table_path"],
            table_type=data["table_type"],
            columns=data.get("columns", []),
            visible_rows=data.get("visible_rows", 0),
            row_path_template=data.get("row_path_template", ""),
        )


@dataclass
class PageFingerprint:
    """页面指纹 — 唯一标识一个 SAP 屏幕状态（screen_title + active_tab）。"""
    fingerprint_id: str                                    # "screen_title|active_tab"
    screen_title: str                                      # SAP 窗口标题
    active_tab: str                                        # 活动页签标识，如 "T\\01"，无页签时为 ""
    view_type: ViewType = ViewType.UNKNOWN
    table_schema: TableSchema | None = None                # view_type=TABLE 时有值
    field_map: dict[str, str] = field(default_factory=dict)  # {"业务名称": "element_id_path"}
    tabstrip_path: str | None = None                       # 页签条路径
    available_tabs: list[str] = field(default_factory=list)  # 可用页签列表
    created_at: datetime = field(default_factory=datetime.now)
    last_used_at: datetime | None = None
    usage_count: int = 0

    def to_dict(self) -> dict[str, Any]:
        result: dict[str, Any] = {
            "fingerprint_id": self.fingerprint_id,
            "screen_title": self.screen_title,
            "active_tab": self.active_tab,
            "view_type": self.view_type.value,
            "field_map": self.field_map,
            "tabstrip_path": self.tabstrip_path,
            "available_tabs": self.available_tabs,
            "created_at": self.created_at.isoformat(),
            "last_used_at": self.last_used_at.isoformat() if self.last_used_at else None,
            "usage_count": self.usage_count,
        }
        if self.table_schema:
            result["table_schema"] = self.table_schema.to_dict()
        return result

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> PageFingerprint:
        table_schema = None
        if data.get("table_schema"):
            table_schema = TableSchema.from_dict(data["table_schema"])
        return cls(
            fingerprint_id=data["fingerprint_id"],
            screen_title=data["screen_title"],
            active_tab=data.get("active_tab", ""),
            view_type=ViewType(data.get("view_type", "unknown")),
            table_schema=table_schema,
            field_map=data.get("field_map", {}),
            tabstrip_path=data.get("tabstrip_path"),
            available_tabs=data.get("available_tabs", []),
            created_at=datetime.fromisoformat(data["created_at"]) if data.get("created_at") else datetime.now(),
            last_used_at=datetime.fromisoformat(data["last_used_at"]) if data.get("last_used_at") else None,
            usage_count=data.get("usage_count", 0),
        )


# ---- 元素路径相关 ----


@dataclass
class ElementInfo:
    """SAP GUI 元素信息"""
    id_path: str
    element_type: str
    tooltip: str
    label_text: str
    current_value: str
    is_changeable: bool = True


@dataclass
class ElementTree:
    """元素树"""
    root_path: str
    elements: list[ElementInfo]
    label_map: dict[str, str]


@dataclass
class ElementMatchResult:
    """元素匹配结果"""
    found: bool
    element: ElementInfo | None = None
    match_method: str = ""
    candidates: list[ElementInfo] = field(default_factory=list)


@dataclass
class PathCorrection:
    """路径修正记录"""
    step_description: str
    original_path: str
    corrected_path: str
    match_method: str
    context: str


# ---- 脚本模板相关 ----


class TemplateConfidence(str, Enum):
    """模板置信度等级"""
    DRAFT = "草稿"
    STABLE = "稳定"
    NEEDS_FIX = "待修复"


@dataclass
class ScriptTemplate:
    """脚本模板"""
    template_id: str
    transaction_code: str
    scenario_type: str
    script_content: str
    element_path_map: dict[str, str]
    parameters: list[str]
    confidence: TemplateConfidence = TemplateConfidence.DRAFT
    consecutive_success_count: int = 0
    created_at: datetime = field(default_factory=datetime.now)
    last_success_at: datetime | None = None
    sap_gui_version: str | None = None
    path_corrections: list[PathCorrection] = field(default_factory=list)
    steps: list[dict[str, Any]] = field(default_factory=list)  # 原始步骤列表

    def to_dict(self) -> dict[str, Any]:
        """序列化为字典，支持 JSON 持久化"""
        return {
            "template_id": self.template_id,
            "transaction_code": self.transaction_code,
            "scenario_type": self.scenario_type,
            "script_content": self.script_content,
            "element_path_map": self.element_path_map,
            "parameters": self.parameters,
            "confidence": self.confidence.value,
            "consecutive_success_count": self.consecutive_success_count,
            "created_at": self.created_at.isoformat(),
            "last_success_at": self.last_success_at.isoformat() if self.last_success_at else None,
            "sap_gui_version": self.sap_gui_version,
            "path_corrections": [
                {
                    "step_description": pc.step_description,
                    "original_path": pc.original_path,
                    "corrected_path": pc.corrected_path,
                    "match_method": pc.match_method,
                    "context": pc.context,
                }
                for pc in self.path_corrections
            ],
            "steps": self.steps,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ScriptTemplate:
        """从字典反序列化"""
        return cls(
            template_id=data["template_id"],
            transaction_code=data["transaction_code"],
            scenario_type=data["scenario_type"],
            script_content=data["script_content"],
            element_path_map=data.get("element_path_map", {}),
            parameters=data.get("parameters", []),
            confidence=TemplateConfidence(data.get("confidence", "草稿")),
            consecutive_success_count=data.get("consecutive_success_count", 0),
            created_at=datetime.fromisoformat(data["created_at"]) if data.get("created_at") else datetime.now(),
            last_success_at=datetime.fromisoformat(data["last_success_at"]) if data.get("last_success_at") else None,
            sap_gui_version=data.get("sap_gui_version"),
            path_corrections=[
                PathCorrection(
                    step_description=pc["step_description"],
                    original_path=pc["original_path"],
                    corrected_path=pc["corrected_path"],
                    match_method=pc["match_method"],
                    context=pc["context"],
                )
                for pc in data.get("path_corrections", [])
            ],
            steps=data.get("steps", []),
        )


# ---- 执行回调 ----


@dataclass
class ExecutionCallbacks:
    """执行过程回调，用于实时推送状态到 task 字典"""
    on_steps_plan: Callable[[list[dict]], None] | None = None
    on_script_generated: Callable[[str], None] | None = None
    on_step_result: Callable[[dict], None] | None = None
    on_log: Callable[[str], None] | None = None


# ---- 执行结果相关 ----


class ExecutionMode(str, Enum):
    """执行模式"""
    EXPLORATION = "exploration"
    REUSE = "reuse"


@dataclass
class AiIntervention:
    """AI 干预记录"""
    exception_type: str
    ui_state: str
    ai_decision: str
    result: str


@dataclass
class StepResult:
    """单步执行结果"""
    step_index: int
    success: bool
    screenshot_path: str | None = None
    status_bar_message: str | None = None
    extracted_document_number: str | None = None
    error_message: str | None = None
    ai_intervention: AiIntervention | None = None
    path_correction: PathCorrection | None = None
    execution_time_ms: int = 0
    # ---- 新增字段：AI 自愈能力 ----
    before_snapshot: ScreenSnapshot | None = None
    after_snapshot: ScreenSnapshot | None = None
    ai_intervention_records: list[HealingRecord] = field(default_factory=list)
    dialog_records: list[DialogRecord] = field(default_factory=list)
    healing_action: RecoveryAction | None = None


@dataclass
class VerificationResult:
    """预期结果验证"""
    description: str
    passed: bool
    expected_value: str | None = None
    actual_value: str | None = None


@dataclass
class TestCaseResult:
    """测试用例执行结果"""
    case_id: str
    success: bool
    execution_mode: ExecutionMode
    step_results: list[StepResult]
    verification_results: list[VerificationResult]
    template_solidified: bool = False
    flow_variables_extracted: dict[str, str] = field(default_factory=dict)
    failure_analysis: str | None = None


@dataclass
class TestSuiteResult:
    """测试套件执行结果"""
    suite_id: str
    case_results: list[TestCaseResult]
    flow_variable_chain: dict[str, str]
    total_cases: int
    passed_cases: int
    failed_cases: int
    skipped_cases: int
    new_templates: int
    template_upgrades: int


# ---- 状态栏消息 ----


class MessageType(str, Enum):
    """SAP 状态栏消息类型"""
    SUCCESS = "S"
    ERROR = "E"
    WARNING = "W"
    INFO = "I"


@dataclass
class StatusBarMessage:
    """SAP GUI 状态栏消息"""
    text: str
    message_type: MessageType
    message_id: str | None = None
    message_number: str | None = None


# ---- AI 自愈能力相关 ----


class RecoveryAction(str, Enum):
    """Recovery_Plan 动作类型"""
    RETRY = "retry"
    NAVIGATE = "navigate"
    SKIP = "skip"
    ABORT = "abort"


@dataclass
class ScreenSnapshot:
    """屏幕快照 — 包含当前 SAP GUI 窗口的完整上下文。"""
    window_title: str
    status_bar_text: str
    status_bar_type: MessageType
    active_window_id: str
    element_tree_summary: str
    timestamp: datetime

    def to_dict(self) -> dict[str, Any]:
        return {
            "window_title": self.window_title,
            "status_bar_text": self.status_bar_text,
            "status_bar_type": self.status_bar_type.value,
            "active_window_id": self.active_window_id,
            "element_tree_summary": self.element_tree_summary,
            "timestamp": self.timestamp.isoformat(),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ScreenSnapshot:
        return cls(
            window_title=data["window_title"],
            status_bar_text=data["status_bar_text"],
            status_bar_type=MessageType(data["status_bar_type"]),
            active_window_id=data["active_window_id"],
            element_tree_summary=data["element_tree_summary"],
            timestamp=datetime.fromisoformat(data["timestamp"]),
        )


@dataclass
class RecoveryPlan:
    """GLM 生成的结构化修正方案。"""
    action: RecoveryAction
    reason: str
    confidence: float
    corrected_target: str | None = None
    corrected_value: str | None = None
    navigation_steps: list[dict] | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "action": self.action.value,
            "reason": self.reason,
            "confidence": self.confidence,
            "corrected_target": self.corrected_target,
            "corrected_value": self.corrected_value,
            "navigation_steps": self.navigation_steps,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> RecoveryPlan:
        return cls(
            action=RecoveryAction(data["action"]),
            reason=data.get("reason", ""),
            confidence=float(data.get("confidence", 0.5)),
            corrected_target=data.get("corrected_target"),
            corrected_value=data.get("corrected_value"),
            navigation_steps=data.get("navigation_steps"),
        )


@dataclass
class HealingRecord:
    """单次自愈重试记录。"""
    attempt: int
    snapshot: ScreenSnapshot | None
    plan: RecoveryPlan | None
    result_success: bool
    error: str | None = None
    elapsed_ms: int = 0


@dataclass
class HealingResult:
    """自愈控制器的最终结果。"""
    success: bool
    action_taken: RecoveryAction
    records: list[HealingRecord] = field(default_factory=list)
    final_plan: RecoveryPlan | None = None


@dataclass
class DialogRecord:
    """弹窗处理记录。"""
    title: str
    text: str
    action: str  # "confirm" | "cancel" | "input"
    reason: str
    error_text: str | None = None
    elapsed_ms: int = 0
