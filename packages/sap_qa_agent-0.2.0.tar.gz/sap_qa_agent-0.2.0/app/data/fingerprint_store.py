"""页面指纹持久化存储

管理 PageFingerprint 的 JSON 持久化存储，按 fingerprint_id 索引。
存储路径: knowledge_base/page_fingerprints.json
"""

from __future__ import annotations

import json
import logging
import os
from datetime import datetime
from typing import Any

from app.config import KNOWLEDGE_BASE_DIR
from app.data.models import PageFingerprint

logger = logging.getLogger(__name__)


class FingerprintStore:
    """页面指纹存储 — JSON 文件持久化。

    存储结构:
    {
      "version": "1.0",
      "fingerprints": {
        "screen_title|active_tab": { ... PageFingerprint data ... }
      },
      "metadata": {
        "total_fingerprints": N,
        "last_updated": "ISO datetime"
      }
    }
    """

    def __init__(self, storage_path: str | None = None) -> None:
        self._storage_dir = storage_path or KNOWLEDGE_BASE_DIR
        self._file_path = os.path.join(self._storage_dir, "page_fingerprints.json")
        self._data: dict[str, Any] = self._load()

    @staticmethod
    def _make_fingerprint_id(screen_title: str, active_tab: str) -> str:
        """生成指纹 ID: screen_title|active_tab"""
        return f"{screen_title}|{active_tab}"

    # ---- 持久化 ----

    def _load(self) -> dict[str, Any]:
        """从 JSON 文件加载指纹数据"""
        if os.path.exists(self._file_path):
            try:
                with open(self._file_path, "r", encoding="utf-8") as f:
                    return json.load(f)
            except (json.JSONDecodeError, OSError) as e:
                logger.warning("指纹文件读取失败，使用空存储: %s", e)
        return self._empty_store()

    def _save(self) -> None:
        """将指纹数据写入 JSON 文件"""
        os.makedirs(self._storage_dir, exist_ok=True)
        self._data["metadata"]["total_fingerprints"] = len(self._data["fingerprints"])
        self._data["metadata"]["last_updated"] = datetime.now().isoformat()
        with open(self._file_path, "w", encoding="utf-8") as f:
            json.dump(self._data, f, ensure_ascii=False, indent=2)

    @staticmethod
    def _empty_store() -> dict[str, Any]:
        return {
            "version": "1.0",
            "fingerprints": {},
            "metadata": {"total_fingerprints": 0, "last_updated": None},
        }

    # ---- 公开接口 ----

    def get(self, fingerprint_id: str) -> PageFingerprint | None:
        """按 fingerprint_id 获取页面指纹"""
        fp_data = self._data["fingerprints"].get(fingerprint_id)
        if fp_data is None:
            return None
        return PageFingerprint.from_dict(fp_data)

    def get_by_screen(self, screen_title: str, active_tab: str = "") -> PageFingerprint | None:
        """按屏幕标题和页签获取页面指纹"""
        fp_id = self._make_fingerprint_id(screen_title, active_tab)
        return self.get(fp_id)

    def save(self, fingerprint: PageFingerprint) -> None:
        """保存或更新页面指纹"""
        existing = self._data["fingerprints"].get(fingerprint.fingerprint_id)
        if existing:
            # 保留创建时间，更新使用次数
            fingerprint.created_at = datetime.fromisoformat(existing["created_at"]) if existing.get("created_at") else fingerprint.created_at
            fingerprint.usage_count = existing.get("usage_count", 0) + 1
        fingerprint.last_used_at = datetime.now()
        self._data["fingerprints"][fingerprint.fingerprint_id] = fingerprint.to_dict()
        self._save()
        logger.info(
            "指纹已保存: %s (view=%s)",
            fingerprint.fingerprint_id,
            fingerprint.view_type.value,
        )

    def list_all(self) -> list[PageFingerprint]:
        """列出所有页面指纹"""
        result: list[PageFingerprint] = []
        for fp_data in self._data["fingerprints"].values():
            result.append(PageFingerprint.from_dict(fp_data))
        return result

    def delete(self, fingerprint_id: str) -> bool:
        """删除指定指纹"""
        if fingerprint_id in self._data["fingerprints"]:
            del self._data["fingerprints"][fingerprint_id]
            self._save()
            logger.info("指纹已删除: %s", fingerprint_id)
            return True
        return False
