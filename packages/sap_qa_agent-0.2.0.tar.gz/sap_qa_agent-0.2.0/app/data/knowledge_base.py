"""知识库管理模块 - 脚本模板的持久化存储与查询

管理所有已固化的脚本模板，支持按事务码+场景类型查询和置信度管理。
使用 JSON 文件持久化存储。
"""

from __future__ import annotations

import json
import logging
import os
from dataclasses import dataclass
from datetime import datetime
from typing import Any

from app.config import KNOWLEDGE_BASE_DIR, TEMPLATE_CONFIDENCE_THRESHOLD
from app.data.models import ScriptTemplate, TemplateConfidence

logger = logging.getLogger(__name__)


@dataclass
class TemplateInfo:
    """模板摘要信息，用于 list_templates() 返回"""
    template_id: str
    transaction_code: str
    scenario_type: str
    confidence: TemplateConfidence
    last_success_at: datetime | None


class KnowledgeBase:
    """脚本模板知识库，JSON 文件持久化

    存储结构:
    {
      "version": "1.0",
      "templates": {
        "{transaction_code}_{scenario_type}": { ... template data ... }
      },
      "metadata": {
        "total_templates": N,
        "last_updated": "ISO datetime"
      }
    }
    """

    def __init__(self, storage_path: str | None = None) -> None:
        self._storage_dir = storage_path or KNOWLEDGE_BASE_DIR
        self._file_path = os.path.join(self._storage_dir, "templates.json")
        self._data: dict[str, Any] = self._load()

    @staticmethod
    def _make_key(transaction_code: str, scenario_type: str) -> str:
        """生成模板存储键: {transaction_code}_{scenario_type}"""
        return f"{transaction_code}_{scenario_type}"

    # ---- 持久化 ----

    def _load(self) -> dict[str, Any]:
        """从 JSON 文件加载知识库数据"""
        if os.path.exists(self._file_path):
            try:
                with open(self._file_path, "r", encoding="utf-8") as f:
                    return json.load(f)
            except (json.JSONDecodeError, OSError) as e:
                logger.warning("知识库文件读取失败，使用空知识库: %s", e)
        return self._empty_store()

    def _save(self) -> None:
        """将知识库数据写入 JSON 文件"""
        os.makedirs(self._storage_dir, exist_ok=True)
        self._data["metadata"]["total_templates"] = len(self._data["templates"])
        self._data["metadata"]["last_updated"] = datetime.now().isoformat()
        with open(self._file_path, "w", encoding="utf-8") as f:
            json.dump(self._data, f, ensure_ascii=False, indent=2)

    @staticmethod
    def _empty_store() -> dict[str, Any]:
        return {
            "version": "1.0",
            "templates": {},
            "metadata": {"total_templates": 0, "last_updated": None},
        }

    # ---- 公开接口 ----

    def match_template(
        self, transaction_code: str, scenario_type: str
    ) -> ScriptTemplate | None:
        """按事务码+场景类型精确匹配模板"""
        key = self._make_key(transaction_code, scenario_type)
        tpl_data = self._data["templates"].get(key)
        if tpl_data is None:
            return None
        return ScriptTemplate.from_dict(tpl_data)

    def save_template(self, template: ScriptTemplate) -> None:
        """保存或更新模板"""
        key = self._make_key(template.transaction_code, template.scenario_type)
        self._data["templates"][key] = template.to_dict()
        self._save()
        logger.info("模板已保存: %s (confidence=%s)", key, template.confidence.value)

    def update_confidence(self, template_id: str, success: bool) -> None:
        """更新模板置信度

        成功时:
          - DRAFT: consecutive_success_count + 1，达到阈值后升级为 STABLE
          - STABLE: consecutive_success_count + 1
          - NEEDS_FIX: 重置为 DRAFT，consecutive_success_count = 1

        失败时:
          - STABLE → DRAFT, consecutive_success_count 重置为 0
          - DRAFT → NEEDS_FIX, consecutive_success_count 重置为 0
          - NEEDS_FIX: 保持 NEEDS_FIX, consecutive_success_count 重置为 0
        """
        tpl_data = self._find_by_id(template_id)
        if tpl_data is None:
            logger.warning("未找到模板: %s", template_id)
            return

        current_confidence = TemplateConfidence(tpl_data["confidence"])

        if success:
            if current_confidence == TemplateConfidence.NEEDS_FIX:
                tpl_data["confidence"] = TemplateConfidence.DRAFT.value
                tpl_data["consecutive_success_count"] = 1
            else:
                tpl_data["consecutive_success_count"] = (
                    tpl_data.get("consecutive_success_count", 0) + 1
                )
                if (
                    current_confidence == TemplateConfidence.DRAFT
                    and tpl_data["consecutive_success_count"]
                    >= TEMPLATE_CONFIDENCE_THRESHOLD
                ):
                    tpl_data["confidence"] = TemplateConfidence.STABLE.value
            tpl_data["last_success_at"] = datetime.now().isoformat()
        else:
            tpl_data["consecutive_success_count"] = 0
            if current_confidence == TemplateConfidence.STABLE:
                tpl_data["confidence"] = TemplateConfidence.DRAFT.value
            elif current_confidence == TemplateConfidence.DRAFT:
                tpl_data["confidence"] = TemplateConfidence.NEEDS_FIX.value
            # NEEDS_FIX stays NEEDS_FIX

        self._save()
        logger.info(
            "模板置信度已更新: %s → %s (success=%s)",
            template_id,
            tpl_data["confidence"],
            success,
        )

    def record_path_correction(
        self, template_id: str, correction: dict[str, str]
    ) -> None:
        """记录路径修正到模板的 path_corrections 列表

        Args:
            template_id: 模板 ID
            correction: 修正记录字典，包含 original_path, corrected_path,
                        match_method, screen_context 等字段
        """
        tpl_data = self._find_by_id(template_id)
        if tpl_data is None:
            logger.warning("未找到模板: %s", template_id)
            return

        corrections = tpl_data.get("path_corrections", [])
        corrections.append({
            "step_description": correction.get("step_description", ""),
            "original_path": correction.get("original_path", ""),
            "corrected_path": correction.get("corrected_path", ""),
            "match_method": correction.get("match_method", ""),
            "context": correction.get("screen_context", ""),
        })
        tpl_data["path_corrections"] = corrections
        self._save()
        logger.info(
            "路径修正已记录: %s (共 %d 条)", template_id, len(corrections)
        )

    def update_element_paths(
        self, template_id: str, path_updates: dict[str, str]
    ) -> None:
        """更新模板中的元素路径映射"""
        tpl_data = self._find_by_id(template_id)
        if tpl_data is None:
            logger.warning("未找到模板: %s", template_id)
            return

        element_path_map = tpl_data.get("element_path_map", {})
        element_path_map.update(path_updates)
        tpl_data["element_path_map"] = element_path_map
        self._save()
        logger.info("模板元素路径已更新: %s (%d 条)", template_id, len(path_updates))

    def list_templates(self) -> list[TemplateInfo]:
        """列出所有模板的摘要信息"""
        result: list[TemplateInfo] = []
        for tpl_data in self._data["templates"].values():
            last_success_at = None
            if tpl_data.get("last_success_at"):
                last_success_at = datetime.fromisoformat(tpl_data["last_success_at"])
            result.append(
                TemplateInfo(
                    template_id=tpl_data["template_id"],
                    transaction_code=tpl_data["transaction_code"],
                    scenario_type=tpl_data["scenario_type"],
                    confidence=TemplateConfidence(
                        tpl_data.get("confidence", "草稿")
                    ),
                    last_success_at=last_success_at,
                )
            )
        return result

    # ---- 内部辅助 ----

    def _find_by_id(self, template_id: str) -> dict[str, Any] | None:
        """按 template_id 查找模板数据（返回可变引用）"""
        for tpl_data in self._data["templates"].values():
            if tpl_data.get("template_id") == template_id:
                return tpl_data
        return None
