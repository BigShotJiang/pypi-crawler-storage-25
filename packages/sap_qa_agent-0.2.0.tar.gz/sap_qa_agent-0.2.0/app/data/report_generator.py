"""测试报告生成器 — 输出 HTML 格式的测试报告。

支持单用例报告和测试套件报告，使用 Jinja2 模板渲染 HTML。
自动脱敏 SAP 系统凭据信息。
"""

from __future__ import annotations

import os
import re
from typing import Any

from jinja2 import Template

from app.data.models import (
    ExecutionMode,
    TestCaseResult,
    TestSuiteResult,
)

# SAP 凭据脱敏正则模式
_CREDENTIAL_PATTERNS = [
    # SAP 密码字段（password / passwd / passwort）
    re.compile(r"(password|passwd|passwort|kennwort)\s*[:=]\s*\S+", re.IGNORECASE),
    # API key 模式
    re.compile(r"(api[_-]?key|apikey)\s*[:=]\s*\S+", re.IGNORECASE),
    # SAP 客户端密码（client secret）
    re.compile(r"(client[_-]?secret)\s*[:=]\s*\S+", re.IGNORECASE),
    # Bearer token
    re.compile(r"(Bearer\s+)\S+", re.IGNORECASE),
    # SAP 连接字符串中的密码
    re.compile(r"(syspwd|mysapsso2|snc_partnername)\s*[:=]\s*\S+", re.IGNORECASE),
]

_REDACTED = "[REDACTED]"


# ---- HTML 模板 ----

_HTML_TEMPLATE = """\
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{{ title }}</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { font-family: -apple-system, "Segoe UI", "Microsoft YaHei", sans-serif;
         background: #f5f7fa; color: #333; padding: 24px; }
  .container { max-width: 1100px; margin: 0 auto; }
  h1 { font-size: 1.6rem; margin-bottom: 16px; }
  h2 { font-size: 1.2rem; margin: 20px 0 10px; border-left: 4px solid #409eff; padding-left: 10px; }
  .summary { display: flex; gap: 16px; flex-wrap: wrap; margin-bottom: 20px; }
  .stat-card { background: #fff; border-radius: 8px; padding: 16px 24px;
               box-shadow: 0 1px 3px rgba(0,0,0,.08); min-width: 140px; text-align: center; }
  .stat-card .num { font-size: 2rem; font-weight: 700; }
  .stat-card .label { font-size: .85rem; color: #888; margin-top: 4px; }
  .pass { color: #67c23a; }
  .fail { color: #f56c6c; }
  .skip { color: #e6a23c; }
  table { width: 100%; border-collapse: collapse; background: #fff;
          border-radius: 8px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,.08);
          margin-bottom: 20px; }
  th, td { padding: 10px 14px; text-align: left; border-bottom: 1px solid #ebeef5; font-size: .9rem; }
  th { background: #fafafa; font-weight: 600; }
  .badge { display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: .8rem; color: #fff; }
  .badge-pass { background: #67c23a; }
  .badge-fail { background: #f56c6c; }
  .badge-skip { background: #e6a23c; }
  .badge-explore { background: #409eff; }
  .badge-reuse { background: #909399; }
  .flow-chain { background: #fff; border-radius: 8px; padding: 16px;
                box-shadow: 0 1px 3px rgba(0,0,0,.08); margin-bottom: 20px; }
  .flow-chain code { background: #f0f2f5; padding: 2px 6px; border-radius: 3px; }
  .ai-note { background: #fdf6ec; border-left: 3px solid #e6a23c; padding: 8px 12px;
             margin: 4px 0; font-size: .85rem; border-radius: 0 4px 4px 0; }
  .screenshot-link { color: #409eff; text-decoration: none; }
  .screenshot-link:hover { text-decoration: underline; }
</style>
</head>
<body>
<div class="container">
  <h1>{{ title }}</h1>

  {% if suite %}
  <div class="summary">
    <div class="stat-card"><div class="num">{{ suite.total_cases }}</div><div class="label">总用例</div></div>
    <div class="stat-card"><div class="num pass">{{ suite.passed_cases }}</div><div class="label">通过</div></div>
    <div class="stat-card"><div class="num fail">{{ suite.failed_cases }}</div><div class="label">失败</div></div>
    <div class="stat-card"><div class="num skip">{{ suite.skipped_cases }}</div><div class="label">跳过</div></div>
    <div class="stat-card"><div class="num">{{ suite.new_templates }}</div><div class="label">新增模板</div></div>
    <div class="stat-card"><div class="num">{{ suite.template_upgrades }}</div><div class="label">模板升级</div></div>
  </div>

  {% if suite.flow_variable_chain %}
  <h2>FlowVariable 传递链</h2>
  <div class="flow-chain">
    {% for k, v in suite.flow_variable_chain.items() %}
    <div><code>${{ '{' }}{{ k }}{{ '}' }}</code> = <strong>{{ v }}</strong></div>
    {% endfor %}
  </div>
  {% endif %}
  {% endif %}

  {% for case in cases %}
  <h2>用例 {{ case.case_id }}
    <span class="badge {{ 'badge-pass' if case.success else 'badge-fail' }}">{{ '通过' if case.success else '失败' }}</span>
    <span class="badge {{ 'badge-explore' if case.execution_mode == 'exploration' else 'badge-reuse' }}">{{ '探索' if case.execution_mode == 'exploration' else '复用' }}</span>
  </h2>

  {% if case.template_solidified %}
  <p style="margin-bottom:8px;font-size:.85rem;color:#67c23a;">✅ 模板已固化</p>
  {% endif %}

  <table>
    <thead><tr><th>#</th><th>结果</th><th>状态栏消息</th><th>凭证号</th><th>截图</th><th>AI 干预</th></tr></thead>
    <tbody>
    {% for step in case.steps %}
    <tr>
      <td>{{ step.step_index }}</td>
      <td><span class="badge {{ 'badge-pass' if step.success else 'badge-fail' }}">{{ '✓' if step.success else '✗' }}</span></td>
      <td>{{ step.status_bar_message or '-' }}</td>
      <td>{{ step.extracted_document_number or '-' }}</td>
      <td>{% if step.screenshot_path %}<a class="screenshot-link" href="{{ step.screenshot_path }}">查看</a>{% else %}-{% endif %}</td>
      <td>{% if step.ai_intervention %}<div class="ai-note">{{ step.ai_intervention }}</div>{% else %}-{% endif %}</td>
    </tr>
    {% endfor %}
    </tbody>
  </table>

  {% if case.verifications %}
  <table>
    <thead><tr><th>验证项</th><th>结果</th><th>期望值</th><th>实际值</th></tr></thead>
    <tbody>
    {% for v in case.verifications %}
    <tr>
      <td>{{ v.description }}</td>
      <td><span class="badge {{ 'badge-pass' if v.passed else 'badge-fail' }}">{{ '通过' if v.passed else '失败' }}</span></td>
      <td>{{ v.expected_value or '-' }}</td>
      <td>{{ v.actual_value or '-' }}</td>
    </tr>
    {% endfor %}
    </tbody>
  </table>
  {% endif %}

  {% if case.failure_analysis %}
  <div class="ai-note"><strong>失败分析：</strong>{{ case.failure_analysis }}</div>
  {% endif %}
  {% endfor %}
</div>
</body>
</html>
"""


class ReportGenerator:
    """测试报告生成器，输出 HTML 格式。"""

    def generate_case_report(self, result: TestCaseResult) -> dict[str, Any]:
        """生成单用例测试报告数据字典。"""
        steps = []
        for sr in result.step_results:
            ai_text = None
            if sr.ai_intervention:
                ai_text = (
                    f"[{sr.ai_intervention.exception_type}] "
                    f"{sr.ai_intervention.ai_decision} → {sr.ai_intervention.result}"
                )
            steps.append({
                "step_index": sr.step_index,
                "success": sr.success,
                "status_bar_message": sr.status_bar_message,
                "extracted_document_number": sr.extracted_document_number,
                "screenshot_path": sr.screenshot_path,
                "ai_intervention": ai_text,
                "error_message": sr.error_message,
                "execution_time_ms": sr.execution_time_ms,
            })

        verifications = []
        for vr in result.verification_results:
            verifications.append({
                "description": vr.description,
                "passed": vr.passed,
                "expected_value": vr.expected_value,
                "actual_value": vr.actual_value,
            })

        return {
            "case_id": result.case_id,
            "success": result.success,
            "execution_mode": result.execution_mode.value,
            "template_solidified": result.template_solidified,
            "flow_variables_extracted": result.flow_variables_extracted,
            "failure_analysis": result.failure_analysis,
            "steps": steps,
            "verifications": verifications,
        }

    def generate_suite_report(self, result: TestSuiteResult) -> dict[str, Any]:
        """生成测试套件报告数据字典。"""
        cases = [self.generate_case_report(cr) for cr in result.case_results]
        return {
            "title": f"测试套件报告 — {result.suite_id}",
            "suite": {
                "suite_id": result.suite_id,
                "total_cases": result.total_cases,
                "passed_cases": result.passed_cases,
                "failed_cases": result.failed_cases,
                "skipped_cases": result.skipped_cases,
                "new_templates": result.new_templates,
                "template_upgrades": result.template_upgrades,
                "flow_variable_chain": result.flow_variable_chain,
            },
            "cases": cases,
        }

    def export_html(self, report_data: dict[str, Any], output_path: str) -> None:
        """导出 HTML 报告，自动脱敏 SAP 凭据。"""
        if "title" not in report_data:
            report_data["title"] = "SAP 自动化测试报告"
        if "cases" not in report_data:
            # 单用例报告包装
            report_data = {
                "title": f"用例报告 — {report_data.get('case_id', '')}",
                "suite": None,
                "cases": [report_data],
            }
        if "suite" not in report_data:
            report_data["suite"] = None

        template = Template(_HTML_TEMPLATE)
        html = template.render(**report_data)
        html = self._sanitize_credentials(html)

        os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(html)

    @staticmethod
    def _sanitize_credentials(text: str) -> str:
        """替换 SAP 凭据为 [REDACTED]。"""
        for pattern in _CREDENTIAL_PATTERNS:
            text = pattern.sub(
                lambda m: m.group(0).split("=")[0].split(":")[0].split()[-1]
                + "=" + _REDACTED
                if "=" in m.group(0)
                else m.group(1) + _REDACTED,
                text,
            )
        return text
