"""Pydantic 数据模型"""

from datetime import datetime
from enum import Enum

from pydantic import BaseModel, Field


class StepStatus(str, Enum):
    """步骤执行状态"""

    PENDING = "pending"
    SUCCESS = "success"
    FAILED = "failed"


class TaskStatus(str, Enum):
    """任务执行状态"""

    CREATED = "created"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


class StepInfo(BaseModel):
    """步骤信息"""

    index: int = Field(gt=0, description="步骤序号，必须为正整数")
    description: str = Field(min_length=1, description="步骤描述，不能为空")
    status: StepStatus = StepStatus.PENDING
    log: str | None = None
    screenshots: list[str] = []


class TaskInfo(BaseModel):
    """任务信息"""

    task_id: str
    filename: str
    status: TaskStatus = TaskStatus.CREATED
    steps: list[StepInfo] = []
    prompt: str | None = None
    raw_output: str | None = None
    error: str | None = None
    created_at: datetime
    started_at: datetime | None = None
    completed_at: datetime | None = None


class ExecuteRequest(BaseModel):
    """执行请求 - 包含用户编辑后的最终步骤列表"""

    steps: list[StepInfo]


class UploadResponse(BaseModel):
    """上传响应"""

    task_id: str
    filename: str
    step_count: int
    steps: list[StepInfo]


class ExecuteResponse(BaseModel):
    """执行响应"""

    task_id: str
    message: str


class ScreenshotInfo(BaseModel):
    """截图信息"""

    step_index: int | None = None
    filepath: str
    timestamp: datetime


class TaskStatusResponse(BaseModel):
    """任务状态响应"""

    task_id: str
    filename: str
    status: TaskStatus
    steps: list[StepInfo]
    prompt: str | None = None
    error: str | None = None
    created_at: datetime
    started_at: datetime | None = None
    completed_at: datetime | None = None
