"""FastAPI 应用入口"""

import logging
import os

# 配置日志：让 vlm_executor 等模块的 logger.info() 输出可见
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    datefmt="%H:%M:%S",
)

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from .config import ARTIFACTS_DIR, FRONTEND_DEV_URL, KNOWLEDGE_BASE_DIR, UPLOAD_DIR
from .routes import router
from .sap_routes import sap_router

# 确保必要目录存在
os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(ARTIFACTS_DIR, exist_ok=True)
os.makedirs(KNOWLEDGE_BASE_DIR, exist_ok=True)

app = FastAPI(title="Excel Agent TARS 执行器", version="0.1.0")

# 配置 CORS，允许前端开发服务器跨域访问
app.add_middleware(
    CORSMiddleware,
    allow_origins=[FRONTEND_DEV_URL],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 注册 API 路由
app.include_router(router)
app.include_router(sap_router)

# 配置静态文件服务（截图文件访问）
app.mount("/artifacts", StaticFiles(directory=ARTIFACTS_DIR), name="artifacts")


@app.get("/api/health")
async def health_check():
    return {"status": "ok"}


def run() -> None:
    """``sap-qa-backend`` 脚本入口：启动 FastAPI + Uvicorn。

    用于 ``pyproject.toml`` 的 ``[project.scripts]`` 入口点。端口 / 主机从
    ``app.config`` 读取，便于集中调整。

    现有 ``python -m uvicorn app.main:app`` 启动方式保持可用——此函数仅在被显式
    调用时才会导入 ``uvicorn``，不会产生模块级副作用。

    启动前先尝试获取 MCP 通道锁（design §6 / §13.2、R18.2–R18.3）。锁文件位于
    ``$ARTIFACTS_DIR/.sap-channel.lock``。若另一通道（``sap-qa-mcp``）已持有
    锁且其 PID 仍存活，则打印冲突信息到 stderr 并以退出码 2 终止，避免两侧
    同时驱动 SAP GUI COM。若锁为 stale（owner 已退出），会自动覆盖。
    """
    import sys as _sys

    from . import config
    from .mcp_server.channel_lock import ChannelLock, ChannelLockedError

    _channel_lock = ChannelLock(config.ARTIFACTS_DIR)
    try:
        _channel_lock.acquire("backend")
    except ChannelLockedError as exc:
        owner = exc.owner
        print(
            "SAP channel already owned by another process: "
            f"channel={owner.channel} pid={owner.pid} "
            f"started_at={owner.started_at} host={owner.host}.\n"
            "Stop the other channel (sap-qa-mcp) before starting sap-qa-backend.",
            file=_sys.stderr,
        )
        raise SystemExit(2) from exc

    import uvicorn

    uvicorn.run(
        app,
        host=config.BACKEND_HOST,
        port=config.BACKEND_PORT,
        log_level="info",
    )
