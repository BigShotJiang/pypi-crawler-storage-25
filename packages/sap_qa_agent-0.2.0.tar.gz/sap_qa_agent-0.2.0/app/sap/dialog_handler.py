"""SAP 级弹窗智能检测与处理。

在每个步骤执行前后检测 SAP 应用层弹窗（wnd[1]），
根据弹窗内容智能决定处理方式：已知模式直接处理，未知弹窗调用 GLM 分析。
"""

from __future__ import annotations

import logging
import time
from typing import Any

from app.config import GLM_EXCEPTION_TIMEOUT
from app.data.models import DialogRecord

logger = logging.getLogger(__name__)

MAX_STACKED_DIALOGS = 5
DIALOG_WAIT_MS = 500

# 已知弹窗模式
_SUCCESS_KEYWORDS = ("已保存", "已创建", "成功", "saved", "created", "success")
_ERROR_KEYWORDS = ("错误", "error")
_MULTI_LOGIN_KEYWORDS = ("用户已登录", "已经登录", "already logged")


class DialogHandler:
    """SAP 级弹窗智能检测与处理。"""

    def __init__(self, sap_wrapper: Any, glm_client: Any) -> None:
        self._sap = sap_wrapper
        self._glm = glm_client

    async def check_and_handle(self) -> list[DialogRecord]:
        """检测并处理所有叠加的 SAP_Dialog，最多 5 个。

        Returns:
            处理记录列表
        """
        records: list[DialogRecord] = []

        for _ in range(MAX_STACKED_DIALOGS):
            dialog = self._sap.check_modal_dialog()
            if dialog is None:
                break

            start_t = time.time()
            record = await self._handle_single_dialog(dialog)
            record.elapsed_ms = int((time.time() - start_t) * 1000)
            records.append(record)

            time.sleep(DIALOG_WAIT_MS / 1000.0)

        return records

    async def _handle_single_dialog(self, dialog: dict) -> DialogRecord:
        """处理单个 SAP_Dialog。"""
        title = dialog.get("title", "")
        text = dialog.get("text", "")
        title_lower = title.lower()
        text_lower = text.lower()

        # 成功类弹窗 → 确认
        if any(kw in text_lower for kw in _SUCCESS_KEYWORDS):
            self._click_confirm()
            return DialogRecord(
                title=title, text=text, action="confirm",
                reason="成功类弹窗",
            )

        # 错误类弹窗 → 读取文本后确认
        if any(kw in title_lower for kw in _ERROR_KEYWORDS):
            full_text = self._read_full_dialog_text()
            self._click_confirm()
            return DialogRecord(
                title=title, text=full_text or text,
                action="confirm", reason="错误弹窗",
                error_text=full_text or text,
            )

        # 多重登录警告 → 确认
        if any(kw in text_lower for kw in _MULTI_LOGIN_KEYWORDS):
            self._click_confirm()
            return DialogRecord(
                title=title, text=text, action="confirm",
                reason="多重登录警告",
            )

        # 未知弹窗 → GLM 分析
        try:
            suggestion = await self._glm.analyze_dialog(
                dialog_title=title,
                dialog_text=text,
                timeout=GLM_EXCEPTION_TIMEOUT,
            )
            action = suggestion.get("action", "confirm")
            if action == "confirm":
                self._click_confirm()
            elif action == "cancel":
                self._click_cancel()
            elif action == "input":
                self._input_value(suggestion.get("value", ""))
                self._click_confirm()
            return DialogRecord(
                title=title, text=text, action=action,
                reason=f"GLM 建议: {suggestion.get('reason', '')}",
            )
        except Exception as exc:
            # GLM 超时或异常 → 默认确认
            logger.warning("GLM 弹窗分析超时/异常: %s，默认确认", exc)
            self._click_confirm()
            return DialogRecord(
                title=title, text=text, action="confirm",
                reason=f"GLM 超时，默认确认: {exc}",
            )

    def _click_confirm(self) -> None:
        try:
            self._sap.press_button("wnd[1]/tbar[0]/btn[0]")
        except Exception as exc:
            logger.warning("点击确认按钮失败: %s", exc)

    def _click_cancel(self) -> None:
        try:
            self._sap.press_button("wnd[1]/tbar[0]/btn[1]")
        except Exception as exc:
            logger.warning("点击取消按钮失败: %s", exc)

    def _input_value(self, value: str) -> None:
        try:
            self._sap.set_text("wnd[1]/usr/txtV1", value)
        except Exception as exc:
            logger.warning("弹窗输入值失败: %s", exc)

    def _read_full_dialog_text(self) -> str:
        """读取弹窗完整文本。"""
        texts = []
        for path in [
            "wnd[1]/usr/txtMESSTXT1",
            "wnd[1]/usr/txtMESSTXT2",
            "wnd[1]/usr/txtMESSTXT3",
            "wnd[1]/usr/lblMESSTXT1",
        ]:
            try:
                elem = self._sap.find_element(path)
                if elem and elem.Text:
                    texts.append(str(elem.Text))
            except Exception:
                continue
        return " | ".join(texts)
