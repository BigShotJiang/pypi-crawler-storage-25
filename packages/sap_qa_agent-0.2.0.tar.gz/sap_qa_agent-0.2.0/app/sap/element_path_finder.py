"""SAP GUI 元素路径发现与修正

通过 Children 属性递归遍历元素树，实现元素路径的自动发现与修正。
支持 5 级优先级匹配策略和 ALV Grid 表格定位。
"""

from __future__ import annotations

import logging
import re
from typing import Any

from app.config import MAX_ELEMENT_TREE_DEPTH
from app.data.models import (
    ElementInfo,
    ElementMatchResult,
    ElementTree,
)

logger = logging.getLogger(__name__)


class ElementPathFinder:
    """SAP GUI 元素路径发现与修正。

    通过 SapGuiWrapper 遍历元素树，建立标签映射，
    按 5 级优先级匹配目标元素，支持 GLM 辅助消歧。
    """

    def __init__(self, sap_wrapper: Any, glm_client: Any) -> None:
        """
        Args:
            sap_wrapper: SapGuiWrapper instance for COM operations.
            glm_client: GlmClient instance for AI-assisted disambiguation.
        """
        self._sap_wrapper = sap_wrapper
        self._glm_client = glm_client
        self._cached_tree: ElementTree | None = None

    # ------------------------------------------------------------------
    # Element tree traversal
    # ------------------------------------------------------------------

    def traverse_element_tree(
        self, root_path: str, max_depth: int = MAX_ELEMENT_TREE_DEPTH
    ) -> ElementTree:
        """递归遍历 Children 属性，采集元素信息。

        Args:
            root_path: Root element ID path (e.g. "wnd[0]/usr").
            max_depth: Maximum recursion depth (default from config).

        Returns:
            ElementTree containing all discovered elements and label map.
        """
        elements: list[ElementInfo] = []
        self._traverse_recursive(root_path, elements, current_depth=0, max_depth=max_depth)
        label_map = self._build_label_map_from_elements(elements)
        tree = ElementTree(root_path=root_path, elements=elements, label_map=label_map)
        self._cached_tree = tree
        logger.info(
            "Traversed element tree from '%s': %d elements, %d labels",
            root_path, len(elements), len(label_map),
        )
        return tree

    def generate_fingerprint(self, window_title: str) -> Any:
        """从缓存的元素树生成页面指纹。

        Args:
            window_title: 当前 SAP 窗口标题

        Returns:
            PageFingerprint 对象，或 None（无缓存时）
        """
        if self._cached_tree is None:
            return None
        from app.sap.fingerprint_generator import generate_fingerprint
        return generate_fingerprint(
            window_title=window_title,
            element_tree=self._cached_tree,
            sap_wrapper=self._sap_wrapper,
        )

    def _traverse_recursive(
        self,
        path: str,
        elements: list[ElementInfo],
        current_depth: int,
        max_depth: int,
    ) -> None:
        """Recursively traverse SAP GUI element tree via Children property.

        对 GuiShell (ALV Grid/Table) 类型做特殊处理：
        用 Grid 专用 API 采集列信息，生成虚拟的可输入元素。

        对 GuiTabStrip 做特殊处理：
        通过 Children 遍历所有 GuiTab 页签标签，确保每个页签都被采集。
        """
        if current_depth > max_depth:
            return

        element = self._sap_wrapper.find_element(path)
        if element is None:
            return

        # Collect element info
        info = self._extract_element_info(element, path)
        if info is not None:
            elements.append(info)

        # Special handling for GuiShell (ALV Grid / Table Control)
        elem_type = ""
        try:
            elem_type = str(element.Type) if element.Type else ""
        except Exception:
            pass

        if elem_type == "GuiShell":
            self._extract_grid_elements(element, path, elements)
            return  # Grid 内部不用递归 Children

        # Special handling for GuiTabStrip: enumerate all tab labels
        if elem_type == "GuiTabStrip":
            self._extract_tabstrip_tabs(element, path, elements, current_depth, max_depth)
            return  # 已经在内部处理了 Children 遍历

        # Recurse into children
        try:
            children = element.Children
            if children is None:
                return
            count = children.Count
            for i in range(count):
                try:
                    child = children(i)
                    child_id = str(child.Id)
                    self._traverse_recursive(
                        child_id, elements, current_depth + 1, max_depth
                    )
                except Exception as exc:
                    logger.debug("Error traversing child %d of %s: %s", i, path, exc)
        except Exception:
            # Element has no Children property – leaf node
            pass

        # TableControl: 子元素遍历完后，读取列标题映射到单元格
        if elem_type == "GuiTableControl":
            self._extract_table_control_elements(element, path, elements)

    def _extract_tabstrip_tabs(
        self,
        tabstrip: Any,
        tabstrip_path: str,
        elements: list[ElementInfo],
        current_depth: int,
        max_depth: int,
    ) -> None:
        """从 GuiTabStrip 中提取所有页签标签（GuiTab）及活动页签内容。

        GuiTabStrip.Children 包含所有 GuiTab 页签。
        对每个 GuiTab：提取标签信息（名称如"条件"、"物料数据"）。
        对当前活动的 GuiTab：还要递归遍历其子元素（页签内容面板）。
        """
        try:
            children = tabstrip.Children
            if children is None:
                return

            count = children.Count
            tab_count = 0

            for i in range(count):
                try:
                    child = children(i)
                    child_type = ""
                    try:
                        child_type = str(child.Type) if child.Type else ""
                    except Exception:
                        pass

                    child_id = str(child.Id)

                    if child_type == "GuiTab":
                        # 提取页签标签信息
                        tab_info = self._extract_element_info(child, child_id)
                        if tab_info is not None:
                            elements.append(tab_info)
                            tab_count += 1

                        # 递归遍历页签内容（所有页签都尝试，
                        # 非活动页签的 Children 通常为空或抛异常，会自动跳过）
                        try:
                            tab_children = child.Children
                            if tab_children and tab_children.Count > 0:
                                for j in range(tab_children.Count):
                                    try:
                                        tab_child = tab_children(j)
                                        tab_child_id = str(tab_child.Id)
                                        self._traverse_recursive(
                                            tab_child_id, elements,
                                            current_depth + 1, max_depth,
                                        )
                                    except Exception:
                                        pass
                        except Exception:
                            # 非活动页签没有可访问的子元素，正常跳过
                            pass
                    else:
                        # 非 GuiTab 子元素（可能是内容面板），继续递归
                        self._traverse_recursive(
                            child_id, elements, current_depth + 1, max_depth
                        )
                except Exception as exc:
                    logger.debug("Error traversing tabstrip child %d of %s: %s", i, tabstrip_path, exc)

            logger.info("TabStrip %s: found %d tabs", tabstrip_path, tab_count)

        except Exception as exc:
            logger.debug("TabStrip extraction failed for %s: %s", tabstrip_path, exc)

    def _extract_grid_elements(
        self, grid: Any, grid_path: str, elements: list[ElementInfo],
    ) -> None:
        """从 GuiShell (ALV Grid) 中提取列信息和行数据。

        为每一列生成一个虚拟 ElementInfo，让 ElementPathFinder 能匹配到
        表格中的字段（如"物料"、"数量"、"工厂"）。
        """
        try:
            # 尝试获取列信息
            columns = []
            try:
                col_order = grid.ColumnOrder
                for col_id in col_order:
                    col_title = ""
                    try:
                        col_title = grid.GetColumnTitles(col_id)
                        if isinstance(col_title, (list, tuple)):
                            col_title = col_title[0] if col_title else ""
                        col_title = str(col_title) if col_title else ""
                    except Exception:
                        pass
                    columns.append({"id": str(col_id), "title": col_title})
            except Exception:
                # 备选：尝试 Columns 属性
                try:
                    cols = grid.Columns
                    for i in range(cols.Count):
                        col = cols(i)
                        col_id = str(col.ColumnName) if hasattr(col, 'ColumnName') else f"col_{i}"
                        col_title = str(col.Title) if hasattr(col, 'Title') else ""
                        columns.append({"id": col_id, "title": col_title})
                except Exception:
                    pass

            row_count = 0
            try:
                row_count = grid.RowCount
            except Exception:
                pass

            logger.info("Grid %s: %d columns, %d rows", grid_path, len(columns), row_count)

            # 为每列生成虚拟元素（用于 label 匹配）
            for col in columns:
                col_id = col["id"]
                col_title = col["title"]
                # 虚拟路径格式：grid_path/col[col_id]
                virtual_path = f"{grid_path}/col[{col_id}]"
                elements.append(ElementInfo(
                    id_path=virtual_path,
                    element_type="GuiGridColumn",
                    tooltip=col_title,
                    label_text=col_title,
                    current_value=f"grid_col:{col_id},rows:{row_count}",
                ))

            # 记录 Grid 本身的信息
            if info := self._extract_element_info(grid, grid_path):
                info.current_value = f"rows={row_count}, cols={len(columns)}"

        except Exception as exc:
            logger.debug("Grid element extraction failed for %s: %s", grid_path, exc)

    def _extract_table_control_elements(
        self, table: Any, table_path: str, elements: list[ElementInfo],
    ) -> None:
        """从 GuiTableControl 中提取列标题，映射到单元格路径。

        SAP GuiTableControl 的子元素路径格式：
          tblXXX/xxxFIELD-NAME[col_index, row_index]

        策略：
        1. 读取列标题（Columns 属性）
        2. 为每行的每个单元格设置 label_text = "列标题"
        3. 找到"标识列"（类型/名称等），为同行其他单元格生成复合 label
           如 "PBXX 金额"、"PBXX 货币"，让 GLM 能按行条件定位
        """
        try:
            columns = table.Columns
            if columns is None:
                return

            col_count = columns.Count
            col_info: list[dict] = []

            for i in range(col_count):
                try:
                    col = columns(i)
                    title = ""
                    try:
                        title = str(col.Title) if col.Title else ""
                    except Exception:
                        pass
                    col_info.append({"index": i, "title": title})
                except Exception:
                    pass

            row_count = 0
            try:
                row_count = table.RowCount
            except Exception:
                pass

            visible_rows = row_count
            try:
                visible_rows = table.VisibleRowCount
            except Exception:
                pass

            logger.info(
                "TableControl %s: %d columns, %d rows (visible: %d), titles: %s",
                table_path, len(col_info), row_count, visible_rows,
                [c["title"] for c in col_info if c["title"]][:10],
            )

            # 第一步：为每列每行的单元格设置基础 label = 列标题
            for col in col_info:
                if not col["title"]:
                    continue
                col_idx = col["index"]
                for row_idx in range(visible_rows):
                    target_suffix = f"[{col_idx},{row_idx}]"
                    for elem in elements:
                        if (elem.id_path.startswith(table_path + "/")
                                and elem.id_path.endswith(target_suffix)):
                            if not elem.label_text:
                                elem.label_text = col["title"]
                            break

            # 第二步：为每行生成复合 label "行标识值 + 列标题"
            # 行标识 = 该行第一个有非空值的单元格内容（如 PBXX、NAVS）
            for row_idx in range(visible_rows):
                # 找该行的标识值：遍历各列，取第一个有值的单元格
                row_id_value = ""
                for col in col_info:
                    cell_suffix = f"[{col['index']},{row_idx}]"
                    for elem in elements:
                        if (elem.id_path.startswith(table_path + "/")
                                and elem.id_path.endswith(cell_suffix)):
                            val = (elem.current_value or "").strip()
                            # 跳过纯数字、空值、货币代码等无意义标识
                            if val and not val.replace(",", "").replace(".", "").replace(" ", "").isdigit():
                                row_id_value = val
                            break
                    if row_id_value:
                        break

                if not row_id_value:
                    continue

                # 为同行其他列的单元格添加复合 label: "PBXX 金额"
                for col in col_info:
                    if not col["title"]:
                        continue
                    cell_suffix = f"[{col['index']},{row_idx}]"
                    for elem in elements:
                        if (elem.id_path.startswith(table_path + "/")
                                and elem.id_path.endswith(cell_suffix)):
                            # 跳过标识列本身（值就是 row_id_value 的那个）
                            if (elem.current_value or "").strip() == row_id_value:
                                break
                            composite_label = f"{row_id_value} {col['title']}"
                            if not elem.label_text or elem.label_text == col["title"]:
                                elem.label_text = composite_label
                            if not elem.tooltip:
                                elem.tooltip = composite_label
                            logger.debug(
                                "TableControl row label: '%s' → %s",
                                composite_label, elem.id_path,
                            )
                            break

        except Exception as exc:
            logger.debug("TableControl extraction failed for %s: %s", table_path, exc)

    @staticmethod
    def _extract_element_info(element: Any, path: str) -> ElementInfo | None:
        """Extract ElementInfo from a COM element object.

        Handles SAP-specific element types:
        - GuiTextField/GuiCTextField: text input fields
        - GuiPasswordField: password fields
        - GuiComboBox: dropdown lists (reads key + selected value)
        - GuiCheckBox: checkboxes
        - GuiRadioButton: radio buttons
        - GuiLabel: labels (used for label_map building)
        - GuiTab/GuiTabStrip: page tabs
        - GuiTableControl/GuiGridView: tables (reads row/column info)
        - GuiButton: buttons
        """
        try:
            element_type = ""
            tooltip = ""
            label_text = ""
            current_value = ""

            try:
                element_type = str(element.Type) if element.Type else ""
            except Exception:
                pass
            try:
                tooltip = str(element.Tooltip) if element.Tooltip else ""
            except Exception:
                pass

            # Read value based on element type
            try:
                if element_type == "GuiComboBox":
                    # Dropdown: read key and text
                    try:
                        current_value = f"key={element.Key}, text={element.Text}"
                    except Exception:
                        current_value = str(element.Text) if element.Text else ""
                elif element_type in ("GuiCheckBox", "GuiRadioButton"):
                    try:
                        current_value = "selected" if element.Selected else "unselected"
                    except Exception:
                        pass
                elif element_type in ("GuiTableControl",):
                    try:
                        current_value = f"rows={element.RowCount}, cols={element.Columns.Count}"
                    except Exception:
                        pass
                elif element_type == "GuiGridView":
                    try:
                        current_value = f"rows={element.RowCount}, cols={element.ColumnCount}"
                    except Exception:
                        pass
                elif element_type in ("GuiTab",):
                    try:
                        current_value = str(element.Text) if element.Text else ""
                    except Exception:
                        pass
                else:
                    try:
                        current_value = str(element.Text) if element.Text else ""
                    except Exception:
                        pass
            except Exception:
                pass

            # Label text: try multiple sources
            try:
                if hasattr(element, "DefaultTooltip") and element.DefaultTooltip:
                    label_text = str(element.DefaultTooltip)
            except Exception:
                pass
            if not label_text:
                try:
                    if hasattr(element, "IconName") and element.IconName:
                        label_text = str(element.IconName)
                except Exception:
                    pass
            # For labels, use the Text as label_text
            if not label_text and element_type == "GuiLabel":
                try:
                    label_text = str(element.Text) if element.Text else ""
                except Exception:
                    pass
            # For tabs, use the Text as label_text (e.g. "条件", "物料数据")
            if not label_text and element_type == "GuiTab":
                try:
                    label_text = str(element.Text) if element.Text else ""
                except Exception:
                    pass
            # For buttons, use the Text as label_text
            if not label_text and element_type == "GuiButton":
                try:
                    label_text = str(element.Text) if element.Text else ""
                except Exception:
                    pass

            # 读取 changeable 属性（SAP GUI 元素是否可编辑）
            is_changeable = True
            try:
                is_changeable = bool(element.Changeable)
            except Exception:
                pass

            return ElementInfo(
                id_path=path,
                element_type=element_type,
                tooltip=tooltip,
                label_text=label_text,
                current_value=current_value,
                is_changeable=is_changeable,
            )
        except Exception as exc:
            logger.debug("Failed to extract info from %s: %s", path, exc)
            return None

    # ------------------------------------------------------------------
    # Label map
    # ------------------------------------------------------------------

    def build_label_map(self, element_tree: ElementTree) -> dict[str, str]:
        """建立"标签文本 → 输入框 ID"映射。

        Args:
            element_tree: Previously traversed ElementTree.

        Returns:
            Dict mapping label text to element ID path.
        """
        return self._build_label_map_from_elements(element_tree.elements)

    @staticmethod
    def _build_label_map_from_elements(elements: list[ElementInfo]) -> dict[str, str]:
        """Build label-to-path mapping from element list.

        Strategy: for each label element (GuiLabel), map its text to the
        next input-capable element in the list (GuiCTextField, GuiTextField, etc.).
        Also maps tooltip and label_text directly.
        Maps clickable elements (GuiTab, GuiButton) by their label_text.
        """
        label_map: dict[str, str] = {}
        input_types = {
            "GuiCTextField", "GuiTextField", "GuiComboBox",
            "GuiPasswordField", "GuiCheckBox", "GuiRadioButton",
        }
        # Clickable types that should also be in label_map
        clickable_types = {"GuiTab", "GuiButton"}

        # Direct mapping from tooltip / label_text for input elements
        for elem in elements:
            if elem.tooltip and elem.element_type in input_types:
                label_map[elem.tooltip] = elem.id_path
            if elem.label_text and elem.element_type in input_types:
                label_map[elem.label_text] = elem.id_path

        # Map clickable elements (tabs, buttons) by their label_text
        for elem in elements:
            if elem.label_text and elem.element_type in clickable_types:
                label_map[elem.label_text] = elem.id_path

        # Positional mapping: GuiLabel → next input element
        for i, elem in enumerate(elements):
            if elem.element_type == "GuiLabel" and elem.current_value:
                # Find the next input-capable element
                for j in range(i + 1, min(i + 5, len(elements))):
                    if elements[j].element_type in input_types:
                        label_map[elem.current_value] = elements[j].id_path
                        break

        return label_map

    # ------------------------------------------------------------------
    # Element matching (5-level priority)
    # ------------------------------------------------------------------

    def find_element_by_description(
        self, description: str, context_window: str | None = None
    ) -> ElementMatchResult:
        """按 5 级优先级匹配目标元素。

        Priority levels:
            1. 标签精确匹配 (label_exact)
            2. Tooltip 精确匹配 (tooltip_exact)
            3. 标签模糊匹配 (label_fuzzy)
            4. 技术名称匹配 (tech_name)
            5. 位置上下文匹配 (position)

        Args:
            description: Target field description (e.g. "销售组织").
            context_window: Optional window context (e.g. "wnd[0]").

        Returns:
            ElementMatchResult with found status, element, and match method.
        """
        # Ensure we have a tree
        if self._cached_tree is None:
            root = context_window or "wnd[0]/usr"
            self.traverse_element_tree(root)

        tree = self._cached_tree
        if tree is None:
            return ElementMatchResult(found=False)

        # Level 1: Label exact match
        if description in tree.label_map:
            path = tree.label_map[description]
            elem = self._find_element_info_by_path(tree, path)
            if elem:
                logger.info("Match L1 (label_exact): '%s' → %s", description, path)
                return ElementMatchResult(
                    found=True, element=elem, match_method="label_exact"
                )

        # Level 1.5: Label contains match (e.g. "订单类型" matches "订单类型（采购）")
        # 也支持复合 label 匹配：描述 "PB00条件类型价格" 包含行标识 "PB00"，
        # 匹配到 label "PB00 金额"
        contains_matches = []
        for label, path in tree.label_map.items():
            if description in label or label in description:
                elem = self._find_element_info_by_path(tree, path)
                if elem:
                    contains_matches.append(elem)
                continue
            # 复合 label 匹配：label 格式 "行标识 列标题"，检查行标识是否在描述中
            if " " in label:
                row_id = label.split(" ")[0]
                if len(row_id) >= 2 and row_id in description:
                    elem = self._find_element_info_by_path(tree, path)
                    if elem:
                        contains_matches.append(elem)
        if len(contains_matches) == 1:
            logger.info("Match L1.5 (label_contains): '%s' → %s", description, contains_matches[0].id_path)
            return ElementMatchResult(
                found=True, element=contains_matches[0], match_method="label_contains"
            )

        # Level 2: Tooltip exact match
        for elem in tree.elements:
            if elem.tooltip == description:
                logger.info("Match L2 (tooltip_exact): '%s' → %s", description, elem.id_path)
                return ElementMatchResult(
                    found=True, element=elem, match_method="tooltip_exact"
                )

        # Level 3: Label fuzzy match
        candidates = self._fuzzy_match_label(tree, description)
        if len(candidates) == 1:
            logger.info("Match L3 (label_fuzzy): '%s' → %s", description, candidates[0].id_path)
            return ElementMatchResult(
                found=True, element=candidates[0], match_method="label_fuzzy"
            )
        if len(candidates) > 1:
            logger.info(
                "Match L3 (label_fuzzy): '%s' → %d candidates, needs disambiguation",
                description, len(candidates),
            )
            return ElementMatchResult(
                found=False, candidates=candidates, match_method="label_fuzzy"
            )

        # Level 4: Technical name match
        tech_match = self._match_technical_name(tree, description)
        if tech_match:
            logger.info("Match L4 (tech_name): '%s' → %s", description, tech_match.id_path)
            return ElementMatchResult(
                found=True, element=tech_match, match_method="tech_name"
            )

        # Level 5: Position context match
        position_candidates = self._match_by_position(tree, description)
        if len(position_candidates) == 1:
            logger.info("Match L5 (position): '%s' → %s", description, position_candidates[0].id_path)
            return ElementMatchResult(
                found=True, element=position_candidates[0], match_method="position"
            )
        if len(position_candidates) > 1:
            return ElementMatchResult(
                found=False, candidates=position_candidates, match_method="position"
            )

        logger.warning("No match found for '%s'", description)
        return ElementMatchResult(found=False)

    # ------------------------------------------------------------------
    # Fuzzy matching helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _fuzzy_match_label(tree: ElementTree, description: str) -> list[ElementInfo]:
        """Fuzzy match against label_map keys and element labels/tooltips."""
        candidates: list[ElementInfo] = []
        desc_lower = description.lower()

        # Check label_map keys
        matched_paths: set[str] = set()
        for label, path in tree.label_map.items():
            if _fuzzy_contains(desc_lower, label.lower()):
                matched_paths.add(path)

        # Check element tooltips and label_text
        for elem in tree.elements:
            if elem.id_path in matched_paths:
                candidates.append(elem)
                continue
            if elem.tooltip and _fuzzy_contains(desc_lower, elem.tooltip.lower()):
                candidates.append(elem)
            elif elem.label_text and _fuzzy_contains(desc_lower, elem.label_text.lower()):
                candidates.append(elem)

        return candidates

    @staticmethod
    def _match_technical_name(tree: ElementTree, description: str) -> ElementInfo | None:
        """Match by SAP technical field name embedded in the element path.

        E.g. description="VBAK-AUART" matches path containing "ctxtVBAK-AUART".
        """
        desc_upper = description.upper().replace(" ", "")
        for elem in tree.elements:
            # Extract technical name from path (last segment after /)
            path_parts = elem.id_path.split("/")
            if path_parts:
                last_part = path_parts[-1].upper()
                # Remove type prefix (ctxt, txt, cmb, etc.)
                tech_name = re.sub(r"^(CTXT|TXT|CMB|CHK|RAD|BTN|LBL|TAB)", "", last_part)
                if desc_upper in tech_name or tech_name in desc_upper:
                    return elem
        return None

    @staticmethod
    def _match_by_position(tree: ElementTree, description: str) -> list[ElementInfo]:
        """Match by positional context – elements near labels containing the description."""
        candidates: list[ElementInfo] = []
        input_types = {
            "GuiCTextField", "GuiTextField", "GuiComboBox",
            "GuiPasswordField", "GuiCheckBox", "GuiRadioButton",
        }
        desc_lower = description.lower()

        for i, elem in enumerate(tree.elements):
            if elem.element_type == "GuiLabel" and elem.current_value:
                if desc_lower in elem.current_value.lower():
                    # Find nearby input elements
                    for j in range(i + 1, min(i + 5, len(tree.elements))):
                        if tree.elements[j].element_type in input_types:
                            candidates.append(tree.elements[j])
                            break
        return candidates

    @staticmethod
    def _find_element_info_by_path(
        tree: ElementTree, path: str
    ) -> ElementInfo | None:
        """Find ElementInfo in tree by id_path."""
        for elem in tree.elements:
            if elem.id_path == path:
                return elem
        return None

    # ------------------------------------------------------------------
    # AI disambiguation
    # ------------------------------------------------------------------

    async def resolve_ambiguity(
        self, candidates: list[ElementInfo], step_context: str
    ) -> ElementInfo:
        """多候选时调用 GLM 选择最佳元素。

        Args:
            candidates: List of candidate ElementInfo objects.
            step_context: Description of the current step for context.

        Returns:
            The selected ElementInfo.

        Raises:
            RuntimeError: If GLM selection fails.
        """
        if len(candidates) == 1:
            return candidates[0]

        try:
            selected_index = await self._glm_client.select_element(
                candidates, step_context
            )
            if 0 <= selected_index < len(candidates):
                selected = candidates[selected_index]
                logger.info(
                    "GLM resolved ambiguity: selected index %d → %s",
                    selected_index, selected.id_path,
                )
                return selected
            else:
                logger.warning(
                    "GLM returned invalid index %d for %d candidates",
                    selected_index, len(candidates),
                )
        except Exception as exc:
            logger.error("GLM disambiguation failed: %s", exc)

        # Fallback: return first candidate
        logger.warning("Falling back to first candidate")
        return candidates[0]

    # ------------------------------------------------------------------
    # ALV Grid support
    # ------------------------------------------------------------------

    def find_alv_grid_cell(
        self,
        shell_path: str,
        row_condition: dict,
        column_name: str,
    ) -> dict | None:
        """ALV Grid 表格按行条件+列名定位单元格。

        Args:
            shell_path: Path to the ALV Grid shell element.
            row_condition: Dict of {column_name: expected_value} to identify the row.
            column_name: Target column name to read/write.

        Returns:
            Dict with 'row', 'column', 'value' keys, or None if not found.
        """
        shell = self._sap_wrapper.find_element(shell_path)
        if shell is None:
            logger.warning("ALV Grid shell not found: %s", shell_path)
            return None

        try:
            row_count = shell.RowCount
            columns = []
            try:
                col_order = shell.ColumnOrder
                columns = list(col_order)
            except Exception:
                logger.debug("Could not get ColumnOrder for %s", shell_path)
                return None

            # Find target column index
            if column_name not in columns:
                logger.warning("Column '%s' not found in ALV Grid", column_name)
                return None

            # Search rows matching condition
            for row_idx in range(row_count):
                match = True
                for cond_col, cond_val in row_condition.items():
                    if cond_col not in columns:
                        match = False
                        break
                    try:
                        cell_value = str(shell.GetCellValue(row_idx, cond_col))
                        if cell_value != str(cond_val):
                            match = False
                            break
                    except Exception:
                        match = False
                        break

                if match:
                    try:
                        value = str(shell.GetCellValue(row_idx, column_name))
                        logger.info(
                            "ALV Grid cell found: row=%d, col='%s', value='%s'",
                            row_idx, column_name, value,
                        )
                        return {
                            "row": row_idx,
                            "column": column_name,
                            "value": value,
                        }
                    except Exception as exc:
                        logger.warning("Failed to read cell value: %s", exc)
                        return None

            logger.info("No matching row found in ALV Grid for condition: %s", row_condition)
            return None

        except Exception as exc:
            logger.error("ALV Grid traversal failed: %s", exc)
            return None


# ------------------------------------------------------------------
# Module-level helpers
# ------------------------------------------------------------------


def _fuzzy_contains(needle: str, haystack: str) -> bool:
    """Check if needle is a fuzzy substring of haystack.

    Handles Chinese/English mixed text and common abbreviations.
    """
    if needle in haystack or haystack in needle:
        return True
    # Character-level overlap for short strings
    if len(needle) >= 2 and len(haystack) >= 2:
        common = sum(1 for c in needle if c in haystack)
        ratio = common / max(len(needle), len(haystack))
        return ratio >= 0.6
    return False
