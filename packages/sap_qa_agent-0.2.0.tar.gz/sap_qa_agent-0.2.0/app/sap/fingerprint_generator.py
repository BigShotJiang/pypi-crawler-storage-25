"""页面指纹生成器 — 从已采集的 ElementTree 生成 PageFingerprint。

根据 SAP GUI 元素树的结构，自动检测视图类型（表格/详情/表单），
提取表格列映射和字段路径映射，生成可持久化的页面指纹。
"""

from __future__ import annotations

import logging
import re
from typing import Any

from app.data.models import (
    ElementInfo,
    ElementTree,
    PageFingerprint,
    TableSchema,
    ViewType,
)

logger = logging.getLogger(__name__)

# 输入类型的元素类型集合
_INPUT_TYPES = {
    "GuiCTextField", "GuiTextField", "GuiComboBox",
    "GuiPasswordField", "GuiCheckBox", "GuiRadioButton",
}


def generate_fingerprint(
    window_title: str,
    element_tree: ElementTree,
    sap_wrapper: Any = None,
) -> PageFingerprint:
    """从已采集的 ElementTree 生成 PageFingerprint。

    Args:
        window_title: 当前 SAP 窗口标题
        element_tree: 已遍历的元素树
        sap_wrapper: SAP GUI wrapper（可选，用于检测活动页签）

    Returns:
        生成的 PageFingerprint 对象
    """
    elements = element_tree.elements

    # 1. 检测活动页签
    active_tab, tabstrip_path, available_tabs = _detect_tabs(elements)

    # 2. 构建 fingerprint_id
    fingerprint_id = f"{window_title}|{active_tab}"

    # 3. 检测视图类型
    view_type = _detect_view_type(elements)

    # 4. 构建 TableSchema（仅 TABLE 视图）
    table_schema = None
    if view_type == ViewType.TABLE:
        table_schema = _build_table_schema(elements)

    # 5. 构建 field_map（所有视图类型都需要）
    field_map = _build_field_map(elements)

    fingerprint = PageFingerprint(
        fingerprint_id=fingerprint_id,
        screen_title=window_title,
        active_tab=active_tab,
        view_type=view_type,
        table_schema=table_schema,
        field_map=field_map,
        tabstrip_path=tabstrip_path,
        available_tabs=available_tabs,
    )

    logger.info(
        "生成页面指纹: %s (view=%s, fields=%d, table=%s)",
        fingerprint_id,
        view_type.value,
        len(field_map),
        "yes" if table_schema else "no",
    )

    return fingerprint


def _detect_tabs(
    elements: list[ElementInfo],
) -> tuple[str, str | None, list[str]]:
    """检测页签信息。

    Returns:
        (active_tab, tabstrip_path, available_tabs)
    """
    tabstrip_path = None
    available_tabs: list[str] = []
    active_tab = ""

    for elem in elements:
        if elem.element_type == "GuiTab":
            # GuiTab 的 label_text 或 current_value 是页签文本（如"概览"）
            tab_label = elem.label_text or elem.current_value or ""
            # 从路径提取 tab 标识（如 tabpT\01）
            tab_id_match = re.search(r'(tabpT\\?\d+)', elem.id_path)
            if tab_id_match:
                tab_id = tab_id_match.group(1)
                available_tabs.append(tab_id)

                # 记录 tabstrip 路径
                if tabstrip_path is None:
                    # 从 tab 路径提取 tabstrip 路径
                    parts = elem.id_path.split("/")
                    for i, part in enumerate(parts):
                        if part.startswith("tabp"):
                            tabstrip_path = "/".join(parts[:i])
                            break

            # 判断是否为活动页签：活动页签的子元素可访问
            # 简单策略：最后一个有文本的 tab 暂定为活动 tab
            # 更准确的方式是通过 sap_wrapper 查询，但这里用启发式
            if tab_label:
                active_tab = tab_id if tab_id_match else tab_label

    if not active_tab and available_tabs:
        active_tab = available_tabs[0]

    return active_tab, tabstrip_path, available_tabs


def _detect_view_type(elements: list[ElementInfo]) -> ViewType:
    """检测当前视图类型。

    策略:
    - 有 GuiTableControl 或 GuiGridColumn → TABLE
    - 输入字段 <= 15 且无表格 → DETAIL
    - 多输入字段无表格 → FORM
    - 其他 → UNKNOWN
    """
    has_table = False
    has_grid = False
    input_count = 0

    for elem in elements:
        if elem.element_type == "GuiTableControl":
            has_table = True
        elif elem.element_type in ("GuiShell", "GuiGridView"):
            # GuiShell 可能是 ALV Grid
            has_grid = True
        elif elem.element_type == "GuiGridColumn":
            # 虚拟列元素，说明有 Grid
            has_grid = True
        elif elem.element_type in _INPUT_TYPES:
            input_count += 1

    if has_table or has_grid:
        return ViewType.TABLE

    if input_count <= 15 and input_count > 0:
        return ViewType.DETAIL

    if input_count > 15:
        return ViewType.FORM

    return ViewType.UNKNOWN


def _build_table_schema(elements: list[ElementInfo]) -> TableSchema | None:
    """从元素列表中构建 TableSchema。

    处理两种表格类型:
    - GuiTableControl: 路径格式 tblXXX/field[col,row]
    - GuiGridView/GuiShell: 虚拟列元素 col[COLUMN_ID]
    """
    # 查找 GuiTableControl
    for elem in elements:
        if elem.element_type == "GuiTableControl":
            return _build_table_control_schema(elem, elements)

    # 查找 GuiGridColumn（ALV Grid 的虚拟列）
    grid_path = None
    columns: list[dict[str, Any]] = []
    for elem in elements:
        if elem.element_type == "GuiGridColumn":
            # 虚拟路径格式: grid_path/col[COLUMN_ID]
            match = re.match(r'(.+)/col\[(.+)\]$', elem.id_path)
            if match:
                if grid_path is None:
                    grid_path = match.group(1)
                columns.append({
                    "name": elem.label_text or elem.tooltip or "",
                    "tech_name": match.group(2),
                    "col_index": len(columns),
                })

    if grid_path and columns:
        return TableSchema(
            table_path=grid_path,
            table_type="GuiGridView",
            columns=columns,
        )

    return None


def _build_table_control_schema(
    table_elem: ElementInfo,
    all_elements: list[ElementInfo],
) -> TableSchema:
    """从 GuiTableControl 元素构建 TableSchema。

    SAP GuiTableControl 的子元素路径格式:
      tblXXX/xxxFIELD-NAME[col_index, row_index]

    我们需要提取:
    - table_path: tblXXX 的完整路径
    - columns: 去重的列名 → col_index + SAP 字段名映射
    """
    table_path = table_elem.id_path

    # 收集表格内所有单元格元素
    columns_by_index: dict[int, dict[str, Any]] = {}
    visible_rows = 0

    for elem in all_elements:
        if not elem.id_path.startswith(table_path + "/"):
            continue

        # 匹配 [col_index, row_index] 格式
        match = re.search(r'\[(\d+),(\d+)\]$', elem.id_path)
        if not match:
            continue

        col_idx = int(match.group(1))
        row_idx = int(match.group(2))
        visible_rows = max(visible_rows, row_idx + 1)

        # 只处理 row=0 来提取列信息（每列结构相同）
        if row_idx > 0:
            continue

        # 提取 SAP 字段名（路径最后一段，去掉类型前缀和索引后缀）
        last_segment = elem.id_path.split("/")[-1]
        # 去掉 [col,row] 后缀
        field_with_prefix = re.sub(r'\[\d+,\d+\]$', '', last_segment)
        # 去掉类型前缀 (ctxt, txt, cmb, chk 等)
        tech_name = re.sub(r'^(ct|t|cmb|chk|rad|btn)', '', field_with_prefix, flags=re.IGNORECASE)

        # 使用 label_text 或 tooltip 作为列名
        label = elem.label_text or elem.tooltip or ""

        if col_idx not in columns_by_index:
            columns_by_index[col_idx] = {
                "name": label,
                "tech_name": last_segment.replace(f"[{col_idx},0]", ""),
                "col_index": col_idx,
            }
        else:
            # 如果之前的名字为空，用这个
            if not columns_by_index[col_idx]["name"] and label:
                columns_by_index[col_idx]["name"] = label

    columns = list(columns_by_index.values())

    return TableSchema(
        table_path=table_path,
        table_type="GuiTableControl",
        columns=columns,
        visible_rows=visible_rows,
    )


def _build_field_map(elements: list[ElementInfo]) -> dict[str, str]:
    """构建 field_map: 业务名称 → SAP 元素路径。

    优先级: tooltip > label_text > 位置关联
    """
    field_map: dict[str, str] = {}

    # 直接映射：输入元素的 label_text / tooltip → path
    for elem in elements:
        if elem.element_type not in _INPUT_TYPES:
            continue

        # 跳过表格单元格（有 [col,row] 后缀的）
        if re.search(r'\[\d+,\d+\]$', elem.id_path):
            continue

        if elem.tooltip:
            field_map[elem.tooltip] = elem.id_path
        if elem.label_text:
            field_map[elem.label_text] = elem.id_path

    # 位置映射：GuiLabel → 下一个输入元素
    for i, elem in enumerate(elements):
        if elem.element_type == "GuiLabel" and elem.current_value:
            for j in range(i + 1, min(i + 5, len(elements))):
                if elements[j].element_type in _INPUT_TYPES:
                    # 不覆盖已有的映射
                    if elem.current_value not in field_map:
                        field_map[elem.current_value] = elements[j].id_path
                    break

    return field_map
