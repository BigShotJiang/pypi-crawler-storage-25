"""SAP GUI Scripting API COM 接口封装

通过 win32com.client 连接 SAP GUI，提供 Pythonic 的操作接口。
所有 COM 调用均包含 try/except 保护。
在非 Windows 环境下，win32com 相关功能不可用，但模块可正常导入。
"""

from __future__ import annotations

import logging
import os
import sys
import time
from typing import Any

from app.data.models import MessageType, StatusBarMessage

logger = logging.getLogger(__name__)

# Conditional imports for Windows COM automation
_WIN32_AVAILABLE = False
if sys.platform == "win32":
    try:
        import win32com.client
        import win32gui
        import win32con

        _WIN32_AVAILABLE = True
    except ImportError:
        logger.warning("win32com not available – SAP GUI COM features disabled")


class SapGuiWrapper:
    """SAP GUI Scripting API COM 接口封装。

    封装 SAP GUI Scripting API 的 COM 接口，提供元素定位、文本输入、
    按钮点击、状态栏读取、截图、弹窗检测等功能。
    """

    def __init__(self) -> None:
        self._session: Any = None
        self._connected: bool = False
        self._application: Any = None
        self._connection: Any = None

    # ------------------------------------------------------------------
    # Connection management
    # ------------------------------------------------------------------

    def connect(self, max_retries: int = 3, retry_interval: float = 2.0) -> bool:
        """通过 win32com.client.GetObject("SAPGUI") 连接 SAP GUI。

        SAP GUI 窗口（非 SAP Logon Pad）必须已经打开（已连接到服务器，
        处于登录界面或已登录状态）。如果首次连接失败，会自动重试。

        Args:
            max_retries: 最大重试次数，默认 3
            retry_interval: 重试间隔秒数，默认 2.0

        Returns:
            True if connection succeeded, False otherwise.
        """
        if not _WIN32_AVAILABLE:
            logger.error("win32com not available on this platform")
            return False

        # COM 必须在每个线程上初始化（asyncio.to_thread 使用线程池）
        import pythoncom
        try:
            pythoncom.CoInitialize()
        except Exception:
            pass  # 主线程可能已经初始化过

        last_error = None
        for attempt in range(1, max_retries + 1):
            try:
                sap_gui = win32com.client.GetObject("SAPGUI")
                if sap_gui is None:
                    logger.error("GetObject('SAPGUI') returned None")
                    return False

                self._application = sap_gui.GetScriptingEngine
                if self._application is None:
                    logger.error("GetScriptingEngine returned None")
                    return False

                self._connection = self._application.Children(0)
                if self._connection is None:
                    logger.error("No active connection found")
                    return False

                self._session = self._connection.Children(0)
                if self._session is None:
                    logger.error("No active session found")
                    return False

                self._connected = True
                logger.info("Successfully connected to SAP GUI session")
                return True

            except Exception as exc:
                last_error = exc
                error_code = getattr(exc, "hresult", None) or (
                    exc.args[0] if exc.args else None
                )
                if error_code == -2147221020:
                    # MK_E_SYNTAX — SAP GUI 未在 ROT 中注册
                    logger.warning(
                        "SAP GUI 未就绪 (attempt %d/%d): "
                        "请确认 SAP GUI 窗口已打开（不仅是 SAP Logon Pad，"
                        "需要已连接到服务器）。%s 秒后重试...",
                        attempt, max_retries, retry_interval,
                    )
                else:
                    logger.warning(
                        "连接 SAP GUI 失败 (attempt %d/%d): %s",
                        attempt, max_retries, exc,
                    )
                if attempt < max_retries:
                    time.sleep(retry_interval)

        logger.error(
            "连接 SAP GUI 最终失败 (%d 次尝试): %s。"
            "请确认: 1) SAP GUI 窗口已打开并连接到服务器 "
            "2) SAP GUI Scripting 已启用 (Options → Accessibility & Scripting → Scripting)",
            max_retries, last_error,
        )
        self._connected = False
        return False

    def is_connected(self) -> bool:
        """检查是否已连接到 SAP GUI。"""
        if not self._connected or self._session is None:
            return False
        try:
            # Probe the session to verify it's still alive
            _ = self._session.Info.SystemName
            return True
        except Exception:
            self._connected = False
            return False

    def get_session(self) -> Any:
        """获取当前活动的 SAP GUI session 对象。

        Returns:
            SAP GUI session COM object, or None if not connected.
        """
        if not self.is_connected():
            logger.warning("get_session called but not connected")
            return None
        return self._session

    # ------------------------------------------------------------------
    # Element operations
    # ------------------------------------------------------------------

    def find_element(self, element_path: str) -> Any:
        """通过 session.findById() 定位元素。

        Args:
            element_path: SAP GUI element ID path, e.g. "wnd[0]/usr/ctxtVBAK-AUART".

        Returns:
            The COM element object, or None if not found.
        """
        if not self.is_connected():
            logger.warning("find_element called but not connected")
            return None
        try:
            element = self._session.findById(element_path)
            return element
        except Exception as exc:
            logger.debug("Element not found: %s – %s", element_path, exc)
            return None

    def set_text(self, element_path: str, value: str) -> None:
        """设置元素的 text 属性。

        Args:
            element_path: SAP GUI element ID path.
            value: Text value to set.

        Raises:
            RuntimeError: If element not found or text cannot be set.
        """
        element = self.find_element(element_path)
        if element is None:
            raise RuntimeError(f"Element not found: {element_path}")
        try:
            element.text = value
            logger.info("set_text(%s, '%s') OK", element_path, value)
        except Exception as exc:
            raise RuntimeError(
                f"Failed to set text on {element_path}: {exc}"
            ) from exc

    def press_button(self, element_path: str) -> None:
        """调用元素的 press() 方法。

        Args:
            element_path: SAP GUI element ID path.

        Raises:
            RuntimeError: If element not found or press fails.
        """
        element = self.find_element(element_path)
        if element is None:
            raise RuntimeError(f"Element not found: {element_path}")
        try:
            element.press()
            logger.info("press_button(%s) OK", element_path)
        except Exception as exc:
            raise RuntimeError(
                f"Failed to press button {element_path}: {exc}"
            ) from exc

    def set_selected(self, element_path: str, selected: bool) -> None:
        """设置元素的 selected 属性。

        Args:
            element_path: SAP GUI element ID path.
            selected: Whether the element should be selected.

        Raises:
            RuntimeError: If element not found or selection fails.
        """
        element = self.find_element(element_path)
        if element is None:
            raise RuntimeError(f"Element not found: {element_path}")
        try:
            element.selected = selected
            logger.info("set_selected(%s, %s) OK", element_path, selected)
        except Exception as exc:
            raise RuntimeError(
                f"Failed to set selected on {element_path}: {exc}"
            ) from exc

    # ------------------------------------------------------------------
    # Status bar & screenshots
    # ------------------------------------------------------------------

    def read_status_bar(self) -> StatusBarMessage:
        """读取 wnd[0]/sbar 的状态栏消息。

        Returns:
            StatusBarMessage with text, type, id, and number.
        """
        if not self.is_connected():
            return StatusBarMessage(
                text="", message_type=MessageType.INFO
            )
        try:
            sbar = self._session.findById("wnd[0]/sbar")
            text = str(sbar.Text) if sbar.Text else ""
            msg_type_raw = str(sbar.MessageType) if sbar.MessageType else "I"

            type_map = {"S": MessageType.SUCCESS, "E": MessageType.ERROR,
                        "W": MessageType.WARNING, "I": MessageType.INFO}
            msg_type = type_map.get(msg_type_raw, MessageType.INFO)

            msg_id = None
            msg_number = None
            try:
                msg_id = str(sbar.MessageId) if sbar.MessageId else None
                msg_number = str(sbar.MessageNumber) if sbar.MessageNumber else None
            except Exception:
                pass  # Some SAP versions don't expose these

            logger.info("Status bar: [%s] %s", msg_type_raw, text)
            return StatusBarMessage(
                text=text,
                message_type=msg_type,
                message_id=msg_id,
                message_number=msg_number,
            )
        except Exception as exc:
            logger.warning("Failed to read status bar: %s", exc)
            return StatusBarMessage(
                text="", message_type=MessageType.INFO
            )

    def screenshot(self, save_path: str) -> str:
        """截取屏幕截图（包含 OS 级弹窗），保存到指定路径。

        优先使用 PIL ImageGrab 截取全屏（能捕获 OS 弹窗），
        不可用时回退到 SAP HardCopy（仅截 SAP 窗口内容）。

        Args:
            save_path: File path to save the screenshot.

        Returns:
            The save_path on success, empty string on failure.
        """
        os.makedirs(os.path.dirname(save_path), exist_ok=True)

        # 优先：PIL 全屏截图（能捕获 OS 弹窗、对话框等）
        if _WIN32_AVAILABLE:
            try:
                from PIL import ImageGrab

                hwnd = self._find_sap_window_handle()
                if hwnd:
                    self._activate_window(hwnd)
                    time.sleep(0.3)

                img = ImageGrab.grab()
                img.save(save_path)
                logger.info("Screenshot (fullscreen) saved: %s", save_path)
                return save_path
            except Exception as exc:
                logger.warning("Fullscreen screenshot failed: %s, trying HardCopy", exc)

        # 兜底：SAP HardCopy（仅截 SAP 窗口，不含 OS 弹窗）
        if self.is_connected():
            try:
                self._session.findById("wnd[0]").HardCopy(
                    save_path, "PNG"
                )
                logger.info("Screenshot (HardCopy) saved: %s", save_path)
                return save_path
            except Exception as exc:
                logger.warning("Screenshot via HardCopy failed: %s", exc)

        return ""

    def _screenshot_win32_fallback(self, save_path: str) -> str:
        """Win32 API fallback for screenshots when HardCopy is unavailable."""
        if not _WIN32_AVAILABLE:
            return ""
        try:
            from PIL import ImageGrab

            hwnd = self._find_sap_window_handle()
            if hwnd:
                self._activate_window(hwnd)
                time.sleep(0.3)

            img = ImageGrab.grab()
            os.makedirs(os.path.dirname(save_path), exist_ok=True)
            img.save(save_path)
            logger.info("Screenshot (win32 fallback) saved: %s", save_path)
            return save_path
        except Exception as exc:
            logger.error("Win32 screenshot fallback failed: %s", exc)
            return ""

    # ------------------------------------------------------------------
    # Window management
    # ------------------------------------------------------------------

    def get_active_window_id(self) -> str:
        """获取当前活动窗口 ID（如 wnd[0] 或 wnd[1]）。

        Returns:
            Window ID string, defaults to "wnd[0]".
        """
        if not self.is_connected():
            return "wnd[0]"
        try:
            active_window = self._session.ActiveWindow
            if active_window:
                return str(active_window.Id)
        except Exception as exc:
            logger.debug("Failed to get active window ID: %s", exc)
        return "wnd[0]"

    def check_modal_dialog(self) -> dict | None:
        """检测模态对话框，返回 {title, text} 或 None。

        Checks wnd[1] for a modal dialog window.

        Returns:
            Dict with 'title' and 'text' keys, or None if no dialog.
        """
        if not self.is_connected():
            return None
        try:
            dialog = self._session.findById("wnd[1]")
            if dialog is None:
                return None
            title = ""
            text = ""
            try:
                title = str(dialog.Text) if dialog.Text else ""
            except Exception:
                pass
            # Try to read dialog message text from common locations
            for text_path in [
                "wnd[1]/usr/txtMESSTXT1",
                "wnd[1]/usr/txtMESSTXT2",
                "wnd[1]/usr/lblMESSTXT1",
            ]:
                try:
                    text_elem = self._session.findById(text_path)
                    if text_elem and text_elem.Text:
                        text = str(text_elem.Text)
                        break
                except Exception:
                    continue

            logger.info("Modal dialog detected: title='%s', text='%s'", title, text)
            return {"title": title, "text": text}
        except Exception:
            # No wnd[1] means no modal dialog
            return None

    def ensure_scripting_enabled(self) -> bool:
        """检查 SAP GUI Scripting 是否启用。

        Returns:
            True if scripting is enabled and accessible.
        """
        if not _WIN32_AVAILABLE:
            return False
        try:
            sap_gui = win32com.client.GetObject("SAPGUI")
            return sap_gui is not None
        except Exception:
            return False

    # ------------------------------------------------------------------
    # Three-tier window activation strategy
    # ------------------------------------------------------------------

    def _find_sap_window_handle(self) -> int | None:
        """Find the SAP GUI main window handle."""
        if not _WIN32_AVAILABLE:
            return None
        try:
            hwnd = win32gui.FindWindow("SAP_FRONTEND_SESSION", None)
            if hwnd:
                return hwnd
            # Fallback: search by window title
            result = []

            def _enum_callback(h: int, extra: list) -> None:
                try:
                    title = win32gui.GetWindowText(h)
                    if "SAP" in title:
                        extra.append(h)
                except Exception:
                    pass

            win32gui.EnumWindows(_enum_callback, result)
            return result[0] if result else None
        except Exception as exc:
            logger.debug("Failed to find SAP window handle: %s", exc)
            return None

    def _activate_window(self, hwnd: int) -> bool:
        """三级窗口激活策略，确保 SAP GUI 窗口在前台。

        Tier 1: BringWindowToTop
        Tier 2: PostMessage WM_ACTIVATE
        Tier 3: SendKeys('%') + SetForegroundWindow
        """
        if not _WIN32_AVAILABLE or not hwnd:
            return False

        try:
            # Tier 1: BringWindowToTop
            win32gui.BringWindowToTop(hwnd)
            time.sleep(0.1)
            if self._is_window_active(hwnd):
                logger.debug("Window activated via Tier 1 (BringWindowToTop)")
                return True

            # Tier 2: PostMessage WM_ACTIVATE
            WM_ACTIVATE = 0x0006
            WA_ACTIVE = 1
            win32gui.PostMessage(hwnd, WM_ACTIVATE, WA_ACTIVE, 0)
            time.sleep(0.1)
            if self._is_window_active(hwnd):
                logger.debug("Window activated via Tier 2 (PostMessage)")
                return True

            # Tier 3: SendKeys + SetForegroundWindow
            shell = win32com.client.Dispatch("WScript.Shell")
            shell.SendKeys("%")  # Alt key to release foreground lock
            win32gui.SetForegroundWindow(hwnd)
            time.sleep(0.1)
            if self._is_window_active(hwnd):
                logger.debug("Window activated via Tier 3 (SendKeys+SetForegroundWindow)")
                return True

            logger.warning("All three activation tiers failed for hwnd=%s", hwnd)
            return False

        except Exception as exc:
            logger.warning("Window activation failed: %s", exc)
            return False

    @staticmethod
    def _is_window_active(hwnd: int) -> bool:
        """Check if the given window handle is the foreground window."""
        if not _WIN32_AVAILABLE:
            return False
        try:
            return win32gui.GetForegroundWindow() == hwnd
        except Exception:
            return False
