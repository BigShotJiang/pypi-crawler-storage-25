from __future__ import annotations
import logging
import threading
import time
from typing import Any

logger = logging.getLogger(__name__)

SCAN_INTERVAL_MS = 300
BM_CLICK = 0x00F5


class DialogWatchdog:
    """OS 级弹窗后台监控守护线程。

    以 300ms 间隔扫描 Windows 窗口，自动处理 SAP 安全确认弹窗。
    """

    def __init__(self) -> None:
        self._thread: threading.Thread | None = None
        self._stop_event = threading.Event()
        self._handled_count = 0

    def start(self) -> None:
        """启动守护线程。"""
        self._stop_event.clear()
        self._handled_count = 0
        self._thread = threading.Thread(
            target=self._scan_loop, daemon=True, name="DialogWatchdog"
        )
        self._thread.start()
        logger.info("Dialog_Watchdog 已启动")

    def stop(self) -> None:
        """发送停止信号，等待线程退出。"""
        self._stop_event.set()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=2)
        logger.info(
            "Dialog_Watchdog 已停止，累计处理 %d 个 OS 弹窗",
            self._handled_count,
        )

    @property
    def handled_count(self) -> int:
        return self._handled_count

    def _scan_loop(self) -> None:
        """扫描循环主体。"""
        import win32gui
        import win32con

        while not self._stop_event.is_set():
            try:
                self._scan_once(win32gui, win32con)
            except Exception as exc:
                logger.warning("Dialog_Watchdog 扫描异常: %s", exc)
            self._stop_event.wait(SCAN_INTERVAL_MS / 1000.0)

    def _scan_once(self, win32gui: Any, win32con: Any) -> None:
        """单次扫描所有可见窗口。"""
        def _enum_callback(hwnd: int, _: Any) -> None:
            try:
                if not win32gui.IsWindowVisible(hwnd):
                    return
                class_name = win32gui.GetClassName(hwnd)
                title = win32gui.GetWindowText(hwnd)

                # 检测 SAP 安全弹窗：
                # 1. 标准 Windows 对话框 (#32770) 标题含 SAP
                # 2. SAP Logon 脚本访问确认弹窗（标题 "SAP Logon" 或 "SAP GUI"）
                # 3. 任何包含"脚本"和"访问"的弹窗
                is_sap_dialog = (
                    (class_name == "#32770" and "SAP" in title)
                    or ("SAP Logon" in title and class_name in ("#32770", "SAP_FRONTEND_SESSION"))
                    or ("脚本" in title or "脚本" in self._get_window_text(hwnd, win32gui))
                )
                if is_sap_dialog:
                    self._handle_os_dialog(hwnd, title, win32gui, win32con)
            except Exception:
                pass

        win32gui.EnumWindows(_enum_callback, None)

    @staticmethod
    def _get_window_text(hwnd: int, win32gui: Any) -> str:
        """尝试读取窗口内的静态文本内容。"""
        texts: list[str] = []
        def _enum_child(child_hwnd: int, _: Any) -> None:
            try:
                cls = win32gui.GetClassName(child_hwnd)
                if cls in ("Static", "STATIC"):
                    t = win32gui.GetWindowText(child_hwnd)
                    if t:
                        texts.append(t)
            except Exception:
                pass
        try:
            win32gui.EnumChildWindows(hwnd, _enum_child, None)
        except Exception:
            pass
        return " ".join(texts)

    def _handle_os_dialog(
        self, hwnd: int, title: str, win32gui: Any, win32con: Any
    ) -> None:
        """处理单个 OS 级弹窗 — 点击确定/OK/允许按钮。"""
        buttons: list[int] = []

        def _find_button(child_hwnd: int, _: Any) -> None:
            try:
                if win32gui.GetClassName(child_hwnd) == "Button":
                    text = win32gui.GetWindowText(child_hwnd)
                    # 匹配各种确认按钮文本
                    if any(kw in text for kw in ("确定", "OK", "允许", "是", "Yes", "继续")):
                        buttons.append(child_hwnd)
            except Exception:
                pass

        win32gui.EnumChildWindows(hwnd, _find_button, None)

        for btn in buttons:
            win32gui.PostMessage(btn, BM_CLICK, 0, 0)
            self._handled_count += 1
            logger.info(
                "Dialog_Watchdog 处理 OS 弹窗: '%s' (累计 %d)",
                title, self._handled_count,
            )
