"""SAP GUI 脚本执行引擎

负责逐步执行 SAP GUI Scripting API 脚本，处理截图、状态栏消息捕获、
弹窗检测，以及 COM/VLM 兜底方案的自动切换。
"""

from __future__ import annotations

import json
import logging
import os
import re
import time
from typing import Any, Callable

from app.config import (
    ARTIFACTS_DIR,
    KNOWLEDGE_BASE_DIR,
    STEP_WAIT_INTERVAL,
)
from app.data.models import (
    MessageType,
    StepActionType,
    StepResult,
    StatusBarMessage,
    TestStep,
)

logger = logging.getLogger(__name__)


class ScriptExecutor:
    """SAP GUI 脚本执行引擎。

    逐步执行 TestStep 列表，每步包含：等待 → 执行 → 截图 → 状态栏读取 → 弹窗检测。
    当 SAP GUI Scripting API 不可用时，自动降级到 VLM 兜底方案。
    """

    def __init__(self, sap_wrapper: Any, vlm_fallback: Any, element_finder: Any = None, glm_client: Any = None, fingerprint_store: Any = None) -> None:
        """
        Args:
            sap_wrapper: SapGuiWrapper instance for COM operations.
            vlm_fallback: VlmFallbackExecutor instance for fallback execution.
            element_finder: Optional ElementPathFinder for resolving business
                descriptions to real element ID paths.
            glm_client: Optional GlmClient for AI-driven recovery scripts.
            fingerprint_store: Optional FingerprintStore for page fingerprint lookup.
        """
        self._sap_wrapper = sap_wrapper
        self._vlm_fallback = vlm_fallback
        self._element_finder = element_finder
        self._glm_client = glm_client
        self._fingerprint_store = fingerprint_store
        self._stopped = False
        self._patterns: list[dict] = self._load_patterns()
        self._test_case_context: str = ""  # 由调用方设置
        self._completed_steps: list[dict] = []  # 已完成步骤记录
        self._current_fp: Any = None  # 当前页面指纹缓存

    # ------------------------------------------------------------------
    # Script execution
    # ------------------------------------------------------------------

    async def execute_script(
        self,
        steps: list[TestStep],
        flow_context: Any,
        step_callback: Callable[[StepResult], None] | None = None,
        log_callback: Callable[[str], None] | None = None,
        test_case_context: str = "",
        skip_before_index: int = 0,
    ) -> list[StepResult]:
        """逐步执行脚本，失败时调用 GLM 生成修复脚本。

        Args:
            steps: 步骤列表
            flow_context: 流程变量上下文
            step_callback: 步骤完成回调
            log_callback: 日志回调
            test_case_context: 测试用例上下文
            skip_before_index: 跳过此 index 之前的步骤（用于从失败步骤重试）
        """
        from app.config import MAX_AI_INTERVENTION_FAILURES
        import time as _time

        MAX_RETRIES = MAX_AI_INTERVENTION_FAILURES  # 3

        self._stopped = False
        self._test_case_context = test_case_context
        self._completed_steps = []
        self._cached_screen_title = ""  # 当前界面标题缓存
        results: list[StepResult] = []

        def _log(msg: str):
            if log_callback:
                log_callback(msg)

        _log(f"▶️ 开始逐步执行 ({len(steps)} 个步骤)...")
        if skip_before_index > 0:
            _log(f"  ⏭️ 跳过 Step 1-{skip_before_index - 1}（从 Step {skip_before_index} 开始重试）")

        # 初始采集屏幕元素
        self._refresh_screen_cache(_log)

        batch_processed_indices: set[int] = set()  # 已被批量处理的步骤索引

        for step in steps:
            # 跳过已完成的步骤（重试模式）
            if step.index < skip_before_index:
                continue

            # 跳过已被批量处理的步骤
            if step.index in batch_processed_indices:
                continue

            if self._stopped:
                result = StepResult(
                    step_index=step.index,
                    success=False,
                    error_message="Execution stopped by user",
                )
                results.append(result)
                if step_callback is not None:
                    step_callback(result)
                continue

            # Resolve flow variables in step value
            resolved_step = self._resolve_step_variables(step, flow_context)

            val_display = f" = {resolved_step.value}" if resolved_step.value else ""
            row_col = ""
            if resolved_step.row is not None and resolved_step.column is not None:
                row_col = f" (行{resolved_step.row}, {resolved_step.column})"
            _log(f"  Step {resolved_step.index}: [{resolved_step.action_type.value}] {resolved_step.target_description}{row_col}{val_display}")

            # 先尝试直接执行（不带 retry）
            result = await self.execute_step(resolved_step)

            # 如果 input 步骤失败，检查是否有连续 input 可以批量处理
            if (not result.success
                    and resolved_step.action_type == StepActionType.INPUT
                    and self._glm_client is not None):
                # 收集后续连续的 input 步骤
                batch_steps = [resolved_step]
                for next_step in steps:
                    if next_step.index <= resolved_step.index:
                        continue
                    if next_step.index in batch_processed_indices:
                        continue
                    next_resolved = self._resolve_step_variables(next_step, flow_context)
                    if next_resolved.action_type == StepActionType.INPUT:
                        batch_steps.append(next_resolved)
                    else:
                        break

                if len(batch_steps) > 1:
                    # 多个连续 input → 批量处理
                    _log(f"  📦 批量处理 {len(batch_steps)} 个连续输入步骤...")
                    batch_result = await self._batch_ai_recovery(batch_steps, _log)
                    if batch_result is not None:
                        # 批量成功
                        result = StepResult(
                            step_index=resolved_step.index, success=True,
                            status_bar_message=batch_result,
                        )
                        for bs in batch_steps[1:]:
                            batch_processed_indices.add(bs.index)
                            sr = StepResult(
                                step_index=bs.index, success=True,
                                status_bar_message="(批量执行)",
                            )
                            results.append(sr)
                            self._completed_steps.append({
                                "index": bs.index, "action": bs.action_type.value,
                                "target": bs.target_description, "value": bs.value,
                                "status": "成功(批量)",
                            })
                            val_d = f" = {bs.value}" if bs.value else ""
                            _log(f"  ✅ Step {bs.index}: [{bs.action_type.value}] {bs.target_description}{val_d} (批量)")
                            if step_callback is not None:
                                step_callback(sr)
                    else:
                        # 批量失败，回退到单步 retry
                        result = await self._execute_with_retry(
                            resolved_step, flow_context, MAX_RETRIES, _log,
                        )
                else:
                    # 只有一个 input 失败，走单步 retry
                    result = await self._execute_with_retry(
                        resolved_step, flow_context, MAX_RETRIES, _log,
                    )

            elif not result.success:
                # 非 input 步骤失败，走单步 retry
                result = await self._execute_with_retry(
                    resolved_step, flow_context, MAX_RETRIES, _log,
                )

            results.append(result)

            # Log final result
            if result.success:
                detail = result.status_bar_message or ""
                _log(f"  ✅ Step {resolved_step.index} 成功 ({result.execution_time_ms}ms) {detail}")
                self._completed_steps.append({
                    "index": resolved_step.index,
                    "action": resolved_step.action_type.value,
                    "target": resolved_step.target_description,
                    "value": resolved_step.value,
                    "status": "成功",
                })
                # 检测界面是否变化（navigate/click 后可能切换界面）
                if resolved_step.action_type in (StepActionType.NAVIGATE, StepActionType.CLICK):
                    self._check_screen_change(_log)
            else:
                _log(f"  ❌ Step {resolved_step.index} 最终失败: {result.error_message}")

            # Extract document number from status bar if present
            if result.status_bar_message:
                doc_no = self.extract_document_number(result.status_bar_message)
                if doc_no:
                    result.extracted_document_number = doc_no
                    _log(f"  📄 提取凭证号: {doc_no}")
                    logger.info(
                        "Extracted document number: %s from step %d",
                        doc_no, step.index,
                    )

            # Invoke step callback after step execution
            if step_callback is not None:
                step_callback(result)

            # Stop on failure (after all retries exhausted)
            if not result.success:
                logger.warning(
                    "Step %d failed after retries: %s",
                    step.index, result.error_message,
                )
                break

        return results

    async def _execute_with_retry(
        self,
        step: TestStep,
        flow_context: Any,
        max_retries: int,
        log_fn: Callable[[str], None],
    ) -> StepResult:
        """执行单步，失败时调用 GLM 生成修复脚本并执行。

        修复流程：
        1. 先处理 SAP 弹窗
        2. 采集当前屏幕状态 + 测试上下文
        3. 发给 GLM 生成修复脚本
        4. 执行修复脚本
        5. 重试原步骤
        """
        import time as _time

        result = await self.execute_step(step)

        if result.success:
            return result

        # 首次失败，开始 AI 驱动的修复
        for attempt in range(1, max_retries + 1):
            error_msg = result.error_message or ""
            log_fn(f"  🔄 AI 修复 #{attempt}/{max_retries}: {error_msg}")

            # 1. 先处理可能存在的 SAP 弹窗
            session = self._sap_wrapper.get_session()
            if session:
                handled = self._auto_handle_sap_dialog(session)
                if handled:
                    log_fn(f"  🔔 自动处理了 SAP 弹窗")
                    _time.sleep(1)
                    # 弹窗处理后直接重试
                    result = await self.execute_step(step)
                    if result.success:
                        log_fn(f"  ✅ 弹窗处理后重试成功")
                        return result

            # 2. 调用 GLM 生成修复脚本
            if self._glm_client is not None:
                try:
                    recovery_result = await self._ai_recovery(step, error_msg, log_fn)
                    if recovery_result is not None and recovery_result.success:
                        return recovery_result
                except Exception as exc:
                    log_fn(f"  ⚠️ AI 修复异常: {exc}")
                    logger.error("AI recovery failed: %s", exc)

            # 3. 兜底：等待后直接重试
            _time.sleep(2)
            result = await self.execute_step(step)
            if result.success:
                log_fn(f"  ✅ 重试 #{attempt} 成功")
                return result

        return result

    async def _ai_recovery(
        self,
        step: TestStep,
        error_msg: str,
        log_fn: Callable[[str], None],
    ) -> StepResult | None:
        """调用 GLM 生成修复脚本并执行。

        采集当前屏幕状态 + 测试上下文 → GLM 生成修复脚本 → 执行 → 返回结果。
        """
        import time as _time

        session = self._sap_wrapper.get_session()
        if not session:
            return None

        # 采集当前屏幕状态
        window_title = ""
        status_bar = ""
        screen_elements = ""

        try:
            window_title = str(session.findById("wnd[0]").Text or "")
        except Exception:
            pass
        try:
            status_bar = str(session.findById("wnd[0]/sbar").Text or "")
        except Exception:
            pass

        # 采集屏幕元素（recovery 时强制刷新，因为失败可能是界面变化导致路径失效）
        self._refresh_screen_cache()
        screen_elements = self.collect_screen_elements_text(max_elements=1000)

        # 已完成步骤摘要
        completed_str = "\n".join(
            f"  Step {s['index']}: [{s['action']}] {s['target']} = {s.get('value', '')} → {s['status']}"
            for s in self._completed_steps
        ) if self._completed_steps else "无"

        log_fn(f"  🤖 AI 分析屏幕状态，生成修复脚本...")
        log_fn(f"  📍 当前界面: {window_title}")

        # 构建指纹上下文信息
        fingerprint_info = "无指纹信息"
        if self._current_fp:
            fp = self._current_fp
            fingerprint_info = (
                f"view_type={fp.view_type.value}, "
                f"active_tab={fp.active_tab}, "
                f"fields={len(fp.field_map)}, "
                f"table={'yes' if fp.table_schema else 'no'}"
            )

        # 调用 GLM 生成修复脚本
        recovery_script = await self._glm_client.generate_recovery_script(
            test_case_context=self._test_case_context,
            step_index=step.index,
            action_type=step.action_type.value,
            target_description=step.target_description,
            value=step.value or "",
            error_message=error_msg,
            completed_steps=completed_str,
            window_title=window_title,
            status_bar=status_bar,
            screen_elements=screen_elements,
            fingerprint_info=fingerprint_info,
        )

        log_fn(f"  📝 修复脚本已生成 ({len(recovery_script)} 字符)")
        log_fn(f"  📜 脚本内容:")
        for line in recovery_script.split("\n"):
            log_fn(f"    {line}")

        # 执行修复脚本
        try:
            exec_globals = {"session": session, "time": _time}
            exec(recovery_script, exec_globals)

            # 调用 recover() 函数
            if "recover" in exec_globals:
                recover_results = exec_globals["recover"](session)
                if recover_results and isinstance(recover_results, list):
                    all_ok = all(r.get("success", False) for r in recover_results)
                    if all_ok:
                        log_fn(f"  ✅ AI 修复脚本执行成功")
                        # 重新读取状态
                        new_status = ""
                        try:
                            new_status = str(session.findById("wnd[0]/sbar").Text or "")
                        except Exception:
                            pass
                        return StepResult(
                            step_index=step.index,
                            success=True,
                            status_bar_message=new_status,
                        )
                    else:
                        errors = [r.get("error", "") for r in recover_results if not r.get("success")]
                        log_fn(f"  ❌ AI 修复脚本部分失败: {'; '.join(errors)}")
            else:
                log_fn(f"  ⚠️ 修复脚本中没有 recover() 函数")

        except Exception as exc:
            log_fn(f"  ❌ 修复脚本执行异常: {exc}")
            logger.error("Recovery script execution error: %s", exc)

        return None

    async def _batch_ai_recovery(
        self,
        batch_steps: list[TestStep],
        log_fn: Callable[[str], None],
    ) -> str | None:
        """批量调用 GLM 生成修复脚本 — 多个连续输入步骤一次性处理。

        Returns:
            状态栏消息（成功时），或 None（失败时）。
        """
        import time as _time

        session = self._sap_wrapper.get_session()
        if not session or not self._glm_client:
            return None

        # 采集当前屏幕状态
        window_title = ""
        status_bar = ""
        try:
            window_title = str(session.findById("wnd[0]").Text or "")
        except Exception:
            pass
        try:
            status_bar = str(session.findById("wnd[0]/sbar").Text or "")
        except Exception:
            pass

        # 批量处理前强制刷新元素（确保路径是最新的）
        self._refresh_screen_cache()
        screen_elements = self.collect_screen_elements_text(max_elements=1000)

        # 构建批量步骤描述
        batch_desc = "\n".join(
            f"  Step {s.index}: [{s.action_type.value}] {s.target_description} = {s.value or ''}"
            for s in batch_steps
        )

        completed_str = "\n".join(
            f"  Step {s['index']}: [{s['action']}] {s['target']} = {s.get('value', '')} → {s['status']}"
            for s in self._completed_steps
        ) if self._completed_steps else "无"

        log_fn(f"  🤖 AI 批量分析 {len(batch_steps)} 个输入步骤...")
        log_fn(f"  📍 当前界面: {window_title}")

        try:
            script = await self._glm_client.generate_batch_recovery_script(
                test_case_context=self._test_case_context,
                batch_steps=batch_desc,
                completed_steps=completed_str,
                window_title=window_title,
                status_bar=status_bar,
                screen_elements=screen_elements,
            )

            log_fn(f"  📝 批量修复脚本已生成 ({len(script)} 字符)")
            log_fn(f"  📜 脚本内容:")
            for line in script.split("\n"):
                log_fn(f"    {line}")

            # 执行脚本
            exec_globals = {"session": session, "time": _time}
            exec(script, exec_globals)

            if "recover" in exec_globals:
                recover_results = exec_globals["recover"](session)
                if recover_results and isinstance(recover_results, list):
                    all_ok = all(r.get("success", False) for r in recover_results)
                    if all_ok:
                        log_fn(f"  ✅ 批量修复成功 ({len(recover_results)} 个操作)")
                        new_status = ""
                        try:
                            new_status = str(session.findById("wnd[0]/sbar").Text or "")
                        except Exception:
                            pass
                        return new_status
                    else:
                        errors = [r.get("error", "") for r in recover_results if not r.get("success")]
                        log_fn(f"  ❌ 批量修复部分失败: {'; '.join(errors)}")

        except Exception as exc:
            log_fn(f"  ❌ 批量修复异常: {exc}")
            logger.error("Batch recovery failed: %s", exc)

        return None

    async def execute_step(self, step: TestStep) -> StepResult:
        """执行单步操作：等待 → 执行 → 截图 → 状态栏读取 → 弹窗检测。

        Implements COM/VLM fallback switching: if SAP GUI COM is connected,
        use COM; otherwise fall back to VLM executor.

        Args:
            step: The TestStep to execute.

        Returns:
            StepResult with execution outcome.
        """
        start_time = time.time()

        # Wait before execution
        time.sleep(STEP_WAIT_INTERVAL)

        try:
            # Choose execution path: COM or VLM fallback
            if self._sap_wrapper.is_connected():
                result = await self._execute_via_com(step)
            elif self._vlm_fallback.is_available():
                logger.warning(
                    "SAP GUI Scripting API not available, falling back to VLM"
                )
                result = await self._vlm_fallback.execute_step(step)
            else:
                result = StepResult(
                    step_index=step.index,
                    success=False,
                    error_message=(
                        "SAP GUI Scripting API and VLM fallback are both unavailable"
                    ),
                )
                return result

            # Post-execution: screenshot + status bar + modal dialog check
            if self._sap_wrapper.is_connected():
                self._post_step_capture(step, result)

            elapsed_ms = int((time.time() - start_time) * 1000)
            result.execution_time_ms = elapsed_ms
            return result

        except Exception as exc:
            elapsed_ms = int((time.time() - start_time) * 1000)
            logger.error("Step %d execution error: %s", step.index, exc)
            return StepResult(
                step_index=step.index,
                success=False,
                error_message=str(exc),
                execution_time_ms=elapsed_ms,
            )

    # ------------------------------------------------------------------
    # Screen awareness
    # ------------------------------------------------------------------

    def get_current_screen(self) -> dict[str, str]:
        """获取当前屏幕状态信息。

        Returns:
            包含 window_title, transaction, status_bar 的字典。
        """
        info = {"window_title": "", "transaction": "", "status_bar": ""}
        session = self._sap_wrapper.get_session()
        if not session:
            return info
        try:
            info["window_title"] = str(session.findById("wnd[0]").Text or "")
        except Exception:
            pass
        try:
            info["transaction"] = str(session.findById("wnd[0]/tbar[0]/okcd").text or "")
        except Exception:
            pass
        try:
            info["status_bar"] = str(session.findById("wnd[0]/sbar").Text or "")
        except Exception:
            pass
        return info

    def is_on_login_screen(self) -> bool:
        """判断当前是否在登录界面。"""
        session = self._sap_wrapper.get_session()
        if not session:
            return False
        try:
            # 登录界面有 RSYST-BNAME 字段
            session.findById("wnd[0]/usr/txtRSYST-BNAME")
            return True
        except Exception:
            return False

    def is_logged_in(self) -> bool:
        """判断是否已经登录（在 SAP Easy Access 主界面）。"""
        screen = self.get_current_screen()
        title = screen["window_title"]
        return "轻松访问" in title or "Easy Access" in title or "SAP Menu" in title

    # ------------------------------------------------------------------
    # COM execution
    # ------------------------------------------------------------------

    async def _execute_via_com(self, step: TestStep) -> StepResult:
        """Execute a step via SAP GUI Scripting API (COM)."""
        try:
            if step.action_type == StepActionType.NAVIGATE:
                return self._execute_navigate(step)
            elif step.action_type == StepActionType.INPUT:
                return self._execute_input(step)
            elif step.action_type == StepActionType.CLICK:
                return self._execute_click(step)
            elif step.action_type == StepActionType.DOUBLE_CLICK:
                return self._execute_double_click(step)
            elif step.action_type == StepActionType.SELECT:
                return self._execute_select(step)
            elif step.action_type == StepActionType.VERIFY:
                return self._execute_verify(step)
            elif step.action_type == StepActionType.WAIT:
                return self._execute_wait(step)
            elif step.action_type == StepActionType.READ:
                return self._execute_read(step)
            else:
                return StepResult(
                    step_index=step.index,
                    success=False,
                    error_message=f"Unknown action type: {step.action_type}",
                )
        except Exception as exc:
            return StepResult(
                step_index=step.index,
                success=False,
                error_message=str(exc),
            )

    def _execute_navigate(self, step: TestStep) -> StepResult:
        """Execute a navigation step with screen awareness.

        如果当前已经在目标界面，跳过导航。
        如果当前在登录界面且导航目标不是事务码，跳过。
        """
        session = self._sap_wrapper.get_session()
        if session is None:
            return StepResult(
                step_index=step.index, success=False,
                error_message="No active session",
            )

        command = step.value or ""
        screen = self.get_current_screen()

        # 屏幕感知：如果当前在登录界面，跳过事务码导航（登录界面不支持事务码）
        if self.is_on_login_screen() and command.startswith("/n"):
            logger.info("跳过导航 %s（当前在登录界面）", command)
            return StepResult(
                step_index=step.index, success=True,
                status_bar_message="跳过（当前在登录界面）",
            )

        # 屏幕感知：如果当前已经在目标事务码界面，跳过导航
        tcode = command.replace("/n", "").replace("/o", "").upper()
        current_title = screen["window_title"].upper()
        if tcode and tcode in current_title:
            logger.info("跳过导航 %s（当前已在该界面）", command)
            return StepResult(
                step_index=step.index, success=True,
                status_bar_message=f"跳过（已在 {tcode} 界面）",
            )

        try:
            session.findById("wnd[0]/tbar[0]/okcd").text = command
            session.findById("wnd[0]").sendVKey(0)
            logger.info("Navigate: %s", command)
            time.sleep(1)
            # 处理可能出现的弹窗
            self._auto_handle_sap_dialog(session)
            return StepResult(step_index=step.index, success=True)
        except Exception as exc:
            return StepResult(
                step_index=step.index, success=False,
                error_message=f"Navigation failed: {exc}",
            )

    def _execute_input(self, step: TestStep) -> StepResult:
        """Execute an input step (set text on a field).

        Resolution strategy:
        1. If target is "命令输入框" → treat as navigate (enter tcode + press Enter)
        2. If target looks like a wait/verify description → skip gracefully
        3. If target looks like an ID path (contains '/') → use directly
        4. Otherwise → use ElementPathFinder to resolve business description
        """
        target = step.target_description
        value = step.value or ""

        # 命令输入框 → 当作导航处理
        if "命令输入框" in target or "okcd" in target.lower():
            nav_step = TestStep(
                index=step.index, action_type=StepActionType.NAVIGATE,
                target_description="命令输入框", value=value,
            )
            return self._execute_navigate(nav_step)

        # Skip non-input targets that were incorrectly classified as INPUT
        skip_keywords = ("等待", "验证", "检查", "确认登录", "观察", "wait", "verify", "check")
        if any(kw in target.lower() for kw in skip_keywords):
            logger.info("Skipping non-input step: %s (looks like wait/verify)", target)
            return StepResult(step_index=step.index, success=True)

        # 指纹快速路径：有 row/column 的表格操作，直接拼路径
        if step.row is not None and step.column is not None:
            fp_result = self._execute_structured_table_input(step, value)
            if fp_result is not None:
                return fp_result
            # 指纹路径失败，回退到下面的 ElementPathFinder 逻辑

        # 指纹快速路径：普通输入字段，从 field_map 中查找缓存路径
        if self._current_fp and self._current_fp.field_map:
            fp_path = self._match_field_from_fingerprint(target, self._current_fp.field_map)
            if fp_path:
                try:
                    self._sap_wrapper.set_text(fp_path, value)
                    logger.info(
                        "指纹字段命中: '%s' → %s (field_map)",
                        target, fp_path,
                    )
                    return StepResult(step_index=step.index, success=True)
                except Exception as exc:
                    logger.debug("指纹字段路径失败 (%s): %s", fp_path, exc)

        # If it already looks like a SAP element path, use directly
        if "/" in target or "wnd[" in target:
            try:
                self._sap_wrapper.set_text(target, value)
                return StepResult(step_index=step.index, success=True)
            except RuntimeError as exc:
                return StepResult(
                    step_index=step.index, success=False,
                    error_message=str(exc),
                )

        # Use ElementPathFinder to resolve business description to real path
        if self._element_finder is not None:
            try:
                # Use cached tree first
                match_result = self._element_finder.find_element_by_description(target)
                if match_result.found and match_result.element:
                    real_path = match_result.element.id_path
                    elem_type = match_result.element.element_type
                    logger.info(
                        "Resolved '%s' → %s (type=%s, method: %s)",
                        target, real_path, elem_type, match_result.match_method,
                    )
                    return self._set_element_value(step, real_path, elem_type, value)

                # Cache miss — force refresh and retry
                logger.info("Cache miss for '%s', refreshing element tree", target)
                self._element_finder.traverse_element_tree("wnd[0]/usr")
                match_result = self._element_finder.find_element_by_description(target)
                if match_result.found and match_result.element:
                    real_path = match_result.element.id_path
                    elem_type = match_result.element.element_type
                    logger.info(
                        "Resolved '%s' → %s (type=%s, method: %s) [after refresh]",
                        target, real_path, elem_type, match_result.match_method,
                    )
                    return self._set_element_value(step, real_path, elem_type, value)
            except Exception as exc:
                logger.debug("ElementPathFinder resolution failed for '%s': %s", target, exc)

        # Fall back to direct attempt (will likely fail for business descriptions)
        try:
            self._sap_wrapper.set_text(target, value)
            return StepResult(step_index=step.index, success=True)
        except RuntimeError as exc:
            return StepResult(
                step_index=step.index, success=False,
                error_message=str(exc),
            )

    # ------------------------------------------------------------------
    # Structured table input (fingerprint-based)
    # ------------------------------------------------------------------

    def _current_fingerprint_id(self, screen: dict[str, str] | None = None) -> str:
        """构建当前页面的指纹 ID"""
        if screen is None:
            screen = self.get_current_screen()
        active_tab = ""
        if self._current_fp and hasattr(self._current_fp, "active_tab"):
            active_tab = self._current_fp.active_tab
        return f"{screen.get('window_title', '')}|{active_tab}"

    @staticmethod
    def _match_field_from_fingerprint(target: str, field_map: dict[str, str]) -> str | None:
        """从指纹的 field_map 中匹配目标字段。

        匹配策略（按优先级）：
        1. 精确匹配
        2. target 包含在 key 中（如 "订单类型" 匹配 key "订单类型（采购）"）
        3. key 包含在 target 中（如 target "PB00条件类型价格" 匹配 key "条件类型价格"）
        4. 去掉"第N行"前缀后匹配
        """
        # 1. 精确匹配
        if target in field_map:
            return field_map[target]

        # 2/3. 包含匹配
        for key, path in field_map.items():
            if target in key or key in target:
                return path

        # 4. 去掉"第N行"前缀再匹配（如 "第一行物料" → "物料"）
        import re
        stripped = re.sub(r'^第[一二三四五六七八九十\d]+行', '', target)
        if stripped != target and stripped in field_map:
            return field_map[stripped]

        return None

    def _execute_structured_table_input(
        self, step: TestStep, value: str,
    ) -> StepResult | None:
        """使用指纹 + row/column 直接构造表格单元格路径。

        Returns:
            StepResult 成功/失败，或 None（指纹不可用时回退到原有逻辑）
        """
        from app.data.models import ViewType

        if self._fingerprint_store is None or self._current_fp is None:
            return None

        fp = self._current_fp

        # DETAIL 视图：用 field_map 定位，不使用行索引
        if fp.view_type == ViewType.DETAIL:
            if step.column and step.column in fp.field_map:
                path = fp.field_map[step.column]
                try:
                    self._sap_wrapper.set_text(path, value)
                    logger.info(
                        "结构化详情输入: [%s] column='%s' → %s",
                        fp.fingerprint_id, step.column, path,
                    )
                    return StepResult(step_index=step.index, success=True)
                except Exception as exc:
                    logger.debug("结构化详情输入失败: %s", exc)
                    return None
            return None

        # TABLE 视图：用 table_schema 拼接单元格路径
        if fp.view_type != ViewType.TABLE or fp.table_schema is None:
            return None

        schema = fp.table_schema

        # 在 columns 中按 column 名匹配
        col_info = None
        for col in schema.columns:
            col_name = col.get("name", "")
            if col_name == step.column or step.column in col_name:
                col_info = col
                break

        if col_info is None:
            logger.warning("指纹中未找到列 '%s'", step.column)
            return None

        col_index = col_info.get("col_index", 0)
        tech_name = col_info.get("tech_name", "")
        # TestStep.row 是 1-based, SAP 是 0-based
        sap_row = step.row - 1

        if schema.table_type == "GuiTableControl":
            # GuiTableControl 路径格式: table_path/tech_name[col_index, row_index]
            cell_path = f"{schema.table_path}/{tech_name}[{col_index},{sap_row}]"
        elif schema.table_type == "GuiGridView":
            # GuiGridView 用 Grid API
            return self._set_grid_cell_by_fingerprint(step, schema, value)
        else:
            return None

        try:
            self._sap_wrapper.set_text(cell_path, value)
            logger.info(
                "结构化表格输入: [%s] row=%d col='%s' → %s",
                fp.fingerprint_id, step.row, step.column, cell_path,
            )
            return StepResult(step_index=step.index, success=True)
        except Exception as exc:
            logger.debug("结构化表格输入失败 (%s)，回退: %s", cell_path, exc)
            return None

    def _set_grid_cell_by_fingerprint(
        self, step: TestStep, schema: Any, value: str,
    ) -> StepResult | None:
        """通过 GuiGridView 的 ModifyCell API 设置单元格值"""
        session = self._sap_wrapper.get_session()
        if not session:
            return None

        try:
            grid = session.findById(schema.table_path)
            col_info = None
            for col in schema.columns:
                if col.get("name", "") == step.column or step.column in col.get("name", ""):
                    col_info = col
                    break
            if col_info is None:
                return None

            col_id = col_info.get("tech_name", "")
            sap_row = step.row - 1

            grid.ModifyCell(sap_row, col_id, value)
            logger.info("Grid 结构化输入: [%d, %s] = '%s'", sap_row, col_id, value)
            return StepResult(step_index=step.index, success=True)
        except Exception as exc:
            logger.debug("Grid 结构化输入失败: %s", exc)
            return None

    def _execute_click(self, step: TestStep) -> StepResult:
        """Execute a click step (press button or send VKey)."""
        import time as _time
        target = step.target_description.lower().strip()
        session = self._sap_wrapper.get_session()

        if session is None:
            return StepResult(
                step_index=step.index, success=False,
                error_message="No active session",
            )

        try:
            if target in ("回车", "enter", "确认", "登录", "登录按钮"):
                session.findById("wnd[0]").sendVKey(0)
                _time.sleep(1)
                # 登录后可能出现多次登录弹窗，自动处理
                self._auto_handle_sap_dialog(session)
            elif target in ("保存按钮", "保存", "save"):
                session.findById("wnd[0]/tbar[0]/btn[11]").press()
            elif target in ("返回", "back"):
                session.findById("wnd[0]/tbar[0]/btn[3]").press()
            elif target in ("执行", "执行按钮", "execute", "f8"):
                try:
                    session.findById("wnd[0]").sendVKey(8)
                except Exception as vk_exc:
                    # F8 不可用说明可能已经在结果页了，视为成功
                    if "virtual key is not enabled" in str(vk_exc).lower():
                        logger.info("F8 not enabled — already on result page, treating as success")
                    else:
                        raise
            elif target in ("检查", "检查按钮", "check"):
                try:
                    session.findById("wnd[0]/tbar[1]/btn[0]").press()
                except Exception:
                    session.findById("wnd[0]").sendVKey(0)
            else:
                # 先尝试用 ElementPathFinder 找到匹配的元素
                found_and_clicked = False
                if self._element_finder is not None:
                    try:
                        # 刷新元素缓存
                        self._element_finder.traverse_element_tree("wnd[0]/usr")
                        # 尝试原始描述
                        match = self._element_finder.find_element_by_description(
                            step.target_description
                        )
                        # 如果没找到，去掉常见后缀再试（"条件页签"→"条件"）
                        if not match.found:
                            stripped = step.target_description
                            for suffix in ("页签", "标签", "按钮", "tab", "Tab", "button"):
                                if stripped.endswith(suffix):
                                    stripped = stripped[:-len(suffix)].strip()
                                    break
                            if stripped != step.target_description:
                                match = self._element_finder.find_element_by_description(stripped)
                                if match.found:
                                    logger.info("Found after stripping suffix: '%s' → '%s'",
                                                step.target_description, stripped)

                        if match.found and match.element:
                            elem_path = match.element.id_path
                            elem_type = match.element.element_type
                            element = session.findById(elem_path)
                            if elem_type == "GuiTab":
                                element.select()
                                logger.info("Tab selected: %s → %s", step.target_description, elem_path)
                            else:
                                element.press()
                                logger.info("Button pressed: %s → %s", step.target_description, elem_path)
                            found_and_clicked = True
                    except Exception as exc:
                        logger.debug("ElementPathFinder click failed: %s", exc)

                if not found_and_clicked:
                    self._sap_wrapper.press_button(step.target_description)

            # 任何点击后都检查弹窗
            self._auto_handle_sap_dialog(session)

            # 页签点击后强制刷新元素缓存（页签切换不改变窗口标题但内容变了）
            if any(kw in step.target_description for kw in ("页签", "标签", "tab", "Tab")):
                import time as _t2
                _t2.sleep(1)
                self._refresh_screen_cache()

            logger.info("Click: %s", step.target_description)
            return StepResult(step_index=step.index, success=True)
        except Exception as exc:
            return StepResult(
                step_index=step.index, success=False,
                error_message=f"Click failed: {exc}",
            )

    def _execute_double_click(self, step: TestStep) -> StepResult:
        """Execute a double-click step — double-click a table row item to enter detail."""
        import time as _time
        session = self._sap_wrapper.get_session()

        if session is None:
            return StepResult(
                step_index=step.index, success=False,
                error_message="No active session",
            )

        try:
            target = step.target_description
            row_num = step.row  # 行号，从1开始

            # 策略1：通过 ElementPathFinder 定位表格行并双击
            if self._element_finder is not None:
                try:
                    self._element_finder.traverse_element_tree("wnd[0]/usr")
                    match = self._element_finder.find_element_by_description(target)
                    if match.found and match.element:
                        elem_path = match.element.id_path
                        element = session.findById(elem_path)
                        if hasattr(element, 'doubleClick'):
                            element.doubleClick()
                        elif hasattr(element, 'select'):
                            element.select()
                            # F2 键在 SAP 中通常对应"选择/双击"
                            session.findById("wnd[0]").sendVKey(2)
                        else:
                            session.findById("wnd[0]").sendVKey(2)
                        _time.sleep(1)
                        self._auto_handle_sap_dialog(session)
                        self._refresh_screen_cache()
                        logger.info("Double-click: %s", target)
                        return StepResult(step_index=step.index, success=True)
                except Exception as exc:
                    logger.debug("ElementPathFinder double-click failed: %s", exc)

            # 策略2：如果指定了行号，尝试定位 GuiTableControl 并双击该行
            if row_num is not None:
                try:
                    # 查找屏幕上的 GuiTableControl
                    if self._element_finder is not None:
                        for elem_info in self._element_finder._elements_cache.values():
                            if elem_info.element_type in ("GuiTableControl", "GuiGridView"):
                                table = session.findById(elem_info.id_path)
                                if hasattr(table, 'currentCellRow'):
                                    table.currentCellRow = row_num - 1  # SAP 行号从0开始
                                    table.doubleClickCurrentCell()
                                elif hasattr(table, 'setCurrentCell'):
                                    table.setCurrentCell(row_num - 1, 0)
                                    table.doubleClickCurrentCell()
                                _time.sleep(1)
                                self._auto_handle_sap_dialog(session)
                                self._refresh_screen_cache()
                                logger.info("Double-click row %d: %s", row_num, target)
                                return StepResult(step_index=step.index, success=True)
                except Exception as exc:
                    logger.debug("Table double-click failed: %s", exc)

            # 策略3：回退到 F2 键（SAP 中 F2 = 选择/双击当前焦点项）
            session.findById("wnd[0]").sendVKey(2)
            _time.sleep(1)
            self._auto_handle_sap_dialog(session)
            logger.info("Double-click (F2 fallback): %s", target)
            return StepResult(step_index=step.index, success=True)

        except Exception as exc:
            return StepResult(
                step_index=step.index, success=False,
                error_message=f"Double-click failed: {exc}",
            )

    def _execute_select(self, step: TestStep) -> StepResult:
        """Execute a select step."""
        try:
            selected = True
            if step.value and step.value.lower() in ("false", "0", "no"):
                selected = False
            self._sap_wrapper.set_selected(step.target_description, selected)
            return StepResult(step_index=step.index, success=True)
        except RuntimeError as exc:
            return StepResult(
                step_index=step.index, success=False,
                error_message=str(exc),
            )

    def _execute_verify(self, step: TestStep) -> StepResult:
        """执行验证步骤 — 先做基础匹配，匹配不上让 GLM 判断。

        验证策略：
        1. 精确子串匹配（快速路径）
        2. 语义匹配：把预期和实际屏幕状态发给 GLM 判断是否满足
        """
        import time as _time

        session = self._sap_wrapper.get_session()
        window_title = ""
        status_text = ""

        if session:
            self._auto_handle_sap_dialog(session)
            try:
                window_title = str(session.findById("wnd[0]").Text or "")
            except Exception:
                pass

        status_bar = self._sap_wrapper.read_status_bar()
        if status_bar:
            status_text = status_bar.text or ""

        expected = step.value or ""
        screen_info = f"窗口: {window_title} | 状态栏: {status_text}"

        if not expected:
            return StepResult(
                step_index=step.index, success=True,
                status_bar_message=screen_info,
            )

        # 1. 精确子串匹配
        screen_text = f"{window_title} {status_text}"
        if expected in screen_text:
            return StepResult(
                step_index=step.index, success=True,
                status_bar_message=screen_info,
            )

        # 2. GLM 语义判断
        if self._glm_client is not None:
            try:
                result = self._glm_verify(expected, window_title, status_text, step)
                if result is not None:
                    return result
            except Exception as exc:
                logger.debug("GLM verify failed: %s", exc)

        # 3. 兜底：子串匹配失败
        return StepResult(
            step_index=step.index, success=False,
            status_bar_message=screen_info,
            error_message=f"验证失败: 期望包含「{expected}」，实际窗口=「{window_title}」，状态栏=「{status_text}」",
        )

    def _glm_verify(
        self, expected: str, window_title: str, status_text: str, step: TestStep,
    ) -> StepResult | None:
        """让 GLM 根据完整屏幕状态判断是否满足预期。"""
        screen_elements = self.collect_screen_elements_text(max_elements=50)

        # 调用 GLM 判断（直接用同步方法）
        prompt = self._glm_client._prompt_manager.render_verify_result(
            expected=expected,
            window_title=window_title,
            status_bar=status_text,
            screen_elements=screen_elements,
        )
        raw = self._glm_client._chat_sync(prompt, timeout=10)
        result = self._glm_client._parse_json(raw)

        passed = result.get("pass", False)
        reason = result.get("reason", "")

        logger.info("GLM verify: pass=%s, reason=%s", passed, reason)

        return StepResult(
            step_index=step.index,
            success=passed,
            status_bar_message=f"窗口: {window_title} | 状态栏: {status_text}",
            error_message="" if passed else f"验证失败（AI判断）: {reason}",
        )

        # Should not reach here, but just in case
        return StepResult(step_index=step.index, success=True)

    def _execute_wait(self, step: TestStep) -> StepResult:
        """Execute a wait step."""
        wait_val = step.value or ""
        # Extract numeric value from value or target_description
        wait_seconds = STEP_WAIT_INTERVAL
        for src in [wait_val, step.target_description]:
            try:
                cleaned = ''.join(c for c in src if c.isdigit() or c == '.')
                if cleaned:
                    wait_seconds = float(cleaned)
                    break
            except (ValueError, TypeError):
                continue
        time.sleep(wait_seconds)
        return StepResult(step_index=step.index, success=True)

    def _execute_read(self, step: TestStep) -> StepResult:
        """执行数据读取步骤 — 从当前屏幕采集表格/清单数据。

        读取 SAP ALV Grid 或普通表格中的所有行数据，
        记录到 StepResult.status_bar_message 中。
        """
        session = self._sap_wrapper.get_session()
        if not session:
            return StepResult(
                step_index=step.index, success=False,
                error_message="No active session",
            )

        collected_data: list[dict] = []

        # 方法 1: 尝试读取 ALV Grid 控件
        try:
            grid = session.findById("wnd[0]/usr/cntlGRID1/shellcont/shell")
            row_count = grid.RowCount
            col_count = grid.ColumnCount

            # 读取列标题
            columns = []
            for c in range(col_count):
                try:
                    col_name = grid.GetColumnTitles(c)
                    columns.append(str(col_name) if col_name else f"col_{c}")
                except Exception:
                    columns.append(f"col_{c}")

            # 如果 GetColumnTitles 不可用，尝试其他方式获取列名
            if all(c.startswith("col_") for c in columns):
                try:
                    col_order = grid.ColumnOrder
                    columns = [str(c) for c in col_order][:col_count]
                except Exception:
                    pass

            # 读取行数据
            max_rows = min(row_count, 100)  # 最多读 100 行
            for r in range(max_rows):
                row_data = {}
                for c in range(min(col_count, 20)):  # 最多 20 列
                    try:
                        cell_value = grid.GetCellValue(r, columns[c] if c < len(columns) else f"col_{c}")
                        col_name = columns[c] if c < len(columns) else f"col_{c}"
                        row_data[col_name] = str(cell_value) if cell_value else ""
                    except Exception:
                        pass
                if row_data:
                    collected_data.append(row_data)

            logger.info("Read %d rows from ALV Grid (%d columns)", len(collected_data), col_count)

        except Exception as grid_exc:
            logger.debug("ALV Grid read failed: %s, trying element tree", grid_exc)

            # 方法 2: 通过元素树读取屏幕上的文本内容
            if self._element_finder is not None:
                try:
                    tree = self._element_finder.traverse_element_tree("wnd[0]/usr")
                    for elem in tree.elements:
                        if elem.current_value:
                            collected_data.append({
                                "path": elem.id_path,
                                "label": elem.label_text or elem.tooltip or "",
                                "value": elem.current_value,
                                "type": elem.element_type,
                            })
                    logger.info("Read %d elements from screen", len(collected_data))
                except Exception as tree_exc:
                    logger.debug("Element tree read failed: %s", tree_exc)

        if collected_data:
            # 格式化数据为可读文本
            import json
            data_json = json.dumps(collected_data, ensure_ascii=False, indent=2)
            summary = f"读取到 {len(collected_data)} 条数据"
            logger.info("Read data:\n%s", data_json[:2000])

            return StepResult(
                step_index=step.index,
                success=True,
                status_bar_message=f"{summary}\n{data_json[:5000]}",
            )
        else:
            return StepResult(
                step_index=step.index,
                success=True,
                status_bar_message="当前屏幕无可读取的表格数据",
            )

    # ------------------------------------------------------------------
    # Screen change detection
    # ------------------------------------------------------------------

    # ------------------------------------------------------------------
    # Element value setting
    # ------------------------------------------------------------------

    def _set_element_value(self, step: TestStep, path: str, elem_type: str, value: str) -> StepResult:
        """根据元素类型选择正确的赋值方式。

        - GuiTextField/GuiCTextField/GuiPasswordField → .text = value
        - GuiComboBox → .key = value (下拉框用 key 选择)
        - GuiCheckBox → .selected = True/False
        - GuiRadioButton → .select()
        - GuiGridColumn → Grid API SetCellValue (表格单元格)
        """
        session = self._sap_wrapper.get_session()
        if not session:
            return StepResult(step_index=step.index, success=False, error_message="No session")

        try:
            # 表格列：用 Grid API 写入单元格
            if elem_type == "GuiGridColumn" and "/col[" in path:
                return self._set_grid_cell_value(session, step, path, value)

            element = session.findById(path)

            if elem_type == "GuiComboBox":
                try:
                    element.key = value
                except Exception:
                    element.value = value
                logger.info("ComboBox %s set to '%s'", path, value)

            elif elem_type in ("GuiCheckBox",):
                selected = value.lower() not in ("false", "0", "no", "unselected", "")
                element.selected = selected
                logger.info("CheckBox %s set to %s", path, selected)

            elif elem_type in ("GuiRadioButton",):
                element.select()
                logger.info("RadioButton %s selected", path)

            else:
                element.text = value
                logger.info("Input %s set to '%s'", path, value)

            return StepResult(step_index=step.index, success=True)

        except Exception as exc:
            return StepResult(
                step_index=step.index, success=False,
                error_message=f"Set value failed on {path} (type={elem_type}): {exc}",
            )

    def _set_grid_cell_value(
        self, session, step: TestStep, virtual_path: str, value: str,
    ) -> StepResult:
        """通过 Grid API 设置表格单元格的值。

        virtual_path 格式: .../shell/col[COLUMN_ID]
        从 virtual_path 中提取 grid_path 和 column_id，
        然后用 ModifyCell(row, column_id, value) 写入。
        """
        import re
        import time as _time

        # 解析 virtual_path: grid_path/col[COLUMN_ID]
        match = re.match(r'(.+)/col\[(.+)\]$', virtual_path)
        if not match:
            return StepResult(
                step_index=step.index, success=False,
                error_message=f"Invalid grid column path: {virtual_path}",
            )

        grid_path = match.group(1)
        column_id = match.group(2)

        try:
            grid = session.findById(grid_path)

            # 找到第一个空行或当前行
            row_count = grid.RowCount
            target_row = max(0, row_count - 1)  # 默认最后一行

            # 如果是新增行，尝试找第一个空行
            for r in range(row_count):
                try:
                    cell_val = grid.GetCellValue(r, column_id)
                    if not cell_val or str(cell_val).strip() == "":
                        target_row = r
                        break
                except Exception:
                    target_row = r
                    break

            # 设置单元格值
            grid.ModifyCell(target_row, column_id, value)
            logger.info("Grid %s: set cell [%d, %s] = '%s'", grid_path, target_row, column_id, value)

            # 按回车确认输入
            _time.sleep(0.3)
            grid.PressEnter()

            return StepResult(step_index=step.index, success=True)

        except Exception as exc:
            return StepResult(
                step_index=step.index, success=False,
                error_message=f"Grid cell set failed [{column_id}]: {exc}",
            )

    def _refresh_screen_cache(self, log_fn=None):
        """采集当前屏幕元素并缓存，同时生成/更新页面指纹。"""
        screen = self.get_current_screen()
        self._cached_screen_title = screen["window_title"]
        if self._element_finder is not None:
            try:
                self._element_finder.traverse_element_tree("wnd[0]/usr")
                # 生成并存储页面指纹
                try:
                    fp = self._element_finder.generate_fingerprint(screen["window_title"])
                    if fp is not None:
                        self._current_fp = fp
                        if self._fingerprint_store is not None:
                            self._fingerprint_store.save(fp)
                except Exception as fp_exc:
                    logger.debug("指纹生成失败（不影响执行）: %s", fp_exc)
                if log_fn:
                    tree = self._element_finder._cached_tree
                    if tree:
                        view_info = ""
                        if self._current_fp:
                            view_info = f", view={self._current_fp.view_type.value}"
                        log_fn(f"  🔎 采集屏幕元素: {len(tree.elements)} 个 (界面: {self._cached_screen_title}{view_info})")
            except Exception as exc:
                if log_fn:
                    log_fn(f"  ⚠️ 屏幕元素采集失败: {exc}")

    def collect_screen_elements_text(self, max_elements: int = 60) -> str:
        """统一的屏幕元素采集方法 — 返回格式化的元素文本。

        优先返回有 label/tooltip 的元素（可操作的），过滤掉纯容器元素。
        对表格单元格做智能压缩：只保留有复合 label（如"PBXX 金额"）的关键单元格，
        避免大量重复的货币/单位单元格挤掉真正有用的元素。
        """
        if self._element_finder is None:
            return ""

        try:
            tree = self._element_finder._cached_tree
            if tree is None:
                self._element_finder.traverse_element_tree("wnd[0]/usr")
                tree = self._element_finder._cached_tree

            if tree is None:
                return ""

            # 分三组：关键元素（优先）、普通有 label 的、没有 label 的
            key_elements = []    # 非表格元素 + 表格中有复合 label 的
            table_basic = []     # 表格中只有基础列标题 label 的
            unlabeled = []       # 没有 label 的

            skip_types = {"GuiSimpleContainer", "GuiScrollContainer", "GuiUserArea",
                          "GuiCustomControl", "GuiContainerShell",
                          "GuiTabStrip", "GuiLabel"}

            for elem in tree.elements:
                if elem.element_type in skip_types:
                    continue
                label = elem.label_text or elem.tooltip or ""

                info = f"  {elem.id_path} (type={elem.element_type}"
                if label:
                    info += f", label=\"{label}\""
                if elem.current_value:
                    info += f", value=\"{elem.current_value}\""
                if not elem.is_changeable:
                    info += ", readonly=true"
                info += ")"

                if not label:
                    unlabeled.append(info)
                    continue

                # 判断是否是表格单元格（路径中包含 tbl 且有 [col,row] 后缀）
                is_table_cell = "/tbl" in elem.id_path and re.search(r'\[\d+,\d+\]$', elem.id_path)
                if is_table_cell:
                    # 复合 label（包含空格，如 "PBXX 金额"）→ 关键元素
                    if " " in label:
                        key_elements.append(info)
                    else:
                        table_basic.append(info)
                else:
                    key_elements.append(info)

            # 优先：关键元素 → 表格基础 → 无 label
            result = key_elements[:max_elements]
            remaining = max_elements - len(result)
            if remaining > 0:
                result.extend(table_basic[:remaining])
                remaining = max_elements - len(result)
            if remaining > 0:
                result.extend(unlabeled[:remaining])

            return "\n".join(result)
        except Exception:
            return ""

    def _check_screen_change(self, log_fn=None):
        """检测界面是否变化，变化则重新采集元素并刷新指纹。"""
        screen = self.get_current_screen()
        new_title = screen["window_title"]
        if new_title != self._cached_screen_title:
            if log_fn:
                log_fn(f"  🔄 界面变化: {self._cached_screen_title} → {new_title}")
            self._refresh_screen_cache(log_fn)
            # 界面变化后提示当前视图类型
            if self._current_fp and log_fn:
                from app.data.models import ViewType
                if self._current_fp.view_type == ViewType.DETAIL:
                    log_fn(f"  📋 详情视图 — 表格行索引不可用")

    # ------------------------------------------------------------------
    # Post-step capture
    # ------------------------------------------------------------------

    def _post_step_capture(self, step: TestStep, result: StepResult) -> None:
        """Capture screenshot, status bar, and check for modal dialogs after a step."""
        import time as _time

        # Screenshot
        try:
            screenshot_dir = os.path.join(ARTIFACTS_DIR, "screenshots")
            screenshot_path = os.path.join(
                screenshot_dir, f"step_{step.index:03d}.png"
            )
            saved = self._sap_wrapper.screenshot(screenshot_path)
            if saved:
                result.screenshot_path = saved
        except Exception as exc:
            logger.debug("Screenshot capture failed: %s", exc)

        # Status bar
        try:
            status_bar = self._sap_wrapper.read_status_bar()
            result.status_bar_message = status_bar.text
        except Exception as exc:
            logger.debug("Status bar read failed: %s", exc)

        # Modal dialog check and auto-handle
        try:
            session = self._sap_wrapper.get_session()
            if session:
                self._auto_handle_sap_dialog(session)
        except Exception as exc:
            logger.debug("Modal dialog handling failed: %s", exc)

    def _auto_handle_sap_dialog(self, session) -> bool:
        """自动处理 SAP wnd[1] 模态弹窗。

        策略：
        1. 采集弹窗信息（标题、正文、按钮列表）
        2. 多次登录弹窗 → 直接选择"继续此登录"（这是固定的 SAP 系统行为）
        3. 其他弹窗 → 交给 GLM 判断该点哪个按钮
        4. GLM 不可用时 → 兜底点第一个按钮

        Returns:
            True if a dialog was handled, False otherwise.
        """
        import time as _time
        try:
            wnd1 = session.findById("wnd[1]")
        except Exception:
            return False  # 没有弹窗

        try:
            title = str(wnd1.Text or "")
            logger.info("SAP 弹窗检测: title='%s'", title)

            # 采集弹窗完整信息
            dialog_text = ""
            buttons = []
            try:
                # 读取弹窗正文
                usr = wnd1.Children
                for i in range(usr.Count):
                    try:
                        child = usr(i)
                        child_type = str(child.Type) if hasattr(child, 'Type') else ""
                        if child_type == "GuiButton":
                            btn_text = str(child.Text) if child.Text else ""
                            btn_id = str(child.Id) if child.Id else ""
                            buttons.append({"text": btn_text.strip(), "id": btn_id})
                        elif hasattr(child, 'Text') and child.Text:
                            dialog_text += str(child.Text) + " "
                        # 递归一层读取 usr 下的子元素
                        if hasattr(child, 'Children'):
                            sub_children = child.Children
                            for j in range(sub_children.Count):
                                try:
                                    sub = sub_children(j)
                                    sub_type = str(sub.Type) if hasattr(sub, 'Type') else ""
                                    if sub_type == "GuiButton":
                                        btn_text = str(sub.Text) if sub.Text else ""
                                        btn_id = str(sub.Id) if sub.Id else ""
                                        buttons.append({"text": btn_text.strip(), "id": btn_id})
                                    elif hasattr(sub, 'Text') and sub.Text:
                                        dialog_text += str(sub.Text) + " "
                                except Exception:
                                    pass
                    except Exception:
                        pass
            except Exception:
                pass

            # 工具栏按钮
            for btn_idx in range(5):
                try:
                    btn = session.findById(f"wnd[1]/tbar[0]/btn[{btn_idx}]")
                    btn_text = str(btn.Text) if btn.Text else f"btn[{btn_idx}]"
                    btn_id = str(btn.Id)
                    buttons.append({"text": btn_text.strip(), "id": btn_id})
                except Exception:
                    break

            logger.info("弹窗内容: title='%s', text='%s', buttons=%s",
                        title, dialog_text.strip()[:100],
                        [b["text"] for b in buttons])

            # 多次登录弹窗 — SAP 系统固定行为，直接处理
            if "登录" in title or "许可" in title or "Multiple Logon" in title.lower():
                try:
                    session.findById("wnd[1]/usr/radMULTI_LOGON_OPT2").select()
                    logger.info("选择了'继续此登录'选项")
                except Exception:
                    try:
                        session.findById("wnd[1]/usr/radMULTI_LOGON_OPT1").select()
                    except Exception:
                        pass
                try:
                    session.findById("wnd[1]/tbar[0]/btn[0]").press()
                except Exception:
                    wnd1.sendVKey(0)
                _time.sleep(0.5)
                return True

            # 其他弹窗 — 交给 GLM 判断
            if self._glm_client and buttons:
                try:
                    btn_id = self._glm_decide_dialog(title, dialog_text.strip(), buttons)
                    if btn_id:
                        session.findById(btn_id).press()
                        logger.info("GLM 决策弹窗: 点击 '%s' (%s)", btn_id, title)
                        _time.sleep(0.5)
                        # 递归检查后续弹窗
                        try:
                            session.findById("wnd[1]")
                            self._auto_handle_sap_dialog(session)
                        except Exception:
                            pass
                        return True
                except Exception as exc:
                    logger.debug("GLM dialog decision failed: %s", exc)

            # 兜底：点第一个工具栏按钮
            try:
                session.findById("wnd[1]/tbar[0]/btn[0]").press()
                logger.info("弹窗兜底处理: 点击第一个按钮 '%s'", title)
            except Exception:
                try:
                    wnd1.sendVKey(0)
                except Exception:
                    pass

            _time.sleep(0.5)
            return True

        except Exception as exc:
            logger.debug("SAP 弹窗处理异常: %s", exc)
            return False

    def _glm_decide_dialog(
        self, title: str, text: str, buttons: list[dict],
    ) -> str | None:
        """让 GLM 根据弹窗内容和测试上下文决定点哪个按钮。

        Returns:
            按钮的 element ID path，或 None。
        """
        buttons_desc = "\n".join(
            f"  - \"{b['text']}\" (id: {b['id']})" for b in buttons
        )
        prompt = f"""SAP GUI 弹出了一个对话框，请根据当前测试上下文判断应该点击哪个按钮。

弹窗标题: {title}
弹窗内容: {text}
当前测试上下文: {self._test_case_context}

可用按钮:
{buttons_desc}

请直接返回应该点击的按钮 id（只返回 id 字符串，不要其他内容）。
如果是保存/确认类操作，通常点击"保存"或确认按钮。
如果是错误提示，通常点击确认/关闭按钮。"""

        raw = self._glm_client._chat_sync(prompt, timeout=10)
        if not raw:
            return None

        # 从 GLM 返回中提取按钮 ID
        raw = raw.strip().strip('"').strip("'")
        for btn in buttons:
            if btn["id"] in raw or raw in btn["id"]:
                return btn["id"]
            if btn["text"] and btn["text"] in raw:
                return btn["id"]

        # 兜底：返回第一个按钮
        return buttons[0]["id"] if buttons else None

    # ------------------------------------------------------------------
    # Document number extraction
    # ------------------------------------------------------------------

    def extract_document_number(self, status_message: str) -> str | None:
        """正则匹配凭证号，使用可配置的正则模式列表。

        Args:
            status_message: Status bar message text.

        Returns:
            Extracted document number (8-10 digit string), or None.
        """
        if not status_message:
            return None

        # Try configured patterns first
        for pattern_def in self._patterns:
            regex = pattern_def.get("regex", "")
            if not regex:
                continue
            try:
                match = re.search(regex, status_message)
                if match and match.group(1):
                    doc_no = match.group(1)
                    logger.info(
                        "Document number extracted via pattern '%s': %s",
                        pattern_def.get("name", "unknown"), doc_no,
                    )
                    return doc_no
            except Exception as exc:
                logger.debug("Pattern '%s' failed: %s", pattern_def.get("name"), exc)

        # Fallback: generic 8-10 digit number extraction
        fallback_match = re.search(r"(\d{8,10})", status_message)
        if fallback_match:
            doc_no = fallback_match.group(1)
            logger.info("Document number extracted via fallback: %s", doc_no)
            return doc_no

        return None

    # ------------------------------------------------------------------
    # Modal dialog handling
    # ------------------------------------------------------------------

    async def handle_modal_dialog(self, dialog_info: dict) -> str:
        """处理模态对话框。

        Args:
            dialog_info: Dict with 'title' and 'text' keys.

        Returns:
            Action taken: "confirmed", "cancelled", or "unknown".
        """
        if not self._sap_wrapper.is_connected():
            return "unknown"

        title = dialog_info.get("title", "").lower()
        text = dialog_info.get("text", "").lower()

        try:
            # Information dialogs: confirm
            if any(kw in text for kw in ["已保存", "已创建", "saved", "created", "成功"]):
                self._sap_wrapper.press_button("wnd[1]/tbar[0]/btn[0]")
                logger.info("Modal dialog confirmed (info): %s", dialog_info.get("title"))
                return "confirmed"

            # Confirmation dialogs: confirm by default
            if any(kw in title for kw in ["确认", "confirm", "信息", "information"]):
                self._sap_wrapper.press_button("wnd[1]/tbar[0]/btn[0]")
                logger.info("Modal dialog confirmed: %s", dialog_info.get("title"))
                return "confirmed"

            # Error dialogs: confirm to dismiss
            if any(kw in title for kw in ["错误", "error"]):
                self._sap_wrapper.press_button("wnd[1]/tbar[0]/btn[0]")
                logger.info("Modal dialog dismissed (error): %s", dialog_info.get("title"))
                return "confirmed"

            # Default: try to confirm
            self._sap_wrapper.press_button("wnd[1]/tbar[0]/btn[0]")
            logger.info("Modal dialog confirmed (default): %s", dialog_info.get("title"))
            return "confirmed"

        except Exception as exc:
            logger.warning("Failed to handle modal dialog: %s", exc)
            return "unknown"

    # ------------------------------------------------------------------
    # Stop execution
    # ------------------------------------------------------------------

    def stop(self) -> None:
        """停止执行。"""
        self._stopped = True
        logger.info("Execution stop requested")

    # ------------------------------------------------------------------
    # Pattern loading
    # ------------------------------------------------------------------

    def _load_patterns(self) -> list[dict]:
        """从 knowledge_base/patterns.json 加载正则模式。

        Returns:
            List of pattern dicts with 'name', 'regex', 'variable' keys.
        """
        patterns_path = os.path.join(KNOWLEDGE_BASE_DIR, "patterns.json")
        try:
            with open(patterns_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            patterns = data.get("patterns", [])
            logger.info("Loaded %d document number patterns from %s", len(patterns), patterns_path)
            return patterns
        except FileNotFoundError:
            logger.warning("Patterns file not found: %s", patterns_path)
            return []
        except Exception as exc:
            logger.warning("Failed to load patterns: %s", exc)
            return []

    # ------------------------------------------------------------------
    # Variable resolution
    # ------------------------------------------------------------------

    @staticmethod
    def _resolve_step_variables(step: TestStep, flow_context: Any) -> TestStep:
        """Resolve flow variable references in step value.

        Args:
            step: Original TestStep.
            flow_context: FlowVariableContext for variable resolution.

        Returns:
            New TestStep with resolved values.
        """
        if flow_context is None or step.value is None:
            return step

        try:
            resolved_value = flow_context.resolve(step.value)
            if resolved_value != step.value:
                logger.info(
                    "Resolved step %d value: '%s' → '%s'",
                    step.index, step.value, resolved_value,
                )
            return TestStep(
                index=step.index,
                action_type=step.action_type,
                target_description=step.target_description,
                value=resolved_value,
                flow_variable_ref=step.flow_variable_ref,
                row=step.row,
                column=step.column,
            )
        except KeyError as exc:
            logger.warning("Variable resolution failed for step %d: %s", step.index, exc)
            return step
