"""VLM 兜底执行器

当 SAP GUI Scripting API 不可用时，通过 VLM + OCR + PyAutoGUI 执行步骤。
封装现有 ui_test_python 工程的 VLMExecutor，适配新的 TestStep/StepResult 接口。
"""

from __future__ import annotations

import logging
import os
import time
import uuid
from typing import Any

from app.config import ARTIFACTS_DIR
from app.data.models import (
    StepActionType,
    StepResult,
    TestStep,
)

logger = logging.getLogger(__name__)


class VlmFallbackExecutor:
    """VLM 兜底执行器，基于现有 ui_test_python 工程的 VLMExecutor。

    Wraps the existing VLMExecutor to adapt it to the new TestStep/StepResult
    interface used by ScriptExecutor.
    """

    def __init__(self) -> None:
        self._available = self._check_dependencies()
        self._vlm_executor: Any = None

    # ------------------------------------------------------------------
    # Availability check
    # ------------------------------------------------------------------

    def is_available(self) -> bool:
        """检查 VLM 方案是否可用。"""
        return self._available

    def _check_dependencies(self) -> bool:
        """检查依赖（RapidOCR、PyAutoGUI 等）。

        Returns:
            True if all VLM dependencies are available.
        """
        try:
            import pyautogui  # noqa: F401
            logger.debug("pyautogui available")
        except ImportError:
            logger.info("pyautogui not available – VLM fallback disabled")
            return False

        try:
            import mss  # noqa: F401
            logger.debug("mss available")
        except ImportError:
            logger.info("mss not available – VLM fallback disabled")
            return False

        try:
            from PIL import Image  # noqa: F401
            logger.debug("Pillow available")
        except ImportError:
            logger.info("Pillow not available – VLM fallback disabled")
            return False

        try:
            import httpx  # noqa: F401
            logger.debug("httpx available")
        except ImportError:
            logger.info("httpx not available – VLM fallback disabled")
            return False

        # RapidOCR is loaded lazily by VLMExecutor, just check importability
        try:
            import rapidocr_onnxruntime  # noqa: F401
            logger.debug("rapidocr_onnxruntime available")
        except ImportError:
            logger.info("rapidocr_onnxruntime not available – VLM fallback may be limited")
            # Not a hard requirement; VLM can work without OCR in some modes

        logger.info("VLM fallback dependencies check passed")
        return True

    # ------------------------------------------------------------------
    # Lazy initialization
    # ------------------------------------------------------------------

    def _get_vlm_executor(self) -> Any:
        """Lazily initialize the underlying VLMExecutor."""
        if self._vlm_executor is None:
            try:
                from app.vlm_executor import VLMExecutor
                self._vlm_executor = VLMExecutor()
                logger.info("VLMExecutor initialized for fallback")
            except Exception as exc:
                logger.error("Failed to initialize VLMExecutor: %s", exc)
                self._available = False
                raise RuntimeError(
                    f"VLMExecutor initialization failed: {exc}"
                ) from exc
        return self._vlm_executor

    # ------------------------------------------------------------------
    # Step execution
    # ------------------------------------------------------------------

    async def execute_step(self, step: TestStep) -> StepResult:
        """通过 VLM + OCR + PyAutoGUI 执行步骤。

        Converts the TestStep to a natural language prompt and delegates
        to the existing VLMExecutor.

        Args:
            step: TestStep to execute.

        Returns:
            StepResult with execution outcome.
        """
        start_time = time.time()

        if not self._available:
            return StepResult(
                step_index=step.index,
                success=False,
                error_message="VLM fallback is not available",
            )

        try:
            executor = self._get_vlm_executor()
            prompt = self._step_to_prompt(step)
            task_id = f"vlm_fallback_{uuid.uuid4().hex[:8]}"

            logger.info(
                "VLM fallback executing step %d: %s", step.index, prompt
            )

            result = await executor.execute(task_id, prompt)

            elapsed_ms = int((time.time() - start_time) * 1000)

            if result.success:
                return StepResult(
                    step_index=step.index,
                    success=True,
                    execution_time_ms=elapsed_ms,
                )
            else:
                return StepResult(
                    step_index=step.index,
                    success=False,
                    error_message=result.error or "VLM execution failed",
                    execution_time_ms=elapsed_ms,
                )

        except Exception as exc:
            elapsed_ms = int((time.time() - start_time) * 1000)
            logger.error("VLM fallback step %d failed: %s", step.index, exc)
            return StepResult(
                step_index=step.index,
                success=False,
                error_message=f"VLM fallback error: {exc}",
                execution_time_ms=elapsed_ms,
            )

    # ------------------------------------------------------------------
    # Step-to-prompt conversion
    # ------------------------------------------------------------------

    @staticmethod
    def _step_to_prompt(step: TestStep) -> str:
        """Convert a TestStep to a natural language prompt for VLMExecutor.

        Args:
            step: The TestStep to convert.

        Returns:
            Natural language instruction string.
        """
        action = step.action_type
        target = step.target_description
        value = step.value or ""

        if action == StepActionType.NAVIGATE:
            return f'在命令输入框中输入 "{value}" 并按 Enter 键'

        elif action == StepActionType.INPUT:
            if value:
                return f'在 "{target}" 输入框输入 "{value}"'
            return f'定位 "{target}" 输入框'

        elif action == StepActionType.CLICK:
            return f'点击 "{target}"'

        elif action == StepActionType.SELECT:
            if value and value.lower() in ("false", "0", "no"):
                return f'取消选择 "{target}"'
            return f'选择 "{target}"'

        elif action == StepActionType.VERIFY:
            return f'验证 "{target}"'

        elif action == StepActionType.WAIT:
            return f'等待 {value or "1"} 秒'

        return f'{target} {value}'.strip()
