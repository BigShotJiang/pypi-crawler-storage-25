"""屏幕状态采集器 — 采集 SAP GUI 当前窗口的完整上下文。

在每个步骤执行前后捕获窗口标题、状态栏、活动窗口 ID 和元素树摘要，
组装为 ScreenSnapshot 对象。任何 COM 异常不中断采集，未采集字段设为空值。
"""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Any

from app.config import MAX_ELEMENT_TREE_DEPTH
from app.data.models import MessageType, ScreenSnapshot

logger = logging.getLogger(__name__)


class ScreenStateCollector:
    """屏幕状态采集器 — 采集 SAP GUI 当前窗口的完整上下文。"""

    def __init__(
        self,
        sap_wrapper: Any,
        element_finder: Any,
    ) -> None:
        self._sap = sap_wrapper
        self._element_finder = element_finder

    def collect_snapshot(self, include_element_tree: bool = True) -> ScreenSnapshot:
        """采集当前屏幕状态，返回 ScreenSnapshot。

        Args:
            include_element_tree: 是否采集元素树（耗时操作）。
                常规步骤前后设为 False 以提速，仅在自愈分析时设为 True。

        任何 COM 异常不会中断采集，未采集字段设为空值。
        """
        window_title = ""
        status_bar_text = ""
        status_bar_type = MessageType.INFO
        active_window_id = "wnd[0]"
        element_tree_summary = ""
        timestamp = datetime.now()

        # 采集窗口标题
        try:
            session = self._sap.get_session()
            if session:
                window_title = str(session.findById("wnd[0]").Text or "")
        except Exception as exc:
            logger.warning("采集窗口标题失败: %s", exc)

        # 采集状态栏
        try:
            sbar = self._sap.read_status_bar()
            status_bar_text = sbar.text
            status_bar_type = sbar.message_type
        except Exception as exc:
            logger.warning("采集状态栏失败: %s", exc)

        # 采集活动窗口 ID
        try:
            active_window_id = self._sap.get_active_window_id()
        except Exception as exc:
            logger.warning("采集活动窗口 ID 失败: %s", exc)

        # 采集元素树摘要（仅在需要时，如自愈分析）
        if include_element_tree:
            try:
                tree = self._element_finder.traverse_element_tree(
                    "wnd[0]/usr", max_depth=MAX_ELEMENT_TREE_DEPTH
                )
                input_fields = [
                    e for e in tree.elements
                    if e.element_type in (
                        "GuiCTextField", "GuiTextField",
                        "GuiPasswordField", "GuiComboBox",
                    )
                ]
                field_names = [
                    f.tooltip or f.label_text or f.id_path
                    for f in input_fields[:20]
                ]
                element_tree_summary = (
                    f"元素总数: {len(tree.elements)}, "
                    f"输入字段: {field_names}"
                )
            except Exception as exc:
                logger.warning("采集元素树失败: %s", exc)

        return ScreenSnapshot(
            window_title=window_title,
            status_bar_text=status_bar_text,
            status_bar_type=status_bar_type,
            active_window_id=active_window_id,
            element_tree_summary=element_tree_summary,
            timestamp=timestamp,
        )
