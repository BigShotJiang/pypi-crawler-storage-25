"""任务状态存储

本模块提供两套任务存储：

1. ``VlmTaskStore``：VLM / Excel 流程使用的 ``TaskInfo`` 存储
   （供 ``app/routes.py`` 的 Excel 解析 → 执行流程使用）。

2. ``TaskStore`` + ``InMemoryTaskStore``：供 SAP 自动化路由与 MCP Server
   复用的通用异步任务存储抽象（对齐 design.md §7.2、requirements.md R18.6–R18.7）。
   任务以 ``dict`` 形式保存，便于 FastAPI JSON 序列化与实时字段增量更新。
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from threading import RLock
from typing import Any, Protocol

from .models import TaskInfo, TaskStatus


# ---------------------------------------------------------------------------
# 1) VLM / Excel 流程的 TaskInfo 存储（原 TaskStore 类，改名 VlmTaskStore）
# ---------------------------------------------------------------------------


class VlmTaskStore:
    """基于内存字典的任务状态存储（VLM / Excel 流程）。

    使用 dict 存储任务，key 为 task_id（UUID）。
    提供 create_task、get_task、update_task 方法。
    """

    def __init__(self) -> None:
        self._tasks: dict[str, TaskInfo] = {}

    def create_task(self, filename: str) -> TaskInfo:
        """创建新任务，生成唯一 UUID 作为 task_id。

        Args:
            filename: 上传的文件名。

        Returns:
            新创建的 TaskInfo 实例。
        """
        task_id = str(uuid.uuid4())
        task = TaskInfo(
            task_id=task_id,
            filename=filename,
            created_at=datetime.now(timezone.utc),
        )
        self._tasks[task_id] = task
        return task

    def get_task(self, task_id: str) -> TaskInfo | None:
        """根据 task_id 获取任务。

        Args:
            task_id: 任务唯一标识。

        Returns:
            TaskInfo 实例，不存在时返回 None。
        """
        return self._tasks.get(task_id)

    def update_task(self, task_id: str, **kwargs: Any) -> TaskInfo | None:
        """更新任务字段。

        支持更新 TaskInfo 上的任意字段。当 status 变为终态
        （COMPLETED / FAILED）时自动记录 completed_at。

        Args:
            task_id: 任务唯一标识。
            **kwargs: 要更新的字段及其值。

        Returns:
            更新后的 TaskInfo 实例，任务不存在时返回 None。
        """
        task = self._tasks.get(task_id)
        if task is None:
            return None

        for key, value in kwargs.items():
            if hasattr(task, key):
                setattr(task, key, value)

        # 自动记录终态时间戳
        if task.status in (TaskStatus.COMPLETED, TaskStatus.FAILED) and task.completed_at is None:
            task.completed_at = datetime.now(timezone.utc)

        return task


# ---------------------------------------------------------------------------
# 2) SAP / MCP 异步任务存储（新增，对齐 design.md §7.2）
# ---------------------------------------------------------------------------


class TaskStore(Protocol):
    """SAP / MCP 异步任务存储抽象接口。

    任务以 dict 形式暴露，便于前端 JSON 序列化与实时字段增量更新。
    同一进程内 FastAPI 路由与 MCP Server 各自实例化一份
    ``InMemoryTaskStore``，**不共享**（见 requirements R18.7）。
    """

    def create_task(
        self,
        case_id: str,
        case_data: dict,
        task_type: str = "case",
    ) -> str:
        """创建新任务，返回 task_id。"""
        ...

    def get_task(self, task_id: str) -> dict | None:
        """按 task_id 查询任务 dict（返回活引用，调用方可原地修改）。"""
        ...

    def update_task(self, task_id: str, **fields: Any) -> dict | None:
        """批量更新任务字段。"""
        ...

    def list_recent(self, limit: int = 20) -> list[dict]:
        """按 created_at 降序返回最近 ``limit`` 个任务。"""
        ...

    def count_running(self) -> int:
        """统计当前处于 ``running`` 状态的任务数。"""
        ...

    def register_executor(self, task_id: str, executor: Any) -> None:
        """登记正在执行的 executor（如 ScriptExecutor），不序列化。"""
        ...

    def pop_executor(self, task_id: str) -> Any | None:
        """移除并返回已登记的 executor；不存在时返回 None。"""
        ...


class InMemoryTaskStore:
    """基于进程内字典的 ``TaskStore`` 默认实现。

    - 任务以 dict 存储，``get_task`` 返回活引用，调用方可直接
      ``task["status"] = ...`` 原地修改（保持现有 ``sap_routes.py`` 的使用习惯）
    - executor 另存 ``_executors`` dict；不随任务 JSON 序列化
    - 内部使用 ``RLock`` 保护 dict 级并发；task 内字段的并发修改仍由调用方协调
    """

    def __init__(self) -> None:
        self._tasks: dict[str, dict] = {}
        self._executors: dict[str, Any] = {}
        self._lock = RLock()

    # ---- Tasks ---------------------------------------------------------

    def create_task(
        self,
        case_id: str,
        case_data: dict,
        task_type: str = "case",
    ) -> str:
        """创建任务并返回 task_id。

        初始化后的 dict 字段与原 ``sap_routes.py`` 内联创建保持一致，
        确保 FastAPI 对前端 Vue 的 JSON 契约零变更。
        """
        task_id = uuid.uuid4().hex[:12]
        now_iso = datetime.now().isoformat()
        task: dict[str, Any] = {
            "task_id": task_id,
            "case_id": case_id,
            "type": task_type,
            "status": "queued",
            "case_data": case_data,
            "logs": [],
            "step_results": [],
            "steps_plan": [],
            "generated_script": None,
            "result": None,
            "error": None,
            "created_at": now_iso,
            "started_at": None,
            "completed_at": None,
        }
        with self._lock:
            self._tasks[task_id] = task
        return task_id

    def get_task(self, task_id: str) -> dict | None:
        with self._lock:
            return self._tasks.get(task_id)

    def update_task(self, task_id: str, **fields: Any) -> dict | None:
        with self._lock:
            task = self._tasks.get(task_id)
            if task is None:
                return None
            task.update(fields)
            return task

    def list_recent(self, limit: int = 20) -> list[dict]:
        with self._lock:
            tasks = list(self._tasks.values())
        tasks.sort(key=lambda t: t.get("created_at") or "", reverse=True)
        return tasks[:limit]

    def count_running(self) -> int:
        with self._lock:
            return sum(1 for t in self._tasks.values() if t.get("status") == "running")

    # ---- Executors -----------------------------------------------------

    def register_executor(self, task_id: str, executor: Any) -> None:
        with self._lock:
            self._executors[task_id] = executor

    def pop_executor(self, task_id: str) -> Any | None:
        with self._lock:
            return self._executors.pop(task_id, None)
