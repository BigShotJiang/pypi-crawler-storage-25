"""屏幕录制器 - 使用 ffmpeg 录制执行过程，支持 macOS 和 Windows"""

import asyncio
import logging
import os
import platform
import shutil

logger = logging.getLogger(__name__)


class ScreenRecorder:
    """跨平台屏幕录制器，基于 ffmpeg。"""

    def __init__(self) -> None:
        self._process: asyncio.subprocess.Process | None = None
        self._output_path: str = ""

    @staticmethod
    def is_available() -> bool:
        """检查 ffmpeg 是否可用。"""
        return shutil.which("ffmpeg") is not None

    def _build_cmd(self, output_path: str) -> list[str]:
        """根据操作系统构建 ffmpeg 录屏命令。"""
        system = platform.system()

        if system == "Darwin":
            # macOS: 使用 avfoundation 捕获屏幕
            # 设备索引通过 ffmpeg -f avfoundation -list_devices true -i "" 查看
            # "Capture screen 0" 通常是索引 2（0/1 是摄像头）
            screen_index = os.environ.get("FFMPEG_SCREEN_INDEX", "2")
            return [
                "ffmpeg", "-y",
                "-f", "avfoundation",
                "-framerate", "10",
                "-capture_cursor", "1",
                "-i", f"{screen_index}:none",
                "-c:v", "libx264",
                "-preset", "ultrafast",
                "-crf", "28",
                "-pix_fmt", "yuv420p",
                output_path,
            ]
        elif system == "Windows":
            # Windows: 使用 gdigrab 捕获桌面
            return [
                "ffmpeg", "-y",
                "-f", "gdigrab",
                "-framerate", "10",
                "-i", "desktop",
                "-c:v", "libx264",
                "-preset", "ultrafast",
                "-crf", "28",
                "-pix_fmt", "yuv420p",
                output_path,
            ]
        else:
            # Linux: 使用 x11grab
            return [
                "ffmpeg", "-y",
                "-f", "x11grab",
                "-framerate", "10",
                "-video_size", "1920x1080",
                "-i", ":0.0",
                "-c:v", "libx264",
                "-preset", "ultrafast",
                "-crf", "28",
                "-pix_fmt", "yuv420p",
                output_path,
            ]

    async def start(self, output_path: str) -> bool:
        """开始录屏。返回是否成功启动。"""
        if not self.is_available():
            logger.warning("ffmpeg not found, screen recording disabled")
            return False

        self._output_path = output_path
        cmd = self._build_cmd(output_path)
        logger.info("Starting screen recording: %s", output_path)

        try:
            self._process = await asyncio.create_subprocess_exec(
                *cmd,
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.PIPE,
            )
            # 等一小会确认进程没有立即退出
            await asyncio.sleep(1)
            if self._process.returncode is not None:
                stderr = await self._process.stderr.read() if self._process.stderr else b""
                logger.warning("ffmpeg exited immediately (code=%d): %s",
                               self._process.returncode,
                               stderr.decode(errors="replace")[:500])
                self._process = None
                return False
            logger.info("Screen recording started (pid=%d)", self._process.pid)
            return True
        except Exception as e:
            logger.warning("Failed to start screen recording: %s", e)
            self._process = None
            return False

    async def stop(self) -> str | None:
        """停止录屏。返回录制文件路径，失败返回 None。"""
        if self._process is None:
            return None

        logger.info("Stopping screen recording...")
        try:
            # 发送 'q' 让 ffmpeg 优雅退出
            if self._process.stdin:
                self._process.stdin.write(b"q")
                await self._process.stdin.drain()

            try:
                await asyncio.wait_for(self._process.wait(), timeout=10)
            except asyncio.TimeoutError:
                self._process.kill()
                await self._process.wait()

            logger.info("Screen recording saved: %s", self._output_path)
            self._process = None
            return self._output_path
        except Exception as e:
            logger.warning("Error stopping screen recording: %s", e)
            if self._process and self._process.returncode is None:
                self._process.kill()
            self._process = None
            return self._output_path if self._output_path else None
