"""桌面应用：按步骤「打开/启动」时，检测进程、复用窗口或启动新实例（Windows 为主，macOS 兼容）。"""

from __future__ import annotations

import logging
import os
import platform
import re
import subprocess
import sys
import time
from typing import Any

logger = logging.getLogger(__name__)

# 仅当步骤描述较短且明显为「打开某应用」时解析，避免与业务长句混淆
_MAX_LAUNCH_STEP_LEN = 120

# 中文 / 英文：打开 Excel、请先启动 Outlook、open Word、launch SAP GUI
_RE_LAUNCH_ZH = re.compile(
    r"(?:请\s*(?:先\s*)?)?(?:打开|启动|运行)\s*(?:应用|程序|软件)?\s*(?:Microsoft|微软|MS)?\s*"
    r"(Excel|Outlook|Word|SAP\s*GUI|SAP)\b",
    re.IGNORECASE,
)
_RE_LAUNCH_EN = re.compile(
    r"(?:open|launch|start)\s+(?:app\s+)?(?:Microsoft\s+)?(Excel|Outlook|Word|SAP\s*GUI|SAP)\b",
    re.IGNORECASE,
)

# Windows：进程名（小写比较）与启动方式
# start 命令依赖系统 PATH / App Paths 注册；SAP 可配置 SAP_LOGON_EXE
_WIN_APPS: dict[str, dict[str, Any]] = {
    "excel": {
        "exe_names": ("EXCEL.EXE",),
        "start_cmd": ["cmd", "/c", "start", "", "excel"],
    },
    "outlook": {
        "exe_names": ("OUTLOOK.EXE",),
        "start_cmd": ["cmd", "/c", "start", "", "outlook"],
    },
    "word": {
        "exe_names": ("WINWORD.EXE",),
        "start_cmd": ["cmd", "/c", "start", "", "winword"],
    },
    "sap": {
        "exe_names": ("saplogon.exe", "saplgpad.exe", "sapfront.exe", "sapguiserver.exe"),
        "start_cmd": None,  # 见 _start_sap_windows
    },
}

# macOS：`open -a` 的应用名（Office）；SAP 用 config.TARGET_APP_PROCESS + AppleScript
_DARWIN_OPEN_A = {
    "excel": "Microsoft Excel",
    "outlook": "Microsoft Outlook",
    "word": "Microsoft Word",
}


def _normalize_app_key(fragment: str) -> str | None:
    t = fragment.strip().lower().replace(" ", "")
    if "sap" in t:
        return "sap"
    if t in ("excel",):
        return "excel"
    if t in ("outlook",):
        return "outlook"
    if t in ("word",):
        return "word"
    return None


def parse_desktop_launch(step_desc: str) -> str | None:
    """若本步为「打开/启动某桌面应用」，返回应用键 excel|outlook|word|sap；否则 None。"""
    s = (step_desc or "").strip()
    if not s or len(s) > _MAX_LAUNCH_STEP_LEN:
        return None
    for rx in (_RE_LAUNCH_ZH, _RE_LAUNCH_EN):
        m = rx.search(s)
        if m:
            return _normalize_app_key(m.group(1))
    return None


def _pids_for_exe_names(exe_names: tuple[str, ...]) -> list[int]:
    import psutil

    want = {n.lower() for n in exe_names}
    out: list[int] = []
    for proc in psutil.process_iter(["pid", "name"]):
        try:
            name = proc.info.get("name") or ""
            if name.lower() in want:
                out.append(int(proc.info["pid"]))
        except (psutil.NoSuchProcess, psutil.AccessDenied, TypeError, ValueError):
            continue
    return out


def _creation_flags() -> int:
    if sys.platform != "win32":
        return 0
    # Python 3.7+ Windows：减少闪出控制台窗口
    try:
        return subprocess.CREATE_NO_WINDOW  # type: ignore[attr-defined]
    except AttributeError:
        return 0


def _bring_pid_to_foreground_windows(pid: int) -> bool:
    import ctypes
    from ctypes import wintypes

    user32 = ctypes.windll.user32
    SW_RESTORE = 9
    found: list[int] = []

    @ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
    def _enum(hwnd, _lp):
        if not user32.IsWindowVisible(hwnd):
            return True
        p = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(p))
        if int(p.value) == pid:
            found.append(int(hwnd))
        return True

    user32.EnumWindows(_enum, 0)
    if not found:
        return False
    hwnd = found[0]
    user32.ShowWindow(hwnd, SW_RESTORE)
    user32.SetForegroundWindow(hwnd)
    return True


def _start_sap_windows() -> bool:
    from app.config import SAP_LOGON_EXE

    cf = _creation_flags()
    if SAP_LOGON_EXE and os.path.isfile(SAP_LOGON_EXE):
        subprocess.Popen([SAP_LOGON_EXE], creationflags=cf)
        return True
    # 依赖 PATH 或开始菜单中的 saplogon
    try:
        subprocess.Popen(
            ["cmd", "/c", "start", "", "saplogon"],
            creationflags=cf,
        )
        return True
    except OSError:
        pass
    return False


def ensure_windows_app(app_key: str) -> str:
    """检测进程：有则置前，无则启动。返回写入 step_logs 的一行说明。"""
    meta = _WIN_APPS.get(app_key)
    if not meta:
        return f"  ⚠ 未识别的应用: {app_key}"

    exe_names: tuple[str, ...] = meta["exe_names"]
    pids = _pids_for_exe_names(exe_names)
    label = app_key.upper()

    if pids:
        ok = _bring_pid_to_foreground_windows(pids[0])
        if ok:
            logger.info("Windows: 复用已有进程 %s pid=%s，已尝试置前", label, pids[0])
            return f"  ✓ Windows: 检测到 {label} 已在运行 (pid={pids[0]})，已切换至前台"
        logger.warning("Windows: 找到进程但置前失败 %s pid=%s", label, pids[0])
        return f"  ⚠ Windows: {label} 已在运行 (pid={pids[0]})，但无法置前窗口（请手动点选窗口）"

    logger.info("Windows: 未检测到 %s，尝试启动", label)
    if app_key == "sap":
        started = _start_sap_windows()
        if not started:
            return (
                "  ❌ Windows: 未找到 SAP GUI 进程，且无法启动。"
                "请在 config 中设置 SAP_LOGON_EXE 为 saplogon.exe 完整路径，"
                "或自行打开 SAP Logon 后重试。"
            )
        time.sleep(2.5)
        pids2 = _pids_for_exe_names(exe_names)
        if pids2:
            _bring_pid_to_foreground_windows(pids2[0])
        return "  ✓ Windows: 已启动 SAP Logon / SAP GUI，请按需登录并置前窗口"

    start_cmd = meta.get("start_cmd")
    if not start_cmd:
        return f"  ❌ Windows: 未配置 {label} 的启动命令"

    try:
        subprocess.Popen(start_cmd, creationflags=_creation_flags())
    except OSError as e:
        logger.exception("启动 %s 失败", label)
        return f"  ❌ Windows: 启动 {label} 失败: {e}"

    time.sleep(2.0)
    pids2 = _pids_for_exe_names(exe_names)
    if pids2:
        _bring_pid_to_foreground_windows(pids2[0])
        return f"  ✓ Windows: 已启动 {label} (pid={pids2[0]}) 并尝试置前"
    return f"  ✓ Windows: 已发出启动 {label} 命令；若未出现窗口请检查是否已安装 Office"


def ensure_darwin_app(app_key: str) -> str:
    """macOS：`open -a` 会在已运行时置前，未运行时启动。"""
    from app.config import TARGET_APP_PROCESS

    if app_key == "sap":
        script = f'''
tell application "System Events"
    try
        set targetProc to first process whose name is "{TARGET_APP_PROCESS}"
        set frontmost of targetProc to true
    end try
end tell
'''
        try:
            subprocess.run(
                ["osascript", "-e", script],
                capture_output=True,
                timeout=15,
                check=False,
            )
        except OSError as e:
            return f"  ⚠ macOS: 无法激活 SAP ({e})"
        time.sleep(1.0)
        return f"  ✓ macOS: 已尝试将 {TARGET_APP_PROCESS} 置前（若未运行请先手动打开 SAP GUI）"

    app_name = _DARWIN_OPEN_A.get(app_key)
    if not app_name:
        return f"  ⚠ macOS: 不支持的应用 {app_key}"

    try:
        subprocess.run(["open", "-a", app_name], timeout=120, check=False)
    except OSError as e:
        return f"  ❌ macOS: open -a 失败: {e}"
    time.sleep(1.5)
    return f"  ✓ macOS: 已执行 open -a \"{app_name}\"（已运行则置前）"


def ensure_desktop_app(app_key: str) -> str:
    """同步入口：按平台调度。"""
    system = platform.system()
    if system == "Windows":
        return ensure_windows_app(app_key)
    if system == "Darwin":
        return ensure_darwin_app(app_key)
    return f"  ⚠ 当前系统 ({system}) 不支持自动打开/置前桌面应用，请手动切换窗口"
