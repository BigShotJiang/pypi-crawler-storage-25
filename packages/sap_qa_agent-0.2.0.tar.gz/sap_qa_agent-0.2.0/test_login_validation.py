"""登录测试用例验证脚本

验证：
1. Markdown 解析 → TestCase
2. 字段提取（事务码、FlowVariable、依赖）
3. GLM 步骤拆分（真实 API 调用）
4. 凭证号提取逻辑
"""

import asyncio
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))

from app.core.test_case_parser import TestCaseParser
from app.data.models import TestCaseType


def separator(title: str):
    print(f"\n{'='*60}")
    print(f"  {title}")
    print(f"{'='*60}")


def check(label: str, condition: bool, detail: str = ""):
    status = "✅ PASS" if condition else "❌ FAIL"
    msg = f"  {status} | {label}"
    if detail:
        msg += f" — {detail}"
    print(msg)
    return condition


async def main():
    test_case_path = os.path.join(
        os.path.dirname(os.path.dirname(__file__)),
        "test_case",
        "SAP_GUI_登录测试用例.md",
    )

    all_passed = True

    # ================================================================
    # 1. 用例解析
    # ================================================================
    separator("1. 登录用例 Markdown 解析")

    parser = TestCaseParser()
    cases = parser.parse_markdown(test_case_path)

    all_passed &= check("解析到用例", len(cases) == 1, f"实际: {len(cases)} 个")

    if not cases:
        print("  解析失败，终止验证")
        return 1

    tc = cases[0]
    print(f"\n  用例详情:")
    print(f"    编号: {tc.case_id}")
    print(f"    目的: {tc.purpose[:60]}...")
    print(f"    事务码: {tc.transaction_code}")
    print(f"    类型: {tc.case_type.value}")
    print(f"    FlowVar: {[fv.name for fv in tc.flow_variable_defs]}")
    print(f"    依赖: {tc.dependencies}")
    print(f"    预期结果: {len(tc.expected_results)} 条")
    print(f"    测试数据: {tc.test_data}")
    print(f"    操作步骤前100字: {tc.steps_text[:100]}...")

    # ================================================================
    # 2. 字段验证
    # ================================================================
    separator("2. 字段验证")

    all_passed &= check("用例编号", tc.case_id == "LOGIN-001", f"实际: {tc.case_id}")
    all_passed &= check("用例类型为 NORMAL", tc.case_type == TestCaseType.NORMAL)

    missing = parser.validate(tc)
    all_passed &= check("必填字段完整", len(missing) == 0,
                       f"缺失: {missing}" if missing else "")

    all_passed &= check("有预期结果", len(tc.expected_results) > 0,
                       f"{len(tc.expected_results)} 条")

    all_passed &= check("测试数据包含用户", "用户" in str(tc.test_data) or "ZHOUXINYIN" in str(tc.test_data),
                       f"数据: {tc.test_data}")

    all_passed &= check("操作步骤非空", len(tc.steps_text) > 50,
                       f"长度: {len(tc.steps_text)}")

    # ================================================================
    # 3. GLM 步骤拆分（真实 API 调用）
    # ================================================================
    separator("3. GLM 步骤拆分（真实 API 调用）")

    try:
        from app.ai.glm_client import GlmClient
        from app.ai.prompt_manager import PromptManager
        from app.core.step_splitter import StepSplitter

        glm = GlmClient()
        pm = PromptManager()
        splitter = StepSplitter(glm, pm)

        print("  正在调用 GLM API 拆分步骤...")
        steps = await splitter.split(tc)

        all_passed &= check("GLM 返回步骤", len(steps) > 0, f"共 {len(steps)} 步")

        print(f"\n  拆分结果 ({len(steps)} 步):")
        for s in steps:
            var_info = f" [FlowVar: {s.flow_variable_ref}]" if s.flow_variable_ref else ""
            print(f"    Step {s.index}: [{s.action_type.value:8s}] {s.target_description}"
                  f"{' = ' + s.value if s.value else ''}{var_info}")

        # 验证步骤合理性
        action_types = [s.action_type.value for s in steps]
        all_passed &= check("包含 input 类型步骤", "input" in action_types,
                           f"类型: {action_types}")
        all_passed &= check("包含 click 类型步骤", "click" in action_types,
                           f"类型: {action_types}")

        # 检查是否包含用户名输入步骤
        has_user_input = any(
            "ZHOUXINYIN" in (s.value or "") or "用户" in s.target_description
            for s in steps
        )
        all_passed &= check("包含用户名输入步骤", has_user_input)

    except ImportError as e:
        print(f"  ⚠️ 跳过 GLM 测试（依赖缺失: {e}）")
    except Exception as e:
        all_passed &= check("GLM API 调用", False, f"错误: {e}")

    # ================================================================
    # 总结
    # ================================================================
    separator("验证总结")
    if all_passed:
        print("  🎉 登录测试用例验证全部通过！")
    else:
        print("  ⚠️ 部分验证项未通过，请检查上方 ❌ 项目。")

    return 0 if all_passed else 1


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
