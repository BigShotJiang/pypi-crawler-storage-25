"""端到端逻辑验证脚本

逐步验证整个框架的逻辑链路：
1. 用例解析（Markdown → TestCase）
2. 字段提取（事务码、FlowVariable、依赖关系）
3. 步骤拆分（GLM 调用）
4. 模板匹配（知识库查询）
5. 依赖图构建与拓扑排序
6. FlowVariable 传递
7. 预期结果验证（含 Expected_Failure）
8. 报告生成
"""

import asyncio
import json
import os
import sys
import tempfile

# 确保项目根目录在 path 中
sys.path.insert(0, os.path.dirname(__file__))

from app.core.test_case_parser import TestCaseParser
from app.core.orchestrator import DependencyGraph
from app.data.flow_variable import FlowVariableContext
from app.data.knowledge_base import KnowledgeBase
from app.data.models import (
    ExecutionMode, StepResult, TestCase, TestCaseType,
    TestCaseResult, TestSuiteResult, VerificationResult,
)
from app.data.report_generator import ReportGenerator
from app.core.template_matcher import TemplateMatcher
from app.core.result_verifier import ResultVerifier


def separator(title: str):
    print(f"\n{'='*60}")
    print(f"  {title}")
    print(f"{'='*60}")


def check(label: str, condition: bool, detail: str = ""):
    status = "✅ PASS" if condition else "❌ FAIL"
    msg = f"  {status} | {label}"
    if detail:
        msg += f" — {detail}"
    print(msg)
    return condition


def main():
    test_case_path = os.path.join(
        os.path.dirname(os.path.dirname(__file__)),
        "test_case",
        "SAP Public Cloud 2602版本 BD9从库存销售流程测试用例V1.0.md",
    )

    if not os.path.exists(test_case_path):
        # 尝试相对路径
        test_case_path = os.path.join(
            os.path.dirname(__file__), "..",
            "test_case",
            "SAP Public Cloud 2602版本 BD9从库存销售流程测试用例V1.0.md",
        )

    all_passed = True

    # ================================================================
    # 1. 用例解析
    # ================================================================
    separator("1. Markdown 用例解析")

    parser = TestCaseParser()
    cases = parser.parse_markdown(test_case_path)

    all_passed &= check("解析到用例数量", len(cases) >= 5, f"实际: {len(cases)} 个")

    print(f"\n  解析到的用例列表:")
    for tc in cases:
        print(f"    {tc.case_id}: {tc.purpose[:40]}...")
        print(f"      事务码: {tc.transaction_code}")
        print(f"      FlowVar定义: {[fv.name for fv in tc.flow_variable_defs]}")
        print(f"      依赖: {tc.dependencies}")
        print(f"      预期结果数: {len(tc.expected_results)}")
        print(f"      测试数据: {tc.test_data}")

    # ================================================================
    # 2. 字段提取验证
    # ================================================================
    separator("2. 字段提取验证")

    case_map = {tc.case_id: tc for tc in cases}

    # 用例1: VA01
    if "BD9-2602-001" in case_map:
        tc1 = case_map["BD9-2602-001"]
        all_passed &= check("用例1 事务码提取", tc1.transaction_code == "VA01",
                           f"实际: {tc1.transaction_code}")
        all_passed &= check("用例1 有 FlowVariable 定义",
                           len(tc1.flow_variable_defs) > 0,
                           f"实际: {[fv.name for fv in tc1.flow_variable_defs]}")
        all_passed &= check("用例1 有预期结果", len(tc1.expected_results) > 0,
                           f"实际: {len(tc1.expected_results)} 条")
    else:
        all_passed &= check("用例1 存在", False, "BD9-2602-001 未找到")

    # 用例2: VA02 + 依赖
    if "BD9-2602-002" in case_map:
        tc2 = case_map["BD9-2602-002"]
        all_passed &= check("用例2 事务码提取", tc2.transaction_code == "VA02",
                           f"实际: {tc2.transaction_code}")
        all_passed &= check("用例2 有依赖关系", len(tc2.dependencies) > 0,
                           f"实际: {tc2.dependencies}")
    else:
        all_passed &= check("用例2 存在", False, "BD9-2602-002 未找到")

    # 用例3: VL01N
    if "BD9-2602-003" in case_map:
        tc3 = case_map["BD9-2602-003"]
        all_passed &= check("用例3 事务码提取",
                           tc3.transaction_code in ("VL01N", "VL01", "F0869"),
                           f"实际: {tc3.transaction_code}")
    else:
        all_passed &= check("用例3 存在", False, "BD9-2602-003 未找到")

    # 用例5: VF01
    if "BD9-2602-005" in case_map:
        tc5 = case_map["BD9-2602-005"]
        all_passed &= check("用例5 事务码提取", tc5.transaction_code == "VF01",
                           f"实际: {tc5.transaction_code}")
    else:
        all_passed &= check("用例5 存在", False, "BD9-2602-005 未找到")

    # ================================================================
    # 3. 必填字段验证
    # ================================================================
    separator("3. 必填字段验证")

    for tc in cases:
        missing = parser.validate(tc)
        all_passed &= check(f"{tc.case_id} 必填字段完整",
                           len(missing) == 0,
                           f"缺失: {missing}" if missing else "")

    # ================================================================
    # 4. 依赖图构建与拓扑排序
    # ================================================================
    separator("4. 依赖图与拓扑排序")

    from app.data.models import TestSuite
    suite = TestSuite(suite_id="BD9-2602", name="BD9从库存销售", test_cases=cases)
    dep_graph = DependencyGraph(suite)

    errors = dep_graph.validate()
    # Filter out __case_ref_ warnings (these are "用例N执行成功" references, not real errors)
    real_errors = [e for e in errors if "__case_ref_" not in e]
    all_passed &= check("依赖图无严重错误", len(real_errors) == 0,
                       f"错误: {real_errors}" if real_errors else "")

    order = dep_graph.get_execution_order()
    all_passed &= check("拓扑排序包含所有用例", len(order) == len(cases),
                       f"排序: {order} (共{len(order)}个, 期望{len(cases)}个)")

    print(f"\n  执行顺序: {' → '.join(order)}")

    # 验证依赖顺序正确性
    if "BD9-2602-001" in order and "BD9-2602-002" in order:
        all_passed &= check("用例1 在用例2 之前",
                           order.index("BD9-2602-001") < order.index("BD9-2602-002"))

    # ================================================================
    # 5. FlowVariable 传递模拟
    # ================================================================
    separator("5. FlowVariable 传递模拟")

    flow = FlowVariableContext()

    # 模拟用例1执行后提取订单号
    flow.set("ORDER_NO", "0000012345")
    all_passed &= check("设置 ORDER_NO", flow.get("ORDER_NO") == "0000012345")

    # 模拟用例3执行后提取交货单号
    flow.set("DELIVERY_NO", "0080012345")
    all_passed &= check("设置 DELIVERY_NO", flow.get("DELIVERY_NO") == "0080012345")

    # 模拟用例5中引用交货单号
    resolved = flow.resolve("输入交货单号：${DELIVERY_NO}")
    all_passed &= check("解析 ${DELIVERY_NO}",
                       "0080012345" in resolved,
                       f"结果: {resolved}")

    # 测试缺失变量
    try:
        flow.resolve("${MISSING_VAR}")
        all_passed &= check("缺失变量抛异常", False, "应该抛出 KeyError")
    except KeyError:
        all_passed &= check("缺失变量抛异常", True)

    print(f"\n  FlowVariable 上下文: {flow.to_dict()}")

    # ================================================================
    # 6. 模板匹配逻辑
    # ================================================================
    separator("6. 模板匹配逻辑")

    with tempfile.TemporaryDirectory() as tmp_dir:
        kb = KnowledgeBase(storage_path=tmp_dir)
        matcher = TemplateMatcher(kb)

        # 首次查询 — 应进入探索模式
        result = matcher.match("VA01", "default")
        all_passed &= check("首次查询 → 探索模式",
                           result.mode == "exploration",
                           f"mode={result.mode}")

        # 模拟保存模板
        from app.data.models import ScriptTemplate, TemplateConfidence
        tpl = ScriptTemplate(
            template_id="tpl_va01_001",
            transaction_code="VA01",
            scenario_type="default",
            script_content="# test",
            element_path_map={},
            parameters=[],
            confidence=TemplateConfidence.DRAFT,
        )
        kb.save_template(tpl)

        # 再次查询 — 应进入复用模式（DRAFT 带警告）
        result = matcher.match("VA01", "default")
        all_passed &= check("有模板(DRAFT) → 复用模式+警告",
                           result.mode == "reuse" and result.confidence_warning is not None,
                           f"mode={result.mode}, warning={result.confidence_warning}")

        # 升级到 STABLE
        for _ in range(3):
            kb.update_confidence("tpl_va01_001", success=True)
        result = matcher.match("VA01", "default")
        all_passed &= check("STABLE 模板 → 复用模式无警告",
                           result.mode == "reuse" and result.confidence_warning is None,
                           f"mode={result.mode}")

        # 失败降级
        kb.update_confidence("tpl_va01_001", success=False)
        result = matcher.match("VA01", "default")
        all_passed &= check("失败后降级 → 仍可复用(DRAFT)",
                           result.mode == "reuse",
                           f"mode={result.mode}")

    # ================================================================
    # 7. 预期结果验证（含 Expected_Failure）
    # ================================================================
    separator("7. 预期结果验证")

    from unittest.mock import MagicMock
    verifier = ResultVerifier(MagicMock())

    # 正常用例 — 状态栏匹配（含 XXXXXXXX 通配符）
    normal_case = TestCase(
        case_id="TC-NORMAL", purpose="test", preconditions="",
        steps_text="", test_data={},
        expected_results=["销售订单 XXXXXXXX 已创建"],
        ai_notes="", case_type=TestCaseType.NORMAL,
    )
    step_results = [
        StepResult(step_index=0, success=True,
                  status_bar_message="销售订单 0000012345 已创建"),
    ]
    vr = verifier.verify_expected_results(normal_case, step_results)
    all_passed &= check("正常用例 — XXXXXXXX 通配符匹配",
                       len(vr) > 0 and vr[0].passed,
                       f"结果: {vr[0].passed if vr else 'N/A'}, actual={vr[0].actual_value if vr else 'N/A'}")

    # Expected_Failure — 错误出现 = PASS
    ef_case = TestCase(
        case_id="TC-EF", purpose="test", preconditions="",
        steps_text="", test_data={},
        expected_results=["交货单未发货"],
        ai_notes="", case_type=TestCaseType.EXPECTED_FAILURE,
    )
    ef_results = [
        StepResult(step_index=0, success=False,
                  error_message="交货单未发货，无法创建开票文档"),
    ]
    vr_ef = verifier.verify_expected_results(ef_case, ef_results)
    all_passed &= check("Expected_Failure — 错误出现 = PASS",
                       len(vr_ef) > 0 and vr_ef[0].passed,
                       f"结果: {vr_ef[0].passed if vr_ef else 'N/A'}")

    # Expected_Failure — 意外成功 = FAIL
    ef_success_results = [
        StepResult(step_index=0, success=True,
                  status_bar_message="开票文档已创建"),
    ]
    vr_ef2 = verifier.verify_expected_results(ef_case, ef_success_results)
    all_passed &= check("Expected_Failure — 意外成功 = FAIL",
                       len(vr_ef2) > 0 and not vr_ef2[0].passed,
                       f"结果: {vr_ef2[0].passed if vr_ef2 else 'N/A'}")

    # ================================================================
    # 8. 凭证号提取
    # ================================================================
    separator("8. 凭证号提取")

    from app.sap.script_executor import ScriptExecutor
    executor = ScriptExecutor(MagicMock(), MagicMock())

    test_messages = [
        ("销售订单 0000012345 已创建", "0000012345"),
        ("外向交货单 0080012345 已创建", "0080012345"),
        ("开票文档 0090012345 已创建", "0090012345"),
        ("Sales Order 0000054321 has been saved", "0000054321"),
        ("没有凭证号的消息", None),
    ]
    for msg, expected in test_messages:
        result = executor.extract_document_number(msg)
        passed = result == expected
        all_passed &= check(f"提取: '{msg[:30]}...'",
                           passed,
                           f"期望={expected}, 实际={result}")

    # ================================================================
    # 9. 报告生成
    # ================================================================
    separator("9. 报告生成")

    report_gen = ReportGenerator()

    case_result = TestCaseResult(
        case_id="BD9-2602-001",
        success=True,
        execution_mode=ExecutionMode.EXPLORATION,
        step_results=[
            StepResult(step_index=0, success=True,
                      status_bar_message="销售订单 0000012345 已创建",
                      extracted_document_number="0000012345"),
        ],
        verification_results=[
            VerificationResult(description="订单已创建", passed=True,
                             expected_value="已创建", actual_value="已创建"),
        ],
        template_solidified=True,
        flow_variables_extracted={"ORDER_NO": "0000012345"},
    )

    report_data = report_gen.generate_case_report(case_result)
    all_passed &= check("报告数据生成", report_data is not None and "case_id" in report_data)

    with tempfile.NamedTemporaryFile(suffix=".html", delete=False) as f:
        html_path = f.name
    try:
        report_gen.export_html(report_data, html_path)
        html_size = os.path.getsize(html_path)
        all_passed &= check("HTML 报告导出", html_size > 100,
                           f"文件大小: {html_size} bytes")

        # 验证凭据脱敏
        with open(html_path, "r", encoding="utf-8") as f:
            html_content = f.read()
        has_password = "Niniyaft@0885" in html_content
        all_passed &= check("凭据脱敏", not has_password,
                           "密码未出现在报告中" if not has_password else "⚠️ 密码泄露!")
    finally:
        os.unlink(html_path)

    # ================================================================
    # 总结
    # ================================================================
    separator("验证总结")
    if all_passed:
        print("  🎉 所有验证项全部通过！框架逻辑正确。")
    else:
        print("  ⚠️ 部分验证项未通过，请检查上方标记为 ❌ 的项目。")

    return 0 if all_passed else 1


if __name__ == "__main__":
    sys.exit(main())
