# MCP Server 接入指南

本文档介绍如何将 SAP QA Agent 作为 MCP Server 接入 Claude Desktop、Kiro、Cursor 等支持 Model Context Protocol 的宿主 Agent。

---

## 目录

1. [概述](#概述)
2. [前置条件](#前置条件)
3. [安装](#安装)
4. [SAP Scripting 启用步骤](#sap-scripting-启用步骤)
5. [配置方式](#配置方式)
6. [Claude Desktop 接入（完整示例）](#claude-desktop-接入完整示例)
7. [Kiro 接入](#kiro-接入)
8. [Cursor 接入](#cursor-接入)
9. [使用 sap-parse-and-execute Skill](#使用-sap-parse-and-execute-skill)
10. [可用工具一览](#可用工具一览)
11. [故障排查](#故障排查)

---

## 概述

SAP QA Agent MCP Server 通过 Model Context Protocol 暴露一组 Tools、Resources 和 Prompts，让宿主 Agent 能够：

- 解析 Excel / Markdown 格式的 SAP 测试用例
- 连接 SAP GUI 并驱动自动化执行
- 查询任务状态、获取截图与报告
- 利用知识库模板加速执行
- 触发 AI 自愈修复失败步骤

MCP Server 与现有 FastAPI 后端**二选一启动**，同一主机同一时间只允许一种通道驱动 SAP GUI。

---

## 前置条件

| 项目 | 要求 |
|------|------|
| Python | 3.12+ |
| 操作系统 | Windows 10/11（SAP GUI Scripting 依赖 COM） |
| SAP GUI | 已安装并可正常登录目标系统 |
| SAP Scripting | 已启用（见下方步骤） |
| GLM API Key | 智谱 AI 密钥（用于 AI 自愈，可选但推荐） |

---

## 安装

### 方式一：pip 安装（推荐）

```bash
# 仅安装 MCP Server（默认，不含 FastAPI 后端）
pip install sap-qa-agent

# 如需同时使用 FastAPI + Vue 前端
pip install sap-qa-agent[backend]

# 安装全部依赖
pip install sap-qa-agent[all]
```

### 方式二：uv 工具安装

```bash
# 全局安装为 CLI 工具
uv tool install sap-qa-agent

# 或在项目中使用
uv pip install sap-qa-agent
```

### 方式三：从源码安装

```bash
git clone <repo-url>
cd ui_test_python
pip install -e .
```

安装完成后验证：

```bash
sap-qa-mcp --version
sap-qa-mcp --help
```

---

## SAP Scripting 启用步骤

SAP GUI Scripting 默认关闭，需要在客户端和服务端同时启用。

### 1. 客户端注册表设置（Windows）

打开注册表编辑器 (`regedit`)，确认以下键值：

```
HKEY_LOCAL_MACHINE\SOFTWARE\SAP\SAPGUI Front\SAP Frontend Server\Security
  EnableScripting = 1  (DWORD)
```

或通过 PowerShell 一键设置：

```powershell
New-ItemProperty -Path "HKLM:\SOFTWARE\SAP\SAPGUI Front\SAP Frontend Server\Security" `
  -Name "EnableScripting" -Value 1 -PropertyType DWORD -Force
```

### 2. SAP GUI 选项设置

1. 打开 SAP GUI → 菜单栏 → **自定义本地布局** (Alt+F12) → **选项**
2. 导航到 **辅助功能和脚本** → **脚本**
3. 勾选 **启用脚本**
4. 取消勾选 **在脚本连接到 SAP GUI 时通知** 和 **在脚本打开连接时通知**（避免弹窗阻塞自动化）

### 3. 服务端配置（需 Basis 管理员）

在 SAP 系统中执行事务码 `RZ11`，确认以下参数：

| 参数 | 值 |
|------|-----|
| `sapgui/user_scripting` | `TRUE` |
| `sapgui/user_scripting_disable_recording` | `FALSE` |
| `sapgui/user_scripting_force_notification` | `FALSE` |

> **注意**：如果无法修改服务端参数，仅客户端启用也可运行，但部分系统可能拒绝脚本连接。

---

## 配置方式

MCP Server 支持三种配置来源（优先级从高到低）：

### 1. 命令行参数

```bash
sap-qa-mcp --transport stdio --log-level DEBUG --enable-atomic-tools
```

### 2. 环境变量

```bash
# GLM AI 配置
export GLM_API_KEY="your-api-key-here"
export GLM_BASE_URL="https://open.bigmodel.cn/api/coding/paas/v4"
export GLM_MODEL="GLM-4"

# 路径配置
export SAP_QA_MCP_ARTIFACTS_DIR="./artifacts"
export SAP_QA_MCP_KNOWLEDGE_BASE_DIR="./knowledge_base"
export SAP_QA_MCP_UPLOAD_DIR="./uploads"

# 服务配置
export SAP_QA_MCP_AUTH_TOKEN="my-secret-token"
export SAP_QA_MCP_ENABLE_ATOMIC_TOOLS="true"
export SAP_QA_MCP_TOKEN_BUDGET="16000"
export SAP_QA_MCP_ALLOW_PATHS="C:\\Users\\me\\testcases;D:\\shared"
```

### 3. 配置文件（JSON 或 TOML）

```bash
sap-qa-mcp --config ./mcp-config.json
```

**mcp-config.json** 示例：

```json
{
  "glm_api_key": "your-api-key-here",
  "glm_model": "GLM-4",
  "knowledge_base_dir": "./knowledge_base",
  "artifacts_dir": "./artifacts",
  "upload_dir": "./uploads",
  "max_concurrent_tasks": 1,
  "enable_atomic_tools": false,
  "token_budget": 16000,
  "log_level": "INFO"
}
```

---

## Claude Desktop 接入（完整示例）

以下是在 Claude Desktop 中完整接入 SAP QA Agent MCP Server 的步骤。

### 步骤 1：安装 MCP Server

```bash
pip install sap-qa-agent
```

### 步骤 2：验证安装

```bash
sap-qa-mcp --version
# 输出: sap-qa-agent 0.1.0
```

### 步骤 3：配置 Claude Desktop

编辑 Claude Desktop 配置文件：

- **Windows**: `%APPDATA%\Claude\claude_desktop_config.json`
- **macOS**: `~/Library/Application Support/Claude/claude_desktop_config.json`

写入以下内容：

```json
{
  "mcpServers": {
    "sap-qa-agent": {
      "command": "sap-qa-mcp",
      "args": ["--log-level", "INFO"],
      "env": {
        "GLM_API_KEY": "<your-glm-api-key>",
        "SAP_QA_MCP_KNOWLEDGE_BASE_DIR": "C:\\path\\to\\knowledge_base",
        "SAP_QA_MCP_ARTIFACTS_DIR": "C:\\path\\to\\artifacts",
        "SAP_QA_MCP_UPLOAD_DIR": "C:\\path\\to\\uploads"
      }
    }
  }
}
```

> **GLM_API_KEY 获取方式**：访问 [智谱 AI 开放平台](https://open.bigmodel.cn/)，注册后在控制台创建 API Key。

### 步骤 4：重启 Claude Desktop

关闭并重新打开 Claude Desktop，在对话界面底部应能看到 MCP 工具图标，点击可查看已注册的 Tools 列表。

### 步骤 5：验证连接

在 Claude Desktop 中输入：

> 请列出所有可用的 SAP 测试 Skills

Claude 会调用 `list_skills` 工具，返回 5 个内置 Skill 的列表。

### 步骤 6：执行测试

确保 SAP GUI 已打开并登录，然后对 Claude 说：

> 请帮我解析并执行这个测试用例文件：C:\uploads\SAP_BD9_测试.xlsx

Claude 将按照 `sap-parse-and-execute` Skill 的流程自动完成解析、连接、执行和结果汇报。

---

## Kiro 接入

在 Kiro 工作区中配置 MCP Server。

### 配置文件

在项目根目录创建 `.kiro/mcp.json`（或在 Kiro 设置中添加）：

```json
{
  "mcpServers": {
    "sap-qa-agent": {
      "command": "sap-qa-mcp",
      "args": ["--log-level", "INFO"],
      "env": {
        "GLM_API_KEY": "<your-glm-api-key>",
        "SAP_QA_MCP_ARTIFACTS_DIR": "./artifacts",
        "SAP_QA_MCP_KNOWLEDGE_BASE_DIR": "./knowledge_base",
        "SAP_QA_MCP_UPLOAD_DIR": "./uploads"
      },
      "autoApprove": [
        "parse_test_case",
        "list_skills",
        "get_skill",
        "list_templates",
        "get_template",
        "sap_session_status"
      ]
    }
  }
}
```

`autoApprove` 列表中的工具为只读操作，Kiro 会自动批准调用而无需用户逐次确认。涉及 SAP 操作的工具（如 `sap_connect`、`execute_test_case`）需要用户手动确认。

---

## Cursor 接入

在 Cursor 中通过 MCP 设置添加 Server。

### 配置方式

打开 Cursor Settings → MCP Servers → Add Server，或编辑 `.cursor/mcp.json`：

```json
{
  "mcpServers": {
    "sap-qa-agent": {
      "command": "sap-qa-mcp",
      "env": {
        "GLM_API_KEY": "<your-glm-api-key>"
      }
    }
  }
}
```

配置完成后在 Cursor 的 Agent 模式中即可调用 SAP QA Agent 的工具。

---

## 使用 sap-parse-and-execute Skill

`sap-parse-and-execute` 是最常用的 Skill，覆盖"解析测试用例 → 连接 SAP → 执行 → 获取结果"的完整流程。

### 触发方式

在任意支持 MCP 的宿主 Agent 中，用自然语言描述需求即可触发：

> 帮我把 uploads/SAP_BD9_测试.xlsx 里的用例在 SAP 里跑一遍

### 典型对话流程

```
用户: 请解析并执行这个测试用例：C:\uploads\SAP_BD9_测试.xlsx

Agent: [调用 sap_session_status]
       SAP 未连接，正在建立连接...
       [调用 sap_connect]
       ✓ 已连接到 SAP 系统 (PRD/800, 用户 TESTUSER)

       [调用 parse_test_case(file_path="C:\\uploads\\SAP_BD9_测试.xlsx")]
       ✓ 解析完成：共 3 个测试用例，2 个含事务码，1 个含流程变量

       [调用 execute_test_case(case_data=..., mode="auto")]
       ✓ 任务已提交，task_id: abc123

       [轮询 get_task_status(task_id="abc123")]
       执行中... 步骤 3/8 完成

       [最终结果]
       ✓ 执行完成！8/8 步骤成功
       报告地址: sap-qa://artifacts/abc123/report.json

用户: 有截图吗？

Agent: [调用 resources/read("sap-qa://artifacts/abc123/step_3.png")]
       这是步骤 3 的截图...
```

### Skill 内部工具调用顺序

1. `sap_session_status` — 检查 SAP 连接状态
2. `sap_connect` — 建立连接（如需要）
3. `parse_test_case` — 解析测试用例文件
4. `execute_test_case` — 提交执行任务
5. `get_task_status` — 轮询直到终态
6. `resources/read` — 读取报告和截图

---

## 可用工具一览

| 工具名 | 类别 | 说明 |
|--------|------|------|
| `parse_test_case` | 解析 | 解析 Excel/Markdown 测试用例为结构化数据 |
| `sap_connect` | 会话 | 连接 SAP GUI 会话 |
| `sap_disconnect` | 会话 | 断开 SAP GUI 会话 |
| `sap_session_status` | 会话 | 查询当前 SAP 连接状态 |
| `execute_test_case` | 执行 | 提交测试用例异步执行 |
| `get_task_status` | 任务 | 查询任务执行状态与结果 |
| `list_tasks` | 任务 | 列出最近的执行任务 |
| `stop_task` | 任务 | 中止正在执行的任务 |
| `capture_screen` | 采集 | 获取当前 SAP 屏幕快照与元素信息 |
| `list_templates` | 知识库 | 列出可复用的脚本模板 |
| `get_template` | 知识库 | 获取单个模板详情 |
| `list_skills` | Skills | 列出所有可用 Skill |
| `get_skill` | Skills | 获取 Skill 完整内容 |
| `start_recording` | 录制 | 启动操作录制（仅 HTTP 模式） |
| `stop_recording` | 录制 | 停止录制并获取步骤 |
| `sap_input` | 原子* | 输入文本到指定控件 |
| `sap_click` | 原子* | 点击指定控件 |
| `sap_select` | 原子* | 选择下拉/列表项 |
| `sap_verify` | 原子* | 验证控件值 |
| `sap_read` | 原子* | 读取控件值 |
| `sap_navigate` | 原子* | 执行导航操作 |
| `sap_wait` | 原子* | 等待条件满足 |
| `sap_double_click` | 原子* | 双击指定控件 |

> *原子工具需要启动时设置 `--enable-atomic-tools` 或配置 `enable_atomic_tools: true`。

---

## 故障排查

### MCP Server 无法启动

**症状**：`sap-qa-mcp` 命令未找到

```bash
# 确认安装
pip show sap-qa-agent

# 确认 Scripts 目录在 PATH 中
python -c "import sysconfig; print(sysconfig.get_path('scripts'))"
```

### SAP 连接失败

**错误码 `SAP_GUI_NOT_RUNNING`**：

- 确认 SAP GUI (saplogon.exe) 已启动并登录
- MCP Server 不会自动启动 SAP GUI，需要用户手动打开

**错误码 `SCRIPTING_DISABLED`**：

- 按上方"SAP Scripting 启用步骤"检查注册表和 SAP GUI 选项
- 联系 Basis 管理员确认服务端参数 `sapgui/user_scripting = TRUE`

**错误码 `SAP_SESSION_OWNED_BY_OTHER_CHANNEL`**：

- 另一个进程（FastAPI 后端或另一个 MCP 实例）正在占用 SAP 会话
- 关闭占用进程后重试，或检查 `artifacts/.sap-channel.lock` 文件

### GLM API 相关

**错误码 `GLM_NOT_CONFIGURED`**：

- AI 自愈功能需要 GLM API Key
- 设置环境变量 `GLM_API_KEY` 或在配置文件中指定 `glm_api_key`
- 未配置时 MCP Server 仍可正常启动，但自愈功能不可用

### Token 截断

**响应中出现 `truncated: true`**：

- 响应体积超过 token 预算（默认 16000 token）
- 完整内容可通过 `truncation_ref` 中的 URI 使用 `resources/read` 获取
- 可通过 `--token-budget` 或环境变量 `SAP_QA_MCP_TOKEN_BUDGET` 调大（上限 64000）

### 路径权限

**错误码 `PATH_NOT_ALLOWED`**：

- MCP Server 仅允许访问白名单目录下的文件
- 默认白名单：`upload_dir`、`artifacts_dir`、`knowledge_base_dir`、`mcp_skills/`
- 使用 `--allow-path <dir>` 添加额外允许目录

### 日志查看

```bash
# 启动时指定日志文件
sap-qa-mcp --log-level DEBUG --log-file ./mcp-server.log

# 日志自动轮转：10MB/文件，保留最近 5 个
```

---

## Smoke Test 清单（Task 11.3）

本节记录 MCP Server 集成冒烟测试的验证结果。测试分为两部分：

1. **程序化验证**（无需 SAP GUI）— 通过 pytest 自动执行
2. **真实宿主 E2E 验证**（需要 SAP GUI + 宿主 Agent）— 需设置 `SAP_QA_MCP_E2E=1`

### 程序化 Smoke 清单

以下清单通过 `tests/mcp/e2e/test_smoke_checklist.py` 自动验证：

| # | 检查项 | 状态 | 说明 |
|---|--------|------|------|
| 1 | `initialize` 握手成功 | ✅ PASS | `build_mcp()` 成功构建 FastMCP 实例，`server_name="sap-qa-agent"`，`version="0.1.0"` |
| 2 | `list_skills` 命中 5 个 | ✅ PASS | 返回 `sap-parse-and-execute`、`sap-self-healing-playbook`、`sap-recording-to-testcase`、`sap-knowledge-base-reuse`、`sap-session-bootstrap` |
| 3 | `parse_test_case` 成功解析样例 | ✅ PASS | Markdown 键值表格格式测试用例成功解析为 `TestCase` 对象，`case_id`/`purpose`/`steps_text` 均正确提取 |
| 4 | 所有预期 Tools 已注册 | ✅ PASS | 15 个核心 Tools 全部注册：`parse_test_case`、`list_skills`、`get_skill`、`list_templates`、`get_template`、`sap_connect`、`sap_disconnect`、`sap_session_status`、`execute_test_case`、`get_task_status`、`list_tasks`、`stop_task`、`capture_screen`、`start_recording`、`stop_recording` |
| 5 | Skills 元数据完整 | ✅ PASS | 5 个 Skill 均含完整 front-matter（`id`/`title`/`description`/`version`/`keywords`/`required_tools`）及 5 个必需章节 |

### 运行程序化 Smoke 测试

```bash
# 在 ui_test_python/ 目录下
pytest tests/mcp/e2e/test_smoke_checklist.py -v
```

### 真实宿主 E2E Smoke 清单

以下清单需要在真实 SAP GUI 环境中手动验证（设置 `SAP_QA_MCP_E2E=1`）：

| # | 检查项 | 验证方式 | 前置条件 |
|---|--------|----------|----------|
| 1 | `initialize` 握手成功 | 宿主 Agent 显示 MCP 工具图标 | MCP Server 已配置到宿主 |
| 2 | `list_skills` 命中 5 个 | 对话中请求"列出所有 Skills" | 同上 |
| 3 | `parse_test_case` 成功解析 | 提供 Excel/Markdown 文件路径 | 文件在 `UPLOAD_DIR` 下 |
| 4 | `execute_test_case` 返回 task_id | 提交解析后的用例执行 | SAP GUI 已连接 |
| 5 | `get_task_status` 终态 `report_uri` 可读 | 轮询直到 `completed`/`failed` | 执行完成 |

#### 启用 E2E 测试

```bash
# 确保 SAP GUI 已启动并登录
export SAP_QA_MCP_E2E=1
pytest tests/mcp/e2e/ -v
```

### 测试环境信息

- **Python**: 3.13.9
- **FastMCP**: ≥0.2.0
- **pytest**: 9.0.3
- **平台**: Windows (SAP GUI Scripting 依赖 COM)
- **测试日期**: 自动化测试随 CI 持续运行

---

## 参考

- [MCP 协议规范](https://modelcontextprotocol.io/)
- [FastMCP SDK](https://github.com/jlowin/fastmcp)
- [智谱 AI 开放平台](https://open.bigmodel.cn/)
- 示例配置：[`examples/mcp/claude_desktop_config.json`](../examples/mcp/claude_desktop_config.json)
- 示例配置：[`examples/mcp/kiro_mcp.json`](../examples/mcp/kiro_mcp.json)
