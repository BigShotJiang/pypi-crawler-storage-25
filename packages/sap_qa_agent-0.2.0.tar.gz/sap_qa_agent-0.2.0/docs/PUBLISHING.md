# SAP QA Agent 发布指南

## 方式 1：发布到 PyPI（推荐）

### 前置准备

1. 注册 PyPI 账号：https://pypi.org/account/register/
2. 安装发布工具：
```bash
pip install build twine
```

### 发布步骤

```bash
cd ui_test_python

# 1. 构建
python -m build

# 2. 检查构建产物
ls dist/
# 应该看到:
#   sap_qa_agent-0.1.0-py3-none-any.whl
#   sap-qa-agent-0.1.0.tar.gz

# 3. 上传到 TestPyPI（可选，先测试）
twine upload --repository testpypi dist/*

# 4. 上传到正式 PyPI
twine upload dist/*
```

### 用户安装方式

发布后，用户可以通过以下方式安装：

```bash
pip install sap-qa-agent
```

### MCP 配置

用户安装后，在 `.kiro/settings/mcp.json` 中配置：

```json
{
  "mcpServers": {
    "sap-qa-agent": {
      "command": "sap-qa-mcp",
      "env": {
        "GLM_API_KEY": "your-api-key",
        "SAP_QA_MCP_ARTIFACTS_DIR": "/path/to/artifacts",
        "SAP_QA_MCP_KNOWLEDGE_BASE_DIR": "/path/to/knowledge_base",
        "SAP_QA_MCP_UPLOAD_DIR": "/path/to/uploads"
      }
    }
  }
}
```

---

## 方式 2：GitHub Releases

### 步骤

1. 在 GitHub 上创建 Release：
   - 标签：`v0.1.0`
   - 标题：`SAP QA Agent v0.1.0`
   - 说明：功能描述、安装方法、更新日志

2. 上传构建产物作为 Release Assets：
   - `sap-qa-agent-0.1.0.tar.gz`
   - `sap_qa_agent-0.1.0-py3-none-any.whl`

### 用户安装方式

```bash
# 从 GitHub Release 安装
pip install https://github.com/YOUR_USERNAME/sap-qa-agent/releases/download/v0.1.0/sap_qa_agent-0.1.0-py3-none-any.whl
```

---

## 方式 3：uvx 直接运行（无需安装）

如果您的包已发布到 PyPI，用户可以直接使用：

```bash
# 一次性运行，无需安装
uvx sap-qa-agent --help

# 或在 MCP 配置中使用
{
  "mcpServers": {
    "sap-qa-agent": {
      "command": "uvx",
      "args": ["sap-qa-agent"],
      "env": { ... }
    }
  }
}
```

---

## 方式 4：HTTP 传输模式（远程访问）

MCP Server 支持 HTTP 传输，可以部署到服务器供远程访问：

### 启动 HTTP 服务

```bash
# 启动 HTTP 服务（默认端口 8100）
sap-qa-mcp --transport http --port 8100 --auth-token your-secret-token
```

### 用户连接配置

```json
{
  "mcpServers": {
    "sap-qa-agent-remote": {
      "url": "http://your-server:8100/mcp",
      "headers": {
        "Authorization": "Bearer your-secret-token"
      }
    }
  }
}
```

### 部署建议

可以使用以下方式部署 HTTP 服务：
- Docker 容器
- Systemd 服务
- 云平台（AWS、Azure、阿里云等）

---

## Skills 使用方式

用户安装后，可以直接使用预置的 Skills：

### 在 Kiro 中使用

用户只需说：
- "用 sap-parse-and-execute skill 执行这个测试用例"
- "用 sap-session-bootstrap skill 连接 SAP"
- "用 sap-self-healing-playbook skill 分析失败原因"

Kiro 会自动识别并调用对应的 Skill。

### 列出所有 Skills

```bash
sap-qa-mcp list-skills
```

输出：
```
sap-knowledge-base-reuse    复用知识库模板执行测试
sap-parse-and-execute       解析并执行 SAP 测试用例
sap-recording-to-testcase   将录制操作转换为测试用例
sap-self-healing-playbook   AI 自愈故障排查手册
sap-session-bootstrap       SAP 会话连接引导
```

---

## 版本更新

更新 `pyproject.toml` 中的版本号：

```toml
[project]
name = "sap-qa-agent"
version = "0.2.0"  # 更新版本
```

然后重新构建和发布。

---

## 注意事项

1. **API Key 安全**：不要在代码中硬编码 API Key，使用环境变量
2. **依赖管理**：确保 `dependencies` 列表完整
3. **平台兼容性**：当前主要支持 Windows（依赖 pywin32）
4. **文档**：发布前确保 README.md 和文档完整
