"""Execute test cases from SAP GUI测试3.md"""
import asyncio
import sys
import os

# 确保项目根目录在 Python 路径中
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app.sap.sap_gui_wrapper import SapGuiWrapper
from app.core.orchestrator import TestOrchestrator
from app.core.step_splitter import StepSplitter
from app.core.exploration_engine import ExplorationEngine
from app.core.reuse_engine import ReuseEngine
from app.core.result_verifier import ResultVerifier
from app.ai.glm_client import GlmClient
from app.ai.prompt_manager import PromptManager
from app.data.knowledge_base import KnowledgeBase
from app.data.flow_variable import FlowVariableContext
from app.data.models import TestCase, ExecutionMode, TestCaseResult, ExecutionCallbacks
from app.sap.script_executor import ScriptExecutor
from app.sap.element_path_finder import ElementPathFinder
from app.sap.vlm_fallback import VlmFallbackExecutor
from app.config import ARTIFACTS_DIR, KNOWLEDGE_BASE_DIR


# 第一个测试用例数据
case_data_1 = {
    "case_id": "TC-SD-OM-001",
    "purpose": "打开销售订单报表",
    "preconditions": "1. 客户主数据已维护",
    "steps_text": "1. 输入 VA05 事务代码 2. 在筛选界面输入订单类型：OR1 3. 点击执行 4. 显示销售订单报表",
    "test_data": {},
    "expected_results": ["销售订单报表可以打开"],
    "ai_notes": "",
    "case_type": "normal",
    "transaction_code": "VA05"
}

# 第二个测试用例数据
case_data_2 = {
    "case_id": "TC-SD-OM-002",
    "purpose": "创建采购订单",
    "preconditions": "1. 供应商主数据已维护 2. 物料主数据已维护",
    "steps_text": "1. 输入事务代码 ME21N 2. 输入订单类型：ZTNB 3. 输入供应商: 2000039 4. 在采购订单抬头输入采购组织：ZY01，采购组：HS1，公司代码: ZY01 5. 输入第一行物料：602579，数量：100，工厂: ZY01 6. 到条件页签修改第一行物料PB00条件类型的价格为：200 7. 输入第二行物料：602579，数量: 200，工厂: ZY01 8. 到条件页签修改第二行PB00物料的价格为：300 9. 保存采购订单，生成订单号码",
    "test_data": {},
    "expected_results": ["采购订单创建成功并生成订单号"],
    "ai_notes": "",
    "case_type": "normal",
    "transaction_code": "ME21N"
}


def print_log(message: str):
    """Simple log callback"""
    print(f"  {message}")


async def run_test_case(case_data: dict, case_name: str, sap: SapGuiWrapper):
    """Execute a single test case"""
    print(f"\n{'='*60}")
    print(f"执行测试用例: {case_name}")
    print(f"用例ID: {case_data['case_id']}")
    print(f"事务码: {case_data['transaction_code']}")
    print(f"{'='*60}\n")
    
    # 解析测试用例
    print("📋 解析测试用例...")
    tc = TestCase.from_dict(case_data)
    print(f"用例: {tc.case_id} — {tc.purpose[:60]}")
    
    # 初始化组件
    print("🔌 初始化组件...")
    session = sap.get_session()
    sys_name = user = ""
    try:
        if session:
            sys_name = getattr(session.Info, "SystemName", "") or ""
            user = getattr(session.Info, "User", "") or ""
    except Exception:
        pass
    print(f"✅ SAP 已连接: 系统={sys_name or '(未知)'}, 用户={user or '(未知)'}")
    
    # 创建 GLM 客户端
    glm_client = GlmClient()
    prompt_manager = PromptManager()
    
    # 创建知识库
    kb = KnowledgeBase(KNOWLEDGE_BASE_DIR)
    
    # 创建组件
    step_splitter = StepSplitter(glm_client, prompt_manager)
    
    # 先创建执行器（ExplorationEngine 需要）
    element_finder = ElementPathFinder(sap, glm_client)
    vlm_fallback = VlmFallbackExecutor()
    script_executor = ScriptExecutor(
        sap_wrapper=sap,
        vlm_fallback=vlm_fallback,
        element_finder=element_finder,
        glm_client=glm_client,
    )
    
    exploration_engine = ExplorationEngine(glm_client, script_executor, element_finder, kb)
    reuse_engine = ReuseEngine(glm_client, kb)
    result_verifier = ResultVerifier(sap)
    
    # 创建模板匹配器
    from app.core.template_matcher import TemplateMatcher
    template_matcher = TemplateMatcher(kb)
    
    # 创建流程变量上下文
    flow_var_ctx = FlowVariableContext()
    
    # 创建回调
    callbacks = ExecutionCallbacks(
        on_steps_plan=lambda steps: print_log(f"📋 计划执行 {len(steps)} 个步骤"),
        on_script_generated=lambda script: print_log(f"📝 脚本已生成"),
        on_step_result=lambda result: print_log(f"✅ 步骤 {getattr(result, 'step_index', '?')}: {'成功' if getattr(result, 'success', False) else '失败'}"),
        on_log=print_log,
    )
    
    # 创建编排器
    orchestrator = TestOrchestrator(
        step_splitter=step_splitter,
        template_matcher=template_matcher,
        exploration_engine=exploration_engine,
        reuse_engine=reuse_engine,
        result_verifier=result_verifier,
        script_executor=script_executor,
    )
    
    # 执行测试用例
    print(f"\n🚀 开始执行测试用例...")
    try:
        result = await orchestrator.execute_test_case(
            test_case=tc,
            flow_context=flow_var_ctx,
            callbacks=callbacks,
        )
        
        print(f"\n{'='*60}")
        print(f"测试用例执行完成!")
        print(f"结果: {'✅ 成功' if result.success else '❌ 失败'}")
        print(f"执行模式: {result.execution_mode.value}")
        print(f"总步骤: {len(result.step_results)}")
        
        # 统计成功/失败步骤
        success_count = sum(1 for sr in result.step_results if sr.success)
        print(f"步骤统计: {success_count}/{len(result.step_results)} 成功")
        
        if result.verification_results:
            print(f"验证结果: {len(result.verification_results)} 条")
            for v in result.verification_results:
                status = '✅ 通过' if v.passed else '⚠️ 未完全匹配'
                print(f"  - {v.description}: {status}")
                if not v.passed and v.actual_value:
                    print(f"    实际值: {v.actual_value[:100]}")
        
        print(f"模板固化: {'是' if result.template_solidified else '否'}")
        print(f"{'='*60}")
        
        return result
        
    except Exception as e:
        print(f"\n❌ 执行失败: {e}")
        import traceback
        traceback.print_exc()
        return None


async def main():
    # 连接 SAP GUI
    print("\n🔌 连接 SAP GUI...")
    sap = SapGuiWrapper()
    
    if not sap.connect(max_retries=3):
        print("❌ 无法连接 SAP GUI")
        print("请确保:")
        print("  1. SAP GUI 已打开并连接到服务器")
        print("  2. SAP GUI Scripting 已启用")
        return
    
    session = sap.get_session()
    if session:
        try:
            info = session.Info
            print(f"✅ 连接成功!")
            print(f"   系统: {getattr(info, 'SystemName', 'N/A')}")
            print(f"   用户: {getattr(info, 'User', 'N/A')}")
        except Exception as e:
            print(f"✅ 连接成功 (无法读取会话信息)")
    
    # 执行第一个测试用例
    result_1 = await run_test_case(case_data_1, "打开销售订单报表 (VA05)", sap)
    
    # 执行第二个测试用例
    # result_2 = await run_test_case(case_data_2, "创建采购订单 (ME21N)", sap)


if __name__ == '__main__':
    asyncio.run(main())
