"""启动入口 - 在 backend/ 目录下运行: python run.py

PyCharm Debug 配置:
  - Script path: backend/run.py
  - Working directory: backend/
  - Python interpreter: backend/venv/bin/python
"""

import logging
import platform

import uvicorn

# Windows 需要 ProactorEventLoop 才能使用 asyncio.create_subprocess_exec
if platform.system() == "Windows":
    import asyncio
    asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())

# 配置日志：让 app.* 的日志输出到控制台
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    datefmt="%H:%M:%S",
)

if __name__ == "__main__":
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)

