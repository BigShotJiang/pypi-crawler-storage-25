"""SAP GUI COM 连接诊断脚本

运行方式: python test_sap_com_diag.py
请确保 SAP GUI 窗口已打开（登录界面或已登录）。
"""
import ctypes
import os
import sys


def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin() != 0
    except Exception:
        return False


def main():
    print("=" * 60)
    print("SAP GUI COM 连接诊断")
    print("=" * 60)

    # 1. 环境信息
    print(f"\nPython:       {sys.version}")
    print(f"Platform:     {sys.platform}")
    print(f"管理员权限:   {'是' if is_admin() else '否'}")
    print(f"PID:          {os.getpid()}")

    # 2. 检查 win32com
    try:
        import win32com.client
        print(f"win32com:     可用")
    except ImportError:
        print("win32com:     不可用 — 请安装 pywin32")
        return

    # 3. 检查 SAP GUI 进程
    try:
        import subprocess
        result = subprocess.run(
            ["tasklist", "/FI", "IMAGENAME eq saplogon.exe", "/FO", "CSV", "/NH"],
            capture_output=True, text=True, timeout=5,
        )
        if "saplogon" in result.stdout.lower():
            print("saplogon.exe: 运行中")
        else:
            print("saplogon.exe: 未运行")

        result2 = subprocess.run(
            ["tasklist", "/FI", "IMAGENAME eq sapgui.exe", "/FO", "CSV", "/NH"],
            capture_output=True, text=True, timeout=5,
        )
        if "sapgui" in result2.stdout.lower():
            print("sapgui.exe:   运行中")
        else:
            print("sapgui.exe:   未运行 ← SAP GUI 窗口可能未打开")
    except Exception as e:
        print(f"进程检查失败: {e}")

    # 4. 尝试 GetObject("SAPGUI")
    print("\n--- 测试 GetObject('SAPGUI') ---")
    try:
        sap_gui = win32com.client.GetObject("SAPGUI")
        print(f"结果: 成功! type={type(sap_gui)}")

        app = sap_gui.GetScriptingEngine
        print(f"ScriptingEngine: {type(app)}")
        print(f"连接数: {app.Children.Count}")

        conn = app.Children(0)
        print(f"Connection: {type(conn)}")
        print(f"会话数: {conn.Children.Count}")

        session = conn.Children(0)
        info = session.Info
        print(f"系统: {info.SystemName}, 用户: {info.User}, 客户端: {info.Client}")
        print(f"\n✅ SAP GUI COM 连接完全正常!")

    except Exception as exc:
        error_code = exc.args[0] if exc.args else None
        print(f"结果: 失败!")
        print(f"错误码: {error_code}")
        print(f"错误信息: {exc}")

        if error_code == -2147221020:
            print("\n诊断: MK_E_SYNTAX — SAPGUI 对象未在 ROT 中注册")
            print("可能原因:")
            print("  1. SAP GUI 和 Python 的权限级别不一致")
            print("     → SAP GUI 以管理员运行? Python 也需要以管理员运行")
            print("     → 或者反过来，两者都用普通用户权限运行")
            print("  2. SAP GUI Scripting 未启用")
            print("     → 菜单 → 选项 → 辅助功能和脚本 → 脚本 → 启用脚本")
            print("  3. SAP GUI 版本过旧，不支持 Scripting API")
        elif error_code == -2147352567:
            print("\n诊断: DISP_E_EXCEPTION — COM 调用异常")
            print("  可能是 Scripting 被服务器端禁用")

    # 5. 备选方案: Dispatch
    print("\n--- 测试 Dispatch('Sapgui.ScriptingCtrl.1') ---")
    try:
        ctrl = win32com.client.Dispatch("Sapgui.ScriptingCtrl.1")
        print(f"结果: 成功! type={type(ctrl)}")
    except Exception as exc:
        print(f"结果: 失败 — {exc}")

    print("\n" + "=" * 60)


if __name__ == "__main__":
    main()
