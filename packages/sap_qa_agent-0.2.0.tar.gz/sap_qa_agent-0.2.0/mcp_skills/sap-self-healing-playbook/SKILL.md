---
id: sap-self-healing-playbook
title: SAP 自愈工作手册 (Self-Healing Playbook)
description: 当 SAP 测试步骤失败时，如何读取 AI 干预记录、分析根因、决定重试或放弃的决策流程。
version: 0.1.0
keywords:
  - sap
  - self-healing
  - recovery
  - ai-intervention
  - troubleshooting
required_tools:
  - get_task_status
  - capture_screen
  - execute_test_case
  - stop_task
language: zh-CN
---

# SAP Self-Healing Playbook

SAP 测试步骤失败时，本 Skill 指导如何复盘 `SelfHealingController` 的干预记录、
分析失败根因，并决定"继续自愈重试"还是"放弃本轮执行"。

## When to use

- `get_task_status` 返回 `status=failed`，且 `step_results` 中至少有一条
  `success=false`。
- 某一步 `ai_intervention_records` 非空，说明已尝试自愈但最终仍未通过。
- 用户提出"帮我看看为什么失败"、"能不能再试一次"这类后续问题。

## Inputs

- `task_id`：需要分析的任务 id。
- 可选 `step_index`：指向具体失败步骤的索引（来自 `step_results[*].index`）。

## Tool sequence

1. 调用 `get_task_status(task_id)`，读出：
   - `error` 顶层错误信息
   - `step_results[*]` 中 `success=false` 的条目
   - 每条失败步骤的 `ai_intervention_records` 列表
2. 对每条 `HealingRecord`：
   - `action_type`（如 `retry_with_hint` / `switch_strategy` / `vlm_locate`）是
     自愈选择的策略。
   - `reason` 是 GLM 生成的根因判断。
   - `success` 表明该次自愈是否生效。
3. 可选：调用 `capture_screen(include_elements=true)` 拿当前屏幕做对比，注意
   这是**当前**屏幕，不是失败时的屏幕——失败时的截图在
   `step_results[*].screenshot_url` 或 `sap-qa://artifacts/{task_id}/...`。
4. 把人可读的诊断写给用户：
   - 第 N 步在做什么 (`action` + `target` + `value`)
   - 状态栏信息 (`status_bar`) / 错误信息 (`error`)
   - 最后一次 `HealingRecord` 的 `action_type` + `reason`
5. 决策：
   - 若失败为"元素定位漂移"且自愈已耗尽 `max_healing_attempts`，建议人工
     校准后再次调用 `execute_test_case(case_data=..., retry_from_step=N)`。
   - 若失败为 SAP 本身业务错误（状态栏 `E` 型消息），不要再重试，回传给
     用户让其核对数据。
   - 若任务仍在 `running` 状态但显然卡住了，使用 `stop_task` 后再重试。

## Success criteria

- 每一条失败步骤都已给出"是什么 / 为什么 / 建议怎么处理"三段式解释。
- 如果选择重试，新的 `task_id` 终态为 `completed`。

## Failure handling

- `ai_intervention_records` 为空，但仍然 `success=false`：说明自愈未触发
  （可能因 `enable_self_healing=false` 或 `GLM_NOT_CONFIGURED`）。不要伪造
  诊断，直接告诉用户缺少自愈结果。
- 读取 `report_uri` 资源时遇到 `PATH_NOT_ALLOWED`：用户自定义了 artifacts_root
  但未把它加到 `--allow-path`，提示用户补配置。
- 同一步骤连续两次 `retry_from_step` 仍失败：停止自动重试，转人工。
