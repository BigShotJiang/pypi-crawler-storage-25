---
id: sap-session-bootstrap
title: SAP 会话引导 (Session Bootstrap)
description: 在执行任何 SAP 自动化操作之前，正确建立并验证 SAP GUI 脚本会话的标准流程。
version: 0.1.0
keywords:
  - sap
  - session
  - bootstrap
  - connect
  - precondition
required_tools:
  - sap_connect
  - sap_session_status
  - sap_disconnect
  - capture_screen
language: zh-CN
---

# SAP Session Bootstrap

在调用任何需要 SAP GUI 的工具之前，先用本 Skill 把会话建立起来，确保 SAP GUI
已启动、Scripting API 已启用，且当前窗口状态可控。

## When to use

- 用户请求执行任何 SAP 自动化任务，但本会话尚未调用过 `sap_connect`。
- 之前的 `sap_connect` 失败，或被 `sap_disconnect` 主动释放过。
- 需要确认当前 SAP GUI 停留在哪个事务码/界面。

## Inputs

- 无显式输入；Skill 内部假设主机安装了 SAP GUI 并通过注册表开启了 Scripting。
- 可选：若用户给了 SAP 系统名 / 用户名，可在响应中比对 `sap_connect` 返回的
  `system_name` / `user` 字段，避免连错环境。

## Tool sequence

1. 调用 `sap_connect`：
   - 成功 → 记下 `system_name`、`user`、`window_title`。
   - 错误码 `SAP_GUI_NOT_RUNNING` → 提示用户手动启动 `saplogon.exe`。
   - 错误码 `SCRIPTING_DISABLED` → 引导用户按 SAP GUI → Options → Accessibility &
     Scripting 打开 Scripting。
   - 错误码 `SAP_SESSION_OWNED_BY_OTHER_CHANNEL` → 提示用户关闭占用会话的另一
     进程（`details.other_channel` + `details.other_pid` 会指明）。
2. 调用 `sap_session_status` 获取 `connected` / `on_login_screen` / `transaction_code`。
3. 如果 `on_login_screen=true`，调用 `capture_screen(include_elements=true)` 把
   登录界面元素交回给用户，让人工完成登录后再继续。
4. 如果 `transaction_code` 不符合用户指定的起始事务码，可继续用后续 Skill
   (`sap-parse-and-execute`) 的步骤引导跳转。

## Success criteria

- `sap_session_status` 返回 `connected=true` 且 `on_login_screen=false`。
- 若用户提供了目标系统 / 用户，`sap_connect` 的 `system_name` / `user` 匹配。

## Failure handling

- 三次 `sap_connect` 连续失败仍报 `SAP_GUI_NOT_RUNNING`：停止自动化，等待人工。
- 出现未在 Requirements 中列出的错误码：直接把原始错误返回给用户，不要猜测
  原因，也不要重试超过 3 次。
- `SAP_SESSION_OWNED_BY_OTHER_CHANNEL`：不要尝试强制接管，必须要求占用方先
  退出。
