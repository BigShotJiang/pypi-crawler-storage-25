---
id: sap-parse-and-execute
title: 解析并执行 SAP 测试用例
description: 从 Excel / Markdown 文件或内联内容解析出测试用例，然后驱动 SAP GUI 完整执行并回传任务状态与产物。
version: 0.1.0
keywords:
  - sap
  - testcase
  - parse
  - execute
  - orchestration
required_tools:
  - parse_test_case
  - sap_connect
  - sap_session_status
  - execute_test_case
  - get_task_status
  - list_tasks
  - stop_task
language: zh-CN
---

# SAP Parse and Execute

把"把这个测试用例在 SAP 里跑一遍"这类需求拆成标准的三段：解析 → 连接 → 执行，
并给出轮询与产物读取的标准做法。

## When to use

- 用户提供一个 Excel (`.xlsx`) / Markdown (`.md`) 测试用例文件路径。
- 用户直接在消息里粘贴了测试用例内容，并期望自动跑起来。
- 需要把前一次执行的结果（截图 / 报告）回传给用户。

## Inputs

- `file_path` *(可选)*：文件绝对路径，必须位于白名单目录之一（`upload_dir`、
  `artifacts_dir`、`knowledge_base_dir`、`--allow-path`）。
- `content` *(可选)*：测试用例文本（Markdown 优先），二选一与 `file_path` 互斥。
- `format`：`excel` / `markdown` / `auto`，默认 `auto`。
- `mode` *(可选)*：`auto` / `exploration` / `reuse`，默认 `auto`。
- `enable_self_healing` *(可选)*：默认 `true`，当 `GLM_API_KEY` 未配置时会被
  强制降级为 `false`。

## Tool sequence

1. **解析**：调用 `parse_test_case(file_path=..., format=auto)` 或
   `parse_test_case(content=..., format=markdown)`。
   - 校验响应 `summary.case_count ≥ 1`；否则返回给用户让其补充。
2. **会话**：先用 `sap_session_status` 检查 `connected`。若未连接，调用
   `sap_connect`。连接失败时按 `sap-session-bootstrap` Skill 的指引处理。
3. **执行**：对每个 TestCase 依次调用 `execute_test_case(case_data=...,
   mode=..., enable_self_healing=...)`。
   - 得到 `task_id` 后保留，用户后续可能询问进度。
   - 错误码 `CONCURRENCY_LIMIT` → 等待 `list_tasks` 返回的 running 任务结束
     再重试，不要并发提交。
4. **轮询**：以 3–5 秒间隔调用 `get_task_status(task_id)`，直到 `status ∈
   {completed, failed, cancelled}`。
   - 结果中 `step_results` 超过 50 条时会 `truncated=true`，完整列表从
     `sap-qa://artifacts/{task_id}/report.json` 读取。
5. **收尾**：终态后把 `report_uri` 和 `step_results` 汇总给用户，必要时
   引用截图 URI（`sap-qa://artifacts/{task_id}/.../*.png`）。

## Success criteria

- 每个 `task_id` 终态为 `completed`，并且 `success_count == step_count`。
- `report_uri` 可通过 `resources/read` 成功读出 JSON 报告。

## Failure handling

- `UNSUPPORTED_FORMAT` / `FILE_TOO_LARGE` / `PATH_NOT_ALLOWED`：向用户说明
  限制，不要尝试绕过路径白名单或压缩文件。
- `INVALID_CASE_DATA`：把错误 `details` 完整回显给用户，让其修正字段。
- `CONCURRENCY_LIMIT`：先用 `list_tasks` 找出占用的 `task_id`，询问用户是否
  要 `stop_task` 再继续。
- 执行失败：读取 `report_uri`，引用 `ai_intervention_records` 中的最后一次
  `HealingRecord` 给用户看，必要时切换到 `sap-self-healing-playbook` Skill。
