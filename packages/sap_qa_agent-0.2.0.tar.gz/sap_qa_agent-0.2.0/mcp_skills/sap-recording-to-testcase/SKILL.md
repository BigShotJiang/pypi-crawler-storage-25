---
id: sap-recording-to-testcase
title: 录制 SAP 操作并生成测试用例 (Recording to Test Case)
description: 通过 start_recording / stop_recording 捕获 SAP 操作，转化为结构化测试用例，并驱动重放验证。
version: 0.1.0
keywords:
  - sap
  - recording
  - testcase
  - automation
  - replay
required_tools:
  - start_recording
  - stop_recording
  - parse_test_case
  - execute_test_case
  - get_task_status
language: zh-CN
---

# SAP Recording to Test Case

把人工在 SAP 里的一次操作录下来，转成标准测试用例，再让机器重放，是最快把
"新流程"沉淀进知识库的办法。本 Skill 规定操作顺序与边界条件。

## When to use

- 用户说"我自己来操作，你帮我录下来并保存为用例"。
- 已有录屏事件，需要把它转成 TestCase 供 `execute_test_case` 重放。
- 需要向用户说明为什么录制在 stdio 传输下不可用。

## Inputs

- 无必填输入；可选 `description` 用于写入未来生成的 TestCase `purpose` 字段。
- 需要 MCP Server 以 `streamable-http` 传输启动（参见失败处理）。

## Tool sequence

1. 确认传输模式：若调用 `start_recording` 返回 `RECORDING_NOT_AVAILABLE_IN_STDIO`，
   告诉用户切换启动方式为 `sap-qa-mcp --transport streamable-http`。
2. `start_recording()` → 拿到 `recording_id`。告知用户"开始录制，请在 SAP 中
   正常操作；完成后告诉我 'stop'。"
3. 人工操作期间，**不要**并发调用其他会干扰焦点的工具（原子工具、
   `capture_screen` 等）。
4. 用户示意结束后，`stop_recording(recording_id)`：
   - 返回 `steps` 与 `raw_events_uri`。
   - 若 `video_available=false`，说明 FFMPEG 不可用，只有事件日志没有视频。
5. 把 `steps` 归并为 TestCase JSON（参考 `sap-parse-and-execute`），可选用
   `parse_test_case(content=json.dumps({...}))` 做一次结构校验。
6. 重放验证：`execute_test_case(case_data=...)` → `get_task_status(task_id)`
   轮询直到终态。

## Success criteria

- `stop_recording` 返回 `steps` 非空；若启用了视频，`video_available=true`。
- 重放执行 `completed` 且所有步骤 `success=true`。
- 重放成功后，建议把该 TestCase 入库（下一次可走 `sap-knowledge-base-reuse`）。

## Failure handling

- `RECORDING_NOT_AVAILABLE_IN_STDIO`：不要尝试绕过；明确告诉用户必须换
  `streamable-http` 模式。
- `RECORDING_IN_PROGRESS`：已有活动录制；要求用户先 `stop_recording` 旧的
  再启动新的。
- `RECORDING_NOT_FOUND`：`recording_id` 错误或已停止；不要猜测 id，要求
  用户提供正确值或重新开始。
- 重放失败：按 `sap-self-healing-playbook` 诊断，通常录制里夹带的不稳定
  定位（如屏幕坐标）需要手动修成结构化目标。
