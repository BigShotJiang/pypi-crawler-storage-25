---
id: sap-knowledge-base-reuse
title: SAP 知识库复用 (Knowledge Base Reuse)
description: 在执行前基于事务码检索知识库模板，判断走复用模式还是探索模式，最大化复用已固化的脚本。
version: 0.1.0
keywords:
  - sap
  - knowledge-base
  - template
  - reuse
  - exploration
required_tools:
  - list_templates
  - get_template
  - parse_test_case
  - execute_test_case
language: zh-CN
---

# SAP Knowledge Base Reuse

本 Skill 指导如何在正式执行前先查知识库，把"已经固化的模板"和"新用例"区分
开来，帮宿主 Agent 选择最合适的 `execute_test_case` 模式。

## When to use

- 接到新测试用例，想知道是否已有历史成功脚本可复用。
- 需要把多个相同事务码的用例批量执行，希望选出最可靠的模板。
- 需要向用户说明"为什么这次会走探索模式/复用模式"。

## Inputs

- `transaction_code` *(可选)*：如 `VA01`、`MM01`。未知事务码时留空，工具会
  返回全部模板。
- `confidence` *(可选)*：`HIGH` / `MEDIUM` / `LOW`。默认不过滤。
- 对照的 TestCase 对象（已由 `parse_test_case` 产出或由用户提供）。

## Tool sequence

1. 调用 `list_templates(transaction_code=..., confidence=HIGH)` 检索高置信度
   模板。
   - 返回 `count > 0` → 至少有一条可用，进入第 2 步；
   - `count == 0` → 放宽到 MEDIUM / 无过滤，重试；仍为 0 则走探索模式。
2. 对最高置信度模板调用 `get_template(template_id)` 取完整 `ScriptTemplate`。
3. 对比模板与当前 TestCase：
   - 事务码一致、期望结果字段对齐 → 用
     `execute_test_case(case_data=..., mode=reuse)`。
   - 字段差异较大 → 选 `mode=auto`（交给 orchestrator 决定），或 `mode=exploration`
     并在执行后依赖模板固化机制写回知识库。
4. 执行完成后（`get_task_status` 终态），若 `result.template_solidified=true`，
   告知用户"已把本次成功脚本固化进知识库，后续可直接复用"。

## Success criteria

- 当模板匹配度高时选择 `mode=reuse` 并在合理时间内完成。
- 当无合适模板时明确切换到 `mode=auto` 或 `mode=exploration`，不要硬塞
  `reuse` 导致失败。

## Failure handling

- `TEMPLATE_NOT_FOUND`：用户给出的 `template_id` 已被删除或重命名；重新
  `list_templates` 再确认。
- `truncated=true`：`list_templates` 超过 100 条被截断；让用户通过
  `transaction_code` 进一步过滤，不要盲目请求完整列表。
- 模板置信度全部为 `LOW`：建议用户先跑一两轮探索模式把模板升级到 `MEDIUM`
  再批量复用。
