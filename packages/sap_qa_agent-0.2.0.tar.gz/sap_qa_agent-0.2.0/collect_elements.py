"""测试脚本：连接 SAP GUI，采集当前页面所有元素路径并输出。

使用方法：
1. 确保 SAP GUI 已打开并连接到系统
2. 手动导航到你想测试的页面（如 ME21N 创建采购订单）
3. 运行: python collect_elements.py

输出：
- 所有元素的路径、类型、label、value
- 有 label 的元素优先显示
- 结果同时输出到控制台和 artifacts/screen_elements.txt 文件
"""

import os
import sys
import logging

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(name)s] %(levelname)s: %(message)s")
logger = logging.getLogger(__name__)


def main():
    # 初始化 COM
    import pythoncom
    pythoncom.CoInitialize()

    try:
        from app.sap.sap_gui_wrapper import SapGuiWrapper
        from app.sap.element_path_finder import ElementPathFinder
        from app.sap.vlm_fallback import VlmFallbackExecutor
        from app.sap.script_executor import ScriptExecutor
        from app.ai.glm_client import GlmClient

        # 连接 SAP GUI
        print("🔌 连接 SAP GUI...")
        sap = SapGuiWrapper()
        connected = sap.connect()
        if not connected:
            print("❌ 无法连接 SAP GUI，请确保 SAP GUI 已打开")
            return

        session = sap.get_session()
        if not session:
            print("❌ 无法获取 SAP session")
            return

        # 读取当前界面信息
        try:
            title = str(session.findById("wnd[0]").Text or "")
        except Exception:
            title = "(unknown)"

        try:
            status = str(session.findById("wnd[0]/sbar").Text or "")
        except Exception:
            status = ""

        print(f"✅ 已连接")
        print(f"📍 当前界面: {title}")
        if status:
            print(f"📊 状态栏: {status}")
        print()

        # 初始化 ElementPathFinder
        glm = GlmClient()
        finder = ElementPathFinder(sap, glm)
        vlm = VlmFallbackExecutor()
        executor = ScriptExecutor(sap, vlm, element_finder=finder, glm_client=glm)

        # 采集屏幕元素
        print("🔎 采集屏幕元素...")
        finder.traverse_element_tree("wnd[0]/usr")
        tree = finder._cached_tree

        if not tree:
            print("❌ 采集失败")
            return

        print(f"✅ 采集到 {len(tree.elements)} 个元素")
        print(f"📋 Label Map: {len(tree.label_map)} 个映射")
        print()

        # 输出所有元素
        lines = []

        # 1. 先输出 label_map
        lines.append("=" * 80)
        lines.append("LABEL MAP（标签 → 路径映射）")
        lines.append("=" * 80)
        for label, path in sorted(tree.label_map.items()):
            line = f"  \"{label}\" → {path}"
            lines.append(line)

        lines.append("")
        lines.append("=" * 80)
        lines.append("所有元素（有 label 的优先）")
        lines.append("=" * 80)

        # 2. 分组：有 label 和没有 label
        labeled = []
        unlabeled = []
        skip_types = {"GuiSimpleContainer", "GuiScrollContainer", "GuiUserArea",
                      "GuiCustomControl", "GuiContainerShell"}

        # 验证 SAP GUI COM 元素是否暴露 Changeable 属性
        changeable_sample = []
        for elem in tree.elements:
            if elem.element_type in ("GuiTextField", "GuiCTextField", "GuiComboBox"):
                try:
                    raw_elem = session.findById(elem.id_path)
                    if raw_elem:
                        val = raw_elem.Changeable
                        changeable_sample.append(
                            f"  {elem.id_path}: Changeable={val} (type={elem.element_type})"
                        )
                except AttributeError:
                    changeable_sample.append(
                        f"  {elem.id_path}: AttributeError — 无 Changeable 属性"
                    )
                except Exception as e:
                    changeable_sample.append(
                        f"  {elem.id_path}: 读取异常 — {e}"
                    )
                if len(changeable_sample) >= 10:
                    break

        if changeable_sample:
            lines.append("")
            lines.append("=" * 80)
            lines.append("Changeable 属性探测（抽样前10个输入元素）")
            lines.append("=" * 80)
            for s in changeable_sample:
                lines.append(s)
            lines.append("")

        for elem in tree.elements:
            label = elem.label_text or elem.tooltip or ""
            info = f"{elem.id_path} (type={elem.element_type}"
            if label:
                info += f", label=\"{label}\""
            if elem.current_value:
                val_display = elem.current_value[:80]
                info += f", value=\"{val_display}\""
            if not elem.is_changeable:
                info += ", readonly=true"
            info += ")"

            if elem.element_type in skip_types:
                continue

            if label:
                labeled.append(info)
            else:
                unlabeled.append(info)

        lines.append(f"\n--- 有 label 的元素 ({len(labeled)} 个) ---")
        for info in labeled:
            lines.append(f"  {info}")

        lines.append(f"\n--- 没有 label 的元素 ({len(unlabeled)} 个) ---")
        for info in unlabeled:
            lines.append(f"  {info}")

        # 3. 输出 collect_screen_elements_text 的结果
        lines.append("")
        lines.append("=" * 80)
        lines.append("collect_screen_elements_text 输出（传给 GLM 的内容）")
        lines.append("=" * 80)
        glm_text = executor.collect_screen_elements_text(max_elements=500)
        lines.append(glm_text)

        # 4. 深度探测：从条件页签路径向下逐层探测子元素类型
        lines.append("")
        lines.append("=" * 80)
        lines.append("深度探测：逐层遍历子元素")
        lines.append("=" * 80)

        def _probe_children(parent_path, depth=0, max_depth=5):
            """递归探测子元素，输出类型和路径。"""
            if depth > max_depth:
                return
            indent = "  " * (depth + 1)
            try:
                parent = session.findById(parent_path)
                elem_type = ""
                elem_text = ""
                try:
                    elem_type = str(parent.Type) if parent.Type else ""
                except Exception:
                    pass
                try:
                    elem_text = str(parent.Text)[:60] if parent.Text else ""
                except Exception:
                    pass
                lines.append(f"{indent}{parent_path}")
                lines.append(f"{indent}  type={elem_type}, text=\"{elem_text}\"")

                # 对 GuiShell 尝试读取 Grid 信息
                if elem_type == "GuiShell":
                    try:
                        sub_type = str(parent.SubType) if hasattr(parent, 'SubType') else ""
                        lines.append(f"{indent}  SubType={sub_type}")
                    except Exception:
                        pass
                    try:
                        row_count = parent.RowCount
                        lines.append(f"{indent}  RowCount={row_count}")
                    except Exception as e:
                        lines.append(f"{indent}  RowCount error: {e}")
                    try:
                        col_order = parent.ColumnOrder
                        cols = [str(c) for c in col_order][:10]
                        lines.append(f"{indent}  Columns={cols}")
                    except Exception as e:
                        lines.append(f"{indent}  ColumnOrder error: {e}")
                    return  # Grid 不递归

                # 对 GuiTableControl 输出列信息
                if elem_type == "GuiTableControl":
                    try:
                        cols = parent.Columns
                        col_titles = []
                        for ci in range(cols.Count):
                            try:
                                col_titles.append(str(cols(ci).Title))
                            except Exception:
                                pass
                        lines.append(f"{indent}  TableColumns={col_titles[:15]}")
                        lines.append(f"{indent}  RowCount={parent.RowCount}")
                    except Exception as e:
                        lines.append(f"{indent}  TableControl error: {e}")

                # 递归子元素
                try:
                    children = parent.Children
                    if children:
                        for i in range(children.Count):
                            try:
                                child = children(i)
                                child_id = str(child.Id)
                                _probe_children(child_id, depth + 1, max_depth)
                            except Exception:
                                pass
                except Exception:
                    pass
            except Exception as e:
                lines.append(f"{indent}{parent_path} → ERROR: {e}")

        # 找到条件页签的路径，从那里开始探测
        condition_tab_path = None
        for elem in tree.elements:
            if elem.element_type == "GuiTab" and elem.label_text == "条件":
                condition_tab_path = elem.id_path
                break

        if condition_tab_path:
            lines.append(f"\n从条件页签开始探测: {condition_tab_path}")
            _probe_children(condition_tab_path, depth=0, max_depth=6)
        else:
            lines.append("\n未找到条件页签，从 wnd[0]/usr 开始探测前3层:")
            _probe_children("wnd[0]/usr", depth=0, max_depth=3)

        # 输出到控制台
        output = "\n".join(lines)
        print(output)

        # 保存到文件
        os.makedirs("artifacts", exist_ok=True)
        output_path = "artifacts/screen_elements.txt"
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(f"界面: {title}\n")
            f.write(f"状态栏: {status}\n")
            f.write(f"元素总数: {len(tree.elements)}\n")
            f.write(f"Label Map: {len(tree.label_map)} 个\n\n")
            f.write(output)

        print(f"\n📁 结果已保存到: {output_path}")

    finally:
        pythoncom.CoUninitialize()


if __name__ == "__main__":
    main()
