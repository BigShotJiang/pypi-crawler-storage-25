"""快速测试：验证 SAP GUI COM 连接

前提：SAP Logon 已打开（不需要登录到系统）
"""
import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

print("=" * 50)
print("  SAP GUI COM 连接测试")
print("=" * 50)

# Step 1: 检查 win32com 是否可用
print("\n1. 检查 win32com...")
try:
    import win32com.client
    print("   ✅ win32com 可用")
except ImportError:
    print("   ❌ win32com 不可用，需要安装: pip install pywin32")
    sys.exit(1)

# Step 2: 尝试连接 SAP GUI
print("\n2. 连接 SAP GUI Scripting Engine...")
try:
    sap_gui = win32com.client.GetObject("SAPGUI")
    if sap_gui is None:
        print("   ❌ GetObject('SAPGUI') 返回 None")
        print("   → SAP Logon 可能未打开，或 Scripting 未启用")
        sys.exit(1)
    print("   ✅ 获取到 SAPGUI 对象")
except Exception as e:
    print(f"   ❌ 连接失败: {e}")
    print("   → 请确认 SAP Logon 已打开")
    print("   → 如果已打开但仍失败，可能需要在 SAP GUI 选项中启用 Scripting:")
    print("     SAP Logon → 选项 → 辅助功能和脚本 → 脚本 → 启用脚本")
    sys.exit(1)

# Step 3: 获取 Scripting Engine
print("\n3. 获取 Scripting Engine...")
try:
    application = sap_gui.GetScriptingEngine
    if application is None:
        print("   ❌ GetScriptingEngine 返回 None")
        print("   → Scripting 可能未启用")
        sys.exit(1)
    print(f"   ✅ Scripting Engine 获取成功")
    print(f"   连接数: {application.Children.Count}")
except Exception as e:
    print(f"   ❌ 获取 Scripting Engine 失败: {e}")
    sys.exit(1)

# Step 4: 检查是否有活动连接
print("\n4. 检查活动连接...")
conn_count = application.Children.Count
if conn_count == 0:
    print("   ⚠️ 没有活动的 SAP 连接")
    print("   → 请先双击 SAP Logon 中的系统条目登录")
    print("   → 登录后重新运行此脚本")
    print("\n   当前状态：SAP GUI 已连接，但未登录到任何系统")
    print("   框架可以启动 SAP GUI，但需要先登录才能执行测试用例")
else:
    print(f"   ✅ 找到 {conn_count} 个活动连接")
    
    # Step 5: 获取 session 信息
    for i in range(conn_count):
        try:
            connection = application.Children(i)
            session_count = connection.Children.Count
            print(f"\n   连接 {i}: {session_count} 个 session")
            
            for j in range(session_count):
                session = connection.Children(j)
                try:
                    sys_name = session.Info.SystemName
                    client = session.Info.Client
                    user = session.Info.User
                    lang = session.Info.Language
                    print(f"     Session {j}: 系统={sys_name}, 客户端={client}, 用户={user}, 语言={lang}")
                    
                    # 读取状态栏
                    try:
                        sbar = session.findById("wnd[0]/sbar")
                        print(f"     状态栏: [{sbar.MessageType}] {sbar.Text}")
                    except:
                        print(f"     状态栏: (无法读取)")
                    
                    # 读取窗口标题
                    try:
                        title = session.findById("wnd[0]").Text
                        print(f"     窗口标题: {title}")
                    except:
                        pass
                        
                except Exception as e:
                    print(f"     Session {j}: 无法读取信息 ({e})")
        except Exception as e:
            print(f"   连接 {i}: 无法读取 ({e})")

print("\n" + "=" * 50)
print("  测试完成")
print("=" * 50)
