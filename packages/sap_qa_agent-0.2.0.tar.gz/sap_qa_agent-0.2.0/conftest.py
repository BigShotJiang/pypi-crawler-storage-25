import sys
import os
import json
from unittest.mock import MagicMock, AsyncMock

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "app", ".."))


# ---- SAP Testing Fixtures ----


@pytest.fixture
def mock_sap_session():
    """Mock SAP GUI session object for testing without a real SAP connection."""
    session = MagicMock()

    # Status bar mock
    sbar = MagicMock()
    sbar.Text = ""
    sbar.MessageType = "S"
    session.findById.return_value = sbar

    # Active window
    session.ActiveWindow = MagicMock()
    session.ActiveWindow.Name = "wnd[0]"

    # Info
    session.Info = MagicMock()
    session.Info.SystemName = "TEST"
    session.Info.Client = "100"
    session.Info.User = "TESTUSER"

    return session


@pytest.fixture
def mock_glm_client():
    """Mock GlmClient for testing without real API calls."""
    client = MagicMock()
    client.split_steps = AsyncMock(return_value=[])
    client.generate_script = AsyncMock(return_value="# mock script")
    client.analyze_exception = AsyncMock(return_value=MagicMock(
        action="confirm", value="", reason="mock"
    ))
    client.select_element = AsyncMock(return_value=0)
    client.analyze_failure = AsyncMock(return_value="Mock failure analysis")
    return client


@pytest.fixture
def tmp_knowledge_base(tmp_path):
    """Temporary knowledge base directory with empty templates.json."""
    kb_dir = tmp_path / "knowledge_base"
    kb_dir.mkdir()
    templates_file = kb_dir / "templates.json"
    templates_file.write_text(json.dumps({
        "version": "1.0",
        "templates": {},
        "metadata": {"total_templates": 0, "last_updated": None},
    }), encoding="utf-8")

    patterns_file = kb_dir / "patterns.json"
    patterns_file.write_text(json.dumps({
        "patterns": [
            {"name": "销售订单", "regex": "(?:销售订单|Sales Order)\\s*(\\d{8,10})\\s*(?:已创建|has been saved)", "variable": "ORDER_NO"},
        ],
        "language": "zh_CN",
    }), encoding="utf-8")

    return str(kb_dir)
