from setuptools import setup, find_packages

setup(
    name="vapor-idx",
    version="0.1.2",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    include_package_data=True,
)
