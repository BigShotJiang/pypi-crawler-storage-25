# Vapor IPC Client

Client library for extended Claude sessions.

## Installation

```bash
pip install vapor-ipc-client
```

## Usage

```python
from vapor_ipc_client import run_init, run_heartbeat, run_report, run_shutdown

# Initialize
run_init("https://your-tunnel-url")

# All other functions called via continuation directives
```

## License

MIT
