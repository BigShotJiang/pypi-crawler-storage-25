# 🎉 instruction-lint v0.6.0 — Release Notes

**Released:** April 10, 2026 | **Status:** Production-ready

---

## 📋 What's in This Release

### 🚀 Major Features Added

- **`--fix` auto-fix flag** — Automatically repair violations directly in your instruction files. Three check families now emit fixable violations: `AL-DEP*` (deprecated patterns with replacements), `AL-P*` (forbidden patterns with fixes), and `AL-S01` (redacts leaked credentials).

- **AL-FRESH01 `freshness` check** — Warn when instruction files contain dates older than your configured threshold. Supports ISO, slash-separated, and long/short named-month formats. Disabled by default.

- **AL-DEP* `deprecated_patterns` check** — Flag deprecated AI provider models, SDK methods, and endpoints before they break. Entirely configurable — supply your own list of deprecated patterns with optional replacement text.

- **AL-CONF01 `semantic_conflict` check** — Detect contradictory directives between instruction files (e.g., one says "always use tabs", another says "never use tabs").

- **AL-DUP01 `duplicate_content` check** — Find near-duplicate SKILL and DISPATCH files using Jaccard similarity (default 85%). Threshold is configurable.

- **AL-V01 AST-based value extraction** — More robust constant value lookups for Python files. Now uses full AST parsing with class-scope awareness for better accuracy. Handles type-annotated assignments, negative literals, and deeply nested classes. Includes support for negative numbers (e.g., `-1`).

- **Al-ENC01 `encoding_check`** — Verify all instruction files are valid UTF-8.

- **AL-FM01 `frontmatter_schema`** — Enforce required YAML frontmatter keys in SKILL files via config.

- **AL-LEN01 `min_content`** — Catch accidentally empty stub SKILL files by enforcing a minimum token count.

- **AL-D05 dispatch coverage extension** — Error when two or more SKILL files share the same effective name.

- **VS Code 1.99+ per-file instruction support** — `.github/instructions/*.md` files now auto-discovered as SKILL role.

- **Claude Code nested rules** — `<subdir>/CLAUDE.md` files anywhere under the project root are collected as SKILL role.

- **Gemini CLI nested rules** — `<subdir>/GEMINI.md` files anywhere under the project root are collected as SKILL role.

- **Action inputs** — New `version` input for pinning `instruction-lint` to a specific release in CI, and `config` input to pass custom config paths.

---

### 🐛 Bug Fixes

This release includes **21 targeted bug fixes** across the codebase:

| Bug | Issue | Fix | Impact |
|-----|-------|-----|--------|
| **B-01** | Numeric config values set via `setattr()` bypass validation | Added type guards before numeric assignment | Prevents invalid config state |
| **B-02** | `source_markers` list concatenation without type check | Type guardrail added to `source_markers` assignment | Blocks accidental string-to-list coercion |
| **B-03** | `checks` dict keys set without validation | Key type check before assignment | Prevents invalid check IDs |
| **B-04** | `forbidden_patterns` list extended without type guard | Type check before pattern list extension | Stops accidental scalar appends |
| **B-05** | Variable shadowing: `path` shadowed in `circular_refs.py` | Renamed stack variable to `_stack` | Better readability, avoids confusion |
| **B-06** | Variable shadowing: `f` shadowed in 4 check files | Renamed loop variable to `_f` | Clearer intent, avoids shadowing |
| **B-08** | Dead `seen` set in `duplicate_content.py` | Removed unused set | Minor code cleanup |
| **B-09** | YAML exceptions swallowed silently | Converted to named warning on stderr | Better debugging visibility |
| **B-10** | Baseline file load failures swallowed | Converted to named warning | Users informed of baseline issues |
| **B-11** | Regex errors swallowed in 5 check files | Named warnings to stderr on `re.error` | Pattern bugs are now reportable |
| **B-12** | Code fence tracking broken by leading/trailing whitespace | Added `.strip()` to fence marker detection | Fixes freshness date detection |
| **B-14** | Semantic conflict dedup key incorrect | Corrected to use canonical topic order | Accurate conflict detection |
| **B-15** | Circular ref DFS could hit RecursionError on deep graphs | Converted to iterative DFS with explicit stack | Handles arbitrarily deep chains (1500+ nodes tested) |
| **B-17–B-20** | Path traversal attacks possible in 5 checks | Added `.is_relative_to()` validation | File path operations are now safe |
| **B-21** | CLI baseline report silently continues on stale files | Better error handling and reporting | Users see what baseline violations were suppressed |

---

### 📊 Test Coverage

- **24 new regression tests** in `tests/test_bugfix_stress.py` covering all bug scenarios
- **Total test suite: 572 tests** (up from 547)
- **All tests passing** — including edge cases (1500-node circular chains, quoted numerics, dedup exactness)
- **Ruff lint & format** — fully clean

---

### 📖 Documentation Improvements

- **README accuracy audit** — Fixed 8 discrepancies:
  - AL-LEN01 zero-config status corrected
  - Claude Code missing `.claude/rules/*.md` paths added
  - Gemini missing per-directory file format documented
  - 6 missing config keys added to example block
  - AL-V01 factual accuracy updated (AST vs regex)
  - Circular refs terminology clarified
  - Action inputs table updated with `version` and `config`

- **Configuration examples** — Added all 6 missing config keys to the `.agentlint.yml` example

---

### 🔒 Security & Quality

- **Security audit PASS** — No CVEs, no unsafe patterns, YAML safe
- **Pre-commit hook fixes** — `.pre-commit-hooks.yaml` now scans YAML instruction files
- **Code deduplication** — Extracted shared `_CODE_FENCE_RE` regex from 5 files
- **Performance improvement** — Pattern compilation now happens once per file instead of per-pattern per-file

---

## 📦 Installation

### Via pip (recommended)

```bash
pip install instruction-lint==0.6.0
```

Or use the alias:

```bash
pip install agentlint==0.6.0
```

Both commands install the same binary: `agentlint`

### Via pre-commit hook

Update your `.pre-commit-config.yaml`:

```yaml
repos:
  - repo: https://github.com/Mr-afroverse/agentlint
    rev: v0.6.0
    hooks:
      - id: agentlint
```

### Via GitHub Actions

```yaml
- uses: Mr-afroverse/agentlint@v0.6.0
  with:
    version: "0.6.0"
```

---

## 🚦 Quick Start

```bash
cd your-project
agentlint
```

Scan with auto-fix enabled (requires config for some checks):

```bash
agentlint --fix
```

---

## 💡 Upgrade Path

This is a **backward-compatible** release. Existing instruction files and `.agentlint.yml` configs will work without modification. New checks are disabled by default unless configured.

To opt into the new checks:
- `AL-FRESH01`: Set `stale_days: ≥1` in config
- `AL-DEP*`: Add `deprecated_patterns:` list in config
- `AL-FM01`: Add `required_frontmatter:` list in config

---

## 📚 Complete Feature Matrix

| Check | ID | Type | Auto-detect | Config-driven | Default |
|-------|----|----|-------------|---------------|---------|
| Skill dispatch coverage | AL-D01, AL-D02, AL-D05 | Error | ✅ | — | ON |
| Circular dependencies | AL-D03 | Error | ✅ | — | ON |
| Role coverage | AL-D04 | Error | ✅ | ✅ | OFF |
| File references | AL-F01 | Warning | ✅ | — | ON |
| Dead anchors | AL-F02 | Warning | ✅ | — | ON |
| Number sourcing | AL-N01, AL-N02 | Warning | ✅ | — | ON |
| Value extraction (AST + regex) | AL-V01 | Error | ✅ | — | ON |
| Trigger overlap | AL-T01 | Warning | ✅ | — | ON |
| Forbidden patterns | AL-P* | Error | ✅ | — | ON |
| **Deprecated patterns** | **AL-DEP*** | **Warning** | **✅** | **✅** | **OFF** |
| Secret detection | AL-S01 | Warning | ✅ | — | ON |
| Inverse claims | AL-INV01 | Warning | ✅ | — | ON |
| Vague instructions | AL-Q01 | Warning | ✅ | — | ON |
| **Semantic conflict** | **AL-CONF01** | **Warning** | **✅** | **—** | **ON** |
| **Duplicate content** | **AL-DUP01** | **Warning** | **✅** | **✅** | **ON** |
| Encoding validation | AL-ENC01 | Error | ✅ | — | ON |
| **Frontmatter schema** | **AL-FM01** | **Warning** | **✅** | **✅** | **OFF** |
| **Minimum content** | **AL-LEN01** | **Warning** | **✅** | **✅** | **ON** |
| Token budget | AL-TOK01 | Warning | — | ✅ | OFF |
| **Freshness dates** | **AL-FRESH01** | **Warning** | **✅** | **✅** | **OFF** |
| .env parity | AL-E01 | Error | — | ✅ | OFF |
| Consistency groups | AL-C01 | Error | — | ✅ | OFF |
| Ground truth | AL-G01 | Error | — | ✅ | OFF |

*New in 0.6.0 (bold)*

---

## 📥 Downloads

- **Wheel**: `instruction_lint-0.6.0-py3-none-any.whl` (82.9 KB)
- **Source**: `instruction_lint-0.6.0.tar.gz` (138.9 KB)

Available on [PyPI](https://pypi.org/project/instruction-lint/0.6.0/) and [GitHub Releases](https://github.com/Mr-afroverse/agentlint/releases/tag/v0.6.0).

---

## 🔗 Resources

- **[GitHub](https://github.com/Mr-afroverse/agentlint)** — Source code, issues, discussions
- **[PyPI](https://pypi.org/project/instruction-lint/)** — Package page
- **[README](https://github.com/Mr-afroverse/agentlint#readme)** — Full documentation
- **[CHANGELOG](https://github.com/Mr-afroverse/agentlint/blob/main/CHANGELOG.md)** — Complete version history

---

## 🎓 What's Next?

In upcoming releases, we're exploring:
- Enhanced diagnostic reports (time-series tracking of instruction health)
- Multi-repository audit dashboards
- IDE extensions (VS Code, JetBrains)
- Cloud-hosted instruction validation service

---

## 🙏 Thanks

Special thanks to everyone who reported issues, tested pre-releases, and contributed feedback. instruction-lint is better because of your input.

**Happy linting! ✨**
