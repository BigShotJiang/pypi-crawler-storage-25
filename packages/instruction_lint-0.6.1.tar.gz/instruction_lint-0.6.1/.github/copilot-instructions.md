# agentlint — Workspace Instructions for Copilot

## Identity

- **Package:** `instruction-lint` (PyPI name)
- **Module:** `agentlint` (Python import)
- **CLI binary:** `agentlint`
- **Version:** Read from `agentlint/__init__.py` — do not hardcode version numbers in instructions
- **License:** MIT
- **Repo:** https://github.com/Mr-afroverse/agentlint

## Session Start

Read `AGENT_STATE.md` at the start of every session. It contains the Active Queue, session log, standing decisions, and technical inventory. Update it after every session.

## Standing Decisions (never re-ask these)

- Build backend: hatchling
- Python target: ≥ 3.10
- Dependencies: click ≥ 8.0, pyyaml ≥ 6.0 (no others at runtime)
- Test framework: pytest
- No over-engineering: only add what's needed for the current phase milestone
- Strategy: open core + SaaS. Free CLI forever, paid cloud platform later.

## Architecture

- **Adapters** (`agentlint/adapters/`): each adapter has `detect(root) -> bool` and `collect(root) -> list[InstructionFile]`. Currently: Copilot, Cursor, Windsurf, Aider, Continue, ClaudeCode, Gemini.
- **Checks** (`agentlint/checks/`): uniform signature `run(files: list[InstructionFile], config: Config, root: Path) -> list[Violation]`. Parameter order is `files, config, root` — never `files, root, config`.
- **Config** (`agentlint/config.py`): dataclass loaded from `.agentlint.yml`. All fields have sensible defaults. New config keys go in the dataclass + `_from_file()` parser.
- **CLI** (`agentlint/cli.py`): click-based. `_UNIQUE_CHECKS` run per adapter, `_DOCS_CHECKS` run on extra_paths files, `_STANDALONE_CHECKS` run from config alone.
- **Roles**: `DISPATCH` (main instruction file), `SKILL` (individual rule/skill), `DOCS` (extra documentation via extra_paths).

## Conventions

- All checks are in `agentlint/checks/<name>.py` with a module-level `run()` function
- Check IDs: `AL-D01`, `AL-D02`, `AL-D03`, `AL-D04`, `AL-D05`, `AL-F01`, `AL-F02`, `AL-N01`, `AL-N02`, `AL-T01`, `AL-P*`, `AL-DEP*`, `AL-S01`, `AL-INV01`, `AL-Q01`, `AL-TOK01`, `AL-LEN01`, `AL-ENC01`, `AL-FM01`, `AL-DUP01`, `AL-CONF01`, `AL-FRESH01`, `AL-E01`, `AL-C01`, `AL-V01`, `AL-G01`
- Tests mirror source: `tests/test_<name>.py`
- Use `ruff` for linting and formatting, `mypy` for type checking
- No `# noqa` comments — fix the issue or restructure the code
- Run `python -m pytest -k "not watch_exits"` to skip the watchdog-dependent test

## Before Any Commit

1. `python -m pytest -k "not watch_exits"` — all tests must pass
2. `ruff check agentlint/ tests/` — no lint issues
3. `ruff format --check agentlint/ tests/` — formatting clean
4. Cross-reference docs vs code: README check table, CHANGELOG version, CONTRIBUTING test count, action.yml inputs must match the actual codebase
5. Never commit with stale version references in docs

## Skills

- `.github/instructions/agentlint-conventions.md` — Developer conventions for authoring checks, adapters, config keys, and tests.

## What Not To Do

- Don't add features without user feedback or explicit request
- Don't refactor working code for aesthetics
- Don't add dependencies — every new dep needs strong justification
- Don't modify AGENT_STATE.md Standing Decisions without explicit user approval
- Don't create markdown documentation files unless requested
