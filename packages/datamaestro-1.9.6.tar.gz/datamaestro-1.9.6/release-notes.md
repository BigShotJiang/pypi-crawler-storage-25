## [1.9.6] - 2026-04-03

### Bug Fixes
- SetDataIDs now recurses into list-typed parameters ([6494c10](https://github.com/experimaestro/experimaestro-python/commit/6494c10f7b1eb748df0d11db41e862a0bc14619c))

