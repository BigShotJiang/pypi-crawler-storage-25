"""Incentive programs resource — market-level reward programs.

Wire quirk: this endpoint paginates on ``next_cursor`` (every other
Kalshi endpoint uses ``cursor``). The base ``_list`` / ``_list_all``
helpers accept a ``cursor_key`` kwarg to handle the difference.
"""

from __future__ import annotations

from collections.abc import AsyncIterator, Iterator

from kalshi.models.common import Page
from kalshi.models.incentive_programs import (
    IncentiveProgram,
    IncentiveProgramStatusLiteral,
    IncentiveProgramTypeLiteral,
)
from kalshi.resources._base import (
    AsyncResource,
    SyncResource,
    _params,
    _validate_limit,
    _validate_max_pages,
)


class IncentiveProgramsResource(SyncResource):
    """Sync incentive programs API.

    ``incentive_type`` renames the spec's ``type`` query param to avoid
    shadowing the Python built-in. Wire still sends ``?type=...``.
    """

    def list(
        self,
        *,
        status: IncentiveProgramStatusLiteral | None = None,
        incentive_type: IncentiveProgramTypeLiteral | None = None,
        incentive_description: str | None = None,
        limit: int | None = None,
        cursor: str | None = None,
        extra_headers: dict[str, str] | None = None,
    ) -> Page[IncentiveProgram]:
        _validate_limit(limit, hi=10000)
        params = _params(
            status=status,
            type=incentive_type,
            incentive_description=incentive_description,
            limit=limit,
            cursor=cursor,
        )
        return self._list(
            "/incentive_programs",
            IncentiveProgram,
            "incentive_programs",
            params=params,
            cursor_key="next_cursor",
            extra_headers=extra_headers,
        )

    def list_all(
        self,
        *,
        status: IncentiveProgramStatusLiteral | None = None,
        incentive_type: IncentiveProgramTypeLiteral | None = None,
        incentive_description: str | None = None,
        limit: int | None = None,
        max_pages: int | None = None,
        extra_headers: dict[str, str] | None = None,
    ) -> Iterator[IncentiveProgram]:
        _validate_max_pages(max_pages)
        _validate_limit(limit, hi=10000)
        params = _params(
            status=status,
            type=incentive_type,
            incentive_description=incentive_description,
            limit=limit,
        )
        return self._list_all(
            "/incentive_programs",
            IncentiveProgram,
            "incentive_programs",
            params=params,
            max_pages=max_pages,
            cursor_key="next_cursor",
            extra_headers=extra_headers,
        )


class AsyncIncentiveProgramsResource(AsyncResource):
    """Async incentive programs API."""

    async def list(
        self,
        *,
        status: IncentiveProgramStatusLiteral | None = None,
        incentive_type: IncentiveProgramTypeLiteral | None = None,
        incentive_description: str | None = None,
        limit: int | None = None,
        cursor: str | None = None,
        extra_headers: dict[str, str] | None = None,
    ) -> Page[IncentiveProgram]:
        _validate_limit(limit, hi=10000)
        params = _params(
            status=status,
            type=incentive_type,
            incentive_description=incentive_description,
            limit=limit,
            cursor=cursor,
        )
        return await self._list(
            "/incentive_programs",
            IncentiveProgram,
            "incentive_programs",
            params=params,
            cursor_key="next_cursor",
            extra_headers=extra_headers,
        )

    def list_all(
        self,
        *,
        status: IncentiveProgramStatusLiteral | None = None,
        incentive_type: IncentiveProgramTypeLiteral | None = None,
        incentive_description: str | None = None,
        limit: int | None = None,
        max_pages: int | None = None,
        extra_headers: dict[str, str] | None = None,
    ) -> AsyncIterator[IncentiveProgram]:
        """Returns an async iterator — use ``async for``."""
        _validate_max_pages(max_pages)
        _validate_limit(limit, hi=10000)
        params = _params(
            status=status,
            type=incentive_type,
            incentive_description=incentive_description,
            limit=limit,
        )
        return self._list_all(
            "/incentive_programs",
            IncentiveProgram,
            "incentive_programs",
            params=params,
            max_pages=max_pages,
            cursor_key="next_cursor",
            extra_headers=extra_headers,
        )
