"""Market positions channel message models."""
from __future__ import annotations

from pydantic import AliasChoices, BaseModel, Field

from kalshi.types import DollarDecimal, FixedPointCount


class MarketPositionsPayload(BaseModel):
    """Payload for market_positions messages (private channel).

    Dollar-denominated fields use :data:`DollarDecimal` per the CLAUDE.md
    convention. ``position`` is a fixed-point contract count (string).
    """

    user_id: str
    market_ticker: str
    position: FixedPointCount = Field(
        validation_alias=AliasChoices("position_fp", "position"),
    )
    position_cost: DollarDecimal = Field(
        validation_alias=AliasChoices("position_cost_dollars", "position_cost"),
    )
    realized_pnl: DollarDecimal = Field(
        validation_alias=AliasChoices("realized_pnl_dollars", "realized_pnl"),
    )
    fees_paid: DollarDecimal = Field(
        validation_alias=AliasChoices("fees_paid_dollars", "fees_paid"),
    )
    position_fee_cost: DollarDecimal = Field(
        validation_alias=AliasChoices("position_fee_cost_dollars", "position_fee_cost"),
    )
    volume: FixedPointCount = Field(
        validation_alias=AliasChoices("volume_fp", "volume"),
    )
    subaccount: int | None = None
    model_config = {"extra": "allow", "populate_by_name": True}


class MarketPositionsMessage(BaseModel):
    """Market positions update message. NO required seq."""

    type: str = "market_position"
    sid: int
    seq: int | None = None
    msg: MarketPositionsPayload
    model_config = {"extra": "allow", "populate_by_name": True}
