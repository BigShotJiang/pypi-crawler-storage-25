"""
simplemcp/cli.py — SimpleMCP V2 command-line interface

Commands:
  simplemcp install <path/to/kit.py>   Install a kit
  simplemcp remove <kit_name>          Remove a kit
  simplemcp start                      Start the server (loading bar)
  simplemcp start --verbose            Start the server with full log output
  simplemcp start stdio                Start stdio shim (all kits)
  simplemcp start stdio <kit_name>     Start stdio shim (single kit)
  simplemcp stop                       Stop the running server
  simplemcp restart                    Restart the server
  simplemcp rebuild                    Pull latest image from ghcr.io and restart
  simplemcp rebuild --local            Build image locally from bundled Dockerfile
  simplemcp rebuild --version <tag>    Pull a specific image version and restart
  simplemcp rebuild --verbose          Show full output during rebuild
  simplemcp list                       List installed kits and status
  simplemcp compat claude              Write installed kits to Claude Desktop config
  simplemcp compat lmstudio            Write installed kits to LM Studio config
  simplemcp compat vscode              Write installed kits to VS Code user config
  simplemcp compat openwebui <url> <api_key>  Register installed kits with OpenWebUI
  simplemcp config list <kit_name>     List config variables for a kit
  simplemcp config get <kit_name> <var>       Get a config value
  simplemcp config set <kit_name> <var> <val> Set a config value
  simplemcp config reset <kit_name> <var>     Reset a config value to default
  simplemcp browser start              Start the Chrome CDP broker
  simplemcp browser stop               Stop the Chrome CDP broker
  simplemcp browser status             Show broker and Chrome CDP status
"""

import sys

from simplemcp import config as cfg
from simplemcp import docker_manager as dm
from simplemcp import kit_manager as km


# ── Commands ──────────────────────────────────────────────────────────────────

def cmd_install(args: list[str]):
    if not args:
        print("Usage: simplemcp install <path/to/kit.py>")
        sys.exit(1)
    config = cfg.load()
    kits_dir = cfg.kits_dir()
    km.install_kit(args[0], config, kits_dir)
    cfg.save(config)


def cmd_remove(args: list[str]):
    if not args:
        print("Usage: simplemcp remove <kit_name>")
        sys.exit(1)
    config = cfg.load()
    kits_dir = cfg.kits_dir()
    km.remove_kit(args[0], config, kits_dir)
    cfg.save(config)


def cmd_start(args: list[str]):
    config = cfg.load()
    kits_dir = cfg.kits_dir()

    # Pull --verbose flag from args wherever it appears
    verbose = "--verbose" in args
    args = [a for a in args if a != "--verbose"]

    # stdio mode — shim against the already-running server
    if args and args[0].lower() == "stdio":
        kit_name = args[1] if len(args) > 1 else None
        if kit_name and kit_name not in config["kits"]:
            print(f"[simplemcp] Unknown kit: '{kit_name}'", file=sys.stderr)
            sys.exit(1)

        port = config.get("port")
        if not port:
            print("[simplemcp] No server running. Start one with: simplemcp start", file=sys.stderr)
            sys.exit(1)

        from simplemcp.stdio_shim import run_shim
        run_shim(port, kit_name)
        return

    # Server mode — start the container
    port = dm.start_simplemcp(config, kits_dir, verbose=verbose)
    config["port"] = port
    cfg.save(config)
    print(f"[simplemcp] Server running on http://localhost:{port}")
    print(f"[simplemcp] SimpleMCP protocol: http://localhost:{port}/list_kits")
    print(f"[simplemcp] MCP protocol:       http://localhost:{port}/mcp")


def cmd_stop(args: list[str]):
    config = cfg.load()
    try:
        import docker as docker_sdk
        client = docker_sdk.from_env()
    except Exception:
        print("[simplemcp] Could not connect to Docker daemon. Is Docker running?")
        sys.exit(1)

    result = dm.stop_all(client)

    if not result["stopped"]:
        print("[simplemcp] No running simplemcp containers found.")
    else:
        print("[simplemcp] Server stopped.")

    config["port"] = None
    config["container_id"] = None
    cfg.save(config)


def cmd_restart(args: list[str]):
    config = cfg.load()

    try:
        import docker as docker_sdk
        client = docker_sdk.from_env()
        dm.stop_all(client)
    except Exception:
        pass

    cmd_start([])


def cmd_rebuild(args: list[str]):
    """Stop the container, update the image, and restart."""
    config = cfg.load()
    client = dm.get_client()

    verbose = "--verbose" in args
    local = "--local" in args
    args_clean = [a for a in args if a not in ("--verbose", "--local")]

    # Parse --version <tag>
    version_tag = "latest"
    if "--version" in args_clean:
        idx = args_clean.index("--version")
        if idx + 1 < len(args_clean):
            version_tag = args_clean[idx + 1]
        else:
            print("[simplemcp] --version requires a tag argument, e.g. --version 2.1.0")
            sys.exit(1)

    # Stop running container
    dm.stop_all(client)
    config["port"] = None
    config["container_id"] = None
    cfg.save(config)

    # Remove existing image for a clean slate
    try:
        client.images.remove(dm.IMAGE_NAME, force=True)
        print(f"[simplemcp] Removed existing image '{dm.IMAGE_NAME}'.")
    except Exception:
        print(f"[simplemcp] No existing image to remove.")

    # Build or pull
    if local:
        print("[simplemcp] Building image locally from bundled Dockerfile...")
        dm.build_image(client)
    else:
        print(f"[simplemcp] Pulling image from ghcr.io (tag: {version_tag})...")
        if not dm.pull_image(client, tag=version_tag):
            print("[simplemcp] Pull failed. Try --local to build from the bundled Dockerfile.")
            sys.exit(1)

    kits_dir = cfg.kits_dir()
    port = dm.start_simplemcp(config, kits_dir, verbose=verbose)
    config["port"] = port
    cfg.save(config)
    print(f"[simplemcp] Server running on http://localhost:{port}")


def cmd_list(args: list[str]):
    config = cfg.load()
    port = config.get("port")

    running = False
    try:
        import docker as docker_sdk
        client = docker_sdk.from_env()
        container = dm.get_container(client)
        running = container is not None and container.status == "running"
    except Exception:
        pass

    if running and port:
        print(f"SimpleMCP Protocol: running on http://localhost:{port}\n")
    else:
        print("Server: OFF\n")

    if not config["kits"]:
        print("No kits installed.")
        return

    kit_ports = config.get("ports", {})

    for kit_stem, info in config["kits"].items():
        display_name = info.get("kit_name", kit_stem)
        desc = info.get("kit_description", "")
        enabled = info.get("enabled", True)
        if enabled and kit_stem in kit_ports:
            status = f"MCP {kit_ports[kit_stem]}"
        elif enabled:
            status = "enabled"
        else:
            status = "disabled"
        print(f"  [{status}] {display_name} ({kit_stem})")
        if desc:
            print(f"           {desc}")


# ── Entry point ───────────────────────────────────────────────────────────────

def cmd_config(args: list[str]):
    if len(args) < 2:
        print("Usage: simplemcp config <get|set|list|reset> <kit_name> [variable] [value]")
        sys.exit(1)

    subcommand = args[0].lower()
    kit_stem = args[1]

    config = cfg.load()
    if kit_stem not in config.get("kits", {}):
        print(f"[simplemcp] Unknown kit: '{kit_stem}'")
        sys.exit(1)

    # Load kit defaults from the installed kit file
    from simplemcp.kit_manager import parse_kit_metadata
    kits_dir = cfg.kits_dir()
    kit_file = kits_dir / f"{kit_stem}.py"
    defaults = parse_kit_metadata(kit_file).get("config", {}) if kit_file.exists() else {}
    saved = cfg.load_kit_config(kit_stem)

    if subcommand == "list":
        if not defaults:
            print(f"[simplemcp] Kit '{kit_stem}' has no config variables.")
            return
        print(f"Config for '{kit_stem}':")
        for key, default in defaults.items():
            current = saved.get(key, default)
            marker = " (default)" if key not in saved else ""
            print(f"  {key} = {current!r}{marker}")

    elif subcommand == "get":
        if len(args) < 3:
            print("Usage: simplemcp config get <kit_name> <variable>")
            sys.exit(1)
        var = args[2]
        if var not in defaults:
            print(f"[simplemcp] Unknown config variable '{var}' for kit '{kit_stem}'")
            sys.exit(1)
        print(saved.get(var, defaults[var]))

    elif subcommand == "set":
        if len(args) < 4:
            print("Usage: simplemcp config set <kit_name> <variable> <value>")
            sys.exit(1)
        var = args[2]
        value = args[3]
        if var not in defaults:
            print(f"[simplemcp] Unknown config variable '{var}' for kit '{kit_stem}'")
            sys.exit(1)
        saved[var] = value
        cfg.save_kit_config(kit_stem, saved)
        print(f"[simplemcp] Set {kit_stem}.{var} = {value!r}")

    elif subcommand == "reset":
        if len(args) < 3:
            print("Usage: simplemcp config reset <kit_name> <variable>")
            sys.exit(1)
        var = args[2]
        if var not in defaults:
            print(f"[simplemcp] Unknown config variable '{var}' for kit '{kit_stem}'")
            sys.exit(1)
        saved.pop(var, None)
        cfg.save_kit_config(kit_stem, saved)
        print(f"[simplemcp] Reset {kit_stem}.{var} to default ({defaults[var]!r})")

    else:
        print(f"[simplemcp] Unknown config subcommand: '{subcommand}'")
        print("Subcommands: get, set, list, reset")
        sys.exit(1)


def cmd_compat(args: list[str]):
    import json
    from pathlib import Path

    if not args:
        print("Usage: simplemcp compat <target> [options]")
        print("Targets: claude, lmstudio, openwebui <url> <api_key>")
        sys.exit(1)

    target = args[0].lower()

    if target == "claude":
        _compat_write_stdio_config(_claude_config_path(), "Claude Desktop", servers_key="mcpServers")
    elif target == "lmstudio":
        _compat_write_stdio_config(_lmstudio_config_path(), "LM Studio", servers_key="mcpServers")
    elif target == "vscode":
        _compat_write_stdio_config(_vscode_config_path(), "VS Code", servers_key="servers")
    elif target == "openwebui":
        if len(args) < 3:
            print("Usage: simplemcp compat openwebui <url> <api_key>")
            print("Example: simplemcp compat openwebui https://my-server:8086 sk-...")
            sys.exit(1)
        _compat_openwebui(args[1], args[2])
    else:
        print(f"[simplemcp] Unknown compat target: '{target}'")
        print("Available targets: claude, lmstudio, vscode, openwebui")
        sys.exit(1)


def _claude_config_path():
    import sys
    from pathlib import Path

    if sys.platform == "win32":
        base = Path.home() / "AppData" / "Roaming" / "Claude"
    elif sys.platform == "darwin":
        base = Path.home() / "Library" / "Application Support" / "Claude"
    else:
        base = Path.home() / ".config" / "Claude"

    return base / "claude_desktop_config.json"


def _lmstudio_config_path():
    from pathlib import Path
    return Path.home() / ".lmstudio" / "mcp.json"


def _vscode_config_path():
    from pathlib import Path
    if sys.platform == "win32":
        base = Path.home() / "AppData" / "Roaming" / "Code" / "User"
    elif sys.platform == "darwin":
        base = Path.home() / "Library" / "Application Support" / "Code" / "User"
    else:
        base = Path.home() / ".config" / "Code" / "User"
    return base / "mcp.json"


def _compat_write_stdio_config(config_path, app_name: str, servers_key: str = "mcpServers"):
    """
    Shared logic for writing simplemcp stdio entries to any app that uses
    the Claude Desktop mcpServers JSON format (Claude Desktop, LM Studio, Cursor, etc.)
    """
    import json

    config = cfg.load()
    kits = config.get("kits", {})

    if not kits:
        print(f"[simplemcp] No kits installed. Install kits first with: simplemcp install <kit.py>")
        sys.exit(1)

    existing = {}
    if config_path.exists():
        try:
            with open(config_path) as f:
                existing = json.load(f)
        except Exception as e:
            print(f"[simplemcp] Warning: could not read existing config ({e}), starting fresh.")

    mcp_servers = existing.get(servers_key, {})

    # Prune entries whose args match ["start", "stdio", <kit_stem>] but the
    # kit is no longer installed — avoids stale entries accumulating over time.
    stale = [
        name for name, entry in mcp_servers.items()
        if isinstance(entry.get("args"), list)
        and len(entry["args"]) >= 3
        and entry["args"][0] == "start"
        and entry["args"][1] == "stdio"
        and entry["args"][2] not in kits
    ]
    for name in stale:
        del mcp_servers[name]
        print(f"[simplemcp] Removed stale entry: {name}")

    # Build a set of kit stems already registered to avoid duplicates.
    # A registration counts if its args are ["start", "stdio", <kit_stem>].
    already_registered = {
        entry["args"][2]
        for entry in mcp_servers.values()
        if isinstance(entry.get("args"), list)
        and len(entry["args"]) >= 3
        and entry["args"][0] == "start"
        and entry["args"][1] == "stdio"
    }

    # Append entries for kits not already registered
    for kit_stem, info in kits.items():
        display_name = info.get("kit_name", kit_stem)
        if kit_stem in already_registered:
            print(f"[simplemcp] Skipped (already registered): {display_name}")
            continue
        mcp_servers[display_name] = {
            "command": "simplemcp",
            "args": ["start", "stdio", kit_stem],
        }
        print(f"[simplemcp] Added: {display_name} -> simplemcp start stdio {kit_stem}")

    existing[servers_key] = mcp_servers

    config_path.parent.mkdir(parents=True, exist_ok=True)
    with open(config_path, "w") as f:
        json.dump(existing, f, indent=2)

    print(f"[simplemcp] {app_name} config updated: {config_path}")
    print(f"[simplemcp] Restart {app_name} for changes to take effect.")


def _compat_openwebui(base_url: str, api_key: str):
    import json
    import urllib.request
    import urllib.error

    base_url = base_url.rstrip("/")
    config = cfg.load()
    kits = config.get("kits", {})

    if not kits:
        print("[simplemcp] No kits installed. Install kits first with: simplemcp install <kit.py>")
        sys.exit(1)

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
        "Accept": "application/json",
    }

    def _request(method: str, path: str, body=None) -> dict:
        url = f"{base_url}{path}"
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(url, data=data, headers=headers, method=method)
        try:
            with urllib.request.urlopen(req, timeout=15) as resp:
                return json.loads(resp.read())
        except urllib.error.HTTPError as e:
            print(f"[simplemcp] HTTP {e.code} on {method} {path}: {e.read().decode()}", file=sys.stderr)
            sys.exit(1)
        except Exception as e:
            print(f"[simplemcp] Request failed: {e}", file=sys.stderr)
            sys.exit(1)

    # Fetch current connections
    print(f"[simplemcp] Fetching current tool server connections from {base_url}...")
    current = _request("GET", "/api/v1/configs/tool_servers")
    connections = current.get("TOOL_SERVER_CONNECTIONS", [])

    # Read port assignments from config — written by assign_kit_port on simplemcp start.
    # These are the authoritative per-kit port assignments.
    kit_port_map = config.get("ports", {})

    if not config.get("port"):
        print("[simplemcp] Server is not running. Start it first with: simplemcp start", file=sys.stderr)
        sys.exit(1)

    # Warn if any kit is missing a port assignment (server hasn't been started yet)
    missing = [k for k in kits if k not in kit_port_map]
    if missing:
        print(f"[simplemcp] Warning: no port assigned for kits: {', '.join(missing)}", file=sys.stderr)
        print("[simplemcp] Run 'simplemcp start' first to assign ports, then re-run compat.", file=sys.stderr)
        sys.exit(1)

    # Build a map of existing SimpleMCP connections keyed by kit id so we can update in-place
    existing_by_id = {
        c["info"]["id"]: i
        for i, c in enumerate(connections)
        if isinstance(c.get("info"), dict) and c["info"].get("id") in kits
    }

    for kit_stem, info in kits.items():
        display_name = info.get("kit_name", kit_stem)
        description = info.get("kit_description", f"{display_name} MCP server")
        kit_port = kit_port_map[kit_stem]

        entry = {
            "url": f"http://localhost:{kit_port}/mcp",
            "path": "",
            "type": "mcp",
            "auth_type": "none",
            "headers": None,
            "key": "",
            "config": {
                "enable": True,
                "function_name_filter_list": "",
                "access_grants": [],
            },
            "spec_type": "url",
            "spec": "",
            "info": {
                "id": kit_stem,
                "name": display_name,
                "description": description,
            },
        }

        if kit_stem in existing_by_id:
            connections[existing_by_id[kit_stem]] = entry
            print(f"[simplemcp] Updated: {display_name} -> http://localhost:{kit_port}/mcp")
        else:
            connections.append(entry)
            print(f"[simplemcp] Added: {display_name} -> http://localhost:{kit_port}/mcp")

    # Remove stale SimpleMCP entries for kits no longer installed
    connections = [
        c for c in connections
        if not (isinstance(c.get("info"), dict) and c["info"].get("id") not in kits and c["info"].get("id") in existing_by_id)
    ]

    # POST the updated list back
    print(f"[simplemcp] Saving tool server connections...")
    _request("POST", "/api/v1/configs/tool_servers", {"TOOL_SERVER_CONNECTIONS": connections})
    print(f"[simplemcp] OpenWebUI tool servers updated successfully.")
    print(f"[simplemcp] You may need to refresh your OpenWebUI tab for changes to appear.")


def cmd_browser(args: list[str]):
    import shutil
    import subprocess
    import time
    import socket
    from pathlib import Path

    CDP_PORT = 9222
    BROKER_PORT = 9223
    PID_FILE = Path.home() / ".simplemcp" / "chrome_cdp.pid"
    BROKER_PID_FILE = Path.home() / ".simplemcp" / "browser_broker.pid"

    def _find_chrome() -> str | None:
        if sys.platform == "win32":
            import os
            candidates = [
                Path(os.environ.get("PROGRAMFILES", "C:\\Program Files")) / "Google" / "Chrome" / "Application" / "chrome.exe",
                Path(os.environ.get("PROGRAMFILES(X86)", "C:\\Program Files (x86)")) / "Google" / "Chrome" / "Application" / "chrome.exe",
                Path(os.environ.get("LOCALAPPDATA", "")) / "Google" / "Chrome" / "Application" / "chrome.exe",
            ]
            for c in candidates:
                if c.exists():
                    return str(c)
        elif sys.platform == "darwin":
            for c in ["/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
                      "/Applications/Chromium.app/Contents/MacOS/Chromium"]:
                if Path(c).exists():
                    return c
        else:
            for name in ("google-chrome", "google-chrome-stable", "chromium-browser", "chromium"):
                path = shutil.which(name)
                if path:
                    return path
        return None

    def _port_open(port: int) -> bool:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(2)
            return s.connect_ex(("localhost", port)) == 0

    def _cdp_alive() -> bool:
        return _port_open(CDP_PORT)

    def _broker_alive() -> bool:
        return _port_open(BROKER_PORT)

    subcommand = args[0].lower() if args else "status"

    if subcommand == "start":
        # Start Chrome if not already running
        if _cdp_alive():
            print(f"[simplemcp] Chrome CDP already running on port {CDP_PORT}.")
        else:
            chrome = _find_chrome()
            if not chrome:
                print("[simplemcp] Could not find Chrome. Install Chrome and try again.")
                sys.exit(1)

            user_data_dir = str(Path.home() / ".simplemcp" / "chrome-profile")
            print(f"[simplemcp] Launching Chrome with CDP on port {CDP_PORT}...")
            proc = subprocess.Popen(
                [chrome,
                 f"--remote-debugging-port={CDP_PORT}",
                 "--remote-debugging-address=0.0.0.0",
                 f"--user-data-dir={user_data_dir}",
                 "--no-first-run",
                 "--no-default-browser-check"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            PID_FILE.parent.mkdir(parents=True, exist_ok=True)
            PID_FILE.write_text(str(proc.pid))

            for _ in range(40):
                time.sleep(0.5)
                if _cdp_alive():
                    print(f"[simplemcp] Chrome ready on port {CDP_PORT}.")
                    break
            else:
                print("[simplemcp] Warning: Chrome did not become ready in time.", file=sys.stderr)
                return

        # Start broker if not already running
        if _broker_alive():
            print(f"[simplemcp] Broker already running on port {BROKER_PORT}.")
        else:
            print(f"[simplemcp] Starting CDP broker on port {BROKER_PORT}...")
            broker_proc = subprocess.Popen(
                [sys.executable, "-m", "simplemcp.browser_broker"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            BROKER_PID_FILE.write_text(str(broker_proc.pid))

            for _ in range(10):
                time.sleep(0.5)
                if _broker_alive():
                    print(f"[simplemcp] Broker ready on port {BROKER_PORT}.")
                    return
            print("[simplemcp] Warning: broker did not start in time.", file=sys.stderr)

    elif subcommand == "stop":
        for pid_file, label in [(PID_FILE, "Chrome"), (BROKER_PID_FILE, "broker")]:
            if pid_file.exists():
                try:
                    pid = int(pid_file.read_text().strip())
                    if sys.platform == "win32":
                        subprocess.run(["taskkill", "/F", "/PID", str(pid)],
                                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    else:
                        import os as _os, signal
                        _os.kill(pid, signal.SIGTERM)
                    pid_file.unlink(missing_ok=True)
                    print(f"[simplemcp] {label} stopped.")
                except Exception as e:
                    print(f"[simplemcp] Could not stop {label}: {e}", file=sys.stderr)
            else:
                print(f"[simplemcp] {label}: no PID file found.")

    elif subcommand == "status":
        print(f"[simplemcp] Chrome CDP: {'running on port ' + str(CDP_PORT) if _cdp_alive() else 'NOT running'}")
        print(f"[simplemcp] CDP broker: {'running on port ' + str(BROKER_PORT) if _broker_alive() else 'NOT running'}")
        if not _cdp_alive():
            print("[simplemcp] Run 'simplemcp browser start' to launch Chrome and the broker.")
    else:
        print(f"[simplemcp] Unknown browser subcommand: '{subcommand}'")
        print("Subcommands: start, stop, status")
        sys.exit(1)



def main():
    # Ensure UTF-8 output so spinner/bar characters render correctly on all terminals
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    if hasattr(sys.stderr, "reconfigure"):
        sys.stderr.reconfigure(encoding="utf-8")

    args = sys.argv[1:]

    if not args:
        print(__doc__)
        sys.exit(0)

    command = args[0].lower()
    rest = args[1:]

    if command == "install":
        cmd_install(rest)
    elif command == "remove":
        cmd_remove(rest)
    elif command == "start":
        cmd_start(rest)
    elif command == "stop":
        cmd_stop(rest)
    elif command == "restart":
        cmd_restart(rest)
    elif command == "rebuild":
        cmd_rebuild(rest)
    elif command == "list":
        cmd_list(rest)
    elif command == "compat":
        cmd_compat(rest)
    elif command == "config":
        cmd_config(rest)
    elif command == "browser":
        cmd_browser(rest)
    else:
        print(f"Unknown command: '{command}'")
        print("Commands: install, remove, start, stop, restart, rebuild, list, compat, config, browser")
        sys.exit(1)
