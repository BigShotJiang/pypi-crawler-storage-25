import logging

from .rich_log import wave_text

log = logging.getLogger("rich")


def _cli_execute():
    execute(wave_cheering=False)


def execute(wave_cheering: bool = True):
    if wave_cheering:
        wave_text("Hello you kind gents", wave_length=6, delay=0.01, loops=3)
    log.info("Hello, [bold green]World![/bold green]")
