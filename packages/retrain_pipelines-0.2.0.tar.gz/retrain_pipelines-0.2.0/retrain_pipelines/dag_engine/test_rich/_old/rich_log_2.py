import sys
import time
import math
import os

from rich.console import Console
from rich.text import Text
from rich.live import Live

from IPython import get_ipython
from IPython.display import display, clear_output, HTML

def _create_wave_frame_html(text, t, width):
    wave_frame = []
    text_length = len(text)
    for x in range(width):
        char_index = x % text_length
        wave = math.sin(x / 5 + t) + 1
        if wave > 1.8:
            wave_frame.append(f"<span class='wave-magenta'>{text[char_index].upper()}</span>")
        else:
            wave_frame.append(f"<span class='wave-yellow'>{text[char_index]}</span>")
    return ''.join(wave_frame)


def wave_text(text: str, wave_length: int = 6, delay: float = 0.1, loops: int = 2):
    length = len(text)
    base_color = "gold1 on grey11"
    wave_color = "purple on grey11"

    with Live(refresh_per_second=50) as live:
        for loop in range(loops):
            if loop < loops - 1:
                # For all but last loop: circular wrapping for smooth continuous wave
                for i in range(length):
                    rendered = Text()
                    for idx, char in enumerate(text):
                        dist = (idx - i) % length
                        if dist < wave_length:
                            if 2 <= dist <= length - 2:
                                display_char = char.upper()
                            else:
                                display_char = char
                            rendered.append(display_char, style=wave_color)
                        else:
                            rendered.append(char, style=base_color)
                    live.update(rendered)
                    time.sleep(delay)
            else:
                # For last loop: linear wave sliding off the end, no wrapping
                for i in range(length + wave_length):
                    rendered = Text()
                    for idx, char in enumerate(text):
                        if i <= idx < i + wave_length:
                            wave_pos = idx - i
                            if 2 <= wave_pos <= 4:
                                display_char = char.upper()
                            else:
                                display_char = char
                            rendered.append(display_char, style=wave_color)
                        else:
                            rendered.append(char, style=base_color)
                    live.update(rendered)
                    time.sleep(delay)

        time.sleep(0.4)
        live.stop()



def animate_wave(text, duration=4, fps=20):
    """
    Animated wave effect for both CLI (rich) and Jupyter (HTML).
    """
    in_jupyter = get_ipython() is not None and hasattr(sys, 'ps1')
    width = len(text)

    if in_jupyter:
        # CSS styles for Jupyter output
        styles = """
        <style>
        .wave-container {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 5px;
            background-color: black;
            font-family: monospace;
        }
        .wave-yellow { color: #debb00; }
        .wave-magenta { color: #9a2bab; font-weight: bold; }
        </style>
        """
        for t in range(int(duration * fps)):
            frame = _create_wave_frame_html(text, t * 0.2, width)
            clear_output(wait=True)
            display(HTML(styles + f"<div class='wave-container'>{frame}</div>"))
            time.sleep(1 / fps)
        # Final frame
        final_frame = text.lower()
        clear_output(wait=True)
        display(HTML(styles + f"<div class='wave-container'><span class='wave-yellow'>{final_frame}</span></div>"))
    else:
        console = Console()
        with Live(refresh_per_second=fps, console=console) as live:
            for t in range(int(duration * fps)):
                frame = _create_wave_frame_rich(text, t * 0.2, width)
                live.update(frame)
                time.sleep(1 / fps)
            # Final frame
            final_frame = Text(text.lower(), style="#c39c1a on black")
            # "#c2981a") #9a2bab") #972fa6") #902d9f") #8c239b") #881798")
            # "#c29a1d") #c2991a") #b18e15") #a8770f") #b68d1a") #b28f16") #c39c1a") #e3b600") #DEBB00") #d7b000") #cdaa00") #c5a600") #c5a500") #c3a402")
            # "#c39c1a on black") #c49c19 on black") # "#c59c17") #c59c16") #c29b1b") #c39c1b") #c59d19") #c49c17") #c19914") #bd9717") #c09a1a") #c19b1d") #c39d1d") #c39d1d ") #c49d19") #C3A600") #C3A000") #C3B700") #B8860B") #
            live.update(final_frame)
            time.sleep(0.5)
            live.stop()

# Example usage:
if __name__ == "__main__":
    animate_wave("Rich & Jupyter Wave!", duration=6, fps=20)







































































