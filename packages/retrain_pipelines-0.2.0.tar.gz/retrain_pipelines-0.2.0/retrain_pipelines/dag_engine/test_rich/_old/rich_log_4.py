import sys
import time
import math
import os

from rich.console import Console
from rich.text import Text
from rich.live import Live

from IPython import get_ipython
from IPython.display import display, clear_output, HTML


def wave_text(text: str, wave_length: int = 6, delay: float = 0.1, loops: int = 2):
    length = len(text)
    base_color = "gold1 on grey11"
    wave_color = "purple on grey11"

    with Live(refresh_per_second=50) as live:
        for loop in range(loops):
            if loop < loops - 1:
                # For all but last loop: circular wrapping for smooth continuous wave
                for i in range(length):
                    rendered = Text()
                    for idx, char in enumerate(text):
                        dist = (idx - i) % length
                        if dist < wave_length:
                            if 2 <= dist <= length - 2:
                                display_char = char.upper()
                            else:
                                display_char = char
                            rendered.append(display_char, style=wave_color)
                        else:
                            rendered.append(char, style=base_color)
                    live.update(rendered)
                    time.sleep(delay)
            else:
                # For last loop: linear wave sliding off the end, no wrapping
                for i in range(length + wave_length):
                    rendered = Text()
                    for idx, char in enumerate(text):
                        if i <= idx < i + wave_length:
                            wave_pos = idx - i
                            if 2 <= wave_pos <= 4:
                                display_char = char.upper()
                            else:
                                display_char = char
                            rendered.append(display_char, style=wave_color)
                        else:
                            rendered.append(char, style=base_color)
                    live.update(rendered)
                    time.sleep(delay)

        time.sleep(0.4)
        live.stop()



def animate_wave(text: str, wave_length: int = 6, delay: float = 0.1, loops: int = 2):
    """
    Animated wave effect for both CLI (rich) and Jupyter (HTML).
    """
    in_jupyter = get_ipython() is not None and hasattr(sys, 'ps1')
    width = len(text)

    if in_jupyter:
        # CSS styles for Jupyter output
        styles = """
        <style>
        .wave-container {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 5px;
            background-color: black;
            font-family: monospace;
        }
        .wave-yellow { color: #debb00; }
        .wave-magenta { color: #9a2bab; font-weight: bold; }
        </style>
        """
        frames = []
        length = len(text)
        for loop in range(loops):
            if loop < loops - 1:
                for i in range(length):
                    frame = ""
                    for idx, char in enumerate(text):
                        dist = (idx - i) % length
                        if dist < wave_length:
                            if 2 <= dist <= length - 2:
                                display_char = char.upper()
                            else:
                                display_char = char
                            frame += f"<span class='wave-magenta'>{display_char}</span>"
                        else:
                            frame += f"<span class='wave-yellow'>{char}</span>"
                    frames.append(frame)
            else:
                for i in range(length + wave_length):
                    frame = ""
                    for idx, char in enumerate(text):
                        if i <= idx < i + wave_length:
                            wave_pos = idx - i
                            if 2 <= wave_pos <= 4:
                                display_char = char.upper()
                            else:
                                display_char = char
                            frame += f"<span class='wave-magenta'>{display_char}</span>"
                        else:
                            frame += f"<span class='wave-yellow'>{char}</span>"
                    frames.append(frame)

        for frame in frames:
            clear_output(wait=True)
            display(HTML(styles + f"<div class='wave-container'>{frame}</div>"))
            time.sleep(delay)
        # Final frame
        final_frame = text.lower()
        clear_output(wait=True)
        display(HTML(styles + f"<div class='wave-container'><span class='wave-yellow'>{final_frame}</span></div>"))
    else:
        wave_text(text, wave_length, delay, loops)

# Example usage:
if __name__ == "__main__":
    animate_wave("Rich & Jupyter Wave!", duration=6, fps=20)







































































