import logging
import time

from rich.live import Live
from rich.logging import LogRender, RichHandler
from rich.text import Text

# https://rich.readthedocs.io/en/stable/markup.html


class CustomRichHandler(RichHandler):
    def get_level_text(self, record: logging.LogRecord) -> Text:
        # Override to hide level text for INFO logs
        if record.levelno == logging.INFO:
            return Text("")  # Return empty text to hide level
        return super().get_level_text(record)


FORMAT = "%(message)s"  # Define a basic log message format
DATEFMT = "%H:%M:%S"


# Configure the root logger to use RichHandler
logging.basicConfig(
    level="NOTSET",  # Log all levels
    format=FORMAT,  # Use simple message format
    datefmt=DATEFMT,  # Time format (optional)
    handlers=[CustomRichHandler(markup=True)],
)


def wave_text(text: str, wave_length: int = 6, delay: float = 0.1, loops: int = 2):
    length = len(text)
    base_color = "gold1 on grey11"
    wave_color = "purple on grey11"

    with Live(refresh_per_second=50) as live:
        for loop in range(loops):
            if loop < loops - 1:
                # For all but last loop: circular wrapping for smooth continuous wave
                for i in range(length):
                    rendered = Text()
                    for idx, char in enumerate(text):
                        dist = (idx - i) % length
                        if dist < wave_length:
                            if 2 <= dist <= length - 2:
                                display_char = char.upper()
                            else:
                                display_char = char
                            rendered.append(display_char, style=wave_color)
                        else:
                            rendered.append(char, style=base_color)
                    live.update(rendered)
                    time.sleep(delay)
            else:
                # For last loop: linear wave sliding off the end, no wrapping
                for i in range(length + wave_length):
                    rendered = Text()
                    for idx, char in enumerate(text):
                        if i <= idx < i + wave_length:
                            wave_pos = idx - i
                            if 2 <= wave_pos <= 4:
                                display_char = char.upper()
                            else:
                                display_char = char
                            rendered.append(display_char, style=wave_color)
                        else:
                            rendered.append(char, style=base_color)
                    live.update(rendered)
                    time.sleep(delay)

        time.sleep(0.4)
        live.stop()
