import logging
import time

# https://rich.readthedocs.io/en/stable/markup.html


if __name__ == "__main__":
    # python -m retrain_pipelines.dag_engine.test_rich.test_rich

    log = logging.getLogger("rich")

    # Log some messages with different levels and styles
    ## red, green, blue, yellow, magenta, cyan, white, black
    ## pink3, plum3, violet, gold3, light_goldenrod3, tan, misty_rose3, thistle3
    log.info("Hello, [bold green]World![/bold green]")
    time.sleep(0.2)
    log.info("Hello, [red on white]World![/red on white]")
    time.sleep(0.2)
    log.info("Hello, [rgb(0,255,255) on #af00ff]World![/rgb(0,255,255) on #af00ff]")
    time.sleep(0.2)

    log.error("[bold red blink]Server is shutting down![/]")

    # Log an exception with rich tracebacks
    try:
        1 / 0
    except Exception:
        log.exception("An error occurred!")
