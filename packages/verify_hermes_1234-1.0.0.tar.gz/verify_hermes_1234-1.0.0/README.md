# verify_hermes_1234

This package was uploaded as an ownership verification step
in response to a request by JFrog Security Research, related
to the hermes-px incident analysis.

The PyPI account used to upload this package is the same account
that was compromised and used to publish hermes-px without the
account owner's knowledge or consent.
