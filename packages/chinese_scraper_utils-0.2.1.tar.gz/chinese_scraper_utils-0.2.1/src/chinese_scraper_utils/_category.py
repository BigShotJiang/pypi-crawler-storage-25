"""中文活动类别猜测。"""

CATEGORY_ALIASES = {
    "漫展": "漫展", "同人展": "同人展", "演唱会": "演唱会",
    "舞台剧": "舞台剧", "音乐会": "音乐会", "展览": "展览",
    "二次元": "漫展", "cosplay": "漫展", "动漫": "漫展",
    "主题餐厅": "展览", "主题店": "展览", "授权店": "展览",
    "咖啡": "展览", "快闪": "展览", "谷子": "展览",
    "only": "同人展", "ONLY": "同人展", "同人": "同人展",
    "画展": "展览", "纪念展": "展览", "原画展": "展览",
    "声优": "演唱会", "见面会": "演唱会", "live": "演唱会", "Live": "演唱会",
    "音乐节": "演唱会", "地下偶像": "演唱会", "mixup": "演唱会",
    "游乐园": "漫展", "嘉年华": "漫展", "面基": "漫展",
    "痛岛": "漫展", "cafe": "展览", "茶会": "展览", "玩偶": "展览",
}


def guess_category(title: str) -> str:
    """根据标题猜测活动类别。使用最长匹配优先，避免短关键词覆盖长关键词。"""
    t = title.lower().replace(" ", "")
    # 按 alias 长度降序排列：长关键词优先匹配（"二次元" 优于 "元"）
    best_match = ""
    best_cat = "其他"
    for alias, cat in CATEGORY_ALIASES.items():
        if alias.lower() in t and len(alias) > len(best_match):
            best_match = alias
            best_cat = cat
    return best_cat
