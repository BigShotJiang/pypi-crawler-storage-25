# Exceptions

::: etcion.exceptions
