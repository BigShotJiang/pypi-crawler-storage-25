# Relationships

::: etcion.metamodel.relationships
