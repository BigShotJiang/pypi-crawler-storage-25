"""
_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_processes urls *

:details: lara_django_processes urls module.
         - add app specific urls here
         -
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: -
________________________________________________________________________
"""

from django.urls import path
from django.views.generic import TemplateView
from django_socio_grpc.settings import grpc_settings

from . import views

# Add your {cookiecutter.project_slug}} urls here.


# !! this sets the apps namespace to be used in the template
app_name = "lara_django_processes"

# companies and institutions should also be added
# the 'name' attribute is used in templates to address the url independent of the view
# it is used/called by the {% url %} template tag
urlpatterns = [
    # path('', views.index, name='index'),
    # ~ path(r'^processlist$', views.processList, name='process_list'),
    # ~ path(r'^(?P<process_id>[0-9]+)/$', views.processDetails, name='process_details'),
    path("method/list/", views.MethodSingleTableView.as_view(), name="method-list"),
    path("method/create/", views.MethodCreateView.as_view(), name="method-create"),
    path("method/update/<uuid:pk>", views.MethodUpdateView.as_view(), name="method-update"),
    path("method/delete/<uuid:pk>", views.MethodDeleteView.as_view(), name="method-delete"),
    path("method/<uuid:pk>/", views.MethodDetailView.as_view(), name="method-detail"),
    path("method-instance/list/", views.MethodInstanceSingleTableView.as_view(), name="method-instance-list"),
    path("method-instance/create/", views.MethodInstanceCreateView.as_view(), name="method-instance-create"),
    path("method-instance/update/<uuid:pk>", views.MethodInstanceUpdateView.as_view(), name="method-instance-update"),
    path("method-instance/delete/<uuid:pk>", views.MethodInstanceDeleteView.as_view(), name="method-instance-delete"),
    path("method-instance/<uuid:pk>/", views.MethodInstanceDetailView.as_view(), name="method-instance-detail"),
    path("procedure/list/", views.ProcedureSingleTableView.as_view(), name="procedure-list"),
    path("procedure/create/", views.ProcedureCreateView.as_view(), name="procedure-create"),
    path("procedure/update/<uuid:pk>", views.ProcedureUpdateView.as_view(), name="procedure-update"),
    path("procedure/delete/<uuid:pk>", views.ProcedureDeleteView.as_view(), name="procedure-delete"),
    path("procedure/<uuid:pk>/", views.ProcedureDetailView.as_view(), name="procedure-detail"),
    path("procedure-instance/list/", views.ProcedureInstanceSingleTableView.as_view(), name="procedure-instance-list"),
    path("procedure-instance/create/", views.ProcedureInstanceCreateView.as_view(), name="procedure-instance-create"),
    path(
        "procedure-instance/update/<uuid:pk>",
        views.ProcedureInstanceUpdateView.as_view(),
        name="procedure-instance-update",
    ),
    path(
        "procedure-instance/delete/<uuid:pk>",
        views.ProcedureInstanceDeleteView.as_view(),
        name="procedure-instance-delete",
    ),
    path(
        "procedure-instance/<uuid:pk>/", views.ProcedureInstanceDetailView.as_view(), name="procedure-instance-detail"
    ),
    path("process/list/", views.ProcessSingleTableView.as_view(), name="process-list"),
    path("process/create/", views.ProcessCreateView.as_view(), name="process-create"),
    path("process/update/<uuid:pk>", views.ProcessUpdateView.as_view(), name="process-update"),
    path("process/delete/<uuid:pk>", views.ProcessDeleteView.as_view(), name="process-delete"),
    path("process/<uuid:pk>/", views.ProcessDetailView.as_view(), name="process-detail"),
    path("process-instance/list/", views.ProcessInstanceSingleTableView.as_view(), name="process-instance-list"),
    path("process-instance/create/", views.ProcessInstanceCreateView.as_view(), name="process-instance-create"),
    path(
        "process-instance/update/<uuid:pk>", views.ProcessInstanceUpdateView.as_view(), name="process-instance-update"
    ),
    path(
        "process-instance/delete/<uuid:pk>", views.ProcessInstanceDeleteView.as_view(), name="process-instance-delete"
    ),
    path("process-instance/<uuid:pk>/", views.ProcessInstanceDetailView.as_view(), name="process-instance-detail"),
    path("search/", views.searchForm, name="searchForm"),
    path("search-results/", views.search, name="search"),
    path("results/", views.results, name="results"),
    path(
        "generator/", TemplateView.as_view(template_name="process_generator/index.html"), name="process-generator-index"
    ),
    path("", views.ProcessSingleTableView.as_view(), name="processes-root"),
]

# register handlers in settings
grpc_settings.user_settings["GRPC_HANDLERS"] += ["lara_django_processes.grpc.handlers.grpc_handlers"]
