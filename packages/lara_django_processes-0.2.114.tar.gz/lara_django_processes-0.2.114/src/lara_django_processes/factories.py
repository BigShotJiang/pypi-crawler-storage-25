"""
Factory definitions for ``lara_django_processes`` models.

Factories are only available when ``factory_boy`` is installed (dev/test environments).
This module can be safely imported in production - factories will simply be ``None``.
"""

# isort: skip_file

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from factory.django import DjangoModelFactory  # type: ignore[import-not-found]

try:
    from factory import Faker, LazyFunction, Sequence, SubFactory  # type: ignore[import-not-found]
    from factory.django import DjangoModelFactory  # type: ignore[import-not-found]

    from lara_django_processes.models import (
        Method,
        MethodInstance,
        ProcMethodClass,
        Process,
        ProcessInstance,
        ProcessStepClass,
        Procedure,
        ProcedureInstance,
    )

    class ProcMethodClassFactory(DjangoModelFactory):
        """Factory for creating ``ProcMethodClass`` test instances."""

        class Meta:
            """Factory metadata."""

            model = ProcMethodClass
            django_get_or_create = ("name",)

        name = Sequence(lambda n: f"TestProcMethodClass{n}")
        iri = Sequence(lambda n: f"http://example.com/proc-method-class/{n}")
        proc_method_schema = LazyFunction(dict)
        description = Faker("sentence")

    class ProcessStepClassFactory(DjangoModelFactory):
        """Factory for creating ``ProcessStepClass`` test instances."""

        class Meta:
            """Factory metadata."""

            model = ProcessStepClass
            django_get_or_create = ("name",)

        name = Sequence(lambda n: f"TestProcessStepClass{n}")
        iri = Sequence(lambda n: f"http://example.com/process-step-class/{n}")
        processstep_schema = LazyFunction(dict)
        description = Faker("sentence")

    class MethodFactory(DjangoModelFactory):
        """Factory for creating ``Method`` test instances."""

        class Meta:
            """Factory metadata."""

            model = Method
            django_get_or_create = ("name",)

        method_class = SubFactory(ProcMethodClassFactory)
        name_display = Sequence(lambda n: f"Test Method {n}")
        name = Sequence(lambda n: f"test_method_{n}")
        iri = Sequence(lambda n: f"http://example.com/method/{n}")
        version = "0.0.1"
        description = Faker("sentence")

    class ProcedureFactory(DjangoModelFactory):
        """Factory for creating ``Procedure`` test instances."""

        class Meta:
            """Factory metadata."""

            model = Procedure
            django_get_or_create = ("name",)

        procedure_class = SubFactory(ProcMethodClassFactory)
        name_display = Sequence(lambda n: f"Test Procedure {n}")
        name = Sequence(lambda n: f"test_procedure_{n}")
        iri = Sequence(lambda n: f"http://example.com/procedure/{n}")
        version = "0.0.1"
        description = Faker("sentence")

    class ProcessFactory(DjangoModelFactory):
        """Factory for creating ``Process`` test instances."""

        class Meta:
            """Factory metadata."""

            model = Process
            django_get_or_create = ("name",)

        process_class = SubFactory(ProcMethodClassFactory)
        name_display = Sequence(lambda n: f"Test Process {n}")
        name = Sequence(lambda n: f"test_process_{n}")
        iri = Sequence(lambda n: f"http://example.com/process/{n}")
        version = "0.0.1"
        description = Faker("sentence")

    class MethodInstanceFactory(DjangoModelFactory):
        """Factory for creating ``MethodInstance`` test instances."""

        class Meta:
            """Factory metadata."""

            model = MethodInstance
            django_get_or_create = ("name",)

        method_base = SubFactory(MethodFactory)
        name_display = Sequence(lambda n: f"Test Method Instance {n}")
        name = Sequence(lambda n: f"test_method_instance_{n}")
        iri = Sequence(lambda n: f"http://example.com/method-instance/{n}")
        version = "0.0.1"
        description = Faker("sentence")

    class ProcedureInstanceFactory(DjangoModelFactory):
        """Factory for creating ``ProcedureInstance`` test instances."""

        class Meta:
            """Factory metadata."""

            model = ProcedureInstance
            django_get_or_create = ("name",)

        procedure_base = SubFactory(ProcedureFactory)
        name_display = Sequence(lambda n: f"Test Procedure Instance {n}")
        name = Sequence(lambda n: f"test_procedure_instance_{n}")
        iri = Sequence(lambda n: f"http://example.com/procedure-instance/{n}")
        version = "0.0.1"
        description = Faker("sentence")

    class ProcessInstanceFactory(DjangoModelFactory):
        """Factory for creating ``ProcessInstance`` test instances."""

        class Meta:
            """Factory metadata."""

            model = ProcessInstance
            django_get_or_create = ("name",)

        process_base = SubFactory(ProcessFactory)
        name_display = Sequence(lambda n: f"Test Process Instance {n}")
        name = Sequence(lambda n: f"test_process_instance_{n}")
        iri = Sequence(lambda n: f"http://example.com/process-instance/{n}")
        version = "0.0.1"
        description = Faker("sentence")

    def create_demo_data(n: int = 1) -> None:
        """Create a small demo dataset for local testing."""
        ProcMethodClassFactory.create_batch(n)
        ProcessStepClassFactory.create_batch(n)
        MethodFactory.create_batch(n)
        ProcedureFactory.create_batch(n)
        ProcessFactory.create_batch(n)
        MethodInstanceFactory.create_batch(n)
        ProcedureInstanceFactory.create_batch(n)
        ProcessInstanceFactory.create_batch(n)
except ImportError:
    ProcMethodClassFactory = None  # type: ignore[misc,assignment]
    ProcessStepClassFactory = None  # type: ignore[misc,assignment]
    MethodFactory = None  # type: ignore[misc,assignment]
    ProcedureFactory = None  # type: ignore[misc,assignment]
    ProcessFactory = None  # type: ignore[misc,assignment]
    MethodInstanceFactory = None  # type: ignore[misc,assignment]
    ProcedureInstanceFactory = None  # type: ignore[misc,assignment]
    ProcessInstanceFactory = None  # type: ignore[misc,assignment]

    def create_demo_data(n: int = 1) -> None:
        """Stub function when ``factory_boy`` is not available."""
        raise RuntimeError("factory_boy is not installed - cannot create demo data")
