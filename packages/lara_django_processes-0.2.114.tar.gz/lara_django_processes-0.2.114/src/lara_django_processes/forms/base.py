"""
Shared widgets for lara_django_processes forms.

:PROJECT: LARAsuite
:details: Custom widgets and renderers for forms.
:authors: mark doerr <mark.doerr@uni-greifswald.de>
"""

from typing import ClassVar

from django import forms
from django.forms.renderers import TemplatesSetting

from ..models import ExtraData, ProcMethodClass


class CustomFormRenderer(TemplatesSetting):
    """Custom form renderer using custom field template."""

    field_template_name = "lara_django_processes/forms/field_group.html"


class SearchableSelectMultiple(forms.SelectMultiple):
    """Custom widget for searchable multi-select using Alpine.js."""

    template_name = "lara_django_processes/widgets/searchable_select_multiple.html"

    def __init__(self, attrs=None):
        """
        Initialize the widget with default searchable attributes.

        Args:
            attrs: Optional dictionary of HTML attributes for the widget.

        """
        default_attrs = {"class": "searchable-select-multiple"}
        if attrs:
            default_attrs.update(attrs)
        super().__init__(attrs=default_attrs)


class MethodClassCreateForm(forms.ModelForm):
    """Form for creating a new method class."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = ProcMethodClass
        fields = ("name", "iri", "description", "tags")

        text_fields_required: ClassVar = ("name",)
        url_fields: ClassVar = ("iri",)
        textarea_fields: ClassVar = ("description",)

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            "tags": SearchableSelectMultiple(),
        }


class MethodClassUpdateForm(forms.ModelForm):
    """Form for updating an existing method class."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = ProcMethodClass
        fields = ("name", "iri", "description", "tags")

        text_fields_required: ClassVar = ("name",)
        url_fields: ClassVar = ("iri",)
        textarea_fields: ClassVar = ("description",)

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            "tags": SearchableSelectMultiple(),
        }


class ExtraDataCreateForm(forms.ModelForm):
    """Form for creating a new ExtraData instance with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = ExtraData

        fields = (
            "data_type",
            "name",
            "name_full",
            "name_display",
            "namespace",
            "version",
            "hash_sha256",
            "data_json",
            "media_type",
            "iri",
            "url",
            "description",
            "image",
            "file",
        )

        # Categorize fields by widget type
        text_fields_required: ClassVar = ("name",)

        text_fields: ClassVar = (
            "name_full",
            "name_display",
            "version",
            "hash_sha256",
        )

        textarea_fields: ClassVar = (
            "data_json",
            "description",
        )

        url_fields: ClassVar = ("iri", "url")

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "data_type": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "namespace": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "media_type": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "image": forms.ClearableFileInput(attrs={"class": "file-input file-input-sm file-input-bordered w-full"}),
            "file": forms.ClearableFileInput(attrs={"class": "file-input file-input-sm file-input-bordered w-full"}),
        }


class ExtraDataUpdateForm(forms.ModelForm):
    """Form for updating an existing ExtraData instance with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = ExtraData

        fields = (
            "data_type",
            "name",
            "name_full",
            "name_display",
            "namespace",
            "version",
            "data_json",
            "media_type",
            "iri",
            "url",
            "description",
            "image",
            "file",
        )

        # Categorize fields by widget type
        text_fields_required: ClassVar = ("name",)

        text_fields: ClassVar = (
            "name_full",
            "name_display",
            "version",
        )

        textarea_fields: ClassVar = (
            "data_json",
            "description",
        )

        url_fields: ClassVar = ("iri", "url")

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "data_type": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "namespace": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "media_type": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "image": forms.ClearableFileInput(attrs={"class": "file-input file-input-sm file-input-bordered w-full"}),
            "file": forms.ClearableFileInput(attrs={"class": "file-input file-input-sm file-input-bordered w-full"}),
        }
