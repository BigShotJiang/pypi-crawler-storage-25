"""
Process and ProcessInstance forms for lara_django_processes.

:PROJECT: LARAsuite
:details: Forms for Process, ProcessInstance, ProcessStepClass, and ProcessInstanceStep models.
:authors: mark doerr <mark.doerr@uni-greifswald.de>
"""

from typing import ClassVar

from django import forms

from ..models import Process, ProcessInstance, ProcessInstanceStep, ProcessStepClass
from .base import CustomFormRenderer, SearchableSelectMultiple


class ProcessStepClassCreateForm(forms.ModelForm):
    """Form for creating a new process step class."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = ProcessStepClass
        fields = ("name", "iri", "description")

        text_fields_required: ClassVar = ("name",)
        url_fields: ClassVar = ("iri",)
        textarea_fields: ClassVar = ("description",)

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
        }


class ProcessStepClassUpdateForm(forms.ModelForm):
    """Form for updating an existing process step class."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = ProcessStepClass
        fields = ("name", "iri", "description")

        text_fields_required: ClassVar = ("name",)
        url_fields: ClassVar = ("iri",)
        textarea_fields: ClassVar = ("description",)

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
        }


class ProcessCreateForm(forms.ModelForm):
    """Form for creating a new process with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Process

        fields = (
            "name_display",
            "namespace",
            "name",
            "process_class",
            "procedures",
            "creators",
            "parts",
            "devices",
            "device_setups",
            "labware",
            "substances",
            "polymers",
            "mixtures",
            "organisms",
            "samples",
            "sample_sets",
            "tags",
            "uri",
            "version",
            "parameters",
            "resources_external",
            "data_extra",
            "icon",
            "description",
            "remarks",
            "iri",
            "pid",
            "pac_id",
            "process_json",
            "process_file",
            "graph_representation",
            "media_type",
        )

        # Categorize fields by widget type
        text_fields_required: ClassVar = ("name_display",)

        text_fields: ClassVar = (
            "name",
            "version",
            "icon",
            "pid",
        )

        textarea_fields: ClassVar = (
            "parameters",
            "description",
            "remarks",
            "process_json",
            "graph_representation",
        )

        url_fields: ClassVar = ("uri", "iri", "pac_id")

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "namespace": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "process_class": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "media_type": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "procedures": SearchableSelectMultiple(),
            "creators": SearchableSelectMultiple(),
            "parts": SearchableSelectMultiple(),
            "devices": SearchableSelectMultiple(),
            "device_setups": SearchableSelectMultiple(),
            "labware": SearchableSelectMultiple(),
            "substances": SearchableSelectMultiple(),
            "polymers": SearchableSelectMultiple(),
            "mixtures": SearchableSelectMultiple(),
            "organisms": SearchableSelectMultiple(),
            "samples": SearchableSelectMultiple(),
            "sample_sets": SearchableSelectMultiple(),
            "resources_external": SearchableSelectMultiple(),
            "data_extra": SearchableSelectMultiple(),
            "tags": SearchableSelectMultiple(),
            "process_file": forms.ClearableFileInput(
                attrs={"class": "file-input file-input-sm file-input-bordered w-full"}
            ),
        }


class ProcessUpdateForm(forms.ModelForm):
    """Form for updating an existing process with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Process

        fields = (
            "name_display",
            "namespace",
            "name",
            "process_class",
            "procedures",
            "creators",
            "parts",
            "devices",
            "device_setups",
            "labware",
            "substances",
            "polymers",
            "mixtures",
            "organisms",
            "samples",
            "sample_sets",
            "tags",
            "uri",
            "version",
            "parameters",
            "resources_external",
            "data_extra",
            "icon",
            "description",
            "remarks",
            "iri",
            "pid",
            "pac_id",
            "process_json",
            "process_file",
            "graph_representation",
            "media_type",
        )

        # Categorize fields by widget type
        text_fields_required: ClassVar = ("name_display",)

        text_fields: ClassVar = (
            "name",
            "version",
            "icon",
            "pid",
        )

        textarea_fields: ClassVar = (
            "parameters",
            "description",
            "remarks",
            "process_json",
            "graph_representation",
        )

        url_fields: ClassVar = ("uri", "iri", "pac_id")

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "namespace": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "process_class": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "media_type": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "procedures": SearchableSelectMultiple(),
            "creators": SearchableSelectMultiple(),
            "parts": SearchableSelectMultiple(),
            "devices": SearchableSelectMultiple(),
            "device_setups": SearchableSelectMultiple(),
            "labware": SearchableSelectMultiple(),
            "substances": SearchableSelectMultiple(),
            "polymers": SearchableSelectMultiple(),
            "mixtures": SearchableSelectMultiple(),
            "organisms": SearchableSelectMultiple(),
            "samples": SearchableSelectMultiple(),
            "sample_sets": SearchableSelectMultiple(),
            "resources_external": SearchableSelectMultiple(),
            "data_extra": SearchableSelectMultiple(),
            "tags": SearchableSelectMultiple(),
            "process_file": forms.ClearableFileInput(
                attrs={"class": "file-input file-input-sm file-input-bordered w-full"}
            ),
        }


class ProcessInstanceStepCreateForm(forms.ModelForm):
    """Form for creating a new process instance step."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = ProcessInstanceStep

        fields = (
            "process_step_base",
            "process_instance",
            "status",
            "datetime_start",
            "datetime_end",
            "procedure_instance",
            "parameters",
            "simulation",
        )

        textarea_fields: ClassVar = ("parameters",)

        widgets: ClassVar = {
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            "process_step_base": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "process_instance": forms.Select(attrs={"class": "select select-sm select-bordered w-full", "required": True}),
            "status": forms.Select(attrs={"class": "select select-sm select-bordered w-full", "required": True}),
            "procedure_instance": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "datetime_start": forms.DateTimeInput(attrs={"class": "input input-sm input-bordered w-full", "type": "datetime-local"}),
            "datetime_end": forms.DateTimeInput(attrs={"class": "input input-sm input-bordered w-full", "type": "datetime-local"}),
            "simulation": forms.CheckboxInput(attrs={"class": "checkbox"}),
        }


class ProcessInstanceStepUpdateForm(forms.ModelForm):
    """Form for updating an existing process instance step."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = ProcessInstanceStep

        fields = (
            "process_step_base",
            "process_instance",
            "status",
            "datetime_start",
            "datetime_end",
            "procedure_instance",
            "parameters",
            "simulation",
        )

        textarea_fields: ClassVar = ("parameters",)

        widgets: ClassVar = {
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            "process_step_base": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "process_instance": forms.Select(attrs={"class": "select select-sm select-bordered w-full", "required": True}),
            "status": forms.Select(attrs={"class": "select select-sm select-bordered w-full", "required": True}),
            "procedure_instance": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "datetime_start": forms.DateTimeInput(attrs={"class": "input input-sm input-bordered w-full", "type": "datetime-local"}),
            "datetime_end": forms.DateTimeInput(attrs={"class": "input input-sm input-bordered w-full", "type": "datetime-local"}),
            "simulation": forms.CheckboxInput(attrs={"class": "checkbox"}),
        }


class ProcessInstanceCreateForm(forms.ModelForm):
    """Form for creating a new process instance with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = ProcessInstance

        fields = (
            "process_base",
            "name_display",
            "namespace",
            "name",
            "creators",
            "part_instances",
            "device_instances",
            "device_setup_instances",
            "labware_instances",
            "substance_instances",
            "polymer_instances",
            "mixture_instances",
            "organism_instances",
            "samples",
            "sample_sets",
            "tags",
            "uri",
            "version",
            "parameters",
            "resources_external",
            "data_extra",
            "icon",
            "description",
            "remarks",
            "iri",
            "pid",
            "process_json",
            "process_file",
            "media_type",
            "status",
        )

        # Categorize fields by widget type
        text_fields: ClassVar = (
            "name_display",
            "name",
            "version",
            "icon",
            "pid",
        )

        textarea_fields: ClassVar = (
            "parameters",
            "description",
            "remarks",
            "process_json",
        )

        url_fields: ClassVar = ("uri", "iri")

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "process_base": forms.Select(attrs={"class": "select select-sm select-bordered w-full", "required": True}),
            "namespace": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "status": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "media_type": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "creators": SearchableSelectMultiple(),
            "part_instances": SearchableSelectMultiple(),
            "device_instances": SearchableSelectMultiple(),
            "device_setup_instances": SearchableSelectMultiple(),
            "labware_instances": SearchableSelectMultiple(),
            "substance_instances": SearchableSelectMultiple(),
            "polymer_instances": SearchableSelectMultiple(),
            "mixture_instances": SearchableSelectMultiple(),
            "organism_instances": SearchableSelectMultiple(),
            "samples": SearchableSelectMultiple(),
            "sample_sets": SearchableSelectMultiple(),
            "resources_external": SearchableSelectMultiple(),
            "data_extra": SearchableSelectMultiple(),
            "tags": SearchableSelectMultiple(),
            "process_file": forms.ClearableFileInput(
                attrs={"class": "file-input file-input-sm file-input-bordered w-full"}
            ),
        }


class ProcessInstanceUpdateForm(forms.ModelForm):
    """Form for updating an existing process instance with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = ProcessInstance

        fields = (
            "process_base",
            "namespace",
            "name",
            "uri",
            "version",
            "parameters",
            "status",
            "resources_external",
            "data_extra",
            "tags",
            "icon",
            "description",
            "remarks",
            "iri",
            "pid",
            "process_json",
            "media_type",
            "process_file",
        )

        # Categorize fields by widget type
        text_fields: ClassVar = (
            "name",
            "version",
            "icon",
            "pid",
        )

        textarea_fields: ClassVar = (
            "parameters",
            "description",
            "remarks",
            "process_json",
        )

        url_fields: ClassVar = ("uri", "iri")

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "process_base": forms.Select(attrs={"class": "select select-sm select-bordered w-full", "required": True}),
            "namespace": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "status": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "media_type": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "resources_external": SearchableSelectMultiple(),
            "data_extra": SearchableSelectMultiple(),
            "tags": SearchableSelectMultiple(),
            "process_file": forms.ClearableFileInput(
                attrs={"class": "file-input file-input-sm file-input-bordered w-full"}
            ),
        }
