"""
Forms package for lara_django_processes.

:PROJECT: LARAsuite
:details: Aggregates all form classes from sub-modules.
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: Auto-generated imports - run forms_generator to update
"""

from .base import (
    CustomFormRenderer,
    ExtraDataCreateForm,
    ExtraDataUpdateForm,
    MethodClassCreateForm,
    MethodClassUpdateForm,
    SearchableSelectMultiple,
)
from .method import (
    MethodCreateForm,
    MethodInstanceCreateForm,
    MethodInstanceUpdateForm,
    MethodUpdateForm,
)
from .procedure import (
    ProcedureCreateForm,
    ProcedureInstanceCreateForm,
    ProcedureInstanceUpdateForm,
    ProcedureUpdateForm,
)
from .process import (
    ProcessCreateForm,
    ProcessInstanceCreateForm,
    ProcessInstanceStepCreateForm,
    ProcessInstanceStepUpdateForm,
    ProcessInstanceUpdateForm,
    ProcessStepClassCreateForm,
    ProcessStepClassUpdateForm,
    ProcessUpdateForm,
)

__all__ = [
    # Widgets
    "CustomFormRenderer",
    # ExtraData forms
    "ExtraDataCreateForm",
    "ExtraDataUpdateForm",
    "MethodClassCreateForm",
    "MethodClassUpdateForm",
    # Method forms
    "MethodCreateForm",
    "MethodInstanceCreateForm",
    "MethodInstanceUpdateForm",
    "MethodUpdateForm",
    # Procedure forms
    "ProcedureCreateForm",
    "ProcedureInstanceCreateForm",
    "ProcedureInstanceUpdateForm",
    "ProcedureUpdateForm",
    "ProcessCreateForm",
    "ProcessInstanceCreateForm",
    "ProcessInstanceStepCreateForm",
    "ProcessInstanceStepUpdateForm",
    "ProcessInstanceUpdateForm",
    # Process forms
    "ProcessStepClassCreateForm",
    "ProcessStepClassUpdateForm",
    "ProcessUpdateForm",
    "SearchableSelectMultiple",
]
