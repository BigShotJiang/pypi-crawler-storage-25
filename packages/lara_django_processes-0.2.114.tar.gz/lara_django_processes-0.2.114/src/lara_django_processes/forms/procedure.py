"""
Procedure and ProcedureInstance forms for lara_django_processes.

:PROJECT: LARAsuite
:details: Forms for Procedure and ProcedureInstance models.
:authors: mark doerr <mark.doerr@uni-greifswald.de>
"""

from typing import ClassVar

from django import forms

from ..models import Procedure, ProcedureInstance
from .base import CustomFormRenderer, SearchableSelectMultiple


class ProcedureCreateForm(forms.ModelForm):
    """Form for creating a new procedure with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Procedure

        fields = (
            "name_display",
            "namespace",
            "name",
            "procedure_class",
            "method",
            "creators",
            "parts",
            "devices",
            "device_setups",
            "labware",
            "substances",
            "polymers",
            "mixtures",
            "organisms",
            "samples",
            "sample_sets",
            "tags",
            "uri",
            "version",
            "parameters",
            "resources_external",
            "data_extra",
            "icon",
            "description",
            "remarks",
            "iri",
            "pid",
            "pac_id",
            "procedure_txt",
            "procedure_json",
            "procedure_file",
            "media_type",
        )

        # Categorize fields by widget type
        text_fields_required: ClassVar = ("name_display",)

        text_fields: ClassVar = (
            "name",
            "version",
            "icon",
            "pid",
        )

        textarea_fields: ClassVar = (
            "parameters",
            "description",
            "remarks",
            "procedure_txt",
            "procedure_json",
        )

        url_fields: ClassVar = ("uri", "iri", "pac_id")

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "namespace": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "procedure_class": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "method": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "media_type": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "creators": SearchableSelectMultiple(),
            "parts": SearchableSelectMultiple(),
            "devices": SearchableSelectMultiple(),
            "device_setups": SearchableSelectMultiple(),
            "labware": SearchableSelectMultiple(),
            "substances": SearchableSelectMultiple(),
            "polymers": SearchableSelectMultiple(),
            "mixtures": SearchableSelectMultiple(),
            "organisms": SearchableSelectMultiple(),
            "samples": SearchableSelectMultiple(),
            "sample_sets": SearchableSelectMultiple(),
            "resources_external": SearchableSelectMultiple(),
            "data_extra": SearchableSelectMultiple(),
            "tags": SearchableSelectMultiple(),
            "procedure_file": forms.ClearableFileInput(
                attrs={"class": "file-input file-input-sm file-input-bordered w-full"}
            ),
        }


class ProcedureUpdateForm(forms.ModelForm):
    """Form for updating an existing procedure with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Procedure

        fields = (
            "name_display",
            "namespace",
            "name",
            "procedure_class",
            "method",
            "creators",
            "parts",
            "devices",
            "device_setups",
            "labware",
            "substances",
            "polymers",
            "mixtures",
            "organisms",
            "samples",
            "sample_sets",
            "tags",
            "uri",
            "version",
            "parameters",
            "resources_external",
            "data_extra",
            "icon",
            "description",
            "remarks",
            "iri",
            "pid",
            "pac_id",
            "procedure_txt",
            "procedure_json",
            "procedure_file",
            "media_type",
        )

        # Categorize fields by widget type
        text_fields_required: ClassVar = ("name_display",)

        text_fields: ClassVar = (
            "name",
            "version",
            "icon",
            "pid",
        )

        textarea_fields: ClassVar = (
            "parameters",
            "description",
            "remarks",
            "procedure_txt",
            "procedure_json",
        )

        url_fields: ClassVar = ("uri", "iri", "pac_id")

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "namespace": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "procedure_class": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "method": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "media_type": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "creators": SearchableSelectMultiple(),
            "parts": SearchableSelectMultiple(),
            "devices": SearchableSelectMultiple(),
            "device_setups": SearchableSelectMultiple(),
            "labware": SearchableSelectMultiple(),
            "substances": SearchableSelectMultiple(),
            "polymers": SearchableSelectMultiple(),
            "mixtures": SearchableSelectMultiple(),
            "organisms": SearchableSelectMultiple(),
            "samples": SearchableSelectMultiple(),
            "sample_sets": SearchableSelectMultiple(),
            "resources_external": SearchableSelectMultiple(),
            "data_extra": SearchableSelectMultiple(),
            "tags": SearchableSelectMultiple(),
            "procedure_file": forms.ClearableFileInput(
                attrs={"class": "file-input file-input-sm file-input-bordered w-full"}
            ),
        }


class ProcedureInstanceCreateForm(forms.ModelForm):
    """Form for creating a new procedure instance with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = ProcedureInstance

        fields = (
            "procedure_base",
            "name_display",
            "namespace",
            "name",
            "creators",
            "part_instances",
            "device_instances",
            "device_setup_instances",
            "labware_instances",
            "substance_instances",
            "polymer_instances",
            "mixture_instances",
            "organism_instances",
            "samples",
            "sample_sets",
            "tags",
            "uri",
            "version",
            "parameters",
            "resources_external",
            "data_extra",
            "icon",
            "description",
            "remarks",
            "iri",
            "pid",
            "procedure_json",
            "procedure_file",
            "media_type",
            "status",
        )

        # Categorize fields by widget type
        text_fields: ClassVar = (
            "name_display",
            "name",
            "version",
            "icon",
            "pid",
        )

        textarea_fields: ClassVar = (
            "parameters",
            "description",
            "remarks",
            "procedure_json",
        )

        url_fields: ClassVar = ("uri", "iri")

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "procedure_base": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "namespace": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "status": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "media_type": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "creators": SearchableSelectMultiple(),
            "part_instances": SearchableSelectMultiple(),
            "device_instances": SearchableSelectMultiple(),
            "device_setup_instances": SearchableSelectMultiple(),
            "labware_instances": SearchableSelectMultiple(),
            "substance_instances": SearchableSelectMultiple(),
            "polymer_instances": SearchableSelectMultiple(),
            "mixture_instances": SearchableSelectMultiple(),
            "organism_instances": SearchableSelectMultiple(),
            "samples": SearchableSelectMultiple(),
            "sample_sets": SearchableSelectMultiple(),
            "resources_external": SearchableSelectMultiple(),
            "data_extra": SearchableSelectMultiple(),
            "tags": SearchableSelectMultiple(),
            "procedure_file": forms.ClearableFileInput(
                attrs={"class": "file-input file-input-sm file-input-bordered w-full"}
            ),
        }


class ProcedureInstanceUpdateForm(forms.ModelForm):
    """Form for updating an existing procedure instance with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = ProcedureInstance

        fields = (
            "procedure_base",
            "namespace",
            "name",
            "uri",
            "version",
            "parameters",
            "status",
            "resources_external",
            "data_extra",
            "tags",
            "icon",
            "description",
            "remarks",
            "iri",
            "pid",
            "procedure_json",
            "media_type",
            "procedure_file",
        )

        # Categorize fields by widget type
        text_fields: ClassVar = (
            "name",
            "version",
            "icon",
            "pid",
        )

        textarea_fields: ClassVar = (
            "parameters",
            "description",
            "remarks",
            "procedure_json",
        )

        url_fields: ClassVar = ("uri", "iri")

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "procedure_base": forms.Select(attrs={"class": "select select-sm select-bordered w-full", "required": True}),
            "namespace": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "status": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "media_type": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "resources_external": SearchableSelectMultiple(),
            "data_extra": SearchableSelectMultiple(),
            "tags": SearchableSelectMultiple(),
            "procedure_file": forms.ClearableFileInput(
                attrs={"class": "file-input file-input-sm file-input-bordered w-full"}
            ),
        }
