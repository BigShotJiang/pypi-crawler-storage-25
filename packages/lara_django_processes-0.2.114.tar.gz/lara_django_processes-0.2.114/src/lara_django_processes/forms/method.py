"""
Method and MethodInstance forms for lara_django_processes.

:PROJECT: LARAsuite
:details: Forms for Method and MethodInstance models.
:authors: mark doerr <mark.doerr@uni-greifswald.de>
"""

from typing import ClassVar

from django import forms

from ..models import Method, MethodInstance
from .base import CustomFormRenderer, SearchableSelectMultiple


class MethodCreateForm(forms.ModelForm):
    """Form for creating a new method with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Method

        fields = (
            "name_display",
            "namespace",
            "name",
            "method_class",
            "uri",
            "version",
            "parameters",
            "resources_external",
            "data_extra",
            "tags",
            "icon",
            "description",
            "remarks",
            "iri",
            "pid",
            "pac_id",
            "media_type",
            "method_json",
        )

        # Categorize fields by widget type
        text_fields_required: ClassVar = ("name_display",)

        text_fields: ClassVar = (
            "name",
            "version",
            "icon",
            "pid",
        )

        textarea_fields: ClassVar = (
            "parameters",
            "description",
            "remarks",
            "method_json",
        )

        url_fields: ClassVar = ("uri", "iri", "pac_id")

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "namespace": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "method_class": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "media_type": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "resources_external": SearchableSelectMultiple(),
            "data_extra": SearchableSelectMultiple(),
            "tags": SearchableSelectMultiple(),
        }


class MethodUpdateForm(forms.ModelForm):
    """Form for updating an existing method with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Method

        fields = (
            "name_display",
            "namespace",
            "name",
            "method_class",
            "uri",
            "version",
            "parameters",
            "resources_external",
            "data_extra",
            "tags",
            "icon",
            "description",
            "remarks",
            "iri",
            "pid",
            "pac_id",
            "media_type",
            "method_json",
        )

        # Categorize fields by widget type
        text_fields_required: ClassVar = ("name_display",)

        text_fields: ClassVar = (
            "name",
            "version",
            "icon",
            "pid",
        )

        textarea_fields: ClassVar = (
            "parameters",
            "description",
            "remarks",
            "method_json",
        )

        url_fields: ClassVar = ("uri", "iri", "pac_id")

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "namespace": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "method_class": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "media_type": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "resources_external": SearchableSelectMultiple(),
            "data_extra": SearchableSelectMultiple(),
            "tags": SearchableSelectMultiple(),
        }


class MethodInstanceCreateForm(forms.ModelForm):
    """Form for creating a new method instance with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = MethodInstance

        fields = (
            "method_base",
            "name_display",
            "namespace",
            "name",
            "uri",
            "version",
            "parameters",
            "status",
            "resources_external",
            "data_extra",
            "tags",
            "icon",
            "description",
            "remarks",
            "iri",
            "pid",
            "media_type",
            "method_json",
        )

        # Categorize fields by widget type
        text_fields: ClassVar = (
            "name_display",
            "name",
            "version",
            "icon",
            "pid",
        )

        textarea_fields: ClassVar = (
            "parameters",
            "description",
            "remarks",
            "method_json",
        )

        url_fields: ClassVar = ("uri", "iri")

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "method_base": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "namespace": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "status": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "media_type": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "resources_external": SearchableSelectMultiple(),
            "data_extra": SearchableSelectMultiple(),
            "tags": SearchableSelectMultiple(),
        }


class MethodInstanceUpdateForm(forms.ModelForm):
    """Form for updating an existing method instance with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = MethodInstance

        fields = (
            "method_base",
            "namespace",
            "name",
            "uri",
            "version",
            "parameters",
            "status",
            "resources_external",
            "data_extra",
            "tags",
            "icon",
            "description",
            "remarks",
            "iri",
            "pid",
            "media_type",
            "method_json",
        )

        # Categorize fields by widget type
        text_fields: ClassVar = (
            "name",
            "version",
            "icon",
            "pid",
        )

        textarea_fields: ClassVar = (
            "parameters",
            "description",
            "remarks",
            "method_json",
        )

        url_fields: ClassVar = ("uri", "iri")

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "method_base": forms.Select(attrs={"class": "select select-sm select-bordered w-full", "required": True}),
            "namespace": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "status": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "media_type": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "resources_external": SearchableSelectMultiple(),
            "data_extra": SearchableSelectMultiple(),
            "tags": SearchableSelectMultiple(),
        }
