"""
_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_myproj gRPC services*

:details: lara_django_myproj gRPC services.
         -

:authors: mark doerr <mark.doerr@uni-greifswald.de>, marco di sarno <disarno@k3b.de>

.. note:: -
.. todo:: -
________________________________________________________________________
"""

## generated with django-socio-grpc generateprpcinterface lara_django_processes  (LARA-version)

import lara_django_processes_grpc.v1.lara_django_processes_pb2 as lara_django_processes_pb2
from django_socio_grpc.mixins import AsyncStreamModelMixin
from lara_django_base.grpc.mixins import AsyncDownloadModelMixin, AsyncRetrieveByNameModelMixin, AsyncUploadModelMixin

from lara_django_processes.models import (
    ExtraData,
    Method,
    MethodInstance,
    Procedure,
    ProcedureInstance,
    Process,
    ProcessInstance,
    ProcMethodClass,
)

from ..filters import (
    ExtraDataFilterSet,
    MethodFilterSet,
    MethodInstanceFilterSet,
    ProcedureFilterSet,
    ProcedureInstanceFilterSet,
    ProcessFilterSet,
    ProcessInstanceFilterSet,
)
from .serializers import (
    ExtraDataProtoSerializer,
    MethodClassProtoSerializer,
    MethodInstanceProtoSerializer,
    MethodProtoSerializer,
    ProcedureInstanceProtoSerializer,
    ProcedureProtoSerializer,
    ProcessInstanceProtoSerializer,
    ProcessProtoSerializer,
)
from .subscriptions import AsyncModelServiceWithSubscribe


class ExtraDataService(
    AsyncModelServiceWithSubscribe,
    AsyncStreamModelMixin,
    AsyncUploadModelMixin,
    AsyncRetrieveByNameModelMixin,
    AsyncDownloadModelMixin,
):
    pb2 = lara_django_processes_pb2
    queryset = ExtraData.objects.all()
    serializer_class = ExtraDataProtoSerializer
    filterset_class = ExtraDataFilterSet


class MethodClassService(AsyncModelServiceWithSubscribe, AsyncStreamModelMixin):
    queryset = ProcMethodClass.objects.all()
    serializer_class = MethodClassProtoSerializer


class MethodService(
    AsyncModelServiceWithSubscribe,
    AsyncUploadModelMixin,
    AsyncRetrieveByNameModelMixin,
    AsyncDownloadModelMixin,
):
    pb2 = lara_django_processes_pb2
    queryset = Method.objects.all()
    serializer_class = MethodProtoSerializer
    filterset_class = MethodFilterSet


class ProcedureService(
    AsyncModelServiceWithSubscribe,
    AsyncStreamModelMixin,
    AsyncUploadModelMixin,
    AsyncRetrieveByNameModelMixin,
    AsyncDownloadModelMixin,
):
    pb2 = lara_django_processes_pb2
    queryset = Procedure.objects.all()
    serializer_class = ProcedureProtoSerializer
    filterset_class = ProcedureFilterSet


class ProcessService(
    AsyncModelServiceWithSubscribe,
    AsyncStreamModelMixin,
    AsyncUploadModelMixin,
    AsyncRetrieveByNameModelMixin,
    AsyncDownloadModelMixin,
):
    pb2 = lara_django_processes_pb2
    queryset = Process.objects.all()
    serializer_class = ProcessProtoSerializer
    filterset_class = ProcessFilterSet


class MethodInstanceService(
    AsyncModelServiceWithSubscribe,
    AsyncStreamModelMixin,
    AsyncUploadModelMixin,
    AsyncRetrieveByNameModelMixin,
    AsyncDownloadModelMixin,
):
    pb2 = lara_django_processes_pb2
    queryset = MethodInstance.objects.all()
    serializer_class = MethodInstanceProtoSerializer
    filterset_class = MethodInstanceFilterSet


class ProcedureInstanceService(
    AsyncModelServiceWithSubscribe,
    AsyncStreamModelMixin,
    AsyncUploadModelMixin,
    AsyncRetrieveByNameModelMixin,
    AsyncDownloadModelMixin,
):
    pb2 = lara_django_processes_pb2
    queryset = ProcedureInstance.objects.all()
    serializer_class = ProcedureInstanceProtoSerializer
    filterset_class = ProcedureInstanceFilterSet


class ProcessInstanceService(
    AsyncModelServiceWithSubscribe,
    AsyncStreamModelMixin,
    AsyncUploadModelMixin,
    AsyncRetrieveByNameModelMixin,
    AsyncDownloadModelMixin,
):
    pb2 = lara_django_processes_pb2
    queryset = ProcessInstance.objects.all()
    serializer_class = ProcessInstanceProtoSerializer
    filterset_class = ProcessInstanceFilterSet
