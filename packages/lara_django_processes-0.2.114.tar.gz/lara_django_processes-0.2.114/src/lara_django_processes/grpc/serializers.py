"""
_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_processes gRPC serializer*

:details: lara_django_processes gRPC serializer.
         -
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: -
________________________________________________________________________
"""

## generated with django-socio-grpc generateprpcinterface lara_django_processes  (LARA-version)

import lara_django_processes_grpc.v1.lara_django_processes_pb2 as lara_django_processes_pb2
from django_socio_grpc import proto_serializers
from lara_django_base.models import (
    DataType,
    ExternalResource,
    ItemStatus,
    MediaType,
    Namespace,
    Tag,
)
from lara_django_material.models import Device, DeviceSetup, Labware, Part
from lara_django_material_store.models import (
    DeviceInstance,
    DeviceSetupInstance,
    LabwareInstance,
    PartInstance,
)
from lara_django_organisms.models import Organism
from lara_django_organisms_store.models import OrganismInstance
from lara_django_people.models import Entity
from lara_django_samples.models import Sample, SampleSet
from lara_django_substances.models import Mixture, Polymer, Substance
from lara_django_substances_store.models import (
    MixtureInstance,
    PolymerInstance,
    SubstanceInstance,
)
from rest_framework.serializers import PrimaryKeyRelatedField, UUIDField

from lara_django_processes.models import (
    ExtraData,
    Method,
    MethodInstance,
    Procedure,
    ProcedureInstance,
    Process,
    ProcessInstance,
    ProcMethodClass,
)


class ExtraDataProtoSerializer(proto_serializers.ModelProtoSerializer):
    data_type = PrimaryKeyRelatedField(
        queryset=DataType.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        allow_null=True,
        required=False,
    )
    namespace = PrimaryKeyRelatedField(queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    media_type = PrimaryKeyRelatedField(
        queryset=MediaType.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        allow_null=True,
        required=False,
    )

    class Meta:
        model = ExtraData
        proto_class = lara_django_processes_pb2.ExtraDataResponse

        proto_class_list = lara_django_processes_pb2.ExtraDataListResponse

        fields = "__all__"  # [data_type', namespace', URI', text', XML', JSON', bin', media_type', IRI', URL', description', image', file']


class MethodClassProtoSerializer(proto_serializers.ModelProtoSerializer):
    class Meta:
        model = ProcMethodClass
        proto_class = lara_django_processes_pb2.MethodClassResponse

        proto_class_list = lara_django_processes_pb2.MethodClassListResponse

        fields = "__all__"  # [method_class', description']


class MethodProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(
        queryset=Namespace.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
    )

    substances = PrimaryKeyRelatedField(
        queryset=Substance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    polymers = PrimaryKeyRelatedField(
        queryset=Polymer.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    mixtures = PrimaryKeyRelatedField(
        queryset=Mixture.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )

    parts = PrimaryKeyRelatedField(
        queryset=Part.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    devices = PrimaryKeyRelatedField(
        queryset=Device.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    device_setups = PrimaryKeyRelatedField(
        queryset=DeviceSetup.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    labware = PrimaryKeyRelatedField(
        queryset=Labware.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    organisms = PrimaryKeyRelatedField(
        queryset=Organism.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    samples = PrimaryKeyRelatedField(
        queryset=Sample.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    sample_sets = PrimaryKeyRelatedField(
        queryset=SampleSet.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    creators = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    resources_external = PrimaryKeyRelatedField(
        queryset=ExternalResource.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )

    data_extra = PrimaryKeyRelatedField(
        queryset=ExtraData.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )

    method_class = PrimaryKeyRelatedField(
        queryset=ProcMethodClass.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        allow_null=True,
        required=False,
    )

    class Meta:
        model = Method
        proto_class = lara_django_processes_pb2.MethodResponse

        proto_class_list = lara_django_processes_pb2.MethodListResponse

        fields = "__all__"  # [namespace', name', name_full', URI', version', parameters', literature', icon', description', remarks', IRI', handle', method', method_class', media_type', method_file']


class ProcedureProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(
        queryset=Namespace.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
    )

    substances = PrimaryKeyRelatedField(
        queryset=Substance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    polymers = PrimaryKeyRelatedField(
        queryset=Polymer.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    mixtures = PrimaryKeyRelatedField(
        queryset=Mixture.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )

    parts = PrimaryKeyRelatedField(
        queryset=Part.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    devices = PrimaryKeyRelatedField(
        queryset=Device.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    device_setups = PrimaryKeyRelatedField(
        queryset=DeviceSetup.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    labware = PrimaryKeyRelatedField(
        queryset=Labware.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )

    organisms = PrimaryKeyRelatedField(
        queryset=Organism.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )

    samples = PrimaryKeyRelatedField(
        queryset=Sample.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    sample_sets = PrimaryKeyRelatedField(
        queryset=SampleSet.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )

    creators = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    resources_external = PrimaryKeyRelatedField(
        queryset=ExternalResource.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )

    data_extra = PrimaryKeyRelatedField(
        queryset=ExtraData.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )

    media_type = PrimaryKeyRelatedField(
        queryset=MediaType.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        allow_null=True,
        required=False,
    )
    procedure_class = PrimaryKeyRelatedField(
        queryset=ProcMethodClass.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        allow_null=True,
        required=False,
    )

    class Meta:
        model = Procedure
        proto_class = lara_django_processes_pb2.ProcedureResponse

        proto_class_list = lara_django_processes_pb2.ProcedureListResponse

        fields = "__all__"  # [namespace', name', name_full', URI', version', parameters', literature', icon', description', remarks', IRI', handle', procedure', procedure_class', media_type', procedure_file']


class ProcessProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(
        queryset=Namespace.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
    )

    substances = PrimaryKeyRelatedField(
        queryset=Substance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    polymers = PrimaryKeyRelatedField(
        queryset=Polymer.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    mixtures = PrimaryKeyRelatedField(
        queryset=Mixture.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )

    parts = PrimaryKeyRelatedField(
        queryset=Part.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    devices = PrimaryKeyRelatedField(
        queryset=Device.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    device_setups = PrimaryKeyRelatedField(
        queryset=DeviceSetup.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    labware = PrimaryKeyRelatedField(
        queryset=Labware.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )

    organisms = PrimaryKeyRelatedField(
        queryset=Organism.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )

    samples = PrimaryKeyRelatedField(
        queryset=Sample.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    sample_sets = PrimaryKeyRelatedField(
        queryset=SampleSet.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )

    creators = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    resources_external = PrimaryKeyRelatedField(
        queryset=ExternalResource.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )

    data_extra = PrimaryKeyRelatedField(
        queryset=ExtraData.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )

    process_class = PrimaryKeyRelatedField(
        queryset=ProcMethodClass.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        allow_null=True,
        required=False,
    )
    procedures = PrimaryKeyRelatedField(
        queryset=Procedure.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )

    class Meta:
        model = Process
        proto_class = lara_django_processes_pb2.ProcessResponse

        proto_class_list = lara_django_processes_pb2.ProcessListResponse

        fields = "__all__"  # [namespace', name', name_full', URI', version', parameters', literature', icon', description', remarks', IRI', handle', process_class']


class MethodInstanceProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(
        queryset=Namespace.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
    )
    method_base = PrimaryKeyRelatedField(queryset=Method.objects.all(), pk_field=UUIDField(format="hex_verbose"))

    status = PrimaryKeyRelatedField(
        queryset=ItemStatus.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        allow_null=True,
        required=False,
    )
    media_type = PrimaryKeyRelatedField(
        queryset=MediaType.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        allow_null=True,
        required=False,
    )
    substance_instances = PrimaryKeyRelatedField(
        queryset=SubstanceInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    polymer_instances = PrimaryKeyRelatedField(
        queryset=PolymerInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    mixture_instances = PrimaryKeyRelatedField(
        queryset=MixtureInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )

    part_instances = PrimaryKeyRelatedField(
        queryset=PartInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    device_instances = PrimaryKeyRelatedField(
        queryset=DeviceInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    device_setup_instances = PrimaryKeyRelatedField(
        queryset=DeviceSetupInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    labware_instances = PrimaryKeyRelatedField(
        queryset=LabwareInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    organism_instances = PrimaryKeyRelatedField(
        queryset=OrganismInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )

    samples = PrimaryKeyRelatedField(
        queryset=Sample.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    sample_sets = PrimaryKeyRelatedField(
        queryset=SampleSet.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )

    creators = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    resources_external = PrimaryKeyRelatedField(
        queryset=ExternalResource.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )

    data_extra = PrimaryKeyRelatedField(
        queryset=ExtraData.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )

    class Meta:
        model = MethodInstance
        proto_class = lara_django_processes_pb2.MethodInstanceResponse

        proto_class_list = lara_django_processes_pb2.MethodInstanceListResponse

        fields = "__all__"  # [namespace', name', name_full', proc_class', URI', version', parameters', status', literature', icon', description', remarks', IRI', handle', method_base', method', media_type', method_file']


class ProcedureInstanceProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(
        queryset=Namespace.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
    )

    procedure_base = PrimaryKeyRelatedField(
        queryset=Procedure.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
    )

    status = PrimaryKeyRelatedField(
        queryset=ItemStatus.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        allow_null=True,
        required=False,
    )
    media_type = PrimaryKeyRelatedField(
        queryset=MediaType.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        allow_null=True,
        required=False,
    )

    substance_instances = PrimaryKeyRelatedField(
        queryset=SubstanceInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    polymer_instances = PrimaryKeyRelatedField(
        queryset=PolymerInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    mixture_instances = PrimaryKeyRelatedField(
        queryset=MixtureInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )

    part_instances = PrimaryKeyRelatedField(
        queryset=PartInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    device_instances = PrimaryKeyRelatedField(
        queryset=DeviceInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    device_setup_instances = PrimaryKeyRelatedField(
        queryset=DeviceSetupInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    labware_instances = PrimaryKeyRelatedField(
        queryset=LabwareInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )

    organism_instances = PrimaryKeyRelatedField(
        queryset=OrganismInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )

    samples = PrimaryKeyRelatedField(
        queryset=Sample.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    sample_sets = PrimaryKeyRelatedField(
        queryset=SampleSet.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )

    creators = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    resources_external = PrimaryKeyRelatedField(
        queryset=ExternalResource.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )

    data_extra = PrimaryKeyRelatedField(
        queryset=ExtraData.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )

    class Meta:
        model = ProcedureInstance
        proto_class = lara_django_processes_pb2.ProcedureInstanceResponse

        proto_class_list = lara_django_processes_pb2.ProcedureInstanceListResponse

        fields = "__all__"  # [namespace', name', name_full', proc_class', URI', version', parameters', status', literature', icon', description', remarks', IRI', handle', procedure_base', procedure', media_type', procedure_file']


class ProcessInstanceProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(
        queryset=Namespace.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
    )

    process_base = PrimaryKeyRelatedField(
        queryset=Process.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
    )
    namespace = PrimaryKeyRelatedField(
        queryset=Namespace.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
    )

    process_base = PrimaryKeyRelatedField(
        queryset=Process.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
    )

    status = PrimaryKeyRelatedField(
        queryset=ItemStatus.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        allow_null=True,
        required=False,
    )
    media_type = PrimaryKeyRelatedField(
        queryset=MediaType.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        allow_null=True,
        required=False,
    )

    substance_instances = PrimaryKeyRelatedField(
        queryset=SubstanceInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    polymer_instances = PrimaryKeyRelatedField(
        queryset=PolymerInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    mixture_instances = PrimaryKeyRelatedField(
        queryset=MixtureInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )

    part_instances = PrimaryKeyRelatedField(
        queryset=PartInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    device_instances = PrimaryKeyRelatedField(
        queryset=DeviceInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    device_setup_instances = PrimaryKeyRelatedField(
        queryset=DeviceSetupInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    labware_instances = PrimaryKeyRelatedField(
        queryset=LabwareInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )

    organism_instances = PrimaryKeyRelatedField(
        queryset=OrganismInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )

    samples = PrimaryKeyRelatedField(
        queryset=Sample.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    sample_sets = PrimaryKeyRelatedField(
        queryset=SampleSet.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )

    creators = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    resources_external = PrimaryKeyRelatedField(
        queryset=ExternalResource.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )

    data_extra = PrimaryKeyRelatedField(
        queryset=ExtraData.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )

    procedure_instances = PrimaryKeyRelatedField(
        queryset=ProcedureInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )

    class Meta:
        model = ProcessInstance
        proto_class = lara_django_processes_pb2.ProcessInstanceResponse

        proto_class_list = lara_django_processes_pb2.ProcessInstanceListResponse

        fields = "__all__"  # [namespace', name', name_full', proc_class', URI', version', parameters', status', literature', icon', description', remarks', IRI', handle', process_base']
        fields = "__all__"  # [namespace', name', name_full', proc_class', URI', version', parameters', status', literature', icon', description', remarks', IRI', handle', process_base']
