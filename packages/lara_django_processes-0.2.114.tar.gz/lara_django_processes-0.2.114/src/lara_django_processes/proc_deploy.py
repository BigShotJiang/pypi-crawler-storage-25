# process dedployment

from .tasks import deploy_process


def deploy_prefect_process(sender, instance, **kwargs):
    print(f"******* - --- deploying process {instance.name}")

    deploy_process.delay(instance.name, str(instance.processinstance_id)[:8])
