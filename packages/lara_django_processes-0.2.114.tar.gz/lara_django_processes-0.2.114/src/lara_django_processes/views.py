"""
_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_processes views *

:details: lara_django_processes views module.
         - add app specific urls here
         -
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: -
________________________________________________________________________
"""

import sys
from dataclasses import dataclass, field

from django.shortcuts import get_object_or_404, render
from django.views.generic import (
    CreateView,
    DeleteView,
    DetailView,
    UpdateView,
)
from django_tables2 import SingleTableView

from .forms import (
    MethodCreateForm,
    MethodInstanceCreateForm,
    MethodInstanceUpdateForm,
    MethodUpdateForm,
    ProcedureCreateForm,
    ProcedureInstanceCreateForm,
    ProcedureInstanceUpdateForm,
    ProcedureUpdateForm,
    ProcessCreateForm,
    ProcessInstanceCreateForm,
    ProcessInstanceUpdateForm,
    ProcessUpdateForm,
)
from .models import (
    Method,
    MethodInstance,
    Procedure,
    ProcedureInstance,
    Process,
    ProcessInstance,
)
from .tables import (
    MethodInstanceTable,
    MethodTable,
    ProcedureInstanceTable,
    ProcedureTable,
    ProcessInstanceTable,
    ProcessTable,
)

# Create your  lara_django_processes views here.


@dataclass
class ProcessesMenu:
    """Menu configuration for processes navigation."""

    menu_items: list[dict] = field(
        default_factory=lambda: [
            {
                "name": "Procedure Instances",
                "path": "lara_django_processes:procedure-instance-list",
            },
            {"name": "Procedure", "path": "lara_django_processes:procedure-list"},
            {
                "name": "Process Instances",
                "path": "lara_django_processes:process-instance-list",
            },
            {"name": "Processes", "path": "lara_django_processes:process-list"},
            {
                "name": "Method Instances",
                "path": "lara_django_processes:method-instance-list",
            },
            {"name": "Method", "path": "lara_django_processes:method-list"},
        ]
    )


class MethodSingleTableView(SingleTableView):
    """Table view for listing methods."""

    model = Method
    table_class = MethodTable

    # fields = ('name', 'name_full', 'URL', 'pid', 'iri', 'manufacturer', 'model_no', 'product_type', 'type_barcode', 'product_no', 'weight', 'specifications', 'spec_json', 'spec_doc', 'brochure', 'quickstart', 'manual', 'service_manual', 'icon', 'image', 'description', 'method_id', 'method_class', 'shape')  # noqa: E501  # noqa: E501

    template_name = "lara_django_processes/list.html"
    success_url = "/processes/method/list"

    def get_context_data(self, **kwargs):
        """Add context data for template rendering."""
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Method - List"
        context["create_link"] = "lara_django_processes:method-create"
        context["menu_items"] = ProcessesMenu().menu_items
        return context


class MethodDetailView(DetailView):
    """Detail view for a single method."""

    model = Method

    template_name = "lara_django_processes/method_detail.html"

    def get_context_data(self, **kwargs):
        """Add section title, update link and menu to context."""
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Method - Details"
        context["update_link"] = "lara_django_processes:method-update"
        context["menu_items"] = ProcessesMenu().menu_items
        return context


class MethodCreateView(CreateView):
    """Create view for methods."""

    model = Method

    template_name = "lara_django_processes/create_form.html"
    form_class = MethodCreateForm
    success_url = "/processes/method/list"

    def get_context_data(self, **kwargs):
        """Add section title to context."""
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Method - Create"
        return context


class MethodUpdateView(UpdateView):
    """Update view for methods."""

    model = Method

    template_name = "lara_django_processes/update_form.html"
    form_class = MethodUpdateForm
    success_url = "/processes/method/list"

    def get_context_data(self, **kwargs):
        """Add section title and delete link to context."""
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Method - Update"
        context["delete_link"] = "lara_django_processes:method-delete"
        return context


class MethodDeleteView(DeleteView):
    """Delete view for methods."""

    model = Method

    template_name = "lara_django_processes/delete_form.html"
    success_url = "/processes/method/list"

    def get_context_data(self, **kwargs):
        """Add section title and delete link to context."""
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Method - Delete"
        context["delete_link"] = "lara_django_processes:method-delete"
        return context


# ==== Method Instance ====


class MethodInstanceSingleTableView(SingleTableView):
    """Table view for listing method instances."""

    model = MethodInstance
    table_class = MethodInstanceTable

    # fields = ('name', 'name_full', 'URL', 'pid', 'iri', 'manufacturer', 'model_no', 'product_type', 'type_barcode', 'product_no', 'weight', 'specifications', 'spec_json', 'spec_doc', 'brochure', 'quickstart', 'manual', 'service_manual', 'icon', 'image', 'description', 'method-instance_id', 'method-instance_class', 'shape')  # noqa: E501  # noqa: E501

    template_name = "lara_django_processes/list.html"
    success_url = "/processes/method-instance/list"

    def get_context_data(self, **kwargs):
        """Add context data for template rendering."""
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Method Instance - List"
        context["create_link"] = "lara_django_processes:method-instance-create"
        context["menu_items"] = ProcessesMenu().menu_items
        return context


class MethodInstanceDetailView(DetailView):
    """Detail view for a single method instance."""

    model = MethodInstance

    template_name = "lara_django_processes/method-instance_detail.html"

    def get_context_data(self, **kwargs):
        """Add context data for template rendering."""
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Method Instance - Details"
        context["update_link"] = "lara_django_processes:method-instance-update"
        context["menu_items"] = ProcessesMenu().menu_items
        return context


class MethodInstanceCreateView(CreateView):
    """Create view for method instances."""

    model = MethodInstance

    template_name = "lara_django_processes/create_form.html"
    form_class = MethodInstanceCreateForm
    success_url = "/processes/method-instance/list"

    def get_context_data(self, **kwargs):
        """Add context data for template rendering."""
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Method Instance - Create"
        return context


class MethodInstanceUpdateView(UpdateView):
    """Update view for method instances."""

    model = MethodInstance

    template_name = "lara_django_processes/update_form.html"
    form_class = MethodInstanceUpdateForm
    success_url = "/processes/method-instance/list"

    def get_context_data(self, **kwargs):
        """Add context data for template rendering."""
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Method Instance - Update"
        context["delete_link"] = "lara_django_processes:method-instance-delete"
        return context


class MethodInstanceDeleteView(DeleteView):
    """Delete view for method instances."""

    model = MethodInstance

    template_name = "lara_django_processes/delete_form.html"
    success_url = "/processes/method-instance/list"

    def get_context_data(self, **kwargs):
        """Add context data for template rendering."""
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Method Instance - Delete"
        context["delete_link"] = "lara_django_processes:method-instance-delete"
        return context


# ==== Procedure ====


class ProcedureSingleTableView(SingleTableView):
    """Table view for listing procedures."""

    model = Procedure
    table_class = ProcedureTable

    # fields = ('name', 'name_full', 'URL', 'pid', 'iri', 'manufacturer', 'model_no', 'product_type', 'type_barcode', 'product_no', 'weight', 'specifications', 'spec_json', 'spec_doc', 'brochure', 'quickstart', 'manual', 'service_manual', 'icon', 'image', 'description', 'procedure_id', 'procedure_class', 'shape')  # noqa: E501

    template_name = "lara_django_processes/list.html"
    success_url = "/processes/procedure/list"

    def get_context_data(self, **kwargs):
        """Add context data for template rendering."""
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Procedure - List"
        context["create_link"] = "lara_django_processes:procedure-create"
        context["menu_items"] = ProcessesMenu().menu_items
        return context


class ProcedureDetailView(DetailView):
    """Detail view for a single procedure."""

    model = Procedure

    template_name = "lara_django_processes/procedure_detail.html"

    def get_context_data(self, **kwargs):
        """Add context data for template rendering."""
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Procedure - Details"
        context["update_link"] = "lara_django_processes:procedure-update"
        context["menu_items"] = ProcessesMenu().menu_items
        return context


class ProcedureCreateView(CreateView):
    """Create view for procedures."""

    model = Procedure

    template_name = "lara_django_processes/create_form.html"
    form_class = ProcedureCreateForm
    success_url = "/processes/procedure/list"

    def get_context_data(self, **kwargs):
        """Add context data for template rendering."""
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Procedure - Create"
        return context


class ProcedureUpdateView(UpdateView):
    """Update view for procedures."""

    model = Procedure

    template_name = "lara_django_processes/update_form.html"
    form_class = ProcedureUpdateForm
    success_url = "/processes/procedure/list"

    def get_context_data(self, **kwargs):
        """Add context data for template rendering."""
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Procedure - Update"
        context["delete_link"] = "lara_django_processes:procedure-delete"
        return context


class ProcedureDeleteView(DeleteView):
    """Delete view for procedures."""

    model = Procedure

    template_name = "lara_django_processes/delete_form.html"
    success_url = "/processes/procedure/list"

    def get_context_data(self, **kwargs):
        """Add context data for template rendering."""
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Procedure - Delete"
        context["delete_link"] = "lara_django_processes:procedure-delete"
        return context


class ProcedureInstanceSingleTableView(SingleTableView):
    """Table view for listing procedure instances."""

    model = ProcedureInstance
    table_class = ProcedureInstanceTable

    # fields = ('name', 'name_full', 'URL', 'pid', 'iri', 'manufacturer', 'model_no', 'product_type', 'type_barcode', 'product_no', 'weight', 'specifications', 'spec_json', 'spec_doc', 'brochure', 'quickstart', 'manual', 'service_manual', 'icon', 'image', 'description', 'procedure-instance_id', 'procedure-instance_class', 'shape')  # noqa: E501

    template_name = "lara_django_processes/list.html"
    success_url = "/processes/procedure-instance/list"

    def get_context_data(self, **kwargs):
        """Add context data for template rendering."""
        context = super().get_context_data(**kwargs)
        context["section_title"] = "ProcedureInstance - List"
        context["create_link"] = "lara_django_processes:procedure-instance-create"
        context["menu_items"] = ProcessesMenu().menu_items
        return context


class ProcedureInstanceDetailView(DetailView):
    """Detail view for a single procedure instance."""

    model = ProcedureInstance

    template_name = "lara_django_processes/procedure-instance_detail.html"

    def get_context_data(self, **kwargs):
        """Add context data for template rendering."""
        context = super().get_context_data(**kwargs)
        context["section_title"] = "ProcedureInstance - Details"
        context["update_link"] = "lara_django_processes:procedure-instance-update"
        context["menu_items"] = ProcessesMenu().menu_items
        return context


class ProcedureInstanceCreateView(CreateView):
    """Create view for procedure instances."""

    model = ProcedureInstance

    template_name = "lara_django_processes/create_form.html"
    form_class = ProcedureInstanceCreateForm
    success_url = "/processes/procedure-instance/list"

    def get_context_data(self, **kwargs):
        """Add context data for template rendering."""
        context = super().get_context_data(**kwargs)
        context["section_title"] = "ProcedureInstance - Create"
        return context


class ProcedureInstanceUpdateView(UpdateView):
    """Update view for procedure instances."""

    model = ProcedureInstance

    template_name = "lara_django_processes/update_form.html"
    form_class = ProcedureInstanceUpdateForm
    success_url = "/processes/procedure-instance/list"

    def get_context_data(self, **kwargs):
        """Add context data for template rendering."""
        context = super().get_context_data(**kwargs)
        context["section_title"] = "ProcedureInstance - Update"
        context["delete_link"] = "lara_django_processes:procedure-instance-delete"
        return context


class ProcedureInstanceDeleteView(DeleteView):
    """Delete view for procedure instances."""

    model = ProcedureInstance

    template_name = "lara_django_processes/delete_form.html"
    success_url = "/processes/procedure-instance/list"

    def get_context_data(self, **kwargs):
        """Add context data for template rendering."""
        context = super().get_context_data(**kwargs)
        context["section_title"] = "ProcedureInstance - Delete"
        context["delete_link"] = "lara_django_processes:procedure-instance-delete"
        return context


# ==== Process ====


class ProcessSingleTableView(SingleTableView):
    """Table view for listing processes."""

    model = Process
    table_class = ProcessTable

    # fields = ('name', 'name_full', 'URL', 'pid', 'iri', 'manufacturer', 'model_no', 'product_type', 'type_barcode', 'product_no', 'weight', 'specifications', 'spec_json', 'spec_doc', 'brochure', 'quickstart', 'manual', 'service_manual', 'icon', 'image', 'description', 'process_id', 'process_class', 'shape')  # noqa: E501

    template_name = "lara_django_processes/list.html"
    success_url = "/processes/process/list"

    def get_context_data(self, **kwargs):
        """Add context data for template rendering."""
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Process - List"
        context["create_link"] = "lara_django_processes:process-create"
        context["menu_items"] = ProcessesMenu().menu_items
        return context


class ProcessDetailView(DetailView):
    """Detail view for a single process."""

    model = Process

    template_name = "lara_django_processes/process_detail.html"

    def get_context_data(self, **kwargs):
        """Add context data for template rendering."""
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Process - Details"
        context["update_link"] = "lara_django_processes:process-update"
        context["menu_items"] = ProcessesMenu().menu_items
        return context


class ProcessCreateView(CreateView):
    """Create view for processes."""

    model = Process

    template_name = "lara_django_processes/create_form.html"
    form_class = ProcessCreateForm
    success_url = "/processes/process/list"

    def get_context_data(self, **kwargs):
        """Add context data for template rendering."""
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Process - Create"
        return context


class ProcessUpdateView(UpdateView):
    """Update view for processes."""

    model = Process

    template_name = "lara_django_processes/update_form.html"
    form_class = ProcessUpdateForm
    success_url = "/processes/process/list"

    def get_context_data(self, **kwargs):
        """Add context data for template rendering."""
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Process - Update"
        context["delete_link"] = "lara_django_processes:process-delete"
        return context


class ProcessDeleteView(DeleteView):
    """Delete view for processes."""

    model = Process

    template_name = "lara_django_processes/delete_form.html"
    success_url = "/processes/process/list"

    def get_context_data(self, **kwargs):
        """Add context data for template rendering."""
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Process - Delete"
        context["delete_link"] = "lara_django_processes:process-delete"
        return context


class ProcessInstanceSingleTableView(SingleTableView):
    """Table view for listing process instances."""

    model = ProcessInstance
    table_class = ProcessInstanceTable

    # fields = ('name', 'name_full', 'URL', 'pid', 'iri', 'manufacturer', 'model_no', 'product_type', 'type_barcode', 'product_no', 'weight', 'specifications', 'spec_json', 'spec_doc', 'brochure', 'quickstart', 'manual', 'service_manual', 'icon', 'image', 'description', 'process-instance_id', 'process-instance_class', 'shape')  # noqa: E501

    template_name = "lara_django_processes/list.html"
    success_url = "/processes/process-instance/list"

    def get_context_data(self, **kwargs):
        """Add context data for template rendering."""
        context = super().get_context_data(**kwargs)
        context["section_title"] = "ProcessInstance - List"
        context["create_link"] = "lara_django_processes:process-instance-create"
        context["menu_items"] = ProcessesMenu().menu_items
        return context


class ProcessInstanceDetailView(DetailView):
    """Detail view for a single process instance."""

    model = ProcessInstance

    template_name = "lara_django_processes/process-instance_detail.html"

    def get_context_data(self, **kwargs):
        """Add context data for template rendering."""
        context = super().get_context_data(**kwargs)
        context["section_title"] = "ProcessInstance - Details"
        context["update_link"] = "lara_django_processes:process-instance-update"
        context["menu_items"] = ProcessesMenu().menu_items
        return context


class ProcessInstanceCreateView(CreateView):
    """Create view for process instances."""

    model = ProcessInstance

    template_name = "lara_django_processes/create_form.html"
    form_class = ProcessInstanceCreateForm
    success_url = "/processes/process-instance/list"

    def get_context_data(self, **kwargs):
        """Add context data for template rendering."""
        context = super().get_context_data(**kwargs)
        context["section_title"] = "ProcessInstance - Create"
        return context


class ProcessInstanceUpdateView(UpdateView):
    """Update view for process instances."""

    model = ProcessInstance

    template_name = "lara_django_processes/update_form.html"
    form_class = ProcessInstanceUpdateForm
    success_url = "/processes/process-instance/list"

    def get_context_data(self, **kwargs):
        """Add context data for template rendering."""
        context = super().get_context_data(**kwargs)
        context["section_title"] = "ProcessInstance - Update"
        context["delete_link"] = "lara_django_processes:process-instance-delete"
        return context


class ProcessInstanceDeleteView(DeleteView):
    """Delete view for process instances."""

    model = ProcessInstance

    template_name = "lara_django_processes/delete_form.html"
    success_url = "/processes/process-instance/list"

    def get_context_data(self, **kwargs):
        """Add context data for template rendering."""
        context = super().get_context_data(**kwargs)
        context["section_title"] = "ProcessInstance - Delete"
        context["delete_link"] = "lara_django_processes:process-instance-delete"
        return context


### - ---- old


def index(request):
    """Main index view showing all processes."""
    process_list = Process.objects.all()
    context = {"process_list": process_list}
    return render(request, "lara_django_processes/index.html", context)


def processList(request):
    """List all processes with table caption."""
    process_list = Process.objects.all()
    table_caption = "List of all LARA data"
    context = {"table_caption": table_caption, "process_list": process_list}
    return render(request, "lara_django_processes/process_list.html", context)


def searchForm(request):
    """Render the search form."""
    return render(request, "lara_django_processes/search.html", context={})


def search(request):
    """Search for processes by device name."""
    search_string = request.POST["search"]

    try:
        process_list = []
        curr_process = Process.objects.get(device__name=search_string)
        process_list.append(curr_process)

    except ValueError as err:
        sys.stderr.write(f"{err}")
        # ~ return render(request, 'polls/detail.html', {
        # ~ 'question': question,
        # ~ 'error_message': "You didn't select a choice.",
        # ~ })
    else:
        context = {"process_list": process_list}
        return render(request, "lara_django_processes/results.html", context)
        # return HttpResponseRedirect(reverse('lara_django_processes:results', args=(lara_device_list,)))


def results(request, process_list):
    """Display search results."""
    # question = get_object_or_404(Question, pk=question_id)
    context = {"process_list": process_list}
    return render(request, "lara_django_processes/results.html", context)


def processDetails(request, process_id):
    """Display details for a specific process."""
    curr_process = get_object_or_404(Process, pk=process_id)
    context = {"process": curr_process}
    return render(request, "lara_django_processes/process.html", context)
