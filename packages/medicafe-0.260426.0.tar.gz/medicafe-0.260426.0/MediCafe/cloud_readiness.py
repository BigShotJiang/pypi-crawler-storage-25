﻿#!/usr/bin/env python
# pyright: reportArgumentType=false, reportOptionalMemberAccess=false
"""
Cloud Readiness Pipeline service module.

Service-only: no UI. Launcher delegates phase actions here.
Returns (ok, message, data); no exceptions to caller.
Python 3.4 compatible.
"""
from __future__ import print_function

import json
import os
import re
import calendar
import sqlite3
import subprocess
import sys
import time
from MediCafe import shadow_orchestrator
from MediCafe import cloud_readiness_artifact_tools as _artifact_tools
from MediCafe import cloud_readiness_patient_tools as _patient_tools
from MediCafe import cloud_readiness_runbooks as _runbook_tools
from MediCafe import cloud_readiness_health as _health_tools
from MediCafe import cloud_readiness_actions as _action_tools
from MediCafe import cloud_readiness_recommendations as _recommendation_tools

try:
    from MediCafe.MediLink_ConfigLoader import log as mc_log
except Exception:
    mc_log = None

try:
    from MediCafe.cloud_readiness_health import build_cloud_health_lines
except Exception:
    build_cloud_health_lines = None

try:
    from MediCafe.error_reporter import (
        collect_support_bundle,
        submit_support_bundle_email,
        get_error_reporting_delivery_readiness,
        try_acquire_report_dedup_lock,
        release_report_dedup_lock,
    )
except Exception:
    collect_support_bundle = None
    submit_support_bundle_email = None
    get_error_reporting_delivery_readiness = None
    try_acquire_report_dedup_lock = None
    release_report_dedup_lock = None

try:
    from scripts.unified_model.phase_d_historical_reprocess import (
        collect_phase_d_reject_snapshot as _collect_phase_d_reject_snapshot_impl,
        execute_historical_phase_d_reprocess as _execute_historical_phase_d_reprocess_impl,
        normalize_artifact_classes as _normalize_phase_d_reprocess_classes_impl,
        preview_historical_phase_d_reprocess as _preview_historical_phase_d_reprocess_impl,
    )
except Exception:
    try:
        from phase_d_historical_reprocess import (
            collect_phase_d_reject_snapshot as _collect_phase_d_reject_snapshot_impl,
            execute_historical_phase_d_reprocess as _execute_historical_phase_d_reprocess_impl,
            normalize_artifact_classes as _normalize_phase_d_reprocess_classes_impl,
            preview_historical_phase_d_reprocess as _preview_historical_phase_d_reprocess_impl,
        )
    except Exception:
        _collect_phase_d_reject_snapshot_impl = None
        _execute_historical_phase_d_reprocess_impl = None
        _normalize_phase_d_reprocess_classes_impl = None
        _preview_historical_phase_d_reprocess_impl = None

try:
    from scripts.unified_model.phase_d_backlog_signals import (
        historical_reprocess_numeric_predicates as _historical_reprocess_numeric_predicates,
    )
except Exception:
    try:
        from phase_d_backlog_signals import (
            historical_reprocess_numeric_predicates as _historical_reprocess_numeric_predicates,
        )
    except Exception:
        _historical_reprocess_numeric_predicates = None

# Avoid `from subprocess import DEVNULL` + reassignment: typeshed marks DEVNULL as Final.
_subprocess_devnull = getattr(subprocess, 'DEVNULL', None)
if _subprocess_devnull is not None:
    DEVNULL = _subprocess_devnull
else:
    DEVNULL = open(os.devnull, 'wb')

# KEEP IN SYNC WITH scripts/unified_model/shadow_run_actuals.SHADOW_ACTUAL_INT_FIELDS (parity tests).
_SHADOW_ACTUAL_INT_FIELDS_FALLBACK = (
    "phase_b_dat_manifest_rows_count",
    "phase_d_dat_selected_count",
    "phase_d_dat_qa_pass_count",
    "phase_d_dat_qa_reject_count",
    "phase_d_dat_canonical_record_count",
    "phase_d_dat_v2_payload_attempted_total",
    "phase_d_dat_v2_inserted_total",
    "phase_d_dat_v2_skipped_total",
    "phase_d_dat_v2_constraint_failed_total",
)
try:
    from scripts.unified_model.shadow_run_actuals import (
        SHADOW_ACTUAL_FIELDS_VERSION,
        SHADOW_ACTUAL_INT_FIELDS,
        normalize_shadow_actual as _normalize_shadow_actual_impl,
    )
except Exception:
    try:
        import shadow_run_actuals as _shadow_run_actuals_mod
        SHADOW_ACTUAL_FIELDS_VERSION = getattr(_shadow_run_actuals_mod, "SHADOW_ACTUAL_FIELDS_VERSION", 1)
        SHADOW_ACTUAL_INT_FIELDS = getattr(
            _shadow_run_actuals_mod, "SHADOW_ACTUAL_INT_FIELDS", _SHADOW_ACTUAL_INT_FIELDS_FALLBACK
        )
        _normalize_shadow_actual_impl = _shadow_run_actuals_mod.normalize_shadow_actual
    except Exception:
        SHADOW_ACTUAL_FIELDS_VERSION = 1
        SHADOW_ACTUAL_INT_FIELDS = _SHADOW_ACTUAL_INT_FIELDS_FALLBACK
        _normalize_shadow_actual_impl = None


_HEALTH_TRACKER_FILENAME = 'cloud_health_tracker.json'
_HEALTH_ALERT_STATE_FILENAME = 'cloud_health_alert_state.json'
_ORCHESTRATOR_ALERT_STATE_FILENAME = 'orchestrator_failure_alert_state.json'
_ORCHESTRATOR_ALERT_DEDUP_WINDOW_SEC = 10 * 60
_REPORT_DELIVERY_ALERT_STALE_SEC = 24 * 60 * 60
_WARN_ESCALATION_MIN_COUNT = 3
_WARN_ESCALATION_MIN_AGE_SEC = 120
_ALERT_DEDUP_WINDOW_SEC = 6 * 60 * 60
# Bootstrap-only warn codes: expected before any pipeline run; do not escalate to incident alerts.
_WARN_NON_ESCALATING_CODES = frozenset([
    'DIAGNOSTICS_STATE_MISSING',
    'PHASE_B_NOT_RUN', 'PHASE_C_NOT_RUN', 'PHASE_D_NOT_RUN',
    'PHASE_E_NOT_RUN', 'PHASE_F_NOT_RUN',
])
_PHASE_ORDER = {'A': 1, 'B': 2, 'C': 3, 'D': 4, 'E': 5, 'F': 6}
# Keep aligned with scripts/unified_model/unified_rollout_policy.py (D-032).
# TODO(theme5): If policy constants change, update this value or refactor shared import; grep TODO(theme5).
_PHASE_D_INVALID_EXTERNAL_ID_RATIO_PASS_MAX = 0.02


def _seed_diagnostics_state_if_missing(state_path):
    """Best-effort bootstrap of diagnostics_state.json when absent."""
    if not state_path or os.path.exists(state_path):
        return False
    now_utc = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
    seed = {
        'version': 2,
        'updated_at_utc': now_utc,
        'last_phase_a_run_id': '',
        'last_phase_a_ok': None,
        'last_schema_sha256': '',
        'last_discovery_ok': None,
        'last_phase_c_ok': None,
        'last_phase_d_ok': None,
        'last_phase_e_ok': None,
        'last_shadow_pipeline_ok': None,
        'pipeline_state': 'idle',
        'active_run_id': '',
        'active_phase': '',
        'last_error_code': '',
        'started_at_utc': now_utc,
        'heartbeat_at_utc': None,
        'finished_at_utc': None,
    }
    return _save_json_dict(state_path, seed)


def _tail_parts_cross_platform(path_value):
    """Return (tail, parent_tail) while treating "\\" and "/" as path separators."""
    normalized = str(path_value or '').replace('\\', '/')
    parts = [p for p in normalized.split('/') if p]
    tail = parts[-1].lower() if parts else ''
    parent_tail = parts[-2].lower() if len(parts) >= 2 else ''
    return tail, parent_tail


def _log_health(level, message):
    """Best-effort logger for cloud readiness diagnostics."""
    try:
        if mc_log is not None:
            mc_log(message, level=level)
            return
    except Exception:
        pass
    try:
        print('{0}: {1}'.format(level, message))
    except Exception:
        pass


def _load_json_dict(path):
    if not path or not os.path.exists(path):
        return {}
    try:
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        if isinstance(data, dict):
            return data
    except (IOError, OSError, ValueError):
        pass
    return {}


def _save_json_dict(path, data):
    try:
        parent = os.path.dirname(path)
        if parent and not os.path.exists(parent):
            os.makedirs(parent)
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, sort_keys=True)
        return True
    except Exception:
        return False


def _collect_delivery_diagnostics():
    """Best-effort sender readiness snapshot for support-bundle telemetry."""
    diagnostics = {'token_available': None, 'recipient_count': None}
    if get_error_reporting_delivery_readiness is None:
        diagnostics['helper_unavailable'] = True
        return diagnostics
    try:
        shared = get_error_reporting_delivery_readiness(
            quiet_token=True,
            include_queue_paths=True,
        )
        if isinstance(shared, dict):
            diagnostics.update(shared)
    except Exception as e:
        diagnostics['helper_error'] = str(e)
    return diagnostics


def _emit_progress(progress_callback, stage_label):
    """Best-effort coarse status update for long-running cloud-readiness actions."""
    try:
        from MediCafe.bundle_build_telemetry import telemetry_record_milestone
        telemetry_record_milestone(str(stage_label or '').strip(), subsystem='cloud_readiness')
    except Exception:
        pass
    try:
        from MediCafe.debug_bundle_perf import agent_log_progress_stage
        agent_log_progress_stage('bundle_heartbeat', stage_label)
    except Exception:
        pass
    if not callable(progress_callback):
        return
    try:
        progress_callback(str(stage_label or '').strip())
    except Exception:
        pass


def _format_epoch_utc(epoch_value):
    try:
        if epoch_value is None:
            return ''
        return time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(int(epoch_value)))
    except Exception:
        return ''


def _parse_iso_utc_epoch(text_value):
    """Best-effort parse for %Y-%m-%dT%H:%M:%SZ timestamps."""
    try:
        text = str(text_value or '').strip()
        if not text:
            return None
        return int(calendar.timegm(time.strptime(text, '%Y-%m-%dT%H:%M:%SZ')))
    except Exception:
        return None


def _alert_state_epoch(state):
    try:
        if not isinstance(state, dict):
            return None
        for key in ('last_attempt_epoch', 'last_sent_epoch'):
            if key in state:
                value = state.get(key)
                if value in (None, ''):
                    continue
                return int(value)
    except Exception:
        return None
    return None


def _alert_state_age_sec(state, now_epoch=None):
    state_epoch = _alert_state_epoch(state)
    if not state_epoch:
        return None
    try:
        if now_epoch is None:
            now_epoch = int(time.time())
        return int(max(0, int(now_epoch) - int(state_epoch)))
    except Exception:
        return None


def _alert_state_freshness(state, now_epoch=None, stale_after_sec=None):
    age_sec = _alert_state_age_sec(state, now_epoch=now_epoch)
    if age_sec is None:
        return 'unknown'
    if stale_after_sec is None:
        stale_after_sec = _REPORT_DELIVERY_ALERT_STALE_SEC
    try:
        if age_sec >= int(stale_after_sec):
            return 'stale'
    except Exception:
        pass
    return 'fresh'


def _collect_failed_or_warned_signals(audit_payload):
    return _runbook_tools.collect_failed_or_warned_signals(audit_payload)


def _build_system_health_triage_runbook(audit_ok, audit_data, pack_ok, pack_path, report_path):
    return _runbook_tools.build_system_health_triage_runbook(
        audit_ok,
        audit_data,
        pack_ok,
        pack_path,
        report_path,
        collect_failed_or_warned_signals_fn=_collect_failed_or_warned_signals,
    )


def _build_system_health_pack_runbook(lab_root, audit_payload, artifacts, state_override=None, pack_scope='', anchor_run_id=''):
    return _runbook_tools.build_system_health_pack_runbook(
        lab_root,
        audit_payload,
        artifacts,
        parse_iso_utc_epoch_fn=_parse_iso_utc_epoch,
        load_json_dict_fn=_load_json_dict,
        state_override=state_override,
        pack_scope=pack_scope,
        anchor_run_id=anchor_run_id,
    )


def _build_delivery_runbook_lines(delivery_diag, orchestrator_error_code=None):
    return _runbook_tools.build_delivery_runbook_lines(
        delivery_diag,
        orchestrator_error_code=orchestrator_error_code,
    )


def _safe_json_loads(value, default=None):
    return _patient_tools._IMPL_safe_json_loads(value, default=default)


def _safe_int(value, fallback=0):
    return _patient_tools._IMPL_safe_int(value, fallback=fallback)


def _slug_token(value, fallback='unknown'):
    return _patient_tools._IMPL_slug_token(value, fallback=fallback)


def _collect_data_plane_snapshot(lab_root):
    return _patient_tools._IMPL_collect_data_plane_snapshot(
        lab_root,
        safe_int_fn=_safe_int,
    )


def _collect_db_enrichment_summary(lab_root):
    return _patient_tools._IMPL_collect_db_enrichment_summary(
        lab_root,
        safe_int_fn=_safe_int,
    )


def _sorted_count_items(counts, preferred_keys=None):
    counts = counts if isinstance(counts, dict) else {}
    preferred = preferred_keys or []
    items = []
    seen = set()
    for key in preferred:
        if key in counts and key not in seen:
            items.append((key, _safe_int(counts.get(key), 0)))
            seen.add(key)
    remainder = []
    for key, value in counts.items():
        if key in seen:
            continue
        remainder.append((str(key), _safe_int(value, 0)))
    remainder = sorted(remainder, key=lambda item: (-_safe_int(item[1], 0), str(item[0])))
    items.extend(remainder)
    return items


def _format_count_map(counts, preferred_keys=None, limit=None):
    items = _sorted_count_items(counts, preferred_keys=preferred_keys)
    if limit is not None:
        items = items[:max(0, _safe_int(limit, 0))]
    if not items:
        return 'none'
    return ', '.join('{0}:{1}'.format(key, value) for key, value in items)


def _percent_text(numerator, denominator):
    numerator = _safe_int(numerator, 0)
    denominator = _safe_int(denominator, 0)
    if denominator <= 0:
        return 'n/a'
    try:
        return '{0:.3f}'.format(float(numerator) / float(denominator))
    except Exception:
        return 'n/a'


def _readiness_level(score, hard_blockers):
    score = _safe_int(score, 0)
    if hard_blockers:
        if score >= 50:
            return 'blocked_with_partial_population'
        return 'blocked'
    if score >= 85:
        return 'ready_candidate'
    if score >= 60:
        return 'partial'
    return 'not_ready'


def _build_unified_db_readiness_lines(lab_root, snapshot=None, diagnostics_state=None):
    lines = ['Unified DB Readiness:']
    snap = snapshot if isinstance(snapshot, dict) else _collect_data_plane_snapshot(lab_root)
    if not snap.get('ok'):
        lines.append(' - overall=unavailable score=0/100 reason={0}'.format(
            snap.get('error') or 'db snapshot unavailable'))
        return lines
    summary = _collect_db_enrichment_summary(lab_root)
    if not summary.get('ok'):
        lines.append(' - overall=unavailable score=0/100 reason={0}'.format(
            summary.get('error') or 'db enrichment summary unavailable'))
        return lines

    state = diagnostics_state if isinstance(diagnostics_state, dict) else {}
    counts = snap.get('counts', {}) if isinstance(snap.get('counts', {}), dict) else {}
    canonical_counts = summary.get('canonical_type_counts', {}) if isinstance(summary.get('canonical_type_counts', {}), dict) else {}
    cumulative_join = summary.get('csv_docx_join', {}) if isinstance(summary.get('csv_docx_join', {}), dict) else {}
    latest_csv_docx = state.get('last_phase_d_csv_docx_join_telemetry', {}) if isinstance(state.get('last_phase_d_csv_docx_join_telemetry', {}), dict) else {}
    latest_dat_csv = state.get('last_phase_d_dat_csv_join_telemetry', {}) if isinstance(state.get('last_phase_d_dat_csv_join_telemetry', {}), dict) else {}
    dat = state.get('last_phase_d_dat_telemetry', {}) if isinstance(state.get('last_phase_d_dat_telemetry', {}), dict) else {}
    constraint_skips = state.get('last_phase_d_constraint_skip_counts', {}) if isinstance(state.get('last_phase_d_constraint_skip_counts', {}), dict) else {}

    patient_rows = _safe_int(counts.get('patient'), 0)
    patient_count = _safe_int(
        snap.get('patient_count_effective'),
        _safe_int(snap.get('patient_latest_identity_count'), patient_rows))
    duplicate_identity_rows = max(0, patient_rows - patient_count)
    projection_success = _safe_int(
        snap.get('projection_success_count_effective'),
        _safe_int(snap.get('projection_success_count'), 0))
    qa_reject = _safe_int(
        snap.get('qa_reject_count_effective'),
        _safe_int(snap.get('qa_reject_count'), 0))
    replay_pending = _safe_int(snap.get('replay_pending_count'), 0)

    cumulative_csv_keys = _safe_int(cumulative_join.get('csv_join_key_count'), 0)
    cumulative_docx_keys = _safe_int(cumulative_join.get('docx_join_key_count'), 0)
    cumulative_overlap = _safe_int(
        cumulative_join.get('overlap_join_key_count'),
        _safe_int(cumulative_join.get('matched_count'), 0))
    cumulative_join_den = max(cumulative_csv_keys, cumulative_docx_keys)
    latest_csv_docx_matched = _safe_int(latest_csv_docx.get('matched_count'), 0)
    latest_csv_docx_csv_only = _safe_int(latest_csv_docx.get('csv_only_count'), 0)
    latest_csv_docx_docx_only = _safe_int(latest_csv_docx.get('docx_only_count'), 0)
    latest_csv_docx_ambiguous = _safe_int(latest_csv_docx.get('ambiguous_count'), 0)

    dat_selected = _safe_int(dat.get('dat_selected_count'), 0)
    dat_field_presence = dat.get('dat_field_presence_by_alias', {}) if isinstance(dat.get('dat_field_presence_by_alias', {}), dict) else {}
    dat_records_seen = _safe_int(dat_field_presence.get('records_seen'), 0)
    dat_qa_pass = _safe_int(dat.get('dat_qa_pass_count'), 0)
    dat_qa_reject = _safe_int(dat.get('dat_qa_reject_count'), 0)
    dat_canonical = _safe_int(dat.get('dat_canonical_record_count'), 0)
    dat_csv_matched = _safe_int(latest_dat_csv.get('matched_count'), 0)
    dat_csv_invalid = _safe_int(latest_dat_csv.get('invalid_external_id_csv_count'), 0)
    invalid_patient_skips = _safe_int(constraint_skips.get('patient_invalid_external_id'), 0)

    coverage_count = _safe_int(counts.get('coverage'), 0)
    encounter_count = _safe_int(counts.get('encounter'), 0)
    claim_count = _safe_int(counts.get('claim'), 0)
    claim_line_count = _safe_int(counts.get('claim_line'), 0)

    score = 0
    blockers = []
    if patient_count > 0:
        score += 15
    if projection_success > 0:
        score += 10
    if cumulative_overlap > 0 and cumulative_join_den > 0:
        score += 15
    if latest_csv_docx_matched > 0:
        score += 10
    if dat_selected > 0 and dat_qa_pass > 0 and dat_canonical > 0 and dat_csv_matched > 0:
        score += 20
    elif dat_selected > 0:
        blockers.append('dat_selected_but_not_integrated')
    if coverage_count > 0 and encounter_count > 0:
        score += 15
    else:
        blockers.append('relational_chain_shallow')
    if qa_reject <= 0 and replay_pending <= 0:
        score += 10
    else:
        blockers.append('quality_backlog_active')
    if invalid_patient_skips <= 0 and dat_csv_invalid <= 0:
        score += 5
    else:
        blockers.append('invalid_external_patient_ids')

    overall = _readiness_level(score, blockers)
    lines.append(' - overall={0} score={1}/100 blockers={2}'.format(
        overall,
        score,
        ','.join(blockers) if blockers else 'none'))
    lines.append(
        ' - patient_identity=patient_count:{0}, raw_patient_rows:{1}, duplicate_identity_rows:{2}, projection_success:{3}'.format(
            patient_count,
            patient_rows,
            duplicate_identity_rows,
            projection_success,
        )
    )
    lines.append(
        ' - cross_source_csv_docx=cumulative_overlap_keys:{0}, cumulative_csv_keys:{1}, cumulative_docx_keys:{2}, cumulative_overlap_rate:{3}, latest_matched:{4}, latest_csv_only:{5}, latest_docx_only:{6}, latest_ambiguous:{7}'.format(
            cumulative_overlap,
            cumulative_csv_keys,
            cumulative_docx_keys,
            _percent_text(cumulative_overlap, cumulative_join_den),
            latest_csv_docx_matched,
            latest_csv_docx_csv_only,
            latest_csv_docx_docx_only,
            latest_csv_docx_ambiguous,
        )
    )
    lines.append(
        ' - dat_integration=selected:{0}, records_seen:{1}, qa_pass:{2}, qa_reject:{3}, canonical:{4}, dat_csv_matched:{5}, invalid_external_id_csv:{6}'.format(
            dat_selected,
            dat_records_seen,
            dat_qa_pass,
            dat_qa_reject,
            dat_canonical,
            dat_csv_matched,
            dat_csv_invalid,
        )
    )
    lines.append(
        ' - relational_depth=coverage:{0}, encounter:{1}, claim:{2}, claim_line:{3}'.format(
            coverage_count,
            encounter_count,
            claim_count,
            claim_line_count,
        )
    )
    lines.append(
        ' - quality_backlog=qa_reject:{0}, replay_pending:{1}, patient_invalid_external_id_skips:{2}'.format(
            qa_reject,
            replay_pending,
            invalid_patient_skips,
        )
    )
    lines.append(
        ' - canonical_population={0}'.format(
            _format_count_map(
                canonical_counts,
                preferred_keys=['patient_csv_row', 'docx_schedule', 'dat_record', 'x12_member', 'remittance_row'],
                limit=8,
            )
        )
    )
    parser_status = 'dat_not_exercised'
    if dat_selected > 0 and dat_records_seen <= 0:
        parser_status = 'dat_selected_zero_records'
    elif dat_selected > 0 and dat_qa_pass <= 0:
        parser_status = 'dat_records_not_qa_clean'
    elif dat_selected > 0 and dat_canonical > 0:
        parser_status = 'dat_parser_to_canonical_present'
    lines.append(' - parser_parity=production_parser_status:{0}, dat_reject_mix:{1}'.format(
        parser_status,
        _format_count_map(
            dat.get('dat_qa_reject_counts_by_reason', {}) if isinstance(dat.get('dat_qa_reject_counts_by_reason', {}), dict) else {},
            limit=5),
    ))
    if overall in ('ready_candidate', 'partial'):
        guidance = 'continue validation; verify sampled patient timelines before GCP cutover'
    else:
        guidance = 'not_gcp_ready; resolve DAT parse/join blockers, invalid external IDs, and shallow relational chain before migration reliance'
    lines.append(' - migration_guidance={0}'.format(guidance))
    return lines


def _build_db_enrichment_overview_lines(lab_root, snapshot=None, compact=False):
    title = 'DB enrichment overview (cumulative lab state):' if compact else 'DB Enrichment Overview:'
    lines = [title]
    snap = snapshot if isinstance(snapshot, dict) else _collect_data_plane_snapshot(lab_root)
    if not snap.get('ok'):
        lines.append(' - unavailable ({0})'.format(snap.get('error') or 'db snapshot unavailable'))
        return lines
    summary = _collect_db_enrichment_summary(lab_root)
    if not summary.get('ok'):
        lines.append(' - unavailable ({0})'.format(summary.get('error') or 'db enrichment summary unavailable'))
        return lines

    counts = snap.get('counts', {}) if isinstance(snap.get('counts', {}), dict) else {}
    patient_rows = _safe_int(counts.get('patient'), 0)
    patient_count = _safe_int(
        snap.get('patient_count_effective'),
        _safe_int(snap.get('patient_latest_identity_count'), patient_rows))
    qa_pass = _safe_int(
        snap.get('qa_pass_count_effective'),
        _safe_int(snap.get('qa_pass_count'), 0))
    qa_reject = _safe_int(
        snap.get('qa_reject_count_effective'),
        _safe_int(snap.get('qa_reject_count'), 0))
    projection_success = _safe_int(
        snap.get('projection_success_count_effective'),
        _safe_int(snap.get('projection_success_count'), 0))
    projection_reject = _safe_int(
        snap.get('projection_reject_count_effective'),
        _safe_int(snap.get('projection_reject_count'), 0))
    replay_pending = _safe_int(snap.get('replay_pending_count'), 0)

    ingest_counts = summary.get('ingest_source_type_counts', {}) if isinstance(summary.get('ingest_source_type_counts', {}), dict) else {}
    canonical_counts = summary.get('canonical_type_counts', {}) if isinstance(summary.get('canonical_type_counts', {}), dict) else {}
    join = summary.get('csv_docx_join', {}) if isinstance(summary.get('csv_docx_join', {}), dict) else {}
    csv_rows = _safe_int(join.get('csv_candidate_count'), 0)
    csv_unique_keys = _safe_int(join.get('csv_join_key_count'), 0)
    docx_rows = _safe_int(join.get('docx_candidate_count'), 0)
    docx_unique_keys = _safe_int(join.get('docx_join_key_count'), 0)
    overlap_keys = _safe_int(join.get('overlap_join_key_count'), _safe_int(join.get('matched_count'), 0))
    csv_only_keys = _safe_int(join.get('csv_only_join_key_count'), _safe_int(join.get('csv_only_count'), 0))
    docx_only_keys = _safe_int(join.get('docx_only_join_key_count'), _safe_int(join.get('docx_only_count'), 0))
    historical_duplicate_keys = _safe_int(join.get('historical_duplicate_key_count'), 0)
    csv_missing_join_key_rows = _safe_int(join.get('csv_no_join_key_count'), 0)
    duplicate_breakdown = join.get('historical_duplicate_breakdown', {}) if isinstance(join.get('historical_duplicate_breakdown', {}), dict) else {}
    scope_note = str(join.get('scope_note', '') or '').strip()
    if not scope_note:
        scope_note = 'overlap/csv_only/docx_only use unique cumulative join keys; historical_duplicate_keys reflects repeated keys across stored DB history and is not unresolved ambiguity by itself'

    lines.append(' - intake_sources={0}'.format(
        _format_count_map(ingest_counts, preferred_keys=['csv', 'docx', 'dat', '837', 'receipt'])
    ))
    if not compact:
        lines.append(' - canonical_types={0}'.format(
            _format_count_map(
                canonical_counts,
                preferred_keys=['patient_csv_row', 'docx_schedule', 'dat_record', 'x12_member', 'remittance_row']
            )
        ))
    lines.append(
        ' - upstream_csv_docx_join=csv_rows={0}, csv_keys={1}, docx_rows={2}, docx_keys={3}, overlap_keys={4}, csv_only_keys={5}, docx_only_keys={6}, historical_duplicate_keys={7}, csv_missing_join_key={8}'.format(
            csv_rows,
            csv_unique_keys,
            docx_rows,
            docx_unique_keys,
            overlap_keys,
            csv_only_keys,
            docx_only_keys,
            historical_duplicate_keys,
            csv_missing_join_key_rows,
        )
    )
    lines.append(
        ' - upstream_csv_docx_unique_key_outcomes=overlap_keys={0}, csv_only_keys={1}, docx_only_keys={2}'.format(
            overlap_keys,
            csv_only_keys,
            docx_only_keys,
        )
    )
    lines.append(
        ' - upstream_csv_docx_volume=csv_rows={0}, csv_unique_keys={1}, docx_rows={2}, docx_unique_keys={3}, csv_missing_join_key_rows={4}'.format(
            csv_rows,
            csv_unique_keys,
            docx_rows,
            docx_unique_keys,
            csv_missing_join_key_rows,
        )
    )
    lines.append(
        ' - upstream_csv_docx_historical_duplicate_pressure=duplicate_keys={0}, both_sources={1}, csv_only={2}, docx_only={3}'.format(
            historical_duplicate_keys,
            _safe_int(duplicate_breakdown.get('both_sources'), 0),
            _safe_int(duplicate_breakdown.get('csv_only'), 0),
            _safe_int(duplicate_breakdown.get('docx_only'), 0),
        )
    )
    lines.append(' - join_scope_note={0}'.format(scope_note))
    if compact:
        lines.append(' - join_scope_note_phase_d=check latest Phase D run telemetry for unresolved ambiguity; this cumulative block reports historical duplicate pressure separately')
    else:
        lines.append(' - join_scope_note_phase_d=latest Phase D run telemetry, not cumulative DB history, is the source of truth for unresolved ambiguity')
    if not compact and sum(_safe_int(v, 0) for v in duplicate_breakdown.values()) > 0:
        lines.append(
            ' - historical_duplicate_breakdown=both_sources={0}, csv_only={1}, docx_only={2}'.format(
                _safe_int(duplicate_breakdown.get('both_sources'), 0),
                _safe_int(duplicate_breakdown.get('csv_only'), 0),
                _safe_int(duplicate_breakdown.get('docx_only'), 0),
            )
        )
        duplicate_examples = join.get('historical_duplicate_examples', []) if isinstance(join.get('historical_duplicate_examples', []), list) else []
        formatted_examples = []
        for item in duplicate_examples[:5]:
            if not isinstance(item, dict):
                continue
            formatted_examples.append(
                '{0}(csv={1},docx={2})'.format(
                    str(item.get('join_key', '') or '').strip() or '-',
                    _safe_int(item.get('csv_count'), 0),
                    _safe_int(item.get('docx_count'), 0),
                )
            )
        if formatted_examples:
            lines.append(' - historical_duplicate_examples={0}'.format(' | '.join(formatted_examples)))
    reason_counts = join.get('csv_no_join_key_reason_counts', {}) if isinstance(join.get('csv_no_join_key_reason_counts', {}), dict) else {}
    if not compact and sum(_safe_int(v, 0) for v in reason_counts.values()) > 0:
        lines.append(' - csv_missing_join_key_reasons={0}'.format(
            _format_count_map(reason_counts, preferred_keys=['missing_patient_id', 'missing_surgery_date', 'other'])
        ))
    lines.append(
        ' - relational_depth=patient_count={0}, coverage_count={1}, encounter_count={2}, claim_count={3}, claim_line_count={4}'.format(
            patient_count,
            _safe_int(counts.get('coverage'), 0),
            _safe_int(counts.get('encounter'), 0),
            _safe_int(counts.get('claim'), 0),
            _safe_int(counts.get('claim_line'), 0),
        )
    )
    lines.append(
        ' - forward_motion=qa_pass={0}, qa_reject={1}, projection_success={2}, projection_reject={3}, replay_pending={4}'.format(
            qa_pass,
            qa_reject,
            projection_success,
            projection_reject,
            replay_pending,
        )
    )

    interpretation = []
    if sum(_safe_int(v, 0) for v in ingest_counts.values()) > 0 or sum(_safe_int(v, 0) for v in canonical_counts.values()) > 0:
        interpretation.append('upstream_evidence_present')
    if (_safe_int(join.get('csv_candidate_count'), 0) > 0
            or _safe_int(join.get('docx_candidate_count'), 0) > 0
            or _safe_int(join.get('overlap_join_key_count'), _safe_int(join.get('matched_count'), 0)) > 0):
        interpretation.append('upstream_enrichment_accumulating')
    if (_safe_int(counts.get('coverage'), 0) <= 0
            and _safe_int(counts.get('encounter'), 0) <= 0
            and _safe_int(counts.get('claim'), 0) <= 0
            and _safe_int(counts.get('claim_line'), 0) <= 0):
        interpretation.append('relational_chain_still_shallow')
    else:
        interpretation.append('relational_chain_materialized')
    if qa_reject > 0 or replay_pending > 0:
        interpretation.append('quality_backlog_present')
    else:
        interpretation.append('quality_backlog_clear')
    lines.append(' - interpretation={0}'.format('; '.join(interpretation) if interpretation else 'unknown'))
    return lines


def _score_patient_chain_row(row):
    return _patient_tools._IMPL_score_patient_chain_row(row, safe_int_fn=_safe_int)


def _collect_patient_chain_rows(
        conn,
        limit=200,
        projection_version_scope=None,
        collapse_latest_by_identity=True):
    return _patient_tools._IMPL_collect_patient_chain_rows(
        conn,
        limit=limit,
        safe_int_fn=_safe_int,
        score_patient_chain_row_fn=_score_patient_chain_row,
        projection_version_scope=projection_version_scope,
        collapse_latest_by_identity=collapse_latest_by_identity,
    )


def _patient_display_id(row):
    return _patient_tools._IMPL_patient_display_id(row)


def _build_guided_patient_options(rows, diagnostics_state):
    return _patient_tools._IMPL_build_guided_patient_options(
        rows,
        diagnostics_state,
        safe_int_fn=_safe_int,
        patient_display_id_fn=_patient_display_id,
    )


def _find_patient_option_by_reference(rows, patient_ref):
    return _patient_tools._IMPL_find_patient_option_by_reference(
        rows,
        patient_ref,
        safe_int_fn=_safe_int,
    )


def _build_guided_options_runbook_lines(snapshot, options):
    return _patient_tools._IMPL_build_guided_options_runbook_lines(snapshot, options)


def _build_patient_reference_options(rows, limit=25):
    return _patient_tools._IMPL_build_patient_reference_options(
        rows,
        limit=limit,
        safe_int_fn=_safe_int,
        patient_display_id_fn=_patient_display_id,
    )


def _build_no_patient_guidance_payload(snapshot, diagnostics_state, lab_root, db_path):
    """Build actionable runbook payload when guided patient rows are unavailable."""
    snap = snapshot if isinstance(snapshot, dict) else {}
    state = diagnostics_state if isinstance(diagnostics_state, dict) else {}
    counts = snap.get('counts', {}) if isinstance(snap.get('counts', {}), dict) else {}
    patient_rows = _safe_int(counts.get('patient'), 0)
    patient_count = _safe_int(
        snap.get('patient_count_effective'),
        _safe_int(snap.get('patient_latest_identity_count'), patient_rows))
    qa_reject_count = _safe_int(
        snap.get('qa_reject_count_effective'),
        _safe_int(snap.get('qa_reject_count'), 0))
    replay_pending_count = _safe_int(snap.get('replay_pending_count'), 0)
    projection_success_count = _safe_int(
        snap.get('projection_success_count_effective'),
        _safe_int(snap.get('projection_success_count'), 0))
    qa_scope = str(snap.get('qa_scope_version', '') or '').strip()
    projection_scope = str(snap.get('projection_scope_version', '') or '').strip()
    active_run_id = str(state.get('active_run_id', '') or '').strip()
    last_run_id = str(state.get('last_shadow_pipeline_run_id', '') or '').strip()
    pipeline_state = str(state.get('pipeline_state', '') or '').strip().lower() or 'unknown'

    runbook_lines = [
        'Guided Patient Completeness Runbook:',
        ' - condition=no_patient_rows',
        ' - data_plane_status={0}'.format(snap.get('status', 'unknown')),
        ' - patient_count={0}{1}'.format(
            patient_count,
            ' (raw_patient_rows={0})'.format(patient_rows) if patient_rows != patient_count else ''),
        ' - qa_reject_count={0}'.format(qa_reject_count),
        ' - replay_pending_count={0}'.format(replay_pending_count),
        ' - projection_success_count={0}'.format(projection_success_count),
        ' - quality_scope=qa_version:{0}, projection_version:{1}'.format(
            qa_scope or '-',
            projection_scope or '-'),
        ' - pipeline_state={0}'.format(pipeline_state),
        ' - active_run_id={0}'.format(active_run_id or '-'),
        ' - last_shadow_pipeline_run_id={0}'.format(last_run_id or '-'),
    ]

    actions = []
    actions.append(
        'No patient rows are currently materialized in the local XP DB. This is a data-state condition, not a launcher failure.'
    )
    if qa_reject_count > 0 or replay_pending_count > 0:
        actions.append(
            'Review QA rejects/replay queue first (qa_reject_count={0}, replay_pending_count={1}) and clear pending replay items.'.format(
                qa_reject_count, replay_pending_count
            )
        )
    if projection_success_count <= 0:
        actions.append(
            'Inspect latest Phase E projection/parity outputs for zero patient projections before rerunning guided completeness.'
        )
    if active_run_id:
        actions.append(
            'Pipeline is active (run_id={0}); wait for completion, then reopen Guided Patient Completeness Runbook.'.format(
                active_run_id
            )
        )
    elif last_run_id:
        actions.append(
            'Inspect run-scoped evidence for run_id={0} via Cloud Phase Artifact Tools (A/B), then re-run full shadow pipeline (A->F) if still empty.'.format(
                last_run_id
            )
        )
    else:
        actions.append(
            'No prior pipeline run ID is recorded; trigger full shadow pipeline (A->F), then reopen Guided Patient Completeness Runbook.'
        )
    actions.append(
        'Re-open Cloud Readiness -> 2) Investigate patient / data -> 1) Guided completeness after data-state changes.'
    )
    action_lines = ['What To Do Now:']
    step = 1
    for item in actions:
        action_lines.append(' {0}) {1}'.format(step, item))
        step += 1
    runbook_lines.extend(action_lines)

    return {
        'condition': 'no_patient_rows',
        'lab_root': lab_root,
        'db_path': db_path,
        'snapshot': snap,
        'diagnostics_state': state,
        'options': [],
        'runbook_lines': runbook_lines,
        'actions': actions,
    }


def get_guided_patient_completeness_options(repo_root):
    """Return enriched letter options for patient completeness runbook flow."""
    lab_root = resolve_lab_root(repo_root)
    reports_err = _reports_dir_access_error(lab_root)
    if reports_err:
        return (False, reports_err, None)
    snapshot = _collect_data_plane_snapshot(lab_root)
    if not snapshot.get('ok'):
        return (False, snapshot.get('error') or 'Unable to read lab DB.', None)
    diagnostics_state = _load_json_dict(os.path.join(lab_root, 'diagnostics_state.json'))
    projection_version_scope = str(diagnostics_state.get('last_projection_version', '') or '').strip()
    db_path = snapshot.get('db_path')
    rows = []
    conn = None
    try:
        conn = sqlite3.connect(db_path)
        conn.execute("PRAGMA foreign_keys = ON")
        rows = _collect_patient_chain_rows(
            conn,
            limit=250,
            projection_version_scope=projection_version_scope,
        )
    except Exception as e:
        return (False, 'DB query failed: {0}'.format(e), None)
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass
    if not rows:
        guidance = _build_no_patient_guidance_payload(snapshot, diagnostics_state, lab_root, db_path)
        return (
            False,
            'Guided patient completeness unavailable due to current data-state (0 patient rows). '
            'Launcher is healthy; review runbook actions below.',
            guidance,
        )
    options = _build_guided_patient_options(rows, diagnostics_state)
    runbook_lines = _build_guided_options_runbook_lines(snapshot, options)
    return (True, 'Guided patient completeness options ready.', {
        'lab_root': lab_root,
        'db_path': db_path,
        'snapshot': snapshot,
        'options': options,
        'runbook_lines': runbook_lines,
    })




def get_patient_flow_reference_options(repo_root, limit=25):
    """Return auto-populated patient reference options for flow runbook selection."""
    lab_root = resolve_lab_root(repo_root)
    reports_err = _reports_dir_access_error(lab_root)
    if reports_err:
        return (False, reports_err, None)
    snapshot = _collect_data_plane_snapshot(lab_root)
    if not snapshot.get('ok'):
        return (False, snapshot.get('error') or 'Unable to read lab DB.', None)
    diagnostics_state = _load_json_dict(os.path.join(lab_root, 'diagnostics_state.json'))
    projection_version_scope = str(diagnostics_state.get('last_projection_version', '') or '').strip()
    db_path = snapshot.get('db_path')
    rows = []
    conn = None
    try:
        conn = sqlite3.connect(db_path)
        conn.execute("PRAGMA foreign_keys = ON")
        rows = _collect_patient_chain_rows(
            conn,
            limit=max(25, _safe_int(limit, 25)),
            projection_version_scope=projection_version_scope,
        )
    except Exception as e:
        return (False, 'DB query failed: {0}'.format(e), None)
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass

    if not rows:
        guidance = _build_no_patient_guidance_payload(snapshot, diagnostics_state, lab_root, db_path)
        return (
            False,
            'Patient flow options unavailable due to current data-state (0 patient rows).',
            guidance,
        )

    options = _build_patient_reference_options(rows, limit=_safe_int(limit, 25))
    return (True, 'Patient flow reference options ready.', {
        'lab_root': lab_root,
        'db_path': db_path,
        'snapshot': snapshot,
        'options': options,
    })


def _query_rows_for_ids(conn, sql_prefix, ids, sql_suffix='', max_rows=120):
    return _patient_tools._IMPL_query_rows_for_ids(
        conn,
        sql_prefix,
        ids,
        sql_suffix=sql_suffix,
        max_rows=max_rows,
        safe_int_fn=_safe_int,
    )


def _build_patient_trace_payload(conn, reports_dir, selected):
    return _patient_tools._IMPL_build_patient_trace_payload(
        conn,
        reports_dir,
        selected,
        find_latest_by_prefix_fn=_find_latest_by_prefix,
        safe_int_fn=_safe_int,
        safe_json_loads_fn=_safe_json_loads,
        query_rows_for_ids_fn=_query_rows_for_ids,
    )


def _build_patient_trace_decision(selected, trace, diagnostics_state):
    return _patient_tools._IMPL_build_patient_trace_decision(
        selected,
        trace,
        diagnostics_state,
        safe_int_fn=_safe_int,
    )


def _write_patient_trace_runbook_report(reports_dir, payload):
    return _patient_tools._IMPL_write_patient_trace_runbook_report(
        reports_dir,
        payload,
        safe_int_fn=_safe_int,
        slug_token_fn=_slug_token,
    )


def open_guided_patient_completeness_runbook(repo_root, option_code):
    """Generate one patient completeness runbook report from lettered enriched options."""
    code = str(option_code or '').strip().upper()
    if not code:
        return (False, 'Option code is required.', None)
    ok, msg, data = get_guided_patient_completeness_options(repo_root)
    if not ok:
        return (False, msg, None)
    options = data.get('options', []) if isinstance(data, dict) else []
    selected = None
    for item in options:
        if str(item.get('code', '')).upper() == code:
            selected = item
            break
    if not isinstance(selected, dict):
        valid = ','.join([str(x.get('code', '')).upper() for x in options]) or '(none)'
        return (False, 'Invalid option code: {0}. valid={1}'.format(code, valid), None)

    lab_root = data.get('lab_root') if isinstance(data, dict) else resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    db_path = data.get('db_path') if isinstance(data, dict) else os.path.join(lab_root, 'unified_model_xp.db')
    diagnostics_state = _load_json_dict(os.path.join(lab_root, 'diagnostics_state.json'))
    snapshot = data.get('snapshot', {}) if isinstance(data, dict) else {}

    conn = None
    try:
        conn = sqlite3.connect(db_path)
        conn.execute("PRAGMA foreign_keys = ON")
        trace = _build_patient_trace_payload(conn, reports_dir, selected)
    except Exception as e:
        return (False, 'Unable to build patient trace: {0}'.format(e), None)
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass

    decision = _build_patient_trace_decision(selected, trace, diagnostics_state)
    payload = {
        'generated_at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        'selected': selected,
        'snapshot': snapshot,
        'artifact_ids': trace.get('artifact_ids', []),
        'artifact_pointers': trace.get('artifact_pointers', {}),
        'rows': trace.get('rows', {}),
        'decision': decision,
    }
    try:
        path_txt, _ = _write_patient_trace_runbook_report(reports_dir, payload)
    except Exception as e:
        return (False, 'Failed to write patient runbook report: {0}'.format(e), None)
    msg_out = 'Patient completeness runbook generated. verdict={0} patient={1}'.format(
        decision.get('verdict', 'UNKNOWN'),
        selected.get('display_id', selected.get('patient_key', '')),
    )
    return (True, msg_out, path_txt)


def open_patient_flow_runbook(repo_root, patient_ref):
    """Generate a patient flow runbook for an explicit patient reference."""
    ref = str(patient_ref or '').strip()
    if not ref:
        return (False, 'Patient reference is required (patient_id/external_patient_id/patient_key).', None)
    ok, msg, data = get_patient_flow_reference_options(repo_root, limit=250)
    if not ok or not isinstance(data, dict):
        return (False, msg or 'Patient flow unavailable.', None)

    options = data.get('options', []) if isinstance(data.get('options', []), list) else []
    selected = _find_patient_option_by_reference(options, ref)
    if not isinstance(selected, dict):
        return (
            False,
            'Patient reference not found in available patient options: {0}. '
            'Open patient flow options (menu option 5) to pick an auto-populated reference.'.format(ref),
            None,
        )

    lab_root = data.get('lab_root') if isinstance(data, dict) else resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    db_path = data.get('db_path') if isinstance(data, dict) else os.path.join(lab_root, 'unified_model_xp.db')
    diagnostics_state = _load_json_dict(os.path.join(lab_root, 'diagnostics_state.json'))
    snapshot = data.get('snapshot', {}) if isinstance(data, dict) else {}

    conn = None
    try:
        conn = sqlite3.connect(db_path)
        conn.execute("PRAGMA foreign_keys = ON")
        trace = _build_patient_trace_payload(conn, reports_dir, selected)
    except Exception as e:
        return (False, 'Unable to build patient flow trace: {0}'.format(e), None)
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass

    decision = _build_patient_trace_decision(selected, trace, diagnostics_state)
    payload = {
        'generated_at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        'selected': selected,
        'snapshot': snapshot,
        'artifact_ids': trace.get('artifact_ids', []),
        'artifact_pointers': trace.get('artifact_pointers', {}),
        'rows': trace.get('rows', {}),
        'decision': decision,
    }
    try:
        path_txt, _ = _write_patient_trace_runbook_report(reports_dir, payload)
    except Exception as e:
        return (False, 'Failed to write patient flow runbook report: {0}'.format(e), None)
    msg_out = 'Patient flow runbook generated. verdict={0} patient={1}'.format(
        decision.get('verdict', 'UNKNOWN'),
        selected.get('display_id', selected.get('patient_key', '')),
    )
    return (True, msg_out, path_txt)


def _normalize_data_plane_report_type(report_type):
    """Normalize report type aliases for data-plane audit reports."""
    key = str(report_type or 'overview').strip().lower()
    aliases = {
        'overview': 'overview',
        'summary': 'overview',
        'recent': 'recent',
        'recent_patients': 'recent',
        'high_risk': 'high_risk',
        'high-risk': 'high_risk',
        'risky': 'high_risk',
        'risk': 'high_risk',
    }
    return aliases.get(key, 'overview')


def _summarize_patient_chain_rows(rows):
    """Return aggregate counts for a list of scored patient-chain rows."""
    items = rows if isinstance(rows, list) else []
    out = {
        'rows': len(items),
        'risk_high': 0,
        'risk_medium': 0,
        'risk_low': 0,
        'missing_any': 0,
        'projection_reject_any': 0,
        'with_coverage': 0,
        'with_encounter': 0,
        'with_claim': 0,
        'with_claim_line': 0,
    }
    for row in items:
        risk = str(row.get('risk_label', '') or '').strip().upper()
        if risk == 'HIGH':
            out['risk_high'] += 1
        elif risk == 'MEDIUM':
            out['risk_medium'] += 1
        else:
            out['risk_low'] += 1
        if _safe_int(row.get('missing_count'), 0) > 0:
            out['missing_any'] += 1
        if _safe_int(row.get('projection_reject_count'), 0) > 0:
            out['projection_reject_any'] += 1
        if _safe_int(row.get('coverage_count'), 0) > 0:
            out['with_coverage'] += 1
        if _safe_int(row.get('encounter_count'), 0) > 0:
            out['with_encounter'] += 1
        if _safe_int(row.get('claim_count'), 0) > 0:
            out['with_claim'] += 1
        if _safe_int(row.get('claim_line_count'), 0) > 0:
            out['with_claim_line'] += 1
    return out


def _write_data_plane_audit_report(reports_dir, payload, report_type):
    """Write data-plane audit report text/json and latest aliases."""
    report_key = _normalize_data_plane_report_type(report_type)
    stamp = time.strftime('%Y%m%d-%H%M%S', time.gmtime())
    base = 'db_data_audit_{0}_{1}'.format(report_key, stamp)
    txt_path = os.path.join(reports_dir, base + '.txt')
    json_path = os.path.join(reports_dir, base + '.json')
    latest_txt = os.path.join(reports_dir, 'db_data_audit_{0}_latest.txt'.format(report_key))
    latest_json = os.path.join(reports_dir, 'db_data_audit_{0}_latest.json'.format(report_key))

    snap = payload.get('snapshot', {}) if isinstance(payload.get('snapshot', {}), dict) else {}
    counts = snap.get('counts', {}) if isinstance(snap.get('counts', {}), dict) else {}
    rows = payload.get('sample_rows', []) if isinstance(payload.get('sample_rows', []), list) else []
    summary_all = payload.get('summary_all_rows', {}) if isinstance(payload.get('summary_all_rows', {}), dict) else {}
    summary_sample = payload.get('summary_sample_rows', {}) if isinstance(payload.get('summary_sample_rows', {}), dict) else {}

    db_path = str(payload.get('db_path', '') or '')
    db_size = ''
    db_mtime = ''
    try:
        if db_path and os.path.exists(db_path):
            db_size = str(os.path.getsize(db_path))
            db_mtime = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(os.path.getmtime(db_path)))
    except Exception:
        pass

    lines = []
    lines.append('DB Data Audit Report')
    lines.append('generated_at_utc={0}'.format(time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())))
    lines.append('report_type={0}'.format(report_key))
    lines.append('selection_rule={0}'.format(payload.get('selection_rule', 'recent_created_at')))
    lines.append('lab_root={0}'.format(payload.get('lab_root', '(unset)')))
    lines.append('db_path={0}'.format(db_path or '(unset)'))
    lines.append('db_file_size_bytes={0}'.format(db_size or '-'))
    lines.append('db_last_modified_utc={0}'.format(db_mtime or '-'))
    lines.append('')
    lines.append('Data Plane Summary:')
    if snap.get('ok'):
        patient_rows = _safe_int(counts.get('patient'), 0)
        patient_count = _safe_int(
            snap.get('patient_count_effective'),
            _safe_int(snap.get('patient_latest_identity_count'), patient_rows))
        qa_reject_raw = _safe_int(snap.get('qa_reject_count'), 0)
        qa_reject_count = _safe_int(snap.get('qa_reject_count_effective'), qa_reject_raw)
        projection_success_raw = _safe_int(snap.get('projection_success_count'), 0)
        projection_success_count = _safe_int(
            snap.get('projection_success_count_effective'),
            projection_success_raw)
        projection_reject_raw = _safe_int(snap.get('projection_reject_count'), 0)
        projection_reject_count = _safe_int(
            snap.get('projection_reject_count_effective'),
            projection_reject_raw)
        qa_scope = str(snap.get('qa_scope_version', '') or '').strip()
        projection_scope = str(snap.get('projection_scope_version', '') or '').strip()
        lines.append(' - db_status={0}'.format(snap.get('status', 'unknown')))
        if patient_rows != patient_count:
            lines.append(
                ' - patient_count={0} (latest identity rows; raw_patient_rows={1})'.format(
                    patient_count,
                    patient_rows))
        else:
            lines.append(' - patient_count={0}'.format(patient_count))
        if qa_scope:
            lines.append(
                ' - qa_reject_count={0} (qa_version={1}, raw={2})'.format(
                    qa_reject_count,
                    qa_scope,
                    qa_reject_raw))
        else:
            lines.append(' - qa_reject_count={0}'.format(qa_reject_count))
        lines.append(
            ' - replay_pending_count={0} (active backlog only)'.format(
                _safe_int(snap.get('replay_pending_count'), 0)
            )
        )
        if projection_scope:
            lines.append(
                ' - projection_success_count={0} (projection_version={1}, raw={2})'.format(
                    projection_success_count,
                    projection_scope,
                    projection_success_raw))
            lines.append(
                ' - projection_reject_count={0} (projection_version={1}, raw={2})'.format(
                    projection_reject_count,
                    projection_scope,
                    projection_reject_raw))
        else:
            lines.append(' - projection_success_count={0}'.format(projection_success_count))
            lines.append(' - projection_reject_count={0}'.format(projection_reject_count))
        lines.append(' - orphan_claim_lines={0}'.format(_safe_int(snap.get('orphan_claim_lines'), 0)))
    else:
        lines.append(' - db_status=FAIL ({0})'.format(snap.get('error', 'unknown')))
    lines.append('')
    lines.extend(_build_db_enrichment_overview_lines(payload.get('lab_root'), snapshot=snap, compact=False))
    lines.append('')
    lines.append('Table row counts:')
    for key in (
            'patient',
            'coverage',
            'encounter',
            'claim',
            'claim_line',
            'extracted_canonical_record',
            'projection_result',
            'qa_result',
            'replay_queue',
            'ingest_artifact'):
        lines.append(' - {0}={1}'.format(key, _safe_int(counts.get(key), 0)))
    lines.append('')
    lines.append('Patient chain summary (scanned rows):')
    lines.append(' - scanned_rows={0}'.format(_safe_int(summary_all.get('rows'), 0)))
    lines.append(' - risk_high={0}, risk_medium={1}, risk_low={2}'.format(
        _safe_int(summary_all.get('risk_high'), 0),
        _safe_int(summary_all.get('risk_medium'), 0),
        _safe_int(summary_all.get('risk_low'), 0),
    ))
    lines.append(' - missing_any={0}, projection_reject_any={1}'.format(
        _safe_int(summary_all.get('missing_any'), 0),
        _safe_int(summary_all.get('projection_reject_any'), 0),
    ))
    lines.append(' - with_coverage={0}, with_encounter={1}, with_claim={2}, with_claim_line={3}'.format(
        _safe_int(summary_all.get('with_coverage'), 0),
        _safe_int(summary_all.get('with_encounter'), 0),
        _safe_int(summary_all.get('with_claim'), 0),
        _safe_int(summary_all.get('with_claim_line'), 0),
    ))
    lines.append('')
    lines.append('Patient sample summary (rendered rows):')
    lines.append(' - sample_rows={0}'.format(_safe_int(summary_sample.get('rows'), 0)))
    lines.append(' - risk_high={0}, risk_medium={1}, risk_low={2}'.format(
        _safe_int(summary_sample.get('risk_high'), 0),
        _safe_int(summary_sample.get('risk_medium'), 0),
        _safe_int(summary_sample.get('risk_low'), 0),
    ))
    lines.append(' - missing_any={0}, projection_reject_any={1}'.format(
        _safe_int(summary_sample.get('missing_any'), 0),
        _safe_int(summary_sample.get('projection_reject_any'), 0),
    ))
    lines.append('')
    lines.append('Patient sample rows:')
    lines.append('Columns: patient_ref | risk | missing | cov/enc/claim/line | proj_ok/rej | full_name | birth_date | created_at')
    lines.append('Note: created_at is DB row creation timestamp (not date of service).')
    if not rows:
        lines.append(' (no rows selected)')
    else:
        row_idx = 1
        for row in rows:
            display_id = _patient_display_id(row)
            patient_ref = str(row.get('external_patient_id') or row.get('patient_key') or row.get('patient_id') or '-')
            full_name = str(row.get('full_name', '') or '').strip() or '-'
            if len(full_name) > 36:
                full_name = full_name[:33] + '...'
            birth_date = str(row.get('birth_date', '') or '').strip() or '-'
            created_at = str(row.get('created_at', '') or '').strip() or '-'
            risk_label = str(row.get('risk_label', 'UNKNOWN') or 'UNKNOWN')
            missing_count = _safe_int(row.get('missing_count'), 0)
            line = (
                ' {0:>3}) {1} ({2}) | risk={3} | missing={4} | '
                'cov/enc/claim/line={5}/{6}/{7}/{8} | proj_ok/rej={9}/{10} | '
                'name={11} | dob={12} | created={13}'
            ).format(
                row_idx,
                patient_ref,
                display_id,
                risk_label,
                missing_count,
                _safe_int(row.get('coverage_count'), 0),
                _safe_int(row.get('encounter_count'), 0),
                _safe_int(row.get('claim_count'), 0),
                _safe_int(row.get('claim_line_count'), 0),
                _safe_int(row.get('projection_success_count'), 0),
                _safe_int(row.get('projection_reject_count'), 0),
                full_name,
                birth_date,
                created_at,
            )
            lines.append(line)
            reason = str(row.get('reason', '') or '').strip()
            if reason:
                lines.append('       why={0}'.format(reason))
            row_idx += 1

    with open(txt_path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines) + '\n')
    with open(json_path, 'w', encoding='utf-8') as f:
        json.dump(payload, f, indent=2, sort_keys=True)
    try:
        with open(latest_txt, 'w', encoding='utf-8') as f:
            f.write('\n'.join(lines) + '\n')
        with open(latest_json, 'w', encoding='utf-8') as f:
            json.dump(payload, f, indent=2, sort_keys=True)
    except Exception:
        pass
    return txt_path, json_path


def generate_data_plane_audit_report(repo_root, report_type='overview', limit=40):
    """Compatibility wrapper for _patient_tools.generate_data_plane_audit_report."""
    return _patient_tools._IMPL_generate_data_plane_audit_report(repo_root, report_type, limit)



def open_data_plane_audit_report(repo_root, report_type='overview', limit=40):
    """Compatibility wrapper for _patient_tools.open_data_plane_audit_report."""
    return _patient_tools._IMPL_open_data_plane_audit_report(repo_root, report_type, limit)



def open_latest_data_plane_audit_report(repo_root, report_type='overview'):
    """Compatibility wrapper for _patient_tools.open_latest_data_plane_audit_report."""
    return _patient_tools._IMPL_open_latest_data_plane_audit_report(repo_root, report_type)



def get_report_delivery_status_lines(lab_root):
    """
    Build compact delivery-status lines for operator triage.
    Includes sender readiness, queue snapshot, and last auto-report attempts.
    """
    lines = []
    stamp = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
    lines.append('Report Delivery Status')
    lines.append('generated_at_utc={0}'.format(stamp))
    lines.append('lab_root={0}'.format(lab_root or '(unset)'))
    lines.append('')

    delivery = _collect_delivery_diagnostics()
    lines.append('Sender readiness:')
    lines.append(' - token_available={0}'.format(delivery.get('token_available')))
    lines.append(' - recipient_count={0}'.format(delivery.get('recipient_count')))
    lines.append(' - queued_bundle_count={0}'.format(delivery.get('queued_bundle_count', '?')))
    if delivery.get('config_probe_error'):
        lines.append(' - config_probe_error={0}'.format(delivery.get('config_probe_error')))
    if delivery.get('token_probe_error'):
        lines.append(' - token_probe_error={0}'.format(delivery.get('token_probe_error')))
    if delivery.get('queue_probe_error'):
        lines.append(' - queue_probe_error={0}'.format(delivery.get('queue_probe_error')))
    lines.append('')

    lines.append('Queued bundles (up to 5 newest):')
    queued = delivery.get('queued_bundle_paths', [])
    if not isinstance(queued, list):
        queued = []
    try:
        queued = sorted(queued, key=lambda p: os.path.getmtime(p), reverse=True)
    except Exception:
        try:
            queued = sorted(queued, reverse=True)
        except Exception:
            pass
    if queued:
        for path in queued[:5]:
            try:
                age_sec = int(max(0, time.time() - os.path.getmtime(path)))
            except Exception:
                age_sec = None
            if age_sec is None:
                lines.append(' - {0}'.format(path))
            else:
                lines.append(' - {0} (age_sec={1})'.format(path, age_sec))
        if len(queued) > 5:
            lines.append(' - ... {0} more'.format(len(queued) - 5))
    else:
        lines.append(' - none')
    lines.append('')

    now_epoch = int(time.time())

    def _append_alert_state(label, path):
        state = _load_json_dict(path)
        lines.append('{0}:'.format(label))
        if not state:
            lines.append(' - none')
            return None
        for key in (
            'last_attempt_ok',
            'last_error_code',
            'last_trigger',
            'last_issue_key',
            'last_sent_epoch',
            'last_attempt_epoch',
        ):
            if key in state:
                val = state.get(key)
                if key.endswith('_epoch'):
                    utc_val = _format_epoch_utc(val)
                    if utc_val:
                        lines.append(' - {0}={1} ({2})'.format(key, val, utc_val))
                        continue
                lines.append(' - {0}={1}'.format(key, val))
        age_sec = _alert_state_age_sec(state, now_epoch=now_epoch)
        freshness = _alert_state_freshness(state, now_epoch=now_epoch)
        if age_sec is not None:
            lines.append(' - state_age_sec={0}'.format(age_sec))
        lines.append(' - state_freshness={0}'.format(freshness))
        if freshness == 'stale':
            lines.append(
                ' - state_note=historical context only; excluded from current delivery remediation actions.'
            )
        diag = state.get('last_delivery_diag', {})
        if isinstance(diag, dict):
            if 'token_available' in diag:
                lines.append(' - delivery.token_available={0}'.format(diag.get('token_available')))
            if 'recipient_count' in diag:
                lines.append(' - delivery.recipient_count={0}'.format(diag.get('recipient_count')))
            if 'queued_bundle_count' in diag:
                lines.append(' - delivery.queued_bundle_count={0}'.format(diag.get('queued_bundle_count')))
        return {
            'state': state,
            'age_sec': age_sec,
            'freshness': freshness,
        }

    _append_alert_state('Cloud health auto-report', os.path.join(lab_root or '.', _HEALTH_ALERT_STATE_FILENAME))
    lines.append('')
    orch_path = os.path.join(lab_root or '.', _ORCHESTRATOR_ALERT_STATE_FILENAME)
    orch_info = _append_alert_state('Orchestrator auto-report', orch_path) or {}
    orch_state = orch_info.get('state')
    orch_freshness = orch_info.get('freshness')
    orch_is_stale = orch_freshness == 'stale'
    if isinstance(orch_state, dict) and orch_state.get('last_error_code'):
        if orch_is_stale:
            lines.append(
                ' - interpret_last_attempt_ok=Historical failure-report record only; current delivery remediation uses sender readiness unless a newer orchestrator failure is recorded.'
            )
        else:
            lines.append(
                ' - interpret_last_attempt_ok=Failure-report email delivery only (orchestration already failed).'
            )
        lines.append(
            ' - last_bundle_send_ok={0}'.format(orch_state.get('last_bundle_send_ok', orch_state.get('last_attempt_ok')))
        )
        lines.append(' - delivery_runbook_uses_orchestrator_error={0}'.format(not orch_is_stale))
    lines.append('')
    orch_ec = orch_state.get('last_error_code') if isinstance(orch_state, dict) and not orch_is_stale else None
    lines.append('Remediation Playbook:')
    for line in _build_delivery_runbook_lines(delivery, orchestrator_error_code=orch_ec):
        lines.append(line)
    return lines


def _format_delivery_failure_message(delivery_diag):
    reason = 'email submission failed'
    recipient_count = delivery_diag.get('recipient_count')
    token_available = delivery_diag.get('token_available')
    if isinstance(recipient_count, int) and recipient_count <= 0:
        reason = 'no valid recipients configured'
    elif token_available is False:
        reason = 'gmail token unavailable'
    msg = 'Report queued or failed ({0}).'.format(reason)
    queued_count = delivery_diag.get('queued_bundle_count')
    if isinstance(queued_count, int):
        msg += ' queued_bundle_count={0}.'.format(queued_count)
    return msg


def _submit_bundle_with_delivery_diagnostics(zip_path, allow_interactive_reauth, progress_callback=None):
    """Send bundle and return (ok, msg, delivery_diag)."""
    if submit_support_bundle_email is None:
        return (False, 'Support bundle tools unavailable.', {})
    _emit_progress(progress_callback, 'checking delivery diagnostics')
    delivery_diag = _collect_delivery_diagnostics()
    delivery_diag['allow_interactive_reauth'] = bool(allow_interactive_reauth)
    try:
        _emit_progress(progress_callback, 'sending email to support')
        ok = submit_support_bundle_email(
            zip_path=zip_path,
            include_traceback=False,
            skip_interactive_reauth=not allow_interactive_reauth,
            progress_callback=progress_callback,
        )
    except Exception as e:
        ok = False
        delivery_diag['send_exception'] = str(e)
    if ok:
        # Empty msg: callers print kind-specific success (avoid duplicate generic line).
        return (True, '', delivery_diag)
    refreshed_diag = _collect_delivery_diagnostics()
    for key, value in refreshed_diag.items():
        delivery_diag[key] = value
    return (False, _format_delivery_failure_message(delivery_diag), delivery_diag)


def _orchestrator_failure_report_dedup_key(error_code, message):
    """Build a stable dedup key so repeated retries of the same failure do not spam auto-reports.

    Bootstrap diagnostics use a unique JSON path per attempt and embed it in the operator
    message; free-text tails can also differ (timeouts, OS errors). The windowed dedup key is
    therefore **error_code only** so all retries of the same classified failure coalesce.
    The ``message`` parameter is kept for API compatibility with older call sites.
    """
    _ = message
    return str(error_code or '').strip() or 'UNKNOWN_ORCHESTRATOR_FAILURE'


def _maybe_send_orchestrator_failure_report(repo_root, lab_root, orchestration_result, trigger):
    """Best-effort auto-report for typed orchestrator failures (non-interactive)."""
    if collect_support_bundle is None or submit_support_bundle_email is None:
        return False
    if not isinstance(orchestration_result, dict):
        return False
    if orchestration_result.get('status') != shadow_orchestrator.STATUS_FAILED:
        return False

    error_code = str(orchestration_result.get('error_code', '') or '').strip() or 'UNKNOWN_ORCHESTRATOR_FAILURE'
    message = str(orchestration_result.get('message', '') or '').strip()
    payload = orchestration_result.get('payload', {}) if isinstance(orchestration_result.get('payload', {}), dict) else {}
    diagnostic_path = str(orchestration_result.get('diagnostic_path', '') or '').strip()
    report_path = str(orchestration_result.get('report_path', '') or '').strip()

    alert_root = lab_root if lab_root and str(lab_root).strip() else os.path.join(repo_root or os.getcwd(), 'lab')
    alert_state_path = os.path.join(alert_root, _ORCHESTRATOR_ALERT_STATE_FILENAME)
    issue_key = _orchestrator_failure_report_dedup_key(error_code, message)

    held_lock = False
    if try_acquire_report_dedup_lock is not None:
        held_lock = bool(try_acquire_report_dedup_lock(alert_state_path, timeout_sec=45, sleep_sec=0.05))
        if not held_lock:
            _log_health('WARNING', 'Orchestrator auto-report: dedup lock timeout; skipping send.')
            return False

    try:
        now_epoch = int(time.time())
        try:
            alert_state = _load_json_dict(alert_state_path)
            last_key = str(alert_state.get('last_issue_key', '') or '')
            last_epoch = int(alert_state.get('last_attempt_epoch', 0) or 0)
            if last_key == issue_key and (now_epoch - last_epoch) < _ORCHESTRATOR_ALERT_DEDUP_WINDOW_SEC:
                return False
        except Exception:
            pass

        extra_files = [('orchestrator_result.json', orchestration_result)]
        if payload:
            extra_files.append(('orchestrator_payload.json', payload))
        for candidate in (diagnostic_path, report_path):
            if candidate and os.path.isfile(candidate):
                extra_files.append((os.path.basename(candidate), candidate))
        for ctx_name in ('diagnostics_state.json', 'run_cursor.json', _HEALTH_TRACKER_FILENAME):
            ctx_path = os.path.join(alert_root, ctx_name)
            if os.path.isfile(ctx_path):
                extra_files.append((ctx_name, ctx_path))

        extra_meta = {
            'orchestrator_failure_auto_report': True,
            'orchestrator_trigger': trigger,
            'error_code': error_code,
            'error_summary': message or error_code,
            'repo_root': repo_root,
            'lab_root': alert_root,
        }
        zip_path = collect_support_bundle(
            include_traceback=False,
            extra_meta=extra_meta,
            extra_files=extra_files,
        )
        if not zip_path:
            return False
        ok, msg, delivery_diag = _submit_bundle_with_delivery_diagnostics(
            zip_path=zip_path,
            allow_interactive_reauth=False,
        )
        state_payload = {
            'last_issue_key': issue_key,
            'last_attempt_epoch': now_epoch,
            'last_attempt_ok': bool(ok),
            'last_bundle_send_ok': bool(ok),
            'last_error_code': error_code,
            'last_trigger': trigger,
        }
        if isinstance(delivery_diag, dict):
            state_payload['last_delivery_diag'] = delivery_diag
        save_ok = _save_json_dict(alert_state_path, state_payload)
        if not save_ok:
            _log_health(
                'WARNING',
                'Orchestrator auto-report: could not persist alert state (dedup may fail on next retry): {0}'.format(
                    alert_state_path,
                ),
            )
        if not ok:
            _log_health('WARNING', 'Auto-report failed for {0}: {1}'.format(error_code, msg))
        return ok
    except Exception as e:
        _log_health('ERROR', 'Auto-report exception for {0}: {1}'.format(error_code, e))
        return False
    finally:
        if held_lock and release_report_dedup_lock is not None:
            release_report_dedup_lock(alert_state_path)


def _collect_health_diagnostics(lab_root, auto_resolve=True):
    """Compatibility wrapper for _health_tools._collect_health_diagnostics."""
    return _health_tools._IMPL__collect_health_diagnostics(lab_root, auto_resolve)



def _update_health_issue_tracker(lab_root, diagnostics, now_epoch=None):
    """Track intermittent/repeated issues across checks and identify escalation candidates."""
    now_epoch = int(now_epoch or time.time())
    # TODO(agent-followup): Consider a bounded "recent history" ring-buffer per issue code
    # so we can include cadence details (e.g., bursty vs steady failures) in support bundles
    # without growing this tracker file indefinitely over long-lived installations.
    tracker_path = os.path.join(lab_root or '.', _HEALTH_TRACKER_FILENAME)
    tracker = _load_json_dict(tracker_path)
    issues = tracker.get('issues', {}) if isinstance(tracker.get('issues', {}), dict) else {}
    current_keys = []
    escalated_codes = []

    for issue in diagnostics.get('issues', []):
        code = str(issue.get('code', '') or '').strip()
        severity = str(issue.get('severity', 'warn') or 'warn').strip().lower()
        if not code:
            continue
        current_keys.append(code)
        rec = issues.get(code, {}) if isinstance(issues.get(code, {}), dict) else {}
        count = int(rec.get('count', 0) or 0) + 1
        first_seen = int(rec.get('first_seen_epoch', now_epoch) or now_epoch)
        rec.update({
            'severity': severity,
            'count': count,
            'first_seen_epoch': first_seen,
            'last_seen_epoch': now_epoch,
            'message': issue.get('message', ''),
        })
        issues[code] = rec
        age = now_epoch - first_seen
        if severity == 'fail':
            escalated_codes.append(code)
        elif (severity == 'warn' and code not in _WARN_NON_ESCALATING_CODES
              and count >= _WARN_ESCALATION_MIN_COUNT and age >= _WARN_ESCALATION_MIN_AGE_SEC):
            escalated_codes.append(code)

    resolved = []
    for code in list(issues.keys()):
        if code not in current_keys:
            rec = issues.get(code, {})
            if isinstance(rec, dict):
                resolved.append(code)
            issues.pop(code, None)

    tracker['issues'] = issues
    tracker['last_updated_epoch'] = now_epoch
    _save_json_dict(tracker_path, tracker)
    return {
        'tracker_path': tracker_path,
        'escalated_codes': sorted(set(escalated_codes)),
        'resolved_codes': sorted(set(resolved)),
    }


def _maybe_send_cloud_health_failure_report(lab_root, diagnostics, tracker_info):
    """Send deduplicated support bundle for fail or sustained warn diagnostics."""
    if collect_support_bundle is None or submit_support_bundle_email is None:
        return False
    # TODO(agent-followup): If lab_root is empty/invalid, skip persistence and surface an
    # explicit diagnostic for this pathing condition instead of falling back to cwd ('.').
    # That hardening would prevent accidental artifact writes outside expected lab scope.
    escalated_codes = tracker_info.get('escalated_codes', []) if isinstance(tracker_info, dict) else []
    if not escalated_codes:
        return False
    issues = diagnostics.get('issues', []) if isinstance(diagnostics, dict) else []
    issue_key = '|'.join(['{0}:{1}'.format(i.get('code', ''), i.get('message', '')) for i in issues if i.get('code') in escalated_codes])
    if not issue_key:
        return False

    alert_state_path = os.path.join(lab_root or '.', _HEALTH_ALERT_STATE_FILENAME)
    now_epoch = int(time.time())
    alert_state = _load_json_dict(alert_state_path)
    last_key = alert_state.get('last_issue_key')
    last_epoch = int(alert_state.get('last_sent_epoch', 0) or 0)
    if last_key == issue_key and (now_epoch - last_epoch) < _ALERT_DEDUP_WINDOW_SEC:
        return False

    try:
        delivery_preflight = _collect_delivery_diagnostics()
        extra_files = [('cloud_health_diagnostics.json', diagnostics)]
        for name in (_HEALTH_TRACKER_FILENAME, 'diagnostics_state.json', 'run_cursor.json'):
            p = os.path.join(lab_root, name)
            if os.path.isfile(p):
                extra_files.append((name, p))
        zip_path = collect_support_bundle(
            include_traceback=False,
            extra_meta={
                'cloud_health_failure': True,
                'escalated_codes': escalated_codes,
                'lab_root': lab_root,
                'email_delivery_preflight': delivery_preflight,
            },
            extra_files=extra_files,
        )
        if not zip_path:
            return False
        ok, msg, _ = _submit_bundle_with_delivery_diagnostics(
            zip_path=zip_path,
            allow_interactive_reauth=False,
        )
        if not ok:
            _log_health('WARNING', 'Cloud health report submission fallback: {0}'.format(msg))
            return False
        _save_json_dict(alert_state_path, {'last_issue_key': issue_key, 'last_sent_epoch': now_epoch})
        return True
    except Exception as e:
        _log_health('ERROR', 'Cloud health report send failed: {0}'.format(e))
        return False


def resolve_lab_root(repo_root):
    """Compatibility wrapper for _health_tools.resolve_lab_root."""
    return _health_tools._IMPL_resolve_lab_root(repo_root)



def _describe_lab_root_issue(lab_root):
    """Return a richer LAB_ROOT_NOT_FOUND explanation to speed operator triage."""
    parts = ['Lab root does not exist: {0}'.format(lab_root)]
    env_raw = os.environ.get('MEDICAFE_LAB_DIR', '')
    if env_raw:
        parts.append('MEDICAFE_LAB_DIR(raw)={0!r}'.format(env_raw))
    try:
        normalized = os.path.abspath(os.path.expandvars(os.path.expanduser(str(lab_root))))
        if normalized != lab_root:
            parts.append('normalized={0}'.format(normalized))
    except Exception:
        pass
    try:
        parent = os.path.dirname(lab_root)
        if parent:
            parts.append('parent_exists={0}'.format(os.path.isdir(parent)))
            parts.append('parent_writable={0}'.format(os.access(parent, os.W_OK)))
    except Exception:
        pass
    return ' | '.join(parts)


def _lab_has_core_artifacts(lab_root):
    """True if lab has db and cursor (bootstrap completed successfully)."""
    if not lab_root:
        return False
    db = os.path.join(lab_root, 'unified_model_xp.db')
    cursor = os.path.join(lab_root, 'run_cursor.json')
    return os.path.isfile(db) and os.path.isfile(cursor)


def _write_bootstrap_diag(repo_root, lab_root, reason, extra=None):
    """Best-effort write of opportunistic bootstrap diagnostics for in-situ triage."""
    try:
        fallback_lab = os.path.join(repo_root, 'lab')
        base_lab = lab_root if lab_root and str(lab_root).strip() else fallback_lab
        reports_dir = os.path.join(base_lab, 'reports')
        if not os.path.isdir(reports_dir):
            os.makedirs(reports_dir)
        stamp = time.strftime('%Y%m%dT%H%M%SZ', time.gmtime())
        unique = '{0}-{1}-{2}'.format(stamp, os.getpid(), int((time.time() % 1) * 1000))
        path = os.path.join(reports_dir, 'bootstrap_autofix_diag_{0}.json'.format(unique))
        payload = {
            'reason': reason,
            'lab_root': lab_root,
            'repo_root': repo_root,
            'medicafe_lab_dir_raw': os.environ.get('MEDICAFE_LAB_DIR', ''),
            'timestamp_utc': stamp,
        }
        if isinstance(extra, dict):
            payload.update(extra)
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return path
    except Exception:
        return None


def _probe_lab_root(path):
    """Collect lightweight filesystem/pipeline facts for bootstrap diagnostics."""
    probe = {
        'path': path,
        'exists': False,
        'is_dir': False,
        'parent': None,
        'parent_exists': False,
        'parent_writable': False,
        'has_core_artifacts': False,
        'pipeline_running': False,
    }
    try:
        if not path:
            return probe
        probe['exists'] = os.path.exists(path)
        probe['is_dir'] = os.path.isdir(path)
        parent = os.path.dirname(path)
        probe['parent'] = parent
        if parent:
            probe['parent_exists'] = os.path.isdir(parent)
            probe['parent_writable'] = os.access(parent, os.W_OK)
        if probe['is_dir']:
            probe['has_core_artifacts'] = _lab_has_core_artifacts(path)
        probe['pipeline_running'] = is_pipeline_running(path)
    except Exception:
        pass
    return probe


def _bootstrap_fail_message(code, message, diag_path=None):
    """Standardized bootstrap failure message with code and optional diag path."""
    msg = '{0}: {1}'.format(code, message)
    if diag_path:
        msg = '{0} (diagnostics: {1})'.format(msg, diag_path)
    return msg


def _bootstrap_creationflags():
    """Windows-only process-group mitigation for bootstrap child."""
    if os.name == 'nt':
        return getattr(subprocess, 'CREATE_NEW_PROCESS_GROUP', 0)
    return 0


def _orchestrator_ops():
    return {
        "resolve_lab_root": resolve_lab_root,
        "lab_has_core_artifacts": _lab_has_core_artifacts,
        "write_bootstrap_diag": _write_bootstrap_diag,
        "bootstrap_fail_message": _bootstrap_fail_message,
        "devnull": DEVNULL,
    }


def _coerce_orchestrator_result_to_legacy(result, default_running_message='Initialization in progress.'):
    status = (result or {}).get("status", "")
    code = (result or {}).get("error_code", "")
    msg = (result or {}).get("message", "") or ""
    payload = result or {}
    if status == shadow_orchestrator.STATUS_FAILED:
        return (False, msg or code or "Coordinator failed.", payload)
    if status == shadow_orchestrator.STATUS_ALREADY_RUNNING:
        return (True, default_running_message, payload)
    if code == shadow_orchestrator.ERROR_READY_NOOP:
        return (True, "", payload)
    return (True, msg, payload)


def _lab_root_has_recent_successful_shadow_pipeline_within_cooldown(lab_root, env):
    """True if diagnostics_state shows a completed successful pipeline within startup autorun cooldown."""
    state = _load_json_dict(os.path.join(lab_root or '', 'diagnostics_state.json'))
    if state.get('last_shadow_pipeline_ok') is not True:
        return False
    run_id = str(state.get('last_shadow_pipeline_run_id', '') or '').strip()
    if not run_id:
        return False
    cooldown = shadow_orchestrator._startup_autorun_cooldown_seconds(env or {})
    if cooldown <= 0:
        return False
    finished_at = state.get('last_shadow_pipeline_finished_at_utc', '')
    finished_epoch = shadow_orchestrator._parse_iso_utc_to_epoch(finished_at)
    if finished_epoch is None:
        return False
    age = int(time.time() - finished_epoch)
    if age < 0:
        return False
    return age < cooldown


def _lab_has_shadow_phase_f_artifacts_for_run_id(lab_root, run_id):
    """True if Phase F report and evidence index JSON exist for run_id under lab/reports."""
    rid = str(run_id or '').strip()
    if not rid:
        return False
    try:
        reports = os.path.join(lab_root or '', 'reports')
        report_json = os.path.join(reports, 'shadow_run_report_{0}.json'.format(rid))
        index_json = os.path.join(reports, 'shadow_evidence_index_{0}.json'.format(rid))
        return os.path.isfile(report_json) and os.path.isfile(index_json)
    except Exception:
        return False


def _should_skip_followup_full_pipeline_after_baseline(lab_root, env, allow_skip):
    """
    Cloud Readiness entry only: skip automatic MANUAL_FULL_PIPELINE after Phase A when
    diagnostics show a recent successful run and on-disk Phase F artifacts match that run_id.
    """
    if not allow_skip:
        return False
    if not _lab_root_has_recent_successful_shadow_pipeline_within_cooldown(lab_root, env):
        return False
    state = _load_json_dict(os.path.join(lab_root or '', 'diagnostics_state.json'))
    run_id = str(state.get('last_shadow_pipeline_run_id', '') or '').strip()
    return _lab_has_shadow_phase_f_artifacts_for_run_id(lab_root, run_id)


def ensure_lab_ready(repo_root, python_exe, env, env_flag_fn, skip_recent_success_autopipeline=False):
    """Compatibility wrapper for _health_tools.ensure_lab_ready."""
    return _health_tools._IMPL_ensure_lab_ready(repo_root, python_exe, env, env_flag_fn, skip_recent_success_autopipeline)



def is_pipeline_running(lab_root):
    """Check if shadow pipeline is running. Returns bool. Exception-safe."""
    try:
        return _health_tools._IMPL_is_pipeline_running(lab_root)
    except Exception:
        return False


def check_pipeline_running_for_action(repo_root, action_name):
    """Returns (is_running, warning_msg). warning_msg set when is_running."""
    lab_root = resolve_lab_root(repo_root)
    running = is_pipeline_running(lab_root)
    msg = 'Note: Pipeline is running. {0} may reflect stale data.'.format(action_name) if running else None
    return (running, msg)


def _default_env_flag(_name, default=False):
    return default


_OPERATOR_DEFERRED_SEND_FILENAME = 'operator_deferred_support_send.json'
_OPERATOR_DEFERRED_DAT_SMOKE_FILENAME = 'operator_deferred_phase_d_dat_smoke.json'
_PHASE_D_DAT_SMOKE_STATE_FILENAME = 'phase_d_dat_smoke_state.json'
_PHASE_D_DAT_SMOKE_DEFAULT_COOLDOWN_SEC = 30 * 60


def _normalize_phase_d_reprocess_classes(raw):
    if _normalize_phase_d_reprocess_classes_impl is not None:
        try:
            return _normalize_phase_d_reprocess_classes_impl(raw)
        except Exception:
            pass
    classes = []
    seen = set()
    if raw is None:
        raw_parts = []
    elif isinstance(raw, str):
        raw_parts = raw.split(',')
    else:
        try:
            raw_parts = list(raw)
        except Exception:
            raw_parts = [raw]
    for value in raw_parts:
        key = str(value or '').strip().lower()
        if not key or key in seen or key not in ('csv', 'dat', 'docx'):
            continue
        seen.add(key)
        classes.append(key)
    return classes


def operator_deferred_support_send_path(repo_root):
    """Path for one-shot deferred recommendation intent (under lab reports/)."""
    lab_root = resolve_lab_root(repo_root)
    return os.path.join(lab_root, 'reports', _OPERATOR_DEFERRED_SEND_FILENAME)


def _normalize_operator_deferred_support_send(data):
    payload = data if isinstance(data, dict) else {}
    primary_send = str(payload.get('primary_send', '') or '').strip()
    if primary_send not in ('run_evidence', 'system_health'):
        primary_send = 'system_health'
    action_kind = str(payload.get('action_kind', '') or 'send_bundle').strip()
    if action_kind not in ('send_bundle', 'historical_phase_d_reprocess', 'phase_d_dat_smoke', 'review_dat_qa_full_block'):
        action_kind = 'send_bundle'
    report_kind = str(payload.get('recommended_report_kind', '') or '').strip()
    if report_kind not in ('artifact_triage_pack', 'system_health_pack'):
        report_kind = ''
    return {
        'primary_send': primary_send,
        'action_kind': action_kind,
        'recommended_report_kind': report_kind,
        'artifact_classes': _normalize_phase_d_reprocess_classes(payload.get('artifact_classes', [])),
        'reason': str(payload.get('reason', '') or '')[:500],
        'created_at_utc': str(payload.get('created_at_utc', '') or ''),
    }


def write_operator_deferred_support_send(repo_root, primary_send, reason='', action_kind='send_bundle', artifact_classes=None, recommended_report_kind=''):
    """
    Persist a deferred recommended action. The launcher recomputes the current
    recommendation after the lab settles before executing anything.
    """
    path = operator_deferred_support_send_path(repo_root)
    try:
        parent = os.path.dirname(path)
        if parent and not os.path.isdir(parent):
            os.makedirs(parent)
        payload = _normalize_operator_deferred_support_send({
            'primary_send': primary_send,
            'action_kind': action_kind,
            'artifact_classes': artifact_classes,
            'recommended_report_kind': recommended_report_kind,
            'reason': reason,
            'created_at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        })
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return True
    except Exception:
        return False


def read_operator_deferred_support_send(repo_root):
    try:
        path = operator_deferred_support_send_path(repo_root)
        if not os.path.isfile(path):
            return None
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        if not isinstance(data, dict):
            return None
        return _normalize_operator_deferred_support_send(data)
    except Exception:
        return None


def clear_operator_deferred_support_send(repo_root):
    try:
        path = operator_deferred_support_send_path(repo_root)
        if os.path.isfile(path):
            os.remove(path)
        return True
    except Exception:
        return False


def phase_d_dat_smoke_state_path(repo_root):
    lab_root = resolve_lab_root(repo_root)
    return os.path.join(lab_root, _PHASE_D_DAT_SMOKE_STATE_FILENAME)


def _normalize_phase_d_dat_smoke_state(data):
    payload = data if isinstance(data, dict) else {}
    out = {
        'last_requested_anchor_run_id': str(payload.get('last_requested_anchor_run_id', '') or '').strip(),
        'last_requested_context_run_id': str(payload.get('last_requested_context_run_id', '') or '').strip(),
        'last_remediation_issue_code': str(payload.get('last_remediation_issue_code', '') or '').strip(),
        'last_started_at_utc': str(payload.get('last_started_at_utc', '') or '').strip(),
        'last_finished_at_utc': str(payload.get('last_finished_at_utc', '') or '').strip(),
        'last_status': str(payload.get('last_status', '') or '').strip(),
        'last_report_path': str(payload.get('last_report_path', '') or '').strip(),
        'last_assessment': str(payload.get('last_assessment', '') or '').strip(),
        'cooldown_until_utc': str(payload.get('cooldown_until_utc', '') or '').strip(),
    }
    return out


def read_phase_d_dat_smoke_state(repo_root):
    try:
        path = phase_d_dat_smoke_state_path(repo_root)
        if not os.path.isfile(path):
            return _normalize_phase_d_dat_smoke_state({})
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return _normalize_phase_d_dat_smoke_state(data)
    except Exception:
        return _normalize_phase_d_dat_smoke_state({})


def write_phase_d_dat_smoke_state(repo_root, data):
    path = phase_d_dat_smoke_state_path(repo_root)
    try:
        parent = os.path.dirname(path)
        if parent and not os.path.isdir(parent):
            os.makedirs(parent)
        payload = _normalize_phase_d_dat_smoke_state(data)
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return True
    except Exception:
        return False


def update_phase_d_dat_smoke_state(
        repo_root,
        anchor_run_id='',
        context_run_id='',
        issue_code='',
        started_at_utc='',
        finished_at_utc='',
        status='',
        report_path='',
        assessment='',
        cooldown_until_utc=''):
    """
    Merge-update phase_d_dat_smoke_state.json keys. Empty arguments keep current values.
    """
    state = read_phase_d_dat_smoke_state(repo_root)
    if anchor_run_id is not None and str(anchor_run_id or '').strip():
        state['last_requested_anchor_run_id'] = str(anchor_run_id or '').strip()
    if context_run_id is not None and str(context_run_id or '').strip():
        state['last_requested_context_run_id'] = str(context_run_id or '').strip()
    if issue_code is not None and str(issue_code or '').strip():
        state['last_remediation_issue_code'] = str(issue_code or '').strip()
    if started_at_utc is not None and str(started_at_utc or '').strip():
        state['last_started_at_utc'] = str(started_at_utc or '').strip()
    if finished_at_utc is not None and str(finished_at_utc or '').strip():
        state['last_finished_at_utc'] = str(finished_at_utc or '').strip()
    if status is not None and str(status or '').strip():
        state['last_status'] = str(status or '').strip()
    if report_path is not None and str(report_path or '').strip():
        state['last_report_path'] = str(report_path or '').strip()
    if assessment is not None and str(assessment or '').strip():
        state['last_assessment'] = str(assessment or '').strip()
    if cooldown_until_utc is not None and str(cooldown_until_utc or '').strip():
        state['cooldown_until_utc'] = str(cooldown_until_utc or '').strip()
    return write_phase_d_dat_smoke_state(repo_root, state)


def operator_deferred_phase_d_dat_smoke_path(repo_root):
    lab_root = resolve_lab_root(repo_root)
    return os.path.join(lab_root, 'reports', _OPERATOR_DEFERRED_DAT_SMOKE_FILENAME)


def _normalize_operator_deferred_phase_d_dat_smoke(data):
    payload = data if isinstance(data, dict) else {}
    return {
        'anchor_run_id': str(payload.get('anchor_run_id', '') or '').strip(),
        'context_run_id': str(payload.get('context_run_id', '') or '').strip(),
        'issue_code': str(payload.get('issue_code', '') or '').strip(),
        'reference_phase_d_summary_path': str(payload.get('reference_phase_d_summary_path', '') or '').strip(),
        'reason': str(payload.get('reason', '') or '')[:500],
        'created_at_utc': str(payload.get('created_at_utc', '') or '').strip(),
    }


def write_operator_deferred_phase_d_dat_smoke(
        repo_root,
        anchor_run_id,
        context_run_id,
        issue_code='',
        reference_phase_d_summary_path='',
        reason=''):
    path = operator_deferred_phase_d_dat_smoke_path(repo_root)
    try:
        parent = os.path.dirname(path)
        if parent and not os.path.isdir(parent):
            os.makedirs(parent)
        payload = _normalize_operator_deferred_phase_d_dat_smoke({
            'anchor_run_id': anchor_run_id,
            'context_run_id': context_run_id,
            'issue_code': issue_code,
            'reference_phase_d_summary_path': reference_phase_d_summary_path,
            'reason': reason,
            'created_at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        })
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return True
    except Exception:
        return False


def read_operator_deferred_phase_d_dat_smoke(repo_root):
    try:
        path = operator_deferred_phase_d_dat_smoke_path(repo_root)
        if not os.path.isfile(path):
            return None
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        if not isinstance(data, dict):
            return None
        return _normalize_operator_deferred_phase_d_dat_smoke(data)
    except Exception:
        return None


def clear_operator_deferred_phase_d_dat_smoke(repo_root):
    try:
        path = operator_deferred_phase_d_dat_smoke_path(repo_root)
        if os.path.isfile(path):
            os.remove(path)
        return True
    except Exception:
        return False


def _phase_d_dat_smoke_target_tuple(anchor_run_id, context_run_id, issue_code):
    return (
        str(anchor_run_id or '').strip(),
        str(context_run_id or '').strip(),
        str(issue_code or '').strip(),
    )


def _phase_d_dat_smoke_state_suppressed(state, anchor_run_id, context_run_id, issue_code):
    st = state if isinstance(state, dict) else {}
    target = _phase_d_dat_smoke_target_tuple(anchor_run_id, context_run_id, issue_code)
    last = _phase_d_dat_smoke_target_tuple(
        st.get('last_requested_anchor_run_id', ''),
        st.get('last_requested_context_run_id', ''),
        st.get('last_remediation_issue_code', ''),
    )
    if not target[0] or not target[1]:
        return False
    if target != last:
        return False
    status = str(st.get('last_status', '') or '').strip().lower()
    if status in ('running', 'started'):
        return True
    cooldown_until = str(st.get('cooldown_until_utc', '') or '').strip()
    if cooldown_until:
        try:
            until_epoch = _parse_iso_utc_epoch(cooldown_until)
            if until_epoch and until_epoch > time.time():
                return True
        except Exception:
            pass
    return False


def _phase_d_dat_smoke_reference_summary_for_anchor(repo_root, anchor_run_id):
    """Resolve anchored main-lab Phase D summary JSON; no latest-by-prefix fallback."""
    anchor = str(anchor_run_id or '').strip()
    if not anchor:
        return ''
    lab_root = resolve_lab_root(repo_root)
    path = os.path.join(lab_root, 'reports', 'qa_canonical_summary_{0}.json'.format(anchor))
    if os.path.isfile(path):
        return path
    return ''


def _phase_d_dat_smoke_context_run_id(phase_d_payload, anchor_run_id):
    phase_d_payload = phase_d_payload if isinstance(phase_d_payload, dict) else {}
    rid = str(phase_d_payload.get('run_id', '') or '').strip()
    if rid:
        return rid
    return str(anchor_run_id or '').strip()

def _preferred_when_stable_from_snapshot(ok_snap, snap, snap_msg, nearest_complete, artifact_why_lines):
    """Compatibility wrapper for _recommendation_tools._preferred_when_stable_from_snapshot."""
    return _recommendation_tools._IMPL__preferred_when_stable_from_snapshot(ok_snap, snap, snap_msg, nearest_complete, artifact_why_lines)



def _snapshot_phase_json_path(snapshot, phase_code, prefix=''):
    rows = snapshot.get('phase_rows', []) if isinstance(snapshot.get('phase_rows', []), list) else []
    for row in rows:
        if str(row.get('code', '') or '').strip().upper() != str(phase_code or '').strip().upper():
            continue
        files = row.get('files', []) if isinstance(row.get('files', []), list) else []
        for path in files:
            base = os.path.basename(str(path or ''))
            if prefix and not base.startswith(prefix):
                continue
            if base.lower().endswith('.json'):
                return path
    return ''



def _load_phase_summary_from_snapshot(snapshot, phase_code, prefix=''):
    path = _snapshot_phase_json_path(snapshot, phase_code, prefix=prefix)
    return (_load_json_dict(path), path)



def _int_or_zero(value):
    try:
        return int(value or 0)
    except Exception:
        return 0



def _relax_snapshot_diagnostics_for_anchor_evaluation(snapshot, anchor_run_id):
    """
    Shallow-adjust diagnostics_state so coherence checks evaluate the anchored run_id against
    a synthetic last-completed handoff, ignoring live lab drift (failed newer attempt, etc.).

    Also clears snapshot lineage_issues for this evaluation-only view. Zero-selection Phase D
    summaries often record a different phase_c_summary_run_id_used_for_zero_selection than the
    shadow phase_run_ids.C line — that is expected for historical-backlog / duplicate-dominant
    runs but would otherwise keep artifact_snapshot_coherence_blocked true and suppress
    historical_phase_d_reprocess in favor of send_bundle.
    """
    if not isinstance(snapshot, dict):
        return snapshot
    anchor_run_id = str(anchor_run_id or '').strip()
    rid = str(snapshot.get('run_id', '') or '').strip()
    if not anchor_run_id or rid != anchor_run_id:
        return snapshot
    out = dict(snapshot)
    ds = snapshot.get('diagnostics_state')
    ds = dict(ds) if isinstance(ds, dict) else {}
    ds['last_shadow_pipeline_run_id'] = anchor_run_id
    ds['active_run_id'] = ''
    ps = str(ds.get('pipeline_state', '') or '').strip().lower()
    if ps in ('failed', 'running', 'bootstrapping'):
        ds['pipeline_state'] = 'completed'
    out['diagnostics_state'] = ds
    out['lineage_issues'] = []
    return out


def _derive_live_run_id_for_recommendation(state, latest_snapshot):
    """Prefer diagnostics active/last pipeline run id; fall back to latest artifact snapshot run_id."""
    state = state if isinstance(state, dict) else {}
    latest = latest_snapshot if isinstance(latest_snapshot, dict) else {}
    active = str(state.get('active_run_id', '') or '').strip()
    if active:
        return active
    last = str(state.get('last_shadow_pipeline_run_id', '') or '').strip()
    if last:
        return last
    return str(latest.get('run_id', '') or '').strip()


def _derive_live_pipeline_status(state, pipeline_running):
    """Map diagnostics state to recommendation_live_run_status."""
    state = state if isinstance(state, dict) else {}
    if pipeline_running:
        return 'running'
    ps = str(state.get('pipeline_state', '') or '').strip().lower()
    if ps in ('bootstrapping', 'running'):
        return 'running'
    ok = state.get('last_shadow_pipeline_ok')
    if ok is True:
        return 'completed'
    if ok is False:
        return 'failed'
    return 'pending'


def _select_evaluation_snapshot_for_recommendation(repo_root, pack_context):
    """Compatibility wrapper for _recommendation_tools._select_evaluation_snapshot_for_recommendation."""
    return _recommendation_tools._IMPL__select_evaluation_snapshot_for_recommendation(repo_root, pack_context)



def _build_historical_phase_d_reprocess_recommendation(repo_root, snapshot, bundle_quality, pipeline_running):
    """Compatibility wrapper for _recommendation_tools._build_historical_phase_d_reprocess_recommendation."""
    return _recommendation_tools._IMPL__build_historical_phase_d_reprocess_recommendation(repo_root, snapshot, bundle_quality, pipeline_running)



def _build_phase_d_dat_smoke_recommendation(repo_root, snapshot, pipeline_running):
    """Compatibility wrapper for _recommendation_tools._build_phase_d_dat_smoke_recommendation."""
    return _recommendation_tools._IMPL__build_phase_d_dat_smoke_recommendation(repo_root, snapshot, pipeline_running)



def _adjacent_json_path_for_text_report(path):
    text_path = str(path or '').strip()
    if not text_path:
        return ''
    root, ext = os.path.splitext(text_path)
    if ext.lower() != '.txt':
        return ''
    candidate = root + '.json'
    if os.path.isfile(candidate):
        return candidate
    return ''


def _dat_smoke_report_payload_from_state(smoke_state):
    state = smoke_state if isinstance(smoke_state, dict) else {}
    report_path = str(state.get('last_report_path', '') or '').strip()
    json_path = _adjacent_json_path_for_text_report(report_path)
    if not json_path:
        return {}
    payload = _load_json_dict(json_path)
    return payload if isinstance(payload, dict) else {}


def _safe_json_pair_path(reports_dir, prefix, run_id, suffix):
    reports_dir = str(reports_dir or '').strip()
    run_id = str(run_id or '').strip()
    if not reports_dir or not run_id:
        return ''
    path = os.path.join(reports_dir, '{0}{1}{2}'.format(prefix, run_id, suffix))
    if os.path.isfile(path):
        return path
    return ''


def _dat_metric_from_sources(
        shadow_payload, phase_d_payload, phase_d_telemetry, smoke_df,
        shadow_key, summary_key, smoke_counters_allowed=False):
    """
    Resolve a single DAT metric. Smoke funnel counters may override anchored Phase D only when
    smoke_counters_allowed is True (completed smoke, dat_selected_qa_blocked, same anchor as review).
    Otherwise anchored phase_d_telemetry / phase_d_payload / shadow_payload are display truth.
    """
    sources = []
    if smoke_counters_allowed and isinstance(smoke_df, dict):
        sources.append(smoke_df)
    sources.extend([phase_d_telemetry, phase_d_payload])
    for source in sources:
        if isinstance(source, dict) and summary_key in source:
            return _safe_int(source.get(summary_key), 0)
    if isinstance(shadow_payload, dict) and shadow_key in shadow_payload:
        return _safe_int(shadow_payload.get(shadow_key), 0)
    return None


def _build_phase_d_dat_qa_full_block_recommendation(repo_root, snapshot, smoke_state, pipeline_running):
    """Compatibility wrapper for _recommendation_tools._build_phase_d_dat_qa_full_block_recommendation."""
    return _recommendation_tools._IMPL__build_phase_d_dat_qa_full_block_recommendation(repo_root, snapshot, smoke_state, pipeline_running)



def _qa_drop_spike_reply_context(lab_root):
    """Compatibility wrapper for _recommendation_tools._qa_drop_spike_reply_context."""
    return _recommendation_tools._IMPL__qa_drop_spike_reply_context(lab_root)



def _step2_run_coherence_from_snapshot(snapshot):
    """Compatibility wrapper for _recommendation_tools._step2_run_coherence_from_snapshot."""
    return _recommendation_tools._IMPL__step2_run_coherence_from_snapshot(snapshot)




def compute_operator_support_send_recommendation_core(repo_root, evaluation_snapshot, ok_snap, snap_msg, pipeline_running, recommendation_source_scope='latest_live_snapshot', recommendation_anchor_run_id='', recommendation_live_run_id='', recommendation_live_run_status='', provenance_extra_lines=None):
    """Compatibility wrapper for _recommendation_tools.compute_operator_support_send_recommendation_core."""
    return _recommendation_tools._IMPL_compute_operator_support_send_recommendation_core(repo_root, evaluation_snapshot, ok_snap, snap_msg, pipeline_running, recommendation_source_scope, recommendation_anchor_run_id, recommendation_live_run_id, recommendation_live_run_status, provenance_extra_lines)



def compute_operator_support_send_recommendation(repo_root, env_flag_fn=None):
    """Compatibility wrapper for _recommendation_tools.compute_operator_support_send_recommendation."""
    return _recommendation_tools._IMPL_compute_operator_support_send_recommendation(repo_root, env_flag_fn)



def run_pipeline(repo_root, python_exe, env, env_flag_fn):
    """Compatibility wrapper for _action_tools.run_pipeline."""
    return _action_tools._IMPL_run_pipeline(repo_root, python_exe, env, env_flag_fn)



def _find_latest_run_id_by_prefix(reports_dir, prefix, suffix_choices):
    """Compatibility wrapper for _action_tools._find_latest_run_id_by_prefix."""
    return _action_tools._IMPL__find_latest_run_id_by_prefix(reports_dir, prefix, suffix_choices)



def _preferred_evidence_run_id(lab_root, reports_dir):
    state = _load_json_dict(os.path.join(lab_root or '.', 'diagnostics_state.json'))
    if not isinstance(state, dict):
        state = {}
    pipeline_running = is_pipeline_running(lab_root)
    try:
        return _artifact_tools.prefer_diagnostics_run_id(
            reports_dir,
            state,
            pipeline_running,
            run_has_required_artifacts_fn=_run_has_required_artifacts,
        )
    except Exception:
        return ''


def _reports_dir_access_error(lab_root):
    """Return readable error string when reports dir exists but is unreadable; else None."""
    reports_dir = os.path.join(lab_root, 'reports')
    if not reports_dir or not os.path.exists(reports_dir):
        return None
    try:
        os.listdir(reports_dir)
    except (IOError, OSError) as e:
        return 'Unable to read reports directory: {0}'.format(e)
    return None


def _select_latest_evidence_files(lab_root, prefix_specs, prefer_diagnostics_lineage=False):
    """Compatibility wrapper for _action_tools._select_latest_evidence_files."""
    return _action_tools._IMPL__select_latest_evidence_files(lab_root, prefix_specs, prefer_diagnostics_lineage)



def _find_latest_by_prefix(reports_dir, prefix, suffix_choices):
    """Find latest file by prefix. Returns (path, None) or (None, message)."""
    if not reports_dir or not os.path.exists(reports_dir):
        return (None, 'No reports directory: {0}'.format(reports_dir))
    try:
        items = os.listdir(reports_dir)
    except (IOError, OSError) as e:
        return (None, 'Unable to read reports directory: {0}'.format(e))
    candidates = []
    for item in items:
        if item.startswith(prefix):
            for suf in suffix_choices:
                if item.endswith(suf):
                    path = os.path.join(reports_dir, item)
                    if os.path.isfile(path):
                        candidates.append(path)
                    break
    if not candidates:
        return (None, None)
    try:
        return (max(candidates, key=os.path.getmtime), None)
    except (IOError, OSError, ValueError):
        return (None, 'Unable to resolve latest report file.')


def _shadow_run_report_run_id_from_path(path):
    """Extract shadow pipeline run_id from a shadow_run_report path."""
    if not path:
        return ''
    base = os.path.basename(str(path))
    if not base.startswith('shadow_run_report_'):
        return ''
    tail = base[len('shadow_run_report_'):]
    for suffix in ('.json', '.txt'):
        if tail.endswith(suffix):
            return tail[:-len(suffix)]
    return ''


def open_phase_b_summary(repo_root):
    """Compatibility wrapper for _action_tools.open_phase_b_summary."""
    return _action_tools._IMPL_open_phase_b_summary(repo_root)



def open_manifest_location(repo_root):
    """Compatibility wrapper for _action_tools.open_manifest_location."""
    return _action_tools._IMPL_open_manifest_location(repo_root)



def _resolve_unified_model_script(repo_root, python_exe, script_name):
    script_repo_root, script_path, script_checks = shadow_orchestrator._find_unified_model_script(
        repo_root, script_name, python_exe=python_exe
    )
    if os.path.exists(script_path):
        return (True, '', script_repo_root, script_path, script_checks)
    checked_paths = [c.get('script_path', '') for c in script_checks if c.get('script_path')]
    detail = ', '.join(checked_paths) if checked_paths else script_path
    msg = '{0} not found. checked: {1}'.format(script_name, detail)
    _log_health('WARNING', 'Cloud Readiness script resolution failure: {0}'.format(msg))
    return (False, msg, script_repo_root, script_path, script_checks)


def run_phase_b_manual(repo_root, python_exe, env):
    """Compatibility wrapper for _action_tools.run_phase_b_manual."""
    return _action_tools._IMPL_run_phase_b_manual(repo_root, python_exe, env)



def _send_phase_evidence(lab_root, prefix_specs, extra_meta_key, no_attach_msg):
    """Compatibility wrapper for _action_tools._send_phase_evidence."""
    return _action_tools._IMPL__send_phase_evidence(lab_root, prefix_specs, extra_meta_key, no_attach_msg)



def send_phase_b_evidence(repo_root):
    """Compatibility wrapper for _action_tools.send_phase_b_evidence."""
    return _action_tools._IMPL_send_phase_b_evidence(repo_root)



def open_phase_c_summary(repo_root):
    """Compatibility wrapper for _action_tools.open_phase_c_summary."""
    return _action_tools._IMPL_open_phase_c_summary(repo_root)



def run_phase_c_manual(repo_root, python_exe, env):
    """Compatibility wrapper for _action_tools.run_phase_c_manual."""
    return _action_tools._IMPL_run_phase_c_manual(repo_root, python_exe, env)



def send_phase_c_evidence(repo_root):
    """Compatibility wrapper for _action_tools.send_phase_c_evidence."""
    return _action_tools._IMPL_send_phase_c_evidence(repo_root)



def open_phase_d_summary(repo_root):
    """Compatibility wrapper for _action_tools.open_phase_d_summary."""
    return _action_tools._IMPL_open_phase_d_summary(repo_root)



def open_phase_d_reject_sample(repo_root):
    """Compatibility wrapper for _action_tools.open_phase_d_reject_sample."""
    return _action_tools._IMPL_open_phase_d_reject_sample(repo_root)



def run_phase_d_manual(repo_root, python_exe, env, artifact_classes=None):
    """Compatibility wrapper for _action_tools.run_phase_d_manual."""
    return _action_tools._IMPL_run_phase_d_manual(repo_root, python_exe, env, artifact_classes)



def run_phase_d_dat_smoke(repo_root, python_exe, env, reference_phase_d_summary_path=None, recommendation_anchor_run_id='', recommendation_context_run_id='', recommendation_issue_code=''):
    """Compatibility wrapper for _action_tools.run_phase_d_dat_smoke."""
    return _action_tools._IMPL_run_phase_d_dat_smoke(repo_root, python_exe, env, reference_phase_d_summary_path, recommendation_anchor_run_id, recommendation_context_run_id, recommendation_issue_code)



def preview_historical_phase_d_reprocess(repo_root, artifact_classes=None, remediation_context_run_id=None):
    """Compatibility wrapper for _action_tools.preview_historical_phase_d_reprocess."""
    return _action_tools._IMPL_preview_historical_phase_d_reprocess(repo_root, artifact_classes, remediation_context_run_id)




def run_historical_phase_d_reprocess(repo_root, python_exe, env, artifact_classes=None, remediation_context_run_id=None):
    """Compatibility wrapper for _action_tools.run_historical_phase_d_reprocess."""
    return _action_tools._IMPL_run_historical_phase_d_reprocess(repo_root, python_exe, env, artifact_classes, remediation_context_run_id)



def send_phase_d_evidence(repo_root):
    """Compatibility wrapper for _action_tools.send_phase_d_evidence."""
    return _action_tools._IMPL_send_phase_d_evidence(repo_root)



def open_phase_e_summary(repo_root):
    """Compatibility wrapper for _action_tools.open_phase_e_summary."""
    return _action_tools._IMPL_open_phase_e_summary(repo_root)



def open_phase_e_deviation_samples(repo_root):
    """Compatibility wrapper for _action_tools.open_phase_e_deviation_samples."""
    return _action_tools._IMPL_open_phase_e_deviation_samples(repo_root)



def run_phase_e_manual(repo_root, python_exe, env):
    """Compatibility wrapper for _action_tools.run_phase_e_manual."""
    return _action_tools._IMPL_run_phase_e_manual(repo_root, python_exe, env)



def send_phase_e_evidence(repo_root):
    """Compatibility wrapper for _action_tools.send_phase_e_evidence."""
    return _action_tools._IMPL_send_phase_e_evidence(repo_root)



def run_shadow_pipeline(repo_root, python_exe, env):
    """Compatibility wrapper for _action_tools.run_shadow_pipeline."""
    return _action_tools._IMPL_run_shadow_pipeline(repo_root, python_exe, env)



def open_phase_f_shadow_report(repo_root):
    """Compatibility wrapper for _action_tools.open_phase_f_shadow_report."""
    return _action_tools._IMPL_open_phase_f_shadow_report(repo_root)



def open_phase_f_evidence_index(repo_root):
    """Compatibility wrapper for _action_tools.open_phase_f_evidence_index."""
    return _action_tools._IMPL_open_phase_f_evidence_index(repo_root)



def run_phase_f_manual(repo_root, python_exe, env, pipeline_running=None):
    """Compatibility wrapper for _action_tools.run_phase_f_manual."""
    return _action_tools._IMPL_run_phase_f_manual(repo_root, python_exe, env, pipeline_running)



def run_phase_f_manual_for_run_id(repo_root, python_exe, env, run_id):
    """Compatibility wrapper for _action_tools.run_phase_f_manual_for_run_id."""
    return _action_tools._IMPL_run_phase_f_manual_for_run_id(repo_root, python_exe, env, run_id)



def send_phase_f_evidence(repo_root):
    """Compatibility wrapper for _action_tools.send_phase_f_evidence."""
    return _action_tools._IMPL_send_phase_f_evidence(repo_root)



def open_report_delivery_status(repo_root):
    """Compatibility wrapper for _action_tools.open_report_delivery_status."""
    return _action_tools._IMPL_open_report_delivery_status(repo_root)



def _parse_shadow_run_id_from_report_text(text):
    """Best-effort run_id from shadow_run_report*.txt body."""
    for line in (text or '').splitlines()[:48]:
        line = line.strip()
        if line.startswith('run_id:'):
            return line.split(':', 1)[1].strip()
    return ''


def _append_phase_f_report_appendix(content, reports_dir, lab_root):
    """Attach shadow_run_report for the current pipeline run_id when possible; avoid silent stale green."""
    state = _load_json_dict(os.path.join(lab_root, 'diagnostics_state.json'))
    expected_rid = str(state.get('last_shadow_pipeline_run_id', '') or '').strip()
    if not expected_rid:
        expected_rid = str(state.get('active_run_id', '') or '').strip()
    lock_diag = str(state.get('last_phase_f_lock_diag_path', '') or '').strip()
    failed_phase = str(state.get('last_shadow_pipeline_failed_phase', '') or '').strip().upper()
    err_code = str(state.get('last_shadow_pipeline_error_code', '') or '')
    phase_f_failed = failed_phase == 'F' or 'PHASE_F' in err_code

    def append_section(title, body):
        content[0] += '\n--- {0} ---\n'.format(title)
        content[0] += body

    preferred = ''
    if expected_rid:
        candidate = os.path.join(reports_dir, 'shadow_run_report_{0}.txt'.format(expected_rid))
        if os.path.isfile(candidate):
            preferred = candidate
    if preferred:
        try:
            with open(preferred, 'r', encoding='utf-8') as f:
                append_section('Phase F detailed report', f.read())
        except (IOError, OSError):
            pass
        return

    if expected_rid and phase_f_failed:
        stub = (
            'No shadow_run_report_{0}.txt found (Phase F likely failed before packaging). '.format(expected_rid)
        )
        if lock_diag:
            stub += 'Lock/evidence: {0}\n'.format(os.path.basename(lock_diag))
        else:
            stub += 'See diagnostics_state.json for Phase F error fields.\n'
        append_section('Phase F detailed report', stub)
        return

    # Latest .txt only; a single max(mtime) across .txt and .json drops the appendix when JSON is newer.
    shadow_path, _ = _find_latest_by_prefix(reports_dir, 'shadow_run_report_', ('.txt',))
    if shadow_path:
        try:
            with open(shadow_path, 'r', encoding='utf-8') as f:
                shadow_content = f.read()
            parsed_rid = _parse_shadow_run_id_from_report_text(shadow_content)
            banner = ''
            if expected_rid and parsed_rid and parsed_rid != expected_rid:
                banner = (
                    'WARNING: This appendix file is for run_id={0}; current pipeline context run_id={1}.\n\n'.format(
                        parsed_rid, expected_rid,
                    )
                )
            append_section('Phase F detailed report', banner + shadow_content)
        except (IOError, OSError):
            pass


def open_consolidated_health_report(repo_root, env_flag_fn):
    """
    Generate and return path to consolidated health report (all phases B-F).
    Writes Pipeline Health Snapshot to lab/reports/consolidated_health_snapshot.txt,
    appending shadow_run_report for the current run when possible.
    Returns (ok, message, path).
    """
    lab_root = resolve_lab_root(repo_root)
    lines = get_health_lines(lab_root, env_flag_fn)
    reports_dir = os.path.join(lab_root, 'reports')
    try:
        if reports_dir and not os.path.exists(reports_dir):
            os.makedirs(reports_dir, exist_ok=True)
        path = os.path.join(reports_dir, 'consolidated_health_snapshot.txt')
        content_holder = ['\n'.join(lines) + '\n']
        _append_phase_f_report_appendix(content_holder, reports_dir, lab_root)
        with open(path, 'w', encoding='utf-8') as f:
            f.write(content_holder[0])
        return (True, '', path)
    except Exception as e:
        return (False, str(e), None)


def _audit_script_path(repo_root, python_exe=None):
    ok_script, script_msg, script_repo_root, script_path, script_checks = _resolve_unified_model_script(
        repo_root, python_exe, 'audit_migration_health.py'
    )
    return {
        'ok': ok_script,
        'message': script_msg,
        'cwd': script_repo_root,
        'path': script_path,
        'checks': script_checks,
    }


def _extract_json_object_from_text(raw_text):
    """Best-effort JSON object extraction from mixed stdout text."""
    text = str(raw_text or '').strip()
    if not text:
        return {}
    # Fast path: entire payload is JSON.
    try:
        obj = json.loads(text)
        if isinstance(obj, dict):
            return obj
    except ValueError:
        pass
    # Fallback: parse line-by-line and return first JSON object line.
    for line in text.splitlines():
        line = line.strip()
        if not line or not line.startswith('{'):
            continue
        try:
            obj = json.loads(line)
            if isinstance(obj, dict):
                return obj
        except ValueError:
            continue
    return {}


def _deduplicate_audit_hint_lines(hints):
    """Drop duplicate hint lines (normalized by stripped text), preserve first occurrence order."""
    seen = set()
    deduped = []
    for line in hints:
        if not isinstance(line, str):
            continue
        key = line.strip()
        if not key or key in seen:
            continue
        seen.add(key)
        deduped.append(line)
    return deduped


def _audit_hint_lines_from_payload(payload):
    """Compatibility wrapper for _recommendation_tools._audit_hint_lines_from_payload."""
    return _recommendation_tools._IMPL__audit_hint_lines_from_payload(payload)



def _shadow_run_actual_from_payload(payload, path=''):
    """Compatibility wrapper for _recommendation_tools._shadow_run_actual_from_payload."""
    return _recommendation_tools._IMPL__shadow_run_actual_from_payload(payload, path)



def _collect_recent_shadow_run_actuals(reports_dir, limit=3):
    """Compatibility wrapper for _recommendation_tools._collect_recent_shadow_run_actuals."""
    return _recommendation_tools._IMPL__collect_recent_shadow_run_actuals(reports_dir, limit)



def _derive_current_state_post_medisoft_summary(state):
    """Return compact live DAT/post-MediSoft summary from diagnostics state."""
    if _patient_tools:
        return _patient_tools._IMPL_derive_post_medisoft_summary(state, _safe_int)
    return {
        'status': 'not_exercised',
        'blocked_stage': '',
        'label': 'not_exercised',
        'manifest_rows': 0,
        'selected': 0,
        'qa_pass': 0,
        'qa_reject': 0,
        'canonical': 0,
    }


def _audit_shadow_run_id(payload):
    """Return shadow pipeline run_id recorded by the audit payload."""
    surfaces = payload.get('surfaces', {}) if isinstance(payload.get('surfaces', {}), dict) else {}
    xp = surfaces.get('xp_local', {}) if isinstance(surfaces.get('xp_local', {}), dict) else {}
    run_ids = xp.get('run_ids', {}) if isinstance(xp.get('run_ids', {}), dict) else {}
    return str(run_ids.get('shadow', '') or '').strip()


def _load_shadow_report_payload(shadow_report_path):
    """Return parsed shadow_run_report JSON payload and resolved JSON path when available."""
    path = str(shadow_report_path or '').strip()
    if not path:
        return ({}, '')
    candidates = []
    if path.lower().endswith('.txt'):
        candidates.append(path[:-4] + '.json')
    elif path.lower().endswith('.json'):
        candidates.append(path)
    if path not in candidates:
        candidates.append(path)
    seen = set()
    for candidate in candidates:
        key = os.path.normcase(os.path.abspath(candidate)) if candidate else candidate
        if key in seen:
            continue
        seen.add(key)
        data = _load_json_dict(candidate)
        if data:
            return (data, candidate)
    return ({}, '')


def _shadow_report_has_summary_fields(payload):
    if not isinstance(payload, dict):
        return False
    for key in (
            'pipeline_ok', 'failed_phase', 'error_code', 'post_medisoft_status',
            'phase_b_dat_manifest_rows_count', 'phase_d_dat_selected_count',
            'phase_d_dat_qa_reject_count', 'phase_d_dat_qa_pass_count',
            'phase_d_dat_canonical_record_count'):
        if key in payload:
            return True
    return False


def _select_system_health_anchor_report_path(reports_dir, artifacts, expected_run_id=''):
    """Resolve the completed-run shadow_run_report JSON that should anchor the pack."""
    if expected_run_id:
        expected_json = os.path.join(reports_dir or '.', 'shadow_run_report_{0}.json'.format(expected_run_id))
        if os.path.isfile(expected_json):
            return expected_json
    selected_path = str((artifacts or {}).get('shadow_report_path', '') or '').strip()
    if selected_path.lower().endswith('.txt'):
        candidate = selected_path[:-4] + '.json'
        if os.path.isfile(candidate):
            return candidate
    if selected_path.lower().endswith('.json') and os.path.isfile(selected_path):
        return selected_path
    return ''


def _merge_state_overrides(base_state, overrides):
    merged = dict(base_state or {})
    if not isinstance(overrides, dict):
        return merged
    replace_keys = ('last_discovery_dat_telemetry', 'last_phase_d_dat_telemetry')
    for key, value in overrides.items():
        if key in replace_keys and isinstance(value, dict):
            merged[key] = dict(value)
        elif isinstance(value, dict) and isinstance(merged.get(key), dict):
            current = dict(merged.get(key) or {})
            current.update(value)
            merged[key] = current
        else:
            merged[key] = value
    return merged


def _shadow_report_state_overrides(payload):
    """Map anchored shadow_run_report summary fields into state-style DAT telemetry keys."""
    if not _shadow_report_has_summary_fields(payload):
        return {}
    discovery = {}
    phase_d = {}
    for src, dst in (
            ('phase_b_dat_manifest_rows_count', 'dat_manifest_rows_count'),
            ('phase_b_dat_configured_root_missing_count', 'dat_configured_root_missing_count'),
            ('phase_b_dat_fallback_root_count', 'dat_fallback_root_count'),
            ('phase_b_dat_existing_empty_root_count', 'dat_existing_empty_root_count'),
            ('phase_b_dat_selection_mode', 'dat_selection_mode'),
            ('phase_b_dat_selected_root_source_id', 'dat_selected_root_source_id'),
            ('phase_b_dat_effective_root_source_id', 'dat_effective_root_source_id'),
            ('phase_b_dat_root_yield_counts_by_source', 'dat_root_yield_counts_by_source'),
            ('phase_b_dat_yielding_root_source_ids', 'dat_yielding_root_source_ids')):
        if src in payload:
            discovery[dst] = payload.get(src)
    for src, dst in (
            ('phase_d_dat_selected_count', 'dat_selected_count'),
            ('phase_d_dat_qa_pass_count', 'dat_qa_pass_count'),
            ('phase_d_dat_qa_reject_count', 'dat_qa_reject_count'),
            ('phase_d_dat_qa_reject_counts_by_reason', 'dat_qa_reject_counts_by_reason'),
            ('phase_d_dat_field_presence_by_alias', 'dat_field_presence_by_alias'),
            ('phase_d_dat_canonical_record_count', 'dat_canonical_record_count'),
            ('phase_d_entity_scope', 'phase_d_entity_scope'),
            ('phase_d_dat_parse_diagnostics', 'dat_parse_diagnostics'),
            ('phase_d_dat_file_prefix_counts', 'dat_file_prefix_counts'),
            ('phase_d_dat_reject_file_prefix_counts', 'dat_reject_file_prefix_counts')):
        if src in payload:
            phase_d[dst] = payload.get(src)
    if 'post_medisoft_status' in payload:
        phase_d['post_medisoft_exercised'] = str(payload.get('post_medisoft_status', '') or '').strip().lower() == 'exercised'
    if 'post_medisoft_blocked_stage' in payload:
        phase_d['post_medisoft_blocked_stage'] = payload.get('post_medisoft_blocked_stage')

    overrides = {}
    if discovery:
        overrides['last_discovery_dat_telemetry'] = discovery
    if phase_d:
        overrides['last_phase_d_dat_telemetry'] = phase_d
    run_id = str(payload.get('run_id', '') or '').strip()
    if run_id:
        overrides['last_shadow_pipeline_run_id'] = run_id
    return overrides


def _build_system_health_pack_context(lab_root, reports_dir, artifacts):
    """Compatibility wrapper for _recommendation_tools._build_system_health_pack_context."""
    return _recommendation_tools._IMPL__build_system_health_pack_context(lab_root, reports_dir, artifacts)



def _build_anchor_run_snapshot_lines(pack_context):
    """Compatibility wrapper for _recommendation_tools._build_anchor_run_snapshot_lines."""
    return _recommendation_tools._IMPL__build_anchor_run_snapshot_lines(pack_context)



def _should_show_latest_live_pipeline_attempt(pack_context):
    """Compatibility wrapper for _recommendation_tools._should_show_latest_live_pipeline_attempt."""
    return _recommendation_tools._IMPL__should_show_latest_live_pipeline_attempt(pack_context)



def _build_latest_live_pipeline_attempt_lines(pack_context):
    """Compatibility wrapper for _recommendation_tools._build_latest_live_pipeline_attempt_lines."""
    return _recommendation_tools._IMPL__build_latest_live_pipeline_attempt_lines(pack_context)



def _build_system_health_alignment_notes(lab_root, reports_dir, artifacts, audit_payload):
    """Compatibility wrapper for _recommendation_tools._build_system_health_alignment_notes."""
    return _recommendation_tools._IMPL__build_system_health_alignment_notes(lab_root, reports_dir, artifacts, audit_payload)



def _build_recent_shadow_run_actual_lines(reports_dir, limit=3, expected_run_id=''):
    """Compatibility wrapper for _recommendation_tools._build_recent_shadow_run_actual_lines."""
    return _recommendation_tools._IMPL__build_recent_shadow_run_actual_lines(reports_dir, limit, expected_run_id)



def _build_recent_run_regression_hints(latest, previous):
    """Compatibility wrapper for _recommendation_tools._build_recent_run_regression_hints."""
    return _recommendation_tools._IMPL__build_recent_run_regression_hints(latest, previous)



def run_migration_health_audit(repo_root, python_exe, env, scope='both', write_report=False, cloud_required=False, migration_stage='xp_validation'):
    """Compatibility wrapper for _action_tools.run_migration_health_audit."""
    return _action_tools._IMPL_run_migration_health_audit(repo_root, python_exe, env, scope, write_report, cloud_required, migration_stage)



def open_latest_migration_health_report(repo_root):
    """Compatibility wrapper for _action_tools.open_latest_migration_health_report."""
    return _action_tools._IMPL_open_latest_migration_health_report(repo_root)



def _add_unique_file(extra_files, seen, path, alias=None):
    """Append existing file path once to support-bundle file list."""
    if not path or not os.path.isfile(path):
        return
    try:
        norm = os.path.normcase(os.path.abspath(path))
    except Exception:
        norm = str(path)
    if norm in seen:
        return
    seen.add(norm)
    extra_files.append((alias or os.path.basename(path), path))


def _collect_system_health_artifacts(repo_root, env_flag_fn, include_delivery_status=False):
    """Resolve latest system-health artifact paths; refresh consolidated snapshot first."""
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    if reports_dir and not os.path.exists(reports_dir):
        os.makedirs(reports_dir, exist_ok=True)

    consolidated_ok, consolidated_msg, consolidated_path = open_consolidated_health_report(
        repo_root, env_flag_fn)
    if not consolidated_ok:
        consolidated_path = ''

    audit_summary_txt, _ = _find_latest_by_prefix(
        reports_dir, 'audit_migration_health_summary_', ('.txt',))
    audit_summary_json, _ = _find_latest_by_prefix(
        reports_dir, 'audit_migration_health_summary_', ('.json',))
    audit_metrics_json, _ = _find_latest_by_prefix(
        reports_dir, 'audit_migration_health_metrics_', ('.json',))
    preferred_run_id = _preferred_evidence_run_id(lab_root, reports_dir)
    shadow_report_path = ''
    shadow_index_path = ''
    phase_f_mismatch_path = ''
    if preferred_run_id:
        for suffix in ('.json', '.txt'):
            candidate = os.path.join(reports_dir, 'shadow_run_report_{0}{1}'.format(preferred_run_id, suffix))
            if os.path.isfile(candidate):
                shadow_report_path = candidate
                break
        candidate = os.path.join(reports_dir, 'shadow_evidence_index_{0}.json'.format(preferred_run_id))
        if os.path.isfile(candidate):
            shadow_index_path = candidate
        candidate = os.path.join(reports_dir, 'phase_f_mismatch_{0}.txt'.format(preferred_run_id))
        if os.path.isfile(candidate):
            phase_f_mismatch_path = candidate
    if not shadow_report_path:
        shadow_report_path, _ = _find_latest_by_prefix(
            reports_dir, 'shadow_run_report_', ('.txt', '.json'))
    if not shadow_index_path:
        shadow_index_path, _ = _find_latest_by_prefix(
            reports_dir, 'shadow_evidence_index_', ('.json',))
    if not phase_f_mismatch_path:
        phase_f_mismatch_path, _ = _find_latest_by_prefix(
            reports_dir, 'phase_f_mismatch_', ('.txt',))

    delivery_status_path = os.path.join(reports_dir, 'report_delivery_status.txt')
    if include_delivery_status:
        delivery_ok, _, delivery_path = open_report_delivery_status(repo_root)
        if delivery_ok and delivery_path:
            delivery_status_path = delivery_path
    if not os.path.isfile(delivery_status_path):
        delivery_status_path = ''

    return {
        'lab_root': lab_root,
        'reports_dir': reports_dir,
        'consolidated_ok': bool(consolidated_ok),
        'consolidated_message': consolidated_msg or '',
        'consolidated_path': consolidated_path or '',
        'audit_summary_txt': audit_summary_txt or '',
        'audit_summary_json': audit_summary_json or '',
        'audit_metrics_json': audit_metrics_json or '',
        'shadow_report_path': shadow_report_path or '',
        'shadow_index_path': shadow_index_path or '',
        'phase_f_mismatch_path': phase_f_mismatch_path or '',
        'delivery_status_path': delivery_status_path or '',
    }


def _collect_current_state_bundle_companion_files(repo_root, lab_root):
    """Return current-run companion artifacts referenced by diagnostics state."""
    state = _load_json_dict(os.path.join(lab_root or '.', 'diagnostics_state.json'))
    current_run_id = str(state.get('last_shadow_pipeline_run_id', '') or '').strip()
    files = []
    seen = set()
    if current_run_id:
        try:
            ok, _msg, snapshot = _build_run_artifact_snapshot(repo_root, run_id=current_run_id)
        except Exception:
            ok, snapshot = False, None
        if ok and isinstance(snapshot, dict):
            for path in snapshot.get('artifact_files', []):
                _append_unique_path(files, seen, path)
            for path in snapshot.get('context_files', []):
                _append_unique_path(files, seen, path)
    lock_diag_path = str(state.get('last_phase_f_lock_diag_path', '') or '').strip()
    if lock_diag_path:
        _append_unique_path(files, seen, lock_diag_path)
    return files



def _build_phase_f_lock_context_lines(lab_root):
    """Return compact inline lock context when the latest Phase F failed on lock acquisition."""
    state = _load_json_dict(os.path.join(lab_root or '.', 'diagnostics_state.json'))
    error_code = str(
        state.get('last_shadow_pipeline_error_code', '') or state.get('last_error_code', '') or ''
    ).strip().upper()
    if error_code != 'PHASE_F_LOCK_FAIL':
        return []

    diag_path = str(state.get('last_phase_f_lock_diag_path', '') or '').strip()
    diag_exists = bool(diag_path and os.path.isfile(diag_path))
    diag = _load_json_dict(diag_path) if diag_exists else {}
    parts = []
    reason = str(diag.get('reason', '') or '').strip()
    if reason:
        parts.append('reason={0}'.format(reason))
    if 'lock_owner_running' in diag:
        parts.append('owner_running={0}'.format(bool(diag.get('lock_owner_running'))))
    if 'lock_heartbeat_stale' in diag:
        parts.append('heartbeat_stale={0}'.format(bool(diag.get('lock_heartbeat_stale'))))
    pid = str(diag.get('lock_pid', '') or '').strip()
    if pid:
        parts.append('pid={0}'.format(pid))
    if not parts:
        detail = str(state.get('last_error_detail', '') or '').strip()
        if detail:
            parts.append('detail={0}'.format(detail))
    if diag_path:
        label = os.path.basename(diag_path)
        if not diag_exists:
            label += ' (missing)'
        parts.append('diag={0}'.format(label))
    return ['Phase F lock context: {0}'.format(', '.join(parts) if parts else 'diagnostics unavailable')]


def _load_shadow_report_machine_context(shadow_report_path):
    """Return machine/runtime fingerprint from latest shadow_run_report JSON when available."""
    path = str(shadow_report_path or '').strip()
    if not path:
        return {}
    candidate_paths = [path]
    if path.lower().endswith('.txt'):
        candidate_paths.insert(0, path[:-4] + '.json')
    for candidate in candidate_paths:
        data = _load_json_dict(candidate)
        if not data:
            continue
        out = {}
        for key in (
                'machine_hostname',
                'machine_app_version',
                'machine_python_version',
                'machine_platform',
                'machine_test_mode'):
            if key in data:
                out[key] = data.get(key)
        if out:
            return out
    return {}


def open_latest_system_health_pack(
        repo_root,
        env_flag_fn,
        include_delivery_status=False,
        progress_callback=None,
        include_guided_patient_preview=True):
    """Compatibility wrapper for _recommendation_tools.open_latest_system_health_pack."""
    return _recommendation_tools._IMPL_open_latest_system_health_pack(
        repo_root,
        env_flag_fn,
        include_delivery_status,
        progress_callback,
        include_guided_patient_preview)



def run_system_health_triage(repo_root, python_exe, env, env_flag_fn, scope='both', cloud_required=False, migration_stage='xp_validation'):
    """Compatibility wrapper for _recommendation_tools.run_system_health_triage."""
    return _recommendation_tools._IMPL_run_system_health_triage(repo_root, python_exe, env, env_flag_fn, scope, cloud_required, migration_stage)



def send_latest_system_health_pack(
        repo_root,
        env_flag_fn,
        progress_callback=None,
        recommendation=None,
        send_source='manual_system_health_pack',
        operator_execution_mode='explicit_send_menu',
        frozen_recommendation=None,
        support_send_job_context=None):
    """Compatibility wrapper for _recommendation_tools.send_latest_system_health_pack."""
    return _recommendation_tools._IMPL_send_latest_system_health_pack(
        repo_root,
        env_flag_fn,
        progress_callback,
        recommendation,
        send_source,
        operator_execution_mode,
        frozen_recommendation,
        support_send_job_context,
    )



_ARTIFACT_PHASE_LAYOUT = _artifact_tools.ARTIFACT_PHASE_LAYOUT


def _append_unique_path(paths, seen, path):
    return _artifact_tools.append_unique_path(paths, seen, path)


def _safe_run_token(run_id):
    return _artifact_tools.safe_run_token(run_id)


def _collect_group_paths_for_run(reports_dir, run_id, group):
    return _artifact_tools.collect_group_paths_for_run(reports_dir, run_id, group)


def _collect_artifact_run_candidates(reports_dir):
    return _artifact_tools.collect_artifact_run_candidates(
        reports_dir,
        artifact_phase_layout=_ARTIFACT_PHASE_LAYOUT,
    )


def _recent_artifact_run_ids(reports_dir, limit=20):
    return _artifact_tools.recent_artifact_run_ids(
        reports_dir,
        limit=limit,
        collect_artifact_run_candidates_fn=_collect_artifact_run_candidates,
    )


def _run_has_required_artifacts(reports_dir, run_id):
    return _artifact_tools.run_has_required_artifacts(
        reports_dir,
        run_id,
        artifact_phase_layout=_ARTIFACT_PHASE_LAYOUT,
        collect_group_paths_for_run_fn=_collect_group_paths_for_run,
    )


def _find_latest_complete_artifact_run_id(reports_dir, exclude_run_id=''):
    return _artifact_tools.find_latest_complete_artifact_run_id(
        reports_dir,
        exclude_run_id=exclude_run_id,
        recent_artifact_run_ids_fn=_recent_artifact_run_ids,
        run_has_required_artifacts_fn=_run_has_required_artifacts,
    )


def _find_latest_artifact_run_id(reports_dir):
    return _artifact_tools.find_latest_artifact_run_id(
        reports_dir,
        collect_artifact_run_candidates_fn=_collect_artifact_run_candidates,
    )


def _build_run_artifact_snapshot(repo_root, run_id=''):
    return _artifact_tools.build_run_artifact_snapshot(
        repo_root,
        run_id=run_id,
        resolve_lab_root_fn=resolve_lab_root,
        reports_dir_access_error_fn=_reports_dir_access_error,
        find_latest_artifact_run_id_fn=_find_latest_artifact_run_id,
        load_json_dict_fn=_load_json_dict,
        find_latest_complete_artifact_run_id_fn=_find_latest_complete_artifact_run_id,
        recent_artifact_run_ids_fn=_recent_artifact_run_ids,
        is_pipeline_running_fn=is_pipeline_running,
        artifact_phase_layout=_ARTIFACT_PHASE_LAYOUT,
        collect_group_paths_for_run_fn=_collect_group_paths_for_run,
        append_unique_path_fn=_append_unique_path,
    )


def _recommended_action_for_snapshot(snapshot):
    """
    Operator recommendation for a run evidence snapshot (triage, run artifact index).
    Anchor the evaluated run_id so milestone_verdict / evidence_coherence match the opened snapshot,
    not an unanchored summary.
    """
    rec = None
    repo_root = str((snapshot or {}).get('repo_root', '') or '').strip()
    if repo_root:
        try:
            lab_root = str((snapshot or {}).get('lab_root', '') or '').strip() or resolve_lab_root(repo_root)
            pipeline_running = is_pipeline_running(lab_root)
            state = _load_json_dict(os.path.join(lab_root, 'diagnostics_state.json'))
            live_id = str((snapshot or {}).get('run_id', '') or '').strip()
            live_status = _derive_live_pipeline_status(state, pipeline_running)
            eval_snap = snapshot if isinstance(snapshot, dict) else {}
            if live_id:
                eval_snap = _relax_snapshot_diagnostics_for_anchor_evaluation(eval_snap, live_id)
            rec = compute_operator_support_send_recommendation_core(
                repo_root,
                eval_snap,
                True,
                '',
                pipeline_running,
                recommendation_source_scope='latest_live_snapshot',
                recommendation_anchor_run_id=live_id,
                recommendation_live_run_id=live_id,
                recommendation_live_run_status=live_status,
            )
        except Exception:
            rec = None
    return rec


def _write_run_artifact_index(snapshot, latest_alias=False, recommended_action=None):
    return _artifact_tools.write_run_artifact_index(
        snapshot, latest_alias=latest_alias, recommended_action=recommended_action)


def _write_artifact_triage_pack(snapshot, latest_alias=False, recommended_action=None):
    rec = recommended_action if recommended_action is not None else _recommended_action_for_snapshot(snapshot)
    return _artifact_tools.write_artifact_triage_pack(snapshot, latest_alias=latest_alias, recommended_action=rec)


def _artifact_bundle_quality(snapshot):
    return _artifact_tools.artifact_bundle_quality(snapshot)


def _build_run_id_diagnostics(snapshot, requested_run_id):
    return _artifact_tools.build_run_id_diagnostics(snapshot, requested_run_id)


def open_latest_artifact_triage_pack(repo_root, progress_callback=None):
    """Generate and return triage pack for latest run-scoped artifact set."""
    _emit_progress(progress_callback, 'building run evidence snapshot')
    ok, msg, snapshot = _build_run_artifact_snapshot(repo_root, run_id='')
    if not ok:
        return (False, msg, None)
    try:
        path = _write_artifact_triage_pack(snapshot, latest_alias=True)
        return (True, '', path)
    except Exception as e:
        return (False, str(e), None)


def open_latest_run_artifact_index(repo_root, progress_callback=None):
    """Generate and return run artifact index for latest run-scoped artifact set."""
    _emit_progress(progress_callback, 'building run evidence snapshot')
    ok, msg, snapshot = _build_run_artifact_snapshot(repo_root, run_id='')
    if not ok:
        return (False, msg, None)
    try:
        rec = _recommended_action_for_snapshot(snapshot)
        path = _write_run_artifact_index(snapshot, latest_alias=True, recommended_action=rec)
        return (True, '', path)
    except Exception as e:
        return (False, str(e), None)


def open_run_artifact_index_for_run_id(repo_root, run_id):
    """Generate and return run artifact index for explicit run_id."""
    run_id = str(run_id or '').strip()
    if not run_id:
        return (False, 'Run ID is required.', None)
    ok, msg, snapshot = _build_run_artifact_snapshot(repo_root, run_id=run_id)
    if not ok:
        lab_root = resolve_lab_root(repo_root)
        reports_dir = os.path.join(lab_root, 'reports')
        diag_snapshot = {
            'recent_run_ids': _recent_artifact_run_ids(reports_dir, limit=12),
            'nearest_complete_run_id': _find_latest_complete_artifact_run_id(reports_dir, exclude_run_id=''),
            'diagnostics_state': _load_json_dict(os.path.join(lab_root, 'diagnostics_state.json')),
        }
        diag_msg = _build_run_id_diagnostics(diag_snapshot, run_id)
        full_msg = '{0} {1}'.format(msg, diag_msg).strip()
        return (False, full_msg, None)
    try:
        rec = _recommended_action_for_snapshot(snapshot)
        path = _write_run_artifact_index(snapshot, latest_alias=False, recommended_action=rec)
        return (True, '', path)
    except Exception as e:
        return (False, str(e), None)


def _latest_phase_d_reprocess_report_paths(lab_root):
    reports_dir = os.path.join(str(lab_root or ''), 'reports')
    paths = []
    for name in (
            'phase_d_historical_reprocess_preview_latest.txt',
            'phase_d_historical_reprocess_execution_latest.txt'):
        path = os.path.join(reports_dir, name)
        if os.path.isfile(path):
            paths.append(path)
    return paths


def _parse_remediation_context_run_id_from_phase_d_report(path):
    """Return remediation_context_run_id= value from report header, or ''."""
    if not path or not os.path.isfile(path):
        return ''
    try:
        with open(path, 'r', encoding='utf-8') as f:
            for _ in range(64):
                line = f.readline()
                if not line:
                    break
                s = str(line or '').strip()
                if s.startswith('remediation_context_run_id='):
                    return s.split('=', 1)[1].strip()
    except (IOError, OSError, UnicodeError):
        pass
    return ''


def _phase_d_reprocess_report_paths_for_run_evidence(lab_root, recommendation, bundle_run_id):
    """Compatibility wrapper for _recommendation_tools._phase_d_reprocess_report_paths_for_run_evidence."""
    return _recommendation_tools._IMPL__phase_d_reprocess_report_paths_for_run_evidence(lab_root, recommendation, bundle_run_id)



def _latest_interrupt_report_paths(lab_root, bundle_run_id=None):
    """Compatibility wrapper for _recommendation_tools._latest_interrupt_report_paths."""
    return _recommendation_tools._IMPL__latest_interrupt_report_paths(lab_root, bundle_run_id)




def _write_run_evidence_dat_smoke_note(repo_root, reports_dir, bundle_run_id, recommendation, smoke_state, deferred_smoke, attached_paths):
    """Compatibility wrapper for _recommendation_tools._write_run_evidence_dat_smoke_note."""
    return _recommendation_tools._IMPL__write_run_evidence_dat_smoke_note(repo_root, reports_dir, bundle_run_id, recommendation, smoke_state, deferred_smoke, attached_paths)




def _write_run_evidence_smoke_anchor_mismatch_note(repo_root, reports_dir, bundle_run_id, reviewed_anchor, smoke_anchor, last_report_path, smoke_status='', smoke_assessment='', detail=''):
    """Compatibility wrapper for _recommendation_tools._write_run_evidence_smoke_anchor_mismatch_note."""
    return _recommendation_tools._IMPL__write_run_evidence_smoke_anchor_mismatch_note(repo_root, reports_dir, bundle_run_id, reviewed_anchor, smoke_anchor, last_report_path, smoke_status, smoke_assessment, detail)



def _phase_d_dat_smoke_report_paths_for_run_evidence(repo_root, lab_root, recommendation, bundle_run_id):
    """Compatibility wrapper for _recommendation_tools._phase_d_dat_smoke_report_paths_for_run_evidence."""
    return _recommendation_tools._IMPL__phase_d_dat_smoke_report_paths_for_run_evidence(repo_root, lab_root, recommendation, bundle_run_id)




def _write_run_evidence_context_note(reports_dir, bundle_run_id, pack_context, pack_path, pack_error=''):
    """Compatibility wrapper for _recommendation_tools._write_run_evidence_context_note."""
    return _recommendation_tools._IMPL__write_run_evidence_context_note(reports_dir, bundle_run_id, pack_context, pack_path, pack_error)



def _collect_run_evidence_context_attachment(repo_root, snapshot, progress_callback=None):
    """Compatibility wrapper for _recommendation_tools._collect_run_evidence_context_attachment."""
    return _recommendation_tools._IMPL__collect_run_evidence_context_attachment(repo_root, snapshot, progress_callback)



def _write_run_evidence_anchor_resolution_note(repo_root, lab_root, anchor_run_id, error_detail):
    """Compatibility wrapper for _recommendation_tools._write_run_evidence_anchor_resolution_note."""
    return _recommendation_tools._IMPL__write_run_evidence_anchor_resolution_note(repo_root, lab_root, anchor_run_id, error_detail)



def _review_dat_qa_full_block_forced_attachment_paths(recommendation):
    """Compatibility wrapper for _recommendation_tools._review_dat_qa_full_block_forced_attachment_paths."""
    return _recommendation_tools._IMPL__review_dat_qa_full_block_forced_attachment_paths(recommendation)



def send_latest_run_evidence_bundle(
        repo_root,
        progress_callback=None,
        send_source='manual_run_evidence_bundle',
        operator_execution_mode='explicit_send_menu',
        frozen_recommendation=None,
        support_send_job_context=None):
    """Compatibility wrapper for _recommendation_tools.send_latest_run_evidence_bundle."""
    return _recommendation_tools._IMPL_send_latest_run_evidence_bundle(
        repo_root,
        progress_callback,
        send_source,
        operator_execution_mode,
        frozen_recommendation,
        support_send_job_context,
    )



def _has_invalid_lab_root(diagnostics):
    """True if diagnostics indicate lab root is missing or not found (read-only path)."""
    codes = {str(i.get('code', '') or '').strip() for i in diagnostics.get('issues', [])}
    return bool(codes & {'LAB_ROOT_MISSING', 'LAB_ROOT_NOT_FOUND'})


def get_health_lines(lab_root, env_flag_fn):
    """Compatibility wrapper for _health_tools.get_health_lines."""
    return _health_tools._IMPL_get_health_lines(lab_root, env_flag_fn)


