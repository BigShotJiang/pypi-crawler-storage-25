import json
import os
import tempfile
import time
import calendar
import unittest

from unittest.mock import patch

from MediCafe import json_health


def _write_jsonl(path, rows):
    with open(path, 'w', encoding='utf-8') as handle:
        for row in rows:
            if isinstance(row, str):
                handle.write(row + '\n')
            else:
                handle.write(json.dumps(row) + '\n')


def _assert_no_phi_text(payload):
    text = json.dumps(payload, sort_keys=True)
    for token in ('Jane Doe', 'MEM123456', '1980-01-02', 'CHART123', 'CLAIMKEY123', 'TX123'):
        assert token not in text


def test_submission_index_scan_skips_ack_rows_and_flags_placeholder():
    tmp = tempfile.mkdtemp(prefix='mc_json_health_')
    claims_dir = os.path.join(tmp, 'claims')
    storage_dir = os.path.join(tmp, 'storage')
    os.makedirs(claims_dir)
    os.makedirs(storage_dir)
    _write_jsonl(
        os.path.join(claims_dir, 'submission_index.jsonl'),
        [
            {'record_type': 'ack_event', 'patient_name': '', 'patient_id': ''},
            {'record_type': 'submission', 'patient_name': 'unknown', 'patient_id': ''},
        ],
    )
    config = {'MediLink_Config': {'local_claims_path': claims_dir, 'local_storage_path': storage_dir}}
    summary = json_health.run_json_health_scan(
        config=config,
        artifact_keys=['submission_index'],
        persist=False,
        max_records=100,
    )
    issue_codes = [i.get('issue_code') for i in summary.get('issues') or []]
    assert 'PATIENT_NAME_PLACEHOLDER' in issue_codes
    assert summary.get('status') in ('degraded', 'error')


def test_submission_index_uses_internal_chart_as_identity_alias():
    tmp = tempfile.mkdtemp(prefix='mc_json_health_')
    claims_dir = os.path.join(tmp, 'claims')
    storage_dir = os.path.join(tmp, 'storage')
    os.makedirs(claims_dir)
    os.makedirs(storage_dir)
    _write_jsonl(
        os.path.join(claims_dir, 'submission_index.jsonl'),
        [{'record_type': 'submission', 'patient_name': 'Jane Smith', 'patient_id': '', 'internal_chart': 'CH123'}],
    )
    config = {'MediLink_Config': {'local_claims_path': claims_dir, 'local_storage_path': storage_dir}}
    summary = json_health.run_json_health_scan(
        config=config,
        artifact_keys=['submission_index'],
        persist=False,
        max_records=100,
    )
    issue_codes = [i.get('issue_code') for i in summary.get('issues') or []]
    assert 'PATIENT_ID_MISSING' not in issue_codes


def test_append_submission_record_backfills_identity_but_ack_exempt():
    from MediCafe.submission_index import append_submission_record

    tmp = tempfile.mkdtemp(prefix='mc_json_health_')
    claims_dir = os.path.join(tmp, 'claims')
    os.makedirs(claims_dir)
    append_submission_record(claims_dir, {
        'record_type': 'submission',
        'claim_key': 'CHART9|62308|20260409|file.dat',
        'member_first_name': 'Jane',
        'member_last_name': 'Smith',
    })
    append_submission_record(claims_dir, {
        'record_type': 'ack_event',
        'notes': 'ack event',
        'claim_key': '',
    })

    with open(os.path.join(claims_dir, 'submission_index.jsonl'), 'r') as handle:
        rows = [json.loads(line) for line in handle if line.strip()]
    assert rows[0].get('patient_id') == 'CHART9'
    assert rows[0].get('internal_chart') == 'CHART9'
    assert rows[0].get('payer_id') == '62308'
    assert rows[0].get('dos') == '20260409'
    assert rows[0].get('patient_name') == 'Jane Smith'
    assert rows[1].get('patient_id') in (None, '')


def test_optional_missing_artifact_does_not_force_error():
    tmp = tempfile.mkdtemp(prefix='mc_json_health_')
    claims_dir = os.path.join(tmp, 'claims')
    storage_dir = os.path.join(tmp, 'storage')
    os.makedirs(claims_dir)
    os.makedirs(storage_dir)
    _write_jsonl(
        os.path.join(claims_dir, 'submission_index.jsonl'),
        [{'record_type': 'submission', 'patient_name': 'Jane Smith', 'patient_id': 'ABC123'}],
    )
    config = {'MediLink_Config': {'local_claims_path': claims_dir, 'local_storage_path': storage_dir}}
    summary = json_health.run_json_health_scan(
        config=config,
        artifact_keys=['submission_index', 'remittance_parsed'],
        persist=False,
        max_records=100,
    )
    assert summary.get('status') != 'error'


def test_support_attachment_omits_phi_fields():
    attachment = json_health.build_json_health_support_attachment(
        {
            'scan_id': '1',
            'scanned_at_utc': '2026-01-01T00:00:00Z',
            'status': 'degraded',
            'artifact_count': 1,
            'warning_count': 1,
            'error_count': 0,
            'issues': [
                {
                    'artifact_key': 'submission_index',
                    'artifact_basename': 'submission_index.jsonl',
                    'issue_code': 'PATIENT_ID_MISSING',
                    'severity': 'warning',
                    'count': 2,
                    'sample_refs': ['line:9'],
                    'patient_name': 'SHOULD_NOT_APPEAR',
                    'patient_id': 'SHOULD_NOT_APPEAR',
                }
            ],
            'artifact_diagnostics': [],
        }
    )
    issue = attachment['issues'][0]
    assert issue['issue_code'] == 'PATIENT_ID_MISSING'
    assert 'patient_name' not in issue
    assert 'patient_id' not in issue


def test_required_submission_index_missing_sets_global_missing():
    tmp = tempfile.mkdtemp(prefix='mc_json_health_')
    claims_dir = os.path.join(tmp, 'claims')
    storage_dir = os.path.join(tmp, 'storage')
    os.makedirs(claims_dir)
    os.makedirs(storage_dir)
    config = {'MediLink_Config': {'local_claims_path': claims_dir, 'local_storage_path': storage_dir}}
    summary = json_health.run_json_health_scan(
        config=config,
        artifact_keys=['submission_index'],
        persist=False,
        max_records=100,
    )
    assert summary.get('status') == 'missing'


def test_optional_unreadable_remittance_degrades_not_errors():
    tmp = tempfile.mkdtemp(prefix='mc_json_health_')
    claims_dir = os.path.join(tmp, 'claims')
    storage_dir = os.path.join(tmp, 'storage')
    os.makedirs(claims_dir)
    os.makedirs(storage_dir)
    _write_jsonl(
        os.path.join(claims_dir, 'submission_index.jsonl'),
        [{'record_type': 'submission', 'patient_name': 'Jane Smith', 'patient_id': 'ABC123'}],
    )
    os.makedirs(os.path.join(storage_dir, 'remittance_parsed.jsonl'))
    config = {'MediLink_Config': {'local_claims_path': claims_dir, 'local_storage_path': storage_dir}}
    summary = json_health.run_json_health_scan(
        config=config,
        artifact_keys=['submission_index', 'remittance_parsed'],
        persist=False,
        max_records=100,
    )
    assert summary.get('status') == 'degraded'
    assert summary.get('error_count') == 0


def test_get_latest_json_health_attachment_omits_stale_ok_snapshot():
    tmp = tempfile.mkdtemp(prefix='mc_json_health_')
    storage_dir = os.path.join(tmp, 'storage')
    telemetry_dir = os.path.join(storage_dir, 'telemetry')
    os.makedirs(telemetry_dir)
    snapshot_path = os.path.join(telemetry_dir, 'json_health_snapshot.json')
    with open(snapshot_path, 'w', encoding='utf-8') as handle:
        json.dump({
            'scan_id': 'old-ok',
            'scanned_at_utc': '2026-01-01T00:00:00Z',
            'status': 'ok',
            'artifact_count': 1,
            'warning_count': 0,
            'error_count': 0,
            'issues': [],
            'artifact_diagnostics': [],
        }, handle)
    stale_time = time.time() - (48 * 60 * 60)
    os.utime(snapshot_path, (stale_time, stale_time))
    config = {'MediLink_Config': {'local_storage_path': storage_dir}}
    assert json_health.get_latest_json_health_attachment(config=config) is None


def test_get_latest_json_health_attachment_keeps_stale_degraded_snapshot():
    tmp = tempfile.mkdtemp(prefix='mc_json_health_')
    storage_dir = os.path.join(tmp, 'storage')
    telemetry_dir = os.path.join(storage_dir, 'telemetry')
    os.makedirs(telemetry_dir)
    snapshot_path = os.path.join(telemetry_dir, 'json_health_snapshot.json')
    with open(snapshot_path, 'w', encoding='utf-8') as handle:
        json.dump({
            'scan_id': 'old-degraded',
            'scanned_at_utc': '2026-01-01T00:00:00Z',
            'status': 'degraded',
            'artifact_count': 1,
            'warning_count': 1,
            'error_count': 0,
            'issues': [],
            'artifact_diagnostics': [],
        }, handle)
    stale_time = time.time() - (48 * 60 * 60)
    os.utime(snapshot_path, (stale_time, stale_time))
    config = {'MediLink_Config': {'local_storage_path': storage_dir}}
    attachment = json_health.get_latest_json_health_attachment(config=config)
    assert attachment is not None
    name, payload = attachment
    assert name == 'json_health_snapshot.json'
    assert payload.get('status') == 'degraded'
    assert isinstance(payload.get('snapshot_age_seconds'), int)


def test_get_latest_json_health_attachment_prefers_partial_snapshot_over_stale_full_history():
    tmp = tempfile.mkdtemp(prefix='mc_json_health_')
    storage_dir = os.path.join(tmp, 'storage')
    telemetry_dir = os.path.join(storage_dir, 'telemetry')
    os.makedirs(telemetry_dir)
    snapshot_path = os.path.join(telemetry_dir, 'json_health_snapshot.json')
    history_path = os.path.join(telemetry_dir, 'json_health_history.jsonl')
    with open(snapshot_path, 'w', encoding='utf-8') as handle:
        json.dump({
            'scan_id': 'partial-scan',
            'scan_scope': 'partial',
            'artifact_keys': ['submission_index'],
            'scanned_at_utc': '2026-01-01T00:00:00Z',
            'status': 'ok',
            'artifact_count': 1,
            'warning_count': 0,
            'error_count': 0,
            'issues': [],
            'artifact_diagnostics': [],
        }, handle)
    with open(history_path, 'w', encoding='utf-8') as handle:
        handle.write(json.dumps({
            'scan_id': 'full-scan',
            'scan_scope': 'full',
            'artifact_keys': ['submission_index', 'remittance_parsed'],
            'scanned_at_utc': '2026-01-01T00:10:00Z',
            'status': 'degraded',
            'artifact_count': 2,
            'warning_count': 1,
            'error_count': 0,
            'issues': [],
            'artifact_diagnostics': [],
        }) + '\n')
    config = {'MediLink_Config': {'local_storage_path': storage_dir}}
    attachment = json_health.get_latest_json_health_attachment(config=config)
    assert attachment is not None
    _name, payload = attachment
    assert payload.get('scan_id') == 'partial-scan'
    assert payload.get('scan_scope') == 'partial'
    assert payload.get('snapshot_source') == 'snapshot'


def test_get_latest_json_health_attachment_omits_stale_ok_full_history_fallback():
    tmp = tempfile.mkdtemp(prefix='mc_json_health_')
    storage_dir = os.path.join(tmp, 'storage')
    telemetry_dir = os.path.join(storage_dir, 'telemetry')
    os.makedirs(telemetry_dir)
    snapshot_path = os.path.join(telemetry_dir, 'json_health_snapshot.json')
    history_path = os.path.join(telemetry_dir, 'json_health_history.jsonl')
    with open(snapshot_path, 'w', encoding='utf-8') as handle:
        json.dump({
            'scan_id': 'partial-scan',
            'scan_scope': 'partial',
            'artifact_keys': ['submission_index'],
            'scanned_at_utc': '2026-01-01T00:00:00Z',
            'status': 'degraded',
            'artifact_count': 1,
            'warning_count': 1,
            'error_count': 0,
            'issues': [],
            'artifact_diagnostics': [],
        }, handle)
    with open(history_path, 'w', encoding='utf-8') as handle:
        handle.write(json.dumps({
            'scan_id': 'full-stale-ok',
            'scan_scope': 'full',
            'artifact_keys': ['submission_index', 'remittance_parsed'],
            'scanned_at_utc': '2020-01-01T00:00:00Z',
            'status': 'ok',
            'artifact_count': 2,
            'warning_count': 0,
            'error_count': 0,
            'issues': [],
            'artifact_diagnostics': [],
        }) + '\n')
    config = {'MediLink_Config': {'local_storage_path': storage_dir}}
    attachment = json_health.get_latest_json_health_attachment(config=config)
    assert attachment is not None
    _name, payload = attachment
    assert payload.get('scan_id') == 'partial-scan'
    assert payload.get('scan_scope') == 'partial'
    assert payload.get('snapshot_source') == 'snapshot'


def test_get_latest_json_health_attachment_prefers_fresh_partial_over_stale_full_degraded():
    tmp = tempfile.mkdtemp(prefix='mc_json_health_')
    storage_dir = os.path.join(tmp, 'storage')
    telemetry_dir = os.path.join(storage_dir, 'telemetry')
    os.makedirs(telemetry_dir)
    snapshot_path = os.path.join(telemetry_dir, 'json_health_snapshot.json')
    history_path = os.path.join(telemetry_dir, 'json_health_history.jsonl')
    with open(snapshot_path, 'w', encoding='utf-8') as handle:
        json.dump({
            'scan_id': 'partial-fresh',
            'scan_scope': 'partial',
            'artifact_keys': ['submission_index'],
            'scanned_at_utc': '2026-01-01T00:00:00Z',
            'status': 'degraded',
            'artifact_count': 1,
            'warning_count': 1,
            'error_count': 0,
            'issues': [],
            'artifact_diagnostics': [],
        }, handle)
    with open(history_path, 'w', encoding='utf-8') as handle:
        handle.write(json.dumps({
            'scan_id': 'full-stale-degraded',
            'scan_scope': 'full',
            'artifact_keys': ['submission_index', 'remittance_parsed'],
            'scanned_at_utc': '2020-01-01T00:00:00Z',
            'status': 'degraded',
            'artifact_count': 2,
            'warning_count': 3,
            'error_count': 0,
            'issues': [],
            'artifact_diagnostics': [],
        }) + '\n')
    config = {'MediLink_Config': {'local_storage_path': storage_dir}}
    attachment = json_health.get_latest_json_health_attachment(config=config)
    assert attachment is not None
    _name, payload = attachment
    assert payload.get('scan_id') == 'partial-fresh'
    assert payload.get('snapshot_source') == 'snapshot'


def test_get_latest_json_health_attachment_uses_full_history_when_snapshot_missing():
    tmp = tempfile.mkdtemp(prefix='mc_json_health_')
    storage_dir = os.path.join(tmp, 'storage')
    telemetry_dir = os.path.join(storage_dir, 'telemetry')
    os.makedirs(telemetry_dir)
    history_path = os.path.join(telemetry_dir, 'json_health_history.jsonl')
    with open(history_path, 'w', encoding='utf-8') as handle:
        handle.write(json.dumps({
            'scan_id': 'full-history-only',
            'scan_scope': 'full',
            'artifact_keys': ['submission_index', 'remittance_parsed'],
            'scanned_at_utc': '2026-01-01T00:00:00Z',
            'status': 'degraded',
            'artifact_count': 2,
            'warning_count': 1,
            'error_count': 0,
            'issues': [],
            'artifact_diagnostics': [],
        }) + '\n')
    config = {'MediLink_Config': {'local_storage_path': storage_dir}}
    attachment = json_health.get_latest_json_health_attachment(config=config)
    assert attachment is not None
    _name, payload = attachment
    assert payload.get('scan_id') == 'full-history-only'
    assert payload.get('snapshot_source') == 'history_full_fallback'


def test_summary_age_seconds_uses_utc_epoch_for_zulu_timestamp():
    original_time = json_health.time.time
    try:
        expected_now = float(calendar.timegm((2026, 1, 2, 0, 0, 0)))
        json_health.time.time = lambda: expected_now
        age = json_health._summary_age_seconds({'scanned_at_utc': '2026-01-01T00:00:00Z'}, mtime=None)
    finally:
        json_health.time.time = original_time
    assert age == 86400


def test_new_scan_id_is_unique_when_time_is_pinned():
    original_time = json_health.time.time
    try:
        json_health.time.time = lambda: 1770000000.0
        a = json_health._new_scan_id()
        b = json_health._new_scan_id()
    finally:
        json_health.time.time = original_time
    assert a != b


def test_phi_tokens_not_present_in_notice_log_or_support_attachment():
    summary = {
        'scan_id': 'scan-1',
        'scanned_at_utc': '2026-01-01T00:00:00Z',
        'status': 'degraded',
        'artifact_count': 1,
        'warning_count': 1,
        'error_count': 0,
        'required_warning_count': 1,
        'required_missing_count': 0,
        'optional_missing_count': 0,
        'issues': [{
            'artifact_key': 'submission_index',
            'artifact_basename': 'submission_index.jsonl',
            'issue_code': 'PATIENT_ID_MISSING',
            'severity': 'warning',
            'count': 1,
            'sample_refs': ['line:3'],
            'patient_name': 'Jane Doe',
            'member_id': 'MEM123456',
            'dob': '1980-01-02',
            'claim_key': 'CLAIMKEY123',
            'transactionId': 'TX123',
        }],
        'artifact_diagnostics': [],
    }
    notice = json_health.build_json_health_notice(summary)
    log_line = json_health.format_json_health_log_line(summary)
    attachment = json_health.build_json_health_support_attachment(summary)
    _assert_no_phi_text(notice or {})
    _assert_no_phi_text({'log_line': log_line})
    _assert_no_phi_text(attachment)


def test_scan_error_diagnostics_are_sanitized():
    tmp = tempfile.mkdtemp(prefix='mc_json_health_')
    claims_dir = os.path.join(tmp, 'claims')
    storage_dir = os.path.join(tmp, 'storage')
    os.makedirs(claims_dir)
    os.makedirs(storage_dir)
    os.makedirs(os.path.join(claims_dir, 'submission_index.jsonl'))
    config = {'MediLink_Config': {'local_claims_path': claims_dir, 'local_storage_path': storage_dir}}
    summary = json_health.run_json_health_scan(
        config=config,
        artifact_keys=['submission_index'],
        persist=False,
        max_records=10,
    )
    diag = (summary.get('artifact_diagnostics') or [{}])[0]
    assert diag.get('status') == 'error'
    assert diag.get('error')
    assert os.path.sep not in str(diag.get('error') or '')
    attachment = json_health.build_json_health_support_attachment(summary)
    _assert_no_phi_text(attachment)


def test_scan_limit_caps_lines_read_for_filtered_rows():
    tmp = tempfile.mkdtemp(prefix='mc_json_health_')
    claims_dir = os.path.join(tmp, 'claims')
    storage_dir = os.path.join(tmp, 'storage')
    os.makedirs(claims_dir)
    os.makedirs(storage_dir)
    rows = []
    for _ in range(300):
        rows.append({'record_type': 'ack_event', 'patient_name': '', 'patient_id': ''})
    _write_jsonl(os.path.join(claims_dir, 'submission_index.jsonl'), rows)
    config = {'MediLink_Config': {'local_claims_path': claims_dir, 'local_storage_path': storage_dir}}
    summary = json_health.run_json_health_scan(
        config=config,
        artifact_keys=['submission_index'],
        persist=False,
        max_records=10,
    )
    diag = (summary.get('artifact_diagnostics') or [{}])[0]
    assert diag.get('scan_limit_hit') is True
    assert int(diag.get('lines_read') or 0) <= 50


def test_sanitize_jsonl_file_drops_invalid_lines():
    tmp = tempfile.mkdtemp(prefix='mc_json_health_')
    path = os.path.join(tmp, 'ledger.jsonl')
    with open(path, 'w', encoding='utf-8') as handle:
        handle.write('{"a":1}\n')
        handle.write('not json at all\n')
        handle.write('{"b":2}\n')
    res = json_health.sanitize_jsonl_file(path, backup=False)
    assert res.get('ok') is True
    assert res.get('changed') is True
    assert int(res.get('lines_dropped') or 0) == 1
    with open(path, 'r', encoding='utf-8') as handle:
        kept = [json.loads(x.strip()) for x in handle if x.strip()]
    assert len(kept) == 2
    assert kept[0].get('a') == 1
    assert kept[1].get('b') == 2


def test_sanitize_clears_invalid_lines_in_submission_index_scan():
    tmp = tempfile.mkdtemp(prefix='mc_json_health_')
    claims_dir = os.path.join(tmp, 'claims')
    storage_dir = os.path.join(tmp, 'storage')
    os.makedirs(claims_dir)
    os.makedirs(storage_dir)
    idx_path = os.path.join(claims_dir, 'submission_index.jsonl')
    with open(idx_path, 'w', encoding='utf-8') as handle:
        handle.write(json.dumps({'record_type': 'submission', 'patient_name': 'Jane Smith', 'patient_id': 'X'}) + '\n')
        handle.write('{{{broken json' + '\n')
    config = {'MediLink_Config': {'local_claims_path': claims_dir, 'local_storage_path': storage_dir}}
    s1 = json_health.run_json_health_scan(
        config=config,
        artifact_keys=['submission_index'],
        persist=False,
        max_records=100,
    )
    d1 = (s1.get('artifact_diagnostics') or [{}])[0]
    assert int(d1.get('invalid_lines') or 0) >= 1
    json_health.sanitize_jsonl_artifacts_for_config(config, artifact_keys=['submission_index'], backup=False)
    s2 = json_health.run_json_health_scan(
        config=config,
        artifact_keys=['submission_index'],
        persist=False,
        max_records=100,
    )
    d2 = (s2.get('artifact_diagnostics') or [{}])[0]
    assert int(d2.get('invalid_lines') or 0) == 0


def test_auto_repair_runs_by_default_when_invalid_lines():
    tmp = tempfile.mkdtemp(prefix='mc_json_health_')
    claims_dir = os.path.join(tmp, 'claims')
    storage_dir = os.path.join(tmp, 'storage')
    os.makedirs(claims_dir)
    os.makedirs(storage_dir)
    idx_path = os.path.join(claims_dir, 'submission_index.jsonl')
    with open(idx_path, 'w', encoding='utf-8') as handle:
        handle.write(json.dumps({'record_type': 'submission', 'patient_name': 'Jane Smith', 'patient_id': 'X'}) + '\n')
        handle.write('not-json' + '\n')
    config = {'MediLink_Config': {'local_claims_path': claims_dir, 'local_storage_path': storage_dir}}
    telem = os.path.join(storage_dir, 'telemetry')
    os.makedirs(telem, exist_ok=True)
    summary = json_health.run_json_health_scan(
        config=config,
        artifact_keys=['submission_index'],
        persist=True,
        max_records=100,
    )
    d = (summary.get('artifact_diagnostics') or [{}])[0]
    assert int(d.get('invalid_lines') or 0) == 0
    with open(idx_path, 'r', encoding='utf-8') as handle:
        text = handle.read()
    assert 'not-json' not in text


def test_auto_repair_skipped_when_env_disables():
    tmp = tempfile.mkdtemp(prefix='mc_json_health_')
    claims_dir = os.path.join(tmp, 'claims')
    storage_dir = os.path.join(tmp, 'storage')
    os.makedirs(claims_dir)
    os.makedirs(storage_dir)
    idx_path = os.path.join(claims_dir, 'submission_index.jsonl')
    with open(idx_path, 'w', encoding='utf-8') as handle:
        handle.write(json.dumps({'record_type': 'submission', 'patient_name': 'Jane Smith', 'patient_id': 'X'}) + '\n')
        handle.write('not-json' + '\n')
    config = {'MediLink_Config': {'local_claims_path': claims_dir, 'local_storage_path': storage_dir}}
    os.makedirs(os.path.join(storage_dir, 'telemetry'), exist_ok=True)
    with patch.dict(os.environ, {'MEDICAFE_JSON_HEALTH_AUTO_REPAIR': '0'}):
        summary = json_health.run_json_health_scan(
            config=config,
            artifact_keys=['submission_index'],
            persist=True,
            max_records=100,
        )
    d = (summary.get('artifact_diagnostics') or [{}])[0]
    assert int(d.get('invalid_lines') or 0) >= 1
    with open(idx_path, 'r', encoding='utf-8') as handle:
        text = handle.read()
    assert 'not-json' in text


def test_scan_scope_full_when_phase1_artifacts_are_requested_with_duplicates():
    tmp = tempfile.mkdtemp(prefix='mc_json_health_')
    claims_dir = os.path.join(tmp, 'claims')
    storage_dir = os.path.join(tmp, 'storage')
    os.makedirs(claims_dir)
    os.makedirs(storage_dir)
    _write_jsonl(
        os.path.join(claims_dir, 'submission_index.jsonl'),
        [{'record_type': 'submission', 'patient_name': 'Jane Smith', 'patient_id': 'ABC123'}],
    )
    _write_jsonl(
        os.path.join(storage_dir, 'remittance_parsed.jsonl'),
        [{'patient_name': 'Jane Smith', 'patient_id': 'ABC123', 'data_source': 'parsed_file', 'schema_version': 1}],
    )
    config = {'MediLink_Config': {'local_claims_path': claims_dir, 'local_storage_path': storage_dir}}
    summary = json_health.run_json_health_scan(
        config=config,
        artifact_keys=['submission_index', 'submission_index', 'remittance_parsed'],
        persist=False,
        max_records=100,
    )
    assert summary.get('scan_scope') == 'full'


def load_tests(loader, tests, pattern):
    suite = unittest.TestSuite()
    suite.addTests(tests)
    for name in sorted(globals().keys()):
        value = globals().get(name)
        if name.startswith('test_') and callable(value):
            code = getattr(value, '__code__', None)
            if code is not None and int(code.co_argcount) == 0:
                suite.addTest(unittest.FunctionTestCase(value))
    return suite
