import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/api': {
        target: 'http://localhost:8000',
        ws: true,
      },
    },
  },
  build: {
    rollupOptions: {
      output: {
        manualChunks: {
          'vendor-react': ['react', 'react-dom'],
          'vendor-cytoscape': ['cytoscape'],
          'vendor-icons': [
            '@fortawesome/react-fontawesome',
            '@fortawesome/free-solid-svg-icons',
          ],
        },
      },
    },
  },
})
