"""Side-effect-free recall wrapper for threshold tuning.

Key properties:
- Loads the MemorySystem (and Gemma embedder) ONCE per process. Subsequent
  trials swap only the RecallEngine.config to change thresholds. Avoids
  ~100s Gemma reload per trial.
- `store.increment_access` is monkey-patched to no-op during training so
  access_count does not drift across trials.
- Uses a dedicated MemorySystem instance (not Phoenix's default singleton),
  so live Phoenix can run concurrently with training if desired.

The 5 MVP tunables, with names, default, and search bounds:

    relevance_gate_threshold  (0.275, [0.15, 0.45])  -- query-doc direct sim gate
    min_relevance             (0.192, [0.05, 0.30])  -- composite score floor
    pinned_boost              (1.15,  [1.00, 1.50])  -- multiplier for pinned memories
    recency_weight            (0.2,   [0.0, 0.5])    -- weight of recency vs relevance
    strength_compression      (0.3,   [0.1, 0.7])    -- exponent on memory strength

With ordering constraint: min_relevance <= relevance_gate_threshold.
Enforced via delta re-parameterization in the optimizer.
"""

from __future__ import annotations

from dataclasses import replace
from pathlib import Path
from typing import Any

from phoenix.memory import MemorySystem
from phoenix.memory.config import MemoryParams

TUNABLE_FIELDS = (
    "relevance_gate_threshold",
    "min_relevance",
    "pinned_boost",
    "recency_weight",
    "strength_compression",
)

# Search space for Optuna. Ordering: min_relevance <= relevance_gate_threshold
# is enforced at the optimizer layer via delta re-parameterization.
SEARCH_SPACE = {
    "relevance_gate_threshold": (0.15, 0.45),
    "min_relevance": (0.05, 0.30),
    "pinned_boost": (1.00, 1.50),
    "recency_weight": (0.0, 0.5),
    "strength_compression": (0.1, 0.7),
}


def _load_env_file(path: Path) -> None:
    """Minimal .env loader for HF_TOKEN, GEMINI_API_KEY etc."""
    import os

    if not path.exists():
        return
    for raw in path.read_text().splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, _, v = line.partition("=")
        k = k.strip()
        v = v.strip().strip('"').strip("'")
        if k and k not in os.environ:
            os.environ[k] = v


class RecallRunner:
    """Loads MemorySystem once, runs side-effect-free recall with swappable thresholds."""

    def __init__(self, db_path: str | None = None, env_file: Path | None = None):
        # Default env_file to the repo root .env so PHOENIX_MEMORY_DB and HF_TOKEN
        # are picked up without callers wiring it manually.
        if env_file is None:
            env_file = Path(__file__).resolve().parent.parent / ".env"
        _load_env_file(env_file)
        import os

        if db_path:
            os.environ["PHOENIX_MEMORY_DB"] = db_path
        # Force gemma backend (the tunable thresholds are calibrated for Gemma space)
        os.environ.setdefault("PHOENIX_EMBEDDING_BACKEND", "gemma")

        self._memory = MemorySystem()
        self._memory._ensure_initialized()

        # Disable side effects during training.
        self._memory.store.increment_access = lambda _mid: None  # type: ignore[method-assign]

        self._base_config: MemoryParams = self._memory.config

    @property
    def base_config(self) -> MemoryParams:
        return self._base_config

    def recall(
        self,
        query: str,
        thresholds: dict[str, float],
        top_k: int = 5,
        namespace: str = "global",
    ) -> list[dict[str, Any]]:
        """Run recall with a candidate threshold set. Returns top-K memory dicts."""
        # Build a candidate config by replacing only the tunable fields.
        candidate = replace(self._base_config, **thresholds)

        # Swap the recall engine's config. The embedder and store stay shared.
        self._memory._recall.config = candidate

        # Fresh context vector per query to avoid EMA leakage across trials.
        # (Matches MCP bridge behavior: each tool call is independent.)
        self._memory._recall._context_vector = None
        self._memory._recall.update_context(query)

        results = self._memory._recall.recall(query, namespace=namespace, top_k=top_k)

        # Restore base config so other code paths (e.g. warm-up queries) don't drift.
        self._memory._recall.config = self._base_config

        return results

    def recall_batch(
        self,
        queries: list[str],
        thresholds: dict[str, float],
        top_k: int = 5,
    ) -> list[list[dict[str, Any]]]:
        """Batch helper -- one set of thresholds applied to a list of queries."""
        return [self.recall(q, thresholds, top_k=top_k) for q in queries]
