"""Slash commands for the Phoenix shell."""

from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

from phoenix.shell.display import BOLD, BRIGHT_BLACK, CYAN, DIM, GREEN, RED, RESET, YELLOW


@dataclass
class CommandContext:
    history: list
    turn_count: int = 0
    usage_total: dict = field(default_factory=lambda: {"input": 0, "output": 0})
    save_fn: Callable | None = None
    engine: Any = None


def cmd_help(args: str, ctx: CommandContext) -> str:
    return (
        f"{BOLD}Commands{RESET}\n"
        f"\n"
        f"  {CYAN}/help{RESET}       Show this help\n"
        f"  {CYAN}/about{RESET}      Version, config, system info\n"
        f"  {CYAN}/setup{RESET}      Reconfigure model and API key\n"
        f"\n"
        f"  {CYAN}/tools{RESET}      List available abilities\n"
        f"  {CYAN}/agents{RESET}     List available agents\n"
        f"  {CYAN}/model{RESET}      Show or switch model\n"
        f"  {CYAN}/mode{RESET}       Approval mode (safe/auto/yolo)\n"
        f"  {CYAN}/memory{RESET}     Memory stats\n"
        f"\n"
        f"  {CYAN}/sessions{RESET}   List saved sessions\n"
        f"  {CYAN}/history{RESET}    Message count\n"
        f"  {CYAN}/cost{RESET}       Token usage\n"
        f"  {CYAN}/logs{RESET}       Show recent log entries (optional: /logs 50)\n"
        f"  {CYAN}/clear{RESET}      Clear conversation\n"
        f"  {CYAN}/bye{RESET}        Exit (or Ctrl+D)\n"
    )


def cmd_clear(args: str, ctx: CommandContext) -> str:
    ctx.history.clear()
    ctx.turn_count = 0
    return f"{GREEN}History cleared.{RESET}"


def cmd_history(args: str, ctx: CommandContext) -> str:
    return f"{len(ctx.history)} messages in history, {ctx.turn_count} turns."


def cmd_model(args: str, ctx: CommandContext) -> str:
    from phoenix.config.settings import get_model, get_provider, set_model

    if not args:
        model = get_model()
        return f"Current model: {BOLD}{model}{RESET} (provider: {get_provider()})"
    set_model(args.strip())
    return f"Model switched to: {BOLD}{args.strip()}{RESET}"


def cmd_cost(args: str, ctx: CommandContext) -> str:
    inp = ctx.usage_total.get("input", 0)
    out = ctx.usage_total.get("output", 0)
    total = inp + out
    return (
        f"Session tokens: {total:,}\n"
        f"  Input:  {inp:,}\n"
        f"  Output: {out:,}\n"
        f"  Turns:  {ctx.turn_count}"
    )


def cmd_tools(args: str, ctx: CommandContext) -> str:
    if not ctx.engine:
        return "Engine not available."
    abilities = ctx.engine.registry.list_abilities()
    if not abilities:
        return "No abilities discovered."
    lines = [f"{BOLD}Abilities ({len(abilities)}){RESET}"]
    for name in abilities:
        info = ctx.engine.registry.get_ability(name)
        desc = info.description if info else ""
        lines.append(f"  {CYAN}{name}{RESET} {DIM}{desc}{RESET}")
    return "\n".join(lines)


def cmd_agents(args: str, ctx: CommandContext) -> str:
    if not ctx.engine:
        return "Engine not available."
    agents = ctx.engine.registry.list_agents()
    if not agents:
        return "No agents discovered."
    lines = [f"{BOLD}Agents ({len(agents)}){RESET}"]
    for name in agents:
        config = ctx.engine.registry.get_agent_config(name)
        role = config.role if config else ""
        lines.append(f"  {CYAN}{name}{RESET} {DIM}{role}{RESET}")
    return "\n".join(lines)


def cmd_sessions(args: str, ctx: CommandContext) -> str:
    from phoenix.shell.session import SessionManager

    sessions = SessionManager.list_sessions()
    if not sessions:
        return "No saved sessions."
    lines = [f"{BOLD}Recent sessions{RESET}"]
    for s in sessions[:10]:
        sid = s.get("session_id", "?")[:12]
        count = s.get("message_count", 0)
        active = s.get("last_active", "?")[:19]
        lines.append(f"  {CYAN}{sid}{RESET}  {count:>4} msgs  {DIM}{active}{RESET}")
    if len(sessions) > 10:
        lines.append(f"  {DIM}... and {len(sessions) - 10} more{RESET}")
    return "\n".join(lines)


def cmd_mode(args: str, ctx: CommandContext) -> str:
    from phoenix.core.interceptor import (
        AutoApprovalBackend,
        CLIApprovalBackend,
        get_approval_backend,
        set_approval_backend,
    )

    if not args:
        backend = get_approval_backend()
        mode = backend.mode if isinstance(backend, AutoApprovalBackend) else "safe"
        color = RED if mode == "yolo" else YELLOW if mode == "auto" else GREEN
        return f"Approval mode: {color}{mode}{RESET}"

    mode = args.strip().lower()
    if mode == "safe":
        set_approval_backend(CLIApprovalBackend())
    elif mode in ("auto", "yolo"):
        set_approval_backend(AutoApprovalBackend(mode))
    else:
        return f"Unknown mode '{mode}'. Use: safe, auto, yolo"
    color = RED if mode == "yolo" else YELLOW if mode == "auto" else GREEN
    return f"Switched to: {color}{mode}{RESET}"


def cmd_memory(args: str, ctx: CommandContext) -> str:
    if not ctx.engine or not ctx.engine._memory:
        return "Memory system not available."
    stats = ctx.engine._memory.stats()
    lines = [f"{BOLD}Memory Stats{RESET}"]
    lines.append(f"  Total memories: {stats['total']}")
    lines.append(f"  Pinned: {stats['pinned']}")
    lines.append(f"  Clusters: {stats['clusters']}")
    lines.append(f"  Graph edges: {stats['edge_count']}")
    lines.append(f"  Episodes: {stats['episodes']}")
    lines.append(f"  Avg strength: {stats['avg_strength']}")
    if stats.get("by_category"):
        cats = ", ".join(f"{k}:{v}" for k, v in stats["by_category"].items())
        lines.append(f"  Categories: {cats}")
    if stats.get("by_namespace"):
        nss = ", ".join(f"{k}:{v}" for k, v in stats["by_namespace"].items())
        lines.append(f"  Namespaces: {nss}")
    return "\n".join(lines)


def cmd_ambient(args: str, ctx: CommandContext) -> str:
    return f"{DIM}Ambient daemon runs in background. Status available at startup.{RESET}"


def cmd_voice(args: str, ctx: CommandContext) -> str:
    msg = "Voice requires --voice flag at startup. Install: pip install phoenix-os[voice]"
    return f"{DIM}{msg}{RESET}"


def cmd_logs(args: str, ctx: CommandContext) -> str:
    from phoenix.logging_setup import LOG_FILE, tail

    try:
        n = int(args.strip()) if args.strip() else 20
    except ValueError:
        n = 20

    lines = tail(n)
    return (
        f"{BOLD}Log file:{RESET} {LOG_FILE}\n"
        f"{DIM}(last {n} lines -- pass a number to /logs for more, or quit and run `phoenix --logs`){RESET}\n"
        f"{BRIGHT_BLACK}{'-' * 60}{RESET}\n"
        f"{lines}"
    )


def cmd_setup(args: str, ctx: CommandContext) -> str:
    return (
        f"{YELLOW}Setup runs on a fresh terminal before the TUI starts.{RESET}\n"
        f"  Quit Phoenix ({CYAN}/bye{RESET} or {CYAN}Ctrl+D{RESET}) "
        f"and run: {BOLD}phoenix --setup{RESET}\n"
        f"\n"
        f"  In-session you can still use: "
        f"{CYAN}/model <name>{RESET}, {CYAN}/mode safe|auto|yolo{RESET}"
    )


def cmd_about(args: str, ctx: CommandContext) -> str:
    import platform

    from phoenix import __version__
    from phoenix.config.settings import PHOENIX_DIR, get_model, get_provider

    model = get_model()
    provider = get_provider()
    mode = "safe"
    from phoenix.core.interceptor import AutoApprovalBackend, get_approval_backend

    backend = get_approval_backend()
    if isinstance(backend, AutoApprovalBackend):
        mode = backend.mode

    lines = [
        f"{BOLD}Phoenix{RESET} v{__version__}",
        "",
        f"  {BRIGHT_BLACK}Model{RESET}       {model}",
        f"  {BRIGHT_BLACK}Provider{RESET}    {provider}",
        f"  {BRIGHT_BLACK}Mode{RESET}        {mode}",
        f"  {BRIGHT_BLACK}Data dir{RESET}    {PHOENIX_DIR}",
        f"  {BRIGHT_BLACK}Platform{RESET}    {platform.system()} {platform.machine()}",
        f"  {BRIGHT_BLACK}Python{RESET}      {platform.python_version()}",
    ]

    if ctx.engine:
        n_ab = len(ctx.engine.registry.list_abilities())
        n_ag = len(ctx.engine.registry.list_agents())
        lines.append(f"  {BRIGHT_BLACK}Abilities{RESET}   {n_ab}")
        lines.append(f"  {BRIGHT_BLACK}Agents{RESET}      {n_ag}")

    if ctx.engine and ctx.engine._memory:
        stats = ctx.engine._memory.stats()
        lines.append(f"  {BRIGHT_BLACK}Memories{RESET}    {stats.get('total', 0)}")

    lines.append("")
    lines.append(f"  {BRIGHT_BLACK}GitHub{RESET}      https://github.com/harshalmore31/phoenix-os")
    lines.append(f"  {BRIGHT_BLACK}License{RESET}     Apache 2.0")

    return "\n".join(lines)


def cmd_doctor(args: str, ctx: CommandContext) -> str:
    """Check system health -- model connectivity, deps, storage."""
    import shutil

    from phoenix.config.settings import PHOENIX_DIR, get_model, get_provider

    checks: list[tuple[str, bool, str]] = []

    # Model configured
    model = get_model()
    checks.append(("Model configured", bool(model), model))

    # API key available
    provider = get_provider()
    import os

    key_map = {
        "anthropic": "ANTHROPIC_API_KEY",
        "openai": "OPENAI_API_KEY",
        "google-gla": "GEMINI_API_KEY",
        "groq": "GROQ_API_KEY",
        "mistral": "MISTRAL_API_KEY",
        "deepseek": "DEEPSEEK_API_KEY",
    }
    env_var = key_map.get(provider)
    if env_var:
        has_key = bool(os.environ.get(env_var))
        status = "set" if has_key else f"missing ({env_var})"
        checks.append(("API key", has_key, status))
    elif provider == "ollama":
        checks.append(("API key", True, "not needed (local)"))

    # Data directory
    dir_exists = PHOENIX_DIR.exists()
    checks.append(("Data directory", dir_exists, str(PHOENIX_DIR)))

    # Memory database
    db_path = PHOENIX_DIR / "memory.db"
    checks.append(("Memory database", db_path.exists(), str(db_path)))

    # Git available
    has_git = shutil.which("git") is not None
    checks.append(("git", has_git, "found" if has_git else "not found"))

    # ripgrep available
    has_rg = shutil.which("rg") is not None
    checks.append(("ripgrep", has_rg, "found" if has_rg else "using grep fallback"))

    # Optional: fastembed
    try:
        import fastembed  # noqa: F401

        checks.append(("fastembed", True, "installed"))
    except ImportError:
        checks.append(("fastembed", False, "not installed (using TF-IDF fallback)"))

    # Optional: voice deps
    try:
        import sounddevice  # noqa: F401

        checks.append(("voice deps", True, "installed"))
    except ImportError:
        checks.append(("voice deps", False, "not installed (pip install phoenix-os[voice])"))

    # Format output
    ok = f"{GREEN}ok{RESET}"
    fail = f"{YELLOW}--{RESET}"
    lines = [f"{BOLD}Doctor{RESET}", ""]
    all_good = True
    for name, passed, detail in checks:
        icon = ok if passed else fail
        lines.append(f"  {icon}  {name}  {BRIGHT_BLACK}{detail}{RESET}")
        if not passed:
            all_good = False

    lines.append("")
    if all_good:
        lines.append(f"  {GREEN}All checks passed.{RESET}")
    else:
        lines.append(f"  {YELLOW}Some checks need attention.{RESET}")

    return "\n".join(lines)


def cmd_settings(args: str, ctx: CommandContext) -> str:
    """Show current settings."""
    import os

    from phoenix.config.settings import PHOENIX_DIR, get_model, get_provider

    model = get_model()
    provider = get_provider()

    mode = "safe"
    from phoenix.core.interceptor import AutoApprovalBackend, get_approval_backend

    backend = get_approval_backend()
    if isinstance(backend, AutoApprovalBackend):
        mode = backend.mode
    mode_colors = {"safe": GREEN, "auto": YELLOW, "yolo": RED}
    mode_color = mode_colors.get(mode, GREEN)

    lines = [f"{BOLD}Settings{RESET}", ""]

    lines.append(f"  {BRIGHT_BLACK}Model{RESET}         {CYAN}{model}{RESET}")
    lines.append(f"  {BRIGHT_BLACK}Provider{RESET}      {provider}")
    lines.append(f"  {BRIGHT_BLACK}Mode{RESET}          {mode_color}{mode}{RESET}")
    lines.append(f"  {BRIGHT_BLACK}Data dir{RESET}      {PHOENIX_DIR}")

    # Show which API keys are set
    keys = {
        "ANTHROPIC_API_KEY": "Anthropic",
        "OPENAI_API_KEY": "OpenAI",
        "GROQ_API_KEY": "Groq",
        "GEMINI_API_KEY": "Gemini",
    }
    set_keys = [name for env, name in keys.items() if os.environ.get(env)]
    if set_keys:
        lines.append(f"  {BRIGHT_BLACK}API keys{RESET}      {', '.join(set_keys)}")

    if ctx.engine and ctx.engine._memory:
        stats = ctx.engine._memory.stats()
        lines.append(f"  {BRIGHT_BLACK}Memories{RESET}      {stats.get('total', 0)}")

    lines.append("")
    lines.append(f"  {BRIGHT_BLACK}Change model:{RESET}  /model <name>")
    lines.append(f"  {BRIGHT_BLACK}Change mode:{RESET}   /mode <safe|auto|yolo>")
    lines.append(f"  {BRIGHT_BLACK}Full setup:{RESET}    /setup")

    return "\n".join(lines)


COMMANDS: dict[str, Callable] = {
    "/help": cmd_help,
    "/clear": cmd_clear,
    "/history": cmd_history,
    "/model": cmd_model,
    "/cost": cmd_cost,
    "/tools": cmd_tools,
    "/agents": cmd_agents,
    "/sessions": cmd_sessions,
    "/mode": cmd_mode,
    "/memory": cmd_memory,
    "/ambient": cmd_ambient,
    "/voice": cmd_voice,
    "/setup": cmd_setup,
    "/logs": cmd_logs,
    "/about": cmd_about,
    "/doctor": cmd_doctor,
    "/settings": cmd_settings,
}

ALIASES = {"quit": "/bye", "exit": "/bye", "clear": "/clear", "history": "/history"}


def handle_command(user_input: str, ctx: CommandContext) -> str | None:
    """Handle a slash command. Returns output string, or None if not a command."""
    stripped = user_input.strip()

    if stripped in ALIASES:
        stripped = ALIASES[stripped]

    if not stripped.startswith("/"):
        return None

    parts = stripped.split(None, 1)
    cmd_name = parts[0].lower()
    args = parts[1] if len(parts) > 1 else ""

    if cmd_name in ("/bye", "/quit", "/exit"):
        return "__EXIT__"

    handler = COMMANDS.get(cmd_name)
    if handler:
        return handler(args, ctx)

    return f"Unknown command: {cmd_name}. Type /help for available commands."
