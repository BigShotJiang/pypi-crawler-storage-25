"""Consolidation engine -- cluster similar memories into meta-memories."""

import logging

import numpy as np

from .config import CATEGORY_IMPORTANCE, MemoryParams
from .embeddings import EmbeddingService
from .store import MemoryStore

log = logging.getLogger(__name__)


def _truncate_at_boundary(text: str, max_len: int) -> str:
    """Truncate at last sentence/clause/word boundary before max_len.

    Avoids the mid-word cuts ("...and all") that hard slicing produces.
    Falls back to word boundary, then hard cut with ellipsis if no boundary
    is found in the latter 40% of the allowed range.
    """
    if len(text) <= max_len:
        return text
    truncated = text[:max_len]
    for boundary in (". ", "; ", "! ", "? "):
        idx = truncated.rfind(boundary)
        if idx > max_len * 0.6:
            return truncated[: idx + 1].rstrip()
    idx = truncated.rfind(" ")
    if idx > max_len * 0.6:
        return truncated[:idx]
    return truncated[: max_len - 3] + "..."


class ConsolidationEngine:
    """Periodically clusters similar memories into higher-level abstractions."""

    def __init__(self, config: MemoryParams, embedder: EmbeddingService, store: MemoryStore):
        self.config = config
        self.embedder = embedder
        self.store = store
        self._category_usefulness: dict[str, float] = {}

    def consolidate(self, namespace: str = "global") -> list[dict]:
        """Greedy clustering of similar memories into meta-memories."""
        ids, matrix = self.store.get_all_embeddings(namespace)
        if len(ids) < self.config.consolidate_min_cluster * 2:
            return []

        # Pairwise similarity
        norms = np.linalg.norm(matrix, axis=1, keepdims=True)
        norms = np.maximum(norms, 1e-9)
        normed = matrix / norms
        sim_matrix = normed @ normed.T

        # Load memories for strength sorting
        mems = {}
        for mid in ids:
            mem = self.store.get(mid)
            if mem:
                mems[mid] = mem

        # Sort by strength (seed from strongest)
        sorted_ids = sorted(ids, key=lambda m: mems.get(m, {}).get("strength", 0), reverse=True)
        id_to_idx = {mid: i for i, mid in enumerate(ids)}

        used = set()
        clusters: list[list[str]] = []

        for mid in sorted_ids:
            if mid in used or len(clusters) >= self.config.consolidate_max_clusters:
                break
            idx = id_to_idx[mid]
            cluster = [mid]
            used.add(mid)

            for other_mid in sorted_ids:
                if other_mid in used:
                    continue
                other_idx = id_to_idx[other_mid]
                if sim_matrix[idx, other_idx] >= self.config.consolidate_sim_threshold:
                    cluster.append(other_mid)
                    used.add(other_mid)

            if len(cluster) >= self.config.consolidate_min_cluster:
                clusters.append(cluster)

        # Create meta-memories
        created = []
        for cluster in clusters:
            contents = []
            strengths = []

            for mid in cluster:
                mem = mems.get(mid)
                if not mem:
                    continue
                content = mem["content"]
                # Strip ALL leading `[consolidated] ` prefixes to prevent
                # multi-layer nesting when re-consolidating already-merged memories.
                while content.startswith("[consolidated] "):
                    content = content.removeprefix("[consolidated] ")
                contents.append(_truncate_at_boundary(content, 100))
                strengths.append(mem.get("strength", 1.0))

            if not contents:
                continue

            meta_content = "[consolidated] " + "; ".join(contents)
            meta_content = _truncate_at_boundary(meta_content, 300)

            # Re-embed the merged meta_content with the `clustering` task prompt.
            # For Gemma this yields cluster-optimized vectors (EmbeddingGemma's
            # intended use). FastEmbed and TF-IDF are symmetric and ignore task.
            meta_embedding = self.embedder.embed_clustering(meta_content)

            mean_strength = sum(strengths) / len(strengths) if strengths else 1.0
            meta_strength = min(mean_strength * 1.3, 2.0)

            meta_id = self.store.add(
                content=meta_content,
                category="fact",
                namespace=namespace,
                embedding=meta_embedding,
                strength=meta_strength,
                source_session="consolidation",
            )

            # High-weight edges back to originals
            for mid in cluster:
                self.store.add_edge(meta_id, mid, weight=0.9, reinforce_amount=0.0)

            created.append({"id": meta_id, "content": meta_content, "cluster_size": len(cluster)})
            log.info("Consolidated %d memories: %s", len(cluster), meta_content[:80])

        return created

    def update_category_usefulness(self, category: str, alignment: float):
        """Update running average of how useful a category's memories are."""
        old = self._category_usefulness.get(category, 0.5)
        self._category_usefulness[category] = (
            self.config.adaptive_ema * old + (1 - self.config.adaptive_ema) * alignment
        )

    def get_adaptive_importance(self) -> dict[str, float]:
        """Return category importance weights adjusted by learned usefulness."""
        if not self.config.adaptive_weights or not self._category_usefulness:
            return dict(CATEGORY_IMPORTANCE)

        adapted = {}
        for cat, base in CATEGORY_IMPORTANCE.items():
            usefulness = self._category_usefulness.get(cat, 0.5)
            adjusted = base * (1 + self.config.adaptive_lr * (usefulness - 0.5))
            adapted[cat] = max(0.5, min(2.0, adjusted))
        return adapted
