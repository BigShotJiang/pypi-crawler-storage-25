import asyncio
import json
import sys
import tomllib
from pathlib import Path

from platformdirs import user_config_dir
from websockets.asyncio.client import connect


async def main(port: int) -> None:
    cfg_path = Path(user_config_dir("thesis", appauthor=False)) / "config.toml"
    cfg = tomllib.loads(cfg_path.read_text(encoding="utf-8"))
    token = cfg["token"]

    async with connect(f"ws://127.0.0.1:{port}?token={token}") as ws:
        print("STATUS:", await ws.recv())
        await ws.send(json.dumps({"type": "ping"}))
        print("PONG:", await ws.recv())
        async def run_cell(code: str, cell_id: str) -> None:
            await ws.send(
                json.dumps(
                    {"type": "exec", "project_id": "x", "cell_id": cell_id, "code": code}
                )
            )
            while True:
                m = json.loads(await ws.recv())
                print(m)
                if m.get("type") == "done":
                    return

        print("\n--- cell 1: define x ---")
        await run_cell("x = 7 * 6", "c1")
        print("\n--- cell 2: use x ---")
        await run_cell("print(f'x is {x}')", "c2")
        print("\n--- cell 3: exception ---")
        await run_cell("1/0", "c3")


if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 61720
    asyncio.run(main(port))
