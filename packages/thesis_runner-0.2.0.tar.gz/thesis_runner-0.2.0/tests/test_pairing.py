from __future__ import annotations

import asyncio
from typing import Any

import pytest
from aiohttp import web

from thesis_runner.pairing import PairingError, PairingSession


async def _fake_backend(behavior: dict[str, Any]) -> tuple[web.AppRunner, str]:
    """Spin up a stub API implementing /runner/pair/{request,claim}."""
    state: dict[str, Any] = {"approved": False, "registered": False}

    async def req(request: web.Request) -> web.Response:
        body = await request.json()
        assert "code" in body
        state["registered"] = True
        return web.Response(status=204)

    async def claim(request: web.Request) -> web.Response:
        state["claim_calls"] = state.get("claim_calls", 0) + 1
        if state["claim_calls"] < behavior.get("approve_after", 1):
            return web.json_response({"status": "pending"})
        if behavior.get("expire"):
            return web.Response(status=404, text="expired")
        return web.json_response(
            {"status": "approved", "token": "tok_xxx", "user_id": "u_1"}
        )

    app = web.Application()
    app.router.add_post("/runner/pair/request", req)
    app.router.add_get("/runner/pair/claim", claim)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "127.0.0.1", 0)
    await site.start()
    port = site._server.sockets[0].getsockname()[1]  # type: ignore[union-attr]
    return runner, f"http://127.0.0.1:{port}"


@pytest.mark.asyncio
async def test_pairing_polls_and_returns_token() -> None:
    runner, base = await _fake_backend({"approve_after": 2})
    try:
        session = PairingSession(base)
        await session.register()
        result = await session.poll(timeout=10.0, interval=0.05)
        assert result.token == "tok_xxx"
        assert result.user_id == "u_1"
    finally:
        await runner.cleanup()


@pytest.mark.asyncio
async def test_pairing_expired_code_raises() -> None:
    runner, base = await _fake_backend({"approve_after": 1, "expire": True})
    try:
        session = PairingSession(base)
        await session.register()
        with pytest.raises(PairingError):
            await session.poll(timeout=2.0, interval=0.05)
    finally:
        await runner.cleanup()


@pytest.mark.asyncio
async def test_pairing_timeout() -> None:
    # backend always says pending
    runner, base = await _fake_backend({"approve_after": 10_000})
    try:
        session = PairingSession(base)
        await session.register()
        with pytest.raises(PairingError, match="timed out"):
            await session.poll(timeout=0.2, interval=0.05)
    finally:
        await runner.cleanup()
