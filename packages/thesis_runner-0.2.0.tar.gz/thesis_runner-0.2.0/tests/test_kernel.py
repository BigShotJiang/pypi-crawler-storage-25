import pytest

from thesis_runner.kernel import KernelProcess


async def _collect(kernel: KernelProcess, code: str, cell_id: str = "c1") -> list[dict]:
    msgs: list[dict] = []

    async def on_msg(m: dict) -> None:
        msgs.append(m)

    await kernel.exec(cell_id, code, on_msg)
    return msgs


@pytest.mark.asyncio
async def test_exec_print_streams_stdout() -> None:
    k = KernelProcess()
    try:
        msgs = await _collect(k, "print('hello')")
        types = [m["type"] for m in msgs]
        assert "stdout" in types
        assert types[-1] == "done"
        stdout = "".join(m["text"] for m in msgs if m["type"] == "stdout")
        assert "hello" in stdout
    finally:
        await k.stop()


@pytest.mark.asyncio
async def test_state_persists_across_cells() -> None:
    k = KernelProcess()
    try:
        await _collect(k, "x = 42", cell_id="a")
        msgs = await _collect(k, "print(x * 2)", cell_id="b")
        stdout = "".join(m["text"] for m in msgs if m["type"] == "stdout")
        assert "84" in stdout
    finally:
        await k.stop()


@pytest.mark.asyncio
async def test_exception_goes_to_stderr() -> None:
    k = KernelProcess()
    try:
        msgs = await _collect(k, "1/0")
        stderr = "".join(m["text"] for m in msgs if m["type"] == "stderr")
        assert "ZeroDivisionError" in stderr
        assert msgs[-1]["type"] == "done"
    finally:
        await k.stop()


@pytest.mark.asyncio
async def test_restart_clears_state() -> None:
    k = KernelProcess()
    try:
        await _collect(k, "x = 42", cell_id="a")
        await k.restart()
        msgs = await _collect(k, "print(x)", cell_id="b")
        stderr = "".join(m["text"] for m in msgs if m["type"] == "stderr")
        assert "NameError" in stderr
    finally:
        await k.stop()
