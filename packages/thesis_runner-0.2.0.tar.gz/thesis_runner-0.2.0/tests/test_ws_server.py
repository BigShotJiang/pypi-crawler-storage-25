import json

import pytest
from websockets.asyncio.client import connect

from thesis_runner.ws_server import Server


@pytest.mark.asyncio
async def test_ping_pong() -> None:
    server = Server(token="test-token")
    async with server.serve(port=0) as port:
        async with connect(f"ws://127.0.0.1:{port}?token=test-token") as ws:
            await ws.recv()  # status
            await ws.send(json.dumps({"type": "ping"}))
            reply = json.loads(await ws.recv())
            assert reply["type"] == "pong"


@pytest.mark.asyncio
async def test_exec_real_python_emits_stdout_and_done() -> None:
    server = Server(token="test-token")
    async with server.serve(port=0) as port:
        async with connect(f"ws://127.0.0.1:{port}?token=test-token") as ws:
            await ws.recv()  # status
            await ws.send(
                json.dumps(
                    {
                        "type": "exec",
                        "project_id": "p1",
                        "cell_id": "c1",
                        "code": "print(7 * 6)",
                    }
                )
            )
            msgs = []
            while True:
                raw = await ws.recv()
                m = json.loads(raw)
                msgs.append(m)
                if m.get("type") == "done":
                    break
            types = [m["type"] for m in msgs]
            assert "stdout" in types
            assert types[-1] == "done"
            stdout = "".join(m["text"] for m in msgs if m["type"] == "stdout")
            assert "42" in stdout


@pytest.mark.asyncio
async def test_wrong_token_rejected() -> None:
    from websockets.exceptions import ConnectionClosed

    server = Server(token="good")
    async with server.serve(port=0) as port:
        async with connect(f"ws://127.0.0.1:{port}?token=bad") as ws:
            with pytest.raises(ConnectionClosed):
                await ws.recv()
            assert ws.close_code == 4401
