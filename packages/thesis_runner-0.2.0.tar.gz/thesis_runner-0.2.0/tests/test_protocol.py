import pytest

from thesis_runner.protocol import ExecMessage, PingMessage, parse_message


def test_parse_exec() -> None:
    raw = '{"type":"exec","project_id":"p1","file_id":"f1","code":"print(1)"}'
    m = parse_message(raw)
    assert isinstance(m, ExecMessage)
    assert m.project_id == "p1"
    assert m.code == "print(1)"


def test_parse_ping() -> None:
    m = parse_message('{"type":"ping"}')
    assert isinstance(m, PingMessage)


def test_parse_unknown_raises() -> None:
    with pytest.raises(ValueError):
        parse_message('{"type":"nonsense"}')
