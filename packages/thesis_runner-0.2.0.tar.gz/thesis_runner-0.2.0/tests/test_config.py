from pathlib import Path

from thesis_runner.config import Config, default_config_path, load, save


def test_save_and_load_roundtrip(tmp_path: Path) -> None:
    path = tmp_path / "config.toml"
    c = Config(token="abc123", user_id="u_1", api_base="https://api.example.com")
    save(c, path)
    loaded = load(path)
    assert loaded == c


def test_load_missing_returns_empty(tmp_path: Path) -> None:
    assert load(tmp_path / "nonexistent.toml") == Config()


def test_default_config_path_is_under_thesis_dir() -> None:
    p = default_config_path()
    assert p.parent.name == "thesis"
    assert p.name == "config.toml"


def test_save_creates_parent_dir(tmp_path: Path) -> None:
    path = tmp_path / "nested" / "dir" / "config.toml"
    save(Config(token="t"), path)
    assert path.exists()
