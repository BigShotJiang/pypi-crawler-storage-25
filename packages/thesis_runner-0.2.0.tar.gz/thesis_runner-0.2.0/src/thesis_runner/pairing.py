from __future__ import annotations

import asyncio
import secrets

import httpx
from pydantic import BaseModel


class PairingResult(BaseModel):
    token: str
    user_id: str


class PairingError(RuntimeError):
    pass


class PairingSession:
    """Device-flow pairing. Runner registers a code with the backend, opens the
    browser to the approval page, and polls /runner/pair/claim until the user
    approves or the session times out.
    """

    def __init__(self, api_base: str) -> None:
        self.api_base = api_base.rstrip("/")
        self.code = secrets.token_urlsafe(24)

    @property
    def approve_url(self) -> str:
        return f"{self.api_base}/runner/pair?code={self.code}"

    async def register(self) -> None:
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.post(
                f"{self.api_base}/runner/pair/request",
                json={"code": self.code},
            )
            if resp.status_code >= 400:
                raise PairingError(
                    f"register failed: {resp.status_code} {resp.text[:200]}"
                )

    async def poll(
        self, timeout: float = 300.0, interval: float = 2.0
    ) -> PairingResult:
        deadline = asyncio.get_event_loop().time() + timeout
        async with httpx.AsyncClient(timeout=15.0) as client:
            while True:
                if asyncio.get_event_loop().time() > deadline:
                    raise PairingError("pairing timed out")
                resp = await client.get(
                    f"{self.api_base}/runner/pair/claim",
                    params={"code": self.code},
                )
                if resp.status_code == 200:
                    data = resp.json()
                    if data.get("status") == "approved":
                        return PairingResult(
                            token=data["token"], user_id=data["user_id"]
                        )
                elif resp.status_code == 404:
                    raise PairingError("pair code expired; restart the runner")
                elif resp.status_code >= 500:
                    # Transient — keep polling.
                    pass
                await asyncio.sleep(interval)
