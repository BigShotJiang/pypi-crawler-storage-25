"""Runs inside the kernel subprocess.

Reads newline-delimited JSON ops from stdin, executes Python in a persistent
namespace, writes newline-delimited JSON events to stdout. All prints inside
user code are captured and surfaced as stdout/stderr events.
"""
from __future__ import annotations

import ast
import base64
import io
import json
import sys
import time
import traceback
from contextlib import redirect_stderr, redirect_stdout
from typing import Any

_NAMESPACE: dict[str, Any] = {"__name__": "__main__"}
_RAW_STDOUT = sys.__stdout__
_CURRENT_CELL: str | None = None


def emit(msg: dict[str, Any]) -> None:
    assert _RAW_STDOUT is not None
    _RAW_STDOUT.write(json.dumps(msg) + "\n")
    _RAW_STDOUT.flush()


class _StreamProxy(io.TextIOBase):
    def __init__(self, kind: str, cell_id: str | None) -> None:
        self.kind = kind
        self.cell_id = cell_id
        self._buf = ""

    def write(self, s: str) -> int:  # type: ignore[override]
        self._buf += s
        while "\n" in self._buf:
            line, self._buf = self._buf.split("\n", 1)
            emit({"type": self.kind, "cell_id": self.cell_id, "text": line + "\n"})
        return len(s)

    def flush(self) -> None:
        if self._buf:
            emit({"type": self.kind, "cell_id": self.cell_id, "text": self._buf})
            self._buf = ""


def _bootstrap_matplotlib() -> None:
    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        def _show(*args: Any, **kwargs: Any) -> None:
            for num in plt.get_fignums():
                fig = plt.figure(num)
                buf = io.BytesIO()
                fig.savefig(buf, format="png", bbox_inches="tight")
                emit(
                    {
                        "type": "display",
                        "cell_id": _CURRENT_CELL,
                        "mime": "image/png",
                        "data": base64.b64encode(buf.getvalue()).decode("ascii"),
                    }
                )
                plt.close(fig)

        plt.show = _show  # type: ignore[assignment]
    except Exception:
        pass


def _run_exec(cell_id: str | None, code: str) -> None:
    global _CURRENT_CELL
    _CURRENT_CELL = cell_id
    start = time.monotonic()
    out = _StreamProxy("stdout", cell_id)
    err = _StreamProxy("stderr", cell_id)
    try:
        tree = ast.parse(code, filename="<cell>", mode="exec")
    except SyntaxError:
        err.write(traceback.format_exc())
        out.flush()
        err.flush()
        emit(
            {
                "type": "done",
                "cell_id": cell_id,
                "duration_ms": int((time.monotonic() - start) * 1000),
            }
        )
        _CURRENT_CELL = None
        return

    trailing_expr: ast.Expression | None = None
    if tree.body and isinstance(tree.body[-1], ast.Expr):
        expr_node = tree.body.pop().value  # type: ignore[union-attr]
        trailing_expr = ast.Expression(body=expr_node)
        ast.copy_location(trailing_expr, expr_node)

    try:
        with redirect_stdout(out), redirect_stderr(err):
            if tree.body:
                exec(compile(tree, "<cell>", "exec"), _NAMESPACE)
            if trailing_expr is not None:
                value = eval(
                    compile(trailing_expr, "<cell>", "eval"), _NAMESPACE
                )
                if value is not None:
                    out.write(repr(value) + "\n")
    except BaseException:
        err.write(traceback.format_exc())
    out.flush()
    err.flush()
    emit(
        {
            "type": "done",
            "cell_id": cell_id,
            "duration_ms": int((time.monotonic() - start) * 1000),
        }
    )
    _CURRENT_CELL = None


def main() -> None:
    _bootstrap_matplotlib()
    emit({"type": "ready"})
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            op = json.loads(line)
        except json.JSONDecodeError:
            continue
        if op.get("op") == "exec":
            _run_exec(op.get("cell_id"), op.get("code", ""))


if __name__ == "__main__":
    main()
