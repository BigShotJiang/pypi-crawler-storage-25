"""Kernel subprocess manager.

One long-lived Python subprocess per project. Holds state across cell execs.
"""
from __future__ import annotations

import asyncio
import json
import re
import sys
from typing import Any, Awaitable, Callable

_MODULE_NOT_FOUND = re.compile(r"ModuleNotFoundError: No module named '([A-Za-z0-9_\.]+)'")


class KernelProcess:
    def __init__(self, python_exe: str | None = None) -> None:
        self.python_exe = python_exe or sys.executable
        self._proc: asyncio.subprocess.Process | None = None
        self._lock = asyncio.Lock()

    async def start(self) -> None:
        if self._proc is not None:
            return
        self._proc = await asyncio.create_subprocess_exec(
            self.python_exe,
            "-u",
            "-m",
            "thesis_runner._kernel_entry",
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        ready = await self._read_line()
        if ready.get("type") != "ready":
            raise RuntimeError(f"kernel failed to start: {ready}")

    async def _read_line(self) -> dict[str, Any]:
        assert self._proc and self._proc.stdout
        line = await self._proc.stdout.readline()
        if not line:
            raise RuntimeError("kernel stdout closed")
        return json.loads(line.decode())

    async def exec(
        self,
        cell_id: str | None,
        code: str,
        on_message: Callable[[dict[str, Any]], Awaitable[None]],
    ) -> None:
        await self.start()
        async with self._lock:
            await self._exec_once(cell_id, code, on_message)

    async def _exec_once(
        self,
        cell_id: str | None,
        code: str,
        on_message: Callable[[dict[str, Any]], Awaitable[None]],
    ) -> None:
        assert self._proc and self._proc.stdin
        payload = json.dumps({"op": "exec", "cell_id": cell_id, "code": code}) + "\n"
        self._proc.stdin.write(payload.encode())
        await self._proc.stdin.drain()

        collected_stderr: list[str] = []
        while True:
            msg = await self._read_line()
            await on_message(msg)
            if msg.get("type") == "stderr":
                collected_stderr.append(msg.get("text", ""))
            if msg.get("type") == "done":
                break

        missing = self._missing_module("".join(collected_stderr))
        if missing:
            await on_message(
                {
                    "type": "stdout",
                    "cell_id": cell_id,
                    "text": f"[runner] Installing {missing} …\n",
                }
            )
            ok = await self._pip_install(missing, on_message, cell_id)
            if ok:
                await on_message(
                    {
                        "type": "stdout",
                        "cell_id": cell_id,
                        "text": f"[runner] Installed {missing}. Retrying cell.\n",
                    }
                )
                # Retry once.
                await self._exec_once(cell_id, code, on_message)

    @staticmethod
    def _missing_module(stderr_text: str) -> str | None:
        m = _MODULE_NOT_FOUND.search(stderr_text)
        if not m:
            return None
        return m.group(1).split(".")[0]

    async def _pip_install(
        self,
        package: str,
        on_message: Callable[[dict[str, Any]], Awaitable[None]],
        cell_id: str | None,
    ) -> bool:
        proc = await asyncio.create_subprocess_exec(
            self.python_exe,
            "-m",
            "pip",
            "install",
            "--quiet",
            package,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        _, err = await proc.communicate()
        if proc.returncode != 0:
            await on_message(
                {
                    "type": "stderr",
                    "cell_id": cell_id,
                    "text": f"[runner] pip install {package} failed:\n{err.decode(errors='replace')}",
                }
            )
            return False
        return True

    async def restart(self) -> None:
        await self.stop()
        await self.start()

    async def interrupt(self) -> None:
        # Windows doesn't support SIGINT to subprocess reliably; cheapest "works" is restart.
        await self.restart()

    async def stop(self) -> None:
        if self._proc is None:
            return
        try:
            self._proc.terminate()
        except ProcessLookupError:
            pass
        try:
            await asyncio.wait_for(self._proc.wait(), timeout=2.0)
        except asyncio.TimeoutError:
            self._proc.kill()
            await self._proc.wait()
        self._proc = None


class KernelManager:
    def __init__(self) -> None:
        self._kernels: dict[str, KernelProcess] = {}

    def get(self, project_id: str) -> KernelProcess:
        if project_id not in self._kernels:
            self._kernels[project_id] = KernelProcess()
        return self._kernels[project_id]

    async def stop_all(self) -> None:
        for k in list(self._kernels.values()):
            await k.stop()
        self._kernels.clear()
