from __future__ import annotations

import json
from contextlib import asynccontextmanager
from typing import Any, AsyncIterator
from urllib.parse import parse_qs, urlparse

from websockets.asyncio.server import ServerConnection, serve

from .kernel import KernelManager
from .protocol import (
    ExecMessage,
    InterruptMessage,
    PingMessage,
    PongMessage,
    RestartMessage,
    StatusMessage,
    parse_message,
)
from .version import __version__


_DEFAULT_ALLOWED_ORIGINS = (
    "https://thesis-app-web-bay.vercel.app",
    "http://localhost:3000",
    "http://127.0.0.1:3000",
)


class Server:
    def __init__(
        self, token: str, allowed_origins: tuple[str, ...] | None = None
    ) -> None:
        self.token = token
        self.allowed_origins = allowed_origins or _DEFAULT_ALLOWED_ORIGINS
        self.kernels = KernelManager()

    async def _handler(self, ws: ServerConnection) -> None:
        # Reject cross-origin browser connections. Non-browser clients (python
        # tests, future pass-7c server-side proxy) send no Origin and are
        # permitted — the token is still required.
        if ws.request is not None:
            origin = ws.request.headers.get("Origin")
            if origin is not None and origin not in self.allowed_origins:
                await ws.close(code=4403, reason="origin not allowed")
                return

        path = ws.request.path if ws.request else ""
        params = parse_qs(urlparse(path).query)
        provided = (params.get("token") or [None])[0]
        if provided != self.token:
            await ws.close(code=4401, reason="bad token")
            return

        await ws.send(
            StatusMessage(connected=True, version=__version__).model_dump_json()
        )

        async def send_json(msg: dict[str, Any]) -> None:
            await ws.send(json.dumps(msg))

        async for raw in ws:
            text = raw if isinstance(raw, str) else raw.decode()
            try:
                msg = parse_message(text)
            except ValueError as e:
                await send_json({"type": "error", "detail": str(e)})
                continue

            if isinstance(msg, PingMessage):
                await ws.send(PongMessage().model_dump_json())
            elif isinstance(msg, ExecMessage):
                kernel = self.kernels.get(msg.project_id)
                try:
                    await kernel.exec(msg.cell_id, msg.code, send_json)
                except Exception as e:
                    await send_json(
                        {"type": "stderr", "cell_id": msg.cell_id, "text": f"[runner] {e}\n"}
                    )
                    await send_json(
                        {"type": "done", "cell_id": msg.cell_id, "duration_ms": 0}
                    )
            elif isinstance(msg, InterruptMessage):
                await self.kernels.get(msg.project_id).interrupt()
                await send_json({"type": "interrupted", "project_id": msg.project_id})
            elif isinstance(msg, RestartMessage):
                await self.kernels.get(msg.project_id).restart()
                await send_json({"type": "restarted", "project_id": msg.project_id})
            else:
                await send_json({"type": "error", "detail": "unsupported"})

    @asynccontextmanager
    async def serve(
        self, *, host: str = "127.0.0.1", port: int = 0
    ) -> AsyncIterator[int]:
        async with serve(self._handler, host, port) as server:
            actual = next(iter(server.sockets)).getsockname()[1]
            try:
                yield actual
            finally:
                await self.kernels.stop_all()
