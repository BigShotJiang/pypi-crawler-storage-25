from __future__ import annotations

from typing import Annotated, Literal, Union

from pydantic import BaseModel, Field, TypeAdapter, ValidationError


class ExecMessage(BaseModel):
    type: Literal["exec"] = "exec"
    project_id: str
    file_id: str | None = None
    cell_id: str | None = None
    code: str


class InterruptMessage(BaseModel):
    type: Literal["interrupt"] = "interrupt"
    project_id: str


class RestartMessage(BaseModel):
    type: Literal["restart"] = "restart"
    project_id: str


class PingMessage(BaseModel):
    type: Literal["ping"] = "ping"


ClientMessage = Annotated[
    Union[ExecMessage, InterruptMessage, RestartMessage, PingMessage],
    Field(discriminator="type"),
]

_adapter: TypeAdapter[ClientMessage] = TypeAdapter(ClientMessage)


def parse_message(raw: str) -> ClientMessage:
    try:
        return _adapter.validate_json(raw)
    except ValidationError as e:
        raise ValueError(str(e)) from e


class StdoutMessage(BaseModel):
    type: Literal["stdout"] = "stdout"
    cell_id: str | None
    text: str


class StderrMessage(BaseModel):
    type: Literal["stderr"] = "stderr"
    cell_id: str | None
    text: str


class DoneMessage(BaseModel):
    type: Literal["done"] = "done"
    cell_id: str | None
    duration_ms: int


class PongMessage(BaseModel):
    type: Literal["pong"] = "pong"


class StatusMessage(BaseModel):
    type: Literal["status"] = "status"
    connected: bool
    version: str
