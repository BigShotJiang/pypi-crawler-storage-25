from __future__ import annotations

import asyncio
import sys
import webbrowser

import click

from .config import load, save
from .pairing import PairingSession
from .version import __version__
from .ws_server import Server


async def _pair_and_run(api_base: str | None) -> None:
    cfg = load()
    if api_base:
        cfg.api_base = api_base

    if not cfg.token:
        click.echo("No paired account. Starting pairing flow…")
        session = PairingSession(cfg.api_base)
        await session.register()
        click.echo(f"Opening browser: {session.approve_url}")
        click.echo(f"Pair code: {session.code[:8]}… (confirm this on the web page)")
        webbrowser.open(session.approve_url)
        click.echo("Waiting for you to sign in and approve (5 min timeout)…")
        result = await session.poll(timeout=300.0)
        cfg.token = result.token
        cfg.user_id = result.user_id
        save(cfg)
        click.echo(f"Paired as {cfg.user_id}. Token saved to config.")

    assert cfg.token is not None
    server = Server(token=cfg.token)
    async with server.serve(port=cfg.ws_port or 0) as port:
        click.echo(f"Runner listening on ws://127.0.0.1:{port}")
        click.echo(f"Version: {__version__}")
        click.echo("Press Ctrl+C to stop.")
        await asyncio.Event().wait()


@click.group()
@click.version_option(__version__)
def main() -> None:
    """Thesis App local runner."""


@main.command()
@click.option("--api-base", default=None, help="Override the web app API URL.")
def start(api_base: str | None) -> None:
    """Start the runner and pair if needed."""
    try:
        asyncio.run(_pair_and_run(api_base))
    except KeyboardInterrupt:
        click.echo("\nStopping.")
        sys.exit(0)


@main.command()
def status() -> None:
    """Show pairing status."""
    cfg = load()
    if cfg.token:
        click.echo(f"Paired as {cfg.user_id}. API: {cfg.api_base}")
    else:
        click.echo("Not paired. Run `thesis-runner start` to pair.")


@main.command()
def unpair() -> None:
    """Forget the paired token."""
    cfg = load()
    cfg.token = None
    cfg.user_id = None
    save(cfg)
    click.echo("Unpaired.")
