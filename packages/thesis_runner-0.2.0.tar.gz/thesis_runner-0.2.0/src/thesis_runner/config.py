from __future__ import annotations

from pathlib import Path

import tomli_w
from platformdirs import user_config_dir
from pydantic import BaseModel


class Config(BaseModel):
    token: str | None = None
    user_id: str | None = None
    api_base: str = "https://thesis-app.fly.dev"
    ws_port: int = 57890  # fixed so the browser can find it; 0 to auto-pick


def default_config_path() -> Path:
    return Path(user_config_dir("thesis", appauthor=False)) / "config.toml"


def load(path: Path | None = None) -> Config:
    p = path or default_config_path()
    if not p.exists():
        return Config()
    import tomllib

    data = tomllib.loads(p.read_text(encoding="utf-8"))
    return Config.model_validate(data)


def save(config: Config, path: Path | None = None) -> None:
    p = path or default_config_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(
        tomli_w.dumps(config.model_dump(exclude_none=True)),
        encoding="utf-8",
    )
