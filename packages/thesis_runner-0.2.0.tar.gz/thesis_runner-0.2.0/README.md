# thesis-runner

Local Python execution runner for [Thesis App](https://github.com/Viliusas1/thesis-app).

## Install

```bash
pip install thesis-runner
```

## Use

```bash
thesis-runner start
```

This opens your browser to pair with the web app. Sign in, click "Approve and pair," and the runner is connected. Keep the terminal running — the web app uses it to execute Python code from your projects.

## Commands

- `thesis-runner start` — start the runner (pairs on first use).
- `thesis-runner status` — show pairing status.
- `thesis-runner unpair` — forget the paired token.

## Config

Stored at the platform's user-config dir, e.g.:

- Windows: `%APPDATA%\thesis\config.toml`
- macOS: `~/Library/Application Support/thesis/config.toml`
- Linux: `~/.config/thesis/config.toml`
