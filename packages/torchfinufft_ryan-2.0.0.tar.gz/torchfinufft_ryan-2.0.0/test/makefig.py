from numpy import *
from matplotlib.pyplot import *

nAx = 2

subfold = ["w_precond", "wo_precond"][0]
arrImg = load(f"test/{subfold}/Original.npy")
lstArrK = list(load(f"test/{subfold}/Trajectory.npz").values())
imgDisp = load(f"test/{subfold}/Reconstructed.npy")

# Visualization
fig = figure(figsize=(12, 6))

subplot(231)
imshow(abs(arrImg), cmap='gray')
clim(0,1)
title("Original")

subplot(232)
for i in range(len(lstArrK)): plot(*lstArrK[i].T[:nAx,:], ".-")
axis("equal")
title("K-space Trajectory")

subplot(233)
imshow(imgDisp, cmap='gray')
clim(0,1)
title("Reconstructed")

subplot(212)
arrLoss = load(f"test/{"w_precond"}/Convergence.npy")
plot(arrLoss, ".-" if subfold=="w_precond" else "--", color="tab:blue")
arrLoss = load(f"test/{"wo_precond"}/Convergence.npy")
plot(arrLoss, ".-" if subfold=="wo_precond" else "--", color="tab:blue")
yscale("log")
title("Convergence")

tight_layout(h_pad=1.25, w_pad=1.00, rect=[0.01,0.01,0.99,0.99])
savefig("test/figure.png")

# show()