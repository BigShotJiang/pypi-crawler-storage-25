from numpy import *
from matplotlib.pyplot import *

import torch
from torch import Tensor

from torchfinufft import *
from time import time
from mrphantom import *
import mrarbgrad as mag
import mrarbdcf as mad

# parameters
useToeplitz = 1
usePrecond = 1
sDev = "cuda" if torch.cuda.is_available() else "cpu"
dev = torch.device(sDev)

if sDev=="cuda":
    complex = torch.complex64
    float = torch.float32
    scomplex = "complex64"
elif sDev=="cpu":
    complex = torch.complex128
    float = torch.float64
    scomplex = "complex128"
else:
    raise NotImplementedError("dev")

# Generate non-Cartesian trajectories
gamma = 42.5756e6
fov = 0.384; nPix = 768; nAx = 2
dtGrad, dtAdc = 10e-6, 2.5e-6
sLim = 50 * gamma*fov/nPix
gLim = 1/nPix/dtAdc
lstArrG = mag.getG_VDSpiral_RT(nPix=nPix, sLim=sLim, gLim=gLim, kRhoPhi0=0.5/(nPix*pi), kRhoPhi1=0.5/(2*pi))[1]
nTraj = len(lstArrG)
lstArrK = [mag.cvtGrad2Traj(arrG, dtGrad, dtAdc)[0] for arrG in lstArrG]
lstArrDcf = mad.solve(nPix, lstArrK)
lstTen2PiKT = [torch.as_tensor(2*pi*arrK.T, dtype=float, device=dev) for arrK in lstArrK]
lstTenDcf = [torch.as_tensor(arrDcf, dtype=complex, device=dev) for arrDcf in lstArrDcf]

tAcq = lstArrK[0].shape[0]*dtAdc
print(f"Tacq: {tAcq*1e3:.2f} ms")

# precompute the motion curve
random.seed(0)
tScan = 14.7e0; tRes = 14.7e-3; nT = int(tScan/tRes)
ampRes = genResAmp(tScan, tRes)
ampCar = genCarAmp(tScan, tRes)
mapPh = genPhMap(nPix=nPix)

# acquire kspace signal
modNufft = Nufft(2, (nPix,)*nAx, 1, zeros((2,3), dtype=float64), dev, complex)
lstTenSig = []
for iT in range(nT):
    if iT%10==0: print(f"iT: {iT}/{nT}")
    # get M0 map
    arrPhant = genPhant(2, nPix, ampRes[iT], ampCar[iT])
    arrImg = Enum2M0(arrPhant)*mapPh
    tenImg = torch.from_numpy(arrImg).to(dev, complex)
    # get trajectory
    arrK = lstArrK[iT%len(lstArrK)]
    arr2PiKT = ascontiguousarray(2*pi*arrK.T)
    modNufft.setpts(arr2PiKT)
    tenSig = modNufft(tenImg)
    lstTenSig.append(tenSig)
    
# reconstruct
lamb = 1e-3
_tenImg = torch.zeros((nT,)+(nPix,)*nAx, device=dev, dtype=complex, requires_grad=True)

optimizer = torch.optim.SGD([_tenImg], lr=1e3); nIter = 1000
# optimizer = torch.optim.Adam([_tenImg], lr=1e-1); nIter = 1000
# optimizer = torch.optim.LBFGS([_tenImg], tolerance_grad=0, tolerance_change=0); nIter = 5 # 25

loss0 = -1; lstLoss = []
def closure():
    global loss0, lstLoss
    optimizer.zero_grad()
    
    loss = torch.zeros((1,), dtype=float, device=dev)
    for iT in range(nT):
        ten2PiKT = lstTen2PiKT[iT%nTraj]
        tenDcf = lstTenDcf[iT%nTraj]
        tenSig = lstTenSig[iT]
        modNufft.setpts(ten2PiKT)
        _tenSig = modNufft(_tenImg[iT,...])
        loss += torch.mean(torch.abs(tenDcf.sqrt()*(_tenSig - tenSig))**2)
    
    tenDiff = torch.diff(_tenImg, dim=0).abs()
    loss += lamb*(tenDiff**2 + 1e-6).sqrt().mean()
    # loss += lamb*tenDiff.mean()
    
    if loss0<0: loss0 = loss.item()
    loss *= 1e0/loss0
        
    if torch.isnan(loss):
        print(f"[WARN] loss==NaN, iter={len(lstLoss)}")
        raise ValueError("loss==NaN")
    
    loss.backward()
    lstLoss += [loss.item()]
    return loss
    
t = time()
for i in range(nIter):
    print(f"Iiter: {i}")
    isnanBef = torch.isnan(_tenImg).any()
    try: optimizer.step(closure)
    except ValueError as e: print(e); break
    except KeyboardInterrupt as e: print(e); break
    isnanAft = torch.isnan(_tenImg).any()
    if ~isnanBef and isnanAft: print("[NaN] step()")
    # if i%10==0: print(f"iter {i}: loss {lstLoss[-1]:.3e}")
t = time() - t
print(f"Elapsed Time: {t:.3f}s")

# Visualization
figure(figsize=(12, 6))

subplot(231)
arrPhant = genPhant(2, nPix, ampRes[0], ampCar[0])
arrImg = Enum2M0(arrPhant)*mapPh
imshow(abs(arrImg[0,...]), cmap='gray')
clim(0,1)
title("Original")

subplot(232);
for i in range(len(lstArrK)): plot(*lstArrK[i].T[:nAx,:], ".-")
axis("equal")
title("K-space Trajectory")

subplot(233)
imshow(_tenImg[0,...].detach().abs().cpu(), cmap='gray')
clim(0,1)
title("Reconstructed")

subplot(212)
plot(array(lstLoss), ".-")
yscale("log")
title("Convergence")

tight_layout(h_pad=1.25, w_pad=1.00, rect=[0.01,0.01,0.99,0.99])

# savefig("test/figure.png")

show()