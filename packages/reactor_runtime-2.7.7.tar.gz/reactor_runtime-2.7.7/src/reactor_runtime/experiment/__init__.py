# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.

"""Experiment-tracking integration for the Reactor runtime.

Activates only when ``EXPERIMENT_ID`` is set in the environment. When unset,
``maybe_build_session()`` returns ``None`` and the runtime takes the same
code paths it always has — no overhead, no NVML sampling, no profiler.

The runtime's only role is to produce artifacts (recording, metrics
summary, profile trace, derived config, session times) under a single
directory. The skill side (``iterate-model.sh``) reads that directory
post-run, uploads to S3 via presigned URLs, and POSTs ``/update_experiment``.
This keeps the runtime free of HTTP, boto3, and presigned-URL env vars.

See ``internal/experiment_tracking/`` for the backing API.
"""

from reactor_runtime.experiment.session import (
    EXPERIMENT_ENV_ARTIFACTS_DIR,
    EXPERIMENT_ENV_ID,
    ExperimentSession,
    maybe_build_session,
)

__all__ = [
    "EXPERIMENT_ENV_ARTIFACTS_DIR",
    "EXPERIMENT_ENV_ID",
    "ExperimentSession",
    "maybe_build_session",
]
