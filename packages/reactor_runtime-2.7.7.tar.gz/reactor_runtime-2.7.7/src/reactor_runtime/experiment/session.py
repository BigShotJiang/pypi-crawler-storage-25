# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.

"""Container-side experiment session — passive artifact producer.

When ``EXPERIMENT_ID`` is set in the env on rank0, the runtime drops the
following files into ``/tmp/experiment-<id>/`` at session stop:

- ``session_times.json``     start + end ISO timestamps (UTC)
- ``metrics_summary.json``   NVML aggregate (avg/peak VRAM, GPU util %)
- ``derived_config.json``    model._config snapshot (or runtime merged
                             config dict if the model didn't expose one)
- ``profile.pt.trace.json.gz``  torch.profiler chrome trace, only if
                                EXPERIMENT_PROFILE_RANGE is set (see
                                reactor_runtime.profiling.ChunkRangeProfiler)
- ``recording.mp4``          fMP4 init.mp4 + chunk_*.m4s byte-concatenated
                             into a single playable file, if the runtime
                             had recording enabled and the session
                             produced chunks

That's it — no HTTP, no boto3, no S3. The script (``iterate-model.sh``
on the developer's machine) reads the artifacts dir over SSH, tars +
gzips it, POSTs it to ``/experiments/<id>/finalize``. The service
extracts the JSONs into RDS and routes the binary blobs (profile +
recording) into S3 using its own task role — the developer never needs
S3 PUT credentials.

Non-rank0 workers return ``None`` from :func:`maybe_build_session` and
take the runtime's normal no-op path — no duplicate finalize calls.
"""

from __future__ import annotations

import json
import os
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from reactor_runtime.profiling.nvml_sampler import NVMLSampler
from reactor_runtime.utils.log import get_logger

# datetime.UTC is a 3.11+ alias for timezone.utc. CI lint runs mypy with
# --python-version 3.10, so import timezone.utc and alias it ourselves.
UTC = timezone.utc

logger = get_logger(__name__)


EXPERIMENT_ENV_ID = "EXPERIMENT_ID"
# Override the default artifacts dir. Defaults to /tmp/experiment-<id>/.
EXPERIMENT_ENV_ARTIFACTS_DIR = "EXPERIMENT_ARTIFACTS_DIR"


class ExperimentSession:
    """One in-flight experiment session.

    Owns the artifacts directory and the session-start/end timestamps. All
    network egress is the caller's responsibility (``iterate-model.sh``).
    """

    def __init__(
        self,
        experiment_id: str,
        artifacts_dir: Path,
    ) -> None:
        self.experiment_id = experiment_id
        self.artifacts_dir = artifacts_dir
        self.started_at: datetime | None = None
        self.ended_at: datetime | None = None
        self._nvml_sampler: NVMLSampler | None = None
        self.artifacts_dir.mkdir(parents=True, exist_ok=True)

    def mark_start(self, device_index: int = 0) -> None:
        self.started_at = datetime.now(UTC)
        try:
            self._nvml_sampler = NVMLSampler(
                device_index=device_index,
                attrs={"experiment_id": self.experiment_id},
            )
            self._nvml_sampler.start()
        except Exception:
            logger.exception("Failed to start NVML sampler; continuing without")
            self._nvml_sampler = None

    def mark_end(self) -> None:
        self.ended_at = datetime.now(UTC)

    def finalize(
        self,
        *,
        derived_config: dict[str, Any] | None,
        recording_session_dir: Path | None = None,
    ) -> None:
        """Write every artifact the skill will ship to the tracker into
        ``self.artifacts_dir``.

        Each artifact is independent — a failure on one doesn't prevent
        the others from being written. The skill treats a missing file as
        "this artifact wasn't produced".

        Note: the torch.profiler chrome trace + key_averages summary
        (``profile.pt.trace.json.gz`` / ``profile.summary.txt``) are
        written DIRECTLY into ``self.artifacts_dir`` by the model's
        worker process via
        :class:`reactor_runtime.profiling.ChunkRangeProfiler`. This
        method doesn't move them around; it just trusts that they're
        already in place by the time it runs.
        """
        if self.started_at and self.ended_at:
            self._write_json(
                "session_times.json",
                {
                    "start": self.started_at.isoformat(),
                    "end": self.ended_at.isoformat(),
                },
            )

        metrics_summary = self._stop_sampling_and_summarize()
        if metrics_summary is not None:
            self._write_json("metrics_summary.json", metrics_summary)

        if derived_config is not None:
            self._write_json("derived_config.json", derived_config)

        if recording_session_dir is not None:
            self._assemble_recording(recording_session_dir)

        logger.info(
            "Experiment artifacts finalized",
            experiment_id=self.experiment_id,
            artifacts_dir=str(self.artifacts_dir),
        )

    def _assemble_recording(self, session_dir: Path) -> None:
        """Concatenate ``init.mp4 + chunk_*.m4s`` into ``recording.mp4``.

        fMP4 byte-concat is valid for players that accept fragmented MP4
        (Safari, Chrome, ffmpeg). Streams chunks through ``copyfileobj``
        rather than buffering in RAM since recordings can be 100 MB+.

        Leading-black trimming used to live here as a post-hoc ffmpeg
        pass. Removed once the recorder learned to drop pre-roll
        duplicates at the source (REA-2323 / #2325) — the bytes never
        reach init.mp4 / chunk_*.m4s anymore.
        """
        init = session_dir / "init.mp4"
        if not init.exists():
            return  # Recording disabled or session was empty.

        chunks = sorted(session_dir.glob("chunk_*.m4s"))
        dest = self.artifacts_dir / "recording.mp4"
        try:
            with open(dest, "wb") as out:
                with open(init, "rb") as src:
                    shutil.copyfileobj(src, out)
                for chunk in chunks:
                    with open(chunk, "rb") as src:
                        shutil.copyfileobj(src, out)
        except OSError as err:
            logger.warning(
                "Failed to assemble recording.mp4",
                session_dir=str(session_dir),
                error=str(err),
            )

    def _stop_sampling_and_summarize(self) -> dict[str, Any] | None:
        sampler = self._nvml_sampler
        if sampler is None:
            return None
        self._nvml_sampler = None
        try:
            sampler.stop()
        except Exception:
            logger.exception("NVML sampler stop failed")
            return None
        state = sampler.state
        n = max(int(state.get("samples", 0)), 1)
        return {
            "samples": int(state.get("samples", 0)),
            "avg_vram_gb": round(float(state.get("vram_sum_gb", 0.0)) / n, 3),
            "peak_vram_gb": round(float(state.get("vram_peak_gb", 0.0)), 3),
            "avg_gpu_util_pct": round(float(state.get("gpu_util_sum_pct", 0.0)) / n, 2),
        }

    def _write_json(self, name: str, payload: Any) -> None:
        path = self.artifacts_dir / name
        try:
            path.write_text(json.dumps(payload, default=str, indent=2))
        except OSError as err:
            logger.warning(
                "Failed to write experiment artifact",
                name=name,
                error=str(err),
            )


def maybe_build_session() -> ExperimentSession | None:
    """Return an ``ExperimentSession`` iff the runtime was launched as a
    tracked experiment (``EXPERIMENT_ID`` set) AND this worker is rank0.

    Non-rank0 workers and untracked runs both get ``None`` — callers
    must treat that as "no tracking, behave as before".
    """
    # Only rank0 produces artifacts. Multiple ranks writing into the same
    # /tmp/experiment-<id>/ would race on the JSON files; the cheaper fix
    # is to keep this whole subsystem inert on non-rank0 workers.
    if int(os.environ.get("RANK", "0")) != 0:
        return None

    experiment_id = os.environ.get(EXPERIMENT_ENV_ID)
    if not experiment_id:
        return None

    artifacts_dir = Path(
        os.environ.get(EXPERIMENT_ENV_ARTIFACTS_DIR)
        or f"/tmp/experiment-{experiment_id}"
    )

    logger.info(
        "Experiment tracking enabled",
        experiment_id=experiment_id,
        artifacts_dir=str(artifacts_dir),
    )
    return ExperimentSession(
        experiment_id=experiment_id,
        artifacts_dir=artifacts_dir,
    )
