# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.

"""NVML resource sampler — general-purpose GPU observability.

Polls VRAM use + GPU utilization at 1Hz on a daemon thread and emits them
as OTLP gauges through the meter pipeline (set up by
``reactor_machine_metrics``). The exporter ships them to Grafana via the
same path the rest of the runtime uses.

Activation is the caller's responsibility — typical pattern is
"start it when there's a session you care about, stop it when the
session ends". The sampler doesn't know about experiments or sessions;
it just samples and emits. Callers that want a snapshot-style summary
(e.g. for inclusion in a row update) can read ``.state`` at stop time
and aggregate however they like.

Cost: ~2 NVML calls per second on a side thread. The main thread and
CUDA streams are untouched.
"""

from __future__ import annotations

import threading
from typing import Any

from opentelemetry import metrics

from reactor_runtime.utils.log import get_logger

logger = get_logger(__name__)


class NVMLSampler:
    """Background NVML poller emitting OTLP gauges + maintaining state.

    Parameters
    ----------
    device_index:
        CUDA device to poll. Defaults to 0.
    interval_s:
        Poll interval in seconds. 1Hz default.
    attrs:
        Label dict applied to every emitted observation. Use this to
        attach context like ``{"experiment_id": "exp_..."}`` or
        ``{"model_name": "delta-forcing"}``. ``None`` → empty attrs
        (gauges still emit, just unlabeled beyond the global meter labels).
    meter_name:
        OTel meter name. Defaults to ``reactor.machine`` — keep this
        consistent with what your dashboards expect.
    metric_namespace:
        Prefix for emitted metrics. ``reactor.machine`` → emits
        ``reactor.machine.vram_used_gb`` + ``reactor.machine.gpu_util_pct``.
    """

    def __init__(
        self,
        device_index: int = 0,
        interval_s: float = 1.0,
        attrs: dict[str, str] | None = None,
        meter_name: str = "reactor.machine",
        metric_namespace: str = "reactor.machine",
    ) -> None:
        self._device_index = device_index
        self._interval_s = interval_s
        self._stop_evt = threading.Event()
        self._thread: threading.Thread | None = None

        meter = metrics.get_meter(meter_name)
        self._attrs: dict[str, str] = dict(attrs or {})

        # In-memory state read by .state — used for snapshot-style
        # aggregation at session-stop (avg/peak summaries etc.).
        self._last_vram_gb: float = 0.0
        self._last_gpu_util_pct: float = 0.0
        self._sample_count: int = 0
        self._vram_sum_gb: float = 0.0
        self._gpu_util_sum_pct: float = 0.0
        self._vram_peak_gb: float = 0.0

        meter.create_observable_gauge(
            name=f"{metric_namespace}.vram_used_gb",
            callbacks=[self._observe_vram],
            description="VRAM used (GB), sampled at 1Hz",
            unit="GB",
        )
        meter.create_observable_gauge(
            name=f"{metric_namespace}.gpu_util_pct",
            callbacks=[self._observe_gpu_util],
            description="GPU utilization (%), sampled at 1Hz",
            unit="%",
        )

    # ------------------------------------------------------------------
    # OTel callbacks
    # ------------------------------------------------------------------

    def _observe_vram(self, _options):  # type: ignore[no-untyped-def]
        from opentelemetry.metrics import Observation

        return [Observation(self._last_vram_gb, self._attrs)]

    def _observe_gpu_util(self, _options):  # type: ignore[no-untyped-def]
        from opentelemetry.metrics import Observation

        return [Observation(self._last_gpu_util_pct, self._attrs)]

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def start(self) -> None:
        if self._thread is not None:
            return
        self._thread = threading.Thread(
            target=self._run,
            name=f"nvml-sampler-{self._device_index}",
            daemon=True,
        )
        self._thread.start()

    def stop(self) -> None:
        self._stop_evt.set()
        thread = self._thread
        if thread is not None and thread.is_alive():
            thread.join(timeout=2.0)
        self._thread = None

    # ------------------------------------------------------------------
    # Sampling loop
    # ------------------------------------------------------------------

    def _run(self) -> None:
        try:
            import pynvml  # type: ignore
        except ImportError:
            logger.warning("pynvml not installed; NVML sampler disabled")
            return

        try:
            pynvml.nvmlInit()
        except Exception as err:
            logger.warning("nvmlInit failed", error=str(err))
            return

        # Once nvmlInit() succeeds we MUST pair it with nvmlShutdown(),
        # even if handle lookup below fails — otherwise NVML's library
        # state leaks for the lifetime of the process.
        try:
            try:
                handle = pynvml.nvmlDeviceGetHandleByIndex(self._device_index)
            except Exception as err:
                logger.warning(
                    "nvmlDeviceGetHandleByIndex failed",
                    device_index=self._device_index,
                    error=str(err),
                )
                return

            while not self._stop_evt.is_set():
                try:
                    mem = pynvml.nvmlDeviceGetMemoryInfo(handle)
                    util = pynvml.nvmlDeviceGetUtilizationRates(handle)
                    vram_gb = mem.used / 1e9
                    gpu_pct = float(util.gpu)
                    self._last_vram_gb = vram_gb
                    self._last_gpu_util_pct = gpu_pct
                    self._vram_sum_gb += vram_gb
                    self._gpu_util_sum_pct += gpu_pct
                    self._vram_peak_gb = max(self._vram_peak_gb, vram_gb)
                    self._sample_count += 1
                except Exception as err:
                    logger.debug("NVML sample failed", error=str(err))
                # Sleep on the stop-event so stop() unblocks immediately.
                self._stop_evt.wait(self._interval_s)
        finally:
            try:
                pynvml.nvmlShutdown()
            except Exception as err:
                logger.debug("nvmlShutdown failed", error=str(err))

    # ------------------------------------------------------------------
    # State accessor for snapshot aggregation
    # ------------------------------------------------------------------

    @property
    def state(self) -> dict[str, Any]:
        """Raw counter state — caller aggregates as they wish.

        Snapshot semantics: returns the current counters at call time. Safe
        to call from another thread; reads are atomic enough that the
        worst case is a sample number that doesn't quite match the sums
        (off by one). For the avg/peak rollups used by experiment-tracking
        that's fine.
        """
        return {
            "samples": self._sample_count,
            "vram_sum_gb": self._vram_sum_gb,
            "vram_peak_gb": self._vram_peak_gb,
            "gpu_util_sum_pct": self._gpu_util_sum_pct,
        }
