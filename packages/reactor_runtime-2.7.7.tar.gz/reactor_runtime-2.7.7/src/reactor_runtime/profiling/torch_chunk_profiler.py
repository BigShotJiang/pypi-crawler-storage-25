# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.

"""``torch.profiler`` wrapper that captures one inclusive chunk range.

Mirrors the lingbot-optimization (``wan/image2video_fast.py``) pattern:
``record_shapes=True``, lazy-start at the range opening chunk,
``profiler.step()`` per chunk, exports a Chrome trace + a
``key_averages().table(sort_by="cuda_time_total", row_limit=50)`` summary
at the range close. Result is data-equivalent to the upstream tool's
rank-0 trace.

Default-OFF: callers can construct unconditionally. The factory returns
a no-op instance unless ALL gates are satisfied:

- ``EXPERIMENT_ID`` env var is set (skill-driven launches only)
- ``EXPERIMENT_PROFILE_RANGE`` env var is set to ``"start,stop"``
  (inclusive chunk indices)
- ``rank == 0``  (other ranks return a no-op so we only ship one trace)

The gate is env-driven, not config-driven: profiling is a runtime
observability feature, not a model parameter. Model config.yml stays
agnostic; production containers (no ``EXPERIMENT_PROFILE_RANGE``) get
the no-op path with no branching needed on the model side.

Usage from a model's worker / inference loop::

    from reactor_runtime.profiling import ChunkRangeProfiler

    prof = ChunkRangeProfiler.from_env(rank=local_rank)
    for chunk_id in range(num_chunks):
        with prof.chunk(chunk_id):
            # existing inference call(s)

When the helper is no-op (the default), every method short-circuits with
zero overhead — safe to leave in production code paths.
"""

from __future__ import annotations

import contextlib
import gzip
import os
import shutil
import tempfile
from pathlib import Path
from typing import Any

from reactor_runtime.utils.log import get_logger

logger = get_logger(__name__)


class ChunkRangeProfiler:
    """One ``torch.profiler.profile`` instance scoped to ``[start, stop]``.

    Created via :meth:`from_env`. The factory decides whether to build a
    real profiler or a no-op based on env-var gating; callers don't need
    to repeat the gate logic per model.
    """

    def __init__(
        self,
        *,
        enabled: bool,
        target_range: tuple[int, int] | None,
        artifacts_dir: Path | None,
        experiment_id: str | None,
    ) -> None:
        self._enabled = enabled
        self._target_range = target_range
        self._artifacts_dir = artifacts_dir
        self._experiment_id = experiment_id
        # Lazily populated when chunk_index == target_range[0].
        self._profiler: Any = None
        # Set after :meth:`serialize_now` writes the trace.
        self._trace_path: Path | None = None
        # Snapshotted at chunk-range close (``__exit__``) but NOT
        # serialized — held here until the caller invokes
        # :meth:`serialize_now` from off the streaming hot path
        # (typically the model worker's ``drop_session`` handler).
        # Serializing inline would freeze the worker for ~16 s
        # (export_chrome_trace + key_averages + gzip walk every
        # captured event); doing it on a daemon thread spread the same
        # cost across the next ~3 chunks via GIL contention. Holding
        # the captured state and serializing AFTER the user has
        # disconnected — i.e. when streaming quality no longer matters
        # — gives zero in-session overhead at the cost of a ~15 s
        # tail at disconnect.
        self._captured_profiler: Any = None

    # ------------------------------------------------------------------
    # Factory
    # ------------------------------------------------------------------

    @classmethod
    def from_env(cls, *, rank: int) -> "ChunkRangeProfiler":
        """Build from the runtime environment + the current worker rank.

        Reads:
        - ``EXPERIMENT_ID`` — required, gates the whole helper
        - ``EXPERIMENT_PROFILE_RANGE`` — ``"start,stop"`` inclusive ints
        - ``EXPERIMENT_ARTIFACTS_DIR`` — optional override, defaults to
          ``/tmp/experiment-<id>/``

        Returns a no-op instance unless all gates pass.
        """
        noop = cls(
            enabled=False,
            target_range=None,
            artifacts_dir=None,
            experiment_id=None,
        )

        experiment_id = os.environ.get("EXPERIMENT_ID")
        if not experiment_id:
            return noop

        if rank != 0:
            # We only ship rank 0's trace through experiment-tracking;
            # ulysses workers are symmetric so one rank is representative
            # for the kernel-level view. Other ranks no-op.
            return noop

        raw_range = os.environ.get("EXPERIMENT_PROFILE_RANGE", "").strip()
        if not raw_range:
            return noop

        target_range = _parse_range_env(raw_range)
        if target_range is None:
            logger.warning(
                "EXPERIMENT_PROFILE_RANGE set but malformed; expected "
                "'start,stop' (inclusive ints). Skipping torch.profiler "
                "capture.",
                raw_range=raw_range,
                experiment_id=experiment_id,
            )
            return noop

        artifacts_dir = Path(
            os.environ.get("EXPERIMENT_ARTIFACTS_DIR")
            or f"/tmp/experiment-{experiment_id}"
        )
        return cls(
            enabled=True,
            target_range=target_range,
            artifacts_dir=artifacts_dir,
            experiment_id=experiment_id,
        )

    # ------------------------------------------------------------------
    # Per-chunk context manager — the only thing model code needs
    # ------------------------------------------------------------------

    @contextlib.contextmanager
    def chunk(self, chunk_index: int):
        """Wrap one chunk's inference. No-op when the helper isn't active.

        Side-effects when active:
        - On ``chunk_index == start``: opens ``torch.profiler.profile(...)``.
        - On every chunk inside the range: emits a
          ``torch.profiler.record_function(f"chunk_{chunk_index}")`` region
          and calls ``profiler.step()`` after the body.
        - On ``chunk_index == stop``: ``__exit__``, exports trace + summary
          to the artifacts dir, releases the profiler.
        """
        if not self._enabled or self._target_range is None:
            yield
            return

        start, stop = self._target_range

        # Lazy-start at the range opening.
        if chunk_index == start and self._profiler is None:
            self._open()

        # The record_function is a no-op when no profiler is active (e.g.
        # this is a chunk outside the target range), so it stays cheap.
        try:
            import torch.profiler  # type: ignore[import]

            with torch.profiler.record_function(f"chunk_{chunk_index}"):
                yield
        except ImportError:
            logger.warning("torch.profiler unavailable; ChunkRangeProfiler skipped")
            self._enabled = False
            yield
            return

        # Inside the range: step + maybe close.
        if self._profiler is not None and start <= chunk_index <= stop:
            try:
                self._profiler.step()
            except Exception:
                logger.exception("profiler.step() failed; closing the trace early")
                self._close_and_export()
                return
            if chunk_index == stop:
                self._close_and_export()

    @property
    def trace_path(self) -> Path | None:
        return self._trace_path

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _open(self) -> None:
        try:
            import torch  # noqa: F401  # type: ignore[import]
            from torch.profiler import ProfilerActivity, profile  # type: ignore[import]
        except ImportError:
            logger.warning(
                "torch.profiler unavailable; ChunkRangeProfiler degraded to no-op"
            )
            self._enabled = False
            return

        try:
            self._profiler = profile(
                activities=[ProfilerActivity.CPU, ProfilerActivity.CUDA],
                record_shapes=True,
                profile_memory=False,
                with_stack=False,
            )
            self._profiler.__enter__()
            logger.info(
                "torch.profiler started for chunk range",
                experiment_id=self._experiment_id,
                start=self._target_range[0] if self._target_range else None,
                stop=self._target_range[1] if self._target_range else None,
            )
        except Exception:
            logger.exception("torch.profiler open failed; continuing without")
            self._profiler = None
            self._enabled = False

    def _close_and_export(self) -> None:
        """Stop the profiler. Defer all serialization until
        :meth:`serialize_now`.

        Runs in the chunk handler thread, so it must be FAST — anything
        that takes >100 ms here shows up as a stutter in the live
        stream. torch.profiler's ``__exit__`` (kineto teardown +
        snapshot the captured event list) is the only required call;
        everything else (``export_chrome_trace``, ``key_averages``,
        gzip, summary) is held back to ``serialize_now``.

        The captured profiler object lives on ``self._captured_profiler``
        for the worker's ``drop_session`` handler to consume.
        """
        if self._profiler is None:
            return
        prof = self._profiler
        self._profiler = None
        try:
            import torch  # type: ignore[import]

            torch.cuda.synchronize()
            prof.__exit__(None, None, None)
        except Exception:
            logger.exception(
                "failed to stop torch.profiler in chunk handler; "
                "trace will not be exported"
            )
            return
        # Hand off to serialize_now via this instance attribute. The
        # captured kineto event list lives inside prof.kineto_results
        # at this point — fully snapshotted, safe to read from anywhere
        # later.
        self._captured_profiler = prof
        logger.info(
            "torch.profiler stopped; serialization deferred to session-stop",
            experiment_id=self._experiment_id,
        )

    def force_close(self) -> None:
        """Close any in-flight torch.profiler, leaving it ready for
        ``serialize_now`` (which then writes the partial trace).

        Called from the worker's session-teardown path (``drop_session``)
        to handle the case where the session ended mid-range — between
        the start chunk (which opened the profiler) and the stop chunk
        (which would have run ``_close_and_export``). Without this:

        - ``self._profiler`` leaks into the next session, ``_open`` is
          skipped on the next ``start`` chunk, and ``step()`` calls
          accumulate against the stale profiler.
        - The stale profiler keeps holding CUDA event handles open
          across sessions.
        - ``serialize_now`` is a no-op (``_captured_profiler`` is None),
          so nothing about this partial profile makes it to disk.

        After this method, the profiler instance is either fully shut
        down (``_captured_profiler`` populated → ``serialize_now`` will
        write a partial trace) or zeroed out (capture failed → next
        session starts cleanly).

        Safe to call multiple times. No-op when no profiler is open.
        """
        if self._profiler is None:
            # Either never opened (range wasn't reached this session) or
            # already closed via the normal stop-chunk path. Nothing to
            # do — let ``serialize_now`` handle ``_captured_profiler``.
            return
        logger.warning(
            "torch.profiler still open at session teardown — session ended "
            "mid-range. Closing now to produce a partial trace and unblock "
            "the next session.",
            experiment_id=self._experiment_id,
            target_range=self._target_range,
        )
        # Reuse _close_and_export's same code path so the partial trace
        # is exported via the normal route. cuda.synchronize +
        # profiler.__exit__ on this thread (the worker's drop_session
        # handler), then serialize_now downstream writes the partial
        # trace + summary.
        self._close_and_export()

    def serialize_now(self) -> None:
        """Synchronously write the chrome trace + summary to disk.

        Designed to run on the model worker's ``drop_session`` handler
        — i.e. AFTER the streaming session has ended. Blocking for the
        full ~15 s here is fine because no frames are being produced.

        Idempotent: safe to call multiple times or when no profile was
        captured (becomes a no-op).
        """
        prof = self._captured_profiler
        if prof is None or self._artifacts_dir is None:
            return
        self._captured_profiler = None
        artifacts_dir = self._artifacts_dir
        experiment_id = self._experiment_id

        try:
            artifacts_dir.mkdir(parents=True, exist_ok=True)
            # Canonical name: matches the /finalize endpoint's expected
            # blob name. The chunk range is embedded as metadata via
            # the record_function regions inside the trace itself.
            raw_path = (
                Path(tempfile.gettempdir())
                / f"experiment-{experiment_id}.pt.trace.json"
            )
            prof.export_chrome_trace(str(raw_path))
            gz_path = artifacts_dir / "profile.pt.trace.json.gz"
            # Stream-gzip rather than buffering — traces span a few MB
            # normally and can spike under heavy kernel counts.
            with open(raw_path, "rb") as src, gzip.open(gz_path, "wb") as dst:
                shutil.copyfileobj(src, dst)
            try:
                raw_path.unlink()
            except OSError:
                logger.debug(
                    "failed to remove temporary uncompressed trace file; continuing",
                    path=str(raw_path),
                )

            # Human-readable top-50 CUDA kernels summary — same format
            # the upstream lingbot-optimization tool writes.
            summary_path = artifacts_dir / "profile.summary.txt"
            try:
                summary_path.write_text(
                    prof.key_averages().table(sort_by="cuda_time_total", row_limit=50)
                )
            except Exception:
                logger.exception(
                    "failed to write profile.summary.txt; trace is still on disk"
                )

            self._trace_path = gz_path
            logger.info(
                "torch.profiler trace + summary written",
                trace=str(gz_path),
                summary=str(summary_path),
                trace_bytes=gz_path.stat().st_size,
            )
        except Exception:
            logger.exception("failed to serialize torch.profiler trace")


def _parse_range_env(raw: str) -> tuple[int, int] | None:
    """Parse ``EXPERIMENT_PROFILE_RANGE`` into ``(start, stop)`` or ``None``.

    Accepts ``"12,13"`` (comma-separated inclusive ints). Returns ``None``
    for any malformed input — wrong arity, non-int, or ``stop < start`` —
    so the caller can log + no-op rather than crash.
    """
    parts = [p.strip() for p in raw.split(",")]
    if len(parts) != 2:
        return None
    try:
        start, stop = int(parts[0]), int(parts[1])
    except ValueError:
        return None
    if stop < start:
        return None
    return start, stop
