# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""Per-session recorder: encoder, uploader, markers, and sink.

The runtime registers ``_on_bundle_sync`` on the model's
:class:`~reactor_runtime.interface.output_buffer.OutputBuffer`.
With ``skip_leading_black`` (default), gap-fill duplicates before the
first real frame are dropped; after that, keepalive duplicates may be
fed at a reduced rate during model idle periods.

``request_clip`` / ``request_recording`` resolve from local marker
state and return immediately (the SDK polls ``/clips`` for chunks).
"""

from __future__ import annotations

import math
import queue
import shutil
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Tuple
from urllib.parse import urlencode

import numpy as np

from reactor_runtime.recording.chunk_encoder import ChunkEncoder
from reactor_runtime.recording.chunk_uploader import ChunkUploader
from reactor_runtime.recording.config import RecordingConfig
from reactor_runtime.recording.markers import MarkerBookkeeper
from reactor_runtime.recording.sinks import RecordingSink
from reactor_runtime.transports.media import MediaBundle, TrackKind
from reactor_runtime.utils.log import get_logger

logger = get_logger(__name__)


class RecorderDisabledError(RuntimeError):
    """Raised by ``request_*`` when the recorder cannot serve the request.

    Reasons include: encoder crashed, recorder was never started, or
    recording is disabled by config.  Callers translate this into a
    ``clipFailed`` runtime message envelope.
    """


class NoMediaYetError(RecorderDisabledError):
    """``request_clip`` / ``request_recording`` before the first real frame.

    Distinct subclass so callers can disambiguate from encoder-crash
    failures without string matching.
    """


@dataclass(frozen=True)
class ClipResult:
    """Resolved outcome of a ``requestClip`` / ``requestRecording`` call.

    The runtime returns immediately on every request — it does *not*
    block until the in-progress chunk has been finalised.  Instead the
    response is a promise: ``end_marker`` reflects wall-clock at
    request time and may point inside a chunk ffmpeg is still
    writing.  The ``/clips`` manifest endpoint returns
    ``202 Retry-After`` while that chunk is in flight; the SDK polls
    until ``200``.

    ``start_marker`` / ``end_marker`` / ``now_marker`` are seconds on the
    recording timeline (``t=0`` at the first real frame when
    ``skip_leading_black`` is on).  ``predicted_ready_at_ms``
    is a **Unix epoch in milliseconds** — the runtime's estimate of
    when the clip will be servable by ``/clips``.  An epoch lets the
    client decide independently whether to keep polling (epoch is
    still in the near future), give up and surface a failure (epoch
    has passed by more than a configured slack — the runtime likely
    crashed mid-clip), or schedule a UX "ready at HH:MM:SS"
    indicator.  Matches JS ``Date.now()`` exactly.

    ``playlist_url`` is a **path-only** URL (e.g.
    ``/clips?session_id=…&start=…&end=…``).  The SDK is the only
    component that knows the absolute origin to prepend — the local
    HttpRuntime serves the path itself, the production Coordinator
    serves the same path on its public host.  Keeping the runtime
    out of the absolute-URL game means the Redis runtime never has
    to learn the production Coordinator URL, and the SDK never has
    to special-case local vs prod.
    """

    session_id: str
    kind: str
    start_marker: float
    end_marker: float
    now_marker: float
    predicted_ready_at_ms: int
    playlist_url: str
    first_real_frame_marker: Optional[float] = None

    def to_dict(self) -> dict:
        return {
            "session_id": self.session_id,
            "kind": self.kind,
            "start_marker": self.start_marker,
            "end_marker": self.end_marker,
            "now_marker": self.now_marker,
            "predicted_ready_at_ms": self.predicted_ready_at_ms,
            "playlist_url": self.playlist_url,
            "first_real_frame_marker": self.first_real_frame_marker,
        }


class SessionRecorder:
    """Per-session recorder built by the runtime at session start.

    The recorder is *best-effort*: an encoder crash flips
    ``self._disabled`` and any subsequent ``request_*`` raises
    :class:`RecorderDisabledError`.  Chunks that already made it into
    the sink remain accessible.
    """

    def __init__(
        self,
        config: RecordingConfig,
        session_id: str,
        sink: RecordingSink,
        video_track_name: str,
        audio_track_name: Optional[str],
        audio_sample_rate: Optional[int],
        work_dir: Path,
        keepalive_interval: float = 1.0,
    ) -> None:
        self._config = config
        self._session_id = session_id
        self._sink = sink
        self._video_track = video_track_name
        self._audio_track = audio_track_name
        self._audio_sample_rate = audio_sample_rate or 48_000
        self._work_dir = Path(work_dir)
        self._work_dir.mkdir(parents=True, exist_ok=True)

        self._markers = MarkerBookkeeper(
            anchor_at_first_frame=config.skip_leading_black
        )
        self._encoder = ChunkEncoder(
            output_dir=self._work_dir,
            config=config,
            has_audio=audio_track_name is not None,
            audio_sample_rate=audio_sample_rate,
        )
        self._uploader = ChunkUploader(
            encoder_dir=self._work_dir,
            sink=sink,
            markers=self._markers,
            chunk_seconds=float(config.chunk_seconds),
            encoder_alive=lambda: not self._encoder.failed,
        )
        self._started = False
        self._disabled = False

        self._feed_queue: "queue.Queue[Optional[Tuple[np.ndarray, Optional[np.ndarray]]]]" = queue.Queue(
            maxsize=4
        )
        self._feed_thread: Optional[threading.Thread] = None
        self._feed_stop = threading.Event()
        self._dropped_frames: int = 0

        self._keepalive_interval = max(0.0, float(keepalive_interval))
        self._last_fed_t: float = 0.0
        self._last_video_wall_t: float = 0.0
        self._audio_jitter_buf: List[np.ndarray] = []
        self._audio_buffered_samples: int = 0
        self._audio_buffer_cap_samples: int = self._audio_sample_rate

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    @property
    def session_id(self) -> str:
        return self._session_id

    @property
    def disabled(self) -> bool:
        return self._disabled or self._encoder.failed

    @property
    def chunk_seconds(self) -> int:
        return self._config.chunk_seconds

    def start(self) -> None:
        """Start the uploader + feed-worker threads; encoder spawns lazily."""
        if self._started:
            return
        self._uploader.start()
        self._feed_stop.clear()
        self._feed_thread = threading.Thread(
            target=self._feed_loop, name="recording-feed", daemon=True
        )
        self._feed_thread.start()
        self._started = True
        logger.info(
            "SessionRecorder started",
            session_id=self._session_id,
            work_dir=str(self._work_dir),
        )

    def stop(self) -> None:
        """Tear down feed worker, encoder, and uploader.

        Emits a structured ``SessionRecorder stopped`` log with
        ``clean=…`` and per-thread leak flags so failed joins surface
        in monitoring instead of leaking ffmpeg + uploader threads
        silently.
        """
        if not self._started:
            return
        self._disabled = True
        self._feed_stop.set()
        try:
            self._feed_queue.put_nowait(None)
        except queue.Full:
            pass
        feed_thread = self._feed_thread
        self._feed_thread = None
        self._encoder.stop()
        if feed_thread is not None:
            feed_thread.join(timeout=2.0)
        feed_leaked = feed_thread is not None and feed_thread.is_alive()
        uploader_clean = self._uploader.stop(flush_remaining=True)
        self._started = False
        try:
            shutil.rmtree(self._work_dir, ignore_errors=True)
        except Exception:
            logger.exception(
                "Failed to clean encoder work dir; leaking",
                work_dir=str(self._work_dir),
            )
        clean = not feed_leaked and uploader_clean
        log = logger.info if clean else logger.error
        log(
            "SessionRecorder stopped",
            session_id=self._session_id,
            last_uploaded_chunk_idx=self._markers.last_uploaded_chunk_idx,
            dropped=self._dropped_frames,
            clean=clean,
            feed_leaked=feed_leaked,
            uploader_leaked=not uploader_clean,
        )

    # ------------------------------------------------------------------
    # OutputBuffer integration
    # ------------------------------------------------------------------

    def _on_bundle_sync(
        self,
        bundle: MediaBundle,
        duplicate: bool,
        is_fresh_black: bool = False,
    ) -> None:
        """Enqueue a bundle for the feed worker; non-blocking.

        Session-boundary synthesised black (``is_fresh_black``) is not
        real model output and is invisible to the recording timeline:
        no feed-queue write, no ``mark_first_real_frame`` consideration.
        """
        if self._disabled or not self._started:
            return
        if is_fresh_black:
            return
        now = time.monotonic()
        if duplicate:
            if self._config.skip_leading_black and not self._markers.recording_started:
                return
            if (
                self._keepalive_interval <= 0.0
                or (now - self._last_fed_t) < self._keepalive_interval
            ):
                return
        video_td = bundle.tracks.get(self._video_track)
        if video_td is None:
            videos = bundle.get_tracks_by_kind(TrackKind.VIDEO)
            if not videos:
                return
            video_td = videos[0]
        audio_data: Optional[np.ndarray] = None
        if self._audio_track is not None:
            audio_td = bundle.tracks.get(self._audio_track)
            if audio_td is not None:
                audio_data = audio_td.data
        video_data = video_td.data
        if (
            duplicate
            and not self._config.skip_leading_black
            and self._markers.first_real_frame_marker is None
        ):
            # Legacy mode still records pre-roll; zero-fill so the
            # OutputBuffer's per-model cache cannot leak the previous
            # session's last frame into chunk 0.
            video_data = np.zeros_like(video_data)
            if audio_data is not None:
                audio_data = np.zeros_like(audio_data)
        try:
            self._feed_queue.put_nowait((video_data, audio_data))
        except queue.Full:
            self._dropped_frames += 1
            if self._dropped_frames == 1 or self._dropped_frames % 300 == 0:
                logger.warning(
                    "Recorder feed queue full; dropping frame to keep wire path unblocked",
                    dropped_total=self._dropped_frames,
                )
            return
        if not duplicate:
            self._markers.mark_first_real_frame()
        self._last_fed_t = now

    def _feed_loop(self) -> None:
        """Drain ``_feed_queue`` into ffmpeg; disable on encoder failure."""
        while True:
            if self._feed_stop.is_set() and self._feed_queue.empty():
                return
            try:
                item = self._feed_queue.get(timeout=0.1)
            except queue.Empty:
                continue
            if item is None:
                return
            video, audio = item
            now = time.monotonic()
            dt = (
                now - self._last_video_wall_t
                if self._last_video_wall_t > 0.0
                else 1.0 / 30.0
            )
            self._last_video_wall_t = now
            try:
                self._encoder.feed_video(video)
                if self._audio_track is not None:
                    target_samples = max(0, int(round(self._audio_sample_rate * dt)))
                    av_chunk = self._next_audio_chunk(audio, target_samples)
                    if av_chunk is not None:
                        self._encoder.feed_audio(av_chunk)
            except Exception:
                logger.exception(
                    "Recorder encoder feed failed; disabling for this session"
                )
                self._disabled = True
                try:
                    while True:
                        self._feed_queue.get_nowait()
                except queue.Empty:
                    pass
                return

    def _next_audio_chunk(
        self, model_audio: Optional[np.ndarray], target: int
    ) -> Optional[np.ndarray]:
        """Produce exactly ``target`` samples for ffmpeg.

        ``target`` is computed by the caller as
        ``round(audio_sample_rate * dt_since_previous_video_frame)`` so
        each batch represents exactly the same wall-clock interval as
        the video frame it accompanies.  Echoes model audio when
        present, silence-pads on underrun, and queues surplus for the
        next tick.
        """
        if target <= 0:
            return None

        if model_audio is not None and model_audio.size > 0:
            flat = np.ascontiguousarray(model_audio, dtype=np.int16).reshape(-1)
            self._audio_jitter_buf.append(flat)
            self._audio_buffered_samples += flat.size

        while self._audio_buffered_samples > self._audio_buffer_cap_samples:
            head = self._audio_jitter_buf[0]
            drop = self._audio_buffered_samples - self._audio_buffer_cap_samples
            if head.size <= drop:
                self._audio_jitter_buf.pop(0)
                self._audio_buffered_samples -= head.size
            else:
                self._audio_jitter_buf[0] = head[drop:]
                self._audio_buffered_samples -= drop

        out = np.empty(target, dtype=np.int16)
        filled = 0
        while filled < target and self._audio_jitter_buf:
            head = self._audio_jitter_buf[0]
            take = min(head.size, target - filled)
            out[filled : filled + take] = head[:take]
            filled += take
            if take == head.size:
                self._audio_jitter_buf.pop(0)
            else:
                self._audio_jitter_buf[0] = head[take:]
            self._audio_buffered_samples -= take
        if filled < target:
            out[filled:] = 0  # silence pad
        return out.reshape(1, -1)

    # ------------------------------------------------------------------
    # Clip / recording requests
    # ------------------------------------------------------------------

    def request_clip(self, duration_seconds: float, kind: str = "snap") -> ClipResult:
        """Resolve a snap-clip request to markers + a playlist URL.

        Returns immediately with ``end_marker = now_marker`` — i.e. the
        promise includes the chunk ffmpeg is currently writing.  The
        ``/clips`` manifest endpoint will ``202 Retry-After`` until
        that chunk lands; the SDK polls until ``200``.

        """
        if self.disabled:
            raise RecorderDisabledError("recorder disabled or encoder crashed")
        capped = min(float(duration_seconds), float(self._config.clip_max_seconds))
        if capped <= 0:
            raise ValueError("duration_seconds must be positive")
        if not self._markers.recording_started:
            raise NoMediaYetError("no media generated yet")
        start, end = self._markers.compute_clip_range(capped)
        return self._build_result(kind=kind, start=start, end=end)

    def request_recording(self) -> ClipResult:
        """Resolve a full-recording request; ``end = now``.

        Same promise-then-poll semantics as :meth:`request_clip`.
        """
        if self.disabled:
            raise RecorderDisabledError("recorder disabled or encoder crashed")
        if not self._markers.recording_started:
            raise NoMediaYetError("no media generated yet")
        start, end = self._markers.compute_recording_range()
        return self._build_result(kind="recording", start=start, end=end)

    def _build_result(self, kind: str, start: float, end: float) -> ClipResult:
        now = self._markers.now_marker()
        cs = float(self._config.chunk_seconds)
        if cs > 0:
            next_boundary = (math.floor(now / cs) + 1) * cs
            wait_s = max(0.0, next_boundary - now)
        else:
            wait_s = 0.0
        predicted_ready_at_ms = int(round((time.time() + wait_s) * 1000))
        query = urlencode(
            {
                "session_id": self._session_id,
                "start": f"{start:.3f}",
                "end": f"{end:.3f}",
            }
        )
        playlist_url = f"/clips?{query}"
        return ClipResult(
            session_id=self._session_id,
            kind=kind,
            start_marker=start,
            end_marker=end,
            now_marker=now,
            predicted_ready_at_ms=predicted_ready_at_ms,
            playlist_url=playlist_url,
            first_real_frame_marker=self._markers.first_real_frame_marker,
        )
