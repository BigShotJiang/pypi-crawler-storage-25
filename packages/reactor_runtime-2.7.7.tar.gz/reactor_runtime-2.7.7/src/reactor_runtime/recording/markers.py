# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""Wall-clock marker bookkeeping for the recording subsystem.

Markers are wall-clock seconds aligned with ffmpeg's
``-use_wallclock_as_timestamps`` input.  When ``anchor_at_first_frame``
is set (``RecordingConfig.skip_leading_black``), ``t=0`` is the first
real frame fed to the encoder, not recorder arm time.

The encoder additionally applies ``setpts=PTS-STARTPTS`` on the video
output (REA-2482), which zeroes media PTS at the *first packet fed* to
ffmpeg.  With ``anchor_at_first_frame=True`` that's the same instant
the bookkeeper anchors on, so markers and media share an origin.  With
``anchor_at_first_frame=False`` the bookkeeper's origin stays at
recorder arm time while the media origin slips to the first emission
tick; the gap is typically a single frame interval but can be longer
if the OutputBuffer hadn't started emitting yet at arm time.  See
``RecordingConfig.skip_leading_black`` for the user-facing contract.
"""

from __future__ import annotations

import threading
import time
from typing import Optional, Tuple


class MarkerBookkeeper:
    """Tracks ``now_marker`` and the latest fully-uploaded chunk index.

    Thread-safe — ``mark_chunk_uploaded`` is called from the uploader
    thread while ``compute_*_range`` is called from the runtime's
    asyncio loop on the inbound runtime-message dispatch path.
    """

    def __init__(self, *, anchor_at_first_frame: bool = False) -> None:
        self._anchor_at_first_frame = anchor_at_first_frame
        self._session_start = time.monotonic()
        self._last_uploaded_chunk_idx: int = -1
        self._recording_start: Optional[float] = None
        self._first_real_frame_marker: Optional[float] = None
        self._lock = threading.Lock()

    def now_marker(self) -> float:
        """Seconds since the active timeline origin."""
        with self._lock:
            origin = (
                self._recording_start
                if self._recording_start is not None
                else self._session_start
            )
        return time.monotonic() - origin

    @property
    def last_uploaded_chunk_idx(self) -> int:
        """Index of the most recent chunk known to be in the sink, or -1."""
        with self._lock:
            return self._last_uploaded_chunk_idx

    @property
    def first_real_frame_marker(self) -> Optional[float]:
        """Session-relative time of the first real frame, or ``None``."""
        with self._lock:
            return self._first_real_frame_marker

    @property
    def recording_started(self) -> bool:
        """False until the first real frame when ``anchor_at_first_frame``."""
        if not self._anchor_at_first_frame:
            return True
        with self._lock:
            return self._recording_start is not None

    def mark_chunk_uploaded(self, idx: int) -> None:
        """Advance ``last_uploaded_chunk_idx`` monotonically."""
        with self._lock:
            if idx > self._last_uploaded_chunk_idx:
                self._last_uploaded_chunk_idx = idx

    def mark_first_real_frame(self) -> None:
        """Latch the first real frame; re-anchor timeline when configured."""
        with self._lock:
            if self._first_real_frame_marker is None:
                self._first_real_frame_marker = time.monotonic() - self._session_start
            if self._anchor_at_first_frame and self._recording_start is None:
                self._recording_start = time.monotonic()

    def compute_clip_range(self, duration_seconds: float) -> Tuple[float, float]:
        """``(start_marker, end_marker)`` for a snap clip ending at ``now_marker``."""
        end_marker = self.now_marker()
        start_marker = max(0.0, end_marker - duration_seconds)
        return start_marker, end_marker

    def compute_recording_range(self) -> Tuple[float, float]:
        """``(0, now_marker)`` for a full-session recording request."""
        end_marker = self.now_marker()
        return 0.0, end_marker
