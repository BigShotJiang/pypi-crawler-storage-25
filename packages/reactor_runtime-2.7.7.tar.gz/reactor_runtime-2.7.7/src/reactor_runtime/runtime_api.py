# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""
Runtime base class — manages session lifecycle and wires the model
interface to transports.
"""

import argparse
import asyncio
import json
import math
import os
import signal
import threading
import uuid
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Optional

from reactor_runtime.schema import ModelSchema
from reactor_runtime.config import ReactorConfig
from reactor_runtime.interface.events.connected import Connected, Disconnected
from reactor_runtime.interface.events.event import EVENT_REGISTRY
from reactor_runtime.interface.events.upload import FileUploaded
from reactor_runtime.interface.upload import UploadedFile
from reactor_runtime.interface.internal.reactor_core import ReactorCore

if TYPE_CHECKING:
    from reactor_runtime.recording import SessionRecorder
from reactor_runtime.schema_validator import SchemaValidator
from reactor_runtime.model_state import ModelEvent, ModelState, ModelStateMachine
from reactor_runtime.transports import WebRTCTransport
from reactor_runtime.transports.media import MediaBundle
from reactor_runtime.profiling.backends.file import FileProfilerBackend
from reactor_runtime.profiling.backends.otlp import OTLPProfilerBackend
from reactor_runtime.profiling.profiler import Profiler
from reactor_runtime.profiling.singleton import get_profiler, set_profiler
from reactor_runtime.utils.loader import build_model
from reactor_runtime.utils.messages import (
    ApplicationMessage,
    RuntimeMessage,
    RuntimeMessageType,
)
from reactor_runtime.utils.log import get_logger

logger = get_logger(__name__)

_IDLING_INTERVAL_ENV_VAR = "IDLING_INTERVAL_SECONDS"
_DEFAULT_IDLING_INTERVAL = 30.0

_PING_TIMEOUT_ENV_VAR = "WEBRTC_CLIENT_PING_TIMEOUT_SECONDS"
_DEFAULT_PING_TIMEOUT = 20.0


# ---------------------------------------------------------------------------
# RuntimeConfig
# ---------------------------------------------------------------------------


@dataclass
class RuntimeConfig:
    """Base configuration for all runtime implementations.

    Each runtime implementation should extend this with additional
    fields (e.g. Redis host, HTTP port).
    """

    reactor_config: ReactorConfig

    node_id: str = field(init=False)
    machine_id: str = field(init=False)

    orphan_timeout: float = (
        30.0  # Seconds to wait before stopping session when WebRTC disconnects
    )

    # Idling interval in seconds for sending IDLING events when in READY state.
    # Priority: ENV > CLI > default. Set to None to use default.
    idling_interval: Optional[float] = None

    # WebRTC client-ping watchdog timeout (seconds). Priority: ENV > CLI > default.
    # Resolved to a concrete float in __post_init__; non-positive disables the watchdog.
    ping_timeout: Optional[float] = None

    profiling_output_dir: Optional[str] = None

    def __post_init__(self) -> None:
        """Build node_id from model name and machine identifier."""
        name = self.reactor_config.name or "reactor"
        self.machine_id = os.getenv("HOSTNAME", str(uuid.uuid4()))
        self.node_id = f"{name}@{self.machine_id}"

        # Resolve idling_interval: ENV > CLI > default
        env_val = os.getenv(_IDLING_INTERVAL_ENV_VAR)
        if env_val:
            try:
                self.idling_interval = float(env_val)
            except ValueError:
                logger.warning(
                    "Invalid idling interval env value, falling back to default",
                    env_var=_IDLING_INTERVAL_ENV_VAR,
                    value=env_val,
                )

        # Validate positive value, fall back to default if invalid
        if self.idling_interval is not None and self.idling_interval <= 0:
            self.idling_interval = None

        # Apply default if still None
        if self.idling_interval is None:
            self.idling_interval = _DEFAULT_IDLING_INTERVAL

        # Resolve ping_timeout: ENV > CLI > default (reject non-finite floats)
        resolved_ping: Optional[float] = None
        ping_env = os.getenv(_PING_TIMEOUT_ENV_VAR)
        if ping_env:
            try:
                env_ping = float(ping_env)
            except ValueError:
                logger.warning(
                    "Invalid WebRTC client ping timeout env value, falling back to CLI/default",
                    env_var=_PING_TIMEOUT_ENV_VAR,
                    value=ping_env,
                )
            else:
                if math.isfinite(env_ping):
                    resolved_ping = env_ping
                else:
                    logger.warning(
                        "Non-finite WebRTC client ping timeout env value, falling back to CLI/default",
                        env_var=_PING_TIMEOUT_ENV_VAR,
                        value=ping_env,
                    )
        if resolved_ping is None:
            if self.ping_timeout is not None:
                if math.isfinite(self.ping_timeout):
                    resolved_ping = self.ping_timeout
                else:
                    logger.warning(
                        "Non-finite WebRTC client ping timeout from CLI/config, falling back to default",
                        value=self.ping_timeout,
                    )
            if resolved_ping is None:
                resolved_ping = _DEFAULT_PING_TIMEOUT
        if resolved_ping < 0:
            resolved_ping = 0.0
        self.ping_timeout = resolved_ping

    @staticmethod
    def parser() -> argparse.ArgumentParser:
        """Return an argument parser for runtime-specific CLI arguments.

        The parsed args will be used to construct the config.

        Returns:
            argparse.ArgumentParser with runtime-specific arguments
        """
        parser = argparse.ArgumentParser(add_help=False)
        parser.add_argument(
            "--detailed-logs",
            action=argparse.BooleanOptionalAction,
            default=False,
            dest="detailed_logs",
            help="Show timestamps and full log detail. Default: off.",
        )
        parser.add_argument(
            "--orphan-timeout",
            type=float,
            default=30.0,
            help="Seconds before stopping session when no client connects. Default: 30.0. Set to 0 to disable.",
        )
        parser.add_argument(
            "--ping-timeout",
            type=float,
            default=None,
            dest="ping_timeout",
            help=(
                "Seconds without a client ping before declaring the connection stale "
                f"({_PING_TIMEOUT_ENV_VAR} env overrides). "
                f"Default: {_DEFAULT_PING_TIMEOUT}. Set to 0 to disable."
            ),
        )
        parser.add_argument(
            "--idling-interval",
            type=float,
            default=None,
            help=f"Idling event interval ({_IDLING_INTERVAL_ENV_VAR} env overrides). "
            f"Default: {_DEFAULT_IDLING_INTERVAL}s",
        )
        parser.add_argument(
            "--profiling-dir",
            type=str,
            dest="profiling_output_dir",
            default=None,
            help="Write profiling artifacts (JSON/CSV/MD) to this directory. "
            "When omitted, OTLP export is used automatically if available.",
        )
        return parser


# ---------------------------------------------------------------------------
# Runtime
# ---------------------------------------------------------------------------


class Runtime(ModelStateMachine, ABC):
    """Base runtime — manages session state and wires the model to transports.

    Subclasses implement the abstract transport methods and ``run()``.
    """

    def __init__(self, config: RuntimeConfig) -> None:
        """Initialize the runtime with a configuration object.

        Note: This does NOT load the model. Call ``await load()`` after
        construction to load the model asynchronously.

        Args:
            config: RuntimeConfig containing model information and runtime-specific settings.
        """
        super().__init__(ModelState.CREATED)
        self.config = config
        self.model: Optional[ReactorCore] = None
        self.model_loaded = False
        self.model_thread: Optional[threading.Thread] = None
        self.loop = asyncio.get_running_loop()

        # Recording subsystem.  Subclasses set this in their session-start
        # hook (HttpRuntime today, RedisRuntime later) and clear it in the
        # stop-session hook.  The base ``_handle_runtime_message`` dispatch
        # for ``requestClip`` / ``requestRecording`` reads this slot, so
        # the recorder lifecycle is owned per-runtime but the wire contract
        # is shared.
        self.recorder: Optional["SessionRecorder"] = None

        # Orphan timeout task - stops session if no client connection for too long
        self._orphan_task: Optional[asyncio.Task] = None

        # Idling task - sends periodic IDLING events when in READY state
        self._idling_task: Optional[asyncio.Task] = None

        # Trickle-ICE buffer
        # Browsers start emitting ICE candidates as soon as
        # ``setLocalDescription`` runs — typically *before* the SDP
        # offer reaches the runtime, and certainly before the WebRTC
        # transport has finished being created in the background.
        # Candidates that arrive in that window are buffered here and
        # replayed onto the freshly-installed transport when the runtime
        # enters STREAMING.
        self._pending_ice_candidates: list[
            tuple[str, Optional[str], Optional[int]]
        ] = []
        self._ice_candidate_lock: asyncio.Lock = asyncio.Lock()

        # Graceful shutdown state (for SIGTERM handling)
        self._shutdown_pending: bool = False
        self._shutdown_event: asyncio.Event = asyncio.Event()
        self._setup_signal_handlers()

        # Start idling loop (runs continuously, only sends events when in READY state)
        self._start_idling_loop()

    # -----------------------------------------------------------------
    # Model loading
    # -----------------------------------------------------------------

    async def load(self) -> None:
        """Load the model asynchronously, then start emission and run().

        Runs _load_and_start() in a separate thread and waits for it to complete
        without blocking the event loop. Sends INITIALIZATION_SUCCESS or
        INITIALIZATION_FAIL event based on the result. On failure the state
        machine transitions to TERMINATED which triggers runtime shutdown.
        """
        try:
            await asyncio.to_thread(self._load_and_start)
        except Exception as e:
            logger.critical("Failed to load model", exc_info=True, error=e)
            self.send(ModelEvent.INITIALIZATION_FAIL)
            return

        self.send(ModelEvent.INITIALIZATION_SUCCESS)

    def _load_and_start(self) -> None:
        """Load, wire, and start the model (runs in a thread)."""
        self._init_profiler()

        self.model = build_model(self.config.reactor_config)
        self.model_loaded = True

        self.model.output_buffer.add_callback(self._send_out_app_bundle_sync)
        self.model._send_fn = self._send_out_app_message_sync

        self.model.output_buffer.start_emission()

        self.model_thread = threading.Thread(
            target=self.model._start, daemon=True, name="model-run"
        )
        self.model_thread.start()

        logger.debug(
            "Model loaded, emission started, run() thread spawned",
            model=self.config.reactor_config.model,
        )

    def _init_profiler(self) -> None:
        """Initialise the process-level profiler singleton.

        Backend selection priority (matches origin/main behaviour):
        1. OTLP backend if ReactorMachineMetrics is available and enabled
        2. File backend if ``profiling_output_dir`` is set via ``--profiling-dir``
        3. NoOpProfiler (profiling disabled — the default singleton)
        """
        try:
            from reactor_runtime.runtimes._redis.reactor_machine_metrics import (
                ReactorMachineMetrics,
            )

            if ReactorMachineMetrics.is_enabled():
                set_profiler(Profiler(OTLPProfilerBackend()))
                logger.info("Profiler initialised with OTLP backend")
                return
        except Exception as e:
            logger.debug("OTLP profiler backend unavailable", error=e)

        if self.config.profiling_output_dir is not None:
            try:
                backend = FileProfilerBackend(self.config.profiling_output_dir)
                set_profiler(Profiler(backend))
                logger.info(
                    "Profiler initialised with file backend",
                    output_dir=self.config.profiling_output_dir,
                )
            except Exception as e:
                logger.warning("Failed to initialise file profiler", error=e)

    # -----------------------------------------------------------------
    # Outbound helpers (sync wrappers for the async transport)
    # -----------------------------------------------------------------

    def _send_out_app_message_sync(self, data: dict) -> None:
        """Send an application message from the model to the client."""
        wrapped = ApplicationMessage(data=data).model_dump()
        if self.loop.is_closed():
            return
        try:
            asyncio.run_coroutine_threadsafe(
                self.send_out_app_message(wrapped), self.loop
            )
        except Exception as e:
            logger.warning("Failed to send app message", error=e)

    def _send_out_app_bundle_sync(
        self,
        media_bundle: MediaBundle,
        duplicate: bool,
        is_fresh_black: bool = False,
    ) -> None:
        """OutputBuffer callback — forward real frames + session-boundary black.

        Drops keepalive duplicates (the wire track already shows that
        frame) but forwards ``is_fresh_black`` bundles so the client
        transitions off the previous session's last frame on flush.
        Silently fails if the event loop is closed (shutdown).
        """
        if duplicate and not is_fresh_black:
            return
        if self.loop.is_closed():
            return
        try:
            asyncio.run_coroutine_threadsafe(
                self.send_out_app_bundle(media_bundle, duplicate),
                self.loop,
            )
        except RuntimeError:
            pass

    # -----------------------------------------------------------------
    # State machine enter handlers
    # -----------------------------------------------------------------

    def on_enter_STREAMING(self, previous_state: ModelState) -> None:
        """Push Connected event to the model on first connect only.

        Also replays any ICE candidates that were buffered while the
        WebRTC transport was still being created — see
        :meth:`add_ice_candidate`.
        """
        self._cancel_orphan_timeout()

        # Replay buffered trickle ICE candidates onto the freshly
        # installed transport. Scheduled via create_task because
        # on_enter_* hooks are called synchronously from send().
        asyncio.create_task(self._flush_pending_ice_candidates())

        if previous_state == ModelState.WAITING:
            if self.model is not None:
                self.model._push_event(Connected())
                logger.info("Pushed Connected event to model")
        else:
            logger.info("Reconnection (ORPHANED->STREAMING), no Connected event")

    def on_enter_ORPHANED(self, previous_state: ModelState) -> None:
        """Handler called when the session enters the ORPHANED state.
        Starts the orphan timeout and discards any buffered trickle ICE
        candidates — they belonged to the now-dead transport.
        """
        self._clear_pending_ice_candidates()
        self._start_orphan_timeout()

    def on_enter_WAITING(self, previous_state: ModelState) -> None:
        """Handler called when the session enters the WAITING state.
        Starts the orphan timeout.
        """
        self._start_orphan_timeout()

    def on_enter_TERMINATED(self, previous_state: ModelState) -> None:
        """TERMINATED means the runtime should exit."""
        self._shutdown_event.set()

    def on_enter_READY(self, previous_state: ModelState) -> None:
        """Handler called when entering the READY state.

        Drops any leftover trickle ICE candidates (defensive — there
        should be none outside of an active session) and triggers the
        shutdown event if SIGTERM was received earlier.
        """
        self._clear_pending_ice_candidates()
        if self._shutdown_pending:
            self._shutdown_event.set()

    def on_enter_CLOSING(self, previous_state: ModelState) -> None:
        """Tear down runtime session resources and notify the model.

        Pushes a ``Disconnected`` event to the model queue, then
        signals ``CLEANUP_COMPLETE`` to release runtime-level session
        resources (timeouts, transport state).  The model processes
        ``@disconnected`` asynchronously on its own thread.
        """
        self._cancel_orphan_timeout()
        self._clear_pending_ice_candidates()

        if self.model is not None:
            self.model._push_event(Disconnected())
            logger.info("Pushed Disconnected event to model")

        self.loop.call_soon_threadsafe(self.send, ModelEvent.CLEANUP_COMPLETE)

    # -----------------------------------------------------------------
    # Schema validator (lazy)
    # -----------------------------------------------------------------

    _schema_validator: Optional[SchemaValidator] = None

    def _get_schema_validator(self) -> SchemaValidator:
        if self._schema_validator is None:
            schema = ModelSchema.from_config(
                self.config.reactor_config,
                model_cls=type(self.model) if self.model else None,
            )
            self._schema_validator = SchemaValidator(schema.to_openapi())
        return self._schema_validator

    # -----------------------------------------------------------------
    # Inbound data channel messages
    # -----------------------------------------------------------------

    async def _handle_incoming_data_channel_message(self, message: str) -> None:
        """Common handler for incoming data channel messages.

        Parses the outer envelope ``{ scope: "application"|"runtime", data: {...} }``
        and routes to the appropriate handler.

        Subclasses should call this from their data channel message event handler.
        """
        if not self.session_running:
            return

        try:
            data = json.loads(message)
            scope = data.get("scope")
            inner = data.get("data", {})

            if scope == "runtime":
                await self._handle_runtime_message(inner)
            elif scope == "application":
                await self._handle_application_message(inner)
            else:
                logger.warning("Dropping message with unrecognized scope", scope=scope)
        except json.JSONDecodeError:
            logger.warning("Non-JSON data channel message", raw=message)

    async def _handle_runtime_message(self, data: dict) -> None:
        """Handle incoming runtime-layer messages."""
        msg_type = data.get("type")
        if msg_type == RuntimeMessageType.REQUEST_SCHEMA:
            if self.model:
                schema = ModelSchema.from_config(
                    self.config.reactor_config,
                    model_cls=type(self.model),
                )
                inner = {
                    "type": RuntimeMessageType.MODEL_SCHEMA,
                    "data": schema.to_openapi(),
                }
                wrapped = RuntimeMessage(data=inner).model_dump()
                await self.send_out_runtime_message(wrapped)
        elif msg_type == RuntimeMessageType.REQUEST_CAPABILITIES:
            logger.warning("requestCapabilities is deprecated, use requestSchema")
            if self.model:
                schema = ModelSchema.from_config(
                    self.config.reactor_config,
                    model_cls=type(self.model),
                )
                inner = {
                    "type": RuntimeMessageType.MODEL_CAPABILITIES,
                    "data": schema.to_legacy_tracks_only(),
                }
                wrapped = RuntimeMessage(data=inner).model_dump()
                await self.send_out_runtime_message(wrapped)
        elif msg_type == RuntimeMessageType.PING:
            self._on_ping_received()
        elif msg_type == RuntimeMessageType.FILE_UPLOADED:
            await self._handle_file_uploaded(data.get("data", {}))
        elif msg_type == RuntimeMessageType.REQUEST_CLIP:
            await self._handle_request_clip(data.get("data", {}))
        elif msg_type == RuntimeMessageType.REQUEST_RECORDING:
            await self._handle_request_recording(data.get("data", {}))
        else:
            logger.warning("Unknown runtime message type", msg_type=msg_type)

    async def _handle_request_clip(self, data: dict) -> None:
        """Resolve a ``requestClip`` message to ``clipReady`` / ``clipFailed``.

        ``recorder.request_clip`` returns immediately with a *promise*
        whose ``end_marker`` may point inside a chunk ffmpeg is still
        writing; the SDK polls the ``/clips`` manifest endpoint
        (``202 Retry-After`` → ``200``) until the chunk lands.  No
        executor needed — this is a marker-math computation.
        """
        from reactor_runtime.recording import RecorderDisabledError

        if self.recorder is None:
            await self._send_clip_failed("recorder disabled")
            return
        try:
            duration = float(data.get("duration_seconds", 0) or 0)
        except (TypeError, ValueError):
            await self._send_clip_failed("invalid duration_seconds")
            return
        try:
            result = self.recorder.request_clip(duration_seconds=duration)
        except RecorderDisabledError as exc:
            await self._send_clip_failed(str(exc) or "recorder disabled")
            return
        except ValueError as exc:
            await self._send_clip_failed(str(exc))
            return
        except Exception as exc:
            logger.exception("requestClip failed")
            await self._send_clip_failed(f"internal error: {exc}")
            return
        await self._send_clip_ready(result.to_dict())

    async def _handle_request_recording(self, _data: dict) -> None:
        """Resolve a ``requestRecording`` message to ``clipReady`` / ``clipFailed``.

        Same promise-then-poll semantics as ``requestClip``.
        """
        from reactor_runtime.recording import RecorderDisabledError

        if self.recorder is None:
            await self._send_clip_failed("recorder disabled")
            return
        try:
            result = self.recorder.request_recording()
        except RecorderDisabledError as exc:
            await self._send_clip_failed(str(exc) or "recorder disabled")
            return
        except Exception as exc:
            logger.exception("requestRecording failed")
            await self._send_clip_failed(f"internal error: {exc}")
            return
        await self._send_clip_ready(result.to_dict())

    async def _send_clip_ready(self, payload: dict) -> None:
        wrapped = RuntimeMessage(
            data={"type": RuntimeMessageType.CLIP_READY, "data": payload}
        ).model_dump()
        await self.send_out_runtime_message(wrapped)

    async def _send_clip_failed(self, reason: str) -> None:
        wrapped = RuntimeMessage(
            data={
                "type": RuntimeMessageType.CLIP_FAILED,
                "data": {"reason": reason},
            }
        ).model_dump()
        await self.send_out_runtime_message(wrapped)

    async def _handle_application_message(self, data: dict) -> None:
        """Centralized validation gateway for inbound application messages.

        All validation happens here. The model interface layer downstream
        receives pre-validated, typed objects and does zero validation.
        """
        cmd_name = data.get("type")
        cmd_args = data.get("data") or {}

        if not cmd_name or self.model is None:
            return

        event_cls = EVENT_REGISTRY.get(cmd_name)
        if event_cls is None:
            logger.warning("Unknown event", name=cmd_name)
            return

        validator = self._get_schema_validator()

        legacy_uploads = data.get("uploads")
        if isinstance(legacy_uploads, dict):
            for param_name, meta in legacy_uploads.items():
                if isinstance(meta, dict) and param_name not in cmd_args:
                    cmd_args[param_name] = meta

        validated, error = validator.validate(cmd_name, cmd_args)
        if error is not None:
            logger.warning("Schema validation failed", event=cmd_name, error=error)
            return

        upload_fields = validator.get_upload_fields(cmd_name)
        if upload_fields:
            for param_name in upload_fields:
                ref = validated.get(param_name)
                if not isinstance(ref, dict):
                    continue
                upload_id = ref.get("upload_id")
                if not upload_id:
                    logger.warning(
                        "Upload reference missing upload_id",
                        event=cmd_name,
                        param=param_name,
                    )
                    return
                try:
                    file_bytes = await self._download_uploaded_file(upload_id)
                except Exception:
                    logger.exception(
                        "Failed to download file",
                        event=cmd_name,
                        param=param_name,
                        upload_id=upload_id,
                    )
                    return
                validated[param_name] = UploadedFile(
                    name=ref.get("name", ""),
                    mime_type=ref.get("mime_type", ""),
                    size=ref.get("size", 0),
                    data=file_bytes,
                )

        try:
            event = event_cls(**validated)
        except Exception as e:
            logger.warning("Failed to create event", name=cmd_name, error=e)
            return

        self.model._push_event(event)

    async def _handle_file_uploaded(self, payload: dict) -> None:
        """Download an uploaded file and push a FileUploaded event to the model.

        Skips the download entirely when the model has no ``@file_uploaded``
        handler registered, avoiding wasted work for models that only use
        ``UploadedFile``-typed event parameters.
        """
        if self.model is None:
            return
        handlers = type(self.model)._get_handlers()
        if handlers.file_uploaded is None:
            return

        upload_id = payload.get("upload_id", "")
        if not upload_id:
            logger.warning("fileUploaded message missing upload_id")
            return
        name = payload.get("name", "")
        mime_type = payload.get("mime_type", "")
        size = payload.get("size", 0)
        try:
            data = await self._download_uploaded_file(upload_id)
        except Exception:
            logger.exception(
                "Failed to download uploaded file",
                upload_id=upload_id,
                name=name,
            )
            return
        file = UploadedFile(name=name, mime_type=mime_type, size=size, data=data)
        self.model._push_event(FileUploaded(file=file))
        logger.info(
            "Pushed FileUploaded event to model",
            upload_id=upload_id,
            name=name,
            mime_type=mime_type,
            size=size,
        )

    # -----------------------------------------------------------------
    # Trickle ICE (transport-agnostic)
    # -----------------------------------------------------------------

    async def add_ice_candidate(
        self,
        candidate: str,
        sdp_mid: Optional[str] = None,
        sdp_mline_index: Optional[int] = None,
    ) -> None:
        """Forward a trickle ICE candidate to the active WebRTC transport.

        If no transport is installed yet (the common case during the
        signalling handshake — candidates start flowing the moment
        ``setLocalDescription`` runs on the client), the candidate is
        buffered and replayed on entry to STREAMING.

        Concrete runtimes override :meth:`_active_webrtc_client` to
        expose their live transport; the buffering / flushing logic is
        owned here so every runtime gets the same behaviour for free.

        Args:
            candidate: The ICE candidate string (per RFC 5245).
            sdp_mid: Media-section identifier (may be ``None``).
            sdp_mline_index: Zero-based m-line index (may be ``None``).
        """
        client = self._active_webrtc_client()
        if client is not None:
            try:
                await client.add_ice_candidate(candidate, sdp_mline_index, sdp_mid)
            except Exception as e:
                logger.warning("Failed to add ICE candidate", error=e)
            return

        async with self._ice_candidate_lock:
            self._pending_ice_candidates.append((candidate, sdp_mid, sdp_mline_index))
            logger.debug(
                "Buffered ICE candidate (no active transport yet)",
                buffered=len(self._pending_ice_candidates),
            )

    def _active_webrtc_client(self) -> Optional[WebRTCTransport]:
        """Hook for subclasses with a WebRTC transport.

        Subclasses that own a WebRTC transport return the live instance
        so the base class can forward trickle ICE candidates to it.
        Returns ``None`` when no transport is active or the runtime
        does not use WebRTC.
        """
        return None

    async def _flush_pending_ice_candidates(self) -> None:
        """Replay buffered ICE candidates onto the freshly-installed transport.

        Called automatically from :meth:`on_enter_STREAMING`. No-ops if
        no transport is active or no candidates were buffered.
        """
        client = self._active_webrtc_client()
        if client is None:
            return

        async with self._ice_candidate_lock:
            pending = self._pending_ice_candidates
            self._pending_ice_candidates = []

        if not pending:
            return

        logger.debug("Flushing buffered ICE candidates", count=len(pending))
        for candidate, sdp_mid, sdp_mline_index in pending:
            try:
                await client.add_ice_candidate(candidate, sdp_mline_index, sdp_mid)
            except Exception as e:
                logger.warning("Failed to flush buffered ICE candidate", error=e)

    def _clear_pending_ice_candidates(self) -> None:
        """Drop any buffered ICE candidates.

        Synchronous so it can be called from ``on_enter_*`` state hooks.
        Safe to call concurrently with :meth:`add_ice_candidate` because
        the worst case is that a candidate appended just after the clear
        survives — and that candidate would itself be discarded on the
        next state transition out of STREAMING.
        """
        if self._pending_ice_candidates:
            logger.debug(
                "Discarding buffered ICE candidates",
                count=len(self._pending_ice_candidates),
            )
            self._pending_ice_candidates = []

    # -----------------------------------------------------------------
    # Abstract transport methods
    # -----------------------------------------------------------------

    @abstractmethod
    async def _download_uploaded_file(self, upload_id: str) -> bytes:
        """Download the bytes for a previously uploaded file.

        Each concrete runtime implements this differently:

        - **RedisRuntime**: calls ``GetPresignedUrl`` on the Supervisor
          via gRPC, then HTTP-GETs the presigned URL.
        - **HttpRuntime**: reads from the local in-memory upload store.

        Args:
            upload_id: The ``presigned_id`` / upload slot identifier.

        Returns:
            The raw file bytes.

        Raises:
            Exception: On download failure (network, not-found, etc.).
        """

    @abstractmethod
    async def send_out_app_message(self, data: dict) -> None:
        """Send an application message FROM the model TO the client.

        The message has already been wrapped in an ApplicationMessage envelope.
        """

    @abstractmethod
    async def send_out_runtime_message(self, data: dict) -> None:
        """Send a runtime message FROM the runtime TO the client.

        The message has already been wrapped in a RuntimeMessage envelope.
        Used for platform-level responses (e.g., capabilities).
        """

    @abstractmethod
    async def send_out_app_bundle(
        self, media_bundle: MediaBundle, duplicate: bool
    ) -> None:
        """Send a synchronised multi-track media bundle to the client.

        Called periodically by the :class:`FrameBuffer` emission loop at
        the dynamically calculated FPS.  Implementations forward the
        bundle to the transport via ``send_media``.

        Args:
            media_bundle: The :class:`MediaBundle` to send.
            duplicate: True if this is a re-emission of the last frame.
        """

    @abstractmethod
    async def run(self) -> None:
        """Main entry point for the runtime.

        Subclasses implement this to start their server (e.g., uvicorn
        for HTTP, stdin loop for headless).
        """

    # -----------------------------------------------------------------
    # Ping (overridden by WebRTC runtimes)
    # -----------------------------------------------------------------

    def _on_ping_received(self) -> None:
        """Called when a client ping arrives on the runtime channel.

        The default implementation is a no-op.  WebRTC-based runtimes override
        this to forward the ping to the WebRTCClient's watchdog via
        ``notify_ping()``.
        """
        pass

    # -----------------------------------------------------------------
    # Graceful shutdown (SIGTERM)
    # -----------------------------------------------------------------

    def get_shutdown_event(self) -> asyncio.Event:
        """Get the shutdown event for waiting on graceful shutdown.

        Concrete runtimes should await this event in their run() method:
            ``await self.get_shutdown_event().wait()``

        Returns:
            The asyncio.Event that is set when shutdown should occur.
        """
        return self._shutdown_event

    def _setup_signal_handlers(self) -> None:
        """Set up signal handlers for graceful shutdown (SIGTERM/SIGINT).

        Called automatically during __init__. The handlers trigger graceful
        shutdown logic that:
        - Immediately shuts down if in READY or CREATED state
        - Waits for grace period if in a session, then forces stop
        - Sets the shutdown event when ready to exit
        """

        def signal_handler(sig: signal.Signals) -> None:
            if self._shutdown_pending:
                return
            logger.info("Signal received, initiating shutdown", signal=sig)
            self.loop.call_soon_threadsafe(
                lambda: asyncio.create_task(self._handle_sigterm_graceful_shutdown())
            )

        for sig in (signal.SIGTERM, signal.SIGINT):
            self.loop.add_signal_handler(sig, signal_handler, sig)

    async def _handle_sigterm_graceful_shutdown(self) -> None:
        """Internal handler for SIGTERM graceful shutdown.

        - If in READY or CREATED: set shutdown_event immediately
        - If in session states (WAITING, STREAMING, ORPHANED): wait grace period,
          then force stop the session
        - If in other states (e.g., CLOSING): the state machine will automatically
          transition to READY, which will trigger shutdown via on_enter_READY

        The grace period is controlled by the SIGTERM_GRACE_PERIOD environment
        variable (defaults to 30 seconds).
        """
        self._shutdown_pending = True
        try:
            grace_period = float(os.getenv("SIGTERM_GRACE_PERIOD", "30"))
        except ValueError:
            grace_period = 30.0

        current = self.current_state

        if current == ModelState.TERMINATED:
            self._shutdown_event.set()
            return

        if current in (ModelState.READY, ModelState.CREATED):
            self._shutdown_event.set()
            return

        if current in (
            ModelState.WAITING,
            ModelState.STREAMING,
            ModelState.ORPHANED,
        ):
            try:
                await asyncio.wait_for(
                    self._shutdown_event.wait(), timeout=grace_period
                )
            except asyncio.TimeoutError:
                self.send(ModelEvent.STOP_SESSION)

    # -----------------------------------------------------------------
    # Shutdown cleanup
    # -----------------------------------------------------------------

    async def shutdown(self) -> None:
        """Perform graceful shutdown cleanup.

        Stops any running session, waits for READY state, then sends EVICTION.

        This method is shielded from cancellation to ensure EVICTION always happens.
        Subclasses should call this in their run() method's finally block.
        """
        try:
            await asyncio.shield(self._shutdown_cleanup())
        except asyncio.CancelledError:
            pass

    async def _shutdown_cleanup(self) -> None:
        """Internal shutdown cleanup implementation."""
        await self._stop_idling_loop()

        try:
            if self.session_running or self.current_state == ModelState.WAITING:
                self.send(ModelEvent.STOP_SESSION)

            while self.current_state not in (
                ModelState.READY,
                ModelState.TERMINATED,
                ModelState.CREATED,
            ):
                await asyncio.sleep(0.05)

            if self.model is not None:
                self.model._stop()
                if self.model_thread is not None and self.model_thread.is_alive():
                    self.model_thread.join(timeout=2.0)
                self.model.output_buffer.stop_emission()

            try:
                get_profiler().shutdown()
            except Exception as e:
                logger.warning("Failed to shutdown profiler", error=e)

            if self.current_state == ModelState.READY:
                self.send(ModelEvent.EVICTION)

        except asyncio.CancelledError:
            if self.current_state == ModelState.READY:
                self.send(ModelEvent.EVICTION)
            raise

        logger.info("Runtime shutdown complete")

    # -----------------------------------------------------------------
    # Orphan timeout
    # -----------------------------------------------------------------

    def _start_orphan_timeout(self) -> None:
        """Start the orphan timeout coroutine.

        If no Client Connection is established within the timeout period,
        the session will be stopped automatically.
        """
        if self.config.orphan_timeout <= 0:
            return
        self._cancel_orphan_timeout()

        async def coro() -> None:
            try:
                logger.info(
                    "Orphan timeout started",
                    timeout=f"{self.config.orphan_timeout}s",
                )
                await asyncio.sleep(self.config.orphan_timeout)
                self.send(ModelEvent.TIMEOUT)
            except asyncio.CancelledError:
                pass

        self._orphan_task = asyncio.create_task(coro())

    def _cancel_orphan_timeout(self) -> None:
        """Cancel the orphan timeout if running."""
        if self._orphan_task is not None:
            self._orphan_task.cancel()
            self._orphan_task = None

    # -----------------------------------------------------------------
    # Idling
    # -----------------------------------------------------------------

    def _start_idling_loop(self) -> None:
        """Start the idling loop task.

        The idling loop periodically triggers IDLING events via the state machine.
        The event is only valid when in READY state (READY -> READY transition).
        """
        if self._idling_task is not None:
            return
        self._idling_task = asyncio.create_task(self._idling_loop())

    async def _stop_idling_loop(self) -> None:
        """Stop the idling loop task."""
        if self._idling_task is not None:
            self._idling_task.cancel()
            try:
                await self._idling_task
            except asyncio.CancelledError:
                pass
            self._idling_task = None

    async def _idling_loop(self) -> None:
        """Background task that periodically triggers IDLING events.

        The IDLING event is only valid when the runtime is in READY state
        (READY -> READY).  If the runtime is not in READY state, the state
        machine will reject the event.  Runs continuously until cancelled.
        """
        assert self.config.idling_interval is not None
        interval = self.config.idling_interval
        while True:
            try:
                await asyncio.sleep(interval)
                self.send(ModelEvent.IDLING)
            except asyncio.CancelledError:
                break
            except Exception:
                pass
