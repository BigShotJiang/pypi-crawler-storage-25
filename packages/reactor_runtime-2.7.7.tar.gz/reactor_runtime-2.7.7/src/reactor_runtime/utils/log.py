# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""Structured logging for the Reactor Runtime.

The runtime writes to stdout/stderr; in production Grafana Alloy tails
the container logs into Loki.  K8s metadata (``namespace``, ``pod``,
``container``) is attached by Alloy as labels — this module is only
responsible for the line body.

Usage::

    from reactor_runtime.utils.log import get_logger

    logger = get_logger(__name__)
    logger.info("Session created")
    # => "... Session created session_id=<sid> machine_id=<pod> model=<slug>"

``session_id``, ``machine_id``, ``model``, and a model/system origin
tag are stamped on every record by :class:`ContextFilter` — callers
only pass kwargs for values that vary per call.

Two output modes (selected via ``REACTOR_LOG_FORMAT``):

* **text** (default): logfmt-shaped ``key=value`` tokens, ASCII-safe
  even when colourised (ANSI only wraps the level column) so Loki
  substring filters like ``|= "session_id=<sid>"`` always match.
* **json**: one JSON object per line, parseable by Loki's ``| json``
  parser.  Production sets ``REACTOR_LOG_FORMAT=json``.

The customer-vs-system discriminator is keyed off ``record.pathname``
relative to the configured ``model_root`` — anything emitted from a
file under the model directory is tagged ``MDL`` / ``origin=model``
(partner code), everything else is ``SYS`` / ``origin=system``.
"""

from __future__ import annotations

import json
import logging
import os
import sys
from typing import Any, Optional

# ---------------------------------------------------------------------------
# Process-wide context
# ---------------------------------------------------------------------------
#
# These four globals are read by :class:`ContextFilter` on every record.
# ``session_id`` is a module global rather than a :class:`ContextVar`
# because the runtime fans the work of a session out across several
# plain ``threading.Thread`` workers (model loop, frame emission,
# recorder, transport) and ContextVars do not cross those boundaries.

_session_id: Optional[str] = None
_machine_id: str = os.getenv("HOSTNAME", "")
_model: str = ""
_model_root: str = ""


class _SessionIdVar:
    """Process-global session id with a ``ContextVar``-shaped API.

    ``set()`` returns the previous value (the "token"); ``reset(token)``
    restores it, matching the stdlib idiom test code uses for scoping.
    """

    __slots__ = ()

    def get(self) -> Optional[str]:
        return _session_id

    def set(self, value: Optional[str]) -> Optional[str]:
        global _session_id
        previous = _session_id
        _session_id = value or None
        return previous

    def reset(self, token: Optional[str]) -> None:
        global _session_id
        _session_id = token


session_id_var: _SessionIdVar = _SessionIdVar()


def set_runtime_context(
    *,
    machine_id: Optional[str] = None,
    model: Optional[str] = None,
    model_root: Optional[str] = None,
) -> None:
    """Capture invariant runtime identity stamped on every log record.

    ``machine_id`` is the k8s pod name, ``model`` is the model slug,
    ``model_root`` is the absolute path used to classify records as
    partner (``MDL``) or system (``SYS``).  Any argument left ``None``
    is left unchanged.
    """
    global _machine_id, _model, _model_root
    if machine_id is not None:
        _machine_id = machine_id
    if model is not None:
        _model = model
    if model_root is not None:
        _model_root = os.path.realpath(model_root) if model_root else ""


# ---------------------------------------------------------------------------
# Record decoration
# ---------------------------------------------------------------------------


def _is_model_path(pathname: str) -> bool:
    """Return True iff *pathname* lives under the configured model root."""
    if not _model_root or not pathname:
        return False
    try:
        resolved = os.path.realpath(pathname)
    except (OSError, ValueError):
        return False
    return resolved == _model_root or resolved.startswith(_model_root + os.sep)


class ContextFilter(logging.Filter):
    """Stamp ``session_id``, ``machine_id``, ``model``, and ``is_model``
    on every record.

    Attached to the root handler so records from third-party libraries
    (``aiortc``, ``uvicorn``, ``httpx``, …) that propagate up to root
    pick up the same context.
    """

    def filter(self, record: logging.LogRecord) -> bool:
        record.session_id = _session_id or ""
        record.machine_id = _machine_id
        record.model = _model
        record.is_model = _is_model_path(getattr(record, "pathname", ""))
        return True


# ---------------------------------------------------------------------------
# Formatters
# ---------------------------------------------------------------------------

LOG_DATEFMT = "%Y-%m-%dT%H:%M:%S%z"
LOG_FORMAT = "%(asctime)s %(levelname)s %(name)s: %(message)s"
LOG_FORMAT_BRIEF = "%(levelname)s %(message)s"

# Structured kwargs from ``logger.info(..., k=v)`` are stashed on the
# record under this attribute to avoid colliding with any of stdlib's
# reserved ``LogRecord`` field names.
_REACTOR_FIELDS_ATTR = "reactor_fields"


_LOGFMT_CONTROL_CHARS = ("\n", "\r", "\t")
_LOGFMT_QUOTE_TRIGGERS = (" ", "=", '"') + _LOGFMT_CONTROL_CHARS


def _logfmt_value(v: Any) -> str:
    """Render *v* as a logfmt-safe token.

    Values containing whitespace, ``=``, ``"`` or a control character
    are wrapped in quotes; ``\\``, ``"``, ``\\n``, ``\\r``, ``\\t`` are
    escaped so a multi-line value (e.g. a stack trace) stays on one
    physical log line.
    """
    s = "" if v is None else str(v)
    needs_quote = not s or any(c in s for c in _LOGFMT_QUOTE_TRIGGERS)
    if not needs_quote:
        return s
    escaped = (
        s.replace("\\", "\\\\")
        .replace('"', '\\"')
        .replace("\n", "\\n")
        .replace("\r", "\\r")
        .replace("\t", "\\t")
    )
    return f'"{escaped}"'


def _record_fields(record: logging.LogRecord) -> dict[str, Any]:
    """Collect the fields rendered after the message in text mode.

    Explicit ``logger.info(..., k=v)`` kwargs first, then the
    auto-injected ``session_id`` / ``machine_id`` / ``model`` for any
    key the caller didn't already provide.  ``None`` values are dropped.
    """
    fields: dict[str, Any] = {}
    raw = getattr(record, _REACTOR_FIELDS_ATTR, None)
    if isinstance(raw, dict):
        for k, v in raw.items():
            if v is not None:
                fields[k] = v
    sid = getattr(record, "session_id", "") or ""
    mid = getattr(record, "machine_id", "") or ""
    mdl = getattr(record, "model", "") or ""
    if sid and "session_id" not in fields:
        fields["session_id"] = sid
    if mid and "machine_id" not in fields:
        fields["machine_id"] = mid
    if mdl and "model" not in fields:
        fields["model"] = mdl
    return fields


class TextFormatter(logging.Formatter):
    """Human-readable logfmt-ish output.

    The line body stays pure ASCII; colour, when enabled, only wraps
    the level column so Loki substring filters on the body still match.
    """

    _RESET = "\033[0m"
    _LEVEL_COLOURS = {
        logging.DEBUG: "\033[37m",
        logging.INFO: "\033[32m",
        logging.WARNING: "\033[33m",
        logging.ERROR: "\033[31m",
        logging.CRITICAL: "\033[1;31m",
    }
    _MODEL_COLOUR = "\033[36m"
    _KEY_COLOUR = "\033[38;5;25m"
    _LEVEL_WIDTH = 12  # fits "CRITICAL MDL"

    def __init__(
        self, fmt: str, datefmt: Optional[str] = None, *, color: bool = False
    ) -> None:
        super().__init__(fmt=fmt, datefmt=datefmt)
        self._color = color

    def format(self, record: logging.LogRecord) -> str:
        original_levelname = record.levelname
        try:
            record.levelname = self._render_level(record)
            base = super().format(record)
        finally:
            record.levelname = original_levelname
        fields = _record_fields(record)
        if fields:
            base = f"{base} {self._render_fields(fields)}"
        return base

    def _render_level(self, record: logging.LogRecord) -> str:
        level = record.levelname
        kind = "MDL" if getattr(record, "is_model", False) else "SYS"
        if self._color:
            level_col = self._LEVEL_COLOURS.get(record.levelno, "")
            kind_col = self._MODEL_COLOUR if kind == "MDL" else ""
            visible = len(level) + 1 + len(kind)
            pad = max(self._LEVEL_WIDTH - visible, 0)
            kind_part = f"{kind_col}{kind}{self._RESET}" if kind_col else kind
            return f"{level_col}{level}{self._RESET} {kind_part}{' ' * pad}"
        return f"{level} {kind}".ljust(self._LEVEL_WIDTH)

    def _render_fields(self, fields: dict[str, Any]) -> str:
        if self._color:
            b, r = self._KEY_COLOUR, self._RESET
            return " ".join(f"{b}{k}={r}{_logfmt_value(v)}" for k, v in fields.items())
        return " ".join(f"{k}={_logfmt_value(v)}" for k, v in fields.items())


class JsonFormatter(logging.Formatter):
    """One JSON object per line, parseable by Loki's ``| json`` parser.

    The structural envelope (``ts``, ``level``, ``logger``, ``origin``,
    ``msg``, ``exc_info``) is owned by the formatter and cannot be
    overridden by caller kwargs.  ``origin`` is ``"model"`` or
    ``"system"`` — named ``origin`` rather than ``kind`` so partner
    fields like ``track.kind`` survive into the output untouched.

    Caller kwargs take precedence over the auto-injected context
    (``session_id`` / ``machine_id`` / ``model``), so a billing event
    logging an explicit ``session_id`` lands the explicit value.
    """

    _RESERVED_KEYS = frozenset({"ts", "level", "logger", "origin", "msg", "exc_info"})

    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, Any] = {
            "ts": self.formatTime(record, LOG_DATEFMT),
            "level": record.levelname.lower(),
            "logger": record.name,
            "origin": "model" if getattr(record, "is_model", False) else "system",
            "msg": record.getMessage(),
        }

        # Caller kwargs first so an explicit ``session_id=`` wins over
        # the auto-injected one filled in below.
        raw_fields = getattr(record, _REACTOR_FIELDS_ATTR, None)
        if isinstance(raw_fields, dict):
            for k, v in raw_fields.items():
                if v is None or k in self._RESERVED_KEYS:
                    continue
                payload[k] = v

        sid = getattr(record, "session_id", "") or ""
        mid = getattr(record, "machine_id", "") or ""
        mdl = getattr(record, "model", "") or ""
        if sid and "session_id" not in payload:
            payload["session_id"] = sid
        if mid and "machine_id" not in payload:
            payload["machine_id"] = mid
        if mdl and "model" not in payload:
            payload["model"] = mdl

        if record.exc_info:
            payload["exc_info"] = self.formatException(record.exc_info)

        return json.dumps(payload, default=str, ensure_ascii=False)


# ---------------------------------------------------------------------------
# Public logger wrapper
# ---------------------------------------------------------------------------


class StructuredLogger:
    """Thin wrapper around :class:`logging.Logger`.

    ``logger.info("msg", k=v)`` attaches ``{"k": v}`` to the record;
    the active formatter renders it as ``key=value`` (text) or as a
    structured field (JSON).
    """

    __slots__ = ("_log",)

    def __init__(self, name: str) -> None:
        self._log: logging.Logger = logging.getLogger(name)

    # -- internal helpers --------------------------------------------------

    def _emit(
        self,
        level: int,
        msg: str,
        kw: dict[str, Any],
        *,
        exc_info: bool = False,
    ) -> None:
        if not self._log.isEnabledFor(level):
            return
        extra = {_REACTOR_FIELDS_ATTR: kw} if kw else None
        # Resolve the caller frame manually so ``record.pathname``
        # points at the actual call site (used by :func:`_is_model_path`
        # to classify the record).  Doing this with stdlib ``stacklevel=``
        # would require Python 3.11+ for internal-frame skipping; this
        # works on all supported CPython versions.
        try:
            caller = sys._getframe(2)  # _emit -> debug/info/... -> caller
            fn = caller.f_code.co_filename
            lno = caller.f_lineno
            func = caller.f_code.co_name
        except (ValueError, AttributeError):
            fn, lno, func = "(unknown file)", 0, "(unknown function)"
        exc_info_tuple = sys.exc_info() if exc_info else None
        record = self._log.makeRecord(
            self._log.name,
            level,
            fn,
            lno,
            msg,
            (),
            exc_info_tuple,
            func=func,
            extra=extra,
        )
        self._log.handle(record)

    # -- public API --------------------------------------------------------

    def debug(self, msg: str, **kw: Any) -> None:
        self._emit(logging.DEBUG, msg, kw)

    def info(self, msg: str, **kw: Any) -> None:
        self._emit(logging.INFO, msg, kw)

    def warning(self, msg: str, **kw: Any) -> None:
        self._emit(logging.WARNING, msg, kw)

    def error(self, msg: str, **kw: Any) -> None:
        self._emit(logging.ERROR, msg, kw)

    def critical(self, msg: str, *, exc_info: bool = False, **kw: Any) -> None:
        self._emit(logging.CRITICAL, msg, kw, exc_info=exc_info)

    def exception(self, msg: str, **kw: Any) -> None:
        self._emit(logging.ERROR, msg, kw, exc_info=True)

    # -- stdlib-style attribute delegation --------------------------------

    @property
    def level(self) -> int:
        return self._log.level

    def setLevel(self, level: int) -> None:  # noqa: N802 – match stdlib API
        self._log.setLevel(level)

    def isEnabledFor(self, level: int) -> bool:  # noqa: N802
        return self._log.isEnabledFor(level)


def get_logger(name: str) -> StructuredLogger:
    """Return a :class:`StructuredLogger` for *name*.

    Typical usage at module level::

        from reactor_runtime.utils.log import get_logger

        logger = get_logger(__name__)
    """
    return StructuredLogger(name)


__all__ = [
    "ContextFilter",
    "JsonFormatter",
    "LOG_DATEFMT",
    "LOG_FORMAT",
    "LOG_FORMAT_BRIEF",
    "StructuredLogger",
    "TextFormatter",
    "get_logger",
    "session_id_var",
    "set_runtime_context",
]
