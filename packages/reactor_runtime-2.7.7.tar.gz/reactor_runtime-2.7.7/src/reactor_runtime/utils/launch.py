# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""Entry point for running the Reactor runtime."""

import asyncio
import logging
import os
import sys
from typing import Callable, List, Optional

from reactor_runtime import __version__
from reactor_runtime.config import ReactorConfig
from reactor_runtime.utils.log import (
    LOG_DATEFMT,
    LOG_FORMAT,
    LOG_FORMAT_BRIEF,
    ContextFilter,
    JsonFormatter,
    TextFormatter,
    get_logger,
    set_runtime_context,
)

logger = get_logger(__name__)

# Third-party loggers floored to WARNING to keep prod logs scannable.
# httpx in particular is INFO-level per request and embeds presigned
# credentials in the URL — explicitly excluded from the default path.
_QUIET_LOGGERS = (
    "aiortc",
    "av",
    "aioice",
    "uvicorn",
    "uvicorn.error",
    "uvicorn.access",
    "httpx",
    "httpcore",
)

# Marker we set on our handler so ``configure_logging`` can replace it
# in place on re-entry instead of stacking duplicates.
_HANDLER_MARK = "_reactor_runtime_handler"


def add_import_paths(paths: List[str]) -> None:
    """Prepend provided directories to sys.path if they exist."""
    for p in paths:
        if not p:
            continue
        ap = os.path.abspath(p)
        if os.path.isdir(ap) and ap not in sys.path:
            sys.path.insert(0, ap)


def _resolve_json_output(json_output: Optional[bool]) -> bool:
    if json_output is not None:
        return json_output
    return os.getenv("REACTOR_LOG_FORMAT", "").strip().lower() == "json"


def _resolve_color(json_output: bool, color: Optional[bool]) -> bool:
    """Decide whether ANSI colour is enabled for the text formatter.

    JSON output is never colourised.  Precedence: explicit arg >
    ``REACTOR_LOG_COLOR`` > ``NO_COLOR`` > stderr TTY autodetection.
    """
    if json_output:
        return False
    if color is not None:
        return color
    env = os.getenv("REACTOR_LOG_COLOR", "auto").strip().lower()
    if env in ("never", "no", "false", "0", "off"):
        return False
    if env in ("always", "yes", "true", "1", "on"):
        return True
    if os.getenv("NO_COLOR"):
        return False
    try:
        return sys.stderr.isatty()
    except (AttributeError, ValueError):
        return False


def configure_logging(
    level: str,
    *,
    show_timestamps: bool = True,
    model: Optional[str] = None,
    model_root: Optional[str] = None,
    json_output: Optional[bool] = None,
    color: Optional[bool] = None,
) -> None:
    """Initialise the root logger.  Idempotent across re-entry.

    Args:
        level: Root log level (``DEBUG``/``INFO``/``WARNING``/...).
        show_timestamps: Include the ``asctime`` prefix in text mode.
        model: Model slug stamped on every record as ``model=<slug>``.
        model_root: Absolute path to the model directory; records emitted
            from files under it are tagged as partner code (``MDL`` /
            ``"origin":"model"``), everything else is ``SYS`` /
            ``"origin":"system"``.
        json_output: Force JSON output.  Defaults to
            ``REACTOR_LOG_FORMAT=json``.
        color: Force ANSI colour in text mode.  Defaults to TTY
            autodetection with ``REACTOR_LOG_COLOR`` / ``NO_COLOR``
            overrides.
    """
    set_runtime_context(
        machine_id=os.getenv("HOSTNAME", ""),
        model=model,
        model_root=model_root,
    )

    use_json = _resolve_json_output(json_output)
    use_color = _resolve_color(use_json, color)

    if use_json:
        formatter: logging.Formatter = JsonFormatter()
    else:
        fmt = LOG_FORMAT if show_timestamps else LOG_FORMAT_BRIEF
        formatter = TextFormatter(fmt, datefmt=LOG_DATEFMT, color=use_color)

    # Drop any previous reactor handler in place; foreign handlers
    # (pytest's ``caplog`` etc.) are left untouched.
    root = logging.root
    for h in list(root.handlers):
        if getattr(h, _HANDLER_MARK, False):
            root.removeHandler(h)

    handler = logging.StreamHandler()
    handler.setFormatter(formatter)
    handler.addFilter(ContextFilter())
    setattr(handler, _HANDLER_MARK, True)

    root.addHandler(handler)
    root.setLevel(getattr(logging, level.upper(), logging.INFO))

    for name in _QUIET_LOGGERS:
        logging.getLogger(name).setLevel(logging.WARNING)


def _infer_runtime_name(serve_fn: Callable) -> str:
    """Derive a short runtime label from the serve function's module path.

    e.g. ``reactor_runtime.runtimes.http.http_runtime`` -> ``http``
         ``reactor_runtime.runtimes._redis._redis_runtime`` -> ``redis``
    """
    parts = getattr(serve_fn, "__module__", "").split(".")
    if len(parts) >= 3:
        return parts[2].lstrip("_")
    return "unknown"


def run_reactor_runtime(
    runtime_serve_fn: Callable,
    reactor_config: ReactorConfig,
    model_root: Optional[str] = None,
    log_level: str = "INFO",
    show_timestamps: bool = True,
    **runtime_kwargs,
) -> None:
    """Run the Reactor runtime.

    Args:
        runtime_serve_fn: ``serve()`` function from the runtime module.
        reactor_config: Parsed ``reactor.yaml``.
        model_root: Directory added to ``sys.path`` for model imports,
            also used to classify logs as partner (``MDL``) or system
            (``SYS``).
        log_level: Root log level.
        show_timestamps: Include timestamps in text-mode output.
        **runtime_kwargs: Forwarded to ``serve()``.
    """
    configure_logging(
        log_level,
        show_timestamps=show_timestamps,
        model=reactor_config.name or None,
        model_root=model_root,
    )

    runtime_name = _infer_runtime_name(runtime_serve_fn)
    logger.info(
        "Starting reactor runtime",
        version=__version__,
        runtime=runtime_name,
    )
    detected: dict = {"entrypoint": reactor_config.model}
    if reactor_config.config:
        detected["config"] = reactor_config.config
    logger.info("Model detected", **detected)

    if model_root is not None:
        add_import_paths([model_root])

    asyncio.run(
        runtime_serve_fn(
            reactor_config=reactor_config,
            **runtime_kwargs,
        )
    )
