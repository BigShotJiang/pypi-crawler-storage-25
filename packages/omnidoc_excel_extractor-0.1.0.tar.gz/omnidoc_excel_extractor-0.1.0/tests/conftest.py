"""Create a minimal .xlsx fixture programmatically (no binary checked-in)."""
import pytest
from pathlib import Path


FIXTURE_DIR = Path(__file__).parent / "fixtures"


@pytest.fixture(scope="session")
def sample_xlsx(tmp_path_factory) -> Path:
    """Build a self-contained .xlsx with tables, formulas, merged cells, charts."""
    import openpyxl
    from openpyxl.chart import BarChart, Reference
    from openpyxl.utils import get_column_letter

    tmp = tmp_path_factory.mktemp("excel")
    path = tmp / "sample.xlsx"

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Sales"

    # Header + data
    headers = ["Date", "Product", "Region", "Revenue", "Units", "Cost"]
    ws.append(headers)
    rows = [
        ["2024-01-01", "Widget A", "North", 10000, 100, 6000],
        ["2024-02-01", "Widget B", "South", 15000, 150, 9000],
        ["2024-03-01", "Widget A", "East",  12000, 120, 7200],
        ["2024-04-01", "Widget C", "West",  8000,  80,  4800],
        ["2024-05-01", "Widget B", "North", 18000, 180, 10800],
    ]
    for row in rows:
        ws.append(row)

    # Named table
    from openpyxl.worksheet.table import Table, TableStyleInfo
    tbl = Table(displayName="SalesData", ref="A1:F6")
    tbl.tableStyleInfo = TableStyleInfo(name="TableStyleMedium9", showFirstColumn=False,
                                        showLastColumn=False, showRowStripes=True)
    ws.add_table(tbl)

    # Formula cells
    ws["H1"] = "Total Revenue"
    ws["H2"] = "=SUM(D2:D6)"
    ws["H3"] = "=AVERAGE(D2:D6)"
    ws["H4"] = "=MAX(D2:D6)"
    ws["H5"] = "=MIN(D2:D6)"

    # Merged cell
    ws.merge_cells("J1:K2")
    ws["J1"] = "Merged Header"

    # Bar chart
    chart = BarChart()
    chart.type = "col"
    chart.title = "Revenue by Row"
    data = Reference(ws, min_col=4, min_row=1, max_row=6)
    chart.add_data(data, titles_from_data=True)
    ws.add_chart(chart, "A9")

    # Second sheet with date column
    ws2 = wb.create_sheet("Dates")
    from datetime import date
    ws2.append(["Date", "Value"])
    for i in range(12):
        ws2.append([date(2024, i + 1, 1), i * 100])

    wb.save(path)
    return path


@pytest.fixture(scope="session")
def extractor(sample_xlsx):
    from omnidoc_excel_extractor import ExcelExtractor
    return ExcelExtractor(str(sample_xlsx))
