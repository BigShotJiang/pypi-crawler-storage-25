"""Tests for the omnidoc Excel extractor."""
import pytest
from omnidoc_excel_extractor import ExcelExtractor, ExtractionResult


# ---------------------------------------------------------------------------
# Smoke tests — full pipeline
# ---------------------------------------------------------------------------

def test_extraction_returns_result(extractor):
    result = extractor.extract(include_rows=False, include_analytics=False, include_visual=False)
    assert isinstance(result, ExtractionResult)
    assert len(result.chunks) > 0


def test_summary_has_expected_keys(extractor):
    result = extractor.extract(include_rows=False, include_analytics=False, include_visual=False)
    s = result.summary()
    assert "total_chunks" in s
    assert "type_counts" in s
    assert s["total_chunks"] > 0


def test_to_dicts_are_serialisable(extractor):
    result = extractor.extract(include_rows=False, include_analytics=False, include_visual=False)
    import json
    dicts = result.to_dicts()
    assert isinstance(dicts, list)
    json.dumps(dicts, default=str)  # must not raise


# ---------------------------------------------------------------------------
# Workbook chunk
# ---------------------------------------------------------------------------

def test_workbook_chunk_fields(extractor):
    result = extractor.extract(include_rows=False, include_analytics=False, include_visual=False)
    wb_chunks = result.by_type("WorkbookChunk")
    assert len(wb_chunks) == 1
    wbc = wb_chunks[0]
    assert wbc.name == "sample"
    assert "Sales" in wbc.sheet_names
    assert isinstance(wbc.sheet_names, list)


# ---------------------------------------------------------------------------
# Sheet chunks
# ---------------------------------------------------------------------------

def test_sheet_chunks_count(extractor):
    result = extractor.extract(include_rows=False, include_analytics=False, include_visual=False)
    sheets = result.by_type("SheetChunk")
    assert len(sheets) >= 2


def test_sheet_chunk_fields(extractor):
    result = extractor.extract(include_rows=False, include_analytics=False, include_visual=False)
    sheet = next(c for c in result.by_type("SheetChunk") if c.sheet_name == "Sales")
    assert sheet.sheet_index == 0
    assert sheet.sheet_type == "worksheet"
    assert sheet.is_visible is True


# ---------------------------------------------------------------------------
# Table chunks
# ---------------------------------------------------------------------------

def test_table_chunk_detected(extractor):
    result = extractor.extract(include_rows=False, include_analytics=False, include_visual=False)
    tables = result.by_type("TableChunk")
    assert any(t.table_name == "SalesData" for t in tables)


def test_table_chunk_dimensions(extractor):
    result = extractor.extract(include_rows=False, include_analytics=False, include_visual=False)
    tbl = next(t for t in result.by_type("TableChunk") if t.table_name == "SalesData")
    assert tbl.col_count == 6
    assert tbl.row_count >= 5


# ---------------------------------------------------------------------------
# Schema chunks
# ---------------------------------------------------------------------------

def test_schema_chunk_columns(extractor):
    result = extractor.extract(include_rows=False, include_analytics=False, include_visual=False)
    schemas = result.by_type("SchemaChunk")
    assert len(schemas) >= 1
    sales_schema = next((s for s in schemas if s.sheet_name == "Sales"), None)
    assert sales_schema is not None
    col_names = [c["name"] for c in sales_schema.columns]
    assert "Revenue" in col_names
    assert "Date" in col_names


# ---------------------------------------------------------------------------
# Row chunks
# ---------------------------------------------------------------------------

def test_row_chunks_count(extractor):
    result = extractor.extract(include_rows=True, include_analytics=False, include_visual=False)
    rows = result.by_type("RowChunk")
    assert len(rows) >= 5  # 5 data rows in Sales sheet + Dates sheet


def test_row_chunk_values(extractor):
    result = extractor.extract(include_rows=True, include_analytics=False, include_visual=False)
    rows = [r for r in result.by_type("RowChunk") if r.parent_sheet == "Sales"]
    assert len(rows) >= 5
    # All rows should have Revenue key
    assert all("Revenue" in r.values for r in rows)


# ---------------------------------------------------------------------------
# Merged cell chunks
# ---------------------------------------------------------------------------

def test_merged_cell_detected(extractor):
    result = extractor.extract(include_rows=False, include_analytics=False, include_visual=False)
    merged = result.by_type("MergedCellChunk")
    assert len(merged) >= 1
    assert any(m.merged_value == "Merged Header" for m in merged)


# ---------------------------------------------------------------------------
# Formula chunks
# ---------------------------------------------------------------------------

def test_formula_definition_chunks(extractor):
    result = extractor.extract(include_rows=False, include_analytics=True, include_visual=False)
    formulas = result.by_type("FormulaDefinitionChunk")
    assert len(formulas) >= 4
    fstr = [f.formula_string for f in formulas]
    assert any("SUM" in s for s in fstr)
    assert any("AVERAGE" in s for s in fstr)


# ---------------------------------------------------------------------------
# Summary / semantic chunks
# ---------------------------------------------------------------------------

def test_summary_chunk_sales_sheet(extractor):
    result = extractor.extract(include_rows=False, include_analytics=False, include_visual=False)
    summaries = result.by_type("SummaryChunk")
    sales = next((s for s in summaries if s.sheet_name == "Sales"), None)
    assert sales is not None
    assert sales.row_count == 5
    # The fixture writes helper formulas in cols H+ so col_count >= 6
    assert sales.col_count >= 6


def test_column_semantic_chunks(extractor):
    result = extractor.extract(include_rows=False, include_analytics=False, include_visual=False)
    col_chunks = result.by_type("ColumnSemanticChunk")
    revenue_col = next((c for c in col_chunks if c.col_name == "Revenue"), None)
    assert revenue_col is not None
    assert revenue_col.role == "measure"


def test_header_alias_chunks(extractor):
    result = extractor.extract(include_rows=False, include_analytics=False, include_visual=False)
    aliases = result.by_type("HeaderAliasChunk")
    assert len(aliases) >= 6


# ---------------------------------------------------------------------------
# Temporal chunks
# ---------------------------------------------------------------------------

def test_temporal_chunk_dates_sheet(extractor):
    result = extractor.extract(include_rows=False, include_analytics=True, include_visual=False)
    temporal = result.by_type("TemporalChunk")
    assert len(temporal) >= 1
    dates_temporal = [t for t in temporal if t.sheet_name == "Dates"]
    assert len(dates_temporal) >= 1


# ---------------------------------------------------------------------------
# Aggregation chunks
# ---------------------------------------------------------------------------

def test_aggregation_chunks_revenue(extractor):
    result = extractor.extract(include_rows=False, include_analytics=True, include_visual=False)
    aggs = [a for a in result.by_type("AggregationChunk")
            if a.col_name == "Revenue" and a.agg_type == "SUM"]
    assert len(aggs) == 1
    assert aggs[0].value == pytest.approx(63000.0)


# ---------------------------------------------------------------------------
# Chart chunks
# ---------------------------------------------------------------------------

def test_chart_chunk_detected(extractor):
    result = extractor.extract(include_rows=False, include_analytics=False, include_visual=True)
    charts = result.by_type("ChartChunk")
    assert len(charts) >= 1
    assert charts[0].chart_type in {"bar", "col", "unknown"}


# ---------------------------------------------------------------------------
# Selective extraction
# ---------------------------------------------------------------------------

def test_selective_by_chunk_type(extractor):
    result = extractor.extract(
        chunk_types=["WorkbookChunk", "SheetChunk"],
        include_rows=False, include_analytics=False, include_visual=False,
    )
    types = {c.chunk_type for c in result.chunks}
    assert types == {"WorkbookChunk", "SheetChunk"}


def test_by_sheet_filter(extractor):
    result = extractor.extract(include_rows=True, include_analytics=False, include_visual=False)
    sales_chunks = result.by_sheet("Sales")
    assert len(sales_chunks) > 0
    assert all(getattr(c, "sheet_name", None) == "Sales" for c in sales_chunks)


# ---------------------------------------------------------------------------
# ChunkIndex
# ---------------------------------------------------------------------------

def test_chunk_index_counts(extractor):
    result = extractor.extract(include_rows=False, include_analytics=False, include_visual=False)
    idx = result.index
    assert idx.chunk_type == "ChunkIndexChunk"
    assert idx.type_counts.get("WorkbookChunk", 0) == 1
    assert len(idx.all_chunk_ids) == len(result.chunks)


# ---------------------------------------------------------------------------
# Newly wired chunk types (11 additions)
# ---------------------------------------------------------------------------

def test_entity_chunks_produced(extractor):
    result = extractor.extract(include_rows=False, include_analytics=False, include_visual=False)
    # EntityChunks may be empty if no entity patterns found — just verify type is produced
    entity_chunks = result.by_type("EntityChunk")
    # No assertion on count — fixture has no person names — just check model is correct
    for c in entity_chunks:
        assert c.entity_type in {"person", "org", "date", "product", "location"}
        assert c.frequency >= 1


def test_kpi_chunks_produced(extractor):
    result = extractor.extract(include_rows=False, include_analytics=True, include_visual=False)
    kpi_chunks = result.by_type("KPIChunk")
    # The fixture has "Total Revenue" label next to a SUM formula result
    # KPI detection scans for keyword labels adjacent to numeric cells
    for c in kpi_chunks:
        assert c.kpi_name
        assert c.chunk_type == "KPIChunk"


def test_chart_annotation_chunks_produced(extractor):
    result = extractor.extract(include_rows=False, include_analytics=False, include_visual=True)
    annotations = result.by_type("ChartAnnotationChunk")
    # May be 0 if chart has no text annotations — just verify it doesn't error
    for c in annotations:
        assert c.annotation_type in {"data_label", "callout", "textbox"}


def test_pivot_cache_chunks_produced(extractor):
    result = extractor.extract(include_rows=False, include_analytics=False, include_visual=True)
    caches = result.by_type("PivotCacheChunk")
    # Fixture has no pivot tables — should be 0 but not error
    assert isinstance(caches, list)


def test_slicer_chunks_produced(extractor):
    result = extractor.extract(include_rows=False, include_analytics=False, include_visual=True)
    slicers = result.by_type("SlicerChunk")
    assert isinstance(slicers, list)


def test_timeline_chunks_produced(extractor):
    result = extractor.extract(include_rows=False, include_analytics=False, include_visual=True)
    timelines = result.by_type("TimelineChunk")
    assert isinstance(timelines, list)


def test_form_control_chunks_produced(extractor):
    result = extractor.extract(include_rows=False, include_analytics=False, include_visual=True)
    controls = result.by_type("FormControlChunk")
    assert isinstance(controls, list)


def test_activex_control_chunks_produced(extractor):
    result = extractor.extract(include_rows=False, include_analytics=False, include_visual=True)
    controls = result.by_type("ActiveXControlChunk")
    assert isinstance(controls, list)


def test_power_pivot_measure_chunks_produced(extractor):
    result = extractor.extract(include_rows=False, include_analytics=False, include_visual=False)
    measures = result.by_type("PowerPivotMeasureChunk")
    assert isinstance(measures, list)


def test_change_log_chunks_produced(extractor):
    result = extractor.extract(include_rows=False, include_analytics=False, include_visual=False)
    logs = result.by_type("ChangeLogChunk")
    assert isinstance(logs, list)


def test_all_57_chunk_types_have_builders():
    """Verify that every chunk type in CHUNK_REGISTRY can be instantiated via extract()."""
    from omnidoc_excel_extractor import CHUNK_REGISTRY
    # All 57 types (excl BaseChunk) must be in the registry
    assert len(CHUNK_REGISTRY) == 57


# ---------------------------------------------------------------------------
# Unsupported format
# ---------------------------------------------------------------------------

def test_unsupported_format_raises():
    with pytest.raises(ValueError, match="Unsupported file type"):
        ExcelExtractor("report.csv")
