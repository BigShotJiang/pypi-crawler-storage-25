"""Parse individual worksheet data from openpyxl worksheets."""
from __future__ import annotations

from typing import Any, Dict, Iterator, List, Optional, Tuple

from ..utils.cell_utils import col_index_to_letter, used_range_str


def parse_sheet_meta(ws, sheet_index: int) -> Dict[str, Any]:
    """Return sheet-level metadata dict."""
    tab_color = None
    try:
        tc = ws.sheet_properties.tabColor
        if tc:
            tab_color = tc.rgb or tc.theme or None
    except Exception:
        pass

    zoom = None
    try:
        zoom = ws.sheet_view.zoomScale
    except Exception:
        pass

    sheet_type = "worksheet"
    try:
        from openpyxl.chartsheet import Chartsheet
        if isinstance(ws, Chartsheet):
            sheet_type = "chart"
    except Exception:
        pass

    return {
        "sheet_name": ws.title,
        "sheet_index": sheet_index,
        "sheet_type": sheet_type,
        "is_visible": ws.sheet_state == "visible",
        "used_range": used_range_str(ws),
        "tab_color": str(tab_color) if tab_color else None,
        "is_protected": ws.protection.sheet if ws.protection else False,
        "zoom_level": zoom,
    }


def iter_rows(ws) -> Iterator[Tuple[int, List[Any]]]:
    """Yield (row_index_1based, [cell_values]) for every non-empty row."""
    for row in ws.iter_rows():
        values = [cell.value for cell in row]
        if any(v is not None for v in values):
            yield row[0].row, values


def get_header_row(ws, header_row: int = 1) -> List[str]:
    """Return the header values from the given row."""
    headers = []
    for cell in ws[header_row]:
        v = cell.value
        headers.append(str(v) if v is not None else f"col_{cell.column}")
    return headers


def get_all_values(ws) -> Tuple[List[str], List[List[Any]]]:
    """Return (headers, data_rows) where data_rows exclude the header row."""
    all_rows = list(ws.iter_rows(values_only=True))
    if not all_rows:
        return [], []
    headers = [str(h) if h is not None else f"col_{i}" for i, h in enumerate(all_rows[0])]
    data = [list(row) for row in all_rows[1:] if any(v is not None for v in row)]
    return headers, data


def get_merged_cells(ws) -> List[Dict[str, Any]]:
    """Return merged cell info from the worksheet."""
    merged = []
    for mc in ws.merged_cells.ranges:
        # Read value from top-left cell of the merge
        tl = ws.cell(row=mc.min_row, column=mc.min_col)
        merged.append({
            "merge_range": str(mc),
            "merged_value": tl.value,
            "row_span": mc.max_row - mc.min_row + 1,
            "col_span": mc.max_col - mc.min_col + 1,
        })
    return merged


def get_frozen_pane(ws) -> Optional[Dict[str, Any]]:
    """Return frozen pane configuration, or None."""
    try:
        pane = ws.freeze_panes
        if not pane:
            return None
        from openpyxl.utils.cell import coordinate_from_string, column_index_from_string
        col_str, row_str = coordinate_from_string(pane)
        freeze_col = column_index_from_string(col_str) - 1 or None
        freeze_row = (int(row_str) - 1) or None
        return {"freeze_row": freeze_row, "freeze_col": freeze_col}
    except Exception:
        return None


def get_row_groups(ws) -> List[Dict[str, Any]]:
    """Extract row groupings from worksheet."""
    groups = []
    try:
        for rg in ws.row_dimensions.values():
            lvl = getattr(rg, "outlineLevel", 0)
            if lvl and lvl > 0:
                groups.append({
                    "direction": "row",
                    "level": lvl,
                    "start_index": rg.index,
                    "end_index": rg.index,
                    "is_collapsed": getattr(rg, "collapsed", False),
                })
    except Exception:
        pass
    return groups


def get_col_groups(ws) -> List[Dict[str, Any]]:
    """Extract column groupings from worksheet."""
    groups = []
    try:
        for col_letter, cd in ws.column_dimensions.items():
            lvl = getattr(cd, "outlineLevel", 0)
            if lvl and lvl > 0:
                from openpyxl.utils import column_index_from_string
                idx = column_index_from_string(col_letter)
                groups.append({
                    "direction": "col",
                    "level": lvl,
                    "start_index": idx,
                    "end_index": idx,
                    "is_collapsed": getattr(cd, "collapsed", False),
                })
    except Exception:
        pass
    return groups


def get_data_validations(ws) -> List[Dict[str, Any]]:
    """Return list of data validation rules on the sheet."""
    rules = []
    try:
        for dv in ws.data_validations.dataValidation:
            rules.append({
                "range_addr": str(dv.sqref),
                "validation_type": dv.type or "custom",
                "allowed_values": list(dv.formula1.split(",")) if dv.type == "list" and dv.formula1 else [],
                "formula": dv.formula1,
                "error_msg": dv.error,
            })
    except Exception:
        pass
    return rules


def get_conditional_formats(ws) -> List[Dict[str, Any]]:
    """Return conditional formatting rules."""
    cfs = []
    try:
        for cf_range, rules in ws.conditional_formatting._cf_rules.items():
            for rule in rules:
                cfs.append({
                    "range_addr": str(cf_range),
                    "rule_type": str(rule.type) if rule.type else None,
                    "condition_formula": str(rule.formula[0]) if rule.formula else None,
                    "threshold": None,
                    "format_applied": None,
                })
    except Exception:
        pass
    return cfs


def get_comments(ws) -> List[Dict[str, Any]]:
    """Return cell comments/notes."""
    comments = []
    try:
        for row in ws.iter_rows():
            for cell in row:
                if cell.comment:
                    comments.append({
                        "cell_address": cell.coordinate,
                        "annotation_type": "comment",
                        "text": cell.comment.text,
                        "author": cell.comment.author,
                    })
    except Exception:
        pass
    return comments


def get_print_settings(ws) -> Dict[str, Any]:
    """Return print-related settings."""
    result: Dict[str, Any] = {}
    try:
        if ws.print_area:
            result["print_area"] = ws.print_area
        ph = ws.oddHeader
        result["header_text"] = str(ph) if ph else None
        pf = ws.oddFooter
        result["footer_text"] = str(pf) if pf else None
        result["orientation"] = ws.page_setup.orientation
        result["page_break_rows"] = [pb.id for pb in ws.row_breaks.brk]
    except Exception:
        pass
    return result
