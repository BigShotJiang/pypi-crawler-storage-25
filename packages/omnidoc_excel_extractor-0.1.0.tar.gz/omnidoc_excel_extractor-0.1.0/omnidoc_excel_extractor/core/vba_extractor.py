"""Extract VBA modules and macros using oletools."""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Dict, List, Optional

_EVENT_NAMES = {
    "Workbook_Open", "Workbook_Close", "Workbook_BeforeSave", "Workbook_AfterSave",
    "Workbook_BeforeClose", "Workbook_SheetChange", "Workbook_SheetActivate",
    "Worksheet_Change", "Worksheet_Activate", "Worksheet_SelectionChange",
    "Worksheet_BeforeDoubleClick", "Worksheet_BeforeRightClick",
}

_SUB_RE = re.compile(r"^\s*(Public|Private|Friend)?\s*Sub\s+(\w+)\s*\(", re.MULTILINE | re.IGNORECASE)
_FUNC_RE = re.compile(r"^\s*(Public|Private|Friend)?\s*Function\s+(\w+)\s*\(([^)]*)\)", re.MULTILINE | re.IGNORECASE)
_TRIGGER_RE = re.compile(r"^\s*Sub\s+(Workbook_\w+|Worksheet_\w+|Auto_\w+)\s*\(", re.MULTILINE | re.IGNORECASE)


def extract_vba(file_path: str) -> List[Dict[str, Any]]:
    """
    Extract VBA module info using oletools.
    Returns list of dicts with module_name, module_type, source_code, procedures.
    """
    modules: List[Dict[str, Any]] = []
    try:
        from oletools.olevba import VBA_Parser
        vba_parser = VBA_Parser(file_path)
        if not vba_parser.detect_vba_macros():
            return modules
        for (filename, stream_path, vba_filename, vba_code) in vba_parser.extract_macros():
            module_name = Path(vba_filename).stem if vba_filename else "Module"
            mtype = _detect_module_type(module_name, vba_code)
            subs = _extract_procedure_names(_SUB_RE, vba_code)
            funcs = _extract_procedure_names(_FUNC_RE, vba_code)
            modules.append({
                "module_name": module_name,
                "module_type": mtype,
                "source_code": vba_code,
                "procedure_names": subs + funcs,
                "line_count": len(vba_code.splitlines()) if vba_code else 0,
                "references": [],
            })
        vba_parser.close()
    except ImportError:
        pass
    except Exception:
        pass
    return modules


def _detect_module_type(module_name: str, code: str) -> str:
    name_lower = module_name.lower()
    if "thisworkbook" in name_lower:
        return "workbook"
    if name_lower.startswith("sheet"):
        return "sheet"
    if code and "Attribute VB_PredeclaredId = True" in code:
        return "class"
    return "standard"


def _extract_procedure_names(pattern: re.Pattern, code: str) -> List[str]:
    if not code:
        return []
    return [m.group(2) for m in pattern.finditer(code)]


def parse_macros(modules: List[Dict[str, Any]], workbook_name: str) -> List[Dict[str, Any]]:
    """Convert module info into macro-level records."""
    macros = []
    for mod in modules:
        code = mod.get("source_code", "") or ""
        for proc_name in mod.get("procedure_names", []):
            trigger_type = "auto" if proc_name.lower().startswith("auto_") else "event"
            trigger_event = None
            for evt in _EVENT_NAMES:
                if evt.lower() == proc_name.lower():
                    trigger_type = "event"
                    trigger_event = evt
                    break
            macros.append({
                "macro_name": proc_name,
                "module_name": mod["module_name"],
                "trigger_type": trigger_type,
                "trigger_event": trigger_event,
                "workbook": workbook_name,
                "line_count": _count_proc_lines(code, proc_name),
                "scope": "sheet" if mod["module_type"] == "sheet" else "workbook",
            })
    return macros


def _count_proc_lines(code: str, proc_name: str) -> int:
    if not code:
        return 0
    lines = code.splitlines()
    in_proc = False
    count = 0
    for line in lines:
        stripped = line.strip().lower()
        if stripped.startswith(("sub ", "function ", "private sub ", "public sub ",
                                 "private function ", "public function ")):
            name = re.split(r"[\s(]", stripped.lstrip("private ").lstrip("public ").lstrip("sub ").lstrip("function "))[0]
            in_proc = name == proc_name.lower()
        if in_proc:
            count += 1
        if in_proc and stripped.startswith("end sub") or stripped.startswith("end function"):
            break
    return count


def extract_udf_functions(modules: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Extract user-defined functions (UDFs) from VBA modules."""
    udfs = []
    for mod in modules:
        code = mod.get("source_code", "") or ""
        for m in _FUNC_RE.finditer(code):
            func_name = m.group(2)
            params_str = m.group(3)
            params = [p.strip().split(" ")[0] for p in params_str.split(",") if p.strip()]
            udfs.append({
                "module": mod["module_name"],
                "function_name": func_name,
                "parameters": params,
                "return_type": None,
                "is_udf": True,
            })
    return udfs


def extract_events(modules: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Extract event handlers from VBA modules."""
    events = []
    for mod in modules:
        code = mod.get("source_code", "") or ""
        for m in _TRIGGER_RE.finditer(code):
            events.append({
                "module": mod["module_name"],
                "event_name": m.group(1),
                "trigger_condition": None,
                "affected_range": None,
                "summary": None,
            })
    return events
