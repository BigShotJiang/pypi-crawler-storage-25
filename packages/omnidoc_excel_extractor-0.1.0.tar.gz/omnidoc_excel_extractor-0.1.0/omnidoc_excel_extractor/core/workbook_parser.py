"""Extract workbook-level metadata from openpyxl Workbook objects."""
from __future__ import annotations

import os
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

try:
    import openpyxl
    from openpyxl import Workbook
except ImportError:
    Workbook = None  # type: ignore


def parse_workbook_meta(wb: "Workbook", file_path: str) -> Dict[str, Any]:
    """Return a dict of workbook-level metadata fields."""
    p = Path(file_path)
    props = wb.properties

    created_at: Optional[datetime] = None
    modified_at: Optional[datetime] = None
    try:
        created_at = props.created
        modified_at = props.modified
    except Exception:
        pass

    try:
        size_kb = round(p.stat().st_size / 1024, 2)
    except OSError:
        size_kb = None

    sheet_names: List[str] = wb.sheetnames

    has_macros = p.suffix.lower() in {".xlsm", ".xlsb", ".xls"}

    app_version: Optional[str] = None
    try:
        app_version = wb.properties.appVersion
    except Exception:
        pass

    return {
        "name": p.stem,
        "path": str(p.resolve()),
        "sheet_names": sheet_names,
        "author": getattr(props, "creator", None),
        "created_at": created_at,
        "modified_at": modified_at,
        "file_size_kb": size_kb,
        "app_version": app_version,
        "has_macros": has_macros,
        "is_shared": False,
    }


def get_named_ranges(wb: "Workbook") -> List[Dict[str, Any]]:
    """Return list of named ranges as dicts {range_name, refers_to, scope}."""
    results = []
    try:
        for name, defn in wb.defined_names.items():
            scope = "workbook"
            try:
                scope = defn.localSheetId if defn.localSheetId is not None else "workbook"
                if isinstance(scope, int):
                    scope = wb.sheetnames[scope] if scope < len(wb.sheetnames) else "workbook"
            except Exception:
                pass
            refers_to = str(defn.attr_text) if hasattr(defn, "attr_text") else str(defn)
            results.append({
                "range_name": name,
                "refers_to": refers_to,
                "scope": scope,
            })
    except Exception:
        pass
    return results


def get_external_links(wb: "Workbook") -> List[Dict[str, Any]]:
    """Return list of external link references."""
    links = []
    try:
        for ext in wb._external_links:
            target = getattr(ext, "file_link", None) or getattr(ext, "Target", "")
            links.append({"target_file": str(target), "is_broken": False})
    except Exception:
        pass
    return links


def get_connections(wb: "Workbook") -> List[Dict[str, Any]]:
    """Return data connection metadata from the workbook."""
    connections = []
    try:
        # openpyxl exposes connections via wb._connections or similar
        raw = getattr(wb, "_connections", []) or []
        for c in raw:
            connections.append({
                "connection_name": getattr(c, "name", ""),
                "connection_type": getattr(c, "type", None),
                "connection_string_sanitized": None,
                "refresh_schedule": None,
            })
    except Exception:
        pass
    return connections
