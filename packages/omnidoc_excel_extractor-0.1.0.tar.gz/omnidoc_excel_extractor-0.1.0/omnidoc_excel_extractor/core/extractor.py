"""Main ExcelExtractor orchestrator — public API entry point."""
from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Type

from ..chunks.models import BaseChunk, ChunkIndexChunk, CHUNK_REGISTRY
from ..builder import (
    build_workbook_chunk, build_sheet_chunks, build_table_chunks,
    build_schema_chunks, build_row_chunks, build_group_chunks,
    build_parent_context_chunks, build_merged_cell_chunks, build_frozen_pane_chunks,
    build_summary_chunks, build_semantic_narrative_chunks,
    build_column_semantic_chunks, build_header_alias_chunks,
    build_cell_annotation_chunks, build_entity_chunks,
    build_formula_definition_chunks, build_formula_result_chunks,
    build_aggregation_chunks, build_temporal_chunks, build_trend_chunks,
    build_outlier_chunks, build_lookup_map_chunks, build_kpi_chunks,
    build_validation_chunks, build_error_chunks, build_conditional_format_chunks,
    build_protection_chunks, build_data_quality_chunks,
    build_chart_chunks, build_chart_series_chunks, build_chart_annotation_chunks,
    build_pivot_table_chunks, build_pivot_field_chunks, build_pivot_cache_chunks,
    build_slicer_chunks, build_timeline_chunks,
    build_sparkline_chunks, build_shape_chunks, build_image_chunks,
    build_form_control_chunks, build_activex_control_chunks,
    build_vba_module_chunks, build_macro_chunks,
    build_vba_event_chunks, build_custom_function_chunks,
    build_ribbon_customization_chunks,
    build_named_range_chunks, build_external_link_chunks,
    build_relationship_chunks, build_dependency_graph_chunks,
    build_power_query_chunks, build_connection_chunks,
    build_data_model_chunk, build_power_pivot_measure_chunks,
    build_print_settings_chunks, build_change_log_chunks, build_chunk_index,
)

_SUPPORTED = {".xlsx", ".xlsm", ".xlsb", ".xls"}


class ExcelExtractor:
    """
    Extract structured chunks from Excel files for AI/LLM/RAG pipelines.

    Usage::

        extractor = ExcelExtractor("report.xlsx")
        result = extractor.extract()
        chunks = result.chunks          # list[BaseChunk]
        index  = result.index           # ChunkIndexChunk
        dicts  = result.to_dicts()      # list[dict]

    Selective extraction::

        result = extractor.extract(
            chunk_types=["WorkbookChunk", "SheetChunk", "SchemaChunk"],
            include_rows=False,
        )
    """

    def __init__(
        self,
        file_path: str,
        *,
        password: Optional[str] = None,
        data_only: bool = False,
    ) -> None:
        self.file_path = str(Path(file_path).resolve())
        self.password = password
        self.data_only = data_only
        self._suffix = Path(file_path).suffix.lower()
        if self._suffix not in _SUPPORTED:
            raise ValueError(
                f"Unsupported file type '{self._suffix}'. Supported: {_SUPPORTED}"
            )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def extract(
        self,
        *,
        chunk_types: Optional[List[str]] = None,
        include_rows: bool = True,
        include_vba: bool = True,
        include_analytics: bool = True,
        include_visual: bool = True,
        row_batch_size: int = 500,
        priority: Optional[str] = None,  # "must" | "should" | "nice" | None=all
    ) -> "ExtractionResult":
        """Run the full extraction pipeline and return an ExtractionResult."""
        wb = self._load_workbook()
        workbook_name = Path(self.file_path).stem

        all_chunks: List[BaseChunk] = []

        # --- Structural (must) ---
        wb_chunk = build_workbook_chunk(wb, self.file_path)
        all_chunks.append(wb_chunk)
        all_chunks.extend(build_sheet_chunks(wb))
        all_chunks.extend(build_table_chunks(wb))
        all_chunks.extend(build_schema_chunks(wb))
        all_chunks.extend(build_group_chunks(wb))
        all_chunks.extend(build_parent_context_chunks(wb))
        all_chunks.extend(build_merged_cell_chunks(wb))
        all_chunks.extend(build_frozen_pane_chunks(wb))

        if include_rows:
            all_chunks.extend(build_row_chunks(wb, batch_size=row_batch_size))

        # --- Semantic (must/should) ---
        all_chunks.extend(build_summary_chunks(wb))
        all_chunks.extend(build_semantic_narrative_chunks(wb))
        all_chunks.extend(build_column_semantic_chunks(wb))
        all_chunks.extend(build_header_alias_chunks(wb))
        all_chunks.extend(build_cell_annotation_chunks(wb))
        all_chunks.extend(build_entity_chunks(wb))

        # --- Analytical ---
        if include_analytics:
            formula_defs = build_formula_definition_chunks(wb)
            all_chunks.extend(formula_defs)
            all_chunks.extend(build_formula_result_chunks(wb, formula_defs))
            all_chunks.extend(build_kpi_chunks(wb))
            all_chunks.extend(build_aggregation_chunks(wb))
            all_chunks.extend(build_temporal_chunks(wb))
            all_chunks.extend(build_trend_chunks(wb))
            all_chunks.extend(build_outlier_chunks(wb))
            all_chunks.extend(build_lookup_map_chunks(wb))

        # --- Validation ---
        all_chunks.extend(build_validation_chunks(wb))
        all_chunks.extend(build_error_chunks(wb))
        all_chunks.extend(build_conditional_format_chunks(wb))
        all_chunks.extend(build_protection_chunks(wb))
        all_chunks.extend(build_data_quality_chunks(wb))

        # --- Visual ---
        if include_visual:
            chart_chunks = build_chart_chunks(wb)
            all_chunks.extend(chart_chunks)
            all_chunks.extend(build_chart_series_chunks(wb, chart_chunks))
            all_chunks.extend(build_chart_annotation_chunks(wb, chart_chunks))
            pivot_chunks = build_pivot_table_chunks(wb)
            all_chunks.extend(pivot_chunks)
            all_chunks.extend(build_pivot_field_chunks(wb, pivot_chunks))
            all_chunks.extend(build_pivot_cache_chunks(wb, pivot_chunks))
            all_chunks.extend(build_slicer_chunks(wb))
            all_chunks.extend(build_timeline_chunks(wb))
            all_chunks.extend(build_sparkline_chunks(wb))
            all_chunks.extend(build_shape_chunks(wb))
            all_chunks.extend(build_image_chunks(wb))
            all_chunks.extend(build_form_control_chunks(wb))
            all_chunks.extend(build_activex_control_chunks(wb))

        # --- VBA ---
        if include_vba and self._suffix in {".xlsm", ".xlsb", ".xls"}:
            all_chunks.extend(build_vba_module_chunks(self.file_path, workbook_name))
            all_chunks.extend(build_macro_chunks(self.file_path, workbook_name))
            all_chunks.extend(build_vba_event_chunks(self.file_path))
            all_chunks.extend(build_custom_function_chunks(self.file_path))
            all_chunks.extend(build_ribbon_customization_chunks(wb, workbook_name))

        # --- Cross-reference ---
        all_chunks.extend(build_named_range_chunks(wb))
        all_chunks.extend(build_external_link_chunks(wb, workbook_name))
        all_chunks.extend(build_relationship_chunks(wb))
        all_chunks.extend(build_dependency_graph_chunks(wb))

        # --- Connectivity ---
        all_chunks.extend(build_power_query_chunks(wb, workbook_name))
        all_chunks.extend(build_connection_chunks(wb, workbook_name))
        all_chunks.extend(build_data_model_chunk(wb, workbook_name))
        all_chunks.extend(build_power_pivot_measure_chunks(wb, workbook_name))

        # --- Operational ---
        all_chunks.extend(build_print_settings_chunks(wb))
        all_chunks.extend(build_change_log_chunks(wb))

        # --- Filter by chunk_types / priority ---
        if chunk_types:
            allowed: Set[str] = set(chunk_types)
            all_chunks = [c for c in all_chunks if c.chunk_type in allowed]
        if priority:
            all_chunks = [c for c in all_chunks if c.priority == priority]

        # --- Index (always last, always included) ---
        index = build_chunk_index(all_chunks, workbook_name)

        return ExtractionResult(chunks=all_chunks, index=index)

    # ------------------------------------------------------------------
    # Convenience methods
    # ------------------------------------------------------------------

    def extract_sheets(self) -> "ExtractionResult":
        return self.extract(chunk_types=["WorkbookChunk", "SheetChunk", "SummaryChunk"])

    def extract_schema(self) -> "ExtractionResult":
        return self.extract(
            chunk_types=["SchemaChunk", "TableChunk", "ColumnSemanticChunk", "HeaderAliasChunk"],
            include_rows=False, include_analytics=False, include_visual=False,
        )

    def extract_formulas(self) -> "ExtractionResult":
        return self.extract(
            chunk_types=["FormulaDefinitionChunk", "FormulaResultChunk", "LookupMapChunk"],
            include_rows=False, include_visual=False,
        )

    def extract_vba_only(self) -> "ExtractionResult":
        return self.extract(
            chunk_types=["MacroChunk", "VBAModuleChunk", "VBAEventChunk", "CustomFunctionChunk"],
            include_rows=False, include_analytics=False, include_visual=False,
        )

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _load_workbook(self):
        if self._suffix == ".xls":
            return self._load_xls()
        if self._suffix == ".xlsb":
            return self._load_xlsb()
        return self._load_openpyxl()

    def _load_openpyxl(self):
        import openpyxl
        return openpyxl.load_workbook(
            self.file_path,
            data_only=self.data_only,
            read_only=False,
        )

    def _load_xls(self):
        """Load .xls file via xlrd and wrap in a thin openpyxl-compatible adapter."""
        try:
            import xlrd
        except ImportError as e:
            raise ImportError("xlrd is required for .xls files: pip install xlrd") from e
        from .._adapters.xlrd_adapter import XlrdWorkbookAdapter
        wb = xlrd.open_workbook(self.file_path, formatting_info=True)
        return XlrdWorkbookAdapter(wb)

    def _load_xlsb(self):
        """Load .xlsb file via pyxlsb and wrap in a thin adapter."""
        try:
            import pyxlsb
        except ImportError as e:
            raise ImportError("pyxlsb is required for .xlsb files: pip install pyxlsb") from e
        from .._adapters.xlsb_adapter import XlsbWorkbookAdapter
        wb = pyxlsb.open_workbook(self.file_path)
        return XlsbWorkbookAdapter(wb, self.file_path)


class ExtractionResult:
    """Container for all extracted chunks plus the manifest index."""

    def __init__(self, chunks: List[BaseChunk], index: ChunkIndexChunk) -> None:
        self.chunks = chunks
        self.index = index

    def to_dicts(self) -> List[Dict[str, Any]]:
        return [c.to_dict() for c in self.chunks]

    def by_type(self, chunk_type: str) -> List[BaseChunk]:
        return [c for c in self.chunks if c.chunk_type == chunk_type]

    def by_sheet(self, sheet_name: str) -> List[BaseChunk]:
        return [
            c for c in self.chunks
            if getattr(c, "sheet_name", None) == sheet_name
        ]

    def summary(self) -> Dict[str, Any]:
        return {
            "total_chunks": len(self.chunks),
            "type_counts": self.index.type_counts,
            "workbook": self.index.workbook_ref,
            "created_at": self.index.created_at.isoformat(),
        }

    def __repr__(self) -> str:
        return f"ExtractionResult(chunks={len(self.chunks)}, types={len(self.index.type_counts)})"
