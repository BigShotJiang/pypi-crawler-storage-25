"""Extract and classify formulas from openpyxl worksheets."""
from __future__ import annotations

import re
from typing import Any, Dict, List, Optional, Tuple

_LOOKUP_FUNCS = {"VLOOKUP", "HLOOKUP", "INDEX", "MATCH", "XLOOKUP", "XMATCH"}
_AGG_FUNCS = {"SUM", "AVERAGE", "COUNT", "COUNTA", "MIN", "MAX", "MEDIAN", "STDEV", "STDEVP", "VAR"}
_ERROR_VALUES = {"#REF!", "#DIV/0!", "#N/A", "#VALUE!", "#NAME?", "#NULL!", "#NUM!"}
_ERROR_MAP = {
    "#REF!": "#REF", "#DIV/0!": "#DIV0", "#N/A": "#NA",
    "#VALUE!": "#VALUE", "#NAME?": "#NAME", "#NULL!": "#NULL", "#NUM!": "#NUM",
}
_NAMED_REF_RE = re.compile(r"\b([A-Za-z_][A-Za-z0-9_\.]*)\s*\(", re.IGNORECASE)
_CELL_REF_RE = re.compile(r"'?[\w\s]+'?!?\$?[A-Z]{1,3}\$?\d+(?::\$?[A-Z]{1,3}\$?\d+)?", re.IGNORECASE)


def classify_formula(formula: str) -> str:
    """Classify formula as scalar/array/dynamic/lambda."""
    if formula.startswith("{") and formula.endswith("}"):
        return "array"
    upper = formula.upper()
    if "LAMBDA(" in upper or "LET(" in upper:
        return "lambda"
    dynamic_funcs = {"FILTER(", "SORT(", "SORTBY(", "UNIQUE(", "SEQUENCE(", "RANDARRAY("}
    if any(f in upper for f in dynamic_funcs):
        return "dynamic"
    return "scalar"


def extract_named_refs(formula: str) -> List[str]:
    """Extract function/named-range references from a formula."""
    return list(set(m.group(1).upper() for m in _NAMED_REF_RE.finditer(formula)))


def extract_precedents(formula: str, sheet_name: str) -> List[str]:
    """Extract cell/range references from a formula."""
    refs = _CELL_REF_RE.findall(formula)
    results = []
    for ref in refs:
        if "!" not in ref:
            results.append(f"'{sheet_name}'!{ref}")
        else:
            results.append(ref)
    return list(set(results))


def detect_lookup_type(formula: str) -> Optional[str]:
    upper = formula.upper()
    if "XLOOKUP(" in upper:
        return "XLOOKUP"
    if "VLOOKUP(" in upper:
        return "VLOOKUP"
    if "HLOOKUP(" in upper:
        return "HLOOKUP"
    if "INDEX(" in upper and "MATCH(" in upper:
        return "INDEX-MATCH"
    return None


def detect_agg_type(formula: str) -> Optional[str]:
    upper = formula.upper()
    for fn in sorted(_AGG_FUNCS, key=len, reverse=True):
        if f"{fn}(" in upper:
            return fn
    return None


def parse_formula_range(formula: str) -> Optional[str]:
    """Try to extract the primary source range from an aggregation formula."""
    m = re.search(r"\(([A-Z]+\d+:[A-Z]+\d+)", formula, re.IGNORECASE)
    return m.group(1) if m else None


def get_formula_cells(ws) -> List[Dict[str, Any]]:
    """Return all cells that contain formulas on the worksheet."""
    results = []
    for row in ws.iter_rows():
        for cell in row:
            val = cell.value
            if isinstance(val, str) and val.startswith("="):
                results.append({
                    "cell_address": cell.coordinate,
                    "formula_string": val,
                    "computed_value": None,
                    "has_error": False,
                    "error_type": None,
                })
            elif val in _ERROR_VALUES:
                results.append({
                    "cell_address": cell.coordinate,
                    "formula_string": "",
                    "computed_value": None,
                    "has_error": True,
                    "error_type": _ERROR_MAP.get(str(val), str(val)),
                })
    return results


def get_error_cells(ws) -> List[Dict[str, Any]]:
    """Return cells containing Excel error values."""
    errors = []
    for row in ws.iter_rows():
        for cell in row:
            val = str(cell.value) if cell.value is not None else ""
            for err, mapped in _ERROR_MAP.items():
                if err in val:
                    formula = None
                    # Try to find formula from cached formula cell
                    errors.append({
                        "cell_addr": cell.coordinate,
                        "error_type": mapped,
                        "formula": formula,
                        "likely_cause": _likely_cause(mapped),
                    })
                    break
    return errors


def _likely_cause(error_type: str) -> str:
    causes = {
        "#REF": "Cell reference is invalid (deleted row/col)",
        "#DIV0": "Division by zero",
        "#NA": "Value not available (lookup failure)",
        "#VALUE": "Wrong value type in formula",
        "#NAME": "Unrecognised function or named range",
        "#NULL": "Invalid cell range intersection",
        "#NUM": "Invalid numeric value",
    }
    return causes.get(error_type, "Unknown")
