"""Thin adapter that wraps pyxlsb workbook to expose an openpyxl-like interface."""
from __future__ import annotations

from typing import Any, List, Optional


class _FakeProps:
    creator = None
    created = None
    modified = None
    appVersion = None


class _FakeProtection:
    sheet = False
    password = None


class _FakeMergedCells:
    ranges = []


class _FakeDataValidations:
    dataValidation = []


class _FakeConditionalFormatting:
    _cf_rules = {}


class _FakePageSetup:
    orientation = None


class _FakeRowBreaks:
    brk = []


class _FakeCell:
    def __init__(self, value: Any, row: int, col: int) -> None:
        self.value = value
        self.row = row
        self.column = col
        from ..utils.cell_utils import col_index_to_letter
        self.coordinate = f"{col_index_to_letter(col - 1)}{row}"
        self.comment = None


class XlsbSheetAdapter:
    def __init__(self, name: str, rows: List[List[Any]]) -> None:
        self.title = name
        self._rows = rows
        self.sheet_state = "visible"
        self.protection = _FakeProtection()
        self.merged_cells = _FakeMergedCells()
        self.data_validations = _FakeDataValidations()
        self.conditional_formatting = _FakeConditionalFormatting()
        self.page_setup = _FakePageSetup()
        self.row_breaks = _FakeRowBreaks()
        self._charts: List = []
        self._images: List = []
        self._shapes: List = []
        self._pivots: List = []
        self._sparklineGroups: List = []
        self.tables: dict = {}
        self.sheet_properties = type("Props", (), {"tabColor": None})()
        self.sheet_view = type("View", (), {"zoomScale": None})()
        self.freeze_panes = None
        self.print_area = None
        self.oddHeader = None
        self.oddFooter = None
        self.row_dimensions = {}
        self.column_dimensions = {}

    @property
    def min_row(self):
        return 1 if self._rows else None

    @property
    def max_row(self):
        return len(self._rows) or None

    @property
    def min_column(self):
        return 1 if self._rows and self._rows[0] else None

    @property
    def max_column(self):
        return max((len(r) for r in self._rows), default=None)

    def iter_rows(self, values_only: bool = False):
        for r_idx, row in enumerate(self._rows):
            if values_only:
                yield tuple(c.v if hasattr(c, "v") else c for c in row)
            else:
                cells = []
                for c_idx, cell in enumerate(row):
                    val = cell.v if hasattr(cell, "v") else cell
                    cells.append(_FakeCell(val, r_idx + 1, c_idx + 1))
                yield cells

    def __getitem__(self, row: int):
        r = self._rows[row - 1] if row - 1 < len(self._rows) else []
        return [_FakeCell(c.v if hasattr(c, "v") else c, row, ci + 1)
                for ci, c in enumerate(r)]


class XlsbWorkbookAdapter:
    def __init__(self, wb, file_path: str) -> None:
        self._wb = wb
        self.properties = _FakeProps()
        self._external_links: List = []
        self._connections: List = []
        self.custom_xml_parts: List = []
        self._sheets = self._load_sheets()

    def _load_sheets(self) -> List[XlsbSheetAdapter]:
        sheets = []
        for name in self._wb.sheets:
            try:
                with self._wb.get_sheet(name) as ws:
                    rows = list(ws.rows())
            except Exception:
                rows = []
            sheets.append(XlsbSheetAdapter(name, rows))
        return sheets

    @property
    def sheetnames(self) -> List[str]:
        return self._wb.sheets

    @property
    def worksheets(self):
        return self._sheets

    @property
    def defined_names(self):
        return {}
