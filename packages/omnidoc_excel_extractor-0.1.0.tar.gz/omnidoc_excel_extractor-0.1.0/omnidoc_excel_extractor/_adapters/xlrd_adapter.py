"""Thin adapter that wraps xlrd workbook to expose an openpyxl-like interface."""
from __future__ import annotations

from datetime import datetime, date
from typing import Any, Iterator, List, Optional

import xlrd
from xlrd import xldate_as_datetime


class _FakeProps:
    def __init__(self, wb: xlrd.Book) -> None:
        self.creator = None
        self.created = None
        self.modified = None
        self.appVersion = None


class _FakeProtection:
    sheet = False
    password = None


class _FakeMergedCells:
    def __init__(self, ws: "XlrdSheetAdapter") -> None:
        self._ws = ws

    @property
    def ranges(self):
        return self._ws._merged_ranges()


class _MergeRange:
    def __init__(self, min_row, min_col, max_row, max_col):
        self.min_row = min_row
        self.min_col = min_col
        self.max_row = max_row
        self.max_col = max_col

    def __str__(self):
        from ..utils.cell_utils import col_index_to_letter
        tl = f"{col_index_to_letter(self.min_col)}{self.min_row}"
        br = f"{col_index_to_letter(self.max_col)}{self.max_row}"
        return f"{tl}:{br}"


class _FakeDataValidations:
    dataValidation = []


class _FakeConditionalFormatting:
    _cf_rules = {}


class _FakePageSetup:
    orientation = None


class _FakeRowBreaks:
    brk = []


class _FakeCell:
    def __init__(self, value: Any, row: int, col: int) -> None:
        self.value = value
        self.row = row
        self.column = col
        from ..utils.cell_utils import col_index_to_letter
        self.coordinate = f"{col_index_to_letter(col - 1)}{row}"
        self.comment = None


class XlrdSheetAdapter:
    def __init__(self, sheet: xlrd.sheet.Sheet, datemode: int) -> None:
        self._sheet = sheet
        self._datemode = datemode
        self.title = sheet.name
        self.sheet_state = "visible" if sheet.visibility == 0 else "hidden"
        self.protection = _FakeProtection()
        self.merged_cells = _FakeMergedCells(self)
        self.data_validations = _FakeDataValidations()
        self.conditional_formatting = _FakeConditionalFormatting()
        self.page_setup = _FakePageSetup()
        self.row_breaks = _FakeRowBreaks()
        self._charts: List = []
        self._images: List = []
        self._shapes: List = []
        self._pivots: List = []
        self._sparklineGroups: List = []
        self.tables: dict = {}

        props = getattr(sheet, "sheet_properties", None)
        self.sheet_properties = type("Props", (), {"tabColor": None})()
        view = type("View", (), {"zoomScale": None})()
        self.sheet_view = view
        self.freeze_panes = None
        self.print_area = None
        self.oddHeader = None
        self.oddFooter = None
        self.row_dimensions = {}
        self.column_dimensions = {}

    @property
    def min_row(self) -> int:
        return 1 if self._sheet.nrows > 0 else None

    @property
    def max_row(self) -> int:
        return self._sheet.nrows or None

    @property
    def min_column(self) -> int:
        return 1 if self._sheet.ncols > 0 else None

    @property
    def max_column(self) -> int:
        return self._sheet.ncols or None

    def iter_rows(self, values_only: bool = False):
        for r in range(self._sheet.nrows):
            cells = []
            for c in range(self._sheet.ncols):
                raw = self._sheet.cell(r, c)
                val = self._cell_value(raw)
                if values_only:
                    cells.append(val)
                else:
                    cells.append(_FakeCell(val, r + 1, c + 1))
            if values_only:
                yield tuple(cells)
            else:
                yield cells

    def _cell_value(self, cell: xlrd.sheet.Cell) -> Any:
        if cell.ctype == xlrd.XL_CELL_DATE:
            try:
                return xldate_as_datetime(cell.value, self._datemode).date()
            except Exception:
                return cell.value
        if cell.ctype == xlrd.XL_CELL_BOOLEAN:
            return bool(cell.value)
        if cell.ctype == xlrd.XL_CELL_EMPTY:
            return None
        return cell.value

    def __getitem__(self, row: int):
        r = row - 1
        return [_FakeCell(self._cell_value(self._sheet.cell(r, c)), r + 1, c + 1)
                for c in range(self._sheet.ncols)]

    def _merged_ranges(self):
        ranges = []
        for rlo, rhi, clo, chi in self._sheet.merged_cells:
            ranges.append(_MergeRange(rlo + 1, clo, rhi, chi - 1))
        return ranges


class XlrdWorkbookAdapter:
    def __init__(self, wb: xlrd.Book) -> None:
        self._wb = wb
        self.properties = _FakeProps(wb)
        self._sheets = [XlrdSheetAdapter(wb.sheet_by_index(i), wb.datemode)
                        for i in range(wb.nsheets)]
        self._external_links: List = []
        self._connections: List = []
        self.custom_xml_parts: List = []

    @property
    def sheetnames(self) -> List[str]:
        return self._wb.sheet_names()

    @property
    def worksheets(self):
        return self._sheets

    def defined_names(self):
        return {}

    @property
    def defined_names(self):
        return {}
