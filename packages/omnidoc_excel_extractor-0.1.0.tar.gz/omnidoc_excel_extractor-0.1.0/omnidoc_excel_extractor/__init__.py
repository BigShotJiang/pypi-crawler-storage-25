"""
omnidoc-excel-extractor
~~~~~~~~~~~~~~~~~~~~~~~
Comprehensive Excel extraction SDK — 57 structured chunk types for AI/LLM/RAG pipelines.

Supported formats: .xlsx  .xlsm  .xlsb  .xls

Quick start::

    from omnidoc_excel_extractor import ExcelExtractor

    extractor = ExcelExtractor("report.xlsx")
    result = extractor.extract()

    print(result.summary())          # chunk counts by type
    dicts = result.to_dicts()        # JSON-serialisable list[dict]
    schema = result.by_type("SchemaChunk")
"""

from .core.extractor import ExcelExtractor, ExtractionResult  # noqa: F401
from .chunks.models import CHUNK_REGISTRY, BaseChunk  # noqa: F401

__version__ = "0.1.0"
__all__ = ["ExcelExtractor", "ExtractionResult", "BaseChunk", "CHUNK_REGISTRY", "__version__"]
