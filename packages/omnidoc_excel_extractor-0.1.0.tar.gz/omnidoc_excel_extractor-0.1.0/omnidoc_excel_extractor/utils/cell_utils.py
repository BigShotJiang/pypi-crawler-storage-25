"""Cell address and range utilities."""
from __future__ import annotations

import re
from typing import Iterator, Optional, Tuple


_COL_RE = re.compile(r"([A-Za-z]+)(\d+)")


def col_letter_to_index(col: str) -> int:
    """Convert column letter(s) to 0-based index ('A'→0, 'Z'→25, 'AA'→26)."""
    col = col.upper()
    result = 0
    for ch in col:
        result = result * 26 + (ord(ch) - ord("A") + 1)
    return result - 1


def col_index_to_letter(idx: int) -> str:
    """Convert 0-based column index to letter(s)."""
    result = ""
    idx += 1
    while idx:
        idx, rem = divmod(idx - 1, 26)
        result = chr(65 + rem) + result
    return result


def parse_cell_address(addr: str) -> Tuple[str, int]:
    """Return (col_letter, row_1based) from an address like 'B3'."""
    m = _COL_RE.match(addr.strip().upper())
    if not m:
        raise ValueError(f"Invalid cell address: {addr!r}")
    return m.group(1), int(m.group(2))


def parse_range(range_str: str) -> Tuple[str, str]:
    """Split 'A1:C10' into ('A1', 'C10')."""
    parts = range_str.strip().split(":")
    if len(parts) == 1:
        return parts[0], parts[0]
    return parts[0], parts[1]


def range_to_bounds(range_str: str) -> Tuple[int, int, int, int]:
    """Return (min_row, min_col, max_row, max_col) as 1-based indices."""
    top_left, bottom_right = parse_range(range_str)
    tl_col, tl_row = parse_cell_address(top_left)
    br_col, br_row = parse_cell_address(bottom_right)
    return (
        tl_row,
        col_letter_to_index(tl_col) + 1,
        br_row,
        col_letter_to_index(br_col) + 1,
    )


def iter_range_addresses(range_str: str) -> Iterator[str]:
    """Yield every cell address within a range string."""
    min_row, min_col, max_row, max_col = range_to_bounds(range_str)
    for row in range(min_row, max_row + 1):
        for col in range(min_col, max_col + 1):
            yield f"{col_index_to_letter(col - 1)}{row}"


def sheet_qualified(sheet_name: str, addr: str) -> str:
    return f"'{sheet_name}'!{addr}"


def strip_sheet_prefix(addr: str) -> str:
    """Remove 'SheetName!' prefix from a cell reference."""
    if "!" in addr:
        return addr.split("!")[-1]
    return addr


def used_range_str(ws) -> Optional[str]:
    """Return the used-range string for an openpyxl worksheet, or None."""
    try:
        if ws.min_row and ws.max_row and ws.min_column and ws.max_column:
            tl = f"{col_index_to_letter(ws.min_column - 1)}{ws.min_row}"
            br = f"{col_index_to_letter(ws.max_column - 1)}{ws.max_row}"
            return f"{tl}:{br}"
    except Exception:
        pass
    return None
