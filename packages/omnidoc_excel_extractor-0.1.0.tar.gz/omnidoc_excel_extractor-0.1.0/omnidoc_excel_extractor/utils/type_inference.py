"""Column data-type inference and semantic role detection."""
from __future__ import annotations

import re
from datetime import date, datetime
from typing import Any, Dict, List, Optional, Sequence

_CURRENCY_RE = re.compile(r"^\s*[\$€£¥₹]")
_PCT_RE = re.compile(r"%\s*$")
_DATE_KEYWORDS = {"date", "time", "year", "month", "quarter", "period", "dt", "day"}
_ID_KEYWORDS = {"id", "key", "code", "num", "number", "no", "ref", "idx"}
_FLAG_KEYWORDS = {"flag", "is_", "has_", "active", "enabled", "status"}
_MEASURE_KEYWORDS = {
    "amount", "qty", "quantity", "total", "sum", "count", "value",
    "revenue", "cost", "price", "rate", "ratio", "score", "pct", "percent",
}


def infer_dtype(values: Sequence[Any]) -> str:
    """Return the dominant dtype: numeric / date / boolean / text / mixed."""
    clean = [v for v in values if v is not None and v != ""]
    if not clean:
        return "text"
    type_counts: Dict[str, int] = {"numeric": 0, "date": 0, "boolean": 0, "text": 0}
    for v in clean:
        if isinstance(v, bool):
            type_counts["boolean"] += 1
        elif isinstance(v, (int, float)):
            type_counts["numeric"] += 1
        elif isinstance(v, (date, datetime)):
            type_counts["date"] += 1
        else:
            s = str(v).strip()
            if _try_numeric(s):
                type_counts["numeric"] += 1
            elif _try_bool(s):
                type_counts["boolean"] += 1
            else:
                type_counts["text"] += 1
    dominant = max(type_counts, key=lambda k: type_counts[k])
    total = sum(type_counts.values())
    if type_counts[dominant] / total >= 0.75:
        return dominant
    return "mixed"


def _try_numeric(s: str) -> bool:
    s = s.replace(",", "").replace("$", "").replace("€", "").replace("£", "").strip()
    try:
        float(s.rstrip("%"))
        return True
    except ValueError:
        return False


def _try_bool(s: str) -> bool:
    return s.lower() in {"true", "false", "yes", "no", "y", "n", "1", "0"}


def infer_column_role(col_name: str, dtype: str) -> str:
    """Infer semantic role: id / measure / dimension / date / flag / freetext."""
    lower = col_name.lower().replace(" ", "_")
    if dtype == "date":
        return "date"
    if any(kw in lower for kw in _DATE_KEYWORDS):
        return "date"
    if any(lower.startswith(kw) or lower.endswith(kw) for kw in _FLAG_KEYWORDS):
        return "flag"
    if dtype == "boolean":
        return "flag"
    if any(lower.endswith(kw) or lower.startswith(kw) for kw in _ID_KEYWORDS):
        return "id"
    if dtype == "numeric" and any(kw in lower for kw in _MEASURE_KEYWORDS):
        return "measure"
    if dtype == "numeric":
        return "measure"
    if dtype == "text":
        return "dimension"
    return "freetext"


def detect_currency(col_name: str, sample_values: Sequence[Any]) -> Optional[str]:
    for v in sample_values:
        s = str(v)
        if "$" in s:
            return "USD"
        if "€" in s:
            return "EUR"
        if "£" in s:
            return "GBP"
        if "¥" in s:
            return "JPY"
        if "₹" in s:
            return "INR"
    return None


def detect_unit(col_name: str, sample_values: Sequence[Any]) -> Optional[str]:
    lower = col_name.lower()
    for v in sample_values:
        s = str(v)
        if _PCT_RE.search(s) or "pct" in lower or "percent" in lower or "ratio" in lower:
            return "%"
    if "kg" in lower:
        return "kg"
    if "km" in lower:
        return "km"
    if "mb" in lower:
        return "MB"
    if "gb" in lower:
        return "GB"
    return None


def normalize_header(header: str) -> str:
    """Convert header to snake_case normalized name."""
    s = str(header).strip()
    s = re.sub(r"[^\w\s]", "", s)
    s = re.sub(r"\s+", "_", s)
    return s.lower()


def generate_aliases(header: str) -> List[str]:
    """Generate common alias variants for a column header."""
    norm = normalize_header(header)
    parts = norm.split("_")
    aliases = set()
    aliases.add(norm.replace("_", " "))
    aliases.add("".join(p.capitalize() for p in parts))  # CamelCase
    if len(parts) > 1:
        aliases.add("".join(p[0] for p in parts).upper())  # ACRONYM
    aliases.discard(header)
    aliases.discard(norm)
    return sorted(aliases)


def generate_abbreviations(header: str) -> List[str]:
    norm = normalize_header(header)
    parts = norm.split("_")
    abbrevs = set()
    if len(parts) > 1:
        abbrevs.add("".join(p[0] for p in parts).lower())
    for p in parts:
        if len(p) > 4:
            abbrevs.add(p[:3])
    return sorted(abbrevs)
