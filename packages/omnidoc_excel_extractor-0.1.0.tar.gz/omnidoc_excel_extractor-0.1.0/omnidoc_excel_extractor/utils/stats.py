"""Statistical helpers for analytical chunk builders."""
from __future__ import annotations

import math
from typing import Any, List, Optional, Sequence, Tuple


def null_rate(values: Sequence[Any]) -> float:
    if not values:
        return 0.0
    nulls = sum(1 for v in values if v is None or v == "")
    return round(nulls / len(values), 4)


def unique_rate(values: Sequence[Any]) -> float:
    clean = [v for v in values if v is not None and v != ""]
    if not clean:
        return 0.0
    return round(len(set(str(v) for v in clean)) / len(clean), 4)


def dupe_rate(values: Sequence[Any]) -> float:
    return round(1.0 - unique_rate(values), 4)


def safe_mean(nums: Sequence[float]) -> Optional[float]:
    clean = [v for v in nums if v is not None and not math.isnan(float(v))]
    return sum(clean) / len(clean) if clean else None


def safe_stdev(nums: Sequence[float]) -> Optional[float]:
    clean = [float(v) for v in nums if v is not None]
    n = len(clean)
    if n < 2:
        return None
    mean = sum(clean) / n
    variance = sum((x - mean) ** 2 for x in clean) / (n - 1)
    return math.sqrt(variance)


def zscore_outliers(values: Sequence[Any], threshold: float = 3.0) -> List[Tuple[int, float, float]]:
    """Return [(index, value, z_score)] for outliers exceeding threshold."""
    nums = []
    for v in values:
        try:
            nums.append(float(v))
        except (TypeError, ValueError):
            nums.append(None)

    clean = [v for v in nums if v is not None]
    if len(clean) < 4:
        return []
    mean = sum(clean) / len(clean)
    std = safe_stdev(clean)
    if not std:
        return []
    results = []
    for i, v in enumerate(nums):
        if v is None:
            continue
        z = abs(v - mean) / std
        if z > threshold:
            results.append((i, v, round(z, 3)))
    return results


def iqr_outliers(values: Sequence[Any]) -> List[Tuple[int, float]]:
    """Return [(index, value)] for IQR-based outliers."""
    indexed = []
    for i, v in enumerate(values):
        try:
            indexed.append((i, float(v)))
        except (TypeError, ValueError):
            pass
    if len(indexed) < 4:
        return []
    sorted_vals = sorted(v for _, v in indexed)
    n = len(sorted_vals)
    q1 = sorted_vals[n // 4]
    q3 = sorted_vals[(3 * n) // 4]
    iqr = q3 - q1
    lo, hi = q1 - 1.5 * iqr, q3 + 1.5 * iqr
    return [(i, v) for i, v in indexed if v < lo or v > hi]


def detect_trend(values: Sequence[Any]) -> Tuple[Optional[str], Optional[float], Optional[float], Optional[float]]:
    """Return (direction, delta_abs, delta_pct, regression_slope)."""
    nums = []
    for v in values:
        try:
            nums.append(float(v))
        except (TypeError, ValueError):
            pass
    if len(nums) < 2:
        return None, None, None, None
    delta_abs = nums[-1] - nums[0]
    delta_pct = (delta_abs / nums[0] * 100) if nums[0] != 0 else None
    direction = "up" if delta_abs > 0 else ("down" if delta_abs < 0 else "flat")
    slope = _linear_slope(nums)
    return direction, round(delta_abs, 4), (round(delta_pct, 4) if delta_pct is not None else None), slope


def _linear_slope(ys: List[float]) -> Optional[float]:
    n = len(ys)
    if n < 2:
        return None
    xs = list(range(n))
    x_mean = sum(xs) / n
    y_mean = sum(ys) / n
    num = sum((x - x_mean) * (y - y_mean) for x, y in zip(xs, ys))
    den = sum((x - x_mean) ** 2 for x in xs)
    return round(num / den, 6) if den else None


def detect_frequency(dates: Sequence[Any]) -> Optional[str]:
    """Infer time series frequency from a sorted list of date-like objects."""
    from datetime import date, datetime, timedelta
    parsed = []
    for d in dates:
        if isinstance(d, datetime):
            parsed.append(d.date())
        elif isinstance(d, date):
            parsed.append(d)
    if len(parsed) < 2:
        return None
    deltas = sorted([(parsed[i + 1] - parsed[i]).days for i in range(len(parsed) - 1)])
    median_days = deltas[len(deltas) // 2]
    if median_days <= 1:
        return "daily"
    if median_days <= 8:
        return "weekly"
    if median_days <= 16:
        return "biweekly"
    if median_days <= 35:
        return "monthly"
    if median_days <= 100:
        return "quarterly"
    return "yearly"
