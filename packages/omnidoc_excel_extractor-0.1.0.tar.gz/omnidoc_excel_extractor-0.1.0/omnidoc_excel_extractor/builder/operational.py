"""Build operational / metadata chunks (55-57)."""
from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List

from ..chunks.models import PrintSettingsChunk, ChangeLogChunk, ChunkIndexChunk
from ..core.sheet_parser import get_print_settings


def build_print_settings_chunks(wb) -> List[PrintSettingsChunk]:
    chunks = []
    for ws in wb.worksheets:
        settings = get_print_settings(ws)
        if settings:
            chunks.append(PrintSettingsChunk(sheet_name=ws.title, **settings))
    return chunks


def build_change_log_chunks(wb) -> List[ChangeLogChunk]:
    """
    Extract tracked changes from shared workbooks.
    openpyxl exposes revision history via wb._revisions (available in some xlsx files).
    Falls back to scanning revision XML parts when available.
    """
    import re as _re
    chunks = []
    try:
        # Some xlsx files carry revision parts
        for ws in wb.worksheets:
            revisions = getattr(ws, "_revisions", []) or []
            for rev in revisions:
                chunks.append(ChangeLogChunk(
                    sheet_name=ws.title,
                    cell_addr=str(getattr(rev, "ref", "")),
                    old_value=getattr(rev, "old_value", None),
                    new_value=getattr(rev, "new_value", None),
                    author=getattr(rev, "author", None),
                    changed_at=getattr(rev, "dateTime", None),
                    change_type="edit",
                ))
    except Exception:
        pass

    # Also scan custom_xml_parts for revision XML
    try:
        for part in wb.custom_xml_parts:
            xml = part.xml.decode("utf-8", errors="ignore") if isinstance(part.xml, bytes) else part.xml
            if "<rrc:" not in xml and "revisionRowColumn" not in xml and "revCell" not in xml:
                continue
            for m in _re.finditer(
                r'<(?:rrc:)?revCell[^>]+r="([^"]+)"[^>]*/?>',
                xml, _re.IGNORECASE,
            ):
                chunks.append(ChangeLogChunk(
                    sheet_name="",
                    cell_addr=m.group(1),
                    change_type="edit",
                ))
    except Exception:
        pass
    return chunks


def build_chunk_index(all_chunks: List[Any], workbook_ref: str) -> ChunkIndexChunk:
    type_counts: Dict[str, int] = {}
    source_map: Dict[str, str] = {}
    chunk_ids = []
    for c in all_chunks:
        ct = c.chunk_type
        type_counts[ct] = type_counts.get(ct, 0) + 1
        chunk_ids.append(c.chunk_id)
        addr = getattr(c, "cell_address", None) or getattr(c, "cell_addr", None)
        if addr:
            sheet = getattr(c, "sheet_name", "")
            source_map[c.chunk_id] = f"{sheet}!{addr}" if sheet else addr

    return ChunkIndexChunk(
        workbook_ref=workbook_ref,
        all_chunk_ids=chunk_ids,
        type_counts=type_counts,
        source_address_map=source_map,
        created_at=datetime.utcnow(),
    )
