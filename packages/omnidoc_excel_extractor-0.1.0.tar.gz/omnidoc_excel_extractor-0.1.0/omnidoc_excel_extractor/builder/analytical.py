"""Build analytical chunks (16-23)."""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from ..chunks.models import (
    FormulaDefinitionChunk, FormulaResultChunk, KPIChunk,
    AggregationChunk, TemporalChunk, TrendChunk, OutlierChunk, LookupMapChunk,
)
from ..core.formula_extractor import (
    get_formula_cells, classify_formula, extract_named_refs,
    extract_precedents, detect_lookup_type, detect_agg_type, parse_formula_range,
)
from ..core.sheet_parser import get_all_values
from ..utils.type_inference import infer_dtype
from ..utils.stats import (
    null_rate, zscore_outliers, iqr_outliers, detect_trend, detect_frequency,
)


def build_formula_definition_chunks(wb) -> List[FormulaDefinitionChunk]:
    chunks = []
    for ws in wb.worksheets:
        for fc in get_formula_cells(ws):
            formula = fc["formula_string"]
            if not formula:
                continue
            chunks.append(FormulaDefinitionChunk(
                sheet_name=ws.title,
                cell_address=fc["cell_address"],
                formula_string=formula,
                formula_type=classify_formula(formula),
                named_refs=extract_named_refs(formula),
                precedents=extract_precedents(formula, ws.title),
            ))
    return chunks


def build_formula_result_chunks(
    wb, definition_chunks: List[FormulaDefinitionChunk]
) -> List[FormulaResultChunk]:
    """Pair formula results with their definition chunks."""
    def_map = {(c.sheet_name, c.cell_address): c.chunk_id for c in definition_chunks}
    chunks = []
    for ws in wb.worksheets:
        for row in ws.iter_rows():
            for cell in row:
                formula = cell.value if isinstance(cell.value, str) and cell.value.startswith("=") else None
                if formula is None:
                    continue
                cached_value = _get_cached_value(cell)
                has_error = str(cached_value).startswith("#") if cached_value else False
                error_type = str(cached_value).rstrip("!").replace("/", "").replace("?", "") if has_error else None
                chunks.append(FormulaResultChunk(
                    sheet_name=ws.title,
                    cell_address=cell.coordinate,
                    computed_value=cached_value,
                    value_type=type(cached_value).__name__ if cached_value is not None else None,
                    has_error=has_error,
                    error_type=error_type,
                    linked_definition_id=def_map.get((ws.title, cell.coordinate)),
                ))
    return chunks


def _get_cached_value(cell) -> Optional[Any]:
    try:
        # openpyxl stores cached value in data_only mode
        return cell.value
    except Exception:
        return None


def build_aggregation_chunks(wb) -> List[AggregationChunk]:
    chunks = []
    for ws in wb.worksheets:
        headers, data = get_all_values(ws)
        if not headers or not data:
            continue
        for i, h in enumerate(headers):
            col_vals = [row[i] if i < len(row) else None for row in data]
            try:
                nums = [float(v) for v in col_vals if v is not None]
            except (TypeError, ValueError):
                nums = []
            if not nums:
                continue
            for agg_type, val in [
                ("SUM", sum(nums)),
                ("AVG", sum(nums) / len(nums)),
                ("MIN", min(nums)),
                ("MAX", max(nums)),
                ("COUNT", len(nums)),
            ]:
                chunks.append(AggregationChunk(
                    sheet_name=ws.title,
                    col_name=h,
                    agg_type=agg_type,
                    value=round(val, 4),
                    source_range=None,
                ))
    return chunks


def build_temporal_chunks(wb) -> List[TemporalChunk]:
    from datetime import date, datetime
    chunks = []
    for ws in wb.worksheets:
        headers, data = get_all_values(ws)
        for i, h in enumerate(headers):
            col_vals = [row[i] if i < len(row) else None for row in data]
            dates = [v for v in col_vals if isinstance(v, (date, datetime))]
            if len(dates) < 2:
                continue
            dates_sorted = sorted(dates)
            freq = detect_frequency(dates_sorted)
            chunks.append(TemporalChunk(
                sheet_name=ws.title,
                date_col=h,
                frequency=freq,
                start_date=str(dates_sorted[0]),
                end_date=str(dates_sorted[-1]),
                gap_count=0,
                is_sorted=dates == dates_sorted,
            ))
    return chunks


def build_trend_chunks(wb) -> List[TrendChunk]:
    chunks = []
    for ws in wb.worksheets:
        headers, data = get_all_values(ws)
        for i, h in enumerate(headers):
            col_vals = [row[i] if i < len(row) else None for row in data]
            if infer_dtype(col_vals) != "numeric":
                continue
            direction, delta_abs, delta_pct, slope = detect_trend(col_vals)
            if direction is None:
                continue
            chunks.append(TrendChunk(
                sheet_name=ws.title,
                col_name=h,
                direction=direction,
                delta_abs=delta_abs,
                delta_pct=delta_pct,
                periods_compared=len([v for v in col_vals if v is not None]),
                regression_slope=slope,
            ))
    return chunks


def build_outlier_chunks(wb) -> List[OutlierChunk]:
    chunks = []
    for ws in wb.worksheets:
        headers, data = get_all_values(ws)
        for i, h in enumerate(headers):
            col_vals = [row[i] if i < len(row) else None for row in data]
            if infer_dtype(col_vals) != "numeric":
                continue
            for idx, val, z in zscore_outliers(col_vals):
                from ..utils.cell_utils import col_index_to_letter
                col_letter = col_index_to_letter(i)
                row_num = idx + 2  # +1 header, +1 for 1-based
                severity = "high" if z > 5 else ("medium" if z > 4 else "low")
                chunks.append(OutlierChunk(
                    sheet_name=ws.title,
                    col_name=h,
                    outlier_type="zscore",
                    cell_addr=f"{col_letter}{row_num}",
                    value=val,
                    z_score=z,
                    severity=severity,
                ))
    return chunks


def build_lookup_map_chunks(wb) -> List[LookupMapChunk]:
    chunks = []
    for ws in wb.worksheets:
        for fc in get_formula_cells(ws):
            formula = fc["formula_string"]
            if not formula:
                continue
            ltype = detect_lookup_type(formula)
            if ltype:
                chunks.append(LookupMapChunk(
                    sheet_name=ws.title,
                    cell_address=fc["cell_address"],
                    lookup_type=ltype,
                    lookup_range=parse_formula_range(formula),
                ))
    return chunks


def build_kpi_chunks(wb) -> List[KPIChunk]:
    """
    Detect KPI-like cells: a labelled single numeric value adjacent to a text label.
    Heuristic: if row has 1–2 cols where col-A is a text label and col-B is numeric,
    or a single isolated large numeric preceded by a label in the row above.
    """
    import re
    _KPI_LABEL_RE = re.compile(
        r'\b(total|revenue|profit|loss|margin|growth|count|rate|ratio|score|'
        r'budget|forecast|actual|target|kpi|sales|cost|income|ebitda|roi|'
        r'nps|csat|churn|conversion|cac|ltv|arr|mrr)\b',
        re.IGNORECASE,
    )
    chunks = []
    for ws in wb.worksheets:
        try:
            rows = list(ws.iter_rows())
        except Exception:
            continue

        for row in rows:
            # Pattern: [label_cell, value_cell] in same row, 2–4 columns wide
            for i in range(len(row) - 1):
                label_cell = row[i]
                value_cell = row[i + 1]
                label_val = label_cell.value
                num_val = value_cell.value
                if not isinstance(label_val, str):
                    continue
                if not isinstance(num_val, (int, float)):
                    continue
                if not _KPI_LABEL_RE.search(label_val):
                    continue
                chunks.append(KPIChunk(
                    sheet_name=ws.title,
                    kpi_name=label_val.strip(),
                    value=num_val,
                    source_cell=value_cell.coordinate,
                ))
    return chunks
