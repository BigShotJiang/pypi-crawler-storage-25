"""Build connectivity / Power Features chunks (51-54)."""
from __future__ import annotations

from typing import List

from ..chunks.models import (
    PowerQueryChunk, DataModelChunk, PowerPivotMeasureChunk, ConnectionChunk,
)
from ..core.workbook_parser import get_connections


def build_power_query_chunks(wb, workbook_name: str) -> List[PowerQueryChunk]:
    """Extract Power Query definitions from the workbook's custom XML parts."""
    chunks = []
    try:
        for part in wb.custom_xml_parts:
            xml = part.xml.decode("utf-8", errors="ignore") if isinstance(part.xml, bytes) else part.xml
            if "Query" in xml and "Source" in xml:
                import re
                names = re.findall(r'Name="([^"]+)"', xml)
                for name in names:
                    chunks.append(PowerQueryChunk(
                        workbook=workbook_name,
                        query_name=name,
                    ))
    except Exception:
        pass
    return chunks


def build_connection_chunks(wb, workbook_name: str) -> List[ConnectionChunk]:
    connections = get_connections(wb)
    return [
        ConnectionChunk(workbook=workbook_name, **c)
        for c in connections
    ]


def build_data_model_chunk(wb, workbook_name: str) -> List[DataModelChunk]:
    """Attempt to extract data model (PowerPivot) info from the workbook."""
    import re as _re
    chunks = []
    try:
        for part in wb.custom_xml_parts:
            xml = part.xml.decode("utf-8", errors="ignore") if isinstance(part.xml, bytes) else part.xml
            if "DataModel" in xml or "Relationship" in xml:
                tables = _re.findall(r'<Table[^>]+Name="([^"]+)"', xml)
                rel_froms = _re.findall(r'FromTable="([^"]+)"', xml)
                rel_tos = _re.findall(r'ToTable="([^"]+)"', xml)
                relationships = [
                    {"from_table": f, "to_table": t, "on_col": ""}
                    for f, t in zip(rel_froms, rel_tos)
                ]
                chunks.append(DataModelChunk(
                    workbook=workbook_name,
                    tables=tables,
                    relationships=relationships,
                    dax_measures=[],
                    dax_columns=[],
                ))
                break
    except Exception:
        pass
    return chunks


def build_power_pivot_measure_chunks(wb, workbook_name: str) -> List[PowerPivotMeasureChunk]:
    """Extract DAX measure definitions from the PowerPivot data model XML."""
    import re as _re
    chunks = []
    try:
        for part in wb.custom_xml_parts:
            xml = part.xml.decode("utf-8", errors="ignore") if isinstance(part.xml, bytes) else part.xml
            # Look for measure definitions in DataModel XML
            measures = _re.finditer(
                r'<Measure[^>]*Name="([^"]+)"[^>]*>.*?<Expression>(.*?)</Expression>',
                xml, _re.DOTALL | _re.IGNORECASE,
            )
            for m in measures:
                chunks.append(PowerPivotMeasureChunk(
                    workbook=workbook_name,
                    measure_name=m.group(1),
                    dax_expression=m.group(2).strip(),
                ))
            # Also look for <m:Measure> patterns (alternate schema)
            alt_measures = _re.finditer(
                r'measureName="([^"]+)"[^/]*/?>.*?<dax:Expression>(.*?)</dax:Expression>',
                xml, _re.DOTALL | _re.IGNORECASE,
            )
            for m in alt_measures:
                chunks.append(PowerPivotMeasureChunk(
                    workbook=workbook_name,
                    measure_name=m.group(1),
                    dax_expression=m.group(2).strip(),
                ))
    except Exception:
        pass
    return chunks
