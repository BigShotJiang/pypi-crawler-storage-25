"""Build structural chunks (1-9)."""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from ..chunks.models import (
    WorkbookChunk, SheetChunk, TableChunk, SchemaChunk,
    RowChunk, GroupChunk, ParentContextChunk, MergedCellChunk, FrozenPaneChunk,
)
from ..core.sheet_parser import (
    parse_sheet_meta, get_all_values, get_merged_cells,
    get_frozen_pane, get_row_groups, get_col_groups,
)
from ..core.workbook_parser import parse_workbook_meta
from ..utils.type_inference import infer_dtype
from ..utils.stats import null_rate, unique_rate

_ROW_BATCH = 500


def build_workbook_chunk(wb, file_path: str) -> WorkbookChunk:
    meta = parse_workbook_meta(wb, file_path)
    return WorkbookChunk(**meta)


def build_sheet_chunks(wb) -> List[SheetChunk]:
    chunks = []
    for idx, ws in enumerate(wb.worksheets):
        meta = parse_sheet_meta(ws, idx)
        chunks.append(SheetChunk(**meta))
    return chunks


def build_table_chunks(wb) -> List[TableChunk]:
    chunks = []
    for ws in wb.worksheets:
        for tbl in ws.tables.values():
            ref = tbl.ref or ""
            chunks.append(TableChunk(
                table_name=tbl.name,
                sheet_name=ws.title,
                address=ref,
                style=tbl.tableStyleInfo.name if tbl.tableStyleInfo else None,
                has_total_row=tbl.totalsRowShown if tbl.totalsRowShown else False,
                has_header_row=tbl.headerRowCount != 0,
                col_count=len(tbl.tableColumns),
                row_count=_table_row_count(ws, ref),
            ))
    return chunks


def _table_row_count(ws, ref: str) -> int:
    try:
        from openpyxl.utils.cell import range_boundaries
        min_col, min_row, max_col, max_row = range_boundaries(ref)
        return max(0, max_row - min_row)
    except Exception:
        return 0


def build_schema_chunks(wb) -> List[SchemaChunk]:
    chunks = []
    for ws in wb.worksheets:
        headers, data = get_all_values(ws)
        if not headers:
            continue
        columns = _build_column_schema(headers, data)
        chunks.append(SchemaChunk(
            sheet_name=ws.title,
            columns=columns,
            header_row_addr=f"A1:{_col_letter(len(headers))}1",
            inferred_pk=_infer_pk(headers, data),
        ))
    return chunks


def _build_column_schema(headers: List[str], data: List[List[Any]]) -> List[Dict[str, Any]]:
    cols = []
    for i, h in enumerate(headers):
        col_vals = [row[i] if i < len(row) else None for row in data]
        dtype = infer_dtype(col_vals)
        clean = [v for v in col_vals if v is not None and v != ""]
        sample = [str(v) for v in clean[:5]]
        cols.append({
            "name": h,
            "data_type": dtype,
            "null_rate": null_rate(col_vals),
            "unique_rate": unique_rate(col_vals),
            "sample_values": sample,
        })
    return cols


def _infer_pk(headers: List[str], data: List[List[Any]]) -> Optional[str]:
    for i, h in enumerate(headers):
        col_vals = [row[i] if i < len(row) else None for row in data]
        if unique_rate(col_vals) == 1.0 and null_rate(col_vals) == 0.0:
            return h
    return None


def _col_letter(n: int) -> str:
    from ..utils.cell_utils import col_index_to_letter
    return col_index_to_letter(n - 1)


def build_row_chunks(wb, batch_size: int = _ROW_BATCH) -> List[RowChunk]:
    chunks = []
    for ws in wb.worksheets:
        headers, data = get_all_values(ws)
        if not headers or not data:
            continue
        for batch_start in range(0, len(data), batch_size):
            batch = data[batch_start:batch_start + batch_size]
            for offset, row_vals in enumerate(batch):
                row_idx = batch_start + offset + 2  # +2: 1-based + skip header
                values = {headers[i]: row_vals[i] for i in range(min(len(headers), len(row_vals)))}
                chunks.append(RowChunk(
                    row_index=row_idx,
                    values=values,
                    parent_sheet=ws.title,
                    batch_start=batch_start + 2,
                    batch_end=min(batch_start + batch_size + 1, len(data) + 1),
                ))
    return chunks


def build_group_chunks(wb) -> List[GroupChunk]:
    chunks = []
    for ws in wb.worksheets:
        for g in get_row_groups(ws) + get_col_groups(ws):
            chunks.append(GroupChunk(sheet_name=ws.title, **g))
    return chunks


def build_parent_context_chunks(wb) -> List[ParentContextChunk]:
    """One ParentContextChunk per sheet (breadcrumb)."""
    chunks = []
    wb_name = wb.properties.creator or "workbook"
    for ws in wb.worksheets:
        chunks.append(ParentContextChunk(
            workbook=wb_name,
            sheet=ws.title,
        ))
    return chunks


def build_merged_cell_chunks(wb) -> List[MergedCellChunk]:
    chunks = []
    for ws in wb.worksheets:
        for mc in get_merged_cells(ws):
            chunks.append(MergedCellChunk(sheet_name=ws.title, **mc))
    return chunks


def build_frozen_pane_chunks(wb) -> List[FrozenPaneChunk]:
    chunks = []
    for ws in wb.worksheets:
        fp = get_frozen_pane(ws)
        if fp:
            chunks.append(FrozenPaneChunk(sheet_name=ws.title, **fp))
    return chunks
