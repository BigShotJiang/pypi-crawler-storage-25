"""Build cross-reference and linkage chunks (47-50)."""
from __future__ import annotations

from typing import Any, Dict, List

from ..chunks.models import (
    RelationshipChunk, NamedRangeChunk, ExternalLinkChunk, DependencyGraphChunk,
)
from ..core.formula_extractor import (
    get_formula_cells, extract_precedents, detect_lookup_type,
)
from ..core.workbook_parser import get_named_ranges, get_external_links


def build_named_range_chunks(wb) -> List[NamedRangeChunk]:
    named_ranges = get_named_ranges(wb)
    return [
        NamedRangeChunk(
            range_name=nr["range_name"],
            refers_to=nr["refers_to"],
            scope=str(nr["scope"]),
        )
        for nr in named_ranges
    ]


def build_external_link_chunks(wb, workbook_name: str) -> List[ExternalLinkChunk]:
    links = get_external_links(wb)
    return [
        ExternalLinkChunk(workbook=workbook_name, **lnk)
        for lnk in links
    ]


def build_relationship_chunks(wb) -> List[RelationshipChunk]:
    """Build cross-sheet relationship chunks from lookup formulas."""
    chunks = []
    for ws in wb.worksheets:
        for fc in get_formula_cells(ws):
            formula = fc["formula_string"]
            if not formula:
                continue
            rel_type = detect_lookup_type(formula)
            if not rel_type:
                # Also capture direct sheet references
                if "!" in formula:
                    rel_type = "direct_ref"
                else:
                    continue
            precedents = extract_precedents(formula, ws.title)
            for ref in precedents:
                if "!" in ref:
                    target_sheet = ref.split("!")[0].strip("'")
                    target_cell = ref.split("!")[-1]
                    if target_sheet != ws.title:
                        chunks.append(RelationshipChunk(
                            source_sheet=ws.title,
                            source_cell=fc["cell_address"],
                            target_cell=target_cell,
                            target_sheet=target_sheet,
                            rel_type=rel_type or "direct_ref",
                            formula=formula,
                        ))
    return chunks


def build_dependency_graph_chunks(wb) -> List[DependencyGraphChunk]:
    """Build a dependency graph per sheet using formula precedents."""
    try:
        import networkx as nx
    except ImportError:
        return []

    chunks = []
    for ws in wb.worksheets:
        G = nx.DiGraph()
        for fc in get_formula_cells(ws):
            formula = fc["formula_string"]
            if not formula:
                continue
            src = f"{ws.title}!{fc['cell_address']}"
            G.add_node(src)
            for ref in extract_precedents(formula, ws.title):
                G.add_node(ref)
                G.add_edge(ref, src, type="precedent")

        has_circular = not nx.is_directed_acyclic_graph(G) if G.edges else False
        max_depth = 0
        try:
            max_depth = nx.dag_longest_path_length(G) if G.edges and not has_circular else 0
        except Exception:
            pass

        edges = [{"from": u, "to": v, "type": d.get("type", "")} for u, v, d in G.edges(data=True)]
        chunks.append(DependencyGraphChunk(
            sheet_name=ws.title,
            nodes=list(G.nodes),
            edges=edges,
            max_depth=max_depth,
            has_circular_ref=has_circular,
        ))
    return chunks
