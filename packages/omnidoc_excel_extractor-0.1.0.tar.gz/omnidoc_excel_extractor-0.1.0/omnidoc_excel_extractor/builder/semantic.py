"""Build semantic chunks (10-15)."""
from __future__ import annotations

from typing import Any, Dict, List

from ..chunks.models import (
    SummaryChunk, SemanticNarrativeChunk, ColumnSemanticChunk,
    HeaderAliasChunk, EntityChunk, CellAnnotationChunk,
)
from ..core.sheet_parser import get_all_values, get_comments
from ..utils.type_inference import (
    infer_dtype, infer_column_role, detect_currency, detect_unit,
    normalize_header, generate_aliases, generate_abbreviations,
)
from ..utils.stats import null_rate, dupe_rate


def build_summary_chunks(wb) -> List[SummaryChunk]:
    chunks = []
    for ws in wb.worksheets:
        headers, data = get_all_values(ws)
        if not headers:
            continue
        numeric_cols, date_cols, text_cols = [], [], []
        for i, h in enumerate(headers):
            col_vals = [row[i] if i < len(row) else None for row in data]
            dt = infer_dtype(col_vals)
            if dt == "numeric":
                numeric_cols.append(h)
            elif dt == "date":
                date_cols.append(h)
            else:
                text_cols.append(h)

        all_vals = [v for row in data for v in row]
        chunks.append(SummaryChunk(
            sheet_name=ws.title,
            row_count=len(data),
            col_count=len(headers),
            numeric_cols=numeric_cols,
            date_cols=date_cols,
            text_cols=text_cols,
            null_rate=null_rate(all_vals),
            dupe_rate=dupe_rate(all_vals),
        ))
    return chunks


def build_semantic_narrative_chunks(wb) -> List[SemanticNarrativeChunk]:
    chunks = []
    for ws in wb.worksheets:
        headers, data = get_all_values(ws)
        if not headers or not data:
            continue
        narrative = _generate_narrative(ws.title, headers, data)
        chunks.append(SemanticNarrativeChunk(
            scope="sheet",
            scope_name=ws.title,
            narrative=narrative,
            subject=ws.title,
            confidence=0.8,
        ))
    return chunks


def _generate_narrative(sheet_name: str, headers: List[str], data: List[List[Any]]) -> str:
    n_rows = len(data)
    n_cols = len(headers)
    col_summary = ", ".join(headers[:8])
    if len(headers) > 8:
        col_summary += f" and {len(headers) - 8} more"
    return (
        f"Sheet '{sheet_name}' contains {n_rows} data rows across {n_cols} columns: "
        f"{col_summary}."
    )


def build_column_semantic_chunks(wb) -> List[ColumnSemanticChunk]:
    chunks = []
    for ws in wb.worksheets:
        headers, data = get_all_values(ws)
        for i, h in enumerate(headers):
            col_vals = [row[i] if i < len(row) else None for row in data]
            dtype = infer_dtype(col_vals)
            role = infer_column_role(h, dtype)
            currency = detect_currency(h, col_vals[:20])
            unit = detect_unit(h, col_vals[:20])
            chunks.append(ColumnSemanticChunk(
                sheet_name=ws.title,
                col_name=h,
                role=role,
                unit=unit,
                currency=currency,
                is_pk=False,
                is_fk=False,
            ))
    return chunks


def build_header_alias_chunks(wb) -> List[HeaderAliasChunk]:
    chunks = []
    for ws in wb.worksheets:
        headers, _ = get_all_values(ws)
        for h in headers:
            norm = normalize_header(h)
            chunks.append(HeaderAliasChunk(
                sheet_name=ws.title,
                original_header=h,
                aliases=generate_aliases(h),
                abbreviations=generate_abbreviations(h),
                normalized_name=norm,
            ))
    return chunks


def build_cell_annotation_chunks(wb) -> List[CellAnnotationChunk]:
    chunks = []
    for ws in wb.worksheets:
        for comment in get_comments(ws):
            chunks.append(CellAnnotationChunk(sheet_name=ws.title, **comment))
    return chunks


def build_entity_chunks(wb) -> List[EntityChunk]:
    """
    Detect common entities (person names, orgs, locations, dates) in text columns
    using simple heuristics — no NLP dependency required.
    """
    import re
    workbook_name = getattr(wb.properties, "creator", None) or "workbook"

    _PERSON_RE = re.compile(r'\b([A-Z][a-z]+ [A-Z][a-z]+)\b')
    _EMAIL_RE = re.compile(r'\b[\w.+-]+@[\w-]+\.[a-z]{2,}\b')
    _URL_RE = re.compile(r'https?://\S+')
    _DATE_PATTERNS = re.compile(
        r'\b(\d{4}-\d{2}-\d{2}|\d{1,2}/\d{1,2}/\d{2,4}|'
        r'(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\w*\.?\s+\d{1,2},?\s+\d{4})\b',
        re.IGNORECASE,
    )

    freq_map: Dict[tuple, int] = {}
    source_map: Dict[tuple, list] = {}

    for ws in wb.worksheets:
        headers, data = get_all_values(ws)
        for i, h in enumerate(headers):
            col_vals = [row[i] if i < len(row) else None for row in data]
            if infer_dtype(col_vals) != "text":
                continue
            for v in col_vals:
                if not isinstance(v, str) or not v.strip():
                    continue
                for m in _PERSON_RE.finditer(v):
                    key = ("person", m.group(0))
                    freq_map[key] = freq_map.get(key, 0) + 1
                    source_map.setdefault(key, [])
                    if h not in source_map[key]:
                        source_map[key].append(h)
                for m in _EMAIL_RE.finditer(v):
                    key = ("org", m.group(0))
                    freq_map[key] = freq_map.get(key, 0) + 1
                    source_map.setdefault(key, [])
                    if h not in source_map[key]:
                        source_map[key].append(h)
                for m in _DATE_PATTERNS.finditer(v):
                    key = ("date", m.group(0))
                    freq_map[key] = freq_map.get(key, 0) + 1
                    source_map.setdefault(key, [])
                    if h not in source_map[key]:
                        source_map[key].append(h)

    chunks = []
    for (etype, value), freq in freq_map.items():
        chunks.append(EntityChunk(
            workbook=workbook_name,
            entity_type=etype,
            value=value,
            frequency=freq,
            source_columns=source_map.get((etype, value), []),
            canonical=value,
        ))
    return chunks
