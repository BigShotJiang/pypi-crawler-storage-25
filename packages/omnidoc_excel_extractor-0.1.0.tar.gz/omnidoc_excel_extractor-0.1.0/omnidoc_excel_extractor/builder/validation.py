"""Build validation / QA chunks (24-28)."""
from __future__ import annotations

from typing import Any, Dict, List

from ..chunks.models import (
    ValidationChunk, ErrorChunk, ConditionalFormatChunk,
    ProtectionChunk, DataQualityChunk,
)
from ..core.sheet_parser import (
    get_all_values, get_data_validations, get_conditional_formats,
)
from ..core.formula_extractor import get_error_cells
from ..utils.type_inference import infer_dtype
from ..utils.stats import null_rate


def build_validation_chunks(wb) -> List[ValidationChunk]:
    chunks = []
    for ws in wb.worksheets:
        for dv in get_data_validations(ws):
            chunks.append(ValidationChunk(sheet_name=ws.title, **dv))
    return chunks


def build_error_chunks(wb) -> List[ErrorChunk]:
    chunks = []
    for ws in wb.worksheets:
        for ec in get_error_cells(ws):
            chunks.append(ErrorChunk(sheet_name=ws.title, **ec))
    return chunks


def build_conditional_format_chunks(wb) -> List[ConditionalFormatChunk]:
    chunks = []
    for ws in wb.worksheets:
        for cf in get_conditional_formats(ws):
            chunks.append(ConditionalFormatChunk(sheet_name=ws.title, **cf))
    return chunks


def build_protection_chunks(wb) -> List[ProtectionChunk]:
    chunks = []
    for ws in wb.worksheets:
        prot = ws.protection
        if not prot:
            continue
        is_protected = bool(prot.sheet)
        if is_protected:
            chunks.append(ProtectionChunk(
                sheet_name=ws.title,
                scope="sheet",
                is_password_protected=bool(prot.password),
                locked_ranges=[],
                allowed_edit_ranges=[],
            ))
    return chunks


def build_data_quality_chunks(wb) -> List[DataQualityChunk]:
    chunks = []
    for ws in wb.worksheets:
        headers, data = get_all_values(ws)
        if not headers or not data:
            continue
        for i, h in enumerate(headers):
            col_vals = [row[i] if i < len(row) else None for row in data]
            blanks = sum(1 for v in col_vals if v is None or v == "")
            dupes = len(col_vals) - len(set(str(v) for v in col_vals if v is not None))
            dtype = infer_dtype(col_vals)
            mismatches = 0
            if dtype == "numeric":
                for v in col_vals:
                    if v is not None and v != "":
                        try:
                            float(v)
                        except (TypeError, ValueError):
                            mismatches += 1
            chunks.append(DataQualityChunk(
                sheet_name=ws.title,
                col_name=h,
                blank_count=blanks,
                dupe_count=max(0, dupes),
                type_mismatch_count=mismatches,
                out_of_range_count=0,
                flagged_cells=[],
            ))
    return chunks
