"""Build visual chunks — charts, pivots, sparklines, shapes, images (29-41)."""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from ..chunks.models import (
    ChartChunk, ChartSeriesChunk, ChartAnnotationChunk,
    PivotTableChunk, PivotFieldChunk, PivotCacheChunk,
    SlicerChunk, TimelineChunk,
    SparklineChunk, ShapeChunk, ImageChunk,
    FormControlChunk, ActiveXControlChunk,
)


# ---------------------------------------------------------------------------
# Charts
# ---------------------------------------------------------------------------

def build_chart_chunks(wb) -> List[ChartChunk]:
    chunks = []
    for ws in wb.worksheets:
        for chart in ws._charts:
            chart_type = _classify_chart(chart)
            title = _safe_chart_title(chart)
            series_meta = _extract_series_meta(chart)
            anchor = _chart_anchor(chart)
            chunks.append(ChartChunk(
                sheet_name=ws.title,
                chart_name=title or f"{chart_type}_{len(chunks)}",
                chart_type=chart_type,
                title=title,
                series=series_meta,
                sheet_anchor=anchor,
            ))
    return chunks


def build_chart_series_chunks(wb, chart_chunks: List[ChartChunk]) -> List[ChartSeriesChunk]:
    chunks = []
    chart_idx = 0
    for ws in wb.worksheets:
        for chart in ws._charts:
            if chart_idx >= len(chart_chunks):
                break
            chart_id = chart_chunks[chart_idx].chunk_id
            chart_idx += 1
            for s in getattr(chart, "series", []):
                title = None
                source_range = None
                try:
                    title = str(s.title) if s.title else None
                except Exception:
                    pass
                try:
                    source_range = str(s.val.numRef.f) if s.val and s.val.numRef else None
                except Exception:
                    pass
                chunks.append(ChartSeriesChunk(
                    chart_id=chart_id,
                    series_name=title,
                    source_range=source_range,
                ))
    return chunks


def _classify_chart(chart) -> str:
    cls_name = type(chart).__name__.lower()
    mapping = {
        "barchart": "bar", "linechart": "line", "piechart": "pie",
        "scatterchart": "scatter", "areachart": "area",
        "bubblechart": "bubble", "radarchart": "radar",
        "stockchart": "stock", "surfacechart": "surface",
    }
    for key, val in mapping.items():
        if key in cls_name:
            return val
    return "unknown"


def _safe_chart_title(chart) -> Optional[str]:
    try:
        t = chart.title
        if t is None:
            return None
        if hasattr(t, "tx"):
            return str(t.tx)
        return str(t)
    except Exception:
        return None


def _extract_series_meta(chart) -> List[Dict[str, Any]]:
    meta = []
    for s in getattr(chart, "series", []):
        entry: Dict[str, Any] = {}
        try:
            entry["name"] = str(s.title) if s.title else None
        except Exception:
            entry["name"] = None
        try:
            entry["range"] = str(s.val.numRef.f) if s.val and s.val.numRef else None
        except Exception:
            entry["range"] = None
        meta.append(entry)
    return meta


def _chart_anchor(chart) -> Optional[str]:
    try:
        anchor = chart.anchor
        if hasattr(anchor, "_from"):
            f = anchor._from
            return f"{f.col}{f.row}"
    except Exception:
        pass
    return None


# ---------------------------------------------------------------------------
# Pivot Tables
# ---------------------------------------------------------------------------

def build_pivot_table_chunks(wb) -> List[PivotTableChunk]:
    chunks = []
    for ws in wb.worksheets:
        for pt in getattr(ws, "_pivots", []):
            row_fields = _get_pivot_fields(pt, "row")
            col_fields = _get_pivot_fields(pt, "col")
            value_fields = _get_pivot_value_fields(pt)
            filter_fields = _get_pivot_fields(pt, "page")
            chunks.append(PivotTableChunk(
                sheet_name=ws.title,
                pivot_name=getattr(pt, "name", f"Pivot_{len(chunks)}"),
                source_range=_pivot_source_range(pt),
                row_fields=row_fields,
                col_fields=col_fields,
                value_fields=value_fields,
                filter_fields=filter_fields,
            ))
    return chunks


def build_pivot_field_chunks(wb, pivot_chunks: List[PivotTableChunk]) -> List[PivotFieldChunk]:
    chunks = []
    pi = 0
    for ws in wb.worksheets:
        for pt in getattr(ws, "_pivots", []):
            if pi >= len(pivot_chunks):
                break
            pivot_id = pivot_chunks[pi].chunk_id
            pi += 1
            for field in getattr(pt, "pivotFields", []):
                name = getattr(field, "name", None) or ""
                ftype = "value" if getattr(field, "dataField", False) else "row"
                chunks.append(PivotFieldChunk(
                    pivot_id=pivot_id,
                    field_name=name,
                    field_type=ftype,
                    subtotal_enabled=True,
                ))
    return chunks


def _get_pivot_fields(pt, ftype: str) -> List[str]:
    try:
        if ftype == "row":
            return [str(f.x) for f in pt.rowFields] if pt.rowFields else []
        if ftype == "col":
            return [str(f.x) for f in pt.colFields] if pt.colFields else []
        if ftype == "page":
            return [str(f.x) for f in pt.pageFields] if pt.pageFields else []
    except Exception:
        pass
    return []


def _get_pivot_value_fields(pt) -> List[Dict[str, str]]:
    try:
        result = []
        for df in pt.dataFields:
            result.append({
                "field": str(getattr(df, "name", "")),
                "agg": str(getattr(df, "subtotal", "sum")),
            })
        return result
    except Exception:
        return []


def _pivot_source_range(pt) -> Optional[str]:
    try:
        cache = pt.cache
        return str(cache.cacheSource.worksheetSource.ref)
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Sparklines
# ---------------------------------------------------------------------------

def build_sparkline_chunks(wb) -> List[SparklineChunk]:
    chunks = []
    for ws in wb.worksheets:
        try:
            for sg in ws._sparklineGroups:
                stype = getattr(sg, "type", "line") or "line"
                for sl in sg.sparklines:
                    chunks.append(SparklineChunk(
                        sheet_name=ws.title,
                        sparkline_type=stype,
                        host_cell=str(sl.ref),
                        source_range=str(sl.f),
                        markers=bool(getattr(sg, "markers", False)),
                    ))
        except Exception:
            pass
    return chunks


# ---------------------------------------------------------------------------
# Shapes / Images / Controls
# ---------------------------------------------------------------------------

def build_shape_chunks(wb) -> List[ShapeChunk]:
    chunks = []
    for ws in wb.worksheets:
        try:
            for shape in ws._shapes:
                text = None
                try:
                    text = shape.text
                except Exception:
                    pass
                chunks.append(ShapeChunk(
                    sheet_name=ws.title,
                    shape_name=getattr(shape, "name", None),
                    text_content=text,
                ))
        except Exception:
            pass
    return chunks


def build_image_chunks(wb) -> List[ImageChunk]:
    chunks = []
    for ws in wb.worksheets:
        try:
            for img in ws._images:
                anchor_cell = None
                try:
                    anchor_cell = str(img.anchor._from) if hasattr(img.anchor, "_from") else None
                except Exception:
                    pass
                chunks.append(ImageChunk(
                    sheet_name=ws.title,
                    image_type=getattr(img, "format", None),
                    anchor_cell=anchor_cell,
                    width_px=int(img.width) if hasattr(img, "width") and img.width else None,
                    height_px=int(img.height) if hasattr(img, "height") and img.height else None,
                ))
        except Exception:
            pass
    return chunks


# ---------------------------------------------------------------------------
# Chart Annotations
# ---------------------------------------------------------------------------

def build_chart_annotation_chunks(wb, chart_chunks: List[ChartChunk]) -> List[ChartAnnotationChunk]:
    """Extract text-box and data-label annotations from charts."""
    chunks = []
    chart_idx = 0
    for ws in wb.worksheets:
        for chart in ws._charts:
            if chart_idx >= len(chart_chunks):
                break
            chart_id = chart_chunks[chart_idx].chunk_id
            chart_idx += 1
            # Data labels
            try:
                for series in getattr(chart, "series", []):
                    dLbls = getattr(series, "dLbls", None)
                    if dLbls is not None:
                        chunks.append(ChartAnnotationChunk(
                            chart_id=chart_id,
                            annotation_type="data_label",
                            text=None,
                        ))
            except Exception:
                pass
            # Text boxes attached to chart
            try:
                for txb in getattr(chart, "txPr", []) or []:
                    text = str(txb) if txb else None
                    if text:
                        chunks.append(ChartAnnotationChunk(
                            chart_id=chart_id,
                            annotation_type="textbox",
                            text=text,
                        ))
            except Exception:
                pass
    return chunks


# ---------------------------------------------------------------------------
# Pivot Cache
# ---------------------------------------------------------------------------

def build_pivot_cache_chunks(wb, pivot_chunks: List[PivotTableChunk]) -> List[PivotCacheChunk]:
    """Build pivot cache metadata chunks."""
    chunks = []
    pi = 0
    for ws in wb.worksheets:
        for pt in getattr(ws, "_pivots", []):
            if pi >= len(pivot_chunks):
                break
            pivot_id = pivot_chunks[pi].chunk_id
            pi += 1
            record_count = None
            cache_range = None
            try:
                cache_range = _pivot_source_range(pt)
                # Count records from source range if possible
                src_sheet = getattr(pt.cache.cacheSource.worksheetSource, "sheet", None)
                if src_sheet and cache_range:
                    src_ws = next((s for s in wb.worksheets if s.title == src_sheet), None)
                    if src_ws:
                        _, data = __import__(
                            "omnidoc_excel_extractor.core.sheet_parser",
                            fromlist=["get_all_values"]
                        ).get_all_values(src_ws)
                        record_count = len(data)
            except Exception:
                pass
            chunks.append(PivotCacheChunk(
                pivot_id=pivot_id,
                cache_range=cache_range,
                record_count=record_count,
            ))
    return chunks


# ---------------------------------------------------------------------------
# Slicers & Timelines (extracted from custom XML parts)
# ---------------------------------------------------------------------------

def build_slicer_chunks(wb) -> List[SlicerChunk]:
    """Extract slicer definitions from workbook custom XML."""
    import re
    chunks = []
    try:
        for part in wb.custom_xml_parts:
            xml = part.xml.decode("utf-8", errors="ignore") if isinstance(part.xml, bytes) else part.xml
            if "slicer" not in xml.lower():
                continue
            names = re.findall(r'name="([^"]+)"', xml)
            captions = re.findall(r'caption="([^"]+)"', xml)
            for i, name in enumerate(names):
                chunks.append(SlicerChunk(
                    sheet_name="",
                    slicer_name=name,
                    field_name=captions[i] if i < len(captions) else None,
                ))
    except Exception:
        pass
    return chunks


def build_timeline_chunks(wb) -> List[TimelineChunk]:
    """Extract timeline slicer definitions from workbook custom XML."""
    import re
    chunks = []
    try:
        for part in wb.custom_xml_parts:
            xml = part.xml.decode("utf-8", errors="ignore") if isinstance(part.xml, bytes) else part.xml
            if "timeline" not in xml.lower():
                continue
            names = re.findall(r'name="([^"]+)"', xml)
            for name in names:
                chunks.append(TimelineChunk(
                    sheet_name="",
                    timeline_name=name,
                ))
    except Exception:
        pass
    return chunks


# ---------------------------------------------------------------------------
# Form Controls & ActiveX Controls
# ---------------------------------------------------------------------------

def build_form_control_chunks(wb) -> List[FormControlChunk]:
    """Extract legacy form controls from worksheet drawing XML."""
    import re
    chunks = []
    _CTRL_TYPE_MAP = {
        "button": "button", "checkbox": "checkbox", "listbox": "listbox",
        "combobox": "combobox", "spinner": "spinner", "scrollbar": "scrollbar",
        "label": "button", "groupbox": "button",
    }
    for ws in wb.worksheets:
        try:
            # openpyxl exposes controls via _controls or worksheet XML
            for ctrl in getattr(ws, "_controls", []):
                ctype = str(getattr(ctrl, "controlType", "")).lower()
                mapped = _CTRL_TYPE_MAP.get(ctype, ctype) or "button"
                linked = getattr(ctrl, "linkedCell", None)
                macro = getattr(ctrl, "macro", None)
                chunks.append(FormControlChunk(
                    sheet_name=ws.title,
                    control_type=mapped,
                    linked_cell=str(linked) if linked else None,
                    macro_assigned=str(macro) if macro else None,
                ))
        except Exception:
            pass
        # Also scan drawing XML for freestanding shapes acting as form controls
        try:
            for shape in ws._shapes:
                macro = getattr(shape, "macro", None) or getattr(shape, "fmla", None)
                if macro:
                    chunks.append(FormControlChunk(
                        sheet_name=ws.title,
                        control_type="button",
                        macro_assigned=str(macro),
                    ))
        except Exception:
            pass
    return chunks


def build_activex_control_chunks(wb) -> List[ActiveXControlChunk]:
    """Extract ActiveX control metadata from custom XML / OLE parts."""
    import re
    chunks = []
    try:
        for part in wb.custom_xml_parts:
            xml = part.xml.decode("utf-8", errors="ignore") if isinstance(part.xml, bytes) else part.xml
            if "ActiveX" not in xml and "activeX" not in xml:
                continue
            names = re.findall(r'name="([^"]+)"', xml, re.IGNORECASE)
            types = re.findall(r'classid="([^"]+)"', xml, re.IGNORECASE)
            for i, name in enumerate(names):
                chunks.append(ActiveXControlChunk(
                    sheet_name="",
                    name=name,
                    control_type=types[i] if i < len(types) else None,
                ))
    except Exception:
        pass
    return chunks
