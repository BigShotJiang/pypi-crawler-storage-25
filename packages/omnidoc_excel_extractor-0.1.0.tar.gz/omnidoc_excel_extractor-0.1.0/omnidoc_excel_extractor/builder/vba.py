"""Build VBA / macro chunks (42-46)."""
from __future__ import annotations

from typing import List

from ..chunks.models import (
    MacroChunk, VBAModuleChunk, VBAEventChunk,
    CustomFunctionChunk, RibbonCustomizationChunk,
)
from ..core.vba_extractor import (
    extract_vba, parse_macros, extract_udf_functions, extract_events,
)


def build_vba_module_chunks(file_path: str, workbook_name: str) -> List[VBAModuleChunk]:
    modules = extract_vba(file_path)
    return [
        VBAModuleChunk(
            workbook=workbook_name,
            module_name=m["module_name"],
            module_type=m["module_type"],
            procedure_names=m["procedure_names"],
            line_count=m["line_count"],
            references=m["references"],
            source_code=m.get("source_code"),
        )
        for m in modules
    ]


def build_macro_chunks(file_path: str, workbook_name: str) -> List[MacroChunk]:
    modules = extract_vba(file_path)
    macros = parse_macros(modules, workbook_name)
    return [MacroChunk(**m) for m in macros]


def build_vba_event_chunks(file_path: str) -> List[VBAEventChunk]:
    modules = extract_vba(file_path)
    events = extract_events(modules)
    return [VBAEventChunk(**e) for e in events]


def build_custom_function_chunks(file_path: str) -> List[CustomFunctionChunk]:
    modules = extract_vba(file_path)
    udfs = extract_udf_functions(modules)
    return [CustomFunctionChunk(**u) for u in udfs]


def build_ribbon_customization_chunks(wb, workbook_name: str) -> List[RibbonCustomizationChunk]:
    """Extract Ribbon UI customizations from the workbook's customUI XML part."""
    import re
    chunks = []
    try:
        for part in wb.custom_xml_parts:
            xml = part.xml.decode("utf-8", errors="ignore") if isinstance(part.xml, bytes) else part.xml
            if "customUI" not in xml and "ribbon" not in xml.lower():
                continue
            # Extract button definitions
            buttons = re.finditer(
                r'<(?:button|control)[^>]+label="([^"]*)"[^>]*(?:onAction|macro)="([^"]*)"',
                xml, re.IGNORECASE,
            )
            for btn in buttons:
                chunks.append(RibbonCustomizationChunk(
                    workbook=workbook_name,
                    button_label=btn.group(1),
                    macro_assigned=btn.group(2),
                ))
            # Extract tab names
            tabs = re.findall(r'<tab[^>]+label="([^"]*)"', xml, re.IGNORECASE)
            for tab in tabs:
                chunks.append(RibbonCustomizationChunk(
                    workbook=workbook_name,
                    tab_name=tab,
                ))
    except Exception:
        pass
    return chunks
