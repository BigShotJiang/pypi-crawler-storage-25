"""All 57 chunk type models for the omnidoc Excel extractor."""
from __future__ import annotations

import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


def _uid() -> str:
    return str(uuid.uuid4())


# ---------------------------------------------------------------------------
# Base
# ---------------------------------------------------------------------------

class BaseChunk(BaseModel):
    chunk_id: str = Field(default_factory=_uid)
    chunk_type: str
    layer: str
    priority: str  # must / should / nice

    model_config = {"extra": "allow"}

    def to_dict(self) -> Dict[str, Any]:
        return self.model_dump()


# ---------------------------------------------------------------------------
# STRUCTURAL (1-9)
# ---------------------------------------------------------------------------

class WorkbookChunk(BaseChunk):
    chunk_type: str = "WorkbookChunk"
    layer: str = "structural"
    priority: str = "must"
    name: str
    path: str
    sheet_names: List[str] = Field(default_factory=list)
    author: Optional[str] = None
    created_at: Optional[datetime] = None
    modified_at: Optional[datetime] = None
    file_size_kb: Optional[float] = None
    app_version: Optional[str] = None
    has_macros: bool = False
    is_shared: bool = False


class SheetChunk(BaseChunk):
    chunk_type: str = "SheetChunk"
    layer: str = "structural"
    priority: str = "must"
    sheet_name: str
    sheet_index: int
    sheet_type: str = "worksheet"  # worksheet / chart / dialog
    is_visible: bool = True
    used_range: Optional[str] = None
    tab_color: Optional[str] = None
    is_protected: bool = False
    zoom_level: Optional[int] = None


class TableChunk(BaseChunk):
    chunk_type: str = "TableChunk"
    layer: str = "structural"
    priority: str = "must"
    table_name: str
    sheet_name: str
    address: str
    style: Optional[str] = None
    has_total_row: bool = False
    has_header_row: bool = True
    col_count: int = 0
    row_count: int = 0


class SchemaChunk(BaseChunk):
    chunk_type: str = "SchemaChunk"
    layer: str = "structural"
    priority: str = "must"
    sheet_name: str
    table_name: Optional[str] = None
    columns: List[Dict[str, Any]] = Field(default_factory=list)
    # each col: {name, data_type, null_rate, unique_rate, sample_values[]}
    header_row_addr: Optional[str] = None
    inferred_pk: Optional[str] = None


class RowChunk(BaseChunk):
    chunk_type: str = "RowChunk"
    layer: str = "structural"
    priority: str = "must"
    row_index: int
    values: Dict[str, Any] = Field(default_factory=dict)
    parent_table: Optional[str] = None
    parent_sheet: str = ""
    batch_start: Optional[int] = None
    batch_end: Optional[int] = None
    is_total_row: bool = False


class GroupChunk(BaseChunk):
    chunk_type: str = "GroupChunk"
    layer: str = "structural"
    priority: str = "must"
    sheet_name: str
    direction: str  # row / col
    level: int
    start_index: int
    end_index: int
    is_collapsed: bool = False
    label: Optional[str] = None


class ParentContextChunk(BaseChunk):
    chunk_type: str = "ParentContextChunk"
    layer: str = "structural"
    priority: str = "must"
    workbook: str
    sheet: str
    table: Optional[str] = None
    group_path: List[str] = Field(default_factory=list)
    row_range: Optional[str] = None


class MergedCellChunk(BaseChunk):
    chunk_type: str = "MergedCellChunk"
    layer: str = "structural"
    priority: str = "must"
    sheet_name: str
    merge_range: str
    merged_value: Optional[Any] = None
    row_span: int = 1
    col_span: int = 1


class FrozenPaneChunk(BaseChunk):
    chunk_type: str = "FrozenPaneChunk"
    layer: str = "structural"
    priority: str = "nice"
    sheet_name: str
    freeze_row: Optional[int] = None
    freeze_col: Optional[int] = None
    split_horizontal: Optional[float] = None
    split_vertical: Optional[float] = None


# ---------------------------------------------------------------------------
# SEMANTIC (10-15)
# ---------------------------------------------------------------------------

class SummaryChunk(BaseChunk):
    chunk_type: str = "SummaryChunk"
    layer: str = "semantic"
    priority: str = "must"
    sheet_name: str
    table_name: Optional[str] = None
    row_count: int = 0
    col_count: int = 0
    numeric_cols: List[str] = Field(default_factory=list)
    date_cols: List[str] = Field(default_factory=list)
    text_cols: List[str] = Field(default_factory=list)
    null_rate: float = 0.0
    dupe_rate: float = 0.0
    size_kb: Optional[float] = None


class SemanticNarrativeChunk(BaseChunk):
    chunk_type: str = "SemanticNarrativeChunk"
    layer: str = "semantic"
    priority: str = "must"
    scope: str  # sheet / table
    scope_name: str
    narrative: str
    subject: Optional[str] = None
    time_scope: Optional[str] = None
    grain: Optional[str] = None
    confidence: float = 1.0
    generated_by: str = "omnidoc-excel-extractor"


class ColumnSemanticChunk(BaseChunk):
    chunk_type: str = "ColumnSemanticChunk"
    layer: str = "semantic"
    priority: str = "must"
    sheet_name: str
    table_name: Optional[str] = None
    col_name: str
    role: str  # id/measure/dimension/date/flag/freetext
    unit: Optional[str] = None
    currency: Optional[str] = None
    is_pk: bool = False
    is_fk: bool = False


class HeaderAliasChunk(BaseChunk):
    chunk_type: str = "HeaderAliasChunk"
    layer: str = "semantic"
    priority: str = "must"
    sheet_name: str
    table_name: Optional[str] = None
    original_header: str
    aliases: List[str] = Field(default_factory=list)
    abbreviations: List[str] = Field(default_factory=list)
    normalized_name: str


class EntityChunk(BaseChunk):
    chunk_type: str = "EntityChunk"
    layer: str = "semantic"
    priority: str = "should"
    workbook: str
    entity_type: str  # person/org/product/location/date
    value: str
    frequency: int = 1
    source_columns: List[str] = Field(default_factory=list)
    canonical: Optional[str] = None


class CellAnnotationChunk(BaseChunk):
    chunk_type: str = "CellAnnotationChunk"
    layer: str = "semantic"
    priority: str = "should"
    sheet_name: str
    cell_address: str
    annotation_type: str  # comment/note/tooltip
    text: str
    author: Optional[str] = None
    timestamp: Optional[datetime] = None
    resolved: bool = False


# ---------------------------------------------------------------------------
# ANALYTICAL (16-23)
# ---------------------------------------------------------------------------

class FormulaDefinitionChunk(BaseChunk):
    chunk_type: str = "FormulaDefinitionChunk"
    layer: str = "analytical"
    priority: str = "must"
    sheet_name: str
    cell_address: str
    formula_string: str
    formula_type: str = "scalar"  # scalar/array/dynamic/lambda
    named_refs: List[str] = Field(default_factory=list)
    precedents: List[str] = Field(default_factory=list)


class FormulaResultChunk(BaseChunk):
    chunk_type: str = "FormulaResultChunk"
    layer: str = "analytical"
    priority: str = "must"
    sheet_name: str
    cell_address: str
    computed_value: Optional[Any] = None
    value_type: Optional[str] = None
    has_error: bool = False
    error_type: Optional[str] = None
    linked_definition_id: Optional[str] = None


class KPIChunk(BaseChunk):
    chunk_type: str = "KPIChunk"
    layer: str = "analytical"
    priority: str = "must"
    sheet_name: str
    kpi_name: str
    value: Optional[Any] = None
    unit: Optional[str] = None
    target: Optional[Any] = None
    variance: Optional[float] = None
    variance_pct: Optional[float] = None
    source_cell: Optional[str] = None
    period: Optional[str] = None


class AggregationChunk(BaseChunk):
    chunk_type: str = "AggregationChunk"
    layer: str = "analytical"
    priority: str = "must"
    sheet_name: str
    col_name: str
    agg_type: str  # SUM/AVG/COUNT/MIN/MAX/MEDIAN/STDEV
    value: Optional[Any] = None
    source_range: Optional[str] = None
    filter_conditions: List[str] = Field(default_factory=list)


class TemporalChunk(BaseChunk):
    chunk_type: str = "TemporalChunk"
    layer: str = "analytical"
    priority: str = "must"
    sheet_name: str
    date_col: str
    frequency: Optional[str] = None  # daily/weekly/monthly/quarterly/yearly
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    gap_count: int = 0
    is_sorted: bool = True
    fiscal_year_start: Optional[int] = None  # month number


class TrendChunk(BaseChunk):
    chunk_type: str = "TrendChunk"
    layer: str = "analytical"
    priority: str = "should"
    sheet_name: str
    col_name: str
    direction: Optional[str] = None  # up/down/flat
    delta_abs: Optional[float] = None
    delta_pct: Optional[float] = None
    periods_compared: Optional[int] = None
    regression_slope: Optional[float] = None


class OutlierChunk(BaseChunk):
    chunk_type: str = "OutlierChunk"
    layer: str = "analytical"
    priority: str = "should"
    sheet_name: str
    col_name: str
    outlier_type: str  # zscore/iqr/blank_spike/dupe
    cell_addr: Optional[str] = None
    value: Optional[Any] = None
    z_score: Optional[float] = None
    severity: Optional[str] = None  # low/medium/high


class LookupMapChunk(BaseChunk):
    chunk_type: str = "LookupMapChunk"
    layer: str = "analytical"
    priority: str = "should"
    sheet_name: str
    cell_address: str
    lookup_type: str  # VLOOKUP/HLOOKUP/INDEX-MATCH/XLOOKUP
    key_col: Optional[str] = None
    return_col: Optional[str] = None
    lookup_range: Optional[str] = None
    match_type: Optional[str] = None


# ---------------------------------------------------------------------------
# VALIDATION / QA (24-28)
# ---------------------------------------------------------------------------

class ValidationChunk(BaseChunk):
    chunk_type: str = "ValidationChunk"
    layer: str = "validation"
    priority: str = "must"
    sheet_name: str
    range_addr: str
    validation_type: str  # list/decimal/date/whole/custom
    allowed_values: List[Any] = Field(default_factory=list)
    formula: Optional[str] = None
    error_msg: Optional[str] = None


class ErrorChunk(BaseChunk):
    chunk_type: str = "ErrorChunk"
    layer: str = "validation"
    priority: str = "must"
    sheet_name: str
    cell_addr: str
    error_type: str  # #REF/#DIV0/#NA/#VALUE/#NAME/#NULL/#NUM
    formula: Optional[str] = None
    likely_cause: Optional[str] = None


class ConditionalFormatChunk(BaseChunk):
    chunk_type: str = "ConditionalFormatChunk"
    layer: str = "validation"
    priority: str = "must"
    sheet_name: str
    range_addr: str
    rule_type: Optional[str] = None
    condition_formula: Optional[str] = None
    threshold: Optional[Any] = None
    format_applied: Optional[str] = None
    business_meaning: Optional[str] = None


class ProtectionChunk(BaseChunk):
    chunk_type: str = "ProtectionChunk"
    layer: str = "validation"
    priority: str = "should"
    sheet_name: str
    scope: str  # sheet/range
    is_password_protected: bool = False
    locked_ranges: List[str] = Field(default_factory=list)
    allowed_edit_ranges: List[str] = Field(default_factory=list)


class DataQualityChunk(BaseChunk):
    chunk_type: str = "DataQualityChunk"
    layer: str = "validation"
    priority: str = "should"
    sheet_name: str
    col_name: str
    blank_count: int = 0
    dupe_count: int = 0
    type_mismatch_count: int = 0
    out_of_range_count: int = 0
    flagged_cells: List[str] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# VISUAL / CHARTS (29-31)
# ---------------------------------------------------------------------------

class ChartChunk(BaseChunk):
    chunk_type: str = "ChartChunk"
    layer: str = "visual"
    priority: str = "must"
    sheet_name: str
    chart_name: str
    chart_type: str  # bar/line/pie/scatter/combo/waterfall/funnel/treemap/map/stock
    title: Optional[str] = None
    x_axis: Optional[str] = None
    y_axis: Optional[str] = None
    series: List[Dict[str, Any]] = Field(default_factory=list)  # [{name, range}]
    sheet_anchor: Optional[str] = None
    source_table: Optional[str] = None


class ChartSeriesChunk(BaseChunk):
    chunk_type: str = "ChartSeriesChunk"
    layer: str = "visual"
    priority: str = "must"
    chart_id: str
    series_name: Optional[str] = None
    source_range: Optional[str] = None
    series_type: Optional[str] = None
    color: Optional[str] = None
    trendline_type: Optional[str] = None
    trendline_formula: Optional[str] = None


class ChartAnnotationChunk(BaseChunk):
    chunk_type: str = "ChartAnnotationChunk"
    layer: str = "visual"
    priority: str = "should"
    chart_id: str
    annotation_type: str  # data_label/callout/textbox
    text: Optional[str] = None
    cell_ref: Optional[str] = None
    position: Optional[Dict[str, Any]] = None


# ---------------------------------------------------------------------------
# VISUAL / PIVOT TABLES (32-36)
# ---------------------------------------------------------------------------

class PivotTableChunk(BaseChunk):
    chunk_type: str = "PivotTableChunk"
    layer: str = "visual"
    priority: str = "must"
    sheet_name: str
    pivot_name: str
    source_range: Optional[str] = None
    source_sheet: Optional[str] = None
    row_fields: List[str] = Field(default_factory=list)
    col_fields: List[str] = Field(default_factory=list)
    value_fields: List[Dict[str, str]] = Field(default_factory=list)  # [{field, agg}]
    filter_fields: List[str] = Field(default_factory=list)
    report_filter_values: Dict[str, Any] = Field(default_factory=dict)


class PivotFieldChunk(BaseChunk):
    chunk_type: str = "PivotFieldChunk"
    layer: str = "visual"
    priority: str = "must"
    pivot_id: str
    field_name: str
    field_type: str  # row/col/value/filter
    agg_function: Optional[str] = None
    sort_order: Optional[str] = None
    subtotal_enabled: bool = True
    grouped_by: Optional[str] = None


class PivotCacheChunk(BaseChunk):
    chunk_type: str = "PivotCacheChunk"
    layer: str = "visual"
    priority: str = "should"
    pivot_id: str
    cache_range: Optional[str] = None
    last_refreshed: Optional[datetime] = None
    record_count: Optional[int] = None
    unique_items_per_field: Dict[str, int] = Field(default_factory=dict)


class SlicerChunk(BaseChunk):
    chunk_type: str = "SlicerChunk"
    layer: str = "visual"
    priority: str = "should"
    sheet_name: str
    slicer_name: str
    field_name: Optional[str] = None
    connected_objects: List[str] = Field(default_factory=list)
    active_filters: List[str] = Field(default_factory=list)
    style: Optional[str] = None
    sheet_anchor: Optional[str] = None


class TimelineChunk(BaseChunk):
    chunk_type: str = "TimelineChunk"
    layer: str = "visual"
    priority: str = "should"
    sheet_name: str
    timeline_name: str
    date_field: Optional[str] = None
    connected_pivots: List[str] = Field(default_factory=list)
    active_period: Optional[str] = None
    granularity: Optional[str] = None  # year/quarter/month/day


# ---------------------------------------------------------------------------
# VISUAL / OTHER OBJECTS (37-41)
# ---------------------------------------------------------------------------

class SparklineChunk(BaseChunk):
    chunk_type: str = "SparklineChunk"
    layer: str = "visual"
    priority: str = "should"
    sheet_name: str
    sparkline_type: str  # line/column/win_loss
    host_cell: str
    source_range: str
    color: Optional[str] = None
    markers: bool = False
    axis_min: Optional[float] = None
    axis_max: Optional[float] = None


class ShapeChunk(BaseChunk):
    chunk_type: str = "ShapeChunk"
    layer: str = "visual"
    priority: str = "nice"
    sheet_name: str
    shape_type: Optional[str] = None
    text_content: Optional[str] = None
    cell_anchor: Optional[str] = None
    position: Dict[str, Any] = Field(default_factory=dict)
    linked_cell: Optional[str] = None
    shape_name: Optional[str] = None


class ImageChunk(BaseChunk):
    chunk_type: str = "ImageChunk"
    layer: str = "visual"
    priority: str = "nice"
    sheet_name: str
    image_type: Optional[str] = None
    anchor_cell: Optional[str] = None
    alt_text: Optional[str] = None
    width_px: Optional[int] = None
    height_px: Optional[int] = None
    is_linked: bool = False
    source_url: Optional[str] = None


class FormControlChunk(BaseChunk):
    chunk_type: str = "FormControlChunk"
    layer: str = "visual"
    priority: str = "should"
    sheet_name: str
    control_type: str  # button/checkbox/listbox/combobox/spinner/scrollbar
    linked_cell: Optional[str] = None
    value: Optional[Any] = None
    range_source: Optional[str] = None
    macro_assigned: Optional[str] = None


class ActiveXControlChunk(BaseChunk):
    chunk_type: str = "ActiveXControlChunk"
    layer: str = "visual"
    priority: str = "should"
    sheet_name: str
    control_type: Optional[str] = None
    name: Optional[str] = None
    linked_cell: Optional[str] = None
    properties: Dict[str, Any] = Field(default_factory=dict)
    event_macro: Optional[str] = None
    sheet_anchor: Optional[str] = None


# ---------------------------------------------------------------------------
# VBA / MACRO (42-46)
# ---------------------------------------------------------------------------

class MacroChunk(BaseChunk):
    chunk_type: str = "MacroChunk"
    layer: str = "vba"
    priority: str = "must"
    workbook: str
    macro_name: str
    module_name: Optional[str] = None
    trigger_type: Optional[str] = None  # button/event/auto/ribbon
    trigger_event: Optional[str] = None
    description: Optional[str] = None
    line_count: int = 0
    scope: str = "workbook"  # workbook/sheet


class VBAModuleChunk(BaseChunk):
    chunk_type: str = "VBAModuleChunk"
    layer: str = "vba"
    priority: str = "must"
    workbook: str
    module_name: str
    module_type: str  # standard/class/sheet/workbook
    procedure_names: List[str] = Field(default_factory=list)
    line_count: int = 0
    references: List[str] = Field(default_factory=list)
    source_code: Optional[str] = None


class VBAEventChunk(BaseChunk):
    chunk_type: str = "VBAEventChunk"
    layer: str = "vba"
    priority: str = "should"
    module: str
    event_name: str  # Workbook_Open/Sheet_Change/BeforeSave…
    trigger_condition: Optional[str] = None
    affected_range: Optional[str] = None
    summary: Optional[str] = None


class CustomFunctionChunk(BaseChunk):
    chunk_type: str = "CustomFunctionChunk"
    layer: str = "vba"
    priority: str = "should"
    module: str
    function_name: str
    parameters: List[str] = Field(default_factory=list)
    return_type: Optional[str] = None
    description: Optional[str] = None
    usage_cells: List[str] = Field(default_factory=list)
    is_udf: bool = True


class RibbonCustomizationChunk(BaseChunk):
    chunk_type: str = "RibbonCustomizationChunk"
    layer: str = "vba"
    priority: str = "nice"
    workbook: str
    tab_name: Optional[str] = None
    group_name: Optional[str] = None
    button_label: Optional[str] = None
    macro_assigned: Optional[str] = None
    icon: Optional[str] = None


# ---------------------------------------------------------------------------
# CROSS-REFERENCE / LINKAGE (47-50)
# ---------------------------------------------------------------------------

class RelationshipChunk(BaseChunk):
    chunk_type: str = "RelationshipChunk"
    layer: str = "cross_ref"
    priority: str = "must"
    source_sheet: str
    source_cell: str
    target_cell: str
    target_sheet: str
    rel_type: str  # vlookup/index_match/direct_ref/power_query_feed
    formula: Optional[str] = None


class NamedRangeChunk(BaseChunk):
    chunk_type: str = "NamedRangeChunk"
    layer: str = "cross_ref"
    priority: str = "must"
    range_name: str
    refers_to: str
    scope: str = "workbook"  # workbook/sheet
    usage_count: int = 0
    used_in: List[str] = Field(default_factory=list)


class ExternalLinkChunk(BaseChunk):
    chunk_type: str = "ExternalLinkChunk"
    layer: str = "cross_ref"
    priority: str = "should"
    workbook: str
    source_cell: Optional[str] = None
    target_file: str = ""
    target_range: Optional[str] = None
    last_updated: Optional[datetime] = None
    is_broken: bool = False
    update_mode: Optional[str] = None


class DependencyGraphChunk(BaseChunk):
    chunk_type: str = "DependencyGraphChunk"
    layer: str = "cross_ref"
    priority: str = "should"
    sheet_name: str
    nodes: List[str] = Field(default_factory=list)
    edges: List[Dict[str, str]] = Field(default_factory=list)  # [{from, to, type}]
    max_depth: int = 0
    has_circular_ref: bool = False


# ---------------------------------------------------------------------------
# CONNECTIVITY / POWER FEATURES (51-54)
# ---------------------------------------------------------------------------

class PowerQueryChunk(BaseChunk):
    chunk_type: str = "PowerQueryChunk"
    layer: str = "connectivity"
    priority: str = "must"
    workbook: str
    query_name: str
    source_type: Optional[str] = None  # file/db/api/web/sharepoint
    source_path: Optional[str] = None
    transformation_steps: List[str] = Field(default_factory=list)
    output_table: Optional[str] = None
    last_refreshed: Optional[datetime] = None


class DataModelChunk(BaseChunk):
    chunk_type: str = "DataModelChunk"
    layer: str = "connectivity"
    priority: str = "should"
    workbook: str
    tables: List[str] = Field(default_factory=list)
    relationships: List[Dict[str, str]] = Field(default_factory=list)
    dax_measures: List[str] = Field(default_factory=list)
    dax_columns: List[str] = Field(default_factory=list)


class PowerPivotMeasureChunk(BaseChunk):
    chunk_type: str = "PowerPivotMeasureChunk"
    layer: str = "connectivity"
    priority: str = "should"
    workbook: str
    measure_name: str
    dax_expression: Optional[str] = None
    format_string: Optional[str] = None
    source_table: Optional[str] = None
    used_in_pivots: List[str] = Field(default_factory=list)


class ConnectionChunk(BaseChunk):
    chunk_type: str = "ConnectionChunk"
    layer: str = "connectivity"
    priority: str = "should"
    workbook: str
    connection_name: str
    connection_type: Optional[str] = None  # ODBC/OLE/web/sharepoint/odata
    connection_string_sanitized: Optional[str] = None
    refresh_schedule: Optional[str] = None


# ---------------------------------------------------------------------------
# OPERATIONAL / METADATA (55-57)
# ---------------------------------------------------------------------------

class PrintSettingsChunk(BaseChunk):
    chunk_type: str = "PrintSettingsChunk"
    layer: str = "operational"
    priority: str = "nice"
    sheet_name: str
    print_area: Optional[str] = None
    page_break_rows: List[int] = Field(default_factory=list)
    header_text: Optional[str] = None
    footer_text: Optional[str] = None
    orientation: Optional[str] = None  # portrait/landscape
    fit_to_pages: Optional[bool] = None


class ChangeLogChunk(BaseChunk):
    chunk_type: str = "ChangeLogChunk"
    layer: str = "operational"
    priority: str = "nice"
    sheet_name: str
    cell_addr: str
    old_value: Optional[Any] = None
    new_value: Optional[Any] = None
    author: Optional[str] = None
    changed_at: Optional[datetime] = None
    change_type: Optional[str] = None  # edit/insert/delete


class ChunkIndexChunk(BaseChunk):
    chunk_type: str = "ChunkIndexChunk"
    layer: str = "operational"
    priority: str = "must"
    workbook_ref: str
    all_chunk_ids: List[str] = Field(default_factory=list)
    type_counts: Dict[str, int] = Field(default_factory=dict)
    source_address_map: Dict[str, str] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=datetime.utcnow)


# ---------------------------------------------------------------------------
# Registry — chunk_type string → class
# ---------------------------------------------------------------------------

CHUNK_REGISTRY: Dict[str, type] = {
    "WorkbookChunk": WorkbookChunk,
    "SheetChunk": SheetChunk,
    "TableChunk": TableChunk,
    "SchemaChunk": SchemaChunk,
    "RowChunk": RowChunk,
    "GroupChunk": GroupChunk,
    "ParentContextChunk": ParentContextChunk,
    "MergedCellChunk": MergedCellChunk,
    "FrozenPaneChunk": FrozenPaneChunk,
    "SummaryChunk": SummaryChunk,
    "SemanticNarrativeChunk": SemanticNarrativeChunk,
    "ColumnSemanticChunk": ColumnSemanticChunk,
    "HeaderAliasChunk": HeaderAliasChunk,
    "EntityChunk": EntityChunk,
    "CellAnnotationChunk": CellAnnotationChunk,
    "FormulaDefinitionChunk": FormulaDefinitionChunk,
    "FormulaResultChunk": FormulaResultChunk,
    "KPIChunk": KPIChunk,
    "AggregationChunk": AggregationChunk,
    "TemporalChunk": TemporalChunk,
    "TrendChunk": TrendChunk,
    "OutlierChunk": OutlierChunk,
    "LookupMapChunk": LookupMapChunk,
    "ValidationChunk": ValidationChunk,
    "ErrorChunk": ErrorChunk,
    "ConditionalFormatChunk": ConditionalFormatChunk,
    "ProtectionChunk": ProtectionChunk,
    "DataQualityChunk": DataQualityChunk,
    "ChartChunk": ChartChunk,
    "ChartSeriesChunk": ChartSeriesChunk,
    "ChartAnnotationChunk": ChartAnnotationChunk,
    "PivotTableChunk": PivotTableChunk,
    "PivotFieldChunk": PivotFieldChunk,
    "PivotCacheChunk": PivotCacheChunk,
    "SlicerChunk": SlicerChunk,
    "TimelineChunk": TimelineChunk,
    "SparklineChunk": SparklineChunk,
    "ShapeChunk": ShapeChunk,
    "ImageChunk": ImageChunk,
    "FormControlChunk": FormControlChunk,
    "ActiveXControlChunk": ActiveXControlChunk,
    "MacroChunk": MacroChunk,
    "VBAModuleChunk": VBAModuleChunk,
    "VBAEventChunk": VBAEventChunk,
    "CustomFunctionChunk": CustomFunctionChunk,
    "RibbonCustomizationChunk": RibbonCustomizationChunk,
    "RelationshipChunk": RelationshipChunk,
    "NamedRangeChunk": NamedRangeChunk,
    "ExternalLinkChunk": ExternalLinkChunk,
    "DependencyGraphChunk": DependencyGraphChunk,
    "PowerQueryChunk": PowerQueryChunk,
    "DataModelChunk": DataModelChunk,
    "PowerPivotMeasureChunk": PowerPivotMeasureChunk,
    "ConnectionChunk": ConnectionChunk,
    "PrintSettingsChunk": PrintSettingsChunk,
    "ChangeLogChunk": ChangeLogChunk,
    "ChunkIndexChunk": ChunkIndexChunk,
}

__all__ = list(CHUNK_REGISTRY.keys()) + ["BaseChunk", "CHUNK_REGISTRY"]
