import struct
import urllib
from typing import Dict
from azure.identity import DefaultAzureCredential
from sqlalchemy import event
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker

SQL_COPT_SS_ACCESS_TOKEN = 1256
class Connection:

    _instances: Dict[str, 'Connection'] = {}

    def __new__(cls, db_url: str):
        if db_url not in cls._instances:
            cls._instances[db_url] = super(Connection, cls).__new__(cls)
        return cls._instances[db_url]

    def __init__(self, db_url: str):
        if not hasattr(self, 'initialized'):
            self.credential = DefaultAzureCredential()
            raw_odbc_string = db_url
            params = urllib.parse.quote_plus(raw_odbc_string)
            sqlalchemy_url = f"mssql+aioodbc:///?odbc_connect={params}"
            self.engine = create_async_engine(
                sqlalchemy_url,
                pool_size=20,          
                max_overflow=40,       
                pool_timeout=30,       
                pool_recycle=1800,
                pool_pre_ping=True   
            )
            self._attach_token_listener()
            self.session_factory = sessionmaker(
                bind=self.engine, 
                class_=AsyncSession, 
                expire_on_commit=False
            )
            self.initialized = True

    def _attach_token_listener(self):

        @event.listens_for(self.engine.sync_engine, "do_connect")
        def provide_token(dialect, conn_rec, cargs, cparams):

            token = self.credential.get_token(
                "https://database.windows.net/.default"
            ).token

            token_bytes = token.encode("utf-16-le")

            token_struct = struct.pack(
                f"<I{len(token_bytes)}s",
                len(token_bytes),
                token_bytes
            )

            cparams["attrs_before"] = {
                SQL_COPT_SS_ACCESS_TOKEN: token_struct
            }

    
    async def close_engine(self) -> None:
        """Dispose of the engine and remove instance."""
        if self.engine:
            await self.engine.dispose() 