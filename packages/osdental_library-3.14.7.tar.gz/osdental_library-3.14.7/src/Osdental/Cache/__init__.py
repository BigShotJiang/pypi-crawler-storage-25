from typing import Protocol, Optional, Dict, List, Any


class ICacheService(Protocol):

    async def set_dict(self, key: str, value: Dict[str, Any], ttl: Optional[int] = None):
        """Set a JSON value in the cache."""
        pass

    async def set_str(self, key: str, value: str, ttl: Optional[int] = None):
        """Set a string value in the cache."""
        pass

    async def get_dict(self, key: str) -> Optional[Dict[str, Any]]:
        """Get a JSON value from the cache and convert it back to a Python object."""
        pass


    async def get_str(self, key: str) -> Optional[str]:
        """Get a string value from the cache."""
        pass

    async def delete(self, key: str) -> bool:
        """Delete a value from the cache."""
        pass

    async def exists(self, key: str) -> bool:
        """Check if a key exists in the cache."""
        pass

    async def flush(self):
        """Flush all keys in the cache."""
        pass
    
    async def flush_all(self):
        """Flush all keys in all Redis databases."""
        pass

    async def mget(self, keys:List[str]) -> List[Optional[str]]:
        """Get multiple values from the cache."""
        pass

    async def clear_cache(self, prefix: str):
        """Delete all keys matching the given prefix."""
        pass

    async def _scan_keys(self, match: str = "*"):
        """Asynchronous generator to scan keys matching a pattern."""
        pass

    async def close(self):
        """Close the connection pool and Redis client."""
        pass