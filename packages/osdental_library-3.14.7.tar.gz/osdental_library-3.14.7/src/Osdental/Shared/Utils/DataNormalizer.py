from datetime import datetime, date
from decimal import Decimal
from uuid import UUID
from typing import Any
from sqlalchemy import RowMapping

def is_uuid_string(value: str) -> bool:
    try:
        UUID(value)
        return True
    except (ValueError, TypeError):
        return False
    
def normalize_odbc_value(value: Any) -> Any:
    """
    Convierte valores problemáticos de ODBC a tipos JSON serializables.
    """
    
    if value is None:
        return None
    
    if isinstance(value, Decimal):
        return float(value)

    if isinstance(value, (datetime, date)):
        return value.isoformat()

    if isinstance(value, UUID):
        return str(value).lower()
    
    if isinstance(value, str) and is_uuid_string(value):
        return value.lower()

    return value

def normalize(data: Any) -> Any:
    """
    Normaliza cualquier estructura:
    - RowMapping
    - dict
    - list
    - valores simples
    """

    # SQLAlchemy RowMapping
    if isinstance(data, RowMapping):
        data = dict(data)

    # dict
    if isinstance(data, dict):
        return {k: normalize(v) for k, v in data.items()}

    # list / tuple
    if isinstance(data, (list, tuple)):
        return [normalize(item) for item in data]

    # valor simple
    return normalize_odbc_value(data)