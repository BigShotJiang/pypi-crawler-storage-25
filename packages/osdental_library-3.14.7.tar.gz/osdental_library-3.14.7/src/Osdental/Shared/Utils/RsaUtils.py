
def normalize_rsa_keys(key_str: str, is_private: bool = True) -> str:
    """
    Normaliza una llave RSA (privada o pública) para que sea compatible con cryptography.
    Si is_private=True, normaliza la llave privada; si False, normaliza la llave pública.
    """

    # Determinar encabezados correctos
    if is_private:
        header = "-----BEGIN RSA PRIVATE KEY-----"
        footer = "-----END RSA PRIVATE KEY-----"
        invalid_texts = ["-----BEGINRSAPRIVATEKEY-----", "-----ENDRSAPRIVATEKEY-----",
                        "-----BEGIN RSA PRIVATE KEY-----", "-----END RSA PRIVATE KEY-----"]
    else:
        header = "-----BEGIN PUBLIC KEY-----"
        footer = "-----END PUBLIC KEY-----"
        invalid_texts = ["-----BEGINPUBLICKEY-----", "-----ENDPUBLICKEY-----",
                        "-----BEGIN PUBLIC KEY-----", "-----END PUBLIC KEY-----"]

    # Limpiar encabezados inválidos y espacios
    for text in invalid_texts:
        key_str = key_str.replace(text, "")
    key_str = key_str.replace("\r", "").replace(" ", "").replace("\n", "")

    # Dividir en líneas de 64 caracteres
    lines = [key_str[i:i+64] for i in range(0, len(key_str), 64)]

    # Reconstruir PEM válido
    pem = f"{header}\n" + "\n".join(lines) + f"\n{footer}\n"
    return pem