from Osdental.Rest.Context.RequestContext import current_context
from Osdental.Models.ApiResponse import ApiResponse
from Osdental.Shared.Enums.Constant import Constant
from Osdental.Shared.Logger import logger

"""
    Helpers to control external API audit logging.
"""

def _get_dispatcher():
    try:
        ctx = current_context.get()
        if ctx and ctx.request:
            return ctx.request, ctx.request.app.state.audit_dispatcher
    except Exception:
        return None, None
    return None, None

def _safe_dispatch(**kwargs):
    try:
        _, dispatcher = _get_dispatcher()
        if dispatcher:
            dispatcher.dispatch(**kwargs)
    except Exception as e:
        logger.error(f"Audit error: {str(e)}")

def _build_payload(method, url, kwargs):
    return {
        "operation_name": "ExternalAPI",
        "method": method,
        "query": url,
        "variables": kwargs.get("json") or kwargs.get("params")
    }

# Success
def audit_success(response, method, url, kwargs):
    request, _ = _get_dispatcher()
    if not request:
        return
    
    _safe_dispatch(
        request=request,
        request_payload=_build_payload(method, url, kwargs),
        result=ApiResponse(
            status=response.status_code,
            message="External API SUCCESS",
            data=response.text
        ),
        audit_type=Constant.MESSAGE_LOG_EXTERNAL
    )

# HTTP Error
def audit_http_error(response, method, url, kwargs):
    request, _ = _get_dispatcher()
    if not request:
        return
    
    _safe_dispatch(
        request=request,
        request_payload=_build_payload(method, url, kwargs),
        result=ApiResponse(
            status=response.status_code,
            message="External API ERROR",
            error=response.text
        ),
        audit_type=Constant.MESSAGE_LOG_EXTERNAL
    )

# Network Error
def audit_exception_error(exc, method, url, kwargs):
    request, _ = _get_dispatcher()
    if not request:
        return
    
    _safe_dispatch(
        request=request,
        request_payload=_build_payload(method, url, kwargs),
        result=ApiResponse(
            status=0,
            message="External API NETWORK ERROR",
            error=str(exc)
        ),
        audit_type=Constant.MESSAGE_LOG_EXTERNAL
    )

# Unknown Error
def audit_unknown_error(exc, method, url, kwargs):
    request, _ = _get_dispatcher()
    if not request:
        return
    
    _safe_dispatch(
        request=request,
        request_payload=_build_payload(method, url, kwargs),
        result=ApiResponse(
            status=0,
            message="External API UNKNOWN ERROR",
            error=str(exc)
        ),
        audit_type=Constant.MESSAGE_LOG_EXTERNAL
    )

# GraphQL Error
def audit_graphql_error(errors, url, payload):
    request, _ = _get_dispatcher()
    if not request:
        return
    
    _safe_dispatch(
        request=request,
        request_payload={
            "operation_name": "GraphQL",
            "query": url,
            "variables": payload
        },
        result=ApiResponse(
            status=400,
            message="GraphQL ERROR",
            error=str(errors)
        ),
        audit_type=Constant.MESSAGE_LOG_EXTERNAL
    )