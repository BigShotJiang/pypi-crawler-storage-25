import httpx
from typing import Optional, Dict, Any
from Osdental.Decorators.Retry import rest_retry
from Osdental.Http._Helpers import (
    audit_success, audit_http_error, audit_exception_error,
    audit_unknown_error, audit_graphql_error
)
from Osdental.Exception.ControlledException import HttpClientException
from Osdental.Shared.Logger import logger

class APIClient:

    def __init__(
        self,
        timeout: Optional[httpx.Timeout] = None,
        limits: Optional[httpx.Limits] = None
    ):
        self._client = httpx.AsyncClient(
            follow_redirects=True,
            timeout=timeout or httpx.Timeout(10.0, read=20.0),
            limits=limits or httpx.Limits(
                max_connections=100,
                max_keepalive_connections=20
            )
        )

    async def close(self):
        await self._client.aclose()

    @rest_retry
    async def _request(self, method: str, url: str, **kwargs) -> httpx.Response:

        try:

            response = await self._client.request(
                method,
                url,
                **kwargs
            )

            response.raise_for_status()

            audit_success(response, method, url, kwargs)

            return response

        except httpx.HTTPStatusError as exc:
            
            audit_http_error(exc.response, method, url, kwargs)
            raise HttpClientException(
                status_code=exc.response.status_code,
                error=exc.response.text
            ) from exc
        
        except httpx.RequestError as exc:

            audit_exception_error(exc, method, url, kwargs)
            raise HttpClientException(
                status_code=0,
                error=str(exc)
            ) from exc
        
        except Exception as exc:

            audit_unknown_error(exc, method, url, kwargs)

            raise
    
    async def request(
        self,
        method: str,
        url: str,
        **kwargs
    ) -> Any:

        response = await self._request(
            method,
            url,
            **kwargs
        )

        content_type = response.headers.get(
            "content-type", ""
        ).lower()

        if "application/json" in content_type:
            return response.json()

        if "text/" in content_type or "xml" in content_type:
            return response.text

        return response.content
    

    async def execute(
        self,
        url: str,
        query: str,
        variables: Dict[str, Any],
        headers: Optional[Dict[str, str]] = None
    ) -> Dict[str, Any]:

        payload = {
            "query": query,
            "variables": variables
        }

        response = await self._request(
            "POST",
            url,
            json=payload,
            headers=headers or {}
        )

        data = response.json()

        if "errors" in data:

            logger.error(
                f"GraphQL error: {data['errors']}"
            )

            audit_graphql_error(data["errors"], url, payload)
            raise HttpClientException(
                message="GraphQL execution failed",
                error=str(data["errors"])
            )

        return data["data"]