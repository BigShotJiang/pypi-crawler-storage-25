def public_resolver(resolver):
    setattr(resolver, "_is_public", True)
    return resolver