import json
from functools import wraps
from Osdental.Shared.Logger import logger

def parse_rpc_request_payload(func):

    @wraps(func)
    async def wrapper(self, request, context, *args, **kwargs):
        payload = {}

        if hasattr(request, "data"):
            data = request.data

            if data:
                if isinstance(data, bytes):
                    data = data.decode("utf-8")

                if isinstance(data, str):
                    try:
                        payload = json.loads(data)
                    except json.JSONDecodeError:
                        logger.debug("Invalid JSON in request.data, using empty payload")

                elif isinstance(data, dict):
                    payload = data

                else:
                    logger.debug(f"Unsupported request.data type: {type(data).__name__}")

        return await func(self, payload, context, *args, **kwargs)

    return wrapper