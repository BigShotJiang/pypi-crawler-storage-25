from functools import wraps
from typing import Callable
from Osdental.Models.Response import Response
from Osdental.Shared.Enums.Profile import Profile
from Osdental.Exception.ControlledException import OSDException, AccessDeniedException, UnauthorizedException
from Osdental.Shared.Logger import logger

def resolver(public: bool = False, action=None):

    def decorator(func: Callable):

        func._is_public = public

        @wraps(func)
        async def wrapper(obj, info, **kwargs):
            try:
                context = info.context
                token = getattr(context, "token", None)

                if not public:
                    if not token:
                        raise UnauthorizedException(
                            error="Authorization required"
                        )

                    if action:
                        if Profile(token.abbreviation) not in action.allowed_roles:
                            raise AccessDeniedException(
                                error="User not allowed to perform this action"
                            )

                result = await func(obj, info, **kwargs)

                if not isinstance(result, Response):
                    raise TypeError("Resolver must return a Response instance")

                return result

            except OSDException as e:
                logger.warning(f"Business error: {str(e)}")

                return Response(
                    status=e.status_code,
                    message=e.message,
                    error=e.error
                )

            except Exception as e:
                logger.exception(f"Unexpected error: {str(e)}")

                return Response(
                    status="DB_ERROR_UNEXPECTED",
                    message="Could not process request.",
                    error=str(e)
                )

        return wrapper

    return decorator