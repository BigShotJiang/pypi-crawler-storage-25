from typing import Dict, Any
from uuid import UUID
from graphql import OperationType
from starlette.datastructures import Headers
from Osdental.Encryptor.Aes import AES
from Osdental.Models.Token import AuthToken

class TenantPolicy:

    @staticmethod
    def resolve(
        token: AuthToken, 
        headers: Headers, 
        decrypted_payload: Dict[str, Any], 
        operation_type: str
    ) -> AuthToken:

        final_id = None

        external_enterprise_req = (
            decrypted_payload.get("idExternalEnterprise")
            if decrypted_payload else None
        )

        if external_enterprise_req:
            final_id = external_enterprise_req


        elif token.abbreviation.startswith("OSDMK"):
            dynamic_client_id = headers.get("dynamicClientId")
            if dynamic_client_id:
                decrypted_mk_id = AES.decrypt(token.aes_key_auth, dynamic_client_id)
                final_id = decrypted_mk_id
                token.mk_id_external_enterprise = decrypted_mk_id

        elif (
            token.abbreviation.startswith(("SPAU", "OSDA")) 
            and operation_type == OperationType.QUERY.value
        ):
            final_id = str(UUID(int=0))

        if final_id:
            token.id_external_enterprise = final_id

        return token