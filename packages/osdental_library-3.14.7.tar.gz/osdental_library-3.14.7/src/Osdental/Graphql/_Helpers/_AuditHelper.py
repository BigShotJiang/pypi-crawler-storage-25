import json
from typing import Dict, Literal, Any, Optional
from Osdental.Models._Audit import Audit

class AuditHelper:
        
    @staticmethod
    async def build_request_payload(audit: Audit) -> Dict[str, Any]:
        request = audit.request
        audit_config = audit.audit_config
        payload = audit.payload

        default_value = "*"

        user_ip = request.headers.get("X-Forwarded-For")
        if user_ip:
            user_ip = user_ip.split(",")[0]
        else:
            user_ip = getattr(request.client, "host", "*")

        SAFE_HEADERS = {
            "user-agent",
            "host",
            "origin",
            "referer",
            "content-type"
        }

        headers = {k: v for k, v in request.headers.items() if k.lower() in SAFE_HEADERS}

        return {
            "idMessageLog": request.headers.get("Idmessagelog"),
            "environment": audit_config.environment,
            "header": json.dumps(headers),
            "microServiceUrl": str(request.url),
            "microServiceName": audit_config.microservice_name,
            "microServiceVersion": audit_config.microservice_version,
            "serviceName": audit.operation_name,
            "machineNameUser": request.headers.get("Machinenameuser", default_value),
            "ipUser": user_ip or default_value,
            "userName": audit.full_name,
            "localitation": default_value,
            "httpMethod": request.method,
            "messageIn": json.dumps(payload) if payload else default_value,
            "auditLog": audit.audit_type
        }
    
    @staticmethod
    def build_final_payload(
        _type: Literal["RESPONSE", "ERROR"],
        status_code: int,
        result: Optional[Any] = None,
        error: Optional[Any] = None
    ) -> Dict[str, Any]:

        result = "*" if result is None else result
        error = "*" if error is None else error

        if isinstance(result, (dict, list)):
            result = json.dumps(result)

        return {
            "type": _type,
            "httpResponseCode": status_code,
            "messageOut": result,
            "errorProducer": error
        }
