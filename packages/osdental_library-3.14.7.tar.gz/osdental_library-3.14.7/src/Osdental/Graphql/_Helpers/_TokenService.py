from starlette.datastructures import Headers
from Osdental.Encryptor.Aes import AES
from Osdental.Encryptor.Jwt import JWT
from Osdental.Models.Token import AuthToken
from Osdental.Graphql._Helpers._ExtractAuthToken import ExtractAuthToken

class TokenService:

    def __init__(self, jwt_user_key: str, auth_validator):
        self.jwt_user_key = jwt_user_key
        self.auth_validator = auth_validator

    async def authenticate(self, headers: Headers, aes_user: str) -> AuthToken:
        encrypted_token = ExtractAuthToken.get_auth_token(headers)

        user_token = AES.decrypt(aes_user, encrypted_token)
        payload = JWT.extract_payload(user_token, self.jwt_user_key)

        token = AuthToken(
            id_token=payload.get("idToken"),
            id_user=payload.get("idUser"),
            id_external_enterprise=payload.get("idExternalEnterprise"),
            id_profile=payload.get("idProfile"),
            id_legacy=payload.get("idLegacy"),
            id_authorization=payload.get("idAuthorization"),
            id_item_report=payload.get("idItemReport"),
            id_enterprise=payload.get("idEnterprise"),
            user_full_name=payload.get("userFullName"),
            abbreviation=payload.get("abbreviation"),
            aes_key_auth=payload.get("aesKeyAuth"),
            aes_key_user=payload.get("aesKeyUser"),
            base_id_external_enterprise=payload.get("idExternalEnterprise")
        )

        # Validate via RPC
        paylod = {
            "idToken": token.id_token,
            "idUser": token.id_user
        }
        is_valid = await self.auth_validator.validate_auth_token(paylod)
        if not int(is_valid):
            raise ValueError("You are not authorized to access this portal.")

        return token