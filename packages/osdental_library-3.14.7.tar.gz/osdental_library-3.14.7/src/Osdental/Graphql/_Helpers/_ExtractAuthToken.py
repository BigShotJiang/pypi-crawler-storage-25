from starlette.datastructures import Headers

class ExtractAuthToken:

    @staticmethod
    def get_auth_token(headers: Headers) -> str:
        authorization = headers.get("authorization")
        if not authorization or not authorization.startswith("Bearer "):
            raise ValueError("Missing Bearer token")
        
        return authorization.split(" ")[1]