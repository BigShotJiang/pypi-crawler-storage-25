import inspect
import json
from graphql.pyutils import is_awaitable
from ariadne.types import Extension
from Osdental.Shared.Logger import logger
from Osdental.Encryptor.Aes import AES
from Osdental.Graphql._Helpers._TenantPolicy import TenantPolicy
from Osdental.Rest.Context.RequestContext import (
    current_context,
    RequestContext
)
from Osdental.Models.Response import Response
from Osdental.Graphql.Models import BaseGraphQLContext
from Osdental.Shared.Enums.Constant import Constant

class AuditExtension(Extension):

    def request_started(self, context):
        request = context.request
        self._ctx_token = current_context.set(
            RequestContext(
                request=request,
                request_id=request.headers.get("x-request-id"),
                user=None
            )
        )

        self.errors = None
        self.request_payload = None
        self.result = None

    def _should_skip(self, body) -> bool:
        query = body.get("query", "") or ""
        return "__schema" in query or "__type(" in query

    async def resolve(self, next_, root, info, **kwargs):

        context: BaseGraphQLContext = info.context
        request = context.request

        # cache body
        context._cached_body = getattr(context, "_cached_body", None) or await request.json()
        body = context._cached_body

        # skip introspection
        if self._should_skip(body):
            result = next_(root, info, **kwargs)
            if is_awaitable(result):
                result = await result
            return result

        is_root = root is None

        # SOLO ROOT
        if is_root:

            # identificar resolver público
            resolver_fn = inspect.unwrap(next_)
            is_public = getattr(resolver_fn, "_is_public", False)

            # inicializar auth UNA SOLA VEZ
            if not hasattr(context, "_auth_initialized"):
                context._auth_initialized = True

                headers = request.headers
                container = context.container
                token_service = container.token_service

                original_token = None
                context.aes_auth = None
                if not is_public and headers.get("authorization"):
                    aes_auth = request.app.state.aes_auth
                    aes_user = request.app.state.aes_user

                    try:
                        original_token = await token_service.authenticate(headers, aes_user)
                    except Exception:
                        original_token = None

                    context.aes_auth = aes_auth

            # VALIDACIÓN SOLO ROOT
            if not is_public and not original_token:
                raise ValueError("Authorization required")

            # payload
            variables = body.get("variables") or {}

            encrypted_payload = (
                kwargs.get("data")
                or variables.get("data")
            )

            decrypted_payload = None

            if not is_public and encrypted_payload is not None:

                if not isinstance(encrypted_payload, str):
                    raise ValueError("Encrypted payload must be a string")

                if not context.aes_auth:
                    raise ValueError("Missing AES configuration")

                try:
                    decrypted = AES.decrypt(context.aes_auth, encrypted_payload)
                except Exception:
                    raise ValueError("Invalid encrypted payload")

                if isinstance(decrypted, dict):
                    decrypted_payload = decrypted

                elif isinstance(decrypted, str):
                    try:
                        decrypted_payload = json.loads(decrypted)
                    except Exception:
                        raise ValueError("Decrypted payload is not valid JSON")

                else:
                    raise ValueError("Unsupported decrypted payload type")
                        
            if decrypted_payload is not None:
                kwargs["data"] = decrypted_payload
            
            if not is_public:
                token = TenantPolicy.resolve(
                    token=original_token,
                    headers=request.headers,
                    decrypted_payload=decrypted_payload,
                    operation_type=info.operation.operation.value
                )
                context.token = token

            # auditoría request payload
            if not self.request_payload:
                token = context.token

                self.request = request
                self.request_payload = {
                    "operation_type": info.operation.operation.value,
                    "operation_name": body.get("operationName", "UnknownOperation"),
                    "query": body.get("query"),
                    "variables": decrypted_payload,
                    "user": token.user_full_name if token else "Public"
                }

        # SIEMPRE ejecutar resolver (root + fields)
        result = next_(root, info, **kwargs)

        if is_awaitable(result):
            result = await result

        # SOLO ROOT captura resultado final
        if is_root and self.result is None:
            self.result = result

        return result

    def has_errors(self, errors, context):
        self.errors = errors

    def request_finished(self, context):

        if not self.request_payload:
            return

        query = self.request_payload.get("query", "")

        if self._should_skip({"query": query}):
            return
        
        if self.result is None:
            return

        decrypted_key = context.aes_auth

        if isinstance(self.result, Response):
            decrypted_key = self.result.key or decrypted_key

        dispatcher = context.request.app.state.audit_dispatcher

        try:
            dispatcher.dispatch(
                request=self.request,
                request_payload=self.request_payload,
                result=self.result,
                metadata={
                    "decrypted_key": decrypted_key
                },
                audit_type=Constant.MESSAGE_LOG_INTERNAL
            )
        except Exception as e:
            logger.warning(f"[AUDIT ERROR]: {str(e)}")