from contextvars import ContextVar
from typing import Optional

class RequestContext:
    def __init__(
        self,
        request=None,
        request_id: Optional[str] = None,
        user: Optional[str] = None
    ):
        self.request = request
        self.request_id = request_id
        self.user = user


current_context: ContextVar[RequestContext | None] = ContextVar(
    "current_context",
    default=None
)