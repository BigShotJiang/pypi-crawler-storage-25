import uuid
from starlette.middleware.base import BaseHTTPMiddleware
from Osdental.Rest.Context.RequestContext import RequestContext, current_context

class RequestContextMiddleware(BaseHTTPMiddleware):

    async def dispatch(self, request, call_next):
        
        request_id = request.headers.get("X-Request-ID") or str(uuid.uuid4())

        context = RequestContext(
            request=request,
            request_id=request_id
        )

        token = current_context.set(context)

        try:
            response = await call_next(request)
            return response
        finally:
            current_context.reset(token)