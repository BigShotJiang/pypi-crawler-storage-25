from abc import ABC, abstractmethod
from Osdental.Models.Notification import Notification

class INotificationPublisher(ABC):

    @abstractmethod
    async def send_notification(
        self,
        notification: Notification
    ) -> None:
        pass