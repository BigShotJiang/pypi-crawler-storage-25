from typing import Dict, Any
from Osdental.Encryptor.Aes import AES
from Osdental.Encryptor.Rsa import RSAEncryptor
from Osdental.Shared.Logger import logger

VALID_TYPES = {"RSA", "AES"}

def encryptor_data(encryption_type: str, key: str, data: Dict[str, Any] | str) -> Any:
    match encryption_type:

        case "AES":
            return AES.encrypt(key, data)

        case "RSA":
            return RSAEncryptor.encrypt(data, key)
        
        case _:
            logger.warning(f"Encryption type '{encryption_type}' not supported.")
            return data
        
def decryptor_data(encryption_type: str, key: str, data: Dict[str, Any] | str) -> Any:
    
    match encryption_type:

        case "AES":
            return AES.decrypt(key, data)

        case "RSA":
            return RSAEncryptor.decrypt(data, key)
        
        case _:
            logger.warning(f"Encryption type '{encryption_type}' not supported.")
            return data