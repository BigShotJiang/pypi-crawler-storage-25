import json
from Osdental.Http.APIClient import APIClient
from Osdental.Shared.Logger import logger
from Osdental.Helpers._Ports import INotificationPublisher
from Osdental.Models.Notification import Notification


class WebsocketClient(INotificationPublisher):

    SEND_NOTIFICATION_MUTATION = """
        mutation SendNotification($data: String!, $message: String!) {
            sendNotification(data: $data, message: $message)
        }
    """

    def __init__(self, client: APIClient, endpoint: str):
        self.client = client
        self.endpoint = endpoint

    async def send_notification(self, notification: Notification) -> None:
        variables = {
            "data": json.dumps(notification.to_dict()),
            "message": notification.message
        }

        try:

            res = await self.client.execute(
                self.endpoint,
                self.SEND_NOTIFICATION_MUTATION,
                variables
            )

            logger.debug(
                f"Websocket notification sent successfully → {res}"
            )

        except Exception as e:

            logger.error(
                f"Error sending websocket notification: {e}"
            )

            raise
