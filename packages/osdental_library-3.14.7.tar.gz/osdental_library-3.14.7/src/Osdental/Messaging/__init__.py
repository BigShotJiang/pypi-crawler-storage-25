from abc import ABC, abstractmethod
from typing import Any

class IMessageQueue(ABC):

    @abstractmethod
    async def send_message(self, message: Any) -> None:
        pass

    @abstractmethod
    async def close(self) -> None:
        pass