from typing import Any
from Osdental.Messaging import IMessageQueue

class RabbitMqQueue(IMessageQueue):

    async def send_message(self, message: Any) -> None:
        print(f'[RabbitMQ] Queuing message: {message}')

    
    async def close(self) -> None:
        print("Closing...")