from typing import Any
from Osdental.Messaging import IMessageQueue

class KafkaQueue(IMessageQueue):

    async def send_message(self, message: Any) -> None:
        print(f'[Kafka] Queuing message: {message}')
    
    
    async def close(self) -> None:
        print("Closing...")