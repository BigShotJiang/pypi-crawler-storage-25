from dataclasses import dataclass, field
from typing import Any, Optional
from fastapi import Request
from Osdental.Models.AuditConfig import AuditConfig


@dataclass
class Audit:
    request: Request
    audit_config: AuditConfig
    payload: Any = field(default_factory=dict)
    audit_type: str = field(default="MESSAGE_LOG_INTERNAL")
    operation_name: Optional[str] = "Unknown"
    full_name: Optional[str] = "Joe Doe"