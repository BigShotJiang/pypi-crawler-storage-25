from dataclasses import dataclass

@dataclass(frozen=True)
class AuditConfig:
    environment: str
    microservice_name: str
    microservice_version: str