from dataclasses import dataclass, field, asdict
from typing import Any, Optional
from Osdental.Shared.Enums.Code import Code
from Osdental.Shared.Enums.Message import Message

@dataclass
class ApiResponse:
    status: Any = field(default=Code.PROCESS_SUCCESS_CODE)
    message: str = field(default=Message.PROCESS_SUCCESS_MSG)
    data: Optional[Any] = None
    error: Optional[str] = None

    def send(self):
        api_response = asdict(self)

        if api_response["error"] is None:
            api_response.pop("error")