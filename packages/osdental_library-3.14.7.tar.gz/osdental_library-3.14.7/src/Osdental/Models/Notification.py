from dataclasses import dataclass, asdict

@dataclass
class Notification:
    user_id: str
    action: str
    message: str

    def to_dict(self):
        return asdict(self)