# osdental-library

`osdental-library` centralizes the core components and shared utilities of the ecosystem. Its goal is to ensure technical consistency, reduce code duplication, and accelerate delivery time for our digital products.

## What's new in v3.14.7

## Features
- Added @parse_rpc_request_payload decorator for automated JSON/Byte serialization
- Implement GrpcConnection manager for async channels

## Bug Fixes
- Fixed token handling logic based on specific user profile constraints.
- Resolved an issue where inactive tokens were incorrectly passing validation.
- Fixed an issue in TenantPolicy where id_external_enterprise resolution relied on implicit sequential mutations, causing unintended overwrites. Implemented explicit priority handling (request > marketing > admin) to ensure deterministic behavior.

## Breaking Changes (v3.14)
- Removed the database execution methods from the connection class.
- Removed internal gRPC connections. Now, these must be injected from the client microservice, allowing greater flexibility and avoiding circular dependencies.
- Classes that connected directly via .env were removed. Access to Azure has been restructured to support Dependency Injection correctly.
- The base structure generation CLI commands have been temporarily removed to adapt them to the new library architecture.
- Improved audit queue handling by centralizing it into a single control point. Added support for decrypting final responses using AES and RSA algorithms.

## What's Next
- Implementation of a stricter validation process to improve type-safety and structural control of authentication payloads.
- Migration plan for all base libraries to their most recent stable versions.
- Refinement of methods for hybrid environments that require switching between Managed Identity and Connection Strings depending on the environment.
- Continuous monitoring to resolve bugs and improve performance in the consumption of Azure resources.

We continue to work to deliver a superior development experience, ensuring our internal infrastructure is robust, secure and easy to deploy.

## Installation

You can easily install `osdental-library` using `pip`:

```bash
pip install osdental-library