# kloudhub-mcp

MCP server for [KloudHub](https://kloudhub.io). Connect Claude, Codex, or any MCP-compatible AI client to KloudHub and manage your cloud infrastructure through natural language.

## What you can do

| Ask Claude... | What happens |
|---|---|
| "Scan my AWS account and show me what's wasting money" | Discovers all resources across regions, runs cost analysis |
| "Generate a VPC for my new service and deploy it" | Creates a Terraform blueprint and deploys it to AWS |
| "Show me all failed deployments this week" | Queries deployment history with status and logs |
| "Run KloudPilot on my account and give me the top recommendations" | Starts an AI health analysis and returns findings |
| "What's my cloud spend vs last month?" | Returns MTD costs and month-over-month comparison |
| "Start a persistent shell environment" | Provisions a cloud shell and returns connection details |

## Tools

- **Cloud Accounts** - list connected AWS accounts
- **Klouds** - list, inspect, and generate infrastructure blueprints
- **Deployments** - deploy Terraform, get status, stream logs
- **Cloud Scanning** - discover all AWS resources across regions
- **Cost Analysis** - MTD costs, forecasts, month-over-month comparison
- **Waste Detection** - identify idle and oversized resources with savings estimates
- **KloudPilot** - AI health scores and optimization recommendations
- **Persistent Shells** - create and manage cloud shell environments
- ...and more

## Quickstart

### 1. Generate an API key

Go to [app.kloudhub.io/mcp](https://app.kloudhub.io/mcp) and generate an API key.

### 2. Add to Claude Code

```json
{
  "mcpServers": {
    "kloudhub": {
      "type": "stdio",
      "command": "uvx",
      "args": ["kloudhub-mcp"],
      "env": {
        "KLOUDHUB_API_KEY": "khub_live_YOUR_KEY"
      }
    }
  }
}
```

Add to `~/.claude/settings.json` (global) or `.claude/settings.json` (per-project).

### 3. Add to Claude Desktop

```json
{
  "mcpServers": {
    "kloudhub": {
      "command": "uvx",
      "args": ["kloudhub-mcp"],
      "env": {
        "KLOUDHUB_API_KEY": "khub_live_YOUR_KEY"
      }
    }
  }
}
```

**macOS:** `~/Library/Application Support/Claude/claude_desktop_config.json`  
**Windows:** `%APPDATA%\Claude\claude_desktop_config.json`

Restart Claude Desktop after saving.

### 4. Claude Web (Remote MCP)

In Claude.ai, go to Settings, then Integrations, then Add MCP Server:

```
https://mcp.kloudhub.io/sse
```

Enter your API key when prompted. No local install needed.

### 5. Codex CLI

```json
{
  "mcpServers": {
    "kloudhub": {
      "command": "uvx",
      "args": ["kloudhub-mcp"],
      "env": {
        "KLOUDHUB_API_KEY": "khub_live_YOUR_KEY"
      }
    }
  }
}
```

Add to `~/.codex/config.json`.

## Security

- Cloud credentials (AWS keys, secrets, tokens) are **never** accessible via MCP
- Only operational data is returned: resource names, costs, analysis results, deployment logs
- API keys are stored as SHA-256 hashes and shown only once at creation
- All tool calls go through KloudHub's authenticated API

## Requirements

- Python 3.11+
- A [KloudHub](https://kloudhub.io) account with at least one connected AWS cloud account

## Links

- [KloudHub](https://kloudhub.io)
- [Generate API Key](https://app.kloudhub.io/mcp)
- [Documentation](https://docs.kloudhub.io/mcp)
