"""Authenticated HTTP client for KloudHub API calls.

In stdio mode, the API key comes from settings (one key per process).
In remote SSE mode, the API key comes from the per-connection ContextVar so
multiple users can share one server process safely.
"""
from __future__ import annotations

import httpx

from kloudhub_mcp.config import settings
from kloudhub_mcp.context import current_api_key

# Base client — shared for connection pooling, NO auth baked into headers.
# Auth is injected per-request so remote SSE multi-tenant works correctly.
_client: httpx.AsyncClient | None = None


def _get_base_client() -> httpx.AsyncClient:
    global _client
    if _client is None or _client.is_closed:
        _client = httpx.AsyncClient(
            base_url=settings.kloudhub_base_url,
            headers={
                "Content-Type": "application/json",
                "User-Agent": "kloudhub-mcp/0.1.0",
            },
            timeout=httpx.Timeout(60.0, connect=10.0),
            follow_redirects=True,
        )
    return _client


def _get_api_key() -> str:
    """Return the API key for the current request.

    Prefers the ContextVar (set by remote SSE middleware per-connection).
    Falls back to the module-level settings value (stdio mode).
    """
    return current_api_key.get("") or settings.kloudhub_api_key


async def api_get(path: str, params: dict | None = None) -> dict:
    """GET request to KloudHub API. Raises ValueError with a clean message on error."""
    headers = {"Authorization": f"Bearer {_get_api_key()}"}
    resp = await _get_base_client().get(path, params=params, headers=headers)
    return _handle_response(resp)


async def api_post(path: str, body: dict | None = None) -> dict:
    """POST request to KloudHub API."""
    headers = {"Authorization": f"Bearer {_get_api_key()}"}
    resp = await _get_base_client().post(path, json=body or {}, headers=headers)
    return _handle_response(resp)


def _handle_response(resp: httpx.Response) -> dict:
    if resp.status_code == 401:
        raise ValueError("Authentication failed — check your KLOUDHUB_API_KEY")
    if resp.status_code == 403:
        raise ValueError("Access denied")
    if resp.status_code == 404:
        raise ValueError("Resource not found")
    if resp.status_code >= 500:
        raise ValueError(f"KloudHub API error (HTTP {resp.status_code})")
    resp.raise_for_status()
    return resp.json()


async def close_client() -> None:
    global _client
    if _client and not _client.is_closed:
        await _client.aclose()
        _client = None
