from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """MCP server configuration loaded from environment variables."""

    kloudhub_api_key: str = ""
    """KloudHub API key (khub_live_...).
    Required for stdio mode. Not needed for remote SSE mode (per-connection auth).
    Generate at https://app.kloudhub.io/mcp"""

    kloudhub_base_url: str = "https://app.kloudhub.io"
    """KloudHub application base URL."""

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8")


# Module-level singleton — loaded once at import time
settings = Settings()
