from pydantic import BaseModel


class ShellInfo(BaseModel):
    id: str
    name: str | None = None
    status: str | None = None
    created_at: str | None = None
    last_activity_at: str | None = None

    # SECURITY: shell output and file contents are never included —
    # they may contain cloud credentials or sensitive runtime data.
