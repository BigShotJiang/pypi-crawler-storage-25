from pydantic import BaseModel


class ScanSummary(BaseModel):
    id: str
    status: str | None = None
    cloud_account_id: str | None = None
    total_resources: int | None = None
    total_monthly_cost: float | None = None
    regions_scanned: list[str] | None = None
    created_at: str | None = None


class WasteFinding(BaseModel):
    id: str | None = None
    resource_id: str | None = None
    resource_type: str | None = None
    service: str | None = None
    region: str | None = None
    rule_name: str | None = None
    category: str | None = None
    severity: str | None = None
    monthly_cost: float | None = None
    estimated_savings: float | None = None
    recommendation: str | None = None


class KloudPilotSummary(BaseModel):
    id: str
    status: str | None = None
    health_score: float | None = None
    total_resources: int | None = None
    resources_optimized: int | None = None
    resources_attention: int | None = None
    estimated_monthly_savings: float | None = None
    executive_summary: str | None = None
    top_recommendations: list[str] | None = None
    created_at: str | None = None
