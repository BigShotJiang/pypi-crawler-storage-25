from pydantic import BaseModel


class DeploymentSummary(BaseModel):
    id: str
    kloud_id: str | None = None
    kloud_name: str | None = None
    status: str | None = None
    cloud_account_id: str | None = None
    region: str | None = None
    resources_added: int | None = None
    resources_changed: int | None = None
    resources_destroyed: int | None = None
    created_at: str | None = None
    updated_at: str | None = None
    error_message: str | None = None
