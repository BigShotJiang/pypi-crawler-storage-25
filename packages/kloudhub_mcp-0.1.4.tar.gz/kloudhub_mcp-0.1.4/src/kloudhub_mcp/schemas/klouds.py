from pydantic import BaseModel


class KloudSummary(BaseModel):
    id: str
    name: str
    description: str | None = None
    status: str | None = None
    is_public: bool = False
    created_at: str | None = None
    updated_at: str | None = None


class KloudDetail(KloudSummary):
    terraform_files: list[str] | None = None
    provider: str | None = None
    resource_count: int | None = None
