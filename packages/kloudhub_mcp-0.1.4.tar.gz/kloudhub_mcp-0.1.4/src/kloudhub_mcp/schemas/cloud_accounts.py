"""Sanitized cloud account schema — credentials are intentionally excluded."""
from pydantic import BaseModel


class CloudAccountSummary(BaseModel):
    id: str
    name: str
    provider: str = "aws"
    aws_region: str | None = None
    aws_account_id: str | None = None
    is_default: bool = False
    is_validated: bool = False
    last_validated_at: str | None = None

    # SECURITY: aws_access_key_id and aws_secret_access_key are NEVER included.
