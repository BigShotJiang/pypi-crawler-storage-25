"""KloudHub MCP Server — Connect AI clients to KloudHub cloud infrastructure."""
__version__ = "0.1.0"
