"""
KloudHub MCP — Remote SSE Server.

Hosts the MCP protocol over HTTP/SSE for clients that don't run a local
process (Claude Web, remote deployments). Each connection authenticates
with a KloudHub API key (khub_live_*) and gets an isolated async context
so multiple users can share one server process safely.

Deployment: run with `kloudhub-mcp --transport sse --port 8001`
Hosted at: https://mcp.kloudhub.io
"""
from __future__ import annotations

import json
import logging

import httpx
from starlette.applications import Starlette
from starlette.middleware.cors import CORSMiddleware
from starlette.requests import Request
from starlette.responses import Response
from starlette.routing import Mount, Route

from kloudhub_mcp._app import mcp
from kloudhub_mcp.config import settings
from kloudhub_mcp.context import current_api_key

# Import all tools so @mcp.tool() decorators are executed
import kloudhub_mcp.tools  # noqa: F401

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# API key validation — with 5-min in-process cache to survive brief outages
# ---------------------------------------------------------------------------

_key_cache: dict[str, tuple[bool, float]] = {}  # hash → (valid, expires_at)
_CACHE_TTL = 300.0  # 5 minutes


def _cache_key(raw_key: str) -> str:
    import hashlib
    return hashlib.sha256(raw_key.encode()).hexdigest()


async def _validate_api_key(raw_key: str) -> bool:
    """Validate key against the KloudHub application. Returns True if valid."""
    import time
    ck = _cache_key(raw_key)
    now = time.monotonic()

    cached = _key_cache.get(ck)
    if cached and cached[1] > now:
        return cached[0]

    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.get(
                f"{settings.kloudhub_base_url}/api/api-keys/validate",
                headers={"Authorization": f"Bearer {raw_key}"},
            )
            valid = resp.status_code == 200
    except Exception as exc:
        logger.warning("API key validation request failed: %s", exc)
        # If we have a stale cache entry, serve it rather than hard-failing
        if cached:
            return cached[0]
        return False

    _key_cache[ck] = (valid, now + _CACHE_TTL)
    return valid


# ---------------------------------------------------------------------------
# Raw ASGI auth middleware — sets ContextVar before every MCP connection
# ---------------------------------------------------------------------------

class _ApiKeyAuthMiddleware:
    """ASGI middleware: validates Bearer token and sets per-connection ContextVar.

    Must be raw ASGI (not Starlette BaseHTTPMiddleware) so the ContextVar
    is set *before* the async SSE stream starts and is correctly inherited
    by all tasks spawned within that connection's async context.
    """

    def __init__(self, app) -> None:
        self._app = app

    async def __call__(self, scope, receive, send) -> None:
        if scope["type"] not in ("http", "websocket"):
            await self._app(scope, receive, send)
            return

        headers = {k.lower(): v for k, v in scope.get("headers", [])}
        auth = headers.get(b"authorization", b"").decode()

        if not auth.startswith("Bearer khub_live_"):
            await _json_response(
                send,
                401,
                {
                    "error": (
                        "KloudHub API key required. "
                        "Set Authorization: Bearer khub_live_... "
                        "Generate a key at https://app.kloudhub.io/mcp"
                    )
                },
            )
            return

        raw_key = auth[len("Bearer "):]

        valid = await _validate_api_key(raw_key)
        if not valid:
            await _json_response(
                send,
                401,
                {"error": "Invalid or revoked KloudHub API key"},
            )
            return

        # Set per-connection API key — inherited by all async tasks in this context
        token = current_api_key.set(raw_key)
        try:
            await self._app(scope, receive, send)
        finally:
            current_api_key.reset(token)


async def _json_response(send, status: int, body: dict) -> None:
    body_bytes = json.dumps(body).encode()
    await send(
        {
            "type": "http.response.start",
            "status": status,
            "headers": [
                (b"content-type", b"application/json"),
                (b"content-length", str(len(body_bytes)).encode()),
            ],
        }
    )
    await send({"type": "http.response.body", "body": body_bytes})


# ---------------------------------------------------------------------------
# MCP SSE ASGI app builder
# ---------------------------------------------------------------------------

def _build_mcp_sse_app():
    """Build Starlette app exposing the MCP server over SSE transport."""
    from mcp.server.sse import SseServerTransport

    # SseServerTransport handles the /messages POST endpoint internally
    sse_transport = SseServerTransport("/messages/")

    # Access the underlying low-level mcp.server.Server from FastMCP
    _server = getattr(mcp, "_mcp_server", mcp)

    async def handle_sse(request: Request) -> Response:
        async with sse_transport.connect_sse(
            request.scope,
            request.receive,
            request._send,  # type: ignore[attr-defined]
        ) as (read_stream, write_stream):
            await _server.run(
                read_stream,
                write_stream,
                _server.create_initialization_options(),
            )
        return Response()

    async def handle_messages(request: Request) -> Response:
        await sse_transport.handle_post_message(
            request.scope,
            request.receive,
            request._send,  # type: ignore[attr-defined]
        )
        return Response()

    return Starlette(
        routes=[
            Route("/sse", handle_sse),
            Route("/messages/", handle_messages, methods=["POST"]),
        ]
    )


def build_remote_app() -> Starlette:
    """Build the full ASGI app: CORS → auth middleware → MCP SSE."""
    mcp_sse = _build_mcp_sse_app()

    # Wrap with auth middleware (raw ASGI so ContextVar is set before SSE stream)
    authed = _ApiKeyAuthMiddleware(mcp_sse)

    # Health check endpoint (no auth required — for load balancers / uptime)
    async def health(request: Request) -> Response:
        return Response(
            json.dumps({"status": "ok", "server": "kloudhub-mcp"}),
            media_type="application/json",
        )

    # Compose final app with CORS for Claude Web browser connections
    app = Starlette(
        routes=[
            Route("/health", health),
            Mount("/", app=authed),
        ]
    )
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["https://claude.ai", "https://chatgpt.com"],
        allow_methods=["GET", "POST", "OPTIONS"],
        allow_headers=["Authorization", "Content-Type"],
    )
    return app
