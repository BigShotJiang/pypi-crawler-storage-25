"""
KloudHub MCP Server — entry point.

Two transport modes:
  stdio  (default) — local clients: Claude Desktop, Claude Code, Codex CLI
  sse              — remote hosted: Claude Web at https://mcp.kloudhub.io

Usage:
  kloudhub-mcp                          # stdio, requires KLOUDHUB_API_KEY
  kloudhub-mcp --transport sse          # SSE on 0.0.0.0:8001, per-connection auth
  kloudhub-mcp --transport sse --port 9000 --host 127.0.0.1
"""
from __future__ import annotations

import argparse
import sys


def main() -> None:
    """CLI entry point: kloudhub-mcp"""
    parser = argparse.ArgumentParser(
        prog="kloudhub-mcp",
        description="KloudHub MCP server — connects AI clients to your cloud infrastructure",
    )
    parser.add_argument(
        "--transport",
        choices=["stdio", "sse"],
        default="stdio",
        help="Transport protocol (default: stdio)",
    )
    parser.add_argument(
        "--host",
        default="0.0.0.0",
        help="Host to bind for SSE mode (default: 0.0.0.0)",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=8001,
        help="Port to bind for SSE mode (default: 8001)",
    )
    args, _ = parser.parse_known_args()

    if args.transport == "sse":
        _run_sse(args.host, args.port)
    else:
        _run_stdio()


def _run_stdio() -> None:
    """Stdio mode — single user, API key from environment."""
    try:
        from kloudhub_mcp.config import settings  # validate env on startup

        if not settings.kloudhub_api_key.startswith("khub_live_"):
            print(
                "ERROR: KLOUDHUB_API_KEY must start with 'khub_live_'.\n"
                "Generate one at https://app.kloudhub.io/mcp",
                file=sys.stderr,
            )
            sys.exit(1)
    except Exception as exc:
        print(f"ERROR: Configuration invalid — {exc}", file=sys.stderr)
        sys.exit(1)

    from kloudhub_mcp._app import mcp
    import kloudhub_mcp.tools  # noqa: F401 — registers all @mcp.tool() decorators

    mcp.run(transport="stdio")


def _run_sse(host: str, port: int) -> None:
    """SSE mode — multi-tenant, per-connection auth via Bearer token."""
    try:
        import uvicorn
    except ImportError:
        print(
            "ERROR: uvicorn is required for SSE mode.\n"
            "Install with: pip install 'kloudhub-mcp[server]'",
            file=sys.stderr,
        )
        sys.exit(1)

    try:
        from kloudhub_mcp.remote import build_remote_app
    except Exception as exc:
        print(f"ERROR: Failed to build remote SSE app — {exc}", file=sys.stderr)
        sys.exit(1)

    app = build_remote_app()
    print(
        f"KloudHub MCP remote server starting on http://{host}:{port}\n"
        f"SSE endpoint: http://{host}:{port}/sse\n"
        f"Health check:  http://{host}:{port}/health",
        file=sys.stderr,
    )
    uvicorn.run(app, host=host, port=port, log_level="info")


if __name__ == "__main__":
    main()
