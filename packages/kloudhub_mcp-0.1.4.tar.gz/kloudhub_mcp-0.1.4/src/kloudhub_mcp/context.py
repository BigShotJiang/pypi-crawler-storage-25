"""Per-connection context for multi-tenant remote SSE mode."""
from contextvars import ContextVar

# Stores the API key for the current MCP connection.
# In stdio mode: not used (settings.kloudhub_api_key is used directly).
# In remote SSE mode: set per-connection by the auth middleware so each
# concurrent user's tool calls carry their own credentials.
current_api_key: ContextVar[str] = ContextVar("current_api_key", default="")
