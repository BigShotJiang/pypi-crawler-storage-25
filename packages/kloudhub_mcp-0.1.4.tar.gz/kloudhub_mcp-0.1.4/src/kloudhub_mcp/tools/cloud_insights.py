"""Tools: start_cloud_scan, get_scan_status, get_scan_resources"""
from kloudhub_mcp._app import mcp
from kloudhub_mcp.client.http import api_get, api_post
from kloudhub_mcp.schemas.insights import ScanSummary

# Fields that must never appear in resource lists (defense-in-depth)
_CREDENTIAL_FIELDS = {
    "access_key", "secret_key", "aws_access_key_id", "aws_secret_access_key",
    "password", "token", "secret", "credentials", "private_key",
}


@mcp.tool()
async def start_cloud_scan(
    cloud_account_id: str,
    regions: list[str] | None = None,
) -> dict:
    """
    Start a full AWS resource discovery scan for a cloud account.

    Discovers all AWS resources (EC2, S3, RDS, Lambda, VPC, etc.) across
    the specified regions and calculates monthly costs.

    This is async — use get_scan_status(scan_id) to poll until status == "completed".

    Args:
        cloud_account_id: The cloud account to scan (from list_cloud_accounts)
        regions: AWS regions to scan (default: all active regions)

    Returns scan_id for polling.
    """
    body: dict = {"cloud_account_id": cloud_account_id}
    if regions:
        body["regions"] = regions
    data = await api_post("/api/cloud-insights", body)
    return {
        "scan_id": data.get("id") or data.get("scan_id"),
        "status": data.get("status"),
    }


@mcp.tool()
async def get_scan_status(scan_id: str) -> dict:
    """
    Check the status of a cloud resource scan.

    Args:
        scan_id: The scan UUID

    Returns status, total resources found, total monthly cost, and regions scanned.
    Status values: pending → scanning → completed | failed | cancelled
    """
    data = await api_get(f"/api/cloud-insights/{scan_id}")
    scan = data.get("scan", data)
    return ScanSummary.model_validate(scan).model_dump(exclude_none=True)


@mcp.tool()
async def get_scan_resources(
    scan_id: str,
    service: str | None = None,
    region: str | None = None,
    limit: int = 50,
) -> list[dict]:
    """
    Get discovered AWS resources from a completed scan.

    Args:
        scan_id: The completed scan UUID
        service: Optional filter by AWS service (e.g. "EC2", "S3", "RDS")
        region: Optional filter by AWS region
        limit: Max resources to return (default 50, max 200)

    Returns resource list with type, name, region, state, and monthly cost.
    Cloud credentials are never included.
    """
    params: dict = {"limit": min(limit, 200)}
    if service:
        params["service"] = service
    if region:
        params["region"] = region
    data = await api_get(f"/api/cloud-insights/{scan_id}/resources", params=params)
    resources = data if isinstance(data, list) else data.get("resources", [])

    # Strip any credential-like fields (defense-in-depth — schemas should catch these first)
    return [
        {k: v for k, v in r.items() if k.lower() not in _CREDENTIAL_FIELDS}
        for r in resources
    ]
