"""Tools: start_kloudpilot, get_kloudpilot_status, get_kloudpilot_results"""
from kloudhub_mcp._app import mcp
from kloudhub_mcp.client.http import api_get, api_post
from kloudhub_mcp.schemas.insights import KloudPilotSummary


@mcp.tool()
async def start_kloudpilot(cloud_account_id: str) -> dict:
    """
    Start a KloudPilot AI analysis for a cloud account.

    KloudPilot scans all resources across 9 AWS services, enriches them with
    30 days of CloudWatch metrics, then uses AI to generate:
    - An overall health score (0–100)
    - Optimization recommendations ranked by business impact
    - Per-service analysis (security, cost, performance)
    - Estimated total monthly savings

    This is async — use get_kloudpilot_status(analysis_id) to poll until complete.

    Args:
        cloud_account_id: The cloud account to analyze (from list_cloud_accounts)

    Returns analysis_id for polling.
    """
    data = await api_post("/api/kloudpilot", {"cloud_account_id": cloud_account_id})
    return {
        "analysis_id": data.get("id") or data.get("analysis_id"),
        "status": data.get("status"),
    }


@mcp.tool()
async def get_kloudpilot_status(analysis_id: str) -> dict:
    """
    Check the status of a KloudPilot analysis.

    Args:
        analysis_id: The KloudPilot analysis UUID

    Returns status and progress.
    Status values: pending → collecting → analyzing → completed | failed | cancelled
    """
    return await api_get(f"/api/kloudpilot/{analysis_id}/status")


@mcp.tool()
async def get_kloudpilot_results(analysis_id: str) -> dict:
    """
    Get the full results of a completed KloudPilot analysis.

    Args:
        analysis_id: The completed KloudPilot analysis UUID

    Returns health score, resource counts, estimated savings, executive summary,
    top priority recommendations, and per-service analysis.
    """
    data = await api_get(f"/api/kloudpilot/{analysis_id}")
    analysis = data.get("analysis", data)
    return KloudPilotSummary.model_validate(analysis).model_dump(exclude_none=True)
