"""Tool: list_cloud_accounts"""
from kloudhub_mcp._app import mcp
from kloudhub_mcp.client.http import api_get
from kloudhub_mcp.schemas.cloud_accounts import CloudAccountSummary


@mcp.tool()
async def list_cloud_accounts() -> list[dict]:
    """
    List all connected AWS cloud accounts.

    Returns account names, regions, AWS account IDs, and validation status.
    Cloud credentials (access keys, secrets) are never included.
    """
    data = await api_get("/api/cloud-accounts")
    accounts = data.get("accounts", [])
    return [
        CloudAccountSummary.model_validate(a).model_dump(exclude_none=True)
        for a in accounts
    ]
