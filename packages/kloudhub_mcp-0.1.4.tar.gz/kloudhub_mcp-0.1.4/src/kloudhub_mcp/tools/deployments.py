"""Tools: list_deployments, deploy_kloud, get_deployment_status, get_deployment_logs"""
from kloudhub_mcp._app import mcp
from kloudhub_mcp.client.http import api_get, api_post
from kloudhub_mcp.schemas.deployments import DeploymentSummary


@mcp.tool()
async def list_deployments(
    status: str | None = None,
    limit: int = 20,
) -> list[dict]:
    """
    List infrastructure deployments.

    Args:
        status: Optional filter — e.g. "deployed", "failed", "planning", "applying"
        limit: Max results to return (default 20, max 100)

    Returns deployment history with status, kloud name, and resource change counts.
    """
    params: dict = {"limit": min(limit, 100)}
    if status:
        params["status"] = status
    data = await api_get("/api/deployments", params=params)
    deployments = data if isinstance(data, list) else data.get("deployments", [])
    return [DeploymentSummary.model_validate(d).model_dump(exclude_none=True) for d in deployments]


@mcp.tool()
async def deploy_kloud(
    kloud_id: str,
    cloud_account_id: str,
    region: str = "ap-south-1",
    auto_approve: bool = False,
) -> dict:
    """
    Deploy a Kloud infrastructure blueprint to AWS using Terraform.

    This starts an async deployment. Use get_deployment_status(deployment_id) to
    poll until status is "deployed" or "failed".

    Args:
        kloud_id: The Kloud to deploy
        cloud_account_id: Target AWS account (from list_cloud_accounts)
        region: AWS region (default: ap-south-1)
        auto_approve: Skip plan review and apply immediately (use with caution)

    Returns deployment_id for status polling.
    """
    data = await api_post("/api/deployments", {
        "kloud_id": kloud_id,
        "cloud_account_id": cloud_account_id,
        "region": region,
        "auto_approve": auto_approve,
    })
    return {
        "deployment_id": data.get("id") or data.get("deployment_id"),
        "status": data.get("status"),
    }


@mcp.tool()
async def get_deployment_status(deployment_id: str) -> dict:
    """
    Get the current status of a deployment.

    Args:
        deployment_id: The deployment UUID

    Returns status, plan summary (resources added/changed/destroyed),
    Terraform outputs, and any error messages.
    Status values: pending → planning → planned → applying → deployed | failed
    """
    data = await api_get(f"/api/deployments/{deployment_id}")
    deployment = data.get("deployment", data)
    return DeploymentSummary.model_validate(deployment).model_dump(exclude_none=True)


@mcp.tool()
async def get_deployment_logs(deployment_id: str) -> str:
    """
    Fetch deployment logs (Terraform plan/apply output).

    Args:
        deployment_id: The deployment UUID

    Returns the raw Terraform log output as a string.
    Logs are sanitized at source — no credentials are included.
    """
    data = await api_get(f"/api/deployments/{deployment_id}/logs")
    return data.get("logs") or data.get("content") or str(data)
