"""Tool registry — importing all modules triggers @mcp.tool() registration."""
from . import (  # noqa: F401
    cloud_accounts,
    klouds,
    deployments,
    cloud_insights,
    costs,
    waste,
    kloudpilot,
    shells,
)
