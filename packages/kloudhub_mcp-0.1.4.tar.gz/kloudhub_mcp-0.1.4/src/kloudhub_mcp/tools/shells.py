"""Tools: list_shells, create_shell, stop_shell"""
from kloudhub_mcp._app import mcp
from kloudhub_mcp.client.http import api_get, api_post
from kloudhub_mcp.schemas.shells import ShellInfo


@mcp.tool()
async def list_shells() -> list[dict]:
    """
    List all persistent shell environments.

    Returns shell metadata: id, name, status, and timestamps.
    Shell command output and file contents are never included for security.
    """
    data = await api_get("/api/persistent-shells")
    shells = data if isinstance(data, list) else data.get("shells", [])
    return [ShellInfo.model_validate(s).model_dump(exclude_none=True) for s in shells]


@mcp.tool()
async def create_shell(name: str) -> dict:
    """
    Create a new persistent shell environment.

    Provisions a Docker container pre-loaded with the user's AWS credentials
    and common cloud tools (AWS CLI, kubectl, terraform, etc.). The shell
    persists across disconnects — reconnect from the KloudHub UI at any time.
    Up to 5 active shells per user. Once created, connect via the KloudHub
    web terminal at app.kloudhub.io/shells.

    Args:
        name: A short descriptive label (e.g. "prod-debug", "vpc-setup", "k8s-fix")

    Returns the shell id, status, and connection details.
    """
    data = await api_post("/api/persistent-shells", {"name": name})
    shell = data.get("shell", data)
    return ShellInfo.model_validate(shell).model_dump(exclude_none=True)


@mcp.tool()
async def stop_shell(shell_id: str) -> dict:
    """
    Stop a running persistent shell environment.

    Args:
        shell_id: The shell UUID to stop

    Returns the updated shell status.
    """
    return await api_post(f"/api/persistent-shells/{shell_id}/stop", {})
