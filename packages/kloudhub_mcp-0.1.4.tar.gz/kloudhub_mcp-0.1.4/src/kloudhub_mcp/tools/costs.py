"""Tools: get_scan_costs, get_cost_comparison"""
from kloudhub_mcp._app import mcp
from kloudhub_mcp.client.http import api_get


@mcp.tool()
async def get_scan_costs(scan_id: str) -> dict:
    """
    Get the cost breakdown from a completed cloud scan.

    Returns a breakdown of AWS spend by service (EC2, RDS, S3, Lambda, etc.)
    and by region, based on the billing data collected during the scan.
    Each entry includes the service name, region, and monthly cost in USD.

    Call get_scan_status(scan_id) first and wait for status == "completed".

    Args:
        scan_id: UUID of the completed scan (from start_cloud_scan)

    Returns:
        costs: list of {service, region, monthly_cost_usd}
        total_monthly_usd: total estimated monthly spend across all services
    """
    return await api_get(f"/api/cloud-insights/{scan_id}/costs")


@mcp.tool()
async def get_cost_comparison(scan_id: str) -> dict:
    """
    Compare current month-to-date spend vs the previous month (same period).

    Useful for spotting cost spikes or savings. Returns the raw USD figures,
    percentage change (positive = spending more, negative = spending less),
    and a forecast for the full current month based on daily run rate.

    Args:
        scan_id: UUID of the completed scan (from start_cloud_scan)

    Returns:
        mtd_cost_usd: spend so far this month
        last_month_same_period_usd: spend over the same days last month
        change_pct: percentage change (e.g. 12.5 means 12.5% more than last month)
        forecast_usd: projected full-month spend at current daily rate
    """
    return await api_get(f"/api/cloud-insights/{scan_id}/cost-comparison")
