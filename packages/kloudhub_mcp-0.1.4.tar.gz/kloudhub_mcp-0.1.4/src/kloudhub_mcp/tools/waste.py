"""Tools: start_waste_analysis, get_waste_status, get_waste_findings"""
from kloudhub_mcp._app import mcp
from kloudhub_mcp.client.http import api_get, api_post
from kloudhub_mcp.schemas.insights import WasteFinding


@mcp.tool()
async def start_waste_analysis(cloud_account_id: str) -> dict:
    """
    Start a waste detection analysis to identify underutilized or idle AWS resources.

    Analyzes CloudWatch metrics over 14 days to find resources that can be
    rightsized, stopped, or terminated to reduce costs.

    This is async — use get_waste_status(analysis_id) to poll until complete.

    Args:
        cloud_account_id: The cloud account to analyze (from list_cloud_accounts)

    Returns analysis_id for polling.
    """
    data = await api_post("/api/cloud-insights/waste/analyze", {
        "cloud_account_id": cloud_account_id,
    })
    return {
        "analysis_id": data.get("id") or data.get("analysis_id"),
        "status": data.get("status"),
    }


@mcp.tool()
async def get_waste_status(analysis_id: str) -> dict:
    """
    Check the status of a waste detection analysis.

    Args:
        analysis_id: The waste analysis UUID

    Returns status and progress percentage.
    Status values: pending → analyzing → completed | failed | cancelled
    """
    return await api_get(f"/api/cloud-insights/waste/{analysis_id}/status")


@mcp.tool()
async def get_waste_findings(
    analysis_id: str,
    severity: str | None = None,
) -> list[dict]:
    """
    Get waste findings from a completed analysis.

    Args:
        analysis_id: The completed waste analysis UUID
        severity: Optional filter — "critical", "high", "medium", or "low"

    Returns findings with resource details, estimated monthly savings,
    and remediation recommendations. Sorted by estimated savings descending.
    """
    params: dict = {}
    if severity:
        params["severity"] = severity
    data = await api_get(f"/api/cloud-insights/waste/{analysis_id}/findings", params=params)
    findings = data if isinstance(data, list) else data.get("findings", [])
    return [WasteFinding.model_validate(f).model_dump(exclude_none=True) for f in findings]
