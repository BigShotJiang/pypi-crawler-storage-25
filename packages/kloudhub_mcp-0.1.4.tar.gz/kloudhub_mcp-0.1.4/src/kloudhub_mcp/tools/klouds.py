"""Tools: list_klouds, get_kloud, create_kloud"""
from kloudhub_mcp._app import mcp
from kloudhub_mcp.client.http import api_get, api_post
from kloudhub_mcp.schemas.klouds import KloudSummary, KloudDetail


@mcp.tool()
async def list_klouds(status: str | None = None) -> list[dict]:
    """
    List all infrastructure blueprints (Klouds) for the authenticated user.

    Args:
        status: Optional filter — e.g. "completed", "generating", "failed"

    Returns a list of Klouds with id, name, status, and metadata.
    """
    params: dict = {}
    if status:
        params["status"] = status
    data = await api_get("/api/klouds", params=params)
    klouds = data if isinstance(data, list) else data.get("klouds", [])
    return [KloudSummary.model_validate(k).model_dump(exclude_none=True) for k in klouds]


@mcp.tool()
async def get_kloud(kloud_id: str) -> dict:
    """
    Get detailed information about a specific Kloud infrastructure blueprint.

    Args:
        kloud_id: The UUID of the Kloud

    Returns full metadata including name, status, provider, resource count,
    and list of generated Terraform files.
    """
    data = await api_get(f"/api/klouds/{kloud_id}")
    kloud = data.get("kloud", data)
    return KloudDetail.model_validate(kloud).model_dump(exclude_none=True)


@mcp.tool()
async def create_kloud(
    name: str,
    description: str,
    cloud_account_id: str,
) -> dict:
    """
    Start generating a new infrastructure blueprint (Kloud) using AI.

    This is an async operation — it starts generation and returns immediately.
    Use get_kloud(kloud_id) to poll for status until status == "completed".

    Args:
        name: A short, descriptive name for the infrastructure
        description: Natural language description of what to build
                     (e.g. "VPC with 2 private and 2 public subnets across 2 AZs,
                      with NAT gateway and internet gateway")
        cloud_account_id: The ID of the cloud account to target (from list_cloud_accounts)

    Returns the kloud_id and initial status.
    """
    data = await api_post("/api/klouds/create", {
        "name": name,
        "description": description,
        "cloud_account_id": cloud_account_id,
    })
    return {
        "kloud_id": data.get("kloud_id") or data.get("id"),
        "status": data.get("status", "generating"),
    }
