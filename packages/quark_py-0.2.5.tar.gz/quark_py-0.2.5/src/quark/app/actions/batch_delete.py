from typing import List

from tortoise.queryset import QuerySet

from quark import Message, Request
from quark.template.action import Action


class BatchDelete(Action):

    def __init__(self, name: str = "批量删除"):
        self.name = name
        self.icon = "ant-design:delete-outlined"
        self.type = "primary"
        self.size = "small"
        self.reload = "table"
        self.batch = True
        self.danger = True
        self.ghost = True
        self.with_confirm(
            "确定要删除吗？", "删除后数据将无法恢复，请谨慎操作！", "modal"
        )
        self.set_only_on_index(True)

    def get_api_params(self) -> List[str]:
        return ["id"]

    async def handle(self, request: Request, query: QuerySet):
        try:
            await query.all().delete()
            return Message.success("操作成功")
        except Exception as e:
            return Message.error(str(e))
