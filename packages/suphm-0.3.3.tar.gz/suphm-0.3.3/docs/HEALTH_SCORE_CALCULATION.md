# Health Score Calculation

This document explains how the package health score (0-100) is calculated in suphm.

## Overview

The health score is a weighted average across ten categories. Each category is scored 0-100 from observed metrics, multiplied by its weight, and summed. Default weights sum to 100 so the final score lands on a 0-100 scale.

| Category | Default Weight | Source | What it measures |
|---|---|---|---|
| `commit_activity` | 15 | git history | Commits over the last 90 days, days since the last commit |
| `bus_factor` | 10 | git history | CHAOSS bus factor — minimum contributors holding 50% of recent commits |
| `pony_factor` | 10 | git history | CHAOSS pony factor — number of contributors holding 50% of all-time commits |
| `elephant_factor` | 10 | git + enrichment | CHAOSS elephant factor — distinct organizations holding 50% of commits |
| `contributor_retention` | 10 | git history | Share of prior-window contributors still active in the current 90-day window |
| `license_stability` | 5 | LICENSE file history | Number of detected SPDX-id transitions over the project's lifetime |
| `issue_responsiveness` | 10 | GitHub API | Share of recent issues that received a maintainer response |
| `pr_velocity` | 10 | GitHub API | Median PR merge time |
| `branch_protection` | 10 | GitHub API | Required reviews, status checks, signed commits on the default branch |
| `release_frequency` | 10 | GitHub API | Cadence of tagged releases |

Weights are configurable via `~/.suphm/config.yaml` under `scoring.health`. They must still sum to 100.

The final score also drives a letter grade and risk level:

- **A**: ≥80 (low risk)
- **B**: 70-79 (low risk)
- **C**: 60-69 (medium risk)
- **D**: 50-59 (high risk)
- **F**: <50 (high risk)

## Per-category scoring

Each `_score_*` method in `src/suphm/scoring/health.py` maps observed metrics to a 0-100 score using fixed thresholds. Examples:

- **bus_factor**: `≥10 → 100`, `≥5 → 75`, `≥3 → 50`, `≥2 → 30`, else `20`
- **commit_activity**: rewards both volume (commits in the last 90 days) and recency (days since the last commit)
- **license_stability**: scores on real SPDX-id transitions, not file edits. Initial license adoption is not a "transition." See `_score_license_stability`.
- **branch_protection**: weighted by enforced rules (required reviewers, status checks, etc.)

Read the source for the exact thresholds; they're short and easier to keep current than a duplicated table.

## Normalization

If a category cannot be scored — for example, GitHub API metrics are missing because the request was rate-limited or returned an error — its weight is excluded from both the numerator and the denominator, but the final score is still divided by the **full configured weight (100)** rather than the present weight. This avoids inflating a score when half the data is missing. The amount of weight that actually contributed to the final score is exposed as `extended_metrics.data_completeness` in the JSON output.

## Recommendations

When a category lands in the `warning` or `critical` band, the calculator emits a recommendation in `recommendations[]`. Common ones:

- **Bus Factor ≤ 2**: "High bus factor risk - only X contributor(s) for 50% of commits"
- **Elephant Factor = 1**: "Single company dominance - consider corporate dependency risk"
- **Branch Protection disabled**: "Main branch is not protected - risk of unauthorized changes"
- **License changes detected**: "License has changed multiple times or has concerning transitions"
- **Slow PR merges**: "Slow PR merge times - contributions may not be reviewed promptly"
- **Stagnant contributor growth**: "Stagnant contributor growth - few new contributors joining"

## Caching

Metrics are cached locally under `~/.suphm/cache/` (override via `SUPHM_CACHE_DIR`) so repeat analyses don't re-hit the GitHub or registry APIs. The health score itself is recomputed every run — it's cheap once the underlying metrics are in cache.

## Implementation

`HealthScoreCalculator.calculate()` in `src/suphm/scoring/health.py` is the entry point. It takes a `GitMetricsResult` and a `GitHubMetricsResult` and returns a `HealthScoreResult` with `category_scores`, `risk_factors`, `recommendations`, and `chaoss_metrics`.

## Related documentation

- [commands.md](./commands.md) — CLI command reference
- [API_REFERENCE.md](./API_REFERENCE.md) — Python library API
