# Changelog

## [Unreleased]

## [0.3.3] - 2026-05-08

### Changed (potentially breaking)

- The git-history license detector now runs through ``osslili`` — the
  same library the tarball scanner uses — instead of the hand-rolled
  substring matcher. This makes the two detection paths in suphm
  agree on a given project, picks up the four-tier detection osslili
  provides (exact-hash, Dice-Sørensen, regex), and improves accuracy
  on canonical SPDX license texts.

  Concretely, SPDX ids reported in ``git_metrics.license_changes`` and
  ``health_score.category_scores.license_stability`` may shift to
  modern SPDX 3.x naming. Notable changes:

  - ``GPL-3.0`` → ``GPL-3.0-only``
  - ``GPL-2.0`` → ``GPL-2.0-only``
  - ``LGPL-3.0`` → ``LGPL-3.0-only``
  - ``AGPL-3.0`` → ``AGPL-3.0-only``

  ``MIT``, ``Apache-2.0``, ``BSD-3-Clause``, ``BSD-2-Clause``,
  and ``MPL-2.0`` are unchanged. Internal change-detection consistency
  is preserved — the same input always produces the same id, so the
  ``transitions`` count is stable for any given project.

- The hand-rolled substring matcher is retained as a fallback for
  formats osslili currently doesn't handle (notably the Unlicense
  and very minimal license stubs). It runs only when osslili returns
  no hit. Each per-commit detection adds ~40ms; with the 100-commit
  history cap, the worst-case overhead per analysis is ~4s.

### Notes for users

- Some non-canonical license texts will still classify as ``Unknown``.
  Example: psf/requests' 2011 LICENSE (a non-canonical ISC variant
  that was later relicensed to Apache-2.0) classifies as
  ``Unknown → Apache-2.0`` — a real, accurate license transition,
  but the first state lacks an SPDX id. Installing ``python-tlsh``
  alongside osslili enables fuzzy hashing and improves coverage on
  texts like these; we may make it a default dependency in a future
  release.

## [0.3.2] - 2026-05-08

### Fixed

- `_detect_license` in `metrics/git.py` now requires *all* patterns to
  match before returning a license id. The previous version checked only
  the first pattern (`patterns[:1]`), which meant a file whose header
  read "MIT License" but contained none of the actual MIT terms still
  matched MIT, and licenses sharing a leading phrase (GPL-2.0 vs GPL-3.0,
  BSD-2 vs BSD-3) were never distinguishable. The detector now correctly
  separates GPL-2 from GPL-3, BSD-2 from BSD-3, and recognizes LGPL,
  AGPL, MPL, and Unlicense files that the old version misread or missed.

### Changed

- The CLI `License History` table now shows two rows where it used to
  show one: `Detected Events` (every recorded SPDX-id event, including
  the initial license adoption) and `Relicensing Transitions` (the
  events that represent an actual change between licenses). This makes
  the post-0.3.1 semantics legible — "1 detected event" no longer reads
  as "the license has changed once" when in fact the project simply
  adopted a license and never changed it.

## [0.3.1] - 2026-05-08

### Fixed

- **License-change detector** in `metrics/git.py` no longer reports cosmetic
  edits to the LICENSE file (copyright year bumps, formatting tweaks) as
  license changes. The detector now retrieves the LICENSE content at each
  commit via `git show <sha>:<file>`, runs SPDX detection on the before and
  after states, and only records a `LicenseChange` when the detected
  identifier actually transitions. Previously every commit that touched the
  file produced a fake "null → current" entry, and the resulting
  `change_count` drove the `license_stability` health score into the
  critical band on healthy projects (e.g. psf/requests scored 30/100 on
  license stability despite being Apache-2.0 since 2011). Inspection is
  bounded to the most recent 100 license-touching commits with a 30-second
  wall-clock budget so pathological histories cannot stall the analyzer.
- `_score_license_stability` in `scoring/health.py` was updated to score on
  real transitions rather than total `change_count`, since the first entry
  is now always the project's initial license adoption (null → SPDX), which
  isn't a relicensing event. An "Unknown" current license (LICENSE file
  present but unrecognized SPDX format) is now scored the same as no
  license — legal ambiguity is not stability.

### Documentation

- Removed two large pre-rename specification documents
  (`docs/METRICS_SPECIFICATION.md`, `docs/METRICS_COMPARISON.md`) that
  described aspirational features not present in the codebase and would
  mislead users about what the tool actually does.
- Rewrote `docs/HEALTH_SCORE_CALCULATION.md` to match the actual ten-category
  weighted scoring model in `src/suphm/scoring/health.py`. The previous
  version described a five-category (Vulnerability/Maintenance/Security/
  Community/Stability) model that does not exist in the code.
- Swept remaining `CCDA`/`ccda` references and broken cross-document links
  out of the docs (`api-integrations.md`, `commands.md`, `getting-started.md`,
  `github-token-setup.md`, `serpapi-setup.md`, `API_MIGRATION_GUIDE.md`).
- Trimmed the README so the PyPI project page stays compact:
  removed the standalone Documentation/Contributing/Authors sections, fixed
  every relative `docs/*.md` link to use absolute `github.com/SemClone/suphm`
  URLs (relative links 404 on pypi.org).

### Added

- `oscarvalenzuelab <oscar.valenzuela.b@gmail.com>` listed as an author in
  `pyproject.toml` alongside SEMCL.

## [0.3.0] - 2026-04-29

### Changed (BREAKING)

- **Project renamed** from `ccda-cli` to `suphm` (Supply Chain Health Metrics).
  The repo also moved from `SemClone/ccda-cli` to `SemClone/suphm`.
- Python package: `ccda_cli` → `suphm`. All imports change.
  ```python
  # before
  from ccda_cli.metrics.git import GitMetricsAnalyzer
  # after
  from suphm.metrics.git import GitMetricsAnalyzer
  ```
- CLI entry point: `ccda-cli` → `suphm`. Update any scripts.
- Distribution name on PyPI: `ccda-cli` → `suphm` (new package; the old one
  will not be updated further).
- Cache directory: `~/.ccda/` → `~/.suphm/`. Existing caches are not migrated;
  delete the old directory or copy contents over manually.
- Project config file: `./ccda-config.yaml` → `./suphm-config.yaml`.
- Environment variables:
  - `CCDA_GITHUB_TOKEN` → `SUPHM_GITHUB_TOKEN`
  - `CCDA_SERPAPI_KEY` → `SUPHM_SERPAPI_KEY`
  - `CCDA_CACHE_DIR` → `SUPHM_CACHE_DIR`
  - `GITHUB_TOKEN` continues to work as a fallback.
- Repo-clone metadata file in cache: `.ccda-metadata.json` → `.suphm-metadata.json`.
  Repos cloned by older versions will be re-cloned on first use.

## [0.2.2] - 2026-01-14

### Fixed

- **Critical**: Fixed malformed GitHub URLs with `git+` prefix causing clone failures
  - Discovery stage now properly normalizes GitHub URLs by stripping `git+` prefix
  - Removes `.git` suffix and trailing paths (`/issues`, `/pulls`, `/wiki`, etc.)
  - Replaces `git://` protocol with `https://`
  - Affects all npm packages and potentially other ecosystems
  - Missing metrics restored: Bus Factor, Pony Factor, Elephant Factor, Commit Activity, Contributor Retention, License Stability
  - Now collecting all 10 health metrics instead of only 4 for affected packages
  - Added `_normalize_github_url()` helper function in `discovery/resolver.py`
  - Applied normalization to all repository URL assignments across all discovery sources

## [0.2.1] - 2026-01-13

### Fixed

- **Critical**: Fixed pkg:github package analysis failure with 'ecosystem' parameter error
  - Fixed `_github_discovery_step` in `pipeline.py` passing invalid parameters to `DiscoveryResult`
  - Removed non-existent `ecosystem` parameter
  - Changed `github_url` to correct `repository_url` parameter
  - Removed non-existent `success` parameter
  - Changed `metadata` to correct `registry_data` parameter
  - Added required `version` parameter
  - GitHub packages like `pkg:github/hashicorp/terraform` now analyze successfully

## [0.2.0] - 2026-01-13

### Added

- **Phase 4 Metric A.6: Review Turnaround Time**
  - New `avg_review_turnaround_hours` metric in pull request data
  - New `median_review_turnaround_hours` metric in pull request data
  - Track `prs_with_reviews` and `prs_without_reviews` counts
  - Samples up to 50 recent PRs to calculate time from PR creation to first review
  - Handles APPROVED, CHANGES_REQUESTED, and COMMENTED review states

- **Phase 4 Metric A.8: New Contributor Rate**
  - New `new_contributors_count` metric in time window data (90d, 180d, 365d)
  - New `new_contributors_per_month` metric showing monthly rate
  - New `contributor_growth_rate` showing percentage of contributors who are new
  - Tracks contributors whose first commit falls within each time window

### Changed

- Enhanced `PullRequestMetrics` dataclass with review turnaround fields
- Added `get_pull_reviews()` method to `GitHubClient` for fetching PR reviews
- Enhanced `TimeWindowMetrics` dataclass with new contributor rate fields

## [0.1.10] - 2026-01-12

### Fixed

- **Critical**: Fixed golang package GitHub metrics discovery
  - Fixed `depsdev_ecosystem` property to handle "golang" vs "go" type mismatch
  - Fixed `_discover_from_depsdev` to support both "go" and "golang" types
  - Golang packages now correctly infer GitHub URL from package namespace
  - Example: `pkg:golang/github.com/gin-gonic/gin` now discovers `https://github.com/gin-gonic/gin`
  - Root cause: packageurl library returns `type="golang"` but code only checked for `"go"`

## [0.1.9] - 2026-01-12

### Changed

- Version bump to publish GitHub PURL support to PyPI
- No code changes from 0.1.8 (which included the GitHub PURL feature but was not published with it)

## [0.1.8] - 2026-01-12

### Added

- **Native pkg:github/* PURL support** for direct GitHub package analysis
  - Early PURL detection in `AnalysisPipeline.analyze()` to identify GitHub packages
  - New `_analyze_github_package()` method for specialized GitHub package analysis
  - New `_github_discovery_step()` helper for minimal discovery without external API calls
  - Direct GitHub API access for metrics collection (no tarball download required)
  - Simplified 3-step pipeline for GitHub packages: Discovery → GitHub Metrics → Health Score

### Changed

- GitHub packages now skip package registry discovery (not needed for pkg:github/*)
- GitHub packages no longer require tarball download or git cloning
- Analysis time for GitHub packages reduced from ~80s to ~10s

### Fixed

- Analysis failures for GitHub PURLs like `pkg:github/hashicorp/terraform` and `pkg:github/actions/checkout`
- Unnecessary package registry lookups for GitHub-native packages

## [0.1.7] - 2026-01-05

### Fixed

- **Critical**: Fixed company affiliation enrichment silently failing
  - Company enrichment was not working due to async/await execution context issue
  - `_enrich_contributors()` was calling async code from within an executor thread
  - Added proper event loop detection and thread-safe async execution
  - Now correctly handles both standalone and executor-based execution contexts
  - Company data now properly populates in metrics output

## [0.1.6] - 2026-01-05

### Added

- **Company affiliation enrichment** via GitHub API (optional, requires GitHub token)
  - Automatically enriches contributor data with company information from GitHub user profiles
  - Extracts GitHub usernames from commit emails (e.g., `username@users.noreply.github.com`)
  - Fetches user profiles from GitHub API in batch to minimize API calls
  - Caches user profiles for 30 days to avoid duplicate requests
  - Normalizes company names using configurable mappings (e.g., "@google" → "Google")
  - Respects GitHub API rate limits and degrades gracefully
  - Falls back to email domain detection when API unavailable or rate limited
  - Provides more accurate elephant factor and company distribution metrics
- New `CompanyEnricher` class in `ccda_cli.enrichment.company` module
- Configuration option `github.enrich_company_affiliation` (default: true when token provided)
- Comprehensive test suite for company enrichment (16 unit tests)
- Enhanced documentation in `docs/github-token-setup.md` with company enrichment examples

### Changed

- `GitMetricsAnalyzer` now accepts optional `github_token` parameter for enrichment
- Company detection now prioritizes GitHub API data over email domain mapping (when token available)
- Updated README.md to highlight company affiliation enrichment feature

## [0.1.5] - 2026-01-05

### Added

- **osslili as required dependency** for professional license detection
  - Replaced brittle pattern-matching with osslili's Python API
  - Accurate SPDX license identification with confidence scores
  - Copyright statement extraction
  - Support for all osslili detection methods (metadata, file analysis, keyword matching)

### Fixed

- **Critical**: Cargo package tarball scanning now works correctly
  - Fixed `.crate` file download from crates.io (was downloading as `download` with no extension)
  - Added `.crate` extension support to archive extraction
  - Enhanced download URL detection to handle redirects properly (checks Content-Disposition header and final redirect URL)
- License file detection now works for all ecosystems
  - Removed incomplete `LICENSE_PATTERNS` that missed common patterns like `LICENSE-MIT`, `LICENSE-APACHE`
  - Now uses osslili for comprehensive license file discovery
- Relative path display in scan results (shows `serde-1.0.228/LICENSE-MIT` instead of full temp paths)

### Changed

- **Breaking**: osslili is now a required dependency (previously optional)
- **Breaking**: purl2src is now a required dependency (previously optional)
- Removed optional dependency groups `scanner` and `all`
- Tarball scanner completely refactored to use osslili Python API
  - Deleted 200+ lines of brittle pattern-matching code
  - Removed fallback license detection methods
  - Scan method now always reports `osslili`
- Cleaned up unused code and imports from tarball scanner

### Removed

- Removed obsolete methods: `_check_tool`, `_resolve_command`, `_build_command`, `_run_external_tool`, `_run_osslili`, `_run_upmex`, `_apply_osslili_results`, `_apply_upmex_results`, `_analyze_license_file`
- Removed `LICENSE_PATTERNS` and `COPYRIGHT_PATTERNS` constants
- Removed support for external tool command-line integration (now uses Python APIs directly)

## [0.1.4] - 2026-01-04

### Added

- **purl2src integration** for automatic download URL discovery
  - Integrated purl2src library as optional dependency
  - Tarball scanner now auto-discovers download URLs from PURLs
  - Fallback to PackageResolver if purl2src unavailable
  - New optional dependency group: `scanner` and `all`
- Crates.io (Rust Cargo) package discovery integration
  - Full metadata extraction from crates.io API
  - Registry data snapshot including downloads, keywords, and categories
  - Tarball URL resolution for package scanning
- Enhanced tarball scanner with external tool integration support
  - Support for osslili and upmex external scanning tools
  - Dynamic scan method tracking (builtin, osslili, upmex, or combined)
  - Improved license detection and binary file analysis

### Fixed

- Test suite compatibility with Python 3.14
- Virtual environment setup and package installation workflow

## [0.1.3] - 2026-01-04

### Added

- Dynamic API sampling based on GitHub token authentication status
  - Authenticated (5000 calls/hr): Fetches up to 5000 issues, 5000 PRs, 2000 closed issues
  - Unauthenticated (60 calls/hr): Conservative limits of 300 items per category
- Sampling metadata in JSON output for transparency
  - `_sampling` field in `IssueMetrics` showing sample size vs total count
  - `_sampling` field in `PullRequestMetrics` with coverage information
  - Coverage percentage indicator for quality assessment

### Fixed

- **Critical**: Metrics severely underreported due to hard-coded 300-item limit regardless of token
  - Issue sample size increased from 300 to 5000 when authenticated (16x improvement)
  - PR sample size increased from 300 to 5000 when authenticated (16x improvement)
  - Unlabeled rate now calculated from proper sample size
  - Unresponded rate now reflects larger sample for better accuracy
- Burnout score `issue_backlog` now uses adjusted full count instead of sampled count
- PR counts (open/merged/closed) now reflect comprehensive data instead of first 300 items

### Changed

- `IssueMetrics` dataclass now includes `sampled_open_count` and `sampled_closed_count` fields
- `PullRequestMetrics` dataclass now includes `sampled_count` field
- GitHub API collector now adapts page limits based on token availability

## [0.1.2] - 2026-01-04

### Fixed

- Use actual `open_issues_count` from GitHub repo API instead of sampled count (max 300)
- Subtract open PRs from issue count for accurate totals
- Fixes incorrect burnout score `issue_backlog` calculation

## [0.1.1] - 2026-01-04

### Added

- `chaoss_metrics` field to `HealthScoreResult` containing bus_factor, pony_factor, elephant_factor, and contributor_count
- `extended_metrics` field to `HealthScoreResult` containing commit_frequency, commits_per_day, pr_velocity, median_pr_merge_hours, branch_protected, and has_signed_releases
- Helper methods `_classify_frequency()` and `_classify_velocity()` for categorizing activity levels

### Fixed

- Dashboard template compatibility by exposing CHAOSS and extended metrics in health score output (#1)

## [0.1.0] - 2026-01-03

### Initial Release

First public release of ccda-cli - Supply Chain Security Metrics tool.

### Features

- Multi-ecosystem package analysis (npm, PyPI, Cargo, Maven, Go)
- Health score calculation (0-100) based on commit activity, contributor diversity, and community health
- Burnout score detection for maintainer sustainability risk assessment
- CHAOSS metrics computation (bus factor, pony factor, elephant factor)
- GitHub API integration for community health indicators (stars, forks, issues, PRs)
- Package tarball scanning for license compliance and binary detection
- Multiple discovery sources (deps.dev, ecosyste.ms, package registries, SerpAPI fallback)
- CLI commands: analyze, discover, cache management
- JSON output format for integration with other tools
- Comprehensive documentation and usage examples

### Documentation

- Complete README with installation and usage instructions
- Contribution guidelines (CONTRIBUTING.md)
- Code of Conduct (CODE_OF_CONDUCT.md)
- Authors and credits (AUTHORS.md)
- Detailed documentation for API integrations and configuration

### License

GNU Affero General Public License v3.0
