"""Tarball scanning for licenses, copyrights, and binaries.

Uses osslili for license and copyright detection.
"""

from __future__ import annotations

import logging
import mimetypes
import os
import sys
import tarfile
import tempfile
import zipfile
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import httpx

from suphm.discovery.purl import PURLParser

log = logging.getLogger(__name__)

# Hard caps to prevent OOM and decompression bombs.
# Tarballs that exceed these are rejected rather than truncated; package
# registries do not legitimately ship single archives near these sizes.
MAX_DOWNLOAD_BYTES = 500 * 1024 * 1024  # 500 MiB on the wire
MAX_EXTRACTED_BYTES = 2 * 1024 * 1024 * 1024  # 2 GiB after extraction
MAX_ARCHIVE_MEMBERS = 200_000


class UnsafeArchiveError(Exception):
    """Raised when an archive contains members that would escape the extraction root,
    contains unsafe link targets, or exceeds size/count caps."""


def _sanitize_download_filename(raw: str | None, fallback: str = "package.tar.gz") -> str:
    """Return a safe leaf filename for a downloaded artifact.

    Strips any path components, rejects parent-traversal, null bytes, and
    empty/dot-only names. The Content-Disposition header is attacker-controlled
    when downloading from arbitrary registries, so we never trust it as a path.
    """
    if not raw:
        return fallback
    # Drop everything except the leaf name on either separator.
    leaf = os.path.basename(raw.replace("\\", "/"))
    if not leaf or leaf in (".", "..") or "\x00" in leaf:
        return fallback
    return leaf


def _is_within(child: Path, parent: Path) -> bool:
    """True if `child` resolves inside `parent` (or equals it)."""
    try:
        child.relative_to(parent)
        return True
    except ValueError:
        return False


def _safe_extract_zip(archive_path: Path, dest_dir: Path) -> None:
    """Extract a zip archive, refusing path traversal and oversized payloads."""
    dest_resolved = dest_dir.resolve()
    with zipfile.ZipFile(archive_path) as zf:
        infos = zf.infolist()
        if len(infos) > MAX_ARCHIVE_MEMBERS:
            raise UnsafeArchiveError(
                f"zip has {len(infos)} members (cap {MAX_ARCHIVE_MEMBERS})"
            )
        total = 0
        for info in infos:
            name = info.filename
            # Absolute paths and parent traversal are not safe in extractall.
            if name.startswith("/") or name.startswith("\\"):
                raise UnsafeArchiveError(f"absolute path in zip: {name!r}")
            target = (dest_resolved / name).resolve()
            if not _is_within(target, dest_resolved):
                raise UnsafeArchiveError(f"zip member escapes root: {name!r}")
            total += info.file_size
            if total > MAX_EXTRACTED_BYTES:
                raise UnsafeArchiveError(
                    f"zip extracted size exceeds cap ({MAX_EXTRACTED_BYTES} bytes)"
                )
        zf.extractall(dest_resolved)


def _safe_extract_tar(archive_path: Path, dest_dir: Path) -> None:
    """Extract a tar archive, refusing path traversal, unsafe links, devices,
    and oversized payloads. Uses tarfile's data filter on Python 3.12+ as a
    second layer of defence."""
    dest_resolved = dest_dir.resolve()
    with tarfile.open(archive_path) as tf:
        safe_members: list[tarfile.TarInfo] = []
        total = 0
        member_count = 0
        for m in tf.getmembers():
            member_count += 1
            if member_count > MAX_ARCHIVE_MEMBERS:
                raise UnsafeArchiveError(
                    f"tar has more than {MAX_ARCHIVE_MEMBERS} members"
                )
            if m.isdev():
                # Skip block/char/fifo entries; package archives never need them.
                continue
            if m.name.startswith("/") or m.name.startswith("\\"):
                raise UnsafeArchiveError(f"absolute path in tar: {m.name!r}")
            target = (dest_resolved / m.name).resolve()
            if not _is_within(target, dest_resolved):
                raise UnsafeArchiveError(f"tar member escapes root: {m.name!r}")
            if m.issym() or m.islnk():
                # Resolve link target relative to where the link will live.
                link_target = (target.parent / m.linkname).resolve()
                if not _is_within(link_target, dest_resolved):
                    raise UnsafeArchiveError(
                        f"tar link target escapes root: {m.name!r} -> {m.linkname!r}"
                    )
            total += m.size
            if total > MAX_EXTRACTED_BYTES:
                raise UnsafeArchiveError(
                    f"tar extracted size exceeds cap ({MAX_EXTRACTED_BYTES} bytes)"
                )
            safe_members.append(m)
        if sys.version_info >= (3, 12):
            tf.extractall(dest_resolved, members=safe_members, filter="data")
        else:
            tf.extractall(dest_resolved, members=safe_members)


@dataclass
class LicenseFile:
    """Detected license file."""

    path: str
    spdx_id: str | None = None
    confidence: float = 0.0
    content_hash: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "path": self.path,
            "spdx_id": self.spdx_id,
            "confidence": round(self.confidence, 1),
        }


@dataclass
class BinaryFile:
    """Detected binary file."""

    path: str
    file_type: str
    size_bytes: int
    signature: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "path": self.path,
            "file_type": self.file_type,
            "size_bytes": self.size_bytes,
            "signature": self.signature,
        }


@dataclass
class PackageMetadata:
    """Package metadata from manifest files."""

    name: str | None = None
    version: str | None = None
    description: str | None = None
    license: str | None = None
    author: str | None = None
    homepage: str | None = None
    repository: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "name": self.name,
            "version": self.version,
            "description": self.description,
            "license": self.license,
            "author": self.author,
            "homepage": self.homepage,
            "repository": self.repository,
        }


@dataclass
class TarballScanResult:
    """Result of tarball scan."""

    purl: str
    tarball_url: str | None
    scanned_at: datetime
    ttl_days: int = 365  # Tarball scans never expire

    license_files: list[LicenseFile] = field(default_factory=list)
    copyrights: list[str] = field(default_factory=list)
    binaries: dict[str, Any] = field(default_factory=dict)
    package_metadata: PackageMetadata = field(default_factory=PackageMetadata)

    # Scan metadata
    file_count: int = 0
    total_size_bytes: int = 0
    scan_method: str = "basic"  # basic, osslili, binarysniffer

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "purl": self.purl,
            "tarball_url": self.tarball_url,
            "scanned_at": self.scanned_at.isoformat(),
            "ttl_days": self.ttl_days,
            "license_files": [f.to_dict() for f in self.license_files],
            "copyrights": self.copyrights,
            "binaries": {
                "found": bool(self.binaries.get("files")),
                "files": [f.to_dict() for f in self.binaries.get("files", [])],
                "signatures": self.binaries.get("signatures", []),
            },
            "package_metadata": self.package_metadata.to_dict(),
            "file_count": self.file_count,
            "total_size_bytes": self.total_size_bytes,
            "scan_method": self.scan_method,
        }


class TarballScanner:
    """Scans tarballs for licenses, copyrights, and binaries."""

    # Package manifest patterns
    MANIFEST_PATTERNS = {
        "npm": ["package.json"],
        "pypi": ["setup.py", "pyproject.toml", "PKG-INFO"],
        "maven": ["pom.xml"],
        "cargo": ["Cargo.toml"],
        "gem": ["*.gemspec"],
    }

    # Binary file signatures (magic bytes)
    BINARY_SIGNATURES = {
        b"\x7fELF": "ELF executable",
        b"MZ": "Windows executable",
        b"\xca\xfe\xba\xbe": "Mach-O binary",
        b"\xcf\xfa\xed\xfe": "Mach-O 64-bit binary",
        b"PK\x03\x04": "ZIP archive",
        b"\x1f\x8b": "gzip compressed",
    }

    def __init__(self):
        """Initialize scanner with required osslili dependency."""
        try:
            from osslili.core.generator import LicenseCopyrightDetector
            self._osslili_detector = LicenseCopyrightDetector()
        except ImportError as e:
            raise RuntimeError(
                "osslili is required for tarball scanning. "
                "Install with: pip install osslili"
            ) from e

    def _get_download_url_via_purl2src(self, purl: str) -> str | None:
        """Get download URL using purl2src library.

        Args:
            purl: Package URL

        Returns:
            Download URL if successful, None otherwise
        """
        try:
            from purl2src import get_download_url
        except ImportError:
            return None

        try:
            result = get_download_url(purl, validate=False)
            if result and result.download_url:
                url: str = result.download_url
                # purl2src falls back to the .git clone URL for some PURL types
                # (notably pkg:github/*). That is not a registry tarball and
                # tarfile.open will silently extract zero files from it.
                # Reject it here so the scan returns a clean empty result.
                if url.endswith(".git"):
                    return None
                return url
        except Exception as e:
            log.debug("purl2src failed for %s: %s", purl, e)

        return None

    async def scan_purl(self, purl: str) -> TarballScanResult:
        """Scan a package by PURL.

        Uses purl2src to discover the download URL, with fallback to
        PackageResolver for additional metadata discovery.

        pkg:github/* PURLs have no registry tarball by definition, so we
        short-circuit them upfront and return an empty result.

        Args:
            purl: Package URL

        Returns:
            TarballScanResult
        """
        try:
            parsed = PURLParser.parse(purl)
        except Exception:
            parsed = None
        if parsed is not None and parsed.type == "github":
            return TarballScanResult(
                purl=purl,
                tarball_url=None,
                scanned_at=datetime.now(),
            )

        # Try purl2src first for direct download URL discovery
        tarball_url = self._get_download_url_via_purl2src(purl)

        # Fallback to PackageResolver if purl2src fails
        if not tarball_url:
            from suphm.discovery import PackageResolver

            resolver = PackageResolver()
            discovery = await resolver.discover(purl)
            tarball_url = discovery.tarball_url

        if not tarball_url:
            return TarballScanResult(
                purl=purl,
                tarball_url=None,
                scanned_at=datetime.now(),
            )

        return await self.scan_url(purl, tarball_url)

    async def scan_url(self, purl: str, tarball_url: str) -> TarballScanResult:
        """Scan a tarball from URL.

        Args:
            purl: Package URL
            tarball_url: URL to the tarball

        Returns:
            TarballScanResult
        """
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir_path = Path(tmpdir)

            # Download tarball
            archive_path = await self._download_tarball(tarball_url, tmpdir_path)
            if not archive_path:
                return TarballScanResult(
                    purl=purl,
                    tarball_url=tarball_url,
                    scanned_at=datetime.now(),
                )

            # Extract
            extract_dir = tmpdir_path / "extracted"
            extract_dir.mkdir()
            try:
                self._extract_archive(archive_path, extract_dir)
            except UnsafeArchiveError as e:
                log.warning("rejected unsafe archive from %s: %s", tarball_url, e)
                return TarballScanResult(
                    purl=purl,
                    tarball_url=tarball_url,
                    scanned_at=datetime.now(),
                )

            # Scan
            return self._scan_directory(purl, tarball_url, extract_dir)

    def scan_local(self, purl: str, path: Path) -> TarballScanResult:
        """Scan a local tarball or directory.

        Args:
            purl: Package URL
            path: Path to tarball or directory

        Returns:
            TarballScanResult
        """
        path = Path(path)

        if path.is_dir():
            return self._scan_directory(purl, None, path)

        with tempfile.TemporaryDirectory() as tmpdir:
            extract_dir = Path(tmpdir) / "extracted"
            extract_dir.mkdir()
            try:
                self._extract_archive(path, extract_dir)
            except UnsafeArchiveError as e:
                log.warning("rejected unsafe local archive %s: %s", path, e)
                return TarballScanResult(
                    purl=purl,
                    tarball_url=str(path),
                    scanned_at=datetime.now(),
                )
            return self._scan_directory(purl, str(path), extract_dir)

    async def _download_tarball(self, url: str, dest_dir: Path) -> Path | None:
        """Stream a tarball to disk with a hard size cap and a sanitized filename.

        Returns None on network/protocol failure. The Content-Disposition header
        is attacker-controlled, so we always sanitize to a leaf name and verify
        the resulting path stays inside dest_dir.
        """
        dest_resolved = dest_dir.resolve()
        try:
            async with httpx.AsyncClient(follow_redirects=True, timeout=300) as client:
                async with client.stream("GET", url) as response:
                    response.raise_for_status()

                    # Pick a candidate filename, preferring registry-meaningful
                    # signals but falling back to a safe default.
                    candidate: str | None = None
                    content_disp = response.headers.get("content-disposition", "")
                    if "filename=" in content_disp:
                        candidate = content_disp.split("filename=", 1)[1].strip('"').strip("'")
                    if not candidate and response.url:
                        candidate = Path(str(response.url).split("?", 1)[0]).name
                    if not candidate or candidate == "download":
                        candidate = Path(urlparse(url).path).name

                    filename = _sanitize_download_filename(candidate)
                    dest_path = (dest_resolved / filename).resolve()
                    if not _is_within(dest_path, dest_resolved):
                        # Defensive: should be impossible after sanitisation.
                        raise UnsafeArchiveError(
                            f"download filename escapes dest: {filename!r}"
                        )

                    # Pre-flight check on Content-Length when the server provides it.
                    declared = response.headers.get("content-length")
                    if declared and declared.isdigit() and int(declared) > MAX_DOWNLOAD_BYTES:
                        raise UnsafeArchiveError(
                            f"declared download size {declared} exceeds cap {MAX_DOWNLOAD_BYTES}"
                        )

                    total = 0
                    with open(dest_path, "wb") as f:
                        async for chunk in response.aiter_bytes(chunk_size=64 * 1024):
                            total += len(chunk)
                            if total > MAX_DOWNLOAD_BYTES:
                                # Best-effort cleanup of the partial file.
                                f.close()
                                dest_path.unlink(missing_ok=True)
                                raise UnsafeArchiveError(
                                    f"download exceeded cap {MAX_DOWNLOAD_BYTES} bytes"
                                )
                            f.write(chunk)

                    return dest_path

        except UnsafeArchiveError as e:
            log.warning("rejected tarball %s: %s", url, e)
            return None
        except (httpx.HTTPError, OSError) as e:
            log.warning("tarball download failed for %s: %s", url, e)
            return None

    def _extract_archive(self, archive_path: Path, dest_dir: Path) -> None:
        """Extract archive to destination directory using path-validated extractors."""
        suffix = archive_path.suffix.lower()
        name = archive_path.name.lower()

        if suffix == ".zip" or name.endswith(".whl"):
            _safe_extract_zip(archive_path, dest_dir)
        elif suffix in (".gz", ".tgz", ".crate", ".tar", ".bz2", ".xz") or ".tar" in name:
            _safe_extract_tar(archive_path, dest_dir)

    def _scan_directory(
        self, purl: str, tarball_url: str | None, directory: Path
    ) -> TarballScanResult:
        """Scan extracted directory using osslili."""
        result = TarballScanResult(
            purl=purl,
            tarball_url=tarball_url,
            scanned_at=datetime.now(),
        )

        # Count files and total size
        all_files = list(directory.rglob("*"))
        for f in all_files:
            if f.is_file():
                result.file_count += 1
                result.total_size_bytes += f.stat().st_size

        # Scan for binaries
        binary_files = []
        for f in all_files:
            if f.is_file():
                binary_info = self._check_binary(f)
                if binary_info:
                    binary_files.append(binary_info)

        result.binaries = {
            "files": binary_files[:50],  # Limit
            "signatures": list(set(b.signature for b in binary_files if b.signature)),
        }

        # Use osslili to scan for licenses and copyrights
        osslili_result = self._osslili_detector.process_local_path(str(directory))

        # Convert osslili licenses to our format
        for lic in osslili_result.licenses:
            # Get relative path for cleaner display
            source_path = Path(lic.source_file).resolve()
            directory_resolved = directory.resolve()

            try:
                rel_path = source_path.relative_to(directory_resolved)
            except ValueError:
                # If we can't get relative path, just use the filename
                rel_path = Path(source_path.name)

            license_file = LicenseFile(
                path=str(rel_path),
                spdx_id=getattr(lic, 'spdx_id', None),
                confidence=getattr(lic, 'confidence', 0.0) * 100,  # Convert to percentage
            )
            result.license_files.append(license_file)

        # Convert osslili copyrights to our format
        for cr in osslili_result.copyrights:
            result.copyrights.append(getattr(cr, 'statement', str(cr)))

        result.copyrights = result.copyrights[:20]  # Limit

        # Parse package metadata
        parsed = PURLParser.parse(purl)
        pkg_type = parsed.type

        if pkg_type in self.MANIFEST_PATTERNS:
            for pattern in self.MANIFEST_PATTERNS[pkg_type]:
                for manifest in directory.rglob(pattern):
                    if manifest.is_file():
                        result.package_metadata = self._parse_manifest(manifest, pkg_type)
                        break

        result.scan_method = "osslili"

        return result

    def _check_binary(self, path: Path) -> BinaryFile | None:
        """Check if a file is a binary."""
        try:
            # Check by extension first
            suffix = path.suffix.lower()
            binary_extensions = {
                ".exe", ".dll", ".so", ".dylib", ".a", ".o",
                ".pyc", ".pyo", ".class", ".jar", ".war",
                ".wasm", ".node",
            }

            if suffix in binary_extensions:
                return BinaryFile(
                    path=str(path.name),
                    file_type=mimetypes.guess_type(path.name)[0] or "application/octet-stream",
                    size_bytes=path.stat().st_size,
                    signature=suffix,
                )

            # Check magic bytes
            with open(path, "rb") as f:
                header = f.read(8)

            for sig, file_type in self.BINARY_SIGNATURES.items():
                if header.startswith(sig):
                    return BinaryFile(
                        path=str(path.name),
                        file_type=file_type,
                        size_bytes=path.stat().st_size,
                        signature=sig.hex(),
                    )

        except Exception:
            pass

        return None

    def _parse_manifest(self, path: Path, pkg_type: str) -> PackageMetadata:
        """Parse package manifest file."""
        metadata = PackageMetadata()

        try:
            content = path.read_text(errors="ignore")

            if pkg_type == "npm" and path.name == "package.json":
                import json
                data = json.loads(content)
                metadata.name = data.get("name")
                metadata.version = data.get("version")
                metadata.description = data.get("description")
                metadata.license = data.get("license")
                metadata.author = data.get("author") if isinstance(data.get("author"), str) else None
                metadata.homepage = data.get("homepage")
                repo = data.get("repository")
                if isinstance(repo, dict):
                    metadata.repository = repo.get("url")
                elif isinstance(repo, str):
                    metadata.repository = repo

            elif pkg_type == "pypi" and path.name == "pyproject.toml":
                # Basic TOML parsing
                for line in content.split("\n"):
                    if line.startswith("name"):
                        metadata.name = line.split("=")[1].strip().strip('"\'')
                    elif line.startswith("version"):
                        metadata.version = line.split("=")[1].strip().strip('"\'')
                    elif line.startswith("description"):
                        metadata.description = line.split("=")[1].strip().strip('"\'')

            elif pkg_type == "cargo" and path.name == "Cargo.toml":
                for line in content.split("\n"):
                    if line.startswith("name"):
                        metadata.name = line.split("=")[1].strip().strip('"\'')
                    elif line.startswith("version"):
                        metadata.version = line.split("=")[1].strip().strip('"\'')
                    elif line.startswith("license"):
                        metadata.license = line.split("=")[1].strip().strip('"\'')

        except Exception:
            pass

        return metadata
