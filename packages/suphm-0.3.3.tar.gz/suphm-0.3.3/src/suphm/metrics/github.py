"""GitHub API metrics collection.

Fetches metrics that cannot be extracted from git alone:
- Issues (open/closed, response times, labels)
- Pull requests (merge times, review activity)
- Releases (frequency, signatures)
- Branch protection status
- Repository metadata (stars, forks)
"""

from __future__ import annotations

import logging
import re
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from statistics import mean, median
from typing import Any

from suphm.config import get_config
from suphm.core.http import GitHubClient, HTTPError, RateLimitError, RateLimitInfo

log = logging.getLogger(__name__)


@dataclass
class RepositoryMetrics:
    """Basic repository metadata."""

    stars: int = 0
    forks: int = 0
    watchers: int = 0
    created_at: datetime | None = None
    updated_at: datetime | None = None
    pushed_at: datetime | None = None
    default_branch: str = "main"
    license: str | None = None
    topics: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "stars": self.stars,
            "forks": self.forks,
            "watchers": self.watchers,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "pushed_at": self.pushed_at.isoformat() if self.pushed_at else None,
            "default_branch": self.default_branch,
            "license": self.license,
            "topics": self.topics,
        }


@dataclass
class IssueMetrics:
    """Issue-related metrics."""

    open_count: int = 0
    closed_count: int = 0
    unresponded_rate_7d: float = 0.0
    unlabeled_rate: float = 0.0
    avg_close_days: float = 0.0
    median_close_days: float = 0.0
    issue_backlog_score: int = 0

    # Sampling metadata
    sampled_open_count: int = 0
    sampled_closed_count: int = 0

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        result: dict[str, Any] = {
            "open_count": self.open_count,
            "closed_count": self.closed_count,
            "unresponded_rate_7d": round(self.unresponded_rate_7d, 1),
            "unlabeled_rate": round(self.unlabeled_rate, 1),
            "avg_close_days": round(self.avg_close_days, 1),
            "median_close_days": round(self.median_close_days, 1),
            "issue_backlog_score": self.issue_backlog_score,
        }

        # Add sampling info if rates were calculated from samples
        if self.sampled_open_count > 0 and self.sampled_open_count < self.open_count:
            result["_sampling"] = {
                "open_sample_size": self.sampled_open_count,
                "open_total": self.open_count,
                "coverage_pct": round((self.sampled_open_count / self.open_count) * 100, 1) if self.open_count > 0 else 100,
                "note": "Percentage metrics (unresponded_rate, unlabeled_rate) are based on sample"
            }

        return result


@dataclass
class PullRequestMetrics:
    """Pull request metrics."""

    open_count: int = 0
    merged_count: int = 0
    closed_count: int = 0
    avg_merge_hours: float = 0.0
    median_merge_hours: float = 0.0
    avg_review_comments: float = 0.0

    # A.6 Review Turnaround Time metrics
    avg_review_turnaround_hours: float = 0.0
    median_review_turnaround_hours: float = 0.0
    prs_with_reviews: int = 0
    prs_without_reviews: int = 0

    # Sampling metadata
    sampled_count: int = 0

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        result: dict[str, Any] = {
            "open_count": self.open_count,
            "merged_count": self.merged_count,
            "closed_count": self.closed_count,
            "avg_merge_hours": round(self.avg_merge_hours, 1),
            "median_merge_hours": round(self.median_merge_hours, 1),
            "avg_review_comments": round(self.avg_review_comments, 1),
            "avg_review_turnaround_hours": round(self.avg_review_turnaround_hours, 1),
            "median_review_turnaround_hours": round(self.median_review_turnaround_hours, 1),
            "prs_with_reviews": self.prs_with_reviews,
            "prs_without_reviews": self.prs_without_reviews,
        }

        # Add sampling info if we didn't fetch all PRs
        total_prs = self.open_count + self.merged_count + self.closed_count
        if self.sampled_count > 0 and self.sampled_count >= total_prs:
            result["_sampling"] = {
                "sample_size": self.sampled_count,
                "note": "Counts and metrics based on most recent PRs up to sample size"
            }

        return result


@dataclass
class ReleaseMetrics:
    """Release-related metrics."""

    total_count: int = 0
    has_signed_releases: bool = False
    latest_release: dict[str, Any] | None = None
    release_frequency_days: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "total_count": self.total_count,
            "has_signed_releases": self.has_signed_releases,
            "latest_release": self.latest_release,
            "release_frequency_days": round(self.release_frequency_days, 1),
        }


@dataclass
class BranchProtection:
    """Branch protection status."""

    default_branch_protected: bool = False
    requires_pr_reviews: bool = False
    requires_status_checks: bool = False
    requires_signatures: bool = False
    enforces_admins: bool = False

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "default_branch_protected": self.default_branch_protected,
            "requires_pr_reviews": self.requires_pr_reviews,
            "requires_status_checks": self.requires_status_checks,
            "requires_signatures": self.requires_signatures,
            "enforces_admins": self.enforces_admins,
        }


@dataclass
class GitHubMetricsResult:
    """Complete GitHub API metrics result."""

    repo_url: str
    fetched_at: datetime
    method: str = "github_api"
    ttl_hours: int = 6
    api_calls_used: int = 0
    rate_limit: RateLimitInfo | None = None

    repository: RepositoryMetrics = field(default_factory=RepositoryMetrics)
    issues: IssueMetrics = field(default_factory=IssueMetrics)
    pull_requests: PullRequestMetrics = field(default_factory=PullRequestMetrics)
    releases: ReleaseMetrics = field(default_factory=ReleaseMetrics)
    branch_protection: BranchProtection = field(default_factory=BranchProtection)

    # Internal: GitHub's open_issues_count includes PRs. We capture the
    # repo-API count here and adjust it down by the number of open PRs after
    # the PR collector runs. Not surfaced in to_dict.
    _repo_open_issues_count: int = 0

    # Per-collector outcome. Lets consumers tell "all data was collected" from
    # "issues failed silently because GitHub rate-limited us mid-run". Keys are
    # collector names (repository, issues, pull_requests, releases,
    # branch_protection); values are one of:
    #   "ok"                  - completed successfully
    #   "skipped_rate_limit"  - pre-flight rate-limit budget too low
    #   "rate_limited"        - hit RateLimitError mid-collection
    #   "http_error:<code>"   - non-success response that wasn't a rate limit
    #   "error"               - unexpected exception (see logs)
    collector_status: dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "repo_url": self.repo_url,
            "fetched_at": self.fetched_at.isoformat(),
            "method": self.method,
            "ttl_hours": self.ttl_hours,
            "api_calls_used": self.api_calls_used,
            "rate_limit": {
                "remaining": self.rate_limit.remaining if self.rate_limit else 0,
                "limit": self.rate_limit.limit if self.rate_limit else 0,
                "reset_at": (
                    self.rate_limit.reset_at.isoformat()
                    if self.rate_limit and self.rate_limit.reset_at
                    else None
                ),
            },
            "repository": self.repository.to_dict(),
            "issues": self.issues.to_dict(),
            "pull_requests": self.pull_requests.to_dict(),
            "releases": self.releases.to_dict(),
            "branch_protection": self.branch_protection.to_dict(),
            "collector_status": dict(self.collector_status),
        }


class GitHubMetricsCollector:
    """Collects metrics from GitHub API."""

    def __init__(self, token: str | None = None):
        """Initialize collector with optional token.

        Args:
            token: GitHub API token (uses config if not provided)
        """
        config = get_config()
        self.token = token or config.github_token
        self.client = GitHubClient(token=self.token)
        self._api_calls = 0

        # Adjust sampling based on authentication
        # Authenticated: 5000 calls/hr - can fetch more data
        # Unauthenticated: 60 calls/hr - must be conservative
        if self.token:
            self.max_issue_pages = 50  # Up to 5000 issues
            self.max_closed_issue_pages = 20  # Up to 2000 closed issues
            self.max_pr_pages = 50  # Up to 5000 PRs
            self.max_release_pages = 10  # Up to 1000 releases
        else:
            self.max_issue_pages = 3  # Up to 300 issues
            self.max_closed_issue_pages = 2  # Up to 200 closed issues
            self.max_pr_pages = 3  # Up to 300 PRs
            self.max_release_pages = 2  # Up to 200 releases

    async def collect(self, repo_url: str) -> GitHubMetricsResult:
        """Collect all GitHub metrics for a repository.

        Each collector is wrapped with status tracking so a single failed
        endpoint (rate limit, 5xx, network blip) leaves the rest of the
        result intact and tags the failure mode in
        ``result.collector_status`` instead of silently zero-ing out.
        """
        owner, repo = self._parse_repo_url(repo_url)

        result = GitHubMetricsResult(
            repo_url=repo_url,
            fetched_at=datetime.now(),
        )

        async with self.client.session():
            # min_calls is the lower bound below which the collector will
            # produce no usable data. We skip the collector entirely when the
            # remaining budget is under this number rather than burning calls
            # on a half-page of results that the scoring layer can't trust.
            await self._safe_run(result, "repository", 1,
                                 self._collect_repository_info, owner, repo, result)
            await self._safe_run(result, "issues", 2,
                                 self._collect_issue_metrics, owner, repo, result)
            await self._safe_run(result, "pull_requests", 2,
                                 self._collect_pr_metrics, owner, repo, result)
            await self._safe_run(result, "releases", 1,
                                 self._collect_release_metrics, owner, repo, result)
            await self._safe_run(result, "branch_protection", 1,
                                 self._collect_branch_protection, owner, repo, result)

            result.api_calls_used = self._api_calls
            result.rate_limit = self.client.rate_limit

        return result

    async def _safe_run(
        self,
        result: GitHubMetricsResult,
        name: str,
        min_calls: int,
        fn: Callable[..., Awaitable[None]],
        *args: Any,
    ) -> None:
        """Run a collector with status tracking and pre-flight rate-limit check.

        The collector implementations no longer wrap their bodies in
        ``except Exception: pass`` so their failures actually surface here.
        Anything they raise is logged and mapped to a status string; the
        analysis pipeline as a whole stays alive and produces a partial
        result rather than a crashed run.
        """
        remaining = self.client.rate_limit.remaining if self.client.rate_limit else None
        if remaining is not None and remaining < min_calls:
            result.collector_status[name] = "skipped_rate_limit"
            log.warning(
                "Skipping %s collector: rate-limit remaining=%s < min_calls=%s",
                name, remaining, min_calls,
            )
            return

        try:
            await fn(*args)
            result.collector_status[name] = "ok"
        except RateLimitError:
            result.collector_status[name] = "rate_limited"
            log.warning("%s collector hit rate limit", name)
        except HTTPError as e:
            code = getattr(e, "status_code", None) or "?"
            result.collector_status[name] = f"http_error:{code}"
            log.warning("%s collector failed with HTTP error: %s", name, e)
        except Exception:
            result.collector_status[name] = "error"
            log.exception("%s collector failed unexpectedly", name)

    def _parse_repo_url(self, url: str) -> tuple[str, str]:
        """Parse owner and repo from GitHub URL."""
        patterns = [
            r"github\.com/([^/]+)/([^/\.]+)",
            r"github\.com/([^/]+)/([^/]+)\.git",
        ]

        for pattern in patterns:
            match = re.search(pattern, url)
            if match:
                owner, repo = match.groups()
                return owner, repo

        raise ValueError(f"Could not parse GitHub URL: {url}")

    async def _collect_repository_info(
        self, owner: str, repo: str, result: GitHubMetricsResult
    ) -> None:
        """Collect basic repository information."""
        response = await self.client.get_repo(owner, repo)
        self._api_calls += 1

        if response.status_code != 200:
            raise HTTPError(
                f"GET /repos/{owner}/{repo} returned {response.status_code}",
                status_code=response.status_code,
            )

        data = response.data
        result.repository = RepositoryMetrics(
            stars=data.get("stargazers_count", 0),
            forks=data.get("forks_count", 0),
            watchers=data.get("subscribers_count", 0),
            created_at=self._parse_date(data.get("created_at")),
            updated_at=self._parse_date(data.get("updated_at")),
            pushed_at=self._parse_date(data.get("pushed_at")),
            default_branch=data.get("default_branch", "main"),
            license=(
                data.get("license", {}).get("spdx_id")
                if data.get("license")
                else None
            ),
            topics=data.get("topics", []),
        )
        # Store open_issues_count for later (includes PRs, but we'll adjust)
        result._repo_open_issues_count = data.get("open_issues_count", 0)

    async def _collect_issue_metrics(
        self, owner: str, repo: str, result: GitHubMetricsResult
    ) -> None:
        """Collect issue metrics."""
        now = datetime.now()
        seven_days_ago = now - timedelta(days=7)

        open_issues = []
        closed_issues = []
        close_times = []
        unresponded_count = 0
        unlabeled_count = 0

        # Get open issues (adaptive based on authentication)
        for page in range(1, self.max_issue_pages + 1):
            response = await self.client.get_issues(
                owner, repo, state="open", per_page=100, page=page
            )
            self._api_calls += 1

            if response.status_code != 200:
                break

            issues = [i for i in response.data if "pull_request" not in i]
            if not issues:
                break

            for issue in issues:
                open_issues.append(issue)

                # Check if unresponded (no comments, created > 7 days ago)
                created = self._parse_date(issue.get("created_at"))
                if created and created < seven_days_ago:
                    if issue.get("comments", 0) == 0:
                        unresponded_count += 1

                # Check if unlabeled
                if not issue.get("labels"):
                    unlabeled_count += 1

            if len(issues) < 100:
                break

        # Get closed issues (sample for response/close times)
        for page in range(1, self.max_closed_issue_pages + 1):
            response = await self.client.get_issues(
                owner, repo, state="closed", per_page=100, page=page
            )
            self._api_calls += 1

            if response.status_code != 200:
                break

            issues = [i for i in response.data if "pull_request" not in i]
            if not issues:
                break

            for issue in issues:
                closed_issues.append(issue)

                created = self._parse_date(issue.get("created_at"))
                closed = self._parse_date(issue.get("closed_at"))

                if created and closed:
                    close_time = (closed - created).total_seconds() / 86400  # days
                    close_times.append(close_time)

            if len(issues) < 100:
                break

        # Calculate metrics
        # Use actual count from repo API if available, otherwise use sampled count
        # Note: repo's open_issues_count includes PRs, we'll adjust after PR collection
        result.issues.open_count = result._repo_open_issues_count or len(open_issues)
        result.issues.closed_count = len(closed_issues)
        result.issues.sampled_open_count = len(open_issues)
        result.issues.sampled_closed_count = len(closed_issues)

        if open_issues:
            result.issues.unresponded_rate_7d = (
                unresponded_count / len(open_issues)
            ) * 100
            result.issues.unlabeled_rate = (
                unlabeled_count / len(open_issues)
            ) * 100

        if close_times:
            result.issues.avg_close_days = mean(close_times)
            result.issues.median_close_days = median(close_times)

        # Calculate backlog score using the repo API count if available
        # This will be adjusted after PR collection
        backlog_count = result._repo_open_issues_count or len(open_issues)
        result.issues.issue_backlog_score = self._calculate_backlog_score(
            backlog_count
        )

    async def _collect_pr_metrics(
        self, owner: str, repo: str, result: GitHubMetricsResult
    ) -> None:
        """Collect pull request metrics."""
        merge_times: list[float] = []
        review_turnaround_times: list[float] = []
        open_count = 0
        merged_count = 0
        closed_count = 0
        prs_with_reviews = 0
        prs_without_reviews = 0
        prs_to_check_for_reviews: list[dict[str, Any]] = []

        # Get PRs (adaptive based on authentication)
        for page in range(1, self.max_pr_pages + 1):
            response = await self.client.get_pulls(
                owner, repo, state="all", per_page=100, page=page
            )
            self._api_calls += 1

            if response.status_code != 200:
                break

            prs = response.data
            if not prs:
                break

            for pr in prs:
                state = pr.get("state")
                merged = pr.get("merged_at")

                if state == "open":
                    open_count += 1
                elif merged:
                    merged_count += 1
                    created = self._parse_date(pr.get("created_at"))
                    merged_at = self._parse_date(merged)
                    if created and merged_at:
                        hours = (merged_at - created).total_seconds() / 3600
                        merge_times.append(hours)
                else:
                    closed_count += 1

                # Collect PRs for review turnaround analysis (sample recent PRs)
                # Limit to 50 PRs to avoid excessive API calls
                if len(prs_to_check_for_reviews) < 50:
                    prs_to_check_for_reviews.append({
                        "number": pr.get("number"),
                        "created_at": pr.get("created_at")
                    })

            if len(prs) < 100:
                break

        result.pull_requests.open_count = open_count
        result.pull_requests.merged_count = merged_count
        result.pull_requests.closed_count = closed_count
        result.pull_requests.sampled_count = open_count + merged_count + closed_count

        # Adjust issue open_count: repo's open_issues_count includes PRs
        # Subtract open PRs to get actual issue count
        if result._repo_open_issues_count > 0:
            adjusted_issues = result._repo_open_issues_count - open_count
            if adjusted_issues > 0:
                result.issues.open_count = adjusted_issues
                # Also recalculate backlog score with adjusted count
                result.issues.issue_backlog_score = self._calculate_backlog_score(
                    adjusted_issues
                )

        if merge_times:
            result.pull_requests.avg_merge_hours = mean(merge_times)
            result.pull_requests.median_merge_hours = median(merge_times)

        # Calculate review turnaround time (A.6).
        # Per-PR review fetches still tolerate individual failures because one
        # bad PR shouldn't lose the whole review-turnaround sample, but a
        # rate-limit error is allowed to bubble up so the orchestrator can
        # tag the collector as rate_limited rather than producing garbage.
        for pr_info in prs_to_check_for_reviews:
            try:
                review_response = await self.client.get_pull_reviews(
                    owner, repo, pr_info["number"]
                )
                self._api_calls += 1
            except RateLimitError:
                raise
            except Exception as e:
                log.debug("review fetch failed for PR #%s: %s", pr_info["number"], e)
                continue

            if review_response.status_code == 200:
                reviews = review_response.data
                if reviews:
                    prs_with_reviews += 1
                    # Find first review (any state: APPROVED, CHANGES_REQUESTED, COMMENTED)
                    first_review = None
                    for review in reviews:
                        if review.get("submitted_at"):
                            first_review = review
                            break

                    if first_review:
                        pr_created = self._parse_date(pr_info["created_at"])
                        review_submitted = self._parse_date(first_review["submitted_at"])
                        if pr_created and review_submitted:
                            turnaround_hours = (review_submitted - pr_created).total_seconds() / 3600
                            if turnaround_hours >= 0:  # Sanity check
                                review_turnaround_times.append(turnaround_hours)
                else:
                    prs_without_reviews += 1

        result.pull_requests.prs_with_reviews = prs_with_reviews
        result.pull_requests.prs_without_reviews = prs_without_reviews

        if review_turnaround_times:
            result.pull_requests.avg_review_turnaround_hours = mean(review_turnaround_times)
            result.pull_requests.median_review_turnaround_hours = median(review_turnaround_times)

    async def _collect_release_metrics(
        self, owner: str, repo: str, result: GitHubMetricsResult
    ) -> None:
        """Collect release metrics."""
        releases = []
        has_signed = False

        for page in range(1, self.max_release_pages + 1):
            response = await self.client.get_releases(
                owner, repo, per_page=100, page=page
            )
            self._api_calls += 1

            if response.status_code != 200:
                break

            page_releases = response.data
            if not page_releases:
                break

            for release in page_releases:
                releases.append(release)

                # Check for signed assets
                assets = release.get("assets", [])
                for asset in assets:
                    name = asset.get("name", "").lower()
                    if ".sig" in name or ".asc" in name or "signature" in name:
                        has_signed = True
                        break

            if len(page_releases) < 100:
                break

        result.releases.total_count = len(releases)
        result.releases.has_signed_releases = has_signed

        if releases:
            latest = releases[0]
            result.releases.latest_release = {
                "tag": latest.get("tag_name"),
                "published_at": latest.get("published_at"),
                "prerelease": latest.get("prerelease", False),
            }

            # Calculate release frequency
            if len(releases) >= 2:
                dates = []
                for release in releases:
                    pub_date = self._parse_date(release.get("published_at"))
                    if pub_date:
                        dates.append(pub_date)

                if len(dates) >= 2:
                    dates.sort(reverse=True)
                    intervals = []
                    for i in range(len(dates) - 1):
                        interval = (dates[i] - dates[i + 1]).days
                        intervals.append(interval)
                    if intervals:
                        result.releases.release_frequency_days = mean(intervals)

    async def _collect_branch_protection(
        self, owner: str, repo: str, result: GitHubMetricsResult
    ) -> None:
        """Collect branch protection status.

        GitHub returns 404 when the default branch has no protection rules
        configured. The HTTP client raises HTTPError on any 4xx, so we have
        to catch that 404 here and translate it to "ok, not protected"
        rather than letting it surface as http_error:404. Other 4xx/5xx
        bubble up to ``_safe_run`` and get tagged as real errors.
        """
        default_branch = result.repository.default_branch

        try:
            response = await self.client.get_branch_protection(
                owner, repo, default_branch
            )
        except HTTPError as e:
            self._api_calls += 1
            if e.status_code == 404:
                result.branch_protection.default_branch_protected = False
                return
            raise
        self._api_calls += 1

        if response.status_code != 200:
            raise HTTPError(
                f"branch protection lookup returned {response.status_code}",
                status_code=response.status_code,
            )

        data = response.data
        result.branch_protection.default_branch_protected = True

        # Check PR reviews
        pr_reviews = data.get("required_pull_request_reviews", {})
        if pr_reviews:
            result.branch_protection.requires_pr_reviews = True

        # Check status checks
        status_checks = data.get("required_status_checks", {})
        if status_checks:
            result.branch_protection.requires_status_checks = True

        # Check signatures
        if data.get("required_signatures", {}).get("enabled"):
            result.branch_protection.requires_signatures = True

        # Check admin enforcement
        if data.get("enforce_admins", {}).get("enabled"):
            result.branch_protection.enforces_admins = True

    def _parse_date(self, date_str: str | None) -> datetime | None:
        """Parse ISO date string to datetime."""
        if not date_str:
            return None
        try:
            return datetime.fromisoformat(date_str.replace("Z", "+00:00")).replace(
                tzinfo=None
            )
        except ValueError:
            return None

    def _calculate_backlog_score(self, open_count: int) -> int:
        """Calculate issue backlog score (0-20 for burnout)."""
        if open_count <= 100:
            return 0
        elif open_count <= 500:
            return 5
        elif open_count <= 1000:
            return 10
        elif open_count <= 2500:
            return 15
        else:
            return 20
