"""Git-based metrics analysis.

Analyzes git history to extract:
- Bus factor: Minimum developers needed to lose 50%+ of commits
- Pony factor: Number of developers contributing 50% of commits (CHAOSS)
- Elephant factor: Number of companies contributing 50% of commits
- Contributor retention: Percentage of contributors remaining active
- Commit activity and velocity
- License change history
"""

from __future__ import annotations

import asyncio
import contextlib
import re
import subprocess
import tempfile
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from time import monotonic
from typing import Any

from suphm.config import get_config
from suphm.enrichment.company import CompanyEnricher


@dataclass
class ContributorStats:
    """Statistics for a single contributor."""

    email: str
    name: str
    commits: int = 0
    percentage: float = 0.0
    company: str = "Independent"
    first_commit: datetime | None = None
    last_commit: datetime | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ContributorStats:
        """Create from dictionary."""
        return cls(
            email=data.get("email", ""),
            name=data.get("name", ""),
            commits=data.get("commits", 0),
            percentage=data.get("percentage", 0.0),
            company=data.get("company", "Independent"),
        )


@dataclass
class CompanyStats:
    """Statistics for a company/organization."""

    company: str
    commits: int = 0
    percentage: float = 0.0
    contributors: int = 0

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CompanyStats:
        """Create from dictionary."""
        return cls(
            company=data.get("company", "Unknown"),
            commits=data.get("commits", 0),
            percentage=data.get("percentage", 0.0),
            contributors=data.get("contributors", 0),
        )


@dataclass
class LicenseChange:
    """Record of a license change."""

    commit_hash: str
    date: datetime
    old_license: str | None
    new_license: str
    author: str = ""

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> LicenseChange:
        """Create from dictionary."""
        date = data.get("date", "")
        if isinstance(date, str):
            date = datetime.fromisoformat(date.replace("Z", "+00:00")) if date else datetime.now()
        return cls(
            commit_hash=data.get("commit_hash", ""),
            date=date,
            old_license=data.get("old_license"),
            new_license=data.get("new_license", ""),
            author=data.get("author", ""),
        )


@dataclass
class TimeWindowMetrics:
    """Metrics for a specific time window."""

    start_date: datetime
    end_date: datetime
    total_commits: int = 0
    unique_contributors: int = 0
    bus_factor: int = 0
    pony_factor: int = 0
    elephant_factor: int = 0
    contributor_retention: float | None = None  # None == no prior window to compare
    commits_per_day: float = 0.0
    days_since_last_commit: float = 0.0

    # A.8 New Contributor Rate metrics
    new_contributors_count: int = 0
    new_contributors_per_month: float = 0.0
    contributor_growth_rate: float = 0.0

    top_contributors: list[ContributorStats] = field(default_factory=list)
    company_distribution: list[CompanyStats] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "start_date": self.start_date.isoformat(),
            "end_date": self.end_date.isoformat(),
            "total_commits": self.total_commits,
            "unique_contributors": self.unique_contributors,
            "bus_factor": self.bus_factor,
            "pony_factor": self.pony_factor,
            "elephant_factor": self.elephant_factor,
            "contributor_retention": self.contributor_retention,
            "commits_per_day": round(self.commits_per_day, 2),
            "days_since_last_commit": round(self.days_since_last_commit, 1),
            "new_contributors_count": self.new_contributors_count,
            "new_contributors_per_month": round(self.new_contributors_per_month, 2),
            "contributor_growth_rate": round(self.contributor_growth_rate, 3),
            "top_contributors": [
                {
                    "email": c.email,
                    "name": c.name,
                    "company": c.company,
                    "commits": c.commits,
                    "percentage": round(c.percentage, 2),
                }
                for c in self.top_contributors[:10]
            ],
            "company_distribution": [
                {
                    "company": c.company,
                    "commits": c.commits,
                    "percentage": round(c.percentage, 2),
                    "contributors": c.contributors,
                }
                for c in self.company_distribution
            ],
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TimeWindowMetrics:
        """Create from dictionary."""
        start = data.get("start_date", "")
        end = data.get("end_date", "")
        if isinstance(start, str):
            start = datetime.fromisoformat(start.replace("Z", "+00:00")) if start else datetime.now()
        if isinstance(end, str):
            end = datetime.fromisoformat(end.replace("Z", "+00:00")) if end else datetime.now()

        return cls(
            start_date=start,
            end_date=end,
            total_commits=data.get("total_commits", 0),
            unique_contributors=data.get("unique_contributors", 0),
            bus_factor=data.get("bus_factor", 0),
            pony_factor=data.get("pony_factor", 0),
            elephant_factor=data.get("elephant_factor", 0),
            contributor_retention=data.get("contributor_retention"),
            commits_per_day=data.get("commits_per_day", 0.0),
            days_since_last_commit=data.get("days_since_last_commit", 0.0),
            top_contributors=[
                ContributorStats.from_dict(c) for c in data.get("top_contributors", [])
            ],
            company_distribution=[
                CompanyStats.from_dict(c) for c in data.get("company_distribution", [])
            ],
        )


@dataclass
class LicenseHistory:
    """License change tracking."""

    license_file: str | None = None
    current_license: str | None = None
    change_count: int = 0
    changes: list[LicenseChange] = field(default_factory=list)
    risk_level: str = "low"

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "license_file": self.license_file,
            "current_license": self.current_license,
            "change_count": self.change_count,
            "changes": [
                {
                    "commit_hash": c.commit_hash,
                    "date": c.date.isoformat(),
                    "old_license": c.old_license,
                    "new_license": c.new_license,
                }
                for c in self.changes
            ],
            "risk_level": self.risk_level,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> LicenseHistory:
        """Create from dictionary."""
        return cls(
            license_file=data.get("license_file"),
            current_license=data.get("current_license"),
            change_count=data.get("change_count", 0),
            changes=[LicenseChange.from_dict(c) for c in data.get("changes", [])],
            risk_level=data.get("risk_level", "low"),
        )


@dataclass
class GitMetricsResult:
    """Complete git metrics analysis result."""

    repo_url: str
    clone_path: str
    analyzed_at: datetime
    method: str = "git_offline"
    ttl_hours: int = 24
    time_windows: dict[str, TimeWindowMetrics] = field(default_factory=dict)
    license_changes: LicenseHistory = field(default_factory=LicenseHistory)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "repo_url": self.repo_url,
            "analyzed_at": self.analyzed_at.isoformat(),
            "method": self.method,
            "clone_path": self.clone_path,
            "ttl_hours": self.ttl_hours,
            "time_windows": {k: v.to_dict() for k, v in self.time_windows.items()},
            "license_changes": self.license_changes.to_dict(),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> GitMetricsResult:
        """Create from dictionary."""
        analyzed = data.get("analyzed_at", "")
        if isinstance(analyzed, str):
            analyzed = datetime.fromisoformat(analyzed.replace("Z", "+00:00")) if analyzed else datetime.now()

        return cls(
            repo_url=data.get("repo_url", ""),
            clone_path=data.get("clone_path", ""),
            analyzed_at=analyzed,
            method=data.get("method", "git_offline"),
            ttl_hours=data.get("ttl_hours", 24),
            time_windows={
                k: TimeWindowMetrics.from_dict(v)
                for k, v in data.get("time_windows", {}).items()
            },
            license_changes=LicenseHistory.from_dict(data.get("license_changes", {})),
        )


class GitMetricsAnalyzer:
    """Analyzes git repositories for community health metrics."""

    # License file patterns
    LICENSE_FILES = [
        "LICENSE",
        "LICENSE.txt",
        "LICENSE.md",
        "LICENCE",
        "COPYING",
        "COPYING.txt",
    ]

    def __init__(self, repo_path: Path, github_token: str | None = None):
        """Initialize analyzer with repository path.

        Args:
            repo_path: Path to the git repository
            github_token: Optional GitHub token for company enrichment
        """
        self.repo_path = Path(repo_path)
        if not (self.repo_path / ".git").exists():
            raise ValueError(f"Not a git repository: {repo_path}")

        self.config = get_config()
        self._company_cache: dict[str, str] = {}
        self._enricher = CompanyEnricher(github_token=github_token or self.config.github_token)
        # Lazily initialised on first use; osslili construction is heavy
        # (loads the SPDX corpus and pattern tables) and most analyzer
        # instances never reach license detection.
        self._osslili_detector: Any = None

    def analyze(self, repo_url: str | None = None) -> GitMetricsResult:
        """Run full git metrics analysis.

        Args:
            repo_url: Optional repository URL for metadata

        Returns:
            GitMetricsResult with all metrics
        """
        now = datetime.now()

        # Get all commits
        commits = self._get_commits()

        if not commits:
            return GitMetricsResult(
                repo_url=repo_url or str(self.repo_path),
                clone_path=str(self.repo_path),
                analyzed_at=now,
            )

        # Enrich contributor data with GitHub company information
        self._enrich_contributors(commits)

        result = GitMetricsResult(
            repo_url=repo_url or self._get_remote_url() or str(self.repo_path),
            clone_path=str(self.repo_path),
            analyzed_at=now,
        )

        # Analyze time windows
        for window in self.config.analysis.time_windows:
            if window.days:
                start_date = now - timedelta(days=window.days)
            else:
                # All-time window: anchor start_date to the earliest commit so
                # commits_per_day divides by the project's actual lifetime.
                # Using datetime.min (year 1) here would inflate the divisor to
                # ~730K days and produce a near-zero rate for any real repo.
                start_date = min((c["date"] for c in commits), default=now)

            window_commits = [c for c in commits if c["date"] >= start_date]
            metrics = self._analyze_window(window_commits, start_date, now)

            # Calculate retention (compare current window to previous)
            if window.days:
                prev_start = start_date - timedelta(days=window.days)
                prev_commits = [
                    c for c in commits if prev_start <= c["date"] < start_date
                ]
                metrics.contributor_retention = self._calculate_retention(
                    prev_commits, window_commits
                )

            result.time_windows[window.name] = metrics

        # Analyze license changes
        result.license_changes = self._analyze_license_history()

        return result

    def _get_commits(self) -> list[dict[str, Any]]:
        """Get all commits from git log."""
        # Format: hash|author_email|author_name|date
        cmd = [
            "git",
            "log",
            "--format=%H|%ae|%an|%aI",
            "--no-merges",
        ]

        try:
            output = subprocess.run(
                cmd,
                cwd=self.repo_path,
                capture_output=True,
                text=True,
                timeout=60,
            )

            if output.returncode != 0:
                return []

            commits = []
            for line in output.stdout.strip().split("\n"):
                if not line:
                    continue
                parts = line.split("|", 3)
                if len(parts) >= 4:
                    try:
                        date = datetime.fromisoformat(parts[3].replace("Z", "+00:00"))
                        # Convert to naive datetime for comparison
                        date = date.replace(tzinfo=None)
                    except ValueError:
                        date = datetime.now()

                    commits.append(
                        {
                            "hash": parts[0],
                            "email": parts[1].lower(),
                            "name": parts[2],
                            "date": date,
                        }
                    )

            return commits

        except subprocess.TimeoutExpired:
            return []
        except Exception:
            return []

    def _analyze_window(
        self,
        commits: list[dict[str, Any]],
        start_date: datetime,
        end_date: datetime,
    ) -> TimeWindowMetrics:
        """Analyze commits within a time window."""
        metrics = TimeWindowMetrics(start_date=start_date, end_date=end_date)

        if not commits:
            return metrics

        metrics.total_commits = len(commits)

        # Group commits by contributor
        contributor_commits: dict[str, ContributorStats] = {}
        for commit in commits:
            email = commit["email"]
            if email not in contributor_commits:
                contributor_commits[email] = ContributorStats(
                    email=email,
                    name=commit["name"],
                    company=self._get_company(email),
                    first_commit=commit["date"],
                    last_commit=commit["date"],
                )
            stats = contributor_commits[email]
            stats.commits += 1
            if commit["date"] < stats.first_commit:
                stats.first_commit = commit["date"]
            if commit["date"] > stats.last_commit:
                stats.last_commit = commit["date"]

        metrics.unique_contributors = len(contributor_commits)

        # Calculate percentages
        for stats in contributor_commits.values():
            stats.percentage = (stats.commits / metrics.total_commits) * 100

        # Sort by commits descending
        sorted_contributors = sorted(
            contributor_commits.values(), key=lambda x: x.commits, reverse=True
        )
        metrics.top_contributors = sorted_contributors

        # Calculate bus factor (min developers to lose 50%+ commits)
        metrics.bus_factor = self._calculate_factor(sorted_contributors, 50)

        # Pony factor is same as bus factor in CHAOSS
        metrics.pony_factor = metrics.bus_factor

        # Calculate elephant factor (companies contributing 50%)
        company_commits: dict[str, CompanyStats] = {}
        for stats in sorted_contributors:
            company = stats.company
            if company not in company_commits:
                company_commits[company] = CompanyStats(company=company)
            company_commits[company].commits += stats.commits
            company_commits[company].contributors += 1

        for company_stats in company_commits.values():
            company_stats.percentage = (
                company_stats.commits / metrics.total_commits
            ) * 100

        sorted_companies = sorted(
            company_commits.values(), key=lambda x: x.commits, reverse=True
        )
        metrics.company_distribution = sorted_companies

        company_list = [
            ContributorStats(
                email="",
                name=c.company,
                commits=c.commits,
                percentage=c.percentage,
            )
            for c in sorted_companies
        ]
        metrics.elephant_factor = self._calculate_factor(company_list, 50)

        # Calculate activity metrics
        days = (end_date - start_date).days or 1
        metrics.commits_per_day = metrics.total_commits / days

        if commits:
            last_commit_date = max(c["date"] for c in commits)
            metrics.days_since_last_commit = (end_date - last_commit_date).days

        # Calculate new contributor rate (A.8)
        # Count contributors whose first commit is within the time window
        new_contributors = [
            stats for stats in sorted_contributors
            if stats.first_commit and start_date <= stats.first_commit <= end_date
        ]
        metrics.new_contributors_count = len(new_contributors)

        # Calculate per-month rate
        months = days / 30.0 if days > 0 else 1
        metrics.new_contributors_per_month = metrics.new_contributors_count / months

        # Calculate growth rate (percentage of total contributors who are new)
        if metrics.unique_contributors > 0:
            metrics.contributor_growth_rate = metrics.new_contributors_count / metrics.unique_contributors
        else:
            metrics.contributor_growth_rate = 0.0

        return metrics

    def _calculate_factor(
        self, sorted_items: list[ContributorStats], threshold: float
    ) -> int:
        """Calculate bus/pony/elephant factor.

        Returns the minimum number of items needed to reach threshold% of commits.
        """
        if not sorted_items:
            return 0

        total = sum(item.commits for item in sorted_items)
        if total == 0:
            return 0

        cumulative = 0
        count = 0

        for item in sorted_items:
            cumulative += item.commits
            count += 1
            if (cumulative / total) * 100 >= threshold:
                return count

        return count

    def _calculate_retention(
        self,
        prev_commits: list[dict[str, Any]],
        current_commits: list[dict[str, Any]],
    ) -> float | None:
        """Calculate contributor retention between time windows.

        Returns None when there is no prior window to compare against (e.g.
        a young repo with no commits older than the window). Returning 0.0
        in that case is misleading: it conflates "no prior data" with "all
        prior contributors left," and the scoring layer treats both as
        catastrophic.
        """
        if not prev_commits:
            return None

        prev_contributors = {c["email"] for c in prev_commits}
        current_contributors = {c["email"] for c in current_commits}

        if not prev_contributors:
            return None

        retained = prev_contributors & current_contributors
        return (len(retained) / len(prev_contributors)) * 100

    def _enrich_contributors(self, commits: list[dict[str, Any]]) -> None:
        """Enrich contributor data with GitHub company information.

        This method collects all unique contributors and enriches them
        in a batch operation to minimize API calls.

        Args:
            commits: List of commit dicts with email and name
        """
        if not self._enricher.is_enabled():
            return

        # Collect unique contributors
        contributors: dict[str, dict[str, Any]] = {}
        for commit in commits:
            email = commit["email"]
            if email not in contributors:
                contributors[email] = {
                    "name": commit["name"],
                    "company": "Independent",  # Default
                }

        # Run async enrichment
        try:
            # If a loop is already running (e.g. we're inside run_in_executor
            # from the analysis pipeline), asyncio.run would error - dispatch
            # to a fresh thread instead.
            try:
                asyncio.get_running_loop()
            except RuntimeError:
                asyncio.run(self._enricher.enrich_contributors(contributors))
            else:
                import concurrent.futures
                with concurrent.futures.ThreadPoolExecutor() as executor:
                    future = executor.submit(
                        asyncio.run,
                        self._enricher.enrich_contributors(contributors)
                    )
                    future.result()

            # Update cache with results
            for email, data in contributors.items():
                self._company_cache[email] = data["company"]

        except Exception:
            # If enrichment fails, fall back to email domain detection
            # This is already the default behavior in _get_company
            pass

    def _get_company(self, email: str) -> str:
        """Determine company affiliation.

        Uses enriched data from GitHub API if available, otherwise falls back
        to email domain mapping.

        Args:
            email: Contributor email

        Returns:
            Company name or "Independent"
        """
        if email in self._company_cache:
            return self._company_cache[email]

        # Use enricher to get company (will use cache or email domain)
        company = self._enricher.get_company(email)
        self._company_cache[email] = company
        return company

    def _get_remote_url(self) -> str | None:
        """Get the remote origin URL."""
        try:
            output = subprocess.run(
                ["git", "remote", "get-url", "origin"],
                cwd=self.repo_path,
                capture_output=True,
                text=True,
                timeout=10,
            )
            if output.returncode == 0:
                url = output.stdout.strip()
                # Convert SSH to HTTPS
                if url.startswith("git@"):
                    url = re.sub(r"git@([^:]+):", r"https://\1/", url)
                if url.endswith(".git"):
                    url = url[:-4]
                return url
        except Exception:
            pass
        return None

    # Maximum number of license-touching commits we'll inspect, and the
    # total wall-clock budget for all `git show` reads. Together these cap
    # the analysis on pathological histories (e.g. 1000+ LICENSE edits)
    # without making detection useless on normal projects.
    _LICENSE_HISTORY_COMMIT_CAP = 100
    _LICENSE_HISTORY_TIME_BUDGET_S = 30.0

    def _analyze_license_history(self) -> LicenseHistory:
        """Analyze license file changes in git history.

        Walks the most recent ``_LICENSE_HISTORY_COMMIT_CAP`` commits that
        touched the LICENSE file (oldest of those first), grabs the file
        contents at each via ``git show``, runs SPDX detection, and only
        records a LicenseChange when the detected id differs from the
        previous one. Cosmetic edits (copyright year bumps, formatting,
        whitespace) intentionally produce no entries.

        Limitations:
        - We do not use ``git log --follow``: pre-rename history would
          require resolving the file's path at each historical commit, and
          ``git show <sha>:<current_path>`` returns nothing for commits that
          predate the rename. Honest partial history is preferable to
          silently dropping pre-rename commits as null detections.
        - On repos with more than ``_LICENSE_HISTORY_COMMIT_CAP`` license
          edits, the very oldest history is skipped. The recent history is
          almost always what matters for risk.
        """
        history = LicenseHistory()

        for license_file in self.LICENSE_FILES:
            license_path = self.repo_path / license_file
            if license_path.exists():
                history.license_file = license_file
                try:
                    # 64KB is enough for any reasonable LICENSE file; cap to
                    # protect osslili from a pathologically huge file.
                    content = license_path.read_text()[:65536]
                    history.current_license = self._detect_license(content)
                except Exception:
                    pass
                break

        tracked_path: str | None = history.license_file
        if not tracked_path:
            return history

        try:
            cmd = [
                "git",
                "log",
                "-n",
                str(self._LICENSE_HISTORY_COMMIT_CAP),
                "--format=%H|%aI|%an",
                "--",
                tracked_path,
            ]
            output = subprocess.run(
                cmd,
                cwd=self.repo_path,
                capture_output=True,
                text=True,
                timeout=30,
            )
        except (subprocess.SubprocessError, OSError):
            return history

        if output.returncode != 0:
            return history

        # `git log` returns newest first; reverse so we iterate chronologically.
        commits = [c for c in output.stdout.strip().split("\n") if c][::-1]

        previous_id: str | None = None
        deadline = monotonic() + self._LICENSE_HISTORY_TIME_BUDGET_S
        for line in commits:
            if monotonic() > deadline:
                break

            parts = line.split("|", 2)
            if len(parts) < 3:
                continue
            sha, date_str, author = parts[0], parts[1], parts[2]

            commit_content = self._file_at_commit(sha, tracked_path)
            current_id = (
                self._detect_license(commit_content[:65536]) if commit_content else None
            )

            # Skip noise: identical detection on both sides, or both
            # unrecognizable (Unknown→Unknown is detector noise, not a change).
            if current_id == previous_id:
                continue
            if previous_id == "Unknown" and current_id == "Unknown":
                continue

            try:
                date = datetime.fromisoformat(date_str.replace("Z", "+00:00")).replace(
                    tzinfo=None
                )
            except ValueError:
                date = datetime.now()

            history.changes.append(
                LicenseChange(
                    commit_hash=sha[:7],
                    date=date,
                    old_license=previous_id,
                    new_license=current_id or "Unknown",
                    author=author,
                )
            )
            previous_id = current_id

        history.change_count = len(history.changes)

        # The very first entry is the project adopting a license, not a
        # change. Risk thresholds count subsequent transitions only.
        transitions = max(0, history.change_count - 1)
        if transitions >= 2:
            history.risk_level = "high"
        elif transitions == 1:
            history.risk_level = "medium"
        else:
            history.risk_level = "low"

        return history

    def _file_at_commit(self, sha: str, path: str) -> str | None:
        """Return file contents at ``sha``, or None if the file is absent."""
        try:
            result = subprocess.run(
                ["git", "show", f"{sha}:{path}"],
                cwd=self.repo_path,
                capture_output=True,
                text=True,
                timeout=10,
            )
        except (subprocess.SubprocessError, OSError):
            return None
        if result.returncode != 0:
            return None
        content = result.stdout
        return content if content.strip() else None

    def _detect_license(self, content: str) -> str:
        """Detect SPDX license id from license-file content.

        Tries the ``osslili`` detector first — same library the tarball
        scanner uses, so the git-history view and the tarball view of the
        same project agree. Falls back to a hand-rolled substring matcher
        if osslili returns nothing, which catches a few formats osslili
        misses (notably Unlicense and minimal license stubs).

        Returns an SPDX id (e.g. ``MIT``, ``Apache-2.0``, ``GPL-3.0-only``)
        or ``"Unknown"`` if neither path can classify the text.

        Note: ids reflect modern SPDX 3.x naming where osslili emits it
        (so ``GPL-3.0-only`` rather than ``GPL-3.0``). The substring
        fallback returns older 2.x-style ids; the two paths are not always
        identical for the same input. Internal consistency for change
        detection is preserved because the same input always routes the
        same way.
        """
        result = self._detect_license_via_osslili(content)
        if result:
            return result
        return self._detect_license_substring(content)

    def _detect_license_via_osslili(self, content: str) -> str | None:
        """Run the osslili detector on raw license text via a tmp file.

        Uses osslili's public ``detect_licenses(Path)`` API rather than the
        private ``_detect_license_from_text``. The tmp-file overhead is
        negligible (~0.1ms) and the public surface gives us a stable
        contract across osslili upgrades.

        ``detect_licenses`` can return multiple hits for the same file
        because osslili runs SPDX-tag, keyword, and regex detectors in
        parallel. We dedupe on SPDX id and return the highest-confidence
        match, or None if osslili produced no hits.
        """
        if not content.strip():
            return None

        try:
            from osslili.core.generator import LicenseCopyrightDetector
        except ImportError:
            return None

        if self._osslili_detector is None:
            try:
                self._osslili_detector = LicenseCopyrightDetector()
            except Exception:
                return None

        detector = self._osslili_detector.license_detector

        try:
            with tempfile.NamedTemporaryFile(
                mode="w",
                suffix="-LICENSE",
                delete=False,
                encoding="utf-8",
            ) as tmp:
                tmp.write(content)
                tmp_path = Path(tmp.name)
        except OSError:
            return None

        try:
            try:
                hits = detector.detect_licenses(tmp_path)
            except Exception:
                return None
        finally:
            with contextlib.suppress(OSError):
                tmp_path.unlink()

        if not hits:
            return None

        # Pick the highest-confidence id, breaking ties by first occurrence.
        best = max(hits, key=lambda h: getattr(h, "confidence", 0.0))
        spdx_id = getattr(best, "spdx_id", None)
        return spdx_id if spdx_id else None

    def _detect_license_substring(self, content: str) -> str:
        """Fallback substring-pattern detector.

        Used when osslili produces no hit. All patterns for a given license
        must match for that id to be returned. Order matters: more specific
        patterns must be checked before broader ones (LGPL before GPL,
        BSD-3 before BSD-2, AGPL before GPL).
        """
        content = content.lower()

        license_patterns = [
            ("AGPL-3.0", ["gnu affero general public license", "version 3"]),
            ("LGPL-3.0", ["lesser general public license", "version 3"]),
            ("LGPL-2.1", ["lesser general public license", "version 2.1"]),
            ("GPL-3.0", ["gnu general public license", "version 3"]),
            ("GPL-2.0", ["gnu general public license", "version 2"]),
            ("MPL-2.0", ["mozilla public license", "version 2.0"]),
            ("Apache-2.0", ["apache license", "version 2.0"]),
            ("MIT", ["mit license", "permission is hereby granted"]),
            ("ISC", ["isc license", "permission to use"]),
            ("BSD-3-Clause", ["redistribution and use", "neither the name"]),
            ("BSD-2-Clause", ["redistribution and use"]),
            ("Unlicense", ["this is free and unencumbered software"]),
        ]

        for license_id, patterns in license_patterns:
            if all(p in content for p in patterns):
                return license_id

        return "Unknown"
