"""Scoring calculations for suphm."""

from suphm.scoring.burnout import BurnoutScoreCalculator, BurnoutScoreResult
from suphm.scoring.health import HealthScoreCalculator, HealthScoreResult

__all__ = [
    "HealthScoreCalculator",
    "HealthScoreResult",
    "BurnoutScoreCalculator",
    "BurnoutScoreResult",
]
