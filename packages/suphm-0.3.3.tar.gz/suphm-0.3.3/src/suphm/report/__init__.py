"""Report generation for suphm."""

from suphm.report.generator import ReportGenerator

__all__ = ["ReportGenerator"]
