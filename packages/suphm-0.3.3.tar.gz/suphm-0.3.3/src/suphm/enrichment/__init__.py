"""Enrichment modules for adding external data to metrics."""

from suphm.enrichment.company import CompanyEnricher

__all__ = ["CompanyEnricher"]
