"""Tests for suphm."""
