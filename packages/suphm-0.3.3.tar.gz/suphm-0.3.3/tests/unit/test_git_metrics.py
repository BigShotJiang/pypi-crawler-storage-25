"""Unit tests for git metrics module."""

from __future__ import annotations

import tempfile
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from suphm.metrics.git import (
    CompanyStats,
    ContributorStats,
    GitMetricsAnalyzer,
    GitMetricsResult,
    LicenseHistory,
    TimeWindowMetrics,
)


class TestContributorStats:
    """Test ContributorStats data class."""

    def test_basic_stats(self):
        """Test basic contributor stats."""
        stats = ContributorStats(
            email="test@example.com",
            name="Test User",
            commits=100,
            percentage=25.0,
            company="Test Corp",
        )

        assert stats.email == "test@example.com"
        assert stats.commits == 100
        assert stats.percentage == 25.0


class TestCompanyStats:
    """Test CompanyStats data class."""

    def test_basic_stats(self):
        """Test basic company stats."""
        stats = CompanyStats(
            company="Test Corp",
            commits=500,
            percentage=50.0,
            contributors=10,
        )

        assert stats.company == "Test Corp"
        assert stats.commits == 500


class TestTimeWindowMetrics:
    """Test TimeWindowMetrics data class."""

    def test_to_dict(self):
        """Test serialization."""
        now = datetime.now()
        metrics = TimeWindowMetrics(
            start_date=now - timedelta(days=90),
            end_date=now,
            total_commits=150,
            unique_contributors=35,
            bus_factor=8,
            pony_factor=8,
            elephant_factor=2,
        )

        d = metrics.to_dict()

        assert d["total_commits"] == 150
        assert d["unique_contributors"] == 35
        assert d["bus_factor"] == 8
        assert d["pony_factor"] == 8
        assert d["elephant_factor"] == 2


class TestLicenseHistory:
    """Test LicenseHistory data class."""

    def test_default_values(self):
        """Test default values."""
        history = LicenseHistory()

        assert history.license_file is None
        assert history.current_license is None
        assert history.change_count == 0
        assert history.risk_level == "low"

    def test_to_dict(self):
        """Test serialization."""
        history = LicenseHistory(
            license_file="LICENSE",
            current_license="MIT",
            change_count=1,
            risk_level="low",
        )

        d = history.to_dict()

        assert d["license_file"] == "LICENSE"
        assert d["current_license"] == "MIT"
        assert d["change_count"] == 1


class TestGitMetricsResult:
    """Test GitMetricsResult data class."""

    def test_to_dict(self):
        """Test serialization."""
        result = GitMetricsResult(
            repo_url="https://github.com/test/repo",
            clone_path="/tmp/repo",
            analyzed_at=datetime(2024, 1, 1, 12, 0, 0),
        )

        d = result.to_dict()

        assert d["repo_url"] == "https://github.com/test/repo"
        assert d["method"] == "git_offline"
        assert d["ttl_hours"] == 24


class TestGitMetricsAnalyzer:
    """Test GitMetricsAnalyzer functionality."""

    @pytest.fixture
    def mock_config(self):
        """Create mock config."""
        with patch("suphm.metrics.git.get_config") as mock:
            config = MagicMock()
            config.company_mappings.email_domains = {
                "amazon.com": "Amazon",
                "google.com": "Google",
            }
            config.analysis.time_windows = [
                MagicMock(name="90_days", days=90),
                MagicMock(name="all_time", days=None),
            ]
            mock.return_value = config
            yield mock

    def test_init_not_git_repo(self):
        """Should raise error for non-git directory."""
        with tempfile.TemporaryDirectory() as tmpdir:
            with pytest.raises(ValueError, match="Not a git repository"):
                GitMetricsAnalyzer(Path(tmpdir))

    def test_calculate_factor_empty(self, mock_config):
        """Calculate factor with empty list."""
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create fake git repo
            (Path(tmpdir) / ".git").mkdir()

            analyzer = GitMetricsAnalyzer(Path(tmpdir))
            result = analyzer._calculate_factor([], 50)

            assert result == 0

    def test_calculate_factor_single(self, mock_config):
        """Calculate factor with single contributor."""
        with tempfile.TemporaryDirectory() as tmpdir:
            (Path(tmpdir) / ".git").mkdir()

            analyzer = GitMetricsAnalyzer(Path(tmpdir))
            contributors = [
                ContributorStats(email="a@test.com", name="A", commits=100),
            ]
            result = analyzer._calculate_factor(contributors, 50)

            assert result == 1

    def test_calculate_factor_multiple(self, mock_config):
        """Calculate factor with multiple contributors."""
        with tempfile.TemporaryDirectory() as tmpdir:
            (Path(tmpdir) / ".git").mkdir()

            analyzer = GitMetricsAnalyzer(Path(tmpdir))
            contributors = [
                ContributorStats(email="a@test.com", name="A", commits=40),
                ContributorStats(email="b@test.com", name="B", commits=35),
                ContributorStats(email="c@test.com", name="C", commits=25),
            ]

            # Need 2 contributors to reach 50% (40 + 35 = 75 > 50)
            result = analyzer._calculate_factor(contributors, 50)
            assert result == 2

    def test_get_company_from_email(self, mock_config):
        """Get company from email domain."""
        with tempfile.TemporaryDirectory() as tmpdir:
            (Path(tmpdir) / ".git").mkdir()

            analyzer = GitMetricsAnalyzer(Path(tmpdir))

            assert analyzer._get_company("user@amazon.com") == "Amazon"
            assert analyzer._get_company("user@google.com") == "Google"
            assert analyzer._get_company("user@unknown.com") == "Independent"

    def test_get_company_noreply(self, mock_config):
        """Noreply emails should be Independent."""
        with tempfile.TemporaryDirectory() as tmpdir:
            (Path(tmpdir) / ".git").mkdir()

            analyzer = GitMetricsAnalyzer(Path(tmpdir))

            assert analyzer._get_company("user@users.noreply.github.com") == "Independent"

    def test_calculate_retention(self, mock_config):
        """Calculate contributor retention."""
        with tempfile.TemporaryDirectory() as tmpdir:
            (Path(tmpdir) / ".git").mkdir()

            analyzer = GitMetricsAnalyzer(Path(tmpdir))

            prev = [
                {"email": "a@test.com"},
                {"email": "b@test.com"},
            ]
            current = [
                {"email": "a@test.com"},
                {"email": "c@test.com"},
            ]

            retention = analyzer._calculate_retention(prev, current)
            assert retention == 50.0  # 1 of 2 retained

    def test_calculate_retention_empty(self, mock_config):
        """Retention with empty previous window returns None.

        None means "no prior data to compare," distinct from 0.0 which
        would mean "all prior contributors left." Pre-fix this returned
        0.0 and the scoring layer treated young repos like collapsing ones.
        """
        with tempfile.TemporaryDirectory() as tmpdir:
            (Path(tmpdir) / ".git").mkdir()

            analyzer = GitMetricsAnalyzer(Path(tmpdir))
            retention = analyzer._calculate_retention([], [{"email": "a@test.com"}])

            assert retention is None

    def test_detect_license_mit(self, mock_config):
        """Detect MIT license."""
        with tempfile.TemporaryDirectory() as tmpdir:
            (Path(tmpdir) / ".git").mkdir()

            analyzer = GitMetricsAnalyzer(Path(tmpdir))
            content = "MIT License\n\nPermission is hereby granted, free of charge"

            assert analyzer._detect_license(content) == "MIT"

    def test_detect_license_apache(self, mock_config):
        """Detect Apache license."""
        with tempfile.TemporaryDirectory() as tmpdir:
            (Path(tmpdir) / ".git").mkdir()

            analyzer = GitMetricsAnalyzer(Path(tmpdir))
            content = "Apache License\nVersion 2.0"

            assert analyzer._detect_license(content) == "Apache-2.0"

    def test_detect_license_unknown(self, mock_config):
        """Unknown license returns Unknown."""
        with tempfile.TemporaryDirectory() as tmpdir:
            (Path(tmpdir) / ".git").mkdir()

            analyzer = GitMetricsAnalyzer(Path(tmpdir))
            content = "Some custom license text"

            assert analyzer._detect_license(content) == "Unknown"

    def test_substring_fallback_requires_all_patterns(self, mock_config):
        """The substring fallback must require all patterns to match.

        Tests the fallback path directly. Through the orchestrator
        ``_detect_license`` osslili would catch "MIT License" via fuzzy
        matching even from just the header, so this bug-guard exists at
        the substring layer.
        """
        with tempfile.TemporaryDirectory() as tmpdir:
            (Path(tmpdir) / ".git").mkdir()
            analyzer = GitMetricsAnalyzer(Path(tmpdir))

            assert analyzer._detect_license_substring("MIT License") == "Unknown"

    def test_detect_license_gpl2_not_gpl3(self, mock_config):
        """osslili emits modern SPDX-3.x ids: GPL-2.0-only, not GPL-2.0."""
        with tempfile.TemporaryDirectory() as tmpdir:
            (Path(tmpdir) / ".git").mkdir()
            analyzer = GitMetricsAnalyzer(Path(tmpdir))
            gpl2 = "GNU General Public License\nVersion 2, June 1991"

            assert analyzer._detect_license(gpl2) == "GPL-2.0-only"

    def test_detect_license_gpl3_not_gpl2(self, mock_config):
        with tempfile.TemporaryDirectory() as tmpdir:
            (Path(tmpdir) / ".git").mkdir()
            analyzer = GitMetricsAnalyzer(Path(tmpdir))
            gpl3 = "GNU General Public License\nVersion 3, 29 June 2007"

            assert analyzer._detect_license(gpl3) == "GPL-3.0-only"

    def test_detect_license_lgpl_not_gpl(self, mock_config):
        with tempfile.TemporaryDirectory() as tmpdir:
            (Path(tmpdir) / ".git").mkdir()
            analyzer = GitMetricsAnalyzer(Path(tmpdir))
            lgpl3 = "GNU Lesser General Public License\nVersion 3, 29 June 2007"

            assert analyzer._detect_license(lgpl3) == "LGPL-3.0-only"

    def test_detect_license_agpl_not_gpl(self, mock_config):
        with tempfile.TemporaryDirectory() as tmpdir:
            (Path(tmpdir) / ".git").mkdir()
            analyzer = GitMetricsAnalyzer(Path(tmpdir))
            agpl3 = "GNU Affero General Public License\nVersion 3, 19 November 2007"

            assert analyzer._detect_license(agpl3) == "AGPL-3.0-only"

    def test_detect_license_unlicense_uses_fallback(self, mock_config):
        """osslili currently does not detect the Unlicense; substring
        fallback handles it. This pins the contract so we notice if osslili
        starts handling it (good) or our fallback regresses (bad).
        """
        with tempfile.TemporaryDirectory() as tmpdir:
            (Path(tmpdir) / ".git").mkdir()
            analyzer = GitMetricsAnalyzer(Path(tmpdir))
            unlicense = (
                "This is free and unencumbered software released into the "
                "public domain."
            )

            assert analyzer._detect_license(unlicense) == "Unlicense"

    def test_detect_license_bsd3(self, mock_config):
        with tempfile.TemporaryDirectory() as tmpdir:
            (Path(tmpdir) / ".git").mkdir()
            analyzer = GitMetricsAnalyzer(Path(tmpdir))
            bsd3 = (
                "Redistribution and use in source and binary forms, with or "
                "without modification, are permitted provided that the "
                "following conditions are met:\n"
                "1. Redistributions of source code must retain...\n"
                "2. Redistributions in binary form must reproduce...\n"
                "3. Neither the name of the copyright holder nor the names "
                "of its contributors may be used to endorse or promote..."
            )

            assert analyzer._detect_license(bsd3) == "BSD-3-Clause"

    def test_detect_license_bsd2_not_bsd3(self, mock_config):
        """BSD-2 has no 'neither the name' clause; must not match BSD-3."""
        with tempfile.TemporaryDirectory() as tmpdir:
            (Path(tmpdir) / ".git").mkdir()
            analyzer = GitMetricsAnalyzer(Path(tmpdir))
            bsd2 = (
                "Redistribution and use in source and binary forms, with or "
                "without modification, are permitted provided that the "
                "following conditions are met:\n"
                "1. Redistributions of source code must retain the above "
                "copyright notice...\n"
                "2. Redistributions in binary form must reproduce the above "
                "copyright notice..."
            )

            assert analyzer._detect_license(bsd2) == "BSD-2-Clause"

    def test_detect_license_unlicense(self, mock_config):
        with tempfile.TemporaryDirectory() as tmpdir:
            (Path(tmpdir) / ".git").mkdir()
            analyzer = GitMetricsAnalyzer(Path(tmpdir))
            unlicense = (
                "This is free and unencumbered software released into the "
                "public domain.\n"
            )

            assert analyzer._detect_license(unlicense) == "Unlicense"
