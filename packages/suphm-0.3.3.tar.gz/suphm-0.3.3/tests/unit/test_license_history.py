"""Tests for the license-change detector in metrics.git.

The detector must compare detected SPDX ids between commits and only record
real transitions. Cosmetic edits to the LICENSE file (copyright year bumps,
formatting tweaks) must not count as license changes.
"""

from __future__ import annotations

import shutil
import subprocess
import tempfile
from datetime import datetime
from pathlib import Path
from unittest.mock import patch

import pytest

from suphm.metrics.git import GitMetricsAnalyzer

MIT_LICENSE = """MIT License

Copyright (c) 2020 Example

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction.
"""

MIT_LICENSE_BUMPED_YEAR = MIT_LICENSE.replace("2020", "2024")

APACHE2_LICENSE = """Apache License
Version 2.0, January 2004
http://www.apache.org/licenses/

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
"""

GPL3_LICENSE = """GNU General Public License
Version 3, 29 June 2007

Copyright (C) 2007 Free Software Foundation, Inc.
"""


def _git(repo: Path, *args: str) -> None:
    subprocess.run(
        ["git", "-c", "user.email=t@t", "-c", "user.name=Tester", *args],
        cwd=repo,
        check=True,
        capture_output=True,
    )


def _commit_license(repo: Path, content: str, message: str) -> None:
    (repo / "LICENSE").write_text(content)
    _git(repo, "add", "LICENSE")
    _git(repo, "commit", "-m", message)


@pytest.fixture
def repo() -> Path:
    """A throwaway git repo with no commits."""
    path = Path(tempfile.mkdtemp())
    try:
        _git(path, "init", "-q", "-b", "main")
        # Seed an unrelated file so the repo has history independent of LICENSE.
        (path / "README.md").write_text("seed\n")
        _git(path, "add", "README.md")
        _git(path, "commit", "-m", "seed")
        yield path
    finally:
        shutil.rmtree(path, ignore_errors=True)


@pytest.fixture
def analyzer(repo, tmp_path):
    with patch("suphm.metrics.git.get_config") as cfg:
        cfg.return_value.cache_dir = tmp_path
        yield GitMetricsAnalyzer(repo)


class TestLicenseHistoryDetection:
    def test_no_license_file(self, analyzer):
        history = analyzer._analyze_license_history()
        assert history.license_file is None
        assert history.current_license is None
        assert history.change_count == 0
        assert history.changes == []
        assert history.risk_level == "low"

    def test_initial_adoption_emits_one_change(self, repo, analyzer):
        _commit_license(repo, MIT_LICENSE, "Add MIT license")

        history = analyzer._analyze_license_history()

        assert history.license_file == "LICENSE"
        assert history.current_license == "MIT"
        assert history.change_count == 1
        assert len(history.changes) == 1
        assert history.changes[0].old_license is None
        assert history.changes[0].new_license == "MIT"
        # Initial adoption alone is not a "transition" — risk should be low.
        assert history.risk_level == "low"

    def test_cosmetic_edit_does_not_count(self, repo, analyzer):
        _commit_license(repo, MIT_LICENSE, "Add MIT license")
        _commit_license(repo, MIT_LICENSE_BUMPED_YEAR, "Bump copyright year")
        _commit_license(repo, MIT_LICENSE_BUMPED_YEAR + "\n", "Trailing newline")

        history = analyzer._analyze_license_history()

        # Three commits touched the LICENSE file but the SPDX id never changed.
        assert history.current_license == "MIT"
        assert history.change_count == 1
        assert history.risk_level == "low"

    def test_real_relicense_emits_change(self, repo, analyzer):
        _commit_license(repo, MIT_LICENSE, "Adopt MIT")
        _commit_license(repo, APACHE2_LICENSE, "Relicense to Apache-2.0")

        history = analyzer._analyze_license_history()

        assert history.current_license == "Apache-2.0"
        assert history.change_count == 2
        assert [c.new_license for c in history.changes] == ["MIT", "Apache-2.0"]
        assert history.changes[1].old_license == "MIT"
        # One real transition → medium risk.
        assert history.risk_level == "medium"

    def test_multiple_relicenses_high_risk(self, repo, analyzer):
        _commit_license(repo, MIT_LICENSE, "Adopt MIT")
        _commit_license(repo, APACHE2_LICENSE, "Relicense to Apache")
        _commit_license(repo, GPL3_LICENSE, "Relicense to GPL")

        history = analyzer._analyze_license_history()

        assert history.current_license == "GPL-3.0-only"
        assert history.change_count == 3
        # Two transitions (MIT→Apache, Apache→GPL) → high risk.
        assert history.risk_level == "high"

    def test_old_license_chain_is_correct(self, repo, analyzer):
        """Each entry's old_license must match the previous entry's new_license."""
        _commit_license(repo, MIT_LICENSE, "Adopt MIT")
        _commit_license(repo, APACHE2_LICENSE, "Apache")
        _commit_license(repo, APACHE2_LICENSE + "\n# trailing\n", "noise")
        _commit_license(repo, GPL3_LICENSE, "GPL")

        history = analyzer._analyze_license_history()

        prior = None
        for change in history.changes:
            assert change.old_license == prior
            prior = change.new_license
        assert prior == history.current_license

    def test_unrecognized_license_marked_unknown(self, repo, analyzer):
        """A custom license that doesn't match any SPDX pattern → 'Unknown'.

        The scoring layer must treat this the same as no license: a file is
        present but downstream users can't recognize it.
        """
        _commit_license(
            repo,
            "Custom proprietary license — see legal@example.com\n",
            "Custom license",
        )

        history = analyzer._analyze_license_history()

        assert history.current_license == "Unknown"
        # We still record the file's existence, but the scoring layer
        # (tested separately) should treat 'Unknown' as legal ambiguity.

    def test_commit_cap_bounds_runtime(self, repo, analyzer, monkeypatch):
        """The commit cap protects against pathological histories.

        We force a tiny cap and commit more than that many edits. The
        analyzer should walk only the most recent ``cap`` commits, in
        chronological order, and still detect the current license.
        """
        monkeypatch.setattr(
            "suphm.metrics.git.GitMetricsAnalyzer._LICENSE_HISTORY_COMMIT_CAP", 3
        )
        for i in range(6):
            _commit_license(repo, MIT_LICENSE + f"\n# edit {i}\n", f"edit {i}")

        history = analyzer._analyze_license_history()

        assert history.current_license == "MIT"
        # Only 3 commits inspected; all detect MIT, so the chronological
        # walk records exactly one transition (None → MIT).
        assert history.change_count == 1


class TestLicenseStabilityScoring:
    """The scoring layer must not reward 'Unknown' current licenses."""

    def test_unknown_license_scores_low(self):
        from suphm.metrics.git import GitMetricsResult, LicenseHistory
        from suphm.scoring.health import HealthScoreCalculator, HealthScoreResult

        calc = HealthScoreCalculator()
        gm = GitMetricsResult(repo_url="x", clone_path="/tmp", analyzed_at=datetime.now())
        gm.license_changes = LicenseHistory(
            license_file="LICENSE", current_license="Unknown", change_count=1
        )
        result = HealthScoreResult(purl="x", calculated_at=datetime.now())

        calc._score_license_stability(gm, result)

        assert result.category_scores["license_stability"].score == 20

    def test_clean_apache_history_scores_perfect(self):
        from suphm.metrics.git import GitMetricsResult, LicenseChange, LicenseHistory
        from suphm.scoring.health import HealthScoreCalculator, HealthScoreResult

        calc = HealthScoreCalculator()
        gm = GitMetricsResult(repo_url="x", clone_path="/tmp", analyzed_at=datetime.now())
        gm.license_changes = LicenseHistory(
            license_file="LICENSE",
            current_license="Apache-2.0",
            change_count=1,
            changes=[
                LicenseChange(
                    commit_hash="a" * 7,
                    date=datetime.now(),
                    old_license=None,
                    new_license="Apache-2.0",
                )
            ],
        )
        result = HealthScoreResult(purl="x", calculated_at=datetime.now())

        calc._score_license_stability(gm, result)

        # Initial adoption only, zero transitions → perfect score.
        assert result.category_scores["license_stability"].score == 100
