"""Tests for the tarball scanner.

These tests cover dataclass serialization, binary-file detection,
manifest parsing, local-directory scanning, and the scan_purl
orchestration around purl2src + the package resolver.

Security-critical extraction safety (zip-slip, tar-slip, filename
sanitization, size caps) and pkg:github short-circuit live in
tests/unit/test_tarball_security.py.
"""

from __future__ import annotations

import asyncio
from datetime import datetime
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from suphm.scanner.tarball import (
    BinaryFile,
    LicenseFile,
    PackageMetadata,
    TarballScanner,
    TarballScanResult,
)

# ---------------------------------------------------------------------------
# Dataclass serialization
# ---------------------------------------------------------------------------


class TestLicenseFile:
    def test_to_dict(self):
        lf = LicenseFile(path="LICENSE", spdx_id="MIT", confidence=95.0, content_hash="abc")
        data = lf.to_dict()
        assert data["path"] == "LICENSE"
        assert data["spdx_id"] == "MIT"
        assert data["confidence"] == 95.0

    def test_to_dict_unknown_license(self):
        data = LicenseFile(path="LICENSE.txt").to_dict()
        assert data["spdx_id"] is None
        assert data["confidence"] == 0.0


class TestBinaryFile:
    def test_to_dict(self):
        data = BinaryFile(
            path="lib.so", file_type="ELF executable", size_bytes=1024, signature="7f454c46"
        ).to_dict()
        assert data == {
            "path": "lib.so",
            "file_type": "ELF executable",
            "size_bytes": 1024,
            "signature": "7f454c46",
        }


class TestPackageMetadata:
    def test_to_dict_full(self):
        data = PackageMetadata(
            name="express", version="4.18.2", license="MIT", author="TJ Holowaychuk"
        ).to_dict()
        assert data["name"] == "express"
        assert data["version"] == "4.18.2"
        assert data["license"] == "MIT"

    def test_to_dict_empty(self):
        data = PackageMetadata().to_dict()
        assert data["name"] is None
        assert data["version"] is None


class TestTarballScanResult:
    def test_to_dict(self):
        result = TarballScanResult(
            purl="pkg:npm/express@4.18.2",
            tarball_url="https://example.com/express.tgz",
            scanned_at=datetime(2024, 1, 1, 12, 0, 0),
            license_files=[LicenseFile(path="LICENSE", spdx_id="MIT", confidence=95.0)],
            copyrights=["Copyright (c) 2024 Express Team"],
            binaries={"files": [], "signatures": []},
            file_count=100,
            total_size_bytes=50_000,
            scan_method="osslili",
        )
        data = result.to_dict()
        assert data["purl"] == "pkg:npm/express@4.18.2"
        assert len(data["license_files"]) == 1
        assert data["file_count"] == 100
        assert data["scan_method"] == "osslili"


# ---------------------------------------------------------------------------
# Scanner behaviour
# ---------------------------------------------------------------------------


@pytest.fixture
def scanner():
    """A real TarballScanner. The osslili dependency is required at import
    time (raises RuntimeError if missing); we trust the dev install pulled
    it in via pyproject."""
    return TarballScanner()


class TestBinaryDetection:
    def test_check_binary_by_extension(self, scanner, tmp_path):
        f = tmp_path / "lib.so"
        f.write_bytes(b"not actually elf bytes")
        result = scanner._check_binary(f)
        assert result is not None
        assert result.signature == ".so"

    def test_check_binary_by_magic_bytes(self, scanner, tmp_path):
        f = tmp_path / "blob.bin"
        f.write_bytes(b"\x7fELF" + b"\x00" * 100)
        result = scanner._check_binary(f)
        assert result is not None
        assert result.file_type == "ELF executable"

    def test_check_binary_text_file_returns_none(self, scanner, tmp_path):
        f = tmp_path / "readme.txt"
        f.write_text("This is a text file")
        assert scanner._check_binary(f) is None


class TestManifestParsing:
    def test_parse_npm_package_json(self, scanner, tmp_path):
        f = tmp_path / "package.json"
        f.write_text('{"name": "@scope/pkg", "version": "1.2.3", "license": "Apache-2.0"}')
        result = scanner._parse_manifest(f, "npm")
        assert result.name == "@scope/pkg"
        assert result.version == "1.2.3"
        assert result.license == "Apache-2.0"

    def test_parse_pypi_pyproject_toml(self, scanner, tmp_path):
        f = tmp_path / "pyproject.toml"
        f.write_text('name = "my-package"\nversion = "0.1.0"\ndescription = "A test package"')
        result = scanner._parse_manifest(f, "pypi")
        assert result.name == "my-package"
        assert result.version == "0.1.0"


class TestScanLocal:
    def test_scan_local_directory_finds_license_and_metadata(self, scanner, tmp_path):
        (tmp_path / "LICENSE").write_text(
            "MIT License\n\nPermission is hereby granted, free of charge..."
        )
        (tmp_path / "package.json").write_text(
            '{"name": "test-pkg", "version": "1.0.0", "license": "MIT"}'
        )
        (tmp_path / "index.js").write_text(
            "// Copyright 2024 Test Author\nmodule.exports = {}"
        )

        result = scanner.scan_local("pkg:npm/test-pkg@1.0.0", tmp_path)

        assert result.purl == "pkg:npm/test-pkg@1.0.0"
        assert result.file_count >= 3
        assert result.package_metadata.name == "test-pkg"
        # osslili picked up at least the LICENSE file
        assert len(result.license_files) >= 1


# ---------------------------------------------------------------------------
# scan_purl orchestration (purl2src first, then PackageResolver)
# ---------------------------------------------------------------------------


class TestScanPurlOrchestration:
    def test_uses_purl2src_first_when_available(self, scanner):
        """If purl2src returns a URL, the resolver should not be queried."""
        with patch.object(
            scanner,
            "_get_download_url_via_purl2src",
            return_value="https://crates.io/api/v1/crates/serde/1.0.0/download",
        ), patch("suphm.discovery.PackageResolver") as resolver, \
             patch.object(scanner, "scan_url", new_callable=AsyncMock) as scan_url:
            scan_url.return_value = TarballScanResult(
                purl="pkg:cargo/serde@1.0.0",
                tarball_url="https://crates.io/api/v1/crates/serde/1.0.0/download",
                scanned_at=datetime.now(),
            )
            asyncio.run(scanner.scan_purl("pkg:cargo/serde@1.0.0"))

        resolver.assert_not_called()
        scan_url.assert_called_once_with(
            "pkg:cargo/serde@1.0.0",
            "https://crates.io/api/v1/crates/serde/1.0.0/download",
        )

    def test_falls_back_to_resolver_when_purl2src_returns_none(self, scanner):
        mock_discovery = MagicMock()
        mock_discovery.tarball_url = "https://example.com/pkg.tar.gz"
        with patch.object(scanner, "_get_download_url_via_purl2src", return_value=None), \
             patch("suphm.discovery.PackageResolver") as resolver_cls, \
             patch.object(scanner, "scan_url", new_callable=AsyncMock) as scan_url:
            resolver_cls.return_value.discover = AsyncMock(return_value=mock_discovery)
            scan_url.return_value = TarballScanResult(
                purl="pkg:npm/test@1.0.0",
                tarball_url="https://example.com/pkg.tar.gz",
                scanned_at=datetime.now(),
            )
            result = asyncio.run(scanner.scan_purl("pkg:npm/test@1.0.0"))

        assert result.purl == "pkg:npm/test@1.0.0"
        scan_url.assert_called_once_with("pkg:npm/test@1.0.0", "https://example.com/pkg.tar.gz")

    def test_returns_empty_when_no_tarball_url_anywhere(self, scanner):
        mock_discovery = MagicMock()
        mock_discovery.tarball_url = None
        with patch.object(scanner, "_get_download_url_via_purl2src", return_value=None), \
             patch("suphm.discovery.PackageResolver") as resolver_cls:
            resolver_cls.return_value.discover = AsyncMock(return_value=mock_discovery)
            result = asyncio.run(scanner.scan_purl("pkg:npm/notfound@1.0.0"))

        assert result.tarball_url is None
        assert result.file_count == 0


class TestPurl2srcWrapper:
    """The scanner wraps purl2src with import-failure tolerance and exception
    swallowing. It also rejects .git URLs (covered in test_tarball_security.py)."""

    def test_returns_url_on_success(self, scanner):
        fake = type("R", (), {"download_url": "https://registry.npmjs.org/express/-/express-4.17.1.tgz"})()
        with patch("purl2src.get_download_url", return_value=fake, create=True):
            url = scanner._get_download_url_via_purl2src("pkg:npm/express@4.17.1")
        assert url == "https://registry.npmjs.org/express/-/express-4.17.1.tgz"

    def test_returns_none_when_purl2src_unavailable(self, scanner):
        # Simulate an ImportError as if purl2src wasn't installed.
        with patch.dict("sys.modules", {"purl2src": None}):
            assert scanner._get_download_url_via_purl2src("pkg:npm/x@1") is None

    def test_returns_none_on_internal_failure(self, scanner):
        with patch("purl2src.get_download_url", side_effect=RuntimeError("api error"), create=True):
            assert scanner._get_download_url_via_purl2src("pkg:npm/x@1") is None
