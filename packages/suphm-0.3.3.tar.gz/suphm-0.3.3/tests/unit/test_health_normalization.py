"""Regression tests for the health-score normalization fix.

Pre-fix bug: HealthScoreCalculator divided by the sum of *present* category
weights, so a perfect score in a single dimension produced a 100/100 result
identical to a perfect score across every dimension. Missing data was
rewarded rather than penalised.

Post-fix: the divisor is the sum of all configured weights, so missing
categories implicitly contribute 0 and pull the score down. data_completeness
in extended_metrics tells consumers what fraction of dimensions had data.
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from suphm.scoring.health import (
    CategoryScore,
    HealthScoreCalculator,
    HealthScoreResult,
)


@pytest.fixture
def calc():
    """Calculator wired to the default 100-sum weights."""
    with patch("suphm.scoring.health.get_config") as mock:
        config = MagicMock()
        config.scoring.health.commit_activity = 15
        config.scoring.health.bus_factor = 10
        config.scoring.health.pony_factor = 10
        config.scoring.health.license_stability = 5
        config.scoring.health.contributor_retention = 10
        config.scoring.health.elephant_factor = 10
        config.scoring.health.issue_responsiveness = 10
        config.scoring.health.pr_velocity = 10
        config.scoring.health.branch_protection = 10
        config.scoring.health.release_frequency = 10
        config.analysis.thresholds = {
            "bus_factor_min": 3,
            "pony_factor_min": 3,
            "elephant_factor_min": 2,
        }
        mock.return_value = config
        yield HealthScoreCalculator()


def _seed_categories(result: HealthScoreResult, scores: dict[str, tuple[int, int]]):
    """Inject pre-computed category scores. Keys are category names; values
    are (raw_score, weight)."""
    for name, (score, weight) in scores.items():
        result.category_scores[name] = CategoryScore(
            name=name,
            score=score,
            weight=weight,
            weighted_score=(score / 100) * weight,
            status="healthy" if score >= 80 else "moderate",
        )


def _calc_overall(calc: HealthScoreCalculator, result: HealthScoreResult) -> int:
    """Replay just the overall-score block from calculate() so we can test
    normalization in isolation, without standing up real Git/GitHub fixtures."""
    total_weighted = sum(c.weighted_score for c in result.category_scores.values())
    max_weight = calc._max_possible_weight()
    return int((total_weighted / max_weight) * 100) if max_weight else 0


class TestNormalisation:
    def test_max_possible_weight_sums_to_100(self, calc):
        assert calc._max_possible_weight() == 100

    def test_perfect_in_every_dimension_is_100(self, calc):
        result = HealthScoreResult(purl="pkg:npm/x", calculated_at=None)  # type: ignore[arg-type]
        _seed_categories(
            result,
            {
                "commit_activity": (100, 15),
                "bus_factor": (100, 10),
                "pony_factor": (100, 10),
                "license_stability": (100, 5),
                "contributor_retention": (100, 10),
                "elephant_factor": (100, 10),
                "issue_responsiveness": (100, 10),
                "pr_velocity": (100, 10),
                "branch_protection": (100, 10),
                "release_frequency": (100, 10),
            },
        )
        assert _calc_overall(calc, result) == 100

    def test_perfect_git_only_no_longer_scores_100(self, calc):
        """The headline regression: only git dimensions present, all 100, used
        to produce health_score=100. Now it should produce 60 (sum of git
        weights / 100), which honestly reflects that GitHub data was missing."""
        result = HealthScoreResult(purl="pkg:npm/x", calculated_at=None)  # type: ignore[arg-type]
        _seed_categories(
            result,
            {
                "commit_activity": (100, 15),
                "bus_factor": (100, 10),
                "pony_factor": (100, 10),
                "license_stability": (100, 5),
                "contributor_retention": (100, 10),
                "elephant_factor": (100, 10),
            },
        )
        assert _calc_overall(calc, result) == 60

    def test_partial_data_drags_score_down(self, calc):
        """Half the dimensions present at 100, the other half absent. Score
        should be ~50, not ~100."""
        result = HealthScoreResult(purl="pkg:npm/x", calculated_at=None)  # type: ignore[arg-type]
        _seed_categories(
            result,
            {
                "commit_activity": (100, 15),
                "bus_factor": (100, 10),
                "pony_factor": (100, 10),
                "license_stability": (100, 5),
                "contributor_retention": (100, 10),
            },
        )
        assert _calc_overall(calc, result) == 50

    def test_no_data_is_zero(self, calc):
        result = HealthScoreResult(purl="pkg:npm/x", calculated_at=None)  # type: ignore[arg-type]
        assert _calc_overall(calc, result) == 0


class TestDataCompleteness:
    def test_full_data_is_completeness_1(self, calc):
        result = HealthScoreResult(purl="pkg:npm/x", calculated_at=None)  # type: ignore[arg-type]
        _seed_categories(
            result,
            {
                "commit_activity": (100, 15),
                "bus_factor": (100, 10),
                "pony_factor": (100, 10),
                "license_stability": (100, 5),
                "contributor_retention": (100, 10),
                "elephant_factor": (100, 10),
                "issue_responsiveness": (100, 10),
                "pr_velocity": (100, 10),
                "branch_protection": (100, 10),
                "release_frequency": (100, 10),
            },
        )
        calc._populate_extended_metrics(None, None, result)
        assert result.extended_metrics["data_completeness"] == 1.0

    def test_git_only_is_completeness_0_60(self, calc):
        result = HealthScoreResult(purl="pkg:npm/x", calculated_at=None)  # type: ignore[arg-type]
        _seed_categories(
            result,
            {
                "commit_activity": (100, 15),
                "bus_factor": (100, 10),
                "pony_factor": (100, 10),
                "license_stability": (100, 5),
                "contributor_retention": (100, 10),
                "elephant_factor": (100, 10),
            },
        )
        calc._populate_extended_metrics(None, None, result)
        assert result.extended_metrics["data_completeness"] == 0.6
