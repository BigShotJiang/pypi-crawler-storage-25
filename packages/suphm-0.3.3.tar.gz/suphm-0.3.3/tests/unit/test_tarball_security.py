"""Regression tests for tarball-scanner security hardening.

Covers:
- Content-Disposition / URL filename sanitization
- Zip-slip rejection on absolute paths and parent-traversal members
- Tar-slip rejection on absolute paths, parent-traversal, and symlinks/hardlinks
  whose targets escape the extraction root
- Member-count and extracted-size caps
"""

from __future__ import annotations

import io
import tarfile
import zipfile
from pathlib import Path
from unittest.mock import patch

import pytest

from suphm.scanner import tarball as tb
from suphm.scanner.tarball import (
    TarballScanner,
    UnsafeArchiveError,
    _safe_extract_tar,
    _safe_extract_zip,
    _sanitize_download_filename,
)


class TestSanitizeFilename:
    def test_strips_path_components(self):
        assert _sanitize_download_filename("../../etc/passwd") == "passwd"
        assert _sanitize_download_filename("/abs/path/pkg.tgz") == "pkg.tgz"
        assert _sanitize_download_filename("dir\\sub\\pkg.zip") == "pkg.zip"

    def test_rejects_dot_and_double_dot(self):
        assert _sanitize_download_filename(".") == "package.tar.gz"
        assert _sanitize_download_filename("..") == "package.tar.gz"

    def test_rejects_null_bytes(self):
        assert _sanitize_download_filename("evil\x00.tgz") == "package.tar.gz"

    def test_falls_back_when_empty(self):
        assert _sanitize_download_filename(None) == "package.tar.gz"
        assert _sanitize_download_filename("") == "package.tar.gz"

    def test_passes_through_clean_name(self):
        assert _sanitize_download_filename("requests-2.31.0.tar.gz") == "requests-2.31.0.tar.gz"


class TestSafeZipExtract:
    def _make_zip(self, tmp_path: Path, members: dict[str, bytes]) -> Path:
        archive = tmp_path / "evil.zip"
        with zipfile.ZipFile(archive, "w") as zf:
            for name, data in members.items():
                zf.writestr(name, data)
        return archive

    def test_extracts_normal_zip(self, tmp_path):
        archive = self._make_zip(tmp_path, {"a.txt": b"hello"})
        dest = tmp_path / "out"
        dest.mkdir()
        _safe_extract_zip(archive, dest)
        assert (dest / "a.txt").read_bytes() == b"hello"

    def test_rejects_parent_traversal(self, tmp_path):
        archive = self._make_zip(tmp_path, {"../escape.txt": b"pwn"})
        dest = tmp_path / "out"
        dest.mkdir()
        with pytest.raises(UnsafeArchiveError, match="escapes root"):
            _safe_extract_zip(archive, dest)
        # Critical: the file must not have been written outside dest.
        assert not (tmp_path / "escape.txt").exists()

    def test_rejects_absolute_path(self, tmp_path):
        # zipfile normalises forward slashes; a leading slash is the canonical
        # absolute marker on POSIX.
        archive = self._make_zip(tmp_path, {"/etc/passwd": b"x"})
        dest = tmp_path / "out"
        dest.mkdir()
        with pytest.raises(UnsafeArchiveError):
            _safe_extract_zip(archive, dest)

    def test_rejects_oversized_payload(self, tmp_path, monkeypatch):
        monkeypatch.setattr(tb, "MAX_EXTRACTED_BYTES", 16)
        archive = self._make_zip(tmp_path, {"big.bin": b"x" * 1024})
        dest = tmp_path / "out"
        dest.mkdir()
        with pytest.raises(UnsafeArchiveError, match="extracted size"):
            _safe_extract_zip(archive, dest)


class TestSafeTarExtract:
    def _start_tar(self, path: Path) -> tarfile.TarFile:
        return tarfile.open(path, "w")

    def _add(self, tf: tarfile.TarFile, name: str, data: bytes) -> None:
        info = tarfile.TarInfo(name=name)
        info.size = len(data)
        tf.addfile(info, io.BytesIO(data))

    def test_extracts_normal_tar(self, tmp_path):
        archive = tmp_path / "ok.tar"
        with self._start_tar(archive) as tf:
            self._add(tf, "pkg/a.txt", b"hi")
        dest = tmp_path / "out"
        dest.mkdir()
        _safe_extract_tar(archive, dest)
        assert (dest / "pkg" / "a.txt").read_bytes() == b"hi"

    def test_rejects_parent_traversal(self, tmp_path):
        archive = tmp_path / "evil.tar"
        with self._start_tar(archive) as tf:
            self._add(tf, "../escape.txt", b"pwn")
        dest = tmp_path / "out"
        dest.mkdir()
        with pytest.raises(UnsafeArchiveError, match="escapes root"):
            _safe_extract_tar(archive, dest)
        assert not (tmp_path / "escape.txt").exists()

    def test_rejects_absolute_path(self, tmp_path):
        archive = tmp_path / "evil.tar"
        with self._start_tar(archive) as tf:
            self._add(tf, "/etc/passwd", b"x")
        dest = tmp_path / "out"
        dest.mkdir()
        with pytest.raises(UnsafeArchiveError):
            _safe_extract_tar(archive, dest)

    def test_rejects_symlink_escape(self, tmp_path):
        archive = tmp_path / "evil.tar"
        with self._start_tar(archive) as tf:
            info = tarfile.TarInfo(name="link")
            info.type = tarfile.SYMTYPE
            info.linkname = "../../etc/passwd"
            tf.addfile(info)
        dest = tmp_path / "out"
        dest.mkdir()
        with pytest.raises(UnsafeArchiveError, match="link target"):
            _safe_extract_tar(archive, dest)

    def test_rejects_hardlink_escape(self, tmp_path):
        archive = tmp_path / "evil.tar"
        with self._start_tar(archive) as tf:
            info = tarfile.TarInfo(name="hl")
            info.type = tarfile.LNKTYPE
            info.linkname = "../outside"
            tf.addfile(info)
        dest = tmp_path / "out"
        dest.mkdir()
        with pytest.raises(UnsafeArchiveError, match="link target"):
            _safe_extract_tar(archive, dest)

    def test_rejects_too_many_members(self, tmp_path, monkeypatch):
        monkeypatch.setattr(tb, "MAX_ARCHIVE_MEMBERS", 3)
        archive = tmp_path / "many.tar"
        with self._start_tar(archive) as tf:
            for i in range(10):
                self._add(tf, f"f{i}.txt", b"x")
        dest = tmp_path / "out"
        dest.mkdir()
        with pytest.raises(UnsafeArchiveError, match="more than"):
            _safe_extract_tar(archive, dest)

    def test_rejects_oversized_payload(self, tmp_path, monkeypatch):
        monkeypatch.setattr(tb, "MAX_EXTRACTED_BYTES", 16)
        archive = tmp_path / "big.tar"
        with self._start_tar(archive) as tf:
            self._add(tf, "big.bin", b"x" * 1024)
        dest = tmp_path / "out"
        dest.mkdir()
        with pytest.raises(UnsafeArchiveError, match="extracted size"):
            _safe_extract_tar(archive, dest)


class TestPurl2srcGitFilter:
    """purl2src returns the .git clone URL for some PURL types (notably
    pkg:github/*). That is not a registry tarball and tarfile.open silently
    extracts zero files from it. The scanner must reject .git URLs."""

    def test_git_url_is_rejected(self):
        scanner = TarballScanner()
        fake = type("R", (), {"download_url": "https://github.com/x/y.git"})()
        with patch.object(scanner, "_get_download_url_via_purl2src", wraps=scanner._get_download_url_via_purl2src):
            with patch("purl2src.get_download_url", return_value=fake, create=True):
                assert scanner._get_download_url_via_purl2src("pkg:github/x/y") is None

    def test_normal_url_passes(self):
        scanner = TarballScanner()
        fake = type("R", (), {"download_url": "https://registry.npmjs.org/x/-/x-1.0.0.tgz"})()
        with patch("purl2src.get_download_url", return_value=fake, create=True):
            assert (
                scanner._get_download_url_via_purl2src("pkg:npm/x")
                == "https://registry.npmjs.org/x/-/x-1.0.0.tgz"
            )


class TestPkgGithubScanShortCircuit:
    """pkg:github/* PURLs have no registry tarball by definition. scan_purl
    must return an empty result without making any network calls or reaching
    the resolver."""

    @pytest.mark.asyncio
    async def test_pkg_github_returns_empty_without_network(self):
        scanner = TarballScanner()
        with patch.object(scanner, "_get_download_url_via_purl2src") as purl2src, \
             patch("suphm.discovery.PackageResolver") as resolver:
            result = await scanner.scan_purl("pkg:github/AInvirion/aiproxyguard")
        purl2src.assert_not_called()
        resolver.assert_not_called()
        assert result.tarball_url is None
        assert result.file_count == 0
        assert result.license_files == []
