"""Regression tests for GitHubMetricsCollector partial-data status tracking.

Pre-fix behaviour: every collector wrapped its body in `except Exception: pass`
so a single failed endpoint silently zero-ed out a whole metric category and
downstream scoring couldn't tell "no data" from "no failure".

Post-fix behaviour: the orchestrator (`_safe_run`) records a per-collector
status in `GitHubMetricsResult.collector_status`. Failures are logged and
mapped to "rate_limited", "http_error:<code>", or "error". Pre-flight rate
budget skips the collector before it burns calls.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from suphm.core.http import APIResponse, HTTPError, RateLimitError, RateLimitInfo
from suphm.metrics.github import GitHubMetricsCollector


def _ok_response(data):
    return APIResponse(status_code=200, data=data, headers={})


def _empty_repo_payload():
    return {
        "stargazers_count": 1,
        "forks_count": 0,
        "subscribers_count": 0,
        "default_branch": "main",
        "open_issues_count": 0,
        "topics": [],
    }


@pytest.fixture
def collector():
    """Token-authenticated collector with a stubbed GitHub client.

    The client's session() is a no-op async context manager so collect() can
    drive the full orchestration path. Each test patches the individual
    `get_*` methods to script the API behaviour it cares about.
    """
    with patch("suphm.metrics.github.get_config") as cfg:
        cfg.return_value.github_token = "fake-token"
        c = GitHubMetricsCollector(token="fake-token")

    # Replace the client wholesale; we don't want real httpx sessions.
    client = MagicMock()
    client.session.return_value.__aenter__ = AsyncMock(return_value=client)
    client.session.return_value.__aexit__ = AsyncMock(return_value=None)
    client.rate_limit = RateLimitInfo(remaining=4990, limit=5000)
    c.client = client
    return c


class TestHappyPath:
    @pytest.mark.asyncio
    async def test_all_collectors_marked_ok_when_endpoints_succeed(self, collector):
        c = collector.client
        c.get_repo = AsyncMock(return_value=_ok_response(_empty_repo_payload()))
        c.get_issues = AsyncMock(return_value=_ok_response([]))
        c.get_pulls = AsyncMock(return_value=_ok_response([]))
        c.get_releases = AsyncMock(return_value=_ok_response([]))
        c.get_branch_protection = AsyncMock(return_value=_ok_response({}))

        result = await collector.collect("https://github.com/o/r")

        assert result.collector_status == {
            "repository": "ok",
            "issues": "ok",
            "pull_requests": "ok",
            "releases": "ok",
            "branch_protection": "ok",
        }


class TestRateLimitMidRun:
    @pytest.mark.asyncio
    async def test_rate_limited_collector_is_tagged_others_continue(self, collector):
        c = collector.client
        c.get_repo = AsyncMock(return_value=_ok_response(_empty_repo_payload()))
        c.get_issues = AsyncMock(side_effect=RateLimitError(reset_at=None))
        c.get_pulls = AsyncMock(return_value=_ok_response([]))
        c.get_releases = AsyncMock(return_value=_ok_response([]))
        c.get_branch_protection = AsyncMock(return_value=_ok_response({}))

        result = await collector.collect("https://github.com/o/r")

        assert result.collector_status["repository"] == "ok"
        assert result.collector_status["issues"] == "rate_limited"
        assert result.collector_status["pull_requests"] == "ok"
        assert result.collector_status["releases"] == "ok"
        assert result.collector_status["branch_protection"] == "ok"


class TestHTTPErrorMidRun:
    @pytest.mark.asyncio
    async def test_500_response_is_tagged_with_code(self, collector):
        c = collector.client
        c.get_repo = AsyncMock(return_value=APIResponse(status_code=500, data={}, headers={}))
        c.get_issues = AsyncMock(return_value=_ok_response([]))
        c.get_pulls = AsyncMock(return_value=_ok_response([]))
        c.get_releases = AsyncMock(return_value=_ok_response([]))
        c.get_branch_protection = AsyncMock(return_value=_ok_response({}))

        result = await collector.collect("https://github.com/o/r")

        assert result.collector_status["repository"] == "http_error:500"
        # Repo defaults are intact (the field was never assigned because the
        # collector raised before that line).
        assert result.repository.stars == 0


class TestUnexpectedException:
    @pytest.mark.asyncio
    async def test_arbitrary_exception_is_tagged_error(self, collector):
        c = collector.client
        c.get_repo = AsyncMock(return_value=_ok_response(_empty_repo_payload()))
        c.get_issues = AsyncMock(side_effect=ValueError("boom"))
        c.get_pulls = AsyncMock(return_value=_ok_response([]))
        c.get_releases = AsyncMock(return_value=_ok_response([]))
        c.get_branch_protection = AsyncMock(return_value=_ok_response({}))

        result = await collector.collect("https://github.com/o/r")

        assert result.collector_status["issues"] == "error"
        # Other collectors still ran.
        assert result.collector_status["repository"] == "ok"
        assert result.collector_status["releases"] == "ok"


class TestBranchProtection404IsOk:
    """GitHub returns 404 from the branch-protection endpoint when the default
    branch has no protection rules. That is a normal repo state, not an error,
    so the collector must tag it ok with default_branch_protected=False."""

    @pytest.mark.asyncio
    async def test_branch_protection_404_marks_ok(self, collector):
        c = collector.client
        c.get_repo = AsyncMock(return_value=_ok_response(_empty_repo_payload()))
        c.get_issues = AsyncMock(return_value=_ok_response([]))
        c.get_pulls = AsyncMock(return_value=_ok_response([]))
        c.get_releases = AsyncMock(return_value=_ok_response([]))
        c.get_branch_protection = AsyncMock(
            side_effect=HTTPError("Client error: 404", status_code=404)
        )

        result = await collector.collect("https://github.com/o/r")

        assert result.collector_status["branch_protection"] == "ok"
        assert result.branch_protection.default_branch_protected is False

    @pytest.mark.asyncio
    async def test_branch_protection_other_4xx_is_tagged_error(self, collector):
        c = collector.client
        c.get_repo = AsyncMock(return_value=_ok_response(_empty_repo_payload()))
        c.get_issues = AsyncMock(return_value=_ok_response([]))
        c.get_pulls = AsyncMock(return_value=_ok_response([]))
        c.get_releases = AsyncMock(return_value=_ok_response([]))
        c.get_branch_protection = AsyncMock(
            side_effect=HTTPError("Client error: 401", status_code=401)
        )

        result = await collector.collect("https://github.com/o/r")

        assert result.collector_status["branch_protection"] == "http_error:401"


class TestPreFlightRateLimitSkip:
    @pytest.mark.asyncio
    async def test_collector_skipped_when_remaining_below_min_calls(self, collector):
        c = collector.client
        c.rate_limit = RateLimitInfo(remaining=0, limit=60)
        c.get_repo = AsyncMock(return_value=_ok_response(_empty_repo_payload()))
        c.get_issues = AsyncMock(return_value=_ok_response([]))
        c.get_pulls = AsyncMock(return_value=_ok_response([]))
        c.get_releases = AsyncMock(return_value=_ok_response([]))
        c.get_branch_protection = AsyncMock(return_value=_ok_response({}))

        result = await collector.collect("https://github.com/o/r")

        # Every collector requires at least 1 call; with remaining=0 they all skip.
        assert all(v == "skipped_rate_limit" for v in result.collector_status.values())
        # And we made zero API calls.
        c.get_repo.assert_not_called()
        c.get_issues.assert_not_called()
