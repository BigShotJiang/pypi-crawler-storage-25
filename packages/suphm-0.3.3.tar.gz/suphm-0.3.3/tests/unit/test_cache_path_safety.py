"""Regression tests for CacheManager.get_repo_path() path-traversal safety.

Pre-fix behaviour: get_repo_path stripped the URL scheme then concatenated
the rest as a path. ``https://github.com/x/../../tmp/pwn`` resolved to
``/tmp/pwn``, escaping the cache root. Downstream consumers of the path
(``git clone``, ``save_repo_metadata``, ``delete_clone``, ``clear_repo``)
all wrote / cleaned-up against the escaped location.

Post-fix behaviour: the URL is parsed, every component is checked for
empty / dot / dotdot / backslash / leading-dash, and the final resolved
path is verified to stay under ``repos_dir``. Hostile URLs raise
ValueError before any filesystem operation runs.
"""

from __future__ import annotations

import pytest

from suphm.cache.manager import CacheManager


@pytest.fixture
def manager(tmp_path):
    return CacheManager(base_dir=tmp_path)


class TestRepoPathSafety:
    def test_clean_https_url_resolves_inside_cache(self, manager, tmp_path):
        path = manager.get_repo_path("https://github.com/expressjs/express")
        assert path.is_relative_to(tmp_path.resolve())
        assert str(path).endswith("github.com/expressjs/express")

    def test_strips_dot_git_suffix(self, manager, tmp_path):
        path = manager.get_repo_path("https://github.com/x/y.git")
        assert path.is_relative_to(tmp_path.resolve())
        assert not str(path).endswith(".git")

    def test_short_form_works(self, manager, tmp_path):
        # Some callers pass a host-relative form (no scheme).
        path = manager.get_repo_path("github.com/x/y")
        assert path.is_relative_to(tmp_path.resolve())

    def test_rejects_parent_traversal(self, manager):
        with pytest.raises(ValueError, match="traversal"):
            manager.get_repo_path("https://github.com/x/../../tmp/pwn")

    def test_rejects_embedded_empty_component(self, manager):
        with pytest.raises(ValueError, match="traversal"):
            manager.get_repo_path("https://github.com/x//y")

    def test_rejects_dot_component(self, manager):
        with pytest.raises(ValueError, match="traversal"):
            manager.get_repo_path("https://github.com/./y")

    def test_rejects_backslash(self, manager):
        with pytest.raises(ValueError, match="suspicious"):
            manager.get_repo_path("https://github.com/x/y\\z")

    def test_rejects_leading_dash_component(self, manager):
        with pytest.raises(ValueError, match="suspicious"):
            manager.get_repo_path("https://github.com/--upload-pack=x/y")

    def test_rejects_null_byte(self, manager):
        with pytest.raises(ValueError, match="null byte"):
            manager.get_repo_path("https://github.com/x\x00/y")

    def test_get_repo_metadata_inherits_protection(self, manager):
        # Downstream consumers of get_repo_path must also raise on hostile URLs
        # rather than silently writing somewhere unexpected.
        with pytest.raises(ValueError, match="traversal"):
            manager.get_repo_metadata("https://github.com/x/../../etc/passwd")

    def test_save_repo_metadata_inherits_protection(self, manager):
        with pytest.raises(ValueError, match="traversal"):
            manager.save_repo_metadata("https://github.com/x/../../etc/passwd", {"x": 1})

    def test_clear_repo_inherits_protection(self, manager):
        with pytest.raises(ValueError, match="traversal"):
            manager.clear_repo("https://github.com/x/../../tmp/pwn")
