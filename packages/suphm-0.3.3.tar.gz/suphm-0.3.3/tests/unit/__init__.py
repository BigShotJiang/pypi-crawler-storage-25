"""Unit tests for suphm."""
