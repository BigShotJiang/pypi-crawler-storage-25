"""Regression tests for pipeline reliability fixes.

Covers:
- Atomic cache writes (no torn JSON when two processes race on the same PURL)
- analyze_batch survives a per-PURL exception instead of aborting everything
- AnalysisResult._build_summary tolerates a malformed self.purl
"""

from __future__ import annotations

import json
from datetime import datetime
from unittest.mock import patch

import pytest

from suphm.analysis.pipeline import (
    AnalysisPipeline,
    AnalysisResult,
)
from suphm.cache.manager import _atomic_json_dump
from suphm.discovery import DiscoveryResult


class TestAtomicCacheWrite:
    def test_atomic_dump_replaces_existing_file(self, tmp_path):
        target = tmp_path / "out.json"
        target.write_text('{"old": true}')
        _atomic_json_dump(target, {"new": True})
        assert json.loads(target.read_text()) == {"new": True}

    def test_atomic_dump_creates_parent_dirs(self, tmp_path):
        target = tmp_path / "a" / "b" / "out.json"
        _atomic_json_dump(target, {"k": 1})
        assert json.loads(target.read_text()) == {"k": 1}

    def test_atomic_dump_cleans_temp_on_failure(self, tmp_path):
        target = tmp_path / "out.json"

        # Force a serialization failure midway through. default=str will be
        # invoked for any non-JSON-native value; raising from __repr__
        # (which str() calls when there is no __str__) propagates up.
        class Boom:
            def __repr__(self):
                raise RuntimeError("nope")

        with pytest.raises(RuntimeError):
            _atomic_json_dump(target, {"bad": Boom()})

        # No stray .tmp files left behind in the parent directory.
        leftovers = [p.name for p in tmp_path.iterdir()]
        assert not any(p.endswith(".tmp") for p in leftovers), leftovers
        assert not target.exists()

    def test_atomic_dump_is_used_by_save_package_data(self):
        """save_package_data must route through _atomic_json_dump rather than
        a raw open()/json.dump pair, otherwise concurrent runs on the same
        PURL can corrupt the cache file."""
        import inspect

        from suphm.cache import manager as mgr_mod
        src = inspect.getsource(mgr_mod.CacheManager.save_package_data)
        assert "_atomic_json_dump" in src
        # And that the user-profile + repo-metadata writers also use it.
        assert "_atomic_json_dump" in inspect.getsource(mgr_mod.CacheManager.save_user_profile)
        assert "_atomic_json_dump" in inspect.getsource(mgr_mod.CacheManager.save_repo_metadata)


class TestBatchResilience:
    @pytest.mark.asyncio
    async def test_batch_survives_one_failure(self, tmp_path):
        with patch("suphm.analysis.pipeline.get_config") as cfg, \
             patch("suphm.cache.manager.get_config") as cache_cfg:
            cfg.return_value.cache.directory = tmp_path
            cache_cfg.return_value.cache.directory = tmp_path
            pipeline = AnalysisPipeline(cache_dir=tmp_path)

            async def fake_analyze(purl, **kwargs):
                if "boom" in purl:
                    raise RuntimeError("simulated upstream failure")
                return AnalysisResult(purl=purl, analyzed_at=datetime.now())

            with patch.object(pipeline, "analyze", side_effect=fake_analyze):
                results = await pipeline.analyze_batch(
                    ["pkg:npm/ok-a", "pkg:npm/boom", "pkg:npm/ok-b"],
                    concurrency=3,
                )

        # All three slots are populated; the boom case has a captured error.
        assert [r.purl for r in results] == ["pkg:npm/ok-a", "pkg:npm/boom", "pkg:npm/ok-b"]
        assert results[0].errors == []
        assert results[2].errors == []
        assert any("simulated upstream failure" in e for e in results[1].errors)


class TestSummaryReparseGuard:
    def test_build_summary_tolerates_malformed_purl(self, tmp_path):
        result = AnalysisResult(purl="not-a-purl::::", analyzed_at=datetime.now())
        result.discovery = DiscoveryResult(
            purl="not-a-purl::::",
            name="recovered-name",
            version="9.9.9",
            repository_url="https://example.com/foo/bar",
        )
        # Pre-fix this would raise inside PURLParser.parse and abort to_dict().
        out = result.to_dict()
        assert out["summary"]["package_name"] == "recovered-name"
        assert out["summary"]["version"] == "9.9.9"
