"""Integration tests for suphm."""
