"""Backward-compatible re-export. Prefer `praisonai.scheduler`.

This module is deprecated. Use the canonical implementation in the
scheduler package for full functionality including async support.
"""

import warnings

warnings.warn(
    "praisonai.async_agent_scheduler is pending deprecation; it will be moved to "
    "praisonai.scheduler.async_agent_scheduler in a future release. Continue "
    "importing from praisonai.async_agent_scheduler until then.",
    PendingDeprecationWarning,
    stacklevel=2,
)

# TODO: Once AsyncAgentScheduler is moved to scheduler package, import from there
# For now, re-export the existing implementation to avoid breaking changes
from .scheduler.shared import ScheduleParser, backoff_delay, safe_call
import asyncio
import logging
import threading
from datetime import datetime
from typing import Optional, Dict, Any, Callable, Union
from abc import ABC, abstractmethod

logger = logging.getLogger(__name__)


class AsyncAgentExecutorInterface(ABC):
    """Abstract interface for async agent execution."""
    
    @abstractmethod
    async def execute(self, task: str) -> Any:
        """Execute the agent with given task asynchronously."""
        pass


class AsyncPraisonAgentExecutor(AsyncAgentExecutorInterface):
    """Async executor for PraisonAI agents."""
    
    def __init__(self, agent):
        """
        Initialize executor with a PraisonAI agent.
        
        Args:
            agent: PraisonAI Agent instance
        """
        self.agent = agent
        
    async def execute(self, task: str) -> Any:
        """
        Execute the agent with the given task.
        
        Args:
            task: Task description to execute
            
        Returns:
            Agent execution result
        """
        try:
            # Check if agent has async support
            if hasattr(self.agent, 'astart'):
                result = await self.agent.astart(task)
            elif hasattr(self.agent, 'start'):
                # Wrap sync call in executor
                result = await asyncio.to_thread(self.agent.start, task)
            else:
                raise AttributeError("Agent must have either 'start' or 'astart' method")
            return result
        except Exception as e:
            logger.error(f"Async agent execution failed: {e}")
            raise


class AsyncAgentScheduler:
    """
    Async-native scheduler for running PraisonAI agents periodically.
    
    Features:
    - Proper async/await execution
    - Cancellation support  
    - No global state pollution
    - Native async coordination
    
    Example:
        scheduler = AsyncAgentScheduler(agent, task="Check news")
        await scheduler.start(schedule_expr="hourly")
        await asyncio.sleep(3600)  # Let it run
        await scheduler.stop()
    """
    
    def __init__(
        self,
        agent,
        task: str,
        config: Optional[Dict[str, Any]] = None,
        on_success: Optional[Callable] = None,
        on_failure: Optional[Callable] = None
    ):
        """
        Initialize async agent scheduler.
        
        Args:
            agent: PraisonAI Agent instance
            task: Task description to execute
            config: Optional configuration dict
            on_success: Callback function on successful execution
            on_failure: Callback function on failed execution
        """
        self.agent = agent
        self.task = task
        self.config = config or {}
        self.on_success = on_success
        self.on_failure = on_failure
        
        self.is_running = False
        self._task: Optional[asyncio.Task] = None
        self._executor = AsyncPraisonAgentExecutor(agent)
        self._execution_count = 0
        self._success_count = 0
        self._failure_count = 0
        
        # Sync lock for async primitives creation and bound loop tracking
        self._primitives_lock = threading.Lock()
        self._stop_event: Optional[asyncio.Event] = None
        self._cancel_event: Optional[asyncio.Event] = None
        self._stats_lock: Optional[asyncio.Lock] = None
        self._bound_loop: Optional[asyncio.AbstractEventLoop] = None

    def _ensure_async_primitives(self) -> None:
        """Create async primitives if they don't exist yet.
        
        Thread-safe and loop-aware: primitives are bound to the current running loop.
        If called from a different loop, new primitives are created.
        """
        loop = asyncio.get_running_loop()  # must be called from a coroutine
        
        with self._primitives_lock:
            if self._bound_loop is not loop:
                self._stop_event = asyncio.Event()
                self._cancel_event = asyncio.Event()
                self._stats_lock = asyncio.Lock()
                self._bound_loop = loop


    async def start(
        self,
        schedule_expr: str,
        max_retries: int = 3,
        run_immediately: bool = False
    ) -> bool:
        """
        Start scheduled agent execution.
        
        Args:
            schedule_expr: Schedule expression (e.g., "hourly", "*/6h", "3600")
            max_retries: Maximum retry attempts on failure
            run_immediately: If True, run agent immediately before starting schedule
            
        Returns:
            True if scheduler started successfully
        """
        if self.is_running:
            logger.warning("Async scheduler is already running")
            return False
            
        try:
            interval = ScheduleParser.parse(schedule_expr)
            self.is_running = True
            self._ensure_async_primitives()  # NEW — bind to the loop start() runs on
            self._stop_event.clear()
            
            logger.info(f"Starting async agent scheduler: {getattr(self.agent, 'name', 'Agent')}")
            logger.info(f"Task: {self.task}")
            logger.info(f"Schedule: {schedule_expr} ({interval}s interval)")
            
            # Run immediately if requested
            if run_immediately:
                logger.info("Running agent immediately before starting schedule...")
                await self._execute_with_retry(max_retries)
            
            # Start background task
            self._task = asyncio.create_task(
                self._run_schedule(interval, max_retries)
            )
            
            logger.info("Async agent scheduler started successfully")
            return True
            
        except Exception as e:
            logger.error(f"Failed to start async scheduler: {e}")
            self.is_running = False
            return False
    
    async def stop(self) -> bool:
        """
        Stop the scheduler gracefully.
        
        IMPORTANT: This method must be called from the same event loop
        that was used to start the scheduler.
        
        Returns:
            True if stopped successfully
            
        Raises:
            RuntimeError: If called from a different event loop than start()
        """
        if not self.is_running:
            logger.info("Async scheduler is not running")
            return True
        
        logger.info("Stopping async agent scheduler...")
        
        # _stop_event is guaranteed non-None after a successful start()
        if self._stop_event is None:
            logger.warning("stop() called before start(); nothing to stop.")
            self.is_running = False
            return True
            
        # Ensure we're on the same loop that was bound during start()
        current_loop = asyncio.get_running_loop()
        if self._bound_loop is not None and current_loop is not self._bound_loop:
            raise RuntimeError(
                "stop() must be called from the same event loop as start(). "
                f"Expected: {self._bound_loop}, got: {current_loop}"
            )
            
        self._stop_event.set()
        
        try:
            if self._task:
                try:
                    await asyncio.wait_for(self._task, timeout=10)
                except asyncio.TimeoutError:
                    logger.warning("Scheduler task didn't stop gracefully, cancelling")
                    self._task.cancel()
                    try:
                        await self._task
                    except asyncio.CancelledError:
                        pass
                    except Exception as e:
                        logger.error(f"Scheduler task raised on cancel: {e}")
                except asyncio.CancelledError:
                    # Task already cancelled; treat as expected during shutdown
                    pass
                except Exception as e:
                    logger.error(f"Scheduler task raised during stop: {e}")
        finally:
            self.is_running = False
        
        logger.info("Async agent scheduler stopped")
        
        # Log final stats with consistent snapshot
        if self._stats_lock is not None:
            async with self._stats_lock:
                total = self._execution_count
                ok = self._success_count
                fail = self._failure_count
        else:
            total = self._execution_count
            ok = self._success_count
            fail = self._failure_count
        logger.info(f"Execution stats - Total: {total}, Success: {ok}, Failed: {fail}")
        return True
    
    async def get_stats(self) -> Dict[str, Any]:
        """
        Get current execution statistics (synchronous, best-effort).
        
        Warning: This method provides a best-effort view of stats without
        guaranteeing atomicity. For consistent snapshots in async context,
        use get_stats_async() instead.
        
        Returns:
            Dictionary with execution stats
        """
        # Primitives are created lazily in _ensure_async_primitives(); if not yet
        # initialized there are no concurrent writers, so a direct read is safe.
        if self._stats_lock is not None:
            async with self._stats_lock:
                total = self._execution_count
                ok = self._success_count
                fail = self._failure_count
                running = self.is_running
        else:
            total = self._execution_count
            ok = self._success_count
            fail = self._failure_count
            running = self.is_running
            
        return {
            "is_running": running,
            "total_executions": total,
            "successful_executions": ok,
            "failed_executions": fail,
            "success_rate": (ok / total * 100) if total > 0 else 0
        }
    
    async def get_stats_async(self) -> Dict[str, Any]:
        """
        Get current execution statistics with atomic snapshot (async).
        
        Returns:
            Dictionary with execution stats
        """
        if self._stats_lock is None:
            # Not yet started: stats are all zero, no lock needed
            execs, success, failed = 0, 0, 0
        else:
            # Take atomic snapshot of all counters
            async with self._stats_lock:
                execs = self._execution_count
                success = self._success_count
                failed = self._failure_count
        
        return {
            "is_running": self.is_running,
            "total_executions": execs,
            "successful_executions": success,
            "failed_executions": failed,
            "success_rate": (success / execs * 100) if execs > 0 else 0
        }
    
    def get_stats_sync(self) -> Dict[str, Any]:
        """
        Alias for get_stats() for clarity.
        
        Returns:
            Dictionary with execution stats
        """
        return self.get_stats()
    
    async def _run_schedule(self, interval: int, max_retries: int):
        """Internal method to run scheduled agent executions."""
        try:
            self._ensure_async_primitives()
            while not self._stop_event.is_set():
                logger.info(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] Starting async scheduled agent execution")
                
                await self._execute_with_retry(max_retries)
                
                # Wait for next scheduled time or stop event
                logger.info(f"Next execution in {interval} seconds ({interval/3600:.1f} hours)")
                try:
                    await asyncio.wait_for(self._stop_event.wait(), timeout=interval)
                    break  # Stop event was set
                except asyncio.TimeoutError:
                    continue  # Timeout reached, continue with next execution
        finally:
            self.is_running = False
    
    async def _execute_with_retry(self, max_retries: int):
        """Execute agent with retry logic."""
        self._ensure_async_primitives()  # guarantees _stats_lock is bound to current loop

        async with self._stats_lock:
            self._execution_count += 1
        
        last_exc: Optional[Exception] = None
        for attempt in range(max_retries):
            try:
                logger.info(f"Async attempt {attempt + 1}/{max_retries}")
                result = await self._executor.execute(self.task)
                
                logger.info(f"Async agent execution successful on attempt {attempt + 1}")
                logger.info(f"Result: {result}")
                
                async with self._stats_lock:
                    self._success_count += 1
                safe_call(self.on_success, result)
                return
                
            except Exception as e:
                last_exc = e
                logger.error(f"Async agent execution failed on attempt {attempt + 1}: {e}")
                
                if attempt < max_retries - 1:
                    wait_time = backoff_delay(attempt)
                    logger.info(f"Waiting {wait_time}s before async retry...")
                    await asyncio.sleep(wait_time)
        
        async with self._stats_lock:
            self._failure_count += 1
        logger.error(f"Async agent execution failed after {max_retries} attempts")
        safe_call(
            self.on_failure,
            last_exc if last_exc is not None
            else RuntimeError(f"Failed after {max_retries} attempts")
        )
    
    async def execute_once(self) -> Any:
        """
        Execute agent immediately (one-time execution).
        
        Returns:
            Agent execution result
        """
        logger.info("Executing agent once (async)")
        try:
            result = await self._executor.execute(self.task)
            logger.info(f"One-time async execution successful: {result}")
            return result
        except Exception as e:
            logger.error(f"One-time async execution failed: {e}")
            raise


def create_async_agent_scheduler(
    agent,
    task: str,
    config: Optional[Dict[str, Any]] = None
) -> AsyncAgentScheduler:
    """
    Factory function to create async agent scheduler.
    
    Args:
        agent: PraisonAI Agent instance
        task: Task description
        config: Optional configuration
        
    Returns:
        Configured AsyncAgentScheduler instance
    """
    return AsyncAgentScheduler(agent, task, config)