"""concinno-skills-sql — Remote SQL database skills for Concinno.

Opt-in plugin package. When installed alongside ``concinno>=2.15.1`` and
the consumer env sets ``CONCINNO_LOAD_PLUGINS=1``, the tools here
auto-mount into :class:`concinno.tools.registry.ToolRegistry` via the
``[project.entry-points."concinno.tools"]`` table in ``pyproject.toml``.

MVP surface
-----------
- :class:`PostgresQuery` — parameterised SELECT / DML against Postgres
  via SQLAlchemy + ``psycopg[binary]``.
- :class:`MysqlQuery`    — same, against MySQL / MariaDB via
  ``pymysql``.
- :class:`SqliteQuery`   — same, against a local SQLite file (or
  ``:memory:``) via stdlib ``sqlite3``.

Scope separation from Concinno core
-----------------------------------
``concinno.tools.builtin.DuckDbQuery`` (shipped inside Concinno core)
handles **local file** analytical SQL — ``read_csv_auto`` / ``read_parquet``
/ ``read_json_auto``. This sibling package fills the orthogonal need:
connect to a real DB server (Postgres / MySQL) or a persistent SQLite
file. The two do not overlap and can coexist in the same registry.

Safety
------
All tools route through :mod:`concinno_skills_sql._safety`:

1. ``check_connection_url`` — scheme allow-list (postgresql / mysql /
   sqlite only); SQLite paths must live under ``Path.home()`` or
   ``Path.cwd()`` and not under system roots (``/etc``, ``/Windows``,
   …). Optional ``?readonly=1`` flag surfaces and blocks DML.
2. ``check_sql_ddl`` — reject DROP / TRUNCATE / ALTER / CREATE /
   GRANT / REVOKE for both ``query`` and ``exec``. Use your DB's
   migration tool for schema changes.
3. ``check_row_limit`` — clamp query row cap at 10_000.

The real injection defense is SQLAlchemy's parameterised bind
placeholders (``:name``). These guards are defense-in-depth for the
common LLM mistake of concatenating user input into SQL.

License note
------------
This package is Apache-2.0. ``psycopg[binary]`` is **LGPL-3.0**; we
depend on it as a pip dependency (dynamic link) only. See README for
the re-link rights that carries. Consumers who prefer pure-MIT paths
should install without Postgres (``pip install concinno-skills-sql
--no-deps && pip install sqlalchemy pymysql``) and avoid
``PostgresQuery``.

No credentials are stored. ``connection_url`` is passed per call.
Callers wanting credential indirection can either:

- Use env expansion upstream (``os.environ["DATABASE_URL"]``).
- Use Concinno's ``CredentialStore`` ``{"$ref": "env:DATABASE_URL"}``
  shape and resolve before calling.

This package intentionally does not do the env-substitution itself to
keep the Tool surface auditable.
"""
from __future__ import annotations

from concinno_skills_sql.mysql import MysqlQuery
from concinno_skills_sql.postgres import PostgresQuery
from concinno_skills_sql.sqlite import SqliteQuery

__version__ = "0.1.0"
__all__ = [
    "MysqlQuery",
    "PostgresQuery",
    "SqliteQuery",
    "__version__",
]
