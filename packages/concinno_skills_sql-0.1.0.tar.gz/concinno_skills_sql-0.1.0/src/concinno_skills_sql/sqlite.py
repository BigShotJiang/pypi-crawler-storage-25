"""concinno_skills_sql.sqlite — SqliteQuery Concinno Tool.

@module sqlite
@responsibility Implement the Concinno :class:`Tool` protocol for
    executing parameterised SELECT / INSERT / UPDATE / DELETE against
    a SQLite database file (or ``:memory:``). Uses stdlib ``sqlite3``
    via SQLAlchemy's built-in dialect — no external driver package is
    needed. Intentionally separate from the Concinno-core
    ``DuckDbQuery`` tool: that one targets ad-hoc analytical queries
    over CSV / Parquet / JSON via ``read_csv_auto`` etc.; this one
    targets persistent SQLite DB files (e.g. an application's
    on-disk DB).
@dependencies SQLAlchemy 2.0+ (MIT); ``sqlite3`` from CPython stdlib.
@exports SqliteQuery

Path-safety
-----------
``_safety.check_connection_url`` rejects sqlite paths outside
``Path.home()`` / ``Path.cwd()`` and system directories
(``/etc``, ``/Windows``, …). ``:memory:`` is allowed unconditionally.

Concurrency note
----------------
``is_concurrency_safe = False``. SQLite serialises writes at the
file-lock level, and we create a fresh engine per call. Serialised
dispatch lines up with the DB.
"""

from __future__ import annotations

from typing import Any

from concinno_skills_sql._executor import execute_dml, execute_query
from concinno_skills_sql._safety import (
    check_connection_url,
    check_row_limit,
    check_sql_ddl,
)

_VALID_ACTIONS = frozenset({"query", "exec"})


class SqliteQuery:
    """Run parameterised SQL against a local SQLite DB file.

    Params accepted via ``call(**kwargs)``:
        action (str):          ``"query"`` or ``"exec"``.
        connection_url (str):  ``sqlite:///path/to/file.db`` (path must
                               live under home or cwd) or
                               ``sqlite:///:memory:`` for a scratch DB.
                               Append ``?readonly=1`` to block ``exec``.
        sql (str):             SQL with ``:name`` bind placeholders.
                               DDL rejected.
        params (dict | None):  Bind parameters.
        limit (int):           Row cap (default 100, max 10_000).

    Returns:
        query: ``{"rows": [...], "count": N, "columns": [...]}``.
        exec:  ``{"ok": True, "rowcount": N}``.
        error: ``{"error": "..."}``.
    """

    name: str = "sqlite_query"
    description: str = (
        "Query or modify a local SQLite DB via parameterised SQL. "
        "Params: action='query'|'exec', connection_url "
        "(sqlite:///path.db under home/cwd, or sqlite:///:memory:; "
        "append ?readonly=1 to block DML), sql (:name-bound, "
        "DDL rejected), params (dict), limit (<=10000)."
    )
    is_concurrency_safe: bool = False

    def call(self, **kwargs: Any) -> Any:
        action = kwargs.get("action")
        if action not in _VALID_ACTIONS:
            return {"error": f"action must be 'query' or 'exec', got {action!r}"}

        url_check = check_connection_url(kwargs.get("connection_url"))
        if isinstance(url_check, dict):
            return url_check
        connection_url, readonly = url_check
        if not connection_url.lower().startswith("sqlite"):
            return {
                "error": (
                    "SqliteQuery: connection_url must use the 'sqlite' "
                    "scheme (e.g. sqlite:///path/to/file.db)"
                )
            }

        sql_check = check_sql_ddl(kwargs.get("sql"))
        if isinstance(sql_check, dict):
            return sql_check
        sql: str = sql_check

        params = kwargs.get("params")
        if params is not None and not isinstance(params, dict):
            return {"error": "params must be a dict when provided"}

        if action == "query":
            limit_check = check_row_limit(kwargs.get("limit"))
            if isinstance(limit_check, dict):
                return limit_check
            limit: int = limit_check
            return execute_query(
                connection_url=connection_url,
                sql=sql,
                params=params,
                limit=limit,
                readonly=readonly,
                tool_name="SqliteQuery",
            )

        return execute_dml(
            connection_url=connection_url,
            sql=sql,
            params=params,
            readonly=readonly,
            tool_name="SqliteQuery",
        )


__all__ = ["SqliteQuery"]
