"""concinno_skills_sql._safety — shared SQL + connection-URL guard.

@module _safety
@responsibility Central safety-check module used by every SQL tool
    (``PostgresQuery`` / ``MysqlQuery`` / ``SqliteQuery``).

    Three separable checks:

    1. :func:`check_connection_url` — validate the SQLAlchemy URL scheme
       (reject ``ftp://`` / bare strings / foreign schemes) and detect
       the optional ``?readonly=1`` query flag. SQLite paths additionally
       must live under ``Path.home()`` / ``Path.cwd()`` to block
       ``sqlite:////etc/passwd``-style reads.
    2. :func:`check_sql_ddl` — reject DDL keywords (``DROP`` / ``TRUNCATE``
       / ``ALTER`` / ``CREATE`` / ``GRANT`` / ``REVOKE``) for both
       ``query`` and ``exec`` actions. An agent should not drop a
       production schema by mistake.
    3. :func:`check_row_limit` — cap ``limit`` at 10_000 so a bad
       ``SELECT * FROM huge_table`` doesn't exhaust the calling agent's
       context window.

The checks live here (not duplicated in each tool) because we want a
single source of truth — CC's review culture says a thing that can drop
a database must be obvious and auditable.

Safety rationale
----------------
SQLAlchemy's text execution + ``connection.execute(text(sql), params)``
parameter binding is the real defense against injection — these guards
are defense-in-depth for the common LLM mistake of concatenating user
input into SQL. We do not pretend to be a full SQL parser; we match
DDL keywords with word boundaries and reject outright rather than try
to rewrite.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import TypeAlias
from urllib.parse import urlparse

# Return type shared with the tool modules — resolved URL or a
# ``{"error": "..."}`` dict. Narrowing happens via ``isinstance(...,
# ParsedUrl)`` in the tool's ``call``.
ParsedUrl: TypeAlias = "tuple[str, bool]"
SafeUrlResult: TypeAlias = "ParsedUrl | dict[str, str]"
SafeSqlResult: TypeAlias = "str | dict[str, str]"
SafeLimitResult: TypeAlias = "int | dict[str, str]"


# Hard cap so a broken ``limit`` (or none at all) cannot pull a 10M-row
# table into the agent's context. Agents can still ``LIMIT`` inside SQL
# if they want more specific paging.
MAX_ROW_LIMIT: int = 10_000
DEFAULT_ROW_LIMIT: int = 100


# Allow-list. Anything else (``ftp``, ``file``, bare strings, …) is
# rejected. We deliberately keep the list short — consumers who want
# Oracle / MSSQL can ship their own sibling package.
_ALLOWED_SCHEMES: frozenset[str] = frozenset(
    {
        "postgresql",
        "postgresql+psycopg",
        "postgresql+psycopg2",
        "postgresql+asyncpg",
        "mysql",
        "mysql+pymysql",
        "sqlite",
    }
)


# Word-boundary regex so ``description`` column isn't treated as DDL
# because it starts with ``de``. Case-insensitive to cover agent sloppy
# formatting. Matches only keywords that are destructive at the schema
# or permission level.
_DDL_PATTERN = re.compile(
    r"\b(DROP|TRUNCATE|ALTER|CREATE|GRANT|REVOKE)\b",
    re.IGNORECASE,
)


# Block well-known system roots so a SQLite URL cannot read system
# files. Belt-and-braces for the ``HOME=/`` edge case (mirrors the
# concinno-skills-office ``_safety`` pattern).
_BLOCKED_ROOTS: tuple[str, ...] = (
    "/etc",
    "/System",
    "/usr/bin",
    "/usr/sbin",
    "/boot",
    "/root",
    "/bin",
    "/sbin",
    "/dev",
    "/proc",
    "/sys",
    "/Windows",
    "/Program Files",
    "/Program Files (x86)",
)


def _is_under(candidate: Path, parent: Path) -> bool:
    """Return True when ``candidate`` is ``parent`` or a descendant."""
    try:
        return candidate.is_relative_to(parent)
    except ValueError:
        return False


def _check_sqlite_path(url: str) -> SafeUrlResult:
    """Validate a ``sqlite:///...`` URL's filesystem target.

    SQLAlchemy sqlite URL shapes::

        sqlite:///relative/path.db        (3 slashes, relative)
        sqlite:////absolute/path.db       (4 slashes, absolute POSIX)
        sqlite:///C:/abs/path.db          (3 slashes, Windows abs)
        sqlite:///:memory:                (in-memory, allowed)

    We allow ``:memory:`` unconditionally (it is obvious test/temporary
    use). File-backed DBs must live under ``Path.home()`` or
    ``Path.cwd()`` after resolve, mirroring the concinno-skills-office
    output-path guard. The ``readonly`` flag is propagated out so the
    tool ``call`` can refuse DML later.

    Returns ``(rewritten_url, readonly)`` on success, ``{"error":…}``
    on failure.
    """
    # Split off any SQLAlchemy-style query string (``?readonly=1``).
    readonly = False
    if "?" in url:
        base, _, qs = url.partition("?")
        if "readonly=1" in qs or "readonly=true" in qs.lower():
            readonly = True
        # Strip the query string — SQLAlchemy's sqlite driver doesn't
        # understand our custom ``readonly`` flag, we handle it in the
        # tool wrapper.
        url_no_qs = base
    else:
        url_no_qs = url

    # Extract the path portion after ``sqlite:///``.
    prefix = "sqlite:///"
    if not url_no_qs.startswith(prefix):
        return {"error": f"malformed sqlite URL: {url!r}"}
    path_part = url_no_qs[len(prefix) :]

    if path_part == ":memory:" or path_part == "":
        # In-memory — harmless, allow. Empty also treated as in-memory
        # by SQLAlchemy.
        return (url_no_qs, readonly)

    # Three-slash absolute POSIX paths round-trip as "/path/..." (the
    # leading slash survives). On Windows SQLAlchemy uses
    # ``sqlite:///C:/path/...``.
    try:
        resolved = Path(path_part).expanduser().resolve(strict=False)
    except (OSError, RuntimeError) as exc:
        return {"error": f"cannot resolve sqlite path: {exc}"}

    resolved_str = str(resolved).replace("\\", "/")
    for blocked in _BLOCKED_ROOTS:
        if resolved_str == blocked or resolved_str.startswith(blocked + "/"):
            return {
                "error": (
                    f"sqlite path must be under home or cwd, not system "
                    f"directory: {blocked}"
                )
            }

    try:
        home = Path.home().resolve(strict=False)
        cwd = Path.cwd().resolve(strict=False)
    except (OSError, RuntimeError) as exc:
        return {"error": f"cannot determine home/cwd: {exc}"}

    if _is_under(resolved, home) or _is_under(resolved, cwd):
        return (url_no_qs, readonly)

    return {
        "error": (
            "sqlite path must be under home directory or current working "
            "directory (traversal into system paths is blocked)"
        )
    }


def check_connection_url(raw: object) -> SafeUrlResult:
    """Validate a SQLAlchemy connection URL.

    Returns ``(rewritten_url, readonly_flag)`` on success (caller uses
    the rewritten URL to construct the engine; the readonly_flag gates
    DML later), or ``{"error": "..."}`` on failure.

    Rules:
        1. Non-empty string.
        2. Scheme in :data:`_ALLOWED_SCHEMES` (no ``ftp``, ``file``,
           ``oracle``, ``mssql``, …).
        3. Optional ``?readonly=1`` (or ``?readonly=true``) query flag
           is stripped and surfaced via the return tuple.
        4. SQLite URLs additionally pass :func:`_check_sqlite_path`.
    """
    if not isinstance(raw, str) or not raw.strip():
        return {"error": "connection_url must be a non-empty string"}

    # ``urlparse`` keeps the scheme lowercase; we compare to lowercase
    # allow-list. It also safely returns an empty scheme for
    # things like ``/tmp/x.db`` — we reject those.
    parsed = urlparse(raw)
    scheme = parsed.scheme.lower()
    if not scheme:
        return {
            "error": (
                "connection_url must include a scheme "
                "(postgresql / mysql / sqlite)"
            )
        }
    if scheme not in _ALLOWED_SCHEMES:
        return {
            "error": (
                f"connection_url scheme {scheme!r} not allowed. "
                f"Use one of: postgresql, mysql, sqlite (with optional "
                f"+psycopg / +pymysql driver suffix)."
            )
        }

    # For sqlite, validate the filesystem path too.
    if scheme == "sqlite":
        return _check_sqlite_path(raw)

    # For postgres / mysql, the ``readonly=1`` flag may live in the
    # query string. Detect it; SQLAlchemy ignores unknown flags so
    # we leave the URL intact.
    readonly = False
    if parsed.query:
        q = parsed.query.lower()
        if "readonly=1" in q or "readonly=true" in q:
            readonly = True

    return (raw, readonly)


def check_sql_ddl(raw: object) -> SafeSqlResult:
    """Reject DDL keywords (DROP / TRUNCATE / ALTER / CREATE / GRANT
    / REVOKE) in any SQL statement.

    Returns the sql string on success, ``{"error":…}`` on failure.

    Implementation note: we match with ``\\b`` word boundaries so a
    column literally named ``created_at`` passes (the ``CREATE`` match
    is against ``CREATE TABLE foo`` shape). Comments inside the SQL
    are not stripped — a ``-- DROP TABLE x`` is also rejected, which
    is the safe side to err on.
    """
    if not isinstance(raw, str) or not raw.strip():
        return {"error": "sql must be a non-empty string"}

    match = _DDL_PATTERN.search(raw)
    if match:
        return {
            "error": (
                f"DDL keyword {match.group(0).upper()!r} is not allowed. "
                f"Use your DB's migration tool for schema changes."
            )
        }
    return raw


def check_row_limit(raw: object) -> SafeLimitResult:
    """Clamp the ``limit`` kwarg.

    Missing → :data:`DEFAULT_ROW_LIMIT` (100).
    Int in ``[1, MAX_ROW_LIMIT]`` → passthrough.
    Otherwise → ``{"error":…}``.
    """
    if raw is None:
        return DEFAULT_ROW_LIMIT
    if not isinstance(raw, int) or isinstance(raw, bool):
        return {"error": "limit must be an integer when provided"}
    if raw <= 0:
        return {"error": "limit must be a positive integer"}
    if raw > MAX_ROW_LIMIT:
        return {
            "error": (
                f"limit {raw} exceeds MAX_ROW_LIMIT={MAX_ROW_LIMIT}. "
                f"Use pagination (OFFSET / LIMIT in SQL) for larger "
                f"result sets."
            )
        }
    return raw


__all__ = [
    "DEFAULT_ROW_LIMIT",
    "MAX_ROW_LIMIT",
    "ParsedUrl",
    "SafeLimitResult",
    "SafeSqlResult",
    "SafeUrlResult",
    "check_connection_url",
    "check_row_limit",
    "check_sql_ddl",
]
