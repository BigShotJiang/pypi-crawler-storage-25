"""concinno_skills_sql.mysql — MysqlQuery Concinno Tool.

@module mysql
@responsibility Implement the Concinno :class:`Tool` protocol for
    executing parameterised SELECT / INSERT / UPDATE / DELETE against
    a remote MySQL / MariaDB database. SQLAlchemy + ``pymysql`` under
    the hood; this class is a thin dispatch layer over
    :mod:`_executor` — by design a mirror of ``PostgresQuery`` so
    reviewers can diff the two files and see only the scheme / name
    differences.
@dependencies SQLAlchemy 2.0+, pymysql 1.1+ (MIT).
@exports MysqlQuery

Concurrency note
----------------
``is_concurrency_safe = False``. Same rationale as ``PostgresQuery``
— SQLAlchemy connection pool carries engine-level state.
"""

from __future__ import annotations

from typing import Any

from concinno_skills_sql._executor import execute_dml, execute_query
from concinno_skills_sql._safety import (
    check_connection_url,
    check_row_limit,
    check_sql_ddl,
)

_VALID_ACTIONS = frozenset({"query", "exec"})


class MysqlQuery:
    """Run parameterised SQL against a remote MySQL / MariaDB database.

    Params accepted via ``call(**kwargs)``:
        action (str):          ``"query"`` or ``"exec"``.
        connection_url (str):  e.g. ``mysql+pymysql://user:pw@host:3306/db``.
                               Append ``?readonly=1`` to block ``exec``.
        sql (str):             SQL with ``:name`` bind placeholders.
                               DDL rejected.
        params (dict | None):  Bind parameters.
        limit (int):           Row cap for query (default 100, max 10_000).

    Returns:
        query: ``{"rows": [...], "count": N, "columns": [...]}``.
        exec:  ``{"ok": True, "rowcount": N}``.
        error: ``{"error": "..."}``.
    """

    name: str = "mysql_query"
    description: str = (
        "Query or modify a MySQL / MariaDB database via parameterised "
        "SQL. Params: action='query'|'exec', connection_url "
        "(mysql+pymysql://user:pw@host:port/db; append ?readonly=1 "
        "to block DML), sql (:name-bound, DDL rejected), params (dict), "
        "limit (<=10000)."
    )
    is_concurrency_safe: bool = False

    def call(self, **kwargs: Any) -> Any:
        action = kwargs.get("action")
        if action not in _VALID_ACTIONS:
            return {"error": f"action must be 'query' or 'exec', got {action!r}"}

        url_check = check_connection_url(kwargs.get("connection_url"))
        if isinstance(url_check, dict):
            return url_check
        connection_url, readonly = url_check
        if not connection_url.lower().startswith("mysql"):
            return {
                "error": (
                    "MysqlQuery: connection_url must use the 'mysql' "
                    "scheme (e.g. mysql+pymysql://...)"
                )
            }

        sql_check = check_sql_ddl(kwargs.get("sql"))
        if isinstance(sql_check, dict):
            return sql_check
        sql: str = sql_check

        params = kwargs.get("params")
        if params is not None and not isinstance(params, dict):
            return {"error": "params must be a dict when provided"}

        if action == "query":
            limit_check = check_row_limit(kwargs.get("limit"))
            if isinstance(limit_check, dict):
                return limit_check
            limit: int = limit_check
            return execute_query(
                connection_url=connection_url,
                sql=sql,
                params=params,
                limit=limit,
                readonly=readonly,
                tool_name="MysqlQuery",
            )

        return execute_dml(
            connection_url=connection_url,
            sql=sql,
            params=params,
            readonly=readonly,
            tool_name="MysqlQuery",
        )


__all__ = ["MysqlQuery"]
