"""concinno_skills_sql.postgres — PostgresQuery Concinno Tool.

@module postgres
@responsibility Implement the Concinno :class:`Tool` protocol for
    executing parameterised SELECT / INSERT / UPDATE / DELETE against
    a remote PostgreSQL database. SQLAlchemy + ``psycopg[binary]`` under
    the hood; the class itself is a thin dispatch layer over
    :mod:`_executor`.
@dependencies SQLAlchemy 2.0+, psycopg[binary] 3.2+ (LGPL-3.0 — dynamic
    pip link only; see README license notes).
@exports PostgresQuery

Concurrency note
----------------
``is_concurrency_safe = False``. SQLAlchemy connection pools carry
engine-level state (dialect compilation cache, checked-out
connections); serial dispatch keeps the contract simple. Agents that
need parallel reads should issue multiple independent calls; the
:func:`sqlalchemy.create_engine` call inside each ``call`` is
short-lived and ``engine.dispose()`` runs in a ``finally`` block.
"""

from __future__ import annotations

from typing import Any

from concinno_skills_sql._executor import execute_dml, execute_query
from concinno_skills_sql._safety import (
    check_connection_url,
    check_row_limit,
    check_sql_ddl,
)

_VALID_ACTIONS = frozenset({"query", "exec"})


class PostgresQuery:
    """Run parameterised SQL against a remote Postgres database.

    Params accepted via ``call(**kwargs)``:
        action (str):          ``"query"`` (SELECT → rows) or ``"exec"``
                               (INSERT/UPDATE/DELETE → rowcount).
        connection_url (str):  SQLAlchemy URL, e.g.
                               ``postgresql+psycopg://user:pw@host:5432/db``.
                               Append ``?readonly=1`` to block ``exec``.
        sql (str):             SQL statement. DDL (DROP/TRUNCATE/ALTER/
                               CREATE/GRANT/REVOKE) is rejected.
        params (dict | None):  Bind parameters for ``:name`` placeholders
                               (SQLAlchemy's driver-agnostic shape).
        limit (int):           Row cap for query (default 100, max 10_000).
                               Ignored for exec.

    Returns:
        query: ``{"rows": [...], "count": N, "columns": [...]}``.
        exec:  ``{"ok": True, "rowcount": N}``.
        error: ``{"error": "..."}``.
    """

    name: str = "postgres_query"
    description: str = (
        "Query or modify a Postgres database via parameterised SQL. "
        "Params: action='query'|'exec', connection_url "
        "(postgresql+psycopg://user:pw@host:port/db; append ?readonly=1 "
        "to block DML), sql (:name-bound, DDL rejected), params (dict), "
        "limit (<=10000)."
    )
    is_concurrency_safe: bool = False

    def call(self, **kwargs: Any) -> Any:
        action = kwargs.get("action")
        if action not in _VALID_ACTIONS:
            return {"error": f"action must be 'query' or 'exec', got {action!r}"}

        url_check = check_connection_url(kwargs.get("connection_url"))
        if isinstance(url_check, dict):
            return url_check
        connection_url, readonly = url_check
        # Must be a Postgres URL; _safety allows sqlite/mysql too since it
        # is shared across the three tools. Enforce the tool-specific
        # scheme here so ``PostgresQuery`` never accidentally runs on a
        # sqlite URL.
        if not connection_url.lower().startswith("postgresql"):
            return {
                "error": (
                    "PostgresQuery: connection_url must use the "
                    "'postgresql' scheme (e.g. "
                    "postgresql+psycopg://...)"
                )
            }

        sql_check = check_sql_ddl(kwargs.get("sql"))
        if isinstance(sql_check, dict):
            return sql_check
        sql: str = sql_check

        params = kwargs.get("params")
        if params is not None and not isinstance(params, dict):
            return {"error": "params must be a dict when provided"}

        if action == "query":
            limit_check = check_row_limit(kwargs.get("limit"))
            if isinstance(limit_check, dict):
                return limit_check
            limit: int = limit_check
            return execute_query(
                connection_url=connection_url,
                sql=sql,
                params=params,
                limit=limit,
                readonly=readonly,
                tool_name="PostgresQuery",
            )

        # action == "exec"
        return execute_dml(
            connection_url=connection_url,
            sql=sql,
            params=params,
            readonly=readonly,
            tool_name="PostgresQuery",
        )


__all__ = ["PostgresQuery"]
