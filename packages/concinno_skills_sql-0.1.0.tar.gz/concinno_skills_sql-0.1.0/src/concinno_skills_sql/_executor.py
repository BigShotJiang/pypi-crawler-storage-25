"""concinno_skills_sql._executor — shared SQLAlchemy call flow.

@module _executor
@responsibility All three tools (``PostgresQuery`` / ``MysqlQuery`` /
    ``SqliteQuery``) share the same ``action='query'|'exec'`` dispatch,
    parameter binding, row-dict conversion, and error-wrap shape. We
    centralise here so the three tool classes are thin dispatch wrappers.

Why a separate module
---------------------
SQLAlchemy's Core API is the same across dialects; only the driver
package (``psycopg`` / ``pymysql`` / stdlib ``sqlite3``) differs, and
that's a pip-install concern, not a runtime-code concern. Duplicating
the execute-then-rowify code in three files would be a maintenance
trap — the concinno-skills-office ``_safety`` module shows the same
"centralise the concern, tool is a thin wrapper" pattern.

Safety contract enforced by caller
----------------------------------
Each tool class is expected to have already run:

    1. :func:`_safety.check_connection_url` — scheme + sqlite path
       guard, returns ``readonly`` flag.
    2. :func:`_safety.check_sql_ddl` — reject DDL up-front.
    3. :func:`_safety.check_row_limit` — cap ``limit``.

This module does not re-run those; it assumes a pre-validated payload.
The tool wrappers are responsible for the upstream validation so that
error messages mention the specific tool name (``PostgresQuery: …``).

Error wrap
----------
All :exc:`sqlalchemy.exc.SQLAlchemyError` subclasses (connection
refused, syntax error, unique-violation, …) surface as
``{"error": "SQL error: <short message>"}``. The short message is the
first line of ``str(exc)`` to avoid dumping full SQL + driver traceback
into the LLM's context window.
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger("concinno_skills_sql._executor")


def execute_query(
    connection_url: str,
    sql: str,
    params: dict[str, Any] | None,
    limit: int,
    readonly: bool,  # noqa: ARG001 — reserved for future RO-session enforcement
    tool_name: str,
) -> dict[str, Any]:
    """Execute a SELECT-style statement and return row dicts.

    Returns ``{"rows": [...], "count": N, "columns": [...]}`` on
    success or ``{"error": "..."}`` on failure.

    Args:
        connection_url: Pre-validated SQLAlchemy URL.
        sql: Pre-validated (DDL-free) SQL ``SELECT`` string.
        params: Optional ``{"name": value}`` dict for parameterised
            bind vars — uses SQLAlchemy's ``:name`` placeholder shape,
            which is driver-agnostic.
        limit: Pre-clamped row cap (<= MAX_ROW_LIMIT).
        readonly: Hint that the caller requested a read-only URL.
            Reserved for future BEGIN TRANSACTION READ ONLY injection;
            currently the tool-level DML block handles this.
        tool_name: Caller's identifier for logging/error shaping.

    The ``params`` binding path is the real injection defense — we never
    concatenate user input into SQL on this code path.
    """
    try:
        from sqlalchemy import create_engine, text
        from sqlalchemy.exc import SQLAlchemyError
    except ImportError as exc:
        return {
            "error": (
                f"sqlalchemy not installed: {exc}. "
                f"Run: pip install concinno-skills-sql"
            )
        }

    try:
        engine = create_engine(connection_url)
    except SQLAlchemyError as exc:
        return _wrap_error(exc, tool_name, "create engine")
    except Exception as exc:  # noqa: BLE001 — driver import can raise
        # E.g. psycopg / pymysql missing — surface clearly.
        return {
            "error": (
                f"{tool_name}: connect failed — "
                f"{_first_line(exc)}. "
                f"Check that the driver package "
                f"(psycopg[binary] / pymysql) is installed."
            )
        }

    rows: list[dict[str, Any]] = []
    columns: list[str] = []

    try:
        with engine.connect() as conn:
            result = conn.execute(text(sql), params or {})
            columns = list(result.keys())
            # Use ``fetchmany(limit)`` not ``fetchall()`` so we do not
            # pull 10M rows into memory just to slice [:limit].
            fetched = result.fetchmany(limit)
            for row in fetched:
                # ``row._mapping`` is the canonical dict view in
                # SQLAlchemy 2.x. Values kept as-is (caller serialises
                # downstream).
                rows.append(dict(row._mapping))
    except SQLAlchemyError as exc:
        return _wrap_error(exc, tool_name, "query")
    finally:
        # ``create_engine`` maintains a connection pool; ``dispose``
        # closes all pooled connections so a short-lived tool call does
        # not leak a stale socket on Postgres / MySQL.
        engine.dispose()

    return {"rows": rows, "count": len(rows), "columns": columns}


def execute_dml(
    connection_url: str,
    sql: str,
    params: dict[str, Any] | None,
    readonly: bool,
    tool_name: str,
) -> dict[str, Any]:
    """Execute an INSERT / UPDATE / DELETE statement.

    Returns ``{"ok": True, "rowcount": N}`` on success or
    ``{"error": "..."}`` on failure.

    A URL carrying ``?readonly=1`` fails DML up-front — caller-side
    intent flag, defense-in-depth with DB-side roles.
    """
    if readonly:
        return {
            "error": (
                f"{tool_name}: connection_url requested readonly=1; "
                f"exec (DML) is rejected. Remove the flag or use a "
                f"write-privileged URL."
            )
        }

    try:
        from sqlalchemy import create_engine, text
        from sqlalchemy.exc import SQLAlchemyError
    except ImportError as exc:
        return {
            "error": (
                f"sqlalchemy not installed: {exc}. "
                f"Run: pip install concinno-skills-sql"
            )
        }

    try:
        engine = create_engine(connection_url)
    except SQLAlchemyError as exc:
        return _wrap_error(exc, tool_name, "create engine")
    except Exception as exc:  # noqa: BLE001 — driver import can raise
        return {
            "error": (
                f"{tool_name}: connect failed — "
                f"{_first_line(exc)}. "
                f"Check that the driver package "
                f"(psycopg[binary] / pymysql) is installed."
            )
        }

    try:
        with engine.begin() as conn:
            # ``engine.begin`` auto-commits on context exit; rolls back
            # on exception. Matches CC's "commit on success, nothing
            # else" discipline.
            result = conn.execute(text(sql), params or {})
            rowcount = result.rowcount
    except SQLAlchemyError as exc:
        return _wrap_error(exc, tool_name, "exec")
    finally:
        engine.dispose()

    # Some dialects / statements set rowcount=-1 (no count available).
    # We surface it literally — the LLM can interpret.
    return {"ok": True, "rowcount": rowcount}


def _first_line(exc: BaseException) -> str:
    """Return the first non-empty line of ``str(exc)``.

    Avoids dumping full driver tracebacks into the agent's context.
    """
    text_ = str(exc)
    for line in text_.splitlines():
        stripped = line.strip()
        if stripped:
            return stripped
    return text_ or exc.__class__.__name__


def _wrap_error(exc: BaseException, tool_name: str, phase: str) -> dict[str, str]:
    """Produce the standard ``{"error":…}`` payload + log at WARNING."""
    msg = _first_line(exc)
    logger.warning("%s %s failed: %s", tool_name, phase, msg)
    return {"error": f"{tool_name}: SQL error during {phase}: {msg}"}


__all__ = ["execute_dml", "execute_query"]
