# Changelog

All notable changes to `concinno-skills-sql` are documented here.
Format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/)
and the project adheres to Semantic Versioning.

## [0.1.0] - 2026-04-22

### Added

- Initial release. Fourth sub-package in the `concinno-skills-*`
  ecosystem after `concinno-skills-google`, `concinno-skills-chat`, and
  `concinno-skills-office`. Exercises the
  `[project.entry-points."concinno.tools"]` discovery path.
- `PostgresQuery` tool — parameterised SELECT / INSERT / UPDATE /
  DELETE against a remote Postgres via SQLAlchemy 2.x + `psycopg`
  (LGPL-3.0, dynamic pip link; see README license notes).
- `MysqlQuery` tool — same, against MySQL / MariaDB via `pymysql`
  (MIT).
- `SqliteQuery` tool — same, against a local `.db` file or
  `:memory:` via stdlib `sqlite3` + SQLAlchemy.
- Shared `_safety` module enforcing:
  - connection URL scheme allow-list (postgresql / mysql / sqlite);
  - DDL rejection (`DROP` / `TRUNCATE` / `ALTER` / `CREATE` /
    `GRANT` / `REVOKE`) across both `query` and `exec`;
  - SQLite filesystem guard — paths must be under `Path.home()` or
    `Path.cwd()` and never under `/etc`, `/Windows`, `/System`, etc.;
    `:memory:` unconditionally allowed;
  - Optional `?readonly=1` URL flag that blocks `exec` DML;
  - Row-count cap (`DEFAULT_ROW_LIMIT=100`, `MAX_ROW_LIMIT=10_000`).
- Shared `_executor` module routing both actions through SQLAlchemy
  Core `text()` + bind parameters; surfaces
  `sqlalchemy.exc.SQLAlchemyError` as the tool's structured
  `{"error": "..."}` payload instead of raw tracebacks.

### Scope separation

Concinno core's `DuckDbQuery` (CSV / Parquet / JSON analytical SQL)
remains the local-file path. This sub-package adds the orthogonal
"connect to a running DB server" slot; the two tools can coexist in
the same registry without overlap.
