"""Unit tests for concinno_skills_sql.postgres.PostgresQuery.

No real Postgres available in the unit-test env. We exercise:

1. **Protocol surface + validation** — thin dispatch layer; every
   guard hit is observable without a network connection.
2. **Happy path via monkeypatch** — replace the ``_executor.*`` entry
   points to avoid opening a socket, and assert the dispatch args.

This is the same mock pattern Concinno uses for its remote-service
tools; matches the office template philosophy (real library where
zero-dep, mock where network-dep).
"""

from __future__ import annotations

from typing import Any

import pytest

pytest.importorskip("sqlalchemy")

from concinno_skills_sql import (
    PostgresQuery,  # noqa: E402
    _executor,  # noqa: E402
)


def test_postgres_protocol_surface() -> None:
    assert PostgresQuery.name == "postgres_query"
    assert PostgresQuery.is_concurrency_safe is False
    assert "postgresql" in PostgresQuery.description


def test_postgres_invalid_action() -> None:
    out = PostgresQuery().call(
        action="delete",
        connection_url="postgresql+psycopg://u:p@h:5432/d",
        sql="SELECT 1",
    )
    assert "error" in out
    assert "query" in out["error"]


def test_postgres_missing_connection_url() -> None:
    out = PostgresQuery().call(action="query", sql="SELECT 1")
    assert "error" in out
    assert "connection_url" in out["error"]


def test_postgres_wrong_scheme_rejected() -> None:
    """A sqlite:// URL is not acceptable to PostgresQuery."""
    out = PostgresQuery().call(
        action="query",
        connection_url="sqlite:///:memory:",
        sql="SELECT 1",
    )
    assert "error" in out
    assert "postgresql" in out["error"].lower()


def test_postgres_ftp_scheme_rejected() -> None:
    out = PostgresQuery().call(
        action="query",
        connection_url="ftp://a.b/c",
        sql="SELECT 1",
    )
    assert "error" in out
    assert "scheme" in out["error"].lower()


def test_postgres_ddl_rejected() -> None:
    out = PostgresQuery().call(
        action="exec",
        connection_url="postgresql+psycopg://u:p@h:5432/d",
        sql="DROP TABLE users",
    )
    assert "error" in out
    assert "DROP" in out["error"]


def test_postgres_truncate_rejected() -> None:
    out = PostgresQuery().call(
        action="exec",
        connection_url="postgresql+psycopg://u:p@h:5432/d",
        sql="TRUNCATE users",
    )
    assert "error" in out
    assert "TRUNCATE" in out["error"]


def test_postgres_grant_rejected() -> None:
    out = PostgresQuery().call(
        action="exec",
        connection_url="postgresql+psycopg://u:p@h:5432/d",
        sql="GRANT ALL ON users TO bob",
    )
    assert "error" in out
    assert "GRANT" in out["error"]


def test_postgres_bad_params_type() -> None:
    out = PostgresQuery().call(
        action="query",
        connection_url="postgresql+psycopg://u:p@h:5432/d",
        sql="SELECT :a",
        params=["not", "a", "dict"],
    )
    assert "error" in out
    assert "params" in out["error"]


def test_postgres_limit_overflow() -> None:
    out = PostgresQuery().call(
        action="query",
        connection_url="postgresql+psycopg://u:p@h:5432/d",
        sql="SELECT 1",
        limit=20_000,
    )
    assert "error" in out
    assert "MAX_ROW_LIMIT" in out["error"]


def test_postgres_query_dispatch(monkeypatch: pytest.MonkeyPatch) -> None:
    """Happy path — confirm dispatch args reach ``execute_query``."""
    captured: dict[str, Any] = {}

    def fake_execute_query(**kwargs: Any) -> Any:
        captured.update(kwargs)
        return {"rows": [{"x": 1}], "count": 1, "columns": ["x"]}

    monkeypatch.setattr(_executor, "execute_query", fake_execute_query)
    # PostgresQuery.call imports ``execute_query`` at module-level; patch
    # there too.
    import concinno_skills_sql.postgres as pg_mod

    monkeypatch.setattr(pg_mod, "execute_query", fake_execute_query)

    out = PostgresQuery().call(
        action="query",
        connection_url="postgresql+psycopg://u:p@h:5432/d",
        sql="SELECT * FROM t WHERE id = :id",
        params={"id": 7},
        limit=50,
    )
    assert out == {"rows": [{"x": 1}], "count": 1, "columns": ["x"]}
    assert captured["connection_url"] == "postgresql+psycopg://u:p@h:5432/d"
    assert captured["sql"] == "SELECT * FROM t WHERE id = :id"
    assert captured["params"] == {"id": 7}
    assert captured["limit"] == 50
    assert captured["readonly"] is False
    assert captured["tool_name"] == "PostgresQuery"


def test_postgres_readonly_url_query_ok(monkeypatch: pytest.MonkeyPatch) -> None:
    """``?readonly=1`` passes through for ``query`` (read path)."""
    captured: dict[str, Any] = {}

    def fake_execute_query(**kwargs: Any) -> Any:
        captured.update(kwargs)
        return {"rows": [], "count": 0, "columns": []}

    import concinno_skills_sql.postgres as pg_mod

    monkeypatch.setattr(pg_mod, "execute_query", fake_execute_query)

    out = PostgresQuery().call(
        action="query",
        connection_url="postgresql+psycopg://u:p@h:5432/d?readonly=1",
        sql="SELECT 1",
    )
    assert "error" not in out
    assert captured["readonly"] is True


def test_postgres_readonly_url_exec_blocked(monkeypatch: pytest.MonkeyPatch) -> None:
    """``?readonly=1`` blocks DML at the executor."""
    import concinno_skills_sql.postgres as pg_mod

    # If execute_dml is accidentally called, make it raise; the
    # readonly check lives in execute_dml so we actually want that
    # path to run — use the real one but against a sabotaged engine
    # via monkey-patching create_engine. Easier: call execute_dml
    # directly so we exercise only the readonly gate.
    captured: dict[str, Any] = {}

    def fake_execute_dml(**kwargs: Any) -> Any:
        captured.update(kwargs)
        # Use the real safety behaviour: readonly=True must return error.
        if kwargs["readonly"]:
            return {
                "error": f"{kwargs['tool_name']}: connection_url requested readonly=1"
            }
        return {"ok": True, "rowcount": 1}

    monkeypatch.setattr(pg_mod, "execute_dml", fake_execute_dml)

    out = PostgresQuery().call(
        action="exec",
        connection_url="postgresql+psycopg://u:p@h:5432/d?readonly=1",
        sql="INSERT INTO t (x) VALUES (:x)",
        params={"x": 1},
    )
    assert "error" in out
    assert "readonly" in out["error"].lower()
    assert captured["readonly"] is True


def test_postgres_exec_dispatch(monkeypatch: pytest.MonkeyPatch) -> None:
    captured: dict[str, Any] = {}

    def fake_execute_dml(**kwargs: Any) -> Any:
        captured.update(kwargs)
        return {"ok": True, "rowcount": 3}

    import concinno_skills_sql.postgres as pg_mod

    monkeypatch.setattr(pg_mod, "execute_dml", fake_execute_dml)

    out = PostgresQuery().call(
        action="exec",
        connection_url="postgresql+psycopg://u:p@h:5432/d",
        sql="UPDATE t SET x = :v",
        params={"v": 10},
    )
    assert out == {"ok": True, "rowcount": 3}
    assert captured["sql"] == "UPDATE t SET x = :v"
    assert captured["params"] == {"v": 10}
