"""Unit tests for concinno_skills_sql.sqlite.SqliteQuery.

Uses SQLite in-memory (``sqlite:///:memory:``) for real SQL — stdlib
``sqlite3`` is zero-dep and gives us a true end-to-end path through
SQLAlchemy + ``_executor`` without touching the network.

The in-memory DB is re-created per test because ``create_engine``
inside ``_executor.execute_query`` opens a fresh connection (no
pool-sharing), so each call sees an empty DB. We work around this by
executing setup + query in a single ``call`` via a multi-statement
pattern, or by using a file-backed SQLite DB under ``tmp_path``.

The multi-call pattern uses ``tmp_path`` — file-backed SQLite keeps
state between calls, which is the realistic way an agent would use
this tool.
"""

from __future__ import annotations

from pathlib import Path

import pytest

sqlalchemy = pytest.importorskip("sqlalchemy")

from concinno_skills_sql import SqliteQuery  # noqa: E402


@pytest.fixture()
def db_url(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> str:
    """Return a sqlite:/// URL under tmp_path (satisfies path guard)."""
    monkeypatch.chdir(tmp_path)
    return f"sqlite:///{tmp_path / 'test.db'}"


def test_sqlite_protocol_surface() -> None:
    """Class attrs match the Concinno Tool protocol."""
    assert SqliteQuery.name == "sqlite_query"
    assert SqliteQuery.is_concurrency_safe is False
    assert "connection_url" in SqliteQuery.description
    assert "query" in SqliteQuery.description
    assert "exec" in SqliteQuery.description


def test_sqlite_invalid_action() -> None:
    out = SqliteQuery().call(action="delete", connection_url="sqlite:///:memory:", sql="SELECT 1")
    assert "error" in out
    assert "query" in out["error"] or "exec" in out["error"]


def test_sqlite_missing_connection_url() -> None:
    out = SqliteQuery().call(action="query", sql="SELECT 1")
    assert "error" in out
    assert "connection_url" in out["error"]


def test_sqlite_wrong_scheme_rejected() -> None:
    out = SqliteQuery().call(
        action="query",
        connection_url="postgresql://u:p@h/d",
        sql="SELECT 1",
    )
    assert "error" in out
    assert "sqlite" in out["error"].lower()


def test_sqlite_ddl_rejected(db_url: str) -> None:
    """DROP / CREATE etc. are hard-rejected before ever opening a
    connection."""
    out = SqliteQuery().call(
        action="exec",
        connection_url=db_url,
        sql="DROP TABLE users",
    )
    assert "error" in out
    assert "DROP" in out["error"]


def test_sqlite_ddl_create_rejected(db_url: str) -> None:
    out = SqliteQuery().call(
        action="exec",
        connection_url=db_url,
        sql="CREATE TABLE t (id INTEGER)",
    )
    assert "error" in out
    assert "CREATE" in out["error"]


def test_sqlite_path_traversal_rejected() -> None:
    out = SqliteQuery().call(
        action="query",
        connection_url="sqlite:////etc/passwd.db",
        sql="SELECT 1",
    )
    assert "error" in out
    assert (
        "system directory" in out["error"]
        or "home directory or current working" in out["error"]
    )


def test_sqlite_memory_allowed() -> None:
    """``:memory:`` is a special-cased allowed path."""
    # Bootstrap a table — but since engine is re-opened per call the
    # table won't survive. We still exercise the path-guard allow and
    # surface the empty-select path.
    out = SqliteQuery().call(
        action="query",
        connection_url="sqlite:///:memory:",
        sql="SELECT 1 AS one",
    )
    assert "error" not in out, out
    assert out["count"] == 1
    assert out["rows"][0]["one"] == 1


def test_sqlite_roundtrip_insert_select(db_url: str) -> None:
    """Real end-to-end: INSERT rows then SELECT them back.

    Needs a file-backed URL because each ``call`` opens a fresh engine
    (in-memory DBs don't share state across engines).
    """
    # Bootstrap schema via direct SQLAlchemy since DDL is blocked.
    from sqlalchemy import create_engine, text

    engine = create_engine(db_url)
    with engine.begin() as c:
        c.execute(text("CREATE TABLE users (id INTEGER PRIMARY KEY, name TEXT)"))
    engine.dispose()

    # exec — insert two rows using parameter binding.
    out_exec = SqliteQuery().call(
        action="exec",
        connection_url=db_url,
        sql="INSERT INTO users (id, name) VALUES (:id, :name)",
        params={"id": 1, "name": "Alice"},
    )
    assert out_exec == {"ok": True, "rowcount": 1}, out_exec

    out_exec2 = SqliteQuery().call(
        action="exec",
        connection_url=db_url,
        sql="INSERT INTO users (id, name) VALUES (:id, :name)",
        params={"id": 2, "name": "Bob"},
    )
    assert out_exec2["ok"] is True

    # query — read them back.
    out_query = SqliteQuery().call(
        action="query",
        connection_url=db_url,
        sql="SELECT id, name FROM users ORDER BY id",
    )
    assert "error" not in out_query, out_query
    assert out_query["count"] == 2
    assert out_query["columns"] == ["id", "name"]
    assert out_query["rows"] == [
        {"id": 1, "name": "Alice"},
        {"id": 2, "name": "Bob"},
    ]


def test_sqlite_readonly_blocks_dml(db_url: str) -> None:
    """``?readonly=1`` makes ``exec`` refuse before touching the DB."""
    from sqlalchemy import create_engine, text

    engine = create_engine(db_url)
    with engine.begin() as c:
        c.execute(text("CREATE TABLE t (id INTEGER)"))
    engine.dispose()

    out = SqliteQuery().call(
        action="exec",
        connection_url=f"{db_url}?readonly=1",
        sql="INSERT INTO t (id) VALUES (:id)",
        params={"id": 1},
    )
    assert "error" in out
    assert "readonly" in out["error"].lower()


def test_sqlite_limit_cap(db_url: str) -> None:
    """Row count cap: seed 5 rows, ``limit=2`` returns 2."""
    from sqlalchemy import create_engine, text

    engine = create_engine(db_url)
    with engine.begin() as c:
        c.execute(text("CREATE TABLE t (id INTEGER)"))
        for i in range(5):
            c.execute(text("INSERT INTO t (id) VALUES (:id)"), {"id": i})
    engine.dispose()

    out = SqliteQuery().call(
        action="query",
        connection_url=db_url,
        sql="SELECT id FROM t ORDER BY id",
        limit=2,
    )
    assert out["count"] == 2
    assert out["rows"] == [{"id": 0}, {"id": 1}]


def test_sqlite_limit_overflow_rejected(db_url: str) -> None:
    out = SqliteQuery().call(
        action="query",
        connection_url=db_url,
        sql="SELECT 1",
        limit=99_999_999,
    )
    assert "error" in out
    assert "MAX_ROW_LIMIT" in out["error"]


def test_sqlite_bad_params_type(db_url: str) -> None:
    out = SqliteQuery().call(
        action="query",
        connection_url=db_url,
        sql="SELECT :a",
        params="not-a-dict",
    )
    assert "error" in out
    assert "params" in out["error"]


def test_sqlite_sqlalchemy_error_wrapped(db_url: str) -> None:
    """A bad SQL statement surfaces as a ``SQL error`` payload, not a
    raw exception."""
    out = SqliteQuery().call(
        action="query",
        connection_url=db_url,
        sql="SELECT * FROM nonexistent_table_xyz",
    )
    assert "error" in out
    assert "SqliteQuery" in out["error"]
    assert "SQL error" in out["error"]
