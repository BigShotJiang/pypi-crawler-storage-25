"""Unit tests for concinno_skills_sql.mysql.MysqlQuery.

Same mock strategy as test_postgres.py — MysqlQuery is a scheme-
swapped twin of PostgresQuery and we want the diff between the two
test files to be small so reviewers can spot drift quickly.
"""

from __future__ import annotations

from typing import Any

import pytest

pytest.importorskip("sqlalchemy")

from concinno_skills_sql import MysqlQuery  # noqa: E402


def test_mysql_protocol_surface() -> None:
    assert MysqlQuery.name == "mysql_query"
    assert MysqlQuery.is_concurrency_safe is False
    assert "mysql" in MysqlQuery.description.lower()


def test_mysql_invalid_action() -> None:
    out = MysqlQuery().call(
        action="delete",
        connection_url="mysql+pymysql://u:p@h:3306/d",
        sql="SELECT 1",
    )
    assert "error" in out
    assert "query" in out["error"]


def test_mysql_missing_connection_url() -> None:
    out = MysqlQuery().call(action="query", sql="SELECT 1")
    assert "error" in out
    assert "connection_url" in out["error"]


def test_mysql_wrong_scheme_rejected() -> None:
    out = MysqlQuery().call(
        action="query",
        connection_url="postgresql+psycopg://u:p@h/d",
        sql="SELECT 1",
    )
    assert "error" in out
    assert "mysql" in out["error"].lower()


def test_mysql_ftp_scheme_rejected() -> None:
    out = MysqlQuery().call(
        action="query",
        connection_url="ftp://bad",
        sql="SELECT 1",
    )
    assert "error" in out
    assert "scheme" in out["error"].lower()


def test_mysql_ddl_drop_rejected() -> None:
    out = MysqlQuery().call(
        action="exec",
        connection_url="mysql+pymysql://u:p@h:3306/d",
        sql="DROP DATABASE prod",
    )
    assert "error" in out
    assert "DROP" in out["error"]


def test_mysql_ddl_alter_rejected() -> None:
    out = MysqlQuery().call(
        action="exec",
        connection_url="mysql+pymysql://u:p@h:3306/d",
        sql="ALTER TABLE t ADD COLUMN x INT",
    )
    assert "error" in out
    assert "ALTER" in out["error"]


def test_mysql_ddl_revoke_rejected() -> None:
    out = MysqlQuery().call(
        action="exec",
        connection_url="mysql+pymysql://u:p@h:3306/d",
        sql="REVOKE SELECT ON *.* FROM bob",
    )
    assert "error" in out
    assert "REVOKE" in out["error"]


def test_mysql_bad_params_type() -> None:
    out = MysqlQuery().call(
        action="query",
        connection_url="mysql+pymysql://u:p@h:3306/d",
        sql="SELECT :a",
        params=42,
    )
    assert "error" in out
    assert "params" in out["error"]


def test_mysql_query_dispatch(monkeypatch: pytest.MonkeyPatch) -> None:
    captured: dict[str, Any] = {}

    def fake_execute_query(**kwargs: Any) -> Any:
        captured.update(kwargs)
        return {"rows": [{"n": 42}], "count": 1, "columns": ["n"]}

    import concinno_skills_sql.mysql as my_mod

    monkeypatch.setattr(my_mod, "execute_query", fake_execute_query)

    out = MysqlQuery().call(
        action="query",
        connection_url="mysql+pymysql://u:p@h:3306/d",
        sql="SELECT n FROM t WHERE n = :n",
        params={"n": 42},
        limit=10,
    )
    assert out["count"] == 1
    assert captured["tool_name"] == "MysqlQuery"
    assert captured["limit"] == 10
    assert captured["readonly"] is False


def test_mysql_exec_dispatch(monkeypatch: pytest.MonkeyPatch) -> None:
    captured: dict[str, Any] = {}

    def fake_execute_dml(**kwargs: Any) -> Any:
        captured.update(kwargs)
        return {"ok": True, "rowcount": 2}

    import concinno_skills_sql.mysql as my_mod

    monkeypatch.setattr(my_mod, "execute_dml", fake_execute_dml)

    out = MysqlQuery().call(
        action="exec",
        connection_url="mysql+pymysql://u:p@h:3306/d",
        sql="DELETE FROM t WHERE id = :id",
        params={"id": 3},
    )
    assert out == {"ok": True, "rowcount": 2}
    assert captured["sql"] == "DELETE FROM t WHERE id = :id"
    assert captured["tool_name"] == "MysqlQuery"


def test_mysql_readonly_url_dispatch(monkeypatch: pytest.MonkeyPatch) -> None:
    """``?readonly=1`` surfaces through to executor as readonly=True."""
    captured: dict[str, Any] = {}

    def fake_execute_query(**kwargs: Any) -> Any:
        captured.update(kwargs)
        return {"rows": [], "count": 0, "columns": []}

    import concinno_skills_sql.mysql as my_mod

    monkeypatch.setattr(my_mod, "execute_query", fake_execute_query)

    MysqlQuery().call(
        action="query",
        connection_url="mysql+pymysql://u:p@h:3306/d?readonly=1",
        sql="SELECT 1",
    )
    assert captured["readonly"] is True


def test_mysql_limit_default(monkeypatch: pytest.MonkeyPatch) -> None:
    """No ``limit`` kwarg → DEFAULT_ROW_LIMIT (100) reaches executor."""
    captured: dict[str, Any] = {}

    def fake_execute_query(**kwargs: Any) -> Any:
        captured.update(kwargs)
        return {"rows": [], "count": 0, "columns": []}

    import concinno_skills_sql.mysql as my_mod

    monkeypatch.setattr(my_mod, "execute_query", fake_execute_query)

    MysqlQuery().call(
        action="query",
        connection_url="mysql+pymysql://u:p@h:3306/d",
        sql="SELECT 1",
    )
    assert captured["limit"] == 100
