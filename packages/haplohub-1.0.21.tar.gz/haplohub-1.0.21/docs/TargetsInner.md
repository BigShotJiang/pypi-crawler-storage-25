# TargetsInner


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **str** |  | [optional] [default to 'region']
**accession** | **str** |  | 
**start** | **int** |  | 
**end** | **int** |  | 
**reference** | **str** |  | [optional] 
**alternate** | **str** |  | [optional] 
**value** | **str** |  | 
**gene_symbols** | **List[str]** |  | 
**clinical_significance** | **List[str]** |  | [optional] [default to [Pathogenic, Likely_pathogenic]]

## Example

```python
from haplohub.models.targets_inner import TargetsInner

# TODO update the JSON string below
json = "{}"
# create an instance of TargetsInner from a JSON string
targets_inner_instance = TargetsInner.from_json(json)
# print the JSON string representation of the object
print TargetsInner.to_json()

# convert the object into a dict
targets_inner_dict = targets_inner_instance.to_dict()
# create an instance of TargetsInner from a dict
targets_inner_from_dict = TargetsInner.from_dict(targets_inner_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


