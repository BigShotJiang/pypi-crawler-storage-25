# RegionTargetSchema


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **str** |  | [optional] [default to 'region']
**accession** | **str** |  | 
**start** | **int** |  | 
**end** | **int** |  | 
**reference** | **str** |  | [optional] 
**alternate** | **str** |  | [optional] 

## Example

```python
from haplohub.models.region_target_schema import RegionTargetSchema

# TODO update the JSON string below
json = "{}"
# create an instance of RegionTargetSchema from a JSON string
region_target_schema_instance = RegionTargetSchema.from_json(json)
# print the JSON string representation of the object
print RegionTargetSchema.to_json()

# convert the object into a dict
region_target_schema_dict = region_target_schema_instance.to_dict()
# create an instance of RegionTargetSchema from a dict
region_target_schema_from_dict = RegionTargetSchema.from_dict(region_target_schema_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


