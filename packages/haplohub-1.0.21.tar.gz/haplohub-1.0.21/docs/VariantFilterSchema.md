# VariantFilterSchema


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**call_state** | **str** |  | [optional] [default to 'called']

## Example

```python
from haplohub.models.variant_filter_schema import VariantFilterSchema

# TODO update the JSON string below
json = "{}"
# create an instance of VariantFilterSchema from a JSON string
variant_filter_schema_instance = VariantFilterSchema.from_json(json)
# print the JSON string representation of the object
print VariantFilterSchema.to_json()

# convert the object into a dict
variant_filter_schema_dict = variant_filter_schema_instance.to_dict()
# create an instance of VariantFilterSchema from a dict
variant_filter_schema_from_dict = VariantFilterSchema.from_dict(variant_filter_schema_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


