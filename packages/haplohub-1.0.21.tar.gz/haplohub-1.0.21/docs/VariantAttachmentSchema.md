# VariantAttachmentSchema


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**clinvar** | [**List[ClinvarAttachmentSchema]**](ClinvarAttachmentSchema.md) |  | [optional] 

## Example

```python
from haplohub.models.variant_attachment_schema import VariantAttachmentSchema

# TODO update the JSON string below
json = "{}"
# create an instance of VariantAttachmentSchema from a JSON string
variant_attachment_schema_instance = VariantAttachmentSchema.from_json(json)
# print the JSON string representation of the object
print VariantAttachmentSchema.to_json()

# convert the object into a dict
variant_attachment_schema_dict = variant_attachment_schema_instance.to_dict()
# create an instance of VariantAttachmentSchema from a dict
variant_attachment_schema_from_dict = VariantAttachmentSchema.from_dict(variant_attachment_schema_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


