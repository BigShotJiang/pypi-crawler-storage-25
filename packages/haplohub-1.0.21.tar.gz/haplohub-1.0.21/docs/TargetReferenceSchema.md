# TargetReferenceSchema


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **str** |  | 
**input** | **str** |  | 
**resolved** | **str** |  | [optional] 

## Example

```python
from haplohub.models.target_reference_schema import TargetReferenceSchema

# TODO update the JSON string below
json = "{}"
# create an instance of TargetReferenceSchema from a JSON string
target_reference_schema_instance = TargetReferenceSchema.from_json(json)
# print the JSON string representation of the object
print TargetReferenceSchema.to_json()

# convert the object into a dict
target_reference_schema_dict = target_reference_schema_instance.to_dict()
# create an instance of TargetReferenceSchema from a dict
target_reference_schema_from_dict = TargetReferenceSchema.from_dict(target_reference_schema_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


