# ClinvarFilterRequest


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sample_id** | **str** |  | 
**gene_symbols** | **List[str]** |  | 
**clinical_significance** | **List[str]** |  | [optional] [default to [Pathogenic, Likely_pathogenic]]
**include_uncalled** | **bool** |  | [optional] [default to False]

## Example

```python
from haplohub.models.clinvar_filter_request import ClinvarFilterRequest

# TODO update the JSON string below
json = "{}"
# create an instance of ClinvarFilterRequest from a JSON string
clinvar_filter_request_instance = ClinvarFilterRequest.from_json(json)
# print the JSON string representation of the object
print ClinvarFilterRequest.to_json()

# convert the object into a dict
clinvar_filter_request_dict = clinvar_filter_request_instance.to_dict()
# create an instance of ClinvarFilterRequest from a dict
clinvar_filter_request_from_dict = ClinvarFilterRequest.from_dict(clinvar_filter_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


