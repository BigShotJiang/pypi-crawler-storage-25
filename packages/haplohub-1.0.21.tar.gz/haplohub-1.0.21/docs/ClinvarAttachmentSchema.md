# ClinvarAttachmentSchema


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accession** | **str** |  | 
**position** | **int** |  | 
**reference** | **str** |  | 
**alternate** | **str** |  | 
**gene_symbol** | **str** |  | 
**clinical_significance** | **str** |  | 
**review_status** | **str** |  | 
**conditions** | **str** |  | [optional] 
**rs_id** | **str** |  | [optional] 

## Example

```python
from haplohub.models.clinvar_attachment_schema import ClinvarAttachmentSchema

# TODO update the JSON string below
json = "{}"
# create an instance of ClinvarAttachmentSchema from a JSON string
clinvar_attachment_schema_instance = ClinvarAttachmentSchema.from_json(json)
# print the JSON string representation of the object
print ClinvarAttachmentSchema.to_json()

# convert the object into a dict
clinvar_attachment_schema_dict = clinvar_attachment_schema_instance.to_dict()
# create an instance of ClinvarAttachmentSchema from a dict
clinvar_attachment_schema_from_dict = ClinvarAttachmentSchema.from_dict(clinvar_attachment_schema_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


