# ResultListResponseClinvarVariantSchema


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **str** |  | [optional] [default to 'success']
**items** | [**List[ClinvarVariantSchema]**](ClinvarVariantSchema.md) |  | 

## Example

```python
from haplohub.models.result_list_response_clinvar_variant_schema import ResultListResponseClinvarVariantSchema

# TODO update the JSON string below
json = "{}"
# create an instance of ResultListResponseClinvarVariantSchema from a JSON string
result_list_response_clinvar_variant_schema_instance = ResultListResponseClinvarVariantSchema.from_json(json)
# print the JSON string representation of the object
print ResultListResponseClinvarVariantSchema.to_json()

# convert the object into a dict
result_list_response_clinvar_variant_schema_dict = result_list_response_clinvar_variant_schema_instance.to_dict()
# create an instance of ResultListResponseClinvarVariantSchema from a dict
result_list_response_clinvar_variant_schema_from_dict = ResultListResponseClinvarVariantSchema.from_dict(result_list_response_clinvar_variant_schema_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


