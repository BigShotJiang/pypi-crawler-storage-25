# SampleVariantCallSchema


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sample_id** | **str** |  | 
**is_called** | **bool** |  | 
**dosage** | **int** |  | [optional] 

## Example

```python
from haplohub.models.sample_variant_call_schema import SampleVariantCallSchema

# TODO update the JSON string below
json = "{}"
# create an instance of SampleVariantCallSchema from a JSON string
sample_variant_call_schema_instance = SampleVariantCallSchema.from_json(json)
# print the JSON string representation of the object
print SampleVariantCallSchema.to_json()

# convert the object into a dict
sample_variant_call_schema_dict = sample_variant_call_schema_instance.to_dict()
# create an instance of SampleVariantCallSchema from a dict
sample_variant_call_schema_from_dict = SampleVariantCallSchema.from_dict(sample_variant_call_schema_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


