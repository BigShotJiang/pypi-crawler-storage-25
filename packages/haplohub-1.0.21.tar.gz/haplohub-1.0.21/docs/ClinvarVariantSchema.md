# ClinvarVariantSchema


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accession** | **str** |  | 
**position** | **int** |  | 
**reference** | **str** |  | 
**alternate** | **str** |  | 
**gene_symbol** | **str** |  | 
**clinical_significance** | **str** |  | 
**review_status** | **str** |  | 
**conditions** | **str** |  | [optional] 
**rs_id** | **str** |  | [optional] 
**is_called** | **bool** |  | 
**dosage** | **int** |  | [optional] 

## Example

```python
from haplohub.models.clinvar_variant_schema import ClinvarVariantSchema

# TODO update the JSON string below
json = "{}"
# create an instance of ClinvarVariantSchema from a JSON string
clinvar_variant_schema_instance = ClinvarVariantSchema.from_json(json)
# print the JSON string representation of the object
print ClinvarVariantSchema.to_json()

# convert the object into a dict
clinvar_variant_schema_dict = clinvar_variant_schema_instance.to_dict()
# create an instance of ClinvarVariantSchema from a dict
clinvar_variant_schema_from_dict = ClinvarVariantSchema.from_dict(clinvar_variant_schema_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


