# ResultListResponseVariantResultSchema


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **str** |  | [optional] [default to 'success']
**items** | [**List[VariantResultSchema]**](VariantResultSchema.md) |  | 

## Example

```python
from haplohub.models.result_list_response_variant_result_schema import ResultListResponseVariantResultSchema

# TODO update the JSON string below
json = "{}"
# create an instance of ResultListResponseVariantResultSchema from a JSON string
result_list_response_variant_result_schema_instance = ResultListResponseVariantResultSchema.from_json(json)
# print the JSON string representation of the object
print ResultListResponseVariantResultSchema.to_json()

# convert the object into a dict
result_list_response_variant_result_schema_dict = result_list_response_variant_result_schema_instance.to_dict()
# create an instance of ResultListResponseVariantResultSchema from a dict
result_list_response_variant_result_schema_from_dict = ResultListResponseVariantResultSchema.from_dict(result_list_response_variant_result_schema_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


