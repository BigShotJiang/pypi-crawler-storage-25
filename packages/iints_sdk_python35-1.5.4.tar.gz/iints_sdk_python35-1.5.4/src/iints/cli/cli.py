import typer  # type: ignore
import concurrent.futures
from pathlib import Path
from typing import Dict, Any, Union, List, Tuple, Optional, cast
from dataclasses import asdict
from typing_extensions import Annotated
from pydantic import ValidationError
import difflib
import os
import hashlib
import importlib.util
import importlib
import sys
import json
import platform
import tempfile
import time
import shutil
import yaml # Added for Virtual Patient Registry
import pandas as pd # Added for DataFrame in benchmark results
import numpy as np
import click
from typer.core import TyperGroup
from click.core import ParameterSource

from rich.console import Console  # type: ignore # For pretty printing
from rich.table import Table  # type: ignore # For comparison table
from rich.panel import Panel  # type: ignore # For nicer auto-doc output
from rich.progress import BarColumn, Progress, SpinnerColumn, TextColumn, TimeElapsedColumn  # type: ignore

import iints # Import the top-level SDK package
from iints.ai import prepare_ai_ready_artifacts
from iints.ai.cli import app as ai_app
from iints.cli import patient_cli as patient_cli_module
from iints.cli.patient_cli import app as patient_app
from iints.analysis import build_booth_demo, build_carelink_workbench, generate_study_poster
from iints.analysis.baseline import run_baseline_comparison, write_baseline_comparison
from iints.analysis.eucys_results import generate_eucys_results_bundle
from iints.analysis.study_analysis import analyze_study_directory, compare_studies, load_study_summary
from iints.analysis.study_experiment import load_study_experiment_config
from iints.analysis.study_engine import DEFAULT_PROFILE_SET, build_study_design_payload, slugify_study_token
from iints.analysis.study_protocol import write_study_protocol_bundle
from iints.api.registry import list_algorithm_plugins
from iints.core.patient.profile import PatientProfile
from iints.core.algorithms.clinical_baseline import ClinicalBaselineAlgorithm
from iints.core.safety import SafetyConfig
from iints.scenarios import (
    ScenarioGeneratorConfig,
    build_eucys_arm_scenario,
    build_eucys_study_pack,
    export_eucys_study_pack,
    export_official_study_pack,
    generate_random_scenario,
)
from iints.data.nightscout import NightscoutConfig, import_nightscout
from iints.data.tidepool import TidepoolClient
from iints.data.importer import (
    export_demo_csv,
    export_standard_csv,
    guess_column_mapping,
    import_cgm_dataframe,
    summarize_carelink_csv,
    load_demo_dataframe,
    scenario_from_csv,
    scenario_from_dataframe,
)
from iints.data.study_corruption import AVAILABLE_STUDY_CORRUPTIONS, write_corrupted_study_csv
from iints.data.registry import (
    load_dataset_registry,
    get_dataset,
    fetch_dataset,
    DatasetFetchError,
    DatasetRegistryError,
)
from iints.data.contracts import load_contract_yaml
from iints.data.synthetic_mirror import generate_synthetic_mirror
from iints.demo_assets import export_live_stage_demo
from iints.live_patient.edge_benchmark import run_edge_benchmark
from iints.live_patient.edge_ops import (
    build_edge_offline_bundle,
    create_edge_bundle,
    deploy_edge_project,
    export_edge_setup,
    run_remote_edge_command,
    summarize_edge_workspace,
    write_edge_update_script,
)
from iints.live_patient.long_study import (
    EdgeLongStudyExecutionError,
    LongStudyConfigError,
    create_edge_study_snapshot,
    export_edge_study_archive,
    run_edge_long_study,
)
from iints.live_patient.runtime import PatientRuntimeConfig
from iints.live_patient.uno_q import (
    UNO_Q_BRIDGE_BAUDRATE,
    export_uno_q_bridge,
    flash_uno_q_bridge,
    list_uno_q_serial_ports,
    run_uno_q_bridge_forwarder,
    run_uno_q_bridge_test,
    uno_q_bridge_environment_report,
)
from iints.mdmp.backend import (
    MDMP_GRADE_ORDER,
    active_mdmp_backend,
    build_mdmp_dashboard_html,
    load_mdmp_contract,
    mdmp_grade_meets_minimum,
    run_mdmp_validation,
)
from iints.utils.run_io import (
    build_run_metadata,
    build_run_manifest,
    generate_run_id,
    maybe_sign_manifest,
    resolve_output_dir,
    resolve_seed,
    write_json,
)
from iints.utils.csv_safety import sanitize_csv_dataframe
from iints.validation import (
    apply_contract_to_config,
    build_stress_events,
    compute_run_metrics,
    evaluate_expected_ranges,
    evaluate_run,
    format_validation_error,
    load_golden_benchmark_pack,
    load_contract_spec,
    load_validation_profiles,
    run_deterministic_replay_check,
    load_scenario,
    load_patient_config,
    load_patient_config_by_name,
    migrate_scenario_dict,
    scenario_to_payloads,
    scenario_warnings,
    verify_safety_contract,
    validate_patient_config_dict,
    validate_scenario_dict,
)


def _require_reports_feature(console: Console, module_path: str, attribute: str, feature_name: str):
    try:
        module = importlib.import_module(module_path)
        return getattr(module, attribute)
    except Exception as exc:
        console.print(
            f"[bold red]{feature_name} is not available in the minimal edge install.[/bold red]\n"
            "Install the optional reporting stack with:\n"
            "  [cyan]python -m pip install -U \"iints-sdk-python35[reports]\"[/cyan]\n"
            "or:\n"
            "  [cyan]python -m pip install -U \"iints-sdk-python35[full]\"[/cyan]\n"
            f"Details: {exc}"
        )
        raise typer.Exit(code=1)


IINTS_ASCII_LOGO = r"""
 /$$$$$$ /$$$$$$ /$$   /$$ /$$$$$$$$ /$$$$$$           /$$$$$$  /$$$$$$$  /$$   /$$
|_  $$_/|_  $$_/| $$$ | $$|__  $$__//$$__  $$         /$$__  $$| $$__  $$| $$  /$$/
  | $$    | $$  | $$$$| $$   | $$  | $$  \__/        | $$  \__/| $$  \ $$| $$ /$$/
  | $$    | $$  | $$ $$ $$   | $$  |  $$$$$$  /$$$$$$|  $$$$$$ | $$  | $$| $$$$$/
  | $$    | $$  | $$  $$$$   | $$   \____  $$|______/ \____  $$| $$  | $$| $$  $$
  | $$    | $$  | $$\  $$$   | $$   /$$  \ $$         /$$  \ $$| $$  | $$| $$\  $$
 /$$$$$$ /$$$$$$| $$ \  $$   | $$  |  $$$$$$/        |  $$$$$$/| $$$$$$$/| $$ \  $$
|______/|______/|__/  \__/   |__/   \______/          \______/ |_______/ |__/  \__/
"""

APP_HELP = (
    "IINTS-AF SDK CLI - Intelligent Insulin Titration System for Artificial Pancreas research."
)


class BrandedTyperGroup(TyperGroup):
    def get_help(self, ctx):  # type: ignore[override]
        return f"{IINTS_ASCII_LOGO}\n\n{super().get_help(ctx)}"


app = typer.Typer(
    help=APP_HELP,
    context_settings={"max_content_width": 120},
    cls=BrandedTyperGroup,
    rich_markup_mode=None,
)
docs_app = typer.Typer(help="Generate documentation and technical summaries for IINTS-AF components.")
presets_app = typer.Typer(help="Clinic-safe presets and quickstart runs.")
profiles_app = typer.Typer(help="Patient profiles and physiological presets.")
data_app = typer.Typer(help="Data import, certification, and public data packs.")
mdmp_app = typer.Typer(help="Legacy MDMP namespace kept for backwards compatibility.")
scenarios_app = typer.Typer(help="Scenario generation and utilities.")
algorithms_app = typer.Typer(help="Algorithm registry and plugins.")
edge_app = typer.Typer(help="Single-board computer and edge deployment tools.")
makerfaire_app = typer.Typer(help="Maker Faire booth startup helpers for the physical virtual patient setup.")
app.add_typer(docs_app, name="docs")
app.add_typer(presets_app, name="presets")
app.add_typer(profiles_app, name="profiles")
app.add_typer(data_app, name="data")
app.add_typer(mdmp_app, name="mdmp", hidden=True, deprecated=True)
app.add_typer(ai_app, name="ai")
app.add_typer(scenarios_app, name="scenarios")
app.add_typer(algorithms_app, name="algorithms")
app.add_typer(edge_app, name="edge")
app.add_typer(makerfaire_app, name="makerfaire")
app.add_typer(patient_app, name="patient")

def _load_algorithm_instance(algo: Path, console: Console) -> iints.InsulinAlgorithm:
    try:
        return _load_algorithm_instance_silent(algo)
    except FileNotFoundError:
        console.print(f"[bold red]{_algorithm_not_found_message(algo)}[/bold red]")
        raise typer.Exit(code=1)
    except Exception as e:
        console.print(f"[bold red]Error loading algorithm module {algo}: {e}[/bold red]")
        raise typer.Exit(code=1)

def _load_algorithm_class_silent(algo: Path) -> type[iints.InsulinAlgorithm]:
    if not algo.is_file():
        raise FileNotFoundError(f"Algorithm file '{algo}' not found.")
    resolved = algo.expanduser().resolve()
    module_hash = hashlib.sha256(str(resolved).encode("utf-8")).hexdigest()[:12]
    module_name = f"_iints_user_algo_{resolved.stem}_{module_hash}_{time.monotonic_ns()}"
    spec = importlib.util.spec_from_file_location(module_name, resolved)
    if spec is None or spec.loader is None:
        raise ImportError(f"Could not load module spec for {resolved}")
    module = importlib.util.module_from_spec(spec)
    module.__dict__.setdefault("iints", iints)
    previous_module = sys.modules.get(module_name)
    sys.modules[module_name] = module
    try:
        spec.loader.exec_module(module)
    finally:
        if previous_module is None:
            sys.modules.pop(module_name, None)
        else:
            sys.modules[module_name] = previous_module
    for _, obj in module.__dict__.items():
        if isinstance(obj, type) and issubclass(obj, iints.InsulinAlgorithm) and obj is not iints.InsulinAlgorithm:
            return obj
    raise ImportError(f"No subclass of InsulinAlgorithm found in {resolved}")


def _load_algorithm_instance_silent(algo: Path) -> iints.InsulinAlgorithm:
    algorithm_class = _load_algorithm_class_silent(algo)
    return algorithm_class()

def _load_presets() -> List[Dict[str, Any]]:
    if sys.version_info >= (3, 9):
        from importlib.resources import files
        content = files("iints.presets").joinpath("presets.json").read_text()
    else:
        from importlib import resources
        content = resources.read_text("iints.presets", "presets.json")
    return json.loads(content)


def _load_evidence_sources() -> Dict[str, Any]:
    if sys.version_info >= (3, 9):
        from importlib.resources import files

        content = files("iints.presets").joinpath("evidence_sources.yaml").read_text()
    else:
        from importlib import resources

        content = resources.read_text("iints.presets", "evidence_sources.yaml")
    raw = yaml.safe_load(content) or {}
    if not isinstance(raw, dict):
        raise ValueError("evidence_sources.yaml must contain a top-level mapping")
    return raw


def _filtered_evidence_sources(category: Optional[str] = None) -> Dict[str, Any]:
    payload = _load_evidence_sources()
    rows = payload.get("sources", [])
    if not isinstance(rows, list):
        raise ValueError("evidence_sources.yaml must contain a 'sources' list")
    selected: List[Dict[str, Any]] = []
    for entry in rows:
        if not isinstance(entry, dict):
            continue
        if category and str(entry.get("category", "")).strip().lower() != category.strip().lower():
            continue
        selected.append(entry)
    return {
        "version": payload.get("version", 1),
        "updated_utc": payload.get("updated_utc"),
        "category": category,
        "count": len(selected),
        "sources": selected,
    }


def _write_certification_summary(
    output_dir: Path,
    outputs: Dict[str, Any],
    profile: str,
    report: Dict[str, Any],
    source_manifest_path: Optional[Path],
) -> Path:
    checks = report.get("checks", [])
    failed_checks = [check for check in checks if not bool(check.get("passed", False))]
    status = "PASS" if bool(report.get("passed", False)) else "FAIL"
    required_passed = report.get("required_checks_passed", 0)
    required_total = report.get("required_checks_total", 0)

    lines = [
        "# IINTS-AF Certification Bundle",
        "",
        f"- Status: **{status}** ({required_passed}/{required_total} required checks passed)",
        f"- Validation profile: `{profile}`",
        f"- Results CSV: `{outputs.get('results_csv', '')}`",
        f"- Validation report: `validation_report.json`",
        f"- Run manifest: `{outputs.get('run_manifest_path', '')}`",
    ]
    if source_manifest_path is not None:
        lines.append(f"- Source manifest: `{source_manifest_path}`")
    if failed_checks:
        lines.append("")
        lines.append("## Failed Checks")
        for check in failed_checks:
            lines.append(
                f"- `{check.get('label', check.get('metric', 'metric'))}`: "
                f"value={check.get('value')} threshold {check.get('op')} {check.get('threshold')}"
            )
    else:
        lines.append("")
        lines.append("All required checks passed.")

    lines.extend(
        [
            "",
            "## Next Steps",
            "1. Open `clinical_report.pdf` for visual review.",
            "2. Inspect `validation_report.json` for gate-level details.",
            "3. Archive `run_manifest.json`, `run_metadata.json`, and `sources_manifest.json` (if present).",
        ]
    )

    summary_path = output_dir / "SUMMARY.md"
    summary_path.write_text("\n".join(lines) + "\n")
    return summary_path


def _maybe_prepare_ai_artifacts(output_dir: Path, console: Console) -> None:
    try:
        outputs = prepare_ai_ready_artifacts(output_dir, create_dev_mdmp_cert=True)
        console.print(f"[green]AI-ready artifacts:[/green] {output_dir / 'ai'}")
        if "mdmp_cert" in outputs:
            console.print(f"[green]AI quick start:[/green] iints ai report {output_dir}")
        return
    except ImportError as exc:
        console.print(f"[yellow]AI dev certificate skipped:[/yellow] {exc}")
    except Exception as exc:
        console.print(f"[yellow]AI-ready export skipped:[/yellow] {exc}")
        return

    try:
        prepare_ai_ready_artifacts(output_dir, create_dev_mdmp_cert=False)
        console.print(f"[green]AI-ready payloads:[/green] {output_dir / 'ai'}")
        console.print(
            "[yellow]Tip:[/yellow] Install the MDMP extra or rerun "
            f"`iints ai prepare {output_dir}` to generate a local development certificate."
        )
    except Exception as exc:
        console.print(f"[yellow]AI-ready payload export skipped:[/yellow] {exc}")


def _get_preset(name: str) -> Dict[str, Any]:
    presets = _load_presets()
    for preset in presets:
        if preset.get("name") == name:
            return preset
    raise KeyError(name)


def _read_template_text(package: str, resource_name: str) -> str:
    if sys.version_info >= (3, 9):
        from importlib.resources import files

        return files(package).joinpath(resource_name).read_text(encoding="utf-8")
    from importlib import resources

    return resources.read_text(package, resource_name, encoding="utf-8")


def _write_default_algorithm_template(output_path: Path, *, algo_name: str, author_name: str) -> Path:
    content = _read_template_text("iints.templates", "default_algorithm.py")
    content = content.replace("{{ALGO_NAME}}", algo_name)
    content = content.replace("{{AUTHOR_NAME}}", author_name)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(content, encoding="utf-8")
    return output_path


def _find_close_path_match(target: Path, candidates: List[Path]) -> Optional[Path]:
    if not candidates:
        return None
    target_name = target.name
    by_name = {candidate.name: candidate for candidate in candidates}
    matches = difflib.get_close_matches(target_name, list(by_name.keys()), n=1, cutoff=0.45)
    if matches:
        return by_name[matches[0]]
    target_str = str(target)
    by_path = {str(candidate): candidate for candidate in candidates}
    matches = difflib.get_close_matches(target_str, list(by_path.keys()), n=1, cutoff=0.45)
    if matches:
        return by_path[matches[0]]
    return None


def _suggest_path_message(target: Path, *, glob_pattern: str, include_common_roots: bool = True) -> Optional[str]:
    candidates: List[Path] = []
    if include_common_roots:
        for root in (Path.cwd(), Path.cwd() / "algorithms", Path.cwd() / "scenarios", Path.cwd() / "results"):
            if root.exists():
                candidates.extend(root.glob(glob_pattern))
    else:
        candidates.extend(Path.cwd().glob(glob_pattern))
    suggestion = _find_close_path_match(target, candidates)
    if suggestion is None:
        return None
    try:
        suggestion_display = suggestion.relative_to(Path.cwd())
    except ValueError:
        suggestion_display = suggestion
    return f"Did you mean '{suggestion_display}'?"


def _algorithm_not_found_message(target: Path) -> str:
    suggestion = _suggest_path_message(target, glob_pattern="**/*.py")
    detail = f"Algorithm file not found: {target}"
    if suggestion:
        detail = f"{detail}. {suggestion}"
    else:
        detail = f"{detail}. Tip: run `iints demo` or `iints quickstart` if you want a working example first."
    return detail


def _scenario_not_found_message(target: Path) -> str:
    suggestion = _suggest_path_message(target, glob_pattern="**/*.json")
    detail = f"Scenario file not found: {target}"
    if suggestion:
        detail = f"{detail}. {suggestion}"
    else:
        detail = f"{detail}. Tip: leave --scenario blank, use `--preset baseline_t1d`, or create one with `iints scenarios generate`."
    return detail


def _patient_config_not_found_message(target: Path) -> str:
    suggestion = _suggest_path_message(target, glob_pattern="**/*.yaml")
    detail = f"Patient config file not found: {target}"
    if suggestion:
        detail = f"{detail}. {suggestion}"
    else:
        detail = f"{detail}. Tip: use `--preset baseline_t1d` or create one with `iints profiles create`."
    return detail


def _run_progress(console: Console) -> Progress:
    return Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(bar_width=28),
        TextColumn("{task.completed}/{task.total}"),
        TimeElapsedColumn(),
        console=console,
        transient=True,
    )


def _print_run_summary(
    console: Console,
    *,
    algorithm_name: str,
    output_dir: Path,
    metrics: Dict[str, float],
    duration_minutes: int,
    seed: int,
    wall_seconds: float,
    preset_name: Optional[str] = None,
) -> None:
    lines = [
        f"Algorithm: [green]{algorithm_name}[/green]",
        f"Preset: [cyan]{preset_name}[/cyan]" if preset_name else "Preset: [dim]custom[/dim]",
        f"Duration: {duration_minutes} min",
        f"Seed: {seed}",
        f"Wall time: {wall_seconds:.1f}s",
        "",
        f"TIR 70-180: [bold]{metrics.get('tir_70_180', float('nan')):.1f}%[/bold]",
        f"Below 70: {metrics.get('tir_below_70', float('nan')):.1f}%",
        f"Above 180: {metrics.get('tir_above_180', float('nan')):.1f}%",
        f"Mean glucose: {metrics.get('mean_glucose', float('nan')):.1f} mg/dL",
        f"Safety interventions: {metrics.get('supervisor_interventions', 0.0):.0f}",
        "",
        f"Results: {output_dir / 'results.csv'}",
        f"Report: {output_dir / 'report.pdf'}",
        f"Manifest: {output_dir / 'run_manifest.json'}",
    ]
    console.print(Panel("\n".join(lines), title="Run Complete", border_style="green"))


def _print_dry_run_plan(
    console: Console,
    *,
    algorithm_label: str,
    algorithm_source: str,
    patient_label: str,
    scenario_label: str,
    duration: int,
    time_step: int,
    output_dir: Path,
    compare_baselines: bool,
    seed: int,
    preset_name: Optional[str] = None,
) -> None:
    table = Table(title="Dry Run Plan", show_lines=False)
    table.add_column("Field", style="cyan")
    table.add_column("Value")
    table.add_row("Preset", preset_name or "custom")
    table.add_row("Algorithm", algorithm_label)
    table.add_row("Algorithm source", algorithm_source)
    table.add_row("Patient", patient_label)
    table.add_row("Scenario", scenario_label)
    table.add_row("Duration", f"{duration} min")
    table.add_row("Time step", f"{time_step} min")
    table.add_row("Seed", str(seed))
    table.add_row("Compare baselines", "yes" if compare_baselines else "no")
    table.add_row("Output dir", str(output_dir))
    console.print(table)
    console.print(
        Panel(
            "\n".join(
                [
                    "Nothing was executed.",
                    "Expected outputs:",
                    f"- {output_dir / 'results.csv'}",
                    f"- {output_dir / 'report.pdf'}",
                    f"- {output_dir / 'run_manifest.json'}",
                ]
            ),
            title="Next",
            border_style="blue",
        )
    )


def _parse_column_mapping(items: List[str], console: Console) -> Dict[str, str]:
    mapping: Dict[str, str] = {}
    for item in items:
        if "=" not in item:
            console.print(f"[bold red]Invalid mapping '{item}'. Use key=value.[/bold red]")
            raise typer.Exit(code=1)
        key, value = item.split("=", 1)
        key = key.strip()
        value = value.strip()
        if not key or not value:
            console.print(f"[bold red]Invalid mapping '{item}'. Use key=value.[/bold red]")
            raise typer.Exit(code=1)
        mapping[key] = value
    return mapping


def _load_json_dict(path: Path, label: str) -> Dict[str, Any]:
    try:
        payload = json.loads(path.read_text())
    except json.JSONDecodeError as exc:
        raise ValueError(f"{label} is not valid JSON: {exc}") from exc
    if not isinstance(payload, dict):
        raise ValueError(f"{label} must be a JSON object")
    return payload


def _module_available(module_name: str) -> bool:
    try:
        importlib.import_module(module_name)
        return True
    except Exception:
        return False


def _parse_float_csv(values: str, label: str) -> List[float]:
    parsed: List[float] = []
    for token in values.split(","):
        token = token.strip()
        if not token:
            continue
        try:
            parsed.append(float(token))
        except ValueError as exc:
            raise ValueError(f"Invalid float in {label}: '{token}'") from exc
    if not parsed:
        raise ValueError(f"{label} cannot be empty")
    return parsed


def _load_predictor_service_from_path(predictor_path: Optional[Path], console: Console) -> Optional[object]:
    if predictor_path is None:
        return None
    if not predictor_path.is_file():
        console.print(f"[bold red]Predictor checkpoint not found: {predictor_path}[/bold red]")
        raise typer.Exit(code=1)
    try:
        from iints.research.predictor import load_predictor_service

        return load_predictor_service(predictor_path)
    except Exception as exc:
        console.print(
            "[bold red]Could not load predictor service. Install research extras "
            "(`pip install iints-sdk-python35[research]`) and verify the checkpoint format.[/bold red]"
        )
        console.print(f"[red]Details:[/red] {exc}")
        raise typer.Exit(code=1)


def _build_safety_config_from_options(**kwargs: Any) -> Optional[SafetyConfig]:
    if all(value is None for value in kwargs.values()):
        return None
    config = SafetyConfig()
    for key, value in kwargs.items():
        if value is not None:
            setattr(config, key, value)
    return config


def _build_safety_config_from_dict(values: Optional[Dict[str, Any]]) -> Optional[SafetyConfig]:
    if not values:
        return None
    config = SafetyConfig()
    for key, value in values.items():
        setattr(config, key, value)
    return config


def _run_parallel_job(job: Dict[str, Any]) -> Dict[str, Any]:
    algo_path = Path(job["algo"])
    scenario_path = Path(job["scenario_path"])
    output_dir = Path(job["output_dir"])
    patient_config = job["patient_config"]
    safety_config = _build_safety_config_from_dict(job.get("safety_overrides"))
    algorithm_instance = _load_algorithm_instance_silent(algo_path)
    predictor = None
    predictor_path = job.get("predictor_path")
    if predictor_path:
        from iints.research.predictor import load_predictor_service

        predictor = load_predictor_service(Path(predictor_path))

    outputs = iints.run_simulation(
        algorithm=algorithm_instance,
        scenario=str(scenario_path),
        patient_config=patient_config,
        duration_minutes=int(job["duration_minutes"]),
        time_step=int(job["time_step"]),
        seed=job.get("seed"),
        output_dir=output_dir,
        compare_baselines=bool(job.get("compare_baselines")),
        export_audit=bool(job.get("export_audit")),
        generate_report=bool(job.get("generate_report")),
        safety_config=safety_config,
        predictor=predictor,
    )
    outputs.pop("results", None)
    safety_report = outputs.get("safety_report", {})
    return {
        "scenario": scenario_path.stem,
        "patient": job["patient_label"],
        "output_dir": str(output_dir),
        "results_csv": outputs.get("results_csv"),
        "report_pdf": outputs.get("report_pdf"),
        "run_manifest": outputs.get("run_manifest_path"),
        "terminated_early": safety_report.get("terminated_early", False),
        "total_violations": safety_report.get("total_violations", 0),
        "error": "",
    }

@app.command()
def evaluate(
    algo: Annotated[Path, typer.Option(help="Path to the algorithm Python file")],
    population: Annotated[int, typer.Option(help="Number of virtual patients to simulate")] = 100,
    patient_config_name: Annotated[str, typer.Option("--patient-config", help="Base patient configuration name")] = "default_patient",
    patient_config_path: Annotated[Optional[Path], typer.Option("--patient-config-path", help="Path to base patient config YAML")] = None,
    scenario_path: Annotated[Optional[Path], typer.Option("--scenario", help="Path to scenario JSON")] = None,
    duration: Annotated[int, typer.Option(help="Simulation duration in minutes")] = 720,
    time_step: Annotated[int, typer.Option(help="Time step in minutes")] = 5,
    output_dir: Annotated[Optional[Path], typer.Option(help="Output directory")] = None,
    max_workers: Annotated[Optional[int], typer.Option(help="Max parallel workers (default: all cores)")] = None,
    seed: Annotated[Optional[int], typer.Option(help="Random seed for reproducibility")] = None,
    patient_model: Annotated[str, typer.Option("--patient-model", help="Patient model: auto, bergman, custom, simglucose")] = "auto",
):
    """
    Run a Monte Carlo population evaluation of an algorithm.

    Generates N virtual patients with physiological variation, runs each
    through the simulator in parallel, and reports aggregate TIR, hypo-risk,
    and Safety Index with 95% confidence intervals.

    Example:
        iints evaluate --algo my_algo.py --population 500 --seed 42
    """
    console = Console()
    console.print(f"[bold blue]IINTS-AF Population Evaluation[/bold blue]")
    console.print(f"  Algorithm:       [green]{algo.name}[/green]")
    console.print(f"  Population size: [cyan]{population}[/cyan]")
    console.print(f"  Patient model:   [cyan]{patient_model}[/cyan]")
    console.print(f"  Duration:        {duration} min")
    console.print()

    # Validate algo file exists
    _load_algorithm_instance(algo, console)

    patient_config: Union[str, Path] = str(patient_config_path) if patient_config_path else patient_config_name
    scenario = str(scenario_path) if scenario_path else None

    from iints.highlevel import run_population

    with console.status("[bold green]Running population evaluation...", spinner="dots"):
        results = run_population(
            algo_path=str(algo),
            n_patients=population,
            scenario=scenario,
            patient_config=patient_config,
            duration_minutes=duration,
            time_step=time_step,
            seed=seed,
            output_dir=str(output_dir) if output_dir else None,
            max_workers=max_workers,
            patient_model_type=patient_model,
        )

    report = results["population_report"]
    agg = report["aggregate_metrics"]
    safety_agg = report["aggregate_safety"]

    # --- Results table ---
    table = Table(title=f"Population Evaluation Results (N={population})")
    table.add_column("Metric", style="cyan", min_width=25)
    table.add_column("Mean", justify="right", style="green")
    table.add_column("95% CI", justify="right", style="yellow")
    table.add_column("Std", justify="right", style="dim")

    _METRIC_DISPLAY = {
        "tir_70_180": "TIR 70-180 mg/dL (%)",
        "tir_below_70": "Time <70 mg/dL (%)",
        "tir_below_54": "Time <54 mg/dL (%)",
        "tir_above_180": "Time >180 mg/dL (%)",
        "mean_glucose": "Mean Glucose (mg/dL)",
        "cv": "Coefficient of Variation (%)",
        "gmi": "Glucose Management Indicator (%)",
    }

    for metric_key, stats in agg.items():
        label = _METRIC_DISPLAY.get(metric_key, metric_key)
        table.add_row(
            label,
            f"{stats['mean']:.1f}",
            f"[{stats['ci_lower']:.1f}, {stats['ci_upper']:.1f}]",
            f"{stats['std']:.1f}",
        )

    if "safety_index" in safety_agg:
        si = safety_agg["safety_index"]
        table.add_row(
            "[bold]Safety Index[/bold]",
            f"[bold]{si['mean']:.1f}[/bold]",
            f"[{si['ci_lower']:.1f}, {si['ci_upper']:.1f}]",
            f"{si['std']:.1f}",
        )

    console.print(table)

    # --- Grade distribution ---
    if "grade_distribution" in safety_agg:
        console.print()
        grade_table = Table(title="Safety Grade Distribution")
        grade_table.add_column("Grade", style="bold")
        grade_table.add_column("Count", justify="right")
        grade_table.add_column("Percentage", justify="right")
        for grade in ["A", "B", "C", "D", "F"]:
            count = safety_agg["grade_distribution"].get(grade, 0)
            pct = count / population * 100 if population else 0
            grade_table.add_row(grade, str(count), f"{pct:.1f}%")
        console.print(grade_table)

    etr = safety_agg.get("early_termination_rate")
    if etr is not None and etr > 0:
        console.print(f"\n[yellow]Early termination rate: {etr * 100:.1f}%[/yellow]")

    console.print(f"\n[green]Results saved to:[/green] {results['output_dir']}")
    console.print(f"  - population_summary.csv")
    console.print(f"  - population_report.json")
    console.print(f"  - population_report.pdf")


@app.command(name="doctor")
def doctor(
    smoke_run: Annotated[bool, typer.Option(help="Run a short deterministic smoke simulation")] = False,
    smoke_duration: Annotated[int, typer.Option(help="Smoke simulation duration in minutes")] = 30,
    full: Annotated[bool, typer.Option("--full", help="Run extra environment checks that help beginners debug setup issues")] = False,
    suggest: Annotated[bool, typer.Option("--suggest", help="Print concrete next commands based on what doctor finds")] = False,
):
    """
    Environment and installation health-check.

    Examples:
      iints doctor
      iints doctor --smoke-run --suggest
      iints doctor --full
    """
    console = Console()
    required_checks: List[Tuple[str, bool, str]] = []
    suggestions: List[str] = []

    py_ok = sys.version_info >= (3, 10)
    required_checks.append(
        ("Python >= 3.10", py_ok, f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}")
    )
    if not py_ok:
        suggestions.append("Install Python 3.10 or newer, recreate your virtual environment, then rerun `iints doctor`.")

    package_checks = [
        ("pandas", True, "core"),
        ("numpy", True, "core"),
        ("typer", True, "core"),
        ("rich", True, "core"),
        ("yaml", True, "core"),
        ("torch", False, "research"),
        ("onnx", False, "research"),
        ("onnxscript", False, "research"),
        ("h5py", False, "research"),
    ]

    table = Table(title="IINTS Doctor", show_lines=False)
    table.add_column("Check", style="cyan")
    table.add_column("Status", style="bold")
    table.add_column("Detail", style="dim")

    for check_name, passed, detail in required_checks:
        table.add_row(check_name, "[green]OK[/green]" if passed else "[red]FAIL[/red]", detail)

    for module_name, required, category in package_checks:
        available = _module_available(module_name)
        status = "[green]OK[/green]" if available else ("[red]MISSING[/red]" if required else "[yellow]optional[/yellow]")
        extra = f"{category} dependency"
        table.add_row(f"Module: {module_name}", status, extra)
        if required:
            required_checks.append((f"Module: {module_name}", available, extra))
            if not available:
                suggestions.append(
                    "Install the main SDK stack with `python -m pip install -U \"iints-sdk-python35[full,mdmp]\"`."
                )
        elif full and not available:
            suggestions.append(
                f"Optional package `{module_name}` is missing. Add it later if you need the {category} workflow."
            )

    try:
        presets = _load_presets()
        presets_ok = len(presets) > 0
        table.add_row("Preset bundle", "[green]OK[/green]" if presets_ok else "[red]FAIL[/red]", f"{len(presets)} presets loaded")
        required_checks.append(("Preset bundle", presets_ok, f"{len(presets)} presets"))
    except Exception as exc:
        table.add_row("Preset bundle", "[red]FAIL[/red]", str(exc))
        required_checks.append(("Preset bundle", False, str(exc)))
        suggestions.append("Reinstall the package from a clean virtual environment so the bundled presets are restored.")

    try:
        profiles = load_validation_profiles()
        profiles_ok = len(profiles) > 0
        table.add_row(
            "Validation profiles",
            "[green]OK[/green]" if profiles_ok else "[red]FAIL[/red]",
            ", ".join(sorted(profiles.keys())) if profiles else "none",
        )
        required_checks.append(("Validation profiles", profiles_ok, f"{len(profiles)} profiles"))
    except Exception as exc:
        table.add_row("Validation profiles", "[red]FAIL[/red]", str(exc))
        required_checks.append(("Validation profiles", False, str(exc)))
        suggestions.append("Reinstall or update the SDK so the validation profile bundle is available again.")

    if full:
        demo_df_ok = False
        try:
            demo_df_ok = not load_demo_dataframe().empty
        except Exception as exc:
            table.add_row("Bundled demo data", "[red]FAIL[/red]", str(exc))
            required_checks.append(("Bundled demo data", False, str(exc)))
            suggestions.append("Use `iints demo` once the package install is clean; it relies on the bundled demo assets.")
        else:
            table.add_row("Bundled demo data", "[green]OK[/green]" if demo_df_ok else "[red]FAIL[/red]", "embedded sample pack")
            required_checks.append(("Bundled demo data", demo_df_ok, "embedded sample pack"))

        cwd_writable = os.access(Path.cwd(), os.W_OK)
        table.add_row("Current folder writable", "[green]OK[/green]" if cwd_writable else "[red]FAIL[/red]", str(Path.cwd()))
        required_checks.append(("Current folder writable", cwd_writable, str(Path.cwd())))
        if not cwd_writable:
            suggestions.append("Switch to a writable project folder before running `iints demo` or `iints quickstart`.")

        dataset_registry_ok = True
        dataset_detail = "public registry loaded"
        try:
            dataset_registry_ok = len(load_dataset_registry()) > 0
            dataset_detail = f"{len(load_dataset_registry())} public packs"
        except Exception as exc:
            dataset_registry_ok = False
            dataset_detail = str(exc)
            suggestions.append("If data packs fail to load, reinstall the SDK or inspect `src/iints/data/datasets.json` in a source checkout.")
        table.add_row("Dataset registry", "[green]OK[/green]" if dataset_registry_ok else "[red]FAIL[/red]", dataset_detail)
        required_checks.append(("Dataset registry", dataset_registry_ok, dataset_detail))

    if smoke_run:
        try:
            with tempfile.TemporaryDirectory(prefix="iints_doctor_") as tmp:
                smoke_outputs = iints.run_simulation(
                    algorithm=iints.ConstantDoseAlgorithm(),
                    duration_minutes=max(smoke_duration, 5),
                    output_dir=Path(tmp),
                    compare_baselines=False,
                    export_audit=False,
                    generate_report=False,
                    seed=42,
                )
                results_path = smoke_outputs.get("results_csv", "")
                smoke_ok = bool(results_path) and Path(results_path).is_file()
                detail = f"results: {results_path}" if smoke_ok else "simulation output missing"
                table.add_row("Smoke simulation", "[green]OK[/green]" if smoke_ok else "[red]FAIL[/red]", detail)
                required_checks.append(("Smoke simulation", smoke_ok, detail))
                if not smoke_ok:
                    suggestions.append("Run `iints demo --dry-run` to confirm the SDK can at least resolve a complete run plan.")
        except Exception as exc:
            table.add_row("Smoke simulation", "[red]FAIL[/red]", str(exc))
            required_checks.append(("Smoke simulation", False, str(exc)))
            suggestions.append("Run `iints doctor --smoke-run --suggest` inside your active virtual environment for a fuller diagnosis.")

    console.print(table)
    if suggest:
        deduped: List[str] = []
        for item in suggestions:
            if item not in deduped:
                deduped.append(item)
        if deduped:
            escaped = [item.replace("[", "\\[").replace("]", "\\]") for item in deduped]
            console.print(
                Panel(
                    "\n".join(f"{idx}. {item}" for idx, item in enumerate(escaped, start=1)),
                    title="Suggested Next Steps",
                    border_style="blue",
                )
            )
        else:
            console.print(Panel("Everything essential looks healthy. A good next command is `iints demo`.", title="Suggested Next Steps", border_style="green"))
    if not all(passed for _, passed, _ in required_checks):
        raise typer.Exit(code=1)


@app.command(name="validation-profiles")
def validation_profiles(
    profiles_path: Annotated[Optional[Path], typer.Option(help="Optional custom profiles YAML")] = None,
):
    """List available run-validation profiles."""
    console = Console()
    try:
        profiles = load_validation_profiles(profiles_path)
    except Exception as exc:
        console.print(f"[bold red]Could not load validation profiles: {exc}[/bold red]")
        raise typer.Exit(code=1)

    table = Table(title="Validation Profiles")
    table.add_column("Profile", style="cyan")
    table.add_column("Min Duration (min)", justify="right")
    table.add_column("Checks", justify="right")
    table.add_column("Description")
    for profile_id, profile in sorted(profiles.items()):
        table.add_row(
            profile_id,
            str(profile.min_duration_minutes),
            str(len(profile.checks)),
            profile.description,
        )
    console.print(table)


@app.command(name="replay-check")
def replay_check(
    algo: Annotated[Path, typer.Option(help="Path to the algorithm Python file")],
    predictor_path: Annotated[Optional[Path], typer.Option("--predictor", help="Optional predictor checkpoint (.pt)")] = None,
    patient_config_name: Annotated[str, typer.Option(help="Patient config name")] = "default_patient",
    patient_config_path: Annotated[Optional[Path], typer.Option(help="Patient config YAML path")] = None,
    scenario_path: Annotated[Optional[Path], typer.Option(help="Path to scenario JSON")] = None,
    duration: Annotated[int, typer.Option(help="Simulation duration in minutes")] = 240,
    time_step: Annotated[int, typer.Option(help="Simulation time step in minutes")] = 5,
    seed: Annotated[int, typer.Option(help="Deterministic seed")] = 42,
    repeats: Annotated[int, typer.Option(help="Replay runs to compare")] = 2,
    output_json: Annotated[Optional[Path], typer.Option(help="Optional output JSON path")] = None,
    fail_on_mismatch: Annotated[bool, typer.Option(help="Exit code 1 if replay mismatch is detected")] = True,
):
    """
    Deterministic replay suite: same seed, same config, same output hashes.
    """
    console = Console()
    algorithm_instance = _load_algorithm_instance(algo, console)
    predictor = _load_predictor_service_from_path(predictor_path, console)

    patient_config: Union[str, Path]
    if patient_config_path:
        if not patient_config_path.is_file():
            console.print(f"[bold red]Patient config file not found: {patient_config_path}[/bold red]")
            raise typer.Exit(code=1)
        patient_config = patient_config_path
    else:
        patient_config = patient_config_name

    scenario_payload: Optional[Dict[str, Any]] = None
    if scenario_path:
        if not scenario_path.is_file():
            console.print(f"[bold red]Scenario file not found: {scenario_path}[/bold red]")
            raise typer.Exit(code=1)
        scenario_payload = load_scenario(scenario_path).model_dump()

    result = run_deterministic_replay_check(
        algorithm=algorithm_instance,
        scenario=scenario_payload,
        patient_config=patient_config,
        duration_minutes=duration,
        time_step=time_step,
        seed=seed,
        repeats=max(2, repeats),
        predictor=predictor,
    )

    table = Table(title="Deterministic Replay Check")
    table.add_column("Run", style="cyan")
    table.add_column("Rows", justify="right")
    table.add_column("Results Hash")
    table.add_column("Safety Hash")
    for idx, digest in enumerate(result.digests, start=1):
        table.add_row(str(idx), str(digest.rows), digest.results_hash[:16], digest.safety_hash[:16])
    console.print(table)
    console.print("[green]PASS[/green]" if result.passed else "[red]FAIL[/red]")

    if output_json is not None:
        output_json.parent.mkdir(parents=True, exist_ok=True)
        output_json.write_text(json.dumps(result.to_dict(), indent=2))
        console.print(f"[green]Replay report written:[/green] {output_json}")

    if fail_on_mismatch and not result.passed:
        raise typer.Exit(code=1)


@app.command(name="golden-benchmark")
def golden_benchmark(
    algo: Annotated[Path, typer.Option(help="Path to the algorithm Python file")],
    predictor_path: Annotated[Optional[Path], typer.Option("--predictor", help="Optional predictor checkpoint (.pt)")] = None,
    pack_path: Annotated[Optional[Path], typer.Option(help="Optional golden benchmark YAML path")] = None,
    output_dir: Annotated[Optional[Path], typer.Option(help="Optional output directory for benchmark runs")] = None,
    seed: Annotated[int, typer.Option(help="Random seed")] = 42,
    duration_override: Annotated[Optional[int], typer.Option(help="Optional duration override (minutes)")] = None,
    output_json: Annotated[Optional[Path], typer.Option(help="Write benchmark report JSON")] = None,
    fail_on_check: Annotated[bool, typer.Option(help="Exit code 1 when any scenario fails")] = True,
):
    """
    Run a golden scenario pack and validate metrics against expected ranges.
    """
    console = Console()
    algorithm_instance = _load_algorithm_instance(algo, console)
    predictor = _load_predictor_service_from_path(predictor_path, console)

    try:
        pack = load_golden_benchmark_pack(pack_path)
    except Exception as exc:
        console.print(f"[bold red]Could not load golden benchmark pack: {exc}[/bold red]")
        raise typer.Exit(code=1)

    if not pack.scenarios:
        console.print("[bold red]Golden benchmark pack contains no scenarios.[/bold red]")
        raise typer.Exit(code=1)

    run_root = output_dir
    temp_dir: Optional[tempfile.TemporaryDirectory[str]] = None
    if run_root is None:
        temp_dir = tempfile.TemporaryDirectory(prefix="iints_golden_")
        run_root = Path(temp_dir.name)
    run_root.mkdir(parents=True, exist_ok=True)

    scenario_results: List[Dict[str, Any]] = []
    all_passed = True

    for idx, scenario_spec in enumerate(pack.scenarios):
        algorithm_instance.reset()
        try:
            preset = _get_preset(scenario_spec.preset)
        except KeyError:
            console.print(f"[bold red]Unknown preset in golden pack: {scenario_spec.preset}[/bold red]")
            if temp_dir is not None:
                temp_dir.cleanup()
            raise typer.Exit(code=1)

        duration_minutes = int(duration_override if duration_override is not None else preset.get("duration_minutes", 720))
        time_step_minutes = int(preset.get("time_step_minutes", 5))
        scenario_output = run_root / f"{idx+1:02d}_{scenario_spec.preset}"

        outputs = iints.run_simulation(
            algorithm=algorithm_instance,
            scenario=preset.get("scenario"),
            patient_config=str(preset.get("patient_config", "default_patient")),
            duration_minutes=duration_minutes,
            time_step=time_step_minutes,
            seed=seed,
            output_dir=scenario_output,
            compare_baselines=False,
            export_audit=False,
            generate_report=False,
            predictor=predictor,
        )

        metrics = compute_run_metrics(
            outputs["results"],
            safety_report=outputs.get("safety_report"),
            duration_minutes=duration_minutes,
        )
        checks = evaluate_expected_ranges(metrics, scenario_spec.expected)
        passed = all(item.get("passed", False) for item in checks.values())
        all_passed = all_passed and passed

        scenario_results.append(
            {
                "preset": scenario_spec.preset,
                "description": scenario_spec.description,
                "passed": passed,
                "metrics": metrics,
                "checks": checks,
                "output_dir": str(scenario_output),
            }
        )

    table = Table(title=f"Golden Benchmark Pack — {pack.name} v{pack.version}")
    table.add_column("Preset", style="cyan")
    table.add_column("Status", style="bold")
    table.add_column("Checks", justify="right")
    table.add_column("Failed Metrics")
    for row in scenario_results:
        failed_metrics = [metric for metric, check in row["checks"].items() if not check.get("passed", False)]
        table.add_row(
            row["preset"],
            "[green]PASS[/green]" if row["passed"] else "[red]FAIL[/red]",
            str(len(row["checks"])),
            ", ".join(failed_metrics) if failed_metrics else "-",
        )
    console.print(table)
    console.print("[green]Golden benchmark PASS[/green]" if all_passed else "[red]Golden benchmark FAIL[/red]")

    payload = {
        "pack": {"name": pack.name, "version": pack.version},
        "seed": seed,
        "duration_override": duration_override,
        "passed": all_passed,
        "scenarios": scenario_results,
    }
    if output_json is not None:
        output_json.parent.mkdir(parents=True, exist_ok=True)
        output_json.write_text(json.dumps(payload, indent=2))
        console.print(f"[green]Golden benchmark report written:[/green] {output_json}")

    if temp_dir is not None:
        temp_dir.cleanup()

    if fail_on_check and not all_passed:
        raise typer.Exit(code=1)


@app.command(name="validate-run")
def validate_run(
    results_csv: Annotated[Path, typer.Option(help="Path to simulation results CSV")],
    profile: Annotated[str, typer.Option(help="Validation profile id")] = "research_default",
    safety_report_path: Annotated[Optional[Path], typer.Option(help="Optional safety report JSON")] = None,
    duration_minutes: Annotated[Optional[int], typer.Option(help="Override run duration (minutes)")] = None,
    profiles_path: Annotated[Optional[Path], typer.Option(help="Optional custom profiles YAML")] = None,
    output_json: Annotated[Optional[Path], typer.Option(help="Write validation report JSON")] = None,
    fail_on_check: Annotated[bool, typer.Option(help="Exit with code 1 when required checks fail")] = True,
):
    """
    Validate a simulation run against a profile (TIR/hypo/CV/safety gates).
    """
    console = Console()
    if not results_csv.is_file():
        console.print(f"[bold red]Results file not found: {results_csv}[/bold red]")
        raise typer.Exit(code=1)

    try:
        profiles = load_validation_profiles(profiles_path)
    except Exception as exc:
        console.print(f"[bold red]Could not load validation profiles: {exc}[/bold red]")
        raise typer.Exit(code=1)

    selected_profile = profiles.get(profile)
    if selected_profile is None:
        available = ", ".join(sorted(profiles.keys()))
        console.print(f"[bold red]Unknown profile '{profile}'. Available: {available}[/bold red]")
        raise typer.Exit(code=1)

    safety_report: Optional[Dict[str, Any]] = None
    if safety_report_path is not None:
        if not safety_report_path.is_file():
            console.print(f"[bold red]Safety report not found: {safety_report_path}[/bold red]")
            raise typer.Exit(code=1)
        try:
            safety_report = _load_json_dict(safety_report_path, "safety report")
        except ValueError as exc:
            console.print(f"[bold red]{exc}[/bold red]")
            raise typer.Exit(code=1)

    try:
        results_df = pd.read_csv(results_csv)
    except Exception as exc:
        console.print(f"[bold red]Could not read results CSV: {exc}[/bold red]")
        raise typer.Exit(code=1)

    try:
        report = evaluate_run(
            results_df,
            profile=selected_profile,
            safety_report=safety_report,
            duration_minutes=duration_minutes,
        )
    except Exception as exc:
        console.print(f"[bold red]Run validation failed: {exc}[/bold red]")
        raise typer.Exit(code=1)

    summary = Table(title=f"Run Validation — {selected_profile.profile_id}")
    summary.add_column("Field", style="cyan")
    summary.add_column("Value", style="white")
    summary.add_row("Profile description", selected_profile.description)
    summary.add_row(
        "Required checks",
        f"{report.required_checks_passed}/{report.required_checks_total}",
    )
    summary.add_row("Score", f"{report.score:.1f}")
    summary.add_row("Overall", "[green]PASS[/green]" if report.passed else "[red]FAIL[/red]")
    console.print(summary)

    checks_table = Table(title="Validation Checks")
    checks_table.add_column("Status", style="bold")
    checks_table.add_column("Check")
    checks_table.add_column("Value", justify="right")
    checks_table.add_column("Target", justify="right")
    checks_table.add_column("Required", justify="center")
    for check in report.checks:
        status = "[green]PASS[/green]" if check.passed else "[red]FAIL[/red]"
        value = "n/a" if check.value is None else f"{check.value:.2f}"
        target = f"{check.rule.op} {check.rule.threshold:g}"
        checks_table.add_row(
            status,
            check.rule.label,
            value,
            target,
            "yes" if check.rule.required else "no",
        )
    console.print(checks_table)

    metrics_table = Table(title="Computed Metrics")
    metrics_table.add_column("Metric", style="cyan")
    metrics_table.add_column("Value", justify="right")
    for key, metric_value in sorted(report.metrics.items()):
        metrics_table.add_row(key, f"{metric_value:.3f}")
    console.print(metrics_table)

    if output_json is not None:
        output_json.parent.mkdir(parents=True, exist_ok=True)
        output_json.write_text(json.dumps(report.to_dict(), indent=2))
        console.print(f"[green]Validation report written:[/green] {output_json}")

    if fail_on_check and not report.passed:
        raise typer.Exit(code=1)


def _study_summary_markdown(payload: Dict[str, Any]) -> str:
    aggregate = payload.get("aggregate", {})
    aggregate_stats = payload.get("aggregate_stats", {})
    certification = payload.get("certification_comparison", {})
    failure_analysis = payload.get("failure_analysis", {})
    study_protocol = payload.get("study_protocol")
    safety_summary = payload.get("safety_summary", {}) if isinstance(payload.get("safety_summary"), dict) else {}
    pairwise = payload.get("pairwise_baseline_deltas", {}) if isinstance(payload.get("pairwise_baseline_deltas"), dict) else {}
    external_validation = payload.get("external_validation")
    calibration_summary = payload.get("calibration_summary") if isinstance(payload.get("calibration_summary"), dict) else None
    uncertainty_summary = payload.get("uncertainty_summary") if isinstance(payload.get("uncertainty_summary"), dict) else None
    by_algorithm = payload.get("by_algorithm", {}) if isinstance(payload.get("by_algorithm"), dict) else {}
    by_profile = payload.get("by_profile", {}) if isinstance(payload.get("by_profile"), dict) else {}
    by_arm = payload.get("by_arm", {}) if isinstance(payload.get("by_arm"), dict) else {}
    by_scenario = payload.get("by_scenario", {}) if isinstance(payload.get("by_scenario"), dict) else {}

    lines = [
        "# IINTS Study Summary",
        "",
        f"- Study directory: `{payload.get('study_dir', '')}`",
        f"- Run count: `{payload.get('run_count', 0)}`",
        "",
        "## Aggregate",
        "",
        f"- Mean TIR 70-180: `{aggregate.get('mean_tir_70_180')}`",
        f"- Mean TIR <70: `{aggregate.get('mean_tir_below_70')}`",
        f"- Mean TIR <54: `{aggregate.get('mean_tir_below_54')}`",
        f"- Mean TIR >180: `{aggregate.get('mean_tir_above_180')}`",
        f"- Mean supervisor interventions: `{aggregate.get('mean_supervisor_interventions')}`",
        f"- Mean glucose: `{aggregate.get('mean_glucose')}`",
        f"- Mean CV: `{aggregate.get('mean_cv')}`",
        f"- Mean GMI: `{aggregate.get('mean_gmi')}`",
        f"- Mean predictor uncertainty: `{aggregate.get('mean_predictor_uncertainty_mean')}`",
        "",
        "## Descriptive Statistics",
        "",
        f"- TIR 70-180 std: `{aggregate_stats.get('tir_70_180', {}).get('std')}`",
        f"- TIR 70-180 95% CI: `[{aggregate_stats.get('tir_70_180', {}).get('ci95_low')}, {aggregate_stats.get('tir_70_180', {}).get('ci95_high')}]`",
        f"- Mean glucose std: `{aggregate_stats.get('mean_glucose', {}).get('std')}`",
        f"- Mean glucose 95% CI: `[{aggregate_stats.get('mean_glucose', {}).get('ci95_low')}, {aggregate_stats.get('mean_glucose', {}).get('ci95_high')}]`",
        "",
        "## Certification Comparison",
        "",
        f"- Certified runs: `{certification.get('certified_runs')}`",
        f"- Uncertified runs: `{certification.get('uncertified_runs')}`",
        f"- Mean TIR (certified): `{certification.get('mean_tir_70_180_certified')}`",
        f"- Mean TIR (uncertified): `{certification.get('mean_tir_70_180_uncertified')}`",
        "",
        "## Failure Analysis",
        "",
        f"- Terminated early runs: `{failure_analysis.get('terminated_early_runs')}`",
        f"- Severe hypo runs: `{failure_analysis.get('severe_hypo_runs')}`",
        f"- Supervisor-heavy runs: `{failure_analysis.get('supervisor_heavy_runs')}`",
        f"- Needs-review runs: `{failure_analysis.get('needs_review_runs')}`",
        "",
        "## Safety Summary",
        "",
        f"- Severe hypo run count: `{safety_summary.get('severe_hypo_run_count')}`",
        f"- Terminated early run count: `{safety_summary.get('terminated_early_run_count')}`",
        f"- Supervisor-on runs: `{safety_summary.get('supervisor_on_vs_off', {}).get('supervisor_on_runs')}`",
        f"- Supervisor-off runs: `{safety_summary.get('supervisor_on_vs_off', {}).get('supervisor_off_runs')}`",
        "",
    ]
    if isinstance(study_protocol, dict):
        lines.extend(
            [
                "## Protocol Reference",
                "",
                f"- Protocol source: `{study_protocol.get('source_path', '')}`",
                f"- Research question: {study_protocol.get('research_question', '')}",
                "",
            ]
        )
    if pairwise.get("baselines"):
        lines.extend(["## Candidate vs Baselines", ""])
        for baseline, details in pairwise.get("baselines", {}).items():
            lines.append(f"- `{baseline}` mean TIR delta: `{details.get('mean_deltas', {}).get('tir_70_180')}`")
        lines.append("")
    if by_algorithm:
        lines.extend(["## By Algorithm", ""])
        for algorithm, details in by_algorithm.items():
            lines.append(f"- `{algorithm}` mean TIR: `{details.get('aggregate', {}).get('mean_tir_70_180')}`")
        lines.append("")
    if by_profile:
        lines.extend(["## By Profile", ""])
        for profile, details in by_profile.items():
            lines.append(f"- `{profile}` mean TIR: `{details.get('aggregate', {}).get('mean_tir_70_180')}`")
        lines.append("")
    if by_arm:
        lines.extend(["## By Arm", ""])
        for arm, details in by_arm.items():
            lines.append(f"- `{arm}` mean TIR: `{details.get('aggregate', {}).get('mean_tir_70_180')}`")
        lines.append("")
    if by_scenario:
        lines.extend(["## By Scenario", ""])
        for scenario, details in by_scenario.items():
            lines.append(f"- `{scenario}` mean TIR: `{details.get('aggregate', {}).get('mean_tir_70_180')}`")
        lines.append("")
    if isinstance(calibration_summary, dict):
        overall = calibration_summary.get("overall", {})
        lines.extend(
            [
                "## Calibration Summary",
                "",
                f"- Mean MAE: `{overall.get('mean_mae')}`",
                f"- Mean RMSE: `{overall.get('mean_rmse')}`",
                f"- Mean interval coverage: `{overall.get('mean_interval_95_coverage_pct')}`",
                "",
            ]
        )
    if isinstance(uncertainty_summary, dict):
        overall = uncertainty_summary.get("overall", {})
        alignment = uncertainty_summary.get("uncertainty_vs_error", {}) if isinstance(uncertainty_summary.get("uncertainty_vs_error"), dict) else {}
        alignment_overall = alignment.get("overall", {}) if isinstance(alignment.get("overall"), dict) else {}
        lines.extend(
            [
                "## Uncertainty Summary",
                "",
                f"- Mean predictor std: `{overall.get('mean')}`",
                f"- P95 predictor std: `{overall.get('p95')}`",
                f"- Max predictor std: `{overall.get('max')}`",
                "",
            ]
        )
        if alignment_overall:
            lines.extend(
                [
                    "### Uncertainty Vs Error",
                    "",
                    f"- Mean absolute error: `{alignment_overall.get('mean_abs_error')}`",
                    f"- Correlation between predicted std and absolute error: `{alignment_overall.get('uncertainty_abs_error_corr')}`",
                    f"- High-vs-low uncertainty error gap: `{alignment_overall.get('high_vs_low_abs_error_gap')}`",
                    "",
                ]
            )
    if isinstance(external_validation, dict):
        lines.extend(
            [
                "## External Validation",
                "",
                f"- Reference path: `{external_validation.get('reference_path')}`",
                f"- Mean glucose delta: `{external_validation.get('delta_mean_glucose_mgdl')}`",
                f"- CV delta: `{external_validation.get('delta_cv_pct')}`",
                f"- TIR delta: `{external_validation.get('delta_tir_70_180_pct')}`",
                f"- Plausibility verdict: `{external_validation.get('plausibility_verdict')}`",
                "",
            ]
        )
    lines.extend(["## Runs", ""])
    for run in payload.get("runs", []):
        metrics = run.get("metrics", {})
        lines.extend(
            [
                f"### {run.get('scenario_name', run.get('run_id', 'run'))}",
                f"- Run id: `{run.get('run_id')}`",
                f"- Algorithm: `{run.get('algorithm')}` (`{run.get('algorithm_role')}`)",
                f"- Profile: `{run.get('profile_id')}`",
                f"- Condition group: `{run.get('condition_group')}`",
                f"- Scenario slug: `{run.get('scenario_slug')}`",
                f"- TIR 70-180: `{metrics.get('tir_70_180')}`",
                f"- TIR <70: `{metrics.get('tir_below_70')}`",
                f"- TIR >180: `{metrics.get('tir_above_180')}`",
                f"- Supervisor interventions: `{metrics.get('supervisor_interventions')}`",
                f"- Predictor uncertainty mean: `{run.get('predictor_uncertainty_mean')}`",
                f"- Certification grade: `{run.get('certification_grade')}`",
                "",
            ]
        )
    return "\n".join(lines).rstrip() + "\n"


def _write_evidence_table_csv(payload: Dict[str, Any], output_path: Path) -> None:
    rows = payload.get("evidence_rows", [])
    sanitize_csv_dataframe(pd.DataFrame(rows)).to_csv(output_path, index=False)


def _write_evidence_table_markdown(payload: Dict[str, Any], output_path: Path) -> None:
    rows = payload.get("evidence_rows", [])
    if not rows:
        output_path.write_text("# IINTS Evidence Table\n\nNo runs found.\n", encoding="utf-8")
        return
    columns = [
        "scenario_name",
        "scenario_slug",
        "study_arm",
        "condition_group",
        "algorithm",
        "algorithm_role",
        "profile_id",
        "seed",
        "tir_70_180",
        "tir_below_70",
        "tir_below_54",
        "tir_above_180",
        "tir_above_250",
        "mean_glucose",
        "cv",
        "gmi",
        "terminated_early",
        "supervisor_interventions",
        "predictor_uncertainty_mean",
        "certification_grade",
        "quality_badges",
    ]
    header = "| " + " | ".join(columns) + " |"
    divider = "| " + " | ".join(["---"] * len(columns)) + " |"
    lines = ["# IINTS Evidence Table", "", header, divider]
    for row in rows:
        lines.append("| " + " | ".join(str(row.get(column, "")) for column in columns) + " |")
    output_path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _study_comparison_markdown(payload: Dict[str, Any]) -> str:
    delta = payload.get("delta", {})
    effect_estimates = payload.get("effect_estimates", {})
    lines = [
        "# IINTS Study Comparison",
        "",
        f"- Left: `{payload.get('left_label')}`",
        f"- Right: `{payload.get('right_label')}`",
        "",
        "## Deltas (left minus right)",
        "",
        f"- Mean TIR 70-180: `{delta.get('mean_tir_70_180')}`",
        f"- Mean TIR <70: `{delta.get('mean_tir_below_70')}`",
        f"- Mean TIR <54: `{delta.get('mean_tir_below_54')}`",
        f"- Mean TIR >180: `{delta.get('mean_tir_above_180')}`",
        f"- Mean supervisor interventions: `{delta.get('mean_supervisor_interventions')}`",
        f"- Mean glucose: `{delta.get('mean_glucose')}`",
        f"- Mean CV: `{delta.get('mean_cv')}`",
        f"- Mean predictor uncertainty: `{delta.get('mean_predictor_uncertainty_mean')}`",
        f"- Certified runs: `{delta.get('certified_runs')}`",
        f"- Uncertified runs: `{delta.get('uncertified_runs')}`",
        f"- Severe hypo runs: `{delta.get('severe_hypo_runs')}`",
        "",
        "## Effect Estimates",
        "",
    ]
    for metric, estimate in effect_estimates.items():
        lines.extend(
            [
                f"### {metric}",
                f"- Difference in means: `{estimate.get('difference_in_means')}`",
                f"- 95% CI: `[{estimate.get('ci95_low')}, {estimate.get('ci95_high')}]`",
                f"- Cohen's d: `{estimate.get('cohens_d')}`",
                "",
            ]
        )
    for section_name in ("by_algorithm", "by_profile", "by_scenario"):
        section = payload.get(section_name, {})
        if not isinstance(section, dict) or not section:
            continue
        lines.extend([f"## {section_name.replace('_', ' ').title()}", ""])
        for label, metrics in section.items():
            lines.append(f"### {label}")
            tir = metrics.get("tir_70_180", {}) if isinstance(metrics, dict) else {}
            lines.append(f"- TIR diff: `{tir.get('difference_in_means')}`")
            lines.append(f"- TIR Cohen's d: `{tir.get('cohens_d')}`")
            lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def _supervisor_off_safety_config() -> SafetyConfig:
    return SafetyConfig(
        min_glucose=10.0,
        max_glucose=1000.0,
        max_glucose_delta_per_5_min=250.0,
        hypoglycemia_threshold=-1000.0,
        severe_hypoglycemia_threshold=-1000.0,
        hyperglycemia_threshold=10000.0,
        max_insulin_per_bolus=1000.0,
        glucose_rate_alarm=-1000.0,
        max_insulin_per_hour=1000.0,
        max_iob=1000.0,
        trend_stop=-1000.0,
        hypo_cutoff=-1000.0,
        predicted_hypoglycemia_threshold=-1000.0,
        predictor_uncertainty_gate_enabled=False,
        predictor_ood_gate_enabled=False,
        contract_enabled=False,
        critical_glucose_threshold=-1000.0,
        critical_glucose_duration_minutes=100000,
    )


def _annotate_eucys_run(
    run_dir: Path,
    *,
    condition_group: str,
    study_arm: str,
    protocol_preset: str,
    supervisor_enabled: bool,
    corruption_modes: List[str],
) -> None:
    for candidate in (run_dir / "run_metadata.json", run_dir / "config.json"):
        if not candidate.is_file():
            continue
        payload = json.loads(candidate.read_text(encoding="utf-8"))
        config: Dict[str, Any]
        if candidate.name == "run_metadata.json":
            config = payload.get("config", {}) if isinstance(payload.get("config"), dict) else {}
        else:
            config = payload if isinstance(payload, dict) else {}

        config["condition_group"] = condition_group
        config["study_condition"] = study_arm
        config["study_protocol_preset"] = protocol_preset
        config["supervisor_enabled"] = supervisor_enabled
        config["corruption_modes"] = corruption_modes
        scenario_payload = config.get("scenario", {}) if isinstance(config.get("scenario"), dict) else {}
        if scenario_payload:
            scenario_payload["condition_group"] = condition_group
            scenario_payload["study_arm"] = study_arm
            scenario_payload["supervisor_enabled"] = supervisor_enabled
            scenario_payload["corruption_modes"] = corruption_modes
            config["scenario"] = scenario_payload

        if candidate.name == "run_metadata.json":
            payload["config"] = config
        else:
            payload = config
        candidate.write_text(json.dumps(payload, indent=2), encoding="utf-8")


_PLUGIN_ALGORITHM_CLASS_CACHE: Dict[str, Any] = {}


def _algorithm_display_name(instance: Any, fallback: str) -> str:
    metadata_fn = getattr(instance, "get_algorithm_metadata", None)
    if callable(metadata_fn):
        try:
            metadata = metadata_fn()
            name = getattr(metadata, "name", None)
            if name:
                return str(name)
        except Exception:
            pass
    return fallback


def _load_algorithm_plugin_instance(display_name: str) -> iints.InsulinAlgorithm:
    if display_name not in _PLUGIN_ALGORITHM_CLASS_CACHE:
        entries = list_algorithm_plugins()
        match = next((entry for entry in entries if entry.name == display_name and entry.status == "available"), None)
        algorithm_class = None
        if match is not None:
            class_path = match.class_path.replace(":", ".")
            module_name, class_name = class_path.rsplit(".", 1)
            module = importlib.import_module(module_name)
            algorithm_class = getattr(module, class_name)
        else:
            fallback_registry = {
                "Clinical Baseline": ("iints.core.algorithms.clinical_baseline", "ClinicalBaselineAlgorithm"),
                "PID Controller": ("iints.core.algorithms.pid_controller", "PIDController"),
                "Standard Pump": ("iints.core.algorithms.standard_pump_algo", "StandardPumpAlgorithm"),
                "Correction Bolus": ("iints.core.algorithms.correction_bolus", "CorrectionBolus"),
            }
            fallback = fallback_registry.get(display_name)
            if fallback is None:
                raise ValueError(f"Algorithm plugin '{display_name}' is not available")
            module_name, class_name = fallback
            module = importlib.import_module(module_name)
            algorithm_class = getattr(module, class_name)
        _PLUGIN_ALGORITHM_CLASS_CACHE[display_name] = algorithm_class
    algorithm_class = _PLUGIN_ALGORITHM_CLASS_CACHE[display_name]
    return algorithm_class()


def _option_was_set(ctx: typer.Context, name: str) -> bool:
    try:
        return ctx.get_parameter_source(name) == ParameterSource.COMMANDLINE
    except Exception:
        return False


def _arm_output_dir_name(arm_id: str) -> str:
    return {
        "clean_certified": "study_clean",
        "corrupted_uncertified": "study_corrupted",
        "supervisor_off_ablation": "study_supervisor_off",
    }.get(arm_id, f"study_{slugify_study_token(arm_id)}")


def _annotate_study_run(
    run_dir: Path,
    *,
    condition_group: str,
    study_arm: str,
    protocol_preset: str,
    supervisor_enabled: bool,
    corruption_modes: List[str],
    algorithm_id: str,
    algorithm_role: str,
    profile_id: str,
    scenario_slug: str,
) -> None:
    for candidate in (run_dir / "run_metadata.json", run_dir / "config.json"):
        if not candidate.is_file():
            continue
        payload = json.loads(candidate.read_text(encoding="utf-8"))
        config: Dict[str, Any]
        if candidate.name == "run_metadata.json":
            config = payload.get("config", {}) if isinstance(payload.get("config"), dict) else {}
        else:
            config = payload if isinstance(payload, dict) else {}

        config["condition_group"] = condition_group
        config["study_condition"] = study_arm
        config["study_arm"] = study_arm
        config["study_protocol_preset"] = protocol_preset
        config["supervisor_enabled"] = supervisor_enabled
        config["corruption_modes"] = corruption_modes
        config["algorithm_id"] = algorithm_id
        config["algorithm_role"] = algorithm_role
        config["profile_id"] = profile_id
        config["scenario_slug"] = scenario_slug
        scenario_payload = config.get("scenario", {}) if isinstance(config.get("scenario"), dict) else {}
        if scenario_payload:
            scenario_payload["condition_group"] = condition_group
            scenario_payload["study_arm"] = study_arm
            scenario_payload["study_protocol_preset"] = protocol_preset
            scenario_payload["supervisor_enabled"] = supervisor_enabled
            scenario_payload["corruption_modes"] = corruption_modes
            scenario_payload["scenario_slug"] = scenario_slug
            config["scenario"] = scenario_payload

        if candidate.name == "run_metadata.json":
            payload["config"] = config
            payload["algorithm_id"] = algorithm_id
            payload["algorithm_role"] = algorithm_role
            payload["profile_id"] = profile_id
        else:
            payload = config
        candidate.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def _write_run_forecast_evaluation(
    run_dir: Path,
    *,
    gate_profile: Optional[str],
    gate_profiles_path: Optional[Path],
    fail_on_gate: bool,
) -> Optional[Path]:
    results_csv = run_dir / "results.csv"
    if not results_csv.is_file():
        return None
    df = pd.read_csv(results_csv)
    observed_column = "glucose_actual_mgdl"
    predicted_column = "predicted_glucose_ai_30min"
    if observed_column not in df.columns or predicted_column not in df.columns:
        return None

    from iints.research.evaluation import forecast_error_report

    predicted_std = None
    if "predictor_uncertainty_std_mgdl" in df.columns:
        predicted_std = pd.to_numeric(df["predictor_uncertainty_std_mgdl"], errors="coerce").to_numpy(dtype=float)
    report = forecast_error_report(
        df[observed_column].to_numpy(dtype=float),
        df[predicted_column].to_numpy(dtype=float),
        predicted_std,
    )

    if gate_profile:
        from iints.research.calibration_gate import evaluate_calibration_gate, load_calibration_gate_profiles

        profiles = load_calibration_gate_profiles(gate_profiles_path)
        gate = profiles.get(gate_profile)
        if gate is None:
            available = ", ".join(sorted(profiles.keys()))
            raise ValueError(f"Unknown calibration gate '{gate_profile}'. Available: {available}")
        checks = evaluate_calibration_gate(report, gate)
        passed = all(check.get("passed", False) for check in checks.values()) if checks else True
        report["calibration_gate"] = {
            "profile": gate_profile,
            "passed": passed,
            "checks": checks,
        }
        if fail_on_gate and not passed:
            raise ValueError(f"Calibration gate '{gate_profile}' failed for run {run_dir.name}")

    output_path = run_dir / "forecast_evaluation.json"
    output_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
    return output_path


def _write_study_arm_outputs(
    *,
    arm_dirs: Dict[str, Path],
    carelink_metrics: Optional[Path],
    title_prefix: str,
) -> Dict[str, Dict[str, Path]]:
    outputs: Dict[str, Dict[str, Path]] = {}
    for arm_id, study_root in arm_dirs.items():
        summary = analyze_study_directory(study_root, external_reference_metrics=carelink_metrics)
        payload = summary.to_dict()
        summary_json = study_root / "study_summary.json"
        summary_md = study_root / "study_summary.md"
        evidence_csv = study_root / "evidence_table.csv"
        evidence_md = study_root / "evidence_table.md"
        summary_json.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        summary_md.write_text(_study_summary_markdown(payload), encoding="utf-8")
        _write_evidence_table_csv(payload, evidence_csv)
        _write_evidence_table_markdown(payload, evidence_md)
        poster_outputs = generate_study_poster(
            summary,
            output_path=study_root / "study_poster.png",
            title=f"{title_prefix} - {arm_id.replace('_', ' ').title()}",
            subtitle="Closed-loop study evidence with fixed protocol metadata and subgroup summaries.",
            summary_output_path=study_root / "study_poster.json",
        )
        outputs[arm_id] = {
            "summary_json": summary_json,
            "summary_md": summary_md,
            "evidence_csv": evidence_csv,
            "evidence_md": evidence_md,
            "poster_png": Path(poster_outputs["poster_png"]),
            "poster_summary_json": Path(poster_outputs["poster_summary_json"]),
        }
    return outputs


def _write_study_comparisons(root_dir: Path, arm_dirs: Dict[str, Path]) -> list[Path]:
    comparisons_dir = root_dir / "comparisons"
    comparisons_dir.mkdir(parents=True, exist_ok=True)
    comparison_specs = [
        ("clean_vs_corrupted", arm_dirs.get("clean_certified"), arm_dirs.get("corrupted_uncertified")),
        ("clean_vs_supervisor_off", arm_dirs.get("clean_certified"), arm_dirs.get("supervisor_off_ablation")),
    ]
    outputs: list[Path] = []
    for slug, left_path, right_path in comparison_specs:
        if left_path is None or right_path is None:
            continue
        comparison = compare_studies(left_path, right_path, left_label=left_path.name, right_label=right_path.name)
        payload = comparison.to_dict()
        json_path = comparisons_dir / f"{slug}.json"
        md_path = comparisons_dir / f"{slug}.md"
        json_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        md_path.write_text(_study_comparison_markdown(payload), encoding="utf-8")
        outputs.extend([json_path, md_path])
    return outputs


def _write_eucys_result_package(
    *,
    root_dir: Path,
    protocol_outputs: Dict[str, str],
    per_arm_outputs: Dict[str, Dict[str, Path]],
    comparison_outputs: list[Path],
) -> Dict[str, Path]:
    bundle_outputs = generate_eucys_results_bundle(root_dir, output_dir=root_dir / "EUCYS_RESULTS")
    summary_path = root_dir / "EUCYS_SUMMARY.md"
    results_table_path = root_dir / "EUCYS_RESULTS_TABLE.csv"
    figure_manifest_path = root_dir / "EUCYS_FIGURE_MANIFEST.json"
    limitations_path = root_dir / "EUCYS_LIMITATIONS.md"
    abstract_filled_path = root_dir / "EUCYS_ABSTRACT_FILLED.md"
    main_figure_path = root_dir / "EUCYS_MAIN_FIGURE.png"
    main_figure_csv_path = root_dir / "EUCYS_MAIN_FIGURE.csv"

    shutil.copy2(bundle_outputs["summary_markdown"], summary_path)
    shutil.copy2(bundle_outputs["results_table_csv"], results_table_path)
    shutil.copy2(bundle_outputs["figure_manifest_json"], figure_manifest_path)
    shutil.copy2(bundle_outputs["limitations_markdown"], limitations_path)
    shutil.copy2(bundle_outputs["abstract_filled_markdown"], abstract_filled_path)
    shutil.copy2(bundle_outputs["main_figure_png"], main_figure_path)
    shutil.copy2(bundle_outputs["main_figure_csv"], main_figure_csv_path)
    return {
        "summary_markdown": summary_path,
        "results_table_csv": results_table_path,
        "figure_manifest_json": figure_manifest_path,
        "limitations_markdown": limitations_path,
        "abstract_filled_markdown": abstract_filled_path,
        "main_figure_png": main_figure_path,
        "main_figure_csv": main_figure_csv_path,
    }


def _run_study_bundle(
    *,
    algo: Path,
    output_dir: Path,
    preset: str,
    scenarios: Optional[List[str]],
    seeds: List[int],
    duration: Optional[int],
    time_step: int,
    carelink_metrics: Optional[Path],
    prepare_ai: bool,
    reference_csv: Optional[Path],
    profile_set: str,
    include_default_baselines: bool,
    extra_algorithms: Optional[List[str]],
    external_reference_label: str,
    gate_profile: Optional[str],
    gate_profiles_path: Optional[Path],
    fail_on_gate: bool,
) -> Dict[str, Any]:
    target_root = output_dir.expanduser().resolve()
    target_root.mkdir(parents=True, exist_ok=True)

    candidate_instance = _load_algorithm_instance_silent(algo)
    candidate_label = _algorithm_display_name(candidate_instance, algo.stem)
    design = build_study_design_payload(
        preset=preset,
        scenarios=scenarios,
        seeds=seeds,
        candidate_algorithm=candidate_label,
        include_default_baselines=include_default_baselines,
        extra_algorithms=extra_algorithms,
        profile_set=profile_set,
        external_reference_label=external_reference_label,
        candidate_source_type="path",
        candidate_source_ref=str(algo),
    )
    design_payload = design.to_dict()

    if preset == "eucys":
        pack_outputs = export_eucys_study_pack(target_root / "scenarios", seeds=seeds)
    else:
        pack_outputs = export_official_study_pack(target_root / "scenarios", seeds=seeds)
    protocol_outputs = write_study_protocol_bundle(
        target_root / "protocol",
        preset=preset,
        title="IINTS EUCYS Scientific Validation Protocol" if preset == "eucys" else "IINTS Scientific Validation Protocol",
        scenarios=scenarios,
        seeds=seeds,
        algorithms=[candidate_label],
        profile_set=profile_set,
        include_default_baselines=include_default_baselines,
        extra_algorithms=extra_algorithms,
        external_reference_label=external_reference_label,
    )
    if reference_csv is not None and reference_csv.is_file():
        write_corrupted_study_csv(
            reference_csv,
            output_csv=target_root / "protocol" / "reference_corrupted.csv",
            manifest_output=target_root / "protocol" / "reference_corrupted.manifest.json",
            modes=["timestamp_shift", "missing_block", "glucose_spikes"],
        )

    scenario_lookup = {str(item["slug"]): item for item in design_payload["scenarios"]}
    arm_lookup = {str(item["arm_id"]): item for item in design_payload["study_arms"]}
    algorithm_lookup = {str(item["algorithm_id"]): item for item in design_payload["algorithms"]}
    arm_dirs = {
        arm_id: target_root / _arm_output_dir_name(arm_id)
        for arm_id in arm_lookup
    }

    for row in design_payload["matrix_rows"]:
        scenario_meta = scenario_lookup[str(row["scenario_slug"])]
        arm = arm_lookup[str(row["arm_id"])]
        algorithm_spec = algorithm_lookup[str(row["algorithm_id"])]
        base_scenario = dict(scenario_meta["scenario"])
        scenario_payload, arm_manifest = build_eucys_arm_scenario(base_scenario, arm_id=str(row["arm_id"]))
        scenario_duration = int(duration or row["recommended_duration_minutes"])

        if algorithm_spec["source_type"] == "path":
            algorithm_instance = _load_algorithm_instance_silent(algo)
        else:
            algorithm_instance = _load_algorithm_plugin_instance(str(algorithm_spec["display_name"]))

        run_dir = (
            arm_dirs[str(row["arm_id"])]
            / str(row["algorithm_id"])
            / str(row["profile_id"])
            / f"{row['scenario_slug']}_seed_{row['seed']}"
        )
        safety_config = None if bool(arm["supervisor_enabled"]) else _supervisor_off_safety_config()
        outputs = iints.run_full(
            algorithm=algorithm_instance,
            scenario=scenario_payload,
            patient_config=str(row["profile_id"]),
            duration_minutes=scenario_duration,
            time_step=time_step,
            seed=int(row["seed"]),
            output_dir=run_dir,
            safety_config=safety_config,
        )
        resolved_run_dir = Path(outputs["output_dir"])
        _annotate_study_run(
            resolved_run_dir,
            condition_group=str(row["condition_group"]),
            study_arm=str(row["arm_id"]),
            protocol_preset=preset,
            supervisor_enabled=bool(arm["supervisor_enabled"]),
            corruption_modes=[str(item) for item in arm.get("corruption_modes", [])],
            algorithm_id=str(row["algorithm_id"]),
            algorithm_role=str(algorithm_spec["role"]),
            profile_id=str(row["profile_id"]),
            scenario_slug=str(row["scenario_slug"]),
        )
        write_json(
            resolved_run_dir / "study_arm_manifest.json",
            {
                "matrix_row": row,
                "study_preset": preset,
                "candidate_algorithm": candidate_label,
                "algorithm_spec": algorithm_spec,
                "scenario_mutation": arm_manifest,
            },
        )
        _write_run_forecast_evaluation(
            resolved_run_dir,
            gate_profile=gate_profile,
            gate_profiles_path=gate_profiles_path,
            fail_on_gate=fail_on_gate,
        )
        if prepare_ai and str(row["arm_id"]) != "corrupted_uncertified":
            _maybe_prepare_ai_artifacts(resolved_run_dir, Console())

    per_arm_outputs = _write_study_arm_outputs(
        arm_dirs=arm_dirs,
        carelink_metrics=carelink_metrics,
        title_prefix="IINTS EUCYS Study" if preset == "eucys" else "IINTS Study",
    )
    comparison_outputs = _write_study_comparisons(target_root, arm_dirs)
    root_summary = analyze_study_directory(target_root, external_reference_metrics=carelink_metrics)
    root_summary_json = target_root / "study_summary.json"
    root_summary_json.write_text(json.dumps(root_summary.to_dict(), indent=2), encoding="utf-8")

    return {
        "target_root": target_root,
        "protocol_outputs": protocol_outputs,
        "pack_outputs": pack_outputs,
        "per_arm_outputs": per_arm_outputs,
        "comparison_outputs": comparison_outputs,
        "root_summary_json": root_summary_json,
    }


@app.command(name="analyze")
def analyze(
    study_dir: Annotated[Path, typer.Argument(help="Directory containing one or more run folders.")],
    output_json: Annotated[Path, typer.Option(help="Write aggregated study summary JSON")] = Path("results/study_summary.json"),
    output_markdown: Annotated[Optional[Path], typer.Option(help="Optional markdown summary path")] = None,
    output_csv: Annotated[Optional[Path], typer.Option(help="Optional evidence-table CSV path")] = None,
    output_evidence_markdown: Annotated[Optional[Path], typer.Option(help="Optional evidence-table markdown path")] = None,
    carelink_metrics: Annotated[
        Optional[Path],
        typer.Option(help="Optional CareLink metrics JSON or workbench directory for external plausibility comparison"),
    ] = None,
) -> None:
    """Aggregate multiple run folders into one study summary for posters, demos, and review."""
    console = Console()
    if not study_dir.exists():
        console.print(f"[bold red]Study directory not found: {study_dir}[/bold red]")
        raise typer.Exit(code=1)

    try:
        summary = analyze_study_directory(study_dir, external_reference_metrics=carelink_metrics)
    except Exception as exc:
        console.print(f"[bold red]Study analysis failed: {exc}[/bold red]")
        raise typer.Exit(code=1)

    payload = summary.to_dict()
    aggregate = payload["aggregate"]
    aggregate_stats = payload["aggregate_stats"]
    certification = payload["certification_comparison"]
    failure_analysis = payload["failure_analysis"]

    table = Table(title="IINTS Study Summary")
    table.add_column("Field", style="cyan")
    table.add_column("Value")
    table.add_row("Run count", str(payload["run_count"]))
    table.add_row("Mean TIR 70-180", f"{aggregate['mean_tir_70_180']:.2f}%" if aggregate["mean_tir_70_180"] is not None else "n/a")
    table.add_row("TIR 70-180 std", f"{aggregate_stats['tir_70_180']['std']:.2f}" if aggregate_stats["tir_70_180"]["std"] is not None else "n/a")
    table.add_row(
        "TIR 70-180 95% CI",
        (
            f"[{aggregate_stats['tir_70_180']['ci95_low']:.2f}, {aggregate_stats['tir_70_180']['ci95_high']:.2f}]"
            if aggregate_stats["tir_70_180"]["ci95_low"] is not None and aggregate_stats["tir_70_180"]["ci95_high"] is not None
            else "n/a"
        ),
    )
    table.add_row(
        "Mean supervisor interventions",
        f"{aggregate['mean_supervisor_interventions']:.2f}" if aggregate["mean_supervisor_interventions"] is not None else "n/a",
    )
    table.add_row("Mean glucose", f"{aggregate['mean_glucose']:.2f} mg/dL" if aggregate["mean_glucose"] is not None else "n/a")
    table.add_row("Mean CV", f"{aggregate['mean_cv']:.2f}%" if aggregate["mean_cv"] is not None else "n/a")
    table.add_row("Certified runs", str(certification["certified_runs"]))
    table.add_row("Uncertified runs", str(certification["uncertified_runs"]))
    table.add_row("Severe hypo runs", str(failure_analysis["severe_hypo_runs"]))
    table.add_row("Terminated early runs", str(failure_analysis["terminated_early_runs"]))
    console.print(table)

    runs_table = Table(title="Runs")
    runs_table.add_column("Scenario", style="green")
    runs_table.add_column("Condition")
    runs_table.add_column("Algorithm")
    runs_table.add_column("TIR 70-180", justify="right")
    runs_table.add_column("TIR <70", justify="right")
    runs_table.add_column("Interventions", justify="right")
    runs_table.add_column("Grade", justify="center")
    for run in payload["runs"]:
        metrics = run["metrics"]
        runs_table.add_row(
            str(run["scenario_name"]),
            str(run.get("condition_group") or "-"),
            str(run["algorithm"]),
            f"{metrics['tir_70_180']:.2f}",
            f"{metrics['tir_below_70']:.2f}",
            f"{metrics['supervisor_interventions']:.0f}",
            str(run["certification_grade"] or "-"),
        )
    console.print(runs_table)

    if isinstance(payload.get("external_validation"), dict):
        external = payload["external_validation"]
        external_table = Table(title="External Validation")
        external_table.add_column("Field", style="cyan")
        external_table.add_column("Value")
        external_table.add_row("Reference path", str(external.get("reference_path")))
        external_table.add_row("Mean glucose delta", str(external.get("delta_mean_glucose_mgdl")))
        external_table.add_row("CV delta", str(external.get("delta_cv_pct")))
        external_table.add_row("TIR delta", str(external.get("delta_tir_70_180_pct")))
        external_table.add_row("Plausibility verdict", str(external.get("plausibility_verdict")))
        console.print(external_table)

    output_json.parent.mkdir(parents=True, exist_ok=True)
    output_json.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    console.print(f"[green]Study summary JSON written:[/green] {output_json}")

    if output_markdown is not None:
        output_markdown.parent.mkdir(parents=True, exist_ok=True)
        output_markdown.write_text(_study_summary_markdown(payload), encoding="utf-8")
        console.print(f"[green]Study summary markdown written:[/green] {output_markdown}")

    if output_csv is not None:
        output_csv.parent.mkdir(parents=True, exist_ok=True)
        _write_evidence_table_csv(payload, output_csv)
        console.print(f"[green]Evidence table CSV written:[/green] {output_csv}")

    if output_evidence_markdown is not None:
        output_evidence_markdown.parent.mkdir(parents=True, exist_ok=True)
        _write_evidence_table_markdown(payload, output_evidence_markdown)
        console.print(f"[green]Evidence table markdown written:[/green] {output_evidence_markdown}")


@app.command(name="compare-study")
def compare_study(
    left: Annotated[Path, typer.Argument(help="Left study directory or study summary JSON")],
    right: Annotated[Path, typer.Argument(help="Right study directory or study summary JSON")],
    output_json: Annotated[Path, typer.Option(help="Write comparison JSON")] = Path("results/study_comparison.json"),
    output_markdown: Annotated[Optional[Path], typer.Option(help="Optional markdown comparison path")] = None,
    left_label: Annotated[Optional[str], typer.Option(help="Optional display label for the left study")] = None,
    right_label: Annotated[Optional[str], typer.Option(help="Optional display label for the right study")] = None,
) -> None:
    """Compare two studies to support baseline-vs-new or certified-vs-uncertified claims."""
    console = Console()
    try:
        comparison = compare_studies(left, right, left_label=left_label, right_label=right_label)
    except Exception as exc:
        console.print(f"[bold red]Study comparison failed: {exc}[/bold red]")
        raise typer.Exit(code=1)

    payload = comparison.to_dict()
    table = Table(title="IINTS Study Comparison")
    table.add_column("Metric", style="cyan")
    table.add_column("Delta (left - right)")
    for metric, value in payload["delta"].items():
        table.add_row(metric, "n/a" if value is None else f"{value}")
    console.print(table)

    effects = Table(title="Effect Estimates")
    effects.add_column("Metric", style="green")
    effects.add_column("Difference in means")
    effects.add_column("95% CI")
    effects.add_column("Cohen's d")
    for metric, estimate in payload.get("effect_estimates", {}).items():
        ci_low = estimate.get("ci95_low")
        ci_high = estimate.get("ci95_high")
        ci_text = "n/a" if ci_low is None or ci_high is None else f"[{ci_low:.3f}, {ci_high:.3f}]"
        diff = estimate.get("difference_in_means")
        effects.add_row(
            metric,
            "n/a" if diff is None else f"{diff:.3f}",
            ci_text,
            "n/a" if estimate.get("cohens_d") is None else f"{estimate['cohens_d']:.3f}",
        )
    console.print(effects)

    output_json.parent.mkdir(parents=True, exist_ok=True)
    output_json.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    console.print(f"[green]Study comparison JSON written:[/green] {output_json}")

    if output_markdown is not None:
        output_markdown.parent.mkdir(parents=True, exist_ok=True)
        output_markdown.write_text(_study_comparison_markdown(payload), encoding="utf-8")
        console.print(f"[green]Study comparison markdown written:[/green] {output_markdown}")


@app.command(name="poster-study")
def poster_study(
    study_input: Annotated[Path, typer.Argument(help="Study directory or study summary JSON")],
    output_path: Annotated[Path, typer.Option(help="Output PNG path")] = Path("results/study_poster.png"),
    title: Annotated[str, typer.Option(help="Poster title")] = "IINTS Study Results",
    subtitle: Annotated[str, typer.Option(help="Poster subtitle")] = "Simulation evidence across runs, safety behavior, and certification quality.",
) -> None:
    """Generate a poster-style visual summary from study results."""
    console = Console()
    try:
        outputs = generate_study_poster(study_input, output_path=output_path, title=title, subtitle=subtitle)
    except Exception as exc:
        console.print(f"[bold red]Study poster generation failed: {exc}[/bold red]")
        raise typer.Exit(code=1)
    console.print(f"[green]Study poster written:[/green] {outputs['poster_png']}")
    console.print(f"[green]Poster summary JSON written:[/green] {outputs['poster_summary_json']}")


@app.command(name="demo-expo")
def demo_expo(
    output_dir: Annotated[Path, typer.Option(help="Directory for the expo demo bundle")] = Path("results/expo_demo"),
    patient_config: Annotated[str, typer.Option(help="Patient profile name or path-like identifier")] = "default_patient",
    duration_minutes: Annotated[int, typer.Option(help="Scenario duration in minutes")] = 360,
    seed: Annotated[int, typer.Option(help="Random seed for reproducible expo runs")] = 42,
) -> None:
    """Build the public expo bundle: three runs, study summary, study poster, and evidence tables."""
    console = Console()
    try:
        booth_outputs = build_booth_demo(
            output_dir=output_dir,
            patient_config=patient_config,
            duration_minutes=duration_minutes,
            seed=seed,
        )
        summary = analyze_study_directory(output_dir)
        payload = summary.to_dict()
        study_summary_json = output_dir / "study_summary.json"
        study_summary_md = output_dir / "study_summary.md"
        evidence_csv = output_dir / "evidence_table.csv"
        evidence_md = output_dir / "evidence_table.md"
        protocol_outputs = write_study_protocol_bundle(
            output_dir / "protocol",
            title="IINTS Expo Scientific Protocol",
            seeds=[seed, seed + 1, seed + 2],
        )
        study_summary_json.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        study_summary_md.write_text(_study_summary_markdown(payload), encoding="utf-8")
        _write_evidence_table_csv(payload, evidence_csv)
        _write_evidence_table_markdown(payload, evidence_md)
        poster_outputs = generate_study_poster(
            summary,
            output_path=output_dir / "study_poster.png",
            title="IINTS Expo Study Results",
            subtitle="One platform: simulate, certify, understand.",
            summary_output_path=output_dir / "study_poster.json",
        )
    except Exception as exc:
        console.print(f"[bold red]Expo demo build failed: {exc}[/bold red]")
        raise typer.Exit(code=1)

    table = Table(title="IINTS Expo Demo Bundle")
    table.add_column("Artifact", style="cyan")
    table.add_column("Path", overflow="fold")
    table.add_row("Three-scenario poster", str(booth_outputs["poster_png"]))
    table.add_row("Study summary JSON", str(study_summary_json))
    table.add_row("Study summary markdown", str(study_summary_md))
    table.add_row("Evidence CSV", str(evidence_csv))
    table.add_row("Evidence markdown", str(evidence_md))
    table.add_row("Study poster", str(poster_outputs["poster_png"]))
    table.add_row("Study protocol", str(protocol_outputs["protocol_markdown"]))
    console.print(table)


@app.command(name="run-study")
def run_study(
    ctx: typer.Context,
    algo: Annotated[Optional[Path], typer.Option(help="Path to the algorithm Python file")] = None,
    experiment: Annotated[Optional[Path], typer.Option(help="Optional study experiment YAML file")] = None,
    output_dir: Annotated[Path, typer.Option(help="Root directory for the study bundle")] = Path("results/study_bundle"),
    preset: Annotated[str, typer.Option(help="Study preset: default or eucys")] = "default",
    profile_set: Annotated[str, typer.Option(help="Patient profile set to evaluate")] = DEFAULT_PROFILE_SET,
    scenarios: Annotated[str, typer.Option(help="Optional comma-separated scenario slugs to run")] = "",
    seeds: Annotated[str, typer.Option(help="Comma-separated seed list")] = "1,2,3,4,5",
    duration: Annotated[Optional[int], typer.Option(help="Override scenario duration in minutes")] = None,
    time_step: Annotated[int, typer.Option(help="Simulation time step in minutes")] = 5,
    carelink_metrics: Annotated[
        Optional[Path],
        typer.Option(help="Optional CareLink metrics JSON or workbench directory for plausibility comparison"),
    ] = None,
    prepare_ai: Annotated[bool, typer.Option(help="Generate AI-ready artifacts for non-corrupted study arms")] = True,
    reference_csv: Annotated[
        Optional[Path],
        typer.Option(help="Optional source CSV to corrupt and archive alongside the study protocol"),
    ] = None,
    include_default_baselines: Annotated[
        bool,
        typer.Option("--include-default-baselines/--no-include-default-baselines", help="Include the default baseline registry in the study matrix"),
    ] = True,
    extra_algorithms: Annotated[str, typer.Option(help="Comma-separated additional comparison algorithm labels")] = "",
    external_reference_label: Annotated[str, typer.Option(help="Label for the plausibility reference lane")] = "CareLink personal workbench metrics",
    gate_profile: Annotated[Optional[str], typer.Option(help="Optional calibration gate profile id")] = None,
    gate_profiles_path: Annotated[Optional[Path], typer.Option(help="Optional calibration gate profiles YAML path")] = None,
    fail_on_gate: Annotated[bool, typer.Option(help="Exit with code 1 when any run fails the calibration gate")] = False,
) -> None:
    """Run the generic benchmark study engine with protocol, subgroup summaries, and posters."""
    console = Console()
    experiment_config = load_study_experiment_config(experiment) if experiment is not None else None

    algo_path = algo if _option_was_set(ctx, "algo") else (experiment_config.candidate_algorithm if experiment_config is not None else algo)
    output_dir_value = output_dir if _option_was_set(ctx, "output_dir") else (experiment_config.output_dir if experiment_config is not None and experiment_config.output_dir is not None else output_dir)
    preset_value = preset if _option_was_set(ctx, "preset") else (experiment_config.preset if experiment_config is not None else preset)
    profile_set_value = profile_set if _option_was_set(ctx, "profile_set") else (experiment_config.profile_set if experiment_config is not None else profile_set)
    scenario_values = (
        [item.strip() for item in scenarios.split(",") if item.strip()]
        if _option_was_set(ctx, "scenarios")
        else (experiment_config.scenarios if experiment_config is not None else [])
    )
    parsed_seeds = (
        [int(item.strip()) for item in seeds.split(",") if item.strip()]
        if _option_was_set(ctx, "seeds")
        else (experiment_config.seeds if experiment_config is not None else [int(item.strip()) for item in seeds.split(",") if item.strip()])
    )
    duration_value = duration if _option_was_set(ctx, "duration") else (experiment_config.duration_minutes if experiment_config is not None else duration)
    time_step_value = time_step if _option_was_set(ctx, "time_step") else (experiment_config.time_step if experiment_config is not None else time_step)
    carelink_metrics_value = carelink_metrics if _option_was_set(ctx, "carelink_metrics") else (experiment_config.carelink_metrics if experiment_config is not None else carelink_metrics)
    prepare_ai_value = prepare_ai if _option_was_set(ctx, "prepare_ai") else (experiment_config.prepare_ai if experiment_config is not None else prepare_ai)
    reference_csv_value = reference_csv if _option_was_set(ctx, "reference_csv") else (experiment_config.reference_csv if experiment_config is not None else reference_csv)
    include_default_baselines_value = (
        include_default_baselines
        if _option_was_set(ctx, "include_default_baselines")
        else (experiment_config.include_default_baselines if experiment_config is not None else include_default_baselines)
    )
    extra_algorithm_values = (
        [item.strip() for item in extra_algorithms.split(",") if item.strip()]
        if _option_was_set(ctx, "extra_algorithms")
        else (experiment_config.extra_algorithms if experiment_config is not None else [])
    )
    external_reference_label_value = (
        external_reference_label
        if _option_was_set(ctx, "external_reference_label")
        else (experiment_config.external_reference_label if experiment_config is not None else external_reference_label)
    )
    gate_profile_value = gate_profile if _option_was_set(ctx, "gate_profile") else (experiment_config.gate_profile if experiment_config is not None else gate_profile)
    gate_profiles_path_value = (
        gate_profiles_path
        if _option_was_set(ctx, "gate_profiles_path")
        else (experiment_config.gate_profiles_path if experiment_config is not None else gate_profiles_path)
    )
    fail_on_gate_value = fail_on_gate if _option_was_set(ctx, "fail_on_gate") else (experiment_config.fail_on_gate if experiment_config is not None else fail_on_gate)

    if algo_path is None:
        console.print("[bold red]Please provide --algo or an --experiment file with algorithm.candidate.[/bold red]")
        raise typer.Exit(code=1)
    if not parsed_seeds:
        console.print("[bold red]Please provide at least one seed.[/bold red]")
        raise typer.Exit(code=1)

    try:
        outputs = _run_study_bundle(
            algo=algo_path,
            output_dir=output_dir_value,
            preset=preset_value.strip().lower(),
            scenarios=scenario_values or None,
            seeds=parsed_seeds,
            duration=duration_value,
            time_step=time_step_value,
            carelink_metrics=carelink_metrics_value,
            prepare_ai=prepare_ai_value,
            reference_csv=reference_csv_value,
            profile_set=profile_set_value,
            include_default_baselines=include_default_baselines_value,
            extra_algorithms=extra_algorithm_values or None,
            external_reference_label=external_reference_label_value,
            gate_profile=gate_profile_value,
            gate_profiles_path=gate_profiles_path_value,
            fail_on_gate=fail_on_gate_value,
        )
        eucys_outputs = None
        if preset_value.strip().lower() == "eucys":
            eucys_outputs = _write_eucys_result_package(
                root_dir=outputs["target_root"],
                protocol_outputs=outputs["protocol_outputs"],
                per_arm_outputs=outputs["per_arm_outputs"],
                comparison_outputs=outputs["comparison_outputs"],
            )
    except Exception as exc:
        console.print(f"[bold red]Study run failed: {exc}[/bold red]")
        raise typer.Exit(code=1)

    table = Table(title="IINTS Study Bundle")
    table.add_column("Artifact", style="cyan")
    table.add_column("Path", overflow="fold")
    table.add_row("Scenario pack", outputs["pack_outputs"].get("output_dir", "n/a"))
    table.add_row("Protocol markdown", outputs["protocol_outputs"]["protocol_markdown"])
    table.add_row("Protocol matrix", outputs["protocol_outputs"]["study_matrix_csv"])
    table.add_row("Algorithm registry", outputs["protocol_outputs"]["algorithms_json"])
    table.add_row("Experiment YAML", outputs["protocol_outputs"]["study_experiment_yaml"])
    table.add_row("Bundle summary", str(outputs["root_summary_json"]))
    clean_summary = outputs["per_arm_outputs"].get("clean_certified", {}).get("summary_json")
    corrupted_summary = outputs["per_arm_outputs"].get("corrupted_uncertified", {}).get("summary_json")
    supervisor_summary = outputs["per_arm_outputs"].get("supervisor_off_ablation", {}).get("summary_json")
    if clean_summary is not None:
        table.add_row("Clean study summary", str(clean_summary))
    if corrupted_summary is not None:
        table.add_row("Corrupted study summary", str(corrupted_summary))
    if supervisor_summary is not None:
        table.add_row("Supervisor-off summary", str(supervisor_summary))
    if outputs["comparison_outputs"]:
        table.add_row("First comparison", str(outputs["comparison_outputs"][0]))
    if eucys_outputs is not None:
        table.add_row("EUCYS summary", str(eucys_outputs["summary_markdown"]))
        table.add_row("EUCYS results table", str(eucys_outputs["results_table_csv"]))
        table.add_row("EUCYS figure manifest", str(eucys_outputs["figure_manifest_json"]))
        table.add_row("EUCYS filled abstract", str(eucys_outputs["abstract_filled_markdown"]))
        table.add_row("EUCYS main figure", str(eucys_outputs["main_figure_png"]))
        table.add_row("EUCYS limitations", str(eucys_outputs["limitations_markdown"]))
    console.print(table)


@app.command(name="run-eucys-study")
def run_eucys_study(
    algo: Annotated[Path, typer.Option(help="Path to the algorithm Python file")],
    patient_config_name: Annotated[str, typer.Option(help="Legacy option kept for compatibility; the EUCYS preset now uses the fixed clinic_safe_core profile set")] = "default_patient",
    patient_config_path: Annotated[Optional[Path], typer.Option(help="Legacy option kept for compatibility; the EUCYS preset now uses the fixed clinic_safe_core profile set")] = None,
    output_dir: Annotated[Path, typer.Option(help="Root directory for the EUCYS study bundle")] = Path("results/eucys_study"),
    seeds: Annotated[str, typer.Option(help="Comma-separated seed list")] = "1,2,3,4,5,6,7,8,9,10",
    duration: Annotated[Optional[int], typer.Option(help="Override scenario duration in minutes")] = None,
    time_step: Annotated[int, typer.Option(help="Simulation time step in minutes")] = 5,
    carelink_metrics: Annotated[
        Optional[Path],
        typer.Option(help="Optional CareLink metrics JSON or workbench directory for plausibility comparison"),
    ] = None,
    prepare_ai: Annotated[bool, typer.Option(help="Generate AI-ready artifacts for certified study arms")] = True,
    reference_csv: Annotated[
        Optional[Path],
        typer.Option(help="Optional source CSV to corrupt and archive alongside the study protocol"),
    ] = None,
    include_default_baselines: Annotated[
        bool,
        typer.Option("--include-default-baselines/--no-include-default-baselines", help="Include the default baseline registry in the EUCYS matrix"),
    ] = True,
    gate_profile: Annotated[Optional[str], typer.Option(help="Optional calibration gate profile id")] = None,
    gate_profiles_path: Annotated[Optional[Path], typer.Option(help="Optional calibration gate profiles YAML path")] = None,
    fail_on_gate: Annotated[bool, typer.Option(help="Exit with code 1 when any run fails the calibration gate")] = False,
) -> None:
    """Run the fixed EUCYS study matrix and generate summaries, comparisons, and EUCYS artifacts."""
    console = Console()
    parsed_seeds = [int(item.strip()) for item in seeds.split(",") if item.strip()]
    if not parsed_seeds:
        console.print("[bold red]Please provide at least one seed.[/bold red]")
        raise typer.Exit(code=1)
    if patient_config_path is not None or patient_config_name != "default_patient":
        console.print(
            "[yellow]Note:[/yellow] `run-eucys-study` now uses the fixed `clinic_safe_core` profile set. "
            "Legacy patient-config overrides are ignored so the study matrix stays reproducible."
        )

    try:
        outputs = _run_study_bundle(
            algo=algo,
            output_dir=output_dir,
            preset="eucys",
            scenarios=None,
            seeds=parsed_seeds,
            duration=duration,
            time_step=time_step,
            carelink_metrics=carelink_metrics,
            prepare_ai=prepare_ai,
            reference_csv=reference_csv,
            profile_set=DEFAULT_PROFILE_SET,
            include_default_baselines=include_default_baselines,
            extra_algorithms=None,
            external_reference_label="CareLink personal workbench metrics",
            gate_profile=gate_profile,
            gate_profiles_path=gate_profiles_path,
            fail_on_gate=fail_on_gate,
        )
        eucys_outputs = _write_eucys_result_package(
            root_dir=outputs["target_root"],
            protocol_outputs=outputs["protocol_outputs"],
            per_arm_outputs=outputs["per_arm_outputs"],
            comparison_outputs=outputs["comparison_outputs"],
        )
    except Exception as exc:
        console.print(f"[bold red]EUCYS study run failed: {exc}[/bold red]")
        raise typer.Exit(code=1)

    table = Table(title="IINTS EUCYS Study Bundle")
    table.add_column("Artifact", style="cyan")
    table.add_column("Path", overflow="fold")
    table.add_row("Scenario pack", outputs["pack_outputs"].get("output_dir", "n/a"))
    table.add_row("Protocol markdown", outputs["protocol_outputs"]["protocol_markdown"])
    table.add_row("Protocol matrix", outputs["protocol_outputs"]["study_matrix_csv"])
    table.add_row("Algorithm registry", outputs["protocol_outputs"]["algorithms_json"])
    table.add_row("Clean study summary", str(outputs["per_arm_outputs"]["clean_certified"]["summary_json"]))
    table.add_row("Corrupted study summary", str(outputs["per_arm_outputs"]["corrupted_uncertified"]["summary_json"]))
    table.add_row("Supervisor-off summary", str(outputs["per_arm_outputs"]["supervisor_off_ablation"]["summary_json"]))
    if outputs["comparison_outputs"]:
        table.add_row("Clean vs corrupted", str(outputs["comparison_outputs"][0]))
        if len(outputs["comparison_outputs"]) >= 3:
            table.add_row("Clean vs supervisor-off", str(outputs["comparison_outputs"][2]))
    table.add_row("EUCYS summary", str(eucys_outputs["summary_markdown"]))
    table.add_row("EUCYS results table", str(eucys_outputs["results_table_csv"]))
    table.add_row("EUCYS figure manifest", str(eucys_outputs["figure_manifest_json"]))
    table.add_row("EUCYS filled abstract", str(eucys_outputs["abstract_filled_markdown"]))
    table.add_row("EUCYS main figure", str(eucys_outputs["main_figure_png"]))
    table.add_row("EUCYS limitations", str(eucys_outputs["limitations_markdown"]))
    console.print(table)


@app.command(name="eucys-results")
def eucys_results(
    study_dir: Annotated[Path, typer.Argument(help="Root directory of a completed EUCYS or run-study bundle.")],
    output_dir: Annotated[
        Optional[Path],
        typer.Option(help="Optional output directory for the packaged EUCYS results bundle. Defaults to <study_dir>/EUCYS_RESULTS."),
    ] = None,
) -> None:
    """Build a competition-ready EUCYS results folder from an existing study bundle."""
    console = Console()
    try:
        outputs = generate_eucys_results_bundle(study_dir, output_dir=output_dir)
    except Exception as exc:
        console.print(f"[bold red]EUCYS results generation failed: {exc}[/bold red]")
        raise typer.Exit(code=1)

    table = Table(title="IINTS EUCYS Results Bundle")
    table.add_column("Artifact", style="cyan")
    table.add_column("Path", overflow="fold")
    table.add_row("Bundle root", outputs["bundle_root"])
    table.add_row("Summary markdown", outputs["summary_markdown"])
    table.add_row("Results table", outputs["results_table_csv"])
    table.add_row("Figure manifest", outputs["figure_manifest_json"])
    table.add_row("Reproducibility bundle", outputs["reproducibility_bundle_json"])
    table.add_row("Abstract draft", outputs["abstract_markdown"])
    table.add_row("Abstract filled", outputs["abstract_filled_markdown"])
    table.add_row("Poster outline", outputs["poster_outline_markdown"])
    table.add_row("Jury Q&A", outputs["jury_qa_markdown"])
    table.add_row("Limitations & ethics", outputs["limitations_markdown"])
    table.add_row("Main figure", outputs["main_figure_png"])
    console.print(table)


@app.command(name="study-protocol")
def study_protocol(
    ctx: typer.Context,
    output_dir: Annotated[Path, typer.Option(help="Directory where the protocol bundle should be written")] = Path("results/study_protocol"),
    experiment: Annotated[Optional[Path], typer.Option(help="Optional study experiment YAML file to seed the protocol bundle")] = None,
    preset: Annotated[str, typer.Option(help="Protocol preset: default or eucys")] = "default",
    title: Annotated[str, typer.Option(help="Protocol title")] = "IINTS Scientific Validation Protocol",
    primary_hypothesis: Annotated[
        Optional[str],
        typer.Option(help="Optional override for the primary H1 hypothesis"),
    ] = None,
    seeds: Annotated[str, typer.Option(help="Comma-separated seed list")] = "1,2,3,4,5",
    algorithms: Annotated[str, typer.Option(help="Comma-separated candidate+comparison algorithms (legacy; first entry becomes the candidate)")] = "your_algorithm",
    scenarios: Annotated[str, typer.Option(help="Comma-separated scenario names")] = "baseline_day,meal_challenge,exercise_challenge,supervisor_override",
    profile_set: Annotated[str, typer.Option(help="Patient profile set to encode in the study protocol")] = DEFAULT_PROFILE_SET,
    include_default_baselines: Annotated[
        bool,
        typer.Option("--include-default-baselines/--no-include-default-baselines", help="Include the default baseline registry in the protocol bundle"),
    ] = True,
    extra_algorithms: Annotated[str, typer.Option(help="Comma-separated additional algorithm labels for the protocol bundle")] = "",
    corruption_modes: Annotated[
        str,
        typer.Option(help="Comma-separated corruption modes for the protocol plan"),
    ] = ",".join(AVAILABLE_STUDY_CORRUPTIONS),
    external_reference_label: Annotated[str, typer.Option(help="Label for the real-world plausibility reference")] = "CareLink personal workbench metrics",
) -> None:
    """Write a reproducible study protocol bundle for scientific benchmarking."""
    console = Console()
    experiment_config = load_study_experiment_config(experiment) if experiment is not None else None
    output_dir_value = output_dir if _option_was_set(ctx, "output_dir") else output_dir
    preset_value = preset if _option_was_set(ctx, "preset") else (experiment_config.preset if experiment_config is not None else preset)
    title_value = title if _option_was_set(ctx, "title") else (experiment_config.title if experiment_config is not None else title)
    parsed_seed_values = (
        [int(item.strip()) for item in seeds.split(",") if item.strip()]
        if _option_was_set(ctx, "seeds")
        else (experiment_config.seeds if experiment_config is not None else [int(item.strip()) for item in seeds.split(",") if item.strip()])
    )
    scenario_values = (
        [item.strip() for item in scenarios.split(",") if item.strip()]
        if _option_was_set(ctx, "scenarios")
        else (experiment_config.scenarios if experiment_config is not None else [item.strip() for item in scenarios.split(",") if item.strip()])
    )
    profile_set_value = profile_set if _option_was_set(ctx, "profile_set") else (experiment_config.profile_set if experiment_config is not None else profile_set)
    include_default_baselines_value = (
        include_default_baselines
        if _option_was_set(ctx, "include_default_baselines")
        else (experiment_config.include_default_baselines if experiment_config is not None else include_default_baselines)
    )
    extra_algorithm_values = (
        [item.strip() for item in extra_algorithms.split(",") if item.strip()]
        if _option_was_set(ctx, "extra_algorithms")
        else (experiment_config.extra_algorithms if experiment_config is not None else [item.strip() for item in extra_algorithms.split(",") if item.strip()])
    )
    external_reference_label_value = (
        external_reference_label
        if _option_was_set(ctx, "external_reference_label")
        else (experiment_config.external_reference_label if experiment_config is not None else external_reference_label)
    )
    algorithm_values = [item.strip() for item in algorithms.split(",") if item.strip()]
    if experiment_config is not None and not _option_was_set(ctx, "algorithms"):
        algorithm_values = [str(experiment_config.candidate_algorithm)] + list(experiment_config.extra_algorithms)
    try:
        outputs = write_study_protocol_bundle(
            output_dir_value,
            preset=preset_value,
            title=title_value,
            primary_hypothesis=primary_hypothesis,
            seeds=parsed_seed_values,
            algorithms=algorithm_values,
            scenarios=scenario_values,
            corruption_modes=[item.strip() for item in corruption_modes.split(",") if item.strip()],
            external_reference_label=external_reference_label_value,
            profile_set=profile_set_value,
            include_default_baselines=include_default_baselines_value,
            extra_algorithms=extra_algorithm_values,
        )
    except Exception as exc:
        console.print(f"[bold red]Could not write study protocol bundle: {exc}[/bold red]")
        raise typer.Exit(code=1)

    table = Table(title="IINTS Study Protocol Bundle")
    table.add_column("Artifact", style="cyan")
    table.add_column("Path", overflow="fold")
    table.add_row("Protocol markdown", outputs["protocol_markdown"])
    table.add_row("Study design JSON", outputs["study_design_json"])
    table.add_row("Study matrix CSV", outputs["study_matrix_csv"])
    table.add_row("Algorithm registry", outputs["algorithms_json"])
    table.add_row("Experiment YAML", outputs["study_experiment_yaml"])
    console.print(table)


@app.command(name="contract-verify")
def contract_verify(
    contract_path: Annotated[Optional[Path], typer.Option(help="Optional YAML safety-contract file")] = None,
    glucose_min: Annotated[float, typer.Option(help="Minimum glucose to test (mg/dL)")] = 50.0,
    glucose_max: Annotated[float, typer.Option(help="Maximum glucose to test (mg/dL)")] = 160.0,
    glucose_step: Annotated[float, typer.Option(help="Glucose grid step (mg/dL)")] = 5.0,
    trend_min: Annotated[float, typer.Option(help="Minimum trend to test (mg/dL/min)")] = -5.0,
    trend_max: Annotated[float, typer.Option(help="Maximum trend to test (mg/dL/min)")] = 3.0,
    trend_step: Annotated[float, typer.Option(help="Trend grid step (mg/dL/min)")] = 0.5,
    proposed_doses: Annotated[str, typer.Option(help="Comma-separated proposed insulin doses (U)")] = "0.0,0.5,1.0,2.0,4.0",
    iob_values: Annotated[Optional[str], typer.Option(help="Optional comma-separated current IOB values (U)")] = None,
    output_json: Annotated[Optional[Path], typer.Option(help="Write contract verification report JSON")] = None,
    fail_on_violation: Annotated[bool, typer.Option(help="Exit with code 1 when any contract violation is found")] = True,
):
    """
    Compile and formally verify the deterministic safety contract on a full input grid.
    """
    console = Console()
    try:
        spec = load_contract_spec(contract_path)
    except Exception as exc:
        console.print(f"[bold red]Could not load contract spec: {exc}[/bold red]")
        raise typer.Exit(code=1)

    if glucose_step <= 0 or trend_step <= 0:
        console.print("[bold red]glucose-step and trend-step must be > 0[/bold red]")
        raise typer.Exit(code=1)

    try:
        dose_values = _parse_float_csv(proposed_doses, "proposed-doses")
    except ValueError as exc:
        console.print(f"[bold red]{exc}[/bold red]")
        raise typer.Exit(code=1)
    iob_grid = None
    if iob_values is not None:
        try:
            iob_grid = _parse_float_csv(iob_values, "iob-values")
        except ValueError as exc:
            console.print(f"[bold red]{exc}[/bold red]")
            raise typer.Exit(code=1)

    glucose_values = np.arange(glucose_min, glucose_max + 1e-9, glucose_step).tolist()
    trend_values = np.arange(trend_min, trend_max + 1e-9, trend_step).tolist()
    report = verify_safety_contract(
        spec,
        glucose_values=glucose_values,
        trend_values=trend_values,
        proposed_doses=dose_values,
        iob_values=iob_grid,
    )

    table = Table(title="Safety Contract Verification")
    table.add_column("Field", style="cyan")
    table.add_column("Value")
    table.add_row("Contract enabled", str(spec.contract_enabled))
    table.add_row("Glucose threshold", f"{spec.contract_glucose_threshold:.2f} mg/dL")
    table.add_row("Trend threshold", f"{spec.contract_trend_threshold_mgdl_min:.2f} mg/dL/min")
    table.add_row("Max IOB", f"{spec.contract_max_iob_units:.2f} U")
    table.add_row("Max bolus", f"{spec.contract_max_bolus_units:.2f} U")
    table.add_row("Hypo cutoff", f"{spec.contract_hypo_cutoff_mgdl:.2f} mg/dL")
    table.add_row("Total cases", str(report.total_cases))
    table.add_row("Expected blocked cases", str(report.expected_block_cases))
    table.add_row("Blocked cases", str(report.blocked_cases))
    table.add_row("Violations", str(len(report.violations)))
    table.add_row("Status", "[green]PASS[/green]" if report.passed else "[red]FAIL[/red]")
    console.print(table)

    if report.violations:
        violations_table = Table(title="Contract Violations (first 20)")
        violations_table.add_column("Glucose", justify="right")
        violations_table.add_column("Trend", justify="right")
        violations_table.add_column("Proposed", justify="right")
        violations_table.add_column("Approved", justify="right")
        violations_table.add_column("Reason")
        for violation in report.violations[:20]:
            violations_table.add_row(
                f"{violation.glucose_mgdl:.1f}",
                f"{violation.trend_mgdl_min:.2f}",
                f"{violation.proposed_insulin_units:.2f}",
                f"{violation.approved_insulin_units:.2f}",
                violation.reason,
            )
        console.print(violations_table)

    if output_json is not None:
        output_json.parent.mkdir(parents=True, exist_ok=True)
        output_json.write_text(json.dumps(report.to_dict(), indent=2))
        console.print(f"[green]Contract report written:[/green] {output_json}")

    if fail_on_violation and not report.passed:
        raise typer.Exit(code=1)


@app.command(name="certify-run")
def certify_run(
    algo: Annotated[Path, typer.Option(help="Path to the algorithm Python file")],
    profile: Annotated[str, typer.Option(help="Validation profile id")] = "research_default",
    predictor_path: Annotated[Optional[Path], typer.Option("--predictor", help="Optional predictor checkpoint (.pt) for dual-guard forecasting")] = None,
    patient_config_name: Annotated[str, typer.Option(help="Name of the patient configuration")] = "default_patient",
    patient_config_path: Annotated[Optional[Path], typer.Option(help="Path to a patient config YAML")] = None,
    scenario_path: Annotated[Optional[Path], typer.Option(help="Path to scenario JSON")] = None,
    duration: Annotated[int, typer.Option(help="Simulation duration in minutes")] = 720,
    time_step: Annotated[int, typer.Option(help="Simulation time step in minutes")] = 5,
    output_dir: Annotated[Path, typer.Option(help="Directory to save outputs")] = Path("results/certified_run"),
    seed: Annotated[Optional[int], typer.Option(help="Random seed")] = None,
    export_sources: Annotated[bool, typer.Option(help="Write sources_manifest.json with peer-reviewed references.")] = True,
    source_category: Annotated[Optional[str], typer.Option(help="Optional evidence source category filter (guideline, trial, model, ...).")] = None,
    write_summary: Annotated[bool, typer.Option(help="Write SUMMARY.md with key artifacts and next steps.")] = True,
    fail_on_check: Annotated[bool, typer.Option(help="Exit code 1 when validation profile fails")] = True,
):
    """
    One-command certification pipeline: run-full + profile validation + artifacts.
    """
    console = Console()
    algorithm_instance = _load_algorithm_instance(algo, console)
    predictor = _load_predictor_service_from_path(predictor_path, console)

    patient_config: Union[str, Path]
    if patient_config_path is not None:
        if not patient_config_path.is_file():
            console.print(f"[bold red]Patient config file not found: {patient_config_path}[/bold red]")
            raise typer.Exit(code=1)
        patient_config = patient_config_path
    else:
        patient_config = patient_config_name

    outputs = iints.run_full(
        algorithm=algorithm_instance,
        scenario=str(scenario_path) if scenario_path else None,
        patient_config=patient_config,
        duration_minutes=duration,
        time_step=time_step,
        seed=seed,
        output_dir=output_dir,
        predictor=predictor,
    )

    results_csv = Path(outputs["results_csv"])
    safety_summary_path = Path(outputs["audit"]["summary"]) if "audit" in outputs else None

    try:
        profiles = load_validation_profiles()
    except Exception as exc:
        console.print(f"[bold red]Could not load validation profiles: {exc}[/bold red]")
        raise typer.Exit(code=1)
    selected_profile = profiles.get(profile)
    if selected_profile is None:
        console.print(f"[bold red]Unknown profile '{profile}'.[/bold red]")
        raise typer.Exit(code=1)

    results_df = pd.read_csv(results_csv)
    safety_report = _load_json_dict(safety_summary_path, "safety summary") if safety_summary_path else {}
    report = evaluate_run(
        results_df,
        profile=selected_profile,
        safety_report=safety_report,
        duration_minutes=duration,
    )

    validation_path = Path(outputs["output_dir"]) / "validation_report.json"
    report_payload = report.to_dict()
    validation_path.write_text(json.dumps(report_payload, indent=2))
    console.print(f"[green]Validation report:[/green] {validation_path}")
    console.print(f"[bold]{'PASS' if report.passed else 'FAIL'}[/bold] {report.required_checks_passed}/{report.required_checks_total} required checks passed")

    source_manifest_path: Optional[Path] = None
    if export_sources:
        try:
            source_manifest = _filtered_evidence_sources(category=source_category)
            source_manifest_path = Path(outputs["output_dir"]) / "sources_manifest.json"
            source_manifest_path.write_text(json.dumps(source_manifest, indent=2))
            console.print(f"[green]Source manifest:[/green] {source_manifest_path}")
        except Exception as exc:
            console.print(f"[yellow]Could not export source manifest: {exc}[/yellow]")

    if write_summary:
        summary_path = _write_certification_summary(
            Path(outputs["output_dir"]),
            outputs,
            profile,
            report_payload,
            source_manifest_path,
        )
        console.print(f"[green]Summary:[/green] {summary_path}")

    if fail_on_check and not report.passed:
        raise typer.Exit(code=1)


@app.command(name="study-ready")
def study_ready(
    algo: Annotated[Path, typer.Option(help="Path to the algorithm Python file")],
    scenario_path: Annotated[Optional[Path], typer.Option(help="Path to scenario JSON")] = None,
    output_dir: Annotated[Path, typer.Option(help="Directory to save outputs")] = Path("results/study_ready"),
    duration: Annotated[int, typer.Option(help="Simulation duration in minutes")] = 720,
    time_step: Annotated[int, typer.Option(help="Simulation time step in minutes")] = 5,
    seed: Annotated[Optional[int], typer.Option(help="Random seed")] = None,
    profile: Annotated[str, typer.Option(help="Validation profile id")] = "research_default",
    predictor_path: Annotated[Optional[Path], typer.Option("--predictor", help="Optional predictor checkpoint (.pt)")] = None,
    patient_config_name: Annotated[str, typer.Option(help="Patient configuration name")] = "default_patient",
    patient_config_path: Annotated[Optional[Path], typer.Option(help="Optional patient config YAML path")] = None,
    fail_on_check: Annotated[bool, typer.Option(help="Exit code 1 when validation profile fails")] = True,
):
    """
    Simplified one-command pipeline: run + validate + sources manifest + summary bundle.
    """
    certify_run(
        algo=algo,
        profile=profile,
        predictor_path=predictor_path,
        patient_config_name=patient_config_name,
        patient_config_path=patient_config_path,
        scenario_path=scenario_path,
        duration=duration,
        time_step=time_step,
        output_dir=output_dir,
        seed=seed,
        export_sources=True,
        source_category=None,
        write_summary=True,
        fail_on_check=fail_on_check,
    )


@app.command()
def init(
    project_name: Annotated[str, typer.Option(help="Name of the project directory")] = "my_iints_project",
    template: Annotated[str, typer.Option(help="Project template: research or clinical-trial")] = "research",
):
    """
    Initialize a new IINTS-AF project with a standard folder structure.
    """
    console = Console()
    project_path = Path(project_name)

    if project_path.exists():
        console.print(f"[bold red]Error: Directory '{project_name}' already exists.[/bold red]")
        raise typer.Exit(code=1)

    selected_template = template.strip().lower()
    if selected_template not in {"research", "clinical-trial"}:
        console.print("[bold red]Invalid --template. Use 'research' or 'clinical-trial'.[/bold red]")
        raise typer.Exit(code=1)

    console.print(f"[bold blue]Initializing IINTS-AF Project: {project_name} ({selected_template})[/bold blue]")

    # Base directories
    (project_path / "algorithms").mkdir(parents=True)
    (project_path / "scenarios").mkdir(parents=True)
    (project_path / "data").mkdir(parents=True)
    (project_path / "results").mkdir(parents=True)

    if selected_template == "clinical-trial":
        (project_path / "contracts").mkdir(parents=True)
        (project_path / "audit").mkdir(parents=True)
        (project_path / "notebooks").mkdir(parents=True)
        (project_path / "reports").mkdir(parents=True)
        (project_path / "data" / "demo").mkdir(parents=True)

    # Copy Default Algorithm
    try:
        if sys.version_info >= (3, 9):
            from importlib.resources import files
            algo_content = files("iints.templates").joinpath("default_algorithm.py").read_text()
            scenario_content = files("iints.templates.scenarios").joinpath("example_scenario.json").read_text()
            exercise_content = files("iints.templates.scenarios").joinpath("exercise_stress.json").read_text()
            stacking_content = files("iints.templates.scenarios").joinpath("chaos_insulin_stacking.json").read_text()
            runaway_content = files("iints.templates.scenarios").joinpath("chaos_runaway_ai.json").read_text()
        else:
            from importlib import resources
            algo_content = resources.read_text("iints.templates", "default_algorithm.py")
            scenario_content = resources.read_text("iints.templates.scenarios", "example_scenario.json")
            exercise_content = resources.read_text("iints.templates.scenarios", "exercise_stress.json")
            stacking_content = resources.read_text("iints.templates.scenarios", "chaos_insulin_stacking.json")
            runaway_content = resources.read_text("iints.templates.scenarios", "chaos_runaway_ai.json")
    except Exception as e:
        console.print(f"[bold red]Error reading template files: {e}[/bold red]")
        raise typer.Exit(code=1)

    # Instantiate the default algorithm template
    algo_content = algo_content.replace("{{ALGO_NAME}}", "ExampleAlgorithm")
    algo_content = algo_content.replace("{{AUTHOR_NAME}}", "IINTS User")

    with open(project_path / "algorithms" / "example_algorithm.py", "w") as f:
        f.write(algo_content)

    with open(project_path / "scenarios" / "example_scenario.json", "w") as f:
        f.write(scenario_content)
    with open(project_path / "scenarios" / "exercise_stress.json", "w") as f:
        f.write(exercise_content)
    with open(project_path / "scenarios" / "chaos_insulin_stacking.json", "w") as f:
        f.write(stacking_content)
    with open(project_path / "scenarios" / "chaos_runaway_ai.json", "w") as f:
        f.write(runaway_content)

    if selected_template == "clinical-trial":
        contract_path = project_path / "contracts" / "clinical_mdmp_contract.yaml"
        contract_payload = _build_data_contract_template()
        contract_path.write_text(yaml.safe_dump(contract_payload, sort_keys=False))

        demo_df = pd.DataFrame(
            {
                "timestamp": [
                    "2026-01-01T00:00:00Z",
                    "2026-01-01T00:05:00Z",
                    "2026-01-01T00:10:00Z",
                    "2026-01-01T00:15:00Z",
                    "2026-01-01T00:20:00Z",
                    "2026-01-01T00:25:00Z",
                ],
                "glucose": [118.0, 120.0, 122.0, 124.0, 123.0, 121.0],
                "carbs": [0.0, 0.0, 0.0, 12.0, 0.0, 0.0],
                "insulin": [0.0, 0.0, 0.1, 0.0, 0.0, 0.0],
            }
        )
        demo_path = project_path / "data" / "demo" / "diabetes_cgm.csv"
        demo_df.to_csv(demo_path, index=False)

    # Create README
    if selected_template == "clinical-trial":
        readme_content = f"""# {project_name}

Powered by IINTS-AF SDK (clinical-trial scaffold).

## Structure
- `algorithms/`: Algorithms under evaluation.
- `scenarios/`: Simulation scenarios.
- `contracts/`: MDMP contracts.
- `data/demo/`: Synthetic-safe starter dataset.
- `audit/`: Validation JSON + MDMP dashboards.
- `reports/`: Study outputs for sharing.
- `results/`: Raw simulation outputs.

## Data Certification Quick Path
```bash
iints data certify contracts/clinical_mdmp_contract.yaml data/demo/diabetes_cgm.csv \\
  --output-json audit/certification.json \\
  --min-mdmp-grade research_grade --fail-on-noncompliant

iints data certify-visualizer audit/certification.json \\
  --output-html audit/mdmp_dashboard.html
```

## Run Simulation
```bash
iints run --algo algorithms/example_algorithm.py --scenario-path scenarios/example_scenario.json
```
"""
    else:
        readme_content = f"""# {project_name}

Powered by IINTS-AF SDK.

## Structure
- `algorithms/`: Place your custom python algorithms here.
- `scenarios/`: JSON files defining stress test scenarios.
- `data/`: Custom patient data or configuration.
- `results/`: Simulation outputs.

## Getting Started

1. Run the example algorithm:
   ```bash
   iints run --algo algorithms/example_algorithm.py --scenario-path scenarios/example_scenario.json
   ```

2. Create a new algorithm:
   ```bash
   iints new-algo MyNewAlgo --output-dir algorithms/
   ```
"""
    with open(project_path / "README.md", "w") as f:
        f.write(readme_content)

    console.print(f"[green]Project initialized successfully in '{project_name}'[/green]")
    if selected_template == "clinical-trial":
        console.print(
            "To get started:\n"
            f"  cd {project_name}\n"
            "  iints data certify contracts/clinical_mdmp_contract.yaml data/demo/diabetes_cgm.csv "
            "--output-json audit/certification.json\n"
            "  iints data certify-visualizer audit/certification.json --output-html audit/mdmp_dashboard.html"
        )
    else:
        console.print(f"To get started:\n  cd {project_name}\n  iints run --algo algorithms/example_algorithm.py")

@app.command()
def quickstart(
    project_name: Annotated[str, typer.Option(help="Name of the project directory")] = "iints_quickstart",
):
    """
    Create a ready-to-run project using clinic-safe presets and a demo algorithm.
    """
    console = Console()
    project_path = Path(project_name)

    if project_path.exists():
        console.print(f"[bold red]Error: Directory '{project_name}' already exists.[/bold red]")
        raise typer.Exit(code=1)

    console.print(f"[bold blue]Creating IINTS-AF Quickstart Project: {project_name}[/bold blue]")

    (project_path / "algorithms").mkdir(parents=True)
    (project_path / "scenarios").mkdir(parents=True)
    (project_path / "results").mkdir(parents=True)
    (project_path / "contracts").mkdir(parents=True)
    (project_path / "audit").mkdir(parents=True)
    (project_path / "data" / "demo").mkdir(parents=True)

    try:
        if sys.version_info >= (3, 9):
            from importlib.resources import files
            algo_content = files("iints.templates").joinpath("default_algorithm.py").read_text()
        else:
            from importlib import resources
            algo_content = resources.read_text("iints.templates", "default_algorithm.py")
    except Exception as e:
        console.print(f"[bold red]Error reading template files: {e}[/bold red]")
        raise typer.Exit(code=1)

    algo_content = algo_content.replace("{{ALGO_NAME}}", "QuickstartAlgorithm")
    algo_content = algo_content.replace("{{AUTHOR_NAME}}", "IINTS User")
    algo_path = project_path / "algorithms" / "example_algorithm.py"
    algo_path.write_text(algo_content)

    try:
        preset = _get_preset("baseline_t1d")
        scenario_path = project_path / "scenarios" / "clinic_safe_baseline.json"
        scenario_path.write_text(json.dumps(preset.get("scenario", {}), indent=2))
    except Exception as e:
        console.print(f"[yellow]Preset scenario not available: {e}[/yellow]")

    try:
        if sys.version_info >= (3, 9):
            from importlib.resources import files
            exercise_content = files("iints.templates.scenarios").joinpath("exercise_stress.json").read_text()
        else:
            from importlib import resources
            exercise_content = resources.read_text("iints.templates.scenarios", "exercise_stress.json")
        (project_path / "scenarios" / "exercise_stress.json").write_text(exercise_content)
    except Exception as e:
        console.print(f"[yellow]Exercise stress scenario not available: {e}[/yellow]")

    contract_path = project_path / "contracts" / "clinical_mdmp_contract.yaml"
    contract_path.write_text(yaml.safe_dump(_build_data_contract_template(), sort_keys=False))

    demo_df = pd.DataFrame(
        {
            "timestamp": [
                "2026-01-01T00:00:00Z",
                "2026-01-01T00:05:00Z",
                "2026-01-01T00:10:00Z",
                "2026-01-01T00:15:00Z",
                "2026-01-01T00:20:00Z",
                "2026-01-01T00:25:00Z",
            ],
            "glucose": [118.0, 120.0, 122.0, 124.0, 123.0, 121.0],
            "carbs": [0.0, 0.0, 0.0, 12.0, 0.0, 0.0],
            "insulin": [0.0, 0.0, 0.1, 0.0, 0.0, 0.0],
        }
    )
    (project_path / "data" / "demo" / "diabetes_cgm.csv").write_text(demo_df.to_csv(index=False))

    readme_content = f"""# {project_name}

Clinic-safe quickstart project powered by IINTS-AF.

## Quickstart

Run a clinic-safe preset:

```bash
iints presets run --name baseline_t1d --algo algorithms/example_algorithm.py
```

Run with the included scenario file:

```bash
iints run --algo algorithms/example_algorithm.py --scenario-path scenarios/clinic_safe_baseline.json --duration 1440
```

Certify data with the bundled contract:

```bash
iints data certify contracts/clinical_mdmp_contract.yaml data/demo/diabetes_cgm.csv --output-json audit/certification.json
```
"""
    (project_path / "README.md").write_text(readme_content)

    console.print(f"[green]Quickstart project ready in '{project_name}'.[/green]")
    console.print(
        f"Next:\n"
        f"  cd {project_name}\n"
        "  iints presets run --name baseline_t1d --algo algorithms/example_algorithm.py\n"
        "  iints data certify contracts/clinical_mdmp_contract.yaml data/demo/diabetes_cgm.csv --output-json audit/certification.json"
    )


@app.command(name="demo")
def demo(
    output_dir: Annotated[Path, typer.Option(help="Directory where the zero-config demo outputs should be written")] = Path("results/demo"),
    mode: Annotated[str, typer.Option("--mode", help="Demo mode: quick or full")] = "quick",
    quick_mode: Annotated[bool, typer.Option("--quick", help="Shortcut for --mode quick")] = False,
    full_mode: Annotated[bool, typer.Option("--full", help="Shortcut for --mode full")] = False,
    preset: Annotated[Optional[str], typer.Option(help="Optional preset override. Defaults to baseline_t1d for quick and stress_test_meal for full.")] = None,
    seed: Annotated[int, typer.Option(help="Deterministic seed for the bundled demo")] = 42,
    compare_baselines: Annotated[bool, typer.Option(help="Include built-in baselines in the demo output")] = True,
    dry_run: Annotated[bool, typer.Option("--dry-run", help="Show the plan without running the demo")] = False,
):
    """
    Zero-config demo run for first-time users.

    Examples:
      iints demo
      iints demo --mode full
      iints demo --dry-run
    """
    console = Console()
    if quick_mode and full_mode:
        console.print("[bold red]Use either --quick or --full, not both.[/bold red]")
        raise typer.Exit(code=1)

    normalized_mode = mode.strip().lower()
    if quick_mode:
        normalized_mode = "quick"
    if full_mode:
        normalized_mode = "full"
    if normalized_mode not in {"quick", "full"}:
        console.print("[bold red]Demo mode must be 'quick' or 'full'.[/bold red]")
        raise typer.Exit(code=1)

    resolved_preset = preset or ("baseline_t1d" if normalized_mode == "quick" else "stress_test_meal")
    duration = 180 if normalized_mode == "quick" else 720
    console.print(
        Panel(
            "\n".join(
                [
                    f"Mode: {normalized_mode}",
                    f"Preset: {resolved_preset}",
                    "Algorithm: built-in Clinical Baseline",
                    f"Output: {output_dir}",
                ]
            ),
            title="IINTS Demo",
            border_style="green",
        )
    )

    run(
        algo=None,
        preset=resolved_preset,
        predictor_path=None,
        patient_config_name="default_patient",
        patient_config_path=None,
        scenario_path=None,
        duration=duration,
        time_step=5,
        output_dir=output_dir,
        compare_baselines=compare_baselines,
        seed=seed,
        patient_model_type="auto",
        sensor_noise_std=None,
        sensor_lag_minutes=None,
        sensor_dropout_prob=None,
        sensor_bias=None,
        safety_min_glucose=None,
        safety_max_glucose=None,
        safety_max_glucose_delta_per_5_min=None,
        safety_hypoglycemia_threshold=None,
        safety_severe_hypoglycemia_threshold=None,
        safety_hyperglycemia_threshold=None,
        safety_max_insulin_per_bolus=None,
        safety_glucose_rate_alarm=None,
        safety_max_insulin_per_hour=None,
        safety_max_iob=None,
        safety_trend_stop=None,
        safety_hypo_cutoff=None,
        safety_critical_glucose_threshold=None,
        safety_critical_glucose_duration_minutes=None,
        safety_predictor_uncertainty_gate_enabled=None,
        safety_predictor_uncertainty_max_std_mgdl=None,
        safety_predictor_ood_gate_enabled=None,
        safety_predictor_ood_zscore_threshold=None,
        safety_predictor_ood_max_feature_fraction=None,
        wizard=False,
        dry_run=dry_run,
    )

    if dry_run:
        return

    demo_algo_path = _write_default_algorithm_template(
        output_dir / "demo_assets" / "example_algorithm.py",
        algo_name="DemoAlgorithm",
        author_name="IINTS Demo",
    )
    console.print(
        Panel(
            "\n".join(
                [
                    f"Editable example algorithm: {demo_algo_path}",
                    "Next steps:",
                    f"1. Rerun with your own file: iints run --algo {demo_algo_path} --preset {resolved_preset}",
                    "2. Use `iints run --wizard` if you want to tweak the patient or scenario interactively.",
                ]
            ),
            title="What To Do Next",
            border_style="blue",
        )
    )


@app.command(name="guide")
def guide():
    """Friendly entry point that helps beginners choose the right first command."""
    console = Console()
    console.print(
        Panel(
            "\n".join(
                [
                    "1. Quick demo (recommended first run)",
                    "2. Build a custom run interactively",
                    "3. Scaffold a project folder",
                    "4. Raspberry Pi / Maker Faire path",
                ]
            ),
            title="IINTS Guide",
            border_style="blue",
        )
    )
    choice = typer.prompt("Choose 1, 2, 3, or 4", default="1").strip()
    if choice == "1":
        demo()
        return
    if choice == "2":
        run_wizard()
        return
    if choice == "3":
        project_name = typer.prompt("Project folder name", default="iints_quickstart").strip() or "iints_quickstart"
        quickstart(project_name=project_name)
        return
    if choice == "4":
        console.print(
            Panel(
                "\n".join(
                    [
                        "Pi-only booth flow:",
                        "1. iints edge doctor --board raspberry_pi",
                        "2. iints edge setup --output-dir iints_pi_demo --board raspberry_pi --scenario-profile expo_hot_start",
                        "3. cd iints_pi_demo",
                        "4. iints makerfaire up --project-dir .",
                        "",
                        f"Docs: {Path.cwd() / 'docs' / 'MAKERFAIRE_PI.md'}",
                    ]
                ),
                title="Maker Faire Path",
                border_style="green",
            )
        )
        return
    console.print("[bold red]Unknown choice. Please rerun `iints guide` and choose 1, 2, 3, or 4.[/bold red]")
    raise typer.Exit(code=1)


@app.command()
def new_algo(
    name: Annotated[str, typer.Option(help="Name of the new algorithm")],
    author: Annotated[str, typer.Option(help="Author of the algorithm")],
    output_dir: Annotated[Path, typer.Option(help="Directory to save the new algorithm file")] = Path("."),
):
    """
    Creates a new algorithm template file based on the BaseAlgorithm.
    """
    if not output_dir.is_dir():
        typer.echo(f"Error: Output directory '{output_dir}' does not exist.")
        raise typer.Exit(code=1)

    try:
        # Try Python 3.9+ style
        if sys.version_info >= (3, 9):
            from importlib.resources import files
            template_content = files("iints.templates").joinpath("default_algorithm.py").read_text()
        else:
            # Fallback for Python 3.8
            from importlib import resources
            template_content = resources.read_text("iints.templates", "default_algorithm.py")
    except Exception as e:
        typer.echo(f"Error reading template file: {e}")
        raise typer.Exit(code=1)

    # Replace placeholders
    # We expect the template class name to be {{ALGO_NAME}} and author {{AUTHOR_NAME}}
    # But wait, the file I wrote uses {{ALGO_NAME}} as a class name, which is valid syntax only if I replace it.
    # The file on disk is valid python ONLY if those tokens are valid. 
    # Actually, in the previous step I wrote {{ALGO_NAME}} literally into the python file.
    # That makes the template file itself invalid python syntax until replaced. 
    # That's fine for a template file, but might confuse linters. 
    # Ideally it's a .txt or .tmpl, but .py is fine if we accept it's a template.
    
    final_content = template_content.replace("{{ALGO_NAME}}", f"{name}Algorithm")
    final_content = final_content.replace("{{AUTHOR_NAME}}", author)

    output_file = output_dir / f"{name.lower().replace(' ', '_')}_algorithm.py"
    with open(output_file, "w") as f:
        f.write(final_content)
    
    typer.echo(f"Successfully created new algorithm template: {output_file}")


@presets_app.command(name="list")
def presets_list():
    """List clinic-safe presets."""
    console = Console()
    presets = _load_presets()
    table = Table(title="Clinic-Safe Presets", show_lines=False)
    table.add_column("Name", style="cyan")
    table.add_column("Description")
    table.add_column("Patient Config")
    table.add_column("Duration (min)", justify="right")
    for preset in presets:
        table.add_row(
            preset.get("name", ""),
            preset.get("description", ""),
            preset.get("patient_config", ""),
            str(preset.get("duration_minutes", "")),
        )
    console.print(table)


@presets_app.command(name="show")
def presets_show(
    name: Annotated[str, typer.Option(help="Preset name (e.g., baseline_t1d)")],
):
    """Show a preset definition."""
    console = Console()
    try:
        preset = _get_preset(name)
    except KeyError:
        console.print(f"[bold red]Error: Unknown preset '{name}'.[/bold red]")
        raise typer.Exit(code=1)
    console.print_json(json.dumps(preset, indent=2))


@presets_app.command(name="run")
def presets_run(
    name: Annotated[str, typer.Option(help="Preset name (e.g., baseline_t1d)")],
    algo: Annotated[Path, typer.Option(help="Path to the algorithm Python file")],
    predictor_path: Annotated[Optional[Path], typer.Option("--predictor", help="Optional predictor checkpoint (.pt) for dual-guard forecasting")] = None,
    output_dir: Annotated[Optional[Path], typer.Option(help="Directory to save outputs")] = None,
    compare_baselines: Annotated[bool, typer.Option(help="Run PID and standard pump baselines in the background")] = True,
    seed: Annotated[Optional[int], typer.Option(help="Random seed for deterministic runs")] = None,
    patient_model_type: Annotated[str, typer.Option("--patient-model", help="Patient model: auto, bergman, custom, simglucose")] = "auto",
    sensor_noise_std: Annotated[Optional[float], typer.Option("--sensor-noise-std", help="CGM noise std (mg/dL)")] = None,
    sensor_lag_minutes: Annotated[Optional[int], typer.Option("--sensor-lag-minutes", help="CGM lag (minutes)")] = None,
    sensor_dropout_prob: Annotated[Optional[float], typer.Option("--sensor-dropout-prob", help="CGM dropout probability (0-1)")] = None,
    sensor_bias: Annotated[Optional[float], typer.Option("--sensor-bias", help="CGM bias (mg/dL)")] = None,
    safety_min_glucose: Annotated[Optional[float], typer.Option("--safety-min-glucose", help="Min plausible glucose (mg/dL)")] = None,
    safety_max_glucose: Annotated[Optional[float], typer.Option("--safety-max-glucose", help="Max plausible glucose (mg/dL)")] = None,
    safety_max_glucose_delta_per_5_min: Annotated[Optional[float], typer.Option("--safety-max-glucose-delta-per-5-min", help="Max glucose delta per 5 min (mg/dL)")] = None,
    safety_hypoglycemia_threshold: Annotated[Optional[float], typer.Option("--safety-hypo-threshold", help="Hypoglycemia threshold (mg/dL)")] = None,
    safety_severe_hypoglycemia_threshold: Annotated[Optional[float], typer.Option("--safety-severe-hypo-threshold", help="Severe hypoglycemia threshold (mg/dL)")] = None,
    safety_hyperglycemia_threshold: Annotated[Optional[float], typer.Option("--safety-hyper-threshold", help="Hyperglycemia threshold (mg/dL)")] = None,
    safety_max_insulin_per_bolus: Annotated[Optional[float], typer.Option("--safety-max-bolus", help="Max insulin per bolus (U)")] = None,
    safety_glucose_rate_alarm: Annotated[Optional[float], typer.Option("--safety-glucose-rate-alarm", help="Glucose rate alarm (mg/dL/min)")] = None,
    safety_max_insulin_per_hour: Annotated[Optional[float], typer.Option("--safety-max-insulin-per-hour", help="Max insulin per 60 min (U)")] = None,
    safety_max_iob: Annotated[Optional[float], typer.Option("--safety-max-iob", help="Max insulin on board (U)")] = None,
    safety_trend_stop: Annotated[Optional[float], typer.Option("--safety-trend-stop", help="Negative trend cutoff (mg/dL/min)")] = None,
    safety_hypo_cutoff: Annotated[Optional[float], typer.Option("--safety-hypo-cutoff", help="Hard hypo cutoff (mg/dL)")] = None,
    safety_critical_glucose_threshold: Annotated[Optional[float], typer.Option("--safety-critical-glucose", help="Critical glucose threshold (mg/dL)")] = None,
    safety_critical_glucose_duration_minutes: Annotated[Optional[int], typer.Option("--safety-critical-duration", help="Critical glucose duration (minutes)")] = None,
    safety_predictor_uncertainty_gate_enabled: Annotated[Optional[bool], typer.Option("--safety-predictor-uncertainty-gate", help="Enable predictor uncertainty gate")] = None,
    safety_predictor_uncertainty_max_std_mgdl: Annotated[Optional[float], typer.Option("--safety-predictor-max-std", help="Max allowed predictor std (mg/dL) before fallback")] = None,
    safety_predictor_ood_gate_enabled: Annotated[Optional[bool], typer.Option("--safety-predictor-ood-gate", help="Enable predictor OOD gate")] = None,
    safety_predictor_ood_zscore_threshold: Annotated[Optional[float], typer.Option("--safety-predictor-ood-z", help="Predictor OOD z-score threshold")] = None,
    safety_predictor_ood_max_feature_fraction: Annotated[Optional[float], typer.Option("--safety-predictor-ood-feature-fraction", help="Max fraction of features allowed OOD")] = None,
):
    """Run a clinic-safe preset with an algorithm and generate outputs."""
    console = Console()
    try:
        preset = _get_preset(name)
    except KeyError:
        console.print(f"[bold red]Error: Unknown preset '{name}'.[/bold red]")
        raise typer.Exit(code=1)

    algorithm_instance = _load_algorithm_instance(algo, console)
    console.print(f"Loaded algorithm: [green]{algorithm_instance.get_algorithm_metadata().name}[/green]")
    predictor = _load_predictor_service_from_path(predictor_path, console)

    resolved_seed = resolve_seed(seed)
    run_id = generate_run_id(resolved_seed)

    try:
        patient_config_name = preset.get("patient_config", "default_patient")
        validated_patient_params = load_patient_config_by_name(patient_config_name).model_dump()
        patient_model = iints.PatientFactory.create_patient(patient_type=patient_model_type, **validated_patient_params)
    except ValidationError as e:
        console.print("[bold red]Patient config validation failed:[/bold red]")
        for line in format_validation_error(e):
            console.print(f"- {line}")
        raise typer.Exit(code=1)
    except Exception as e:
        console.print(f"[bold red]Error loading patient config {patient_config_name}: {e}[/bold red]")
        raise typer.Exit(code=1)

    duration = int(preset.get("duration_minutes", 720))
    time_step = int(preset.get("time_step_minutes", 5))
    safety_config = _build_safety_config_from_options(
        min_glucose=safety_min_glucose,
        max_glucose=safety_max_glucose,
        max_glucose_delta_per_5_min=safety_max_glucose_delta_per_5_min,
        hypoglycemia_threshold=safety_hypoglycemia_threshold,
        severe_hypoglycemia_threshold=safety_severe_hypoglycemia_threshold,
        hyperglycemia_threshold=safety_hyperglycemia_threshold,
        max_insulin_per_bolus=safety_max_insulin_per_bolus,
        glucose_rate_alarm=safety_glucose_rate_alarm,
        max_insulin_per_hour=safety_max_insulin_per_hour,
        max_iob=safety_max_iob,
        trend_stop=safety_trend_stop,
        hypo_cutoff=safety_hypo_cutoff,
        critical_glucose_threshold=safety_critical_glucose_threshold,
        critical_glucose_duration_minutes=safety_critical_glucose_duration_minutes,
        predictor_uncertainty_gate_enabled=safety_predictor_uncertainty_gate_enabled,
        predictor_uncertainty_max_std_mgdl=safety_predictor_uncertainty_max_std_mgdl,
        predictor_ood_gate_enabled=safety_predictor_ood_gate_enabled,
        predictor_ood_zscore_threshold=safety_predictor_ood_zscore_threshold,
        predictor_ood_max_feature_fraction=safety_predictor_ood_max_feature_fraction,
    )

    sensor_model = None
    if any(v is not None for v in (sensor_noise_std, sensor_lag_minutes, sensor_dropout_prob, sensor_bias)):
        sensor_model = iints.SensorModel(
            noise_std=float(sensor_noise_std or 0.0),
            lag_minutes=int(sensor_lag_minutes or 0),
            dropout_prob=float(sensor_dropout_prob or 0.0),
            bias=float(sensor_bias or 0.0),
            seed=resolved_seed,
        )
    elif patient_model_type == "auto":
        sensor_model = iints.SensorModel(
            noise_std=7.0,
            lag_minutes=10,
            dropout_prob=0.0,
            bias=0.0,
            seed=resolved_seed,
        )

    simulator_kwargs: Dict[str, Any] = {
        "patient_model": patient_model,
        "algorithm": algorithm_instance,
        "time_step": time_step,
        "safety_config": safety_config,
        "predictor": predictor,
    }
    if sensor_model is not None:
        simulator_kwargs["sensor_model"] = sensor_model
    simulator_kwargs["seed"] = resolved_seed
    if safety_config is None:
        safety_config = SafetyConfig()
        if "critical_glucose_threshold" in preset:
            safety_config.critical_glucose_threshold = float(preset["critical_glucose_threshold"])
        if "critical_glucose_duration_minutes" in preset:
            safety_config.critical_glucose_duration_minutes = int(preset["critical_glucose_duration_minutes"])
        simulator_kwargs["safety_config"] = safety_config
    simulator = iints.Simulator(**simulator_kwargs)

    scenario_payload = preset.get("scenario", {})
    try:
        scenario_model = validate_scenario_dict(scenario_payload)
    except ValidationError as e:
        console.print("[bold red]Preset scenario validation failed:[/bold red]")
        for line in format_validation_error(e):
            console.print(f"- {line}")
        raise typer.Exit(code=1)

    stress_event_payloads = scenario_to_payloads(scenario_model)
    for warning in scenario_warnings(scenario_model):
        console.print(f"[yellow]Warning:[/yellow] {warning}")
    for event in build_stress_events(stress_event_payloads):
        simulator.add_stress_event(event)

    output_dir = resolve_output_dir(output_dir, run_id)
    results_df, safety_report = simulator.run_batch(duration)

    scenario_payload = scenario_model.model_dump() if scenario_model else None
    config_payload: Dict[str, Any] = {
        "run_type": "preset",
        "preset_name": name,
        "algorithm": {
            "class": f"{algorithm_instance.__class__.__module__}.{algorithm_instance.__class__.__name__}",
            "metadata": algorithm_instance.get_algorithm_metadata().to_dict(),
        },
        "patient_config": validated_patient_params,
        "scenario": scenario_payload,
        "duration_minutes": duration,
        "time_step_minutes": time_step,
        "seed": resolved_seed,
        "compare_baselines": compare_baselines,
        "export_audit": True,
        "generate_report": True,
        "safety_config": asdict(safety_config),
        "predictor_path": str(predictor_path) if predictor_path else None,
    }
    config_path = output_dir / "config.json"
    write_json(config_path, config_payload)
    run_metadata = build_run_metadata(run_id, resolved_seed, config_payload, output_dir)
    run_metadata_path = output_dir / "run_metadata.json"
    write_json(run_metadata_path, run_metadata)

    results_file = output_dir / "results.csv"
    results_df.to_csv(results_file, index=False)
    console.print(f"Results saved to: {results_file}")
    console.print(f"Run metadata: {run_metadata_path}")

    audit_dir = output_dir / "audit"
    try:
        audit_paths = simulator.export_audit_trail(results_df, output_dir=str(audit_dir))
        console.print(f"Audit trail: {audit_paths}")
    except Exception as e:
        console.print(f"[yellow]Audit export skipped: {e}[/yellow]")

    if compare_baselines:
        comparison = run_baseline_comparison(
            patient_params=validated_patient_params,
            stress_event_payloads=stress_event_payloads,
            duration=duration,
            time_step=time_step,
            primary_label=algorithm_instance.get_algorithm_metadata().name,
            primary_results=results_df,
            primary_safety=safety_report,
            seed=resolved_seed,
        )
        safety_report["baseline_comparison"] = comparison
        baseline_paths = write_baseline_comparison(comparison, output_dir / "baseline")
        console.print(f"Baseline comparison saved to: {baseline_paths}")

    report_path = output_dir / "report.pdf"
    iints.generate_report(results_df, str(report_path), safety_report)
    console.print(f"PDF report saved to: {report_path}")

    manifest_files = {
        "config": config_path,
        "run_metadata": run_metadata_path,
        "results_csv": results_file,
        "report_pdf": report_path,
    }
    if compare_baselines:
        manifest_files["baseline_json"] = output_dir / "baseline" / "baseline_comparison.json"
        manifest_files["baseline_csv"] = output_dir / "baseline" / "baseline_comparison.csv"
    audit_summary_path = output_dir / "audit" / "audit_summary.json"
    if audit_summary_path.exists():
        manifest_files["audit_summary"] = audit_summary_path
    run_manifest = build_run_manifest(output_dir, manifest_files)
    run_manifest_path = output_dir / "run_manifest.json"
    write_json(run_manifest_path, run_manifest)
    console.print(f"Run manifest: {run_manifest_path}")
    _maybe_prepare_ai_artifacts(output_dir, console)
    signature_path = maybe_sign_manifest(run_manifest_path)
    if signature_path:
        console.print(f"Run manifest signature: {signature_path}")
    _maybe_prepare_ai_artifacts(output_dir, console)


@presets_app.command(name="create")
def presets_create(
    name: Annotated[str, typer.Option(help="Preset name (snake_case)")],
    output_dir: Annotated[Path, typer.Option(help="Output directory for preset files")] = Path("./presets"),
    initial_glucose: Annotated[float, typer.Option(help="Initial glucose (mg/dL)")] = 140.0,
    basal_insulin_rate: Annotated[float, typer.Option(help="Basal insulin rate (U/hr)")] = 0.5,
    insulin_sensitivity: Annotated[float, typer.Option(help="Insulin sensitivity (mg/dL per U)")] = 50.0,
    carb_factor: Annotated[float, typer.Option(help="Carb factor (g per U)")] = 10.0,
):
    """
    Generate a clinic-safe preset scaffold (patient YAML + scenario JSON).
    """
    console = Console()
    output_dir.mkdir(parents=True, exist_ok=True)

    patient_config_name = f"clinic_safe_{name}"
    patient_yaml_path = output_dir / f"{patient_config_name}.yaml"
    scenario_path = output_dir / f"{name}.json"

    patient_yaml = (
        f"basal_insulin_rate: {basal_insulin_rate}\n"
        f"insulin_sensitivity: {insulin_sensitivity}\n"
        f"carb_factor: {carb_factor}\n"
        "glucose_decay_rate: 0.03\n"
        f"initial_glucose: {initial_glucose}\n"
        "glucose_absorption_rate: 0.03\n"
        "insulin_action_duration: 300.0\n"
        "insulin_peak_time: 75.0\n"
        "meal_mismatch_epsilon: 1.0\n"
    )
    patient_yaml_path.write_text(patient_yaml)

    scenario = {
        "scenario_name": f"Clinic Safe {name.replace('_', ' ').title()}",
        "schema_version": "1.1",
        "scenario_version": "1.0",
        "stress_events": [
            {"start_time": 60, "event_type": "meal", "value": 45, "absorption_delay_minutes": 15, "duration": 60},
            {"start_time": 360, "event_type": "meal", "value": 60, "absorption_delay_minutes": 20, "duration": 90},
            {"start_time": 720, "event_type": "meal", "value": 70, "absorption_delay_minutes": 15, "duration": 90},
        ],
    }
    scenario_path.write_text(json.dumps(scenario, indent=2))

    preset_snippet = {
        "name": name,
        "description": "Custom clinic-safe preset (generated).",
        "patient_config": patient_config_name,
        "duration_minutes": 1440,
        "time_step_minutes": 5,
        "critical_glucose_threshold": 40.0,
        "critical_glucose_duration_minutes": 30,
        "scenario": scenario,
    }

    console.print(f"[green]Preset files created:[/green] {patient_yaml_path} , {scenario_path}")
    console.print("[bold]Add this preset to presets.json if you want it built-in:[/bold]")
    console.print_json(json.dumps(preset_snippet, indent=2))


@app.command(name="run-wizard")
def run_wizard():
    """Interactive wizard that forwards to `iints run --wizard`."""
    run(
        algo=None,
        preset=None,
        predictor_path=None,
        patient_config_name="default_patient",
        patient_config_path=None,
        scenario_path=None,
        duration=720,
        time_step=5,
        output_dir=None,
        compare_baselines=True,
        seed=None,
        patient_model_type="auto",
        sensor_noise_std=None,
        sensor_lag_minutes=None,
        sensor_dropout_prob=None,
        sensor_bias=None,
        safety_min_glucose=None,
        safety_max_glucose=None,
        safety_max_glucose_delta_per_5_min=None,
        safety_hypoglycemia_threshold=None,
        safety_severe_hypoglycemia_threshold=None,
        safety_hyperglycemia_threshold=None,
        safety_max_insulin_per_bolus=None,
        safety_glucose_rate_alarm=None,
        safety_max_insulin_per_hour=None,
        safety_max_iob=None,
        safety_trend_stop=None,
        safety_hypo_cutoff=None,
        safety_critical_glucose_threshold=None,
        safety_critical_glucose_duration_minutes=None,
        safety_predictor_uncertainty_gate_enabled=None,
        safety_predictor_uncertainty_max_std_mgdl=None,
        safety_predictor_ood_gate_enabled=None,
        safety_predictor_ood_zscore_threshold=None,
        safety_predictor_ood_max_feature_fraction=None,
        wizard=True,
        dry_run=False,
    )


@profiles_app.command(name="create")
def profiles_create(
    name: Annotated[str, typer.Option(help="Profile name (file stem)")],
    output_dir: Annotated[Path, typer.Option(help="Output directory for the profile YAML")] = Path("./patient_profiles"),
    isf: Annotated[float, typer.Option(help="Insulin Sensitivity Factor (mg/dL per unit)")] = 50.0,
    icr: Annotated[float, typer.Option(help="Insulin-to-carb ratio (grams per unit)")] = 10.0,
    basal_rate: Annotated[float, typer.Option(help="Basal insulin rate (U/hr)")] = 0.8,
    initial_glucose: Annotated[float, typer.Option(help="Initial glucose (mg/dL)")] = 120.0,
    dawn_strength: Annotated[float, typer.Option(help="Dawn phenomenon strength (mg/dL per hour)")] = 0.0,
    dawn_start: Annotated[float, typer.Option(help="Dawn phenomenon start hour (0-23)")] = 4.0,
    dawn_end: Annotated[float, typer.Option(help="Dawn phenomenon end hour (0-24)")] = 8.0,
):
    """Create a patient profile YAML you can pass to --patient-config-path."""
    console = Console()
    output_dir.mkdir(parents=True, exist_ok=True)
    output_path = output_dir / f"{name}.yaml"

    profile = PatientProfile(
        isf=isf,
        icr=icr,
        basal_rate=basal_rate,
        initial_glucose=initial_glucose,
        dawn_phenomenon_strength=dawn_strength,
        dawn_start_hour=dawn_start,
        dawn_end_hour=dawn_end,
    )
    with output_path.open("w") as handle:
        yaml.safe_dump(profile.to_patient_config(), handle, sort_keys=False)

    console.print(f"[green]Patient profile saved:[/green] {output_path}")
    console.print("Use it with:")
    console.print(f"  iints run --algo algorithms/example_algorithm.py --patient-config-path {output_path}")


@scenarios_app.command(name="generate")
def scenarios_generate(
    name: Annotated[str, typer.Option(help="Scenario name")] = "Generated Scenario",
    output_path: Annotated[Path, typer.Option(help="Output JSON path")] = Path("./scenarios/generated_scenario.json"),
    duration_minutes: Annotated[int, typer.Option(help="Scenario duration in minutes")] = 1440,
    seed: Annotated[Optional[int], typer.Option(help="Random seed")] = None,
    meal_count: Annotated[int, typer.Option(help="Number of meal events")] = 3,
    meal_min_grams: Annotated[float, typer.Option(help="Min meal size (g carbs)")] = 30.0,
    meal_max_grams: Annotated[float, typer.Option(help="Max meal size (g carbs)")] = 80.0,
    exercise_count: Annotated[int, typer.Option(help="Number of exercise events")] = 0,
    sensor_error_count: Annotated[int, typer.Option(help="Number of sensor error events")] = 0,
):
    """Generate a random stress-test scenario JSON."""
    config = ScenarioGeneratorConfig(
        name=name,
        duration_minutes=duration_minutes,
        seed=seed,
        meal_count=meal_count,
        meal_min_grams=meal_min_grams,
        meal_max_grams=meal_max_grams,
        exercise_count=exercise_count,
        sensor_error_count=sensor_error_count,
    )
    scenario = generate_random_scenario(config)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(scenario, indent=2))
    typer.echo(f"Scenario saved: {output_path}")


@scenarios_app.command(name="wizard")
def scenarios_wizard():
    """Interactive scenario generator."""
    name = typer.prompt("Scenario name", default="Generated Scenario")
    duration_minutes = int(typer.prompt("Duration (minutes)", default="1440"))
    meal_count = int(typer.prompt("Meal events", default="3"))
    meal_min = float(typer.prompt("Meal min grams", default="30"))
    meal_max = float(typer.prompt("Meal max grams", default="80"))
    exercise_count = int(typer.prompt("Exercise events", default="0"))
    sensor_error_count = int(typer.prompt("Sensor error events", default="0"))
    output_path = Path(typer.prompt("Output JSON path", default="scenarios/generated_scenario.json"))

    config = ScenarioGeneratorConfig(
        name=name,
        duration_minutes=duration_minutes,
        meal_count=meal_count,
        meal_min_grams=meal_min,
        meal_max_grams=meal_max,
        exercise_count=exercise_count,
        sensor_error_count=sensor_error_count,
    )
    scenario = generate_random_scenario(config)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(scenario, indent=2))
    typer.echo(f"Scenario saved: {output_path}")


@scenarios_app.command(name="migrate")
def scenarios_migrate(
    input_path: Annotated[Path, typer.Argument(help="Scenario JSON to migrate")],
    output_path: Annotated[Optional[Path], typer.Option(help="Output path (default: overwrite input)")] = None,
):
    """Migrate a scenario JSON to the latest schema version."""
    console = Console()
    if not input_path.is_file():
        console.print(f"[bold red]Error: Scenario '{input_path}' not found.[/bold red]")
        raise typer.Exit(code=1)
    try:
        data = json.loads(input_path.read_text())
    except json.JSONDecodeError as exc:
        console.print(f"[bold red]Invalid JSON: {exc}[/bold red]")
        raise typer.Exit(code=1)
    migrated = migrate_scenario_dict(data)
    target = output_path or input_path
    target.write_text(json.dumps(migrated, indent=2))
    console.print(f"[green]Migrated scenario saved to {target}[/green]")


@scenarios_app.command(name="export-study-pack")
def scenarios_export_study_pack(
    output_dir: Annotated[Path, typer.Option(help="Directory to write the official study pack")] = Path("scenarios/study_pack"),
    seeds: Annotated[str, typer.Option(help="Comma-separated seed list to include in the pack manifest")] = "1,2,3,4,5,6,7,8,9,10",
    preset: Annotated[str, typer.Option(help="Study-pack preset: official or eucys")] = "official",
):
    """Export the official public study pack used for repeatable evidence runs."""
    console = Console()
    try:
        parsed_seeds = [int(item.strip()) for item in seeds.split(",") if item.strip()]
        normalized_preset = preset.strip().lower()
        if normalized_preset == "official":
            outputs = export_official_study_pack(output_dir, seeds=parsed_seeds)
        elif normalized_preset == "eucys":
            outputs = export_eucys_study_pack(output_dir, seeds=parsed_seeds)
        else:
            raise ValueError("preset must be 'official' or 'eucys'")
    except Exception as exc:
        console.print(f"[bold red]Study pack export failed: {exc}[/bold red]")
        raise typer.Exit(code=1)
    console.print(f"[green]Study pack exported:[/green] {outputs['output_dir']}")
    console.print(f"[green]Manifest:[/green] {outputs['manifest_json']}")
    if "matrix_csv" in outputs:
        console.print(f"[green]Study matrix:[/green] {outputs['matrix_csv']}")

@app.command()
def run(
    algo: Annotated[Optional[Path], typer.Option(help="Path to the algorithm Python file. Leave blank to use the built-in Clinical Baseline.")] = None,
    preset: Annotated[Optional[str], typer.Option(help="Optional built-in preset such as baseline_t1d. This fills the patient profile and scenario unless you override them.")] = None,
    predictor_path: Annotated[Optional[Path], typer.Option("--predictor", help="Optional predictor checkpoint (.pt) for dual-guard forecasting")] = None,
    patient_config_name: Annotated[str, typer.Option(help="Name of the patient configuration (for example 'default_patient' or 'clinic_safe_baseline')")] = "default_patient",
    patient_config_path: Annotated[Optional[Path], typer.Option(help="Path to a patient config YAML (overrides --patient-config-name)")] = None,
    scenario_path: Annotated[
        Optional[Path],
        typer.Option(
            "--scenario",
            "--scenario-path",
            help="Path to the scenario JSON file (for example scenarios/example_scenario.json)",
        ),
    ] = None,
    duration: Annotated[int, typer.Option(help="Simulation duration in minutes")] = 720,
    time_step: Annotated[int, typer.Option(help="Simulation time step in minutes")] = 5,
    output_dir: Annotated[Optional[Path], typer.Option(help="Directory to save simulation results")] = None,
    compare_baselines: Annotated[bool, typer.Option(help="Run built-in baselines in the background for comparison")] = True,
    seed: Annotated[Optional[int], typer.Option(help="Random seed for deterministic runs")] = None,
    patient_model_type: Annotated[str, typer.Option("--patient-model", help="Patient model: auto, bergman, custom, simglucose")] = "auto",
    sensor_noise_std: Annotated[Optional[float], typer.Option("--sensor-noise-std", help="CGM noise std (mg/dL)")] = None,
    sensor_lag_minutes: Annotated[Optional[int], typer.Option("--sensor-lag-minutes", help="CGM lag (minutes)")] = None,
    sensor_dropout_prob: Annotated[Optional[float], typer.Option("--sensor-dropout-prob", help="CGM dropout probability (0-1)")] = None,
    sensor_bias: Annotated[Optional[float], typer.Option("--sensor-bias", help="CGM bias (mg/dL)")] = None,
    safety_min_glucose: Annotated[Optional[float], typer.Option("--safety-min-glucose", help="Min plausible glucose (mg/dL)")] = None,
    safety_max_glucose: Annotated[Optional[float], typer.Option("--safety-max-glucose", help="Max plausible glucose (mg/dL)")] = None,
    safety_max_glucose_delta_per_5_min: Annotated[Optional[float], typer.Option("--safety-max-glucose-delta-per-5-min", help="Max glucose delta per 5 min (mg/dL)")] = None,
    safety_hypoglycemia_threshold: Annotated[Optional[float], typer.Option("--safety-hypo-threshold", help="Hypoglycemia threshold (mg/dL)")] = None,
    safety_severe_hypoglycemia_threshold: Annotated[Optional[float], typer.Option("--safety-severe-hypo-threshold", help="Severe hypoglycemia threshold (mg/dL)")] = None,
    safety_hyperglycemia_threshold: Annotated[Optional[float], typer.Option("--safety-hyper-threshold", help="Hyperglycemia threshold (mg/dL)")] = None,
    safety_max_insulin_per_bolus: Annotated[Optional[float], typer.Option("--safety-max-bolus", help="Max insulin per bolus (U)")] = None,
    safety_glucose_rate_alarm: Annotated[Optional[float], typer.Option("--safety-glucose-rate-alarm", help="Glucose rate alarm (mg/dL/min)")] = None,
    safety_max_insulin_per_hour: Annotated[Optional[float], typer.Option("--safety-max-insulin-per-hour", help="Max insulin per 60 min (U)")] = None,
    safety_max_iob: Annotated[Optional[float], typer.Option("--safety-max-iob", help="Max insulin on board (U)")] = None,
    safety_trend_stop: Annotated[Optional[float], typer.Option("--safety-trend-stop", help="Negative trend cutoff (mg/dL/min)")] = None,
    safety_hypo_cutoff: Annotated[Optional[float], typer.Option("--safety-hypo-cutoff", help="Hard hypo cutoff (mg/dL)")] = None,
    safety_critical_glucose_threshold: Annotated[Optional[float], typer.Option("--safety-critical-glucose", help="Critical glucose threshold (mg/dL)")] = None,
    safety_critical_glucose_duration_minutes: Annotated[Optional[int], typer.Option("--safety-critical-duration", help="Critical glucose duration (minutes)")] = None,
    safety_predictor_uncertainty_gate_enabled: Annotated[Optional[bool], typer.Option("--safety-predictor-uncertainty-gate", help="Enable predictor uncertainty gate")] = None,
    safety_predictor_uncertainty_max_std_mgdl: Annotated[Optional[float], typer.Option("--safety-predictor-max-std", help="Max allowed predictor std (mg/dL) before fallback")] = None,
    safety_predictor_ood_gate_enabled: Annotated[Optional[bool], typer.Option("--safety-predictor-ood-gate", help="Enable predictor OOD gate")] = None,
    safety_predictor_ood_zscore_threshold: Annotated[Optional[float], typer.Option("--safety-predictor-ood-z", help="Predictor OOD z-score threshold")] = None,
    safety_predictor_ood_max_feature_fraction: Annotated[Optional[float], typer.Option("--safety-predictor-ood-feature-fraction", help="Max fraction of features allowed OOD")] = None,
    wizard: Annotated[bool, typer.Option("--wizard", help="Ask a few questions and build the run interactively")] = False,
    dry_run: Annotated[bool, typer.Option("--dry-run", help="Validate the setup and print the run plan without executing the simulation")] = False,
):
    """
    Run an IINTS-AF simulation.

    Examples:
      iints run --preset baseline_t1d
      iints run --wizard
      iints run --algo algorithms/example_algorithm.py --scenario scenarios/example_scenario.json --dry-run
    """
    console = Console()
    wall_start = time.perf_counter()

    try:
        ctx = click.get_current_context(silent=True)
    except RuntimeError:
        ctx = None

    def _uses_default(name: str) -> bool:
        if ctx is None:
            return False
        source = ctx.get_parameter_source(name)
        return source in (None, ParameterSource.DEFAULT)

    if wizard:
        console.print(Panel("We bouwen samen een runplan. Laat velden leeg wanneer je de veilige standaard wilt gebruiken.", title="Run Wizard", border_style="blue"))
        available_presets = [item.get("name", "") for item in _load_presets() if item.get("name")]
        preset_default = preset or ("baseline_t1d" if available_presets else "")
        preset_input = typer.prompt("Preset (blank = custom)", default=preset_default, show_default=bool(preset_default))
        preset = preset_input.strip() or None
        algo_default = str(algo) if algo else ""
        algo_input = typer.prompt(
            "Algorithm path (blank = built-in Clinical Baseline)",
            default=algo_default,
            show_default=bool(algo_default),
        )
        algo = Path(algo_input) if algo_input.strip() else None
        if preset is None and patient_config_path is None:
            patient_config_name = typer.prompt("Patient config name", default=patient_config_name)
            scenario_default = str(scenario_path) if scenario_path else ""
            scenario_input = typer.prompt("Scenario JSON (blank = none)", default=scenario_default, show_default=bool(scenario_default))
            scenario_path = Path(scenario_input) if scenario_input.strip() else None
        duration = int(typer.prompt("Duration in minutes", default=str(duration)))
        time_step = int(typer.prompt("Time step in minutes", default=str(time_step)))
        compare_baselines = typer.confirm("Compare against built-in baselines?", default=compare_baselines)
        output_default = str(output_dir) if output_dir else ""
        output_input = typer.prompt("Output directory (blank = auto)", default=output_default, show_default=bool(output_default))
        output_dir = Path(output_input) if output_input.strip() else None
        seed_default = str(seed) if seed is not None else ""
        seed_input = typer.prompt("Seed (blank = auto)", default=seed_default, show_default=bool(seed_default))
        seed = int(seed_input) if seed_input.strip() else None

    preset_payload: Optional[Dict[str, Any]] = None
    if preset:
        try:
            preset_payload = _get_preset(preset)
        except KeyError:
            preset_names = [item.get("name", "") for item in _load_presets() if item.get("name")]
            matches = difflib.get_close_matches(preset, preset_names, n=1, cutoff=0.45)
            detail = f"Unknown preset '{preset}'."
            if matches:
                detail = f"{detail} Did you mean '{matches[0]}'?"
            console.print(f"[bold red]{detail}[/bold red]")
            raise typer.Exit(code=1)

        if patient_config_path is None and _uses_default("patient_config_name"):
            patient_config_name = str(preset_payload.get("patient_config", patient_config_name))
        if scenario_path is None and preset_payload.get("scenario") is not None:
            scenario_payload = cast(Dict[str, Any], preset_payload.get("scenario") or {})
        else:
            scenario_payload = None
        if _uses_default("duration"):
            duration = int(preset_payload.get("duration_minutes", duration))
        if _uses_default("time_step"):
            time_step = int(preset_payload.get("time_step_minutes", time_step))
    else:
        scenario_payload = None

    resolved_seed = resolve_seed(seed)
    run_id = generate_run_id(resolved_seed)
    if output_dir is None:
        predicted_output_dir = (Path.cwd() / "results" / run_id).resolve()
    else:
        predicted_output_dir = Path(output_dir).expanduser()
        if not predicted_output_dir.is_absolute():
            predicted_output_dir = (Path.cwd() / predicted_output_dir).resolve()
        else:
            predicted_output_dir = predicted_output_dir.resolve()

    algorithm_instance: iints.InsulinAlgorithm
    if algo is None:
        algorithm_instance = ClinicalBaselineAlgorithm()
        algorithm_label = algorithm_instance.get_algorithm_metadata().name
        algorithm_source = "built-in Clinical Baseline"
    else:
        algorithm_instance = _load_algorithm_instance(algo, console)
        algorithm_label = algorithm_instance.get_algorithm_metadata().name
        algorithm_source = str(algo)

    predictor = None
    if predictor_path is not None and not predictor_path.is_file():
        console.print(f"[bold red]Predictor checkpoint not found: {predictor_path}[/bold red]")
        raise typer.Exit(code=1)
    if not dry_run:
        predictor = _load_predictor_service_from_path(predictor_path, console)

    validated_patient_params: Dict[str, Any]
    patient_label: str
    try:
        if patient_config_path:
            if not patient_config_path.is_file():
                console.print(f"[bold red]{_patient_config_not_found_message(patient_config_path)}[/bold red]")
                raise typer.Exit(code=1)
            validated_patient_params = load_patient_config(patient_config_path).model_dump()
            patient_label = patient_config_path.stem
        else:
            validated_patient_params = load_patient_config_by_name(patient_config_name).model_dump()
            patient_label = patient_config_name
    except ValidationError as e:
        console.print("[bold red]Patient config validation failed:[/bold red]")
        for line in format_validation_error(e):
            console.print(f"- {line}")
        raise typer.Exit(code=1)
    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[bold red]Could not load patient config '{patient_config_name}': {e}[/bold red]")
        raise typer.Exit(code=1)

    stress_events = []
    stress_event_payloads: List[Dict[str, Any]] = []
    scenario_model = None
    if scenario_path:
        if not scenario_path.is_file():
            console.print(f"[bold red]{_scenario_not_found_message(scenario_path)}[/bold red]")
            raise typer.Exit(code=1)
        try:
            scenario_model = load_scenario(scenario_path)
        except ValidationError as e:
            console.print("[bold red]Scenario validation failed:[/bold red]")
            for line in format_validation_error(e):
                console.print(f"- {line}")
            raise typer.Exit(code=1)
        stress_event_payloads = scenario_to_payloads(scenario_model)
        stress_events = build_stress_events(stress_event_payloads)
        for warning in scenario_warnings(scenario_model):
            console.print(f"[yellow]Warning:[/yellow] {warning}")
        scenario_display = str(scenario_path)
    elif scenario_payload:
        try:
            scenario_model = validate_scenario_dict(scenario_payload)
        except ValidationError as e:
            console.print("[bold red]Preset scenario validation failed:[/bold red]")
            for line in format_validation_error(e):
                console.print(f"- {line}")
            raise typer.Exit(code=1)
        stress_event_payloads = scenario_to_payloads(scenario_model)
        stress_events = build_stress_events(stress_event_payloads)
        for warning in scenario_warnings(scenario_model):
            console.print(f"[yellow]Warning:[/yellow] {warning}")
        scenario_display = f"preset:{preset}"
    else:
        scenario_display = "none"

    if dry_run:
        _print_dry_run_plan(
            console,
            algorithm_label=algorithm_label,
            algorithm_source=algorithm_source,
            patient_label=patient_label,
            scenario_label=scenario_display,
            duration=duration,
            time_step=time_step,
            output_dir=predicted_output_dir,
            compare_baselines=compare_baselines,
            seed=resolved_seed,
            preset_name=preset,
        )
        return

    console.print(f"[bold blue]Starting IINTS-AF simulation[/bold blue] - {algorithm_label}")
    console.print(f"Patient: [cyan]{patient_label}[/cyan]")
    console.print(f"Scenario: [magenta]{scenario_display}[/magenta]")

    safety_config = _build_safety_config_from_options(
        min_glucose=safety_min_glucose,
        max_glucose=safety_max_glucose,
        max_glucose_delta_per_5_min=safety_max_glucose_delta_per_5_min,
        hypoglycemia_threshold=safety_hypoglycemia_threshold,
        severe_hypoglycemia_threshold=safety_severe_hypoglycemia_threshold,
        hyperglycemia_threshold=safety_hyperglycemia_threshold,
        max_insulin_per_bolus=safety_max_insulin_per_bolus,
        glucose_rate_alarm=safety_glucose_rate_alarm,
        max_insulin_per_hour=safety_max_insulin_per_hour,
        max_iob=safety_max_iob,
        trend_stop=safety_trend_stop,
        hypo_cutoff=safety_hypo_cutoff,
        critical_glucose_threshold=safety_critical_glucose_threshold,
        critical_glucose_duration_minutes=safety_critical_glucose_duration_minutes,
        predictor_uncertainty_gate_enabled=safety_predictor_uncertainty_gate_enabled,
        predictor_uncertainty_max_std_mgdl=safety_predictor_uncertainty_max_std_mgdl,
        predictor_ood_gate_enabled=safety_predictor_ood_gate_enabled,
        predictor_ood_zscore_threshold=safety_predictor_ood_zscore_threshold,
        predictor_ood_max_feature_fraction=safety_predictor_ood_max_feature_fraction,
    )

    effective_safety_config = safety_config or SafetyConfig()
    if safety_config is None and preset_payload is not None:
        if "critical_glucose_threshold" in preset_payload:
            effective_safety_config.critical_glucose_threshold = float(preset_payload["critical_glucose_threshold"])
        if "critical_glucose_duration_minutes" in preset_payload:
            effective_safety_config.critical_glucose_duration_minutes = int(preset_payload["critical_glucose_duration_minutes"])

    output_dir = resolve_output_dir(output_dir, run_id)

    with _run_progress(console) as progress:
        total_steps = 6 + (1 if compare_baselines else 0)
        task = progress.add_task("Preparing run", total=total_steps)

        device_manager = iints.DeviceManager()
        device = device_manager.get_device()
        progress.advance(task, 1)
        progress.update(task, description="Building patient model")

        try:
            patient_model = iints.PatientFactory.create_patient(patient_type=patient_model_type, **validated_patient_params)
        except ValidationError as e:
            console.print("[bold red]Patient config validation failed during model creation:[/bold red]")
            for line in format_validation_error(e):
                console.print(f"- {line}")
            raise typer.Exit(code=1)
        except TypeError as e:
            console.print(f"[bold red]Patient model creation failed:[/bold red] {e}")
            raise typer.Exit(code=1)
        progress.advance(task, 1)
        progress.update(task, description="Configuring sensor model")

        sensor_model = None
        if any(v is not None for v in (sensor_noise_std, sensor_lag_minutes, sensor_dropout_prob, sensor_bias)):
            sensor_model = iints.SensorModel(
                noise_std=float(sensor_noise_std or 0.0),
                lag_minutes=int(sensor_lag_minutes or 0),
                dropout_prob=float(sensor_dropout_prob or 0.0),
                bias=float(sensor_bias or 0.0),
                seed=resolved_seed,
            )
        elif patient_model_type == "auto":
            sensor_model = iints.SensorModel(
                noise_std=7.0,
                lag_minutes=10,
                dropout_prob=0.0,
                bias=0.0,
                seed=resolved_seed,
            )
        progress.advance(task, 1)
        progress.update(task, description="Starting simulator")

        simulator = iints.Simulator(
            patient_model=patient_model,
            algorithm=algorithm_instance,
            time_step=time_step,
            seed=resolved_seed,
            safety_config=effective_safety_config,
            sensor_model=sensor_model,
            predictor=predictor,
        )
        for event in stress_events:
            simulator.add_stress_event(event)
        progress.advance(task, 1)
        progress.update(task, description="Running simulation")

        simulation_results_df, safety_report = simulator.run_batch(duration)
        progress.advance(task, 1)
        progress.update(task, description="Writing outputs")

        config_payload: Dict[str, Any] = {
            "run_type": "single",
            "preset_name": preset,
            "algorithm": {
                "class": f"{algorithm_instance.__class__.__module__}.{algorithm_instance.__class__.__name__}",
                "metadata": algorithm_instance.get_algorithm_metadata().to_dict(),
            },
            "patient_config": validated_patient_params,
            "scenario": scenario_model.model_dump() if scenario_model else scenario_payload,
            "duration_minutes": duration,
            "time_step_minutes": time_step,
            "seed": resolved_seed,
            "compare_baselines": compare_baselines,
            "export_audit": False,
            "generate_report": True,
            "safety_config": asdict(effective_safety_config),
            "predictor_path": str(predictor_path) if predictor_path else None,
            "algorithm_source": algorithm_source,
        }
        config_path = output_dir / "config.json"
        write_json(config_path, config_payload)
        run_metadata = build_run_metadata(run_id, resolved_seed, config_payload, output_dir)
        run_metadata_path = output_dir / "run_metadata.json"
        write_json(run_metadata_path, run_metadata)

        results_file = output_dir / "results.csv"
        simulation_results_df.to_csv(results_file, index=False)
        progress.advance(task, 1)

        baseline_paths = None
        if compare_baselines:
            progress.update(task, description="Running baseline comparison")
            comparison = run_baseline_comparison(
                patient_params=validated_patient_params,
                stress_event_payloads=stress_event_payloads,
                duration=duration,
                time_step=time_step,
                primary_label=algorithm_label,
                primary_results=simulation_results_df,
                primary_safety=safety_report,
                seed=resolved_seed,
            )
            safety_report["baseline_comparison"] = comparison
            baseline_paths = write_baseline_comparison(comparison, output_dir / "baseline")
            progress.advance(task, 1)

        report_output_path = output_dir / "report.pdf"
        iints.generate_report(simulation_results_df, str(report_output_path), safety_report)

        manifest_files = {
            "config": config_path,
            "run_metadata": run_metadata_path,
            "results_csv": results_file,
            "report_pdf": report_output_path,
        }
        if compare_baselines:
            manifest_files["baseline_json"] = output_dir / "baseline" / "baseline_comparison.json"
            manifest_files["baseline_csv"] = output_dir / "baseline" / "baseline_comparison.csv"
        run_manifest = build_run_manifest(output_dir, manifest_files)
        run_manifest_path = output_dir / "run_manifest.json"
        write_json(run_manifest_path, run_manifest)

    metrics = compute_run_metrics(simulation_results_df, safety_report=safety_report, duration_minutes=duration)
    console.print(f"Using compute device: [blue]{device}[/blue]")
    if baseline_paths is not None:
        console.print(f"Baseline comparison saved to: {baseline_paths}")
    console.print(f"Run metadata: {run_metadata_path}")
    console.print(f"Run manifest: {run_manifest_path}")
    _print_run_summary(
        console,
        algorithm_name=algorithm_label,
        output_dir=output_dir,
        metrics=metrics,
        duration_minutes=duration,
        seed=resolved_seed,
        wall_seconds=time.perf_counter() - wall_start,
        preset_name=preset,
    )


@app.command(name="run-full")
def run_full(
    algo: Annotated[Path, typer.Option(help="Path to the algorithm Python file")],
    predictor_path: Annotated[Optional[Path], typer.Option("--predictor", help="Optional predictor checkpoint (.pt) for dual-guard forecasting")] = None,
    patient_config_name: Annotated[str, typer.Option(help="Name of the patient configuration (e.g., 'default_patient')")] = "default_patient",
    patient_config_path: Annotated[Optional[Path], typer.Option(help="Path to a patient config YAML (overrides --patient-config-name)")] = None,
    scenario_path: Annotated[Optional[Path], typer.Option(help="Path to the scenario JSON file")] = None,
    duration: Annotated[int, typer.Option(help="Simulation duration in minutes")] = 720,
    time_step: Annotated[int, typer.Option(help="Simulation time step in minutes")] = 5,
    output_dir: Annotated[Optional[Path], typer.Option(help="Directory to save results + audit + report")] = None,
    seed: Annotated[Optional[int], typer.Option(help="Random seed for deterministic runs")] = None,
    safety_min_glucose: Annotated[Optional[float], typer.Option("--safety-min-glucose", help="Min plausible glucose (mg/dL)")] = None,
    safety_max_glucose: Annotated[Optional[float], typer.Option("--safety-max-glucose", help="Max plausible glucose (mg/dL)")] = None,
    safety_max_glucose_delta_per_5_min: Annotated[Optional[float], typer.Option("--safety-max-glucose-delta-per-5-min", help="Max glucose delta per 5 min (mg/dL)")] = None,
    safety_hypoglycemia_threshold: Annotated[Optional[float], typer.Option("--safety-hypo-threshold", help="Hypoglycemia threshold (mg/dL)")] = None,
    safety_severe_hypoglycemia_threshold: Annotated[Optional[float], typer.Option("--safety-severe-hypo-threshold", help="Severe hypoglycemia threshold (mg/dL)")] = None,
    safety_hyperglycemia_threshold: Annotated[Optional[float], typer.Option("--safety-hyper-threshold", help="Hyperglycemia threshold (mg/dL)")] = None,
    safety_max_insulin_per_bolus: Annotated[Optional[float], typer.Option("--safety-max-bolus", help="Max insulin per bolus (U)")] = None,
    safety_glucose_rate_alarm: Annotated[Optional[float], typer.Option("--safety-glucose-rate-alarm", help="Glucose rate alarm (mg/dL/min)")] = None,
    safety_max_insulin_per_hour: Annotated[Optional[float], typer.Option("--safety-max-insulin-per-hour", help="Max insulin per 60 min (U)")] = None,
    safety_max_iob: Annotated[Optional[float], typer.Option("--safety-max-iob", help="Max insulin on board (U)")] = None,
    safety_trend_stop: Annotated[Optional[float], typer.Option("--safety-trend-stop", help="Negative trend cutoff (mg/dL/min)")] = None,
    safety_hypo_cutoff: Annotated[Optional[float], typer.Option("--safety-hypo-cutoff", help="Hard hypo cutoff (mg/dL)")] = None,
    safety_critical_glucose_threshold: Annotated[Optional[float], typer.Option("--safety-critical-glucose", help="Critical glucose threshold (mg/dL)")] = None,
    safety_critical_glucose_duration_minutes: Annotated[Optional[int], typer.Option("--safety-critical-duration", help="Critical glucose duration (minutes)")] = None,
    safety_predictor_uncertainty_gate_enabled: Annotated[Optional[bool], typer.Option("--safety-predictor-uncertainty-gate", help="Enable predictor uncertainty gate")] = None,
    safety_predictor_uncertainty_max_std_mgdl: Annotated[Optional[float], typer.Option("--safety-predictor-max-std", help="Max allowed predictor std (mg/dL) before fallback")] = None,
    safety_predictor_ood_gate_enabled: Annotated[Optional[bool], typer.Option("--safety-predictor-ood-gate", help="Enable predictor OOD gate")] = None,
    safety_predictor_ood_zscore_threshold: Annotated[Optional[float], typer.Option("--safety-predictor-ood-z", help="Predictor OOD z-score threshold")] = None,
    safety_predictor_ood_max_feature_fraction: Annotated[Optional[float], typer.Option("--safety-predictor-ood-feature-fraction", help="Max fraction of features allowed OOD")] = None,
):
    """One-line runner: results CSV + audit + PDF + baseline comparison."""
    console = Console()
    algorithm_instance = _load_algorithm_instance(algo, console)
    predictor = _load_predictor_service_from_path(predictor_path, console)

    patient_config: Union[str, Path]
    if patient_config_path:
        if not patient_config_path.is_file():
            console.print(f"[bold red]Error: Patient config file '{patient_config_path}' not found.[/bold red]")
            raise typer.Exit(code=1)
        patient_config = patient_config_path
    else:
        patient_config = patient_config_name

    safety_config = _build_safety_config_from_options(
        min_glucose=safety_min_glucose,
        max_glucose=safety_max_glucose,
        max_glucose_delta_per_5_min=safety_max_glucose_delta_per_5_min,
        hypoglycemia_threshold=safety_hypoglycemia_threshold,
        severe_hypoglycemia_threshold=safety_severe_hypoglycemia_threshold,
        hyperglycemia_threshold=safety_hyperglycemia_threshold,
        max_insulin_per_bolus=safety_max_insulin_per_bolus,
        glucose_rate_alarm=safety_glucose_rate_alarm,
        max_insulin_per_hour=safety_max_insulin_per_hour,
        max_iob=safety_max_iob,
        trend_stop=safety_trend_stop,
        hypo_cutoff=safety_hypo_cutoff,
        critical_glucose_threshold=safety_critical_glucose_threshold,
        critical_glucose_duration_minutes=safety_critical_glucose_duration_minutes,
        predictor_uncertainty_gate_enabled=safety_predictor_uncertainty_gate_enabled,
        predictor_uncertainty_max_std_mgdl=safety_predictor_uncertainty_max_std_mgdl,
        predictor_ood_gate_enabled=safety_predictor_ood_gate_enabled,
        predictor_ood_zscore_threshold=safety_predictor_ood_zscore_threshold,
        predictor_ood_max_feature_fraction=safety_predictor_ood_max_feature_fraction,
    )

    outputs = iints.run_full(
        algorithm=algorithm_instance,
        scenario=str(scenario_path) if scenario_path else None,
        patient_config=patient_config,
        duration_minutes=duration,
        time_step=time_step,
        seed=seed,
        output_dir=output_dir,
        safety_config=safety_config,
        predictor=predictor,
    )

    console.print("[green]Run complete.[/green]")
    if "results_csv" in outputs:
        console.print(f"Results CSV: {outputs['results_csv']}")
    if "report_pdf" in outputs:
        console.print(f"Report PDF: {outputs['report_pdf']}")
    if "audit" in outputs:
        console.print(f"Audit: {outputs['audit']}")
    if "baseline_files" in outputs:
        console.print(f"Baseline files: {outputs['baseline_files']}")
    if "run_metadata_path" in outputs:
        console.print(f"Run metadata: {outputs['run_metadata_path']}")
    if "run_manifest_path" in outputs:
        console.print(f"Run manifest: {outputs['run_manifest_path']}")
    if "profiling_path" in outputs:
        console.print(f"Profiling report: {outputs['profiling_path']}")
    if "run_manifest_signature" in outputs:
        console.print(f"Run manifest signature: {outputs['run_manifest_signature']}")
    if "output_dir" in outputs:
        _maybe_prepare_ai_artifacts(Path(outputs["output_dir"]), console)


@app.command(name="run-parallel")
def run_parallel(
    algo: Annotated[Path, typer.Option(help="Path to the algorithm Python file")],
    predictor_path: Annotated[Optional[Path], typer.Option("--predictor", help="Optional predictor checkpoint (.pt) for dual-guard forecasting")] = None,
    scenarios_dir: Annotated[Optional[Path], typer.Option(help="Directory with scenario JSON files")] = None,
    scenario_paths: Annotated[List[Path], typer.Option("--scenario-path", help="Scenario JSON path (repeatable)")] = [],
    patient_config_name: Annotated[str, typer.Option(help="Patient config name")] = "default_patient",
    patient_config_path: Annotated[Optional[Path], typer.Option(help="Patient config YAML path")] = None,
    patient_configs_dir: Annotated[Optional[Path], typer.Option(help="Directory of patient YAML configs")] = None,
    duration: Annotated[int, typer.Option(help="Simulation duration in minutes")] = 720,
    time_step: Annotated[int, typer.Option(help="Simulation time step in minutes")] = 5,
    output_dir: Annotated[Path, typer.Option(help="Root directory for batch outputs")] = Path("./results/batch"),
    max_workers: Annotated[Optional[int], typer.Option(help="Max parallel workers")] = None,
    seed: Annotated[Optional[int], typer.Option(help="Base seed for deterministic runs")] = None,
    compare_baselines: Annotated[bool, typer.Option(help="Run PID + standard pump baselines")] = False,
    export_audit: Annotated[bool, typer.Option(help="Export audit trails")] = False,
    generate_report: Annotated[bool, typer.Option(help="Generate PDF reports")] = False,
    safety_min_glucose: Annotated[Optional[float], typer.Option("--safety-min-glucose")] = None,
    safety_max_glucose: Annotated[Optional[float], typer.Option("--safety-max-glucose")] = None,
    safety_max_glucose_delta_per_5_min: Annotated[Optional[float], typer.Option("--safety-max-glucose-delta-per-5-min")] = None,
    safety_hypoglycemia_threshold: Annotated[Optional[float], typer.Option("--safety-hypo-threshold")] = None,
    safety_severe_hypoglycemia_threshold: Annotated[Optional[float], typer.Option("--safety-severe-hypo-threshold")] = None,
    safety_hyperglycemia_threshold: Annotated[Optional[float], typer.Option("--safety-hyper-threshold")] = None,
    safety_max_insulin_per_bolus: Annotated[Optional[float], typer.Option("--safety-max-bolus")] = None,
    safety_glucose_rate_alarm: Annotated[Optional[float], typer.Option("--safety-glucose-rate-alarm")] = None,
    safety_max_insulin_per_hour: Annotated[Optional[float], typer.Option("--safety-max-insulin-per-hour")] = None,
    safety_max_iob: Annotated[Optional[float], typer.Option("--safety-max-iob")] = None,
    safety_trend_stop: Annotated[Optional[float], typer.Option("--safety-trend-stop")] = None,
    safety_hypo_cutoff: Annotated[Optional[float], typer.Option("--safety-hypo-cutoff")] = None,
    safety_critical_glucose_threshold: Annotated[Optional[float], typer.Option("--safety-critical-glucose")] = None,
    safety_critical_glucose_duration_minutes: Annotated[Optional[int], typer.Option("--safety-critical-duration")] = None,
    safety_predictor_uncertainty_gate_enabled: Annotated[Optional[bool], typer.Option("--safety-predictor-uncertainty-gate")] = None,
    safety_predictor_uncertainty_max_std_mgdl: Annotated[Optional[float], typer.Option("--safety-predictor-max-std")] = None,
    safety_predictor_ood_gate_enabled: Annotated[Optional[bool], typer.Option("--safety-predictor-ood-gate")] = None,
    safety_predictor_ood_zscore_threshold: Annotated[Optional[float], typer.Option("--safety-predictor-ood-z")] = None,
    safety_predictor_ood_max_feature_fraction: Annotated[Optional[float], typer.Option("--safety-predictor-ood-feature-fraction")] = None,
):
    """Run many scenarios in parallel across CPU cores."""
    console = Console()
    base_seed = resolve_seed(seed)
    if predictor_path is not None:
        _load_predictor_service_from_path(predictor_path, console)
    if scenarios_dir is None and not scenario_paths:
        console.print("[bold red]Provide --scenarios-dir or at least one --scenario-path.[/bold red]")
        raise typer.Exit(code=1)

    scenarios: List[Path] = []
    if scenarios_dir:
        if not scenarios_dir.is_dir():
            console.print(f"[bold red]Scenarios directory not found: {scenarios_dir}[/bold red]")
            raise typer.Exit(code=1)
        scenarios.extend(sorted(scenarios_dir.glob("*.json")))
    scenarios.extend(scenario_paths)
    scenarios = [path for path in scenarios if path.is_file()]
    if not scenarios:
        console.print("[bold red]No scenario JSON files found.[/bold red]")
        raise typer.Exit(code=1)

    patient_configs: List[Union[str, Path]] = []
    patient_labels: List[str] = []
    if patient_configs_dir:
        if not patient_configs_dir.is_dir():
            console.print(f"[bold red]Patient config directory not found: {patient_configs_dir}[/bold red]")
            raise typer.Exit(code=1)
        for path in sorted(patient_configs_dir.glob("*.yaml")):
            patient_configs.append(path)
            patient_labels.append(path.stem)
    elif patient_config_path:
        if not patient_config_path.is_file():
            console.print(f"[bold red]Patient config file not found: {patient_config_path}[/bold red]")
            raise typer.Exit(code=1)
        patient_configs.append(patient_config_path)
        patient_labels.append(patient_config_path.stem)
    else:
        patient_configs.append(patient_config_name)
        patient_labels.append(patient_config_name)

    safety_overrides = {
        "min_glucose": safety_min_glucose,
        "max_glucose": safety_max_glucose,
        "max_glucose_delta_per_5_min": safety_max_glucose_delta_per_5_min,
        "hypoglycemia_threshold": safety_hypoglycemia_threshold,
        "severe_hypoglycemia_threshold": safety_severe_hypoglycemia_threshold,
        "hyperglycemia_threshold": safety_hyperglycemia_threshold,
        "max_insulin_per_bolus": safety_max_insulin_per_bolus,
        "glucose_rate_alarm": safety_glucose_rate_alarm,
        "max_insulin_per_hour": safety_max_insulin_per_hour,
        "max_iob": safety_max_iob,
        "trend_stop": safety_trend_stop,
        "hypo_cutoff": safety_hypo_cutoff,
        "critical_glucose_threshold": safety_critical_glucose_threshold,
        "critical_glucose_duration_minutes": safety_critical_glucose_duration_minutes,
        "predictor_uncertainty_gate_enabled": safety_predictor_uncertainty_gate_enabled,
        "predictor_uncertainty_max_std_mgdl": safety_predictor_uncertainty_max_std_mgdl,
        "predictor_ood_gate_enabled": safety_predictor_ood_gate_enabled,
        "predictor_ood_zscore_threshold": safety_predictor_ood_zscore_threshold,
        "predictor_ood_max_feature_fraction": safety_predictor_ood_max_feature_fraction,
    }
    safety_overrides = {k: v for k, v in safety_overrides.items() if v is not None}

    output_dir.mkdir(parents=True, exist_ok=True)
    jobs: List[Dict[str, Any]] = []
    idx = 0
    for scenario in scenarios:
        for patient_config, patient_label in zip(patient_configs, patient_labels):
            job_seed = base_seed + idx
            run_output_dir = output_dir / f"{scenario.stem}__{patient_label}"
            jobs.append(
                {
                    "algo": str(algo),
                    "scenario_path": str(scenario),
                    "patient_config": patient_config,
                    "patient_label": patient_label,
                    "output_dir": str(run_output_dir),
                    "duration_minutes": duration,
                    "time_step": time_step,
                    "seed": job_seed,
                    "compare_baselines": compare_baselines,
                    "export_audit": export_audit,
                    "generate_report": generate_report,
                    "safety_overrides": safety_overrides,
                    "predictor_path": str(predictor_path) if predictor_path else None,
                }
            )
            idx += 1

    console.print(f"Launching {len(jobs)} parallel jobs...")
    results: List[Dict[str, Any]] = []
    with concurrent.futures.ProcessPoolExecutor(max_workers=max_workers) as executor:
        future_map = {executor.submit(_run_parallel_job, job): job for job in jobs}
        for future in concurrent.futures.as_completed(future_map):
            job = future_map[future]
            try:
                result = future.result()
            except Exception as exc:
                result = {
                    "scenario": Path(job["scenario_path"]).stem,
                    "patient": job["patient_label"],
                    "output_dir": job["output_dir"],
                    "results_csv": "",
                    "report_pdf": "",
                    "terminated_early": False,
                    "total_violations": 0,
                    "error": str(exc),
                }
            results.append(result)

    summary_df = pd.DataFrame(results)
    summary_path = output_dir / "batch_summary.csv"
    summary_df.to_csv(summary_path, index=False)
    console.print(f"[green]Batch summary saved:[/green] {summary_path}")


@app.command(name="scorecard")
def scorecard(
    algo: Annotated[Path, typer.Option(help="Path to the algorithm Python file")],
    profile: Annotated[str, typer.Option(help="Validation profile id")] = "research_default",
    predictor_path: Annotated[Optional[Path], typer.Option("--predictor", help="Optional predictor checkpoint (.pt)")] = None,
    presets_csv: Annotated[Optional[str], typer.Option(help="Comma-separated preset names (default: all bundled presets)")] = None,
    output_dir: Annotated[Path, typer.Option(help="Output directory for scorecard artifacts")] = Path("results/scorecard"),
    seed: Annotated[Optional[int], typer.Option(help="Base random seed")] = 42,
):
    """
    Run a scenario bank and generate a validation scorecard.
    """
    console = Console()
    algorithm_template = _load_algorithm_instance(algo, console)
    predictor = _load_predictor_service_from_path(predictor_path, console)
    try:
        profiles = load_validation_profiles()
    except Exception as exc:
        console.print(f"[bold red]Could not load validation profiles: {exc}[/bold red]")
        raise typer.Exit(code=1)
    selected_profile = profiles.get(profile)
    if selected_profile is None:
        console.print(f"[bold red]Unknown profile '{profile}'.[/bold red]")
        raise typer.Exit(code=1)

    all_presets = _load_presets()
    selected_names: Optional[set[str]] = None
    if presets_csv:
        selected_names = {name.strip() for name in presets_csv.split(",") if name.strip()}
    presets_to_run = [
        preset for preset in all_presets
        if selected_names is None or preset.get("name") in selected_names
    ]
    if not presets_to_run:
        console.print("[bold red]No presets selected for scorecard.[/bold red]")
        raise typer.Exit(code=1)

    output_dir.mkdir(parents=True, exist_ok=True)
    seed_base = resolve_seed(seed)
    rows: List[Dict[str, Any]] = []
    for idx, preset in enumerate(presets_to_run):
        preset_name = str(preset.get("name", f"preset_{idx}"))
        scenario_payload = preset.get("scenario")
        if not isinstance(scenario_payload, dict):
            console.print(f"[yellow]Skipping {preset_name}: no scenario payload[/yellow]")
            continue

        run_output_dir = output_dir / preset_name
        algorithm_instance = algorithm_template.__class__()
        outputs = iints.run_simulation(
            algorithm=algorithm_instance,
            scenario=scenario_payload,
            patient_config=str(preset.get("patient_config", "default_patient")),
            duration_minutes=int(preset.get("duration_minutes", 720)),
            time_step=int(preset.get("time_step_minutes", 5)),
            seed=seed_base + idx,
            output_dir=run_output_dir,
            compare_baselines=False,
            export_audit=True,
            generate_report=False,
            predictor=predictor,
        )
        results_df = outputs["results"]
        safety_report = outputs.get("safety_report", {})
        validation = evaluate_run(
            results_df,
            profile=selected_profile,
            safety_report=safety_report,
            duration_minutes=int(preset.get("duration_minutes", 720)),
        )

        rows.append(
            {
                "preset": preset_name,
                "passed": validation.passed,
                "required_checks_passed": validation.required_checks_passed,
                "required_checks_total": validation.required_checks_total,
                "validation_score": validation.score,
                "tir_70_180": validation.metrics.get("tir_70_180"),
                "tir_below_70": validation.metrics.get("tir_below_70"),
                "tir_below_54": validation.metrics.get("tir_below_54"),
                "cv": validation.metrics.get("cv"),
                "safety_index": validation.metrics.get("safety_index"),
                "supervisor_interventions_per_hour": validation.metrics.get("supervisor_interventions_per_hour"),
                "output_dir": str(run_output_dir),
            }
        )

        (run_output_dir / "validation_report.json").write_text(json.dumps(validation.to_dict(), indent=2))

    if not rows:
        console.print("[bold red]Scorecard produced no rows.[/bold red]")
        raise typer.Exit(code=1)

    scorecard_df = pd.DataFrame(rows).sort_values(by=["passed", "validation_score"], ascending=[False, False])
    scorecard_csv = output_dir / "scorecard.csv"
    scorecard_json = output_dir / "scorecard.json"
    scorecard_df.to_csv(scorecard_csv, index=False)
    scorecard_json.write_text(json.dumps(rows, indent=2))

    table = Table(title=f"Scenario Bank Scorecard ({selected_profile.profile_id})")
    table.add_column("Preset", style="cyan")
    table.add_column("Status", style="bold")
    table.add_column("Checks", justify="right")
    table.add_column("Score", justify="right")
    table.add_column("TIR", justify="right")
    table.add_column("T<70", justify="right")
    for row in rows:
        table.add_row(
            str(row["preset"]),
            "[green]PASS[/green]" if bool(row["passed"]) else "[red]FAIL[/red]",
            f"{int(row['required_checks_passed'])}/{int(row['required_checks_total'])}",
            f"{float(row['validation_score']):.1f}",
            f"{float(row['tir_70_180']):.1f}",
            f"{float(row['tir_below_70']):.1f}",
        )
    console.print(table)
    console.print(f"[green]Scorecard CSV:[/green] {scorecard_csv}")
    console.print(f"[green]Scorecard JSON:[/green] {scorecard_json}")

@app.command()
def poster(
    run_dir: Annotated[
        List[Path],
        typer.Option(
            "--run-dir",
            help="Run bundle directory containing results.csv. Repeat up to three times.",
        ),
    ] = [],
    label: Annotated[
        List[str],
        typer.Option(
            "--label",
            help="Optional poster label aligned to each --run-dir (for example: Normal Run, Meal Stress Test, Supervisor Override).",
        ),
    ] = [],
    output_path: Annotated[
        Path,
        typer.Option(help="PNG output path for the poster graphic."),
    ] = Path("./results/posters/iints_results_poster.png"),
    summary_output_path: Annotated[
        Optional[Path],
        typer.Option(help="Optional JSON sidecar summary path."),
    ] = None,
    title: Annotated[
        str,
        typer.Option(help="Main poster headline."),
    ] = "288 Decisions. Every Day. We Test Them All.",
    subtitle: Annotated[
        str,
        typer.Option(help="Supporting poster subtitle."),
    ] = "Three IINTS-AF scenarios showing control, stress handling, and supervisor protection.",
    results_root: Annotated[
        Path,
        typer.Option(help="Root folder used when no --run-dir values are supplied."),
    ] = Path("./results"),
):
    """Generate a poster-style PNG from one to three IINTS run bundles."""
    console = Console()
    generate_results_poster = _require_reports_feature(
        console,
        "iints.analysis.poster",
        "generate_results_poster",
        "Run poster generation",
    )
    try:
        outputs = generate_results_poster(
            run_dirs=run_dir,
            labels=label,
            output_path=output_path,
            summary_output_path=summary_output_path,
            poster_title=title,
            subtitle=subtitle,
            results_root=results_root,
        )
    except Exception as exc:
        console.print(f"[bold red]Error:[/bold red] {exc}")
        raise typer.Exit(code=1)

    console.print(
        Panel(
            "\n".join(
                [
                    f"Poster PNG: {outputs['poster_png']}",
                    f"Summary JSON: {outputs['summary_json']}",
                ]
            ),
            title="IINTS Poster Export",
            border_style="cyan",
        )
    )
    console.print(
        "[green]Tip:[/green] Use "
        "`--label \"Normal Run\" --label \"Meal Stress Test\" --label \"Supervisor Override\"` "
        "to tell a clear jury story."
    )


@app.command(name="demo-booth")
def demo_booth(
    output_dir: Annotated[
        Path,
        typer.Option(help="Directory where the fair-ready demo bundle should be written."),
    ] = Path("./results/booth_demo"),
    duration: Annotated[
        int,
        typer.Option(help="Simulation duration in minutes for each booth scenario."),
    ] = 360,
    time_step: Annotated[
        int,
        typer.Option(help="Simulation step size in minutes."),
    ] = 5,
    seed: Annotated[
        int,
        typer.Option(help="Deterministic random seed."),
    ] = 42,
    prepare_ai: Annotated[
        bool,
        typer.Option(
            "--prepare-ai/--no-prepare-ai",
            help="Prepare AI-ready artifacts for the Supervisor Override run.",
        ),
    ] = True,
) -> None:
    """Build a full expo/jury demo bundle with runs, poster, and talk track."""
    console = Console()
    try:
        outputs = build_booth_demo(
            output_dir=output_dir,
            duration_minutes=duration,
            time_step=time_step,
            seed=seed,
            prepare_ai=prepare_ai,
        )
    except Exception as exc:
        console.print(f"[bold red]Booth demo failed:[/bold red] {exc}")
        raise typer.Exit(code=1)

    table = Table(title="IINTS Booth Demo")
    table.add_column("Artifact", style="cyan")
    table.add_column("Path", overflow="fold")
    for key in [
        "poster_png",
        "poster_summary_json",
        "demo_summary_json",
        "jury_talk_track",
        "live_demo_script",
        "run_commands",
        "showcase_study_summary_json",
        "showcase_study_poster_png",
        "showcase_research_sync_md",
        "showcase_explanation_panel_md",
        "01_normal_run_dir",
        "02_meal_stress_test_dir",
        "03_supervisor_override_dir",
        "mdmp_cert",
    ]:
        if key in outputs:
            table.add_row(key, outputs[key])
    console.print(table)
    if "jury_talk_track" in outputs:
        jury_track_name = Path(str(outputs["jury_talk_track"])).name
        console.print(f"[green]Jury talk track:[/green] {jury_track_name} ({outputs['jury_talk_track']})")
    if "live_demo_script" in outputs:
        live_script_name = Path(str(outputs["live_demo_script"])).name
        console.print(f"[green]Live booth script:[/green] {live_script_name} ({outputs['live_demo_script']})")
    if "showcase_research_sync_md" in outputs:
        showcase_sync_name = Path(str(outputs["showcase_research_sync_md"])).name
        console.print(f"[green]Showcase research sync:[/green] {showcase_sync_name} ({outputs['showcase_research_sync_md']})")
    if "showcase_explanation_panel_md" in outputs:
        explanation_name = Path(str(outputs["showcase_explanation_panel_md"])).name
        console.print(
            f"[green]Showcase explanation panel:[/green] {explanation_name} ({outputs['showcase_explanation_panel_md']})"
        )
    console.print(
        "[green]Next:[/green] open the poster and use the jury talk track to walk people through the story."
    )


@app.command(name="demo-export")
def demo_export(
    output_dir: Annotated[
        Path,
        typer.Option(help="Directory where the bundled live stage demo files should be written."),
    ] = Path("./iints_demo"),
    overwrite: Annotated[
        bool,
        typer.Option("--overwrite/--no-overwrite", help="Allow overwriting exported demo files."),
    ] = False,
) -> None:
    """Export the showable live demo code from the installed SDK."""
    console = Console()
    try:
        outputs = export_live_stage_demo(output_dir=output_dir, overwrite=overwrite)
    except FileExistsError as exc:
        console.print(f"[bold red]Demo export stopped:[/bold red] {exc}")
        raise typer.Exit(code=1)
    except Exception as exc:
        console.print(f"[bold red]Demo export failed:[/bold red] {exc}")
        raise typer.Exit(code=1)

    table = Table(title="IINTS Demo Export")
    table.add_column("Artifact", style="cyan")
    table.add_column("Path", overflow="fold")
    table.add_row("script", outputs["script_path"])
    table.add_row("notes", outputs["notes_path"])
    console.print(table)
    console.print(
        "[green]Next:[/green] open `07_live_stage_demo.py`, explain the visible SDK calls, then run `python 07_live_stage_demo.py`."
    )


@app.command()
def report(
    results_csv: Annotated[Path, typer.Option(help="Path to a simulation results CSV")],
    output_path: Annotated[Path, typer.Option(help="Output PDF path")] = Path("./results/clinical_report.pdf"),
    safety_report_path: Annotated[Optional[Path], typer.Option(help="Optional safety report JSON path")] = None,
    audit_output_dir: Annotated[Optional[Path], typer.Option(help="Optional audit output directory")] = None,
    bundle_dir: Annotated[Optional[Path], typer.Option(help="If set, write PDF + plots + audit into this folder")] = None,
):
    """Generate a clinical PDF report (and optional audit summary) from a results CSV."""
    console = Console()
    if not results_csv.is_file():
        console.print(f"[bold red]Error: Results file '{results_csv}' not found.[/bold red]")
        raise typer.Exit(code=1)

    results_df = pd.read_csv(results_csv)
    safety_report: Dict[str, Any] = {}
    if safety_report_path:
        if not safety_report_path.is_file():
            console.print(f"[bold red]Error: Safety report file '{safety_report_path}' not found.[/bold red]")
            raise typer.Exit(code=1)
        safety_report = json.loads(safety_report_path.read_text())

    if bundle_dir:
        bundle_dir.mkdir(parents=True, exist_ok=True)
        output_path = bundle_dir / "clinical_report.pdf"
        audit_output_dir = bundle_dir / "audit"
        plots_dir = bundle_dir / "plots"
        _require_reports_feature(console, "iints.analysis.reporting", "ClinicalReportGenerator", "Clinical PDF reporting")
        generator = iints.ClinicalReportGenerator()
        generator.export_plots(results_df, str(plots_dir))
    output_path.parent.mkdir(parents=True, exist_ok=True)
    _require_reports_feature(console, "iints.analysis.reporting", "ClinicalReportGenerator", "Clinical PDF reporting")
    iints.generate_report(results_df, str(output_path), safety_report)
    console.print(f"PDF report saved to: [link=file://{output_path}]{output_path}[/link]")

    if audit_output_dir:
        audit_output_dir.mkdir(parents=True, exist_ok=True)
        audit_columns = [
            "time_minutes",
            "glucose_actual_mgdl",
            "glucose_to_algo_mgdl",
            "algo_recommended_insulin_units",
            "delivered_insulin_units",
            "safety_reason",
            "safety_triggered",
            "supervisor_latency_ms",
        ]
        available = [c for c in audit_columns if c in results_df.columns]
        audit_df = results_df[available].copy()

        jsonl_path = audit_output_dir / "audit_trail.jsonl"
        csv_path = audit_output_dir / "audit_trail.csv"
        summary_path = audit_output_dir / "audit_summary.json"

        audit_df.to_json(jsonl_path, orient="records", lines=True)
        audit_df.to_csv(csv_path, index=False)

        overrides = audit_df[audit_df.get("safety_triggered", False) == True] if "safety_triggered" in audit_df.columns else audit_df.iloc[0:0]
        reasons = overrides["safety_reason"].value_counts().to_dict() if "safety_reason" in overrides.columns else {}
        summary = {
            "total_steps": int(len(audit_df)),
            "total_overrides": int(len(overrides)),
            "top_reasons": reasons,
        }
        summary_path.write_text(json.dumps(summary, indent=2))
        console.print(f"Audit exports saved to: {audit_output_dir}")


@app.command()
def validate(
    scenario_path: Annotated[Path, typer.Option(help="Path to a scenario JSON file")],
    patient_config_path: Annotated[Optional[Path], typer.Option(help="Optional patient config YAML to validate")] = None,
):
    """Validate a scenario JSON for out-of-range values and missing keys."""
    console = Console()
    if not scenario_path.is_file():
        console.print(f"[bold red]Error: Scenario file '{scenario_path}' not found.[/bold red]")
        raise typer.Exit(code=1)

    try:
        scenario = json.loads(scenario_path.read_text())
        scenario_model = validate_scenario_dict(scenario)
        for warning in scenario_warnings(scenario_model):
            console.print(f"[yellow]Warning:[/yellow] {warning}")
    except json.JSONDecodeError as e:
        console.print(f"[bold red]Error: Invalid JSON - {e}[/bold red]")
        raise typer.Exit(code=1)
    except ValidationError as e:
        console.print("[bold red]Scenario validation failed:[/bold red]")
        for line in format_validation_error(e):
            console.print(f"- {line}")
        raise typer.Exit(code=1)

    if patient_config_path:
        if not patient_config_path.is_file():
            console.print(f"[bold red]Error: Patient config '{patient_config_path}' not found.[/bold red]")
            raise typer.Exit(code=1)
        try:
            patient_config = yaml.safe_load(patient_config_path.read_text())
            validate_patient_config_dict(patient_config)
        except yaml.YAMLError as e:
            console.print(f"[bold red]Error: Invalid YAML - {e}[/bold red]")
            raise typer.Exit(code=1)
        except ValidationError as e:
            console.print("[bold red]Patient config validation failed:[/bold red]")
            for line in format_validation_error(e):
                console.print(f"- {line}")
            raise typer.Exit(code=1)

    console.print("[green]Scenario validation passed.[/green]")


@data_app.command(name="list")
def data_list():
    """List official datasets and access requirements."""
    console = Console()
    datasets = load_dataset_registry()
    table = Table(title="IINTS-AF Official Datasets", show_header=True, header_style="bold cyan")
    table.add_column("ID", style="green")
    table.add_column("Name", style="white")
    table.add_column("Access", style="magenta")
    table.add_column("Source", style="yellow")
    for entry in datasets:
        table.add_row(
            entry.get("id", ""),
            entry.get("name", ""),
            entry.get("access", ""),
            entry.get("source", ""),
        )
    console.print(table)


@data_app.command(name="info")
def data_info(
    dataset_id: Annotated[str, typer.Argument(help="Dataset id (see `iints data list`)")],
):
    """Show metadata and access info for a dataset."""
    console = Console()
    try:
        dataset = get_dataset(dataset_id)
    except DatasetRegistryError as e:
        console.print(f"[bold red]{e}[/bold red]")
        raise typer.Exit(code=1)
    console.print_json(json.dumps(dataset, indent=2))
    citation = dataset.get("citation", {})
    if citation:
        text = citation.get("text")
        bibtex = citation.get("bibtex")
        if text:
            console.print("\n[bold]Citation (text)[/bold]")
            console.print(text)
        if bibtex:
            console.print("\n[bold]Citation (BibTeX)[/bold]")
            console.print(bibtex)


@data_app.command(name="cite")
def data_cite(
    dataset_id: Annotated[str, typer.Argument(help="Dataset id (see `iints data list`)")],
):
    """Print BibTeX citation for a dataset."""
    console = Console()
    try:
        dataset = get_dataset(dataset_id)
    except DatasetRegistryError as e:
        console.print(f"[bold red]{e}[/bold red]")
        raise typer.Exit(code=1)
    citation = dataset.get("citation", {})
    bibtex = citation.get("bibtex")
    text = citation.get("text")
    if bibtex:
        console.print(bibtex)
        return
    if text:
        console.print(text)
        return
    console.print("[yellow]No citation available for this dataset.[/yellow]")


@data_app.command(name="fetch")
def data_fetch(
    dataset_id: Annotated[str, typer.Argument(help="Dataset id (see `iints data list`)")],
    output_dir: Annotated[Optional[Path], typer.Option(help="Output directory (default: data_packs/official/<id>)")] = None,
    extract: Annotated[bool, typer.Option(help="Extract zip files if present")] = True,
    verify: Annotated[bool, typer.Option(help="Verify pinned SHA-256 hashes and emit SHA256SUMS.txt. Public sources without published hashes now require --no-verify.")] = True,
):
    """Download a dataset (public-download only)."""
    console = Console()
    try:
        dataset = get_dataset(dataset_id)
    except DatasetRegistryError as e:
        console.print(f"[bold red]{e}[/bold red]")
        raise typer.Exit(code=1)

    if output_dir is None:
        output_dir = Path("data_packs") / "official" / dataset_id
    output_dir = output_dir.expanduser()
    if not output_dir.is_absolute():
        output_dir = (Path.cwd() / output_dir).resolve()
    else:
        output_dir = output_dir.resolve()

    access = dataset.get("access", "manual")
    landing = dataset.get("landing_page", "")
    if access in {"request", "manual"}:
        console.print("[yellow]Manual download required for this dataset.[/yellow]")
        if landing:
            console.print(f"Source: {landing}")
        console.print("After downloading, place files in:")
        console.print(f"  {output_dir}")
        return

    try:
        downloaded = fetch_dataset(dataset_id, output_dir=output_dir, extract=extract, verify=verify)
        console.print(f"[green]Downloaded {len(downloaded)} file(s) to {output_dir}[/green]")
    except DatasetFetchError as e:
        console.print(f"[bold red]{e}[/bold red]")
        raise typer.Exit(code=1)


def _resolve_secret_option(
    *,
    console: Console,
    label: str,
    direct_value: Optional[str],
    env_name: Optional[str],
    file_path: Optional[Path],
) -> Optional[str]:
    configured_sources = [
        source
        for source, value in (
            ("direct", direct_value),
            ("env", env_name),
            ("file", file_path),
        )
        if value
    ]
    if len(configured_sources) > 1:
        raise typer.BadParameter(
            f"Choose only one source for {label}: direct value, --{label.replace('_', '-')}-env, or --{label.replace('_', '-')}-file."
        )
    if direct_value:
        console.print(
            f"[yellow]Warning:[/yellow] passing {label} directly on the command line can leak into shell history or process lists. "
            f"Prefer --{label.replace('_', '-')}-env or --{label.replace('_', '-')}-file."
        )
        return direct_value
    if env_name:
        value = os.getenv(env_name, "").strip()
        if not value:
            raise typer.BadParameter(f"Environment variable '{env_name}' is not set or is empty.")
        return value
    if file_path:
        resolved_path = file_path.expanduser().resolve()
        if not resolved_path.is_file():
            raise typer.BadParameter(f"Secret file does not exist: {resolved_path}")
        value = resolved_path.read_text(encoding="utf-8").strip()
        if not value:
            raise typer.BadParameter(f"Secret file is empty: {resolved_path}")
        return value
    return None


def _build_data_contract_template() -> Dict[str, Any]:
    return {
        "version": 1,
        "streams": [
            {
                "name": "PatientHealth",
                "source": "sdk.iints_af.v1",
                "security": "PII_ENCRYPTED",
                "metadata": {
                    "required_columns": ["timestamp", "glucose"],
                    "column_types": {
                        "glucose": "float",
                    },
                    "ranges": {
                        "glucose": {"min": 40, "max": 400},
                    },
                    "unit_conversions": {
                        "glucose": {"from": "mmol/L", "to": "mg/dL"},
                    },
                },
            }
        ],
        "processes": [
            {
                "name": "GlucoseData",
                "input_stream": "PatientHealth.glucose",
                "features": [
                    {
                        "name": "rolling_avg_15m",
                        "operation": "moving_average",
                        "source": "PatientHealth.glucose",
                        "window": "15m",
                    }
                ],
                "labels": [
                    {
                        "name": "hyper_event",
                        "expression": "glucose > 180",
                        "classes": ["Critical", "Normal"],
                    }
                ],
                "validations": [
                    {
                        "expression": "glucose is not null and glucose > 20",
                        "on_fail": "DISCARD_AND_LOG",
                    }
                ],
            }
        ],
    }


def _build_mdmp_core_contract_template() -> Dict[str, Any]:
    return {
        "schema": {
            "name": "cgm_dataset",
            "version": "1.0",
            "industry": "health",
            "columns": [
                {"name": "timestamp", "type": "datetime", "required": True},
                {"name": "glucose", "type": "float", "unit": "mg/dL", "bounds": [40, 400], "required": True},
            ],
        },
        "consent": {
            "ai_training_allowed": True,
            "jurisdiction": "GDPR",
            "anonymized": True,
        },
    }


@data_app.command(name="contract-template", hidden=True, deprecated=True)
def data_contract_template(
    output_path: Annotated[Path, typer.Option(help="Where to write the starter contract YAML")] = Path("data_contract.yaml"),
):
    """Write a starter data contract template for model-ready validation."""
    console = Console()
    backend = active_mdmp_backend()
    template = _build_mdmp_core_contract_template() if backend == "mdmp_core" else _build_data_contract_template()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(yaml.safe_dump(template, sort_keys=False))
    console.print(f"[green]Contract template written:[/green] {output_path}")
    console.print(f"[cyan]Template backend:[/cyan] {backend}")


@data_app.command(name="certify-template")
def data_certify_template(
    output_path: Annotated[Path, typer.Option(help="Where to write the starter certification contract YAML")] = Path("data_contract.yaml"),
):
    """Write a starter IINTS data-certification contract."""
    data_contract_template(output_path=output_path)


@data_app.command(name="contract-run", hidden=True, deprecated=True)
def data_contract_run(
    contract_path: Annotated[Path, typer.Argument(help="Path to contract YAML")],
    input_csv: Annotated[Path, typer.Argument(help="Path to input CSV")],
    output_json: Annotated[Optional[Path], typer.Option(help="Optional output report JSON path")] = None,
    apply_builtin_transforms: Annotated[bool, typer.Option(help="Apply built-in unit conversion transforms from the contract")] = True,
    fail_on_noncompliant: Annotated[bool, typer.Option(help="Exit code 1 when compliance checks fail")] = False,
    min_mdmp_grade: Annotated[
        Optional[str],
        typer.Option(help="Optional MDMP grade gate (draft, research_grade, clinical_grade)"),
    ] = None,
):
    """Validate a dataset against a model-ready contract and compute compliance score."""
    console = Console()
    if not contract_path.is_file():
        console.print(f"[bold red]Contract file not found: {contract_path}[/bold red]")
        raise typer.Exit(code=1)
    if not input_csv.is_file():
        console.print(f"[bold red]Input CSV not found: {input_csv}[/bold red]")
        raise typer.Exit(code=1)

    try:
        contract = load_mdmp_contract(contract_path)
        df = pd.read_csv(input_csv)
        report = run_mdmp_validation(
            contract,
            df,
            apply_builtin_transforms=apply_builtin_transforms,
        )
    except Exception as exc:
        console.print(f"[bold red]Contract runner failed: {exc}[/bold red]")
        raise typer.Exit(code=1)

    summary = Table(title="Data Contract Compliance")
    summary.add_column("Field", style="cyan")
    summary.add_column("Value")
    summary.add_row("Rows", str(report.row_count))
    summary.add_row("Compliance", f"{report.compliance_score:.2f}%")
    summary.add_row("Status", "[green]PASS[/green]" if report.is_compliant else "[red]FAIL[/red]")
    summary.add_row("Backend", active_mdmp_backend())
    summary.add_row("MDMP grade", report.mdmp_grade)
    summary.add_row("MDMP protocol", report.mdmp_protocol_version)
    summary.add_row(
        "Certified",
        "yes" if report.certified_for_medical_research else "no",
    )
    summary.add_row("Contract fingerprint", report.contract_fingerprint_sha256[:16] + "...")
    summary.add_row("Dataset fingerprint", report.dataset_fingerprint_sha256[:16] + "...")
    console.print(summary)

    checks_table = Table(title="Checks")
    checks_table.add_column("Check", style="green")
    checks_table.add_column("Passed")
    checks_table.add_column("Failed rows", justify="right")
    checks_table.add_column("Detail")
    for check in report.checks:
        checks_table.add_row(
            check.name,
            "[green]yes[/green]" if check.passed else "[red]no[/red]",
            str(check.failed_rows),
            check.detail,
        )
    console.print(checks_table)

    if output_json is not None:
        output_json.parent.mkdir(parents=True, exist_ok=True)
        output_json.write_text(json.dumps(report.to_dict(), indent=2))
        console.print(f"[green]Contract report written:[/green] {output_json}")

    if min_mdmp_grade is not None:
        normalized = min_mdmp_grade.strip().lower()
        if normalized not in MDMP_GRADE_ORDER:
            allowed = ", ".join(MDMP_GRADE_ORDER)
            console.print(f"[bold red]Invalid --min-mdmp-grade value: {min_mdmp_grade}. Use one of: {allowed}[/bold red]")
            raise typer.Exit(code=1)
        if not mdmp_grade_meets_minimum(report.mdmp_grade, normalized):
            console.print(
                f"[bold red]MDMP gate failed:[/bold red] got {report.mdmp_grade}, requires at least {normalized}"
            )
            raise typer.Exit(code=1)

    if fail_on_noncompliant and not report.is_compliant:
        raise typer.Exit(code=1)


@data_app.command(name="certify")
def data_certify(
    contract_path: Annotated[Path, typer.Argument(help="Path to certification contract YAML")],
    input_csv: Annotated[Path, typer.Argument(help="Path to input CSV")],
    output_json: Annotated[Optional[Path], typer.Option(help="Optional output report JSON path")] = None,
    apply_builtin_transforms: Annotated[bool, typer.Option(help="Apply built-in unit conversion transforms from the contract")] = True,
    fail_on_noncompliant: Annotated[bool, typer.Option(help="Exit code 1 when compliance checks fail")] = False,
    min_mdmp_grade: Annotated[
        Optional[str],
        typer.Option(help="Optional certification grade gate (draft, research_grade, clinical_grade, ai_ready)"),
    ] = None,
):
    """Certify a dataset against an IINTS data contract and compute its trust grade."""
    data_contract_run(
        contract_path=contract_path,
        input_csv=input_csv,
        output_json=output_json,
        apply_builtin_transforms=apply_builtin_transforms,
        fail_on_noncompliant=fail_on_noncompliant,
        min_mdmp_grade=min_mdmp_grade,
    )


@data_app.command(name="mdmp-visualizer", hidden=True, deprecated=True)
def data_mdmp_visualizer(
    report_json: Annotated[Path, typer.Argument(help="Path to contract-run JSON report")],
    output_html: Annotated[Path, typer.Option(help="Output HTML path")] = Path("results/mdmp_dashboard.html"),
    title: Annotated[str, typer.Option(help="Dashboard title")] = "IINTS MDMP Certification Dashboard",
):
    """Build a single-file interactive MDMP certification dashboard."""
    console = Console()

    if not report_json.is_file():
        console.print(f"[bold red]Report JSON not found: {report_json}[/bold red]")
        raise typer.Exit(code=1)

    try:
        payload = json.loads(report_json.read_text())
        html_text = build_mdmp_dashboard_html(payload, title=title)
    except Exception as exc:
        console.print(f"[bold red]Could not build MDMP visualizer: {exc}[/bold red]")
        raise typer.Exit(code=1)

    output_html.parent.mkdir(parents=True, exist_ok=True)
    output_html.write_text(html_text)
    console.print(f"[green]MDMP dashboard written:[/green] {output_html}")


@data_app.command(name="certify-visualizer")
def data_certify_visualizer(
    report_json: Annotated[Path, typer.Argument(help="Path to certification report JSON")],
    output_html: Annotated[Path, typer.Option(help="Output HTML path")] = Path("results/mdmp_dashboard.html"),
    title: Annotated[str, typer.Option(help="Dashboard title")] = "IINTS Data Certification Dashboard",
):
    """Render a single-file dashboard from a certification report."""
    data_mdmp_visualizer(report_json=report_json, output_html=output_html, title=title)


@data_app.command(name="corrupt-for-study")
def data_corrupt_for_study(
    input_csv: Annotated[Path, typer.Argument(help="Source CSV that will be deliberately corrupted for ablation studies")],
    output_csv: Annotated[Path, typer.Option(help="Output CSV path for the corrupted dataset")] = Path("results/corrupted_study.csv"),
    mode: Annotated[
        List[str],
        typer.Option("--mode", help="Corruption mode to apply. Repeat --mode for multiple operators."),
    ] = ["timestamp_shift"],
    manifest_output: Annotated[Optional[Path], typer.Option(help="Optional corruption manifest JSON path")] = None,
    seed: Annotated[int, typer.Option(help="Random seed for deterministic corruption")] = 42,
    timestamp_shift_minutes: Annotated[int, typer.Option(help="Minutes to shift timestamps for the timestamp_shift mode")] = 60,
    missing_fraction: Annotated[float, typer.Option(help="Fraction of rows to remove for missing_block")] = 0.10,
    duplicate_fraction: Annotated[float, typer.Option(help="Fraction of rows to duplicate for duplicate_rows")] = 0.05,
    spike_fraction: Annotated[float, typer.Option(help="Fraction of glucose rows to spike for glucose_spikes")] = 0.03,
    spike_magnitude_mgdl: Annotated[float, typer.Option(help="Spike magnitude in mg/dL for glucose_spikes")] = 60.0,
) -> None:
    """Create a controlled corrupted dataset so certified-vs-uncertified claims can be tested scientifically."""
    console = Console()
    try:
        outputs = write_corrupted_study_csv(
            input_csv,
            output_csv=output_csv,
            modes=mode,
            manifest_output=manifest_output,
            seed=seed,
            timestamp_shift_minutes=timestamp_shift_minutes,
            missing_fraction=missing_fraction,
            duplicate_fraction=duplicate_fraction,
            spike_fraction=spike_fraction,
            spike_magnitude_mgdl=spike_magnitude_mgdl,
        )
    except Exception as exc:
        console.print(f"[bold red]Could not generate corrupted study dataset: {exc}[/bold red]")
        raise typer.Exit(code=1)

    table = Table(title="IINTS Study Corruption")
    table.add_column("Artifact", style="cyan")
    table.add_column("Path", overflow="fold")
    table.add_row("Corrupted CSV", outputs["corrupted_csv"])
    table.add_row("Manifest JSON", outputs["manifest_json"])
    table.add_row("Modes", ", ".join(mode))
    console.print(table)


@data_app.command(name="synthetic-mirror")
def data_synthetic_mirror(
    input_csv: Annotated[Path, typer.Argument(help="Source CSV (validated real dataset)")],
    contract_path: Annotated[Path, typer.Argument(help="Contract YAML path used as schema/range guard")],
    output_csv: Annotated[Path, typer.Option(help="Output synthetic CSV path")] = Path("data/synthetic_mirror.csv"),
    output_json: Annotated[Optional[Path], typer.Option(help="Optional synthetic mirror report JSON")] = Path("results/synthetic_mirror_report.json"),
    rows: Annotated[Optional[int], typer.Option(help="Optional number of rows to generate")] = None,
    seed: Annotated[int, typer.Option(help="Random seed for deterministic synthesis")] = 42,
    noise_scale: Annotated[float, typer.Option(help="Numeric perturbation scale as fraction of source std-dev")] = 0.05,
    min_mdmp_grade: Annotated[
        Optional[str],
        typer.Option(help="Optional MDMP grade gate for generated synthetic dataset"),
    ] = "research_grade",
    fail_on_noncompliant: Annotated[bool, typer.Option(help="Exit code 1 when generated dataset fails compliance")] = True,
):
    """Generate a privacy-safe synthetic mirror dataset and validate it against MDMP contract gates."""
    console = Console()
    if not input_csv.is_file():
        console.print(f"[bold red]Input CSV not found: {input_csv}[/bold red]")
        raise typer.Exit(code=1)
    if not contract_path.is_file():
        console.print(f"[bold red]Contract file not found: {contract_path}[/bold red]")
        raise typer.Exit(code=1)

    try:
        source_df = pd.read_csv(input_csv)
        contract = load_contract_yaml(contract_path)
        synthetic_df, artifact = generate_synthetic_mirror(
            source_df,
            contract,
            rows=rows,
            seed=seed,
            noise_scale=noise_scale,
        )
    except Exception as exc:
        console.print(f"[bold red]Synthetic mirror generation failed: {exc}[/bold red]")
        raise typer.Exit(code=1)

    output_csv.parent.mkdir(parents=True, exist_ok=True)
    synthetic_df.to_csv(output_csv, index=False)
    console.print(f"[green]Synthetic mirror CSV written:[/green] {output_csv}")

    summary = Table(title="Synthetic Mirror Summary")
    summary.add_column("Field", style="cyan")
    summary.add_column("Value")
    summary.add_row("Source rows", str(artifact.summary.get("source_rows", 0)))
    summary.add_row("Synthetic rows", str(artifact.summary.get("synthetic_rows", 0)))
    summary.add_row("Noise scale", str(artifact.summary.get("noise_scale", 0.0)))
    summary.add_row("MDMP grade", artifact.validation.mdmp_grade)
    summary.add_row("Compliance", f"{artifact.validation.compliance_score:.2f}%")
    summary.add_row("Status", "[green]PASS[/green]" if artifact.validation.is_compliant else "[red]FAIL[/red]")
    console.print(summary)

    if output_json is not None:
        output_json.parent.mkdir(parents=True, exist_ok=True)
        output_json.write_text(json.dumps(artifact.to_dict(), indent=2))
        console.print(f"[green]Synthetic mirror report written:[/green] {output_json}")

    if min_mdmp_grade is not None:
        normalized = min_mdmp_grade.strip().lower()
        if normalized not in MDMP_GRADE_ORDER:
            allowed = ", ".join(MDMP_GRADE_ORDER)
            console.print(f"[bold red]Invalid --min-mdmp-grade value: {min_mdmp_grade}. Use one of: {allowed}[/bold red]")
            raise typer.Exit(code=1)
        if not mdmp_grade_meets_minimum(artifact.validation.mdmp_grade, normalized):
            console.print(
                f"[bold red]MDMP gate failed:[/bold red] got {artifact.validation.mdmp_grade}, requires at least {normalized}"
            )
            raise typer.Exit(code=1)

    if fail_on_noncompliant and not artifact.validation.is_compliant:
        raise typer.Exit(code=1)


@mdmp_app.command(name="template")
def mdmp_template(
    output_path: Annotated[Path, typer.Option(help="Where to write the MDMP contract YAML")] = Path("mdmp_contract.yaml"),
):
    """Write an MDMP contract template (preferred MDMP namespace)."""
    data_contract_template(output_path=output_path)


@mdmp_app.command(name="validate")
def mdmp_validate(
    contract_path: Annotated[Path, typer.Argument(help="Path to MDMP contract YAML")],
    input_csv: Annotated[Path, typer.Argument(help="Path to input CSV")],
    output_json: Annotated[Optional[Path], typer.Option(help="Optional output report JSON path")] = None,
    apply_builtin_transforms: Annotated[
        bool,
        typer.Option(help="Apply built-in unit conversion transforms (default: off for explicit MDMP operation)"),
    ] = False,
    fail_on_noncompliant: Annotated[bool, typer.Option(help="Exit code 1 when compliance checks fail")] = False,
    min_mdmp_grade: Annotated[
        Optional[str],
        typer.Option(help="Optional MDMP grade gate (draft, research_grade, clinical_grade)"),
    ] = None,
):
    """Validate dataset against MDMP contract (preferred MDMP namespace)."""
    data_contract_run(
        contract_path=contract_path,
        input_csv=input_csv,
        output_json=output_json,
        apply_builtin_transforms=apply_builtin_transforms,
        fail_on_noncompliant=fail_on_noncompliant,
        min_mdmp_grade=min_mdmp_grade,
    )


@mdmp_app.command(name="visualizer")
def mdmp_visualizer(
    report_json: Annotated[Path, typer.Argument(help="Path to MDMP validation report JSON")],
    output_html: Annotated[Path, typer.Option(help="Output HTML path")] = Path("results/mdmp_dashboard.html"),
    title: Annotated[str, typer.Option(help="Dashboard title")] = "IINTS MDMP Certification Dashboard",
):
    """Generate MDMP dashboard from report JSON (preferred MDMP namespace)."""
    data_mdmp_visualizer(report_json=report_json, output_html=output_html, title=title)


@mdmp_app.command(name="synthetic-mirror")
def mdmp_synthetic_mirror(
    input_csv: Annotated[Path, typer.Argument(help="Source CSV")],
    contract_path: Annotated[Path, typer.Argument(help="MDMP contract YAML")],
    output_csv: Annotated[Path, typer.Option(help="Output synthetic CSV path")] = Path("data/synthetic_mirror.csv"),
    output_json: Annotated[Optional[Path], typer.Option(help="Optional synthetic mirror report JSON")] = Path("results/synthetic_mirror_report.json"),
    rows: Annotated[Optional[int], typer.Option(help="Optional number of rows to generate")] = None,
    seed: Annotated[int, typer.Option(help="Random seed")] = 42,
    noise_scale: Annotated[float, typer.Option(help="Numeric perturbation scale")] = 0.05,
    min_mdmp_grade: Annotated[Optional[str], typer.Option(help="Optional MDMP grade gate")] = "research_grade",
    fail_on_noncompliant: Annotated[bool, typer.Option(help="Exit code 1 when generated dataset fails compliance")] = True,
):
    """Generate synthetic mirror dataset (preferred MDMP namespace)."""
    data_synthetic_mirror(
        input_csv=input_csv,
        contract_path=contract_path,
        output_csv=output_csv,
        output_json=output_json,
        rows=rows,
        seed=seed,
        noise_scale=noise_scale,
        min_mdmp_grade=min_mdmp_grade,
        fail_on_noncompliant=fail_on_noncompliant,
    )


@app.command(name="sources")
def sources(
    category: Annotated[Optional[str], typer.Option(help="Filter by source category (guideline, trial, model, dataset, ...).")] = None,
    output_json: Annotated[Optional[Path], typer.Option(help="Optional JSON output path.")] = None,
):
    """List evidence sources used to ground simulation defaults and evaluation targets."""
    console = Console()

    try:
        payload = _filtered_evidence_sources(category=category)
    except Exception as exc:
        console.print(f"[bold red]Could not load evidence sources: {exc}[/bold red]")
        raise typer.Exit(code=1)

    filtered = payload.get("sources", [])
    if not isinstance(filtered, list):
        console.print("[bold red]Invalid evidence sources payload[/bold red]")
        raise typer.Exit(code=1)

    if not filtered:
        if category:
            console.print(f"[yellow]No sources found for category '{category}'.[/yellow]")
        else:
            console.print("[yellow]No evidence sources found.[/yellow]")
        raise typer.Exit(code=1)

    table = Table(title="IINTS-AF Evidence Sources", show_header=True, header_style="bold cyan")
    table.add_column("ID", style="green")
    table.add_column("Category", style="magenta")
    table.add_column("Component", style="white")
    table.add_column("Year", style="yellow")
    table.add_column("Title", style="white")
    table.add_column("DOI / URL", style="blue")
    for entry in filtered:
        citation = str(entry.get("citation", ""))
        year = ""
        for token in citation.replace(";", " ").replace(".", " ").split():
            if len(token) == 4 and token.isdigit():
                year = token
                break
        doi = str(entry.get("doi", "")).strip()
        url = str(entry.get("url", "")).strip()
        table.add_row(
            str(entry.get("id", "")),
            str(entry.get("category", "")),
            str(entry.get("component", "")),
            year,
            str(entry.get("title", "")),
            doi if doi else url,
        )
    console.print(table)
    console.print("[dim]See docs/EVIDENCE_BASE.md for mapping, assumptions, and implementation notes.[/dim]")

    if output_json is not None:
        output_json.parent.mkdir(parents=True, exist_ok=True)
        output_json.write_text(json.dumps(payload, indent=2))
        console.print(f"[green]Saved source manifest: {output_json}[/green]")


# ---------------------------------------------------------------------------
# P1-4: Research pipeline CLI commands
# ---------------------------------------------------------------------------

research_app = typer.Typer(help="Research pipeline: dataset preparation and quality reporting.")
app.add_typer(research_app, name="research")


@research_app.command(name="prepare-azt1d")
def research_prepare_azt1d(
    input_dir: Annotated[Path, typer.Option(help="Root directory containing AZT1D Subject folders")] = Path("data_packs/public/azt1d/AZT1D 2025/CGM Records"),
    output: Annotated[Path, typer.Option(help="Output dataset path (CSV or Parquet)")] = Path("data_packs/public/azt1d/processed/azt1d_merged.csv"),
    report: Annotated[Path, typer.Option(help="Quality report output path")] = Path("data_packs/public/azt1d/quality_report.json"),
    time_step: Annotated[int, typer.Option(help="Expected CGM sample interval (minutes)")] = 5,
    max_gap_multiplier: Annotated[float, typer.Option(help="Segment-break gap multiplier")] = 2.5,
    dia_minutes: Annotated[float, typer.Option(help="Insulin action duration (minutes)")] = 240.0,
    peak_minutes: Annotated[float, typer.Option(help="IOB peak time (minutes, OpenAPS bilinear)")] = 75.0,
    carb_absorb_minutes: Annotated[float, typer.Option(help="Carb absorption duration (minutes)")] = 120.0,
    max_basal: Annotated[float, typer.Option(help="Clip basal values above this (U/hr)")] = 20.0,
    max_bolus: Annotated[float, typer.Option(help="Clip bolus values above this (U)")] = 30.0,
    max_carbs: Annotated[float, typer.Option(help="Clip carb grams above this")] = 200.0,
    basal_is_rate: Annotated[bool, typer.Option(help="Treat Basal column as U/hr (convert to U/step)")] = True,
):
    """
    Prepare the AZT1D CGM dataset for LSTM predictor training.

    Reads per-subject CSVs, applies basal-rate conversion (U/hr → U/step),
    derives IOB/COB using the OpenAPS bilinear model, adds time-of-day
    cyclical features, and writes the merged dataset plus a quality report.

    Example
    -------
    iints research prepare-azt1d --input-dir data_packs/public/azt1d/... --output merged.parquet
    """
    console = Console()
    if not input_dir.exists():
        console.print(f"[bold red]Input directory not found: {input_dir}[/bold red]")
        raise typer.Exit(code=1)

    import subprocess, sys  # noqa: E401
    cmd = [
        sys.executable,
        str(Path(__file__).parent.parent.parent.parent.parent / "research" / "prepare_azt1d.py"),
        "--input", str(input_dir),
        "--output", str(output),
        "--report", str(report),
        "--time-step", str(time_step),
        "--max-gap-multiplier", str(max_gap_multiplier),
        "--dia-minutes", str(dia_minutes),
        "--peak-minutes", str(peak_minutes),
        "--carb-absorb-minutes", str(carb_absorb_minutes),
        "--max-basal", str(max_basal),
        "--max-bolus", str(max_bolus),
        "--max-carbs", str(max_carbs),
    ]
    if not basal_is_rate:
        cmd.append("--no-basal-is-rate")
    try:
        import importlib.util as _ilu
        # Prefer in-process execution when the research script is importable
        spec = _ilu.spec_from_file_location(
            "_prepare_azt1d",
            Path(__file__).parent.parent.parent.parent.parent / "research" / "prepare_azt1d.py",
        )
        if spec is not None and spec.loader is not None:
            import sys as _sys
            _old_argv = _sys.argv[:]
            _sys.argv = cmd[1:]  # strip python interpreter
            try:
                mod = _ilu.module_from_spec(spec)
                spec.loader.exec_module(mod)  # type: ignore[union-attr]
                mod.main()  # type: ignore[attr-defined]
            finally:
                _sys.argv = _old_argv
        else:
            result = subprocess.run(cmd, check=True)
    except Exception as exc:
        console.print(f"[bold red]prepare-azt1d failed: {exc}[/bold red]")
        raise typer.Exit(code=1)

    console.print(f"[green]Dataset written to:[/green] {output}")
    console.print(f"[green]Quality report   :[/green] {report}")


@research_app.command(name="prepare-ohio")
def research_prepare_ohio(
    input_dir: Annotated[Path, typer.Option(help="Root directory containing OhioT1DM patient_* folders")] = Path("data_packs/public/ohio_t1dm"),
    output: Annotated[Path, typer.Option(help="Output dataset path (CSV or Parquet)")] = Path("data_packs/public/ohio_t1dm/processed/ohio_t1dm_merged.csv"),
    report: Annotated[Path, typer.Option(help="Quality report output path")] = Path("data_packs/public/ohio_t1dm/quality_report.json"),
    time_step: Annotated[int, typer.Option(help="Expected CGM sample interval (minutes)")] = 5,
    max_gap_multiplier: Annotated[float, typer.Option(help="Segment-break gap multiplier")] = 2.5,
    dia_minutes: Annotated[float, typer.Option(help="Insulin action duration (minutes)")] = 240.0,
    peak_minutes: Annotated[float, typer.Option(help="IOB peak time (minutes, OpenAPS bilinear)")] = 75.0,
    carb_absorb_minutes: Annotated[float, typer.Option(help="Carb absorption duration (minutes)")] = 120.0,
    max_insulin: Annotated[float, typer.Option(help="Clip insulin units above this")] = 30.0,
    max_carbs: Annotated[float, typer.Option(help="Clip carb grams above this")] = 200.0,
    icr_default: Annotated[float, typer.Option(help="Fallback ICR (g/U)")] = 10.0,
    isf_default: Annotated[float, typer.Option(help="Fallback ISF (mg/dL per U)")] = 50.0,
    basal_default: Annotated[float, typer.Option(help="Fallback basal rate (U/hr)")] = 0.0,
    meal_window_min: Annotated[float, typer.Option(help="Meal→insulin matching window (minutes)")] = 30.0,
    isf_window_min: Annotated[float, typer.Option(help="ISF estimation window (minutes)")] = 60.0,
    min_meal_carbs: Annotated[float, typer.Option(help="Minimum carbs to consider a meal (g)")] = 5.0,
    min_bolus: Annotated[float, typer.Option(help="Minimum insulin to consider a bolus (U)")] = 0.1,
):
    """
    Prepare the OhioT1DM dataset for LSTM predictor training.

    Reads per-patient CSVs, derives IOB/COB using the OpenAPS bilinear model,
    estimates effective ISF/ICR/basal per subject, adds time-of-day features,
    and writes the merged dataset plus a quality report.

    Example
    -------
    iints research prepare-ohio --input-dir data_packs/public/ohio_t1dm --output ohio.parquet
    """
    console = Console()
    if not input_dir.exists():
        console.print(f"[bold red]Input directory not found: {input_dir}[/bold red]")
        raise typer.Exit(code=1)

    import subprocess, sys  # noqa: E401
    cmd = [
        sys.executable,
        str(Path(__file__).parent.parent.parent.parent.parent / "research" / "prepare_ohio_t1dm.py"),
        "--input", str(input_dir),
        "--output", str(output),
        "--report", str(report),
        "--time-step", str(time_step),
        "--max-gap-multiplier", str(max_gap_multiplier),
        "--dia-minutes", str(dia_minutes),
        "--peak-minutes", str(peak_minutes),
        "--carb-absorb-minutes", str(carb_absorb_minutes),
        "--max-insulin", str(max_insulin),
        "--max-carbs", str(max_carbs),
        "--icr-default", str(icr_default),
        "--isf-default", str(isf_default),
        "--basal-default", str(basal_default),
        "--meal-window-min", str(meal_window_min),
        "--isf-window-min", str(isf_window_min),
        "--min-meal-carbs", str(min_meal_carbs),
        "--min-bolus", str(min_bolus),
    ]
    try:
        import importlib.util as _ilu
        spec = _ilu.spec_from_file_location(
            "_prepare_ohio_t1dm",
            Path(__file__).parent.parent.parent.parent.parent / "research" / "prepare_ohio_t1dm.py",
        )
        if spec is not None and spec.loader is not None:
            import sys as _sys
            _old_argv = _sys.argv[:]
            _sys.argv = cmd[1:]
            try:
                mod = _ilu.module_from_spec(spec)
                spec.loader.exec_module(mod)  # type: ignore[union-attr]
                mod.main()  # type: ignore[attr-defined]
            finally:
                _sys.argv = _old_argv
        else:
            subprocess.run(cmd, check=True)
    except Exception as exc:
        console.print(f"[bold red]prepare-ohio failed: {exc}[/bold red]")
        raise typer.Exit(code=1)

    console.print(f"[green]Dataset written to:[/green] {output}")
    console.print(f"[green]Quality report   :[/green] {report}")


@research_app.command(name="prepare-hupa")
def research_prepare_hupa(
    input_dir: Annotated[Path, typer.Option(help="Root directory containing HUPA-UCM CSV files")] = Path("data_packs/public/hupa_ucm"),
    output: Annotated[Path, typer.Option(help="Output dataset path (CSV or Parquet)")] = Path("data_packs/public/hupa_ucm/processed/hupa_ucm_merged.csv"),
    report: Annotated[Path, typer.Option(help="Quality report output path")] = Path("data_packs/public/hupa_ucm/quality_report.json"),
    time_step: Annotated[int, typer.Option(help="Expected CGM sample interval (minutes)")] = 5,
    max_gap_multiplier: Annotated[float, typer.Option(help="Segment-break gap multiplier")] = 2.5,
    dia_minutes: Annotated[float, typer.Option(help="Insulin action duration (minutes)")] = 240.0,
    peak_minutes: Annotated[float, typer.Option(help="IOB peak time (minutes, OpenAPS bilinear)")] = 75.0,
    carb_absorb_minutes: Annotated[float, typer.Option(help="Carb absorption duration (minutes)")] = 120.0,
    max_insulin: Annotated[float, typer.Option(help="Clip insulin units above this")] = 30.0,
    max_carbs: Annotated[float, typer.Option(help="Clip carb grams above this")] = 200.0,
    carb_serving_grams: Annotated[float, typer.Option(help="Carb serving size (g) for carb_input")] = 10.0,
    basal_is_rate: Annotated[bool, typer.Option(help="Treat basal_rate as U/hr (convert to U/step)")] = False,
    icr_default: Annotated[float, typer.Option(help="Fallback ICR (g/U)")] = 10.0,
    isf_default: Annotated[float, typer.Option(help="Fallback ISF (mg/dL per U)")] = 50.0,
    basal_default: Annotated[float, typer.Option(help="Fallback basal rate (U/hr)")] = 0.0,
    meal_window_min: Annotated[float, typer.Option(help="Meal→insulin matching window (minutes)")] = 30.0,
    isf_window_min: Annotated[float, typer.Option(help="ISF estimation window (minutes)")] = 60.0,
    min_meal_carbs: Annotated[float, typer.Option(help="Minimum carbs to consider a meal (g)")] = 5.0,
    min_bolus: Annotated[float, typer.Option(help="Minimum insulin to consider a bolus (U)")] = 0.1,
):
    """
    Prepare the HUPA-UCM dataset for LSTM predictor training.

    Parses per-patient CSVs, derives IOB/COB, estimates ISF/ICR/basal per
    subject, and writes the merged dataset plus a quality report.

    Example
    -------
    iints research prepare-hupa --input-dir data_packs/public/hupa_ucm --output hupa.parquet
    """
    console = Console()
    if not input_dir.exists():
        console.print(f"[bold red]Input directory not found: {input_dir}[/bold red]")
        raise typer.Exit(code=1)

    import subprocess, sys  # noqa: E401
    cmd = [
        sys.executable,
        str(Path(__file__).parent.parent.parent.parent.parent / "research" / "prepare_hupa_ucm.py"),
        "--input", str(input_dir),
        "--output", str(output),
        "--report", str(report),
        "--time-step", str(time_step),
        "--max-gap-multiplier", str(max_gap_multiplier),
        "--dia-minutes", str(dia_minutes),
        "--peak-minutes", str(peak_minutes),
        "--carb-absorb-minutes", str(carb_absorb_minutes),
        "--max-insulin", str(max_insulin),
        "--max-carbs", str(max_carbs),
        "--carb-serving-grams", str(carb_serving_grams),
        "--icr-default", str(icr_default),
        "--isf-default", str(isf_default),
        "--basal-default", str(basal_default),
        "--meal-window-min", str(meal_window_min),
        "--isf-window-min", str(isf_window_min),
        "--min-meal-carbs", str(min_meal_carbs),
        "--min-bolus", str(min_bolus),
    ]
    if basal_is_rate:
        cmd.append("--basal-is-rate")
    else:
        cmd.append("--no-basal-is-rate")
    try:
        import importlib.util as _ilu
        spec = _ilu.spec_from_file_location(
            "_prepare_hupa_ucm",
            Path(__file__).parent.parent.parent.parent.parent / "research" / "prepare_hupa_ucm.py",
        )
        if spec is not None and spec.loader is not None:
            import sys as _sys
            _old_argv = _sys.argv[:]
            _sys.argv = cmd[1:]
            try:
                mod = _ilu.module_from_spec(spec)
                spec.loader.exec_module(mod)  # type: ignore[union-attr]
                mod.main()  # type: ignore[attr-defined]
            finally:
                _sys.argv = _old_argv
        else:
            subprocess.run(cmd, check=True)
    except Exception as exc:
        console.print(f"[bold red]prepare-hupa failed: {exc}[/bold red]")
        raise typer.Exit(code=1)

    console.print(f"[green]Dataset written to:[/green] {output}")
    console.print(f"[green]Quality report   :[/green] {report}")


@research_app.command(name="quality")
def research_quality(
    report: Annotated[Path, typer.Option(help="Path to quality_report.json produced by prepare-azt1d")] = Path("data_packs/public/azt1d/quality_report.json"),
):
    """
    Display a quality report produced by `iints research prepare-azt1d`.

    Shows dataset summary statistics, subject count, glucose range, and
    pipeline parameters in a formatted table.

    Example
    -------
    iints research quality --report data_packs/public/azt1d/quality_report.json
    """
    console = Console()
    if not report.exists():
        console.print(f"[bold red]Report not found: {report}[/bold red]")
        console.print("Run [bold]iints research prepare-azt1d[/bold] first.")
        raise typer.Exit(code=1)

    try:
        data = json.loads(report.read_text())
    except Exception as exc:
        console.print(f"[bold red]Failed to parse report: {exc}[/bold red]")
        raise typer.Exit(code=1)

    table = Table(title=f"AZT1D Dataset Quality Report", show_header=True, header_style="bold cyan")
    table.add_column("Field", style="green")
    table.add_column("Value", style="white")

    display_keys = [
        ("source", "Source directory"),
        ("records_total", "Total records"),
        ("subjects", "Subject count"),
        ("subject_ids", "Subject IDs"),
        ("start_time", "Start time"),
        ("end_time", "End time"),
        ("glucose_mean", "Glucose mean (mg/dL)"),
        ("glucose_std", "Glucose std (mg/dL)"),
        ("glucose_min", "Glucose min (mg/dL)"),
        ("glucose_max", "Glucose max (mg/dL)"),
        ("insulin_mean", "Insulin mean (U/step)"),
        ("carb_mean", "Carb mean (g/step)"),
        ("iob_model", "IOB model"),
        ("basal_is_rate", "Basal as U/hr"),
        ("time_step_minutes", "Time step (min)"),
        ("dia_minutes", "DIA (min)"),
        ("peak_minutes", "Peak time (min)"),
        ("carb_absorb_minutes", "Carb absorb (min)"),
    ]

    for key, label in display_keys:
        if key in data:
            val = data[key]
            if isinstance(val, list):
                val = ", ".join(str(v) for v in val)
            elif isinstance(val, float):
                val = f"{val:.3f}"
            else:
                val = str(val)
            table.add_row(label, val)

    console.print(table)


@research_app.command(name="export-onnx")
def research_export_onnx(
    model: Annotated[Path, typer.Option(help="Predictor checkpoint (.pt)")] = Path("models/hupa_finetuned_v2/predictor.pt"),
    out: Annotated[Path, typer.Option(help="Output ONNX file path")] = Path("models/predictor.onnx"),
):
    """
    Export a trained predictor to ONNX for edge/Jetson deployment.
    """
    console = Console()
    if not model.exists():
        console.print(f"[bold red]Model not found: {model}[/bold red]")
        raise typer.Exit(code=1)

    import subprocess, sys  # noqa: E401
    cmd = [
        sys.executable,
        str(Path(__file__).parent.parent.parent.parent.parent / "research" / "export_predictor.py"),
        "--model", str(model),
        "--out", str(out),
    ]
    try:
        subprocess.run(cmd, check=True)
    except Exception as exc:
        console.print(f"[bold red]export-onnx failed: {exc}[/bold red]")
        raise typer.Exit(code=1)

    console.print(f"[green]ONNX written to:[/green] {out}")


@research_app.command(name="audit-split")
def research_audit_split(
    data: Annotated[Path, typer.Option(help="Prepared dataset path (CSV/Parquet)")],
    history_steps: Annotated[int, typer.Option(help="History window length")] = 48,
    horizon_steps: Annotated[int, typer.Option(help="Forecast horizon length")] = 6,
    feature_columns_csv: Annotated[str, typer.Option(help="Comma-separated feature columns")] = "glucose_actual_mgdl,patient_iob_units,patient_cob_grams,effective_isf,effective_icr,effective_basal_rate_u_per_hr,glucose_trend_mgdl_min",
    target_column: Annotated[str, typer.Option(help="Target column")] = "glucose_actual_mgdl",
    subject_column: Annotated[str, typer.Option(help="Subject ID column")] = "subject_id",
    segment_column: Annotated[Optional[str], typer.Option(help="Segment column (optional)")] = "segment_id",
    output_json: Annotated[Optional[Path], typer.Option(help="Write audit report JSON")] = None,
):
    """
    Audit subject-level leakage and window overlap for train/val/test splits.
    """
    console = Console()
    if not data.exists():
        console.print(f"[bold red]Dataset not found: {data}[/bold red]")
        raise typer.Exit(code=1)

    from iints.research.dataset import load_dataset
    from iints.research.audit import audit_subject_split_and_leakage

    df = load_dataset(data)
    feature_columns = [col.strip() for col in feature_columns_csv.split(",") if col.strip()]
    report = audit_subject_split_and_leakage(
        df,
        history_steps=history_steps,
        horizon_steps=horizon_steps,
        feature_columns=feature_columns,
        target_column=target_column,
        subject_column=subject_column,
        segment_column=segment_column,
    )

    table = Table(title="Leakage & Split Audit")
    table.add_column("Field", style="cyan")
    table.add_column("Value")
    table.add_row("Leakage free", "[green]yes[/green]" if report["leakage_free"] else "[red]no[/red]")
    table.add_row("Train subjects", str(report["subject_counts"]["train"]))
    table.add_row("Val subjects", str(report["subject_counts"]["val"]))
    table.add_row("Test subjects", str(report["subject_counts"]["test"]))
    table.add_row("Train windows", str(report["sequence_counts"]["train"]))
    table.add_row("Val windows", str(report["sequence_counts"]["val"]))
    table.add_row("Test windows", str(report["sequence_counts"]["test"]))
    table.add_row("Overlap train/val", str(report["sequence_overlap_counts"]["train_val"]))
    table.add_row("Overlap train/test", str(report["sequence_overlap_counts"]["train_test"]))
    table.add_row("Overlap val/test", str(report["sequence_overlap_counts"]["val_test"]))
    console.print(table)

    if output_json is not None:
        output_json.parent.mkdir(parents=True, exist_ok=True)
        output_json.write_text(json.dumps(report, indent=2))
        console.print(f"[green]Audit report written:[/green] {output_json}")

    if not report["leakage_free"]:
        raise typer.Exit(code=1)


@research_app.command(name="evaluate-forecast")
def research_evaluate_forecast(
    input_csv: Annotated[Path, typer.Option(help="CSV with observed/predicted columns")],
    observed_column: Annotated[str, typer.Option(help="Observed glucose column")] = "glucose_actual_mgdl",
    predicted_column: Annotated[str, typer.Option(help="Predicted glucose column")] = "predicted_glucose_ai_30min",
    predicted_std_column: Annotated[Optional[str], typer.Option(help="Optional prediction std column")] = "predictor_uncertainty_std_mgdl",
    gate_profile: Annotated[Optional[str], typer.Option(help="Optional calibration gate profile id")] = None,
    gate_profiles_path: Annotated[Optional[Path], typer.Option(help="Optional calibration gate profiles YAML path")] = None,
    fail_on_gate: Annotated[bool, typer.Option(help="Exit code 1 when calibration gate fails")] = False,
    output_json: Annotated[Optional[Path], typer.Option(help="Write metrics JSON")] = None,
):
    """
    Calibration-first forecast evaluation (global, band-wise, and alarm quality).
    """
    console = Console()
    if not input_csv.exists():
        console.print(f"[bold red]Input CSV not found: {input_csv}[/bold red]")
        raise typer.Exit(code=1)
    df = pd.read_csv(input_csv)
    for col in (observed_column, predicted_column):
        if col not in df.columns:
            console.print(f"[bold red]Missing column: {col}[/bold red]")
            raise typer.Exit(code=1)

    from iints.research.evaluation import forecast_error_report

    observed = df[observed_column].to_numpy(dtype=float)
    predicted = df[predicted_column].to_numpy(dtype=float)
    predicted_std = None
    if predicted_std_column and predicted_std_column in df.columns:
        predicted_std = df[predicted_std_column].to_numpy(dtype=float)

    report = forecast_error_report(observed, predicted, predicted_std)

    table = Table(title="Forecast Evaluation")
    table.add_column("Metric", style="cyan")
    table.add_column("Value", justify="right")
    table.add_row("Samples", str(report["n"]))
    table.add_row("MAE", f"{report['mae']:.3f}")
    table.add_row("RMSE", f"{report['rmse']:.3f}")
    table.add_row("Bias", f"{report['bias']:.3f}")
    table.add_row("Within ±10 mg/dL (%)", f"{report['within_10_mgdl_pct']:.2f}")
    table.add_row("Within ±20 mg/dL (%)", f"{report['within_20_mgdl_pct']:.2f}")
    table.add_row("False hypo alarm (%)", f"{report['false_hypo_alarm_rate_pct']:.2f}")
    table.add_row("Missed hypo (%)", f"{report['missed_hypo_rate_pct']:.2f}")
    if "interval_95_coverage_pct" in report:
        table.add_row("95% interval coverage (%)", f"{report['interval_95_coverage_pct']:.2f}")
        table.add_row("Mean predicted std (mg/dL)", f"{report['mean_predicted_std_mgdl']:.3f}")
    console.print(table)

    band_table = Table(title="Band-wise Error")
    band_table.add_column("Band", style="cyan")
    band_table.add_column("Count", justify="right")
    band_table.add_column("MAE", justify="right")
    band_table.add_column("RMSE", justify="right")
    band_table.add_column("Bias", justify="right")
    for band, values in report["band_metrics"].items():
        band_table.add_row(
            band,
            f"{values['count']:.0f}",
            f"{values['mae']:.3f}" if not np.isnan(values["mae"]) else "n/a",
            f"{values['rmse']:.3f}" if not np.isnan(values["rmse"]) else "n/a",
            f"{values['bias']:.3f}" if not np.isnan(values["bias"]) else "n/a",
        )
    console.print(band_table)

    gate_failed = False
    if gate_profile:
        from iints.research.calibration_gate import (
            evaluate_calibration_gate,
            load_calibration_gate_profiles,
        )

        try:
            profiles = load_calibration_gate_profiles(gate_profiles_path)
        except Exception as exc:
            console.print(f"[bold red]Could not load calibration gate profiles: {exc}[/bold red]")
            raise typer.Exit(code=1)
        gate = profiles.get(gate_profile)
        if gate is None:
            available = ", ".join(sorted(profiles.keys()))
            console.print(f"[bold red]Unknown calibration gate '{gate_profile}'. Available: {available}[/bold red]")
            raise typer.Exit(code=1)

        checks = evaluate_calibration_gate(report, gate)
        gate_passed = all(check.get("passed", False) for check in checks.values()) if checks else True
        gate_failed = not gate_passed
        report["calibration_gate"] = {
            "profile": gate_profile,
            "passed": gate_passed,
            "checks": checks,
        }

        gate_table = Table(title=f"Calibration Gate — {gate_profile}")
        gate_table.add_column("Status", style="bold")
        gate_table.add_column("Metric", style="cyan")
        gate_table.add_column("Value", justify="right")
        gate_table.add_column("Threshold", justify="right")
        gate_table.add_column("Reason")
        for metric, check in checks.items():
            status = "[green]PASS[/green]" if check.get("passed", False) else "[red]FAIL[/red]"
            value = "n/a" if check.get("value") is None else f"{float(check['value']):.3f}"
            threshold = "n/a" if check.get("threshold") is None else f"{float(check['threshold']):.3f}"
            gate_table.add_row(status, metric, value, threshold, str(check.get("reason", "")))
        console.print(gate_table)

    if output_json is not None:
        output_json.parent.mkdir(parents=True, exist_ok=True)
        output_json.write_text(json.dumps(report, indent=2))
        console.print(f"[green]Forecast metrics written:[/green] {output_json}")

    if fail_on_gate and gate_failed:
        raise typer.Exit(code=1)


@research_app.command(name="parity-check")
def research_parity_check(
    model: Annotated[Path, typer.Option(help="Predictor checkpoint (.pt)")],
    onnx: Annotated[Path, typer.Option(help="Exported ONNX model path")],
    samples: Annotated[int, typer.Option(help="Random sample count for parity check")] = 64,
    tolerance: Annotated[float, typer.Option(help="Maximum allowed absolute error")] = 1e-3,
    seed: Annotated[int, typer.Option(help="Random seed")] = 42,
    output_json: Annotated[Optional[Path], typer.Option(help="Write parity report JSON")] = None,
):
    """
    Check Torch vs ONNX parity and report edge latency.
    """
    console = Console()
    if not model.exists():
        console.print(f"[bold red]Model not found: {model}[/bold red]")
        raise typer.Exit(code=1)
    if not onnx.exists():
        console.print(f"[bold red]ONNX model not found: {onnx}[/bold red]")
        raise typer.Exit(code=1)

    try:
        import onnxruntime as ort
    except Exception as exc:
        console.print("[bold red]onnxruntime is required for parity-check.[/bold red]")
        console.print(f"[red]Details:[/red] {exc}")
        raise typer.Exit(code=1)

    from iints.research.predictor import load_predictor_service

    predictor = load_predictor_service(model)
    feature_count = len(predictor.feature_columns)
    history_steps = int(predictor.history_steps)
    rng = np.random.default_rng(seed)
    X = rng.normal(size=(samples, history_steps, feature_count)).astype(np.float32)

    t0 = time.perf_counter()
    torch_pred = predictor.predict(X)
    torch_latency_ms = (time.perf_counter() - t0) * 1000.0

    session = ort.InferenceSession(str(onnx), providers=["CPUExecutionProvider"])
    input_name = session.get_inputs()[0].name
    t1 = time.perf_counter()
    onnx_pred = session.run(None, {input_name: X})[0]
    onnx_latency_ms = (time.perf_counter() - t1) * 1000.0

    diff = np.abs(torch_pred - onnx_pred)
    max_abs = float(np.max(diff))
    mean_abs = float(np.mean(diff))
    passed = max_abs <= tolerance

    report = {
        "samples": samples,
        "tolerance": tolerance,
        "max_abs_diff": max_abs,
        "mean_abs_diff": mean_abs,
        "torch_latency_ms": torch_latency_ms,
        "onnx_latency_ms": onnx_latency_ms,
        "passed": passed,
    }

    table = Table(title="Torch/ONNX Parity")
    table.add_column("Field", style="cyan")
    table.add_column("Value", justify="right")
    table.add_row("Samples", str(samples))
    table.add_row("Tolerance", f"{tolerance:.6f}")
    table.add_row("Max abs diff", f"{max_abs:.6f}")
    table.add_row("Mean abs diff", f"{mean_abs:.6f}")
    table.add_row("Torch latency (ms)", f"{torch_latency_ms:.2f}")
    table.add_row("ONNX latency (ms)", f"{onnx_latency_ms:.2f}")
    table.add_row("Status", "[green]PASS[/green]" if passed else "[red]FAIL[/red]")
    console.print(table)

    if output_json is not None:
        output_json.parent.mkdir(parents=True, exist_ok=True)
        output_json.write_text(json.dumps(report, indent=2))
        console.print(f"[green]Parity report written:[/green] {output_json}")

    if not passed:
        raise typer.Exit(code=1)


@research_app.command(name="registry-list")
def research_registry_list(
    registry: Annotated[Path, typer.Option(help="Path to model registry JSON")] = Path("models/registry.json"),
    stage: Annotated[Optional[str], typer.Option(help="Optional stage filter (candidate/validated/production/archived)")] = None,
    limit: Annotated[int, typer.Option(help="Max rows to print")] = 30,
):
    """List model runs from the research registry."""
    console = Console()
    from iints.research.model_registry import list_registry

    rows = list_registry(registry)
    if stage:
        rows = [row for row in rows if str(row.get("stage", "candidate")) == stage]

    if not rows:
        console.print(f"[yellow]No registry entries found at {registry}.[/yellow]")
        return

    rows = rows[-limit:] if limit > 0 else rows
    rows = list(reversed(rows))

    table = Table(title=f"Model Registry — {registry}")
    table.add_column("Run ID", style="cyan")
    table.add_column("Stage", style="bold")
    table.add_column("RMSE", justify="right")
    table.add_column("MAE", justify="right")
    table.add_column("Timestamp")
    table.add_column("Model Path")
    for row in rows:
        table.add_row(
            str(row.get("run_id", "")),
            str(row.get("stage", "candidate")),
            "n/a" if row.get("test_rmse") is None else f"{float(row['test_rmse']):.3f}",
            "n/a" if row.get("test_mae") is None else f"{float(row['test_mae']):.3f}",
            str(row.get("timestamp_utc", "")),
            str(row.get("model_path", "")),
        )
    console.print(table)


@research_app.command(name="registry-promote")
def research_registry_promote(
    registry: Annotated[Path, typer.Option(help="Path to model registry JSON")] = Path("models/registry.json"),
    run_id: Annotated[str, typer.Option(help="Run ID to promote")]= "",
    stage: Annotated[str, typer.Option(help="Target stage (validated/production/archived/candidate)")] = "validated",
    force: Annotated[bool, typer.Option(help="Allow production promotion without validated stage")] = False,
    output_json: Annotated[Optional[Path], typer.Option(help="Write promotion result JSON")] = None,
):
    """Promote a model run through candidate -> validated -> production stages."""
    console = Console()
    from iints.research.model_registry import ModelStage, promote_registry_run

    allowed = {"candidate", "validated", "production", "archived"}
    if stage not in allowed:
        console.print(f"[bold red]Invalid stage '{stage}'. Allowed: {', '.join(sorted(allowed))}[/bold red]")
        raise typer.Exit(code=1)
    if not run_id.strip():
        console.print("[bold red]--run-id is required[/bold red]")
        raise typer.Exit(code=1)

    stage_literal = cast(ModelStage, stage)
    result = promote_registry_run(registry, run_id=run_id.strip(), stage=stage_literal, force=force)
    payload = result.to_dict()
    console.print_json(json.dumps(payload, indent=2))

    if output_json is not None:
        output_json.parent.mkdir(parents=True, exist_ok=True)
        output_json.write_text(json.dumps(payload, indent=2))
        console.print(f"[green]Promotion result written:[/green] {output_json}")

    if not result.updated:
        raise typer.Exit(code=1)


@app.command(name="import-data")
def import_data(
    input_csv: Annotated[Path, typer.Option(help="Path to CGM CSV file")],
    output_dir: Annotated[Path, typer.Option(help="Output directory for scenario + standard CSV")] = Path("./results/imported"),
    data_format: Annotated[str, typer.Option(help="Data format preset: generic, dexcom, libre, carelink")] = "generic",
    scenario_name: Annotated[str, typer.Option(help="Scenario name")] = "Imported CGM Scenario",
    scenario_version: Annotated[str, typer.Option(help="Scenario version")] = "1.0",
    time_unit: Annotated[str, typer.Option(help="Timestamp unit: minutes or seconds")] = "minutes",
    carb_threshold: Annotated[float, typer.Option(help="Minimum carbs (g) to create a meal event")] = 0.1,
    scenario_path: Annotated[Optional[Path], typer.Option(help="Optional output scenario path")] = None,
    data_path: Annotated[Optional[Path], typer.Option(help="Optional output standard CSV path")] = None,
    mapping: Annotated[List[str], typer.Option("--map", help="Column mapping key=value (e.g., timestamp=Time, glucose=SGV)")] = [],
):
    """Import real-world CGM CSV into the IINTS standard schema + scenario JSON."""
    console = Console()
    if not input_csv.is_file():
        console.print(f"[bold red]Error: Input CSV '{input_csv}' not found.[/bold red]")
        raise typer.Exit(code=1)

    column_map = _parse_column_mapping(mapping, console)

    try:
        result = scenario_from_csv(
            input_csv,
            scenario_name=scenario_name,
            scenario_version=scenario_version,
            data_format=data_format,
            column_map=column_map or None,
            time_unit=time_unit,
            carb_threshold=carb_threshold,
        )
    except Exception as e:
        console.print(f"[bold red]Import failed: {e}[/bold red]")
        raise typer.Exit(code=1)

    output_dir.mkdir(parents=True, exist_ok=True)
    scenario_path = scenario_path or output_dir / "scenario.json"
    data_path = data_path or output_dir / "cgm_standard.csv"

    scenario_path.write_text(json.dumps(result.scenario, indent=2))
    export_standard_csv(result.dataframe, data_path)

    console.print(f"[green]Scenario saved:[/green] {scenario_path}")
    console.print(f"[green]Standard CSV saved:[/green] {data_path}")
    console.print(f"Rows: {len(result.dataframe)} | Meal events: {len(result.scenario.get('stress_events', []))}")


@app.command(name="import-carelink")
def import_carelink(
    input_csv: Annotated[Path, typer.Option(help="Path to a Medtronic CareLink CSV export")],
    output_dir: Annotated[Path, typer.Option(help="Output directory for imported CareLink artifacts")] = Path("./results/imported_carelink"),
    scenario_name: Annotated[str, typer.Option(help="Scenario name")] = "Imported CareLink Scenario",
    scenario_version: Annotated[str, typer.Option(help="Scenario version")] = "1.0",
    scenario_path: Annotated[Optional[Path], typer.Option(help="Optional output scenario path")] = None,
    data_path: Annotated[Optional[Path], typer.Option(help="Optional output standard CSV path")] = None,
    summary_path: Annotated[Optional[Path], typer.Option(help="Optional output summary JSON path")] = None,
    carb_threshold: Annotated[float, typer.Option(help="Minimum carbs (g) to create a meal event")] = 0.1,
):
    """Import a Medtronic CareLink / MiniMed event export into the IINTS standard schema."""
    console = Console()
    if not input_csv.is_file():
        console.print(f"[bold red]Error: Input CSV '{input_csv}' not found.[/bold red]")
        raise typer.Exit(code=1)

    try:
        result = scenario_from_csv(
            input_csv,
            scenario_name=scenario_name,
            scenario_version=scenario_version,
            data_format="carelink",
            carb_threshold=carb_threshold,
        )
        summary = summarize_carelink_csv(input_csv)
    except Exception as exc:
        console.print(f"[bold red]CareLink import failed: {exc}[/bold red]")
        raise typer.Exit(code=1)

    output_dir.mkdir(parents=True, exist_ok=True)
    scenario_path = scenario_path or output_dir / "scenario.json"
    data_path = data_path or output_dir / "cgm_standard.csv"
    summary_path = summary_path or output_dir / "carelink_summary.json"

    scenario_path.write_text(json.dumps(result.scenario, indent=2))
    export_standard_csv(result.dataframe, data_path)
    summary_path.write_text(json.dumps(summary, indent=2))

    table = Table(title="CareLink Import Summary")
    table.add_column("Field", style="cyan")
    table.add_column("Value", overflow="fold")
    for key in [
        "patient_name",
        "start_date",
        "end_date",
        "device",
        "cgm",
        "raw_event_rows",
        "sensor_glucose_rows",
        "bolus_rows",
        "meal_rows",
        "alert_rows",
    ]:
        table.add_row(key, str(summary.get(key, "")))
    console.print(table)
    console.print(f"[green]Scenario saved:[/green] {scenario_path}")
    console.print(f"[green]Standard CSV saved:[/green] {data_path}")
    console.print(f"[green]Summary JSON saved:[/green] {summary_path}")


@app.command(name="carelink-workbench")
def carelink_workbench(
    input_csv: Annotated[Path, typer.Option(help="Path to a Medtronic CareLink CSV export")],
    output_dir: Annotated[
        Path,
        typer.Option(help="Output directory for the personal CareLink workspace"),
    ] = Path("./results/carelink_workbench"),
    scenario_name: Annotated[str, typer.Option(help="Scenario name for the generated experiment scenario")] = "Imported CareLink Scenario",
    scenario_version: Annotated[str, typer.Option(help="Scenario version")] = "1.0",
    carb_threshold: Annotated[float, typer.Option(help="Minimum carbs (g) to create a meal event")] = 0.1,
    create_dev_mdmp_cert: Annotated[
        bool,
        typer.Option(
            "--create-dev-mdmp-cert/--no-create-dev-mdmp-cert",
            help="Generate a local development MDMP certificate and keypair for the AI assistant.",
        ),
    ] = True,
    grade: Annotated[str, typer.Option(help="Grade to embed in the local development MDMP certificate.")] = "research_grade",
    expires_days: Annotated[int, typer.Option(help="Certificate expiry window in days for local development certs.")] = 30,
    key_dir: Annotated[Optional[Path], typer.Option(help="Optional directory for the generated local MDMP keypair.")] = None,
) -> None:
    """Build a personal CareLink workspace with imports, visualization, and AI-ready payloads."""
    console = Console()
    if not input_csv.is_file():
        console.print(f"[bold red]Error: Input CSV '{input_csv}' not found.[/bold red]")
        raise typer.Exit(code=1)

    try:
        outputs = build_carelink_workbench(
            input_csv,
            output_dir=output_dir,
            scenario_name=scenario_name,
            scenario_version=scenario_version,
            carb_threshold=carb_threshold,
            create_dev_mdmp_cert=create_dev_mdmp_cert,
            grade=grade,
            expires_days=expires_days,
            key_dir=key_dir,
        )
    except Exception as exc:
        console.print(f"[bold red]CareLink workbench failed:[/bold red] {exc}")
        raise typer.Exit(code=1)

    table = Table(title="IINTS CareLink Workbench")
    table.add_column("Artifact", style="cyan")
    table.add_column("Path", overflow="fold")
    for key in [
        "standard_csv",
        "scenario",
        "summary",
        "metrics",
        "timeline",
        "dashboard_png",
        "poster_png",
        "dashboard_html",
        "report_payload",
        "trends_payload",
        "anomalies_payload",
        "step_riskiest",
        "step_latest",
        "mdmp_cert",
    ]:
        if key in outputs:
            table.add_row(key, outputs[key])
    console.print(table)
    console.print("[green]Personal CareLink workspace is ready.[/green]")
    console.print(
        "[green]Experiment with your data:[/green] "
        f"`iints run --algo algorithms/example_algorithm.py --scenario-path {Path(outputs['scenario'])}`"
    )
    if "mdmp_cert" in outputs:
        console.print(
            "[green]Ask the local AI assistant to explain it:[/green] "
            f"`iints ai report {output_dir}` and `iints ai explain {output_dir}`"
        )
    else:
        console.print(
            "[yellow]Note:[/yellow] no local MDMP certificate was generated, so AI commands will still need "
            "`--mdmp-cert` unless you install the optional `mdmp` extra."
        )


@app.command(name="import-wizard")
def import_wizard():
    """Interactive wizard to import real-world CGM CSVs."""
    console = Console()
    input_csv = Path(typer.prompt("Path to CGM CSV"))
    if not input_csv.is_file():
        console.print(f"[bold red]Error: Input CSV '{input_csv}' not found.[/bold red]")
        raise typer.Exit(code=1)

    data_format = typer.prompt("Data format (generic/dexcom/libre)", default="generic")

    header = pd.read_csv(input_csv, nrows=1)
    columns = list(header.columns)
    guesses = guess_column_mapping(columns, data_format=data_format)

    console.print(f"[bold]Detected columns:[/bold] {', '.join(columns)}")
    try:
        preview = pd.read_csv(input_csv, nrows=5)
        console.print(Panel(preview.to_string(index=False), title="Preview (first 5 rows)"))
    except Exception as exc:
        console.print(f"[yellow]Preview unavailable:[/yellow] {exc}")

    ts_col = typer.prompt("Timestamp column", default=guesses.get("timestamp") or columns[0])
    glucose_col = typer.prompt("Glucose column", default=guesses.get("glucose") or "")
    carbs_col = typer.prompt("Carbs column (optional)", default=guesses.get("carbs") or "")
    insulin_col = typer.prompt("Insulin column (optional)", default=guesses.get("insulin") or "")

    mapping = {
        "timestamp": ts_col.strip(),
        "glucose": glucose_col.strip(),
        "carbs": carbs_col.strip(),
        "insulin": insulin_col.strip(),
    }
    mapping = {k: v for k, v in mapping.items() if v}

    time_unit = typer.prompt("Timestamp unit (minutes/seconds)", default="minutes")
    scenario_name = typer.prompt("Scenario name", default="Imported CGM Scenario")
    output_dir = Path(typer.prompt("Output directory", default="results/imported"))

    try:
        result = scenario_from_csv(
            input_csv,
            scenario_name=scenario_name,
            data_format=data_format,
            column_map=mapping or None,
            time_unit=time_unit,
        )
    except Exception as exc:
        console.print(f"[bold red]Import failed: {exc}[/bold red]")
        raise typer.Exit(code=1)

    output_dir.mkdir(parents=True, exist_ok=True)
    scenario_path = output_dir / "scenario.json"
    data_path = output_dir / "cgm_standard.csv"

    scenario_path.write_text(json.dumps(result.scenario, indent=2))
    export_standard_csv(result.dataframe, data_path)

    console.print(f"[green]Scenario saved:[/green] {scenario_path}")
    console.print(f"[green]Standard CSV saved:[/green] {data_path}")
    console.print(f"Rows: {len(result.dataframe)} | Meal events: {len(result.scenario.get('stress_events', []))}")


@app.command(name="import-demo")
def import_demo(
    output_dir: Annotated[Path, typer.Option(help="Output directory for scenario + CSV")] = Path("./results/demo_import"),
    scenario_name: Annotated[str, typer.Option(help="Scenario name")] = "Demo CGM Scenario",
    export_raw: Annotated[bool, typer.Option(help="Export the raw demo CSV into output dir")] = True,
):
    """Generate a ready-to-run scenario from the bundled demo CGM data pack."""
    console = Console()
    demo_df = load_demo_dataframe()
    standard_df = import_cgm_dataframe(demo_df, data_format="generic", source="demo")
    scenario = scenario_from_dataframe(standard_df, scenario_name=scenario_name)

    output_dir.mkdir(parents=True, exist_ok=True)
    scenario_path = output_dir / "scenario.json"
    data_path = output_dir / "cgm_standard.csv"

    scenario_path.write_text(json.dumps(scenario, indent=2))
    export_standard_csv(standard_df, data_path)
    if export_raw:
        export_demo_csv(output_dir / "demo_cgm.csv")

    console.print(f"[green]Scenario saved:[/green] {scenario_path}")
    console.print(f"[green]Standard CSV saved:[/green] {data_path}")
    if export_raw:
        console.print(f"[green]Raw demo CSV saved:[/green] {output_dir / 'demo_cgm.csv'}")


@app.command(name="import-nightscout")
def import_nightscout_cmd(
    url: Annotated[str, typer.Option(help="Nightscout base URL. Use https for non-local hosts.")],
    output_dir: Annotated[Path, typer.Option(help="Output directory for scenario + CSV")] = Path("./results/nightscout_import"),
    api_secret: Annotated[Optional[str], typer.Option(help="API secret (if required)")] = None,
    api_secret_env: Annotated[Optional[str], typer.Option(help="Environment variable name containing the Nightscout API secret.")] = None,
    api_secret_file: Annotated[Optional[Path], typer.Option(help="Path to a file containing the Nightscout API secret.")] = None,
    token: Annotated[Optional[str], typer.Option(help="API token (if required)")] = None,
    token_env: Annotated[Optional[str], typer.Option(help="Environment variable name containing the Nightscout API token.")] = None,
    token_file: Annotated[Optional[Path], typer.Option(help="Path to a file containing the Nightscout API token.")] = None,
    start: Annotated[Optional[str], typer.Option(help="Start time (ISO string)")] = None,
    end: Annotated[Optional[str], typer.Option(help="End time (ISO string)")] = None,
    limit: Annotated[Optional[int], typer.Option(help="Limit number of entries")] = None,
    scenario_name: Annotated[str, typer.Option(help="Scenario name")] = "Nightscout Import",
):
    """Import CGM entries from Nightscout into a scenario + standard CSV."""
    console = Console()
    resolved_api_secret = _resolve_secret_option(
        console=console,
        label="api_secret",
        direct_value=api_secret,
        env_name=api_secret_env,
        file_path=api_secret_file,
    )
    resolved_token = _resolve_secret_option(
        console=console,
        label="token",
        direct_value=token,
        env_name=token_env,
        file_path=token_file,
    )
    config = NightscoutConfig(
        url=url,
        api_secret=resolved_api_secret,
        token=resolved_token,
        start=start,
        end=end,
        limit=limit,
    )
    try:
        result = import_nightscout(config, scenario_name=scenario_name)
    except ImportError as exc:
        console.print(f"[bold red]{exc}[/bold red]")
        raise typer.Exit(code=1)
    except Exception as exc:
        console.print(f"[bold red]Nightscout import failed: {exc}[/bold red]")
        raise typer.Exit(code=1)

    output_dir.mkdir(parents=True, exist_ok=True)
    scenario_path = output_dir / "scenario.json"
    data_path = output_dir / "cgm_standard.csv"
    scenario_path.write_text(json.dumps(result.scenario, indent=2))
    export_standard_csv(result.dataframe, data_path)
    console.print(f"[green]Scenario saved:[/green] {scenario_path}")
    console.print(f"[green]Standard CSV saved:[/green] {data_path}")


@app.command(name="import-tidepool")
def import_tidepool_cmd(
    base_url: Annotated[str, typer.Option(help="Tidepool API base URL. Use https for non-local hosts.")] = "https://api.tidepool.org",
    token: Annotated[Optional[str], typer.Option(help="Bearer token")] = None,
    token_env: Annotated[Optional[str], typer.Option(help="Environment variable name containing the Tidepool bearer token.")] = None,
    token_file: Annotated[Optional[Path], typer.Option(help="Path to a file containing the Tidepool bearer token.")] = None,
):
    """Skeleton Tidepool client for future cloud imports."""
    console = Console()
    resolved_token = _resolve_secret_option(
        console=console,
        label="token",
        direct_value=token,
        env_name=token_env,
        file_path=token_file,
    )
    client = TidepoolClient(base_url=base_url, token=resolved_token)
    try:
        _ = client._headers()
    except Exception as exc:
        console.print(f"[bold red]{exc}[/bold red]")
        raise typer.Exit(code=1)
    console.print("[yellow]Tidepool client skeleton is initialized. Auth flow and endpoints are TODO.[/yellow]")

@app.command(name="check-deps")
def check_deps():
    """Check optional dependencies and report readiness."""
    console = Console()

    def has(module: str) -> bool:
        return importlib.util.find_spec(module) is not None

    checks = [
        ("Simulator", True, "Core simulation engine"),
        ("Metrics", has("numpy") and has("pandas"), "Clinical metrics"),
        ("Reporting", has("matplotlib") and has("fpdf"), "PDF reports"),
        ("Validation", has("pydantic"), "Schema validation"),
        ("Deep Learning", has("torch"), "AI models (install with `pip install iints[torch]`)"),
    ]

    table = Table(title="IINTS Dependency Check", show_lines=False)
    table.add_column("Component", style="cyan")
    table.add_column("Status", style="green")
    table.add_column("Notes")

    for name, ok, notes in checks:
        status = "OK" if ok else "Missing"
        table.add_row(name, status, notes)

    console.print(table)


@algorithms_app.command(name="list")
def algorithms_list():
    """List available algorithm plugins and built-ins."""
    console = Console()
    entries = list_algorithm_plugins()
    table = Table(title="IINTS Algorithms", show_header=True, header_style="bold cyan")
    table.add_column("Name", style="green")
    table.add_column("Source", style="magenta")
    table.add_column("Status", style="yellow")
    table.add_column("Class", style="white")
    for entry in entries:
        table.add_row(
            entry.name,
            entry.source,
            entry.status,
            entry.class_path,
        )
    console.print(table)


@algorithms_app.command(name="info")
def algorithms_info(
    name: Annotated[str, typer.Argument(help="Algorithm display name")],
):
    """Show metadata for a specific algorithm."""
    console = Console()
    entries = list_algorithm_plugins()
    matches = [entry for entry in entries if entry.name.lower() == name.lower()]
    if not matches:
        console.print(f"[bold red]Algorithm '{name}' not found.[/bold red]")
        raise typer.Exit(code=1)
    entry = matches[0]
    console.print(f"[bold]Name:[/bold] {entry.name}")
    console.print(f"[bold]Source:[/bold] {entry.source}")
    console.print(f"[bold]Status:[/bold] {entry.status}")
    console.print(f"[bold]Class:[/bold] {entry.class_path}")
    if entry.error:
        console.print(f"[bold red]Error:[/bold red] {entry.error}")
    if entry.metadata:
        console.print_json(json.dumps(entry.metadata.to_dict(), indent=2))
@docs_app.command(name="algo")
def docs_algo(
    algo_path: Annotated[Path, typer.Option(help="Path to the algorithm Python file to document")],
):
    """
    Generates a technical summary (auto-documentation) for a specified InsulinAlgorithm.
    """
    console = Console()
    console.print(f"[bold blue]Generating Auto-Documentation for Algorithm: {algo_path.name}[/bold blue]")

    if not algo_path.is_file():
        console.print(f"[bold red]Error: Algorithm file '{algo_path}' not found.[/bold red]")
        raise typer.Exit(code=1)
    try:
        algorithm_class = _load_algorithm_class_silent(algo_path)
        algorithm_instance = algorithm_class()
    except Exception as e:
        console.print(f"[bold red]Error loading algorithm module {algo_path}: {e}[/bold red]")
        raise typer.Exit(code=1)
    
    if algorithm_instance is None:
        console.print(f"[bold red]Error: No subclass of InsulinAlgorithm found in {algo_path}[/bold red]")
        raise typer.Exit(code=1)
    
    # Extract Metadata
    metadata = algorithm_instance.get_algorithm_metadata()

    # Ensure algorithm_class is not None (it shouldn't be if algorithm_instance is not None)
    assert algorithm_class is not None
    algorithm_class = cast(type[iints.InsulinAlgorithm], algorithm_class)

    # Extract class docstring
    class_doc = algorithm_class.__doc__ if algorithm_class.__doc__ else "No class docstring available."

    # Extract predict_insulin docstring
    predict_insulin_doc = algorithm_class.predict_insulin.__doc__ if algorithm_class.predict_insulin.__doc__ else "No docstring for predict_insulin method."

    console.print(Panel(
        f"[bold blue]Algorithm Overview[/bold blue]\n\n"
        f"[green]Name:[/green] {metadata.name}\n"
        f"[green]Version:[/green] {metadata.version}\n"
        f"[green]Author:[/green] {metadata.author}\n"
        f"[green]Type:[/green] {metadata.algorithm_type}\n"
        f"[green]Description:[/green] {metadata.description}\n"
        f"[green]Requires Training:[/green] {metadata.requires_training}\n"
        f"[green]Supported Scenarios:[/green] {', '.join(metadata.supported_scenarios)}\n\n"
        f"[bold blue]Class Documentation[/bold blue]\n"
        f"{class_doc}\n\n"
        f"[bold blue]predict_insulin Method Documentation[/bold blue]\n"
        f"{predict_insulin_doc}",
        title=f"Auto-Doc: {metadata.name}",
        border_style="blue"
    ))

@app.command()
def benchmark(
    algo_to_benchmark: Annotated[Path, typer.Option(help="Path to the AI algorithm Python file to benchmark")],
    # standard_pump_config: Annotated[str, typer.Option(help="Name of the standard pump patient config (e.g., 'default')")] = "default", # This will be loaded implicitly for the standard pump
    patient_configs_dir: Annotated[Path, typer.Option(help="Directory containing patient configuration YAML files")] = Path("src/iints/data/virtual_patients"),
    scenarios_dir: Annotated[Path, typer.Option(help="Directory containing scenario JSON files")] = Path("scenarios"),
    duration: Annotated[int, typer.Option(help="Simulation duration in minutes for each run")] = 720, # 12 hours
    time_step: Annotated[int, typer.Option(help="Simulation time step in minutes")] = 5,
    output_dir: Annotated[Optional[Path], typer.Option(help="Directory to save all benchmark results")] = None,
    seed: Annotated[Optional[int], typer.Option(help="Base seed for deterministic runs")] = None,
):
    """
    Runs a series of simulations to benchmark an AI algorithm against a standard pump
    across multiple patient configurations and scenarios.
    """
    console = Console()
    resolved_seed = resolve_seed(seed)
    run_id = generate_run_id(resolved_seed)
    output_dir = resolve_output_dir(output_dir, run_id)
    console.print(f"[bold blue]Starting IINTS-AF Benchmark Suite[/bold blue]")
    console.print(f"AI Algorithm: [green]{algo_to_benchmark.name}[/green]")
    # console.print(f"Standard Pump Config: [yellow]{standard_pump_config}[/yellow]") # Removed, as standard pump uses patient params
    console.print(f"Patient Configs from: [cyan]{patient_configs_dir}[/cyan]")
    console.print(f"Scenarios from: [magenta]{scenarios_dir}[/magenta]")
    console.print(f"Duration: {duration} min, Time Step: {time_step} min")
    console.print(f"Run ID: {run_id}")
    console.print(f"Output directory: {output_dir}")

    if not algo_to_benchmark.is_file():
        console.print(f"[bold red]Error: AI Algorithm file '{algo_to_benchmark}' not found.[/bold red]")
        raise typer.Exit(code=1)
    if not patient_configs_dir.is_dir():
        console.print(f"[bold red]Error: Patient configurations directory '{patient_configs_dir}' not found.[/bold red]")
        raise typer.Exit(code=1)
    if not scenarios_dir.is_dir():
        console.print(f"[bold red]Error: Scenarios directory '{scenarios_dir}' not found.[/bold red]")
        raise typer.Exit(code=1)
    
    # Ensure output directory exists
    output_dir.mkdir(parents=True, exist_ok=True)

    config_payload = {
        "run_type": "benchmark",
        "run_id": run_id,
        "algorithm_path": str(algo_to_benchmark),
        "patient_configs_dir": str(patient_configs_dir),
        "scenarios_dir": str(scenarios_dir),
        "duration_minutes": duration,
        "time_step_minutes": time_step,
        "seed": resolved_seed,
    }
    config_path = output_dir / "config.json"
    write_json(config_path, config_payload)
    run_metadata = build_run_metadata(run_id, resolved_seed, config_payload, output_dir)
    run_metadata_path = output_dir / "run_metadata.json"
    write_json(run_metadata_path, run_metadata)

    # Load AI Algorithm
    try:
        ai_algo_instance = _load_algorithm_instance_silent(algo_to_benchmark)
    except Exception as e:
        console.print(f"[bold red]Error loading AI algorithm module {algo_to_benchmark}: {e}[/bold red]")
        raise typer.Exit(code=1)
    if ai_algo_instance is None:
        console.print(f"[bold red]Error: No subclass of InsulinAlgorithm found in AI algorithm {algo_to_benchmark}[/bold red]")
        raise typer.Exit(code=1)
    console.print(f"Loaded AI Algorithm: [green]{ai_algo_instance.get_algorithm_metadata().name}[/green]")

    # Get compute device
    device_manager = iints.DeviceManager()
    device = device_manager.get_device()
    console.print(f"Using compute device: [blue]{device}[/blue]")

    # Collect patient configurations and scenarios
    patient_config_files = list(patient_configs_dir.glob("*.yaml"))
    scenario_files = list(scenarios_dir.glob("*.json"))

    if not patient_config_files:
        console.print(f"[bold red]Error: No patient configuration files found in '{patient_configs_dir}'[/bold red]")
        raise typer.Exit(code=1)
    if not scenario_files:
        console.print(f"[bold red]Error: No scenario files found in '{scenarios_dir}'[/bold red]")
        raise typer.Exit(code=1)

    benchmark_results = []
    run_index = 0

    # Iterate through patients and scenarios
    for patient_config_file in patient_config_files:
        patient_config_name = patient_config_file.stem
        try:
            with open(patient_config_file, 'r') as f:
                patient_params = yaml.safe_load(f)
            console.print(f"\n[bold underline]Benchmarking Patient: {patient_config_name}[/bold underline]")
        except yaml.YAMLError as e:
            console.print(f"[bold red]Error parsing patient configuration '{patient_config_file.name}': {e}[/bold red]")
            continue # Skip this patient

        for scenario_file in scenario_files:
            scenario_name = scenario_file.stem
            console.print(f"  [bold]Scenario: {scenario_name}[/bold]")
            
            # Load Scenario Data (validated)
            try:
                scenario_model = load_scenario(scenario_file)
                payloads = scenario_to_payloads(scenario_model)
                stress_events = build_stress_events(payloads)
            except ValidationError as e:
                console.print(f"[bold red]  Scenario validation failed: {scenario_file.name}[/bold red]")
                for line in format_validation_error(e):
                    console.print(f"  - {line}")
                continue
            except Exception as e:
                console.print(f"[bold red]  Error loading scenario '{scenario_file.name}': {e}[/bold red]")
                continue # Skip this scenario

            job_seed = resolved_seed + run_index
            # --- Run AI Algorithm Simulation ---
            console.print(f"    Running [green]{ai_algo_instance.get_algorithm_metadata().name}[/green]...")
            patient_model_ai = iints.PatientModel(**patient_params) # New instance for each run
            simulator_ai = iints.Simulator(
                patient_model=patient_model_ai,
                algorithm=ai_algo_instance,
                time_step=time_step,
                seed=job_seed,
            )
            for event in stress_events:
                simulator_ai.add_stress_event(event)
            
            try:
                results_df_ai, safety_report_ai = simulator_ai.run_batch(duration)
                metrics_ai = iints.generate_benchmark_metrics(results_df_ai)
            except Exception as e:
                console.print(f"[bold red]      AI Simulation failed: {e}[/bold red]")
                # Provide dummy metrics for failed simulations to allow table generation
                metrics_ai = {"TIR (%)": float('nan'), "Hypoglycemia (<70 mg/dL) (%)": float('nan'),
                              "Hyperglycemia (>180 mg/dL) (%)": float('nan'), "Avg Glucose (mg/dL)": float('nan')}
                safety_report_ai = {'num_violations': float('nan')} # Dummy report

            # --- Run Standard Pump Algorithm Simulation ---
            console.print(f"    Running [yellow]Standard Pump[/yellow]...") # Use name directly
            # The standard pump also needs patient-specific parameters for ISF, ICR, basal rate, etc.
            # We'll pass the patient_params directly to the StandardPumpAlgorithm constructor.
            standard_pump_algo_instance = iints.StandardPumpAlgorithm(settings=patient_params) 
            patient_model_std = iints.PatientModel(**patient_params) # New instance for each run
            simulator_std = iints.Simulator(
                patient_model=patient_model_std,
                algorithm=standard_pump_algo_instance,
                time_step=time_step,
                seed=job_seed,
            )
            for event in stress_events:
                simulator_std.add_stress_event(event)
            
            try:
                results_df_std, safety_report_std = simulator_std.run_batch(duration)
                metrics_std = iints.generate_benchmark_metrics(results_df_std)
            except Exception as e:
                console.print(f"[bold red]      Standard Pump Simulation failed: {e}[/bold red]")
                # Provide dummy metrics for failed simulations
                metrics_std = {"TIR (%)": float('nan'), "Hypoglycemia (<70 mg/dL) (%)": float('nan'),
                               "Hyperglycemia (>180 mg/dL) (%)": float('nan'), "Avg Glucose (mg/dL)": float('nan')}
                safety_report_std = {'num_violations': float('nan')} # Dummy report


            # Store results
            benchmark_results.append({
                "run_id": run_id,
                "seed": job_seed,
                "Patient": patient_config_name,
                "Scenario": scenario_name,
                "AI Algo": ai_algo_instance.get_algorithm_metadata().name,
                **{f"AI {k}": v for k, v in metrics_ai.items()},
                **{f"AI Safety Violations": safety_report_ai.get('total_violations', float('nan'))},
                "Standard Algo": standard_pump_algo_instance.get_algorithm_metadata().name,
                **{f"Std {k}": v for k, v in metrics_std.items()},
                **{f"Std Safety Violations": safety_report_std.get('total_violations', float('nan'))},
            })
            run_index += 1
    
    console.print("\n[bold green]Benchmark Suite Completed![/bold green]")

    # Print Comparison Table
    if benchmark_results:
        results_df = pd.DataFrame(benchmark_results)
        
        table = Table(title="IINTS-AF Benchmark Results", show_header=True, header_style="bold magenta")
        
        # Add columns dynamically
        table.add_column("Patient", style="cyan", no_wrap=True)
        table.add_column("Scenario", style="cyan", no_wrap=True)
        
        # Assuming AI Algo and Standard Algo names are consistent across results
        ai_algo_name = benchmark_results[0]["AI Algo"]
        std_algo_name = benchmark_results[0]["Standard Algo"]

        # Get a sample of metric keys (excluding 'AI Algo', 'Standard Algo')
        # Fix: Filter out non-metric keys like 'AI Algo'
        sample_metrics_keys_raw = [k.replace('AI ', '') for k in benchmark_results[0].keys() if k.startswith('AI ') and 'Algo' not in k and 'Violations' not in k]

        for metric_name_raw in sample_metrics_keys_raw:
            table.add_column(f"{ai_algo_name} {metric_name_raw}", style="green")
            table.add_column(f"{std_algo_name} {metric_name_raw}", style="yellow")
        
        table.add_column(f"{ai_algo_name} Safety Violations", style="red")
        table.add_column(f"{std_algo_name} Safety Violations", style="red")

        for _, row in results_df.iterrows():
            row_data = [str(row["Patient"]), str(row["Scenario"])]
            for metric_name_raw in sample_metrics_keys_raw:
                ai_val = row[f'AI {metric_name_raw}']
                std_val = row[f'Std {metric_name_raw}']
                
                ai_formatted = f"{ai_val:.2f}%" if "%" in metric_name_raw and not pd.isna(ai_val) else (f"{ai_val:.2f}" if not pd.isna(ai_val) else "N/A")
                std_formatted = f"{std_val:.2f}%" if "%" in metric_name_raw and not pd.isna(std_val) else (f"{std_val:.2f}" if not pd.isna(std_val) else "N/A")
                
                row_data.append(ai_formatted)
                row_data.append(std_formatted)
            
            ai_safety_violations = row['AI Safety Violations']
            std_safety_violations = row['Std Safety Violations']
            row_data.append(f"{ai_safety_violations:.0f}" if not pd.isna(ai_safety_violations) else "N/A")
            row_data.append(f"{std_safety_violations:.0f}" if not pd.isna(std_safety_violations) else "N/A")
            table.add_row(*row_data)

        console.print(table)

        results_csv = output_dir / "benchmark_summary.csv"
        results_df.to_csv(results_csv, index=False)
        console.print(f"[green]Benchmark summary saved:[/green] {results_csv}")

        manifest_files = {
            "config": config_path,
            "run_metadata": run_metadata_path,
            "benchmark_summary": results_csv,
        }
        run_manifest = build_run_manifest(output_dir, manifest_files)
        run_manifest_path = output_dir / "run_manifest.json"
        write_json(run_manifest_path, run_manifest)
        console.print(f"Run manifest: {run_manifest_path}")
        signature_path = maybe_sign_manifest(run_manifest_path)
        if signature_path:
            console.print(f"Run manifest signature: {signature_path}")
    else:
        console.print("[yellow]No benchmark results were generated.[/yellow]")


@app.command(name="edge-benchmark")
def edge_benchmark(
    algo: Annotated[Path, typer.Option(help="Path to the insulin algorithm Python file used for the edge benchmark.")],
    output_json: Annotated[Path, typer.Option(help="Output JSON path for the hardware benchmark results.")] = Path("results/edge_benchmark.json"),
    patient_config: Annotated[str, typer.Option(help="Patient configuration name or YAML path.")] = "default_patient",
    patient_model: Annotated[str, typer.Option("--patient-model", help="Patient model type.")] = "auto",
    scenario_profile: Annotated[str, typer.Option(help="Digital patient scenario profile.")] = "normal_day",
    steps: Annotated[int, typer.Option(help="Number of simulated steps used for throughput measurement.")] = 72,
    platform_name: Annotated[str, typer.Option("--platform", help="Platform label written into the benchmark report. Use 'auto' to detect locally.")] = "auto",
    api_host: Annotated[str, typer.Option(help="Host used for the local dashboard probe.")] = "127.0.0.1",
    api_port: Annotated[int, typer.Option(help="Port used for the local dashboard probe.")] = 8766,
    seed: Annotated[Optional[int], typer.Option(help="Optional deterministic seed override.")] = None,
) -> None:
    """Measure digital-patient throughput, memory use, and dashboard response time on edge hardware."""
    console = Console()
    if not algo.is_file():
        console.print(f"[bold red]Algorithm file '{algo}' not found.[/bold red]")
        raise typer.Exit(code=1)

    try:
        payload = run_edge_benchmark(
            algo_path=algo,
            patient_config=patient_config,
            patient_model_type=patient_model,
            scenario_profile=scenario_profile,
            steps=steps,
            platform_name=platform_name,
            api_host=api_host,
            api_port=api_port,
            seed=seed,
        )
    except Exception as exc:
        console.print(f"[bold red]Edge benchmark failed:[/bold red] {exc}")
        raise typer.Exit(code=1)

    output_json.parent.mkdir(parents=True, exist_ok=True)
    output_json.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    runtime = payload["runtime"]
    dashboard = payload["dashboard"]
    table = Table(title="IINTS Edge Benchmark")
    table.add_column("Metric", style="cyan")
    table.add_column("Value")
    table.add_row("Platform", str(payload["platform"]))
    table.add_row("Scenario", str(payload["scenario_profile"]))
    table.add_row("Seed", str(payload["seed"]))
    table.add_row("Steps / second", f"{runtime['steps_per_second']:.2f}")
    table.add_row("Mean step latency", f"{runtime['mean_step_latency_ms']:.2f} ms")
    table.add_row("Peak process memory", f"{runtime['peak_process_memory_mb']:.2f} MB")
    table.add_row("Dashboard response", f"{dashboard['dashboard_response_ms']['mean_ms']:.2f} ms")
    table.add_row("Status response", f"{dashboard['status_response_ms']['mean_ms']:.2f} ms")
    console.print(table)
    console.print(f"[green]Edge benchmark JSON written:[/green] {output_json}")


def _parse_edge_speed(value: str | float) -> float:
    if isinstance(value, (int, float)):
        parsed = float(value)
    else:
        text = str(value).strip().lower()
        if text.endswith("x"):
            text = text[:-1]
        parsed = float(text)
    if parsed <= 0.0:
        raise typer.BadParameter("Speed must be a positive number such as 60 or 60x.")
    return parsed


def _resolve_edge_project_dir(project_dir: Path) -> Path:
    return project_dir.expanduser().resolve()


def _resolve_edge_workspace(
    *,
    project_dir: Path | None = None,
    workspace: Path | None = None,
    workspace_name: str = "patient_runtime",
) -> Path:
    if workspace is not None:
        return workspace.expanduser().resolve()
    if project_dir is not None:
        return _resolve_edge_project_dir(project_dir) / workspace_name
    return Path("./digital_patient_runtime").expanduser().resolve()


def _load_edge_project_config(project_dir: Path, workspace_name: str = "patient_runtime") -> PatientRuntimeConfig:
    root = _resolve_edge_project_dir(project_dir)
    config_path = root / workspace_name / "patient_runtime_config.json"
    if not config_path.is_file():
        raise FileNotFoundError(
            f"No edge runtime config found at {config_path}. "
            "Run `iints edge setup` first."
        )
    return PatientRuntimeConfig.from_path(config_path)


def _detect_edge_board(project_dir: Path) -> str:
    root = _resolve_edge_project_dir(project_dir)
    return "uno_q" if (root / "uno_q_bridge").is_dir() else "raspberry_pi"


def _makerfaire_runtime_snapshot(
    *,
    cfg: PatientRuntimeConfig,
    scenario_profile: str,
    seed: int | None,
) -> dict[str, Any]:
    workspace = Path(cfg.workspace).expanduser().resolve()
    summary = summarize_edge_workspace(workspace)
    if summary:
        payload = dict(summary)
        payload["scenario_profile"] = scenario_profile
        payload["active_seed"] = seed if seed is not None else payload.get("active_seed", cfg.seed)
        return payload
    return {
        "daemon_status": "starting",
        "workspace": str(workspace),
        "api_host": cfg.api_host,
        "api_port": cfg.api_port,
        "dashboard_url": cfg.dashboard_url,
        "kiosk_url": f"http://{cfg.api_host}:{cfg.api_port}/kiosk",
        "scenario_profile": scenario_profile,
        "active_seed": seed if seed is not None else cfg.seed,
        "algorithm_name": Path(cfg.algo_path).stem,
    }


@edge_app.command(name="setup")
def edge_setup(
    output_dir: Annotated[Path, typer.Option(help="Directory where the edge-ready project scaffold should be written.")] = Path("iints_edge_demo"),
    board: Annotated[str, typer.Option(help="Edge board target: raspberry_pi or uno_q.")] = "raspberry_pi",
    workspace_name: Annotated[str, typer.Option(help="Workspace folder name used for the persistent patient runtime.")] = "patient_runtime",
    scenario_profile: Annotated[str, typer.Option(help="Initial live scenario profile.")] = "normal_day",
    patient_config: Annotated[str, typer.Option(help="Patient configuration name or YAML path.")] = "default_patient",
    patient_model: Annotated[str, typer.Option("--patient-model", help="Patient model type.")] = "auto",
    mode: Annotated[str, typer.Option(help="Clock mode for the generated edge project.")] = "demo-time",
    speed: Annotated[str, typer.Option(help="Acceleration factor for demo-time mode. Accepts 60 or 60x.")] = "60x",
    api_host: Annotated[str, typer.Option(help="Dashboard host to bake into the generated runtime config.")] = "127.0.0.1",
    api_port: Annotated[int, typer.Option(help="Dashboard port to bake into the generated runtime config.")] = 8765,
    seed: Annotated[Optional[int], typer.Option(help="Optional deterministic seed override.")] = None,
    service_name: Annotated[str, typer.Option(help="systemd service name without the .service suffix.")] = "iints-digital-patient",
    user_name: Annotated[Optional[str], typer.Option(help="Linux user that should own the generated systemd service.")] = None,
    uno_bridge_port: Annotated[Optional[str], typer.Option(help="Optional UNO Q serial port to bake into a generated bridge systemd service.")] = None,
    uno_bridge_service_name: Annotated[str, typer.Option(help="UNO Q bridge systemd service name without the .service suffix.")] = "iints-uno-q-bridge",
) -> None:
    console = Console()
    normalized_board = board.strip().lower()
    if normalized_board not in {"raspberry_pi", "uno_q"}:
        console.print("[bold red]Unsupported board. Use `raspberry_pi` or `uno_q`.[/bold red]")
        raise typer.Exit(code=1)

    outputs = export_edge_setup(
        output_dir,
        board=normalized_board,
        workspace_name=workspace_name,
        scenario_profile=scenario_profile,
        patient_config=patient_config,
        patient_model_type=patient_model,
        mode=mode,
        speed=_parse_edge_speed(speed),
        api_host=api_host,
        api_port=api_port,
        seed=seed,
        service_name=service_name,
        user_name=user_name,
        include_uno_bridge=normalized_board == "uno_q" or uno_bridge_port is not None,
        uno_bridge_port=uno_bridge_port,
        uno_bridge_service_name=uno_bridge_service_name,
    )

    table = Table(title="IINTS Edge Setup")
    table.add_column("Artifact", style="cyan")
    table.add_column("Path", overflow="fold")
    for key in [
        "root",
        "algorithm",
        "workspace",
        "config",
        "run_script",
        "kiosk_script",
        "makerfaire_script",
        "makerfaire_guide",
        "makerfaire_kiosk_script",
        "makerfaire_desktop_entry",
        "makerfaire_autostart_script",
        "makerfaire_autostart_guide",
        "makerfaire_watchdog_script",
        "makerfaire_watchdog_service",
        "makerfaire_watchdog_timer",
        "makerfaire_checklist",
        "remote_access_guide",
        "long_study_template",
        "update_script",
        "service_file",
        "service_notes",
        "setup_guide",
    ]:
        table.add_row(key, outputs[key])
    if "uno_q_bridge" in outputs:
        table.add_row("uno_q_bridge", outputs["uno_q_bridge"])
    if "uno_bridge_service" in outputs:
        table.add_row("uno_bridge_service", outputs["uno_bridge_service"])
    if "uno_bridge_service_notes" in outputs:
        table.add_row("uno_bridge_service_notes", outputs["uno_bridge_service_notes"])
    console.print(table)
    console.print(
        Panel(
            "\n".join(
                [
                    f"Board profile: {normalized_board}",
                    f"CLI start: iints edge up --project-dir {outputs['root']}",
                    f"Maker Faire start: iints makerfaire up --project-dir {outputs['root']}",
                    f"Maker Faire autostart: iints makerfaire autostart --project-dir {outputs['root']}",
                    f"Maker Faire watchdog: iints makerfaire watchdog --project-dir {outputs['root']}",
                    f"CLI kiosk: iints edge kiosk --project-dir {outputs['root']}",
                    f"Setup guide: {outputs['setup_guide']}",
                    f"Remote guide: {outputs['remote_access_guide']}",
                    f"Long study config: {outputs['long_study_template']}",
                ]
            ),
            title="Edge Setup Ready",
            border_style="green",
        )
    )


@edge_app.command(name="deploy")
def edge_deploy(
    host: Annotated[str, typer.Option(help="Remote Raspberry Pi hostname or IP address.")],
    user_name: Annotated[Optional[str], typer.Option("--user", help="Optional remote SSH username.")] = None,
    ssh_port: Annotated[int, typer.Option(help="SSH port used for the remote Raspberry Pi.")] = 22,
    remote_dir: Annotated[str, typer.Option(help="Target project directory on the Raspberry Pi.")] = "~/iints_pi_demo",
    local_output_dir: Annotated[Path, typer.Option(help="Local scaffold directory that will also be synced to the Pi.")] = Path("iints_pi_demo"),
    board: Annotated[str, typer.Option(help="Edge board target: raspberry_pi or uno_q.")] = "raspberry_pi",
    workspace_name: Annotated[str, typer.Option(help="Workspace folder name used for the persistent patient runtime.")] = "patient_runtime",
    scenario_profile: Annotated[str, typer.Option(help="Initial live scenario profile deployed to the Pi.")] = "expo_hot_start",
    patient_config: Annotated[str, typer.Option(help="Patient configuration name or YAML path.")] = "default_patient",
    patient_model: Annotated[str, typer.Option("--patient-model", help="Patient model type.")] = "auto",
    mode: Annotated[str, typer.Option(help="Clock mode for the generated edge project.")] = "demo-time",
    speed: Annotated[str, typer.Option(help="Acceleration factor for demo-time mode. Accepts 60 or 60x.")] = "60x",
    api_host: Annotated[str, typer.Option(help="Dashboard host to bake into the generated runtime config. Keep 127.0.0.1 when using Raspberry Pi Connect.")] = "127.0.0.1",
    api_port: Annotated[int, typer.Option(help="Dashboard port to bake into the generated runtime config.")] = 8765,
    seed: Annotated[Optional[int], typer.Option(help="Optional deterministic seed override.")] = None,
    service_name: Annotated[str, typer.Option(help="systemd service name without the .service suffix.")] = "iints-digital-patient",
    install_autostart: Annotated[bool, typer.Option(help="Install the generated systemd service, watchdog timer, and desktop autostart on the Pi.")] = True,
    start_runtime: Annotated[bool, typer.Option(help="Start the Maker Faire runtime after deployment.")] = True,
    enable_connect_linger: Annotated[bool, typer.Option(help="Run `loginctl enable-linger` on the Pi so Raspberry Pi Connect remote shell keeps working after reboots.")] = True,
    ssh_timeout_seconds: Annotated[float, typer.Option(help="Timeout per remote SSH step in seconds.")] = 300.0,
    ssh_retries: Annotated[int, typer.Option(help="How many times to retry a failing SSH step before giving up.")] = 1,
    uno_bridge_port: Annotated[Optional[str], typer.Option(help="Optional UNO Q serial port on the Pi, for example /dev/ttyACM0. Generates and installs a bridge service.")] = None,
    uno_bridge_service_name: Annotated[str, typer.Option(help="UNO Q bridge systemd service name without the .service suffix.")] = "iints-uno-q-bridge",
    flash_uno_bridge: Annotated[bool, typer.Option(help="Flash the UNO Q bridge sketch remotely after syncing the project. Requires --uno-bridge-port and --uno-fqbn.")] = False,
    uno_fqbn: Annotated[Optional[str], typer.Option(help="Arduino CLI FQBN used when --flash-uno-bridge is enabled.")] = None,
    arduino_cli: Annotated[str, typer.Option(help="Arduino CLI executable name or path on the Raspberry Pi.")] = "arduino-cli",
    dry_run: Annotated[bool, typer.Option(help="Show the remote deployment plan without executing SSH commands.")] = False,
    verbose: Annotated[bool, typer.Option(help="Print the raw remote SSH command and deploy stdout for debugging.")] = False,
) -> None:
    console = Console()
    normalized_board = board.strip().lower()
    if normalized_board not in {"raspberry_pi", "uno_q"}:
        console.print("[bold red]Unsupported board. Use `raspberry_pi` or `uno_q`.[/bold red]")
        raise typer.Exit(code=1)
    if flash_uno_bridge and (not uno_bridge_port or not uno_fqbn):
        console.print("[bold red]Remote UNO Q flashing needs both --uno-bridge-port and --uno-fqbn.[/bold red]")
        raise typer.Exit(code=1)

    try:
        payload = deploy_edge_project(
            host=host,
            user_name=user_name,
            ssh_port=ssh_port,
            remote_dir=remote_dir,
            local_output_dir=local_output_dir,
            board=normalized_board,
            workspace_name=workspace_name,
            scenario_profile=scenario_profile,
            patient_config=patient_config,
            patient_model_type=patient_model,
            mode=mode,
            speed=_parse_edge_speed(speed),
            api_host=api_host,
            api_port=api_port,
            seed=seed,
            service_name=service_name,
            include_uno_bridge=normalized_board == "uno_q",
            uno_bridge_port=uno_bridge_port,
            uno_bridge_service_name=uno_bridge_service_name,
            install_autostart=install_autostart,
            start_runtime=start_runtime,
            enable_connect_linger=enable_connect_linger,
            flash_uno_bridge=flash_uno_bridge,
            uno_fqbn=uno_fqbn,
            arduino_cli=arduino_cli,
            dry_run=dry_run,
            ssh_timeout_seconds=ssh_timeout_seconds,
            ssh_retries=ssh_retries,
            progress_callback=lambda message: console.print(f"[cyan]→[/cyan] {message}"),
        )
    except Exception as exc:
        console.print(f"[bold red]Edge deployment failed:[/bold red] {exc}")
        raise typer.Exit(code=1)

    artifacts = payload["artifacts"]
    table = Table(title="IINTS Edge Remote Deploy")
    table.add_column("Field", style="cyan")
    table.add_column("Value", overflow="fold")
    rows = [
        ("remote_target", payload["destination"]),
        ("remote_project", payload["remote_dir"]),
        ("local_scaffold", payload["local_output_dir"]),
        ("board", payload["board"]),
        ("scenario_profile", payload["scenario_profile"]),
        ("mode", "dry-run only" if payload["dry_run"] else "live deploy"),
        ("remote_access", "Raspberry Pi Connect recommended"),
        ("remote_guide", artifacts["remote_access_guide"]),
        ("setup_guide", artifacts["setup_guide"]),
    ]
    if "uno_bridge_service" in artifacts:
        rows.append(("uno_bridge_service", artifacts["uno_bridge_service"]))
    for field, value in rows:
        table.add_row(str(field), str(value))
    console.print(table)

    console.print(
        Panel(
            "\n".join(
                [
                    (
                        "Dry run complete. Nothing was changed on the Raspberry Pi."
                        if payload["dry_run"]
                        else "The Pi project has been scaffolded, provisioned, and started."
                    ),
                    "For safe remote presentation, keep the dashboard on loopback and use Raspberry Pi Connect for screen sharing or remote shell.",
                    f"Remote status: {payload['remote_commands']['status']}",
                    f"Remote reset: {payload['remote_commands']['reset']}",
                    f"Remote stop: {payload['remote_commands']['stop']}",
                ]
            ),
            title="Remote Edge Deploy Ready" if not payload["dry_run"] else "Remote Edge Deploy Plan",
            border_style="green" if not payload["dry_run"] else "cyan",
        )
    )
    if verbose:
        console.print(f"[dim]SSH command:[/dim] {payload['deploy_command']}")
        if payload["deploy_stdout"]:
            console.print(
                Panel(
                    payload["deploy_stdout"],
                    title="Remote Deploy Output",
                    border_style="blue",
                )
            )


@edge_app.command(name="offline-bundle")
def edge_offline_bundle(
    output: Annotated[Path, typer.Option(help="Tarball written for offline USB-stick installs.")] = Path("iints_offline.tar.gz"),
    board: Annotated[str, typer.Option(help="Edge board target baked into the scaffold: raspberry_pi or uno_q.")] = "raspberry_pi",
    workspace_name: Annotated[str, typer.Option(help="Workspace folder name used for the persistent patient runtime.")] = "patient_runtime",
    scenario_profile: Annotated[str, typer.Option(help="Initial live scenario profile baked into the scaffold.")] = "expo_hot_start",
    patient_config: Annotated[str, typer.Option(help="Patient configuration name or YAML path.")] = "default_patient",
    patient_model: Annotated[str, typer.Option("--patient-model", help="Patient model type.")] = "auto",
    mode: Annotated[str, typer.Option(help="Clock mode baked into the generated edge project.")] = "demo-time",
    speed: Annotated[str, typer.Option(help="Acceleration factor for demo-time mode. Accepts 60 or 60x.")] = "60x",
    api_host: Annotated[str, typer.Option(help="Dashboard host baked into the runtime config. Keep 127.0.0.1 for Pi Connect setups.")] = "127.0.0.1",
    api_port: Annotated[int, typer.Option(help="Dashboard port baked into the runtime config.")] = 8765,
    seed: Annotated[Optional[int], typer.Option(help="Optional deterministic seed override.")] = None,
) -> None:
    console = Console()
    normalized_board = board.strip().lower()
    if normalized_board not in {"raspberry_pi", "uno_q"}:
        console.print("[bold red]Unsupported board. Use `raspberry_pi` or `uno_q`.[/bold red]")
        raise typer.Exit(code=1)
    try:
        outputs = build_edge_offline_bundle(
            output,
            board=normalized_board,
            workspace_name=workspace_name,
            scenario_profile=scenario_profile,
            patient_config=patient_config,
            patient_model_type=patient_model,
            mode=mode,
            speed=_parse_edge_speed(speed),
            api_host=api_host,
            api_port=api_port,
            seed=seed,
            include_uno_bridge=normalized_board == "uno_q",
            progress_callback=lambda message: console.print(f"[cyan]→[/cyan] {message}"),
        )
    except Exception as exc:
        console.print(f"[bold red]Offline bundle generation failed:[/bold red] {exc}")
        raise typer.Exit(code=1)

    table = Table(title="IINTS Offline Edge Bundle")
    table.add_column("Artifact", style="cyan")
    table.add_column("Value", overflow="fold")
    table.add_row("Archive", outputs["archive"])
    table.add_row("Install script", outputs["install_script"])
    table.add_row("Install guide", outputs["install_guide"])
    table.add_row("Package spec", outputs["package_spec"])
    console.print(table)
    console.print(f"Offline package: {outputs['package_spec']}", markup=False)


@edge_app.command(name="study")
def edge_study(
    algo: Annotated[Path, typer.Option(help="Path to the algorithm Python file.")],
    output_dir: Annotated[Path, typer.Option(help="Root directory for the Pi-generated study bundle.")] = Path("results/pi_study"),
    preset: Annotated[str, typer.Option(help="Study preset: default or eucys.")] = "default",
    profile_set: Annotated[str, typer.Option(help="Patient profile set to evaluate on the Pi.")] = DEFAULT_PROFILE_SET,
    scenarios: Annotated[str, typer.Option(help="Optional comma-separated scenario slugs to run.")] = "",
    seeds: Annotated[str, typer.Option(help="Comma-separated seed list.")] = "1,2,3,4,5",
    duration: Annotated[Optional[int], typer.Option(help="Override scenario duration in minutes.")] = None,
    time_step: Annotated[int, typer.Option(help="Simulation time step in minutes.")] = 5,
    include_default_baselines: Annotated[
        bool,
        typer.Option("--include-default-baselines/--no-include-default-baselines", help="Include the default baseline registry in the Pi study matrix."),
    ] = True,
    extra_algorithms: Annotated[str, typer.Option(help="Comma-separated additional comparison algorithm labels.")] = "",
    prepare_ai: Annotated[bool, typer.Option(help="Generate AI-ready artifacts for non-corrupted study arms.")] = False,
) -> None:
    console = Console()
    parsed_seeds = [int(item.strip()) for item in seeds.split(",") if item.strip()]
    if not parsed_seeds:
        console.print("[bold red]Please provide at least one seed.[/bold red]")
        raise typer.Exit(code=1)
    started_at = time.time()
    scenario_values = [item.strip() for item in scenarios.split(",") if item.strip()] or None
    extra_algorithm_values = [item.strip() for item in extra_algorithms.split(",") if item.strip()] or None
    try:
        outputs = _run_study_bundle(
            algo=algo,
            output_dir=output_dir,
            preset=preset.strip().lower(),
            scenarios=scenario_values,
            seeds=parsed_seeds,
            duration=duration,
            time_step=time_step,
            carelink_metrics=None,
            prepare_ai=prepare_ai,
            reference_csv=None,
            profile_set=profile_set,
            include_default_baselines=include_default_baselines,
            extra_algorithms=extra_algorithm_values,
            external_reference_label="Edge-local study run",
            gate_profile=None,
            gate_profiles_path=None,
            fail_on_gate=False,
        )
    except Exception as exc:
        console.print(f"[bold red]Edge study failed:[/bold red] {exc}")
        raise typer.Exit(code=1)

    elapsed_seconds = round(time.time() - started_at, 3)
    metadata = {
        "kind": "edge_study",
        "generated_at_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "hostname": platform.node(),
        "platform": platform.platform(),
        "python": sys.version,
        "processor": platform.processor(),
        "seed_count": len(parsed_seeds),
        "seeds": parsed_seeds,
        "preset": preset.strip().lower(),
        "profile_set": profile_set,
        "elapsed_seconds": elapsed_seconds,
        "output_dir": str(Path(outputs["target_root"]).resolve()),
    }
    metadata_path = Path(outputs["target_root"]) / "edge_study_metadata.json"
    metadata_path.write_text(json.dumps(metadata, indent=2), encoding="utf-8")

    table = Table(title="IINTS Edge Study")
    table.add_column("Artifact", style="cyan")
    table.add_column("Path", overflow="fold")
    table.add_row("Study root", str(outputs["target_root"]))
    table.add_row("Protocol markdown", outputs["protocol_outputs"]["protocol_markdown"])
    table.add_row("Study matrix", outputs["protocol_outputs"]["study_matrix_csv"])
    table.add_row("Study summary", str(outputs["root_summary_json"]))
    table.add_row("Edge metadata", str(metadata_path))
    console.print(table)
    console.print(
        Panel(
            "\n".join(
                [
                    f"Seeds: {', '.join(str(seed_value) for seed_value in parsed_seeds)}",
                    f"Preset: {preset.strip().lower()}",
                    f"Elapsed time: {elapsed_seconds:.3f}s",
                    "This study bundle was generated directly on the current machine, which is useful for edge-hardware reproducibility claims.",
                ]
            ),
            title="Edge Study Complete",
            border_style="green",
        )
    )


@edge_app.command(name="long-study")
def edge_long_study(
    config: Annotated[Path, typer.Option(help="YAML config describing the multi-day edge study.")],
    project_dir: Annotated[Path, typer.Option(help="Edge project directory that contains the algorithms folder and runtime scaffold.")] = Path("."),
    resume: Annotated[bool, typer.Option(help="Resume from the next incomplete day by inspecting long_study_index.csv.")] = False,
) -> None:
    console = Console()
    try:
        outputs = run_edge_long_study(
            config_path=config,
            project_dir=project_dir,
            resume=resume,
            progress_callback=lambda message: console.print(f"[cyan]→[/cyan] {message}"),
        )
    except (LongStudyConfigError, FileNotFoundError, EdgeLongStudyExecutionError) as exc:
        console.print(f"[bold red]Edge long study failed:[/bold red] {exc}")
        raise typer.Exit(code=1)

    table = Table(title="IINTS Edge Long Study")
    table.add_column("Artifact", style="cyan")
    table.add_column("Path / Value", overflow="fold")
    table.add_row("Project dir", outputs["project_dir"])
    table.add_row("Study root", outputs["output_dir"])
    table.add_row("Scratch dir", outputs["scratch_dir"])
    table.add_row("Index CSV", outputs["index_csv"])
    table.add_row("Summary JSON", outputs["summary_json"])
    table.add_row("Progress JSON", outputs["progress_json"])
    table.add_row("Export guide", outputs["export_readme"])
    table.add_row("Completed runs", str(outputs["completed_runs"]))
    table.add_row("Skipped existing", str(outputs["skipped_runs"]))
    table.add_row("Resume start day", str(outputs["resume_start_day"]))
    table.add_row("Elapsed time", f"{outputs['elapsed_seconds']:.3f}s")
    console.print(table)

    snapshots = outputs.get("snapshots", [])
    snapshot_line = snapshots[-1]["archive"] if snapshots else "No snapshots were created."
    console.print(
        Panel(
            "\n".join(
                [
                    "The long-horizon study is stored as normal folders plus CSV/JSON manifests, so you can copy it off the Pi without touching the live runtime database.",
                    f"Scratch-first writes: {outputs['scratch_dir']}",
                    f"Latest snapshot: {snapshot_line}",
                    f"Export command: iints edge study-export --project-dir {Path(project_dir).expanduser().resolve()} --input-dir {outputs['output_dir']} --output {Path(outputs['output_dir']) / 'long_study_export.zip'}",
                ]
            ),
            title="Edge Long Study Complete",
            border_style="green",
        )
    )


@edge_app.command(name="study-snapshot")
def edge_study_snapshot(
    project_dir: Annotated[Path, typer.Option(help="Edge project directory used to resolve relative study paths.")] = Path("."),
    input_dir: Annotated[Path, typer.Option(help="Long-study directory to snapshot.")] = Path("results/long_study"),
    output: Annotated[Path, typer.Option(help="Output directory or .tar.gz path for the snapshot archive.")] = Path("snapshots"),
) -> None:
    console = Console()
    project_root = project_dir.expanduser().resolve()
    resolved_input = input_dir if input_dir.is_absolute() else (project_root / input_dir)
    resolved_output = output if output.is_absolute() else (project_root / output)
    try:
        snapshot = create_edge_study_snapshot(resolved_input, output=resolved_output)
    except (FileNotFoundError, OSError) as exc:
        console.print(f"[bold red]Study snapshot failed:[/bold red] {exc}")
        raise typer.Exit(code=1)

    table = Table(title="IINTS Edge Study Snapshot")
    table.add_column("Field", style="cyan")
    table.add_column("Value", overflow="fold")
    table.add_row("Study input", snapshot.input_dir)
    table.add_row("Snapshot archive", snapshot.archive)
    table.add_row("Generated at", snapshot.generated_at_utc)
    console.print(table)


@edge_app.command(name="study-export")
def edge_study_export(
    project_dir: Annotated[Path, typer.Option(help="Edge project directory used to resolve relative study paths.")] = Path("."),
    input_dir: Annotated[Path, typer.Option(help="Long-study directory to export.")] = Path("results/long_study"),
    output: Annotated[Path, typer.Option(help="Zip archive written for transfer to another device.")] = Path("results/long_study_export.zip"),
) -> None:
    console = Console()
    project_root = project_dir.expanduser().resolve()
    resolved_input = input_dir if input_dir.is_absolute() else (project_root / input_dir)
    resolved_output = output if output.is_absolute() else (project_root / output)
    try:
        exported = export_edge_study_archive(resolved_input, output=resolved_output)
    except (FileNotFoundError, OSError) as exc:
        console.print(f"[bold red]Study export failed:[/bold red] {exc}")
        raise typer.Exit(code=1)

    table = Table(title="IINTS Edge Study Export")
    table.add_column("Artifact", style="cyan")
    table.add_column("Path", overflow="fold")
    table.add_row("Study input", exported["input_dir"])
    table.add_row("Export archive", exported["archive"])
    table.add_row("Manifest", exported["manifest"])
    console.print(table)


@edge_app.command(name="doctor")
def edge_doctor(
    board: Annotated[str, typer.Option(help="Board target to validate: raspberry_pi or uno_q.")] = "raspberry_pi",
    project_dir: Annotated[Optional[Path], typer.Option(help="Optional edge project directory created by `iints edge setup`.")] = None,
    workspace_name: Annotated[str, typer.Option(help="Workspace folder inside the edge project.")] = "patient_runtime",
) -> None:
    console = Console()
    normalized_board = board.strip().lower()
    if normalized_board not in {"raspberry_pi", "uno_q"}:
        console.print("[bold red]Unsupported board. Use `raspberry_pi` or `uno_q`.[/bold red]")
        raise typer.Exit(code=1)

    board_label = "Raspberry Pi" if normalized_board == "raspberry_pi" else "Arduino UNO Q"
    console.print(
        Panel(
            "\n".join(
                [
                    f"This check helps you bring a {board_label} demo online without guesswork.",
                    "We verify the Python runtime, edge dependencies, and the board-specific pieces you need next.",
                ]
            ),
            title=f"{board_label} Edge Check",
            border_style="cyan",
        )
    )

    table = Table(title=f"IINTS Edge Doctor - {board_label}")
    table.add_column("What We Checked", style="cyan")
    table.add_column("Result", style="bold")
    table.add_column("What It Means", overflow="fold")

    failures: list[str] = []
    action_items: list[str] = []
    note_items: list[str] = []

    py_ok = sys.version_info >= (3, 10)
    table.add_row(
        "Python runtime",
        "[green]Ready[/green]" if py_ok else "[red]Update needed[/red]",
        f"Found Python {sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}. Edge commands need Python 3.10 or newer.",
    )
    if not py_ok:
        failures.append("python")
        action_items.append("Install Python 3.10 or newer, then rerun `iints edge doctor`.")

    fastapi_ok = _module_available("fastapi")
    table.add_row(
        "Dashboard dependency",
        "[green]Ready[/green]" if fastapi_ok else "[red]Install needed[/red]",
        "FastAPI powers the live dashboard and kiosk.",
    )
    if not fastapi_ok:
        failures.append("fastapi")
        action_items.append('Install the edge runtime extras: `python3 -m pip install -U "iints-sdk-python35[edge,mdmp]"`.')

    if project_dir is not None:
        root = _resolve_edge_project_dir(project_dir)
        config_path = root / workspace_name / "patient_runtime_config.json"
        has_project = config_path.is_file()
        detected_board = _detect_edge_board(root)
        table.add_row(
            "Project scaffold",
            "[green]Ready[/green]" if has_project else "[yellow]Create it first[/yellow]",
            str(config_path) if has_project else f"Expected {config_path} after `iints edge setup`.",
        )
        table.add_row("Detected board", "[green]OK[/green]", detected_board)
        if not has_project:
            action_items.append(f"Create the edge project first: `iints edge setup --board {normalized_board} --output-dir {root}`.")
        elif detected_board != normalized_board:
            note_items.append(
                f"The project in `{root}` looks like `{detected_board}` while you asked for `{normalized_board}`. Use matching board settings to avoid mixed instructions."
            )
    else:
        table.add_row(
            "Project scaffold",
            "[blue]Skipped[/blue]",
            "Pass `--project-dir` if you already created a board project and want doctor to verify it too.",
        )

    if normalized_board == "raspberry_pi":
        launcher_ok = shutil.which("xdg-open") is not None or shutil.which("open") is not None
        table.add_row(
            "Browser launcher",
            "[green]Ready[/green]" if launcher_ok else "[yellow]Optional[/yellow]",
            "Used by `iints edge kiosk`. If missing, you can still open the kiosk URL manually in a browser.",
        )
        if not launcher_ok:
            note_items.append("If `iints edge kiosk` cannot open a browser, start the runtime first and visit the kiosk URL manually.")
    else:
        report = uno_q_bridge_environment_report()
        pyserial_ok = bool(report["pyserial_available"])
        table.add_row(
            "USB serial support",
            "[green]Ready[/green]" if pyserial_ok else "[red]Install needed[/red]",
            report["pyserial_error"] or "The bridge commands can talk to the STM32 side over USB serial.",
        )
        if not pyserial_ok:
            failures.append("pyserial")
            action_items.append('Install serial support with the edge extras: `python3 -m pip install -U "iints-sdk-python35[edge,mdmp]"`.')

        ports = report["serial_ports"]
        table.add_row(
            "UNO Q USB link",
            "[green]Detected[/green]" if ports else "[yellow]Check cable[/yellow]",
            ", ".join(ports) if ports else "No serial device was auto-detected right now.",
        )
        if not ports:
            note_items.append(
                "Plug the UNO Q in with a USB data cable, then rerun `iints edge doctor --board uno_q`. You can still pass `--port /dev/ttyACM0` directly to bridge commands if you already know the port."
            )

        arduino_cli_path = report["arduino_cli_path"]
        table.add_row(
            "Arduino flashing tool",
            "[green]Ready[/green]" if arduino_cli_path else "[yellow]Optional[/yellow]",
            arduino_cli_path or "Install `arduino-cli` if you want `iints edge bridge-flash` to program the STM32 side from the terminal.",
        )
        if not arduino_cli_path:
            note_items.append("You can still run the Linux-side demo now. Add `arduino-cli` later if you want fully CLI-based flashing.")

    console.print(table)

    if failures:
        console.print(
            Panel(
                "\n".join(
                    [
                        f"You're not blocked forever; there are just {len(failures)} required fix(es) before the {board_label} path is fully ready.",
                        "Work through the items below, then rerun `iints edge doctor`.",
                    ]
                ),
                title="Not Ready Yet",
                border_style="red",
            )
        )
    elif action_items:
        console.print(
            Panel(
                "A few required setup actions are still listed below. Once they are done, the rest of the flow is straightforward.",
                title="Almost Ready",
                border_style="yellow",
            )
        )
    else:
        console.print(
            Panel(
                f"Good news: the core {board_label} prerequisites are in place. You can move straight into setup and runtime commands.",
                title="Ready To Go",
                border_style="green",
            )
        )

    if action_items:
        console.print(
            Panel(
                "\n".join(f"{index}. {item}" for index, item in enumerate(action_items, start=1)),
                title="Do This Next",
                border_style="yellow",
            )
        )

    if note_items:
        console.print(
            Panel(
                "\n".join(f"{index}. {item}" for index, item in enumerate(note_items, start=1)),
                title="Helpful Notes",
                border_style="blue",
            )
        )

    suggested_dir = f"./iints_{normalized_board}_demo"
    next_steps = [
        f"1. Create the project: iints edge setup --board {normalized_board} --output-dir {suggested_dir}",
        f"2. Start the runtime: iints edge up --project-dir {suggested_dir}",
        f"3. Check that it is alive: iints edge status --project-dir {suggested_dir}",
    ]
    if normalized_board == "uno_q":
        next_steps.extend(
            [
                "4. Test the serial bridge: iints edge bridge-test --port /dev/ttyACM0",
                "5. Forward live states to the board: iints edge bridge-run --project-dir ./iints_uno_q_demo --port /dev/ttyACM0",
            ]
        )
    else:
        next_steps.append(f"4. Open the kiosk view: iints edge kiosk --project-dir {suggested_dir}")
    console.print(Panel("\n".join(next_steps), title="Next Commands", border_style="cyan"))

    if failures:
        raise typer.Exit(code=1)


@edge_app.command(name="remote-status")
def edge_remote_status(
    host: Annotated[str, typer.Option(help="Remote Raspberry Pi hostname or IP address.")],
    user_name: Annotated[Optional[str], typer.Option("--user", help="Optional remote SSH username.")] = None,
    ssh_port: Annotated[int, typer.Option(help="SSH port used for the remote Raspberry Pi.")] = 22,
    remote_dir: Annotated[str, typer.Option(help="Target project directory on the Raspberry Pi.")] = "~/iints_pi_demo",
    ssh_timeout_seconds: Annotated[float, typer.Option(help="Timeout per remote SSH step in seconds.")] = 60.0,
    ssh_retries: Annotated[int, typer.Option(help="How many times to retry a failing SSH step before giving up.")] = 0,
) -> None:
    console = Console()
    try:
        payload = run_remote_edge_command(
            host=host,
            user_name=user_name,
            ssh_port=ssh_port,
            remote_dir=remote_dir,
            action="status",
            timeout_seconds=ssh_timeout_seconds,
            retries=ssh_retries,
        )
    except Exception as exc:
        console.print(f"[bold red]Remote status failed:[/bold red] {exc}")
        raise typer.Exit(code=1)
    console.print(payload["stdout"])


@edge_app.command(name="remote-reset")
def edge_remote_reset(
    host: Annotated[str, typer.Option(help="Remote Raspberry Pi hostname or IP address.")],
    user_name: Annotated[Optional[str], typer.Option("--user", help="Optional remote SSH username.")] = None,
    ssh_port: Annotated[int, typer.Option(help="SSH port used for the remote Raspberry Pi.")] = 22,
    remote_dir: Annotated[str, typer.Option(help="Target project directory on the Raspberry Pi.")] = "~/iints_pi_demo",
    scenario_profile: Annotated[Optional[str], typer.Option(help="Optional profile to load after reset.")] = None,
    seed: Annotated[Optional[int], typer.Option(help="Optional deterministic seed override for the reset profile.")] = None,
    ssh_timeout_seconds: Annotated[float, typer.Option(help="Timeout per remote SSH step in seconds.")] = 60.0,
    ssh_retries: Annotated[int, typer.Option(help="How many times to retry a failing SSH step before giving up.")] = 0,
) -> None:
    console = Console()
    try:
        payload = run_remote_edge_command(
            host=host,
            user_name=user_name,
            ssh_port=ssh_port,
            remote_dir=remote_dir,
            action="reset",
            scenario_profile=scenario_profile,
            seed=seed,
            timeout_seconds=ssh_timeout_seconds,
            retries=ssh_retries,
        )
    except Exception as exc:
        console.print(f"[bold red]Remote reset failed:[/bold red] {exc}")
        raise typer.Exit(code=1)
    console.print(payload["stdout"] or "[green]Remote reset command sent.[/green]")


@edge_app.command(name="remote-stop")
def edge_remote_stop(
    host: Annotated[str, typer.Option(help="Remote Raspberry Pi hostname or IP address.")],
    user_name: Annotated[Optional[str], typer.Option("--user", help="Optional remote SSH username.")] = None,
    ssh_port: Annotated[int, typer.Option(help="SSH port used for the remote Raspberry Pi.")] = 22,
    remote_dir: Annotated[str, typer.Option(help="Target project directory on the Raspberry Pi.")] = "~/iints_pi_demo",
    ssh_timeout_seconds: Annotated[float, typer.Option(help="Timeout per remote SSH step in seconds.")] = 60.0,
    ssh_retries: Annotated[int, typer.Option(help="How many times to retry a failing SSH step before giving up.")] = 0,
) -> None:
    console = Console()
    try:
        payload = run_remote_edge_command(
            host=host,
            user_name=user_name,
            ssh_port=ssh_port,
            remote_dir=remote_dir,
            action="stop",
            timeout_seconds=ssh_timeout_seconds,
            retries=ssh_retries,
        )
    except Exception as exc:
        console.print(f"[bold red]Remote stop failed:[/bold red] {exc}")
        raise typer.Exit(code=1)
    console.print(payload["stdout"] or "[green]Remote stop command sent.[/green]")


@edge_app.command(name="up")
def edge_up(
    project_dir: Annotated[Path, typer.Option(help="Edge project directory created by `iints edge setup`.")] = Path("."),
    workspace_name: Annotated[str, typer.Option(help="Workspace folder inside the edge project.")] = "patient_runtime",
    foreground: Annotated[bool, typer.Option(help="Run the digital patient in the foreground instead of spawning the daemon.")] = False,
    reset: Annotated[bool, typer.Option(help="Reset the runtime state before starting.")] = False,
    max_steps: Annotated[Optional[int], typer.Option("--max-steps", hidden=True)] = None,
) -> None:
    cfg = _load_edge_project_config(project_dir, workspace_name=workspace_name)
    patient_cli_module.start(
        algo=Path(cfg.algo_path),
        patient_config=cfg.patient_config,
        patient_model=cfg.patient_model_type,
        scenario_profile=cfg.scenario_profile,
        workspace=Path(cfg.workspace),
        mode=cfg.mode,
        speed=f"{cfg.speed:g}x",
        api_host=cfg.api_host,
        api_port=cfg.api_port,
        seed=cfg.seed,
        foreground=foreground,
        max_steps=max_steps,
        reset=reset,
    )


@makerfaire_app.command(name="up")
def makerfaire_up(
    project_dir: Annotated[Path, typer.Option(help="Edge project directory created by `iints edge setup`.")] = Path("."),
    workspace_name: Annotated[str, typer.Option(help="Workspace folder inside the edge project.")] = "patient_runtime",
    scenario_profile: Annotated[str, typer.Option(help="Booth-ready scenario profile. Defaults to expo_hot_start.")] = "expo_hot_start",
    seed: Annotated[Optional[int], typer.Option(help="Optional deterministic seed override for the booth reset/start.")] = None,
    reset: Annotated[bool, typer.Option(help="Reset into the booth profile when the runtime is already running.")] = True,
    foreground: Annotated[bool, typer.Option(help="Run in the foreground instead of using the background daemon.")] = False,
    show_kiosk: Annotated[bool, typer.Option(help="Print the kiosk panel after startup so you can copy the Pi display URL quickly.")] = True,
) -> None:
    """Start the Raspberry Pi virtual patient in a Maker Faire-friendly way."""
    console = Console()
    root = _resolve_edge_project_dir(project_dir)
    cfg = _load_edge_project_config(root, workspace_name=workspace_name)
    workspace = Path(cfg.workspace).expanduser().resolve()
    board = _detect_edge_board(root)
    existing = summarize_edge_workspace(workspace)
    already_running = bool(existing and existing.get("pid_alive"))
    effective_seed = seed if seed is not None else cfg.seed

    if already_running:
        if reset:
            patient_cli_module.expo_reset(
                scenario_profile=scenario_profile,
                seed=seed,
                workspace=workspace,
            )
    else:
        patient_cli_module.start(
            algo=Path(cfg.algo_path),
            patient_config=cfg.patient_config,
            patient_model=cfg.patient_model_type,
            scenario_profile=scenario_profile,
            workspace=workspace,
            mode=cfg.mode,
            speed=f"{cfg.speed:g}x",
            api_host=cfg.api_host,
            api_port=cfg.api_port,
            foreground=foreground,
            seed=effective_seed,
            reset=reset,
        )

    if show_kiosk and not foreground:
        patient_cli_module.kiosk(workspace=workspace)

    snapshot = _makerfaire_runtime_snapshot(
        cfg=cfg,
        scenario_profile=scenario_profile,
        seed=effective_seed,
    )
    table = Table(title="IINTS Maker Faire Pi")
    table.add_column("Field", style="cyan")
    table.add_column("Value", overflow="fold")
    table.add_row("project_dir", str(root))
    table.add_row("board", board)
    table.add_row("workspace", str(workspace))
    table.add_row("daemon_status", str(snapshot.get("daemon_status", "-")))
    table.add_row("scenario_profile", str(snapshot.get("scenario_profile", scenario_profile)))
    table.add_row("active_seed", str(snapshot.get("active_seed", effective_seed)))
    table.add_row("algorithm", str(snapshot.get("algorithm_name", Path(cfg.algo_path).stem)))
    table.add_row("dashboard_url", str(snapshot.get("dashboard_url", cfg.dashboard_url)))
    table.add_row("kiosk_url", str(snapshot.get("kiosk_url", f"http://{cfg.api_host}:{cfg.api_port}/kiosk")))

    makerfaire_script = root / "start_makerfaire_patient.sh"
    makerfaire_guide = root / "MAKERFAIRE_START.md"
    makerfaire_autostart_script = root / "install_makerfaire_autostart.sh"
    makerfaire_autostart_guide = root / "MAKERFAIRE_AUTOSTART.md"
    makerfaire_watchdog_script = root / "run_makerfaire_watchdog.sh"
    makerfaire_watchdog_timer = sorted(root.glob("*-watchdog.timer"))
    makerfaire_checklist = root / "MAKERFAIRE_CHECKLIST.md"
    if makerfaire_script.is_file():
        table.add_row("makerfaire_script", str(makerfaire_script))
    if makerfaire_guide.is_file():
        table.add_row("makerfaire_guide", str(makerfaire_guide))
    if makerfaire_autostart_script.is_file():
        table.add_row("makerfaire_autostart_script", str(makerfaire_autostart_script))
    if makerfaire_autostart_guide.is_file():
        table.add_row("makerfaire_autostart_guide", str(makerfaire_autostart_guide))
    if makerfaire_watchdog_script.is_file():
        table.add_row("makerfaire_watchdog_script", str(makerfaire_watchdog_script))
    if makerfaire_watchdog_timer:
        table.add_row("makerfaire_watchdog_timer", str(makerfaire_watchdog_timer[0]))
    if makerfaire_checklist.is_file():
        table.add_row("makerfaire_checklist", str(makerfaire_checklist))
    service_files = sorted(workspace.glob("*.service"))
    if service_files:
        table.add_row("service_file", str(service_files[0]))
    console.print(table)
    if makerfaire_script.is_file():
        console.print(f"Maker Faire start script: {makerfaire_script.name}")
    if makerfaire_guide.is_file():
        console.print(f"Maker Faire quick guide: {makerfaire_guide.name}")
    if makerfaire_autostart_script.is_file():
        console.print(f"Maker Faire autostart installer: {makerfaire_autostart_script.name}")
    if makerfaire_autostart_guide.is_file():
        console.print(f"Maker Faire autostart guide: {makerfaire_autostart_guide.name}")
    if makerfaire_watchdog_script.is_file():
        console.print(f"Maker Faire watchdog script: {makerfaire_watchdog_script.name}")
    if makerfaire_checklist.is_file():
        console.print(f"Maker Faire checklist: {makerfaire_checklist.name}")

    next_steps = [
        f"Reset between visitors: iints edge reset --project-dir {root}",
        f"Check runtime status: iints edge status --project-dir {root}",
        f"Run booth watchdog: iints makerfaire watchdog --project-dir {root}",
        f"Stop after the booth: iints edge stop --project-dir {root}",
        f"Booth autostart guide: iints makerfaire autostart --project-dir {root}",
    ]
    if board == "uno_q":
        next_steps.append(f"Optional bridge terminal: iints edge bridge-run --project-dir {root} --port /dev/ttyACM0")
    console.print(
        Panel(
            "\n".join(next_steps),
            title="Maker Faire Next Steps",
            border_style="green",
        )
    )


@makerfaire_app.command(name="autostart")
def makerfaire_autostart(
    project_dir: Annotated[Path, typer.Option(help="Edge project directory created by `iints edge setup`.")] = Path("."),
    workspace_name: Annotated[str, typer.Option(help="Workspace folder inside the edge project.")] = "patient_runtime",
) -> None:
    """Show the generated Raspberry Pi autostart files and install steps."""
    console = Console()
    root = _resolve_edge_project_dir(project_dir)
    cfg = _load_edge_project_config(root, workspace_name=workspace_name)
    workspace = Path(cfg.workspace).expanduser().resolve()
    service_files = sorted(workspace.glob("*.service"))
    install_files = sorted(workspace.glob("*.INSTALL.txt"))

    artifacts = {
        "service_file": service_files[0] if service_files else workspace / "iints-digital-patient.service",
        "service_notes": install_files[0] if install_files else workspace / "iints-digital-patient.INSTALL.txt",
        "makerfaire_script": root / "start_makerfaire_patient.sh",
        "makerfaire_guide": root / "MAKERFAIRE_START.md",
        "makerfaire_kiosk_script": root / "open_makerfaire_kiosk.sh",
        "makerfaire_desktop_entry": root / "iints-makerfaire-kiosk.desktop",
        "makerfaire_autostart_script": root / "install_makerfaire_autostart.sh",
        "makerfaire_autostart_guide": root / "MAKERFAIRE_AUTOSTART.md",
        "makerfaire_watchdog_script": root / "run_makerfaire_watchdog.sh",
        "makerfaire_checklist": root / "MAKERFAIRE_CHECKLIST.md",
    }
    watchdog_services = sorted(root.glob("*-watchdog.service"))
    watchdog_timers = sorted(root.glob("*-watchdog.timer"))
    if watchdog_services:
        artifacts["makerfaire_watchdog_service"] = watchdog_services[0]
    if watchdog_timers:
        artifacts["makerfaire_watchdog_timer"] = watchdog_timers[0]

    missing = [name for name, path in artifacts.items() if not path.is_file()]
    if missing:
        console.print(
            "[bold red]This project is missing some Maker Faire autostart artifacts.[/bold red] "
            "Regenerate it with `iints edge setup` or run the command inside a fresh edge project."
        )
        for name in missing:
            console.print(f"- missing: {artifacts[name]}")
        raise typer.Exit(code=1)

    table = Table(title="IINTS Maker Faire Autostart")
    table.add_column("Artifact", style="cyan")
    table.add_column("Path", overflow="fold")
    for name, path in artifacts.items():
        table.add_row(name, str(path))
    console.print(table)
    console.print(f"Autostart installer: {artifacts['makerfaire_autostart_script'].name}")
    console.print(f"Desktop entry: {artifacts['makerfaire_desktop_entry'].name}")
    console.print(f"Kiosk opener: {artifacts['makerfaire_kiosk_script'].name}")
    console.print(f"Watchdog script: {artifacts['makerfaire_watchdog_script'].name}")
    console.print(f"Event checklist: {artifacts['makerfaire_checklist'].name}")

    kiosk_url = f"http://{cfg.api_host}:{cfg.api_port}/kiosk"
    console.print(
        Panel(
            "\n".join(
                [
                    "1. Test the normal booth flow first:",
                    f"   ./start_makerfaire_patient.sh",
                    "2. Install booth autostart on the Pi:",
                    "   ./install_makerfaire_autostart.sh",
                    "3. Enable Desktop Autologin in Raspberry Pi Configuration so the kiosk browser can open after login.",
                    "4. Let the generated watchdog timer protect the booth runtime in the background.",
                    "5. Reboot and verify all three pieces:",
                    "   - the digital patient daemon starts automatically",
                    "   - the watchdog timer is active",
                    f"   - the kiosk browser opens to {kiosk_url}",
                    f"6. Between visitors, keep using: iints edge reset --project-dir {root}",
                ]
            ),
            title="Maker Faire Autostart Steps",
            border_style="green",
        )
    )


@makerfaire_app.command(name="watchdog")
def makerfaire_watchdog(
    project_dir: Annotated[Path, typer.Option(help="Edge project directory created by `iints edge setup`.")] = Path("."),
    workspace_name: Annotated[str, typer.Option(help="Workspace folder inside the edge project.")] = "patient_runtime",
    scenario_profile: Annotated[str, typer.Option(help="Booth-safe scenario profile to restore if the runtime must be restarted.")] = "expo_hot_start",
    seed: Annotated[Optional[int], typer.Option(help="Optional deterministic seed override used when the watchdog has to restart the runtime.")] = None,
    quiet: Annotated[bool, typer.Option(help="Print only minimal output. Useful for watchdog scripts and timers.")] = False,
) -> None:
    """Check the Maker Faire runtime and restart it if the booth patient is down."""
    console = Console()
    root = _resolve_edge_project_dir(project_dir)
    cfg = _load_edge_project_config(root, workspace_name=workspace_name)
    workspace = Path(cfg.workspace).expanduser().resolve()
    effective_seed = seed if seed is not None else cfg.seed
    summary = summarize_edge_workspace(workspace)

    daemon_status = str(summary.get("daemon_status", "unknown"))
    pid_alive = bool(summary.get("pid_alive"))
    action = "healthy"

    if not pid_alive or daemon_status in {"error", "stopped"}:
        patient_cli_module.start(
            algo=Path(cfg.algo_path),
            patient_config=cfg.patient_config,
            patient_model=cfg.patient_model_type,
            scenario_profile=scenario_profile,
            workspace=workspace,
            mode=cfg.mode,
            speed=f"{cfg.speed:g}x",
            api_host=cfg.api_host,
            api_port=cfg.api_port,
            foreground=False,
            seed=effective_seed,
            reset=True,
        )
        summary = _makerfaire_runtime_snapshot(
            cfg=cfg,
            scenario_profile=scenario_profile,
            seed=effective_seed,
        )
        action = "restarted"
    elif summary.get("scenario_profile") != scenario_profile:
        action = "running"

    if quiet:
        if action == "restarted":
            console.print(f"restarted {workspace}")
        else:
            console.print(f"ok {workspace}")
        return

    table = Table(title="IINTS Maker Faire Watchdog")
    table.add_column("Field", style="cyan")
    table.add_column("Value", overflow="fold")
    table.add_row("project_dir", str(root))
    table.add_row("workspace", str(workspace))
    table.add_row("action", action)
    table.add_row("daemon_status", str(summary.get("daemon_status", daemon_status)))
    table.add_row("scenario_profile", str(summary.get("scenario_profile", scenario_profile)))
    table.add_row("active_seed", str(summary.get("active_seed", effective_seed)))
    table.add_row("dashboard_url", str(summary.get("dashboard_url", cfg.dashboard_url)))
    table.add_row("kiosk_url", str(summary.get("kiosk_url", f"http://{cfg.api_host}:{cfg.api_port}/kiosk")))
    console.print(table)
    console.print(
        Panel(
            "\n".join(
                [
                    "Use this command when the booth patient looks frozen or vanished.",
                    "If the runtime was down, the watchdog has already restarted it in the background.",
                    f"Manual reset command: iints edge reset --project-dir {root}",
                ]
            ),
            title="Watchdog Result",
            border_style="green" if action != "restarted" else "yellow",
        )
    )


@edge_app.command(name="kiosk")
def edge_kiosk(
    project_dir: Annotated[Optional[Path], typer.Option(help="Optional edge project directory created by `iints edge setup`.")] = None,
    workspace: Annotated[Optional[Path], typer.Option(help="Optional runtime workspace override.")] = None,
    workspace_name: Annotated[str, typer.Option(help="Workspace folder inside the edge project.")] = "patient_runtime",
) -> None:
    patient_cli_module.kiosk(
        workspace=_resolve_edge_workspace(project_dir=project_dir, workspace=workspace, workspace_name=workspace_name)
    )


@edge_app.command(name="reset")
def edge_reset(
    project_dir: Annotated[Optional[Path], typer.Option(help="Optional edge project directory created by `iints edge setup`.")] = None,
    workspace: Annotated[Optional[Path], typer.Option(help="Optional runtime workspace override.")] = None,
    workspace_name: Annotated[str, typer.Option(help="Workspace folder inside the edge project.")] = "patient_runtime",
    scenario_profile: Annotated[Optional[str], typer.Option(help="Optional profile to load after reset. Defaults to expo_hot_start.")] = None,
    seed: Annotated[Optional[int], typer.Option(help="Optional deterministic seed override for the reset profile.")] = None,
) -> None:
    patient_cli_module.expo_reset(
        scenario_profile=scenario_profile,
        seed=seed,
        workspace=_resolve_edge_workspace(project_dir=project_dir, workspace=workspace, workspace_name=workspace_name),
    )


@edge_app.command(name="stop")
def edge_stop(
    project_dir: Annotated[Optional[Path], typer.Option(help="Optional edge project directory created by `iints edge setup`.")] = None,
    workspace: Annotated[Optional[Path], typer.Option(help="Optional runtime workspace override.")] = None,
    workspace_name: Annotated[str, typer.Option(help="Workspace folder inside the edge project.")] = "patient_runtime",
) -> None:
    patient_cli_module.stop(
        workspace=_resolve_edge_workspace(project_dir=project_dir, workspace=workspace, workspace_name=workspace_name)
    )


@edge_app.command(name="service")
def edge_service(
    project_dir: Annotated[Optional[Path], typer.Option(help="Optional edge project directory created by `iints edge setup`.")] = None,
    workspace: Annotated[Optional[Path], typer.Option(help="Optional runtime workspace override.")] = None,
    workspace_name: Annotated[str, typer.Option(help="Workspace folder inside the edge project.")] = "patient_runtime",
    output: Annotated[Optional[Path], typer.Option(help="Optional output service file path.")] = None,
    service_name: Annotated[str, typer.Option(help="systemd service name without the .service suffix.")] = "iints-digital-patient",
    user_name: Annotated[Optional[str], typer.Option(help="Linux user that should run the service. Defaults to the current shell user.")] = None,
    python_path: Annotated[Optional[Path], typer.Option(help="Python executable used in ExecStart. Defaults to the current interpreter.")] = None,
) -> None:
    patient_cli_module.export_service(
        workspace=_resolve_edge_workspace(project_dir=project_dir, workspace=workspace, workspace_name=workspace_name),
        output=output,
        service_name=service_name,
        user_name=user_name,
        python_path=python_path,
    )


@edge_app.command(name="status")
def edge_status(
    workspace: Annotated[Optional[Path], typer.Option(help="Workspace directory for the persistent digital patient state.")] = None,
    project_dir: Annotated[Optional[Path], typer.Option(help="Optional edge project directory created by `iints edge setup`.")] = None,
    workspace_name: Annotated[str, typer.Option(help="Workspace folder inside the edge project.")] = "patient_runtime",
) -> None:
    console = Console()
    resolved_workspace = _resolve_edge_workspace(project_dir=project_dir, workspace=workspace, workspace_name=workspace_name)
    summary = summarize_edge_workspace(resolved_workspace)
    if not summary:
        console.print(f"[bold red]No edge runtime found in {resolved_workspace}.[/bold red]")
        raise typer.Exit(code=1)

    certification = summary.get("certification") or {}
    review = summary.get("review") or {}

    table = Table(title="IINTS Edge Runtime Status")
    table.add_column("Field", style="cyan")
    table.add_column("Value", overflow="fold")
    rows = [
        ("daemon_status", summary.get("daemon_status", "-")),
        ("pid_alive", summary.get("pid_alive", "-")),
        ("algorithm_name", summary.get("algorithm_name", "-")),
        ("scenario_profile", summary.get("scenario_profile", "-")),
        ("active_seed", summary.get("active_seed", "-")),
        ("simulated_clock", summary.get("simulated_clock", "-")),
        ("last_glucose_mgdl", summary.get("last_glucose_mgdl", "-")),
        ("dashboard_url", summary.get("dashboard_url", "-")),
        ("kiosk_url", summary.get("kiosk_url", "-")),
        ("certification", certification.get("label", "-")),
        ("review", review.get("label", "-")),
        ("workspace_size_mb", summary.get("workspace_size_mb", "-")),
        ("bundle_size_mb", summary.get("bundle_size_mb", "-")),
        ("last_heartbeat_utc", summary.get("last_heartbeat_utc", "-")),
    ]
    for field, value in rows:
        table.add_row(str(field), str(value))
    console.print(table)


@edge_app.command(name="bundle")
def edge_bundle(
    workspace: Annotated[Optional[Path], typer.Option(help="Workspace directory for the persistent digital patient state.")] = None,
    project_dir: Annotated[Optional[Path], typer.Option(help="Optional edge project directory created by `iints edge setup`.")] = None,
    workspace_name: Annotated[str, typer.Option(help="Workspace folder inside the edge project.")] = "patient_runtime",
    output: Annotated[Path, typer.Option(help="ZIP archive written for workstation-side analysis.")] = Path("results/edge_runtime_bundle.zip"),
    include_log: Annotated[bool, typer.Option(help="Include the patient log in the archive.")] = True,
    include_database: Annotated[bool, typer.Option(help="Include the SQLite runtime database in the archive.")] = True,
) -> None:
    console = Console()
    resolved_workspace = _resolve_edge_workspace(project_dir=project_dir, workspace=workspace, workspace_name=workspace_name)
    payload = create_edge_bundle(
        resolved_workspace,
        output_path=output,
        include_log=include_log,
        include_database=include_database,
    )
    summary = payload["summary"]
    console.print(
        Panel(
            "\n".join(
                [
                    f"Archive: {payload['archive']}",
                    f"Scenario: {summary.get('scenario_profile', '-')}",
                    f"Certification: {(summary.get('certification') or {}).get('label', '-')}",
                    f"Review: {(summary.get('review') or {}).get('label', '-')}",
                ]
            ),
            title="Edge Bundle Ready",
            border_style="cyan",
        )
    )


@edge_app.command(name="update")
def edge_update(
    output_script: Annotated[Path, typer.Option(help="Where to write the edge update shell script.")] = Path("update_edge_runtime.sh"),
    profile: Annotated[str, typer.Option(help="Install profile to upgrade: edge or full.")] = "edge",
    version_pin: Annotated[Optional[str], typer.Option(help="Optional exact SDK version pin, for example 1.5.2.")] = None,
) -> None:
    console = Console()
    normalized = profile.strip().lower()
    if normalized not in {"edge", "full"}:
        console.print("[bold red]Profile must be `edge` or `full`.[/bold red]")
        raise typer.Exit(code=1)
    script_path = write_edge_update_script(output_script, profile=normalized, version_pin=version_pin)
    console.print(f"[green]Edge update script written:[/green] {script_path}")


@edge_app.command(name="hardware-bridge")
def edge_hardware_bridge(
    board: Annotated[str, typer.Option(help="Hardware bridge target. Currently supported: uno_q.")] = "uno_q",
    output_dir: Annotated[Path, typer.Option(help="Directory where the hardware bridge scaffold should be written.")] = Path("uno_q_bridge"),
) -> None:
    console = Console()
    normalized = board.strip().lower()
    if normalized != "uno_q":
        console.print("[bold red]Only the `uno_q` hardware bridge is currently implemented.[/bold red]")
        raise typer.Exit(code=1)
    outputs = export_uno_q_bridge(output_dir)
    table = Table(title="IINTS Edge Hardware Bridge")
    table.add_column("Artifact", style="cyan")
    table.add_column("Path", overflow="fold")
    table.add_row("sketch", outputs["sketch"])
    table.add_row("readme", outputs["readme"])
    table.add_row("protocol", outputs["protocol"])
    console.print(table)


@edge_app.command(name="bridge-test")
def edge_bridge_test(
    port: Annotated[Optional[str], typer.Option(help="Serial port for the UNO Q STM32 side. Use `auto` or omit it if exactly one port is connected.")] = None,
    baudrate: Annotated[int, typer.Option(help="Serial baud rate used by the UNO Q bridge sketch.")] = UNO_Q_BRIDGE_BAUDRATE,
    delay_seconds: Annotated[float, typer.Option(help="Pause between test states in seconds.")] = 0.75,
) -> None:
    console = Console()
    try:
        results = run_uno_q_bridge_test(port, baudrate=baudrate, delay_seconds=delay_seconds)
    except Exception as exc:
        console.print(f"[bold red]UNO Q bridge test failed:[/bold red] {exc}")
        raise typer.Exit(code=1)

    table = Table(title="UNO Q Bridge Test")
    table.add_column("State", style="cyan")
    table.add_column("Port")
    table.add_column("Response", overflow="fold")
    for result in results:
        response = result.get("response")
        if not response:
            startup_lines = result.get("startup_lines") or []
            response = startup_lines[-1] if startup_lines else "-"
        table.add_row(result["state"], result["port"], str(response))
    console.print(table)


@edge_app.command(name="bridge-run")
def edge_bridge_run(
    port: Annotated[Optional[str], typer.Option(help="Serial port for the UNO Q STM32 side. Use `auto` or omit it if exactly one port is connected.")] = None,
    workspace: Annotated[Optional[Path], typer.Option(help="Workspace directory for the persistent digital patient state.")] = None,
    project_dir: Annotated[Optional[Path], typer.Option(help="Optional edge project directory created by `iints edge setup`.")] = None,
    workspace_name: Annotated[str, typer.Option(help="Workspace folder inside the edge project.")] = "patient_runtime",
    baudrate: Annotated[int, typer.Option(help="Serial baud rate used by the UNO Q bridge sketch.")] = UNO_Q_BRIDGE_BAUDRATE,
    poll_interval: Annotated[float, typer.Option(help="Polling interval in seconds while following runtime status.")] = 1.0,
    once: Annotated[bool, typer.Option(help="Send the current state once and exit.")] = False,
    max_cycles: Annotated[Optional[int], typer.Option("--max-cycles", hidden=True)] = None,
) -> None:
    console = Console()
    resolved_workspace = _resolve_edge_workspace(project_dir=project_dir, workspace=workspace, workspace_name=workspace_name)
    if not once:
        console.print(
            Panel(
                "\n".join(
                    [
                        f"Workspace: {resolved_workspace}",
                        f"Port: {port or 'auto'}",
                        f"Baud rate: {baudrate}",
                        "Press Ctrl+C to stop the bridge forwarder.",
                    ]
                ),
                title="UNO Q Bridge Forwarder",
                border_style="cyan",
            )
        )
    try:
        payload = run_uno_q_bridge_forwarder(
            resolved_workspace,
            port,
            baudrate=baudrate,
            poll_interval=poll_interval,
            once=once,
            max_cycles=max_cycles,
        )
    except KeyboardInterrupt:
        console.print("[yellow]UNO Q bridge forwarder stopped.[/yellow]")
        raise typer.Exit(code=0)
    except Exception as exc:
        console.print(f"[bold red]UNO Q bridge forwarder failed:[/bold red] {exc}")
        raise typer.Exit(code=1)

    if once:
        console.print(
            f"[green]UNO Q bridge state sent:[/green] {payload.get('state', '-')} -> {payload.get('port', '-')}"
        )


@edge_app.command(name="bridge-flash")
def edge_bridge_flash(
    port: Annotated[str, typer.Option(help="Serial port used to upload the UNO Q bridge sketch.")] ,
    fqbn: Annotated[str, typer.Option(help="Arduino CLI FQBN for the UNO Q board package.")] ,
    project_dir: Annotated[Path, typer.Option(help="Edge project directory created by `iints edge setup`.")] = Path("."),
    sketch_dir: Annotated[Optional[Path], typer.Option(help="Optional bridge sketch directory. Defaults to <project-dir>/uno_q_bridge.")] = None,
    arduino_cli: Annotated[str, typer.Option(help="Arduino CLI executable name or path.")] = "arduino-cli",
) -> None:
    console = Console()
    resolved_project = _resolve_edge_project_dir(project_dir)
    resolved_sketch_dir = (sketch_dir.expanduser().resolve() if sketch_dir is not None else resolved_project / "uno_q_bridge")
    try:
        payload = flash_uno_q_bridge(
            resolved_sketch_dir,
            port=port,
            fqbn=fqbn,
            arduino_cli=arduino_cli,
        )
    except Exception as exc:
        console.print(f"[bold red]UNO Q bridge flash failed:[/bold red] {exc}")
        raise typer.Exit(code=1)

    console.print(
        Panel(
            "\n".join(
                [
                    f"Sketch directory: {payload['sketch_dir']}",
                    f"Port: {payload['port']}",
                    f"FQBN: {payload['fqbn']}",
                    f"Arduino CLI: {payload['arduino_cli']}",
                ]
            ),
            title="UNO Q Bridge Flashed",
            border_style="green",
        )
    )


@edge_app.command(name="benchmark")
def edge_benchmark_alias(
    algo: Annotated[Path, typer.Option(help="Path to the insulin algorithm Python file used for the edge benchmark.")],
    output_json: Annotated[Path, typer.Option(help="Output JSON path for the hardware benchmark results.")] = Path("results/edge_benchmark.json"),
    patient_config: Annotated[str, typer.Option(help="Patient configuration name or YAML path.")] = "default_patient",
    patient_model: Annotated[str, typer.Option("--patient-model", help="Patient model type.")] = "auto",
    scenario_profile: Annotated[str, typer.Option(help="Digital patient scenario profile.")] = "normal_day",
    steps: Annotated[int, typer.Option(help="Number of simulated steps used for throughput measurement.")] = 72,
    platform_name: Annotated[str, typer.Option("--platform", help="Platform label written into the benchmark report. Use 'auto' to detect locally.")] = "auto",
    api_host: Annotated[str, typer.Option(help="Host used for the local dashboard probe.")] = "127.0.0.1",
    api_port: Annotated[int, typer.Option(help="Port used for the local dashboard probe.")] = 8766,
    seed: Annotated[Optional[int], typer.Option(help="Optional deterministic seed override.")] = None,
) -> None:
    edge_benchmark(
        algo=algo,
        output_json=output_json,
        patient_config=patient_config,
        patient_model=patient_model,
        scenario_profile=scenario_profile,
        steps=steps,
        platform_name=platform_name,
        api_host=api_host,
        api_port=api_port,
        seed=seed,
    )
