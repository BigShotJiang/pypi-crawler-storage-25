# SPDX-License-Identifier: AGPL-3.0-or-later
import sqlite3
from datetime import UTC, datetime, timedelta
from pathlib import Path

import pytest

from nexus.db.t2 import T2Database, _sanitize_fts5

_OLD_FTS_SCHEMA = """PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS memory (
  id INTEGER PRIMARY KEY, project TEXT NOT NULL, title TEXT NOT NULL,
  session TEXT, agent TEXT, content TEXT NOT NULL, tags TEXT,
  timestamp TEXT NOT NULL, ttl INTEGER);
CREATE UNIQUE INDEX IF NOT EXISTS idx_memory_project_title ON memory(project, title);
CREATE INDEX IF NOT EXISTS idx_memory_project ON memory(project);
CREATE INDEX IF NOT EXISTS idx_memory_agent ON memory(agent);
CREATE INDEX IF NOT EXISTS idx_memory_timestamp ON memory(timestamp);
CREATE INDEX IF NOT EXISTS idx_memory_ttl_timestamp ON memory(ttl, timestamp);
CREATE VIRTUAL TABLE IF NOT EXISTS memory_fts USING fts5(
  content, tags, content='memory', content_rowid='id');
CREATE TRIGGER IF NOT EXISTS memory_ai AFTER INSERT ON memory BEGIN
  INSERT INTO memory_fts(rowid, content, tags) VALUES (new.id, new.content, new.tags); END;
CREATE TRIGGER IF NOT EXISTS memory_ad AFTER DELETE ON memory BEGIN
  INSERT INTO memory_fts(memory_fts, rowid, content, tags)
  VALUES ('delete', old.id, old.content, old.tags); END;
CREATE TRIGGER IF NOT EXISTS memory_au AFTER UPDATE ON memory BEGIN
  INSERT INTO memory_fts(memory_fts, rowid, content, tags)
  VALUES ('delete', old.id, old.content, old.tags);
  INSERT INTO memory_fts(rowid, content, tags) VALUES (new.id, new.content, new.tags); END;"""


# ── helpers ──────────────────────────────────────────────────────────────────

def _backdate(db: T2Database, title: str, days: float = 0, seconds: float = 0) -> None:
    past = (datetime.now(UTC) - timedelta(days=days, seconds=seconds)).strftime("%Y-%m-%dT%H:%M:%SZ")
    db.conn.execute("UPDATE memory SET timestamp=? WHERE title=?", (past, title))
    db.conn.commit()


def _create_old_schema_db(path: Path) -> None:
    conn = sqlite3.connect(str(path))
    conn.executescript(_OLD_FTS_SCHEMA)
    conn.execute(
        "INSERT INTO memory (project, title, session, agent, content, tags, timestamp, ttl) "
        "VALUES (?, ?, NULL, NULL, ?, ?, ?, ?)",
        ("testproj", "RDR-007-design.md", "generic body content", "rdr", "2026-01-01T00:00:00Z", 30),
    )
    conn.commit()
    conn.close()


# ── context manager ──────────────────────────────────────────────────────────

def test_context_manager_closes_on_exit(tmp_path: Path) -> None:
    with T2Database(tmp_path / "cm.db") as db:
        row_id = db.put(project="test", title="cm-entry", content="hello")
        assert row_id is not None
    with pytest.raises(Exception):
        db.conn.execute("SELECT 1")


def test_context_manager_closes_on_exception(tmp_path: Path) -> None:
    with pytest.raises(ValueError, match="intentional"):
        with T2Database(tmp_path / "cm_exc.db") as db:
            db.put(project="test", title="exc-entry", content="before error")
            raise ValueError("intentional")
    with pytest.raises(Exception):
        db.conn.execute("SELECT 1")


def test_context_manager_returns_self(tmp_path: Path) -> None:
    with T2Database(tmp_path / "cm_self.db") as db:
        assert isinstance(db, T2Database)


def test_context_manager_does_not_suppress_exception(tmp_path: Path) -> None:
    with pytest.raises(RuntimeError, match="propagated"):
        with T2Database(tmp_path / "cm_nosup.db") as db:
            raise RuntimeError("propagated")


# ── get() ValueError ─────────────────────────────────────────────────────────

@pytest.mark.parametrize("kwargs", [
    {},
    {"project": "proj"},
    {"title": "some.md"},
])
def test_get_missing_args_raises_valueerror(db: T2Database, kwargs: dict) -> None:
    with pytest.raises(ValueError, match="Provide either id or both project and title"):
        db.get(**kwargs)


# ── WAL mode ─────────────────────────────────────────────────────────────────

def test_wal_mode_enabled(db: T2Database) -> None:
    mode = db.conn.execute("PRAGMA journal_mode").fetchone()[0]
    assert mode.lower() == "wal"


# ── expire ───────────────────────────────────────────────────────────────────

def test_expire_returns_zero_on_fresh_db(db: T2Database) -> None:
    assert db.expire() == 0


@pytest.mark.parametrize("title,ttl,backdate_days,backdate_secs,expect_deleted,expect_gone", [
    ("stale.md",     1,    2,  0, 1, True),
    ("fresh.md",     30,   0,  0, 0, False),
    ("permanent.md", None, 1000, 0, 0, False),
    ("zero.md",      0,    0, 60, 1, True),
    ("recent.md",    30,  29,  0, 0, False),
])
def test_expire_scenarios(
    db: T2Database, title: str, ttl: int | None,
    backdate_days: float, backdate_secs: float,
    expect_deleted: int, expect_gone: bool,
) -> None:
    db.put(project="proj", title=title, content="data", ttl=ttl)
    if backdate_days or backdate_secs:
        _backdate(db, title, days=backdate_days, seconds=backdate_secs)
    assert db.expire() == expect_deleted
    if expect_gone:
        assert db.get(project="proj", title=title) is None
    else:
        assert db.get(project="proj", title=title) is not None


# ── list_entries with agent filter ───────────────────────────────────────────

def test_list_entries_with_agent_filter(db: T2Database) -> None:
    db.put(project="proj", title="a.md", content="aaa", agent="agent-alpha")
    db.put(project="proj", title="b.md", content="bbb", agent="agent-beta")
    db.put(project="proj", title="c.md", content="ccc", agent="agent-alpha")

    alpha = db.list_entries(project="proj", agent="agent-alpha")
    assert {e["title"] for e in alpha} == {"a.md", "c.md"}

    beta = db.list_entries(project="proj", agent="agent-beta")
    assert len(beta) == 1 and beta[0]["title"] == "b.md"


def test_list_entries_agent_filter_only(db: T2Database) -> None:
    db.put(project="proj_a", title="x.md", content="xxx", agent="shared-agent")
    db.put(project="proj_b", title="y.md", content="yyy", agent="shared-agent")
    db.put(project="proj_c", title="z.md", content="zzz", agent="other-agent")

    entries = db.list_entries(agent="shared-agent")
    assert {e["title"] for e in entries} == {"x.md", "y.md"}


# ── search_glob ──────────────────────────────────────────────────────────────

def test_search_glob(db: T2Database) -> None:
    db.put(project="nexus_rdr", title="phase1.md", content="authentication design")
    db.put(project="nexus_active", title="notes.md", content="authentication notes")
    db.put(project="arcaneum_rdr", title="arch.md", content="authentication architecture")

    results = db.search_glob("authentication", "*_rdr")
    assert {r["project"] for r in results} == {"nexus_rdr", "arcaneum_rdr"}


def test_search_glob_no_match(db: T2Database) -> None:
    db.put(project="nexus_active", title="notes.md", content="some content")
    assert db.search_glob("content", "*_rdr") == []


# ── get_projects_with_prefix ─────────────────────────────────────────────────

def test_get_projects_with_prefix_returns_matching(db: T2Database) -> None:
    db.put(project="nexus", title="ctx.md", content="main context")
    db.put(project="nexus_rdr", title="006.md", content="rdr entry")
    db.put(project="nexus_knowledge", title="notes.md", content="knowledge entry")
    db.put(project="other", title="x.md", content="unrelated")

    projects = {r["project"] for r in db.get_projects_with_prefix("nexus")}
    assert projects == {"nexus", "nexus_rdr", "nexus_knowledge"}


def test_get_projects_with_prefix_returns_last_updated(db: T2Database) -> None:
    db.put(project="repo_rdr", title="entry.md", content="content")
    results = db.get_projects_with_prefix("repo")
    assert len(results) == 1 and "last_updated" in results[0]


def test_get_projects_with_prefix_ordered_by_most_recent(db: T2Database) -> None:
    db.put(project="repo_knowledge", title="old.md", content="older entry")
    db.put(project="repo_rdr", title="new.md", content="newer entry")
    db.conn.execute(
        "UPDATE memory SET timestamp='2020-01-01T00:00:00Z' WHERE project='repo_knowledge'"
    )
    db.conn.commit()

    results = db.get_projects_with_prefix("repo")
    assert results[0]["project"] == "repo_rdr"
    assert results[1]["project"] == "repo_knowledge"


@pytest.mark.parametrize("prefix,setup,expected,excluded", [
    ("arcaneum", [("nexus_rdr", "e.md")], set(), set()),
    ("abc", [("abc", "e.md"), ("abc_sub", "e2.md"), ("xabc", "e3.md")],
     {"abc", "abc_sub"}, {"xabc"}),
    ("my_repo", [("my_repo", "a.md"), ("myXrepo", "b.md")],
     {"my_repo"}, {"myXrepo"}),
    ("50%", [("50%_done", "a.md"), ("50x_done", "b.md")],
     {"50%_done"}, {"50x_done"}),
    ("", [("alpha", "a.md")], set(), set()),
])
def test_get_projects_with_prefix_edge_cases(
    db: T2Database, prefix: str,
    setup: list[tuple[str, str]], expected: set[str], excluded: set[str],
) -> None:
    for proj, title in setup:
        db.put(project=proj, title=title, content="entry")
    projects = {r["project"] for r in db.get_projects_with_prefix(prefix)}
    assert projects == expected
    for ex in excluded:
        assert ex not in projects


# ── delete ───────────────────────────────────────────────────────────────────

def test_delete(db: T2Database) -> None:
    db.put(project="proj", title="doomed.md", content="to be deleted")
    assert db.delete(project="proj", title="doomed.md") is True
    assert db.get(project="proj", title="doomed.md") is None


def test_delete_nonexistent_returns_false(db: T2Database) -> None:
    assert db.delete(project="proj", title="never_existed.md") is False


def test_delete_removes_from_fts_index(db: T2Database) -> None:
    db.put(project="proj", title="indexed.md", content="searchable unique keyword xyzzy")
    assert len(db.search("xyzzy")) == 1
    db.delete(project="proj", title="indexed.md")
    assert db.search("xyzzy") == []


# ── search_by_tag ────────────────────────────────────────────────────────────

def test_search_by_tag(db: T2Database) -> None:
    db.put(project="nexus", title="phase1.md", content="authentication design", tags="rdr,phase:1")
    db.put(project="nexus", title="notes.md", content="authentication notes", tags="notes")
    db.put(project="arcaneum", title="arch.md", content="authentication architecture", tags="rdr,arch")

    results = db.search_by_tag("authentication", "rdr")
    assert {r["project"] for r in results} == {"nexus", "arcaneum"}


def test_search_by_tag_boundary_and_no_false_positive(db: T2Database) -> None:
    db.put(project="proj", title="active.md", content="active doc", tags="rdr")
    db.put(project="proj", title="archived.md", content="archived doc", tags="rdr-archived")
    db.put(project="proj", title="xrdr.md", content="xrdr doc", tags="xrdr")

    results = db.search_by_tag("doc", "rdr")
    assert len(results) == 1 and results[0]["title"] == "active.md"


def test_search_by_tag_no_match(db: T2Database) -> None:
    db.put(project="proj", title="notes.md", content="some content", tags="notes")
    assert db.search_by_tag("content", "rdr") == []


def test_search_by_tag_single_letter(db: T2Database) -> None:
    db.put(project="proj", title="tagged.md", content="searchable content", tags="a,b,c")
    assert len(db.search_by_tag("searchable", "b")) == 1


# ── FTS5 special characters ─────────────────────────────────────────────────

@pytest.mark.parametrize("title,content,query,expect_found", [
    ("cn.md", "训练神经网络 🚀", None, True),       # unicode roundtrip (checked via get)
    ("fr.md", "résumé cafetière naïve", "resume", True),
    ("quotes.md", 'He said "hello world" to everyone', "hello", True),
    ("auth.md", "authentication authorization tokens", "auth*", True),
])
def test_fts_special_characters(
    db: T2Database, title: str, content: str, query: str | None, expect_found: bool,
) -> None:
    db.put(project="proj", title=title, content=content)
    if query is None:
        entry = db.get(project="proj", title=title)
        assert entry is not None and entry["content"] == content
    else:
        assert (len(db.search(query)) >= 1) == expect_found


# ── Upsert semantics ────────────────────────────────────────────────────────

def test_put_upsert_updates_content(db: T2Database) -> None:
    db.put(project="proj", title="doc.md", content="version 1")
    db.put(project="proj", title="doc.md", content="version 2")

    entry = db.get(project="proj", title="doc.md")
    assert entry["content"] == "version 2"
    assert len(db.list_entries(project="proj")) == 1


def test_put_upsert_updates_fts(db: T2Database) -> None:
    db.put(project="proj", title="doc.md", content="unique_keyword_alpha")
    db.put(project="proj", title="doc.md", content="unique_keyword_beta")
    assert db.search("unique_keyword_alpha") == []
    assert len(db.search("unique_keyword_beta")) == 1


# ── get_all ──────────────────────────────────────────────────────────────────

def test_get_all_returns_full_content(db: T2Database) -> None:
    db.put(project="proj", title="a.md", content="content a")
    db.put(project="proj", title="b.md", content="content b")

    entries = db.get_all("proj")
    assert {e["title"] for e in entries} == {"a.md", "b.md"}
    assert all("content" in e["content"] for e in entries)


# ── _sanitize_fts5 ──────────────────────────────────────────────────────────

@pytest.mark.parametrize("input_q,expected", [
    ("hello world", "hello world"),
    ("verification-probe", '"verification-probe"'),
    ("phase:1", '"phase:1"'),
    ("foo bar-baz", 'foo "bar-baz"'),
    ('say"hello', '"say""hello"'),
])
def test_sanitize_fts5(input_q: str, expected: str) -> None:
    assert _sanitize_fts5(input_q) == expected


@pytest.mark.parametrize("search_fn,query,setup_kwargs", [
    ("search", "verification-probe", {}),
    ("search", "smoke-test", {"project": "proj"}),
    ("search_glob", "verification-probe", {"glob_pattern": "*_rdr"}),
    ("search_by_tag", "verification-probe", {"tag": "rdr"}),
])
def test_sanitize_fts5_hyphen_no_crash(
    db: T2Database, search_fn: str, query: str, setup_kwargs: dict,
) -> None:
    db.put(project="nexus_rdr", title="notes.md", content="verification probe", tags="rdr")
    if search_fn == "search":
        results = db.search(query, project=setup_kwargs.get("project"))
    elif search_fn == "search_glob":
        results = db.search_glob(query, setup_kwargs["glob_pattern"])
    else:
        results = db.search_by_tag(query, setup_kwargs["tag"])
    assert isinstance(results, list)


# ── FTS5 title indexing ──────────────────────────────────────────────────────

@pytest.mark.parametrize("title,content,query,project_filter,expect_count", [
    ("RDR-025-implementation.md", "some generic content", "RDR-025", None, 1),
    ("xylophone99.md", "completely different words", "xylophone99", None, 1),
])
def test_search_finds_by_title(
    db: T2Database, title: str, content: str, query: str,
    project_filter: str | None, expect_count: int,
) -> None:
    db.put(project="proj", title=title, content=content)
    results = db.search(query, project=project_filter)
    assert len(results) == expect_count


def test_search_title_with_project_filter(db: T2Database) -> None:
    db.put(project="proj_a", title="auth-design.md", content="generic text")
    db.put(project="proj_b", title="auth-notes.md", content="generic text")
    results = db.search("auth", project="proj_a")
    assert len(results) == 1 and results[0]["project"] == "proj_a"


def test_search_title_update_triggers_reindex(db: T2Database) -> None:
    db.put(project="proj", title="olduniquetitleword.md", content="content")
    assert len(db.search("olduniquetitleword")) == 1

    db.conn.execute(
        "UPDATE memory SET title='newuniquetitleword.md' "
        "WHERE project='proj' AND title='olduniquetitleword.md'"
    )
    db.conn.commit()

    assert db.search("olduniquetitleword") == []
    assert len(db.search("newuniquetitleword")) == 1


# ── FTS5 migration (old schema without title) ───────────────────────────────

def test_fts_migration_enables_title_search(tmp_path: Path) -> None:
    db_path = tmp_path / "old_schema.db"
    _create_old_schema_db(db_path)

    conn = sqlite3.connect(str(db_path))
    fts_schema = conn.execute(
        "SELECT sql FROM sqlite_master WHERE type='table' AND name='memory_fts'"
    ).fetchone()[0]
    assert "title" not in fts_schema
    conn.close()

    with T2Database(db_path) as db:
        fts_new = db.conn.execute(
            "SELECT sql FROM sqlite_master WHERE type='table' AND name='memory_fts'"
        ).fetchone()[0]
        assert "title" in fts_new

        db.put(project="testproj", title="RDR-999-migration.md", content="unrelated body")

        results = db.search("RDR-007")
        assert len(results) == 1 and results[0]["title"] == "RDR-007-design.md"

        results2 = db.search("RDR-999")
        assert len(results2) == 1 and results2[0]["title"] == "RDR-999-migration.md"


def test_fts_migration_is_idempotent(tmp_path: Path) -> None:
    db_path = tmp_path / "new_schema.db"
    with T2Database(db_path) as db:
        db.put(project="proj", title="existing-entry.md", content="content here")

    with T2Database(db_path) as db:
        results = db.search("existing-entry")
        assert len(results) == 1 and results[0]["title"] == "existing-entry.md"
