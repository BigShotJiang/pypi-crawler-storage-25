"""Comprehensive test suite for Antaris Agent tool system.

This file tests all major tool system components together:
- WebSearchTool (Brave API integration)
- WebFetchTool (URL fetch with SSRF protection) 
- BrowserTool (Playwright automation)
- FileOpsTool (File operations)
- ShellTool (Shell command execution)
- MCPClient (stdio + SSE transports)
- ToolRegistry (native + MCP tool management)
- Pipeline integration (tool loops with LLM)
"""

from __future__ import annotations

import asyncio
import json
import tempfile
from pathlib import Path
from unittest.mock import AsyncMock, Mock, patch
from typing import Dict, Any, List

import pytest
import httpx

from antaris_agent.tools.models import ToolDef, ToolResult, NativeTool
from antaris_agent.tools.native.web_search import WebSearchTool
from antaris_agent.tools.native.web_fetch import WebFetchTool
from antaris_agent.tools.native.browser import BrowserTool
from antaris_agent.tools.native.file_ops import FileOpsTool
from antaris_agent.tools.native.shell import ShellTool
from antaris_agent.tools.mcp_client import MCPClient
from antaris_agent.tools.tool_registry import ToolRegistry
from antaris_agent.tools.pipeline_integration import run_tool_loop
from antaris_agent.tools.adapters.js_bridge import JSToolBridge
from antaris_agent.llm.base import LLMProvider, Message, LLMResponse


# Mock LLM Provider for pipeline testing
class MockLLMProvider(LLMProvider):
    """Mock LLM provider for testing."""
    
    def __init__(self):
        super().__init__("test-key", "test-model")
        self.responses = []
        self.call_count = 0
    
    def set_responses(self, responses: List[LLMResponse]):
        """Set responses to return in sequence."""
        self.responses = responses
        self.call_count = 0
    
    async def complete(
        self,
        messages: List[Message],
        system: str = "",
        model: str = None,
        max_tokens: int = 4096,
        temperature: float = 0.7,
        tools: List[Dict[str, Any]] = None,
        thinking=None,
    ) -> LLMResponse:
        """Return next mock response."""
        if self.call_count < len(self.responses):
            response = self.responses[self.call_count]
            self.call_count += 1
            return response
        
        # Default response if no more mocked responses
        return LLMResponse(
            content="Default response",
            model="test-model",
            input_tokens=10,
            output_tokens=20,
            cost_usd=0.01,
            tool_use=None
        )
    
    def estimate_tokens(self, text: str) -> int:
        """Rough token estimate (chars / 4)."""
        return len(text) // 4


class TestWebSearchTool:
    """Test WebSearchTool with Brave API integration."""

    @pytest.mark.asyncio
    async def test_successful_search(self):
        """Test successful search with mock Brave API response."""
        with patch('antaris_agent.tools.native.web_search.httpx.AsyncClient') as mock_client:
            mock_response = Mock()
            mock_response.status_code = 200
            mock_response.json.return_value = {
                "web": {
                    "results": [
                        {
                            "title": "Test Result 1",
                            "url": "https://example.com/1",
                            "description": "Test description 1"
                        },
                        {
                            "title": "Test Result 2",
                            "url": "https://example.com/2", 
                            "description": "Test description 2"
                        }
                    ]
                }
            }
            
            mock_client.return_value.__aenter__ = AsyncMock(return_value=mock_client.return_value)
            mock_client.return_value.__aexit__ = AsyncMock(return_value=False)
            mock_client.return_value.get = AsyncMock(return_value=mock_response)
            
            tool = WebSearchTool(api_key="test-api-key")
            result = await tool.execute({"query": "test query"})
            
            assert result.success is True
            assert "Search Results for 'test query'" in result.content
            assert "Test Result 1" in result.content
            assert "https://example.com/1" in result.content

    @pytest.mark.asyncio
    async def test_missing_api_key(self):
        """Test search with missing API key."""
        tool = WebSearchTool(api_key="")
        result = await tool.execute({"query": "test"})
        
        assert result.success is False
        assert result.is_error is True
        assert "Missing API key" in result.error

    @pytest.mark.asyncio
    async def test_missing_query_parameter(self):
        """Test search with missing query parameter."""
        tool = WebSearchTool(api_key="test-key")
        result = await tool.execute({})
        
        assert result.success is False
        assert result.is_error is True
        assert "Missing required parameter: query" in result.error

    @pytest.mark.asyncio
    async def test_api_error_non_200_status(self):
        """Test search with API error (non-200 status)."""
        with patch('antaris_agent.tools.native.web_search.httpx.AsyncClient') as mock_client:
            mock_response = Mock()
            mock_response.status_code = 403
            mock_response.text = "Forbidden"
            
            mock_client.return_value.__aenter__ = AsyncMock(return_value=mock_client.return_value)
            mock_client.return_value.__aexit__ = AsyncMock(return_value=False)
            mock_client.return_value.get = AsyncMock(return_value=mock_response)
            
            tool = WebSearchTool(api_key="test-key")
            result = await tool.execute({"query": "test"})
            
            assert result.success is False
            assert result.is_error is True
            assert "Search API returned status 403" in result.error

    @pytest.mark.asyncio
    async def test_timeout(self):
        """Test search timeout."""
        with patch('antaris_agent.tools.native.web_search.httpx.AsyncClient') as mock_client:
            mock_client.return_value.__aenter__ = AsyncMock(return_value=mock_client.return_value)
            mock_client.return_value.__aexit__ = AsyncMock(return_value=False)
            mock_client.return_value.get = AsyncMock(side_effect=httpx.TimeoutException("Timeout"))
            
            tool = WebSearchTool(api_key="test-key")
            result = await tool.execute({"query": "test"})
            
            assert result.success is False
            assert result.is_error is True
            assert "timed out" in result.error

    @pytest.mark.asyncio
    async def test_network_error(self):
        """Test search network error."""
        with patch('antaris_agent.tools.native.web_search.httpx.AsyncClient') as mock_client:
            mock_client.return_value.__aenter__ = AsyncMock(return_value=mock_client.return_value)
            mock_client.return_value.__aexit__ = AsyncMock(return_value=False)
            mock_client.return_value.get = AsyncMock(side_effect=httpx.RequestError("Network error"))
            
            tool = WebSearchTool(api_key="test-key")
            result = await tool.execute({"query": "test"})
            
            assert result.success is False
            assert result.is_error is True
            assert "Network error" in result.error

    @pytest.mark.asyncio
    async def test_empty_results(self):
        """Test search with empty results."""
        with patch('antaris_agent.tools.native.web_search.httpx.AsyncClient') as mock_client:
            mock_response = Mock()
            mock_response.status_code = 200
            mock_response.json.return_value = {"web": {"results": []}}
            
            mock_client.return_value.__aenter__ = AsyncMock(return_value=mock_client.return_value)
            mock_client.return_value.__aexit__ = AsyncMock(return_value=False)
            mock_client.return_value.get = AsyncMock(return_value=mock_response)
            
            tool = WebSearchTool(api_key="test-key")
            result = await tool.execute({"query": "test"})
            
            assert result.success is True
            assert "No search results found" in result.content

    @pytest.mark.asyncio
    async def test_count_parameter_bounds(self):
        """Test count parameter bounds (min 1, max 10)."""
        with patch('antaris_agent.tools.native.web_search.httpx.AsyncClient') as mock_client:
            mock_response = Mock()
            mock_response.status_code = 200
            mock_response.json.return_value = {"web": {"results": []}}
            
            mock_client.return_value.__aenter__ = AsyncMock(return_value=mock_client.return_value)
            mock_client.return_value.__aexit__ = AsyncMock(return_value=False)
            mock_client.return_value.get = AsyncMock(return_value=mock_response)
            
            tool = WebSearchTool(api_key="test-key")
            
            # Test count=0 gets clamped to 1
            await tool.execute({"query": "test", "count": 0})
            mock_client.return_value.get.assert_called()
            call_kwargs = mock_client.return_value.get.call_args[1]
            assert call_kwargs['params']['count'] == 1
            
            # Test count=15 gets clamped to 10
            await tool.execute({"query": "test", "count": 15})
            call_kwargs = mock_client.return_value.get.call_args[1] 
            assert call_kwargs['params']['count'] == 10


class TestWebFetchTool:
    """Test WebFetchTool with URL fetch and SSRF protection."""

    @pytest.mark.asyncio
    async def test_successful_html_fetch_markdown(self):
        """Test successful HTML fetch → markdown extraction."""
        with patch('antaris_agent.tools.native.web_fetch.httpx.AsyncClient') as mock_client:
            mock_response = Mock()
            mock_response.status_code = 200
            mock_response.headers = {"content-type": "text/html"}
            mock_response.text = "<html><body><h1>Test Page</h1><p>Test content</p></body></html>"
            
            mock_client.return_value.__aenter__ = AsyncMock(return_value=mock_client.return_value)
            mock_client.return_value.__aexit__ = AsyncMock(return_value=False)
            mock_client.return_value.get = AsyncMock(return_value=mock_response)
            
            tool = WebFetchTool()
            with patch('antaris_agent.tools.native.web_fetch.html_to_markdown') as mock_md:
                mock_md.return_value = "# Test Page\n\nTest content"
                result = await tool.execute({
                    "url": "https://example.com", 
                    "extract_mode": "markdown"
                })
            
            assert result.success is True
            assert "# Test Page" in result.content

    @pytest.mark.asyncio
    async def test_successful_html_fetch_text(self):
        """Test successful HTML fetch → text extraction."""
        with patch('antaris_agent.tools.native.web_fetch.httpx.AsyncClient') as mock_client:
            mock_response = Mock()
            mock_response.status_code = 200
            mock_response.headers = {"content-type": "text/html"}
            mock_response.text = "<html><body><h1>Test Page</h1><p>Test content</p></body></html>"
            
            mock_client.return_value.__aenter__ = AsyncMock(return_value=mock_client.return_value)
            mock_client.return_value.__aexit__ = AsyncMock(return_value=False)
            mock_client.return_value.get = AsyncMock(return_value=mock_response)
            
            tool = WebFetchTool()
            with patch('antaris_agent.tools.native.web_fetch.html_to_text') as mock_text:
                mock_text.return_value = "Test Page\nTest content"
                result = await tool.execute({
                    "url": "https://example.com", 
                    "extract_mode": "text"
                })
            
            assert result.success is True
            assert "Test Page" in result.content

    @pytest.mark.asyncio
    async def test_plain_text_content_type(self):
        """Test plain text content type."""
        with patch('antaris_agent.tools.native.web_fetch.httpx.AsyncClient') as mock_client:
            mock_response = Mock()
            mock_response.status_code = 200
            mock_response.headers = {"content-type": "text/plain"}
            mock_response.text = "Plain text content"
            
            mock_client.return_value.__aenter__ = AsyncMock(return_value=mock_client.return_value)
            mock_client.return_value.__aexit__ = AsyncMock(return_value=False)
            mock_client.return_value.get = AsyncMock(return_value=mock_response)
            
            tool = WebFetchTool()
            result = await tool.execute({"url": "https://example.com/file.txt"})
            
            assert result.success is True
            assert result.content == "Plain text content"

    def test_ssrf_blocking_localhost(self):
        """Test SSRF blocking (localhost, 127.0.0.1, private IPs)."""
        tool = WebFetchTool()
        
        # Test localhost
        is_safe, error = tool._validate_url_security("http://localhost/test")
        assert not is_safe
        assert "localhost" in error
        
        # Test 127.0.0.1
        is_safe, error = tool._validate_url_security("http://127.0.0.1/test")
        assert not is_safe
        assert "localhost" in error
        
        # Test private IP ranges
        is_safe, error = tool._validate_url_security("http://192.168.1.1/test")
        assert not is_safe
        assert "private" in error
        
        is_safe, error = tool._validate_url_security("http://10.0.0.1/test")
        assert not is_safe
        assert "private" in error

    def test_ssrf_blocking_metadata_endpoints(self):
        """Test SSRF blocking of metadata endpoints."""
        tool = WebFetchTool()
        
        is_safe, error = tool._validate_url_security("http://169.254.169.254/metadata")
        assert not is_safe
        assert "private" in error or "metadata" in error or "reserved" in error
        
        is_safe, error = tool._validate_url_security("http://metadata.google.internal/")
        assert not is_safe
        assert "metadata" in error

    @pytest.mark.asyncio
    async def test_unsupported_url_scheme(self):
        """Test unsupported URL scheme (ftp://)."""
        tool = WebFetchTool()
        result = await tool.execute({"url": "ftp://example.com/file.txt"})
        
        assert result.success is False
        assert result.is_error is True
        assert "Unsupported URL scheme" in result.error

    @pytest.mark.asyncio
    async def test_content_truncation_at_max_chars(self):
        """Test content truncation at max_chars."""
        with patch('antaris_agent.tools.native.web_fetch.httpx.AsyncClient') as mock_client:
            # Create content longer than max_chars
            long_content = "x" * 60000  # Longer than 50KB default
            mock_response = Mock()
            mock_response.status_code = 200
            mock_response.headers = {"content-type": "text/html"}
            mock_response.text = f"<html><body><p>{long_content}</p></body></html>"
            
            mock_client.return_value.__aenter__ = AsyncMock(return_value=mock_client.return_value)
            mock_client.return_value.__aexit__ = AsyncMock(return_value=False)
            mock_client.return_value.get = AsyncMock(return_value=mock_response)
            
            tool = WebFetchTool(max_chars=1000)  # Small max_chars for testing
            with patch('antaris_agent.tools.native.web_fetch.html_to_markdown') as mock_md:
                mock_md.return_value = "x" * 1500  # Return more than max_chars
                result = await tool.execute({"url": "https://example.com"})
            
            assert result.success is True
            assert len(result.content) <= 1000 + 50  # Allow for truncation message
            assert "Content truncated" in result.content

    @pytest.mark.asyncio
    async def test_timeout(self):
        """Test timeout."""
        with patch('antaris_agent.tools.native.web_fetch.httpx.AsyncClient') as mock_client:
            mock_client.return_value.__aenter__ = AsyncMock(return_value=mock_client.return_value)
            mock_client.return_value.__aexit__ = AsyncMock(return_value=False)
            mock_client.return_value.get = AsyncMock(side_effect=httpx.TimeoutException("Timeout"))
            
            tool = WebFetchTool()
            result = await tool.execute({"url": "https://example.com"})
            
            assert result.success is False
            assert result.is_error is True
            assert "timed out" in result.error

    @pytest.mark.asyncio
    async def test_http_error_status(self):
        """Test HTTP error status."""
        with patch('antaris_agent.tools.native.web_fetch.httpx.AsyncClient') as mock_client:
            mock_response = Mock()
            mock_response.status_code = 404
            
            mock_client.return_value.__aenter__ = AsyncMock(return_value=mock_client.return_value)
            mock_client.return_value.__aexit__ = AsyncMock(return_value=False)
            mock_client.return_value.get = AsyncMock(return_value=mock_response)
            
            tool = WebFetchTool()
            result = await tool.execute({"url": "https://example.com/notfound"})
            
            assert result.success is False
            assert result.is_error is True
            assert "HTTP 404" in result.error


class TestBrowserTool:
    """Test BrowserTool with Playwright automation."""

    @pytest.mark.asyncio
    async def test_navigate_action(self):
        """Test navigate action (mock Playwright page)."""
        with patch('playwright.async_api.async_playwright') as mock_pw:
            mock_page = AsyncMock()
            mock_page.title = AsyncMock(return_value="Test Page")
            mock_page.inner_text = AsyncMock(return_value="Page content")
            
            mock_browser = AsyncMock()
            mock_browser.new_page = AsyncMock(return_value=mock_page)
            
            mock_playwright = AsyncMock()
            mock_playwright.chromium.launch = AsyncMock(return_value=mock_browser)
            mock_pw.return_value.__aenter__ = AsyncMock(return_value=mock_playwright)
            
            tool = BrowserTool()
            result = await tool.execute({
                "action": "navigate", 
                "url": "https://example.com"
            })
            
            assert result.success is True
            assert "Test Page" in result.content
            assert "Page content" in result.content

    @pytest.mark.asyncio
    async def test_screenshot_action(self):
        """Test screenshot action."""
        with patch('playwright.async_api.async_playwright') as mock_pw:
            mock_page = AsyncMock()
            mock_page.screenshot = AsyncMock()
            
            mock_browser = AsyncMock()
            mock_browser.new_page = AsyncMock(return_value=mock_page)
            
            mock_playwright = AsyncMock()
            mock_playwright.chromium.launch = AsyncMock(return_value=mock_browser)
            mock_pw.return_value.__aenter__ = AsyncMock(return_value=mock_playwright)
            
            with tempfile.TemporaryDirectory() as tmpdir:
                tool = BrowserTool(workspace_path=tmpdir)
                result = await tool.execute({"action": "screenshot"})
                
                assert result.success is True
                assert "Screenshot saved" in result.content
                mock_page.screenshot.assert_called_once()

    @pytest.mark.asyncio
    async def test_click_action(self):
        """Test click action."""
        with patch('playwright.async_api.async_playwright') as mock_pw:
            mock_page = AsyncMock()
            mock_page.click = AsyncMock()
            
            mock_browser = AsyncMock()
            mock_browser.new_page = AsyncMock(return_value=mock_page)
            
            mock_playwright = AsyncMock()
            mock_playwright.chromium.launch = AsyncMock(return_value=mock_browser)
            mock_pw.return_value.__aenter__ = AsyncMock(return_value=mock_playwright)
            
            tool = BrowserTool()
            result = await tool.execute({
                "action": "click", 
                "selector": "#button"
            })
            
            assert result.success is True
            assert "Successfully clicked" in result.content
            mock_page.click.assert_called_once_with("#button", timeout=10000)

    @pytest.mark.asyncio
    async def test_type_action(self):
        """Test type action."""
        with patch('playwright.async_api.async_playwright') as mock_pw:
            mock_page = AsyncMock()
            mock_page.fill = AsyncMock()
            
            mock_browser = AsyncMock()
            mock_browser.new_page = AsyncMock(return_value=mock_page)
            
            mock_playwright = AsyncMock()
            mock_playwright.chromium.launch = AsyncMock(return_value=mock_browser)
            mock_pw.return_value.__aenter__ = AsyncMock(return_value=mock_playwright)
            
            tool = BrowserTool()
            result = await tool.execute({
                "action": "type", 
                "selector": "#input",
                "text": "Hello World"
            })
            
            assert result.success is True
            assert "Successfully typed" in result.content
            mock_page.fill.assert_called_once_with("#input", "Hello World", timeout=10000)

    @pytest.mark.asyncio
    async def test_get_text_action(self):
        """Test get_text action."""
        with patch('playwright.async_api.async_playwright') as mock_pw:
            mock_element = AsyncMock()
            mock_element.inner_text = AsyncMock(return_value="Element text content")
            
            mock_page = AsyncMock()
            mock_page.wait_for_selector = AsyncMock(return_value=mock_element)
            
            mock_browser = AsyncMock()
            mock_browser.new_page = AsyncMock(return_value=mock_page)
            
            mock_playwright = AsyncMock()
            mock_playwright.chromium.launch = AsyncMock(return_value=mock_browser)
            mock_pw.return_value.__aenter__ = AsyncMock(return_value=mock_playwright)
            
            tool = BrowserTool()
            result = await tool.execute({
                "action": "get_text", 
                "selector": "#content"
            })
            
            assert result.success is True
            assert result.content == "Element text content"

    @pytest.mark.asyncio
    async def test_missing_required_parameters(self):
        """Test missing required parameters for each action."""
        tool = BrowserTool()
        # Prevent real Playwright init for param validation tests
        tool.browser = True  # truthy sentinel
        tool.page = AsyncMock()
        
        # Missing action
        result = await tool.execute({})
        assert result.success is False
        assert "Missing required parameter: action" in result.error
        
        # Missing URL for navigate
        result = await tool.execute({"action": "navigate"})
        assert result.success is False
        assert "Navigate action requires url parameter" in result.error
        
        # Missing selector for click
        result = await tool.execute({"action": "click"})
        assert result.success is False
        assert "Click action requires selector parameter" in result.error
        
        # Missing text for type
        result = await tool.execute({"action": "type", "selector": "#input"})
        assert result.success is False
        assert "Type action requires selector and text parameters" in result.error

    @pytest.mark.asyncio
    async def test_browser_init_failure(self):
        """Test browser init failure (playwright not installed)."""
        with patch('playwright.async_api.async_playwright', side_effect=ImportError("playwright not installed")):
            tool = BrowserTool()
            result = await tool.execute({
                "action": "navigate", 
                "url": "https://example.com"
            })
            
            assert result.success is False
            assert result.is_error is True
            assert "playwright" in result.error

    @pytest.mark.asyncio
    async def test_cleanup(self):
        """Test cleanup."""
        tool = BrowserTool()
        
        # Mock objects for cleanup
        mock_page = AsyncMock()
        mock_browser = AsyncMock()
        mock_playwright = AsyncMock()
        mock_playwright.__aexit__ = AsyncMock()
        
        tool.page = mock_page
        tool.browser = mock_browser
        tool._playwright = mock_playwright
        
        await tool._cleanup()
        
        mock_page.close.assert_called_once()
        mock_browser.close.assert_called_once()
        mock_playwright.__aexit__.assert_called_once()
        assert tool.page is None
        assert tool.browser is None
        assert tool._playwright is None


class TestMCPClient:
    """Test MCPClient for stdio + SSE transports."""

    @pytest.mark.asyncio
    async def test_stdio_connect_initialize_handshake(self):
        """Test stdio connect + initialize handshake."""
        with patch('asyncio.create_subprocess_exec') as mock_subprocess:
            mock_process = Mock()
            mock_process.returncode = None
            mock_process.stdin = Mock()
            mock_process.stdin.write = Mock()
            mock_process.stdin.drain = AsyncMock()
            mock_process.stdout = Mock()
            mock_subprocess.return_value = mock_process
            
            # Mock successful initialize response
            mock_process.stdout.readline = AsyncMock(
                return_value=b'{"jsonrpc":"2.0","id":1,"result":{}}\n'
            )
            
            client = MCPClient(
                name="test-server",
                transport="stdio", 
                command=["python", "-m", "test_server"]
            )
            
            await client.connect()
            
            assert client._connected is True
            assert client._process == mock_process
            mock_subprocess.assert_called_once()

    @pytest.mark.asyncio
    async def test_sse_connect(self):
        """Test sse connect."""
        with patch('httpx.AsyncClient') as mock_client_class:
            mock_client = AsyncMock()
            mock_response = Mock()
            mock_response.raise_for_status = Mock()
            mock_client.get = AsyncMock(return_value=mock_response)
            mock_client_class.return_value = mock_client
            
            client = MCPClient(
                name="test-server",
                transport="sse",
                url="http://localhost:8000"
            )
            
            # Mock successful initialize response
            mock_client.post = AsyncMock(return_value=Mock(
                json=Mock(return_value={"jsonrpc":"2.0","id":1,"result":{}})
            ))
            
            await client.connect()
            
            assert client._connected is True
            assert client._http_client == mock_client

    @pytest.mark.asyncio
    async def test_list_tools_parse_jsonrpc_response(self):
        """Test list_tools (parse JSON-RPC response)."""
        client = MCPClient(name="test-server")
        client._connected = True
        
        with patch.object(client, '_send_request') as mock_send:
            mock_send.return_value = {
                "jsonrpc": "2.0",
                "id": 1,
                "result": {
                    "tools": [
                        {
                            "name": "test_tool",
                            "description": "Test tool description",
                            "inputSchema": {"type": "object", "properties": {}}
                        }
                    ]
                }
            }
            
            tools = await client.list_tools()
            
            assert len(tools) == 1
            assert isinstance(tools[0], ToolDef)
            assert tools[0].name == "test_tool"
            assert tools[0].description == "Test tool description"
            assert tools[0].source == "mcp:test-server"

    @pytest.mark.asyncio
    async def test_call_tool(self):
        """Test call_tool."""
        client = MCPClient(name="test-server")
        client._connected = True
        
        with patch.object(client, '_send_request') as mock_send:
            mock_send.return_value = {
                "jsonrpc": "2.0",
                "id": 1,
                "result": {
                    "content": [
                        {"type": "text", "text": "Tool execution result"}
                    ]
                }
            }
            
            result = await client.call_tool("test_tool", {"arg": "value"})
            
            assert result.success is True
            assert result.content == "Tool execution result"
            assert not result.is_error

    @pytest.mark.asyncio
    async def test_disconnect_cleanup(self):
        """Test disconnect cleanup."""
        client = MCPClient(name="test-server", transport="stdio")
        
        # Mock stdio process (terminate/kill are sync methods in asyncio subprocess protocol)
        mock_process = Mock()
        mock_process.terminate = Mock()
        mock_process.kill = Mock()
        mock_process.wait = AsyncMock()
        client._process = mock_process
        client._connected = True
        
        await client.disconnect()
        
        mock_process.terminate.assert_called_once()
        assert client._connected is False
        assert client._process is None

    @pytest.mark.asyncio
    async def test_reconnection_on_failure(self):
        """Test reconnection on failure."""
        client = MCPClient(name="test-server")
        client._connected = True
        client._retry_count = 0
        
        # Mock first call fails, reconnection succeeds
        call_count = 0
        async def mock_send_request(message):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                raise ConnectionError("Connection lost")
            return {"jsonrpc": "2.0", "id": 1, "result": {"tools": []}}
        
        with patch.object(client, '_send_request', side_effect=mock_send_request):
            with patch.object(client, 'disconnect') as mock_disconnect:
                with patch.object(client, 'connect') as mock_connect:
                    tools = await client.list_tools()
                    
                    mock_disconnect.assert_called_once()
                    mock_connect.assert_called_once()
                    assert tools == []

    @pytest.mark.asyncio
    async def test_timeout_handling(self):
        """Test timeout handling."""
        client = MCPClient(name="test-server", transport="stdio", timeout=0.1)
        
        mock_process = Mock()
        mock_process.returncode = None
        mock_process.stdin = Mock()
        mock_process.stdin.write = Mock()
        mock_process.stdin.drain = AsyncMock()
        mock_process.stdout = Mock()
        
        # Mock readline that hangs (return a coroutine that sleeps)
        async def slow_readline():
            await asyncio.sleep(1)  # Sleep longer than timeout
            return b'{"result": {}}\n'
        
        mock_process.stdout.readline = AsyncMock(side_effect=slow_readline)
        client._process = mock_process
        
        with pytest.raises(asyncio.TimeoutError):
            message = {"jsonrpc": "2.0", "id": 1, "method": "test"}
            await client._send_request_stdio(message)

    @pytest.mark.asyncio
    async def test_healthcheck(self):
        """Test healthcheck."""
        client = MCPClient(name="test-server")
        client._connected = True
        
        with patch.object(client, '_send_request') as mock_send:
            mock_send.return_value = {"jsonrpc": "2.0", "id": 1, "result": {}}
            
            healthy = await client.healthcheck()
            assert healthy is True
            
            # Test failure case
            mock_send.side_effect = Exception("Connection error")
            healthy = await client.healthcheck()
            assert healthy is False


class TestToolRegistry:
    """Test ToolRegistry for native + MCP tool management."""

    @pytest.fixture
    def registry(self):
        """Create fresh ToolRegistry."""
        return ToolRegistry()

    @pytest.fixture  
    def mock_native_tool(self):
        """Create mock native tool."""
        tool = Mock(spec=NativeTool)
        tool.name = "test_native_tool"
        tool.description = "Test native tool"
        tool.input_schema = {"type": "object", "properties": {}}
        tool.execute = AsyncMock(return_value=ToolResult(success=True, content="Native result"))
        return tool

    @pytest.mark.asyncio
    async def test_register_native_tool(self, registry, mock_native_tool):
        """Test register native tool."""
        await registry.register_native("test_tool", mock_native_tool)
        
        assert registry.has_tool("test_tool")
        assert "test_tool" in registry.list_tools()
        
        definitions = await registry.get_tool_definitions()
        assert len(definitions) == 1
        assert definitions[0]["name"] == "test_tool"

    @pytest.mark.asyncio
    async def test_get_tool_definitions_anthropic_format(self, registry, mock_native_tool):
        """Test get_tool_definitions (Anthropic format)."""
        await registry.register_native("test_tool", mock_native_tool)
        
        definitions = await registry.get_tool_definitions()
        assert len(definitions) == 1
        
        definition = definitions[0]
        assert definition["name"] == "test_tool"
        assert definition["description"] == "Test native tool"
        assert definition["input_schema"] == {"type": "object", "properties": {}}

    def test_get_tool_definitions_sync(self, registry, mock_native_tool):
        """Test get_tool_definitions_sync."""
        # Need to set up the internal state manually since we can't await
        tool_def = ToolDef(
            name="test_tool",
            description="Test tool",
            input_schema={"type": "object"},
            source="native"
        )
        registry._tool_definitions["test_tool"] = tool_def
        
        definitions = registry.get_tool_definitions_sync()
        assert len(definitions) == 1
        assert definitions[0]["name"] == "test_tool"

    @pytest.mark.asyncio
    async def test_execute_tool_native(self, registry, mock_native_tool):
        """Test execute_tool (native)."""
        await registry.register_native("test_tool", mock_native_tool)
        
        result = await registry.execute_tool("test_tool", {"arg": "value"})
        
        assert result.success is True
        assert result.content == "Native result"
        mock_native_tool.execute.assert_called_once_with({"arg": "value"})

    @pytest.mark.asyncio
    async def test_execute_tool_mcp(self, registry):
        """Test execute_tool (MCP - mock client)."""
        mock_client = AsyncMock()
        mock_client.call_tool = AsyncMock(return_value=ToolResult(success=True, content="MCP result"))
        registry._mcp_clients["test_server"] = mock_client
        
        # Register MCP tool
        tool_def = ToolDef(
            name="mcp_tool",
            description="MCP tool",
            input_schema={},
            source="mcp:test_server"
        )
        registry._tool_definitions["mcp_tool"] = tool_def
        
        result = await registry.execute_tool("mcp_tool", {"arg": "value"})
        
        assert result.success is True
        assert result.content == "MCP result"
        mock_client.call_tool.assert_called_once_with("mcp_tool", {"arg": "value"})

    @pytest.mark.asyncio
    async def test_tool_name_conflict(self, registry, mock_native_tool):
        """Test tool name conflict (native vs MCP prefix)."""
        # Register native tool first
        await registry.register_native("conflict_tool", mock_native_tool)
        
        # Mock MCP client with conflicting tool name
        mock_client = AsyncMock()
        mock_client.connect = AsyncMock()
        mock_client.list_tools = AsyncMock(return_value=[
            ToolDef(
                name="conflict_tool",
                description="MCP tool with same name",
                input_schema={},
                source="mcp:test_server"
            )
        ])
        
        with patch('antaris_agent.tools.tool_registry.MCPClient', return_value=mock_client):
            await registry.add_mcp_server(
                name="test_server",
                transport="stdio",
                command=["python", "-m", "test_server"]
            )
        
        # Native tool should keep original name, MCP tool should be prefixed
        assert registry.has_tool("conflict_tool")  # Native tool
        assert registry.has_tool("test_server.conflict_tool")  # Prefixed MCP tool
        
        tools = registry.list_tools()
        assert "conflict_tool" in tools
        assert "test_server.conflict_tool" in tools

    @pytest.mark.asyncio
    async def test_remove_mcp_server(self, registry):
        """Test remove_mcp_server."""
        mock_client = AsyncMock()
        mock_client.disconnect = AsyncMock()
        registry._mcp_clients["test_server"] = mock_client
        
        # Add some tool definitions from this server
        registry._tool_definitions["mcp_tool"] = ToolDef(
            name="mcp_tool",
            description="MCP tool",
            input_schema={},
            source="mcp:test_server"
        )
        
        await registry.remove_mcp_server("test_server")
        
        assert "test_server" not in registry._mcp_clients
        assert not registry.has_tool("mcp_tool")
        mock_client.disconnect.assert_called_once()

    @pytest.mark.asyncio
    async def test_shutdown_cleans_everything(self, registry, mock_native_tool):
        """Test shutdown cleans everything."""
        await registry.register_native("test_tool", mock_native_tool)
        
        mock_client = AsyncMock()
        mock_client.disconnect = AsyncMock()
        registry._mcp_clients["test_server"] = mock_client
        
        await registry.shutdown()
        
        assert len(registry._native_tools) == 0
        assert len(registry._mcp_clients) == 0
        assert len(registry._tool_definitions) == 0
        assert not registry._initialized
        mock_client.disconnect.assert_called_once()

    def test_has_tool_list_tools(self, registry):
        """Test has_tool / list_tools."""
        # Setup tool definitions manually
        registry._tool_definitions["tool1"] = ToolDef(
            name="tool1", description="Tool 1", input_schema={}, source="native"
        )
        registry._tool_definitions["tool2"] = ToolDef(
            name="tool2", description="Tool 2", input_schema={}, source="mcp:server"
        )
        
        assert registry.has_tool("tool1")
        assert registry.has_tool("tool2")
        assert not registry.has_tool("tool3")
        
        tools = registry.list_tools()
        assert "tool1" in tools
        assert "tool2" in tools
        assert len(tools) == 2

    @pytest.mark.asyncio
    async def test_execute_unknown_tool(self, registry):
        """Test execute unknown tool."""
        result = await registry.execute_tool("unknown_tool", {})
        
        assert result.success is False
        assert result.is_error is True
        assert "Tool 'unknown_tool' not found" in result.content
        assert "Unknown tool: unknown_tool" in result.error


class TestPipelineToolLoop:
    """Test pipeline tool loop integration."""

    @pytest.fixture
    def mock_llm(self):
        """Create mock LLM provider."""
        return MockLLMProvider()

    @pytest.fixture
    def mock_registry(self):
        """Create mock tool registry."""
        registry = AsyncMock()
        registry.execute_tool = AsyncMock(return_value=ToolResult(
            success=True, content="Tool executed successfully"
        ))
        return registry

    @pytest.mark.asyncio
    async def test_run_tool_loop_with_tool_use(self, mock_llm, mock_registry):
        """Test run_tool_loop with mock LLM that returns tool_use."""
        # Set up LLM responses: first tool use, then text response
        responses = [
            LLMResponse(
                content="I'll help you with that.",
                model="test-model",
                input_tokens=10,
                output_tokens=20,
                cost_usd=0.01,
                tool_use=[{
                    "id": "tool_123",
                    "name": "test_tool",
                    "input": {"arg": "value"}
                }]
            ),
            LLMResponse(
                content="Task completed successfully!",
                model="test-model", 
                input_tokens=15,
                output_tokens=25,
                cost_usd=0.02,
                tool_use=None
            )
        ]
        mock_llm.set_responses(responses)
        
        messages = [Message(role="user", content="Test message")]
        tools = [{"name": "test_tool", "description": "Test tool"}]
        
        final_text, updated_messages, metadata = await run_tool_loop(
            llm=mock_llm,
            messages=messages,
            tools=tools,
            tool_registry=mock_registry,
            max_iterations=10
        )
        
        assert final_text == "Task completed successfully!"
        assert len(metadata["tool_calls_made"]) == 1
        assert metadata["tool_calls_made"][0]["name"] == "test_tool"
        assert metadata["iterations"] == 2
        assert not metadata["stopped_by_max_iterations"]

    @pytest.mark.asyncio
    async def test_max_iterations_limit(self, mock_llm, mock_registry):
        """Test max_iterations limit."""
        # Set up LLM to always return tool use (infinite loop)
        tool_response = LLMResponse(
            content="Using tool again...",
            model="test-model",
            input_tokens=10,
            output_tokens=20,
            cost_usd=0.01,
            tool_use=[{
                "id": "tool_123",
                "name": "test_tool",
                "input": {"arg": "value"}
            }]
        )
        mock_llm.set_responses([tool_response] * 10)  # Return same response 10 times
        
        messages = [Message(role="user", content="Test message")]
        tools = [{"name": "test_tool", "description": "Test tool"}]
        
        final_text, updated_messages, metadata = await run_tool_loop(
            llm=mock_llm,
            messages=messages,
            tools=tools,
            tool_registry=mock_registry,
            max_iterations=3
        )
        
        assert "maximum number of tool calls" in final_text
        assert metadata["iterations"] == 3
        assert metadata["stopped_by_max_iterations"] is True
        assert len(metadata["tool_calls_made"]) == 3

    @pytest.mark.asyncio
    async def test_tool_execution_error_handling(self, mock_llm, mock_registry):
        """Test tool execution error handling."""
        # Set up tool to return error
        mock_registry.execute_tool = AsyncMock(return_value=ToolResult(
            success=False, content="", error="Tool execution failed", is_error=True
        ))
        
        responses = [
            LLMResponse(
                content="I'll use the tool.",
                model="test-model",
                input_tokens=10,
                output_tokens=20,
                cost_usd=0.01,
                tool_use=[{
                    "id": "tool_123",
                    "name": "test_tool",
                    "input": {"arg": "value"}
                }]
            ),
            LLMResponse(
                content="I see the tool failed. Let me handle this error.",
                model="test-model",
                input_tokens=15,
                output_tokens=25,
                cost_usd=0.02,
                tool_use=None
            )
        ]
        mock_llm.set_responses(responses)
        
        messages = [Message(role="user", content="Test message")]
        tools = [{"name": "test_tool", "description": "Test tool"}]
        
        final_text, updated_messages, metadata = await run_tool_loop(
            llm=mock_llm,
            messages=messages,
            tools=tools,
            tool_registry=mock_registry,
            max_iterations=10
        )
        
        assert final_text == "I see the tool failed. Let me handle this error."
        assert len(metadata["tool_calls_made"]) == 1
        assert not metadata["tool_calls_made"][0]["success"]
        assert metadata["tool_calls_made"][0]["error"] == "Tool execution failed"

    @pytest.mark.asyncio
    async def test_final_text_response_extraction(self, mock_llm, mock_registry):
        """Test final text response extraction."""
        # Set up LLM to return text immediately (no tools)
        responses = [
            LLMResponse(
                content="This is a direct text response without tools.",
                model="test-model",
                input_tokens=10,
                output_tokens=20,
                cost_usd=0.01,
                tool_use=None
            )
        ]
        mock_llm.set_responses(responses)
        
        messages = [Message(role="user", content="Test message")]
        tools = []
        
        final_text, updated_messages, metadata = await run_tool_loop(
            llm=mock_llm,
            messages=messages,
            tools=tools,
            tool_registry=mock_registry,
            max_iterations=10
        )
        
        assert final_text == "This is a direct text response without tools."
        assert metadata["iterations"] == 1
        assert len(metadata["tool_calls_made"]) == 0
        assert not metadata["stopped_by_max_iterations"]


# Additional comprehensive tests
class TestFileOpsTool:
    """Test FileOpsTool with workspace validation."""

    def test_workspace_validation(self):
        """Test workspace validation prevents path traversal."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tool = FileOpsTool(workspace_path=tmpdir)
            
            # Test valid path
            is_valid, error, _ = tool._validate_path("test.txt")
            assert is_valid
            
            # Test path traversal attempt
            is_valid, error, _ = tool._validate_path("../../../etc/passwd")
            assert not is_valid
            assert "Path traversal" in error

    @pytest.mark.asyncio
    async def test_file_operations(self):
        """Test file read/write/edit operations."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tool = FileOpsTool(workspace_path=tmpdir)
            
            # Test write
            result = await tool.execute({
                "operation": "write",
                "path": "test.txt", 
                "content": "Hello World"
            })
            assert result.success is True
            
            # Test read
            result = await tool.execute({
                "operation": "read",
                "path": "test.txt"
            })
            assert result.success is True
            assert result.content == "Hello World"
            
            # Test edit
            result = await tool.execute({
                "operation": "edit",
                "path": "test.txt",
                "old_text": "World",
                "new_text": "Universe"
            })
            assert result.success is True
            
            # Verify edit
            result = await tool.execute({
                "operation": "read",
                "path": "test.txt"
            })
            assert result.content == "Hello Universe"


class TestShellTool:
    """Test ShellTool with workspace restrictions."""

    @pytest.mark.asyncio
    async def test_command_execution(self):
        """Test basic command execution with mocked subprocess."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tool = ShellTool(workspace_path=tmpdir, timeout=5)

            mock_proc = AsyncMock()
            mock_proc.communicate = AsyncMock(return_value=(b"Hello World\n", None))
            mock_proc.returncode = 0
            mock_proc.kill = AsyncMock()

            with patch('asyncio.create_subprocess_shell', return_value=mock_proc):
                result = await tool.execute({
                    "command": "echo 'Hello World'"
                })

            assert result.success is True
            assert "Hello World" in result.content

    @pytest.mark.asyncio
    async def test_command_timeout(self):
        """Test command timeout."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tool = ShellTool(workspace_path=tmpdir, timeout=1)

            mock_proc = Mock()
            mock_proc.communicate = AsyncMock(side_effect=asyncio.TimeoutError())
            mock_proc.returncode = None
            mock_proc.kill = Mock()
            mock_proc.wait = AsyncMock()

            with patch('asyncio.create_subprocess_shell', return_value=mock_proc):
                result = await tool.execute({
                    "command": "sleep 5"
                })

            assert result.success is False
            assert "timed out" in result.error.lower()

    @pytest.mark.asyncio
    async def test_command_failure(self):
        """Test command with non-zero exit code."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tool = ShellTool(workspace_path=tmpdir)

            mock_proc = AsyncMock()
            mock_proc.communicate = AsyncMock(return_value=(b"error output\n", None))
            mock_proc.returncode = 1
            mock_proc.kill = AsyncMock()

            with patch('asyncio.create_subprocess_shell', return_value=mock_proc):
                result = await tool.execute({
                    "command": "exit 1"
                })

            # Non-zero exit should still have content with the output
            assert "error output" in result.content or "Exit code: 1" in result.content

    @pytest.mark.asyncio
    async def test_missing_command_parameter(self):
        """Test missing command parameter."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tool = ShellTool(workspace_path=tmpdir)

            result = await tool.execute({})

            assert result.success is False
            assert "Missing required parameter: command" in result.error

    @pytest.mark.asyncio
    async def test_invalid_working_directory(self):
        """Test invalid working directory."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tool = ShellTool(workspace_path=tmpdir)

            result = await tool.execute({
                "command": "echo test",
                "workdir": "../../../etc"
            })

            assert result.success is False
            assert "outside workspace" in result.error.lower() or "not allowed" in result.error.lower()

    @pytest.mark.asyncio
    async def test_working_directory_validation(self):
        """Test working directory validation with valid subdir."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tool = ShellTool(workspace_path=tmpdir)

            subdir = Path(tmpdir) / "subdir"
            subdir.mkdir()

            mock_proc = AsyncMock()
            mock_proc.communicate = AsyncMock(return_value=(str(subdir).encode() + b"\n", None))
            mock_proc.returncode = 0
            mock_proc.kill = AsyncMock()

            with patch('asyncio.create_subprocess_shell', return_value=mock_proc):
                result = await tool.execute({
                    "command": "pwd",
                    "workdir": "subdir"
                })

            assert result.success is True


# Additional comprehensive integration tests
class TestIntegrationScenarios:
    """Integration tests combining multiple tools."""

    @pytest.mark.asyncio
    async def test_file_ops_read_nonexistent_file(self):
        """Test file operations with nonexistent file."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tool = FileOpsTool(workspace_path=tmpdir)
            
            result = await tool.execute({
                "operation": "read",
                "path": "nonexistent.txt"
            })
            
            assert result.success is False
            assert "File not found" in result.error

    @pytest.mark.asyncio
    async def test_file_ops_edit_nonexistent_text(self):
        """Test file edit with text that doesn't exist."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tool = FileOpsTool(workspace_path=tmpdir)
            
            # Write file first
            await tool.execute({
                "operation": "write",
                "path": "test.txt",
                "content": "Hello World"
            })
            
            # Try to edit non-existent text
            result = await tool.execute({
                "operation": "edit",
                "path": "test.txt",
                "old_text": "NotFound",
                "new_text": "Replacement"
            })
            
            assert result.success is False
            assert "Text to replace not found" in result.error

    @pytest.mark.asyncio
    async def test_file_ops_list_empty_directory(self):
        """Test listing empty directory."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tool = FileOpsTool(workspace_path=tmpdir)
            
            result = await tool.execute({
                "operation": "list",
                "path": "."
            })
            
            assert result.success is True
            assert "Directory is empty" in result.content

    @pytest.mark.asyncio
    async def test_web_search_exception_handling(self):
        """Test web search with unexpected exception."""
        with patch('antaris_agent.tools.native.web_search.httpx.AsyncClient') as mock_client:
            mock_client.return_value.__aenter__ = AsyncMock(return_value=mock_client.return_value)
            mock_client.return_value.__aexit__ = AsyncMock(return_value=False)
            mock_client.return_value.get = AsyncMock(side_effect=Exception("Unexpected error"))
            
            tool = WebSearchTool(api_key="test-key")
            result = await tool.execute({"query": "test"})
            
            assert result.success is False
            assert result.is_error is True
            assert "Unexpected error" in result.error

    @pytest.mark.asyncio
    async def test_web_fetch_unsupported_content_type(self):
        """Test web fetch with unsupported content type."""
        with patch('antaris_agent.tools.native.web_fetch.httpx.AsyncClient') as mock_client:
            mock_response = Mock()
            mock_response.status_code = 200
            mock_response.headers = {"content-type": "application/pdf"}
            
            mock_client.return_value.__aenter__ = AsyncMock(return_value=mock_client.return_value)
            mock_client.return_value.__aexit__ = AsyncMock(return_value=False)
            mock_client.return_value.get = AsyncMock(return_value=mock_response)
            
            tool = WebFetchTool()
            result = await tool.execute({"url": "https://example.com/file.pdf"})
            
            assert result.success is False
            assert result.is_error is True
            assert "Unsupported content type" in result.error

    @pytest.mark.asyncio
    async def test_mcp_client_connection_failure(self):
        """Test MCP client connection failure scenarios."""
        client = MCPClient(
            name="test-server",
            transport="stdio",
            command=["nonexistent-command"]
        )
        
        with patch('asyncio.create_subprocess_exec') as mock_subprocess:
            mock_process = Mock()
            mock_process.returncode = 1  # Process failed to start
            mock_subprocess.return_value = mock_process
            
            with pytest.raises(RuntimeError, match="failed to start"):
                await client.connect()

    def test_tool_registry_repr(self):
        """Test ToolRegistry string representation."""
        registry = ToolRegistry()
        
        # Add some test data
        registry._tool_definitions["native_tool"] = ToolDef(
            name="native_tool", description="Native", input_schema={}, source="native"
        )
        registry._tool_definitions["mcp_tool"] = ToolDef(
            name="mcp_tool", description="MCP", input_schema={}, source="mcp:server"
        )
        registry._mcp_clients["test_server"] = Mock()
        
        repr_str = repr(registry)
        assert "ToolRegistry" in repr_str
        assert "native_tools=1" in repr_str
        assert "mcp_tools=1" in repr_str
        assert "servers=1" in repr_str

    def test_mcp_client_repr(self):
        """Test MCPClient string representation."""
        client = MCPClient(name="test-server", transport="stdio")
        
        repr_str = repr(client)
        assert "MCPClient" in repr_str
        assert "name=test-server" in repr_str
        assert "transport=stdio" in repr_str
        assert "connected=False" in repr_str


class TestJSToolBridge:
    """Test JSToolBridge for JavaScript tool integration."""

    def test_init(self):
        """Test JSToolBridge initialization."""
        bridge = JSToolBridge(
            name="test-js-tool",
            script_path="/path/to/script.js"
        )
        
        assert bridge.name == "test-js-tool"
        assert bridge.script_path == Path("/path/to/script.js")
        assert bridge.node_path == "node"

    def test_init_custom_node_path(self):
        """Test JSToolBridge initialization with custom node path."""
        bridge = JSToolBridge(
            name="test-js-tool",
            script_path="/path/to/script.js",
            node_path="/usr/local/bin/node"
        )
        
        assert bridge.node_path == "/usr/local/bin/node"

    def test_check_node_available_exists(self):
        """Test check_node_available when Node.js exists."""
        bridge = JSToolBridge("test-tool", "script.js")
        
        with patch('shutil.which', return_value="/usr/bin/node"):
            result = bridge.check_node_available()
            assert result is True

    def test_check_node_available_missing(self):
        """Test check_node_available when Node.js is missing."""
        bridge = JSToolBridge("test-tool", "script.js")
        
        with patch('shutil.which', return_value=None):
            result = bridge.check_node_available()
            assert result is False

    @pytest.mark.asyncio
    async def test_start_process_node_missing(self):
        """Test _start_process when Node.js is missing."""
        bridge = JSToolBridge("test-tool", "script.js")
        
        with patch('shutil.which', return_value=None):
            with pytest.raises(RuntimeError, match="Node.js not found"):
                await bridge._start_process()

    @pytest.mark.asyncio
    async def test_start_process_script_missing(self):
        """Test _start_process when script file is missing."""
        with tempfile.TemporaryDirectory() as tmpdir:
            script_path = Path(tmpdir) / "nonexistent.js"
            bridge = JSToolBridge("test-tool", str(script_path))
            
            with patch('shutil.which', return_value="/usr/bin/node"):
                with pytest.raises(RuntimeError, match="Script not found"):
                    await bridge._start_process()

    @pytest.mark.asyncio
    async def test_call_success(self):
        """Test successful call."""
        with tempfile.TemporaryDirectory() as tmpdir:
            script_path = Path(tmpdir) / "script.js"
            script_path.write_text("// mock script")
            
            bridge = JSToolBridge("test-tool", str(script_path))
            
            with patch('subprocess.Popen') as mock_popen:
                mock_process = Mock()
                mock_process.poll.return_value = None  # Process running
                mock_process.pid = 12345
                mock_process.stdin = Mock()
                mock_process.stdout = Mock()
                mock_popen.return_value = mock_process
                
                # Mock _read_line to return a successful response
                async def mock_read_line():
                    return '{"jsonrpc": "2.0", "id": 1, "result": {"status": "success"}}'
                
                with patch.object(bridge, '_read_line', side_effect=mock_read_line):
                    with patch('shutil.which', return_value="/usr/bin/node"):
                        result = await bridge.call("test_method", {"arg": "value"})
                        
                        assert result == {"status": "success"}

    @pytest.mark.asyncio
    async def test_call_error_response(self):
        """Test call with error response."""
        with tempfile.TemporaryDirectory() as tmpdir:
            script_path = Path(tmpdir) / "script.js"
            script_path.write_text("// mock script")
            
            bridge = JSToolBridge("test-tool", str(script_path))
            
            with patch('subprocess.Popen') as mock_popen:
                mock_process = Mock()
                mock_process.poll.return_value = None
                mock_process.pid = 12345
                mock_process.stdin = Mock()
                mock_process.stdout = Mock()
                mock_popen.return_value = mock_process
                
                # Mock _read_line to return an error response
                async def mock_read_line():
                    return '{"jsonrpc": "2.0", "id": 1, "error": {"message": "Method failed"}}'
                
                with patch.object(bridge, '_read_line', side_effect=mock_read_line):
                    with patch('shutil.which', return_value="/usr/bin/node"):
                        with pytest.raises(RuntimeError, match="Method failed"):
                            await bridge.call("test_method", {"arg": "value"})

    @pytest.mark.asyncio
    async def test_call_timeout(self):
        """Test call timeout."""
        with tempfile.TemporaryDirectory() as tmpdir:
            script_path = Path(tmpdir) / "script.js"
            script_path.write_text("// mock script")
            
            bridge = JSToolBridge("test-tool", str(script_path))
            
            with patch('subprocess.Popen') as mock_popen:
                mock_process = Mock()
                mock_process.poll.return_value = None
                mock_process.pid = 12345
                mock_process.stdin = Mock()
                mock_process.stdout = Mock()
                mock_popen.return_value = mock_process
                
                # Mock _read_line to hang
                async def mock_read_line():
                    await asyncio.sleep(1)
                    return '{"result": {}}'
                
                # Mock the timeout in asyncio.wait_for to be very short
                original_wait_for = asyncio.wait_for
                async def mock_wait_for(coro, timeout):
                    if timeout == 30.0:  # Override the hardcoded timeout
                        timeout = 0.01
                    return await original_wait_for(coro, timeout)
                
                with patch.object(bridge, '_read_line', side_effect=mock_read_line):
                    with patch('asyncio.wait_for', side_effect=mock_wait_for):
                        with patch('shutil.which', return_value="/usr/bin/node"):
                            with pytest.raises(RuntimeError, match="Timeout"):
                                await bridge.call("test_method", {"arg": "value"})

    @pytest.mark.asyncio
    async def test_call_invalid_json_response(self):
        """Test call with invalid JSON response."""
        with tempfile.TemporaryDirectory() as tmpdir:
            script_path = Path(tmpdir) / "script.js"
            script_path.write_text("// mock script")
            
            bridge = JSToolBridge("test-tool", str(script_path))
            
            with patch('subprocess.Popen') as mock_popen:
                mock_process = Mock()
                mock_process.poll.return_value = None
                mock_process.pid = 12345
                mock_process.stdin = Mock()
                mock_process.stdout = Mock()
                mock_popen.return_value = mock_process
                
                # Mock _read_line to return invalid JSON
                async def mock_read_line():
                    return 'invalid json'
                
                with patch.object(bridge, '_read_line', side_effect=mock_read_line):
                    with patch('shutil.which', return_value="/usr/bin/node"):
                        with pytest.raises(RuntimeError, match="Invalid JSON"):
                            await bridge.call("test_method", {"arg": "value"})

    @pytest.mark.asyncio
    async def test_close(self):
        """Test close method."""
        bridge = JSToolBridge("test-tool", "script.js")
        
        mock_process = Mock()
        mock_process.terminate = Mock()
        mock_process.kill = Mock()
        bridge._process = mock_process
        
        # Mock _wait_for_exit to succeed immediately
        async def mock_wait():
            pass
            
        with patch.object(bridge, '_wait_for_exit', side_effect=mock_wait):
            await bridge.close()
            
            mock_process.terminate.assert_called_once()

    @pytest.mark.asyncio
    async def test_close_force_kill(self):
        """Test close method with force kill."""
        bridge = JSToolBridge("test-tool", "script.js")
        
        mock_process = Mock()
        mock_process.terminate = Mock()
        mock_process.kill = Mock()
        bridge._process = mock_process
        
        # Mock _wait_for_exit to timeout first time, succeed second time
        call_count = 0
        async def mock_wait():
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                raise asyncio.TimeoutError()
            
        with patch.object(bridge, '_wait_for_exit', side_effect=mock_wait):
            await bridge.close()
            
            mock_process.terminate.assert_called_once()
            mock_process.kill.assert_called_once()

    def test_from_openclaw_extension_missing_package_json(self):
        """Test from_openclaw_extension with missing package.json."""
        with tempfile.TemporaryDirectory() as tmpdir:
            result = JSToolBridge.from_openclaw_extension(tmpdir)
            assert result is None

    def test_from_openclaw_extension_no_main_script(self):
        """Test from_openclaw_extension with no main script."""
        with tempfile.TemporaryDirectory() as tmpdir:
            package_json = Path(tmpdir) / "package.json"
            package_json.write_text('{"name": "test-ext"}')
            
            result = JSToolBridge.from_openclaw_extension(tmpdir)
            assert result is None


if __name__ == "__main__":
    pytest.main([__file__, "-v"])