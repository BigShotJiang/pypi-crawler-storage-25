import httpx
import pytest
from unittest.mock import MagicMock


@pytest.mark.asyncio
async def test_google_provider_connect_error_normalized(monkeypatch):
    from antaris_agent.llm.google import GoogleProvider

    provider = GoogleProvider(api_key="x", model="gemini-2.0-flash")

    async def boom(*args, **kwargs):
        raise httpx.ConnectError(
            "no route", request=httpx.Request("POST", "https://example.com")
        )

    monkeypatch.setattr(provider._client, "post", boom)
    with pytest.raises(RuntimeError, match="network error"):
        await provider.complete(messages=[], system="hi")


@pytest.mark.asyncio
async def test_google_provider_timeout_normalized(monkeypatch):
    from antaris_agent.llm.google import GoogleProvider

    provider = GoogleProvider(api_key="x", model="gemini-2.0-flash")

    async def boom(*args, **kwargs):
        raise httpx.TimeoutException("timed out")

    monkeypatch.setattr(provider._client, "post", boom)
    with pytest.raises(RuntimeError, match="timed out"):
        await provider.complete(messages=[], system="hi")


@pytest.mark.asyncio
async def test_google_provider_invalid_json_normalized(monkeypatch):
    from antaris_agent.llm.google import GoogleProvider

    provider = GoogleProvider(api_key="x", model="gemini-2.0-flash")

    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.raise_for_status = MagicMock()
    mock_response.json = MagicMock(side_effect=ValueError("bad json"))

    async def return_bad_json(*args, **kwargs):
        return mock_response

    monkeypatch.setattr(provider._client, "post", return_bad_json)
    with pytest.raises(RuntimeError, match="invalid JSON"):
        await provider.complete(messages=[], system="hi")
