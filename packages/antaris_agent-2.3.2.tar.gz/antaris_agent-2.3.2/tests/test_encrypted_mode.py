"""
Tests for P0: encrypted mode fail-closed + honest encryption status.

Verifies:
  1. Bot raises RuntimeError if encryption key init fails (fail-closed)
  2. BotMemory raises RuntimeError if encrypted mode has no key
  3. encryption_status honestly reports no data-at-rest encryption
  4. Non-encrypted modes work fine without a key
"""

import os
import pytest
from pathlib import Path


def test_encrypted_mode_requires_key_in_memory(tmp_path):
    """BotMemory must raise if encrypted mode has no key."""
    from antaris_agent.core.memory import BotMemory
    with pytest.raises(RuntimeError, match="requires encryption_key"):
        BotMemory(
            store_path=str(tmp_path / "mem"),
            security_mode="encrypted",
            encryption_key=None,
        )


def test_memory_encryption_status_honest(tmp_path):
    """encryption_status should honestly report no data-at-rest encryption."""
    from antaris_agent.core.memory import BotMemory
    key = os.urandom(32)
    mem = BotMemory(
        store_path=str(tmp_path / "mem"),
        security_mode="encrypted",
        encryption_key=key,
    )
    status = mem.encryption_status
    assert status["mode"] == "encrypted"
    assert status["key_loaded"] is True
    assert status["data_at_rest_encrypted"] is False  # Honest!
    assert status["os_level_protection"] is True
    assert status["audit_hook_active"] is True


def test_non_encrypted_mode_works_without_key(tmp_path):
    """Standard mode should work fine without encryption key."""
    from antaris_agent.core.memory import BotMemory
    mem = BotMemory(
        store_path=str(tmp_path / "mem"),
        security_mode="standard",
        encryption_key=None,
    )
    assert mem.security_mode == "standard"


def test_encryption_status_standard_mode(tmp_path):
    """encryption_status for standard mode should show no OS protection."""
    from antaris_agent.core.memory import BotMemory
    mem = BotMemory(
        store_path=str(tmp_path / "mem"),
        security_mode="standard",
        encryption_key=None,
    )
    status = mem.encryption_status
    assert status["mode"] == "standard"
    assert status["key_loaded"] is False
    assert status["data_at_rest_encrypted"] is False
    assert status["os_level_protection"] is False
    assert status["audit_hook_active"] is True  # standard != open


def test_encryption_status_open_mode(tmp_path):
    """encryption_status for open mode should show no audit hook."""
    from antaris_agent.core.memory import BotMemory
    mem = BotMemory(
        store_path=str(tmp_path / "mem"),
        security_mode="open",
        encryption_key=None,
    )
    status = mem.encryption_status
    assert status["mode"] == "open"
    assert status["audit_hook_active"] is False


def test_encrypted_mode_with_key_succeeds(tmp_path):
    """Encrypted mode with a valid key should initialize without error."""
    from antaris_agent.core.memory import BotMemory
    key = os.urandom(32)
    mem = BotMemory(
        store_path=str(tmp_path / "mem"),
        security_mode="encrypted",
        encryption_key=key,
    )
    assert mem.security_mode == "encrypted"
    assert mem.encryption_key == key


def test_locked_mode_alias_requires_key(tmp_path):
    """'locked' is a legacy alias for 'encrypted' — should also require key."""
    from antaris_agent.core.memory import BotMemory
    # 'locked' normalizes to 'encrypted', so it should raise without a key
    with pytest.raises(RuntimeError, match="requires encryption_key"):
        BotMemory(
            store_path=str(tmp_path / "mem"),
            security_mode="locked",
            encryption_key=None,
        )
