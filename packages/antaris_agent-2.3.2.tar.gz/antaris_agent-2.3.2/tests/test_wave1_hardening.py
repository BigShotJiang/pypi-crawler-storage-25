"""
Wave 1 Runtime Integrity — Hardening Tests

Covers:
  1. BotMemory path traversal prevention (_normalize_user_id, _ensure_within_root)
  2. BotMemory.clear_memories() containment
  3. PPTX tool import path — shim resolution
  4. export_memories() zero-export bug fix
  5. Security-mode normalization (locked → encrypted)
"""

import asyncio
import hashlib
import json
import os
import re
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest


# ─────────────────────────────────────────────────────────────────────────────
# 1. BotMemory — Path Traversal Prevention
# ─────────────────────────────────────────────────────────────────────────────

class TestPathTraversal:
    """Verify that malicious user_ids cannot escape the memory store root."""

    def test_normalize_user_id_strips_slashes(self):
        from antaris_agent.core.memory import _normalize_user_id
        result = _normalize_user_id("../../etc/passwd")
        assert "/" not in result
        assert "\\" not in result
        assert ".." not in result

    def test_normalize_user_id_strips_null_bytes(self):
        from antaris_agent.core.memory import _normalize_user_id
        result = _normalize_user_id("user\x00evil")
        assert "\x00" not in result

    def test_normalize_user_id_deterministic(self):
        from antaris_agent.core.memory import _normalize_user_id
        a = _normalize_user_id("user-123")
        b = _normalize_user_id("user-123")
        assert a == b

    def test_normalize_user_id_different_for_different_inputs(self):
        from antaris_agent.core.memory import _normalize_user_id
        a = _normalize_user_id("alice")
        b = _normalize_user_id("bob")
        assert a != b

    def test_normalize_user_id_empty_raises(self):
        from antaris_agent.core.memory import _normalize_user_id
        with pytest.raises(ValueError):
            _normalize_user_id("")

    def test_normalize_user_id_whitespace_only_raises(self):
        from antaris_agent.core.memory import _normalize_user_id
        with pytest.raises(ValueError):
            _normalize_user_id("   ")

    def test_normalize_user_id_has_hash_suffix(self):
        """Output should include a SHA-256 prefix for uniqueness."""
        from antaris_agent.core.memory import _normalize_user_id
        result = _normalize_user_id("testuser")
        # Should end with a hex digest portion
        assert re.search(r'-[0-9a-f]{16}$', result)

    def test_ensure_within_root_rejects_escape(self):
        from antaris_agent.core.memory import _ensure_within_root
        root = Path(tempfile.mkdtemp())
        with pytest.raises(ValueError, match="escape"):
            _ensure_within_root(root / ".." / "etc", root)

    def test_ensure_within_root_allows_child(self):
        from antaris_agent.core.memory import _ensure_within_root
        root = Path(tempfile.mkdtemp())
        child = root / "subdir" / "data"
        child.mkdir(parents=True, exist_ok=True)
        result = _ensure_within_root(child, root)
        assert str(result).startswith(str(root.resolve()))

    def test_get_store_with_adversarial_user_id(self):
        """_get_store should sanitize and not create dirs outside store_path."""
        from antaris_agent.core.memory import BotMemory
        with tempfile.TemporaryDirectory() as tmpdir:
            bm = BotMemory(store_path=tmpdir, agent_name="test")
            # These would escape the store without sanitization
            adversarial_ids = [
                "../../etc/passwd",
                "../../../tmp/evil",
                "user/../../../escape",
                "..\\..\\windows\\system32",
                "valid_user/../../escape",
            ]
            for uid in adversarial_ids:
                try:
                    store = bm._get_store(uid)
                    # If it succeeds, the resolved path must be inside tmpdir
                    user_path = bm._user_store_path(uid)
                    assert str(user_path.resolve()).startswith(str(Path(tmpdir).resolve())), \
                        f"user_id {uid!r} escaped store root"
                except ValueError:
                    pass  # Also acceptable — the _ensure check rejected it


# ─────────────────────────────────────────────────────────────────────────────
# 2. BotMemory — clear_memories containment
# ─────────────────────────────────────────────────────────────────────────────

class TestClearMemoriesContainment:
    """Verify clear_memories only deletes within the user's store directory."""

    def test_clear_memories_normal_user(self):
        from antaris_agent.core.memory import BotMemory
        with tempfile.TemporaryDirectory() as tmpdir:
            bm = BotMemory(store_path=tmpdir, agent_name="test")
            # Create a dummy store for a user
            store = bm._get_store("user-clear-test")
            # Put a file in the user dir
            user_path = bm._user_store_path("user-clear-test")
            (user_path / "test.json").write_text("{}")
            assert (user_path / "test.json").exists()

            count = bm.clear_memories("user-clear-test")
            assert count >= 1
            # Verify files are gone
            remaining = list(user_path.rglob("*"))
            files_remaining = [f for f in remaining if f.is_file()]
            assert len(files_remaining) == 0

    def test_clear_memories_adversarial_user_id(self):
        """clear_memories with a path-traversal user_id must not escape."""
        from antaris_agent.core.memory import BotMemory
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create a sentinel file outside the store
            sentinel = Path(tmpdir) / "outside" / "sentinel.txt"
            sentinel.parent.mkdir(parents=True, exist_ok=True)
            sentinel.write_text("do not delete me")

            store_dir = Path(tmpdir) / "store"
            store_dir.mkdir()
            bm = BotMemory(store_path=str(store_dir), agent_name="test")

            # Try to clear with an adversarial ID
            try:
                bm.clear_memories("../../outside")
            except ValueError:
                pass  # Expected

            # Sentinel must still exist
            assert sentinel.exists(), "Sentinel file was deleted by adversarial clear_memories!"


# ─────────────────────────────────────────────────────────────────────────────
# 3. PPTX Tool Import — Shim Resolution
# ─────────────────────────────────────────────────────────────────────────────

class TestPPTXImport:
    """Verify PPTX ingestion is importable from parsica_memory (the canonical source)."""

    def test_import_from_parsica_memory(self):
        """Direct import from parsica_memory should work."""
        from parsica_memory.ingest_pptx import PPTXIngester
        assert PPTXIngester is not None
        assert hasattr(PPTXIngester, 'ingest')

    def test_tool_get_pptx_ingester_class(self):
        """The tool's dynamic import helper should resolve successfully."""
        from antaris_agent.tools.native.pptx_tool import _get_pptx_ingester_class
        cls = _get_pptx_ingester_class()
        assert cls is not None
        assert cls.__name__ == "PPTXIngester"

    def test_convenience_functions_available(self):
        """Convenience functions should be importable from parsica_memory directly."""
        from parsica_memory.ingest_pptx import (
            extract_text,
            extract_structure,
            extract_slide,
            summarize_deck,
        )
        assert callable(extract_text)
        assert callable(extract_structure)


# ─────────────────────────────────────────────────────────────────────────────
# 4. export_memories() — Zero-Export Bug Fix
# ─────────────────────────────────────────────────────────────────────────────

class TestExportMemories:
    """Verify export_memories returns all entries, not zero from empty-query BM25."""

    def test_export_uses_memories_attribute(self):
        """export_memories should access store.memories directly, not search('')."""
        from antaris_agent.core.memory import BotMemory
        with tempfile.TemporaryDirectory() as tmpdir:
            bm = BotMemory(store_path=tmpdir, agent_name="test")
            store = bm._get_store("user-export")

            # Manually add entries to the store's memory list
            from parsica_memory.entry import MemoryEntry
            for i in range(5):
                entry = MemoryEntry(
                    content=f"Test memory entry {i}",
                    source="test",
                    category="test",
                )
                store.memories.append(entry)
            store.save()

            # Export
            output_path = os.path.join(tmpdir, "export.json")
            count = bm.export_memories("user-export", output_path)

            # Should export all 5 entries
            assert count == 5, f"Expected 5 exports, got {count}"

            # Verify the file
            with open(output_path) as f:
                data = json.load(f)
            assert data["entry_count"] == 5
            assert len(data["entries"]) == 5

    def test_export_empty_store(self):
        """export_memories on an empty store should return 0, not error."""
        from antaris_agent.core.memory import BotMemory
        with tempfile.TemporaryDirectory() as tmpdir:
            bm = BotMemory(store_path=tmpdir, agent_name="test")

            output_path = os.path.join(tmpdir, "empty_export.json")
            count = bm.export_memories("user-empty", output_path)

            assert count == 0
            with open(output_path) as f:
                data = json.load(f)
            assert data["entry_count"] == 0

    def test_export_matches_ingest_count(self):
        """Memories ingested via store.ingest() should all appear in export."""
        from antaris_agent.core.memory import BotMemory
        with tempfile.TemporaryDirectory() as tmpdir:
            bm = BotMemory(store_path=tmpdir, agent_name="test")
            store = bm._get_store("user-ingest-export")

            # Ingest some entries
            for i in range(3):
                store.ingest(
                    f"Meeting notes from project alpha session {i}: discussed roadmap milestones and team assignments",
                    source="test",
                    category="meeting",
                )
            store.save()

            output_path = os.path.join(tmpdir, "ingest_export.json")
            count = bm.export_memories("user-ingest-export", output_path)

            assert count >= 3, f"Expected at least 3 exports after 3 ingests, got {count}"


# ─────────────────────────────────────────────────────────────────────────────
# 5. Security-Mode Normalization
# ─────────────────────────────────────────────────────────────────────────────

class TestSecurityModeNormalization:
    """Verify security modes are normalized consistently across the codebase."""

    def test_config_normalize_locked_to_encrypted(self):
        """Config should normalize 'locked' to 'encrypted'."""
        from antaris_agent.core.config import normalize_security_mode
        assert normalize_security_mode("locked") == "encrypted"

    def test_config_normalize_numeric_aliases(self):
        """Numeric aliases should map to names."""
        from antaris_agent.core.config import normalize_security_mode
        assert normalize_security_mode("0") == "open"
        assert normalize_security_mode("1") == "standard"
        assert normalize_security_mode("2") == "sandboxed"
        assert normalize_security_mode("3") == "secured"
        assert normalize_security_mode("4") == "encrypted"

    def test_config_normalize_unknown_defaults_to_sandboxed(self):
        from antaris_agent.core.config import normalize_security_mode
        assert normalize_security_mode("invalid_mode") == "sandboxed"
        assert normalize_security_mode("") == "sandboxed"
        assert normalize_security_mode(None) == "sandboxed"

    def test_config_normalize_case_insensitive(self):
        from antaris_agent.core.config import normalize_security_mode
        assert normalize_security_mode("ENCRYPTED") == "encrypted"
        assert normalize_security_mode("Sandboxed") == "sandboxed"
        assert normalize_security_mode("LOCKED") == "encrypted"

    def test_memory_normalize_locked_to_encrypted(self):
        """BotMemory should normalize 'locked' to 'encrypted' internally."""
        from antaris_agent.core.memory import _normalize_security_mode
        assert _normalize_security_mode("locked") == "encrypted"

    def test_memory_normalize_unknown_defaults_sandboxed(self):
        from antaris_agent.core.memory import _normalize_security_mode
        assert _normalize_security_mode("foobar") == "sandboxed"
        assert _normalize_security_mode("") == "sandboxed"

    def test_bot_memory_applies_chmod_for_encrypted(self):
        """BotMemory should chmod 700 for both 'locked' and 'encrypted' modes."""
        from antaris_agent.core.memory import BotMemory
        with tempfile.TemporaryDirectory() as tmpdir:
            bm = BotMemory(store_path=tmpdir, security_mode="encrypted", encryption_key=os.urandom(32), agent_name="test")
            mode = oct(Path(tmpdir).stat().st_mode)[-3:]
            assert mode == "700", f"Expected 700, got {mode}"

    def test_bot_memory_applies_chmod_for_locked(self):
        """BotMemory should chmod 700 for legacy 'locked' alias too."""
        from antaris_agent.core.memory import BotMemory
        with tempfile.TemporaryDirectory() as tmpdir:
            bm = BotMemory(store_path=tmpdir, security_mode="locked", encryption_key=os.urandom(32), agent_name="test")
            mode = oct(Path(tmpdir).stat().st_mode)[-3:]
            assert mode == "700", f"Expected 700 for 'locked', got {mode}"

    def test_bot_memory_stores_normalized_mode(self):
        """BotMemory.security_mode should always be the canonical value."""
        from antaris_agent.core.memory import BotMemory
        with tempfile.TemporaryDirectory() as tmpdir:
            bm = BotMemory(store_path=tmpdir, security_mode="locked", encryption_key=os.urandom(32), agent_name="test")
            assert bm.security_mode == "encrypted"

    def test_config_validate_no_longer_accepts_locked(self):
        """After normalization, validate() should pass for 'locked' input."""
        from antaris_agent.core.config import Config
        cfg = Config()
        cfg.security_mode = "locked"
        cfg.api_key = "test-key"
        errors = cfg.validate()
        # validate() normalizes, so locked → encrypted → valid
        assert not any("security_mode" in e for e in errors)

    def test_guard_mode_derived_from_encrypted(self):
        """Config.load should derive guard_mode='block' for encrypted mode."""
        from antaris_agent.core.config import Config
        import json
        with tempfile.TemporaryDirectory() as tmpdir:
            config_path = os.path.join(tmpdir, "config.json")
            config_data = {
                "provider": {"name": "anthropic", "apiKey": "test"},
                "security": {"mode": "locked"},
                "bot": {"name": "TestBot"},
            }
            with open(config_path, "w") as f:
                json.dump(config_data, f)

            cfg = Config.load(config_path)
            assert cfg is not None
            assert cfg.security_mode == "encrypted"
            assert cfg.guard_mode == "block"
