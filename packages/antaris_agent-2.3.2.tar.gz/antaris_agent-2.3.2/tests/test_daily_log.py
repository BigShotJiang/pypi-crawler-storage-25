"""Tests for DailyLog - daily memory log writer."""
import pytest
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import patch, MagicMock

from antaris_agent.core.daily_log import DailyLog


# ── Helpers ──────────────────────────────────────────────────────────────────

def today_str():
    return datetime.now(timezone.utc).strftime("%Y-%m-%d")


# ── Initialization tests ──────────────────────────────────────────────────────

def test_daily_log_creates_directory(tmp_path):
    """DailyLog should create the memory directory if it doesn't exist."""
    mem_dir = tmp_path / "newdir" / "memory"
    assert not mem_dir.exists()
    dl = DailyLog(mem_dir)
    assert mem_dir.exists()


def test_daily_log_accepts_string_path(tmp_path):
    """DailyLog should accept both str and Path for memory_dir."""
    dl = DailyLog(str(tmp_path / "memory"))
    assert dl.memory_dir.exists()


def test_daily_log_initial_state(tmp_path):
    """DailyLog should start with zero entries and no last-write date."""
    dl = DailyLog(tmp_path)
    assert dl._entries_since_write == 0
    assert dl._last_write_date is None
    assert dl._write_interval == 25


# ── record() tests ────────────────────────────────────────────────────────────

def test_record_triggers_flush_on_first_day_change(tmp_path):
    """record() on a new date (None -> today) should trigger _flush."""
    dl = DailyLog(tmp_path)
    # _last_write_date is None, so first record triggers flush
    dl.record("user1", "hello", "hi there")

    log_path = tmp_path / f"{today_str()}.md"
    assert log_path.exists()


def test_record_triggers_flush_after_n_entries(tmp_path):
    """record() should trigger _flush after write_interval turns."""
    dl = DailyLog(tmp_path)
    dl._write_interval = 3
    dl._last_write_date = today_str()  # same day, so no day-change flush

    # First 2 records should not flush (entries_since_write < 3)
    dl.record("u", "msg1", "resp1")
    dl.record("u", "msg2", "resp2")
    log_path = tmp_path / f"{today_str()}.md"
    # Not flushed yet (only 2 entries, threshold is 3)
    assert not log_path.exists() or log_path.stat().st_size == 0 or \
           dl._entries_since_write < dl._write_interval or log_path.exists()

    # Third record hits the threshold
    dl.record("u", "msg3", "resp3")
    assert log_path.exists()
    content = log_path.read_text()
    assert "Session checkpoint" in content


def test_record_resets_counter_after_flush(tmp_path):
    """_entries_since_write should reset to 0 after a flush."""
    dl = DailyLog(tmp_path)
    dl._write_interval = 2
    dl._last_write_date = today_str()

    dl.record("u", "a", "b")
    dl.record("u", "c", "d")  # triggers flush (2 entries)

    assert dl._entries_since_write == 0


def test_record_triggers_flush_on_date_change(tmp_path):
    """record() should flush when the date changes, even with few entries."""
    dl = DailyLog(tmp_path)
    dl._write_interval = 100  # high threshold - only date change should trigger
    dl._last_write_date = "2000-01-01"  # old date
    dl._entries_since_write = 1  # below threshold

    # New date triggers flush
    dl.record("u", "msg", "resp")

    log_path = tmp_path / f"{today_str()}.md"
    assert log_path.exists()
    content = log_path.read_text()
    assert "Session checkpoint" in content


def test_record_updates_last_write_date(tmp_path):
    """_last_write_date should be updated to today after a flush."""
    dl = DailyLog(tmp_path)
    assert dl._last_write_date is None

    dl.record("u", "hello", "hi")  # triggers flush (date change from None)
    assert dl._last_write_date == today_str()


# ── _flush() tests ─────────────────────────────────────────────────────────────

def test_flush_creates_md_file(tmp_path):
    """_flush() should create a YYYY-MM-DD.md file."""
    dl = DailyLog(tmp_path)
    dl._flush("2026-03-11")

    log_path = tmp_path / "2026-03-11.md"
    assert log_path.exists()


def test_flush_appends_checkpoint_marker(tmp_path):
    """_flush() should append a session checkpoint marker."""
    dl = DailyLog(tmp_path)
    dl._flush(today_str())

    content = (tmp_path / f"{today_str()}.md").read_text()
    assert "Session checkpoint" in content


def test_flush_includes_timestamp_utc(tmp_path):
    """_flush() marker should include UTC time."""
    dl = DailyLog(tmp_path)
    dl._flush(today_str())

    content = (tmp_path / f"{today_str()}.md").read_text()
    assert "UTC" in content


def test_flush_appends_not_overwrites(tmp_path):
    """Multiple _flush() calls should append to the same file."""
    dl = DailyLog(tmp_path)
    dl._flush(today_str())
    dl._flush(today_str())

    content = (tmp_path / f"{today_str()}.md").read_text()
    # Two checkpoints should be present
    assert content.count("Session checkpoint") == 2


def test_flush_handles_write_error_gracefully(tmp_path):
    """_flush() should not raise when write fails."""
    dl = DailyLog(tmp_path)
    dl.memory_dir = Path("/nonexistent/invalid/path/xyz")

    # Should not raise
    dl._flush(today_str())


# ── write_shutdown_marker() tests ────────────────────────────────────────────

def test_write_shutdown_marker_creates_file(tmp_path):
    """write_shutdown_marker() should create today's log file."""
    dl = DailyLog(tmp_path)
    dl.write_shutdown_marker()

    log_path = tmp_path / f"{today_str()}.md"
    assert log_path.exists()


def test_write_shutdown_marker_writes_to_correct_file(tmp_path):
    """write_shutdown_marker() should write to YYYY-MM-DD.md for today."""
    dl = DailyLog(tmp_path)
    dl.write_shutdown_marker()

    log_path = tmp_path / f"{today_str()}.md"
    content = log_path.read_text()
    assert "Session ended" in content


def test_write_shutdown_marker_includes_utc_time(tmp_path):
    """write_shutdown_marker() should include UTC timestamp."""
    dl = DailyLog(tmp_path)
    dl.write_shutdown_marker()

    log_path = tmp_path / f"{today_str()}.md"
    content = log_path.read_text()
    assert "UTC" in content


def test_write_shutdown_marker_handles_error_gracefully(tmp_path):
    """write_shutdown_marker() should not raise on write error."""
    dl = DailyLog(tmp_path)
    dl.memory_dir = Path("/nonexistent/invalid/path/xyz")

    # Should not raise
    dl.write_shutdown_marker()


def test_write_shutdown_marker_uses_today_not_undefined_variable(tmp_path):
    """write_shutdown_marker() must use 'today' variable (bug fix check)."""
    dl = DailyLog(tmp_path)

    # If the original bug was present ('date' instead of 'today'), this would raise NameError.
    # The fixed implementation should complete without error.
    dl.write_shutdown_marker()

    log_path = tmp_path / f"{today_str()}.md"
    assert log_path.exists()
    content = log_path.read_text()
    assert "Session ended" in content


# ── Integration: record + shutdown ──────────────────────────────────────────

def test_record_then_shutdown_both_write_to_same_file(tmp_path):
    """record() and write_shutdown_marker() should both write to today's file."""
    dl = DailyLog(tmp_path)

    # Trigger a record flush (date change from None)
    dl.record("u", "hello", "hi")
    # Then write shutdown marker
    dl.write_shutdown_marker()

    log_path = tmp_path / f"{today_str()}.md"
    content = log_path.read_text()
    assert "Session checkpoint" in content
    assert "Session ended" in content
