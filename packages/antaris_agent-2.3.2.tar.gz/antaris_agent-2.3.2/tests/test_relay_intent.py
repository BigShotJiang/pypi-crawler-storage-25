"""
Tests for antaris_agent.core.relay_intent — relay-intent detector.

Covers:
  - Mode A: acknowledge / stay-in-frame cases
  - Mode B: compose / direct-message cases
  - False-positive guard (should NOT trigger on stop-words)
  - Content + target extraction accuracy
  - build_relay_context_block output
  - Pipeline integration (relay detector wired into system prompt)
"""
from __future__ import annotations

import pytest
from antaris_agent.core.relay_intent import detect_relay_intent, build_relay_context_block, RelayIntent


# ---------------------------------------------------------------------------
# Mode A — stay in frame (acknowledge)
# ---------------------------------------------------------------------------

class TestModeA:
    """Expected stay-in-frame cases."""

    @pytest.mark.parametrize("text,expected_target", [
        ("Tell Laina I said thanks", "Laina"),
        ("tell laina i said thanks", "Laina"),
        ("Let Jason know I'm good with that", "Jason"),
        ("Tell Chemist I'm ready", "Chemist"),
        ("Please let Sarah know we're running late", "Sarah"),
        ("Pass this along to Marcus", "Marcus"),
        ("Ping Alex that the build is done", "Alex"),
        ("Say thanks to Jordan", "Jordan"),
        ("Send my regards to Elena", "Elena"),
        ("Inform Derek about the update", "Derek"),
        ("Remind Mike that the meeting is at 3", "Mike"),
        ("tell him that i finished", None),   # stop-word target — should NOT trigger or should filter
    ])
    def test_acknowledge_mode_detected(self, text, expected_target):
        result = detect_relay_intent(text)
        if expected_target is None:
            # Either not detected or target filtered
            if result.detected:
                assert result.target == "" or result.target.lower() in ("him", "he")
        else:
            assert result.detected is True
            assert result.mode == "acknowledge"
            assert result.target == expected_target

    def test_content_extracted_tell_laina(self):
        result = detect_relay_intent("Tell Laina I said thanks for the tune-up")
        assert result.detected
        assert result.target == "Laina"
        assert "thanks" in result.content.lower() or "tune" in result.content.lower()

    def test_content_extracted_let_know(self):
        result = detect_relay_intent("Let Jason know I'm good with that")
        assert result.detected
        assert result.target == "Jason"

    def test_mode_is_acknowledge(self):
        result = detect_relay_intent("Tell Laina I said thanks")
        assert result.mode == "acknowledge"


# ---------------------------------------------------------------------------
# Mode B — compose / direct message
# ---------------------------------------------------------------------------

class TestModeB:
    """Expected direct-message compose cases."""

    @pytest.mark.parametrize("text,expected_target", [
        ("Write a message to Laina", "Laina"),
        ("Draft what I should send Chemist", "Chemist"),
        ("How should I reply to Jason?", "Jason"),
        ("What should I tell Sarah about the delay?", "Sarah"),
        ("Compose a reply to Marcus", "Marcus"),
        ("write a dm to Alex", "Alex"),
        ("Please draft a message to Jordan", "Jordan"),
        ("What should I say to Elena?", "Elena"),
    ])
    def test_compose_mode_detected(self, text, expected_target):
        result = detect_relay_intent(text)
        assert result.detected is True
        assert result.mode == "compose"
        assert result.target == expected_target

    def test_mode_b_takes_priority_over_mode_a(self):
        """If text matches both patterns, Mode B wins."""
        result = detect_relay_intent("Draft a message to tell Laina thanks")
        assert result.mode == "compose"
        assert result.target == "Laina"


# ---------------------------------------------------------------------------
# False-positive guard — should NOT trigger
# ---------------------------------------------------------------------------

class TestNoFalsePositives:
    """These should NOT trigger relay-intent detection."""

    @pytest.mark.parametrize("text", [
        "Tell me more about this",
        "Let me know when it's ready",
        "Let me think about that",
        "Can you tell me what time it is?",
        "Tell me how to do this",
        "I want to know more",
        "What do you think?",
        "How does this work?",
        "Let us begin",
        "Tell me everything",
    ])
    def test_no_false_positive(self, text):
        result = detect_relay_intent(text)
        # Either not detected, or if detected the target must not be a stop-word
        if result.detected:
            assert result.target not in ("Me", "You", "Them", "Us", "Everyone", "")

    def test_empty_string(self):
        result = detect_relay_intent("")
        assert result.detected is False
        assert result.mode == "none"

    def test_whitespace_only(self):
        result = detect_relay_intent("   ")
        assert result.detected is False


# ---------------------------------------------------------------------------
# RelayIntent dataclass defaults
# ---------------------------------------------------------------------------

class TestRelayIntentDefaults:
    def test_default_not_detected(self):
        r = RelayIntent()
        assert r.detected is False
        assert r.mode == "none"
        assert r.target == ""
        assert r.content == ""


# ---------------------------------------------------------------------------
# build_relay_context_block
# ---------------------------------------------------------------------------

class TestBuildRelayContextBlock:
    def test_mode_a_block_content(self):
        intent = RelayIntent(detected=True, mode="acknowledge", target="Laina", content="thanks for the tune-up")
        block = build_relay_context_block(intent)
        assert "Mode A" in block
        assert "Laina" in block
        assert "current speaker" in block.lower() or "addressed" in block.lower()
        assert "Do NOT" in block

    def test_mode_b_block_content(self):
        intent = RelayIntent(detected=True, mode="compose", target="Jason", content="")
        block = build_relay_context_block(intent)
        assert "Mode B" in block
        assert "Jason" in block
        assert "compose" in block.lower() or "draft" in block.lower()

    def test_no_block_for_undetected(self):
        intent = RelayIntent(detected=False)
        block = build_relay_context_block(intent)
        assert block == ""

    def test_mode_a_block_without_content(self):
        intent = RelayIntent(detected=True, mode="acknowledge", target="Chemist", content="")
        block = build_relay_context_block(intent)
        assert "Chemist" in block
        assert block  # not empty


# ---------------------------------------------------------------------------
# Pipeline integration — relay detector in system prompt
# ---------------------------------------------------------------------------

class TestPipelineRelayIntegration:
    """Verify relay detector is wired into the pipeline's system-prompt assembly."""

    def test_relay_frame_guard_present_when_no_intent(self):
        """When no relay intent, the static guard should still be in the system prompt."""
        import inspect
        from antaris_agent.core import pipeline as pipeline_mod
        src = inspect.getsource(pipeline_mod)
        assert "RELAY_FRAME_GUARD" in src

    def test_relay_intent_imported_in_pipeline(self):
        """relay_intent module must be imported by pipeline."""
        from antaris_agent.core import pipeline as pipeline_mod
        assert hasattr(pipeline_mod, "detect_relay_intent")
        assert hasattr(pipeline_mod, "build_relay_context_block")

    def test_relay_detector_called_in_pipeline(self):
        """Pipeline source should call detect_relay_intent."""
        import inspect
        from antaris_agent.core import pipeline as pipeline_mod
        src = inspect.getsource(pipeline_mod)
        assert "detect_relay_intent" in src
        assert "build_relay_context_block" in src
