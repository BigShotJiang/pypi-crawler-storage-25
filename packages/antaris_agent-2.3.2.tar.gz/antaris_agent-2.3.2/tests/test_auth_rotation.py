"""Tests for auth-profile auto-rotation system.

Covers:
  - AuthProfilesFile reading/writing
  - AuthMonitor profile-level tracking
  - AuthMonitor intra-provider rotation
  - AuthMonitor cross-provider failover
  - AuthMonitor expiry detection
  - Dispatcher integration with profile rotation
  - Notification events
  - Rotation log persistence
"""

import asyncio
import json
import time
import pytest
from pathlib import Path

from antaris_agent.extensions.auth_monitor import (
    AuthMonitor,
    AuthKeyStatus,
    AuthProfilesFile,
    ProfileStatus,
    RotationEvent,
)
from antaris_agent.llm.dispatcher import LLMDispatcher
from antaris_agent.llm.base import LLMProvider, LLMResponse, Message, ThinkingConfig


# ── Helpers ───────────────────────────────────────────────────────────────

def _make_auth_profiles(tmp_path: Path, profiles: dict = None, order: dict = None,
                         last_good: dict = None) -> Path:
    """Create a test auth-profiles.json."""
    data = {
        "version": 1,
        "profiles": profiles or {},
        "order": order or {},
        "lastGood": last_good or {},
        "usageStats": {},
    }
    path = tmp_path / "auth-profiles.json"
    path.write_text(json.dumps(data, indent=2))
    return path


class MockProvider(LLMProvider):
    """Mock LLM provider for testing dispatcher failover."""

    def __init__(self, api_key: str = "test-key", model: str = "test-model",
                 should_fail: bool = False, fail_error: str = ""):
        super().__init__(api_key=api_key, model=model)
        self.should_fail = should_fail
        self.fail_error = fail_error
        self.call_count = 0
        self.last_api_key = None

    async def complete(self, messages, system, model=None, max_tokens=4096,
                       temperature=0.7, tools=None, thinking=None):
        self.call_count += 1
        self.last_api_key = self.api_key
        if self.should_fail:
            raise RuntimeError(self.fail_error or "test error")
        return LLMResponse(
            content="test response",
            model=model or self.model,
            input_tokens=10,
            output_tokens=5,
            cost_usd=0.001,
        )

    def estimate_tokens(self, text: str) -> int:
        return max(1, len(text) // 4)


# ── AuthProfilesFile Tests ───────────────────────────────────────────────

def test_auth_profiles_file_load(tmp_path):
    path = _make_auth_profiles(tmp_path, profiles={
        "anthropic:key1": {"type": "token", "provider": "anthropic", "token": "sk-ant-key1-xxxxxxxxxxxx"},
        "anthropic:key2": {"type": "token", "provider": "anthropic", "token": "sk-ant-key2-yyyyyyyyyyyy"},
    }, order={"anthropic": ["anthropic:key1", "anthropic:key2"]})

    apf = AuthProfilesFile(str(path))
    profiles = apf.get_profiles_for_provider("anthropic")
    assert len(profiles) == 2
    assert profiles[0][0] == "anthropic:key1"
    assert profiles[1][0] == "anthropic:key2"


def test_auth_profiles_file_get_credential(tmp_path):
    path = _make_auth_profiles(tmp_path, profiles={
        "anthropic:key1": {"type": "token", "provider": "anthropic", "token": "sk-ant-key1-xxxxxxxxxxxxxxxxxxxx"},
    })

    apf = AuthProfilesFile(str(path))
    cred = apf.get_credential("anthropic:key1")
    assert cred == "sk-ant-key1-xxxxxxxxxxxxxxxxxxxx"


def test_auth_profiles_file_get_next_profile(tmp_path):
    path = _make_auth_profiles(tmp_path, profiles={
        "anthropic:key1": {"type": "token", "provider": "anthropic", "token": "sk-ant-key1-xxxxxxxxxxxxxxxxxxxx"},
        "anthropic:key2": {"type": "token", "provider": "anthropic", "token": "sk-ant-key2-yyyyyyyyyyyyyyyyyyyy"},
    }, order={"anthropic": ["anthropic:key1", "anthropic:key2"]})

    apf = AuthProfilesFile(str(path))

    # Excluding key1 should return key2
    result = apf.get_next_profile("anthropic", exclude="anthropic:key1")
    assert result is not None
    assert result[0] == "anthropic:key2"

    # Excluding key2 should return key1
    result = apf.get_next_profile("anthropic", exclude="anthropic:key2")
    assert result is not None
    assert result[0] == "anthropic:key1"


def test_auth_profiles_file_skip_expired(tmp_path):
    expired_ts = (time.time() - 3600) * 1000  # 1 hour ago, in ms
    path = _make_auth_profiles(tmp_path, profiles={
        "anthropic:key1": {"type": "token", "provider": "anthropic", "token": "sk-ant-key1-xxxxxxxxxxxxxxxxxxxx"},
        "anthropic:expired": {"type": "token", "provider": "anthropic", "token": "sk-ant-exp-xxxxxxxxxxxxxxxxxxxx", "expires": expired_ts},
    }, order={"anthropic": ["anthropic:expired", "anthropic:key1"]})

    apf = AuthProfilesFile(str(path))

    # Should skip expired and return key1
    result = apf.get_next_profile("anthropic", exclude=None)
    assert result is not None
    assert result[0] == "anthropic:key1"


def test_auth_profiles_file_set_last_good(tmp_path):
    path = _make_auth_profiles(tmp_path, profiles={
        "anthropic:key1": {"type": "token", "provider": "anthropic", "token": "sk-ant-key1-xxxxxxxxxxxxxxxxxxxx"},
    })

    apf = AuthProfilesFile(str(path))
    apf.set_last_good("anthropic", "anthropic:key1")

    # Reload and verify
    data = json.loads(path.read_text())
    assert data["lastGood"]["anthropic"] == "anthropic:key1"


def test_auth_profiles_file_record_usage(tmp_path):
    path = _make_auth_profiles(tmp_path, profiles={
        "anthropic:key1": {"type": "token", "provider": "anthropic", "token": "sk-ant-key1-xxxxxxxxxxxxxxxxxxxx"},
    })

    apf = AuthProfilesFile(str(path))
    apf.record_usage("anthropic:key1", success=True)

    data = json.loads(path.read_text())
    stats = data["usageStats"]["anthropic:key1"]
    assert stats["errorCount"] == 0
    assert stats["lastUsed"] > 0

    apf.record_usage("anthropic:key1", success=False, error_msg="rate limited")
    data = json.loads(path.read_text())
    stats = data["usageStats"]["anthropic:key1"]
    assert stats["errorCount"] == 1
    assert "lastError" in stats


def test_auth_profiles_file_no_alternatives(tmp_path):
    path = _make_auth_profiles(tmp_path, profiles={
        "anthropic:only": {"type": "token", "provider": "anthropic", "token": "sk-ant-only-xxxxxxxxxxxxxxxxxxxx"},
    })

    apf = AuthProfilesFile(str(path))
    result = apf.get_next_profile("anthropic", exclude="anthropic:only")
    assert result is None


# ── AuthMonitor Profile Tracking Tests ────────────────────────────────────

def test_auth_monitor_profile_tracking(tmp_path):
    monitor = AuthMonitor(config_dir=str(tmp_path))

    monitor.record_call("anthropic", success=True, profile_id="anthropic:key1")
    assert "anthropic:key1" in monitor._health.profiles
    ps = monitor._health.profiles["anthropic:key1"]
    assert ps.total_calls == 1
    assert ps.is_valid is True


def test_auth_monitor_profile_unhealthy(tmp_path):
    monitor = AuthMonitor(config_dir=str(tmp_path))
    events = []
    monitor.set_event_callback(lambda t, d: events.append((t, d)))

    for _ in range(3):
        monitor.record_call("anthropic", success=False, error="error",
                            profile_id="anthropic:key1")

    ps = monitor._health.profiles["anthropic:key1"]
    assert ps.is_valid is False
    assert ps.consecutive_errors == 3


def test_auth_monitor_auth_error(tmp_path):
    monitor = AuthMonitor(config_dir=str(tmp_path))
    events = []
    monitor.set_event_callback(lambda t, d: events.append((t, d)))

    monitor.record_call("anthropic", success=False, error="401 Unauthorized",
                        auth_error=True, profile_id="anthropic:key1")

    status = monitor._health.providers["anthropic"]
    assert status.is_auth_error is True
    assert status.is_valid is False
    assert any(e[0] == "auth.auth_error" for e in events)


def test_auth_monitor_intra_provider_rotation(tmp_path):
    path = _make_auth_profiles(tmp_path, profiles={
        "anthropic:key1": {"type": "token", "provider": "anthropic", "token": "sk-ant-key1-xxxxxxxxxxxxxxxxxxxx"},
        "anthropic:key2": {"type": "token", "provider": "anthropic", "token": "sk-ant-key2-yyyyyyyyyyyyyyyyyyyy"},
    }, order={"anthropic": ["anthropic:key1", "anthropic:key2"]})

    monitor = AuthMonitor(config_dir=str(tmp_path), auth_profiles_path=str(path))
    events = []
    notifications = []
    monitor.set_event_callback(lambda t, d: events.append((t, d)))
    monitor.set_notification_callback(lambda msg: notifications.append(msg))

    result = monitor.try_rotate_profile("anthropic", current_profile="anthropic:key1",
                                         reason="rate_limit")
    assert result is not None
    pid, cred = result
    assert pid == "anthropic:key2"
    assert cred == "sk-ant-key2-yyyyyyyyyyyyyyyyyyyy"

    # Check rotation was recorded
    assert monitor._health.rotation_count == 1
    assert any(e[0] == "auth.profile_rotated" for e in events)
    assert len(notifications) == 1
    assert "Profile Rotated" in notifications[0]

    # Check lastGood was updated
    data = json.loads(path.read_text())
    assert data["lastGood"]["anthropic"] == "anthropic:key2"


def test_auth_monitor_rotation_no_alternative(tmp_path):
    path = _make_auth_profiles(tmp_path, profiles={
        "anthropic:only": {"type": "token", "provider": "anthropic", "token": "sk-ant-only-xxxxxxxxxxxxxxxxxxxx"},
    })

    monitor = AuthMonitor(config_dir=str(tmp_path), auth_profiles_path=str(path))
    result = monitor.try_rotate_profile("anthropic", current_profile="anthropic:only",
                                         reason="rate_limit")
    assert result is None


def test_auth_monitor_cross_provider_failover(tmp_path):
    monitor = AuthMonitor(config_dir=str(tmp_path))

    # Set up two providers
    monitor.record_call("anthropic", success=True)
    monitor.record_call("openai", success=True)

    # Make anthropic unhealthy
    for _ in range(3):
        monitor.record_call("anthropic", success=False, error="error")

    fallback = monitor.should_failover("anthropic")
    assert fallback == "openai"


def test_auth_monitor_rotation_log_persistence(tmp_path):
    path = _make_auth_profiles(tmp_path, profiles={
        "anthropic:key1": {"type": "token", "provider": "anthropic", "token": "sk-ant-key1-xxxxxxxxxxxxxxxxxxxx"},
        "anthropic:key2": {"type": "token", "provider": "anthropic", "token": "sk-ant-key2-yyyyyyyyyyyyyyyyyyyy"},
    }, order={"anthropic": ["anthropic:key1", "anthropic:key2"]})

    monitor = AuthMonitor(config_dir=str(tmp_path), auth_profiles_path=str(path))
    monitor.try_rotate_profile("anthropic", current_profile="anthropic:key1", reason="test")

    # Verify rotation log is persisted
    state_file = tmp_path / "auth_monitor_state.json"
    assert state_file.exists()
    state = json.loads(state_file.read_text())
    assert len(state.get("rotation_log", [])) == 1
    assert state["rotation_log"][0]["reason"] == "test"


def test_auth_monitor_status_text_enhanced(tmp_path):
    path = _make_auth_profiles(tmp_path, profiles={
        "anthropic:key1": {"type": "token", "provider": "anthropic", "token": "sk-ant-key1-xxxxxxxxxxxxxxxxxxxx"},
        "anthropic:key2": {"type": "token", "provider": "anthropic", "token": "sk-ant-key2-yyyyyyyyyyyyyyyyyyyy"},
    }, order={"anthropic": ["anthropic:key1", "anthropic:key2"]})

    monitor = AuthMonitor(config_dir=str(tmp_path), auth_profiles_path=str(path))
    monitor.record_call("anthropic", success=True, profile_id="anthropic:key1")
    monitor.try_rotate_profile("anthropic", current_profile="anthropic:key1", reason="test")

    text = monitor.get_status_text()
    assert "Auth Status" in text
    assert "anthropic" in text
    assert "Recent Rotations" in text


# ── RotationEvent Tests ───────────────────────────────────────────────────

def test_rotation_event_notification():
    event = RotationEvent(
        timestamp=time.time(),
        from_profile="anthropic:key1",
        to_profile="anthropic:key2",
        provider="anthropic",
        reason="rate_limit",
    )
    msg = event.to_notification()
    assert "Profile Rotated" in msg
    assert "anthropic" in msg
    assert "rate_limit" in msg


def test_rotation_event_to_dict():
    ts = time.time()
    event = RotationEvent(
        timestamp=ts,
        from_profile="anthropic:key1",
        to_profile="anthropic:key2",
        provider="anthropic",
        reason="auth_error",
        detail="401 Unauthorized",
    )
    d = event.to_dict()
    assert d["from"] == "anthropic:key1"
    assert d["to"] == "anthropic:key2"
    assert d["reason"] == "auth_error"
    assert "time_str" in d


# ── Dispatcher Integration Tests ──────────────────────────────────────────

@pytest.mark.asyncio
async def test_dispatcher_profile_rotation_on_rate_limit(tmp_path):
    """Test that dispatcher rotates profiles within a provider on rate limit."""
    path = _make_auth_profiles(tmp_path, profiles={
        "anthropic:key1": {"type": "token", "provider": "anthropic", "token": "sk-ant-key1-xxxxxxxxxxxxxxxxxxxx"},
        "anthropic:key2": {"type": "token", "provider": "anthropic", "token": "sk-ant-key2-yyyyyyyyyyyyyyyyyyyy"},
    }, order={"anthropic": ["anthropic:key1", "anthropic:key2"]})

    monitor = AuthMonitor(config_dir=str(tmp_path), auth_profiles_path=str(path))

    # Create a provider that fails first, then succeeds with new key
    provider = MockProvider(api_key="sk-ant-key1-xxxxxxxxxxxxxxxxxxxx")
    call_count = [0]
    original_complete = provider.complete

    async def failing_then_success(messages, system, model=None, max_tokens=4096,
                                    temperature=0.7, tools=None, thinking=None):
        call_count[0] += 1
        if call_count[0] == 1:
            raise RuntimeError("rate_limit:30")
        return await LLMResponse(
            content="success after rotation",
            model=model or "test-model",
            input_tokens=10,
            output_tokens=5,
            cost_usd=0.001,
        ).__class__(
            content="success after rotation",
            model=model or "test-model",
            input_tokens=10,
            output_tokens=5,
            cost_usd=0.001,
        )
    
    # Simpler approach: make provider fail then succeed
    provider.should_fail = True
    provider.fail_error = "rate_limit:30"

    dispatcher = LLMDispatcher()
    dispatcher.register("anthropic", provider)
    dispatcher.set_auth_monitor(monitor)
    dispatcher.set_active_profile("anthropic", "anthropic:key1")

    # After the profile rotates, the provider will have a new key
    # and should succeed (mock will still fail, but let's test the rotation path)
    try:
        await dispatcher.complete(
            provider="anthropic",
            model="test-model",
            messages=[Message(role="user", content="test")],
            system="test",
        )
    except RuntimeError:
        pass  # Expected — both profiles fail because mock always fails

    # Verify rotation happened
    assert monitor._health.rotation_count >= 1
    # Verify the provider's api_key was updated
    assert provider.api_key == "sk-ant-key2-yyyyyyyyyyyyyyyyyyyy"


@pytest.mark.asyncio
async def test_dispatcher_auth_error_triggers_rotation(tmp_path):
    """Test that 401 auth errors trigger profile rotation."""
    path = _make_auth_profiles(tmp_path, profiles={
        "anthropic:key1": {"type": "token", "provider": "anthropic", "token": "sk-ant-key1-xxxxxxxxxxxxxxxxxxxx"},
        "anthropic:key2": {"type": "token", "provider": "anthropic", "token": "sk-ant-key2-yyyyyyyyyyyyyyyyyyyy"},
    }, order={"anthropic": ["anthropic:key1", "anthropic:key2"]})

    monitor = AuthMonitor(config_dir=str(tmp_path), auth_profiles_path=str(path))

    provider = MockProvider(should_fail=True, fail_error="Invalid Anthropic API key")

    dispatcher = LLMDispatcher()
    dispatcher.register("anthropic", provider)
    dispatcher.set_auth_monitor(monitor)
    dispatcher.set_active_profile("anthropic", "anthropic:key1")

    try:
        await dispatcher.complete(
            provider="anthropic",
            model="test-model",
            messages=[Message(role="user", content="test")],
            system="test",
        )
    except (RuntimeError, ValueError):
        pass

    # Auth error should trigger rotation
    assert monitor._health.rotation_count >= 1
    assert provider.api_key == "sk-ant-key2-yyyyyyyyyyyyyyyyyyyy"


@pytest.mark.asyncio
async def test_dispatcher_cross_provider_fallback(tmp_path):
    """Test cross-provider failover when no profile alternatives exist."""
    path = _make_auth_profiles(tmp_path, profiles={
        "anthropic:only": {"type": "token", "provider": "anthropic", "token": "sk-ant-only-xxxxxxxxxxxxxxxxxxxx"},
    })

    monitor = AuthMonitor(config_dir=str(tmp_path), auth_profiles_path=str(path))
    # Pre-register openai as healthy
    monitor.record_call("openai", success=True)

    anthropic_provider = MockProvider(should_fail=True, fail_error="rate_limit:30")
    openai_provider = MockProvider(should_fail=False)

    dispatcher = LLMDispatcher()
    dispatcher.register("anthropic", anthropic_provider)
    dispatcher.register("openai", openai_provider)
    dispatcher.set_auth_monitor(monitor)
    dispatcher.set_active_profile("anthropic", "anthropic:only")

    response = await dispatcher.complete(
        provider="anthropic",
        model="test-model",
        messages=[Message(role="user", content="test")],
        system="test",
    )

    # Should have fallen back to openai
    assert response.content == "test response"
    assert openai_provider.call_count == 1


@pytest.mark.asyncio
async def test_dispatcher_success_records_profile(tmp_path):
    """Test that successful calls record the active profile."""
    monitor = AuthMonitor(config_dir=str(tmp_path))
    provider = MockProvider()

    dispatcher = LLMDispatcher()
    dispatcher.register("anthropic", provider)
    dispatcher.set_auth_monitor(monitor)
    dispatcher.set_active_profile("anthropic", "anthropic:key1")

    await dispatcher.complete(
        provider="anthropic",
        model="test-model",
        messages=[Message(role="user", content="test")],
        system="test",
    )

    # Should have recorded success with profile ID
    assert "anthropic:key1" in monitor._health.profiles
    ps = monitor._health.profiles["anthropic:key1"]
    assert ps.total_calls == 1
    assert ps.is_valid is True


# ── Expiry Detection Tests ────────────────────────────────────────────────

def test_auth_monitor_expiry_detection(tmp_path):
    monitor = AuthMonitor(config_dir=str(tmp_path))
    events = []
    notifications = []
    monitor.set_event_callback(lambda t, d: events.append((t, d)))
    monitor.set_notification_callback(lambda msg: notifications.append(msg))

    # Set an expired credential
    monitor.check_expiry("anthropic", time.time() - 100)

    status = monitor._health.providers["anthropic"]
    assert status.is_valid is False
    assert any(e[0] == "auth.key_expired" for e in events)
    assert len(notifications) == 1


def test_auth_monitor_expiry_warning(tmp_path):
    monitor = AuthMonitor(config_dir=str(tmp_path))
    events = []
    monitor.set_event_callback(lambda t, d: events.append((t, d)))

    # Set a credential expiring in 30 minutes
    monitor.check_expiry("anthropic", time.time() + 1800)

    assert any(e[0] == "auth.key_expiring" for e in events)


def test_auth_profiles_expiry_in_ms(tmp_path):
    """Verify that auth-profiles.json expires field in milliseconds is handled."""
    future_ms = int((time.time() + 3600) * 1000)  # 1 hour from now, in ms
    path = _make_auth_profiles(tmp_path, profiles={
        "anthropic:oauth": {"type": "token", "provider": "anthropic",
                            "token": "sk-ant-xxxxxxxxxxxxxxxxxxxx",
                            "expires": future_ms},
    })

    apf = AuthProfilesFile(str(path))
    expires = apf.get_expires("anthropic:oauth")
    # Should be in seconds, roughly 1 hour from now
    assert expires > time.time()
    assert expires < time.time() + 7200


# ── State Persistence Tests ───────────────────────────────────────────────

def test_auth_monitor_state_roundtrip(tmp_path):
    """Test that auth monitor state survives save/load cycle."""
    monitor1 = AuthMonitor(config_dir=str(tmp_path))
    monitor1.record_call("anthropic", success=True, profile_id="anthropic:key1")
    monitor1.record_call("anthropic", success=False, error="test",
                          profile_id="anthropic:key1")
    monitor1._health.rotation_count = 5
    monitor1._health.rotation_log = [{"test": "entry"}]
    monitor1._save_state()

    # Load into new instance
    monitor2 = AuthMonitor(config_dir=str(tmp_path))
    assert monitor2._health.rotation_count == 5
    assert len(monitor2._health.rotation_log) == 1
    status = monitor2._health.providers.get("anthropic")
    assert status is not None
    assert status.total_calls == 2
    assert status.total_errors == 1


def test_auth_monitor_profile_state_roundtrip(tmp_path):
    """Test that profile-level state survives save/load."""
    monitor1 = AuthMonitor(config_dir=str(tmp_path))
    monitor1.record_call("anthropic", success=True, profile_id="anthropic:key1")
    monitor1.record_call("anthropic", success=False, error="err",
                          auth_error=True, profile_id="anthropic:key1")
    monitor1._save_state()

    monitor2 = AuthMonitor(config_dir=str(tmp_path))
    ps = monitor2._health.profiles.get("anthropic:key1")
    assert ps is not None
    assert ps.total_calls == 2
    assert ps.is_auth_error is True


# ── Rate Limit Reset Tests ───────────────────────────────────────────────

def test_auth_monitor_rate_limit_reset(tmp_path):
    monitor = AuthMonitor(config_dir=str(tmp_path))

    # Set rate limited with past reset time
    monitor.record_call("anthropic", success=False, rate_limited=True,
                        rate_limit_reset=time.time() - 10)

    # Check reset
    monitor._check_rate_limit_resets()

    status = monitor._health.providers["anthropic"]
    assert status.is_rate_limited is False


def test_auth_monitor_profile_rate_limit_reset(tmp_path):
    monitor = AuthMonitor(config_dir=str(tmp_path))

    monitor.record_call("anthropic", success=False, rate_limited=True,
                        rate_limit_reset=time.time() - 10,
                        profile_id="anthropic:key1")

    monitor._check_rate_limit_resets()

    ps = monitor._health.profiles["anthropic:key1"]
    assert ps.is_rate_limited is False
