"""
tests/test_user_identity.py — Phase 1: Per-User Identity Fix

Tests the core invariant: USER.md (owner's personal context) is only injected
for the owner.  Non-owner users get their per-user profile context instead,
and facts extracted from their messages route to profiles, not USER.md.

Covers:
  1. Owner gets USER.md in system prompt
  2. Non-owner does NOT get USER.md (gets identity boundary note)
  3. Missing owner_id falls back to old behavior (backwards compat)
  4. UserTracker only writes to USER.md for owner
  5. Non-owner facts route to profile notes
  6. _maybe_update_user_context gates on owner
  7. display_name captured in profile via touch()
"""
from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from antaris_agent.persona.loader import PersonaLoader
from antaris_agent.persona.user_tracker import UserTracker
from antaris_agent.core.profiles import ProfileManager, UserProfile


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
OWNER_ID = "owner_12345"
NON_OWNER_ID = "stranger_67890"

SAMPLE_USER_MD = """\
# About Laina

## Personal Facts
- Lives in San Francisco
- Works at SharkNinja
- Prefers dark mode
- Enjoys hiking on weekends

## Learned Facts
- Name: Laina *(learned 2026-03-20)*
- Occupation/role: product manager *(learned 2026-03-21)*
"""

SAMPLE_SOUL_MD = """\
You are TestBot — a helpful assistant.
Be direct and concise.
"""


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def config_dir(tmp_path: Path) -> Path:
    """Create a minimal config directory with SOUL.md, USER.md, and context.json."""
    d = tmp_path / "botconfig"
    d.mkdir()

    (d / "SOUL.md").write_text(SAMPLE_SOUL_MD)
    (d / "USER.md").write_text(SAMPLE_USER_MD)

    # Context cadence: SOUL.md every turn, USER.md handled separately
    (d / "context.json").write_text(json.dumps({"SOUL.md": "every"}))

    # Profiles dir
    (d / "profiles").mkdir()

    return d


@pytest.fixture
def persona(config_dir: Path) -> PersonaLoader:
    return PersonaLoader(config_dir=str(config_dir))


@pytest.fixture
def tracker(config_dir: Path) -> UserTracker:
    return UserTracker(config_dir=str(config_dir))


@pytest.fixture
def profiles(config_dir: Path) -> ProfileManager:
    return ProfileManager(profiles_dir=config_dir / "profiles")


# ═══════════════════════════════════════════════════════════════════════════
# Test 1: Owner gets USER.md context
# ═══════════════════════════════════════════════════════════════════════════

class TestOwnerGetsUserMd:
    """When user_id == owner_id, build_system_prompt must include USER.md content."""

    def test_owner_sees_user_md_content(self, persona: PersonaLoader):
        """USER.md content appears in system prompt for the owner."""
        prompt = persona.build_system_prompt(
            memories=None,
            user_id=OWNER_ID,
            owner_id=OWNER_ID,
        )
        # The owner should see the USER.md content
        assert "About Laina" in prompt or "Laina" in prompt
        assert "SharkNinja" in prompt
        assert "San Francisco" in prompt

    def test_owner_sees_about_section_header(self, persona: PersonaLoader):
        """The 'About the person I'm talking to' header is present for owner."""
        prompt = persona.build_system_prompt(
            memories=None,
            user_id=OWNER_ID,
            owner_id=OWNER_ID,
        )
        assert "About the person I'm talking to" in prompt

    def test_owner_with_memories(self, persona: PersonaLoader):
        """USER.md + memories both appear for the owner."""
        prompt = persona.build_system_prompt(
            memories=["User mentioned they like Python", "Previous chat about hiking"],
            user_id=OWNER_ID,
            owner_id=OWNER_ID,
        )
        assert "SharkNinja" in prompt  # USER.md content
        assert "Python" in prompt       # memory content


# ═══════════════════════════════════════════════════════════════════════════
# Test 2: Non-owner does NOT get USER.md
# ═══════════════════════════════════════════════════════════════════════════

class TestNonOwnerExcluded:
    """When user_id != owner_id, USER.md must NOT be injected and
    an identity boundary note should appear instead."""

    def test_non_owner_no_user_md_content(self, persona: PersonaLoader):
        """Non-owner should NOT see the owner's personal details."""
        prompt = persona.build_system_prompt(
            memories=None,
            user_id=NON_OWNER_ID,
            owner_id=OWNER_ID,
        )
        assert "SharkNinja" not in prompt
        assert "San Francisco" not in prompt

    def test_non_owner_no_about_section(self, persona: PersonaLoader):
        """The 'About the person I'm talking to' section should be absent for non-owner."""
        prompt = persona.build_system_prompt(
            memories=None,
            user_id=NON_OWNER_ID,
            owner_id=OWNER_ID,
        )
        assert "About the person I'm talking to" not in prompt

    def test_non_owner_gets_boundary_note(self, persona: PersonaLoader):
        """Non-owner should see an identity boundary note (mentioning owner vs current speaker)."""
        prompt = persona.build_system_prompt(
            memories=None,
            user_id=NON_OWNER_ID,
            owner_id=OWNER_ID,
        )
        # Should contain some form of identity boundary warning
        lower = prompt.lower()
        assert ("not your owner" in lower
                or "not the owner" in lower
                or "current speaker" in lower
                or "identity" in lower
                or "owner" in lower), \
            f"Expected identity boundary note in prompt, got: {prompt[-500:]}"

    def test_non_owner_soul_still_present(self, persona: PersonaLoader):
        """SOUL.md should still load for non-owner — only USER.md is gated."""
        prompt = persona.build_system_prompt(
            memories=None,
            user_id=NON_OWNER_ID,
            owner_id=OWNER_ID,
        )
        assert "TestBot" in prompt


# ═══════════════════════════════════════════════════════════════════════════
# Test 3: Missing owner_id falls back to old behavior
# ═══════════════════════════════════════════════════════════════════════════

class TestMissingOwnerFallback:
    """When owner_id is None or empty, USER.md should inject for everyone
    (backwards compatibility with existing deployments that haven't set owner_id)."""

    def test_owner_id_none_injects_user_md(self, persona: PersonaLoader):
        """owner_id=None → USER.md loads for any user (legacy behavior)."""
        prompt = persona.build_system_prompt(
            memories=None,
            user_id=NON_OWNER_ID,
            owner_id=None,
        )
        assert "SharkNinja" in prompt

    def test_owner_id_empty_string_injects_user_md(self, persona: PersonaLoader):
        """owner_id='' → USER.md loads for any user (legacy behavior)."""
        prompt = persona.build_system_prompt(
            memories=None,
            user_id=NON_OWNER_ID,
            owner_id="",
        )
        assert "SharkNinja" in prompt

    def test_both_none_injects_user_md(self, persona: PersonaLoader):
        """Both user_id and owner_id None → legacy path, USER.md injected."""
        prompt = persona.build_system_prompt(
            memories=None,
            user_id=None,
            owner_id=None,
        )
        assert "SharkNinja" in prompt

    def test_no_kwargs_at_all_injects_user_md(self, persona: PersonaLoader):
        """Calling with no user_id/owner_id kwargs → backwards compat, USER.md injected."""
        prompt = persona.build_system_prompt(memories=None)
        assert "SharkNinja" in prompt


# ═══════════════════════════════════════════════════════════════════════════
# Test 4: UserTracker only writes to USER.md for owner
# ═══════════════════════════════════════════════════════════════════════════

class TestUserTrackerOwnerGate:
    """UserTracker.process_message should only write to USER.md when the
    message comes from the owner."""

    def test_owner_facts_written_to_user_md(self, tracker: UserTracker, config_dir: Path):
        """Owner's facts get written to USER.md."""
        original = (config_dir / "USER.md").read_text()
        facts = tracker.process_message(
            "my name is Laina and I live in San Francisco",
            user_id=OWNER_ID,
            owner_id=OWNER_ID,
        )
        assert len(facts) > 0
        updated = (config_dir / "USER.md").read_text()
        # At least one new fact should appear in USER.md
        assert len(updated) >= len(original)

    def test_non_owner_facts_not_written_to_user_md(self, tracker: UserTracker, config_dir: Path):
        """Non-owner's facts must NOT modify USER.md."""
        original = (config_dir / "USER.md").read_text()
        facts = tracker.process_message(
            "my name is Jake and I work at Google",
            user_id=NON_OWNER_ID,
            owner_id=OWNER_ID,
        )
        # Facts should still be extracted (returned for profile routing)
        assert len(facts) > 0
        # But USER.md should be unchanged
        assert (config_dir / "USER.md").read_text() == original

    def test_non_owner_facts_returned_for_routing(self, tracker: UserTracker):
        """Even though USER.md is not written, extracted facts are returned
        so the caller can route them to profiles."""
        facts = tracker.process_message(
            "I live in New York and I'm a developer",
            user_id=NON_OWNER_ID,
            owner_id=OWNER_ID,
        )
        assert any("New York" in f for f in facts)


# ═══════════════════════════════════════════════════════════════════════════
# Test 5: Non-owner facts route to profiles
# ═══════════════════════════════════════════════════════════════════════════

class TestNonOwnerFactsRouteToProfiles:
    """Facts extracted from non-owner messages should be added to their
    per-user profile notes, not to USER.md."""

    def test_facts_added_to_profile_notes(
        self, tracker: UserTracker, profiles: ProfileManager, config_dir: Path
    ):
        """Extracted non-owner facts can be added to profile notes."""
        facts = tracker.process_message(
            "my name is Jake and I live in Portland",
            user_id=NON_OWNER_ID,
            owner_id=OWNER_ID,
        )
        # Simulate what the pipeline should do: route facts to profile
        for fact in facts:
            profiles.add_note(NON_OWNER_ID, fact)

        profile = profiles.get(NON_OWNER_ID)
        assert len(profile.notes) > 0
        note_text = " ".join(profile.notes)
        assert "Portland" in note_text or "Jake" in note_text

    def test_user_md_unchanged_after_profile_routing(
        self, tracker: UserTracker, profiles: ProfileManager, config_dir: Path
    ):
        """After routing to profiles, USER.md is still untouched."""
        original = (config_dir / "USER.md").read_text()
        facts = tracker.process_message(
            "I work at Netflix",
            user_id=NON_OWNER_ID,
            owner_id=OWNER_ID,
        )
        for fact in facts:
            profiles.add_note(NON_OWNER_ID, fact)

        assert (config_dir / "USER.md").read_text() == original

    def test_profile_persists_to_disk(
        self, tracker: UserTracker, profiles: ProfileManager, config_dir: Path
    ):
        """Profile notes are persisted to JSON on disk."""
        facts = tracker.process_message(
            "I prefer dark mode",
            user_id=NON_OWNER_ID,
            owner_id=OWNER_ID,
        )
        for fact in facts:
            profiles.add_note(NON_OWNER_ID, fact)

        # Reload from disk
        fresh_profiles = ProfileManager(profiles_dir=config_dir / "profiles")
        fresh_profile = fresh_profiles.get(NON_OWNER_ID)
        assert len(fresh_profile.notes) > 0


# ═══════════════════════════════════════════════════════════════════════════
# Test 6: _maybe_update_user_context gates on owner
# ═══════════════════════════════════════════════════════════════════════════

class TestMaybeUpdateUserContextGate:
    """Pipeline._maybe_update_user_context should only write to USER.md
    when the inbound message is from the owner."""

    @pytest.fixture
    def mock_pipeline(self, config_dir: Path):
        """Create a minimal Pipeline-like object with the relevant attributes."""
        from antaris_agent.channels.base import InboundMessage

        persona = PersonaLoader(config_dir=str(config_dir))

        # Build a thin mock that has the fields _maybe_update_user_context needs
        pipeline = MagicMock()
        pipeline.persona = persona
        pipeline.config = MagicMock()
        pipeline.config.owner_user_id = OWNER_ID

        # Bind the real method to our mock
        from antaris_agent.core.pipeline import Pipeline
        pipeline._maybe_update_user_context = Pipeline._maybe_update_user_context.__get__(
            pipeline, Pipeline
        )

        return pipeline

    @pytest.mark.asyncio
    async def test_owner_trigger_writes_user_md(self, mock_pipeline, config_dir: Path):
        """Owner saying 'my name is Laina' triggers USER.md update."""
        from antaris_agent.channels.base import InboundMessage

        inbound = InboundMessage(
            id="msg1",
            user_id=OWNER_ID,
            user_name="Laina",
            channel_id="ch1",
            platform="test",
            text="My name is Laina and I live in Oakland",
        )
        original = (config_dir / "USER.md").read_text()
        await mock_pipeline._maybe_update_user_context(inbound, "Nice to meet you!")
        updated = (config_dir / "USER.md").read_text()
        # For owner, USER.md should be updated (or at least attempted)
        # The fact "My name is Laina and I live in Oakland" should be appended
        assert len(updated) >= len(original)

    @pytest.mark.asyncio
    async def test_non_owner_trigger_does_not_write_user_md(self, mock_pipeline, config_dir: Path):
        """Non-owner saying 'I live in Portland' must NOT modify USER.md."""
        from antaris_agent.channels.base import InboundMessage

        inbound = InboundMessage(
            id="msg2",
            user_id=NON_OWNER_ID,
            user_name="Jake",
            channel_id="ch1",
            platform="test",
            text="I live in Portland and my job is engineering",
        )
        original = (config_dir / "USER.md").read_text()
        await mock_pipeline._maybe_update_user_context(inbound, "Cool!")
        assert (config_dir / "USER.md").read_text() == original

    @pytest.mark.asyncio
    async def test_non_owner_personal_triggers_blocked(self, mock_pipeline, config_dir: Path):
        """All personal trigger phrases from non-owner are blocked."""
        from antaris_agent.channels.base import InboundMessage

        triggers = [
            "my name is Jake",
            "I work at Google",
            "I'm a developer",
            "I live in New York",
            "I love pizza",
            "my favorite color is blue",
        ]
        original = (config_dir / "USER.md").read_text()
        for text in triggers:
            inbound = InboundMessage(
                id="msg_trigger",
                user_id=NON_OWNER_ID,
                user_name="Jake",
                channel_id="ch1",
                platform="test",
                text=text,
            )
            await mock_pipeline._maybe_update_user_context(inbound, "Noted!")

        # None of these should have modified USER.md
        assert (config_dir / "USER.md").read_text() == original


# ═══════════════════════════════════════════════════════════════════════════
# Test 7: display_name captured in profile
# ═══════════════════════════════════════════════════════════════════════════

class TestDisplayNameInProfile:
    """ProfileManager.touch() (or update_name) should capture the display_name
    from message metadata."""

    def test_touch_with_display_name(self, profiles: ProfileManager):
        """touch() with display_name updates the profile."""
        # First touch creates the profile
        profile = profiles.touch(NON_OWNER_ID)
        assert profile.message_count == 1
        assert profile.display_name == ""  # not set yet

        # Update display name
        profiles.update_name(NON_OWNER_ID, "Jake Stanier")
        profile = profiles.get(NON_OWNER_ID)
        assert profile.display_name == "Jake Stanier"

    def test_display_name_persists(self, profiles: ProfileManager, config_dir: Path):
        """display_name survives reload from disk."""
        profiles.update_name(NON_OWNER_ID, "Jake S.")
        profiles.touch(NON_OWNER_ID)

        # Reload from disk
        fresh = ProfileManager(profiles_dir=config_dir / "profiles")
        profile = fresh.get(NON_OWNER_ID)
        assert profile.display_name == "Jake S."

    def test_display_name_in_context_string(self, profiles: ProfileManager):
        """Profile context string includes display_name when set."""
        profiles.update_name(NON_OWNER_ID, "Jake")
        ctx = profiles.get_context(NON_OWNER_ID)
        assert ctx is not None
        assert "Jake" in ctx

    def test_touch_increments_message_count(self, profiles: ProfileManager):
        """Each touch() increments message_count."""
        profiles.touch(NON_OWNER_ID)
        profiles.touch(NON_OWNER_ID)
        profiles.touch(NON_OWNER_ID)
        profile = profiles.get(NON_OWNER_ID)
        assert profile.message_count == 3

    def test_multiple_users_independent(self, profiles: ProfileManager):
        """Profiles for different users are independent."""
        profiles.update_name(OWNER_ID, "Laina")
        profiles.update_name(NON_OWNER_ID, "Jake")
        profiles.touch(OWNER_ID)
        profiles.touch(NON_OWNER_ID)
        profiles.touch(NON_OWNER_ID)

        owner_profile = profiles.get(OWNER_ID)
        stranger_profile = profiles.get(NON_OWNER_ID)

        assert owner_profile.display_name == "Laina"
        assert stranger_profile.display_name == "Jake"
        assert owner_profile.message_count == 1
        assert stranger_profile.message_count == 2


# ═══════════════════════════════════════════════════════════════════════════
# Edge cases and integration
# ═══════════════════════════════════════════════════════════════════════════

class TestEdgeCases:
    """Additional edge cases for robustness."""

    def test_user_md_missing_still_works(self, tmp_path: Path):
        """If USER.md doesn't exist, build_system_prompt works without error."""
        d = tmp_path / "empty_config"
        d.mkdir()
        (d / "SOUL.md").write_text(SAMPLE_SOUL_MD)
        (d / "context.json").write_text(json.dumps({"SOUL.md": "every"}))

        persona = PersonaLoader(config_dir=str(d))
        prompt = persona.build_system_prompt(
            memories=None,
            user_id=NON_OWNER_ID,
            owner_id=OWNER_ID,
        )
        # Should work fine, just no user context
        assert "TestBot" in prompt
        assert "SharkNinja" not in prompt

    def test_user_md_too_short_not_injected(self, tmp_path: Path):
        """USER.md with <50 chars (placeholder) is not injected even for owner."""
        d = tmp_path / "short_config"
        d.mkdir()
        (d / "SOUL.md").write_text(SAMPLE_SOUL_MD)
        (d / "USER.md").write_text("# About You\n\nTell me.")
        (d / "context.json").write_text(json.dumps({"SOUL.md": "every"}))

        persona = PersonaLoader(config_dir=str(d))
        prompt = persona.build_system_prompt(
            memories=None,
            user_id=OWNER_ID,
            owner_id=OWNER_ID,
        )
        assert "Tell me" not in prompt  # too short, should be filtered by load_user()

    def test_same_user_as_owner_and_non_owner(self, persona: PersonaLoader):
        """Verify prompt changes based on owner_id, not user_id alone."""
        prompt_as_owner = persona.build_system_prompt(
            memories=None, user_id=OWNER_ID, owner_id=OWNER_ID
        )
        prompt_as_stranger = persona.build_system_prompt(
            memories=None, user_id=OWNER_ID, owner_id="someone_else"
        )
        # As owner: USER.md content present
        assert "SharkNinja" in prompt_as_owner
        # As non-owner of a different bot: USER.md content absent
        assert "SharkNinja" not in prompt_as_stranger

    def test_extract_facts_independent_of_identity(self, tracker: UserTracker):
        """extract_facts() itself doesn't care about identity — it's pure text matching."""
        facts = tracker.extract_facts("my name is Jake and I live in Portland")
        assert len(facts) > 0
        # Facts are extracted regardless — it's process_message that gates writing
