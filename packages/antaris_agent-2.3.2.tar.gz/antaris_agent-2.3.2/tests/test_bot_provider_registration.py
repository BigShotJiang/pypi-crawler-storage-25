from contextlib import ExitStack
from unittest.mock import MagicMock, patch

from antaris_agent.core.bot import Bot
from antaris_agent.core.config import Config


class RecordingDispatcher:
    def __init__(self):
        self.registered = []

    def register(self, name, provider):
        self.registered.append((name, provider))


def _base_config() -> Config:
    cfg = Config()
    cfg.config_path = "/tmp/test-config/config.json"
    cfg.api_key = "sk-primary"
    cfg.provider_name = "anthropic"
    cfg.model = "claude-sonnet-4-6"
    cfg.fallback_model = "claude-haiku-4-5-20251001"
    cfg.ollama_base_url = "http://localhost:11434/v1"
    cfg.validate = MagicMock(return_value=[])
    return cfg


def test_bot_registers_extra_provider_with_provider_specific_defaults():
    cfg = _base_config()
    cfg.openai_api_key = "sk-openai"
    cfg.google_api_key = "AIza-test"

    bot = Bot.__new__(Bot)
    bot.config = cfg
    bot.dispatcher = RecordingDispatcher()
    bot.llm = MagicMock(name="primary")
    bot.dispatcher.register(cfg.provider_name, bot.llm)

    created = {}

    def fake_import_module(name):
        module = MagicMock()
        class Provider:
            def __init__(self, **kwargs):
                created[name] = kwargs
                self.kwargs = kwargs
        mapping = {
            "antaris_agent.llm.openai": "OpenAIProvider",
            "antaris_agent.llm.google": "GoogleProvider",
            "antaris_agent.llm.ollama": "OllamaProvider",
            "antaris_agent.llm.anthropic": "AnthropicProvider",
        }
        setattr(module, mapping[name], Provider)
        return module

    extra_providers = {
        "anthropic": ("antaris_agent.llm.anthropic", "AnthropicProvider"),
        "openai": ("antaris_agent.llm.openai", "OpenAIProvider"),
        "google": ("antaris_agent.llm.google", "GoogleProvider"),
        "ollama": ("antaris_agent.llm.ollama", "OllamaProvider"),
    }

    with patch("importlib.import_module", side_effect=fake_import_module):
        for _pname, (_mod, _cls) in extra_providers.items():
            if _pname == bot.config.provider_name:
                continue
            _m = fake_import_module(_mod)
            _provider_cls = getattr(_m, _cls)
            if _pname == "ollama":
                _base_url = getattr(bot.config, "ollama_base_url", "http://localhost:11434/v1")
                _extra_llm = _provider_cls(base_url=_base_url)
                bot.dispatcher.register(_pname, _extra_llm)
            else:
                _key = getattr(bot.config, f"{_pname}_api_key", None)
                if _key:
                    _provider_model_defaults = {
                        "anthropic": getattr(bot.config, "fallback_model", None) or "claude-sonnet-4-6",
                        "openai": "gpt-5.4",
                        "google": "gemini-2.0-flash",
                    }
                    _provider_model = _provider_model_defaults.get(_pname, bot.config.model)
                    _extra_llm = _provider_cls(api_key=_key, model=_provider_model)
                    bot.dispatcher.register(_pname, _extra_llm)

    assert [name for name, _ in bot.dispatcher.registered] == ["anthropic", "openai", "google", "ollama"]
    assert created["antaris_agent.llm.openai"] == {"api_key": "sk-openai", "model": "gpt-5.4"}
    assert created["antaris_agent.llm.google"] == {"api_key": "AIza-test", "model": "gemini-2.0-flash"}
    assert created["antaris_agent.llm.ollama"] == {"base_url": "http://localhost:11434/v1"}
