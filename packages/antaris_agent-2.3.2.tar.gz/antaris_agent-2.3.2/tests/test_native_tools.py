from __future__ import annotations

import asyncio
import json
import tempfile
from pathlib import Path
from unittest.mock import AsyncMock, Mock, patch

import pytest

from antaris_agent.tools.native import (
    BrowserTool,
    FileOpsTool,
    NativeTool,
    ShellTool,
    ToolResult,
    VideoTool,
    WebFetchTool,
    WebSearchTool,
)


class TestToolResult:
    """Test ToolResult dataclass."""
    
    def test_tool_result_success(self):
        result = ToolResult(success=True, content="test content")
        assert result.success is True
        assert result.content == "test content"
        assert result.error is None
        assert result.is_error is False

    def test_tool_result_error(self):
        result = ToolResult(
            success=False, 
            content="", 
            error="test error", 
            is_error=True
        )
        assert result.success is False
        assert result.content == ""
        assert result.error == "test error"
        assert result.is_error is True


class TestWebSearchTool:
    """Test WebSearchTool."""
    
    def test_tool_properties(self):
        tool = WebSearchTool(api_key="test-key")
        assert tool.name == "web_search"
        assert tool.description == "Search the web using Brave Search API"
        assert isinstance(tool.input_schema, dict)
        assert "query" in tool.input_schema["properties"]
        assert "count" in tool.input_schema["properties"]

    def test_schema_validation(self):
        tool = WebSearchTool(api_key="test-key")
        schema = tool.input_schema
        
        # Check schema structure
        assert schema["type"] == "object"
        assert "properties" in schema
        assert "required" in schema
        assert "query" in schema["required"]
        
        # Check query property
        query_prop = schema["properties"]["query"]
        assert query_prop["type"] == "string"
        
        # Check count property
        count_prop = schema["properties"]["count"]
        assert count_prop["type"] == "integer"
        assert count_prop["minimum"] == 1
        assert count_prop["maximum"] == 10

    @pytest.mark.asyncio
    async def test_missing_api_key(self):
        tool = WebSearchTool(api_key="")
        result = await tool.execute({"query": "test"})
        assert result.success is False
        assert result.is_error is True
        assert "Missing API key" in result.error

    @pytest.mark.asyncio
    async def test_missing_query(self):
        tool = WebSearchTool(api_key="test-key")
        result = await tool.execute({})
        assert result.success is False
        assert result.is_error is True
        assert "Missing required parameter: query" in result.error

    @pytest.mark.asyncio
    @patch('antaris_agent.tools.native.web_search.httpx.AsyncClient')
    async def test_successful_search(self, mock_client_class):
        mock_client = AsyncMock()
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "web": {
                "results": [
                    {
                        "title": "Test Result 1",
                        "url": "https://example.com/1",
                        "description": "Test description 1"
                    },
                    {
                        "title": "Test Result 2", 
                        "url": "https://example.com/2",
                        "description": "Test description 2"
                    }
                ]
            }
        }
        mock_client.get.return_value = mock_response
        mock_client_class.return_value.__aenter__.return_value = mock_client

        tool = WebSearchTool(api_key="test-key")
        result = await tool.execute({"query": "test search", "count": 2})

        assert result.success is True
        assert "Test Result 1" in result.content
        assert "Test Result 2" in result.content
        assert "https://example.com/1" in result.content
        assert "https://example.com/2" in result.content

    @pytest.mark.asyncio
    @patch('antaris_agent.tools.native.web_search.httpx.AsyncClient')
    async def test_empty_results(self, mock_client_class):
        mock_client = AsyncMock()
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"web": {"results": []}}
        mock_client.get.return_value = mock_response
        mock_client_class.return_value.__aenter__.return_value = mock_client

        tool = WebSearchTool(api_key="test-key")
        result = await tool.execute({"query": "test"})

        assert result.success is True
        assert "No search results found" in result.content

    @pytest.mark.asyncio
    @patch('antaris_agent.tools.native.web_search.httpx.AsyncClient')
    async def test_http_error(self, mock_client_class):
        mock_client = AsyncMock()
        mock_response = Mock()
        mock_response.status_code = 401
        mock_response.text = "Unauthorized"
        mock_client.get.return_value = mock_response
        mock_client_class.return_value.__aenter__.return_value = mock_client

        tool = WebSearchTool(api_key="test-key")
        result = await tool.execute({"query": "test"})

        assert result.success is False
        assert result.is_error is True
        assert "401" in result.error


class TestWebFetchTool:
    """Test WebFetchTool."""

    def test_tool_properties(self):
        tool = WebFetchTool()
        assert tool.name == "web_fetch"
        assert tool.description == "Fetch and extract readable content from a URL"
        assert isinstance(tool.input_schema, dict)
        assert "url" in tool.input_schema["properties"]
        assert "extract_mode" in tool.input_schema["properties"]

    @pytest.mark.asyncio
    async def test_missing_url(self):
        tool = WebFetchTool()
        result = await tool.execute({})
        assert result.success is False
        assert result.is_error is True
        assert "Missing required parameter: url" in result.error

    @pytest.mark.asyncio
    async def test_invalid_url(self):
        tool = WebFetchTool()
        result = await tool.execute({"url": "not-a-url"})
        assert result.success is False
        assert result.is_error is True
        assert "Unsupported URL scheme" in result.error

    @pytest.mark.asyncio
    @patch('antaris_agent.tools.native.web_fetch.httpx.AsyncClient')
    async def test_successful_html_fetch_markdown(self, mock_client_class):
        mock_client = AsyncMock()
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.headers = {"content-type": "text/html"}
        mock_response.text = "<html><head><title>Test</title></head><body><h1>Header</h1><p>Paragraph</p></body></html>"
        mock_client.get.return_value = mock_response
        mock_client_class.return_value.__aenter__.return_value = mock_client

        tool = WebFetchTool()
        result = await tool.execute({"url": "https://example.com", "extract_mode": "markdown"})

        assert result.success is True
        assert "# Header" in result.content
        assert "Paragraph" in result.content

    @pytest.mark.asyncio
    @patch('antaris_agent.tools.native.web_fetch.httpx.AsyncClient')
    async def test_successful_html_fetch_text(self, mock_client_class):
        mock_client = AsyncMock()
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.headers = {"content-type": "text/html"}
        mock_response.text = "<html><body><h1>Header</h1><p>Paragraph</p></body></html>"
        mock_client.get.return_value = mock_response
        mock_client_class.return_value.__aenter__.return_value = mock_client

        tool = WebFetchTool()
        result = await tool.execute({"url": "https://example.com", "extract_mode": "text"})

        assert result.success is True
        assert "Header" in result.content
        assert "Paragraph" in result.content
        assert "#" not in result.content  # No markdown formatting

    @pytest.mark.asyncio
    @patch('antaris_agent.tools.native.web_fetch.httpx.AsyncClient')
    async def test_plain_text_content(self, mock_client_class):
        mock_client = AsyncMock()
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.headers = {"content-type": "text/plain"}
        mock_response.text = "Plain text content"
        mock_client.get.return_value = mock_response
        mock_client_class.return_value.__aenter__.return_value = mock_client

        tool = WebFetchTool()
        result = await tool.execute({"url": "https://example.com"})

        assert result.success is True
        assert result.content == "Plain text content"

    @pytest.mark.asyncio
    @patch('antaris_agent.tools.native.web_fetch.httpx.AsyncClient')
    async def test_content_truncation(self, mock_client_class):
        mock_client = AsyncMock()
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.headers = {"content-type": "text/html"}
        # Create content longer than max_chars
        long_content = "<html><body><p>" + "x" * 60000 + "</p></body></html>"
        mock_response.text = long_content
        mock_client.get.return_value = mock_response
        mock_client_class.return_value.__aenter__.return_value = mock_client

        tool = WebFetchTool(max_chars=1000)
        result = await tool.execute({"url": "https://example.com"})

        assert result.success is True
        assert "[Content truncated...]" in result.content
        assert len(result.content) <= 1000 + 100  # Some buffer for truncation message

    @pytest.mark.asyncio
    async def test_ssrf_blocking_file_scheme(self):
        tool = WebFetchTool()
        result = await tool.execute({"url": "file:///etc/passwd"})
        assert result.success is False
        assert result.is_error is True
        assert "Unsupported URL scheme: file" in result.error

    @pytest.mark.asyncio
    async def test_ssrf_blocking_localhost(self):
        tool = WebFetchTool()
        result = await tool.execute({"url": "http://localhost:8080"})
        assert result.success is False
        assert result.is_error is True
        assert "Access to localhost/loopback addresses is blocked" in result.error

    @pytest.mark.asyncio
    async def test_ssrf_blocking_loopback_ip(self):
        tool = WebFetchTool()
        result = await tool.execute({"url": "http://127.0.0.1:8080"})
        assert result.success is False
        assert result.is_error is True
        assert "Access to localhost/loopback addresses is blocked" in result.error

    @pytest.mark.asyncio
    async def test_ssrf_blocking_private_ip(self):
        tool = WebFetchTool()
        result = await tool.execute({"url": "http://192.168.1.1"})
        assert result.success is False
        assert result.is_error is True
        assert "Access to private/reserved IP 192.168.1.1 is blocked" in result.error

    @pytest.mark.asyncio
    async def test_ssrf_blocking_metadata_endpoint(self):
        tool = WebFetchTool()
        result = await tool.execute({"url": "http://169.254.169.254/metadata"})
        assert result.success is False
        assert result.is_error is True
        # This should be blocked as a private/reserved IP address
        assert "Access to private/reserved IP 169.254.169.254 is blocked" in result.error

    @pytest.mark.asyncio
    async def test_ssrf_blocking_metadata_google(self):
        tool = WebFetchTool()
        result = await tool.execute({"url": "http://metadata.google.internal"})
        assert result.success is False
        assert result.is_error is True
        assert "Access to cloud metadata endpoints is blocked" in result.error

    @pytest.mark.asyncio
    async def test_ssrf_redirect_blocked(self):
        """Test that redirects to private IPs are blocked."""
        import httpx
        
        tool = WebFetchTool()
        # Test that the _check_redirect method rejects private IPs
        # Create a mock response with redirect to private IP
        mock_request = httpx.Request("GET", "https://evil.com/redirect")
        mock_response = httpx.Response(
            302,
            headers={"location": "http://169.254.169.254/latest/meta-data/"},
            request=mock_request,
        )
        mock_response._is_redirect = True
        
        with pytest.raises(httpx.TooManyRedirects, match="SSRF protection"):
            await tool._check_redirect(mock_response)


class TestFileOpsTool:
    """Test FileOpsTool."""

    def test_tool_properties(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            tool = FileOpsTool(workspace_path=temp_dir)
            assert tool.name == "file_ops"
            assert tool.description == "File operations: read, write, edit, list files"
            assert isinstance(tool.input_schema, dict)
            assert "operation" in tool.input_schema["properties"]
            assert "path" in tool.input_schema["properties"]

    @pytest.mark.asyncio
    async def test_path_traversal_protection(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            tool = FileOpsTool(workspace_path=temp_dir)
            result = await tool.execute({"operation": "read", "path": "../../etc/passwd"})
            assert result.success is False
            assert result.is_error is True
            assert "Path traversal attempt" in result.error

    @pytest.mark.asyncio
    async def test_write_and_read_file(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            tool = FileOpsTool(workspace_path=temp_dir)
            
            # Write file
            content = "Hello, World!"
            result = await tool.execute({
                "operation": "write",
                "path": "test.txt",
                "content": content
            })
            assert result.success is True
            
            # Read file back
            result = await tool.execute({
                "operation": "read", 
                "path": "test.txt"
            })
            assert result.success is True
            assert result.content == content

    @pytest.mark.asyncio
    async def test_edit_file(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            tool = FileOpsTool(workspace_path=temp_dir)
            
            # Create initial file
            await tool.execute({
                "operation": "write",
                "path": "test.txt",
                "content": "Hello, World!"
            })
            
            # Edit file
            result = await tool.execute({
                "operation": "edit",
                "path": "test.txt",
                "old_text": "World",
                "new_text": "Python"
            })
            assert result.success is True
            
            # Verify edit
            result = await tool.execute({
                "operation": "read",
                "path": "test.txt"
            })
            assert result.success is True
            assert result.content == "Hello, Python!"

    @pytest.mark.asyncio
    async def test_edit_file_text_not_found(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            tool = FileOpsTool(workspace_path=temp_dir)
            
            # Create initial file
            await tool.execute({
                "operation": "write",
                "path": "test.txt", 
                "content": "Hello, World!"
            })
            
            # Try to edit non-existent text
            result = await tool.execute({
                "operation": "edit",
                "path": "test.txt",
                "old_text": "NotFound",
                "new_text": "Replacement"
            })
            assert result.success is False
            assert result.is_error is True
            assert "Text to replace not found" in result.error

    @pytest.mark.asyncio
    async def test_list_directory(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            tool = FileOpsTool(workspace_path=temp_dir)
            
            # Create some files
            await tool.execute({
                "operation": "write",
                "path": "file1.txt",
                "content": "content1"
            })
            await tool.execute({
                "operation": "write",
                "path": "subdir/file2.txt", 
                "content": "content2"
            })
            
            # List directory
            result = await tool.execute({
                "operation": "list",
                "path": "."
            })
            assert result.success is True
            assert "file1.txt" in result.content
            assert "subdir/file2.txt" in result.content

    @pytest.mark.asyncio
    async def test_read_nonexistent_file(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            tool = FileOpsTool(workspace_path=temp_dir)
            result = await tool.execute({
                "operation": "read",
                "path": "nonexistent.txt"
            })
            assert result.success is False
            assert result.is_error is True
            assert "File not found" in result.error


class TestShellTool:
    """Test ShellTool."""

    def test_tool_properties(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            tool = ShellTool(workspace_path=temp_dir)
            assert tool.name == "shell"
            assert tool.description == "Execute shell commands"
            assert isinstance(tool.input_schema, dict)
            assert "command" in tool.input_schema["properties"]

    @pytest.mark.asyncio
    async def test_missing_command(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            tool = ShellTool(workspace_path=temp_dir)
            result = await tool.execute({})
            assert result.success is False
            assert result.is_error is True
            assert "Missing required parameter: command" in result.error

    @pytest.mark.asyncio
    async def test_simple_command(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            tool = ShellTool(workspace_path=temp_dir)
            result = await tool.execute({"command": "echo 'Hello, World!'"})
            assert result.success is True
            assert "Hello, World!" in result.content
            assert "Exit code: 0" in result.content

    @pytest.mark.asyncio
    async def test_command_with_workdir(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            tool = ShellTool(workspace_path=temp_dir)
            
            # Create subdirectory
            subdir = Path(temp_dir) / "subdir"
            subdir.mkdir()
            
            # Run command in subdirectory
            result = await tool.execute({
                "command": "pwd",
                "workdir": "subdir"
            })
            assert result.success is True
            assert str(subdir) in result.content

    @pytest.mark.asyncio
    async def test_failed_command(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            tool = ShellTool(workspace_path=temp_dir)
            result = await tool.execute({"command": "exit 1"})
            assert result.success is False
            assert result.is_error is True
            assert "Exit code: 1" in result.content

    @pytest.mark.asyncio
    async def test_workdir_outside_workspace(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            tool = ShellTool(workspace_path=temp_dir)
            result = await tool.execute({
                "command": "echo test",
                "workdir": "../../etc"
            })
            assert result.success is False
            assert result.is_error is True
            assert "outside workspace" in result.error

    @pytest.mark.asyncio
    async def test_shell_invalid_timeout_falls_back_to_default(self):
        """Non-integer timeout should fall back to default_timeout."""
        with tempfile.TemporaryDirectory() as temp_dir:
            tool = ShellTool(workspace_path=temp_dir, timeout=30)
            result = await tool.execute({
                "command": "echo ok",
                "timeout": "not-a-number"
            })
            assert result.success is True
            assert "ok" in result.content


class TestVideoTool:
    """Test VideoTool."""

    def test_tool_properties(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            dispatcher = Mock()
            dispatcher.providers = {}
            tool = VideoTool(dispatcher=dispatcher, workspace_path=temp_dir)
            assert tool.name == "video"
            assert "video" in tool.description.lower()
            assert "action" in tool.input_schema["properties"]
            assert "path" in tool.input_schema["properties"]

    @pytest.mark.asyncio
    async def test_missing_action_or_path(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            dispatcher = Mock()
            dispatcher.providers = {}
            tool = VideoTool(dispatcher=dispatcher, workspace_path=temp_dir)
            result = await tool.execute({"action": "inspect"})
            assert result.success is False
            assert result.is_error is True
            assert "action and path" in result.error

    @pytest.mark.asyncio
    async def test_inspect_missing_file(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            dispatcher = Mock()
            dispatcher.providers = {}
            tool = VideoTool(dispatcher=dispatcher, workspace_path=temp_dir)
            result = await tool.execute({"action": "inspect", "path": "missing.mp4"})
            assert result.success is False
            assert result.is_error is True
            assert "Media file not found" in result.error

    @pytest.mark.asyncio
    async def test_transcribe_requires_whisper(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            media = Path(temp_dir) / "clip.mp4"
            media.write_text("fake")
            dispatcher = Mock()
            dispatcher.providers = {}
            tool = VideoTool(dispatcher=dispatcher, workspace_path=temp_dir)
            with patch('antaris_agent.tools.native.video.shutil.which', side_effect=lambda name: None if name == 'whisper' else '/usr/bin/' + name):
                result = await tool.execute({"action": "transcribe", "path": str(media)})
            assert result.success is False
            assert result.is_error is True
            assert "whisper CLI is required" in result.error

    @pytest.mark.asyncio
    async def test_sample_frames_writes_index(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            media = Path(temp_dir) / "clip.mp4"
            media.write_text("fake")
            dispatcher = Mock()
            dispatcher.providers = {}
            tool = VideoTool(dispatcher=dispatcher, workspace_path=temp_dir)

            async def fake_run(cmd, timeout=None):
                class Result:
                    returncode = 0
                    output = "12.0"
                if cmd[0].endswith('ffmpeg') and cmd[-1].endswith('.jpg'):
                    Path(cmd[-1]).write_bytes(b'jpg')
                    Result.output = ""
                return Result()

            with patch.object(tool, '_run', side_effect=fake_run):
                result = await tool.execute({
                    "action": "sample_frames",
                    "path": str(media),
                    "max_frames": 3,
                })

            assert result.success is True
            assert "Sampled 3 frame(s)" in result.content
            index_path = Path(temp_dir) / '.antaris_video' / 'clip' / 'frames.json'
            assert index_path.exists()
            payload = json.loads(index_path.read_text())
            assert len(payload) == 3

    @pytest.mark.asyncio
    async def test_qa_requires_question(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            media = Path(temp_dir) / "clip.mp4"
            media.write_text("fake")
            dispatcher = Mock()
            dispatcher.providers = {}
            tool = VideoTool(dispatcher=dispatcher, workspace_path=temp_dir)
            result = await tool.execute({"action": "qa", "path": str(media)})
            assert result.success is False
            assert result.is_error is True
            assert "requires question" in result.error

    @pytest.mark.asyncio
    async def test_summarize_uses_llm_and_writes_file(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            media = Path(temp_dir) / "clip.mp4"
            media.write_text("fake")
            provider = Mock()
            provider.complete = AsyncMock(return_value=Mock(content="Concise summary"))
            dispatcher = Mock()
            dispatcher.providers = {"anthropic": provider}
            tool = VideoTool(dispatcher=dispatcher, workspace_path=temp_dir)

            with patch.object(tool, '_build_analysis_context', AsyncMock(return_value='context block')):
                result = await tool.execute({"action": "summarize", "path": str(media)})

            assert result.success is True
            assert "Concise summary" in result.content
            out_path = Path(temp_dir) / '.antaris_video' / 'clip' / 'summary.md'
            assert out_path.exists()
            assert out_path.read_text() == "Concise summary"


class TestBrowserTool:
    """Test BrowserTool."""

    def test_tool_properties(self):
        tool = BrowserTool()
        assert tool.name == "browser"
        assert "Browser automation" in tool.description
        assert "Playwright" in tool.description
        assert isinstance(tool.input_schema, dict)
        assert "action" in tool.input_schema["properties"]

    def test_schema_validation(self):
        tool = BrowserTool()
        schema = tool.input_schema
        
        # Check that schema is valid JSON Schema structure
        assert "type" in schema
        assert "properties" in schema
        assert "required" in schema
        assert "action" in schema["required"]
        
        # Check action enum
        action_prop = schema["properties"]["action"]
        assert action_prop["type"] == "string"
        assert "enum" in action_prop
        # Must include at least the core actions + new ones
        expected_core = {"navigate", "screenshot", "click", "type", "get_text"}
        expected_new = {"evaluate", "wait_for", "scroll", "go_back", "go_forward", "reload", "get_url"}
        assert expected_core.issubset(set(action_prop["enum"]))
        assert expected_new.issubset(set(action_prop["enum"]))

    @pytest.mark.asyncio
    async def test_missing_action(self):
        tool = BrowserTool()
        result = await tool.execute({})
        assert result.success is False
        assert result.is_error is True
        assert "Missing required parameter: action" in result.error

    @pytest.mark.asyncio
    async def test_playwright_not_installed(self):
        tool = BrowserTool()
        
        # Mock playwright import to fail
        with patch('builtins.__import__', side_effect=ImportError):
            result = await tool.execute({"action": "navigate", "url": "https://example.com"})
            assert result.success is False
            assert result.is_error is True
            assert "pip install playwright" in result.error

    @pytest.mark.asyncio
    async def test_navigate_missing_url(self):
        tool = BrowserTool()
        
        # Mock successful playwright import but don't actually use it
        with patch('builtins.__import__'):
            result = await tool.execute({"action": "navigate"})
            assert result.success is False
            assert result.is_error is True
            assert "Navigate action requires url parameter" in result.error

    @pytest.mark.asyncio
    async def test_click_missing_selector(self):
        tool = BrowserTool()
        
        with patch('builtins.__import__'):
            result = await tool.execute({"action": "click"})
            assert result.success is False
            assert result.is_error is True
            assert "Click action requires selector parameter" in result.error

    @pytest.mark.asyncio
    async def test_type_missing_parameters(self):
        tool = BrowserTool()
        
        with patch('builtins.__import__'):
            result = await tool.execute({"action": "type", "selector": "input"})
            assert result.success is False
            assert result.is_error is True
            assert "Type action requires selector and text parameters" in result.error


class TestNativeToolInterface:
    """Test that all tools implement NativeTool interface correctly."""

    def test_all_tools_have_required_attributes(self):
        tools = [
            WebSearchTool(api_key="test"),
            WebFetchTool(),
            FileOpsTool(workspace_path="/tmp"),
            ShellTool(workspace_path="/tmp"), 
            BrowserTool(),
        ]
        
        for tool in tools:
            # Check required attributes exist
            assert hasattr(tool, 'name')
            assert hasattr(tool, 'description')
            assert hasattr(tool, 'input_schema')
            assert hasattr(tool, 'execute')
            
            # Check types
            assert isinstance(tool.name, str)
            assert isinstance(tool.description, str)
            assert isinstance(tool.input_schema, dict)
            assert callable(tool.execute)
            
            # Check values are non-empty
            assert tool.name.strip() != ""
            assert tool.description.strip() != ""

    def test_input_schemas_are_valid_json_schema(self):
        tools = [
            WebSearchTool(api_key="test"),
            WebFetchTool(),
            FileOpsTool(workspace_path="/tmp"),
            ShellTool(workspace_path="/tmp"),
            BrowserTool(),
        ]
        
        for tool in tools:
            schema = tool.input_schema
            
            # Basic JSON Schema structure
            assert "type" in schema
            assert schema["type"] == "object"
            assert "properties" in schema
            assert isinstance(schema["properties"], dict)
            
            # Required field should exist if any required params
            if "required" in schema:
                assert isinstance(schema["required"], list)
                # All required fields should exist in properties
                for required_field in schema["required"]:
                    assert required_field in schema["properties"]