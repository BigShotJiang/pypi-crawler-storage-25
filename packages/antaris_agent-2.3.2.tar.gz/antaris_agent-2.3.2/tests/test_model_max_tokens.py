"""Tests for MODEL_MAX_TOKENS and get_model_max_tokens()."""

from antaris_agent.llm.base import get_model_max_tokens, MODEL_MAX_TOKENS


def test_opus_46_128k():
    assert get_model_max_tokens("claude-opus-4-6") == 128000


def test_opus_45_64k():
    assert get_model_max_tokens("claude-opus-4-5") == 64000


def test_opus_41_32k():
    assert get_model_max_tokens("claude-opus-4-1") == 32000


def test_sonnet_46_64k():
    assert get_model_max_tokens("claude-sonnet-4-6") == 64000


def test_sonnet_4_base_64k():
    assert get_model_max_tokens("claude-sonnet-4-20250514") == 64000


def test_haiku_45_64k():
    assert get_model_max_tokens("claude-haiku-4-5-20251001") == 64000


def test_haiku_35_8k():
    assert get_model_max_tokens("claude-haiku-3-5-20241022") == 8192


def test_haiku_unversioned_conservative():
    """Bare 'haiku' should use conservative 8K fallback."""
    assert get_model_max_tokens("haiku") == 8192


def test_gpt_54_128k():
    assert get_model_max_tokens("gpt-5.4") == 128000


def test_gpt_52_128k():
    assert get_model_max_tokens("gpt-5.2") == 128000


def test_gpt_4o_16k():
    assert get_model_max_tokens("gpt-4o") == 16384


def test_gemini_3_65k():
    assert get_model_max_tokens("gemini-3.1-pro-preview") == 65536


def test_gemini_25_65k():
    assert get_model_max_tokens("gemini-2.5-pro") == 65536


def test_unknown_model_default():
    assert get_model_max_tokens("some-unknown-model") == 16384


def test_custom_default():
    assert get_model_max_tokens("unknown", default=8000) == 8000


def test_empty_string():
    assert get_model_max_tokens("") == 16384


def test_none_model():
    """None model should not crash."""
    assert get_model_max_tokens(None) == 16384


def test_case_insensitive():
    """Matching should be case-insensitive."""
    assert get_model_max_tokens("Claude-Opus-4-6") == 128000
    assert get_model_max_tokens("GPT-5.4") == 128000


def test_specific_before_general():
    """More specific patterns should match before general ones."""
    # 'haiku-4-5' should match before bare 'haiku'
    assert get_model_max_tokens("claude-haiku-4-5-20251001") == 64000
    # 'opus-4-6' should match its specific entry, not a broader one
    assert get_model_max_tokens("anthropic/claude-opus-4-6") == 128000
