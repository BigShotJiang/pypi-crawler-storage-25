"""Tests for PowerPoint tool and PPTX ingestion.

Tests cover:
  - PPTXIngester: text extraction, structure analysis, notes, tables, chunking
  - PowerPointTool: all 8 operations (read, structure, slide, summarize, notes,
    rewrite_notes, export_outline, slide_text_replace)
  - Edge cases: empty decks, missing files, missing python-pptx, large text
  - Memory integration: to_memory_entries() output format
"""

from __future__ import annotations

import asyncio
import os
import tempfile
from pathlib import Path
from unittest.mock import patch

import pytest

# ── Test fixtures ──────────────────────────────────────────────────────

def _create_test_pptx(
    path: str,
    slide_count: int = 3,
    include_notes: bool = True,
    include_table: bool = False,
    title: str = "Test Deck",
    author: str = "Test Author",
) -> str:
    """Create a test .pptx file with controllable content."""
    from pptx import Presentation
    from pptx.util import Inches, Pt

    prs = Presentation()

    # Set metadata
    prs.core_properties.title = title
    prs.core_properties.author = author
    prs.core_properties.subject = "Test Subject"

    for i in range(1, slide_count + 1):
        # Use a layout that has a title and content placeholder
        layout = prs.slide_layouts[1]  # Title and Content layout
        slide = prs.slides.add_slide(layout)

        # Set title
        slide.shapes.title.text = f"Slide {i} Title"

        # Set body text
        body = slide.placeholders[1]
        body.text = f"Slide {i} body text.\nThis is the content of slide {i}."
        body.text_frame.add_paragraph().text = f"Additional bullet point on slide {i}."

        # Add speaker notes
        if include_notes:
            notes_slide = slide.notes_slide
            notes_slide.notes_text_frame.text = f"Speaker notes for slide {i}. Key talking point here."

        # Add a table on the last slide
        if include_table and i == slide_count:
            rows, cols = 3, 3
            left = Inches(1.0)
            top = Inches(4.0)
            width = Inches(6.0)
            height = Inches(1.5)
            table = slide.shapes.add_table(rows, cols, left, top, width, height).table

            # Header row
            table.cell(0, 0).text = "Metric"
            table.cell(0, 1).text = "Q1"
            table.cell(0, 2).text = "Q2"
            # Data rows
            table.cell(1, 0).text = "Revenue"
            table.cell(1, 1).text = "$1.2M"
            table.cell(1, 2).text = "$1.5M"
            table.cell(2, 0).text = "Users"
            table.cell(2, 1).text = "10,000"
            table.cell(2, 2).text = "15,000"

    prs.save(path)
    return path


def _create_empty_pptx(path: str) -> str:
    """Create an empty .pptx with no slides."""
    from pptx import Presentation

    prs = Presentation()
    prs.core_properties.title = "Empty Deck"
    prs.save(path)
    return path


@pytest.fixture
def test_pptx(tmp_path):
    """Create a standard test PPTX."""
    path = str(tmp_path / "test_deck.pptx")
    _create_test_pptx(path)
    return path


@pytest.fixture
def test_pptx_with_table(tmp_path):
    """Create a test PPTX with a table."""
    path = str(tmp_path / "table_deck.pptx")
    _create_test_pptx(path, include_table=True)
    return path


@pytest.fixture
def empty_pptx(tmp_path):
    """Create an empty test PPTX."""
    path = str(tmp_path / "empty_deck.pptx")
    _create_empty_pptx(path)
    return path


# ── PPTXIngester tests ─────────────────────────────────────────────────

class TestPPTXIngester:
    """Test the PPTX ingestion module."""

    def test_available(self):
        from parsica_memory.ingest_pptx import PPTXIngester
        assert PPTXIngester.available() is True

    def test_ingest_basic(self, test_pptx):
        from parsica_memory.ingest_pptx import PPTXIngester
        ingester = PPTXIngester()
        result = ingester.ingest(test_pptx)

        assert result.slide_count == 3
        assert result.total_words > 0
        assert len(result.chunks) > 0
        assert not result.errors

    def test_ingest_metadata(self, test_pptx):
        from parsica_memory.ingest_pptx import PPTXIngester
        ingester = PPTXIngester()
        result = ingester.ingest(test_pptx)

        assert result.metadata.title == "Test Deck"
        assert result.metadata.author == "Test Author"
        assert result.metadata.subject == "Test Subject"
        assert result.metadata.slide_count == 3
        assert result.metadata.file_size > 0

    def test_ingest_slide_titles(self, test_pptx):
        from parsica_memory.ingest_pptx import PPTXIngester
        ingester = PPTXIngester()
        result = ingester.ingest(test_pptx)

        titles = [s.title for s in result.slides]
        assert "Slide 1 Title" in titles
        assert "Slide 2 Title" in titles
        assert "Slide 3 Title" in titles

    def test_ingest_body_text(self, test_pptx):
        from parsica_memory.ingest_pptx import PPTXIngester
        ingester = PPTXIngester()
        result = ingester.ingest(test_pptx)

        # Body text should contain the content
        all_body = " ".join(s.body_text for s in result.slides)
        assert "body text" in all_body
        assert "bullet point" in all_body

    def test_ingest_notes(self, test_pptx):
        from parsica_memory.ingest_pptx import PPTXIngester
        ingester = PPTXIngester(include_notes=True)
        result = ingester.ingest(test_pptx)

        notes_slides = [s for s in result.slides if s.notes_text]
        assert len(notes_slides) == 3
        assert "Speaker notes for slide 1" in notes_slides[0].notes_text

    def test_ingest_no_notes(self, test_pptx):
        from parsica_memory.ingest_pptx import PPTXIngester
        ingester = PPTXIngester(include_notes=False)
        result = ingester.ingest(test_pptx)

        # Notes should be empty when disabled
        notes_slides = [s for s in result.slides if s.notes_text]
        assert len(notes_slides) == 0

    def test_ingest_table(self, test_pptx_with_table):
        from parsica_memory.ingest_pptx import PPTXIngester
        ingester = PPTXIngester(include_tables=True)
        result = ingester.ingest(test_pptx_with_table)

        # Last slide should have table
        last_slide = result.slides[-1]
        assert last_slide.has_tables is True

        # Table data should be extracted
        full_text = result.full_text
        assert "Revenue" in full_text or "Metric" in full_text

    def test_ingest_specific_slides(self, test_pptx):
        from parsica_memory.ingest_pptx import PPTXIngester
        ingester = PPTXIngester()
        result = ingester.ingest(test_pptx, slides=[1, 3])

        assert len(result.slides) == 2
        slide_nums = [s.slide_number for s in result.slides]
        assert 1 in slide_nums
        assert 3 in slide_nums
        assert 2 not in slide_nums

    def test_ingest_file_not_found(self):
        from parsica_memory.ingest_pptx import PPTXIngester
        ingester = PPTXIngester()
        result = ingester.ingest("/nonexistent/file.pptx")

        assert len(result.errors) > 0
        assert "not found" in result.errors[0].lower()

    def test_ingest_empty_deck(self, empty_pptx):
        from parsica_memory.ingest_pptx import PPTXIngester
        ingester = PPTXIngester()
        result = ingester.ingest(empty_pptx)

        assert result.slide_count == 0
        assert result.total_words == 0
        assert len(result.chunks) == 0

    def test_full_text(self, test_pptx):
        from parsica_memory.ingest_pptx import PPTXIngester
        ingester = PPTXIngester()
        result = ingester.ingest(test_pptx)

        full_text = result.full_text
        assert "Slide 1" in full_text
        assert "Slide 2" in full_text
        assert "Slide 3" in full_text
        assert "[Notes]" in full_text  # Notes should be included

    def test_structure(self, test_pptx):
        from parsica_memory.ingest_pptx import PPTXIngester
        ingester = PPTXIngester()
        result = ingester.ingest(test_pptx)

        structure = result.structure()
        assert len(structure) == 3
        assert structure[0]["slide"] == 1
        assert structure[0]["title"] == "Slide 1 Title"
        assert "word_count" in structure[0]
        assert "layout" in structure[0]

    def test_summary(self, test_pptx):
        from parsica_memory.ingest_pptx import PPTXIngester
        ingester = PPTXIngester()
        result = ingester.ingest(test_pptx)

        summary = result.summary()
        assert "test_deck.pptx" in summary
        assert "Slides: 3" in summary
        assert "Words:" in summary
        assert "Chunks:" in summary

    def test_slide_text(self, test_pptx):
        from parsica_memory.ingest_pptx import PPTXIngester
        ingester = PPTXIngester()
        result = ingester.ingest(test_pptx)

        text = result.slide_text(1)
        assert text is not None
        assert "Slide 1 Title" in text

        # Non-existent slide
        assert result.slide_text(99) is None

    def test_to_memory_entries(self, test_pptx):
        from parsica_memory.ingest_pptx import PPTXIngester
        ingester = PPTXIngester()
        result = ingester.ingest(test_pptx)

        entries = result.to_memory_entries()
        assert len(entries) > 0

        for entry in entries:
            assert "content" in entry
            assert "source" in entry
            assert "category" in entry
            assert "metadata" in entry
            assert entry["category"] == "deck"
            assert entry["source"].startswith("pptx:")

    def test_to_memory_entries_no_notes(self, test_pptx):
        from parsica_memory.ingest_pptx import PPTXIngester
        ingester = PPTXIngester()
        result = ingester.ingest(test_pptx)

        entries_with_notes = result.to_memory_entries(include_notes=True)
        entries_without_notes = result.to_memory_entries(include_notes=False)

        # Should have fewer entries without notes
        assert len(entries_without_notes) < len(entries_with_notes)

    def test_chunk_content_hashes(self, test_pptx):
        from parsica_memory.ingest_pptx import PPTXIngester
        ingester = PPTXIngester()
        result = ingester.ingest(test_pptx)

        # All chunks should have content hashes
        for chunk in result.chunks:
            assert chunk.content_hash
            assert len(chunk.content_hash) == 16  # SHA-256 prefix

    def test_extraction_time(self, test_pptx):
        from parsica_memory.ingest_pptx import PPTXIngester
        ingester = PPTXIngester()
        result = ingester.ingest(test_pptx)

        assert result.extraction_time_ms > 0

    def test_aspect_ratio(self, test_pptx):
        from parsica_memory.ingest_pptx import PPTXIngester
        ingester = PPTXIngester()
        result = ingester.ingest(test_pptx)

        # Default pptx is typically 10" x 7.5" (4:3)
        # python-pptx defaults to 10" × 7.5" = 13333333 × 10000000 EMU
        ratio = result.metadata.aspect_ratio
        assert ratio in ("4:3", "16:9", "16:10") or ":" in ratio


class TestPPTXConvenienceFunctions:
    """Test the convenience functions."""

    def test_extract_text(self, test_pptx):
        from parsica_memory.ingest_pptx import extract_text
        text = extract_text(test_pptx)
        assert "Slide 1" in text
        assert len(text) > 50

    def test_extract_structure(self, test_pptx):
        from parsica_memory.ingest_pptx import extract_structure
        structure = extract_structure(test_pptx)
        assert len(structure) == 3
        assert structure[0]["title"] == "Slide 1 Title"

    def test_extract_slide(self, test_pptx):
        from parsica_memory.ingest_pptx import extract_slide
        text = extract_slide(test_pptx, 2)
        assert text is not None
        assert "Slide 2 Title" in text

    def test_summarize_deck(self, test_pptx):
        from parsica_memory.ingest_pptx import summarize_deck
        summary = summarize_deck(test_pptx)
        assert "Slides:" in summary


# ── PowerPointTool tests ──────────────────────────────────────────────

class TestPowerPointTool:
    """Test the PowerPoint NativeTool."""

    def test_tool_properties(self):
        from antaris_agent.tools.native.pptx_tool import PowerPointTool
        tool = PowerPointTool()
        assert tool.name == "powerpoint"
        assert "PowerPoint" in tool.description or "pptx" in tool.description
        assert isinstance(tool.input_schema, dict)
        assert "operation" in tool.input_schema["properties"]
        assert "path" in tool.input_schema["properties"]

    def test_schema_operations(self):
        from antaris_agent.tools.native.pptx_tool import PowerPointTool
        tool = PowerPointTool()
        ops = tool.input_schema["properties"]["operation"]["enum"]
        expected = [
            "read", "structure", "slide", "summarize",
            "notes", "rewrite_notes", "export_outline", "slide_text_replace",
        ]
        for op in expected:
            assert op in ops, f"Missing operation: {op}"

    @pytest.mark.asyncio
    async def test_missing_params(self):
        from antaris_agent.tools.native.pptx_tool import PowerPointTool
        tool = PowerPointTool()
        result = await tool.execute({})
        assert result.is_error is True
        assert "Missing required" in result.error

    @pytest.mark.asyncio
    async def test_read(self, test_pptx):
        from antaris_agent.tools.native.pptx_tool import PowerPointTool
        tool = PowerPointTool()
        result = await tool.execute({"operation": "read", "path": test_pptx})
        assert result.success is True
        assert "Slide 1" in result.content
        assert "Slides:" in result.content  # Summary header

    @pytest.mark.asyncio
    async def test_structure(self, test_pptx):
        from antaris_agent.tools.native.pptx_tool import PowerPointTool
        tool = PowerPointTool()
        result = await tool.execute({"operation": "structure", "path": test_pptx})
        assert result.success is True
        assert "Slide  1:" in result.content or "Slide 1:" in result.content
        assert "Slide  2:" in result.content or "Slide 2:" in result.content

    @pytest.mark.asyncio
    async def test_slide(self, test_pptx):
        from antaris_agent.tools.native.pptx_tool import PowerPointTool
        tool = PowerPointTool()
        result = await tool.execute({
            "operation": "slide",
            "path": test_pptx,
            "slide_number": 2,
        })
        assert result.success is True
        assert "Slide 2 Title" in result.content

    @pytest.mark.asyncio
    async def test_slide_missing_number(self, test_pptx):
        from antaris_agent.tools.native.pptx_tool import PowerPointTool
        tool = PowerPointTool()
        result = await tool.execute({
            "operation": "slide",
            "path": test_pptx,
        })
        assert result.is_error is True

    @pytest.mark.asyncio
    async def test_slide_out_of_range(self, test_pptx):
        from antaris_agent.tools.native.pptx_tool import PowerPointTool
        tool = PowerPointTool()
        result = await tool.execute({
            "operation": "slide",
            "path": test_pptx,
            "slide_number": 99,
        })
        assert result.is_error is True

    @pytest.mark.asyncio
    async def test_summarize(self, test_pptx):
        from antaris_agent.tools.native.pptx_tool import PowerPointTool
        tool = PowerPointTool()
        result = await tool.execute({"operation": "summarize", "path": test_pptx})
        assert result.success is True
        assert "Slides: 3" in result.content

    @pytest.mark.asyncio
    async def test_notes(self, test_pptx):
        from antaris_agent.tools.native.pptx_tool import PowerPointTool
        tool = PowerPointTool()
        result = await tool.execute({"operation": "notes", "path": test_pptx})
        assert result.success is True
        assert "Speaker notes" in result.content

    @pytest.mark.asyncio
    async def test_notes_empty_deck(self, empty_pptx):
        from antaris_agent.tools.native.pptx_tool import PowerPointTool
        tool = PowerPointTool()
        result = await tool.execute({"operation": "notes", "path": empty_pptx})
        assert result.success is True
        assert "No speaker notes" in result.content

    @pytest.mark.asyncio
    async def test_rewrite_notes(self, test_pptx):
        from antaris_agent.tools.native.pptx_tool import PowerPointTool
        tool = PowerPointTool()

        new_notes = "These are the updated speaker notes.\nWith multiple lines."
        result = await tool.execute({
            "operation": "rewrite_notes",
            "path": test_pptx,
            "slide_number": 1,
            "notes_text": new_notes,
        })
        assert result.success is True
        assert "Updated" in result.content

        # Verify the notes were actually written
        verify = await tool.execute({"operation": "notes", "path": test_pptx})
        assert "updated speaker notes" in verify.content

    @pytest.mark.asyncio
    async def test_rewrite_notes_out_of_range(self, test_pptx):
        from antaris_agent.tools.native.pptx_tool import PowerPointTool
        tool = PowerPointTool()
        result = await tool.execute({
            "operation": "rewrite_notes",
            "path": test_pptx,
            "slide_number": 99,
            "notes_text": "test",
        })
        assert result.is_error is True

    @pytest.mark.asyncio
    async def test_export_outline(self, test_pptx):
        from antaris_agent.tools.native.pptx_tool import PowerPointTool
        tool = PowerPointTool()
        result = await tool.execute({"operation": "export_outline", "path": test_pptx})
        assert result.success is True
        assert "## Slide 1:" in result.content
        assert "## Slide 2:" in result.content

    @pytest.mark.asyncio
    async def test_slide_text_replace(self, test_pptx):
        from antaris_agent.tools.native.pptx_tool import PowerPointTool
        tool = PowerPointTool()

        result = await tool.execute({
            "operation": "slide_text_replace",
            "path": test_pptx,
            "slide_number": 1,
            "old_text": "Slide 1 Title",
            "new_text": "Updated Title",
        })
        assert result.success is True
        assert "Replaced" in result.content

        # Verify the replacement
        verify = await tool.execute({
            "operation": "slide",
            "path": test_pptx,
            "slide_number": 1,
        })
        assert "Updated Title" in verify.content

    @pytest.mark.asyncio
    async def test_slide_text_replace_not_found(self, test_pptx):
        from antaris_agent.tools.native.pptx_tool import PowerPointTool
        tool = PowerPointTool()
        result = await tool.execute({
            "operation": "slide_text_replace",
            "path": test_pptx,
            "slide_number": 1,
            "old_text": "This text does not exist anywhere",
            "new_text": "replacement",
        })
        assert result.is_error is True

    @pytest.mark.asyncio
    async def test_file_not_found(self):
        from antaris_agent.tools.native.pptx_tool import PowerPointTool
        tool = PowerPointTool()
        result = await tool.execute({
            "operation": "read",
            "path": "/nonexistent/file.pptx",
        })
        # Read operation on ingester returns errors inside the result
        # The tool should still return but with error info
        assert result.success is True or result.is_error is True

    @pytest.mark.asyncio
    async def test_unknown_operation(self, test_pptx):
        from antaris_agent.tools.native.pptx_tool import PowerPointTool
        tool = PowerPointTool()
        result = await tool.execute({
            "operation": "unknown_op",
            "path": test_pptx,
        })
        assert result.is_error is True

    @pytest.mark.asyncio
    async def test_workspace_path_resolution(self, tmp_path):
        from antaris_agent.tools.native.pptx_tool import PowerPointTool

        # Create a pptx in tmp_path
        pptx_path = str(tmp_path / "rel_test.pptx")
        _create_test_pptx(pptx_path, slide_count=1)

        tool = PowerPointTool(workspace_path=str(tmp_path))
        result = await tool.execute({
            "operation": "read",
            "path": "rel_test.pptx",
        })
        assert result.success is True


# ── Integration tests ──────────────────────────────────────────────────

class TestPPTXIntegration:
    """Integration tests: tool + ingester together."""

    @pytest.mark.asyncio
    async def test_full_workflow(self, tmp_path):
        """End-to-end: create deck, read, modify notes, verify."""
        from antaris_agent.tools.native.pptx_tool import PowerPointTool

        pptx_path = str(tmp_path / "workflow_test.pptx")
        _create_test_pptx(pptx_path, slide_count=5, title="Pitch Deck")

        tool = PowerPointTool()

        # 1. Summarize
        result = await tool.execute({"operation": "summarize", "path": pptx_path})
        assert result.success
        assert "Slides: 5" in result.content

        # 2. Get structure
        result = await tool.execute({"operation": "structure", "path": pptx_path})
        assert result.success
        assert "Slide  1:" in result.content or "Slide 1:" in result.content

        # 3. Read specific slide
        result = await tool.execute({
            "operation": "slide",
            "path": pptx_path,
            "slide_number": 3,
        })
        assert result.success
        assert "Slide 3" in result.content

        # 4. Rewrite notes
        result = await tool.execute({
            "operation": "rewrite_notes",
            "path": pptx_path,
            "slide_number": 3,
            "notes_text": "Updated talking point for investors.",
        })
        assert result.success

        # 5. Verify notes update
        result = await tool.execute({"operation": "notes", "path": pptx_path})
        assert result.success
        assert "Updated talking point" in result.content

        # 6. Export outline
        result = await tool.execute({"operation": "export_outline", "path": pptx_path})
        assert result.success
        assert "# Pitch Deck" in result.content

        # 7. Text replace
        result = await tool.execute({
            "operation": "slide_text_replace",
            "path": pptx_path,
            "slide_number": 1,
            "old_text": "Slide 1 Title",
            "new_text": "Introduction",
        })
        assert result.success

        # 8. Verify replace
        result = await tool.execute({
            "operation": "slide",
            "path": pptx_path,
            "slide_number": 1,
        })
        assert "Introduction" in result.content

    @pytest.mark.asyncio
    async def test_table_extraction(self, test_pptx_with_table):
        """Verify table content is properly extracted."""
        from antaris_agent.tools.native.pptx_tool import PowerPointTool

        tool = PowerPointTool()
        result = await tool.execute({
            "operation": "read",
            "path": test_pptx_with_table,
        })
        assert result.success

        # Table content should appear
        content = result.content
        assert "Revenue" in content or "Metric" in content

    @pytest.mark.asyncio
    async def test_memory_entries_format(self, test_pptx):
        """Verify memory entries have correct format for Parsica ingestion."""
        from parsica_memory.ingest_pptx import PPTXIngester

        ingester = PPTXIngester()
        result = ingester.ingest(test_pptx)
        entries = result.to_memory_entries(category="pitch_deck")

        assert len(entries) > 0
        for entry in entries:
            assert isinstance(entry["content"], str)
            assert len(entry["content"]) > 0
            assert entry["source"].startswith("pptx:test_deck.pptx:")
            assert entry["category"] == "pitch_deck"
            assert "slide" in entry["metadata"]
            assert "content_type" in entry["metadata"]
            assert "content_hash" in entry["metadata"]


class TestPPTXEdgeCases:
    """Edge case tests."""

    def test_ingester_available_check(self):
        from parsica_memory.ingest_pptx import PPTXIngester
        # python-pptx is installed in the test env
        assert PPTXIngester.available() is True

    def test_content_hash_deterministic(self):
        from parsica_memory.ingest_pptx import _content_hash
        h1 = _content_hash("test content")
        h2 = _content_hash("test content")
        h3 = _content_hash("different content")
        assert h1 == h2
        assert h1 != h3

    def test_clean_text(self):
        from parsica_memory.ingest_pptx import _clean_text
        assert _clean_text("  hello   world  ") == "hello world"
        assert _clean_text("a\n\n\n\n\nb") == "a\n\nb"
        assert _clean_text("") == ""
        assert _clean_text(None) == ""

    def test_metadata_aspect_ratio(self):
        from parsica_memory.ingest_pptx import PPTXMetadata

        # 16:9
        meta = PPTXMetadata(slide_width_emu=12192000, slide_height_emu=6858000)
        assert meta.aspect_ratio == "16:9"

        # 4:3
        meta = PPTXMetadata(slide_width_emu=9144000, slide_height_emu=6858000)
        assert meta.aspect_ratio == "4:3"

        # Unknown
        meta = PPTXMetadata(slide_width_emu=0, slide_height_emu=0)
        assert meta.aspect_ratio == "unknown"

    def test_slide_content_types(self):
        from parsica_memory.ingest_pptx import SlideContentType
        assert SlideContentType.TITLE.value == "title"
        assert SlideContentType.BODY.value == "body"
        assert SlideContentType.TABLE.value == "table"
        assert SlideContentType.NOTES.value == "notes"

    def test_large_deck(self, tmp_path):
        """Test with a larger deck (20 slides)."""
        from parsica_memory.ingest_pptx import PPTXIngester

        path = str(tmp_path / "large_deck.pptx")
        _create_test_pptx(path, slide_count=20)

        ingester = PPTXIngester()
        result = ingester.ingest(path)

        assert result.slide_count == 20
        assert result.total_words > 0
        assert len(result.chunks) > 0
        assert result.extraction_time_ms > 0
