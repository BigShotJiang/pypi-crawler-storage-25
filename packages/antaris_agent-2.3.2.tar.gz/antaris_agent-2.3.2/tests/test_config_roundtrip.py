"""Tests for Config load/save round-trip of new v2.0.6 fields."""

import json
import tempfile
from pathlib import Path

from antaris_agent.core.config import Config


def _write_config(overrides: dict) -> Path:
    """Write a minimal config JSON to a temp file and return the path."""
    base = {
        "provider": {"name": "anthropic", "apiKey": "test-key"},
        "persona": {"name": "test"},
    }
    base.update(overrides)
    tmp = Path(tempfile.mkdtemp()) / "config.json"
    tmp.write_text(json.dumps(base))
    return tmp


def test_keep_recent_tokens_loads():
    """keep_recent_tokens should load from context.keepRecentTokens."""
    path = _write_config({
        "context": {"maxTokens": 500000, "keepRecentTokens": 50000}
    })
    cfg = Config.load(str(path))
    assert cfg is not None
    assert cfg.context_max_tokens == 500000
    assert cfg.keep_recent_tokens == 50000


def test_keep_recent_tokens_default():
    """keep_recent_tokens should default to 100000 if not in config."""
    path = _write_config({})
    cfg = Config.load(str(path))
    assert cfg is not None
    assert cfg.keep_recent_tokens == 100000


def test_llm_max_tokens_loads():
    """llm.maxTokens should load into cfg.max_tokens."""
    path = _write_config({"llm": {"maxTokens": 32000}})
    cfg = Config.load(str(path))
    assert cfg is not None
    assert cfg.max_tokens == 32000


def test_llm_temperature_loads():
    """llm.temperature should load into cfg.temperature."""
    path = _write_config({"llm": {"temperature": 0.3}})
    cfg = Config.load(str(path))
    assert cfg is not None
    assert cfg.temperature == 0.3


def test_llm_temperature_none_by_default():
    """temperature should be None if not set in config."""
    path = _write_config({})
    cfg = Config.load(str(path))
    assert cfg is not None
    assert cfg.temperature is None


def test_context_max_tokens_default_1m():
    """Default context_max_tokens should be 1M."""
    cfg = Config()
    assert cfg.context_max_tokens == 1000000


def test_save_round_trip():
    """Config.save() should persist llm section and context.keepRecentTokens."""
    path = _write_config({
        "context": {"maxTokens": 750000, "keepRecentTokens": 75000},
        "llm": {"maxTokens": 64000, "temperature": 0.5},
    })
    cfg = Config.load(str(path))
    assert cfg is not None

    # Save to a new temp file
    save_path = Path(tempfile.mkdtemp()) / "config-saved.json"
    cfg.save(str(save_path))

    with open(save_path) as f:
        saved = json.load(f)

    assert saved["context"]["maxTokens"] == 750000
    assert saved["context"]["keepRecentTokens"] == 75000
    assert saved["llm"]["maxTokens"] == 64000
    assert saved["llm"]["temperature"] == 0.5


def test_save_round_trip_no_temperature():
    """When temperature is None, it should be omitted from saved JSON."""
    path = _write_config({"llm": {"maxTokens": 0}})
    cfg = Config.load(str(path))
    assert cfg is not None
    assert cfg.temperature is None

    save_path = Path(tempfile.mkdtemp()) / "config-saved.json"
    cfg.save(str(save_path))

    with open(save_path) as f:
        saved = json.load(f)

    assert "temperature" not in saved.get("llm", {})
