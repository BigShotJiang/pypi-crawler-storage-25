"""Tests for JavaScript Tool Bridge."""

from __future__ import annotations

import asyncio
import json
import pytest
import tempfile
from pathlib import Path
from unittest.mock import Mock, patch, AsyncMock

from antaris_agent.tools.adapters.js_bridge import JSToolBridge


@pytest.fixture
def temp_script():
    """Create a temporary JS script file."""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.js', delete=False) as f:
        f.write("""
// Mock Node.js script for testing
process.stdin.on('data', (data) => {
    try {
        const request = JSON.parse(data.toString());
        const response = {
            jsonrpc: "2.0",
            id: request.id,
            result: {
                method: request.method,
                params: request.params,
                success: true
            }
        };
        console.log(JSON.stringify(response));
    } catch (e) {
        const error = {
            jsonrpc: "2.0",
            id: request?.id || null,
            error: {
                code: -32600,
                message: "Parse error"
            }
        };
        console.log(JSON.stringify(error));
    }
});
""")
        temp_path = f.name
    
    yield temp_path
    
    # Cleanup
    Path(temp_path).unlink(missing_ok=True)


@pytest.fixture
def temp_extension_dir():
    """Create a temporary extension directory with package.json."""
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)
        
        # Create package.json
        package_json = {
            "name": "test-extension",
            "version": "1.0.0",
            "main": "index.js",
            "description": "Test extension"
        }
        
        with open(temp_path / "package.json", 'w') as f:
            json.dump(package_json, f)
        
        # Create main script
        with open(temp_path / "index.js", 'w') as f:
            f.write("""
module.exports = {
    hello: function(name) {
        return `Hello ${name}!`;
    },
    add: function(a, b) {
        return a + b;
    }
};
""")
        
        yield str(temp_path)


@pytest.fixture 
def temp_hook_only_extension():
    """Create extension that only has hooks (not bridgeable)."""
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)
        
        # Package.json without main entry
        package_json = {
            "name": "hook-extension",
            "version": "1.0.0",
            "description": "Hook-only extension"
        }
        
        with open(temp_path / "package.json", 'w') as f:
            json.dump(package_json, f)
        
        yield str(temp_path)


def test_js_bridge_init():
    """Test JSToolBridge initialization."""
    bridge = JSToolBridge("test", "/path/to/script.js", "node")
    
    assert bridge.name == "test"
    assert bridge.script_path == Path("/path/to/script.js")
    assert bridge.node_path == "node"
    assert bridge._process is None
    assert bridge._request_id == 0


@patch('shutil.which')
def test_check_node_available_true(mock_which):
    """Test node availability check when node is available."""
    mock_which.return_value = "/usr/bin/node"
    
    bridge = JSToolBridge("test", "/path/to/script.js")
    assert bridge.check_node_available() is True
    
    mock_which.assert_called_once_with("node")


@patch('shutil.which')
def test_check_node_available_false(mock_which):
    """Test node availability check when node is not available."""
    mock_which.return_value = None
    
    bridge = JSToolBridge("test", "/path/to/script.js")
    assert bridge.check_node_available() is False


@patch('shutil.which')
def test_check_node_available_custom_path(mock_which):
    """Test node availability check with custom node path."""
    mock_which.return_value = "/custom/path/node"
    
    bridge = JSToolBridge("test", "/path/to/script.js", "/custom/path/node")
    assert bridge.check_node_available() is True
    
    mock_which.assert_called_once_with("/custom/path/node")


def test_from_openclaw_extension_success(temp_extension_dir):
    """Test successful extension detection."""
    bridge = JSToolBridge.from_openclaw_extension(temp_extension_dir)
    
    assert bridge is not None
    assert bridge.name == "test-extension"
    # Check that wrapper path was generated
    assert "openclaw_test-extension_wrapper.js" in str(bridge.script_path)


def test_from_openclaw_extension_no_package_json():
    """Test extension detection with missing package.json."""
    with tempfile.TemporaryDirectory() as temp_dir:
        bridge = JSToolBridge.from_openclaw_extension(temp_dir)
        assert bridge is None


def test_from_openclaw_extension_no_main(temp_hook_only_extension):
    """Test extension detection with no main script."""
    bridge = JSToolBridge.from_openclaw_extension(temp_hook_only_extension)
    assert bridge is None


def test_from_openclaw_extension_missing_main_script():
    """Test extension detection when main script doesn't exist."""
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)
        
        # Package.json pointing to non-existent file
        package_json = {
            "name": "broken-extension",
            "main": "missing.js"
        }
        
        with open(temp_path / "package.json", 'w') as f:
            json.dump(package_json, f)
        
        bridge = JSToolBridge.from_openclaw_extension(temp_dir)
        assert bridge is None


@pytest.mark.asyncio
@patch('subprocess.Popen')
@patch('shutil.which')
async def test_call_successful(mock_which, mock_popen, temp_script):
    """Test successful JSON-RPC call."""
    mock_which.return_value = "/usr/bin/node"
    
    # Mock process
    mock_process = Mock()
    mock_process.pid = 12345
    mock_process.poll.return_value = None  # Process is running
    mock_process.stdin = Mock()
    mock_process.stdin.write = Mock()
    mock_process.stdin.flush = Mock()
    mock_process.stdout = Mock()
    mock_process.stderr = Mock()
    
    # Mock successful response
    response_data = {
        "jsonrpc": "2.0",
        "id": 1,
        "result": {"success": True, "message": "test response"}
    }
    mock_process.stdout.readline.return_value = json.dumps(response_data) + "\n"
    
    mock_popen.return_value = mock_process
    
    bridge = JSToolBridge("test", temp_script)
    
    result = await bridge.call("test_method", {"param": "value"})
    
    assert result == {"success": True, "message": "test response"}
    
    # Verify JSON-RPC request was sent correctly
    mock_process.stdin.write.assert_called_once()
    written_data = mock_process.stdin.write.call_args[0][0]
    request = json.loads(written_data.strip())
    
    assert request["jsonrpc"] == "2.0"
    assert request["method"] == "test_method"
    assert request["params"] == {"param": "value"}
    assert request["id"] == 1


@pytest.mark.asyncio
@patch('subprocess.Popen')
@patch('shutil.which')
async def test_call_json_rpc_error(mock_which, mock_popen, temp_script):
    """Test JSON-RPC error response handling."""
    mock_which.return_value = "/usr/bin/node"
    
    # Mock process
    mock_process = Mock()
    mock_process.pid = 12345
    mock_process.poll.return_value = None
    mock_process.stdin = Mock()
    mock_process.stdin.write = Mock()
    mock_process.stdin.flush = Mock()
    mock_process.stdout = Mock()
    mock_process.stderr = Mock()
    
    # Mock error response
    error_data = {
        "jsonrpc": "2.0",
        "id": 1,
        "error": {
            "code": -32601,
            "message": "Method not found"
        }
    }
    mock_process.stdout.readline.return_value = json.dumps(error_data) + "\n"
    
    mock_popen.return_value = mock_process
    
    bridge = JSToolBridge("test", temp_script)
    
    with pytest.raises(RuntimeError, match="JavaScript tool error"):
        await bridge.call("unknown_method", {})


@pytest.mark.asyncio
@patch('shutil.which')
async def test_call_node_not_available(mock_which):
    """Test call when Node.js is not available."""
    mock_which.return_value = None
    
    bridge = JSToolBridge("test", "/path/to/script.js")
    
    with pytest.raises(RuntimeError, match="Node.js not found"):
        await bridge.call("test", {})


@pytest.mark.asyncio
@patch('shutil.which')
async def test_call_script_not_found(mock_which):
    """Test call when script file doesn't exist."""
    mock_which.return_value = "/usr/bin/node"
    
    bridge = JSToolBridge("test", "/nonexistent/script.js")
    
    with pytest.raises(RuntimeError, match="Script not found"):
        await bridge.call("test", {})


@pytest.mark.asyncio
@patch('subprocess.Popen')
@patch('shutil.which')
async def test_close_graceful_shutdown(mock_which, mock_popen):
    """Test graceful process shutdown."""
    mock_which.return_value = "/usr/bin/node"
    
    # Mock process
    mock_process = Mock()
    mock_process.pid = 12345
    mock_process.poll.return_value = None
    mock_process.terminate = Mock()
    mock_process.kill = Mock()
    mock_process.wait = Mock(return_value=0)
    mock_process.stdin = Mock()
    mock_process.stdout = Mock()
    mock_process.stderr = Mock()
    
    mock_popen.return_value = mock_process
    
    bridge = JSToolBridge("test", "/fake/script.js")
    
    # Start process (simulate) - mock script existence
    with patch('pathlib.Path.exists', return_value=True):
        await bridge._start_process()
    
    # Close
    await bridge.close()
    
    mock_process.terminate.assert_called_once()
    mock_process.wait.assert_called_once()
    assert bridge._process is None


@pytest.mark.asyncio
@patch('subprocess.Popen')
@patch('shutil.which')  
async def test_close_force_kill(mock_which, mock_popen):
    """Test force kill when graceful shutdown times out."""
    mock_which.return_value = "/usr/bin/node"
    
    # Mock process that doesn't exit gracefully
    mock_process = Mock()
    mock_process.pid = 12345
    mock_process.poll.return_value = None
    mock_process.terminate = Mock()
    mock_process.kill = Mock()
    mock_process.stdin = Mock()
    mock_process.stdout = Mock()
    mock_process.stderr = Mock()
    
    # Simulate timeout on first wait, then success on forced wait
    wait_calls = 0
    def mock_wait():
        nonlocal wait_calls
        wait_calls += 1
        if wait_calls == 1:
            # Simulate timeout by raising
            import asyncio
            raise asyncio.TimeoutError()
        return 0
    
    mock_popen.return_value = mock_process
    
    bridge = JSToolBridge("test", "/fake/script.js")
    
    # Start process (simulate) - mock script existence
    with patch('pathlib.Path.exists', return_value=True):
        await bridge._start_process()
    
    # Mock the timeout scenario
    with patch('asyncio.wait_for', side_effect=[asyncio.TimeoutError(), None]):
        await bridge.close()
    
    mock_process.terminate.assert_called_once()
    mock_process.kill.assert_called_once()