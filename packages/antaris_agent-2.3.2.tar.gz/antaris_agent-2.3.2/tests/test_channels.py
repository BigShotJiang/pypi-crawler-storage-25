"""
Tests for channel adapters (base, terminal, discord).
Uses mocks — no live connections required.
"""
import asyncio
import builtins
import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from antaris_agent.channels.base import InboundMessage, OutboundMessage, ChannelAdapter
from antaris_agent.channels.terminal import TerminalAdapter
from antaris_agent.channels.discord import DiscordAdapter, MAX_MESSAGE_LENGTH


discord = pytest.importorskip("discord")


# ---------------------------------------------------------------------------
# Dataclass tests
# ---------------------------------------------------------------------------

class TestInboundMessage:
    def test_required_fields(self):
        msg = InboundMessage(
            id="msg-1",
            user_id="user-42",
            user_name="Alice",
            channel_id="ch-100",
            platform="terminal",
            text="hello world",
        )
        assert msg.id == "msg-1"
        assert msg.user_id == "user-42"
        assert msg.user_name == "Alice"
        assert msg.channel_id == "ch-100"
        assert msg.platform == "terminal"
        assert msg.text == "hello world"

    def test_optional_defaults(self):
        msg = InboundMessage(
            id="x", user_id="u", user_name="n", channel_id="c",
            platform="discord", text="hi",
        )
        assert msg.reply_to is None
        assert msg.timestamp_ms == 0
        assert msg.metadata == {}

    def test_metadata_is_independent(self):
        """Each instance should get its own metadata dict."""
        m1 = InboundMessage(id="1", user_id="u", user_name="n", channel_id="c", platform="p", text="t")
        m2 = InboundMessage(id="2", user_id="u", user_name="n", channel_id="c", platform="p", text="t")
        m1.metadata["key"] = "value"
        assert "key" not in m2.metadata


class TestOutboundMessage:
    def test_required_fields(self):
        msg = OutboundMessage(channel_id="ch-1", text="response")
        assert msg.channel_id == "ch-1"
        assert msg.text == "response"

    def test_optional_defaults(self):
        msg = OutboundMessage(channel_id="ch-1", text="hi")
        assert msg.reply_to is None
        assert msg.metadata == {}

    def test_with_all_fields(self):
        msg = OutboundMessage(
            channel_id="ch-99",
            text="full",
            reply_to="msg-5",
            metadata={"foo": "bar"},
        )
        assert msg.reply_to == "msg-5"
        assert msg.metadata["foo"] == "bar"


# ---------------------------------------------------------------------------
# TerminalAdapter tests
# ---------------------------------------------------------------------------

class TestTerminalAdapter:
    def test_initialization_defaults(self):
        adapter = TerminalAdapter()
        assert adapter.bot_name == "Antaris"
        assert adapter._running is False
        assert adapter._handler is None

    def test_initialization_custom_name(self):
        adapter = TerminalAdapter(bot_name="MyBot")
        assert adapter.bot_name == "MyBot"

    def test_format_for_surface_returns_plain_text(self):
        adapter = TerminalAdapter()
        text = "**bold** and _italic_"
        assert adapter.format_for_surface(text) == text

    def test_on_message_registers_handler(self):
        adapter = TerminalAdapter()
        handler = AsyncMock()
        adapter.on_message(handler)
        assert adapter._handler is handler

    @pytest.mark.asyncio
    async def test_send_prints_output(self, capsys):
        adapter = TerminalAdapter(bot_name="TestBot")
        msg = OutboundMessage(channel_id="terminal-local", text="Hello!")
        await adapter.send(msg)
        captured = capsys.readouterr()
        assert "TestBot" in captured.out
        assert "Hello!" in captured.out

    @pytest.mark.asyncio
    async def test_disconnect_sets_running_false(self):
        adapter = TerminalAdapter()
        adapter._running = True
        await adapter.disconnect()
        assert adapter._running is False

    @pytest.mark.asyncio
    async def test_repl_loop_calls_handler(self):
        """REPL should call handler with InboundMessage for user input."""
        adapter = TerminalAdapter()
        handler = AsyncMock()
        adapter.on_message(handler)
        adapter._running = True

        # Simulate: one message then "quit"
        inputs = iter(["Hello bot", "quit"])
        adapter._get_input = lambda: next(inputs)

        await adapter._repl_loop()

        handler.assert_called_once()
        call_arg = handler.call_args[0][0]
        assert isinstance(call_arg, InboundMessage)
        assert call_arg.text == "Hello bot"
        assert call_arg.platform == "terminal"
        assert call_arg.channel_id == TerminalAdapter.CHANNEL_ID

    @pytest.mark.asyncio
    async def test_repl_loop_skips_empty_input(self):
        """Empty lines should not trigger the handler."""
        adapter = TerminalAdapter()
        handler = AsyncMock()
        adapter.on_message(handler)
        adapter._running = True

        inputs = iter(["", "  ", "quit"])
        adapter._get_input = lambda: next(inputs)

        await adapter._repl_loop()
        handler.assert_not_called()

    @pytest.mark.asyncio
    async def test_repl_loop_exits_on_none(self):
        """None return from _get_input (EOF/interrupt) stops the loop."""
        adapter = TerminalAdapter()
        adapter._running = True
        adapter._get_input = lambda: None

        await adapter._repl_loop()
        assert adapter._running is False


# ---------------------------------------------------------------------------
# DiscordAdapter tests (no live connection)
# ---------------------------------------------------------------------------

class TestDiscordAdapter:
    def test_initialization(self):
        adapter = DiscordAdapter(token="fake-token")
        assert adapter.token == "fake-token"
        assert adapter.bot_name == "Antaris"
        assert adapter._client is None

    def test_initialization_custom_name(self):
        adapter = DiscordAdapter(token="tok", bot_name="Shiro")
        assert adapter.bot_name == "Shiro"

    def test_format_for_surface_returns_text_as_is(self):
        adapter = DiscordAdapter(token="tok")
        text = "**bold** _italic_ `code`"
        assert adapter.format_for_surface(text) == text

    def test_split_message_short(self):
        adapter = DiscordAdapter(token="tok")
        text = "Short message"
        chunks = adapter._split_message(text)
        assert chunks == ["Short message"]

    def test_split_message_exact_limit(self):
        adapter = DiscordAdapter(token="tok")
        text = "x" * MAX_MESSAGE_LENGTH
        chunks = adapter._split_message(text)
        assert len(chunks) == 1
        assert chunks[0] == text

    def test_split_message_long_text(self):
        adapter = DiscordAdapter(token="tok")
        # Build a text that is ~3x the limit, split across newlines
        line = "A" * 100
        text = "\n".join([line] * 25)  # 25 * 100 + 24 newlines = 2524 chars
        chunks = adapter._split_message(text)
        assert len(chunks) >= 2
        for chunk in chunks:
            assert len(chunk) <= MAX_MESSAGE_LENGTH

    def test_split_message_preserves_content(self):
        adapter = DiscordAdapter(token="tok")
        line = "B" * 100
        text = "\n".join([line] * 25)
        chunks = adapter._split_message(text)
        rejoined = "\n".join(chunks)
        # All original lines should be present
        for chunk in chunks:
            assert "B" * 100 in chunk

    def test_split_message_single_oversized_line(self):
        """A single line longer than the limit should be its own chunk."""
        adapter = DiscordAdapter(token="tok")
        huge_line = "Z" * (MAX_MESSAGE_LENGTH + 500)
        chunks = adapter._split_message(huge_line)
        # The huge line should end up in a chunk by itself
        assert any(huge_line in chunk for chunk in chunks)

    @pytest.mark.asyncio
    async def test_send_no_client_is_noop(self):
        """send() should silently do nothing if client is not connected."""
        adapter = DiscordAdapter(token="tok")
        msg = OutboundMessage(channel_id="123456789", text="hi")
        # Should not raise
        await adapter.send(msg)

    @pytest.mark.asyncio
    async def test_disconnect_no_client_is_noop(self):
        adapter = DiscordAdapter(token="tok")
        # Should not raise
        await adapter.disconnect()

    @pytest.mark.asyncio
    async def test_connect_without_discord_dependency_raises_helpful_error(self):
        adapter = DiscordAdapter(token="tok")

        real_import = builtins.__import__

        def fake_import(name, *args, **kwargs):
            if name == "discord":
                raise ImportError("No module named 'discord'")
            return real_import(name, *args, **kwargs)

        with patch("builtins.__import__", side_effect=fake_import):
            with pytest.raises(ImportError, match=r"antaris-agent\[discord\]"):
                await adapter.connect()

    @pytest.mark.asyncio
    async def test_send_uses_split_and_sends_chunks(self):
        """send() should call channel.send() for each chunk."""
        adapter = DiscordAdapter(token="tok")

        # Mock client and channel
        mock_channel = AsyncMock()
        mock_client = MagicMock()
        mock_client.get_channel.return_value = mock_channel
        adapter._client = mock_client

        line = "C" * 100
        long_text = "\n".join([line] * 25)  # > 2000 chars
        msg = OutboundMessage(channel_id="999", text=long_text)
        await adapter.send(msg)

        # Should have called channel.send at least twice
        assert mock_channel.send.call_count >= 2

    @pytest.mark.asyncio
    async def test_send_fetches_channel_if_not_cached(self):
        """If get_channel returns None, adapter should try fetch_channel."""
        adapter = DiscordAdapter(token="tok")

        mock_channel = MagicMock()
        mock_channel.send = AsyncMock()

        # Use MagicMock for client so get_channel() is synchronous (as in real discord.py)
        mock_client = MagicMock()
        mock_client.get_channel.return_value = None
        mock_client.fetch_channel = AsyncMock(return_value=mock_channel)
        adapter._client = mock_client

        msg = OutboundMessage(channel_id="888", text="hello")
        await adapter.send(msg)

        mock_client.fetch_channel.assert_called_once_with(888)
        mock_channel.send.assert_called_once_with("hello")

    @pytest.mark.asyncio
    async def test_send_handles_fetch_failure_gracefully(self, caplog):
        """If fetch_channel raises, adapter should log error and not crash."""
        import logging
        adapter = DiscordAdapter(token="tok")

        # Use MagicMock for client so get_channel() is synchronous (as in real discord.py)
        mock_client = MagicMock()
        mock_client.get_channel.return_value = None
        mock_client.fetch_channel = AsyncMock(side_effect=Exception("Not found"))
        adapter._client = mock_client

        msg = OutboundMessage(channel_id="777", text="hello")
        with caplog.at_level(logging.ERROR):
            await adapter.send(msg)  # Should not raise

        assert "Could not find" in caplog.text or len(caplog.records) > 0
