import asyncio
import json
import re
from pathlib import Path
from unittest.mock import MagicMock

from antaris_agent.core.config import Config, normalize_security_mode
from antaris_agent.core.memory import BotMemory, _normalize_user_id
from antaris_agent.persona.awakening import Awakening
from antaris_agent.persona.loader import PersonaLoader
from antaris_agent.tools.native.pptx_tool import _get_pptx_ingester_class


# ---------------------------------------------------------------------------
# Version surface consistency (Wave 3)
# ---------------------------------------------------------------------------

def test_package_version_single_source_of_truth():
    """antaris_agent.__version__ must come from _version.py, not a duplicate."""
    from antaris_agent._version import __version__ as canonical
    from antaris_agent import __version__ as init_version
    from antaris_agent.cli import VERSION as cli_version
    assert init_version == canonical, f"__init__ ({init_version}) != _version ({canonical})"
    assert cli_version == canonical, f"cli ({cli_version}) != _version ({canonical})"


def test_suite_component_versions_match_umbrella():
    """All suite component __version__ strings must equal the umbrella version."""
    from antaris_agent.suite import __version__ as umbrella
    from antaris_agent.suite.guard import __version__ as guard_v
    from antaris_agent.suite.router import __version__ as router_v
    from antaris_agent.suite.context import __version__ as context_v
    from antaris_agent.suite.pipeline import __version__ as pipeline_v
    for name, v in [("guard", guard_v), ("router", router_v),
                    ("context", context_v), ("pipeline", pipeline_v)]:
        assert v == umbrella, f"suite.{name} ({v}) != umbrella ({umbrella})"


def test_pyproject_comments_match_actual_versions():
    """pyproject.toml version comments must agree with code."""
    from antaris_agent.suite.guard import __version__ as guard_v
    from parsica_memory import __version__ as pm_v

    toml_path = Path(__file__).resolve().parent.parent / "pyproject.toml"
    text = toml_path.read_text()

    # Check parsica-memory comment
    pm_match = re.search(r"# parsica-memory (\S+)", text)
    assert pm_match, "pyproject.toml missing parsica-memory version comment"
    assert pm_match.group(1) == pm_v, f"comment ({pm_match.group(1)}) != code ({pm_v})"

    # Check guard comment (representative of all suite components)
    guard_match = re.search(r"# antaris-guard (\S+)", text)
    assert guard_match, "pyproject.toml missing antaris-guard version comment"
    assert guard_match.group(1) == guard_v, f"comment ({guard_match.group(1)}) != code ({guard_v})"


def test_parsica_memory_version_is_set():
    """parsica_memory.__version__ must be set and non-empty."""
    from parsica_memory import __version__ as pm_v
    assert pm_v, "parsica_memory.__version__ must not be empty"


# ---------------------------------------------------------------------------
# Original Wave 1 tests
# ---------------------------------------------------------------------------

def test_security_mode_normalization_aliases():
    assert normalize_security_mode("locked") == "encrypted"
    assert normalize_security_mode("3") == "secured"
    assert normalize_security_mode("  SANDBOXED ") == "sandboxed"


def test_config_load_normalizes_locked_security_mode(tmp_path, monkeypatch):
    monkeypatch.setattr("antaris_agent.core.config.load_auth_profiles", lambda path=None: {})
    config_file = tmp_path / "config.json"
    config_file.write_text(json.dumps({
        "bot": {"name": "Wave1"},
        "provider": {"name": "anthropic", "apiKey": "sk-test"},
        "security": {"mode": "locked"},
    }))
    cfg = Config.load(str(config_file))
    assert cfg is not None
    assert cfg.security_mode == "encrypted"
    assert cfg.guard_mode == "block"


def test_memory_user_id_is_sanitized_and_contained(tmp_path):
    mem = BotMemory(store_path=str(tmp_path / "store"))
    dangerous = "../../outside-user"
    safe_dir = mem._user_store_path(dangerous)
    assert safe_dir.parent == mem.store_path
    assert ".." not in safe_dir.name
    assert safe_dir.name == _normalize_user_id(dangerous)


def test_clear_memories_only_affects_hashed_user_dir(tmp_path):
    mem = BotMemory(store_path=str(tmp_path / "store"))
    user_id = "../../outside-user"
    user_dir = mem._user_store_path(user_id)
    user_dir.mkdir(parents=True, exist_ok=True)
    (user_dir / "keep.json").write_text("{}")
    sibling = mem.store_path / "innocent"
    sibling.mkdir(parents=True, exist_ok=True)
    (sibling / "safe.json").write_text("{}")

    deleted = mem.clear_memories(user_id)

    assert deleted == 1
    assert user_dir.exists()
    assert not (user_dir / "keep.json").exists()
    assert (sibling / "safe.json").exists()


def test_awakening_completion_seeds_memory(tmp_path):
    soul_path = tmp_path / "SOUL.md"
    soul_path.write_text("AWAKENING_NEEDED\n")
    loader = PersonaLoader(config_dir=str(tmp_path))
    memory = MagicMock()
    awakening = Awakening(loader, llm=None, memory=memory)

    awakening.start("user-1")
    asyncio.run(awakening.process("user-1", "Nova"))
    asyncio.run(awakening.process("user-1", "Created by Antaris"))
    asyncio.run(awakening.process("user-1", "Help with work"))
    asyncio.run(awakening.process("user-1", "Direct and calm"))
    asyncio.run(awakening.process("user-1", "nothing"))
    asyncio.run(awakening.process("user-1", "yes"))

    assert soul_path.exists()
    memory._get_store.assert_called_once_with("user-1")


def test_pptx_ingester_import_prefers_bundled_runtime():
    klass = _get_pptx_ingester_class()
    assert klass.__module__.startswith("parsica_memory")


def test_export_memories_uses_wildcard_fallback(tmp_path):
    mem = BotMemory(store_path=str(tmp_path / "store"))
    mock_store = MagicMock()
    entry = MagicMock()
    entry.content = "remember this"
    entry.relevance = 0.9
    entry.score = 0.9
    entry.timestamp = None
    entry.source = "conversation"
    entry.category = "chat"
    mock_store.search.side_effect = [[], [entry]]
    mem._stores["user1"] = mock_store

    out = tmp_path / "export.json"
    count = mem.export_memories("user1", str(out))

    assert count == 1
    assert mock_store.search.call_args_list[0].args == ("*",)
    assert mock_store.search.call_args_list[0].kwargs == {"limit": 10_000}
    data = json.loads(out.read_text())
    assert data["entry_count"] == 1
