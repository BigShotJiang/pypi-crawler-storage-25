"""
Tests for RepairManager self-diagnostic system.

Covers:
- Config integrity checks
- PID file cleanup
- Memory store validation
- Socket cleanup
- Dependency verification
- Directory structure
"""
from __future__ import annotations

import json
import os
import signal
import socket
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, mock_open, patch

import pytest

from antaris_agent.daemon.repair import RepairManager


class TestRepairManager:
    """Test the self-diagnostic repair manager."""

    @pytest.fixture
    def repair_manager(self):
        """Create RepairManager instance."""
        return RepairManager()

    @pytest.fixture
    def temp_config_dir(self):
        """Create temporary config directory."""
        with tempfile.TemporaryDirectory() as temp_dir:
            config_dir = Path(temp_dir)
            config_path = config_dir / "config.json"
            pid_file = config_dir / "bot.pid"
            socket_path = config_dir / "antarisd.sock"
            
            # Patch all the paths
            with patch("antaris_agent.daemon.repair.DEFAULT_CONFIG_DIR", config_dir), \
                 patch("antaris_agent.daemon.repair.DEFAULT_CONFIG_PATH", config_path), \
                 patch("antaris_agent.daemon.repair.PID_FILE", pid_file), \
                 patch("antaris_agent.daemon.repair.SOCKET_PATH", socket_path):
                yield config_dir, config_path, pid_file, socket_path

    def test_run_all_checks(self, repair_manager, temp_config_dir):
        """Test running all repair checks."""
        config_dir, config_path, pid_file, socket_path = temp_config_dir
        
        # Create a valid config
        valid_config = {
            "bot_name": "Antaris",
            "provider_name": "anthropic", 
            "model": "claude-sonnet-4-6"
        }
        config_path.write_text(json.dumps(valid_config))
        
        # Create memory directory
        (config_dir / "memory").mkdir()
        
        results = repair_manager.run()
        
        assert len(results) == 6
        check_names = {result["check"] for result in results}
        expected_checks = {
            "config_integrity", "pid_file", "memory_store", 
            "socket_file", "dependencies", "directories"
        }
        assert check_names == expected_checks

    def test_check_config_valid(self, repair_manager, temp_config_dir):
        """Test config check with valid config."""
        config_dir, config_path, pid_file, socket_path = temp_config_dir
        
        valid_config = {
            "bot_name": "Antaris",
            "provider_name": "anthropic",
            "model": "claude-sonnet-4-6",
            "extra_field": "value"
        }
        config_path.write_text(json.dumps(valid_config))
        
        result = repair_manager._check_config()
        
        assert result["check"] == "config_integrity"
        assert result["status"] == "ok"
        assert result["fixed"] is False
        assert "valid" in result["message"]

    def test_check_config_missing(self, repair_manager, temp_config_dir):
        """Test config check with missing config file."""
        config_dir, config_path, pid_file, socket_path = temp_config_dir
        
        result = repair_manager._check_config()
        
        assert result["check"] == "config_integrity"
        assert result["status"] == "error"
        assert result["fixed"] is False
        assert "not found" in result["message"]

    def test_check_config_missing_fields(self, repair_manager, temp_config_dir):
        """Test config check with missing required fields."""
        config_dir, config_path, pid_file, socket_path = temp_config_dir
        
        invalid_config = {
            "bot_name": "Antaris"
            # Missing provider_name and model
        }
        config_path.write_text(json.dumps(invalid_config))
        
        result = repair_manager._check_config()
        
        assert result["check"] == "config_integrity"
        assert result["status"] == "error"
        assert "missing required fields" in result["message"]
        assert "provider_name" in result["message"]
        assert "model" in result["message"]

    def test_check_config_corrupt_with_backup(self, repair_manager, temp_config_dir):
        """Test config check with corrupt config and valid backup."""
        config_dir, config_path, pid_file, socket_path = temp_config_dir
        
        # Create corrupt config
        config_path.write_text("invalid json {")
        
        # Create valid backup
        backup_path = config_path.with_suffix(".json.bak")
        valid_config = {
            "bot_name": "Antaris",
            "provider_name": "anthropic",
            "model": "claude-sonnet-4-6"
        }
        backup_path.write_text(json.dumps(valid_config))
        
        result = repair_manager._check_config(auto_fix=True)
        
        assert result["check"] == "config_integrity"
        assert result["status"] == "fixed"
        assert result["fixed"] is True
        assert "Restored config from backup" in result["message"]
        
        # Verify config was restored
        restored_config = json.loads(config_path.read_text())
        assert restored_config["bot_name"] == "Antaris"

    def test_check_config_corrupt_no_backup(self, repair_manager, temp_config_dir):
        """Test config check with corrupt config and no backup."""
        config_dir, config_path, pid_file, socket_path = temp_config_dir
        
        # Create corrupt config
        config_path.write_text("invalid json {")
        
        result = repair_manager._check_config(auto_fix=True)
        
        assert result["check"] == "config_integrity"
        assert result["status"] == "error"
        assert result["fixed"] is False
        assert "corrupt and no valid backup" in result["message"]

    def test_check_config_corrupt_invalid_backup(self, repair_manager, temp_config_dir):
        """Test config check with corrupt config and invalid backup."""
        config_dir, config_path, pid_file, socket_path = temp_config_dir
        
        # Create corrupt config
        config_path.write_text("invalid json {")
        
        # Create invalid backup
        backup_path = config_path.with_suffix(".json.bak")
        backup_path.write_text("also invalid {")
        
        result = repair_manager._check_config(auto_fix=True)
        
        assert result["check"] == "config_integrity"
        assert result["status"] == "error"
        assert result["fixed"] is False
        assert "corrupt and no valid backup" in result["message"]

    def test_check_pid_file_clean_state(self, repair_manager, temp_config_dir):
        """Test PID file check with no PID file."""
        config_dir, config_path, pid_file, socket_path = temp_config_dir
        
        result = repair_manager._check_pid_file()
        
        assert result["check"] == "pid_file"
        assert result["status"] == "ok"
        assert result["fixed"] is False
        assert "clean state" in result["message"]

    def test_check_pid_file_running_process(self, repair_manager, temp_config_dir):
        """Test PID file check with running process."""
        config_dir, config_path, pid_file, socket_path = temp_config_dir
        
        current_pid = os.getpid()
        pid_file.write_text(str(current_pid))
        
        result = repair_manager._check_pid_file()
        
        assert result["check"] == "pid_file"
        assert result["status"] == "ok"
        assert result["fixed"] is False
        assert f"running with PID {current_pid}" in result["message"]

    def test_check_pid_file_stale(self, repair_manager, temp_config_dir):
        """Test PID file check with stale PID."""
        config_dir, config_path, pid_file, socket_path = temp_config_dir
        
        # Use a PID that definitely doesn't exist
        fake_pid = 999999
        pid_file.write_text(str(fake_pid))
        
        # Mock os.kill to raise ProcessLookupError
        with patch("os.kill") as mock_kill:
            mock_kill.side_effect = ProcessLookupError()
            
            result = repair_manager._check_pid_file(auto_fix=True)
            
            assert result["check"] == "pid_file"
            assert result["status"] == "fixed"
            assert result["fixed"] is True
            assert "Removed stale PID file" in result["message"]
            assert not pid_file.exists()

    def test_check_pid_file_stale_no_fix(self, repair_manager, temp_config_dir):
        """Test PID file check with stale PID and no auto-fix."""
        config_dir, config_path, pid_file, socket_path = temp_config_dir
        
        fake_pid = 999999
        pid_file.write_text(str(fake_pid))
        
        with patch("os.kill") as mock_kill:
            mock_kill.side_effect = ProcessLookupError()
            
            result = repair_manager._check_pid_file(auto_fix=False)
            
            assert result["check"] == "pid_file"
            assert result["status"] == "error"
            assert result["fixed"] is False
            assert "Stale PID file exists" in result["message"]
            assert pid_file.exists()  # Should not be removed

    def test_check_pid_file_permission_denied(self, repair_manager, temp_config_dir):
        """Test PID file check with permission denied."""
        config_dir, config_path, pid_file, socket_path = temp_config_dir
        
        pid_file.write_text("12345")
        
        with patch("os.kill") as mock_kill:
            mock_kill.side_effect = PermissionError()
            
            result = repair_manager._check_pid_file()
            
            assert result["check"] == "pid_file"
            assert result["status"] == "warning"
            assert result["fixed"] is False
            assert "permission denied" in result["message"]

    def test_check_pid_file_invalid(self, repair_manager, temp_config_dir):
        """Test PID file check with invalid PID."""
        config_dir, config_path, pid_file, socket_path = temp_config_dir
        
        pid_file.write_text("not_a_number")
        
        result = repair_manager._check_pid_file(auto_fix=True)
        
        assert result["check"] == "pid_file"
        assert result["status"] == "fixed"
        assert result["fixed"] is True
        assert "Removed invalid PID file" in result["message"]
        assert not pid_file.exists()

    def test_check_memory_store_exists(self, repair_manager, temp_config_dir):
        """Test memory store check when directory exists."""
        config_dir, config_path, pid_file, socket_path = temp_config_dir
        
        memory_dir = config_dir / "memory"
        memory_dir.mkdir()
        
        result = repair_manager._check_memory_store()
        
        assert result["check"] == "memory_store"
        assert result["status"] == "ok"
        assert result["fixed"] is False
        assert "accessible" in result["message"]

    def test_check_memory_store_missing(self, repair_manager, temp_config_dir):
        """Test memory store check when directory is missing."""
        config_dir, config_path, pid_file, socket_path = temp_config_dir
        
        result = repair_manager._check_memory_store(auto_fix=True)
        
        assert result["check"] == "memory_store"
        assert result["status"] == "fixed"
        assert result["fixed"] is True
        assert "Created memory store directory" in result["message"]
        
        memory_dir = config_dir / "memory"
        assert memory_dir.exists()
        assert memory_dir.is_dir()

    def test_check_memory_store_missing_no_fix(self, repair_manager, temp_config_dir):
        """Test memory store check with missing directory and no auto-fix."""
        config_dir, config_path, pid_file, socket_path = temp_config_dir
        
        result = repair_manager._check_memory_store(auto_fix=False)
        
        assert result["check"] == "memory_store"
        assert result["status"] == "error"
        assert result["fixed"] is False
        assert "directory missing" in result["message"]

    def test_check_memory_store_from_config(self, repair_manager, temp_config_dir):
        """Test memory store check using path from config."""
        config_dir, config_path, pid_file, socket_path = temp_config_dir
        
        custom_memory = config_dir / "custom_memory"
        config = {"memory_store": str(custom_memory)}
        config_path.write_text(json.dumps(config))
        
        result = repair_manager._check_memory_store(auto_fix=True)
        
        assert result["check"] == "memory_store"
        assert result["status"] == "fixed"
        assert str(custom_memory) in result["message"]
        assert custom_memory.exists()

    def test_check_memory_store_not_directory(self, repair_manager, temp_config_dir):
        """Test memory store check when path exists but is not a directory."""
        config_dir, config_path, pid_file, socket_path = temp_config_dir
        
        # Create a file instead of directory
        memory_file = config_dir / "memory"
        memory_file.write_text("not a directory")
        
        result = repair_manager._check_memory_store()
        
        assert result["check"] == "memory_store"
        assert result["status"] == "error"
        assert result["fixed"] is False
        assert "not a directory" in result["message"]

    def test_check_memory_store_not_writable(self, repair_manager, temp_config_dir):
        """Test memory store check when directory is not writable."""
        config_dir, config_path, pid_file, socket_path = temp_config_dir
        
        memory_dir = config_dir / "memory"
        memory_dir.mkdir()
        
        # Mock write test to fail
        with patch.object(Path, "write_text") as mock_write:
            mock_write.side_effect = OSError("Permission denied")
            
            result = repair_manager._check_memory_store()
            
            assert result["check"] == "memory_store"
            assert result["status"] == "error"
            assert "not writable" in result["message"]

    def test_check_socket_clean_state(self, repair_manager, temp_config_dir):
        """Test socket check with no socket file."""
        config_dir, config_path, pid_file, socket_path = temp_config_dir
        
        result = repair_manager._check_socket()
        
        assert result["check"] == "socket_file"
        assert result["status"] == "ok"
        assert result["fixed"] is False
        assert "clean state" in result["message"]

    def test_check_socket_active(self, repair_manager, temp_config_dir):
        """Test socket check with active daemon."""
        config_dir, config_path, pid_file, socket_path = temp_config_dir
        
        socket_path.touch()  # Create socket file
        
        # Mock successful socket connection
        mock_socket = MagicMock()
        
        with patch("socket.socket") as mock_socket_class:
            mock_socket_class.return_value.__enter__ = MagicMock(return_value=mock_socket)
            mock_socket_class.return_value.__exit__ = MagicMock(return_value=None)
            mock_socket.connect = MagicMock()  # Successful connection
            
            result = repair_manager._check_socket()
            
            assert result["check"] == "socket_file"
            assert result["status"] == "ok"
            assert "daemon listening" in result["message"]

    def test_check_socket_stale(self, repair_manager, temp_config_dir):
        """Test socket check with stale socket file."""
        config_dir, config_path, pid_file, socket_path = temp_config_dir
        
        socket_path.touch()  # Create socket file
        
        # Mock connection refused
        mock_socket = MagicMock()
        mock_socket.connect.side_effect = ConnectionRefusedError()
        
        with patch("socket.socket") as mock_socket_class:
            mock_socket_class.return_value = mock_socket
            
            result = repair_manager._check_socket(auto_fix=True)
            
            assert result["check"] == "socket_file"
            assert result["status"] == "fixed"
            assert result["fixed"] is True
            assert "Removed stale socket file" in result["message"]
            assert not socket_path.exists()

    def test_check_socket_stale_no_fix(self, repair_manager, temp_config_dir):
        """Test socket check with stale socket and no auto-fix."""
        config_dir, config_path, pid_file, socket_path = temp_config_dir
        
        socket_path.touch()
        
        mock_socket = MagicMock()
        mock_socket.connect.side_effect = ConnectionRefusedError()
        
        with patch("socket.socket") as mock_socket_class:
            mock_socket_class.return_value = mock_socket
            
            result = repair_manager._check_socket(auto_fix=False)
            
            assert result["check"] == "socket_file"
            assert result["status"] == "error"
            assert result["fixed"] is False
            assert "Stale socket file exists" in result["message"]
            assert socket_path.exists()

    def test_check_dependencies_all_present(self, repair_manager):
        """Test dependency check with all packages installed."""
        # Mock importlib.util.find_spec to always return a truthy spec
        with patch("importlib.util.find_spec", return_value=MagicMock()):
            result = repair_manager._check_dependencies()
        
        assert result["check"] == "dependencies"
        assert result["status"] == "ok"
        assert result["fixed"] is False
        assert "All required packages installed" in result["message"]

    def test_check_dependencies_missing(self, repair_manager):
        """Test dependency check with missing packages."""
        def mock_find_spec(name):
            if name in ("parsica_memory", "discord"):
                return None  # Not found
            return MagicMock()  # Found
        
        with patch("importlib.util.find_spec", side_effect=mock_find_spec):
            result = repair_manager._check_dependencies()
        
        assert result["check"] == "dependencies"
        assert result["status"] == "error"
        assert result["fixed"] is False
        assert "Missing packages" in result["message"]
        assert "parsica-memory" in result["message"]
        assert "discord.py" in result["message"]

    def test_check_directories_all_exist(self, repair_manager, temp_config_dir):
        """Test directory check when all directories exist."""
        config_dir, config_path, pid_file, socket_path = temp_config_dir
        
        # Create all required directories
        (config_dir / "logs").mkdir()
        (config_dir / "memory").mkdir()
        (config_dir / "backups").mkdir()
        
        result = repair_manager._check_directories()
        
        assert result["check"] == "directories"
        assert result["status"] == "ok"
        assert result["fixed"] is False
        assert "All required directories exist" in result["message"]

    def test_check_directories_missing(self, repair_manager, temp_config_dir):
        """Test directory check with missing directories."""
        config_dir, config_path, pid_file, socket_path = temp_config_dir
        
        result = repair_manager._check_directories(auto_fix=True)
        
        assert result["check"] == "directories"
        assert result["status"] == "fixed"
        assert result["fixed"] is True
        assert "Created directories" in result["message"]
        
        # Verify directories were created
        assert (config_dir / "logs").exists()
        assert (config_dir / "memory").exists()
        assert (config_dir / "backups").exists()

    def test_check_directories_missing_no_fix(self, repair_manager, temp_config_dir):
        """Test directory check with missing directories and no auto-fix."""
        config_dir, config_path, pid_file, socket_path = temp_config_dir
        
        result = repair_manager._check_directories(auto_fix=False)
        
        assert result["check"] == "directories"
        assert result["status"] == "error"
        assert result["fixed"] is False
        assert "Cannot create directories" in result["message"]

    def test_check_directories_creation_fails(self, repair_manager, temp_config_dir):
        """Test directory check when directory creation fails."""
        config_dir, config_path, pid_file, socket_path = temp_config_dir
        
        # Mock mkdir to fail
        with patch.object(Path, "mkdir") as mock_mkdir:
            mock_mkdir.side_effect = OSError("Permission denied")
            
            result = repair_manager._check_directories(auto_fix=True)
            
            assert result["check"] == "directories"
            assert result["status"] == "error"
            assert "Cannot create directories" in result["message"]

    def test_check_directories_partial_success(self, repair_manager, temp_config_dir):
        """Test directory check when some dirs can be created and one fails."""
        config_dir, config_path, pid_file, socket_path = temp_config_dir

        # Pre-create logs and memory dirs so only backups is missing
        (config_dir / "logs").mkdir(exist_ok=True)
        (config_dir / "memory").mkdir(exist_ok=True)
        # Leave backups missing — patch mkdir on that specific path to raise
        backups_dir = config_dir / "backups"

        original_mkdir = Path.mkdir

        def selective_mkdir(self_path, *args, **kwargs):
            if self_path == backups_dir:
                raise OSError("Permission denied")
            return original_mkdir(self_path, *args, **kwargs)

        with patch.object(Path, "mkdir", selective_mkdir):
            result = repair_manager._check_directories(auto_fix=True)

        # backups failed → status is error, but other dirs may have been created
        assert result["check"] == "directories"
        assert result["status"] == "error"
        assert "backups" in result["message"]
        assert result["fixed"] in (True, False)  # partial creation may have happened

    def test_run_with_auto_fix_disabled(self, repair_manager, temp_config_dir):
        """Test running repair with auto-fix disabled."""
        config_dir, config_path, pid_file, socket_path = temp_config_dir
        
        # Create issues that would normally be auto-fixed
        pid_file.write_text("999999")  # Fake PID
        
        with patch("os.kill") as mock_kill:
            mock_kill.side_effect = ProcessLookupError()
            
            results = repair_manager.run(auto_fix=False)
            
            # Should detect but not fix issues
            pid_result = next(r for r in results if r["check"] == "pid_file")
            assert pid_result["status"] == "error"
            assert pid_result["fixed"] is False
            assert pid_file.exists()  # Should not be removed

    def test_all_checks_return_proper_format(self, repair_manager, temp_config_dir):
        """Test that all check methods return the expected dictionary format."""
        config_dir, config_path, pid_file, socket_path = temp_config_dir
        
        # Create minimal valid setup
        valid_config = {
            "bot_name": "Test",
            "provider_name": "test", 
            "model": "test-model"
        }
        config_path.write_text(json.dumps(valid_config))
        
        results = repair_manager.run()
        
        for result in results:
            # Verify required fields
            assert "check" in result
            assert "status" in result
            assert "message" in result
            assert "fixed" in result
            
            # Verify field types
            assert isinstance(result["check"], str)
            assert result["status"] in ["ok", "error", "warning", "fixed"]
            assert isinstance(result["message"], str)
            assert isinstance(result["fixed"], bool)
            
            # Verify logic consistency
            if result["status"] == "fixed":
                assert result["fixed"] is True
            elif result["status"] == "ok":
                assert result["fixed"] is False