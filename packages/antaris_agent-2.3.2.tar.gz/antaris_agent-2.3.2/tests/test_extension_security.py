"""
Tests for the extension security system — capability-based access control,
source trust classification, allowlist enforcement, and high-risk gating.
"""

import json
import pytest
from pathlib import Path
from unittest.mock import MagicMock, AsyncMock

from antaris_agent.extensions.security import (
    ExtensionCapability,
    ExtensionSource,
    ExtensionSecurityManager,
    ExtensionAllowlist,
    ExtensionPolicy,
    AllowlistEntry,
    HIGH_RISK_CAPABILITIES,
    BUILTIN_EXTENSION_NAMES,
    _MODE_DEFAULTS,
)
from antaris_agent.extensions.base import Extension, ExtensionContext, ExtensionState
from antaris_agent.extensions.manager import ExtensionManager


# ── HIGH_RISK_CAPABILITIES ────────────────────────────────────────────────

class TestHighRiskCapabilities:

    def test_high_risk_set_contains_expected(self):
        assert ExtensionCapability.SHELL_EXEC in HIGH_RISK_CAPABILITIES
        assert ExtensionCapability.DESKTOP in HIGH_RISK_CAPABILITIES
        assert ExtensionCapability.BROWSER in HIGH_RISK_CAPABILITIES
        assert ExtensionCapability.WEBHOOKS in HIGH_RISK_CAPABILITIES

    def test_high_risk_does_not_contain_safe_caps(self):
        assert ExtensionCapability.NETWORK_READ not in HIGH_RISK_CAPABILITIES
        assert ExtensionCapability.FILE_READ not in HIGH_RISK_CAPABILITIES
        assert ExtensionCapability.MEMORY_READ not in HIGH_RISK_CAPABILITIES
        assert ExtensionCapability.SYSTEM_INFO not in HIGH_RISK_CAPABILITIES

    def test_is_high_risk_method(self):
        sec = ExtensionSecurityManager(security_mode="standard")
        assert sec.is_high_risk(ExtensionCapability.SHELL_EXEC) is True
        assert sec.is_high_risk(ExtensionCapability.DESKTOP) is True
        assert sec.is_high_risk(ExtensionCapability.NETWORK_READ) is False


# ── WEBHOOKS Capability ───────────────────────────────────────────────────

class TestWebhooksCapability:

    def test_webhooks_enum_exists(self):
        cap = ExtensionCapability.WEBHOOKS
        assert cap.value == "webhooks"

    def test_standard_mode_requires_approval_for_webhooks(self):
        sec = ExtensionSecurityManager(security_mode="standard")
        assert sec.needs_approval("test-ext", ExtensionCapability.WEBHOOKS)
        assert not sec.is_allowed("test-ext", ExtensionCapability.WEBHOOKS)

    def test_open_mode_allows_webhooks(self):
        sec = ExtensionSecurityManager(security_mode="open")
        assert sec.is_allowed("test-ext", ExtensionCapability.WEBHOOKS)

    def test_secured_mode_denies_webhooks(self):
        sec = ExtensionSecurityManager(security_mode="secured")
        assert sec.is_denied("test-ext", ExtensionCapability.WEBHOOKS)

    def test_encrypted_mode_denies_webhooks(self):
        sec = ExtensionSecurityManager(security_mode="encrypted")
        assert sec.is_denied("test-ext", ExtensionCapability.WEBHOOKS)


# ── ExtensionSource ───────────────────────────────────────────────────────

class TestExtensionSource:

    def test_source_enum_values(self):
        assert ExtensionSource.BUILTIN.value == "builtin"
        assert ExtensionSource.CONFIG.value == "config"
        assert ExtensionSource.FILESYSTEM.value == "filesystem"
        assert ExtensionSource.PIP.value == "pip"


# ── Source Classification ─────────────────────────────────────────────────

class TestSourceClassification:

    def test_builtin_by_name(self):
        sec = ExtensionSecurityManager(security_mode="standard")
        for name in BUILTIN_EXTENSION_NAMES:
            assert sec.classify_source(name) == ExtensionSource.BUILTIN

    def test_builtin_by_path(self):
        sec = ExtensionSecurityManager(security_mode="standard")
        source = sec.classify_source(
            "custom-name",
            load_path="/path/to/antaris_agent/extensions/builtin/example_extension.py"
        )
        assert source == ExtensionSource.BUILTIN

    def test_core_extension_by_path(self):
        sec = ExtensionSecurityManager(security_mode="standard")
        source = sec.classify_source(
            "custom-name",
            load_path="/path/to/antaris_agent/extensions/desktop_control.py"
        )
        assert source == ExtensionSource.BUILTIN

    def test_unknown_extension_is_filesystem(self):
        sec = ExtensionSecurityManager(security_mode="standard")
        source = sec.classify_source("random-extension")
        assert source == ExtensionSource.FILESYSTEM

    def test_unknown_with_path(self):
        sec = ExtensionSecurityManager(security_mode="standard")
        source = sec.classify_source(
            "random-extension",
            load_path="/home/user/.antaris/extensions/random-extension/extension.py"
        )
        assert source == ExtensionSource.FILESYSTEM


# ── Allowlist ─────────────────────────────────────────────────────────────

class TestAllowlist:

    def test_empty_allowlist(self, tmp_path):
        al = ExtensionAllowlist(config_dir=str(tmp_path))
        assert al.is_approved("test-ext") is False
        assert al.list_entries() == []

    def test_approve_and_check(self, tmp_path):
        al = ExtensionAllowlist(config_dir=str(tmp_path))
        al.approve("test-ext", approved_by="user")
        assert al.is_approved("test-ext") is True
        assert al.is_approved("other-ext") is False

    def test_approve_with_capabilities(self, tmp_path):
        al = ExtensionAllowlist(config_dir=str(tmp_path))
        al.approve("test-ext", granted_capabilities=["shell.exec", "browser"])
        entry = al.get_entry("test-ext")
        assert entry is not None
        assert "shell.exec" in entry.granted_capabilities
        assert "browser" in entry.granted_capabilities

    def test_revoke(self, tmp_path):
        al = ExtensionAllowlist(config_dir=str(tmp_path))
        al.approve("test-ext")
        assert al.is_approved("test-ext") is True
        result = al.revoke("test-ext")
        assert result is True
        assert al.is_approved("test-ext") is False

    def test_revoke_nonexistent(self, tmp_path):
        al = ExtensionAllowlist(config_dir=str(tmp_path))
        assert al.revoke("nonexistent") is False

    def test_persistence(self, tmp_path):
        # Save
        al1 = ExtensionAllowlist(config_dir=str(tmp_path))
        al1.approve("test-ext", approved_by="admin", notes="For testing")
        
        # Load in new instance
        al2 = ExtensionAllowlist(config_dir=str(tmp_path))
        assert al2.is_approved("test-ext") is True
        entry = al2.get_entry("test-ext")
        assert entry.approved_by == "admin"
        assert entry.notes == "For testing"

    def test_file_created(self, tmp_path):
        al = ExtensionAllowlist(config_dir=str(tmp_path))
        al.approve("test-ext")
        assert (tmp_path / "extension_allowlist.json").exists()

    def test_list_entries(self, tmp_path):
        al = ExtensionAllowlist(config_dir=str(tmp_path))
        al.approve("ext-a", approved_by="user")
        al.approve("ext-b", approved_by="admin")
        entries = al.list_entries()
        assert len(entries) == 2
        names = {e.name for e in entries}
        assert names == {"ext-a", "ext-b"}


# ── Load Gating (can_load) ───────────────────────────────────────────────

class TestCanLoad:

    def test_open_mode_allows_everything(self):
        sec = ExtensionSecurityManager(security_mode="open")
        assert sec.can_load("any-ext", ExtensionSource.FILESYSTEM) is True
        assert sec.can_load("any-ext", ExtensionSource.PIP) is True

    def test_builtin_always_loads(self):
        for mode in ("standard", "sandboxed", "secured", "encrypted"):
            sec = ExtensionSecurityManager(security_mode=mode)
            assert sec.can_load("auth-monitor", ExtensionSource.BUILTIN) is True

    def test_config_always_loads(self):
        for mode in ("standard", "sandboxed", "secured", "encrypted"):
            sec = ExtensionSecurityManager(security_mode=mode)
            assert sec.can_load("custom-ext", ExtensionSource.CONFIG) is True

    def test_filesystem_blocked_without_allowlist(self):
        sec = ExtensionSecurityManager(security_mode="standard")
        assert sec.can_load("custom-ext", ExtensionSource.FILESYSTEM) is False

    def test_filesystem_allowed_with_allowlist(self, tmp_path):
        sec = ExtensionSecurityManager(security_mode="standard", config_dir=str(tmp_path))
        sec.allowlist.approve("custom-ext")
        assert sec.can_load("custom-ext", ExtensionSource.FILESYSTEM) is True

    def test_pip_blocked_without_allowlist(self):
        sec = ExtensionSecurityManager(security_mode="sandboxed")
        assert sec.can_load("pip-ext", ExtensionSource.PIP) is False

    def test_denial_reason_message(self):
        sec = ExtensionSecurityManager(security_mode="standard")
        reason = sec.get_load_denial_reason("bad-ext", ExtensionSource.FILESYSTEM)
        assert "allowlist" in reason.lower()
        assert "bad-ext" in reason

    def test_no_denial_for_allowed(self):
        sec = ExtensionSecurityManager(security_mode="open")
        reason = sec.get_load_denial_reason("any-ext", ExtensionSource.FILESYSTEM)
        assert reason == ""


# ── Policy with Allowlist Capabilities ────────────────────────────────────

class TestPolicyFromAllowlist:

    def test_allowlist_grants_extra_capabilities(self, tmp_path):
        sec = ExtensionSecurityManager(security_mode="standard", config_dir=str(tmp_path))
        sec.allowlist.approve("my-ext", granted_capabilities=["shell.exec", "browser"])
        
        policy = sec.get_policy("my-ext")
        assert ExtensionCapability.SHELL_EXEC in policy.allowed_capabilities
        assert ExtensionCapability.BROWSER in policy.allowed_capabilities
        # These should no longer require approval
        assert ExtensionCapability.SHELL_EXEC not in policy.requires_approval
        assert ExtensionCapability.BROWSER not in policy.requires_approval

    def test_policy_without_allowlist_keeps_defaults(self, tmp_path):
        sec = ExtensionSecurityManager(security_mode="standard", config_dir=str(tmp_path))
        policy = sec.get_policy("unapproved-ext")
        # Shell should still require approval
        assert ExtensionCapability.SHELL_EXEC in policy.requires_approval


# ── Mode Defaults (regression checks) ────────────────────────────────────

class TestModeDefaults:

    def test_standard_mode_allows_read_capabilities(self):
        sec = ExtensionSecurityManager(security_mode="standard")
        assert sec.is_allowed("test-ext", ExtensionCapability.NETWORK_READ)
        assert sec.is_allowed("test-ext", ExtensionCapability.FILE_READ)
        assert sec.is_allowed("test-ext", ExtensionCapability.MEMORY_READ)
        assert sec.is_allowed("test-ext", ExtensionCapability.SYSTEM_INFO)

    def test_standard_mode_requires_approval_for_high_risk(self):
        sec = ExtensionSecurityManager(security_mode="standard")
        for cap in HIGH_RISK_CAPABILITIES:
            assert not sec.is_allowed("test-ext", cap), \
                f"{cap} should NOT be auto-allowed in standard mode"

    def test_all_modes_gate_high_risk(self):
        """In every non-open mode, high-risk caps are never auto-allowed."""
        for mode in ("standard", "sandboxed", "secured", "encrypted"):
            sec = ExtensionSecurityManager(security_mode=mode)
            for cap in HIGH_RISK_CAPABILITIES:
                assert not sec.is_allowed("test-ext", cap), \
                    f"{cap} should not be auto-allowed in {mode} mode"

    def test_open_mode_allows_everything(self):
        sec = ExtensionSecurityManager(security_mode="open")
        for cap in ExtensionCapability:
            assert sec.is_allowed("test-ext", cap), \
                f"{cap} should be allowed in open mode"

    def test_encrypted_mode_nothing_auto_allowed(self):
        sec = ExtensionSecurityManager(security_mode="encrypted")
        for cap in ExtensionCapability:
            assert not sec.is_allowed("test-ext", cap), \
                f"{cap} should not be auto-allowed in encrypted mode"

    def test_sandboxed_denies_shell_and_desktop(self):
        sec = ExtensionSecurityManager(security_mode="sandboxed")
        assert sec.is_denied("test-ext", ExtensionCapability.SHELL_EXEC)
        assert sec.is_denied("test-ext", ExtensionCapability.DESKTOP)

    def test_webhooks_in_mode_defaults(self):
        """WEBHOOKS capability is properly gated in all mode defaults."""
        # standard: requires_approval
        assert ExtensionCapability.WEBHOOKS in _MODE_DEFAULTS["standard"]["requires_approval"]
        # sandboxed: requires_approval
        assert ExtensionCapability.WEBHOOKS in _MODE_DEFAULTS["sandboxed"]["requires_approval"]
        # secured: denied
        assert ExtensionCapability.WEBHOOKS in _MODE_DEFAULTS["secured"]["denied"]
        # encrypted: denied
        assert ExtensionCapability.WEBHOOKS in _MODE_DEFAULTS["encrypted"]["denied"]
        # open: allowed (all are)
        assert ExtensionCapability.WEBHOOKS in _MODE_DEFAULTS["open"]["allowed"]


# ── Grant / Deny ──────────────────────────────────────────────────────────

class TestGrantDeny:

    def test_grant_overrides_denial(self):
        sec = ExtensionSecurityManager(security_mode="sandboxed")
        assert sec.is_denied("test-ext", ExtensionCapability.SHELL_EXEC)
        sec.grant_capability("test-ext", ExtensionCapability.SHELL_EXEC)
        assert sec.is_allowed("test-ext", ExtensionCapability.SHELL_EXEC)

    def test_deny_overrides_grant(self):
        sec = ExtensionSecurityManager(security_mode="open")
        assert sec.is_allowed("test-ext", ExtensionCapability.BROWSER)
        sec.deny_capability("test-ext", ExtensionCapability.BROWSER)
        assert sec.is_denied("test-ext", ExtensionCapability.BROWSER)

    def test_per_extension_isolation(self):
        sec = ExtensionSecurityManager(security_mode="sandboxed")
        sec.grant_capability("ext-a", ExtensionCapability.SHELL_EXEC)
        assert sec.is_allowed("ext-a", ExtensionCapability.SHELL_EXEC)
        assert sec.is_denied("ext-b", ExtensionCapability.SHELL_EXEC)


# ── Status Text ───────────────────────────────────────────────────────────

class TestStatusText:

    def test_status_with_policies(self, tmp_path):
        sec = ExtensionSecurityManager(security_mode="standard", config_dir=str(tmp_path))
        sec.get_policy("builtin-ext", source=ExtensionSource.BUILTIN)
        sec.get_policy("third-party-ext", source=ExtensionSource.FILESYSTEM)
        
        text = sec.status_text()
        assert "standard" in text
        assert "builtin-ext" in text
        assert "third-party-ext" in text

    def test_status_empty(self):
        sec = ExtensionSecurityManager(security_mode="standard")
        text = sec.status_text()
        assert "No extension policies" in text

    def test_status_with_allowlist(self, tmp_path):
        sec = ExtensionSecurityManager(security_mode="standard", config_dir=str(tmp_path))
        sec.allowlist.approve("approved-ext")
        sec.get_policy("approved-ext")
        text = sec.status_text()
        assert "Allowlist" in text


# ── Manager Security Integration ─────────────────────────────────────────

class DummyExtension(Extension):
    name = "dummy"
    version = "1.0.0"
    
    async def on_load(self, ctx):
        pass


class UnapprovedExtension(Extension):
    name = "unapproved-third-party"
    version = "1.0.0"
    
    async def on_load(self, ctx):
        pass


class TestManagerSecurityIntegration:

    @pytest.mark.asyncio
    async def test_manager_blocks_unapproved_extension(self, tmp_path):
        """Extensions from filesystem are blocked if not allowlisted."""
        manager = ExtensionManager()
        
        ext = UnapprovedExtension()
        manager.register(ext, source=ExtensionSource.FILESYSTEM)
        
        # Create a mock bot with security manager in standard mode
        bot = MagicMock()
        bot.config = MagicMock()
        bot.config._extensions_config = {}
        bot.config.config_path = str(tmp_path / "config.json")
        bot.tool_registry = None
        bot.pipeline = MagicMock()
        bot.extension_security = ExtensionSecurityManager(
            security_mode="standard",
            config_dir=str(tmp_path),
        )
        
        results = await manager.load_all(bot)
        assert results.get("unapproved-third-party") is False
        assert manager._states["unapproved-third-party"] == ExtensionState.DISABLED

    @pytest.mark.asyncio
    async def test_manager_allows_approved_extension(self, tmp_path):
        """Allowlisted extensions from filesystem can load."""
        manager = ExtensionManager()
        
        ext = UnapprovedExtension()
        manager.register(ext, source=ExtensionSource.FILESYSTEM)
        
        bot = MagicMock()
        bot.config = MagicMock()
        bot.config._extensions_config = {}
        bot.config.config_path = str(tmp_path / "config.json")
        bot.tool_registry = None
        bot.pipeline = MagicMock()
        
        security = ExtensionSecurityManager(
            security_mode="standard",
            config_dir=str(tmp_path),
        )
        # Approve the extension
        security.allowlist.approve("unapproved-third-party")
        bot.extension_security = security
        
        results = await manager.load_all(bot)
        assert results.get("unapproved-third-party") is True

    @pytest.mark.asyncio
    async def test_manager_allows_builtin_without_allowlist(self, tmp_path):
        """Builtin extensions load without needing allowlist."""
        manager = ExtensionManager()
        
        ext = DummyExtension()
        ext.name = "auth-monitor"  # A known builtin name
        manager.register(ext, source=ExtensionSource.BUILTIN)
        
        bot = MagicMock()
        bot.config = MagicMock()
        bot.config._extensions_config = {}
        bot.config.config_path = str(tmp_path / "config.json")
        bot.tool_registry = None
        bot.pipeline = MagicMock()
        bot.extension_security = ExtensionSecurityManager(
            security_mode="secured",
            config_dir=str(tmp_path),
        )
        
        results = await manager.load_all(bot)
        assert results.get("auth-monitor") is True

    @pytest.mark.asyncio
    async def test_manager_no_security_allows_all(self, tmp_path):
        """Without a security manager on the bot, all extensions load."""
        manager = ExtensionManager()
        
        ext = DummyExtension()
        manager.register(ext)
        
        bot = MagicMock()
        bot.config = MagicMock()
        bot.config._extensions_config = {}
        bot.config.config_path = str(tmp_path / "config.json")
        bot.tool_registry = None
        bot.pipeline = MagicMock()
        # No extension_security attribute
        del bot.extension_security
        
        results = await manager.load_all(bot)
        assert results.get("dummy") is True

    @pytest.mark.asyncio
    async def test_manager_open_mode_allows_all(self, tmp_path):
        """In open mode, everything loads regardless of source."""
        manager = ExtensionManager()
        
        ext = UnapprovedExtension()
        manager.register(ext, source=ExtensionSource.FILESYSTEM)
        
        bot = MagicMock()
        bot.config = MagicMock()
        bot.config._extensions_config = {}
        bot.config.config_path = str(tmp_path / "config.json")
        bot.tool_registry = None
        bot.pipeline = MagicMock()
        bot.extension_security = ExtensionSecurityManager(
            security_mode="open",
            config_dir=str(tmp_path),
        )
        
        results = await manager.load_all(bot)
        assert results.get("unapproved-third-party") is True


# ── Extension Capabilities Declaration ────────────────────────────────────

class TestExtensionCapabilitiesDeclaration:

    def test_extension_has_capabilities_attr(self):
        ext = DummyExtension()
        assert hasattr(ext, 'capabilities')
        assert ext.capabilities == []

    def test_desktop_control_declares_capabilities(self):
        from antaris_agent.extensions.desktop_control import DesktopControlExtension
        ext = DesktopControlExtension()
        assert "shell.exec" in ext.capabilities
        assert "desktop" in ext.capabilities
        assert "browser" in ext.capabilities


# ── BUILTIN_EXTENSION_NAMES ──────────────────────────────────────────────

class TestBuiltinNames:

    def test_known_builtins(self):
        assert "example" in BUILTIN_EXTENSION_NAMES
        assert "auth-monitor" in BUILTIN_EXTENSION_NAMES
        assert "model-control" in BUILTIN_EXTENSION_NAMES
        assert "desktop-control" in BUILTIN_EXTENSION_NAMES

    def test_random_not_builtin(self):
        assert "random-extension" not in BUILTIN_EXTENSION_NAMES
