"""
Tests for DiscordBridge.
"""

import pytest
import asyncio
from unittest.mock import Mock, AsyncMock, MagicMock
from datetime import datetime, timezone
discord = pytest.importorskip("discord")
from antaris_agent.channels.discord_bridge import DiscordBridge


class MockDiscordMessage:
    """Mock Discord message for testing"""
    def __init__(
        self, 
        id="123456789",
        content="Test message content", 
        author_id="987654321",
        author_name="TestUser",
        channel_id="555666777",
        channel_name="test-channel",
        is_bot=False,
        created_at=None
    ):
        self.id = id
        self.content = content
        self.created_at = created_at or datetime.now(timezone.utc)
        
        self.author = Mock()
        self.author.id = author_id
        self.author.display_name = author_name
        self.author.bot = is_bot
        
        self.channel = Mock()
        self.channel.id = channel_id
        self.channel.name = channel_name


class MockMemory:
    """Mock BotMemory for testing"""
    def __init__(self):
        self.ingest = AsyncMock()


@pytest.fixture
def mock_memory():
    return MockMemory()


@pytest.fixture
def discord_bridge(mock_memory):
    return DiscordBridge(
        memory=mock_memory,
        bridge_enabled=True,
        bridge_channels=["555666777"],
        bot_user_id="111222333"
    )


def test_discord_bridge_init(discord_bridge, mock_memory):
    """Test DiscordBridge initialization"""
    assert discord_bridge.memory == mock_memory
    assert discord_bridge.enabled is True
    assert "555666777" in discord_bridge.bridge_channels
    assert discord_bridge.bot_user_id == "111222333"
    assert len(discord_bridge._ingested_message_ids) == 0


def test_discord_bridge_disabled():
    """Test DiscordBridge when disabled"""
    mock_memory = MockMemory()
    bridge = DiscordBridge(mock_memory, bridge_enabled=False)
    
    assert bridge.enabled is False


def test_should_ingest_disabled(discord_bridge):
    """Test should_ingest() when bridge is disabled"""
    discord_bridge.enabled = False
    message = MockDiscordMessage()
    
    assert discord_bridge.should_ingest(message) is False


def test_should_ingest_none_author(discord_bridge):
    """Test should_ingest() handles None author edge case"""
    message = MockDiscordMessage()
    message.author = None  # Edge case
    
    assert discord_bridge.should_ingest(message) is False


def test_should_ingest_bot_message(discord_bridge):
    """Test should_ingest() filters out bot's own messages"""
    message = MockDiscordMessage(author_id="111222333")  # Same as bot_user_id
    
    assert discord_bridge.should_ingest(message) is False


def test_should_ingest_other_bots(discord_bridge):
    """Test should_ingest() filters out other bot messages"""
    message = MockDiscordMessage(is_bot=True)
    
    assert discord_bridge.should_ingest(message) is False


def test_should_ingest_wrong_channel(discord_bridge):
    """Test should_ingest() filters out messages from non-bridge channels"""
    message = MockDiscordMessage(channel_id="999888777")  # Not in bridge_channels
    
    assert discord_bridge.should_ingest(message) is False


def test_should_ingest_none_content(discord_bridge):
    """Test should_ingest() handles None content edge case"""
    message = MockDiscordMessage()
    message.content = None  # Edge case
    
    assert discord_bridge.should_ingest(message) is False


def test_should_ingest_short_message(discord_bridge):
    """Test should_ingest() filters out short messages"""
    message = MockDiscordMessage(content="hi")  # Too short
    
    assert discord_bridge.should_ingest(message) is False


def test_should_ingest_command_message(discord_bridge):
    """Test should_ingest() filters out bot commands"""
    message = MockDiscordMessage(content="!help me with something")
    
    assert discord_bridge.should_ingest(message) is False


def test_should_ingest_already_ingested(discord_bridge):
    """Test should_ingest() filters out already ingested messages"""
    message = MockDiscordMessage(id="123456789")
    discord_bridge._ingested_message_ids.append("123456789")
    
    assert discord_bridge.should_ingest(message) is False


def test_should_ingest_valid_message(discord_bridge):
    """Test should_ingest() accepts valid messages"""
    message = MockDiscordMessage(
        content="This is a valid message with enough content to be ingested"
    )
    
    assert discord_bridge.should_ingest(message) is True


def test_should_ingest_all_channels(mock_memory):
    """Test should_ingest() with empty bridge_channels (all channels)"""
    bridge = DiscordBridge(
        memory=mock_memory,
        bridge_enabled=True,
        bridge_channels=[],  # Empty = all channels
        bot_user_id="111222333"
    )
    
    message = MockDiscordMessage(
        content="This message should be ingested from any channel",
        channel_id="999888777"  # Different channel, but should work
    )
    
    assert bridge.should_ingest(message) is True


@pytest.mark.asyncio
async def test_ingest_message_invalid(discord_bridge):
    """Test ingest_message() with invalid message"""
    message = MockDiscordMessage(content="hi")  # Too short
    
    result = await discord_bridge.ingest_message(message)
    
    assert result is False
    discord_bridge.memory.ingest.assert_not_called()


@pytest.mark.asyncio
async def test_ingest_message_valid(discord_bridge):
    """Test ingest_message() with valid message"""
    message = MockDiscordMessage(
        id="123456789",
        content="This is a test message that should be ingested properly",
        author_id="987654321",
        author_name="TestUser",
        channel_id="555666777",
        channel_name="test-channel"
    )
    
    result = await discord_bridge.ingest_message(message)
    
    assert result is True
    discord_bridge.memory.ingest.assert_called_once()
    
    # Check the call arguments
    call_kwargs = discord_bridge.memory.ingest.call_args[1]
    
    assert "session_id" in call_kwargs
    assert "channel_id" in call_kwargs
    assert "metadata" not in call_kwargs
    
    assert call_kwargs["user_id"] == "987654321"
    assert "[TestUser]" in call_kwargs["user_message"]
    assert "This is a test message" in call_kwargs["user_message"]
    assert "TestUser" in call_kwargs["bot_response"]
    assert "#test-channel" in call_kwargs["bot_response"]
    assert call_kwargs["session_id"] == "discord_bridge_555666777"
    assert call_kwargs["channel_id"] == "555666777"


@pytest.mark.asyncio
async def test_ingest_message_deduplication(discord_bridge):
    """Test ingest_message() tracks message IDs for deduplication"""
    message = MockDiscordMessage(
        id="123456789",
        content="This message should be tracked for deduplication"
    )
    
    result = await discord_bridge.ingest_message(message)
    
    assert result is True
    assert "123456789" in discord_bridge._ingested_message_ids


@pytest.mark.asyncio
async def test_ingest_message_long_content(discord_bridge):
    """Test ingest_message() truncates long content in bot_response"""
    long_content = "A" * 200  # Very long message
    message = MockDiscordMessage(content=long_content)
    
    result = await discord_bridge.ingest_message(message)
    
    assert result is True
    
    # Check that bot_response was truncated
    call_kwargs = discord_bridge.memory.ingest.call_args[1]
    bot_response = call_kwargs["bot_response"]
    assert "..." in bot_response  # Should be truncated


@pytest.mark.asyncio
async def test_ingest_message_searchable_format(discord_bridge):
    """Test ingest_message() creates searchable bot_response format"""
    message = MockDiscordMessage(
        content="Can you help me with my Python project?",
        author_name="DevUser", 
        channel_name="programming"
    )
    
    result = await discord_bridge.ingest_message(message)
    
    assert result is True
    
    # Verify bot_response is formatted for searchability
    call_kwargs = discord_bridge.memory.ingest.call_args[1]
    bot_response = call_kwargs["bot_response"]
    
    # Should contain author, channel, and content snippet
    assert "DevUser" in bot_response
    assert "#programming" in bot_response
    assert "Can you help me with my Python project?" in bot_response


@pytest.mark.asyncio
async def test_ingest_message_memory_error(discord_bridge):
    """Test ingest_message() handles memory errors gracefully"""
    discord_bridge.memory.ingest.side_effect = Exception("Memory error")
    
    message = MockDiscordMessage(
        content="This message ingestion will fail due to memory error"
    )
    
    result = await discord_bridge.ingest_message(message)
    
    assert result is False


@pytest.mark.asyncio
async def test_ingest_message_none_content_handling(discord_bridge):
    """Test ingest_message() handles None content gracefully"""
    message = MockDiscordMessage()
    message.content = None
    
    # Should be filtered out by should_ingest, but test handles it if it gets through
    result = await discord_bridge.ingest_message(message)
    
    assert result is False


@pytest.mark.asyncio
async def test_ingest_message_dedup_size_limit(discord_bridge):
    """Test that deduplication deque maintains max size automatically"""
    # Fill up to max size
    for i in range(1000):
        discord_bridge._ingested_message_ids.append(str(i))
    
    # Add one more via ingest_message - deque should automatically evict oldest
    message = MockDiscordMessage(
        id="1001",
        content="This message should trigger dedup automatic size management"
    )
    
    result = await discord_bridge.ingest_message(message)
    
    assert result is True
    # Should maintain maxlen of 1000
    assert len(discord_bridge._ingested_message_ids) == 1000


def test_update_config(discord_bridge):
    """Test update_config() method"""
    discord_bridge.update_config(
        bridge_enabled=False,
        bridge_channels=["111222333", "444555666"]
    )
    
    assert discord_bridge.enabled is False
    assert "111222333" in discord_bridge.bridge_channels
    assert "444555666" in discord_bridge.bridge_channels


def test_update_config_partial(discord_bridge):
    """Test update_config() with partial updates"""
    discord_bridge.update_config(bridge_enabled=False)
    
    assert discord_bridge.enabled is False
    # Original bridge_channels should be unchanged
    assert "555666777" in discord_bridge.bridge_channels


def test_get_stats(discord_bridge):
    """Test get_stats() method"""
    discord_bridge._ingested_message_ids.append("123")
    discord_bridge._ingested_message_ids.append("456")
    
    stats = discord_bridge.get_stats()
    
    assert stats["enabled"] is True
    assert stats["bridge_channels"] == ["555666777"]
    assert stats["ingested_message_count"] == 2
    assert stats["bot_user_id"] == "111222333"


@pytest.mark.asyncio
async def test_end_to_end_workflow(mock_memory):
    """Test complete workflow from message to ingestion"""
    bridge = DiscordBridge(
        memory=mock_memory,
        bridge_enabled=True,
        bridge_channels=["555666777"],
        bot_user_id="111222333"
    )
    
    # Valid message
    message1 = MockDiscordMessage(
        id="msg1",
        content="This is a valid message to ingest",
        author_id="user1",
        channel_id="555666777"
    )
    
    # Invalid message (too short)
    message2 = MockDiscordMessage(
        id="msg2", 
        content="hi",
        author_id="user1",
        channel_id="555666777"
    )
    
    # Bot message (should be filtered)
    message3 = MockDiscordMessage(
        id="msg3",
        content="I am a bot message that should be filtered",
        author_id="111222333",  # Same as bot_user_id
        channel_id="555666777"
    )
    
    result1 = await bridge.ingest_message(message1)
    result2 = await bridge.ingest_message(message2)
    result3 = await bridge.ingest_message(message3)
    
    assert result1 is True   # Valid message ingested
    assert result2 is False  # Short message filtered
    assert result3 is False  # Bot message filtered
    
    # Only valid message should be ingested
    assert mock_memory.ingest.call_count == 1
    
    # Stats should reflect one ingested message
    stats = bridge.get_stats()
    assert stats["ingested_message_count"] == 1