"""
tests/test_memory.py

Tests for BotMemory wrapper around parsica-memory.
"""

import asyncio
import pytest
import tempfile
import os
from pathlib import Path

# Suppress GC-triggered "coroutine never awaited" warnings that leak from
# prior test modules' AsyncMock objects being collected during our MemorySystem
# load/save calls.  This is a test-isolation artifact, not a real issue.
pytestmark = pytest.mark.filterwarnings("ignore::RuntimeWarning")

from antaris_agent.core.memory import MEMORY_SOURCE_OF_TRUTH_NOTE


def _run(coro):
    """Helper: run a coroutine in tests without pytest-asyncio."""
    return asyncio.run(coro)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def tmp_store(tmp_path):
    """Return a temporary directory path for memory store."""
    store_dir = tmp_path / "memory_store"
    return str(store_dir)


@pytest.fixture
def bot_memory(tmp_store):
    """Return a BotMemory instance backed by a temp directory."""
    from antaris_agent.core.memory import BotMemory
    return BotMemory(store_path=tmp_store, search_limit=5, min_relevance=0.1)


# ---------------------------------------------------------------------------
# Initialization tests
# ---------------------------------------------------------------------------

class TestBotMemoryInit:
    def test_source_of_truth_note_mentions_bundled_runtime(self):
        assert "bundled parsica_memory" in MEMORY_SOURCE_OF_TRUTH_NOTE
        assert "separately installed" in MEMORY_SOURCE_OF_TRUTH_NOTE

    def test_initializes_correctly(self, tmp_store):
        """BotMemory initialises without raising."""
        from antaris_agent.core.memory import BotMemory
        mem = BotMemory(store_path=tmp_store)
        assert mem is not None

    def test_store_path_created(self, tmp_store):
        """Root store directory is created on init."""
        from antaris_agent.core.memory import BotMemory
        assert not os.path.exists(tmp_store)
        BotMemory(store_path=tmp_store)
        assert os.path.isdir(tmp_store)

    def test_default_params(self, tmp_store):
        """Default search_limit and min_relevance are set."""
        from antaris_agent.core.memory import BotMemory
        mem = BotMemory(store_path=tmp_store)
        assert mem.search_limit == 10
        assert mem.min_relevance == 0.3

    def test_custom_params(self, tmp_store):
        """Custom search_limit and min_relevance are stored."""
        from antaris_agent.core.memory import BotMemory
        mem = BotMemory(store_path=tmp_store, search_limit=7, min_relevance=0.5)
        assert mem.search_limit == 7
        assert mem.min_relevance == 0.5

    def test_stores_dict_starts_empty(self, bot_memory):
        """Internal store cache starts empty."""
        assert bot_memory._stores == {}


# ---------------------------------------------------------------------------
# User-scoped directory tests
# ---------------------------------------------------------------------------

class TestUserScopedDirectories:
    def test_user_directory_created_on_first_access(self, bot_memory, tmp_store):
        """Getting a store for a user creates a subdirectory."""
        user_id = "user_alice"
        bot_memory._get_store(user_id)
        # user_id is normalized (slug + hash), so check via _user_store_path
        expected = bot_memory._user_store_path(user_id)
        assert expected.is_dir()

    def test_two_users_get_separate_directories(self, bot_memory, tmp_store):
        """Two different users get separate memory directories."""
        bot_memory._get_store("alice")
        bot_memory._get_store("bob")
        assert bot_memory._user_store_path("alice").is_dir()
        assert bot_memory._user_store_path("bob").is_dir()
        # They must be different directories
        assert bot_memory._user_store_path("alice") != bot_memory._user_store_path("bob")

    def test_store_is_cached_after_first_access(self, bot_memory):
        """Calling _get_store twice returns the same object."""
        store1 = bot_memory._get_store("user_x")
        store2 = bot_memory._get_store("user_x")
        assert store1 is store2

    def test_stores_dict_tracks_users(self, bot_memory):
        """Internal _stores dict tracks initialized users."""
        bot_memory._get_store("alpha")
        bot_memory._get_store("beta")
        assert "alpha" in bot_memory._stores
        assert "beta" in bot_memory._stores


# ---------------------------------------------------------------------------
# Stats tests
# ---------------------------------------------------------------------------

class TestStats:
    def test_stats_returns_dict(self, bot_memory):
        """stats() returns a dict."""
        result = bot_memory.stats()
        assert isinstance(result, dict)

    def test_stats_aggregate_has_expected_keys(self, bot_memory):
        """Aggregate stats has users, user_count, total_entries."""
        result = bot_memory.stats()
        assert "users" in result
        assert "user_count" in result
        assert "total_entries" in result

    def test_stats_for_known_user_returns_dict(self, bot_memory):
        """Per-user stats returns a dict."""
        bot_memory._get_store("user_stats_test")
        result = bot_memory.stats(user_id="user_stats_test")
        assert isinstance(result, dict)
        assert "entry_count" in result
        assert "user_id" in result

    def test_stats_entry_count_is_int(self, bot_memory):
        """entry_count in per-user stats is an int."""
        bot_memory._get_store("user_count_test")
        result = bot_memory.stats(user_id="user_count_test")
        assert isinstance(result["entry_count"], int)


# ---------------------------------------------------------------------------
# Recall graceful-failure tests
# ---------------------------------------------------------------------------

class TestRecallGracefulFailure:
    def test_recall_returns_list(self, bot_memory):
        """recall() returns a list (even when empty)."""
        result = _run(bot_memory.recall("user_recall", "test query"))
        assert isinstance(result, list)

    def test_recall_does_not_raise_on_unknown_user(self, bot_memory):
        """recall() does not raise for a brand-new user."""
        # Should not raise — returns empty or whatever memories exist
        result = _run(bot_memory.recall("totally_new_user_xyz", "something"))
        assert isinstance(result, list)

    def test_recall_returns_strings(self, bot_memory):
        """recall() returns a list of strings."""
        # Ingest a fact first so there's something to recall
        _run(bot_memory.ingest(
            "user_recall_type_test",
            "My favourite colour is blue.",
            "Great choice!"
        ))
        results = _run(bot_memory.recall("user_recall_type_test", "colour"))
        assert all(isinstance(s, str) for s in results)

    def test_recall_failure_returns_empty_list_not_exception(self, bot_memory, monkeypatch):
        """
        If the underlying search raises, recall() returns [] not an exception.
        This validates the try/except safety net.
        """
        # Patch _get_store to raise
        def exploding_get_store(user_id):
            raise RuntimeError("simulated store failure")

        monkeypatch.setattr(bot_memory, "_get_store", exploding_get_store)
        result = _run(bot_memory.recall("any_user", "any query"))
        assert result == []


# ---------------------------------------------------------------------------
# Ingest + recall round-trip (integration smoke test)
# ---------------------------------------------------------------------------

class TestIngestRecallRoundTrip:
    def test_ingest_then_recall(self, bot_memory):
        """Ingested content is retrievable via recall."""
        user_id = "test_roundtrip_user"
        _run(bot_memory.ingest(user_id, "I love Python programming.", "Python is great!"))
        results = _run(bot_memory.recall(user_id, "Python"))
        # May be empty if relevance threshold isn't met, but should not raise
        assert isinstance(results, list)

    def test_ingest_does_not_raise(self, bot_memory):
        """ingest() completes without raising."""
        _run(bot_memory.ingest(
            "ingest_test_user",
            "Hello world",
            "Hi there!"
        ))

    def test_search_returns_list_of_dicts(self, bot_memory):
        """search() returns a list of dicts with metadata."""
        bot_memory._get_store("search_test_user")
        results = bot_memory.search("search_test_user", "anything")
        assert isinstance(results, list)
        for item in results:
            assert isinstance(item, dict)



