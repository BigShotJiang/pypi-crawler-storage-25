import base64
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest

from antaris_agent.llm.base import LLMResponse, Message
from antaris_agent.llm.dispatcher import LLMDispatcher
from antaris_agent.llm.google import GoogleProvider, _to_gemini_parts
from antaris_agent.tools.native.image import ImageTool
from antaris_agent.tools.native.video import VideoTool


@pytest.mark.asyncio
async def test_image_tool_uses_local_file_mime_type(tmp_path):
    img_path = tmp_path / "sample.png"
    img_path.write_bytes(b"fake-png")

    provider = MagicMock()
    provider.complete = AsyncMock(
        return_value=LLMResponse(content="ok", model="m", input_tokens=1, output_tokens=1, cost_usd=0)
    )
    dispatcher = MagicMock()
    dispatcher.providers = {"openai": provider}

    tool = ImageTool(dispatcher)
    result = await tool.execute({"image_path": str(img_path), "prompt": "describe"})

    assert result.success is True
    sent_messages = provider.complete.call_args.kwargs["messages"]
    source = sent_messages[0]["content"][1]["source"]
    assert source["media_type"] == "image/png"


@pytest.mark.asyncio
async def test_image_tool_uses_remote_content_type():
    provider = MagicMock()
    provider.complete = AsyncMock(
        return_value=LLMResponse(content="ok", model="m", input_tokens=1, output_tokens=1, cost_usd=0)
    )
    dispatcher = MagicMock()
    dispatcher.providers = {"openai": provider}

    tool = ImageTool(dispatcher)

    response = MagicMock()
    response.content = b"gif-bytes"
    response.headers = {"content-type": "image/gif; charset=binary"}
    response.raise_for_status = MagicMock()

    mock_client = MagicMock()
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=False)
    mock_client.get = AsyncMock(return_value=response)

    import antaris_agent.tools.native.image as image_mod

    original = image_mod.httpx.AsyncClient
    image_mod.httpx.AsyncClient = MagicMock(return_value=mock_client)
    try:
        result = await tool.execute({"image_url": "https://example.com/test.gif"})
    finally:
        image_mod.httpx.AsyncClient = original

    assert result.success is True
    sent_messages = provider.complete.call_args.kwargs["messages"]
    source = sent_messages[0]["content"][1]["source"]
    assert source["media_type"] == "image/gif"


@pytest.mark.asyncio
async def test_dispatcher_cross_provider_failover_remaps_model_to_fallback_default(tmp_path):
    dispatcher = LLMDispatcher()

    primary = MagicMock()
    primary.complete = AsyncMock(side_effect=RuntimeError("rate_limit:30"))

    fallback_response = LLMResponse(content="fallback", model="gemini-2.0-flash", input_tokens=1, output_tokens=1, cost_usd=0)
    fallback = MagicMock()
    fallback.model = "gemini-2.0-flash"
    fallback.complete = AsyncMock(return_value=fallback_response)

    dispatcher.register("anthropic", primary)
    dispatcher.register("google", fallback)

    from antaris_agent.extensions.auth_monitor import AuthMonitor
    monitor = AuthMonitor(config_dir=str(tmp_path))
    monitor.record_call("anthropic", success=True)
    monitor.record_call("google", success=True)
    dispatcher.set_auth_monitor(monitor)

    result = await dispatcher.complete(
        provider="anthropic",
        model="claude-sonnet-4-6",
        messages=[Message(role="user", content="hi")],
        system="sys",
    )

    assert result.content == "fallback"
    assert fallback.complete.call_args.kwargs["model"] == "gemini-2.0-flash"


def test_gemini_parts_renders_tool_use_and_list_tool_result_safely():
    parts = _to_gemini_parts([
        {"type": "tool_use", "name": "weather", "input": {"city": "LA"}},
        {"type": "tool_result", "content": [{"type": "text", "text": "72F"}]},
    ])

    assert "weather" in parts[0]["text"]
    assert "LA" in parts[0]["text"]
    assert parts[1] == {"text": "72F"}


@pytest.mark.asyncio
async def test_google_provider_parses_function_call_as_tool_use():
    provider = GoogleProvider(api_key="test", model="gemini-2.0-flash")

    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.raise_for_status = MagicMock()
    mock_response.json.return_value = {
        "candidates": [{
            "content": {
                "parts": [
                    {"functionCall": {"name": "weather", "args": {"city": "LA"}}}
                ]
            }
        }],
        "usageMetadata": {"promptTokenCount": 1, "candidatesTokenCount": 1},
    }
    provider._client = MagicMock()
    provider._client.post = AsyncMock(return_value=mock_response)

    response = await provider.complete(
        messages=[Message(role="user", content="weather?")],
        system="sys",
        tools=[{"name": "weather", "description": "Weather tool", "input_schema": {"type": "object", "properties": {"city": {"type": "string"}}}}],
    )

    assert response.tool_use is not None
    assert response.tool_use[0]["name"] == "weather"
    assert response.tool_use[0]["input"] == {"city": "LA"}


def test_video_tool_prefers_multimodal_provider_order(tmp_path):
    dispatcher = MagicMock()
    dispatcher.providers = {
        "ollama": object(),
        "google": object(),
        "openai": object(),
    }
    tool = VideoTool(dispatcher, str(tmp_path))

    assert tool._select_multimodal_provider(dispatcher.providers) is dispatcher.providers["openai"]
    assert tool._select_text_provider(dispatcher.providers) is dispatcher.providers["openai"]
