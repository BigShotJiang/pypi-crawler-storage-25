"""
Tests for FocusManager, FocusSession, and focus command integration.
"""
import asyncio
import time
import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from antaris_agent.core.focus import FocusManager, FocusSession, parse_duration_minutes
from antaris_agent.channels.base import InboundMessage
from antaris_agent.core.commands import CommandDispatcher


# ── Helpers ─────────────────────────────────────────────────────────────────

def make_inbound(text="Hello", user_id="user-42"):
    return InboundMessage(
        id="msg-1",
        user_id=user_id,
        user_name="TestUser",
        channel_id="ch-1",
        platform="terminal",
        text=text,
        timestamp_ms=0,
    )


def make_bot_with_focus():
    bot = MagicMock()
    bot.memory.stats.return_value = {"total": 0}
    bot.config.model = "claude-sonnet-4-6"
    bot.config.provider_name = "anthropic"
    bot.config.guard_mode = "monitor"
    bot.config.security_mode = "sandboxed"
    bot.dispatcher.providers = {}
    bot.router = None
    bot.focus = FocusManager()
    return bot


# ── FocusSession tests ───────────────────────────────────────────────────────

def test_focus_session_not_expired_when_indefinite():
    session = FocusSession(
        topic="antaris-agent",
        user_id="u1",
        started_at=time.time() - 9999,
        duration_seconds=0,
    )
    assert session.is_expired is False


def test_focus_session_not_expired_when_fresh():
    session = FocusSession(
        topic="myproject",
        user_id="u1",
        started_at=time.time(),
        duration_seconds=3600,
    )
    assert session.is_expired is False


def test_focus_session_expired_when_past_duration():
    session = FocusSession(
        topic="myproject",
        user_id="u1",
        started_at=time.time() - 7200,  # 2 hours ago
        duration_seconds=3600,           # 1 hour duration
    )
    assert session.is_expired is True


def test_focus_session_remaining_minutes_indefinite():
    session = FocusSession(
        topic="antaris-agent",
        user_id="u1",
        started_at=time.time(),
        duration_seconds=0,
    )
    assert session.remaining_minutes == -1


def test_focus_session_remaining_minutes_positive():
    session = FocusSession(
        topic="myproject",
        user_id="u1",
        started_at=time.time(),
        duration_seconds=3600,  # 1 hour
    )
    # Should be close to 59 or 60 minutes
    assert 58 <= session.remaining_minutes <= 60


def test_focus_session_remaining_minutes_zero_when_expired():
    session = FocusSession(
        topic="myproject",
        user_id="u1",
        started_at=time.time() - 7200,
        duration_seconds=3600,
    )
    assert session.remaining_minutes == 0


# ── FocusManager tests ───────────────────────────────────────────────────────

def test_focus_manager_start_returns_session():
    fm = FocusManager()
    session = fm.start("user1", "antaris-agent", 60)
    assert isinstance(session, FocusSession)
    assert session.topic == "antaris-agent"
    assert session.user_id == "user1"
    assert session.duration_seconds == 3600


def test_focus_manager_start_indefinite():
    fm = FocusManager()
    session = fm.start("user1", "myproject", 0)
    assert session.duration_seconds == 0
    assert session.is_expired is False


def test_focus_manager_get_returns_active_session():
    fm = FocusManager()
    fm.start("user1", "antaris-agent", 60)
    session = fm.get("user1")
    assert session is not None
    assert session.topic == "antaris-agent"


def test_focus_manager_get_returns_none_for_unknown_user():
    fm = FocusManager()
    assert fm.get("no-such-user") is None


def test_focus_manager_stop_returns_true_when_active():
    fm = FocusManager()
    fm.start("user1", "myproject", 30)
    result = fm.stop("user1")
    assert result is True


def test_focus_manager_stop_returns_false_when_not_active():
    fm = FocusManager()
    result = fm.stop("user1")
    assert result is False


def test_focus_manager_stop_clears_session():
    fm = FocusManager()
    fm.start("user1", "myproject", 30)
    fm.stop("user1")
    assert fm.get("user1") is None


def test_focus_manager_auto_expires_session():
    fm = FocusManager()
    # Manually insert an already-expired session
    fm._sessions["user1"] = FocusSession(
        topic="old",
        user_id="user1",
        started_at=time.time() - 7200,
        duration_seconds=3600,
    )
    session = fm.get("user1")
    assert session is None
    assert "user1" not in fm._sessions


def test_focus_manager_sessions_are_per_user():
    fm = FocusManager()
    fm.start("alice", "project-a", 30)
    fm.start("bob", "project-b", 60)
    assert fm.get("alice").topic == "project-a"
    assert fm.get("bob").topic == "project-b"


def test_focus_manager_start_overwrites_previous_session():
    fm = FocusManager()
    fm.start("user1", "old-topic", 30)
    fm.start("user1", "new-topic", 60)
    session = fm.get("user1")
    assert session.topic == "new-topic"
    assert session.duration_seconds == 3600


# ── get_context tests ────────────────────────────────────────────────────────

def test_get_context_returns_empty_when_no_focus():
    fm = FocusManager()
    assert fm.get_context("user1") == ""


def test_get_context_returns_empty_after_stop():
    fm = FocusManager()
    fm.start("user1", "myproject", 30)
    fm.stop("user1")
    assert fm.get_context("user1") == ""


def test_get_context_returns_formatted_string():
    fm = FocusManager()
    fm.start("user1", "antaris-agent", 60)
    ctx = fm.get_context("user1")
    assert "FOCUS MODE ACTIVE" in ctx
    assert "antaris-agent" in ctx
    assert "remaining" in ctx


def test_get_context_indefinite_shows_no_time_limit():
    fm = FocusManager()
    fm.start("user1", "myproject", 0)
    ctx = fm.get_context("user1")
    assert "no time limit" in ctx
    assert "myproject" in ctx


def test_get_context_empty_when_expired():
    fm = FocusManager()
    fm._sessions["user1"] = FocusSession(
        topic="expired",
        user_id="user1",
        started_at=time.time() - 7200,
        duration_seconds=3600,
    )
    assert fm.get_context("user1") == ""


# ── parse_duration_minutes tests ─────────────────────────────────────────────

def test_parse_duration_1h():
    assert parse_duration_minutes("1h") == 60


def test_parse_duration_2h():
    assert parse_duration_minutes("2h") == 120


def test_parse_duration_30m():
    assert parse_duration_minutes("30m") == 30


def test_parse_duration_90m():
    assert parse_duration_minutes("90m") == 90


def test_parse_duration_bare_int():
    assert parse_duration_minutes("45") == 45


def test_parse_duration_empty_returns_none():
    assert parse_duration_minutes("") is None


def test_parse_duration_invalid_returns_none():
    assert parse_duration_minutes("abc") is None


def test_parse_duration_invalid_h_returns_none():
    assert parse_duration_minutes("abch") is None


def test_parse_duration_invalid_m_returns_none():
    assert parse_duration_minutes("xm") is None


def test_parse_duration_strips_whitespace():
    assert parse_duration_minutes("  1h  ") == 60


# ── !focus command tests ─────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_focus_command_no_focus_manager():
    """!focus without a focus manager on bot returns unavailable message."""
    bot = MagicMock()
    bot.memory.stats.return_value = {"total": 0}
    bot.config.model = "claude-sonnet-4-6"
    bot.config.provider_name = "anthropic"
    bot.config.guard_mode = "monitor"
    bot.config.security_mode = "sandboxed"
    bot.dispatcher.providers = {}
    bot.router = None
    bot.focus = None  # explicitly None

    dispatcher = CommandDispatcher(bot)
    result = await dispatcher.dispatch(make_inbound("!focus antaris-agent 1h"))
    assert result.handled is True
    assert "not available" in result.response.lower()


@pytest.mark.asyncio
async def test_focus_command_starts_focus():
    bot = make_bot_with_focus()
    dispatcher = CommandDispatcher(bot)
    result = await dispatcher.dispatch(make_inbound("!focus antaris-agent 1h"))
    assert result.handled is True
    assert "antaris-agent" in result.response
    session = bot.focus.get("user-42")
    assert session is not None
    assert session.topic == "antaris-agent"
    assert session.duration_seconds == 3600


@pytest.mark.asyncio
async def test_focus_command_30m():
    bot = make_bot_with_focus()
    dispatcher = CommandDispatcher(bot)
    result = await dispatcher.dispatch(make_inbound("!focus myproject 30m", user_id="u1"))
    assert result.handled is True
    session = bot.focus.get("u1")
    assert session.topic == "myproject"
    assert session.duration_seconds == 1800


@pytest.mark.asyncio
async def test_focus_command_2h():
    bot = make_bot_with_focus()
    dispatcher = CommandDispatcher(bot)
    result = await dispatcher.dispatch(make_inbound("!focus work 2h", user_id="u1"))
    assert result.handled is True
    session = bot.focus.get("u1")
    assert session.duration_seconds == 7200


@pytest.mark.asyncio
async def test_focus_command_no_duration_is_indefinite():
    bot = make_bot_with_focus()
    dispatcher = CommandDispatcher(bot)
    result = await dispatcher.dispatch(make_inbound("!focus antaris-agent"))
    assert result.handled is True
    session = bot.focus.get("user-42")
    assert session is not None
    assert session.duration_seconds == 0
    assert "no time limit" in result.response


@pytest.mark.asyncio
async def test_focus_command_no_args_shows_status_when_active():
    bot = make_bot_with_focus()
    bot.focus.start("user-42", "myproject", 60)
    dispatcher = CommandDispatcher(bot)
    result = await dispatcher.dispatch(make_inbound("!focus"))
    assert result.handled is True
    assert "myproject" in result.response


@pytest.mark.asyncio
async def test_focus_command_no_args_shows_no_session():
    bot = make_bot_with_focus()
    dispatcher = CommandDispatcher(bot)
    result = await dispatcher.dispatch(make_inbound("!focus"))
    assert result.handled is True
    assert "no active" in result.response.lower()


@pytest.mark.asyncio
async def test_unfocus_command_ends_focus():
    bot = make_bot_with_focus()
    bot.focus.start("user-42", "myproject", 60)
    dispatcher = CommandDispatcher(bot)
    result = await dispatcher.dispatch(make_inbound("!unfocus"))
    assert result.handled is True
    assert "ended" in result.response.lower() or "general" in result.response.lower()
    assert bot.focus.get("user-42") is None


@pytest.mark.asyncio
async def test_unfocus_command_no_active_session():
    bot = make_bot_with_focus()
    dispatcher = CommandDispatcher(bot)
    result = await dispatcher.dispatch(make_inbound("!unfocus"))
    assert result.handled is True
    assert "no active" in result.response.lower()


@pytest.mark.asyncio
async def test_help_includes_focus_commands():
    bot = make_bot_with_focus()
    dispatcher = CommandDispatcher(bot)
    result = await dispatcher.dispatch(make_inbound("!help"))
    assert result.handled is True
    assert "!focus" in result.response
    assert "!unfocus" in result.response


# ── Pipeline integration tests ───────────────────────────────────────────────

@pytest.mark.asyncio
async def test_pipeline_focus_prepends_topic_to_recall_query():
    """When focus is active, recall query should be biased with the topic."""
    from antaris_agent.core.pipeline import Pipeline
    from antaris_agent.core.focus import FocusManager

    # Build a minimal pipeline with mocked components
    config = MagicMock()
    config.rate_limit_messages = 20
    config.rate_limit_window_seconds = 60
    config.model = "claude-sonnet-4-6"
    config.guard_mode = "monitor"

    memory = MagicMock()
    memory.recall = AsyncMock(return_value=["relevant memory"])
    memory.ingest = AsyncMock()

    guard = MagicMock()
    guard.check_input = AsyncMock(return_value=(True, ""))
    guard.check_output = AsyncMock(return_value=(True, "response text"))

    persona = MagicMock()
    persona.config_dir = ""
    persona.build_system_prompt = MagicMock(return_value="You are helpful.")
    persona.update_user_context = MagicMock()

    llm_response = MagicMock()
    llm_response.content = "response text"
    llm_response.input_tokens = 10
    llm_response.output_tokens = 20
    llm_response.cost_usd = 0.0

    llm = MagicMock()
    llm.complete = AsyncMock(return_value=llm_response)

    adapter = MagicMock()
    adapter.format_for_surface = MagicMock(side_effect=lambda x: x)

    focus = FocusManager()
    focus.start("user1", "antaris-agent", 60)

    pipeline = Pipeline(
        config=config,
        memory=memory,
        guard=guard,
        persona=persona,
        llm=llm,
        focus=focus,
    )

    inbound = make_inbound("how do I configure this?", user_id="user1")
    await pipeline.process(inbound, adapter)

    # Verify memory.recall was called with the biased query
    memory.recall.assert_awaited()
    call_args = memory.recall.call_args_list
    # The first real recall (not startup recall) should have the biased query
    recall_queries = [str(call) for call in call_args]
    found_biased = any("antaris-agent" in q for q in recall_queries)
    assert found_biased, f"Expected focus topic in recall query. Calls: {recall_queries}"


@pytest.mark.asyncio
async def test_pipeline_no_focus_uses_plain_query():
    """Without focus, recall query is just the user message."""
    from antaris_agent.core.pipeline import Pipeline

    config = MagicMock()
    config.rate_limit_messages = 20
    config.rate_limit_window_seconds = 60
    config.model = "claude-sonnet-4-6"
    config.guard_mode = "monitor"

    memory = MagicMock()
    memory.recall = AsyncMock(return_value=[])
    memory.ingest = AsyncMock()

    guard = MagicMock()
    guard.check_input = AsyncMock(return_value=(True, ""))
    guard.check_output = AsyncMock(return_value=(True, "response"))

    persona = MagicMock()
    persona.config_dir = ""
    persona.build_system_prompt = MagicMock(return_value="You are helpful.")
    persona.update_user_context = MagicMock()

    llm_response = MagicMock()
    llm_response.content = "response"
    llm_response.input_tokens = 10
    llm_response.output_tokens = 20
    llm_response.cost_usd = 0.0

    llm = MagicMock()
    llm.complete = AsyncMock(return_value=llm_response)

    adapter = MagicMock()
    adapter.format_for_surface = MagicMock(side_effect=lambda x: x)

    pipeline = Pipeline(
        config=config,
        memory=memory,
        guard=guard,
        persona=persona,
        llm=llm,
        focus=None,
    )

    inbound = make_inbound("plain message", user_id="user1")
    await pipeline.process(inbound, adapter)

    # Verify recall was called without biasing
    calls = memory.recall.call_args_list
    # At least one call for the user message
    user_calls = [c for c in calls if "user1" in str(c)]
    assert len(user_calls) > 0
    # The query should be the plain message (no topic prefix)
    for call in user_calls:
        args = call.args or []
        kwargs = call.kwargs or {}
        query = args[1] if len(args) > 1 else kwargs.get("query", "")
        assert query == "plain message"
