"""Tests for token-budget compaction in SessionManager."""

import pytest
from unittest.mock import MagicMock

from antaris_agent.core.session import SessionManager, SessionState


@pytest.fixture
def config():
    config = MagicMock()
    config.keep_recent_tokens = 100
    config.context_max_tokens = 1000000
    config.session_persistence_enabled = True
    config.session_max_age_hours = 48
    return config


@pytest.fixture
def manager(config):
    return SessionManager(config)


@pytest.mark.asyncio
async def test_compaction_keeps_messages_within_budget(manager):
    """Messages that fit within keep_recent_tokens are all kept."""
    session = await manager.get_or_create("u1", "c1", "discord")
    # Add small messages (~5 tokens each via len/4 estimation)
    for i in range(10):
        session.add_to_history({"content": f"msg{i:02d}"})  # ~6 chars = ~1 token

    summary = await manager.compact_session("u1:c1")
    assert summary is not None
    assert session.status == "compacted"
    # All 10 tiny messages should be kept (well within 100 tokens)
    assert len(session.history) == 10


@pytest.mark.asyncio
async def test_compaction_trims_to_budget(config, manager):
    """When history exceeds budget, oldest messages are dropped."""
    config.keep_recent_tokens = 50  # Very tight budget
    session = await manager.get_or_create("u2", "c2", "discord")
    # Add messages with known size: 200 chars each = ~50 tokens each
    for i in range(5):
        session.add_to_history({"content": "X" * 200})

    assert len(session.history) == 5
    summary = await manager.compact_session("u2:c2")
    assert summary is not None
    # Only ~1 message should fit in 50 tokens (each is ~50 tokens)
    assert len(session.history) < 5
    assert len(session.history) >= 1  # Always keeps at least 1


@pytest.mark.asyncio
async def test_compaction_always_keeps_newest_message(config, manager):
    """Even if the newest message exceeds the budget, it's kept."""
    config.keep_recent_tokens = 10  # Tiny budget
    session = await manager.get_or_create("u3", "c3", "discord")
    # Single huge message: 10000 chars = ~2500 tokens
    session.add_to_history({"content": "Z" * 10000})

    summary = await manager.compact_session("u3:c3")
    assert summary is not None
    # The single message must be kept (never compact to empty)
    assert len(session.history) == 1
    assert session.history[0]["content"] == "Z" * 10000


@pytest.mark.asyncio
async def test_compaction_preserves_chronological_order(config, manager):
    """After compaction, remaining messages stay in chronological order."""
    config.keep_recent_tokens = 30
    session = await manager.get_or_create("u4", "c4", "discord")
    for i in range(10):
        session.add_to_history({"content": f"Message-{i:03d}" + "P" * 40})

    await manager.compact_session("u4:c4")
    # Check that messages are in order (newest at end)
    for j in range(len(session.history) - 1):
        assert session.history[j]["content"] < session.history[j + 1]["content"]


@pytest.mark.asyncio
async def test_compaction_empty_history(manager):
    """Compacting a session with empty history should work."""
    session = await manager.get_or_create("u5", "c5", "discord")
    assert len(session.history) == 0
    summary = await manager.compact_session("u5:c5")
    assert summary is not None
    assert len(session.history) == 0
    assert session.status == "compacted"


@pytest.mark.asyncio
async def test_compaction_clears_buffer(manager):
    """Conversation buffer should be cleared on compaction."""
    session = await manager.get_or_create("u6", "c6", "discord")
    session.add_to_history({"content": "hello"})
    session.add_to_buffer("u6", "hello", "hi")
    assert len(session.conversation_buffer) == 1

    await manager.compact_session("u6:c6")
    assert len(session.conversation_buffer) == 0


@pytest.mark.asyncio
async def test_compaction_warns_on_oversized_single_message(config, manager, caplog):
    """A warning should be logged when the newest message exceeds the budget."""
    import logging
    config.keep_recent_tokens = 10  # Tiny budget
    session = await manager.get_or_create("u7", "c7", "discord")
    session.add_to_history({"content": "Z" * 10000})  # ~2500 tokens, way over 10

    with caplog.at_level(logging.WARNING, logger="antaris_agent.core.session"):
        await manager.compact_session("u7:c7")

    assert any("exceeds keep_recent_tokens" in rec.message for rec in caplog.records)
