"""Tests for pipeline tool loop integration."""

from __future__ import annotations

import pytest
from unittest.mock import Mock, AsyncMock
from typing import Dict, Any, List

from antaris_agent.llm.base import LLMProvider, Message, LLMResponse, ThinkingConfig
from antaris_agent.tools.tool_registry import ToolRegistry
from antaris_agent.tools.pipeline_integration import run_tool_loop
from antaris_agent.tools import ToolResult


class MockLLMProvider(LLMProvider):
    """Mock LLM provider for testing."""
    
    def __init__(self):
        super().__init__("test-key", "test-model")
        self.responses = []
        self.call_count = 0
    
    def set_responses(self, responses: List[LLMResponse]):
        """Set responses to return in sequence."""
        self.responses = responses
        self.call_count = 0
    
    async def complete(
        self,
        messages: List[Message],
        system: str,
        model: str = None,
        max_tokens: int = 4096,
        temperature: float = 0.7,
        tools: List[Dict[str, Any]] = None,
        thinking: ThinkingConfig = None,
    ) -> LLMResponse:
        """Return next mock response."""
        if self.call_count < len(self.responses):
            response = self.responses[self.call_count]
            self.call_count += 1
            return response
        
        # Default response if no more mocked responses
        return LLMResponse(
            content="Default response",
            model="test-model",
            input_tokens=10,
            output_tokens=20,
            cost_usd=0.01,
            tool_use=None
        )
    
    def estimate_tokens(self, text: str) -> int:
        return len(text) // 4


@pytest.fixture
def mock_llm():
    """Create mock LLM provider."""
    return MockLLMProvider()


@pytest.fixture
def mock_tool_registry():
    """Create mock tool registry."""
    registry = Mock(spec=ToolRegistry)
    
    # Mock successful tool execution
    async def execute_tool(name: str, args: Dict[str, Any]) -> ToolResult:
        if name == "test_tool":
            return ToolResult(
                success=True,
                content=f"Tool result for {name} with args {args}"
            )
        elif name == "error_tool":
            return ToolResult(
                success=False,
                content="Tool failed",
                error="Simulated error",
                is_error=True
            )
        else:
            return ToolResult(
                success=False,
                content=f"Unknown tool: {name}",
                error=f"Tool {name} not found",
                is_error=True
            )
    
    registry.execute_tool = AsyncMock(side_effect=execute_tool)
    return registry


@pytest.fixture
def sample_tools():
    """Sample tool definitions."""
    return [
        {
            "name": "test_tool",
            "description": "A test tool",
            "input_schema": {
                "type": "object",
                "properties": {
                    "query": {"type": "string"}
                },
                "required": ["query"]
            }
        }
    ]


@pytest.mark.asyncio
async def test_tool_loop_no_tools(mock_llm, mock_tool_registry):
    """Test direct text response when no tools are provided."""
    mock_llm.set_responses([
        LLMResponse(
            content="Hello world",
            model="test-model",
            input_tokens=10,
            output_tokens=5,
            cost_usd=0.01,
            tool_use=None
        )
    ])
    
    messages = [Message(role="user", content="Hi")]
    
    result_text, updated_messages, metadata = await run_tool_loop(
        llm=mock_llm,
        messages=messages,
        tools=[],
        tool_registry=mock_tool_registry,
    )
    
    assert result_text == "Hello world"
    assert len(updated_messages) == 1
    assert metadata["iterations"] == 1
    assert metadata["tool_calls_made"] == []
    assert not metadata["stopped_by_max_iterations"]


@pytest.mark.asyncio
async def test_tool_loop_single_tool_call(mock_llm, mock_tool_registry, sample_tools):
    """Test single tool call followed by text response."""
    mock_llm.set_responses([
        # First response: tool use
        LLMResponse(
            content="",
            model="test-model", 
            input_tokens=10,
            output_tokens=20,
            cost_usd=0.01,
            tool_use=[{
                "id": "tool_123",
                "name": "test_tool",
                "input": {"query": "hello"}
            }]
        ),
        # Second response: text after tool result
        LLMResponse(
            content="Based on the tool result, here's my answer.",
            model="test-model",
            input_tokens=15,
            output_tokens=25, 
            cost_usd=0.02,
            tool_use=None
        )
    ])
    
    messages = [Message(role="user", content="Use the tool")]
    
    result_text, updated_messages, metadata = await run_tool_loop(
        llm=mock_llm,
        messages=messages,
        tools=sample_tools,
        tool_registry=mock_tool_registry,
    )
    
    assert result_text == "Based on the tool result, here's my answer."
    assert len(updated_messages) == 3  # original + assistant tool use + user tool result
    assert metadata["iterations"] == 2
    assert len(metadata["tool_calls_made"]) == 1
    assert metadata["tool_calls_made"][0]["name"] == "test_tool"
    assert metadata["tool_calls_made"][0]["success"] == True
    assert not metadata["stopped_by_max_iterations"]
    
    # Verify tool was called correctly
    mock_tool_registry.execute_tool.assert_called_once_with("test_tool", {"query": "hello"})


@pytest.mark.asyncio 
async def test_tool_loop_multiple_tool_calls(mock_llm, mock_tool_registry, sample_tools):
    """Test multiple tool calls before text response."""
    mock_llm.set_responses([
        # First response: tool use
        LLMResponse(
            content="",
            model="test-model",
            input_tokens=10,
            output_tokens=20,
            cost_usd=0.01,
            tool_use=[{
                "id": "tool_123", 
                "name": "test_tool",
                "input": {"query": "first"}
            }]
        ),
        # Second response: another tool use
        LLMResponse(
            content="",
            model="test-model",
            input_tokens=15,
            output_tokens=25,
            cost_usd=0.02,
            tool_use=[{
                "id": "tool_456",
                "name": "test_tool", 
                "input": {"query": "second"}
            }]
        ),
        # Third response: final text
        LLMResponse(
            content="All done with tools!",
            model="test-model",
            input_tokens=20,
            output_tokens=30,
            cost_usd=0.03,
            tool_use=None
        )
    ])
    
    messages = [Message(role="user", content="Use tools multiple times")]
    
    result_text, updated_messages, metadata = await run_tool_loop(
        llm=mock_llm,
        messages=messages, 
        tools=sample_tools,
        tool_registry=mock_tool_registry,
    )
    
    assert result_text == "All done with tools!"
    assert len(updated_messages) == 5  # original + 2 assistant + 2 user tool results
    assert metadata["iterations"] == 3
    assert len(metadata["tool_calls_made"]) == 2
    assert not metadata["stopped_by_max_iterations"]


@pytest.mark.asyncio
async def test_tool_loop_max_iterations_reached(mock_llm, mock_tool_registry, sample_tools):
    """Test that loop stops at max iterations."""
    # Create a response that always returns tool use
    tool_response = LLMResponse(
        content="",
        model="test-model", 
        input_tokens=10,
        output_tokens=20,
        cost_usd=0.01,
        tool_use=[{
            "id": "tool_loop",
            "name": "test_tool",
            "input": {"query": "loop"}
        }]
    )
    
    mock_llm.set_responses([tool_response] * 20)  # More than max iterations
    
    messages = [Message(role="user", content="Loop forever")]
    
    result_text, updated_messages, metadata = await run_tool_loop(
        llm=mock_llm,
        messages=messages,
        tools=sample_tools,
        tool_registry=mock_tool_registry,
        max_iterations=3  # Low limit for testing
    )
    
    assert "maximum number of tool calls" in result_text
    assert metadata["iterations"] == 3
    assert metadata["stopped_by_max_iterations"] == True
    assert len(metadata["tool_calls_made"]) == 3


@pytest.mark.asyncio
async def test_tool_loop_tool_execution_error(mock_llm, mock_tool_registry, sample_tools):
    """Test handling of tool execution errors."""
    mock_llm.set_responses([
        # Tool use with error-prone tool
        LLMResponse(
            content="",
            model="test-model",
            input_tokens=10,
            output_tokens=20,
            cost_usd=0.01,
            tool_use=[{
                "id": "tool_error",
                "name": "error_tool",
                "input": {"param": "test"}
            }]
        ),
        # LLM handles the error and responds
        LLMResponse(
            content="I encountered an error with the tool.",
            model="test-model",
            input_tokens=15,
            output_tokens=25,
            cost_usd=0.02,
            tool_use=None
        )
    ])
    
    # Add error_tool to sample tools
    error_tools = sample_tools + [{
        "name": "error_tool",
        "description": "A tool that always errors",
        "input_schema": {"type": "object"}
    }]
    
    messages = [Message(role="user", content="Use the error tool")]
    
    result_text, updated_messages, metadata = await run_tool_loop(
        llm=mock_llm,
        messages=messages,
        tools=error_tools,
        tool_registry=mock_tool_registry,
    )
    
    assert result_text == "I encountered an error with the tool."
    assert metadata["iterations"] == 2
    assert len(metadata["tool_calls_made"]) == 1
    assert metadata["tool_calls_made"][0]["success"] == False
    assert metadata["tool_calls_made"][0]["error"] == "Simulated error"


@pytest.mark.asyncio
async def test_tool_loop_unknown_tool(mock_llm, mock_tool_registry, sample_tools):
    """Test handling of unknown tool calls."""
    mock_llm.set_responses([
        # Tool use with unknown tool
        LLMResponse(
            content="", 
            model="test-model",
            input_tokens=10,
            output_tokens=20,
            cost_usd=0.01,
            tool_use=[{
                "id": "tool_unknown",
                "name": "unknown_tool",
                "input": {"param": "test"}
            }]
        ),
        # LLM handles the error and responds
        LLMResponse(
            content="That tool doesn't exist.",
            model="test-model",
            input_tokens=15,
            output_tokens=25,
            cost_usd=0.02,
            tool_use=None
        )
    ])
    
    messages = [Message(role="user", content="Use unknown tool")]
    
    result_text, updated_messages, metadata = await run_tool_loop(
        llm=mock_llm,
        messages=messages,
        tools=sample_tools,
        tool_registry=mock_tool_registry,
    )
    
    assert result_text == "That tool doesn't exist."
    assert metadata["iterations"] == 2
    assert len(metadata["tool_calls_made"]) == 1
    assert metadata["tool_calls_made"][0]["success"] == False


@pytest.mark.asyncio
async def test_tool_loop_no_tools_configured(mock_llm, mock_tool_registry):
    """Test that loop works normally when no tools are configured."""
    mock_llm.set_responses([
        LLMResponse(
            content="Normal response without tools",
            model="test-model",
            input_tokens=10,
            output_tokens=20,
            cost_usd=0.01,
            tool_use=None
        )
    ])
    
    messages = [Message(role="user", content="Hello")]
    
    result_text, updated_messages, metadata = await run_tool_loop(
        llm=mock_llm,
        messages=messages,
        tools=[],  # No tools
        tool_registry=mock_tool_registry,
    )
    
    assert result_text == "Normal response without tools"
    assert len(updated_messages) == 1  # Unchanged
    assert metadata["iterations"] == 1
    assert metadata["tool_calls_made"] == []


@pytest.mark.asyncio
async def test_tool_loop_with_middleware_approved(mock_llm, mock_tool_registry, sample_tools):
    """Test that tool_middleware gates tool execution."""
    # Create a mock middleware that approves the tool call
    mock_middleware = AsyncMock()
    mock_middleware.approve_and_run.return_value = ToolResult(success=True, content="Tool approved and executed")
    
    mock_llm.set_responses([
        # LLM decides to use a tool
        LLMResponse(
            content="I'll use the test tool.",
            model="test-model",
            input_tokens=10,
            output_tokens=15,
            cost_usd=0.01,
            tool_use=[{
                "id": "test_call_1",
                "name": "test_tool",
                "input": {"test": "value"}
            }]
        ),
        # LLM handles the tool result
        LLMResponse(
            content="Tool was executed successfully!",
            model="test-model",
            input_tokens=20,
            output_tokens=25,
            cost_usd=0.02,
            tool_use=None
        )
    ])
    
    messages = [Message(role="user", content="Use test tool")]
    
    result_text, updated_messages, metadata = await run_tool_loop(
        llm=mock_llm,
        messages=messages,
        tools=sample_tools,
        tool_registry=mock_tool_registry,
        tool_middleware=mock_middleware,
    )
    
    # Verify middleware was called with approve_and_run
    mock_middleware.approve_and_run.assert_called_once()
    assert result_text == "Tool was executed successfully!"
    assert metadata["iterations"] == 2


@pytest.mark.asyncio
async def test_tool_loop_with_middleware_rejected(mock_llm, mock_tool_registry, sample_tools):
    """Test that rejected tool calls return proper error."""
    # Create a mock middleware that rejects the tool call
    mock_middleware = AsyncMock()
    mock_middleware.approve_and_run.return_value = None  # None means rejected
    
    mock_llm.set_responses([
        # LLM decides to use a tool
        LLMResponse(
            content="I'll use the test tool.",
            model="test-model",
            input_tokens=10,
            output_tokens=15,
            cost_usd=0.01,
            tool_use=[{
                "id": "test_call_2",
                "name": "test_tool",
                "input": {"test": "value"}
            }]
        ),
        # LLM handles the rejection
        LLMResponse(
            content="The tool request was rejected by policy.",
            model="test-model",
            input_tokens=20,
            output_tokens=25,
            cost_usd=0.02,
            tool_use=None
        )
    ])
    
    messages = [Message(role="user", content="Use test tool")]
    
    result_text, updated_messages, metadata = await run_tool_loop(
        llm=mock_llm,
        messages=messages,
        tools=sample_tools,
        tool_registry=mock_tool_registry,
        tool_middleware=mock_middleware,
    )
    
    # Verify middleware was called and request was rejected
    mock_middleware.approve_and_run.assert_called_once()
    assert result_text == "The tool request was rejected by policy."
    assert metadata["iterations"] == 2
    # The tool_calls_made should still contain the rejected call
    assert len(metadata["tool_calls_made"]) == 1
    assert metadata["tool_calls_made"][0]["success"] == False