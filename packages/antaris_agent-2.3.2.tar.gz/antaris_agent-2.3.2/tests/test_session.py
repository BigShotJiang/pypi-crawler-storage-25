"""Tests for antaris_agent.core.session"""

import asyncio
import pytest
import time
from unittest.mock import MagicMock

from antaris_agent.core.session import SessionState, SessionManager


# ---------------------------------------------------------------------------
# SessionState Tests
# ---------------------------------------------------------------------------

class TestSessionState:
    """Test SessionState dataclass functionality."""

    def test_session_state_creation(self):
        """Test basic session state creation with defaults."""
        session = SessionState(
            session_id="user1:channel1",
            user_id="user1",
            channel_id="channel1", 
            platform="discord",
            history=[]
        )
        assert session.session_id == "user1:channel1"
        assert session.user_id == "user1"
        assert session.channel_id == "channel1"
        assert session.platform == "discord"
        assert session.history == []
        assert session.message_count == 0
        assert not session.compaction_notified
        assert not session.pre_compaction_flushed
        assert session.conversation_buffer == []
        assert session.status == "active"
        assert session.metadata == {}
        # Timestamps should be auto-initialized
        assert session.created_at > 0
        assert session.last_active > 0

    def test_session_state_with_explicit_timestamps(self):
        """Test session creation with explicit timestamps."""
        created_time = 1000.0
        active_time = 2000.0
        session = SessionState(
            session_id="test:session",
            user_id="test_user",
            channel_id="test_channel",
            platform="telegram",
            history=[],
            created_at=created_time,
            last_active=active_time
        )
        assert session.created_at == created_time
        assert session.last_active == active_time

    def test_add_to_history_basic(self):
        """Test adding messages to history."""
        session = SessionState(
            session_id="test:session",
            user_id="user",
            channel_id="channel",
            platform="discord",
            history=[]
        )
        initial_time = session.last_active
        
        # Add a message
        time.sleep(0.001)  # Ensure timestamp changes
        session.add_to_history({"role": "user", "content": "Hello"})
        
        assert len(session.history) == 1
        assert session.history[0] == {"role": "user", "content": "Hello"}
        assert session.message_count == 1
        assert session.last_active > initial_time

    def test_add_to_history_no_trim(self):
        """History grows without an artificial cap (token-based compaction handles size)."""
        session = SessionState(
            session_id="test:session",
            user_id="user", 
            channel_id="channel",
            platform="discord",
            history=[],
        )
        
        # Add 50 messages — all should be retained
        for i in range(50):
            session.add_to_history({"role": "user", "content": f"Message {i}"})
            
        assert len(session.history) == 50
        assert session.history[0]["content"] == "Message 0"
        assert session.history[49]["content"] == "Message 49"
        assert session.message_count == 50

    def test_add_to_buffer_basic(self):
        """Test adding to conversation buffer."""
        session = SessionState(
            session_id="test:session",
            user_id="user",
            channel_id="channel", 
            platform="discord",
            history=[]
        )
        
        session.add_to_buffer("user1", "Hello", "Hi there!")
        assert len(session.conversation_buffer) == 1
        assert session.conversation_buffer[0] == ("user1", "Hello", "Hi there!")

    def test_add_to_buffer_rolling_window(self):
        """Test conversation buffer rolling window (30 max)."""
        session = SessionState(
            session_id="test:session",
            user_id="user",
            channel_id="channel",
            platform="discord", 
            history=[]
        )
        
        # Add 35 conversation pairs
        for i in range(35):
            session.add_to_buffer(f"user{i}", f"Message {i}", f"Response {i}")
            
        # Should only keep last 30
        assert len(session.conversation_buffer) == 30
        assert session.conversation_buffer[0] == ("user5", "Message 5", "Response 5")
        assert session.conversation_buffer[-1] == ("user34", "Message 34", "Response 34")

    def test_build_summary_empty(self):
        """Test building summary with empty buffer."""
        session = SessionState(
            session_id="test:session",
            user_id="user",
            channel_id="channel",
            platform="discord",
            history=[]
        )
        
        summary = session.build_summary()
        assert summary == "(no conversation data)"

    def test_build_summary_with_data(self):
        """Test building summary with conversation data."""
        session = SessionState(
            session_id="test:session",
            user_id="user",
            channel_id="channel",
            platform="discord",
            history=[]
        )
        
        session.add_to_buffer("user1", "A" * 200, "B" * 200)  # Long messages
        session.add_to_buffer("user2", "Short", "Also short")
        
        summary = session.build_summary()
        lines = summary.split("\n")
        
        assert lines[0] == "### Recent conversation summary"
        assert len(lines) == 6  # Header + blank + 2 conversations * 2 lines each
        assert lines[2].startswith("- User: " + "A" * 150)  # Truncated at 150
        assert lines[3].startswith("  Bot: " + "B" * 150)   # Truncated at 150
        assert lines[4] == "- User: Short"
        assert lines[5] == "  Bot: Also short"

    def test_context_pct_calculation(self):
        """Test context percentage calculation."""
        session = SessionState(
            session_id="test:session",
            user_id="user",
            channel_id="channel",
            platform="discord",
            history=[]
        )
        
        # Empty history = 0%
        assert session.context_pct == 0.0
        
        # Add some messages
        session.add_to_history({"content": "A" * 1000})  # ~250 tokens
        session.add_to_history({"content": "B" * 3000})  # ~750 tokens
        
        # Should be about (1000 tokens / 1,000,000 max) * 100 = 0.1%
        pct = session.context_pct
        assert 0.05 <= pct <= 0.15  # Allow for some variance in calculation

    def test_context_pct_max_100(self):
        """Test context percentage caps at 100%."""
        session = SessionState(
            session_id="test:session", 
            user_id="user",
            channel_id="channel",
            platform="discord",
            history=[]
        )
        
        # Add a huge message that would exceed 100% (1M context = 4M chars)
        huge_content = "A" * 5_000_000  # 5M chars = ~1.25M tokens, well over 1M limit
        session.add_to_history({"content": huge_content})
        
        assert session.context_pct == 100.0


# ---------------------------------------------------------------------------
# SessionManager Tests  
# ---------------------------------------------------------------------------

@pytest.fixture
def mock_config():
    """Mock config for testing."""
    config = MagicMock()
    config.session_persistence_enabled = True
    config.keep_recent_tokens = 100000
    config.context_max_tokens = 1000000
    config.session_max_age_hours = 48
    config.session_max_restore_messages = 20
    return config


@pytest.fixture
def session_manager(mock_config):
    """Create SessionManager for testing."""
    return SessionManager(mock_config, idle_timeout_minutes=1, max_concurrent=3)


class TestSessionManager:
    """Test SessionManager functionality."""

    @pytest.mark.asyncio
    async def test_session_manager_creation(self, mock_config):
        """Test SessionManager initialization."""
        manager = SessionManager(mock_config, idle_timeout_minutes=60, max_concurrent=10)
        assert manager._idle_timeout == 3600  # 60 minutes in seconds
        assert manager._max_concurrent == 10
        assert manager._config == mock_config
        assert manager.total_count == 0
        assert manager.active_count == 0

    @pytest.mark.asyncio
    async def test_get_or_create_new_session(self, session_manager):
        """Test creating new session."""
        session = await session_manager.get_or_create("user1", "channel1", "discord")
        
        assert session.session_id == "user1:channel1"
        assert session.user_id == "user1"
        assert session.channel_id == "channel1"
        assert session.platform == "discord"
        assert session.status == "active"
        assert session.status == "active"
        assert session_manager.total_count == 1
        assert session_manager.active_count == 1

    @pytest.mark.asyncio
    async def test_get_or_create_existing_session(self, session_manager):
        """Test retrieving existing session."""
        # Create session
        session1 = await session_manager.get_or_create("user1", "channel1", "discord")
        initial_time = session1.last_active
        
        # Wait a bit then retrieve again
        time.sleep(0.001)
        session2 = await session_manager.get_or_create("user1", "channel1", "discord")
        
        # Should be same session with updated timestamp
        assert session1 is session2
        assert session2.last_active > initial_time
        assert session_manager.total_count == 1

    @pytest.mark.asyncio
    async def test_get_or_create_reactivates_idle(self, session_manager):
        """Test that accessing idle session reactivates it."""
        # Create and mark as idle
        session = await session_manager.get_or_create("user1", "channel1", "discord")
        await session_manager.mark_idle(session.session_id)
        assert session.status == "idle"
        
        # Access again should reactivate
        session2 = await session_manager.get_or_create("user1", "channel1", "discord")
        assert session2 is session
        assert session2.status == "active"

    @pytest.mark.asyncio
    async def test_get_session(self, session_manager):
        """Test getting session by ID."""
        # Non-existent session
        session = await session_manager.get_session("nonexistent")
        assert session is None
        
        # Create and retrieve
        created = await session_manager.get_or_create("user1", "channel1", "discord")
        retrieved = await session_manager.get_session("user1:channel1")
        assert retrieved is created

    @pytest.mark.asyncio
    async def test_list_sessions_active_only(self, session_manager):
        """Test listing sessions with active_only filter."""
        # Create sessions with different statuses
        s1 = await session_manager.get_or_create("user1", "channel1", "discord")
        s2 = await session_manager.get_or_create("user2", "channel2", "telegram") 
        s3 = await session_manager.get_or_create("user3", "channel3", "discord")
        
        await session_manager.mark_idle(s2.session_id)
        s3.status = "closed"
        
        # Active only (default) - should exclude closed
        active_sessions = await session_manager.list_sessions(active_only=True)
        assert len(active_sessions) == 2  # active + idle (closed excluded)
        session_ids = [s.session_id for s in active_sessions]
        assert "user1:channel1" in session_ids
        assert "user2:channel2" in session_ids
        assert "user3:channel3" not in session_ids
        
        # All sessions
        all_sessions = await session_manager.list_sessions(active_only=False)
        assert len(all_sessions) == 3

    @pytest.mark.asyncio
    async def test_kill_session(self, session_manager):
        """Test killing sessions."""
        # Non-existent session
        result = await session_manager.kill_session("nonexistent")
        assert not result
        
        # Create and kill
        session = await session_manager.get_or_create("user1", "channel1", "discord")
        assert session_manager.total_count == 1
        
        result = await session_manager.kill_session("user1:channel1")
        assert result
        assert session_manager.total_count == 0
        assert session.status == "closed"

    @pytest.mark.asyncio
    async def test_reset_session(self, session_manager):
        """Test resetting session history."""
        # Non-existent session
        result = await session_manager.reset_session("nonexistent")
        assert not result
        
        # Create session with data
        session = await session_manager.get_or_create("user1", "channel1", "discord")
        session.add_to_history({"content": "test"})
        session.add_to_buffer("user1", "Hello", "Hi")
        session.compaction_notified = True
        session.pre_compaction_flushed = True
        
        assert len(session.history) == 1
        assert len(session.conversation_buffer) == 1
        assert session.message_count == 1
        
        # Reset
        result = await session_manager.reset_session("user1:channel1")
        assert result
        assert len(session.history) == 0
        assert len(session.conversation_buffer) == 0
        assert session.message_count == 0
        assert not session.compaction_notified
        assert not session.pre_compaction_flushed

    @pytest.mark.asyncio
    async def test_cleanup_idle_no_timeout(self, session_manager):
        """Test cleanup with no sessions to clean."""
        # Create active and idle sessions, none timed out
        s1 = await session_manager.get_or_create("user1", "channel1", "discord")
        s2 = await session_manager.get_or_create("user2", "channel2", "telegram")
        await session_manager.mark_idle(s2.session_id)
        
        cleaned = await session_manager.cleanup_idle()
        assert cleaned == 0
        assert session_manager.total_count == 2

    @pytest.mark.asyncio
    async def test_cleanup_idle_with_timeout(self, session_manager):
        """Test cleanup with timed out sessions."""
        # Create session and manually set old timestamp
        session = await session_manager.get_or_create("user1", "channel1", "discord")
        await session_manager.mark_idle(session.session_id)
        
        # Set last_active to 2 hours ago (manager timeout is 1 minute)
        session.last_active = time.time() - 7200
        
        cleaned = await session_manager.cleanup_idle()
        assert cleaned == 1
        assert session_manager.total_count == 0

    @pytest.mark.asyncio
    async def test_compact_session(self, session_manager):
        """Test session compaction."""
        # Non-existent session
        summary = await session_manager.compact_session("nonexistent")
        assert summary is None
        
        # Create session with history and buffer
        session = await session_manager.get_or_create("user1", "channel1", "discord")
        for i in range(10):
            session.add_to_history({"content": f"Message {i}"})
        session.add_to_buffer("user1", "Hello", "Hi there")
        
        assert len(session.history) == 10
        assert len(session.conversation_buffer) == 1
        
        # Compact
        summary = await session_manager.compact_session("user1:channel1")
        assert summary is not None
        assert "Hi there" in summary  # From conversation buffer
        # Token-based compaction: small messages all fit within keep_recent_tokens (100K)
        # so all 10 are retained. With large messages, older ones would be pruned.
        assert len(session.history) <= 10
        assert len(session.conversation_buffer) == 0  # Cleared
        assert session.status == "compacted"

    @pytest.mark.asyncio
    async def test_max_concurrent_eviction(self, session_manager):
        """Test max concurrent limit with idle eviction."""
        # Manager has max_concurrent=3
        # Create 3 active sessions
        s1 = await session_manager.get_or_create("user1", "channel1", "discord")
        s2 = await session_manager.get_or_create("user2", "channel2", "discord")
        s3 = await session_manager.get_or_create("user3", "channel3", "discord")
        
        assert session_manager.active_count == 3
        
        # Mark first two as idle (different times)
        await session_manager.mark_idle(s1.session_id)
        s1.last_active = time.time() - 100  # Older
        await session_manager.mark_idle(s2.session_id)
        s2.last_active = time.time() - 50   # Newer
        
        # Create 4th session - should evict oldest idle (s1)
        s4 = await session_manager.get_or_create("user4", "channel4", "discord")
        
        assert session_manager.total_count == 3  # s1 was evicted
        assert "user1:channel1" not in session_manager._sessions
        assert "user2:channel2" in session_manager._sessions  # Newer idle kept
        assert "user4:channel4" in session_manager._sessions

    @pytest.mark.asyncio
    async def test_session_id_generation(self, session_manager):
        """Test session ID generation."""
        session_id = session_manager.session_id_for("user123", "channel456")
        assert session_id == "user123:channel456"

    @pytest.mark.asyncio
    async def test_mark_idle(self, session_manager):
        """Test marking sessions as idle."""
        # Non-existent session
        result = await session_manager.mark_idle("nonexistent")
        assert not result
        
        # Active session
        session = await session_manager.get_or_create("user1", "channel1", "discord")
        assert session.status == "active"
        
        result = await session_manager.mark_idle("user1:channel1")
        assert result
        assert session.status == "idle"
        
        # Closed session (can't mark idle)
        session.status = "closed"
        result = await session_manager.mark_idle("user1:channel1")
        assert not result

    @pytest.mark.asyncio
    async def test_concurrent_access(self, session_manager):
        """Test concurrent access to same session."""
        async def get_session():
            return await session_manager.get_or_create("user1", "channel1", "discord")
        
        # Run multiple concurrent get_or_create calls
        sessions = await asyncio.gather(*[get_session() for _ in range(5)])
        
        # All should return the same session object
        first_session = sessions[0]
        for session in sessions[1:]:
            assert session is first_session
        
        # Should only have created one session
        assert session_manager.total_count == 1

    @pytest.mark.asyncio
    async def test_config_fallback_values(self):
        """Test fallback values when config is None or missing attrs."""
        # None config — session should still be created with defaults
        manager = SessionManager(None)
        session = await manager.get_or_create("user1", "channel1", "discord")
        assert session.status == "active"
        
        # Config without special attributes — should still work
        config = MagicMock()
        manager2 = SessionManager(config)
        session2 = await manager2.get_or_create("user2", "channel2", "discord")
        assert session2.status == "active"

    @pytest.mark.asyncio
    async def test_active_count_property(self, session_manager):
        """Test active_count property calculation."""
        assert session_manager.active_count == 0
        
        # Create sessions with different statuses
        s1 = await session_manager.get_or_create("user1", "channel1", "discord")
        s2 = await session_manager.get_or_create("user2", "channel2", "discord") 
        s3 = await session_manager.get_or_create("user3", "channel3", "discord")
        
        assert session_manager.active_count == 3
        assert session_manager.total_count == 3
        
        # Mark one idle, one compacted, one closed
        await session_manager.mark_idle(s1.session_id)
        s2.status = "compacted" 
        s3.status = "closed"
        
        assert session_manager.active_count == 2  # active + idle
        assert session_manager.total_count == 3   # all sessions still in dict

    @pytest.mark.asyncio
    async def test_edge_case_empty_manager(self, session_manager):
        """Test operations on empty manager."""
        # All operations should handle empty state gracefully
        sessions = await session_manager.list_sessions()
        assert sessions == []
        
        sessions_all = await session_manager.list_sessions(active_only=False)
        assert sessions_all == []
        
        cleaned = await session_manager.cleanup_idle()
        assert cleaned == 0
        
        assert session_manager.active_count == 0
        assert session_manager.total_count == 0