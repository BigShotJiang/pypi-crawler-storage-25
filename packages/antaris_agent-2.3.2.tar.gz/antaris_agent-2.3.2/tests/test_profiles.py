"""Tests for antaris_agent.core.profiles"""
import json
from pathlib import Path

import pytest

from antaris_agent.core.profiles import UserProfile, ProfileManager


# ── UserProfile ───────────────────────────────────────────────────────────────

class TestUserProfile:
    def test_defaults(self):
        profile = UserProfile(user_id="u1")
        assert profile.display_name == ""
        assert profile.notes == []
        assert profile.preferences == {}
        assert profile.conversation_style == "casual"
        assert profile.message_count == 0
        assert profile.last_seen == ""

    def test_touch_increments_message_count(self):
        profile = UserProfile(user_id="u2")
        assert profile.message_count == 0
        profile.touch()
        assert profile.message_count == 1
        profile.touch()
        assert profile.message_count == 2

    def test_touch_updates_last_seen(self):
        profile = UserProfile(user_id="u3")
        assert profile.last_seen == ""
        profile.touch()
        assert profile.last_seen != ""
        # Should be an ISO format string
        assert "T" in profile.last_seen or "-" in profile.last_seen

    def test_add_note_appends(self):
        profile = UserProfile(user_id="u4")
        profile.add_note("Likes Python")
        assert "Likes Python" in profile.notes

    def test_add_note_deduplicates(self):
        profile = UserProfile(user_id="u5")
        profile.add_note("Fact A")
        profile.add_note("Fact A")  # duplicate
        profile.add_note("Fact A")  # again
        assert profile.notes.count("Fact A") == 1

    def test_add_note_caps_at_50(self):
        profile = UserProfile(user_id="u6")
        for i in range(60):
            profile.add_note(f"Note {i}")
        assert len(profile.notes) == 50
        # Should keep the most recent ones
        assert "Note 59" in profile.notes
        assert "Note 0" not in profile.notes

    def test_to_context_string_none_when_empty(self):
        profile = UserProfile(user_id="u7")
        assert profile.to_context_string() is None

    def test_to_context_string_none_no_name_no_notes(self):
        profile = UserProfile(user_id="u8", conversation_style="technical")
        # No display_name, no notes — should be None even if style != casual
        # Because there's nothing meaningful to surface
        result = profile.to_context_string()
        # Either None or only style (depends on impl) — check it doesn't crash
        # Per spec: "if not self.display_name and not self.notes: return None"
        assert result is None

    def test_to_context_string_with_name(self):
        profile = UserProfile(user_id="u9", display_name="Alice")
        result = profile.to_context_string()
        assert result is not None
        assert "Alice" in result
        assert "Name:" in result

    def test_to_context_string_with_notes(self):
        profile = UserProfile(user_id="u10")
        profile.add_note("Likes cats")
        profile.add_note("Based in Tokyo")
        result = profile.to_context_string()
        assert result is not None
        assert "Likes cats" in result

    def test_to_context_string_full(self):
        profile = UserProfile(
            user_id="u11",
            display_name="Bob",
            conversation_style="technical",
        )
        profile.add_note("Senior engineer")
        result = profile.to_context_string()
        assert result is not None
        assert "Bob" in result
        assert "technical" in result.lower() or "Style" in result
        assert "Senior engineer" in result

    def test_to_context_string_caps_notes_at_5(self):
        profile = UserProfile(user_id="u12", display_name="Cap")
        for i in range(10):
            profile.add_note(f"Note {i}")
        result = profile.to_context_string()
        # Only first 5 notes should appear
        assert result is not None
        # Count semicolons — max 4 separators for 5 notes
        notes_part = [p for p in result.split(" | ") if p.startswith("Notes:")]
        if notes_part:
            note_items = notes_part[0].split(";")
            assert len(note_items) <= 5

    def test_serialization_round_trip(self):
        profile = UserProfile(
            user_id="u13",
            display_name="Round Trip",
            conversation_style="brief",
            message_count=42,
        )
        profile.add_note("loves tests")
        d = profile.to_dict()
        restored = UserProfile.from_dict(d)
        assert restored.user_id == profile.user_id
        assert restored.display_name == profile.display_name
        assert restored.message_count == profile.message_count
        assert restored.notes == profile.notes
        assert restored.conversation_style == profile.conversation_style

    def test_from_dict_ignores_extra_keys(self):
        d = {
            "user_id": "u14",
            "unknown_future_key": "should_be_ignored",
        }
        profile = UserProfile.from_dict(d)
        assert profile.user_id == "u14"


# ── ProfileManager ────────────────────────────────────────────────────────────

@pytest.fixture
def profiles_dir(tmp_path):
    return tmp_path / "profiles"


class TestProfileManager:
    def test_creates_new_profile(self, profiles_dir):
        mgr = ProfileManager(profiles_dir=profiles_dir)
        profile = mgr.get("new_user")
        assert profile is not None
        assert profile.user_id == "new_user"
        assert profile.message_count == 0

    def test_get_returns_same_object_from_cache(self, profiles_dir):
        mgr = ProfileManager(profiles_dir=profiles_dir)
        p1 = mgr.get("user1")
        p2 = mgr.get("user1")
        assert p1 is p2  # same object from cache

    def test_save_and_reload(self, profiles_dir):
        mgr = ProfileManager(profiles_dir=profiles_dir)
        profile = mgr.get("persist_user")
        profile.display_name = "Persisted"
        mgr.save(profile)

        # New manager instance — cold start
        mgr2 = ProfileManager(profiles_dir=profiles_dir)
        loaded = mgr2.get("persist_user")
        assert loaded.display_name == "Persisted"

    def test_touch_increments_message_count(self, profiles_dir):
        mgr = ProfileManager(profiles_dir=profiles_dir)
        profile = mgr.touch("touch_user")
        assert profile.message_count == 1
        profile = mgr.touch("touch_user")
        assert profile.message_count == 2

    def test_touch_persists_to_disk(self, profiles_dir):
        mgr = ProfileManager(profiles_dir=profiles_dir)
        mgr.touch("disk_user")
        mgr.touch("disk_user")

        mgr2 = ProfileManager(profiles_dir=profiles_dir)
        loaded = mgr2.get("disk_user")
        assert loaded.message_count == 2

    def test_update_name(self, profiles_dir):
        mgr = ProfileManager(profiles_dir=profiles_dir)
        mgr.update_name("name_user", "Alice")
        profile = mgr.get("name_user")
        assert profile.display_name == "Alice"

    def test_update_name_no_op_if_same(self, profiles_dir):
        mgr = ProfileManager(profiles_dir=profiles_dir)
        mgr.update_name("name_user2", "Bob")
        # Call again with same name — should not error
        mgr.update_name("name_user2", "Bob")
        assert mgr.get("name_user2").display_name == "Bob"

    def test_add_note(self, profiles_dir):
        mgr = ProfileManager(profiles_dir=profiles_dir)
        mgr.add_note("note_user", "Loves coffee")
        profile = mgr.get("note_user")
        assert "Loves coffee" in profile.notes

    def test_add_note_deduplication_via_manager(self, profiles_dir):
        mgr = ProfileManager(profiles_dir=profiles_dir)
        mgr.add_note("dup_user", "Unique fact")
        mgr.add_note("dup_user", "Unique fact")  # duplicate
        profile = mgr.get("dup_user")
        assert profile.notes.count("Unique fact") == 1

    def test_get_context_returns_none_when_empty(self, profiles_dir):
        mgr = ProfileManager(profiles_dir=profiles_dir)
        ctx = mgr.get_context("empty_user")
        assert ctx is None

    def test_get_context_returns_string_when_populated(self, profiles_dir):
        mgr = ProfileManager(profiles_dir=profiles_dir)
        mgr.update_name("ctx_user", "Carol")
        mgr.add_note("ctx_user", "Prefers brevity")
        ctx = mgr.get_context("ctx_user")
        assert ctx is not None
        assert "Carol" in ctx

    def test_list_profiles_empty(self, profiles_dir):
        mgr = ProfileManager(profiles_dir=profiles_dir)
        assert mgr.list_profiles() == []

    def test_list_profiles_returns_saved(self, profiles_dir):
        mgr = ProfileManager(profiles_dir=profiles_dir)
        mgr.save(mgr.get("list_user1"))
        mgr.save(mgr.get("list_user2"))
        profiles = mgr.list_profiles()
        assert len(profiles) == 2

    def test_safe_id_strips_special_chars(self, profiles_dir):
        """User IDs with special chars should produce safe filenames."""
        mgr = ProfileManager(profiles_dir=profiles_dir)
        # Discord-style ID (all digits) — fine
        mgr.get("276141255266926602")
        # Filepath shouldn't have bad chars
        p = mgr._path("user@with!special#chars")
        assert "@" not in p.name
        assert "!" not in p.name
        assert "#" not in p.name

    def test_profiles_dir_created_automatically(self, tmp_path):
        new_dir = tmp_path / "deep" / "profiles"
        assert not new_dir.exists()
        mgr = ProfileManager(profiles_dir=new_dir)
        assert new_dir.exists()
