"""Release integrity checks — run before every release."""
import re
import subprocess
import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parent.parent


def test_readme_version_matches_package_version():
    from antaris_agent._version import __version__
    readme = (REPO_ROOT / "README.md").read_text(encoding="utf-8")
    # Look for **vX.Y.Z** pattern
    m = re.search(r"\*\*v([0-9.]+)\*\*", readme)
    if m:
        assert m.group(1) == __version__, f"README says v{m.group(1)} but package is v{__version__}"


def test_encrypted_mode_cannot_start_without_key(tmp_path):
    from antaris_agent.core.memory import BotMemory
    with pytest.raises(RuntimeError, match="requires encryption_key"):
        BotMemory(store_path=str(tmp_path / "mem"), security_mode="encrypted", encryption_key=None)


def test_cli_help_portable():
    result = subprocess.run(
        [sys.executable, "-m", "antaris_agent.cli", "--help"],
        capture_output=True, text=True, cwd=str(REPO_ROOT),
    )
    assert result.returncode == 0


def test_audit_hook_blocks_dangerous_paths():
    from antaris_agent.security import audit_hook
    from antaris_agent.security.levels import LEVEL_STANDARD
    import tempfile
    with tempfile.TemporaryDirectory() as ws:
        orig_level = audit_hook._LEVEL
        orig_ws = audit_hook._WORKSPACE
        orig_paths = audit_hook._ALLOWED_PATHS.copy()
        try:
            audit_hook._LEVEL = LEVEL_STANDARD
            audit_hook._WORKSPACE = ws
            audit_hook._ALLOWED_PATHS = audit_hook._build_allowed_paths()
            assert not audit_hook._check_file_access("/usr/bin/malicious_script")
        finally:
            audit_hook._LEVEL = orig_level
            audit_hook._WORKSPACE = orig_ws
            audit_hook._ALLOWED_PATHS = orig_paths
