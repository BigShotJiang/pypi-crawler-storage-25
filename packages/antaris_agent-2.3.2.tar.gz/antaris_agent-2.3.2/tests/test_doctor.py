"""Tests for the `antaris doctor` CLI command — honest encryption reporting."""
import os
import sys
import types
from io import StringIO
from pathlib import Path
from unittest import mock

import pytest


def _run_doctor_capture():
    """Run _cmd_doctor and capture stdout."""
    from antaris_agent.cli import _cmd_doctor
    buf = StringIO()
    with mock.patch("sys.stdout", buf):
        _cmd_doctor()
    return buf.getvalue()


# ---------------------------------------------------------------------------
# Encryption reporting
# ---------------------------------------------------------------------------

def test_doctor_reports_encryption_disabled_in_non_encrypted_mode(tmp_path):
    """When security_mode != 'encrypted', doctor should report key not loaded
    and data-at-rest not yet implemented."""
    config_file = tmp_path / "config.json"
    config_file.write_text('{"provider": {"name": "anthropic", "model": "claude-sonnet-4-6"}, '
                           '"security": {"mode": "sandboxed"}, '
                           '"memory": {"store": "' + str(tmp_path / "memory") + '"}}')
    (tmp_path / "memory").mkdir()

    with mock.patch("antaris_agent.core.config.resolve_config_path", return_value=config_file):
        output = _run_doctor_capture()

    assert "not in encrypted mode" in output
    assert "not yet implemented" in output
    # Should NOT claim encryption is active
    assert "encrypted mode" not in output or "not in encrypted mode" in output


def test_doctor_reports_encryption_honest_in_encrypted_mode(tmp_path):
    """Even when security_mode IS encrypted, data-at-rest should still say
    'not yet implemented' — that's the honest reporting Pro requested."""
    config_file = tmp_path / "config.json"
    config_file.write_text('{"provider": {"name": "anthropic", "model": "claude-sonnet-4-6"}, '
                           '"security": {"mode": "encrypted"}, '
                           '"memory": {"store": "' + str(tmp_path / "memory") + '"}}')
    (tmp_path / "memory").mkdir()

    with mock.patch("antaris_agent.core.config.resolve_config_path", return_value=config_file):
        output = _run_doctor_capture()

    # Data-at-rest must always be honest
    assert "Data-at-rest:" in output
    assert "not yet implemented" in output


# ---------------------------------------------------------------------------
# Missing optional channel dependencies
# ---------------------------------------------------------------------------

def test_doctor_reports_missing_optional_channel_dependency_cleanly(tmp_path):
    """When an optional channel package is missing, doctor should report it
    cleanly without crashing."""
    config_file = tmp_path / "config.json"
    config_file.write_text('{"provider": {"name": "anthropic", "model": "claude-sonnet-4-6"}, '
                           '"security": {"mode": "sandboxed"}, '
                           '"memory": {"store": "' + str(tmp_path / "memory") + '"}}')
    (tmp_path / "memory").mkdir()

    # Force slack_bolt to be "missing" by making import fail
    original_import = __builtins__.__import__ if hasattr(__builtins__, '__import__') else __import__

    def fake_import(name, *args, **kwargs):
        if name == "slack_bolt":
            raise ImportError("No module named 'slack_bolt'")
        return original_import(name, *args, **kwargs)

    with mock.patch("antaris_agent.core.config.resolve_config_path", return_value=config_file):
        with mock.patch("builtins.__import__", side_effect=fake_import):
            output = _run_doctor_capture()

    assert "Slack:" in output
    assert "slack-bolt not installed" in output


# ---------------------------------------------------------------------------
# Memory store writable
# ---------------------------------------------------------------------------

def test_doctor_reports_memory_store_writable(tmp_path):
    """When the memory directory exists and is writable, doctor reports ✅."""
    config_file = tmp_path / "config.json"
    mem_dir = tmp_path / "memory"
    mem_dir.mkdir()
    config_file.write_text('{"provider": {"name": "anthropic", "model": "claude-sonnet-4-6"}, '
                           '"security": {"mode": "sandboxed"}, '
                           '"memory": {"store": "' + str(mem_dir) + '"}}')

    with mock.patch("antaris_agent.core.config.resolve_config_path", return_value=config_file):
        output = _run_doctor_capture()

    assert "Memory store:" in output
    assert "writable" in output
    assert "✅" in output.split("Memory store:")[1].split("\n")[0]


def test_doctor_reports_memory_store_not_writable(tmp_path):
    """When the memory directory exists but isn't writable, doctor reports ❌."""
    config_file = tmp_path / "config.json"
    mem_dir = tmp_path / "memory"
    mem_dir.mkdir()
    config_file.write_text('{"provider": {"name": "anthropic", "model": "claude-sonnet-4-6"}, '
                           '"security": {"mode": "sandboxed"}, '
                           '"memory": {"store": "' + str(mem_dir) + '"}}')

    # Mock os.access to return False for the memory dir
    original_access = os.access

    def fake_access(path, mode):
        if str(path) == str(mem_dir) and mode == os.W_OK:
            return False
        return original_access(path, mode)

    with mock.patch("antaris_agent.core.config.resolve_config_path", return_value=config_file):
        with mock.patch("os.access", side_effect=fake_access):
            output = _run_doctor_capture()

    assert "Memory store:" in output
    assert "not writable" in output


def test_doctor_reports_no_config(tmp_path):
    """When no config file exists, doctor should report it and still run."""
    missing = tmp_path / "nonexistent" / "config.json"

    with mock.patch("antaris_agent.core.config.resolve_config_path", return_value=missing):
        output = _run_doctor_capture()

    assert "Config:" in output
    assert "not found" in output or "❌" in output.split("Config:")[1].split("\n")[0]


def test_doctor_reports_audit_hook_installable():
    """Audit hook should be reported as installable on Python >= 3.8."""
    # sys.addaudithook exists on 3.8+, which is our minimum
    assert hasattr(sys, 'addaudithook'), "Test requires Python 3.8+"

    # Just verify doctor mentions audit hook
    # We can't easily mock resolve_config_path here without a full config,
    # but we can verify the attribute check works
    from antaris_agent.cli import _cmd_doctor
    # The function should not crash
    buf = StringIO()
    with mock.patch("sys.stdout", buf):
        try:
            _cmd_doctor()
        except SystemExit:
            pass
    output = buf.getvalue()
    assert "Audit hook:" in output
    assert "installable" in output


def test_doctor_overall_ready_when_all_good(tmp_path):
    """When everything is fine, overall should say Ready."""
    config_file = tmp_path / "config.json"
    mem_dir = tmp_path / "memory"
    mem_dir.mkdir()
    config_file.write_text('{"provider": {"name": "anthropic", "model": "claude-sonnet-4-6"}, '
                           '"security": {"mode": "sandboxed"}, '
                           '"memory": {"store": "' + str(mem_dir) + '"}}')

    with mock.patch("antaris_agent.core.config.resolve_config_path", return_value=config_file):
        output = _run_doctor_capture()

    assert "Overall:" in output
    assert "Ready to start" in output
