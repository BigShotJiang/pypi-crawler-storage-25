"""Tests for the extension system."""

import asyncio
import pytest
from unittest.mock import MagicMock, AsyncMock, patch

from antaris_agent.extensions.base import (
    Extension, ExtensionContext, ExtensionState, ExtensionMetadata
)
from antaris_agent.extensions.manager import ExtensionManager
from antaris_agent.extensions.loader import ExtensionLoader
from antaris_agent.extensions.webhooks import (
    WebhookManager, WebhookEndpoint, WebhookEvent, WebhookPayload
)
from antaris_agent.extensions.auth_monitor import AuthMonitor, AuthKeyStatus
from antaris_agent.extensions.skills import (
    SkillLoader, SkillRegistry, LoadedSkill, SkillManifest, parse_skill_md
)
from antaris_agent.extensions.model_control import (
    ModelController, ThinkingLevel, MODEL_ALIASES
)


# ── Test Extension Base ───────────────────────────────────────────────────

class SampleExtension(Extension):
    name = "sample"
    version = "1.0.0"
    description = "A test extension"
    
    def __init__(self):
        self.loaded = False
        self.unloaded = False
    
    async def on_load(self, ctx: ExtensionContext):
        self.loaded = True
    
    async def on_unload(self, ctx: ExtensionContext):
        self.unloaded = True


class DependentExtension(Extension):
    name = "dependent"
    version = "1.0.0"
    requires = ["sample"]
    
    async def on_load(self, ctx: ExtensionContext):
        pass


def test_extension_metadata():
    ext = SampleExtension()
    meta = ext.get_metadata()
    assert meta.name == "sample"
    assert meta.version == "1.0.0"
    assert meta.description == "A test extension"


def test_extension_status():
    ext = SampleExtension()
    status = ext.get_status()
    assert status["name"] == "sample"
    assert status["version"] == "1.0.0"


# ── Test Extension Manager ───────────────────────────────────────────────

def test_register_extension():
    manager = ExtensionManager()
    ext = SampleExtension()
    manager.register(ext)
    assert "sample" in manager._extensions
    assert manager._states["sample"] == ExtensionState.REGISTERED


def test_register_duplicate():
    manager = ExtensionManager()
    ext1 = SampleExtension()
    ext2 = SampleExtension()
    manager.register(ext1)
    manager.register(ext2)  # Should replace
    assert len(manager._extensions) == 1


def test_register_no_name():
    manager = ExtensionManager()
    ext = SampleExtension()
    ext.name = ""
    with pytest.raises(ValueError):
        manager.register(ext)


@pytest.mark.asyncio
async def test_load_extension():
    manager = ExtensionManager()
    ext = SampleExtension()
    manager.register(ext)
    
    # Create a mock bot
    bot = MagicMock()
    bot.config = MagicMock()
    bot.config._extensions_config = {}
    bot.config.config_path = "/tmp/test/config.json"
    bot.tool_registry = None
    bot.pipeline = MagicMock()
    
    results = await manager.load_all(bot)
    assert results.get("sample") is True
    assert ext.loaded is True
    assert manager._states["sample"] == ExtensionState.ACTIVE


@pytest.mark.asyncio
async def test_load_with_dependency():
    manager = ExtensionManager()
    sample = SampleExtension()
    dependent = DependentExtension()
    
    manager.register(sample)
    manager.register(dependent)
    
    bot = MagicMock()
    bot.config = MagicMock()
    bot.config._extensions_config = {}
    bot.config.config_path = "/tmp/test/config.json"
    bot.tool_registry = None
    bot.pipeline = MagicMock()
    
    results = await manager.load_all(bot)
    assert results.get("sample") is True
    assert results.get("dependent") is True


@pytest.mark.asyncio
async def test_unload_extension():
    manager = ExtensionManager()
    ext = SampleExtension()
    manager.register(ext)
    
    bot = MagicMock()
    bot.config = MagicMock()
    bot.config._extensions_config = {}
    bot.config.config_path = "/tmp/test/config.json"
    bot.tool_registry = None
    bot.pipeline = MagicMock()
    
    await manager.load_all(bot)
    result = await manager.unload("sample")
    assert result is True
    assert ext.unloaded is True
    assert manager._states["sample"] == ExtensionState.UNLOADED


def test_dependency_resolution():
    manager = ExtensionManager()
    sample = SampleExtension()
    dependent = DependentExtension()
    manager.register(dependent)
    manager.register(sample)
    
    order = manager._resolve_load_order()
    assert order.index("sample") < order.index("dependent")


def test_event_bus():
    manager = ExtensionManager()
    received = []
    
    def handler(event_type, data):
        received.append((event_type, data))
    
    manager.subscribe("test.event", handler)
    manager.emit("test.event", {"key": "value"})
    
    assert len(received) == 1
    assert received[0][0] == "test.event"
    assert received[0][1]["key"] == "value"


def test_status_board():
    manager = ExtensionManager()
    ext = SampleExtension()
    manager.register(ext)
    
    board = manager.status_board()
    assert "sample" in board
    assert "v1.0.0" in board


# ── Test Webhooks ─────────────────────────────────────────────────────────

def test_webhook_endpoint():
    ep = WebhookEndpoint(url="https://example.com/hook", secret="test-secret")
    assert ep.enabled is True
    assert ep.max_retries == 3


def test_webhook_payload():
    payload = WebhookPayload(
        event="test.event",
        timestamp=1234567890.0,
        bot_name="TestBot",
        data={"key": "value"}
    )
    d = payload.to_dict()
    assert d["event"] == "test.event"
    assert d["bot_name"] == "TestBot"
    assert "key" in d["data"]
    
    j = payload.to_json()
    assert '"test.event"' in j


def test_webhook_signature():
    manager = WebhookManager(bot_name="Test")
    sig = manager.sign_payload('{"test": true}', "secret")
    assert len(sig) == 64  # SHA-256 hex digest


def test_webhook_from_config():
    config = {
        "webhooks": {
            "endpoints": [
                {
                    "url": "https://example.com/hook",
                    "secret": "my-secret",
                    "events": ["message.responded"],
                    "enabled": True,
                },
                {
                    "url": "ftp://bad-url",  # Invalid scheme
                    "enabled": True,
                }
            ]
        }
    }
    manager = WebhookManager.from_config(config, bot_name="Test")
    assert len(manager._endpoints) == 1
    assert "https://example.com/hook" in manager._endpoints


def test_webhook_add_remove():
    manager = WebhookManager()
    ep = WebhookEndpoint(url="https://example.com/hook")
    manager.add_endpoint(ep)
    assert len(manager._endpoints) == 1
    
    result = manager.remove_endpoint("https://example.com/hook")
    assert result is True
    assert len(manager._endpoints) == 0


def test_webhook_status():
    manager = WebhookManager(bot_name="Test")
    ep = WebhookEndpoint(url="https://example.com/hook", events=["test"])
    manager.add_endpoint(ep)
    
    status = manager.status()
    assert status["running"] is False
    assert len(status["endpoints"]) == 1


# ── Test Auth Monitor ─────────────────────────────────────────────────────

def test_auth_monitor_record_call(tmp_path):
    monitor = AuthMonitor(config_dir=str(tmp_path))
    
    monitor.record_call("anthropic", success=True)
    health = monitor.get_health()
    
    status = health.providers.get("anthropic")
    assert status is not None
    assert status.total_calls == 1
    assert status.is_valid is True


def test_auth_monitor_rate_limit(tmp_path):
    monitor = AuthMonitor(config_dir=str(tmp_path))
    events = []
    monitor.set_event_callback(lambda t, d: events.append((t, d)))
    
    monitor.record_call("anthropic", success=False, rate_limited=True, rate_limit_reset=9999999999.0)
    
    status = monitor._health.providers["anthropic"]
    assert status.is_rate_limited is True
    assert any(e[0] == "auth.rate_limited" for e in events)


def test_auth_monitor_consecutive_errors(tmp_path):
    monitor = AuthMonitor(config_dir=str(tmp_path))
    events = []
    monitor.set_event_callback(lambda t, d: events.append((t, d)))
    
    for _ in range(3):
        monitor.record_call("anthropic", success=False, error="test error")
    
    status = monitor._health.providers["anthropic"]
    assert status.is_valid is False
    assert any(e[0] == "auth.key_unhealthy" for e in events)


def test_auth_monitor_failover(tmp_path):
    monitor = AuthMonitor(config_dir=str(tmp_path))
    
    # Set up two providers
    monitor.record_call("anthropic", success=True)
    monitor.record_call("openai", success=True)
    
    # Make anthropic unhealthy
    for _ in range(3):
        monitor.record_call("anthropic", success=False, error="error")
    
    # Should suggest failover to openai
    fallback = monitor.should_failover("anthropic")
    assert fallback == "openai"


def test_auth_monitor_status_text(tmp_path):
    monitor = AuthMonitor(config_dir=str(tmp_path))
    monitor.record_call("anthropic", success=True)
    
    text = monitor.get_status_text()
    assert "anthropic" in text
    assert "Auth Status" in text


# ── Test Skills ───────────────────────────────────────────────────────────

def test_parse_skill_md():
    content = """# Weather Lookup
Get current weather and forecasts.

## Config
- api_key: Your weather API key (env: WEATHER_KEY)

## Tools
- weather_lookup: Get current weather for a location
- forecast: Get weather forecast

## Triggers
- "what's the weather"
- "forecast for"
- "temperature in"
"""
    manifest = parse_skill_md(content)
    assert manifest.name == "Weather Lookup"
    assert "weather" in manifest.description.lower()
    assert "api_key" in manifest.config_vars
    assert "weather_lookup" in manifest.tool_names
    assert "forecast" in manifest.tool_names
    assert len(manifest.triggers) == 3
    assert "what's the weather" in manifest.triggers


def test_skill_registry():
    registry = SkillRegistry()
    
    manifest = SkillManifest(
        name="test-skill",
        description="A test skill",
        triggers=["test trigger", "run test"],
    )
    skill = LoadedSkill(manifest=manifest, tools=[])
    registry.register(skill)
    
    assert len(registry.list_skills()) == 1
    assert registry.match_skills("please run test now") == [skill]
    assert registry.match_skills("something unrelated") == []


def test_skill_context_injection():
    registry = SkillRegistry()
    
    manifest = SkillManifest(
        name="test-skill",
        instructions="# Test Skill\nDo the test thing.",
        triggers=["do test"],
    )
    skill = LoadedSkill(manifest=manifest)
    registry.register(skill)
    
    context = registry.get_context_for_message("please do test")
    assert "Active Skills" in context
    assert "test-skill" in context


def test_skill_status_text():
    registry = SkillRegistry()
    text = registry.status_text()
    assert "No custom skills" in text
    
    manifest = SkillManifest(name="test", description="A test")
    registry.register(LoadedSkill(manifest=manifest))
    text = registry.status_text()
    assert "test" in text


# ── Test Model Control ────────────────────────────────────────────────────

def test_model_controller_set_model():
    ctrl = ModelController()
    model, provider, msg = ctrl.set_model("user1", "opus")
    assert model == "claude-opus-4-6"
    assert provider == "anthropic"
    assert "opus" in msg.lower() or "claude" in msg.lower()


def test_model_controller_auto_reset():
    ctrl = ModelController()
    ctrl.set_model("user1", "opus")
    assert ctrl.get_model_for_user("user1") == "claude-opus-4-6"
    
    ctrl.set_model("user1", "auto")
    assert ctrl.get_model_for_user("user1") is None


def test_model_controller_thinking_levels():
    ctrl = ModelController()
    msg = ctrl.set_thinking("user1", "high")
    assert "high" in msg.lower()
    
    level, budget = ctrl.get_thinking_for_user("user1")
    assert level == "high"
    assert budget == 16384


def test_model_controller_thinking_invalid():
    ctrl = ModelController()
    msg = ctrl.set_thinking("user1", "invalid")
    assert "invalid" in msg.lower()


def test_model_controller_duration():
    import time
    ctrl = ModelController()
    ctrl.set_model("user1", "opus", duration_minutes=1)
    assert ctrl.get_model_for_user("user1") == "claude-opus-4-6"
    
    # Manually expire
    ctrl._overrides["user1"].expires_at = time.time() - 1
    assert ctrl.get_model_for_user("user1") is None


def test_model_controller_global():
    ctrl = ModelController()
    msg = ctrl.set_global("haiku")
    assert "haiku" in msg.lower() or "claude" in msg.lower()
    
    # User without personal override should get global
    override = ctrl.get_override("some_user")
    assert override is not None
    assert override.model == "claude-haiku-4-5-20251001"


def test_model_aliases_complete():
    # Verify key aliases resolve correctly
    assert MODEL_ALIASES["opus"][0] == "claude-opus-4-6"
    assert MODEL_ALIASES["sonnet"][0] == "claude-sonnet-4-6"
    assert MODEL_ALIASES["gpt"][0] == "gpt-5.4"
    assert MODEL_ALIASES["gemini"][0] == "gemini-3.1-pro"
    assert MODEL_ALIASES["fast"][1] == "anthropic"
    assert MODEL_ALIASES["cheap"][1] == "ollama"


def test_model_controller_status():
    ctrl = ModelController()
    ctrl.set_model("user1", "opus")
    text = ctrl.status_text("user1")
    assert "Model Control" in text
    assert "claude-opus" in text.lower() or "opus" in text.lower()


# ── Test Extension Loader ────────────────────────────────────────────────

def test_loader_no_extensions_dir(tmp_path):
    loader = ExtensionLoader(str(tmp_path))
    extensions = loader.discover_all()
    assert extensions == []


def test_loader_empty_extensions_dir(tmp_path):
    (tmp_path / "extensions").mkdir()
    loader = ExtensionLoader(str(tmp_path))
    extensions = loader.discover_all()
    assert extensions == []
