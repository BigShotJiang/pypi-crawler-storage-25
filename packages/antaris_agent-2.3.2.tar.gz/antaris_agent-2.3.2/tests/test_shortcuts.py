"""Tests for ShortcutLearner and !shortcuts command integration."""
import json
import pytest
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

from antaris_agent.core.shortcuts import ShortcutLearner, MIN_REPETITIONS, MAX_SHORTCUTS


# ── ShortcutLearner unit tests ────────────────────────────────────────────────

class TestShortcutLearnerObserve:
    def test_observe_tracks_pattern(self, tmp_path):
        learner = ShortcutLearner(tmp_path)
        learner.observe("u1", "check bot", "running pytest on antaris-agent...")
        data = json.loads((tmp_path / "u1.json").read_text())
        assert "check bot" in data["patterns"]

    def test_observe_increments_count(self, tmp_path):
        learner = ShortcutLearner(tmp_path)
        for _ in range(2):
            learner.observe("u1", "check bot", "running pytest on antaris-agent...")
        data = json.loads((tmp_path / "u1.json").read_text())
        sig = learner._extract_action_sig("running pytest on antaris-agent...")
        assert data["patterns"]["check bot"][sig] == 2

    def test_observe_learns_after_min_repetitions(self, tmp_path):
        learner = ShortcutLearner(tmp_path)
        result = None
        for i in range(MIN_REPETITIONS):
            result = learner.observe("u1", "check bot", "running pytest on antaris-agent...")
        assert result is not None
        assert "check bot" in result

    def test_observe_does_not_learn_before_threshold(self, tmp_path):
        learner = ShortcutLearner(tmp_path)
        for _ in range(MIN_REPETITIONS - 1):
            result = learner.observe("u1", "check bot", "running tests now...")
        assert result is None

    def test_observe_ignores_long_messages(self, tmp_path):
        learner = ShortcutLearner(tmp_path)
        long_msg = "this is a very long message with more than eight words total"
        for _ in range(MIN_REPETITIONS + 5):
            result = learner.observe("u1", long_msg, "some bot action")
        assert result is None
        data = learner._load("u1")
        assert long_msg.lower() not in data["patterns"]

    def test_observe_ignores_very_short_messages(self, tmp_path):
        learner = ShortcutLearner(tmp_path)
        for _ in range(MIN_REPETITIONS + 5):
            result = learner.observe("u1", "hi", "hello there friend")
        assert result is None

    def test_observe_no_duplicate_shortcut(self, tmp_path):
        learner = ShortcutLearner(tmp_path)
        # Learn it once
        for _ in range(MIN_REPETITIONS):
            learner.observe("u1", "check bot", "running tests...")
        # Keep observing after it was already learned
        for _ in range(5):
            result = learner.observe("u1", "check bot", "running tests...")
        # Should NOT return newly_learned again
        assert result is None

    def test_observe_returns_none_for_empty_bot_action(self, tmp_path):
        learner = ShortcutLearner(tmp_path)
        result = learner.observe("u1", "check bot", "")
        assert result is None

    def test_observe_per_user_isolation(self, tmp_path):
        learner = ShortcutLearner(tmp_path)
        for _ in range(MIN_REPETITIONS):
            learner.observe("u1", "check bot", "running tests...")
        # u2 has no shortcuts
        assert learner.expand("u2", "check bot") is None


class TestShortcutLearnerExpand:
    def test_expand_returns_expansion_for_learned_shortcut(self, tmp_path):
        learner = ShortcutLearner(tmp_path)
        for _ in range(MIN_REPETITIONS):
            learner.observe("u1", "check bot", "running pytest on antaris-agent...")
        expansion = learner.expand("u1", "check bot")
        assert expansion is not None
        assert "running pytest" in expansion

    def test_expand_returns_none_for_unknown(self, tmp_path):
        learner = ShortcutLearner(tmp_path)
        assert learner.expand("u1", "unknown phrase") is None

    def test_expand_case_insensitive(self, tmp_path):
        learner = ShortcutLearner(tmp_path)
        for _ in range(MIN_REPETITIONS):
            learner.observe("u1", "Check Bot", "running tests...")
        assert learner.expand("u1", "CHECK BOT") is not None
        assert learner.expand("u1", "check bot") is not None

    def test_expand_strips_whitespace(self, tmp_path):
        learner = ShortcutLearner(tmp_path)
        for _ in range(MIN_REPETITIONS):
            learner.observe("u1", "check bot", "running tests...")
        assert learner.expand("u1", "  check bot  ") is not None


class TestShortcutLearnerGetContext:
    def test_get_context_formats_for_learned_shortcut(self, tmp_path):
        learner = ShortcutLearner(tmp_path)
        for _ in range(MIN_REPETITIONS):
            learner.observe("u1", "check bot", "running pytest on antaris-agent...")
        ctx = learner.get_context("u1", "check bot")
        assert "## Learned Shortcut" in ctx
        assert "The user often says this when they mean:" in ctx
        assert "running pytest" in ctx

    def test_get_context_returns_empty_for_unknown(self, tmp_path):
        learner = ShortcutLearner(tmp_path)
        assert learner.get_context("u1", "unknown phrase") == ""

    def test_get_context_returns_empty_for_new_user(self, tmp_path):
        learner = ShortcutLearner(tmp_path)
        assert learner.get_context("brand_new_user", "anything") == ""


class TestShortcutLearnerListShortcuts:
    def test_list_shortcuts_returns_all(self, tmp_path):
        learner = ShortcutLearner(tmp_path)
        for _ in range(MIN_REPETITIONS):
            learner.observe("u1", "check bot", "running tests...")
        for _ in range(MIN_REPETITIONS):
            learner.observe("u1", "deploy it", "deploying to production...")
        shortcuts = learner.list_shortcuts("u1")
        phrases = [s["phrase"] for s in shortcuts]
        assert "check bot" in phrases
        assert "deploy it" in phrases

    def test_list_shortcuts_empty_for_new_user(self, tmp_path):
        learner = ShortcutLearner(tmp_path)
        assert learner.list_shortcuts("u1") == []

    def test_list_shortcuts_includes_phrase_expansion_count(self, tmp_path):
        learner = ShortcutLearner(tmp_path)
        for _ in range(MIN_REPETITIONS):
            learner.observe("u1", "check bot", "running tests...")
        items = learner.list_shortcuts("u1")
        assert len(items) == 1
        assert "phrase" in items[0]
        assert "expansion" in items[0]
        assert "count" in items[0]
        assert items[0]["count"] == MIN_REPETITIONS


class TestShortcutLearnerRemove:
    def test_remove_deletes_shortcut(self, tmp_path):
        learner = ShortcutLearner(tmp_path)
        for _ in range(MIN_REPETITIONS):
            learner.observe("u1", "check bot", "running tests...")
        assert learner.remove("u1", "check bot") is True
        assert learner.expand("u1", "check bot") is None

    def test_remove_clears_pattern_history(self, tmp_path):
        learner = ShortcutLearner(tmp_path)
        for _ in range(MIN_REPETITIONS):
            learner.observe("u1", "check bot", "running tests...")
        learner.remove("u1", "check bot")
        data = learner._load("u1")
        assert "check bot" not in data["patterns"]

    def test_remove_returns_false_for_unknown(self, tmp_path):
        learner = ShortcutLearner(tmp_path)
        assert learner.remove("u1", "nonexistent phrase") is False

    def test_remove_case_insensitive(self, tmp_path):
        learner = ShortcutLearner(tmp_path)
        for _ in range(MIN_REPETITIONS):
            learner.observe("u1", "check bot", "running tests...")
        assert learner.remove("u1", "CHECK BOT") is True
        assert learner.expand("u1", "check bot") is None

    def test_after_remove_can_relearn(self, tmp_path):
        """After removing, the pattern counter is cleared so it won't instantly re-learn."""
        learner = ShortcutLearner(tmp_path)
        for _ in range(MIN_REPETITIONS):
            learner.observe("u1", "check bot", "running tests...")
        learner.remove("u1", "check bot")
        # One observation after removal should not re-learn immediately
        result = learner.observe("u1", "check bot", "running tests...")
        assert result is None


class TestShortcutLearnerMaxLimit:
    def test_max_shortcuts_not_exceeded(self, tmp_path):
        learner = ShortcutLearner(tmp_path)
        # Fill up to MAX_SHORTCUTS
        for i in range(MAX_SHORTCUTS):
            phrase = f"phrase {i}"
            for _ in range(MIN_REPETITIONS):
                learner.observe("u1", phrase, f"action {i} happening now...")
        # One more shortcut beyond the limit
        for _ in range(MIN_REPETITIONS):
            result = learner.observe("u1", "overflow phrase", "overflow action...")
        shortcuts = learner.list_shortcuts("u1")
        assert len(shortcuts) <= MAX_SHORTCUTS

    def test_max_shortcuts_boundary(self, tmp_path):
        learner = ShortcutLearner(tmp_path)
        for i in range(MAX_SHORTCUTS):
            phrase = f"cmd {i}"
            for _ in range(MIN_REPETITIONS):
                learner.observe("u1", phrase, f"response {i} here now...")
        assert len(learner.list_shortcuts("u1")) == MAX_SHORTCUTS


class TestShortcutLearnerPersistence:
    def test_persistence_roundtrip(self, tmp_path):
        learner1 = ShortcutLearner(tmp_path)
        for _ in range(MIN_REPETITIONS):
            learner1.observe("u1", "check bot", "running tests now...")
        # New instance, same store
        learner2 = ShortcutLearner(tmp_path)
        expansion = learner2.expand("u1", "check bot")
        assert expansion is not None
        assert "running tests" in expansion

    def test_partial_patterns_persist(self, tmp_path):
        learner1 = ShortcutLearner(tmp_path)
        learner1.observe("u1", "check bot", "running tests...")
        learner1.observe("u1", "check bot", "running tests...")
        # Not yet learned (only 2 of MIN_REPETITIONS)
        learner2 = ShortcutLearner(tmp_path)
        # 3rd observation on new instance should learn it
        result = learner2.observe("u1", "check bot", "running tests...")
        assert result is not None

    def test_corrupted_json_returns_empty(self, tmp_path):
        bad_file = tmp_path / "u1.json"
        bad_file.write_text("not valid json {{{{")
        learner = ShortcutLearner(tmp_path)
        assert learner.list_shortcuts("u1") == []
        assert learner.expand("u1", "anything") is None


class TestExtractActionSig:
    def test_strips_filler_sure(self, tmp_path):
        learner = ShortcutLearner(tmp_path)
        sig = learner._extract_action_sig("Sure, running your tests now...")
        assert not sig.startswith("sure, ")

    def test_strips_filler_ok(self, tmp_path):
        learner = ShortcutLearner(tmp_path)
        sig = learner._extract_action_sig("Ok, deploying to server...")
        assert not sig.startswith("ok, ")

    def test_strips_filler_done(self, tmp_path):
        learner = ShortcutLearner(tmp_path)
        sig = learner._extract_action_sig("Done! Task complete.")
        assert not sig.startswith("done! ")

    def test_truncates_to_80_chars(self, tmp_path):
        learner = ShortcutLearner(tmp_path)
        long = "x" * 200
        sig = learner._extract_action_sig(long)
        assert len(sig) <= 80

    def test_empty_returns_empty(self, tmp_path):
        learner = ShortcutLearner(tmp_path)
        assert learner._extract_action_sig("") == ""

    def test_normalizes_to_lowercase(self, tmp_path):
        learner = ShortcutLearner(tmp_path)
        sig = learner._extract_action_sig("Running Pytest On Antaris Agent")
        assert sig == sig.lower()


# ── Pipeline integration test ─────────────────────────────────────────────────

class TestShortcutsInPipeline:
    def _make_pipeline(self, tmp_path, shortcuts=None):
        from antaris_agent.core.pipeline import Pipeline

        config = MagicMock()
        config.model = "test-model"
        config.rate_limit_messages = 20
        config.rate_limit_window_seconds = 60

        memory = MagicMock()
        memory.recall = AsyncMock(return_value=[])
        memory.ingest = AsyncMock()

        guard = MagicMock()
        guard.check_input = AsyncMock(return_value=(True, ""))
        guard.check_output = AsyncMock(return_value=(True, "hello from bot"))

        persona = MagicMock()
        persona.config_dir = ""
        persona.build_system_prompt = MagicMock(return_value="You are a helpful bot.")
        persona.update_user_context = MagicMock()

        captured = {"prompts": []}

        async def mock_complete(messages, system=None, model=None, **kwargs):
            captured["prompts"].append(system)
            resp = MagicMock()
            resp.content = "hello from bot"
            resp.input_tokens = 10
            resp.output_tokens = 5
            resp.cost_usd = 0.0
            return resp

        llm = MagicMock()
        llm.complete = mock_complete

        adapter = MagicMock()
        adapter.format_for_surface = MagicMock(side_effect=lambda x: x)

        pipeline = Pipeline(
            config=config,
            memory=memory,
            guard=guard,
            persona=persona,
            llm=llm,
            shortcuts=shortcuts,
        )
        return pipeline, adapter, captured

    def _make_inbound(self, text, user_id="u1"):
        from antaris_agent.channels.base import InboundMessage
        return InboundMessage(
            id="msg1",
            user_id=user_id,
            user_name="User",
            channel_id="ch1",
            platform="discord",
            text=text,
        )

    @pytest.mark.asyncio
    async def test_shortcut_context_injected_into_system_prompt(self, tmp_path):
        shortcuts = ShortcutLearner(tmp_path)
        for _ in range(MIN_REPETITIONS):
            shortcuts.observe("u1", "check bot", "running pytest on antaris-agent tests...")

        pipeline, adapter, captured = self._make_pipeline(tmp_path, shortcuts=shortcuts)
        await pipeline.process(self._make_inbound("check bot"), adapter)

        assert len(captured["prompts"]) == 1
        prompt = captured["prompts"][0]
        assert "Learned Shortcut" in prompt
        assert "running pytest" in prompt

    @pytest.mark.asyncio
    async def test_no_shortcut_no_injection(self, tmp_path):
        shortcuts = ShortcutLearner(tmp_path)
        # No shortcuts learned

        pipeline, adapter, captured = self._make_pipeline(tmp_path, shortcuts=shortcuts)
        await pipeline.process(self._make_inbound("check bot"), adapter)

        prompt = captured["prompts"][0]
        assert "Learned Shortcut" not in prompt

    @pytest.mark.asyncio
    async def test_shortcut_observation_happens_after_llm(self, tmp_path):
        shortcuts = ShortcutLearner(tmp_path)
        pipeline, adapter, _ = self._make_pipeline(tmp_path, shortcuts=shortcuts)

        # Disable cooldown so rapid messages are all processed
        pipeline._cooldown_seconds = 0.0

        # Send same short message MIN_REPETITIONS times
        for _ in range(MIN_REPETITIONS):
            await pipeline.process(self._make_inbound("check bot"), adapter)

        # After enough repetitions, shortcut should be learned
        assert shortcuts.expand("u1", "check bot") is not None

    @pytest.mark.asyncio
    async def test_pipeline_works_without_shortcuts(self, tmp_path):
        pipeline, adapter, captured = self._make_pipeline(tmp_path, shortcuts=None)
        result = await pipeline.process(self._make_inbound("hello"), adapter)
        assert result.success
        assert result.response_text == "hello from bot"


# ── !shortcuts command tests ──────────────────────────────────────────────────

class TestShortcutsCommand:
    def _make_dispatcher(self, tmp_path):
        from antaris_agent.core.commands import CommandDispatcher

        bot = MagicMock()
        learner = ShortcutLearner(tmp_path / "shortcuts")
        bot.shortcuts = learner

        dispatcher = CommandDispatcher(bot=bot)
        return dispatcher, learner

    def _make_inbound(self, text, user_id="u1"):
        from antaris_agent.channels.base import InboundMessage
        return InboundMessage(
            id="msg1",
            user_id=user_id,
            user_name="User",
            channel_id="ch1",
            platform="discord",
            text=text,
        )

    @pytest.mark.asyncio
    async def test_shortcuts_empty_list(self, tmp_path):
        dispatcher, _ = self._make_dispatcher(tmp_path)
        result = await dispatcher.dispatch(self._make_inbound("!shortcuts"))
        assert result.handled
        assert "No shortcuts" in result.response or "no shortcuts" in result.response.lower()

    @pytest.mark.asyncio
    async def test_shortcuts_shows_learned(self, tmp_path):
        dispatcher, learner = self._make_dispatcher(tmp_path)
        for _ in range(MIN_REPETITIONS):
            learner.observe("u1", "check bot", "running tests now...")
        result = await dispatcher.dispatch(self._make_inbound("!shortcuts"))
        assert result.handled
        assert "check bot" in result.response

    @pytest.mark.asyncio
    async def test_shortcuts_remove_success(self, tmp_path):
        dispatcher, learner = self._make_dispatcher(tmp_path)
        for _ in range(MIN_REPETITIONS):
            learner.observe("u1", "check bot", "running tests now...")
        result = await dispatcher.dispatch(self._make_inbound("!shortcuts remove check bot"))
        assert result.handled
        assert "removed" in result.response.lower() or "check bot" in result.response
        assert learner.expand("u1", "check bot") is None

    @pytest.mark.asyncio
    async def test_shortcuts_remove_not_found(self, tmp_path):
        dispatcher, _ = self._make_dispatcher(tmp_path)
        result = await dispatcher.dispatch(self._make_inbound("!shortcuts remove nonexistent"))
        assert result.handled
        assert "No shortcut" in result.response or "not found" in result.response.lower() or "nonexistent" in result.response

    @pytest.mark.asyncio
    async def test_shortcuts_remove_missing_phrase(self, tmp_path):
        dispatcher, _ = self._make_dispatcher(tmp_path)
        result = await dispatcher.dispatch(self._make_inbound("!shortcuts remove"))
        assert result.handled
        assert "Usage" in result.response or "usage" in result.response.lower()

    @pytest.mark.asyncio
    async def test_shortcuts_unavailable(self, tmp_path):
        from antaris_agent.core.commands import CommandDispatcher
        bot = MagicMock()
        bot.shortcuts = None
        dispatcher = CommandDispatcher(bot=bot)
        result = await dispatcher.dispatch(self._make_inbound("!shortcuts"))
        assert result.handled
        assert "not available" in result.response.lower()

    @pytest.mark.asyncio
    async def test_help_includes_shortcuts(self, tmp_path):
        dispatcher, _ = self._make_dispatcher(tmp_path)
        result = await dispatcher.dispatch(self._make_inbound("!help"))
        assert result.handled
        assert "!shortcuts" in result.response
