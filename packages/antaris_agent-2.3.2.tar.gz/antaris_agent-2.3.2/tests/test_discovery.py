"""Tests for the capability discovery / reminder system."""
import json
import time
import pytest
from pathlib import Path
from unittest.mock import MagicMock, patch

from antaris_agent.core.config import Config
from antaris_agent.core.discovery import (
    DiscoveryManager,
    DiscoveryState,
    DiscoveryHint,
    CategoryState,
    ALL_CATEGORIES,
    CATEGORY_GENERAL,
    CATEGORY_INTEGRATIONS,
    CATEGORY_AUTOMATION,
    CATEGORY_POWER_USER,
    CATEGORY_LABELS,
    load_discovery_state,
    save_discovery_state,
    format_hint_markdown,
    format_hint_plain,
    format_status_markdown,
    _check_general_setup,
    _check_integrations,
    _check_automation,
    _check_power_user,
)


# ── Fixtures ──────────────────────────────────────────────────────────────


@pytest.fixture
def tmp_config_dir(tmp_path):
    """Temporary config directory."""
    return tmp_path


@pytest.fixture
def base_config(tmp_path):
    """A minimal Config with all defaults."""
    cfg = Config()
    cfg.config_path = str(tmp_path / "config.json")
    cfg.api_key = "sk-test-key"
    cfg.provider_name = "anthropic"
    cfg.discord_enabled = False
    cfg.telegram_enabled = False
    cfg.slack_enabled = False
    cfg._tools_config = {}
    cfg.heartbeat_enabled = False
    cfg.per_turn_recall = True
    cfg.extensions_enabled = True
    cfg.security_mode = "sandboxed"
    cfg.anthropic_api_key = ""
    cfg.openai_api_key = ""
    cfg.google_api_key = ""
    cfg.owner_user_id = ""
    return cfg


@pytest.fixture
def full_config(tmp_path):
    """A fully configured Config (no hints should surface)."""
    cfg = Config()
    cfg.config_path = str(tmp_path / "config.json")
    cfg.api_key = "sk-test-key"
    cfg.provider_name = "anthropic"
    cfg.discord_enabled = True
    cfg.discord_token = "MTI3..."
    cfg.telegram_enabled = True
    cfg.telegram_token = "123456:ABC"
    cfg.slack_enabled = True
    cfg.slack_bot_token = "xoxb-test"
    cfg._tools_config = {
        "brave_search": {"enabled": True, "apiKey": "BSA-test"},
        "shell": {"enabled": True},
        "file_ops": {"enabled": True},
        "web_fetch": {"enabled": True},
        "mcp_servers": [{"name": "test", "transport": "stdio"}],
    }
    cfg.heartbeat_enabled = True
    cfg.per_turn_recall = True
    cfg.extensions_enabled = True
    cfg.security_mode = "standard"
    cfg.anthropic_api_key = "sk-ant-test"
    cfg.openai_api_key = "sk-openai-test"
    cfg.google_api_key = "AIza-test"
    cfg.owner_user_id = "123456789012345678"

    # Create SOUL.md and USER.md
    (tmp_path / "SOUL.md").write_text("I am a fully configured bot with a real personality that spans multiple lines and has depth.")
    (tmp_path / "USER.md").write_text("# About the user\nThey like coding.\n")

    return cfg


# ── State persistence ─────────────────────────────────────────────────────


class TestStatePersistence:
    def test_load_fresh_state(self, tmp_config_dir):
        """Loading from empty dir returns defaults."""
        state = load_discovery_state(tmp_config_dir)
        assert state.enabled is True
        assert state.globally_disabled is False
        assert len(state.categories) == len(ALL_CATEGORIES)

    def test_save_and_load_roundtrip(self, tmp_config_dir):
        """State survives save/load cycle."""
        state = DiscoveryState()
        state.globally_disabled = True
        state.min_interval_hours = 12.0
        state.snooze_hours = 48.0
        state.messages_between_hints = 50
        state.categories[CATEGORY_GENERAL].permanently_disabled = True
        state.categories[CATEGORY_INTEGRATIONS].snoozed_until = time.time() + 3600
        state.categories[CATEGORY_AUTOMATION].show_count = 3

        save_discovery_state(tmp_config_dir, state)
        loaded = load_discovery_state(tmp_config_dir)

        assert loaded.globally_disabled is True
        assert loaded.min_interval_hours == 12.0
        assert loaded.snooze_hours == 48.0
        assert loaded.messages_between_hints == 50
        assert loaded.categories[CATEGORY_GENERAL].permanently_disabled is True
        assert loaded.categories[CATEGORY_INTEGRATIONS].snoozed_until > time.time()
        assert loaded.categories[CATEGORY_AUTOMATION].show_count == 3

    def test_load_corrupt_file(self, tmp_config_dir):
        """Corrupt state file returns defaults."""
        (tmp_config_dir / "discovery_state.json").write_text("not json")
        state = load_discovery_state(tmp_config_dir)
        assert state.enabled is True
        assert len(state.categories) == len(ALL_CATEGORIES)

    def test_load_partial_state(self, tmp_config_dir):
        """Partial state file fills missing categories."""
        data = {"enabled": True, "categories": {"general_setup": {"show_count": 5}}}
        (tmp_config_dir / "discovery_state.json").write_text(json.dumps(data))
        state = load_discovery_state(tmp_config_dir)
        assert state.categories[CATEGORY_GENERAL].show_count == 5
        # Other categories should exist with defaults
        assert CATEGORY_AUTOMATION in state.categories
        assert state.categories[CATEGORY_AUTOMATION].show_count == 0


# ── Config inspection ─────────────────────────────────────────────────────


class TestGeneralSetupCheck:
    def test_missing_soul_md(self, base_config, tmp_path):
        """Detects missing SOUL.md."""
        hints = _check_general_setup(base_config)
        soul_hints = [h for h in hints if "personality" in h.title.lower() or "persona" in h.title.lower()]
        assert len(soul_hints) >= 1

    def test_minimal_soul_md(self, base_config, tmp_path):
        """Detects SOUL.md with minimal content."""
        (tmp_path / "SOUL.md").write_text("AWAKENING_NEEDED\n")
        hints = _check_general_setup(base_config)
        soul_hints = [h for h in hints if "personal" in h.title.lower()]
        assert len(soul_hints) >= 1

    def test_good_soul_md(self, full_config, tmp_path):
        """No soul hint when SOUL.md is well-populated."""
        hints = _check_general_setup(full_config)
        soul_hints = [h for h in hints if "personality" in h.title.lower()]
        assert len(soul_hints) == 0

    def test_missing_user_md(self, base_config, tmp_path):
        """Detects missing USER.md."""
        hints = _check_general_setup(base_config)
        user_hints = [h for h in hints if "user" in h.title.lower() or "about you" in h.title.lower()]
        assert len(user_hints) >= 1


class TestIntegrationsCheck:
    def test_no_channels(self, base_config):
        """Detects zero channels configured."""
        hints = _check_integrations(base_config)
        channel_hints = [h for h in hints if "channel" in h.title.lower() or "messaging" in h.title.lower()]
        assert len(channel_hints) >= 1

    def test_one_channel(self, base_config):
        """With one channel, suggests adding another."""
        base_config.discord_enabled = True
        base_config.discord_token = "MTI3..."
        hints = _check_integrations(base_config)
        add_hints = [h for h in hints if "another" in h.title.lower()]
        assert len(add_hints) >= 1

    def test_missing_owner_id(self, base_config):
        """Detects missing owner_user_id."""
        hints = _check_integrations(base_config)
        owner_hints = [h for h in hints if "owner" in h.title.lower()]
        assert len(owner_hints) >= 1

    def test_all_channels_and_owner(self, full_config):
        """No channel hints when all are configured."""
        hints = _check_integrations(full_config)
        channel_hints = [h for h in hints if "connect" in h.title.lower() and "channel" in h.title.lower()]
        assert len(channel_hints) == 0


class TestAutomationCheck:
    def test_no_tools(self, base_config):
        """Detects no tools enabled."""
        hints = _check_automation(base_config)
        tool_hints = [h for h in hints if "tool" in h.title.lower()]
        assert len(tool_hints) >= 1

    def test_some_tools_missing(self, base_config):
        """With some tools, suggests missing ones."""
        base_config._tools_config = {"web_fetch": {"enabled": True}}
        hints = _check_automation(base_config)
        # Should still suggest shell, search, file_ops
        expand_hints = [h for h in hints if "expand" in h.title.lower() or "toolkit" in h.title.lower()]
        assert len(expand_hints) >= 1

    def test_heartbeat_disabled(self, base_config):
        """Detects heartbeat not enabled."""
        hints = _check_automation(base_config)
        hb_hints = [h for h in hints if "heartbeat" in h.title.lower()]
        assert len(hb_hints) >= 1

    def test_no_mcp(self, base_config):
        """Detects no MCP servers when tools are enabled."""
        base_config._tools_config = {
            "shell": {"enabled": True},
            "file_ops": {"enabled": True},
            "brave_search": {"enabled": True, "apiKey": "test"},
        }
        hints = _check_automation(base_config)
        mcp_hints = [h for h in hints if "mcp" in h.title.lower()]
        assert len(mcp_hints) >= 1


class TestPowerUserCheck:
    def test_sandboxed_security(self, base_config):
        """Suggests reviewing security when in sandboxed mode."""
        hints = _check_power_user(base_config)
        sec_hints = [h for h in hints if "security" in h.title.lower()]
        assert len(sec_hints) >= 1

    def test_no_multi_provider(self, base_config):
        """Detects missing multi-provider keys."""
        hints = _check_power_user(base_config)
        mp_hints = [h for h in hints if "multi-provider" in h.title.lower() or "routing" in h.title.lower()]
        assert len(mp_hints) >= 1

    def test_fully_configured_power_user(self, full_config):
        """Minimal hints when fully configured."""
        hints = _check_power_user(full_config)
        # Should have very few or no hints
        high_priority = [h for h in hints if h.priority >= 5]
        assert len(high_priority) == 0


# ── DiscoveryManager ──────────────────────────────────────────────────────


class TestDiscoveryManager:
    def test_get_all_hints(self, tmp_config_dir, base_config):
        """get_all_hints returns hints for unconfigured features."""
        dm = DiscoveryManager(tmp_config_dir)
        hints = dm.get_all_hints(base_config)
        assert len(hints) > 0
        # Should be sorted by priority (descending)
        priorities = [h.priority for h in hints]
        assert priorities == sorted(priorities, reverse=True)

    def test_get_next_hint_returns_highest_priority(self, tmp_config_dir, base_config):
        """get_next_hint returns the highest priority eligible hint."""
        dm = DiscoveryManager(tmp_config_dir)
        hint = dm.get_next_hint(base_config, message_count=100)
        assert hint is not None
        all_hints = dm.get_all_hints(base_config)
        assert hint.priority == all_hints[0].priority

    def test_get_next_hint_respects_message_spacing(self, tmp_config_dir, base_config):
        """No hint if not enough messages have passed."""
        dm = DiscoveryManager(tmp_config_dir)
        # Show a hint at message 10
        hint = dm.get_next_hint(base_config, message_count=10)
        assert hint is not None
        dm.mark_shown(hint.category, message_count=10)

        # Only 5 messages later — should be None
        hint2 = dm.get_next_hint(base_config, message_count=15)
        assert hint2 is None

    def test_get_next_hint_respects_time_interval(self, tmp_config_dir, base_config):
        """No hint if min_interval_hours hasn't passed."""
        dm = DiscoveryManager(tmp_config_dir)
        dm.state.messages_between_hints = 1  # bypass message spacing
        
        hint = dm.get_next_hint(base_config, message_count=100)
        assert hint is not None
        dm.mark_shown(hint.category, message_count=100)

        # Same category should not appear immediately
        hint2 = dm.get_next_hint(base_config, message_count=200)
        # If there's only one category with hints, hint2 should be None or a different category
        if hint2 is not None:
            assert hint2.category != hint.category or hint2 is None

    def test_get_next_hint_globally_disabled(self, tmp_config_dir, base_config):
        """No hint when globally disabled."""
        dm = DiscoveryManager(tmp_config_dir)
        dm.disable_all()
        hint = dm.get_next_hint(base_config, message_count=100)
        assert hint is None

    def test_get_next_hint_category_disabled(self, tmp_config_dir, base_config):
        """Disabled category is skipped."""
        dm = DiscoveryManager(tmp_config_dir)
        dm.state.messages_between_hints = 1

        # Disable all categories except one
        all_hints = dm.get_all_hints(base_config)
        categories_with_hints = set(h.category for h in all_hints)
        
        for cat in categories_with_hints:
            dm.disable(cat)

        hint = dm.get_next_hint(base_config, message_count=100)
        assert hint is None

    def test_get_next_hint_snoozed(self, tmp_config_dir, base_config):
        """Snoozed category is skipped."""
        dm = DiscoveryManager(tmp_config_dir)
        dm.state.messages_between_hints = 1

        all_hints = dm.get_all_hints(base_config)
        categories_with_hints = set(h.category for h in all_hints)

        for cat in categories_with_hints:
            dm.snooze(cat, hours=24)

        hint = dm.get_next_hint(base_config, message_count=100)
        assert hint is None

    def test_fully_configured_no_hints(self, tmp_config_dir, full_config):
        """No hints for a fully configured bot."""
        dm = DiscoveryManager(tmp_config_dir)
        hints = dm.get_all_hints(full_config)
        # May have minor suggestions (like "add another channel") but nothing high-priority
        high_priority = [h for h in hints if h.priority >= 8]
        assert len(high_priority) == 0


class TestDiscoveryUserActions:
    def test_dismiss(self, tmp_config_dir):
        """Dismiss sets the dismissed flag."""
        dm = DiscoveryManager(tmp_config_dir)
        dm.dismiss(CATEGORY_GENERAL)
        assert dm.state.categories[CATEGORY_GENERAL].dismissed is True

    def test_snooze(self, tmp_config_dir):
        """Snooze sets snoozed_until."""
        dm = DiscoveryManager(tmp_config_dir)
        dm.snooze(CATEGORY_GENERAL, hours=12)
        cs = dm.state.categories[CATEGORY_GENERAL]
        assert cs.snoozed_until > time.time()
        assert cs.snoozed_until < time.time() + (13 * 3600)

    def test_disable_and_enable(self, tmp_config_dir):
        """Disable/enable toggling works."""
        dm = DiscoveryManager(tmp_config_dir)
        dm.disable(CATEGORY_GENERAL)
        assert dm.state.categories[CATEGORY_GENERAL].permanently_disabled is True

        dm.enable(CATEGORY_GENERAL)
        assert dm.state.categories[CATEGORY_GENERAL].permanently_disabled is False

    def test_disable_all_and_enable_all(self, tmp_config_dir):
        """Global disable/enable works."""
        dm = DiscoveryManager(tmp_config_dir)
        dm.disable_all()
        assert dm.state.globally_disabled is True

        dm.enable_all()
        assert dm.state.globally_disabled is False
        assert dm.state.enabled is True

    def test_reset(self, tmp_config_dir):
        """Reset restores defaults."""
        dm = DiscoveryManager(tmp_config_dir)
        dm.disable(CATEGORY_GENERAL)
        dm.snooze(CATEGORY_INTEGRATIONS, hours=48)
        dm.state.messages_between_hints = 100

        dm.reset()
        assert dm.state.categories[CATEGORY_GENERAL].permanently_disabled is False
        assert dm.state.categories[CATEGORY_INTEGRATIONS].snoozed_until == 0.0
        assert dm.state.messages_between_hints == 25

    def test_mark_shown(self, tmp_config_dir):
        """mark_shown updates show_count and last_shown."""
        dm = DiscoveryManager(tmp_config_dir)
        dm.mark_shown(CATEGORY_GENERAL, message_count=42)
        cs = dm.state.categories[CATEGORY_GENERAL]
        assert cs.show_count == 1
        assert cs.last_shown > 0
        assert dm.state.last_hint_message_count == 42


class TestDiscoveryConfiguration:
    def test_set_interval(self, tmp_config_dir):
        """set_interval updates min_interval_hours."""
        dm = DiscoveryManager(tmp_config_dir)
        dm.set_interval(16.0)
        assert dm.state.min_interval_hours == 16.0

    def test_set_interval_minimum(self, tmp_config_dir):
        """set_interval enforces minimum of 1 hour."""
        dm = DiscoveryManager(tmp_config_dir)
        dm.set_interval(0.1)
        assert dm.state.min_interval_hours == 1.0

    def test_set_snooze_duration(self, tmp_config_dir):
        """set_snooze_duration updates snooze_hours."""
        dm = DiscoveryManager(tmp_config_dir)
        dm.set_snooze_duration(72.0)
        assert dm.state.snooze_hours == 72.0

    def test_set_message_spacing(self, tmp_config_dir):
        """set_message_spacing updates messages_between_hints."""
        dm = DiscoveryManager(tmp_config_dir)
        dm.set_message_spacing(50)
        assert dm.state.messages_between_hints == 50

    def test_set_message_spacing_minimum(self, tmp_config_dir):
        """set_message_spacing enforces minimum of 5."""
        dm = DiscoveryManager(tmp_config_dir)
        dm.set_message_spacing(1)
        assert dm.state.messages_between_hints == 5


class TestCategoryStatus:
    def test_get_category_status(self, tmp_config_dir):
        """get_category_status returns all categories."""
        dm = DiscoveryManager(tmp_config_dir)
        status = dm.get_category_status()
        assert "_global" in status
        for cat in ALL_CATEGORIES:
            assert cat in status
            assert "label" in status[cat]
            assert "permanently_disabled" in status[cat]
            assert "snoozed" in status[cat]
            assert "show_count" in status[cat]

    def test_status_reflects_snooze(self, tmp_config_dir):
        """Snoozed category shows as snoozed in status."""
        dm = DiscoveryManager(tmp_config_dir)
        dm.snooze(CATEGORY_GENERAL, hours=24)
        status = dm.get_category_status()
        assert status[CATEGORY_GENERAL]["snoozed"] is True

    def test_status_reflects_disabled(self, tmp_config_dir):
        """Disabled category shows as disabled in status."""
        dm = DiscoveryManager(tmp_config_dir)
        dm.disable(CATEGORY_AUTOMATION)
        status = dm.get_category_status()
        assert status[CATEGORY_AUTOMATION]["permanently_disabled"] is True


# ── Formatting ────────────────────────────────────────────────────────────


class TestFormatting:
    def test_format_hint_markdown(self):
        """format_hint_markdown produces valid output."""
        hint = DiscoveryHint(
            category=CATEGORY_GENERAL,
            title="Test Hint",
            message="This is a test message.",
            action_hint="Run some command.",
            priority=5,
        )
        result = format_hint_markdown(hint)
        assert "**Test Hint**" in result
        assert "test message" in result
        assert "Run some command" in result
        assert "dismiss" in result.lower()
        assert "snooze" in result.lower()

    def test_format_hint_plain(self):
        """format_hint_plain produces clean output."""
        hint = DiscoveryHint(
            category=CATEGORY_AUTOMATION,
            title="Enable Tools",
            message="Your bot needs tools.",
            action_hint="Edit config.json",
        )
        result = format_hint_plain(hint)
        assert "Enable Tools" in result
        assert "Automation" in result
        assert "Edit config.json" in result

    def test_format_status_markdown(self, tmp_config_dir):
        """format_status_markdown produces full status view."""
        dm = DiscoveryManager(tmp_config_dir)
        dm.disable(CATEGORY_GENERAL)
        dm.snooze(CATEGORY_INTEGRATIONS, hours=12)
        status = dm.get_category_status()
        result = format_status_markdown(status)
        assert "Capability Discovery" in result
        assert "disabled" in result
        assert "snoozed" in result
        assert "active" in result

    def test_category_labels_complete(self):
        """All categories have labels."""
        for cat in ALL_CATEGORIES:
            assert cat in CATEGORY_LABELS
            assert len(CATEGORY_LABELS[cat]) > 0


# ── Hint data integrity ──────────────────────────────────────────────────


class TestHintDataIntegrity:
    def test_all_hints_have_required_fields(self, tmp_config_dir, base_config):
        """Every hint has category, title, message, action_hint."""
        dm = DiscoveryManager(tmp_config_dir)
        hints = dm.get_all_hints(base_config)
        for hint in hints:
            assert hint.category in ALL_CATEGORIES, f"Invalid category: {hint.category}"
            assert len(hint.title) > 0, "Empty title"
            assert len(hint.message) > 0, "Empty message"
            assert len(hint.action_hint) > 0, "Empty action_hint"
            assert isinstance(hint.priority, int), "Priority must be int"

    def test_hint_categories_valid(self, tmp_config_dir, base_config):
        """All hints have valid categories."""
        dm = DiscoveryManager(tmp_config_dir)
        hints = dm.get_all_hints(base_config)
        for hint in hints:
            assert hint.category in ALL_CATEGORIES


# ── Edge cases ────────────────────────────────────────────────────────────


class TestEdgeCases:
    def test_dismiss_unknown_category(self, tmp_config_dir):
        """Dismissing unknown category creates it."""
        dm = DiscoveryManager(tmp_config_dir)
        dm.dismiss("nonexistent_category")
        assert "nonexistent_category" in dm.state.categories

    def test_snooze_with_zero_hours(self, tmp_config_dir):
        """Snooze with 0 hours effectively dismisses."""
        dm = DiscoveryManager(tmp_config_dir)
        dm.snooze(CATEGORY_GENERAL, hours=0)
        # snoozed_until should be approximately now
        assert dm.state.categories[CATEGORY_GENERAL].snoozed_until <= time.time() + 1

    def test_concurrent_categories(self, tmp_config_dir, base_config):
        """Multiple categories can have hints simultaneously."""
        dm = DiscoveryManager(tmp_config_dir)
        hints = dm.get_all_hints(base_config)
        categories = set(h.category for h in hints)
        # A bare config should trigger hints in multiple categories
        assert len(categories) >= 2

    def test_no_crash_on_missing_tools_config(self, tmp_config_dir, base_config):
        """Doesn't crash when _tools_config is missing."""
        delattr(base_config, '_tools_config')
        dm = DiscoveryManager(tmp_config_dir)
        # Should not raise
        hints = dm.get_all_hints(base_config)
        assert isinstance(hints, list)

    def test_persistence_across_manager_instances(self, tmp_config_dir):
        """State persists between DiscoveryManager instances."""
        dm1 = DiscoveryManager(tmp_config_dir)
        dm1.disable(CATEGORY_GENERAL)
        dm1.snooze(CATEGORY_AUTOMATION, hours=48)

        dm2 = DiscoveryManager(tmp_config_dir)
        assert dm2.state.categories[CATEGORY_GENERAL].permanently_disabled is True
        assert dm2.state.categories[CATEGORY_AUTOMATION].snoozed_until > time.time()
