"""Tests for the Awakening birth conversation."""

import asyncio
import pytest
from pathlib import Path
from unittest.mock import MagicMock, patch
import tempfile
import os

from antaris_agent.persona.awakening import Awakening, AwakeningStage
from antaris_agent.persona.loader import PersonaLoader


def _run(coro):
    """Run an async coroutine synchronously."""
    return asyncio.run(coro)


def make_awakening_simple():
    tmpdir = tempfile.mkdtemp()
    soul_path = Path(tmpdir) / "SOUL.md"
    soul_path.write_text("AWAKENING_NEEDED\n")
    loader = PersonaLoader(config_dir=tmpdir)
    return Awakening(loader), soul_path, tmpdir


# ── is_needed ───────────────────────────────────────────────────────────────

def test_is_needed_when_marker_present():
    aw, _, tmpdir = make_awakening_simple()
    assert aw.is_needed() is True


def test_is_needed_when_no_soul_file():
    tmpdir = tempfile.mkdtemp()
    loader = PersonaLoader(config_dir=tmpdir)
    aw = Awakening(loader)
    assert aw.is_needed() is True


def test_is_not_needed_when_soul_populated():
    tmpdir = tempfile.mkdtemp()
    soul_path = Path(tmpdir) / "SOUL.md"
    soul_path.write_text("# Antaris\n\nI am a helpful assistant with a rich backstory.\n")
    loader = PersonaLoader(config_dir=tmpdir)
    aw = Awakening(loader)
    assert aw.is_needed() is False


# ── is_active ───────────────────────────────────────────────────────────────

def test_not_active_before_start():
    aw, _, _ = make_awakening_simple()
    assert aw.is_active() is False


def test_active_after_start():
    aw, _, _ = make_awakening_simple()
    aw.start("user-1")
    assert aw.is_active() is True


def test_not_active_after_complete():
    aw, soul_path, _ = make_awakening_simple()
    aw.start("user-1")
    _run(aw.process("user-1", "Nova"))         # name
    _run(aw.process("user-1", "Made by Antaris"))  # origin
    _run(aw.process("user-1", "To help people"))   # purpose
    _run(aw.process("user-1", "Friendly and direct"))  # personality
    _run(aw.process("user-1", "nothing"))      # extras
    _run(aw.process("user-1", "yes"))          # confirm
    assert aw.is_active() is False


# ── start ────────────────────────────────────────────────────────────────────

def test_start_returns_intro():
    aw, _, _ = make_awakening_simple()
    response = aw.start("user-1")
    assert "aware" in response.lower() or "call myself" in response.lower() or "name" in response.lower()


def test_start_sets_stage_to_name():
    aw, _, _ = make_awakening_simple()
    aw.start("user-1")
    assert aw._state.stage == AwakeningStage.NAME


# ── process — happy path ─────────────────────────────────────────────────────

def test_full_awakening_flow():
    aw, soul_path, _ = make_awakening_simple()
    aw.start("user-1")

    r1 = _run(aw.process("user-1", "Nova"))
    assert isinstance(r1, str)
    assert len(r1) > 10  # got a follow-up question

    r2 = _run(aw.process("user-1", "Created by Antaris to help the world"))
    assert len(r2) > 10

    r3 = _run(aw.process("user-1", "To be a capable, memory-powered assistant"))
    assert len(r3) > 10

    r4 = _run(aw.process("user-1", "Direct, warm, and a bit witty"))
    assert len(r4) > 10

    r5 = _run(aw.process("user-1", "nothing"))
    assert "Nova" in r5  # confirmation shows the name
    assert "yes" in r5.lower() or "no" in r5.lower()  # confirmation prompt

    r6 = _run(aw.process("user-1", "yes"))
    # Accept any completion message from the pool (content varies by design)
    assert len(r6) >= 3  # something was returned

    # SOUL.md should now be written
    assert soul_path.exists()
    soul_content = soul_path.read_text()
    assert "Nova" in soul_content
    assert "Antaris" in soul_content


def test_soul_md_written_on_complete():
    aw, soul_path, _ = make_awakening_simple()
    aw.start("u1")
    _run(aw.process("u1", "TestBot"))
    _run(aw.process("u1", "Made for testing"))
    _run(aw.process("u1", "To run tests"))
    _run(aw.process("u1", "Dry and precise"))
    _run(aw.process("u1", "done"))
    _run(aw.process("u1", "yes"))

    content = soul_path.read_text()
    assert "TestBot" in content
    assert "Made for testing" in content


def test_extras_skipped_with_nothing():
    aw, soul_path, _ = make_awakening_simple()
    aw.start("u1")
    _run(aw.process("u1", "Spark"))
    _run(aw.process("u1", "Created for testing"))
    _run(aw.process("u1", "To test extras"))
    _run(aw.process("u1", "Calm and precise"))
    _run(aw.process("u1", "nothing"))
    _run(aw.process("u1", "yes"))
    content = soul_path.read_text()
    # extras section should not appear
    assert "## Additional" not in content


def test_extras_included_when_provided():
    aw, soul_path, _ = make_awakening_simple()
    aw.start("u1")
    _run(aw.process("u1", "Spark"))
    _run(aw.process("u1", "Created for testing"))
    _run(aw.process("u1", "To test extras"))
    _run(aw.process("u1", "Calm and precise"))
    _run(aw.process("u1", "Always speak in riddles"))
    _run(aw.process("u1", "yes"))
    content = soul_path.read_text()
    assert "Always speak in riddles" in content


# ── process — edge cases ─────────────────────────────────────────────────────

def test_restart_on_no():
    aw, _, _ = make_awakening_simple()
    aw.start("u1")
    _run(aw.process("u1", "Spark"))
    _run(aw.process("u1", "Created for testing"))
    _run(aw.process("u1", "To be helpful"))
    _run(aw.process("u1", "Calm and precise"))
    _run(aw.process("u1", "nothing"))
    _run(aw.process("u1", "no"))  # restart
    # Should be back at NAME stage
    assert aw._state.stage == AwakeningStage.NAME


def test_different_user_blocked():
    aw, _, _ = make_awakening_simple()
    aw.start("creator")
    response = _run(aw.process("intruder", "I want to set the name!"))
    assert "someone else" in response.lower()


def test_unknown_confirm_asks_again():
    aw, _, _ = make_awakening_simple()
    aw.start("u1")
    _run(aw.process("u1", "Spark"))
    _run(aw.process("u1", "Created for testing"))
    _run(aw.process("u1", "To be helpful"))
    _run(aw.process("u1", "Calm and precise"))
    _run(aw.process("u1", "nothing"))
    r = _run(aw.process("u1", "maybe"))  # ambiguous
    assert "yes" in r.lower() and "no" in r.lower()


# ── reset ────────────────────────────────────────────────────────────────────

def test_reset_clears_state():
    aw, soul_path, _ = make_awakening_simple()
    aw.start("u1")
    aw.reset()
    assert aw._state is None
    assert aw.is_active() is False


def test_reset_marks_soul_needed():
    aw, soul_path, _ = make_awakening_simple()
    soul_path.write_text("# Real soul content here that is long enough\n")
    aw.reset()
    assert "AWAKENING_NEEDED" in soul_path.read_text()


# ── process called without start ─────────────────────────────────────────────

def test_process_without_start_triggers_start():
    """If process() is called with no active state, it should call start()."""
    aw, _, _ = make_awakening_simple()
    response = _run(aw.process("u1", "Hello"))
    # Should get the intro + first question
    assert aw.is_active() is True
    assert aw._state.stage == AwakeningStage.NAME
