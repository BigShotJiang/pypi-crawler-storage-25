"""Tests for antaris_agent.core.config"""

import json
import pytest
from pathlib import Path
from unittest.mock import patch, MagicMock

from antaris_agent.core.config import (
    Config,
    run_init_wizard,
    DEFAULT_CONFIG_DIR,
    DEFAULT_CONFIG_PATH,
    resolve_auth_profiles_path,
    resolve_config_path,
)


VALID_CONFIG_DATA = {
    "bot": {"name": "TestBot"},
    "provider": {
        "name": "anthropic",
        "apiKey": "sk-test-key-123",
        "model": "claude-sonnet-4-20250514",
        "fallbackModel": "claude-haiku-4-5-20251001"
    },
    "channels": {
        "discord": {"enabled": True, "token": "discord-token-abc"},
        "telegram": {"enabled": False, "token": ""}
    },
    "memory": {
        "store": "/tmp/test-memory",
        "searchLimit": 5,
        "minRelevance": 0.5,
        "autoIngest": True,
        "autoRecall": True
    },
    "guard": {"mode": "warn"},
    "context": {"maxTokens": 50000}
}


class TestPathResolution:
    def test_resolve_config_path_prefers_antaris_config_dir(self, tmp_path, monkeypatch):
        monkeypatch.delenv("ANTARISBOT_CONFIG", raising=False)
        monkeypatch.setenv("ANTARIS_CONFIG_DIR", str(tmp_path))
        assert resolve_config_path() == (tmp_path / "config.json")

    def test_resolve_config_path_explicit_arg_beats_env(self, tmp_path, monkeypatch):
        explicit = tmp_path / "custom.json"
        monkeypatch.setenv("ANTARIS_CONFIG_DIR", str(tmp_path / "ignored"))
        assert resolve_config_path(str(explicit)) == explicit.resolve()

    def test_resolve_auth_profiles_path_prefers_config_dir_file(self, tmp_path, monkeypatch):
        monkeypatch.delenv("ANTARIS_AUTH_PROFILES", raising=False)
        monkeypatch.delenv("ANTARISBOT_CONFIG", raising=False)
        monkeypatch.setenv("ANTARIS_CONFIG_DIR", str(tmp_path))
        auth_path = tmp_path / "auth-profiles.json"
        auth_path.write_text("{}")
        assert resolve_auth_profiles_path() == auth_path

    def test_resolve_auth_profiles_path_env_beats_config_dir(self, tmp_path, monkeypatch):
        monkeypatch.setenv("ANTARIS_CONFIG_DIR", str(tmp_path))
        env_path = tmp_path / "from-env.json"
        env_path.write_text("{}")
        monkeypatch.setenv("ANTARIS_AUTH_PROFILES", str(env_path))
        assert resolve_auth_profiles_path() == env_path.resolve()


class TestConfigLoad:
    def test_load_valid_data(self, tmp_path, monkeypatch):
        monkeypatch.delenv("ANTARIS_AUTH_PROFILES", raising=False)
        monkeypatch.setattr("antaris_agent.core.config.load_auth_profiles", lambda path=None: {})
        config_file = tmp_path / "config.json"
        config_file.write_text(json.dumps(VALID_CONFIG_DATA))

        cfg = Config.load(str(config_file))

        assert cfg is not None
        assert cfg.bot_name == "TestBot"
        assert cfg.provider_name == "anthropic"
        assert cfg.api_key == "sk-test-key-123"
        assert cfg.model == "claude-sonnet-4-20250514"
        assert cfg.fallback_model == "claude-haiku-4-5-20251001"
        assert cfg.discord_enabled is True
        assert cfg.discord_token == "discord-token-abc"
        assert cfg.telegram_enabled is False
        assert cfg.memory_store == "/tmp/test-memory"
        assert cfg.memory_search_limit == 5
        assert cfg.memory_min_relevance == 0.5
        assert cfg.guard_mode == "warn"
        assert cfg.config_path == str(config_file)

    def test_load_missing_file_returns_none(self, tmp_path):
        missing = tmp_path / "nonexistent.json"
        result = Config.load(str(missing))
        assert result is None

    def test_load_rejects_empty_config(self, tmp_path):
        config_file = tmp_path / "config.json"
        config_file.write_text(json.dumps({}))
        assert Config.load(str(config_file)) is None

    def test_load_uses_defaults_for_partial_config(self, tmp_path, monkeypatch):
        monkeypatch.delenv("ANTARIS_AUTH_PROFILES", raising=False)
        monkeypatch.setattr("antaris_agent.core.config.load_auth_profiles", lambda path=None: {})
        config_file = tmp_path / "config.json"
        config_file.write_text(json.dumps({"provider": {"name": "anthropic", "apiKey": "sk-partial-test"}}))

        cfg = Config.load(str(config_file))

        assert cfg is not None
        assert cfg.bot_name == "Antaris"
        assert cfg.provider_name == "anthropic"
        assert cfg.api_key == "sk-partial-test"
        assert cfg.model == "claude-sonnet-4-6"
        assert cfg.guard_mode == "monitor"


class TestConfigValidate:
    def test_validate_catches_missing_api_key(self):
        cfg = Config()
        cfg.api_key = ""
        errors = cfg.validate()
        assert any("API key" in e for e in errors)

    def test_validate_catches_discord_token_missing(self):
        cfg = Config()
        cfg.api_key = "sk-valid"
        cfg.discord_enabled = True
        cfg.discord_token = ""
        errors = cfg.validate()
        assert any("Discord token" in e for e in errors)

    def test_validate_passes_when_all_good(self):
        cfg = Config()
        cfg.api_key = "sk-valid"
        cfg.discord_enabled = False
        assert cfg.validate() == []

    def test_validate_passes_discord_with_token(self):
        cfg = Config()
        cfg.api_key = "sk-valid"
        cfg.discord_enabled = True
        cfg.discord_token = "discord-token-xyz"
        assert cfg.validate() == []


class TestConfigSave:
    def test_save_writes_correct_json(self, tmp_path):
        cfg = Config()
        cfg.bot_name = "SavedBot"
        cfg.api_key = "sk-save-test"
        cfg.provider_name = "openai"
        cfg.model = "gpt-4o"
        cfg.discord_enabled = True
        cfg.discord_token = "discord-save-token"
        cfg.guard_mode = "block"
        cfg.memory_store = str(tmp_path / "memory")
        cfg.context_max_tokens = 75000

        save_path = tmp_path / "config.json"
        cfg.save(str(save_path))

        assert save_path.exists()
        data = json.loads(save_path.read_text())
        assert data["bot"]["name"] == "SavedBot"
        assert data["provider"]["name"] == "openai"
        assert data["provider"]["apiKey"] == "sk-save-test"
        assert data["provider"]["model"] == "gpt-4o"
        assert data["channels"]["discord"]["enabled"] is True
        assert data["channels"]["discord"]["token"] == "discord-save-token"
        assert data["guard"]["mode"] == "block"
        assert data["context"]["maxTokens"] == 75000
        assert data["memory"]["autoIngest"] is True
        assert data["memory"]["autoRecall"] is True

    def test_save_creates_parent_dirs(self, tmp_path):
        save_path = tmp_path / "deep" / "nested" / "config.json"
        cfg = Config()
        cfg.api_key = "sk-x"
        cfg.save(str(save_path))
        assert save_path.exists()

    def test_roundtrip(self, tmp_path, monkeypatch):
        monkeypatch.delenv("ANTARIS_AUTH_PROFILES", raising=False)
        monkeypatch.setattr("antaris_agent.core.config.load_auth_profiles", lambda path=None: {})
        cfg = Config()
        cfg.bot_name = "RoundTrip"
        cfg.api_key = "sk-rt"
        cfg.model = "claude-sonnet-4-20250514"
        cfg.guard_mode = "warn"
        cfg.memory_search_limit = 7
        cfg.memory_store = str(tmp_path / "mem")

        save_path = tmp_path / "rt.json"
        cfg.save(str(save_path))

        loaded = Config.load(str(save_path))
        assert loaded is not None
        assert loaded.bot_name == cfg.bot_name
        assert loaded.api_key == cfg.api_key
        assert loaded.model == cfg.model
        assert loaded.guard_mode == cfg.guard_mode
        assert loaded.memory_search_limit == cfg.memory_search_limit


class TestRunInitWizard:
    def test_wizard_exists_and_is_callable(self):
        assert callable(run_init_wizard)

    def test_wizard_runs_with_mocked_input(self, tmp_path):
        inputs = iter(["MyBot", "1", "sk-wizard-key", "", "1", "y"])
        with patch("builtins.input", side_effect=lambda prompt="": next(inputs)):
            with patch("antaris_agent.core.config.DEFAULT_CONFIG_DIR", tmp_path):
                with patch("antaris_agent.core.config.DEFAULT_CONFIG_PATH", tmp_path / "config.json"):
                    with patch.object(Config, "save") as mock_save:
                        run_init_wizard()
                        mock_save.assert_called_once()


class TestConfigSaveAtomic:
    def test_save_is_atomic_no_tmp_left_behind(self, tmp_path):
        cfg = Config()
        cfg.api_key = "sk-atomic"
        cfg.memory_store = str(tmp_path / "mem")
        save_path = tmp_path / "config.json"
        cfg.config_path = str(save_path)
        cfg.save(str(save_path))
        assert not (tmp_path / "config.json.tmp").exists()
        assert save_path.exists()

    def test_save_creates_bak_of_previous_config(self, tmp_path):
        cfg = Config()
        cfg.api_key = "sk-first"
        cfg.memory_store = str(tmp_path / "mem")
        save_path = tmp_path / "config.json"
        cfg.config_path = str(save_path)
        cfg.save(str(save_path))
        cfg.api_key = "sk-second"
        cfg.save(str(save_path))
        bak_path = tmp_path / ".config.json.bak"
        assert bak_path.exists()
        assert json.loads(bak_path.read_text())["provider"]["apiKey"] == "sk-first"
        assert json.loads(save_path.read_text())["provider"]["apiKey"] == "sk-second"

    def test_save_no_bak_when_no_existing_file(self, tmp_path):
        cfg = Config()
        cfg.api_key = "sk-fresh"
        cfg.memory_store = str(tmp_path / "mem")
        save_path = tmp_path / "config.json"
        cfg.config_path = str(save_path)
        cfg.save(str(save_path))
        assert not (tmp_path / ".config.json.bak").exists()

    def test_save_skips_bak_for_corrupt_existing_file(self, tmp_path):
        save_path = tmp_path / "config.json"
        save_path.write_text("THIS IS NOT JSON {{{{")
        cfg = Config()
        cfg.api_key = "sk-overwrite"
        cfg.memory_store = str(tmp_path / "mem")
        cfg.config_path = str(save_path)
        cfg.save(str(save_path))
        assert json.loads(save_path.read_text())["provider"]["apiKey"] == "sk-overwrite"


class TestConfigLoadWithFallback:
    def test_returns_main_config_when_valid(self, tmp_path, monkeypatch):
        monkeypatch.delenv("ANTARIS_AUTH_PROFILES", raising=False)
        monkeypatch.setattr("antaris_agent.core.config.load_auth_profiles", lambda path=None: {})
        config_file = tmp_path / "config.json"
        config_file.write_text(json.dumps(VALID_CONFIG_DATA))
        result = Config.load_with_fallback(str(config_file))
        assert result is not None
        assert result.api_key == "sk-test-key-123"

    def test_falls_back_to_bak_when_main_is_empty(self, tmp_path, monkeypatch):
        monkeypatch.delenv("ANTARIS_AUTH_PROFILES", raising=False)
        monkeypatch.setattr("antaris_agent.core.config.load_auth_profiles", lambda path=None: {})
        monkeypatch.setattr("antaris_agent.core.config.resolve_provider_credential", lambda *a, **kw: (None, None))
        bak_file = tmp_path / ".config.json.bak"
        bak_file.write_text(json.dumps({
            "bot": {"name": "FallbackBot"},
            "provider": {"name": "anthropic", "apiKey": "sk-from-bak", "model": "claude-sonnet-4-6"},
            "memory": {}
        }))
        main_file = tmp_path / "config.json"
        main_file.write_text(json.dumps({
            "bot": {"name": "EmptyBot"},
            "provider": {"name": "anthropic", "apiKey": ""},
            "memory": {}
        }))
        result = Config.load_with_fallback(str(main_file))
        assert result is not None
        assert result.api_key == "sk-from-bak"
        assert result.bot_name == "FallbackBot"

    def test_falls_back_to_bak_when_main_is_missing(self, tmp_path, monkeypatch):
        monkeypatch.delenv("ANTARIS_AUTH_PROFILES", raising=False)
        monkeypatch.setattr("antaris_agent.core.config.load_auth_profiles", lambda path=None: {})
        bak_file = tmp_path / ".config.json.bak"
        bak_file.write_text(json.dumps({
            "bot": {"name": "BakBot"},
            "provider": {"name": "anthropic", "apiKey": "sk-bak-only", "model": "claude-sonnet-4-6"},
            "memory": {}
        }))
        result = Config.load_with_fallback(str(tmp_path / "config.json"))
        assert result is not None
        assert result.api_key == "sk-bak-only"

    def test_returns_none_when_both_missing(self, tmp_path, monkeypatch):
        monkeypatch.delenv("ANTARIS_AUTH_PROFILES", raising=False)
        monkeypatch.setattr("antaris_agent.core.config.load_auth_profiles", lambda path=None: {})
        assert Config.load_with_fallback(str(tmp_path / "config.json")) is None

    def test_returns_none_when_both_empty(self, tmp_path, monkeypatch):
        monkeypatch.delenv("ANTARIS_AUTH_PROFILES", raising=False)
        monkeypatch.setattr("antaris_agent.core.config.load_auth_profiles", lambda path=None: {})
        monkeypatch.setattr("antaris_agent.core.config.resolve_provider_credential", lambda *a, **kw: (None, None))
        for fname in ("config.json", ".config.json.bak"):
            (tmp_path / fname).write_text(json.dumps({"provider": {"name": "anthropic", "apiKey": ""}, "memory": {}}))
        result = Config.load_with_fallback(str(tmp_path / "config.json"))
        assert result is not None
        assert result.api_key == ""
