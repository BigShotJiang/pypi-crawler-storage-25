"""
Antaris Agent v4.5 — Production Hardening Tests

Covers:
  - RateLimiter (sliding window, per-user, reset, wait seconds)
  - setup_logging / get_logger
  - Pipeline error isolation (non-critical stages)
  - Pipeline rate limit integration
  - PipelineResult.failed_stages observability
"""

import asyncio
import logging
import math
import os
import tempfile
import time
import unittest
from unittest.mock import AsyncMock, MagicMock, patch, call

# ── Imports ───────────────────────────────────────────────────────────────────

from antaris_agent.core.rate_limiter import RateLimiter
from antaris_agent.core.logger import setup_logging, get_logger
from antaris_agent.core.pipeline import Pipeline, PipelineResult
from antaris_agent.channels.base import InboundMessage


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _make_inbound(user_id: str = "user123", text: str = "hello") -> InboundMessage:
    return InboundMessage(
        id="msg1",
        user_id=user_id,
        user_name="Test User",
        channel_id="chan1",
        platform="test",
        text=text,
    )


def _make_pipeline(
    rate_limit_messages: int = 20,
    rate_limit_window_seconds: int = 60,
    memory_recall_side_effect=None,
    memory_ingest_side_effect=None,
    llm_response_text: str = "Hello there!",
    guard_input_result=(True, ""),
    guard_output_result=None,
    persona_side_effect=None,
    format_side_effect=None,
):
    """Build a Pipeline with mocked dependencies."""
    from antaris_agent.llm.base import LLMResponse

    config = MagicMock()
    config.rate_limit_messages = rate_limit_messages
    config.rate_limit_window_seconds = rate_limit_window_seconds
    config.model = "test-model"

    memory = MagicMock()
    if memory_recall_side_effect is not None:
        memory.recall = AsyncMock(side_effect=memory_recall_side_effect)
    else:
        memory.recall = AsyncMock(return_value=[])
    if memory_ingest_side_effect is not None:
        memory.ingest = AsyncMock(side_effect=memory_ingest_side_effect)
    else:
        memory.ingest = AsyncMock(return_value=None)

    guard = MagicMock()
    guard.check_input = AsyncMock(return_value=guard_input_result)
    if guard_output_result is not None:
        guard.check_output = AsyncMock(return_value=guard_output_result)
    else:
        guard.check_output = AsyncMock(return_value=(True, llm_response_text))

    persona = MagicMock()
    if persona_side_effect is not None:
        persona.build_system_prompt = MagicMock(side_effect=persona_side_effect)
    else:
        persona.build_system_prompt = MagicMock(return_value="You are a helpful bot.")
    persona.update_user_context = MagicMock()

    llm = MagicMock()
    llm_resp = LLMResponse(
        content=llm_response_text,
        model="test-model",
        input_tokens=10,
        output_tokens=20,
        cost_usd=0.001,
    )
    llm.complete = AsyncMock(return_value=llm_resp)

    adapter = MagicMock()
    if format_side_effect is not None:
        adapter.format_for_surface = MagicMock(side_effect=format_side_effect)
    else:
        adapter.format_for_surface = MagicMock(side_effect=lambda t: t)

    pipeline = Pipeline(
        config=config,
        memory=memory,
        guard=guard,
        persona=persona,
        llm=llm,
        awakening=None,
    )
    # Disable per-message cooldown so tests don't need to sleep
    pipeline._cooldown_seconds = 0.0

    return pipeline, adapter


def _run(coro):
    return asyncio.run(coro)


# ─────────────────────────────────────────────────────────────────────────────
# 1. RateLimiter Tests
# ─────────────────────────────────────────────────────────────────────────────

class TestRateLimiter(unittest.TestCase):

    # ── is_allowed ─────────────────────────────────────────────────────────

    def test_under_limit_is_allowed(self):
        """Messages below max_messages are allowed."""
        rl = RateLimiter(max_messages=5, window_seconds=60)
        for i in range(4):
            self.assertTrue(rl.is_allowed("user1"), f"Message {i+1} should be allowed")

    def test_at_limit_last_message_allowed(self):
        """The Nth message (exactly at limit) is still allowed."""
        rl = RateLimiter(max_messages=5, window_seconds=60)
        for i in range(4):
            rl.is_allowed("user1")
        self.assertTrue(rl.is_allowed("user1"), "5th message should still be allowed")

    def test_over_limit_is_blocked(self):
        """The (N+1)th message is blocked."""
        rl = RateLimiter(max_messages=3, window_seconds=60)
        for _ in range(3):
            rl.is_allowed("user1")
        self.assertFalse(rl.is_allowed("user1"), "4th message should be blocked")

    def test_per_user_isolation(self):
        """Different users have independent windows."""
        rl = RateLimiter(max_messages=2, window_seconds=60)
        rl.is_allowed("user1")
        rl.is_allowed("user1")
        self.assertFalse(rl.is_allowed("user1"), "user1 should be blocked")
        self.assertTrue(rl.is_allowed("user2"), "user2 should still be allowed")

    def test_is_allowed_records_attempt(self):
        """Allowed messages are recorded — blocking kicks in after max."""
        rl = RateLimiter(max_messages=1, window_seconds=60)
        self.assertTrue(rl.is_allowed("u"))
        self.assertFalse(rl.is_allowed("u"))

    # ── get_wait_seconds ──────────────────────────────────────────────────

    def test_wait_seconds_zero_when_allowed(self):
        """Returns 0 when user is within limit."""
        rl = RateLimiter(max_messages=5, window_seconds=60)
        self.assertEqual(rl.get_wait_seconds("newuser"), 0.0)

    def test_wait_seconds_positive_when_limited(self):
        """Returns positive float when user has hit their limit."""
        rl = RateLimiter(max_messages=2, window_seconds=60)
        rl.is_allowed("user1")
        rl.is_allowed("user1")
        wait = rl.get_wait_seconds("user1")
        self.assertGreater(wait, 0.0)
        self.assertLessEqual(wait, 60.0)

    def test_wait_seconds_at_limit(self):
        """Wait seconds is close to window_seconds right after hitting limit."""
        rl = RateLimiter(max_messages=1, window_seconds=30)
        rl.is_allowed("u")
        wait = rl.get_wait_seconds("u")
        # Should be close to 30 seconds (within 1s tolerance)
        self.assertGreater(wait, 28.0)
        self.assertLessEqual(wait, 30.0)

    # ── reset ─────────────────────────────────────────────────────────────

    def test_reset_clears_state(self):
        """reset() allows the user to send again immediately."""
        rl = RateLimiter(max_messages=1, window_seconds=60)
        rl.is_allowed("user1")
        self.assertFalse(rl.is_allowed("user1"), "should be blocked before reset")
        rl.reset("user1")
        self.assertTrue(rl.is_allowed("user1"), "should be allowed after reset")

    def test_reset_unknown_user_no_error(self):
        """reset() on an unknown user should not raise."""
        rl = RateLimiter()
        try:
            rl.reset("ghost_user")
        except Exception as e:
            self.fail(f"reset() raised unexpectedly: {e}")

    # ── Sliding window ─────────────────────────────────────────────────────

    def test_sliding_window_old_messages_expire(self):
        """Messages older than window_seconds are pruned; new ones are allowed."""
        rl = RateLimiter(max_messages=2, window_seconds=1)
        rl.is_allowed("user1")
        rl.is_allowed("user1")
        self.assertFalse(rl.is_allowed("user1"), "should be blocked immediately")

        # Wait for the window to expire
        time.sleep(1.05)

        # Now the old messages should have expired
        self.assertTrue(rl.is_allowed("user1"), "should be allowed after window expiry")

    def test_sliding_window_partial_expiry(self):
        """Only the oldest message expires — not all of them."""
        rl = RateLimiter(max_messages=2, window_seconds=1)
        rl.is_allowed("user1")  # t=0
        time.sleep(1.05)
        rl.is_allowed("user1")  # t≈1.05 — first message expired, this one added
        # Now window has 1 message
        self.assertTrue(rl.is_allowed("user1"), "should be allowed — only 1 in window")

    # ── Default / custom values ───────────────────────────────────────────

    def test_default_values(self):
        rl = RateLimiter()
        self.assertEqual(rl.max_messages, 20)
        self.assertEqual(rl.window_seconds, 60)

    def test_custom_values(self):
        rl = RateLimiter(max_messages=10, window_seconds=30)
        self.assertEqual(rl.max_messages, 10)
        self.assertEqual(rl.window_seconds, 30)


# ─────────────────────────────────────────────────────────────────────────────
# 2. Logger Tests
# ─────────────────────────────────────────────────────────────────────────────

class TestLogger(unittest.TestCase):

    def test_setup_logging_creates_log_dir(self):
        """setup_logging() creates the logs/ directory if it doesn't exist."""
        with tempfile.TemporaryDirectory() as tmpdir:
            log_dir = os.path.join(tmpdir, "logs")
            self.assertFalse(os.path.exists(log_dir))
            setup_logging(tmpdir)
            self.assertTrue(os.path.exists(log_dir))

    def test_setup_logging_creates_log_file(self):
        """setup_logging() creates the log file."""
        with tempfile.TemporaryDirectory() as tmpdir:
            setup_logging(tmpdir)
            log_file = os.path.join(tmpdir, "logs", "antaris_agent.log")
            # Write a log message to trigger file creation
            logging.getLogger("test_setup").info("ping")
            self.assertTrue(os.path.exists(log_file))

    def test_setup_logging_adds_handlers(self):
        """setup_logging() adds handlers to the root logger."""
        with tempfile.TemporaryDirectory() as tmpdir:
            setup_logging(tmpdir)
            root = logging.getLogger()
            self.assertGreaterEqual(len(root.handlers), 2, "Expected console + file handlers")

    def test_setup_logging_replaces_handlers_on_second_call(self):
        """Calling setup_logging() twice does not stack duplicate handlers."""
        with tempfile.TemporaryDirectory() as tmpdir:
            setup_logging(tmpdir)
            count_first = len(logging.getLogger().handlers)
            setup_logging(tmpdir)
            count_second = len(logging.getLogger().handlers)
            self.assertEqual(count_first, count_second, "Handler count should not grow on repeated setup")

    def test_get_logger_returns_logger(self):
        """get_logger() returns a logging.Logger instance."""
        lg = get_logger("antaris_agent.test_module")
        self.assertIsInstance(lg, logging.Logger)

    def test_get_logger_name(self):
        """get_logger() returns a logger with the correct name."""
        lg = get_logger("my.module.name")
        self.assertEqual(lg.name, "my.module.name")


# ─────────────────────────────────────────────────────────────────────────────
# 3. Pipeline Error Isolation Tests
# ─────────────────────────────────────────────────────────────────────────────

class TestPipelineErrorIsolation(unittest.TestCase):

    def test_pipeline_result_has_failed_stages_field(self):
        """PipelineResult dataclass has a failed_stages field."""
        result = PipelineResult(success=True, response_text="hi")
        self.assertTrue(hasattr(result, "failed_stages"))
        self.assertIsInstance(result.failed_stages, list)

    def test_pipeline_result_failed_stages_default_empty(self):
        """failed_stages defaults to empty list."""
        result = PipelineResult(success=True, response_text="hi")
        self.assertEqual(result.failed_stages, [])

    def test_pipeline_failed_recall_still_returns_response(self):
        """If memory recall fails, pipeline continues and returns a response."""
        pipeline, adapter = _make_pipeline(
            memory_recall_side_effect=RuntimeError("DB unavailable")
        )
        inbound = _make_inbound()
        result = _run(pipeline.process(inbound, adapter))
        self.assertTrue(result.success)
        self.assertNotEqual(result.response_text, "")
        self.assertIn("memory_recall", result.failed_stages)

    def test_pipeline_failed_recall_response_text_not_empty(self):
        """Even with recall failure, the user gets an LLM response."""
        pipeline, adapter = _make_pipeline(
            memory_recall_side_effect=RuntimeError("timeout"),
            llm_response_text="I am here to help!",
        )
        inbound = _make_inbound()
        result = _run(pipeline.process(inbound, adapter))
        self.assertIn("help", result.response_text)

    def test_pipeline_failed_ingest_still_returns_response(self):
        """If memory ingest fails, pipeline still returns the LLM response."""
        pipeline, adapter = _make_pipeline(
            memory_ingest_side_effect=RuntimeError("write failed")
        )
        inbound = _make_inbound()
        result = _run(pipeline.process(inbound, adapter))
        self.assertTrue(result.success)
        self.assertIn("memory_ingest", result.failed_stages)

    def test_pipeline_failed_format_still_returns_response(self):
        """If surface formatting fails, pipeline returns unformatted text."""
        pipeline, adapter = _make_pipeline(
            format_side_effect=RuntimeError("format crash"),
            llm_response_text="Raw response",
        )
        inbound = _make_inbound()
        result = _run(pipeline.process(inbound, adapter))
        # Should still return the unformatted text
        self.assertTrue(result.success)
        self.assertIn("surface_format", result.failed_stages)
        self.assertEqual(result.response_text, "Raw response")

    def test_pipeline_failed_stages_populated_on_recall_failure(self):
        """failed_stages contains 'memory_recall' when recall raises."""
        pipeline, adapter = _make_pipeline(
            memory_recall_side_effect=Exception("recall error")
        )
        inbound = _make_inbound()
        result = _run(pipeline.process(inbound, adapter))
        self.assertIn("memory_recall", result.failed_stages)

    def test_pipeline_failed_stages_empty_on_success(self):
        """failed_stages is empty on a fully successful pipeline run."""
        pipeline, adapter = _make_pipeline()
        inbound = _make_inbound()
        result = _run(pipeline.process(inbound, adapter))
        self.assertTrue(result.success)
        self.assertEqual(result.failed_stages, [])


# ─────────────────────────────────────────────────────────────────────────────
# 4. Pipeline Rate Limit Tests
# ─────────────────────────────────────────────────────────────────────────────

class TestPipelineRateLimit(unittest.TestCase):

    def test_rate_limited_user_gets_friendly_message(self):
        """A user who has hit their limit gets a friendly wait message."""
        pipeline, adapter = _make_pipeline(
            rate_limit_messages=1,
            rate_limit_window_seconds=60,
        )
        # Exhaust the rate limit directly
        pipeline._rate_limiter.is_allowed("user1")

        inbound = _make_inbound(user_id="user1")
        result = _run(pipeline.process(inbound, adapter))
        self.assertIn("too fast", result.response_text.lower())
        self.assertIn("wait", result.response_text.lower())

    def test_rate_limited_message_contains_wait_seconds(self):
        """Friendly message includes the number of seconds to wait."""
        pipeline, adapter = _make_pipeline(
            rate_limit_messages=1,
            rate_limit_window_seconds=60,
        )
        pipeline._rate_limiter.is_allowed("u")
        inbound = _make_inbound(user_id="u")
        result = _run(pipeline.process(inbound, adapter))
        # Should mention seconds
        self.assertRegex(result.response_text, r"\d+ second")

    def test_rate_limiter_lives_on_pipeline_instance(self):
        """The rate limiter is created once per Pipeline, not per message."""
        pipeline, _ = _make_pipeline()
        rl1 = pipeline._rate_limiter
        # It should be the same object across calls
        self.assertIs(pipeline._rate_limiter, rl1)

    def test_different_users_independent_rate_limits(self):
        """One user hitting the limit does not affect another user."""
        pipeline, adapter = _make_pipeline(
            rate_limit_messages=1,
            rate_limit_window_seconds=60,
        )
        # Exhaust user1's limit
        pipeline._rate_limiter.is_allowed("user1")

        # user2 should still be allowed through
        inbound = _make_inbound(user_id="user2")
        result = _run(pipeline.process(inbound, adapter))
        self.assertTrue(result.success)
        self.assertNotIn("too fast", result.response_text.lower())

    def test_rate_limit_not_triggered_when_under_limit(self):
        """A user under the limit passes through normally."""
        pipeline, adapter = _make_pipeline(
            rate_limit_messages=10,
            rate_limit_window_seconds=60,
            llm_response_text="Normal reply",
        )
        inbound = _make_inbound(user_id="user_ok")
        result = _run(pipeline.process(inbound, adapter))
        self.assertTrue(result.success)
        self.assertEqual(result.response_text, "Normal reply")

    def test_rate_limit_config_applied_to_rate_limiter(self):
        """Pipeline uses config.rate_limit_messages to size the rate limiter."""
        pipeline, _ = _make_pipeline(rate_limit_messages=42, rate_limit_window_seconds=120)
        self.assertEqual(pipeline._rate_limiter.max_messages, 42)
        self.assertEqual(pipeline._rate_limiter.window_seconds, 120)


if __name__ == "__main__":
    unittest.main(verbosity=2)
