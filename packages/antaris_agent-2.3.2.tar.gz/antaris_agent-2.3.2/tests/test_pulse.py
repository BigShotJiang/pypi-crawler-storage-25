"""Tests for antaris pulse health check."""
import asyncio
import json
import tempfile
from pathlib import Path
from unittest.mock import AsyncMock, patch

from antaris_agent.core.pulse import PulseCheck, PulseReport, run_pulse


def make_config_dir(config: dict = None):
    """Create a temp config directory with a valid config.json."""
    tmpdir = tempfile.mkdtemp()
    cfg = config or {
        "bot": {"name": "TestBot"},
        "provider": {
            "name": "anthropic",
            "apiKey": "sk-ant-test-key-that-is-long-enough",
            "model": "claude-haiku-4-5-20251001",
        },
        "channels": {
            "discord": {"enabled": False, "token": ""},
            "telegram": {"enabled": False, "token": ""},
        },
        "memory": {"store": str(Path(tmpdir) / "memory")},
        "guard": {"mode": "monitor"},
    }
    Path(tmpdir, "config.json").write_text(json.dumps(cfg))
    return tmpdir


# ── PulseCheck tests ─────────────────────────────────────────────────────────

def test_pulse_check_icons():
    assert PulseCheck("x", "ok").icon() == "✅"
    assert PulseCheck("x", "warn").icon() == "⚠️ "
    assert PulseCheck("x", "fail").icon() == "❌"
    assert PulseCheck("x", "skip").icon() == "⏭️ "


def test_pulse_check_str_with_message():
    c = PulseCheck("api", "ok", "connected")
    assert "api" in str(c)
    assert "connected" in str(c)


def test_pulse_check_str_with_detail():
    c = PulseCheck("cfg", "fail", "not found", "Run: antaris init")
    s = str(c)
    assert "cfg" in s
    assert "not found" in s
    assert "antaris init" in s


# ── PulseReport tests ────────────────────────────────────────────────────────

def test_report_passed_with_no_fails():
    r = PulseReport()
    r.add(PulseCheck("a", "ok"))
    r.add(PulseCheck("b", "warn"))
    assert r.passed() is True


def test_report_fails_with_fail():
    r = PulseReport()
    r.add(PulseCheck("a", "fail"))
    assert r.passed() is False


def test_report_has_warnings():
    r = PulseReport()
    r.add(PulseCheck("a", "ok"))
    r.add(PulseCheck("b", "warn"))
    assert r.has_warnings() is True


def test_report_no_warnings():
    r = PulseReport()
    r.add(PulseCheck("a", "ok"))
    assert r.has_warnings() is False


def test_report_summary_contains_all_systems_go():
    r = PulseReport()
    r.add(PulseCheck("a", "ok"))
    summary = r.summary()
    assert "All systems go" in summary or "all systems" in summary.lower()


def test_report_summary_shows_issues_on_fail():
    r = PulseReport()
    r.add(PulseCheck("a", "fail", "broke"))
    summary = r.summary()
    assert "Issues found" in summary or "issues" in summary.lower()


def test_report_summary_warns_when_warnings():
    r = PulseReport()
    r.add(PulseCheck("a", "ok"))
    r.add(PulseCheck("b", "warn", "something off"))
    summary = r.summary()
    assert "warnings" in summary.lower() or "warning" in summary.lower()


def test_report_summary_contains_header():
    r = PulseReport()
    assert "antaris pulse" in r.summary()


# ── run_pulse integration tests ──────────────────────────────────────────────

def test_run_pulse_no_config_returns_fail():
    async def run():
        tmpdir = tempfile.mkdtemp()
        return await run_pulse(config_dir=tmpdir)

    report = asyncio.run(run())
    assert not report.passed()
    statuses = [c.status for c in report.checks]
    assert "fail" in statuses


def test_run_pulse_valid_config_no_api_check():
    """With a valid config but skipping live API, most checks should pass."""
    async def run():
        tmpdir = make_config_dir()
        with patch("antaris_agent.core.pulse._check_api", new=AsyncMock(return_value=("ok", "mocked"))):
            return await run_pulse(config_dir=tmpdir)

    report = asyncio.run(run())
    check_names = {c.name: c.status for c in report.checks}
    assert check_names.get("config") == "ok"
    assert check_names.get("api_key") == "ok"


def test_run_pulse_no_api_key_fails():
    async def run():
        tmpdir = make_config_dir(config={
            "bot": {"name": "Test"},
            "provider": {"name": "anthropic", "apiKey": "", "model": "x"},
            "channels": {"discord": {"enabled": False, "token": ""}},
            "memory": {"store": "/tmp/mem"},
            "guard": {"mode": "monitor"},
        })
        return await run_pulse(config_dir=tmpdir)

    # Patch out credential resolution so env-var keys don't leak into the test
    with patch("antaris_agent.core.config.resolve_provider_credential", return_value=(None, None)), \
         patch("antaris_agent.core.config.load_auth_profile_credential", return_value=(None, None)):
        report = asyncio.run(run())
    check_names = {c.name: c.status for c in report.checks}
    assert check_names.get("api_key") == "fail"


def test_run_pulse_short_api_key_warns():
    async def run():
        tmpdir = make_config_dir(config={
            "bot": {"name": "Test"},
            "provider": {"name": "anthropic", "apiKey": "short", "model": "x"},
            "channels": {"discord": {"enabled": False, "token": ""}},
            "memory": {"store": "/tmp/mem"},
            "guard": {"mode": "monitor"},
        })
        return await run_pulse(config_dir=tmpdir)

    report = asyncio.run(run())
    check_names = {c.name: c.status for c in report.checks}
    assert check_names.get("api_key") == "warn"


def test_run_pulse_soul_not_found_warns():
    async def run():
        tmpdir = make_config_dir()
        with patch("antaris_agent.core.pulse._check_api", new=AsyncMock(return_value=("ok", "mocked"))):
            return await run_pulse(config_dir=tmpdir)

    report = asyncio.run(run())
    check_names = {c.name: c.status for c in report.checks}
    # No SOUL.md in temp dir → warn
    assert check_names.get("soul_md") == "warn"


def test_run_pulse_soul_awaiting_awakening():
    async def run():
        tmpdir = make_config_dir()
        Path(tmpdir, "SOUL.md").write_text("AWAKENING_NEEDED\n")
        with patch("antaris_agent.core.pulse._check_api", new=AsyncMock(return_value=("ok", "mocked"))):
            return await run_pulse(config_dir=tmpdir)

    report = asyncio.run(run())
    check_names = {c.name: c.status for c in report.checks}
    assert check_names.get("soul_md") == "warn"


def test_run_pulse_soul_populated():
    async def run():
        tmpdir = make_config_dir()
        Path(tmpdir, "SOUL.md").write_text(
            "# Altaris\n\nI am a capable AI assistant with a rich identity.\n"
        )
        with patch("antaris_agent.core.pulse._check_api", new=AsyncMock(return_value=("ok", "mocked"))):
            return await run_pulse(config_dir=tmpdir)

    report = asyncio.run(run())
    check_names = {c.name: c.status for c in report.checks}
    assert check_names.get("soul_md") == "ok"


def test_run_pulse_discord_skipped_when_disabled():
    async def run():
        tmpdir = make_config_dir()
        with patch("antaris_agent.core.pulse._check_api", new=AsyncMock(return_value=("ok", "mocked"))):
            return await run_pulse(config_dir=tmpdir)

    report = asyncio.run(run())
    check_names = {c.name: c.status for c in report.checks}
    assert check_names.get("discord") == "skip"


def test_run_pulse_discord_fails_when_enabled_no_token():
    async def run():
        tmpdir = make_config_dir(config={
            "bot": {"name": "Test"},
            "provider": {"name": "anthropic", "apiKey": "sk-ant-test-key-that-is-long-enough", "model": "x"},
            "channels": {"discord": {"enabled": True, "token": ""}},
            "memory": {"store": "/tmp/mem"},
            "guard": {"mode": "monitor"},
        })
        with patch("antaris_agent.core.pulse._check_api", new=AsyncMock(return_value=("ok", "mocked"))):
            return await run_pulse(config_dir=tmpdir)

    report = asyncio.run(run())
    check_names = {c.name: c.status for c in report.checks}
    assert check_names.get("discord") == "fail"


def test_run_pulse_discord_ok_when_token_present():
    async def run():
        tmpdir = make_config_dir(config={
            "bot": {"name": "Test"},
            "provider": {"name": "anthropic", "apiKey": "sk-ant-test-key-that-is-long-enough", "model": "x"},
            "channels": {"discord": {"enabled": True, "token": "Bot.token.abcdefghij"}},
            "memory": {"store": "/tmp/mem"},
            "guard": {"mode": "monitor"},
        })
        with patch("antaris_agent.core.pulse._check_api", new=AsyncMock(return_value=("ok", "mocked"))):
            return await run_pulse(config_dir=tmpdir)

    report = asyncio.run(run())
    check_names = {c.name: c.status for c in report.checks}
    assert check_names.get("discord") == "ok"


def test_run_pulse_memory_store_missing_warns():
    async def run():
        tmpdir = make_config_dir()
        # Default config has memory.store pointing to tmpdir/memory which doesn't exist
        with patch("antaris_agent.core.pulse._check_api", new=AsyncMock(return_value=("ok", "mocked"))):
            return await run_pulse(config_dir=tmpdir)

    report = asyncio.run(run())
    check_names = {c.name: c.status for c in report.checks}
    assert check_names.get("memory_store") == "warn"


def test_run_pulse_memory_store_exists():
    async def run():
        tmpdir = make_config_dir()
        mem_path = Path(tmpdir) / "memory"
        mem_path.mkdir()
        (mem_path / "user1").mkdir()
        with patch("antaris_agent.core.pulse._check_api", new=AsyncMock(return_value=("ok", "mocked"))):
            return await run_pulse(config_dir=tmpdir)

    report = asyncio.run(run())
    check_names = {c.name: c.status for c in report.checks}
    assert check_names.get("memory_store") == "ok"
