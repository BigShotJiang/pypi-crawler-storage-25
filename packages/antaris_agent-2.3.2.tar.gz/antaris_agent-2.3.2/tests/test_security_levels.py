"""Test suite for 5-level security architecture."""
from __future__ import annotations

import asyncio
import sys
import tempfile
import unittest.mock
from pathlib import Path
from unittest.mock import patch

import pytest

from antaris_agent.security import audit_hook, tool_middleware
from antaris_agent.security.levels import (
    LEVEL_OPEN, LEVEL_STANDARD, LEVEL_SANDBOXED, LEVEL_SECURED, LEVEL_ENCRYPTED,
    is_destructive_tool, can_escalate, level_name, DESTRUCTIVE_TOOL_KEYWORDS
)


class TestSecurityLevels:
    """Test security level constants and utilities."""

    def test_level_constants(self):
        """Test that level constants have correct values."""
        assert LEVEL_OPEN == 0
        assert LEVEL_STANDARD == 1
        assert LEVEL_SANDBOXED == 2
        assert LEVEL_SECURED == 3
        assert LEVEL_ENCRYPTED == 4

    def test_level_name(self):
        """Test level_name function returns correct names."""
        assert level_name(0) == "Open"
        assert level_name(1) == "Standard"
        assert level_name(2) == "Sandboxed"
        assert level_name(3) == "Secured"
        assert level_name(4) == "Encrypted"
        assert level_name(99) == "Unknown(99)"

    def test_can_escalate(self):
        """Test escalation rules (up only, no downgrade)."""
        # Valid escalations
        assert can_escalate(0, 1) is True
        assert can_escalate(1, 2) is True
        assert can_escalate(2, 3) is True
        assert can_escalate(3, 4) is True
        assert can_escalate(0, 4) is True
        
        # Invalid downgrades
        assert can_escalate(4, 3) is False
        assert can_escalate(3, 2) is False
        assert can_escalate(2, 1) is False
        assert can_escalate(1, 0) is False
        
        # Same level
        assert can_escalate(2, 2) is False

    def test_is_destructive_tool(self):
        """Test destructive tool detection."""
        # Destructive tools
        for keyword in DESTRUCTIVE_TOOL_KEYWORDS:
            assert is_destructive_tool(f"test_{keyword}_tool") is True
            assert is_destructive_tool(f"UPPER_{keyword.upper()}_TOOL") is True
        
        # Non-destructive tools
        assert is_destructive_tool("read_file") is False
        assert is_destructive_tool("list_directory") is False
        assert is_destructive_tool("search_memory") is False
        assert is_destructive_tool("get_weather") is False
        
        # Edge cases
        assert is_destructive_tool("") is False
        assert is_destructive_tool("completely_safe") is False


class TestAuditHook:
    """Test audit hook functionality across all levels."""

    def setup_method(self):
        """Reset audit hook state before each test."""
        # Reset module-level state
        audit_hook._LEVEL = LEVEL_STANDARD
        audit_hook._WORKSPACE = ""
        audit_hook._ALLOWED_PATHS = set()
        audit_hook._INSTALLED = False

    @patch('sys.addaudithook')
    def test_install_with_integer_levels(self, mock_hook):
        """Test install function accepts integer levels."""
        with tempfile.TemporaryDirectory() as tmpdir:
            # Test each level
            for level in range(5):
                audit_hook.install(level, tmpdir)
                assert audit_hook.current_level() == level

    @patch('sys.addaudithook')
    def test_install_with_legacy_string_modes(self, mock_hook):
        """Test backward compatibility with string modes."""
        with tempfile.TemporaryDirectory() as tmpdir:
            # Test legacy mode mapping
            audit_hook.install("open", tmpdir)
            assert audit_hook.current_level() == LEVEL_OPEN
            
            audit_hook.install("sandboxed", tmpdir)
            assert audit_hook.current_level() == LEVEL_SANDBOXED
            
            audit_hook.install("locked", tmpdir)
            assert audit_hook.current_level() == LEVEL_ENCRYPTED
            
            # Unknown mode defaults to STANDARD
            audit_hook.install("unknown", tmpdir)
            assert audit_hook.current_level() == LEVEL_STANDARD

    @patch('sys.addaudithook')
    def test_escalate_function(self, mock_hook):
        """Test escalate function enforces up-only rule."""
        with tempfile.TemporaryDirectory() as tmpdir:
            audit_hook.install(LEVEL_STANDARD, tmpdir)
            
            # Valid escalations
            assert audit_hook.escalate(LEVEL_SANDBOXED) is True
            assert audit_hook.current_level() == LEVEL_SANDBOXED
            
            assert audit_hook.escalate(LEVEL_ENCRYPTED) is True
            assert audit_hook.current_level() == LEVEL_ENCRYPTED
            
            # Invalid downgrade
            assert audit_hook.escalate(LEVEL_STANDARD) is False
            assert audit_hook.current_level() == LEVEL_ENCRYPTED
            
            # Same level
            assert audit_hook.escalate(LEVEL_ENCRYPTED) is False

    def test_add_allowed_host(self):
        """Test adding hosts to allowlist."""
        original_count = len(audit_hook.ALLOWED_HOSTS)
        audit_hook.add_allowed_host("example.com")
        assert "example.com" in audit_hook.ALLOWED_HOSTS
        assert len(audit_hook.ALLOWED_HOSTS) == original_count + 1

    @patch('sys.addaudithook')
    def test_level_0_skips_audit_hook(self, mock_addaudithook):
        """Test that Level 0 (OPEN) skips audit hook installation."""
        with tempfile.TemporaryDirectory() as tmpdir:
            audit_hook.install(LEVEL_OPEN, tmpdir)
            mock_addaudithook.assert_not_called()

    @patch('sys.addaudithook')
    def test_level_1_plus_installs_audit_hook(self, mock_addaudithook):
        """Test that Level 1+ installs audit hook."""
        with tempfile.TemporaryDirectory() as tmpdir:
            for level in range(1, 5):
                mock_addaudithook.reset_mock()
                audit_hook._INSTALLED = False  # Reset guard for each iteration
                audit_hook.install(level, tmpdir)
                mock_addaudithook.assert_called_once()

    @patch('sys.addaudithook')
    def test_level_1_file_access_permissions(self, mock_hook):
        """Test Level 1 (STANDARD) file access permissions."""
        with tempfile.TemporaryDirectory() as tmpdir:
            audit_hook.install(LEVEL_STANDARD, tmpdir)
            
            # Mock the hook to test file access logic
            hook = audit_hook._antaris_hook
            
            # Should allow workspace files
            hook("open", (str(Path(tmpdir) / "test.txt"),))
            
            # Should allow approved home subdirectory (.openclaw)
            hook("open", (str(Path.home() / ".openclaw" / "test.txt"),))
            
            # Should allow /tmp
            hook("open", ("/tmp/test.txt",))
            
            # Should block paths outside all allow-lists
            # Note: /etc paths are now allowed (stdlib reads MIME, SSL, passwd).
            # /root/.ssh/ is never allowed — it's outside workspace, home, tmp,
            # stdlib, and the system-read allow-list.
            with pytest.raises(PermissionError, match="File access blocked"):
                hook("open", ("/root/.ssh/id_rsa",))

    @patch('sys.addaudithook')
    def test_level_1_subprocess_allowed(self, mock_hook):
        """Test Level 1 (STANDARD) allows subprocesses."""
        with tempfile.TemporaryDirectory() as tmpdir:
            audit_hook.install(LEVEL_STANDARD, tmpdir)
            hook = audit_hook._antaris_hook
            
            # Should not raise for subprocess
            hook("subprocess.Popen", ("echo", "test"))

    @patch('sys.addaudithook')
    def test_level_2_plus_subprocess_blocked(self, mock_hook):
        """Test Level 2+ blocks subprocesses."""
        with tempfile.TemporaryDirectory() as tmpdir:
            for level in range(LEVEL_SANDBOXED, LEVEL_ENCRYPTED + 1):
                audit_hook.install(level, tmpdir)
                hook = audit_hook._antaris_hook
                
                with pytest.raises(PermissionError, match="Subprocess execution blocked"):
                    hook("subprocess.Popen", ("echo", "test"))

    @patch('sys.addaudithook')
    def test_level_3_plus_network_restrictions(self, mock_hook):
        """Test Level 3+ (SECURED/ENCRYPTED) network restrictions."""
        with tempfile.TemporaryDirectory() as tmpdir:
            for level in [LEVEL_SECURED, LEVEL_ENCRYPTED]:
                audit_hook.install(level, tmpdir)
                hook = audit_hook._antaris_hook
                
                # Should allow allowed hosts
                hook("socket.connect", (None, ("localhost", 80)))
                hook("socket.connect", (None, ("api.anthropic.com", 443)))
                
                # Should block non-allowed hosts
                with pytest.raises(PermissionError, match="Network access blocked"):
                    hook("socket.connect", (None, ("malicious.com", 80)))

    @patch('sys.addaudithook')
    def test_level_4_exec_blocked(self, mock_hook):
        """Test Level 4 (ENCRYPTED) blocks exec()."""
        with tempfile.TemporaryDirectory() as tmpdir:
            audit_hook.install(LEVEL_ENCRYPTED, tmpdir)
            hook = audit_hook._antaris_hook
            
            with pytest.raises(PermissionError, match="Code execution blocked"):
                hook("exec", ("print('hello')",))

    @patch('sys.addaudithook')
    def test_levels_0_3_exec_allowed(self, mock_hook):
        """Test Levels 0-3 allow exec()."""
        with tempfile.TemporaryDirectory() as tmpdir:
            for level in range(LEVEL_OPEN, LEVEL_SECURED + 1):
                audit_hook.install(level, tmpdir)
                hook = audit_hook._antaris_hook
                
                # Should not raise for exec
                hook("exec", ("print('hello')",))


class TestToolMiddleware:
    """Test tool middleware functionality across all levels."""

    @pytest.mark.asyncio
    async def test_tool_middleware_integer_levels(self):
        """Test ToolMiddleware accepts integer levels."""
        for level in range(5):
            middleware = tool_middleware.ToolMiddleware(level)
            assert middleware.level == level

    @pytest.mark.asyncio
    async def test_tool_middleware_legacy_string_modes(self):
        """Test ToolMiddleware backward compatibility with string modes."""
        middleware = tool_middleware.ToolMiddleware("open")
        assert middleware.level == LEVEL_OPEN
        
        middleware = tool_middleware.ToolMiddleware("sandboxed")
        assert middleware.level == LEVEL_SANDBOXED
        
        middleware = tool_middleware.ToolMiddleware("locked")
        assert middleware.level == LEVEL_ENCRYPTED
        
        middleware = tool_middleware.ToolMiddleware("unknown")
        assert middleware.level == LEVEL_STANDARD

    @pytest.mark.asyncio
    async def test_levels_0_1_no_approval_needed(self):
        """Test Levels 0-1 run tools without approval."""
        for level in [LEVEL_OPEN, LEVEL_STANDARD]:
            middleware = tool_middleware.ToolMiddleware(level)
            
            async def mock_tool():
                return "success"
            
            result = await middleware.approve_and_run("test_tool", {}, mock_tool)
            assert result == "success"

    @pytest.mark.asyncio
    async def test_level_2_prints_tool_name(self):
        """Test Level 2 (SANDBOXED) prints tool name."""
        middleware = tool_middleware.ToolMiddleware(LEVEL_SANDBOXED)
        
        async def mock_tool():
            return "success"
        
        with patch('builtins.print') as mock_print:
            result = await middleware.approve_and_run("test_tool", {}, mock_tool)
            assert result == "success"
            mock_print.assert_called_once_with("   [tool] test_tool", flush=True)

    @pytest.mark.asyncio
    async def test_level_3_destructive_tool_prompts(self):
        """Test Level 3 (SECURED) prompts for destructive tools."""
        with tempfile.NamedTemporaryFile() as audit_file:
            middleware = tool_middleware.ToolMiddleware(LEVEL_SECURED, audit_file.name)
            
            async def mock_tool():
                return "deleted"
            
            # Test destructive tool with "y" response
            with patch('builtins.input', return_value='y'):
                result = await middleware.approve_and_run("delete_file", {"path": "/test"}, mock_tool)
                assert result == "deleted"
            
            # Test destructive tool with "n" response
            with patch('builtins.input', return_value='n'):
                result = await middleware.approve_and_run("delete_file", {"path": "/test"}, mock_tool)
                assert result is None
            
            # Test non-destructive tool runs without prompt
            result = await middleware.approve_and_run("read_file", {"path": "/test"}, mock_tool)
            assert result == "deleted"  # mock returns this

    @pytest.mark.asyncio
    async def test_level_4_all_tools_need_approval(self):
        """Test Level 4 (ENCRYPTED) prompts for all tools."""
        with tempfile.NamedTemporaryFile() as audit_file:
            middleware = tool_middleware.ToolMiddleware(LEVEL_ENCRYPTED, audit_file.name)
            
            async def mock_tool():
                return "result"
            
            # Test approved tool
            with patch('builtins.input', return_value='y'):
                result = await middleware.approve_and_run("read_file", {"path": "/test"}, mock_tool)
                assert result == "result"
            
            # Test rejected tool
            with patch('builtins.input', return_value='n'):
                result = await middleware.approve_and_run("read_file", {"path": "/test"}, mock_tool)
                assert result is None

    @pytest.mark.asyncio
    async def test_tool_middleware_escalate(self):
        """Test ToolMiddleware escalate method."""
        middleware = tool_middleware.ToolMiddleware(LEVEL_STANDARD)
        
        # Valid escalation
        assert middleware.escalate(LEVEL_SANDBOXED) is True
        assert middleware.level == LEVEL_SANDBOXED
        
        # Invalid downgrade
        assert middleware.escalate(LEVEL_STANDARD) is False
        assert middleware.level == LEVEL_SANDBOXED

    @pytest.mark.asyncio
    async def test_audit_logging_levels_3_4(self):
        """Test audit logging works for levels 3-4."""
        with tempfile.NamedTemporaryFile() as audit_file:
            for level in [LEVEL_SECURED, LEVEL_ENCRYPTED]:
                middleware = tool_middleware.ToolMiddleware(level, audit_file.name)
                
                async def mock_tool():
                    return "test_result"
                
                with patch('builtins.input', return_value='y'):
                    result = await middleware.approve_and_run("test_tool", {"arg": "value"}, mock_tool)
                    assert result == "test_result"
                
                # Check that audit logger was created
                assert middleware._audit_logger is not None

    @pytest.mark.asyncio
    async def test_no_audit_logging_levels_0_2(self):
        """Test no audit logging for levels 0-2."""
        for level in [LEVEL_OPEN, LEVEL_STANDARD, LEVEL_SANDBOXED]:
            middleware = tool_middleware.ToolMiddleware(level)
            assert middleware._audit_logger is None


# Integration tests
class TestSecurityIntegration:
    """Integration tests for the complete security system."""

    @pytest.mark.asyncio
    @patch('sys.addaudithook')
    async def test_full_security_escalation_path(self, mock_hook):
        """Test escalating through all security levels."""
        with tempfile.TemporaryDirectory() as tmpdir:
            # Start at OPEN
            audit_hook.install(LEVEL_OPEN, tmpdir)
            middleware = tool_middleware.ToolMiddleware(LEVEL_OPEN)
            
            # Escalate through all levels
            for target_level in range(1, 5):
                assert audit_hook.escalate(target_level) is True
                assert middleware.escalate(target_level) is True
                assert audit_hook.current_level() == target_level
                assert middleware.level == target_level

    @pytest.mark.asyncio
    @patch('sys.addaudithook')
    async def test_backward_compatibility_integration(self, mock_hook):
        """Test that both modules handle legacy modes consistently."""
        with tempfile.TemporaryDirectory() as tmpdir:
            legacy_modes = ["open", "sandboxed", "locked"]
            
            for mode in legacy_modes:
                audit_hook.install(mode, tmpdir)
                middleware = tool_middleware.ToolMiddleware(mode)
                
                # Both should map to same level
                assert audit_hook.current_level() == middleware.level

    def test_destructive_tool_keywords_coverage(self):
        """Test that all expected destructive keywords are covered."""
        expected_keywords = {"write", "delete", "shell", "exec", "remove", "kill"}
        assert DESTRUCTIVE_TOOL_KEYWORDS == expected_keywords
        
        # Test that our function catches all variations
        test_tools = [
            "write_file", "delete_record", "shell_command", "exec_python",
            "remove_directory", "kill_process", "WRITE_DATA", "Delete_Item"
        ]
        
        for tool in test_tools:
            assert is_destructive_tool(tool) is True


if __name__ == "__main__":
    pytest.main([__file__, "-v"])