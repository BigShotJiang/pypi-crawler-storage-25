import pytest

from antaris_agent.llm.base import Message
from antaris_agent.llm.google import _to_gemini_parts


def test_to_gemini_parts_plain_text():
    parts = _to_gemini_parts("hello")
    assert parts == [{"text": "hello"}]


def test_to_gemini_parts_structured_vision_blocks():
    parts = _to_gemini_parts([
        {"type": "text", "text": "analyze this screenshot"},
        {
            "type": "image",
            "source": {
                "type": "base64",
                "media_type": "image/png",
                "data": "YWJj",
            },
        },
    ])

    assert parts[0] == {"text": "analyze this screenshot"}
    assert parts[1]["inline_data"]["mime_type"] == "image/png"
    assert parts[1]["inline_data"]["data"] == "YWJj"


def test_to_gemini_parts_tool_result_falls_back_to_text():
    parts = _to_gemini_parts([
        {"type": "tool_result", "content": "done"},
    ])
    assert parts == [{"text": "done"}]
