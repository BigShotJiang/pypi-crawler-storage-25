"""Test suite for SecurityLock system."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from unittest.mock import patch

import pytest

from antaris_agent.security.security_lock import LockConfig, SecurityLock


class TestLockConfig:
    """Test LockConfig dataclass."""
    
    def test_default_config(self):
        """Test default configuration."""
        config = LockConfig()
        assert config.enabled is False
        assert config.min_level == 0
        assert config.auth == "none"
        assert config.passphrase_hash == ""
        assert config.pin_hash == ""
    
    def test_to_dict_roundtrip(self):
        """Test to_dict and from_dict roundtrip."""
        original = LockConfig(
            enabled=True,
            min_level=3,
            auth="passphrase",
            passphrase_hash="abc123",
            pin_hash=""
        )
        
        # Convert to dict and back
        dict_repr = original.to_dict()
        reconstructed = LockConfig.from_dict(dict_repr)
        
        assert original == reconstructed
    
    def test_from_dict_with_extra_keys(self):
        """Test from_dict ignores extra keys gracefully."""
        data = {
            "enabled": True,
            "min_level": 2,
            "auth": "pin",
            "pin_hash": "def456",
            "extra_field": "should_be_ignored",
            "another_extra": 123
        }
        
        config = LockConfig.from_dict(data)
        assert config.enabled is True
        assert config.min_level == 2
        assert config.auth == "pin"
        assert config.pin_hash == "def456"
        assert config.passphrase_hash == ""  # Default value


class TestSecurityLock:
    """Test SecurityLock class."""
    
    def test_init_default_config_path(self):
        """Test initialization with default config path."""
        lock = SecurityLock()
        expected_path = Path.home() / ".antaris"
        assert lock._config_path == expected_path
        assert not lock.is_locked
        assert lock.min_level == 0
        assert lock.auth_method == "none"
    
    def test_init_custom_config_path(self, tmp_path):
        """Test initialization with custom config path."""
        lock = SecurityLock(config_path=tmp_path)
        assert lock._config_path == tmp_path
    
    def test_set_lock_with_passphrase(self, tmp_path):
        """Test setting lock with passphrase authentication."""
        lock = SecurityLock(config_path=tmp_path)
        
        result = lock.set_lock(min_level=3, auth="passphrase", passphrase="secret123")
        
        assert result is True
        assert lock.is_locked is True
        assert lock.min_level == 3
        assert lock.auth_method == "passphrase"
        assert lock._lock_config.passphrase_hash == hashlib.sha256(b"secret123").hexdigest()
        assert lock._lock_config.pin_hash == ""
        
        # Verify integrity file was created
        integrity_path = tmp_path / ".lock_integrity"
        assert integrity_path.exists()
    
    def test_set_lock_with_pin(self, tmp_path):
        """Test setting lock with PIN authentication."""
        lock = SecurityLock(config_path=tmp_path)
        
        result = lock.set_lock(min_level=2, auth="pin", pin="1234")
        
        assert result is True
        assert lock.is_locked is True
        assert lock.min_level == 2
        assert lock.auth_method == "pin"
        assert lock._lock_config.pin_hash == hashlib.sha256(b"1234").hexdigest()
        assert lock._lock_config.passphrase_hash == ""
    
    def test_set_lock_with_auth_none(self, tmp_path):
        """Test setting hard lock with auth=none."""
        lock = SecurityLock(config_path=tmp_path)
        
        result = lock.set_lock(min_level=4, auth="none")
        
        assert result is True
        assert lock.is_locked is True
        assert lock.min_level == 4
        assert lock.auth_method == "none"
        assert lock._lock_config.passphrase_hash == ""
        assert lock._lock_config.pin_hash == ""
    
    def test_set_lock_invalid_level_negative(self, tmp_path):
        """Test setting lock with invalid negative level."""
        lock = SecurityLock(config_path=tmp_path)
        
        result = lock.set_lock(min_level=-1)
        
        assert result is False
        assert not lock.is_locked
    
    def test_set_lock_invalid_level_too_high(self, tmp_path):
        """Test setting lock with invalid level > 4."""
        lock = SecurityLock(config_path=tmp_path)
        
        result = lock.set_lock(min_level=5)
        
        assert result is False
        assert not lock.is_locked
    
    def test_set_lock_invalid_auth_method(self, tmp_path):
        """Test setting lock with invalid auth method."""
        lock = SecurityLock(config_path=tmp_path)
        
        result = lock.set_lock(min_level=2, auth="invalid")
        
        assert result is False
        assert not lock.is_locked
    
    def test_set_lock_passphrase_auth_missing_passphrase(self, tmp_path):
        """Test setting passphrase auth without providing passphrase."""
        lock = SecurityLock(config_path=tmp_path)
        
        result = lock.set_lock(min_level=2, auth="passphrase", passphrase="")
        
        assert result is False
        assert not lock.is_locked
    
    def test_set_lock_pin_auth_missing_pin(self, tmp_path):
        """Test setting PIN auth without providing PIN."""
        lock = SecurityLock(config_path=tmp_path)
        
        result = lock.set_lock(min_level=2, auth="pin", pin="")
        
        assert result is False
        assert not lock.is_locked


class TestSecurityLockDowngradeChecks:
    """Test security lock downgrade checking logic."""
    
    def test_check_downgrade_not_locked_allows_all(self, tmp_path):
        """Test that unlocked state allows all level changes."""
        lock = SecurityLock(config_path=tmp_path)
        
        # Not locked - should allow any change
        allowed, msg = lock.check_downgrade(current_level=3, target_level=1)
        assert allowed is True
        assert msg == ""
        
        allowed, msg = lock.check_downgrade(current_level=0, target_level=4)
        assert allowed is True
        assert msg == ""
    
    def test_check_downgrade_escalation_allowed(self, tmp_path):
        """Test that escalation is always allowed."""
        lock = SecurityLock(config_path=tmp_path)
        lock.set_lock(min_level=2, auth="passphrase", passphrase="secret")
        
        allowed, msg = lock.check_downgrade(current_level=1, target_level=3)
        assert allowed is True
        assert msg == ""
    
    def test_check_downgrade_same_level_allowed(self, tmp_path):
        """Test that same level is allowed."""
        lock = SecurityLock(config_path=tmp_path)
        lock.set_lock(min_level=2, auth="passphrase", passphrase="secret")
        
        allowed, msg = lock.check_downgrade(current_level=3, target_level=3)
        assert allowed is True
        assert msg == ""
    
    def test_check_downgrade_above_floor_allowed(self, tmp_path):
        """Test that downgrade above floor level is allowed."""
        lock = SecurityLock(config_path=tmp_path)
        lock.set_lock(min_level=2, auth="passphrase", passphrase="secret")
        
        allowed, msg = lock.check_downgrade(current_level=4, target_level=3)
        assert allowed is True
        assert msg == ""
        
        allowed, msg = lock.check_downgrade(current_level=3, target_level=2)
        assert allowed is True
        assert msg == ""
    
    def test_check_downgrade_below_floor_auth_required(self, tmp_path):
        """Test downgrade below floor with auth returns auth required message."""
        lock = SecurityLock(config_path=tmp_path)
        lock.set_lock(min_level=3, auth="passphrase", passphrase="secret")
        
        allowed, msg = lock.check_downgrade(current_level=4, target_level=1)
        assert allowed is False
        assert "Authentication required to drop below level 3" in msg
    
    def test_check_downgrade_below_floor_auth_none_permanent_lock(self, tmp_path):
        """Test downgrade below floor with auth=none returns permanent lock message."""
        lock = SecurityLock(config_path=tmp_path)
        lock.set_lock(min_level=3, auth="none")
        
        allowed, msg = lock.check_downgrade(current_level=4, target_level=2)
        assert allowed is False
        assert "permanently locked" in msg
        assert "cannot drop below 3" in msg


class TestSecurityLockBypass:
    """Test lock bypass functionality."""
    
    def test_bypass_lock_not_enabled_always_true(self, tmp_path):
        """Test bypass returns True when lock is not enabled."""
        lock = SecurityLock(config_path=tmp_path)
        
        assert lock.bypass_lock() is True
        assert lock.bypass_lock(passphrase="anything") is True
    
    def test_bypass_lock_auth_none_always_false(self, tmp_path):
        """Test bypass returns False for hard lock (auth=none)."""
        lock = SecurityLock(config_path=tmp_path)
        lock.set_lock(min_level=3, auth="none")
        
        assert lock.bypass_lock() is False
        assert lock.bypass_lock(passphrase="anything") is False
        assert lock.bypass_lock(pin="1234") is False
    
    def test_bypass_lock_correct_passphrase(self, tmp_path):
        """Test bypass with correct passphrase."""
        lock = SecurityLock(config_path=tmp_path)
        lock.set_lock(min_level=3, auth="passphrase", passphrase="secret123")
        
        assert lock.bypass_lock(passphrase="secret123") is True
    
    def test_bypass_lock_wrong_passphrase(self, tmp_path):
        """Test bypass with wrong passphrase."""
        lock = SecurityLock(config_path=tmp_path)
        lock.set_lock(min_level=3, auth="passphrase", passphrase="secret123")
        
        assert lock.bypass_lock(passphrase="wrongpassword") is False
        assert lock.bypass_lock() is False
    
    def test_bypass_lock_correct_pin(self, tmp_path):
        """Test bypass with correct PIN."""
        lock = SecurityLock(config_path=tmp_path)
        lock.set_lock(min_level=2, auth="pin", pin="9876")
        
        assert lock.bypass_lock(pin="9876") is True
    
    def test_bypass_lock_wrong_pin(self, tmp_path):
        """Test bypass with wrong PIN."""
        lock = SecurityLock(config_path=tmp_path)
        lock.set_lock(min_level=2, auth="pin", pin="9876")
        
        assert lock.bypass_lock(pin="1234") is False
        assert lock.bypass_lock() is False


class TestSecurityLockDisable:
    """Test lock disable functionality."""
    
    def test_disable_lock_not_enabled_always_true(self, tmp_path):
        """Test disable returns True when lock is not enabled."""
        lock = SecurityLock(config_path=tmp_path)
        
        assert lock.disable_lock() is True
    
    def test_disable_lock_correct_passphrase(self, tmp_path):
        """Test disable with correct passphrase."""
        lock = SecurityLock(config_path=tmp_path)
        lock.set_lock(min_level=3, auth="passphrase", passphrase="secret123")
        
        # Verify lock is enabled
        assert lock.is_locked is True
        
        # Disable with correct passphrase
        result = lock.disable_lock(passphrase="secret123")
        assert result is True
        assert lock.is_locked is False
        
        # Verify integrity file was removed
        integrity_path = tmp_path / ".lock_integrity"
        assert not integrity_path.exists()
    
    def test_disable_lock_wrong_passphrase(self, tmp_path):
        """Test disable with wrong passphrase fails."""
        lock = SecurityLock(config_path=tmp_path)
        lock.set_lock(min_level=3, auth="passphrase", passphrase="secret123")
        
        result = lock.disable_lock(passphrase="wrongpassword")
        assert result is False
        assert lock.is_locked is True
    
    def test_disable_lock_auth_none_cannot_disable(self, tmp_path):
        """Test that hard lock (auth=none) cannot be disabled."""
        lock = SecurityLock(config_path=tmp_path)
        lock.set_lock(min_level=3, auth="none")
        
        result = lock.disable_lock()
        assert result is False
        assert lock.is_locked is True


class TestSecurityLockIntegrity:
    """Test integrity verification system."""
    
    def test_verify_integrity_no_integrity_file_no_lock(self, tmp_path):
        """Test verify_integrity when no integrity file and no lock in config."""
        lock = SecurityLock(config_path=tmp_path)
        
        lock_dict = {"enabled": False}
        result = lock.verify_integrity(lock_dict)
        assert result is True
    
    def test_verify_integrity_no_integrity_file_but_lock_enabled(self, tmp_path):
        """Test verify_integrity fails when lock enabled but no integrity file."""
        lock = SecurityLock(config_path=tmp_path)
        
        lock_dict = {"enabled": True, "min_level": 2}
        result = lock.verify_integrity(lock_dict)
        assert result is False
    
    def test_verify_integrity_matching_hmac(self, tmp_path):
        """Test verify_integrity succeeds when HMAC matches."""
        lock = SecurityLock(config_path=tmp_path)
        
        # Set up lock to create integrity file
        lock.set_lock(min_level=2, auth="pin", pin="1234")
        lock_dict = lock._lock_config.to_dict()
        
        result = lock.verify_integrity(lock_dict)
        assert result is True
    
    def test_verify_integrity_tampered_config(self, tmp_path):
        """Test verify_integrity fails when config has been tampered."""
        lock = SecurityLock(config_path=tmp_path)
        
        # Set up lock to create integrity file
        lock.set_lock(min_level=2, auth="pin", pin="1234")
        
        # Now create tampered config (different from what was locked)
        tampered_dict = {
            "enabled": True,
            "min_level": 1,  # Changed from 2
            "auth": "pin",
            "pin_hash": lock._lock_config.pin_hash
        }
        
        result = lock.verify_integrity(tampered_dict)
        assert result is False
    
    def test_verify_integrity_corrupted_integrity_file(self, tmp_path):
        """Test verify_integrity handles corrupted integrity file."""
        lock = SecurityLock(config_path=tmp_path)
        
        # Create corrupted integrity file
        integrity_path = tmp_path / ".lock_integrity"
        integrity_path.write_text("corrupted_hmac_data")
        
        lock_dict = {"enabled": True, "min_level": 2}
        result = lock.verify_integrity(lock_dict)
        assert result is False


class TestSecurityLockMachineId:
    """Test machine ID generation."""
    
    def test_machine_id_deterministic(self, tmp_path):
        """Test that machine ID is deterministic for same machine."""
        lock1 = SecurityLock(config_path=tmp_path)
        lock2 = SecurityLock(config_path=tmp_path)
        
        id1 = lock1._get_machine_id()
        id2 = lock2._get_machine_id()
        
        assert id1 == id2
        assert len(id1) == 64  # SHA-256 hex digest length
    
    @patch('platform.node')
    @patch('platform.system')
    @patch('platform.machine')
    @patch('uuid.getnode')
    def test_machine_id_exception_fallback(self, mock_getnode, mock_machine, mock_system, mock_node, tmp_path):
        """Test machine ID fallback when platform calls fail."""
        # Make platform calls raise exceptions
        mock_node.side_effect = Exception("Test exception")
        mock_system.side_effect = Exception("Test exception")
        mock_machine.side_effect = Exception("Test exception")
        mock_getnode.side_effect = Exception("Test exception")
        
        lock = SecurityLock(config_path=tmp_path)
        machine_id = lock._get_machine_id()

        # Should fall back to a per-install UUID (not the static "fallback-machine-id" string)
        assert machine_id is not None
        assert len(machine_id) > 0
        assert machine_id != "fallback-machine-id-INSECURE"  # absolute last resort not reached
        # Calling again should return the same persisted UUID
        machine_id_2 = lock._get_machine_id()
        assert machine_id == machine_id_2


class TestSecurityLockLoad:
    """Test loading configuration."""
    
    def test_load_config_from_dict(self, tmp_path):
        """Test loading lock config from dictionary."""
        lock = SecurityLock(config_path=tmp_path)
        
        config_dict = {
            "enabled": True,
            "min_level": 3,
            "auth": "passphrase",
            "passphrase_hash": "abc123",
            "pin_hash": ""
        }
        
        lock.load(config_dict)
        
        assert lock.is_locked is True
        assert lock.min_level == 3
        assert lock.auth_method == "passphrase"
        assert lock._lock_config.passphrase_hash == "abc123"


class TestSecurityLockStatus:
    """Test status reporting."""
    
    def test_get_status_unlocked(self, tmp_path):
        """Test status when lock is disabled."""
        lock = SecurityLock(config_path=tmp_path)
        
        status = lock.get_status()
        expected = {
            "enabled": False,
            "min_level": 0,
            "auth": "none",
            "has_passphrase": False,
            "has_pin": False,
        }
        
        assert status == expected
    
    def test_get_status_locked_with_passphrase(self, tmp_path):
        """Test status when locked with passphrase."""
        lock = SecurityLock(config_path=tmp_path)
        lock.set_lock(min_level=3, auth="passphrase", passphrase="secret")
        
        status = lock.get_status()
        expected = {
            "enabled": True,
            "min_level": 3,
            "auth": "passphrase",
            "has_passphrase": True,
            "has_pin": False,
        }
        
        assert status == expected
    
    def test_get_status_locked_with_pin(self, tmp_path):
        """Test status when locked with PIN."""
        lock = SecurityLock(config_path=tmp_path)
        lock.set_lock(min_level=2, auth="pin", pin="1234")
        
        status = lock.get_status()
        expected = {
            "enabled": True,
            "min_level": 2,
            "auth": "pin",
            "has_passphrase": False,
            "has_pin": True,
        }
        
        assert status == expected