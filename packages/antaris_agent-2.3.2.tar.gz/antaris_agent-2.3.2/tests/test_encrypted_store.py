import base64
from pathlib import Path

import pytest

from antaris_agent.security import encrypted_store


def test_load_key_from_keyring_returns_32_bytes(monkeypatch):
    key = b"k" * 32

    class FakeKeyring:
        def get_password(self, service, account):
            return base64.urlsafe_b64encode(key).decode()

        def set_password(self, service, account, value):
            raise AssertionError("should not write when key already exists")

    monkeypatch.setitem(__import__("sys").modules, "keyring", FakeKeyring())

    loaded = encrypted_store.load_or_create_key(service="svc", account="acct")
    assert loaded == key


def test_env_key_invalid_length_raises(monkeypatch):
    bad = base64.urlsafe_b64encode(b"short").decode()
    monkeypatch.setenv("ANTARISBOT_MEMORY_KEY", bad)

    # Ensure keyring path returns None
    class FakeKeyring:
        def get_password(self, service, account):
            return None

        def set_password(self, service, account, value):
            return None

    monkeypatch.setitem(__import__("sys").modules, "keyring", FakeKeyring())

    with pytest.raises(ValueError, match="Invalid key length"):
        encrypted_store.load_or_create_key(service="svc", account="acct")


def test_encrypt_decrypt_roundtrip():
    key = b"a" * 32
    data = {"hello": "world", "n": 1}
    blob = encrypted_store.encrypt_json(data, key)
    out = encrypted_store.decrypt_json(blob, key)
    assert out == data


def test_save_load_store_roundtrip(tmp_path: Path):
    key = b"b" * 32
    data = {"x": 123, "nested": {"y": "z"}}
    p = tmp_path / "store.bin"
    encrypted_store.save_store(p, data, key)
    assert p.exists()
    out = encrypted_store.load_store(p, key)
    assert out == data


def test_env_key_checked_before_keyring(monkeypatch):
    """ANTARISBOT_MEMORY_KEY should be checked before any keyring import."""
    key = b"e" * 32
    monkeypatch.setenv("ANTARISBOT_MEMORY_KEY", base64.urlsafe_b64encode(key).decode())

    # Even if keyring is not importable, env var should work
    monkeypatch.setitem(__import__("sys").modules, "keyring", None)

    loaded = encrypted_store.load_or_create_key(service="svc", account="acct")
    assert loaded == key


def test_no_keyring_no_env_raises(monkeypatch):
    """Without env var and without keyring, load_or_create_key must raise RuntimeError."""
    monkeypatch.delenv("ANTARISBOT_MEMORY_KEY", raising=False)
    # Make keyring unimportable
    monkeypatch.setitem(__import__("sys").modules, "keyring", None)

    with pytest.raises((RuntimeError, ImportError)):
        encrypted_store.load_or_create_key(service="svc", account="acct")


def test_keyring_persistence_failure_raises(monkeypatch):
    """If passphrase derivation succeeds but keyring.set_password fails, must raise."""
    monkeypatch.delenv("ANTARISBOT_MEMORY_KEY", raising=False)

    class FailingKeyring:
        def get_password(self, service, account):
            return None

        def set_password(self, service, account, value):
            raise OSError("keyring backend broken")

    monkeypatch.setitem(__import__("sys").modules, "keyring", FailingKeyring())
    monkeypatch.setattr("getpass.getpass", lambda prompt="": "test-passphrase")

    with pytest.raises(RuntimeError, match="could not be persisted"):
        encrypted_store.load_or_create_key(service="svc", account="acct")
