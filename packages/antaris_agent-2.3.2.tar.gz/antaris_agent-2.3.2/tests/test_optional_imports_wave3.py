import builtins
import importlib
import sys

import pytest


@pytest.mark.parametrize(
    ("module_name", "blocked_roots"),
    [
        ("antaris_agent.channels.discord", {"discord"}),
        ("antaris_agent.channels.slack", {"slack_bolt"}),
        ("antaris_agent.channels.telegram", {"telegram"}),
    ],
)
def test_optional_channel_modules_import_without_optional_dependencies(module_name, blocked_roots):
    original_import = builtins.__import__
    saved = {name: sys.modules.pop(name, None) for name in list(sys.modules) if name == module_name or name.startswith(module_name + ".")}

    def fake_import(name, globals=None, locals=None, fromlist=(), level=0):
        root = name.split(".", 1)[0]
        if root in blocked_roots:
            raise ImportError(f"blocked optional dependency: {name}")
        return original_import(name, globals, locals, fromlist, level)

    try:
        with pytest.MonkeyPatch.context() as mp:
            mp.setattr(builtins, "__import__", fake_import)
            module = importlib.import_module(module_name)
            assert module is not None
    finally:
        sys.modules.pop(module_name, None)
        for name, module_obj in saved.items():
            if module_obj is not None:
                sys.modules[name] = module_obj


@pytest.mark.parametrize(
    ("module_name", "blocked_roots"),
    [
        ("antaris_agent.tools.native.discord_proactive", {"discord"}),
    ],
)
def test_optional_tool_modules_import_without_optional_dependencies(module_name, blocked_roots):
    """Tools that depend on optional packages should import cleanly at module level."""
    original_import = builtins.__import__
    saved = {name: sys.modules.pop(name, None) for name in list(sys.modules) if name == module_name or name.startswith(module_name + ".")}

    def fake_import(name, globals=None, locals=None, fromlist=(), level=0):
        root = name.split(".", 1)[0]
        if root in blocked_roots:
            raise ImportError(f"blocked optional dependency: {name}")
        return original_import(name, globals, locals, fromlist, level)

    try:
        with pytest.MonkeyPatch.context() as mp:
            mp.setattr(builtins, "__import__", fake_import)
            module = importlib.import_module(module_name)
            assert module is not None
    finally:
        sys.modules.pop(module_name, None)
        for name, module_obj in saved.items():
            if module_obj is not None:
                sys.modules[name] = module_obj


def test_package_version_matches_runtime_surfaces():
    import antaris_agent
    from antaris_agent import cli
    from antaris_agent import _version

    assert antaris_agent.__version__ == _version.__version__
    assert cli.VERSION == _version.__version__


def test_updater_reads_version_from_canonical_source():
    """Updater should get the real version even with dynamic pyproject.toml."""
    from antaris_agent.core.updater import Updater
    from antaris_agent._version import __version__

    u = Updater.__new__(Updater)
    # _read_version_from_source is the fallback when pkg metadata is missing
    result = u._read_version_from_source()
    assert result == __version__, (
        f"Updater._read_version_from_source() returned {result!r}, "
        f"expected {__version__!r} from _version.py"
    )


def test_suite_component_versions_are_consistent():
    """All suite component __version__ strings should match the parent suite version."""
    from antaris_agent.suite import __version__ as suite_ver
    from antaris_agent.suite.guard import __version__ as guard_ver
    from antaris_agent.suite.router import __version__ as router_ver
    from antaris_agent.suite.pipeline import __version__ as pipeline_ver
    from antaris_agent.suite.context import __version__ as context_ver

    assert guard_ver == suite_ver, f"guard {guard_ver} != suite {suite_ver}"
    assert router_ver == suite_ver, f"router {router_ver} != suite {suite_ver}"
    assert pipeline_ver == suite_ver, f"pipeline {pipeline_ver} != suite {suite_ver}"
    assert context_ver == suite_ver, f"context {context_ver} != suite {suite_ver}"
