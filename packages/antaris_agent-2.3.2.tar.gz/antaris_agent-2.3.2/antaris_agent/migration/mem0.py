from __future__ import annotations

from pathlib import Path
from typing import Optional

from .base import BaseMigration, MigrationResult, ScanResult


class Mem0Migration(BaseMigration):
    """
    Migrates from mem0 to Antaris Agent.

    Detection: checks for ~/.mem0/ directory or Qdrant data at /tmp/qdrant/.
    Memory: reads Qdrant collections, extracts text, ingests via MemorySystem.
    Config: extracts LLM provider info if available.
    """

    def detect(self) -> bool:
        # Check explicit source_path first
        if not self.source_path.exists():
            return False
        if (self.source_path / ".mem0").exists():
            return True
        if (self.source_path / "mem0_data").exists():
            return True

        # Only check global default locations when source_path is the home dir
        home = Path.home()
        if self.source_path == home or self.source_path == home / ".mem0":
            if (home / ".mem0").exists():
                return True
            if Path("/tmp/qdrant").exists():
                return True
        return False

    def scan(self) -> ScanResult:
        result = ScanResult()
        result.has_config = False

        mem0_dir = self._find_mem0_dir()
        if mem0_dir:
            # Estimate memory count from files
            result.memory_count = len(list(mem0_dir.rglob("*.json")))
            result.notes.append(f"mem0 data at {mem0_dir}")

        qdrant_path = Path("/tmp/qdrant")
        if qdrant_path.exists():
            result.notes.append("Qdrant instance found at /tmp/qdrant")

        return result

    def migrate(self, selections: Optional[list[str]] = None) -> MigrationResult:
        result = MigrationResult(success=True, source="mem0")

        mem0_dir = self._find_mem0_dir()

        # Only check global Qdrant when source is home dir
        qdrant_path = Path("/tmp/qdrant")
        home = Path.home()
        use_qdrant = qdrant_path.exists() and (
            self.source_path == home
            or self.source_path == qdrant_path
        )

        if not mem0_dir and not use_qdrant:
            result.success = False
            result.errors.append(
                "No mem0 data found. Expected ~/.mem0/ or Qdrant at /tmp/qdrant/. "
                "Export your mem0 data as JSON and use --from custom instead."
            )
            return result

        # Try Qdrant import
        if use_qdrant:
            count = self._import_from_qdrant(qdrant_path, result)
            result.items_migrated["memories"] = count
        elif mem0_dir:
            count = self._import_from_mem0_dir(mem0_dir, result)
            result.items_migrated["memories"] = count
        else:
            result.warnings.append(
                "mem0 migration: no Qdrant collections found. "
                "Export your mem0 data as JSON and use --from custom."
            )
            result.items_migrated["memories"] = 0

        return result

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _find_mem0_dir(self) -> Optional[Path]:
        """Find mem0 data directory."""
        candidates: list[Path] = [
            self.source_path / ".mem0",
            self.source_path / "mem0_data",
        ]
        # Only add global path when source is home directory
        home = Path.home()
        if self.source_path == home:
            candidates.append(home / ".mem0")
        for c in candidates:
            if c.exists():
                return c
        return None

    def _import_from_qdrant(self, qdrant_path: Path, result: MigrationResult) -> int:
        """Read Qdrant collections and ingest text content."""
        try:
            from qdrant_client import QdrantClient  # type: ignore[import]
        except ImportError:
            result.warnings.append(
                "qdrant-client not installed. Run: pip install qdrant-client. "
                "Falling back to file-based import."
            )
            return self._import_from_files(qdrant_path)

        try:
            client = QdrantClient(path=str(qdrant_path))
            collections = client.get_collections().collections
            texts: list[str] = []
            for col in collections:
                try:
                    points = client.scroll(
                        collection_name=col.name,
                        limit=10000,
                        with_payload=True,
                        with_vectors=False,
                    )[0]
                    for pt in points:
                        payload = pt.payload or {}
                        text = (
                            payload.get("text")
                            or payload.get("content")
                            or payload.get("data")
                            or ""
                        )
                        if text and isinstance(text, str):
                            texts.append(text)
                except Exception as e:
                    result.warnings.append(f"Could not read collection {col.name}: {e}")

            if not texts:
                result.warnings.append("No text content found in Qdrant collections")
                return 0

            return self._import_memories(texts, self.user_id, source="mem0-import")
        except Exception as e:
            result.warnings.append(f"Qdrant import failed: {e}")
            return self._import_from_files(qdrant_path)

    def _import_from_mem0_dir(self, mem0_dir: Path, result: MigrationResult) -> int:
        """Import from mem0 directory JSON files."""
        return self._import_from_files(mem0_dir)

    def _import_from_files(self, directory: Path) -> int:
        """Generic fallback: scan directory for JSON files and extract text."""
        import json as _json
        texts: list[str] = []
        for f in directory.rglob("*.json"):
            try:
                data = _json.loads(f.read_text())
                if isinstance(data, list):
                    for item in data:
                        if isinstance(item, dict):
                            text = item.get("text") or item.get("content") or item.get("memory", "")
                            if text:
                                texts.append(str(text))
                elif isinstance(data, dict):
                    text = data.get("text") or data.get("content") or data.get("memory", "")
                    if text:
                        texts.append(str(text))
            except Exception:
                continue
        if not texts:
            return 0
        return self._import_memories(texts, self.user_id, source="mem0-import")
