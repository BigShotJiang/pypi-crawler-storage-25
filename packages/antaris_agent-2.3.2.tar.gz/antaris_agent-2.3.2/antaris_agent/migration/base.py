from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


@dataclass
class ScanResult:
    """What a migration source has available to import."""
    identity_files: list[str] = field(default_factory=list)
    memory_count: int = 0
    has_config: bool = False
    has_channels: bool = False
    notes: list[str] = field(default_factory=list)

    def summary(self) -> str:
        lines = ["Available to import:"]
        if self.identity_files:
            lines.append(f"  Identity files: {', '.join(self.identity_files)}")
        lines.append(f"  Memories: {self.memory_count}")
        lines.append(f"  Config: {'yes' if self.has_config else 'no'}")
        lines.append(f"  Channels: {'yes' if self.has_channels else 'no'}")
        for note in self.notes:
            lines.append(f"  Note: {note}")
        return "\n".join(lines)


@dataclass
class MigrationResult:
    success: bool
    source: str
    items_migrated: dict = field(default_factory=dict)
    # items_migrated e.g. {"soul": True, "user": True, "memories": 1247, "config": True}
    warnings: list = field(default_factory=list)
    errors: list = field(default_factory=list)

    def summary(self) -> str:
        lines = [f"Migration from {self.source}:"]
        for key, val in self.items_migrated.items():
            if isinstance(val, bool):
                status = "✅" if val else "⚠️  skipped"
                lines.append(f"  {status} {key}")
            else:
                lines.append(f"  ✅ {key}: {val}")
        if self.warnings:
            for w in self.warnings:
                lines.append(f"  ⚠️  {w}")
        if self.errors:
            for e in self.errors:
                lines.append(f"  ❌ {e}")
        return "\n".join(lines)


class BaseMigration(ABC):
    """
    Abstract base class for all migration sources.

    Subclasses implement detect(), scan(), and migrate().
    Helper methods handle common operations like copying identity files,
    translating configs, and importing memories.
    """

    def __init__(
        self,
        source_path: str,
        dest_path: str,
        dry_run: bool = False,
        user_id: str = "migrated-user",
    ):
        self.source_path = Path(source_path)
        self.dest_path = Path(dest_path)
        self.dry_run = dry_run
        self.user_id = user_id

    @abstractmethod
    def detect(self) -> bool:
        """Return True if this source exists and looks valid at source_path."""

    def scan(self) -> ScanResult:
        """Enumerate what is available in the source. Default implementation."""
        return ScanResult()

    @abstractmethod
    def migrate(self, selections: Optional[list[str]] = None) -> MigrationResult:
        """Perform the migration. Return result."""

    # ------------------------------------------------------------------
    # Core helpers
    # ------------------------------------------------------------------

    def _write(self, dest: Path, content: str):
        """Write content to dest, respecting dry_run. Creates parents."""
        if self.dry_run:
            print(f"  [dry-run] would write: {dest}")
            return
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(content)

    def _copy_file(self, src: Path, dest: Path) -> bool:
        """Copy a single file, respecting dry_run. Returns True on success."""
        import shutil
        if not src.exists():
            return False
        if self.dry_run:
            print(f"  [dry-run] would copy: {src} -> {dest}")
            return True
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(str(src), str(dest))
        return True

    # ------------------------------------------------------------------
    # Identity file helpers
    # ------------------------------------------------------------------

    IDENTITY_FILES = [
        "SOUL.md",
        "AGENTS.md",
        "MEMORY.md",
        "TOOLS.md",
        "USER.md",
        "HEARTBEAT.md",
        "IDENTITY.md",
    ]

    def _copy_identity_files(
        self,
        source_dir: Path,
        dest_dir: Path,
        files: Optional[list[str]] = None,
    ) -> dict[str, bool]:
        """
        Copy identity markdown files from source_dir to dest_dir.
        Returns a dict of filename -> success.
        """
        results: dict[str, bool] = {}
        targets = files or self.IDENTITY_FILES
        for name in targets:
            src = source_dir / name
            ok = self._copy_file(src, dest_dir / name)
            results[name] = ok
        return results

    # ------------------------------------------------------------------
    # Config translation helpers
    # ------------------------------------------------------------------

    def _translate_config(self, openclaw_cfg: dict) -> dict:
        """
        Translate an openclaw.json dict into Antaris Agent config.json structure.
        Returns the translated dict (does not write to disk).
        """
        import json

        antaris_cfg: dict = {
            "bot": {"name": "Antaris"},
            "provider": {},
            "channels": {},
            "memory": {
                "store": str(self.dest_path / "memory"),
                "searchLimit": 10,
                "minRelevance": 0.3,
                "autoIngest": True,
                "autoRecall": True,
            },
            "guard": {"mode": "monitor"},
            "security": {"mode": "sandboxed"},
        }

        # Provider: from auth.profiles
        profiles = openclaw_cfg.get("auth", {}).get("profiles", {})
        if profiles:
            # Take the first profile
            for profile_name, profile in profiles.items():
                antaris_cfg["provider"] = {
                    "name": profile.get("provider", profile_name),
                    "apiKey": profile.get("apiKey", profile.get("key", "")),
                    "model": profile.get("model", "claude-sonnet-4-6"),
                    "fallbackModel": profile.get("fallbackModel", ""),
                }
                break
        else:
            # Try top-level provider block
            prov = openclaw_cfg.get("provider", {})
            if prov:
                antaris_cfg["provider"] = {
                    "name": prov.get("name", "anthropic"),
                    "apiKey": prov.get("apiKey", prov.get("key", "")),
                    "model": prov.get("model", "claude-sonnet-4-6"),
                    "fallbackModel": prov.get("fallbackModel", ""),
                }

        # Channels
        channels_src = openclaw_cfg.get("channels", {})

        discord_src = channels_src.get("discord", {})
        if discord_src:
            guilds = discord_src.get("guilds", discord_src.get("servers", []))
            open_channels: list[str] = discord_src.get("openChannels", [])
            # Flatten guilds -> open channels if present
            if guilds and not open_channels:
                for g in guilds:
                    if isinstance(g, dict):
                        open_channels.extend(g.get("openChannels", []))

            allowlist: list[str] = discord_src.get("allowlist", discord_src.get("allowedUsers", []))
            antaris_cfg["channels"]["discord"] = {
                "enabled": bool(discord_src.get("token", "")),
                "token": discord_src.get("token", ""),
                "openChannels": open_channels,
                "allowlist": allowlist,
                "requireMention": discord_src.get("requireMention", True),
            }

        telegram_src = channels_src.get("telegram", {})
        if telegram_src:
            antaris_cfg["channels"]["telegram"] = {
                "enabled": bool(telegram_src.get("token", "")),
                "token": telegram_src.get("token", ""),
                "openChats": telegram_src.get("openChats", telegram_src.get("allowedChats", [])),
            }

        slack_src = channels_src.get("slack", {})
        if slack_src:
            antaris_cfg["channels"]["slack"] = {
                "enabled": bool(slack_src.get("botToken", slack_src.get("bot_token", ""))),
                "botToken": slack_src.get("botToken", slack_src.get("bot_token", "")),
                "appToken": slack_src.get("appToken", slack_src.get("app_token", "")),
                "openChannels": slack_src.get("openChannels", slack_src.get("channels", [])),
            }

        # Additional channels stored as-is for reference
        for extra_ch in ("imessage", "signal", "irc", "googlechat"):
            ch_data = channels_src.get(extra_ch, {})
            if ch_data:
                antaris_cfg["channels"][extra_ch] = ch_data

        return antaris_cfg

    def _translate_router_config(self, openclaw_cfg: dict) -> dict:
        """
        Build router/config.json from openclaw models.providers section.
        Returns the router config dict.
        """
        router_cfg: dict = {"models": [], "routing": {"strategy": "fallback"}}
        providers = openclaw_cfg.get("models", {}).get("providers", {})
        if not providers:
            # Try top-level providers block
            providers = openclaw_cfg.get("providers", {})

        tier_map = {0: "fast", 1: "balanced", 2: "powerful"}
        for i, (prov_name, prov_data) in enumerate(providers.items()):
            if isinstance(prov_data, dict):
                models_list = prov_data.get("models", [])
                if isinstance(models_list, list):
                    for j, model in enumerate(models_list):
                        router_cfg["models"].append({
                            "provider": prov_name,
                            "model": model if isinstance(model, str) else model.get("name", ""),
                            "tier": tier_map.get(j, "balanced"),
                        })
                elif isinstance(models_list, str):
                    router_cfg["models"].append({
                        "provider": prov_name,
                        "model": models_list,
                        "tier": tier_map.get(i, "balanced"),
                    })

        return router_cfg

    # ------------------------------------------------------------------
    # Memory import helpers
    # ------------------------------------------------------------------

    def _import_memories(
        self,
        texts: list[str],
        user_id: str,
        source: str = "migration",
        memory_store: Optional[str] = None,
    ) -> int:
        """
        Ingest a list of text strings into MemorySystem.
        Returns count of successfully ingested items.
        """
        store_path = memory_store or str(self.dest_path / "memory")
        if self.dry_run:
            print(f"  [dry-run] would ingest {len(texts)} memories for user {user_id}")
            return len(texts)
        try:
            from parsica_memory import MemorySystem
            user_path = Path(store_path) / user_id
            user_path.mkdir(parents=True, exist_ok=True)
            ms = MemorySystem(workspace=str(user_path))
            try:
                ms.load()
            except Exception:
                pass
            count = 0
            for text in texts:
                if text and text.strip():
                    ms.ingest(text.strip(), source=source, category="migration")
                    count += 1
            ms.save()
            return count
        except ImportError:
            print("  ⚠️  parsica-memory not installed. Storing memories as flat files.")
            return self._import_memories_flat(texts, user_id, source, store_path)
        except Exception as e:
            print(f"  ⚠️  Memory ingest failed: {e}")
            return 0

    def _import_memories_flat(
        self,
        texts: list[str],
        user_id: str,
        source: str,
        store_path: str,
    ) -> int:
        """Fallback: write memories as a flat markdown file."""
        dest_dir = Path(store_path) / user_id
        dest_dir.mkdir(parents=True, exist_ok=True)
        out_file = dest_dir / f"{source}-import.md"
        content = "\n\n".join(t.strip() for t in texts if t and t.strip())
        out_file.write_text(content)
        return len(texts)

    def _translate_channels(self, openclaw_cfg: dict) -> dict:
        """Extract channel config from openclaw.json. Returns channels dict."""
        return self._translate_config(openclaw_cfg).get("channels", {})


# Keep MigrationSource as alias for backward compat
MigrationSource = BaseMigration
