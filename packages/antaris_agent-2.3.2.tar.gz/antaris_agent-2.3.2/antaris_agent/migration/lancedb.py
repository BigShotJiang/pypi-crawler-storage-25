from __future__ import annotations

from pathlib import Path
from typing import Optional

from .base import BaseMigration, MigrationResult, ScanResult


class LanceDBMigration(BaseMigration):
    """
    Migrates from LanceDB vector store to Antaris Agent.

    Detection: scan for .lance directories or .lancedb/ folders.
    Memory: open LanceDB table, read all rows, extract text field, ingest.

    Requires the 'lancedb' package. If not installed, prints a helpful message.
    """

    def detect(self) -> bool:
        search_path = self.source_path
        if not search_path.exists():
            return False

        # .lancedb/ folder
        if (search_path / ".lancedb").exists():
            return True

        # Any .lance directory in the tree
        if list(search_path.rglob("*.lance")):
            return True

        # Common openclaw memory path with lance format
        openclaw_mem = Path.home() / ".openclaw" / "memory"
        if openclaw_mem.exists() and list(openclaw_mem.rglob("*.lance")):
            return True

        return False

    def scan(self) -> ScanResult:
        result = ScanResult()
        tables = self._find_lance_tables()
        result.memory_count = len(tables)
        for t in tables:
            result.notes.append(f"LanceDB table: {t}")
        return result

    def migrate(self, selections: Optional[list[str]] = None) -> MigrationResult:
        result = MigrationResult(success=True, source="LanceDB")

        try:
            import lancedb  # type: ignore[import]  # noqa: F401
        except ImportError:
            result.success = False
            result.errors.append(
                "lancedb package is not installed. "
                "Run: pip install lancedb -- then retry."
            )
            return result

        tables = self._find_lance_tables()
        if not tables:
            result.success = False
            result.errors.append(
                "No LanceDB tables found. "
                "Expected .lance directories or a .lancedb/ folder."
            )
            return result

        texts: list[str] = []
        for table_path in tables:
            table_texts = self._extract_from_lance_table(table_path, result)
            texts.extend(table_texts)

        if not texts:
            result.warnings.append("No text content found in LanceDB tables")
            result.items_migrated["memories"] = 0
            return result

        count = self._import_memories(texts, self.user_id, source="lancedb-import")
        result.items_migrated["memories"] = count
        result.items_migrated["tables"] = len(tables)
        return result

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _find_lance_tables(self) -> list[Path]:
        """Find all .lance table directories."""
        found: list[Path] = []

        search_paths = [self.source_path]
        # Also check openclaw memory path
        openclaw_mem = Path.home() / ".openclaw" / "memory"
        if openclaw_mem.exists() and openclaw_mem != self.source_path:
            search_paths.append(openclaw_mem)

        for base in search_paths:
            if not base.exists():
                continue
            # .lancedb/ directory contains table subdirectories
            lancedb_dir = base / ".lancedb"
            if lancedb_dir.exists():
                for child in lancedb_dir.iterdir():
                    if child.is_dir():
                        found.append(child)
            # Direct .lance dirs
            for lance_dir in base.rglob("*.lance"):
                if lance_dir.is_dir() and lance_dir not in found:
                    found.append(lance_dir)

        return list(dict.fromkeys(found))

    def _extract_from_lance_table(
        self, table_path: Path, result: MigrationResult
    ) -> list[str]:
        """Open a LanceDB table directory and extract text rows."""
        try:
            import lancedb  # type: ignore[import]
            # Open the parent directory as a LanceDB connection
            parent = table_path.parent
            table_name = table_path.name.replace(".lance", "")
            db = lancedb.connect(str(parent))
            table = db.open_table(table_name)
            rows = table.to_pandas()
            texts: list[str] = []
            for _, row in rows.iterrows():
                text = (
                    row.get("text")
                    or row.get("content")
                    or row.get("document")
                    or row.get("page_content")
                    or ""
                )
                if text and isinstance(text, str) and text.strip():
                    texts.append(text.strip())
            return texts
        except Exception as e:
            result.warnings.append(f"Could not read LanceDB table {table_path.name}: {e}")
            return []
