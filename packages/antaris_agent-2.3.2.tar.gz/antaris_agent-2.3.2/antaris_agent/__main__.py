from antaris_agent.cli import main

main()
