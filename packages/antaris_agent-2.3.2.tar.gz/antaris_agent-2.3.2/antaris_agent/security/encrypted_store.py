"""Antaris Agent encrypted store — AES-256-GCM key management and data encryption primitives.

Provides key loading (env var / keyring / passphrase derivation) and
AES-256-GCM encrypt/decrypt helpers.  These primitives are used for
encrypted metadata stores.  Memory shard encryption (data-at-rest) is
planned for a future release.
"""
from __future__ import annotations

import base64
import getpass
import json
import logging
import os
from pathlib import Path

logger = logging.getLogger(__name__)


def validate_key(key: bytes) -> None:
    """Validate that *key* is a 32-byte AES-256 key.

    Raises:
        ValueError: if key is not exactly 32 bytes.
    """
    if not isinstance(key, (bytes, bytearray)):
        raise ValueError("Key must be bytes")
    if len(key) != 32:
        raise ValueError(f"Invalid key length: {len(key)} (expected 32)")


def load_or_create_key(
    service: str = "antaris-agent",
    account: str = "memory-key",
) -> bytes:
    """Return a 32-byte AES key, loading from env / keyring / passphrase derivation.

    Resolution order:
    1. ``ANTARISBOT_MEMORY_KEY`` env var — base64url-encoded key (checked first,
       no dependencies required)
    2. ``keyring.get_password(service, account)`` — base64url-encoded stored key
       (requires ``pip install antaris-agent[secure-store]``)
    3. Interactive passphrase → Scrypt derivation → persisted in keyring
       (requires both keyring and cryptography)

    Returns:
        32 bytes (256-bit key).

    Raises:
        RuntimeError: if no key source is available or persistence fails.
        ValueError: if a stored/env key is the wrong length.
    """
    # 1. Environment variable — checked FIRST, no imports needed
    env_val = os.environ.get("ANTARISBOT_MEMORY_KEY")
    if env_val:
        key = base64.urlsafe_b64decode(env_val.encode())
        validate_key(key)
        return key

    # 2. Keyring — optional dependency
    try:
        import keyring
    except ImportError:
        keyring = None  # type: ignore[assignment]

    if keyring is not None:
        try:
            stored = keyring.get_password(service, account)
            if stored:
                key = base64.urlsafe_b64decode(stored.encode())
                validate_key(key)
                return key
        except ValueError as e:
            # Key exists in keyring but is wrong length/type — warn loudly
            logger.warning(
                "Keyring key for %s/%s is invalid (%s) — falling through to passphrase",
                service, account, e,
            )
        except Exception as e:
            logger.debug("Keyring lookup failed: %s", e)

    # 3. Interactive passphrase derivation — requires keyring for persistence
    if keyring is None:
        raise RuntimeError(
            "Encrypted mode needs either ANTARISBOT_MEMORY_KEY env var "
            "or the secure-store extra (pip install antaris-agent[secure-store]). "
            "Neither is available."
        )

    from cryptography.hazmat.primitives.kdf.scrypt import Scrypt
    from cryptography.hazmat.backends import default_backend

    passphrase = getpass.getpass("Antaris Agent memory passphrase: ").encode("utf-8")
    salt = os.urandom(16)

    kdf = Scrypt(
        salt=salt,
        length=32,
        n=2**14,
        r=8,
        p=1,
        backend=default_backend(),
    )
    key = kdf.derive(passphrase)

    # Store ONLY the derived 32-byte key (base64url).
    # Salt is not persisted — this is a one-time interactive bootstrap path.
    validate_key(key)
    blob = base64.urlsafe_b64encode(key).decode()
    try:
        keyring.set_password(service, account, blob)
    except Exception as e:
        raise RuntimeError(
            "Derived encryption key could not be persisted to keyring. "
            "Set ANTARISBOT_MEMORY_KEY env var or fix keyring configuration."
        ) from e

    return key


def encrypt_json(data: dict, key: bytes) -> bytes:
    """Encrypt *data* as JSON using AES-256-GCM.

    Returns:
        ``nonce (12 bytes) + ciphertext+tag`` as a single byte string.
    """
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM

    validate_key(key)
    nonce = os.urandom(12)
    plaintext = json.dumps(data).encode("utf-8")
    ciphertext = AESGCM(key).encrypt(nonce, plaintext, None)
    return nonce + ciphertext


def decrypt_json(blob: bytes, key: bytes) -> dict:
    """Decrypt a blob produced by :func:`encrypt_json`.

    Returns:
        The original dict.
    """
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM

    validate_key(key)
    nonce, ciphertext = blob[:12], blob[12:]
    plaintext = AESGCM(key).decrypt(nonce, ciphertext, None)
    return json.loads(plaintext.decode("utf-8"))


def save_store(path: Path, data: dict, key: bytes) -> None:
    """Encrypt *data* and write to *path* (mode 0o600).

    Args:
        path: Destination file path (created or overwritten).
        data: JSON-serialisable dict to store.
        key: 32-byte AES key.
    """
    validate_key(key)
    encrypted = encrypt_json(data, key)
    path.write_bytes(encrypted)
    path.chmod(0o600)


def load_store(path: Path, key: bytes) -> dict:
    """Load and decrypt the store at *path*.

    Returns:
        Decrypted dict, or ``{}`` if the file does not exist.
    """
    validate_key(key)
    if not path.exists():
        return {}
    return decrypt_json(path.read_bytes(), key)
