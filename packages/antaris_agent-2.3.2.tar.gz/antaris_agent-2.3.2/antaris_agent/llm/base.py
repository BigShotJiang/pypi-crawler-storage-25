import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Optional, Union, List, Dict, Any

logger = logging.getLogger(__name__)


# ── Per-model max output tokens (OpenClaw parity) ─────────────────────────
# Per-model max output tokens — ordered most-specific first (first match wins).
# Sources: platform.claude.com, developers.openai.com, cloud.google.com (2026-03)
MODEL_MAX_TOKENS = {
    # Anthropic — Claude family
    "opus-4-6": 128000,
    "opus-4-5": 64000,
    "opus-4-1": 32000,

    "sonnet-4-6": 64000,
    "sonnet-4-5": 64000,
    "sonnet-4-20250514": 64000,
    "haiku-4-5": 64000,
    "haiku-3-5": 8192,
    "haiku": 8192,           # conservative fallback for unversioned haiku
    # OpenAI — GPT family
    "gpt-5.4": 128000,
    "gpt-5.2": 128000,
    "gpt-4o": 16384,
    # Google — Gemini family
    "gemini-3": 65536,
    "gemini-2.5": 65536,
    "gemini": 65536,
}


def get_model_max_tokens(model: str, default: int = 16384) -> int:
    """Return max output tokens for a known model, or *default*.

    The lookup is substring-based against ``MODEL_MAX_TOKENS`` (ordered
    most-specific first).  Unknown models fall back to *default* and a
    debug-level log is emitted so operators can spot uncovered model strings.
    """
    model_lower = model.lower() if model else ""
    for pattern, tokens in MODEL_MAX_TOKENS.items():
        if pattern in model_lower:
            return tokens
    if model:
        logger.debug("get_model_max_tokens: no match for %r, using default %d", model, default)
    return default


@dataclass
class Message:
    role: str  # "user" | "assistant" | "system"
    content: Union[str, List[Dict[str, Any]]]  # Support both text and structured content


@dataclass
class LLMResponse:
    content: str
    model: str
    input_tokens: int
    output_tokens: int
    cost_usd: float
    tool_use: Optional[list[dict]] = None  # List of tool use blocks from LLM
    thinking_content: Optional[str] = None  # Extended thinking output (if enabled)


@dataclass
class ThinkingConfig:
    """Configuration for extended thinking / reasoning mode.
    
    Propagated from ModelController through the pipeline into provider calls.
    Each provider maps this to its own API format:
      - Anthropic: thinking.type="enabled", thinking.budget_tokens
      - OpenAI: reasoning.effort (o-series models)
      - Google: thinkingConfig.thinkingBudget
    """
    enabled: bool = False
    budget_tokens: int = 0
    level: str = "off"  # off | low | medium | high | max

    @classmethod
    def from_level(cls, level: str, budget: int = 0) -> 'ThinkingConfig':
        """Create from a thinking level string."""
        if level == "off" or not level:
            return cls(enabled=False, budget_tokens=0, level="off")
        return cls(enabled=True, budget_tokens=budget, level=level)


class LLMProvider(ABC):
    def __init__(self, api_key: str, model: str):
        self.api_key = api_key
        self.model = model

    @abstractmethod
    async def complete(
        self,
        messages: list[Message],
        system: str,
        model: Optional[str] = None,
        max_tokens: int = 16384,
        temperature: Optional[float] = None,
        tools: Optional[list[dict]] = None,
        thinking: Optional[ThinkingConfig] = None,
    ) -> LLMResponse:
        """Send messages, return response.
        
        Args:
            thinking: Optional thinking/reasoning configuration.
                      When enabled, the provider should use extended thinking
                      according to its API capabilities.
        """
        pass

    @abstractmethod
    def estimate_tokens(self, text: str) -> int:
        """Rough token estimate (chars / 4)."""
        pass
