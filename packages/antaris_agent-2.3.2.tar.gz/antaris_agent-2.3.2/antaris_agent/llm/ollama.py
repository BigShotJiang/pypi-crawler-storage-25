"""Ollama provider — fully local, zero cost, OpenAI-compatible API."""

import re
import httpx
from typing import Optional
from .base import LLMProvider, Message, LLMResponse, ThinkingConfig

# Qwen3 thinking mode outputs <think>...</think> blocks in response content.
# These are internal reasoning and should NEVER be sent to the user.
_THINK_BLOCK_RE = re.compile(r"<think>.*?</think>", re.DOTALL)

DEFAULT_BASE_URL = "http://localhost:11434/v1"


class OllamaProvider(LLMProvider):
    """Local Ollama provider — OpenAI-compatible endpoint, zero API cost.

    Works with any model installed via `ollama pull <model>`.
    Recommended models for Antaris Agent:
      - qwen3.5:0.8b  (ultra-lightweight, edge devices, ~600MB)
      - qwen3.5:2b    (fast, good quality, ~1.5GB)
      - qwen3.5:4b    (best balance, ~2.5GB) ← default
      - qwen3.5:9b    (near-Sonnet quality, ~5.5GB)
      - qwen3:8b      (already installed on Mac Mini M4)
    """

    def __init__(
        self,
        api_key: str = "ollama",        # ignored by ollama — kept for interface compat
        model: str = "qwen3.5:4b",
        base_url: str = DEFAULT_BASE_URL,
    ):
        super().__init__(api_key=api_key, model=model)
        self.base_url = base_url.rstrip("/")
        # Longer timeout — local inference can be slow on first run (model load)
        self._client = httpx.AsyncClient(timeout=120.0)

    async def close(self) -> None:
        """Close the underlying httpx client."""
        await self._client.aclose()

    async def complete(
        self,
        messages: list[Message],
        system: str,
        model: Optional[str] = None,
        max_tokens: int = 16384,
        temperature: Optional[float] = None,
        thinking: Optional[ThinkingConfig] = None,
        tools=None,
    ) -> LLMResponse:
        use_model = model or self.model

        # Qwen3 supports thinking mode toggle via "think" payload option.
        # Default: thinking=False for agent use (faster, more predictable).
        # Set thinking=True to enable chain-of-thought for complex tasks.
        system_content = system or ""

        ollama_messages = []
        if system_content:
            ollama_messages.append({"role": "system", "content": system_content})
        ollama_messages.extend(
            {"role": m.role, "content": m.content}
            for m in messages
            if m.role != "system"
        )

        payload = {
            "model": use_model,
            "messages": ollama_messages,
            "max_tokens": max_tokens,
            "stream": False,
        }
        # Only include temperature if explicitly set; otherwise let model use its default
        if temperature is not None:
            payload["temperature"] = temperature
        # Qwen3 thinking mode toggle (ollama ≥0.7.0 supports "think" in payload)
        # Accept ThinkingConfig or legacy bool
        _enable_thinking = False
        if isinstance(thinking, ThinkingConfig):
            _enable_thinking = thinking.enabled
        elif isinstance(thinking, bool):
            _enable_thinking = thinking
        if "qwen3" in use_model.lower():
            payload["think"] = _enable_thinking

        # Bearer token not required by ollama but included for compat
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

        client = self._client
        try:
            response = await client.post(
                f"{self.base_url}/chat/completions",
                json=payload,
                headers=headers,
            )

            if response.status_code == 404:
                raise ValueError(
                    f"Model '{use_model}' not found locally. "
                    f"Run: ollama pull {use_model}"
                )
            if response.status_code == 500:
                body = response.text
                raise RuntimeError(f"Ollama error: {body[:200]}")

            response.raise_for_status()
            data = response.json()

            msg = data["choices"][0]["message"]
            content = msg.get("content") or ""

            # Strip Qwen3 <think>...</think> blocks — internal reasoning
            # should NEVER be sent to the user as a message.
            if "<think>" in content:
                content = _THINK_BLOCK_RE.sub("", content).strip()

            # If content is empty but reasoning exists, model used all tokens
            # on thinking — surface a useful error rather than empty string
            if not content.strip() and msg.get("reasoning"):
                raise RuntimeError(
                    f"Model '{use_model}' used all {max_tokens} tokens on reasoning "
                    f"with nothing left for the response. "
                    f"Increase max_tokens or use thinking=False."
                )
            usage = data.get("usage", {})
            input_tokens = usage.get("prompt_tokens", 0)
            output_tokens = usage.get("completion_tokens", 0)

            # Local inference — always $0
            return LLMResponse(
                content=content,
                model=use_model,
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                cost_usd=0.0,
            )

        except (ValueError, RuntimeError):
            raise
        except httpx.ConnectError:
            raise RuntimeError(
                "Cannot connect to Ollama. Is it running? Start with: ollama serve"
            )
        except httpx.TimeoutException:
            raise RuntimeError(
                f"Ollama inference timed out (120s). "
                f"Try a smaller model: ollama pull qwen3.5:2b"
            )
        except httpx.HTTPStatusError as e:
            raise RuntimeError(
                f"Ollama API error {e.response.status_code}: {e.response.text}"
            )

    def estimate_tokens(self, text: str) -> int:
        return max(1, len(text) // 4)

    @staticmethod
    async def list_models(base_url: str = DEFAULT_BASE_URL) -> list[str]:
        """Return list of locally installed model names."""
        async with httpx.AsyncClient(timeout=5.0) as client:
            try:
                r = await client.get(f"{base_url.rstrip('/')}/models")
                r.raise_for_status()
                data = r.json()
                return [m["id"] for m in data.get("data", [])]
            except Exception:
                return []
