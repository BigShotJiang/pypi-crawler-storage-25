"""
antaris_agent/persona/user_tracker.py

Detects user facts in messages and updates USER.md silently.
The persona loader already reads USER.md into the system prompt,
so learned facts automatically become part of context.
"""

from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

_SECTION_HEADER = "## Learned Facts"

# Words that should never be stored as user facts — common filler/function words
# that the "I'm X" pattern would otherwise capture as names/descriptors.
_FACT_STOPWORDS = frozenset({
    "not", "just", "also", "already", "able", "being", "the", "a", "an",
    "so", "very", "really", "pretty", "quite", "gonna", "going", "trying",
    "working", "looking", "feeling", "sending", "setting", "curious",
    "interested", "hoping", "good", "okay", "fine", "sure", "here", "there",
    "back", "still", "now", "then", "up", "down", "in", "out", "on", "off",
    "it", "this", "that", "these", "those", "some", "any", "all", "no",
    "well", "actually", "basically", "literally", "honestly", "totally",
    "currently", "thinking", "wondering", "assuming", "guessing", "planning",
    "happy", "sad", "excited", "tired", "busy", "stuck", "lost", "ready",
    "done", "finished", "starting", "running", "using", "getting", "having",
    "making", "taking", "seeing", "saying", "asking", "telling", "showing",
    "coming", "going", "leaving", "staying", "waiting", "wanting", "needing",
})


class UserTracker:
    """Detects user facts in messages and updates USER.md."""

    FACT_PATTERNS: list[tuple[str, str]] = [
        (r"my name is (\w+)", "Name: {0}"),
        (r"(?:call me|you can call me|also call me) (\w+)", "Also known as: {0}"),
        (r"(?:call me|you can call me) (\w+).*?(?:but also|or|also) (\w+)", "Preferred name: {0} (also {1})"),
        # NOTE: "i'm X" only — handled with stopword filtering in extract_facts
        (r"i(?:'m| am) a[n]? (.+?)(?:\.|,|$)", "Occupation/role: {0}"),
        (r"i work (?:at|for) (.+?)(?:\.|,|$)", "Works at/for: {0}"),
        (r"i live in (.+?)(?:\.|,|$)", "Lives in: {0}"),
        (r"i(?:'m| am) (\d+) years? old", "Age: {0}"),
        (r"my (?!name\b)(.+?) is (.+?)(?:\.|,|$)", "My {0}: {1}"),
        (r"i (?:like|love) (.+?)(?:\.|,|$)", "Likes/loves: {0}"),
        (r"i hate (.+?)(?:\.|,|$)", "Dislikes: {0}"),
        (r"i prefer (.+?)(?:\.|,|$)", "Prefers: {0}"),
        (r"i use (.+?)(?:\.|,|$)", "Uses: {0}"),
    ]

    _compiled: Optional[list[tuple[re.Pattern, str]]] = None

    def __init__(self, config_dir: str):
        self.user_md_path = Path(config_dir) / "USER.md"

    @classmethod
    def _get_compiled(cls) -> list[tuple[re.Pattern, str]]:
        if cls._compiled is None:
            cls._compiled = [
                (re.compile(p, re.IGNORECASE | re.MULTILINE), tmpl)
                for p, tmpl in cls.FACT_PATTERNS
            ]
        return cls._compiled

    @staticmethod
    def _format_fact(template: str, groups: tuple) -> str:
        try:
            clean_groups = [g.strip() if g else "" for g in groups]
            return template.format(*clean_groups)
        except (IndexError, KeyError):
            return ""

    def _read_existing(self) -> str:
        if self.user_md_path.exists():
            return self.user_md_path.read_text(encoding="utf-8")
        return ""

    @staticmethod
    def _is_meaningful_fact(fact: str) -> bool:
        """Return False for facts that are clearly noise — stopwords, too short, numeric-only."""
        if not fact or len(fact) < 5:
            return False
        # Extract the value portion (everything after the first ": ")
        parts = fact.split(": ", 1)
        value = parts[1].strip() if len(parts) > 1 else fact
        # Reject single-word values that are stopwords
        words = value.lower().split()
        if len(words) == 1 and words[0] in _FACT_STOPWORDS:
            return False
        # Reject values that are purely numeric or single characters
        if re.fullmatch(r"[\d\s\W]+", value):
            return False
        # Reject very short values (less than 3 meaningful characters)
        if len(value.strip()) < 3:
            return False
        return True

    def extract_facts(self, message: str) -> list[str]:
        """Return list of fact strings detected in message."""
        facts: list[str] = []
        for pattern, template in self._get_compiled():
            for match in pattern.finditer(message):
                groups = match.groups()
                fact = self._format_fact(template, groups)
                fact = fact.strip().rstrip(".,;")
                if self._is_meaningful_fact(fact):
                    facts.append(fact)
        return facts

    def update_user_md(self, facts: list[str]) -> bool:
        """
        Append new facts to USER.md under '## Learned Facts'.

        Each fact includes a timestamp for provenance.
        Deduplicates by fact content (ignores timestamp when checking).
        Creates file if needed. Returns True if file was updated.
        """
        if not facts:
            return False

        from datetime import datetime, timezone
        now = datetime.now(timezone.utc).strftime("%Y-%m-%d")

        existing_content = self._read_existing()
        # Deduplicate by fact text (strip existing timestamps for comparison)
        new_facts = [f for f in facts if f not in existing_content]

        if not new_facts:
            return False

        self.user_md_path.parent.mkdir(parents=True, exist_ok=True)
        section_idx = existing_content.find(_SECTION_HEADER)

        # Format with timestamps
        fact_lines = [f"- {f} *(learned {now})*" for f in new_facts]

        if section_idx == -1:
            lines_to_add = f"\n\n{_SECTION_HEADER}\n" + "\n".join(fact_lines) + "\n"
            with open(self.user_md_path, "a", encoding="utf-8") as fh:
                fh.write(lines_to_add)
        else:
            after_section = existing_content[section_idx + len(_SECTION_HEADER):]
            next_heading = re.search(r"\n##\s", after_section)
            if next_heading:
                insert_pos = section_idx + len(_SECTION_HEADER) + next_heading.start()
                insert_text = "\n" + "\n".join(fact_lines)
                new_content = (
                    existing_content[:insert_pos]
                    + insert_text
                    + existing_content[insert_pos:]
                )
            else:
                insert_text = "\n" + "\n".join(fact_lines) + "\n"
                new_content = existing_content.rstrip() + insert_text
            self.user_md_path.write_text(new_content, encoding="utf-8")

        logger.debug("UserTracker: wrote %d fact(s) to %s", len(new_facts), self.user_md_path)
        return True

    def process_message(
        self,
        message: str,
        user_id: Optional[str | int] = None,
        owner_id: Optional[str | int] = None,
    ) -> list[str]:
        """
        Extract facts and update USER.md. Returns only NEWLY LEARNED facts.

        This distinction matters for downstream consumers:
        - extract_facts() returns all detected facts (raw detection)
        - process_message() returns only facts that were actually new (deduped)
        """
        facts = self.extract_facts(message)
        if not facts:
            return []

        # Determine which facts are actually new BEFORE writing
        existing_content = self._read_existing()
        new_facts = [f for f in facts if f not in existing_content]

        if not new_facts:
            return []

        owner_id_str = str(owner_id) if owner_id else None
        user_id_str = str(user_id) if user_id else None

        if not owner_id:
            logger.debug(
                "UserTracker: owner_id missing/falsy; updating USER.md for backwards compatibility"
            )
            self.update_user_md(new_facts)
        elif user_id is not None and user_id_str == owner_id_str:
            logger.debug(
                "UserTracker: user_id=%s matches owner_id=%s; updating USER.md",
                user_id_str,
                owner_id_str,
            )
            self.update_user_md(new_facts)
        else:
            logger.info(
                "UserTracker: extracted %d new fact(s) for non-owner user_id=%s owner_id=%s; skipping USER.md write",
                len(new_facts),
                user_id_str,
                owner_id_str,
            )

        return new_facts
