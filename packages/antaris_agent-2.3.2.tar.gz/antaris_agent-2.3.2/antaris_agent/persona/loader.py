import logging
from pathlib import Path
from typing import Optional

DEFAULT_CONFIG_DIR = Path.home() / ".antaris"

DEFAULT_SOUL = """You are Antaris — a personal AI assistant built to remember, protect, and adapt.

You have persistent memory. You remember past conversations.
You have safety built in. You can't be easily manipulated.
You improve over time. The more we talk, the better you get.

Be helpful, be direct, and have genuine personality. Skip the filler phrases.
You're not a customer service bot. You're a capable partner.

Audience framing rule: when the user mentions a third party (for example, “tell X...” or “let X know...”), stay addressed to the current user by default. Only switch into a direct message written to that third party if the user explicitly asks you to draft, compose, or write the message itself."""

DEFAULT_USER = """# About You

I'm learning about you. Tell me about yourself and I'll remember."""

logger = logging.getLogger(__name__)


class PersonaLoader:
    def __init__(self, config_dir: Optional[str] = None):
        self.config_dir = Path(config_dir or DEFAULT_CONFIG_DIR)
        self.soul_path = self.config_dir / "SOUL.md"
        self.user_path = self.config_dir / "USER.md"

        # Context cadence system — controls which .md files inject and when
        from antaris_agent.persona.context_cadence import ContextCadence
        self.cadence = ContextCadence(self.config_dir)

    def load_soul(self) -> str:
        """Load SOUL.md or return default."""
        if self.soul_path.exists():
            return self.soul_path.read_text().strip()
        return DEFAULT_SOUL

    def load_context_files(self) -> list[tuple[str, str]]:
        """Load all .md files from config dir that act as system context.

        Returns list of (filename, content) tuples in priority order:
          SOUL.md first, then RULES.md, TOOLS.md, TEAM.md,
          then any other .md files alphabetically.
          USER.md is excluded (handled separately with its own logic).
        """
        if not self.config_dir.exists():
            return []

        # Priority order for known files
        priority = ["SOUL.md", "RULES.md", "TOOLS.md", "TEAM.md"]
        skip = {"USER.md"}  # handled separately

        result: list[tuple[str, str]] = []
        seen: set[str] = set()

        # Load priority files first
        for name in priority:
            path = self.config_dir / name
            if path.exists():
                content = path.read_text().strip()
                if content:
                    result.append((name, content))
                    seen.add(name)

        # Load any additional .md files alphabetically
        for path in sorted(self.config_dir.glob("*.md")):
            name = path.name
            if name in seen or name in skip:
                continue
            content = path.read_text().strip()
            if content:
                result.append((name, content))

        return result

    def load_user(self) -> Optional[str]:
        """Load USER.md if it exists and has content."""
        if not self.user_path.exists():
            return None
        content = self.user_path.read_text().strip()
        # Don't inject placeholder/empty USER.md
        if content == DEFAULT_USER.strip() or len(content) < 50:
            return None
        return content

    def build_system_prompt(
        self,
        memories: Optional[list] = None,
        user_id: Optional[str | int] = None,
        owner_id: Optional[str | int] = None,
    ) -> str:
        """
        Build full system prompt from all context files + memories.
        Order: SOUL.md → RULES.md → TOOLS.md → TEAM.md → other .md → USER.md → memories
        USER.md injection is owner-scoped when owner_id is configured.
        """
        # Load files based on cadence (SOUL.md is always "every" by default)
        cadence_files = self.cadence.get_files_for_turn()
        if cadence_files:
            parts = []
            for name, content in cadence_files:
                section = name.replace(".md", "")
                parts.append(f"## {section}\n{content}")
        else:
            # Fallback if no cadence config or no files match
            parts = [self.load_soul()]

        user_context = self.load_user()
        owner_id_str = str(owner_id) if owner_id else None
        user_id_str = str(user_id) if user_id else None

        if user_context:
            if not owner_id:
                logger.debug(
                    "PersonaLoader: owner_id missing/falsy; injecting USER.md for backwards compatibility"
                )
                parts.append(f"\n---\n## About the person I'm talking to:\n{user_context}")
            elif user_id is not None and user_id_str == owner_id_str:
                logger.debug(
                    "PersonaLoader: injecting USER.md for owner user_id=%s",
                    user_id_str,
                )
                parts.append(f"\n---\n## About the person I'm talking to:\n{user_context}")
            else:
                logger.info(
                    "PersonaLoader: withholding USER.md for non-owner user_id=%s owner_id=%s",
                    user_id_str,
                    owner_id_str,
                )
                parts.append(
                    "\n---\n## Identity boundary\n"
                    "Do not assume the current speaker is the owner described in USER.md. "
                    "Treat this conversation as belonging to the current user only, and avoid using owner-specific personal details unless the current user independently provides them."
                )

        parts.append(
            "\n---\n## Response framing\n"
            "Address the current speaker, not a third party mentioned in their request. "
            "If the user says things like 'tell X', 'let X know', or refers to what someone else should hear, "
            "respond to the user unless they explicitly ask you to draft/compose/write a direct message to that third party."
        )

        if memories and len(memories) > 0:
            memory_text = "\n".join(f"- {m}" for m in memories[:15])
            parts.append(f"\n---\n## Relevant memories from past conversations:\n{memory_text}")

        return "\n".join(parts)

    def update_user_context(self, new_info: str):
        """Append new user information to USER.md."""
        self.user_path.parent.mkdir(parents=True, exist_ok=True)
        current = self.user_path.read_text() if self.user_path.exists() else ""
        if new_info not in current:
            with open(self.user_path, "a") as f:
                f.write(f"\n{new_info}\n")

    def reload(self):
        """Force re-read persona files on next call (for hot-reload)."""
        # Files are read on each call already — hot reload is free
        pass
