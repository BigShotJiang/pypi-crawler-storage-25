"""
Extension Security Policy — governs what extensions can do.

Implements a capability-based security model:
  - Extensions declare what they need (capabilities)
  - The security policy decides what's allowed based on security_mode
  - Default behaviors are safe — extensions must opt-in to dangerous capabilities
  - Third-party extensions require allowlisting before they can load

Extension Sources:
  - builtin:     Ships with antaris-agent (always trusted)
  - config:      Declared in config.json (trusted by default)
  - filesystem:  Discovered from extensions/ directory (requires allowlist unless open mode)
  - pip:         Installed via pip (requires allowlist unless open mode)

High-Risk Capabilities (always require opt-in regardless of security mode):
  - shell.exec        Execute shell commands
  - desktop           Desktop control (mouse/keyboard)
  - browser           Browser automation
  - webhooks          Outbound HTTP webhook calls

Security Modes → Default Extension Policies:
  - open:      All capabilities allowed, no restrictions, no allowlist needed
  - standard:  Network, file read allowed. Shell/desktop/browser/webhooks require approval.
  - sandboxed: File read within workspace. No shell. Network allowlisted.
  - secured:   All tool calls logged. Destructive ops need approval.
  - encrypted: All tool calls need approval. Strict isolation.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional, Set

logger = logging.getLogger(__name__)


# ── Enums ─────────────────────────────────────────────────────────────────

class ExtensionCapability(Enum):
    """Capabilities an extension can request."""
    NETWORK_READ = "network.read"          # Fetch URLs, API calls
    NETWORK_WRITE = "network.write"        # Send data externally (webhooks, API posts)
    FILE_READ = "file.read"                # Read files from workspace
    FILE_WRITE = "file.write"              # Write files
    SHELL_EXEC = "shell.exec"              # Execute shell commands
    BROWSER = "browser"                    # Browser automation
    DESKTOP = "desktop"                    # Desktop control (mouse/keyboard)
    WEBHOOKS = "webhooks"                  # Register/fire outbound webhooks
    MEMORY_READ = "memory.read"            # Read agent memory
    MEMORY_WRITE = "memory.write"          # Write to agent memory
    LLM_CALL = "llm.call"                 # Make LLM API calls (costs money)
    SYSTEM_INFO = "system.info"            # Read system info (OS, processes)
    CRON = "cron"                          # Schedule periodic tasks


class ExtensionSource(Enum):
    """Where an extension was loaded from — determines trust level."""
    BUILTIN = "builtin"          # Ships with antaris-agent package
    CONFIG = "config"            # Declared explicitly in config.json
    FILESYSTEM = "filesystem"    # Discovered from extensions/ directory
    PIP = "pip"                  # Installed via pip (entry points)


# High-risk capabilities that always require separate opt-in / approval,
# even in standard mode. These are the capabilities Antaris explicitly
# identified as needing gating.
HIGH_RISK_CAPABILITIES: frozenset[ExtensionCapability] = frozenset({
    ExtensionCapability.SHELL_EXEC,
    ExtensionCapability.DESKTOP,
    ExtensionCapability.BROWSER,
    ExtensionCapability.WEBHOOKS,
})


# ── Data Classes ──────────────────────────────────────────────────────────

@dataclass
class ExtensionPolicy:
    """Security policy for a specific extension."""
    extension_name: str
    source: ExtensionSource = ExtensionSource.FILESYSTEM
    allowed_capabilities: Set[ExtensionCapability] = field(default_factory=set)
    denied_capabilities: Set[ExtensionCapability] = field(default_factory=set)
    requires_approval: Set[ExtensionCapability] = field(default_factory=set)
    max_api_calls_per_hour: int = 100
    allowed_domains: List[str] = field(default_factory=list)
    sandbox_path: str = ""  # If set, file ops restricted to this path
    is_allowlisted: bool = False  # Explicitly approved by user


@dataclass
class AllowlistEntry:
    """A user-approved extension in the allowlist."""
    name: str
    approved_at: str = ""          # ISO timestamp
    approved_by: str = ""          # "user", "admin", "config"
    granted_capabilities: List[str] = field(default_factory=list)  # Extra caps beyond mode default
    notes: str = ""


# ── Mode Defaults ─────────────────────────────────────────────────────────

# Default capability sets per security mode.
# NOTE: HIGH_RISK_CAPABILITIES are always in requires_approval (or denied)
# for standard+ modes, even for builtin extensions.
_MODE_DEFAULTS: Dict[str, Dict[str, Set[ExtensionCapability]]] = {
    "open": {
        "allowed": set(ExtensionCapability),
        "denied": set(),
        "requires_approval": set(),
    },
    "standard": {
        "allowed": {
            ExtensionCapability.NETWORK_READ,
            ExtensionCapability.FILE_READ,
            ExtensionCapability.MEMORY_READ,
            ExtensionCapability.MEMORY_WRITE,
            ExtensionCapability.LLM_CALL,
            ExtensionCapability.SYSTEM_INFO,
            ExtensionCapability.CRON,
        },
        "denied": set(),
        "requires_approval": {
            ExtensionCapability.FILE_WRITE,
            ExtensionCapability.SHELL_EXEC,
            ExtensionCapability.NETWORK_WRITE,
            ExtensionCapability.BROWSER,
            ExtensionCapability.DESKTOP,
            ExtensionCapability.WEBHOOKS,
        },
    },
    "sandboxed": {
        "allowed": {
            ExtensionCapability.FILE_READ,
            ExtensionCapability.MEMORY_READ,
            ExtensionCapability.MEMORY_WRITE,
            ExtensionCapability.LLM_CALL,
            ExtensionCapability.SYSTEM_INFO,
        },
        "denied": {
            ExtensionCapability.SHELL_EXEC,
            ExtensionCapability.DESKTOP,
        },
        "requires_approval": {
            ExtensionCapability.NETWORK_READ,
            ExtensionCapability.NETWORK_WRITE,
            ExtensionCapability.FILE_WRITE,
            ExtensionCapability.BROWSER,
            ExtensionCapability.WEBHOOKS,
            ExtensionCapability.CRON,
        },
    },
    "secured": {
        "allowed": {
            ExtensionCapability.MEMORY_READ,
            ExtensionCapability.SYSTEM_INFO,
        },
        "denied": {
            ExtensionCapability.SHELL_EXEC,
            ExtensionCapability.DESKTOP,
            ExtensionCapability.WEBHOOKS,
        },
        "requires_approval": {
            ExtensionCapability.NETWORK_READ,
            ExtensionCapability.NETWORK_WRITE,
            ExtensionCapability.FILE_READ,
            ExtensionCapability.FILE_WRITE,
            ExtensionCapability.BROWSER,
            ExtensionCapability.MEMORY_WRITE,
            ExtensionCapability.LLM_CALL,
            ExtensionCapability.CRON,
        },
    },
    "encrypted": {
        "allowed": set(),
        "denied": {
            ExtensionCapability.SHELL_EXEC,
            ExtensionCapability.DESKTOP,
            ExtensionCapability.NETWORK_WRITE,
            ExtensionCapability.WEBHOOKS,
        },
        "requires_approval": set(ExtensionCapability),  # Everything needs approval
    },
}

# Names of extensions that ship with antaris-agent and are always trusted.
BUILTIN_EXTENSION_NAMES: frozenset[str] = frozenset({
    "example",
    "auth-monitor",
    "model-control",
    "desktop-control",
})


# ── Allowlist Manager ─────────────────────────────────────────────────────

class ExtensionAllowlist:
    """Manages the persistent allowlist for third-party extensions.
    
    The allowlist is stored as a JSON file in the config directory.
    Extensions not on the allowlist are blocked from loading in
    standard, sandboxed, secured, and encrypted modes.
    
    In open mode, the allowlist is not enforced (all extensions load).
    
    Usage:
        allowlist = ExtensionAllowlist(config_dir="/path/to/.antaris")
        allowlist.approve("my-extension", approved_by="user")
        
        if allowlist.is_approved("my-extension"):
            # OK to load
            ...
    """

    def __init__(self, config_dir: str = ""):
        self._config_dir = Path(config_dir) if config_dir else Path(".")
        self._file_path = self._config_dir / "extension_allowlist.json"
        self._entries: Dict[str, AllowlistEntry] = {}
        self._load()

    def is_approved(self, name: str) -> bool:
        """Check if an extension is on the allowlist."""
        return name in self._entries

    def approve(
        self,
        name: str,
        approved_by: str = "user",
        granted_capabilities: Optional[List[str]] = None,
        notes: str = "",
    ) -> None:
        """Add an extension to the allowlist."""
        from datetime import datetime, timezone
        self._entries[name] = AllowlistEntry(
            name=name,
            approved_at=datetime.now(tz=timezone.utc).isoformat(),
            approved_by=approved_by,
            granted_capabilities=granted_capabilities or [],
            notes=notes,
        )
        self._save()
        logger.info("Extension '%s' approved by %s", name, approved_by)

    def revoke(self, name: str) -> bool:
        """Remove an extension from the allowlist."""
        if name in self._entries:
            del self._entries[name]
            self._save()
            logger.info("Extension '%s' revoked from allowlist", name)
            return True
        return False

    def get_entry(self, name: str) -> Optional[AllowlistEntry]:
        """Get the allowlist entry for an extension."""
        return self._entries.get(name)

    def list_entries(self) -> List[AllowlistEntry]:
        """List all allowlist entries."""
        return list(self._entries.values())

    def _load(self) -> None:
        """Load allowlist from disk."""
        if not self._file_path.exists():
            return
        try:
            with open(self._file_path) as f:
                data = json.load(f)
            for name, entry_data in data.get("extensions", {}).items():
                self._entries[name] = AllowlistEntry(
                    name=name,
                    approved_at=entry_data.get("approved_at", ""),
                    approved_by=entry_data.get("approved_by", ""),
                    granted_capabilities=entry_data.get("granted_capabilities", []),
                    notes=entry_data.get("notes", ""),
                )
        except Exception as e:
            logger.warning("Failed to load extension allowlist: %s", e)

    def _save(self) -> None:
        """Save allowlist to disk."""
        try:
            self._file_path.parent.mkdir(parents=True, exist_ok=True)
            data = {"extensions": {}}
            for name, entry in self._entries.items():
                data["extensions"][name] = {
                    "approved_at": entry.approved_at,
                    "approved_by": entry.approved_by,
                    "granted_capabilities": entry.granted_capabilities,
                    "notes": entry.notes,
                }
            with open(self._file_path, 'w') as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            logger.warning("Failed to save extension allowlist: %s", e)


# ── Security Manager ─────────────────────────────────────────────────────

class ExtensionSecurityManager:
    """Manages security policies for extensions.
    
    Enforces:
      1. Capability-based access control per extension
      2. Source-based trust (builtin > config > filesystem/pip)
      3. Allowlist enforcement for third-party extensions
      4. High-risk capability gating regardless of source
    
    Usage:
        security = ExtensionSecurityManager(security_mode="standard")
        
        # Check if an extension is allowed to load
        if security.can_load("my-ext", ExtensionSource.FILESYSTEM):
            ...
        
        # Check if a capability is allowed
        if security.is_allowed("my-ext", ExtensionCapability.BROWSER):
            ...
    """

    def __init__(self, security_mode: str = "standard", config_dir: str = ""):
        self.security_mode = security_mode
        self._policies: Dict[str, ExtensionPolicy] = {}
        self._mode_config = _MODE_DEFAULTS.get(security_mode, _MODE_DEFAULTS["standard"])
        self._allowlist = ExtensionAllowlist(config_dir=config_dir)

    @property
    def allowlist(self) -> ExtensionAllowlist:
        """Access the extension allowlist."""
        return self._allowlist

    def classify_source(self, extension_name: str, load_path: str = "") -> ExtensionSource:
        """Classify the trust source of an extension.
        
        Args:
            extension_name: The extension's declared name
            load_path: The filesystem path the extension was loaded from
        
        Returns:
            ExtensionSource indicating the trust level
        """
        # Builtin extensions are always trusted
        if extension_name in BUILTIN_EXTENSION_NAMES:
            return ExtensionSource.BUILTIN
        
        # Check if it's from the antaris_agent package itself
        if load_path:
            load_path_str = str(load_path)
            if "antaris_agent/extensions/builtin" in load_path_str:
                return ExtensionSource.BUILTIN
            if "antaris_agent/extensions/" in load_path_str and "/builtin/" not in load_path_str:
                # Core extension module (e.g., desktop_control.py, auth_monitor.py)
                # These ship with the package → builtin
                if any(
                    mod in load_path_str
                    for mod in ("desktop_control", "auth_monitor", "model_control", "skills")
                ):
                    return ExtensionSource.BUILTIN
        
        # If we reached here, it's a filesystem-discovered or pip extension
        return ExtensionSource.FILESYSTEM

    def can_load(self, extension_name: str, source: ExtensionSource) -> bool:
        """Check if an extension is allowed to load based on source trust.
        
        In open mode: everything loads.
        Builtin and config sources: always allowed.
        Filesystem/pip sources: require allowlist in standard+ modes.
        
        Returns:
            True if the extension is allowed to load.
        """
        # Open mode: no restrictions
        if self.security_mode == "open":
            return True
        
        # Builtin and config-declared extensions are always trusted
        if source in (ExtensionSource.BUILTIN, ExtensionSource.CONFIG):
            return True
        
        # Third-party extensions require allowlist approval
        return self._allowlist.is_approved(extension_name)

    def get_load_denial_reason(self, extension_name: str, source: ExtensionSource) -> str:
        """Get a human-readable reason why an extension cannot load.
        
        Returns empty string if the extension CAN load.
        """
        if self.can_load(extension_name, source):
            return ""
        
        return (
            f"Extension '{extension_name}' is not on the allowlist. "
            f"Third-party extensions require approval in {self.security_mode} mode. "
            f"Add it with: !extension approve {extension_name}"
        )

    def get_policy(self, extension_name: str, source: Optional[ExtensionSource] = None) -> ExtensionPolicy:
        """Get or create the policy for an extension.
        
        Args:
            extension_name: Extension identifier
            source: Where the extension came from (affects default trust)
        """
        if extension_name not in self._policies:
            _source = source or self.classify_source(extension_name)
            policy = ExtensionPolicy(
                extension_name=extension_name,
                source=_source,
                allowed_capabilities=set(self._mode_config["allowed"]),
                denied_capabilities=set(self._mode_config["denied"]),
                requires_approval=set(self._mode_config["requires_approval"]),
                is_allowlisted=self._allowlist.is_approved(extension_name),
            )
            
            # Apply any granted capabilities from the allowlist
            entry = self._allowlist.get_entry(extension_name)
            if entry and entry.granted_capabilities:
                for cap_str in entry.granted_capabilities:
                    try:
                        cap = ExtensionCapability(cap_str)
                        policy.allowed_capabilities.add(cap)
                        policy.requires_approval.discard(cap)
                        policy.denied_capabilities.discard(cap)
                    except ValueError:
                        logger.warning(
                            "Unknown capability '%s' in allowlist for '%s'",
                            cap_str, extension_name
                        )
            
            self._policies[extension_name] = policy
        return self._policies[extension_name]

    def is_allowed(self, extension_name: str, capability: ExtensionCapability) -> bool:
        """Check if a capability is allowed for an extension.
        
        Returns True if explicitly allowed, False if denied or requires approval.
        """
        policy = self.get_policy(extension_name)
        
        if capability in policy.denied_capabilities:
            return False
        
        if capability in policy.requires_approval:
            return False  # Caller should use needs_approval() and get approval first
        
        return capability in policy.allowed_capabilities

    def needs_approval(self, extension_name: str, capability: ExtensionCapability) -> bool:
        """Check if a capability requires explicit approval."""
        policy = self.get_policy(extension_name)
        return capability in policy.requires_approval

    def is_denied(self, extension_name: str, capability: ExtensionCapability) -> bool:
        """Check if a capability is explicitly denied (cannot be approved)."""
        policy = self.get_policy(extension_name)
        return capability in policy.denied_capabilities

    def is_high_risk(self, capability: ExtensionCapability) -> bool:
        """Check if a capability is classified as high-risk."""
        return capability in HIGH_RISK_CAPABILITIES

    def grant_capability(self, extension_name: str, capability: ExtensionCapability) -> None:
        """Explicitly grant a capability to an extension (admin action)."""
        policy = self.get_policy(extension_name)
        policy.allowed_capabilities.add(capability)
        policy.requires_approval.discard(capability)
        policy.denied_capabilities.discard(capability)
        logger.info("Granted %s to extension '%s'", capability.value, extension_name)

    def deny_capability(self, extension_name: str, capability: ExtensionCapability) -> None:
        """Explicitly deny a capability for an extension."""
        policy = self.get_policy(extension_name)
        policy.denied_capabilities.add(capability)
        policy.allowed_capabilities.discard(capability)
        policy.requires_approval.discard(capability)
        logger.info("Denied %s for extension '%s'", capability.value, extension_name)

    def status_text(self) -> str:
        """Generate human-readable security status."""
        lines = [f"**🔒 Extension Security ({self.security_mode} mode):**"]
        
        if not self._policies:
            lines.append("No extension policies configured.")
            return "\n".join(lines)
        
        for name, policy in self._policies.items():
            allowed_count = len(policy.allowed_capabilities)
            denied_count = len(policy.denied_capabilities)
            approval_count = len(policy.requires_approval)
            source_icon = {
                ExtensionSource.BUILTIN: "🏠",
                ExtensionSource.CONFIG: "⚙️",
                ExtensionSource.FILESYSTEM: "📁",
                ExtensionSource.PIP: "📦",
            }.get(policy.source, "❓")
            trust = "✅" if policy.is_allowlisted or policy.source == ExtensionSource.BUILTIN else "⚠️"
            lines.append(
                f"  {source_icon}{trust} **{name}**: {allowed_count} allowed, "
                f"{approval_count} need approval, {denied_count} denied"
            )
        
        # Allowlist summary
        entries = self._allowlist.list_entries()
        if entries:
            lines.append(f"\n**📋 Allowlist:** {len(entries)} extension(s) approved")
        
        return "\n".join(lines)
