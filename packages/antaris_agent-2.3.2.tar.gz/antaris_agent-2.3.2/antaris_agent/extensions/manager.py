"""
Extension Manager — loads, manages, and coordinates extensions.

Handles:
  - Extension registration and lifecycle (load/unload/reload)
  - Dependency resolution between extensions
  - Event bus for inter-extension communication
  - Extension-registered command dispatch
  - Status reporting
"""

from __future__ import annotations

import logging
from collections import defaultdict
from typing import Any, Callable, Dict, List, Optional, TYPE_CHECKING

from .base import Extension, ExtensionContext, ExtensionState

if TYPE_CHECKING:
    from antaris_agent.core.bot import Bot

logger = logging.getLogger(__name__)


class ExtensionManager:
    """Central manager for all extensions.
    
    Usage:
        manager = ExtensionManager()
        manager.register(MyExtension())
        await manager.load_all(bot)
        
        # Hot-reload an extension
        await manager.reload("my-extension")
        
        # Dispatch extension commands
        result = manager.dispatch_command("weather", user_id, "London")
    """

    def __init__(self):
        self._extensions: Dict[str, Extension] = {}
        self._contexts: Dict[str, ExtensionContext] = {}
        self._states: Dict[str, ExtensionState] = {}
        self._extension_sources: Dict[str, Any] = {}  # name → ExtensionSource
        self._event_handlers: Dict[str, List[Callable]] = defaultdict(list)
        self._bot: Optional['Bot'] = None
        self._load_order: List[str] = []

    def register(self, extension: Extension, source: Any = None) -> None:
        """Register an extension for later loading.
        
        Args:
            extension: The extension instance.
            source: Optional ExtensionSource indicating provenance.
        
        Does not load the extension — call load_all() or load() for that.
        """
        if not extension.name:
            raise ValueError(f"Extension {type(extension).__name__} has no name")
        
        if extension.name in self._extensions:
            logger.warning("Extension '%s' already registered, replacing", extension.name)
        
        self._extensions[extension.name] = extension
        self._states[extension.name] = ExtensionState.REGISTERED
        if source is not None:
            self._extension_sources[extension.name] = source
        logger.info("Registered extension: %s v%s", extension.name, extension.version)

    async def load_all(self, bot: 'Bot') -> Dict[str, bool]:
        """Load all registered extensions in dependency order.
        
        Returns dict of {extension_name: success}.
        """
        self._bot = bot
        results = {}
        
        # Resolve load order based on dependencies
        order = self._resolve_load_order()
        
        for name in order:
            success = await self.load(name)
            results[name] = success
        
        loaded = sum(1 for v in results.values() if v)
        failed = sum(1 for v in results.values() if not v)
        logger.info("Extensions loaded: %d successful, %d failed", loaded, failed)
        
        return results

    async def load(self, name: str) -> bool:
        """Load a single extension.
        
        Enforces security checks:
          1. Dependency resolution
          2. Allowlist / source trust check (via ExtensionSecurityManager)
          3. Capability declaration validation
        
        Returns True if loaded successfully.
        """
        if name not in self._extensions:
            logger.error("Extension '%s' not registered", name)
            return False
        
        if self._states.get(name) == ExtensionState.ACTIVE:
            logger.warning("Extension '%s' already active", name)
            return True
        
        extension = self._extensions[name]
        
        # ── Security: source trust / allowlist check ──────────────────
        security = getattr(self._bot, 'extension_security', None) if self._bot else None
        if security:
            source = self._extension_sources.get(name)
            if source is None:
                source = security.classify_source(name)
            if not security.can_load(name, source):
                reason = security.get_load_denial_reason(name, source)
                logger.warning(
                    "Extension '%s' blocked by security policy: %s", name, reason
                )
                self._states[name] = ExtensionState.DISABLED
                return False
        
        # Check dependencies
        for dep in extension.requires:
            if dep not in self._extensions:
                logger.error(
                    "Extension '%s' requires '%s' which is not registered", 
                    name, dep
                )
                self._states[name] = ExtensionState.ERROR
                return False
            if self._states.get(dep) != ExtensionState.ACTIVE:
                logger.error(
                    "Extension '%s' requires '%s' which is not active (state=%s)", 
                    name, dep, self._states.get(dep)
                )
                self._states[name] = ExtensionState.ERROR
                return False
        
        # Load extension config from bot config
        ext_configs = getattr(self._bot.config, '_extensions_config', {})
        ext_config = ext_configs.get(name, {})
        
        # Create context
        ctx = ExtensionContext(
            bot=self._bot,
            extension_name=name,
            extension_config=ext_config,
        )
        
        self._states[name] = ExtensionState.LOADING
        
        try:
            await extension.on_load(ctx)
            self._contexts[name] = ctx
            self._states[name] = ExtensionState.ACTIVE
            self._load_order.append(name)
            logger.info("Extension '%s' loaded successfully", name)
            
            # Emit load event
            self.emit("extension.loaded", {"extension": name, "version": extension.version})
            
            return True
            
        except Exception as e:
            logger.error("Extension '%s' failed to load: %s", name, e, exc_info=True)
            self._states[name] = ExtensionState.ERROR
            ctx.cleanup()
            return False

    async def unload(self, name: str) -> bool:
        """Unload an extension.
        
        Returns True if unloaded successfully.
        """
        if name not in self._extensions:
            return False
        
        if self._states.get(name) != ExtensionState.ACTIVE:
            return False
        
        # Check if other active extensions depend on this one
        dependents = [
            ext_name for ext_name, ext in self._extensions.items()
            if name in ext.requires and self._states.get(ext_name) == ExtensionState.ACTIVE
        ]
        if dependents:
            logger.error(
                "Cannot unload '%s' — depended on by: %s", 
                name, ", ".join(dependents)
            )
            return False
        
        extension = self._extensions[name]
        ctx = self._contexts.get(name)
        
        try:
            if ctx:
                await extension.on_unload(ctx)
                ctx.cleanup()
        except Exception as e:
            logger.warning("Extension '%s' on_unload error (continuing): %s", name, e)
        
        self._states[name] = ExtensionState.UNLOADED
        self._contexts.pop(name, None)
        if name in self._load_order:
            self._load_order.remove(name)
        
        self.emit("extension.unloaded", {"extension": name})
        logger.info("Extension '%s' unloaded", name)
        return True

    async def reload(self, name: str) -> bool:
        """Unload and reload an extension (hot-reload)."""
        if self._states.get(name) == ExtensionState.ACTIVE:
            await self.unload(name)
        return await self.load(name)

    def get(self, name: str) -> Optional[Extension]:
        """Get a loaded extension by name."""
        if self._states.get(name) == ExtensionState.ACTIVE:
            return self._extensions.get(name)
        return None

    def get_context(self, name: str) -> Optional[ExtensionContext]:
        """Get the context for a loaded extension."""
        return self._contexts.get(name)

    # ── Event Bus ─────────────────────────────────────────────────────────

    def subscribe(self, event_type: str, handler: Callable) -> None:
        """Subscribe to an event type."""
        self._event_handlers[event_type].append(handler)

    def unsubscribe(self, event_type: str, handler: Callable) -> None:
        """Unsubscribe from an event type."""
        handlers = self._event_handlers.get(event_type, [])
        if handler in handlers:
            handlers.remove(handler)

    def emit(self, event_type: str, data: Dict[str, Any] = None) -> None:
        """Emit an event to all subscribers.
        
        Handlers are called synchronously. Use emit_async for async handlers.
        """
        handlers = self._event_handlers.get(event_type, [])
        for handler in handlers:
            try:
                handler(event_type, data or {})
            except Exception as e:
                logger.warning("Event handler error for '%s': %s", event_type, e)

    async def emit_async(self, event_type: str, data: Dict[str, Any] = None) -> None:
        """Emit an event and await all async handlers."""
        import asyncio
        handlers = self._event_handlers.get(event_type, [])
        for handler in handlers:
            try:
                result = handler(event_type, data or {})
                if asyncio.iscoroutine(result):
                    await result
            except Exception as e:
                logger.warning("Async event handler error for '%s': %s", event_type, e)

    # ── Command Dispatch ──────────────────────────────────────────────────

    def dispatch_command(self, command_name: str, user_id: str, args: str) -> Optional[str]:
        """Try to dispatch a command to extension-registered handlers.
        
        Returns the response string if handled, None if no handler found.
        """
        for name, ctx in self._contexts.items():
            if command_name in ctx._registered_commands:
                try:
                    handler = ctx._registered_commands[command_name]
                    return handler(user_id, args)
                except Exception as e:
                    logger.error("Extension command '%s' from '%s' failed: %s", 
                                command_name, name, e)
                    return f"Extension command error: {e}"
        return None

    # ── Status ────────────────────────────────────────────────────────────

    def status_board(self) -> str:
        """Generate a status board for all extensions."""
        if not self._extensions:
            return "No extensions registered."
        
        state_icons = {
            ExtensionState.REGISTERED: "⬜",
            ExtensionState.LOADING: "🔄",
            ExtensionState.ACTIVE: "✅",
            ExtensionState.ERROR: "❌",
            ExtensionState.DISABLED: "⏸️",
            ExtensionState.UNLOADED: "⬛",
        }
        
        lines = ["**🧩 Extensions:**"]
        for name, ext in self._extensions.items():
            state = self._states.get(name, ExtensionState.REGISTERED)
            icon = state_icons.get(state, "❓")
            ctx = self._contexts.get(name)
            tools = len(ctx._registered_tools) if ctx else 0
            commands = len(ctx._registered_commands) if ctx else 0
            extra = []
            if tools:
                extra.append(f"{tools} tools")
            if commands:
                extra.append(f"{commands} commands")
            extra_str = f" ({', '.join(extra)})" if extra else ""
            lines.append(f"{icon} **{name}** v{ext.version}{extra_str} — {state.value}")
        
        return "\n".join(lines)

    def list_extensions(self) -> List[Dict[str, Any]]:
        """List all extensions with their status."""
        result = []
        for name, ext in self._extensions.items():
            state = self._states.get(name, ExtensionState.REGISTERED)
            result.append({
                "name": name,
                "version": ext.version,
                "description": ext.description,
                "state": state.value,
                "requires": list(ext.requires),
            })
        return result

    # ── Dependency Resolution ─────────────────────────────────────────────

    def _resolve_load_order(self) -> List[str]:
        """Topological sort of extensions based on dependencies.
        
        Extensions with no dependencies load first.
        """
        # Build adjacency list
        in_degree: Dict[str, int] = {}
        dependents: Dict[str, List[str]] = defaultdict(list)
        
        for name, ext in self._extensions.items():
            if self._states.get(name) == ExtensionState.DISABLED:
                continue
            in_degree[name] = 0
        
        for name, ext in self._extensions.items():
            if name not in in_degree:
                continue
            for dep in ext.requires:
                if dep in in_degree:
                    in_degree[name] += 1
                    dependents[dep].append(name)
        
        # Kahn's algorithm
        queue = [name for name, deg in in_degree.items() if deg == 0]
        order = []
        
        while queue:
            node = queue.pop(0)
            order.append(node)
            for dep in dependents.get(node, []):
                in_degree[dep] -= 1
                if in_degree[dep] == 0:
                    queue.append(dep)
        
        # Check for cycles
        if len(order) != len(in_degree):
            remaining = set(in_degree.keys()) - set(order)
            logger.error("Circular dependency detected among extensions: %s", remaining)
            # Load the remaining anyway (they'll fail on dependency check)
            order.extend(remaining)
        
        return order

    async def shutdown(self) -> None:
        """Unload all extensions in reverse order."""
        for name in reversed(list(self._load_order)):
            try:
                await self.unload(name)
            except Exception as e:
                logger.warning("Error unloading '%s' during shutdown: %s", name, e)
        
        self._event_handlers.clear()
        logger.info("Extension manager shut down")
