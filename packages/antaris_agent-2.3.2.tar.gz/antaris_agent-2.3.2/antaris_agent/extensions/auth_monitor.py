"""
Auth Monitor Extension — tracks API key health, usage, rotation, and expiry.

Features:
  - Monitors API key validity and rate limit status
  - Tracks per-provider AND per-profile usage patterns
  - Detects approaching rate limits
  - Alerts on key expiry (OAuth tokens)
  - Auto-rotates between auth profiles when rate-limited or unhealthy
  - Writes back lastGood / usageStats to auth-profiles.json
  - Fires webhook events for auth state changes
  - Operator-facing notification messages for rotation events
"""

from __future__ import annotations

import asyncio
import json
import logging
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from .base import Extension, ExtensionContext

logger = logging.getLogger(__name__)


# ── Data classes ──────────────────────────────────────────────────────────

@dataclass
class AuthKeyStatus:
    """Status of a single API key / auth credential."""
    provider: str
    profile_id: str = ""
    key_preview: str = ""          # Last 8 chars for identification
    is_valid: bool = True
    is_rate_limited: bool = False
    rate_limit_resets_at: float = 0.0  # Unix timestamp
    last_used: float = 0.0
    total_calls: int = 0
    total_errors: int = 0
    consecutive_errors: int = 0
    expires_at: float = 0.0        # 0 = no expiry known
    last_check: float = 0.0
    error_message: str = ""
    is_auth_error: bool = False    # 401/403 — key itself is bad


@dataclass
class ProfileStatus:
    """Status of a single auth profile (more granular than provider-level)."""
    profile_id: str
    provider: str
    key_preview: str = ""
    is_valid: bool = True
    is_rate_limited: bool = False
    rate_limit_resets_at: float = 0.0
    consecutive_errors: int = 0
    total_calls: int = 0
    total_errors: int = 0
    expires_at: float = 0.0
    last_used: float = 0.0
    error_message: str = ""
    is_auth_error: bool = False


@dataclass
class AuthHealth:
    """Aggregate auth health across all providers."""
    providers: Dict[str, AuthKeyStatus] = field(default_factory=dict)
    profiles: Dict[str, ProfileStatus] = field(default_factory=dict)
    primary_provider: str = ""
    active_profile: str = ""       # Currently active profile ID
    fallback_available: bool = False
    overall_healthy: bool = True
    last_rotation: float = 0.0
    rotation_count: int = 0
    rotation_log: List[Dict[str, Any]] = field(default_factory=list)


@dataclass
class RotationEvent:
    """Represents a profile rotation event for operator visibility."""
    timestamp: float
    from_profile: str
    to_profile: str
    provider: str
    reason: str  # "rate_limit" | "auth_error" | "consecutive_errors" | "expired" | "server_error"
    detail: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "timestamp": self.timestamp,
            "from": self.from_profile,
            "to": self.to_profile,
            "provider": self.provider,
            "reason": self.reason,
            "detail": self.detail,
            "time_str": datetime.fromtimestamp(self.timestamp, tz=timezone.utc).isoformat(),
        }

    def to_notification(self) -> str:
        """Generate a human-readable notification message."""
        reason_emoji = {
            "rate_limit": "⏳",
            "auth_error": "🔑",
            "consecutive_errors": "❌",
            "expired": "⏰",
            "server_error": "🔥",
        }
        icon = reason_emoji.get(self.reason, "🔄")
        ts = datetime.fromtimestamp(self.timestamp, tz=timezone.utc).strftime("%H:%M:%S UTC")
        msg = f"{icon} **Auth Profile Rotated** ({ts})\n"
        msg += f"Provider: **{self.provider}**\n"
        msg += f"From: `{self.from_profile}` → To: `{self.to_profile}`\n"
        msg += f"Reason: {self.reason}"
        if self.detail:
            msg += f" — {self.detail}"
        return msg


# ── Auth Profiles File Manager ────────────────────────────────────────────

class AuthProfilesFile:
    """Reads and writes auth-profiles.json for profile rotation state.
    
    Manages:
      - Reading available profiles per provider
      - Updating lastGood when a profile works
      - Updating usageStats on calls/errors
      - Resolving the next-best profile when current one fails
    """

    def __init__(self, auth_profiles_path: Optional[str] = None):
        self._path = self._resolve_path(auth_profiles_path)
        self._data: Dict[str, Any] = {}
        self._load()

    @staticmethod
    def _resolve_path(explicit_path: Optional[str] = None) -> Path:
        """Resolve auth-profiles.json location."""
        if explicit_path:
            return Path(explicit_path).expanduser().resolve()
        
        import os
        env = os.environ.get("ANTARIS_AUTH_PROFILES")
        if env:
            return Path(env).expanduser().resolve()
        
        # Try config dir
        try:
            from antaris_agent.core.config import resolve_config_path
            candidate = resolve_config_path().parent / "auth-profiles.json"
            if candidate.exists():
                return candidate
        except Exception:
            pass
        
        # OpenClaw default
        openclaw = Path.home() / ".openclaw" / "agents" / "main" / "agent" / "auth-profiles.json"
        if openclaw.exists():
            return openclaw
        
        return Path.home() / ".antaris" / "auth-profiles.json"

    def _load(self) -> None:
        """Load auth-profiles.json from disk."""
        if not self._path.exists():
            self._data = {}
            return
        try:
            with open(self._path) as f:
                self._data = json.load(f)
            if not isinstance(self._data, dict):
                self._data = {}
        except Exception as e:
            logger.warning("Failed to load auth-profiles.json: %s", e)
            self._data = {}

    def reload(self) -> None:
        """Re-read from disk (e.g., after external rotation by OpenClaw gateway)."""
        self._load()

    @property
    def path(self) -> Path:
        return self._path

    def get_profiles_for_provider(self, provider: str) -> List[Tuple[str, Dict[str, Any]]]:
        """Get all profiles for a provider, ordered by preference.
        
        Returns list of (profile_id, profile_data) tuples.
        Order: order list first, then any remaining profiles.
        """
        profiles = self._data.get("profiles", {})
        order = self._data.get("order", {}).get(provider, [])
        
        result = []
        seen = set()
        
        # Add profiles in explicit order first
        for pid in order:
            if pid in profiles:
                result.append((pid, profiles[pid]))
                seen.add(pid)
        
        # Add any remaining profiles for this provider
        for pid, pdata in profiles.items():
            if pid not in seen and isinstance(pdata, dict):
                if pdata.get("provider", "") == provider or pid.startswith(f"{provider}:"):
                    result.append((pid, pdata))
        
        return result

    def get_credential(self, profile_id: str) -> Optional[str]:
        """Extract the credential (token/apiKey/access) from a profile."""
        profile = self._data.get("profiles", {}).get(profile_id, {})
        if not isinstance(profile, dict):
            return None
        cred = profile.get("token") or profile.get("apiKey") or profile.get("access")
        return cred if isinstance(cred, str) and len(cred) > 20 else None

    def get_expires(self, profile_id: str) -> float:
        """Get expiry timestamp for a profile (0 if none)."""
        profile = self._data.get("profiles", {}).get(profile_id, {})
        if not isinstance(profile, dict):
            return 0.0
        expires = profile.get("expires", 0)
        if isinstance(expires, (int, float)) and expires > 0:
            # Auth-profiles stores ms, convert to seconds
            return expires / 1000.0 if expires > 1e12 else float(expires)
        return 0.0

    def get_last_good(self, provider: str) -> Optional[str]:
        """Get the lastGood profile ID for a provider."""
        return self._data.get("lastGood", {}).get(provider)

    def set_last_good(self, provider: str, profile_id: str) -> None:
        """Update lastGood and persist."""
        if "lastGood" not in self._data:
            self._data["lastGood"] = {}
        self._data["lastGood"][provider] = profile_id
        self._save()

    def record_usage(self, profile_id: str, success: bool, error_msg: str = "") -> None:
        """Update usageStats for a profile."""
        if "usageStats" not in self._data:
            self._data["usageStats"] = {}
        stats = self._data["usageStats"].setdefault(profile_id, {
            "errorCount": 0,
            "lastUsed": 0,
        })
        stats["lastUsed"] = int(time.time() * 1000)
        if not success:
            stats["errorCount"] = stats.get("errorCount", 0) + 1
            if error_msg:
                stats["lastError"] = error_msg[:200]
                stats["lastErrorAt"] = int(time.time() * 1000)
        else:
            # Reset error count on success
            stats["errorCount"] = 0
            stats.pop("lastError", None)
            stats.pop("lastErrorAt", None)
        self._save()

    def get_next_profile(self, provider: str, exclude: Optional[str] = None) -> Optional[Tuple[str, str]]:
        """Get the next available profile for a provider, excluding the failed one.
        
        Returns (profile_id, credential) or None if no alternative exists.
        Skips expired profiles.
        """
        profiles = self.get_profiles_for_provider(provider)
        now = time.time()
        
        for pid, pdata in profiles:
            if pid == exclude:
                continue
            
            # Check expiry
            expires = self.get_expires(pid)
            if expires > 0 and expires < now:
                logger.debug("Skipping expired profile %s (expired at %s)", pid, expires)
                continue
            
            cred = self.get_credential(pid)
            if cred:
                return (pid, cred)
        
        return None

    def _save(self) -> None:
        """Persist auth-profiles.json to disk."""
        if not self._path.parent.exists():
            return
        try:
            tmp = self._path.parent / (self._path.name + ".tmp")
            with open(tmp, 'w') as f:
                json.dump(self._data, f, indent=2)
            import os
            os.replace(str(tmp), str(self._path))
        except Exception as e:
            logger.warning("Failed to save auth-profiles.json: %s", e)


# ── Auth Monitor ──────────────────────────────────────────────────────────

class AuthMonitor:
    """Monitors API key health and manages automatic failover.
    
    Two-level rotation:
      1. Intra-provider: rotates between profiles of the same provider
         (e.g., anthropic:oauth → anthropic:api-key)
      2. Cross-provider: falls back to a different provider entirely
         (e.g., anthropic → openai)
    
    Integrates with:
      - LLM dispatcher for catching failures and triggering rotation
      - auth-profiles.json for credential resolution and state persistence
      - Webhook/notification system for operator alerts
    """

    # Consecutive error threshold before marking a profile unhealthy
    UNHEALTHY_THRESHOLD = 3
    # Maximum rotation events to keep in memory
    MAX_ROTATION_LOG = 50

    def __init__(self, config_dir: str, check_interval: int = 300,
                 auth_profiles_path: Optional[str] = None):
        self.config_dir = Path(config_dir)
        self.check_interval = check_interval  # seconds between health checks
        self._health = AuthHealth()
        self._state_file = self.config_dir / "auth_monitor_state.json"
        self._running = False
        self._check_task: Optional[asyncio.Task] = None
        self._event_callback: Optional[callable] = None
        self._notification_callback: Optional[callable] = None
        self._profiles_file = AuthProfilesFile(auth_profiles_path)
        self._load_state()
        self._sync_profile_expiry()

    def set_event_callback(self, callback: callable) -> None:
        """Set callback for auth events (used by webhook system)."""
        self._event_callback = callback

    def set_notification_callback(self, callback: callable) -> None:
        """Set callback for operator-facing notifications.
        
        callback(message: str) — called with a human-readable message
        when a rotation event occurs that the operator should know about.
        """
        self._notification_callback = callback

    # ── Core Recording ────────────────────────────────────────────────────

    def record_call(self, provider: str, success: bool,
                    error: Optional[str] = None,
                    rate_limited: bool = False,
                    rate_limit_reset: float = 0.0,
                    auth_error: bool = False,
                    profile_id: str = "") -> None:
        """Record an API call result for monitoring.
        
        Called by LLM dispatcher after each API call.
        
        Args:
            provider: Provider name (e.g. "anthropic")
            success: Whether the call succeeded
            error: Error message if failed
            rate_limited: Whether the failure was a rate limit (429)
            rate_limit_reset: Unix timestamp when rate limit resets
            auth_error: Whether the failure was an auth error (401/403)
            profile_id: The specific profile ID that was used
        """
        # Provider-level tracking
        status = self._get_or_create_status(provider)
        status.last_used = time.time()
        status.total_calls += 1

        if success:
            status.consecutive_errors = 0
            status.is_rate_limited = False
            status.is_auth_error = False
        else:
            status.total_errors += 1
            status.consecutive_errors += 1
            if error:
                status.error_message = error

            if auth_error:
                status.is_auth_error = True
                status.is_valid = False
                self._fire_event("auth.auth_error", {
                    "provider": provider,
                    "profile_id": profile_id,
                    "error": error,
                })

            if rate_limited:
                status.is_rate_limited = True
                status.rate_limit_resets_at = rate_limit_reset
                self._fire_event("auth.rate_limited", {
                    "provider": provider,
                    "profile_id": profile_id,
                    "resets_at": rate_limit_reset,
                })

            # Mark unhealthy after threshold consecutive errors
            if status.consecutive_errors >= self.UNHEALTHY_THRESHOLD:
                status.is_valid = False
                self._fire_event("auth.key_unhealthy", {
                    "provider": provider,
                    "profile_id": profile_id,
                    "consecutive_errors": status.consecutive_errors,
                    "error": error,
                })

        # Profile-level tracking
        if profile_id:
            self._record_profile_call(profile_id, provider, success, error,
                                       rate_limited, rate_limit_reset, auth_error)
            # Update auth-profiles.json usageStats
            self._profiles_file.record_usage(profile_id, success, error or "")

        self._update_overall_health()
        self._save_state()

    def _record_profile_call(self, profile_id: str, provider: str,
                              success: bool, error: Optional[str],
                              rate_limited: bool, rate_limit_reset: float,
                              auth_error: bool) -> None:
        """Track per-profile health."""
        if profile_id not in self._health.profiles:
            self._health.profiles[profile_id] = ProfileStatus(
                profile_id=profile_id,
                provider=provider,
            )
        ps = self._health.profiles[profile_id]
        ps.last_used = time.time()
        ps.total_calls += 1

        if success:
            ps.consecutive_errors = 0
            ps.is_rate_limited = False
            ps.is_auth_error = False
            ps.is_valid = True
        else:
            ps.total_errors += 1
            ps.consecutive_errors += 1
            if error:
                ps.error_message = error
            if auth_error:
                ps.is_auth_error = True
                ps.is_valid = False
            if rate_limited:
                ps.is_rate_limited = True
                ps.rate_limit_resets_at = rate_limit_reset
            if ps.consecutive_errors >= self.UNHEALTHY_THRESHOLD:
                ps.is_valid = False

    def record_key_rotation(self, provider: str, new_key_preview: str = "",
                             from_profile: str = "", to_profile: str = "",
                             reason: str = "manual") -> None:
        """Record that an API key/profile was rotated."""
        status = self._get_or_create_status(provider)
        status.is_valid = True
        status.is_rate_limited = False
        status.is_auth_error = False
        status.consecutive_errors = 0
        status.error_message = ""
        if new_key_preview:
            status.key_preview = new_key_preview
        if to_profile:
            status.profile_id = to_profile
            self._health.active_profile = to_profile

        self._health.last_rotation = time.time()
        self._health.rotation_count += 1

        # Build rotation event
        event = RotationEvent(
            timestamp=time.time(),
            from_profile=from_profile,
            to_profile=to_profile,
            provider=provider,
            reason=reason,
        )
        self._health.rotation_log.append(event.to_dict())
        if len(self._health.rotation_log) > self.MAX_ROTATION_LOG:
            self._health.rotation_log = self._health.rotation_log[-self.MAX_ROTATION_LOG:]

        # Fire events
        self._fire_event("auth.profile_rotated", {
            "provider": provider,
            "from_profile": from_profile,
            "to_profile": to_profile,
            "reason": reason,
        })

        # Operator notification
        self._notify_operator(event.to_notification())

        # Update auth-profiles.json lastGood
        if to_profile:
            self._profiles_file.set_last_good(provider, to_profile)

        self._save_state()

    def check_expiry(self, provider: str, expires_at: float) -> None:
        """Register or update the expiry time for a credential.
        
        Fires warnings when expiry is approaching.
        """
        status = self._get_or_create_status(provider)
        status.expires_at = expires_at

        if expires_at > 0:
            time_left = expires_at - time.time()
            if time_left <= 0:
                status.is_valid = False
                self._fire_event("auth.key_expired", {
                    "provider": provider,
                    "profile_id": status.profile_id,
                })
                self._notify_operator(
                    f"⏰ **Auth Key Expired** — provider: **{provider}**, "
                    f"profile: `{status.profile_id or 'default'}`"
                )
            elif time_left < 3600:  # Less than 1 hour
                self._fire_event("auth.key_expiring", {
                    "provider": provider,
                    "profile_id": status.profile_id,
                    "expires_in_seconds": time_left,
                })
            elif time_left < 86400:  # Less than 24 hours
                self._fire_event("auth.key_expiring_soon", {
                    "provider": provider,
                    "profile_id": status.profile_id,
                    "expires_in_hours": time_left / 3600,
                })

    # ── Rotation Logic ────────────────────────────────────────────────────

    def try_rotate_profile(self, provider: str, current_profile: str = "",
                            reason: str = "unknown") -> Optional[Tuple[str, str]]:
        """Attempt intra-provider profile rotation.
        
        Looks for an alternative profile in auth-profiles.json for the same
        provider, skipping the current one.
        
        Args:
            provider: The provider name (e.g. "anthropic")
            current_profile: The profile ID that just failed
            reason: Why rotation is being attempted
            
        Returns:
            (profile_id, credential) if a viable alternative is found, else None.
        """
        # Reload from disk in case OpenClaw gateway rotated tokens externally
        self._profiles_file.reload()

        result = self._profiles_file.get_next_profile(provider, exclude=current_profile)
        if result:
            new_pid, new_cred = result
            key_preview = new_cred[-8:] if len(new_cred) > 8 else "***"
            self.record_key_rotation(
                provider=provider,
                new_key_preview=key_preview,
                from_profile=current_profile,
                to_profile=new_pid,
                reason=reason,
            )
            logger.info(
                "Auth profile rotated: %s → %s (provider=%s, reason=%s)",
                current_profile, new_pid, provider, reason,
            )
            return result
        
        logger.warning(
            "No alternative profile available for %s (current=%s, reason=%s)",
            provider, current_profile, reason,
        )
        return None

    def should_failover(self, provider: str) -> Optional[str]:
        """Check if we should fail over to another provider (cross-provider).
        
        Returns the name of the fallback provider, or None.
        """
        status = self._health.providers.get(provider)
        if not status:
            return None

        if status.is_valid and not status.is_rate_limited and not status.is_auth_error:
            return None

        # Find a healthy alternative provider
        for alt_provider, alt_status in self._health.providers.items():
            if alt_provider == provider:
                continue
            if alt_status.is_valid and not alt_status.is_rate_limited and not alt_status.is_auth_error:
                return alt_provider

        return None

    def should_rotate_profile(self, provider: str) -> bool:
        """Check if intra-provider profile rotation should be attempted.
        
        Returns True if the current profile is unhealthy and alternatives exist.
        """
        status = self._health.providers.get(provider)
        if not status:
            return False

        if status.is_valid and not status.is_rate_limited and not status.is_auth_error:
            return False

        # Check if there are alternative profiles
        current = status.profile_id or self._profiles_file.get_last_good(provider) or ""
        alt = self._profiles_file.get_next_profile(provider, exclude=current)
        return alt is not None

    def get_active_profile(self, provider: str) -> str:
        """Get the currently active profile ID for a provider."""
        status = self._health.providers.get(provider)
        if status and status.profile_id:
            return status.profile_id
        return self._profiles_file.get_last_good(provider) or ""

    # ── Health Reporting ──────────────────────────────────────────────────

    def get_health(self) -> AuthHealth:
        """Get current auth health status."""
        self._update_overall_health()
        return self._health

    def get_status_text(self) -> str:
        """Generate human-readable auth status."""
        health = self.get_health()

        if not health.providers:
            return "No auth providers configured."

        lines = ["**🔑 Auth Status:**"]

        for provider, status in health.providers.items():
            icon = "✅" if status.is_valid else "❌"
            if status.is_rate_limited:
                icon = "⏳"
            if status.is_auth_error:
                icon = "🔑❌"

            parts = [f"{icon} **{provider}**"]

            if status.profile_id:
                parts.append(f"[`{status.profile_id}`]")
            if status.key_preview:
                parts.append(f"(…{status.key_preview})")

            parts.append(f"— {status.total_calls} calls")

            if status.total_errors > 0:
                parts.append(f", {status.total_errors} errors")

            if status.is_rate_limited:
                if status.rate_limit_resets_at > time.time():
                    wait = int(status.rate_limit_resets_at - time.time())
                    parts.append(f" [rate limited, resets in {wait}s]")
                else:
                    parts.append(" [rate limited]")

            if status.expires_at > 0:
                remaining = status.expires_at - time.time()
                if remaining <= 0:
                    parts.append(" ⚠️ EXPIRED")
                elif remaining < 3600:
                    parts.append(f" ⚠️ expires in {int(remaining / 60)}m")
                elif remaining < 86400:
                    parts.append(f" (expires in {int(remaining / 3600)}h)")

            if not status.is_valid and status.error_message:
                parts.append(f"\n  └ {status.error_message[:100]}")

            lines.append(" ".join(parts))

        # Profile-level detail
        if health.profiles:
            lines.append("\n**📋 Profile Detail:**")
            for pid, ps in health.profiles.items():
                icon = "✅" if ps.is_valid else "❌"
                if ps.is_rate_limited:
                    icon = "⏳"
                line = f"  {icon} `{pid}` — {ps.total_calls} calls, {ps.total_errors} errors"
                if ps.consecutive_errors > 0:
                    line += f" (streak: {ps.consecutive_errors})"
                lines.append(line)

        # Rotation log (last 5)
        if health.rotation_log:
            lines.append("\n**🔄 Recent Rotations:**")
            for entry in health.rotation_log[-5:]:
                ts = entry.get("time_str", "?")
                lines.append(
                    f"  {ts}: {entry.get('from', '?')} → {entry.get('to', '?')} "
                    f"({entry.get('reason', '?')})"
                )

        # Overall
        overall = "✅ Healthy" if health.overall_healthy else "⚠️ Degraded"
        lines.append(f"\nOverall: {overall}")
        if health.fallback_available:
            lines.append("Fallback provider: available")
        if health.rotation_count > 0:
            lines.append(f"Key rotations: {health.rotation_count}")

        return "\n".join(lines)

    # ── Periodic Health Check ─────────────────────────────────────────────

    async def start_monitoring(self) -> None:
        """Start periodic auth health monitoring."""
        if self._running:
            return
        self._running = True
        self._check_task = asyncio.create_task(self._periodic_check())
        logger.info("Auth monitoring started (interval=%ds)", self.check_interval)

    async def stop_monitoring(self) -> None:
        """Stop periodic monitoring."""
        self._running = False
        if self._check_task:
            self._check_task.cancel()
            try:
                await self._check_task
            except asyncio.CancelledError:
                pass

    async def _periodic_check(self) -> None:
        """Periodically check auth health."""
        while self._running:
            try:
                await asyncio.sleep(self.check_interval)
                self._check_rate_limit_resets()
                self._check_all_expiry()
                self._check_profile_expiry()
                self._update_overall_health()
                self._save_state()
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.warning("Auth periodic check failed: %s", e)

    def _check_rate_limit_resets(self) -> None:
        """Clear rate limit flags for providers whose reset time has passed."""
        now = time.time()
        for status in self._health.providers.values():
            if status.is_rate_limited and status.rate_limit_resets_at > 0:
                if now >= status.rate_limit_resets_at:
                    status.is_rate_limited = False
                    status.rate_limit_resets_at = 0.0
                    logger.info("Rate limit cleared for provider: %s", status.provider)

        for ps in self._health.profiles.values():
            if ps.is_rate_limited and ps.rate_limit_resets_at > 0:
                if now >= ps.rate_limit_resets_at:
                    ps.is_rate_limited = False
                    ps.rate_limit_resets_at = 0.0
                    logger.info("Rate limit cleared for profile: %s", ps.profile_id)

    def _check_all_expiry(self) -> None:
        """Check all providers for approaching expiry."""
        for provider, status in self._health.providers.items():
            if status.expires_at > 0:
                self.check_expiry(provider, status.expires_at)

    def _check_profile_expiry(self) -> None:
        """Check auth-profiles.json for OAuth token expiry.
        
        Proactively detects expiring profiles and triggers rotation
        before they actually fail.
        """
        self._profiles_file.reload()
        now = time.time()

        for provider in set(self._health.providers.keys()):
            profiles = self._profiles_file.get_profiles_for_provider(provider)
            active_pid = self.get_active_profile(provider)

            for pid, pdata in profiles:
                expires = self._profiles_file.get_expires(pid)
                if expires <= 0:
                    continue

                time_left = expires - now

                # Track in profile status
                if pid in self._health.profiles:
                    self._health.profiles[pid].expires_at = expires

                if pid == active_pid:
                    if time_left <= 0:
                        # Active profile expired — rotate NOW
                        logger.warning("Active profile %s has expired, rotating", pid)
                        self.try_rotate_profile(provider, current_profile=pid, reason="expired")
                    elif time_left < 300:  # Less than 5 minutes
                        # About to expire — proactive rotation
                        logger.info("Active profile %s expiring in %.0fs, proactive rotation", pid, time_left)
                        self.try_rotate_profile(provider, current_profile=pid, reason="expiring_soon")
                    elif time_left < 3600:
                        self._fire_event("auth.profile_expiring", {
                            "provider": provider,
                            "profile_id": pid,
                            "expires_in_seconds": time_left,
                        })

    def _sync_profile_expiry(self) -> None:
        """On startup, load expiry info from auth-profiles.json into health state."""
        for provider in list(self._health.providers.keys()):
            profiles = self._profiles_file.get_profiles_for_provider(provider)
            for pid, pdata in profiles:
                expires = self._profiles_file.get_expires(pid)
                if expires > 0:
                    # Set expiry on the provider-level status if this is the active profile
                    active = self.get_active_profile(provider)
                    if pid == active:
                        self._health.providers[provider].expires_at = expires

    # ── Internal ──────────────────────────────────────────────────────────

    def _get_or_create_status(self, provider: str) -> AuthKeyStatus:
        """Get or create an AuthKeyStatus for a provider."""
        if provider not in self._health.providers:
            self._health.providers[provider] = AuthKeyStatus(provider=provider)
        return self._health.providers[provider]

    def _update_overall_health(self) -> None:
        """Update the overall health assessment."""
        if not self._health.providers:
            self._health.overall_healthy = True
            return

        primary = self._health.primary_provider
        if primary and primary in self._health.providers:
            primary_status = self._health.providers[primary]
            self._health.overall_healthy = (
                primary_status.is_valid
                and not primary_status.is_rate_limited
                and not primary_status.is_auth_error
            )
        else:
            self._health.overall_healthy = any(
                s.is_valid and not s.is_rate_limited and not s.is_auth_error
                for s in self._health.providers.values()
            )

        # Check fallback availability
        healthy_count = sum(
            1 for s in self._health.providers.values()
            if s.is_valid and not s.is_rate_limited and not s.is_auth_error
        )
        self._health.fallback_available = healthy_count > 1

    def _fire_event(self, event_type: str, data: Dict[str, Any]) -> None:
        """Fire an auth event (webhook system)."""
        if self._event_callback:
            try:
                self._event_callback(event_type, data)
            except Exception as e:
                logger.warning("Auth event callback failed: %s", e)

    def _notify_operator(self, message: str) -> None:
        """Send a notification to the operator (e.g., Discord DM or log channel)."""
        logger.info("Auth notification: %s", message.replace("\n", " | "))
        if self._notification_callback:
            try:
                self._notification_callback(message)
            except Exception as e:
                logger.warning("Auth notification callback failed: %s", e)

    def _save_state(self) -> None:
        """Persist auth monitor state to disk."""
        try:
            self._state_file.parent.mkdir(parents=True, exist_ok=True)
            state = {
                "providers": {},
                "profiles": {},
                "primary_provider": self._health.primary_provider,
                "active_profile": self._health.active_profile,
                "rotation_count": self._health.rotation_count,
                "last_rotation": self._health.last_rotation,
                "rotation_log": self._health.rotation_log[-self.MAX_ROTATION_LOG:],
            }
            for name, status in self._health.providers.items():
                state["providers"][name] = {
                    "provider": status.provider,
                    "profile_id": status.profile_id,
                    "key_preview": status.key_preview,
                    "is_valid": status.is_valid,
                    "is_auth_error": status.is_auth_error,
                    "total_calls": status.total_calls,
                    "total_errors": status.total_errors,
                    "consecutive_errors": status.consecutive_errors,
                    "expires_at": status.expires_at,
                    "last_used": status.last_used,
                }
            for pid, ps in self._health.profiles.items():
                state["profiles"][pid] = {
                    "profile_id": ps.profile_id,
                    "provider": ps.provider,
                    "is_valid": ps.is_valid,
                    "is_auth_error": ps.is_auth_error,
                    "total_calls": ps.total_calls,
                    "total_errors": ps.total_errors,
                    "consecutive_errors": ps.consecutive_errors,
                    "expires_at": ps.expires_at,
                    "last_used": ps.last_used,
                }
            with open(self._state_file, 'w') as f:
                json.dump(state, f, indent=2)
        except Exception as e:
            logger.debug("Auth state save failed: %s", e)

    def _load_state(self) -> None:
        """Load auth monitor state from disk."""
        if not self._state_file.exists():
            return
        try:
            with open(self._state_file) as f:
                state = json.load(f)

            self._health.primary_provider = state.get("primary_provider", "")
            self._health.active_profile = state.get("active_profile", "")
            self._health.rotation_count = state.get("rotation_count", 0)
            self._health.last_rotation = state.get("last_rotation", 0.0)
            self._health.rotation_log = state.get("rotation_log", [])

            for name, data in state.get("providers", {}).items():
                status = AuthKeyStatus(
                    provider=data.get("provider", name),
                    profile_id=data.get("profile_id", ""),
                    key_preview=data.get("key_preview", ""),
                    is_valid=data.get("is_valid", True),
                    is_auth_error=data.get("is_auth_error", False),
                    total_calls=data.get("total_calls", 0),
                    total_errors=data.get("total_errors", 0),
                    consecutive_errors=data.get("consecutive_errors", 0),
                    expires_at=data.get("expires_at", 0.0),
                    last_used=data.get("last_used", 0.0),
                )
                self._health.providers[name] = status

            for pid, data in state.get("profiles", {}).items():
                ps = ProfileStatus(
                    profile_id=data.get("profile_id", pid),
                    provider=data.get("provider", ""),
                    is_valid=data.get("is_valid", True),
                    is_auth_error=data.get("is_auth_error", False),
                    total_calls=data.get("total_calls", 0),
                    total_errors=data.get("total_errors", 0),
                    consecutive_errors=data.get("consecutive_errors", 0),
                    expires_at=data.get("expires_at", 0.0),
                    last_used=data.get("last_used", 0.0),
                )
                self._health.profiles[pid] = ps

        except Exception as e:
            logger.debug("Auth state load failed: %s", e)


# ── Extension Wrapper ─────────────────────────────────────────────────────

class AuthMonitorExtension(Extension):
    """Extension wrapper for the AuthMonitor.
    
    Registers as a standard extension that hooks into the pipeline
    to monitor API call health automatically.
    """

    name = "auth-monitor"
    version = "2.0.0"
    description = "Monitors API key health, profile rotation, and expiry"

    def __init__(self):
        self._monitor: Optional[AuthMonitor] = None

    async def on_load(self, ctx: ExtensionContext) -> None:
        config_dir = ctx.data_dir
        check_interval = ctx.config.get("check_interval", 300)

        self._monitor = AuthMonitor(
            config_dir=config_dir,
            check_interval=check_interval,
        )

        # Wire event callback
        self._monitor.set_event_callback(
            lambda event_type, data: ctx.emit_event(event_type, data)
        )

        # Set primary provider
        self._monitor._health.primary_provider = ctx.config.get(
            "primary_provider", "anthropic"
        )

        # Register !auth command
        ctx.register_command("auth", self._cmd_auth)

        # Start monitoring
        await self._monitor.start_monitoring()

    async def on_unload(self, ctx: ExtensionContext) -> None:
        if self._monitor:
            await self._monitor.stop_monitoring()

    def _cmd_auth(self, user_id: str, args: str) -> str:
        """Handle !auth command."""
        if not self._monitor:
            return "Auth monitor not initialized."
        return self._monitor.get_status_text()
