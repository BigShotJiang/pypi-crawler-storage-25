"""
Model Control Extension — runtime model switching and thinking levels.

Provides:
  - Per-user model overrides (temporary or persistent)
  - Thinking level control (off/low/medium/high)
  - Model aliases for quick switching
  - Cost-aware model suggestions
  - Provider failover controls
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from .base import Extension, ExtensionContext

logger = logging.getLogger(__name__)


class ThinkingLevel:
    """Thinking/reasoning level presets."""
    OFF = "off"           # No extended thinking
    LOW = "low"           # Minimal reasoning (budget: 1024 tokens)
    MEDIUM = "medium"     # Standard reasoning (budget: 4096 tokens)
    HIGH = "high"         # Deep reasoning (budget: 16384 tokens)
    MAX = "max"           # Maximum reasoning (budget: 32768 tokens)

    BUDGETS = {
        "off": 0,
        "low": 1024,
        "medium": 4096,
        "high": 16384,
        "max": 32768,
    }

    VALID_LEVELS = {"off", "low", "medium", "high", "max"}


PROVIDER_THINKING_SUPPORT: Dict[str, Dict[str, Any]] = {
    "anthropic": {
        "mode": "model-list",
        "models": {
            "claude-opus-4-6",
            "claude-sonnet-4-6",
            "claude-sonnet-6",
            "claude-sonnet-4-20250514",
        },
        "label": "Anthropic extended thinking",
    },
    "openai": {
        "mode": "prefix",
        "prefixes": ("o1", "o3", "o4"),
        "label": "OpenAI reasoning_effort",
    },
    "google": {
        "mode": "prefix",
        "prefixes": ("gemini-2.5", "gemini-3"),
        "label": "Gemini thinkingConfig",
    },
    "ollama": {
        "mode": "provider",
        "label": "Ollama think toggle",
    },
}


@dataclass
class ThinkingSupportStatus:
    requested_level: str
    requested_budget: int
    supported: bool
    provider: str = ""
    model: str = ""
    mechanism: str = ""
    warning: str = ""


@dataclass
class ModelOverride:
    """A user's model override configuration."""
    model: str = ""
    provider: str = ""
    thinking_level: str = "off"
    thinking_budget: int = 0
    set_at: float = 0.0
    expires_at: float = 0.0       # 0 = no expiry
    set_by: str = ""              # Who set it (user, admin, auto)
    reason: str = ""              # Why it was set
    last_thinking_warning: str = ""
    last_thinking_warning_at: float = 0.0


# Standard model aliases
MODEL_ALIASES: Dict[str, tuple[str, str]] = {
    # Anthropic
    "opus": ("claude-opus-4-6", "anthropic"),
    "sonnet": ("claude-sonnet-4-6", "anthropic"),
    "haiku": ("claude-haiku-4-5-20251001", "anthropic"),
    
    # OpenAI
    "gpt": ("gpt-5.4", "openai"),
    "gpt5": ("gpt-5.4", "openai"),
    "gpt4": ("gpt-4o", "openai"),
    "gpt4o": ("gpt-4o", "openai"),
    "o3": ("o3", "openai"),
    "o3-mini": ("o3-mini", "openai"),
    "o4-mini": ("o4-mini", "openai"),
    
    # Google
    "gemini": ("gemini-3.1-pro", "google"),
    "flash": ("gemini-2.5-flash", "google"),
    "gemini-pro": ("gemini-3.1-pro", "google"),
    
    # Ollama / Local
    "qwen": ("qwen3.5:4b", "ollama"),
    "qwen9b": ("qwen3.5:9b", "ollama"),
    "qwen8b": ("qwen3:8b", "ollama"),
    "local": ("qwen3.5:4b", "ollama"),
    
    # Meta shortcuts
    "fast": ("claude-haiku-4-5-20251001", "anthropic"),
    "smart": ("claude-sonnet-4-6", "anthropic"),
    "best": ("claude-opus-4-6", "anthropic"),
    "cheap": ("qwen3.5:4b", "ollama"),
}

# Cost estimates per 1M tokens (input, output)
MODEL_COSTS: Dict[str, tuple[float, float]] = {
    "claude-opus-4-6": (15.0, 75.0),
    "claude-sonnet-4-6": (3.0, 15.0),
    "claude-haiku-4-5-20251001": (0.80, 4.0),
    "gpt-5.4": (2.50, 10.0),
    "gpt-4o": (2.50, 10.0),
    "o3": (10.0, 40.0),
    "o3-mini": (1.10, 4.40),
    "gemini-3.1-pro": (1.25, 5.0),
    "gemini-2.5-flash": (0.075, 0.30),
}


class ModelController:
    """Controls model selection and thinking levels.
    
    Integrates with the pipeline to override the default model
    on a per-user or global basis.
    """

    def __init__(self):
        self._overrides: Dict[str, ModelOverride] = {}
        self._global_override: Optional[ModelOverride] = None
        self._default_thinking: str = ThinkingLevel.OFF

    def set_model(self, user_id: str, model_spec: str, 
                  duration_minutes: int = 0) -> tuple[str, str, str]:
        """Set model override for a user.
        
        Args:
            user_id: User to override for
            model_spec: Model name, alias, or "auto" to clear
            duration_minutes: 0 = permanent, >0 = temporary
        
        Returns:
            (model, provider, message)
        """
        if model_spec.lower() == "auto":
            self._overrides.pop(user_id, None)
            return ("", "", "🔄 Model routing reset to auto.")
        
        # Resolve alias
        model, provider = self._resolve_model(model_spec)
        
        override = self._overrides.get(user_id) or ModelOverride()
        override.model = model
        override.provider = provider
        override.set_at = time.time()
        override.set_by = user_id
        override.last_thinking_warning = ""
        override.last_thinking_warning_at = 0.0
        
        if duration_minutes > 0:
            override.expires_at = time.time() + (duration_minutes * 60)
        else:
            override.expires_at = 0.0
        
        self._overrides[user_id] = override
        
        # Cost info
        cost_info = ""
        if model in MODEL_COSTS:
            in_cost, out_cost = MODEL_COSTS[model]
            cost_info = f" (${in_cost:.2f}/${out_cost:.2f} per 1M tokens)"
        
        duration_str = ""
        if duration_minutes > 0:
            duration_str = f" for {duration_minutes}m"

        support = self.get_thinking_support(user_id, provider=provider, model=model)
        thinking_note = ""
        if support.requested_level != "off":
            if support.supported:
                thinking_note = f"\n🧠 Thinking stays **{support.requested_level}** via {support.mechanism}."
            else:
                thinking_note = f"\n⚠️ Thinking is set to **{support.requested_level}**, but `{model}` via {provider} does not support it. Responses will run without provider-side thinking until you switch models or set `!thinking off`."
        
        return (model, provider, f"✅ Model set to `{model}` via {provider}{duration_str}{cost_info}{thinking_note}")

    def set_thinking(self, user_id: str, level: str) -> str:
        """Set thinking/reasoning level for a user.
        
        Returns confirmation message.
        """
        level = level.lower()
        if level not in ThinkingLevel.VALID_LEVELS:
            valid = ", ".join(sorted(ThinkingLevel.VALID_LEVELS))
            return f"Invalid thinking level. Valid: {valid}"
        
        override = self._overrides.get(user_id)
        if not override:
            override = ModelOverride(set_at=time.time(), set_by=user_id)
            self._overrides[user_id] = override
        
        override.thinking_level = level
        override.thinking_budget = ThinkingLevel.BUDGETS.get(level, 0)
        override.last_thinking_warning = ""
        override.last_thinking_warning_at = 0.0
        
        if level == "off":
            return "🧠 Thinking: off (standard responses)"

        support = self.get_thinking_support(user_id)
        budget = override.thinking_budget
        if support.supported:
            if support.model and support.provider:
                return (
                    f"🧠 Thinking: **{level}** (budget: {budget:,} tokens)\n"
                    f"✅ Active on `{support.model}` via {support.provider} using {support.mechanism}."
                )
            return f"🧠 Thinking: **{level}** (budget: {budget:,} tokens)"

        if support.model and support.provider:
            return (
                f"🧠 Thinking: **{level}** (budget: {budget:,} tokens)\n"
                f"⚠️ Current model `{support.model}` via {support.provider} does not support provider-side thinking."
            )
        return (
            f"🧠 Thinking: **{level}** (budget: {budget:,} tokens)\n"
            f"ℹ️ It will apply when you use a thinking-capable model."
        )

    def get_override(self, user_id: str) -> Optional[ModelOverride]:
        """Get the active model override for a user (or None)."""
        override = self._overrides.get(user_id)
        if override:
            # Check expiry
            if override.expires_at > 0 and time.time() > override.expires_at:
                del self._overrides[user_id]
                return None
        
        # Fall back to global override
        if not override and self._global_override:
            return self._global_override
        
        return override

    def get_model_for_user(self, user_id: str) -> Optional[str]:
        """Get the model name override for a user, or None for default."""
        override = self.get_override(user_id)
        return override.model if override and override.model else None

    def get_thinking_for_user(self, user_id: str) -> tuple[str, int]:
        """Get thinking level and budget for a user.
        
        Returns (level, budget_tokens).
        """
        override = self.get_override(user_id)
        if override:
            return (override.thinking_level, override.thinking_budget)
        return (self._default_thinking, ThinkingLevel.BUDGETS.get(self._default_thinking, 0))

    def set_global(self, model_spec: str) -> str:
        """Set a global model override (affects all users without personal overrides)."""
        if model_spec.lower() == "auto":
            self._global_override = None
            return "🌐 Global model override cleared."
        
        model, provider = self._resolve_model(model_spec)
        self._global_override = ModelOverride(
            model=model,
            provider=provider,
            set_at=time.time(),
            set_by="global",
        )
        return f"🌐 Global model set to `{model}` via {provider}"

    def status_text(self, user_id: str = "") -> str:
        """Generate status text for model control."""
        lines = ["**🎛️ Model Control:**"]
        
        if self._global_override:
            lines.append(f"🌐 Global: `{self._global_override.model}` via {self._global_override.provider}")
        
        if user_id:
            override = self.get_override(user_id)
            if override and override.model:
                expiry = ""
                if override.expires_at > 0:
                    remaining = int(override.expires_at - time.time())
                    if remaining > 0:
                        expiry = f" (expires in {remaining // 60}m)"
                lines.append(f"Your model: `{override.model}` via {override.provider}{expiry}")
            else:
                lines.append("Your model: auto (using router/default)")

            thinking_level, thinking_budget = self.get_thinking_for_user(user_id)
            support = self.get_thinking_support(user_id)
            if thinking_level == "off":
                lines.append("Thinking: off")
            else:
                status_icon = "✅" if support.supported else "⚠️"
                target = f" on `{support.model}` via {support.provider}" if support.model and support.provider else ""
                mech = f" ({support.mechanism})" if support.supported and support.mechanism else ""
                lines.append(
                    f"Thinking: {status_icon} {thinking_level} ({thinking_budget:,} tokens){target}{mech}"
                )
                if support.warning:
                    lines.append(f"  {support.warning}")
        
        total_overrides = len(self._overrides)
        if total_overrides > 0:
            lines.append(f"\nActive overrides: {total_overrides}")
        
        lines.append("\n**Aliases:** " + ", ".join(f"`{a}`" for a in sorted(MODEL_ALIASES.keys())))
        
        return "\n".join(lines)

    def get_thinking_support(
        self,
        user_id: str,
        provider: str = "",
        model: str = "",
    ) -> ThinkingSupportStatus:
        """Return whether the current/requested provider+model supports thinking."""
        level, budget = self.get_thinking_for_user(user_id)
        if level == "off" or budget <= 0:
            return ThinkingSupportStatus(
                requested_level=level,
                requested_budget=budget,
                supported=False,
                provider=provider,
                model=model,
            )

        if not provider or not model:
            override = self.get_override(user_id)
            if override:
                provider = provider or override.provider
                model = model or override.model

        provider = (provider or "").strip().lower()
        model = (model or "").strip()
        support = PROVIDER_THINKING_SUPPORT.get(provider)
        if not support:
            warning = (
                f"⚠️ Thinking level `{level}` is set, but provider `{provider or 'unknown'}` "
                f"has no registered thinking support metadata."
            )
            return ThinkingSupportStatus(
                requested_level=level,
                requested_budget=budget,
                supported=False,
                provider=provider,
                model=model,
                warning=warning,
            )

        mode = support.get("mode")
        if mode == "provider":
            return ThinkingSupportStatus(
                requested_level=level,
                requested_budget=budget,
                supported=True,
                provider=provider,
                model=model,
                mechanism=support.get("label", provider),
            )

        if mode == "model-list":
            ok = model in support.get("models", set())
        elif mode == "prefix":
            ok = any(model.startswith(prefix) for prefix in support.get("prefixes", ()))
        else:
            ok = False

        if ok:
            return ThinkingSupportStatus(
                requested_level=level,
                requested_budget=budget,
                supported=True,
                provider=provider,
                model=model,
                mechanism=support.get("label", provider),
            )

        warning = (
            f"⚠️ Thinking level `{level}` was requested, but `{model}` via {provider} does not support it."
        )
        return ThinkingSupportStatus(
            requested_level=level,
            requested_budget=budget,
            supported=False,
            provider=provider,
            model=model,
            warning=warning,
        )

    def note_thinking_warning(
        self,
        user_id: str,
        warning: str,
        provider: str = "",
        model: str = "",
    ) -> bool:
        """Record a thinking warning and de-dup repeated identical warnings.

        Returns True if this warning is new enough to surface to the user.
        """
        override = self._overrides.get(user_id)
        if not override:
            override = ModelOverride(set_at=time.time(), set_by=user_id)
            self._overrides[user_id] = override

        now = time.time()
        if override.last_thinking_warning == warning and (now - override.last_thinking_warning_at) < 300:
            return False

        override.last_thinking_warning = warning
        override.last_thinking_warning_at = now
        if provider:
            override.provider = provider
        if model:
            override.model = model
        return True

    def _resolve_model(self, spec: str) -> tuple[str, str]:
        """Resolve a model spec (name or alias) to (model, provider)."""
        spec_lower = spec.lower()
        if spec_lower in MODEL_ALIASES:
            return MODEL_ALIASES[spec_lower]
        
        # Try to infer provider from model name
        provider = "anthropic"  # default
        if "gpt" in spec_lower or "o3" in spec_lower or "o4" in spec_lower or spec_lower.startswith("o1"):
            provider = "openai"
        elif "gemini" in spec_lower:
            provider = "google"
        elif "qwen" in spec_lower or "llama" in spec_lower or ":" in spec:
            provider = "ollama"
        elif "claude" in spec_lower:
            provider = "anthropic"
        
        return (spec, provider)


class ModelControlExtension(Extension):
    """Extension that registers model control commands.
    
    Commands:
        !model <name>           — switch model
        !model auto             — reset to auto
        !model <name> 30m       — switch for 30 minutes
        !thinking <level>       — set thinking level
        !thinking off           — disable thinking
        !models                 — list available models
    """

    name = "model-control"
    version = "1.0.0"
    description = "Runtime model switching and thinking levels"

    def __init__(self):
        self._controller: Optional[ModelController] = None

    async def on_load(self, ctx: ExtensionContext) -> None:
        self._controller = ModelController()
        
        # Set default thinking from config
        default_thinking = ctx.config.get("default_thinking", "off")
        self._controller._default_thinking = default_thinking
        
        # Register commands
        ctx.register_command("thinking", self._cmd_thinking)
        ctx.register_command("models", self._cmd_models)

    def _cmd_thinking(self, user_id: str, args: str) -> str:
        """Handle !thinking command."""
        if not self._controller:
            return "Model control not initialized."
        
        if not args.strip():
            level, budget = self._controller.get_thinking_for_user(user_id)
            if level == "off":
                return "🧠 Thinking: off\nSet with: `!thinking low|medium|high|max`"
            support = self._controller.get_thinking_support(user_id)
            if support.supported:
                return (
                    f"🧠 Thinking: **{level}** (budget: {budget:,} tokens)\n"
                    f"✅ Active on `{support.model}` via {support.provider}."
                )
            if support.model and support.provider:
                return (
                    f"🧠 Thinking: **{level}** (budget: {budget:,} tokens)\n"
                    f"⚠️ Current model `{support.model}` via {support.provider} does not support it."
                )
            return f"🧠 Thinking: **{level}** (budget: {budget:,} tokens)"
        
        return self._controller.set_thinking(user_id, args.strip())

    def _cmd_models(self, user_id: str, args: str) -> str:
        """Handle !models command."""
        lines = ["**Available Models:**\n"]
        
        # Group by provider
        providers: Dict[str, List[str]] = {}
        for alias, (model, provider) in sorted(MODEL_ALIASES.items()):
            if provider not in providers:
                providers[provider] = []
            cost_info = ""
            if model in MODEL_COSTS:
                in_c, out_c = MODEL_COSTS[model]
                cost_info = f" (${in_c}/{out_c})"
            think_support = self._controller.get_thinking_support(user_id, provider=provider, model=model) if self._controller else None
            think_info = " • thinking" if think_support and think_support.supported else ""
            entry = f"`{alias}` → {model}{cost_info}{think_info}"
            if entry not in providers[provider]:
                providers[provider].append(entry)
        
        for provider, entries in providers.items():
            lines.append(f"**{provider.title()}:**")
            for entry in entries:
                lines.append(f"  {entry}")
            lines.append("")
        
        lines.append("**Thinking Levels:** `!thinking off|low|medium|high|max`")
        lines.append("Tip: switch model and thinking together, e.g. `!model o3` then `!thinking high`")
        
        return "\n".join(lines)
