"""Proactive memory surfacing - notes facts and surfaces them at relevant times."""
import json
import logging
import re
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

# Patterns that indicate something worth noting
NOTE_PATTERNS = [
    (r"(?:i have|i've got|there's) (?:a |an )?(\w+ )?(?:meeting|appointment|call|interview|deadline|event)", "event"),
    (r"(?:i need to|i have to|i should|i must|remind me to|don't let me forget) (.+)", "task"),
    (r"(?:tomorrow|tonight|this evening|this afternoon|next week|on monday|on tuesday|on wednesday|on thursday|on friday|on saturday|on sunday)", "temporal"),
    (r"(?:my (?:favorite|favourite) .+ is|i (?:love|hate|prefer|like|dislike) )", "preference"),
    (r"(?:i'm going to|i'll be|i plan to|planning to) (.+)", "plan"),
]

# Greetings that trigger proactive surfacing
GREETING_PATTERNS = [
    r"(?:good morning|morning|hey|hi|hello|what's up|sup|howdy|yo)",
    r"(?:i'm back|back again|here again)",
]


class ProactiveMemory:
    """Passively notes facts and surfaces them at relevant times."""

    def __init__(self, store_dir: str | Path):
        self.store_dir = Path(store_dir)
        self.store_dir.mkdir(parents=True, exist_ok=True)

    def scan_and_note(self, user_id: str, text: str) -> list[str]:
        """Scan a message for notable facts. Returns list of what was noted."""
        noted = []
        text_lower = text.lower()

        for pattern, category in NOTE_PATTERNS:
            if re.search(pattern, text_lower):
                # Determine if there's a temporal component
                surface_after = self._extract_temporal(text_lower)
                note = {
                    "text": text[:200],
                    "category": category,
                    "created": datetime.now(timezone.utc).isoformat(),
                    "surface_after": surface_after or "",
                    "surfaced": False,
                }
                notes = self._load(user_id)
                notes.append(note)
                self._save(user_id, notes)
                noted.append(f"{category}: {text[:80]}")
                break  # one note per message

        return noted

    def get_surfaces(self, user_id: str, text: str = "") -> list[str]:
        """Get notes that should be surfaced now. Marks them as surfaced."""
        # Only surface on greetings or reconnect
        is_greeting = any(re.search(p, text.lower()) for p in GREETING_PATTERNS)
        if not is_greeting and text:
            return []

        notes = self._load(user_id)
        now = datetime.now(timezone.utc)
        surfaces = []

        for note in notes:
            if note.get("surfaced"):
                continue
            surface_after = note.get("surface_after", "")
            if surface_after:
                try:
                    target = datetime.fromisoformat(surface_after)
                    if now < target:
                        continue
                except (ValueError, TypeError):
                    pass

            surfaces.append(note["text"])
            note["surfaced"] = True

        if surfaces:
            self._save(user_id, notes)

        return surfaces

    def get_context(self, user_id: str, text: str = "") -> str:
        """Build context for system prompt with proactive surfaces."""
        surfaces = self.get_surfaces(user_id, text)
        if not surfaces:
            return ""
        lines = ["## Proactive Reminders (things the user mentioned earlier):"]
        for s in surfaces:
            lines.append(f"- {s}")
        lines.append("\nMention these naturally in your response if relevant.")
        return "\n".join(lines)

    def _extract_temporal(self, text: str) -> str:
        """Extract temporal reference and convert to ISO timestamp."""
        now = datetime.now(timezone.utc)
        if "tomorrow" in text:
            target = now + timedelta(days=1)
            return target.replace(hour=7, minute=0, second=0).isoformat()
        if "tonight" in text or "this evening" in text:
            return now.replace(hour=18, minute=0, second=0).isoformat()
        if "next week" in text:
            target = now + timedelta(weeks=1)
            return target.replace(hour=9, minute=0, second=0).isoformat()
        return ""

    def _load(self, user_id: str) -> list[dict]:
        path = self.store_dir / f"{user_id}.json"
        if path.exists():
            try:
                data = json.loads(path.read_text())
                # Keep only unsurfaced notes and notes from last 7 days
                cutoff = (datetime.now(timezone.utc) - timedelta(days=7)).isoformat()
                return [n for n in data if not n.get("surfaced") or n.get("created", "") > cutoff]
            except Exception:
                return []
        return []

    def _save(self, user_id: str, notes: list[dict]):
        path = self.store_dir / f"{user_id}.json"
        path.write_text(json.dumps(notes, indent=2))
