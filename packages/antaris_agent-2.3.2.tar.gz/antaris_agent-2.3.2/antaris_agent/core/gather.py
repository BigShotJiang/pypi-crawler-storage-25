"""Antaris Agent /gather command — sync Discord channel history into memory."""

import logging
from datetime import datetime, timedelta, timezone
from typing import Optional

from antaris_agent.llm.base import Message

logger = logging.getLogger(__name__)

VALID_HOURS = [3, 6, 12, 18, 24, 48]


async def gather_channel_history(
    client,  # discord.Client
    channel_ids: list[str],
    hours: int = 12,
    max_messages_per_channel: int = 500,
) -> list[dict]:
    """Read recent messages from Discord channels.

    Returns list of {channel_name, channel_id, messages: [{author, content, timestamp}]}
    """
    if hours not in VALID_HOURS:
        hours = 12

    cutoff = datetime.now(timezone.utc) - timedelta(hours=hours)
    results = []

    logger.info("gather: scanning %d channel IDs: %s", len(channel_ids), channel_ids)
    for cid in channel_ids:
        try:
            int_cid = int(cid)
            channel = client.get_channel(int_cid)
            logger.info("gather: channel %s → %s", cid, channel)
            if not channel:
                logger.warning("gather: channel %s (int=%d) not found in cache", cid, int_cid)
                continue

            messages = []
            async for msg in channel.history(limit=max_messages_per_channel, after=cutoff):
                if msg.author.bot:
                    continue  # skip bot messages to avoid noise
                messages.append({
                    "author": msg.author.display_name,
                    "content": msg.content[:500] if msg.content else "",
                    "timestamp": msg.created_at.isoformat(),
                })

            if messages:
                messages.reverse()  # chronological order
                results.append({
                    "channel_name": getattr(channel, 'name', str(cid)),
                    "channel_id": cid,
                    "messages": messages,
                    "count": len(messages),
                })
                logger.info("gather: #%s — %d messages in last %dh",
                            channel.name, len(messages), hours)
        except Exception as e:
            logger.warning("gather: error reading channel %s: %s", cid, e)

    return results


def summarize_channel(channel_data: dict) -> str:
    """Create a text summary of channel activity for memory ingestion.

    Simple approach: concatenate messages with attribution.
    The LLM will naturally summarize when it processes these as memories.
    """
    name = channel_data["channel_name"]
    messages = channel_data["messages"]
    count = channel_data["count"]

    if not messages:
        return ""

    # Build a readable summary
    lines = [f"[Channel sync: #{name}, {count} messages]"]
    for msg in messages[:50]:  # cap at 50 messages per summary
        author = msg["author"]
        content = msg["content"][:200]
        if content:
            lines.append(f"{author}: {content}")

    return "\n".join(lines)


async def smart_summarize_channel(channel_data: dict, llm) -> str:
    """Use the LLM to produce a 2-4 sentence briefing of channel activity.

    Falls back to summarize_channel() if the LLM call fails.
    """
    name = channel_data["channel_name"]
    raw = summarize_channel(channel_data)
    if not raw:
        return raw

    system_prompt = (
        "You are a concise summarizer for a Discord bot. "
        "Produce exactly 2-4 sentences. No bullet points, no headers. "
        "Be specific about WHO said WHAT. "
        "Focus on: decisions made, questions asked, work completed, and anything that needs follow-up."
    )
    user_prompt = (
        f"Summarize the following Discord channel activity in 2-4 concise sentences. "
        f"Channel: #{name}\n\n{raw}"
    )

    try:
        response = await llm.complete(
            messages=[Message(role="user", content=user_prompt)],
            system=system_prompt,
            max_tokens=256,
            temperature=0.3,
        )
        return response.content.strip()
    except Exception as exc:
        logger.warning("gather: smart_summarize_channel failed for #%s, falling back: %s", name, exc)
        return raw


async def gather_and_ingest(
    client,       # discord.Client
    memory,       # BotMemory
    llm,          # LLMProvider (for summarization)
    channel_ids: list[str],
    hours: int = 12,
    user_id: str = "system",
) -> dict:
    """Full gather pipeline: read channels → summarize → ingest into memory.

    Returns: {channels_synced, channels_total, total_messages, errors}
    """
    results = await gather_channel_history(client, channel_ids, hours)

    synced = 0
    total_messages = 0
    errors = []
    channel_summaries: list[dict] = []

    for channel_data in results:
        try:
            if llm is not None:
                summary = await smart_summarize_channel(channel_data, llm)
            else:
                summary = summarize_channel(channel_data)
            if not summary:
                continue

            # Ingest as a system-level memory (not tied to a specific user conversation)
            await memory.ingest(
                user_id=user_id,
                user_message=f"[gather #{channel_data['channel_name']}]",
                bot_response=summary,
            )

            channel_summaries.append({
                "channel_name": channel_data["channel_name"],
                "summary": summary,
                "count": channel_data["count"],
            })
            synced += 1
            total_messages += channel_data["count"]
            logger.info("gather: ingested #%s (%d messages)",
                        channel_data["channel_name"], channel_data["count"])
        except Exception as e:
            errors.append(f"#{channel_data['channel_name']}: {e}")
            logger.warning("gather: ingest error for #%s: %s",
                           channel_data["channel_name"], e)

    return {
        "channels_synced": synced,
        "channels_total": len(channel_ids),
        "total_messages": total_messages,
        "errors": errors,
        "channel_summaries": channel_summaries,
    }
