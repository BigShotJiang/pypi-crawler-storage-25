"""
Antaris Agent — Self-update and version check.

Usage:
    updater = Updater()
    msg = updater.check_and_notify()
    if msg:
        print(msg)
"""

import os
import subprocess
import sys
import urllib.request
import urllib.error
import json
import logging
from importlib.metadata import version as pkg_version, PackageNotFoundError

logger = logging.getLogger(__name__)

PACKAGE_NAME = "antaris-agent"


def _version_gt(a: str, b: str) -> bool:
    """Return True if version string a is greater than b.

    Uses packaging.version if available; falls back to naive tuple comparison.
    """
    try:
        from packaging.version import parse as vparse
        return vparse(a) > vparse(b)
    except ImportError:
        pass
    # Naive: split on '.' and compare integer tuples
    def _parts(v: str):
        parts = []
        for seg in v.split("."):
            # strip pre-release suffixes like 'a1', 'b2', 'rc1'
            digits = ""
            for ch in seg:
                if ch.isdigit():
                    digits += ch
                else:
                    break
            parts.append(int(digits) if digits else 0)
        return parts

    def _pad(lst, length):
        return lst + [0] * (length - len(lst))

    pa, pb = _parts(a), _parts(b)
    length = max(len(pa), len(pb))
    return _pad(pa, length) > _pad(pb, length)


class Updater:
    """Handles version checking and self-update for Antaris Agent."""

    PYPI_URL = "https://pypi.org/pypi/antaris-agent/json"

    # ── Version helpers ───────────────────────────────────────────────────

    def get_installed_version(self) -> str:
        """Return the installed package version string.

        Falls back to '0.0.0' if the package metadata is unavailable
        (e.g. running from an editable install without metadata).
        """
        try:
            return pkg_version(PACKAGE_NAME)
        except PackageNotFoundError:
            # editable / dev install — read from pyproject.toml or default
            return self._read_version_from_source()

    def _read_version_from_source(self) -> str:
        """Try to read version from the canonical _version.py source.

        Falls back through pyproject.toml static version (legacy) and
        then the CLI VERSION constant.
        """
        # 1. Canonical source: antaris_agent._version
        try:
            from antaris_agent._version import __version__
            return __version__
        except Exception:
            pass

        # 2. Legacy fallback: static version in pyproject.toml
        try:
            import tomllib  # Python 3.11+
        except ImportError:
            try:
                import tomli as tomllib  # type: ignore
            except ImportError:
                tomllib = None  # type: ignore

        if tomllib is not None:
            pyproject = self._find_pyproject()
            if pyproject:
                try:
                    with open(pyproject, "rb") as f:
                        data = tomllib.load(f)
                    ver = data.get("project", {}).get("version")
                    if ver:
                        return ver
                except Exception:
                    pass

        # 3. Last resort: try the cli VERSION constant
        try:
            from antaris_agent.cli import VERSION  # type: ignore
            return VERSION
        except Exception:
            return "0.0.0"

    def _find_pyproject(self):
        """Walk up from this file to find pyproject.toml."""
        current = os.path.dirname(os.path.abspath(__file__))
        for _ in range(5):
            candidate = os.path.join(current, "pyproject.toml")
            if os.path.exists(candidate):
                return candidate
            parent = os.path.dirname(current)
            if parent == current:
                break
            current = parent
        return None

    def get_latest_version(self) -> str | None:
        """Fetch the latest version from PyPI.

        Returns None on any network or parse error (non-fatal).
        """
        try:
            req = urllib.request.Request(
                self.PYPI_URL,
                headers={"User-Agent": f"antaris-agent-updater/{self.get_installed_version()}"},
            )
            with urllib.request.urlopen(req, timeout=5) as resp:
                data = json.loads(resp.read().decode("utf-8"))
            return data["info"]["version"]
        except (urllib.error.URLError, KeyError, ValueError, OSError) as exc:
            logger.debug("Could not fetch latest version from PyPI: %s", exc)
            return None

    def is_update_available(self) -> tuple[bool, str, str]:
        """Check whether a newer version exists on PyPI.

        Returns:
            (available, installed_version, latest_version)

        If the latest version cannot be determined, returns
        (False, installed, installed) so callers can always unpack safely.
        """
        installed = self.get_installed_version()
        latest = self.get_latest_version()
        if latest is None:
            return False, installed, installed
        available = _version_gt(latest, installed)
        return available, installed, latest

    # ── Notification ──────────────────────────────────────────────────────

    def check_and_notify(self) -> str | None:
        """Return a human-readable update notification, or None if up to date."""
        available, installed, latest = self.is_update_available()
        if not available:
            return None
        return (
            f"⬆️  Antaris Agent v{latest} is available (you have v{installed}). "
            f"Run `antaris update` to upgrade."
        )

    # ── Self-update ───────────────────────────────────────────────────────

    def update(self, restart: bool = False) -> bool:
        """Install the latest version from PyPI via pip3.

        Args:
            restart: If True and the update succeeds, replace the current
                     process with a fresh one via os.execv.

        Returns:
            True if pip exited with code 0, False otherwise.
        """
        print(f"📦 Running: pip3 install --upgrade {PACKAGE_NAME} --break-system-packages")
        result = subprocess.run(
            ["pip3", "install", "--upgrade", PACKAGE_NAME, "--break-system-packages"],
            capture_output=False,  # let output stream to terminal
        )
        success = result.returncode == 0
        if success and restart:
            print("🔄 Restarting…")
            os.execv(sys.executable, [sys.executable] + sys.argv)
        return success
