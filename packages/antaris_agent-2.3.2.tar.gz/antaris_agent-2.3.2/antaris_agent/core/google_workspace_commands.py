from __future__ import annotations

from typing import Any, Optional


class GoogleWorkspaceCommandMixin:
    """Chat-friendly command handlers for Google Workspace workflows."""

    async def _cmd_gmail(self, inbound, args: str) -> str:
        args = (args or "").strip()
        if not args:
            return (
                "**!gmail**\n"
                "- `!gmail search <query>`\n"
                "- `!gmail read <message_id>`\n"
                "- `!gmail draft to=<email> | subject=<subject> | body=<body> [| cc=<email>] [| bcc=<email>]`\n"
                "- `!gmail send to=<email> | subject=<subject> | body=<body> [| cc=<email>] [| bcc=<email>]`\n"
                "Default policy: draft-first. `!gmail send` requires explicit send intent."
            )

        action, _, remainder = args.partition(" ")
        action = action.lower().strip()
        remainder = remainder.strip()

        if action == "search":
            if not remainder:
                return "Usage: `!gmail search <query>`"
            return await self._invoke_tool("gmail_search", {"query": remainder, "max_results": 10})

        if action == "read":
            if not remainder:
                return "Usage: `!gmail read <message_id>`"
            return await self._invoke_tool("gmail_read", {"message_id": remainder})

        if action in {"draft", "send"}:
            fields = self._parse_pipe_fields(remainder)
            missing = [key for key in ("to", "subject", "body") if not fields.get(key)]
            if missing:
                return "Usage: `!gmail %s to=<email> | subject=<subject> | body=<body> [| cc=<email>] [| bcc=<email>]`" % action
            payload: dict[str, Any] = {
                "to": fields["to"],
                "subject": fields["subject"],
                "body": fields["body"],
            }
            if fields.get("cc"):
                payload["cc"] = fields["cc"]
            if fields.get("bcc"):
                payload["bcc"] = fields["bcc"]
            if action == "draft":
                return await self._invoke_tool("gmail_draft", payload)
            payload.update({"send": True, "confirm_send": True, "mode": "send"})
            return await self._invoke_tool("gmail_send", payload)

        return "Unknown !gmail action. Try `search`, `read`, `draft`, or `send`."

    async def _cmd_calendar(self, inbound, args: str) -> str:
        args = (args or "").strip()
        if not args:
            return (
                "**!calendar**\n"
                "- `!calendar list from=<iso> | to=<iso> [| calendar=primary]`\n"
                "- `!calendar create title=<title> | start=<iso> | end=<iso> [| location=<text>] [| description=<text>]`\n"
                "Calendar writes are confirmation-gated."
            )

        action, _, remainder = args.partition(" ")
        action = action.lower().strip()
        remainder = remainder.strip()

        if action == "list":
            fields = self._parse_pipe_fields(remainder)
            time_min = fields.get("from") or fields.get("start")
            time_max = fields.get("to") or fields.get("end")
            if not time_min or not time_max:
                return "Usage: `!calendar list from=<iso> | to=<iso> [| calendar=primary]`"
            payload = {
                "time_min": time_min,
                "time_max": time_max,
                "calendar_id": fields.get("calendar", "primary"),
            }
            return await self._invoke_tool("calendar_list_events", payload)

        if action == "create":
            fields = self._parse_pipe_fields(remainder)
            title = fields.get("title")
            start = fields.get("start")
            end = fields.get("end")
            if not title or not start or not end:
                return "Usage: `!calendar create title=<title> | start=<iso> | end=<iso> [| location=<text>] [| description=<text>]`"
            payload: dict[str, Any] = {
                "title": title,
                "start": start,
                "end": end,
                "calendar_id": fields.get("calendar", "primary"),
                "confirmed": False,
            }
            if fields.get("location"):
                payload["location"] = fields["location"]
            if fields.get("description"):
                payload["description"] = fields["description"]
            return await self._invoke_tool("calendar_create_event", payload)

        return "Unknown !calendar action. Try `list` or `create`."

    async def _cmd_drive(self, inbound, args: str) -> str:
        args = (args or "").strip()
        if not args:
            return (
                "**!drive**\n"
                "- `!drive search <query>`\n"
                "- `!drive read <file_id>`"
            )

        action, _, remainder = args.partition(" ")
        action = action.lower().strip()
        remainder = remainder.strip()

        if action == "search":
            if not remainder:
                return "Usage: `!drive search <query>`"
            return await self._invoke_tool("drive_search", {"query": remainder, "max_results": 10})

        if action == "read":
            if not remainder:
                return "Usage: `!drive read <file_id>`"
            return await self._invoke_tool("drive_read", {"file_id": remainder})

        return "Unknown !drive action. Try `search` or `read`."

    def _parse_pipe_fields(self, text: str) -> dict[str, str]:
        fields: dict[str, str] = {}
        for segment in (text or "").split("|"):
            piece = segment.strip()
            if not piece or "=" not in piece:
                continue
            key, value = piece.split("=", 1)
            key = key.strip().lower()
            value = value.strip()
            if key:
                fields[key] = value
        return fields

    async def _invoke_tool(self, tool_name: str, arguments: dict[str, Any]) -> str:
        registry = getattr(self.bot, "tool_registry", None)
        if not registry:
            return "Tool registry unavailable."
        tool = getattr(registry, "_native_tools", {}).get(tool_name)
        if not tool:
            return f"Tool `{tool_name}` is not enabled."
        try:
            result = await tool.execute(arguments)
        except Exception as exc:
            return f"`{tool_name}` failed: {exc}"
        if getattr(result, "success", False):
            return result.content or f"`{tool_name}` completed."
        return result.error or result.content or f"`{tool_name}` failed."
