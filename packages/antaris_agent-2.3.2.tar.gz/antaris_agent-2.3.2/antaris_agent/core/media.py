"""Shared image/screenshot context helpers for the pipeline.

This module turns raw inbound image metadata into:
- a normalized media summary for prompt injection
- a screenshot-aware UX guidance block
- provider-safe content block helpers

Goal: make image understanding feel first-class even when the selected model
is not fully multimodal, while still letting multimodal providers receive the
actual image bytes.
"""

from __future__ import annotations

from typing import Any, Dict, List, Tuple

_SCREENSHOT_HINTS = (
    "screenshot",
    "screen shot",
    "screen",
    "ui",
    "browser",
    "app",
    "window",
    "dialog",
    "error",
    "popup",
    "modal",
    "dashboard",
    "settings",
    "page",
    "desktop",
)


def classify_image_kind(inbound_text: str, images: List[Dict[str, Any]]) -> str:
    """Infer whether the attached images are likely screenshots or general images."""
    text = (inbound_text or "").lower()
    if any(hint in text for hint in _SCREENSHOT_HINTS):
        return "screenshot"

    # Heuristic fallback from filenames / metadata if available.
    for img in images or []:
        name = str(img.get("filename", "")).lower()
        if any(hint in name for hint in ("screen", "screenshot", "capture", "window")):
            return "screenshot"

    return "image"


def build_media_context(inbound_text: str, images: List[Dict[str, Any]] | None = None) -> Tuple[str, Dict[str, Any]]:
    """Build a prompt-safe media context block and summary metadata."""
    images = images or []
    if not images:
        return "", {"has_images": False, "image_count": 0, "image_kind": None}

    image_kind = classify_image_kind(inbound_text, images)
    lines = [f"[Visual input attached: {len(images)} {image_kind}{'s' if len(images) != 1 else ''}]" ]

    if image_kind == "screenshot":
        lines.extend([
            "Treat the image as a UI/app/browser screenshot unless the pixels clearly show otherwise.",
            "Prioritize: what screen this is, visible errors or warnings, key UI state, actionable next steps, and OCR of important text.",
            "If asked 'what am I looking at?', answer in plain product/UI terms first.",
        ])
    else:
        lines.extend([
            "Treat the image as a general visual input.",
            "Prioritize: main subjects, notable text, scene/object relationships, and direct answers to the user's question.",
        ])

    lines.append("If text is visible, extract the most important words exactly when possible.")

    return "\n".join(lines), {
        "has_images": True,
        "image_count": len(images),
        "image_kind": image_kind,
    }


def build_screenshot_response_hint() -> str:
    """Specialized UX guidance for screenshot analysis responses."""
    return (
        "When responding to screenshots, prefer this structure when relevant: "
        "(1) what screen/app this appears to be, "
        "(2) important UI state or changes, "
        "(3) errors/warnings/notices, "
        "(4) important visible text/OCR, "
        "(5) concise next step or explanation."
    )


def build_provider_text_fallback(inbound_text: str, images: List[Dict[str, Any]] | None = None) -> str:
    """Append media-aware fallback context into plain-text user content."""
    context, _summary = build_media_context(inbound_text, images)
    if not context:
        return inbound_text
    if inbound_text.strip():
        return f"{inbound_text.strip()}\n\n---\n{context}"
    return context
