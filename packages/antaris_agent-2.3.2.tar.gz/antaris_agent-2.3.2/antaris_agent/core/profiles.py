"""
Antaris Agent User Profiles — persistent per-user context beyond raw memories.

Stored at: ~/.antaris/profiles/<user_id>.json

Fields:
    user_id            — Discord/Telegram user ID
    display_name       — human name (learned over time)
    preferences        — dict of user preferences
    notes              — list of notable facts about this user
    conversation_style — "casual" | "technical" | "brief"
    last_seen          — ISO timestamp
    message_count      — total messages processed
"""
import json
import logging
import time
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


@dataclass
class UserProfile:
    user_id: str
    display_name: str = ""
    preferences: dict = field(default_factory=dict)
    notes: list = field(default_factory=list)
    conversation_style: str = "casual"
    last_seen: str = ""
    message_count: int = 0
    created_at: str = ""

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "UserProfile":
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})

    def touch(self, display_name: Optional[str] = None):
        """Update last_seen timestamp and optionally refresh display name."""
        self.last_seen = datetime.now(timezone.utc).isoformat()
        self.message_count += 1
        if display_name and display_name != self.display_name:
            logger.info(
                "UserProfile.touch: updating display_name for user_id=%s to %s",
                self.user_id,
                display_name,
            )
            self.display_name = display_name

    def add_note(self, note: str):
        """Add a fact about this user (no duplicates)."""
        if note not in self.notes:
            self.notes.append(note)
            if len(self.notes) > 50:  # cap at 50 notes
                self.notes = self.notes[-50:]

    def to_context_string(self) -> Optional[str]:
        """Return a short context string for injection into system prompt."""
        if not self.display_name and not self.notes:
            return None
        parts = []
        if self.display_name:
            parts.append(f"Name: {self.display_name}")
        if self.conversation_style != "casual":
            parts.append(f"Style: {self.conversation_style}")
        if self.notes:
            parts.append(f"Notes: {'; '.join(self.notes[:5])}")
        return " | ".join(parts) if parts else None


class ProfileManager:
    """Loads, saves, and manages per-user profiles."""

    def __init__(self, profiles_dir: str | Path):
        self.profiles_dir = Path(profiles_dir)
        self.profiles_dir.mkdir(parents=True, exist_ok=True)
        self._cache: dict[str, UserProfile] = {}

    def _path(self, user_id: str) -> Path:
        safe_id = "".join(c for c in str(user_id) if c.isalnum() or c in "-_")
        return self.profiles_dir / f"{safe_id}.json"

    def get(self, user_id: str) -> UserProfile:
        """Get profile for user, creating if needed."""
        if user_id in self._cache:
            return self._cache[user_id]
        path = self._path(user_id)
        if path.exists():
            try:
                data = json.loads(path.read_text())
                profile = UserProfile.from_dict(data)
                self._cache[user_id] = profile
                return profile
            except Exception as e:
                logger.warning("ProfileManager: failed to load %s: %s", user_id, e)
        # Create new profile
        profile = UserProfile(
            user_id=user_id,
            created_at=datetime.now(timezone.utc).isoformat(),
        )
        self._cache[user_id] = profile
        return profile

    def save(self, profile: UserProfile):
        """Save a profile to disk."""
        path = self._path(profile.user_id)
        path.write_text(json.dumps(profile.to_dict(), indent=2))

    def touch(self, user_id: str, display_name: Optional[str] = None) -> UserProfile:
        """Touch a user's profile (update last_seen, increment message_count, optionally refresh display name)."""
        profile = self.get(user_id)
        profile.touch(display_name=display_name)
        if display_name:
            logger.debug(
                "ProfileManager.touch: touched profile for user_id=%s with display_name=%s",
                user_id,
                display_name,
            )
        self.save(profile)
        return profile

    def update_name(self, user_id: str, name: str):
        """Update display name."""
        profile = self.get(user_id)
        if name and name != profile.display_name:
            profile.display_name = name
            self.save(profile)

    def add_note(self, user_id: str, note: str):
        """Add a fact about this user."""
        profile = self.get(user_id)
        profile.add_note(note)
        self.save(profile)

    def get_context(self, user_id: str) -> Optional[str]:
        """Get context string for a user (for system prompt injection)."""
        profile = self.get(user_id)
        return profile.to_context_string()

    def list_profiles(self) -> list[UserProfile]:
        """List all known profiles."""
        profiles = []
        for path in self.profiles_dir.glob("*.json"):
            try:
                data = json.loads(path.read_text())
                profiles.append(UserProfile.from_dict(data))
            except Exception:
                pass
        return profiles
