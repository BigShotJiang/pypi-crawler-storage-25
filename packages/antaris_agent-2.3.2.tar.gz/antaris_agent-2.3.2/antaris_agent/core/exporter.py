"""Conversation export - generates clean markdown from memory."""
import logging
from datetime import datetime, timezone, timedelta
from pathlib import Path

logger = logging.getLogger(__name__)


class ConversationExporter:
    """Exports conversation history as formatted markdown."""

    def __init__(self, memory, export_dir: str | Path):
        self.memory = memory  # BotMemory instance
        self.export_dir = Path(export_dir)
        self.export_dir.mkdir(parents=True, exist_ok=True)

    def export_recent(self, user_id: str, days: int = 1) -> tuple[str, str]:
        """Export last N days of conversation. Returns (filepath, summary)."""
        query = "conversation today recent"
        results = self.memory.search_memories(user_id, query, limit=100)

        if not results:
            return "", "No conversations found."

        # Filter by date
        cutoff = datetime.now(timezone.utc) - timedelta(days=days)
        filtered = []
        for r in results:
            ts = r.get("timestamp")
            if ts:
                try:
                    entry_time = datetime.fromisoformat(str(ts))
                    # Make offset-naive timestamps timezone-aware for comparison
                    if entry_time.tzinfo is None:
                        entry_time = entry_time.replace(tzinfo=timezone.utc)
                    if entry_time < cutoff:
                        continue
                except (ValueError, TypeError):
                    pass
            filtered.append(r)

        if not filtered:
            filtered = results[:20]  # fallback: use top results

        period = "today" if days == 1 else f"last {days} days"
        md = self._format_markdown(filtered, f"Conversation Export - {period}")

        filename = f"export_{user_id}_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}.md"
        filepath = self.export_dir / filename
        filepath.write_text(md)

        return str(filepath), f"Exported {len(filtered)} entries to `{filename}`"

    def export_by_topic(self, user_id: str, topic: str) -> tuple[str, str]:
        """Export conversations matching a topic. Returns (filepath, summary)."""
        results = self.memory.search_memories(user_id, topic, limit=100)

        if not results:
            return "", f"No conversations found about '{topic}'."

        md = self._format_markdown(results, f"Conversation Export - Topic: {topic}")

        safe_topic = topic.replace(" ", "_")[:30]
        filename = f"export_{user_id}_{safe_topic}_{datetime.now(timezone.utc).strftime('%Y%m%d')}.md"
        filepath = self.export_dir / filename
        filepath.write_text(md)

        return str(filepath), f"Exported {len(results)} entries about '{topic}' to `{filename}`"

    def export_all(self, user_id: str) -> tuple[str, str]:
        """Export all conversations. Returns (filepath, summary)."""
        results = self.memory.search_memories(user_id, "", limit=10000)

        if not results:
            return "", "No conversations found."

        md = self._format_markdown(results, "Conversation Export - Complete")

        filename = f"export_{user_id}_complete_{datetime.now(timezone.utc).strftime('%Y%m%d')}.md"
        filepath = self.export_dir / filename
        filepath.write_text(md)

        return str(filepath), f"Exported {len(results)} entries to `{filename}`"

    def _format_markdown(self, entries: list[dict], title: str) -> str:
        """Format memory entries as clean markdown."""
        lines = [
            f"# {title}",
            f"*Exported: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}*",
            f"*Entries: {len(entries)}*",
            "",
            "---",
            "",
        ]

        for i, entry in enumerate(entries, 1):
            content = entry.get("content", "")
            score = entry.get("score", 0)
            source = entry.get("source", "unknown")
            timestamp = entry.get("timestamp", "")

            if timestamp:
                lines.append(f"### Entry {i} ({timestamp})")
            else:
                lines.append(f"### Entry {i}")

            lines.append("")
            lines.append(content)
            lines.append("")
            lines.append(f"*Source: {source} | Relevance: {score:.2f}*")
            lines.append("")
            lines.append("---")
            lines.append("")

        return "\n".join(lines)
