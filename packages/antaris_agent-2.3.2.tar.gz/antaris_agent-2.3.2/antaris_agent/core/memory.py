"""
antaris_agent/core/memory.py

Thin wrapper around parsica-memory for Antaris Agent.
Handles per-user memory scoping, auto-ingest, and recall.

Real API discovered via inspection:
    MemorySystem(workspace=<path>)  — constructor
    .ingest(content, source, category, memory_type, tags) → int
    .search(query, limit, ...) → list[SearchResult]
        SearchResult.content      — the text
        SearchResult.relevance    — 0.0–1.0 score
        SearchResult.source       — origin label
        SearchResult.category     — category label
    .stats() → dict (total, avg_score, categories, …)
    .save()  — flush WAL + shards to disk
    .load()  — reload from disk
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional


MEMORY_SOURCE_OF_TRUTH_NOTE = (
    "Use the bundled parsica_memory package in this repository as the runtime "
    "source of truth. Do not mix it with a separately installed parsica-memory "
    "package from another environment."
)

logger = logging.getLogger(__name__)

# ── Canonical security modes ──────────────────────────────────────────────
# "locked" is a legacy alias for "encrypted".  Normalizing early prevents
# scattered ``if mode in ("locked", "encrypted")`` checks throughout the
# codebase and ensures a single canonical value is stored and compared.
_SECURITY_MODE_ALIASES: dict[str, str] = {
    "locked": "encrypted",
}
_VALID_SECURITY_MODES = frozenset(
    {"open", "standard", "sandboxed", "secured", "encrypted"}
)


def _normalize_security_mode(mode: str) -> str:
    """Resolve legacy aliases and validate.

    Returns the canonical mode string.  Raises ``ValueError`` for
    completely unknown modes (typos, empty strings, etc.).
    """
    mode = (mode or "").strip().lower()
    mode = _SECURITY_MODE_ALIASES.get(mode, mode)
    if mode not in _VALID_SECURITY_MODES:
        logger.warning(
            "Unknown security_mode %r — falling back to 'sandboxed'", mode
        )
        mode = "sandboxed"
    return mode


def _normalize_user_id(user_id: str) -> str:
    """Map external user IDs to a safe per-user store directory name."""
    raw = (user_id or "").strip()
    if not raw:
        raise ValueError("user_id cannot be empty")
    digest = hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]
    slug = re.sub(r"[^A-Za-z0-9._-]+", "-", raw).strip(".-_")
    if not slug:
        slug = "user"
    return f"{slug[:48]}-{digest}"


def _ensure_within_root(path: Path, root: Path) -> Path:
    """Resolve *path* and ensure it stays inside *root*."""
    resolved_root = root.resolve()
    resolved_path = path.resolve()
    try:
        resolved_path.relative_to(resolved_root)
    except ValueError as exc:
        raise ValueError(f"Path escapes memory root: {resolved_path}") from exc
    return resolved_path


def _get_relevance_score(result: object) -> float:
    """Extract a relevance score from a search result object.

    Handles both SearchResult (has .relevance + .score) and MemoryEntry
    (has .confidence) return types from MemorySystem.search().

    Falls back to 1.0 if none of the expected fields exist, which passes
    the relevance filter rather than silently dropping the entry. A warning
    is logged in that case so schema drift is visible in the logs.
    """
    for attr in ("relevance", "score", "confidence"):
        val = getattr(result, attr, None)
        if val is not None:
            return float(val)
    logger.warning(
        "Memory result %r has no relevance/score/confidence field — "
        "defaulting to 1.0 (check SearchResult/MemoryEntry schema)",
        type(result).__name__,
    )
    return 1.0

# ---------------------------------------------------------------------------
# Import directly from parsica_memory — the single source of truth.
# parsica_memory is the sole memory implementation.
# ---------------------------------------------------------------------------
try:
    from parsica_memory import MemorySystem
    _MEMORY_AVAILABLE = True
except ImportError:
    _MEMORY_AVAILABLE = False
    MemorySystem = None  # type: ignore[assignment, misc]


if _MEMORY_AVAILABLE:
    try:
        _memory_module_path = Path(getattr(MemorySystem, "__module__", "").replace(".", "/"))
        logger.info("BotMemory runtime using bundled parsica_memory import path: %s", _memory_module_path)
    except Exception:
        pass


class BotMemory:
    """
    Wrapper around parsica-memory for Antaris Agent.
    Handles per-user memory scoping, auto-ingest, and recall.

    Each user gets their own MemorySystem backed by a sub-directory under
    store_path, keeping memories fully isolated per user.

    Args:
        store_path:     Root directory for all user memory stores.
        search_limit:   Max results returned from recall/search.
        min_relevance:  Minimum relevance score (0–1) to include in recall.
    """

    def __init__(
        self,
        store_path: str,
        search_limit: int = 10,
        min_relevance: float = 0.3,
        security_mode: str = "sandboxed",
        encryption_key: Optional[bytes] = None,
        agent_name: str = "Antaris Agent",
    ):
        self.store_path = Path(store_path)
        self.store_path.mkdir(parents=True, exist_ok=True)
        self.search_limit = search_limit
        self.min_relevance = min_relevance
        self.security_mode = _normalize_security_mode(security_mode)
        self.encryption_key = encryption_key
        self.agent_name = agent_name

        if self.security_mode == "encrypted" and not self.encryption_key:
            raise RuntimeError("Encrypted memory mode requires encryption_key")

        # NOTE: In "encrypted" security mode, the store directory is permission-locked (chmod 700).
        # Full data-at-rest encryption of individual shard files is planned for a future release.
        # Until then, "encrypted" mode provides OS-level access control + audit hook enforcement.
        if self.security_mode in ("locked", "encrypted"):
            self.store_path.chmod(0o700)  # restrict store dir to owner only
        self._stores: dict[str, object] = {}  # user_id → MemorySystem

    @property
    def encryption_status(self) -> dict:
        """Report encryption status honestly."""
        return {
            "mode": self.security_mode,
            "key_loaded": self.encryption_key is not None,
            "data_at_rest_encrypted": False,  # Honest: not yet implemented
            "os_level_protection": self.security_mode in ("secured", "encrypted"),
            "audit_hook_active": self.security_mode != "open",
        }

    def _user_store_path(self, user_id: str) -> Path:
        legacy_path = self.store_path / user_id
        try:
            if legacy_path.exists() and legacy_path.is_dir():
                return legacy_path
        except Exception:
            pass
        return self.store_path / _normalize_user_id(user_id)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _get_store(self, user_id: str):
        """Get or create a MemorySystem for a specific user."""
        if user_id not in self._stores:
            user_path = _ensure_within_root(self._user_store_path(user_id), self.store_path)
            user_path.mkdir(parents=True, exist_ok=True)
            self._stores[user_id] = self._init_store(str(user_path))
        return self._stores[user_id]

    def _init_store(self, path: str):
        """
        Initialize a parsica-memory MemorySystem at the given path.

        Uses the real MemorySystem API:
            MemorySystem(workspace=path)
            .load() → loads existing memories from disk
        """
        if not _MEMORY_AVAILABLE:
            raise RuntimeError(
                "Bundled parsica_memory is unavailable in this runtime. "
                f"{MEMORY_SOURCE_OF_TRUTH_NOTE}"
            )
        store = MemorySystem(workspace=path, agent_name=self.agent_name)
        try:
            store.load()
        except Exception as e:
            # First-time use — no data on disk yet, that's fine.
            logger.info("Memory store at %s is empty (first use): %s", path, e)
        return store

    # ------------------------------------------------------------------
    # Public async interface
    # ------------------------------------------------------------------

    async def recall(self, user_id: str, query: str, session_id: str = "") -> list[str]:
        """
        Recall relevant memories for a user given a query.

        Uses MemorySystem.search() with BM25 + decay ranking.
        cross_session_recall="semantic" lets facts/decisions cross session boundaries
        while keeping episodic chatter scoped to the current session.
        Returns list of memory content strings filtered by min_relevance.
        """
        try:
            store = self._get_store(user_id)
            search_kwargs = {
                "limit": self.search_limit,
                "use_decay": True,
                "cross_session_recall": "semantic",
            }
            if session_id:
                search_kwargs["session_id"] = session_id
            results = store.search(query, **search_kwargs)
            return [
                r.content
                for r in results
                if _get_relevance_score(r) >= self.min_relevance
            ]
        except Exception as e:
            logger.warning("Memory recall failed: %s", e)
            return []

    # ------------------------------------------------------------------
    # Ingest filter
    # ------------------------------------------------------------------

    def _should_skip_ingest(self, text: str) -> bool:
        """
        Return True if this text should be skipped during memory ingest.

        Filters out:
        - Context packet headers injected by the pipeline
        - System/queue notifications
        - Very short or whitespace-only content
        """
        if not text or not text.strip():
            return True

        stripped = text.strip()

        # Too short to be meaningful
        if len(stripped) < 20:
            return True

        # Pure punctuation / whitespace (no alphanumeric chars)
        if not re.search(r"[a-zA-Z0-9]", stripped):
            return True

        # Context packet noise
        if stripped.startswith("## Context Packet"):
            return True
        if stripped.startswith("### Relevant Context"):
            return True
        if "*Packet built" in stripped:
            return True
        if "[Queued messages while agent was busy]" in stripped:
            return True
        if "<ContextPacket" in stripped:
            return True
        if stripped == "[System Message]":
            return True

        return False

    async def ingest(
        self,
        user_id: str,
        user_message: str,
        bot_response: str,
        session_id: str = "",
        channel_id: str = "",
    ):
        """
        Store a conversation turn in memory.

        Uses MemorySystem.ingest() which handles deduplication internally.
        Saves to disk after each ingest so nothing is lost on crash.
        Skips ingest if either message looks like pipeline noise.
        memory_type is omitted so parsica-memory 5.2+ auto-classifies
        (semantic for facts/decisions, episodic for events/chat).
        """
        if self._should_skip_ingest(user_message):
            logger.debug(
                "Skipping memory ingest: user_message filtered (user=%s, preview=%r)",
                user_id, user_message[:60],
            )
            return
        if self._should_skip_ingest(bot_response):
            logger.debug(
                "Skipping memory ingest: bot_response filtered (user=%s, preview=%r)",
                user_id, bot_response[:60],
            )
            return

        try:
            store = self._get_store(user_id)
            content = f"User: {user_message}\nAntaris: {bot_response}"
            ingest_kwargs = {
                "source": "conversation",
                "category": "chat",
            }
            if session_id:
                ingest_kwargs["session_id"] = session_id
            if channel_id:
                ingest_kwargs["channel_id"] = channel_id
            store.ingest(content, **ingest_kwargs)
            store.save()
        except Exception as e:
            logger.warning("Memory ingest failed: %s", e)

    # ------------------------------------------------------------------
    # Sync utility methods
    # ------------------------------------------------------------------

    def stats(self, user_id: Optional[str] = None) -> dict:
        """
        Return memory stats for a user or all users.

        Single user → returns rich dict with filesystem + MemorySystem info.
        All users   → returns aggregate with per-user breakdown.
        """
        if user_id is not None:
            try:
                store = self._get_store(user_id)
                s = store.stats()
                user_path = _ensure_within_root(self._user_store_path(user_id), self.store_path)

                # Filesystem size
                store_size_bytes = sum(
                    f.stat().st_size
                    for f in user_path.rglob("*")
                    if f.is_file()
                )

                # Oldest/newest entry by file mtime
                all_files = [f for f in user_path.rglob("*") if f.is_file()]
                oldest_entry: Optional[str] = None
                newest_entry: Optional[str] = None
                if all_files:
                    mtimes = sorted(f.stat().st_mtime for f in all_files)
                    oldest_entry = datetime.fromtimestamp(
                        mtimes[0], tz=timezone.utc
                    ).isoformat()
                    newest_entry = datetime.fromtimestamp(
                        mtimes[-1], tz=timezone.utc
                    ).isoformat()

                return {
                    "user_id": user_id,
                    "entry_count": s.get("total", 0),
                    "store_size_bytes": store_size_bytes,
                    "store_path": str(user_path),
                    "oldest_entry": oldest_entry,
                    "newest_entry": newest_entry,
                }
            except Exception as e:
                return {
                    "user_id": user_id,
                    "entry_count": 0,
                    "store_size_bytes": 0,
                    "store_path": str(self._user_store_path(user_id)),
                    "oldest_entry": None,
                    "newest_entry": None,
                    "error": str(e),
                }

        # Aggregate across all known stores
        users_stats = {}
        total_entries = 0
        for uid, store in self._stores.items():
            try:
                s = store.stats()
                count = s.get("total", 0)
                users_stats[uid] = count
                total_entries += count
            except Exception:
                users_stats[uid] = 0

        return {
            "users": list(self._stores.keys()),
            "user_count": len(self._stores),
            "total_entries": total_entries,
            "store_path": str(self.store_path),
            "per_user": users_stats,
        }

    def search_memories(self, user_id: str, query: str, limit: int = 10) -> list[dict]:
        """
        Search memories for a user and return structured results.

        Calls MemorySystem.search(query, limit=limit).
        Returns list of {content, score, timestamp, source}.
        """
        try:
            store = self._get_store(user_id)
            results = store.search(query, limit=limit)
            return [
                {
                    "content": getattr(r, "content", ""),
                    "score": getattr(r, "relevance", getattr(r, "score", 0.0)),
                    "timestamp": getattr(r, "timestamp", None),
                    "source": getattr(r, "source", ""),
                }
                for r in results
            ]
        except Exception as e:
            logger.warning("Memory search_memories failed: %s", e)
            return []

    def export_memories(self, user_id: str, output_path: str) -> int:
        """
        Export all memories for a user to a JSON file.

        Uses ``store.memories`` (the full entry list) rather than
        ``store.search()`` because BM25 search with an empty/wildcard
        query produces zero results (no tokens to match).

        Returns count of exported entries.
        """
        try:
            store = self._get_store(user_id)
            # Access the raw memory list directly — search("") returns nothing
            # because BM25 tokenization discards empty/wildcard queries.
            all_memories = getattr(store, "memories", None)
            if isinstance(all_memories, list):
                pass
            else:
                all_memories = None
            if all_memories is None:
                # Fallback for store implementations that don't expose .memories
                all_memories = store.search("*", limit=10_000)
                if all_memories:
                    first = all_memories[0]
                    if not getattr(first, "content", None):
                        all_memories = []
                if not all_memories:
                    all_memories = store.search("", limit=10_000)
            entries = [
                {
                    "content": getattr(r, "content", ""),
                    "score": getattr(r, "relevance", getattr(r, "score", getattr(r, "confidence", 0.0))),
                    "timestamp": getattr(r, "timestamp", None),
                    "source": getattr(r, "source", ""),
                    "category": getattr(r, "category", ""),
                }
                for r in all_memories
            ]
            export_data = {
                "user_id": user_id,
                "exported_at": datetime.now(tz=timezone.utc).isoformat(),
                "entry_count": len(entries),
                "entries": entries,
            }
            output = Path(output_path)
            output.parent.mkdir(parents=True, exist_ok=True)
            output.write_text(json.dumps(export_data, indent=2, default=str))
            return len(entries)
        except Exception as e:
            logger.warning("Memory export failed: %s", e)
            return 0

    def clear_memories(self, user_id: str) -> int:
        """
        Delete all memory files for a user (not the directory itself).

        Returns count of deleted files.
        """
        try:
            user_path = _ensure_within_root(self._user_store_path(user_id), self.store_path)
            if not user_path.exists():
                return 0
            files = [f for f in user_path.rglob("*") if f.is_file()]
            count = len(files)
            for f in files:
                f.unlink()
            # Remove empty subdirectories (keep user dir itself)
            for d in sorted(user_path.rglob("*"), reverse=True):
                if d.is_dir() and d != user_path:
                    try:
                        d.rmdir()
                    except OSError:
                        pass
            self._stores.pop(user_id, None)
            return count
        except Exception as e:
            logger.warning("Memory clear failed: %s", e)
            return 0

    def search(self, user_id: str, query: str, session_id: str = "") -> list[dict]:
        """
        Search memories and return full results with metadata.

        Returns list of dicts:
            { content, relevance, score, source, category, matched_terms }
        """
        try:
            store = self._get_store(user_id)
            search_kwargs = {
                "limit": self.search_limit,
                "use_decay": True,
                "explain": True,
                "cross_session_recall": "semantic",
            }
            if session_id:
                search_kwargs["session_id"] = session_id
            results = store.search(query, **search_kwargs)
            return [
                {
                    "content": r.content,
                    "relevance": getattr(r, "relevance", getattr(r, "score", 0.0)),
                    "score": getattr(r, "score", getattr(r, "relevance", 0.0)),
                    "source": r.source,
                    "category": r.category,
                    "matched_terms": r.matched_terms,
                    "explanation": r.explanation,
                }
                for r in results
            ]
        except Exception as e:
            logger.warning("Memory search failed: %s", e)
            return []

    def search_recent(self, hours: float = 6.0, limit: int = 5, exclude_session: str = "") -> list:
        """Search for recent memories across all users/sessions.

        Delegates to the underlying MemorySystem.search_recent() if available.
        Returns an empty list if the backend does not support this method.
        """
        # Use any available store; fall back to the default user's store
        store = None
        for s in self._stores.values():
            store = s
            break
        if store is None:
            return []
        if not hasattr(store, "search_recent"):
            return []
        try:
            kwargs: dict = {"hours": hours, "limit": limit}
            if exclude_session:
                kwargs["exclude_session"] = exclude_session
            return store.search_recent(**kwargs)
        except Exception as e:
            logger.warning("Memory search_recent failed: %s", e)
            return []
