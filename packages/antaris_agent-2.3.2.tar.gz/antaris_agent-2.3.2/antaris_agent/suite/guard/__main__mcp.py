"""Entry point for: python -m antaris_agent.suite.guard.mcp_server"""
from antaris_agent.suite.guard.mcp_server import main
main()
