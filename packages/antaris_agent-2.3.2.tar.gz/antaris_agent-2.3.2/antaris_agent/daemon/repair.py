"""
Self-diagnostic and auto-repair system for Antaris Agent.

Checks common issues and attempts automatic fixes:
- Config integrity
- Stale PID files
- Memory store health
- Socket cleanup
- Dependency verification
- Directory structure
"""
from __future__ import annotations

import importlib.util
import json
import logging
import os
import sys
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

DEFAULT_CONFIG_DIR = Path.home() / ".antaris"
DEFAULT_CONFIG_PATH = DEFAULT_CONFIG_DIR / "config.json"
PID_FILE = DEFAULT_CONFIG_DIR / "bot.pid"
SOCKET_PATH = DEFAULT_CONFIG_DIR / "antarisd.sock"


class RepairManager:
    """Self-diagnostic and auto-repair for common issues."""
    
    def run(self, auto_fix: bool = True) -> list[dict]:
        """Run all checks. Returns list of {check, status, message, fixed}."""
        results = []
        results.append(self._check_config(auto_fix))
        results.append(self._check_pid_file(auto_fix))
        results.append(self._check_memory_store(auto_fix))
        results.append(self._check_socket(auto_fix))
        results.append(self._check_dependencies(auto_fix))
        results.append(self._check_directories(auto_fix))
        return results
    
    def _check_config(self, auto_fix: bool = True) -> dict:
        """Check config.json integrity. Auto-restore from backup if corrupt."""
        check_name = "config_integrity"
        
        if not DEFAULT_CONFIG_PATH.exists():
            return {
                "check": check_name,
                "status": "error",
                "message": "Config file not found",
                "fixed": False,
            }
        
        try:
            with open(DEFAULT_CONFIG_PATH, 'r') as f:
                config_data = json.load(f)
            
            # Check for required fields
            required_fields = ["bot_name", "provider_name", "model"]
            missing_fields = [field for field in required_fields if field not in config_data]
            
            if missing_fields:
                return {
                    "check": check_name,
                    "status": "error",
                    "message": f"Config missing required fields: {missing_fields}",
                    "fixed": False,
                }
            
            return {
                "check": check_name,
                "status": "ok",
                "message": "Config file is valid",
                "fixed": False,
            }
            
        except json.JSONDecodeError as e:
            # Config is corrupt
            backup_path = DEFAULT_CONFIG_PATH.with_suffix(".json.bak")
            
            if not auto_fix:
                return {
                    "check": check_name,
                    "status": "error",
                    "message": f"Config file is corrupt: {e}",
                    "fixed": False,
                }
            
            if backup_path.exists():
                try:
                    # Test backup validity
                    with open(backup_path, 'r') as f:
                        json.load(f)
                    
                    # Restore from backup (copy, not rename — preserve backup for future)
                    import shutil
                    shutil.copy2(backup_path, DEFAULT_CONFIG_PATH)
                    
                    return {
                        "check": check_name,
                        "status": "fixed",
                        "message": f"Restored config from backup (was corrupt: {e})",
                        "fixed": True,
                    }
                except (json.JSONDecodeError, OSError):
                    pass
            
            return {
                "check": check_name,
                "status": "error",
                "message": f"Config corrupt and no valid backup found: {e}",
                "fixed": False,
            }
        
        except Exception as e:
            return {
                "check": check_name,
                "status": "error",
                "message": f"Config check failed: {e}",
                "fixed": False,
            }
    
    def _check_pid_file(self, auto_fix: bool = True) -> dict:
        """Check for stale PID file."""
        check_name = "pid_file"
        
        if not PID_FILE.exists():
            return {
                "check": check_name,
                "status": "ok",
                "message": "No PID file (clean state)",
                "fixed": False,
            }
        
        try:
            pid = int(PID_FILE.read_text().strip())
            
            # Check if process exists
            try:
                os.kill(pid, 0)  # Signal 0 just checks if process exists
                return {
                    "check": check_name,
                    "status": "ok",
                    "message": f"Bot running with PID {pid}",
                    "fixed": False,
                }
            except ProcessLookupError:
                # Process doesn't exist - stale PID file
                if auto_fix:
                    PID_FILE.unlink()
                    return {
                        "check": check_name,
                        "status": "fixed",
                        "message": f"Removed stale PID file (process {pid} not running)",
                        "fixed": True,
                    }
                else:
                    return {
                        "check": check_name,
                        "status": "error",
                        "message": f"Stale PID file exists (process {pid} not running)",
                        "fixed": False,
                    }
            except PermissionError:
                return {
                    "check": check_name,
                    "status": "warning",
                    "message": f"Cannot check if process {pid} exists (permission denied)",
                    "fixed": False,
                }
        
        except (ValueError, OSError) as e:
            if auto_fix:
                PID_FILE.unlink()
                return {
                    "check": check_name,
                    "status": "fixed",
                    "message": f"Removed invalid PID file: {e}",
                    "fixed": True,
                }
            else:
                return {
                    "check": check_name,
                    "status": "error",
                    "message": f"Invalid PID file: {e}",
                    "fixed": False,
                }
    
    def _check_memory_store(self, auto_fix: bool = True) -> dict:
        """Check memory store directory exists and is readable."""
        check_name = "memory_store"
        
        # Default memory store path
        memory_store = DEFAULT_CONFIG_DIR / "memory"
        
        # Try to read from config if available
        try:
            if DEFAULT_CONFIG_PATH.exists():
                with open(DEFAULT_CONFIG_PATH, 'r') as f:
                    config_data = json.load(f)
                    if "memory_store" in config_data:
                        memory_store = Path(config_data["memory_store"])
        except (json.JSONDecodeError, OSError):
            pass  # Use default
        
        if not memory_store.exists():
            if auto_fix:
                try:
                    memory_store.mkdir(parents=True, exist_ok=True)
                    return {
                        "check": check_name,
                        "status": "fixed",
                        "message": f"Created memory store directory: {memory_store}",
                        "fixed": True,
                    }
                except OSError as e:
                    return {
                        "check": check_name,
                        "status": "error",
                        "message": f"Cannot create memory store directory: {e}",
                        "fixed": False,
                    }
            else:
                return {
                    "check": check_name,
                    "status": "error",
                    "message": f"Memory store directory missing: {memory_store}",
                    "fixed": False,
                }
        
        if not memory_store.is_dir():
            return {
                "check": check_name,
                "status": "error",
                "message": f"Memory store path exists but is not a directory: {memory_store}",
                "fixed": False,
            }
        
        # Test read/write access
        try:
            test_file = memory_store / ".repair_test"
            test_file.write_text("test")
            test_file.unlink()
            
            return {
                "check": check_name,
                "status": "ok",
                "message": f"Memory store accessible: {memory_store}",
                "fixed": False,
            }
        except OSError as e:
            return {
                "check": check_name,
                "status": "error",
                "message": f"Memory store not writable: {e}",
                "fixed": False,
            }
    
    def _check_socket(self, auto_fix: bool = True) -> dict:
        """Check for stale Unix socket file."""
        check_name = "socket_file"
        
        if not SOCKET_PATH.exists():
            return {
                "check": check_name,
                "status": "ok",
                "message": "No socket file (clean state)",
                "fixed": False,
            }
        
        # Check if daemon is actually listening on the socket
        try:
            # Try to connect to the socket
            import socket
            sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            try:
                sock.connect(str(SOCKET_PATH))
                sock.close()
                return {
                    "check": check_name,
                    "status": "ok",
                    "message": "Socket file active (daemon listening)",
                    "fixed": False,
                }
            except ConnectionRefusedError:
                # Socket exists but nothing listening
                if auto_fix:
                    SOCKET_PATH.unlink()
                    return {
                        "check": check_name,
                        "status": "fixed",
                        "message": "Removed stale socket file (no daemon listening)",
                        "fixed": True,
                    }
                else:
                    return {
                        "check": check_name,
                        "status": "error",
                        "message": "Stale socket file exists (no daemon listening)",
                        "fixed": False,
                    }
            finally:
                sock.close()
        
        except Exception as e:
            return {
                "check": check_name,
                "status": "warning",
                "message": f"Cannot test socket: {e}",
                "fixed": False,
            }
    
    def _check_dependencies(self, auto_fix: bool = True) -> dict:
        """Check antaris-suite packages are installed."""
        check_name = "dependencies"
        
        required_packages = [
            "parsica-memory",
            "antaris-guard", 
            "antaris-context",
            "antaris-router",
            "antaris-pipeline",
            "discord.py",
        ]
        
        missing_packages = []
        
        for package in required_packages:
            if package == "discord.py":
                module_name = "discord"
            else:
                # pip package names use hyphens; Python module names use underscores
                module_name = package.replace("-", "_")

            if importlib.util.find_spec(module_name) is None:
                missing_packages.append(package)
        
        if missing_packages:
            return {
                "check": check_name,
                "status": "error",
                "message": f"Missing packages: {missing_packages}",
                "fixed": False,
            }
        
        return {
            "check": check_name,
            "status": "ok",
            "message": "All required packages installed",
            "fixed": False,
        }
    
    def _check_directories(self, auto_fix: bool = True) -> dict:
        """Ensure required directories exist."""
        check_name = "directories"
        
        required_dirs = [
            DEFAULT_CONFIG_DIR,
            DEFAULT_CONFIG_DIR / "logs",
            DEFAULT_CONFIG_DIR / "memory",
            DEFAULT_CONFIG_DIR / "backups",
        ]
        
        created_dirs = []
        failed_dirs = []
        
        for dir_path in required_dirs:
            if not dir_path.exists():
                if auto_fix:
                    try:
                        dir_path.mkdir(parents=True, exist_ok=True)
                        created_dirs.append(str(dir_path))
                    except OSError as e:
                        failed_dirs.append(f"{dir_path}: {e}")
                else:
                    failed_dirs.append(str(dir_path))
        
        if failed_dirs:
            return {
                "check": check_name,
                "status": "error",
                "message": f"Cannot create directories: {failed_dirs}",
                "fixed": len(created_dirs) > 0,
            }
        
        if created_dirs:
            return {
                "check": check_name,
                "status": "fixed",
                "message": f"Created directories: {created_dirs}",
                "fixed": True,
            }
        
        return {
            "check": check_name,
            "status": "ok",
            "message": "All required directories exist",
            "fixed": False,
        }