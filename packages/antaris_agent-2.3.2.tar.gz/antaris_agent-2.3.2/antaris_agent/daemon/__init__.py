"""
Daemon IPC system for Antaris Agent.

Provides Unix socket communication between the running daemon and CLI commands.
"""
from .ipc import DaemonIPC, DaemonClient
from .repair import RepairManager

__all__ = ["DaemonIPC", "DaemonClient", "RepairManager"]