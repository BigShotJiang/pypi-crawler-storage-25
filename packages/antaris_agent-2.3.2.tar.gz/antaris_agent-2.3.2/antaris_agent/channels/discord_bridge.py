"""
Discord Message Bridge — auto-ingest Discord messages into memory.

The DiscordBridge listens to all messages in configured channels (not just @mentions)
and automatically ingests them into the bot's memory for later recall.
"""

import logging
from collections import deque
from typing import Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from antaris_agent.core.memory import BotMemory
    import discord

logger = logging.getLogger(__name__)


class DiscordBridge:
    """
    Auto-ingest Discord messages into bot memory.
    
    Features:
    - Listens to all messages in configured channels
    - Filters out bot messages and short/command messages  
    - Deduplicates by Discord message ID
    - Adds metadata: source, channel_id, session_id
    """

    def __init__(
        self,
        memory: "BotMemory",
        bridge_enabled: bool = True,
        bridge_channels: Optional[list[str]] = None,
        bot_user_id: Optional[str] = None
    ):
        """
        Initialize Discord bridge.
        
        Args:
            memory: BotMemory instance to ingest messages into
            bridge_enabled: Whether bridge is enabled
            bridge_channels: List of channel IDs to monitor (empty = all open channels)
            bot_user_id: Bot's Discord user ID to filter out its own messages
        """
        self.memory = memory
        self.enabled = bridge_enabled
        self.bridge_channels: set[str] = set(bridge_channels or [])
        self.bot_user_id = bot_user_id
        
        # Deduplication: track recently ingested message IDs (max 1000)
        self._ingested_message_ids: deque[str] = deque(maxlen=1000)

    def should_ingest(self, message: "discord.Message") -> bool:
        """
        Determine if a message should be ingested into memory.
        
        Args:
            message: Discord message object
            
        Returns:
            bool: True if message should be ingested
        """
        if not self.enabled:
            return False

        # Check for None author (edge case)
        if message.author is None:
            logger.debug("Skipping message with None author: %s", message.id)
            return False

        # Skip if message from bot itself
        if self.bot_user_id and str(message.author.id) == self.bot_user_id:
            logger.debug("Skipping bot's own message: %s", message.id)
            return False

        # Skip if other bots
        if message.author.bot:
            logger.debug("Skipping bot message from %s: %s", message.author.name, message.id)
            return False

        # Check for None content (edge case)
        if message.content is None:
            logger.debug("Skipping message with None content: %s", message.id)
            return False

        # Check channel filtering
        if self.bridge_channels and str(message.channel.id) not in self.bridge_channels:
            logger.debug("Skipping message from non-bridge channel %s", message.channel.id)
            return False

        # Skip short messages
        content_stripped = message.content.strip()
        if len(content_stripped) < 20:
            logger.debug("Skipping short message (%d chars): %s", len(content_stripped), message.id)
            return False

        # Skip bot commands
        if content_stripped.startswith("!"):
            logger.debug("Skipping command message: %s", message.id)
            return False

        # Check deduplication
        if str(message.id) in self._ingested_message_ids:
            logger.debug("Skipping already ingested message: %s", message.id)
            return False

        return True

    async def ingest_message(self, message: "discord.Message") -> bool:
        """
        Ingest a Discord message into memory.
        
        Args:
            message: Discord message object
            
        Returns:
            bool: True if successfully ingested
        """
        if not self.should_ingest(message):
            return False

        try:
            # Build message content for ingestion
            user_content = message.content.strip() if message.content else ""
            channel_name = getattr(message.channel, "name", "unknown")
            author_display_name = getattr(message.author, "display_name", "unknown")
            
            # Build metadata-rich content for searchability
            ingest_content = f"[{author_display_name}] {user_content}"
            
            # Create response with metadata context for memory recall
            # Include author, channel, and snippet for better searchability
            bot_response = (
                f"Message from {author_display_name} in #{channel_name}: "
                f'"{user_content[:100]}{"..." if len(user_content) > 100 else ""}"'
            )

            # Use channel ID as session_id for Discord bridge messages
            session_id = f"discord_bridge_{message.channel.id}"

            # Ingest into memory
            await self.memory.ingest(
                user_id=str(message.author.id),
                user_message=ingest_content,
                bot_response=bot_response,
                session_id=session_id,
                channel_id=str(message.channel.id)
            )

            # Track for deduplication (deque automatically handles max size)
            self._ingested_message_ids.append(str(message.id))

            logger.debug(
                "Ingested Discord message %s from %s in #%s (%d chars)",
                message.id, author_display_name, channel_name, len(user_content)
            )
            
            return True

        except Exception as e:
            logger.error("Failed to ingest Discord message %s: %s", message.id, e, exc_info=True)
            return False

    def update_config(
        self, 
        bridge_enabled: Optional[bool] = None,
        bridge_channels: Optional[list[str]] = None
    ) -> None:
        """
        Update bridge configuration at runtime.
        
        Args:
            bridge_enabled: New enabled state
            bridge_channels: New channel list
        """
        if bridge_enabled is not None:
            self.enabled = bridge_enabled
            logger.info("Discord bridge enabled: %s", bridge_enabled)
            
        if bridge_channels is not None:
            self.bridge_channels = set(bridge_channels)
            logger.info("Discord bridge channels: %s", bridge_channels)

    def get_stats(self) -> dict:
        """
        Get bridge statistics.
        
        Returns:
            dict: Bridge stats
        """
        return {
            "enabled": self.enabled,
            "bridge_channels": list(self.bridge_channels),
            "ingested_message_count": len(self._ingested_message_ids),
            "bot_user_id": self.bot_user_id
        }