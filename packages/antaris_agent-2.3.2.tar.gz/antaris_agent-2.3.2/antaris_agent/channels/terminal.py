import asyncio
import uuid
from datetime import datetime
from .base import ChannelAdapter, InboundMessage, OutboundMessage


class TerminalAdapter(ChannelAdapter):
    """Terminal REPL adapter for local testing."""

    CHANNEL_ID = "terminal-local"
    USER_ID = "local-user"
    USER_NAME = "User"

    def __init__(self, bot_name: str = "Antaris"):
        super().__init__()
        self.bot_name = bot_name
        self._running = False

    async def connect(self):
        self._running = True
        print(f"\n🤖 {self.bot_name} is ready. Type 'exit' or 'quit' to stop.\n")
        await self._repl_loop()

    async def disconnect(self):
        self._running = False

    async def send(self, message: OutboundMessage):
        print(f"\n{self.bot_name}: {message.text}\n")

    async def _repl_loop(self):
        while self._running:
            try:
                # Run input() in executor to not block event loop
                loop = asyncio.get_running_loop()
                text = await loop.run_in_executor(None, self._get_input)

                if text is None or text.lower() in ("exit", "quit"):
                    print(f"\n👋 Goodbye.")
                    self._running = False
                    break

                if not text.strip():
                    continue

                if self._handler:
                    msg = InboundMessage(
                        id=str(uuid.uuid4()),
                        user_id=self.USER_ID,
                        user_name=self.USER_NAME,
                        channel_id=self.CHANNEL_ID,
                        platform="terminal",
                        text=text,
                        timestamp_ms=int(datetime.now().timestamp() * 1000),
                    )
                    await self._handler(msg)

            except (EOFError, KeyboardInterrupt):
                print(f"\n👋 Goodbye.")
                self._running = False
                break

    def _get_input(self) -> str:
        try:
            return input("You: ")
        except (EOFError, KeyboardInterrupt):
            return None

    def format_for_surface(self, text: str) -> str:
        return text  # Plain text for terminal
