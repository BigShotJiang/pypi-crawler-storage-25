from .base import ChannelAdapter, InboundMessage, OutboundMessage, MessageHandler
from .terminal import TerminalAdapter

# Lazy imports — channel adapters require optional dependencies
# Import them explicitly where needed, not eagerly at package level


def get_discord_adapter():
    """Lazy import for DiscordAdapter (requires discord.py)."""
    from .discord import DiscordAdapter
    return DiscordAdapter


def get_telegram_adapter():
    """Lazy import for TelegramAdapter (requires python-telegram-bot)."""
    from .telegram import TelegramAdapter
    return TelegramAdapter


def get_slack_adapter():
    """Lazy import for SlackAdapter (requires slack-bolt)."""
    from .slack import SlackAdapter
    return SlackAdapter


__all__ = [
    "ChannelAdapter",
    "InboundMessage",
    "OutboundMessage",
    "MessageHandler",
    "TerminalAdapter",
    "get_discord_adapter",
    "get_telegram_adapter",
    "get_slack_adapter",
]
