from __future__ import annotations

import asyncio
import json
import logging
from pathlib import Path
from typing import Any, Dict

from .base import NativeTool, ToolResult

logger = logging.getLogger(__name__)


class PuppeteerTool(NativeTool):
    def __init__(self, workspace_path: str = None):
        """Initialize PuppeteerTool with workspace path for output files."""
        self.workspace_path = Path(workspace_path) if workspace_path else Path.cwd()
        # Get path to the runner script
        self.runner_script = Path(__file__).parent / "puppeteer_runner.js"

    @property
    def name(self) -> str:
        return "puppeteer"

    @property
    def description(self) -> str:
        return "Browser automation using Puppeteer (headless Chrome)"

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "description": "Puppeteer action to perform",
                    "enum": ["screenshot", "navigate", "click", "extract", "evaluate"]
                },
                "url": {
                    "type": "string",
                    "description": "URL to navigate to"
                },
                "selector": {
                    "type": "string",
                    "description": "CSS selector for click/extract actions"
                },
                "output_path": {
                    "type": "string",
                    "description": "Output file path for screenshots"
                },
                "script": {
                    "type": "string",
                    "description": "JavaScript code to evaluate in the page"
                },
                "options": {
                    "type": "object",
                    "description": "Additional options for the action",
                    "properties": {
                        "headless": {"type": "boolean", "default": True},
                        "width": {"type": "integer", "default": 1280},
                        "height": {"type": "integer", "default": 800},
                        "full_page": {"type": "boolean", "default": False},
                        "timeout": {"type": "integer", "default": 30000},
                        "wait_until": {"type": "string", "default": "networkidle2"}
                    }
                }
            },
            "required": ["action"]
        }

    async def execute(self, arguments: dict) -> ToolResult:
        action = arguments.get("action")
        url = arguments.get("url")
        selector = arguments.get("selector")
        output_path = arguments.get("output_path")
        script = arguments.get("script")
        options = arguments.get("options", {})

        if not action:
            return ToolResult(
                success=False,
                content="",
                error="Missing required parameter: action",
                is_error=True
            )

        # Check if runner script exists
        if not self.runner_script.exists():
            return ToolResult(
                success=False,
                content="",
                error="Puppeteer runner script not found",
                is_error=True
            )

        try:
            # Build command arguments
            cmd_args = ["node", str(self.runner_script), action]

            # Add action-specific arguments
            if url:
                cmd_args.extend(["--url", url])
            
            if selector:
                cmd_args.extend(["--selector", selector])
            
            if output_path:
                # Make path absolute and in workspace
                if not Path(output_path).is_absolute():
                    output_path = str(self.workspace_path / output_path)
                cmd_args.extend(["--output_path", output_path])
            
            if script:
                cmd_args.extend(["--script", script])

            # Add options
            for key, value in options.items():
                cmd_args.extend([f"--{key}", str(value)])

            logger.info("Puppeteer executing: action=%s url=%s", action, url)

            # Execute command
            process = await asyncio.create_subprocess_exec(
                *cmd_args,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=str(self.workspace_path)
            )

            try:
                stdout, stderr = await asyncio.wait_for(
                    process.communicate(),
                    timeout=60.0  # Generous timeout for browser operations
                )
                exit_code = process.returncode
            except asyncio.TimeoutError:
                process.kill()
                await process.wait()
                return ToolResult(
                    success=False,
                    content="",
                    error="Puppeteer command timed out after 60 seconds",
                    is_error=True
                )

            # Process output
            output = stdout.decode('utf-8', errors='replace') if stdout else ""
            error_output = stderr.decode('utf-8', errors='replace') if stderr else ""

            if exit_code != 0:
                # Try to parse error as JSON first
                error_msg = error_output
                try:
                    error_json = json.loads(error_output)
                    error_msg = error_json.get('error', error_output)
                except json.JSONDecodeError:
                    pass
                
                return ToolResult(
                    success=False,
                    content="",
                    error=f"Puppeteer command failed: {error_msg}",
                    is_error=True
                )

            # Format result
            result_content = f"🎭 **Puppeteer - {action.title()}**\n\n"

            # Try to parse JSON output
            try:
                # Look for JSON in the output
                lines = output.strip().split('\n')
                json_found = False
                
                for line in lines:
                    try:
                        json_data = json.loads(line)
                        if isinstance(json_data, dict) and json_data.get('success') is not None:
                            # This is our status JSON
                            if json_data.get('success'):
                                result_content += f"✅ Action completed successfully\n"
                            else:
                                result_content += f"❌ Action failed\n"
                            json_found = True
                        else:
                            # This is data output
                            formatted_json = json.dumps(json_data, indent=2)
                            result_content += f"```json\n{formatted_json}\n```\n"
                            json_found = True
                    except json.JSONDecodeError:
                        continue
                
                if not json_found and output:
                    result_content += f"Output:\n```\n{output}\n```"
                    
            except Exception:
                if output:
                    result_content += f"Output:\n```\n{output}\n```"

            # Add file info for screenshot
            if action == "screenshot" and output_path and Path(output_path).exists():
                file_size = Path(output_path).stat().st_size
                result_content += f"\n📸 Screenshot saved: {output_path}\n"
                result_content += f"File size: {file_size:,} bytes"

            if error_output and not error_output.strip().startswith('{"success":false'):
                result_content += f"\nWarnings:\n```\n{error_output}\n```"

            logger.info("Puppeteer completed successfully: action=%s", action)

            return ToolResult(
                success=True,
                content=result_content
            )

        except FileNotFoundError:
            return ToolResult(
                success=False,
                content="",
                error="Node.js not found. Is Node.js installed?",
                is_error=True
            )
        except Exception as e:
            logger.exception("Unexpected error in Puppeteer tool")
            return ToolResult(
                success=False,
                content="",
                error=f"Unexpected error: {e}",
                is_error=True
            )