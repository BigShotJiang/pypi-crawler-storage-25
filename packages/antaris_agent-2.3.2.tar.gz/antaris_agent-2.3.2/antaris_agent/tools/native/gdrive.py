from __future__ import annotations

import asyncio
import io
import logging
from typing import Optional

try:
    from googleapiclient.errors import HttpError
    from googleapiclient.http import MediaIoBaseUpload, MediaIoBaseDownload
except ImportError:
    HttpError = Exception  # type: ignore[assignment,misc]
    MediaIoBaseUpload = None  # type: ignore[assignment,misc]
    MediaIoBaseDownload = None  # type: ignore[assignment,misc]

from .base import NativeTool, ToolResult
from .google_auth import GoogleAuthManager, NOT_AUTHORIZED_MSG

logger = logging.getLogger(__name__)

_GOOGLE_DOC_MIME = "application/vnd.google-apps.document"
_GOOGLE_SHEET_MIME = "application/vnd.google-apps.spreadsheet"

# MIME types that are binary and cannot be meaningfully decoded as UTF-8 text.
# DriveReadTool will return a friendly error instead of garbled output for these.
BINARY_MIMES = {
    # Images
    "image/jpeg", "image/png", "image/gif", "image/webp",
    "image/bmp", "image/tiff", "image/svg+xml",
    # Documents (binary formats)
    "application/pdf",
    "application/msword",                                                    # .doc
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",  # .docx
    "application/vnd.ms-excel",                                              # .xls
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",     # .xlsx
    "application/vnd.ms-powerpoint",                                         # .ppt
    "application/vnd.openxmlformats-officedocument.presentationml.presentation",  # .pptx
    # Archives & binaries
    "application/zip",
    "application/x-zip-compressed",
    "application/x-tar",
    "application/gzip",
    "application/octet-stream",
    # Media
    "video/mp4", "video/quicktime", "video/x-msvideo",
    "audio/mpeg", "audio/wav", "audio/ogg",
}

_MIME_LABELS = {
    "application/vnd.google-apps.document": "Google Doc",
    "application/vnd.google-apps.spreadsheet": "Google Sheet",
    "application/vnd.google-apps.presentation": "Google Slides",
    "application/vnd.google-apps.folder": "Folder",
    "application/pdf": "PDF",
    "text/plain": "Text",
}


def _build_service(auth: GoogleAuthManager):
    from googleapiclient.discovery import build
    return build("drive", "v3", credentials=auth.get_credentials(), cache_discovery=False)


def _fmt_file(f: dict) -> str:
    mime = f.get("mimeType", "")
    label = _MIME_LABELS.get(mime, mime.split("/")[-1])
    return (
        f"Name: {f.get('name', '?')}\n"
        f"ID: {f.get('id', '?')}\n"
        f"Type: {label}\n"
        f"Modified: {f.get('modifiedTime', '?')}\n"
        f"Link: {f.get('webViewLink', '')}\n"
    )


class DriveSearchTool(NativeTool):
    def __init__(self, auth_manager: GoogleAuthManager):
        self._auth = auth_manager

    @property
    def name(self) -> str:
        return "drive_search"

    @property
    def description(self) -> str:
        return "Search Google Drive files by name or content."

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Drive search query (e.g. 'name contains budget')"},
                "max_results": {"type": "integer", "default": 10},
                "mime_type": {"type": "string", "description": "Filter by MIME type (optional)"},
            },
            "required": ["query"],
        }

    async def execute(self, arguments: dict) -> ToolResult:
        if not self._auth.is_authorized():
            return ToolResult(success=False, content="", error=NOT_AUTHORIZED_MSG, is_error=True)

        query = arguments["query"]
        max_results = int(arguments.get("max_results", 10))
        mime_type = arguments.get("mime_type", "")

        q = f"name contains '{query}' or fullText contains '{query}'"
        if mime_type:
            q += f" and mimeType='{mime_type}'"
        q += " and trashed=false"

        def _search():
            svc = _build_service(self._auth)
            result = svc.files().list(
                q=q,
                pageSize=max_results,
                fields="files(id,name,mimeType,modifiedTime,webViewLink)",
            ).execute()
            return result.get("files", [])

        try:
            files = await asyncio.get_running_loop().run_in_executor(None, _search)
            if not files:
                return ToolResult(success=True, content=f"No files found for: {query}")
            return ToolResult(
                success=True,
                content=("\n" + "-" * 40 + "\n").join(_fmt_file(f) for f in files),
            )
        except HttpError as e:
            return ToolResult(success=False, content="", error=str(e), is_error=True)


class DriveReadTool(NativeTool):
    def __init__(self, auth_manager: GoogleAuthManager):
        self._auth = auth_manager

    @property
    def name(self) -> str:
        return "drive_read"

    @property
    def description(self) -> str:
        return "Read the content of a Google Drive file by ID."

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "file_id": {"type": "string", "description": "Google Drive file ID"},
            },
            "required": ["file_id"],
        }

    async def execute(self, arguments: dict) -> ToolResult:
        if not self._auth.is_authorized():
            return ToolResult(success=False, content="", error=NOT_AUTHORIZED_MSG, is_error=True)

        file_id = arguments["file_id"].strip()

        def _read():
            svc = _build_service(self._auth)
            meta = svc.files().get(
                fileId=file_id, fields="mimeType,name"
            ).execute()
            mime = meta.get("mimeType", "")
            name = meta.get("name", "")

            # Return a friendly error for known binary formats instead of garbled text
            if mime in BINARY_MIMES:
                return f"File '{name}' is a binary file ({mime}) and cannot be read as text."

            buf = io.BytesIO()

            if mime == _GOOGLE_DOC_MIME:
                req = svc.files().export_media(fileId=file_id, mimeType="text/plain")
            elif mime == _GOOGLE_SHEET_MIME:
                req = svc.files().export_media(fileId=file_id, mimeType="text/csv")
            else:
                req = svc.files().get_media(fileId=file_id)

            dl = MediaIoBaseDownload(buf, req)
            done = False
            while not done:
                _, done = dl.next_chunk()

            content = buf.getvalue().decode("utf-8", errors="replace")
            if len(content) > 10000:
                content = content[:10000] + "\n\n[...truncated at 10,000 chars]"
            return content

        try:
            content = await asyncio.get_running_loop().run_in_executor(None, _read)
            return ToolResult(success=True, content=content)
        except HttpError as e:
            return ToolResult(success=False, content="", error=str(e), is_error=True)


class DriveUploadTool(NativeTool):
    def __init__(self, auth_manager: GoogleAuthManager):
        self._auth = auth_manager

    @property
    def name(self) -> str:
        return "drive_upload"

    @property
    def description(self) -> str:
        return "Upload a text file to Google Drive."

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "File name"},
                "content": {"type": "string", "description": "Text content"},
                "mime_type": {"type": "string", "default": "text/plain"},
                "folder_id": {"type": "string", "description": "Parent folder ID (optional)"},
            },
            "required": ["name", "content"],
        }

    async def execute(self, arguments: dict) -> ToolResult:
        if not self._auth.is_authorized():
            return ToolResult(success=False, content="", error=NOT_AUTHORIZED_MSG, is_error=True)

        name = arguments["name"]
        content = arguments["content"]
        mime_type = arguments.get("mime_type", "text/plain")
        folder_id = arguments.get("folder_id", "")

        def _upload():
            svc = _build_service(self._auth)
            meta: dict = {"name": name, "mimeType": mime_type}
            if folder_id:
                meta["parents"] = [folder_id]
            buf = io.BytesIO(content.encode("utf-8"))
            media = MediaIoBaseUpload(buf, mimetype=mime_type)
            f = svc.files().create(
                body=meta, media_body=media,
                fields="id,webViewLink"
            ).execute()
            return f.get("id", "?"), f.get("webViewLink", "")

        try:
            file_id, link = await asyncio.get_running_loop().run_in_executor(None, _upload)
            return ToolResult(
                success=True,
                content=f"File uploaded.\nID: {file_id}\nLink: {link}",
            )
        except HttpError as e:
            return ToolResult(success=False, content="", error=str(e), is_error=True)


class DriveRecentTool(NativeTool):
    def __init__(self, auth_manager: GoogleAuthManager):
        self._auth = auth_manager

    @property
    def name(self) -> str:
        return "drive_recent"

    @property
    def description(self) -> str:
        return "List the most recently modified files in Google Drive."

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "max_results": {"type": "integer", "default": 10},
            },
        }

    async def execute(self, arguments: dict) -> ToolResult:
        if not self._auth.is_authorized():
            return ToolResult(success=False, content="", error=NOT_AUTHORIZED_MSG, is_error=True)

        max_results = int(arguments.get("max_results", 10))

        def _fetch():
            svc = _build_service(self._auth)
            result = svc.files().list(
                pageSize=max_results,
                orderBy="modifiedTime desc",
                q="trashed=false",
                fields="files(id,name,mimeType,modifiedTime,webViewLink)",
            ).execute()
            return result.get("files", [])

        try:
            files = await asyncio.get_running_loop().run_in_executor(None, _fetch)
            if not files:
                return ToolResult(success=True, content="No files found.")
            return ToolResult(
                success=True,
                content=("\n" + "-" * 40 + "\n").join(_fmt_file(f) for f in files),
            )
        except HttpError as e:
            return ToolResult(success=False, content="", error=str(e), is_error=True)
