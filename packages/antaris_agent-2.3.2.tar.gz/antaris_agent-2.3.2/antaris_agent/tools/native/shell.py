from __future__ import annotations

import asyncio
import logging
from pathlib import Path

from .base import NativeTool, ToolResult

logger = logging.getLogger(__name__)


class ShellTool(NativeTool):
    def __init__(self, workspace_path: str, timeout: int = 30):
        self.workspace_path = Path(workspace_path).resolve()
        self.default_timeout = timeout

    @property
    def name(self) -> str:
        return "shell"

    @property
    def description(self) -> str:
        return "Execute shell commands"

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "command": {
                    "type": "string",
                    "description": "Shell command to execute"
                },
                "workdir": {
                    "type": "string",
                    "description": "Working directory (optional, defaults to workspace)"
                },
                "timeout": {
                    "type": "integer",
                    "description": "Timeout in seconds (optional, defaults to 30)",
                    "default": 30,
                    "minimum": 1,
                    "maximum": 300
                }
            },
            "required": ["command"]
        }

    def _validate_workdir(self, workdir_str: str) -> tuple[bool, str, Path]:
        """Validate that working directory is within workspace."""
        try:
            # Convert to Path and resolve
            workdir = (self.workspace_path / workdir_str).resolve()
            workspace_resolved = self.workspace_path.resolve()
            
            # Proper path containment check (not string prefix)
            try:
                workdir.relative_to(workspace_resolved)
            except ValueError:
                return False, "Working directory outside workspace not allowed", workdir
            
            if not workdir.exists():
                return False, f"Working directory does not exist: {workdir}", workdir
            
            if not workdir.is_dir():
                return False, f"Working directory is not a directory: {workdir}", workdir
            
            return True, "", workdir
        except Exception as e:
            return False, f"Invalid working directory: {e}", Path()

    async def execute(self, arguments: dict) -> ToolResult:
        command = arguments.get("command")
        workdir_str = arguments.get("workdir", ".")
        timeout = arguments.get("timeout", self.default_timeout)

        if not command:
            return ToolResult(
                success=False,
                content="",
                error="Missing required parameter: command",
                is_error=True
            )

        # Validate working directory
        is_valid, error_msg, workdir = self._validate_workdir(workdir_str)
        if not is_valid:
            return ToolResult(
                success=False,
                content="",
                error=error_msg,
                is_error=True
            )

        # Defensive timeout validation
        try:
            timeout = int(timeout)
        except (TypeError, ValueError):
            timeout = self.default_timeout
        timeout = max(1, min(300, timeout))

        logger.info("Shell tool executing: command=%r workdir=%s timeout=%d", command, workdir, timeout)

        try:
            # Create subprocess
            process = await asyncio.create_subprocess_shell(
                command,
                cwd=workdir,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,  # Combine stdout and stderr
                limit=1024 * 1024  # 1MB buffer limit
            )

            # Wait for completion with timeout
            try:
                stdout, _ = await asyncio.wait_for(
                    process.communicate(),
                    timeout=timeout
                )
                exit_code = process.returncode
            except asyncio.TimeoutError:
                # Kill the process on timeout
                process.kill()
                try:
                    await asyncio.wait_for(process.wait(), timeout=5)
                except asyncio.TimeoutError:
                    logger.error("Timed out waiting for killed process to exit: %r", command)
                return ToolResult(
                    success=False,
                    content="",
                    error=f"Command timed out after {timeout} seconds",
                    is_error=True,
                )

            # Decode output
            output = stdout.decode('utf-8', errors='replace') if stdout else ""
            
            # Truncate if too long (100KB limit)
            if len(output) > 102400:
                output = output[:102400] + "\n\n[Output truncated at 100KB...]"

            # Prepare result content
            result_content = f"Command: {command}\n"
            result_content += f"Working directory: {workdir}\n"
            result_content += f"Exit code: {exit_code}\n\n"
            result_content += "Output:\n" + output

            # Consider command successful if exit code is 0
            success = exit_code == 0

            logger.info("Shell tool completed: command=%r exit_code=%d output_bytes=%d", command, exit_code, len(output))

            return ToolResult(
                success=success,
                content=result_content,
                error=None if success else f"Command failed with exit code {exit_code}",
                is_error=not success
            )

        except FileNotFoundError:
            return ToolResult(
                success=False,
                content="",
                error="Shell command not found or not executable",
                is_error=True
            )
        except PermissionError:
            return ToolResult(
                success=False,
                content="",
                error="Permission denied executing command",
                is_error=True
            )
        except Exception as e:
            logger.exception("Unexpected error in shell execution")
            return ToolResult(
                success=False,
                content="",
                error=f"Unexpected error: {e}",
                is_error=True
            )