from __future__ import annotations

import json
import logging
import time
from typing import Any, Dict

from .base import NativeTool, ToolResult

logger = logging.getLogger(__name__)


class SessionStatusTool(NativeTool):
    def __init__(self, bot=None):
        """Initialize SessionStatusTool with bot instance."""
        self.bot = bot
        self.start_time = time.time()

    @property
    def name(self) -> str:
        return "session_status"

    @property
    def description(self) -> str:
        return "Get current bot session status, stats, and configuration"

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {},
            "required": []
        }

    async def execute(self, arguments: dict) -> ToolResult:
        try:
            # Calculate uptime
            uptime_seconds = int(time.time() - self.start_time)
            uptime_minutes = uptime_seconds // 60
            uptime_hours = uptime_minutes // 60
            uptime_str = f"{uptime_hours:02d}:{uptime_minutes % 60:02d}:{uptime_seconds % 60:02d}"

            status = {
                "session": {
                    "uptime_seconds": uptime_seconds,
                    "uptime_formatted": uptime_str,
                    "start_time": self.start_time
                },
                "bot": {},
                "tools": {},
                "memory": {},
                "llm": {}
            }

            # Bot information
            if self.bot:
                status["bot"]["name"] = getattr(self.bot, 'name', 'Unknown')
                status["bot"]["version"] = getattr(self.bot, 'version', 'Unknown')
                
                # Config info
                if hasattr(self.bot, 'config'):
                    config = self.bot.config
                    status["bot"]["config_path"] = getattr(config, 'config_path', 'Unknown')
                    status["bot"]["guard_mode"] = getattr(config, 'guard_mode', False)

                # Tool registry info
                if hasattr(self.bot, 'tool_registry') and self.bot.tool_registry:
                    registry = self.bot.tool_registry
                    tool_names = registry.list_tools()
                    status["tools"]["count"] = len(tool_names)
                    status["tools"]["active_tools"] = tool_names
                    
                    # Separate native vs MCP tools
                    native_tools = []
                    mcp_tools = []
                    for tool_name in tool_names:
                        tool_def = registry.get_tool_definition(tool_name)
                        if tool_def:
                            if tool_def.source == 'native':
                                native_tools.append(tool_name)
                            elif tool_def.source.startswith('mcp:'):
                                mcp_tools.append(tool_name)
                    
                    status["tools"]["native"] = native_tools
                    status["tools"]["mcp"] = mcp_tools
                else:
                    status["tools"]["count"] = 0
                    status["tools"]["active_tools"] = []
                    status["tools"]["native"] = []
                    status["tools"]["mcp"] = []

                # Memory info
                if hasattr(self.bot, 'memory') and self.bot.memory:
                    memory = self.bot.memory
                    # Get memory count if available
                    if hasattr(memory, 'count'):
                        try:
                            memory_count = await memory.count()
                            status["memory"]["total_memories"] = memory_count
                        except Exception as e:
                            status["memory"]["error"] = f"Failed to get memory count: {e}"
                    else:
                        status["memory"]["total_memories"] = "Unknown"
                else:
                    status["memory"]["total_memories"] = 0

                # LLM provider info
                if hasattr(self.bot, 'dispatcher') and self.bot.dispatcher:
                    dispatcher = self.bot.dispatcher
                    providers = dispatcher.providers
                    status["llm"]["providers"] = list(providers.keys())
                    status["llm"]["provider_count"] = len(providers)
                    
                    # Try to get current/default provider
                    if hasattr(self.bot, 'config') and hasattr(self.bot.config, 'llm'):
                        llm_config = self.bot.config.llm
                        if hasattr(llm_config, 'provider'):
                            status["llm"]["current_provider"] = llm_config.provider
                        if hasattr(llm_config, 'model'):
                            status["llm"]["current_model"] = llm_config.model
                else:
                    status["llm"]["providers"] = []
                    status["llm"]["provider_count"] = 0

            else:
                status["bot"]["error"] = "Bot instance not available"

            # Format as readable JSON
            formatted_status = json.dumps(status, indent=2, default=str)
            
            result_content = "📊 **Session Status**\n\n"
            result_content += f"```json\n{formatted_status}\n```"

            logger.info("Session status retrieved successfully")

            return ToolResult(
                success=True,
                content=result_content
            )

        except Exception as e:
            logger.exception("Error getting session status")
            return ToolResult(
                success=False,
                content="",
                error=f"Failed to get session status: {e}",
                is_error=True
            )