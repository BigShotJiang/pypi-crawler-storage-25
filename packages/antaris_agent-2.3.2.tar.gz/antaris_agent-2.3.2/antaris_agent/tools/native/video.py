from __future__ import annotations

import asyncio
import json
import logging
import mimetypes
import shutil
import tempfile
from pathlib import Path
from typing import Any

from .base import NativeTool, ToolResult

logger = logging.getLogger(__name__)

_VIDEO_EXTENSIONS = {
    ".mp4", ".mov", ".m4v", ".avi", ".mkv", ".webm", ".mpg", ".mpeg", ".wmv",
}
_AUDIO_EXTENSIONS = {
    ".mp3", ".m4a", ".wav", ".ogg", ".flac", ".aac",
}


class VideoTool(NativeTool):
    def __init__(self, dispatcher, workspace_path: str, timeout: int = 300):
        self.dispatcher = dispatcher
        self.workspace_path = Path(workspace_path).resolve()
        self.default_timeout = timeout

    @property
    def name(self) -> str:
        return "video"

    @property
    def description(self) -> str:
        return (
            "Video understanding tool: inspect media, extract transcripts, sample frames, "
            "and generate summaries or Q&A answers from videos/audio"
        )

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["inspect", "transcribe", "sample_frames", "summarize", "qa"],
                    "description": "Video action to perform"
                },
                "path": {
                    "type": "string",
                    "description": "Path to local video or audio file"
                },
                "question": {
                    "type": "string",
                    "description": "Question to answer for qa action"
                },
                "prompt": {
                    "type": "string",
                    "description": "Custom summarization prompt"
                },
                "max_frames": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": 24,
                    "default": 6,
                    "description": "Maximum number of representative frames to extract"
                },
                "output_dir": {
                    "type": "string",
                    "description": "Optional directory for generated artifacts"
                },
                "interval_seconds": {
                    "type": "number",
                    "minimum": 0.5,
                    "description": "Sample one frame every N seconds if set"
                },
                "whisper_model": {
                    "type": "string",
                    "default": "base",
                    "description": "Whisper model to use when transcribing"
                },
                "language": {
                    "type": "string",
                    "description": "Optional language hint for whisper"
                },
                "include_frame_analysis": {
                    "type": "boolean",
                    "default": True,
                    "description": "Include vision analysis of sampled frames for summarize/qa"
                },
                "force": {
                    "type": "boolean",
                    "default": False,
                    "description": "Regenerate outputs even if cached artifacts exist"
                }
            },
            "required": ["action", "path"]
        }

    async def execute(self, arguments: dict) -> ToolResult:
        action = arguments.get("action")
        path_arg = arguments.get("path")
        if not action or not path_arg:
            return ToolResult(False, "", error="Missing required parameters: action and path", is_error=True)

        valid, error, media_path = self._validate_path(path_arg)
        if not valid:
            return ToolResult(False, "", error=error, is_error=True)
        if not media_path.exists() or not media_path.is_file():
            return ToolResult(False, "", error=f"Media file not found: {media_path}", is_error=True)

        output_dir = self._resolve_output_dir(arguments.get("output_dir"), media_path)
        output_dir.mkdir(parents=True, exist_ok=True)

        try:
            if action == "inspect":
                return await self._inspect(media_path, output_dir)
            if action == "transcribe":
                return await self._transcribe(media_path, output_dir, arguments)
            if action == "sample_frames":
                return await self._sample_frames(media_path, output_dir, arguments)
            if action == "summarize":
                return await self._summarize(media_path, output_dir, arguments)
            if action == "qa":
                return await self._qa(media_path, output_dir, arguments)
            return ToolResult(False, "", error=f"Unknown action: {action}", is_error=True)
        except Exception as exc:
            logger.exception("Video tool failed")
            return ToolResult(False, "", error=f"Video tool failed: {exc}", is_error=True)

    def _validate_path(self, path_str: str) -> tuple[bool, str, Path]:
        try:
            candidate = Path(path_str).expanduser()
            if not candidate.is_absolute():
                candidate = (self.workspace_path / candidate)
            resolved = candidate.resolve()
        except Exception as exc:
            return False, f"Invalid path: {exc}", Path()
        return True, "", resolved

    def _resolve_output_dir(self, output_dir_arg: str | None, media_path: Path) -> Path:
        if output_dir_arg:
            candidate = Path(output_dir_arg).expanduser()
            if not candidate.is_absolute():
                candidate = self.workspace_path / candidate
            return candidate.resolve()
        safe_stem = media_path.stem.replace(" ", "_")
        return (self.workspace_path / ".antaris_video" / safe_stem).resolve()

    async def _inspect(self, media_path: Path, output_dir: Path) -> ToolResult:
        ffprobe = shutil.which("ffprobe")
        if not ffprobe:
            return ToolResult(False, "", error="ffprobe is required for inspect action", is_error=True)

        cmd = [
            ffprobe,
            "-v", "error",
            "-print_format", "json",
            "-show_format",
            "-show_streams",
            str(media_path),
        ]
        result = await self._run(cmd)
        if result.returncode != 0:
            return ToolResult(False, "", error=f"ffprobe failed: {result.output}", is_error=True)

        payload = json.loads(result.output or "{}")
        report_path = output_dir / "inspect.json"
        report_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")

        format_info = payload.get("format", {})
        streams = payload.get("streams", [])
        duration = format_info.get("duration", "unknown")
        size = format_info.get("size", "unknown")
        stream_lines = []
        for stream in streams:
            codec_type = stream.get("codec_type", "unknown")
            codec_name = stream.get("codec_name", "?")
            bits = []
            if codec_type == "video":
                bits.append(f"{stream.get('width', '?')}x{stream.get('height', '?')}")
                if stream.get("avg_frame_rate"):
                    bits.append(f"fps={stream.get('avg_frame_rate')}")
            if codec_type == "audio":
                if stream.get("sample_rate"):
                    bits.append(f"{stream.get('sample_rate')}Hz")
                if stream.get("channels"):
                    bits.append(f"{stream.get('channels')}ch")
            details = ", ".join(bits)
            stream_lines.append(f"- {codec_type}: {codec_name}" + (f" ({details})" if details else ""))

        content = (
            f"Media: {media_path}\n"
            f"Duration: {duration}s\n"
            f"Size: {size} bytes\n"
            f"Artifacts: {report_path}\n"
            f"Streams:\n" + ("\n".join(stream_lines) if stream_lines else "- none")
        )
        return ToolResult(True, content)

    async def _transcribe(self, media_path: Path, output_dir: Path, arguments: dict) -> ToolResult:
        whisper = shutil.which("whisper")
        ffmpeg = shutil.which("ffmpeg")
        if not whisper:
            return ToolResult(False, "", error="whisper CLI is required for transcribe action", is_error=True)
        if not ffmpeg:
            return ToolResult(False, "", error="ffmpeg is required for transcribe action", is_error=True)

        transcript_txt = output_dir / "transcript.txt"
        transcript_json = output_dir / "transcript.json"
        if transcript_txt.exists() and transcript_json.exists() and not arguments.get("force", False):
            text = transcript_txt.read_text(encoding="utf-8")
            return ToolResult(True, self._format_transcript_result(media_path, transcript_txt, transcript_json, text, cached=True))

        model = arguments.get("whisper_model", "base")
        language = arguments.get("language")
        with tempfile.TemporaryDirectory(prefix="antaris-video-audio-") as tmpdir:
            audio_path = Path(tmpdir) / "audio.wav"
            extract_cmd = [
                ffmpeg, "-y", "-i", str(media_path), "-vn", "-ac", "1", "-ar", "16000", str(audio_path)
            ]
            extract = await self._run(extract_cmd)
            if extract.returncode != 0:
                return ToolResult(False, "", error=f"ffmpeg audio extraction failed: {extract.output}", is_error=True)

            whisper_cmd = [
                whisper,
                str(audio_path),
                "--model", str(model),
                "--output_dir", tmpdir,
                "--output_format", "all",
                "--verbose", "False",
            ]
            if language:
                whisper_cmd.extend(["--language", str(language)])
            transcribed = await self._run(whisper_cmd, timeout=max(self.default_timeout, 1800))
            if transcribed.returncode != 0:
                return ToolResult(False, "", error=f"whisper failed: {transcribed.output}", is_error=True)

            base = audio_path.stem
            txt_src = Path(tmpdir) / f"{base}.txt"
            json_src = Path(tmpdir) / f"{base}.json"
            if not txt_src.exists():
                return ToolResult(False, "", error="Whisper did not produce transcript text output", is_error=True)
            shutil.copy2(txt_src, transcript_txt)
            if json_src.exists():
                shutil.copy2(json_src, transcript_json)
            else:
                transcript_json.write_text("{}", encoding="utf-8")

        text = transcript_txt.read_text(encoding="utf-8")
        return ToolResult(True, self._format_transcript_result(media_path, transcript_txt, transcript_json, text, cached=False))

    def _format_transcript_result(self, media_path: Path, transcript_txt: Path, transcript_json: Path, text: str, cached: bool) -> str:
        preview = text.strip()
        if len(preview) > 2000:
            preview = preview[:2000].rstrip() + "\n...[truncated]"
        cached_note = " (cached)" if cached else ""
        return (
            f"Transcript ready{cached_note} for {media_path}\n"
            f"Text: {transcript_txt}\n"
            f"JSON: {transcript_json}\n\n"
            f"Preview:\n{preview}"
        )

    async def _sample_frames(self, media_path: Path, output_dir: Path, arguments: dict) -> ToolResult:
        ffmpeg = shutil.which("ffmpeg")
        ffprobe = shutil.which("ffprobe")
        if not ffmpeg or not ffprobe:
            return ToolResult(False, "", error="ffmpeg and ffprobe are required for sample_frames action", is_error=True)

        frames_dir = output_dir / "frames"
        frames_dir.mkdir(parents=True, exist_ok=True)
        force = arguments.get("force", False)
        if force:
            for existing in frames_dir.glob("frame_*.jpg"):
                existing.unlink(missing_ok=True)

        max_frames = int(arguments.get("max_frames", 6))
        interval_seconds = arguments.get("interval_seconds")
        duration = await self._probe_duration(media_path)
        if duration is None:
            return ToolResult(False, "", error="Unable to determine media duration", is_error=True)

        if interval_seconds is None:
            interval_seconds = max(duration / max(max_frames, 1), 0.5)
        timestamps = self._build_timestamps(duration, float(interval_seconds), max_frames)
        created = []
        for idx, ts in enumerate(timestamps, start=1):
            out_path = frames_dir / f"frame_{idx:03d}.jpg"
            if out_path.exists() and not force:
                created.append((ts, out_path))
                continue
            cmd = [
                ffmpeg,
                "-y",
                "-ss", f"{ts:.3f}",
                "-i", str(media_path),
                "-frames:v", "1",
                "-q:v", "2",
                str(out_path),
            ]
            result = await self._run(cmd)
            if result.returncode != 0:
                return ToolResult(False, "", error=f"Frame extraction failed at {ts:.2f}s: {result.output}", is_error=True)
            created.append((ts, out_path))

        index_path = output_dir / "frames.json"
        index_payload = [{"timestamp_seconds": round(ts, 3), "path": str(path)} for ts, path in created]
        index_path.write_text(json.dumps(index_payload, indent=2), encoding="utf-8")

        lines = [f"Sampled {len(created)} frame(s) from {media_path}", f"Index: {index_path}"]
        lines.extend(f"- {ts:.2f}s -> {path}" for ts, path in created)
        return ToolResult(True, "\n".join(lines))

    async def _summarize(self, media_path: Path, output_dir: Path, arguments: dict) -> ToolResult:
        context = await self._build_analysis_context(media_path, output_dir, arguments)
        prompt = arguments.get("prompt") or (
            "Summarize this video or audio artifact. Include: what it is, key moments/topics, "
            "notable visual changes if available, and a concise action-oriented takeaway."
        )
        summary = await self._ask_llm(prompt, context)
        out_path = output_dir / "summary.md"
        out_path.write_text(summary, encoding="utf-8")
        return ToolResult(True, f"Summary ready for {media_path}\nPath: {out_path}\n\n{summary}")

    async def _qa(self, media_path: Path, output_dir: Path, arguments: dict) -> ToolResult:
        question = arguments.get("question")
        if not question:
            return ToolResult(False, "", error="qa action requires question", is_error=True)
        context = await self._build_analysis_context(media_path, output_dir, arguments)
        answer = await self._ask_llm(
            f"Answer the user's question about this video/audio artifact. If the evidence is incomplete, say so.\n\nQuestion: {question}",
            context,
        )
        out_path = output_dir / "qa.md"
        rendered = f"Question: {question}\n\nAnswer:\n{answer}"
        out_path.write_text(rendered, encoding="utf-8")
        return ToolResult(True, f"Q&A ready for {media_path}\nPath: {out_path}\n\n{rendered}")

    async def _build_analysis_context(self, media_path: Path, output_dir: Path, arguments: dict) -> str:
        parts: list[str] = []
        inspect = await self._inspect(media_path, output_dir)
        if inspect.success:
            parts.append("## Media inspection\n" + inspect.content)

        transcript = await self._transcribe(media_path, output_dir, arguments)
        if transcript.success:
            transcript_path = output_dir / "transcript.txt"
            transcript_text = transcript_path.read_text(encoding="utf-8") if transcript_path.exists() else transcript.content
            if len(transcript_text) > 12000:
                transcript_text = transcript_text[:12000].rstrip() + "\n...[truncated]"
            parts.append("## Transcript\n" + transcript_text)
        else:
            parts.append("## Transcript\nUnavailable: " + (transcript.error or "unknown error"))

        if arguments.get("include_frame_analysis", True) and self._looks_like_video(media_path):
            frames = await self._sample_frames(media_path, output_dir, arguments)
            if frames.success:
                frames_index = output_dir / "frames.json"
                frame_context = await self._analyze_frames_from_index(frames_index)
                parts.append("## Frame analysis\n" + frame_context)
            else:
                parts.append("## Frame analysis\nUnavailable: " + (frames.error or "unknown error"))

        return "\n\n".join(parts)

    async def _analyze_frames_from_index(self, index_path: Path) -> str:
        if not index_path.exists():
            return "No frames available."
        try:
            payload = json.loads(index_path.read_text(encoding="utf-8"))
        except Exception:
            return "Frame index unreadable."

        providers = getattr(self.dispatcher, "providers", {}) if self.dispatcher else {}
        if not providers:
            lines = []
            for item in payload:
                lines.append(f"- {item.get('timestamp_seconds', '?')}s: frame at {item.get('path')}")
            return "Vision provider unavailable. Frame paths only:\n" + "\n".join(lines)

        provider = next(iter(providers.values()))
        analyses = []
        for item in payload[:8]:
            frame_path = item.get("path")
            if not frame_path:
                continue
            try:
                description = await self._analyze_frame(provider, frame_path, item.get("timestamp_seconds"))
            except Exception as exc:
                description = f"Frame analysis failed for {frame_path}: {exc}"
            analyses.append(description)
        return "\n".join(analyses) if analyses else "No frame analyses produced."

    async def _analyze_frame(self, provider: Any, frame_path: str, timestamp: Any) -> str:
        import base64

        path = Path(frame_path)
        media_type = mimetypes.guess_type(path.name)[0] or "image/jpeg"
        image_b64 = base64.b64encode(path.read_bytes()).decode("utf-8")
        messages = [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": "Briefly describe this sampled video frame and any salient action, objects, or on-screen text."},
                    {
                        "type": "image",
                        "source": {
                            "type": "base64",
                            "media_type": media_type,
                            "data": image_b64,
                        },
                    },
                ],
            }
        ]
        response = await provider.complete(
            messages=messages,
            system="You analyze video frames concisely and accurately.",
            max_tokens=300,
            temperature=0.2,
        )
        return f"- {timestamp}s: {response.content.strip()}"

    async def _ask_llm(self, prompt: str, context: str) -> str:
        providers = getattr(self.dispatcher, "providers", {}) if self.dispatcher else {}
        if not providers:
            raise RuntimeError("No LLM providers available for video summarize/qa")
        provider = next(iter(providers.values()))
        response = await provider.complete(
            messages=[{"role": "user", "content": f"{prompt}\n\nContext:\n{context}"}],
            system="You are a careful multimodal analyst. Use the provided transcript and frame evidence only.",
            max_tokens=1200,
            temperature=0.3,
        )
        return response.content.strip()

    def _select_multimodal_provider(self, providers: dict[str, Any]) -> Any | None:
        for name in ("anthropic", "openai", "google"):
            provider = providers.get(name)
            if provider is not None:
                return provider
        return next(iter(providers.values()), None)

    def _select_text_provider(self, providers: dict[str, Any]) -> Any | None:
        for name in ("anthropic", "openai", "google", "ollama"):
            provider = providers.get(name)
            if provider is not None:
                return provider
        return next(iter(providers.values()), None)

    async def _probe_duration(self, media_path: Path) -> float | None:
        ffprobe = shutil.which("ffprobe")
        if not ffprobe:
            return None
        cmd = [
            ffprobe,
            "-v", "error",
            "-show_entries", "format=duration",
            "-of", "default=noprint_wrappers=1:nokey=1",
            str(media_path),
        ]
        result = await self._run(cmd)
        if result.returncode != 0:
            return None
        try:
            return float((result.output or "").strip())
        except Exception:
            return None

    def _build_timestamps(self, duration: float, interval_seconds: float, max_frames: int) -> list[float]:
        if duration <= 0:
            return [0.0]
        timestamps = []
        ts = 0.0
        while ts < duration and len(timestamps) < max_frames:
            timestamps.append(min(ts, max(duration - 0.1, 0.0)))
            ts += max(interval_seconds, 0.5)
        if not timestamps:
            timestamps = [0.0]
        return timestamps

    def _looks_like_video(self, media_path: Path) -> bool:
        suffix = media_path.suffix.lower()
        if suffix in _VIDEO_EXTENSIONS:
            return True
        if suffix in _AUDIO_EXTENSIONS:
            return False
        guessed, _ = mimetypes.guess_type(media_path.name)
        return bool(guessed and guessed.startswith("video/"))

    async def _run(self, cmd: list[str], timeout: int | None = None):
        process = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
        )
        try:
            stdout, _ = await asyncio.wait_for(
                process.communicate(),
                timeout=timeout or self.default_timeout,
            )
        except asyncio.TimeoutError:
            process.kill()
            await process.wait()
            class TimeoutResult:
                returncode = 124
                output = "Command timed out"
            return TimeoutResult()

        class Result:
            returncode = process.returncode
            output = (stdout or b"").decode("utf-8", errors="replace")

        return Result()
