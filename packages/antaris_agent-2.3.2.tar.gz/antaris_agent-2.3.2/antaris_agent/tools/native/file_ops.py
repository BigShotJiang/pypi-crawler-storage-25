from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict, List

from .base import NativeTool, ToolResult

logger = logging.getLogger(__name__)


class FileOpsTool(NativeTool):
    def __init__(self, workspace_path: str):
        self.workspace_path = Path(workspace_path).resolve()

    @property
    def name(self) -> str:
        return "file_ops"

    @property
    def description(self) -> str:
        return "File operations: read, write, edit, list files"

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "operation": {
                    "type": "string",
                    "description": "File operation to perform",
                    "enum": ["read", "write", "edit", "list"]
                },
                "path": {
                    "type": "string",
                    "description": "File or directory path"
                },
                "content": {
                    "type": "string",
                    "description": "Content to write (required for write operation)"
                },
                "old_text": {
                    "type": "string",
                    "description": "Text to find and replace (required for edit operation)"
                },
                "new_text": {
                    "type": "string",
                    "description": "Replacement text (required for edit operation)"
                }
            },
            "required": ["operation", "path"]
        }

    def _validate_path(self, path_str: str) -> tuple[bool, str, Path]:
        """Validate that path is within workspace and safe."""
        try:
            # Convert to Path and resolve
            target_path = (self.workspace_path / path_str).resolve()
            workspace_resolved = self.workspace_path.resolve()
            
            # Proper path containment check (not string prefix)
            try:
                target_path.relative_to(workspace_resolved)
            except ValueError:
                return False, "Path traversal attempt detected", target_path
            
            return True, "", target_path
        except Exception as e:
            return False, f"Invalid path: {e}", Path()

    async def execute(self, arguments: dict) -> ToolResult:
        operation = arguments.get("operation")
        path_str = arguments.get("path")

        if not operation or not path_str:
            return ToolResult(
                success=False,
                content="",
                error="Missing required parameters: operation and path",
                is_error=True
            )

        # Validate path
        is_valid, error_msg, target_path = self._validate_path(path_str)
        if not is_valid:
            return ToolResult(
                success=False,
                content="",
                error=error_msg,
                is_error=True
            )

        try:
            if operation == "read":
                return await self._read_file(target_path)
            elif operation == "write":
                content = arguments.get("content", "")
                return await self._write_file(target_path, content)
            elif operation == "edit":
                old_text = arguments.get("old_text")
                new_text = arguments.get("new_text")
                if old_text is None or new_text is None:
                    return ToolResult(
                        success=False,
                        content="",
                        error="Edit operation requires both old_text and new_text",
                        is_error=True
                    )
                return await self._edit_file(target_path, old_text, new_text)
            elif operation == "list":
                return await self._list_directory(target_path)
            else:
                return ToolResult(
                    success=False,
                    content="",
                    error=f"Unknown operation: {operation}",
                    is_error=True
                )

        except Exception as e:
            logger.exception("Unexpected error in file operation")
            return ToolResult(
                success=False,
                content="",
                error=f"Unexpected error: {e}",
                is_error=True
            )

    async def _read_file(self, path: Path) -> ToolResult:
        """Read file contents with 100KB limit."""
        try:
            if not path.exists():
                return ToolResult(
                    success=False,
                    content="",
                    error=f"File not found: {path}",
                    is_error=True
                )

            if not path.is_file():
                return ToolResult(
                    success=False,
                    content="",
                    error=f"Path is not a file: {path}",
                    is_error=True
                )

            # Read with size limit (100KB = 102400 bytes)
            content = path.read_text(encoding='utf-8')
            if len(content) > 102400:
                content = content[:102400] + "\n\n[Content truncated at 100KB...]"

            return ToolResult(
                success=True,
                content=content
            )

        except UnicodeDecodeError:
            return ToolResult(
                success=False,
                content="",
                error="File contains non-UTF8 content and cannot be read as text",
                is_error=True
            )
        except PermissionError:
            return ToolResult(
                success=False,
                content="",
                error="Permission denied reading file",
                is_error=True
            )

    async def _write_file(self, path: Path, content: str) -> ToolResult:
        """Write content to file, creating parent directories if needed."""
        try:
            # Create parent directories
            path.parent.mkdir(parents=True, exist_ok=True)
            
            # Write content
            path.write_text(content, encoding='utf-8')
            
            return ToolResult(
                success=True,
                content=f"Successfully wrote {len(content)} characters to {path}"
            )

        except PermissionError:
            return ToolResult(
                success=False,
                content="",
                error="Permission denied writing file",
                is_error=True
            )

    async def _edit_file(self, path: Path, old_text: str, new_text: str) -> ToolResult:
        """Find and replace text in file."""
        try:
            if not path.exists():
                return ToolResult(
                    success=False,
                    content="",
                    error=f"File not found: {path}",
                    is_error=True
                )

            if not path.is_file():
                return ToolResult(
                    success=False,
                    content="",
                    error=f"Path is not a file: {path}",
                    is_error=True
                )

            # Read current content
            content = path.read_text(encoding='utf-8')
            
            # Check if old_text exists
            if old_text not in content:
                return ToolResult(
                    success=False,
                    content="",
                    error="Text to replace not found in file",
                    is_error=True
                )

            # Replace and write back
            new_content = content.replace(old_text, new_text)
            path.write_text(new_content, encoding='utf-8')
            
            # Count replacements
            count = content.count(old_text)
            
            return ToolResult(
                success=True,
                content=f"Successfully replaced {count} occurrence(s) in {path}"
            )

        except UnicodeDecodeError:
            return ToolResult(
                success=False,
                content="",
                error="File contains non-UTF8 content and cannot be edited",
                is_error=True
            )
        except PermissionError:
            return ToolResult(
                success=False,
                content="",
                error="Permission denied editing file",
                is_error=True
            )

    async def _list_directory(self, path: Path) -> ToolResult:
        """List files in directory recursively, max 500 entries."""
        try:
            if not path.exists():
                return ToolResult(
                    success=False,
                    content="",
                    error=f"Directory not found: {path}",
                    is_error=True
                )

            if not path.is_dir():
                return ToolResult(
                    success=False,
                    content="",
                    error=f"Path is not a directory: {path}",
                    is_error=True
                )

            # Collect files recursively
            files = []
            dirs = []
            count = 0
            
            for item in path.rglob("*"):
                if count >= 500:
                    break
                
                # Get relative path from workspace
                rel_path = item.relative_to(self.workspace_path)
                
                if item.is_file():
                    size = item.stat().st_size
                    files.append(f"  {rel_path} ({size} bytes)")
                elif item.is_dir():
                    dirs.append(f"  {rel_path}/")
                
                count += 1

            # Format output
            result_lines = []
            if dirs:
                result_lines.append("Directories:")
                result_lines.extend(sorted(dirs))
                result_lines.append("")
            
            if files:
                result_lines.append("Files:")
                result_lines.extend(sorted(files))
            
            if count >= 500:
                result_lines.append("\n[Listing truncated at 500 entries]")

            content = "\n".join(result_lines) if result_lines else "Directory is empty"

            return ToolResult(
                success=True,
                content=content
            )

        except PermissionError:
            return ToolResult(
                success=False,
                content="",
                error="Permission denied accessing directory",
                is_error=True
            )