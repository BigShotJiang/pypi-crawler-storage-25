from __future__ import annotations

import asyncio
import logging
from typing import Any, Dict

from .base import NativeTool, ToolResult

logger = logging.getLogger(__name__)


class TTSTool(NativeTool):
    def __init__(self, default_voice: str = "Samantha"):
        """Initialize TTSTool with default voice."""
        self.default_voice = default_voice

    @property
    def name(self) -> str:
        return "tts"

    @property
    def description(self) -> str:
        return "Convert text to speech using macOS say command"

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "text": {
                    "type": "string",
                    "description": "Text to convert to speech"
                },
                "voice": {
                    "type": "string",
                    "description": "Voice to use for speech (optional)",
                    "default": "Samantha"
                },
                "rate": {
                    "type": "integer",
                    "description": "Speech rate in words per minute (optional, default 180)",
                    "default": 180,
                    "minimum": 100,
                    "maximum": 500
                }
            },
            "required": ["text"]
        }

    async def execute(self, arguments: dict) -> ToolResult:
        text = arguments.get("text")
        voice = arguments.get("voice", self.default_voice)
        rate = arguments.get("rate", 180)

        if not text:
            return ToolResult(
                success=False,
                content="",
                error="Missing required parameter: text",
                is_error=True
            )

        # Validate rate
        rate = max(100, min(500, rate))

        # Escape text for shell safety
        # Basic escaping - we could make this more robust
        safe_text = text.replace('"', '\\"').replace('\\', '\\\\')

        logger.info("TTS tool executing: voice=%s rate=%d text_length=%d", voice, rate, len(text))

        try:
            # Build say command
            cmd_args = [
                "say",
                "-v", voice,
                "-r", str(rate),
                safe_text
            ]

            # Execute asynchronously
            process = await asyncio.create_subprocess_exec(
                *cmd_args,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )

            # Wait for completion (with timeout)
            try:
                stdout, stderr = await asyncio.wait_for(
                    process.communicate(),
                    timeout=60.0  # Max 60 seconds for speech
                )
                exit_code = process.returncode
            except asyncio.TimeoutError:
                process.kill()
                await process.wait()
                return ToolResult(
                    success=False,
                    content="",
                    error="TTS command timed out after 60 seconds",
                    is_error=True
                )

            # Check if successful
            if exit_code != 0:
                error_msg = stderr.decode('utf-8', errors='replace') if stderr else f"Exit code: {exit_code}"
                return ToolResult(
                    success=False,
                    content="",
                    error=f"TTS command failed: {error_msg}",
                    is_error=True
                )

            # Success
            result_content = f"✅ Text-to-speech completed\n"
            result_content += f"Voice: {voice}\n"
            result_content += f"Rate: {rate} WPM\n"
            result_content += f"Text length: {len(text)} characters\n"
            
            if len(text) > 100:
                result_content += f"Preview: {text[:100]}..."
            else:
                result_content += f"Text: {text}"

            logger.info("TTS tool completed successfully")

            return ToolResult(
                success=True,
                content=result_content
            )

        except FileNotFoundError:
            return ToolResult(
                success=False,
                content="",
                error="TTS command 'say' not found (macOS required)",
                is_error=True
            )
        except Exception as e:
            logger.exception("Unexpected error in TTS")
            return ToolResult(
                success=False,
                content="",
                error=f"Unexpected TTS error: {e}",
                is_error=True
            )