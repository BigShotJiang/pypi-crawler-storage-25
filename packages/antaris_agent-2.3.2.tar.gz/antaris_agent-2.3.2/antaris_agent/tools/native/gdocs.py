from __future__ import annotations

import asyncio
import logging

try:
    from googleapiclient.errors import HttpError
except ImportError:
    HttpError = Exception  # type: ignore[assignment,misc]

from .base import NativeTool, ToolResult
from .google_auth import GoogleAuthManager, NOT_AUTHORIZED_MSG

logger = logging.getLogger(__name__)


def _build_docs_service(auth: GoogleAuthManager):
    from googleapiclient.discovery import build
    return build("docs", "v1", credentials=auth.get_credentials(), cache_discovery=False)


def _build_drive_service(auth: GoogleAuthManager):
    from googleapiclient.discovery import build
    return build("drive", "v3", credentials=auth.get_credentials(), cache_discovery=False)


def _extract_text(doc: dict) -> str:
    """Extract plain text from a Google Docs document body."""
    text_parts = []
    body = doc.get("body", {})
    for element in body.get("content", []):
        paragraph = element.get("paragraph")
        if not paragraph:
            continue
        for elem in paragraph.get("elements", []):
            run = elem.get("textRun")
            if run:
                text_parts.append(run.get("content", ""))
    return "".join(text_parts)


class DocsReadTool(NativeTool):
    def __init__(self, auth_manager: GoogleAuthManager):
        self._auth = auth_manager

    @property
    def name(self) -> str:
        return "docs_read"

    @property
    def description(self) -> str:
        return "Read the full plain-text content of a Google Docs document."

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "document_id": {"type": "string", "description": "Google Docs document ID"},
            },
            "required": ["document_id"],
        }

    async def execute(self, arguments: dict) -> ToolResult:
        if not self._auth.is_authorized():
            return ToolResult(success=False, content="", error=NOT_AUTHORIZED_MSG, is_error=True)

        document_id = arguments["document_id"].strip()

        def _fetch():
            svc = _build_docs_service(self._auth)
            doc = svc.documents().get(documentId=document_id).execute()
            return _extract_text(doc)

        try:
            text = await asyncio.get_running_loop().run_in_executor(None, _fetch)
            return ToolResult(success=True, content=text or "(document is empty)")
        except HttpError as e:
            return ToolResult(success=False, content="", error=str(e), is_error=True)


class DocsAppendTool(NativeTool):
    def __init__(self, auth_manager: GoogleAuthManager):
        self._auth = auth_manager

    @property
    def name(self) -> str:
        return "docs_append"

    @property
    def description(self) -> str:
        return "Append text to the end of a Google Docs document."

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "document_id": {"type": "string"},
                "text": {"type": "string", "description": "Text to append"},
            },
            "required": ["document_id", "text"],
        }

    async def execute(self, arguments: dict) -> ToolResult:
        if not self._auth.is_authorized():
            return ToolResult(success=False, content="", error=NOT_AUTHORIZED_MSG, is_error=True)

        document_id = arguments["document_id"].strip()
        text = arguments["text"]

        def _append():
            svc = _build_docs_service(self._auth)
            # Get current end index to know where to insert
            doc = svc.documents().get(documentId=document_id).execute()
            body_content = doc.get("body", {}).get("content", [])
            # End index is the last element's endIndex minus 1 (before the final newline)
            end_index = 1
            if body_content:
                last = body_content[-1]
                end_index = last.get("endIndex", 1) - 1

            requests = [
                {
                    "insertText": {
                        "location": {"index": end_index},
                        "text": "\n" + text,
                    }
                }
            ]
            svc.documents().batchUpdate(
                documentId=document_id, body={"requests": requests}
            ).execute()

        try:
            await asyncio.get_running_loop().run_in_executor(None, _append)
            return ToolResult(success=True, content="Text appended to document.")
        except HttpError as e:
            return ToolResult(success=False, content="", error=str(e), is_error=True)


class DocsCreateTool(NativeTool):
    def __init__(self, auth_manager: GoogleAuthManager):
        self._auth = auth_manager

    @property
    def name(self) -> str:
        return "docs_create"

    @property
    def description(self) -> str:
        return "Create a new Google Docs document, optionally with initial content."

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "title": {"type": "string", "description": "Document title"},
                "content": {"type": "string", "description": "Initial content (optional)"},
            },
            "required": ["title"],
        }

    async def execute(self, arguments: dict) -> ToolResult:
        if not self._auth.is_authorized():
            return ToolResult(success=False, content="", error=NOT_AUTHORIZED_MSG, is_error=True)

        title = arguments["title"]
        content = arguments.get("content", "")

        def _create():
            svc = _build_docs_service(self._auth)
            doc = svc.documents().create(body={"title": title}).execute()
            doc_id = doc.get("documentId", "")
            link = f"https://docs.google.com/document/d/{doc_id}/edit"

            if content:
                requests = [
                    {
                        "insertText": {
                            "location": {"index": 1},
                            "text": content,
                        }
                    }
                ]
                svc.documents().batchUpdate(
                    documentId=doc_id, body={"requests": requests}
                ).execute()

            return doc_id, link

        try:
            doc_id, link = await asyncio.get_running_loop().run_in_executor(None, _create)
            return ToolResult(
                success=True,
                content=f"Document created.\nID: {doc_id}\nLink: {link}",
            )
        except HttpError as e:
            return ToolResult(success=False, content="", error=str(e), is_error=True)
