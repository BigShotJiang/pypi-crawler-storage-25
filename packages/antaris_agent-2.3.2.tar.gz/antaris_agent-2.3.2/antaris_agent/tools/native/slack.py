from __future__ import annotations

import asyncio
import logging
import re
from datetime import datetime, timezone
from typing import Any, Dict, Optional

import httpx

from .base import NativeTool, ToolResult

logger = logging.getLogger(__name__)

SLACK_BASE_URL = "https://slack.com/api/"
NOT_AUTHORIZED_MSG = (
    "Slack not connected. Add your bot token to the config."
)

# Slack channel/DM/group/workspace IDs: uppercase letter prefix (C/D/G/W)
# followed by 8+ uppercase alphanumeric characters (no underscores, no lowercase).
_SLACK_ID_RE = re.compile(r'^[CDGW][A-Z0-9]{8,}$')


# ---------------------------------------------------------------------------
# Auth manager
# ---------------------------------------------------------------------------

class SlackAuthManager:
    """Holds a Slack bot token and exposes auth helpers."""

    def __init__(self, bot_token: str) -> None:
        self._bot_token = bot_token

    def is_authorized(self) -> bool:
        """Return True if a bot token is set and non-empty."""
        return bool(self._bot_token and self._bot_token.strip())

    def get_token(self) -> str:
        """Return the bot token."""
        return self._bot_token


# ---------------------------------------------------------------------------
# Internal HTTP helpers (sync — called via run_in_executor)
# ---------------------------------------------------------------------------

def _headers(token: str) -> Dict[str, str]:
    return {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
    }


def _get(token: str, method: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """HTTP GET to a Slack API method. Returns parsed JSON dict."""
    url = SLACK_BASE_URL + method
    with httpx.Client(timeout=30.0) as client:
        resp = client.get(url, headers=_headers(token), params=params or {})
        resp.raise_for_status()
        return resp.json()


def _post(token: str, method: str, payload: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """HTTP POST to a Slack API method. Returns parsed JSON dict."""
    url = SLACK_BASE_URL + method
    with httpx.Client(timeout=30.0) as client:
        resp = client.post(url, headers=_headers(token), json=payload or {})
        resp.raise_for_status()
        return resp.json()


def _resolve_channel_id(token: str, channel: str) -> Optional[str]:
    """
    Resolve a channel name (with or without leading #) to a Slack channel ID.
    If `channel` already looks like a Slack ID (C/D/G/W prefix + 8+ uppercase
    alphanumeric chars), return it unchanged.
    Returns None if the channel cannot be found.
    """
    # Strip leading # before ID check so "#C01ABC1234" works too
    name_raw = channel.lstrip("#")
    if _SLACK_ID_RE.match(name_raw):
        return name_raw

    name = name_raw.lower()
    cursor = None

    while True:
        params: Dict[str, Any] = {"limit": 200, "types": "public_channel,private_channel"}
        if cursor:
            params["cursor"] = cursor

        data = _get(token, "conversations.list", params)
        if not data.get("ok"):
            logger.warning("conversations.list error: %s", data.get("error"))
            return None

        for ch in data.get("channels", []):
            if ch.get("name", "").lower() == name:
                return ch["id"]

        next_cursor = data.get("response_metadata", {}).get("next_cursor", "")
        if not next_cursor:
            break
        cursor = next_cursor

    return None


def _fmt_ts(ts: str) -> str:
    """Convert a Slack timestamp (e.g. '1700000000.123456') to a human-readable string."""
    try:
        unix = float(ts.split(".")[0])
        dt = datetime.fromtimestamp(unix, tz=timezone.utc)
        return dt.strftime("%Y-%m-%d %H:%M UTC")
    except Exception:
        return ts


# ---------------------------------------------------------------------------
# Base class helper
# ---------------------------------------------------------------------------

class _SlackTool(NativeTool):
    def __init__(self, auth_manager: SlackAuthManager) -> None:
        self._auth = auth_manager

    def _not_auth(self) -> ToolResult:
        return ToolResult(
            success=False,
            content="",
            error=NOT_AUTHORIZED_MSG,
            is_error=True,
        )


# ---------------------------------------------------------------------------
# Tool 1: List channels
# ---------------------------------------------------------------------------

class SlackListChannelsTool(_SlackTool):

    @property
    def name(self) -> str:
        return "slack_list_channels"

    @property
    def description(self) -> str:
        return "List public and private Slack channels the bot has access to"

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "limit": {
                    "type": "integer",
                    "description": "Maximum number of channels to return (default 20)",
                    "default": 20,
                    "minimum": 1,
                    "maximum": 200,
                }
            },
            "required": [],
        }

    async def execute(self, arguments: dict) -> ToolResult:
        if not self._auth.is_authorized():
            return self._not_auth()

        limit = int(arguments.get("limit", 20))
        token = self._auth.get_token()

        def _fetch() -> Dict[str, Any]:
            return _get(token, "conversations.list", {
                "types": "public_channel,private_channel",
                "limit": min(limit, 200),
                "exclude_archived": "true",
            })

        try:
            loop = asyncio.get_running_loop()
            data = await loop.run_in_executor(None, _fetch)
        except Exception as e:
            return ToolResult(success=False, content="", error=f"Request failed: {e}", is_error=True)

        if not data.get("ok"):
            return ToolResult(success=False, content="", error=f"Slack API error: {data.get('error')}", is_error=True)

        channels = data.get("channels", [])[:limit]
        if not channels:
            return ToolResult(success=True, content="No channels found.")

        lines = [f"Slack Channels ({len(channels)} shown):\n"]
        for ch in channels:
            name = ch.get("name", "unknown")
            ch_id = ch.get("id", "")
            members = ch.get("num_members", "?")
            topic = ch.get("topic", {}).get("value", "") or ""
            topic_str = f" — {topic}" if topic else ""
            private_str = " [private]" if ch.get("is_private") else ""
            lines.append(f"  #{name}{private_str}  (ID: {ch_id}, {members} members){topic_str}")

        return ToolResult(success=True, content="\n".join(lines))


# ---------------------------------------------------------------------------
# Tool 2: Read channel history
# ---------------------------------------------------------------------------

class SlackReadChannelTool(_SlackTool):

    @property
    def name(self) -> str:
        return "slack_read_channel"

    @property
    def description(self) -> str:
        return "Read recent messages from a Slack channel"

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "channel": {
                    "type": "string",
                    "description": "Channel name (e.g. #general) or Slack channel ID",
                },
                "limit": {
                    "type": "integer",
                    "description": "Number of messages to fetch (default 20)",
                    "default": 20,
                    "minimum": 1,
                    "maximum": 100,
                },
            },
            "required": ["channel"],
        }

    async def execute(self, arguments: dict) -> ToolResult:
        if not self._auth.is_authorized():
            return self._not_auth()

        channel_arg = arguments.get("channel", "")
        limit = int(arguments.get("limit", 20))
        token = self._auth.get_token()

        def _resolve() -> Optional[str]:
            return _resolve_channel_id(token, channel_arg)

        def _fetch(ch_id: str) -> Dict[str, Any]:
            return _get(token, "conversations.history", {
                "channel": ch_id,
                "limit": min(limit, 100),
            })

        def _usernames(user_ids: list) -> Dict[str, str]:
            mapping: Dict[str, str] = {}
            for uid in user_ids:
                try:
                    d = _get(token, "users.info", {"user": uid})
                    if d.get("ok"):
                        u = d["user"]
                        mapping[uid] = u.get("profile", {}).get("display_name") or u.get("real_name") or uid
                except Exception:
                    mapping[uid] = uid
            return mapping

        try:
            loop = asyncio.get_running_loop()
            channel_id = await loop.run_in_executor(None, _resolve)
            if not channel_id:
                return ToolResult(
                    success=False,
                    content="",
                    error=f"Could not find channel: {channel_arg}",
                    is_error=True,
                )

            data = await loop.run_in_executor(None, lambda: _fetch(channel_id))
        except Exception as e:
            return ToolResult(success=False, content="", error=f"Request failed: {e}", is_error=True)

        if not data.get("ok"):
            return ToolResult(success=False, content="", error=f"Slack API error: {data.get('error')}", is_error=True)

        messages = data.get("messages", [])
        if not messages:
            return ToolResult(success=True, content=f"No messages found in {channel_arg}.")

        # Collect unique user IDs for username resolution
        user_ids = list({m["user"] for m in messages if "user" in m})
        try:
            usernames = await loop.run_in_executor(None, lambda: _usernames(user_ids))
        except Exception:
            usernames = {}

        # Messages come newest-first; reverse for chronological display
        messages = list(reversed(messages))

        lines = [f"Messages in {channel_arg} (last {len(messages)}):\n"]
        for msg in messages:
            ts = _fmt_ts(msg.get("ts", ""))
            uid = msg.get("user", "bot")
            username = usernames.get(uid, uid)
            text = msg.get("text", "").strip()
            # Trim very long messages
            if len(text) > 500:
                text = text[:497] + "..."
            lines.append(f"[{ts}] {username}: {text}")

        return ToolResult(success=True, content="\n".join(lines))


# ---------------------------------------------------------------------------
# Tool 3: Send message
# ---------------------------------------------------------------------------

class SlackSendMessageTool(_SlackTool):

    @property
    def name(self) -> str:
        return "slack_send_message"

    @property
    def description(self) -> str:
        return "Send a message to a Slack channel or thread"

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "channel": {
                    "type": "string",
                    "description": "Channel name (e.g. #general) or Slack channel ID",
                },
                "message": {
                    "type": "string",
                    "description": "Message text to send",
                },
                "thread_ts": {
                    "type": "string",
                    "description": "Thread timestamp to reply to (optional — omit to send to channel)",
                },
            },
            "required": ["channel", "message"],
        }

    async def execute(self, arguments: dict) -> ToolResult:
        if not self._auth.is_authorized():
            return self._not_auth()

        channel_arg = arguments.get("channel", "")
        message = arguments.get("message", "")
        thread_ts = arguments.get("thread_ts")
        token = self._auth.get_token()

        if not message.strip():
            return ToolResult(
                success=False, content="", error="Message cannot be empty.", is_error=True
            )

        def _resolve() -> Optional[str]:
            return _resolve_channel_id(token, channel_arg)

        def _send(ch_id: str) -> Dict[str, Any]:
            payload: Dict[str, Any] = {"channel": ch_id, "text": message}
            if thread_ts:
                payload["thread_ts"] = thread_ts
            return _post(token, "chat.postMessage", payload)

        try:
            loop = asyncio.get_running_loop()
            channel_id = await loop.run_in_executor(None, _resolve)
            if not channel_id:
                return ToolResult(
                    success=False,
                    content="",
                    error=f"Could not find channel: {channel_arg}",
                    is_error=True,
                )

            data = await loop.run_in_executor(None, lambda: _send(channel_id))
        except Exception as e:
            return ToolResult(success=False, content="", error=f"Request failed: {e}", is_error=True)

        if not data.get("ok"):
            return ToolResult(success=False, content="", error=f"Slack API error: {data.get('error')}", is_error=True)

        msg_ts = data.get("ts", "")
        human_ts = _fmt_ts(msg_ts) if msg_ts else "unknown time"
        reply_info = f" (in thread {thread_ts})" if thread_ts else ""
        return ToolResult(
            success=True,
            content=f"Message sent to {channel_arg}{reply_info} at {human_ts} (ts: {msg_ts})",
        )


# ---------------------------------------------------------------------------
# Tool 4: Search messages
# ---------------------------------------------------------------------------

class SlackSearchTool(_SlackTool):

    @property
    def name(self) -> str:
        return "slack_search"

    @property
    def description(self) -> str:
        return (
            "Search Slack messages across all channels. "
            "Requires search:read scope on the token."
        )

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Search query string",
                },
                "count": {
                    "type": "integer",
                    "description": "Number of results to return (default 10)",
                    "default": 10,
                    "minimum": 1,
                    "maximum": 100,
                },
            },
            "required": ["query"],
        }

    async def execute(self, arguments: dict) -> ToolResult:
        if not self._auth.is_authorized():
            return self._not_auth()

        query = arguments.get("query", "")
        count = int(arguments.get("count", 10))
        token = self._auth.get_token()

        if not query.strip():
            return ToolResult(
                success=False, content="", error="Search query cannot be empty.", is_error=True
            )

        def _fetch() -> Dict[str, Any]:
            return _get(token, "search.messages", {
                "query": query,
                "count": min(count, 100),
                "sort": "timestamp",
                "sort_dir": "desc",
            })

        try:
            loop = asyncio.get_running_loop()
            data = await loop.run_in_executor(None, _fetch)
        except Exception as e:
            return ToolResult(success=False, content="", error=f"Request failed: {e}", is_error=True)

        if not data.get("ok"):
            err = data.get("error", "unknown")
            if err == "not_allowed_token_type":
                return ToolResult(
                    success=False,
                    content="",
                    error="Search requires a user token with search:read scope (bot tokens cannot search).",
                    is_error=True,
                )
            return ToolResult(success=False, content="", error=f"Slack API error: {err}", is_error=True)

        matches = data.get("messages", {}).get("matches", [])
        if not matches:
            return ToolResult(success=True, content=f"No results found for '{query}'.")

        lines = [f"Search results for '{query}' ({len(matches)} found):\n"]
        for i, m in enumerate(matches[:count], 1):
            channel_name = m.get("channel", {}).get("name", "unknown")
            username = m.get("username", m.get("user", "unknown"))
            text = m.get("text", "").strip()
            if len(text) > 300:
                text = text[:297] + "..."
            ts = _fmt_ts(m.get("ts", ""))
            permalink = m.get("permalink", "")
            lines.append(
                f"{i}. #{channel_name} — {username} [{ts}]\n"
                f"   {text}\n"
                + (f"   {permalink}\n" if permalink else "")
            )

        return ToolResult(success=True, content="\n".join(lines))


# ---------------------------------------------------------------------------
# Tool 5: Get user info
# ---------------------------------------------------------------------------

class SlackGetUserInfoTool(_SlackTool):

    @property
    def name(self) -> str:
        return "slack_get_user_info"

    @property
    def description(self) -> str:
        return "Get profile info for a Slack user by user ID or display name"

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "user": {
                    "type": "string",
                    "description": "Slack user ID (e.g. U01234ABC) or display name to look up",
                },
            },
            "required": ["user"],
        }

    async def execute(self, arguments: dict) -> ToolResult:
        if not self._auth.is_authorized():
            return self._not_auth()

        user_arg = arguments.get("user", "").strip()
        token = self._auth.get_token()

        def _by_id(uid: str) -> Optional[Dict[str, Any]]:
            data = _get(token, "users.info", {"user": uid})
            if data.get("ok"):
                return data.get("user")
            return None

        def _by_name(name: str) -> Optional[Dict[str, Any]]:
            """Scan users.list for a matching display_name or real_name."""
            cursor = None
            name_lower = name.lower()
            while True:
                params: Dict[str, Any] = {"limit": 200}
                if cursor:
                    params["cursor"] = cursor
                data = _get(token, "users.list", params)
                if not data.get("ok"):
                    return None
                for member in data.get("members", []):
                    profile = member.get("profile", {})
                    display = (profile.get("display_name") or "").lower()
                    real = (profile.get("real_name") or "").lower()
                    if name_lower in (display, real):
                        return member
                next_cursor = data.get("response_metadata", {}).get("next_cursor", "")
                if not next_cursor:
                    break
                cursor = next_cursor
            return None

        def _lookup() -> Optional[Dict[str, Any]]:
            # Heuristic: Slack user IDs start with U and are uppercase alphanumeric
            if user_arg.upper().startswith("U") and user_arg.upper() == user_arg and len(user_arg) >= 8:
                return _by_id(user_arg)
            # Try by name; also attempt direct ID lookup as fallback
            result = _by_name(user_arg)
            if result is None:
                result = _by_id(user_arg)
            return result

        try:
            loop = asyncio.get_running_loop()
            member = await loop.run_in_executor(None, _lookup)
        except Exception as e:
            return ToolResult(success=False, content="", error=f"Request failed: {e}", is_error=True)

        if member is None:
            return ToolResult(
                success=False,
                content="",
                error=f"User '{user_arg}' not found.",
                is_error=True,
            )

        profile = member.get("profile", {})
        uid = member.get("id", "")
        display_name = profile.get("display_name") or profile.get("real_name") or "unknown"
        real_name = profile.get("real_name") or ""
        email = profile.get("email") or "(not available)"
        tz = member.get("tz") or "(unknown)"
        status_emoji = profile.get("status_emoji") or ""
        status_text = profile.get("status_text") or "(no status)"
        is_bot = member.get("is_bot", False)
        is_admin = member.get("is_admin", False)

        lines = [
            f"User: {display_name}",
            f"  ID: {uid}",
            f"  Real name: {real_name}",
            f"  Email: {email}",
            f"  Timezone: {tz}",
            f"  Status: {status_emoji} {status_text}".strip(),
        ]
        if is_bot:
            lines.append("  [Bot account]")
        if is_admin:
            lines.append("  [Workspace admin]")

        return ToolResult(success=True, content="\n".join(lines))


# ---------------------------------------------------------------------------
# Tool 6: List DMs
# ---------------------------------------------------------------------------

class SlackListDMsTool(_SlackTool):

    @property
    def name(self) -> str:
        return "slack_list_dms"

    @property
    def description(self) -> str:
        return "List direct message (DM) conversations in Slack"

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "limit": {
                    "type": "integer",
                    "description": "Maximum number of DMs to return (default 10)",
                    "default": 10,
                    "minimum": 1,
                    "maximum": 100,
                },
            },
            "required": [],
        }

    async def execute(self, arguments: dict) -> ToolResult:
        if not self._auth.is_authorized():
            return self._not_auth()

        limit = int(arguments.get("limit", 10))
        token = self._auth.get_token()

        def _fetch() -> Dict[str, Any]:
            return _get(token, "conversations.list", {
                "types": "im",
                "limit": min(limit, 100),
                "exclude_archived": "true",
            })

        def _resolve_user(uid: str) -> str:
            try:
                data = _get(token, "users.info", {"user": uid})
                if data.get("ok"):
                    u = data["user"]
                    return u.get("profile", {}).get("display_name") or u.get("real_name") or uid
            except Exception:
                pass
            return uid

        try:
            loop = asyncio.get_running_loop()
            data = await loop.run_in_executor(None, _fetch)
        except Exception as e:
            return ToolResult(success=False, content="", error=f"Request failed: {e}", is_error=True)

        if not data.get("ok"):
            return ToolResult(success=False, content="", error=f"Slack API error: {data.get('error')}", is_error=True)

        ims = data.get("channels", [])[:limit]
        if not ims:
            return ToolResult(success=True, content="No DM conversations found.")

        # Resolve user names in parallel-ish (sequential in executor to stay safe)
        def _resolve_all(channels: list) -> list:
            result = []
            for im in channels:
                uid = im.get("user", "unknown")
                username = _resolve_user(uid)
                ch_id = im.get("id", "")
                is_open = im.get("is_open", False)
                result.append((ch_id, uid, username, is_open))
            return result

        try:
            resolved = await loop.run_in_executor(None, lambda: _resolve_all(ims))
        except Exception:
            resolved = [(im.get("id", ""), im.get("user", "?"), im.get("user", "?"), False) for im in ims]

        lines = [f"Direct Messages ({len(resolved)} shown):\n"]
        for ch_id, uid, username, is_open in resolved:
            open_str = " [open]" if is_open else ""
            lines.append(f"  {username}  (user ID: {uid}, DM channel ID: {ch_id}){open_str}")

        return ToolResult(success=True, content="\n".join(lines))
