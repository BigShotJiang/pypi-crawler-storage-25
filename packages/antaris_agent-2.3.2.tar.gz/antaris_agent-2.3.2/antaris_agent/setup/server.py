"""
Antaris Agent Setup Server.

Browser-based setup wizard using only stdlib — zero external dependencies.
Runs on localhost:7474 and serves a single-page HTML wizard.
"""

import json
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Optional
from urllib.request import urlopen, Request
from urllib.error import URLError, HTTPError

from antaris_agent.core.config import Config, DEFAULT_CONFIG_PATH, DEFAULT_CONFIG_DIR

WIZARD_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>Antaris Agent Setup</title>
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;background:#fff;color:#111;min-height:100vh;display:flex;flex-direction:column;align-items:center;padding:0 16px 48px}
  #progress-wrap{width:100%;max-width:720px;padding:28px 0 20px}
  #progress-track{background:#e5e7eb;border-radius:99px;height:6px;overflow:hidden}
  #progress-fill{background:#6366f1;height:6px;border-radius:99px;transition:width 0.4s ease}
  .card{width:100%;max-width:720px;padding:36px 40px;animation:fadeIn 0.25s ease}
  @keyframes fadeIn{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}
  h1{font-size:1.9rem;font-weight:700;margin-bottom:10px;line-height:1.2}
  h2{font-size:1.35rem;font-weight:700;margin-bottom:8px}
  h3{font-size:1rem;font-weight:700;margin-bottom:8px}
  .subtitle{color:#6b7280;font-size:0.95rem;line-height:1.6;margin-bottom:22px}
  .muted{color:#6b7280}
  .radio-group{display:flex;flex-direction:column;gap:12px;margin-bottom:24px}
  .radio-card,.tile-card{display:flex;align-items:flex-start;gap:14px;border:2px solid #e5e7eb;border-radius:12px;padding:16px 18px;cursor:pointer;transition:border-color 0.15s,background 0.15s;text-decoration:none;color:inherit}
  .tile-card{display:block}
  .radio-card:hover,.tile-card:hover{border-color:#a5b4fc}
  .radio-card.selected,.tile-card.selected{border-color:#6366f1;background:#f5f3ff}
  .radio-card input{margin-top:3px;accent-color:#6366f1;flex-shrink:0}
  .radio-label{font-weight:600;font-size:0.95rem}
  .radio-desc{font-size:0.82rem;color:#6b7280;margin-top:2px}
  .badge{display:inline-block;background:#fef3c7;color:#92400e;font-size:0.7rem;font-weight:700;padding:1px 6px;border-radius:99px;margin-left:6px;vertical-align:middle}
  .badge-rec{background:#ede9fe;color:#5b21b6}
  .badge-soft{background:#eef2ff;color:#4338ca}
  .field{margin-bottom:20px}
  .field label{display:block;font-weight:600;font-size:0.9rem;margin-bottom:7px;color:#374151}
  .field input[type=text],.field input[type=password]{width:100%;padding:10px 14px;border:2px solid #e5e7eb;border-radius:8px;font-size:0.95rem;outline:none;transition:border-color 0.15s}
  .field input:focus{border-color:#6366f1}
  .verify-row{display:flex;gap:10px;align-items:center;margin-top:8px}
  .verify-row input{flex:1}
  .btn{display:inline-flex;align-items:center;justify-content:center;gap:7px;padding:11px 26px;border-radius:9px;font-size:0.95rem;font-weight:600;cursor:pointer;border:none;transition:background 0.15s,opacity 0.15s;text-decoration:none}
  .btn-primary{background:#6366f1;color:#fff}
  .btn-primary:hover{background:#4f46e5}
  .btn-primary:disabled{opacity:0.55;cursor:not-allowed}
  .btn-secondary{background:#f3f4f6;color:#374151;border:1px solid #e5e7eb}
  .btn-secondary:hover{background:#e5e7eb}
  .btn-sm{padding:8px 16px;font-size:0.85rem}
  .btn-row{display:flex;gap:12px;flex-wrap:wrap;margin-top:8px}
  .token-status{font-size:0.85rem;min-width:60px;font-weight:500}
  .token-status.ok{color:#059669}
  .token-status.err{color:#dc2626}
  .token-status.checking{color:#6b7280}
  .instr{background:#f8f8ff;border-left:3px solid #6366f1;border-radius:0 8px 8px 0;padding:14px 18px;margin-bottom:20px;font-size:0.88rem;line-height:1.65;color:#374151}
  .instr strong{color:#111}
  .success-wrap{text-align:center;padding:20px 0}
  .success-icon{font-size:3.5rem;margin-bottom:18px}
  .divider{height:1px;background:#e5e7eb;margin:20px 0}
  .grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px;margin-bottom:24px}
  .list{display:flex;flex-direction:column;gap:10px;margin:16px 0 24px}
  .list li{margin-left:18px;color:#374151;line-height:1.55}
  .section-box{border:1px solid #e5e7eb;border-radius:12px;padding:16px 18px;margin-bottom:16px;background:#fff}
  .pill-row{display:flex;flex-wrap:wrap;gap:8px;margin-top:10px}
  .pill{display:inline-block;background:#f3f4f6;color:#374151;padding:6px 10px;border-radius:999px;font-size:0.8rem;font-weight:600}
  .summary{background:#fafafa;border:1px solid #e5e7eb;border-radius:12px;padding:16px 18px;margin:14px 0 22px}
  code{background:#f3f4f6;padding:2px 6px;border-radius:6px}
  @media(max-width:640px){.grid{grid-template-columns:1fr}.card{padding:24px 18px}.btn{width:100%}.btn-row{flex-direction:column}}
</style>
</head>
<body>
<div id="progress-wrap">
  <div id="progress-track"><div id="progress-fill" style="width:16%"></div></div>
</div>
<div id="app" class="card"></div>
<script>
const FLOW_STEPS = {
  general: 5,
  integrations: 4,
  automation: 3,
  power: 3,
  all: 7,
};
const START_STEP = {
  general: 10,
  integrations: 20,
  automation: 30,
  power: 40,
  all: 1,
};
const SEARCH = new URLSearchParams(window.location.search);
let state = {
  flow: SEARCH.get('wizard') || 'all',
  step: 1,
  provider: 'anthropic',
  apiKey: '',
  apiKeyValid: null,
  channel: 'telegram',
  telegramToken: '',
  telegramValid: null,
  discordToken: '',
  discordValid: null,
  slackBotToken: '',
  slackAppToken: '',
  slackValid: null,
  botName: 'Altaris',
  securityMode: 'sandboxed',
  ownerUserId: '',
  memoryStore: '',
  googleEnabled: false,
  googleAccount: '',
  mediaEnabled: false,
  webhooksEnabled: false,
  authMonitorEnabled: false,
  extensionsEnabled: true,
  skillsEnabled: true,
  modelSwitchingEnabled: true,
  browserEnabled: false,
  desktopControlEnabled: false,
  terminalControlEnabled: false,
  launched: false,
  testResult: null,
  status: null,
};

function initFlow() {
  const flow = (state.flow || 'all').toLowerCase();
  state.flow = ['general','integrations','automation','power','all'].includes(flow) ? flow : 'all';
  state.step = START_STEP[state.flow] || 1;
}
initFlow();

async function loadStatus() {
  try {
    const res = await fetch('/api/status');
    const data = await res.json();
    state.status = data;
    hydrateFromStatus(data);
    render();
  } catch (_) {}
}

function hydrateFromStatus(data) {
  if (!data) return;
  if (data.bot_name) state.botName = data.bot_name;
  if (data.provider) state.provider = data.provider;
  if (data.security_mode) state.securityMode = data.security_mode;
  if (data.owner_user_id) state.ownerUserId = data.owner_user_id;
  if (data.memory_store) state.memoryStore = data.memory_store;
  if (data.google_workspace && data.google_workspace.enabled) {
    state.googleEnabled = true;
    state.googleAccount = data.google_workspace.account || '';
  }
  if (data.automation) {
    state.mediaEnabled = !!data.automation.media_enabled;
    state.webhooksEnabled = !!data.automation.webhooks_enabled;
    state.authMonitorEnabled = !!data.automation.auth_monitor_enabled;
  }
  if (data.power) {
    state.extensionsEnabled = data.power.extensions_enabled !== false;
    state.skillsEnabled = data.power.skills_enabled !== false;
    state.modelSwitchingEnabled = data.power.model_switching_enabled !== false;
    state.browserEnabled = !!data.power.browser_enabled;
    state.desktopControlEnabled = !!data.power.desktop_control_enabled;
    state.terminalControlEnabled = !!data.power.terminal_control_enabled;
  }
}

function totalSteps(){ return FLOW_STEPS[state.flow] || 7; }
function currentStepIndex(){
  const s = state.step;
  if (state.flow === 'general') return ({10:1,11:2,12:3,13:4,14:5})[s] || 1;
  if (state.flow === 'integrations') return ({20:1,21:2,22:3,23:4})[s] || 1;
  if (state.flow === 'automation') return ({30:1,31:2,32:3})[s] || 1;
  if (state.flow === 'power') return ({40:1,41:2,42:3})[s] || 1;
  return s;
}
function setProgress(){
  const pct = Math.max(8, Math.round((currentStepIndex()/totalSteps())*100));
  document.getElementById('progress-fill').style.width = pct + '%';
}

function statusClass(v){ if(v===true) return 'ok'; if(v===false) return 'err'; if(v==='checking') return 'checking'; return ''; }
function tokenStatusHtml(v){ if(v===true) return 'Verified'; if(v===false) return 'Invalid'; if(v==='checking') return 'Checking…'; return ''; }
function esc(v){ return String(v || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }

function render() {
  setProgress();
  const app = document.getElementById('app');
  switch(state.step) {
    case 1: app.innerHTML = stepWizardHub(); break;
    case 2: app.innerHTML = stepProvider(); break;
    case 3: app.innerHTML = stepChannel(); break;
    case 4: app.innerHTML = stepChannelSetup(); break;
    case 5: app.innerHTML = stepSecurity(); break;
    case 6: app.innerHTML = stepBotName(); break;
    case 7: app.innerHTML = stepDone(); break;
    case 10: app.innerHTML = stepGeneralWelcome(); break;
    case 11: app.innerHTML = stepProvider(); break;
    case 12: app.innerHTML = stepSecurity(); break;
    case 13: app.innerHTML = stepGeneralProfile(); break;
    case 14: app.innerHTML = stepFlowDone('general'); break;
    case 20: app.innerHTML = stepIntegrationsWelcome(); break;
    case 21: app.innerHTML = stepChannelsOnly(); break;
    case 22: app.innerHTML = stepGoogleWorkspace(); break;
    case 23: app.innerHTML = stepFlowDone('integrations'); break;
    case 30: app.innerHTML = stepAutomationWelcome(); break;
    case 31: app.innerHTML = stepAutomationOptions(); break;
    case 32: app.innerHTML = stepFlowDone('automation'); break;
    case 40: app.innerHTML = stepPowerWelcome(); break;
    case 41: app.innerHTML = stepPowerOptions(); break;
    case 42: app.innerHTML = stepFlowDone('power'); break;
    default: app.innerHTML = stepWizardHub(); break;
  }
  bindEvents();
}

function nextFlow(step){
  const map = {
    1: 2, 2: 3, 3: 4, 4: 5, 5: 6, 6: 7,
    10: 11, 11: 12, 12: 13, 13: 14,
    20: 21, 21: 22, 22: 23,
    30: 31, 31: 32,
    40: 41, 41: 42,
  };
  return map[step] || step;
}
function prevFlow(step){
  const map = {
    2: 1, 3: 2, 4: 3, 5: 4, 6: 5, 7: 6,
    11: 10, 12: 11, 13: 12, 14: 13,
    21: 20, 22: 21, 23: 22,
    31: 30, 32: 31,
    41: 40, 42: 41,
  };
  return map[step] || step;
}
function gotoFlow(flow){
  state.flow = flow;
  state.step = START_STEP[flow] || 1;
  const url = flow === 'all' ? '/' : '/?wizard=' + encodeURIComponent(flow);
  history.replaceState({}, '', url);
  render();
}

function stepWizardHub() {
  const configured = state.status && state.status.configured;
  return `
    <h1>Choose a setup path</h1>
    <p class="subtitle">Antaris now uses multiple focused wizards instead of one giant onboarding flow. Start simple, then come back later for more power.</p>
    ${configured ? `<div class="instr"><strong>Re-entry is built in.</strong><br>Your current config was detected. Open any wizard below to add channels, enable integrations, or unlock advanced controls without starting over.</div>` : ''}
    <div class="grid">
      ${wizardTile('general','General setup','Core identity, provider, security, memory path, owner ID','Recommended first run')}
      ${wizardTile('integrations','Integrations wizard','Discord, Telegram, Slack, Google Workspace and return-later expansion','Channels + workspace')}
      ${wizardTile('automation','Automation/platform wizard','Media/docs, webhooks, and auth monitoring surfaces','Hooks + automation')}
      ${wizardTile('power','Power-user/local control wizard','Extensions, skills, model controls, browser/desktop/terminal control','Advanced / local')}
    </div>
    <div class="divider"></div>
    <h3>Prefer the classic guided flow?</h3>
    <p class="subtitle">You can still run the original all-in-one setup. It now ends with the wizard hub so advanced areas stay discoverable.</p>
    <div class="btn-row">
      <button class="btn btn-secondary" id="btn-classic-flow">Run full setup →</button>
    </div>`;
}
function wizardTile(flow, title, desc, badge){
  return `<div class="tile-card" data-flow="${flow}">
    <div class="radio-label">${title} <span class="badge badge-soft">${badge}</span></div>
    <div class="radio-desc" style="margin-top:8px">${desc}</div>
  </div>`;
}
function stepWelcome() { return stepWizardHub(); }

function stepGeneralWelcome(){
  return `
    <h1>General setup</h1>
    <p class="subtitle">Start with the essentials: who your assistant is, which model it uses, and the default safety posture. This keeps day one lightweight.</p>
    <ul class="list">
      <li>Bot identity + default provider</li>
      <li>Security mode and core runtime defaults</li>
      <li>Owner ID and memory store basics</li>
      <li>You can return later for integrations and power features</li>
    </ul>
    <div class="btn-row">
      <button class="btn btn-secondary" id="btn-back-hub">← Wizard hub</button>
      <button class="btn btn-primary" id="btn-next-gw">Get started →</button>
    </div>`;
}
function stepIntegrationsWelcome(){
  return `
    <h1>Integrations wizard</h1>
    <p class="subtitle">Connect chat surfaces and workspace tooling without dumping every feature on the user upfront.</p>
    <div class="pill-row">
      <span class="pill">Discord</span><span class="pill">Telegram</span><span class="pill">Slack</span><span class="pill">Google Workspace</span>
    </div>
    <div class="btn-row" style="margin-top:24px">
      <button class="btn btn-secondary" id="btn-back-hub">← Wizard hub</button>
      <button class="btn btn-primary" id="btn-next-intro">Continue →</button>
    </div>`;
}
function stepAutomationWelcome(){
  return `
    <h1>Automation / platform wizard</h1>
    <p class="subtitle">Turn on feature clusters for documents, media, hooks, and auth observability when you’re ready for them.</p>
    <div class="pill-row">
      <span class="pill">PDF / media</span><span class="pill">Webhooks</span><span class="pill">Auth monitoring</span>
    </div>
    <div class="btn-row" style="margin-top:24px">
      <button class="btn btn-secondary" id="btn-back-hub">← Wizard hub</button>
      <button class="btn btn-primary" id="btn-next-auto">Continue →</button>
    </div>`;
}
function stepPowerWelcome(){
  return `
    <h1>Power-user / local control wizard</h1>
    <p class="subtitle">Advanced local control stays opt-in: extensions, skills, model switching, and machine-control surfaces.</p>
    <div class="pill-row">
      <span class="pill">Extensions</span><span class="pill">Skills</span><span class="pill">Model switching</span><span class="pill">Browser / desktop / terminal control</span>
    </div>
    <div class="btn-row" style="margin-top:24px">
      <button class="btn btn-secondary" id="btn-back-hub">← Wizard hub</button>
      <button class="btn btn-primary" id="btn-next-power">Continue →</button>
    </div>`;
}

function stepProvider() {
  const anthropicSel = state.provider === 'anthropic' ? 'selected' : '';
  const openaiSel    = state.provider === 'openai'    ? 'selected' : '';
  const googleSel    = state.provider === 'google'    ? 'selected' : '';
  const statusHtml = tokenStatusHtml(state.apiKeyValid);
  const providerHints = {
    anthropic: 'API key or OAuth token — get yours at <a href="https://console.anthropic.com" target="_blank">console.anthropic.com</a> — great default for personality and reasoning',
    openai: 'API key or OAuth token — get yours at <a href="https://platform.openai.com" target="_blank">platform.openai.com</a> — strong general-purpose option',
    google: 'Get your key at <a href="https://aistudio.google.com/apikey" target="_blank">aistudio.google.com</a> — free tier available',
  };
  const providerLabels = { anthropic: 'Anthropic', openai: 'OpenAI', google: 'Google' };
  return `
    <h2>Choose your AI provider</h2>
    <p class="subtitle">This determines which model powers your assistant by default.</p>
    <div class="radio-group" id="provider-group">
      <label class="radio-card ${anthropicSel}" data-val="anthropic">
        <input type="radio" name="provider" value="anthropic" ${state.provider==='anthropic'?'checked':''}/>
        <div>
          <div class="radio-label">Anthropic Claude <span class="badge badge-rec">Recommended</span></div>
          <div class="radio-desc">Sonnet / Opus family — best default for assistant behavior</div>
        </div>
      </label>
      <label class="radio-card ${openaiSel}" data-val="openai">
        <input type="radio" name="provider" value="openai" ${state.provider==='openai'?'checked':''}/>
        <div>
          <div class="radio-label">OpenAI GPT</div>
          <div class="radio-desc">GPT-5.x family — strong all-around choice</div>
        </div>
      </label>
      <label class="radio-card ${googleSel}" data-val="google">
        <input type="radio" name="provider" value="google" ${state.provider==='google'?'checked':''}/>
        <div>
          <div class="radio-label">Google Gemini</div>
          <div class="radio-desc">Fast multimodal option with easy API access</div>
        </div>
      </label>
    </div>
    <p class="subtitle" style="font-size:0.82rem;margin-bottom:12px">${providerHints[state.provider] || providerHints.anthropic}</p>
    <div class="field">
      <label>${providerLabels[state.provider] || 'API'} API Key or OAuth Token</label>
      <div class="verify-row">
        <input type="password" id="api-key-input" value="${esc(state.apiKey)}" placeholder="sk-ant-... / sk-proj-... / sk-ant-oat01-..." autocomplete="off"/>
        <button class="btn btn-secondary btn-sm" id="btn-verify-api">Verify</button>
        <span class="token-status ${statusClass(state.apiKeyValid)}" id="api-key-status">${statusHtml}</span>
      </div>
    </div>
    <div class="btn-row">
      <button class="btn btn-secondary" id="btn-back">← Back</button>
      <button class="btn btn-primary" id="btn-next-provider" ${state.apiKeyValid !== true ? 'disabled' : ''}>Next →</button>
    </div>`;
}

function stepChannel() {
  const sel = state.channel;
  return `
    <h2>Choose your channel</h2>
    <p class="subtitle">Where should people talk to your assistant?</p>
    <div class="radio-group" id="channel-group">
      <label class="radio-card ${sel==='telegram'?'selected':''}" data-val="telegram">
        <input type="radio" name="channel" value="telegram" ${sel==='telegram'?'checked':''}/>
        <div><div class="radio-label">Telegram <span class="badge">★ Easiest</span></div><div class="radio-desc">Fastest path to a live bot</div></div>
      </label>
      <label class="radio-card ${sel==='discord'?'selected':''}" data-val="discord">
        <input type="radio" name="channel" value="discord" ${sel==='discord'?'checked':''}/>
        <div><div class="radio-label">Discord</div><div class="radio-desc">Best for server-based collaboration</div></div>
      </label>
      <label class="radio-card ${sel==='both'?'selected':''}" data-val="both">
        <input type="radio" name="channel" value="both" ${sel==='both'?'checked':''}/>
        <div><div class="radio-label">Both</div><div class="radio-desc">Telegram and Discord simultaneously</div></div>
      </label>
      <label class="radio-card ${sel==='slack'?'selected':''}" data-val="slack">
        <input type="radio" name="channel" value="slack" ${sel==='slack'?'checked':''}/>
        <div><div class="radio-label">Slack</div><div class="radio-desc">Workspace-native team use</div></div>
      </label>
      <label class="radio-card ${sel==='terminal'?'selected':''}" data-val="terminal">
        <input type="radio" name="channel" value="terminal" ${sel==='terminal'?'checked':''}/>
        <div><div class="radio-label">Terminal only</div><div class="radio-desc">No tokens needed — local dev mode</div></div>
      </label>
    </div>
    <div class="btn-row">
      <button class="btn btn-secondary" id="btn-back">← Back</button>
      <button class="btn btn-primary" id="btn-next-channel">Next →</button>
    </div>`;
}
function stepChannelsOnly(){ return stepChannel(); }

function stepChannelSetup() {
  const ch = state.channel;
  if (ch === 'terminal') {
    state.step = nextFlow(state.step);
    return state.step === 5 ? stepSecurity() : stepGoogleWorkspace();
  }
  let html = `<h2>Set up your channel${ch==='both'?' connections':''}</h2><p class="subtitle">Paste the token(s) below — we’ll verify them before continuing.</p>`;
  if (ch === 'telegram' || ch === 'both') {
    const st = tokenStatusHtml(state.telegramValid);
    html += `
      <div class="instr"><strong>Telegram</strong><br>1. Open Telegram and search for <strong>@BotFather</strong><br>2. Send <code>/newbot</code> and follow the prompts<br>3. Copy the token BotFather gives you and paste it below</div>
      <div class="field"><label>Telegram Bot Token</label><div class="verify-row"><input type="password" id="tg-token-input" value="${esc(state.telegramToken)}" placeholder="123456789:ABCdef..." autocomplete="off"/><button class="btn btn-secondary btn-sm" id="btn-verify-tg">Verify</button><span class="token-status ${statusClass(state.telegramValid)}" id="tg-status">${st}</span></div></div>`;
  }
  if (ch === 'both') html += `<div class="divider"></div>`;
  if (ch === 'discord' || ch === 'both') {
    const st = tokenStatusHtml(state.discordValid);
    html += `
      <div class="instr"><strong>Discord</strong><br>1. Go to <strong>discord.com/developers</strong> → New Application<br>2. Open the <strong>Bot</strong> tab → Reset Token → Copy token<br>3. Enable <strong>Message Content Intent</strong><br>4. Paste the token below, then invite the bot to your server</div>
      <div class="field"><label>Discord Bot Token</label><div class="verify-row"><input type="password" id="dc-token-input" value="${esc(state.discordToken)}" placeholder="MTI3..." autocomplete="off"/><button class="btn btn-secondary btn-sm" id="btn-verify-dc">Verify</button><span class="token-status ${statusClass(state.discordValid)}" id="dc-status">${st}</span></div></div>`;
  }
  if (ch === 'slack') {
    const st = tokenStatusHtml(state.slackValid);
    html += `
      <div class="instr"><strong>Slack (Socket Mode)</strong><br>1. Go to <strong>api.slack.com/apps</strong> → Create App<br>2. Add bot scopes like <code>chat:write</code><br>3. Install to workspace, copy the bot token (xoxb-...)<br>4. Enable Socket Mode and create an app token (xapp-...)</div>
      <div class="field"><label>Slack Bot Token (xoxb-...)</label><div class="verify-row"><input type="password" id="slack-bot-input" value="${esc(state.slackBotToken)}" placeholder="xoxb-..." autocomplete="off"/><button class="btn btn-secondary btn-sm" id="btn-verify-slack">Verify</button><span class="token-status ${statusClass(state.slackValid)}" id="slack-status">${st}</span></div></div>
      <div class="field"><label>Slack App Token (xapp-...)</label><input type="password" id="slack-app-input" value="${esc(state.slackAppToken)}" placeholder="xapp-..." autocomplete="off"/></div>`;
  }
  html += `<div class="btn-row"><button class="btn btn-secondary" id="btn-back">← Back</button><button class="btn btn-primary" id="btn-next-ch-setup" ${canProceedChannelSetup()?'':'disabled'}>Next →</button></div>`;
  return html;
}
function canProceedChannelSetup() {
  const ch = state.channel;
  if (ch === 'telegram') return state.telegramValid === true;
  if (ch === 'discord') return state.discordValid === true;
  if (ch === 'both') return state.telegramValid === true && state.discordValid === true;
  if (ch === 'slack') return state.slackValid === true;
  return true;
}

function stepSecurity() {
  const modes = [
    { val: 'sandboxed', label: 'Sandboxed', badge: '★ Recommended', desc: 'Bot can only access its own workspace. Best default for most users.' },
    { val: 'open', label: 'Open', badge: 'Power users', desc: 'Full host access. Maximum capability for trusted local setups.' },
    { val: 'locked', label: 'Locked', badge: 'Maximum security', desc: 'Encrypted memory and approval gates for sensitive environments.' },
  ];
  const cards = modes.map(m => `<label class="radio-card ${state.securityMode === m.val ? 'selected' : ''}" data-val="${m.val}"><input type="radio" name="security_mode" value="${m.val}" ${state.securityMode === m.val ? 'checked' : ''}/><div><div class="radio-label">${m.label} <span class="badge badge-rec">${m.badge}</span></div><div class="radio-desc">${m.desc}</div></div></label>`).join('');
  return `
    <h2>Choose security mode</h2>
    <p class="subtitle">You can start conservative and relax later if needed.</p>
    <div class="radio-group" id="security-group">${cards}</div>
    <div class="btn-row">
      <button class="btn btn-secondary" id="btn-back">← Back</button>
      <button class="btn btn-primary" id="btn-next-security">Next →</button>
    </div>`;
}

function stepBotName() {
  return `
    <h2>Name your bot</h2>
    <p class="subtitle">This is the final step of the original full flow. After saving, you’ll land back on the wizard hub so you can continue with optional setup areas later.</p>
    <div class="field"><label>Bot name</label><input type="text" id="bot-name-input" value="${esc(state.botName)}" placeholder="Altaris" maxlength="40"/></div>
    <div class="btn-row" style="margin-top:24px">
      <button class="btn btn-secondary" id="btn-back">← Back</button>
      <button class="btn btn-primary" id="btn-next-name">Next →</button>
    </div>`;
}
function stepGeneralProfile() {
  return `
    <h2>General runtime defaults</h2>
    <p class="subtitle">A couple of core details that make later re-entry smoother.</p>
    <div class="field"><label>Bot name</label><input type="text" id="bot-name-input" value="${esc(state.botName)}" placeholder="Altaris" maxlength="40"/></div>
    <div class="field"><label>Owner user ID (optional)</label><input type="text" id="owner-user-id-input" value="${esc(state.ownerUserId)}" placeholder="Discord owner ID for alerts and privileged actions"/></div>
    <div class="field"><label>Memory store path (optional override)</label><input type="text" id="memory-store-input" value="${esc(state.memoryStore)}" placeholder="~/.antaris/memory"/></div>
    <div class="btn-row"><button class="btn btn-secondary" id="btn-back">← Back</button><button class="btn btn-primary" id="btn-save-general">Save general setup</button></div>`;
}

function stepGoogleWorkspace(){
  return `
    <h2>Google Workspace</h2>
    <p class="subtitle">Make Gmail, Calendar, Drive, Docs, and Sheets first-class assistant tools later — without forcing it on day one.</p>
    <label class="radio-card ${state.googleEnabled ? 'selected' : ''}" id="google-toggle-card">
      <input type="checkbox" id="google-enabled-input" ${state.googleEnabled ? 'checked' : ''}/>
      <div><div class="radio-label">Enable Google Workspace tool layer</div><div class="radio-desc">Uses the machine's authorized <code>gog</code> CLI when available.</div></div>
    </label>
    <div class="field" style="margin-top:16px"><label>Google account (optional)</label><input type="text" id="google-account-input" value="${esc(state.googleAccount)}" placeholder="user@example.com"/></div>
    <div class="btn-row"><button class="btn btn-secondary" id="btn-back">← Back</button><button class="btn btn-primary" id="btn-save-integrations">Save integrations</button></div>`;
}

function stepAutomationOptions(){
  return `
    <h2>Automation / platform features</h2>
    <p class="subtitle">Choose which product surfaces should be unlocked now.</p>
    ${toggleCard('media-enabled-input','Enable PDF / media / document handling','Transcripts, video understanding, PDF ingestion, and document flows',state.mediaEnabled)}
    ${toggleCard('webhooks-enabled-input','Enable hooks / webhooks','Expose webhook and event-driven automation surfaces',state.webhooksEnabled)}
    ${toggleCard('auth-monitor-enabled-input','Enable auth monitoring','Turn on auth and credential monitoring extension behavior',state.authMonitorEnabled)}
    <div class="btn-row"><button class="btn btn-secondary" id="btn-back">← Back</button><button class="btn btn-primary" id="btn-save-automation">Save automation settings</button></div>`;
}
function stepPowerOptions(){
  return `
    <h2>Power-user / local control features</h2>
    <p class="subtitle">Advanced features stay discoverable but optional.</p>
    ${toggleCard('extensions-enabled-input','Extensions / plugins enabled','Load extension and plugin surfaces',state.extensionsEnabled)}
    ${toggleCard('skills-enabled-input','Skills enabled','Expose skill-driven workflows and discoverability',state.skillsEnabled)}
    ${toggleCard('model-switch-enabled-input','Model switching / thinking controls','Allow model-switching and thinking-level controls',state.modelSwitchingEnabled)}
    ${toggleCard('browser-enabled-input','Browser control','Enable browser automation tools',state.browserEnabled)}
    ${toggleCard('desktop-enabled-input','Desktop control','Enable desktop control extension',state.desktopControlEnabled)}
    ${toggleCard('terminal-enabled-input','Terminal control','Enable terminal control/local shell extension layer',state.terminalControlEnabled)}
    <div class="btn-row"><button class="btn btn-secondary" id="btn-back">← Back</button><button class="btn btn-primary" id="btn-save-power">Save power settings</button></div>`;
}
function toggleCard(id, title, desc, enabled){
  return `<label class="radio-card ${enabled ? 'selected' : ''}" data-toggle-for="${id}"><input type="checkbox" id="${id}" ${enabled ? 'checked' : ''}/><div><div class="radio-label">${title}</div><div class="radio-desc">${desc}</div></div></label>`;
}

function stepDone() {
  const chLabel = {telegram:'Telegram',discord:'Discord',both:'Telegram & Discord',slack:'Slack',terminal:'terminal'}[state.channel] || state.channel;
  const secDesc = { sandboxed:'Sandboxed mode: isolated workspace', open:'Open mode: full machine access', locked:'Locked mode: owner-only memory + approvals' }[state.securityMode] || '';
  if (state.launched) {
    const test = state.testResult || {};
    const testHtml = test.success
      ? `<p style="color:#059669;font-weight:600;margin-top:12px">✅ Connection test passed for ${esc(test.channel || chLabel)}</p>`
      : `<p style="color:#92400e;font-weight:600;margin-top:12px">⚠️ Saved config${test.error ? ' — ' + esc(test.error) : ''}</p>`;
    return `
      <div class="success-wrap">
        <div class="success-icon">✅</div>
        <h2>Antaris is configured</h2>
        <p class="subtitle">Your core setup is saved. You can now run <code>antaris start</code> — and you can always return to add more capabilities.</p>
        <div class="summary">
          <div><strong>Provider:</strong> ${esc(state.provider)}</div>
          <div><strong>Channel:</strong> ${esc(chLabel)}</div>
          <div><strong>Security:</strong> ${esc(secDesc)}</div>
        </div>
        ${testHtml}
        <div class="btn-row" style="justify-content:center;margin-top:18px">
          <a class="btn btn-secondary" href="/">Open wizard hub</a>
        </div>
      </div>`;
  }
  return `
    <h2>Review and launch</h2>
    <p class="subtitle">This saves your base configuration, then hands you back to the wizard hub for optional follow-up setup.</p>
    <div class="summary">
      <div><strong>Bot name:</strong> ${esc(state.botName)}</div>
      <div><strong>Provider:</strong> ${esc(state.provider)}</div>
      <div><strong>Channel:</strong> ${esc(chLabel)}</div>
      <div><strong>Security:</strong> ${esc(secDesc)}</div>
    </div>
    <div class="btn-row">
      <button class="btn btn-secondary" id="btn-back">← Back</button>
      <button class="btn btn-primary" id="btn-launch">🚀 Launch Bot</button>
    </div>`;
}
function stepFlowDone(flow){
  const labels = {general:'General setup saved', integrations:'Integrations saved', automation:'Automation settings saved', power:'Power-user settings saved'};
  return `
    <div class="success-wrap">
      <div class="success-icon">✨</div>
      <h2>${labels[flow] || 'Saved'}</h2>
      <p class="subtitle">Nice. You can return to the wizard hub anytime to unlock more features without redoing the rest.</p>
      <div class="btn-row" style="justify-content:center">
        <a class="btn btn-secondary" href="/">Back to wizard hub</a>
      </div>
    </div>`;
}

async function verifyToken(kind, token) {
  const res = await fetch('/api/validate-token', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({provider: kind, token}) });
  return await res.json();
}
async function saveCurrentFlow(extra = {}) {
  const payload = {
    wizard: state.flow,
    bot_name: state.botName,
    provider: state.provider,
    api_key: state.apiKey,
    channel: state.channel,
    telegram_token: state.telegramToken,
    discord_token: state.discordToken,
    slack_bot_token: state.slackBotToken,
    slack_app_token: state.slackAppToken,
    security_mode: state.securityMode,
    owner_user_id: state.ownerUserId,
    memory_store: state.memoryStore,
    google_workspace_enabled: state.googleEnabled,
    google_workspace_account: state.googleAccount,
    media_enabled: state.mediaEnabled,
    webhooks_enabled: state.webhooksEnabled,
    auth_monitor_enabled: state.authMonitorEnabled,
    extensions_enabled: state.extensionsEnabled,
    skills_enabled: state.skillsEnabled,
    model_switching_enabled: state.modelSwitchingEnabled,
    browser_enabled: state.browserEnabled,
    desktop_control_enabled: state.desktopControlEnabled,
    terminal_control_enabled: state.terminalControlEnabled,
    ...extra,
  };
  const res = await fetch('/api/setup', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) });
  return await res.json();
}

function bindEvents() {
  document.querySelectorAll('[data-flow]').forEach(el => el.addEventListener('click', () => gotoFlow(el.getAttribute('data-flow'))));
  const classic = document.getElementById('btn-classic-flow');
  if (classic) classic.addEventListener('click', () => gotoFlow('all'));
  document.querySelectorAll('[data-toggle-for]').forEach(card => card.addEventListener('click', (e) => {
    if (e.target.tagName === 'INPUT') return;
    const id = card.getAttribute('data-toggle-for');
    const input = document.getElementById(id);
    if (input) { input.checked = !input.checked; render(); }
  }));
  const backHub = document.getElementById('btn-back-hub');
  if (backHub) backHub.addEventListener('click', () => gotoFlow('all'));
  const back = document.getElementById('btn-back');
  if (back) back.addEventListener('click', () => { state.step = prevFlow(state.step); render(); });

  document.querySelectorAll('#provider-group .radio-card').forEach(card => card.addEventListener('click', () => {
    state.provider = card.getAttribute('data-val'); state.apiKeyValid = null; render();
  }));
  document.querySelectorAll('#channel-group .radio-card').forEach(card => card.addEventListener('click', () => {
    state.channel = card.getAttribute('data-val'); render();
  }));
  document.querySelectorAll('#security-group .radio-card').forEach(card => card.addEventListener('click', () => {
    state.securityMode = card.getAttribute('data-val'); render();
  }));

  const nextGW = document.getElementById('btn-next-gw');
  if (nextGW) nextGW.addEventListener('click', () => { state.step = 11; render(); });
  const nextIntro = document.getElementById('btn-next-intro');
  if (nextIntro) nextIntro.addEventListener('click', () => { state.step = 21; render(); });
  const nextAuto = document.getElementById('btn-next-auto');
  if (nextAuto) nextAuto.addEventListener('click', () => { state.step = 31; render(); });
  const nextPower = document.getElementById('btn-next-power');
  if (nextPower) nextPower.addEventListener('click', () => { state.step = 41; render(); });

  const verifyApi = document.getElementById('btn-verify-api');
  if (verifyApi) verifyApi.addEventListener('click', async () => {
    state.apiKey = (document.getElementById('api-key-input').value || '').trim();
    state.apiKeyValid = 'checking'; render();
    const data = await verifyToken(state.provider, state.apiKey);
    state.apiKeyValid = !!data.valid; render();
  });
  const nextProvider = document.getElementById('btn-next-provider');
  if (nextProvider) nextProvider.addEventListener('click', () => { state.apiKey = (document.getElementById('api-key-input').value || '').trim(); state.step = nextFlow(state.step); render(); });
  const nextChannel = document.getElementById('btn-next-channel');
  if (nextChannel) nextChannel.addEventListener('click', () => { state.step = nextFlow(state.step); render(); });
  const verifyTg = document.getElementById('btn-verify-tg');
  if (verifyTg) verifyTg.addEventListener('click', async () => { state.telegramToken = (document.getElementById('tg-token-input').value || '').trim(); state.telegramValid='checking'; render(); const data = await verifyToken('telegram', state.telegramToken); state.telegramValid=!!data.valid; render(); });
  const verifyDc = document.getElementById('btn-verify-dc');
  if (verifyDc) verifyDc.addEventListener('click', async () => { state.discordToken = (document.getElementById('dc-token-input').value || '').trim(); state.discordValid='checking'; render(); const data = await verifyToken('discord', state.discordToken); state.discordValid=!!data.valid; render(); });
  const verifySlack = document.getElementById('btn-verify-slack');
  if (verifySlack) verifySlack.addEventListener('click', async () => { state.slackBotToken = (document.getElementById('slack-bot-input').value || '').trim(); state.slackAppToken = (document.getElementById('slack-app-input').value || '').trim(); state.slackValid='checking'; render(); const data = await verifyToken('slack', state.slackBotToken); state.slackValid=!!data.valid && !!state.slackAppToken; render(); });
  const nextChSetup = document.getElementById('btn-next-ch-setup');
  if (nextChSetup) nextChSetup.addEventListener('click', () => { if (document.getElementById('tg-token-input')) state.telegramToken = document.getElementById('tg-token-input').value.trim(); if (document.getElementById('dc-token-input')) state.discordToken = document.getElementById('dc-token-input').value.trim(); if (document.getElementById('slack-bot-input')) state.slackBotToken = document.getElementById('slack-bot-input').value.trim(); if (document.getElementById('slack-app-input')) state.slackAppToken = document.getElementById('slack-app-input').value.trim(); state.step = nextFlow(state.step); render(); });
  const nextSecurity = document.getElementById('btn-next-security');
  if (nextSecurity) nextSecurity.addEventListener('click', () => { state.step = nextFlow(state.step); render(); });
  const nextName = document.getElementById('btn-next-name');
  if (nextName) nextName.addEventListener('click', () => { state.botName = (document.getElementById('bot-name-input').value || 'Altaris').trim(); state.step = nextFlow(state.step); render(); });

  const saveGeneral = document.getElementById('btn-save-general');
  if (saveGeneral) saveGeneral.addEventListener('click', async () => {
    state.botName = (document.getElementById('bot-name-input').value || 'Altaris').trim();
    state.ownerUserId = (document.getElementById('owner-user-id-input').value || '').trim();
    state.memoryStore = (document.getElementById('memory-store-input').value || '').trim();
    const data = await saveCurrentFlow();
    if (data.ok) { state.step = 14; state.status = data.status || state.status; render(); } else alert('Save failed: ' + (data.error || 'Unknown error'));
  });
  const saveIntegrations = document.getElementById('btn-save-integrations');
  if (saveIntegrations) saveIntegrations.addEventListener('click', async () => {
    state.googleEnabled = !!document.getElementById('google-enabled-input').checked;
    state.googleAccount = (document.getElementById('google-account-input').value || '').trim();
    const data = await saveCurrentFlow();
    if (data.ok) { state.step = 23; state.status = data.status || state.status; render(); } else alert('Save failed: ' + (data.error || 'Unknown error'));
  });
  const saveAutomation = document.getElementById('btn-save-automation');
  if (saveAutomation) saveAutomation.addEventListener('click', async () => {
    state.mediaEnabled = !!document.getElementById('media-enabled-input').checked;
    state.webhooksEnabled = !!document.getElementById('webhooks-enabled-input').checked;
    state.authMonitorEnabled = !!document.getElementById('auth-monitor-enabled-input').checked;
    const data = await saveCurrentFlow();
    if (data.ok) { state.step = 32; state.status = data.status || state.status; render(); } else alert('Save failed: ' + (data.error || 'Unknown error'));
  });
  const savePower = document.getElementById('btn-save-power');
  if (savePower) savePower.addEventListener('click', async () => {
    state.extensionsEnabled = !!document.getElementById('extensions-enabled-input').checked;
    state.skillsEnabled = !!document.getElementById('skills-enabled-input').checked;
    state.modelSwitchingEnabled = !!document.getElementById('model-switch-enabled-input').checked;
    state.browserEnabled = !!document.getElementById('browser-enabled-input').checked;
    state.desktopControlEnabled = !!document.getElementById('desktop-enabled-input').checked;
    state.terminalControlEnabled = !!document.getElementById('terminal-enabled-input').checked;
    const data = await saveCurrentFlow();
    if (data.ok) { state.step = 42; state.status = data.status || state.status; render(); } else alert('Save failed: ' + (data.error || 'Unknown error'));
  });

  const launch = document.getElementById('btn-launch');
  if (launch) launch.addEventListener('click', async () => {
    launch.disabled = true; launch.textContent = 'Saving...';
    const data = await saveCurrentFlow({wizard:'all'});
    if (data.ok) { state.launched = true; state.testResult = data.test || {success:false}; state.status = data.status || state.status; render(); }
    else { launch.disabled = false; launch.textContent = '🚀 Launch Bot'; alert('Save failed: ' + (data.error || 'Unknown error')); }
  });
}

loadStatus();
render();
</script>
</body>
</html>
"""


class _WizardHandler(BaseHTTPRequestHandler):
    server_ref: "SetupServer" = None  # type: ignore[assignment]

    def log_message(self, fmt, *args):
        pass

    def do_GET(self):
        if self.path == "/" or self.path.startswith("/?") or self.path == "/index.html":
            self._send_html(WIZARD_HTML)
        elif self.path.startswith("/api/status"):
            self._handle_status()
        else:
            self._send_json({"error": "not found"}, status=404)

    def do_POST(self):
        if self.path == "/api/setup":
            self._handle_setup()
        elif self.path == "/api/validate-token":
            self._handle_validate_token()
        else:
            self._send_json({"error": "not found"}, status=404)

    def _handle_status(self):
        cfg = Config.load()
        data = {
            "configured": False,
            "channels": [],
            "bot_name": "Altaris",
            "provider": "anthropic",
            "security_mode": "sandboxed",
            "owner_user_id": "",
            "memory_store": "",
            "google_workspace": {"enabled": False, "account": ""},
            "automation": {
                "media_enabled": False,
                "webhooks_enabled": False,
                "auth_monitor_enabled": False,
            },
            "power": {
                "extensions_enabled": True,
                "skills_enabled": True,
                "model_switching_enabled": True,
                "browser_enabled": False,
                "desktop_control_enabled": False,
                "terminal_control_enabled": False,
            },
        }
        if cfg:
            data["configured"] = bool(cfg.api_key)
            data["bot_name"] = cfg.bot_name
            data["provider"] = cfg.provider_name
            data["security_mode"] = getattr(cfg, "security_mode", "sandboxed")
            data["owner_user_id"] = getattr(cfg, "owner_user_id", "")
            data["memory_store"] = getattr(cfg, "memory_store", "")
            if cfg.discord_enabled:
                data["channels"].append("discord")
            if cfg.telegram_enabled:
                data["channels"].append("telegram")
            if getattr(cfg, "slack_enabled", False):
                data["channels"].append("slack")
            tools = getattr(cfg, "_tools_config", {}) or {}
            gw = tools.get("google_workspace", {}) if isinstance(tools, dict) else {}
            data["google_workspace"] = {
                "enabled": bool(gw.get("enabled", False)),
                "account": gw.get("account", ""),
            }
            data["automation"] = {
                "media_enabled": bool(tools.get("video", {}).get("enabled", False)),
                "webhooks_enabled": bool(getattr(cfg, "webhooks_enabled", False) or tools.get("webhooks", {}).get("enabled", False)),
                "auth_monitor_enabled": bool(tools.get("auth_monitor", {}).get("enabled", False)),
            }
            data["power"] = {
                "extensions_enabled": bool(getattr(cfg, "extensions_enabled", True)),
                "skills_enabled": bool(tools.get("skills", {}).get("enabled", True)),
                "model_switching_enabled": bool(tools.get("model_control", {}).get("enabled", True)),
                "browser_enabled": bool(tools.get("browser", {}).get("enabled", False)),
                "desktop_control_enabled": bool(tools.get("desktop_control", {}).get("enabled", False)),
                "terminal_control_enabled": bool(tools.get("terminal_control", {}).get("enabled", False)),
            }
        self._send_json(data)

    def _handle_setup(self):
        body = self._read_json_body()
        if body is None:
            self._send_json({"ok": False, "error": "invalid JSON"}, status=400)
            return

        cfg = Config.load() or Config()
        cfg.bot_name = body.get("bot_name", cfg.bot_name) or cfg.bot_name or "Altaris"
        provider = body.get("provider")
        if provider:
            cfg.provider_name = provider
        api_key = body.get("api_key")
        if api_key is not None:
            cfg.api_key = api_key

        if cfg.provider_name == "openai":
            cfg.model = "gpt-5.2"
            cfg.fallback_model = "gpt-3.5-turbo"
        elif cfg.provider_name == "google":
            cfg.model = "gemini-3.1-pro"
            cfg.fallback_model = "gemini-1.5-flash"
        else:
            cfg.model = "claude-sonnet-4-6"
            cfg.fallback_model = "claude-haiku-4-5-20251001"

        channel = body.get("channel", "terminal")
        telegram_token = body.get("telegram_token", cfg.telegram_token or "")
        discord_token = body.get("discord_token", cfg.discord_token or "")
        slack_bot_token = body.get("slack_bot_token", cfg.slack_bot_token or "")
        slack_app_token = body.get("slack_app_token", cfg.slack_app_token or "")

        cfg.telegram_enabled = channel in ("telegram", "both") and bool(telegram_token)
        cfg.telegram_token = telegram_token if cfg.telegram_enabled else ""
        cfg.discord_enabled = channel in ("discord", "both") and bool(discord_token)
        cfg.discord_token = discord_token if cfg.discord_enabled else ""
        cfg.slack_enabled = channel == "slack" and bool(slack_bot_token) and bool(slack_app_token)
        cfg.slack_bot_token = slack_bot_token if cfg.slack_enabled else ""
        cfg.slack_app_token = slack_app_token if cfg.slack_enabled else ""

        security_mode = body.get("security_mode", cfg.security_mode or "sandboxed")
        if security_mode in ("open", "sandboxed", "locked", "standard", "secured", "encrypted"):
            cfg.security_mode = security_mode

        cfg.owner_user_id = body.get("owner_user_id", getattr(cfg, "owner_user_id", "")) or getattr(cfg, "owner_user_id", "")
        memory_store = body.get("memory_store")
        if isinstance(memory_store, str) and memory_store.strip():
            cfg.memory_store = memory_store.strip()

        cfg.extensions_enabled = bool(body.get("extensions_enabled", getattr(cfg, "extensions_enabled", True)))
        cfg.webhooks_enabled = bool(body.get("webhooks_enabled", getattr(cfg, "webhooks_enabled", False)))

        tools = dict(getattr(cfg, "_tools_config", {}) or {})
        def upsert_tool(name, enabled=None, **extra):
            current = dict(tools.get(name, {}) or {})
            if enabled is not None:
                current["enabled"] = bool(enabled)
            current.update({k:v for k,v in extra.items() if v is not None and v != ""})
            tools[name] = current

        upsert_tool("google_workspace", body.get("google_workspace_enabled", tools.get("google_workspace", {}).get("enabled", False)), account=body.get("google_workspace_account", tools.get("google_workspace", {}).get("account", "")))
        upsert_tool("video", body.get("media_enabled", tools.get("video", {}).get("enabled", False)))
        upsert_tool("webhooks", body.get("webhooks_enabled", tools.get("webhooks", {}).get("enabled", False)))
        upsert_tool("auth_monitor", body.get("auth_monitor_enabled", tools.get("auth_monitor", {}).get("enabled", False)))
        upsert_tool("skills", body.get("skills_enabled", tools.get("skills", {}).get("enabled", True)))
        upsert_tool("model_control", body.get("model_switching_enabled", tools.get("model_control", {}).get("enabled", True)))
        upsert_tool("browser", body.get("browser_enabled", tools.get("browser", {}).get("enabled", False)))
        upsert_tool("desktop_control", body.get("desktop_control_enabled", tools.get("desktop_control", {}).get("enabled", False)))
        upsert_tool("terminal_control", body.get("terminal_control_enabled", tools.get("terminal_control", {}).get("enabled", False)))
        cfg._tools_config = tools

        try:
            cfg.save()
            test_result = _test_channel_connection(cfg)
            if self.server_ref:
                self.server_ref._config = cfg
                self.server_ref._setup_complete = True
            status_payload = self._status_from_config(cfg)
            self._send_json({"ok": True, "test": test_result, "status": status_payload})
        except Exception as exc:
            self._send_json({"ok": False, "error": str(exc)}, status=500)

    def _status_from_config(self, cfg: Config) -> dict:
        tools = getattr(cfg, "_tools_config", {}) or {}
        channels = []
        if cfg.discord_enabled:
            channels.append("discord")
        if cfg.telegram_enabled:
            channels.append("telegram")
        if getattr(cfg, "slack_enabled", False):
            channels.append("slack")
        return {
            "configured": bool(cfg.api_key),
            "channels": channels,
            "bot_name": cfg.bot_name,
            "provider": cfg.provider_name,
            "security_mode": cfg.security_mode,
            "owner_user_id": getattr(cfg, "owner_user_id", ""),
            "memory_store": getattr(cfg, "memory_store", ""),
            "google_workspace": {
                "enabled": bool(tools.get("google_workspace", {}).get("enabled", False)),
                "account": tools.get("google_workspace", {}).get("account", ""),
            },
            "automation": {
                "media_enabled": bool(tools.get("video", {}).get("enabled", False)),
                "webhooks_enabled": bool(tools.get("webhooks", {}).get("enabled", False)),
                "auth_monitor_enabled": bool(tools.get("auth_monitor", {}).get("enabled", False)),
            },
            "power": {
                "extensions_enabled": bool(getattr(cfg, "extensions_enabled", True)),
                "skills_enabled": bool(tools.get("skills", {}).get("enabled", True)),
                "model_switching_enabled": bool(tools.get("model_control", {}).get("enabled", True)),
                "browser_enabled": bool(tools.get("browser", {}).get("enabled", False)),
                "desktop_control_enabled": bool(tools.get("desktop_control", {}).get("enabled", False)),
                "terminal_control_enabled": bool(tools.get("terminal_control", {}).get("enabled", False)),
            },
        }

    def _handle_validate_token(self):
        body = self._read_json_body()
        if body is None:
            self._send_json({"valid": False, "error": "invalid JSON"}, status=400)
            return
        provider = body.get("provider", "")
        token = body.get("token", "")
        if not token:
            self._send_json({"valid": False, "error": "Token is required"})
            return
        valid, error = _validate_token(provider, token)
        self._send_json({"valid": valid, "error": error})

    def _read_json_body(self):
        try:
            length = int(self.headers.get("Content-Length", "0"))
            raw = self.rfile.read(length) if length > 0 else b"{}"
            return json.loads(raw)
        except (json.JSONDecodeError, ValueError):
            return None

    def _send_html(self, html: str):
        encoded = html.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(encoded)))
        self.end_headers()
        self.wfile.write(encoded)

    def _send_json(self, data: dict, status: int = 200):
        encoded = json.dumps(data).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(encoded)))
        self.end_headers()
        self.wfile.write(encoded)


def _validate_token(provider: str, token: str) -> tuple[bool, Optional[str]]:
    try:
        if provider == "telegram":
            return _validate_telegram(token)
        elif provider == "discord":
            return _validate_discord(token)
        elif provider == "anthropic":
            return _validate_anthropic(token)
        elif provider == "openai":
            return _validate_openai(token)
        elif provider == "google":
            return _validate_google(token)
        elif provider == "slack":
            return _validate_slack(token)
        else:
            return False, f"Unknown provider: {provider}"
    except Exception as exc:
        return False, str(exc)


def _validate_telegram(token: str) -> tuple[bool, Optional[str]]:
    url = f"https://api.telegram.org/bot{token}/getMe"
    try:
        with urlopen(url, timeout=10) as resp:
            data = json.loads(resp.read())
            if data.get("ok"):
                return True, None
            return False, data.get("description", "Invalid token")
    except HTTPError as e:
        return False, f"HTTP {e.code}"
    except URLError as e:
        return False, str(e.reason)


def _validate_discord(token: str) -> tuple[bool, Optional[str]]:
    url = "https://discord.com/api/v10/users/@me"
    req = Request(url, headers={"Authorization": f"Bot {token}"})
    try:
        with urlopen(req, timeout=10):
            return True, None
    except HTTPError as e:
        if e.code == 401:
            return False, "Unauthorized — check your token"
        return False, f"HTTP {e.code}"
    except URLError as e:
        return False, str(e.reason)


def _validate_anthropic(token: str) -> tuple[bool, Optional[str]]:
    req = Request(
        "https://api.anthropic.com/v1/messages",
        data=json.dumps({"model": "claude-sonnet-4-20250514", "max_tokens": 1, "messages": [{"role": "user", "content": "ping"}]}).encode("utf-8"),
        headers={
            "x-api-key": token,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        },
        method="POST",
    )
    try:
        with urlopen(req, timeout=10):
            return True, None
    except HTTPError as e:
        if e.code == 400:
            return True, None
        if e.code == 401:
            return False, "Unauthorized"
        return False, f"HTTP {e.code}"
    except URLError as e:
        return False, str(e.reason)


def _validate_openai(token: str) -> tuple[bool, Optional[str]]:
    req = Request("https://api.openai.com/v1/models", headers={"Authorization": f"Bearer {token}"})
    try:
        with urlopen(req, timeout=10):
            return True, None
    except HTTPError as e:
        if e.code == 401:
            return False, "Unauthorized"
        return False, f"HTTP {e.code}"
    except URLError as e:
        return False, str(e.reason)


def _validate_google(token: str) -> tuple[bool, Optional[str]]:
    url = f"https://generativelanguage.googleapis.com/v1beta/models?key={token}"
    try:
        with urlopen(url, timeout=10):
            return True, None
    except HTTPError as e:
        if e.code in (400, 403):
            return False, f"HTTP {e.code}"
        return False, f"HTTP {e.code}"
    except URLError as e:
        return False, str(e.reason)


def _validate_slack(token: str) -> tuple[bool, Optional[str]]:
    req = Request("https://slack.com/api/auth.test", headers={"Authorization": f"Bearer {token}"})
    try:
        with urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read())
            if data.get("ok"):
                return True, None
            return False, data.get("error", "Invalid token")
    except HTTPError as e:
        return False, f"HTTP {e.code}"
    except URLError as e:
        return False, str(e.reason)


def _test_channel_connection(cfg: Config) -> dict:
    result = {"channel": None, "success": False, "error": None}
    try:
        if cfg.telegram_enabled and cfg.telegram_token:
            valid, error = _validate_telegram(cfg.telegram_token)
            result.update({"channel": "telegram", "success": valid, "error": error})
        elif cfg.discord_enabled and cfg.discord_token:
            valid, error = _validate_discord(cfg.discord_token)
            result.update({"channel": "discord", "success": valid, "error": error})
        elif getattr(cfg, "slack_enabled", False) and cfg.slack_bot_token:
            valid, error = _validate_slack(cfg.slack_bot_token)
            result.update({"channel": "slack", "success": valid, "error": error})
        else:
            result["channel"] = "terminal"
            result["success"] = True
    except Exception as exc:
        result["error"] = str(exc)
    return result


class SetupServer:
    HOST = "localhost"
    PORT = 7474

    def __init__(self, initial_wizard: str = "all"):
        self._httpd: Optional[HTTPServer] = None
        self._thread: Optional[threading.Thread] = None
        self._setup_complete: bool = False
        self._config: Optional[Config] = None
        self.initial_wizard = initial_wizard

    @property
    def setup_complete(self) -> bool:
        return self._setup_complete

    @property
    def config(self) -> Optional[Config]:
        return self._config

    def start(self, open_browser: bool = True) -> None:
        server_ref = self
        class BoundHandler(_WizardHandler):
            pass
        BoundHandler.server_ref = server_ref
        self._httpd = HTTPServer((self.HOST, self.PORT), BoundHandler)
        self._thread = threading.Thread(target=self._httpd.serve_forever, daemon=True, name="setup-wizard-server")
        self._thread.start()
        if open_browser:
            url = f"http://{self.HOST}:{self.PORT}"
            if self.initial_wizard and self.initial_wizard != "all":
                url += f"/?wizard={self.initial_wizard}"
            webbrowser.open(url)

    def stop(self) -> None:
        if self._httpd:
            self._httpd.shutdown()
            try:
                self._httpd.server_close()
            except Exception:
                pass
            self._httpd = None
        if self._thread:
            self._thread.join(timeout=5)
            self._thread = None
