"""Manifest — sole source of truth for Parsica's segmented storage.

Contract
--------
The manifest file (``manifest.json``) is the authoritative record of the
storage layer's state.  Every consumer of segments, tombstones, or the
hot-buffer state MUST consult the manifest rather than scanning the
filesystem directly.

Contents
~~~~~~~~
``segments``
    Ordered list of immutable segment metadata dicts.  Each entry records
    the filename, sequence number, entry count, min/max created timestamps,
    SHA-256 checksum, and rich index stats (categories, memory types, agent
    ids, etc.).

``tombstones``
    Mapping of *hash → {deleted_at, reason}* for logically deleted entries.
    Tombstones suppress entries during ``load()`` and are resolved during
    compaction when the corresponding segment is merged away.

``hot``
    Advisory counters for the hot buffer (put_count, delete_count,
    last_write_at).  Not authoritative — ``HotBuffer`` is the ground truth.

``generation``
    Monotonically increasing integer incremented on every manifest write.
    Used for optimistic concurrency: ``_verify_generation()`` re-reads the
    on-disk generation before every write and raises
    :class:`ManifestConflictError` if a concurrent writer has already
    advanced it.

Atomicity guarantees
--------------------
Every mutation path (``save()``, ``batch_update()``, individual ``add_*`` /
``remove_*`` methods) follows the same pattern:

1. Acquire ``FileLock`` on ``manifest.json.lock/`` (directory-based lock,
   supports NFS).
2. Call ``_verify_generation()`` — re-read disk, compare generations.
3. Apply in-memory mutations.
4. Increment ``generation`` and update ``updated_at``.
5. Copy current ``manifest.json`` → ``manifest.json.bak`` (atomic rename).
6. Write new ``manifest.json`` via ``atomic_write_json`` (write temp → fsync
   → rename → fsync directory).
7. Release lock.

Step 5 ensures that at any moment either the primary or the backup is the
last-known-good manifest.  ``load()`` falls back to the backup automatically
if the primary is missing or corrupt.

The caller-level ``batch_update()`` context manager lets ``SegmentStore``
batch multiple logical mutations (add segment + update tombstones + reset hot)
into a single lock acquisition and a single generation increment, avoiding
redundant intermediate writes.

FileLock is non-reentrant.  ``SegmentStore`` uses a *separate* store-level
lock for flush/compact serialisation; it never calls ``Manifest`` methods
that would try to re-acquire the manifest lock while the manifest lock is
already held.
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import tempfile
from contextlib import contextmanager
from datetime import datetime, timezone
from glob import glob
from typing import Generator, Optional

from parsica_memory.locking import FileLock
from parsica_memory.utils import atomic_write_json

logger = logging.getLogger("parsica_memory")

_VERSION = "3.2.0"


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------

class ManifestConflictError(RuntimeError):
    """Raised when the on-disk manifest generation diverges from in-memory state.

    This indicates a concurrent writer advanced the generation between the time
    this instance last read the manifest and the time it tried to write.
    Resolution: reload the manifest (``Manifest.load()``) and retry.
    """


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _utcnow_iso() -> str:
    """Return the current UTC time as an ISO-8601 string."""
    return datetime.now(timezone.utc).isoformat()


def _empty_manifest() -> dict:
    """Return a fresh, empty manifest dict."""
    now = _utcnow_iso()
    return {
        "version": _VERSION,
        "generation": 0,
        "created_at": now,
        "updated_at": now,
        "segments": [],
        "hot": {
            "filename": "hot.jsonl",
            "put_count": 0,
            "delete_count": 0,
            "last_write_at": None,
        },
        "tombstones": {},
        "search": {"index_generation": 0},
        "migration": None,
    }


# ---------------------------------------------------------------------------
# Manifest
# ---------------------------------------------------------------------------

class Manifest:
    """Atomic, lock-protected manifest for the segmented storage layer.

    Parameters
    ----------
    segments_dir : str
        Path to the ``segments/`` directory.  The manifest file
        (``manifest.json``), its backup (``manifest.json.bak``), and the
        lock directory (``manifest.json.lock/``) all live here.
    lock_timeout : float
        Maximum seconds to wait for the manifest lock before raising
        ``TimeoutError``.  Default: 30 seconds.

    Notes
    -----
    The constructor acquires the manifest lock once during ``__init__`` to
    load the initial state.  All subsequent writes re-acquire the lock
    independently.

    ``FileLock`` is **non-reentrant**.  Do not call any ``Manifest`` mutating
    method from within a ``batch_update()`` block — that would deadlock.
    Use ``batch_update()`` exclusively for multi-step atomic mutations.
    """

    def __init__(self, segments_dir: str, *, lock_timeout: float = 30.0) -> None:
        self.segments_dir = os.path.abspath(segments_dir)
        self.manifest_path = os.path.join(self.segments_dir, "manifest.json")
        self.backup_path = os.path.join(self.segments_dir, "manifest.json.bak")
        self._path = self.manifest_path
        self._bak_path = self.backup_path
        self._lock = FileLock(self.manifest_path, timeout=lock_timeout)
        self._data: dict = {}

        os.makedirs(self.segments_dir, exist_ok=True)
        with self._lock:
            self._data = self.load()
            # v3.2.0 Fix: Eagerly persist an empty manifest on first init so
            # that workspace detection (detect_storage_format, PeerSync guard)
            # can always identify a segmented workspace by the presence of
            # segments/manifest.json — even before the first flush.
            if not os.path.exists(self.manifest_path):
                self._backup()
                atomic_write_json(self.manifest_path, self._data, lock=False)

    # ------------------------------------------------------------------
    # Read
    # ------------------------------------------------------------------

    def load(self) -> dict:
        """Load and validate the manifest from disk.

        Falls back to ``manifest.json.bak`` if the primary is missing,
        corrupt, or semantically invalid.  If neither exists, initialises
        a fresh empty manifest in memory (not persisted to disk until the
        first write).

        v3.2.0 fix: After loading the primary manifest, ``validate()`` is
        called to check semantic correctness (missing keys, duplicate
        sequences, references to non-existent segment files).  If
        validation fails, the backup is tried.  If both fail validation,
        the one with fewer errors is used.

        Returns
        -------
        dict
            The loaded (or freshly initialised) manifest data.
        """
        primary_data = self._try_read(self.manifest_path)
        if primary_data is not None:
            # Semantic validation: check if the primary manifest is sound
            self._data = primary_data
            primary_errors = self.validate()
            if not primary_errors:
                return self._data
            # Primary has semantic issues — try the backup
            logger.warning(
                "manifest.json has %d validation error(s): %s; trying backup",
                len(primary_errors),
                "; ".join(primary_errors[:3]),
            )
            backup_data = self._try_read(self.backup_path)
            if backup_data is not None:
                self._data = backup_data
                backup_errors = self.validate()
                if not backup_errors:
                    # Backup is clean — use it and restore primary
                    self._write_to_disk_unlocked()
                    return self._data
                # B6 fix: Both have errors — prefer higher generation
                # (more recent committed state), not fewer errors.
                # Fewer errors is only a tiebreaker when generations are equal.
                primary_gen = primary_data.get("generation", 0)
                backup_gen = backup_data.get("generation", 0)
                use_backup = False
                if backup_gen > primary_gen:
                    use_backup = True
                elif backup_gen == primary_gen:
                    # Same generation — use fewer errors as tiebreaker
                    use_backup = len(backup_errors) < len(primary_errors)

                if use_backup:
                    logger.warning(
                        "Both manifests have errors; using backup "
                        "(gen=%d, %d errors vs primary gen=%d, %d errors)",
                        backup_gen, len(backup_errors),
                        primary_gen, len(primary_errors),
                    )
                    self._write_to_disk_unlocked()
                    return self._data
                else:
                    logger.warning(
                        "Both manifests have errors; using primary "
                        "(gen=%d, %d errors vs backup gen=%d, %d errors)",
                        primary_gen, len(primary_errors),
                        backup_gen, len(backup_errors),
                    )
                    self._data = primary_data
                    return self._data
            # No backup available — use primary despite errors
            self._data = primary_data
            return self._data

        logger.warning("manifest.json unreadable; trying manifest.json.bak")
        data = self._try_read(self.backup_path)
        if data is not None:
            self._data = data
            # Validate backup too (best effort — still better than nothing)
            backup_errors = self.validate()
            if backup_errors:
                logger.warning(
                    "manifest.json.bak has %d validation error(s): %s",
                    len(backup_errors),
                    "; ".join(backup_errors[:3]),
                )
            self._write_to_disk_unlocked()
            return self._data

        # P2 Fix 4: Before creating an empty manifest, scan the segments/
        # directory for existing seg_*.jsonl files.  If segment files are
        # found, reconstruct a best-effort manifest so data isn't invisible.
        recovered = self._recover_manifest_from_segments()
        if recovered is not None:
            self._data = recovered
            self._write_to_disk_unlocked()
            return self._data

        logger.info("No manifest found; creating empty manifest and persisting to disk")
        self._data = _empty_manifest()
        # v3.2.0 fix: Eagerly persist the empty manifest so the workspace is
        # immediately recognizable as segmented. Without this, a fresh segmented
        # workspace has segments/hot.jsonl but no manifest.json until first flush,
        # causing PeerSync and detect_storage_format() to misidentify it.
        atomic_write_json(self._path, self._data, lock=False)
        return self._data

    # ------------------------------------------------------------------
    # Write
    # ------------------------------------------------------------------

    def save(self) -> None:
        """Persist the current in-memory manifest state to disk atomically.

        Does **not** increment the generation counter.  Use ``batch_update()``
        or the individual mutating helpers (``add_segment``, ``add_tombstones``,
        etc.) when the generation must advance.
        """
        with self._lock:
            self._verify_generation()
            self._data["updated_at"] = _utcnow_iso()
            self._backup()
            self._write_to_disk_unlocked()

    @contextmanager
    def batch_update(self) -> Generator[Manifest, None, None]:
        """Acquire the manifest lock once and persist multiple mutations atomically.

        Yields ``self`` so the caller can modify ``self._data`` directly.  On
        successful exit the generation is incremented **exactly once** and the
        manifest is written **exactly once**.  On exception, no new state is
        persisted (all in-memory changes are discarded by the caller).

        Example
        -------
        ::

            with manifest.batch_update() as m:
                m._data.setdefault("segments", []).append(seg_meta)
                m._data.setdefault("tombstones", {}).update(new_tombstones)
                m._data["hot"] = reset_hot_state

        Notes
        -----
        Do **not** call any other ``Manifest`` mutating method inside a
        ``batch_update()`` block — ``FileLock`` is non-reentrant and you will
        deadlock.
        """
        with self._lock:
            self._verify_generation()
            yield self
            self._data["generation"] = self._data.get("generation", 0) + 1
            self._data["updated_at"] = _utcnow_iso()
            self._backup()
            self._write_to_disk_unlocked()

    # ------------------------------------------------------------------
    # Segments
    # ------------------------------------------------------------------

    @property
    def segments(self) -> list[dict]:
        """Return a snapshot list of segment metadata dicts (read-only view)."""
        return list(self._data.get("segments", []))

    def add_segment(self, segment_meta: dict) -> None:
        """Register a new immutable segment in the manifest.

        Parameters
        ----------
        segment_meta : dict
            Segment metadata dict as returned by :meth:`SegmentWriter.write_segment`
            plus caller-supplied fields (``sequence``, ``filename``, ``state``,
            ``flushed_at``).
        """
        with self._lock:
            self._verify_generation()
            self._data.setdefault("segments", []).append(segment_meta)
            self._data["generation"] += 1
            self._data["updated_at"] = _utcnow_iso()
            self._backup()
            self._write_to_disk_unlocked()

    def remove_segments(self, sequences: list[int]) -> None:
        """Remove segments by sequence number (used during compaction).

        Parameters
        ----------
        sequences : list[int]
            Sequence numbers of segments to remove from the manifest.
            Segments not found in the list are retained unchanged.
        """
        seq_set = set(sequences)
        with self._lock:
            self._verify_generation()
            self._data["segments"] = [
                s for s in self._data.get("segments", [])
                if s.get("sequence") not in seq_set
            ]
            self._data["generation"] += 1
            self._data["updated_at"] = _utcnow_iso()
            self._backup()
            self._write_to_disk_unlocked()

    # ------------------------------------------------------------------
    # Tombstones
    # ------------------------------------------------------------------

    @property
    def tombstones(self) -> dict[str, dict]:
        """Return a deep copy of the tombstone ledger (hash → {deleted_at, reason})."""
        return {k: dict(v) for k, v in self._data.get("tombstones", {}).items()}

    def add_tombstones(self, tombstones: dict[str, dict]) -> None:
        """Add or update tombstone entries in the manifest.

        Parameters
        ----------
        tombstones : dict[str, dict]
            Mapping of hash → {deleted_at: ISO string, reason: str}.
            Existing tombstones for a given hash are overwritten.
        """
        with self._lock:
            self._verify_generation()
            self._data.setdefault("tombstones", {}).update(tombstones)
            self._data["generation"] += 1
            self._data["updated_at"] = _utcnow_iso()
            self._backup()
            self._write_to_disk_unlocked()

    def remove_tombstones(self, hashes: set[str]) -> None:
        """Remove resolved tombstones from the manifest.

        Called after compaction when the corresponding entries have been
        permanently dropped from all segments.

        Parameters
        ----------
        hashes : set[str]
            Entry hashes whose tombstones should be removed.
        """
        with self._lock:
            self._verify_generation()
            ts = self._data.get("tombstones", {})
            for h in hashes:
                ts.pop(h, None)
            self._data["generation"] += 1
            self._data["updated_at"] = _utcnow_iso()
            self._backup()
            self._write_to_disk_unlocked()

    def get_tombstone_hashes(self) -> set[str]:
        """Return the set of tombstoned hashes for O(1) membership testing."""
        return set(self._data.get("tombstones", {}).keys())

    # ------------------------------------------------------------------
    # Hot-buffer state
    # ------------------------------------------------------------------

    @property
    def hot(self) -> dict:
        """Return a copy of the current hot-buffer advisory state dict."""
        return dict(self._data.get("hot", {}))

    def update_hot(
        self,
        put_count: int,
        delete_count: int,
        last_write_at: str,
    ) -> None:
        """Update the hot-buffer advisory counters in the manifest.

        Parameters
        ----------
        put_count : int
            Number of put operations since last flush.
        delete_count : int
            Number of delete operations since last flush.
        last_write_at : str
            ISO-8601 timestamp of the most recent hot write.
        """
        with self._lock:
            self._verify_generation()
            hot = self._data.setdefault("hot", {
                "filename": "hot.jsonl",
                "put_count": 0,
                "delete_count": 0,
                "last_write_at": None,
            })
            hot["put_count"] = put_count
            hot["delete_count"] = delete_count
            hot["last_write_at"] = last_write_at
            self._data["generation"] += 1
            self._data["updated_at"] = _utcnow_iso()
            self._backup()
            self._write_to_disk_unlocked()

    def reset_hot(self) -> None:
        """Reset hot-buffer advisory counters to zero after a successful flush."""
        with self._lock:
            self._verify_generation()
            self._data["hot"] = {
                "filename": "hot.jsonl",
                "put_count": 0,
                "delete_count": 0,
                "last_write_at": None,
            }
            self._data["generation"] += 1
            self._data["updated_at"] = _utcnow_iso()
            self._backup()
            self._write_to_disk_unlocked()

    # ------------------------------------------------------------------
    # Generation / sequence
    # ------------------------------------------------------------------

    @property
    def generation(self) -> int:
        """Return the current manifest generation counter (monotonically increasing)."""
        return self._data.get("generation", 0)

    def next_sequence(self) -> int:
        """Increment the generation counter and return the new value as a sequence number.

        Acquires the manifest lock, increments generation, persists, and
        returns the incremented value.  Suitable for callers that need a
        unique monotonically increasing integer without otherwise mutating
        the manifest.
        """
        with self._lock:
            self._verify_generation()
            self._data["generation"] += 1
            self._data["updated_at"] = _utcnow_iso()
            seq = self._data["generation"]
            self._backup()
            self._write_to_disk_unlocked()
        return seq

    # ------------------------------------------------------------------
    # Migration metadata
    # ------------------------------------------------------------------

    @property
    def migration(self) -> Optional[dict]:
        """Return migration metadata dict, or ``None`` if not yet migrated."""
        return self._data.get("migration")

    def set_migration(self, migration_meta: dict) -> None:
        """Record migration metadata in the manifest.

        Parameters
        ----------
        migration_meta : dict
            Dict describing the migration event (source format, timestamp,
            entry counts, backup path, etc.).
        """
        with self._lock:
            self._verify_generation()
            self._data["migration"] = migration_meta
            self._data["generation"] += 1
            self._data["updated_at"] = _utcnow_iso()
            self._backup()
            self._write_to_disk_unlocked()

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------

    def validate(self) -> list[str]:
        """Validate the in-memory manifest state and return a list of error strings.

        Semantic checks performed (all fast — no checksum I/O unless the
        segment file is small enough to read a header):

        - All required top-level keys are present
          (``version``, ``generation``, ``segments``, ``hot``, ``tombstones``).
        - ``generation`` is a non-negative integer.
        - No duplicate segment sequence numbers.
        - No duplicate segment filenames.
        - All referenced segment files exist on disk.
        - Each segment ``entry_count`` is > 0.
        - Each segment has a non-empty ``checksum_sha256``.
        - No segment has a ``state`` other than ``"active"`` (v3.2 invariant).
        - ``generation`` is >= the maximum segment sequence number (monotonic
          consistency — the generation counter must never regress below the
          highest committed segment sequence).
        - Tombstone keys are non-empty strings.

        Returns
        -------
        list[str]
            Empty list if the manifest is valid; one string per error otherwise.
        """
        errors: list[str] = []

        # --- Required top-level keys ---
        required_keys = ("version", "generation", "segments", "hot", "tombstones")
        for key in required_keys:
            if key not in self._data:
                errors.append(f"Missing required key: {key!r}")

        # --- Generation is a non-negative integer ---
        gen = self._data.get("generation")
        if not isinstance(gen, int) or gen < 0:
            errors.append(f"Invalid generation: {gen!r}")

        # --- Segment-level checks ---
        seen_seqs: set[int] = set()
        seen_fnames: set[str] = set()
        max_seq = 0

        for seg in self._data.get("segments", []):
            seq = seg.get("sequence")

            # Duplicate sequence numbers
            if seq is not None:
                if seq in seen_seqs:
                    errors.append(f"Duplicate segment sequence: {seq}")
                seen_seqs.add(seq)
                if isinstance(seq, int) and seq > max_seq:
                    max_seq = seq

            fname = seg.get("filename")

            # Duplicate filenames
            if fname:
                if fname in seen_fnames:
                    errors.append(f"Duplicate segment filename: {fname!r}")
                seen_fnames.add(fname)

                # File must exist on disk
                fpath = os.path.join(self.segments_dir, fname)
                if not os.path.exists(fpath):
                    errors.append(f"Segment file missing: {fname}")

            # entry_count must be a positive integer (unless recovered-corrupt)
            entry_count = seg.get("entry_count")
            is_recovered_corrupt = seg.get("_recovered_corrupt", False)
            if is_recovered_corrupt:
                # B2 fix: recovered-corrupt segments have entry_count=0;
                # don't reject them — they were included intentionally by
                # rebuild_from_disk() so no data is silently dropped.
                if not isinstance(entry_count, int) or entry_count < 0:
                    errors.append(
                        f"Segment seq={seq!r} has invalid entry_count: {entry_count!r}"
                    )
            elif not isinstance(entry_count, int) or entry_count <= 0:
                errors.append(
                    f"Segment seq={seq!r} has invalid entry_count: {entry_count!r}"
                )

            # checksum_sha256 must be present and non-empty
            checksum = seg.get("checksum_sha256")
            if not checksum or not isinstance(checksum, str):
                errors.append(
                    f"Segment seq={seq!r} missing or empty checksum_sha256"
                )

            # state must be "active" for v3.2
            state = seg.get("state")
            if state != "active":
                errors.append(
                    f"Segment seq={seq!r} has unexpected state: {state!r} (expected 'active')"
                )

            # PR 1: Reject negative or non-integer sequence numbers
            if not isinstance(seq, int) or seq < 0:
                errors.append(
                    f"Invalid segment sequence (must be non-negative int): {seq!r}"
                )

            # PR 1: Reject future timestamps beyond tolerance (5 min)
            flushed_at = seg.get("flushed_at")
            if isinstance(flushed_at, str) and flushed_at:
                try:
                    ts = datetime.fromisoformat(flushed_at)
                    now = datetime.now(timezone.utc)
                    # Normalise naive timestamps to UTC for comparison
                    if ts.tzinfo is None:
                        ts = ts.replace(tzinfo=timezone.utc)
                    tolerance_seconds = 300  # 5 minutes
                    if (ts - now).total_seconds() > tolerance_seconds:
                        errors.append(
                            f"Segment seq={seq!r} has future flushed_at "
                            f"({flushed_at}) beyond {tolerance_seconds}s tolerance"
                        )
                except (ValueError, TypeError):
                    pass  # Unparseable timestamp — not a validation concern here

        # --- Generation monotonic consistency ---
        # generation must be >= max segment sequence (it can be higher because
        # non-segment mutations like tombstones also increment generation)
        if isinstance(gen, int) and gen >= 0 and max_seq > gen:
            errors.append(
                f"Generation {gen} is less than max segment sequence {max_seq} "
                "(generation must be monotonically >= max segment sequence)"
            )

        # --- Tombstone key and value validity ---
        tombstones = self._data.get("tombstones", {})
        if isinstance(tombstones, dict):
            for key, value in tombstones.items():
                if not isinstance(key, str) or not key:
                    errors.append(f"Tombstone has empty or non-string key: {key!r}")
                # N1 fix: Validate tombstone values are dicts with the
                # expected structure {deleted_at: str, reason: str}.
                if not isinstance(value, dict):
                    errors.append(
                        f"Tombstone {key!r} value is {type(value).__name__}, "
                        f"expected dict with 'deleted_at' and 'reason' keys"
                    )
                elif not isinstance(value.get("deleted_at"), str):
                    errors.append(
                        f"Tombstone {key!r} missing or non-string 'deleted_at'"
                    )
                elif not isinstance(value.get("reason"), str):
                    errors.append(
                        f"Tombstone {key!r} missing or non-string 'reason'"
                    )

        return errors

    # ------------------------------------------------------------------
    # Convenience accessors
    # ------------------------------------------------------------------

    @property
    def data(self) -> dict:
        """Return a deep copy of the raw manifest dict."""
        return json.loads(json.dumps(self._data))

    @property
    def version(self) -> str:
        """Return the manifest format version string."""
        return self._data.get("version", _VERSION)

    def __repr__(self) -> str:
        seg_count = len(self._data.get("segments", []))
        ts_count = len(self._data.get("tombstones", {}))
        return (
            f"<Manifest gen={self.generation} segments={seg_count} "
            f"tombstones={ts_count} dir={self.segments_dir!r}>"
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    # ------------------------------------------------------------------
    # Rebuild / recovery
    # ------------------------------------------------------------------

    def rebuild_from_disk(self) -> dict:
        """Scan ``segments/`` and reconstruct a valid manifest from discovered files.

        This is the authoritative rebuild path for recovery scenarios.  It:

        1. Scans ``segments/`` for ``seg_*.jsonl`` files.
        2. Parses each filename to extract the sequence number (falls back to
           incrementing counter for non-standard names).
        3. Counts entries in each file (skipping corrupt lines gracefully).
        4. Computes the SHA-256 checksum of each file's raw bytes.
        5. Builds a complete, semantically valid manifest dict.

        The rebuilt manifest is **not** written to disk by this method — the
        caller decides whether to persist it (typically via
        ``_write_to_disk_unlocked()`` after replacing ``self._data``).

        .. note:: The recovery path in :meth:`load` (via
           :meth:`_recover_manifest_from_segments`) **does** persist the
           rebuilt manifest to disk immediately after calling this method.
           Callers reading only this docstring should be aware that the
           ``load()`` recovery flow writes the result to both
           ``manifest.json`` and ``manifest.json.bak``.

        Partial/corrupt segment files are included with best-effort counts
        rather than excluded entirely, so no data is silently dropped.

        Returns
        -------
        dict
            A complete manifest dict with ``segments``, ``generation``,
            ``tombstones``, etc.  Always passes ``validate()`` for
            non-filesystem-access checks.
        """
        seg_pattern = os.path.join(self.segments_dir, "seg_*.jsonl")
        seg_files = sorted(glob(seg_pattern))

        # Parse segment filenames: seg_NNNN_<timestamp>_<count>.jsonl
        seg_re = re.compile(
            r"^seg_(\d{4})_(\d{8}T\d{6}Z)_(\d+)\.jsonl$"
        )

        segments: list[dict] = []
        max_sequence = 0
        # B1 fix: Track ALL assigned sequences (parsed + fallback) to prevent
        # collisions.  First pass: scan standard filenames to find max parsed
        # sequence.  Then fallback_seq starts above that max.
        assigned_sequences: set[int] = set()

        # First pass: determine max parsed sequence from standard filenames
        parsed_seqs: list[tuple[str, int]] = []  # (seg_path, seq)
        non_standard: list[str] = []
        for seg_path in seg_files:
            fname = os.path.basename(seg_path)
            m = seg_re.match(fname)
            if m:
                seq = int(m.group(1))
                parsed_seqs.append((seg_path, seq))
                assigned_sequences.add(seq)
                if seq > max_sequence:
                    max_sequence = seq
            else:
                non_standard.append(seg_path)

        # Fallback counter starts above the highest parsed sequence
        fallback_seq = max_sequence

        # Rebuild the iteration order: parsed first, then non-standard
        ordered_files: list[tuple[str, int]] = list(parsed_seqs)
        for seg_path in non_standard:
            fallback_seq += 1
            # Ensure no collision (defensive — shouldn't happen with correct start)
            while fallback_seq in assigned_sequences:
                fallback_seq += 1
            assigned_sequences.add(fallback_seq)
            ordered_files.append((seg_path, fallback_seq))
            if fallback_seq > max_sequence:
                max_sequence = fallback_seq

        for seg_path, seq in ordered_files:
            fname = os.path.basename(seg_path)

            # Count entries (gracefully skip corrupt lines)
            entry_count = 0
            try:
                with open(seg_path, "r", encoding="utf-8", errors="replace") as fh:
                    for raw_line in fh:
                        line = raw_line.strip()
                        if not line:
                            continue
                        try:
                            obj = json.loads(line)
                            if isinstance(obj, dict):
                                entry_count += 1
                        except (json.JSONDecodeError, ValueError):
                            # Corrupt line — count it as zero, don't skip file
                            pass
            except OSError:
                # File unreadable entirely; still include in manifest so it
                # doesn't become an orphan, but with zero count.
                pass

            # Compute checksum of raw bytes
            checksum = ""
            try:
                h = hashlib.sha256()
                with open(seg_path, "rb") as fh:
                    for chunk in iter(lambda: fh.read(65536), b""):
                        h.update(chunk)
                checksum = h.hexdigest()
            except OSError:
                pass

            # File size
            size_bytes = 0
            try:
                size_bytes = os.path.getsize(seg_path)
            except OSError:
                pass

            # B2 fix: Use the ACTUAL entry_count (0 if fully corrupt) instead
            # of max(1, entry_count) which silently lies to validate().
            # Mark fully-corrupt segments with _recovered_corrupt=True so
            # validate() can exempt them from the entry_count > 0 check.
            is_corrupt = (entry_count == 0)
            segments.append({
                "sequence": seq,
                "filename": fname,
                "state": "active",
                "entry_count": entry_count,
                "size_bytes": size_bytes,
                "checksum_sha256": checksum,
                "flushed_at": _utcnow_iso(),
                "_recovered": True,
                "_recovered_raw_entry_count": entry_count,
                "_recovered_corrupt": is_corrupt,
            })

        # Ensure generation >= max segment sequence
        generation = max(max_sequence, 1) if segments else 0

        now = _utcnow_iso()
        manifest = {
            "version": _VERSION,
            "generation": generation,
            "created_at": now,
            "updated_at": now,
            "segments": segments,
            "hot": {
                "filename": "hot.jsonl",
                "put_count": 0,
                "delete_count": 0,
                "last_write_at": None,
            },
            "tombstones": {},
            "search": {"index_generation": 0},
            "migration": None,
        }

        if segments:
            manifest["_recovery"] = {
                "recovered_at": now,
                "reason": "rebuild_from_disk",
                "segments_found": len(segments),
            }

        return manifest

    def _recover_manifest_from_segments(self) -> Optional[dict]:
        """Scan segments/ for seg_*.jsonl files and reconstruct a manifest.

        This is a best-effort recovery path (P2 Fix 4) invoked when both
        ``manifest.json`` and ``manifest.json.bak`` are missing or corrupt.
        Instead of creating an empty manifest (which makes all data
        invisible), we scan the directory for segment files and build a
        minimal manifest from filename metadata.

        Delegates to :meth:`rebuild_from_disk` for the actual scan/build,
        which now computes real checksums and counts entries.

        Returns
        -------
        dict or None
            A reconstructed manifest dict if segment files were found,
            or ``None`` if no segment files exist (fall through to empty
            manifest creation).
        """
        seg_pattern = os.path.join(self.segments_dir, "seg_*.jsonl")
        seg_files = sorted(glob(seg_pattern))
        if not seg_files:
            return None

        manifest = self.rebuild_from_disk()
        if not manifest.get("segments"):
            return None

        logger.critical(
            "Both manifest files corrupt. Reconstructed manifest from "
            "%d segment files on disk. Data may be incomplete — run "
            "verify_integrity() and consider a full repair.",
            len(manifest["segments"]),
        )
        # Override reason for this specific code path
        if "_recovery" in manifest:
            manifest["_recovery"]["reason"] = "both_manifests_corrupt"
        return manifest

    def _try_read(self, path: str) -> Optional[dict]:
        """Try to read and parse a manifest JSON file.

        Parameters
        ----------
        path : str
            Filesystem path to attempt to read.

        Returns
        -------
        dict or None
            Parsed manifest dict, or ``None`` if the file is missing, not
            valid JSON, or not a dict.
        """
        if not os.path.exists(path):
            return None
        try:
            with open(path, "r") as f:
                data = json.load(f)
            if not isinstance(data, dict):
                return None
            return data
        except (json.JSONDecodeError, OSError) as exc:
            logger.warning("Failed to read %s: %s", path, exc)
            return None

    def _verify_generation(self) -> None:
        """Re-read the on-disk generation and verify it matches in-memory state.

        Raises :class:`ManifestConflictError` if a concurrent writer has
        advanced the on-disk generation since this instance last wrote.
        The caller should reload the manifest and retry their operation.

        Called automatically by all mutating methods before writing.
        """
        on_disk = self._try_read(self._path) or self._try_read(self._bak_path) or {}
        disk_gen = on_disk.get("generation", 0)
        mem_gen = self._data.get("generation", 0)
        if disk_gen != mem_gen:
            raise ManifestConflictError(
                f"Generation conflict at {self.manifest_path!r}: "
                f"disk generation={disk_gen}, in-memory generation={mem_gen}. "
                "Another writer has modified the manifest. "
                "Call Manifest.load() to resync before retrying."
            )

    def _backup(self) -> None:
        """Atomically copy the current ``manifest.json`` to ``manifest.json.bak``.

        Best-effort — a backup failure logs a warning but does not abort the
        write.  The primary manifest write proceeds regardless.
        """
        if not os.path.exists(self.manifest_path):
            return

        tmp_fd = None
        tmp_path = None
        try:
            tmp_fd, tmp_path = tempfile.mkstemp(
                prefix="manifest.json.bak.",
                suffix=".tmp",
                dir=self.segments_dir,
            )
            with os.fdopen(tmp_fd, "wb") as tmp_f, open(self.manifest_path, "rb") as src_f:
                tmp_fd = None
                while True:
                    chunk = src_f.read(1024 * 1024)
                    if not chunk:
                        break
                    tmp_f.write(chunk)
                tmp_f.flush()
                os.fsync(tmp_f.fileno())

            os.replace(tmp_path, self.backup_path)
            self._fsync_directory()
        except OSError as exc:
            logger.warning("Failed to backup manifest: %s", exc)
            if tmp_fd is not None:
                try:
                    os.close(tmp_fd)
                except OSError:
                    pass
            if tmp_path is not None:
                try:
                    os.unlink(tmp_path)
                except OSError:
                    pass

    def _fsync_directory(self) -> None:
        """Fsync the segments directory to make renames durable on supported filesystems."""
        try:
            dir_fd = os.open(self.segments_dir, os.O_RDONLY)
        except OSError:
            return
        try:
            os.fsync(dir_fd)
        except OSError:
            pass
        finally:
            os.close(dir_fd)

    def _write_to_disk(self) -> None:
        """Write the manifest atomically, acquiring the manifest lock."""
        with self._lock:
            self._write_to_disk_unlocked()

    def _write_to_disk_unlocked(self) -> None:
        """Write the manifest atomically — caller MUST already hold the manifest lock."""
        atomic_write_json(self.manifest_path, self._data, lock=False)
