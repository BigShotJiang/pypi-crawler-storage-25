"""Migration utilities for Parsica Memory v3.2.0.

Migration strategy
------------------
Parsica Memory has evolved through several on-disk storage formats:

``empty``
    No recognisable storage files present.

``legacy``
    A single ``memory_metadata.json`` file in the workspace root (v1-era).

``time_shards``
    JSONL files named ``memories_<date>.jsonl`` in the workspace root (v2-era).

``enterprise_shards``
    A ``shards/`` directory containing ``shard_*.json`` files — each file
    holds a ``{"memories": [...]}`` payload (v2.x/early-v3 era).

``segments``
    A ``segments/`` directory with ``manifest.json`` and immutable
    ``seg_*.jsonl`` files (v3.2+, current format).

Use :func:`detect_storage_format` to identify which format a workspace is
currently using, then :func:`migrate_to_segments` to upgrade it.

Enrichment preservation
-----------------------
The migration copies every field of every :class:`~parsica_memory.entry.MemoryEntry`
verbatim, including LLM-enriched fields (``enriched_summary``, ``tags``,
``keywords``, ``search_keywords``, embedding cross-pollination data, etc.).
Enrichment is **never recomputed** during migration — it would be prohibitively
expensive and unnecessary since the data already exists in the source shards.

:func:`verify_migration` samples up to 100 shared hashes and confirms that
``enriched_summary`` and ``search_keywords`` are identical between the backup
and the new segments.

Rollback semantics
------------------
:func:`migrate_to_segments` renames the ``shards/`` directory to
``shards.pre_segments_backup/`` before writing the new ``segments/``.  This
means the original data is never deleted — the backup survives until
:func:`rollback_migration` or a manual cleanup.

:func:`rollback_migration` reverses the migration atomically:

1. Renames ``segments/`` → ``segments.rollback_disabled/``.
2. Renames ``shards.pre_segments_backup/`` → ``shards/``.

If the backup does not exist, the segments directory is still moved aside so
the workspace is in a clean state for a fresh migration attempt.

No data is permanently deleted by any migration function.  All displaced
directories are renamed (not removed) so they can be inspected or recovered
manually.

Sorting behaviour for missing ``created`` fields
-------------------------------------------------
:func:`migrate_to_segments` sorts entries by their ``created`` timestamp
before writing them into segments (to produce time-ordered segments that
give the manifest accurate ``min_created`` / ``max_created`` metadata).

Entries with a missing, empty, or non-ISO-parseable ``created`` field are
sorted to the **end** of the list (after all valid entries).  This is
intentional: unknown-age entries are treated as "oldest unknown" rather than
"newest" so they do not artificially inflate ``max_created`` on segments that
would otherwise be tightly time-bounded.  The sort key is a 2-tuple
``(bucket, value)`` where ``bucket=0`` means parseable and ``bucket=1``
means unparseable — standard lexicographic tuple comparison puts all
bucket-1 entries after all bucket-0 entries.
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import random
import shutil
import tempfile
from datetime import datetime, timezone
from glob import glob
from typing import Dict, List, Optional, Set, Tuple

from parsica_memory.entry import MemoryEntry
from parsica_memory.locking import FileLock
from parsica_memory.storage.segments import SegmentWriter
from parsica_memory.utils import atomic_write_json

logger = logging.getLogger("parsica_memory")


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _utc_now_iso() -> str:
    """Return the current UTC time as an ISO-8601 string."""
    return datetime.now(timezone.utc).isoformat()


def _safe_parse_created(value: str) -> Tuple[int, object]:
    """Return a sort key for a ``created`` timestamp string.

    Returns a 2-tuple ``(bucket, sort_value)`` where:

    * ``(0, float_timestamp)`` — successfully parsed ISO datetime.
    * ``(1, original_string)`` — missing, empty, or unparseable value.

    Tuple comparison ensures all parseable entries sort before unparseable
    ones.  See module docstring for rationale.

    Parameters
    ----------
    value : str
        The ``created`` field value to parse.

    Returns
    -------
    tuple
        ``(0, timestamp_float)`` or ``(1, value_str)``.
    """
    if not value:
        return (1, "")
    try:
        return (0, datetime.fromisoformat(value).timestamp())
    except (ValueError, TypeError):
        return (1, value)


def _segment_filename(sequence: int, created_iso: str, entry_count: int) -> str:
    """Build a human-readable segment filename from sequence, timestamp, and count.

    Parameters
    ----------
    sequence : int
        Monotonically increasing segment sequence number (zero-padded to 4 digits).
    created_iso : str
        ISO-8601 timestamp used for the filename's time component.  Falls
        back to the current UTC time if parsing fails.
    entry_count : int
        Number of entries in the segment (embedded in the filename for
        human readability; the manifest is authoritative).

    Returns
    -------
    str
        Filename of the form ``seg_NNNN_YYYYMMDDTHHMMSSZ_<count>.jsonl``.
    """
    try:
        dt = datetime.fromisoformat(created_iso)
    except (ValueError, TypeError):
        dt = datetime.now(timezone.utc)
    ts = dt.astimezone(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    return f"seg_{sequence:04d}_{ts}_{entry_count}.jsonl"


def _segment_checksum(path: str) -> str:
    """Compute and return the SHA-256 hex digest of a file's raw bytes."""
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        while True:
            chunk = fh.read(1024 * 1024)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def _atomic_write_text(path: str, content: str) -> None:
    """Write *content* to *path* atomically using a temp-file + rename pattern."""
    directory = os.path.dirname(path) or "."
    os.makedirs(directory, exist_ok=True)
    fd, tmp_path = tempfile.mkstemp(dir=directory, suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(content)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp_path, path)
        try:
            dir_fd = os.open(directory, os.O_RDONLY)
            try:
                os.fsync(dir_fd)
            finally:
                os.close(dir_fd)
        except (OSError, AttributeError):
            pass
    except BaseException:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        raise


# ---------------------------------------------------------------------------
# Storage format detection
# ---------------------------------------------------------------------------

def detect_storage_format(workspace: str) -> str:
    """Detect which on-disk storage format a workspace is currently using.

    Parameters
    ----------
    workspace : str
        Root workspace directory path.

    Returns
    -------
    str
        One of ``"segments"``, ``"enterprise_shards"``, ``"time_shards"``,
        ``"legacy"``, or ``"empty"``.

    Notes
    -----
    Detection is performed in priority order — ``"segments"`` is checked first
    because a workspace in the middle of a migration may have both
    ``segments/manifest.json`` and a ``shards.pre_segments_backup/`` present.

    Edge cases handled:

    * **Empty segments/ directory** (no manifest, no hot.jsonl, no seg files):
      Still classified as ``"segments"`` if the directory exists.  An empty
      ``segments/`` directory is the canonical initial state of a freshly
      created segmented workspace whose first write hasn't arrived yet (or
      whose ``hot.jsonl`` was cleaned up).

    * **manifest.json exists but is empty or invalid JSON**: Classified as
      ``"segments"`` — the file's presence is the signal; ``Manifest.load()``
      will repair it on the next open.

    * **segments/ contains only seg_*.jsonl files** (manifest absent, hot
      absent): Classified as ``"segments"`` — the segment files are
      authoritative evidence of a segmented workspace regardless of manifest
      state.  ``Manifest.load()`` will trigger ``rebuild_from_disk()`` on
      next open.
    """
    segments_dir = os.path.join(workspace, "segments")

    # ---- Segments format detection (priority) ----
    # Signal 1: manifest.json present (even if empty/corrupt — presence is enough)
    segments_manifest = os.path.join(segments_dir, "manifest.json")
    if os.path.exists(segments_manifest):
        return "segments"

    # Signal 2: hot.jsonl present (writer has initialised the buffer)
    segments_hot = os.path.join(segments_dir, "hot.jsonl")
    if os.path.exists(segments_hot):
        return "segments"

    # Signal 3: segments/ directory exists.  If empty, this is the canonical
    # initial state of a freshly created segmented workspace (safe to classify
    # as "segments").  If non-empty, require at least one Parsica-specific file
    # (manifest.json.bak, hot.jsonl, or seg_*.jsonl) to avoid false positives
    # when a user creates a segments/ directory for unrelated purposes (B5 fix).
    if os.path.isdir(segments_dir):
        contents = os.listdir(segments_dir)
        if not contents:
            # Empty directory — fresh init, safe to classify as segments
            return "segments"
        # Non-empty: check for Parsica-specific files
        has_parsica_files = (
            "manifest.json.bak" in contents
            or "hot.jsonl" in contents
            or any(f.startswith("seg_") and f.endswith(".jsonl") for f in contents)
        )
        if has_parsica_files:
            return "segments"
        # Non-empty with no Parsica files — fall through to other format checks

    # ---- N5 fix: Detect segments.rollback_disabled/ remnant ----
    # After rollback_migration(), the workspace may have a
    # segments.rollback_disabled/ directory.  This is NOT an active segments
    # workspace — it's a disabled remnant from a rollback.  Log a warning
    # so operators know it exists, but do NOT treat it as active segments.
    rollback_disabled_dir = os.path.join(workspace, "segments.rollback_disabled")
    if os.path.isdir(rollback_disabled_dir):
        logger.warning(
            "Found segments.rollback_disabled/ in workspace %s — this is a "
            "remnant from a previous rollback_migration(). It is NOT treated "
            "as active segments. Inspect or remove it manually.",
            workspace,
        )

    # ---- Legacy / older format detection ----
    shards_dir = os.path.join(workspace, "shards")
    if os.path.isdir(shards_dir):
        shard_files = glob(os.path.join(shards_dir, "shard_*.json"))
        if shard_files:
            return "enterprise_shards"

    if glob(os.path.join(workspace, "memories_*.jsonl")):
        return "time_shards"

    if os.path.exists(os.path.join(workspace, "memory_metadata.json")):
        return "legacy"

    return "empty"


# ---------------------------------------------------------------------------
# Internal loaders
# ---------------------------------------------------------------------------

def _load_entries_from_enterprise_shards(workspace: str) -> List[MemoryEntry]:
    """Load all entries from the ``shards/`` directory of an enterprise-shards workspace."""
    shards_dir = os.path.join(workspace, "shards")
    if not os.path.isdir(shards_dir):
        return []
    return _load_entries_from_shards_dir(shards_dir)


def _load_entries_from_shards_dir(shards_dir: str) -> List[MemoryEntry]:
    """Load all entries from every ``shard_*.json`` file under *shards_dir*.

    Parameters
    ----------
    shards_dir : str
        Directory containing ``shard_*.json`` files.

    Returns
    -------
    list[MemoryEntry]
        All successfully parsed entries.  Unreadable shard files and
        individual invalid memory dicts are logged and skipped.
    """
    if not os.path.isdir(shards_dir):
        return []

    entries: List[MemoryEntry] = []
    for path in sorted(glob(os.path.join(shards_dir, "shard_*.json"))):
        try:
            with open(path, "r", encoding="utf-8") as fh:
                data = json.load(fh)
        except (OSError, json.JSONDecodeError):
            logger.warning(
                "[parsica-memory] Skipping unreadable shard during migration: %s", path
            )
            continue

        memories = data.get("memories", [])
        if not isinstance(memories, list):
            continue

        for item in memories:
            if not isinstance(item, dict):
                continue
            try:
                entries.append(MemoryEntry.from_dict(item))
            except Exception:
                logger.warning(
                    "[parsica-memory] Skipping invalid memory in shard: %s", path
                )
    return entries


def _load_pending_wal(workspace: str) -> List[MemoryEntry]:
    """Load entries from the WAL pending file at ``.wal/pending.jsonl``, if present.

    Parameters
    ----------
    workspace : str
        Root workspace directory.

    Returns
    -------
    list[MemoryEntry]
        Entries parsed from the WAL file.  Returns an empty list if the
        file does not exist or contains no valid entries.
    """
    wal_path = os.path.join(workspace, ".wal", "pending.jsonl")
    if not os.path.exists(wal_path):
        return []

    entries: List[MemoryEntry] = []
    with open(wal_path, "r", encoding="utf-8") as fh:
        for line in fh:
            stripped = line.strip()
            if not stripped:
                continue
            try:
                data = json.loads(stripped)
            except json.JSONDecodeError:
                continue
            if not isinstance(data, dict):
                continue
            try:
                entries.append(MemoryEntry.from_dict(data))
            except Exception:
                logger.warning(
                    "[parsica-memory] Skipping invalid WAL entry during migration"
                )
    return entries


def _load_hashes_from_shards(shards_dir: str) -> Set[str]:
    """Return the set of hashes present in all shard files under *shards_dir*.

    Parameters
    ----------
    shards_dir : str
        Directory containing ``shard_*.json`` files.

    Returns
    -------
    set[str]
        All non-empty hash strings found.
    """
    hashes: Set[str] = set()
    if not os.path.isdir(shards_dir):
        return hashes

    for path in sorted(glob(os.path.join(shards_dir, "shard_*.json"))):
        try:
            with open(path, "r", encoding="utf-8") as fh:
                data = json.load(fh)
        except (OSError, json.JSONDecodeError):
            continue

        for item in data.get("memories", []):
            if isinstance(item, dict):
                value = item.get("hash")
                if value:
                    hashes.add(value)
    return hashes


def _load_entries_from_segments(segments_dir: str) -> List[MemoryEntry]:
    """Load all entries from all active segments referenced in the manifest.

    Parameters
    ----------
    segments_dir : str
        Path to the ``segments/`` directory containing ``manifest.json``
        and segment files.

    Returns
    -------
    list[MemoryEntry]
        All entries across all segments.  Missing segment files and malformed
        lines are silently skipped.
    """
    manifest_path = os.path.join(segments_dir, "manifest.json")
    if not os.path.exists(manifest_path):
        return []

    try:
        with open(manifest_path, "r", encoding="utf-8") as fh:
            manifest = json.load(fh)
    except (OSError, json.JSONDecodeError):
        return []

    entries: List[MemoryEntry] = []
    for segment in manifest.get("segments", []):
        filename = segment.get("filename")
        if not filename:
            continue
        path = os.path.join(segments_dir, filename)
        if not os.path.exists(path):
            continue
        try:
            with open(path, "r", encoding="utf-8") as fh:
                for line in fh:
                    stripped = line.strip()
                    if not stripped:
                        continue
                    try:
                        data = json.loads(stripped)
                        entries.append(MemoryEntry.from_dict(data))
                    except (json.JSONDecodeError, KeyError):
                        continue
        except OSError:
            continue
    return entries


def _load_hashes_from_segments(segments_dir: str) -> Set[str]:
    """Return the set of hashes present in all segments under *segments_dir*.

    Parameters
    ----------
    segments_dir : str
        Path to the ``segments/`` directory.

    Returns
    -------
    set[str]
        All non-empty hash strings found.
    """
    return {
        entry.hash
        for entry in _load_entries_from_segments(segments_dir)
        if entry.hash
    }


# ---------------------------------------------------------------------------
# Public migration API
# ---------------------------------------------------------------------------

def migrate_to_segments(workspace: str, chunk_size: int = 2000) -> Dict:
    """Migrate a workspace from enterprise-shards (or WAL) format to segments.

    This is a one-way, idempotent migration.  If ``segments/manifest.json``
    already exists when this function is called, it returns immediately with
    ``status="already_migrated"`` without modifying anything.

    Migration steps
    ~~~~~~~~~~~~~~~
    1. Acquire a ``FileLock`` on ``segments/manifest.json`` (prevents concurrent
       migrations in multi-process environments).
    2. Load all entries from ``shards/`` (enterprise-shards format) and
       ``.wal/pending.jsonl`` (if present).
    3. Deduplicate by hash — last occurrence wins.
    4. Sort entries by ``created`` timestamp.

       **Sorting behaviour for missing/invalid ``created`` fields:**
       Entries with a missing, empty, or non-ISO-parseable ``created`` field
       are sorted to the **end** of the list, after all validly timestamped
       entries.  This is intentional — unknown-age entries should not inflate
       the ``max_created`` bound of an otherwise tightly time-scoped segment.
       The sort key is ``_safe_parse_created(entry.created)`` which returns
       ``(0, timestamp)`` for parseable values and ``(1, raw_string)`` for
       unparseable ones.  Standard tuple comparison guarantees all bucket-1
       entries sort after all bucket-0 entries.

    5. Write entries in chunks of *chunk_size* as immutable JSONL segments via
       :meth:`SegmentWriter.write_segment`.
    6. Write ``segments/manifest.json`` and a backup copy atomically.
    7. Rename ``shards/`` → ``shards.pre_segments_backup/`` (non-destructive).
    8. Create an empty ``segments/hot.jsonl``.

    Enrichment preservation
    ~~~~~~~~~~~~~~~~~~~~~~~
    All entry fields (including LLM-enriched fields such as
    ``enriched_summary``, ``tags``, ``keywords``, ``search_keywords``) are
    copied verbatim.  Enrichment is never recomputed during migration.

    Parameters
    ----------
    workspace : str
        Root workspace directory path.
    chunk_size : int
        Maximum entries per segment.  Defaults to 2000.  Values ≤ 0 are
        treated as 2000.

    Returns
    -------
    dict
        ``{"status": "already_migrated", ...}`` if already on segments format,
        or a detailed result dict on success::

            {
                "status": "migrated",
                "source_entries": int,
                "wal_entries": int,
                "deduped_entries": int,
                "duplicate_hashes": int,
                "segments": int,
                "backup_created": bool,
                "backup_path": str | None,
                "hot_path": str,
                "manifest_path": str,
            }
    """
    segments_dir = os.path.join(workspace, "segments")
    manifest_path = os.path.join(segments_dir, "manifest.json")
    manifest_backup_path = manifest_path + ".bak"
    lock_path = manifest_path

    os.makedirs(segments_dir, exist_ok=True)

    with FileLock(lock_path, timeout=30.0):
        # Idempotency check — already migrated
        if os.path.exists(manifest_path):
            try:
                with open(manifest_path, "r", encoding="utf-8") as fh:
                    manifest = json.load(fh)
            except (OSError, json.JSONDecodeError):
                manifest = {}
            return {
                "status": "already_migrated",
                "segments": len(manifest.get("segments", [])),
                "entries": sum(
                    seg.get("entry_count", 0)
                    for seg in manifest.get("segments", [])
                ),
            }

        logger.info(
            "[parsica-memory] Starting migration to segments for workspace=%s",
            workspace,
        )

        shard_entries = _load_entries_from_enterprise_shards(workspace)
        wal_entries = _load_pending_wal(workspace)
        source_entry_count = len(shard_entries)

        combined = shard_entries + wal_entries
        shard_hash_set = {e.hash for e in shard_entries}
        wal_hash_set = {e.hash for e in wal_entries}
        deduped: Dict[str, MemoryEntry] = {}
        duplicate_hashes = 0
        # N6 fix: Count cross-source dedup collisions — hashes that appear
        # in both shards and WAL, where the WAL entry overwrites the shard
        # entry (last-occurrence-wins).  Provides operational visibility into
        # how many entries were updated between the shard snapshot and the WAL.
        dedup_collisions = len(shard_hash_set & wal_hash_set)
        for entry in combined:
            if entry.hash in deduped:
                duplicate_hashes += 1
            deduped[entry.hash] = entry

        entries = list(deduped.values())
        # Sort by created timestamp; entries with missing/invalid created sort
        # to the end — see module docstring and function docstring for details.
        entries.sort(key=lambda e: _safe_parse_created(getattr(e, "created", "")))

        os.makedirs(segments_dir, exist_ok=True)

        segment_meta: List[Dict] = []
        segment_count = 0
        effective_chunk_size = chunk_size if chunk_size > 0 else 2000
        for index in range(0, len(entries), effective_chunk_size):
            chunk = entries[index : index + effective_chunk_size]
            if not chunk:
                continue
            sequence = segment_count + 1
            filename = _segment_filename(sequence, chunk[0].created, len(chunk))
            segment_path = os.path.join(segments_dir, filename)
            meta = SegmentWriter.write_segment(segment_path, chunk)
            meta["sequence"] = sequence
            meta["filename"] = filename
            meta["state"] = "active"
            meta["flushed_at"] = _utc_now_iso()
            segment_meta.append(meta)
            segment_count += 1

        now = _utc_now_iso()
        manifest = {
            "version": "3.2.0",
            "generation": segment_count,
            "created_at": now,
            "updated_at": now,
            "segments": segment_meta,
            "hot": {
                "filename": "hot.jsonl",
                "put_count": 0,
                "delete_count": 0,
                "last_write_at": now,
            },
            "tombstones": {},
            "search": {"index_generation": 1},
            "migration": {
                "migrated_from": "enterprise_shards",
                "migrated_at": now,
                "source_entry_count": source_entry_count,
                "legacy_backup": "shards.pre_segments_backup",
                "wal_replayed_count": len(wal_entries),
                "deduped_total_count": len(entries),
                "duplicate_hashes": duplicate_hashes,
            },
        }

        atomic_write_json(manifest_path, manifest, lock=False)
        shutil.copy2(manifest_path, manifest_backup_path)

        shards_dir = os.path.join(workspace, "shards")
        backup_dir = os.path.join(workspace, "shards.pre_segments_backup")
        backup_created = False
        if os.path.isdir(shards_dir):
            if not os.path.exists(backup_dir):
                os.replace(shards_dir, backup_dir)
                backup_created = True
            else:
                backup_created = True

        hot_path = os.path.join(segments_dir, "hot.jsonl")
        _atomic_write_text(hot_path, "")

        logger.info(
            "[parsica-memory] Migrated %s entries to %s segments. Backup: %s",
            len(entries),
            segment_count,
            backup_dir if backup_created else "none",
        )

        return {
            "status": "migrated",
            "source_entries": source_entry_count,
            "wal_entries": len(wal_entries),
            "deduped_entries": len(entries),
            "duplicate_hashes": duplicate_hashes,
            "dedup_collisions": dedup_collisions,
            "segments": segment_count,
            "backup_created": backup_created,
            "backup_path": backup_dir if backup_created else None,
            "hot_path": hot_path,
            "manifest_path": manifest_path,
        }


def verify_migration(workspace: str) -> Dict:
    """Verify that all pre-migration hashes are present in the new segments.

    Compares the set of hashes in ``shards.pre_segments_backup/`` against
    the set of hashes in ``segments/``, and spot-checks enrichment field
    preservation on a random sample.

    Parameters
    ----------
    workspace : str
        Root workspace directory path.

    Returns
    -------
    dict
        ::

            {
                "old_count": int,       # hashes in backup shards
                "new_count": int,       # hashes in new segments
                "missing": list[str],   # hashes in backup but not in segments
                "extra": list[str],     # hashes in segments but not in backup
                "enrichment_preserved": bool,  # True if sample check passes
            }

    Notes
    -----
    ``extra`` hashes typically come from WAL entries that were not present in
    the shard backup.  A non-empty ``missing`` list indicates data loss and
    should be investigated before discarding the backup.
    """
    backup_dir = os.path.join(workspace, "shards.pre_segments_backup")
    segments_dir = os.path.join(workspace, "segments")

    old_hashes = _load_hashes_from_shards(backup_dir)
    new_hashes = _load_hashes_from_segments(segments_dir)

    missing = sorted(old_hashes - new_hashes)
    extra = sorted(new_hashes - old_hashes)

    enrichment_preserved = True
    if os.path.isdir(backup_dir):
        old_entries = {
            entry.hash: entry
            for entry in _load_entries_from_shards_dir(backup_dir)
        }
        new_entries = {
            entry.hash: entry
            for entry in _load_entries_from_segments(segments_dir)
        }
        shared_hashes = sorted(set(old_entries) & set(new_entries))
        if shared_hashes:
            sample_size = min(100, len(shared_hashes))
            sampled = random.sample(shared_hashes, sample_size)
            for value in sampled:
                old_entry = old_entries[value]
                new_entry = new_entries[value]
                if getattr(old_entry, "enriched_summary", "") != getattr(
                    new_entry, "enriched_summary", ""
                ):
                    enrichment_preserved = False
                    break
                if list(getattr(old_entry, "search_keywords", [])) != list(
                    getattr(new_entry, "search_keywords", [])
                ):
                    enrichment_preserved = False
                    break

    return {
        "old_count": len(old_hashes),
        "new_count": len(new_hashes),
        "missing": missing,
        "extra": extra,
        "enrichment_preserved": enrichment_preserved,
    }


def rollback_migration(workspace: str) -> Dict:
    """Roll back a segments migration to restore the enterprise-shards layout.

    Reverses the migration performed by :func:`migrate_to_segments` by:

    1. Moving ``segments/`` → ``segments.rollback_disabled/``.
    2. Moving ``shards.pre_segments_backup/`` → ``shards/``.

    If the backup does not exist, only step 1 is performed so the workspace
    is in a clean state for a fresh migration attempt.

    No data is permanently deleted.  All displaced directories are renamed
    rather than removed.

    Parameters
    ----------
    workspace : str
        Root workspace directory path.

    Returns
    -------
    dict
        ::

            {
                "status": "rolled_back" | "no_backup",
                "restored_shards": bool,
                "segments_removed": bool,
                "shards_path": str | None,
            }

    Raises
    ------
    RuntimeError
        If ``segments.rollback_disabled/`` already exists (a prior rollback
        was not cleaned up).  The path is included in the error message so
        the user knows what to remove.
    """
    shards_dir = os.path.join(workspace, "shards")
    backup_dir = os.path.join(workspace, "shards.pre_segments_backup")
    segments_dir = os.path.join(workspace, "segments")
    rollback_disabled_dir = os.path.join(workspace, "segments.rollback_disabled")

    restored = False
    removed_segments = False

    if not os.path.exists(backup_dir):
        if os.path.exists(segments_dir):
            if os.path.exists(rollback_disabled_dir):
                os.replace(
                    rollback_disabled_dir,
                    os.path.join(workspace, "segments.rollback_backup"),
                )
            os.replace(segments_dir, rollback_disabled_dir)
            removed_segments = True
        return {
            "status": "no_backup",
            "restored_shards": False,
            "segments_removed": removed_segments,
            "shards_path": None,
        }

    if os.path.exists(rollback_disabled_dir):
        raise RuntimeError(
            f"Rollback staging path already exists: {rollback_disabled_dir!r}. "
            "A previous rollback may not have completed cleanly. "
            "Inspect the directory and remove it manually before retrying."
        )

    displaced_shards_dir: Optional[str] = None
    if os.path.exists(shards_dir):
        displaced_shards_dir = os.path.join(workspace, "shards.rollback_displaced")
        suffix = 0
        while os.path.exists(displaced_shards_dir):
            suffix += 1
            displaced_shards_dir = os.path.join(
                workspace, f"shards.rollback_displaced.{suffix}"
            )
        os.replace(shards_dir, displaced_shards_dir)

    try:
        if os.path.exists(segments_dir):
            os.replace(segments_dir, rollback_disabled_dir)
            removed_segments = True

        try:
            os.replace(backup_dir, shards_dir)
            restored = True
        except Exception:
            # Restore segments if we failed to restore shards
            if (
                removed_segments
                and os.path.exists(rollback_disabled_dir)
                and not os.path.exists(segments_dir)
            ):
                os.replace(rollback_disabled_dir, segments_dir)
                removed_segments = False
            raise
    except Exception:
        # Restore the displaced shards dir if anything went wrong
        if (
            displaced_shards_dir
            and os.path.exists(displaced_shards_dir)
            and not os.path.exists(shards_dir)
        ):
            os.replace(displaced_shards_dir, shards_dir)
        raise

    return {
        "status": "rolled_back" if restored else "no_backup",
        "restored_shards": restored,
        "segments_removed": removed_segments,
        "shards_path": shards_dir if restored else None,
    }
