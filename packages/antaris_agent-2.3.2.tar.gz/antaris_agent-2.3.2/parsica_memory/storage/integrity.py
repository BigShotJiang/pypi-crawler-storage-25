"""Dedicated integrity validation for Parsica Memory v3.3 segmented storage.

This module provides comprehensive, non-destructive validation of the entire
storage layer — manifest, segments, hot buffer, tombstones, and orphan files.
It is the diagnostic foundation that ``repair.py`` and ``snapshot.py`` build on.

Design principles
-----------------
- **Read-only**: No mutations.  Every function only reads and reports.
- **Zero external dependencies**: stdlib only (hashlib, json, pathlib, dataclasses).
- **Granular reporting**: Each issue carries a severity, machine-readable code,
  human message, optional path, and optional details dict.
- **Machine-readable output**: ``ValidationReport.to_dict()`` / ``to_json()``
  produce stable JSON for CI pipelines and monitoring.
- **Composable**: ``validate_segment()``, ``validate_hot()``, ``scan_orphans()``
  can be called independently; ``validate_store()`` orchestrates them all.

Issue severities
~~~~~~~~~~~~~~~~
``info``
    Informational observation (e.g. recovered segment markers).
``warning``
    Non-fatal anomaly (e.g. orphan files, oversized hot buffer).
``error``
    Data integrity violation (e.g. checksum mismatch, missing segment).

Python 3.10+.  No external dependencies.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Literal

# ---------------------------------------------------------------------------
# Type aliases
# ---------------------------------------------------------------------------

Severity = Literal["info", "warning", "error"]

IssueCode = Literal[
    "missing_manifest",
    "invalid_manifest",
    "missing_segment_file",
    "duplicate_sequence",
    "duplicate_filename",
    "checksum_mismatch",
    "entry_count_mismatch",
    "orphan_file",
    "missing_hot_file",
    "invalid_hot_file",
    "hot_malformed_line",
    "hot_oversized",
    "rotating_hot_present",
    "hot_manifest_mismatch",
    "tombstone_orphan",
    "search_index_stale",
    "segment_read_error",
    "segment_empty",
    "segment_malformed_line",
    "manifest_schema_error",
]


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

@dataclass(slots=True)
class ValidationIssue:
    """A single validation finding."""

    severity: Severity
    code: IssueCode
    message: str
    path: str | None = None
    details: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Serialise to a plain dict (JSON-safe)."""
        d: dict[str, Any] = {
            "severity": self.severity,
            "code": self.code,
            "message": self.message,
        }
        if self.path is not None:
            d["path"] = self.path
        if self.details:
            d["details"] = self.details
        return d


@dataclass(slots=True)
class SegmentValidation:
    """Per-segment validation result."""

    path: str
    exists: bool
    checksum_expected: str | None = None
    checksum_actual: str | None = None
    entry_count: int | None = None
    ok: bool = True
    issues: list[ValidationIssue] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "path": self.path,
            "exists": self.exists,
            "checksum_expected": self.checksum_expected,
            "checksum_actual": self.checksum_actual,
            "entry_count": self.entry_count,
            "ok": self.ok,
            "issues": [i.to_dict() for i in self.issues],
        }


@dataclass(slots=True)
class HotValidation:
    """Hot buffer validation result."""

    path: str
    exists: bool
    size_bytes: int = 0
    total_lines: int = 0
    valid_lines: int = 0
    malformed_lines: int = 0
    put_count: int = 0
    delete_count: int = 0
    ok: bool = True
    issues: list[ValidationIssue] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "path": self.path,
            "exists": self.exists,
            "size_bytes": self.size_bytes,
            "total_lines": self.total_lines,
            "valid_lines": self.valid_lines,
            "malformed_lines": self.malformed_lines,
            "put_count": self.put_count,
            "delete_count": self.delete_count,
            "ok": self.ok,
            "issues": [i.to_dict() for i in self.issues],
        }


@dataclass(slots=True)
class ValidationReport:
    """Full store validation report."""

    workspace: str
    ok: bool
    issues: list[ValidationIssue] = field(default_factory=list)
    segments: list[SegmentValidation] = field(default_factory=list)
    hot: HotValidation | None = None
    orphan_paths: list[str] = field(default_factory=list)
    # Counters
    total_physical_entries: int = 0
    total_logical_entries: int = 0
    tombstone_count: int = 0
    tombstone_orphan_count: int = 0
    generation: int = 0

    def error_count(self) -> int:
        """Count issues with severity == 'error'."""
        return sum(1 for i in self.issues if i.severity == "error")

    def warning_count(self) -> int:
        """Count issues with severity == 'warning'."""
        return sum(1 for i in self.issues if i.severity == "warning")

    def to_dict(self) -> dict[str, Any]:
        """Serialise the full report to a JSON-safe dict."""
        d: dict[str, Any] = {
            "workspace": self.workspace,
            "ok": self.ok,
            "error_count": self.error_count(),
            "warning_count": self.warning_count(),
            "total_physical_entries": self.total_physical_entries,
            "total_logical_entries": self.total_logical_entries,
            "tombstone_count": self.tombstone_count,
            "tombstone_orphan_count": self.tombstone_orphan_count,
            "generation": self.generation,
            "issues": [i.to_dict() for i in self.issues],
            "segments": [s.to_dict() for s in self.segments],
            "orphan_paths": self.orphan_paths,
        }
        if self.hot is not None:
            d["hot"] = self.hot.to_dict()
        return d

    def to_json(self, indent: int = 2) -> str:
        """Serialise the full report to a JSON string."""
        return json.dumps(self.to_dict(), indent=indent, sort_keys=False)


# ---------------------------------------------------------------------------
# Low-level helpers
# ---------------------------------------------------------------------------

def sha256_file(path: Path) -> str:
    """Compute the SHA-256 hex digest of a file's raw bytes."""
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _load_json(path: Path) -> dict[str, Any]:
    """Load and parse a JSON file, returning the parsed dict."""
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def _count_jsonl_entries(path: Path) -> tuple[int, int, int]:
    """Count entries in a JSONL file.

    Returns (total_lines, valid_entries, malformed_lines).
    Only non-empty lines are counted.
    """
    total = 0
    valid = 0
    malformed = 0
    with path.open("r", encoding="utf-8", errors="replace") as f:
        for raw_line in f:
            line = raw_line.strip()
            if not line:
                continue
            total += 1
            try:
                obj = json.loads(line)
                if isinstance(obj, dict):
                    valid += 1
                else:
                    malformed += 1
            except (json.JSONDecodeError, ValueError):
                malformed += 1
    return total, valid, malformed


# ---------------------------------------------------------------------------
# Segment validation
# ---------------------------------------------------------------------------

def validate_segment(
    path: Path,
    checksum_expected: str | None = None,
    *,
    count_entries: bool = True,
) -> SegmentValidation:
    """Validate a single segment file.

    Checks:
    - File exists.
    - SHA-256 checksum matches ``checksum_expected`` (if provided).
    - File is readable and contains valid JSONL entries.
    - File is not empty (warning if zero valid entries).

    Parameters
    ----------
    path : Path
        Path to the segment file.
    checksum_expected : str or None
        Expected SHA-256 hex digest from the manifest.
    count_entries : bool
        If True, parse the file and count valid JSONL entries.

    Returns
    -------
    SegmentValidation
    """
    result = SegmentValidation(
        path=str(path),
        exists=path.exists(),
        checksum_expected=checksum_expected,
    )

    if not path.exists():
        result.ok = False
        result.issues.append(
            ValidationIssue(
                severity="error",
                code="missing_segment_file",
                message=f"Referenced segment file is missing: {path.name}",
                path=str(path),
            )
        )
        return result

    # Checksum
    try:
        result.checksum_actual = sha256_file(path)
    except Exception as exc:
        result.ok = False
        result.issues.append(
            ValidationIssue(
                severity="error",
                code="segment_read_error",
                message="Failed to read segment for checksum.",
                path=str(path),
                details={"error": repr(exc)},
            )
        )
        return result

    if checksum_expected and result.checksum_actual != checksum_expected:
        result.ok = False
        result.issues.append(
            ValidationIssue(
                severity="error",
                code="checksum_mismatch",
                message="Segment checksum does not match manifest.",
                path=str(path),
                details={
                    "expected": checksum_expected,
                    "actual": result.checksum_actual,
                },
            )
        )

    # Entry count
    if count_entries:
        try:
            total, valid, malformed = _count_jsonl_entries(path)
            result.entry_count = valid
            if valid == 0 and total == 0:
                result.issues.append(
                    ValidationIssue(
                        severity="warning",
                        code="segment_empty",
                        message="Segment file contains zero entries.",
                        path=str(path),
                    )
                )
            if malformed > 0:
                result.issues.append(
                    ValidationIssue(
                        severity="warning",
                        code="segment_malformed_line",
                        message=f"Segment has {malformed} malformed line(s).",
                        path=str(path),
                        details={"malformed_lines": malformed},
                    )
                )
        except Exception as exc:
            result.ok = False
            result.issues.append(
                ValidationIssue(
                    severity="error",
                    code="segment_read_error",
                    message="Failed to read segment entries.",
                    path=str(path),
                    details={"error": repr(exc)},
                )
            )

    return result


# ---------------------------------------------------------------------------
# Hot buffer validation
# ---------------------------------------------------------------------------

# Threshold for "oversized" hot buffer warning (10 MB)
_HOT_SIZE_WARNING_BYTES = 10 * 1024 * 1024


def validate_hot(
    hot_path: Path,
    *,
    size_warning_bytes: int = _HOT_SIZE_WARNING_BYTES,
) -> HotValidation:
    """Validate the hot buffer file.

    Checks:
    - File exists.
    - File is parseable JSONL.
    - Reports malformed lines.
    - Warns if file is oversized.
    - Counts put vs delete operations.

    Parameters
    ----------
    hot_path : Path
        Path to ``hot.jsonl``.
    size_warning_bytes : int
        Emit a warning if the file exceeds this size.

    Returns
    -------
    HotValidation
    """
    result = HotValidation(path=str(hot_path), exists=hot_path.exists())

    if not hot_path.exists():
        result.ok = False
        result.issues.append(
            ValidationIssue(
                severity="error",
                code="missing_hot_file",
                message="Hot buffer file does not exist.",
                path=str(hot_path),
            )
        )
        return result

    # Size check
    try:
        result.size_bytes = hot_path.stat().st_size
    except OSError:
        result.size_bytes = 0

    if result.size_bytes > size_warning_bytes:
        result.issues.append(
            ValidationIssue(
                severity="warning",
                code="hot_oversized",
                message=(
                    f"Hot buffer is {result.size_bytes:,} bytes "
                    f"(threshold: {size_warning_bytes:,} bytes). "
                    "Consider flushing."
                ),
                path=str(hot_path),
                details={
                    "size_bytes": result.size_bytes,
                    "threshold_bytes": size_warning_bytes,
                },
            )
        )

    # Parse lines
    try:
        with hot_path.open("r", encoding="utf-8", errors="replace") as f:
            for raw_line in f:
                line = raw_line.strip()
                if not line:
                    continue
                result.total_lines += 1
                try:
                    obj = json.loads(line)
                    if not isinstance(obj, dict):
                        result.malformed_lines += 1
                        continue
                    result.valid_lines += 1
                    op = obj.get("op")
                    if op == "put":
                        result.put_count += 1
                    elif op == "delete":
                        result.delete_count += 1
                except (json.JSONDecodeError, ValueError):
                    result.malformed_lines += 1
    except Exception as exc:
        result.ok = False
        result.issues.append(
            ValidationIssue(
                severity="error",
                code="invalid_hot_file",
                message="Failed to read hot buffer.",
                path=str(hot_path),
                details={"error": repr(exc)},
            )
        )
        return result

    if result.malformed_lines > 0:
        result.ok = False
        result.issues.append(
            ValidationIssue(
                severity="error",
                code="hot_malformed_line",
                message=(
                    f"Hot buffer has {result.malformed_lines} malformed line(s) "
                    f"out of {result.total_lines} total."
                ),
                path=str(hot_path),
                details={
                    "malformed_lines": result.malformed_lines,
                    "total_lines": result.total_lines,
                },
            )
        )

    return result


# ---------------------------------------------------------------------------
# Orphan scanning
# ---------------------------------------------------------------------------

def scan_orphans(
    workspace: Path,
    referenced_paths: set[Path],
) -> list[Path]:
    """Find files in ``segments/`` not referenced by the manifest.

    Ignores ``.tmp`` files, ``manifest.json``, ``manifest.json.bak``,
    lock directories, and the ``quarantine/`` subdirectory.

    Parameters
    ----------
    workspace : Path
        Root workspace directory.
    referenced_paths : set[Path]
        Set of absolute paths that are referenced by the manifest.

    Returns
    -------
    list[Path]
        Sorted list of orphan file paths.
    """
    segments_dir = workspace / "segments"
    if not segments_dir.exists():
        return []

    # Normalise referenced paths to absolute
    referenced_abs = {p.resolve() for p in referenced_paths}

    skip_names = {
        "manifest.json",
        "manifest.json.bak",
        "segment_store.flush",  # flush lock directory
    }

    orphans: list[Path] = []
    for child in segments_dir.rglob("*"):
        if not child.is_file():
            continue
        # Skip temp files
        if child.name.endswith(".tmp"):
            continue
        # Skip known infrastructure files
        if child.name in skip_names:
            continue
        # Skip quarantine directory
        if "quarantine" in child.parts:
            continue
        # Skip lock directories (they contain lock files)
        if child.name.endswith(".lock") or ".lock" in str(child):
            continue
        # Check if referenced
        if child.resolve() not in referenced_abs:
            orphans.append(child)

    return sorted(orphans)


# ---------------------------------------------------------------------------
# Tombstone validation
# ---------------------------------------------------------------------------

def _collect_all_segment_hashes(
    workspace: Path,
    manifest: dict[str, Any],
) -> set[str]:
    """Read all entry hashes from all active segments.

    This is used to check whether tombstoned hashes actually exist in any
    segment.  Returns the union of all hashes found.
    """
    all_hashes: set[str] = set()
    segments_dir = workspace / "segments"

    for seg in manifest.get("segments", []):
        fname = seg.get("filename", "")
        seg_path = segments_dir / fname
        if not seg_path.exists():
            continue
        try:
            with seg_path.open("r", encoding="utf-8", errors="replace") as f:
                for raw_line in f:
                    line = raw_line.strip()
                    if not line:
                        continue
                    try:
                        obj = json.loads(line)
                        if isinstance(obj, dict):
                            h = obj.get("hash")
                            if isinstance(h, str) and h:
                                all_hashes.add(h)
                    except (json.JSONDecodeError, ValueError):
                        pass
        except OSError:
            pass

    return all_hashes


# ---------------------------------------------------------------------------
# Main validation orchestrator
# ---------------------------------------------------------------------------

def validate_store(workspace: str | Path) -> ValidationReport:
    """Comprehensive validation of the entire segmented store.

    Validates:
    1. Manifest existence and parseability.
    2. Manifest schema (required keys).
    3. Segment file existence and checksums.
    4. Duplicate sequence numbers.
    5. Hot buffer integrity (malformed lines, size).
    6. Tombstone consistency (orphan tombstones pointing to non-existent hashes).
    7. Orphan files in ``segments/``.
    8. Search index generation staleness.
    9. Physical vs logical entry counts.

    Parameters
    ----------
    workspace : str or Path
        Root workspace directory containing ``segments/``.

    Returns
    -------
    ValidationReport
        Complete validation report with all findings.
    """
    workspace = Path(workspace)
    report = ValidationReport(workspace=str(workspace), ok=True)

    manifest_path = workspace / "segments" / "manifest.json"

    # ── 1. Manifest existence ──────────────────────────────────────
    if not manifest_path.exists():
        report.ok = False
        report.issues.append(
            ValidationIssue(
                severity="error",
                code="missing_manifest",
                message="Segmented store manifest is missing.",
                path=str(manifest_path),
            )
        )
        return report

    # ── 2. Manifest parseability ───────────────────────────────────
    try:
        manifest = _load_json(manifest_path)
    except Exception as exc:
        report.ok = False
        report.issues.append(
            ValidationIssue(
                severity="error",
                code="invalid_manifest",
                message="Manifest could not be parsed as JSON.",
                path=str(manifest_path),
                details={"error": repr(exc)},
            )
        )
        return report

    if not isinstance(manifest, dict):
        report.ok = False
        report.issues.append(
            ValidationIssue(
                severity="error",
                code="invalid_manifest",
                message="Manifest root is not a JSON object.",
                path=str(manifest_path),
            )
        )
        return report

    # ── 3. Manifest schema ─────────────────────────────────────────
    required_keys = ("version", "generation", "segments", "hot", "tombstones")
    for key in required_keys:
        if key not in manifest:
            report.issues.append(
                ValidationIssue(
                    severity="error",
                    code="manifest_schema_error",
                    message=f"Manifest missing required key: {key!r}",
                    path=str(manifest_path),
                    details={"missing_key": key},
                )
            )

    report.generation = manifest.get("generation", 0)

    # ── 4. Segments ────────────────────────────────────────────────
    referenced: set[Path] = {
        manifest_path.resolve(),
        manifest_path.with_suffix(".json.bak").resolve(),
    }
    seen_sequences: set[int] = set()
    seen_filenames: set[str] = set()
    total_physical = 0

    for seg in manifest.get("segments", []):
        filename = seg.get("filename", "")
        sequence = seg.get("sequence")
        seg_path = workspace / "segments" / filename
        referenced.add(seg_path.resolve())

        # Duplicate sequence check
        if sequence is not None and sequence in seen_sequences:
            report.issues.append(
                ValidationIssue(
                    severity="error",
                    code="duplicate_sequence",
                    message=f"Duplicate segment sequence {sequence} in manifest.",
                    path=str(manifest_path),
                    details={"sequence": sequence, "filename": filename},
                )
            )
        if sequence is not None:
            seen_sequences.add(sequence)

        # Duplicate filename check
        if filename:
            if filename in seen_filenames:
                report.issues.append(
                    ValidationIssue(
                        severity="error",
                        code="duplicate_filename",
                        message=f"Duplicate segment filename '{filename}' in manifest.",
                        path=str(manifest_path),
                        details={"filename": filename},
                    )
                )
            else:
                seen_filenames.add(filename)

        # Validate the segment file
        sv = validate_segment(
            seg_path,
            checksum_expected=seg.get("checksum_sha256"),
        )
        report.segments.append(sv)

        if not sv.ok:
            report.issues.extend(sv.issues)
        else:
            # Collect non-error issues (warnings) from segment validation
            for issue in sv.issues:
                if issue not in report.issues:
                    report.issues.append(issue)

        # Physical entry count from manifest metadata
        manifest_count = seg.get("entry_count", 0)
        total_physical += manifest_count

        # Cross-check: if we counted entries, compare with manifest
        if sv.entry_count is not None and manifest_count > 0:
            if sv.entry_count != manifest_count:
                report.issues.append(
                    ValidationIssue(
                        severity="warning",
                        code="entry_count_mismatch",
                        message=(
                            f"Segment {filename}: manifest says {manifest_count} entries "
                            f"but file contains {sv.entry_count}."
                        ),
                        path=str(seg_path),
                        details={
                            "manifest_count": manifest_count,
                            "actual_count": sv.entry_count,
                        },
                    )
                )

    # ── 5. Hot buffer ──────────────────────────────────────────────
    hot_meta = manifest.get("hot", {})
    hot_filename = hot_meta.get("filename", "hot.jsonl") if isinstance(hot_meta, dict) else "hot.jsonl"
    hot_path = workspace / "segments" / hot_filename
    referenced.add(hot_path.resolve())

    # Also reference the rotating file if it exists
    rotating_path = workspace / "segments" / "hot.rotating.jsonl"
    if rotating_path.exists():
        referenced.add(rotating_path.resolve())

    hot_val = validate_hot(hot_path)
    report.hot = hot_val

    if not hot_val.exists:
        report.issues.append(
            ValidationIssue(
                severity="error",
                code="missing_hot_file",
                message="Hot file referenced by manifest does not exist.",
                path=str(hot_path),
            )
        )
    if not hot_val.ok:
        report.issues.extend(hot_val.issues)
    else:
        # Collect warnings even when ok
        for issue in hot_val.issues:
            if issue not in report.issues:
                report.issues.append(issue)

    # ── 5b. Rotating hot buffer ───────────────────────────────────
    if rotating_path.exists():
        report.issues.append(
            ValidationIssue(
                severity="warning",
                code="rotating_hot_present",
                message="hot.rotating.jsonl is present and should be reconciled.",
                path=str(rotating_path),
            )
        )

    # ── 5c. Hot manifest counter mismatch ─────────────────────────
    if hot_val.exists and isinstance(hot_meta, dict):
        manifest_put = hot_meta.get("put_count", 0)
        manifest_del = hot_meta.get("delete_count", 0)
        if manifest_put != hot_val.put_count or manifest_del != hot_val.delete_count:
            report.issues.append(
                ValidationIssue(
                    severity="warning",
                    code="hot_manifest_mismatch",
                    message="Manifest hot counters do not match hot.jsonl contents.",
                    path=str(hot_path),
                    details={
                        "manifest_put_count": manifest_put,
                        "manifest_delete_count": manifest_del,
                        "actual_put_count": hot_val.put_count,
                        "actual_delete_count": hot_val.delete_count,
                    },
                )
            )

    # ── 6. Tombstone consistency ───────────────────────────────────
    tombstones = manifest.get("tombstones", {})
    report.tombstone_count = len(tombstones) if isinstance(tombstones, dict) else 0

    if isinstance(tombstones, dict) and tombstones:
        # Collect all hashes from segments to check tombstone validity
        all_segment_hashes = _collect_all_segment_hashes(workspace, manifest)

        orphan_tombstone_count = 0
        for ts_hash in tombstones:
            if ts_hash not in all_segment_hashes:
                orphan_tombstone_count += 1

        report.tombstone_orphan_count = orphan_tombstone_count
        if orphan_tombstone_count > 0:
            report.issues.append(
                ValidationIssue(
                    severity="info",
                    code="tombstone_orphan",
                    message=(
                        f"{orphan_tombstone_count} tombstone(s) reference hashes "
                        "not found in any active segment. These may be stale "
                        "tombstones from already-compacted entries."
                    ),
                    details={
                        "orphan_tombstone_count": orphan_tombstone_count,
                        "total_tombstones": len(tombstones),
                    },
                )
            )

    # ── 7. Orphan files ───────────────────────────────────────────
    for orphan in scan_orphans(workspace, referenced):
        report.orphan_paths.append(str(orphan))
        report.issues.append(
            ValidationIssue(
                severity="warning",
                code="orphan_file",
                message=f"Unreferenced file in segments/: {orphan.name}",
                path=str(orphan),
            )
        )

    # ── 8. Search index generation staleness ──────────────────────
    search_meta = manifest.get("search", {})
    if isinstance(search_meta, dict):
        index_gen = search_meta.get("index_generation", 0)
        store_gen = manifest.get("generation", 0)
        if isinstance(index_gen, int) and isinstance(store_gen, int):
            if index_gen < store_gen:
                report.issues.append(
                    ValidationIssue(
                        severity="info",
                        code="search_index_stale",
                        message=(
                            f"Search index generation ({index_gen}) is behind "
                            f"store generation ({store_gen}). "
                            "Search index may need rebuilding."
                        ),
                        details={
                            "index_generation": index_gen,
                            "store_generation": store_gen,
                        },
                    )
                )

    # ── 9. Entry counts ───────────────────────────────────────────
    report.total_physical_entries = total_physical
    # Logical = physical minus tombstones (approximate — tombstones may
    # reference entries in the hot buffer, not just segments)
    report.total_logical_entries = max(
        0, total_physical - report.tombstone_count
    )

    # Add hot buffer entries to physical count
    if hot_val.exists and hot_val.put_count > 0:
        report.total_physical_entries += hot_val.put_count

    # ── Final ok determination ────────────────────────────────────
    if report.error_count() > 0:
        report.ok = False

    return report
