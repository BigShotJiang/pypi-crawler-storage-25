"""Parsica Memory v3.2.0 — Segmented Storage Layer.

Architecture Overview
---------------------
The storage package implements a log-structured, append-only persistence
layer for Parsica Memory entries.  It consists of four cooperating
components:

Hot buffer (``hot.jsonl``)
    The single mutable file.  Every put or delete is appended as a JSON
    operation envelope and fsynced before returning to the caller.
    The hot buffer is the only file that grows; all other files are either
    immutable or atomically replaced.

Immutable JSONL segments (``seg_NNNN_<ts>_<count>.jsonl``)
    Frozen snapshots of memory entries written during a *flush*.  Segments
    are write-once: once written they are never modified, only compacted
    away.  Each segment is self-contained JSONL — no sidecar files, no
    in-band metadata.

Atomic manifest (``manifest.json``)
    The sole source of truth.  Tracks which segments exist, tombstones
    (deleted hashes), hot-buffer state, a monotonically increasing
    *generation counter* for optimistic concurrency, and migration
    metadata.  Every mutation is guarded by ``FileLock`` and persisted via
    atomic rename.  A backup copy (``manifest.json.bak``) is maintained
    for one-level crash recovery.

Tombstones
    Deletes are recorded in the manifest's ``tombstones`` dict (hash →
    {deleted_at, reason}).  Tombstones suppress entries during ``load()``
    and are resolved (removed) when the corresponding hash is compacted
    away.

Flush lifecycle
    1. Hot buffer reaches a threshold (ops count, size, or age).
    2. ``SegmentStore.flush()`` renames ``hot.jsonl`` →
       ``hot.rotating.jsonl`` (crash-safe pivot point).
    3. Ops are replayed; net puts are written to a new immutable segment.
    4. Manifest is updated atomically (new segment + tombstones + reset hot).
    5. ``hot.rotating.jsonl`` is deleted.

Compaction lifecycle
    Segments in the same size tier (Tier 0 / 1 / 2) are merged when four
    or more accumulate.  Tombstones are resolved, duplicates deduplicated,
    and a new segment written.  The old files are deleted after the
    manifest is updated.

Crash safety
    * The hot buffer is append-only and fsynced per write — no data loss
      for committed ops.
    * ``hot.rotating.jsonl`` left on disk after a crash is replayed during
      the next ``load()`` (crash recovery path in ``SegmentStore.load()``).
    * Immutable segments are verified via SHA-256 checksums stored in the
      manifest.

Module map
----------
:mod:`parsica_memory.storage.manifest`
    :class:`~parsica_memory.storage.manifest.Manifest` — manifest I/O,
    locking, generation counter, and :class:`ManifestConflictError`.

:mod:`parsica_memory.storage.segments`
    :class:`~parsica_memory.storage.segments.SegmentWriter` — write
    immutable segments.
    :class:`~parsica_memory.storage.segments.SegmentReader` — read and
    verify segments.
    :class:`~parsica_memory.storage.segments.HotBuffer` — append-only
    hot log with fsync-per-write semantics.

:mod:`parsica_memory.storage.segment_store`
    :class:`~parsica_memory.storage.segment_store.SegmentStore` —
    orchestrator; the only class that external callers should depend on.

:mod:`parsica_memory.storage.migration`
    Functions for detecting legacy storage formats, migrating to
    segments, verifying migration integrity, and rolling back.
"""

from .manifest import Manifest, ManifestConflictError
from .segments import HotBuffer, SegmentReader, SegmentWriter
from .segment_store import SegmentStore
from .repair import doctor, repair_manifest, quarantine_orphans
from .migration import (
    detect_storage_format,
    migrate_to_segments,
    rollback_migration,
    verify_migration,
)
from .integrity import validate_store, ValidationReport
from .snapshot import (
    SnapshotFile,
    SnapshotManifest,
    StoreValidationError,
    VerifyResult,
    RestoreResult,
    create_snapshot,
    verify_snapshot,
    restore_snapshot,
    snapshot_info,
)

__all__ = [
    # Manifest
    "Manifest",
    "ManifestConflictError",
    # Segment I/O
    "SegmentWriter",
    "SegmentReader",
    "HotBuffer",
    # Orchestrator
    "SegmentStore",
    # Repair
    "doctor",
    "repair_manifest",
    "quarantine_orphans",
    # Migration
    "detect_storage_format",
    "migrate_to_segments",
    "verify_migration",
    "rollback_migration",
    # Integrity
    "validate_store",
    "ValidationReport",
    # Snapshot
    "SnapshotFile",
    "SnapshotManifest",
    "StoreValidationError",
    "VerifyResult",
    "RestoreResult",
    "create_snapshot",
    "verify_snapshot",
    "restore_snapshot",
    "snapshot_info",
]
