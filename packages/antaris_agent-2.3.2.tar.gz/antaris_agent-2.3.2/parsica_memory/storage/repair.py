"""Operator repair tooling for Parsica Memory v3.3 segmented storage.

This module provides diagnostic and repair functions for the segmented store.
It delegates all validation to :mod:`parsica_memory.storage.integrity` so that
``parsica validate`` and ``parsica doctor`` always run the **same** validation
logic.

Design principles
-----------------
- **Backup before mutation**: Every repair function creates a backup of any
  file it modifies before writing.
- **Dry-run support**: All repair functions accept ``dry_run=True`` (the
  default) to preview changes without modifying the store.
- **Diagnosis ≠ treatment**: ``doctor()`` returns a ``RepairPlan`` with
  recommended actions but does **not** execute them.
- **Validation is imported, not reimplemented**: All validation primitives
  come from ``integrity.py``.

Python 3.10+.  No external dependencies.
"""

from __future__ import annotations

import json
import os
import shutil
import tempfile
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Literal

from .integrity import (
    ValidationIssue,
    ValidationReport,
    SegmentValidation,
    validate_store,
    scan_orphans,
    validate_segment,
)
from .manifest import Manifest
from .segment_store import _read_ops_from_path
from .segments import HotBuffer

RepairActionType = Literal[
    "restore_backup_manifest",
    "rebuild_manifest",
    "quarantine_orphans",
    "reconcile_hot_state",
]


@dataclass(slots=True)
class RepairAction:
    """A single recommended or applied repair action."""

    action_type: RepairActionType
    description: str
    details: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class RepairPlan:
    """Diagnostic plan returned by :func:`doctor`.

    Contains the validation report and a list of recommended repair actions.
    The plan does **not** execute any repairs — it is purely diagnostic.
    """

    workspace: str
    dry_run: bool
    ok: bool
    validation: ValidationReport
    actions: list[RepairAction] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def to_json(self, *, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent, sort_keys=True)


@dataclass(slots=True)
class RepairResult:
    """Result of a repair operation (manifest rebuild, quarantine, reconcile)."""

    workspace: str
    dry_run: bool = True
    changed: bool = False
    applied: list[RepairAction] = field(default_factory=list)
    backups_created: list[str] = field(default_factory=list)
    validation_before: ValidationReport | None = None
    validation_after: ValidationReport | None = None
    details: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def to_json(self, *, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent, sort_keys=True)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _timestamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def _backup_path(path: Path) -> Path:
    return path.with_name(f"{path.name}.bak.{_timestamp()}.{uuid.uuid4().hex[:8]}")


def _safe_copy(src: Path, dst: Path) -> None:
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)


def _backup_file(path: Path, created: list[str]) -> None:
    if not path.exists():
        return
    backup = _backup_path(path)
    _safe_copy(path, backup)
    created.append(str(backup))


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def doctor(workspace: str | Path, dry_run: bool = True) -> RepairPlan:
    """Diagnose store health and recommend repair actions.

    Runs the full ``integrity.validate_store()`` validation and maps the
    resulting issues to a set of recommended repair actions.  Does **not**
    execute any repairs — call the individual repair functions to apply.

    Parameters
    ----------
    workspace : str or Path
        Root workspace directory containing ``segments/``.
    dry_run : bool
        Passed through to the ``RepairPlan`` for informational purposes.
        ``doctor()`` itself never mutates the store regardless of this flag.

    Returns
    -------
    RepairPlan
        Diagnostic plan with ``validation`` report and ``actions`` list.

    Notes
    -----
    The ``plan.ok`` field mirrors ``report.ok`` from the validation report.
    A plan with ``ok=True`` and an empty ``actions`` list means the store
    is healthy and no repairs are needed.
    """
    workspace = Path(workspace)
    report = validate_store(workspace)
    plan = RepairPlan(
        workspace=str(workspace),
        dry_run=dry_run,
        ok=report.ok,
        validation=report,
    )

    manifest_path = workspace / "segments" / "manifest.json"
    backup_manifest = workspace / "segments" / "manifest.json.bak"

    # Determine which repair actions are needed based on issue codes
    issue_codes = {issue.code for issue in report.issues}

    needs_manifest_rebuild = bool(
        issue_codes
        & {
            "missing_manifest",
            "invalid_manifest",
            "missing_segment_file",
            "duplicate_sequence",
            "duplicate_filename",
            "checksum_mismatch",
        }
    )
    needs_hot_reconcile = bool(
        issue_codes
        & {
            "missing_hot_file",
            "invalid_hot_file",
            "rotating_hot_present",
            "hot_manifest_mismatch",
        }
    )

    if backup_manifest.exists() and issue_codes & {
        "missing_manifest",
        "invalid_manifest",
    }:
        plan.actions.append(
            RepairAction(
                action_type="restore_backup_manifest",
                description="Backup manifest exists and may be restorable.",
                details={
                    "backup_manifest": str(backup_manifest),
                    "manifest": str(manifest_path),
                },
            )
        )

    if needs_manifest_rebuild:
        plan.actions.append(
            RepairAction(
                action_type="rebuild_manifest",
                description="Rebuild manifest from on-disk segment files.",
                details={"manifest": str(manifest_path)},
            )
        )

    if report.orphan_paths:
        plan.actions.append(
            RepairAction(
                action_type="quarantine_orphans",
                description="Move orphan files to a quarantine directory.",
                details={"orphans": list(report.orphan_paths)},
            )
        )

    if needs_hot_reconcile:
        plan.actions.append(
            RepairAction(
                action_type="reconcile_hot_state",
                description="Reconcile hot.jsonl / hot.rotating.jsonl and reset manifest hot counters.",
                details={
                    "hot": str(workspace / "segments" / "hot.jsonl"),
                },
            )
        )

    return plan


def repair_manifest(
    workspace: str | Path, dry_run: bool = True
) -> RepairResult:
    """Rebuild the manifest from on-disk segment files.

    Uses ``Manifest.rebuild_from_disk()`` to scan the ``segments/``
    directory and reconstruct a valid manifest.  The rebuilt manifest is
    written atomically via a temp file + ``os.replace()``.

    Parameters
    ----------
    workspace : str or Path
        Root workspace directory containing ``segments/``.
    dry_run : bool
        If ``True`` (default), compute the rebuilt manifest but do not
        write it to disk.  The rebuilt data is available in
        ``result.details["rebuilt_manifest"]``.

    Returns
    -------
    RepairResult
        Result with ``changed=True`` if the manifest was written,
        ``validation_before`` and ``validation_after`` reports, and
        ``backups_created`` listing any backup files made.

    Notes
    -----
    When ``dry_run=False``, existing ``manifest.json`` and
    ``manifest.json.bak`` are backed up before overwriting.  The backup
    filenames include a UTC timestamp and a short UUID suffix to prevent
    collisions.
    """
    workspace = Path(workspace)
    result = RepairResult(workspace=str(workspace), dry_run=dry_run)
    result.validation_before = validate_store(workspace)

    manifest_path = workspace / "segments" / "manifest.json"
    segments_dir = workspace / "segments"
    manifest = Manifest.__new__(Manifest)
    manifest.segments_dir = str(segments_dir)
    manifest.manifest_path = str(manifest_path)
    manifest.backup_path = str(segments_dir / "manifest.json.bak")
    manifest._path = manifest.manifest_path
    manifest._bak_path = manifest.backup_path
    manifest._data = {}
    rebuilt = Manifest.rebuild_from_disk(manifest)

    result.details["rebuilt_manifest"] = rebuilt
    result.applied.append(
        RepairAction(
            action_type="rebuild_manifest",
            description="Rebuilt manifest from disk scan.",
            details={
                "segment_count": len(rebuilt.get("segments", [])),
                "generation": rebuilt.get("generation", 0),
            },
        )
    )

    if dry_run:
        simulated = ValidationReport(workspace=str(workspace), ok=True)
        simulated.issues = [
            issue
            for issue in (
                result.validation_before.issues
                if result.validation_before
                else []
            )
            if issue.code
            not in {
                "missing_manifest",
                "invalid_manifest",
                "missing_segment_file",
                "duplicate_sequence",
                "duplicate_filename",
                "checksum_mismatch",
            }
        ]
        simulated.orphan_paths = list(
            result.validation_before.orphan_paths
            if result.validation_before
            else []
        )
        result.validation_after = simulated
        return result

    segments_dir.mkdir(parents=True, exist_ok=True)
    _backup_file(manifest_path, result.backups_created)
    backup_manifest = segments_dir / "manifest.json.bak"
    _backup_file(backup_manifest, result.backups_created)

    with tempfile.NamedTemporaryFile(
        "w",
        dir=segments_dir,
        encoding="utf-8",
        delete=False,
        suffix=".json.tmp",
    ) as handle:
        json.dump(rebuilt, handle, indent=2, sort_keys=True)
        handle.flush()
        os.fsync(handle.fileno())
        temp_path = Path(handle.name)
    os.replace(temp_path, manifest_path)
    shutil.copy2(manifest_path, backup_manifest)

    result.changed = True
    result.validation_after = validate_store(workspace)
    return result


def quarantine_orphans(
    workspace: str | Path, dry_run: bool = True
) -> RepairResult:
    """Move orphan files to a quarantine directory.

    Orphan files are those in ``segments/`` that are not referenced by the
    manifest.  Each orphan is backed up before being moved to
    ``segments/quarantine/<timestamp>/<relative_path>``.

    Parameters
    ----------
    workspace : str or Path
        Root workspace directory containing ``segments/``.
    dry_run : bool
        If ``True`` (default), list what would be moved without actually
        moving anything.  The planned moves are recorded in
        ``result.applied``.

    Returns
    -------
    RepairResult
        Result with ``changed=True`` if any files were moved,
        ``validation_before`` and ``validation_after`` reports, and
        ``backups_created`` listing backup copies of moved files.

    Notes
    -----
    The quarantine directory is timestamped so that multiple quarantine
    runs do not collide.  Orphan files are backed up before being moved,
    so the original data exists in three places: the backup, the
    quarantine, and (if dry_run) the original location.
    """
    workspace = Path(workspace)
    result = RepairResult(workspace=str(workspace), dry_run=dry_run)
    result.validation_before = validate_store(workspace)
    orphan_paths = (
        [Path(path) for path in result.validation_before.orphan_paths]
        if result.validation_before
        else []
    )
    quarantine_dir = workspace / "segments" / "quarantine" / _timestamp()
    result.details["quarantine_dir"] = str(quarantine_dir)
    result.details["orphans"] = [str(path) for path in orphan_paths]

    if dry_run:
        for orphan in orphan_paths:
            rel = orphan.relative_to(workspace / "segments")
            result.applied.append(
                RepairAction(
                    action_type="quarantine_orphans",
                    description="Would move orphan to quarantine.",
                    details={
                        "from": str(orphan),
                        "to": str(quarantine_dir / rel),
                    },
                )
            )
        result.validation_after = result.validation_before
        return result

    for orphan in orphan_paths:
        _backup_file(orphan, result.backups_created)
        rel = orphan.relative_to(workspace / "segments")
        target = quarantine_dir / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(orphan), str(target))
        result.applied.append(
            RepairAction(
                action_type="quarantine_orphans",
                description="Moved orphan to quarantine.",
                details={"from": str(orphan), "to": str(target)},
            )
        )

    result.changed = bool(orphan_paths)
    result.validation_after = validate_store(workspace)
    return result


def reconcile_hot_state(
    workspace: str | Path, dry_run: bool = True
) -> RepairResult:
    """Reconcile hot buffer state and reset manifest counters.

    Merges ``hot.rotating.jsonl`` (if present) and ``hot.jsonl`` into a
    single rebuilt ``hot.jsonl``, then updates the manifest's hot counters
    to match.  Operations from the rotating file are placed **before**
    current hot operations to preserve the original timeline.

    Parameters
    ----------
    workspace : str or Path
        Root workspace directory containing ``segments/``.
    dry_run : bool
        If ``True`` (default), compute the merged state but do not write
        any files.  The computed details (op counts, etc.) are available
        in ``result.details``.

    Returns
    -------
    RepairResult
        Result with ``changed=True`` if files were modified,
        ``validation_before`` and ``validation_after`` reports, and
        ``backups_created`` listing backup copies of modified files.

    Notes
    -----
    All three files (``hot.jsonl``, ``hot.rotating.jsonl``,
    ``manifest.json``) are backed up before any mutation.  The rebuilt
    ``hot.jsonl`` is written atomically via a temp file +
    ``os.replace()``.  The caller is expected to quiesce the store before
    running this — concurrent writes during reconciliation may be lost.
    """
    workspace = Path(workspace)
    result = RepairResult(workspace=str(workspace), dry_run=dry_run)
    result.validation_before = validate_store(workspace)

    segments_dir = workspace / "segments"
    hot = HotBuffer(str(segments_dir))
    hot_path = Path(hot.hot_path)
    rotating_path = Path(hot.rotating_path)
    manifest_path = segments_dir / "manifest.json"

    rotating_ops = (
        _read_ops_from_path(str(rotating_path))
        if rotating_path.exists()
        else []
    )
    current_hot_ops = hot.read_ops() if hot_path.exists() else []
    combined_ops = rotating_ops + current_hot_ops
    put_count = sum(1 for op in combined_ops if op.get("op") == "put")
    delete_count = sum(1 for op in combined_ops if op.get("op") == "delete")

    result.details.update(
        {
            "rotating_present": rotating_path.exists(),
            "hot_present": hot_path.exists(),
            "rotating_ops": len(rotating_ops),
            "hot_ops": len(current_hot_ops),
            "combined_ops": len(combined_ops),
            "put_count": put_count,
            "delete_count": delete_count,
        }
    )

    result.applied.append(
        RepairAction(
            action_type="reconcile_hot_state",
            description="Rebuild hot.jsonl from rotating + current hot ops and reset manifest hot counters.",
            details={
                "combined_ops": len(combined_ops),
                "put_count": put_count,
                "delete_count": delete_count,
            },
        )
    )

    if dry_run:
        result.validation_after = result.validation_before
        return result

    _backup_file(hot_path, result.backups_created)
    _backup_file(rotating_path, result.backups_created)
    _backup_file(manifest_path, result.backups_created)

    segments_dir.mkdir(parents=True, exist_ok=True)
    fd, temp_path_str = tempfile.mkstemp(
        dir=segments_dir, suffix=".jsonl.tmp"
    )
    temp_path = Path(temp_path_str)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            for op in combined_ops:
                handle.write(json.dumps(op, ensure_ascii=False) + "\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_path, hot_path)
    finally:
        if temp_path.exists():
            try:
                temp_path.unlink()
            except OSError:
                pass

    if rotating_path.exists():
        rotating_path.unlink()

    manifest = Manifest(str(segments_dir))
    manifest_data = manifest.load()
    manifest_data.setdefault("hot", {})
    manifest_data["hot"]["filename"] = "hot.jsonl"
    manifest_data["hot"]["put_count"] = put_count
    manifest_data["hot"]["delete_count"] = delete_count
    manifest_data["hot"]["last_write_at"] = (
        combined_ops[-1].get("ts") if combined_ops else None
    )
    manifest._data = manifest_data
    manifest.save()

    result.changed = bool(
        combined_ops or rotating_ops or current_hot_ops or not hot_path.exists()
    )
    result.validation_after = validate_store(workspace)
    return result
