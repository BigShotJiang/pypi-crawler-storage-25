"""Snapshot — create, verify, and restore Parsica Memory store snapshots.

A snapshot is a complete, portable, self-contained copy of a segmented store.
It captures all files that compose the store's durable state and embeds a
machine-readable manifest of checksums so that integrity can be verified at
any point after creation.

Snapshot layout
---------------
::

    <snapshot_dir>/
        snapshot_manifest.json          ← machine-readable snapshot index
        segments/
            manifest.json               ← store manifest (primary)
            manifest.json.bak           ← store manifest (backup, if present)
            hot.jsonl                   ← hot buffer at snapshot time
            hot.rotating.jsonl          ← rotating buffer (if mid-flush)
            seg_0001_20260101T000000Z_123.jsonl
            seg_0002_...
            ...

Design contracts
----------------
* **Create**: validates the store first — snapshots of invalid stores are
  refused.  Every copied file's SHA-256 is recorded in ``snapshot_manifest.json``.

* **Verify**: re-computes SHA-256 for every file listed in
  ``snapshot_manifest.json`` and compares.  Returns a structured result.

* **Restore**: verifies the snapshot first, then restores via a staging
  directory (copy → verify → atomic swap).  The previous workspace content
  is moved to ``.restore_backup_<timestamp>_<uuid>/`` before the swap so
  data is never silently overwritten.

Zero external dependencies.  Python 3.10+.
"""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import tempfile
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _utcnow_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _utcnow_tag() -> str:
    """Return a compact UTC timestamp string suitable for filenames."""
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def _sha256_file(path: Path) -> str:
    """Compute the SHA-256 hex digest of a file."""
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp_path = path.with_suffix(".tmp")
    with tmp_path.open("w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, sort_keys=True)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp_path, path)


# ---------------------------------------------------------------------------
# Store validation (inlined — integrity.py may not exist yet)
# ---------------------------------------------------------------------------

class StoreValidationError(ValueError):
    """Raised when the store fails pre-snapshot validation."""


def _validate_store_for_snapshot(workspace: Path) -> None:
    """Minimal store validation before snapshotting.

    Checks:
    - segments/ directory exists
    - manifest.json is present and valid JSON
    - manifest.json has required keys
    - all referenced segment files exist
    - hot.jsonl is present (may be empty)

    Raises :class:`StoreValidationError` if any check fails.
    """
    segments_dir = workspace / "segments"
    if not segments_dir.is_dir():
        raise StoreValidationError(
            f"segments/ directory not found at {segments_dir}. "
            "This does not look like a valid Parsica segmented store."
        )

    manifest_path = segments_dir / "manifest.json"
    if not manifest_path.exists():
        raise StoreValidationError(
            f"manifest.json is missing from {segments_dir}. "
            "Run validate/doctor before snapshotting."
        )

    try:
        manifest = _read_json(manifest_path)
    except (json.JSONDecodeError, OSError) as exc:
        raise StoreValidationError(
            f"manifest.json cannot be parsed: {exc}"
        ) from exc

    if not isinstance(manifest, dict):
        raise StoreValidationError("manifest.json is not a JSON object.")

    required_keys = ("version", "generation", "segments", "hot", "tombstones")
    missing = [k for k in required_keys if k not in manifest]
    if missing:
        raise StoreValidationError(
            f"manifest.json is missing required keys: {missing}. "
            "Run validate/doctor before snapshotting."
        )

    # Validate all referenced segment files are present
    missing_segments: list[str] = []
    for seg in manifest.get("segments", []):
        fname = seg.get("filename")
        if not fname:
            raise StoreValidationError(
                f"Segment entry in manifest has no 'filename': {seg}"
            )
        seg_path = segments_dir / fname
        if not seg_path.exists():
            missing_segments.append(fname)

    if missing_segments:
        raise StoreValidationError(
            f"Segments referenced in manifest are missing on disk: {missing_segments}. "
            "Run validate/doctor before snapshotting."
        )

    # hot.jsonl must exist (may be empty)
    hot_name = manifest.get("hot", {}).get("filename", "hot.jsonl")
    hot_path = segments_dir / hot_name
    if not hot_path.exists():
        raise StoreValidationError(
            f"Hot buffer file '{hot_name}' is missing from {segments_dir}. "
            "Run validate/doctor before snapshotting."
        )


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

@dataclass(slots=True)
class SnapshotFile:
    """Metadata for a single file captured in a snapshot."""
    path: str       # relative path from snapshot root (e.g. "segments/manifest.json")
    sha256: str     # SHA-256 hex digest of the file's raw bytes
    size_bytes: int # file size in bytes


@dataclass(slots=True)
class SnapshotManifest:
    """Full machine-readable manifest for a snapshot.

    This is written as ``snapshot_manifest.json`` in the snapshot root and
    is the sole source of truth for snapshot verification and restoration.
    """
    snapshot_id: str            # e.g. "snap-20260101T120000Z-abc12345"
    created_at: str             # ISO-8601 UTC timestamp
    store_workspace: str        # absolute path of the original workspace
    store_generation: int       # manifest generation at snapshot time
    store_version: str          # manifest version string at snapshot time
    manifest_checksum: str      # SHA-256 of the copied segments/manifest.json
    file_count: int             # total number of captured files
    total_size_bytes: int       # total bytes across all captured files
    files: list[SnapshotFile] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "snapshot_id": self.snapshot_id,
            "created_at": self.created_at,
            "store_workspace": self.store_workspace,
            "store_generation": self.store_generation,
            "store_version": self.store_version,
            "manifest_checksum": self.manifest_checksum,
            "file_count": self.file_count,
            "total_size_bytes": self.total_size_bytes,
            "files": [asdict(f) for f in self.files],
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "SnapshotManifest":
        files = [
            SnapshotFile(
                path=f["path"],
                sha256=f["sha256"],
                size_bytes=f["size_bytes"],
            )
            for f in data.get("files", [])
        ]
        return cls(
            snapshot_id=data["snapshot_id"],
            created_at=data["created_at"],
            store_workspace=data.get("store_workspace", ""),
            store_generation=data.get("store_generation", 0),
            store_version=data.get("store_version", ""),
            manifest_checksum=data["manifest_checksum"],
            file_count=data.get("file_count", len(files)),
            total_size_bytes=data.get("total_size_bytes", 0),
            files=files,
        )


@dataclass(slots=True)
class VerifyResult:
    """Result of a snapshot verification pass."""
    snapshot_dir: str
    ok: bool
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    file_count: int = 0
    verified_count: int = 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "snapshot_dir": self.snapshot_dir,
            "ok": self.ok,
            "errors": self.errors,
            "warnings": self.warnings,
            "file_count": self.file_count,
            "verified_count": self.verified_count,
        }


@dataclass(slots=True)
class RestoreResult:
    """Result of a snapshot restore operation."""
    snapshot_dir: str
    target_workspace: str
    ok: bool
    backup_path: str | None = None       # path to pre-restore backup of workspace
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "snapshot_dir": self.snapshot_dir,
            "target_workspace": self.target_workspace,
            "ok": self.ok,
            "backup_path": self.backup_path,
            "errors": self.errors,
            "warnings": self.warnings,
        }


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def create_snapshot(
    workspace: str | Path,
    output_dir: str | Path,
    *,
    snapshot_id: str | None = None,
    skip_validation: bool = False,
) -> Path:
    """Create a verified snapshot of the segmented store in *workspace*.

    Captures every durable file that composes the store state:
    - ``segments/manifest.json`` (required)
    - ``segments/manifest.json.bak`` (if present)
    - ``segments/hot.jsonl`` (required)
    - ``segments/hot.rotating.jsonl`` (if present — mid-flush state)
    - All ``segments/seg_*.jsonl`` files referenced in the manifest

    A ``snapshot_manifest.json`` with SHA-256 checksums is written in the
    snapshot root so the snapshot can be verified at any time.

    Parameters
    ----------
    workspace : str | Path
        Path to the Parsica store workspace (the parent of ``segments/``).
    output_dir : str | Path
        Directory where the new snapshot folder will be created.
        The folder is named after the snapshot ID.
    snapshot_id : str | None
        Override the auto-generated snapshot ID.  Auto-generated IDs have the
        form ``snap-<timestamp>-<uuid8>``.
    skip_validation : bool
        If ``True``, skip pre-snapshot store validation.  Not recommended
        for production use; provided for testing invalid-store handling.

    Returns
    -------
    Path
        Absolute path to the created snapshot directory.

    Raises
    ------
    StoreValidationError
        If the store fails pre-snapshot validation (unless *skip_validation*).
    FileExistsError
        If the snapshot directory already exists (collision on snapshot_id).
    OSError
        If any file operation fails.
    """
    workspace = Path(workspace).resolve()
    output_dir = Path(output_dir).resolve()
    segments_dir = workspace / "segments"

    if not skip_validation:
        _validate_store_for_snapshot(workspace)

    # Read manifest once to extract metadata and segment list
    manifest_path = segments_dir / "manifest.json"
    manifest = _read_json(manifest_path)

    # Build snapshot ID and root
    if snapshot_id is None:
        snapshot_id = f"snap-{_utcnow_tag()}-{uuid.uuid4().hex[:8]}"

    root = output_dir / snapshot_id
    if root.exists():
        raise FileExistsError(
            f"Snapshot directory already exists: {root}. "
            "Use a unique snapshot_id or wait one second and retry."
        )
    root.mkdir(parents=True, exist_ok=False)

    files: list[SnapshotFile] = []

    def _copy_and_record(src: Path, rel: Path) -> None:
        """Copy *src* → *root/rel* and append a SnapshotFile record."""
        dst = root / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
        sha = _sha256_file(dst)
        files.append(SnapshotFile(
            path=str(rel),
            sha256=sha,
            size_bytes=dst.stat().st_size,
        ))

    # 1. Primary manifest (always required — validation already confirmed presence)
    _copy_and_record(manifest_path, Path("segments/manifest.json"))

    # 2. Backup manifest (optional — may not exist for brand-new stores)
    bak_manifest = segments_dir / "manifest.json.bak"
    if bak_manifest.exists():
        _copy_and_record(bak_manifest, Path("segments/manifest.json.bak"))

    # 3. Hot buffer (always required)
    hot_name: str = manifest.get("hot", {}).get("filename", "hot.jsonl")
    hot_path = segments_dir / hot_name
    if hot_path.exists():
        _copy_and_record(hot_path, Path("segments") / hot_name)

    # 4. Rotating hot buffer (present only mid-flush or after a crash)
    rotating_path = segments_dir / "hot.rotating.jsonl"
    if rotating_path.exists():
        _copy_and_record(rotating_path, Path("segments/hot.rotating.jsonl"))

    # 5. All segment files referenced in the manifest
    for seg in manifest.get("segments", []):
        fname: str = seg["filename"]
        src = segments_dir / fname
        if src.exists():
            _copy_and_record(src, Path("segments") / fname)
        # Non-existent segments are already caught by validation; skip silently
        # here so we don't abort a snapshot of a skip_validation=True call.

    # Build and write snapshot_manifest.json
    total_bytes = sum(f.size_bytes for f in files)
    manifest_sha = next(
        (f.sha256 for f in files if f.path == "segments/manifest.json"),
        "",
    )

    snap_manifest = SnapshotManifest(
        snapshot_id=snapshot_id,
        created_at=_utcnow_iso(),
        store_workspace=str(workspace),
        store_generation=int(manifest.get("generation", 0)),
        store_version=str(manifest.get("version", "")),
        manifest_checksum=manifest_sha,
        file_count=len(files),
        total_size_bytes=total_bytes,
        files=files,
    )
    _write_json(root / "snapshot_manifest.json", snap_manifest.to_dict())

    return root


def verify_snapshot(snapshot_dir: str | Path) -> VerifyResult:
    """Verify the integrity of a snapshot by re-computing all checksums.

    Reads ``snapshot_manifest.json``, re-computes the SHA-256 of each
    listed file, and reports any mismatches or missing files.

    Parameters
    ----------
    snapshot_dir : str | Path
        Path to the snapshot directory (the folder that contains
        ``snapshot_manifest.json``).

    Returns
    -------
    VerifyResult
        Structured verification result.  Check ``.ok`` for pass/fail.
        ``.errors`` lists individual file failures.
    """
    snapshot_dir = Path(snapshot_dir).resolve()
    result = VerifyResult(snapshot_dir=str(snapshot_dir), ok=False)

    snap_manifest_path = snapshot_dir / "snapshot_manifest.json"
    if not snap_manifest_path.exists():
        result.errors.append(
            "snapshot_manifest.json is missing — this is not a valid snapshot."
        )
        return result

    try:
        raw = _read_json(snap_manifest_path)
        snap_manifest = SnapshotManifest.from_dict(raw)
    except (json.JSONDecodeError, KeyError, OSError) as exc:
        result.errors.append(f"Failed to parse snapshot_manifest.json: {exc}")
        return result

    result.file_count = snap_manifest.file_count

    for item in snap_manifest.files:
        path = snapshot_dir / item.path
        if not path.exists():
            result.errors.append(f"Missing file: {item.path}")
            continue
        actual_sha = _sha256_file(path)
        if actual_sha != item.sha256:
            result.errors.append(
                f"Checksum mismatch: {item.path} "
                f"(expected {item.sha256[:16]}…, got {actual_sha[:16]}…)"
            )
        else:
            result.verified_count += 1

    # Cross-check: manifest_checksum in snapshot_manifest matches the copied file
    copied_manifest = snapshot_dir / "segments" / "manifest.json"
    if copied_manifest.exists() and snap_manifest.manifest_checksum:
        actual_manifest_sha = _sha256_file(copied_manifest)
        if actual_manifest_sha != snap_manifest.manifest_checksum:
            result.errors.append(
                "manifest_checksum in snapshot_manifest.json does not match "
                "segments/manifest.json."
            )

    result.ok = len(result.errors) == 0
    return result


def restore_snapshot(
    snapshot_dir: str | Path,
    target_workspace: str | Path,
    *,
    allow_non_empty: bool = False,
    skip_post_validation: bool = False,
) -> RestoreResult:
    """Restore a snapshot into *target_workspace*.

    Restore is performed via a staging directory to ensure the target is
    never left in a partial state.  The sequence is:

    1. Verify the snapshot (abort if invalid).
    2. If *target_workspace* is non-empty and *allow_non_empty* is True,
       move its current contents to ``.restore_backup_<timestamp>_<uuid>/``
       (same parent directory).
    3. Copy all non-metadata snapshot files into a staging directory.
    4. Verify the staging copy against snapshot checksums.
    5. Atomically move the staging directory into place.
    6. Validate the restored store (unless *skip_post_validation*).

    Parameters
    ----------
    snapshot_dir : str | Path
        Path to the snapshot directory.
    target_workspace : str | Path
        Path to restore into.  Will be created if it does not exist.
    allow_non_empty : bool
        If ``True``, a non-empty *target_workspace* is backed up and
        overwritten.  If ``False`` (default), a non-empty workspace causes
        an error — prevents accidental data loss.
    skip_post_validation : bool
        If ``True``, skip the post-restore store validation.  Useful for
        testing or when restoring into a workspace that uses a different
        layout than expected by ``_validate_store_for_snapshot``.

    Returns
    -------
    RestoreResult
        Structured result.  Check ``.ok``.

    Raises
    ------
    ValueError
        If the snapshot is invalid or the workspace is non-empty without
        *allow_non_empty=True*.
    OSError
        If any file operation fails.
    """
    snapshot_dir = Path(snapshot_dir).resolve()
    target_workspace = Path(target_workspace).resolve()

    result = RestoreResult(
        snapshot_dir=str(snapshot_dir),
        target_workspace=str(target_workspace),
        ok=False,
    )

    # Check for interrupted previous restore
    restore_marker = target_workspace.parent / f".restore_in_progress_{target_workspace.name}"
    if restore_marker.exists():
        result.warnings.append(
            f"A previous restore into {target_workspace} was interrupted "
            f"(marker file: {restore_marker}). The previous backup should be "
            "checked before proceeding. Continuing with this restore."
        )

    # Step 1: Verify snapshot
    verify = verify_snapshot(snapshot_dir)
    if not verify.ok:
        result.errors.append(
            f"Snapshot verification failed — refusing to restore. Errors: {verify.errors}"
        )
        return result

    # Write restore-in-progress marker
    try:
        restore_marker.parent.mkdir(parents=True, exist_ok=True)
        restore_marker.write_text(
            f"restore_started={_utcnow_iso()}\n"
            f"snapshot={snapshot_dir}\n"
            f"target={target_workspace}\n",
            encoding="utf-8",
        )
    except OSError:
        pass  # Best-effort marker; don't fail the restore if we can't write it

    # Step 2: Handle non-empty target workspace
    if target_workspace.exists() and any(target_workspace.iterdir()):
        if not allow_non_empty:
            result.errors.append(
                f"Target workspace is not empty: {target_workspace}. "
                "Pass allow_non_empty=True to back it up and overwrite."
            )
            return result

        # Back up existing workspace contents
        backup_name = f".restore_backup_{_utcnow_tag()}_{uuid.uuid4().hex[:8]}"
        backup_path = target_workspace.parent / backup_name
        shutil.move(str(target_workspace), str(backup_path))
        result.backup_path = str(backup_path)
        result.warnings.append(
            f"Previous workspace backed up to: {backup_path}"
        )

    # Step 3: Copy into staging directory (sibling of target, temp-prefixed)
    staging_parent = target_workspace.parent
    staging_parent.mkdir(parents=True, exist_ok=True)
    staging_dir_obj = tempfile.mkdtemp(
        prefix=".parsica_restore_staging_",
        dir=staging_parent,
    )
    staging_dir = Path(staging_dir_obj)

    try:
        snap_manifest_path = snapshot_dir / "snapshot_manifest.json"
        snap_manifest = SnapshotManifest.from_dict(_read_json(snap_manifest_path))

        # Copy all data files (skip snapshot_manifest.json itself)
        for item in snap_manifest.files:
            src = snapshot_dir / item.path
            dst = staging_dir / item.path
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)

        # Step 4: Verify staging copy
        staging_errors: list[str] = []
        for item in snap_manifest.files:
            staged = staging_dir / item.path
            if not staged.exists():
                staging_errors.append(f"Staging copy missing: {item.path}")
                continue
            actual_sha = _sha256_file(staged)
            if actual_sha != item.sha256:
                staging_errors.append(
                    f"Staging checksum mismatch: {item.path}"
                )

        if staging_errors:
            result.errors.append(
                f"Staging verification failed — restore aborted: {staging_errors}"
            )
            return result

        # Step 5: Atomic move — staging_dir → target_workspace
        # staging_dir is a temp dir inside staging_parent already;
        # rename it to target_workspace.
        target_workspace.parent.mkdir(parents=True, exist_ok=True)
        os.replace(str(staging_dir), str(target_workspace))
        staging_dir = None  # ownership transferred; don't clean up

        # Step 6: Post-restore store validation
        if not skip_post_validation:
            try:
                _validate_store_for_snapshot(target_workspace)
            except StoreValidationError as exc:
                result.errors.append(
                    f"Post-restore validation failed: {exc}. "
                    "The workspace was restored but may be inconsistent."
                )
                result.ok = False
                return result

        # Remove restore-in-progress marker on success
        try:
            if restore_marker.exists():
                restore_marker.unlink()
        except OSError:
            pass  # Best-effort cleanup

        result.ok = True
        return result

    finally:
        # Clean up staging dir if the rename didn't happen (error path)
        if staging_dir is not None and staging_dir.exists():
            shutil.rmtree(str(staging_dir), ignore_errors=True)


def snapshot_info(snapshot_dir: str | Path) -> dict[str, Any]:
    """Return the parsed snapshot manifest as a plain dict.

    Convenience wrapper for tooling that needs to inspect snapshot metadata
    without performing a full verification pass.

    Parameters
    ----------
    snapshot_dir : str | Path
        Path to the snapshot directory.

    Returns
    -------
    dict[str, Any]
        The parsed ``snapshot_manifest.json`` contents, or a dict with an
        ``"error"`` key if the file is missing or unreadable.
    """
    path = Path(snapshot_dir).resolve() / "snapshot_manifest.json"
    if not path.exists():
        return {"error": f"snapshot_manifest.json not found in {snapshot_dir}"}
    try:
        return _read_json(path)
    except (json.JSONDecodeError, OSError) as exc:
        return {"error": str(exc)}


__all__ = [
    "SnapshotFile",
    "SnapshotManifest",
    "VerifyResult",
    "RestoreResult",
    "StoreValidationError",
    "create_snapshot",
    "verify_snapshot",
    "restore_snapshot",
    "snapshot_info",
]
