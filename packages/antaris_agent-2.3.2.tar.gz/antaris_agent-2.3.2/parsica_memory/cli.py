"""
parsica-memory — CLI
====================

Entry point for `python -m parsica_memory` commands.

Commands:
  init            Scaffold a new workspace and generate agent config
  status          Show live stats for an existing workspace
  rebuild-graph   Rebuild the memory graph from all loaded entries
  serve           Start the MCP server (stdio transport)

Usage:
  python -m parsica_memory init [--workspace PATH] [--agent-name NAME]
  python -m parsica_memory status [--workspace PATH]
  python -m parsica_memory rebuild-graph [--workspace PATH]
  python -m parsica_memory serve [--workspace PATH] [--agent-name NAME]
"""

import argparse
import json
import logging
import os
import sys
import uuid
from dataclasses import asdict, is_dataclass
from pathlib import Path

from parsica_memory import __version__

# Config file name — new name with backward-compat fallback
_CONFIG_NAME = "parsica_config.json"
_LEGACY_CONFIG_NAME = "antaris_config.json"


def _resolve_config_path(workspace: str) -> str:
    """Resolve config path, preferring new name but falling back to legacy."""
    new = os.path.join(workspace, _CONFIG_NAME)
    legacy = os.path.join(workspace, _LEGACY_CONFIG_NAME)
    if os.path.exists(new):
        return new
    if os.path.exists(legacy):
        return legacy
    return new  # default to new name for fresh workspaces


# ── Helpers ──────────────────────────────────────────────────────────────────

def _print_header(title: str) -> None:
    print(f"\n⚡ parsica-memory — {title}")
    print("─" * 50)


def _print_stats(s: dict) -> None:
    """Pretty-print stats() output."""
    _print_header(f"v{s.get('version', '?')} status")
    print(f"  Workspace   : {s.get('workspace', '?')}")
    print(f"  Agent       : {s.get('agent_name') or '(unset)'}")
    print()
    print(f"  Entries     : {s.get('total_entries', 0):,} hot  "
          f"| {s.get('warm_entries', 0):,} warm "
          f"| {s.get('cold_entries', 0):,} cold")
    print(f"  WAL pending : {s.get('wal_size', 0):,}")
    print(f"  Enriched    : {s.get('enrichment_count', 0):,}  "
          f"(${s.get('enrichment_cost_usd', 0):.4f} lifetime)")
    print()
    if s.get('graph_enabled'):
        print(f"  Graph       : {s.get('graph_nodes', 0):,} nodes  "
              f"| {s.get('graph_edges', 0):,} edges")
    else:
        print("  Graph       : disabled")
    print(f"  Co-occ pairs: {s.get('cooccurrence_pairs', 0):,}")
    print(f"  Cache size  : {s.get('cache_size', 0):,}")
    print()


def _make_agent_name(provided: str = None) -> str:
    if provided:
        return provided
    # Derive from machine hostname
    import socket
    hostname = socket.gethostname().split('.')[0].lower()
    return f"agent-{hostname}"


# ── Commands ─────────────────────────────────────────────────────────────────

def cmd_init(args) -> int:
    """Scaffold a new parsica-memory workspace.

    If --headless is not set, runs the interactive setup wizard.
    Falls back to headless automatically when stdin/stdout are not TTYs.
    """
    requested_headless = getattr(args, 'headless', False)
    interactive_tty = sys.stdin.isatty() and sys.stdout.isatty()
    headless = requested_headless or not interactive_tty

    if not requested_headless and not interactive_tty:
        print("  Non-interactive shell detected; falling back to --headless init.")

    if not headless:
        # Interactive wizard
        try:
            from .wizard import run_wizard
            result = run_wizard(
                workspace=args.workspace,
                agent_name=args.agent_name,
            )
            return 0 if result.get("mode") else 1
        except (ImportError, KeyboardInterrupt):
            print("\n  Wizard cancelled. Use --headless for non-interactive setup.")
            return 1

    # Headless mode (original behavior)
    workspace = os.path.abspath(args.workspace)
    agent_name = _make_agent_name(args.agent_name)

    _print_header("init")
    print(f"  Workspace   : {workspace}")
    print(f"  Agent name  : {agent_name}")
    print()

    # Create workspace directory
    os.makedirs(workspace, exist_ok=True)

    # Write agent config (new name for fresh workspaces, but respect existing legacy)
    existing = _resolve_config_path(workspace)
    config_path = existing if os.path.exists(existing) else os.path.join(workspace, _CONFIG_NAME)
    if os.path.exists(config_path) and not getattr(args, 'force', False):
        print(f"  Config already exists at {config_path}")
        print("  Use --force to overwrite.")
    else:
        config = {
            "agent_name": agent_name,
            "agent_id": str(uuid.uuid4()),
            "workspace": workspace,
            "version": __version__,
            "settings": {
                "half_life": 7.0,
                "storage_mode": "tiered_storage",
                "graph_intelligence": True,
                "enricher": None,
            },
        }
        with open(config_path, 'w') as f:
            json.dump(config, f, indent=2)
        print(f"  Config written  : {config_path}")
        print("  Storage mode    : tiered_storage (time-shard storage with hot-tier startup)")

    # Touch memory directories
    for d in ['.consolidated', '.shared_pools']:
        os.makedirs(os.path.join(workspace, d), exist_ok=True)

    # Quick smoke test
    try:
        from parsica_memory.core_v4 import MemorySystemV4
        ms = MemorySystemV4(workspace=workspace, agent_name=agent_name)
        ms.save()
        total = len(ms.memories)
        print(f"  MemorySystem OK  : {total:,} entries loaded")
    except Exception as e:
        print(f"  MemorySystem warning: {e}")

    print()
    print("  Ready! Run `python -m parsica_memory status` to see live stats.")
    print()
    return 0


def cmd_status(args) -> int:
    """Show live stats for an existing workspace."""
    workspace = os.path.abspath(args.workspace)

    # Try to get agent_name from config file
    agent_name = None
    config_path = _resolve_config_path(workspace)
    if os.path.exists(config_path):
        try:
            with open(config_path) as f:
                cfg = json.load(f)
            agent_name = cfg.get("agent_name")
        except Exception:
            pass

    try:
        from parsica_memory.core_v4 import MemorySystemV4
        ms = MemorySystemV4(workspace=workspace, agent_name=agent_name)
        ms.load()
        s = ms.stats()
        _print_stats(s)

        # Health check
        h = ms.get_health()
        status_icon = "✅" if h["status"] == "ok" else "⚠️"
        print(f"  {status_icon} Health: {h['status']}")
        for check, ok in h["checks"].items():
            icon = "✅" if ok else "❌"
            print(f"     {icon} {check}")
        print()
    except Exception as e:
        print(f"\n  ❌ Error loading workspace: {e}", file=sys.stderr)
        return 1

    return 0


def cmd_rebuild_graph(args) -> int:
    """Rebuild the memory graph from all loaded entries."""
    workspace = os.path.abspath(args.workspace)

    agent_name = None
    config_path = _resolve_config_path(workspace)
    if os.path.exists(config_path):
        try:
            with open(config_path) as f:
                cfg = json.load(f)
            agent_name = cfg.get("agent_name")
        except Exception:
            pass

    _print_header("rebuild-graph")
    print(f"  Workspace: {workspace}")
    print()

    try:
        from parsica_memory.core_v4 import MemorySystemV4
        ms = MemorySystemV4(workspace=workspace, agent_name=agent_name,
                            graph_intelligence=True)
        ms.load()
        total = len(ms.memories)
        print(f"  Loaded {total:,} entries — rebuilding graph...")
        count = ms.rebuild_graph()
        print(f"  ✅ Graph rebuilt: {count:,} entries indexed")

        g = ms.get_graph_stats()
        print(f"  Nodes: {g.get('node_count', 0):,}  |  Edges: {g.get('edge_count', 0):,}")
        print()
    except Exception as e:
        print(f"\n  ❌ Error: {e}", file=sys.stderr)
        return 1

    return 0


def cmd_serve(args) -> int:
    """Start the MCP server (stdio transport)."""
    workspace = os.path.abspath(args.workspace)
    agent_name = _make_agent_name(getattr(args, 'agent_name', None))

    try:
        from parsica_memory.mcp_server import ParsicaMCPServer
        server = ParsicaMCPServer(workspace=workspace, agent_name=agent_name)
        server.run_stdio()
    except ImportError:
        print("MCP server module not found.", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        pass

    return 0


def _json_safe(value):
    """Recursively convert Path/dataclass values into JSON-safe primitives."""
    if is_dataclass(value):
        return _json_safe(asdict(value))
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, dict):
        return {k: _json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(v) for v in value]
    return value


def _emit_cli_output(payload, *, as_json: bool = False) -> None:
    """Emit machine-readable JSON to stdout or human text to stderr."""
    if as_json:
        print(json.dumps(_json_safe(payload), indent=2, sort_keys=True))
        return

    if isinstance(payload, str):
        print(payload, file=sys.stderr)
        return

    print(json.dumps(_json_safe(payload), indent=2, sort_keys=True), file=sys.stderr)


def _format_issues(issues) -> list[str]:
    lines = []
    for issue in issues:
        path = getattr(issue, 'path', None)
        prefix = f"[{issue.severity.upper()}] {issue.code}: {issue.message}"
        if path:
            prefix += f" ({path})"
        details = getattr(issue, 'details', None) or {}
        if details:
            prefix += f" | details={json.dumps(_json_safe(details), sort_keys=True)}"
        lines.append(prefix)
    return lines


def _format_validation_report(report) -> str:
    issues = getattr(report, 'issues', []) or []
    error_count = report.error_count() if hasattr(report, 'error_count') else sum(1 for issue in issues if getattr(issue, 'severity', None) == 'error')
    warning_count = report.warning_count() if hasattr(report, 'warning_count') else sum(1 for issue in issues if getattr(issue, 'severity', None) == 'warning')

    lines = [
        "Validation report",
        f"  Workspace              : {report.workspace}",
        f"  Status                 : {'clean' if report.ok else 'issues found'}",
        f"  Errors                 : {error_count}",
        f"  Warnings               : {warning_count}",
    ]

    if getattr(report, 'generation', None) is not None:
        lines.append(f"  Generation             : {getattr(report, 'generation', 0)}")
    if getattr(report, 'total_physical_entries', None) is not None:
        lines.append(f"  Physical entries       : {getattr(report, 'total_physical_entries', 0)}")
    if getattr(report, 'total_logical_entries', None) is not None:
        lines.append(f"  Logical entries        : {getattr(report, 'total_logical_entries', 0)}")
    if getattr(report, 'tombstone_count', None) is not None:
        lines.append(f"  Tombstones             : {getattr(report, 'tombstone_count', 0)}")
    if getattr(report, 'tombstone_orphan_count', None) is not None:
        lines.append(f"  Orphan tombstones      : {getattr(report, 'tombstone_orphan_count', 0)}")

    hot = getattr(report, 'hot', None)
    if hot is not None:
        lines.extend([
            "  Hot buffer",
            f"    Path                 : {hot.path}",
            f"    Exists               : {hot.exists}",
            f"    Size bytes           : {hot.size_bytes}",
            f"    Total lines          : {hot.total_lines}",
            f"    Valid lines          : {hot.valid_lines}",
            f"    Malformed lines      : {hot.malformed_lines}",
            f"    Put/Delete           : {hot.put_count}/{hot.delete_count}",
        ])

    if getattr(report, 'segments', None):
        lines.append(f"  Segments               : {len(report.segments)}")
        for seg in report.segments:
            lines.append(
                f"    - {seg.path} | ok={seg.ok} | exists={seg.exists} | entries={seg.entry_count}"
            )

    orphan_paths = getattr(report, 'orphan_paths', []) or []
    if orphan_paths:
        lines.append("  Orphans")
        for orphan in orphan_paths:
            lines.append(f"    - {orphan}")

    issues = getattr(report, 'issues', []) or []
    if issues:
        lines.append("  Issues")
        lines.extend(f"    - {line}" for line in _format_issues(issues))

    return "\n".join(lines)


def _format_repair_plan(plan) -> str:
    lines = [
        "Doctor report",
        f"  Workspace              : {plan.workspace}",
        f"  Dry run                : {plan.dry_run}",
        f"  Status                 : {'clean' if plan.ok else 'issues found'}",
        f"  Planned actions        : {len(plan.actions)}",
        "",
        _format_validation_report(plan.validation),
    ]

    if plan.actions:
        lines.append("")
        lines.append("Repair plan")
        for action in plan.actions:
            lines.append(f"  - {action.action_type}: {action.description}")
            if action.details:
                lines.append(f"    details={json.dumps(_json_safe(action.details), sort_keys=True)}")

    return "\n".join(lines)


def _format_repair_result(result, title: str) -> str:
    lines = [
        title,
        f"  Workspace              : {result.workspace}",
        f"  Dry run                : {result.dry_run}",
        f"  Changed                : {result.changed}",
        f"  Applied actions        : {len(result.applied)}",
        f"  Backups created        : {len(result.backups_created)}",
    ]

    if result.applied:
        lines.append("  Actions")
        for action in result.applied:
            lines.append(f"    - {action.action_type}: {action.description}")
            if action.details:
                lines.append(f"      details={json.dumps(_json_safe(action.details), sort_keys=True)}")

    if result.backups_created:
        lines.append("  Backups")
        for backup in result.backups_created:
            lines.append(f"    - {backup}")

    if result.details:
        lines.append("  Details")
        for key, val in _json_safe(result.details).items():
            lines.append(f"    {key}: {val}")

    if result.validation_before is not None:
        lines.append("")
        lines.append("Before")
        lines.append(_format_validation_report(result.validation_before))

    if result.validation_after is not None:
        lines.append("")
        lines.append("After")
        lines.append(_format_validation_report(result.validation_after))

    return "\n".join(lines)


def _snapshot_summary(snapshot_path: Path) -> dict:
    manifest_path = snapshot_path / 'snapshot_manifest.json'
    summary = {'snapshot_path': str(snapshot_path)}
    if manifest_path.exists():
        try:
            with open(manifest_path, 'r', encoding='utf-8') as handle:
                manifest = json.load(handle)
            summary.update({
                'snapshot_id': manifest.get('snapshot_id'),
                'created_at': manifest.get('created_at'),
                'store_generation': manifest.get('store_generation'),
                'store_version': manifest.get('store_version'),
                'file_count': manifest.get('file_count'),
                'total_size_bytes': manifest.get('total_size_bytes'),
            })
        except Exception:
            pass
    return summary


def cmd_validate(args) -> int:
    """Validate segmented storage integrity for a workspace."""
    workspace = os.path.abspath(args.workspace)
    try:
        from parsica_memory.storage.integrity import validate_store
        report = validate_store(workspace)
    except NotImplementedError as e:
        _emit_cli_output({'error': str(e), 'workspace': workspace}, as_json=getattr(args, 'json', False))
        return 1
    except (FileNotFoundError, ValueError, OSError) as e:
        _emit_cli_output({'error': str(e), 'workspace': workspace}, as_json=getattr(args, 'json', False))
        return 1

    if getattr(args, 'json', False):
        _emit_cli_output(report.to_dict(), as_json=True)
    else:
        _emit_cli_output(_format_validation_report(report), as_json=False)
    return 0 if report.ok else 1


def cmd_doctor(args) -> int:
    """Inspect the store and print a repair plan."""
    workspace = os.path.abspath(args.workspace)
    dry_run = getattr(args, 'dry_run', False)
    try:
        from parsica_memory.storage.repair import doctor
        plan = doctor(workspace, dry_run=dry_run)
    except NotImplementedError as e:
        _emit_cli_output({'error': str(e), 'workspace': workspace, 'dry_run': dry_run}, as_json=getattr(args, 'json', False))
        return 1
    except (FileNotFoundError, ValueError, OSError) as e:
        _emit_cli_output({'error': str(e), 'workspace': workspace, 'dry_run': dry_run}, as_json=getattr(args, 'json', False))
        return 1

    # Exit 1 only if there are actual errors in the validation report.
    # Info and warning level issues are informational — they do not
    # indicate a broken store that requires operator action.
    # Exit 0 = store is healthy (may have warnings/info); exit 1 = errors found.
    validation = getattr(plan, 'validation', None)
    has_errors = bool(validation and validation.error_count() > 0)
    plan.ok = not has_errors

    if getattr(args, 'json', False):
        _emit_cli_output(plan.to_dict(), as_json=True)
    else:
        _emit_cli_output(_format_repair_plan(plan), as_json=False)

    return 0 if plan.ok else 1


def cmd_repair_manifest(args) -> int:
    """Rebuild the manifest from on-disk segments."""
    workspace = os.path.abspath(args.workspace)
    dry_run = getattr(args, 'dry_run', False)
    try:
        from parsica_memory.storage.repair import repair_manifest
        result = repair_manifest(workspace, dry_run=dry_run)
    except NotImplementedError as e:
        _emit_cli_output({'error': str(e), 'workspace': workspace, 'dry_run': dry_run}, as_json=getattr(args, 'json', False))
        return 1
    except (FileNotFoundError, ValueError, OSError) as e:
        _emit_cli_output({'error': str(e), 'workspace': workspace, 'dry_run': dry_run}, as_json=getattr(args, 'json', False))
        return 1

    if getattr(args, 'json', False):
        _emit_cli_output(result.to_dict(), as_json=True)
    else:
        _emit_cli_output(_format_repair_result(result, 'Repair manifest'), as_json=False)

    validation_after = getattr(result, 'validation_after', None)
    if validation_after is not None:
        return 0 if validation_after.ok else 1
    return 0


def cmd_snapshot_create(args) -> int:
    """Create a store snapshot."""
    from parsica_memory.storage.snapshot import StoreValidationError, create_snapshot

    workspace = os.path.abspath(args.workspace)
    output = os.path.abspath(args.output)
    try:
        snapshot_path = create_snapshot(workspace, output)
        summary = _snapshot_summary(snapshot_path)
    except StoreValidationError as e:
        _emit_cli_output({'error': str(e), 'workspace': workspace, 'output': output}, as_json=getattr(args, 'json', False))
        return 1
    except (NotImplementedError, FileNotFoundError, OSError) as e:
        _emit_cli_output({'error': str(e), 'workspace': workspace, 'output': output}, as_json=getattr(args, 'json', False))
        return 1

    if getattr(args, 'json', False):
        _emit_cli_output(summary, as_json=True)
    else:
        lines = [
            'Snapshot created',
            f"  Snapshot path          : {summary.get('snapshot_path')}",
            f"  Snapshot ID            : {summary.get('snapshot_id')}",
            f"  Created at             : {summary.get('created_at')}",
            f"  Store generation       : {summary.get('store_generation')}",
            f"  Store version          : {summary.get('store_version')}",
            f"  Files                  : {summary.get('file_count')}",
            f"  Total size bytes       : {summary.get('total_size_bytes')}",
        ]
        _emit_cli_output('\n'.join(lines), as_json=False)
    return 0


def cmd_snapshot_verify(args) -> int:
    """Verify a snapshot directory."""
    snapshot_path = os.path.abspath(args.path)
    try:
        from parsica_memory.storage.snapshot import verify_snapshot
        result = verify_snapshot(snapshot_path)
    except NotImplementedError as e:
        _emit_cli_output({'error': str(e), 'path': snapshot_path}, as_json=getattr(args, 'json', False))
        return 1
    except (FileNotFoundError, ValueError, OSError) as e:
        _emit_cli_output({'error': str(e), 'path': snapshot_path}, as_json=getattr(args, 'json', False))
        return 1

    payload = result.to_dict()
    if getattr(args, 'json', False):
        _emit_cli_output(payload, as_json=True)
    else:
        lines = [
            'Snapshot verification',
            f"  Snapshot path          : {payload.get('snapshot_dir')}",
            f"  Status                 : {'valid' if payload.get('ok') else 'invalid'}",
            f"  Files                  : {payload.get('file_count')}",
            f"  Verified               : {payload.get('verified_count')}",
        ]
        errors = payload.get('errors') or []
        warnings = payload.get('warnings') or []
        if warnings:
            lines.append('  Warnings')
            lines.extend(f"    - {w}" for w in warnings)
        if errors:
            lines.append('  Errors')
            lines.extend(f"    - {e}" for e in errors)
        _emit_cli_output('\n'.join(lines), as_json=False)
    return 0 if result.ok else 1


def cmd_snapshot_restore(args) -> int:
    """Restore a snapshot into a workspace."""
    snapshot_path = os.path.abspath(args.path)
    workspace = os.path.abspath(args.workspace)
    allow_non_empty = getattr(args, 'allow_non_empty', False)
    try:
        from parsica_memory.storage.snapshot import restore_snapshot
        result = restore_snapshot(snapshot_path, workspace, allow_non_empty=allow_non_empty)
    except NotImplementedError as e:
        _emit_cli_output({'error': str(e), 'path': snapshot_path, 'workspace': workspace}, as_json=getattr(args, 'json', False))
        return 1
    except (FileNotFoundError, ValueError, OSError) as e:
        _emit_cli_output({'error': str(e), 'path': snapshot_path, 'workspace': workspace}, as_json=getattr(args, 'json', False))
        return 1

    payload = result.to_dict()
    if getattr(args, 'json', False):
        _emit_cli_output(payload, as_json=True)
    else:
        lines = [
            'Snapshot restore',
            f"  Snapshot path          : {payload.get('snapshot_dir')}",
            f"  Target workspace       : {payload.get('target_workspace')}",
            f"  Status                 : {'success' if payload.get('ok') else 'failure'}",
            f"  Backup path            : {payload.get('backup_path') or '(none)'}",
        ]
        warnings = payload.get('warnings') or []
        errors = payload.get('errors') or []
        if warnings:
            lines.append('  Warnings')
            lines.extend(f"    - {w}" for w in warnings)
        if errors:
            lines.append('  Errors')
            lines.extend(f"    - {e}" for e in errors)
        _emit_cli_output('\n'.join(lines), as_json=False)
    return 0 if result.ok else 1


def cmd_sync(args) -> int:
    """Sync memories from peer stores."""
    from parsica_memory.sync import PeerSync

    workspace = args.workspace or "."
    hours = args.hours or 6
    peers = args.peers or None

    try:
        syncer = PeerSync(workspace)
    except NotImplementedError as e:
        print(f"  Error: {e}", file=__import__('sys').stderr)
        print("  Hint: PeerSync requires storage_backend='enterprise'. "
              "Segmented storage sync support is planned for v3.3.",
              file=__import__('sys').stderr)
        return 1

    result = syncer.sync(hours=hours, peers=peers)

    _print_header("Sync Results")
    print(f"  Memories synced:  {result.synced}")
    print(f"  Duplicates skipped: {result.skipped}")
    if result.errors:
        print(f"  Errors: {len(result.errors)}")
        for e in result.errors:
            print(f"    - {e}")

    # Daily log sync is already handled inside syncer.sync() when enabled.
    # Report the result from the sync operation directly.
    print(f"  Daily log lines merged: {result.log_lines_merged}")

    return 0


# ── Export / Import ──────────────────────────────────────────────────────────

def cmd_export(args) -> int:
    """Export memories to portable JSON format."""
    workspace = os.path.abspath(args.workspace)
    output = os.path.abspath(args.output)

    _print_header("export")
    print(f"  Workspace : {workspace}")
    print(f"  Output    : {output}")
    print()

    try:
        from parsica_memory.core_v4 import MemorySystemV4
        agent_name = _load_agent_name(workspace)
        ms = MemorySystemV4(workspace=workspace, agent_name=agent_name)
        ms.load()
        count = ms.export(output, include_metadata=True)
        print(f"  Exported {count:,} memories to {output}")
        print()
    except Exception as e:
        print(f"\n  Error: {e}", file=sys.stderr)
        return 1
    return 0


def cmd_cleanup(args) -> int:
    """Purge transport metadata contamination from memory store."""
    from parsica_memory.cleanup import clean_wal, clean_shards, update_index
    from pathlib import Path

    store_path = Path(os.path.abspath(args.workspace))
    dry_run = getattr(args, 'dry_run', False)

    if dry_run:
        print("=== DRY RUN (no files modified) ===")

    print(f"Store: {store_path}")
    wal_removed = clean_wal(store_path, dry_run)
    shard_removed = clean_shards(store_path, dry_run)
    if not dry_run:
        update_index(store_path, dry_run)
    total = wal_removed + shard_removed
    print(f"\nTotal removed: {total}")
    if total == 0:
        print("Store is clean — no transport metadata contamination found.")
    return 0


def cmd_import(args) -> int:
    """Import memories from another system or file."""
    workspace = os.path.abspath(args.workspace)
    input_path = os.path.abspath(args.input)
    source = getattr(args, 'source', 'auto')
    merge = not getattr(args, 'replace', False)
    dry_run = getattr(args, 'dry_run', False)

    _print_header(f"import (from: {source})")
    print(f"  Workspace : {workspace}")
    print(f"  Input     : {input_path}")
    print(f"  Mode      : {'merge' if merge else 'replace'}")
    if dry_run:
        print(f"  DRY RUN   : no changes will be written")
    print()

    if not os.path.exists(input_path):
        print(f"  Error: {input_path} does not exist", file=sys.stderr)
        return 1

    try:
        from parsica_memory.importers import detect_and_import
        result = detect_and_import(
            input_path=input_path,
            workspace=workspace,
            source=source,
            merge=merge,
            dry_run=dry_run,
        )
        if dry_run:
            print(f"  Would import {result['count']:,} memories")
            print(f"  Detected format: {result['format']}")
        else:
            print(f"  Imported {result['count']:,} memories")
            print(f"  Format: {result['format']}")
            if result.get('skipped'):
                print(f"  Skipped: {result['skipped']:,} (duplicates)")
        print()
    except Exception as e:
        print(f"\n  Error: {e}", file=sys.stderr)
        return 1
    return 0


def cmd_ingest_pdf(args) -> int:
    """Ingest a PDF into the memory workspace."""
    workspace = os.path.abspath(args.workspace)
    pdf_path = os.path.abspath(args.pdf)
    category = getattr(args, 'category', 'document')
    use_ocr = not getattr(args, 'no_ocr', False)
    prefer_layout = getattr(args, 'layout', False)
    info_only = getattr(args, 'info', False)

    _print_header(f"ingest-pdf")
    print(f"  PDF         : {pdf_path}")
    print(f"  Workspace   : {workspace}")
    print(f"  Category    : {category}")
    print(f"  OCR         : {'enabled' if use_ocr else 'disabled'}")
    print(f"  Layout mode : {'pdfminer' if prefer_layout else 'pypdf (default)'}")
    print()

    if not os.path.exists(pdf_path):
        print(f"  Error: {pdf_path} does not exist", file=sys.stderr)
        return 1

    try:
        from parsica_memory.ingest_pdf import PDFIngester

        ingester = PDFIngester(
            use_ocr=use_ocr,
            prefer_layout=prefer_layout,
        )

        if info_only:
            # Just extract and show info, don't ingest
            result = ingester.ingest(pdf_path)
            print(result.summary())
            print()
            if result.warnings:
                print("  Warnings:")
                for w in result.warnings:
                    print(f"    ⚠ {w}")
            if result.errors:
                print("  Errors:")
                for e in result.errors:
                    print(f"    ✗ {e}")
            print()
            print(f"  Chunks ready for ingestion: {len(result.chunks)}")
            print()
            return 0

        # Full ingestion
        agent_name = _load_agent_name(workspace)
        result_dict = ingester.ingest_to_memory(
            pdf_path, workspace,
            category=category,
            agent_name=agent_name,
        )

        print(f"  Ingested    : {result_dict['count']:,} memories")
        print(f"  Chunks      : {result_dict['chunks']:,}")
        if result_dict.get('warnings'):
            print(f"  Warnings    : {len(result_dict['warnings'])}")
            for w in result_dict['warnings'][:5]:
                print(f"    ⚠ {w}")
        if result_dict.get('errors'):
            print(f"  Errors      : {len(result_dict['errors'])}")
            for e in result_dict['errors']:
                print(f"    ✗ {e}")
        print()

    except Exception as e:
        print(f"\n  Error: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        return 1
    return 0


def cmd_explain(args) -> int:
    """Run a search query and show detailed score breakdown for each result."""
    workspace = os.path.abspath(args.workspace)
    query = args.query
    limit = getattr(args, 'limit', 10)

    _print_header("explain")
    print(f"  Workspace : {workspace}")
    print(f"  Query     : {query}")
    print(f"  Limit     : {limit}")
    print()

    try:
        from parsica_memory.core_v4 import MemorySystemV4
        agent_name = _load_agent_name(workspace)
        ms = MemorySystemV4(workspace=workspace, agent_name=agent_name)
        ms.load()

        # Use MemorySystemV4's search with explain=True (same engine as production plugin)
        results = ms.search(query, limit=limit, explain=True)

        if not results:
            print("  No results found.")
            return 0

        for i, r in enumerate(results, 1):
            print(f"  ── Result #{i} ──────────────────────────────")
            print(f"  Score     : {r.score:.3f} (relevance: {r.relevance:.2f})")
            print(f"  Matched   : {', '.join(r.matched_terms)}")
            print(f"  Explain   : {r.explanation}")
            
            # Provenance
            entry = r.entry
            source = getattr(entry, 'source', 'unknown')
            ts = getattr(entry, 'timestamp', None) or getattr(entry, 'created_at', 'unknown')
            session = getattr(entry, 'session_id', 'unknown')
            channel = getattr(entry, 'channel_id', None) or ''
            print(f"  Source    : {source}")
            if channel:
                print(f"  Channel   : {channel}")
            print(f"  Timestamp : {ts}")
            print(f"  Session   : {session}")
            print(f"  Content   : {entry.content[:200]}{'...' if len(entry.content) > 200 else ''}")
            
            # Score breakdown if available
            breakdown = getattr(r, '_breakdown', None)
            if breakdown:
                print(f"  Breakdown :")
                for key, val in breakdown.items():
                    if isinstance(val, float):
                        print(f"    {key:20s} = {val:.4f}")
                    else:
                        print(f"    {key:20s} = {val}")
            print()

        print(f"  {len(results)} result(s) returned.")
        print()
    except Exception as e:
        print(f"\n  Error: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        return 1
    return 0


def cmd_enrich(args) -> int:
    """Enrich unenriched memories in a workspace, optionally with multiple API keys.

    v3.1: Multi-key sequential enrichment with round-robin key rotation.
    Keys are cycled through in order so that rate limits on one key don't
    block progress — the next memory uses the next key in the rotation.
    """
    workspace = os.path.abspath(args.workspace)
    keys = getattr(args, 'keys', None)
    coverage_only = getattr(args, 'coverage', False)

    _print_header("enrich")
    print(f"  Workspace : {workspace}")

    try:
        from parsica_memory.core_v4 import MemorySystemV4
        from parsica_memory.enrichers import smart_enricher, auto_enricher
        agent_name = _load_agent_name(workspace)
        ms = MemorySystemV4(workspace=workspace, agent_name=agent_name)
        ms.load()

        total = len(ms.memories)
        enriched = sum(1 for m in ms.memories if getattr(m, 'enriched_summary', ''))
        pct = (enriched / total * 100) if total > 0 else 0

        print(f"  Total     : {total:,} memories")
        print(f"  Enriched  : {enriched:,} ({pct:.1f}%)")
        print(f"  Remaining : {total - enriched:,}")
        print()

        if coverage_only:
            return 0

        unenriched = [m for m in ms.memories if not getattr(m, 'enriched_summary', '')]
        if not unenriched:
            print("  All memories are already enriched. Nothing to do.")
            return 0

        # Build enricher pool: multi-key round-robin or gateway default
        enricher_pool = []
        if keys:
            key_list = [k.strip() for k in keys.split(',') if k.strip()]
            for i, key in enumerate(key_list):
                enricher_fn = smart_enricher(key)
                if enricher_fn is not None:
                    enricher_pool.append(enricher_fn)
                else:
                    print(f"  Warning   : key #{i+1} could not be resolved to a provider, skipping")
            print(f"  API keys  : {len(enricher_pool)} of {len(key_list)} keys active (round-robin)")
        else:
            # Fall back to gateway default (auto_enricher reads auth-profiles.json)
            default_enricher = auto_enricher()
            if default_enricher is not None:
                enricher_pool.append(default_enricher)
            print(f"  API keys  : using gateway default")

        if not enricher_pool:
            print("\n  Error: No valid enricher available. Provide --keys or configure")
            print("         auth-profiles.json / environment variables.")
            return 1

        # Sequential enrichment with round-robin key rotation
        print(f"\n  Enriching {len(unenriched):,} memories with {len(enricher_pool)} key(s)...")
        enriched_count = 0
        error_count = 0
        key_idx = 0

        for i, entry in enumerate(unenriched):
            enricher_fn = enricher_pool[key_idx % len(enricher_pool)]
            try:
                enrichment = enricher_fn(entry.content)
                if enrichment and isinstance(enrichment, dict):
                    if enrichment.get("tags"):
                        entry.tags = sorted(
                            set(entry.tags) | {t.lower() for t in enrichment["tags"]}
                        )
                    if enrichment.get("summary"):
                        entry.enriched_summary = str(enrichment["summary"])
                    if enrichment.get("keywords"):
                        entry.search_keywords = [
                            str(k).lower() for k in enrichment["keywords"]
                        ]
                    if enrichment.get("search_queries"):
                        entry.search_queries = [
                            str(q) for q in enrichment["search_queries"]
                        ]
                    enriched_count += 1
                else:
                    error_count += 1
            except Exception as e:
                error_count += 1
                logging.getLogger("parsica_memory.cli").debug(f"Enrichment failed for {entry.hash[:8]}: {e}")

            key_idx += 1  # rotate to next key

            # Progress every 50 entries
            if (i + 1) % 50 == 0:
                print(f"  Progress  : {i+1:,}/{len(unenriched):,} ({enriched_count:,} enriched, {error_count:,} errors)")

        # Save and rebuild index
        if enriched_count > 0:
            ms.search_engine.mark_dirty()
            try:
                ms.save()
                print(f"  Saved     : workspace updated successfully")
            except Exception as save_err:
                print(f"  ⚠️ SAVE FAILED: {save_err} — enrichment results may not be persisted!", file=sys.stderr)
                return 1

        print(f"\n  Done      : {enriched_count:,} enriched, {error_count:,} errors")
        print()

    except Exception as e:
        print(f"\n  Error: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        return 1
    return 0


def _load_agent_name(workspace: str):
    """Try to read agent_name from workspace config."""
    config_path = _resolve_config_path(workspace)
    if os.path.exists(config_path):
        try:
            with open(config_path) as f:
                return json.load(f).get("agent_name")
        except Exception:
            pass
    return None


# ── Main ─────────────────────────────────────────────────────────────────────

def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        prog="python -m parsica_memory",
        description="parsica-memory CLI",
    )
    subparsers = parser.add_subparsers(dest="command")

    # init
    p_init = subparsers.add_parser("init", help="Interactive setup wizard")
    p_init.add_argument("--workspace", default=".", help="Workspace path (default: .)")
    p_init.add_argument("--agent-name", default=None, help="Agent name")
    p_init.add_argument("--force", action="store_true", help="Overwrite existing config")
    p_init.add_argument("--headless", action="store_true", help="Skip wizard, use defaults")

    # status
    p_status = subparsers.add_parser("status", help="Show live stats")
    p_status.add_argument("--workspace", default=".", help="Workspace path")

    # rebuild-graph
    p_rebuild = subparsers.add_parser("rebuild-graph", help="Rebuild memory graph")
    p_rebuild.add_argument("--workspace", default=".", help="Workspace path")

    # serve (MCP)
    p_serve = subparsers.add_parser("serve", help="Start MCP server (stdio)")
    p_serve.add_argument("--workspace", default=".", help="Workspace path")
    p_serve.add_argument("--agent-name", default=None, help="Agent name")

    # sync
    p_sync = subparsers.add_parser("sync", help="Sync memories from peer stores")
    p_sync.add_argument("--workspace", "-w", default=None)
    p_sync.add_argument("--hours", "-H", type=int, default=6)
    p_sync.add_argument("--peers", nargs="*", default=None)

    # validate
    p_validate = subparsers.add_parser("validate", help="Validate segmented storage integrity")
    p_validate.add_argument("--workspace", default=".", help="Workspace path")
    p_validate.add_argument("--json", action="store_true", help="Emit machine-readable JSON to stdout")

    # doctor
    p_doctor = subparsers.add_parser("doctor", help="Show storage repair plan")
    p_doctor.add_argument("--workspace", default=".", help="Workspace path")
    p_doctor.add_argument("--dry-run", action="store_true", help="Do not modify files; show planned repairs only")
    p_doctor.add_argument("--json", action="store_true", help="Emit machine-readable JSON to stdout")

    # repair-manifest
    p_repair_manifest = subparsers.add_parser("repair-manifest", help="Rebuild manifest from disk")
    p_repair_manifest.add_argument("--workspace", default=".", help="Workspace path")
    p_repair_manifest.add_argument("--dry-run", action="store_true", help="Preview manifest rebuild without writing")
    p_repair_manifest.add_argument("--json", action="store_true", help="Emit machine-readable JSON to stdout")

    # snapshot
    p_snapshot = subparsers.add_parser("snapshot", help="Create, verify, or restore store snapshots")
    snapshot_subparsers = p_snapshot.add_subparsers(dest="snapshot_command")

    p_snapshot_create = snapshot_subparsers.add_parser("create", help="Create a snapshot")
    p_snapshot_create.add_argument("--workspace", default=".", help="Workspace path")
    p_snapshot_create.add_argument("--output", required=True, help="Output directory for snapshot")
    p_snapshot_create.add_argument("--json", action="store_true", help="Emit machine-readable JSON to stdout")

    p_snapshot_verify = snapshot_subparsers.add_parser("verify", help="Verify a snapshot")
    p_snapshot_verify.add_argument("--path", required=True, help="Snapshot directory path")
    p_snapshot_verify.add_argument("--json", action="store_true", help="Emit machine-readable JSON to stdout")

    p_snapshot_restore = snapshot_subparsers.add_parser("restore", help="Restore a snapshot")
    p_snapshot_restore.add_argument("--path", required=True, help="Snapshot directory path")
    p_snapshot_restore.add_argument("--workspace", required=True, help="Target workspace path")
    p_snapshot_restore.add_argument("--allow-non-empty", action="store_true", help="Allow restoring into a non-empty workspace by backing it up first")
    p_snapshot_restore.add_argument("--json", action="store_true", help="Emit machine-readable JSON to stdout")

    # export
    p_export = subparsers.add_parser("export", help="Export memories to JSON")
    p_export.add_argument("--workspace", default=".", help="Workspace path")
    p_export.add_argument("--output", "-o", required=True, help="Output file path")

    # ingest-pdf
    p_pdf = subparsers.add_parser("ingest-pdf", help="Ingest a PDF into memory")
    p_pdf.add_argument("pdf", help="Path to the PDF file")
    p_pdf.add_argument("--workspace", default=".", help="Workspace path")
    p_pdf.add_argument("--category", default="document", help="Memory category (default: document)")
    p_pdf.add_argument("--no-ocr", action="store_true", help="Disable OCR fallback for scanned pages")
    p_pdf.add_argument("--layout", action="store_true", help="Prefer pdfminer layout extraction")
    p_pdf.add_argument("--info", action="store_true", help="Show PDF info without ingesting")

    # explain
    p_explain = subparsers.add_parser("explain", help="Search with detailed score breakdown")
    p_explain.add_argument("query", help="Search query")
    p_explain.add_argument("--workspace", default=".", help="Workspace path")
    p_explain.add_argument("--limit", type=int, default=10, help="Max results (default: 10)")

    # enrich
    p_enrich = subparsers.add_parser("enrich", help="Enrich unenriched memories")
    p_enrich.add_argument("--workspace", default=".", help="Workspace path")
    p_enrich.add_argument("--keys", default=None, help="Comma-separated API keys for multi-key enrichment (round-robin)")
    p_enrich.add_argument("--coverage", action="store_true", help="Show enrichment coverage only")

    # import
    p_import = subparsers.add_parser("import", help="Import memories from another system")
    p_import.add_argument("--workspace", default=".", help="Target workspace path")
    p_import.add_argument("--input", "-i", required=True, help="Input file or directory")
    p_import.add_argument("--from", dest="source", default="auto",
                          choices=["auto", "mem0", "memvid", "memo", "zep", "langmem",
                                   "openai", "json", "jsonl", "sqlite", "markdown", "csv"],
                          help="Source format (default: auto-detect)")
    p_import.add_argument("--replace", action="store_true", help="Replace instead of merge")
    p_import.add_argument("--dry-run", action="store_true", help="Show what would be imported")

    # cleanup
    p_cleanup = subparsers.add_parser("cleanup", help="Purge transport metadata contamination from memory store")
    p_cleanup.add_argument("--workspace", default=".", help="Workspace path (memory store directory)")
    p_cleanup.add_argument("--dry-run", action="store_true", help="Show what would be removed without modifying files")

    p_init.set_defaults(func=cmd_init)
    p_status.set_defaults(func=cmd_status)
    p_rebuild.set_defaults(func=cmd_rebuild_graph)
    p_serve.set_defaults(func=cmd_serve)
    p_sync.set_defaults(func=cmd_sync)
    p_validate.set_defaults(func=cmd_validate)
    p_doctor.set_defaults(func=cmd_doctor)
    p_repair_manifest.set_defaults(func=cmd_repair_manifest)
    p_snapshot_create.set_defaults(func=cmd_snapshot_create)
    p_snapshot_verify.set_defaults(func=cmd_snapshot_verify)
    p_snapshot_restore.set_defaults(func=cmd_snapshot_restore)
    p_export.set_defaults(func=cmd_export)
    p_pdf.set_defaults(func=cmd_ingest_pdf)
    p_explain.set_defaults(func=cmd_explain)
    p_enrich.set_defaults(func=cmd_enrich)
    p_import.set_defaults(func=cmd_import)
    p_cleanup.set_defaults(func=cmd_cleanup)

    args = parser.parse_args(argv)

    if hasattr(args, "func"):
        return args.func(args)
    parser.print_help()
    return 0


if __name__ == "__main__":
    sys.exit(main())
