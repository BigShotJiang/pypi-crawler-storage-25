"""
Peer-to-peer store synchronisation for Parsica Memory v3.1.8.

Syncs memory entries and daily log files between peer workspaces,
using hash-based deduplication to avoid double-ingesting.  New entries
from peers are appended to the local WAL with a ``synced_from``
provenance field so you always know where a memory came from.

Usage::

    from parsica_memory.sync import PeerSync

    ps = PeerSync("/path/to/local/store")
    result = ps.sync(hours=12, peers=["/mnt/remote/store"])
    print(result)  # SyncResult(synced=14, skipped=3, ...)

    merged = ps.sync_daily_logs(hours=24)
    print(f"{merged} log lines merged")

Zero external dependencies — stdlib only.
"""

from __future__ import annotations

import fcntl
import hashlib
import json
import logging
import os
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Optional, Set

logger = logging.getLogger(__name__)


@dataclass
class SyncResult:
    """Outcome of a peer sync operation."""

    synced: int = 0
    skipped: int = 0
    errors: List[str] = field(default_factory=list)
    log_lines_merged: int = 0


class PeerSync:
    """Synchronise memories between peer Parsica stores.

    Parameters
    ----------
    workspace : str
        Absolute or relative path to the **local** memory store
        (the directory that contains ``shards/`` and ``.parsica_wal.jsonl``).
    config : dict | None
        Optional pre-loaded config dict.  When *None*, the constructor
        reads ``parsica_config.json`` from *workspace* (if it exists).

    Config keys (all optional)::

        sync_peers          : List[str]   — default peer store paths
        sync_daily_logs     : bool        — sync daily log files (default True)
        sync_daily_logs_path: str         — relative subdir for daily logs (default "memory")
        sync_max_hours      : int         — max allowed hours window (default 24)
    """

    def __init__(self, workspace: str, config: Optional[dict] = None) -> None:
        self.workspace = os.path.abspath(workspace)

        # v3.2.0: Block PeerSync on segmented workspaces.
        # PeerSync reads/writes legacy shards + .parsica_wal.jsonl which
        # segmented storage does not use. Allowing sync on a segmented
        # workspace silently loses synced entries.
        # Check for manifest OR hot.jsonl — a fresh segmented workspace may
        # have hot.jsonl before the manifest is persisted.
        _seg_dir = os.path.join(self.workspace, "segments")
        _manifest_path = os.path.join(_seg_dir, "manifest.json")
        _hot_path = os.path.join(_seg_dir, "hot.jsonl")
        if os.path.exists(_manifest_path) or os.path.exists(_hot_path):
            raise NotImplementedError(
                "PeerSync is not compatible with segmented storage (v3.2). "
                "Segmented workspaces use segments/manifest.json for persistence, "
                "but PeerSync reads/writes legacy shards and .parsica_wal.jsonl. "
                "Full segment-aware PeerSync support is planned for v3.3. "
                "To use sync, initialize MemorySystem with storage_backend='enterprise'."
            )

        self._config = config or self._load_config()

        self.default_peers: List[str] = self._config.get("sync_peers", [])
        self.sync_daily_logs_enabled: bool = self._config.get("sync_daily_logs", True)
        self.daily_logs_subdir: str = self._config.get("sync_daily_logs_path", "memory")
        self.max_hours: int = self._config.get("sync_max_hours", 24)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def sync(self, hours: int = 24, peers: Optional[List[str]] = None) -> SyncResult:
        """Pull new memories from *peers* into the local store.

        Only entries whose ``hash`` does not already exist locally are
        ingested.  Each ingested entry receives a ``synced_from`` field
        set to the peer path it came from.

        Parameters
        ----------
        hours : int
            Look-back window in hours.  Must be 1–24 inclusive.
        peers : list[str] | None
            Peer store paths to sync from.  Falls back to
            ``sync_peers`` in config.

        Returns
        -------
        SyncResult
        """
        self._validate_hours(hours)
        peers = peers or self.default_peers
        result = SyncResult()

        cutoff = self._cutoff_dt(hours)
        local_hashes = self._get_local_hashes()

        for peer_path in peers:
            peer_path = os.path.abspath(peer_path)
            if not os.path.isdir(peer_path):
                result.errors.append(f"peer not found: {peer_path}")
                continue

            try:
                peer_entries = self._read_peer_memories(peer_path, cutoff)
            except Exception as exc:  # noqa: BLE001
                result.errors.append(f"error reading {peer_path}: {exc}")
                continue

            new_entries: List[dict] = []
            for entry in peer_entries:
                h = entry.get("hash", "")
                if h in local_hashes:
                    result.skipped += 1
                    continue
                entry["synced_from"] = peer_path
                new_entries.append(entry)
                local_hashes.add(h)
                result.synced += 1

            if new_entries:
                self._append_to_local_wal(new_entries)

        # Optionally sync daily logs
        if self.sync_daily_logs_enabled and peers:
            result.log_lines_merged = self.sync_daily_logs(
                hours=hours, peers=peers,
            )

        return result

    def sync_daily_logs(
        self,
        hours: int = 24,
        peers: Optional[List[str]] = None,
    ) -> int:
        """Merge peer daily-log markdown files into local ones.

        Deduplicates by line-content hash and preserves chronological
        order.  Returns the total number of **new** lines merged.
        """
        self._validate_hours(hours)
        peers = peers or self.default_peers
        total_merged = 0

        cutoff = datetime.now(timezone.utc) - timedelta(hours=hours)

        for peer_path in peers:
            peer_path = os.path.abspath(peer_path)
            # Daily logs live at {workspace_parent}/memory/YYYY-MM-DD.md
            # where workspace_parent = dirname(peer_path)  (store is a subdir)
            peer_log_dir = os.path.join(
                os.path.dirname(peer_path), self.daily_logs_subdir,
            )
            if not os.path.isdir(peer_log_dir):
                continue

            local_log_dir = os.path.join(
                os.path.dirname(self.workspace), self.daily_logs_subdir,
            )
            os.makedirs(local_log_dir, exist_ok=True)

            for fname in os.listdir(peer_log_dir):
                if not fname.endswith(".md") or len(fname) != 13:
                    # Expected format: YYYY-MM-DD.md  (10 + 3 = 13 chars)
                    continue
                date_str = fname[:-3]  # YYYY-MM-DD
                try:
                    file_date = datetime.strptime(date_str, "%Y-%m-%d").replace(
                        tzinfo=timezone.utc,
                    )
                except ValueError:
                    continue
                # Compare at day level — include today's log and any log
                # within the hours window (a file dated today should always
                # be included even if hours < 24)
                file_end_of_day = file_date + timedelta(days=1)
                if file_end_of_day < cutoff:
                    continue

                peer_file = os.path.join(peer_log_dir, fname)
                local_file = os.path.join(local_log_dir, fname)

                try:
                    with open(peer_file, "r", encoding="utf-8") as f:
                        incoming_lines = f.read().splitlines()
                except OSError:
                    continue

                existing_lines: List[str] = []
                if os.path.exists(local_file):
                    try:
                        with open(local_file, "r", encoding="utf-8") as f:
                            existing_lines = f.read().splitlines()
                    except OSError:
                        pass

                merged = self._dedup_log_lines(existing_lines, incoming_lines)
                new_count = len(merged) - len(existing_lines)
                if new_count > 0:
                    # Atomic write: write to temp, then replace
                    tmp_file = local_file + ".tmp"
                    with open(tmp_file, "w", encoding="utf-8") as f:
                        f.write("\n".join(merged))
                        if merged:
                            f.write("\n")
                    os.replace(tmp_file, local_file)
                    total_merged += new_count

        return total_merged

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _validate_hours(self, hours) -> None:
        # Accept int or float that's a whole number (JSON deserializes 6.0 as float)
        if isinstance(hours, float) and hours == int(hours):
            hours = int(hours)
        if not isinstance(hours, int) or hours < 1 or hours > 24:
            raise ValueError(
                f"hours must be an integer between 1 and 24, got {hours!r}"
            )

    def _cutoff_dt(self, hours: int) -> datetime:
        """Return a timezone-aware UTC datetime *hours* in the past."""
        return datetime.now(timezone.utc) - timedelta(hours=hours)

    @staticmethod
    def _parse_created(created_str: str) -> Optional[datetime]:
        """Parse a ``created`` ISO string to a timezone-aware UTC datetime.

        Handles both naive (assumed UTC) and aware timestamps.
        Returns *None* for unparseable values.
        """
        if not created_str:
            return None
        try:
            # Handle 'Z' suffix (common in some serializers)
            if created_str.endswith("Z"):
                created_str = created_str[:-1] + "+00:00"
            dt = datetime.fromisoformat(created_str)
            if dt.tzinfo is None:
                # Naive timestamps are assumed UTC (matches Parsica convention)
                dt = dt.replace(tzinfo=timezone.utc)
            else:
                dt = dt.astimezone(timezone.utc)
            return dt
        except (ValueError, TypeError):
            return None

    def _load_config(self) -> dict:
        cfg_path = os.path.join(self.workspace, "parsica_config.json")
        if os.path.exists(cfg_path):
            try:
                with open(cfg_path, "r", encoding="utf-8") as f:
                    return json.load(f)
            except (json.JSONDecodeError, OSError):
                pass
        return {}

    def _read_peer_memories(
        self, peer_path: str, cutoff: datetime,
    ) -> List[dict]:
        """Read shard JSON + WAL JSONL from a peer, filtered by time.

        Uses datetime comparison (not string comparison) to handle
        timezone-mixed timestamps correctly.  Validates that shard files
        are regular files (not symlinks to external paths).
        """
        entries: List[dict] = []
        real_peer = os.path.realpath(peer_path)

        # Validate peer looks like a Parsica store
        if not (os.path.isdir(os.path.join(real_peer, "shards"))
                or os.path.exists(os.path.join(real_peer, ".parsica_wal.jsonl"))):
            raise ValueError(
                f"peer path does not look like a Parsica store: {peer_path}"
            )

        # 1. Read shard files (with symlink protection)
        shards_dir = os.path.join(real_peer, "shards")
        if os.path.isdir(shards_dir):
            for fname in os.listdir(shards_dir):
                if not fname.startswith("shard_") or not fname.endswith(".json"):
                    continue
                shard_path = os.path.join(shards_dir, fname)
                # Symlink containment — resolved path must stay within peer store
                real_shard = os.path.realpath(shard_path)
                if not real_shard.startswith(real_peer + os.sep) and real_shard != real_peer:
                    logger.warning("sync: skipping symlink outside store: %s", shard_path)
                    continue
                if not os.path.isfile(real_shard):
                    continue
                try:
                    with open(real_shard, "r", encoding="utf-8") as f:
                        data = json.load(f)
                    # Handle both list and dict shard formats
                    items = data if isinstance(data, list) else data.get("memories", data.get("entries", []))
                    for entry in items:
                        dt = self._parse_created(entry.get("created", ""))
                        if dt is not None and dt >= cutoff:
                            entries.append(entry)
                except (json.JSONDecodeError, OSError):
                    continue

        # 2. Read WAL
        wal_path = os.path.join(real_peer, ".parsica_wal.jsonl")
        if os.path.exists(wal_path):
            try:
                with open(wal_path, "r", encoding="utf-8") as f:
                    for line in f:
                        stripped = line.strip()
                        if not stripped:
                            continue
                        try:
                            entry = json.loads(stripped)
                            dt = self._parse_created(entry.get("created", ""))
                            if dt is not None and dt >= cutoff:
                                entries.append(entry)
                        except json.JSONDecodeError:
                            continue
            except OSError:
                pass

        return entries

    def _get_local_hashes(self) -> Set[str]:
        """Collect every entry hash from local shards + WAL."""
        hashes: Set[str] = set()

        # Shards
        shards_dir = os.path.join(self.workspace, "shards")
        if os.path.isdir(shards_dir):
            for fname in os.listdir(shards_dir):
                if not fname.startswith("shard_") or not fname.endswith(".json"):
                    continue
                shard_path = os.path.join(shards_dir, fname)
                try:
                    with open(shard_path, "r", encoding="utf-8") as f:
                        data = json.load(f)
                    for entry in data.get("memories", []):
                        h = entry.get("hash", "")
                        if h:
                            hashes.add(h)
                except (json.JSONDecodeError, OSError):
                    continue

        # WAL
        wal_path = os.path.join(self.workspace, ".parsica_wal.jsonl")
        if os.path.exists(wal_path):
            try:
                with open(wal_path, "r", encoding="utf-8") as f:
                    for line in f:
                        stripped = line.strip()
                        if not stripped:
                            continue
                        try:
                            entry = json.loads(stripped)
                            h = entry.get("hash", "")
                            if h:
                                hashes.add(h)
                        except json.JSONDecodeError:
                            continue
            except OSError:
                pass

        return hashes

    def _append_to_local_wal(self, entries: List[dict]) -> None:
        """Append entry dicts to the local WAL file.

        Uses ``fcntl.flock()`` for exclusive locking so concurrent sync
        operations cannot interleave writes and corrupt the JSONL.
        Writes are batched and flushed once for performance.
        """
        wal_path = os.path.join(self.workspace, ".parsica_wal.jsonl")
        os.makedirs(os.path.dirname(os.path.abspath(wal_path)), exist_ok=True)
        with open(wal_path, "a", encoding="utf-8") as f:
            try:
                fcntl.flock(f.fileno(), fcntl.LOCK_EX)
            except (OSError, AttributeError):
                # fcntl not available on all platforms — degrade gracefully
                pass
            try:
                for entry in entries:
                    f.write(json.dumps(entry, ensure_ascii=False) + "\n")
                f.flush()
            finally:
                try:
                    fcntl.flock(f.fileno(), fcntl.LOCK_UN)
                except (OSError, AttributeError):
                    pass

    def _dedup_log_lines(
        self,
        existing_lines: List[str],
        incoming_lines: List[str],
    ) -> List[str]:
        """Merge *incoming_lines* into *existing_lines*, deduplicating by
        stripped-content MD5 hash and preserving chronological order.
        """
        seen: Set[str] = set()
        for line in existing_lines:
            h = hashlib.sha256(line.strip().encode("utf-8")).hexdigest()[:16]
            seen.add(h)

        merged = list(existing_lines)
        for line in incoming_lines:
            h = hashlib.sha256(line.strip().encode("utf-8")).hexdigest()[:16]
            if h not in seen:
                merged.append(line)
                seen.add(h)

        return merged
