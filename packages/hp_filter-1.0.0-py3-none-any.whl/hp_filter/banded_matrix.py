"""Class implemented PSD Banded Operator."""

# flake8: noqa

from typing import Self

import torch
from einops import rearrange, repeat
from torch import diag_embed as torch_diag_embed
from torch import sqrt as torch_sqrt


class SPDBandedMatrix:
    """LinearOperator wrapping of a banded matrix."""

    def __init__(
        self,
        A: torch.Tensor,
        order: int = 1,
        batch_size: int | None = None,
        packed: bool = False,
    ):
        super().__init__()
        # Check size and dim consistency
        assert (
            order + 1 < A.shape[-1]
        ), f"Number of sample {A.shape} is lower than the order {order + 1}."
        assert A.ndim in (2, 3)

        # Save data in lower packed format
        self.order = order
        self.dtype = A.dtype

        if packed:
            self.data = A
        else:
            self.data = self.to_packed_storage(A)

        if (A.ndim == 2) and batch_size:
            self.data = repeat(self.data, "u v -> b u v", b=batch_size).clone()

    @property
    def size(self) -> int:
        """Returns the size of the matrix."""
        return self.data.shape[-1]

    def to_packed_storage(self, A: torch.Tensor) -> torch.Tensor:
        """Convert full matrix into a lower packed tensor.

        From https://www.netlib.org/lapack/lug/node124.html
        """
        match A.ndim:
            case 2:
                data = torch.zeros(
                    self.order + 1,
                    A.shape[-1],
                    dtype=A.dtype,
                    device=A.device,
                )
                for i in range(self.order + 1):
                    for j in range(A.shape[-1] - i):
                        data[i, j] = A[j, i + j]
            case 3:
                data = torch.zeros(
                    A.shape[0],
                    self.order + 1,
                    A.shape[-1],
                    dtype=A.dtype,
                    device=A.device,
                )
                for i in range(self.order + 1):
                    for j in range(A.shape[-1] - i):
                        data[:, i, j] = A[:, j, i + j]
        return data

    def __matmul__(self, X: torch.Tensor) -> torch.Tensor:
        """Dot product for symmetric banded matrix."""
        assert self.data.shape[0] == X.shape[0]
        assert self.size == X.shape[1]
        assert self.data.device == X.device

        return matmul(self.data, X, self.order)

    def to_dense(self) -> torch.Tensor:
        """Return of dense linear operator."""
        A = torch.zeros(
            self.data.shape[0],
            self.size,
            self.size,
            dtype=self.data.dtype,
            device=self.data.device,
        )
        for i in range(1, self.order + 1):
            A += torch_diag_embed(self.data[:, i, :-i], offset=i)
        A = A + rearrange(A, "b u v -> b v u")
        A += torch_diag_embed(self.data[:, 0, :])
        return A

    def add_diag(self, M: torch.Tensor):
        """Add array M to the diagonal of the SPDBandedMatrix."""
        assert M.ndim == 2
        assert (
            self.data.shape[0] == M.shape[0]
        ), f"Batch size not equal: data =  {self.data.shape[0]} and M = {M.shape[0]}"
        assert self.size == M.shape[1]
        assert self.data.device == M.device

        self.data[:, 0, :] += M

    def to(
        self,
        device: torch.device | None = None,
        dtype: torch.dtype | None = None,
    ) -> Self:
        """Move self to device and cast to dtype - do nothing if all None."""
        self.data = self.data.to(device=device, dtype=dtype)
        return self

    def __getitem__(self, idx: torch.Tensor) -> Self:
        """Do slicing on the batch dimension.

        Currently, only the batch dimension is handled
        """
        assert idx.ndim == 1
        assert not torch.is_floating_point(idx) and not torch.is_complex(idx)
        assert idx.max() <= self.data.shape[0] and idx.min() >= 0

        return SPDBandedMatrix(A=self.data[idx, ...], order=self.order, packed=True)


def cholesky(A: SPDBandedMatrix) -> SPDBandedMatrix:
    """Cholesky decompostion of SPDBandedMatrix."""
    # Clone matrix - does not perform in place modification
    data = cholesky_(A.data.detach().clone(), A.order, A.size)

    return SPDBandedMatrix(A=data, order=A.order, packed=True)


@torch.jit.script
def cholesky_(data: torch.Tensor, order: int, size: int) -> torch.Tensor:
    """Compile cholesky decomposition."""
    for j in range(size):
        v0 = data[:, 0, j]

        iv0 = 1 / v0
        sv0 = torch_sqrt(v0)
        siv0 = torch_sqrt(iv0)

        v_access = data[:, 1:, j].detach().clone()
        data[:, 0, j] = sv0
        data[:, 1:, j] = v_access * siv0[:, None]

        for k in range(0, min(order, size - j - 1)):
            data[:, : (order - k), k + j + 1] -= (
                v_access[:, k : (k + order)] * v_access[:, k][:, None] * iv0[:, None]
            )
    return data


def cholesky_solve(A: SPDBandedMatrix, X: torch.Tensor) -> torch.Tensor:
    """
    Solve the linear equations A X = Z.

    A is the Cholesky factorization of the SPDBandedMatrix,
    obtaine with cholesky solver.
    """
    assert X.ndim == 3
    assert A.data.shape[0] == X.shape[0]
    assert A.size == X.shape[1]

    return cholesky_solve_(A.data, X.detach().clone(), A.order, A.size)


@torch.jit.script
def cholesky_solve_(
    data: torch.Tensor, X: torch.Tensor, order: int, size: int
) -> torch.Tensor:
    """Copmile cholesky solver."""
    # Forward pass
    X[:, 0, :] /= data[:, 0, 0][:, None]
    for m in range(1, size):
        diff = X[:, m, :].clone()
        for k in range(1, min(order + 1, m + 1)):
            n = m - k
            diff -= data[:, k, n][:, None] * X[:, n, :]
        X[:, m, :] = diff / data[:, 0, m][:, None]

    # Backward pass
    X[:, -1, :] /= data[:, 0, -1][:, None]
    for m in range(1, size):
        p = size - 1 - m
        diff = X[:, p, :].clone()
        for k in range(1, min(order + 1, m + 1)):
            n = p + k
            diff -= data[:, k, p][:, None] * X[:, n, :]
        X[:, p, :] = diff / data[:, 0, p][:, None]
    return X


def logdet(Achol: SPDBandedMatrix) -> torch.Tensor:
    """
    Compute the log_determinant of a batch of SPDBandedMatrix.

    Achol should be the cholesky decomposition of A.
    """
    batch_logdet: torch.Tensor = 2 * torch.sum(Achol.data[:, 0, :].log(), dim=-1)
    return batch_logdet


@torch.compile
def matmul(data: torch.Tensor, X: torch.Tensor, order: int) -> torch.Tensor:
    """Compiled function for matmul in SPDBandedMatrix."""
    out = data[:, 0, :][..., None] * X
    for i in range(1, order + 1):
        data_i = data[:, i, :-i][..., None]
        out[:, :-i, :] += data_i * X[:, i:, :]
        out[:, i:, :] += data_i * X[:, :-i, :]
    return out
