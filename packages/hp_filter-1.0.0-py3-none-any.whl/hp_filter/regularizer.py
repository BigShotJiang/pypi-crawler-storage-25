"""Class that returns the regularization weight for use in HPFilter."""

from dataclasses import dataclass

import torch
from einops import pack, rearrange
from torch import nn


@dataclass
class BaseRegularizerConfig:
    """Base configuration for regularizer."""

    dtype: torch.dtype = torch.float64
    lower_bound: float = 1e-6
    higher_bound: float = 1e10

    def __post_init__(self) -> None:
        """Check lower/higher bound."""
        assert (
            0 < self.lower_bound < self.higher_bound
        ), "Lower bound should be smaller than higher bound"


@dataclass
class ScalarRegularizerConfig(BaseRegularizerConfig):
    """Configuration for scalar regularizer."""

    constant: float = 1000.0  # Unconstrained scalar regularization parameter

    def __post_init__(self) -> None:
        """Check init."""
        assert self.lower_bound < self.constant < self.higher_bound


@dataclass
class PolynomialFunctionRegularizerConfig(BaseRegularizerConfig):
    """Configuration for polynomial regularizer."""

    degree: int = 1  # Degree of the polynomial_features
    bias_init: float = 1000.0  # Intial values of the bias for the linear layer

    def __post_init__(self) -> None:
        """Check degree parameter."""
        assert (self.degree > 0) and (
            isinstance(self.degree, int)
        ), "degree parameter should be int and higher or equal to 1"


@dataclass
class FourrierFunctionRegularizerConfig(BaseRegularizerConfig):
    """Configuration for Fourrier function regularizer."""

    n_basis: int = 10  # Nb. of Fourrier basis including the linearterm
    scaler: float = 1  # Scaling value for time
    bias_init: float = 1000.0  # Intial values of the bias for the linear layer

    def __post_init__(self) -> None:
        """Check n_basis and scaler values consistency."""
        assert (
            self.n_basis > 1
        ), "n_basis should be > 1. Otherwise use PolynomialFunctionRegularizer"
        assert self.scaler > 0.0, "Scaler should be strictly positive"


@dataclass
class TransformerRegularizerConfig(BaseRegularizerConfig):
    """Configuration for Transformer regularizer."""

    n_channels: int = 10
    embed_dim: int = 64
    n_head: int = 4
    depth: int = 2
    dim_feedforward: int = 512
    dropout: float = 0.5
    scaler: float = 365.0
    dtype: torch.dtype = torch.bfloat16


class BaseRegularizer(nn.Module):
    """Scalar Regularizer: strictly positivie constant w.r.t time."""

    def __init__(self, config: BaseRegularizerConfig):
        super().__init__()
        self.lower_bound = config.lower_bound
        self.higher_bound = config.higher_bound
        self.delta_bound = self.higher_bound - self.lower_bound
        self.dtype = config.dtype
        self.sigmoid = torch.sigmoid
        self.logit = torch.logit

    def forward(self, t: torch.Tensor) -> torch.Tensor:
        """Forward pass to be implemented."""
        raise NotImplementedError()

    def transform(self, t: torch.Tensor) -> torch.Tensor:
        """Ensure that output is interval [lower, higher]."""
        return torch.sigmoid(t) * self.delta_bound + self.lower_bound

    def inv_transform(self, t: torch.Tensor) -> torch.Tensor:
        """Inverse constraint transform."""
        return torch.log((t - self.lower_bound) / (self.higher_bound - t))

    def check_input(self, t: torch.Tensor) -> torch.Tensor:
        """Check time input and reshape."""
        assert t.dtype == self.dtype
        assert t.ndim == 1
        return rearrange(t, "b->b 1")


class ScalarRegularizer(BaseRegularizer):
    """Scalar Regularizer: constant w.r.t time."""

    def __init__(self, config: ScalarRegularizerConfig):
        super().__init__(
            BaseRegularizerConfig(
                dtype=config.dtype,
                lower_bound=config.lower_bound,
                higher_bound=config.higher_bound,
            )
        )
        self.constant = nn.Parameter(
            self.inv_transform(torch.tensor([config.constant], dtype=config.dtype)),
            requires_grad=True,
        )

    def forward(self, t: torch.Tensor) -> torch.Tensor:
        """Forward pass."""
        return self.transform(self.constant)


class PolynomialFunctionRegularizer(BaseRegularizer):
    """Regularizer with a polynomial trend w.r.t. to time."""

    def __init__(self, config=PolynomialFunctionRegularizerConfig):
        super().__init__(
            BaseRegularizerConfig(
                dtype=config.dtype,
                lower_bound=config.lower_bound,
                higher_bound=config.higher_bound,
            )
        )
        self.degree = config.degree
        self.layer = nn.Linear(
            in_features=self.degree,
            out_features=1,
            bias=True,
            dtype=config.dtype,
        )
        self.batch_norm = nn.BatchNorm1d(num_features=self.degree, dtype=config.dtype)
        with torch.no_grad():
            self.layer.weight.fill_(0.0)
            self.layer.bias.fill_(
                self.inv_transform(
                    torch.tensor(
                        [config.bias_init],
                        dtype=config.dtype,
                    )
                )[0]
            )

    def forward(self, t: torch.Tensor) -> torch.Tensor:
        """Forward pass.

        First compute polynome function then linear combine to get a scaler.
        Transform to ensure strict bound constraint.
        """
        t = self.check_input(t)
        out = self.layer(self.batch_norm(self.polynomial_features(t)))
        out = self.transform(out)
        return rearrange(out, "b 1->b")

    def polynomial_features(self, t: torch.Tensor) -> torch.Tensor:
        """Polynomial feature transform."""
        return pack([t**p for p in range(1, self.degree + 1)], "b *")[0]


class FourrierFunctionRegularizer(BaseRegularizer):
    """Regularizer with a Fourrier basis."""

    def __init__(self, config: FourrierFunctionRegularizerConfig):
        super().__init__(
            BaseRegularizerConfig(
                dtype=config.dtype,
                lower_bound=config.lower_bound,
                higher_bound=config.higher_bound,
            )
        )
        self.n_basis = config.n_basis
        self.scaler = config.scaler

        self.layer = nn.Linear(
            in_features=2 * self.n_basis,
            out_features=1,
            bias=True,
            dtype=config.dtype,
        )
        with torch.no_grad():
            self.layer.weight.fill_(0.0)
            self.layer.bias.fill_(
                self.inv_transform(
                    torch.tensor(
                        [config.bias_init],
                        dtype=config.dtype,
                    )
                )[0]
            )

        self.coefficient = nn.Parameter(
            rearrange(
                1
                / torch.arange(
                    1,
                    self.n_basis + 1,
                    dtype=config.dtype,
                ),
                "b -> 1 b",
            ),
            requires_grad=False,
        )

    def forward(self, t: torch.Tensor) -> torch.Tensor:
        """Forward pass.

        First compute fourrier function then linear combine to get a scaler.
        Transform to ensure strict bound constraint.
        """
        t = self.check_input(t)
        out = self.fourrier_features(t)
        out = self.transform(out)
        return rearrange(out, "b 1->b")

    def fourrier_features(self, t: torch.Tensor) -> torch.Tensor:
        """Compute Fourrier feature and linear combine them."""
        out = t / self.scaler * self.coefficient
        out, _ = pack([torch.cos(out), torch.sin(out)], "b *")
        out = self.layer(out)
        return out


class TransformerRegularizer(BaseRegularizer):
    """Regularizer with a transformer."""

    def __init__(self, config: TransformerRegularizerConfig):
        super().__init__(
            BaseRegularizerConfig(
                dtype=config.dtype,
                lower_bound=config.lower_bound,
                higher_bound=config.higher_bound,
            )
        )
        self.dtype = config.dtype
        self.n_channels = config.n_channels
        self.embed_dim = config.embed_dim

        self.time_embedding = PolarPositionalEncoding(
            n_features=config.embed_dim, div=config.scaler, dtype=config.dtype
        )
        self.linear_encoding = nn.Linear(
            config.n_channels, config.embed_dim, dtype=config.dtype
        )
        self.batchnorm = nn.BatchNorm1d(1, dtype=config.dtype)
        self.linear_decoding = nn.Linear(
            self.embed_dim, 1, dtype=config.dtype, bias=False
        )
        self.transformer = nn.Transformer(
            d_model=self.embed_dim,
            nhead=config.n_head,
            num_encoder_layers=config.depth,
            num_decoder_layers=config.depth,
            dim_feedforward=config.dim_feedforward,
            dropout=config.dropout,
            batch_first=True,
            dtype=config.dtype,
        )

    def forward(
        self,
        t_key: torch.Tensor,
        x_values: torch.Tensor,
        mask_value: torch.Tensor,
    ) -> torch.Tensor:
        """Forward pass."""
        t_key_embedded = self.time_embedding(t_key)
        x_values_embedded = self.linear_encoding(x_values) + t_key_embedded
        return self.transform(
            rearrange(
                self.batchnorm(
                    rearrange(
                        self.linear_decoding(
                            self.transformer(
                                x_values_embedded,
                                t_key_embedded,
                                src_key_padding_mask=mask_value,
                            )
                        ),
                        "b t e -> (b t) e",
                    )
                ),
                "(b t) e -> b t e",
                b=t_key_embedded.shape[0],
                t=t_key_embedded.shape[1],
            )
        )


class PolarPositionalEncoding(nn.Module):
    """Implement polar positional encoding."""

    def __init__(
        self,
        n_features: int,
        div: float = 365,
        device: torch.device | None = None,
        dtype: torch.dtype | None = None,
    ):
        super().__init__()
        self.div = div
        self.n_features = n_features
        self.layers = nn.Sequential(
            nn.Linear(2, self.n_features, device=device, dtype=dtype),
            nn.ReLU(),
            nn.Linear(self.n_features, self.n_features, device=device, dtype=dtype),
        )

    def forward(self, doy: torch.Tensor) -> torch.Tensor:
        """Forward method."""
        pe = torch.cat(
            [
                torch.sin(2 * torch.pi * doy / self.div),
                torch.cos(2 * torch.pi * doy / self.div),
            ],
            dim=-1,
        )
        pe = self.layers(pe)
        return pe
