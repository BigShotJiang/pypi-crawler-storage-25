"""Implement banded linear solver using torch autograd"""

from collections.abc import Callable
from typing import TypeAlias

import torch
from einops import einsum, parse_shape, rearrange
from torch import any as torch_any
from torch import isnan as torch_isnan
from torch import ones_like as torch_ones_like
from torch.autograd import Function

from hp_filter.banded_matrix import SPDBandedMatrix, cholesky, cholesky_solve

Solver: TypeAlias = Callable[
    [torch.Tensor, torch.Tensor, torch.Tensor, int, float | None], torch.Tensor
]


def cholesky_solver(
    banded_matrix_full: torch.Tensor,
    weight: torch.Tensor,
    data: torch.Tensor,
    order: int,
    tol: float | None = None,
) -> torch.Tensor:
    """Solve banded linear problem using cholesky decomposition."""
    tol = tol or 1e-6
    assert banded_matrix_full.dtype == torch.float64

    # For cholesky decomposition, tensors are cast to torch.float64
    data_dtype = data.dtype

    # Create linear operator
    batch_banded_matrix = SPDBandedMatrix(
        banded_matrix_full, order=order, batch_size=data.shape[0]
    )
    batch_banded_matrix.add_diag(weight.to(torch.float64))

    # Perform cholesky decomposition
    batch_l_factor = cholesky(batch_banded_matrix)
    regul_step = 0
    while torch_any(torch_isnan(batch_l_factor.data)):
        print("add regul")
        batch_banded_matrix.add_diag(
            tol * 10.0**regul_step * torch_ones_like(weight).to(torch.float64),
        )
        batch_l_factor = cholesky(batch_banded_matrix)
        regul_step += 1

    # Solve linear problem and return
    return cholesky_solve(batch_l_factor, data.to(torch.float64)).to(
        data_dtype
    )  # cast back to original dtype


# def PreconditionedConjugateGradientSolver(
#     banded_matrix_full: torch.Tensor,
#     weight: torch.Tensor,
#     data: torch.Tensor,
#     tol: float | None = None,
#     order: int | None = None,
# ) -> torch.Tensor:
#     """Helper function to solve banded linear problem"""
#     # Get info and set var
#     shapes = parse_shape(data, "b t c")
#     tol = tol or 1e-6
#     delta = tol**2
#     n_iter = shapes["t"]
#     order = (
#         order
#         if order is not None
#         else int(
#             (torch.count_nonzero(banded_matrix_full[shapes["t"] // 2, :]).item() - 1)
#             / 2
#         )
#     )

#     # Create linear operator
#     batch_banded_matrix = SPDBandedMatrix(
#         banded_matrix_full, order=order, batch_size=shapes["b"]
#     )
#     batch_banded_matrix.add_diag(weight)

#     # Get Preconditionner
#     identity = torch.eye(shapes["t"], dtype=data.dtype, device=data.device)
#     M = torch.linalg.inv(banded_matrix_full + identity)
#     invpreconditioner = repeat(M, "u v -> b u v", b=shapes["b"])

#     # Perform Conjugate gradient
#     data_ = torch.empty_like(data).copy_(data)
#     residual = data - batch_banded_matrix @ data_
#     precond_residual = invpreconditioner @ residual
#     curr_conjugate_vec = torch.empty_like(precond_residual).copy_(precond_residual)

#     precond_residual_dot_residual = (residual * precond_residual).sum(
#         dim=1, keepdim=True
#     )
#     residual_square_norm = (residual**2).sum(dim=1, keepdim=True)
#     has_converged_0 = residual_square_norm < delta
#     if has_converged_0.all():
#         return data_, None
#     has_converged = has_converged_0.detach().clone()

#     history = {
#         "residual_square_norm": [residual_square_norm.mean(-1)],
#         "has_converged": [has_converged_0.sum()],
#     }
#     for n_iter_ in range(n_iter):
#         Mp = batch_banded_matrix @ curr_conjugate_vec
#         alpha = precond_residual_dot_residual / (curr_conjugate_vec * Mp).sum(
#             dim=1, keepdim=True
#         )
#         alpha.masked_fill_(has_converged, 0)

#         data_ += alpha * curr_conjugate_vec
#         residual -= alpha * Mp
#         residual_square_norm = (residual**2).sum(dim=1, keepdim=True)
#         if torch.mean(residual_square_norm) < delta:
#             break

#         precond_residual = invpreconditioner @ residual
#         precond_residual_dot_residual_new = (residual * precond_residual).sum(
#             dim=1, keepdim=True
#         )

#         beta = precond_residual_dot_residual_new / precond_residual_dot_residual
#         beta.masked_fill_(has_converged, 0)
#         curr_conjugate_vec = precond_residual + beta * curr_conjugate_vec
#         precond_residual_dot_residual = precond_residual_dot_residual_new

#         # Update convergence and store history
#         torch.lt(residual_square_norm, delta, out=has_converged)

#         history["residual_square_norm"].append(residual_square_norm.mean(-1))
#         history["has_converged"].append((residual_square_norm < delta).sum())

#     data_[repeat(has_converged_0, "b 1 c->b t c", t=shapes["t"])] = data[
#         repeat(has_converged_0, "b 1 c->b t c", t=shapes["t"])
#     ]
#     return data_, history


solver: Solver = cholesky_solver


class BandedLinearSolver(Function):  # pylint: disable=W0223
    """Class implementing the BandedLinearSolver with autograd.

    It implement the solution of the problem
    (x-z)^T W (x-z) + lambda * z^TD^TDz

    with
    x: the reference,
    z: the solution
    lambda: regularization parameter
    D: derivative matrix
    """

    @staticmethod
    def forward(
        alpha: torch.Tensor,
        derivative_matrix: torch.Tensor,
        weight: torch.Tensor,
        data: torch.Tensor,
        order: int,
    ) -> torch.Tensor:  # type: ignore[override]
        """Forward pass."""
        # Compute regularization matrix
        dt_lambda_d: torch.Tensor = compute_regularization_matrix(
            alpha,
            derivative_matrix,
        )
        data_ = solver(dt_lambda_d, weight, data * weight[..., None], order, None)

        return data_

    @staticmethod
    def setup_context(
        ctx,
        inputs: tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, int],
        output: tuple[torch.Tensor] | torch.Tensor,
    ) -> None:  # type: ignore[override]
        """Context."""
        alpha, derivative_matrix, weight, _, order = inputs
        data_ = output

        # Save for backward
        # alpha, weight and data_ are in self.dtype
        # but derivative matrix is in float64
        ctx.mark_non_differentiable(derivative_matrix, weight)
        ctx.save_for_backward(alpha, derivative_matrix, weight, data_)
        ctx.order = order

    @staticmethod
    def backward(ctx, grad: torch.Tensor) -> tuple[
        torch.Tensor | None,
        torch.Tensor | None,
        torch.Tensor | None,
        torch.Tensor | None,
    ]:  # type: ignore[override]
        """Backward pass."""
        # Load saved tensors
        alpha, derivative_matrix, weight, data_ = ctx.saved_tensors
        grad_alpha = grad_derivative_matrix = grad_weight = grad_data_ = grad_order = (
            None  # We must expose all parameters store in ctx
        )

        if ctx.needs_input_grad[0]:
            grad_alpha = compute_gradient_alpha(
                alpha, derivative_matrix, weight, data_, grad, ctx.order
            )

        if ctx.needs_input_grad[3]:
            grad_data_ = compute_gradient_data(
                alpha, derivative_matrix, weight, grad, ctx.order
            )

        return (grad_alpha, grad_derivative_matrix, grad_weight, grad_data_, grad_order)


def compute_gradient_data(
    alpha: torch.Tensor,
    derivative_matrix: torch.Tensor,
    weight: torch.Tensor,
    grad: torch.Tensor,
    order: int,
) -> torch.Tensor:
    """Free function used to compute the gradient w.r.t. data."""
    # Compute regularization matrix derivative
    dt_lambda_d = compute_regularization_matrix(
        alpha,
        derivative_matrix,
    )
    return weight[..., None] * solver(dt_lambda_d, weight, grad, order, None)


def compute_gradient_alpha(
    alpha: torch.Tensor,
    derivative_matrix: torch.Tensor,
    weight: torch.Tensor,
    data_: torch.Tensor,
    grad: torch.Tensor,
    order: int,
) -> torch.Tensor:
    """Free function used to compute the gradient w.r.t. alpha."""
    shapes = parse_shape(data_, "b t c")

    # Compute regularization matrix derivative
    dt_lambda_d = compute_regularization_matrix(
        alpha,
        derivative_matrix,
    )
    dt_lambda_d_derivative = compute_regularization_matrix_derivative(
        alpha, derivative_matrix
    )
    grad_alpha: torch.Tensor

    # Backward
    match alpha.shape:
        case (1,):
            temp_tensor = torch.matmul(
                dt_lambda_d_derivative,
                data_.to(torch.float64),
            ).to(data_.dtype)

            # pylint: disable-next=no-member
            temp_tensor = solver(dt_lambda_d, weight, temp_tensor, order, None)

            # Compute gradient
            grad_alpha = (-1) * rearrange(
                einsum(grad, temp_tensor, "b tu c, b tu c -> "), "->1"
            )  # need 1 dim tensor

        case (s,) | (_, s) if s == derivative_matrix.shape[0]:
            temp_tensor = rearrange(
                einsum(
                    dt_lambda_d_derivative,
                    data_.to(torch.float64),
                    "b r t u, b u c -> b r t c",
                ),
                "b r t c -> b t (r c)",
            ).to(data_.dtype)

            temp_tensor = rearrange(
                solver(dt_lambda_d, weight, temp_tensor, order, None),
                "b t (r c) -> b r t c",
                b=shapes["b"],
                t=shapes["t"],
                c=shapes["c"],
            )
            # Compute gradient
            match alpha.ndim:
                case 1:
                    grad_alpha = (-1) * einsum(
                        grad, temp_tensor, "b tu c, b r tu c -> r"
                    )
                case 2:
                    grad_alpha = (-1) * einsum(
                        grad, temp_tensor, "b tu c, b r tu c -> b r"
                    )
                case _:
                    raise NotImplementedError()
        case _:
            raise NotImplementedError()
    return grad_alpha


def compute_regularization_matrix(
    alpha: torch.Tensor, derivative_matrix: torch.Tensor
) -> torch.Tensor:
    """Free function used to compute the regularization matrix.

    Return the regularization matrix in torch.float64 format because
    of numerical issues.
    """
    # Compute regularization matrix
    t = derivative_matrix.shape[0]
    derivative_matrix_ = derivative_matrix.to(torch.float64)
    alpha_ = alpha.to(torch.float64)
    match alpha.shape:
        case (1,):
            dt_lambda_d = alpha_ * torch.matmul(
                derivative_matrix_.T, derivative_matrix_
            )
        case (s,) | (_, s) if s == t:
            dt_lambda_d = torch.matmul(
                derivative_matrix_.T,
                alpha_.unsqueeze(-1) * derivative_matrix_,
            )  # we make use of matmul(diag(alpha), X) = alpha*X with broadcasting
        case _:
            raise NotImplementedError()
    return (
        dt_lambda_d  # We do not cast to original dtype because of numerical instability
    )


def compute_regularization_matrix_derivative(
    alpha: torch.Tensor, derivative_matrix: torch.Tensor
) -> torch.Tensor:
    """Free function used to compute the deriv. of the regul. term w.r.t. alpha.

    Here derivative_matrix is already in torch.float64 dtype, while alpha not.
    But alpha is used only to check dimension.
    """
    t = derivative_matrix.shape[0]
    derivative_matrix_ = derivative_matrix.to(torch.float64)
    match alpha.shape:
        case (1,):
            # Compute the derivative of DT*Lambda*D when Lambda is scalar -> DT*D
            dt_lambda_d_derivative = torch.matmul(
                derivative_matrix_.T,
                derivative_matrix_,
            )

        case (s,) | (_, s) if s == t:
            # Compute batch outer product for derivative
            # For alpha of size batch X n_times, the derivative is the same
            # for all element of the batch since we put everyting on the same doy
            # In compute_gradient_alpha then we make use of broadcasting
            dt_lambda_d_derivative = einsum(
                derivative_matrix_, derivative_matrix_, "i j, i k -> i j k"
            ).unsqueeze(0)
        case _:
            raise NotImplementedError()
    return dt_lambda_d_derivative  # Return in torch.float64 dtype
