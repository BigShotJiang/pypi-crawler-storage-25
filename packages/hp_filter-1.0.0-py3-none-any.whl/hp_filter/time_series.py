#!/usr/bin/env python

# Copyright: (c) 2023 CESBIO / Centre National d'Etudes Spatiales
"""
Data structure to store SITS tensors
"""

from dataclasses import dataclass
from typing import Self, TypeVar, cast

import torch
from einops import pack, parse_shape, rearrange, reduce, repeat, unpack
from einops.packing import Shape
from torch import all as torch_all
from torch import eq as torch_eq


def constant_pad_end(
    data: torch.Tensor, dim: int, length: int, fill_value: float | int | bool
) -> torch.Tensor | None:
    """
    Pad given dim at the end
    If data dim is larger than length, returns None
    """

    if data.shape[dim] < length:
        padding_length = length - data.shape[dim]
        padding_shape = list(data.shape)
        padding_shape[dim] = padding_length
        padd_data = torch.full(
            padding_shape, fill_value, dtype=data.dtype, device=data.device
        )
        return torch.cat((data, padd_data), dim=dim)
    if data.shape[dim] == length:
        return data
    return None


class SITS:
    """
    Base class for SITS data
    """

    def __init__(
        self,
        data: torch.Tensor,
        doy: torch.Tensor,
        mask: None | torch.Tensor = None,
        soft_mask: bool = False,
    ):
        """
        data: measurements
        doy: acquisition times
        mask : Equal to 1 if measurement is missing and 0 otherwise, element-wise
        """
        # Ensure at least one feature dimension
        assert data.dim() > 2
        self.data = data

        if mask is not None:
            # mask has at least 2 dimension
            assert mask.dim() >= 2
            # Two first dimensions of data and mask are the same
            assert mask.shape[:2] == data.shape[:2]

            # Mask should be boolean value or belongs to [0, 1]
            if soft_mask:
                assert (mask.min() >= 0.0) and (mask.max() <= 1.0)
            else:
                assert mask.dtype == torch.bool
        self.mask = mask

        # doy has at least 2 dims
        assert doy.dim() >= 2
        # First dimensions of doy and data should match
        assert doy.shape[:2] == data.shape[:2]

        # Ensure that all tensors are on the same device
        assert doy.device == data.device
        assert mask is None or mask.device == data.device

        self.doy = doy

        self.soft_mask = soft_mask

    def is_masked(self) -> bool:
        """
        True if SITS contain a mask
        """
        return self.mask is not None

    def shape(self) -> torch.Size:
        """
        Get internal shape
        """
        return self.data.shape

    def to(
        self, device: torch.device | None = None, dtype: torch.dtype | None = None
    ) -> Self:
        """
        Move sits to another device
        """
        self.data = self.data.to(device=device, dtype=dtype)

        if self.mask is not None:
            if not self.soft_mask:
                # We do not allow to cast mask dtype,
                # since it should always be of type torch.bool
                self.mask = self.mask.to(device=device)
            else:
                self.mask = self.mask.to(device=device, dtype=dtype)
        self.doy = self.doy.to(device=device, dtype=dtype)

        return self

    def pin_memory(self) -> Self:
        """
        Pin memory
        """
        self.data = self.data.pin_memory()
        self.doy = self.doy.pin_memory()
        if self.mask is not None:
            self.mask = self.mask.pin_memory()

        return self


@dataclass
class TargetDOYStrategy:
    """Params to generate target DOYs"""

    first_day: int
    last_day: int
    step: int


class MultiModalSITS(SITS):
    """
    Class representing a Multimodal SITS
    """

    def __init__(
        self,
        data: torch.Tensor,
        doy: torch.Tensor,
        mask: None | torch.Tensor = None,
        soft_mask: bool = False,
    ):
        """
        data shape : b t c w h
        mask shape : b t c w h
        doy shape : b t c w h
        """
        # Verify MultiModalSITS constraints
        if mask is not None:
            assert mask.shape == data.shape

        assert doy.shape == data.shape
        super().__init__(data, doy, mask, soft_mask)


class MonoModalSITS(SITS):
    """
    Class representing a monomodal SITS
    """

    def __init__(
        self,
        data: torch.Tensor,
        doy: torch.Tensor,
        mask: None | torch.Tensor = None,
        soft_mask: bool = False,
    ):
        """
        data shape : b t c w h
        mask shape : b t w h
        doy shape : b t
        """
        # Verify MonoModalSITS constraints
        if mask is not None:
            assert mask.dim() == data.dim() - 1
            assert mask.shape[2:] == data.shape[3:]
        assert doy.dim() == 2
        super().__init__(data, doy, mask, soft_mask)

    def expand_tensor_for_as_multimodal(
        self,
    ) -> tuple[torch.Tensor, torch.Tensor | None]:
        """
        Expand all dims so as to return a MultiModalSITS instance
        """
        data_shape = parse_shape(self.data, "b t c w h")
        mask: torch.Tensor | None = None
        if self.mask is not None:
            mask = repeat(self.mask, "b t w h -> b t c w h", **data_shape)
        doy = repeat(self.doy, "b t -> b t c w h", **data_shape)

        return (doy, mask)

    def as_multimodal(self) -> MultiModalSITS:
        """
        Expand all dims so as to return a MultiModalSITS instance
        """
        doy, mask = self.expand_tensor_for_as_multimodal()
        return MultiModalSITS(self.data, doy, mask)

    def trim(self) -> Self:
        """
        Trim masked doy for each element in the batch to reduce the doy
        dimension to the maximum number of valid values over the batch.

        Inplace operation

        sorted: boolean value. If True, the SITS is sorted in increased order
                w.r.t. the doy. The sort is done per element
        """
        if self.mask is None:
            return self

        # parse data shape
        data_shape = parse_shape(self.data, "b t c h w")

        # Find which dates are completely masked for some samples in batch dim
        doy_masked = torch_all(
            rearrange(self.mask, "b t h w -> b t (h w)") == 1, dim=-1
        )
        # move those dates at the end of doy dim

        _, ind = torch.sort(doy_masked, dim=-1, descending=False, stable=True)

        # Derive max length from the max number of valid dates
        max_length = int(torch.max(torch.sum(~doy_masked, dim=-1)).item())
        assert max_length > 0, "SITS is fully masked"

        # Rearange data, mask and doy to move invalid dates at the end of doy dim
        trim_data = torch.gather(
            self.data,
            1,
            repeat(
                ind,
                "b t -> b t c w h",
                c=data_shape["c"],
                w=data_shape["w"],
                h=data_shape["h"],
            ),
        )

        trim_mask = torch.gather(
            self.mask,
            1,
            repeat(ind, "b t -> b t w h", w=data_shape["w"], h=data_shape["h"]),
        )

        trim_doy = torch.gather(self.doy, 1, ind)

        # Trim tensors
        self.data = trim_data[:, :max_length, ...]
        self.mask = trim_mask[:, :max_length, ...]
        self.doy = trim_doy[:, :max_length, ...]

        return self

    def sort_doy(self, descending: bool = False, stable: bool = True) -> Self:
        """Sort doy."""
        # parse data shape
        data_shape = parse_shape(self.data, "b t c h w")

        # Sort doy, data and mask
        self.doy, ind = torch.sort(
            self.doy, dim=-1, descending=descending, stable=stable
        )
        self.data = torch.gather(
            self.data,
            1,
            repeat(
                ind,
                "b t -> b t c w h",
                c=data_shape["c"],
                w=data_shape["w"],
                h=data_shape["h"],
            ),
        )
        if self.mask is not None:
            self.mask = torch.gather(
                self.mask,
                1,
                repeat(ind, "b t -> b t w h", w=data_shape["w"], h=data_shape["h"]),
            )

        return self


class SoftMultiModalSITS(MultiModalSITS):
    """
    Class representing a Multimodal SITS with soft mask enforced
    """

    def __init__(
        self,
        data: torch.Tensor,
        doy: torch.Tensor,
        mask: None | torch.Tensor = None,
    ):
        super().__init__(data, doy, mask, True)


class SoftMonoModalSITS(MonoModalSITS):
    """
    Class representing a Multimodal SITS with soft mask enforced
    """

    def __init__(
        self,
        data: torch.Tensor,
        doy: torch.Tensor,
        mask: None | torch.Tensor = None,
    ):
        super().__init__(data, doy, mask, True)

    def as_multimodal(self) -> SoftMultiModalSITS:
        """
        Expand all dims so as to return a MultiModalSITS instance
        """
        doy, mask = self.expand_tensor_for_as_multimodal()
        return SoftMultiModalSITS(self.data, doy, mask)


class HardMultiModalSITS(MultiModalSITS):
    """
    Class representing a Multimodal SITS with soft mask enforced
    """

    def __init__(
        self,
        data: torch.Tensor,
        doy: torch.Tensor,
        mask: None | torch.Tensor = None,
    ):
        super().__init__(data, doy, mask, False)


class HardMonoModalSITS(MonoModalSITS):
    """
    Class representing a Multimodal SITS with soft mask enforced
    """

    def __init__(
        self,
        data: torch.Tensor,
        doy: torch.Tensor,
        mask: None | torch.Tensor = None,
    ):
        super().__init__(data, doy, mask, False)

    def as_multimodal(self) -> HardMultiModalSITS:
        """
        Expand all dims so as to return a MultiModalSITS instance
        """
        doy, mask = self.expand_tensor_for_as_multimodal()
        return HardMultiModalSITS(self.data, doy, mask)


MonoTVar = TypeVar("MonoTVar", MonoModalSITS, HardMonoModalSITS, SoftMonoModalSITS)
MultiTVar = TypeVar("MultiTVar", MultiModalSITS, HardMultiModalSITS, SoftMultiModalSITS)


def pad_acquisition_time(
    sits: SITS, doy_length: int, fill_value: float = 0.0
) -> SITS | None:
    """
    Increase the size of the time_dimension to doy_length for
    all tensors in the SITS

    If the length of the time dimension is greater than doy_length, returns None
    """
    padded_data = constant_pad_end(sits.data, 1, doy_length, fill_value)
    padded_doy = constant_pad_end(sits.doy, 1, doy_length, fill_value)
    if padded_data is None or padded_doy is None:
        return None

    padded_mask: torch.Tensor | None = None
    if sits.mask is not None:
        # torch.full will cast 1 to appropriate mask.dtype
        padded_mask = constant_pad_end(sits.mask, 1, doy_length, 1)
        if padded_mask is None:
            return None
    # Return object of same class
    sits_type = type(sits)
    return sits_type(padded_data, padded_doy, padded_mask)


def cat_monomodal_sits(sits: list[MonoTVar]) -> MonoTVar:
    """
    Concatenate monodal sits along the channel dimension
    All doy and mask tensor must match exactly
    """
    # Preconditions
    # at least one element
    assert sits

    # All shape matches except in channel dimension
    # Either all sits are masked or none of them are
    data_shape = parse_shape(sits[0].data, "b t c w h")

    mask = sits[0].mask
    doy = sits[0].doy

    for s in sits:  # FIXME: We could start from 1 -> sits[1:]
        current_data_shape = parse_shape(s.data, "b t c w h")
        for key in ("b", "t", "w", "h"):
            assert (
                current_data_shape[key] == data_shape[key]
            ), f"Data shape mismatch for dimension {key} ({current_data_shape[key]} !=\
            {data_shape[key]}"

        if mask is None:
            assert s.mask is None
        else:
            assert s.mask is not None
            assert s.mask.dtype == mask.dtype
            assert torch_all(
                torch_eq(doy, s.doy)
            ), "Doy should be the same for all input sits"
    if mask is not None:
        mask = reduce(
            pack([s.mask for s in sits], "b t * w h")[0], "b t s h w -> b t h w", "max"
        )
    sits_type = type(sits[0])
    return sits_type(pack([s.data for s in sits], "b t * h w")[0], doy, mask)


def cat_multimodal_sits(sits: list[MultiTVar]) -> MultiTVar:
    """
    A free function that concatenates multi-modal sits along the feature dimension
    All remaining dimensions should match
    """
    # Precoditions:
    # At least one element
    assert sits
    # All shape matches except in channel dimension
    # Either all sits are masked or none of them are
    data_shape = parse_shape(sits[0].data, "b t c w h")
    mask: torch.Tensor | None = sits[0].mask
    for s in sits:  # FIXME: We could start from 1 -> sits[1:]
        current_data_shape = parse_shape(s.data, "b t c w h")
        current_doy_shape = parse_shape(s.doy, "b t c w h")
        current_mask_shape: dict[str, int] | None = None
        if mask is None:
            assert s.mask is None
        else:
            assert s.mask is not None
            assert s.mask.dtype == mask.dtype
            current_mask_shape = parse_shape(s.mask, "b t c w h")

        for key in ("b", "t", "w", "h"):
            assert (
                current_data_shape[key] == data_shape[key]
            ), f"Data shape mismatch for dimension {key} ({current_data_shape[key]} !=\
            {data_shape[key]}"
            assert (
                current_data_shape[key] == current_doy_shape[key]
            ), f"Doy shape mismatch for dimension {key} ({current_doy_shape[key]} !=\
            {data_shape[key]}"
            if current_mask_shape is not None:
                assert (
                    current_mask_shape[key] == data_shape[key]
                ), f"Mask shape mismatch for dimension {key} ({current_mask_shape[key]}\
                != {data_shape[key]}"

    # Concatenate data and doy
    data = pack([s.data for s in sits], "b t * h w")[0]
    doy = pack([s.doy for s in sits], "b t * h w")[0]

    # Optionally concatenate masks
    # If first mask is not null
    if mask is not None:
        # Then assert that all masks are not null
        mask = pack([s.mask for s in sits], "b t * h w")[0]

    sits_type = type(sits[0])
    return sits_type(data, doy, mask)


def guess_pack_shape(sits: MultiModalSITS) -> list[Shape]:
    """
    Free function that guesses the pack shape of the MultiModalSITS.

    It is based on the fact that MonoModalSITS has constant mask values
    along the channel dimension
    """
    number_of_channels = sits.data.shape[2]
    ps: list[Shape] = []

    if sits.mask is not None:
        idx_start = 0
        idx_end = idx_start + 1
        # Guess the MonoModalSITS shape based on mask
        while idx_end < number_of_channels:
            while torch_eq(
                sits.mask[:, :, idx_start:idx_end, :, :],
                sits.mask[:, :, idx_start, :, :].unsqueeze(2),
            ).all():
                idx_end += 1
                if idx_end >= number_of_channels:
                    break
            else:  # Executed only if the second while loop is not broken
                idx_end -= 1
            # Update ps list
            lenght = idx_end - idx_start
            if idx_start == 0:
                ps = [(lenght,)]
            else:
                ps.append((lenght,))
            # Update idx
            idx_start = idx_end
            idx_end = idx_start + 1
    else:
        ps = [(number_of_channels,)]

    return ps


def uncat_multimodal_sits(sits: MultiTVar) -> list[MonoTVar]:
    """
    Free function to uncat a MultiModalSITS created from a list of MonoModalSITS.
    """
    pack_shape: list[Shape] = guess_pack_shape(sits)
    # Split data according to the pack shape information
    list_of_data: list[torch.Tensor] = unpack(sits.data, pack_shape, "b t * h w")

    # Split mask and reduce size to match MonoModalSITS constraints
    list_of_mask: list[torch.Tensor] | list[None] = [None] * len(pack_shape)
    if sits.mask is not None:
        list_of_mask = unpack(sits.mask, pack_shape, "b t * h w")
        list_of_mask = [mask[:, :, 0, :, :] for mask in list_of_mask]

    # Split doy and reduce size to match MonoModalSITS constraints
    list_of_doy: list[torch.Tensor] = unpack(sits.doy, pack_shape, "b t * h w")
    list_of_doy = [doy[:, :, 0, 0, 0] for doy in list_of_doy]

    # Create list of corresponding MonoSits
    instance: (
        type[MonoModalSITS] | type[HardMonoModalSITS] | type[SoftMonoModalSITS]
    ) = MonoModalSITS

    match sits:
        case SoftMultiModalSITS():
            instance = SoftMonoModalSITS
        case HardMultiModalSITS():
            instance = HardMonoModalSITS
        case _:
            pass

    list_monomodal_sits: list[MonoTVar] = [
        cast(MonoTVar, instance(data=data, mask=mask, doy=doy))
        for data, mask, doy in zip(list_of_data, list_of_mask, list_of_doy)
    ]

    # Trim each SITS
    for monomodal_sits in list_monomodal_sits:
        monomodal_sits.trim().sort_doy()

    return list_monomodal_sits


def subset_doy_monomodal_sits(
    sits: MonoTVar,
    target_doy: torch.Tensor | None = None,
    fill_value: float | bool | int = 0,
) -> MonoTVar:
    """
    This function uses target_doy as the new set of doy for every batch in sits
    If acquisition is not available in sits, it is masked and filled with fill_value

    if target_doy is None, the union set of all doy in sits is used.
    """
    # variable to hold non-optional target_doy
    nopt_target_doy: torch.Tensor

    if target_doy is None:
        # find intersection of all doy
        nopt_target_doy = torch.unique(sits.doy)
    else:
        nopt_target_doy = target_doy
    if nopt_target_doy.dim() == 1:
        nopt_target_doy = repeat(nopt_target_doy, "t -> b t", b=sits.shape()[0])
    assert nopt_target_doy.dim() == 2
    assert nopt_target_doy.shape[0] == sits.doy.shape[0]

    # Store shape of input data
    data_shape = parse_shape(sits.data, "b t c w h")

    # Build ouptut data shape (with new size for dimension t, and all
    # other dimensions collapsed)
    out_data = torch.full(
        (
            data_shape["c"] * data_shape["w"] * data_shape["h"],
            data_shape["b"],
            nopt_target_doy.shape[1],
        ),
        fill_value,
        dtype=sits.data.dtype,
        device=sits.data.device,
    )

    # Also build output mask shape
    out_mask = torch.full(
        (
            data_shape["w"] * data_shape["h"],
            data_shape["b"],
            nopt_target_doy.shape[1],
        ),
        1,  # torch.full will cast 1 to appropriate mask.dtype
        dtype=sits.mask.dtype if sits.mask is not None else torch.bool,
        device=sits.data.device,
    )

    # Rearrange input doy into (b c w h) t 1 in preparation for torch.where call
    in_doy = repeat(sits.doy, "b t -> b t 1 1")

    # Rearrange target_doy into (1 1 t) in preparation for torch.where call
    nopt_target_doy = rearrange(nopt_target_doy, "b t -> 1 1 b t")
    # Use torch.where to find matching indices in all 3 dimensions
    cross_matrix = in_doy == nopt_target_doy

    # Forbid cross-batch attention
    for b1 in range(in_doy.shape[0]):
        for b2 in range(nopt_target_doy.shape[2]):
            if b1 != b2:
                cross_matrix[b1, :, b2, :] = False

    idx = torch.where(cross_matrix)
    # Copy sits.data to the correct location in out_data

    out_data[:, idx[2], idx[3]] = rearrange(sits.data, "b t c w h -> (c w h) b t")[
        :, idx[0], idx[1]
    ]
    # Rearrange out_data into final shape
    out_data = rearrange(
        out_data,
        "(c w h) b t -> b t c w h",
        b=data_shape["b"],
        c=data_shape["c"],
        w=data_shape["w"],
        h=data_shape["h"],
    )

    # Now rearrange in_doy the same way to process mask (no c dimension)
    del data_shape["c"]  # We do not need c anymore

    # Either we fill with available mask
    if sits.mask is not None:
        out_mask[:, idx[2], idx[3]] = rearrange(sits.mask, "b t h w -> (h w) b t")[
            :, idx[0], idx[1]
        ]
    else:
        # Or we fill with unmasked value if no mask is available in input series
        out_mask[:, idx[2], idx[3]] = False

    # Rearrange mask to final shape
    out_mask = rearrange(
        out_mask,
        "(w h) b t -> b t w h",
        b=data_shape["b"],
        w=data_shape["w"],
        h=data_shape["h"],
    )
    nopt_target_doy = rearrange(nopt_target_doy, "1 1 b t -> b t")
    sits_type = type(sits)

    return sits_type(out_data, nopt_target_doy, out_mask)


def merge_monomodal_sits(
    sits: list[MonoModalSITS],
    target_doy: torch.Tensor | None = None,
    fill_value: float | bool | int = 0,
    sort_doy: bool = True,
) -> MultiModalSITS:
    """
    Merge a list of monomodal sits into multimodal sits.

    This is different from cat_multimodal_sits, because mono_modal
    sits are first aligned to target_doy, meaning acquisition from
    sits occuring on the same date will be in the same doy column.

    If target_doy is None, the union set of all doy from all sits will be used.

    """
    # variable holding non optional target_doy
    nopt_target_doy: torch.Tensor

    if target_doy is None:
        # find intersection of all doy
        nopt_target_doy = torch.unique(torch.cat([s.doy.flatten() for s in sits]))
    else:
        assert target_doy.dim() == 1
        nopt_target_doy = target_doy
    if sort_doy:
        nopt_target_doy, _ = torch.sort(nopt_target_doy)

    # Align all sits on target_doy
    aligned_sits = [
        subset_doy_monomodal_sits(s, target_doy=nopt_target_doy, fill_value=fill_value)
        for s in sits
    ]

    # Expand to multimodal sits
    aligned_multimodal_sits = [s.as_multimodal() for s in aligned_sits]

    return cat_multimodal_sits(aligned_multimodal_sits)


def sits_where(sits1: MonoTVar, sits2: MonoTVar) -> MonoTVar:
    """
    sits1 or sits2 where sits1 is masked and not sits2
    """
    # If there is no mask in sits1, return sits1 itself
    if sits1.mask is None:
        return sits1

    assert sits1.data.shape == sits2.data.shape

    # Build where mask
    where_mask = sits1.mask

    # If there is a mask in sits2, use it
    if sits2.mask is not None:
        # Zeros are treated as False and nonzeros are treated as True
        where_mask = torch.logical_and(where_mask, ~sits2.mask)

    out_mask = None
    if sits2.mask is not None:
        out_mask = torch.logical_and(sits1.mask, sits2.mask)

    where_mask = repeat(where_mask, "b t w h -> b t c w h", c=sits1.data.shape[2])

    out_data = torch.where(where_mask, sits2.data, sits1.data)
    sits_type = type(sits1)

    return sits_type(out_data, sits1.doy, out_mask)
