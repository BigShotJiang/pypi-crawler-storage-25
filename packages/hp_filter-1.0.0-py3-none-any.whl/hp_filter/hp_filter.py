#!/usr/bin/env python

# Copyright: (c) 2023 CESBIO / Centre National d'Etudes Spatiales
"""
HP Filter with autograd facility for the regularization parameter
"""

import math
from collections.abc import Sequence
from dataclasses import dataclass
from typing import cast

import torch
from einops import parse_shape, rearrange, repeat
from torch import diagonal_scatter as torch_diagonal_scatter
from torch import matmul as torch_matmul
from torch import nn
from torch import zeros as torch_zeros
from torch.distributions.normal import Normal

from hp_filter.banded_linear_solver import (
    BandedLinearSolver,
    cholesky_solver,
    compute_regularization_matrix,
)
from hp_filter.regularizer import (
    BaseRegularizer,
    FourrierFunctionRegularizer,
    PolynomialFunctionRegularizer,
    ScalarRegularizer,
    TransformerRegularizer,
)
from hp_filter.time_series import MonoTVar

# TODO: the logic of solve linear then reshape is fuzzy:
#       the output dim of solve linear is not the same than the input.


def compute_derivative_matrix(doy: torch.Tensor, order: int) -> torch.Tensor:
    """
    Free function to compute the derivative matrix.

    Work for irregular doys using finite difference.

    Computation is done in torch.float64 then cast to original dtype
    """
    n_doys = doy.shape[0]
    derivative_matrix = torch.eye(
        n_doys,
        device=doy.device,
        dtype=doy.dtype,
    )
    for time_index in range(1, order + 1):
        inv_time_delta = 1.0 / (doy[time_index:n_doys] - doy[: n_doys - time_index])
        delta = torch_zeros(
            (
                n_doys - time_index,
                n_doys - time_index + 1,
            ),
            device=doy.device,
            dtype=doy.dtype,
        )
        delta = torch_diagonal_scatter(delta, -inv_time_delta)
        delta = torch_diagonal_scatter(delta, inv_time_delta, offset=1)
        derivative_matrix = torch_matmul(delta, derivative_matrix)

    return cast(torch.Tensor, derivative_matrix)


@dataclass
class HPFilterConfig:
    """Configuration for HPFilter module."""

    reference_doy: Sequence[float]  # The reference time-steps
    regularizer: BaseRegularizer  # Regularizer used for smoothness
    order: int = 2  # Order of the derivative to compute the regul. term
    dtype: torch.dtype = torch.float32
    compute_var: bool = False
    credible_interval: float = 0.05

    def __post_init__(self) -> None:
        """Check consistency."""
        # Checks reference_doys: sorted and duplicate
        if isinstance(self.reference_doy, torch.Tensor):
            assert (
                self.reference_doy[1:] > self.reference_doy[:-1]
            ).all(), "reference_doys must be in increasing order with no duplicate"
        elif isinstance(self.reference_doy, list):
            assert (
                self.reference_doy[1:] > self.reference_doy[:-1]
            ), "reference_doys must be in increasing order with no duplicate"

        # Check functional regul parameter
        assert self.order >= 1

        # Check dtype
        assert self.dtype in (torch.bfloat16, torch.float32, torch.float64)

        # Check credible interval
        assert (self.credible_interval >= 0) and (self.credible_interval <= 1)


class HPFilter(nn.Module):
    """Class implementing the HP Filter."""

    def __init__(self, config: HPFilterConfig):
        super().__init__()

        # Convert squence of float to Tensor
        self.dtype = config.dtype
        self.reference_doy = nn.Parameter(
            torch.Tensor(config.reference_doy).to(dtype=self.dtype),
            requires_grad=False,
        )
        self.order = config.order

        # Initialization of the regularization parameter/function
        self.regularizer = config.regularizer

        # Use credible interval
        self.compute_var = config.compute_var
        self.credible_interval = config.credible_interval

    def prepare_data(
        self, sits: MonoTVar
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, dict[str, int]]:
        """Reformat data in the forward pass."""
        # Get data and complement/cast mask (0: nodata, 1: data)
        shapes: dict[str, int] = parse_shape(sits.data, "b t c h w")
        data: torch.Tensor = sits.data.to(dtype=self.dtype)
        mask: torch.Tensor
        if sits.mask is not None:
            mask = 1 - sits.mask.to(dtype=self.dtype)
        else:
            mask = torch.ones(
                shapes["b"],
                shapes["t"],
                shapes["h"],
                shapes["w"],
                dtype=self.dtype,
                device=data.device,
            )

        doy: torch.Tensor = sits.doy.to(dtype=self.dtype)
        del shapes["t"]

        return data, mask, doy, shapes

    def forward(self, sits: MonoTVar) -> MonoTVar | tuple[MonoTVar, MonoTVar]:
        """Forward pass.

        Assume MonoTVar
        data shape : b t c w h
        mask shape : b t w h
        doy shape : b t
        """
        # Prepare data
        data, mask, doy, shapes = self.prepare_data(sits)

        # Create union of dates
        union_of_doys = torch.unique(
            torch.cat(
                [
                    self.reference_doy.to(torch.short),
                    torch.unique(doy.flatten().to(torch.short)),
                ]
            ),
            sorted=True,
        ).to(self.dtype)
        shapes["tu"] = union_of_doys.shape[0]

        # Get indices to recover batch doys and referenced doys
        idx_in, idx_out = self.get_time_indices(doy, union_of_doys)

        # Construct augmented batch - Now data & mask are augmented
        data = self.get_augmented_batch(data, idx_in, shapes)
        mask = self.get_augmented_batch(mask, idx_in, shapes)

        # Construct derivative matrix
        derivative_matrix = compute_derivative_matrix(union_of_doys, order=self.order)

        # Solve linear problem
        alpha = self.compute_regularizer(union_of_doys, data, mask)
        alpha = (
            alpha * shapes["tu"] / math.factorial(self.order - 1)
        )  # Normalisation w.r.t. the number interpolated dates and order

        data_interpolated = self.solve_linear_system(
            data, mask, derivative_matrix, alpha
        )

        # Reshape data and recover values at reference_doys
        data_interpolated, doy_interpolated = self.reshape_interpolated_data(
            data_interpolated, idx_out, shapes
        )

        # Build MonoTVar object from interpolated values
        output_sits = type(sits)(
            data=data_interpolated,
            doy=doy_interpolated,
            mask=None,
        )

        # Compute credible interval if required
        # Here all computation are done in torch.float64
        # Then cast to original dtype
        if self.compute_var:
            P = repeat(
                torch.eye(shapes["tu"], dtype=torch.float64, device=mask.device),
                "u v -> (b h w) u v",
                b=shapes["b"],
                h=shapes["h"],
                w=shapes["w"],
            )

            var_interpolated = cholesky_solver(
                compute_regularization_matrix(
                    alpha,
                    derivative_matrix,
                ).to(torch.float64),
                rearrange(mask.to(torch.float64), "b tu h w -> (b h w) tu"),
                P,
                self.order,
            )

            var_interpolated = torch.diagonal(var_interpolated, dim1=-1, dim2=-2)[
                ..., None
            ]
            var_interpolated, _ = self.reshape_interpolated_data(
                var_interpolated, idx_out, shapes
            )
            var_interpolated = Normal(
                torch.tensor([0.0], device=mask.device),
                torch.tensor([1.0], device=mask.device),
            ).icdf(
                torch.tensor([1 - self.credible_interval / 2], device=mask.device)
            ) * torch.sqrt(
                var_interpolated
            )

            return output_sits, type(sits)(
                data=var_interpolated.to(self.dtype),
                doy=doy_interpolated,
                mask=None,
            )

        return output_sits

    def get_time_indices(
        self, doys: torch.Tensor, union_of_doys: torch.Tensor
    ) -> tuple[tuple[torch.Tensor, ...], tuple[torch.Tensor, ...]]:
        """Get the indices of common doys.

        Compute from batch and references_doys for the extended time series.
        It is assumed MonoTVar
        """
        # Get indices from reference_doys and doys in union_of_doys
        idx_in = torch.nonzero(
            rearrange(doys, "b t -> b t 1") == rearrange(union_of_doys, "t -> 1 1 t"),
            as_tuple=True,
        )
        idx_out = torch.nonzero(
            rearrange(self.reference_doy, "T -> T 1")
            == rearrange(union_of_doys, "T -> 1 T"),
            as_tuple=True,
        )

        return (idx_in, idx_out)

    def get_augmented_batch(
        self, batch: torch.Tensor, idx: tuple[torch.Tensor, ...], shapes: dict
    ) -> torch.Tensor:
        """Build the augmented batch.

        It is assumes that the mask is the same for all channels for one time.
        """
        if batch.ndim == 5:  # data
            augmented_batch = torch_zeros(
                shapes["b"],
                shapes["tu"],
                shapes["c"],
                shapes["h"],
                shapes["w"],
                device=batch.device,
                dtype=self.dtype,
            )
            augmented_batch[idx[0], idx[2], :, :, :] = batch[idx[0], idx[1], :, :, :]
        elif batch.ndim == 4:  # mask
            augmented_batch = torch_zeros(
                shapes["b"],
                shapes["tu"],
                shapes["h"],
                shapes["w"],
                device=batch.device,
                dtype=self.dtype,
            )
            augmented_batch[idx[0], idx[2], :, :] = batch[idx[0], idx[1], :, :]

        return augmented_batch

    def solve_linear_system(
        self,
        data: torch.Tensor,
        mask: torch.Tensor,
        derivative_matrix: torch.Tensor,
        alpha: torch.Tensor,
    ) -> torch.Tensor:
        """Solve the banded linear systems using BandedLinearSolver."""
        data_interpolated = BandedLinearSolver.apply(
            alpha,
            derivative_matrix,
            rearrange(mask, "b tu h w -> (b h w) tu"),
            rearrange(data, "b tu c h w -> (b h w) tu c"),
            self.order,
        )
        return data_interpolated

    def reshape_interpolated_data(
        self,
        data_interpolated: torch.Tensor,
        idx_out: tuple[torch.Tensor, ...],
        shapes: dict,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """Reshape interpolated data and keep only the references_doys."""
        data_interpolated_reshape = rearrange(
            data_interpolated[:, idx_out[1], :],
            "(b h w) ti c -> b ti c h w",
            b=shapes["b"],
            h=shapes["h"],
            w=shapes["w"],
        )

        doys_interpolated = repeat(self.reference_doy, "ti -> b ti", b=shapes["b"])
        return (data_interpolated_reshape, doys_interpolated)

    def update_reference_doy(self, new_reference_doy: torch.Tensor) -> None:
        """Update reference_doys."""
        assert isinstance(
            new_reference_doy, torch.Tensor
        ), "new_reference_doy should be a torch.Tensor"
        self.reference_doy = nn.Parameter(
            new_reference_doy.to(
                dtype=self.dtype,
                device=self.reference_doy.device,
            ),
            requires_grad=False,
        )

    def compute_regularizer(
        self,
        doy: torch.Tensor,
        data: torch.Tensor | None = None,
        mask: torch.Tensor | None = None,
    ) -> torch.Tensor:
        """Compute the regularizer values: scalar or diagonal matrix."""
        shapes = parse_shape(data, "b t c h w")
        doy = doy.to(self.dtype)

        match self.regularizer:
            case ScalarRegularizer():
                alpha = self.regularizer(doy)
            case PolynomialFunctionRegularizer() | FourrierFunctionRegularizer():
                alpha = self.regularizer(doy[: -self.order])
            case TransformerRegularizer():
                assert (data is not None) and (mask is not None)
                data = data.to(self.dtype)
                mask = (  # For the transformer mask=0 we keep the data, need to inverse the current mask
                    mask.to(torch.bool)
                    if mask is not None
                    else torch.ones(
                        (shapes["b"], shapes["t"], shapes["h"], shapes["w"]),
                        dtype=self.dtype,
                        device=data.device,
                    )
                )
                mask = torch.logical_not(mask)
                data = rearrange(
                    data[:, : -self.order, ...],
                    "b tu c h w -> (b h w) tu c",
                )
                mask = rearrange(
                    mask[:, : -self.order, ...],
                    "b tu h w -> (b h w) tu",
                )
                doy = repeat(doy[: -self.order], "t -> b t 1", b=data.shape[0])
                alpha = self.regularizer(doy, data, mask)
                alpha = rearrange(alpha, "b t 1 -> b t")
            case _:
                raise NotImplementedError
        return alpha
