"""API 请求封装"""
import json as json_mod
from urllib.parse import quote

import requests
from typing import Optional

from .auth import get_auth_cookies, get_auth_headers
from .config import config

# BUG「缺陷类型」自定义字段 ID（与缺陷列表页 issue_field_value/.../option 抓包一致；若项目模板不同请改用 CLI --field-id）
BUG_DEFECT_TYPE_FIELD_ID = "f672b38532614f428828d9a68a514e24"

# BUG「发现阶段」自定义字段 ID（与缺陷表 issue_field_value/.../option 抓包及 create_bug 一致；若项目模板不同请改用 CLI --field-id）
BUG_DISCOVERY_PHASE_FIELD_ID = "bcee87c140d3475496a2a31c236631f4"

# BUG「解决方法」自定义字段 ID（与缺陷表 twBug issue_field_value/.../option 抓包及 create_bug 一致；若项目模板不同请改用 CLI --field-id）
BUG_SOLUTION_METHOD_FIELD_ID = "8756c5b483434c2bb54bd6bc6586b09b"

# BUG 工作流「下一节点」ID（与 DevOps 页面抓包一致；若项目工作流不同请改此表）
BUG_DIRECTION_NEXT_NODE_IDS = {
    "accept": "ba66e60c5fd843a8b8fd00ed005eef66",  # 接受
    "resolved": "c66f5b9f84254b4298ff93c859033275",  # 已解决
    "verified": "790befe6321d4f0da588f91f456907ef",  # 已验证
    "close": "d9135ab19a6345a1b04d6358485fd23b",  # 关闭
    "reopen": "17767cf5fb9f4c75a5d2fa7a45343c93",  # 重新打开
    "reject": "08c79f18f6d44a22aae48a3ab14e4d19",  # 拒绝
}


class DevOpsAPI:
    """DevOps API 客户端"""

    def __init__(self, project_id: str):
        self.project_id = project_id
        self.base_url = config.BASE_URL

    def _request(self, method: str, path: str, **kwargs) -> dict:
        """发送 API 请求"""
        cookies = get_auth_cookies()
        headers = get_auth_headers(cookies, self.project_id)

        url = f"{self.base_url}/{path}"

        # 处理 data 参数
        if "data" in kwargs:
            kwargs["json"] = kwargs.pop("data")

        # #############################################
        # # 打印 curl 命令
        # curl_parts = [f"curl -X {method}"]
        # for k, v in headers.items():
        #     curl_parts.append(f"-H '{k}: {v}'")
        # if "json" in kwargs:
        #     curl_parts.append(f"-d '{json_mod.dumps(kwargs['json'], ensure_ascii=False)}'")
        # curl_parts.append(f"'{url}'")
        # print(" ".join(curl_parts))
        # #############################################

        response = requests.request(
            method=method,
            url=url,
            headers=headers,
            cookies=cookies,
            **kwargs
        )

        if response.status_code >= 400:
            raise Exception(f"API 错误: {response.status_code} {response.text}")

        text = (response.text or "").strip()
        if not text:
            return {}
        return response.json()

    # ========== 迭代操作 ==========

    def create_sprint(
            self,
            title: str,
            start_date: str,
            end_date: str,
            purpose: str = "",
            test_start_date: Optional[str] = None,
            test_end_date: Optional[str] = None,
            development_pic: str = "",
            test_pic: str = "",
            acceptance_pic: str = "",
    ) -> dict:
        """创建迭代"""
        data = {
            "title": title,
            "startDate": start_date,
            "endDate": end_date,
            "purpose": purpose,
            "daterange": [f"{start_date}T16:00:00.000Z", f"{end_date}T16:00:00.000Z"],
            "reviewTime": "",
            "testStartDate": test_start_date or start_date,
            "testEndDate": test_end_date or end_date,
            "developmentPic": development_pic,
            "testPic": test_pic,
            "acceptancePic": acceptance_pic,
            "excludeTime": "",
            "state": "ACTIVE",
        }
        return self._request("POST", f"/ms/vteam/api/user/issue_sprint/{self.project_id}", data=data)

    def start_sprint(self, sprint_data: dict) -> dict:
        """启用迭代"""
        return self._request("PUT", f"/ms/vteam/api/user/issue_sprint/{self.project_id}/start", data=sprint_data)

    def delete_sprint(self, sprint_id: str) -> dict:
        """删除迭代"""
        return self._request("DELETE", f"/ms/vteam/api/user/issue_sprint/{self.project_id}/{sprint_id}")

    def done_sprint(self, sprint_id: str) -> dict:
        """完成迭代"""
        return self._request("PUT", f"/ms/vteam/api/user/issue_sprint/{self.project_id}/complete/{sprint_id}")

    def list_sprints(self) -> dict:
        """查询迭代列表"""
        return self._request("GET",
                             f"/ms/vteam/api/user/issue_sprint/{self.project_id}/flat?num=1&count=1&size=20&content=&start_time=&end_time=&state=ACTIVE%2CNOT_STARTED&sort_field=CREATED_TIME&sort_rule=DESC")

    def list_sprint_tests(
            self,
            num: int = 1,
            size: int = 20,
            search: str = "",
            result: Optional[list] = None,
            create_user: Optional[list] = None,
            create_time: Optional[list] = None,
            principal: Optional[list] = None,
            obj_id: Optional[list] = None,
    ) -> dict:
        """查询迭代提测列表"""
        data = {
            "result": result or [],
            "createUser": create_user or [],
            "createTime": create_time or [],
            "principal": principal or [],
            "objId": obj_id or [],
            "search": search,
        }
        return self._request(
            "POST",
            f"/ms/vteam/api/user/test/{self.project_id}/all?num={num}&size={size}",
            data=data,
        )

    def list_projects(self) -> dict:
        """查询项目列表"""
        return self._request("GET",
                             f"/ms/projectmanager/api/user/project/cw/selectByType?showTree=false&haveUser=false")

    def list_zteam_projects(self) -> dict:
        """查询 ZTeam 项目列表（任务字段选项）"""
        return self._request(
            "GET",
            f"/ms/vteam/api/user/issue_field_value/{self.project_id}/option/5abdcb4c783e11edbef4fa819a160800?all=false&classify=TASK",
        )

    def list_bug_state_options(self, all_options: bool = True) -> dict:
        """查询缺陷（BUG）状态字段可选项"""
        all_param = "true" if all_options else "false"
        return self._request(
            "GET",
            f"/ms/vteam/api/user/issue_field_value/{self.project_id}/option/state?all={all_param}&classify=BUG",
        )

    def list_issue_field_value_options(
        self,
        field_id: str,
        classify: str,
        all_options: bool = False,
    ) -> dict:
        """查询某工作项类型下指定自定义字段的下拉可选项（含优先级、严重程度等）。"""
        all_param = "true" if all_options else "false"
        cls = quote(str(classify).strip(), safe="")
        fid = quote(str(field_id).strip(), safe="")
        return self._request(
            "GET",
            f"/ms/vteam/api/user/issue_field_value/{self.project_id}/option/{fid}?all={all_param}&classify={cls}",
        )

    def list_bug_defect_type_options(
            self,
            all_options: bool = False,
            field_id: Optional[str] = None,
    ) -> dict:
        """查询 BUG「缺陷类型」字段下拉可选项（GET issue_field_value/.../option/<fieldId>?classify=BUG）。"""
        fid = (field_id or BUG_DEFECT_TYPE_FIELD_ID).strip()
        return self.list_issue_field_value_options(
            field_id=fid,
            classify="BUG",
            all_options=all_options,
        )

    def list_bug_discovery_phase_options(
            self,
            all_options: bool = False,
            field_id: Optional[str] = None,
    ) -> dict:
        """查询 BUG「发现阶段」字段下拉可选项（GET issue_field_value/.../option/<fieldId>?classify=BUG）。"""
        fid = (field_id or BUG_DISCOVERY_PHASE_FIELD_ID).strip()
        return self.list_issue_field_value_options(
            field_id=fid,
            classify="BUG",
            all_options=all_options,
        )

    def list_bug_solution_method_options(
            self,
            all_options: bool = False,
            field_id: Optional[str] = None,
    ) -> dict:
        """查询 BUG「解决方法」字段下拉可选项（GET issue_field_value/.../option/<fieldId>?classify=BUG）。"""
        fid = (field_id or BUG_SOLUTION_METHOD_FIELD_ID).strip()
        return self.list_issue_field_value_options(
            field_id=fid,
            classify="BUG",
            all_options=all_options,
        )

    # ========== 任务操作 ==========

    def create_task(
            self,
            title: str,
            model_type_id: str,
            priority: str = "CENTRAL",
            editor_type: str = "MARKDOWN",
            desc: str = "",
            parent_id: str = "",
            demand_classify: str = "-1",
            instance_values: Optional[list] = None,
    ) -> dict:
        """创建 TASK 任务"""
        data = {
            "title": title,
            "modelTypeId": model_type_id,
            "priority": priority,
            "editorType": editor_type,
            "desc": desc,
            "parentId": parent_id,
            "relationIssue": {},
            "demandClassify": demand_classify,
            "fileVO": [],
            "labelId": [],
            "instanceValue": instance_values or [],
        }
        return self._request("POST", f"/ms/vteam/api/user/issue/{self.project_id}", data=data)

    def create_bug(
            self,
            title: str,
            model_type_id: str,
            priority: str = "CENTRAL",
            editor_type: str = "RICHTEXT",
            desc: str = "",
            parent_id: str = "",
            demand_classify: str = "-1",
            instance_values: Optional[list] = None,
    ) -> dict:
        """创建 BUG 缺陷"""
        data = {
            "title": title,
            "modelTypeId": model_type_id,
            "priority": priority,
            "editorType": editor_type,
            "desc": desc,
            "parentId": parent_id,
            "relationIssue": {},
            "demandClassify": demand_classify,
            "fileVO": [],
            "labelId": [],
            "instanceValue": instance_values or [],
        }
        return self._request("POST", f"/ms/vteam/api/user/issue/{self.project_id}", data=data)

    def list_tasks(
            self,
            creator: Optional[str] = None,
            start_date: Optional[str] = None,
            end_date: Optional[str] = None,
            num: int = 1,
            size: int = 20,
            remember: bool = False,
    ) -> dict:
        """按条件查询 TASK 列表"""

        data = [ {"name": "exclude", "value": []}]

        if creator:
            data.insert(0, {"name": "createUser", "value": [creator]})
        if start_date and end_date:
            data.insert(0, {"name": "estimate_start_time", "value": [start_date, end_date]})
            data.insert(0, {"name": "estimate_end_time", "value": [start_date, end_date]})
        remember_value = str(remember).lower()
        return self._request(
            "POST",
            f"/ms/vteam/api/user/issue/{self.project_id}/table/TASK?num={num}&size={size}&remember={remember_value}",
            data=data,
        )

    def list_bugs(
            self,
            num: int = 1,
            size: int = 20,
            remember: bool = False,
            operator_user: Optional[list] = None,
            z_team_project_name: Optional[list] = None,
            defect_owner_field: str = "F0dvVdNHpJ",
            defect_owner: Optional[list] = None,
            state: Optional[list] = None,
            create_user: Optional[list] = None,
            create_time: Optional[list] = None,
    ) -> dict:
        """查询 BUG 列表（缺陷）。

        请求体字段与 DevOps 表格筛选一致：operator_user（经办人）、z_team_project_name（ZTeam 项目）、
        defect_owner_field + defect_owner（责任人自定义字段）、state、createUser、createTime（起止各一项日期字符串）。
        """
        remember_value = str(remember).lower()
        data: list = []

        if operator_user:
            data.append({"name": "operator_user", "value": list(operator_user)})
        if z_team_project_name:
            data.append({"name": "z_team_project_name", "value": list(z_team_project_name)})
        if defect_owner:
            field_key = defect_owner_field or "F0dvVdNHpJ"
            data.append({"name": field_key, "value": list(defect_owner)})
        if state:
            data.append({"name": "state", "value": list(state)})
        if create_user:
            data.append({"name": "createUser", "value": list(create_user)})
        if create_time:
            data.append({"name": "createTime", "value": list(create_time)})

        data.append({"name": "exclude", "value": []})

        return self._request(
            "POST",
            f"/ms/vteam/api/user/issue/{self.project_id}/table/BUG?num={num}&size={size}&remember={remember_value}",
            data=data,
        )

    def bug_direction_next(
            self,
            issue_id: str,
            next_node_id: str,
            operators: list,
            comment: str = "",
            at_users: Optional[list] = None,
            direction_fields: Optional[list] = None,
    ) -> dict:
        """缺陷工作流流转到下一节点（POST issue_direction/.../next）。"""
        data = {
            "issueId": issue_id,
            "nextNodeId": next_node_id,
            "comment": {"atUser": list(at_users or []), "comment": comment},
            "directionFields": list(direction_fields or []),
            "operators": list(operators or []),
        }
        return self._request(
            "POST",
            f"/ms/vteam/api/user/issue_direction/{self.project_id}/next",
            data=data,
        )

    def delete_issue(self, issue_id: str) -> dict:
        """删除工作项（缺陷等共用 issue 删除接口）。"""
        return self._request("DELETE", f"/ms/vteam/api/user/issue/{self.project_id}/{issue_id}")
