# dargslan-toolkit

**The Complete Linux Sysadmin Toolkit** — Install everything you need for Linux server management with a single command. System monitoring, log analysis, network scanning, firewall auditing, and Docker health checks.

[![PyPI version](https://img.shields.io/pypi/v/dargslan-toolkit)](https://pypi.org/project/dargslan-toolkit/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## Installation

```bash
pip install dargslan-toolkit
```

This installs all 5 Dargslan tools:

| Tool | Command | Description |
|------|---------|-------------|
| [dargslan-sysinfo](https://pypi.org/project/dargslan-sysinfo/) | `dargslan-sysinfo` | CPU, memory, disk, network monitoring |
| [dargslan-log-parser](https://pypi.org/project/dargslan-log-parser/) | `dargslan-logs` | Parse syslog, auth.log, nginx logs |
| [dargslan-net-scanner](https://pypi.org/project/dargslan-net-scanner/) | `dargslan-netscan` | Ping sweep, TCP port scanning |
| [dargslan-firewall-audit](https://pypi.org/project/dargslan-firewall-audit/) | `dargslan-fwaudit` | iptables/nftables rule auditing |
| [dargslan-docker-health](https://pypi.org/project/dargslan-docker-health/) | `dargslan-docker` | Container health & resource monitoring |

## Quick Start

### Unified CLI

```bash
# Full system overview
dargslan overview

# Individual tools
dargslan sysinfo
dargslan logs auth /var/log/auth.log
dargslan netscan quick 192.168.1.1
dargslan firewall
dargslan docker
```

### Python API

```python
from dargslan_toolkit import Toolkit

tk = Toolkit()

# Full system audit
report = tk.full_audit()

# Individual modules
from dargslan_sysinfo import SystemInfo
from dargslan_log_parser import LogParser
from dargslan_net_scanner import NetScanner
from dargslan_firewall_audit import FirewallAudit
from dargslan_docker_health import DockerHealth
```

## Use Cases

- **Daily server health checks** — Quick overview of all system metrics
- **Security audits** — Firewall rules + open ports + auth log analysis
- **Incident response** — Log parsing + network scanning in one toolkit
- **Infrastructure monitoring** — Docker + system resources + network
- **Compliance checks** — Automated firewall and security auditing

## Why dargslan-toolkit?

- **Zero external dependencies** — Only Python standard library
- **5 tools, 1 install** — Everything a Linux sysadmin needs
- **CLI + Python API** — Use from terminal or import in scripts
- **Lightweight** — Minimal footprint, fast execution
- **Production tested** — Used on real Linux servers

## More Resources

- [Linux & DevOps eBooks](https://dargslan.com/books) — 210+ professional eBooks for sysadmins
- [Free Cheat Sheets](https://dargslan.com/cheat-sheets) — Linux, Docker, Kubernetes, Ansible quick references
- [Blog & Tutorials](https://dargslan.com/blog) — 300+ in-depth Linux and DevOps guides
- [Free Tools](https://dargslan.com/tools) — Linux Distro Finder, IT Career Path Calculator, and more

## Individual Packages

Each tool is also available as a standalone package:

```bash
pip install dargslan-sysinfo
pip install dargslan-log-parser
pip install dargslan-net-scanner
pip install dargslan-firewall-audit
pip install dargslan-docker-health
```

## License

MIT License — see [LICENSE](LICENSE) for details.

---

**Made with care by [Dargslan](https://dargslan.com)** — Your source for Linux & DevOps knowledge.

[Website](https://dargslan.com) | [eBooks](https://dargslan.com/books) | [Cheat Sheets](https://dargslan.com/cheat-sheets) | [Blog](https://dargslan.com/blog) | [GitHub](https://github.com/Dargslan)
