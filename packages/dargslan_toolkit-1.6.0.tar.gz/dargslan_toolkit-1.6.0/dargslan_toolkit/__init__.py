"""
dargslan-toolkit — The Complete Linux Sysadmin Toolkit (15 tools)

Install all Dargslan tools with: pip install dargslan-toolkit

Includes:
  - dargslan-sysinfo: System information & monitoring
  - dargslan-log-parser: Log file analysis
  - dargslan-net-scanner: Network scanning
  - dargslan-firewall-audit: Firewall auditing
  - dargslan-docker-health: Docker health checks
  - dargslan-ssl-checker: SSL certificate checking
  - dargslan-disk-cleaner: Disk usage analysis & cleanup
  - dargslan-process-monitor: Process monitoring & zombie detection
  - dargslan-cron-audit: Crontab auditing
  - dargslan-backup-monitor: Backup status monitoring
  - dargslan-user-audit: User account auditing
  - dargslan-service-monitor: Systemd service monitoring
  - dargslan-port-monitor: Open port monitoring
  - dargslan-log-rotate: Log rotation analysis
  - dargslan-security-scan: Security scanning

Homepage: https://dargslan.com
Free Cheat Sheets: https://dargslan.com/cheat-sheets
Linux & DevOps Books: https://dargslan.com/books
Blog: https://dargslan.com/blog
"""

__version__ = "1.2.0"
__author__ = "Dargslan"
__url__ = "https://dargslan.com"


class Toolkit:
    """Unified access to all 15 Dargslan tools."""

    def __init__(self):
        self._cache = {}

    def _lazy(self, key, module, cls):
        if key not in self._cache:
            mod = __import__(module, fromlist=[cls])
            self._cache[key] = getattr(mod, cls)()
        return self._cache[key]

    @property
    def sysinfo(self):
        return self._lazy('sysinfo', 'dargslan_sysinfo', 'SystemInfo')

    @property
    def logs(self):
        return self._lazy('logs', 'dargslan_log_parser', 'LogParser')

    @property
    def network(self):
        return self._lazy('network', 'dargslan_net_scanner', 'NetScanner')

    @property
    def firewall(self):
        return self._lazy('firewall', 'dargslan_firewall_audit', 'FirewallAudit')

    @property
    def docker(self):
        return self._lazy('docker', 'dargslan_docker_health', 'DockerHealth')

    @property
    def ssl(self):
        return self._lazy('ssl', 'dargslan_ssl_checker', 'SSLChecker')

    @property
    def disk(self):
        return self._lazy('disk', 'dargslan_disk_cleaner', 'DiskCleaner')

    @property
    def processes(self):
        return self._lazy('processes', 'dargslan_process_monitor', 'ProcessMonitor')

    @property
    def cron(self):
        return self._lazy('cron', 'dargslan_cron_audit', 'CronAudit')

    @property
    def backup(self):
        return self._lazy('backup', 'dargslan_backup_monitor', 'BackupMonitor')

    @property
    def users(self):
        return self._lazy('users', 'dargslan_user_audit', 'UserAudit')

    @property
    def services(self):
        return self._lazy('services', 'dargslan_service_monitor', 'ServiceMonitor')

    @property
    def ports(self):
        return self._lazy('ports', 'dargslan_port_monitor', 'PortMonitor')

    @property
    def logrotate(self):
        return self._lazy('logrotate', 'dargslan_log_rotate', 'LogRotateAudit')

    @property
    def security(self):
        return self._lazy('security', 'dargslan_security_scan', 'SecurityScanner')

    def full_audit(self):
        """Run a complete system audit using all tools."""
        return {
            "system": self.sysinfo.full_report(),
            "firewall": self.firewall.full_audit(),
            "docker": self.docker.check_all(),
            "processes": self.processes.process_count(),
            "cron": self.cron.audit(),
            "users": self.users.audit(),
            "security_score": self.security.score(),
        }

    def quick_overview(self):
        """Print a quick system overview."""
        self.sysinfo.print_report(["os", "cpu", "memory", "disk"])


__all__ = ["Toolkit"]
