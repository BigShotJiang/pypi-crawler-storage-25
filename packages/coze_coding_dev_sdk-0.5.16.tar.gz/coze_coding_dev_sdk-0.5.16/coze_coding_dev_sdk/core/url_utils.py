"""
URL 校验工具模块
提供 URL 格式校验、协议校验、本地地址拦截、临时URL检测和可达性预检功能
"""

from urllib.parse import urlparse
from typing import Optional

from .exceptions import ValidationError


# 禁止访问的本地主机名（字符串级别匹配，不做 DNS 解析）
_LOCAL_HOSTS = frozenset({"localhost", "127.0.0.1", "0.0.0.0", "::1"})

# 允许的协议
_ALLOWED_SCHEMES = frozenset({"http", "https"})

# 沙箱代理 URL 的特征路径
_SANDBOX_PROXY_PATH = "/api/sandbox/coze_coding/file/proxy"

# 临时 URL 的域名+路径特征
_EPHEMERAL_URL_PATTERNS = [
    ("code.coze.cn", _SANDBOX_PROXY_PATH),
]


class URLValidationError(ValidationError):
    """URL 校验失败异常"""

    def __init__(self, message: str, url: Optional[str] = None):
        super().__init__(message=message, field="url", value=url)
        self.url = url


def _is_local_path(value: str) -> bool:
    """判断字符串是否看起来像本地文件路径"""
    if not value:
        return False
    # Unix 绝对路径: /Users/xxx, /tmp/file.png
    if value.startswith("/"):
        return True
    # 相对路径: ./file.png, ../assets/img.jpg
    if value.startswith("./") or value.startswith("../"):
        return True
    # Home 目录: ~/Downloads/file.png
    if value.startswith("~/"):
        return True
    # Windows 绝对路径: C:\Users\xxx, D:/files/img.png
    if len(value) >= 3 and value[0].isalpha() and value[1] == ":" and value[2] in ("/", "\\"):
        return True
    return False


def validate_url(
    url: str,
    *,
    allow_head_check: bool = True,
    timeout: int = 5,
) -> str:
    """
    校验 URL 合法性，不触发实际内容下载。

    检查项:
    1. 非空、字符串类型校验
    2. URL 格式校验（scheme + netloc）
    3. 协议校验：仅允许 http/https
    4. 本地地址拦截：禁止 localhost/127.0.0.1/0.0.0.0/::1
    5. 可选 HEAD 预检：确认 URL 可达（不下载内容）

    注意：不做 DNS 解析到 IP 再判断私有网段的检查，避免误杀（如内部 CDN 域名解析到内网 IP 的合法场景）。

    Args:
        url: 待校验的 URL 字符串
        allow_head_check: 是否发送 HEAD 请求预检可达性
        timeout: HEAD 预检超时秒数，默认 5

    Returns:
        str: 经过 strip 的合法 URL

    Raises:
        URLValidationError: URL 校验失败
    """
    # 1. 基本校验
    if not url or not isinstance(url, str):
        raise URLValidationError("URL cannot be empty", url=url if isinstance(url, str) else None)

    url = url.strip()

    if not url:
        raise URLValidationError("URL cannot be empty", url=url)

    # 2. 格式校验
    try:
        parsed = urlparse(url)
    except Exception:
        if _is_local_path(url):
            raise URLValidationError(
                f"The input appears to be a local file path: {url}. "
                f"Please upload it using the Storage skill first to get a persistent HTTP URL.",
                url=url,
            )
        raise URLValidationError(f"Invalid URL format: {url}", url=url)

    if not parsed.scheme or not parsed.netloc:
        if _is_local_path(url):
            raise URLValidationError(
                f"The input appears to be a local file path: {url}. "
                f"Please upload it using the Storage skill first to get a persistent HTTP URL.",
                url=url,
            )
        raise URLValidationError(
            f"Invalid URL format (missing scheme or host): {url}", url=url
        )

    # 3. 协议校验
    if parsed.scheme.lower() not in _ALLOWED_SCHEMES:
        raise URLValidationError(
            f"Unsupported scheme '{parsed.scheme}', only http/https allowed",
            url=url,
        )

    # 4. 本地地址拦截（字符串匹配，不做 DNS 解析）
    hostname = parsed.hostname
    if not hostname:
        raise URLValidationError(f"Cannot extract hostname from URL: {url}", url=url)

    if hostname.lower() in _LOCAL_HOSTS:
        raise URLValidationError(
            f"Access to local address is not allowed: {hostname}", url=url
        )

    # 5. 临时 URL 检测（沙箱代理等）
    if is_ephemeral_url(url):
        raise URLValidationError(
            f"This URL appears to be a temporary sandbox proxy URL that may expire. "
            f"Please download the file and upload it to persistent storage (Storage skill) first.",
            url=url,
        )

    # 6. 可选 HEAD 预检
    if allow_head_check:
        _head_check(url, timeout=timeout)

    return url


def is_ephemeral_url(url: str) -> bool:
    """
    检测 URL 是否为临时/可能失效的地址。

    当前检测规则：
    1. 沙箱文件代理 URL（code.coze.cn/api/sandbox/coze_coding/file/proxy）
       - 带有 expire_time、sign、nonce 参数
       - 这类 URL 有签名过期机制，不适合长期使用

    Args:
        url: 待检测的 URL

    Returns:
        bool: True 表示是临时 URL，应先上传到持久存储
    """
    try:
        parsed = urlparse(url)
    except Exception:
        return False

    hostname = (parsed.hostname or "").lower()
    path = parsed.path or ""

    for pattern_host, pattern_path in _EPHEMERAL_URL_PATTERNS:
        if hostname == pattern_host and path.startswith(pattern_path):
            return True

    return False


def _head_check(url: str, *, timeout: int = 5) -> None:
    """
    发送 HEAD 请求预检 URL 可达性，不下载内容。
    如果服务器不支持 HEAD（返回 405），降级尝试 GET + Range: bytes=0-0。
    """
    import urllib.request

    # 尝试 HEAD
    req = urllib.request.Request(url, method="HEAD")
    req.add_header("User-Agent", "CozeSDK-URLValidator/1.0")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            if resp.status >= 400:
                raise URLValidationError(
                    f"URL is not reachable: HTTP {resp.status}", url=url
                )
    except urllib.error.HTTPError as e:
        if e.code == 405:
            # 服务器不支持 HEAD，降级用 GET + Range
            _range_check(url, timeout=timeout)
        elif e.code >= 400:
            raise URLValidationError(
                f"URL is not reachable: HTTP {e.code}", url=url
            )
        else:
            raise
    except urllib.error.URLError as e:
        raise URLValidationError(
            f"URL is not reachable (network error: {e.reason}). Please check if the URL is correct and accessible.",
            url=url,
        )
    except Exception as e:
        if isinstance(e, URLValidationError):
            raise
        raise URLValidationError(
            f"URL is not reachable ({e}). Please check if the URL is correct and accessible.",
            url=url,
        )


def _range_check(url: str, *, timeout: int = 5) -> None:
    """
    GET + Range: bytes=0-0 降级预检，只取 1 字节。
    如果服务器连 Range GET 也拒绝（405/400），仍视为可达——
    因为返回 HTTP 响应本身就证明服务器在线。
    只有 404/5xx/网络不可达才判定为不可达。
    """
    import urllib.request

    req = urllib.request.Request(url, method="GET")
    req.add_header("User-Agent", "CozeSDK-URLValidator/1.0")
    req.add_header("Range", "bytes=0-0")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            # 206 Partial Content 或 200 都说明可达
            if resp.status >= 400:
                raise URLValidationError(
                    f"URL is not reachable: HTTP {resp.status}", url=url
                )
    except urllib.error.HTTPError as e:
        # 405/400 = 服务器在线但不支持此方法，视为可达
        if e.code in (405, 400):
            return
        # 404/403/5xx = 资源不存在或服务异常
        if e.code >= 400:
            raise URLValidationError(
                f"URL is not reachable: HTTP {e.code}", url=url
            )
    except urllib.error.URLError as e:
        raise URLValidationError(
            f"URL is not reachable (network error: {e.reason}). Please check if the URL is correct and accessible.",
            url=url,
        )
    except Exception as e:
        if isinstance(e, URLValidationError):
            raise
        raise URLValidationError(
            f"URL is not reachable ({e}). Please check if the URL is correct and accessible.",
            url=url,
        )
