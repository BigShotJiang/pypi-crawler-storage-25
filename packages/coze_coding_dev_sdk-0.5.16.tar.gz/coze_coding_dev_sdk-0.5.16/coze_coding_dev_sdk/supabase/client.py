from typing import Dict, List, Optional

from coze_coding_utils.runtime_ctx.context import Context

from ..core.client import BaseClient
from ..core.config import Config
from .models import (
    AuthEmailConfig,
    AuthPhoneConfig,
    BlockedQueryInfo,
    ProjectAuthConfigV2,
    Bucket,
    ConnectionStateCount,
    ConnectionStats,
    CreateBucketResponse,
    DeleteBucketResponse,
    DeleteEdgeFunctionResponse,
    DeployEdgeFunctionResponse,
    DiagnoseDatabaseResponse,
    DiagnosticReport,
    EdgeFunction,
    FunctionFile,
    GetAuthConfigResponse,
    GetBucketResponse,
    GetEdgeFunctionResponse,
    ListBucketsResponse,
    ListEdgeFunctionsResponse,
    LongRunningQueryInfo,
    PGDiagnosticMetrics,
    QueryStatsInfo,
    SupabaseDiagnosticMetrics,
    TableSizeInfo,
    UpdateAuthConfigResponse,
    UpdateBucketResponse,
    GetAuthConfigV2Response,
    UpdateAuthConfigV2Response,
)


class SupabaseClient(BaseClient):
    def __init__(
        self,
        config: Optional[Config] = None,
        ctx: Optional[Context] = None,
        custom_headers: Optional[Dict[str, str]] = None,
        verbose: bool = True,
    ):
        super().__init__(config, ctx, custom_headers, verbose)
        self.base_url = self.config.base_url
        self.api_key = self.config.api_key

    def _get_headers(self) -> Dict[str, str]:
        headers = {"x-coze-token": self.api_key}
        return headers

    def list_functions(self) -> ListEdgeFunctionsResponse:
        response = self._request(
            method="POST",
            url=f"{self.base_url}/v1/supabase/functions/list",
            json={},
            headers=self._get_headers(),
        )

        code = response.get("code", 0)
        msg = response.get("msg", "")

        functions = []
        for fn in response.get("functions") or []:
            functions.append(
                EdgeFunction(
                    id=fn.get("id", ""),
                    slug=fn.get("slug", ""),
                    name=fn.get("name", ""),
                    status=fn.get("status", ""),
                    version=fn.get("version", 0),
                    verify_jwt=fn.get("verify_jwt", False),
                    entrypoint_path=fn.get("entrypoint_path"),
                    created_at=fn.get("created_at"),
                    updated_at=fn.get("updated_at"),
                )
            )

        return ListEdgeFunctionsResponse(functions=functions, code=code, msg=msg)

    def get_function(self, slug: str) -> GetEdgeFunctionResponse:
        response = self._request(
            method="POST",
            url=f"{self.base_url}/v1/supabase/functions/get",
            json={"slug": slug},
            headers=self._get_headers(),
        )

        code = response.get("code", 0)
        msg = response.get("msg", "")

        function = None
        fn = response.get("function")
        if fn:
            function = EdgeFunction(
                id=fn.get("id", ""),
                slug=fn.get("slug", ""),
                name=fn.get("name", ""),
                status=fn.get("status", ""),
                version=fn.get("version", 0),
                verify_jwt=fn.get("verify_jwt", False),
                entrypoint_path=fn.get("entrypoint_path"),
                created_at=fn.get("created_at"),
                updated_at=fn.get("updated_at"),
            )

        files = []
        for f in response.get("files") or []:
            files.append(FunctionFile(name=f.get("name", ""), content=f.get("content", "")))

        return GetEdgeFunctionResponse(function=function, files=files, code=code, msg=msg)

    def deploy_function(
        self,
        slug: str,
        code: Optional[str] = None,
        files: Optional[List[Dict[str, str]]] = None,
        name: Optional[str] = None,
        entrypoint: Optional[str] = None,
        verify_jwt: Optional[bool] = None,
    ) -> DeployEdgeFunctionResponse:
        payload: Dict = {"slug": slug}
        if code is not None:
            payload["code"] = code
        if files is not None:
            payload["files"] = files
        if name is not None:
            payload["name"] = name
        if entrypoint is not None:
            payload["entrypoint"] = entrypoint
        if verify_jwt is not None:
            payload["verify_jwt"] = verify_jwt

        response = self._request(
            method="POST",
            url=f"{self.base_url}/v1/supabase/functions/deploy",
            json=payload,
            headers=self._get_headers(),
        )

        return DeployEdgeFunctionResponse(
            success=response.get("success", False),
            slug=response.get("slug"),
            version=response.get("version"),
            code=response.get("code", 0),
            msg=response.get("msg", ""),
        )

    def delete_function(self, slug: str) -> DeleteEdgeFunctionResponse:
        response = self._request(
            method="POST",
            url=f"{self.base_url}/v1/supabase/functions/delete",
            json={"slug": slug},
            headers=self._get_headers(),
        )

        return DeleteEdgeFunctionResponse(
            success=response.get("success", False),
            code=response.get("code", 0),
            msg=response.get("msg", ""),
        )

    def list_buckets(self) -> ListBucketsResponse:
        response = self._request(
            method="POST",
            url=f"{self.base_url}/v1/supabase/buckets/list",
            json={},
            headers=self._get_headers(),
        )

        code = response.get("code", 0)
        msg = response.get("msg", "")

        buckets = []
        for b in response.get("buckets") or []:
            buckets.append(
                Bucket(
                    id=b.get("id", ""),
                    name=b.get("name", ""),
                    public=b.get("public", False),
                    owner=b.get("owner"),
                    file_size_limit=b.get("file_size_limit"),
                    allowed_mime_types=b.get("allowed_mime_types"),
                    created_at=b.get("created_at"),
                    updated_at=b.get("updated_at"),
                )
            )

        return ListBucketsResponse(buckets=buckets, code=code, msg=msg)

    def get_bucket(self, bucket_id: str) -> GetBucketResponse:
        response = self._request(
            method="POST",
            url=f"{self.base_url}/v1/supabase/buckets/get",
            json={"bucket_id": bucket_id},
            headers=self._get_headers(),
        )

        code = response.get("code", 0)
        msg = response.get("msg", "")

        bucket = None
        b = response.get("bucket")
        if b:
            bucket = Bucket(
                id=b.get("id", ""),
                name=b.get("name", ""),
                public=b.get("public", False),
                owner=b.get("owner"),
                file_size_limit=b.get("file_size_limit"),
                allowed_mime_types=b.get("allowed_mime_types"),
                created_at=b.get("created_at"),
                updated_at=b.get("updated_at"),
            )

        return GetBucketResponse(bucket=bucket, code=code, msg=msg)

    def create_bucket(
        self,
        bucket_id: str,
        name: Optional[str] = None,
        public: Optional[bool] = None,
        file_size_limit: Optional[int] = None,
        allowed_mime_types: Optional[List[str]] = None,
    ) -> CreateBucketResponse:
        payload: Dict = {"bucket_id": bucket_id}
        if name is not None:
            payload["name"] = name
        if public is not None:
            payload["public"] = public
        if file_size_limit is not None:
            payload["file_size_limit"] = file_size_limit
        if allowed_mime_types is not None:
            payload["allowed_mime_types"] = allowed_mime_types

        response = self._request(
            method="POST",
            url=f"{self.base_url}/v1/supabase/buckets/create",
            json=payload,
            headers=self._get_headers(),
        )

        return CreateBucketResponse(
            success=response.get("success", False),
            bucket_id=response.get("bucket_id"),
            code=response.get("code", 0),
            msg=response.get("msg", ""),
        )

    def update_bucket(
        self,
        bucket_id: str,
        public: Optional[bool] = None,
        file_size_limit: Optional[int] = None,
        allowed_mime_types: Optional[List[str]] = None,
    ) -> UpdateBucketResponse:
        payload: Dict = {"bucket_id": bucket_id}
        if public is not None:
            payload["public"] = public
        if file_size_limit is not None:
            payload["file_size_limit"] = file_size_limit
        if allowed_mime_types is not None:
            payload["allowed_mime_types"] = allowed_mime_types

        response = self._request(
            method="POST",
            url=f"{self.base_url}/v1/supabase/buckets/update",
            json=payload,
            headers=self._get_headers(),
        )

        return UpdateBucketResponse(
            success=response.get("success", False),
            code=response.get("code", 0),
            msg=response.get("msg", ""),
        )

    def delete_bucket(self, bucket_id: str) -> DeleteBucketResponse:
        response = self._request(
            method="POST",
            url=f"{self.base_url}/v1/supabase/buckets/delete",
            json={"bucket_id": bucket_id},
            headers=self._get_headers(),
        )

        return DeleteBucketResponse(
            success=response.get("success", False),
            code=response.get("code", 0),
            msg=response.get("msg", ""),
        )

    def get_auth_config(self) -> GetAuthConfigResponse:
        response = self._request(
            method="POST",
            url=f"{self.base_url}/v1/supabase/auth/config/get",
            json={},
            headers=self._get_headers(),
        )

        code = response.get("code", 0)
        msg = response.get("msg", "")

        config = None
        c = response.get("config")
        if c:
            config = AuthEmailConfig(
                external_email_enabled=c.get("external_email_enabled"),
                disable_signup=c.get("disable_signup"),
                mailer_autoconfirm=c.get("mailer_autoconfirm"),
                double_confirm_changes=c.get("double_confirm_changes"),
                mailer_secure_email_change_enabled=c.get("mailer_secure_email_change_enabled"),
                mailer_otp_exp=c.get("mailer_otp_exp"),
                password_min_length=c.get("password_min_length"),
                password_required_characters=c.get("password_required_characters"),
                site_url=c.get("site_url"),
                smtp_host=c.get("smtp_host"),
                smtp_port=c.get("smtp_port"),
                smtp_user=c.get("smtp_user"),
                smtp_pass=c.get("smtp_pass"),
                smtp_admin_email=c.get("smtp_admin_email"),
                smtp_sender_name=c.get("smtp_sender_name"),
                smtp_max_frequency=c.get("smtp_max_frequency"),
            )

        return GetAuthConfigResponse(config=config, code=code, msg=msg)


    def get_auth_config_v2(self) -> GetAuthConfigV2Response:
        response = self._request(
            method="POST",
            url=f"{self.base_url}/v2/supabase/auth/config/get",
            json={},
            headers=self._get_headers(),
        )

        code = response.get("code", 0)
        msg = response.get("msg", "")
        status = response.get("Status", 0)

        config = None
        c = response.get("Config")
        if c:
            email_config = None
            ec = c.get("EmailConfig")
            if ec:
                email_config = AuthEmailConfig(
                    external_email_enabled=ec.get("external_email_enabled"),
                    disable_signup=ec.get("disable_signup"),
                    mailer_auto_confirm=ec.get("mailer_auto_confirm"),
                    double_confirm_changes=ec.get("double_confirm_changes"),
                    mailer_secure_email_change_enabled=ec.get("mailer_secure_email_change_enabled"),
                    mailer_otp_exp=ec.get("mailer_otp_exp"),
                    password_min_length=ec.get("password_min_length"),
                    password_required_characters=ec.get("password_required_characters"),
                    site_url=ec.get("site_url"),
                    smtp_host=ec.get("smtp_host"),
                    smtp_port=ec.get("smtp_port"),
                    smtp_user=ec.get("smtp_user"),
                    smtp_pass=ec.get("smtp_pass"),
                    smtp_admin_email=ec.get("smtp_admin_email"),
                    smtp_sender_name=ec.get("smtp_sender_name"),
                    smtp_max_frequency=ec.get("smtp_max_frequency"),
                )

            phone_config = None
            pc = c.get("PhoneConfig")
            if pc:
                phone_config = AuthPhoneConfig(
                    external_phone_enabled=pc.get("external_phone_enabled"),
                )

            config = ProjectAuthConfigV2(
                project_id=c.get("ProjectID", 0),
                icon_uri=c.get("IconURI", ""),
                icon_url=c.get("IconURL", ""),
                name=c.get("Name", ""),
                email_config=email_config,
                phone_config=phone_config,
            )

        return GetAuthConfigV2Response(config=config, code=code, msg=msg, status=status)

    def update_auth_config(
        self,
        config: Optional[Dict] = None,
    ) -> UpdateAuthConfigResponse:
        payload: Dict = {}
        if config is not None:
            payload["config"] = config

        response = self._request(
            method="POST",
            url=f"{self.base_url}/v1/supabase/auth/config/update",
            json=payload,
            headers=self._get_headers(),
        )

        return UpdateAuthConfigResponse(
            success=response.get("success", False),
            code=response.get("code", 0),
            msg=response.get("msg", ""),
        )

    def update_auth_config_v2(
        self,
        config: Optional[Dict] = None,
    ) -> UpdateAuthConfigV2Response:
        payload: Dict = config if config is not None else {}

        response = self._request(
            method="POST",
            url=f"{self.base_url}/v2/supabase/auth/config/update",
            json=payload,
            headers=self._get_headers(),
        )

        return UpdateAuthConfigV2Response(
            should_update_ui=response.get("should_update_ui", False),
            success=response.get("success", False),
            code=response.get("code", 0),
            msg=response.get("msg", ""),
        )

    def diagnose_database(
        self,
        env: Optional[str] = None,
    ) -> DiagnoseDatabaseResponse:
        payload: Dict = {}
        if env is not None:
            payload["env"] = env

        response = self._request(
            method="POST",
            url=f"{self.base_url}/v1/supabase/database/diagnose",
            json=payload,
            headers=self._get_headers(),
        )

        code = response.get("code", 0)
        msg = response.get("msg", "")

        report = None
        r = response.get("report")
        if r:
            pg_raw = r.get("pg_metrics") or {}
            pg_metrics = PGDiagnosticMetrics(
                top_queries_by_total_time=[
                    QueryStatsInfo(**q) for q in (pg_raw.get("top_queries_by_total_time") or [])
                ],
                top_queries_by_frequency=[
                    QueryStatsInfo(**q) for q in (pg_raw.get("top_queries_by_frequency") or [])
                ],
                slow_queries=[
                    QueryStatsInfo(**q) for q in (pg_raw.get("slow_queries") or [])
                ],
                connection_stats=ConnectionStats(
                    connections_by_state=[
                        ConnectionStateCount(**c)
                        for c in (pg_raw.get("connection_stats", {}).get("connections_by_state") or [])
                    ],
                    max_connections=pg_raw.get("connection_stats", {}).get("max_connections"),
                    connection_usage_pct=pg_raw.get("connection_stats", {}).get("connection_usage_pct"),
                    total_connections=pg_raw.get("connection_stats", {}).get("total_connections"),
                ) if pg_raw.get("connection_stats") else None,
                blocked_queries=[
                    BlockedQueryInfo(**q) for q in (pg_raw.get("blocked_queries") or [])
                ],
                long_running_queries=[
                    LongRunningQueryInfo(**q) for q in (pg_raw.get("long_running_queries") or [])
                ],
                database_size=pg_raw.get("database_size"),
                table_sizes=[
                    TableSizeInfo(**t) for t in (pg_raw.get("table_sizes") or [])
                ],
            )

            supabase_metrics = None
            sm = r.get("supabase_metrics")
            if sm:
                supabase_metrics = SupabaseDiagnosticMetrics(
                    rate_limited_429_count=sm.get("rate_limited_429_count"),
                )

            report = DiagnosticReport(
                database_type=r.get("database_type", 0),
                pg_metrics=pg_metrics,
                supabase_metrics=supabase_metrics,
            )

        return DiagnoseDatabaseResponse(report=report, code=code, msg=msg)
