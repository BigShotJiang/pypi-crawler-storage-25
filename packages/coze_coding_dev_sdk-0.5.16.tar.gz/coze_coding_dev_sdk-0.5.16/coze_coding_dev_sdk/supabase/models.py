from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class EdgeFunction:
    id: str
    slug: str
    name: str
    status: str
    version: int
    verify_jwt: bool
    entrypoint_path: Optional[str] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None


@dataclass
class FunctionFile:
    name: str
    content: str


@dataclass
class Bucket:
    id: str
    name: str
    public: bool
    owner: Optional[str] = None
    file_size_limit: Optional[int] = None
    allowed_mime_types: Optional[List[str]] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None


@dataclass
class AuthEmailConfig:
    external_email_enabled: Optional[bool] = None
    disable_signup: Optional[bool] = None
    mailer_auto_confirm: Optional[bool] = None
    double_confirm_changes: Optional[bool] = None
    mailer_secure_email_change_enabled: Optional[bool] = None
    mailer_otp_exp: Optional[int] = None
    password_min_length: Optional[int] = None
    password_required_characters: Optional[str] = None
    site_url: Optional[str] = None
    smtp_host: Optional[str] = None
    smtp_port: Optional[int] = None
    smtp_user: Optional[str] = None
    smtp_pass: Optional[str] = None
    smtp_admin_email: Optional[str] = None
    smtp_sender_name: Optional[str] = None
    smtp_max_frequency: Optional[int] = None


@dataclass
class AuthPhoneConfig:
    external_phone_enabled: Optional[bool] = None

@dataclass
class ProjectAuthConfigV2:
    project_id: int = 0
    icon_uri: str = ""
    icon_url: str = ""
    name: str = ""
    email_config: Optional[AuthEmailConfig] = None
    phone_config: Optional[AuthPhoneConfig] = None


@dataclass
class ListEdgeFunctionsResponse:
    functions: List[EdgeFunction] = field(default_factory=list)
    code: int = 0
    msg: str = ""


@dataclass
class GetEdgeFunctionResponse:
    function: Optional[EdgeFunction] = None
    files: List[FunctionFile] = field(default_factory=list)
    code: int = 0
    msg: str = ""


@dataclass
class DeployEdgeFunctionResponse:
    success: bool = False
    slug: Optional[str] = None
    version: Optional[int] = None
    code: int = 0
    msg: str = ""


@dataclass
class DeleteEdgeFunctionResponse:
    success: bool = False
    code: int = 0
    msg: str = ""


@dataclass
class ListBucketsResponse:
    buckets: List[Bucket] = field(default_factory=list)
    code: int = 0
    msg: str = ""


@dataclass
class GetBucketResponse:
    bucket: Optional[Bucket] = None
    code: int = 0
    msg: str = ""


@dataclass
class CreateBucketResponse:
    success: bool = False
    bucket_id: Optional[str] = None
    code: int = 0
    msg: str = ""


@dataclass
class UpdateBucketResponse:
    success: bool = False
    code: int = 0
    msg: str = ""


@dataclass
class DeleteBucketResponse:
    success: bool = False
    code: int = 0
    msg: str = ""


@dataclass
class GetAuthConfigResponse:
    config: Optional[AuthEmailConfig] = None
    code: int = 0
    msg: str = ""


@dataclass
class GetAuthConfigV2Response:
    status: int = 0
    config: Optional[ProjectAuthConfigV2] = None
    code: int = 0
    msg: str = ""


@dataclass
class UpdateAuthConfigResponse:
    success: bool = False
    code: int = 0
    msg: str = ""


@dataclass
class UpdateAuthConfigV2Response:
    should_update_ui: bool = False
    success: bool = False
    code: int = 0
    msg: str = ""


# Database Diagnostic


@dataclass
class QueryStatsInfo:
    query: Optional[str] = None
    calls: Optional[int] = None
    avg_ms: Optional[float] = None
    total_ms: Optional[float] = None
    rows: Optional[int] = None


@dataclass
class ConnectionStateCount:
    state: Optional[str] = None
    count: Optional[int] = None


@dataclass
class ConnectionStats:
    connections_by_state: Optional[List["ConnectionStateCount"]] = None
    max_connections: Optional[int] = None
    connection_usage_pct: Optional[float] = None
    total_connections: Optional[int] = None


@dataclass
class BlockedQueryInfo:
    blocked_pid: Optional[int] = None
    blocked_query: Optional[str] = None
    blocking_pid: Optional[int] = None
    blocking_query: Optional[str] = None
    blocked_duration: Optional[str] = None


@dataclass
class LongRunningQueryInfo:
    pid: Optional[int] = None
    duration: Optional[str] = None
    state: Optional[str] = None
    query: Optional[str] = None


@dataclass
class TableSizeInfo:
    table_name: Optional[str] = None
    total_size: Optional[str] = None


@dataclass
class SupabaseDiagnosticMetrics:
    rate_limited_429_count: Optional[int] = None


@dataclass
class PGDiagnosticMetrics:
    top_queries_by_total_time: Optional[List[QueryStatsInfo]] = None
    top_queries_by_frequency: Optional[List[QueryStatsInfo]] = None
    slow_queries: Optional[List[QueryStatsInfo]] = None
    connection_stats: Optional[ConnectionStats] = None
    blocked_queries: Optional[List[BlockedQueryInfo]] = None
    long_running_queries: Optional[List[LongRunningQueryInfo]] = None
    database_size: Optional[str] = None
    table_sizes: Optional[List[TableSizeInfo]] = None


@dataclass
class DiagnosticReport:
    database_type: int = 0
    pg_metrics: Optional[PGDiagnosticMetrics] = None
    supabase_metrics: Optional[SupabaseDiagnosticMetrics] = None


@dataclass
class DiagnoseDatabaseResponse:
    report: Optional[DiagnosticReport] = None
    code: int = 0
    msg: str = ""
