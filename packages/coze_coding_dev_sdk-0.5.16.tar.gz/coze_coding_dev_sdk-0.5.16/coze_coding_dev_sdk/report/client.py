import os
from typing import List, Optional, Dict, Tuple

from .models import LogEntry

BATCH_REPORT_TIMEOUT_SECONDS = 10

_env_loaded = False
_cached_env: Tuple[str, str] = ("", "")


def _load_report_env() -> Tuple[str, str]:
    """Load base_url and api_key from env, dotenv, or coze_workload_identity."""
    global _env_loaded, _cached_env
    if _env_loaded:
        return _cached_env

    base_url = os.environ.get("COZE_INTEGRATION_BASE_URL", "")
    api_key = os.environ.get("COZE_WORKLOAD_IDENTITY_API_KEY", "")

    if base_url and api_key:
        _env_loaded = True
        _cached_env = (base_url, api_key)
        return _cached_env

    try:
        from dotenv import load_dotenv
        load_dotenv()
        base_url = os.environ.get("COZE_INTEGRATION_BASE_URL", "")
        api_key = os.environ.get("COZE_WORKLOAD_IDENTITY_API_KEY", "")
        if base_url and api_key:
            _env_loaded = True
            _cached_env = (base_url, api_key)
            return _cached_env
    except ImportError:
        pass

    try:
        from coze_workload_identity import Client
        client = Client()
        env_vars = client.get_project_env_vars()
        client.close()
        for env_var in env_vars:
            if env_var.key == "COZE_INTEGRATION_BASE_URL":
                base_url = env_var.value
            elif env_var.key == "COZE_WORKLOAD_IDENTITY_API_KEY":
                api_key = env_var.value
    except Exception:
        pass

    _env_loaded = True
    _cached_env = (base_url, api_key)
    return _cached_env


class ReportClient:
    def __init__(self):
        try:
            base_url, api_key = _load_report_env()
            self._base_url = base_url
            self._api_key = api_key
            self._configured = bool(self._base_url and self._api_key)
            if not self._configured:
                missing = []
                if not self._base_url:
                    missing.append("COZE_INTEGRATION_BASE_URL")
                if not self._api_key:
                    missing.append("COZE_WORKLOAD_IDENTITY_API_KEY")
                print(f"[report] ReportClient not configured: {', '.join(missing)} is missing")
        except Exception as e:
            self._base_url = None
            self._api_key = None
            self._configured = False
            print(f"[report] ReportClient config failed: {e}")

    def batch_report(self, entries: List[LogEntry]) -> None:
        if not entries:
            return
        if not self._configured:
            print(f"[report] batchReport skipped: ReportClient is not configured. "
                  f"Set COZE_INTEGRATION_BASE_URL and COZE_WORKLOAD_IDENTITY_API_KEY "
                  f"environment variables. Dropping {len(entries)} entries.")
            return
        # Use `requests` instead of `httpx` intentionally to avoid self-instrumentation:
        # the SDK wraps httpx transports for report interception, so using httpx here
        # would cause the reporting calls themselves to be intercepted recursively.
        import requests

        url = f"{self._base_url}/v1/memory_report/batch_report"
        headers: Dict[str, str] = {
            "Content-Type": "application/json",
            "x-coze-token": self._api_key,
        }
        payload = {"entries": [e.model_dump() for e in entries]}
        resp = requests.post(url, json=payload, headers=headers, timeout=BATCH_REPORT_TIMEOUT_SECONDS)
        resp.raise_for_status()
