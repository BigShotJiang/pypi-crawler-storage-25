import atexit
import os
import threading
import time
from collections import deque
from typing import List, Optional

from .models import LogEntry

BUFFER_SIZE_THRESHOLD = 100
FLUSH_INTERVAL_SECONDS = 60.0
MAX_BUFFER_SIZE = 60_000
MAX_FLUSH_RETRIES = 3
FLUSH_RETRY_BASE_SECONDS = 1.0


class ReportBuffer:
    def __init__(self, client):
        self._client = client
        self._buffer: deque[LogEntry] = deque(maxlen=MAX_BUFFER_SIZE)
        self._lock = threading.Lock()
        self._project_id: Optional[str] = os.environ.get("COZELOOP_WORKSPACE_ID")
        self._env: Optional[str] = os.environ.get("COZE_PROJECT_ENV")
        self._timer: Optional[threading.Timer] = None
        self._destroyed = False
        self._flushing = False
        self._pending_flush = False
        self._start_timer()
        atexit.register(self.destroy)

    def _start_timer(self) -> None:
        with self._lock:
            if self._destroyed:
                return
            self._timer = threading.Timer(FLUSH_INTERVAL_SECONDS, self._on_timer)
            self._timer.daemon = True
            self._timer.start()

    def _on_timer(self) -> None:
        try:
            self.flush()
        except Exception:
            pass
        self._start_timer()

    def add(self, entry: LogEntry) -> None:
        if self._destroyed:
            return
        try:
            with self._lock:
                entry.project_id = self._project_id
                entry.env = self._env
                self._buffer.append(entry)
                should_flush = len(self._buffer) >= BUFFER_SIZE_THRESHOLD
            if should_flush:
                t = threading.Thread(target=self.flush, daemon=True)
                t.start()
        except Exception:
            pass

    def flush(self) -> None:
        with self._lock:
            if self._flushing:
                self._pending_flush = True
                return
            if not self._buffer:
                return
            self._flushing = True

        consecutive_failures = 0
        try:
            while True:
                with self._lock:
                    count = min(BUFFER_SIZE_THRESHOLD, len(self._buffer))
                    if count == 0:
                        break
                    entries: List[LogEntry] = [self._buffer.popleft() for _ in range(count)]

                try:
                    self._client.batch_report(entries)
                    consecutive_failures = 0
                except Exception as e:
                    consecutive_failures += 1
                    with self._lock:
                        for entry in reversed(entries):
                            if len(self._buffer) < MAX_BUFFER_SIZE:
                                self._buffer.appendleft(entry)
                    if consecutive_failures >= MAX_FLUSH_RETRIES:
                        print(f"[report] flush failed {consecutive_failures} times, giving up until next cycle: {e}")
                        break
                    delay = FLUSH_RETRY_BASE_SECONDS * (2 ** (consecutive_failures - 1))
                    print(f"[report] flush failed (attempt {consecutive_failures}/{MAX_FLUSH_RETRIES}), retrying in {delay}s: {e}")
                    time.sleep(delay)
                    continue

                with self._lock:
                    if not self._pending_flush and len(self._buffer) < BUFFER_SIZE_THRESHOLD:
                        break
                    self._pending_flush = False
        finally:
            with self._lock:
                self._flushing = False
                self._pending_flush = False

    def destroy(self) -> None:
        with self._lock:
            self._destroyed = True
            if self._timer:
                self._timer.cancel()
                self._timer = None
        try:
            self.flush()
        except Exception:
            pass
