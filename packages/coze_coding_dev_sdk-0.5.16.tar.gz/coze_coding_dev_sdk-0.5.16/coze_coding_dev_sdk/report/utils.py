import re
from typing import Optional

_SENSITIVE_PARAM_RE = re.compile(
    r'((?:apikey|api_key|access_key|secret_key|access_token|token|secret|password|authorization|credential|X-Amz-Signature|X-Amz-Credential|X-Amz-Security-Token)=)[^&]*',
    re.IGNORECASE,
)

DEFAULT_TRUNCATE_LENGTH = 1024


def truncate(s: Optional[str], max_len: int = DEFAULT_TRUNCATE_LENGTH) -> Optional[str]:
    if s is None:
        return None
    if len(s) <= max_len:
        return s
    return s[:max_len] + "...[truncated]"


def redact_url(url: str) -> str:
    return _SENSITIVE_PARAM_RE.sub(r'\1***', url)
