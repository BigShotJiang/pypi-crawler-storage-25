import threading
from typing import Optional

from .buffer import ReportBuffer
from .client import ReportClient

_buffer: Optional[ReportBuffer] = None
_lock = threading.Lock()


def get_report_buffer() -> Optional[ReportBuffer]:
    global _buffer
    if _buffer is not None:
        return _buffer
    with _lock:
        if _buffer is not None:
            return _buffer
        try:
            client = ReportClient()
            _buffer = ReportBuffer(client)
            return _buffer
        except Exception as e:
            print(f"[report] failed to create singleton buffer: {e}")
            return None
