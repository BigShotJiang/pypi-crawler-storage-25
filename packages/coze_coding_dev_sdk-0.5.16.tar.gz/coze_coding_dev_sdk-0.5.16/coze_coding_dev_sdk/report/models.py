from typing import Optional

from pydantic import BaseModel


class LogEntry(BaseModel):
    source: str
    project_id: Optional[str] = None
    env: Optional[str] = None
    method: str
    url: str
    request_body: Optional[str] = None
    response_body: Optional[str] = None
    status_code: Optional[int] = None
    error: Optional[str] = None
    duration_ms: float
    timestamp: int
    success: bool
