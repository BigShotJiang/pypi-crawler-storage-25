import threading
import time
from typing import Optional

from ..buffer import ReportBuffer
from ..models import LogEntry
from ..utils import redact_url, truncate


def create_boto3_report_hooks(buffer: ReportBuffer, source: str = "s3"):
    # We use thread_id to correlate before/after hooks because boto3's event
    # system does not pass a request-level correlation ID between hooks.
    # Limitation: thread ident can be reused in thread pools after a thread dies,
    # and nested boto3 calls on the same thread will overwrite the pending entry.
    # A periodic cleanup discards stale entries older than 5 minutes.
    _pending = {}
    _pending_lock = threading.Lock()
    _STALE_THRESHOLD = 300  # 5 minutes

    def _cleanup_stale():
        """Remove pending entries older than _STALE_THRESHOLD seconds."""
        now = time.time()
        stale_keys = [k for k, v in _pending.items() if now - v["start_time"] > _STALE_THRESHOLD]
        for k in stale_keys:
            _pending.pop(k, None)

    def before_hook(event_name, params, **kwargs):
        try:
            thread_id = threading.current_thread().ident
            url_parts = []
            if "url" in params:
                url_parts.append(params["url"])
            elif "endpoint_url" in kwargs:
                url_parts.append(kwargs["endpoint_url"])

            method = (params.get("method") or params.get("http_method") or "UNKNOWN") if isinstance(params, dict) else "UNKNOWN"

            request_body: Optional[str] = None
            body = params.get("body") if isinstance(params, dict) else None
            if body:
                try:
                    if isinstance(body, bytes):
                        request_body = truncate(body.decode("utf-8", errors="replace"))
                    elif isinstance(body, str):
                        request_body = truncate(body)
                except Exception:
                    pass

            with _pending_lock:
                _cleanup_stale()
                _pending[thread_id] = {
                    "start_time": time.time(),
                    "method": method,
                    "url": url_parts[0] if url_parts else "",
                    "request_body": request_body,
                }
        except Exception:
            pass

    def after_hook(event_name, parsed, **kwargs):
        try:
            thread_id = threading.current_thread().ident
            with _pending_lock:
                pending = _pending.pop(thread_id, None)
            if pending is None:
                return

            duration_ms = (time.time() - pending["start_time"]) * 1000
            http_response = kwargs.get("http_response")
            status_code: Optional[int] = None
            if http_response is not None:
                status_code = getattr(http_response, "status_code", None)

            success = 200 <= status_code < 300 if status_code else False

            response_body: Optional[str] = None
            if parsed:
                try:
                    import json
                    response_body = truncate(json.dumps(parsed, default=str))
                except Exception:
                    pass

            entry = LogEntry(
                source=source,
                method=pending["method"],
                url=redact_url(pending["url"]),
                request_body=pending.get("request_body"),
                response_body=response_body,
                status_code=status_code,
                error=None,
                duration_ms=duration_ms,
                timestamp=int(pending["start_time"] * 1000),
                success=success,
            )
            buffer.add(entry)
        except Exception:
            pass

    def error_hook(event_name, exception, **kwargs):
        """Handle failed S3 requests: clean up _pending and log the error."""
        try:
            thread_id = threading.current_thread().ident
            with _pending_lock:
                pending = _pending.pop(thread_id, None)
            if pending is None:
                return

            duration_ms = (time.time() - pending["start_time"]) * 1000

            entry = LogEntry(
                source=source,
                method=pending["method"],
                url=redact_url(pending["url"]),
                request_body=pending.get("request_body"),
                response_body=None,
                status_code=None,
                error=str(exception) if exception else "Unknown error",
                duration_ms=duration_ms,
                timestamp=int(pending["start_time"] * 1000),
                success=False,
            )
            buffer.add(entry)
        except Exception:
            pass

    return before_hook, after_hook, error_hook
