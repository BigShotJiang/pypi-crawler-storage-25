import time
from typing import Optional

import httpx

from ..buffer import ReportBuffer
from ..models import LogEntry
from ..utils import redact_url, truncate


def _safe_record(
    buffer: ReportBuffer,
    source: str,
    request: httpx.Request,
    response: Optional[httpx.Response],
    error: Optional[Exception],
    start_time: float,
) -> None:
    try:
        duration_ms = (time.time() - start_time) * 1000
        status_code = response.status_code if response else None
        success = 200 <= status_code < 300 if status_code else False

        request_body: Optional[str] = None
        try:
            raw = request.content
            if raw:
                request_body = truncate(raw.decode("utf-8", errors="replace"))
        except Exception:
            pass

        response_body: Optional[str] = None
        if response is not None:
            try:
                response_body = truncate(response.text)
            except Exception:
                pass

        entry = LogEntry(
            source=source,
            method=request.method,
            url=redact_url(str(request.url)),
            request_body=request_body,
            response_body=response_body,
            status_code=status_code,
            error=str(error) if error else None,
            duration_ms=duration_ms,
            timestamp=int(start_time * 1000),
            success=success,
        )
        buffer.add(entry)
    except Exception as e:
        print(f"[report] _safe_record error: {e}")


class InstrumentedTransport(httpx.BaseTransport):
    def __init__(
        self,
        transport: httpx.BaseTransport,
        buffer: ReportBuffer,
        source: str = "supabase",
    ):
        self._transport = transport
        self._buffer = buffer
        self._source = source

    def handle_request(self, request: httpx.Request) -> httpx.Response:
        start_time = time.time()
        try:
            response = self._transport.handle_request(request)
            _safe_record(self._buffer, self._source, request, response, None, start_time)
            return response
        except Exception as exc:
            _safe_record(self._buffer, self._source, request, None, exc, start_time)
            raise


class InstrumentedAsyncTransport(httpx.AsyncBaseTransport):
    def __init__(
        self,
        transport: httpx.AsyncBaseTransport,
        buffer: ReportBuffer,
        source: str = "supabase",
    ):
        self._transport = transport
        self._buffer = buffer
        self._source = source

    async def handle_async_request(self, request: httpx.Request) -> httpx.Response:
        start_time = time.time()
        try:
            response = await self._transport.handle_async_request(request)
            _safe_record(self._buffer, self._source, request, response, None, start_time)
            return response
        except Exception as exc:
            _safe_record(self._buffer, self._source, request, None, exc, start_time)
            raise
