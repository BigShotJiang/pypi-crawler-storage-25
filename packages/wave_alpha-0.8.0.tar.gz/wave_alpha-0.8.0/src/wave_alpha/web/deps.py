from __future__ import annotations

from datetime import date
from functools import lru_cache
from pathlib import Path

from wave_alpha.data.cached import CachedProvider
from wave_alpha.data.fallback import FallbackProvider
from wave_alpha.data.stooq import StooqProvider
from wave_alpha.data.yahoo import YahooProvider
from wave_alpha.llm.cache import LLMResponseCache
from wave_alpha.llm.client import AnthropicClient, CacheOnlyClient, LLMClient
from wave_alpha.llm.modes import LLMMode
from wave_alpha.llm.runner import LLMRunner
from wave_alpha.pipeline import AnalyzeRequest, AnalyzeResult, run_analysis
from wave_alpha.prefs.config import load_config, resolve_api_key, resolve_stooq_api_key


def _data_dir() -> Path:
    """Indirection so tests can monkeypatch the cache location."""
    return Path.home() / ".wave_alpha"


def analyze(ticker: str, as_of: date, *, llm_mode: LLMMode = LLMMode.DISABLED) -> AnalyzeResult:
    """Memoized wrapper. Key = (ticker, as_of, llm_mode). maxsize=8 covers a
    handful of active deep-dive pages; tests must `cache_clear()` between runs.
    """
    return _memoized_analyze(ticker.upper(), as_of, llm_mode)


@lru_cache(maxsize=8)
def _memoized_analyze(ticker: str, as_of: date, llm_mode: LLMMode) -> AnalyzeResult:
    return _run_analysis_uncached(ticker, as_of, llm_mode)


def _run_analysis_uncached(ticker: str, as_of: date, llm_mode: LLMMode) -> AnalyzeResult:
    data_dir = _data_dir()
    data_dir.mkdir(parents=True, exist_ok=True)
    cfg = load_config()
    stooq_key = resolve_stooq_api_key(cfg)
    provider = CachedProvider(
        upstream=FallbackProvider([YahooProvider(), StooqProvider(api_key=stooq_key)]),
        db_path=data_dir / "cache.sqlite",
    )
    runner: LLMRunner | None = None
    if llm_mode is not LLMMode.DISABLED:
        api_key = resolve_api_key(cfg)
        client: LLMClient
        if api_key:
            client = AnthropicClient(api_key=api_key, model=cfg.llm.scan_model)
        else:
            # CACHED mode without a key: use CacheOnlyClient (paper-reproducible
            # runs). LIVE mode without a key would fail at the AnthropicClient
            # constructor — same as CLI behavior. We mirror that by silently
            # falling back to a CacheOnlyClient here, which surfaces a
            # CachedResponseMissError on first cache miss.
            client = CacheOnlyClient(model=cfg.llm.scan_model)
        cache = LLMResponseCache(db_path=data_dir / "llm_cache.sqlite")
        runner = LLMRunner(client=client, cache=cache, mode=llm_mode)
    req = AnalyzeRequest(ticker=ticker, as_of=as_of)
    return run_analysis(
        req, provider=provider, llm_mode=llm_mode, llm_runner=runner, alpha=cfg.llm.alpha
    )
