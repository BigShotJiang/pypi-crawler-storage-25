from __future__ import annotations


def blend_scores(
    *,
    coh_multiplier: float,
    engine_score: float,
    llm_prob: float | None,
    alpha: float,
) -> float:
    """Final ranking per spec §6:

        final = coh_multiplier * (alpha * engine + (1 - alpha) * llm_prob)

    When ``llm_prob`` is None (mode=DISABLED or call skipped), the blend
    collapses to engine-only (alpha treated as 1.0).
    """
    if not 0.0 <= alpha <= 1.0:
        raise ValueError(f"alpha must be in [0, 1]; got {alpha}")
    if llm_prob is None:
        return coh_multiplier * engine_score
    return coh_multiplier * (alpha * engine_score + (1.0 - alpha) * llm_prob)
