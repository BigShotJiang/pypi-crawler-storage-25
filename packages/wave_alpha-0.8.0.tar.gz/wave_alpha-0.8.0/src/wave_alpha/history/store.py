"""SQLite persistence for history snapshots. Pure CRUD; no pipeline knowledge."""

from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from datetime import date, datetime
from pathlib import Path

from wave_alpha.history.models import Snapshot

_SCHEMA = """
CREATE TABLE IF NOT EXISTS snapshots (
    ticker          TEXT NOT NULL,
    as_of           TEXT NOT NULL,
    engine_version  TEXT NOT NULL,
    top_count_hash  TEXT NOT NULL,
    payload_json    TEXT NOT NULL,
    created_at      TEXT NOT NULL,
    PRIMARY KEY (ticker, as_of)
);
"""

_INDEX = """
CREATE INDEX IF NOT EXISTS idx_snapshots_ticker_as_of
    ON snapshots(ticker, as_of DESC);
"""


@dataclass(frozen=True)
class StoredRow:
    ticker: str
    as_of: date
    engine_version: str
    top_count_hash: str
    payload_json: str
    created_at: datetime


_INITIALIZED: set[Path] = set()


def _ensure_schema(db_path: Path) -> None:
    if db_path in _INITIALIZED:
        return
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(db_path)
    try:
        with conn:
            conn.execute(_SCHEMA)
            conn.execute(_INDEX)
    finally:
        conn.close()
    _INITIALIZED.add(db_path)


def upsert(snapshot: Snapshot, *, db_path: Path) -> None:
    _ensure_schema(db_path)
    payload = snapshot.model_dump_json()
    conn = sqlite3.connect(db_path)
    try:
        with conn:
            conn.execute(
                """
                INSERT INTO snapshots
                    (ticker, as_of, engine_version, top_count_hash, payload_json, created_at)
                VALUES (?, ?, ?, ?, ?, ?)
                ON CONFLICT(ticker, as_of) DO UPDATE SET
                    engine_version = excluded.engine_version,
                    top_count_hash = excluded.top_count_hash,
                    payload_json   = excluded.payload_json,
                    created_at     = excluded.created_at
                """,
                (
                    snapshot.ticker,
                    snapshot.as_of.isoformat(),
                    snapshot.engine_version,
                    snapshot.top_count_hash,
                    payload,
                    snapshot.created_at.isoformat(),
                ),
            )
    finally:
        conn.close()


def recent(ticker: str, n: int, *, db_path: Path) -> list[StoredRow]:
    if not db_path.exists():
        return []
    _ensure_schema(db_path)
    conn = sqlite3.connect(db_path)
    try:
        cursor = conn.execute(
            """
            SELECT ticker, as_of, engine_version, top_count_hash, payload_json, created_at
            FROM snapshots
            WHERE ticker = ?
            ORDER BY as_of DESC
            LIMIT ?
            """,
            (ticker, n),
        )
        rows = cursor.fetchall()
    finally:
        conn.close()
    return [
        StoredRow(
            ticker=r[0],
            as_of=date.fromisoformat(r[1]),
            engine_version=r[2],
            top_count_hash=r[3],
            payload_json=r[4],
            created_at=datetime.fromisoformat(r[5]),
        )
        for r in rows
    ]


def recent_across_all(*, db_path: Path, limit: int = 6) -> list[StoredRow]:
    """Return the most recent snapshots across all tickers, one row per ticker
    (its newest by `as_of`). Used by the Home page "Recently analyzed" card."""
    if not db_path.exists():
        return []
    _ensure_schema(db_path)
    conn = sqlite3.connect(db_path)
    try:
        cursor = conn.execute(
            """
            SELECT s.ticker, s.as_of, s.engine_version, s.top_count_hash,
                   s.payload_json, s.created_at
            FROM snapshots s
            JOIN (
                SELECT ticker, MAX(as_of) AS max_as_of
                FROM snapshots
                GROUP BY ticker
            ) latest
              ON latest.ticker = s.ticker
             AND latest.max_as_of = s.as_of
            ORDER BY s.as_of DESC, s.ticker ASC
            LIMIT ?
            """,
            (limit,),
        )
        rows = cursor.fetchall()
    finally:
        conn.close()
    return [
        StoredRow(
            ticker=r[0],
            as_of=date.fromisoformat(r[1]),
            engine_version=r[2],
            top_count_hash=r[3],
            payload_json=r[4],
            created_at=datetime.fromisoformat(r[5]),
        )
        for r in rows
    ]
