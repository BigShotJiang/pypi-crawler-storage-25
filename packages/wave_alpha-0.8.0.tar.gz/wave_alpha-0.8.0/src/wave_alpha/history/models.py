"""Pydantic models and frozen dataclasses for history snapshots."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime
from decimal import Decimal
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class SnapshotPivot(BaseModel):
    model_config = ConfigDict(frozen=True)

    timestamp: date
    price: Decimal


class SnapshotCount(BaseModel):
    model_config = ConfigDict(frozen=True)

    candidate_id: str
    pattern: str
    degree: int
    last_pivot_label: str
    pivots: list[SnapshotPivot]
    engine_score: float
    llm_prob: float | None
    final_score: float


class SnapshotSignal(BaseModel):
    model_config = ConfigDict(frozen=True)

    direction: Literal["long", "short"]
    entry_price: Decimal
    stop_price: Decimal
    target_price: Decimal
    rr: float


class SnapshotCoherence(BaseModel):
    model_config = ConfigDict(frozen=True)

    score: float
    multiplier: float
    pairwise: dict[str, float]
    fallback_used: str | None


class Snapshot(BaseModel):
    """A single (ticker, as_of) record. Pydantic ignores unknown fields by
    default, which is the forward-compat hook for v2 additive fields."""

    model_config = ConfigDict(frozen=True)

    ticker: str
    as_of: date
    engine_version: str
    top_3: list[SnapshotCount] = Field(..., min_length=1, max_length=3)
    signal: SnapshotSignal | None
    coherence: SnapshotCoherence | None
    top_count_hash: str
    created_at: datetime


@dataclass(frozen=True)
class StabilityBadge:
    streak: int
    matches_in_window: int
    window: int
    last_changed_on: date | None


@dataclass(frozen=True)
class RecentHistory:
    snapshots: list[Snapshot]
    badge: StabilityBadge | None
