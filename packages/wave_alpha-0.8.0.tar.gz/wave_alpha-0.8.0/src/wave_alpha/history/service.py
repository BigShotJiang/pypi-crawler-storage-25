"""Façade for the history package. Only thing call sites should import."""

from __future__ import annotations

import logging
from datetime import UTC, date, datetime
from pathlib import Path
from typing import TYPE_CHECKING

from wave_alpha import __version__
from wave_alpha.elliott.models import _PATTERN_LABELS
from wave_alpha.history import store
from wave_alpha.history.identity import top_count_hash
from wave_alpha.history.models import (
    RecentHistory,
    Snapshot,
    SnapshotCoherence,
    SnapshotCount,
    SnapshotPivot,
    SnapshotSignal,
    StabilityBadge,
)
from wave_alpha.history.store import StoredRow

if TYPE_CHECKING:
    from wave_alpha.coherence.score import CoherenceResult
    from wave_alpha.elliott.models import WaveCount
    from wave_alpha.pipeline import AnalyzeResult, RankedCount
    from wave_alpha.trades.models import TradeSignal

logger = logging.getLogger(__name__)

# Module-level alias for monkeypatch in tests (e.g. patch service.store.upsert).
__all__ = ["record_snapshot", "store"]


def _last_pivot_label(count: WaveCount) -> str:
    labels = _PATTERN_LABELS.get(count.pattern, [])
    if not labels or not count.pivots:
        return ""
    # pivots include the starting pivot before label "1"; segments = pivots-1
    # so the last completed wave label is at index len(pivots)-2 (clamped).
    idx = max(0, min(len(labels) - 1, len(count.pivots) - 2))
    return labels[idx]


def _to_snapshot_count(rc: RankedCount) -> SnapshotCount:
    return SnapshotCount(
        candidate_id=rc.candidate_id,
        pattern=rc.count.pattern,
        degree=rc.count.degree,
        last_pivot_label=_last_pivot_label(rc.count),
        pivots=[SnapshotPivot(timestamp=p.timestamp, price=p.price) for p in rc.count.pivots],
        engine_score=rc.engine_score,
        llm_prob=rc.llm_prob,
        final_score=rc.final_score,
    )


def _to_snapshot_signal(sig: TradeSignal | None) -> SnapshotSignal | None:
    if sig is None:
        return None
    return SnapshotSignal(
        direction=sig.direction,
        entry_price=sig.entry_price,
        stop_price=sig.stop_price,
        target_price=sig.target_price,
        rr=sig.rr,
    )


def _to_snapshot_coherence(coh: CoherenceResult | None) -> SnapshotCoherence | None:
    if coh is None:
        return None
    return SnapshotCoherence(
        score=coh.score,
        multiplier=coh.multiplier,
        pairwise=dict(coh.pairwise),
        fallback_used=coh.fallback_used,
    )


def _build_snapshot(result: AnalyzeResult, ticker: str, as_of: date) -> Snapshot:
    top_3 = [_to_snapshot_count(rc) for rc in result.ranked_daily[:3]]
    signal = _to_snapshot_signal(result.signals[0] if result.signals else None)
    coherence = _to_snapshot_coherence(result.coherence)
    return Snapshot(
        ticker=ticker,
        as_of=as_of,
        engine_version=__version__,
        top_3=top_3,
        signal=signal,
        coherence=coherence,
        top_count_hash=top_count_hash(result.ranked_daily[0].count),
        created_at=datetime.now(tz=UTC),
    )


def _compute_badge(rows: list[StoredRow]) -> StabilityBadge | None:
    if len(rows) < 2:
        return None
    current = rows[0].top_count_hash
    streak = 1
    last_changed: date | None = None
    for r in rows[1:]:
        if r.top_count_hash == current:
            streak += 1
        else:
            last_changed = r.as_of
            break
    matches = sum(1 for r in rows if r.top_count_hash == current)
    return StabilityBadge(
        streak=streak,
        matches_in_window=matches,
        window=len(rows),
        last_changed_on=last_changed,
    )


def get_recent_with_badge(ticker: str, *, n: int = 14, db_path: Path) -> RecentHistory:
    rows = store.recent(ticker, n, db_path=db_path)
    snapshots = [Snapshot.model_validate_json(r.payload_json) for r in rows]
    badge = _compute_badge(rows)
    return RecentHistory(snapshots=snapshots, badge=badge)


def record_snapshot(
    result: AnalyzeResult,
    ticker: str,
    as_of: date,
    *,
    db_path: Path,
) -> None:
    """Persist `result` as a snapshot. Side-effect only — never raises."""
    if not result.ranked_daily:
        return
    try:
        snapshot = _build_snapshot(result, ticker, as_of)
        store.upsert(snapshot, db_path=db_path)
    except Exception as exc:
        logger.warning("history snapshot failed for %s @ %s: %s", ticker, as_of, exc)
