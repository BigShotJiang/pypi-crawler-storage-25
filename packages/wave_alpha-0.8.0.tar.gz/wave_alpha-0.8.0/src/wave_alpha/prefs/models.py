from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class LLMConfig(BaseModel):
    model_config = ConfigDict(frozen=True)

    api_key: str | None = None
    scan_model: str = "claude-haiku-4-5-20251001"
    deep_model: str = "claude-sonnet-4-6"
    alpha: float = Field(default=0.6, ge=0.0, le=1.0)


class RightEdgeConfig(BaseModel):
    model_config = ConfigDict(frozen=True)

    model: Literal["auto", "heuristic", "calibrated_heuristic", "logistic"] = "auto"


class DataConfig(BaseModel):
    model_config = ConfigDict(frozen=True)

    stooq_api_key: str | None = None


class AppConfig(BaseModel):
    model_config = ConfigDict(frozen=True)

    llm: LLMConfig = Field(default_factory=LLMConfig)
    right_edge: RightEdgeConfig = Field(default_factory=RightEdgeConfig)
    data: DataConfig = Field(default_factory=DataConfig)
