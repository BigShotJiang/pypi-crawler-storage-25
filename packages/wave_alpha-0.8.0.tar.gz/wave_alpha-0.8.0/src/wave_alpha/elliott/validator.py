from __future__ import annotations

from wave_alpha.elliott.dsl import evaluate
from wave_alpha.elliott.models import WaveCount, WaveSegment
from wave_alpha.elliott.templates import PatternTemplate


def validate(count: WaveCount, template: PatternTemplate) -> WaveCount:
    """Run all template constraints and return a copy with violation lists populated."""
    bindings = _segment_bindings(count, template)
    hard: list[str] = []
    soft: list[str] = []
    for c in template.constraints:
        ok, _ = evaluate(c.expr, bindings=bindings)
        if not ok:
            (hard if c.severity == "hard" else soft).append(c.name)
    return count.model_copy(update={"hard_violations": hard, "soft_violations": soft})


def _segment_bindings(count: WaveCount, template: PatternTemplate) -> dict[str, WaveSegment]:
    segs = count.segments()
    bindings: dict[str, WaveSegment] = {}
    for label, seg in zip(template.waves, segs, strict=False):
        bindings[f"W{label}"] = seg
    return bindings
