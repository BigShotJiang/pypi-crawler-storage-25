from __future__ import annotations

from pathlib import Path
from typing import Literal

import yaml
from pydantic import BaseModel, ConfigDict


class Constraint(BaseModel):
    model_config = ConfigDict(frozen=True)

    name: str
    severity: Literal["hard", "soft"]
    expr: str
    rationale: str = ""


class PatternTemplate(BaseModel):
    model_config = ConfigDict(frozen=True)

    name: str
    direction_alternates: bool = True
    waves: list[str]
    constraints: list[Constraint]
    allowed_sub_patterns: dict[str, list[str]] = {}

    @classmethod
    def load_bundled(cls, name: str) -> PatternTemplate:
        path = _bundled_dir() / f"{name}.yaml"
        return cls.from_yaml_file(path)

    @classmethod
    def from_yaml_file(cls, path: Path) -> PatternTemplate:
        return cls.model_validate(yaml.safe_load(path.read_text()))


def _bundled_dir() -> Path:
    return Path(__file__).resolve().parent / "templates_data"


def load_bundled_templates() -> list[PatternTemplate]:
    return [PatternTemplate.from_yaml_file(p) for p in sorted(_bundled_dir().glob("*.yaml"))]
