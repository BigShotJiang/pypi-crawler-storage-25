from wave_alpha.prefs.models import AppConfig, LLMConfig


def test_llm_config_defaults() -> None:
    cfg = LLMConfig()
    assert cfg.scan_model == "claude-haiku-4-5-20251001"
    assert cfg.deep_model == "claude-sonnet-4-6"
    assert cfg.alpha == 0.6
    assert cfg.api_key is None


def test_app_config_defaults() -> None:
    cfg = AppConfig()
    assert isinstance(cfg.llm, LLMConfig)
