import logging
from datetime import date
from decimal import Decimal
from pathlib import Path

import pytest

from wave_alpha.coherence.score import CoherenceResult
from wave_alpha.domain import Interval
from wave_alpha.elliott.models import WaveCount
from wave_alpha.history import service, store
from wave_alpha.history.models import Snapshot
from wave_alpha.pipeline import AnalyzeResult, RankedCount
from wave_alpha.pivots.models import PivotEvent, PivotState, PivotType
from wave_alpha.trades.models import TradeSignal


def _pivots() -> list[PivotEvent]:
    return [
        PivotEvent(
            degree=1,
            timestamp=date(2024, 1, 1),
            price=Decimal("100"),
            interval=Interval.DAILY,
            type=PivotType.LOW,
            state=PivotState.CONFIRMED,
        ),
        PivotEvent(
            degree=1,
            timestamp=date(2024, 2, 1),
            price=Decimal("110"),
            interval=Interval.DAILY,
            type=PivotType.HIGH,
            state=PivotState.CONFIRMED,
        ),
        PivotEvent(
            degree=1,
            timestamp=date(2024, 3, 1),
            price=Decimal("105"),
            interval=Interval.DAILY,
            type=PivotType.LOW,
            state=PivotState.CONFIRMED,
        ),
        PivotEvent(
            degree=1,
            timestamp=date(2024, 6, 1),
            price=Decimal("130"),
            interval=Interval.DAILY,
            type=PivotType.HIGH,
            state=PivotState.CONFIRMED,
        ),
    ]


def _wc(pattern: str = "impulse", score: float = 0.7) -> WaveCount:
    return WaveCount(pattern=pattern, degree=1, pivots=_pivots(), score=score)


def _ranked(score: float = 0.7) -> RankedCount:
    return RankedCount(
        candidate_id="C1",
        count=_wc(score=score),
        engine_score=score,
        llm_prob=None,
        final_score=score,
    )


def _signal() -> TradeSignal:
    return TradeSignal(
        ticker="AAPL",
        as_of=date(2024, 6, 1),
        direction="long",
        entry_price=Decimal("130.00"),
        stop_price=Decimal("125.00"),
        target_price=Decimal("145.00"),
        count_id="C1",
        count_pattern="impulse",
        wave_label="3",
        degree=1,
        confidence=0.7,
        expected_bars_to_target=20,
        max_holding_bars=60,
    )


def _coh(score: float = 0.8) -> CoherenceResult:
    return CoherenceResult(
        score=score, multiplier=1.05, pairwise={"weekly_daily": score}, fallback_used=None
    )


def _result(*, ranked: list[RankedCount] | None = None) -> AnalyzeResult:
    if ranked is None:
        ranked = [_ranked()]
    return AnalyzeResult(
        ticker="AAPL",
        as_of=date(2024, 6, 1),
        ranked_daily=ranked,
        signals=[_signal()] if ranked else [],
        coherence=_coh() if ranked else None,
    )


@pytest.fixture
def db_path(tmp_path: Path) -> Path:
    return tmp_path / "history.sqlite"


def test_record_snapshot_writes_a_row(db_path: Path) -> None:
    service.record_snapshot(_result(), "AAPL", date(2024, 6, 1), db_path=db_path)
    rows = store.recent("AAPL", 10, db_path=db_path)
    assert len(rows) == 1
    snap = Snapshot.model_validate_json(rows[0].payload_json)
    assert snap.ticker == "AAPL"
    assert snap.as_of == date(2024, 6, 1)
    assert snap.top_3[0].pattern == "impulse"
    assert snap.signal is not None
    assert snap.signal.direction == "long"
    assert snap.coherence is not None
    assert snap.coherence.score == pytest.approx(0.8)
    assert len(snap.top_count_hash) == 16
    # created_at is stamped during the call (within 10 seconds)
    from datetime import UTC, datetime

    delta = abs((datetime.now(tz=UTC) - snap.created_at).total_seconds())
    assert delta < 10, f"created_at not recent: delta={delta}s"


def test_record_snapshot_skips_when_ranked_daily_empty(db_path: Path) -> None:
    empty = AnalyzeResult(ticker="AAPL", as_of=date(2024, 6, 1))
    service.record_snapshot(empty, "AAPL", date(2024, 6, 1), db_path=db_path)
    assert store.recent("AAPL", 10, db_path=db_path) == []


def test_record_snapshot_swallows_store_errors(
    db_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
) -> None:
    def boom(*args, **kwargs):
        raise RuntimeError("disk full")

    monkeypatch.setattr(service.store, "upsert", boom)
    with caplog.at_level(logging.WARNING, logger="wave_alpha.history.service"):
        service.record_snapshot(_result(), "AAPL", date(2024, 6, 1), db_path=db_path)
    assert any("history snapshot failed" in rec.message for rec in caplog.records)


def test_record_snapshot_caps_top_3_at_three(db_path: Path) -> None:
    five = [_ranked(score=0.9 - 0.1 * i) for i in range(5)]
    service.record_snapshot(_result(ranked=five), "AAPL", date(2024, 6, 1), db_path=db_path)
    rows = store.recent("AAPL", 10, db_path=db_path)
    snap = Snapshot.model_validate_json(rows[0].payload_json)
    assert len(snap.top_3) == 3


def test_record_snapshot_idempotent_on_repeat(db_path: Path) -> None:
    service.record_snapshot(_result(), "AAPL", date(2024, 6, 1), db_path=db_path)
    service.record_snapshot(_result(), "AAPL", date(2024, 6, 1), db_path=db_path)
    rows = store.recent("AAPL", 10, db_path=db_path)
    assert len(rows) == 1
