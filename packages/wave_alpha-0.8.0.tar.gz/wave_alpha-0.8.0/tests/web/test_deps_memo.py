from datetime import date
from unittest.mock import MagicMock, patch

from wave_alpha.llm.modes import LLMMode
from wave_alpha.web import deps


def test_analyze_memoized_dedupes_repeat_calls() -> None:
    deps._memoized_analyze.cache_clear()
    with patch.object(deps, "_run_analysis_uncached") as mock:
        mock.return_value = MagicMock()
        deps.analyze("AAPL", date(2024, 1, 5), llm_mode=LLMMode.DISABLED)
        deps.analyze("AAPL", date(2024, 1, 5), llm_mode=LLMMode.DISABLED)
        deps.analyze("AAPL", date(2024, 1, 5), llm_mode=LLMMode.DISABLED)
        assert mock.call_count == 1


def test_analyze_memoized_keys_on_ticker_as_of_mode() -> None:
    deps._memoized_analyze.cache_clear()
    with patch.object(deps, "_run_analysis_uncached") as mock:
        mock.return_value = MagicMock()
        deps.analyze("AAPL", date(2024, 1, 5), llm_mode=LLMMode.DISABLED)
        deps.analyze("MSFT", date(2024, 1, 5), llm_mode=LLMMode.DISABLED)
        deps.analyze("AAPL", date(2024, 1, 6), llm_mode=LLMMode.DISABLED)
        deps.analyze("AAPL", date(2024, 1, 5), llm_mode=LLMMode.LIVE)
        assert mock.call_count == 4


def test_analyze_cache_clear_works() -> None:
    deps._memoized_analyze.cache_clear()
    with patch.object(deps, "_run_analysis_uncached") as mock:
        mock.return_value = MagicMock()
        deps.analyze("AAPL", date(2024, 1, 5), llm_mode=LLMMode.DISABLED)
        deps._memoized_analyze.cache_clear()
        deps.analyze("AAPL", date(2024, 1, 5), llm_mode=LLMMode.DISABLED)
        assert mock.call_count == 2
