from wave_alpha.elliott.templates import PatternTemplate, load_bundled_templates


def test_impulse_template_has_three_hard_constraints() -> None:
    tpl = PatternTemplate.load_bundled("impulse")
    assert tpl.name == "impulse"
    assert len(tpl.waves) == 5
    hard = [c for c in tpl.constraints if c.severity == "hard"]
    hard_names = {c.name for c in hard}
    assert {"wave_2_max_retrace", "wave_3_not_shortest", "wave_4_no_overlap"} <= hard_names


def test_load_bundled_returns_all_v0_1_patterns() -> None:
    tpls = load_bundled_templates()
    names = {t.name for t in tpls}
    assert {
        "impulse",
        "zigzag",
        "flat",
        "expanded_flat",
        "contracting_triangle",
        "ending_diagonal",
    } <= names
