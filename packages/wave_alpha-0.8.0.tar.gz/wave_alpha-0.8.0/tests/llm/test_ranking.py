import pytest

from wave_alpha.llm.ranking import blend_scores


def test_alpha_one_returns_engine_score_times_multiplier() -> None:
    assert blend_scores(
        coh_multiplier=1.0, engine_score=0.6, llm_prob=0.9, alpha=1.0
    ) == pytest.approx(0.6)


def test_alpha_zero_returns_llm_prob_times_multiplier() -> None:
    assert blend_scores(
        coh_multiplier=1.0, engine_score=0.6, llm_prob=0.9, alpha=0.0
    ) == pytest.approx(0.9)


def test_alpha_default_is_engine_dominant() -> None:
    blended = blend_scores(coh_multiplier=1.0, engine_score=0.6, llm_prob=0.9, alpha=0.6)
    assert blended == pytest.approx(0.6 * 0.6 + 0.4 * 0.9)


def test_coherence_multiplier_scales_result() -> None:
    base = blend_scores(coh_multiplier=1.0, engine_score=0.5, llm_prob=0.5, alpha=0.6)
    scaled = blend_scores(coh_multiplier=1.2, engine_score=0.5, llm_prob=0.5, alpha=0.6)
    assert scaled == pytest.approx(1.2 * base)


def test_llm_disabled_via_none_treats_alpha_as_one() -> None:
    """When LLM is disabled, llm_prob=None means the blend is engine-only."""
    assert blend_scores(
        coh_multiplier=1.0, engine_score=0.6, llm_prob=None, alpha=0.6
    ) == pytest.approx(0.6)


def test_alpha_out_of_range_raises() -> None:
    with pytest.raises(ValueError):
        blend_scores(coh_multiplier=1.0, engine_score=0.6, llm_prob=0.5, alpha=1.5)
