from datetime import date
from decimal import Decimal

from wave_alpha.data.cache import OHLCVCache
from wave_alpha.domain import Bar, Interval


def _bar(d: date, price: str) -> Bar:
    p = Decimal(price)
    return Bar(timestamp=d, open=p, high=p, low=p, close=p, volume=1)


def test_cache_roundtrip(tmp_path) -> None:
    cache = OHLCVCache(db_path=tmp_path / "cache.sqlite")
    bars = [_bar(date(2024, 1, d), "100") for d in (2, 3, 4)]
    cache.put("AAPL", Interval.DAILY, bars)
    out = cache.get("AAPL", Interval.DAILY)
    assert [b.timestamp for b in out] == [b.timestamp for b in bars]


def test_cache_upsert_replaces_overlapping_dates(tmp_path) -> None:
    cache = OHLCVCache(db_path=tmp_path / "cache.sqlite")
    cache.put("AAPL", Interval.DAILY, [_bar(date(2024, 1, 2), "100")])
    cache.put("AAPL", Interval.DAILY, [_bar(date(2024, 1, 2), "200")])
    out = cache.get("AAPL", Interval.DAILY)
    assert len(out) == 1
    assert out[0].close == Decimal("200")


def test_cache_isolates_intervals(tmp_path) -> None:
    cache = OHLCVCache(db_path=tmp_path / "cache.sqlite")
    cache.put("AAPL", Interval.DAILY, [_bar(date(2024, 1, 2), "100")])
    cache.put("AAPL", Interval.WEEKLY, [_bar(date(2024, 1, 5), "200")])
    assert len(cache.get("AAPL", Interval.DAILY)) == 1
    assert cache.get("AAPL", Interval.DAILY)[0].close == Decimal("100")
