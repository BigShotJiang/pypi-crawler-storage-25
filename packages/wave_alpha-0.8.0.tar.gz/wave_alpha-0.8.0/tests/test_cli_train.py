"""End-to-end smoke test for `wave-alpha train right-edge`."""

from __future__ import annotations

from datetime import date, timedelta
from decimal import Decimal
from pathlib import Path

from typer.testing import CliRunner

from wave_alpha.cli.app import app
from wave_alpha.domain import Bar, Interval

runner = CliRunner()


class _SyntheticProvider:
    """Fake OHLCV provider that emits a trending bar series over 2+ years.

    Returns the same series for every ticker so the training pipeline has
    real pivot structure to label without touching the network.
    """

    def fetch(self, ticker: str, interval: Interval, *, end: date) -> list[Bar]:
        bars: list[Bar] = []
        d = date(2021, 1, 1)
        i = 0
        # zig-zag: rise for 20 bars, fall for 20 bars, repeat
        while d <= date(2022, 9, 30):
            if d.weekday() < 5:
                phase = (i // 20) % 2
                price = 100.0 + (i % 20) * 2.0 if phase == 0 else 140.0 - (i % 20) * 2.0
                bars.append(
                    Bar(
                        timestamp=d,
                        open=Decimal(str(round(price - 0.5, 2))),
                        high=Decimal(str(round(price + 1.0, 2))),
                        low=Decimal(str(round(price - 1.0, 2))),
                        close=Decimal(str(round(price, 2))),
                        volume=10_000,
                    )
                )
                i += 1
            d = d + timedelta(days=1)
        return bars


def test_train_right_edge_help() -> None:
    res = runner.invoke(app, ["train", "--help"])
    assert res.exit_code == 0
    assert "right-edge" in res.stdout


def test_train_right_edge_runs_end_to_end(tmp_path: Path, monkeypatch) -> None:
    """Full pipeline: assemble rows → walk-forward → gate → print verdict.

    After the warmup-window fix, as_of_pairs spans ALL quarters from start to end
    (not just fold test windows), so training data includes warmup quarters.
    This means n_train_rows > n_oos_rows when there are ≥5 quarters in the range.
    """
    universe_file = tmp_path / "universe.txt"
    universe_file.write_text("AAPL\nMSFT\n# comment line\n\n")

    from wave_alpha.cli import app as app_module

    monkeypatch.setattr(app_module, "_default_provider", lambda: _SyntheticProvider())

    res = runner.invoke(
        app,
        [
            "train",
            "right-edge",
            "--universe",
            str(universe_file),
            "--start",
            "2021-01-01",
            "--end",
            "2022-07-01",
            "--seed",
            "42",
        ],
    )
    assert res.exit_code == 0, res.stdout
    assert "Verdict:" in res.stdout

    # Parse "  → N train rows, M OOS predictions" line to verify warmup rows are present.
    # Training data spans ALL quarters (including warmup), OOS only the test folds.
    import re

    m = re.search(r"(\d+) train rows, (\d+) OOS", res.stdout)
    if m:
        n_train = int(m.group(1))
        n_oos = int(m.group(2))
        assert n_train > n_oos, (
            f"Expected n_train_rows ({n_train}) > n_oos_rows ({n_oos}); "
            "warmup quarters should contribute training rows that are not OOS."
        )


def test_train_right_edge_no_folds_exits_1(tmp_path: Path, monkeypatch) -> None:
    """Too short a date range → no folds → exit 1."""
    universe_file = tmp_path / "universe.txt"
    universe_file.write_text("AAPL\n")

    from wave_alpha.cli import app as app_module

    monkeypatch.setattr(app_module, "_default_provider", lambda: _SyntheticProvider())

    res = runner.invoke(
        app,
        [
            "train",
            "right-edge",
            "--universe",
            str(universe_file),
            "--start",
            "2021-01-01",
            "--end",
            "2021-06-01",  # < 4 full quarters → empty folds
        ],
    )
    assert res.exit_code == 1


def test_train_right_edge_write_without_promote_exits_1(tmp_path: Path, monkeypatch) -> None:
    """--write without --force on a non-PROMOTE verdict should exit 1."""
    universe_file = tmp_path / "universe.txt"
    universe_file.write_text("AAPL\n")
    output_path = tmp_path / "model.json"

    from wave_alpha.cli import app as app_module

    monkeypatch.setattr(app_module, "_default_provider", lambda: _SyntheticProvider())

    # Patch evaluate_promotion to always return HOLD so we can test the write gate
    # without relying on the actual verdict from a small synthetic dataset.
    import wave_alpha.cli.app as _cli_app
    from wave_alpha.right_edge.promotion import GateResult

    def _fake_evaluate(**kwargs):
        return GateResult(
            verdict="HOLD",
            logistic_brier_ci=(0.2, 0.25, 0.3),
            heuristic_brier_ci=(0.18, 0.22, 0.28),
            per_degree_calibration={},
        )

    monkeypatch.setattr(_cli_app, "_evaluate_promotion", _fake_evaluate)

    res = runner.invoke(
        app,
        [
            "train",
            "right-edge",
            "--universe",
            str(universe_file),
            "--start",
            "2021-01-01",
            "--end",
            "2022-07-01",
            "--write",
            "--output",
            str(output_path),
        ],
    )
    assert res.exit_code == 1
    assert not output_path.exists()


def test_train_right_edge_write_force_writes_anyway(tmp_path: Path, monkeypatch) -> None:
    """--write --force on a HOLD verdict writes the artifact."""
    universe_file = tmp_path / "universe.txt"
    universe_file.write_text("AAPL\n")
    output_path = tmp_path / "model.json"

    from wave_alpha.cli import app as app_module

    monkeypatch.setattr(app_module, "_default_provider", lambda: _SyntheticProvider())

    import wave_alpha.cli.app as _cli_app
    from wave_alpha.right_edge.promotion import GateResult

    def _fake_evaluate(**kwargs):
        return GateResult(
            verdict="HOLD",
            logistic_brier_ci=(0.2, 0.25, 0.3),
            heuristic_brier_ci=(0.18, 0.22, 0.28),
            per_degree_calibration={},
        )

    monkeypatch.setattr(_cli_app, "_evaluate_promotion", _fake_evaluate)

    res = runner.invoke(
        app,
        [
            "train",
            "right-edge",
            "--universe",
            str(universe_file),
            "--start",
            "2021-01-01",
            "--end",
            "2022-07-01",
            "--write",
            "--force",
            "--output",
            str(output_path),
        ],
    )
    assert res.exit_code == 0, res.stdout
    assert output_path.exists()


# ---------------------------------------------------------------------------
# Phase 3 — train calibrated-heuristic CLI smoke tests
# ---------------------------------------------------------------------------


def test_train_calibrated_heuristic_help() -> None:
    """calibrated-heuristic subcommand is registered and shows in train --help."""
    res = runner.invoke(app, ["train", "--help"])
    assert res.exit_code == 0
    assert "calibrated-heuristic" in res.stdout


def test_train_calibrated_heuristic_runs_end_to_end(tmp_path: Path, monkeypatch) -> None:
    """Full calibrated-heuristic pipeline: rows → fit Platt → gate → print verdict."""
    universe_file = tmp_path / "universe.txt"
    universe_file.write_text("AAPL\nMSFT\n# comment line\n\n")

    from wave_alpha.cli import app as app_module

    monkeypatch.setattr(app_module, "_default_provider", lambda: _SyntheticProvider())

    res = runner.invoke(
        app,
        [
            "train",
            "calibrated-heuristic",
            "--universe",
            str(universe_file),
            "--start",
            "2021-01-01",
            "--end",
            "2022-07-01",
            "--seed",
            "42",
        ],
    )
    assert res.exit_code == 0, res.stdout
    assert "Verdict:" in res.stdout
    # Output uses "Calibrated-heuristic" vs "Raw heuristic" labels (not "Logistic").
    assert "Calibrated-heuristic" in res.stdout
    assert "Raw heuristic" in res.stdout


def test_train_calibrated_heuristic_write_without_promote_exits_1(
    tmp_path: Path, monkeypatch
) -> None:
    """--write without --force on a non-PROMOTE verdict should exit 1."""
    universe_file = tmp_path / "universe.txt"
    universe_file.write_text("AAPL\n")
    output_path = tmp_path / "cal_model.json"

    from wave_alpha.cli import app as app_module

    monkeypatch.setattr(app_module, "_default_provider", lambda: _SyntheticProvider())

    import wave_alpha.cli.app as _cli_app
    from wave_alpha.right_edge.promotion import GateResult

    def _fake_evaluate(**kwargs):
        return GateResult(
            verdict="HOLD",
            logistic_brier_ci=(0.2, 0.25, 0.3),
            heuristic_brier_ci=(0.18, 0.22, 0.28),
            per_degree_calibration={},
        )

    monkeypatch.setattr(_cli_app, "_evaluate_promotion", _fake_evaluate)

    res = runner.invoke(
        app,
        [
            "train",
            "calibrated-heuristic",
            "--universe",
            str(universe_file),
            "--start",
            "2021-01-01",
            "--end",
            "2022-07-01",
            "--write",
            "--output",
            str(output_path),
        ],
    )
    assert res.exit_code == 1
    assert not output_path.exists()


def test_train_calibrated_heuristic_write_force_writes_anyway(tmp_path: Path, monkeypatch) -> None:
    """--write --force on a HOLD verdict writes the artifact."""
    universe_file = tmp_path / "universe.txt"
    universe_file.write_text("AAPL\n")
    output_path = tmp_path / "cal_model.json"

    from wave_alpha.cli import app as app_module

    monkeypatch.setattr(app_module, "_default_provider", lambda: _SyntheticProvider())

    import wave_alpha.cli.app as _cli_app
    from wave_alpha.right_edge.promotion import GateResult

    def _fake_evaluate(**kwargs):
        return GateResult(
            verdict="HOLD",
            logistic_brier_ci=(0.2, 0.25, 0.3),
            heuristic_brier_ci=(0.18, 0.22, 0.28),
            per_degree_calibration={},
        )

    monkeypatch.setattr(_cli_app, "_evaluate_promotion", _fake_evaluate)

    res = runner.invoke(
        app,
        [
            "train",
            "calibrated-heuristic",
            "--universe",
            str(universe_file),
            "--start",
            "2021-01-01",
            "--end",
            "2022-07-01",
            "--write",
            "--force",
            "--output",
            str(output_path),
        ],
    )
    assert res.exit_code == 0, res.stdout
    assert output_path.exists()

    # Verify the artifact has the expected structure.
    import json

    artifact = json.loads(output_path.read_text())
    assert artifact["version"] == "calibrated_heuristic_v1"
    assert "platt_per_degree" in artifact
    assert "gate" in artifact
    assert artifact["gate"]["verdict"] == "HOLD"


def test_train_calibrated_heuristic_write_promote_calibration_writes_artifact(
    tmp_path: Path, monkeypatch
) -> None:
    """--write on a PROMOTE_CALIBRATION verdict writes the artifact without --force."""
    universe_file = tmp_path / "universe.txt"
    universe_file.write_text("AAPL\n")
    output_path = tmp_path / "cal_model.json"

    from wave_alpha.cli import app as app_module

    monkeypatch.setattr(app_module, "_default_provider", lambda: _SyntheticProvider())

    import wave_alpha.cli.app as _cli_app
    from wave_alpha.right_edge.promotion import GateResult

    def _fake_evaluate(**kwargs):
        return GateResult(
            verdict="PROMOTE_CALIBRATION",
            logistic_brier_ci=(0.2, 0.25, 0.3),
            heuristic_brier_ci=(0.22, 0.26, 0.32),
            per_degree_calibration={1: {"logistic": 0.05, "heuristic": 0.18}},
        )

    monkeypatch.setattr(_cli_app, "_evaluate_promotion", _fake_evaluate)

    res = runner.invoke(
        app,
        [
            "train",
            "calibrated-heuristic",
            "--universe",
            str(universe_file),
            "--start",
            "2021-01-01",
            "--end",
            "2022-07-01",
            "--write",
            "--output",
            str(output_path),
        ],
    )
    assert res.exit_code == 0, res.stdout
    assert output_path.exists()

    import json

    artifact = json.loads(output_path.read_text())
    assert artifact["gate"]["verdict"] == "PROMOTE_CALIBRATION"
