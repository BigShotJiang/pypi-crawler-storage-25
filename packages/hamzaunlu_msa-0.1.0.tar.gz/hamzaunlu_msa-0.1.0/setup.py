from setuptools import setup, find_packages
 
setup(
    name             = "hamzaunlu_msa",
    version          = "0.1.0",
    packages         = find_packages(),
    install_requires = ["numpy"],
    author           = "Hamza",
    description      = "Needleman-Wunsch (Global DP) tabanlı Çoklu Dizi Hizalama",
    python_requires  = ">=3.8",
)