# hamzaunlu_msa

Needleman-Wunsch (Global Alignment) tabanlı Çoklu Dizi Hizalama kütüphanesi.

## Kurulum

pip install hamzaunlu_msa

## Kullanım

```python
from hamzaunlu_msa import msa

diziler = ["ATCGTA", "ATCGGA", "TTCGTA"]
sonuc = msa(diziler)

for dizi in sonuc:
    print(dizi)
```

## Algoritma

Needleman-Wunsch global hizalama algoritması temelinde ardışık (progressive) hizalama uygulanmıştır.