import numpy as np

match    =  1
mismatch = -1
gap      = -1


def score_matrix(x, y):
    s = np.zeros([len(x)+1, len(y)+1])

    for i in range(1, len(x)+1):
        s[i, 0] = s[i-1, 0] + gap

    for j in range(1, len(y)+1):
        s[0, j] = s[0, j-1] + gap

    for i in range(1, len(x)+1):
        for j in range(1, len(y)+1):
            if x[i-1] == y[j-1]:
                a = s[i-1, j-1] + match
            else:
                a = s[i-1, j-1] + mismatch
            b = s[i-1, j] + gap
            c = s[i, j-1] + gap
            s[i, j] = max(a, b, c)

    return s


def traceback(s, x, y):
    aligned_x = ""
    aligned_y = ""
    i = len(x)
    j = len(y)

    while i > 0 or j > 0:
        if i > 0 and j > 0 and s[i, j] == s[i-1, j-1] + (match if x[i-1] == y[j-1] else mismatch):
            # Çaprazdan geldik: eşleşme veya yanlış eşleşme
            aligned_x = x[i-1] + aligned_x
            aligned_y = y[j-1] + aligned_y
            i -= 1
            j -= 1
        elif i > 0 and s[i, j] == s[i-1, j] + gap:
            # Yukarıdan geldik: y'ye gap ekle
            aligned_x = x[i-1] + aligned_x
            aligned_y = "-" + aligned_y
            i -= 1
        else:
            # Soldan geldik: x'e gap ekle
            aligned_x = "-" + aligned_x
            aligned_y = y[j-1] + aligned_y
            j -= 1

    return aligned_x, aligned_y


def pairwise_align(x, y):
    s = score_matrix(x, y)
    return traceback(s, x, y)


def _gap_ekle(orijinal, gapli_referans):
    # gapli_referans'taki gap konumlarını orijinal diziye uygular
    sonuc = ""
    it = iter(orijinal)
    for karakter in gapli_referans:
        if karakter == "-":
            sonuc += "-"
        else:
            sonuc += next(it, "-")
    return sonuc


def msa(sequences):
    if len(sequences) < 2:
        raise ValueError("En az 2 dizi gereklidir.")

    a1, a2 = pairwise_align(sequences[0], sequences[1])
    sonuc = [a1, a2]

    for yeni_dizi in sequences[2:]:
        temsil = sonuc[0].replace("-", "")
        yeni_temsil, yeni_aligned = pairwise_align(temsil, yeni_dizi)

        guncellenmis = []
        for mevcut in sonuc:
            guncellenmis.append(_gap_ekle(mevcut.replace("-", ""), yeni_temsil))
        guncellenmis.append(yeni_aligned)
        sonuc = guncellenmis

    return sonuc