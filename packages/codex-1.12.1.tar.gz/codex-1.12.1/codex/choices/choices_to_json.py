#!/usr/bin/env python3
"""Dump choices to JSON."""

import json
from collections.abc import Mapping
from pathlib import Path
from types import MappingProxyType

from caseconverter import camelcase

from codex.choices.admin import ADMIN_FLAG_CHOICES
from codex.choices.browser import (
    BROWSER_CHOICES,
    BROWSER_CHOICES_MAP_KEYS,
    BROWSER_CHOICES_VUETIFY_KEYS,
    BROWSER_DEFAULTS,
    BROWSER_TABLE_COLUMN_COSTS,
    BROWSER_TABLE_COLUMNS,
    BROWSER_TABLE_DEFAULT_COLUMNS,
)
from codex.choices.jobs import ADMIN_JOBS
from codex.choices.notifications import Notifications
from codex.choices.reader import READER_CHOICES, READER_DEFAULTS
from codex.choices.search import SEARCH_FIELDS
from codex.choices.statii import ADMIN_STATUS_TITLES

_DEFAULTS = MappingProxyType(
    {"browser-choices.json": BROWSER_DEFAULTS, "reader-choices.json": READER_DEFAULTS}
)

# Per-file include-key filters. A filename present here emits only the
# listed top-level keys from its source mapping; orphan keys are skipped.
_INCLUDE_KEYS = MappingProxyType(
    {
        "browser-choices.json": BROWSER_CHOICES_VUETIFY_KEYS,
        "browser-map.json": BROWSER_CHOICES_MAP_KEYS,
    }
)

_DUMPS = MappingProxyType(
    {
        "admin-flag-choices.json": ADMIN_FLAG_CHOICES,
        "admin-status-titles.json": ADMIN_STATUS_TITLES,
        "browser-choices.json": BROWSER_CHOICES,
        "reader-choices.json": READER_CHOICES,
    }
)

_MAP_DUMPS = MappingProxyType(
    {
        "admin-jobs.json": ADMIN_JOBS,
        "browser-defaults.json": BROWSER_DEFAULTS,
        "browser-map.json": BROWSER_CHOICES,
        "browser-table-column-costs.json": BROWSER_TABLE_COLUMN_COSTS,
        "browser-table-columns.json": BROWSER_TABLE_COLUMNS,
        "browser-table-default-columns.json": BROWSER_TABLE_DEFAULT_COLUMNS,
        "reader-defaults.json": READER_DEFAULTS,
        "reader-map.json": READER_CHOICES,
        "search-map.json": SEARCH_FIELDS,
    }
)


def _to_vuetify_choices(defaults, key: str, obj_map) -> list:
    """Transform a dict into a list of vuetify choices."""
    default = defaults.get(key)
    vuetify_list = []
    for value, title in obj_map.items():
        vuetify_dict = {
            "value": value,
            "title": title,
        }
        if default == value:
            vuetify_dict["default"] = True
        vuetify_list.append(vuetify_dict)
    return vuetify_list


def _json_key(key: str):
    """Transform key to json version."""
    return key if key.upper() == key else camelcase(key)


def _make_json_serializable(data, *, jsonize_keys: bool = True) -> list | dict:
    """Convert nested Mapping objects to dicts."""
    if isinstance(data, Mapping):
        json_dict = {}
        for key, value in data.items():
            json_value = _make_json_serializable(value, jsonize_keys=jsonize_keys)
            json_key = _json_key(key) if jsonize_keys else key
            json_dict[json_key] = json_value
        return json_dict
    if isinstance(data, list | tuple | frozenset | set):
        return [
            _make_json_serializable(item, jsonize_keys=jsonize_keys) for item in data
        ]
    return data


def _to_vuetify_dict(fn: str, data) -> dict:
    """Convert mappings to vuetify dict list."""
    vuetify_data = {}
    defaults = _DEFAULTS.get(fn) or {}
    for key, obj in data.items():
        if isinstance(obj, Mapping):
            vuetify_value = _to_vuetify_choices(defaults, key, obj)
        else:
            vuetify_value = _make_json_serializable(obj)
        vuetify_data[_json_key(key)] = vuetify_value
    return vuetify_data


def _dump(
    parent_path: Path, fn: str, data, *, vuetify: bool, jsonize_keys: bool
) -> None:
    """Dump data to json file."""
    include_keys = _INCLUDE_KEYS.get(fn)
    if include_keys is not None and isinstance(data, Mapping):
        data = {k: v for k, v in data.items() if k in include_keys}
    vuetify_data = (
        _to_vuetify_dict(fn, data)
        if vuetify
        else _make_json_serializable(data, jsonize_keys=jsonize_keys)
    )
    path = parent_path / fn
    with path.open("w") as json_file:
        json.dump(vuetify_data, json_file, indent=2)
        json_file.write("\n")


def _make_websocket_messages() -> MappingProxyType:
    return MappingProxyType(
        {"messages": {msg.name: msg.value for msg in Notifications}}
    )


def main() -> None:
    """Dump all files."""
    import sys

    parent_path = sys.argv[1] if len(sys.argv) > 1 else "."
    parent_path = Path(parent_path)
    parent_path.mkdir(exist_ok=True)
    for fn, data in _DUMPS.items():
        _dump(parent_path, fn, data, vuetify=True, jsonize_keys=True)

    # The column-registry dumps must keep their snake_case keys exactly
    # (the keys are protocol identifiers — they appear in the
    # ``columns=`` query param and must round-trip through the backend's
    # validator). search-map.json is the existing exception.
    skip_jsonize = frozenset(
        {
            "search-map.json",
            "browser-table-column-costs.json",
            "browser-table-columns.json",
            "browser-table-default-columns.json",
        }
    )
    for fn, data in _MAP_DUMPS.items():
        jsonize_keys = fn not in skip_jsonize
        _dump(parent_path, fn, data, vuetify=False, jsonize_keys=jsonize_keys)

    ws_messages = _make_websocket_messages()
    _dump(
        parent_path,
        "websocket-messages.json",
        ws_messages,
        vuetify=False,
        jsonize_keys=True,
    )


if __name__ == "__main__":
    main()
