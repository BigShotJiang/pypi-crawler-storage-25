"""
Per-group column intersections for table view.

For a group row (Series, Publisher, Volume, etc.), each column's
displayed value is the *intersection* across the group's child comics:

- M2M (genres / tags / characters / ...): values present in **every**
  child comic. Comics that don't share the value at all → empty
  cell. Same semantic as
  :class:`MetadataQueryIntersectionsView._get_m2m_intersection_query`.
- Scalar (year / country / language / file_type / monochrome / ...):
  the value if **every** child comic shares it, otherwise empty.

This is what the user asked for in the group-row table experiment.
The helper is invoked after pagination so we only compute for the
visible page; per visible column it issues one batched query that
groups results by the parent group's pk.
"""

from collections import defaultdict
from collections.abc import Iterable
from types import MappingProxyType
from typing import Any

from django.core.exceptions import FieldDoesNotExist
from django.db.models import CharField, Count, F, Min, Q, Sum, Value
from django.db.models.expressions import RawSQL

from codex.models import Comic
from codex.models.groups import (
    BrowserGroupModel,
    Folder,
    Imprint,
    Publisher,
    Series,
    Volume,
)
from codex.views.browser.columns import fk_name_columns, m2m_columns
from codex.views.const import MODEL_REL_MAP

# Comic FK column → group model. Used to correlate the intersection
# sort subquery to the outer group row. ``StoryArc`` traverses
# through ``StoryArcNumber`` so the subquery shape differs; deferred
# from this v1 group-row M2M sort.
_COMIC_GROUP_COL: MappingProxyType[type, str] = MappingProxyType(
    {
        Publisher: "publisher_id",
        Imprint: "imprint_id",
        Series: "series_id",
        Volume: "volume_id",
        Folder: "parent_folder_id",
    }
)


def _format_credit(person_name: str, role_name: str | None) -> str:
    if role_name:
        return f"{person_name} ({role_name})"
    return person_name


def _format_identifier(source_name: str | None, id_type: str, key: str) -> str:
    if source_name:
        return f"{source_name}:{id_type}:{key}"
    return f"{id_type}:{key}"


# Comic field paths for scalar / FK-name columns that participate in
# group-row intersection. Keys mirror the column registry; values are
# Django ORM paths from Comic. The intersection path runs only for
# non-Comic group querysets — Comic rows show their own values via
# the regular ``getattr`` lookup in ``_row_repr``.
_SCALAR_FIELD_PATHS: MappingProxyType[str, str] = MappingProxyType(
    {
        # Direct Comic fields.
        "year": "year",
        "month": "month",
        "day": "day",
        "date": "date",
        "page_count": "page_count",
        "size": "size",
        "file_type": "file_type",
        "reading_direction": "reading_direction",
        "monochrome": "monochrome",
        "critical_rating": "critical_rating",
        "metadata_mtime": "metadata_mtime",
        "created_at": "created_at",
        "updated_at": "updated_at",
        "bookmark_updated_at": "bookmark_updated_at",
        # FK-to-name columns (Comic FK → related model.name).
        "country": "country__name",
        "language": "language__name",
        "original_format": "original_format__name",
        "tagger": "tagger__name",
        "scan_info": "scan_info__name",
        "age_rating": "age_rating__name",
        "main_character": "main_character__name",
        "main_team": "main_team__name",
        # Hierarchy FK-to-name columns. Series / Volume / Imprint
        # have a direct FK on the group model itself but we aggregate
        # via the children's Comic FK chain so the intersection path
        # works uniformly across all non-Comic models — including
        # Folder and StoryArc, which lack the direct FK and so would
        # render blank otherwise.
        "publisher_name": "publisher__name",
        "imprint_name": "imprint__name",
        "series_name": "series__name",
        "volume_name": "volume__name",
    }
)


def _intersection_relation(group_model: type[BrowserGroupModel]) -> str | None:
    """
    Return the ORM lookup that traverses Comic → group for intersections.

    Most groups (Publisher, Imprint, Series, Volume) have a direct FK
    on Comic and ``MODEL_REL_MAP`` carries the right name. Folder is
    the special case: ``Comic.parent_folder`` only points at the
    direct parent, so an FK-based traversal misses comics nested in
    sub-folders. Folder views typically have their content one or
    more levels down, so the FK path returns zero comics for most
    folder rows and intersection / sort silently produces blanks.
    The ``Comic.folders`` M2M includes every ancestor folder, which
    is the relation the cover-pick logic already uses for the same
    reason.
    """
    if group_model is Folder:
        return "folders"
    return MODEL_REL_MAP.get(group_model)


def compute_group_intersections(
    group_qs, columns: Iterable[str]
) -> dict[int, dict[str, Any]]:
    """
    Build ``{group_pk: {column_key: intersection_value}}`` for the page.

    ``group_qs`` should be the already-paginated group queryset. Comic
    querysets short-circuit to an empty dict — Comic rows show their
    own values, not group intersections. Columns whose value source
    isn't recognized are skipped (the row's existing value path
    applies).

    Scalar / FK-name / cumulative columns are batched into a single
    grouped aggregate query — one round-trip regardless of how many
    such columns are visible. M2M columns each issue their own
    query because they each traverse a distinct through-table whose
    JOIN would multiply rows for sibling M2M aggregates if combined.
    """
    cols = tuple(columns)
    if not cols or group_qs.model is Comic:
        return {}

    comic_to_group = _intersection_relation(group_qs.model)
    if not comic_to_group:
        return {}

    group_pks = list(group_qs.values_list("pk", flat=True))
    if not group_pks:
        return {}

    result: dict[int, dict[str, Any]] = {pk: {} for pk in group_pks}

    m2m_cols, intersect_cols, sum_cols = _bucket_intersection_columns(cols)
    counts = _compute_batched_scalars(
        intersect_cols, sum_cols, group_pks, comic_to_group, result
    )

    # Simple-M2M columns share one UNION-ALL query (metadata-view
    # pattern). Composite shapes (credits / identifiers / universes /
    # story_arcs) keep their per-column helpers.
    _compute_simple_m2m_intersections_batched(
        m2m_cols, group_pks, comic_to_group, counts, result
    )
    for col in m2m_cols:
        if col in _SIMPLE_M2M_BATCH_FIELDS:
            continue
        _compute_m2m_intersection(col, group_pks, comic_to_group, counts, result)

    return result


def _bucket_intersection_columns(
    cols: tuple[str, ...],
) -> tuple[list[str], list[tuple[str, str]], list[tuple[str, str]]]:
    """
    Classify requested columns into M2M / scalar-intersection / cumulative.

    Returns three lists that the caller passes to the appropriate
    helpers. M2M columns stay per-query; scalars batch.
    """
    m2m_set = m2m_columns()
    fk_set = fk_name_columns()
    m2m_cols: list[str] = []
    intersect_cols: list[tuple[str, str]] = []
    sum_cols: list[tuple[str, str]] = []
    for col in cols:
        if col in m2m_set:
            m2m_cols.append(col)
            continue
        if col in _CUMULATIVE_SCALAR_FIELDS:
            path = _SCALAR_FIELD_PATHS.get(col)
            if path is not None:
                sum_cols.append((col, path))
                continue
        if col in _SCALAR_FIELD_PATHS or col in fk_set:
            path = _SCALAR_FIELD_PATHS.get(col)
            if path is not None:
                intersect_cols.append((col, path))
    return m2m_cols, intersect_cols, sum_cols


# Scalar columns whose group-row value is the *sum* of the children's
# values rather than the per-row intersection. Both ``page_count`` and
# ``size`` are cumulative quantities — the cover-view card already
# shows ``Sum`` for these, so the table view (display + sort) follows
# the same rule. Categorical scalars (``year``, ``country``,
# ``tagger``, …) keep the intersection rule.
_CUMULATIVE_SCALAR_FIELDS: frozenset[str] = frozenset({"page_count", "size"})


def _build_batched_annotations(
    intersect_cols: list[tuple[str, str]],
    sum_cols: list[tuple[str, str]],
) -> dict[str, Any]:
    """
    Build the ``annotate(**)`` kwargs for the batched scalar query.

    For each intersection column we ask for
    ``COUNT(field)``, ``COUNT(DISTINCT field)``, ``MIN(field)`` —
    enough to evaluate the intersection rule per row. For each
    cumulative column we ask for ``Sum(field)`` (no ``distinct``;
    sibling values that happen to match must contribute fully).
    """
    annotations: dict[str, Any] = {"_isect_comic_count": Count("pk", distinct=True)}
    for col, path in intersect_cols:
        annotations[f"_isect_{col}_count"] = Count(path)
        annotations[f"_isect_{col}_distinct"] = Count(path, distinct=True)
        annotations[f"_isect_{col}_min"] = Min(path)
    for col, path in sum_cols:
        annotations[f"_isect_{col}_sum"] = Sum(path)
    return annotations


def _row_intersection_value(row: dict, col: str, total: int):
    """Apply the intersection rule to one column's batched aggregates."""
    cnt_distinct = row[f"_isect_{col}_distinct"]
    cnt = row[f"_isect_{col}_count"]
    if total > 0 and cnt_distinct == 1 and cnt == total:
        return row[f"_isect_{col}_min"]
    return None


def _compute_batched_scalars(
    intersect_cols: list[tuple[str, str]],
    sum_cols: list[tuple[str, str]],
    group_pks: list[int],
    comic_to_group: str,
    result: dict[int, dict[str, Any]],
) -> dict[int, int]:
    """
    Aggregate every scalar / cumulative column in one grouped query.

    Replaces the previous ``compute_group_intersections`` per-column
    loop (one query each) with a single ``Comic.filter().values(rel)
    .annotate(...)`` that emits, per group, the comic_count plus the
    aggregates needed for each requested scalar column. Returns
    ``{group_pk: comic_count}`` so the caller can pass it to the
    M2M intersection helpers — those still issue per-column queries
    because each M2M traverses a distinct through-table that would
    cross-multiply if combined.

    The intersection rule (every child shares a single non-NULL
    value) reduces to ``count_distinct == 1 AND count == comic_count``
    — and the value is the ``MIN`` (which equals MAX when
    distinct == 1). Cumulative columns use plain ``Sum`` so sibling
    values that happen to match contribute fully.
    """
    annotations = _build_batched_annotations(intersect_cols, sum_cols)
    rows = (
        Comic.objects.filter(**{f"{comic_to_group}__in": group_pks})
        .values(comic_to_group)
        .annotate(**annotations)
    )

    counts: dict[int, int] = {}
    for row in rows:
        gpk = row[comic_to_group]
        total = row["_isect_comic_count"] or 0
        counts[gpk] = total
        bucket = result[gpk]
        for col, _path in intersect_cols:
            bucket[col] = _row_intersection_value(row, col, total)
        for col, _path in sum_cols:
            bucket[col] = row[f"_isect_{col}_sum"]

    # Groups whose filter matched zero comics didn't produce a row;
    # initialize their cells so the row dict has a uniform shape.
    for gpk in group_pks:
        counts.setdefault(gpk, 0)
        bucket = result[gpk]
        for col, _path in intersect_cols:
            bucket.setdefault(col, None)
        for col, _path in sum_cols:
            bucket.setdefault(col, None)
    return counts


# M2M columns whose intersection display is the alphabetized list of
# the target model's ``name`` field. Eligible for the through-table
# batched union (see ``_compute_simple_m2m_intersections_batched``).
# ``universes`` (composite ``name:designation``), ``credits``
# (``Person (Role)``), ``identifiers`` (``[source:]type:key``), and
# ``story_arcs`` (StoryArcNumber → StoryArc indirection) need bespoke
# SQL and stay on per-column helpers.
_SIMPLE_M2M_BATCH_FIELDS: frozenset[str] = frozenset(
    {
        "characters",
        "genres",
        "locations",
        "series_groups",
        "stories",
        "tags",
        "teams",
    }
)


def _build_simple_m2m_intersection_query(
    col: str, comic_to_group: str, group_pks: list[int]
):
    """
    One per-column through-table query, aggregated per (group, value).

    Skips Comic as an anchor: queries the M2M through table directly
    and JOINs to the target's ``__name`` and (via ``comic__``) to the
    parent group's FK column. SQL aggregation produces one row per
    ``(group_pk, value)`` so the union output stays small. Marked
    with the column key as ``field_name`` so a downstream union can
    partition results without per-query Python state.
    """
    field = Comic._meta.get_field(col)
    through = field.remote_field.through  # pyright: ignore[reportAttributeAccessIssue], # ty: ignore[unresolved-attribute]
    rel_name = field.m2m_reverse_field_name()  # pyright: ignore[reportAttributeAccessIssue], # ty: ignore[unresolved-attribute]
    return (
        through.objects.filter(
            **{f"comic__{comic_to_group}__in": group_pks},
            **{f"{rel_name}__name__isnull": False},
        )
        .exclude(**{f"{rel_name}__name": ""})
        .values(
            value=F(f"{rel_name}__name"),
            group_pk=F(f"comic__{comic_to_group}"),
        )
        .annotate(cnt=Count("comic_id", distinct=True))
        .annotate(field_name=Value(col, output_field=CharField()))
        .values_list("field_name", "group_pk", "value", "cnt")
    )


def _initialize_simple_m2m_buckets(
    batched_cols: list[str],
    group_pks: list[int],
    result: dict[int, dict[str, Any]],
) -> None:
    """Pre-fill empty intersection lists so empty-result groups still get ``[]``."""
    for gpk in group_pks:
        bucket = result[gpk]
        for col in batched_cols:
            bucket.setdefault(col, [])


def _union_simple_m2m_queries(queries: list):
    """Combine sub-queries with ``UNION ALL`` (or pass through a single query)."""
    if len(queries) == 1:
        return queries[0]
    return queries[0].union(*queries[1:], all=True)


def _collect_simple_m2m_intersections(
    combined,
    counts: dict[int, int],
) -> dict[tuple[str, int], list[str]]:
    """Group UNION rows by ``(field, group_pk)``, keeping intersection-passing values."""
    intersection_per: dict[tuple[str, int], list[str]] = defaultdict(list)
    for field_name, group_pk, value, cnt in combined:
        if cnt == counts.get(group_pk, 0):
            intersection_per[(field_name, group_pk)].append(value)
    return intersection_per


def _compute_simple_m2m_intersections_batched(
    cols: list[str],
    group_pks: list[int],
    comic_to_group: str,
    counts: dict[int, int],
    result: dict[int, dict[str, Any]],
) -> None:
    """
    Batch every simple-M2M column into one ``UNION ALL`` round-trip.

    Mirrors ``MetadataQueryIntersectionsView._query_m2m_intersections``
    but adapts to multiple groups per page: each sub-query carries a
    ``group_pk`` annotation and aggregates per ``(group_pk, value)``;
    the UNION combines all column shapes into one SQL transmission.
    Python-side partitioning then drops rows whose ``cnt`` doesn't
    match the group's total comic count — that's the intersection
    rule.
    """
    batched_cols = [c for c in cols if c in _SIMPLE_M2M_BATCH_FIELDS]
    # Initialize empty lists for every requested simple column up
    # front so groups whose intersection is empty get ``[]`` rather
    # than missing keys.
    _initialize_simple_m2m_buckets(batched_cols, group_pks, result)
    queries = [
        _build_simple_m2m_intersection_query(col, comic_to_group, group_pks)
        for col in batched_cols
    ]
    if not queries:
        return
    combined = _union_simple_m2m_queries(queries)
    intersection_per = _collect_simple_m2m_intersections(combined, counts)
    for (field_name, gpk), values in intersection_per.items():
        result[gpk][field_name] = sorted(values)


def _compute_m2m_intersection(
    col: str,
    group_pks: list[int],
    comic_to_group: str,
    counts: dict[int, int],
    result: dict[int, dict[str, Any]],
) -> None:
    """
    Set ``result[group][col]`` for one composite-M2M column.

    Simple M2M columns route through
    ``_compute_simple_m2m_intersections_batched`` instead — this
    helper covers the bespoke shapes (credits / identifiers /
    universes / story_arcs).
    """
    if col == "credits":
        _compute_credits_intersection(group_pks, comic_to_group, counts, result)
        return
    if col == "identifiers":
        _compute_identifiers_intersection(group_pks, comic_to_group, counts, result)
        return

    rel = _M2M_NAME_RELATIONS.get(col)
    if rel is None:
        return
    rows = (
        Comic.objects.filter(**{f"{comic_to_group}__in": group_pks})
        .filter(**{f"{rel}__isnull": False})
        .values(comic_to_group, rel)
        .annotate(cnt=Count("pk", distinct=True))
    )
    per_group: dict[int, list[tuple[Any, int]]] = defaultdict(list)
    for row in rows:
        per_group[row[comic_to_group]].append((row[rel], row["cnt"]))
    for gpk in group_pks:
        total = counts.get(gpk, 0)
        if not total:
            result[gpk][col] = []
            continue
        names = sorted(value for value, cnt in per_group.get(gpk, ()) if cnt == total)
        result[gpk][col] = names


_M2M_NAME_RELATIONS: MappingProxyType[str, str] = MappingProxyType(
    {
        "story_arcs": "story_arc_numbers__story_arc__name",
        "universes": "universes__name",
    }
)


# ──────────────────────────────────────────────────────────────────────
# M2M-intersection sort key for group rows
#
# The order_value annotation for a group row sorting by an M2M column
# is the alphabetized concatenation of M2M values present in every
# child comic. Identical intersection sets render identical strings
# under SQLite's binary collation, so ORDER BY clusters equivalent
# rows together — the property the user already validated for the
# Comic-row M2M-sort experiment.
#
# We build the expression as RawSQL for two reasons:
#   1. SQLite's correlated-subquery + HAVING + GROUP_CONCAT pattern
#      with intra-row ORDER BY is straightforward in SQL but requires
#      ORM gymnastics (nested OuterRefs, .aggregate inside Subquery,
#      etc.) that obscure the intent.
#   2. Per-row execution against the outer group table is the most
#      efficient shape SQLite can deliver — see the perf note below.
#
# Performance: the subquery executes once per row in the outer
# queryset's ORDER BY phase. With indexes on the comic's group FK
# (codex_comic.<group>_id) and the through table's (comic_id, target_id)
# pair, each subquery scans only the relevant rows for that group.
# Profile-and-tune is the user's call; the SELECT is structurally
# minimal — one INNER JOIN chain through the M2M, one GROUP BY, one
# correlated COUNT for the HAVING clause.

# ``through_table_attr`` resolves to e.g. ``codex_comic_genres`` via
# Django's metadata; ``target_table_attr`` is the related model's
# ``_meta.db_table`` (``codex_genre``); ``m2m_id_col`` is the through
# table's FK column to the related model (``genre_id``). All three
# are looked up at runtime so we don't hardcode db_table names.
_SIMPLE_M2M_FIELDS = MappingProxyType(
    {
        "characters": "characters",
        "genres": "genres",
        "locations": "locations",
        "series_groups": "series_groups",
        "stories": "stories",
        "tags": "tags",
        "teams": "teams",
        # ``universes`` is *not* simple — its display includes the
        # ``designation`` field. Handled below.
    }
)


def _build_simple_m2m_intersection_sort_sql(
    group_model: type[BrowserGroupModel], column: str
) -> RawSQL | None:
    """
    Return a correlated-subquery RawSQL for the intersection sort key.

    Restricted to ``_SIMPLE_M2M_FIELDS`` and group models in
    ``_COMIC_GROUP_COL`` (StoryArc, credits, identifiers — deferred).
    Returns None when unsupported.
    """
    field_name = _SIMPLE_M2M_FIELDS.get(column)
    correlation = _comic_correlation_sql(group_model)
    if field_name is None or correlation is None:
        return None
    field = Comic._meta.get_field(field_name)
    through = field.remote_field.through  # pyright: ignore[reportAttributeAccessIssue] # ty: ignore[unresolved-attribute]
    through_table = through._meta.db_table
    m2m_id_col = f"{field.m2m_reverse_field_name()}_id"  # pyright: ignore[reportAttributeAccessIssue] # ty: ignore[unresolved-attribute]
    related_model = field.related_model
    if related_model is None:
        return None
    target_table = related_model._meta.db_table
    extra_join, where, total_count = correlation

    # Correlated subquery returning the alphabetized GROUP_CONCAT of
    # target ``name`` values whose comic-count for the outer group
    # matches the group's total comic count — the intersection set.
    # ```` (unit separator) is used as the join character so it
    # never collides with values in the names. NULL/empty target
    # names are filtered out so they can't fold into the sort key.
    # All identifiers spliced into ``sql`` come from Django metadata
    # (``_meta.db_table``, ``m2m_reverse_field_name()``); the column
    # whitelist (``_SIMPLE_M2M_FIELDS``) and group whitelist
    # (``_COMIC_GROUP_COL``) bound the inputs, so RawSQL is safe here.
    # Three-stage shape so the per-outer-row work is bounded by the
    # through-table's slice for the group, not the through-target
    # cross-product:
    #
    # 1. ``isect_ids`` — aggregate only on the through table,
    #    correlated to the outer group via an IN-subselect on
    #    ``th.comic_id``. The IN-subselect uses the comic FK index;
    #    the through-table aggregation uses the (target_id, comic_id)
    #    composite index. No name JOIN, no codex_comic JOIN — those
    #    columns aren't needed to decide which target_ids survive
    #    the HAVING.
    # 2. ``named`` — JOIN the target table to ``isect_ids`` to
    #    surface ``name`` for the few surviving target_ids only.
    #    NULL / empty names drop here.
    # 3. Outer ``GROUP_CONCAT`` collapses ``named`` into one string.
    sql = f"""(
        SELECT COALESCE(GROUP_CONCAT(name, X'1F'), '')
        FROM (
            SELECT t.name AS name
            FROM (
                SELECT th.{m2m_id_col} AS target_id
                FROM {through_table} th
                WHERE th.comic_id IN (
                    SELECT c.id FROM codex_comic c {extra_join} WHERE {where}
                )
                GROUP BY th.{m2m_id_col}
                HAVING COUNT(DISTINCT th.comic_id) = ({total_count})
            ) AS isect_ids
            INNER JOIN {target_table} t ON t.id = isect_ids.target_id
            WHERE t.name IS NOT NULL AND t.name != ''
            ORDER BY t.name
        ) AS named
    )"""  # noqa: S608
    return RawSQL(sql, [])  # noqa: S611


def _wrap_intersection_sort(
    inner_select: str, correlation: tuple[str, str, str]
) -> str:
    """
    Wrap a per-row display-string SELECT with the standard intersection envelope.

    ``inner_select`` is the SELECT body that produces a ``display_name``
    column for each (target, comic) row. ``correlation`` is the
    ``(extra_join, where, total_count)`` tuple from
    ``_comic_correlation_sql``. The envelope splices the join + where
    pieces into the inner select, groups by the target's identity,
    applies the intersection HAVING, and concatenates per-group with
    the same X'1F' separator the simple variant uses.

    All identifiers spliced in come from caller-side whitelists, not
    user input — caller-level S608 noqa applies.
    """
    extra_join, where, total_count = correlation
    return f"""(
        SELECT COALESCE(GROUP_CONCAT(display_name, X'1F'), '')
        FROM (
            {inner_select}
            {extra_join}
            WHERE {where}
              AND display_name IS NOT NULL
              AND display_name != ''
            GROUP BY target_id
            HAVING COUNT(DISTINCT c.id) = ({total_count})
            ORDER BY display_name
        ) AS isect
    )"""  # noqa: S608


def _build_universes_intersection_sort_sql(
    group_model: type[BrowserGroupModel],
) -> RawSQL | None:
    """Universes display as ``name:designation`` (or just ``name`` when blank)."""
    correlation = _comic_correlation_sql(group_model)
    if correlation is None:
        return None
    inner = """
            SELECT
                u.id AS target_id,
                CASE
                    WHEN u.designation IS NULL OR u.designation = ''
                        THEN u.name
                    ELSE u.name || ':' || u.designation
                END AS display_name
            FROM codex_universe u
            INNER JOIN codex_comic_universes th ON th.universe_id = u.id
            INNER JOIN codex_comic c ON c.id = th.comic_id
    """
    sql = _wrap_intersection_sort(inner, correlation)
    return RawSQL(sql, [])  # noqa: S611


def _build_credits_intersection_sort_sql(
    group_model: type[BrowserGroupModel],
) -> RawSQL | None:
    """Credits display as ``Person (Role)`` (or ``Person`` when role is null)."""
    correlation = _comic_correlation_sql(group_model)
    if correlation is None:
        return None
    # Two comics share a Credit only when they reference the same row;
    # ``unique_together = ("person", "role")`` on Credit makes the
    # (person, role) pair the de-facto identity, so grouping by
    # ``credit.id`` is equivalent to grouping by the pair.
    inner = """
            SELECT
                cred.id AS target_id,
                CASE
                    WHEN cr.id IS NULL THEN cp.name
                    ELSE cp.name || ' (' || cr.name || ')'
                END AS display_name
            FROM codex_credit cred
            INNER JOIN codex_creditperson cp ON cp.id = cred.person_id
            LEFT JOIN codex_creditrole cr ON cr.id = cred.role_id
            INNER JOIN codex_comic_credits th ON th.credit_id = cred.id
            INNER JOIN codex_comic c ON c.id = th.comic_id
    """
    sql = _wrap_intersection_sort(inner, correlation)
    return RawSQL(sql, [])  # noqa: S611


def _build_identifiers_intersection_sort_sql(
    group_model: type[BrowserGroupModel],
) -> RawSQL | None:
    """Render identifiers intersection as ``[source:]type:key`` per shared row."""
    correlation = _comic_correlation_sql(group_model)
    if correlation is None:
        return None
    inner = """
            SELECT
                idn.id AS target_id,
                CASE
                    WHEN src.id IS NULL THEN idn.id_type || ':' || idn.key
                    ELSE src.name || ':' || idn.id_type || ':' || idn.key
                END AS display_name
            FROM codex_identifier idn
            LEFT JOIN codex_identifiersource src ON src.id = idn.source_id
            INNER JOIN codex_comic_identifiers th ON th.identifier_id = idn.id
            INNER JOIN codex_comic c ON c.id = th.comic_id
    """
    sql = _wrap_intersection_sort(inner, correlation)
    return RawSQL(sql, [])  # noqa: S611


def _build_story_arcs_intersection_sort_sql(
    group_model: type[BrowserGroupModel],
) -> RawSQL | None:
    """Story arcs go through ``StoryArcNumber``; group by the parent ``StoryArc``."""
    correlation = _comic_correlation_sql(group_model)
    if correlation is None:
        return None
    # Comic.story_arc_numbers → StoryArcNumber → story_arc → StoryArc.
    # We want intersection by StoryArc (not StoryArcNumber): a story
    # arc is "shared" if every comic has at least one StoryArcNumber
    # pointing to it, regardless of issue number.
    inner = """
            SELECT
                sa.id AS target_id,
                sa.name AS display_name
            FROM codex_storyarc sa
            INNER JOIN codex_storyarcnumber san ON san.story_arc_id = sa.id
            INNER JOIN codex_comic_story_arc_numbers th ON th.storyarcnumber_id = san.id
            INNER JOIN codex_comic c ON c.id = th.comic_id
    """
    sql = _wrap_intersection_sort(inner, correlation)
    return RawSQL(sql, [])  # noqa: S611


def _comic_correlation_sql(
    group_model: type[BrowserGroupModel],
) -> tuple[str, str, str] | None:
    """
    Return the SQL fragments correlating Comic rows to the outer group row.

    Most groups (Publisher, Imprint, Series, Volume) carry a direct
    FK on Comic — the JOIN is implicit and the WHERE clause is
    ``c.<fk> = <group_table>.id``. Folder is the special case:
    ``Comic.parent_folder`` only points at the *direct* parent so
    the FK path returns zero comics for any folder whose content
    lives in a sub-folder. The browse query, the cover-pick query
    and the cell display all already prefer the ancestor M2M
    ``Comic.folders`` for Folder; the sort path now does too. The
    extra JOIN clause is empty for non-Folder groups.

    Returns ``(extra_join, where_clause, total_count_select)`` or
    ``None`` when the group model isn't supported.
    """
    if group_model is Folder:
        folders_field = Comic._meta.get_field("folders")
        through = folders_field.remote_field.through  # pyright: ignore[reportAttributeAccessIssue] # ty: ignore[unresolved-attribute]
        through_table = through._meta.db_table
        group_table = Folder._meta.db_table
        extra_join = f"INNER JOIN {through_table} cf ON cf.comic_id = c.id"
        where = f"cf.folder_id = {group_table}.id"
        # ``DISTINCT c2.id`` to defend against any future change that
        # makes the M2M traversal multi-row per comic; today each
        # (comic, folder) pair is unique so the DISTINCT is a no-op.
        total_count = (
            f"SELECT COUNT(DISTINCT c2.id) FROM codex_comic c2 "  # noqa: S608
            f"INNER JOIN {through_table} cf2 ON cf2.comic_id = c2.id "
            f"WHERE cf2.folder_id = {group_table}.id"
        )
        return extra_join, where, total_count
    comic_group_col = _COMIC_GROUP_COL.get(group_model)
    if comic_group_col is None:
        return None
    group_table = group_model._meta.db_table
    where = f"c.{comic_group_col} = {group_table}.id"
    total_count = (
        f"SELECT COUNT(*) FROM codex_comic "  # noqa: S608
        f"WHERE {comic_group_col} = {group_table}.id"
    )
    return "", where, total_count


def scalar_intersection_sort_expr(
    group_model: type[BrowserGroupModel], column: str
) -> RawSQL | None:
    """
    Build a sort-key RawSQL for scalar / FK-name group-row sort.

    The group-row *display* uses intersection (``_compute_scalar_intersection``):
    a value renders only when every child comic in the group shares it
    (same non-NULL value, no missing children). The default
    ``Min`` / ``Avg`` / ``Sum`` aggregates used by ``annotate_order_value``
    don't agree with that — a series whose children mostly lack a year
    but one happens to be 2024 sorts as if year=2024 yet displays
    blank. Mirroring the intersection rule in SQL keeps display and
    sort consistent: the ORDER BY value is the per-group value when
    every child agrees, NULL otherwise. NULLs follow SQLite's default
    sort position (smallest in ASC, last in DESC).

    Returns None when the column or group model isn't supported;
    callers fall back to the previous aggregate path so we don't
    silently break an existing sort if the registry adds a new field
    we haven't wired here yet. Cumulative scalars (``page_count``,
    ``size``) also return None so the caller's ``Sum`` aggregate
    runs — display for those columns is ``Sum`` (matching cover-view)
    rather than intersection, and sort matches display.
    """
    if column in _CUMULATIVE_SCALAR_FIELDS:
        return None
    path = _SCALAR_FIELD_PATHS.get(column)
    correlation = _comic_correlation_sql(group_model)
    if path is None or correlation is None:
        return None
    extra_join, where, total_count = correlation

    if "__" not in path:
        # Direct Comic field — year, page_count, size, file_type, …
        # All identifiers spliced in come from caller-side whitelists
        # (column → ``_SCALAR_FIELD_PATHS``; correlation pieces from
        # ``_comic_correlation_sql`` over a fixed group whitelist).
        col = f"c.{path}"
        sql = f"""(
            SELECT
                CASE
                    WHEN COUNT({col}) = ({total_count})
                      AND MIN({col}) = MAX({col})
                    THEN MIN({col})
                    ELSE NULL
                END
            FROM codex_comic c
            {extra_join}
            WHERE {where}
        )"""  # noqa: S608
        return RawSQL(sql, [])  # noqa: S611

    # FK-to-name field — tagger__name, country__name, age_rating__name, …
    fk_attr, target_field = path.split("__", 1)
    try:
        fk_field = Comic._meta.get_field(fk_attr)
    except FieldDoesNotExist:
        return None
    related_model = fk_field.related_model
    if related_model is None:
        return None
    fk_col = fk_field.column  # e.g. ``tagger_id``
    target_table = related_model._meta.db_table
    target_col = f"t.{target_field}"
    sql = f"""(
        SELECT
            CASE
                WHEN COUNT({target_col}) = ({total_count})
                  AND MIN({target_col}) = MAX({target_col})
                THEN MIN({target_col})
                ELSE NULL
            END
        FROM codex_comic c
        {extra_join}
        LEFT JOIN {target_table} t ON c.{fk_col} = t.id
        WHERE {where}
    )"""  # noqa: S608
    return RawSQL(sql, [])  # noqa: S611


def m2m_intersection_sort_expr(
    group_model: type[BrowserGroupModel], column: str
) -> RawSQL | None:
    """
    Build a sort-key RawSQL for the given (group_model, M2M column).

    Public entry point. Returns None when the combination isn't
    supported; callers fall back to sort_name.
    """
    if column in _SIMPLE_M2M_FIELDS:
        return _build_simple_m2m_intersection_sort_sql(group_model, column)
    if column == "universes":
        return _build_universes_intersection_sort_sql(group_model)
    if column == "credits":
        return _build_credits_intersection_sort_sql(group_model)
    if column == "identifiers":
        return _build_identifiers_intersection_sort_sql(group_model)
    if column == "story_arcs":
        return _build_story_arcs_intersection_sort_sql(group_model)
    return None


def _compute_credits_intersection(
    group_pks: list[int],
    comic_to_group: str,
    counts: dict[int, int],
    result: dict[int, dict[str, Any]],
) -> None:
    """Credit intersection — by (person.name, role.name) tuple, formatted as "Person (Role)"."""
    rows = (
        Comic.objects.filter(**{f"{comic_to_group}__in": group_pks})
        .filter(credits__person__name__gt="")
        .values(
            comic_to_group,
            "credits__person__name",
            "credits__role__name",
        )
        .annotate(cnt=Count("pk", distinct=True))
    )
    per_group: dict[int, list[tuple[str, str | None, int]]] = defaultdict(list)
    for row in rows:
        per_group[row[comic_to_group]].append(
            (
                row["credits__person__name"],
                row["credits__role__name"],
                row["cnt"],
            )
        )
    for gpk in group_pks:
        total = counts.get(gpk, 0)
        if not total:
            result[gpk]["credits"] = []
            continue
        names = sorted(
            _format_credit(person, role)
            for person, role, cnt in per_group.get(gpk, ())
            if cnt == total
        )
        result[gpk]["credits"] = names


def _compute_identifiers_intersection(
    group_pks: list[int],
    comic_to_group: str,
    counts: dict[int, int],
    result: dict[int, dict[str, Any]],
) -> None:
    """Render identifier intersection as ``[source:]type:key`` per shared row."""
    rows = (
        Comic.objects.filter(**{f"{comic_to_group}__in": group_pks})
        .filter(Q(identifiers__id_type__gt="") | Q(identifiers__key__gt=""))
        .values(
            comic_to_group,
            "identifiers__source__name",
            "identifiers__id_type",
            "identifiers__key",
        )
        .annotate(cnt=Count("pk", distinct=True))
    )
    per_group: dict[int, list[tuple[str | None, str, str, int]]] = defaultdict(list)
    for row in rows:
        per_group[row[comic_to_group]].append(
            (
                row["identifiers__source__name"],
                row["identifiers__id_type"],
                row["identifiers__key"],
                row["cnt"],
            )
        )
    for gpk in group_pks:
        total = counts.get(gpk, 0)
        if not total:
            result[gpk]["identifiers"] = []
            continue
        names = sorted(
            _format_identifier(source, id_type, key)
            for source, id_type, key, cnt in per_group.get(gpk, ())
            if cnt == total
        )
        result[gpk]["identifiers"] = names
