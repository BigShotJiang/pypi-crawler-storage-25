"""Demo scripts for KittyChain."""
