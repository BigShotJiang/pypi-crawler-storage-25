"""
Tests package for pygid.
"""