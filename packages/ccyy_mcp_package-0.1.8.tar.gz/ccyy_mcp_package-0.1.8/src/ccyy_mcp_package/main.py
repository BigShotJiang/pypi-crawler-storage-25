from mcp.server.fastmcp import FastMCP

# 初始化MCP服务器实例
mcp = FastMCP("My_Mcp_Server")


@mcp.tool()
def sum(a: int, b: int) -> int:
    """计算两个整数的和
    Args:
        a (int): 第一个整数
        b (int): 第二个整数
    """
    return a + b


if __name__ == "__main__":
    # 启动MCP服务器
    mcp.run(transport="stdio")
