from ccyy_mcp_package.main import mcp


def main() -> None:
    mcp.settings.host = "0.0.0.0"
    mcp.settings.port = 8080
    mcp.run(transport="stdio")
    print("MCP服务器正在运行，等待工具调用...")
