# Changelog

## 0.1.0 (2026-04-04)

### Added

- Initial release
- `Pipeline` class with `.through()`, `.pipe()`, `.when()`, `.unless()`, `.tap()`, `.on_failure()`, `.then()`, `.then_return()`
- `AsyncPipeline` class with async equivalents of all Pipeline methods
- `Pipe` abstract base class for class-based pipes
- `AsyncPipe` abstract base class for async class-based pipes
- `PipelineError` and `PipelineFlowError` exceptions
