"""SuperPenguin Python SDK — AI cost management, attribution, and spend tracking."""

from __future__ import annotations

import os
from typing import Any

from superpenguin._client import SuperPenguinClient
from superpenguin._context import metadata
from superpenguin._litellm import patch_litellm
from superpenguin._trace import trace
from superpenguin._wrap import wrap

__all__ = [
    "init",
    "wrap",
    "trace",
    "metadata",
    "patch_litellm",
    "get_client",
    "flush",
]
__version__ = "0.3.0"

_client: SuperPenguinClient | None = None

_DEFAULT_BASE_URL = "https://api.carrotlabs.ai"


def init(
    *,
    api_key: str | None = None,
    base_url: str | None = None,
    flush_interval: float = 5.0,
    batch_size: int = 50,
) -> None:
    """Initialize the SuperPenguin SDK.

    Must be called before ``wrap()`` or ``@trace`` capture any data.
    Alternatively, set the ``SP_API_KEY`` environment variable for
    auto-initialization on first use.

    Args:
        api_key: Your SuperPenguin API key (``sp_...``).  Falls back to
            ``SP_API_KEY`` env var.
        base_url: Override the API endpoint.  Falls back to
            ``SP_BASE_URL`` env var, then ``https://api.carrotlabs.ai``.
        flush_interval: Seconds between background flushes (default 5).
        batch_size: Max events per batch POST (default 50).
    """
    global _client

    if api_key is None:
        api_key = os.environ.get("SP_API_KEY")
    if api_key is None:
        raise ValueError(
            "api_key is required — pass it to sp.init() "
            "or set the SP_API_KEY environment variable"
        )
    if base_url is None:
        base_url = os.environ.get("SP_BASE_URL", _DEFAULT_BASE_URL)

    _client = SuperPenguinClient(
        api_key=api_key,
        base_url=base_url,
        flush_interval=flush_interval,
        batch_size=batch_size,
    )


def get_client() -> SuperPenguinClient:
    """Return the global client, auto-initializing if ``SP_API_KEY`` is set."""
    global _client
    if _client is None:
        api_key = os.environ.get("SP_API_KEY")
        if api_key:
            init(api_key=api_key)
        else:
            raise RuntimeError(
                "sp.init() has not been called and SP_API_KEY is not set"
            )
    return _client


def flush() -> None:
    """Flush any pending events to the server immediately."""
    if _client is not None:
        _client.flush()
