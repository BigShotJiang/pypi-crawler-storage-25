from __future__ import annotations

import contextvars
from contextlib import contextmanager
from typing import Any, Iterator

current_trace_id: contextvars.ContextVar[str | None] = contextvars.ContextVar(
    "sp_trace_id", default=None
)

# Metadata pushed by an active ``@sp.trace`` decorator OR ``sp.metadata()``
# context manager. Wrapped client calls inside the active scope read this
# and merge it on top of the wrap-time defaults (and beneath any per-call
# overrides).
current_trace_metadata: contextvars.ContextVar[dict[str, Any] | None] = (
    contextvars.ContextVar("sp_trace_metadata", default=None)
)


def merged_metadata(
    wrap_default: dict[str, Any] | None,
    call_meta: dict[str, Any] | None,
) -> dict[str, Any]:
    """Merge metadata layers in precedence order.

    Lowest to highest:
      1. ``wrap_default`` -- passed to ``sp.wrap(client, metadata=...)``
      2. scoped metadata  -- set by ``@sp.trace(metadata=...)`` or
                             ``with sp.metadata({...}):``
      3. ``call_meta``    -- per-call override (e.g. ``extra_body``)

    Returns a fresh dict; never mutates inputs.
    """
    out: dict[str, Any] = dict(wrap_default or {})
    scoped = current_trace_metadata.get() or {}
    if scoped:
        out.update(scoped)
    if call_meta:
        out.update(call_meta)
    return out


@contextmanager
def metadata(values: dict[str, Any]) -> Iterator[None]:
    """Scope metadata to a ``with`` block.

    Every wrapped client call inside the block (any provider, including
    Gemini, Deepgram, and ElevenLabs whose SDKs don't accept ``extra_body``)
    inherits these fields. Layered on top of any active ``@sp.trace``
    metadata, and overridden by per-call ``extra_body`` / ``metadata=``.

    Usage::

        with sp.metadata({"customer_id": cust_id, "prompt_version": "2"}):
            audio = el.text_to_speech.convert(...)
    """
    if not isinstance(values, dict):
        raise TypeError("sp.metadata() expects a dict")

    # Layer on top of any currently active scoped metadata.
    base = current_trace_metadata.get() or {}
    merged = {**base, **values}
    token = current_trace_metadata.set(merged)
    try:
        yield
    finally:
        current_trace_metadata.reset(token)
