"""LiveKit Agents observability shim — pushes voice metrics to the
cost-management backend.

Why this lives in superpenguin (the SDK)
----------------------------------------
NightShift's voice agent runs on top of LiveKit Agents and routes audio
through Deepgram (STT), an OpenAI/Anthropic LLM, and ElevenLabs (TTS).
Three of those four billing surfaces (Deepgram, ElevenLabs, LiveKit itself)
expose **per-request** metrics through LiveKit's own ``MetricsCollectedEvent``
stream — it's the cheapest and most-granular signal the agent has, much
finer-grained than the daily provider invoice.

The fourth (LLM) is already captured by the existing ``sp.wrap()``
client-wrapper path with full token/cache/provider detail. We intentionally
skip ``LLMMetrics`` here so a single LLM call doesn't get two rows in
``request_logs``.

What this shim emits
--------------------
* **STT** (per turn): one row per ``STTMetrics`` event with
  ``audio_seconds`` set to the turn's billable audio duration; provider/model
  default to ``deepgram/nova-3-monolingual`` (override in constructor).
* **TTS** (per turn): one row per ``TTSMetrics`` event with ``characters``
  set to the synthesized character count plus ``audio_seconds`` for the
  output duration (latter is informational; ElevenLabs bills on chars).
* **LiveKit agent-session-minute** (per session end): one row with
  ``audio_seconds`` = total session duration and
  ``model="livekit/agent-session-minute"``.
* **LiveKit observability events** (per session end): one row with
  ``events`` = the count of MetricsCollectedEvent fan-out for this session
  and ``model="livekit/observability-event"``.

Cross-provider correlation
--------------------------
Every row carries the same ``session_id`` (the LiveKit room name passed
into the constructor) so the dashboard can join all four providers' rows
back together for a single call. Each row also carries an
``idempotency_key`` derived from
``f"{session_id}:{kind}:{request_id_or_seq}"`` so a transient HTTP retry
won't create a duplicate row (the API endpoint enforces uniqueness via
``idx_request_logs_idempotency``).

Subscription quotas (LiveKit Build/Ship/Scale, ElevenLabs Pro/etc.) are
NOT applied here — per-row costing has no view of monthly aggregation. The
dashboard subtracts ``subscription_tiers[tier].included_units`` from the
monthly sum before applying the per-unit overage rate.

Usage
-----

Wire the shim into a LiveKit ``AgentSession`` like this::

    from superpenguin.voice import LiveKitObservability

    obs = LiveKitObservability(
        session_id=ctx.room.name,
        metadata={"customer_id": restaurant_id, "feature": "drive-thru-orders"},
    )

    @session.on("metrics_collected")
    def _on_metrics(ev):
        asyncio.create_task(obs.on_metrics(ev))

    # On session end (you decide how to detect it — disconnected room,
    # explicit end signal, etc.):
    await obs.on_session_end(duration_seconds=elapsed)

The shim is async-safe but does not require an event loop — submission
happens through ``superpenguin.get_client().submit()`` which enqueues to a
background daemon thread.
"""

from __future__ import annotations

import logging
from typing import Any

from superpenguin._voice_submit import submit_voice_event

logger = logging.getLogger("superpenguin.voice")


# Default models used for cost lookup. These match the pricing entries
# seeded in pricing/models.json on 2026-04-20. Override in the constructor
# if NightShift switches to a different SKU (e.g. nova-3-multilingual).
_DEFAULT_STT_PROVIDER = "deepgram"
_DEFAULT_STT_MODEL = "deepgram/nova-3-monolingual"
_DEFAULT_TTS_PROVIDER = "elevenlabs"
_DEFAULT_TTS_MODEL = "elevenlabs/eleven_flash_v2_5"
_LIVEKIT_PROVIDER = "livekit"
_LIVEKIT_SESSION_MODEL = "livekit/agent-session-minute"
_LIVEKIT_EVENT_MODEL = "livekit/observability-event"


class LiveKitObservability:
    """Submits LiveKit Agents STT/TTS/session metrics to the cost-management
    backend with cross-provider correlation via ``session_id``.

    LLM metrics are intentionally not submitted from this shim — the SDK's
    ``wrap()`` path already captures them with full token detail.
    """

    def __init__(
        self,
        *,
        session_id: str,
        metadata: dict[str, Any] | None = None,
        stt_provider: str = _DEFAULT_STT_PROVIDER,
        stt_model: str = _DEFAULT_STT_MODEL,
        tts_provider: str = _DEFAULT_TTS_PROVIDER,
        tts_model: str = _DEFAULT_TTS_MODEL,
        routing_path: str = "direct",
    ) -> None:
        """Initialize an observability shim bound to one LiveKit session.

        Args:
            session_id: Cross-provider correlation id. Pass the LiveKit
                room name so STT/TTS/LLM/LiveKit rows for this call all
                join on a single key in the dashboard.
            metadata: Tags applied to every emitted row (e.g.
                ``{"customer_id": "...", "feature": "drive-thru"}``).
                Goes into ``request_logs.custom_tags``.
            stt_provider/stt_model: Identifies which STT pricing entry to
                use. Defaults to Deepgram Nova-3 monolingual.
            tts_provider/tts_model: Identifies which TTS pricing entry.
                Defaults to ElevenLabs Flash v2.5.
            routing_path: ``"direct"`` (default) when the agent calls
                Deepgram/ElevenLabs/etc. directly; ``"livekit_inference"``
                when LiveKit's bundled inference is used. Set on every
                emitted row so the dashboard can reconcile against
                LiveKit's invoice (which double-bills bundled-inference
                paths through its own Inference credits meter).
        """
        self.session_id = session_id
        self.metadata = dict(metadata or {})
        self.stt_provider = stt_provider
        self.stt_model = stt_model
        self.tts_provider = tts_provider
        self.tts_model = tts_model
        self.routing_path = routing_path

        # Counters for session-end emission. Incremented every time
        # `on_metrics` accepts a row so the LiveKit observability-events
        # meter can be priced accurately at session end without an extra
        # subscription to LiveKit's webhook stream.
        self._observability_event_count: int = 0
        # Monotonic counter used as a fallback idempotency-suffix when a
        # MetricsCollectedEvent arrives without a stable request_id.
        self._fallback_seq: int = 0

    # ------------------------------------------------------------------
    # Public emit API
    # ------------------------------------------------------------------

    async def on_metrics(self, ev: Any) -> None:
        """Receiver for LiveKit Agents' ``MetricsCollectedEvent``.

        Dispatches on the metric subtype:
          * ``STTMetrics`` → one Deepgram row (audio_seconds + cost)
          * ``TTSMetrics`` → one ElevenLabs row (characters + audio_seconds + cost)
          * ``LLMMetrics`` → SKIPPED (already captured by sp.wrap())
          * Other (VAD, EOU, ...) → SKIPPED (not currently billed)

        Safe to call from a synchronous event handler via
        ``asyncio.create_task(obs.on_metrics(ev))``. The actual HTTP submit
        happens on a background daemon thread so this returns ~immediately
        regardless of network latency.
        """
        # Always count the event for the LiveKit observability meter,
        # whether or not we end up emitting a billing row for it.
        self._observability_event_count += 1

        metrics = getattr(ev, "metrics", ev)
        type_name = type(metrics).__name__

        if type_name == "STTMetrics":
            self._emit_stt(metrics)
        elif type_name == "TTSMetrics":
            self._emit_tts(metrics)
        elif type_name == "LLMMetrics":
            # Intentional no-op. The LLM call is already captured by the
            # client wrapper installed via sp.wrap(). Re-emitting here
            # would create a second request_logs row for the same LLM
            # request and double the reported cost.
            return
        else:
            # VADMetrics, EOUMetrics, future subtypes — not billed today.
            # Counting them above is enough to keep the LiveKit
            # observability-events meter accurate; we don't emit a row.
            return

    async def on_session_end(
        self,
        *,
        duration_seconds: float,
        extra_observability_events: int = 0,
    ) -> None:
        """Emit per-session LiveKit billing rows when the session terminates.

        Args:
            duration_seconds: Wall-clock seconds the agent session was
                active. LiveKit bills this against the agent-session-minute
                meter (per-second precision; LiveKit rounds to seconds
                internally before applying its $0.01/min overage rate).
            extra_observability_events: Add to the count of observability
                events emitted by `on_metrics` for this session. Use this
                if the agent dispatches additional non-Metrics events
                (state changes, errors, etc.) that LiveKit's observability
                ingest will see and bill for. Pass 0 (default) when you
                only want to count what flowed through `on_metrics`.
        """
        if duration_seconds > 0:
            self._submit_row(
                provider=_LIVEKIT_PROVIDER,
                model=_LIVEKIT_SESSION_MODEL,
                modality="session",
                audio_seconds=duration_seconds,
                idempotency_kind="session-end",
                idempotency_id="end",
            )

        total_events = self._observability_event_count + max(0, extra_observability_events)
        if total_events > 0:
            self._submit_row(
                provider=_LIVEKIT_PROVIDER,
                model=_LIVEKIT_EVENT_MODEL,
                modality="event",
                events=total_events,
                idempotency_kind="obs-events",
                idempotency_id="end",
            )

    # ------------------------------------------------------------------
    # Internal emitters
    # ------------------------------------------------------------------

    def _emit_stt(self, m: Any) -> None:
        """Build and submit one Deepgram-billable STT row."""
        audio_seconds = float(getattr(m, "audio_duration", 0.0) or 0.0)
        if audio_seconds <= 0:
            return  # Empty turn — no billable audio, no row.
        latency_ms = self._latency_ms(m)
        idempotency_id = self._stable_id(m)
        self._submit_row(
            provider=self.stt_provider,
            model=self.stt_model,
            modality="audio_in",
            audio_seconds=audio_seconds,
            latency_ms=latency_ms,
            idempotency_kind="stt",
            idempotency_id=idempotency_id,
        )

    def _emit_tts(self, m: Any) -> None:
        """Build and submit one ElevenLabs-billable TTS row.

        characters_count is the billable unit; audio_duration is recorded
        for analytics (TTS is not billed by audio-seconds today, but having
        it lets the dashboard show real-time-factor and other quality
        metrics alongside cost).
        """
        characters = int(getattr(m, "characters_count", 0) or 0)
        audio_seconds = float(getattr(m, "audio_duration", 0.0) or 0.0)
        if characters <= 0:
            return  # Synthesizer was preempted before generating any audio.
        latency_ms = self._latency_ms(m)
        idempotency_id = self._stable_id(m)
        self._submit_row(
            provider=self.tts_provider,
            model=self.tts_model,
            modality="audio_out",
            characters=characters,
            audio_seconds=audio_seconds,
            latency_ms=latency_ms,
            idempotency_kind="tts",
            idempotency_id=idempotency_id,
        )

    def _submit_row(
        self,
        *,
        provider: str,
        model: str,
        modality: str,
        idempotency_kind: str,
        idempotency_id: str,
        audio_seconds: float = 0.0,
        characters: int = 0,
        events: int = 0,
        latency_ms: int | None = None,
    ) -> None:
        """Compose one ``request_logs`` row and submit through the global SDK client.

        Routes through ``_voice_submit.submit_voice_event``, which is also
        used by the standalone ``sp.wrap(deepgram_client)`` and
        ``sp.wrap(elevenlabs_client)`` paths — keeping all three voice
        emitters on one event-shape contract. The shim's job here is to
        compose the LiveKit-specific bits (session_id, idempotency_key,
        routing_path, ``streaming=True``) and hand off.

        Cost is computed client-side using the pricing table bundled with
        this SDK build. The server treats the submitted value as
        authoritative; if the pricing table is later updated, a manual
        backfill is needed (same as for token rows today).
        """
        # LiveKit shim emissions always set streaming=True (each
        # MetricsCollectedEvent corresponds to a streamed turn) and carry
        # an idempotency key so a duplicate fire of the same turn no-ops
        # at the ingest endpoint.
        idempotency_key = f"{self.session_id}:{idempotency_kind}:{idempotency_id}"

        # The shared helper expects an `extra` dict shaped the same way the
        # LLM wrapper builds it (i.e. {"metadata": {...}}). Wrap our
        # constructor metadata to fit that contract.
        extra = {"metadata": self.metadata}

        # started_at=ended_at + explicit latency_ms tells the helper to
        # honor the LiveKit-reported latency rather than computing one
        # from wall clock (which would be ~0 since we're inside the
        # callback, not the original RPC).
        import time as _time

        now = _time.time()
        submit_voice_event(
            provider=provider,
            model=model,
            modality=modality,
            extra=extra,
            started_at=now,
            ended_at=now,
            audio_seconds=audio_seconds,
            characters=characters,
            events=events,
            latency_ms=latency_ms,
            status_code=200,
            streaming=True,
            session_id=self.session_id,
            idempotency_key=idempotency_key,
            routing_path=self.routing_path,
        )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _stable_id(self, m: Any) -> str:
        """Return a stable per-metric id for idempotency-key construction.

        LiveKit's STTMetrics/TTSMetrics expose a ``request_id`` that is
        unique per provider call. When it's missing (older versions, or
        synthetic events), fall back to a monotonic per-shim counter so
        the key stays unique within the session even though it loses
        retry-deduplication for that one metric.
        """
        request_id = getattr(m, "request_id", None) or getattr(m, "speech_id", None)
        if request_id:
            return str(request_id)
        self._fallback_seq += 1
        return f"seq{self._fallback_seq}"

    @staticmethod
    def _latency_ms(m: Any) -> int | None:
        """Best-effort latency extraction. LiveKit metrics expose a few
        time-to-* fields depending on subtype (TTSMetrics has ttft, STT
        has ``duration``). Returns the most useful one in milliseconds, or
        None if nothing is available."""
        for attr in ("ttft", "duration"):
            v = getattr(m, attr, None)
            if v is not None:
                try:
                    return int(float(v) * 1000.0)
                except (TypeError, ValueError):
                    continue
        return None


__all__ = ["LiveKitObservability"]
