"""@trace() decorator — groups LLM calls under a parent trace via contextvars."""

from __future__ import annotations

import asyncio
import functools
import logging
import time
import uuid
from typing import Any, Callable, TypeVar, overload

from superpenguin._context import current_trace_id, current_trace_metadata

logger = logging.getLogger("superpenguin")

F = TypeVar("F", bound=Callable[..., Any])


# ---------------------------------------------------------------------------
# Public API — supports @sp.trace, @sp.trace(), and @sp.trace("name")
# ---------------------------------------------------------------------------


@overload
def trace(fn: F) -> F: ...


@overload
def trace(
    name: str | None = None,
    *,
    tags: list[str] | None = None,
    metadata: dict[str, Any] | None = None,
) -> Callable[[F], F]: ...


def trace(
    fn: F | str | None = None,
    *,
    name: str | None = None,
    tags: list[str] | None = None,
    metadata: dict[str, Any] | None = None,
) -> F | Callable[[F], F]:
    """Decorator that wraps a function as a SuperPenguin trace.

    LLM calls made through a ``wrap()``-ed client inside the decorated
    function are automatically linked via ``parent_trace_id``.

    Usage::

        @sp.trace
        def answer(question: str) -> str: ...

        @sp.trace("my-pipeline")
        def answer(question: str) -> str: ...

        @sp.trace(tags=["prod"], metadata={"customer_id": "acme_123"})
        def answer(question: str) -> str: ...
    """
    if callable(fn):
        return _wrap_fn(fn, name=None, tags=tags, metadata=metadata)  # type: ignore[return-value]

    if isinstance(fn, str):
        trace_name = fn

        def decorator(func: F) -> F:
            return _wrap_fn(func, name=trace_name, tags=tags, metadata=metadata)  # type: ignore[return-value]

        return decorator  # type: ignore[return-value]

    def decorator(func: F) -> F:
        return _wrap_fn(func, name=name, tags=tags, metadata=metadata)  # type: ignore[return-value]

    return decorator  # type: ignore[return-value]


# ---------------------------------------------------------------------------
# Internals
# ---------------------------------------------------------------------------


def _wrap_fn(
    fn: Callable[..., Any],
    *,
    name: str | None,
    tags: list[str] | None,
    metadata: dict[str, Any] | None,
) -> Any:
    trace_name = name or fn.__qualname__

    if asyncio.iscoroutinefunction(fn):

        @functools.wraps(fn)
        async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
            return await _run_async(fn, trace_name, tags, metadata, args, kwargs)

        return async_wrapper

    @functools.wraps(fn)
    def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
        return _run_sync(fn, trace_name, tags, metadata, args, kwargs)

    return sync_wrapper


def _run_sync(
    fn: Callable[..., Any],
    trace_name: str,
    tags: list[str] | None,
    extra_metadata: dict[str, Any] | None,
    args: tuple[Any, ...],
    kwargs: dict[str, Any],
) -> Any:
    trace_id = str(uuid.uuid4())
    id_token = current_trace_id.set(trace_id)
    meta_token = (
        current_trace_metadata.set(dict(extra_metadata))
        if extra_metadata
        else None
    )
    try:
        return fn(*args, **kwargs)
    finally:
        if meta_token is not None:
            current_trace_metadata.reset(meta_token)
        current_trace_id.reset(id_token)


async def _run_async(
    fn: Callable[..., Any],
    trace_name: str,
    tags: list[str] | None,
    extra_metadata: dict[str, Any] | None,
    args: tuple[Any, ...],
    kwargs: dict[str, Any],
) -> Any:
    trace_id = str(uuid.uuid4())
    id_token = current_trace_id.set(trace_id)
    meta_token = (
        current_trace_metadata.set(dict(extra_metadata))
        if extra_metadata
        else None
    )
    try:
        return await fn(*args, **kwargs)
    finally:
        if meta_token is not None:
            current_trace_metadata.reset(meta_token)
        current_trace_id.reset(id_token)
