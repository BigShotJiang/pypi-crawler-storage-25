"""Shared submit path for non-token (voice / audio / event) ``request_logs`` rows.

Three call sites compose into this helper, all of which need an identical
event-shape contract with the dashboard's ``/api/sdk/ingest`` route:

  1. ``superpenguin.voice.LiveKitObservability`` — per-turn STT/TTS rows + a
     pair of LiveKit rows on session-end. Always carries a ``session_id`` and
     an ``idempotency_key`` since the same MetricsCollectedEvent can be
     re-fired by LiveKit on transient retry.

  2. ``superpenguin._deepgram.wrap_deepgram_client`` — one row per
     ``transcribe_url`` / ``transcribe_file`` REST call. No session
     correlation by default — each call is atomic.

  3. ``superpenguin._elevenlabs.wrap_elevenlabs_client`` — one row per
     ``text_to_speech.convert(...)`` / ``text_to_sound_effects.convert(...)``.
     Same atomicity story.

Why this lives in its own module
--------------------------------
The token-billing wrapper (``_wrap.py::_submit``) already exists with its
own field set (``input_tokens`` / ``output_tokens`` / ``cached_tokens``) that
should NOT leak into voice rows (the ingest route happily defaults the voice
fields to 0/null when missing — keeping the two paths separate avoids any
accidental mixing). Extracting the voice path here also means a future
non-LiveKit voice provider (say, AssemblyAI or Cartesia) can compose into the
same helper instead of forking the per-row event shape.

Subscription quotas note
------------------------
``calculate_unit_cost_micros`` deliberately ignores
``subscription_tiers[tier].included_units`` — per-call costing is unaware of
monthly aggregation. The dashboard subtracts the tier's included units from
the monthly sum and applies the per-unit overage rate to whatever's left.
This helper inherits that behavior unchanged.
"""

from __future__ import annotations

import logging
import time
from typing import Any

from superpenguin._pricing import calculate_unit_cost_micros

logger = logging.getLogger("superpenguin")


# Known top-level attribution fields the ingest route promotes from event
# JSON onto first-class ``request_logs`` columns (the rest land in
# ``custom_tags``). Mirrors the set in ``_wrap.py``; kept separate here so
# touching the LLM wrapper doesn't accidentally drift the voice contract.
_KNOWN_ATTRIBUTION_KEYS: tuple[str, ...] = (
    "customer_id",
    "feature",
    "team",
    "environment",
    "prompt_key",
    "prompt_version",
)


def units_for_billing_unit(
    *,
    modality: str,
    audio_seconds: float = 0.0,
    characters: int = 0,
    events: int = 0,
) -> float:
    """Pick the count to feed ``calculate_unit_cost_micros`` based on modality.

    Mirrors the contract that the ``billing_unit`` validator and the
    pricing-calc agree on: ``audio_in`` and ``session`` bill on
    audio-seconds, ``audio_out`` bills on characters (ElevenLabs charges
    per char, not per audio-second), ``event`` bills on the event count.
    Unknown modality returns 0 so the calculator emits cost=0 instead of
    overcharging — the row is still recorded for debugging.
    """
    if modality in ("audio_in", "session"):
        return float(audio_seconds)
    if modality == "audio_out":
        return float(characters)
    if modality == "event":
        return float(events)
    return 0.0


def submit_voice_event(
    *,
    provider: str,
    model: str,
    modality: str,
    extra: dict[str, Any],
    call_meta: dict[str, Any] | None = None,
    started_at: float,
    ended_at: float | None = None,
    audio_seconds: float = 0.0,
    characters: int = 0,
    events: int = 0,
    latency_ms: int | None = None,
    status_code: int = 200,
    streaming: bool = False,
    session_id: str | None = None,
    idempotency_key: str | None = None,
    routing_path: str | None = None,
    cost_micros_override: int | None = None,
) -> None:
    """Compose one voice-shaped ``request_logs`` row and submit it.

    Args:
        provider: Provider slug (``"deepgram"``, ``"elevenlabs"``, ``"livekit"``).
            Goes into the ``provider`` column verbatim — must match the
            slug the dashboard tabs key off of.
        model: Canonical or bare model id. Resolves through ``_normalize_model``
            inside the cost calculator, so ``"deepgram/nova-3-monolingual"``
            and ``"nova-3-monolingual"`` both work.
        modality: One of ``audio_in`` / ``audio_out`` / ``session`` / ``event``.
            Drives ``units_for_billing_unit``.
        extra: The ``extra`` dict the wrapper built on init — carries
            default ``metadata`` and ``tags`` from the ``sp.wrap()`` call.
        call_meta: Optional per-call metadata override (today only the LLM
            wrappers populate this via ``extra_body``; voice wrappers pass
            None until ``sp.context()`` lands).
        started_at: ``time.time()`` at call start. Used for ``latency_ms``
            when the caller doesn't pass one explicitly.
        ended_at: ``time.time()`` at call end. Defaults to "now".
        audio_seconds: Billable audio duration on STT / LiveKit-session rows.
            On TTS rows, kept as analytics info (not the billing unit).
        characters: Billable character count on TTS / sound-effects rows.
        events: LiveKit observability event count.
        latency_ms: Explicit override; otherwise computed from started/ended.
        status_code: Defaults to 200. Pass the provider error code on failure.
        streaming: Whether the underlying call streamed.
        session_id: Cross-provider correlation key. None for standalone calls.
        idempotency_key: When set, the ingest route routes this row through
            an upsert with ``ON CONFLICT (user_id, idempotency_key) DO NOTHING``,
            making a transient retry a no-op. Standalone callers usually
            pass None.
        routing_path: ``"direct"`` or ``"livekit_inference"``. Only meaningful
            for LiveKit-shim emissions; standalone Deepgram/ElevenLabs callers
            should pass None and the column stays NULL.
        cost_micros_override: Bypass the calculator entirely. Reserved for
            tests and for callers that already computed a tier-aware cost
            (e.g. monthly subscription cron).
    """
    if ended_at is None:
        ended_at = time.time()

    if cost_micros_override is not None:
        cost_micros = cost_micros_override
    else:
        units = units_for_billing_unit(
            modality=modality,
            audio_seconds=audio_seconds,
            characters=characters,
            events=events,
        )
        cost_micros = calculate_unit_cost_micros(model, units) if units > 0 else 0

    if latency_ms is None:
        latency_ms = max(0, round((ended_at - started_at) * 1000))

    from superpenguin._context import merged_metadata

    default_meta = extra.get("metadata")
    merged_meta = merged_metadata(
        default_meta if isinstance(default_meta, dict) else None,
        call_meta,
    )

    event: dict[str, Any] = {
        "provider": provider,
        "model": model,
        "modality": modality,
        "audio_seconds": float(audio_seconds),
        "characters": int(characters),
        "events": int(events),
        "cost_usd_micros": int(cost_micros),
        "latency_ms": latency_ms,
        "status_code": status_code,
        "streaming": streaming,
        # has_tools / has_vision are token-row concepts; voice rows always
        # report False so the column never goes NULL on a voice insert.
        "has_tools": False,
        "has_vision": False,
    }
    if session_id is not None:
        event["session_id"] = session_id
    if idempotency_key is not None:
        event["idempotency_key"] = idempotency_key
    if routing_path is not None:
        event["routing_path"] = routing_path

    # Promote known attribution keys to top-level event fields; everything
    # else (custom strings) routes into ``custom_tags`` so the ingest route
    # stores it on the JSON column.
    custom_tags: dict[str, str] = {}
    for key, value in merged_meta.items():
        if key == "custom_tags" and isinstance(value, dict):
            for ck, cv in value.items():
                if isinstance(cv, str):
                    custom_tags[ck] = cv
            continue
        if value is None:
            continue
        if key in _KNOWN_ATTRIBUTION_KEYS:
            event[key] = (
                str(value) if key == "prompt_version" else value
            )
        elif isinstance(value, str):
            custom_tags[key] = value
    if custom_tags:
        event["custom_tags"] = custom_tags

    # Lazy import to break the import cycle (voice.py imports superpenguin
    # which exports get_client; importing get_client at module scope here
    # would trigger superpenguin.__init__ before its own imports settle on
    # cold start).
    from superpenguin import get_client

    try:
        client = get_client()
    except RuntimeError:
        # SDK not initialized — log once and skip rather than raising. The
        # voice/ingest call sites are typically inside provider callbacks
        # or middleware; raising here would crash the user's pipeline.
        logger.warning(
            "superpenguin: SDK not initialized (set SP_API_KEY or call "
            "sp.init()); dropping %s row for %s/%s",
            modality,
            provider,
            model,
        )
        return
    try:
        client.submit(event)
    except Exception:
        logger.debug("superpenguin: failed to submit voice event", exc_info=True)


__all__ = ["submit_voice_event", "units_for_billing_unit"]
