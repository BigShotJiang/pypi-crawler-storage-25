"""Standalone ElevenLabs client wrapper for ``sp.wrap()``.

Why this exists separately from the LiveKit observability shim
--------------------------------------------------------------
The LiveKit shim only emits TTS rows when LiveKit's
``MetricsCollectedEvent`` stream produces a ``TTSMetrics``. Standalone
ElevenLabs users (most of them — anyone calling ``client.text_to_speech.
convert(...)`` directly from a backend) never see those events. This
module is the on-call hook for them.

Scope (v1 — what we wrap today)
-------------------------------
* ``client.text_to_speech.convert`` (sync + async)
* ``client.text_to_speech.convert_as_stream`` (sync + async, wrapped
  through a stream proxy so latency reflects time-to-completion rather
  than time-to-generator-construction)
* ``client.text_to_sound_effects.convert`` (sync + async, both regular
  and streamed where the SDK exposes them)

Each wrapped call submits one ``request_logs`` row with:

  * ``provider="elevenlabs"``, ``modality="audio_out"``
  * ``characters = len(text)`` from the call's ``text`` argument
  * ``model = "elevenlabs/<model_id>"`` where ``model_id`` comes from
    the call's ``model_id`` kwarg (defaulting to ``eleven_flash_v2_5``
    when the SDK is using its own default)
  * ``cost_usd_micros`` computed from the bundled pricing table

Scope (v1 — what we explicitly do NOT wrap)
-------------------------------------------
* ``client.speech_to_speech.convert`` — different billing unit (per
  audio-second of input), not yet seeded in pricing/models.json.
* Voice changer — per-minute, not yet seeded.
* Real-time WebSocket TTS (``client.text_to_speech.stream``) — uses a
  bidirectional WebSocket; out of scope for this iteration.
* Conversational AI — separate billing model, not yet seeded.

Per-call metadata override
--------------------------
ElevenLabs request models don't expose an ``extra_body`` equivalent, so
per-call ``customer_id`` / ``feature`` overrides are NOT supported in v1.
Pass defaults via ``sp.wrap(..., metadata={...})``. A ``sp.context()``
context manager is planned and will land in a separate change set.

Anti-double-counting note
-------------------------
If you also use ``LiveKitObservability``, do NOT additionally wrap the
ElevenLabs client used inside the LiveKit Agents plugin — both paths
would emit a row for the same synthesis and double the cost.
"""

from __future__ import annotations

import functools
import logging
import time
from typing import Any

from superpenguin._voice_submit import submit_voice_event

logger = logging.getLogger("superpenguin.elevenlabs")


_PROVIDER = "elevenlabs"
_MODALITY = "audio_out"
# Aligns with what most ElevenLabs SDK callers leave as the default in 2026.
_DEFAULT_MODEL_ID = "eleven_flash_v2_5"


# Resources to patch on every wrapped client. Each entry:
#   (resource_attribute, method_name, is_stream)
# resource_attribute is the attribute on the client (e.g.
# ``text_to_speech``); method_name is the function to wrap; is_stream
# indicates whether the result is an iterator we need to proxy through
# rather than discard immediately.
_TEXT_TO_AUDIO_METHODS: tuple[tuple[str, str, bool], ...] = (
    ("text_to_speech", "convert", False),
    ("text_to_speech", "convert_as_stream", True),
    ("text_to_sound_effects", "convert", False),
    ("text_to_sound_effects", "convert_as_stream", True),
)


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------


def wrap_elevenlabs_client(
    client: Any,
    *,
    name: str | None = None,
    metadata: dict[str, Any] | None = None,
    tags: list[str] | None = None,
) -> Any:
    """Patch an ``ElevenLabs`` (or ``AsyncElevenLabs``) client in-place.

    The original ``client`` is mutated and returned, mirroring
    ``sp.wrap(openai_client)``. Methods that don't exist on this SDK
    version are silently skipped, so an SDK upgrade that drops a
    method won't break the wrap call.

    Args:
        client: An ``elevenlabs.client.ElevenLabs`` or
            ``elevenlabs.client.AsyncElevenLabs`` instance. Async-ness
            is auto-detected from the class name (``"Async"`` prefix).
        name: Reserved for parity with the LLM wrapper; unused today.
        metadata: Default attribution applied to every emitted row.
            Same key conventions as the LLM wrapper.
        tags: Reserved for parity; unused today.

    Returns:
        The same ``client`` instance, mutated in place.
    """
    extra: dict[str, Any] = {}
    if name:
        extra["name"] = name
    if metadata:
        extra["metadata"] = metadata
    if tags:
        extra["tags"] = tags

    is_async = "Async" in type(client).__name__

    for resource_attr, method_name, is_stream in _TEXT_TO_AUDIO_METHODS:
        _patch_method(
            client, resource_attr, method_name,
            is_async=is_async, is_stream=is_stream, extra=extra,
        )

    return client


# ---------------------------------------------------------------------------
# Patching helpers
# ---------------------------------------------------------------------------


def _patch_method(
    client: Any,
    resource_attr: str,
    method_name: str,
    *,
    is_async: bool,
    is_stream: bool,
    extra: dict[str, Any],
) -> None:
    """Replace ``client.<resource_attr>.<method_name>`` with a tracked wrapper.

    The ElevenLabs SDK exposes resources as cached attributes on the
    client (e.g. ``client.text_to_speech`` is a ``TextToSpeechClient``
    instance). We patch the bound method on that resource object so all
    subsequent calls flow through the wrapper. If the resource doesn't
    exist (older/newer SDK without this surface), we skip silently.
    """
    resource = getattr(client, resource_attr, None)
    if resource is None:
        return
    original = getattr(resource, method_name, None)
    if original is None:
        return
    # Avoid double-wrapping if user calls sp.wrap() twice on the same client.
    if getattr(original, "__sp_wrapped__", False):
        return

    if is_async:

        @functools.wraps(original)
        async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
            return await _track_async(
                original, resource_attr, method_name, extra,
                args, kwargs, is_stream=is_stream,
            )

        async_wrapper.__sp_wrapped__ = True  # type: ignore[attr-defined]
        wrapped: Any = async_wrapper
    else:

        @functools.wraps(original)
        def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
            return _track_sync(
                original, resource_attr, method_name, extra,
                args, kwargs, is_stream=is_stream,
            )

        sync_wrapper.__sp_wrapped__ = True  # type: ignore[attr-defined]
        wrapped = sync_wrapper

    try:
        setattr(resource, method_name, wrapped)
    except (AttributeError, TypeError):
        logger.debug(
            "superpenguin: could not patch elevenlabs.%s.%s",
            resource_attr, method_name,
        )


# ---------------------------------------------------------------------------
# Tracking
# ---------------------------------------------------------------------------


def _track_sync(
    fn: Any,
    resource_attr: str,
    method_name: str,
    extra: dict[str, Any],
    args: tuple[Any, ...],
    kwargs: dict[str, Any],
    *,
    is_stream: bool,
) -> Any:
    started = time.time()
    text = _extract_text(args, kwargs)
    model_id = _extract_model_id(kwargs)
    canonical = _canonicalize_elevenlabs_model(model_id)
    characters = len(text or "")

    # Empty/missing text — no billable work. Hand off to the SDK without
    # emitting a zero-row (cleaner than recording cost=0 spam).
    if characters == 0:
        return fn(*args, **kwargs)

    try:
        result = fn(*args, **kwargs)
    except Exception as exc:
        _submit_error(extra, canonical, characters, exc, started)
        raise

    if is_stream and _looks_iterable(result):
        # Proxy the iterator so we submit when the user has finished
        # consuming the audio bytes — that captures real synthesis
        # latency. Cost is fixed at len(text) regardless of how the
        # user consumes the stream.
        return _SyncStreamProxy(
            result,
            on_done=lambda: _submit_success(
                extra, canonical, characters, started, streaming=True,
            ),
        )

    _submit_success(extra, canonical, characters, started, streaming=False)
    return result


async def _track_async(
    fn: Any,
    resource_attr: str,
    method_name: str,
    extra: dict[str, Any],
    args: tuple[Any, ...],
    kwargs: dict[str, Any],
    *,
    is_stream: bool,
) -> Any:
    started = time.time()
    text = _extract_text(args, kwargs)
    model_id = _extract_model_id(kwargs)
    canonical = _canonicalize_elevenlabs_model(model_id)
    characters = len(text or "")

    if characters == 0:
        return await fn(*args, **kwargs)

    try:
        result = await fn(*args, **kwargs)
    except Exception as exc:
        _submit_error(extra, canonical, characters, exc, started)
        raise

    if is_stream and _looks_async_iterable(result):
        return _AsyncStreamProxy(
            result,
            on_done=lambda: _submit_success(
                extra, canonical, characters, started, streaming=True,
            ),
        )

    _submit_success(extra, canonical, characters, started, streaming=False)
    return result


def _submit_success(
    extra: dict[str, Any],
    model: str,
    characters: int,
    started: float,
    streaming: bool,
) -> None:
    submit_voice_event(
        provider=_PROVIDER,
        model=model,
        modality=_MODALITY,
        extra=extra,
        started_at=started,
        ended_at=time.time(),
        characters=characters,
        status_code=200,
        streaming=streaming,
    )


def _submit_error(
    extra: dict[str, Any],
    model: str,
    characters: int,
    exc: Exception,
    started: float,
) -> None:
    """On failure, submit a row with the (intended) characters but cost=0.

    We pass cost_micros_override=0 because the synthesis didn't complete
    — ElevenLabs doesn't bill failed requests. This still gives the
    dashboard a record that the request happened (for error-rate /
    latency dashboards) without polluting the cost number.
    """
    status_code = _coerce_status_code(exc)
    submit_voice_event(
        provider=_PROVIDER,
        model=model,
        modality=_MODALITY,
        extra=extra,
        started_at=started,
        ended_at=time.time(),
        characters=characters,
        status_code=status_code,
        streaming=False,
        cost_micros_override=0,
    )


# ---------------------------------------------------------------------------
# Argument extraction
# ---------------------------------------------------------------------------


def _extract_text(args: tuple[Any, ...], kwargs: dict[str, Any]) -> str | None:
    """Pull the ``text`` argument off a TTS / sound-effects call.

    ElevenLabs SDK signatures vary slightly:
      * ``text_to_speech.convert(voice_id, *, text, model_id, ...)``
      * ``text_to_sound_effects.convert(*, text, ...)``
    Some legacy versions accept text positionally as the first or second
    arg. Probe kwargs first (the documented path), then fall back to
    positional.
    """
    if "text" in kwargs:
        v = kwargs["text"]
        return v if isinstance(v, str) else None
    # Positional fallback — try args[0], then args[1].
    for candidate in args[:2]:
        if isinstance(candidate, str):
            return candidate
    return None


def _extract_model_id(kwargs: dict[str, Any]) -> str | None:
    """Pull the ``model_id`` (or ``model``) keyword argument.

    ElevenLabs uses ``model_id`` everywhere, but some user code mirrors
    the OpenAI/Anthropic ``model`` convention via wrapper helpers.
    Accept both.
    """
    for key in ("model_id", "model"):
        v = kwargs.get(key)
        if isinstance(v, str) and v:
            return v
    return None


def _canonicalize_elevenlabs_model(raw_model: str | None) -> str:
    """Normalize an ElevenLabs model id into a canonical pricing slug.

    ElevenLabs model ids (``eleven_flash_v2_5``, ``eleven_v3``,
    ``eleven_multilingual_v2``, ...) are unique and don't need the kind
    of mono/multi disambiguation Deepgram needs. We just prefix
    ``elevenlabs/`` if the user didn't already.
    """
    raw = (raw_model or "").strip()
    if not raw:
        raw = _DEFAULT_MODEL_ID
    if raw.startswith("elevenlabs/"):
        return raw
    return f"elevenlabs/{raw}"


# ---------------------------------------------------------------------------
# Stream proxies — mirror _SyncStreamProxy / _AsyncStreamProxy in _wrap.py
# but without the chunk-accumulator (we don't need to inspect chunks; cost
# is fixed at len(text) and we just need a "stream consumed" signal).
# ---------------------------------------------------------------------------


class _SyncStreamProxy:
    """Wrap a sync iterator so we know when the consumer has finished.

    Used for ``convert_as_stream`` results. Fires ``on_done()`` exactly
    once when the underlying iterator raises StopIteration (success),
    when ``close()`` is called, or when the proxy is garbage-collected
    inside a ``with`` block. Subsequent ``on_done()`` invocations are
    no-ops to keep the cost row count honest.
    """

    def __init__(self, stream: Any, on_done: Any) -> None:
        self._stream = stream
        self._on_done = on_done
        self._done = False

    def __iter__(self) -> Any:
        try:
            for chunk in self._stream:
                yield chunk
        finally:
            self._finish()

    def __enter__(self) -> _SyncStreamProxy:
        if hasattr(self._stream, "__enter__"):
            self._stream.__enter__()
        return self

    def __exit__(self, *args: Any) -> Any:
        self._finish()
        if hasattr(self._stream, "__exit__"):
            return self._stream.__exit__(*args)
        return None

    def close(self) -> None:
        self._finish()
        if hasattr(self._stream, "close"):
            self._stream.close()

    def _finish(self) -> None:
        if self._done:
            return
        self._done = True
        try:
            self._on_done()
        except Exception:
            logger.debug("superpenguin: error in elevenlabs stream callback", exc_info=True)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._stream, name)


class _AsyncStreamProxy:
    """Async equivalent of ``_SyncStreamProxy``."""

    def __init__(self, stream: Any, on_done: Any) -> None:
        self._stream = stream
        self._on_done = on_done
        self._done = False

    async def __aiter__(self) -> Any:
        try:
            async for chunk in self._stream:
                yield chunk
        finally:
            self._finish()

    async def __aenter__(self) -> _AsyncStreamProxy:
        if hasattr(self._stream, "__aenter__"):
            await self._stream.__aenter__()
        return self

    async def __aexit__(self, *args: Any) -> Any:
        self._finish()
        if hasattr(self._stream, "__aexit__"):
            return await self._stream.__aexit__(*args)
        return None

    def _finish(self) -> None:
        if self._done:
            return
        self._done = True
        try:
            self._on_done()
        except Exception:
            logger.debug("superpenguin: error in elevenlabs stream callback", exc_info=True)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._stream, name)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _looks_iterable(obj: Any) -> bool:
    """True when ``obj`` is an iterator/generator we should proxy.

    Excludes raw ``bytes`` (which is technically iterable but
    short-circuits to the success path — we treat the call as
    non-streaming if the SDK already materialized the audio).
    """
    if isinstance(obj, (bytes, bytearray, str)):
        return False
    return hasattr(obj, "__iter__") or hasattr(obj, "__next__")


def _looks_async_iterable(obj: Any) -> bool:
    """True when ``obj`` is an async iterator we should proxy."""
    return hasattr(obj, "__aiter__") or hasattr(obj, "__anext__")


def _coerce_status_code(exc: Exception) -> int:
    """Best-effort HTTP status pull off an ElevenLabs exception."""
    for attr in ("status_code", "status", "code"):
        v = getattr(exc, attr, None)
        if isinstance(v, int):
            return v
    return 500


__all__ = ["wrap_elevenlabs_client"]
