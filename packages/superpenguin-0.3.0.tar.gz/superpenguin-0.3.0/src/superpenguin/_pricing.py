"""Built-in cost estimation for known LLM models.

Pricing data is loaded from the unified ``pricing/models.json`` source of
truth at the monorepo root (or its bundled copy ``superpenguin/data/models.json``
in installed wheels). See ``pricing/README.md`` for the schema reference and
runbooks for adding/changing pricing.

Costs are returned in USD micros (1 USD = 1,000,000 micros) for lossless
integer arithmetic.

Public surface preserved for back-compat with existing imports
(``calculate_cost_micros``, ``_normalize_model``, ``_MODEL_PRICING``,
``_MODEL_ALIASES``, ``_warned_unknown_models``).

New as of voice rollout:

* ``calculate_unit_cost_micros(model, units, *, as_of=None)`` — costs
  non-token billing units (``audio_seconds``, ``characters``, ``events``,
  ``flat_monthly``, ``audio_minutes``, ``images``, ``requests``, ``data_gb``). Used by the
  voice observability shim to cost STT audio-seconds, TTS characters, LiveKit
  observability events, and flat monthly subscriptions/rentals.
  Subscription quotas and overage thresholds are NOT applied here —
  per-call costing is unaware of monthly aggregation; the dashboard subtracts
  ``subscription_tiers[tier].included_units`` from the monthly sum before
  applying the per-unit rate.

``calculate_cost_micros`` itself is unchanged — it remains the token-only
path and is what every existing LLM wrapper call site uses today.
"""

from __future__ import annotations

import json
import logging
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

logger = logging.getLogger("superpenguin")

# Dedupe the warning so a hot loop on an unknown model doesn't spam logs.
# Process-local set; sufficient because the server-side
# /api/sdk/ingest route also pings Slack with its own dedupe layer
# (public.unknown_model_alerts) so the dashboard team gets the alert
# even if the SDK process is short-lived.
_warned_unknown_models: set[str] = set()


# ---------------------------------------------------------------------------
# Loader: bundled JSON in installed wheel, with editable-dev-install fallback
# ---------------------------------------------------------------------------


def _load_pricing_data() -> dict[str, Any]:
    """Load and return the parsed contents of pricing/models.json.

    Resolution order (walk-up FIRST, then bundled):
      1. Monorepo-root walk-up: look for ``pricing/models.json`` in any
         ancestor directory of this file. In editable installs (``pip install
         -e .`` from the monorepo) this hits the canonical source-of-truth on
         disk, so a developer's edits to ``pricing/models.json`` are picked up
         immediately on the next process start — no rebuild needed.
      2. Bundled wheel location: ``superpenguin/data/models.json`` accessed
         via ``importlib.resources``. This is what installed wheels use; the
         file is copied here at build time by hatch's ``force-include`` +
         ``hatch_build.py`` in ``pyproject.toml``. Walk-up will not find a
         monorepo root in a customer install, so resolution naturally falls
         through to this.
      3. Raise an informative error if neither is found.

    The walk-up-first ordering is intentional: it makes editable-install
    development always-fresh while still serving the bundled copy in
    customer-installed wheels (where no monorepo root exists to walk up to).
    """
    here = Path(__file__).resolve()
    for ancestor in here.parents:
        candidate = ancestor / "pricing" / "models.json"
        if candidate.is_file():
            return json.loads(candidate.read_text(encoding="utf-8"))

    try:
        from importlib.resources import files as _resource_files  # type: ignore[attr-defined]

        bundled = _resource_files("superpenguin").joinpath("data", "models.json")
        if bundled.is_file():
            return json.loads(bundled.read_text(encoding="utf-8"))
    except (FileNotFoundError, ModuleNotFoundError, AttributeError):
        # AttributeError covers older importlib.resources without files();
        # ModuleNotFoundError covers paths where the package layout is unusual.
        pass

    raise RuntimeError(
        "superpenguin: could not locate pricing data. Expected either "
        "'pricing/models.json' in a parent directory of "
        f"{__file__}, or 'superpenguin/data/models.json' bundled in the "
        "installed package. If you're running an editable install "
        "(pip install -e .) from the cost-management monorepo, ensure "
        "'pricing/models.json' exists at the repo root."
    )


_PRICING_DATA: dict[str, Any] = _load_pricing_data()

if _PRICING_DATA.get("$schema_version") != 1:
    raise RuntimeError(
        f"superpenguin: pricing/models.json schema version "
        f"{_PRICING_DATA.get('$schema_version')!r} is not supported by this "
        "SDK build (expected 1)."
    )


# ---------------------------------------------------------------------------
# Internal indexes
# ---------------------------------------------------------------------------


def _bare(canonical_key: str) -> str:
    """Return the bare model id (provider prefix stripped) for a canonical key."""
    return canonical_key.split("/", 1)[1] if "/" in canonical_key else canonical_key


# canonical key (e.g. "openai/gpt-4o") indexed by bare key (e.g. "gpt-4o").
# Built once at import. Fails fast on bare-key collisions.
_BARE_TO_CANONICAL: dict[str, str] = {}
for _ck in _PRICING_DATA.get("models", {}).keys():
    _b = _bare(_ck)
    if _b in _BARE_TO_CANONICAL and _BARE_TO_CANONICAL[_b] != _ck:
        raise RuntimeError(
            f"superpenguin: pricing bare-key collision — both "
            f"`{_BARE_TO_CANONICAL[_b]}` and `{_ck}` map to bare key `{_b}`. "
            "The legacy _MODEL_PRICING export requires bare-key uniqueness."
        )
    _BARE_TO_CANONICAL[_b] = _ck


# ---------------------------------------------------------------------------
# Legacy back-compat exports
# ---------------------------------------------------------------------------


def _build_legacy_model_pricing() -> dict[str, dict[str, Any]]:
    """Construct the bare-keyed _MODEL_PRICING view from the canonical JSON.

    Each value mirrors the pre-refactor shape: rate fields lifted from the
    model's CURRENT (latest) rate card, plus ``tier_threshold`` flattened
    from ``model.tier_threshold.value`` to a top-level int (the only
    consumer of legacy tier_threshold cared about the value, not the field).
    """
    out: dict[str, dict[str, Any]] = {}
    for canonical, entry in _PRICING_DATA.get("models", {}).items():
        cards = entry.get("rate_cards") or []
        if not cards:
            continue
        latest = cards[-1]
        rates = dict(latest.get("rates") or {})
        tier = entry.get("tier_threshold")
        if tier and tier.get("field") == "input_tokens":
            rates["tier_threshold"] = tier.get("value")
        out[_bare(canonical)] = rates
    return out


def _build_legacy_aliases() -> dict[str, str]:
    """Strip the provider prefix from alias values to preserve the bare→bare shape."""
    out: dict[str, str] = {}
    for short, target in (_PRICING_DATA.get("aliases") or {}).items():
        out[short] = _bare(target) if isinstance(target, str) else target
    return out


_MODEL_PRICING: dict[str, dict[str, Any]] = _build_legacy_model_pricing()
_MODEL_ALIASES: dict[str, str] = _build_legacy_aliases()


# ---------------------------------------------------------------------------
# Model normalization
# ---------------------------------------------------------------------------

# YYYY-MM-DD or YYYYMMDD trailing date (e.g. "-2025-09-15", "-20250915")
_DATE_SUFFIX = re.compile(r"-\d{4}-\d{2}-\d{2}$|-\d{8}$")
# Google-style trailing month-year (e.g. "-09-2025") used on Gemini preview SKUs
_MONTH_YEAR_SUFFIX = re.compile(r"-\d{2}-\d{4}$")
# Vertex AI version pin (e.g. "-001", "-002")
_VERSION_PIN_SUFFIX = re.compile(r"-\d{3}$")


def _normalize_model(raw: str) -> str:
    """Normalize a raw model name from any provider into a pricing-table key.

    Tries progressively more aggressive suffix-stripping, returning the first
    candidate that matches a known model. This avoids over-stripping cases
    like ``text-embedding-ada-002`` (where the ``-002`` suffix is part of the
    canonical model id, not a Vertex AI version pin).

    Examples::

        openai/gpt-4o                                  -> gpt-4o
        models/gemini-2.5-pro                          -> gemini-2.5-pro
        gemini-2.5-flash-lite-preview-09-2025          -> gemini-2.5-flash-lite-preview
        gemini-2.0-flash-001                           -> gemini-2.0-flash
        gpt-5-mini-2025-09-15                          -> gpt-5-mini
        text-embedding-ada-002                         -> text-embedding-ada-002 (preserved)
    """
    if "/" in raw:
        raw = raw.rsplit("/", 1)[-1]

    # Build the candidate chain from least-stripped to most-stripped. We
    # return the first candidate that resolves to a known model. If none
    # match, we still want a single deterministic answer for the
    # unknown-model warning, so fall through to the fully-stripped form.
    candidates: list[str] = [raw]
    s = _DATE_SUFFIX.sub("", raw)
    if s != candidates[-1]:
        candidates.append(s)
    s = _MONTH_YEAR_SUFFIX.sub("", s)
    if s != candidates[-1]:
        candidates.append(s)
    s = _VERSION_PIN_SUFFIX.sub("", s)
    if s != candidates[-1]:
        candidates.append(s)

    for cand in candidates:
        if cand in _BARE_TO_CANONICAL or cand in _MODEL_ALIASES:
            return _MODEL_ALIASES.get(cand, cand)

    # No candidate resolved — return the fully-stripped form so the caller's
    # unknown-model warning has a stable normalized name to dedupe on.
    return _MODEL_ALIASES.get(s, s)


# ---------------------------------------------------------------------------
# Rate-card resolution
# ---------------------------------------------------------------------------


def _parse_card_date(s: str) -> datetime:
    """Parse an effective_from / effective_until string as midnight-UTC datetime."""
    return datetime.strptime(s, "%Y-%m-%d").replace(tzinfo=timezone.utc)


def _resolve_rate_card(
    entry: dict[str, Any], as_of: datetime | None
) -> dict[str, Any]:
    """Return the rate card whose [effective_from, effective_until) window
    contains as_of. None / no-tz dates are treated as UTC. Falls back to
    the EARLIEST card for timestamps before its effective_from (extrapolating
    backward, with a debug log) and to the LATEST card when as_of is None.
    """
    cards = entry["rate_cards"]
    if as_of is None:
        return cards[-1]
    if as_of.tzinfo is None:
        as_of = as_of.replace(tzinfo=timezone.utc)
    for card in cards:
        from_dt = _parse_card_date(card["effective_from"])
        until_raw = card.get("effective_until")
        until_dt = _parse_card_date(until_raw) if until_raw else None
        if as_of >= from_dt and (until_dt is None or as_of < until_dt):
            return card
    earliest = cards[0]
    logger.debug(
        "superpenguin: extrapolating rate backward — as_of=%s predates earliest "
        "effective_from=%s for provider=%s",
        as_of.isoformat(),
        earliest["effective_from"],
        entry.get("provider"),
    )
    return earliest


def _pick(rate: Any, input_tokens: int, threshold: int | None) -> float:
    """Return the per-1M-token rate for the right tier (legacy helper).

    Kept for any external code that imported it. Internally,
    ``calculate_cost_micros`` now uses ``_pick_rate`` against the resolved
    rate card.
    """
    if isinstance(rate, list):
        if threshold is None or len(rate) < 2:
            return float(rate[0])
        return float(rate[1] if input_tokens > threshold else rate[0])
    return float(rate)


def _pick_rate(value: Any, tier_high: bool) -> float:
    if value is None:
        return 0.0
    if isinstance(value, list):
        return float(value[1] if tier_high else value[0])
    return float(value)


# ---------------------------------------------------------------------------
# Public cost calculator
# ---------------------------------------------------------------------------


def calculate_cost_micros(
    model: str,
    input_tokens: int,
    output_tokens: int,
    cached_tokens: int = 0,
    *,
    as_of: datetime | None = None,
) -> int:
    """Calculate request cost in USD micros (1 USD = 1,000,000 micros).

    Returns 0 if the model is unknown (pings the dedup'd warning logger so
    the gap is visible in customer logs).

    The optional keyword-only ``as_of`` parameter selects the rate card that
    was in effect at that timestamp; omit it to use the current (latest)
    card — appropriate when the caller is computing cost at request time.
    """
    normalized = _normalize_model(model)
    canonical = _BARE_TO_CANONICAL.get(normalized)
    if canonical is None:
        if normalized not in _warned_unknown_models:
            _warned_unknown_models.add(normalized)
            logger.warning(
                "superpenguin: no pricing entry for model %r (normalized %r); "
                "cost will be reported as 0. Add an entry to pricing/models.json "
                "in the cost-management monorepo and ship a new SDK release.",
                model,
                normalized,
            )
        return 0

    entry = _PRICING_DATA["models"][canonical]
    card = _resolve_rate_card(entry, as_of)
    rates = card.get("rates") or {}

    tier = entry.get("tier_threshold")
    tier_high = False
    if tier and tier.get("field") == "input_tokens":
        # Use total input (uncached + cached) for the tier check — matches
        # how Google evaluates the 200K threshold.
        tier_high = input_tokens > int(tier.get("value", 0))

    # Rate-leg resolution: explicit `null` and missing keys both resolve to 0.
    # The previous heuristic (input_rate * 0.5 when cache_read was missing)
    # was wrong for several OpenAI models — gpt-4.1's actual cached-input rate
    # is $0.50/1M but the heuristic returned $1.00/1M. The unified pricing
    # source now records explicit rates for every leg a model supports, and
    # `null` for models that don't (notably the OpenAI Pro family which does
    # not offer prompt caching). _pick_rate returns 0.0 for both.
    input_rate = _pick_rate(rates.get("input"), tier_high)
    output_rate = _pick_rate(rates.get("output"), tier_high)
    cache_rate = _pick_rate(rates.get("cache_read"), tier_high)

    uncached_input = max(0, input_tokens - cached_tokens)
    input_cost = (uncached_input / 1_000_000) * input_rate
    output_cost = (output_tokens / 1_000_000) * output_rate
    cache_cost = (cached_tokens / 1_000_000) * cache_rate

    return round((input_cost + output_cost + cache_cost) * 1_000_000)


# ---------------------------------------------------------------------------
# Non-token cost calculator (voice / events / flat-monthly)
# ---------------------------------------------------------------------------

# Maps each non-token billing_unit to the single rate-leg name the validator
# enforces for that unit. Mirrors NON_TOKEN_RATE_LEG_BY_UNIT in
# scripts/check_pricing_schema.py — keep these in sync.
_NON_TOKEN_RATE_LEG_BY_UNIT: dict[str, str] = {
    "characters": "per_character",
    "audio_seconds": "per_second",
    "audio_minutes": "per_minute",
    "events": "per_event",
    "flat_monthly": "per_month",
    "images": "per_image",
    "requests": "per_request",
    "data_gb": "per_gb",
}


def calculate_unit_cost_micros(
    model: str,
    units: float,
    *,
    as_of: datetime | None = None,
    variant: str | None = None,
) -> int:
    """Calculate non-token request cost in USD micros.

    Args:
        model: Canonical or bare model id (e.g. ``"deepgram/nova-3-monolingual"``,
            ``"elevenlabs/eleven_flash_v2_5"``, ``"livekit/agent-session-minute"``).
        units: How many of the model's billing units this call consumed.
            For ``audio_seconds`` models this is seconds (NOT minutes — pre-divide
            if the metrics API gives you minutes). For ``characters`` it's chars.
            For ``events`` it's the event count. For ``flat_monthly`` it's the
            number of months billed (typically 1).
        as_of: Optional timestamp; selects the rate card in effect at that time.
            Defaults to "now" → latest card.
        variant: Optional rate variant name. When set AND the resolved rate
            card has a ``rate_variants[variant][leg]``, that rate is used
            instead of the default ``rates[leg]``. Used today for LiveKit's
            Scale-tier discounted overage rates (``variant="scale"``); other
            variant names (or models without a matching variant) silently
            fall through to the default rate so passing an unrecognized
            tier name is a safe no-op.

    Returns:
        Cost in USD micros, rounded to the nearest micro. Returns 0 (with a
        deduplicated warning log) when the model is unknown OR when the
        model's ``billing_unit`` is ``"tokens"`` (callers should use
        :func:`calculate_cost_micros` for token models).

    Subscription quotas (``subscription_tiers[tier].included_units``) are NOT
    applied here — per-call costing is unaware of monthly aggregation. The
    dashboard subtracts the tier's included units from the monthly sum and
    applies the per-unit rate to overage only.
    """
    normalized = _normalize_model(model)
    canonical = _BARE_TO_CANONICAL.get(normalized)
    if canonical is None:
        if normalized not in _warned_unknown_models:
            _warned_unknown_models.add(normalized)
            logger.warning(
                "superpenguin: no pricing entry for model %r (normalized %r); "
                "unit cost will be reported as 0. Add an entry to "
                "pricing/models.json in the cost-management monorepo and ship "
                "a new SDK release.",
                model,
                normalized,
            )
        return 0

    entry = _PRICING_DATA["models"][canonical]
    billing_unit = entry.get("billing_unit")
    if billing_unit == "tokens":
        logger.warning(
            "superpenguin: calculate_unit_cost_micros called for token-billing "
            "model %r; use calculate_cost_micros() instead. Returning 0.",
            canonical,
        )
        return 0

    leg_name = _NON_TOKEN_RATE_LEG_BY_UNIT.get(billing_unit or "")
    if leg_name is None:
        logger.warning(
            "superpenguin: model %r has unsupported billing_unit %r; returning 0.",
            canonical,
            billing_unit,
        )
        return 0

    card = _resolve_rate_card(entry, as_of)
    rate: Any = None
    if variant:
        variants = card.get("rate_variants") or {}
        variant_rates = variants.get(variant) or {}
        rate = variant_rates.get(leg_name)
    if rate is None:
        rates = card.get("rates") or {}
        rate = rates.get(leg_name)
    if rate is None:
        return 0

    # rate_basis on non-token entries today is always per_unit (validator allows
    # per_million too, but we never seed that for voice — guard anyway so a
    # future per_million entry doesn't silently inflate by 1e6).
    rate_basis = entry.get("rate_basis", "per_unit")
    rate_value = float(rate)
    if rate_basis == "per_million":
        cost_usd = (units / 1_000_000.0) * rate_value
    else:
        cost_usd = units * rate_value
    return round(cost_usd * 1_000_000)
