"""Standalone Deepgram client wrapper for ``sp.wrap()``.

Why this exists separately from the LiveKit observability shim
--------------------------------------------------------------
Most Deepgram users do NOT run inside a LiveKit Agents session — they call
``DeepgramClient(...).listen.rest.v("1").transcribe_url(...)`` (or its
``.transcribe_file`` / async variants) directly from a backend service.
The LiveKit shim only fires when LiveKit's own ``MetricsCollectedEvent``
stream emits an ``STTMetrics``, which never happens for these standalone
callers. This module is the equivalent on-call hook for them.

Scope (v1 — what we wrap today)
-------------------------------
* ``client.listen.rest.v(...).transcribe_url`` (sync + async)
* ``client.listen.rest.v(...).transcribe_file`` (sync + async)

Each wrapped call submits one ``request_logs`` row with:

  * ``provider="deepgram"``, ``modality="audio_in"``
  * ``audio_seconds`` from ``response.metadata.duration``
  * ``model`` canonicalized to ``deepgram/nova-3-monolingual`` or
    ``deepgram/nova-3-multilingual`` based on ``response.metadata.models``
    (or the PrerecordedOptions ``model=`` hint, if the response's
    model_info is missing)
  * ``cost_usd_micros`` computed from the bundled pricing table

Scope (v1 — what we explicitly do NOT wrap)
-------------------------------------------
* Live WebSocket STT (``client.listen.live.v(...)``) — the callback-based
  pattern is meaningfully more complex; rare for non-LiveKit users.
* Callback-mode async transcribe (``callback=`` URL parameter) — the
  immediate response is a request-id, and the actual transcript+duration
  arrive at the user's webhook later. Tracking those would require a
  user-side webhook helper that's out of scope for v1.
* Deepgram TTS (``client.speak.rest.v(...)``) — not yet seeded in
  ``pricing/models.json``.
* Deepgram Voice Agent API (``client.agent.v(...)``) — not yet seeded.

Per-call metadata override
--------------------------
Deepgram's request models don't expose an ``extra_body``-style passthrough,
so per-call ``customer_id`` / ``feature`` / etc. overrides are NOT
supported in v1. Pass defaults via ``sp.wrap(..., metadata={...})``. A
``sp.context()`` context manager covering all wrappers is planned but
deliberately deferred to its own change set.

Anti-double-counting note
-------------------------
If you also use ``LiveKitObservability``, do NOT additionally wrap the
Deepgram client used inside the LiveKit Agents plugin — both paths would
emit a row for the same audio and double the cost. In practice LiveKit
Agents constructs its own internal Deepgram client that the user doesn't
hold a reference to, so natural separation is the norm.
"""

from __future__ import annotations

import functools
import logging
import time
from typing import Any

from superpenguin._voice_submit import submit_voice_event

logger = logging.getLogger("superpenguin.deepgram")


_PROVIDER = "deepgram"
_MODALITY = "audio_in"
# Used when neither the response nor the call options yield a usable
# model name. Aligns with the most common Deepgram default circa 2026.
_DEFAULT_MODEL = "nova-3"


# Methods on the versioned-listen client we patch. Each entry:
#   (method_name, is_stream)
# is_stream is False today because both REST methods return a fully
# materialized response object. Reserved for future streaming methods.
_LISTEN_REST_METHODS: tuple[tuple[str, bool], ...] = (
    ("transcribe_url", False),
    ("transcribe_file", False),
)


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------


def wrap_deepgram_client(
    client: Any,
    *,
    name: str | None = None,
    metadata: dict[str, Any] | None = None,
    tags: list[str] | None = None,
    tier: str | None = None,
) -> Any:
    """Patch a ``DeepgramClient`` in-place so its REST transcribe calls
    auto-submit a ``request_logs`` row each.

    The original ``client`` is mutated and returned (matching the
    behavior of the LLM wrapper). This works because the Deepgram SDK
    builds versioned-rest objects lazily through ``listen.rest.v(version)``;
    we intercept that ``v()`` call and patch the returned object's
    ``transcribe_*`` methods on each invocation.

    SKU routing
    -----------
    Both methods we wrap (``transcribe_url`` / ``transcribe_file``) hit
    Deepgram's HTTP REST endpoint, which bills against the **pre-recorded**
    SKU — ~44% cheaper than the streaming WebSocket SKU. This wrapper
    emits rows against ``deepgram/<model>-{mono|multi}lingual-prerecorded``
    accordingly. (The LiveKit-Agents shim uses streaming and emits against
    the un-suffixed streaming SKU; that path is unaffected by this wrapper.)

    Args:
        client: A ``deepgram.DeepgramClient`` (or async equivalent)
            instance. Other Deepgram SDK class names are silently skipped
            so a future SDK refactor doesn't crash existing user code.
        name: Reserved for parity with the LLM wrapper; not currently
            promoted onto emitted rows.
        metadata: Default attribution applied to every emitted row.
            Keys ``customer_id``, ``feature``, ``team``, ``environment``,
            ``prompt_key``, ``prompt_version`` route to first-class
            ``request_logs`` columns; other string values land in
            ``custom_tags``.
        tags: Reserved for parity; not currently promoted.
        tier: Deepgram commitment tier — ``"growth"`` for customers on
            the Growth plan ($4K+/yr commitment, ~16% discount across
            all SKUs), or omit / ``None`` for pay-as-you-go (the default).
            When ``"growth"``, the canonical SKU gets a ``-growth``
            suffix so the dashboard prices against the discounted rate
            card. The dashboard's connection-level tier (auto-detected
            from your Deepgram balances) handles per-row reconciliation
            in the daily sync, but for live SDK rows it's worth setting
            this when you know the answer up-front.

    Returns:
        The same ``client`` instance, mutated in place.
    """
    extra: dict[str, Any] = {}
    if name:
        extra["name"] = name
    if metadata:
        extra["metadata"] = metadata
    if tags:
        extra["tags"] = tags
    # Routing flags consumed by the canonicalize step. Living in `extra`
    # rather than as track_* parameters keeps the per-call signature
    # narrow and makes them trivially settable from the wrap() entry.
    extra["_deepgram_prerecorded"] = True
    if tier is not None:
        extra["_deepgram_tier"] = tier

    _wrap_listen_rest_tree(client, "rest", is_async=False, extra=extra)
    _wrap_listen_rest_tree(client, "asyncrest", is_async=True, extra=extra)

    return client


# ---------------------------------------------------------------------------
# Patching helpers
# ---------------------------------------------------------------------------


def _wrap_listen_rest_tree(
    client: Any,
    rest_attr: str,
    *,
    is_async: bool,
    extra: dict[str, Any],
) -> None:
    """Patch the ``v()`` method on ``client.listen.<rest_attr>`` so every
    versioned-client it returns has its transcribe methods tracked.

    The Deepgram SDK exposes ``client.listen.rest.v("1")`` as a factory
    that returns a fresh object every call (or memoized — both work for
    our purposes; we re-patch each returned instance defensively). We
    don't patch the un-versioned root because there's no method to call
    on it; the only way users invoke transcribe is via ``v(version)``.
    """
    listen = getattr(client, "listen", None)
    if listen is None:
        return
    rest = getattr(listen, rest_attr, None)
    if rest is None:
        return
    original_v = getattr(rest, "v", None)
    if original_v is None or not callable(original_v):
        return

    @functools.wraps(original_v)
    def patched_v(version: Any) -> Any:
        versioned = original_v(version)
        if versioned is None:
            return versioned
        for method_name, is_stream in _LISTEN_REST_METHODS:
            _patch_versioned_method(
                versioned, method_name,
                is_async=is_async, is_stream=is_stream, extra=extra,
            )
        return versioned

    try:
        setattr(rest, "v", patched_v)
    except (AttributeError, TypeError):
        # Some Deepgram SDK versions expose `rest` as a slot-typed object;
        # if we can't reassign `.v`, log once and bail rather than
        # crashing the user's import.
        logger.debug(
            "superpenguin: could not patch DeepgramClient.listen.%s.v",
            rest_attr,
        )


def _patch_versioned_method(
    versioned_client: Any,
    method_name: str,
    *,
    is_async: bool,
    is_stream: bool,
    extra: dict[str, Any],
) -> None:
    """Patch one transcribe_* method on a versioned-listen client."""
    original = getattr(versioned_client, method_name, None)
    if original is None:
        return
    # Idempotency guard: if we've already patched this method on this
    # versioned instance (e.g. user called sp.wrap() twice), skip.
    if getattr(original, "__sp_wrapped__", False):
        return

    if is_async:

        @functools.wraps(original)
        async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
            return await _track_async(
                original, method_name, extra, args, kwargs,
                is_stream=is_stream,
            )

        async_wrapper.__sp_wrapped__ = True  # type: ignore[attr-defined]
        wrapped: Any = async_wrapper
    else:

        @functools.wraps(original)
        def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
            return _track_sync(
                original, method_name, extra, args, kwargs,
                is_stream=is_stream,
            )

        sync_wrapper.__sp_wrapped__ = True  # type: ignore[attr-defined]
        wrapped = sync_wrapper

    try:
        setattr(versioned_client, method_name, wrapped)
    except (AttributeError, TypeError):
        logger.debug("superpenguin: could not patch Deepgram .%s", method_name)


# ---------------------------------------------------------------------------
# Tracking
# ---------------------------------------------------------------------------


def _track_sync(
    fn: Any,
    method_name: str,
    extra: dict[str, Any],
    args: tuple[Any, ...],
    kwargs: dict[str, Any],
    *,
    is_stream: bool,
) -> Any:
    started = time.time()
    options = _find_options_arg(args, kwargs)
    model_hint = _model_from_options(options)

    try:
        result = fn(*args, **kwargs)
    except Exception as exc:
        _submit_error(extra, model_hint, exc, started)
        raise

    _submit_success(extra, result, model_hint, started, is_stream)
    return result


async def _track_async(
    fn: Any,
    method_name: str,
    extra: dict[str, Any],
    args: tuple[Any, ...],
    kwargs: dict[str, Any],
    *,
    is_stream: bool,
) -> Any:
    started = time.time()
    options = _find_options_arg(args, kwargs)
    model_hint = _model_from_options(options)

    try:
        result = await fn(*args, **kwargs)
    except Exception as exc:
        _submit_error(extra, model_hint, exc, started)
        raise

    _submit_success(extra, result, model_hint, started, is_stream)
    return result


def _submit_success(
    extra: dict[str, Any],
    response: Any,
    model_hint: str | None,
    started: float,
    is_stream: bool,
) -> None:
    audio_seconds = _extract_audio_seconds(response)
    raw_model = _extract_response_model(response) or model_hint or _DEFAULT_MODEL
    is_multilingual = _extract_is_multilingual(response)
    canonical = _canonicalize_deepgram_model(
        raw_model,
        is_multilingual=is_multilingual,
        prerecorded=bool(extra.get("_deepgram_prerecorded")),
        tier=extra.get("_deepgram_tier"),
    )
    submit_voice_event(
        provider=_PROVIDER,
        model=canonical,
        modality=_MODALITY,
        extra=extra,
        started_at=started,
        ended_at=time.time(),
        audio_seconds=audio_seconds,
        status_code=200,
        streaming=is_stream,
    )


def _submit_error(
    extra: dict[str, Any],
    model_hint: str | None,
    exc: Exception,
    started: float,
) -> None:
    """Submit a zero-cost row on Deepgram exceptions so the dashboard
    still shows the failed request count + latency. We don't know the
    audio_seconds on failure (no response object), so cost is 0."""
    status_code = _coerce_status_code(exc)
    raw_model = model_hint or _DEFAULT_MODEL
    canonical = _canonicalize_deepgram_model(
        raw_model,
        is_multilingual=False,
        prerecorded=bool(extra.get("_deepgram_prerecorded")),
        tier=extra.get("_deepgram_tier"),
    )
    submit_voice_event(
        provider=_PROVIDER,
        model=canonical,
        modality=_MODALITY,
        extra=extra,
        started_at=started,
        ended_at=time.time(),
        audio_seconds=0.0,
        status_code=status_code,
        streaming=False,
    )


# ---------------------------------------------------------------------------
# Response / option parsing
# ---------------------------------------------------------------------------


def _find_options_arg(
    args: tuple[Any, ...], kwargs: dict[str, Any],
) -> Any | None:
    """Locate the PrerecordedOptions argument across SDK versions.

    Deepgram's signatures for ``transcribe_url(source, options=None, ...)``
    and ``transcribe_file(source, options=None, ...)`` have varied across
    SDK majors (kwarg-only vs positional). This probes both call styles.
    """
    if "options" in kwargs:
        return kwargs["options"]
    # Positional shape: source is args[0], options is args[1] (when present).
    if len(args) >= 2:
        return args[1]
    return None


def _model_from_options(options: Any) -> str | None:
    """Pull the ``model`` field off PrerecordedOptions, regardless of
    whether it's the dataclass-style SDK or the dict-style legacy SDK."""
    if options is None:
        return None
    # PrerecordedOptions in v3+ is a dataclass-like with `.model`
    model = getattr(options, "model", None)
    if isinstance(model, str) and model:
        return model
    # Legacy dict-shaped options
    if isinstance(options, dict):
        m = options.get("model")
        if isinstance(m, str) and m:
            return m
    return None


def _extract_audio_seconds(response: Any) -> float:
    """Pull billable audio duration off the Deepgram response.

    Deepgram nests it as ``response.metadata.duration``. The metadata
    object is a dataclass on v3+ SDKs and a plain dict on legacy. Returns
    0.0 if missing — caller will submit a zero-cost row in that case
    (which is correct: nothing was billed).
    """
    metadata = _attr_or_key(response, "metadata")
    if metadata is None:
        return 0.0
    duration = _attr_or_key(metadata, "duration")
    try:
        return float(duration) if duration is not None else 0.0
    except (TypeError, ValueError):
        return 0.0


def _extract_response_model(response: Any) -> str | None:
    """Best-effort extraction of the actual model Deepgram routed to.

    The response's ``metadata.models`` is a list of model UUIDs (not
    helpful for canonicalization), but ``metadata.model_info`` is a
    dict keyed by those UUIDs whose values carry ``name`` / ``version``
    / ``language``. We pull the first entry's ``name`` since Deepgram
    only routes to one model per request today.
    """
    metadata = _attr_or_key(response, "metadata")
    if metadata is None:
        return None
    model_info = _attr_or_key(metadata, "model_info")
    if model_info is None:
        return None
    # model_info on v3+ is a dict keyed by UUID; on legacy SDKs it can be
    # a list of dicts. Handle both.
    candidate: Any = None
    if isinstance(model_info, dict) and model_info:
        candidate = next(iter(model_info.values()))
    elif isinstance(model_info, list) and model_info:
        candidate = model_info[0]
    if candidate is None:
        return None
    name = _attr_or_key(candidate, "name")
    return name if isinstance(name, str) and name else None


def _extract_is_multilingual(response: Any) -> bool:
    """Decide whether to bill against the multilingual SKU.

    Deepgram doesn't expose a single "multilingual" boolean; we infer
    from ``model_info[*].arch`` or fall back to checking whether the
    model's ``language`` field is ``"multi"``. Older SDKs (before
    multilingual was a thing) always return False — that's fine, those
    requests genuinely WERE monolingual.
    """
    metadata = _attr_or_key(response, "metadata")
    if metadata is None:
        return False
    model_info = _attr_or_key(metadata, "model_info")
    candidate: Any = None
    if isinstance(model_info, dict) and model_info:
        candidate = next(iter(model_info.values()))
    elif isinstance(model_info, list) and model_info:
        candidate = model_info[0]
    if candidate is None:
        return False
    # Direct boolean field if the SDK exposes it
    flag = _attr_or_key(candidate, "multilingual")
    if isinstance(flag, bool):
        return flag
    # arch="multi" on Nova-3 multilingual builds
    arch = _attr_or_key(candidate, "arch")
    if isinstance(arch, str) and arch.lower() == "multi":
        return True
    # language="multi" fallback
    lang = _attr_or_key(candidate, "language")
    if isinstance(lang, str) and lang.lower() == "multi":
        return True
    return False


def _canonicalize_deepgram_model(
    raw_model: str,
    *,
    is_multilingual: bool,
    prerecorded: bool = False,
    tier: str | None = None,
) -> str:
    """Normalize a Deepgram model name into the canonical pricing slug.

    The pricing table carries 4 dimensions for each Nova model:
      * mono- vs multi-lingual (engine variant)
      * streaming vs pre-recorded (API endpoint)
      * payg vs growth (commitment tier)

    All combinations are individual entries (e.g.
    ``deepgram/nova-3-monolingual-prerecorded-growth``). This function
    composes the right slug from the four signals.

    Args:
        raw_model: The model string as it appears on the response or in
            the call options. May be empty/None — caller substitutes
            ``_DEFAULT_MODEL`` ("nova-3") in that case.
        is_multilingual: Whether the response indicates a multilingual
            engine. Only consulted for Nova-3 / Nova-2 stems where the
            multilingual/monolingual split exists.
        prerecorded: True for HTTP REST (``transcribe_url`` /
            ``transcribe_file``); False for streaming WebSocket. Drives
            the ``-prerecorded`` suffix.
        tier: ``"growth"`` for Growth-plan customers (~16% discount);
            anything else (including ``None``) → PAYG (the default).
    """
    raw = (raw_model or "").strip().lower()
    if not raw:
        raw = _DEFAULT_MODEL

    # User already wrote it in canonical form — trust it verbatim
    # (escape hatch for SKUs we haven't covered yet).
    if raw.startswith("deepgram/"):
        return raw

    # Strip any internal "-general" / "-en" / "-multi" suffix that
    # Deepgram sometimes embeds in the routed model name.
    stem = raw
    for trailer in ("-general-en", "-general-multi", "-general", "-en", "-multi"):
        if stem.endswith(trailer):
            stem = stem[: -len(trailer)]
            break

    # Determine the base SKU stem with engine-variant suffix.
    if stem in ("nova-3", "nova-2"):
        engine_suffix = "-multilingual" if is_multilingual else "-monolingual"
        base = f"{stem}{engine_suffix}"
    elif stem.endswith("-monolingual") or stem.endswith("-multilingual"):
        # User explicitly named the engine variant — honor it.
        base = stem
    else:
        # Unrecognized model. Don't fabricate a mono/multi suffix; let
        # the unknown-model alert pipeline flag it and we add an entry
        # next release. Drop tier/prerecorded modifiers because they're
        # only valid against known SKU families.
        return f"deepgram/{stem}"

    # Apply the API-endpoint axis. Pre-recorded SKUs are materially
    # cheaper than streaming on every Deepgram model — see the
    # `$deepgram_billing_axes` note in pricing/models.json.
    if prerecorded:
        base = f"{base}-prerecorded"

    # Apply the commitment-tier axis.
    if tier == "growth":
        base = f"{base}-growth"

    return f"deepgram/{base}"


# ---------------------------------------------------------------------------
# Misc helpers
# ---------------------------------------------------------------------------


def _attr_or_key(obj: Any, name: str) -> Any:
    """Return ``obj.<name>`` or ``obj[name]`` depending on shape.

    Deepgram's response objects bounce between dataclass-style and
    dict-style across SDK majors and even within a single major (parsed
    JSON vs typed model). This helper normalizes both.
    """
    if obj is None:
        return None
    if isinstance(obj, dict):
        return obj.get(name)
    return getattr(obj, name, None)


def _coerce_status_code(exc: Exception) -> int:
    """Best-effort HTTP status pull off a Deepgram exception."""
    for attr in ("status_code", "status", "code"):
        v = getattr(exc, attr, None)
        if isinstance(v, int):
            return v
    return 500


__all__ = ["wrap_deepgram_client"]
