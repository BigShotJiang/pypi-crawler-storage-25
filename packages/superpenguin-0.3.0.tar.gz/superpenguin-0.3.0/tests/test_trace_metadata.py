"""Tests for @sp.trace metadata propagation.

Verifies the precedence layers documented on /docs:

    wrap-time defaults  <  @sp.trace metadata  <  per-call override

And confirms the contextvar is reset on function exit so leaks don't
contaminate subsequent calls.
"""

from __future__ import annotations

import asyncio
from typing import Any

import pytest

import superpenguin
from superpenguin._context import (
    current_trace_metadata,
    merged_metadata,
)


# ---------------------------------------------------------------------------
# Capturing client (mirrors test_wrap_deepgram fixture)
# ---------------------------------------------------------------------------


class _CapturingClient:
    def __init__(self) -> None:
        self.events: list[dict[str, Any]] = []

    def submit(self, event: dict[str, Any]) -> None:
        self.events.append(event)


@pytest.fixture(autouse=True)
def _swap_client(monkeypatch: pytest.MonkeyPatch) -> _CapturingClient:
    fake = _CapturingClient()
    monkeypatch.setattr(superpenguin, "_client", fake)
    return fake


# ---------------------------------------------------------------------------
# Unit: merged_metadata precedence
# ---------------------------------------------------------------------------


def test_merged_metadata_call_overrides_trace_overrides_wrap() -> None:
    token = current_trace_metadata.set(
        {"customer_id": "cust_trace", "feature": "trace_feature"}
    )
    try:
        result = merged_metadata(
            {"customer_id": "cust_wrap", "team": "platform"},
            {"customer_id": "cust_call"},
        )
    finally:
        current_trace_metadata.reset(token)

    # call > trace > wrap
    assert result["customer_id"] == "cust_call"
    # trace contributes feature
    assert result["feature"] == "trace_feature"
    # wrap-only field survives
    assert result["team"] == "platform"


def test_merged_metadata_with_no_trace_active() -> None:
    result = merged_metadata({"team": "platform"}, {"customer_id": "cust_call"})
    assert result == {"team": "platform", "customer_id": "cust_call"}


def test_merged_metadata_handles_none_inputs() -> None:
    assert merged_metadata(None, None) == {}
    assert merged_metadata(None, {"customer_id": "x"}) == {"customer_id": "x"}
    assert merged_metadata({"team": "p"}, None) == {"team": "p"}


# ---------------------------------------------------------------------------
# @sp.trace sets and clears the contextvar
# ---------------------------------------------------------------------------


def test_sync_trace_pushes_metadata_then_clears() -> None:
    captured: dict[str, Any] = {}

    @superpenguin.trace(metadata={"customer_id": "cust_acme", "feature": "qa"})
    def inner() -> None:
        captured.update(current_trace_metadata.get() or {})

    assert current_trace_metadata.get() is None
    inner()
    assert captured == {"customer_id": "cust_acme", "feature": "qa"}
    # Cleared after exit so the next caller starts fresh.
    assert current_trace_metadata.get() is None


def test_sync_trace_without_metadata_does_not_set_contextvar() -> None:
    captured: list[Any] = []

    @superpenguin.trace
    def inner() -> None:
        captured.append(current_trace_metadata.get())

    inner()
    assert captured == [None]


def test_async_trace_pushes_metadata_then_clears() -> None:
    captured: dict[str, Any] = {}

    @superpenguin.trace(metadata={"customer_id": "cust_async", "team": "voice"})
    async def inner() -> None:
        captured.update(current_trace_metadata.get() or {})

    assert current_trace_metadata.get() is None
    asyncio.run(inner())
    assert captured == {"customer_id": "cust_async", "team": "voice"}
    assert current_trace_metadata.get() is None


def test_trace_metadata_resets_even_on_exception() -> None:
    @superpenguin.trace(metadata={"customer_id": "cust_boom"})
    def inner() -> None:
        raise RuntimeError("kaboom")

    with pytest.raises(RuntimeError):
        inner()

    assert current_trace_metadata.get() is None


def test_nested_traces_layer_then_unwind() -> None:
    snapshots: list[dict[str, Any] | None] = []

    @superpenguin.trace(metadata={"customer_id": "outer", "team": "platform"})
    def outer() -> None:
        snapshots.append(dict(current_trace_metadata.get() or {}))
        inner()
        snapshots.append(dict(current_trace_metadata.get() or {}))

    @superpenguin.trace(metadata={"customer_id": "inner", "feature": "qa"})
    def inner() -> None:
        snapshots.append(dict(current_trace_metadata.get() or {}))

    outer()
    assert snapshots[0] == {"customer_id": "outer", "team": "platform"}
    # Inner replaces outer entirely (no implicit deep merge); per-row merge
    # still picks up wrap defaults beneath.
    assert snapshots[1] == {"customer_id": "inner", "feature": "qa"}
    # After inner returns, outer's metadata is restored.
    assert snapshots[2] == {"customer_id": "outer", "team": "platform"}
    assert current_trace_metadata.get() is None


# ---------------------------------------------------------------------------
# Integration: trace metadata reaches a Deepgram row
# ---------------------------------------------------------------------------


from types import SimpleNamespace


class _FakeVersionedRest:
    def transcribe_url(self, *args: Any, **kwargs: Any) -> Any:
        return _build_response()


class _FakeRest:
    def __init__(self) -> None:
        self._versioned = _FakeVersionedRest()

    def v(self, version: str) -> Any:
        return self._versioned


class _FakeListen:
    def __init__(self) -> None:
        self.rest = _FakeRest()


class _FakeDeepgramClient:
    def __init__(self) -> None:
        self.listen = _FakeListen()


for cls in (
    _FakeDeepgramClient, _FakeListen, _FakeRest, _FakeVersionedRest,
):
    cls.__module__ = "deepgram.fake"


def _build_response() -> SimpleNamespace:
    model_info = {
        "uuid-1": SimpleNamespace(
            name="nova-3", arch="general", multilingual=False,
        ),
    }
    return SimpleNamespace(
        metadata=SimpleNamespace(duration=10.0, model_info=model_info),
    )


def test_trace_metadata_lands_on_deepgram_row(
    _swap_client: _CapturingClient,
) -> None:
    dg = superpenguin.wrap(
        _FakeDeepgramClient(),
        metadata={"team": "voice-platform", "environment": "production"},
    )

    @superpenguin.trace(
        metadata={"customer_id": "cust_acme_123", "feature": "podcasts"}
    )
    def transcribe_one() -> None:
        dg.listen.rest.v("1").transcribe_url({"url": "https://x/y.mp3"})

    transcribe_one()

    assert len(_swap_client.events) == 1
    event = _swap_client.events[0]
    # From wrap defaults
    assert event["team"] == "voice-platform"
    assert event["environment"] == "production"
    # From @sp.trace, even though Deepgram SDK has no extra_body hook
    assert event["customer_id"] == "cust_acme_123"
    assert event["feature"] == "podcasts"


def test_call_meta_overrides_trace_metadata_on_llm_path() -> None:
    """Direct unit test of the merge precedence used by _wrap._submit."""
    token = current_trace_metadata.set({"customer_id": "from_trace"})
    try:
        merged = merged_metadata(
            {"customer_id": "from_wrap"},
            {"customer_id": "from_extra_body"},
        )
    finally:
        current_trace_metadata.reset(token)
    assert merged["customer_id"] == "from_extra_body"


# ---------------------------------------------------------------------------
# sp.metadata() context manager
# ---------------------------------------------------------------------------


def test_sp_metadata_context_manager_sets_and_clears() -> None:
    assert current_trace_metadata.get() is None
    with superpenguin.metadata({"customer_id": "cust_ctx"}):
        snapshot = dict(current_trace_metadata.get() or {})
    assert snapshot == {"customer_id": "cust_ctx"}
    assert current_trace_metadata.get() is None


def test_sp_metadata_layers_on_top_of_trace() -> None:
    seen: list[dict[str, Any]] = []

    @superpenguin.trace(metadata={"feature": "doc_summary", "team": "core"})
    def run(customer_id: str) -> None:
        with superpenguin.metadata({"customer_id": customer_id}):
            seen.append(dict(current_trace_metadata.get() or {}))

    run("cust_a")
    run("cust_b")

    assert seen[0] == {"feature": "doc_summary", "team": "core", "customer_id": "cust_a"}
    assert seen[1] == {"feature": "doc_summary", "team": "core", "customer_id": "cust_b"}
    # Nothing leaks out.
    assert current_trace_metadata.get() is None


def test_sp_metadata_resets_on_exception() -> None:
    with pytest.raises(RuntimeError):
        with superpenguin.metadata({"customer_id": "cust_boom"}):
            raise RuntimeError("kaboom")
    assert current_trace_metadata.get() is None


def test_sp_metadata_reaches_deepgram_row(
    _swap_client: _CapturingClient,
) -> None:
    dg = superpenguin.wrap(
        _FakeDeepgramClient(),
        metadata={"team": "voice-platform"},
    )

    def transcribe_for(customer_id: str) -> None:
        with superpenguin.metadata({"customer_id": customer_id}):
            dg.listen.rest.v("1").transcribe_url({"url": "https://x/y.mp3"})

    transcribe_for("cust_a")
    transcribe_for("cust_b")

    assert len(_swap_client.events) == 2
    assert _swap_client.events[0]["customer_id"] == "cust_a"
    assert _swap_client.events[1]["customer_id"] == "cust_b"
    # Wrap defaults still present on every row.
    assert _swap_client.events[0]["team"] == "voice-platform"
    assert _swap_client.events[1]["team"] == "voice-platform"


def test_sp_metadata_rejects_non_dict() -> None:
    with pytest.raises(TypeError):
        with superpenguin.metadata("not a dict"):  # type: ignore[arg-type]
            pass
