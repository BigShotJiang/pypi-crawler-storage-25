"""Unit tests for the pricing table, model normalization, and cost math."""

from __future__ import annotations

from datetime import datetime, timezone

import pytest

from superpenguin._pricing import (
    _MODEL_ALIASES,
    _MODEL_PRICING,
    _PRICING_DATA,
    _normalize_model,
    calculate_cost_micros,
    calculate_unit_cost_micros,
)


# ---------------------------------------------------------------------------
# _normalize_model
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "raw, expected",
    [
        ("gpt-4o", "gpt-4o"),
        ("openai/gpt-4o", "gpt-4o"),
        ("openai/gpt-5-mini-2025-09-15", "gpt-5-mini"),
        ("models/gemini-2.5-pro", "gemini-2.5-pro"),
        ("gemini-2.5-flash-lite-preview-09-2025", "gemini-2.5-flash-lite-preview"),
        ("gemini-2.0-flash-001", "gemini-2.0-flash"),
        ("gemini-3.1-pro", "gemini-3.1-pro-preview"),
        ("gemini-3.1-pro-preview", "gemini-3.1-pro-preview"),
        ("gemini-3-flash", "gemini-3-flash-preview"),
        ("gemini-3.1-flash-lite", "gemini-3.1-flash-lite-preview"),
        ("claude-sonnet-4-5-20250915", "claude-sonnet-4-5"),
    ],
)
def test_normalize_model(raw: str, expected: str) -> None:
    assert _normalize_model(raw) == expected


# ---------------------------------------------------------------------------
# Tiered pricing — Gemini 2.5 Pro and 3.1 Pro
# ---------------------------------------------------------------------------


def test_gemini_2_5_pro_low_tier() -> None:
    # 100K input (≤200K), 1K output:
    #   input  100_000 * 1.25 / 1M = 0.125
    #   output   1_000 * 10.0 / 1M = 0.01
    #   total = 0.135 USD = 135_000 micros
    assert calculate_cost_micros("gemini-2.5-pro", 100_000, 1_000) == 135_000


def test_gemini_2_5_pro_high_tier() -> None:
    # 300K input (>200K), 1K output:
    #   input  300_000 * 2.50 / 1M = 0.75
    #   output   1_000 * 15.0 / 1M = 0.015
    #   total = 0.765 USD
    assert calculate_cost_micros("gemini-2.5-pro", 300_000, 1_000) == 765_000


def test_gemini_3_1_pro_low_tier() -> None:
    # 100K input ≤200K: input 0.20 + output 0.012 = 0.212 USD
    assert calculate_cost_micros("gemini-3.1-pro", 100_000, 1_000) == 212_000


def test_gemini_3_1_pro_high_tier() -> None:
    # 300K input >200K: input 1.20 + output 0.018 = 1.218 USD
    assert calculate_cost_micros("gemini-3.1-pro", 300_000, 1_000) == 1_218_000


def test_gemini_3_1_pro_tier_threshold_boundary() -> None:
    # Exactly at threshold (200_000) should still use the LOW tier.
    # 200_000 * 2.0 / 1M = 0.40, output 0.012 = 0.412 USD
    assert calculate_cost_micros("gemini-3.1-pro", 200_000, 1_000) == 412_000
    # One token over → high tier.
    # 200_001 * 4.0 / 1M = 0.800004, output 0.018 = 0.818004 USD → 818_004 micros
    assert calculate_cost_micros("gemini-3.1-pro", 200_001, 1_000) == 818_004


# ---------------------------------------------------------------------------
# Cache pricing for Gemini
# ---------------------------------------------------------------------------


def test_gemini_2_5_pro_cache_uses_official_rate() -> None:
    # 100K input total, 50K of which are cached, 1K output (low tier):
    #   uncached input 50_000 * 1.25 / 1M = 0.0625
    #   cache read     50_000 * 0.125 / 1M = 0.00625
    #   output          1_000 * 10.0  / 1M = 0.01
    #   total = 0.07875 USD = 78_750 micros
    assert calculate_cost_micros("gemini-2.5-pro", 100_000, 1_000, 50_000) == 78_750


def test_gemini_3_1_pro_cache_high_tier() -> None:
    # 300K input total, 100K cached, 1K output (high tier):
    #   uncached input 200_000 * 4.0 / 1M = 0.80
    #   cache read     100_000 * 0.40 / 1M = 0.04
    #   output           1_000 * 18.0 / 1M = 0.018
    #   total = 0.858 USD
    assert calculate_cost_micros("gemini-3.1-pro", 300_000, 1_000, 100_000) == 858_000


def test_gemini_2_5_flash_unified_stable_rate() -> None:
    # Google unified gemini-2.5-flash pricing in the June 2025 stable release:
    # the previous preview-period split between thinking-disabled ($0.15 input /
    # $0.60 output / $0.0375 cache) and thinking-enabled ($0.30 / $2.50 / $0.03)
    # rates was retired. As of 2026-04-20 the published rate is unified at
    #   input $0.30, output $2.50, cache_read $0.03 per 1M
    # regardless of whether reasoning is enabled. Verified against
    # ai.google.dev/gemini-api/docs/pricing on 2026-04-20.
    #
    # 1M input + 1K output:
    #   input  1_000_000 * 0.30 / 1M = 0.300000
    #   output     1_000 * 2.50 / 1M = 0.002500
    #   total = 0.302500 USD = 302_500 micros
    assert calculate_cost_micros("gemini-2.5-flash", 1_000_000, 1_000) == 302_500


# ---------------------------------------------------------------------------
# Regression — non-Gemini models still work
# ---------------------------------------------------------------------------


def test_gpt_4o_regression() -> None:
    # 1M input + 1K output: 2.50 + 0.01 = 2.51 USD
    assert calculate_cost_micros("gpt-4o", 1_000_000, 1_000) == 2_510_000


def test_claude_sonnet_4_with_cache() -> None:
    # 100K input total, 50K cached, 1K output:
    #   uncached input 50_000 * 3.0 / 1M = 0.15
    #   cache read     50_000 * 0.3 / 1M = 0.015
    #   output          1_000 * 15.0 / 1M = 0.015
    #   total = 0.18 USD
    assert calculate_cost_micros("claude-sonnet-4", 100_000, 1_000, 50_000) == 180_000


def test_text_embedding_3_small_input_only() -> None:
    # Embeddings bill on input only ($0.02/MTok). Output rate is 0 so any
    # output_tokens passed in must NOT contribute to the cost.
    #   1M input * $0.02 / 1M = $0.02 = 20_000 micros
    #   any output value is multiplied by 0 → 0
    assert calculate_cost_micros("text-embedding-3-small", 1_000_000, 0) == 20_000
    assert calculate_cost_micros("text-embedding-3-small", 1_000_000, 999) == 20_000


def test_text_embedding_3_large_input_only() -> None:
    # 500K input * $0.13 / 1M = $0.065 = 65_000 micros
    assert calculate_cost_micros("text-embedding-3-large", 500_000, 0) == 65_000


def test_unknown_model_returns_zero() -> None:
    assert calculate_cost_micros("not-a-real-model-xyz", 1_000, 1_000) == 0


def test_provider_prefix_is_stripped() -> None:
    # litellm-style prefixes should resolve to the underlying model
    assert (
        calculate_cost_micros("openai/gpt-4o", 1_000_000, 1_000)
        == calculate_cost_micros("gpt-4o", 1_000_000, 1_000)
    )
    assert (
        calculate_cost_micros("gemini/gemini-2.5-pro", 100_000, 1_000)
        == calculate_cost_micros("gemini-2.5-pro", 100_000, 1_000)
    )


# ---------------------------------------------------------------------------
# Loader / data-source contract
# ---------------------------------------------------------------------------


def test_pricing_data_loads_with_expected_top_level_keys() -> None:
    """The runtime loader must surface the canonical structure intact.

    If this fails, either pricing/models.json was edited without bumping
    $schema_version (and the loader's version guard tripped), or the file
    isn't being found by either resolution path (bundled or repo-root walk-up).
    """
    assert _PRICING_DATA["$schema_version"] == 1
    for key in ("models", "aliases", "flat_pricing"):
        assert key in _PRICING_DATA, f"missing top-level key {key!r}"
    assert len(_PRICING_DATA["models"]) >= 30, "expected at least 30 models in seed"


def test_legacy_model_pricing_is_bare_keyed() -> None:
    """The _MODEL_PRICING legacy export must be keyed by BARE model id (no
    provider prefix) so back-compat consumers like internal-notify.ts on the
    server side and any external code that imported _MODEL_PRICING continue
    to work after the canonical-source refactor.
    """
    assert "gpt-4o" in _MODEL_PRICING, "bare key 'gpt-4o' should be present"
    assert "openai/gpt-4o" not in _MODEL_PRICING, "should NOT include provider prefix"
    assert "gemini-2.5-pro" in _MODEL_PRICING


def test_legacy_aliases_are_bare_to_bare() -> None:
    """_MODEL_ALIASES values used to be bare model ids (pre-refactor). The new
    canonical pricing/models.json stores them as canonical (provider/model)
    targets — the loader must strip the prefix to preserve the bare→bare
    contract for back-compat."""
    assert _MODEL_ALIASES.get("gemini-3.1-pro") == "gemini-3.1-pro-preview"
    assert "/" not in _MODEL_ALIASES.get("gemini-3.1-pro", "")


# ---------------------------------------------------------------------------
# as_of (rate-card resolution by timestamp)
# ---------------------------------------------------------------------------


def test_as_of_none_uses_latest_card() -> None:
    """Default behavior (as_of=None) must use the latest open-ended card."""
    a = calculate_cost_micros("gpt-4o", 1_000_000, 1_000)
    b = calculate_cost_micros("gpt-4o", 1_000_000, 1_000, as_of=None)
    assert a == b == 2_510_000


def test_as_of_after_seed_date_uses_seed_card() -> None:
    """All seed cards have effective_from=2026-04-20. Any timestamp at or
    after that date should resolve to the seed card."""
    after = datetime(2026, 12, 31, tzinfo=timezone.utc)
    assert calculate_cost_micros("gpt-4o", 1_000_000, 1_000, as_of=after) == 2_510_000


def test_as_of_before_earliest_card_extrapolates_backward() -> None:
    """For timestamps before the earliest card's effective_from, the loader
    extrapolates backward (with a debug log). This is necessary so historical
    rows from before the seed date still get a cost computed.
    """
    pre_seed = datetime(2025, 1, 1, tzinfo=timezone.utc)
    assert calculate_cost_micros("gpt-4o", 1_000_000, 1_000, as_of=pre_seed) == 2_510_000


def test_as_of_with_naive_datetime_assumes_utc() -> None:
    """as_of with no tzinfo should be treated as UTC (no AttributeError)."""
    naive = datetime(2026, 12, 31)
    assert calculate_cost_micros("gpt-4o", 1_000_000, 1_000, as_of=naive) == 2_510_000


# ---------------------------------------------------------------------------
# Comprehensive regression fixture
#
# This locks down EXACT cost math for every model in the canonical pricing
# table. If you change a rate in pricing/models.json (legitimately, by
# appending a new effective-dated card), the affected expected values here
# need to be updated too, and the dev-log entry should explain why.
#
# Inputs are chosen to be small but exercise input + output + (where
# applicable) cache_read so the assertion catches drift in any rate leg.
# ---------------------------------------------------------------------------


# (model_bare_key, input_tokens, output_tokens, cached_tokens, expected_micros)
REGRESSION_FIXTURE: list[tuple[str, int, int, int, int]] = [
    # --- OpenAI GPT-5 family (verified against OpenAI pricing page 2026-04-20) ---
    # gpt-5.4 has tiered pricing at 272K input tokens (long-context).
    # Low tier: input 2.5, output 15.0, cache_read 0.25 (per 1M)
    # High tier: input 5.0, output 22.5, cache_read 0.5
    ("gpt-5.4",                     100_000, 1_000,      0,    265_000),  # low tier: 100K*2.5 + 1K*15
    ("gpt-5.4",                   1_000_000, 1_000,      0,  5_022_500),  # high tier: 1M*5.0 + 1K*22.5
    ("gpt-5.4",                     100_000, 1_000, 50_000,    152_500),  # low tier w/ cache: 50K*2.5+50K*0.25+1K*15
    ("gpt-5.4",                     300_000, 1_000,100_000,  1_072_500),  # high tier w/ cache: 200K*5+100K*0.5+1K*22.5
    ("gpt-5.4-mini",              1_000_000, 1_000,      0,    754_500),  # flat: 1M*0.75 + 1K*4.5
    ("gpt-5.4-nano",              1_000_000, 1_000,      0,    201_250),  # flat: 1M*0.2 + 1K*1.25
    ("gpt-5.4-pro",                 100_000, 1_000,      0,  3_180_000),  # low tier: 100K*30 + 1K*180
    ("gpt-5.4-pro",               1_000_000, 1_000,      0, 60_270_000),  # high tier: 1M*60 + 1K*270
    ("gpt-5.2",                   1_000_000, 1_000,      0,  1_764_000),  # 1M*1.75 + 1K*14
    ("gpt-5.2-pro",               1_000_000, 1_000,      0, 21_168_000),  # 1M*21 + 1K*168 (no caching offered)
    ("gpt-5.2-pro",                 100_000, 1_000, 50_000,  1_218_000),  # cached_tokens passed → uncached 50K*21+output 1K*168, cache_read=$0/1M
    ("gpt-5.1",                   1_000_000, 1_000,      0,  1_260_000),  # 1M*1.25 + 1K*10 (same as gpt-5)
    ("gpt-5",                     1_000_000, 1_000,      0,  1_260_000),
    ("gpt-5-mini",                1_000_000, 1_000,      0,    252_000),  # 1M*0.25 + 1K*2.0
    ("gpt-5-nano",                1_000_000, 1_000,      0,     50_400),  # 1M*0.05 + 1K*0.4
    ("gpt-5-pro",                 1_000_000, 1_000,      0, 15_120_000),  # 1M*15 + 1K*120 (no caching offered)
    # --- OpenAI GPT-4 family ---
    ("gpt-4o",                    1_000_000, 1_000,      0,  2_510_000),
    ("gpt-4o",                      100_000, 1_000, 50_000,    197_500),  # 50K*2.5 + 50K*1.25 + 1K*10 = 0.125+0.0625+0.01
    ("gpt-4o-mini",               1_000_000, 1_000,      0,    150_600),
    ("gpt-4.1",                   1_000_000, 1_000,      0,  2_008_000),
    ("gpt-4.1",                     100_000, 1_000, 50_000,    133_000),  # cache fix: 50K*2 + 50K*0.5 + 1K*8 = 0.10+0.025+0.008
    ("gpt-4.1-mini",              1_000_000, 1_000,      0,    401_600),
    ("gpt-4.1-nano",              1_000_000, 1_000,      0,    100_400),
    ("o3",                        1_000_000, 1_000,      0,  2_008_000),
    ("o4-mini",                   1_000_000, 1_000,      0,  1_104_400),
    # --- OpenAI embeddings + transcription ---
    ("text-embedding-3-small",    1_000_000,     0,      0,     20_000),  # input only
    ("text-embedding-3-large",    1_000_000,     0,      0,    130_000),
    ("text-embedding-ada-002",    1_000_000,     0,      0,    100_000),
    ("gpt-4o-transcribe",         1_000_000, 1_000,      0,  2_510_000),
    ("gpt-4o-mini-transcribe",    1_000_000, 1_000,      0,  1_255_000),
    # --- Anthropic ---
    ("claude-opus-4",             1_000_000, 1_000, 0, 15_075_000),    # 1M*15 + 1K*75
    ("claude-opus-4-5",           1_000_000, 1_000, 0,  5_025_000),    # 1M*5 + 1K*25
    ("claude-opus-4-6",           1_000_000, 1_000, 0,  5_025_000),
    ("claude-opus-4-7",           1_000_000, 1_000, 0,  5_025_000),
    ("claude-sonnet-4",           1_000_000, 1_000, 0,  3_015_000),    # 1M*3 + 1K*15
    ("claude-sonnet-4-5",         1_000_000, 1_000, 0,  3_015_000),
    ("claude-sonnet-4-6",         1_000_000, 1_000, 0,  3_015_000),
    ("claude-haiku-4-5",          1_000_000, 1_000, 0,  1_005_000),    # 1M*1 + 1K*5
    # --- Google Gemini ---
    ("gemini-3.1-pro-preview",      100_000, 1_000, 0,    212_000),   # low tier: 100K*2.0 + 1K*12
    ("gemini-3.1-pro-preview",      300_000, 1_000, 0,  1_218_000),   # high tier: 300K*4.0 + 1K*18
    ("gemini-3.1-flash-lite-preview", 1_000_000, 1_000, 0, 251_500),  # 1M*0.25 + 1K*1.5
    ("gemini-3-flash-preview",      1_000_000, 1_000, 0,    503_000), # 1M*0.5 + 1K*3
    ("gemini-2.5-pro",              100_000, 1_000, 0,    135_000),   # low tier: 100K*1.25 + 1K*10
    ("gemini-2.5-pro",              300_000, 1_000, 0,    765_000),   # high tier: 300K*2.5 + 1K*15
    ("gemini-2.5-flash",          1_000_000, 1_000, 0,    302_500),   # unified stable: 1M*0.30 + 1K*2.50
    ("gemini-2.5-flash-lite",     1_000_000, 1_000, 0,    100_400),   # 1M*0.10 + 1K*0.4
    ("gemini-2.0-flash",          1_000_000, 1_000, 0,    100_400),
    ("gemini-2.0-flash-lite",     1_000_000, 1_000, 0,     75_300),   # 1M*0.075 + 1K*0.3
    # --- xAI ---
    ("grok-3",                    1_000_000, 1_000, 0,  3_015_000),
    ("grok-3-mini",               1_000_000, 1_000, 0,    300_500),   # 1M*0.3 + 1K*0.5
    ("grok-3-fast",               1_000_000, 1_000, 0,  5_025_000),   # 1M*5 + 1K*25
    # --- Cache pricing sanity ---
    ("claude-opus-4",             100_000, 1_000, 50_000, 900_000),
    # uncached 50K*$15 + cache_read 50K*$1.5 + output 1K*$75 / 1M
    # = 0.750 + 0.075 + 0.075 = 0.900 USD = 900_000 micros
    ("gpt-4o-audio",              1_000_000, 1_000, 0, 2_510_000),
    # default rates only (input_audio / output_audio default to 0 when no audio
    # token columns supplied to calculate_cost_micros — the SDK API doesn't
    # expose them, so the audio-rate paths are server-only today)
]


@pytest.mark.parametrize(
    "model,input_tokens,output_tokens,cached_tokens,expected_micros",
    REGRESSION_FIXTURE,
)
def test_regression_fixture(
    model: str,
    input_tokens: int,
    output_tokens: int,
    cached_tokens: int,
    expected_micros: int,
) -> None:
    """If this fails, you changed a rate in pricing/models.json (intentionally
    or not). Update the expected_micros in REGRESSION_FIXTURE if the change
    was intentional and explain it in docs/dev-log.md.
    """
    actual = calculate_cost_micros(model, input_tokens, output_tokens, cached_tokens)
    assert actual == expected_micros, (
        f"{model} ({input_tokens=}, {output_tokens=}, {cached_tokens=}): "
        f"expected {expected_micros:,} micros but got {actual:,} micros — "
        f"a rate in pricing/models.json changed"
    )


def test_pro_models_with_cached_tokens_charge_no_cache_surcharge() -> None:
    """Pro models (gpt-5-pro, gpt-5.2-pro, gpt-5.4-pro) do NOT offer prompt
    caching — `cache_read` is explicitly `null` in pricing/models.json. If a
    caller passes `cached_tokens > 0` for one of these models, the calculator
    must:
      (a) deduct the cached portion from the input charge (since those tokens
          aren't counted as fresh input)
      (b) add ZERO cache_read cost (no caching offered → no rate to apply).

    A previous iteration of the calculator used a `input_rate * 0.5` heuristic
    when cache_read was missing/null, which would have over-charged pro-model
    callers by ~50% of the input rate × cached_tokens. This test guards
    against the heuristic being re-introduced.
    """
    # gpt-5-pro: input $15 / 1M, output $120 / 1M, no cached
    # 100K input total, 50K cached, 1K output:
    #   uncached: 50K * $15 / 1M = $0.75
    #   cache_read: 50K * $0   / 1M = $0.00
    #   output: 1K * $120 / 1M = $0.12
    #   total = $0.87 = 870_000 micros
    assert calculate_cost_micros("gpt-5-pro", 100_000, 1_000, 50_000) == 870_000

    # If the heuristic (input_rate * 0.5) were still active:
    #   cache_read = 50K * $7.5 / 1M = $0.375 → total $1.245 = 1_245_000 micros
    # We assert the result is decisively NOT that.
    assert calculate_cost_micros("gpt-5-pro", 100_000, 1_000, 50_000) != 1_245_000


# ---------------------------------------------------------------------------
# Non-token regression fixture (audio_seconds, characters, events, ...).
#
# Token models go in REGRESSION_FIXTURE above and are exercised through
# calculate_cost_micros. Non-token models go here and are exercised through
# calculate_unit_cost_micros — same protection (a rate change → a fixture
# update → an explicit reviewer decision in PR), different code path.
# ---------------------------------------------------------------------------

# (model_bare_key, units, expected_micros)
UNIT_REGRESSION_FIXTURE: list[tuple[str, float, int]] = [
    # Deepgram Nova-3 monolingual streaming — $0.0077/min ⇒ $0.000128333.../s.
    # 60s → 0.0077 USD = 7700 micros.
    ("nova-3-monolingual",      60.0,    7_700),
    # 600s → 0.077 USD = 77000 micros.
    ("nova-3-monolingual",     600.0,   77_000),
    # Multilingual: $0.0092/min (corrected against deepgram.com/pricing 2026-04-20),
    # 60s → 0.0092 USD = 9200 micros.
    ("nova-3-multilingual",     60.0,    9_200),
    # Deepgram Flux (conversational STT for voice agents) — $0.0077/min, same as nova-3 mono.
    ("flux",                    60.0,    7_700),
    # Deepgram Nova-2 legacy — $0.0058/min ⇒ 5800 micros / 60s.
    ("nova-2",                  60.0,    5_800),
    # Deepgram Enhanced — $0.0165/min, 60s → 16500 micros.
    ("enhanced",                60.0,   16_500),
    # Deepgram Base — $0.0145/min, 60s → 14500 micros.
    ("base",                    60.0,   14_500),
    # Deepgram Aura-2 TTS — $0.030/1k chars = $0.00003/char.
    # 1000 chars → 30000 micros.
    ("aura-2",               1_000.0,   30_000),
    # Deepgram Aura-1 TTS — $0.015/1k chars = $0.000015/char.
    ("aura-1",               1_000.0,   15_000),
    # Deepgram Voice Agent API tiers (per-second rates derived from per-minute):
    ("voice-agent-standard",            60.0,   75_000),    # $0.075/min
    ("voice-agent-standard-byo-tts",    60.0,   65_000),    # $0.065/min
    ("voice-agent-custom-byo-llm",      60.0,   56_000),    # $0.056/min
    ("voice-agent-custom-byo-llm-tts",  60.0,   50_000),    # $0.050/min
    ("voice-agent-advanced",            60.0,  163_000),    # $0.163/min
    ("voice-agent-advanced-byo-tts",    60.0,  122_000),    # $0.122/min
    # Deepgram add-ons (per-second rates derived from per-minute charges).
    ("addon-redaction",            60.0,   2_000),    # $0.0020/min
    ("addon-keyterm-prompting",    60.0,   1_300),    # $0.0013/min
    ("addon-diarization",          60.0,   2_000),    # $0.0020/min
    # ElevenLabs Flash family (Flash v2, Flash v2.5, Turbo v2, Turbo v2.5):
    # FLAT $0.05 per 1K chars across all tiers per https://elevenlabs.io/pricing/api
    # 2026-04-20. 1000 chars → 50000 micros.
    ("eleven_flash_v2_5",    1_000.0,   50_000),
    ("eleven_flash_v2_5",      100.0,    5_000),
    ("eleven_flash_v2",      1_000.0,   50_000),
    ("eleven_turbo_v2",      1_000.0,   50_000),
    ("eleven_turbo_v2_5",    1_000.0,   50_000),
    # ElevenLabs Multilingual family (Multilingual v2, v3): FLAT $0.10 per 1K chars.
    # 1000 chars → 100000 micros.
    ("eleven_multilingual_v2", 1_000.0, 100_000),
    ("eleven_v3",            1_000.0,  100_000),
    # ElevenLabs Scribe v1/v2 (batch STT): $0.22/hour = 0.22/3600 per second.
    # 3600s (1h) → 220000 micros = $0.22.
    ("scribe_v1",            3_600.0,  220_000),
    ("scribe_v2",            3_600.0,  220_000),
    # ElevenLabs Scribe v2 Realtime (streaming STT): $0.39/hour.
    ("scribe_v2_realtime",   3_600.0,  390_000),
    # ElevenLabs Scribe add-ons (flat per-hour, no quota, no tier discount).
    ("scribe-addon-entity-detection",  3_600.0,  70_000),  # $0.07/hr
    ("scribe-addon-keyterm-prompting", 3_600.0,  50_000),  # $0.05/hr
    # ElevenLabs Music — $0.30/min, 60s → 300000 micros = $0.30.
    ("music_v1",                60.0,  300_000),
    # ElevenLabs Voice Isolator / Voice Changer — $0.12/min each.
    ("voice-isolator",          60.0,  120_000),
    ("voice-changer",           60.0,  120_000),
    # ElevenLabs Sound Effects — $0.12/generation (events).
    ("sound-effects",            1.0,  120_000),
    ("sound-effects",           10.0, 1_200_000),
    # ElevenLabs Dubbing v1 — watermarked $0.33/min, no-watermark $0.50/min.
    ("dubbing-v1-watermarked",  60.0,  330_000),
    ("dubbing-v1",              60.0,  500_000),
    # LiveKit agent session minutes — $0.01/min ⇒ $0.000166666.../s.
    # 60s → 0.01 USD = 10000 micros.
    ("agent-session-minute",    60.0,   10_000),
    # 1 hour = 3600s → 0.6 USD = 600000 micros.
    ("agent-session-minute",  3_600.0,  600_000),
    # LiveKit observability events — $0.00003/event = 30 micros/event.
    ("observability-event",      1.0,       30),
    ("observability-event",  1_000.0,   30_000),
    # LiveKit WebRTC end-user minutes (Ship rate $0.0005/min = $0.0000083.../s).
    # 60s → 0.0005 USD = 500 micros.
    ("webrtc-minute",           60.0,      500),
    ("webrtc-minute",        3_600.0,   30_000),
    # LiveKit agent-session-recording — $0.005/min, 60s → 5000 micros.
    ("agent-session-recording-minute",  60.0,    5_000),
    # LiveKit voice isolation — $0.0012/min, 60s → 1200 micros.
    ("voice-isolation-minute",          60.0,    1_200),
    # LiveKit track egress — $0.001/min, 60s → 1000 micros.
    ("track-egress-minute",             60.0,    1_000),
    # LiveKit transcode — Ship rates ($0.005/min audio, $0.02/min video).
    ("transcode-audio-minute",          60.0,    5_000),
    ("transcode-video-minute",          60.0,   20_000),
    # LiveKit telephony — $0.01/min local inbound, $0.02/min toll-free, $0.004/min SIP.
    ("us-local-inbound-minute",         60.0,   10_000),
    ("us-toll-free-inbound-minute",     60.0,   20_000),
    ("sip-trunk-minute",                60.0,    4_000),
    # LiveKit data transfer — Ship rate $0.12/GB. 1 GB → 120000 micros.
    ("data-transfer-gb",                 1.0,  120_000),
    # LiveKit phone numbers — $1/mo local, $2/mo toll-free.
    ("us-local-phone-number",            1.0,    1_000_000),
    ("us-toll-free-phone-number",        1.0,    2_000_000),

    # ---- Deepgram Growth-tier streaming (PAYG entries are above) ----
    ("flux-growth",                            60.0,    6_500),    # $0.0065/min
    ("nova-3-monolingual-growth",              60.0,    6_500),    # $0.0065/min
    ("nova-3-multilingual-growth",             60.0,    7_800),    # $0.0078/min
    ("nova-2-growth",                          60.0,    4_700),    # $0.0047/min
    ("enhanced-growth",                        60.0,   13_600),    # $0.0136/min
    ("base-growth",                            60.0,   10_500),    # $0.0105/min
    # ---- Deepgram pre-recorded PAYG (materially cheaper than streaming) ----
    ("nova-3-monolingual-prerecorded",         60.0,    4_300),    # $0.0043/min
    ("nova-3-multilingual-prerecorded",        60.0,    5_200),    # $0.0052/min
    ("nova-2-prerecorded",                     60.0,    4_300),    # $0.0043/min
    ("enhanced-prerecorded",                   60.0,   14_500),    # $0.0145/min
    ("base-prerecorded",                       60.0,   12_500),    # $0.0125/min
    ("whisper-large-prerecorded",              60.0,    4_800),    # $0.0048/min (no Growth discount)
    # ---- Deepgram pre-recorded Growth ----
    ("nova-3-monolingual-prerecorded-growth",  60.0,    3_600),    # $0.0036/min
    ("nova-3-multilingual-prerecorded-growth", 60.0,    4_300),    # $0.0043/min
    ("nova-2-prerecorded-growth",              60.0,    3_500),    # $0.0035/min
    ("enhanced-prerecorded-growth",            60.0,   11_500),    # $0.0115/min
    ("base-prerecorded-growth",                60.0,    9_500),    # $0.0095/min
    # ---- Deepgram TTS Growth ----
    ("aura-2-growth",                       1_000.0,   27_000),    # $0.027/1k chars
    ("aura-1-growth",                       1_000.0,   13_500),    # $0.0135/1k chars
    # ---- Deepgram Voice Agent API Growth ----
    ("voice-agent-standard-growth",            60.0,   68_000),    # $0.068/min
    ("voice-agent-standard-byo-tts-growth",    60.0,   51_000),    # $0.051/min
    ("voice-agent-custom-byo-llm-growth",      60.0,   59_000),    # $0.059/min (HIGHER than PAYG)
    ("voice-agent-custom-byo-llm-tts-growth",  60.0,   41_000),    # $0.041/min
    ("voice-agent-advanced-growth",            60.0,  146_000),    # $0.146/min
    ("voice-agent-advanced-byo-tts-growth",    60.0,  110_000),    # $0.110/min
    # ---- Deepgram add-on Growth + pre-recorded combinations ----
    ("addon-redaction-growth",                 60.0,    1_700),    # $0.0017/min
    ("addon-redaction-prerecorded",            60.0,    2_000),    # $0.0020/min
    ("addon-redaction-prerecorded-growth",     60.0,    1_700),    # $0.0017/min
    ("addon-keyterm-prompting-growth",         60.0,    1_200),    # $0.0012/min
    # Pre-recorded keyterm prompting is FLAT $0.0017/min (HIGHER than streaming
    # PAYG of $0.0013/min — the only add-on that costs more pre-recorded).
    ("addon-keyterm-prompting-prerecorded",    60.0,    1_700),    # $0.0017/min
    ("addon-keyterm-prompting-prerecorded-growth", 60.0, 1_700),   # $0.0017/min (no Growth discount)
    ("addon-diarization-growth",               60.0,    1_700),    # $0.0017/min
    # Entity Detection is pre-recorded-only, flat $0.0017/min on both plans.
    ("addon-entity-detection-prerecorded",     60.0,    1_700),    # $0.0017/min
    ("addon-entity-detection-prerecorded-growth", 60.0,  1_700),   # $0.0017/min (no Growth discount)
]


@pytest.mark.parametrize(
    "model,units,expected_micros",
    UNIT_REGRESSION_FIXTURE,
)
def test_unit_regression_fixture(
    model: str,
    units: float,
    expected_micros: int,
) -> None:
    """If this fails, you changed a rate in pricing/models.json for a non-token
    model. Update the expected_micros in UNIT_REGRESSION_FIXTURE if the change
    was intentional and explain it in docs/dev-log.md.
    """
    actual = calculate_unit_cost_micros(model, units)
    assert actual == expected_micros, (
        f"{model} ({units=}): expected {expected_micros:,} micros but got "
        f"{actual:,} micros — a rate in pricing/models.json changed"
    )


def test_unit_cost_for_token_model_returns_zero() -> None:
    """Mis-routed call: passing a token-billing model to the unit calculator
    should return 0 (and log a warning), not silently invent a cost."""
    assert calculate_unit_cost_micros("gpt-4o", 1000) == 0


def test_unit_cost_for_unknown_model_returns_zero() -> None:
    """Same fail-soft contract as calculate_cost_micros."""
    assert calculate_unit_cost_micros("does-not-exist-model-xyz", 100) == 0


def test_regression_fixture_covers_every_seeded_model() -> None:
    """Guard against a model being added to pricing/models.json without a
    corresponding regression-fixture entry. Every model in _MODEL_PRICING
    must have at least one row in REGRESSION_FIXTURE (token models) or
    UNIT_REGRESSION_FIXTURE (non-token models)."""
    fixture_models = {row[0] for row in REGRESSION_FIXTURE} | {
        row[0] for row in UNIT_REGRESSION_FIXTURE
    }
    pricing_models = set(_MODEL_PRICING.keys())
    missing = pricing_models - fixture_models
    assert not missing, (
        f"{len(missing)} model(s) in pricing/models.json have no regression-"
        f"fixture entry: {sorted(missing)}. Add them to REGRESSION_FIXTURE "
        "(token models) or UNIT_REGRESSION_FIXTURE (non-token models) in "
        "tests/test_pricing.py with hand-calculated expected micros."
    )
