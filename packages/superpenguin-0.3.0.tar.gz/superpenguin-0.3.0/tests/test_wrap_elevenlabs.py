"""Unit tests for ``sp.wrap(elevenlabs_client)`` standalone wrapping.

Uses lightweight fake classes whose ``__module__`` is set to
``"elevenlabs.fake"`` so ``_detect_provider`` recognizes them. The real
``elevenlabs`` SDK is NOT a test dependency.

Coverage:
  * Sync text_to_speech.convert → one elevenlabs row, characters = len(text).
  * Async text_to_speech.convert → same shape, awaited path.
  * convert_as_stream → row submitted ONLY after the consumer iterates
    the stream (so latency captures real synthesis time).
  * text_to_sound_effects.convert → routes to the same audio_out modality.
  * Custom model_id flows through to the canonical slug.
  * Empty text → no row submitted (no billable work).
  * Exception path → row with status_code != 200 and cost=0.
  * Default metadata → known attribution + custom_tags.
  * Double-wrap is a no-op.
"""

from __future__ import annotations

import asyncio
from typing import Any

import pytest

import superpenguin


# ---------------------------------------------------------------------------
# Capturing client
# ---------------------------------------------------------------------------


class _CapturingClient:
    def __init__(self) -> None:
        self.events: list[dict[str, Any]] = []

    def submit(self, event: dict[str, Any]) -> None:
        self.events.append(event)


@pytest.fixture(autouse=True)
def _swap_client(monkeypatch: pytest.MonkeyPatch) -> _CapturingClient:
    fake = _CapturingClient()
    monkeypatch.setattr(superpenguin, "_client", fake)
    return fake


# ---------------------------------------------------------------------------
# Fake ElevenLabs SDK shapes
# ---------------------------------------------------------------------------


class _FakeTextToSpeech:
    """Mimics ``client.text_to_speech``."""

    def __init__(self) -> None:
        self._next_response: Any = None
        self._next_exception: Exception | None = None
        self.last_kwargs: dict[str, Any] = {}

    def set_response(self, response: Any) -> None:
        self._next_response = response
        self._next_exception = None

    def set_exception(self, exc: Exception) -> None:
        self._next_exception = exc
        self._next_response = None

    def convert(self, *args: Any, **kwargs: Any) -> Any:
        self.last_kwargs = kwargs
        if self._next_exception is not None:
            raise self._next_exception
        return self._next_response

    def convert_as_stream(self, *args: Any, **kwargs: Any) -> Any:
        self.last_kwargs = kwargs
        if self._next_exception is not None:
            raise self._next_exception
        return self._next_response


class _FakeAsyncTextToSpeech:
    def __init__(self) -> None:
        self._next_response: Any = None
        self._next_exception: Exception | None = None

    def set_response(self, response: Any) -> None:
        self._next_response = response
        self._next_exception = None

    def set_exception(self, exc: Exception) -> None:
        self._next_exception = exc
        self._next_response = None

    async def convert(self, *args: Any, **kwargs: Any) -> Any:
        if self._next_exception is not None:
            raise self._next_exception
        return self._next_response

    async def convert_as_stream(self, *args: Any, **kwargs: Any) -> Any:
        if self._next_exception is not None:
            raise self._next_exception
        return self._next_response


class _FakeTextToSoundEffects:
    def __init__(self) -> None:
        self._next_response: Any = None

    def set_response(self, response: Any) -> None:
        self._next_response = response

    def convert(self, *args: Any, **kwargs: Any) -> Any:
        return self._next_response

    def convert_as_stream(self, *args: Any, **kwargs: Any) -> Any:
        return self._next_response


class _FakeElevenLabs:
    def __init__(self) -> None:
        self.text_to_speech = _FakeTextToSpeech()
        self.text_to_sound_effects = _FakeTextToSoundEffects()


class _FakeAsyncElevenLabs:
    """Class name carries 'Async' so the wrapper picks the async branch."""

    def __init__(self) -> None:
        self.text_to_speech = _FakeAsyncTextToSpeech()
        self.text_to_sound_effects = _FakeTextToSoundEffects()


# Force _detect_provider to map these to ElevenLabs.
for cls in (
    _FakeElevenLabs, _FakeAsyncElevenLabs,
    _FakeTextToSpeech, _FakeAsyncTextToSpeech, _FakeTextToSoundEffects,
):
    cls.__module__ = "elevenlabs.fake"


# ---------------------------------------------------------------------------
# Sync convert
# ---------------------------------------------------------------------------


def test_sync_convert_emits_one_row(_swap_client: _CapturingClient) -> None:
    client = _FakeElevenLabs()
    superpenguin.wrap(client, metadata={"customer_id": "acme", "feature": "ivr"})
    client.text_to_speech.set_response(b"\x00\x01")  # synthesized audio bytes

    result = client.text_to_speech.convert(
        voice_id="voice-x",
        text="Hello world",  # 11 characters
        model_id="eleven_flash_v2_5",
    )

    assert result == b"\x00\x01"
    assert len(_swap_client.events) == 1
    row = _swap_client.events[0]
    assert row["provider"] == "elevenlabs"
    assert row["model"] == "elevenlabs/eleven_flash_v2_5"
    assert row["modality"] == "audio_out"
    assert row["characters"] == 11
    assert row["customer_id"] == "acme"
    assert row["feature"] == "ivr"
    assert row["status_code"] == 200
    # Flash v2.5 ElevenLabs API rate: $0.05 per 1K chars = $0.00005/char.
    # 11 chars * $0.00005 = $0.00055 = 550 micros.
    assert row["cost_usd_micros"] == 550


def test_sync_convert_with_default_model(_swap_client: _CapturingClient) -> None:
    """When model_id is omitted the wrapper substitutes _DEFAULT_MODEL_ID
    (eleven_flash_v2_5) so the row never lands as 'elevenlabs/' with no
    SKU — that would break dashboard grouping."""
    client = _FakeElevenLabs()
    superpenguin.wrap(client)
    client.text_to_speech.set_response(b"\x00")

    client.text_to_speech.convert(voice_id="v", text="hi")  # no model_id

    row = _swap_client.events[0]
    assert row["model"] == "elevenlabs/eleven_flash_v2_5"
    assert row["characters"] == 2


def test_sync_convert_with_custom_model(_swap_client: _CapturingClient) -> None:
    client = _FakeElevenLabs()
    superpenguin.wrap(client)
    client.text_to_speech.set_response(b"\x00")

    client.text_to_speech.convert(voice_id="v", text="hello", model_id="eleven_v3")

    row = _swap_client.events[0]
    assert row["model"] == "elevenlabs/eleven_v3"


# ---------------------------------------------------------------------------
# Empty / missing text → no row
# ---------------------------------------------------------------------------


def test_empty_text_emits_no_row(_swap_client: _CapturingClient) -> None:
    client = _FakeElevenLabs()
    superpenguin.wrap(client)
    client.text_to_speech.set_response(b"")

    client.text_to_speech.convert(voice_id="v", text="")

    assert _swap_client.events == []


def test_missing_text_emits_no_row(_swap_client: _CapturingClient) -> None:
    client = _FakeElevenLabs()
    superpenguin.wrap(client)
    client.text_to_speech.set_response(b"")

    client.text_to_speech.convert(voice_id="v")  # no text at all

    assert _swap_client.events == []


# ---------------------------------------------------------------------------
# convert_as_stream → row only after consumption
# ---------------------------------------------------------------------------


def test_convert_as_stream_submits_after_consumption(
    _swap_client: _CapturingClient,
) -> None:
    client = _FakeElevenLabs()
    superpenguin.wrap(client)

    def _gen() -> Any:
        for chunk in (b"\x00", b"\x01", b"\x02"):
            yield chunk

    client.text_to_speech.set_response(_gen())

    stream = client.text_to_speech.convert_as_stream(
        voice_id="v", text="streamed text", model_id="eleven_flash_v2_5",
    )

    # No row yet — proxy returned, but we haven't consumed.
    assert _swap_client.events == []

    chunks = list(stream)
    assert chunks == [b"\x00", b"\x01", b"\x02"]

    # NOW the on_done callback fires → exactly one row.
    assert len(_swap_client.events) == 1
    row = _swap_client.events[0]
    assert row["streaming"] is True
    assert row["characters"] == len("streamed text")


# ---------------------------------------------------------------------------
# Sound effects
# ---------------------------------------------------------------------------


def test_sound_effects_convert_emits_row(_swap_client: _CapturingClient) -> None:
    client = _FakeElevenLabs()
    superpenguin.wrap(client)
    client.text_to_sound_effects.set_response(b"\x00")

    client.text_to_sound_effects.convert(text="thunder rumble")

    assert len(_swap_client.events) == 1
    row = _swap_client.events[0]
    assert row["provider"] == "elevenlabs"
    # No model_id provided → defaults to flash. Sound effects pricing is
    # under the same SKU family today; this test guards against the
    # default substitution being dropped.
    assert row["modality"] == "audio_out"
    assert row["characters"] == len("thunder rumble")


# ---------------------------------------------------------------------------
# Async path
# ---------------------------------------------------------------------------


def test_async_convert_emits_row(_swap_client: _CapturingClient) -> None:
    client = _FakeAsyncElevenLabs()
    superpenguin.wrap(client, metadata={"environment": "prod"})
    client.text_to_speech.set_response(b"\x00\x01")

    asyncio.run(
        client.text_to_speech.convert(
            voice_id="v", text="hi async", model_id="eleven_flash_v2_5",
        )
    )

    assert len(_swap_client.events) == 1
    row = _swap_client.events[0]
    assert row["characters"] == len("hi async")
    assert row["environment"] == "prod"


# ---------------------------------------------------------------------------
# Error path
# ---------------------------------------------------------------------------


class _ElevenLabsHTTPError(Exception):
    status_code = 422


def test_exception_emits_zero_cost_row_and_reraises(
    _swap_client: _CapturingClient,
) -> None:
    client = _FakeElevenLabs()
    superpenguin.wrap(client)
    client.text_to_speech.set_exception(_ElevenLabsHTTPError("bad voice"))

    with pytest.raises(_ElevenLabsHTTPError):
        client.text_to_speech.convert(
            voice_id="v", text="will fail", model_id="eleven_flash_v2_5",
        )

    assert len(_swap_client.events) == 1
    row = _swap_client.events[0]
    assert row["status_code"] == 422
    # ElevenLabs doesn't bill failed requests → cost overridden to 0.
    assert row["cost_usd_micros"] == 0
    # Characters still recorded for analytics.
    assert row["characters"] == len("will fail")


# ---------------------------------------------------------------------------
# Idempotency
# ---------------------------------------------------------------------------


def test_double_wrap_is_idempotent(_swap_client: _CapturingClient) -> None:
    client = _FakeElevenLabs()
    superpenguin.wrap(client)
    superpenguin.wrap(client)  # must be no-op
    client.text_to_speech.set_response(b"\x00")

    client.text_to_speech.convert(voice_id="v", text="hi", model_id="eleven_flash_v2_5")

    assert len(_swap_client.events) == 1


# ---------------------------------------------------------------------------
# Module-detection sanity
# ---------------------------------------------------------------------------


def test_detect_provider_recognizes_elevenlabs() -> None:
    from superpenguin._wrap import _detect_provider

    assert _detect_provider(_FakeElevenLabs()) == "elevenlabs"
    assert _detect_provider(_FakeAsyncElevenLabs()) == "elevenlabs"
