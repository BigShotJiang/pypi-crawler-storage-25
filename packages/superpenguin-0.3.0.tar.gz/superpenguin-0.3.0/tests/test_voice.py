"""Unit tests for the LiveKitObservability voice shim.

These tests use lightweight ``SimpleNamespace`` fakes for LiveKit's
``STTMetrics`` / ``TTSMetrics`` / ``LLMMetrics`` so the real
``livekit.agents`` package isn't required to run them.

What's covered:
  * STTMetrics → one Deepgram row with audio_seconds + cost_usd_micros.
  * TTSMetrics → one ElevenLabs row with characters + cost_usd_micros.
  * LLMMetrics → IGNORED (no submit) — guards against double-counting since
    the LLM client wrapper already captures these.
  * Empty turn (audio_duration=0) → no row submitted (skips zero-cost noise).
  * on_session_end → submits LiveKit agent-session-minute and
    observability-event rows when a non-zero count exists.
  * Idempotency keys composed deterministically as
    f"{session_id}:{kind}:{request_id}" so a retry on the SDK side maps to
    the same row server-side.
  * Metadata is split into known attribution columns (customer_id, feature,
    team, environment, prompt_*) vs custom_tags JSON.
"""

from __future__ import annotations

import asyncio
from types import SimpleNamespace
from typing import Any

import pytest

import superpenguin
from superpenguin.voice import LiveKitObservability

# SimpleNamespace is used only for the lightweight event wrapper below;
# the metric subtypes themselves are real named classes (see STTMetrics
# / TTSMetrics / LLMMetrics) since type(metric).__name__ is the dispatch
# key the shim reads.


class _CapturingClient:
    """Drop-in for SuperPenguinClient that just records submitted events."""

    def __init__(self) -> None:
        self.events: list[dict[str, Any]] = []

    def submit(self, event: dict[str, Any]) -> None:
        self.events.append(event)


@pytest.fixture(autouse=True)
def _swap_client(monkeypatch: pytest.MonkeyPatch) -> _CapturingClient:
    """Swap superpenguin's global client with a capturing fake for the duration
    of each test."""
    fake = _CapturingClient()
    monkeypatch.setattr(superpenguin, "_client", fake)
    # get_client() returns _client when set; with the fake in place the
    # shim's submit path captures into `fake.events` instead of POSTing.
    return fake


# Named classes so type(metrics).__name__ matches the shim's dispatch table.
# SimpleNamespace can't have its __class__ reassigned (immutable layout), so
# we define real one-shot classes here. Each carries the public attribute
# surface the shim reads — anything missing should default-out via getattr.


class STTMetrics:
    def __init__(self, *, audio_duration: float, request_id: str | None = None) -> None:
        self.audio_duration = audio_duration
        if request_id is not None:
            self.request_id = request_id
        self.duration = 0.123


class TTSMetrics:
    def __init__(
        self,
        *,
        characters_count: int,
        audio_duration: float,
        request_id: str | None = None,
    ) -> None:
        self.characters_count = characters_count
        self.audio_duration = audio_duration
        if request_id is not None:
            self.request_id = request_id
        self.ttft = 0.05


class LLMMetrics:
    def __init__(self, *, tokens: int = 100) -> None:
        self.prompt_tokens = tokens
        self.completion_tokens = tokens


def _stt(audio_duration: float, request_id: str = "stt-1") -> STTMetrics:
    return STTMetrics(audio_duration=audio_duration, request_id=request_id)


def _tts(characters: int, audio_duration: float, request_id: str = "tts-1") -> TTSMetrics:
    return TTSMetrics(
        characters_count=characters,
        audio_duration=audio_duration,
        request_id=request_id,
    )


def _llm(tokens: int = 100) -> LLMMetrics:
    return LLMMetrics(tokens=tokens)


def _ev(metrics: Any) -> SimpleNamespace:
    return SimpleNamespace(metrics=metrics)


# ---------------------------------------------------------------------------
# STT
# ---------------------------------------------------------------------------


def test_stt_metric_emits_one_deepgram_row(_swap_client: _CapturingClient) -> None:
    obs = LiveKitObservability(session_id="room-abc")
    asyncio.run(obs.on_metrics(_ev(_stt(audio_duration=10.0, request_id="r1"))))

    assert len(_swap_client.events) == 1
    row = _swap_client.events[0]
    assert row["provider"] == "deepgram"
    assert row["model"] == "deepgram/nova-3-monolingual"
    assert row["modality"] == "audio_in"
    assert row["audio_seconds"] == 10.0
    assert row["session_id"] == "room-abc"
    assert row["idempotency_key"] == "room-abc:stt:r1"
    # 10s * $0.0077/min = $0.001283... ≈ 1283 micros.
    assert row["cost_usd_micros"] == pytest.approx(1283, abs=1)


def test_stt_metric_with_zero_audio_emits_nothing(
    _swap_client: _CapturingClient,
) -> None:
    obs = LiveKitObservability(session_id="room-abc")
    asyncio.run(obs.on_metrics(_ev(_stt(audio_duration=0.0))))

    assert _swap_client.events == []


# ---------------------------------------------------------------------------
# TTS
# ---------------------------------------------------------------------------


def test_tts_metric_emits_one_elevenlabs_row(_swap_client: _CapturingClient) -> None:
    obs = LiveKitObservability(session_id="room-xyz")
    asyncio.run(
        obs.on_metrics(_ev(_tts(characters=200, audio_duration=4.0, request_id="t1")))
    )

    assert len(_swap_client.events) == 1
    row = _swap_client.events[0]
    assert row["provider"] == "elevenlabs"
    assert row["model"] == "elevenlabs/eleven_flash_v2_5"
    assert row["modality"] == "audio_out"
    assert row["characters"] == 200
    assert row["audio_seconds"] == 4.0
    assert row["idempotency_key"] == "room-xyz:tts:t1"
    # Flash v2.5 ElevenLabs API rate: flat $0.05 per 1K chars = $0.00005/char.
    # 200 chars * $0.00005 = $0.01 = 10000 micros.
    assert row["cost_usd_micros"] == 10000


def test_tts_metric_with_zero_chars_emits_nothing(
    _swap_client: _CapturingClient,
) -> None:
    obs = LiveKitObservability(session_id="room-xyz")
    asyncio.run(obs.on_metrics(_ev(_tts(characters=0, audio_duration=0.0))))

    assert _swap_client.events == []


# ---------------------------------------------------------------------------
# LLM — must be a no-op
# ---------------------------------------------------------------------------


def test_llm_metric_is_skipped(_swap_client: _CapturingClient) -> None:
    """The LLM call is already captured by sp.wrap(); re-emitting from the
    voice shim would create a second row in request_logs and double the
    reported cost. This test guards against accidentally enabling LLM
    submission in the shim."""
    obs = LiveKitObservability(session_id="room-llm")
    asyncio.run(obs.on_metrics(_ev(_llm())))

    assert _swap_client.events == []


# ---------------------------------------------------------------------------
# Session end
# ---------------------------------------------------------------------------


def test_session_end_emits_session_minute_and_event_rows(
    _swap_client: _CapturingClient,
) -> None:
    obs = LiveKitObservability(session_id="room-end")
    asyncio.run(obs.on_metrics(_ev(_stt(audio_duration=5.0))))
    asyncio.run(obs.on_metrics(_ev(_tts(characters=10, audio_duration=2.0))))
    _swap_client.events.clear()

    asyncio.run(obs.on_session_end(duration_seconds=120.0))

    # One agent-session-minute row + one observability-event row.
    assert len(_swap_client.events) == 2
    by_model = {row["model"]: row for row in _swap_client.events}

    session_row = by_model["livekit/agent-session-minute"]
    assert session_row["audio_seconds"] == 120.0
    assert session_row["modality"] == "session"
    # 120s * $0.01/min = $0.02 = 20000 micros.
    assert session_row["cost_usd_micros"] == 20000
    assert session_row["idempotency_key"] == "room-end:session-end:end"

    event_row = by_model["livekit/observability-event"]
    # Two metrics passed through on_metrics, so the counter should be 2.
    assert event_row["events"] == 2
    assert event_row["modality"] == "event"
    assert event_row["idempotency_key"] == "room-end:obs-events:end"
    # 2 events * $0.00003/event = $0.00006 = 60 micros.
    assert event_row["cost_usd_micros"] == 60


def test_session_end_with_zero_duration_skips_session_row(
    _swap_client: _CapturingClient,
) -> None:
    obs = LiveKitObservability(session_id="room-zero")
    asyncio.run(obs.on_session_end(duration_seconds=0.0))

    # No metrics arrived → observability-event count is 0 → no event row.
    # Session duration is 0 → no session-minute row either.
    assert _swap_client.events == []


# ---------------------------------------------------------------------------
# Metadata routing
# ---------------------------------------------------------------------------


def test_known_attribution_metadata_is_top_level(
    _swap_client: _CapturingClient,
) -> None:
    obs = LiveKitObservability(
        session_id="room-meta",
        metadata={
            "customer_id": "cust-7",
            "feature": "drive-thru",
            "internal_trace_id": "trace-42",  # unknown → custom_tags
        },
    )
    asyncio.run(obs.on_metrics(_ev(_stt(audio_duration=3.0))))

    row = _swap_client.events[0]
    assert row["customer_id"] == "cust-7"
    assert row["feature"] == "drive-thru"
    assert row["custom_tags"] == {"internal_trace_id": "trace-42"}


# ---------------------------------------------------------------------------
# Idempotency-key fallback
# ---------------------------------------------------------------------------


def test_metric_without_request_id_uses_monotonic_fallback(
    _swap_client: _CapturingClient,
) -> None:
    obs = LiveKitObservability(session_id="room-noid")
    # request_id omitted so the shim falls back to its monotonic counter.
    asyncio.run(obs.on_metrics(_ev(STTMetrics(audio_duration=1.0))))
    asyncio.run(obs.on_metrics(_ev(STTMetrics(audio_duration=1.0))))

    keys = [r["idempotency_key"] for r in _swap_client.events]
    assert keys == ["room-noid:stt:seq1", "room-noid:stt:seq2"]


# ---------------------------------------------------------------------------
# routing_path
# ---------------------------------------------------------------------------


def test_routing_path_propagates(_swap_client: _CapturingClient) -> None:
    obs = LiveKitObservability(session_id="room-route", routing_path="livekit_inference")
    asyncio.run(obs.on_metrics(_ev(_stt(audio_duration=1.0))))

    assert _swap_client.events[0]["routing_path"] == "livekit_inference"
