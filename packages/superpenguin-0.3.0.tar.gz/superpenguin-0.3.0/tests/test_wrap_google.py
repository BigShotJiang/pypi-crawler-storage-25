"""Unit tests for Google (google-genai) wrapper plumbing.

Uses lightweight ``SimpleNamespace`` fakes so the real ``google-genai`` SDK
isn't required to run these tests.
"""

from __future__ import annotations

from types import SimpleNamespace

from superpenguin._wrap import (
    _GoogleAccumulator,
    _detect_provider,
    _extract_fallback_model,
    _normalize_google,
)


# ---------------------------------------------------------------------------
# Provider detection
# ---------------------------------------------------------------------------


def _make_client_with_module(module_name: str) -> object:
    """Construct an object whose type sits in the given module path."""
    cls = type("FakeClient", (), {})
    cls.__module__ = module_name
    return cls()


def test_detect_provider_recognizes_google_genai() -> None:
    assert _detect_provider(_make_client_with_module("google.genai.client")) == "google"


def test_detect_provider_recognizes_underscore_variant() -> None:
    assert _detect_provider(_make_client_with_module("google_genai.client")) == "google"


def test_detect_provider_recognizes_openai() -> None:
    assert _detect_provider(_make_client_with_module("openai.resources.chat")) == "openai"


def test_detect_provider_recognizes_anthropic() -> None:
    assert _detect_provider(_make_client_with_module("anthropic._client")) == "anthropic"


def test_detect_provider_returns_none_for_unknown() -> None:
    assert _detect_provider(_make_client_with_module("some.random.module")) is None


# ---------------------------------------------------------------------------
# _normalize_google — non-streaming responses
# ---------------------------------------------------------------------------


def _make_google_response(
    *,
    model: str = "gemini-2.5-pro",
    prompt: int = 1000,
    candidates: int = 50,
    cached: int = 0,
    has_function_call: bool = False,
) -> SimpleNamespace:
    parts = []
    if has_function_call:
        parts.append(SimpleNamespace(function_call=SimpleNamespace(name="lookup")))
    parts.append(SimpleNamespace(function_call=None, text="hello"))

    return SimpleNamespace(
        model_version=model,
        candidates=[SimpleNamespace(content=SimpleNamespace(parts=parts))],
        usage_metadata=SimpleNamespace(
            prompt_token_count=prompt,
            candidates_token_count=candidates,
            cached_content_token_count=cached,
        ),
    )


def test_normalize_google_extracts_model_and_usage() -> None:
    resp = _make_google_response(model="gemini-2.5-pro", prompt=1234, candidates=56, cached=10)
    out = _normalize_google(resp)

    assert out["model"] == "gemini-2.5-pro"
    assert out["has_tools"] is False
    assert out["usage"] == {
        "input_tokens": 1234,
        "output_tokens": 56,
        "total_tokens": 1290,
        "cached_tokens": 10,
    }


def test_normalize_google_detects_function_calls() -> None:
    resp = _make_google_response(has_function_call=True)
    out = _normalize_google(resp)
    assert out["has_tools"] is True


def test_normalize_google_handles_missing_usage() -> None:
    resp = SimpleNamespace(model_version="gemini-2.5-flash", candidates=[], usage_metadata=None)
    out = _normalize_google(resp)
    assert out["model"] == "gemini-2.5-flash"
    assert out["has_tools"] is False
    assert "usage" not in out


# ---------------------------------------------------------------------------
# _GoogleAccumulator — streaming
# ---------------------------------------------------------------------------


def _make_chunk(
    *,
    model: str | None = None,
    prompt: int = 0,
    candidates: int = 0,
    cached: int = 0,
    function_call: bool = False,
) -> SimpleNamespace:
    parts = []
    if function_call:
        parts.append(SimpleNamespace(function_call=SimpleNamespace(name="x")))
    chunk_parts = parts or [SimpleNamespace(function_call=None, text="...")]
    usage = None
    if prompt or candidates or cached:
        usage = SimpleNamespace(
            prompt_token_count=prompt,
            candidates_token_count=candidates,
            cached_content_token_count=cached,
        )
    return SimpleNamespace(
        model_version=model,
        candidates=[SimpleNamespace(content=SimpleNamespace(parts=chunk_parts))],
        usage_metadata=usage,
    )


def test_google_accumulator_collects_final_usage() -> None:
    acc = _GoogleAccumulator()
    acc(_make_chunk(model="gemini-2.5-pro"))
    acc(_make_chunk())
    # Google sends cumulative usage (often only on the final chunk).
    acc(_make_chunk(prompt=500, candidates=120))

    result = acc.result()
    assert result["model"] == "gemini-2.5-pro"
    assert result["has_tools"] is False
    assert result["usage"] == {
        "input_tokens": 500,
        "output_tokens": 120,
        "total_tokens": 620,
        "cached_tokens": 0,
    }


def test_google_accumulator_detects_tool_calls_mid_stream() -> None:
    acc = _GoogleAccumulator()
    acc(_make_chunk(model="gemini-2.5-flash"))
    acc(_make_chunk(function_call=True))
    acc(_make_chunk(prompt=10, candidates=20))

    result = acc.result()
    assert result["has_tools"] is True


def test_google_accumulator_no_chunks_yields_minimal_result() -> None:
    acc = _GoogleAccumulator()
    result = acc.result()
    assert result == {"has_tools": False}


# ---------------------------------------------------------------------------
# _extract_fallback_model
# ---------------------------------------------------------------------------


def test_fallback_model_from_kwargs() -> None:
    assert _extract_fallback_model("google", (), {"model": "gemini-2.5-pro"}) == "gemini-2.5-pro"


def test_fallback_model_returns_empty_when_missing() -> None:
    assert _extract_fallback_model("google", (), {}) == ""
