"""Unit tests for ``sp.wrap(deepgram_client)`` standalone wrapping.

Uses lightweight fake classes whose ``__module__`` is set to
``"deepgram.fake"`` so ``_detect_provider`` finds them. The real
``deepgram-sdk`` is NOT a test dependency.

Coverage:
  * Sync transcribe_url → one deepgram row with audio_seconds + cost.
  * Async transcribe_url → same shape, awaited path.
  * transcribe_file (sync) → identical contract.
  * Multilingual model_info → routes to the multilingual SKU.
  * model from PrerecordedOptions when response lacks model_info.
  * Exception path → submits a status_code != 200 row with audio_seconds=0.
  * Default metadata fans out to known attribution columns + custom_tags.
  * Empty/missing duration → row still emitted with audio_seconds=0
    (cost=0; the dashboard counts the request for error/latency).
"""

from __future__ import annotations

import asyncio
from types import SimpleNamespace
from typing import Any

import pytest

import superpenguin


# ---------------------------------------------------------------------------
# Capturing client (same pattern as test_voice.py)
# ---------------------------------------------------------------------------


class _CapturingClient:
    def __init__(self) -> None:
        self.events: list[dict[str, Any]] = []

    def submit(self, event: dict[str, Any]) -> None:
        self.events.append(event)


@pytest.fixture(autouse=True)
def _swap_client(monkeypatch: pytest.MonkeyPatch) -> _CapturingClient:
    fake = _CapturingClient()
    monkeypatch.setattr(superpenguin, "_client", fake)
    return fake


# ---------------------------------------------------------------------------
# Fake Deepgram SDK shapes
# ---------------------------------------------------------------------------


class _FakeVersionedRest:
    """Mimics ``client.listen.rest.v("1")`` — exposes transcribe_url /
    transcribe_file methods returning whatever the test set as the
    next response. Methods are real instance methods so the wrap
    machinery can replace them."""

    def __init__(self) -> None:
        self._next_response: Any = None
        self._next_exception: Exception | None = None
        self.last_args: tuple[Any, ...] = ()
        self.last_kwargs: dict[str, Any] = {}

    def set_response(self, response: Any) -> None:
        self._next_response = response
        self._next_exception = None

    def set_exception(self, exc: Exception) -> None:
        self._next_exception = exc
        self._next_response = None

    def transcribe_url(self, *args: Any, **kwargs: Any) -> Any:
        self.last_args = args
        self.last_kwargs = kwargs
        if self._next_exception is not None:
            raise self._next_exception
        return self._next_response

    def transcribe_file(self, *args: Any, **kwargs: Any) -> Any:
        self.last_args = args
        self.last_kwargs = kwargs
        if self._next_exception is not None:
            raise self._next_exception
        return self._next_response


class _FakeAsyncVersionedRest:
    """Async equivalent for the asyncrest tree."""

    def __init__(self) -> None:
        self._next_response: Any = None
        self._next_exception: Exception | None = None

    def set_response(self, response: Any) -> None:
        self._next_response = response
        self._next_exception = None

    def set_exception(self, exc: Exception) -> None:
        self._next_exception = exc
        self._next_response = None

    async def transcribe_url(self, *args: Any, **kwargs: Any) -> Any:
        if self._next_exception is not None:
            raise self._next_exception
        return self._next_response

    async def transcribe_file(self, *args: Any, **kwargs: Any) -> Any:
        if self._next_exception is not None:
            raise self._next_exception
        return self._next_response


class _FakeRest:
    """Mimics ``client.listen.rest`` (or ``client.listen.asyncrest``) —
    exposes a ``v(version)`` factory returning the versioned object."""

    def __init__(self, versioned: Any) -> None:
        self._versioned = versioned

    def v(self, version: str) -> Any:
        return self._versioned


class _FakeListen:
    def __init__(self, rest: _FakeRest, asyncrest: _FakeRest | None = None) -> None:
        self.rest = rest
        if asyncrest is not None:
            self.asyncrest = asyncrest


class _FakeDeepgramClient:
    def __init__(
        self,
        rest: _FakeRest,
        asyncrest: _FakeRest | None = None,
    ) -> None:
        self.listen = _FakeListen(rest, asyncrest)


# Force the detector to recognize these as Deepgram clients regardless
# of where this test module physically lives. _detect_provider keys off
# type(client).__module__.
for cls in (
    _FakeDeepgramClient, _FakeListen, _FakeRest,
    _FakeVersionedRest, _FakeAsyncVersionedRest,
):
    cls.__module__ = "deepgram.fake"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _build_response(
    duration: float = 10.0,
    model_name: str = "nova-3",
    multilingual: bool = False,
) -> SimpleNamespace:
    """Build a Deepgram-style response with metadata.duration + model_info."""
    model_info = {
        "uuid-1": SimpleNamespace(
            name=model_name,
            arch="multi" if multilingual else "general",
            multilingual=multilingual,
        ),
    }
    return SimpleNamespace(
        metadata=SimpleNamespace(duration=duration, model_info=model_info),
    )


def _build_options(model: str = "nova-3") -> SimpleNamespace:
    """Stand-in for PrerecordedOptions."""
    return SimpleNamespace(model=model)


def _make_sync_client() -> tuple[_FakeDeepgramClient, _FakeVersionedRest]:
    versioned = _FakeVersionedRest()
    rest = _FakeRest(versioned)
    client = _FakeDeepgramClient(rest)
    return client, versioned


def _make_async_client() -> tuple[_FakeDeepgramClient, _FakeAsyncVersionedRest]:
    async_versioned = _FakeAsyncVersionedRest()
    asyncrest = _FakeRest(async_versioned)
    # Sync rest still needed so the wrap call patches both trees.
    sync_rest = _FakeRest(_FakeVersionedRest())
    client = _FakeDeepgramClient(sync_rest, asyncrest=asyncrest)
    return client, async_versioned


# ---------------------------------------------------------------------------
# Sync transcribe_url
# ---------------------------------------------------------------------------


def test_sync_transcribe_url_emits_one_row(_swap_client: _CapturingClient) -> None:
    client, versioned = _make_sync_client()
    superpenguin.wrap(client, metadata={"customer_id": "acme", "feature": "calls"})
    versioned.set_response(_build_response(duration=12.5, model_name="nova-3"))

    result = client.listen.rest.v("1").transcribe_url(
        {"url": "https://example.com/a.wav"},
        _build_options("nova-3"),
    )

    assert result is not None
    assert len(_swap_client.events) == 1
    row = _swap_client.events[0]
    assert row["provider"] == "deepgram"
    # transcribe_url is HTTP REST → pre-recorded SKU (~44% cheaper than
    # the streaming WebSocket SKU).
    assert row["model"] == "deepgram/nova-3-monolingual-prerecorded"
    assert row["modality"] == "audio_in"
    assert row["audio_seconds"] == 12.5
    assert row["status_code"] == 200
    assert row["customer_id"] == "acme"
    assert row["feature"] == "calls"
    # Pre-recorded Nova-3 monolingual: $0.0043/min = 0.00007166/s.
    # 12.5s * 0.00007166 = $0.000896 ≈ 896 micros.
    assert row["cost_usd_micros"] == pytest.approx(896, abs=2)


def test_sync_transcribe_url_options_kwarg_form(_swap_client: _CapturingClient) -> None:
    """Some user code passes ``options=`` as a keyword. Verify both shapes
    produce identical rows so the kwarg-vs-positional ambiguity in
    Deepgram's API doesn't drift the cost."""
    client, versioned = _make_sync_client()
    superpenguin.wrap(client)
    versioned.set_response(_build_response(duration=4.0))

    client.listen.rest.v("1").transcribe_url(
        {"url": "https://example.com/a.wav"},
        options=_build_options("nova-3"),
    )

    assert len(_swap_client.events) == 1
    assert _swap_client.events[0]["audio_seconds"] == 4.0


def test_sync_transcribe_file_emits_row(_swap_client: _CapturingClient) -> None:
    client, versioned = _make_sync_client()
    superpenguin.wrap(client)
    versioned.set_response(_build_response(duration=7.0))

    client.listen.rest.v("1").transcribe_file(
        b"\x00\x01\x02",
        _build_options("nova-3"),
    )

    assert len(_swap_client.events) == 1
    row = _swap_client.events[0]
    assert row["model"] == "deepgram/nova-3-monolingual-prerecorded"
    assert row["audio_seconds"] == 7.0


# ---------------------------------------------------------------------------
# Multilingual routing
# ---------------------------------------------------------------------------


def test_multilingual_response_routes_to_multilingual_sku(
    _swap_client: _CapturingClient,
) -> None:
    client, versioned = _make_sync_client()
    superpenguin.wrap(client)
    versioned.set_response(
        _build_response(duration=10.0, model_name="nova-3", multilingual=True),
    )

    client.listen.rest.v("1").transcribe_url({"url": "..."}, _build_options())

    row = _swap_client.events[0]
    # Multilingual + pre-recorded.
    assert row["model"] == "deepgram/nova-3-multilingual-prerecorded"
    # Pre-recorded multilingual: $0.0052/min = 0.00008666/s.
    # 10s * 0.00008666 = $0.0008666 ≈ 867 micros.
    assert row["cost_usd_micros"] == pytest.approx(867, abs=2)


# ---------------------------------------------------------------------------
# Model fallback from options when response lacks model_info
# ---------------------------------------------------------------------------


def test_model_falls_back_to_options_when_response_missing(
    _swap_client: _CapturingClient,
) -> None:
    client, versioned = _make_sync_client()
    superpenguin.wrap(client)
    # Response with duration but no model_info.
    versioned.set_response(
        SimpleNamespace(metadata=SimpleNamespace(duration=5.0, model_info=None)),
    )

    client.listen.rest.v("1").transcribe_url({"url": "..."}, _build_options("nova-3"))

    row = _swap_client.events[0]
    # No multilingual signal in the response → defaults to monolingual,
    # plus the -prerecorded suffix because we're on transcribe_url.
    assert row["model"] == "deepgram/nova-3-monolingual-prerecorded"
    assert row["audio_seconds"] == 5.0


# ---------------------------------------------------------------------------
# Async path
# ---------------------------------------------------------------------------


def test_async_transcribe_url_emits_row(_swap_client: _CapturingClient) -> None:
    client, async_versioned = _make_async_client()
    superpenguin.wrap(client, metadata={"team": "platform"})
    async_versioned.set_response(_build_response(duration=8.0))

    asyncio.run(
        client.listen.asyncrest.v("1").transcribe_url(
            {"url": "https://x.example/a.wav"}, _build_options(),
        )
    )

    assert len(_swap_client.events) == 1
    row = _swap_client.events[0]
    assert row["provider"] == "deepgram"
    assert row["audio_seconds"] == 8.0
    assert row["team"] == "platform"


# ---------------------------------------------------------------------------
# Error path
# ---------------------------------------------------------------------------


class _DeepgramHTTPError(Exception):
    status_code = 429


def test_exception_emits_error_row_and_reraises(
    _swap_client: _CapturingClient,
) -> None:
    client, versioned = _make_sync_client()
    superpenguin.wrap(client)
    versioned.set_exception(_DeepgramHTTPError("rate limited"))

    with pytest.raises(_DeepgramHTTPError):
        client.listen.rest.v("1").transcribe_url({"url": "..."}, _build_options())

    assert len(_swap_client.events) == 1
    row = _swap_client.events[0]
    assert row["status_code"] == 429
    assert row["audio_seconds"] == 0.0
    assert row["cost_usd_micros"] == 0


# ---------------------------------------------------------------------------
# Idempotency: double-wrap should not double-patch
# ---------------------------------------------------------------------------


def test_double_wrap_is_idempotent(_swap_client: _CapturingClient) -> None:
    client, versioned = _make_sync_client()
    superpenguin.wrap(client)
    superpenguin.wrap(client)  # second call must be a no-op
    versioned.set_response(_build_response(duration=2.0))

    client.listen.rest.v("1").transcribe_url({"url": "..."}, _build_options())

    # Exactly ONE row, not two — the second wrap must not re-patch.
    assert len(_swap_client.events) == 1


# ---------------------------------------------------------------------------
# Tier override
# ---------------------------------------------------------------------------


def test_growth_tier_routes_to_discounted_sku(
    _swap_client: _CapturingClient,
) -> None:
    """Customers on Deepgram's Growth plan ($4K+/yr commitment) get a
    ~16% discount across all SKUs. Passing ``tier="growth"`` to
    ``sp.wrap()`` should land the row on the ``-growth`` slug so the
    dashboard prices against the discounted rate card."""
    client, versioned = _make_sync_client()
    superpenguin.wrap(client, tier="growth")
    versioned.set_response(_build_response(duration=10.0))

    client.listen.rest.v("1").transcribe_url({"url": "..."}, _build_options())

    row = _swap_client.events[0]
    assert row["model"] == "deepgram/nova-3-monolingual-prerecorded-growth"
    # Growth pre-recorded monolingual: $0.0036/min = 0.00006/s.
    # 10s * 0.00006 = $0.0006 = 600 micros.
    assert row["cost_usd_micros"] == 600


# ---------------------------------------------------------------------------
# Module-detection sanity
# ---------------------------------------------------------------------------


def test_detect_provider_recognizes_deepgram() -> None:
    from superpenguin._wrap import _detect_provider

    client, _ = _make_sync_client()
    assert _detect_provider(client) == "deepgram"
