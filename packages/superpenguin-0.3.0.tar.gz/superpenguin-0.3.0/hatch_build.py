"""Hatch build hook: stage pricing/models.json into the package tree.

Why this exists
---------------
The canonical pricing data lives at the monorepo root in
``pricing/models.json``. We want every published wheel to ship a copy of it
at ``superpenguin/data/models.json`` so customer installs can load pricing
without depending on the original repo layout.

Naively configuring ``[tool.hatch.build.targets.wheel.force-include]`` to
copy ``../../pricing/models.json`` works when building from the monorepo but
*fails* when pip builds a wheel from a previously-published sdist — the sdist
has its own root and ``../../pricing/models.json`` resolves to a directory
that doesn't exist in the extracted tarball.

This build hook resolves the source from either location (monorepo dev or
extracted-sdist root) and copies it into ``src/superpenguin/data/models.json``
before packaging. Wheel + sdist + editable build targets then pick up the
staged file automatically through ``packages = ["src/superpenguin"]`` plus
the wheel's ``force-include`` shim that bypasses the .gitignore entry.

Editable installs are also staged
---------------------------------
We used to skip editable builds (to avoid shadowing in-place edits to the
monorepo's ``pricing/models.json``), but that broke ``uv run pytest`` /
``pip install -e .`` because the wheel target's ``force-include`` requires
``src/superpenguin/data/models.json`` to exist *at install time*, even for
editable installs. Skipping the hook left the file missing, the install
crashed, and the test suite couldn't even start.

The shadowing risk is now mitigated by the runtime loader
(``_pricing._load_pricing_data``), which prefers the monorepo-root
``pricing/models.json`` when one is reachable via walk-up. So editable
developers always see the latest source-of-truth pricing even though a
(potentially stale) staged copy exists alongside the package.
"""

from __future__ import annotations

import shutil
from pathlib import Path
from typing import Any

from hatchling.builders.hooks.plugin.interface import BuildHookInterface


class CopyPricingDataHook(BuildHookInterface):
    PLUGIN_NAME = "copy-pricing-data"

    def initialize(self, version: str, build_data: dict[str, Any]) -> None:
        root = Path(self.root)
        candidates = [
            root / ".." / ".." / "pricing" / "models.json",
            root / "pricing" / "models.json",
        ]
        src = next((c for c in candidates if c.is_file()), None)
        if src is None:
            tried = ", ".join(str(c.resolve()) for c in candidates)
            raise FileNotFoundError(
                f"superpenguin build hook: could not find pricing/models.json. "
                f"Tried: {tried}. Run from the cost-management monorepo or use "
                "an sdist that bundles pricing/models.json at its root."
            )

        dst = root / "src" / "superpenguin" / "data" / "models.json"
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(src, dst)
