# Changelog

All notable changes to the `superpenguin` Python SDK are documented here.

The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and the project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.3.0] — 2026-04-20

### Added

- **`sp.wrap(deepgram_client)` — standalone Deepgram (STT) tracking.** Auto-detects the `deepgram-sdk` client and patches `client.listen.rest.v(...).transcribe_url` / `transcribe_file` (sync + async). Every call submits one `request_logs` row with `provider="deepgram"`, `audio_seconds` from `response.metadata.duration`, and the canonical model SKU resolved from `response.metadata.model_info`.
  - **SKU routing covers all four Deepgram billing axes**: engine variant (Nova-3 / Nova-2 + mono- vs multi-lingual), API endpoint (always `-prerecorded` for the wrapped REST methods — ~44% cheaper than the streaming SKU), and commitment tier. Pass `tier="growth"` to `sp.wrap()` to route rows to the discounted Growth-plan slugs (e.g. `deepgram/nova-3-monolingual-prerecorded-growth`).
  - **Failed-request rows**: exceptions still emit a row with `status_code != 200`, `audio_seconds=0`, `cost_usd_micros=0` so error-rate dashboards stay accurate without polluting cost.
  - **Optional dependency**: `pip install superpenguin[deepgram]` pulls `deepgram-sdk>=3.0.0`. The wrapper itself is lazily imported only when `sp.wrap()` sees a Deepgram client, so apps that don't use Deepgram pay no import cost.
  - **Out of scope (planned)**: live WebSocket STT, callback-mode async transcribe, Deepgram TTS (`speak.rest`), Voice Agent API.
- **`sp.wrap(elevenlabs_client)` — standalone ElevenLabs (TTS) tracking.** Auto-detects the `elevenlabs` SDK client (sync + `AsyncElevenLabs`) and patches `text_to_speech.convert`, `text_to_speech.convert_as_stream`, and `text_to_sound_effects.convert`. Each call submits one `request_logs` row with `provider="elevenlabs"`, `characters = len(text)`, and the canonical `elevenlabs/<model_id>` slug.
  - **Stream wrapping**: `convert_as_stream` returns a transparent proxy that submits the row when consumption finishes (so `latency_ms` reflects time-to-completion, not time-to-iterator-construction). The cost is fixed at `len(text)` regardless.
  - **Failed-request rows**: exceptions emit a row with `status_code != 200` and `cost_usd_micros = 0` (ElevenLabs doesn't bill failed synthesis), preserving error-rate dashboards without affecting cost.
  - **Optional dependency**: `pip install superpenguin[elevenlabs]` pulls `elevenlabs>=1.0.0`.
  - **Out of scope (planned)**: real-time WebSocket TTS (`text_to_speech.stream`), Speech-to-Speech, Voice Changer.
- **`sp.wrap()` now accepts `**provider_kwargs`** for provider-specific options. `tier="growth"` is the first such kwarg (Deepgram only). Unknown kwargs raise `TypeError` for non-voice providers, so a typo on an OpenAI/Anthropic/Google client still fails loud.
- **`superpenguin._voice_submit.submit_voice_event`** — internal shared helper that all three voice paths (LiveKit shim, Deepgram standalone, ElevenLabs standalone) submit through. Keeps the per-row event shape on a single canonical contract with the `/api/sdk/ingest` endpoint, so future voice providers (AssemblyAI, Cartesia, etc.) can compose into the same helper instead of forking the row shape.
- **`pip install superpenguin[voice]`** convenience extra installs all three voice integrations (`deepgram-sdk`, `elevenlabs`, `livekit-agents`) in one step.
- **`superpenguin.voice.LiveKitObservability`** — a one-line observability shim for [LiveKit Agents](https://docs.livekit.io/agents/) voice pipelines. Wire `obs.on_metrics` into `session.on("metrics_collected")` and the agent's per-turn Deepgram (STT) and ElevenLabs (TTS) usage is captured straight from LiveKit's own `MetricsCollectedEvent` stream; call `obs.on_session_end(duration_seconds=...)` when the call ends to emit the LiveKit `agent-session-minute` and `observability-event` rows.
  - **Cross-provider correlation**: every emitted row carries the same `session_id`, so the dashboard joins Deepgram + LLM + ElevenLabs + LiveKit rows back into a single voice call.
  - **Idempotent**: rows are keyed `f"{session_id}:{kind}:{request_id_or_seq}"`, so an SDK retry maps to the same row server-side via `idx_request_logs_idempotency`.
  - **No double-count with `sp.wrap()`**: `LLMMetrics` events are intentionally a no-op in the shim. The LLM call is already captured by the wrapped client with full token/cache/tool detail.
  - **Subscription quotas are NOT applied per-row** — per-call costing has no view of monthly aggregation. The dashboard subtracts `subscription_tiers[tier].included_units` from the monthly sum before applying the per-unit overage rate, against the tier auto-detected from the Connect-Provider integration.
  - Imported via the submodule: `from superpenguin.voice import LiveKitObservability`. The shim has no `livekit-agents` import — it duck-types the metric subtype names — so it adds no runtime dependency to apps that don't use LiveKit.
- **`calculate_unit_cost_micros(model, units, *, as_of=None)`** in `superpenguin._pricing` — a non-token cost calculator covering the new billing units (`audio_seconds`, `characters`, `events`, `flat_monthly`, `audio_minutes`, `images`, `requests`, `data_gb`). Mirrors the rate-card semantics (effective-dated, tier-threshold-aware) of the existing token-only `calculate_cost_micros`. Used by the voice shim to cost STT audio-seconds, TTS characters, and the per-session LiveKit rows; available for direct calls if you want to estimate non-LLM costs from your own telemetry.
- **Voice pricing entries** seeded into the unified `pricing/models.json` source of truth: Deepgram Nova-3 (monolingual + multilingual), ElevenLabs Flash v2.5 + v3, and LiveKit `agent-session-minute` / `observability-event`. The dashboard server (`src/lib/pricing.ts`) loads the same file, so SDK and dashboard stay in lockstep on rates.
- **`@sp.trace(metadata={...})` now actually propagates metadata to wrapped client calls.** A new `current_trace_metadata` `ContextVar` is set on entry and reset on exit (also on exception). Every wrapped client call inside the decorated function — on **any** provider, including Gemini, Deepgram, and ElevenLabs whose SDKs don't accept `extra_body` — merges trace metadata on top of `sp.wrap(metadata=...)` defaults. Per-call `extra_body` / `metadata=` kwargs still win on top. Verified by 10 new tests in `test_trace_metadata.py`, including an end-to-end Deepgram integration test.
- **`sp.metadata({...})` context manager** for block-scoped per-request attribution on providers whose SDK has no `extra_body` hook (Gemini, Deepgram, ElevenLabs). Layers on top of any active `@sp.trace` metadata; reset on exit. Lets you compute `customer_id` (or any other field) per request without restructuring code into a function:
  ```python
  with sp.metadata({"customer_id": cust_id}):
      audio = el.text_to_speech.convert(...)
  ```
- **`superpenguin._context.merged_metadata(wrap_default, call_meta)`** — single canonical merger used by every code path (`_wrap`, `_litellm`, `_voice_submit`). Enforces the documented precedence: `wrap-time defaults < @sp.trace / sp.metadata() < per-call override`.

### Notes

- LiveKit does not publish a billing or usage API. The voice shim is the **only** path that produces LiveKit cost rows in the dashboard. The Connect-Provider entry for LiveKit exists purely to store the credential triple (URL + key + secret) for future control-plane operations and to render "LiveKit · connected" alongside other providers.
- Deepgram and ElevenLabs now have **three integration paths**:
  1. **Server-pull** (Connect Provider) — daily aggregates from the provider's billing API. Coarse, no per-call attribution.
  2. **Standalone `sp.wrap()`** — per-call rows with full latency and metadata. Use when you call Deepgram/ElevenLabs directly from a backend service.
  3. **`LiveKitObservability` shim** — per-turn rows from LiveKit's `MetricsCollectedEvent` stream. Use when you run inside `livekit-agents`.
- **Don't combine paths 2 and 3 on the same client**: both would emit a row for the same audio and double the cost. In practice LiveKit Agents constructs its own internal Deepgram/ElevenLabs clients that you don't hold a reference to, so natural separation is the norm.
- **Per-call metadata override on standalone Deepgram/ElevenLabs/Gemini wrappers** is now supported via `@sp.trace(metadata={...})` (function scope) or `with sp.metadata({...}):` (block scope), both of which work on any provider regardless of whether the underlying SDK accepts `extra_body`. See the per-call overrides section on `/docs`.
- **`voice.py::_submit_row` was refactored** to delegate to `_voice_submit.submit_voice_event`. The public `LiveKitObservability` API is unchanged; existing call sites need no edits.

## [0.2.2] — 2026-04-20

### Changed

- **Pricing data is now loaded from the unified `pricing/models.json`** source of truth at the cost-management monorepo root, replacing the hand-maintained `_MODEL_PRICING` dict that lived in `_pricing.py`. The dashboard server (`src/lib/pricing.ts`) loads the same file, so the SDK and dashboard can no longer drift on model rates.
  - Wheels and sdists ship a bundled copy at `superpenguin/data/models.json` (built by a custom hatch hook). Editable installs (`pip install -e .`) skip the staging step and the runtime loader walks up to find the live monorepo copy, so local edits to `pricing/models.json` are picked up immediately without a reinstall.
  - The schema is **versioned by effective date**: every model has a `rate_cards` array with `effective_from` (and optional `effective_until`) timestamps. Future provider price changes append a new card instead of mutating the old one, so historical `provider_usage_records` rows can re-cost themselves against the rate that was actually in effect when the request happened. See `pricing/README.md` for the runbooks.
- **Cache-rate convention: NO heuristic fallback.** When a model entry omits `cache_read` (or any other rate leg), the calculator now resolves it to **0** rather than using the previous `input_rate × 0.5` heuristic. The heuristic was wrong for several OpenAI models — e.g. `gpt-4.1`'s actual cached_input is $0.50/1M but the heuristic produced $1.00/1M, silently inflating cost reports for cache-heavy workloads. Every model that supports caching now records an explicit `cache_read`; models that do not (the OpenAI Pro family) record `null`.

### Added

- **`as_of: datetime | None`** keyword-only parameter on `calculate_cost_micros` to select the rate card in effect at a given timestamp. Omit (default) to use the current (latest) card. Naive datetimes are treated as UTC.
- **`gemini-2.5-flash` updated to Google's stable unified rate.** Google retired the preview-period thinking-disabled vs thinking-enabled rate split in June 2025 and unified at $0.30 input / $2.50 output / $0.03 cache_read per 1M regardless of reasoning mode. The previous SDK encoded the (now-defunct) thinking-disabled preview rates as the default, undercharging input by 2x and output by ~4x for every gemini-2.5-flash row issued after June 2025. The `rate_variants.thinking` field has been removed since the distinction no longer exists. Verified against `https://ai.google.dev/gemini-api/docs/pricing` on 2026-04-20.
- **OpenAI GPT-5 family completed.** Five models that were missing from the previous table are now included, all verified against `https://platform.openai.com/docs/pricing` on 2026-04-20:
  - `gpt-5.4-pro` — input $30 / output $180 per 1M (≤272K), $60 / $270 (>272K). No prompt caching offered.
  - `gpt-5.2` — input $1.75 / cached $0.175 / output $14 per 1M.
  - `gpt-5.2-pro` — input $21 / output $168 per 1M. No prompt caching offered.
  - `gpt-5.1` — input $1.25 / cached $0.125 / output $10 per 1M (same published rates as `gpt-5`, distinct API id).
  - `gpt-5-pro` — input $15 / output $120 per 1M. No prompt caching offered.
- **`gpt-5.4` long-context tiering.** Added `tier_threshold: { field: "input_tokens", value: 272000 }` with `[low, high]` rate arrays so the calculator picks the correct rate when a single request exceeds 272K input tokens. Low tier matches the previous flat values ($2.50 / $0.25 / $15 per 1M); high tier is $5.00 / $0.50 / $22.50 per 1M.

### Fixed

- **`_normalize_model` no longer over-strips `text-embedding-ada-002`.** The version-pin regex (`-\d{3}$`, intended for Vertex AI suffixes like `gemini-2.0-flash-001`) was greedily turning `text-embedding-ada-002` into `text-embedding-ada` and dropping the cost calculation to $0. The normalizer now tries progressively-aggressive suffix strips and returns the first candidate that resolves to a known model. Behavior for previously-handled models (e.g. `gemini-2.0-flash-001 → gemini-2.0-flash`) is unchanged.
- **`gemini-2.5-flash` rate (re)corrected to Google's stable unified rate.** An interim version of the unified pricing migration encoded the preview-period thinking-disabled rates as the default ($0.15 input / $0.60 output). Both the preview thinking-disabled AND preview thinking-enabled tiers were retired by Google in June 2025 in favor of a single unified $0.30 / $2.50 / $0.03 per 1M rate that applies regardless of reasoning mode. The 0.2.2 release ships with the unified rate.
- **Cached-input rates corrected for several OpenAI models** that previously fell through to the (wrong) `input_rate × 0.5` heuristic. Any caller passing `cached_tokens > 0` for these models was being over-charged on the cached portion. Net direction: cache-heavy workloads on these models will now report **lower** cost going forward.
  - `gpt-4.1`: heuristic $1.00 → actual **$0.50** per 1M
  - `gpt-4.1-mini`: heuristic $0.20 → actual **$0.10** per 1M
  - `gpt-4.1-nano`: heuristic $0.05 → actual **$0.025** per 1M
  - `o3`: heuristic $1.00 → actual **$0.50** per 1M
  - `o4-mini`: heuristic $0.55 → actual **$0.275** per 1M
  - (`gpt-4o` and `gpt-4o-mini` heuristic happened to coincide with OpenAI's published rate, so values are unchanged but `cache_read` is now explicit.)

### Notes

- The SDK's public API is unchanged; only the internal pricing-data loading mechanism moved. `_MODEL_PRICING`, `_MODEL_ALIASES`, `_warned_unknown_models`, `_normalize_model`, and `calculate_cost_micros` remain importable with their existing shapes (the legacy `_MODEL_PRICING` dict is now built at import time from `pricing/models.json`).
- `gemini-2.0-pro` was removed from the table — it was never published by Google (Gemini 2.0 launched as Flash-only) and the previous server-only entry was almost certainly erroneous. If real usage rows reference it, the existing unknown-model Slack alert will fire.

## [0.2.1] — 2026-04-20

### Added

- **Pricing entries for OpenAI embedding models** (input-only, no completion tokens, no caching). Source: https://platform.openai.com/docs/pricing#embeddings (verified 2026-04-20):
  - `text-embedding-3-small` — $0.02 / 1M tokens
  - `text-embedding-3-large` — $0.13 / 1M tokens
  - `text-embedding-ada-002` — $0.10 / 1M tokens
- **Pricing entries for OpenAI transcription models** — pre-positioned for symmetry with the dashboard's pricing table and to prevent future silent regressions when transcribe wrapping is added. Source: https://platform.openai.com/docs/pricing#transcription (verified 2026-04-20):
  - `gpt-4o-transcribe` — input $2.50 / output $10.00 per 1M tokens
  - `gpt-4o-mini-transcribe` — input $1.25 / output $5.00 per 1M tokens

### Notes

- `sp.wrap()` already patches the OpenAI `embeddings` resource (since 0.1.0). Before this release, embedding calls flowed through to the dashboard with `cost_usd_micros = 0`, which silently zeroed embedding spend on per-customer / per-feature breakdowns and triggered an "unknown model pricing" Slack alert via the dashboard's ingest route. After upgrading, embedding calls report cost correctly inline.
- Audio transcription is NOT yet wrapped by `sp.wrap()` — `_OPENAI_RESOURCES` does not include `audio.transcriptions`, so a transcribe call passes straight through and never reaches the SDK pipeline. Transcribe spend continues to flow exclusively via the OpenAI billing-API sync. The transcribe rates are added now so that whenever transcribe wrapping ships, the cost calculation is already correct on day one.
- Note that transcribe rates are very different from the chat-completion `gpt-4o` / `gpt-4o-mini` SKUs ($2.50/$10.00 vs $2.50/$10.00 for the full size — same coincidentally — but $1.25/$5.00 vs $0.15/$0.60 for mini, an ~8× difference). Don't collapse `-transcribe` via model normalization or aliasing.

## [0.2.0] — 2026-04-18

### Added

- **Google Gemini support** via the unified [`google-genai`](https://github.com/googleapis/python-genai) client (works against both AI Studio and Vertex AI).
  - `sp.wrap(genai.Client(...))` patches `client.models.generate_content`, `generate_content_stream`, and their async equivalents under `client.aio.models.*`.
  - Token counts, cached tokens, latency, tool-call detection, and `model_version` are extracted from both single-shot and streaming responses.
  - New `[google]` install extra: `pip install "superpenguin[google]"`.
- **Pricing table for Gemini text models** (Standard tier, verified against `https://ai.google.dev/gemini-api/docs/pricing` on 2026-04-16):
  - `gemini-3.1-pro-preview` (tiered at 200k input tokens)
  - `gemini-3.1-flash-lite-preview`
  - `gemini-3-flash-preview`
  - `gemini-2.5-pro` (tiered at 200k input tokens), `gemini-2.5-flash`, `gemini-2.5-flash-lite`
  - `gemini-2.0-flash`, `gemini-2.0-flash-lite`
- **Tiered pricing engine**: per-rate `[low, high]` lists paired with `tier_threshold` (in input tokens) so Gemini Pro SKUs bill the right rate above/below the long-context threshold.
- **Model alias map** (`_MODEL_ALIASES`) so stable names like `gemini-3.1-pro` resolve to the canonical `-preview` SKU.
- **Smarter model normalization**: in addition to ISO date suffixes (`-2025-09-15`, `-20250915`), the SDK now strips Google month-year suffixes (`-09-2025`) and Vertex version pins (`-001`, `-002`) before pricing lookup.
- `gemini` and `google` added to the package keyword list.

### Notes

- Audio and image input modalities for Gemini are billed separately by Google. The SDK currently tracks the text rate only — audio-heavy workloads will be under-counted by the SDK estimator (provider-side billing is unaffected).
- Batch / Flex / Priority Gemini tiers are not yet modeled; pricing assumes the paid Standard tier.

## [0.1.0] — 2026-04-11

Initial public release.

### Added

- `sp.init()`, `sp.wrap()`, `sp.flush()`, and the `@sp.trace` decorator.
- OpenAI client support (`chat.completions`, `completions`, `embeddings`, `responses`), including streaming.
- Anthropic client support (`messages`), including streaming.
- LiteLLM patching via `sp.patch_litellm()`.
- Background batched HTTP submission to `https://api.carrotlabs.ai/api/sdk/ingest` with `atexit` flush.
- Per-call attribution metadata (`customer_id`, `feature`, `team`, `environment`, `prompt_key`, `prompt_version`, plus arbitrary string custom tags).
