"""Tests for fastapi-refine."""
