# ======================================== IMPORTS ========================================
from __future__ import annotations

from ....math import Vector

from typing import Callable, NamedTuple
from math import cos, sin, atan2, radians
import numpy as np
from numpy.typing import NDArray

# ======================================== CONTACT ========================================
class Contact(NamedTuple):
    """
    Résultat d'une détection de collision

    Convention : normal pointe de B vers A (pousse A hors de B)
    """
    normal: Vector
    depth: float

# ======================================== REGISTRY ========================================
_handlers: dict[tuple[type, type], Callable] = {}

def register(type_a: type, type_b: type):
    """Décore une fonction de narrowphase pour la paire (type_a, type_b)"""
    def decorator(fn: Callable) -> Callable:
        _handlers[(type_a, type_b)] = fn
        return fn
    return decorator

def dispatch(sa, ax, ay, scale_a, rot_a, sb, bx, by, scale_b, rot_b) -> Contact | None:
    """Dispatche vers le bon handler de narrowphase"""
    from ._narrow_phase import dispatch as _np_dispatch
    return _np_dispatch(sa, ax, ay, scale_a, rot_a, sb, bx, by, scale_b, rot_b)

def world_center(shape, tr, offset) -> tuple[float, float]:
    """Calcule le centre géométrique monde depuis transform, bounding_box et offset"""
    x_min, y_min, x_max, y_max = shape.bounding_box

    # Anchor en espace local
    local_ax = x_min + tr.anchor.x * (x_max - x_min)
    local_ay = y_min + tr.anchor.y * (y_max - y_min)

    # Scale + rotation de l'anchor
    rad = radians(-tr.rotation)
    cos_r, sin_r = cos(rad), sin(rad)
    scaled_ax = local_ax * tr.scale
    scaled_ay = local_ay * tr.scale
    rotated_ax = scaled_ax * cos_r - scaled_ay * sin_r
    rotated_ay = scaled_ax * sin_r + scaled_ay * cos_r

    # Centre monde
    return (
        tr.x - rotated_ax + offset[0] * tr.scale,
        tr.y - rotated_ay + offset[1] * tr.scale,
    )

# ======================================== HELPERS GÉOMÉTRIQUES ========================================
def closest_pt_on_seg(sx, sy, sdx, sdy, px, py) -> tuple[float, float]:
    """Point le plus proche de (px,py) sur le segment (sx,sy) -> (sx+sdx,sy+sdy)"""
    len_sq = sdx * sdx + sdy * sdy
    if len_sq < 1e-10:
        return sx, sy
    t = max(0.0, min(1.0, ((px - sx) * sdx + (py - sy) * sdy) / len_sq))
    return sx + t * sdx, sy + t * sdy

def closest_pt_seg_to_seg(ax, ay, adx, ady, bx, by, bdx, bdy) -> tuple[float, float]:
    """Point le plus proche sur le segment A du segment B"""
    a_len_sq = adx * adx + ady * ady
    b_len_sq = bdx * bdx + bdy * bdy
    rx, ry = ax - bx, ay - by
    e = rx * bdx + ry * bdy
    f = adx * bdx + ady * bdy

    if a_len_sq < 1e-10 and b_len_sq < 1e-10:
        return ax, ay
    if a_len_sq < 1e-10:
        s = max(0.0, min(1.0, e / b_len_sq))
        return bx + s * bdx, by + s * bdy
    c = rx * adx + ry * ady
    if b_len_sq < 1e-10:
        t = max(0.0, min(1.0, -c / a_len_sq))
        return ax + t * adx, ay + t * ady
    denom = a_len_sq * b_len_sq - f * f
    t = max(0.0, min(1.0, (f * e - c * b_len_sq) / denom)) if abs(denom) > 1e-10 else 0.0
    s = max(0.0, min(1.0, (f * t + e) / b_len_sq))
    t = max(0.0, min(1.0, (f * s - c) / a_len_sq))
    return ax + t * adx, ay + t * ady

def closest_pt_on_ellipse(cx, cy, rx, ry, px, py) -> tuple[float, float]:
    """Point le plus proche sur l'ellipse (cx,cy,rx,ry) du point (px,py)"""
    lx = px - cx
    ly = py - cy
    if abs(lx) < 1e-12 and abs(ly) < 1e-12:
        return cx + rx, cy
    t = atan2(ly * rx, lx * ry)
    for _ in range(25):
        ct, st = cos(t), sin(t)
        ex2 = rx * ct
        ey2 = ry * st
        f = -rx * st * (ex2 - lx) + ry * ct * (ey2 - ly)
        fp = (-rx * ct * (ex2 - lx) + rx * rx * st * st
              - ry * st * (ey2 - ly) + ry * ry * ct * ct)
        if abs(fp) < 1e-12:
            break
        delta = f / fp
        t -= delta
        if abs(delta) < 1e-9:
            break
    ct, st = cos(t), sin(t)
    return cx + rx * ct, cy + ry * st

def point_in_convex_poly(px: float, py: float, pts: list) -> bool:
    """Vérifie si (px,py) est à l'intérieur d'un polygone convexe"""
    n = len(pts)
    sign = None
    for i in range(n):
        x1, y1 = pts[i]
        x2, y2 = pts[(i + 1) % n]
        cross = (x2 - x1) * (py - y1) - (y2 - y1) * (px - x1)
        if abs(cross) < 1e-10:
            continue
        s = cross > 0
        if sign is None:
            sign = s
        elif sign != s:
            return False
    return sign is not None

# ======================================== ROUNDED RECT ========================================
def rounded_rect_contour(cx: float, cy: float, hx: float, hy: float, r: float, rotation: float, corners) -> NDArray[np.float32]:
    """Génère le contour polygon monde d'un RoundedRect depuis ses paramètres world_transform"""
    seg = max(8, int(r / 1.25))
    rad = np.radians(rotation)
    corner_offsets = [
        (np.pi * 0.5, np.pi),
        (0.0, np.pi * 0.5),
        (np.pi * 1.5, np.pi * 2.0),
        (np.pi, np.pi * 1.5),
    ]
    contour = []
    for (ox, oy), (a_start, a_end) in zip(corners, corner_offsets):
        angles = np.linspace(a_start + rad, a_end + rad, seg + 1, endpoint=False)
        contour.append(np.column_stack((ox + r * np.cos(angles), oy + r * np.sin(angles))))
    return np.vstack(contour).astype(np.float32)