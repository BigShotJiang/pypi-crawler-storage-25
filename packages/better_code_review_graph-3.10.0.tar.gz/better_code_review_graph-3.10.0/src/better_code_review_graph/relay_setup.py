"""Credential resolution for better-code-review-graph.

Resolution order (relay only when ALL local sources are empty):
1. ENV VARS          -- User explicitly set (highest priority, skip everything)
2. RELAY CONFIG      -- Saved from previous relay setup (~/.config/mcp/config.enc)
3. RELAY SETUP       -- Interactive, ONLY when steps 1-2 are ALL empty (30s timeout)
4. LOCAL MODE        -- Fallback (qwen3-embed ONNX)
"""

from __future__ import annotations

import logging
import os
import sys

from .relay_schema import RELAY_SCHEMA

logger = logging.getLogger(__name__)

SERVER_NAME = "better-code-review-graph"
DEFAULT_RELAY_URL = "https://better-code-review-graph.n24q02m.com"
REQUIRED_FIELDS = [
    "GEMINI_API_KEY"
]  # Used for config file lookup (any key triggers match)

# Cloud API keys that indicate user has env vars configured
CLOUD_KEYS = [
    "GEMINI_API_KEY",
    "GOOGLE_API_KEY",
    "JINA_AI_API_KEY",
    "OPENAI_API_KEY",
    "COHERE_API_KEY",
    "CO_API_KEY",
]

# Shorter timeout for optional-credential servers (user can skip)
RELAY_TIMEOUT_S = 120.0


def apply_config(config: dict[str, str]) -> None:
    """Apply config dict to environment variables."""
    for key, value in config.items():
        if value and key not in os.environ:
            os.environ[key] = value
            logger.debug("Applied relay config: %s", key)


async def ensure_config() -> dict[str, str] | None:
    """Resolve config: env vars -> config file -> relay setup -> local fallback.

    Relay is ONLY triggered when steps 1-2 are ALL empty.
    Uses 30s timeout since CRG works locally without credentials.

    Returns:
        Config dict with credential keys, or None if skipped/failed (local mode).
    """
    # 1. Check env vars directly (highest priority, fast path)
    if any(os.environ.get(k) for k in CLOUD_KEYS):
        logger.info("Cloud API keys found in environment, skipping relay")
        return None  # env vars take priority, no relay needed

    # 2. Check saved relay config file (any cloud key is sufficient)
    try:
        from mcp_core.storage.config_file import read_config

        saved = read_config(SERVER_NAME)
        if saved and any(saved.get(k) for k in CLOUD_KEYS):
            logger.info("Config loaded from file")
            for key, value in saved.items():
                os.environ.setdefault(key, value)
            return saved
    except Exception:
        pass

    # 3. No local credentials found -- trigger relay setup
    logger.info("No credentials found. Starting relay setup...")

    relay_url = DEFAULT_RELAY_URL
    try:
        from mcp_core.relay.client import create_session

        # RELAY_SCHEMA is dict[str, Any] for forward-compat with newer
        # relay UI keys — see relay_schema.py for details.
        session = await create_session(relay_url, SERVER_NAME, RELAY_SCHEMA)  # ty: ignore[invalid-argument-type]
    except Exception:
        logger.debug("Cannot reach relay server at %s. Using local mode.", relay_url)
        return None

    # Log URL to stderr (visible to user in MCP client)
    print(
        f"\nConfigure cloud embedding (optional, 30s timeout):"
        f"\n{session.relay_url}"
        f"\nSkip to use local mode (qwen3-embed ONNX).\n",
        file=sys.stderr,
        flush=True,
    )

    # Poll for result with shorter timeout
    try:
        from mcp_core.relay.client import poll_for_result
        from mcp_core.storage.config_file import write_config

        config = await poll_for_result(relay_url, session, timeout_s=RELAY_TIMEOUT_S)

        # Save to config file
        write_config(SERVER_NAME, config)
        logger.info("Config saved successfully")

        # Notify relay page that setup is complete
        try:
            import httpx

            async with httpx.AsyncClient() as http:
                await http.post(
                    f"{relay_url}/api/sessions/{session.session_id}/messages",
                    json={
                        "type": "complete",
                        "text": "CRG config saved. Setup complete!",
                    },
                )
        except Exception:
            pass

        # Inject into environment
        for key, value in config.items():
            os.environ.setdefault(key, value)

        return config

    except RuntimeError as e:
        if "RELAY_SKIPPED" in str(e):
            logger.info("Relay setup skipped by user. Using local mode.")
        elif "timed out" in str(e).lower():
            logger.info("Relay setup timed out. Using local mode.")
        else:
            logger.debug("Relay setup ended: %s", e)
        return None
