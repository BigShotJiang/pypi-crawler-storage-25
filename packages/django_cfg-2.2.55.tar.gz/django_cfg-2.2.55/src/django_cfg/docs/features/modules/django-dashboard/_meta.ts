export default {
  'overview': 'Overview',
}
