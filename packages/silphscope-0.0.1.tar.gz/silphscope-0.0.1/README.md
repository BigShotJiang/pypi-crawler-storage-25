# Brief Description
Agentic Harness and simulation to allow AI to play Pokemon Red while also gathering training data to improve a model's performance for the task.
