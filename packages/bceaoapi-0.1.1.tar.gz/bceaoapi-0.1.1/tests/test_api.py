"""
Tests for the FastAPI REST endpoints.
"""

import pytest


class TestHealth:
    def test_health_ok(self, api_client):
        response = api_client.get("/health")
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "ok"
        assert data["database"]["nb_series"] > 0


class TestDatasets:
    def test_list_datasets(self, api_client):
        response = api_client.get("/v1/datasets")
        assert response.status_code == 200
        data = response.json()
        assert isinstance(data, list)
        codes = [d["code"] for d in data]
        assert "IHPC" in codes
        assert "IMECO" in codes

    def test_list_countries(self, api_client):
        response = api_client.get("/v1/datasets/IHPC/countries")
        assert response.status_code == 200
        countries = response.json()
        assert "SENEGAL" in countries

    def test_list_indicators(self, api_client):
        response = api_client.get("/v1/datasets/IHPC/indicators")
        assert response.status_code == 200
        indicators = response.json()
        assert "Ensemble" in indicators

    def test_list_indicators_with_country(self, api_client):
        response = api_client.get("/v1/datasets/IHPC/indicators?country=MALI")
        assert response.status_code == 200
        assert isinstance(response.json(), list)


class TestSeriesEndpoints:
    def test_search_series(self, api_client):
        response = api_client.get("/v1/series/search?q=inflation")
        assert response.status_code == 200
        data = response.json()
        assert isinstance(data, list)
        assert len(data) > 0

    def test_search_requires_min_length(self, api_client):
        response = api_client.get("/v1/series/search?q=a")
        assert response.status_code == 422  # FastAPI validation error

    def test_get_series_info(self, api_client):
        response = api_client.get("/v1/series/KKKSR1015A0BP")
        assert response.status_code == 200
        data = response.json()
        assert data["series_code"] == "KKKSR1015A0BP"
        assert data["country"] == "SENEGAL"

    def test_get_series_info_not_found(self, api_client):
        response = api_client.get("/v1/series/XXXXXXXXXX")
        assert response.status_code == 404

    def test_get_observations(self, api_client):
        response = api_client.get("/v1/series/KKKSR1015A0BP/observations")
        assert response.status_code == 200
        data = response.json()
        assert data["series_code"] == "KKKSR1015A0BP"
        assert data["count"] > 0
        assert len(data["observations"]) > 0
        # Check observation format
        obs = data["observations"][0]
        assert "date" in obs
        assert "value" in obs

    def test_get_observations_with_date_filter(self, api_client):
        response = api_client.get(
            "/v1/series/KKKSR1015A0BP/observations?start=2010&end=2022"
        )
        assert response.status_code == 200
        data = response.json()
        dates = [o["date"] for o in data["observations"]]
        assert all(d >= "2010-01-01" for d in dates)
        assert all(d <= "2022-12-31" for d in dates)


class TestDataEndpoints:
    def test_get_value(self, api_client):
        response = api_client.get(
            "/v1/data/value",
            params={
                "dataset": "IMECO",
                "indicator": "PIB nominal",
                "country": "SENEGAL",
                "year": 2022,
            },
        )
        assert response.status_code == 200
        data = response.json()
        assert data["value"] == pytest.approx(17330.12, rel=0.01)
        assert data["country"] == "SENEGAL"

    def test_get_value_not_found(self, api_client):
        response = api_client.get(
            "/v1/data/value",
            params={
                "dataset": "IMECO",
                "indicator": "inexistant",
                "country": "SENEGAL",
                "year": 2022,
            },
        )
        assert response.status_code == 404

    def test_get_series_by(self, api_client):
        response = api_client.get(
            "/v1/data/series",
            params={
                "dataset": "IHPC",
                "indicator": "Ensemble",
                "country": "MALI",
                "start": "2018",
            },
        )
        assert response.status_code == 200
        data = response.json()
        assert data["count"] > 0
        assert data["country"] == "MALI"

    def test_get_series_ambiguous(self, api_client):
        response = api_client.get(
            "/v1/data/series",
            params={"dataset": "PIBN", "indicator": "PIB", "country": "SENEGAL"},
        )
        assert response.status_code == 422

    def test_get_cross_country(self, api_client):
        response = api_client.get(
            "/v1/data/cross-country",
            params={"dataset": "IHPC", "indicator": "Ensemble", "start": "2022"},
        )
        assert response.status_code == 200
        data = response.json()
        assert "SENEGAL" in data["countries"]
        assert "MALI" in data["countries"]
        assert "ENSEMBLE UMOA" not in data["countries"]  # excluded by default

    def test_get_cross_country_with_union(self, api_client):
        response = api_client.get(
            "/v1/data/cross-country",
            params={
                "dataset": "IHPC",
                "indicator": "Ensemble",
                "include_union": True,
            },
        )
        assert response.status_code == 200
        data = response.json()
        assert "ENSEMBLE UMOA" in data["countries"]
