"""
Tests for the BCEAO client class.
"""

import pytest
import pandas as pd

from bceaoapi import BCEAO
from bceaoapi.exceptions import AmbiguousQueryError, SeriesNotFoundError


class TestNavigation:
    def test_list_datasets_returns_dataframe(self, db):
        result = db.list_datasets()
        assert isinstance(result, pd.DataFrame)
        assert len(result) > 0
        assert "code" in result.columns
        assert "frequency" in result.columns

    def test_list_datasets_contains_known_codes(self, db):
        codes = db.list_datasets()["code"].tolist()
        for expected in ["IHPC", "PIBN", "TC_M", "IMECO", "BDP6"]:
            assert expected in codes

    def test_list_countries_all(self, db):
        countries = db.list_countries()
        assert "SENEGAL" in countries
        assert "MALI" in countries
        assert "COTE D'IVOIRE" in countries
        assert len(countries) == 9  # 8 states + ENSEMBLE UMOA

    def test_list_countries_filtered_by_dataset(self, db):
        countries = db.list_countries(dataset="IHPC")
        assert len(countries) > 0
        assert "SENEGAL" in countries

    def test_list_indicators_returns_list(self, db):
        indicators = db.list_indicators("IHPC")
        assert isinstance(indicators, list)
        assert "Ensemble" in indicators
        assert "Alimentation" in indicators

    def test_list_indicators_filtered_by_country(self, db):
        indicators = db.list_indicators("PIBN", country="SENEGAL")
        assert isinstance(indicators, list)
        assert len(indicators) > 0


class TestSeriesInfo:
    def test_get_series_info_known_code(self, db):
        info = db.get_series_info("KKKSR1015A0BP")
        assert info["series_code"] == "KKKSR1015A0BP"
        assert info["country"] == "SENEGAL"
        assert info["dataset"] == "IMECO"
        assert info["frequency"] == "ANNUAL"

    def test_get_series_info_not_found(self, db):
        with pytest.raises(SeriesNotFoundError):
            db.get_series_info("XXXXXXXXXX")


class TestGetSeries:
    def test_get_series_returns_series(self, db):
        s = db.get_series("KKKSR1015A0BP")
        assert isinstance(s, pd.Series)
        assert len(s) > 0
        assert isinstance(s.index, pd.DatetimeIndex)

    def test_get_series_with_date_filter(self, db):
        s = db.get_series("KKKSR1015A0BP", start="2010", end="2022")
        assert s.index.min().year >= 2010
        assert s.index.max().year <= 2022

    def test_get_series_not_found(self, db):
        with pytest.raises(SeriesNotFoundError):
            db.get_series("XXXXXXXXXX")


class TestGetSeriesBy:
    def test_get_series_by_exact_match(self, db):
        s = db.get_series_by("IMECO", "PIB nominal (en milliards de FCFA)", "SENEGAL")
        assert isinstance(s, pd.Series)
        assert len(s) > 0

    def test_get_series_by_partial_match(self, db):
        s = db.get_series_by("IHPC", "Ensemble", "MALI")
        assert isinstance(s, pd.Series)
        assert len(s) > 0

    def test_get_series_by_partial_country(self, db):
        # 'BURK' should match 'BURKINA FASO'
        s = db.get_series_by("IHPC", "Ensemble", "BURK")
        assert isinstance(s, pd.Series)

    def test_get_series_by_not_found(self, db):
        with pytest.raises(SeriesNotFoundError):
            db.get_series_by("IHPC", "indicateur_inexistant", "SENEGAL")

    def test_get_series_by_ambiguous(self, db):
        # 'PIB' matches both 'PIB marchand' and 'PIB non marchand'
        with pytest.raises(AmbiguousQueryError):
            db.get_series_by("PIBN", "PIB", "SENEGAL")


class TestGetValue:
    def test_get_value_annual(self, db):
        value = db.get_value("IMECO", "PIB nominal", "SENEGAL", 2022)
        assert value is not None
        assert isinstance(value, float)
        assert value > 0

    def test_get_value_monthly(self, db):
        value = db.get_value("TC_M", "Cours du Dollar US", "ENSEMBLE UMOA", 2025, month=12)
        assert value is not None
        assert isinstance(value, float)
        assert value > 0

    def test_get_value_missing_returns_none(self, db):
        # A very early period that likely has no data
        value = db.get_value("IHPC", "Ensemble", "SENEGAL", 1900)
        assert value is None


class TestGetCrossCountry:
    def test_get_cross_country_shape(self, db):
        df = db.get_cross_country("IHPC", "Ensemble", start="2020")
        assert isinstance(df, pd.DataFrame)
        assert len(df.columns) == 8  # 8 member states, no union
        assert isinstance(df.index, pd.DatetimeIndex)

    def test_get_cross_country_with_union(self, db):
        df = db.get_cross_country("IHPC", "Ensemble", include_union=True)
        assert "ENSEMBLE UMOA" in df.columns
        assert len(df.columns) == 9

    def test_get_cross_country_not_found(self, db):
        from bceaoapi.exceptions import SeriesNotFoundError
        with pytest.raises(SeriesNotFoundError):
            db.get_cross_country("IHPC", "indicateur_inexistant")


class TestGetDataset:
    def test_get_dataset_with_country(self, db):
        df = db.get_dataset("PIBN", country="TOGO")
        assert isinstance(df, pd.DataFrame)
        assert len(df.columns) > 0
        assert isinstance(df.index, pd.DatetimeIndex)

    def test_get_dataset_not_found(self, db):
        from bceaoapi.exceptions import DatasetNotFoundError
        with pytest.raises(DatasetNotFoundError):
            db.get_dataset("XXXXXXXX")


class TestSearch:
    def test_search_returns_dataframe(self, db):
        result = db.search("inflation")
        assert isinstance(result, pd.DataFrame)
        assert len(result) > 0
        assert "series_code" in result.columns

    def test_search_with_country_filter(self, db):
        result = db.search("PIB", country="SENEGAL")
        assert all(result["country"] == "SENEGAL")

    def test_search_with_frequency_filter(self, db):
        result = db.search("taux", frequency="MONTHLY")
        assert all(result["frequency"] == "MONTHLY")

    def test_search_no_results_returns_empty_df(self, db):
        result = db.search("xyzzy_no_match_12345")
        assert isinstance(result, pd.DataFrame)
        assert len(result) == 0

    def test_search_dataset_name_match(self, db):
        # 'taux de change' is in the dataset name, not the series labels
        result = db.search("taux de change", frequency="MONTHLY")
        assert len(result) > 0
        assert all(result["dataset"] == "TC_M")
