"""
db.py — Database backend for bceaoapi (SQLite and PostgreSQL).

Used by the API server and by local users who have run the ETL.
The rest of the world uses the REST backend instead.
"""

import re
import sqlite3
from pathlib import Path
from typing import Optional, Union

import pandas as pd

from bceaoapi.exceptions import (
    AmbiguousQueryError,
    DatasetNotFoundError,
    SeriesNotFoundError,
)


class DbBackend:
    """
    Read-only access to the BCEAO database.

    Supports both SQLite (local development / ETL output) and PostgreSQL
    (production server). The backend is chosen automatically based on the
    connection string provided.

    Parameters
    ----------
    db_path : str or Path, optional
        Path to a local SQLite file.
    db_url : str, optional
        PostgreSQL connection URL: "postgresql://user:pass@host:5432/bceao"
    """

    def __init__(
        self,
        db_path: Union[str, Path, None] = None,
        db_url: Optional[str] = None,
    ):
        if db_url:
            self._mode = "postgres"
            self._db_url = db_url
        elif db_path:
            self._mode = "sqlite"
            self._db_path = Path(db_path)
            if not self._db_path.exists():
                raise FileNotFoundError(
                    f"Database not found: {self._db_path}\n"
                    "Run first: python scripts/etl.py"
                )
        else:
            raise ValueError("Either db_path or db_url must be provided.")

    # ─── Internal connection helpers ─────────────────────────────────────────

    def _connect(self):
        if self._mode == "sqlite":
            conn = sqlite3.connect(self._db_path)
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA query_only=ON")
            return conn
        else:
            try:
                import psycopg2
                import psycopg2.extras
            except ImportError:
                raise ImportError(
                    "psycopg2 is required for PostgreSQL support.\n"
                    "Install it with: pip install psycopg2-binary"
                )
            conn = psycopg2.connect(self._db_url)
            return conn

    def _query(self, sql: str, params: tuple = ()) -> list:
        """Execute a SELECT and return all rows as a list of row-like objects."""
        sql = self._adapt_sql(sql)
        with self._connect() as conn:
            if self._mode == "sqlite":
                return conn.execute(sql, params).fetchall()
            else:
                import psycopg2.extras
                with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                    cur.execute(sql, params)
                    return cur.fetchall()

    def _query_df(self, sql: str, params: tuple = ()) -> pd.DataFrame:
        """Execute a SELECT and return results as a DataFrame."""
        sql = self._adapt_sql(sql)
        with self._connect() as conn:
            return pd.read_sql_query(sql, conn, params=params)

    def _adapt_sql(self, sql: str) -> str:
        """Convert SQLite-style ? placeholders to %s for PostgreSQL."""
        if self._mode == "postgres":
            return sql.replace("?", "%s")
        return sql

    def _row_value(self, row, key: str):
        """Access a row field by name regardless of the cursor type."""
        try:
            return row[key]
        except (KeyError, IndexError, TypeError):
            return None

    # ─── Navigation ──────────────────────────────────────────────────────────

    def list_datasets(self) -> pd.DataFrame:
        return self._query_df("""
            SELECT
                d.code,
                d.name,
                d.frequency,
                d.first_period,
                d.last_period,
                COUNT(DISTINCT s.id) AS nb_series,
                COUNT(o.id)          AS nb_observations
            FROM datasets d
            LEFT JOIN series s ON s.dataset_id = d.id
            LEFT JOIN observations o ON o.series_id = s.id
            GROUP BY d.id, d.code, d.name, d.frequency, d.first_period, d.last_period
            ORDER BY d.code
        """)

    def list_countries(self, dataset: Optional[str] = None) -> list[str]:
        if dataset:
            rows = self._query("""
                SELECT DISTINCT c.name
                FROM countries c
                JOIN series s ON s.country_id = c.id
                JOIN datasets d ON s.dataset_id = d.id
                WHERE d.code = ?
                ORDER BY c.name
            """, (dataset.upper(),))
        else:
            rows = self._query("SELECT name FROM countries ORDER BY name")
        return [r["name"] for r in rows]

    def list_indicators(self, dataset: str, country: Optional[str] = None) -> list[str]:
        sql = """
            SELECT DISTINCT s.label
            FROM series s
            JOIN datasets d ON s.dataset_id = d.id
        """
        params: list = [dataset.upper()]
        sql += " WHERE d.code = ?"

        if country:
            sql += """
                AND s.country_id = (
                    SELECT id FROM countries
                    WHERE name = ? OR name LIKE ?
                    LIMIT 1
                )
            """
            params += [country.upper(), f"%{country.upper()}%"]

        sql += " ORDER BY s.label"
        rows = self._query(sql, tuple(params))
        return [r["label"] for r in rows]

    # ─── Series metadata ─────────────────────────────────────────────────────

    def get_series_info(self, series_code: str) -> dict:
        rows = self._query("""
            SELECT
                s.series_code, s.indicator_code, s.label, s.unit, s.magnitude,
                s.source, s.series_type, s.observation_method,
                s.first_observation, s.last_observation, s.nb_observations,
                d.code  AS dataset, d.frequency,
                c.name  AS country, c.iso3 AS country_iso3
            FROM series s
            JOIN datasets d ON s.dataset_id = d.id
            JOIN countries c ON s.country_id = c.id
            WHERE s.series_code = ?
        """, (series_code,))

        if not rows:
            raise SeriesNotFoundError(f"Series not found: '{series_code}'")
        return dict(rows[0])

    # ─── Observations ────────────────────────────────────────────────────────

    def get_series(
        self,
        series_code: str,
        start: Optional[str] = None,
        end: Optional[str] = None,
    ) -> pd.Series:
        info = self.get_series_info(series_code)
        df = self._fetch_observations(series_code, start=start, end=end)
        if df.empty:
            return pd.Series([], dtype=float, name=series_code)
        s = df.set_index("date")["value"]
        s.index = pd.to_datetime(s.index)
        s.name = f"{info['label']} — {info['country']}"
        return s

    def get_series_by(
        self,
        dataset: str,
        indicator: str,
        country: str,
        start: Optional[str] = None,
        end: Optional[str] = None,
    ) -> pd.Series:
        series_code = self.resolve_series(dataset, indicator, country)
        return self.get_series(series_code, start=start, end=end)

    def get_value(
        self,
        dataset: str,
        indicator: str,
        country: str,
        year: int,
        month: Optional[int] = None,
    ) -> Optional[float]:
        series_code = self.resolve_series(dataset, indicator, country)
        date_str = _build_date(year, month)
        rows = self._query("""
            SELECT o.value FROM observations o
            JOIN series s ON o.series_id = s.id
            WHERE s.series_code = ? AND o.date = ?
        """, (series_code, date_str))
        return rows[0]["value"] if rows else None

    def get_cross_country(
        self,
        dataset: str,
        indicator: str,
        start: Optional[str] = None,
        end: Optional[str] = None,
        include_union: bool = False,
    ) -> pd.DataFrame:
        sql = """
            SELECT c.name AS country, o.date, o.value
            FROM observations o
            JOIN series s ON o.series_id = s.id
            JOIN datasets d ON s.dataset_id = d.id
            JOIN countries c ON s.country_id = c.id
            WHERE d.code = ? AND (s.label = ? OR s.label LIKE ?)
        """
        params: list = [dataset.upper(), indicator, f"%{indicator}%"]
        if not include_union:
            sql += " AND c.is_union = 0"
        if start:
            sql += " AND o.date >= ?"
            params.append(_normalize_date(start, "start"))
        if end:
            sql += " AND o.date <= ?"
            params.append(_normalize_date(end, "end"))
        sql += " ORDER BY o.date, c.name"

        df = self._query_df(sql, tuple(params))
        if df.empty:
            raise SeriesNotFoundError(
                f"No data found for dataset='{dataset}', indicator='{indicator}'"
            )
        pivot = df.pivot(index="date", columns="country", values="value")
        pivot.index = pd.to_datetime(pivot.index)
        pivot.columns.name = None
        return pivot

    def get_dataset(
        self,
        dataset: str,
        country: Optional[str] = None,
        start: Optional[str] = None,
        end: Optional[str] = None,
    ) -> pd.DataFrame:
        sql = """
            SELECT s.label AS indicator, c.name AS country, o.date, o.value
            FROM observations o
            JOIN series s ON o.series_id = s.id
            JOIN datasets d ON s.dataset_id = d.id
            JOIN countries c ON s.country_id = c.id
            WHERE d.code = ?
        """
        params: list = [dataset.upper()]
        if country:
            sql += " AND (c.name = ? OR c.name LIKE ?)"
            params += [country.upper(), f"%{country.upper()}%"]
        if start:
            sql += " AND o.date >= ?"
            params.append(_normalize_date(start, "start"))
        if end:
            sql += " AND o.date <= ?"
            params.append(_normalize_date(end, "end"))
        sql += " ORDER BY o.date"

        df = self._query_df(sql, tuple(params))
        if df.empty:
            raise DatasetNotFoundError(f"No data found for dataset='{dataset}'")

        if country:
            pivot = df.pivot(index="date", columns="indicator", values="value")
        else:
            df["series"] = df["country"] + " | " + df["indicator"]
            pivot = df.pivot(index="date", columns="series", values="value")
        pivot.index = pd.to_datetime(pivot.index)
        pivot.columns.name = None
        return pivot

    def search(
        self,
        query: str,
        country: Optional[str] = None,
        dataset: Optional[str] = None,
        frequency: Optional[str] = None,
        limit: int = 30,
    ) -> pd.DataFrame:
        words = query.strip().split()
        label_conds   = " AND ".join(["s.label LIKE ?" for _ in words])
        dataset_conds = " AND ".join(["d.name LIKE ?"  for _ in words])
        like_params = [f"%{w}%" for w in words]

        sql = f"""
            SELECT s.series_code, d.code AS dataset, c.name AS country,
                   s.label, d.frequency, s.unit, s.magnitude,
                   s.last_observation AS last_date, s.nb_observations
            FROM series s
            JOIN datasets d ON s.dataset_id = d.id
            JOIN countries c ON s.country_id = c.id
            WHERE (({label_conds}) OR ({dataset_conds}))
        """
        params: list = like_params + like_params
        if country:
            sql += " AND (c.name = ? OR c.name LIKE ?)"
            params += [country.upper(), f"%{country.upper()}%"]
        if dataset:
            sql += " AND d.code = ?"
            params.append(dataset.upper())
        if frequency:
            sql += " AND d.frequency = ?"
            params.append(frequency.upper())
        sql += " ORDER BY s.nb_observations DESC, s.label LIMIT ?"
        params.append(limit)
        return self._query_df(sql, tuple(params))

    # ─── Internal ────────────────────────────────────────────────────────────

    def resolve_series(self, dataset: str, indicator: str, country: str) -> str:
        """Resolve (dataset, indicator, country) to a unique series_code."""
        rows = self._query("""
            SELECT s.series_code, s.label, c.name AS country
            FROM series s
            JOIN datasets d ON s.dataset_id = d.id
            JOIN countries c ON s.country_id = c.id
            WHERE d.code = ?
              AND (s.label = ? OR s.label LIKE ?)
              AND (c.name = ? OR c.name LIKE ?)
        """, (
            dataset.upper(),
            indicator, f"%{indicator}%",
            country.upper(), f"%{country.upper()}%",
        ))

        if not rows:
            raise SeriesNotFoundError(
                f"No series found for:\n"
                f"  dataset='{dataset}', indicator='{indicator}', country='{country}'\n"
                f"Tip: use b.list_indicators('{dataset}') to see exact labels."
            )
        if len(rows) > 1:
            matches = "\n".join(
                f"  - [{r['series_code']}] {r['label']} ({r['country']})"
                for r in rows[:5]
            )
            raise AmbiguousQueryError(
                f"{len(rows)} series match indicator='{indicator}'. "
                f"Use a more specific label.\nMatches found:\n{matches}"
            )
        return rows[0]["series_code"]

    def _fetch_observations(
        self,
        series_code: str,
        start: Optional[str] = None,
        end: Optional[str] = None,
    ) -> pd.DataFrame:
        sql = """
            SELECT o.date, o.value FROM observations o
            JOIN series s ON o.series_id = s.id
            WHERE s.series_code = ?
        """
        params: list = [series_code]
        if start:
            sql += " AND o.date >= ?"
            params.append(_normalize_date(start, "start"))
        if end:
            sql += " AND o.date <= ?"
            params.append(_normalize_date(end, "end"))
        sql += " ORDER BY o.date"
        return self._query_df(sql, tuple(params))

    def __repr__(self) -> str:
        loc = self._db_url.split("@")[-1] if self._mode == "postgres" else self._db_path.name
        return f"<DbBackend mode={self._mode} location={loc}>"


# ─── Helpers ──────────────────────────────────────────────────────────────────

def _normalize_date(date_str: str, bound: str) -> str:
    s = str(date_str).strip()
    if re.fullmatch(r"\d{4}", s):
        return f"{s}-01-01" if bound == "start" else f"{s}-12-31"
    if re.fullmatch(r"\d{4}-\d{2}", s):
        return f"{s}-01" if bound == "start" else f"{s}-31"
    return s


def _build_date(year: int, month: Optional[int]) -> str:
    import calendar
    if month:
        last_day = calendar.monthrange(year, month)[1]
        return f"{year}-{month:02d}-{last_day:02d}"
    return f"{year}-12-31"
