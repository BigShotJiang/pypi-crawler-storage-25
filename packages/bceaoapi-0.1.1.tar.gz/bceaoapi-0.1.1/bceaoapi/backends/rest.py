"""
rest.py — HTTP REST backend for bceaoapi.

This is the default backend: when you call BCEAO() with no arguments,
it connects to the hosted API and fetches data over HTTP.
No local database or Excel files required.
"""

from typing import Optional

import requests
import pandas as pd

from bceaoapi.exceptions import (
    AmbiguousQueryError,
    DatasetNotFoundError,
    SeriesNotFoundError,
)


class RestBackend:
    """
    Fetches BCEAO data from a remote FastAPI server over HTTP.

    This backend is used automatically when you call BCEAO() with no arguments.
    It requires only the `requests` library — no local database needed.

    Parameters
    ----------
    api_url : str
        Base URL of the API, e.g. "https://api.bceao.dev/v1".
    timeout : int
        Request timeout in seconds (default: 30).
    """

    def __init__(self, api_url: str, timeout: int = 30):
        self._base = api_url.rstrip("/")
        self._timeout = timeout
        self._session = requests.Session()
        self._session.headers["Accept"] = "application/json"

    # ─── Internal HTTP helpers ────────────────────────────────────────────────

    def _get(self, path: str, params: dict = None) -> object:
        """Execute a GET request and raise bceaoapi exceptions on error."""
        url = f"{self._base}{path}"
        response = self._session.get(url, params=params, timeout=self._timeout)

        if response.status_code == 404:
            raise SeriesNotFoundError(response.json().get("detail", "Not found"))
        if response.status_code == 422:
            detail = response.json().get("detail", "Ambiguous query")
            # FastAPI validation errors have a different shape
            if isinstance(detail, list):
                raise AmbiguousQueryError(str(detail))
            raise AmbiguousQueryError(detail)
        if response.status_code >= 400:
            raise RuntimeError(
                f"API error {response.status_code}: {response.text[:200]}"
            )
        return response.json()

    # ─── Navigation ───────────────────────────────────────────────────────────

    def list_datasets(self) -> pd.DataFrame:
        data = self._get("/datasets")
        return pd.DataFrame(data)

    def list_countries(self, dataset: Optional[str] = None) -> list[str]:
        if dataset:
            return self._get(f"/datasets/{dataset.upper()}/countries")
        return self._get("/datasets/countries")

    def list_indicators(self, dataset: str, country: Optional[str] = None) -> list[str]:
        params = {"country": country} if country else None
        return self._get(f"/datasets/{dataset.upper()}/indicators", params)

    # ─── Series metadata ──────────────────────────────────────────────────────

    def get_series_info(self, series_code: str) -> dict:
        return self._get(f"/series/{series_code}")

    # ─── Observations ─────────────────────────────────────────────────────────

    def get_series(
        self,
        series_code: str,
        start: Optional[str] = None,
        end: Optional[str] = None,
    ) -> pd.Series:
        params = {}
        if start:
            params["start"] = start
        if end:
            params["end"] = end
        data = self._get(f"/series/{series_code}/observations", params)
        return _observations_to_series(
            data["observations"],
            name=f"{data['label']} — {data['country']}",
        )

    def get_series_by(
        self,
        dataset: str,
        indicator: str,
        country: str,
        start: Optional[str] = None,
        end: Optional[str] = None,
    ) -> pd.Series:
        params = {"dataset": dataset, "indicator": indicator, "country": country}
        if start:
            params["start"] = start
        if end:
            params["end"] = end
        data = self._get("/data/series", params)
        return _observations_to_series(
            data["observations"],
            name=f"{data['label']} — {data['country']}",
        )

    def get_value(
        self,
        dataset: str,
        indicator: str,
        country: str,
        year: int,
        month: Optional[int] = None,
    ) -> Optional[float]:
        params = {
            "dataset": dataset,
            "indicator": indicator,
            "country": country,
            "year": year,
        }
        if month:
            params["month"] = month
        data = self._get("/data/value", params)
        return data.get("value")

    def get_cross_country(
        self,
        dataset: str,
        indicator: str,
        start: Optional[str] = None,
        end: Optional[str] = None,
        include_union: bool = False,
    ) -> pd.DataFrame:
        params = {
            "dataset": dataset,
            "indicator": indicator,
            "include_union": str(include_union).lower(),
        }
        if start:
            params["start"] = start
        if end:
            params["end"] = end
        data = self._get("/data/cross-country", params)

        # data["data"] = {country: [{date, value}, ...]}
        frames = {}
        for country_name, observations in data["data"].items():
            frames[country_name] = {
                obs["date"]: obs["value"] for obs in observations
            }
        df = pd.DataFrame(frames)
        df.index = pd.to_datetime(df.index)
        df.index.name = "date"
        return df

    def get_dataset(
        self,
        dataset: str,
        country: Optional[str] = None,
        start: Optional[str] = None,
        end: Optional[str] = None,
    ) -> pd.DataFrame:
        params: dict = {"dataset": dataset}
        if country:
            params["country"] = country
        if start:
            params["start"] = start
        if end:
            params["end"] = end
        data = self._get("/data/dataset", params)

        # data = {indicator: [{date, value}, ...]}
        frames = {}
        for indicator, observations in data["data"].items():
            frames[indicator] = {obs["date"]: obs["value"] for obs in observations}
        df = pd.DataFrame(frames)
        df.index = pd.to_datetime(df.index)
        df.index.name = "date"
        return df

    def search(
        self,
        query: str,
        country: Optional[str] = None,
        dataset: Optional[str] = None,
        frequency: Optional[str] = None,
        limit: int = 30,
    ) -> pd.DataFrame:
        params: dict = {"q": query, "limit": limit}
        if country:
            params["country"] = country
        if dataset:
            params["dataset"] = dataset
        if frequency:
            params["frequency"] = frequency
        data = self._get("/series/search", params)
        return pd.DataFrame(data)

    # ─── Passthrough used by the thin BCEAO wrapper ───────────────────────────

    def resolve_series(self, dataset: str, indicator: str, country: str) -> str:
        """
        Resolve a (dataset, indicator, country) triplet to a series code.
        Uses the search endpoint — the server handles the matching logic.
        """
        results = self.search(indicator, country=country, dataset=dataset, limit=5)
        if results.empty:
            raise SeriesNotFoundError(
                f"No series found for:\n"
                f"  dataset='{dataset}', indicator='{indicator}', country='{country}'\n"
                f"Tip: use b.list_indicators('{dataset}') to see exact labels."
            )
        if len(results) > 1:
            matches = "\n".join(
                f"  - [{r['series_code']}] {r['label']} ({r['country']})"
                for _, r in results.iterrows()
            )
            raise AmbiguousQueryError(
                f"{len(results)} series match indicator='{indicator}'. "
                f"Use a more specific label.\nMatches found:\n{matches}"
            )
        return results.iloc[0]["series_code"]

    def __repr__(self) -> str:
        return f"<RestBackend url='{self._base}'>"


# ─── Helper ───────────────────────────────────────────────────────────────────

def _observations_to_series(observations: list[dict], name: str) -> pd.Series:
    """Convert a [{date, value}, ...] list to a pandas.Series with DatetimeIndex."""
    if not observations:
        return pd.Series([], dtype=float, name=name)
    dates = pd.to_datetime([o["date"] for o in observations])
    values = [o["value"] for o in observations]
    return pd.Series(values, index=dates, name=name, dtype=float)
