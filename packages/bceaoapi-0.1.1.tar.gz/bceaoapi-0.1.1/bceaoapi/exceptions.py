"""Custom exceptions for bceaoapi."""


class BceaoError(Exception):
    """Base exception for the bceaoapi package."""


class SeriesNotFoundError(BceaoError):
    """Raised when a series cannot be found in the database."""


class DatasetNotFoundError(BceaoError):
    """Raised when a dataset cannot be found in the database."""


class AmbiguousQueryError(BceaoError):
    """
    Raised when a query matches multiple series.
    The user needs to provide a more specific indicator label.
    """
