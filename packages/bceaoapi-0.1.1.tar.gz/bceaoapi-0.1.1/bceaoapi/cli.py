"""
Command-line interface for bceaoapi.

Registered entry points (after pip install bceaoapi[etl] / bceaoapi[api]):
    bceao-etl     — import Excel files into a local SQLite database
    bceao-server  — start the REST API server
"""

import sys


def run_etl() -> None:
    """
    Entry point for `bceao-etl`.

    Delegates to scripts/etl.py with the same argument interface.
    Requires the [etl] extra: pip install bceaoapi[etl]
    """
    try:
        import openpyxl  # noqa: F401
    except ImportError:
        print(
            "Error: openpyxl is required to run the ETL.\n"
            "Install it with: pip install bceaoapi[etl]",
            file=sys.stderr,
        )
        sys.exit(1)

    # Import and run the ETL main function
    try:
        from bceaoapi._etl import main
    except ImportError:
        print(
            "Error: ETL module not found.\n"
            "Make sure you are running from the project root directory.",
            file=sys.stderr,
        )
        sys.exit(1)

    main()


def run_server() -> None:
    """
    Entry point for `bceao-server`.

    Starts the FastAPI server with uvicorn.
    Requires the [api] extra: pip install bceaoapi[api]
    """
    try:
        import uvicorn
    except ImportError:
        print(
            "Error: uvicorn is required to run the server.\n"
            "Install it with: pip install bceaoapi[api]",
            file=sys.stderr,
        )
        sys.exit(1)

    import argparse

    parser = argparse.ArgumentParser(description="Start the BCEAO API server.")
    parser.add_argument("--host", default="0.0.0.0", help="Bind host (default: 0.0.0.0)")
    parser.add_argument("--port", type=int, default=8000, help="Port (default: 8000)")
    parser.add_argument("--reload", action="store_true", help="Enable auto-reload (dev mode)")
    args = parser.parse_args()

    uvicorn.run(
        "api.main:app",
        host=args.host,
        port=args.port,
        reload=args.reload,
    )
