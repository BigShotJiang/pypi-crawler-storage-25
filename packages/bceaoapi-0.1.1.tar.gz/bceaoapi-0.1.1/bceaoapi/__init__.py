"""
bceaoapi — BCEAO/UEMOA macroeconomic data for Python.

Quick start:
    from bceaoapi import BCEAO

    b = BCEAO()
    b.list_datasets()
    b.search('inflation', country='SENEGAL')
    b.get_value('IMECO', 'PIB nominal', 'SENEGAL', 2022)
    b.get_series_by('IHPC', 'Ensemble', 'MALI', start='2010')
    b.get_cross_country('IHPC', 'Ensemble')
"""

from .bceao import BCEAO
from .exceptions import (
    AmbiguousQueryError,
    BceaoError,
    DatasetNotFoundError,
    SeriesNotFoundError,
)

__version__ = "0.1.1"
__all__ = [
    "BCEAO",
    "BceaoError",
    "SeriesNotFoundError",
    "DatasetNotFoundError",
    "AmbiguousQueryError",
]
