"""
bceao.py — Main entry point for the bceaoapi package.

BCEAO() with no arguments connects to the hosted public API by default —
no local database or Excel files needed.

Usage:
    from bceaoapi import BCEAO

    b = BCEAO()                             # → hosted API (default)
    b = BCEAO(db_path="bceao.db")           # → local SQLite database
    b = BCEAO(db_url="postgresql://...")    # → PostgreSQL (server-side use)
    b = BCEAO(api_url="http://localhost:8000/v1")  # → custom API endpoint
"""

import os
from pathlib import Path
from typing import Optional, Union

import pandas as pd

from .exceptions import AmbiguousQueryError, DatasetNotFoundError, SeriesNotFoundError

# Public API URL
_DEFAULT_API_URL = "https://bceaoapi.up.railway.app/v1"


class BCEAO:
    """
    Client for BCEAO/UEMOA macroeconomic data.

    By default, connects to the hosted public REST API — no setup required.
    For local use (after running the ETL), pass db_path to use a local database.

    Parameters
    ----------
    db_path : str or Path, optional
        Path to a local SQLite database built by the ETL pipeline.
        Use this when working offline or developing locally.
    db_url : str, optional
        PostgreSQL connection URL. Used by the API server itself.
        Format: "postgresql://user:pass@host:5432/bceao"
    api_url : str, optional
        Override the default hosted API URL.
        Defaults to the BCEAO_API_URL environment variable".

    Examples
    --------
    >>> b = BCEAO()
    >>> b.get_value("IMECO", "PIB nominal", "SENEGAL", 2022)
    17330.12

    >>> b.get_cross_country("IHPC", "Ensemble", start="2015").plot()
    """

    def __init__(
        self,
        db_path: Union[str, Path, None] = None,
        db_url: Optional[str] = None,
        api_url: Optional[str] = None,
    ):
        if db_path is not None or db_url is not None:
            from .backends.db import DbBackend
            self._impl = DbBackend(db_path=db_path, db_url=db_url)
        else:
            from .backends.rest import RestBackend
            url = api_url or os.environ.get("BCEAO_API_URL") or _DEFAULT_API_URL
            self._impl = RestBackend(url)

    # ─── Navigation ───────────────────────────────────────────────────────────

    def list_datasets(self) -> pd.DataFrame:
        """
        List all available datasets.

        Returns
        -------
        DataFrame with columns: code, name, frequency, first_period, last_period,
        nb_series, nb_observations.
        """
        return self._impl.list_datasets()

    def list_countries(self, dataset: Optional[str] = None) -> list[str]:
        """
        List available countries, optionally filtered by dataset.

        Parameters
        ----------
        dataset : str, optional
            Dataset code (e.g. 'PIBN'). If omitted, returns all countries.

        Returns
        -------
        List of country names sorted alphabetically.
        """
        return self._impl.list_countries(dataset=dataset)

    def list_indicators(self, dataset: str, country: Optional[str] = None) -> list[str]:
        """
        List available indicator labels within a dataset.

        Parameters
        ----------
        dataset : str
            Dataset code (e.g. 'IHPC', 'PIBN').
        country : str, optional
            Filter by country name or partial name.

        Returns
        -------
        List of indicator labels sorted alphabetically.
        """
        return self._impl.list_indicators(dataset, country=country)

    # ─── Series metadata ──────────────────────────────────────────────────────

    def get_series_info(self, series_code: str) -> dict:
        """
        Return full metadata for a series.

        Parameters
        ----------
        series_code : str
            Series identifier (e.g. 'KKKSR1015A0BP').

        Raises
        ------
        SeriesNotFoundError
            If no series matches the given code.
        """
        return self._impl.get_series_info(series_code)

    # ─── Observations ─────────────────────────────────────────────────────────

    def get_series(
        self,
        series_code: str,
        start: Optional[str] = None,
        end: Optional[str] = None,
    ) -> pd.Series:
        """
        Fetch observations for a series by its code.

        Parameters
        ----------
        series_code : str
            Series identifier (e.g. 'KKKSR1015A0BP').
        start : str, optional
            Start date as 'YYYY', 'YYYY-MM', or 'YYYY-MM-DD'.
        end : str, optional
            End date as 'YYYY', 'YYYY-MM', or 'YYYY-MM-DD'.

        Returns
        -------
        pandas.Series with DatetimeIndex.
        """
        return self._impl.get_series(series_code, start=start, end=end)

    def get_series_by(
        self,
        dataset: str,
        indicator: str,
        country: str,
        start: Optional[str] = None,
        end: Optional[str] = None,
    ) -> pd.Series:
        """
        Fetch a series by dataset, indicator label, and country — no code needed.

        Partial matching is supported for both indicator and country:
        'PIB' will match 'PIB nominal (en milliards de FCFA)',
        'cote' will match "COTE D'IVOIRE".

        Parameters
        ----------
        dataset : str
            Dataset code (e.g. 'PIBN', 'IHPC', 'IMECO').
        indicator : str
            Indicator label or partial label.
        country : str
            Country name or partial name.
        start : str, optional
            Start date as 'YYYY', 'YYYY-MM', or 'YYYY-MM-DD'.
        end : str, optional
            End date as 'YYYY', 'YYYY-MM', or 'YYYY-MM-DD'.

        Returns
        -------
        pandas.Series with DatetimeIndex.

        Raises
        ------
        SeriesNotFoundError
            If no matching series is found.
        AmbiguousQueryError
            If multiple series match — use a more specific label.

        Examples
        --------
        >>> b.get_series_by('IMECO', 'PIB nominal', 'SENEGAL')
        >>> b.get_series_by('IHPC', 'Ensemble', 'BURKINA', start='2010')
        """
        return self._impl.get_series_by(dataset, indicator, country,
                                        start=start, end=end)

    def get_value(
        self,
        dataset: str,
        indicator: str,
        country: str,
        year: int,
        month: Optional[int] = None,
    ) -> Optional[float]:
        """
        Fetch a single data point for a given period.

        Parameters
        ----------
        dataset : str
            Dataset code (e.g. 'IMECO').
        indicator : str
            Indicator label or partial label.
        country : str
            Country name or partial name.
        year : int
            Year (e.g. 2022).
        month : int, optional
            Month 1–12 for monthly series.

        Returns
        -------
        float or None if the observation is missing.

        Examples
        --------
        >>> b.get_value('IMECO', 'PIB nominal', 'SENEGAL', 2022)
        17330.12
        """
        return self._impl.get_value(dataset, indicator, country, year, month=month)

    def get_cross_country(
        self,
        dataset: str,
        indicator: str,
        start: Optional[str] = None,
        end: Optional[str] = None,
        include_union: bool = False,
    ) -> pd.DataFrame:
        """
        Fetch one indicator across all UEMOA countries at once.

        Parameters
        ----------
        dataset : str
            Dataset code (e.g. 'IHPC').
        indicator : str
            Indicator label or partial label.
        start : str, optional
            Start date.
        end : str, optional
            End date.
        include_union : bool
            Include 'ENSEMBLE UMOA' aggregate column (default: False).

        Returns
        -------
        pandas.DataFrame — index=date, columns=country names.

        Examples
        --------
        >>> b.get_cross_country('IHPC', 'Ensemble', start='2010')
        """
        return self._impl.get_cross_country(dataset, indicator, start=start,
                                            end=end, include_union=include_union)

    def get_dataset(
        self,
        dataset: str,
        country: Optional[str] = None,
        start: Optional[str] = None,
        end: Optional[str] = None,
    ) -> pd.DataFrame:
        """
        Fetch all series in a dataset, optionally filtered by country.

        Parameters
        ----------
        dataset : str
            Dataset code (e.g. 'PIBN').
        country : str, optional
            Filter by country name or partial name.
        start : str, optional
            Start date.
        end : str, optional
            End date.

        Returns
        -------
        pandas.DataFrame — index=date, columns=indicator labels.
        """
        return self._impl.get_dataset(dataset, country=country, start=start, end=end)

    def search(
        self,
        query: str,
        country: Optional[str] = None,
        dataset: Optional[str] = None,
        frequency: Optional[str] = None,
        limit: int = 30,
    ) -> pd.DataFrame:
        """
        Search series by free-text keywords.

        Searches both series labels and dataset names.

        Parameters
        ----------
        query : str
            Keywords to search for (space-separated, all must match).
        country : str, optional
            Filter by country name or partial name.
        dataset : str, optional
            Filter by dataset code.
        frequency : str, optional
            'ANNUAL' or 'MONTHLY'.
        limit : int
            Maximum number of results (default: 30).

        Returns
        -------
        DataFrame with columns: series_code, dataset, country, label,
        frequency, unit, magnitude, last_date, nb_observations.

        Examples
        --------
        >>> b.search('inflation')
        >>> b.search('PIB', country='SENEGAL')
        >>> b.search('dollar', frequency='MONTHLY')
        """
        return self._impl.search(query, country=country, dataset=dataset,
                                 frequency=frequency, limit=limit)

    # ─── Internal (used by API routers) ───────────────────────────────────────

    def _resolve_series(self, dataset: str, indicator: str, country: str) -> str:
        """Resolve (dataset, indicator, country) to a unique series_code."""
        return self._impl.resolve_series(dataset, indicator, country)

    # ─── Repr ─────────────────────────────────────────────────────────────────

    def __repr__(self) -> str:
        return f"<BCEAO backend={self._impl!r}>"
