"""Smoothing the way from diagramming to programming"""
