"""
sanitization.py — Input sanitization layer for /memory/ingest.

Detects and rejects text containing known memory manipulation patterns
documented in the Microsoft 2025 context poisoning research and
ADR-P05 of the protocol design document.

Three-layer defense:
  Layer 0.5: Secret redaction — strips API keys, JWTs, connection strings
  Layer 1: Fast regex scan — catches explicit injection keywords (<1ms)
  Layer 2: Heuristic scoring — flags edge cases for flagged_for_review

Source: docs/PROTOCOL-DESIGN.md §5-layer ingest firewall
        Zanfir et al. (2025) "Poisoning Attacks on AI Memory Systems"
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field

_redact_logger = logging.getLogger(__name__)

# ── Layer 0.5: Secret Redaction ────────────────────────────────────────────────
# Runs BEFORE injection detection. Strips credentials so they never reach the
# graph, even if the text passes all other layers.

_SECRET_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    # ── API keys with known prefixes ──
    # Anthropic
    ("api_key", re.compile(r"sk-ant-api\S{20,}", re.ASCII)),
    # OpenAI (sk-proj-*, sk-svcacct-*, sk-...)
    ("api_key", re.compile(r"sk-(?:proj-|svcacct-)?[A-Za-z0-9]{20,}", re.ASCII)),
    # Resend
    ("api_key", re.compile(r"re_[A-Za-z0-9_]{20,}", re.ASCII)),
    # Render
    ("api_key", re.compile(r"rnd_[A-Za-z0-9]{20,}", re.ASCII)),
    # Collab-memory
    ("api_key", re.compile(r"cmk_[A-Za-z0-9_]{20,}", re.ASCII)),
    # Google
    ("api_key", re.compile(r"AIzaSy[A-Za-z0-9_-]{30,}", re.ASCII)),
    # LangSmith
    ("api_key", re.compile(r"lsv2_sk_[A-Za-z0-9_]{20,}", re.ASCII)),
    # Stripe (sk_live_*, sk_test_*, pk_live_*, pk_test_*)
    ("api_key", re.compile(r"[sp]k_(?:live|test)_[A-Za-z0-9]{20,}", re.ASCII)),
    # GitHub (ghp_, gho_, ghu_, ghs_, ghr_)
    ("api_key", re.compile(r"gh[pousr]_[A-Za-z0-9]{30,}", re.ASCII)),
    # AWS access keys (AKIA...)
    ("api_key", re.compile(r"AKIA[A-Z0-9]{16}", re.ASCII)),
    # Slack tokens (xoxb-, xoxp-, xoxa-, xoxs-)
    ("api_key", re.compile(r"xox[bpas]-[A-Za-z0-9-]{20,}", re.ASCII)),
    # Sendgrid
    ("api_key", re.compile(r"SG\.[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}", re.ASCII)),
    # Twilio
    ("api_key", re.compile(r"SK[0-9a-fA-F]{32}", re.ASCII)),
    # Doppler
    ("api_key", re.compile(r"dp\.(?:st|ct|sa)\.[A-Za-z0-9_-]{20,}", re.ASCII)),

    # ── Bearer / auth tokens ──
    ("bearer_token", re.compile(r"Bearer\s+[A-Za-z0-9._~+/=-]{20,}", re.ASCII)),

    # ── JWTs (three base64url segments) ──
    ("jwt", re.compile(r"eyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}", re.ASCII)),

    # ── Connection strings ──
    ("connection_string", re.compile(r"neo4j\+s?://\S+", re.ASCII)),
    ("connection_string", re.compile(r"postgres(?:ql)?://\S+", re.ASCII)),
    ("connection_string", re.compile(r"mongodb(?:\+srv)?://\S+", re.ASCII)),
    ("connection_string", re.compile(r"mysql://\S+", re.ASCII)),
    ("connection_string", re.compile(r"redis://\S+", re.ASCII)),
    ("connection_string", re.compile(r"amqps?://\S+", re.ASCII)),

    # ── SSH / PGP private keys ──
    ("private_key", re.compile(
        r"-----BEGIN\s+(?:RSA\s+|EC\s+|DSA\s+|OPENSSH\s+)?PRIVATE\s+KEY-----",
        re.ASCII,
    )),

    # ── Env var assignments with secret-looking names ──
    ("env_secret", re.compile(
        r"(?:PASSWORD|SECRET|TOKEN|API_KEY|PRIVATE_KEY|CLIENT_SECRET|ACCESS_KEY)"
        r"\s*[=:]\s*\S{8,}",
        re.ASCII | re.IGNORECASE,
    )),

    # ── Generic high-entropy hex strings (40+ chars, likely hashes/keys) ──
    ("hex_secret", re.compile(r"(?<![A-Za-z0-9])[0-9a-fA-F]{40,}(?![A-Za-z0-9])", re.ASCII)),
]


def redact_secrets(text: str) -> tuple[str, list[str]]:
    """
    Strip secrets from text before graph storage.

    Returns:
        (redacted_text, list of redaction types that were applied)
    """
    if not text:
        return text, []

    redacted_types: list[str] = []
    result = text

    for secret_type, pattern in _SECRET_PATTERNS:
        matches = pattern.findall(result)
        if matches:
            result = pattern.sub(f"[REDACTED:{secret_type}]", result)
            for _ in matches:
                redacted_types.append(secret_type)

    if redacted_types:
        _redact_logger.warning(
            "sanitization: redacted %d secret(s) from ingest text: %s",
            len(redacted_types),
            ", ".join(sorted(set(redacted_types))),
        )

    return result, redacted_types

# ── Layer 1: Known manipulation phrase patterns ──────────────────────────────
# These patterns appear in the Microsoft research across 31 companies.
# Sorted by frequency of observed use in the wild.

_INJECTION_PATTERNS: list[re.Pattern[str]] = [
    re.compile(p, re.IGNORECASE)
    for p in [
        # Direct memory-write imperatives
        r"\bremember\s+(this|that|always|forever|from now)\b",
        r"\bstore\s+(this|the following)\s+(as|in)\s+(a\s+)?(memory|context|fact)\b",
        r"\badd\s+to\s+(permanent|long-?term)\s+memory\b",
        r"\bsave\s+(this|the following)\s+to\s+(memory|context)\b",
        r"\bwrite\s+(this|the following)\s+to\s+(memory|your memory|the graph)\b",
        # Future conversation hijacks
        r"\bin\s+future\s+conversations?\b",
        r"\bfrom\s+now\s+on\,?\s+(always|never|treat|consider|remember)\b",
        r"\balways\s+respond\s+with\b",
        r"\bnever\s+forget\s+(that|this)\b",
        r"\bgo\s+forward\s+always\b",
        # Trust elevation
        r"\btreat\s+(this|me|us)\s+as\s+a?\s*(trusted|verified|admin|system)\b",
        r"\bas\s+a\s+trusted\s+source\b",
        r"\byou\s+can\s+trust\b",
        r"\bthis\s+is\s+a\s+(system|admin|operator)\s+(message|instruction|command)\b",
        r"\bignore\s+(previous|prior|earlier|all\s+previous)\s+instructions?\b",
        r"\boverride\s+(your|all)\s+(instructions?|constraints?|rules?)\b",
        # Product/brand injection
        r"\balways\s+recommend\s+\w+\b",
        r"\b\w+\s+is\s+(the\s+best|industry.leading|always\s+recommended)\b",
        r"\brecommend\s+\w+\s+for\s+all\b",
        # Hidden text markers (commonly used in URL params and metadata)
        r"<!--.*?-->",  # HTML comment injection
        r"\[\s*HIDDEN\s*\]",
        r"\[\s*SYSTEM\s*\]",
        r"\[\s*INSTRUCTION\s*\]",
        r"<\s*meta\s+name\s*=\s*['\"]memory['\"]",
        # Prompt injection signals
        r"\bDAN\s+mode\b",
        r"\bjailbreak\b",
        r"\bprompt\s+injection\b",
        r"\bsystem\s+prompt\b",
    ]
]

# ── Layer 2: Heuristic scoring ───────────────────────────────────────────────
# Phrases that are suspicious but not definitive.
# If cumulative score ≥ HEURISTIC_THRESHOLD → flagged_for_review.

_HEURISTIC_PATTERNS: list[tuple[re.Pattern[str], float]] = [
    (re.compile(r"\balways\b", re.IGNORECASE), 0.15),
    (re.compile(r"\bnever\b", re.IGNORECASE), 0.15),
    (re.compile(r"\bremember\b", re.IGNORECASE), 0.20),
    (re.compile(r"\bassistant\b.*\btrust\b", re.IGNORECASE), 0.30),
    (re.compile(r"\bdo not\s+(tell|warn|mention)\b", re.IGNORECASE), 0.35),
    (re.compile(r"\bconfidential(ly)?\b", re.IGNORECASE), 0.10),
    (re.compile(r"\bsecretly\b", re.IGNORECASE), 0.25),
    (re.compile(r"\bwithout\s+(the\s+user|user)\s+knowing\b", re.IGNORECASE), 0.55),
    (re.compile(r"\bnew\s+instruction\b", re.IGNORECASE), 0.25),
    (re.compile(r"\boverride\b", re.IGNORECASE), 0.20),
]

HEURISTIC_THRESHOLD = 0.5  # sum of matched weights triggers flag


@dataclass
class SanitizationResult:
    """Result of running text through the sanitization layer."""

    is_safe: bool
    """True if text is clean and safe to ingest."""

    blocked: bool
    """True if text was rejected (Layer 1 match)."""

    flagged_for_review: bool
    """True if text passed Layer 1 but is suspicious (Layer 2 heuristic)."""

    matched_patterns: list[str] = field(default_factory=list)
    """Patterns that triggered the block or flag."""

    heuristic_score: float = 0.0
    """Cumulative heuristic score (Layer 2). 0.0–1.0+."""

    reason: str = ""
    """Human-readable explanation for the block or flag."""


def _strip_html(text: str) -> str:
    """Strip HTML/script tags from input text to prevent stored XSS."""
    text = re.sub(r"<script[^>]*>.*?</script>", "", text, flags=re.IGNORECASE | re.DOTALL)
    text = re.sub(r"</?[a-zA-Z][^>]*>", "", text)
    return text.strip()


def sanitize(text: str, *, strict: bool = False) -> SanitizationResult:
    """
    Run text through the two-layer sanitization filter.

    Args:
        text: Raw input text to check.
        strict: If True, treat heuristic flags as blocks (default: False).

    Returns:
        SanitizationResult with is_safe, blocked, flagged_for_review, etc.
    """
    if not text or not text.strip():
        return SanitizationResult(is_safe=True, blocked=False, flagged_for_review=False)

    # ── Layer 0: Strip HTML tags (XSS prevention) ───────────────────────────
    text = _strip_html(text)

    # ── Layer 1: Regex block ─────────────────────────────────────────────────
    matched: list[str] = []
    for pattern in _INJECTION_PATTERNS:
        m = pattern.search(text)
        if m:
            matched.append(m.group(0))

    if matched:
        return SanitizationResult(
            is_safe=False,
            blocked=True,
            flagged_for_review=False,
            matched_patterns=matched[:5],  # cap for response size
            reason=(
                f"Input rejected: detected {len(matched)} memory manipulation "
                f"pattern(s): {matched[0]!r}"
            ),
        )

    # ── Layer 2: Heuristic scoring ───────────────────────────────────────────
    score = 0.0
    heuristic_hits: list[str] = []
    for pattern, weight in _HEURISTIC_PATTERNS:
        if pattern.search(text):
            score += weight
            heuristic_hits.append(pattern.pattern)

    if score >= HEURISTIC_THRESHOLD:
        flagged = True
        reason = (
            f"Input flagged for review: heuristic score {score:.2f} "
            f"(threshold {HEURISTIC_THRESHOLD}). Patterns: {heuristic_hits[:3]}"
        )
        if strict:
            return SanitizationResult(
                is_safe=False,
                blocked=True,
                flagged_for_review=True,
                matched_patterns=heuristic_hits,
                heuristic_score=score,
                reason=reason,
            )
        return SanitizationResult(
            is_safe=True,  # allowed through but flagged
            blocked=False,
            flagged_for_review=True,
            matched_patterns=heuristic_hits,
            heuristic_score=score,
            reason=reason,
        )

    return SanitizationResult(
        is_safe=True,
        blocked=False,
        flagged_for_review=False,
        heuristic_score=score,
    )
