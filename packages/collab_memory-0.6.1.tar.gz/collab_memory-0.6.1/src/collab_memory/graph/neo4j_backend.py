"""
graph/neo4j_backend.py — Direct Neo4j / AuraDB backend for collab-memory.

Uses the official `neo4j` Python driver directly (no graphiti-core required),
making it ideal for Neo4j AuraDB Free tier or any hosted Neo4j instance.

Usage:
    pip install neo4j
    export GRAPH_BACKEND=neo4j
    export NEO4J_URI=neo4j+s://xxxxxxxx.databases.neo4j.io
    export NEO4J_USER=neo4j
    export NEO4J_PASSWORD=your-aura-password

AuraDB Free signup: https://neo4j.com/cloud/platform/aura-graph-database/
"""

from __future__ import annotations

import logging
import os
import uuid
from datetime import datetime, timezone
from typing import Any, Optional

logger = logging.getLogger(__name__)

from ..schema import (
    Session, Entity, Decision, Attempt, Constraint, Preference,
    ExchangeRecord, Edge,
    PreferenceType, ConstraintOrigin, WORTHINESS_THRESHOLD,
)
from .base import GraphBackend

_NEO4J_AVAILABLE = False
try:
    from neo4j import GraphDatabase
    _NEO4J_AVAILABLE = True
except ImportError:
    pass

# ── Cypher injection prevention (OWASP A03:2021) ────────────────────────────
# Neo4j parameters ($param) cannot be used for labels — they must be interpolated.
# This whitelist ensures only known node types are ever used in Cypher label positions.
VALID_NODE_LABELS: frozenset[str] = frozenset({
    "Decision", "Constraint", "Preference", "Attempt", "Episode", "Agent",
    "Project", "Skill", "AtomicFact", "ExchangeRecord", "Entity", "Session",
    "Tenant", "User", "Task", "Sprint", "CommunicationEvent", "Artifact",
    "SocialIdentity", "AuthAudit", "ProjectInvite", "Edge",
})


def _validate_label(label: str) -> str:
    """Validate a node label against the whitelist. Raises ValueError on invalid input."""
    if label not in VALID_NODE_LABELS:
        raise ValueError(f"Invalid node label: {label!r}. Must be one of: {sorted(VALID_NODE_LABELS)}")
    return label


class Neo4jBackend(GraphBackend):
    """
    GraphBackend implementation using the official Neo4j Python driver.

    Compatible with:
    - Neo4j AuraDB Free (neo4j+s://...)
    - Local Neo4j Desktop (bolt://localhost:7687)
    - Neo4j Enterprise

    All data is stored as Cypher nodes/relationships.
    Decision, Constraint, Preference, Attempt nodes are each a label.
    """

    def __init__(
            self,
            uri: str | None = None,
            user: str | None = None,
            password: str | None = None,
            database: str | None = None,
    ):
        # Read credentials from env vars at instantiation time (not import time)
        uri = uri or os.getenv("NEO4J_URI", "bolt://localhost:7687")
        user = user or os.getenv("NEO4J_USER", "neo4j")
        password = password or os.getenv("NEO4J_PASSWORD", "password")
        database = database or os.getenv("NEO4J_DB", "neo4j")

        if not _NEO4J_AVAILABLE:
            raise ImportError(
                "neo4j driver is not installed. Run: pip install neo4j"
            )
        self._driver = GraphDatabase.driver(
            uri,
            auth=(user, password),
            connection_timeout=15,
            max_transaction_retry_time=10,
            max_connection_pool_size=100,
            connection_acquisition_timeout=20,
            max_connection_lifetime=30 * 60,  # 30 min — AuraDB best practice
        )
        self._db = database
        self._ensure_constraints()

    def _ensure_constraints(self):
        """Create uniqueness constraints and HNSW vector indexes on first connect."""
        with self._driver.session(database=self._db) as session:
            for label in ("Decision", "Constraint", "Preference", "Attempt", "Session", "Project",
                          "AtomicFact", "Episode"):
                try:
                    session.run(
                        f"CREATE CONSTRAINT IF NOT EXISTS FOR (n:{label}) REQUIRE n.id IS UNIQUE"
                    )
                except Exception:
                    pass  # Constraint may already exist

        # ── HNSW vector indexes ────────────────────────────────────────────────
        # Create one HNSW index per node type that stores embeddings.
        # Detect actual embedding dimensions by generating a test embedding.
        # Without this index, semantic_search() falls back to BM25.
        _HNSW_LABELS = ("Decision", "Constraint", "Preference", "Attempt",
                        "AtomicFact", "Episode", "Skill")
        try:
            from ..embeddings import generate_embedding
            _test_vec = generate_embedding("test dimension detection")
            _dims = len(_test_vec) if _test_vec else 768
        except Exception:
            _dims = 768
        logger.info("HNSW indexes: using %d dimensions", _dims)

        with self._driver.session(database=self._db) as session:
            for label in _HNSW_LABELS:
                idx_name = f"idx_vector_{label.lower()}"
                try:
                    # Drop existing index if dimension changed
                    session.run(f"DROP INDEX {idx_name} IF EXISTS")
                except Exception:
                    pass
                try:
                    session.run(
                        f"""
                        CREATE VECTOR INDEX {idx_name} IF NOT EXISTS
                        FOR (n:{label}) ON (n.embedding)
                        OPTIONS {{indexConfig: {{
                          `vector.dimensions`: {_dims},
                          `vector.similarity_function`: 'cosine'
                        }}}}
                        """
                    )
                except Exception:
                    pass  # AuraDB may not support this version — BM25 fallback active

    def _tx_write(self, query: str, **params):
        with self._driver.session(database=self._db) as session:
            session.run(query, **params)

    def _tx_read(self, query: str, **params) -> list[dict]:
        with self._driver.session(database=self._db) as session:
            result = session.run(query, **params)
            return [dict(r) for r in result]

    # ── Cognitive Dreams: recall reinforcement ──────────────────────────────
    def reinforce_nodes(self, node_ids: list[str]) -> int:
        """
        Increment recall_count and update last_recalled on retrieved nodes.

        This is the Cognitive Dreams reinforcement signal: every retrieval
        strengthens the node's position in the graduation ladder.
        Preferences use reinforcement_count (legacy field name).

        Returns the number of nodes actually updated.
        """
        if not node_ids:
            return 0
        try:
            import datetime as _dt
            now = _dt.datetime.now(_dt.timezone.utc).isoformat()
            # Single batch Cypher — works regardless of node label
            result = self._tx_read(
                """
                UNWIND $ids AS nid
                MATCH (n) WHERE n.id = nid
                SET n.recall_count = COALESCE(n.recall_count, 0) + 1,
                    n.reinforcement_count = COALESCE(n.reinforcement_count, 0) + 1,
                    n.last_recalled = $now,
                    n.last_reinforced = $now
                RETURN count(n) AS updated
                """,
                ids=node_ids,
                now=now,
            )
            return result[0]["updated"] if result else 0
        except Exception as e:
            logger.warning("reinforce_nodes failed (non-fatal): %s", e)
            return 0

    def safe_write(
        self,
        node_id: str,
        node_type: str,
        updates: dict,
        expected_version: int,
        agent_id: str = "agent",
        project_id: str | None = None,
    ) -> dict:
        """
        Optimistic-lock write: only updates the node if its current version
        matches expected_version. On mismatch, writes a ConflictEvent instead
        of silently overwriting.

        Returns:
            {"ok": True, "version": new_version}         — on success
            {"ok": False, "conflict_id": str, ...}       — on version conflict
        """
        from ..schema import ConflictEvent
        import datetime as _dt

        _validate_label(node_type)
        new_version = expected_version + 1
        set_parts = ", ".join(f"n.{k} = ${k}" for k in updates)
        set_parts += ", n.version = $new_version"

        # Attempt conditional write — only fires if version matches
        rows = self._tx_read(
            f"""
            MATCH (n:{node_type} {{id: $nid}})
            WHERE n.version = $expected OR n.version IS NULL
            SET {set_parts}
            RETURN n.version AS v, count(n) AS matched
            """,
            nid=node_id,
            expected=expected_version,
            new_version=new_version,
            **updates,
        )

        if rows and rows[0].get("matched", 0) > 0:
            return {"ok": True, "version": new_version}

        # Version mismatch — read current state and log conflict
        current = self._tx_read(
            f"MATCH (n:{node_type} {{id: $nid}}) RETURN n.version AS v LIMIT 1",
            nid=node_id,
        )
        current_version = current[0]["v"] if current else -1

        conflict = ConflictEvent(
            node_id=node_id,
            node_type=node_type,
            agent_a="unknown",          # whoever wrote the current version
            agent_b=agent_id,
            version_expected=expected_version,
            version_found=current_version,
            payload_b=updates,
            project_id=project_id,
        )
        self._tx_write(
            """
            CREATE (c:ConflictEvent {
                id: $id, node_id: $node_id, node_type: $node_type,
                agent_a: $agent_a, agent_b: $agent_b,
                version_expected: $ve, version_found: $vf,
                payload_b: $pb, status: 'pending',
                created_at: $ts, project_id: $pid
            })
            """,
            id=conflict.id,
            node_id=node_id,
            node_type=node_type,
            agent_a=conflict.agent_a,
            agent_b=agent_id,
            ve=expected_version,
            vf=current_version,
            pb=str(updates),
            ts=_dt.datetime.utcnow().isoformat(),
            pid=project_id or "",
        )
        return {
            "ok": False,
            "conflict_id": conflict.id,
            "version_expected": expected_version,
            "version_found": current_version,
        }

    # ─── Automatic Versioning ─────────────────────────────────────────────────

    def supersede_node(
        self,
        old_id: str,
        new_id: str,
        node_type: str,
        reason: str = "auto",
    ) -> None:
        """
        Mark an existing node as superseded and create a SUPERSEDED_BY edge.

        This is the core versioning primitive. When a new node replaces an old
        one, call this to:
        1. Set is_superseded=true and status='superseded' on the old node
        2. Create a SUPERSEDED_BY edge from old → new
        3. Set invalid_at on the old node (bi-temporal close)

        Works for Decision, Constraint, Preference, and any other versioned type.
        """
        _validate_label(node_type)
        now_str = datetime.now(timezone.utc).isoformat()
        # Mark old node as superseded
        self._tx_write(
            f"""
            MATCH (old:{node_type} {{id: $old_id}})
            SET old.is_superseded = true,
                old.invalid_at = $now,
                old.superseded_by = $new_id,
                old.superseded_reason = $reason
            """,
            old_id=old_id, new_id=new_id, now=now_str, reason=reason,
        )
        # Also set status='superseded' for Decision nodes
        if node_type == "Decision":
            self._tx_write(
                "MATCH (old:Decision {id: $old_id}) SET old.status = 'superseded'",
                old_id=old_id,
            )
        # Create SUPERSEDED_BY edge
        edge_id = f"edg_{uuid.uuid4().hex[:8]}"
        self._tx_write(
            f"""
            MATCH (old:{node_type} {{id: $old_id}})
            MATCH (new:{node_type} {{id: $new_id}})
            MERGE (old)-[r:SUPERSEDED_BY]->(new)
            SET r.id = $eid, r.created_at = $now, r.reason = $reason
            """,
            old_id=old_id, new_id=new_id, eid=edge_id, now=now_str, reason=reason,
        )
        logger.info(
            "Versioning: %s %s superseded by %s (reason=%s)",
            node_type, old_id, new_id, reason,
        )

    def _find_semantic_duplicate(
        self,
        node_type: str,
        description: str,
        project_id: str | None,
        module: str = "",
        exclude_id: str = "",
    ) -> str | None:
        """
        Find an existing active node of the same type with identical or
        near-identical description within the same project+module scope.

        Returns the node id if a duplicate is found, None otherwise.

        This enables automatic versioning: when an agent writes a Decision
        that matches an existing one, the old one gets superseded automatically
        instead of creating duplicates or leaving stale versions active.
        """
        if not description or len(description) < 10:
            return None

        # Exact match first — fast path
        clauses = [
            f"n.project_id = $pid",
            "(n.is_superseded IS NULL OR n.is_superseded = false)",
        ]
        params: dict[str, Any] = {"pid": project_id or "default"}

        if module:
            clauses.append("n.module = $module")
            params["module"] = module

        if exclude_id:
            clauses.append("n.id <> $exclude_id")
            params["exclude_id"] = exclude_id

        # Exact description match
        clauses.append("n.description = $desc")
        params["desc"] = description

        where = " AND ".join(clauses)
        rows = self._tx_read(
            f"MATCH (n:{node_type}) WHERE {where} RETURN n.id AS id LIMIT 1",
            **params,
        )
        if rows:
            return rows[0]["id"]

        # Prefix match — catches minor edits to the same decision
        # e.g. "Use Neo4j for graph storage" vs "Use Neo4j for graph storage (AuraDB)"
        if len(description) > 30:
            prefix = description[:60]
            params_prefix = dict(params)
            params_prefix.pop("desc", None)
            clauses_prefix = [c for c in clauses if "n.description" not in c]
            clauses_prefix.append("n.description STARTS WITH $prefix")
            params_prefix["prefix"] = prefix
            where_prefix = " AND ".join(clauses_prefix)
            rows = self._tx_read(
                f"MATCH (n:{node_type}) WHERE {where_prefix} RETURN n.id AS id LIMIT 1",
                **params_prefix,
            )
            if rows:
                return rows[0]["id"]

        return None

    def get_version_chain(self, node_id: str, node_type: str = "Decision", tenant_id: str = "default") -> list[dict]:
        """
        Walk the SUPERSEDED_BY chain for a node and return the full version
        history, oldest first.

        Returns a list of dicts with id, description, version, created_at,
        is_superseded, superseded_by, and superseded_reason.
        """
        # Walk backwards to find the root
        rows = self._tx_read(
            f"""
            MATCH path = (root:{node_type})-[:SUPERSEDED_BY*0..20]->(n:{node_type} {{id: $nid}})
            WHERE NOT ()-[:SUPERSEDED_BY]->(root)
              AND n.tenant_id = $tid
            UNWIND nodes(path) AS node
            RETURN DISTINCT node.id AS id,
                   node.description AS description,
                   node.version AS version,
                   node.created_at AS created_at,
                   node.is_superseded AS is_superseded,
                   node.superseded_by AS superseded_by,
                   node.superseded_reason AS superseded_reason
            ORDER BY node.created_at ASC
            """,
            nid=node_id, tid=tenant_id,
        )
        if rows:
            return [dict(r) for r in rows]

        # If no chain found, just return the node itself
        single = self._tx_read(
            f"""
            MATCH (n:{node_type} {{id: $nid}})
            RETURN n.id AS id, n.description AS description,
                   n.version AS version, n.created_at AS created_at,
                   n.is_superseded AS is_superseded,
                   n.superseded_by AS superseded_by,
                   n.superseded_reason AS superseded_reason
            """,
            nid=node_id,
        )
        return [dict(r) for r in single] if single else []

    def ingest_result(self, result) -> None:
        """Store ClassificationResult and create cross-node RELATES_TO edges.

        Extends base.ingest_result to wire together nodes that came from the
        same exchange — Decision ↔ Constraint ↔ Preference — so graph traversal
        returns a connected subgraph rather than isolated nodes.
        """
        from ..schema import ClassificationResult as CR
        self.save_exchange_record(result.exchange_record)
        for node in result.nodes:
            self.save_node(node)
        for edge in result.edges:
            self.save_edge(edge)

        # Create RELATES_TO edges between all co-occurring nodes (same exchange)
        nodes = result.nodes
        if len(nodes) >= 2:
            for i, a in enumerate(nodes):
                for b in nodes[i + 1:]:
                    try:
                        self._tx_write(
                            """
                            MATCH (a {id: $aid}), (b {id: $bid})
                            MERGE (a)-[r:RELATES_TO {id: $rid}]->(b)
                            SET r.type = 'CO_OCCURS',
                                r.exchange_id = $exchange_id,
                                r.created_at = $created_at
                            """,
                            aid=a.id,
                            bid=b.id,
                            rid=f"rel_{a.id[:8]}_{b.id[:8]}",
                            exchange_id=result.exchange_record.id,
                            created_at=str(datetime.now(timezone.utc)),
                        )
                    except Exception:
                        pass  # never block an ingest over an edge write failure

    # ─── Write methods ────────────────────────────────────────────────────────

    def save_session(self, session: Session) -> None:
        self._tx_write(
            """
            MERGE (s:Session {id: $id})
            SET s.title = $title,
                s.started_at = $started_at,
                s.updated_at = $updated_at
            """,
            id=session.id,
            title=session.title or session.id,
            started_at=str(session.started_at or datetime.now(timezone.utc)),
            updated_at=str(datetime.now(timezone.utc)),
        )

    def save_exchange_record(self, record: ExchangeRecord) -> None:
        # Use getattr with fallbacks — field presence varies across schema versions
        ptype = getattr(record, "primitive_type", None)
        ptype_val = ptype.value if hasattr(ptype, "value") else str(ptype or "Exploration")
        self._tx_write(
            """
            MERGE (e:ExchangeRecord {id: $id})
            ON CREATE SET e.processed = false
            SET e.session_id = $session_id,
                e.raw_text = $raw_text,
                e.primitive_type = $primitive_type,
                e.worthiness_score = $worthiness_score,
                e.should_encode = $should_encode,
                e.flagged_for_review = $flagged,
                e.project_id = $project_id,
                e.created_at = $created_at
            """,
            id=record.id,
            session_id=getattr(record, "session_id", "unknown"),
            raw_text=getattr(record, "raw_text", "") or "",
            primitive_type=ptype_val,
            worthiness_score=getattr(record, "worthiness_score", 0.0),
            should_encode=getattr(record, "should_encode", False),
            flagged=getattr(record, "flagged_for_review", False),
            project_id=getattr(record, "project_id", None) or "default",
            created_at=str(getattr(record, "created_at", None) or datetime.now(timezone.utc)),
        )

    # ── Tenant methods ────────────────────────────────────────────────────────

    def create_tenant(self, tenant) -> None:
        """Write a Tenant node. Keys are stored in plaintext (graph is private infra)."""
        self._tx_write(
            """
            MERGE (t:Tenant {id: $id})
            SET t.name = $name,
                t.email = $email,
                t.plan = $plan,
                t.status = $status,
                t.api_key_write = $api_key_write,
                t.api_key_read  = $api_key_read,
                t.owner_id      = $owner_id,
                t.created_at    = $created_at
            """,
            id=tenant.id,
            name=tenant.name,
            email=getattr(tenant, "email", ""),
            plan=tenant.plan.value if hasattr(tenant.plan, "value") else str(tenant.plan),
            status=getattr(tenant, "status", "active"),
            api_key_write=tenant.api_key_write,
            api_key_read=tenant.api_key_read,
            owner_id=getattr(tenant, "owner_id", ""),
            created_at=str(tenant.created_at),
        )

    def get_tenant(self, tenant_id: str) -> dict | None:
        """Fetch a tenant by ID. Returns dict or None."""
        rows = self._tx_read(
            "MATCH (t:Tenant {id: $id}) RETURN t", id=tenant_id
        )
        if not rows:
            return None
        node = rows[0]["t"]
        return dict(node)

    def get_tenant_by_key(self, api_key: str) -> dict | None:
        """Look up a tenant by either write or read API key. Returns dict or None."""
        rows = self._tx_read(
            """
            MATCH (t:Tenant)
            WHERE t.api_key_write = $key OR t.api_key_read = $key
            RETURN t, (t.api_key_write = $key) AS is_write
            """,
            key=api_key,
        )
        if not rows:
            return None
        node = dict(rows[0]["t"])
        node["_is_write_key"] = rows[0]["is_write"]
        return node

    def list_tenants(self, limit: int = 100) -> list[dict]:
        """List all tenants (admin only)."""
        rows = self._tx_read(
            "MATCH (t:Tenant) WHERE t.status <> 'deleted' RETURN t ORDER BY t.created_at DESC LIMIT $lim",
            lim=limit,
        )
        return [dict(r["t"]) for r in rows]

    def save_project(self, project) -> None:
        """Write a Project node to the graph (Sprint 23: with tenant + ownership)."""
        import json
        members = getattr(project, "members", []) or []
        self._tx_write(
            """
            MERGE (p:Project {id: $id})
            SET p.name = $name,
                p.description = $description,
                p.tenant_id = $tenant_id,
                p.owner_id = $owner_id,
                p.members = $members,
                p.status = $status,
                p.tags = $tags,
                p.created_at = $created_at,
                p.updated_at = $updated_at
            """,
            id=project.id,
            name=project.name,
            description=getattr(project, "description", "") or "",
            tenant_id=getattr(project, "tenant_id", "default"),
            owner_id=getattr(project, "owner_id", "") or "",
            members=json.dumps(members),
            status=getattr(project, "status", "active"),
            tags=getattr(project, "tags", []) or [],
            created_at=str(getattr(project, "created_at", None) or datetime.now(timezone.utc)),
            updated_at=str(datetime.now(timezone.utc)),
        )

    def get_projects(self, tenant_id: str = "default") -> list[dict]:
        """Return Project nodes scoped to tenant, with memory counts included."""
        rows = self._tx_read(
            """
            MATCH (p:Project)
            WHERE p.tenant_id = $tid
            AND (p.status IS NULL OR p.status <> 'deleted')
            OPTIONAL MATCH (d:Decision) WHERE d.project_id = p.id
            OPTIONAL MATCH (c:Constraint) WHERE c.project_id = p.id
            OPTIONAL MATCH (pr:Preference) WHERE pr.project_id = p.id
            RETURN p,
                   count(DISTINCT d) AS decision_count,
                   count(DISTINCT c) AS constraint_count,
                   count(DISTINCT pr) AS preference_count
            ORDER BY p.name
            """,
            tid=tenant_id,
        )
        results = []
        for r in rows:
            proj = dict(r["p"])
            proj["decision_count"] = r.get("decision_count", 0)
            proj["constraint_count"] = r.get("constraint_count", 0)
            proj["preference_count"] = r.get("preference_count", 0)
            proj["memory_count"] = (
                proj["decision_count"] + proj["constraint_count"] + proj["preference_count"]
            )
            results.append(proj)
        return results

    def get_project(self, project_id: str, tenant_id: str = "default") -> dict | None:
        """Return a single Project node by ID, scoped to tenant."""
        rows = self._tx_read(
            "MATCH (p:Project {id: $pid}) "
            "WHERE p.tenant_id = $tid "
            "RETURN p",
            pid=project_id, tid=tenant_id,
        )
        return dict(rows[0]["p"]) if rows else None

    # ─── Artifact CRUD ────────────────────────────────────────────────────────

    MAX_INLINE_BYTES = 100_000  # Store content inline if < 100KB

    def save_artifact(self, artifact) -> None:
        """Write an Artifact node to the graph. Stores content inline up to 100KB."""
        content = getattr(artifact, "content", "") or ""
        store_inline = len(content.encode()) < self.MAX_INLINE_BYTES
        self._tx_write(
            """
            MERGE (a:Artifact {id: $id})
            SET a.name = $name,
                a.artifact_type = $artifact_type,
                a.mime_type = $mime_type,
                a.content = $content,
                a.content_base64 = $content_base64,
                a.path = $path,
                a.git_ref = $git_ref,
                a.size_bytes = $size_bytes,
                a.session_id = $session_id,
                a.project_id = $project_id,
                a.tenant_id = $tenant_id,
                a.created_by = $created_by,
                a.description = $description,
                a.tags = $tags,
                a.preview_url = $preview_url,
                a.created_at = $created_at,
                a.updated_at = $updated_at
            """,
            id=artifact.id,
            name=artifact.name,
            artifact_type=getattr(artifact.artifact_type, "value", str(artifact.artifact_type)),
            mime_type=getattr(artifact, "mime_type", "text/plain"),
            content=content if store_inline else "",
            content_base64=getattr(artifact, "content_base64", False),
            path=getattr(artifact, "path", ""),
            git_ref=getattr(artifact, "git_ref", ""),
            size_bytes=len(content.encode()),
            session_id=getattr(artifact, "session_id", ""),
            project_id=getattr(artifact, "project_id", None) or "default",
            tenant_id=getattr(artifact, "tenant_id", "default"),
            created_by=getattr(artifact, "created_by", "agent"),
            description=getattr(artifact, "description", ""),
            tags=getattr(artifact, "tags", []),
            preview_url=getattr(artifact, "preview_url", ""),
            created_at=str(getattr(artifact, "created_at", None) or datetime.now(timezone.utc)),
            updated_at=str(datetime.now(timezone.utc)),
        )

    def get_artifacts(
        self,
        project_id: str | None = None,
        artifact_type: str | None = None,
        session_id: str | None = None,
        limit: int = 50,
        tenant_id: str = "default",
    ) -> list[dict]:
        """List artifacts, optionally filtered by project/type/session."""
        clauses = ["a.tenant_id = $tid"]
        params: dict = {"limit": limit, "tid": tenant_id}
        if project_id:
            clauses.append("(a.project_id = $pid OR a.project_id IS NULL)")
            params["pid"] = project_id
        if artifact_type:
            clauses.append("a.artifact_type = $atype")
            params["atype"] = artifact_type
        if session_id:
            clauses.append("a.session_id = $sid")
            params["sid"] = session_id
        where = "WHERE " + " AND ".join(clauses)
        query = f"MATCH (a:Artifact) {where} RETURN a ORDER BY a.updated_at DESC LIMIT $limit"
        rows = self._tx_read(query, **params)
        return [dict(r["a"]) for r in rows]

    def get_artifact(self, artifact_id: str) -> dict | None:
        """Fetch a single artifact by id (includes full content)."""
        rows = self._tx_read("MATCH (a:Artifact {id: $id}) RETURN a", id=artifact_id)
        return dict(rows[0]["a"]) if rows else None

    def delete_artifact(self, artifact_id: str) -> bool:
        """Delete an artifact node. Returns True if it existed."""
        rows = self._tx_read("MATCH (a:Artifact {id: $id}) RETURN count(a) AS n", id=artifact_id)
        if not rows or rows[0]["n"] == 0:
            return False
        self._tx_write("MATCH (a:Artifact {id: $id}) DETACH DELETE a", id=artifact_id)
        return True

    def save_node(self, node: Decision | Attempt | Constraint | Preference | Entity) -> None:
        label = type(node).__name__
        now_str = str(datetime.now(timezone.utc))
        props = {
            "id": node.id,
            "description": getattr(node, "description", "") or "",
            "session_id": getattr(node, "session_id", None) or getattr(node, "made_in", None) or "unknown",
            "project_id": getattr(node, "project_id", None) or "default",
            "tenant_id": getattr(node, "tenant_id", "default"),  # Sprint 23: tenant isolation
            "module": getattr(node, "module", "") or "",
            "category": getattr(node, "category", "") or "",
            "created_at": str(getattr(node, "created_at", None) or now_str),
            "created_by": getattr(node, "created_by", "agent"),  # Sprint 22b: audit attribution
            # ── Bi-temporal fields (Sprint 20.5) ──
            "valid_at": str(getattr(node, "valid_at", None) or now_str),
            "invalid_at": str(getattr(node, "invalid_at", "")) or "",
            "episode_id": getattr(node, "episode_id", "") or "",
            "decay_rate": getattr(node, "decay_rate", label) or label,
        }

        if isinstance(node, Decision):
            props["confidence"] = getattr(node, "confidence", None) or getattr(node, "worthiness_score", 0.7) or 0.7
            props["is_superseded"] = getattr(node, "is_superseded", False)
            props["rationale"] = getattr(node, "rationale", "") or ""
            status = getattr(node, "status", "active")
            props["status"] = status.value if hasattr(status, "value") else str(status or "active")
        elif isinstance(node, Constraint):
            origin = getattr(node, "origin", None)
            props["origin"] = origin.value if hasattr(origin, "value") else str(origin or "")
            props["active"] = getattr(node, "active", True)
            props["scope"] = getattr(node, "scope", "") or ""
        elif isinstance(node, Preference):
            ptype = getattr(node, "type", None)
            props["type"] = ptype.value if hasattr(ptype, "value") else str(ptype or "")
            props["confidence"] = getattr(node, "confidence", 0.5)
            props["reinforcement_count"] = getattr(node, "reinforcement_count", 0)
        elif isinstance(node, Attempt):
            props["abandoned"] = getattr(node, "abandoned", True)
            props["abandoned_because"] = getattr(node, "abandoned_because", "") or ""

        # ── Generate embedding for semantic search (Sprint S4) ─────────────────
        try:
            from ..embeddings import generate_embedding
            desc_text = props.get("description", "") or ""
            if desc_text:
                emb = generate_embedding(desc_text)
                if emb:
                    props["embedding"] = emb
        except Exception:
            pass  # Never block a node write for an embedding failure
        # ─────────────────────────────────────────────────────────────────────────

        assignments = ", ".join(f"n.{k} = ${k}" for k in props if k != "id")
        self._tx_write(
            f"MERGE (n:{label} {{id: $id}}) SET {assignments}",
            **props,
        )

        # ── Auto-versioning: supersede duplicate nodes automatically ────────
        # When writing a Decision, Constraint, or Preference, check if an
        # existing active node with the same description exists in the same
        # scope. If so, supersede the old one — the new write is the latest
        # version. This prevents stale duplicates from polluting agent context.
        if label in ("Decision", "Constraint", "Preference"):
            try:
                dup_id = self._find_semantic_duplicate(
                    node_type=label,
                    description=props.get("description", ""),
                    project_id=props.get("project_id"),
                    module=props.get("module", ""),
                    exclude_id=node.id,
                )
                if dup_id:
                    self.supersede_node(
                        old_id=dup_id,
                        new_id=node.id,
                        node_type=label,
                        reason="auto_duplicate_detection",
                    )
            except Exception as e:
                logger.debug("Auto-versioning check skipped: %s", e)
        # ─────────────────────────────────────────────────────────────────────

        # ── SSE: broadcast node creation to connected frontends ─────────────
        try:
            from ..api.sse import emit_event_sync
            emit_event_sync({
                "type": "node.created",
                "node": {
                    "id": node.id,
                    "type": label,
                    "label": (props.get("description", "") or "")[:80],
                    "confidence": props.get("confidence", 0.5),
                    "project_id": props.get("project_id"),
                    "created_by": props.get("created_by"),
                },
            })
        except Exception:
            pass  # Never block a write for SSE
        # ─────────────────────────────────────────────────────────────────────

    def save_pending(self, node: Decision | Attempt | Constraint | Preference | Entity) -> str:
        """
        Persist a pipeline-proposed node for HITL before it becomes active memory.
        Uses the same :PendingInference shape as POST /memory/queue_inference.
        """
        item_id = f"pnd_{uuid.uuid4().hex[:8]}"
        label = type(node).__name__
        description = getattr(node, "description", "") or ""
        session_id = (
            getattr(node, "made_in", None)
            or getattr(node, "surfaced_in", None)
            or getattr(node, "inferred_in", None)
            or getattr(node, "tried_in", None)
            or "unknown"
        )
        confidence = float(getattr(node, "confidence", 0.7) or 0.7)
        rationale = getattr(node, "rationale", None) or ""
        raw_text = description
        if rationale:
            raw_text = f"{description}\nRationale: {rationale}"
        raw_text = (raw_text or "")[:8000]
        now = datetime.now(timezone.utc).isoformat()
        project_id_val = getattr(node, "project_id", None) or "default"
        tenant_id_val = getattr(node, "tenant_id", "default") or "default"
        proposed_id = getattr(node, "id", "") or ""

        self._tx_write(
            """
            MERGE (n:PendingInference {id: $id})
            SET n.node_type = $node_type,
                n.description = $description,
                n.session_id = $session_id,
                n.confidence = $confidence,
                n.raw_text = $raw_text,
                n.origin = 'inferred',
                n.status = 'pending',
                n.created_at = $now,
                n.project_id = $project_id,
                n.tenant_id = $tenant_id,
                n.proposed_node_id = $proposed_node_id
            """,
            id=item_id,
            node_type=label,
            description=description,
            session_id=session_id,
            confidence=confidence,
            raw_text=raw_text,
            now=now,
            project_id=project_id_val,
            tenant_id=tenant_id_val,
            proposed_node_id=proposed_id,
        )
        return item_id

    def get_pending(
        self,
        project_id: Optional[str] = None,
        tenant_id: str | None = "default",
    ) -> list[dict]:
        """
        HITL queue: :PendingInference with status 'pending', plus typed nodes
        stuck in legacy pending_confirmation (Graph Writer experiments).
        """
        tid = tenant_id or "default"
        params: dict[str, Any] = {}
        q_pi = (
            "MATCH (n:PendingInference) WHERE n.status = 'pending' "
        )
        q_pi += "AND (n.tenant_id = $tid OR n.tenant_id IS NULL OR n.tenant_id = 'default') "
        params["tid"] = tid
        if project_id:
            q_pi += "AND (n.project_id = $pid OR n.project_id IS NULL OR n.project_id = 'default') "
            params["pid"] = project_id
        q_pi += "RETURN n ORDER BY n.created_at DESC LIMIT 50"
        rows_pi = self._tx_read(q_pi, **params)
        seen: set[str] = set()
        items: list[dict] = []
        for r in rows_pi:
            d = dict(r["n"])
            nid = d.get("id", "")
            if nid and nid not in seen:
                seen.add(nid)
                d.setdefault("node_type", d.get("node_type", "Decision"))
                items.append(d)

        q_pc = (
            "MATCH (n) WHERE NOT n:PendingInference AND n.status = 'pending_confirmation' "
            "AND any(l IN labels(n) WHERE l IN $labels) "
        )
        params2 = {"labels": ["Decision", "Constraint", "Preference", "Attempt"]}
        q_pc += "AND (n.tenant_id = $tid OR n.tenant_id IS NULL OR n.tenant_id = 'default') "
        params2["tid"] = tid
        if project_id:
            q_pc += "AND (n.project_id = $pid OR n.project_id IS NULL OR n.project_id = 'default') "
            params2["pid"] = project_id
        q_pc += "RETURN n, labels(n)[0] AS lbl ORDER BY coalesce(n.created_at, n.made_at, '') DESC LIMIT 50"
        rows_pc = self._tx_read(q_pc, **params2)
        for r in rows_pc:
            node = dict(r["n"])
            nid = node.get("id", "")
            if nid and nid not in seen:
                seen.add(nid)
                node["node_type"] = r.get("lbl", node.get("node_type", "Unknown"))
                items.append(node)
        return items

    def save_atomic_fact(self, fact, project_id: str | None = None, session_id: str | None = None) -> None:
        """
        Plan 2: Write an AtomicFact node WITHOUT project_id so it lives in the
        global permabank (cross-project semantic layer).

        Attribution is preserved via a [:SOURCED_FROM] edge to the Project node.
        This allows:
          - Global retrieval: MATCH (f:AtomicFact) with no project filter
          - Attribution query: MATCH (f:AtomicFact)-[:SOURCED_FROM]->(p:Project)

        Source: research_extended_topics.md §7 (mem0 pipeline memory scopes)
        """
        from datetime import datetime, timezone
        pid = project_id or getattr(fact, "project_id", None) or "default"
        sid = session_id or getattr(fact, "session_id", "unknown")
        content = getattr(fact, "content", getattr(fact, "description", "")) or ""
        fact_id = getattr(fact, "id", None) or str(uuid.uuid4())
        created_at = str(datetime.now(timezone.utc))

        props: dict = {
            "id": fact_id,
            "content": content,
            "type": getattr(fact, "type", "observation"),
            "confidence": float(getattr(fact, "confidence", 0.8)),
            "rationale": getattr(fact, "rationale", "") or "",
            "source_exchange": getattr(fact, "source_exchange", "")[:500],
            "session_id": sid,
            # NOTE: project_id intentionally NOT stored on node — see docstring above
            "created_at": created_at,
        }

        # Generate embedding for global semantic retrieval
        try:
            from ..embeddings import generate_embedding
            if content:
                emb = generate_embedding(content)
                if emb:
                    props["embedding"] = emb
        except Exception:
            pass

        assignments = ", ".join(f"n.{k} = ${k}" for k in props if k != "id")
        self._tx_write(
            f"MERGE (n:AtomicFact {{id: $id}}) SET {assignments}",
            **props,
        )

        # Create SOURCED_FROM edge to Project node for attribution
        try:
            self._tx_write(
                """
                MERGE (p:Project {id: $pid})
                ON CREATE SET p.name = $pid, p.created_at = $created_at
                WITH p
                MATCH (f:AtomicFact {id: $fact_id})
                MERGE (f)-[r:SOURCED_FROM]->(p)
                SET r.session_id = $sid,
                    r.created_at = $created_at
                """,
                pid=pid,
                fact_id=fact_id,
                sid=sid,
                created_at=created_at,
            )
        except Exception as e:
            logger.warning("save_atomic_fact: SOURCED_FROM edge failed (non-fatal): %s", e)

    def save_edge(self, edge: Edge) -> None:
        edge_type = edge.type
        edge_type_str = edge_type.value if hasattr(edge_type, "value") else str(edge_type or "RELATES_TO")
        self._tx_write(
            """
            MATCH (a {id: $source_id}), (b {id: $target_id})
            MERGE (a)-[r:RELATES_TO {id: $id, type: $type}]->(b)
            SET r.rationale = $rationale, r.created_at = $created_at
            """,
            id=edge.id,
            source_id=edge.source_id,
            target_id=edge.target_id,
            type=edge_type_str,
            rationale=getattr(edge, "rationale", "") or "",
            created_at=str(datetime.now(timezone.utc)),
        )

    def save_episode(self, episode) -> None:
        """
        Persist an Episode node (RAPTOR Layer 1 — session-level summary).

        Creates the Episode node, generates an embedding on the summary,
        and creates a [:FOLLOWS] edge from this episode to the most recent
        prior episode in the same project (bitemporal chain for traversal).

        Source: research_deep_five_topics.md §5 (CLS / RAPTOR Layer 1)
        """
        from ..schema import Episode as EpisodeModel  # late import — avoids circular

        project_id = getattr(episode, "project_id", None) or "default"
        summary    = getattr(episode, "summary", "") or ""
        themes     = getattr(episode, "themes", []) or []
        created_at = str(getattr(episode, "created_at", None) or datetime.now(timezone.utc))

        props: dict = {
            "id":               episode.id,
            "session_id":       getattr(episode, "session_id", "unknown"),
            "project_id":       project_id,
            "summary":          summary,
            "themes":           themes,
            "decision_count":   getattr(episode, "decision_count",   0),
            "constraint_count": getattr(episode, "constraint_count", 0),
            "preference_count": getattr(episode, "preference_count", 0),
            "exchange_count":   getattr(episode, "exchange_count",   0),
            "created_at":       created_at,
        }

        # Embed the summary for RAPTOR Layer 2 Sprint clustering
        try:
            from ..embeddings import generate_embedding
            if summary:
                emb = generate_embedding(summary)
                if emb:
                    props["embedding"] = emb
        except Exception:
            pass

        assignments = ", ".join(f"n.{k} = ${k}" for k in props if k != "id")
        self._tx_write(
            f"MERGE (n:Episode {{id: $id}}) SET {assignments}",
            **props,
        )

        # ── FOLLOWS edge: link to previous episode in this project ─────────────
        # This creates the temporal chain so we can traverse episode history.
        try:
            rows = self._tx_read(
                """
                MATCH (prev:Episode {project_id: $project_id})
                WHERE prev.id <> $current_id
                RETURN prev.id AS prev_id
                ORDER BY prev.created_at DESC
                LIMIT 1
                """,
                project_id=project_id,
                current_id=episode.id,
            )
            if rows:
                prev_id = rows[0]["prev_id"]
                self._tx_write(
                    """
                    MATCH (cur:Episode {id: $cur_id}), (prev:Episode {id: $prev_id})
                    MERGE (cur)-[r:FOLLOWS]->(prev)
                    SET r.created_at = $created_at, r.valid_at = $created_at
                    """,
                    cur_id=episode.id,
                    prev_id=prev_id,
                    created_at=created_at,
                )
        except Exception as e:
            logger.warning("save_episode: FOLLOWS edge failed (non-fatal): %s", e)

    # ─── Read methods ──────────────────────────────────────────────────────────

    def get_decisions(
        self,
        session_id: str | None = None,
        project_id: str | None = None,
        tenant_id: str = "default",
        module: str | None = None,
        category: str | None = None,
        since: "datetime | None" = None,
        origin: str | None = None,
        confidence_min: float = 0.0,
        limit: int = 100,
    ) -> list[Decision]:
        base = (
            "MATCH (n:Decision) WHERE "
            "(n.is_superseded = false OR n.is_superseded IS NULL) "
            "AND (n.status IS NULL OR n.status <> 'rejected') "
            "AND n.tenant_id = $tenant_id"
        )
        params: dict = {"tenant_id": tenant_id}
        if project_id:
            # Strict project isolation — do NOT fall through to NULL project nodes
            base += " AND n.project_id = $pid"
            params["pid"] = project_id
        if session_id:
            base += " AND n.session_id = $sid"
            params["sid"] = session_id
        if module:
            base += " AND n.module = $module"
            params["module"] = module
        if category:
            base += " AND n.category = $category"
            params["category"] = category
        if since:
            base += " AND n.made_at >= $since_dt"
            params["since_dt"] = since.isoformat()
        if origin and origin != "all":
            base += " AND n.origin = $origin"
            params["origin"] = origin
        if confidence_min > 0.0:
            base += " AND n.confidence >= $conf_min"
            params["conf_min"] = confidence_min
        params["limit"] = limit
        rows = self._tx_read(base + " RETURN n ORDER BY n.confidence DESC LIMIT $limit", **params)
        results = []
        for r in rows:
            node = r["n"]
            try:
                results.append(Decision(
                    id=node["id"],
                    description=node["description"],
                    made_in=node.get("made_in", node.get("session_id", "unknown")),
                    rationale=node.get("rationale", ""),
                    confidence=node.get("confidence", WORTHINESS_THRESHOLD),
                    status=node.get("status", "active"),
                ))
            except Exception:
                pass
        return results

    def get_constraints(
        self,
        active_only: bool = True,
        project_id: str | None = None,
        tenant_id: str = "default",
        module: str | None = None,
        category: str | None = None,
        since: "datetime | None" = None,
        origin: str | None = None,
        limit: int = 100,
    ) -> list[Constraint]:
        query = "MATCH (n:Constraint)"
        clauses = [
            "n.tenant_id = $tenant_id",
            "(n.is_superseded IS NULL OR n.is_superseded = false)",  # Sprint 27: auto-versioning
        ]
        params: dict = {"tenant_id": tenant_id}
        if active_only:
            clauses.append("(n.active = true OR n.still_active = true OR (n.active IS NULL AND n.still_active IS NULL))")
        if project_id:
            clauses.append("n.project_id = $pid")  # strict — no NULL fallthrough
            params["pid"] = project_id
        if module:
            clauses.append("n.module = $module")
            params["module"] = module
        if category:
            clauses.append("n.category = $category")
            params["category"] = category
        if since:
            clauses.append("n.surfaced_at >= $since_dt")
            params["since_dt"] = since.isoformat()
        if origin and origin != "all":
            clauses.append("n.origin = $origin")
            params["origin"] = origin
        if clauses:
            query += " WHERE " + " AND ".join(clauses)
        query += " RETURN n ORDER BY n.surfaced_at DESC LIMIT $limit"
        params["limit"] = limit
        rows = self._tx_read(query, **params)
        results = []
        for r in rows:
            node = r["n"]
            try:
                results.append(Constraint(
                    id=node["id"],
                    description=node["description"],
                    surfaced_in=node.get("surfaced_in", node.get("session_id", "unknown")),
                    origin=ConstraintOrigin(node.get("origin", "explicit")),
                    still_active=node.get("still_active", node.get("active", True)),
                    scope=node.get("scope", ""),
                ))
            except Exception:
                pass
        return results

    def get_preferences(
            self,
            pref_type: str | None = None,
            confidence_min: float = 0.0,
            min_reinforcements: int = 0,
            project_id: str | None = None,
            tenant_id: str = "default",
            module: str | None = None,
            category: str | None = None,
            since: "datetime | None" = None,
            limit: int = 100,
    ) -> list[Preference]:
        query = ("MATCH (n:Preference) WHERE n.confidence >= $conf "
                 "AND (n.reinforcement_count IS NULL OR n.reinforcement_count >= $min_r) "
                 "AND n.tenant_id = $tenant_id "
                 "AND (n.is_superseded IS NULL OR n.is_superseded = false)"  # Sprint 27: auto-versioning
                 )
        params: dict[str, Any] = {"conf": confidence_min, "min_r": min_reinforcements, "tenant_id": tenant_id}
        if pref_type:
            query += " AND n.type = $ptype"
            params["ptype"] = pref_type
        if project_id:
            query += " AND n.project_id = $pid"  # strict — no NULL fallthrough
            params["pid"] = project_id
        if module:
            query += " AND n.module = $module"
            params["module"] = module
        if category:
            query += " AND n.category = $category"
            params["category"] = category
        if since:
            query += " AND n.inferred_at >= $since_dt"
            params["since_dt"] = since.isoformat()
        query += " RETURN n ORDER BY n.confidence DESC LIMIT $limit"
        params["limit"] = limit
        rows = self._tx_read(query, **params)
        results = []
        for r in rows:
            node = r["n"]
            try:
                results.append(Preference(
                    id=node["id"],
                    description=node["description"],
                    inferred_in=node.get("inferred_in", node.get("noted_in", node.get("session_id", "unknown"))),
                    type=PreferenceType(node.get("type", "process")),
                    confidence=node.get("confidence", 0.5),
                    reinforcement_count=node.get("reinforcement_count", 1),
                ))
            except Exception:
                pass
        return results

    def get_attempts(
        self,
        session_id: str | None = None,
        project_id: str | None = None,
        tenant_id: str = "default",
        module: str | None = None,
        category: str | None = None,
        since: "datetime | None" = None,
        limit: int = 100,
    ) -> list[Attempt]:
        query = "MATCH (n:Attempt)"
        clauses = ["n.tenant_id = $tenant_id"]
        params: dict = {"tenant_id": tenant_id}
        if session_id:
            clauses.append("n.session_id = $sid")
            params["sid"] = session_id
        if project_id:
            clauses.append("n.project_id = $pid")
            params["pid"] = project_id
        if module:
            clauses.append("n.module = $module")
            params["module"] = module
        if category:
            clauses.append("n.category = $category")
            params["category"] = category
        if since:
            clauses.append("n.tried_at >= $since_dt")
            params["since_dt"] = since.isoformat()
        if clauses:
            query += " WHERE " + " AND ".join(clauses)
        query += " RETURN n ORDER BY n.created_at DESC LIMIT $limit"
        params["limit"] = limit
        rows = self._tx_read(query, **params)
        return [
            Attempt(
                id=r["n"]["id"],
                description=r["n"]["description"],
                tried_in=r["n"].get("session_id", "unknown"),
                abandoned=r["n"].get("abandoned", True),
                abandoned_because=r["n"].get("abandoned_because", ""),
            )
            for r in rows
        ]

    def get_decision_chain(self, decision_id: str, tenant_id: str = "default") -> dict:
        rows = self._tx_read(
            """
            MATCH (d:Decision {id: $did})
            WHERE d.tenant_id = $tid
            OPTIONAL MATCH (d)-[r:RELATES_TO*1..3]-(related)
            WHERE related.tenant_id = $tid
            RETURN d, r, related
            """,
            did=decision_id, tid=tenant_id,
        )
        return {"decision_id": decision_id, "chain": rows, "backend": "neo4j"}

    def get_related_nodes(self, node_ids: list[str], max_hops: int = 2, tenant_id: str = "default") -> list[dict]:
        """Return edges connecting anchor nodes to their neighbors.

        Traverses all relationship types (RELATES_TO, DECIDED_IN, SURFACED_IN,
        REVEALS, FOLLOWS, etc.) so the full graph context is surfaced.
        Excludes ExchangeRecord and Session nodes — they are containers, not context.

        Used by build_context_brief() so agents get a connected subgraph
        rather than flat isolated lists.
        """
        if not node_ids:
            return []
        try:
            # Note: Cypher variable-length path bounds must be literals, not params.
            # max_hops=2 is the correct depth for context retrieval — deep enough
            # to surface related constraints/preferences, shallow enough to avoid noise.
            rows = self._tx_read(
                """
                UNWIND $ids AS anchor_id
                MATCH (anchor {id: anchor_id})
                WHERE anchor.tenant_id = $tid
                OPTIONAL MATCH p = (anchor)-[*1..2]-(neighbor)
                WHERE neighbor IS NOT NULL
                  AND neighbor.id IS NOT NULL
                  AND neighbor.description IS NOT NULL
                  AND NOT 'ExchangeRecord' IN labels(neighbor)
                  AND NOT 'Session' IN labels(neighbor)
                  AND neighbor.tenant_id = $tid
                RETURN anchor.id AS from_id,
                       labels(anchor)[0] AS from_type,
                       type(last(relationships(p))) AS rel_type,
                       neighbor.id AS to_id,
                       labels(neighbor)[0] AS to_type,
                       neighbor.description AS to_description
                """,
                ids=node_ids, tid=tenant_id,
            )
            seen: set[tuple] = set()
            edges = []
            for r in rows:
                key = (r.get("from_id"), r.get("to_id"))
                if None in key or key in seen:
                    continue
                seen.add(key)
                edges.append({
                    "from_id": r["from_id"],
                    "from_type": r.get("from_type", "Node"),
                    "rel_type": r.get("rel_type", "RELATES_TO"),
                    "to_id": r["to_id"],
                    "to_type": r.get("to_type", "Node"),
                    "to_description": (r.get("to_description") or "")[:200],
                })
            return edges
        except Exception:
            return []

    def get_flagged_records(self, tenant_id: str = "default") -> list[ExchangeRecord]:
        rows = self._tx_read(
            "MATCH (n:ExchangeRecord) WHERE n.should_encode = false AND n.worthiness_score >= $lo"
            " AND n.tenant_id = $tid"
            " RETURN n ORDER BY n.worthiness_score DESC LIMIT 20",
            lo=WORTHINESS_THRESHOLD - 0.1, tid=tenant_id,
        )
        return [
            ExchangeRecord(
                id=r["n"]["id"],
                session_id=r["n"].get("session_id", "unknown"),
                raw_text=r["n"].get("raw_text", ""),
                primitive_type=PrimitiveType(r["n"].get("primitive_type", "Exploration")),
                worthiness_score=r["n"].get("worthiness_score", 0.0),
                should_encode=r["n"].get("should_encode", False),
            )
            for r in rows
        ]

    def build_context_brief(
        self,
        entity_id: str | None = None,
        task_type: str | None = None,
        project_id: str | None = None,
        tenant_id: str = "default",
        module: str | None = None,
        category: str | None = None,
        since: "datetime | None" = None,
        origin: str | None = None,
        confidence_min: float = 0.0,
        limit: int = 10,
    ) -> dict:
        """Build a structured context brief for session bootstrap.

        Supports scoped filtering via project_id, tenant_id, module, category,
        since, origin, confidence_min, and limit parameters.
        """
        # ── Tier 0: Project manifest — always injected first, never gated by search ──
        # This is the guaranteed always-present block every agent receives regardless
        # of semantic retrieval results. Modelled on ChatGPT bio block + Zep user_context.
        project_manifest: dict = {}
        if project_id:
            try:
                _proj = self.get_project(project_id, tenant_id=tenant_id)
                if _proj:
                    project_manifest = {
                        "id":                 _proj.get("id", project_id),
                        "name":               _proj.get("name", ""),
                        "description":        _proj.get("description", ""),
                        "status":             _proj.get("status", "active"),
                        "lead_agent":         _proj.get("lead_agent", "ohaco"),
                        "worthiness_threshold": _proj.get("worthiness_threshold", 0.4),
                        "tags":               _proj.get("tags", []),
                        "repo_url":           _proj.get("repo_url", ""),
                        "deploy_url":         _proj.get("deploy_url", ""),
                        "docs_url":           _proj.get("docs_url", ""),
                        "hitl_confirm_count": _proj.get("hitl_confirm_count", 0),
                        "hitl_reject_count":  _proj.get("hitl_reject_count", 0),
                        "created_at":         str(_proj.get("created_at", "")),
                    }
            except Exception:
                pass
        # ─────────────────────────────────────────────────────────────────────────

        try:
            decisions = self.get_decisions(
                project_id=project_id, tenant_id=tenant_id, module=module,
                category=category, since=since, origin=origin,
                confidence_min=confidence_min, limit=limit,
            )
        except Exception:
            decisions = []
        try:
            constraints = self.get_constraints(
                active_only=True, project_id=project_id, tenant_id=tenant_id,
                module=module, category=category, since=since, origin=origin,
                limit=limit,
            )
        except Exception:
            constraints = []
        try:
            preferences = self.get_preferences(
                project_id=project_id, tenant_id=tenant_id, module=module,
                category=category, since=since, confidence_min=confidence_min,
                limit=limit,
            )
        except Exception:
            preferences = []
        try:
            attempts = self.get_attempts(
                project_id=project_id, tenant_id=tenant_id, module=module,
                category=category, since=since, limit=limit,
            )
        except Exception:
            attempts = []

        # Node counts — single UNION query instead of 7 individual round-trips
        try:
            rows = self._tx_read(
                "MATCH (n:Decision) RETURN 'Decision' AS lbl, count(n) AS cnt "
                "UNION ALL MATCH (n:Constraint) RETURN 'Constraint' AS lbl, count(n) AS cnt "
                "UNION ALL MATCH (n:Preference) RETURN 'Preference' AS lbl, count(n) AS cnt "
                "UNION ALL MATCH (n:Attempt) RETURN 'Attempt' AS lbl, count(n) AS cnt "
                "UNION ALL MATCH (n:Skill) RETURN 'Skill' AS lbl, count(n) AS cnt "
                "UNION ALL MATCH (n:Artifact) RETURN 'Artifact' AS lbl, count(n) AS cnt "
                "UNION ALL MATCH (n:Exchange) RETURN 'Exchange' AS lbl, count(n) AS cnt"
            )
            node_counts = {r["lbl"]: r["cnt"] for r in rows} if rows else {}
        except Exception:
            node_counts = {}

        # Sprint S5: recent session summaries (compressed history for context bootstrap)
        try:
            from ..session_compressor import get_recent_session_summaries
            recent_session_summaries = get_recent_session_summaries(self, limit=3)
        except Exception:
            recent_session_summaries = []

        # Sprint S1: pending HITL count (:PendingInference + legacy pending_confirmation)
        try:
            pending_count = len(self.get_pending(project_id=project_id))
        except Exception:
            pending_count = 0

        # ── Sprint 20.5: Apply temporal decay scoring ──────────────────────────
        from ..schema import temporal_validity

        def _decay_score(node) -> float:
            """Compute temporal decay for sorting. Returns 0-1."""
            node_dict = {
                "created_at": str(getattr(node, "created_at", "") or ""),
                "last_confirmed": str(getattr(node, "last_confirmed", "") or ""),
                "primitive_type": getattr(node, "decay_rate", type(node).__name__),
            }
            return temporal_validity(node_dict)

        # Sort each list by decay (freshest first)
        decisions = sorted(decisions, key=_decay_score, reverse=True)
        constraints = sorted(constraints, key=_decay_score, reverse=True)
        preferences = sorted(preferences, key=_decay_score, reverse=True)

        # ── Cognitive Dreams: reinforce retrieved nodes ──────────────────────────
        # Every retrieval is a reinforcement signal. Batch-update recall_count
        # for all nodes returned in this context brief.
        retrieved_ids = (
            [d.id for d in decisions] +
            [c.id for c in constraints] +
            [p.id for p in preferences] +
            [a.id for a in attempts]
        )
        if retrieved_ids:
            try:
                self.reinforce_nodes(retrieved_ids)
            except Exception:
                pass  # Non-fatal — context still returns even if reinforcement fails
            # Check for graduation after reinforcement
            try:
                from ..graduation import check_graduations
                check_graduations(retrieved_ids, self)
            except Exception:
                pass  # Non-fatal
        # ─────────────────────────────────────────────────────────────────────────

        # ── Graph traversal: top connected nodes for top decisions ──────────────
        top_ids = [d.id for d in decisions[:limit]]
        try:
            all_related = self.get_related_nodes(top_ids, max_hops=2)
            # Keep only cross-type connections (Decision→Constraint, Decision→Preference etc.)
            # and deduplicate by to_id — limit to 10 most diverse edges
            seen_to = set()
            related_context = []
            for edge in all_related:
                to_id = edge.get("to_id", "")
                if to_id and to_id not in seen_to and edge.get("from_type") != edge.get("to_type"):
                    seen_to.add(to_id)
                    related_context.append({
                        "from_id":       edge["from_id"],
                        "from_type":     edge["from_type"],
                        "to_id":         to_id,
                        "to_type":       edge["to_type"],
                        "to_description": (edge.get("to_description") or "")[:200],
                    })
                    if len(related_context) >= 10:
                        break
        except Exception as e:
            logger.warning("build_context_brief: related_context failed: %s", e)
            related_context = []

        # ── Relevant skills: surface skills matching active context ────────
        try:
            context_query = " ".join(
                (d.description or "")[:80] for d in decisions[:3]
            )
            if context_query.strip():
                relevant_skills = [
                    {
                        "id":      s.id,
                        "name":    s.name,
                        "summary": (s.summary or "")[:200],
                        "tags":    s.tags,
                        "url":     s.url,
                    }
                    for s in self.search_skills(context_query, limit=5, tenant_id=tenant_id)
                ]
            else:
                relevant_skills = []
            # If semantic search found nothing, fall back to most recent skills
            if not relevant_skills:
                recent_skills = self.get_skills(limit=5, tenant_id=tenant_id, project_id=project_id)
                relevant_skills = [
                    {
                        "id":      s.id,
                        "name":    s.name,
                        "summary": (s.summary or "")[:200],
                        "tags":    s.tags,
                        "url":     s.url,
                    }
                    for s in recent_skills
                ]
        except Exception as e:
            logger.warning("build_context_brief: relevant_skills failed: %s", e)
            relevant_skills = []
        # ─────────────────────────────────────────────────────────────────────

        return {
            # ── Tier 0: always-present, zero-retrieval project identity block ───
            # Agents MUST read this before any semantic content.
            # Equivalent to ChatGPT memory bio-block or Zep user_context injection.
            "project_manifest": project_manifest,
            # ── Tier 1: semantic retrieval (search-gated) ─────────────────────
            "active_decisions": [
                {
                    "id": d.id,
                    "description": d.description,
                    "confidence": getattr(d, 'worthiness_score', getattr(d, 'confidence', 0)),
                    "rationale": getattr(d, 'rationale', ''),
                    "temporal_validity": round(_decay_score(d), 3),
                }
                for d in decisions[:limit]
            ],
            "active_constraints": [
                {
                    "id": c.id,
                    "description": c.description,
                    "origin": getattr(getattr(c, 'origin', None), 'value', str(getattr(c, 'origin', 'explicit'))),
                    "temporal_validity": round(_decay_score(c), 3),
                }
                for c in constraints[:limit]
            ],
            "inferred_preferences": [
                {
                    "id": p.id,
                    "description": p.description,
                    "type": getattr(getattr(p, 'type', None), 'value', str(getattr(p, 'type', 'process'))),
                    "confidence": p.confidence,
                    "temporal_validity": round(_decay_score(p), 3),
                }
                for p in preferences[:limit]
            ],
            "recent_attempts": [
                {
                    "id": a.id,
                    "description": a.description,
                    "abandoned": getattr(a, 'abandoned', True),
                    "temporal_validity": round(_decay_score(a), 3),
                }
                for a in attempts[:limit]
                if not any(
                    t in (a.description or "").lower()
                    for t in ["partner_submission","vercel kv","portfolio","loi",
                               "showings","market data","what the tests prove",
                               "keyword scorer","sqft","cap rate","mckinsey","hbr"]
                )
            ][:5],
            "recent_session_summaries": recent_session_summaries,   # Sprint S5
            "pending_count": pending_count,                           # Sprint S1
            "related_context": related_context,                       # graph traversal (top 10 cross-type edges)
            "relevant_skills": relevant_skills,                        # research docs matching active context
            "security_brief": self._get_security_brief_compact(),      # live CVE threat landscape
            "workflow_brief": self._get_workflow_brief(project_id),    # project build rules for agents
            "agent_coordination": self._get_agent_coordination_brief(),  # Sprint 27: peer handoff protocol
            "caution_flags": [],
            "backend": "neo4j",
            "node_counts": node_counts,
            "summary": (
                f"{len(decisions)} active decisions, "
                f"{len(constraints)} constraints, "
                f"{len(preferences)} preferences — backend: Neo4jBackend"
            ),
        }


    def _get_security_brief_compact(self) -> dict:
        """Compact security brief for context window inclusion. Fails silently."""
        try:
            from ..workers.cve_watcher import get_security_brief
            return get_security_brief(self, limit=3)
        except Exception:
            return {"available": False}

    def _get_workflow_brief(self, project_id: str | None = None) -> dict:
        """Return the active workflow skill for this project (or the default).

        Agents receive this as workflow_brief in get_context() — it contains
        the build rules, opsec requirements, testing gates, and agent protocol
        that govern how work should be done on this project.
        """
        try:
            # Look for a project-specific workflow skill first
            if project_id:
                rows = self._tx_read(
                    "MATCH (s:Skill) WHERE s.source_type = 'workflow' "
                    "AND s.project_id = $pid RETURN s LIMIT 1",
                    pid=project_id,
                )
                if rows:
                    s = rows[0]["s"]
                    return {
                        "available": True,
                        "skill_id": s.get("id", ""),
                        "name": s.get("name", "Project Workflow"),
                        "content": (s.get("content") or "")[:4000],
                        "source": "project",
                    }

            # Fall back to the default workflow skill
            rows = self._tx_read(
                "MATCH (s:Skill) WHERE s.source_type = 'workflow' "
                "AND (s.project_id IS NULL OR s.project_id = 'default') "
                "RETURN s ORDER BY s.created_at DESC LIMIT 1",
            )
            if rows:
                s = rows[0]["s"]
                return {
                    "available": True,
                    "skill_id": s.get("id", ""),
                    "name": s.get("name", "Default Workflow"),
                    "content": (s.get("content") or "")[:4000],
                    "source": "default",
                }

            # No workflow skill in graph — serve the bundled template
            import pathlib
            _tmpl = pathlib.Path(__file__).parent.parent / "templates" / "workflow_default.md"
            if _tmpl.exists():
                return {
                    "available": True,
                    "skill_id": "workflow_default",
                    "name": "Default Workflow",
                    "content": _tmpl.read_text()[:4000],
                    "source": "bundled_template",
                }
        except Exception:
            pass
        return {"available": False}

    def _get_agent_coordination_brief(self) -> dict:
        """Return agent peer coordination protocol for context injection.

        Every agent receives this on session start so they know:
        - Who their peer agents are
        - Where each peer puts work products
        - How to find handoff briefs, PRs, and inbox messages
        - The standing protocol for cross-agent collaboration

        Sprint 27: Created to solve AG's inability to find CC's outputs.
        The root cause was no standardized, automatically-injected protocol
        for how agents discover each other's work.
        """
        try:
            # Check for a coordination Skill node in the graph first
            rows = self._tx_read(
                "MATCH (s:Skill) WHERE s.source_type = 'integration' "
                "AND (s.name CONTAINS 'Coordination' OR s.name CONTAINS 'Handoff') "
                "RETURN s ORDER BY s.last_updated DESC LIMIT 1",
            )
            if rows:
                s = rows[0]["s"]
                return {
                    "available": True,
                    "skill_id": s.get("id", ""),
                    "name": s.get("name", ""),
                    "content": (s.get("content") or "")[:3000],
                    "source": "graph",
                }
        except Exception:
            pass

        # Fallback: bundled protocol (always available, even without graph)
        return {
            "available": True,
            "source": "bundled",
            "agents": {
                "claude-code": {
                    "role": "Lead engineer",
                    "outputs": {
                        "code": "Git branches + GitHub PRs",
                        "handoffs": "docs/briefs/CC-HANDOFF-YYYY-MM-DD.md",
                        "tests": "tests/test_*.py",
                        "research": "docs/research/ or docs/briefs/",
                    },
                    "find_recent": "git log --oneline -20",
                },
                "antigravity": {
                    "role": "Exec/CEO layer — review, deploy, strategy",
                    "outputs": {
                        "reviews": "GitHub PR comments",
                        "strategy": "docs/ or eva/",
                        "deployments": "Render dashboard",
                    },
                    "find_recent": "gh pr list --state all --limit 5",
                },
            },
            "protocol": [
                "Check docs/briefs/ for handoff files before starting work",
                "Run 'git log --oneline -20' to see recent changes",
                "Run 'gh pr list --state open' to find pending reviews",
                "Never assume a peer saw your work — write a handoff brief",
                "Include absolute dates, file paths, and branch names — never 'recently' or 'the usual place'",
            ],
        }

    # ─── Skills ───────────────────────────────────────────────────────────────

    def save_skill(self, skill) -> None:
        """Persist a Skill node to Neo4j, with embedding for semantic search."""
        # Generate embedding from name + summary + content (capped at 2000 chars)
        embed_text = f"{skill.name} {skill.summary or ''} {skill.content or ''}"[:2000]
        emb = None
        try:
            from ..embeddings import generate_embedding
            emb = generate_embedding(embed_text)
        except Exception as e:
            logger.debug("save_skill: embedding generation failed: %s", e)

        self._tx_write(
            """
            MERGE (s:Skill {id: $id})
            SET s.name = $name,
                s.url = $url,
                s.summary = $summary,
                s.content = $content,
                s.tags = $tags,
                s.source_type = $source_type,
                s.added_by = $added_by,
                s.created_at = $created_at,
                s.embedding = $embedding,
                s.tenant_id = $tenant_id,
                s.project_id = $project_id
            """,
            id=skill.id,
            name=skill.name,
            url=skill.url or "",
            summary=skill.summary or "",
            content=skill.content or "",
            tags=list(skill.tags) if skill.tags else [],
            source_type=skill.source_type.value if hasattr(skill.source_type, "value") else str(skill.source_type),
            added_by=skill.added_by or "user",
            created_at=str(getattr(skill, "added_at", None) or getattr(skill, "created_at", "")),
            embedding=emb,
            tenant_id=getattr(skill, "tenant_id", "default") or "default",
            project_id=getattr(skill, "project_id", None),
        )

    def get_skills(self, tags=None, source_type=None, limit=100, tenant_id: str = "default", project_id: str = None):
        """List skills, optionally filtered by tags, source type, or project."""
        from ..schema import Skill, SkillSourceType
        query = "MATCH (s:Skill)"
        params: dict = {"limit": limit, "tid": tenant_id}
        filters = ["s.tenant_id = $tid"]
        if project_id:
            filters.append("(s.project_id = $pid OR s.project_id IS NULL)")
            params["pid"] = project_id
        if source_type:
            filters.append("s.source_type = $source_type")
            params["source_type"] = source_type
        query += " WHERE " + " AND ".join(filters)
        query += " RETURN s ORDER BY s.created_at DESC LIMIT $limit"
        try:
            rows = self._tx_read(query, **params)
        except Exception:
            return []
        result = []
        for r in rows:
            node = r["s"]
            # tag filter applied in Python (Neo4j list membership in Cypher is complex)
            if tags and not any(t in node.get("tags", []) for t in tags):
                continue
            try:
                result.append(Skill(
                    id=node["id"],
                    name=node["name"],
                    url=node.get("url", ""),
                    summary=node.get("summary", ""),
                    content=node.get("content", ""),
                    tags=node.get("tags", []),
                    source_type=SkillSourceType(node.get("source_type", "custom")),
                    added_by=node.get("added_by", "user"),
                ))
            except Exception:
                pass
        return result

    def search_skills(self, q: str, limit: int = 20, tenant_id: str = "default", project_id: str = None):
        """Semantic + keyword search over Skill nodes.

        Priority 1: HNSW vector search (requires embeddings stored on Skill nodes).
        Priority 2: Keyword match across name, summary, content, tags.
        """
        from ..schema import Skill, SkillSourceType

        # Try semantic search first — get IDs, then fetch full Skill nodes
        try:
            semantic_hits = self.semantic_search(q, node_types=["Skill"], limit=limit)
            if semantic_hits:
                hit_ids = [h["id"] for h in semantic_hits if h.get("id")]
                if hit_ids:
                    rows = self._tx_read(
                        "MATCH (s:Skill) WHERE s.id IN $ids RETURN s",
                        ids=hit_ids,
                    )
                    # Preserve relevance order from semantic_hits
                    id_order = {sid: i for i, sid in enumerate(hit_ids)}
                    node_map = {}
                    for r in rows:
                        node = dict(r["s"])
                        node_map[node["id"]] = node
                    results = []
                    for sid in hit_ids:
                        node = node_map.get(sid)
                        if not node:
                            continue
                        try:
                            results.append(Skill(
                                id=node.get("id", ""),
                                name=node.get("name", ""),
                                url=node.get("url", ""),
                                summary=node.get("summary", ""),
                                content=node.get("content", ""),
                                tags=node.get("tags", []),
                                source_type=SkillSourceType(node.get("source_type", "custom")),
                                added_by=node.get("added_by", "user"),
                            ))
                        except Exception:
                            pass
                    if results:
                        return results
        except Exception as e:
            logger.debug("search_skills: semantic search failed (%s), using keyword fallback", e)

        # Keyword fallback
        q_lower = q.lower()
        all_skills = self.get_skills(limit=500, tenant_id=tenant_id, project_id=project_id)
        results = [
            s for s in all_skills
            if q_lower in s.name.lower()
            or q_lower in (s.summary or "").lower()
            or q_lower in (s.content or "").lower()
            or any(q_lower in t.lower() for t in (s.tags or []))
        ]
        return results[:limit]

    def test_connection(self) -> bool:
        """Verify the Neo4j connection is healthy. Used by the Setup Wizard."""
        try:
            self._tx_read("RETURN 1 AS ok")
            return True
        except Exception:
            return False

    # ─── Semantic Search ──────────────────────────────────────────────────────

    def semantic_search(
        self,
        query: str,
        node_types: list[str] | None = None,
        limit: int = 20,
        confidence_min: float = 0.0,
        project_id: str | None = None,
        tenant_id: str = "default",
    ) -> list[dict]:
        """
        Semantic + keyword search over MemoryNodes.

        Priority 1: Neo4j HNSW native vector search (db.index.vector.queryNodes)
                     — O(log N), scales to millions of nodes.
                     Requires HNSW index from scripts/hnsw_migration.py.
        Priority 2: Python BM25 + cosine similarity fallback.

        Source: research_gap_deep_dive.md §Gap 2 (HNSW implementation)
        """
        if not query or not query.strip():
            return []

        all_types = node_types or ["Decision", "Constraint", "Preference", "Attempt", "AtomicFact", "Skill"]

        # Try HNSW native vector search first
        try:
            from ..embeddings import generate_embedding
            query_vec = generate_embedding(query)
            if query_vec and len(query_vec) > 0:
                results = self._hnsw_search(
                    query_vec=query_vec,
                    all_types=all_types,
                    limit=limit,
                    confidence_min=confidence_min,
                    project_id=project_id,
                    tenant_id=tenant_id,
                )
                if results:  # HNSW worked — return
                    return results
        except Exception as e:
            logger.debug("semantic_search: HNSW failed (%s), using BM25 fallback", e)

        # BM25 + cosine fallback
        return self._bm25_search(
            query=query,
            all_types=all_types,
            limit=limit,
            confidence_min=confidence_min,
            project_id=project_id,
            tenant_id=tenant_id,
        )

    def _hnsw_search(
        self,
        query_vec: list[float],
        all_types: list[str],
        limit: int,
        confidence_min: float,
        project_id: str | None,
        tenant_id: str = "default",
    ) -> list[dict]:
        """Native Neo4j HNSW vector query via db.index.vector.queryNodes."""
        results: list[dict] = []
        per_type = max(limit, 10)

        for label in all_types:
            idx_name = f"idx_vector_{label.lower()}"
            try:
                pid_filter = " AND node.project_id = $pid" if project_id else ""
                # Sprint 20.5: exclude temporally invalidated nodes
                invalid_filter = " AND (node.invalid_at IS NULL OR node.invalid_at = '')"
                tenant_filter = " AND node.tenant_id = $tid"
                rows = self._tx_read(
                    f"""
                    CALL db.index.vector.queryNodes($idx, $k, $emb)
                    YIELD node, score
                    WHERE node.confidence >= $conf{pid_filter}{invalid_filter}{tenant_filter}
                    RETURN node, score LIMIT $lim
                    """,
                    idx=idx_name, k=per_type * 2, emb=query_vec,
                    conf=confidence_min, pid=project_id, lim=per_type, tid=tenant_id,
                )
                for r in rows:
                    node = dict(r["node"])
                    # Tri-factor retrieval (Park et al., Generative Agents 2023):
                    #   score = recency × importance × relevance
                    from ..schema import temporal_validity
                    recency = temporal_validity({
                        "created_at": str(node.get("created_at", "") or ""),
                        "last_confirmed": str(node.get("last_confirmed", "") or ""),
                        "primitive_type": node.get("decay_rate", label),
                    })
                    importance = float(node.get("confidence", 0.5) or 0.5)
                    relevance = float(r["score"])  # HNSW cosine similarity [0,1]
                    tri_score = recency * importance * relevance
                    results.append({
                        "id": node.get("id", ""),
                        "node_type": label,
                        "primitive_type": label,
                        "description": node.get("description") or node.get("name") or node.get("summary") or "",
                        "confidence": importance,
                        "session_id": node.get("session_id", ""),
                        "project_id": node.get("project_id", ""),
                        "relevance_score": round(tri_score, 4),
                        "recency_score": round(recency, 3),
                        "importance_score": round(importance, 3),
                        "similarity_score": round(relevance, 4),
                        "temporal_validity": round(recency, 3),
                        "origin": node.get("origin", ""),
                        "status": node.get("status", ""),
                        "rationale": node.get("rationale", ""),
                        "created_at": str(node.get("created_at", "")),
                        "last_confirmed": str(node.get("last_confirmed", "")),
                        "_search_path": "hnsw",
                    })
            except Exception as e:
                if "index" in str(e).lower() or "procedure" in str(e).lower():
                    raise  # Index missing — trigger fallback
                logger.warning("_hnsw_search %s: %s", label, e)

        results.sort(key=lambda x: x["relevance_score"], reverse=True)
        return results[:limit]

    def _bm25_search(
        self,
        query: str,
        all_types: list[str],
        limit: int,
        confidence_min: float,
        project_id: str | None,
        tenant_id: str = "default",
    ) -> list[dict]:
        """Python in-memory BM25 + cosine similarity fallback."""
        terms = [t.strip().lower() for t in query.split() if len(t.strip()) > 2]
        if not terms:
            return []

        _query_vec: list[float] = []
        _cos = None
        try:
            from ..embeddings import generate_embedding, cosine_similarity as _cos_fn
            _query_vec = generate_embedding(query)
            _cos = _cos_fn
        except Exception:
            pass

        results: list[dict] = []


        for label in all_types:
            try:
                pid_clause = " AND n.project_id = $pid" if project_id else ""
                tid_clause = " AND n.tenant_id = $tid"
                pid_params = {"pid": project_id} if project_id else {}
                rows = self._tx_read(
                    f"MATCH (n:{label}) WHERE 1=1{pid_clause}{tid_clause} RETURN n LIMIT $lim",
                    **pid_params, tid=tenant_id,
                    lim=limit * 4,  # fetch more than limit to allow scoring/filtering
                )
                for r in rows:
                    node = dict(r["n"])
                    # Sprint 20.5: skip temporally invalidated nodes
                    inv = node.get("invalid_at", "") or ""
                    if inv and inv != "None":
                        continue
                    desc = (node.get("description") or node.get("name") or node.get("summary") or "").lower()
                    rationale = (node.get("rationale") or node.get("abandoned_because") or "").lower()
                    tags_text = " ".join(node.get("tags") or []).lower()
                    session = (node.get("session_id") or "").lower()
                    content = (node.get("content") or "")[:500].lower()

                    score = 0.0

                    # Cosine similarity component (Sprint S4)
                    if _query_vec and _cos:
                        node_emb = node.get("embedding") or []
                        if node_emb and len(node_emb) == len(_query_vec):
                            score += _cos(_query_vec, node_emb) * 6.0  # scale to keyword range

                    # BM25-approximation keyword scoring
                    # IDF = log(1 + N/df) where we approximate df from term length:
                    #   short/common terms (len<=4) get IDF~1.0, longer=higher
                    # Saturation: f/(f + k1) caps term frequency impact (k1=1.5)
                    _k1 = 1.5
                    for term in terms:
                        # Estimate IDF proxy by term length (longer = rarer = higher weight)
                        idf = 1.0 + min(len(term) / 6.0, 1.5)  # range [1.0, 2.5]
                        # Count occurrences as freq proxy
                        tf_title = desc[:80].count(term)
                        tf_desc  = desc.count(term)
                        tf_meta  = rationale.count(term) + tags_text.count(term) + content.count(term)
                        # Saturate: f * (k1+1) / (f + k1)
                        if tf_title > 0:
                            score += idf * (tf_title * (_k1 + 1) / (tf_title + _k1)) * 2.0
                        elif tf_desc > 0:
                            score += idf * (tf_desc * (_k1 + 1) / (tf_desc + _k1)) * 1.2
                        if tf_meta > 0:
                            score += idf * (tf_meta * (_k1 + 1) / (tf_meta + _k1)) * 0.5

                    if score == 0:
                        continue

                    conf = node.get("confidence", node.get("worthiness_score", 0.5)) or 0.5
                    if conf < confidence_min:
                        continue

                    # Tri-factor retrieval (Park et al., Generative Agents 2023):
                    #   score = recency × importance × relevance
                    from ..schema import temporal_validity
                    recency = temporal_validity({
                        "created_at": str(node.get("created_at", "") or ""),
                        "last_confirmed": str(node.get("last_confirmed", "") or ""),
                        "primitive_type": node.get("decay_rate", label),
                    })
                    importance = conf  # node.confidence already fetched above
                    # Normalize BM25 score to [0,1] with soft cap at 10.0
                    relevance = min(score / 10.0, 1.0)
                    blended = recency * importance * relevance

                    results.append({
                        "id": node.get("id", ""),
                        "node_type": label,
                        "primitive_type": label,
                        "description": node.get("description") or node.get("name") or node.get("summary") or "",
                        "confidence": conf,
                        "session_id": node.get("session_id", ""),
                        "project_id": node.get("project_id", ""),
                        "relevance_score": round(blended, 4),
                        "recency_score": round(recency, 3),
                        "importance_score": round(importance, 3),
                        "similarity_score": round(relevance, 4),
                        "temporal_validity": round(recency, 3),
                        "origin": node.get("origin", ""),
                        "status": node.get("status", ""),
                        "rationale": node.get("rationale", ""),
                        "created_at": str(node.get("created_at", "")),
                        "_search_path": "bm25",
                    })
            except Exception:
                continue

        # Also search ExchangeRecord raw_text if requested
        if not all_types or "ExchangeRecord" in all_types:
            try:
                pid_clause = " AND n.project_id = $pid" if project_id else ""
                pid_params: dict = {"min": confidence_min}
                if project_id:
                    pid_params["pid"] = project_id
                rows = self._tx_read(
                    "MATCH (n:ExchangeRecord) WHERE n.worthiness_score >= $min"
                    f"{pid_clause} RETURN n ORDER BY n.created_at DESC LIMIT 200",
                    **pid_params,
                )
                for r in rows:
                    node = dict(r["n"])
                    text = (node.get("raw_text") or "").lower()
                    # BM25-lite scoring for ExchangeRecord
                    _k1 = 1.5
                    xscore = 0.0
                    for term in terms:
                        idf = 1.0 + min(len(term) / 6.0, 1.5)
                        tf_title = text[:200].count(term)
                        tf_body  = text.count(term)
                        if tf_title > 0:
                            xscore += idf * (tf_title * (_k1 + 1) / (tf_title + _k1)) * 1.5
                        elif tf_body > 0:
                            xscore += idf * (tf_body * (_k1 + 1) / (tf_body + _k1))
                    if xscore == 0:
                        continue
                    results.append({
                        "id": node.get("id", ""),
                        "node_type": "ExchangeRecord",
                        "description": (node.get("raw_text") or "")[:200],
                        "confidence": node.get("worthiness_score", 0.5),
                        "session_id": node.get("session_id", ""),
                        "relevance_score": round(xscore, 2),
                        "origin": "exchange",
                        "status": node.get("primitive_type", ""),
                        "rationale": "",
                    })
            except Exception:
                pass

        results.sort(key=lambda x: (-x["relevance_score"], -x["confidence"]))
        return results[:limit]

    # ─── Exchange History ──────────────────────────────────────────────────────

    def get_exchange_history(
        self,
        session_id: str | None = None,
        limit: int = 50,
        offset: int = 0,
        min_score: float = 0.0,
        primitive_type: str | None = None,
        tenant_id: str = "default",
    ) -> dict:
        """
        Return paginated exchange records (raw conversation turns).
        Each record includes session_id, raw_text snippet, primitive_type,
        worthiness_score, and created_at timestamp.

        Use this to give agents access to the full conversation history —
        not just the distilled decisions, but the actual reasoning that produced them.
        """
        clauses = [
            "n.worthiness_score >= $min_score",
            "n.tenant_id = $tid",
        ]
        params: dict = {"min_score": min_score, "limit": limit, "offset": offset, "tid": tenant_id}

        if session_id:
            clauses.append("n.session_id = $sid")
            params["sid"] = session_id
        if primitive_type:
            clauses.append("n.primitive_type = $ptype")
            params["ptype"] = primitive_type

        where = " AND ".join(clauses)

        rows = self._tx_read(
            f"MATCH (n:ExchangeRecord) WHERE {where} "
            f"RETURN n ORDER BY n.created_at DESC SKIP $offset LIMIT $limit",
            **params,
        )

        # Count total matching
        try:
            count_rows = self._tx_read(
                f"MATCH (n:ExchangeRecord) WHERE {where} RETURN count(n) AS total",
                **{k: v for k, v in params.items() if k not in ("limit", "offset")},
            )
            total = count_rows[0]["total"] if count_rows else 0
        except Exception:
            total = len(rows)

        records = []
        for r in rows:
            node = dict(r["n"])
            raw = node.get("raw_text") or ""
            records.append({
                "id": node.get("id", ""),
                "session_id": node.get("session_id", "unknown"),
                "primitive_type": node.get("primitive_type", "Exploration"),
                "worthiness_score": round(node.get("worthiness_score", 0.0), 3),
                "should_encode": node.get("should_encode", False),
                "flagged_for_review": node.get("flagged_for_review", False),
                "created_at": node.get("created_at", ""),
                "text_preview": raw[:300] + ("…" if len(raw) > 300 else ""),
                "text_length": len(raw),
            })

        return {
            "records": records,
            "total": total,
            "offset": offset,
            "limit": limit,
            "session_id": session_id,
            "has_more": (offset + limit) < total,
        }

    def confirm_inference(self, node_id: str, tenant_id: str | None = "default") -> bool:
        """Confirm a pending node — moves it to active/confirmed state."""
        result = self._tx_write(
            "MATCH (n {id: $id}) WHERE n.status = 'pending_confirmation' "
            "AND (n.tenant_id = $tid OR n.tenant_id IS NULL OR n.tenant_id = 'default') "
            "SET n.status = 'confirmed', n.confirmed_at = $ts "
            "RETURN count(n) AS updated",
            id=node_id, ts=str(datetime.now(timezone.utc)), tid=tenant_id or "default"
        )
        return bool(result and result[0].get("updated", 0) > 0)

    def reject_inference(self, node_id: str, tenant_id: str | None = "default") -> bool:
        """Reject a pending node — marks it rejected so it won't resurface."""
        result = self._tx_write(
            "MATCH (n {id: $id}) WHERE n.status = 'pending_confirmation' "
            "AND (n.tenant_id = $tid OR n.tenant_id IS NULL OR n.tenant_id = 'default') "
            "SET n.status = 'rejected', n.rejected_at = $ts "
            "RETURN count(n) AS updated",
            id=node_id, ts=str(datetime.now(timezone.utc)), tid=tenant_id or "default"
        )
        return bool(result and result[0].get("updated", 0) > 0)

    def confirm_pending_inference(self, item_id: str, tenant_id: str | None = "default") -> dict:
        """
        Confirm :PendingInference or legacy pending_confirmation node.
        Returns {"ok": True, ...} or {"ok": False, "error": "not_found"|...}.
        """
        tid = tenant_id or "default"
        rows = self._tx_read(
            "MATCH (n:PendingInference {id: $id}) "
            "WHERE (n.tenant_id = $tid OR n.tenant_id IS NULL OR n.tenant_id = 'default') "
            "RETURN n",
            id=item_id,
            tid=tid,
        )
        if rows:
            node = dict(rows[0]["n"])
            node_type = node.get("node_type", "Decision")
            description = node.get("description", "")
            session_id = node.get("session_id", "unknown")
            confidence = float(node.get("confidence", 0.7) or 0.7)
            proposed = (node.get("proposed_node_id") or "").strip()
            now = datetime.now(timezone.utc).isoformat()
            pid = node.get("project_id") or "default"
            tid = node.get("tenant_id") or "default"

            def _id(prefix: str, default_suffix: str) -> str:
                if proposed and proposed.startswith(prefix):
                    return proposed
                return f"{prefix}_{default_suffix}"

            suffix = item_id[-8:] if len(item_id) >= 8 else item_id.replace("pnd_", "")[:8] or "pending"

            if node_type == "Decision":
                nid = _id("dec", suffix)
                self._tx_write(
                    "MERGE (n:Decision {id: $id}) SET n.description=$desc, n.made_in=$sid, "
                    "n.confidence=$conf, n.origin='inferred', n.status='active', n.made_at=$now, "
                    "n.project_id=$pid, n.tenant_id=$tid",
                    id=nid, desc=description, sid=session_id, conf=confidence, now=now,
                    pid=pid, tid=tid,
                )
            elif node_type == "Constraint":
                nid = _id("con", suffix)
                self._tx_write(
                    "MERGE (n:Constraint {id: $id}) SET n.description=$desc, n.surfaced_in=$sid, "
                    "n.origin='inferred', n.still_active=true, n.surfaced_at=$now, "
                    "n.project_id=$pid, n.tenant_id=$tid",
                    id=nid, desc=description, sid=session_id, now=now, pid=pid, tid=tid,
                )
            elif node_type == "Preference":
                nid = _id("prf", suffix)
                self._tx_write(
                    "MERGE (n:Preference {id: $id}) SET n.description=$desc, n.inferred_in=$sid, "
                    "n.type='process', n.confidence=$conf, n.reinforcement_count=1, "
                    "n.origin='inferred', n.inferred_at=$now, n.project_id=$pid, n.tenant_id=$tid",
                    id=nid, desc=description, sid=session_id, conf=confidence, now=now,
                    pid=pid, tid=tid,
                )
            elif node_type == "Attempt":
                nid = _id("att", suffix)
                self._tx_write(
                    "MERGE (n:Attempt {id: $id}) SET n.description=$desc, n.tried_in=$sid, "
                    "n.abandoned=true, n.abandoned_because='', n.outcome='', "
                    "n.project_id=$pid, n.tenant_id=$tid, n.created_at=$now",
                    id=nid, desc=description, sid=session_id, now=now, pid=pid, tid=tid,
                )
            else:
                return {"ok": False, "error": f"unsupported_node_type:{node_type}"}

            self._tx_write(
                "MATCH (n:PendingInference {id: $id}) SET n.status='confirmed'",
                id=item_id,
            )
            return {
                "ok": True,
                "confirmed": item_id,
                "node_type": node_type,
                "written": True,
            }

        if self.confirm_inference(item_id, tenant_id=tid):
            return {
                "ok": True,
                "confirmed": item_id,
                "mode": "legacy_pending_confirmation",
                "written": True,
            }
        return {"ok": False, "error": "not_found"}

    def reject_pending_inference(self, item_id: str, tenant_id: str | None = "default") -> dict:
        """Reject :PendingInference or legacy pending_confirmation."""
        tid = tenant_id or "default"
        w = self._tx_write(
            "MATCH (n:PendingInference {id: $id}) "
            "WHERE (n.tenant_id = $tid OR n.tenant_id IS NULL OR n.tenant_id = 'default') "
            "SET n.status='rejected' "
            "RETURN count(n) AS c",
            id=item_id,
            tid=tid,
        )
        if w and w[0].get("c", 0) > 0:
            return {"ok": True, "rejected": item_id}
        if self.reject_inference(item_id, tenant_id=tid):
            return {"ok": True, "rejected": item_id, "mode": "legacy_pending_confirmation"}
        return {"ok": False, "error": "not_found"}

    # ─── S9: Admin / Migration Utilities ──────────────────────────────────────

    def backfill_project_id(
        self,
        project_id: str,
        only_types: list[str] | None = None,
        dry_run: bool = False,
    ) -> dict:
        """
        Stamp all nodes missing project_id with the provided value.

        Args:
            project_id:   Value to set (e.g. 'collab-memory').
            only_types:   If set, only backfill nodes of these labels.
                          Defaults to all known types.
            dry_run:      If True, count nodes that WOULD be affected without writing.

        Returns:
            {'affected': int, 'dry_run': bool, 'project_id': str}
        """
        target_types = only_types or [
            "Decision", "Constraint", "Preference", "Attempt",
            "ExchangeRecord", "Skill", "Episode",
        ]
        total = 0
        for label in target_types:
            try:
                if dry_run:
                    rows = self._tx_read(
                        f"MATCH (n:{label}) WHERE n.project_id IS NULL RETURN count(n) AS c"
                    )
                    total += rows[0]["c"] if rows else 0
                else:
                    self._tx_write(
                        f"MATCH (n:{label}) WHERE n.project_id IS NULL "
                        "SET n.project_id = $pid",
                        pid=project_id,
                    )
                    rows = self._tx_read(
                        f"MATCH (n:{label}) WHERE n.project_id = $pid RETURN count(n) AS c",
                        pid=project_id,
                    )
                    total += rows[0]["c"] if rows else 0
            except Exception:
                continue
        return {"affected": total, "dry_run": dry_run, "project_id": project_id}

    def invalidate_node(self, node_id: str, invalid_at=None) -> None:
        """Bi-temporal invalidation: set invalid_at on a node (soft delete)."""
        from datetime import datetime, timezone
        ts = str(invalid_at or datetime.now(timezone.utc))
        self._tx_write(
            "MATCH (n {id: $id}) SET n.invalid_at = $ts, n.status = 'invalidated'",
            id=node_id, ts=ts,
        )

    def update_node_content(
        self,
        node_id: str,
        content: str,
        last_confirmed=None,
    ) -> None:
        """Update a node's description/content and confirmation timestamp."""
        from datetime import datetime, timezone
        ts = str(last_confirmed or datetime.now(timezone.utc))
        self._tx_write(
            "MATCH (n {id: $id}) SET n.description = $content, "
            "n.last_confirmed = $ts, n.updated_at = $ts",
            id=node_id, content=content, ts=ts,
        )

    def __del__(self):
        try:
            self._driver.close()
        except Exception:
            pass

