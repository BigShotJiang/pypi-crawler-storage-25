"""
graph/local.py — JSON file store graph backend.

Stores all graph data as a single JSON file. No dependencies.
Sufficient for prototype validation. Swap for Graphiti in production.
"""

from __future__ import annotations
import json
from datetime import datetime
from pathlib import Path
from typing import Any
import uuid

from .base import GraphBackend
from ..schema import (
    Attempt, Constraint, Decision, DecisionStatus, Edge,
    Entity, ExchangeRecord, Preference, Session, Skill, Project, Artifact,
)

_STORES = ("sessions", "decisions", "attempts", "constraints",
           "preferences", "exchange_records", "edges", "entities", "skills",
           "projects", "artifacts",
           "pending_inferences")


def _default(obj: Any) -> Any:
    if isinstance(obj, datetime):
        return obj.isoformat()
    if hasattr(obj, "model_dump"):
        return obj.model_dump()
    raise TypeError(f"Object of type {type(obj)} is not JSON serializable")


def _norm_tenant_id(tenant_id: str | None) -> str:
    return (tenant_id or "default") or "default"


def _norm_project_id(project_id: str | None) -> str | None:
    # In the schema: None means "default project".
    if project_id in (None, "", "default"):
        return None
    return project_id


class LocalGraphBackend(GraphBackend):
    """
    Persists everything to a single JSON file at `path`.
    Thread-safety is not a concern for the prototype.
    """

    def __init__(self, path: str = "./data/graph.json"):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._data: dict[str, dict[str, Any]] = {s: {} for s in _STORES}
        if self.path.exists():
            self._load()

    # ── Persistence ────────────────────────────────────────────────────────

    def _load(self) -> None:
        with open(self.path) as f:
            raw = json.load(f)
        for store in _STORES:
            self._data[store] = raw.get(store, {})

    def _save(self) -> None:
        with open(self.path, "w") as f:
            json.dump(self._data, f, default=_default, indent=2)

    # ── Write Operations ───────────────────────────────────────────────────

    def save_session(self, session: Session) -> None:
        self._data["sessions"][session.id] = session.model_dump()
        self._save()

    def save_exchange_record(self, record: ExchangeRecord) -> None:
        self._data["exchange_records"][record.id] = record.model_dump()
        self._save()

    def save_edge(self, edge: Edge) -> None:
        self._data["edges"][edge.id] = edge.model_dump()
        self._save()

    def save_node(self, node) -> None:
        if isinstance(node, Decision):
            self._data["decisions"][node.id] = node.model_dump()
        elif isinstance(node, Attempt):
            self._data["attempts"][node.id] = node.model_dump()
        elif isinstance(node, Constraint):
            self._data["constraints"][node.id] = node.model_dump()
        elif isinstance(node, Preference):
            self._data["preferences"][node.id] = node.model_dump()
        elif isinstance(node, Entity):
            self._data["entities"][node.id] = node.model_dump()
        elif isinstance(node, Skill):
            self._data["skills"][node.id] = node.model_dump()
        self._save()

    def save_pending(self, node) -> str:
        """Queue a proposed node for HITL (same contract as Neo4jBackend.save_pending)."""
        from datetime import datetime, timezone

        item_id = f"pnd_{uuid.uuid4().hex[:8]}"
        label = type(node).__name__
        description = getattr(node, "description", "") or ""
        session_id = (
            getattr(node, "made_in", None)
            or getattr(node, "surfaced_in", None)
            or getattr(node, "inferred_in", None)
            or getattr(node, "tried_in", None)
            or "unknown"
        )
        confidence = float(getattr(node, "confidence", 0.7) or 0.7)
        rationale = getattr(node, "rationale", None) or ""
        raw_text = description + (f"\nRationale: {rationale}" if rationale else "")
        now = datetime.now(timezone.utc).isoformat()
        project_id_val = getattr(node, "project_id", None) or "default"
        tenant_id_val = getattr(node, "tenant_id", "default") or "default"
        proposed_id = getattr(node, "id", "") or ""

        rec = {
            "id": item_id,
            "node_type": label,
            "description": description,
            "session_id": session_id,
            "confidence": confidence,
            "raw_text": raw_text[:8000],
            "origin": "inferred",
            "status": "pending",
            "created_at": now,
            "project_id": project_id_val,
            "tenant_id": tenant_id_val,
            "proposed_node_id": proposed_id,
        }
        self._data.setdefault("pending_inferences", {})
        self._data["pending_inferences"][item_id] = rec
        self._save()
        return item_id

    def get_pending(
        self,
        project_id: str | None = None,
        tenant_id: str | None = "default",
    ) -> list[dict]:
        """Return pending HITL rows (PendingInference-shaped dicts)."""
        self._data.setdefault("pending_inferences", {})
        tenant_id_n = _norm_tenant_id(tenant_id)
        items = list(self._data["pending_inferences"].values())
        items = [i for i in items if i.get("status") == "pending"]
        items = [i for i in items if _norm_tenant_id(i.get("tenant_id", "default")) == tenant_id_n]
        if project_id:
            pid_n = _norm_project_id(project_id)
            items = [i for i in items if _norm_project_id(i.get("project_id")) == pid_n]
        items.sort(key=lambda x: x.get("created_at", ""), reverse=True)
        return items[:50]

    def confirm_pending_inference(self, item_id: str, tenant_id: str | None = "default") -> dict:
        """Materialize a pending row into a typed node (parity with Neo4j HITL)."""
        from ..schema import (
            Decision,
            Constraint,
            Preference,
            Attempt,
            ConstraintOrigin,
            PreferenceType,
            DecisionStatus,
        )

        self._data.setdefault("pending_inferences", {})
        rec = self._data["pending_inferences"].get(item_id)
        if not rec or rec.get("status") != "pending":
            return {"ok": False, "error": "not_found"}

        # Enforce tenant isolation for confirmation.
        tenant_id_n = _norm_tenant_id(tenant_id)
        rec_tid = _norm_tenant_id(rec.get("tenant_id", "default"))
        if rec_tid != tenant_id_n:
            return {"ok": False, "error": "not_found"}

        node_type = rec.get("node_type", "Decision")
        description = rec.get("description", "")
        session_id = rec.get("session_id", "unknown")
        confidence = float(rec.get("confidence", 0.7))
        project_id = rec.get("project_id")
        if project_id == "default":
            project_id = None
        tenant_id = rec.get("tenant_id", "default")
        proposed = (rec.get("proposed_node_id") or "").strip()

        if node_type == "Decision":
            kwargs = {
                "description": description,
                "made_in": session_id,
                "confidence": confidence,
                "project_id": project_id,
                "tenant_id": tenant_id,
                "status": DecisionStatus.active,
            }
            if proposed.startswith("dec_"):
                kwargs["id"] = proposed
            self.save_node(Decision(**kwargs))
        elif node_type == "Constraint":
            kwargs = {
                "description": description,
                "surfaced_in": session_id,
                "origin": ConstraintOrigin.inferred,
                "project_id": project_id,
                "tenant_id": tenant_id,
            }
            if proposed.startswith("con_"):
                kwargs["id"] = proposed
            self.save_node(Constraint(**kwargs))
        elif node_type == "Preference":
            kwargs = {
                "description": description,
                "inferred_in": session_id,
                "type": PreferenceType.process,
                "confidence": confidence,
                "reinforcement_count": 1,
                "project_id": project_id,
                "tenant_id": tenant_id,
            }
            if proposed.startswith("prf_"):
                kwargs["id"] = proposed
            self.save_node(Preference(**kwargs))
        elif node_type == "Attempt":
            kwargs = {
                "description": description,
                "tried_in": session_id,
                "project_id": project_id,
                "tenant_id": tenant_id,
            }
            if proposed.startswith("att_"):
                kwargs["id"] = proposed
            self.save_node(Attempt(**kwargs))
        else:
            return {"ok": False, "error": f"unsupported_node_type:{node_type}"}

        rec["status"] = "confirmed"
        self._data["pending_inferences"][item_id] = rec
        self._save()
        return {"ok": True, "confirmed": item_id, "node_type": node_type, "written": True}

    def reject_pending_inference(self, item_id: str, tenant_id: str | None = "default") -> dict:
        self._data.setdefault("pending_inferences", {})
        rec = self._data["pending_inferences"].get(item_id)
        if not rec:
            return {"ok": False, "error": "not_found"}

        # Enforce tenant isolation for rejection.
        tenant_id_n = _norm_tenant_id(tenant_id)
        rec_tid = _norm_tenant_id(rec.get("tenant_id", "default"))
        if rec_tid != tenant_id_n:
            return {"ok": False, "error": "not_found"}

        rec["status"] = "rejected"
        self._data["pending_inferences"][item_id] = rec
        self._save()
        return {"ok": True, "rejected": item_id}

    def save_skill(self, skill: Skill) -> None:
        """Persist a skill/knowledge reference to the graph."""
        self._data.setdefault("skills", {})
        self._data["skills"][skill.id] = skill.model_dump()
        self._save()

    # ── Project + Artifact parity with Neo4j backend ──────────────────────

    def save_project(self, project: Project) -> None:
        self._data.setdefault("projects", {})
        payload = project.model_dump()
        payload["updated_at"] = datetime.utcnow().isoformat()
        self._data["projects"][project.id] = payload
        self._save()

    def get_projects(self, tenant_id: str = "default") -> list[dict]:
        tenant_id_n = _norm_tenant_id(tenant_id)
        items = []
        for raw in self._data.get("projects", {}).values():
            if _norm_tenant_id(raw.get("tenant_id", "default")) != tenant_id_n:
                continue
            if (raw.get("status") or "active") == "deleted":
                continue
            pid = raw.get("id")
            pid_n = _norm_project_id(pid)
            d_count = sum(
                1 for d in self._data.get("decisions", {}).values()
                if _norm_tenant_id(d.get("tenant_id", "default")) == tenant_id_n
                and _norm_project_id(d.get("project_id")) == pid_n
            )
            c_count = sum(
                1 for c in self._data.get("constraints", {}).values()
                if _norm_tenant_id(c.get("tenant_id", "default")) == tenant_id_n
                and _norm_project_id(c.get("project_id")) == pid_n
            )
            p_count = sum(
                1 for p in self._data.get("preferences", {}).values()
                if _norm_tenant_id(p.get("tenant_id", "default")) == tenant_id_n
                and _norm_project_id(p.get("project_id")) == pid_n
            )
            row = dict(raw)
            row["decision_count"] = d_count
            row["constraint_count"] = c_count
            row["preference_count"] = p_count
            row["memory_count"] = d_count + c_count + p_count
            items.append(row)
        return sorted(items, key=lambda x: (x.get("name") or x.get("id") or "").lower())

    def get_project(self, project_id: str, tenant_id: str = "default") -> dict | None:
        raw = self._data.get("projects", {}).get(project_id)
        if not raw:
            return None
        if _norm_tenant_id(raw.get("tenant_id", "default")) != _norm_tenant_id(tenant_id):
            return None
        if (raw.get("status") or "active") == "deleted":
            return None
        return dict(raw)

    def save_artifact(self, artifact: Artifact) -> None:
        self._data.setdefault("artifacts", {})
        payload = artifact.model_dump()
        payload["project_id"] = payload.get("project_id") or "default"
        payload["updated_at"] = datetime.utcnow().isoformat()
        self._data["artifacts"][artifact.id] = payload
        self._save()

    def get_artifacts(
        self,
        project_id: str | None = None,
        artifact_type: str | None = None,
        session_id: str | None = None,
        limit: int = 50,
        tenant_id: str = "default",
    ) -> list[dict]:
        tenant_id_n = _norm_tenant_id(tenant_id)
        project_id_n = _norm_project_id(project_id)
        items = [dict(v) for v in self._data.get("artifacts", {}).values()]
        items = [a for a in items if _norm_tenant_id(a.get("tenant_id", "default")) == tenant_id_n]
        if project_id is not None:
            items = [a for a in items if _norm_project_id(a.get("project_id")) == project_id_n]
        if artifact_type:
            items = [a for a in items if (a.get("artifact_type") or "other") == artifact_type]
        if session_id:
            items = [a for a in items if (a.get("session_id") or "") == session_id]
        items.sort(key=lambda a: (a.get("updated_at") or a.get("created_at") or ""), reverse=True)
        return items[:limit]

    def get_artifact(self, artifact_id: str) -> dict | None:
        raw = self._data.get("artifacts", {}).get(artifact_id)
        return dict(raw) if raw else None

    def delete_artifact(self, artifact_id: str) -> bool:
        arts = self._data.get("artifacts", {})
        if artifact_id not in arts:
            return False
        del arts[artifact_id]
        self._save()
        return True

    def get_skills(
        self,
        tags: list[str] | None = None,
        source_type: str | None = None,
        limit: int = 100,
    ) -> list[Skill]:
        """Return skills, optionally filtered by tag or source_type."""
        self._data.setdefault("skills", {})
        items = [Skill(**v) for v in self._data["skills"].values()]
        if tags:
            items = [s for s in items if any(t in s.tags for t in tags)]
        if source_type:
            items = [s for s in items if s.source_type.value == source_type]
        return sorted(items, key=lambda s: s.added_at, reverse=True)[:limit]

    def search_skills(self, query: str, limit: int = 20) -> list[Skill]:
        """Full-text keyword search across name, summary, content, tags, and url."""
        self._data.setdefault("skills", {})
        q = query.lower()
        results = []
        for raw in self._data["skills"].values():
            skill = Skill(**raw)
            haystack = " ".join([
                skill.name,
                skill.summary,
                skill.content[:1000],
                " ".join(skill.tags),
                skill.url,
            ]).lower()
            if q in haystack:
                results.append(skill)
        return sorted(results, key=lambda s: s.added_at, reverse=True)[:limit]

    # ── Read Operations ────────────────────────────────────────────────────
    def get_decisions(
        self,
        session_id: str | None = None,
        project_id: str | None = None,
        tenant_id: str | None = "default",
        module: str | None = None,
        category: str | None = None,
        since: datetime | None = None,
        origin: str | None = None,
        confidence_min: float = 0.0,
        limit: int = 100,
    ) -> list[Decision]:
        tenant_id_n = _norm_tenant_id(tenant_id)
        project_id_n = _norm_project_id(project_id)

        items = [Decision(**v) for v in self._data["decisions"].values()]
        items = [d for d in items if _norm_tenant_id(getattr(d, "tenant_id", "default")) == tenant_id_n]

        if session_id:
            items = [d for d in items if d.made_in == session_id]
        if project_id is not None:
            items = [d for d in items if _norm_project_id(getattr(d, "project_id", None)) == project_id_n]
        if module:
            items = [d for d in items if (getattr(d, "module", None) or "") == module]
        if category:
            items = [d for d in items if (getattr(d, "category", None) or "") == category]
        if since:
            items = [d for d in items if getattr(d, "made_at", datetime.min) >= since]
        if confidence_min and confidence_min > 0.0:
            items = [d for d in items if getattr(d, "confidence", 0.0) >= confidence_min]

        # Mimic Neo4j "active-ish" behavior: hide superseded decisions.
        items = [d for d in items if getattr(d, "status", DecisionStatus.active) != DecisionStatus.superseded]

        items_sorted = sorted(items, key=lambda d: getattr(d, "confidence", 0.0), reverse=True)
        return items_sorted[:limit] if limit else items_sorted

    def get_constraints(
        self,
        active_only: bool = True,
        project_id: str | None = None,
        tenant_id: str | None = "default",
        module: str | None = None,
        category: str | None = None,
        since: datetime | None = None,
        origin: str | None = None,
        limit: int = 100,
    ) -> list[Constraint]:
        tenant_id_n = _norm_tenant_id(tenant_id)
        project_id_n = _norm_project_id(project_id)

        items = [Constraint(**v) for v in self._data["constraints"].values()]
        items = [c for c in items if _norm_tenant_id(getattr(c, "tenant_id", "default")) == tenant_id_n]
        if active_only:
            items = [c for c in items if getattr(c, "still_active", True)]
        if project_id is not None:
            items = [c for c in items if _norm_project_id(getattr(c, "project_id", None)) == project_id_n]
        if module:
            items = [c for c in items if (getattr(c, "module", None) or "") == module]
        if category:
            items = [c for c in items if (getattr(c, "category", None) or "") == category]
        if since:
            items = [c for c in items if getattr(c, "surfaced_at", datetime.min) >= since]
        if origin and origin != "all":
            # Constraint.origin is a ConstraintOrigin enum.
            items = [
                c
                for c in items
                if str(getattr(c, "origin", "")) in (origin, getattr(getattr(c, "origin", None), "value", None))
                or getattr(getattr(c, "origin", None), "value", None) == origin
            ]

        items_sorted = sorted(items, key=lambda c: getattr(c, "surfaced_at", datetime.min), reverse=True)
        return items_sorted[:limit] if limit else items_sorted

    def get_preferences(
        self,
        pref_type: str | None = None,
        confidence_min: float = 0.0,
        min_reinforcements: int = 0,
        project_id: str | None = None,
        tenant_id: str | None = "default",
        module: str | None = None,
        category: str | None = None,
        since: datetime | None = None,
        limit: int = 100,
    ) -> list[Preference]:
        tenant_id_n = _norm_tenant_id(tenant_id)
        project_id_n = _norm_project_id(project_id)

        items = [Preference(**v) for v in self._data["preferences"].values()]
        items = [p for p in items if _norm_tenant_id(getattr(p, "tenant_id", "default")) == tenant_id_n]

        if pref_type:
            items = [p for p in items if getattr(p.type, "value", p.type) == pref_type]
        if confidence_min and confidence_min > 0.0:
            items = [p for p in items if getattr(p, "confidence", 0.0) >= confidence_min]
        if min_reinforcements:
            items = [p for p in items if getattr(p, "reinforcement_count", 0) >= min_reinforcements]
        if project_id is not None:
            items = [p for p in items if _norm_project_id(getattr(p, "project_id", None)) == project_id_n]
        if module:
            items = [p for p in items if (getattr(p, "module", None) or "") == module]
        if category:
            items = [p for p in items if (getattr(p, "category", None) or "") == category]
        if since:
            items = [p for p in items if getattr(p, "inferred_at", datetime.min) >= since]

        items_sorted = sorted(items, key=lambda p: getattr(p, "confidence", 0.0), reverse=True)
        return items_sorted[:limit] if limit else items_sorted

    def get_attempts(
        self,
        session_id: str | None = None,
        project_id: str | None = None,
        tenant_id: str | None = "default",
        module: str | None = None,
        category: str | None = None,
        since: datetime | None = None,
        limit: int = 100,
    ) -> list[Attempt]:
        tenant_id_n = _norm_tenant_id(tenant_id)
        project_id_n = _norm_project_id(project_id)

        items = [Attempt(**v) for v in self._data["attempts"].values()]
        items = [a for a in items if _norm_tenant_id(getattr(a, "tenant_id", "default")) == tenant_id_n]
        if session_id:
            items = [a for a in items if a.tried_in == session_id]
        if project_id is not None:
            items = [a for a in items if _norm_project_id(getattr(a, "project_id", None)) == project_id_n]
        if module:
            items = [a for a in items if (getattr(a, "module", None) or "") == module]
        if category:
            items = [a for a in items if (getattr(a, "category", None) or "") == category]
        if since:
            items = [a for a in items if getattr(a, "tried_at", datetime.min) >= since]

        items_sorted = sorted(items, key=lambda a: getattr(a, "tried_at", datetime.min), reverse=True)
        return items_sorted[:limit] if limit else items_sorted

    def get_flagged_records(self, tenant_id: str | None = "default") -> list[ExchangeRecord]:
        tenant_id_n = _norm_tenant_id(tenant_id)
        items = [ExchangeRecord(**v) for v in self._data["exchange_records"].values()]
        return [r for r in items if r.flagged_for_review and _norm_tenant_id(getattr(r, "tenant_id", "default")) == tenant_id_n]

    def get_decision_chain(self, decision_id: str, tenant_id: str | None = "default") -> dict:
        """
        Decision archaeology — traces the causal chain for a given decision.
        Returns: the decision, the constraints that shaped it, the attempts
        that preceded it, and the exchange record (with raw text).
        """
        tenant_id_n = _norm_tenant_id(tenant_id)
        if decision_id not in self._data["decisions"]:
            return {"error": f"Decision {decision_id} not found"}

        decision = Decision(**self._data["decisions"][decision_id])
        if _norm_tenant_id(getattr(decision, "tenant_id", "default")) != tenant_id_n:
            return {"error": f"Decision {decision_id} not found"}

        # Find exchange record
        exc_record = None
        if decision.exchange_record_id:
            raw = self._data["exchange_records"].get(decision.exchange_record_id)
            if raw:
                exc_record = ExchangeRecord(**raw)

        # Find edges pointing to this decision
        related_edges = [
            Edge(**e) for e in self._data["edges"].values()
            if e.get("target_id") == decision_id or e.get("source_id") == decision_id
        ]

        # Find constraints linked via CONSTRAINED_BY
        constraint_ids = [
            e.target_id for e in related_edges if e.type == "CONSTRAINED_BY"
        ]
        constraints = [
            Constraint(**self._data["constraints"][cid])
            for cid in constraint_ids
            if cid in self._data["constraints"]
            if _norm_tenant_id(self._data["constraints"][cid].get("tenant_id", "default")) == tenant_id_n
        ]

        # Find attempts closed by this decision
        attempt_ids = [
            e.source_id for e in related_edges if e.type == "CLOSED_BY"
        ]
        attempts = [
            Attempt(**self._data["attempts"][aid])
            for aid in attempt_ids
            if aid in self._data["attempts"]
            if _norm_tenant_id(self._data["attempts"][aid].get("tenant_id", "default")) == tenant_id_n
        ]

        return {
            "decision": decision.model_dump(),
            "exchange_record": exc_record.model_dump() if exc_record else None,
            "shaped_by_constraints": [c.model_dump() for c in constraints],
            "preceded_by_attempts": [a.model_dump() for a in attempts],
        }

    # ── Context Brief ──────────────────────────────────────────────────────

    def build_context_brief(
        self,
        entity_id: str | None = None,
        task_type: str | None = None,
        project_id: str | None = None,
        tenant_id: str | None = "default",
        module: str | None = None,
        category: str | None = None,
        since: datetime | None = None,
        origin: str | None = None,
        confidence_min: float = 0.0,
        limit: int = 10,
    ) -> dict:
        """Build the /memory/context response."""
        tenant_id_n = _norm_tenant_id(tenant_id)
        project_id_n = _norm_project_id(project_id)

        active_decisions = [
            d
            for d in self.get_decisions(
                project_id=project_id_n,
                tenant_id=tenant_id_n,
                module=module,
                category=category,
                since=since,
                origin=origin,
                confidence_min=confidence_min,
                limit=limit * 5,
            )
            if d.status == DecisionStatus.active
        ]
        active_constraints = self.get_constraints(
            active_only=True,
            project_id=project_id_n,
            tenant_id=tenant_id_n,
            module=module,
            category=category,
            since=since,
            origin=origin,
            limit=limit * 5,
        )
        preferences = self.get_preferences(
            confidence_min=max(0.5, confidence_min),
            min_reinforcements=1,
            project_id=project_id_n,
            tenant_id=tenant_id_n,
            module=module,
            category=category,
            since=since,
            limit=limit * 5,
        )
        recent_attempts = self.get_attempts(
            project_id=project_id_n,
            tenant_id=tenant_id_n,
            module=module,
            category=category,
            since=since,
            limit=max(5, limit),
        )[:5]  # newest 5

        # Caution flags
        caution_flags = []
        all_decisions = self.get_decisions(
            project_id=project_id_n,
            tenant_id=tenant_id_n,
            module=module,
            category=category,
            since=since,
            origin=origin,
            confidence_min=0.0,
            limit=500,
        )

        # Flag reversed decisions that were re-made
        decision_descs = [d.description.lower()[:60] for d in all_decisions]
        seen = {}
        for d in all_decisions:
            key = d.description.lower()[:60]
            if key in seen:
                caution_flags.append(
                    f"Decision '{d.description[:80]}' has been made more than once — may be unstable"
                )
            seen[key] = True

        # Flag low-reinforcement preferences
        for p in preferences:
            if p.reinforcement_count == 1:
                caution_flags.append(
                    f"Preference '{p.description[:80]}' has low reinforcement count (1) — treat as tentative"
                )

        return {
            "active_decisions": [
                {
                    "id": d.id,
                    "description": d.description,
                    "rationale": d.rationale,
                    "confidence": d.confidence,
                    "made_in": d.made_in,
                }
                for d in active_decisions
            ],
            "active_constraints": [
                {
                    "id": c.id,
                    "description": c.description,
                    "origin": c.origin.value,
                    "scope": c.scope,
                }
                for c in active_constraints
            ],
            "inferred_preferences": [
                {
                    "id": p.id,
                    "type": p.type.value,
                    "domain": p.domain,
                    "description": p.description,
                    "evidence": p.evidence,
                    "confidence": p.confidence,
                    "reinforcement_count": p.reinforcement_count,
                }
                for p in preferences
            ],
            "recent_attempts": [
                {
                    "description": a.description,
                    "abandoned_because": a.abandoned_because,
                }
                for a in recent_attempts
            ],
            "caution_flags": caution_flags,
        }
