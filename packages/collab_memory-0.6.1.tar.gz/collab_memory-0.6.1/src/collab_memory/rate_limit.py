"""
collab_memory/rate_limit.py — Rate Limiting via slowapi

Implementation of the Session 26 research decision:
  - slowapi (Phase 1): in-memory sliding window, no Redis dependency
  - ContentSizeLimitMiddleware: payload size cap (separate OWASP control)
  - Phase 2 (Sprint 28): migrate slowapi to Redis backend when vault Redis added

Research sources (Session 26, 2026-03-28):
  github.com/laurentS/slowapi — 1.9k stars, 9.3k dependents, MIT, production-grade
  OWASP API Security Top 10 — API4 (resource consumption) requires BOTH
    rate limiting (RPM) AND payload caps as independent controls.

Tier limits (per key, per window):
  /memory/*, /decisions*, /constraints*  → 30/minute
  /skills*                               → 30/minute
  /v1/* (LLM proxy)                      → 20/minute
  /ops/*                                 → 10/minute
  everything else                        → 60/minute

Key resolution (X-API-Key preferred, IP fallback):
  slowapi's default key_func uses the client IP. We override it to prefer
  the X-API-Key header — this gives per-agent buckets, not per-IP buckets,
  which matters when multiple agents share an IP (e.g. all running on Render).

Payload cap:
  ContentSizeLimitMiddleware from starlette (bundled with FastAPI) —
  hard-rejects requests over MAX_BODY_BYTES before they hit any handler.
  Default: 1MB (1_048_576 bytes). Set RATE_LIMIT_MAX_BODY_MB to override.

Disabling for tests:
  Set RATE_LIMIT_ENABLED=false — all limiters become no-ops.
"""
from __future__ import annotations

import os
import logging
from typing import Callable

from fastapi import Request
from slowapi import Limiter
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded
from slowapi.middleware import SlowAPIMiddleware
from fastapi.responses import JSONResponse

logger = logging.getLogger(__name__)

# ── Config ────────────────────────────────────────────────────────────────────

ENABLED: bool = os.environ.get("RATE_LIMIT_ENABLED", "true").lower() not in ("false", "0", "no")

# Payload cap — separate from RPM (OWASP API4 requires both independently)
_MAX_BODY_MB: float = float(os.environ.get("RATE_LIMIT_MAX_BODY_MB", "1"))
MAX_BODY_BYTES: int = int(_MAX_BODY_MB * 1_048_576)

# Per-tier limits (requests per minute)
# Override via env vars e.g. RATE_LIMIT_MEMORY=30
_T = {
    "memory":  os.environ.get("RATE_LIMIT_MEMORY",  "30"),
    "skills":  os.environ.get("RATE_LIMIT_SKILLS",  "30"),
    "proxy":   os.environ.get("RATE_LIMIT_PROXY",   "20"),
    "ops":     os.environ.get("RATE_LIMIT_OPS",     "10"),
    "default": os.environ.get("RATE_LIMIT_DEFAULT", "60"),
}

LIMITS = {k: f"{v}/minute" for k, v in _T.items()}


# ── Key function ─────────────────────────────────────────────────────────────

def _key_from_api_key_or_ip(request: Request) -> str:
    """
    Rate limit key: prefer X-API-Key (per-agent) → X-Forwarded-For → client IP.

    This gives each agent its own bucket even if multiple agents share an IP
    (e.g. all deployed on Render). The key is hashed to keep logs clean.
    """
    api_key = request.headers.get("X-API-Key", "").strip()
    if api_key:
        return f"key:{hash(api_key) & 0xFFFFFF:06x}"

    forwarded = request.headers.get("X-Forwarded-For", "").strip()
    if forwarded:
        return f"ip:{forwarded.split(',')[0].strip()}"

    return f"ip:{get_remote_address(request)}"


# ── Limiter singleton ─────────────────────────────────────────────────────────

# slowapi's Limiter is the central object — shared across all endpoints.
# key_func determines how to identify callers.
# storage_uri=None → in-memory (Phase 1). Phase 2: "redis://..."
limiter = Limiter(
    key_func=_key_from_api_key_or_ip,
    default_limits=[LIMITS["default"]],
    enabled=ENABLED,
)


# ── Per-tier limit strings (used as decorator arguments) ──────────────────────

LIMIT_MEMORY  = LIMITS["memory"]    # Apply to /memory/*, /decisions*, /constraints*
LIMIT_SKILLS  = LIMITS["skills"]    # Apply to /skills*
LIMIT_PROXY   = LIMITS["proxy"]     # Apply to /v1/*
LIMIT_OPS     = LIMITS["ops"]       # Apply to /ops/*
LIMIT_DEFAULT = LIMITS["default"]   # Applied globally as fallback


# ── Custom 429 error handler ──────────────────────────────────────────────────

def rate_limit_exceeded_handler(request: Request, exc: RateLimitExceeded) -> JSONResponse:
    """
    Replaces slowapi's default plain-text 429 with a structured JSON response
    that includes Retry-After and enough detail for MCP clients to back off.
    """
    retry_after = getattr(exc, "retry_after", 60)
    logger.warning(
        "rate_limit: 429 | path=%s | limit=%s | key=%s",
        request.url.path,
        exc.detail,
        _key_from_api_key_or_ip(request),
    )
    return JSONResponse(
        status_code=429,
        headers={"Retry-After": str(retry_after)},
        content={
            "error": "Too Many Requests",
            "detail": f"Rate limit exceeded: {exc.detail}",
            "retry_after_seconds": retry_after,
            "hint": "Back off and retry after the Retry-After period.",
        },
    )


# ── Convenience: apply_rate_limits() wires everything into an existing app ────

def apply_rate_limits(app) -> None:
    """
    Wire slowapi and ContentSizeLimitMiddleware into a FastAPI app.

    Call this ONCE during app setup, before any routes are registered.
    Registers:
      1. limiter on app.state (required by slowapi)
      2. SlowAPIMiddleware (handles 429 propagation)
      3. RateLimitExceeded exception handler (JSON responses)
      4. ContentSizeLimitMiddleware (payload cap — separate OWASP control)

    Example::
        from collab_memory.rate_limit import apply_rate_limits
        apply_rate_limits(app)
    """
    from starlette.middleware.base import BaseHTTPMiddleware

    # 1. Attach limiter to app state (slowapi requirement)
    app.state.limiter = limiter

    # 2. SlowAPIMiddleware propagates RateLimitExceeded through FastAPI's
    #    exception handling chain so our handler below fires correctly
    app.add_middleware(SlowAPIMiddleware)

    # 3. JSON 429 handler
    app.add_exception_handler(RateLimitExceeded, rate_limit_exceeded_handler)

    # 4. Payload cap — ContentSizeLimitMiddleware rejects bodies over the limit
    #    before they reach any handler. This is the OWASP API4 payload control
    #    that RPM limiting alone does NOT cover.
    try:
        from starlette.middleware.base import BaseHTTPMiddleware

        class _PayloadCapMiddleware(BaseHTTPMiddleware):
            async def dispatch(self, request: Request, call_next: Callable):
                content_length = request.headers.get("content-length")
                if content_length and int(content_length) > MAX_BODY_BYTES:
                    logger.warning(
                        "payload_cap: 413 | size=%s | limit=%s | path=%s",
                        content_length, MAX_BODY_BYTES, request.url.path,
                    )
                    return JSONResponse(
                        status_code=413,
                        content={
                            "error": "Payload Too Large",
                            "detail": (
                                f"Request body exceeds the {_MAX_BODY_MB:.0f}MB limit. "
                                "Split your request or reduce the payload size."
                            ),
                            "limit_bytes": MAX_BODY_BYTES,
                        },
                    )
                return await call_next(request)

        app.add_middleware(_PayloadCapMiddleware)
        logger.info(
            "rate_limit: ContentSizeLimitMiddleware active (max=%dMB)",
            int(_MAX_BODY_MB),
        )
    except Exception as e:
        logger.warning("rate_limit: payload cap middleware not loaded: %s", e)

    status = "ENABLED" if ENABLED else "DISABLED"
    logger.info(
        "rate_limit: slowapi %s | tiers=%s | payload_cap=%dMB",
        status, LIMITS, int(_MAX_BODY_MB),
    )
    print(
        f"[collab-memory] Rate limiting {status} (slowapi, in-memory) | "
        f"memory={_T['memory']}/min ops={_T['ops']}/min proxy={_T['proxy']}/min | "
        f"payload_cap={_MAX_BODY_MB:.0f}MB"
    )
