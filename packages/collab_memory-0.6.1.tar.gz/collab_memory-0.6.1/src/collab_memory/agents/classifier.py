"""
agents/classifier.py — Classifier agent: LLM classification + score merge.

Responsibility: Call the configured LLM provider (or keyword-only in skip_llm mode),
merge keyword + LLM scores, determine PrimitiveType and whether to encode.

Wraps existing encoder._call_llm() and the score merge logic from encode_exchange().
"""
from __future__ import annotations

from ..encoder import _call_llm, _keyword_score
from ..schema import AMBIGUITY_LOWER, HIGH_SIGNAL_PRIMITIVES, WORTHINESS_THRESHOLD, PrimitiveType, MemorySource
from .state import PipelineState

# Weight split: keyword 30%, LLM 70%
KEYWORD_WEIGHT = 0.3
LLM_WEIGHT = 0.7


def run_classifier(state: PipelineState) -> PipelineState:
    """
    LLM classification agent node.
    Sets llm_result, primitive_type, final_score, flagged, should_encode.
    """
    raw_text = state.get("raw_text", "")
    keyword_score = state.get("keyword_score", 0.0)
    skip_llm = state.get("skip_llm", False)

    try:
        if skip_llm:
            # Keyword-only path: derive primitive type from patterns
            from ..encoder import (
                _OVERRIDE_PATTERNS, _DECISION_PATTERNS,
                _ABANDON_PATTERNS, _CONSTRAINT_PATTERNS,
            )
            ptype = PrimitiveType.Exploration
            if keyword_score >= WORTHINESS_THRESHOLD:
                if _OVERRIDE_PATTERNS.search(raw_text):
                    ptype = PrimitiveType.Override
                elif _DECISION_PATTERNS.search(raw_text):
                    ptype = PrimitiveType.DecisionClose
                elif _ABANDON_PATTERNS.search(raw_text):
                    ptype = PrimitiveType.AbandonedAttempt
                elif _CONSTRAINT_PATTERNS.search(raw_text):
                    ptype = PrimitiveType.ConstraintSurface

            llm_result = {
                "primitive_type": ptype.value,
                "confidence": keyword_score,
                "description": raw_text[:200],
                "rationale": "",
                "evidence": "",
                "reasoning": "keyword-only mode (skip_llm=True)",
            }
            final_score = keyword_score

        else:
            # LLM path — pass graph context when available for context-grounded classification
            graph_context = state.get("graph_context")
            llm_result = _call_llm(raw_text, graph_context=graph_context)
            llm_confidence = float(llm_result.get("confidence", 0.5))
            final_score = (keyword_score * KEYWORD_WEIGHT) + (llm_confidence * LLM_WEIGHT)

            ptype_raw = llm_result.get("primitive_type", "Exploration")
            try:
                ptype = PrimitiveType(ptype_raw)
            except ValueError:
                ptype = PrimitiveType.Exploration

    except Exception as e:
        return {**state, "error": f"Classifier error: {e}"}

    flagged = AMBIGUITY_LOWER <= final_score < WORTHINESS_THRESHOLD
    should_encode = (
        final_score >= WORTHINESS_THRESHOLD
        and ptype in HIGH_SIGNAL_PRIMITIVES
    )

    # Provenance: keyword-only = inferred, LLM = stated (model read the exchange directly)
    memory_source = MemorySource.stated if not skip_llm else MemorySource.inferred

    return {
        **state,
        "llm_result": llm_result,
        "primitive_type": ptype.value,
        "final_score": round(final_score, 3),
        "flagged": flagged,
        "should_encode": should_encode,
        "classifier_reasoning": llm_result.get("reasoning", ""),
        "memory_source": memory_source.value,
    }
