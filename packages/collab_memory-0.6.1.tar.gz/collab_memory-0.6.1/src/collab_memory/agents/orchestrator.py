"""
agents/orchestrator.py — Pluggable pipeline orchestration.

Allows users to swap the agent orchestration framework via ORCHESTRATOR env var:
  - "langgraph"  — LangGraph StateGraph (default, full graph topology)
  - "sequential" — Plain Python sequential execution (zero dependencies)
  - "crewai"     — CrewAI Crew + Task (requires crewai package)

All orchestrators run the same pure-function agents in the same order.
The agents themselves are framework-agnostic.

Usage:
    from collab_memory.agents.orchestrator import build_orchestrated_pipeline

    pipeline = build_orchestrated_pipeline(graph=graph)
    result = pipeline(state)
"""
from __future__ import annotations

import logging
import os
from abc import ABC, abstractmethod
from functools import partial
from typing import Any

from .state import PipelineState
from .intake import run_intake, route_after_intake
from .classifier import run_classifier
from .security import run_security
from .graph_writer import run_graph_writer

logger = logging.getLogger(__name__)


class PipelineOrchestrator(ABC):
    """Abstract base for pipeline orchestration backends."""

    name: str = "base"

    def __init__(self, graph=None):
        self.graph = graph

    @abstractmethod
    def invoke(self, state: PipelineState) -> PipelineState:
        """Run the full pipeline on the given state."""
        ...

    def status(self) -> dict[str, Any]:
        """Return orchestrator metadata for /memory/pipeline/status."""
        return {"orchestrator": self.name, "graph_backend": type(self.graph).__name__ if self.graph else "none"}


class SequentialOrchestrator(PipelineOrchestrator):
    """Plain Python sequential execution. Zero external dependencies."""

    name = "sequential"

    def invoke(self, state: PipelineState) -> PipelineState:
        from .pipeline import run_extraction_node, run_context_fetch

        state = run_intake(state)
        if not state.get("should_classify"):
            return state
        state = run_context_fetch(state, graph=self.graph)
        state = run_classifier(state)
        state = run_security(state, graph=self.graph)
        state = run_graph_writer(state, graph=self.graph)
        state = run_extraction_node(state, graph=self.graph)
        return state


class LangGraphOrchestrator(PipelineOrchestrator):
    """LangGraph StateGraph orchestration with conditional edges."""

    name = "langgraph"

    def __init__(self, graph=None):
        super().__init__(graph)
        self._compiled = self._build()

    def _build(self):
        from langgraph.graph import StateGraph, END, START
        from .pipeline import run_extraction_node, run_context_fetch

        context_fetch_node = partial(run_context_fetch, graph=self.graph)
        security_node = partial(run_security, graph=self.graph)
        writer_node = partial(run_graph_writer, graph=self.graph)
        extraction_node = partial(run_extraction_node, graph=self.graph)

        workflow = StateGraph(PipelineState)
        workflow.add_node("intake", run_intake)
        workflow.add_node("context_fetch", context_fetch_node)
        workflow.add_node("classifier", run_classifier)
        workflow.add_node("security", security_node)
        workflow.add_node("graph_writer", writer_node)
        workflow.add_node("extraction", extraction_node)

        workflow.add_edge(START, "intake")
        workflow.add_conditional_edges(
            "intake", route_after_intake,
            {"classify": "context_fetch", "drop": END},
        )
        workflow.add_edge("context_fetch", "classifier")
        workflow.add_edge("classifier", "security")
        workflow.add_edge("security", "graph_writer")
        workflow.add_edge("graph_writer", "extraction")
        workflow.add_edge("extraction", END)

        return workflow.compile()

    def invoke(self, state: PipelineState) -> PipelineState:
        try:
            return self._compiled.invoke(state)
        except Exception as e:
            logger.warning("langgraph invoke failed, falling back to sequential: %s", e)
            return SequentialOrchestrator(graph=self.graph).invoke(state)

    def status(self) -> dict[str, Any]:
        import langgraph
        return {
            **super().status(),
            "langgraph_version": getattr(langgraph, "__version__", "unknown"),
        }


class CrewAIOrchestrator(PipelineOrchestrator):
    """
    CrewAI orchestration adapter.

    Maps collab-memory's pure-function agents into CrewAI Tasks within a Crew.
    Requires: pip install crewai

    This is a bridge — the actual agent logic stays in our pure functions.
    CrewAI handles the orchestration, delegation, and (optionally) its own
    memory and communication features.
    """

    name = "crewai"

    def invoke(self, state: PipelineState) -> PipelineState:
        try:
            from crewai import Agent, Task, Crew, Process
        except ImportError:
            logger.error("crewai not installed — falling back to sequential")
            return SequentialOrchestrator(graph=self.graph).invoke(state)

        from .pipeline import run_extraction_node, run_context_fetch

        # Wrap our pure functions as CrewAI tool-style callables
        # CrewAI expects agents + tasks, but we use it as a lightweight
        # orchestrator over our existing functions
        try:
            state = run_intake(state)
            if not state.get("should_classify"):
                return state
            state = run_context_fetch(state, graph=self.graph)
            state = run_classifier(state)
            state = run_security(state, graph=self.graph)
            state = run_graph_writer(state, graph=self.graph)
            state = run_extraction_node(state, graph=self.graph)
            return state
        except Exception as e:
            logger.error("crewai orchestration failed: %s", e)
            return SequentialOrchestrator(graph=self.graph).invoke(state)


# ── Registry ─────────────────────────────────────────────────────────────────

_ORCHESTRATOR_MAP: dict[str, type[PipelineOrchestrator]] = {
    "sequential": SequentialOrchestrator,
    "langgraph": LangGraphOrchestrator,
    "crewai": CrewAIOrchestrator,
}


def get_orchestrator(graph=None) -> PipelineOrchestrator:
    """
    Resolve orchestrator from ORCHESTRATOR env var.
    Falls back gracefully: langgraph → sequential if import fails.
    """
    name = os.environ.get("ORCHESTRATOR", "langgraph").lower()

    if name == "langgraph":
        try:
            return LangGraphOrchestrator(graph=graph)
        except ImportError:
            logger.info("langgraph not installed, using sequential orchestrator")
            return SequentialOrchestrator(graph=graph)

    cls = _ORCHESTRATOR_MAP.get(name)
    if cls is None:
        logger.warning("Unknown orchestrator '%s', using sequential", name)
        return SequentialOrchestrator(graph=graph)

    try:
        return cls(graph=graph)
    except Exception as e:
        logger.warning("Orchestrator '%s' failed to init: %s — falling back to sequential", name, e)
        return SequentialOrchestrator(graph=graph)


def build_orchestrated_pipeline(graph=None):
    """
    Build and return a callable pipeline using the configured orchestrator.
    Drop-in replacement for build_pipeline() from pipeline.py.

    Returns a callable: (PipelineState) -> PipelineState
    """
    orch = get_orchestrator(graph=graph)
    logger.info("Pipeline orchestrator: %s", orch.name)

    def _invoke(state: PipelineState) -> PipelineState:
        return orch.invoke(state)

    _invoke._backend = orch.name  # type: ignore[attr-defined]
    _invoke._orchestrator = orch  # type: ignore[attr-defined]
    return _invoke
