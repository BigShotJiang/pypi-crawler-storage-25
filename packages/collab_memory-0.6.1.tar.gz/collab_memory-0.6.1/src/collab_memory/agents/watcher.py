"""
agents/watcher.py — Security Watcher Agent.

Continuous security monitor that runs post-pipeline on every ingest
and on a cron for access-pattern analysis.

Design principles:
  1. FREE-FIRST: Ships with Ollama/Qwen so every instance gets a watcher
     at zero cost. No API key required for base functionality.
  2. MENTORSHIP: When a senior agent (AG/Gemini or Claude) is available,
     the watcher's flagged items get reviewed. Confirmed flags graduate
     into watcher rules (detail → preference → rule). Over time, the
     free watcher learns from the senior agent's judgments.
  3. GRADUATION: Watcher trust_score starts at 0.0. Each confirmed flag
     adds +0.1 (max 1.0). Each false positive subtracts -0.05.
     At trust_score ≥ 0.7, watcher can auto-block without escalation.
     Below that, it flags for human/senior review.

Monitors:
  - Tenant boundary violations (cross-tenant query results)
  - Injection patterns in ingest payloads (beyond regex — semantic)
  - Anomalous access patterns (volume spikes, unusual read patterns)
  - Credential/secret exposure in graph nodes
  - ABAC policy violations (role escalation attempts)

Integration:
  - Plugs into existing LangGraph pipeline as optional post-write node
  - Also runs standalone via /security/scan cron endpoint
  - Uses LLM_PROVIDER env var (same as classifier) — defaults to ollama
"""
from __future__ import annotations

import logging
import os
import re
import time
from dataclasses import dataclass, field
from typing import Any, Optional

logger = logging.getLogger(__name__)

# ── Configuration ─────────────────────────────────────────────────────────────

# Which LLM to use for watcher analysis. Defaults to ollama (free).
# Set WATCHER_LLM_PROVIDER to override separately from the pipeline's LLM_PROVIDER.
WATCHER_LLM_PROVIDER = os.environ.get(
    "WATCHER_LLM_PROVIDER",
    os.environ.get("LLM_PROVIDER", "ollama"),
).lower()

# Mentor agent provider — the senior agent that reviews escalations.
# Set to "" to disable mentorship (watcher runs solo).
MENTOR_LLM_PROVIDER = os.environ.get("MENTOR_LLM_PROVIDER", "").lower()

# Trust threshold: below this, watcher flags but doesn't auto-block.
AUTO_BLOCK_TRUST_THRESHOLD = float(os.environ.get("WATCHER_AUTO_BLOCK_TRUST", "0.7"))

# ── Secret patterns (extended from sanitization.py Layer 0.5) ─────────────────

_SECRET_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    ("api_key_anthropic", re.compile(r"sk-ant-api\S{20,}", re.ASCII)),
    ("api_key_openai", re.compile(r"sk-[A-Za-z0-9]{20,}", re.ASCII)),
    ("api_key_resend", re.compile(r"re_[A-Za-z0-9_]{20,}", re.ASCII)),
    ("api_key_render", re.compile(r"rnd_[A-Za-z0-9]{20,}", re.ASCII)),
    ("jwt", re.compile(r"eyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}", re.ASCII)),
    ("connection_string", re.compile(r"neo4j\+s?://\S+", re.ASCII)),
    ("connection_string", re.compile(r"postgres(ql)?://\S+", re.ASCII)),
    ("connection_string", re.compile(r"mongodb(\+srv)?://\S+", re.ASCII)),
    ("high_entropy_hex", re.compile(r"\b[a-fA-F0-9]{40,}\b", re.ASCII)),
]


@dataclass
class WatcherFinding:
    """A single security finding from the watcher."""
    category: str          # tenant_leak | injection | secret_exposure | anomaly | abac_violation
    severity: str          # critical | high | medium | low | info
    description: str       # Human-readable description
    evidence: str = ""     # What triggered the finding (redacted)
    node_id: str = ""      # Graph node ID if applicable
    tenant_id: str = ""    # Affected tenant
    auto_blocked: bool = False   # True if watcher auto-blocked (trust >= threshold)
    escalated: bool = False      # True if sent to mentor for review


@dataclass
class WatcherReport:
    """Aggregate report from a watcher scan."""
    scan_type: str         # post_ingest | cron_full | cron_access | manual
    findings: list[WatcherFinding] = field(default_factory=list)
    scanned_nodes: int = 0
    scanned_queries: int = 0
    duration_ms: float = 0.0
    watcher_trust_score: float = 0.0
    mentor_available: bool = False

    @property
    def critical_count(self) -> int:
        return sum(1 for f in self.findings if f.severity == "critical")

    @property
    def has_findings(self) -> bool:
        return len(self.findings) > 0


# ── Watcher Agent ─────────────────────────────────────────────────────────────

class SecurityWatcher:
    """
    Security watcher agent. Free-tier-first design.

    Runs three scan types:
      1. post_ingest — lightweight, runs after every pipeline write
      2. cron_access — periodic access pattern analysis
      3. cron_full — comprehensive graph audit (tenant leaks, secrets, stale nodes)
    """

    def __init__(self, graph=None):
        self._graph = graph
        self._trust_score: float = 0.0
        self._mentor_provider: str = MENTOR_LLM_PROVIDER
        self._findings_history: list[dict] = []

    @property
    def trust_score(self) -> float:
        return self._trust_score

    @property
    def can_auto_block(self) -> bool:
        return self._trust_score >= AUTO_BLOCK_TRUST_THRESHOLD

    def load_trust_score(self) -> float:
        """Load trust score from graph (persisted as Agent node property)."""
        if self._graph is None:
            return self._trust_score
        try:
            rows = self._graph._tx_read(
                "MATCH (a:Agent {agent_id: 'security-watcher'}) "
                "RETURN a.trust_score AS ts"
            )
            if rows and rows[0].get("ts") is not None:
                self._trust_score = float(rows[0]["ts"])
        except Exception as e:
            logger.warning("Failed to load watcher trust score: %s", e)
        return self._trust_score

    def save_trust_score(self) -> None:
        """Persist trust score to graph."""
        if self._graph is None:
            return
        try:
            self._graph._tx_write(
                "MERGE (a:Agent {agent_id: 'security-watcher'}) "
                "SET a.trust_score = $ts, a.display_name = 'Security Watcher', "
                "a.platform = 'ollama', a.role = 'admin', a.status = 'active', "
                "a.last_scan = datetime()",
                ts=self._trust_score,
            )
        except Exception as e:
            logger.warning("Failed to save watcher trust score: %s", e)

    def record_mentor_feedback(self, finding_confirmed: bool) -> None:
        """
        Update trust score based on mentor (AG) feedback.

        Confirmed finding: +0.1 (the watcher was right)
        False positive:    -0.05 (the watcher was wrong)

        This IS the graduation mechanism — the free agent earns autonomy
        by being correct, judged by the senior agent.
        """
        if finding_confirmed:
            self._trust_score = min(1.0, self._trust_score + 0.1)
        else:
            self._trust_score = max(0.0, self._trust_score - 0.05)
        self.save_trust_score()

    # ── Scan: Post-Ingest (lightweight, every write) ──────────────────────────

    def scan_post_ingest(
        self,
        raw_text: str,
        nodes_written: list[str],
        tenant_id: str,
    ) -> WatcherReport:
        """
        Fast scan after each pipeline write. Checks:
          1. Secret exposure in the written text / node descriptions
          2. Tenant_id correctness on written nodes
          3. Basic injection signals missed by firewall
        """
        t0 = time.time()
        report = WatcherReport(
            scan_type="post_ingest",
            watcher_trust_score=self._trust_score,
            mentor_available=bool(self._mentor_provider),
        )

        # Check 1: Secret exposure in raw text
        for secret_type, pattern in _SECRET_PATTERNS:
            if pattern.search(raw_text):
                report.findings.append(WatcherFinding(
                    category="secret_exposure",
                    severity="critical",
                    description=f"Secret pattern ({secret_type}) detected in ingested text",
                    evidence=f"[REDACTED {secret_type}]",
                    tenant_id=tenant_id,
                    auto_blocked=self.can_auto_block,
                    escalated=not self.can_auto_block,
                ))

        # Check 2: Verify written nodes have correct tenant_id
        if self._graph and nodes_written:
            report.scanned_nodes = len(nodes_written)
            self._check_tenant_integrity(nodes_written, tenant_id, report)

        # Check 3: Injection signals missed by firewall (LLM-based if available)
        # This is where the free agent vs paid agent difference matters:
        # Ollama/Qwen does pattern matching; Claude/Gemini does semantic analysis
        self._check_injection_signals(raw_text, report, tenant_id)

        report.duration_ms = (time.time() - t0) * 1000
        return report

    # ── Scan: Cron Full (comprehensive, scheduled) ────────────────────────────

    def scan_full(self, tenant_id: Optional[str] = None) -> WatcherReport:
        """
        Comprehensive security audit. Runs on cron (e.g., daily).
        Checks:
          1. Nodes with NULL or 'default' tenant_id (data leak)
          2. Secrets stored in graph node descriptions
          3. Orphan nodes (no relationships)
          4. Stale pending inferences
          5. Cross-tenant relationship edges
        """
        t0 = time.time()
        report = WatcherReport(
            scan_type="cron_full",
            watcher_trust_score=self._trust_score,
            mentor_available=bool(self._mentor_provider),
        )

        if self._graph is None:
            report.findings.append(WatcherFinding(
                category="anomaly",
                severity="high",
                description="Graph backend unavailable — cannot run full scan",
            ))
            return report

        # Check 1: Tenant leak detection (NULL / 'default' tenant_ids)
        self._check_tenant_leaks(report)

        # Check 2: Secrets stored in graph nodes
        self._check_graph_secrets(report, tenant_id)

        # Check 3: Access pattern anomalies (if auth audit data exists)
        self._check_access_patterns(report, tenant_id)

        report.duration_ms = (time.time() - t0) * 1000
        return report

    # ── Scan: Access Patterns (periodic) ──────────────────────────────────────

    def scan_access_patterns(self, tenant_id: Optional[str] = None) -> WatcherReport:
        """
        Analyze recent access patterns for anomalies.
        Checks:
          1. Unusual read volume spikes per tenant
          2. Failed auth attempts concentration
          3. Cross-tenant probe attempts (403 patterns)
        """
        t0 = time.time()
        report = WatcherReport(
            scan_type="cron_access",
            watcher_trust_score=self._trust_score,
            mentor_available=bool(self._mentor_provider),
        )

        if self._graph is None:
            return report

        self._check_access_patterns(report, tenant_id)

        report.duration_ms = (time.time() - t0) * 1000
        return report

    # ── Internal check methods ────────────────────────────────────────────────

    def _check_tenant_integrity(
        self,
        node_ids: list[str],
        expected_tenant: str,
        report: WatcherReport,
    ) -> None:
        """Verify written nodes have the correct tenant_id."""
        if not self._graph or not node_ids:
            return
        try:
            # Check each node type that might have been written
            for nid in node_ids[:20]:  # Cap to prevent slow queries
                rows = self._graph._tx_read(
                    "MATCH (n) WHERE n.id = $nid "
                    "RETURN n.tenant_id AS tid, labels(n) AS labels",
                    nid=nid,
                )
                for row in rows:
                    tid = row.get("tid")
                    labels = row.get("labels", [])
                    if tid is None or tid == "default":
                        report.findings.append(WatcherFinding(
                            category="tenant_leak",
                            severity="critical",
                            description=(
                                f"Node {nid} ({labels}) written without tenant_id"
                            ),
                            node_id=nid,
                            tenant_id=expected_tenant,
                            auto_blocked=self.can_auto_block,
                            escalated=not self.can_auto_block,
                        ))
                    elif tid != expected_tenant:
                        report.findings.append(WatcherFinding(
                            category="tenant_leak",
                            severity="critical",
                            description=(
                                f"Node {nid} ({labels}) has wrong tenant_id: "
                                f"expected {expected_tenant[:8]}..., got {tid[:8]}..."
                            ),
                            node_id=nid,
                            tenant_id=expected_tenant,
                            auto_blocked=self.can_auto_block,
                            escalated=not self.can_auto_block,
                        ))
                    report.scanned_nodes += 1
        except Exception as e:
            logger.warning("Tenant integrity check failed: %s", e)

    def _check_tenant_leaks(self, report: WatcherReport) -> None:
        """Find nodes with NULL or 'default' tenant_id (data leak vector)."""
        try:
            rows = self._graph._tx_read(
                "MATCH (n) "
                "WHERE n.tenant_id IS NULL OR n.tenant_id = 'default' "
                "AND NOT n:Tenant "
                "RETURN labels(n)[0] AS label, count(n) AS cnt "
                "ORDER BY cnt DESC LIMIT 20"
            )
            total_leaked = 0
            for row in rows:
                label = row.get("label", "Unknown")
                cnt = row.get("cnt", 0)
                total_leaked += cnt
                if cnt > 0:
                    report.findings.append(WatcherFinding(
                        category="tenant_leak",
                        severity="critical" if cnt > 100 else "high",
                        description=(
                            f"{cnt:,} {label} nodes have NULL/default tenant_id — "
                            f"visible to all tenants"
                        ),
                        escalated=True,  # Always escalate tenant leaks
                    ))
            report.scanned_queries += 1
        except Exception as e:
            logger.warning("Tenant leak check failed: %s", e)

    def _check_graph_secrets(
        self, report: WatcherReport, tenant_id: Optional[str]
    ) -> None:
        """Scan graph node descriptions for stored secrets."""
        try:
            # Sample recent nodes (last 200) to check for secrets
            tenant_clause = "AND n.tenant_id = $tid" if tenant_id else ""
            rows = self._graph._tx_read(
                f"MATCH (n) WHERE n.description IS NOT NULL {tenant_clause} "
                "RETURN n.id AS id, n.description AS desc, labels(n) AS labels "
                "ORDER BY n.created_at DESC LIMIT 200",
                **({"tid": tenant_id} if tenant_id else {}),
            )
            for row in rows:
                desc = row.get("desc", "")
                for secret_type, pattern in _SECRET_PATTERNS:
                    if pattern.search(desc):
                        report.findings.append(WatcherFinding(
                            category="secret_exposure",
                            severity="critical",
                            description=(
                                f"Secret ({secret_type}) stored in {row.get('labels', ['?'])[0]} "
                                f"node {row.get('id', '?')[:12]}..."
                            ),
                            node_id=row.get("id", ""),
                            tenant_id=tenant_id or "",
                            escalated=True,  # Always escalate secrets
                        ))
                        break  # One finding per node is enough
                report.scanned_nodes += 1
            report.scanned_queries += 1
        except Exception as e:
            logger.warning("Graph secret scan failed: %s", e)

    def _check_access_patterns(
        self, report: WatcherReport, tenant_id: Optional[str]
    ) -> None:
        """Check for anomalous access patterns in AuthAudit nodes."""
        try:
            # Check for concentrated failed auth attempts (brute force signal)
            rows = self._graph._tx_read(
                "MATCH (a:AuthAudit) "
                "WHERE a.action = 'login_failed' "
                "AND a.created_at > datetime() - duration('PT1H') "
                "RETURN a.ip_address AS ip, count(a) AS cnt "
                "ORDER BY cnt DESC LIMIT 10"
            )
            for row in rows:
                ip = row.get("ip", "unknown")
                cnt = row.get("cnt", 0)
                if cnt >= 5:
                    report.findings.append(WatcherFinding(
                        category="anomaly",
                        severity="high" if cnt >= 10 else "medium",
                        description=(
                            f"Brute force signal: {cnt} failed logins from IP "
                            f"{ip[:16]}... in last hour"
                        ),
                        evidence=f"IP: {ip[:16]}..., attempts: {cnt}",
                        escalated=cnt >= 10,
                    ))
            report.scanned_queries += 1
        except Exception as e:
            logger.debug("Access pattern check skipped: %s", e)

    def _check_injection_signals(
        self, text: str, report: WatcherReport, tenant_id: str
    ) -> None:
        """
        Check for injection signals that the regex firewall might miss.

        Free tier (Ollama): Pattern-based heuristics only.
        Paid tier: LLM semantic analysis via mentor provider.
        """
        # Heuristic: unusual Unicode that could be homoglyph attacks
        non_ascii_ratio = sum(1 for c in text if ord(c) > 127) / max(len(text), 1)
        if non_ascii_ratio > 0.3 and len(text) > 50:
            report.findings.append(WatcherFinding(
                category="injection",
                severity="medium",
                description=(
                    f"High non-ASCII ratio ({non_ascii_ratio:.0%}) — "
                    f"possible homoglyph or encoding attack"
                ),
                tenant_id=tenant_id,
                escalated=not self.can_auto_block,
            ))

        # Heuristic: base64-encoded payloads
        b64_pattern = re.compile(r"[A-Za-z0-9+/]{40,}={0,2}")
        if b64_pattern.search(text):
            report.findings.append(WatcherFinding(
                category="injection",
                severity="low",
                description="Possible base64-encoded payload in ingest text",
                tenant_id=tenant_id,
                escalated=False,
            ))

    # ── Escalation to mentor ──────────────────────────────────────────────────

    def escalate_to_mentor(self, finding: WatcherFinding) -> Optional[dict]:
        """
        Send a finding to the mentor agent (AG/Gemini/Claude) for review.

        Returns mentor's judgment: {"confirmed": bool, "reasoning": str}
        or None if mentor is unavailable.

        This is how the free agent learns — every mentor judgment adjusts
        the trust score, and confirmed findings become watcher rules.
        """
        if not self._mentor_provider:
            return None

        try:
            prompt = (
                "You are a cybersecurity analyst reviewing a finding from an automated "
                "security watcher on a multi-tenant knowledge graph platform.\n\n"
                f"Category: {finding.category}\n"
                f"Severity: {finding.severity}\n"
                f"Description: {finding.description}\n"
                f"Evidence: {finding.evidence}\n\n"
                "Is this a legitimate security concern? Respond with JSON:\n"
                '{"confirmed": true/false, "reasoning": "brief explanation", '
                '"adjusted_severity": "critical/high/medium/low/info"}'
            )

            # Use the mentor's LLM provider
            from ..encoder import _PROVIDER_MAP
            provider_fn = _PROVIDER_MAP.get(self._mentor_provider)
            if provider_fn is None:
                logger.warning("Mentor provider %r not found", self._mentor_provider)
                return None

            import json
            raw = provider_fn(prompt)
            # provider_fn returns a dict or raises
            if isinstance(raw, dict):
                confirmed = raw.get("confirmed", False)
            else:
                # Try to parse JSON from text response
                result = json.loads(raw) if isinstance(raw, str) else raw
                confirmed = result.get("confirmed", False)

            self.record_mentor_feedback(confirmed)
            return {"confirmed": confirmed, "reasoning": raw.get("reasoning", "")}

        except Exception as e:
            logger.warning("Mentor escalation failed: %s", e)
            return None

    # ── Report serialization ──────────────────────────────────────────────────

    def save_report(self, report: WatcherReport, tenant_id: str = "") -> Optional[str]:
        """
        Persist a watcher report as a graph node for audit trail.
        Returns the report node ID.
        """
        if self._graph is None:
            return None
        try:
            import uuid
            report_id = f"watch_{uuid.uuid4().hex[:12]}"
            self._graph._tx_write(
                "CREATE (r:WatcherReport {"
                "  id: $rid, scan_type: $stype, "
                "  findings_count: $fc, critical_count: $cc, "
                "  scanned_nodes: $sn, scanned_queries: $sq, "
                "  duration_ms: $dur, watcher_trust_score: $ts, "
                "  tenant_id: $tid, created_at: datetime()"
                "})",
                rid=report_id,
                stype=report.scan_type,
                fc=len(report.findings),
                cc=report.critical_count,
                sn=report.scanned_nodes,
                sq=report.scanned_queries,
                dur=report.duration_ms,
                ts=report.watcher_trust_score,
                tid=tenant_id,
            )
            return report_id
        except Exception as e:
            logger.warning("Failed to save watcher report: %s", e)
            return None


# ── Module-level convenience ──────────────────────────────────────────────────

def create_watcher(graph=None) -> SecurityWatcher:
    """Create a SecurityWatcher instance, loading trust score from graph."""
    watcher = SecurityWatcher(graph=graph)
    watcher.load_trust_score()
    return watcher
