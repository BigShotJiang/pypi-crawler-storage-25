"""
agents/pipeline.py — LangGraph StateGraph:
  Intake → Context Fetch → Classifier → Security → Graph Writer → Fact Extractor → Memory Consolidator

Graph topology:
  START → intake → [route_after_intake] → context_fetch → classifier → security → graph_writer
                                         ↘ (low-signal drop) → END
                                 graph_writer → extraction → END

Sprint S9: Added Fact Extractor + Memory Consolidator as the 5th and 6th nodes.
Sprint S10: Added Context Fetch before classifier — injects live graph context so the
            LLM classifies with awareness of active decisions/constraints/preferences.

Design: graph backend is injected at call time via functools.partial
        so the same compiled pipeline can be reused across requests.
"""
from __future__ import annotations

import asyncio
import logging
import threading
from functools import partial
from typing import Any

from .state import PipelineState
from .intake import run_intake, route_after_intake
from .classifier import run_classifier
from .security import run_security
from .graph_writer import run_graph_writer

logger = logging.getLogger(__name__)

# Ordered stage IDs for LangGraph pipeline status (API + tests use this as the contract).
PIPELINE_STAGE_AGENT_IDS: tuple[str, ...] = (
    "intake",
    "classifier",
    "security",
    "graph_writer",
    "extraction",
)

# ─── LLM Client Adapter ───────────────────────────────────────────────────────
# fact_extractor and memory_consolidator require an async llm_client.generate().
# We wrap encoder._call_llm (sync) so it satisfies that interface.

class _LLMClientAdapter:
    """Bridges encoder._call_llm_text (sync) to the async .generate() API.

    fact_extractor and memory_consolidator call:
        text = await llm_client.generate(system_prompt, user_prompt)
    and expect a raw text string back, which they parse themselves.

    _call_llm returns a dict (JSON-parsed classification result).
    _call_llm_text returns the raw LLM text — this is what we need here.
    """

    def __init__(self):
        self._call = None

    def _get_call(self):
        if self._call is None:
            try:
                from ..encoder import _call_llm_text
                self._call = _call_llm_text
            except Exception:
                self._call = lambda s, u: ""
        return self._call

    async def generate(self, system: str, user: str) -> str:
        """Run sync LLM text call from async context via thread executor."""
        call = self._get_call()
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, call, system, user)


def _run_async_in_thread(coro) -> Any:
    """
    Run an async coroutine from a synchronous context.
    Creates a fresh event loop in a daemon thread to avoid conflicts with
    uvicorn's main event loop. Safe from FastAPI thread-pool workers.
    """
    result_holder = [None]
    exc_holder = [None]

    def _target():
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            result_holder[0] = loop.run_until_complete(coro)
        except Exception as e:
            exc_holder[0] = e
        finally:
            loop.close()

    t = threading.Thread(target=_target, daemon=True)
    t.start()
    t.join(timeout=45)  # extraction + consolidation should complete in < 30s

    if exc_holder[0]:
        raise exc_holder[0]
    return result_holder[0]


# ─── Extraction Node (Fact Extractor + Memory Consolidator) ───────────────────

def run_extraction_node(state: PipelineState, graph=None) -> PipelineState:
    """
    LangGraph node: Fact Extractor → Memory Consolidator.

    Extracts atomic, self-contained facts from the raw exchange and evaluates
    each against existing graph nodes (ADD/UPDATE/DELETE/NOOP).

    This runs AFTER graph_writer so the main write path is never blocked.
    Gracefully degrades: any error here leaves the graph_writer's write intact.
    """
    raw_text = state.get("raw_text", "")
    # ── Type guard: Neo4j may return legacy ExchangeRecord dicts instead of str ──
    # Calling .strip() on a dict causes the extraction_node crash loop (OOM on Render).
    if isinstance(raw_text, dict):
        raw_text = raw_text.get("text") or raw_text.get("raw_text") or raw_text.get("content") or ""
        logger.warning("extraction_node: raw_text was a dict (legacy node), coerced to str")
    raw_text = str(raw_text) if raw_text else ""
    session_id = state.get("session_id", "unknown")
    project_id = state.get("project_id")

    # Guard: raw_text may arrive as a dict (e.g. ExchangeRecord node from Neo4j poll watcher).
    # Always coerce to string before calling .strip() or passing to LLM.
    if isinstance(raw_text, dict):
        raw_text = raw_text.get("text", "") or raw_text.get("content", "") or str(raw_text)
    raw_text = str(raw_text) if raw_text is not None else ""

    state["extraction_facts"] = []
    state["extraction_results"] = []

    if not raw_text.strip() or graph is None:
        return state

    llm_client = _LLMClientAdapter()

    async def _extract_and_consolidate():
        from .fact_extractor import extract_facts
        from .memory_consolidator import consolidate_fact, apply_consolidation

        facts = await extract_facts(raw_text, session_id, llm_client)
        if not facts:
            return [], []

        results = []
        for fact in facts:
            try:
                decision = await consolidate_fact(fact, graph, llm_client)
                result = await apply_consolidation(
                    decision, graph, session_id, project_id=project_id
                )
                results.append(result)
            except Exception as e:
                logger.warning("extraction_node: fact failed: %s", e)
                results.append({"operation": "ERROR", "status": str(e)})

        return facts, results

    try:
        facts, results = _run_async_in_thread(_extract_and_consolidate())
        state["extraction_facts"] = [
            {
                "content": f.content,
                "type": f.type,
                "confidence": f.confidence,
            }
            for f in (facts or [])
        ]
        state["extraction_results"] = results or []
        logger.info(
            "extraction_node: %d facts → %d ops (session=%s)",
            len(facts or []), len(results or []), session_id,
        )
    except Exception as e:
        logger.error("extraction_node: pipeline error: %s", e)

    return state


# ─── Context Fetch Node ───────────────────────────────────────────────────────

def run_context_fetch(state: PipelineState, graph=None) -> PipelineState:
    """
    Fetch active graph context (decisions/constraints/preferences) and store
    in state["graph_context"] so the classifier prompt is project-aware.
    Gracefully degrades: any error here leaves graph_context as an empty dict.
    """
    if graph is None:
        return {**state, "graph_context": {}}
    try:
        # Scope context to project if known — improves classifier accuracy
        project_id = state.get("project_id") or state.get("metadata", {}).get("project_id")
        tenant_id = state.get("tenant_id")
        brief = graph.build_context_brief(
            project_id=project_id,
            tenant_id=tenant_id,
            limit=15,
        )
        return {**state, "graph_context": brief}
    except Exception as e:
        logger.warning("context_fetch: failed to load graph context: %s", e)
        return {**state, "graph_context": {}}


# ─── Fallback: plain-function pipeline ────────────────────────────────────────

def _run_plain_pipeline(state: PipelineState, graph=None) -> PipelineState:
    """Fallback sequential pipeline (no LangGraph overhead)."""
    state = run_intake(state)
    if not state.get("should_classify"):
        return state
    state = run_context_fetch(state, graph=graph)
    state = run_classifier(state)
    state = run_security(state, graph=graph)
    state = run_graph_writer(state, graph=graph)
    state = run_extraction_node(state, graph=graph)
    return state


# ─── LangGraph Pipeline ───────────────────────────────────────────────────────

def build_pipeline(graph=None):
    """
    Build and return the compiled LangGraph pipeline (or plain fallback).
    Nodes: intake → classifier → security → graph_writer → extraction
    """
    try:
        from langgraph.graph import StateGraph, END, START

        context_fetch_node = partial(run_context_fetch, graph=graph)
        security_node = partial(run_security, graph=graph)
        writer_node = partial(run_graph_writer, graph=graph)
        extraction_node = partial(run_extraction_node, graph=graph)

        workflow = StateGraph(PipelineState)
        workflow.add_node("intake", run_intake)
        workflow.add_node("context_fetch", context_fetch_node)
        workflow.add_node("classifier", run_classifier)
        workflow.add_node("security", security_node)
        workflow.add_node("graph_writer", writer_node)
        workflow.add_node("extraction", extraction_node)

        workflow.add_edge(START, "intake")
        workflow.add_conditional_edges(
            "intake",
            route_after_intake,
            {
                "classify": "context_fetch",
                "drop":     END,
            },
        )
        workflow.add_edge("context_fetch", "classifier")
        workflow.add_edge("classifier", "security")
        workflow.add_edge("security", "graph_writer")
        workflow.add_edge("graph_writer", "extraction")
        workflow.add_edge("extraction", END)

        compiled = workflow.compile()
        _BACKEND = "langgraph"

    except ImportError:
        compiled = None
        _BACKEND = "plain"

    def _invoke(state: PipelineState) -> PipelineState:
        if compiled is not None:
            try:
                if hasattr(compiled, "invoke"):
                    result = compiled.invoke(state)
                else:
                    result = compiled(state)
            except Exception:
                result = _run_plain_pipeline(state, graph=graph)
            return result
        else:
            return _run_plain_pipeline(state, graph=graph)

    _invoke._backend = _BACKEND  # type: ignore[attr-defined]
    return _invoke


# ─── Convenience wrapper ──────────────────────────────────────────────────────

def run_pipeline(
    raw_text: str,
    session_id: str,
    turn_start: int = 0,
    turn_end: int | None = None,
    skip_llm: bool = False,
    graph=None,
    project_id: str | None = None,
) -> PipelineState:
    """
    Build pipeline and process a single exchange.

    Args:
        raw_text:    Raw exchange text to classify.
        session_id:  Session identifier for graph nodes.
        turn_start:  Turn index start.
        turn_end:    Turn index end (defaults to turn_start).
        skip_llm:    If True, use keyword-only classification.
        graph:       Graph backend instance.
        project_id:  Project scope for new nodes (passed to extraction node).

    Returns:
        Final PipelineState after all agents have run.
    """
    pipeline = build_pipeline(graph=graph)
    state: PipelineState = {
        "raw_text": raw_text,
        "session_id": session_id,
        "turn_start": turn_start,
        "turn_end": turn_end if turn_end is not None else turn_start,
        "skip_llm": skip_llm,
        "project_id": project_id,
    }
    return pipeline(state)


def get_pipeline_status(graph=None) -> dict[str, Any]:
    """Return pipeline configuration for GET /memory/pipeline/status."""
    import os
    try:
        import langgraph
        backend = "langgraph"
        version = getattr(langgraph, "__version__", "unknown")
    except ImportError:
        backend = "plain"
        version = "N/A"

    return {
        "backend": backend,
        "langgraph_version": version,
        "llm_provider": os.environ.get("LLM_PROVIDER", "gemini"),
        "agents": list(PIPELINE_STAGE_AGENT_IDS),
        "graph_backend": type(graph).__name__ if graph else "none",
    }
