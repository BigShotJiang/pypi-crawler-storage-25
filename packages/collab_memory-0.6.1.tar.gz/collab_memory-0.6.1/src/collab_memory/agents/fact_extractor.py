"""
agents/fact_extractor.py — Atomic Fact Extraction agent (mem0-style).

Responsibility: Given a raw exchange, extract a list of atomic, self-contained
facts using an LLM. Each fact is smaller than a full exchange and maps to a
single Decision, Constraint, Preference or Observation.

Source: research_extended_topics.md §7 (mem0 pipeline)
Design: One LLM call per exchange → list of AtomicFact objects.
        Each fact is then evaluated by memory_consolidator.py (ADD/UPDATE/DELETE/NOOP).

Why atomic? One exchange often contains multiple independent facts:
    "We decided to use Redis for caching — the team prefers managed services and
     we already have an account. Postgres was ruled out because of connection limits."
    → Fact 1: Decision — Use Redis for caching
    → Fact 2: Preference — Team prefers managed services
    → Fact 3: Constraint — Postgres ruled out due to connection limits
    → Fact 4: Attempt — Postgres was considered but abandoned
"""
from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger(__name__)

EXTRACTION_SYSTEM_PROMPT = """You are a precise knowledge extraction system for a software project memory graph.
Your job is to extract atomic facts from a conversation exchange.

Rules:
- Each fact must be SELF-CONTAINED (no pronouns, no implicit references — make every fact stand alone)
- Each fact must be MINIMAL — one idea per fact  
- Use exact names and references (e.g. "Redis" not "it", "the session endpoint" not "the endpoint")
- Include the WHY when it is stated or strongly implied
- Ignore pleasantries, acknowledgements, and meta-conversation
- Confidence < 0.5 means the fact is speculative or unclear

Fact types:
- "decision": A choice that has been made or closed (use past tense or "we decided/will use")
- "constraint": A hard limit or boundary that cannot be violated
- "preference": A preference, working style, or non-binding inclination
- "observation": A factual observation about the system, codebase, or environment  
- "attempt": Something that was tried and abandoned or failed
"""

EXTRACTION_USER_TEMPLATE = """Extract all atomic facts from this exchange. Return ONLY valid JSON.

Exchange:
{exchange_text}

Return format:
[
  {{
    "content": "...",
    "type": "decision|constraint|preference|observation|attempt",
    "confidence": 0.0-1.0,
    "rationale": "why this fact was extracted (brief)"
  }}
]

If no meaningful facts exist, return an empty array: []
"""


@dataclass
class AtomicFact:
    content: str
    type: str                       # decision | constraint | preference | observation | attempt
    confidence: float = 0.8
    rationale: str = ""
    source_exchange: str = ""       # backref to raw exchange text
    session_id: str = ""


async def extract_facts(
    exchange_text: str,
    session_id: str,
    llm_client=None,
) -> list[AtomicFact]:
    """
    Extract atomic facts from a single exchange using an LLM.

    Args:
        exchange_text: The raw conversation exchange to process.
        session_id:    The session ID for provenance tracking.
        llm_client:    Async LLM client. Must have a .generate(system, user) method.
                       If None, returns empty list (graceful degradation).

    Returns:
        List of AtomicFact objects, possibly empty.
    """
    # Guard: coerce dict to str (e.g. when raw_text from Neo4j is a map property)
    if isinstance(exchange_text, dict):
        exchange_text = exchange_text.get("text", "") or exchange_text.get("content", "") or str(exchange_text)
    exchange_text = str(exchange_text) if exchange_text is not None else ""

    if not exchange_text or not exchange_text.strip():
        return []

    if llm_client is None:
        logger.warning("fact_extractor: no LLM client provided, skipping extraction")
        return []

    user_prompt = EXTRACTION_USER_TEMPLATE.format(exchange_text=exchange_text.strip())

    try:
        raw_response = await llm_client.generate(
            system=EXTRACTION_SYSTEM_PROMPT,
            user=user_prompt,
        )
    except Exception as e:
        logger.error("fact_extractor: LLM call failed: %s", e)
        return []

    # Parse JSON — handle LLM wrapping it in markdown code fences
    cleaned = raw_response.strip()
    # Strip ```json ... ``` or ``` ... ``` blocks
    cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned)
    cleaned = re.sub(r"\s*```$", "", cleaned)

    try:
        items = json.loads(cleaned)
        if not isinstance(items, list):
            logger.warning("fact_extractor: unexpected LLM response shape, expected list")
            return []
    except json.JSONDecodeError as e:
        logger.error("fact_extractor: JSON parse failed: %s | raw: %s", e, raw_response[:200])
        return []

    facts: list[AtomicFact] = []
    for item in items:
        if not isinstance(item, dict) or not item.get("content"):
            continue
        facts.append(AtomicFact(
            content=item.get("content", "").strip(),
            type=item.get("type", "observation").lower(),
            confidence=float(item.get("confidence", 0.8)),
            rationale=item.get("rationale", ""),
            source_exchange=exchange_text[:200],  # truncated for storage
            session_id=session_id,
        ))

    logger.info(
        "fact_extractor: extracted %d facts from exchange (session=%s)",
        len(facts), session_id,
    )
    return facts
