"""
agents/state.py — Shared PipelineState TypedDict.

This is the message object that flows through every LangGraph node.
Every agent reads from it and writes back to it.
"""
from __future__ import annotations
from typing import TypedDict, Any


class PipelineState(TypedDict, total=False):
    """
    Shared state flowing through the 6-agent pipeline.
    All fields are optional (total=False) because agents set them incrementally.
    """

    # ─── Input ──────────────────────────────────────────────────────────────────
    raw_text: str           # Raw conversation exchange text
    session_id: str         # Session this exchange belongs to
    turn_start: int         # Turn index start
    turn_end: int           # Turn index end (defaults to turn_start)
    skip_llm: bool          # If True: keyword-only path (test / batch mode)
    project_id: str         # Optional project scope for context + writes
    tenant_id: str          # Optional tenant scope for context + security checks

    # ─── Intake output ──────────────────────────────────────────────────────────
    keyword_score: float    # 0.0–1.0 from keyword pre-screen
    should_classify: bool   # False → drop early (score < 0.10)

    # ─── Classifier output ──────────────────────────────────────────────────────
    llm_result: dict[str, Any]  # Raw LLM JSON response
    primitive_type: str     # PrimitiveType value string
    final_score: float      # Merged keyword + LLM score
    flagged: bool           # True = in ambiguity band (0.3–0.4)
    should_encode: bool     # True = above threshold + high-signal primitive

    # ─── Security/Drift output ──────────────────────────────────────────────────
    contradiction_detected: bool    # True = conflict with existing graph node
    contradiction_detail: str       # Human-readable conflict summary

    # ─── Graph Writer output ────────────────────────────────────────────────────
    exchange_record_id: str         # ID of the written ExchangeRecord
    nodes_generated: list[str]      # IDs of generated graph nodes
    pending_confirmation: bool      # True = inferred+novel → routed to pending queue
    classifier_reasoning: str       # LLM reasoning string for transparency

    # ─── Context (fetched before classification) ────────────────────────────────
    graph_context: dict             # Active decisions/constraints/preferences from graph

    # ─── Error ──────────────────────────────────────────────────────────────────
    error: str                      # Set if any agent raises an exception
