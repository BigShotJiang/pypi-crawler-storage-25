"""
agents/consolidator.py — End-of-session Episode consolidation (RAPTOR Layer 1).

Responsibility: At session end, summarize the session's exchanges into a
single Episode node — the first level of the RAPTOR hierarchy.

Source: research_deep_five_topics.md §5 (Memory Consolidation / CLS theory)
        research_extended_topics.md §11 (RAPTOR implementation)

Biological analog:
    Sharp-wave ripple (SWR) replay during slow-wave sleep.
    Hippocampus (ExchangeRecords) → replay → Neocortex (Episode node).

The Episode node captures:
    - A concise LLM-generated summary of the session
    - Dominant themes (for cross-session clustering)
    - Counts of each node type created
    - Its own embedding (for RAPTOR Layer 2 Sprint clustering)

Future: Sprint consolidator will cluster Episodes into Sprint nodes.
"""
from __future__ import annotations

import json
import logging
import re
from datetime import datetime, timezone
from typing import Optional
import asyncio

logger = logging.getLogger(__name__)

CONSOLIDATION_SYSTEM = """You are a memory consolidation system for a software project.
Your job is to synthesize the key learnings from a work session into a concise,
structured summary that a future agent can use to understand what happened.

Focus on:
1. What was decided (decisions made)
2. What was learned (discoveries, findings)
3. What was built or changed (artifacts, code)
4. What's still open or blocked (gaps, questions)
5. Dominant themes (3-5 keywords)

Be specific. Use proper nouns. Avoid vague language.
"""

CONSOLIDATION_USER_TEMPLATE = """Summarize this work session for a future agent.

Session ID: {session_id}
Project: {project_id}
Duration: {exchange_count} exchanges processed

Key nodes created this session:
{node_summary}

Sample exchanges (truncated):
{exchange_samples}

Return ONLY valid JSON:
{{
  "summary": "<2-4 sentence narrative summary of what happened>",
  "themes": ["<theme1>", "<theme2>", "<theme3>"],
  "key_decisions": ["<decision1>", "<decision2>"],
  "open_questions": ["<question1>"]
}}
"""


async def consolidate_session(
    session_id: str,
    project_id: Optional[str] = None,
    graph=None,
    llm_client=None,
) -> dict:
    """
    Create an Episode node summarizing the session's exchanges and decisions.

    This is the "synthetic sleep" — the memory consolidation that moves
    information from episodic (individual exchanges) toward semantic (themes).

    Args:
        session_id:  The session to consolidate.
        project_id:  Project scope.
        graph:       Graph backend (must support get_session_exchanges, save_episode).
        llm_client:  Async LLM client for summarization.

    Returns:
        Dict with episode_id, summary, themes, and status.
    """
    from ..schema import Episode

    if graph is None:
        return {"status": "error", "message": "No graph backend provided"}

    # Fetch session data
    exchanges = []
    if hasattr(graph, "get_exchange_history"):
        try:
            result = await asyncio.to_thread(
                graph.get_exchange_history, session_id=session_id, limit=200
            )
            exchanges = result.get("records", result) if isinstance(result, dict) else result
        except Exception as e:
            logger.warning("consolidator: could not fetch exchanges: %s", e)

    # Fetch nodes created in this session
    decisions, constraints, preferences = [], [], []
    if hasattr(graph, "get_context"):
        try:
            ctx = await asyncio.to_thread(
                graph.get_context, project_id=project_id or "default"
            )
            # Filter to nodes from this session
            all_decisions = ctx.get("decisions", [])
            decisions = [d for d in all_decisions if d.get("made_in") == session_id or d.get("session_id") == session_id]
            all_constraints = ctx.get("constraints", [])
            constraints = [c for c in all_constraints if c.get("surfaced_in") == session_id]
            all_prefs = ctx.get("preferences", [])
            preferences = [p for p in all_prefs if p.get("inferred_in") == session_id]
        except Exception as e:
            logger.warning("consolidator: could not fetch context: %s", e)

    exchange_count = len(exchanges)
    decision_count = len(decisions)
    constraint_count = len(constraints)
    preference_count = len(preferences)

    # Build node summary for prompt
    node_summary_lines = []
    for d in decisions[:5]:
        node_summary_lines.append(f"  Decision: {d.get('description', '')[:100]}")
    for c in constraints[:3]:
        node_summary_lines.append(f"  Constraint: {c.get('description', '')[:100]}")
    for p in preferences[:3]:
        node_summary_lines.append(f"  Preference: {p.get('description', '')[:100]}")
    node_summary = "\n".join(node_summary_lines) or "  (no nodes created this session)"

    # Sample exchanges for context
    exchange_samples_lines = []
    for ex in exchanges[:5]:
        text = ex.get("raw_text", ex.get("text", ""))[:150]
        if text:
            exchange_samples_lines.append(f"  [{ex.get('primitive_type','?')}] {text}")
    exchange_samples = "\n".join(exchange_samples_lines) or "  (no exchange samples available)"

    # Build summary via LLM or fallback
    summary = ""
    themes = []
    key_decisions = [d.get("description", "")[:80] for d in decisions[:3]]
    open_questions = []

    if llm_client is not None:
        user_prompt = CONSOLIDATION_USER_TEMPLATE.format(
            session_id=session_id,
            project_id=project_id or "default",
            exchange_count=exchange_count,
            node_summary=node_summary,
            exchange_samples=exchange_samples,
        )
        try:
            raw = await llm_client.generate(
                system=CONSOLIDATION_SYSTEM,
                user=user_prompt,
            )
            cleaned = raw.strip()
            cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned)
            cleaned = re.sub(r"\s*```$", "", cleaned)
            parsed = json.loads(cleaned)
            summary = parsed.get("summary", "")
            themes = parsed.get("themes", [])
            key_decisions = parsed.get("key_decisions", key_decisions)
            open_questions = parsed.get("open_questions", [])
        except Exception as e:
            logger.error("consolidator: LLM summarization failed: %s", e)

    # Fallback summary if LLM failed or unavailable
    if not summary:
        summary = (
            f"Session {session_id}: {exchange_count} exchanges processed. "
            f"{decision_count} decisions, {constraint_count} constraints, "
            f"{preference_count} preferences recorded."
        )
        themes = ["session", project_id or "default"]

    # Create the Episode node
    episode = Episode(
        session_id=session_id,
        project_id=project_id,
        summary=summary,
        themes=themes,
        decision_count=decision_count,
        constraint_count=constraint_count,
        preference_count=preference_count,
        exchange_count=exchange_count,
        created_at=datetime.now(timezone.utc),
    )

    # Persist to graph
    episode_id = episode.id
    if hasattr(graph, "save_episode"):
        try:
            await asyncio.to_thread(graph.save_episode, episode)
            logger.info("consolidator: Episode node %s created for session %s", episode_id, session_id)
        except Exception as e:
            logger.error("consolidator: save_episode failed: %s", e)
            return {
                "status": "error",
                "message": f"Episode creation failed: {e}",
                "episode_id": None,
            }
    elif hasattr(graph, "save_node"):
        # Fallback: use generic save_node if save_episode not implemented yet
        try:
            await asyncio.to_thread(graph.save_node, episode)
            logger.info("consolidator: Episode node %s saved via save_node", episode_id)
        except Exception as e:
            logger.error("consolidator: save_node for episode failed: %s", e)
            return {"status": "error", "message": str(e), "episode_id": None}
    else:
        return {"status": "error", "message": "Graph backend has no save method", "episode_id": None}

    # ── PROTOCOLS.md auto-write ───────────────────────────────────────────────
    # Core Memory Block pattern (MemGPT-inspired): write standing rules to
    # .agents/PROTOCOLS.md so agents naturally pick them up at session start.
    try:
        await asyncio.to_thread(
            _write_protocols_md, graph, project_id or "default"
        )
        logger.info("consolidator: .agents/PROTOCOLS.md updated")
    except Exception as e:
        logger.warning("consolidator: PROTOCOLS.md write failed (non-fatal): %s", e)

    return {
        "status": "ok",
        "episode_id": episode_id,
        "session_id": session_id,
        "summary": summary,
        "themes": themes,
        "counts": {
            "decisions": decision_count,
            "constraints": constraint_count,
            "preferences": preference_count,
            "exchanges": exchange_count,
        },
    }


def _write_protocols_md(graph, project_id: str) -> None:
    """
    Generate .agents/PROTOCOLS.md from current Co-Lab context.

    This file is the 'core memory block' that agents read at session start.
    Written to the project directory so it's version-controlled and always
    available in the workspace.
    """
    import os
    from datetime import datetime, timezone

    # Fetch current context
    ctx = {}
    if hasattr(graph, "get_context"):
        try:
            ctx = graph.get_context(project_id=project_id)
        except Exception:
            pass

    decisions = ctx.get("decisions", [])[:15]
    constraints = ctx.get("constraints", [])[:10]
    preferences = ctx.get("preferences", [])[:10]

    lines = [
        "# Co-Lab Operating Protocols",
        f"**Auto-generated:** {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}",
        f"**Project:** {project_id}",
        "",
        "---",
        "",
        "## Session Start Checklist",
        "",
        "1. Call `mcp_collab-memory_get_context()` to load decisions, constraints, preferences",
        "2. Call `mcp_collab-memory_get_pending()` to check items awaiting review",
        "3. Check `.env` and `mcp_config.json` for credentials before asking the user",
        "4. Read this file for standing rules",
        "",
    ]

    if decisions:
        lines.extend(["## Standing Decisions", ""])
        for d in decisions:
            desc = d.get("description", d.get("content", ""))[:120]
            lines.append(f"- {desc}")
        lines.append("")

    if constraints:
        lines.extend(["## Active Constraints", ""])
        for c in constraints:
            desc = c.get("description", c.get("content", ""))[:120]
            lines.append(f"- {desc}")
        lines.append("")

    if preferences:
        lines.extend(["## User Preferences", ""])
        for p in preferences:
            desc = p.get("description", p.get("content", ""))[:120]
            lines.append(f"- {desc}")
        lines.append("")

    lines.extend([
        "## Credential Retrieval Protocol",
        "",
        "Before asking the user for any credential:",
        "1. Check `.env` file",
        "2. Check `mcp_config.json`",
        "3. Check shell history and running process args",
        "4. Use CLI → MCP → REST API → browser (last resort)",
        "",
        "## Session End",
        "",
        "1. Call `mcp_collab-memory_consolidate_session()`",
        "2. Record any new decisions with `mcp_collab-memory_record_decision()`",
        "3. Update `docs/ROADMAP.md` if tasks were completed or added",
        "",
    ])

    content = "\n".join(lines)

    # Write to .agents/PROTOCOLS.md in the project root
    # Try common project root locations
    project_root = os.environ.get("PROJECT_ROOT", "")
    if not project_root:
        # Try to find .agents/ relative to the package
        pkg_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        if os.path.isdir(os.path.join(pkg_dir, ".agents")):
            project_root = pkg_dir
        elif os.path.isdir(os.path.join(pkg_dir, "..", ".agents")):
            project_root = os.path.join(pkg_dir, "..")

    if project_root:
        protocols_dir = os.path.join(project_root, ".agents")
        os.makedirs(protocols_dir, exist_ok=True)
        protocols_path = os.path.join(protocols_dir, "PROTOCOLS.md")
        with open(protocols_path, "w") as f:
            f.write(content)
        logger.info("consolidator: wrote PROTOCOLS.md to %s", protocols_path)
    else:
        logger.warning("consolidator: could not determine project root for PROTOCOLS.md")
