"""
agents/python_runner.py — Sandboxed Python interpreter for agent use.

Allows AI agents to execute Python code snippets safely via a subprocess
with strict timeout, memory limits, and blocked dangerous operations.

Security model:
  - Runs in a subprocess (not exec/eval — process isolation)
  - No network access (BLOCKED_IMPORTS checked before execution)
  - No filesystem writes outside /tmp
  - Hard timeout: 30s (configurable via MAX_EXEC_SECONDS env)
  - Hard memory cap: 128MB (enforced via resource limits where supported)

Useful for:
  - Data analysis and transformation
  - Checking math / algo correctness
  - Testing schema validation logic
  - Quick prototyping without leaving the agent context

Use POST /agent/python/run or the MCP tool 'run_python'.
"""
from __future__ import annotations

import os
import subprocess
import sys
import textwrap
import tempfile
from typing import Optional

# Imports that should not be allowed inside user code
BLOCKED_IMPORTS = frozenset([
    "socket", "requests", "httpx", "urllib3", "aiohttp",    # network
    "paramiko", "ftplib", "smtplib", "poplib", "imaplib",   # remote access
])

MAX_EXEC_SECONDS = int(os.environ.get("PYTHON_RUNNER_TIMEOUT", 30))
MAX_MEMORY_MB    = int(os.environ.get("PYTHON_RUNNER_MEMORY_MB", 128))
MAX_OUTPUT_BYTES = 16_384  # 16 KB max combined stdout+stderr


def _check_blocked_imports(code: str) -> list[str]:
    """Quick static check for obviously blocked imports. Not a full AST check."""
    found = []
    for line in code.splitlines():
        stripped = line.strip().lstrip("# ")  # skip comments
        for blocked in BLOCKED_IMPORTS:
            if f"import {blocked}" in line or f"from {blocked}" in line:
                found.append(blocked)
    return list(set(found))


def run_python(
    code: str,
    timeout: int | None = None,
    inject_vars: dict | None = None,
) -> dict:
    """
    Execute Python code in a sandboxed subprocess.

    Args:
        code:        Python source code to execute.
        timeout:     Max execution seconds (default: MAX_EXEC_SECONDS).
        inject_vars: Variables to inject as local bindings (via JSON).

    Returns:
        {
            "stdout":   str,
            "stderr":   str,
            "exit_code": int,
            "timed_out": bool,
            "blocked":   list[str],  # blocked imports found
            "error":    str | None,
        }
    """
    timeout = timeout or MAX_EXEC_SECONDS

    if not code or not code.strip():
        return {
            "stdout": "", "stderr": "", "exit_code": 0,
            "timed_out": False, "blocked": [], "error": "Empty code.",
        }

    # Static import check
    blocked = _check_blocked_imports(code)
    if blocked:
        return {
            "stdout": "", "stderr": "",
            "exit_code": 1, "timed_out": False,
            "blocked": blocked,
            "error": f"Blocked imports: {', '.join(blocked)}. Network access denied.",
        }

    # Build wrapper script
    inject_code = ""
    if inject_vars:
        import json
        safe_vars = json.dumps(inject_vars)
        inject_code = f"""
import json as _json
_injected = _json.loads({safe_vars!r})
locals().update(_injected)
"""

    wrapper = textwrap.dedent(f"""
import sys, os, resource

# Memory cap (where supported — Linux only)
try:
    limit = {MAX_MEMORY_MB} * 1024 * 1024
    resource.setrlimit(resource.RLIMIT_AS, (limit, limit))
except Exception:
    pass  # Not supported on macOS/Windows

# Block writes outside /tmp
_real_open = open
def _safe_open(file, mode='r', *args, **kwargs):
    file = str(file)
    if any(m in mode for m in ('w','a','x')):
        if not file.startswith('/tmp') and not file.startswith(os.sep + 'tmp'):
            raise PermissionError(f"Write access denied outside /tmp: {{file}}")
    return _real_open(file, mode, *args, **kwargs)
import builtins
builtins.open = _safe_open

{inject_code}

# ── USER CODE ──────────────────────────────────────────────────────────────────
{code}
""").strip()

    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".py", delete=False, prefix="agent_run_"
    ) as tmp:
        tmp.write(wrapper)
        tmp_path = tmp.name

    try:
        result = subprocess.run(
            [sys.executable, tmp_path],
            capture_output=True,
            text=True,
            timeout=timeout,
            env={
                **os.environ,
                "PYTHONDONTWRITEBYTECODE": "1",
                "PYTHONPATH": "",            # no project imports
            },
        )
        stdout = result.stdout[:MAX_OUTPUT_BYTES]
        stderr = result.stderr[:MAX_OUTPUT_BYTES]
        return {
            "stdout":    stdout,
            "stderr":    stderr,
            "exit_code": result.returncode,
            "timed_out": False,
            "blocked":   [],
            "error":     None if result.returncode == 0 else (stderr or "Non-zero exit"),
        }
    except subprocess.TimeoutExpired:
        return {
            "stdout": "", "stderr": "",
            "exit_code": -1, "timed_out": True,
            "blocked": [],
            "error": f"Execution timed out after {timeout}s.",
        }
    except Exception as e:
        return {
            "stdout": "", "stderr": "",
            "exit_code": -1, "timed_out": False,
            "blocked": [],
            "error": f"Runner error: {e}",
        }
    finally:
        try:
            os.unlink(tmp_path)
        except Exception:
            pass
