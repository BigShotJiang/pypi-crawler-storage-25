"""
agents/memory_consolidator.py — Memory consolidation agent (mem0-style).

Responsibility: For each AtomicFact extracted by fact_extractor.py, decide
whether to ADD, UPDATE, DELETE, or NOOP based on existing graph contents.

Source: research_extended_topics.md §7.1 (mem0 Update Phase)
Operations:
  ADD    — fact is genuinely new, create a node
  UPDATE — fact extends or clarifies an existing node (merge)
  DELETE — fact contradicts and supersedes an existing node (invalidate old)
  NOOP   — fact is already captured, no change needed

Design: LLM evaluates each candidate fact against top-K similar existing nodes
        retrieved by semantic search. The LLM has the final say — not rules.
"""
from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from enum import Enum
from typing import Optional

from .fact_extractor import AtomicFact

logger = logging.getLogger(__name__)


class ConsolidationOp(str, Enum):
    ADD    = "ADD"
    UPDATE = "UPDATE"
    DELETE = "DELETE"
    NOOP   = "NOOP"


@dataclass
class ConsolidationDecision:
    operation: ConsolidationOp
    fact: AtomicFact
    target_id: Optional[str] = None     # existing node ID (for UPDATE/DELETE)
    merged_content: Optional[str] = None  # updated content (for UPDATE)
    reasoning: str = ""


CONSOLIDATION_SYSTEM = """You are a memory management system for a software project knowledge graph.
You decide whether new facts should be added, used to update existing facts, used to delete/supersede
existing facts, or ignored (no-op) because they are already captured.

Operations:
- ADD: The new fact is genuinely new information not in any existing memory
- UPDATE: The new fact extends, refines, or clarifies an existing memory (provide merged_content)
- DELETE: The new fact directly contradicts an existing memory and supersedes it
- NOOP: The new fact is already captured by an existing memory — no change needed

Be conservative with DELETE. Only delete when directly contradicted.
Prefer UPDATE over ADD when there is significant overlap.
"""

CONSOLIDATION_USER_TEMPLATE = """Existing memories (semantically similar to new fact):
{existing_memories}

New fact:
  content: {content}
  type: {fact_type}
  confidence: {confidence}

Decide the operation. Return ONLY valid JSON:
{{
  "operation": "ADD|UPDATE|DELETE|NOOP",
  "target_id": "<existing_node_id or null>",
  "merged_content": "<updated content string if operation=UPDATE, else null>",
  "reasoning": "<brief explanation>"
}}
"""


async def consolidate_fact(
    fact: AtomicFact,
    graph,
    llm_client=None,
    similarity_top_k: int = 5,
) -> ConsolidationDecision:
    """
    Evaluate a single AtomicFact against the existing graph and decide
    what to do: ADD, UPDATE, DELETE, or NOOP.

    Args:
        fact:              The extracted atomic fact to evaluate.
        graph:             Graph backend instance (must support semantic_search).
        llm_client:        Async LLM client. Falls back to ADD if unavailable.
        similarity_top_k:  Number of similar existing nodes to retrieve for comparison.

    Returns:
        ConsolidationDecision with the operation and relevant fields.
    """
    # Retrieve similar existing nodes
    existing: list[dict] = []
    if hasattr(graph, "semantic_search"):
        try:
            existing = graph.semantic_search(
                query=fact.content,
                node_types=None,
                limit=similarity_top_k,
                confidence_min=0.0,
            )
        except Exception as e:
            logger.warning("consolidator: semantic_search failed: %s", e)

    # If no existing nodes or no LLM, just ADD
    if not existing or llm_client is None:
        return ConsolidationDecision(
            operation=ConsolidationOp.ADD,
            fact=fact,
            reasoning="No similar existing nodes found or no LLM available.",
        )

    # Format existing memories for the prompt
    existing_formatted = "\n".join(
        f"  [{i+1}] id={item.get('id','?')} type={item.get('node_type','?')} "
        f"score={item.get('relevance_score', item.get('score','?')):.2f}: "
        f"{item.get('description', item.get('content',''))[:150]}"
        for i, item in enumerate(existing)
    ) or "  (none)"

    user_prompt = CONSOLIDATION_USER_TEMPLATE.format(
        existing_memories=existing_formatted,
        content=fact.content,
        fact_type=fact.type,
        confidence=fact.confidence,
    )

    try:
        raw_response = await llm_client.generate(
            system=CONSOLIDATION_SYSTEM,
            user=user_prompt,
        )
    except Exception as e:
        logger.error("consolidator: LLM call failed: %s", e)
        return ConsolidationDecision(
            operation=ConsolidationOp.ADD,
            fact=fact,
            reasoning=f"LLM call failed ({e}), defaulting to ADD.",
        )

    # Parse JSON response
    cleaned = raw_response.strip()
    cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned)
    cleaned = re.sub(r"\s*```$", "", cleaned)

    try:
        result = json.loads(cleaned)
    except json.JSONDecodeError as e:
        logger.error("consolidator: JSON parse failed: %s | raw: %s", e, raw_response[:200])
        return ConsolidationDecision(
            operation=ConsolidationOp.ADD,
            fact=fact,
            reasoning="JSON parse failed, defaulting to ADD.",
        )

    try:
        op = ConsolidationOp(result.get("operation", "ADD").upper())
    except ValueError:
        op = ConsolidationOp.ADD

    return ConsolidationDecision(
        operation=op,
        fact=fact,
        target_id=result.get("target_id"),
        merged_content=result.get("merged_content"),
        reasoning=result.get("reasoning", ""),
    )


async def apply_consolidation(
    decision: ConsolidationDecision,
    graph,
    session_id: str,
    project_id: Optional[str] = None,
) -> dict:
    """
    Apply a consolidation decision to the graph.

    Returns a summary dict with operation, node_id, and status.
    """
    from ..schema import Decision, Constraint, Preference, DecisionStatus

    fact = decision.fact
    now = datetime.now(timezone.utc)

    if decision.operation == ConsolidationOp.NOOP:
        logger.info("consolidator: NOOP for fact: %s", fact.content[:60])
        return {"operation": "NOOP", "node_id": None, "status": "skipped"}

    if decision.operation == ConsolidationOp.DELETE and decision.target_id:
        # Invalidate the old node (bi-temporal: set invalid_at, don't delete)
        if hasattr(graph, "invalidate_node"):
            graph.invalidate_node(decision.target_id, invalid_at=now)
            logger.info("consolidator: DELETE (invalidated) node %s", decision.target_id)
            return {"operation": "DELETE", "node_id": decision.target_id, "status": "invalidated"}
        else:
            logger.warning("consolidator: graph backend does not support invalidate_node")
            return {"operation": "DELETE", "node_id": decision.target_id, "status": "unsupported"}

    if decision.operation == ConsolidationOp.UPDATE and decision.target_id:
        # Update the existing node content
        if hasattr(graph, "update_node_content"):
            updated_content = decision.merged_content or fact.content
            graph.update_node_content(
                decision.target_id,
                content=updated_content,
                last_confirmed=now,
            )
            logger.info("consolidator: UPDATE node %s", decision.target_id)
            return {"operation": "UPDATE", "node_id": decision.target_id, "status": "updated"}
        else:
            logger.warning("consolidator: graph backend does not support update_node_content, falling back to ADD")
            # Fall through to ADD

    # ADD — create new node based on fact type
    fact_type = fact.type.lower()
    node_id = None

    try:
        if fact_type == "decision":
            node = Decision(
                made_in=session_id,
                description=fact.content,
                rationale=fact.rationale,
                confidence=fact.confidence,
                episode_id=session_id,
                valid_at=now,
                project_id=project_id,
                decay_rate="Decision",
            )
        elif fact_type == "constraint":
            node = Constraint(
                surfaced_in=session_id,
                description=fact.content,
                episode_id=session_id,
                valid_at=now,
                project_id=project_id,
                decay_rate="Constraint",
            )
        elif fact_type in ("preference",):
            from ..schema import PreferenceType
            node = Preference(
                inferred_in=session_id,
                description=fact.content,
                type=PreferenceType.technical,
                evidence=fact.rationale,
                confidence=fact.confidence,
                episode_id=session_id,
                valid_at=now,
                project_id=project_id,
                decay_rate="Preference",
            )
        else:
            # observation / attempt → Decision node with low confidence
            node = Decision(
                made_in=session_id,
                description=fact.content,
                rationale=f"[{fact_type}] {fact.rationale}",
                confidence=min(fact.confidence, 0.6),
                episode_id=session_id,
                valid_at=now,
                project_id=project_id,
                decay_rate="Decision",
            )

        if hasattr(graph, "save_node"):
            graph.save_node(node)
            node_id = node.id
            logger.info("consolidator: ADD node %s (%s)", node_id, fact_type)
        else:
            logger.warning("consolidator: graph backend does not support save_node")
            return {"operation": "ADD", "node_id": None, "status": "unsupported"}

    except Exception as e:
        logger.error("consolidator: failed to create node: %s", e)
        return {"operation": "ADD", "node_id": None, "status": f"error: {e}"}

    return {"operation": "ADD", "node_id": node_id, "status": "created"}
