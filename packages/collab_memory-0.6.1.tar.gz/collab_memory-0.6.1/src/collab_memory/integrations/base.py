"""Base integration adapter — all integrations follow this contract."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timezone


@dataclass
class IntegrationStatus:
    """Status of an integration connection."""
    connected: bool = False
    last_sync: datetime | None = None
    error: str | None = None
    metadata: dict = field(default_factory=dict)


@dataclass
class SyncResult:
    """Result of an inbound or outbound sync."""
    nodes_created: list[dict] = field(default_factory=list)
    nodes_updated: list[dict] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return len(self.errors) == 0


class Integration(ABC):
    """Every integration implements these 4 methods.

    Pattern:
        connect()       — store credentials, register webhooks
        disconnect()    — revoke token, delete webhook
        sync_inbound()  — external event → OHACO nodes
        sync_outbound() — OHACO node change → external action
    """

    name: str = "unknown"
    icon: str = ""  # emoji or icon key

    @abstractmethod
    async def connect(self, tenant_id: str, credentials: dict) -> IntegrationStatus:
        """Store credentials, register webhooks. Returns connection status."""

    @abstractmethod
    async def disconnect(self, tenant_id: str) -> bool:
        """Revoke token, delete webhook. Returns True on success."""

    @abstractmethod
    async def sync_inbound(self, tenant_id: str, payload: dict) -> SyncResult:
        """External event → OHACO nodes. Returns nodes to create/update."""

    @abstractmethod
    async def sync_outbound(self, tenant_id: str, node: dict) -> bool:
        """OHACO node change → external action. Returns True on success."""

    async def status(self, tenant_id: str) -> IntegrationStatus:
        """Check current connection status. Override for custom health checks."""
        return IntegrationStatus(connected=False)
