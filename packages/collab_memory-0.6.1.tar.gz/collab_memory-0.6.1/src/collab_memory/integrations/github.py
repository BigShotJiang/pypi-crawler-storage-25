"""GitHub integration — sync PRs/issues as Task nodes, push webhook."""

from __future__ import annotations

import json
import logging
import os
import urllib.error
import urllib.request
from datetime import datetime, timezone

from .base import Integration, IntegrationStatus, SyncResult

logger = logging.getLogger(__name__)


class GitHubIntegration(Integration):
    name = "github"
    icon = "github"

    async def connect(self, tenant_id: str, credentials: dict) -> IntegrationStatus:
        """Store GitHub token. Optionally register a push webhook."""
        token = credentials.get("token", "")
        if not token:
            return IntegrationStatus(connected=False, error="No token provided")

        # Verify token by fetching user info
        try:
            req = urllib.request.Request(
                "https://api.github.com/user",
                headers={
                    "Authorization": f"token {token}",
                    "Accept": "application/vnd.github.v3+json",
                    "User-Agent": "OHACO-SemanticDreams",
                },
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                user = json.loads(resp.read())
                return IntegrationStatus(
                    connected=True,
                    last_sync=datetime.now(timezone.utc),
                    metadata={"login": user.get("login"), "tenant_id": tenant_id},
                )
        except (urllib.error.HTTPError, Exception) as e:
            return IntegrationStatus(connected=False, error=str(e))

    async def disconnect(self, tenant_id: str) -> bool:
        """Revoke stored token. Webhook cleanup would happen here."""
        # In a full implementation: delete stored token from vault, remove webhook
        return True

    async def sync_inbound(self, tenant_id: str, payload: dict) -> SyncResult:
        """GitHub webhook event → OHACO Task/ExchangeRecord nodes.

        Handles:
            - pull_request (opened/closed/merged) → Task node
            - push → ExchangeRecord node (agent activity)
            - issues (opened/closed) → Task node
        """
        result = SyncResult()
        action = payload.get("action", "")

        # Pull request events
        if "pull_request" in payload:
            pr = payload["pull_request"]
            node = _pr_to_node(pr, action, tenant_id)
            if node:
                result.nodes_created.append(node)

        # Issue events
        elif "issue" in payload and "pull_request" not in payload.get("issue", {}):
            issue = payload["issue"]
            node = _issue_to_node(issue, action, tenant_id)
            if node:
                result.nodes_created.append(node)

        # Push events (agent commits)
        elif "commits" in payload:
            for commit in payload.get("commits", [])[:10]:  # Cap at 10
                node = _commit_to_node(commit, payload, tenant_id)
                if node:
                    result.nodes_created.append(node)

        return result

    async def sync_outbound(self, tenant_id: str, node: dict) -> bool:
        """OHACO Task node → GitHub issue/PR comment. Not yet implemented."""
        # Future: when a Task node is confirmed, post a comment on the linked PR/issue
        return False

    async def status(self, tenant_id: str) -> IntegrationStatus:
        """Check if GitHub token is valid."""
        token = os.environ.get("GITHUB_TOKEN", "")
        if not token:
            return IntegrationStatus(connected=False, error="No GITHUB_TOKEN set")
        return IntegrationStatus(connected=True, metadata={"source": "env"})


def _pr_to_node(pr: dict, action: str, tenant_id: str) -> dict | None:
    """Convert a GitHub PR event to an OHACO Task node."""
    if action not in ("opened", "closed", "reopened"):
        return None

    status = "open"
    if action == "closed":
        status = "merged" if pr.get("merged") else "closed"

    return {
        "type": "Task",
        "content": pr.get("title", ""),
        "label": f"PR #{pr.get('number')}: {pr.get('title', '')[:60]}",
        "status": status,
        "confidence": 0.8,
        "tenant_id": tenant_id,
        "source": "github",
        "tags": ["github", "pull-request"],
        "metadata": {
            "github_url": pr.get("html_url"),
            "github_number": pr.get("number"),
            "github_author": pr.get("user", {}).get("login"),
            "github_branch": pr.get("head", {}).get("ref"),
            "github_action": action,
        },
    }


def _issue_to_node(issue: dict, action: str, tenant_id: str) -> dict | None:
    """Convert a GitHub issue event to an OHACO Task node."""
    if action not in ("opened", "closed", "reopened"):
        return None

    return {
        "type": "Task",
        "content": issue.get("title", ""),
        "label": f"Issue #{issue.get('number')}: {issue.get('title', '')[:60]}",
        "status": "closed" if action == "closed" else "open",
        "confidence": 0.7,
        "tenant_id": tenant_id,
        "source": "github",
        "tags": ["github", "issue"],
        "metadata": {
            "github_url": issue.get("html_url"),
            "github_number": issue.get("number"),
            "github_author": issue.get("user", {}).get("login"),
            "github_action": action,
        },
    }


def _commit_to_node(commit: dict, push_payload: dict, tenant_id: str) -> dict | None:
    """Convert a GitHub push commit to an ExchangeRecord node."""
    message = commit.get("message", "").split("\n")[0][:100]
    if not message:
        return None

    author = commit.get("author", {}).get("username") or commit.get("author", {}).get("name", "unknown")
    repo = push_payload.get("repository", {}).get("full_name", "")
    ref = push_payload.get("ref", "").replace("refs/heads/", "")

    return {
        "type": "ExchangeRecord",
        "content": message,
        "label": f"{author}: {message}",
        "confidence": 0.6,
        "tenant_id": tenant_id,
        "source": "github",
        "created_by": author,
        "tags": ["github", "commit", ref],
        "metadata": {
            "github_sha": commit.get("id", "")[:12],
            "github_repo": repo,
            "github_branch": ref,
            "github_url": commit.get("url"),
        },
    }
