"""OHACO Integration Hub — unified adapter pattern for 3rd-party services."""
