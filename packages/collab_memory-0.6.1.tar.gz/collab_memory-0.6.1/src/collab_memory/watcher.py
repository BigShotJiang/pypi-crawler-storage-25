"""
collab_memory/watcher.py — SessionWatcher: background auto-ingest daemon.

Watches for new conversation exchanges and automatically runs them through
the 6-agent pipeline. This is the "always-on brain" mode.

Usage:
    # Start from CLI
    collab-memory-watch

    # Or programmatically
    from collab_memory.watcher import SessionWatcher
    watcher = SessionWatcher(api_url="http://localhost:8000", session_id="my_project")
    watcher.start()

The watcher monitors a watch file (default: ~/.collab-memory/watch.jsonl) for
new lines. Any agent or script can append to this file to queue exchanges for
processing:

    echo '{"text": "We decided to use Postgres.", "session_id": "proj_alpha"}' \
      >> ~/.collab-memory/watch.jsonl

The watcher picks it up within `poll_interval` seconds, POSTs to
/memory/pipeline/run, and appends the result to ~/.collab-memory/watch.log.

This enables:
  - AI IDE plugins to auto-queue decisions as they happen
  - Shell scripts to queue exchanges without blocking
  - The dashboard to show live pipeline activity
"""
from __future__ import annotations
import os
import json
import time
import threading
import urllib.request
import urllib.error
from pathlib import Path
from datetime import datetime, UTC


DEFAULT_WATCH_FILE = Path.home() / ".collab-memory" / "watch.jsonl"
DEFAULT_LOG_FILE   = Path.home() / ".collab-memory" / "watch.log"
DEFAULT_API_URL    = os.environ.get("COLLAB_MEMORY_URL", "http://localhost:8000")
DEFAULT_API_KEY    = os.environ.get("COLLAB_API_KEY", "")
DEFAULT_INTERVAL   = float(os.environ.get("COLLAB_WATCH_INTERVAL", "5"))  # seconds


def _now() -> str:
    return datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")


def _post(api_url: str, api_key: str, payload: dict) -> dict:
    """POST to /memory/pipeline/run and return the response dict."""
    url = api_url.rstrip("/") + "/memory/pipeline/run"
    data = json.dumps(payload).encode()
    headers = {"Content-Type": "application/json", "Accept": "application/json"}
    if api_key:
        headers["X-API-Key"] = api_key
    req = urllib.request.Request(url, data=data, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return json.loads(r.read())
    except urllib.error.HTTPError as e:
        try:
            return {"error": True, "status": e.code, "detail": json.loads(e.read()).get("detail", str(e))}
        except Exception:
            return {"error": True, "status": e.code, "detail": str(e)}
    except Exception as e:
        return {"error": True, "detail": str(e)}


class SessionWatcher:
    """
    Background daemon that watches a JSONL file and auto-ingests new lines.

    Each line in the watch file must be valid JSON with at minimum:
        {"text": "...", "session_id": "..."}

    Optional fields:
        {"text": "...", "session_id": "...", "label": "my label", "skip_llm": false}
    """

    def __init__(
        self,
        watch_file: Path | str = DEFAULT_WATCH_FILE,
        log_file: Path | str = DEFAULT_LOG_FILE,
        api_url: str = DEFAULT_API_URL,
        api_key: str = DEFAULT_API_KEY,
        poll_interval: float = DEFAULT_INTERVAL,
        session_id: str = "watcher",
    ):
        self.watch_file = Path(watch_file)
        self.log_file = Path(log_file)
        self.api_url = api_url
        self.api_key = api_key
        self.poll_interval = poll_interval
        self.session_id = session_id
        self._stop_event = threading.Event()
        self._thread: threading.Thread | None = None
        self._processed: set[int] = set()  # line positions already processed
        self._last_activity: float = 0.0   # epoch seconds of last processed line
        self._consolidation_triggered: bool = False  # debounce per idle window
        # After this many seconds of inactivity, auto-trigger Episode consolidation
        self._idle_consolidate_after: float = float(
            os.environ.get("WATCHER_IDLE_CONSOLIDATE_S", 600)  # default: 10 minutes
        )

        # Ensure dirs exist
        self.watch_file.parent.mkdir(parents=True, exist_ok=True)
        self.log_file.parent.mkdir(parents=True, exist_ok=True)
        if not self.watch_file.exists():
            self.watch_file.touch()

    def _log(self, entry: dict) -> None:
        line = json.dumps({"ts": _now(), **entry})
        with open(self.log_file, "a") as f:
            f.write(line + "\n")
        # Also print to stdout for visibility
        summary = entry.get("summary", entry.get("detail", ""))
        status = "✓" if not entry.get("error") else "✗"
        print(f"[watcher] {status} {summary}")

    def _process_line(self, line: str, line_no: int) -> None:
        """Parse one JSONL line and run it through the pipeline."""
        line = line.strip()
        if not line:
            return
        try:
            item = json.loads(line)
        except json.JSONDecodeError as e:
            self._log({"error": True, "line": line_no, "detail": f"JSON parse error: {e}"})
            return

        text = item.get("text", "").strip()
        if not text:
            return

        payload = {
            "text": text,
            "session_id": item.get("session_id", self.session_id),
            "label": item.get("label", ""),
            "skip_llm": item.get("skip_llm", False),
        }
        result = _post(self.api_url, self.api_key, payload)
        self._log({
            "line": line_no,
            "session_id": payload["session_id"],
            "summary": result.get("summary", ""),
            "elapsed": result.get("elapsed_seconds"),
            "error": result.get("error", False),
            "detail": result.get("detail", ""),
        })
        # Mark activity so idle timer resets
        import time as _time
        self._last_activity = _time.time()
        self._consolidation_triggered = False

    def _trigger_consolidation(self, session_id: str) -> None:
        """POST to /memory/session/{id}/consolidate to create an Episode node."""
        import time as _time
        url = f"{self.api_url.rstrip('/')}/memory/session/{session_id}/consolidate"
        headers: dict = {"Content-Type": "application/json"}
        if self.api_key:
            headers["X-API-Key"] = self.api_key
        req = urllib.request.Request(url, data=b"{}", headers=headers, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=60) as r:
                result = json.loads(r.read().decode())
                episode_id = result.get("episode_id", "?")
                self._log({
                    "type": "auto_consolidation",
                    "session_id": session_id,
                    "episode_id": episode_id,
                    "summary": f"Episode created [{episode_id}] after {self._idle_consolidate_after/60:.0f}m idle",
                })
                self._consolidation_triggered = True
        except Exception as e:
            self._log({"error": True, "type": "auto_consolidation", "detail": str(e)})

    def _watch_loop(self) -> None:
        import time as _time
        print(f"[watcher] Started — watching {self.watch_file}")
        print(f"[watcher] API: {self.api_url} | interval: {self.poll_interval}s | idle-consolidate: {self._idle_consolidate_after/60:.0f}m")
        self._last_activity = _time.time()  # start timer from launch
        while not self._stop_event.is_set():
            try:
                lines = self.watch_file.read_text().splitlines()
                new_lines_found = False
                for i, line in enumerate(lines):
                    if i not in self._processed:
                        self._process_line(line, i)
                        self._processed.add(i)
                        new_lines_found = True

                # Auto-consolidation: if idle > threshold and not already triggered
                if (
                    not new_lines_found
                    and not self._consolidation_triggered
                    and self._last_activity > 0
                    and (_time.time() - self._last_activity) >= self._idle_consolidate_after
                ):
                    print(f"[watcher] Idle {self._idle_consolidate_after/60:.0f}m — triggering Episode consolidation")
                    self._trigger_consolidation(self.session_id)

            except Exception as e:
                print(f"[watcher] Error reading watch file: {e}")
            self._stop_event.wait(self.poll_interval)
        print("[watcher] Stopped.")

    def start(self, daemon: bool = True) -> "SessionWatcher":
        """Start the watcher in a background thread."""
        if self._thread and self._thread.is_alive():
            return self
        self._stop_event.clear()
        self._thread = threading.Thread(target=self._watch_loop, daemon=daemon, name="collab-watcher")
        self._thread.start()
        return self

    def stop(self) -> None:
        """Stop the watcher thread."""
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=10)

    def queue(self, text: str, session_id: str | None = None, **kwargs) -> None:
        """
        Append an exchange to the watch file for processing.
        This is the programmatic API — call from any agent or script.

        Example:
            watcher.queue("We decided to use Postgres.", session_id="proj_alpha")
        """
        entry = {"text": text, "session_id": session_id or self.session_id, **kwargs}
        with open(self.watch_file, "a") as f:
            f.write(json.dumps(entry) + "\n")


def run_watcher_cli() -> None:
    """Entry point for `collab-memory-watch` CLI command."""
    import argparse
    parser = argparse.ArgumentParser(description="collab-memory SessionWatcher — auto-ingest daemon")
    parser.add_argument("--url", default=DEFAULT_API_URL, help="collab-memory API URL")
    parser.add_argument("--key", default=DEFAULT_API_KEY, help="X-API-Key value")
    parser.add_argument("--interval", type=float, default=DEFAULT_INTERVAL, help="Poll interval seconds")
    parser.add_argument("--session", default="watcher", help="Default session_id for queued items")
    parser.add_argument("--watch-file", default=str(DEFAULT_WATCH_FILE), help="Path to JSONL watch file")
    args = parser.parse_args()

    watcher = SessionWatcher(
        watch_file=args.watch_file,
        api_url=args.url,
        api_key=args.key,
        poll_interval=args.interval,
        session_id=args.session,
    )
    watcher.start(daemon=False)  # blocking in CLI mode


if __name__ == "__main__":
    run_watcher_cli()
