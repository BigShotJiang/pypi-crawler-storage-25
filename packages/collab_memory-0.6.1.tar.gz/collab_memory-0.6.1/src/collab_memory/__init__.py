"""
collab-memory — Semantic working memory for human+agent collaboration.

Part of the Cognitive Dreams suite by OHACO Labs.
https://github.com/ohaco-labs/collab-memory
"""

from .memory import CollabMemory
from .encoder import encode_session, encode_exchange
from .graph.local import LocalGraphBackend
from .graph.base import GraphBackend
from .graph import get_backend
from ._version import __version__

__all__ = [
    "__version__",
    "CollabMemory",
    "encode_session",
    "encode_exchange",
    "LocalGraphBackend",
    "GraphBackend",
    "get_backend",
]

__author__ = "OHACO Labs (Cognitive Dreams)"
