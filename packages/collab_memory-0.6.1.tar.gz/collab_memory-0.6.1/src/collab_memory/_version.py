"""Single source of truth for the collab-memory release version.

``pyproject.toml`` loads this via ``[tool.setuptools.dynamic]`` so FastAPI, MCP,
and ``import collab_memory`` all agree. Bump here, then rebuild / publish.
"""

__version__ = "0.6.1"
