"""
collab_memory/cli.py — Unified `collab` terminal interface using Typer.

Install:  pip install collab-memory
          pipx install collab-memory   (recommended for isolated binary)
          uvx collab-memory            (run without install)

Commands:
  collab enroll     — Auto-configure Claude/Cursor/Windsurf MCP in one command
  collab init       — Interactive setup wizard (set env vars, test connections)
  collab start      — Start API server + watcher (background)
  collab status     — Health check: Neo4j connection, pipeline, node count
  collab search     — Semantic search from terminal (test retrieval quality)
  collab ingest     — Manually ingest a session file
  collab decisions  — List recent decisions for a project
  collab mcp        — Start MCP server only (no API server)
  collab baseline   — Run LongMemEval-style baseline test against live graph

Source: research_infrastructure_and_process.md §Section 6 (CLI Terminal Design)
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time
import urllib.request
import urllib.error
from typing import Optional

try:
    import typer
    from rich.console import Console
    from rich.table import Table
    from rich import print as rprint
except ImportError:
    # Minimal fallback so the module can be imported without typer/rich installed
    typer = None  # type: ignore[assignment]

# ── CLI App ───────────────────────────────────────────────────────────────────

if typer is not None:
    app = typer.Typer(
        name="collab",
        help="Co-Lab Memory — self-hostable AI agent memory layer",
        add_completion=False,
        rich_markup_mode="rich",
    )
    console = Console()
else:
    app = None
    console = None


def _api_url() -> str:
    return os.environ.get("COLLAB_API_URL", "http://localhost:8765")


def _api_key() -> str:
    return os.environ.get("COLLAB_API_KEY", "")


def _project_id() -> str:
    return os.environ.get("COLLAB_PROJECT_ID", "default")


def _get(path: str) -> dict:
    """Make an authenticated GET to the local API."""
    url = f"{_api_url()}{path}"
    req = urllib.request.Request(url, headers={"X-API-Key": _api_key()})
    with urllib.request.urlopen(req, timeout=10) as r:
        return json.loads(r.read().decode())


def _post(path: str, body: dict) -> dict:
    """Make an authenticated POST to the local API."""
    url = f"{_api_url()}{path}"
    data = json.dumps(body).encode()
    req = urllib.request.Request(
        url, data=data,
        headers={"X-API-Key": _api_key(), "Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.loads(r.read().decode())


# ── Commands ──────────────────────────────────────────────────────────────────

if typer is not None:
    @app.command()
    def status():
        """Health check: Neo4j connection, pipeline status, node count."""
        console.print("[bold cyan]Co-Lab Memory — Status[/bold cyan]\n")
        try:
            data = _get("/health")
            table = Table(show_header=False, box=None)
            table.add_column("Key", style="bold")
            table.add_column("Value")
            table.add_row("API", f"[green]✓ {_api_url()}[/green]")
            for k, v in data.items():
                table.add_row(k, str(v))
            console.print(table)
        except Exception as e:
            console.print(f"[red]✗ API unreachable: {e}[/red]")
            console.print(f"  Run [bold]collab start[/bold] first, or check COLLAB_API_URL={_api_url()}")
            raise typer.Exit(1)


    @app.command()
    def start(
        port: int = typer.Option(8765, help="Port for the API server"),
        no_watcher: bool = typer.Option(False, "--no-watcher", help="Skip the file watcher"),
    ):
        """Start the API server (and optionally the file watcher)."""
        console.print(f"[bold cyan]Starting Co-Lab Memory on port {port}...[/bold cyan]")
        env = {**os.environ, "PORT": str(port)}
        try:
            proc = subprocess.Popen(
                [sys.executable, "-m", "collab_memory.scripts.serve"],
                env=env,
            )
            console.print(f"[green]✓ API server started (PID {proc.pid})[/green]")
            console.print(f"  Dashboard: http://localhost:{port}/dashboard")
            console.print(f"  API docs:  http://localhost:{port}/docs")
            if not no_watcher:
                console.print("\n[bold]Starting watcher...[/bold]")
                subprocess.Popen(
                    [sys.executable, "-m", "collab_memory.watcher"],
                    env=env,
                )
            console.print("\nPress [bold]Ctrl-C[/bold] to stop.")
            proc.wait()
        except KeyboardInterrupt:
            console.print("\n[yellow]Shutting down.[/yellow]")


    @app.command()
    def search(
        query: str = typer.Argument(..., help="Search query"),
        project: Optional[str] = typer.Option(None, "--project", "-p", help="Project ID"),
        limit: int = typer.Option(5, "--limit", "-n"),
        types: Optional[str] = typer.Option(None, "--types", "-t", help="Comma-separated: Decision,Constraint,Preference"),
    ):
        """Semantic search against the memory graph."""
        import urllib.parse
        pid = project or _project_id()
        path = f"/memory/search?q={urllib.parse.quote(query)}&project_id={pid}&limit={limit}"
        if types:
            path += f"&node_types={types}"

        try:
            data = _get(path)
        except Exception as e:
            console.print(f"[red]Search failed: {e}[/red]")
            raise typer.Exit(1)

        results = data.get("results", [])
        if not results:
            owa = data.get("owa_notice", "No results found.")
            console.print(f"[yellow]{owa}[/yellow]")
            return

        table = Table(title=f"Search: '{query}' ({len(results)} results)", box=None)
        table.add_column("Type", style="cyan", width=12)
        table.add_column("Description", width=60)
        table.add_column("Score", justify="right", width=8)
        table.add_column("TV", justify="right", width=6)

        for r in results:
            table.add_row(
                r.get("node_type", r.get("primitive_type", "?")),
                r.get("description", "")[:60],
                str(r.get("relevance_score", "")),
                str(round(r.get("temporal_validity", 0), 2)),
            )
        console.print(table)

        scoring = data.get("scoring", {})
        if scoring:
            console.print(f"\n[dim]Scoring: semantic={scoring.get('semantic_weight')} × {scoring.get('model', 'HALO')}[/dim]")


    @app.command()
    def decisions(
        project: Optional[str] = typer.Option(None, "--project", "-p"),
        limit: int = typer.Option(10, "--limit", "-n"),
    ):
        """List recent decisions for a project."""
        pid = project or _project_id()
        try:
            data = _get(f"/memory/context?project_id={pid}")
        except Exception as e:
            console.print(f"[red]Failed: {e}[/red]")
            raise typer.Exit(1)

        decs = data.get("decisions", [])[:limit]
        if not decs:
            console.print("[yellow]No decisions found.[/yellow]")
            return

        table = Table(title=f"Decisions — {pid}", box=None)
        table.add_column("#", width=3)
        table.add_column("Description", width=70)
        table.add_column("Module", width=15)
        for i, d in enumerate(decs, 1):
            table.add_row(str(i), d.get("description", "")[:70], d.get("module", ""))
        console.print(table)


    @app.command()
    def mcp(port: int = typer.Option(3100, help="MCP server port")):
        """Start the MCP server (stdio or SSE transport for IDE integration)."""
        console.print(f"[bold cyan]Starting Co-Lab MCP server...[/bold cyan]")
        env = {**os.environ, "MCP_PORT": str(port)}
        subprocess.run(
            [sys.executable, "-m", "collab_memory.mcp_server"],
            env=env,
        )


    @app.command()
    def ingest(
        file: str = typer.Argument(..., help="Path to session file (.jsonl or .txt)"),
        project: Optional[str] = typer.Option(None, "--project", "-p"),
        session: Optional[str] = typer.Option(None, "--session", "-s"),
    ):
        """Ingest a session file into the memory graph."""
        import pathlib
        pid = project or _project_id()
        path = pathlib.Path(file)
        if not path.exists():
            console.print(f"[red]File not found: {file}[/red]")
            raise typer.Exit(1)

        content = path.read_text()
        session_id = session or f"cli_{int(time.time())}"

        try:
            resp = _post("/memory/ingest", {
                "text": content,
                "session_id": session_id,
                "project_id": pid,
            })
            console.print(f"[green]✓ Ingested: {resp}[/green]")
        except Exception as e:
            console.print(f"[red]Ingest failed: {e}[/red]")
            raise typer.Exit(1)


    @app.command()
    def baseline(
        project: Optional[str] = typer.Option(None, "--project", "-p"),
        save: bool = typer.Option(True, "--save/--no-save", help="Save results to experiment_log.md"),
    ):
        """
        Run LongMemEval-style recall test against the live graph.

        Tests 8 recall queries and scores them. Use BEFORE any embedding
        upgrade to establish a baseline. Run again AFTER to measure improvement.
        """
        import urllib.parse
        pid = project or _project_id()
        console.print(f"[bold cyan]Baseline Recall Test — project: {pid}[/bold cyan]\n")

        # Test queries with expected keywords that should be in top-3 results
        TEST_QUERIES = [
            ("embedding model choice", ["gemini", "embedding", "768", "mteb"]),
            ("HNSW index configuration", ["hnsw", "vector", "index", "cos"]),
            ("cost per month prototype", ["render", "free", "neo4j", "cost"]),
            ("GDPR right to erasure", ["gdpr", "delete", "erase", "pii"]),
            ("why did we choose neo4j", ["neo4j", "graph", "decision"]),
            ("temporal edge pattern", ["valid_at", "invalid_at", "bitemporal", "graphiti"]),
            ("security prompt injection", ["llm guard", "vigil", "injection", "owasp"]),
            ("AI dev process difference", ["crisp", "probabilistic", "drift", "baseline"]),
        ]

        hits = 0
        total = len(TEST_QUERIES)
        results_log = []

        table = Table(title="Recall Test Results", box=None)
        table.add_column("Query", width=35)
        table.add_column("Top Result", width=45)
        table.add_column("Hit?", width=5)
        table.add_column("Score", width=7)

        for query, expected_keywords in TEST_QUERIES:
            try:
                path = f"/memory/search?q={urllib.parse.quote(query)}&project_id={pid}&limit=3"
                data = _get(path)
                res = data.get("results", [])
                top_desc = res[0].get("description", "") if res else ""
                top_score = res[0].get("relevance_score", 0.0) if res else 0.0

                # Hit = at least 1 expected keyword appears in top result description
                hit = any(kw.lower() in top_desc.lower() for kw in expected_keywords) if top_desc else False
                if hit:
                    hits += 1

                table.add_row(
                    query[:35],
                    top_desc[:45],
                    "[green]✓[/green]" if hit else "[red]✗[/red]",
                    str(top_score),
                )
                results_log.append({
                    "query": query,
                    "hit": hit,
                    "top_result": top_desc[:100],
                    "score": top_score,
                })
            except Exception as e:
                table.add_row(query[:35], f"ERROR: {e}", "[red]✗[/red]", "0")
                results_log.append({"query": query, "hit": False, "error": str(e)})

        console.print(table)
        recall_pct = round(hits / total * 100)
        console.print(f"\n[bold]Recall@3: {hits}/{total} = {recall_pct}%[/bold]")
        console.print(f"Precision note: hit = ≥1 expected keyword in top-3 result description\n")

        if recall_pct >= 75:
            console.print("[green]✓ Above threshold (75%). Embedding upgrade still worthwhile.[/green]")
        elif recall_pct >= 50:
            console.print("[yellow]⚠ Moderate recall. Embedding + HNSW upgrade should improve significantly.[/yellow]")
        else:
            console.print("[red]✗ Low recall. Embedding upgrade is critical.[/red]")

        if save:
            _save_baseline(pid, recall_pct, hits, total, results_log)


    def _save_baseline(pid: str, recall_pct: int, hits: int, total: int, results: list):
        """Append baseline result to experiment_log.md."""
        import datetime
        log_path = os.path.join(os.path.dirname(__file__), "..", "..", "..", "experiment_log.md")
        log_path = os.path.normpath(log_path)

        entry = f"""
## Baseline Run — {datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}

- **Project:** {pid}
- **Recall@3:** {hits}/{total} = {recall_pct}%
- **Method:** keyword in top-3 description (pre-HNSW baseline)
- **Hypothesis:** After HNSW + gemini-embedding-001 upgrade, Recall@3 ≥ {min(recall_pct + 20, 100)}%

| Query | Hit | Top Result |
|---|---|---|
""" + "\n".join(f"| {r['query'][:40]} | {'✓' if r['hit'] else '✗'} | {r.get('top_result','err')[:60]} |" for r in results) + "\n"

        try:
            with open(log_path, "a") as f:
                f.write(entry)
            console.print(f"[dim]Saved to experiment_log.md[/dim]")
        except Exception as e:
            console.print(f"[dim]Could not save log: {e}[/dim]")


if typer is not None:
    @app.command()
    def config(
        provider: str = typer.Option(None, "--provider", "-p",
            help="LLM provider: anthropic | ollama | openai | gemini"),
        model: str = typer.Option(None, "--model", "-m",
            help="Anthropic model (e.g. claude-haiku-4-5, claude-sonnet-4-6)"),
        ollama_model: str = typer.Option(None, "--ollama-model",
            help="Ollama model name (e.g. qwen2.5:32b)"),
        ollama_url: str = typer.Option(None, "--ollama-url",
            help="Ollama base URL (default: http://localhost:11434)"),
    ):
        """
        Get or update the active LLM provider — takes effect immediately, no restart needed.

        Examples:
          collab config                                   # show current config
          collab config --provider ollama                 # switch to local Qwen
          collab config --provider anthropic --model claude-sonnet-4-6
          collab config --ollama-model qwen2.5:14b        # change Ollama model
        """
        console.print("[bold cyan]Co-Lab Memory — LLM Config[/bold cyan]\n")

        if provider is None and model is None and ollama_model is None and ollama_url is None:
            # GET: show current config
            try:
                data = _get("/ops/config")
                table = Table(show_header=False, box=None)
                table.add_column("Key", style="bold")
                table.add_column("Value")
                table.add_row("provider",        f"[green]{data.get('llm_provider', '?')}[/green]")
                table.add_row("anthropic_model", data.get("anthropic_model", "—"))
                table.add_row("anthropic_key",   "✓ set" if data.get("anthropic_key_set") else "[dim]not set[/dim]")
                table.add_row("ollama_model",    data.get("ollama_model", "—"))
                table.add_row("ollama_url",      data.get("ollama_base_url", "—"))
                table.add_row("openai_key",      "✓ set" if data.get("openai_key_set") else "[dim]not set[/dim]")
                table.add_row("gemini_key",      "✓ set" if data.get("gemini_key_set") else "[dim]not set[/dim]")
                console.print(table)
            except Exception as e:
                console.print(f"[red]✗ Could not reach API: {e}[/red]")
                raise typer.Exit(1)
            return

        # POST: apply changes
        payload = {}
        if provider:      payload["llm_provider"]  = provider
        if model:         payload["anthropic_model"] = model
        if ollama_model:  payload["ollama_model"]    = ollama_model
        if ollama_url:    payload["ollama_base_url"] = ollama_url

        try:
            result = _post("/ops/config", payload)
            applied = result.get("applied", {})
            console.print(f"[green]✓ Config updated:[/green]")
            for k, v in applied.items():
                console.print(f"  [bold]{k}[/bold] → {v}")
            console.print(f"\n[dim]{result.get('note', '')}[/dim]")
        except Exception as e:
            console.print(f"[red]✗ Config update failed: {e}[/red]")
            console.print("  Check that the API is running and your COLLAB_API_KEY is set.")
            raise typer.Exit(1)


if typer is not None:
    @app.command()
    def enroll(
        tool: str = typer.Argument(
            ..., help="Agent tool to configure: claude | cursor | windsurf | generic"
        ),
        api_key: str = typer.Option(
            None, "--key", "-k", help="API key (or reads COLLAB_API_KEY)"
        ),
        url: str = typer.Option(
            None, "--url", "-u", help="Semantic Dreams URL (or reads COLLAB_API_URL)"
        ),
    ):
        """
        Auto-configure an AI agent tool to use Semantic Dreams.

        Writes the MCP config so your agent connects on next launch.

        Examples:
          collab enroll claude
          collab enroll cursor --key cmk_write_abc123
          collab enroll windsurf --url https://my-instance.onrender.com
        """
        key = api_key or _api_key()
        base_url = url or os.environ.get("COLLAB_API_URL") or os.environ.get("COLLAB_MEMORY_URL") or ""

        if not key:
            console.print("[red]No API key found.[/red]")
            console.print("  Set COLLAB_API_KEY or pass --key <your-key>")
            console.print("  Get your key at: {}/signup".format(base_url or "https://<your-instance>"))
            raise typer.Exit(1)

        tool_lower = tool.lower()
        mcp_block = {
            "collab-memory": {
                "command": "collab-memory-mcp",
                "env": {
                    "COLLAB_API_KEY": key,
                },
            }
        }
        if base_url:
            mcp_block["collab-memory"]["env"]["COLLAB_MEMORY_URL"] = base_url

        if tool_lower == "claude":
            config_path = os.path.expanduser("~/.claude/claude_code_config.json")
            _write_mcp_config(config_path, mcp_block, "mcpServers")
            console.print(f"[green]Done.[/green] Claude Code configured at {config_path}")
            console.print("  Restart Claude Code to pick up the new config.")

        elif tool_lower == "cursor":
            config_path = os.path.join(os.getcwd(), ".cursor", "mcp.json")
            os.makedirs(os.path.dirname(config_path), exist_ok=True)
            _write_mcp_config(config_path, mcp_block, "mcpServers")
            console.print(f"[green]Done.[/green] Cursor configured at {config_path}")
            console.print("  Restart Cursor to pick up the new config.")

        elif tool_lower == "windsurf":
            config_path = os.path.expanduser("~/.codeium/windsurf/mcp_config.json")
            os.makedirs(os.path.dirname(config_path), exist_ok=True)
            _write_mcp_config(config_path, mcp_block, "mcpServers")
            console.print(f"[green]Done.[/green] Windsurf configured at {config_path}")
            console.print("  Restart Windsurf to pick up the new config.")

        elif tool_lower == "generic":
            console.print("[bold]MCP config block:[/bold]\n")
            console.print(json.dumps({"mcpServers": mcp_block}, indent=2))
            console.print("\n[dim]Paste this into your tool's MCP config file.[/dim]")

        else:
            console.print(f"[red]Unknown tool '{tool}'.[/red] Supported: claude, cursor, windsurf, generic")
            raise typer.Exit(1)


def _write_mcp_config(path: str, mcp_block: dict, key: str):
    """Merge MCP server config into an existing JSON file (or create it)."""
    existing = {}
    if os.path.exists(path):
        try:
            with open(path) as f:
                existing = json.load(f)
        except (json.JSONDecodeError, OSError):
            existing = {}

    if key not in existing:
        existing[key] = {}
    existing[key].update(mcp_block)

    with open(path, "w") as f:
        json.dump(existing, f, indent=2)
        f.write("\n")


def main():
    """Entry point for `collab` CLI command."""
    if typer is None:
        print("ERROR: typer and rich are required for the CLI.")
        print("Install with: pip install 'collab-memory[cli]'")
        sys.exit(1)
    app()


if __name__ == "__main__":
    main()
