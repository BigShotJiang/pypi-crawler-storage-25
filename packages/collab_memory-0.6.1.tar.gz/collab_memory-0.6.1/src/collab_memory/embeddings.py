"""
collab_memory/embeddings.py — Lightweight embedding generation for Co-Lab nodes.

Provider priority:
  1. Google text-embedding-004 (768 dims) — if GOOGLE_API_KEY or GEMINI_API_KEY set
  2. OpenAI text-embedding-3-small (1536 dims) — if OPENAI_API_KEY set
  3. Keyword n-gram fallback (128 dims) — always available, no API needed

The fallback ensures no node write is ever blocked by a missing embedding API.
"""
from __future__ import annotations

import hashlib as _hashlib
import math
import os
import threading
import time

# ── Embedding cache — avoids redundant API calls for identical text ──────────
_CACHE_MAX = 512
_CACHE_TTL = 300  # 5 minutes
_cache: dict[str, tuple[list[float], float]] = {}
_cache_lock = threading.Lock()


def _cache_key(text: str) -> str:
    return _hashlib.sha256(text.encode()).hexdigest()[:16]


def _cache_get(text: str) -> list[float] | None:
    key = _cache_key(text)
    with _cache_lock:
        entry = _cache.get(key)
        if entry and (time.monotonic() - entry[1]) < _CACHE_TTL:
            return entry[0]
        if entry:
            del _cache[key]
    return None


def _cache_put(text: str, vec: list[float]) -> None:
    key = _cache_key(text)
    with _cache_lock:
        if len(_cache) >= _CACHE_MAX:
            # Evict oldest entry
            oldest = min(_cache, key=lambda k: _cache[k][1])
            del _cache[oldest]
        _cache[key] = (vec, time.monotonic())


# ── Provider: Google text-embedding-004 ──────────────────────────────────────

def _google_embed(text: str) -> list[float]:
    """Use Google Generative AI embeddings via v1beta REST API.

    Model priority:
      1. gemini-embedding-001 (available with AI Studio key, high quality)
      2. gemini-embedding-2-preview (fallback)
    Uses direct REST calls to v1beta — the google-genai SDK also uses v1beta.
    """
    import json
    import urllib.request
    import urllib.error

    api_key = os.environ.get("GOOGLE_API_KEY") or os.environ.get("GEMINI_API_KEY")
    if not api_key:
        return []

    for model in ("gemini-embedding-001", "gemini-embedding-2-preview"):
        try:
            url = (
                "https://generativelanguage.googleapis.com/v1beta/models/"
                f"{model}:embedContent?key={api_key}"
            )
            payload = json.dumps({
                "model": f"models/{model}",
                "content": {"parts": [{"text": text}]},
            }).encode()
            req = urllib.request.Request(
                url, data=payload,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=10) as r:
                data = json.loads(r.read().decode())
            return [float(v) for v in data["embedding"]["values"]]
        except Exception:
            continue
    return []


# ── Provider: OpenAI text-embedding-3-small ───────────────────────────────────

def _openai_embed(text: str) -> list[float]:
    """Use OpenAI text-embedding-3-small (1536 dims)."""
    try:
        api_key = os.environ.get("OPENAI_API_KEY", "")
        if not api_key:
            return []
        from openai import OpenAI
        client = OpenAI(api_key=api_key)
        resp = client.embeddings.create(
            model="text-embedding-3-small",
            input=text[:8000],
        )
        return list(resp.data[0].embedding)
    except Exception:
        return []


# ── Fallback: character n-gram hash vector ────────────────────────────────────

def _ngram_vector(text: str, dims: int = 128) -> list[float]:
    """
    Deterministic keyword-based sparse vector (no API needed).
    Uses character n-gram hashing to produce a pseudo-semantic representation.
    Provides better fuzzy matching than exact keyword hits alone.
    """
    import hashlib
    vec = [0.0] * dims
    words = text.lower().split()
    for word in words:
        # 2-, 3-, 4-grams
        for n in range(2, min(len(word) + 1, 5)):
            for i in range(len(word) - n + 1):
                ngram = word[i:i + n]
                h = int(hashlib.md5(ngram.encode()).hexdigest(), 16)
                vec[h % dims] += 1.0
    # L2 normalize
    norm = math.sqrt(sum(x * x for x in vec))
    if norm > 0:
        vec = [x / norm for x in vec]
    return vec


# ── Public API ────────────────────────────────────────────────────────────────

def generate_embedding(text: str) -> list[float]:
    """
    Generate an embedding vector for the given text.

    Tries providers in priority order. Always returns a non-empty vector
    (n-gram fallback) so no node write is blocked.
    """
    if not text or not text.strip():
        return []

    text = text[:2000]  # Cap to avoid token limits

    # Check cache first — avoids redundant API calls during multi-node ingest
    cached = _cache_get(text)
    if cached:
        return cached

    vec = _google_embed(text)
    if not vec:
        vec = _openai_embed(text)
    if not vec:
        vec = _ngram_vector(text)

    _cache_put(text, vec)
    return vec


def cosine_similarity(a: list[float], b: list[float]) -> float:
    """
    Cosine similarity between two vectors.
    Returns 0.0 if either is empty or dimensions don't match.
    """
    if not a or not b or len(a) != len(b):
        return 0.0
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(x * x for x in b))
    if norm_a == 0.0 or norm_b == 0.0:
        return 0.0
    return dot / (norm_a * norm_b)
