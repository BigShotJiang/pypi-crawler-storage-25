"""
collab_memory/abac.py — Attribute-Based Access Control

Implements the 4-tier access model approved in docs/ABAC-RESEARCH.md:
  admin       — full read + write + delete (AG, human Claude Desktop)
  contributor — full read + write, no delete (Manus, peer agents)
  reader      — full read, no write, confidence-gated results
  external    — read public context only, writes auto-redirect to HITL queue

Role resolution (Option A — env-var role map):
  COLLAB_API_KEY          → admin
  COLLAB_API_KEY_MANUS    → contributor
  COLLAB_API_KEY_READONLY → reader
  COLLAB_API_KEY_EXTERNAL → external
  COLLAB_API_KEY_<ANY>    → contributor (safe default for new agent keys)

Usage in route handlers:
    from ..abac import require_role, AgentContext
    from fastapi import Depends

    @app.delete("/memory/nodes/{id}")
    async def delete_node(id: str, agent: AgentContext = Depends(require_role("admin"))):
        ...

Usage in middleware:
    from ..abac import resolve_agent_context
    ctx = resolve_agent_context(request.headers.get("X-API-Key", ""))
    request.state.agent = ctx
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Literal, Optional
from fastapi import HTTPException, Request


# ── Role definitions ─────────────────────────────────────────────────────────

Role = Literal["super_admin", "admin", "contributor", "reader", "external", "anonymous"]

# Minimum confidence score enforced for reader-role context responses.
READER_CONFIDENCE_MIN: float = 0.5

# Node types visible to readers (all types, using plain-language aliases in response).
# Future: add fine-grained filtering here as we learn what readers need.
READER_VISIBLE_TYPES: list[str] = ["Decision", "Constraint", "Preference", "Attempt"]

# Routes that external role is auto-redirected from (write ops → HITL queue).
# POST /memory/record, /memory/ingest go here; DELETE always 403 for external.
_EXTERNAL_REDIRECT_PATHS: set[str] = {
    "/memory/record",
    "/memory/ingest",
    "/artifacts",
    "/memory/pipeline/run",
}

# Routes that are completely blocked for external (cannot queue-redirect meaningfully).
_EXTERNAL_BLOCKED_PATHS: set[str] = {
    "/memory/nodes",         # node mutations
    "/memory/session",       # session consolidation
    "/ops/redeploy",         # ops mutations
    "/ops/git/sync",
}

# ── Route-role enforcement table ────────────────────────────────────────────
# Maps path prefixes → minimum required role for write methods (POST/PUT/DELETE/PATCH).
# Checked in order: first match wins (most-specific prefixes should come first).
# GET/HEAD requests bypass this table (they run the reader_view layer instead).
#
# Role ladder: super_admin(5) > admin(4) > contributor(3) > reader(2) > external(1) > anonymous(0)

_ROLE_ORDER: dict[str, int] = {
    "anonymous": 0,
    "external": 1,
    "reader": 2,
    "contributor": 3,
    "admin": 4,
    "super_admin": 5,
}

# (prefix, method_set or None=any-write) → minimum role
# None method_set means "all non-GET write methods".
_ROUTE_MIN_ROLE: list[tuple[str, frozenset[str] | None, Role]] = [
    # ── Admin-only routes ───────────────────────────────────────────────────
    ("/ops/github/prs",         frozenset({"POST"}),   "admin"),   # PR merge
    ("/ops/git/sync",           None,                  "admin"),   # git commit+push
    ("/ops/restart",            None,                  "admin"),   # Render restart
    ("/memory/nodes",           frozenset({"DELETE"}), "admin"),   # hard-delete nodes
    ("/artifacts",              frozenset({"DELETE"}), "admin"),   # artifact delete
    ("/ops/agent/reset",        None,                  "admin"),   # pipeline agent reset
    ("/agent/register",         frozenset({"POST"}),   "admin"),   # agent registration
    ("/memory/session",         frozenset({"DELETE"}), "admin"),   # session delete
    # ── Contributor-level routes ────────────────────────────────────────────
    ("/memory/record",          None,                  "contributor"),  # direct trusted write — was missing!
    ("/memory/ingest",          None,                  "contributor"),
    ("/memory/pipeline/run",    None,                  "contributor"),
    ("/memory/import",          None,                  "contributor"),
    ("/memory/session",         None,                  "contributor"),   # start/save/compress
    ("/memory/confirm",         None,                  "contributor"),
    ("/memory/reject",          None,                  "contributor"),
    ("/memory/queue_inference", None,                  "contributor"),
    ("/memory/watcher/trigger", None,                  "contributor"),
    ("/skills",                 None,                  "contributor"),
    ("/artifacts",              None,                  "contributor"),
    ("/projects",               None,                  "contributor"),
    ("/webhooks",               None,                  "contributor"),
    ("/workflows/sync",         None,                  "contributor"),
    ("/agent/inbox",            frozenset({"POST"}),   "contributor"),  # agent messaging
]


def check_route_permission(path: str, method: str, agent: "AgentContext") -> tuple[bool, str]:
    """
    Check whether the agent's role satisfies the minimum for this route.

    Returns:
        (allowed: bool, required_role: str)

    Rules:
    - GET/HEAD always pass (read-path separately governed by reader_view).
    - Admin bypasses route table entirely.
    - Otherwise: first matching prefix in _ROUTE_MIN_ROLE determines min role.
    - No match → default contributor required for writes.
    """
    if method.upper() in ("GET", "HEAD", "OPTIONS"):
        return True, ""

    if agent.role in ("admin", "super_admin"):
        return True, ""

    agent_level = _ROLE_ORDER.get(agent.role, 0)

    for prefix, methods, min_role in _ROUTE_MIN_ROLE:
        if not path.startswith(prefix):
            continue
        if methods is not None and method.upper() not in methods:
            continue
        required_level = _ROLE_ORDER.get(min_role, 99)
        if agent_level < required_level:
            return False, min_role
        return True, min_role

    # Default: any write requires at least contributor
    if agent_level < _ROLE_ORDER["contributor"]:
        return False, "contributor"
    return True, "contributor"



# ── Agent context ────────────────────────────────────────────────────────────

@dataclass
class AgentContext:
    """Resolved identity for the current request.

    Fields:
        role        — ABAC role (super_admin/admin/contributor/reader/external/anonymous)
        agent_id    — Identifier for the agent or user
        key         — API key used (if X-API-Key auth)
        project_id  — Graph partition scope
        tenant_id   — Billing/auth scope (Supabase user → management plane)
        plan        — Feature tier (free/pro/enterprise) for feature gating
    """
    role: Role = "anonymous"
    agent_id: str = "unknown"
    key: str = ""
    project_id: str = ""
    tenant_id: str = ""   # Set by JWT middleware (Supabase Auth)
    plan: str = "pro"     # Determines feature gate access (no free tier pre-revenue)
    is_superadmin: bool = False  # Cross-tenant visibility — only for blacktech.e@gmail.com

    @property
    def is_admin(self) -> bool:
        return self.role in ("admin", "super_admin")

    @property
    def is_contributor_or_above(self) -> bool:
        return self.role in ("admin", "super_admin", "contributor")

    @property
    def can_write(self) -> bool:
        return self.role in ("admin", "super_admin", "contributor")

    @property
    def can_delete(self) -> bool:
        return self.role in ("admin", "super_admin")

    @property
    def requires_hitl(self) -> bool:
        return self.role == "external"


# ── Role map construction ────────────────────────────────────────────────────

def _build_role_map() -> dict[str, AgentContext]:
    """
    Scan env vars for COLLAB_API_KEY* patterns and build a role lookup dict.

    Pattern → role mapping:
      COLLAB_API_KEY          → admin
      COLLAB_API_KEY_MANUS    → contributor (agent_id = "manus")
      COLLAB_API_KEY_READONLY → reader (agent_id = "readonly")
      COLLAB_API_KEY_EXTERNAL → external (agent_id = "external")
      COLLAB_API_KEY_<OTHER>  → contributor (safe default, agent_id = lowercase suffix)

    Tenant mapping (Sprint 23):
      COLLAB_TENANT_<SUFFIX>  → tenant_id for that agent key
      COLLAB_TENANT           → default tenant for admin key
      Falls back to "default" if no tenant env var exists.
    """
    role_map: dict[str, AgentContext] = {}

    # Resolve default tenant
    default_tenant = os.environ.get("COLLAB_TENANT", "default")

    for env_var, value in os.environ.items():
        if not env_var.startswith("COLLAB_API_KEY") or not value.strip():
            continue
        key = value.strip()
        suffix = env_var[len("COLLAB_API_KEY"):].lstrip("_").lower()

        if suffix == "":
            role: Role = "admin"
            agent_id = "admin"
        elif suffix == "readonly":
            role = "reader"
            agent_id = "readonly"
        elif suffix == "external":
            role = "external"
            agent_id = "external"
        else:
            # manus → contributor, any other → contributor (safe default)
            role = "contributor"
            agent_id = suffix

        # Resolve tenant: COLLAB_TENANT_MANUS → tenant for manus key, etc.
        tenant_key = f"COLLAB_TENANT_{suffix.upper()}" if suffix else "COLLAB_TENANT"
        tenant_id = os.environ.get(tenant_key, default_tenant)

        role_map[key] = AgentContext(
            role=role, agent_id=agent_id, key=key, tenant_id=tenant_id
        )

    return role_map


# Built once at import time; hot-reload-safe (module reimport rebuilds it).
_ROLE_MAP: dict[str, AgentContext] = _build_role_map()


def resolve_agent_context(api_key: str = "", graph=None) -> AgentContext:
    """
    Return the AgentContext for a given API key.

    Resolution order:
      1. Env-var role map (static, built at startup) — fast path
      2. Graph tenant lookup (dynamic) — for tenants registered at runtime
      3. Anonymous fallback
    """
    if not api_key:
        return AgentContext(role="anonymous")

    key = api_key.strip()

    # Fast path: static env-var map
    ctx = _ROLE_MAP.get(key)
    if ctx is not None:
        return ctx

    # Dynamic path: look up in graph (tenant-registered keys)
    if graph is not None:
        # Check project-scoped keys first
        try:
            pk = _lookup_project_key(graph, key)
            if pk is not None:
                return pk
        except Exception:
            pass

        try:
            tenant_node = graph.get_tenant_by_key(key)
            if tenant_node and tenant_node.get("status") == "active":
                is_write = tenant_node.get("_is_write_key", False)
                role: Role = "contributor" if is_write else "reader"
                return AgentContext(
                    role=role,
                    agent_id=tenant_node.get("id", "unknown"),
                    key=key,
                    tenant_id=tenant_node.get("id", "default"),
                )
        except Exception:
            pass  # Graph lookup failed — fall through to safe default

    # Safe fallback: contributor (can write but can't delete)
    return AgentContext(role="contributor", agent_id="unknown", key=key)


def _lookup_project_key(graph, key: str) -> Optional[AgentContext]:
    """
    Look up a project-scoped API key in Neo4j.

    ProjectKey nodes:
        (:ProjectKey {api_key, project_id, tenant_id, role, agent_id, status})

    Returns AgentContext with project_id set, or None if not found.
    """
    if not hasattr(graph, "_tx_read"):
        return None
    rows = graph._tx_read(
        "MATCH (pk:ProjectKey {api_key: $key, status: 'active'}) RETURN pk LIMIT 1",
        key=key,
    )
    if not rows:
        return None
    pk = dict(rows[0]["pk"])
    return AgentContext(
        role=pk.get("role", "contributor"),
        agent_id=pk.get("agent_id", "scoped-agent"),
        key=key,
        project_id=pk.get("project_id", ""),
        tenant_id=pk.get("tenant_id", ""),
        plan=pk.get("plan", "free"),
    )


def get_all_valid_keys(graph=None) -> set[str]:
    """Return the set of all registered API keys (env-var + graph tenants)."""
    keys = set(_ROLE_MAP.keys())
    if graph is not None:
        try:
            for tenant in graph.list_tenants():
                if tenant.get("status") == "active":
                    if tenant.get("api_key_write"):
                        keys.add(tenant["api_key_write"])
                    if tenant.get("api_key_read"):
                        keys.add(tenant["api_key_read"])
        except Exception:
            pass
    return keys


# ── Route-level enforcement ──────────────────────────────────────────────────

def require_role(min_role: Role):
    """
    FastAPI dependency that enforces a minimum role on a route.

    Usage:
        @app.delete("/memory/nodes/{id}")
        async def delete_node(
            id: str,
            agent: AgentContext = Depends(require_role("admin"))
        ):
    """
    _role_order: dict[Role, int] = {
        "anonymous": 0,
        "external": 1,
        "reader": 2,
        "contributor": 3,
        "admin": 4,
        "super_admin": 5,
    }

    async def _dependency(request: Request) -> AgentContext:
        agent: AgentContext = getattr(request.state, "agent", AgentContext())
        if _role_order.get(agent.role, 0) < _role_order.get(min_role, 99):
            raise HTTPException(
                status_code=403,
                detail={
                    "error": "Forbidden",
                    "required_role": min_role,
                    "your_role": agent.role,
                    "hint": "This operation requires elevated access. Contact OHACO Labs.",
                },
            )
        return agent

    return _dependency


def require_tenant():
    """
    FastAPI dependency that enforces a valid tenant_id on the request.

    Rejects requests where tenant_id is missing, empty, or "default".
    This is the database-level guard — even if middleware is bypassed
    (e.g., internal redirect), this catches it.

    Usage:
        @app.get("/memory/search")
        async def search(
            agent: AgentContext = Depends(require_tenant())
        ):
    """

    async def _dependency(request: Request) -> AgentContext:
        agent: AgentContext = getattr(request.state, "agent", AgentContext())
        if not agent.tenant_id or agent.tenant_id == "default":
            raise HTTPException(
                status_code=400,
                detail={
                    "error": "Missing tenant context",
                    "tenant_id": agent.tenant_id or "(none)",
                    "hint": "A valid tenant_id is required for all data operations. "
                            "Ensure your API key or JWT is associated with a tenant.",
                },
            )
        return agent

    return _dependency


# ── Reader perspective normalization ─────────────────────────────────────────

# Plain-language labels for reader-facing responses.
_READER_LABEL_MAP: dict[str, str] = {
    "Decision": "architectural_decision",
    "Constraint": "constraint",
    "Preference": "preference",
    "Attempt": "approach_tried",
    "Skill": "documented_skill",
    "Episode": "session_summary",
    "ExchangeRecord": "conversation_excerpt",
}

def reader_view(node: dict) -> dict:
    """
    Normalize a graph node dict for reader-role consumption.
    Strips internal schema fields; returns human-readable labels.
    Filters out low-confidence nodes (< READER_CONFIDENCE_MIN).
    """
    confidence = node.get("confidence", 0.5)
    if confidence < READER_CONFIDENCE_MIN:
        return {}  # Caller should filter out empty dicts

    original_type = node.get("node_type") or node.get("primitive_type", "")
    readable_type = _READER_LABEL_MAP.get(original_type, original_type.lower())

    return {
        "type": readable_type,
        "summary": node.get("description") or node.get("name") or node.get("summary", ""),
        "rationale": node.get("rationale", ""),
        "confidence": round(float(confidence), 2),
        "created_at": node.get("created_at", ""),
        "project_id": node.get("project_id", ""),
        # id kept for reference but called "ref" to avoid implying direct access
        "ref": node.get("id", ""),
    }


# ── External role HITL redirect helper ───────────────────────────────────────

def should_redirect_external_to_hitl(path: str, method: str) -> bool:
    """
    Returns True if an external-role request should be auto-redirected to
    the HITL queue instead of blocked (202 Queued response).
    """
    if method.upper() in ("DELETE", "PATCH"):
        return False  # Hard block — never allow deletes from external
    for prefix in _EXTERNAL_REDIRECT_PATHS:
        if path.startswith(prefix):
            return True
    return False


def is_blocked_for_external(path: str) -> bool:
    """Returns True if the path is entirely blocked for external role."""
    for prefix in _EXTERNAL_BLOCKED_PATHS:
        if path.startswith(prefix):
            return True
    return False
