"""
collab-memory MCP Server

Exposes the collab-memory graph as an MCP tool server. Any MCP-compatible
AI tool (Claude Desktop, Cursor, Windsurf, Continue.dev, etc.) can connect
to this server and get full project memory context with zero copy-paste.

Usage:
    collab-memory-mcp              # starts stdio MCP server (for Claude Desktop / Cursor)
    collab-memory-mcp --http       # starts HTTP MCP server on port 8765

Claude Desktop config (~/.claude/claude_desktop_config.json):
    {
      "mcpServers": {
        "collab-memory": {
          "command": "collab-memory-mcp",
          "env": {
            "COLLAB_MEMORY_URL": "https://your-instance.onrender.com"
          }
        }
      }
    }

Cursor / Windsurf: Add as MCP server in settings pointing to
    http://localhost:8765  (if running --http mode)
or via stdio command.
"""

import os
import sys
import json
import time
import asyncio
import argparse
import urllib.request
import urllib.error
import urllib.parse
from typing import Any

from collab_memory._version import __version__ as SERVER_VERSION

from mcp.server import Server
from mcp.server.stdio import stdio_server
try:
    from mcp.types import Tool, TextContent, Prompt, PromptMessage, GetPromptResult
except ImportError:
    from mcp.types import Tool, TextContent
    Prompt = PromptMessage = GetPromptResult = None  # type: ignore

# ── Config ───────────────────────────────────────────────────────────────────
BASE_URL = os.environ.get(
    "COLLAB_MEMORY_URL",
    "https://collab-memory.onrender.com"
).rstrip("/")

# Auth key — set COLLAB_API_KEY in env (mcp_config.json or shell)
_API_KEY = os.environ.get("COLLAB_API_KEY", "").strip()
_AUTH_HEADERS = {"X-API-Key": _API_KEY} if _API_KEY else {}

# Project + module scope — constrains all reads + writes to this project/module
_PROJECT_ID = os.environ.get("COLLAB_PROJECT_ID", "").strip()
_DEFAULT_MODULE = os.environ.get("COLLAB_MODULE", "").strip()

SERVER_NAME = "collab-memory"

# ── Context Enforcement Gate ──────────────────────────────────────────────────
# Per CONTEXT-ENFORCEMENT-DESIGN.md Layer 1:
# All tools (except exempt ones) are blocked until get_context() is called.
# Dormancy timeout resets the gate after 30 minutes of inactivity.
_DORMANCY_TIMEOUT = int(os.environ.get("COLLAB_DORMANCY_TIMEOUT", "1800"))  # 30 min
_session_context_loaded: bool = False
_last_tool_call_time: float = 0.0

# Tools that DON'T require context to be loaded first
_EXEMPT_TOOLS = {"get_context", "health_check"}


def _check_context_gate(tool_name: str) -> str | None:
    """Check if the context gate allows this tool call.

    Returns None if allowed, or an error message string if blocked.
    """
    global _session_context_loaded, _last_tool_call_time

    # Exempt tools always pass
    if tool_name in _EXEMPT_TOOLS:
        return None

    # Check dormancy timeout — reset gate if too much time has passed
    now = time.time()
    if _session_context_loaded and _last_tool_call_time > 0:
        elapsed = now - _last_tool_call_time
        if elapsed > _DORMANCY_TIMEOUT:
            _session_context_loaded = False
            return (
                f"⚠️ DORMANCY TIMEOUT: {int(elapsed // 60)} minutes since last tool call.\n"
                f"Session context expired. Call get_context() to reload project memory."
            )

    # Block if context not loaded
    if not _session_context_loaded:
        return (
            "⚠️ PROTOCOL VIOLATION: Context not loaded.\n"
            "Call get_context() before using any other tool.\n"
            "This request was blocked.\n\n"
            "Why: Without loading context, you risk making decisions that "
            "contradict existing architectural choices."
        )

    return None


# ── HTTP helpers ──────────────────────────────────────────────────────────────
def _get(path: str) -> dict:
    url = f"{BASE_URL}{path}"
    req = urllib.request.Request(url, headers=_AUTH_HEADERS)
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            return json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        return {"error": f"HTTP {e.code}: {e.reason}", "url": url}
    except Exception as e:
        return {"error": str(e), "url": url}


def _post(path: str, payload: dict) -> dict:
    url = f"{BASE_URL}{path}"
    body = json.dumps(payload).encode()
    headers = {"Content-Type": "application/json", **_AUTH_HEADERS}
    req = urllib.request.Request(url, data=body, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        return {"error": f"HTTP {e.code}: {e.reason}", "url": url}
    except Exception as e:
        return {"error": str(e), "url": url}


# ── Tool definitions ──────────────────────────────────────────────────────────
TOOLS = [
    Tool(
        name="get_context",
        description=(
            "Get the full project memory context for this session. "
            "Returns standing architectural decisions, active constraints, "
            "inferred preferences, and any items awaiting review. "
            "ALWAYS call this at the start of every session before doing any work."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "project": {
                    "type": "string",
                    "description": "Optional project ID to scope context. Omit for default.",
                }
            },
            "required": [],
        },
    ),
    Tool(
        name="consolidate_session",
        description=(
            "Consolidate all temporary session data (decisions, inferences, artifacts) "
            "into the permanent project memory. Call this at the end of a session "
            "to persist all work. If you don't call this, session data will be lost."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "session_id": {
                    "type": "string",
                    "description": "The session ID to consolidate. Default: 'mcp_session'.",
                },
                "project_id": {
                    "type": "string",
                    "description": "Optional project ID to associate consolidated data with.",
                },
            },
            "required": [],
        },
    ),
    Tool(
        name="run_python",
        description=(
            "Execute Python code in a sandboxed subprocess. Use this to verify logic, "
            "analyse data, run calculations, test schemas, or prototype ideas. "
            "Network access and filesystem writes (outside /tmp) are blocked. "
            "Output is capped at 16 KB. Timeout: 30s."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "code": {
                    "type": "string",
                    "description": "Python source code to execute.",
                },
                "timeout": {
                    "type": "integer",
                    "description": "Max execution seconds (default: 30).",
                },
                "inject_vars": {
                    "type": "object",
                    "description": "Optional dict of variables to inject as locals before execution.",
                },
            },
            "required": ["code"],
        },
    ),
    Tool(
        name="search_memory",
        description=(
            "Search the project memory graph for decisions, constraints, or preferences "
            "related to a specific topic or keyword. Use this when you need to know "
            "if a decision was already made, or what constraints apply to an area."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "What to search for — topic, keyword, or question.",
                },
                "node_type": {
                    "type": "string",
                    "enum": ["decision", "constraint", "preference", "attempt", "any"],
                    "description": "Filter by node type. Default: any.",
                },
            },
            "required": ["query"],
        },
    ),
    Tool(
        name="record_decision",
        description=(
            "Record a new architectural decision, constraint, or preference into project memory. "
            "Use this when an important decision is made during the session that should persist. "
            "The system will classify and store it automatically."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "content": {
                    "type": "string",
                    "description": "The decision, constraint, or preference to record. "
                                   "Write it as a clear statement, e.g. 'Use PostgreSQL for all relational data.'",
                },
                "session_id": {
                    "type": "string",
                    "description": "Optional session label. Default: 'mcp_session'.",
                },
            },
            "required": ["content"],
        },
    ),
    Tool(
        name="get_pending",
        description=(
            "Protocol (after get_context): list inferences awaiting review. "
            "Use confirm_pending or reject_pending with each item's id — do not skip if count > 0."
        ),
        inputSchema={
            "type": "object",
            "properties": {},
            "required": [],
        },
    ),
    Tool(
        name="inbox_send",
        description=(
            "Send a message to another agent_id, a shared inbox target (e.g. team), or the human operator. "
            "Use after get_context for handoffs, alerts, or PR/merge notifications. "
            "Requires contributor API key. Messages expire after 7 days."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "to": {
                    "type": "string",
                    "description": "Recipient agent_id or 'operator' for human (default: operator).",
                },
                "subject": {"type": "string", "description": "Short subject line."},
                "body": {"type": "string", "description": "Message body (required)."},
                "priority": {
                    "type": "string",
                    "description": "normal | high | urgent (default: normal).",
                },
                "topic": {"type": "string", "description": "Optional tag for filtering (e.g. pr-merged, handoff)."},
                "project_id": {
                    "type": "string",
                    "description": "Optional project scope; defaults to COLLAB_PROJECT_ID env if set.",
                },
            },
            "required": ["body"],
        },
    ),
    Tool(
        name="inbox_read",
        description=(
            "Read messages addressed to an agent or operator. "
            "Call after get_context at session start or after completing a task. "
            "If target is omitted, uses the API key's agent_id (or operator)."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "target": {
                    "type": "string",
                    "description": "agent_id to read for; omit to use your key's default inbox.",
                },
                "status": {
                    "type": "string",
                    "description": "unread | all | read (default: unread).",
                },
                "limit": {
                    "type": "integer",
                    "description": "Max messages (1–100, default 20).",
                },
            },
            "required": [],
        },
    ),
    Tool(
        name="inbox_ack",
        description=(
            "Mark an inbox message as read after acting on it. "
            "Use the message id from inbox_read."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "message_id": {"type": "string", "description": "AgentMessage id from inbox_read."},
            },
            "required": ["message_id"],
        },
    ),
    Tool(
        name="health_check",
        description="Check if the collab-memory backend is online and which graph backend is active.",
        inputSchema={
            "type": "object",
            "properties": {},
            "required": [],
        },
    ),
    # ── Artifacts ────────────────────────────────────────────────────────────
    Tool(
        name="store_artifact",
        description=(
            "Store any file (code, HTML, markdown, config, prompts) in the shared Neo4j artifact store. "
            "Any agent on any platform can retrieve it later by ID. "
            "Use this to persist work products across sessions and platforms."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "Descriptive name for the artifact."},
                "content": {"type": "string", "description": "Full text content of the file (up to 100KB)."},
                "artifact_type": {"type": "string", "description": "Type: code | html | markdown | config | prompt | other"},
                "description": {"type": "string", "description": "Optional description of what this artifact is."},
                "session_id": {"type": "string", "description": "Optional session label for filtering later."},
                "project_id": {"type": "string", "description": "Optional project ID to scope the artifact."},
                "tags": {"type": "array", "items": {"type": "string"}, "description": "Optional list of tags."},
            },
            "required": ["name", "content"],
        },
    ),
    Tool(
        name="get_artifact",
        description=(
            "Retrieve a stored artifact by its ID. Returns full file content. "
            "Use list_artifacts first if you don't have the ID."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "artifact_id": {"type": "string", "description": "The artifact ID (from store_artifact or list_artifacts)."},
            },
            "required": ["artifact_id"],
        },
    ),
    Tool(
        name="list_artifacts",
        description="List stored artifacts. Optionally filter by project, type, or session.",
        inputSchema={
            "type": "object",
            "properties": {
                "project_id": {"type": "string", "description": "Filter by project ID."},
                "artifact_type": {"type": "string", "description": "Filter by type: code | html | markdown | config | prompt | other"},
                "session_id": {"type": "string", "description": "Filter by session ID."},
                "limit": {"type": "integer", "description": "Max results to return (default 20)."},
            },
            "required": [],
        },
    ),
    # ── Inference Confirmation ───────────────────────────────────────────────
    Tool(
        name="queue_inference",
        description=(
            "Queue a novel item that you inferred (but were not explicitly told) for human review. "
            "Use this instead of record_decision when confidence is below 0.8 or the item was not "
            "directly stated by the user. The user confirms or rejects via the dashboard."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "description": {"type": "string", "description": "The inferred item — write as a clear statement."},
                "node_type": {"type": "string", "description": "decision | constraint | preference"},
                "confidence": {"type": "number", "description": "Your confidence score (0.0–1.0)."},
                "session_id": {"type": "string", "description": "Optional session label."},
                "raw_text": {"type": "string", "description": "Optional: the exact text that led you to this inference."},
            },
            "required": ["description", "node_type"],
        },
    ),
    Tool(
        name="confirm_pending",
        description=(
            "Protocol: after get_pending(), accept one queued inference and write it to the graph. "
            "Requires contributor API key. Pass the item id from get_pending."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "item_id": {
                    "type": "string",
                    "description": "Pending row id (e.g. pnd_abc12ef3) from get_pending.",
                },
            },
            "required": ["item_id"],
        },
    ),
    Tool(
        name="reject_pending",
        description=(
            "Protocol: after get_pending(), discard one queued inference without writing to active memory."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "item_id": {
                    "type": "string",
                    "description": "Pending row id from get_pending.",
                },
            },
            "required": ["item_id"],
        },
    ),
    # ── Decision Archaeology ─────────────────────────────────────────────────
    Tool(
        name="explain_decision",
        description=(
            "Trace the full causal chain for a decision: what constraints shaped it, "
            "what attempts preceded it, and the raw exchange text it came from. "
            "Use this to understand *why* a decision was made before challenging it."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "decision_id": {"type": "string", "description": "The decision ID to trace (from get_context or search_memory)."},
            },
            "required": ["decision_id"],
        },
    ),
    # ── Skills Library ───────────────────────────────────────────────────────
    Tool(
        name="search_skills",
        description=(
            "Search the skills knowledge library by keyword. Returns matching API docs, "
            "how-tos, and code snippets. Use this before implementing anything — "
            "a skill may already document the correct approach."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Keywords to search for."},
                "limit": {"type": "integer", "description": "Max results (default 10)."},
            },
            "required": ["query"],
        },
    ),
    # ── Workflows ────────────────────────────────────────────────────────────
    Tool(
        name="list_workflows",
        description=(
            "List available workflow templates (app-build-planning, dev-environment-setup, "
            "opsec-baseline, etc.). Use this to discover structured, gate-driven workflows "
            "before starting any major build, setup, or security review. "
            "Returns workflow name, description, trigger keywords, and number of gates."
        ),
        inputSchema={
            "type": "object",
            "properties": {},
            "required": [],
        },
    ),
    Tool(
        name="get_workflow",
        description=(
            "Get the full SOP (standard operating procedure) for a workflow by slug. "
            "Returns the complete step-by-step body and all gate questions. "
            "Inject the 'body' field into the agent's context to run the workflow."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "slug": {"type": "string", "description": "Workflow slug, e.g. 'app-build-planning' or 'opsec-baseline'"},
            },
            "required": ["slug"],
        },
    ),
    Tool(
        name="fetch_skill_url",
        description=(
            "Fetch a URL and index its content as a skill in the knowledge library. "
            "Use this to add API docs, README pages, or integration guides so future "
            "agents can search and retrieve them without re-fetching."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "url": {"type": "string", "description": "URL to fetch and index."},
                "name": {"type": "string", "description": "Optional display name for the skill."},
                "tags": {"type": "array", "items": {"type": "string"}, "description": "Optional tags."},
            },
            "required": ["url"],
        },
    ),
    Tool(
        name="get_history",
        description=(
            "Retrieve paginated exchange history — the raw conversation turns that produced "
            "the decisions in the graph. Use this to understand the full reasoning behind a "
            "decision, resume from a prior session, or find context that wasn't distilled into "
            "a graph node. Each result includes a text preview, session_id, and worthiness score."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "session_id": {"type": "string", "description": "Filter to a specific session (optional)."},
                "limit": {"type": "integer", "description": "Records per page (default 20, max 200)."},
                "offset": {"type": "integer", "description": "Pagination offset (default 0)."},
                "min_score": {"type": "number", "description": "Min worthiness score 0.0–1.0 (default 0.3)."},
                "primitive_type": {"type": "string", "description": "Filter by type: Decision|Constraint|Preference|Attempt|Exploration."},
            },
            "required": [],
        },
    ),
]


# ── Tool handlers ─────────────────────────────────────────────────────────────
async def handle_tool(name: str, arguments: dict) -> list[TextContent]:
    global _session_context_loaded, _last_tool_call_time

    # ── Context Enforcement Gate ──────────────────────────────────────────
    gate_error = _check_context_gate(name)
    if gate_error:
        return [TextContent(type="text", text=gate_error)]

    # Update last tool call time for dormancy tracking
    _last_tool_call_time = time.time()

    if name == "get_context":
        path = "/memory/context/prompt"
        if _PROJECT_ID:
            path += f"?project_id={_PROJECT_ID}"
        data = _get(path)
        if "error" in data:
            return [TextContent(type="text", text=f"Error: {data['error']}")]
        # Mark context as loaded — unlocks all other tools
        _session_context_loaded = True
        return [TextContent(type="text", text=data.get("prompt", "(empty context)"))]

    elif name == "search_memory":
        query = arguments.get("query", "")
        node_type = arguments.get("node_type", "any")
        limit = arguments.get("limit", 20)
        # Use the real semantic search endpoint, scoped to project
        _pid = os.environ.get("COLLAB_PROJECT_ID", "")
        path = f"/memory/search?q={urllib.parse.quote(query)}&limit={limit}"
        if node_type and node_type != "any":
            path += f"&node_types={urllib.parse.quote(node_type)}"
        if _pid:
            path += f"&project_id={urllib.parse.quote(_pid)}"
        data = _get(path)
        if "error" in data:
            return [TextContent(type="text", text=f"Error: {data['error']}")]

        results = data.get("results", [])
        if not results:
            return [TextContent(type="text", text=f"No results found for '{query}'" + (f" in project '{_pid}'" if _pid else ""))]

        lines = [f"## Memory search: '{query}'\n", f"*{len(results)} results*\n"]
        for item in results:
            ntype = item.get("node_type", "")
            score = item.get("relevance_score", 0)
            conf = item.get("confidence", 0)
            desc = item.get("description", "")[:120]
            lines.append(f"**[{ntype}]** (relevance: {score}, confidence: {int(conf*100)}%) {desc}")
            if item.get("rationale"):
                lines.append(f"  _Rationale: {item['rationale'][:80]}_")
        return [TextContent(type="text", text="\n".join(lines))]

    elif name == "record_decision":
        content = arguments.get("content", "")
        session_id = arguments.get("session_id", "mcp_session")
        module = arguments.get("module", _DEFAULT_MODULE)
        category = arguments.get("category", "decision")
        # Trusted direct write — agent has already classified this.
        data = _post("/memory/record", {
            "content": content,
            "node_type": "Decision",
            "session_id": session_id,
            "project_id": _PROJECT_ID or None,
            "module": module,
            "category": category,
        })
        if "error" in data:
            return [TextContent(type="text", text=f"Error: {data['error']}")]
        node_id = data.get("id", "?")
        description = data.get("description", content[:60])
        return [TextContent(type="text", text=f"✓ Decision recorded [{node_id}] project={_PROJECT_ID or 'default'} module={module}: {description}")]


    elif name == "get_pending":
        path = "/memory/pending"
        if _PROJECT_ID:
            path += f"?project_id={urllib.parse.quote(_PROJECT_ID)}"
        data = _get(path)
        if "error" in data:
            return [TextContent(type="text", text=f"Error: {data['error']}")]
        items = data.get("pending", [])
        if not items:
            return [TextContent(type="text", text="✓ No pending items — all inferences confirmed.")]
        lines = [
            f"## {len(items)} item(s) awaiting review\n",
            "_Protocol: call `confirm_pending(item_id=...)` or `reject_pending(item_id=...)` for each._\n",
        ]
        for item in items:
            iid = item.get("id", "?")
            lines.append(f"- **id `{iid}`** [{item.get('node_type','?')}] {item.get('description','')}")
            lines.append(f"  → confirm_pending(item_id=\"{iid}\") | reject_pending(item_id=\"{iid}\")")
        return [TextContent(type="text", text="\n".join(lines))]

    elif name == "inbox_send":
        body = (arguments.get("body") or "").strip()
        if not body:
            return [TextContent(type="text", text="Error: body is required")]
        payload = {
            "to": arguments.get("to") or "operator",
            "subject": arguments.get("subject") or "",
            "body": body,
            "priority": arguments.get("priority") or "normal",
            "topic": arguments.get("topic") or "",
            "project_id": (arguments.get("project_id") or _PROJECT_ID or ""),
        }
        data = _post("/agent/inbox", payload)
        if "error" in data:
            return [TextContent(type="text", text=f"Error: {data['error']}")]
        return [TextContent(type="text", text=(
            f"✓ Sent · id `{data.get('message_id', '?')}` · to `{data.get('to', payload['to'])}` "
            f"· priority {data.get('priority', payload['priority'])} · expires {data.get('expires_at', '?')}"
        ))]

    elif name == "inbox_read":
        params: list[str] = []
        target = (arguments.get("target") or "").strip()
        if target:
            params.append(f"target={urllib.parse.quote(target)}")
        status = arguments.get("status") or "unread"
        if status not in ("unread", "all", "read"):
            status = "unread"
        params.append(f"status={urllib.parse.quote(status)}")
        limit = arguments.get("limit", 20)
        try:
            lim = max(1, min(100, int(limit)))
        except (TypeError, ValueError):
            lim = 20
        params.append(f"limit={lim}")
        path = f"/agent/inbox?{'&'.join(params)}"
        data = _get(path)
        if "error" in data:
            return [TextContent(type="text", text=f"Error: {data['error']}")]
        msgs = data.get("messages", [])
        inbox_for = data.get("inbox_for", target or "default")
        if not msgs:
            return [TextContent(type="text", text=f"✓ Inbox empty for `{inbox_for}` ({status}).")]
        lines = [f"## Inbox · `{inbox_for}` · {len(msgs)} message(s) ({status})\n"]
        for m in msgs:
            mid = m.get("id", "?")
            lines.append(
                f"### `{mid}` · {m.get('priority', 'normal')} · from `{m.get('from', '?')}`\n"
                f"**{m.get('subject', '(no subject)')}**  \n"
                f"{m.get('body', '')}\n"
                f"_topic: {m.get('topic', '')} · status: {m.get('status', '')} · {m.get('created_at', '')}_\n"
                f"Ack: use inbox_ack(message_id=\"{mid}\")\n"
            )
        return [TextContent(type="text", text="\n".join(lines))]

    elif name == "inbox_ack":
        mid = (arguments.get("message_id") or "").strip()
        if not mid:
            return [TextContent(type="text", text="Error: message_id is required")]
        data = _post(f"/agent/inbox/{urllib.parse.quote(mid, safe='')}/ack", {})
        if "error" in data:
            return [TextContent(type="text", text=f"Error: {data['error']}")]
        if data.get("acknowledged"):
            return [TextContent(type="text", text=f"✓ Acknowledged message `{mid}`")]
        return [TextContent(type="text", text=json.dumps(data, indent=2))]

    elif name == "health_check":
        data = _get("/health")
        if "error" in data:
            return [TextContent(type="text", text=f"Offline: {data['error']}")]
        return [TextContent(type="text", text=(
            f"✓ collab-memory {data.get('version','?')} · "
            f"{data.get('backend','?')} · "
            f"status: {data.get('status','?')}"
        ))]

    # ── Artifacts ─────────────────────────────────────────────────────────────
    elif name == "store_artifact":
        payload = {
            "name": arguments.get("name", ""),
            "content": arguments.get("content", ""),
            "artifact_type": arguments.get("artifact_type", "other"),
            "description": arguments.get("description", ""),
            "session_id": arguments.get("session_id", "mcp_session"),
            "tags": arguments.get("tags", []),
        }
        if arguments.get("project_id"):
            payload["project_id"] = arguments["project_id"]
        data = _post("/artifacts", payload)
        if "error" in data:
            return [TextContent(type="text", text=f"Error: {data['error']}")]
        art_id = data.get("artifact_id", data.get("id", "?"))
        return [TextContent(type="text", text=f"✓ Artifact stored · ID: {art_id} · Name: {arguments.get('name')}")]

    elif name == "get_artifact":
        art_id = arguments.get("artifact_id", "")
        data = _get(f"/artifacts/{art_id}")
        if "error" in data:
            return [TextContent(type="text", text=f"Error: {data['error']}")]
        name_str = data.get("name", art_id)
        content = data.get("content", "(no content)")
        art_type = data.get("artifact_type", "?")
        return [TextContent(type="text", text=f"## {name_str} ({art_type})\n\n{content}")]

    elif name == "list_artifacts":
        params = []
        if arguments.get("project_id"): params.append(f"project_id={urllib.parse.quote(arguments['project_id'])}")
        if arguments.get("artifact_type"): params.append(f"artifact_type={urllib.parse.quote(arguments['artifact_type'])}")
        if arguments.get("session_id"): params.append(f"session_id={urllib.parse.quote(arguments['session_id'])}")
        params.append(f"limit={arguments.get('limit', 20)}")
        data = _get(f"/artifacts?{'&'.join(params)}")
        if "error" in data:
            return [TextContent(type="text", text=f"Error: {data['error']}")]
        items = data.get("artifacts", data if isinstance(data, list) else [])
        if not items:
            return [TextContent(type="text", text="No artifacts found.")]
        lines = [f"## {len(items)} artifact(s)\n"]
        for a in items:
            lines.append(f"- **{a.get('name','?')}** | type: {a.get('artifact_type','?')} | id: `{a.get('artifact_id', a.get('id','?'))}`")
        return [TextContent(type="text", text="\n".join(lines))]

    # ── Inference Confirmation ─────────────────────────────────────────────────
    elif name == "queue_inference":
        payload = {
            "description": arguments.get("description", ""),
            "node_type": arguments.get("node_type", "decision"),
            "confidence": arguments.get("confidence", 0.6),
            "session_id": arguments.get("session_id", "mcp_session"),
            "raw_text": arguments.get("raw_text", ""),
        }
        data = _post("/memory/queue_inference", payload)
        if "error" in data:
            return [TextContent(type="text", text=f"Error: {data['error']}")]
        item_id = data.get("queued_id", data.get("id", data.get("item_id", "?")))
        return [TextContent(type="text", text=(
            f"✓ Queued for review · ID: `{item_id}`\n"
            f"Protocol: reviewer calls get_pending → confirm_pending or reject_pending with this id."
        ))]

    elif name == "confirm_pending":
        iid = (arguments.get("item_id") or "").strip()
        if not iid:
            return [TextContent(type="text", text="Error: item_id is required")]
        data = _post(f"/memory/confirm/{urllib.parse.quote(iid, safe='')}", {})
        if "error" in data or not data.get("ok", True):
            detail = data.get("error") or data.get("detail", data)
            return [TextContent(type="text", text=f"Error: {detail}")]
        return [TextContent(type="text", text=(
            f"✓ Confirmed `{iid}` → {data.get('node_type', '?')} written to graph."
        ))]

    elif name == "reject_pending":
        iid = (arguments.get("item_id") or "").strip()
        if not iid:
            return [TextContent(type="text", text="Error: item_id is required")]
        data = _post(f"/memory/reject/{urllib.parse.quote(iid, safe='')}", {})
        if "error" in data or not data.get("ok", True):
            detail = data.get("error") or data.get("detail", data)
            return [TextContent(type="text", text=f"Error: {detail}")]
        return [TextContent(type="text", text=f"✓ Rejected `{iid}` (not written to active memory).")]

    # ── Decision Archaeology ───────────────────────────────────────────────────
    elif name == "explain_decision":
        dec_id = arguments.get("decision_id", "")
        data = _get(f"/memory/why?decision={urllib.parse.quote(dec_id)}")
        if "error" in data:
            return [TextContent(type="text", text=f"Error: {data['error']}")]
        lines = [f"## Decision Archaeology: `{dec_id}`\n"]
        if data.get("description"):
            lines.append(f"**Decision:** {data['description']}\n")
        if data.get("rationale"):
            lines.append(f"**Rationale:** {data['rationale']}\n")
        if data.get("constraints"):
            lines.append("**Shaped by constraints:**")
            for c in data["constraints"]:
                lines.append(f"  - {c.get('description', c)}")
        if data.get("attempts"):
            lines.append("**Preceded by attempts:**")
            for a in data["attempts"]:
                lines.append(f"  - {a.get('description', a)}")
        if data.get("raw_exchange"):
            lines.append(f"\n**Source exchange:**\n> {data['raw_exchange'][:500]}")
        return [TextContent(type="text", text="\n".join(lines) or "No archaeology data found for this decision.")]

    # ── Skills Library ─────────────────────────────────────────────────────────
    elif name == "search_skills":
        q = urllib.parse.quote(arguments.get("query", ""))
        limit = arguments.get("limit", 10)
        data = _get(f"/skills/search?q={q}&limit={limit}")
        if "error" in data:
            return [TextContent(type="text", text=f"Error: {data['error']}")]
        skills = data.get("skills", data if isinstance(data, list) else [])
        if not skills:
            return [TextContent(type="text", text=f"No skills found for '{arguments.get('query')}'")]
        lines = [f"## {len(skills)} skill(s) matching '{arguments.get('query')}'\n"]
        for s in skills:
            lines.append(f"### {s.get('name', '?')}")
            if s.get("summary"): lines.append(s["summary"])
            if s.get("url"): lines.append(f"  URL: {s['url']}")
            if s.get("tags"): lines.append(f"  Tags: {', '.join(s['tags'])}")
            lines.append("")
        return [TextContent(type="text", text="\n".join(lines))]

    elif name == "fetch_skill_url":
        payload = {
            "url": arguments.get("url", ""),
            "name": arguments.get("name", ""),
            "tags": arguments.get("tags", []),
            "source_type": "api_docs",
        }
        data = _post("/skills/fetch", payload)
        if "error" in data:
            return [TextContent(type="text", text=f"Error: {data['error']}")]
        skill_name = data.get("name", arguments.get("url", "?"))
        return [TextContent(type="text", text=f"✓ Fetched and indexed: **{skill_name}**\nSearch for it with search_skills.")]

    elif name == "get_history":
        session_id = arguments.get("session_id", "")
        limit = arguments.get("limit", 20)
        offset = arguments.get("offset", 0)
        min_score = arguments.get("min_score", 0.3)
        ptype = arguments.get("primitive_type", "")

        path = f"/memory/history?limit={limit}&offset={offset}&min_score={min_score}"
        if session_id:
            path += f"&session_id={urllib.parse.quote(session_id)}"
        if ptype:
            path += f"&primitive_type={urllib.parse.quote(ptype)}"

        data = _get(path)
        if "error" in data:
            return [TextContent(type="text", text=f"Error: {data['error']}")]

        records = data.get("records", [])
        total = data.get("total", 0)
        has_more = data.get("has_more", False)

        if not records:
            return [TextContent(type="text", text="No exchange records found matching your filters.")]

        lines = [
            f"## Exchange History ({total} total{', more available' if has_more else ''})\n",
            f"*Showing {len(records)} records (offset={offset})*\n",
        ]
        for rec in records:
            score = rec.get("worthiness_score", 0)
            ptype_label = rec.get("primitive_type", "?")
            sid = rec.get("session_id", "unknown")
            ts = rec.get("created_at", "")[:16]
            preview = rec.get("text_preview", "")
            lines.append(f"**[{ptype_label}]** score={score} | session={sid} | {ts}")
            lines.append(f"> {preview}")
            lines.append("")

        if has_more:
            lines.append(f"*Use offset={offset + limit} to get the next page.*")

        return [TextContent(type="text", text="\n".join(lines))]

    elif name == "list_workflows":
        data = _get("/workflows")
        if "error" in data:
            return [TextContent(type="text", text=f"Error: {data['error']}")]
        workflows = data.get("workflows", [])
        if not workflows:
            return [TextContent(type="text", text="No workflow templates found. Run POST /workflows/sync first.")]
        lines = [f"## {len(workflows)} workflow template(s) available\n"]
        for wf in workflows:
            triggers = ", ".join(wf.get("triggers", [])[:2])
            lines.append(f"**{wf['name']}** ({wf['category']}, {wf.get('gate_count',0)} gates)")
            lines.append(f"> {wf['description']}")
            lines.append(f"> Triggers: {triggers}")
            lines.append(f"> Slug: `{wf['slug']}`")
            lines.append("")
        return [TextContent(type="text", text="\n".join(lines))]

    elif name == "get_workflow":
        slug = arguments.get("slug", "")
        data = _get(f"/workflows/{slug}")
        if "error" in data:
            return [TextContent(type="text", text=f"Error: {data['error']}")]
        gates = data.get("gates", [])
        gate_lines = [f"- **Gate {i+1}**: {g.get('question','') if isinstance(g,dict) else g}" for i, g in enumerate(gates)]
        body = data.get("body", "")
        return [TextContent(type="text", text=(
            f"# Workflow: {data['name']}\n"
            f"{data['description']}\n\n"
            f"**Gates ({len(gates)} required questions):**\n" + "\n".join(gate_lines) + "\n\n"
            f"**SOP:**\n{body[:3000]}"
        ))]

    elif name == "run_python":
        code = arguments.get("code", "")
        timeout = arguments.get("timeout", None)
        inject_vars = arguments.get("inject_vars", None)
        data = _post("/agent/python/run", {
            "code": code,
            "timeout": timeout,
            "inject_vars": inject_vars,
        })
        if data.get("blocked"):
            return [TextContent(type="text", text=(
                f"⛔ Blocked imports: {', '.join(data['blocked'])}\n"
                "Network access is not allowed in the sandbox."
            ))]
        if data.get("timed_out"):
            return [TextContent(type="text", text=f"⏱ Timed out after {timeout or 30}s.")]
        stdout = data.get("stdout", "").strip()
        stderr = data.get("stderr", "").strip()
        exit_code = data.get("exit_code", -1)
        status = "✓" if exit_code == 0 else "✗"
        lines = [f"## Python Run {status} (exit {exit_code})"]
        if stdout:
            lines.append(f"```\n{stdout}\n```")
        if stderr:
            lines.append(f"**stderr:**\n```\n{stderr}\n```")
        if not stdout and not stderr:
            lines.append("(no output)")
        return [TextContent(type="text", text="\n".join(lines))]

    elif name == "consolidate_session":
        session_id = arguments.get("session_id", "")
        project_id = arguments.get("project_id")
        if not session_id:
            return [TextContent(type="text", text="Error: session_id is required")]
        data = _post(f"/memory/session/{urllib.parse.quote(session_id)}/consolidate", {})
        if "error" in data:
            return [TextContent(type="text", text=f"Error: {data['error']}")]
        episode_id = data.get("episode_id", "unknown")
        summary = data.get("summary", "")
        themes = ", ".join(data.get("themes", []))
        counts = data.get("counts", {})
        return [TextContent(type="text", text=(
            f"## Session Consolidated → Episode Node\n"
            f"**Episode ID:** {episode_id}\n"
            f"**Session:** {session_id}\n"
            f"**Themes:** {themes}\n"
            f"**Counts:** {counts.get('decisions',0)} decisions, "
            f"{counts.get('constraints',0)} constraints, "
            f"{counts.get('preferences',0)} preferences, "
            f"{counts.get('exchanges',0)} exchanges\n\n"
            f"**Summary:**\n{summary}"
        ))]

    return [TextContent(type="text", text=f"Unknown tool: {name}")]


# ── Server entry point ────────────────────────────────────────────────────────
async def run_stdio():
    server = Server(SERVER_NAME)

    # ── Session folder auto-ingestion ─────────────────────────────────────────
    # If ANTIGRAVITY_BRAIN_DIR is set, read all .md files from the session
    # folder and upload them to /memory/record in a background thread.
    # This ensures get_context() returns real, current data for this project.
    _brain_dir = os.environ.get("ANTIGRAVITY_BRAIN_DIR", "").strip()
    if _brain_dir:
        import threading
        from .session_ingester import ingest_brain_folder

        def _run_ingestion():
            print(
                f"[collab-memory] auto-ingesting session folder: {_brain_dir}",
                file=sys.stderr,
            )
            result = ingest_brain_folder(
                brain_dir=_brain_dir,
                base_url=BASE_URL,
                api_key=_API_KEY,
                delay_between_posts=0.8,  # respect Render free tier
            )
            print(
                f"[collab-memory] ingestion complete: "
                f"{result.get('chunks_ok',0)}/{result.get('chunks_sent',0)} chunks uploaded, "
                f"{result.get('files_skipped',0)} files unchanged",
                file=sys.stderr,
            )

        threading.Thread(target=_run_ingestion, daemon=True, name="session-ingester").start()


    @server.list_tools()
    async def list_tools() -> list[Tool]:
        return TOOLS

    @server.call_tool()
    async def call_tool(name: str, arguments: dict) -> list[TextContent]:
        return await handle_tool(name, arguments)

    # ── Auto-Bootstrap Prompts (Sprint S6) ────────────────────────────────────
    _BOOTSTRAP_TEXT = (
        "COLLAB-MEMORY AUTO-BOOTSTRAP PROTOCOL\n"
        "Before responding to ANY user message in this session, perform these two steps:\n"
        "1. Call `get_context()` to load all active decisions, constraints, preferences, "
        "    and recent session summaries. Inject the results into your working context.\n"
        "2. Call `get_pending()` to check for any inferences awaiting human review.\n"
        "   If any items exist, call `confirm_pending` or `reject_pending` for each id (protocol — do not ignore).\n"
        "Then — and only then — respond to the user.\n\n"
        "This ensures every session starts with full project awareness. "
        "Without this step, you are working blind on a project with established architecture decisions."
    )

    if Prompt is not None and GetPromptResult is not None:
        @server.list_prompts()
        async def list_prompts() -> list:
            return [Prompt(
                name="on_session_start",
                description=(
                    "Auto-bootstrap: calls get_context() + get_pending() at session start. "
                    "Load this prompt to ensure full project memory awareness before any work."
                ),
                arguments=[],
            )]

        @server.get_prompt()
        async def get_prompt(name: str, arguments: dict) -> object:
            return GetPromptResult(
                description="collab-memory session bootstrap",
                messages=[PromptMessage(
                    role="user",
                    content=TextContent(type="text", text=_BOOTSTRAP_TEXT),
                )],
            )

    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, server.create_initialization_options())


def main():
    parser = argparse.ArgumentParser(description="collab-memory MCP Server")
    parser.add_argument("--url", default=None, help="collab-memory API base URL")
    args = parser.parse_args()

    if args.url:
        global BASE_URL
        BASE_URL = args.url.rstrip("/")

    asyncio.run(run_stdio())


if __name__ == "__main__":
    main()
