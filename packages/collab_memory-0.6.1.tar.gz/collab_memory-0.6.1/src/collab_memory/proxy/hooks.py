"""
collab_memory/proxy/hooks.py — Memory Injection & Capture Hooks

Ported from cognitive-proxy/app/routers/proxy.py into collab-memory
for single-service proxy consolidation.

Responsibility:
    inject_memory()   — Prepend graph context to the system message
    capture_response() — Ingest assistant reply into memory graph
    estimate_tokens()  — Rough token count for budget enforcement

Design:
    - inject_memory() fetches context from the graph backend directly
      (no HTTP round-trip — same process has access to the graph)
    - capture_response() calls the ingest pipeline directly
    - Both are no-ops if no graph backend is available
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)

# ── Injection templates ──────────────────────────────────────────────────────

MEMORY_INJECTION_HEADER = (
    "\n\n---\n"
    "## COGNITIVE MEMORY CONTEXT\n"
    "The following protocols, decisions, and constraints are loaded from the "
    "persistent memory bank. You MUST follow these at all times:\n\n"
)
MEMORY_INJECTION_FOOTER = "\n---\n"


def inject_memory_into_messages(
    messages: list[dict[str, Any]],
    memory_context: str,
) -> list[dict[str, Any]]:
    """Prepend memory context to the system message.

    If no system message exists, creates one.
    Returns a new list (does not mutate input).
    """
    if not memory_context or not memory_context.strip():
        return messages

    injected_block = (
        MEMORY_INJECTION_HEADER
        + memory_context.strip()
        + MEMORY_INJECTION_FOOTER
    )
    messages = list(messages)

    for i, msg in enumerate(messages):
        if msg.get("role") == "system":
            existing = msg.get("content", "")
            if not isinstance(existing, str):
                existing = str(existing)
            # Prepend memory so high-priority constraints appear first.
            messages[i] = {**msg, "content": injected_block + existing}
            return messages

    # No system message — create one
    messages.insert(
        0,
        {
            "role": "system",
            "content": (
                "You are a helpful AI assistant operating within the "
                "collab-memory cognitive framework."
                + injected_block
            ),
        },
    )
    return messages


def extract_user_message(messages: list[dict[str, Any]]) -> str:
    """Extract the last user message for ingestion."""
    for msg in reversed(messages):
        if msg.get("role") == "user":
            content = msg.get("content", "")
            if isinstance(content, list):
                return " ".join(
                    c.get("text", "") for c in content if isinstance(c, dict)
                )
            return str(content)
    return ""


def estimate_tokens(text: str) -> int:
    """Rough token estimate: ~4 chars per token."""
    return max(1, len(text) // 4)


async def fetch_context_from_graph(
    graph,
    project_id: str | None = None,
    confidence_min: float = 0.0,
) -> str:
    """Build a text context brief from the graph backend.

    Returns formatted text suitable for injection into the system message.
    This runs in-process (no HTTP round-trip to the memory API).
    """
    if graph is None:
        return ""

    try:
        brief = graph.build_context_brief(
            project_id=project_id,
            confidence_min=confidence_min,
        )
    except Exception as e:
        logger.warning(f"fetch_context_from_graph failed: {e}")
        return ""

    if not brief:
        return ""

    # Format the brief into text
    lines = []

    decisions = brief.get("active_decisions", [])
    if decisions:
        lines.append("### Active Decisions")
        for d in decisions:
            conf = d.get("confidence", 0)
            lines.append(f"- [{int(conf * 100)}%] {d.get('description', '')}")
            if d.get("rationale"):
                lines.append(f"  > {d['rationale'][:120]}")

    constraints = brief.get("active_constraints", [])
    if constraints:
        lines.append("\n### Active Constraints")
        for c in constraints:
            lines.append(f"- [{c.get('origin', 'explicit')}] {c.get('description', '')}")

    preferences = brief.get("inferred_preferences", [])
    if preferences:
        lines.append("\n### Inferred Preferences")
        for p in preferences:
            lines.append(f"- {p.get('description', '')}")

    return "\n".join(lines)


async def capture_response_to_graph(
    graph,
    user_message: str,
    assistant_response: str,
    session_id: str = "proxy-session",
    project_id: str | None = None,
) -> None:
    """Ingest a user→assistant exchange into the memory graph.

    Uses encode_exchange for classification, then writes noteworthy results
    to the graph via save_exchange_record() + save_node().
    Non-blocking — errors are logged but don't affect the response.
    """
    if graph is None or not user_message:
        return

    try:
        import time
        from collab_memory.encoder import encode_exchange

        raw_text = f"User: {user_message}\nAssistant: {assistant_response}"
        result = encode_exchange(
            raw_text=raw_text,
            session_id=session_id,
            turn_start=int(time.time()),
            skip_llm=False,
        )

        # Sprint 20.5: propagate project_id to exchange record
        if project_id and hasattr(result.exchange_record, "project_id"):
            result.exchange_record.project_id = project_id

        # Always save the exchange record for audit trail
        if hasattr(graph, "save_exchange_record"):
            graph.save_exchange_record(result.exchange_record)

        # Write high-signal nodes to graph
        if result.should_encode:
            for node in result.nodes:
                if hasattr(node, "project_id") and project_id:
                    node.project_id = project_id
                graph.save_node(node)
            for edge in result.edges:
                graph.save_edge(edge)

        logger.info(
            "capture_response: type=%s score=%.2f encoded=%s nodes=%d",
            result.exchange_record.primitive_type.value,
            result.exchange_record.worthiness_score,
            result.should_encode,
            len(result.nodes),
        )
    except Exception as e:
        logger.warning("capture_response failed (non-fatal): %s", e)


