"""
collab_memory/proxy/config.py — Proxy Configuration

Centralized config for the LLM proxy layer:
- Provider routing (model → provider mapping)
- Token budgets for context injection (Phase 3)
- Supported models and their metadata
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


# ── Provider definitions ─────────────────────────────────────────────────────

PROVIDER_MAP = {
    # OpenAI
    "gpt-4": "openai",
    "gpt-4o": "openai",
    "gpt-4o-mini": "openai",
    "gpt-4-turbo": "openai",
    "gpt-3.5-turbo": "openai",
    "o1": "openai",
    "o1-mini": "openai",
    "o1-preview": "openai",
    "o3-mini": "openai",

    # Anthropic
    "claude-3-opus": "anthropic",
    "claude-3-sonnet": "anthropic",
    "claude-3-haiku": "anthropic",
    "claude-3.5-sonnet": "anthropic",
    "claude-3.5-haiku": "anthropic",
    "claude-haiku-4-5": "anthropic",
    "claude-sonnet-4-5": "anthropic",

    # Google
    "gemini-pro": "gemini",
    "gemini-1.5-pro": "gemini",
    "gemini-1.5-flash": "gemini",
    "gemini-2.0-flash": "gemini",
    "gemini-2.5-pro": "gemini",
    "gemini-2.5-flash": "gemini",

    # Groq
    "llama-3.3-70b-versatile": "groq",
    "llama-3.1-8b-instant": "groq",
    "mixtral-8x7b-32768": "groq",

    # Mistral
    "mistral-large-latest": "mistral",
    "mistral-small-latest": "mistral",
}


def resolve_provider(model: str) -> str:
    """Resolve provider from model name.

    Falls back to prefix detection for models not in the map.
    """
    if model in PROVIDER_MAP:
        return PROVIDER_MAP[model]

    # Prefix-based fallback
    if model.startswith("gpt-") or model.startswith("o1") or model.startswith("o3"):
        return "openai"
    if model.startswith("claude"):
        return "anthropic"
    if model.startswith("gemini"):
        return "gemini"
    if model.startswith("llama") or model.startswith("mixtral"):
        return "groq"
    if model.startswith("mistral"):
        return "mistral"

    return "openai"  # Default assumption


# ── Token budgets ────────────────────────────────────────────────────────────

@dataclass
class ProxyConfig:
    """Configuration for the proxy layer.

    Token budgets determine how much of the context window
    is reserved for injected context (Phase 3).
    """

    # Max tokens to use for injected context (Phase 3)
    injection_budget: int = 2000

    # Max tokens to reserve for the model's response
    response_budget: int = 4096

    # Template for context injection XML block (Phase 3)
    injection_template: str = """<collab_context project="{project_id}">
{decisions}
{constraints}
{recent_history}
</collab_context>"""

    # Whether auto-capture is enabled (Phase 4)
    capture_enabled: bool = False

    # Provider-specific API base URLs (for LiteLLM routing)
    api_bases: dict = field(default_factory=lambda: {
        "openai": "https://api.openai.com/v1",
        "anthropic": "https://api.anthropic.com/v1",
        "gemini": "https://generativelanguage.googleapis.com/v1beta",
        "groq": "https://api.groq.com/openai/v1",
        "mistral": "https://api.mistral.ai/v1",
    })
