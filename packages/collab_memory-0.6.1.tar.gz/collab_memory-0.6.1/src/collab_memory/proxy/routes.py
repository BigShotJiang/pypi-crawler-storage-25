"""
collab_memory/proxy/routes.py — LLM Proxy Endpoints

OpenAI-compatible API endpoints that transparently forward
requests to the user's chosen LLM provider.

Flow:
    1. Request arrives at /v1/chat/completions
    2. JWT auth → resolve user + tenant
    3. Decrypt user's LLM API key from vault
    4. Forward request to provider (OpenAI, Anthropic, etc.)
    5. Return response (streaming or non-streaming)

Phase 2: Transparent pipe (no injection/capture)
Phase 3: Adds context injection via hooks.py
Phase 4: Adds auto-capture via capture.py
"""

from __future__ import annotations

import os
import json
import logging
import time
import asyncio
import httpx
from typing import Optional

from fastapi import APIRouter, HTTPException, Depends, Request
from fastapi.responses import StreamingResponse, JSONResponse
from pydantic import BaseModel, ConfigDict, Field

from collab_memory.auth.middleware import require_jwt, jwt_or_apikey_auth
from collab_memory.auth.jwt_provider import AuthUser
from collab_memory.auth.vault import LLMKeyVault
from collab_memory.proxy.config import resolve_provider, ProxyConfig, PROVIDER_MAP
from collab_memory.proxy.hooks import (
    inject_memory_into_messages,
    extract_user_message,
    fetch_context_from_graph,
    capture_response_to_graph,
    estimate_tokens,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/v1", tags=["proxy"])

# Module-level singletons
_vault: Optional[LLMKeyVault] = None
_config: Optional[ProxyConfig] = None
_http_client: Optional[httpx.AsyncClient] = None
_graph_backend = None  # Set by app startup via set_graph_backend()


def get_vault() -> LLMKeyVault:
    global _vault
    if _vault is None:
        _vault = LLMKeyVault()
    return _vault


def get_config() -> ProxyConfig:
    global _config
    if _config is None:
        _config = ProxyConfig()
    return _config


def get_http_client() -> httpx.AsyncClient:
    global _http_client
    if _http_client is None:
        _http_client = httpx.AsyncClient(timeout=120.0)
    return _http_client


def set_graph_backend(graph) -> None:
    """Wire graph backend for memory injection (called at app startup)."""
    global _graph_backend
    _graph_backend = graph
    logger.info("Proxy graph backend wired for memory injection")


# ── Request/Response Models ──────────────────────────────────────────────────

class ChatMessage(BaseModel):
    role: str
    content: str | list | None = None
    name: Optional[str] = None

class ChatCompletionRequest(BaseModel):
    model: str
    messages: list[ChatMessage]
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    top_p: Optional[float] = None
    stream: Optional[bool] = False
    stop: Optional[str | list[str]] = None
    presence_penalty: Optional[float] = None
    frequency_penalty: Optional[float] = None
    user: Optional[str] = None

    # Pass-through: any extra fields forwarded to provider
    model_config = ConfigDict(extra="allow")


# ── Provider Adapters ────────────────────────────────────────────────────────

def _build_openai_headers(api_key: str) -> dict:
    return {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }


def _build_anthropic_headers(api_key: str) -> dict:
    return {
        "x-api-key": api_key,
        "anthropic-version": "2023-06-01",
        "Content-Type": "application/json",
    }


def _build_anthropic_body(req: ChatCompletionRequest) -> dict:
    """Convert OpenAI format to Anthropic Messages API format."""
    system_msg = None
    messages = []

    for msg in req.messages:
        if msg.role == "system":
            system_msg = msg.content if isinstance(msg.content, str) else str(msg.content)
        else:
            messages.append({
                "role": msg.role,
                "content": msg.content if isinstance(msg.content, str) else str(msg.content),
            })

    body = {
        "model": req.model,
        "messages": messages,
        "max_tokens": req.max_tokens or 4096,
    }

    if system_msg:
        body["system"] = system_msg
    if req.temperature is not None:
        body["temperature"] = req.temperature
    if req.top_p is not None:
        body["top_p"] = req.top_p
    if req.stream:
        body["stream"] = True

    return body


def _anthropic_to_openai_response(anthropic_resp: dict, model: str) -> dict:
    """Convert Anthropic response to OpenAI format."""
    content = ""
    if anthropic_resp.get("content"):
        for block in anthropic_resp["content"]:
            if block.get("type") == "text":
                content += block.get("text", "")

    return {
        "id": anthropic_resp.get("id", "chatcmpl-collab"),
        "object": "chat.completion",
        "created": int(time.time()),
        "model": model,
        "choices": [{
            "index": 0,
            "message": {
                "role": "assistant",
                "content": content,
            },
            "finish_reason": _map_anthropic_stop(anthropic_resp.get("stop_reason", "end_turn")),
        }],
        "usage": {
            "prompt_tokens": anthropic_resp.get("usage", {}).get("input_tokens", 0),
            "completion_tokens": anthropic_resp.get("usage", {}).get("output_tokens", 0),
            "total_tokens": (
                anthropic_resp.get("usage", {}).get("input_tokens", 0) +
                anthropic_resp.get("usage", {}).get("output_tokens", 0)
            ),
        },
    }


def _map_anthropic_stop(stop_reason: str) -> str:
    return {
        "end_turn": "stop",
        "max_tokens": "length",
        "stop_sequence": "stop",
    }.get(stop_reason, "stop")


# ── Endpoints ────────────────────────────────────────────────────────────────

@router.post("/chat/completions", summary="Proxy LLM chat completion")
async def chat_completions(
    req: ChatCompletionRequest,
    request: Request,
    user: AuthUser = Depends(require_jwt),
):
    """OpenAI-compatible chat completions endpoint.

    Resolves the user's encrypted API key from the vault,
    forwards the request to the appropriate provider,
    and returns the response in OpenAI format.

    Supports: OpenAI, Anthropic, Gemini, Groq, Mistral
    """
    provider = resolve_provider(req.model)
    vault = get_vault()
    config = get_config()
    client = get_http_client()

    # === Step 1: Resolve API key ===
    api_key = _resolve_api_key(user, provider, vault)

    if not api_key:
        raise HTTPException(
            status_code=400,
            detail={
                "error": f"No {provider} API key found for your account.",
                "hint": f"Store your key via POST /auth/keys with provider='{provider}'",
                "provider": provider,
                "model": req.model,
            },
        )

    # === Step 1.5: Memory injection (Phase 3) ===
    memory_context = ""
    if _graph_backend:
        try:
            memory_context = await fetch_context_from_graph(
                _graph_backend,
                project_id=getattr(user, 'tenant_id', None),
            )
            if memory_context:
                logger.info(
                    f"Injecting {estimate_tokens(memory_context)} tokens "
                    f"of memory context for {user.email}"
                )
        except Exception as e:
            logger.warning(f"Memory injection fetch failed: {e}")

    enriched_messages = inject_memory_into_messages(
        [m.model_dump(exclude_none=True) for m in req.messages],
        memory_context,
    )
    user_message = extract_user_message(
        [m.model_dump(exclude_none=True) for m in req.messages]
    )


    session_id = f"proxy-{user.email or 'anon'}"
    capture_project_id = getattr(user, "tenant_id", None)

    # === Step 2: Forward to provider ===
    try:
        if provider == "anthropic":
            headers = _build_anthropic_headers(api_key)
            body = _build_anthropic_body(req)
            url = "https://api.anthropic.com/v1/messages"

            if req.stream:
                on_complete = None
                if _graph_backend and user_message:
                    async def _capture_after_stream(assistant_text: str):
                        await capture_response_to_graph(
                            _graph_backend,
                            user_message,
                            assistant_text,
                            session_id=session_id,
                            project_id=capture_project_id,
                        )
                    on_complete = _capture_after_stream
                return await _stream_anthropic(client, url, headers, body, req.model, on_complete=on_complete)
            else:
                resp = await client.post(url, json=body, headers=headers)
                resp.raise_for_status()
                openai_resp = _anthropic_to_openai_response(resp.json(), req.model)
                # Capture to graph (non-blocking)
                if _graph_backend and user_message:
                    assistant_text = openai_resp.get("choices", [{}])[0].get("message", {}).get("content", "")
                    asyncio.create_task(capture_response_to_graph(
                        _graph_backend, user_message, assistant_text,
                        session_id=session_id,
                        project_id=capture_project_id,
                    ))
                return openai_resp

        else:
            # OpenAI-compatible providers (OpenAI, Groq, Mistral, Gemini via LiteLLM)
            headers = _build_openai_headers(api_key)
            body = req.model_dump(exclude_none=True)
            body["messages"] = enriched_messages  # Use injected messages
            base_url = config.api_bases.get(provider, config.api_bases["openai"])
            url = f"{base_url}/chat/completions"

            if req.stream:
                on_complete = None
                if _graph_backend and user_message:
                    async def _capture_after_stream(assistant_text: str):
                        await capture_response_to_graph(
                            _graph_backend,
                            user_message,
                            assistant_text,
                            session_id=session_id,
                            project_id=capture_project_id,
                        )
                    on_complete = _capture_after_stream
                return await _stream_openai(client, url, headers, body, on_complete=on_complete)
            else:
                resp = await client.post(url, json=body, headers=headers)
                resp.raise_for_status()
                openai_resp = resp.json()
                # Capture to graph (non-blocking)
                if _graph_backend and user_message:
                    assistant_text = openai_resp.get("choices", [{}])[0].get("message", {}).get("content", "")
                    asyncio.create_task(capture_response_to_graph(
                        _graph_backend, user_message, assistant_text,
                        session_id=session_id,
                        project_id=capture_project_id,
                    ))
                return openai_resp

    except httpx.HTTPStatusError as e:
        logger.error(f"Provider error ({provider}): {e.response.status_code} {e.response.text[:200]}")
        raise HTTPException(
            status_code=e.response.status_code,
            detail={
                "error": "Provider returned an error",
                "provider": provider,
                "status": e.response.status_code,
                "message": e.response.text[:500],
            },
        )
    except httpx.RequestError as e:
        logger.error(f"Network error ({provider}): {e}")
        raise HTTPException(
            status_code=502,
            detail={
                "error": "Failed to reach provider",
                "provider": provider,
                "message": str(e),
            },
        )


@router.get("/models", summary="List available models")
async def list_models():
    """List models supported by the proxy.

    Returns OpenAI-compatible model list format.
    """
    models = []
    for model_id, provider in PROVIDER_MAP.items():
        models.append({
            "id": model_id,
            "object": "model",
            "created": 1700000000,
            "owned_by": provider,
        })

    return {
        "object": "list",
        "data": sorted(models, key=lambda m: m["id"]),
    }


# ── Internal Helpers ─────────────────────────────────────────────────────────

def _resolve_api_key(user: AuthUser, provider: str, vault: LLMKeyVault) -> Optional[str]:
    """Resolve API key for a provider.

    Priority:
    1. User tenant's encrypted key from graph LLMKey node (decrypted by vault)
    2. Environment variable fallback (OPENAI_API_KEY, ANTHROPIC_API_KEY, etc.)
    """
    # Tenant-scoped vault lookup (runtime path).
    if _graph_backend and hasattr(_graph_backend, "_tx_read"):
        try:
            rows = _graph_backend._tx_read(
                "MATCH (k:LLMKey {tenant_id: $tid, provider: $provider}) "
                "RETURN k.encrypted_key AS encrypted_key "
                "ORDER BY k.updated_at DESC LIMIT 1",
                tid=user.tenant_id,
                provider=provider,
            )
            if rows:
                encrypted = rows[0].get("encrypted_key")
                if encrypted:
                    try:
                        return vault.decrypt(encrypted)
                    except Exception as dec_err:
                        logger.warning(
                            "Failed to decrypt stored %s key for tenant %s: %s",
                            provider, user.tenant_id, dec_err,
                        )
        except Exception as e:
            logger.warning(
                "LLMKey lookup failed for tenant=%s provider=%s: %s",
                user.tenant_id, provider, e,
            )

    # Env var fallback (dev mode / legacy)
    env_map = {
        "openai": "OPENAI_API_KEY",
        "anthropic": "ANTHROPIC_API_KEY",
        "gemini": "GOOGLE_API_KEY",
        "groq": "GROQ_API_KEY",
        "mistral": "MISTRAL_API_KEY",
    }

    env_var = env_map.get(provider, "")
    key = os.environ.get(env_var, "")
    if key:
        logger.debug(f"Using env var {env_var} for {provider} (dev mode)")
    return key or None


async def _stream_openai(
    client: httpx.AsyncClient,
    url: str,
    headers: dict,
    body: dict,
    on_complete=None,
):
    """Stream SSE response from OpenAI-compatible provider."""
    async def event_generator():
        chunks: list[str] = []
        async with client.stream("POST", url, json=body, headers=headers) as resp:
            resp.raise_for_status()
            async for line in resp.aiter_lines():
                if line:
                    text = _extract_openai_delta_text(line)
                    if text:
                        chunks.append(text)
                    yield f"{line}\n\n"
        if on_complete:
            try:
                await on_complete("".join(chunks))
            except Exception as e:
                logger.warning("Stream capture callback failed (openai-compatible): %s", e)

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


async def _stream_anthropic(
    client: httpx.AsyncClient,
    url: str,
    headers: dict,
    body: dict,
    model: str,
    on_complete=None,
):
    """Stream SSE response from Anthropic, converting to OpenAI SSE format."""
    async def event_generator():
        chunks: list[str] = []
        async with client.stream("POST", url, json=body, headers=headers) as resp:
            resp.raise_for_status()
            async for line in resp.aiter_lines():
                if line.startswith("data: "):
                    data = line[6:]
                    if data == "[DONE]":
                        yield "data: [DONE]\n\n"
                    else:
                        text = _extract_anthropic_delta_text(data)
                        if text:
                            chunks.append(text)
                        # Pass through Anthropic SSE events
                        # Phase 3 hook will intercept for capture
                        yield f"data: {data}\n\n"
        if on_complete:
            try:
                await on_complete("".join(chunks))
            except Exception as e:
                logger.warning("Stream capture callback failed (anthropic): %s", e)

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


def _extract_openai_delta_text(line: str) -> str:
    """Extract text deltas from OpenAI-compatible SSE line."""
    if not line.startswith("data: "):
        return ""
    data = line[6:]
    if data == "[DONE]":
        return ""
    try:
        payload = json.loads(data)
    except Exception:
        return ""
    out = []
    for choice in payload.get("choices", []):
        delta = choice.get("delta", {})
        text = delta.get("content")
        if isinstance(text, str):
            out.append(text)
    return "".join(out)


def _extract_anthropic_delta_text(data: str) -> str:
    """Extract text deltas from Anthropic streaming event payload."""
    try:
        payload = json.loads(data)
    except Exception:
        return ""
    if payload.get("type") == "content_block_delta":
        delta = payload.get("delta", {})
        text = delta.get("text")
        if isinstance(text, str):
            return text
    return ""
