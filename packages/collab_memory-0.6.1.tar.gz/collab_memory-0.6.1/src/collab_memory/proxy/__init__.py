"""
collab_memory/proxy — LLM Proxy Layer

Transparent, authenticated proxy for LLM API requests.
Provides OpenAI-compatible endpoints that decrypt user keys
from the vault and forward requests to the actual provider.

Modules:
    config  — Token budgets, injection templates, provider maps
    routes  — /v1/chat/completions, /v1/models endpoints
    hooks   — LiteLLM CustomLogger hooks (Phase 3: context injection)
"""

from collab_memory.proxy.config import ProxyConfig

__all__ = ["ProxyConfig"]
