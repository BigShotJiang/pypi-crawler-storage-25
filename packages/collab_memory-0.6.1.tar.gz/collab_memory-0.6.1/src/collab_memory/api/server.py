"""
api/server.py — FastAPI query interface + cognitive-dash dashboard.

Endpoints:
  GET /                   — cognitive-dash dashboard UI
  GET /memory/context     — context brief for a new session
  GET /memory/stats       — dashboard stats summary
  GET /memory/why         — decision archaeology
  GET /memory/preferences — filtered preference query
  GET /memory/decisions   — list active decisions
  GET /memory/constraints — list active constraints
  POST /memory/ingest     — encode and store a raw exchange
"""

from __future__ import annotations
import asyncio
import base64
import os
import json
from contextlib import asynccontextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Optional, Union
from fastapi import BackgroundTasks, Depends, FastAPI, File, HTTPException, Query, Request, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse, Response, StreamingResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, Field, field_validator
from dotenv import load_dotenv

load_dotenv()

from ..graph.local import LocalGraphBackend
from ..encoder import encode_exchange

# Pipeline is lazy-loaded on first request to save ~50MB of startup memory.
# (Avoids importing LangGraph + all agents at server boot time.)
_PIPELINE_AVAILABLE = None  # None = not yet determined
run_pipeline = None
_get_pipeline_status = None


def _ensure_pipeline():
    """Import and cache the pipeline on first use."""
    global _PIPELINE_AVAILABLE, run_pipeline, _get_pipeline_status
    if _PIPELINE_AVAILABLE is None:
        try:
            from ..agents.pipeline import run_pipeline as _rp, get_pipeline_status as _gps
            run_pipeline = _rp
            _get_pipeline_status = _gps
            _PIPELINE_AVAILABLE = True
        except Exception as e:
            print(f"[collab-memory] Pipeline unavailable: {e}")
            _PIPELINE_AVAILABLE = False
    return _PIPELINE_AVAILABLE

# ─── Setup ────────────────────────────────────────────────────────────────────

_HERE = Path(__file__).parent
_TEMPLATES_DIR = _HERE / "templates"
_STATIC_DIR = _HERE / "static"
_TEMPLATES_DIR.mkdir(exist_ok=True)
_STATIC_DIR.mkdir(exist_ok=True)

_cve_watcher_task: asyncio.Task | None = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Start background workers on startup, cancel on shutdown."""
    global _cve_watcher_task

    # ── Security posture check ───────────────────────────────────────────
    # Warn loudly on startup if critical security env vars are missing.
    # In production, this prevents clients from running an insecure instance.
    _missing = []
    if not os.environ.get("COLLAB_API_KEY", "").strip():
        _missing.append("COLLAB_API_KEY")
    if not os.environ.get("JWT_SECRET", "").strip():
        _missing.append("JWT_SECRET")
    if _IS_PRODUCTION and _missing:
        print(
            f"\n{'='*60}\n"
            f"  ⚠ SECURITY WARNING — PRODUCTION MODE\n"
            f"  Missing: {', '.join(_missing)}\n"
            f"  Write operations and auth are DISABLED until these are set.\n"
            f"  Docs: {os.environ.get('COLLAB_PUBLIC_URL', 'https://ohaco.com')}/docs/setup\n"
            f"{'='*60}\n"
        )
    elif _missing:
        print(f"[collab-memory] Dev mode — bypasses active (missing: {', '.join(_missing)})")

    # ── Email configuration posture check ────────────────────────────────
    # Email is required for production onboarding/auth UX (verify/reset/invites).
    try:
        from ..auth.email import email_config_status as _email_config_status

        _mail = _email_config_status()
        if _mail.get("delivery_enabled"):
            print("[collab-memory] Email delivery configured")
        else:
            reason = _mail.get("reason", "unknown")
            if _IS_PRODUCTION:
                print(
                    f"\n{'='*60}\n"
                    f"  ⚠ EMAIL WARNING — DELIVERY DISABLED\n"
                    f"  Reason: {reason}\n"
                    f"  Set RESEND_API_KEY (+ FROM_EMAIL) via vault/env.\n"
                    f"{'='*60}\n"
                )
            else:
                print(f"[collab-memory] Email delivery disabled ({reason})")
    except Exception as e:
        print(f"[collab-memory] Email status check failed: {e}")

    # CVE watcher — only start if graph backend is Neo4j (has save_skill)
    if os.environ.get("CVE_WATCHER_ENABLED", "true").lower() != "false":
        try:
            from ..workers.cve_watcher import CVEWatcher
            from ..graph.neo4j_backend import Neo4jBackend
            _graph = Neo4jBackend()
            watcher = CVEWatcher(_graph)
            _cve_watcher_task = asyncio.create_task(watcher.run())
            app.state.cve_watcher = watcher
        except Exception as e:
            import logging
            logging.getLogger(__name__).warning("CVE watcher not started: %s", e)
            app.state.cve_watcher = None
    yield
    if _cve_watcher_task and not _cve_watcher_task.done():
        _cve_watcher_task.cancel()


from .._version import __version__ as _VERSION

# Deploy platforms often inject commit SHA — used for user-facing “variation receipts”.
_GIT_SHA = (
    os.environ.get("RENDER_GIT_COMMIT", "").strip()
    or os.environ.get("SOURCE_VERSION", "").strip()
    or os.environ.get("COLLAB_GIT_SHA", "").strip()
    or os.environ.get("GIT_COMMIT", "").strip()
)

app = FastAPI(
    title="Semantic Dreams by OHACO Labs",
    description="Semantic working memory layer for human+agent collaboration.",
    version=_VERSION,
    lifespan=lifespan,
)

# ── Rate Limit Middleware ────────────────────────────────────────────────────
# slowapi (Session 26 research decision) — in-memory Phase 1, Redis Phase 2.
# Wires: limiter state + SlowAPIMiddleware + 429 handler + payload cap (1MB).
# Config via env: RATE_LIMIT_ENABLED, RATE_LIMIT_MEMORY, RATE_LIMIT_OPS,
#                 RATE_LIMIT_PROXY, RATE_LIMIT_DEFAULT, RATE_LIMIT_MAX_BODY_MB
try:
    from ..rate_limit import apply_rate_limits
    apply_rate_limits(app)
except Exception as _rl_err:
    print(f"[collab-memory] Rate limiting not loaded: {_rl_err}")

# ── CORS Middleware ──────────────────────────────────────────────────────────
# Restrictive by default. Only allow the Render deployment origin + localhost for dev.
# Additional origins can be added via CORS_ALLOWED_ORIGINS env var (comma-separated).
_CORS_ORIGINS = [
    "https://collab-memory.onrender.com",
    "https://ohaco-command-center.onrender.com",
    "https://cognitive-proxy.onrender.com",
    "https://cognitive-proxy-5yyh.onrender.com",
    "https://ohaco.org",
    "https://www.ohaco.org",
    "https://ohaco-site.onrender.com",
    "http://localhost:8000",
    "http://localhost:3000",
    "http://127.0.0.1:8000",
    "chrome-extension://",  # browser extension — memory capture from AI tools
]
_extra_origins = os.environ.get("CORS_ALLOWED_ORIGINS", "").strip()
if _extra_origins:
    _CORS_ORIGINS.extend([o.strip() for o in _extra_origins.split(",") if o.strip()])

app.add_middleware(GZipMiddleware, minimum_size=1024)
app.add_middleware(
    CORSMiddleware,
    allow_origins=_CORS_ORIGINS,
    allow_origin_regex=r"https://.*\.manus\.space",
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"],
    allow_headers=["X-API-Key", "Authorization", "Content-Type"],
)
# SessionMiddleware — required by Authlib for OAuth state storage
from starlette.middleware.sessions import SessionMiddleware
app.add_middleware(SessionMiddleware, secret_key=os.getenv("JWT_SECRET", "dev-session-secret"))

app.mount("/static", StaticFiles(directory=str(_STATIC_DIR)), name="static")
templates = Jinja2Templates(directory=str(_TEMPLATES_DIR))

_BACKEND = os.environ.get("GRAPH_BACKEND", "local").lower()
active_backend = _BACKEND  # exposed to /setup/status endpoint

def _local_fallback(reason: str = ""):
    if reason:
        print(f"[collab-memory] WARNING: {reason}\n  Falling back to local JSON backend.")
    return LocalGraphBackend(
        path=os.environ.get("LOCAL_GRAPH_PATH", "./data/graph.json")
    )

if _BACKEND == "neo4j":
    try:
        from ..graph.neo4j_backend import Neo4jBackend
        graph = Neo4jBackend(
            uri=os.environ.get("NEO4J_URI", "bolt://localhost:7687"),
            user=os.environ.get("NEO4J_USER", "neo4j"),
            password=os.environ.get("NEO4J_PASSWORD", "password"),
            database=os.environ.get("NEO4J_DATABASE", "neo4j"),
        )
        print(f"[collab-memory] Backend: Neo4j ({os.environ.get('NEO4J_URI', 'bolt://localhost:7687')})")
        active_backend = "neo4j"

        # ── One-time attribution cleanup ──────────────────────────────────────
        # Removes any nodes with inaccurate 'Antigravity/DeepMind' attribution.
        # Safe to run every startup: MERGE is idempotent, MATCH/DELETE is no-op
        # after first run. This will self-resolve on next Render deploy.
        try:
            with graph._driver.session(database=graph._db) as _s:
                bad = list(_s.run(
                    "MATCH (n) WHERE n.description CONTAINS 'Antigravity' "
                    "OR n.description CONTAINS 'DeepMind' RETURN count(n) as c"
                ))
                if bad and bad[0]["c"] > 0:
                    _s.run(
                        "MATCH (n) WHERE n.description CONTAINS 'Antigravity' "
                        "OR n.description CONTAINS 'DeepMind' DETACH DELETE n"
                    )
                    _s.run(
                        "MERGE (d:Decision {id: 'dec_attribution_v3'}) "
                        "SET d.description = 'collab-memory is an open-source project built by Esther Anglade (OHACO Labs). MIT License.', "
                        "d.confidence = 1.0, d.origin = 'explicit', d.status = 'active', "
                        "d.node_type = 'Decision', d.session_id = 'attribution_fix'"
                    )
                    print("[collab-memory] Attribution nodes cleaned up.")
        except Exception as _e:
            print(f"[collab-memory] Attribution cleanup skipped: {_e}")
        # ─────────────────────────────────────────────────────────────────────
    except ImportError:
        graph = _local_fallback("GRAPH_BACKEND=neo4j but 'neo4j' package not installed. Run: pip install neo4j")
        active_backend = "local"
    except Exception as e:
        graph = _local_fallback(f"Neo4j connection failed: {e}. Check NEO4J_URI / NEO4J_PASSWORD.")
        active_backend = "local"

elif _BACKEND in ("graphiti", "falkordb"):
    try:
        from ..graph.graphiti_backend import GraphitiBackend
        _neo4j_uri = os.environ.get("NEO4J_URI") if _BACKEND == "graphiti" else None
        _falkordb = os.environ.get("FALKORDB_URL", "redis://localhost:6379")
        graph = GraphitiBackend(
            uri=_falkordb,
            neo4j_uri=_neo4j_uri,
            neo4j_user=os.environ.get("NEO4J_USER", "neo4j"),
            neo4j_password=os.environ.get("NEO4J_PASSWORD", "password"),
        )
        label = "Graphiti+Neo4j" if _neo4j_uri else "Graphiti+FalkorDB"
        print(f"[collab-memory] Backend: {label}")
        active_backend = _BACKEND
    except ImportError:
        graph = _local_fallback("GRAPH_BACKEND=graphiti but graphiti-core not installed. Run: pip install 'collab-memory[graphiti]'")
        active_backend = "local"
    except Exception as e:
        graph = _local_fallback(f"Graphiti/FalkorDB backend failed: {e}. Is FalkorDB running? Try: docker compose up -d")
        active_backend = "local"

else:
    graph = LocalGraphBackend(
        path=os.environ.get("LOCAL_GRAPH_PATH", "./data/graph.json")
    )

print(f"[collab-memory] Active backend: {active_backend}")

# ─── Neo4j Poll Watcher ──────────────────────────────────────────────────────
# Replaces the file-based SessionWatcher for deployed environments.
# Polls Neo4j for unprocessed ExchangeRecord nodes and runs them through
# the pipeline. Auto-triggers Episode consolidation after idle period.

_poll_watcher = None
_WATCHER_ENABLED = os.environ.get("POLL_WATCHER_ENABLED", "false").lower() in ("true", "1", "yes")
_WATCHER_INTERVAL = float(os.environ.get("POLL_WATCHER_INTERVAL", "30"))
_WATCHER_BATCH = int(os.environ.get("POLL_WATCHER_BATCH", "10"))
_WATCHER_IDLE = float(os.environ.get("POLL_WATCHER_IDLE_CONSOLIDATE", "600"))

if active_backend == "neo4j" and _WATCHER_ENABLED:
    try:
        from ..neo4j_poll_watcher import Neo4jPollWatcher
        _poll_watcher = Neo4jPollWatcher(
            graph=graph,
            poll_interval=_WATCHER_INTERVAL,
            batch_size=_WATCHER_BATCH,
            idle_consolidate_after=_WATCHER_IDLE,
            enabled=True,
        )
        _poll_watcher.start()
        print(f"[collab-memory] Neo4j poll watcher started (interval={_WATCHER_INTERVAL}s, batch={_WATCHER_BATCH})")
    except Exception as e:
        print(f"[collab-memory] Poll watcher failed to start: {e}")
else:
    if not _WATCHER_ENABLED:
        print("[collab-memory] Poll watcher disabled via POLL_WATCHER_ENABLED=false")
    elif active_backend != "neo4j":
        print(f"[collab-memory] Poll watcher skipped (backend={active_backend}, requires neo4j)")

# ─── In-Memory Log Ring Buffer ─────────────────────────────────────────────────
# Captures the last 500 log records from all loggers for the /ops/logs endpoint.
# This lets the dashboard show why things are down without needing Render access.

import logging as _logging
import threading as _threading
import time as _time_mod
from collections import deque as _deque
from datetime import datetime as _datetime

_LOG_BUFFER: _deque = _deque(maxlen=500)

# ── Context brief TTL cache ─────────────────────────────────────────────────
# Avoids re-querying Neo4j for identical context requests within 60 seconds.
# Invalidated automatically by TTL; also cleared on ingest/record writes.
_CONTEXT_CACHE: dict[str, tuple[dict, float]] = {}
_CONTEXT_CACHE_TTL = 60  # seconds
_CONTEXT_CACHE_LOCK = _threading.Lock()


def _context_cache_get(cache_key: str) -> dict | None:
    with _CONTEXT_CACHE_LOCK:
        entry = _CONTEXT_CACHE.get(cache_key)
        if entry and (_time_mod.monotonic() - entry[1]) < _CONTEXT_CACHE_TTL:
            return entry[0]
        if entry:
            del _CONTEXT_CACHE[cache_key]
    return None


def _context_cache_put(cache_key: str, result: dict) -> None:
    with _CONTEXT_CACHE_LOCK:
        _CONTEXT_CACHE[cache_key] = (result, _time_mod.monotonic())


def _context_cache_invalidate() -> None:
    """Clear context cache when new data is written."""
    with _CONTEXT_CACHE_LOCK:
        _CONTEXT_CACHE.clear()

class _LogBufferHandler(_logging.Handler):
    """Thread-safe log handler that appends records to the ring buffer."""
    def emit(self, record: _logging.LogRecord):
        try:
            _LOG_BUFFER.append({
                "ts": _datetime.utcfromtimestamp(record.created).strftime("%H:%M:%S"),
                "level": record.levelname,
                "name": record.name.split(".")[-1],  # last segment only
                "msg": record.getMessage(),
            })
        except Exception:
            pass  # never crash the service over logging

_buf_handler = _LogBufferHandler()
_buf_handler.setLevel(_logging.INFO)
_logging.getLogger().addHandler(_buf_handler)
logger = _logging.getLogger(__name__)

# ─── Auth Router (Self-Hosted JWT + Vault) ─────────────────────────────────────
try:
    from ..auth.routes import router as auth_router
    from ..auth.middleware import init_auth_client
    app.include_router(auth_router)
    init_auth_client(neo4j_backend=graph if active_backend == "neo4j" else None)
    print("[collab-memory] Auth router mounted at /auth/* (JWT provider initialized)")
except Exception as e:
    print(f"[collab-memory] Auth router not loaded: {e} (auth module optional)")

# ─── SAML SSO Router ─────────────────────────────────────────────────────────
try:
    from ..auth.saml_routes import router as saml_router
    app.include_router(saml_router)
    print("[collab-memory] SAML SSO router mounted at /sso/* (python3-saml)")
except Exception as e:
    print(f"[collab-memory] SAML SSO router not loaded: {e} (optional — install python3-saml)")

# ─── Social Login Router ────────────────────────────────────────────────────
try:
    from ..auth.social_routes import router as social_router
    app.include_router(social_router)
    from ..auth.social import get_configured_providers
    _social_providers = get_configured_providers()
    if _social_providers:
        print(f"[collab-memory] Social login mounted at /auth/social/* (providers: {', '.join(_social_providers)})")
    else:
        print("[collab-memory] Social login router mounted (no providers configured — set GITHUB_CLIENT_ID/GOOGLE_CLIENT_ID)")
except Exception as e:
    print(f"[collab-memory] Social login router not loaded: {e} (optional — install authlib)")

# ─── Agent Inbox Email Webhook Router (deferred by default) ───────────────────
# Product policy: inbound "email your agents" stays OFF until dedicated domain,
# provider setup, and queue-first processing are intentionally provisioned.
_FEATURE_AGENT_INBOX_EMAIL = os.environ.get("FEATURE_AGENT_INBOX_EMAIL", "false").lower() in ("true", "1", "yes")
if _FEATURE_AGENT_INBOX_EMAIL:
    try:
        from .email_ingestion import router as email_ingestion_router
        app.include_router(email_ingestion_router)
        print("[collab-memory] Agent inbox email webhook mounted at /webhooks/resend/*")
    except Exception as e:
        print(f"[collab-memory] Agent inbox email webhook not loaded: {e}")
else:
    print("[collab-memory] Agent inbox email webhook disabled (FEATURE_AGENT_INBOX_EMAIL=false)")

# ─── Proxy Router (LLM Pass-Through + Memory Injection) ───────────────────────
try:
    from ..proxy.routes import router as proxy_router, set_graph_backend
    app.include_router(proxy_router)
    set_graph_backend(graph)  # Wire graph for in-process memory injection
    print("[collab-memory] Proxy router mounted at /v1/* (memory injection active)")
except Exception as e:
    print(f"[collab-memory] Proxy router not loaded: {e} (proxy module optional)")

# ─── Auth Middleware ───────────────────────────────────────────────────────────
# Set COLLAB_API_KEY env var on Render to lock your instance.
# Security model:
#   PUBLIC  (no key needed): all GET/HEAD requests — read-only access
#   PROTECTED (key required): POST, PUT, DELETE, PATCH — all writes
# This lets the dashboard, Manus-hosted app, and /agent/bootstrap work freely
# while preventing unauthorized writes to the graph.

from ..abac import (
    resolve_agent_context,
    get_all_valid_keys,
    should_redirect_external_to_hitl,
    is_blocked_for_external,
    check_route_permission,
    require_role,
    AgentContext,
)

_API_KEY = os.environ.get("COLLAB_API_KEY", "").strip()

# Environment detection: "production" disables all dev bypasses.
# Any non-localhost deploy should set this. Managed hosting sets it automatically.
_ENV = os.environ.get("COLLAB_ENV", "development").lower()
_IS_PRODUCTION = _ENV in ("production", "prod", "staging")

# Static env-var keys (fast path). Graph-registered tenant keys resolved dynamically in middleware.
_VALID_API_KEYS: set[str] = get_all_valid_keys()

# Endpoints that require auth even for GET — protects sensitive data exports.
# Pen test 2026-04-01: /memory/context and /graph/debug were leaking full project
# intelligence to unauthenticated requests. /audit/* exposes usage patterns.
# Session 27b: expanded to ALL data endpoints — unauthenticated read access was
# exposing decisions, constraints, preferences, and project data to anyone with the URL.
_FORCE_AUTH_PATHS: set[str] = {
    "/graph/export",
    "/graph/debug",
    "/memory/context",
    "/memory/search",
    "/memory/conflicts",
    "/audit/context",
    "/audit/context/stats",
    "/ops/status",
    "/security/audit",
}

# Path prefixes that require auth for ALL methods (including GET) when API key is configured.
# Only truly public paths (landing, auth, static, docs, signup) remain open.
_PROTECTED_READ_PREFIXES: tuple[str, ...] = (
    "/memory/",
    "/projects",
    "/skills",
    "/graph/",
    "/audit/",
    "/ops/",
    "/tasks",
    "/artifacts",
    "/invites/",
)

# Webhook endpoints — authenticated via HMAC signature in the endpoint itself, not X-API-Key.
# GitHub, Stripe, or any webhook sender won't have our API key.
_WEBHOOK_PATHS: set[str] = {"/ops/github/push", "/webhooks/clerk"}

# GET/HEAD paths that must never require X-API-Key (marketing + apply funnel).
# Listed explicitly so new route prefixes cannot accidentally shadow them.
_PUBLIC_MARKETING_GET_PATHS: frozenset[str] = frozenset({
    "/",
    "/apply",
    "/investors",
    "/investor-deck",
    "/waitlist",
    "/beta",
    "/early-access",
    "/request-access",
    "/signup",
    "/terms",
    "/privacy",
    "/landing",
    "/health",
    "/workspace",
    "/gallery",
})

# ── Plan quota limits ────────────────────────────────────────────────────────
_PLAN_QUOTAS = {
    "pro":        {"pipeline_runs_day": 500, "nodes_day": 2000, "projects_max": 10},
    "enterprise": {"pipeline_runs_day": 0,   "nodes_day": 0,    "projects_max": 0},  # 0 = unlimited
}
# NOTE: No free tier — all access requires a paid plan until OHACO has revenue.
# Free tier is a post-revenue goal, not a launch feature. (Founder decision 2026-04-03)


def _check_plan_quota(agent, path: str) -> dict | None:
    """Check if tenant has exceeded their plan's daily quota. Returns error dict or None."""
    if not agent or getattr(agent, "is_admin", False):
        return None  # Admin / super-admin bypass quotas
    tenant_id = getattr(agent, "tenant_id", "default")
    if tenant_id == "default":
        return None  # Default tenant = local dev, no limits

    try:
        tenant = graph.get_tenant(tenant_id)
        if not tenant:
            return None
        plan = tenant.get("plan", "pro")
        quotas = _PLAN_QUOTAS.get(plan, _PLAN_QUOTAS["pro"])
        if quotas["pipeline_runs_day"] == 0:
            return None  # Unlimited

        # Check daily usage (stored on Tenant node, reset by cron)
        today = str(datetime.now(timezone.utc).date())
        last_reset = tenant.get("quota_reset_date", "")
        runs_today = int(tenant.get("pipeline_runs_today", 0)) if last_reset == today else 0

        if "/ingest" in path and runs_today >= quotas["pipeline_runs_day"]:
            return {
                "error": "quota_exceeded",
                "detail": f"Daily pipeline limit reached ({quotas['pipeline_runs_day']} runs/day on {plan} plan).",
                "plan": plan,
                "usage": runs_today,
                "limit": quotas["pipeline_runs_day"],
                "hint": "Upgrade to Enterprise for unlimited, or contact us at info@ohaco.org.",
            }

        # Increment usage counter (fire-and-forget)
        try:
            graph._tx_write(
                "MATCH (t:Tenant {id: $tid}) "
                "SET t.pipeline_runs_today = CASE WHEN t.quota_reset_date = $today THEN coalesce(t.pipeline_runs_today, 0) + 1 ELSE 1 END, "
                "    t.quota_reset_date = $today",
                tid=tenant_id, today=today,
            )
        except Exception:
            pass  # Non-fatal — don't block requests on counter failure

    except Exception:
        pass  # Quota check failure is non-fatal

    return None


# ── Structured error responses (Stripe-inspired: what → why → fix → docs) ────

def _auth_error(request: Request, status_code: int, code: str, message: str,
                hint: str = "", **extra) -> "JSONResponse":
    """
    Build a consistent, developer-friendly error response.

    Follows:
      - Stripe: type + code + message + doc_url
      - NN/g: what happened → why → how to fix
      - Gov.UK: imperative voice ("Add header…" not "You must…")
      - OHACO tone: confident, accessible, not corporate
    """
    from fastapi.responses import JSONResponse
    body: dict = {
        "error": code,
        "message": message,
    }
    if hint:
        body["hint"] = hint
    body["doc_url"] = str(request.base_url) + "docs"
    body.update(extra)
    return JSONResponse(status_code=status_code, content=body)


def _reject_jwt_if_instance_locked(payload: dict):
    """403 when ALLOWED_INSTANCE_LOGIN_EMAILS is set and JWT email is not listed."""
    from collab_memory.auth.instance_access import instance_login_denied_reason
    from collab_memory.auth.jwt_provider import normalize_email

    msg = instance_login_denied_reason(normalize_email(payload.get("email", "")))
    if msg:
        return JSONResponse(
            status_code=403,
            content={"error": "Forbidden", "detail": msg},
        )
    return None


def _is_public_invite_signup_path(path: str, method: str) -> bool:
    """Allow unauthenticated invite onboarding for new users."""
    if method.upper() != "POST":
        return False
    parts = [p for p in (path or "").split("/") if p]
    return len(parts) == 3 and parts[0] == "invites" and parts[2] == "signup-and-accept"


def _is_public_invite_read_path(path: str, method: str) -> bool:
    """Allow invite preview/landing URLs from email without credentials."""
    if method.upper() not in ("GET", "HEAD"):
        return False
    parts = [p for p in (path or "").split("/") if p]
    if len(parts) == 2 and parts[0] == "invites":
        return True  # /invites/{token}
    if len(parts) == 3 and parts[0] == "invites" and parts[2] == "accept":
        return True  # /invites/{token}/accept
    return False


def _load_pending_invite(token: str, tenant_id: str | None = None) -> dict:
    """Load and validate a pending invite, optionally scoped to a tenant."""
    if not hasattr(graph, "_tx_read"):
        raise HTTPException(status_code=501, detail="Backend does not support invites")
    if not token:
        raise HTTPException(status_code=400, detail="Invite token is required")

    rows = graph._tx_read(
        "MATCH (inv:ProjectInvite {token: $token}) RETURN inv {.*} AS inv",
        token=token,
    )
    if not rows:
        raise HTTPException(status_code=404, detail="Invite not found")

    inv = dict(rows[0]["inv"])
    if tenant_id and inv.get("tenant_id") != tenant_id:
        raise HTTPException(status_code=404, detail="Invite not found")

    if inv.get("status") != "pending":
        raise HTTPException(status_code=410, detail="Invite already used or revoked")

    exp = str(inv.get("expires_at") or "")
    try:
        if datetime.fromisoformat(exp) < datetime.utcnow():
            raise HTTPException(status_code=410, detail="Invite has expired")
    except (ValueError, TypeError):
        pass
    return inv


@app.middleware("http")
async def api_key_middleware(request: Request, call_next):
    """Enforce X-API-Key on writes; attach AgentContext to request.state.agent."""
    if not _API_KEY:
        method = request.method.upper()
        path = request.url.path
        if _IS_PRODUCTION:
            # Production without COLLAB_API_KEY = misconfiguration. Block writes, allow reads.
            if method not in ("GET", "HEAD", "OPTIONS"):
                from fastapi.responses import JSONResponse
                return JSONResponse(
                    status_code=503,
                    content={
                        "error": "Server Misconfigured",
                        "detail": "COLLAB_API_KEY is not set. Write operations are disabled until an API key is configured.",
                        "hint": "Set the COLLAB_API_KEY environment variable.",
                    },
                )
            # Security fix: even in misconfigured production, never serve sensitive reads.
            if method in ("GET", "HEAD") and (
                path in _FORCE_AUTH_PATHS or path.startswith(_PROTECTED_READ_PREFIXES)
            ):
                from fastapi.responses import JSONResponse
                return JSONResponse(
                    status_code=503,
                    content={
                        "error": "Server Misconfigured",
                        "detail": "Authentication is required for this endpoint, but COLLAB_API_KEY is not set.",
                        "hint": "Set the COLLAB_API_KEY environment variable.",
                    },
                )
            request.state.agent = AgentContext(role="reader", agent_id="unconfigured", tenant_id="default")
            return await call_next(request)
        # Local dev: no key configured — fully open (but tenant-scoped reads still default to "default")
        request.state.agent = AgentContext(role="admin", agent_id="local", tenant_id="default")
        return await call_next(request)

    method = request.method.upper()
    path = request.url.path

    # Static assets, docs, and auth endpoints always public
    if path.startswith("/static") or path.startswith("/auth") or path in ("/docs", "/openapi.json", "/redoc"):
        request.state.agent = AgentContext(role="reader", agent_id="public", tenant_id="default")
        return await call_next(request)

    # Webhook paths — authenticated via HMAC, not API key
    if path in _WEBHOOK_PATHS:
        request.state.agent = AgentContext(role="admin", agent_id="webhook", tenant_id="default")
        return await call_next(request)

    # Public pages (apply / waitlist aliases / signup / legal) — no API key on GET
    if method in ("GET", "HEAD") and path in _PUBLIC_MARKETING_GET_PATHS:
        request.state.agent = AgentContext(role="reader", agent_id="public", tenant_id="default")
        return await call_next(request)

    # Invite onboarding path must be callable without credentials.
    if _is_public_invite_signup_path(path, method):
        request.state.agent = AgentContext(role="reader", agent_id="public", tenant_id="default")
        return await call_next(request)
    if _is_public_invite_read_path(path, method):
        request.state.agent = AgentContext(role="reader", agent_id="public", tenant_id="default")
        return await call_next(request)

    # Force-auth paths require a valid key even for GET
    if method in ("GET", "HEAD") and path in _FORCE_AUTH_PATHS:
        key = request.headers.get("X-API-Key", "").strip()
        if not key:
            return _auth_error(
                request, 401, "api_key_required",
                "This endpoint requires authentication.",
                hint="Add header: X-API-Key: <your-key>. Find your key in your project dashboard under Settings.",
            )
        # Validate the key — don't silently downgrade invalid keys
        agent = resolve_agent_context(key, graph=graph)
        if agent.role == "reader" and key not in _VALID_API_KEYS:
            # Key was provided but not recognized — reject, don't downgrade
            try:
                tenant_node = graph.get_tenant_by_key(key)
                if not tenant_node or tenant_node.get("status") != "active":
                    return _auth_error(
                        request, 401, "invalid_api_key",
                        "API key not recognized. Check that you copied the full key from your project settings.",
                        hint="Go to /signup to create an account, or check your dashboard for existing keys.",
                    )
            except Exception:
                return _auth_error(
                    request, 401, "invalid_api_key",
                    "API key not recognized. Check that you copied the full key from your project settings.",
                    hint="Go to /signup to create an account, or check your dashboard for existing keys.",
                )
        request.state.agent = agent
        return await call_next(request)

    # GET and HEAD — check if this path requires authentication
    if method in ("GET", "HEAD"):
        key = request.headers.get("X-API-Key", "").strip()
        auth_header = request.headers.get("Authorization", "").strip()
        is_protected_read = _API_KEY and path.startswith(_PROTECTED_READ_PREFIXES)

        # Try API key first
        if key:
            agent = resolve_agent_context(key, graph=graph)
            if agent.role == "reader" and key not in _VALID_API_KEYS:
                try:
                    tenant_node = graph.get_tenant_by_key(key)
                    if not tenant_node or tenant_node.get("status") != "active":
                        return _auth_error(
                            request, 401, "invalid_api_key",
                            "API key not recognized. Check that you copied the full key from your project settings.",
                            hint="Go to /signup to create an account, or check your dashboard for existing keys.",
                        )
                except Exception:
                    return _auth_error(
                        request, 401, "invalid_api_key",
                        "API key not recognized. Check that you copied the full key from your project settings.",
                        hint="Go to /signup to create an account, or check your dashboard for existing keys.",
                    )
            if (
                not _IS_PRODUCTION
                and key == _API_KEY
                and (not agent.tenant_id or agent.tenant_id == "default")
            ):
                agent = AgentContext(
                    role=agent.role if agent.role else "admin",
                    agent_id=agent.agent_id if agent.agent_id else "local-admin",
                    key=key,
                    project_id=agent.project_id,
                    tenant_id="local-dev",
                )
            request.state.agent = agent
            return await call_next(request)

        # Try JWT Bearer token
        if auth_header.startswith("Bearer "):
            try:
                from collab_memory.auth.middleware import get_auth_client
                auth_client = get_auth_client()
                user = auth_client.get_user(auth_header[7:])
                if user and user.user_id:
                    request.state.agent = AgentContext(
                        role=getattr(user, "role", "contributor"),
                        agent_id=user.user_id,
                        tenant_id=getattr(user, "tenant_id", ""),
                        is_superadmin=bool(getattr(user, "role", "") == "super_admin"),
                    )
                    return await call_next(request)
            except Exception:
                pass

        # No valid credentials — block protected reads, allow public paths
        if is_protected_read:
            return _auth_error(
                request, 401, "authentication_required",
                "This endpoint requires authentication.",
                hint="Log in at /signup, or add header: X-API-Key: <your-key>.",
            )

        request.state.agent = AgentContext(role="reader", agent_id="public", tenant_id="default")
        return await call_next(request)

    # All writes require a valid API key OR a valid JWT Bearer token.
    # JWT ALWAYS takes precedence — it carries the user's verified identity
    # and tenant_id. API key is fallback for agent/programmatic access.
    jwt_authenticated = False
    auth_header = request.headers.get("Authorization", "").strip()
    if auth_header.startswith("Bearer "):
        try:
            from collab_memory.auth.middleware import get_auth_client
            auth_client = get_auth_client()
            user = auth_client.get_user(auth_header[7:])
            if user and user.user_id:
                jwt_authenticated = True
                request.state.agent = AgentContext(
                    role=getattr(user, "role", "contributor"),
                    agent_id=user.user_id,
                    tenant_id=getattr(user, "tenant_id", ""),
                    is_superadmin=bool(getattr(user, "role", "") == "super_admin"),
                )
        except Exception:
            pass

    key = request.headers.get("X-API-Key", "").strip() if not jwt_authenticated else ""

    if not key and not jwt_authenticated:
        return _auth_error(
            request, 401, "api_key_required",
            "Write operations require authentication.",
            hint="Add header: X-API-Key: <your-key>. Or log in at /signup to use the dashboard.",
        )

    if jwt_authenticated:
        # JWT users still need ABAC route check and tenant validation
        agent = getattr(request.state, "agent", AgentContext())
        # Validate tenant_id is present and not "default"
        if not agent.tenant_id or agent.tenant_id == "default":
            return _auth_error(
                request, 400, "missing_tenant",
                "Your session is missing workspace context.",
                hint="Log out and log back in. If this persists, your account may need a workspace assignment — reach out to us.",
            )
        # Check route-level role permissions
        allowed, required_role = check_route_permission(path, method, agent)
        if not allowed:
            return _auth_error(
                request, 403, "insufficient_role",
                f"This action requires the '{required_role}' role.",
                hint=f"Your current role is '{agent.role}'. Ask a project admin to upgrade your access.",
                your_role=agent.role, required_role=required_role,
            )
        return await call_next(request)

    # Fast path: static env-var keys
    key_valid = key in _VALID_API_KEYS
    # Dynamic path: graph-registered tenant keys (only if not in static map)
    if not key_valid:
        try:
            tenant_node = graph.get_tenant_by_key(key)
            key_valid = tenant_node is not None and tenant_node.get("status") == "active"
        except Exception:
            pass

    if not key_valid:
        return _auth_error(
            request, 401, "invalid_api_key",
            "API key not recognized. Check that you copied the full key from your project settings.",
            hint="Go to /signup to create an account, or check your dashboard for existing keys.",
        )

    # Resolve ABAC role and attach to request
    agent = resolve_agent_context(key, graph=graph)
    # Dev ergonomics: allow local admin key flows without tenant provisioning.
    if (
        not _IS_PRODUCTION
        and key == _API_KEY
        and (not agent.tenant_id or agent.tenant_id == "default")
    ):
        agent = AgentContext(
            role="admin",
            agent_id="local-admin",
            key=key,
            tenant_id="local-dev",
            plan="pro",
        )
    request.state.agent = agent

    # Project-scoped key enforcement: if key is scoped to a project,
    # block access to endpoints requesting a different project_id.
    if agent.project_id:
        qp = dict(request.query_params)
        requested_project = qp.get("project_id", "")
        # If endpoint specifies a project_id and it doesn't match, block
        if requested_project and requested_project != agent.project_id:
            from fastapi.responses import JSONResponse
            return JSONResponse(
                status_code=403,
                content={
                    "error": "Project scope violation",
                    "detail": f"This key is scoped to project '{agent.project_id}'. "
                              f"Cannot access project '{requested_project}'.",
                },
            )
        # Also check path-level project_id (e.g., /projects/{project_id}/...)
        if "/projects/" in path:
            import re
            m = re.match(r"/projects/([^/]+)", path)
            if m and m.group(1) != agent.project_id:
                from fastapi.responses import JSONResponse
                return JSONResponse(
                    status_code=403,
                    content={
                        "error": "Project scope violation",
                        "detail": f"This key is scoped to project '{agent.project_id}'.",
                    },
                )

    # External role: auto-redirect writes to HITL queue (202 Queued)
    if agent.role == "external":
        if is_blocked_for_external(path):
            return _auth_error(
                request, 403, "external_blocked",
                "External agents cannot perform this operation directly.",
                hint="Submit a write via /memory/ingest — it will be queued for human review.",
                your_role="external",
            )
        if should_redirect_external_to_hitl(path, method):
            from fastapi.responses import JSONResponse
            return JSONResponse(
                status_code=202,
                content={
                    "status": "queued",
                    "message": "External write queued for human review. Approve from the dashboard.",
                    "hint": "Check GET /memory/pending to see queued items.",
                    "path": path,
                    "method": method,
                }
            )

    # Tenant validation: reject writes with no/default tenant_id
    # Skip for /ops/ and /admin/ paths — these are instance-level operations
    # authenticated via the primary COLLAB_API_KEY, not tenant-scoped
    if (
        _API_KEY
        and not path.startswith("/ops/")
        and not path.startswith("/admin/")
        and (not agent.tenant_id or agent.tenant_id == "default")
    ):
        return _auth_error(
            request, 400, "missing_tenant",
            "Your API key is not associated with a workspace yet.",
            hint="Sign up at /signup to create a workspace, or ask a workspace admin to generate a scoped key for you.",
            tenant_id=agent.tenant_id or "(none)",
        )

    # Route-level role enforcement: check agent role against ROUTE_MIN_ROLE table
    allowed, required_role = check_route_permission(path, method, agent)
    if not allowed:
        return _auth_error(
            request, 403, "insufficient_role",
            f"This action requires the '{required_role}' role.",
            hint=f"Your current role is '{agent.role}'. Ask a project admin to upgrade your access, or generate a new key with the right permissions.",
            your_role=agent.role, required_role=required_role,
        )

    # ── Plan-based quota enforcement ─────────────────────────────────────────
    # Only enforce on write paths that create new nodes (ingest, record, tasks)
    _QUOTA_PATHS = {"/memory/ingest", "/memory/record", "/tasks"}
    if method == "POST" and any(path.startswith(qp) for qp in _QUOTA_PATHS):
        _quota_result = _check_plan_quota(agent, path)
        if _quota_result is not None:
            from fastapi.responses import JSONResponse
            return JSONResponse(status_code=429, content=_quota_result)

    return await call_next(request)


# ─── Request/Response Models ──────────────────────────────────────────────────

from ..schema import Skill, SkillSourceType
from ..adapters.claude import parse_claude_export
from ..adapters.chatgpt import parse_chatgpt_export
from ..agents.pipeline import build_pipeline, get_pipeline_status

# Build pipeline once at startup — graph backend injected
_pipeline = build_pipeline(graph=graph)

class IngestRequest(BaseModel):
    # Primary format: raw_text (canonical)
    raw_text: Optional[str] = None
    # Friendly format: human_turn + agent_turn (dashboard / docs / MCP server use this)
    human_turn: Optional[str] = None
    agent_turn: Optional[str] = None

    session_id: str = "default"
    project_id: Optional[str] = None
    # Accept int (unix ms), float, ISO string, or None (defaults to now)
    turn_start: Optional[Union[int, float, str]] = None
    turn_end: Optional[Union[int, float, str]] = None
    skip_llm: bool = False

    def get_raw_text(self) -> str:
        """Resolve raw_text from whichever format was provided."""
        if self.raw_text:
            return self.raw_text
        parts = []
        if self.human_turn:
            parts.append(f"Human: {self.human_turn}")
        if self.agent_turn:
            parts.append(f"Agent: {self.agent_turn}")
        return "\n".join(parts) if parts else ""

    def get_turn_start(self) -> int:
        """Resolve turn_start to a unix timestamp int."""
        import time as _time
        if self.turn_start is None:
            return int(_time.time())
        if isinstance(self.turn_start, (int, float)):
            return int(self.turn_start)
        try:
            from datetime import datetime as _dt
            return int(_dt.fromisoformat(str(self.turn_start).replace("Z", "+00:00")).timestamp())
        except Exception:
            return int(_time.time())


# Ensure Pydantic V2 fully resolves all forward references for this model
IngestRequest.model_rebuild()


class IngestResponse(BaseModel):
    exchange_record_id: str
    primitive_type: str
    worthiness_score: float
    should_encode: bool
    nodes_generated: list[str]
    flagged_for_review: bool
    classifier_reasoning: str
    graph_write_error: Optional[str] = None   # surfaces graph_writer exceptions for debugging
    pending_confirmation: bool = False   # True if novel+inferred — awaits HITL


class PendingInference(BaseModel):
    """An inferred node awaiting human confirmation before graph write."""
    id: str
    node_type: str          # Decision | Constraint | Preference | Attempt
    description: str
    origin: str = "inferred"
    confidence: float
    session_id: str
    raw_text: str = ""
    created_at: str = ""


class AddSkillRequest(BaseModel):
    name: str
    url: str = ""
    summary: str = ""
    content: str = ""
    tags: list[str] = []
    source_type: str = "custom"
    added_by: str = "user"


class FetchSkillRequest(BaseModel):
    url: str
    name: str = ""
    tags: list[str] = []
    source_type: str = "api_docs"


# ─── Endpoints ────────────────────────────────────────────────────────────────

@app.get("/.well-known/agent.json", include_in_schema=False)
def agent_card(request: Request):
    """Agent Card — A2A protocol discovery endpoint (Google Agent2Agent spec, April 2025).

    Any A2A-compatible agent (Claude, Gemini, GPT, etc.) can GET this URL to
    discover collab-memory's capabilities, authentication scheme, and skills
    before initiating a session.
    """
    base_url = str(request.base_url).rstrip("/")
    version = _VERSION

    return JSONResponse({
        "name": "collab-memory",
        "description": (
            "AI collaboration memory system — captures, classifies, and retrieves "
            "architectural decisions, constraints, and preferences from human-AI sessions. "
            "Provides persistent institutional memory across agent context windows."
        ),
        "url": base_url,
        "version": version,
        "documentationUrl": "https://github.com/OHACO-LABS/collab-memory",
        "capabilities": {
            "streaming": False,
            "pushNotifications": False,
            "stateTransitionHistory": True,
        },
        "authentication": {
            "schemes": ["ApiKey"],
            "credentials": "Pass your API key in the X-API-Key header",
        },
        "defaultInputModes": ["text/plain", "application/json"],
        "defaultOutputModes": ["application/json", "text/markdown", "text/plain"],
        "skills": [
            {
                "id": "get_context",
                "name": "Get Session Context",
                "description": "Bootstrap a session with all active decisions, constraints, preferences, and workflow rules for a project. Call this first.",
                "tags": ["memory", "context", "bootstrap"],
                "examples": ["GET /memory/context", "GET /memory/context?project_id=my-project&limit=20"],
            },
            {
                "id": "semantic_search",
                "name": "Search Memory",
                "description": "Semantic search over stored memory using tri-factor retrieval (recency × importance × relevance).",
                "tags": ["memory", "search", "semantic"],
                "examples": ["GET /memory/search?q=authentication+decisions"],
            },
            {
                "id": "ingest",
                "name": "Record Memory",
                "description": "Ingest a conversation exchange. The pipeline classifies it and stores decisions, constraints, preferences, and attempts automatically.",
                "tags": ["memory", "ingest", "classify"],
                "examples": ["POST /memory/ingest"],
            },
            {
                "id": "handoff",
                "name": "Generate Handoff Document",
                "description": "Auto-generate a full engineer handoff document from the project graph. No separate docs step needed.",
                "tags": ["documentation", "handoff", "export"],
                "examples": ["GET /projects/{project_id}/handoff", "GET /projects/{project_id}/handoff?fmt=json"],
            },
            {
                "id": "export_training_data",
                "name": "Export LoRA Training Data",
                "description": "Export project memory as sharegpt-format JSONL instruction pairs for LoRA fine-tuning.",
                "tags": ["training", "lora", "export", "fine-tuning"],
                "examples": ["GET /projects/{project_id}/export-training-data"],
            },
            {
                "id": "decision_archaeology",
                "name": "Trace Decision Rationale",
                "description": "Trace the causal chain behind any architectural decision — why it was made, what it superseded, what constraints it satisfies.",
                "tags": ["memory", "archaeology", "rationale"],
                "examples": ["GET /memory/why?q=why+did+we+choose+neo4j"],
            },
        ],
    })


# Import limiter for per-endpoint decorators (slowapi pattern)
try:
    from ..rate_limit import limiter, LIMIT_MEMORY, LIMIT_SKILLS, LIMIT_OPS, LIMIT_PROXY
except Exception:
    # Graceful fallback: create a no-op decorator so endpoints still work
    class _NoopLimiter:
        def limit(self, *a, **kw):
            return lambda f: f
    limiter = _NoopLimiter()
    LIMIT_MEMORY = LIMIT_SKILLS = LIMIT_OPS = LIMIT_PROXY = "1000/minute"

# ─── Skills ─────────────────────────
@app.get("/skills", summary="List skills in the library")
@limiter.limit(LIMIT_SKILLS)
def list_skills(
    request: Request,
    tags: Optional[str] = Query(None, description="Comma-separated tag filter"),
    source_type: Optional[str] = Query(None),
    limit: int = Query(100, ge=1, le=500),
):
    """List all stored skills, optionally filtered by tags or source type."""
    tag_list = [t.strip() for t in tags.split(",")] if tags else None
    _agent_ctx = getattr(request.state, "agent", None)
    _tid = getattr(_agent_ctx, "tenant_id", "default") if _agent_ctx else "default"
    if hasattr(graph, "get_skills"):
        items = graph.get_skills(tags=tag_list, source_type=source_type, limit=limit, tenant_id=_tid)
        return {"skills": [s.model_dump() for s in items], "count": len(items)}
    return {"skills": [], "count": 0, "note": "Backend does not support skills"}


@app.get("/skills/search", summary="Search skills by keyword")
@limiter.limit(LIMIT_SKILLS)
def search_skills(
    request: Request,
    q: str = Query(..., description="Search query"),
    limit: int = Query(20, ge=1, le=100),
):
    """Full-text search across skill name, summary, content, tags, and URL."""
    if hasattr(graph, "search_skills"):
        items = graph.search_skills(q, limit=limit)
        return {"skills": [s.model_dump() for s in items], "count": len(items), "query": q}
    return {"skills": [], "count": 0, "query": q}


@app.post("/skills", summary="Add a skill to the library")
def add_skill(req: AddSkillRequest):
    """Manually add a skill (API doc, snippet, how-to) to the knowledge library."""
    try:
        src_type = SkillSourceType(req.source_type)
    except ValueError:
        src_type = SkillSourceType.custom
    skill = Skill(
        name=req.name,
        url=req.url,
        summary=req.summary,
        content=req.content,
        tags=req.tags,
        source_type=src_type,
        added_by=req.added_by,
    )
    if hasattr(graph, "save_skill"):
        graph.save_skill(skill)
    return {"skill_id": skill.id, "name": skill.name, "ok": True}


@app.post("/skills/upload", summary="Upload a document/file as a skill")
async def upload_skill(
    file: UploadFile = File(...),
    name: str = Query(default=""),
    tags: str = Query(default=""),
    source_type: str = Query(default="document"),
    project_id: str = Query(default=""),
    summary: str = Query(default=""),
):
    """
    Upload a file (PDF, markdown, txt, code, etc.) and store it as a Skill node.
    The file content is indexed for semantic search and can be used to augment
    existing memory nodes with relevant knowledge.

    - name: display name (defaults to filename)
    - tags: comma-separated list of tags
    - source_type: document | library | tool | workflow | custom
    - project_id: optional project scope
    """
    content_bytes = await file.read()
    if len(content_bytes) > 200_000:
        content_bytes = content_bytes[:200_000]

    try:
        content = content_bytes.decode("utf-8")
    except UnicodeDecodeError:
        content = content_bytes.decode("latin-1", errors="replace")

    display_name = name or (file.filename or "uploaded_file")
    tag_list = [t.strip() for t in tags.split(",") if t.strip()] if tags else []
    if project_id:
        tag_list.append(f"project:{project_id}")

    skill = Skill(
        name=display_name,
        url="",
        summary=summary or f"Uploaded: {display_name}",
        content=content,
        tags=tag_list,
        source_type=source_type,
        added_by="user",
        project_id=project_id or None,
    )
    if hasattr(graph, "save_skill"):
        graph.save_skill(skill)
    return {
        "skill_id": skill.id,
        "name": skill.name,
        "size_bytes": len(content_bytes),
        "tags": tag_list,
        "ok": True,
    }


@app.post("/memory/augment/{node_id}", summary="Attach a skill to an existing memory node")
def augment_memory_node(node_id: str, skill_id: str = Query(...)):
    """
    Create a RELATES_TO edge from a memory node (Decision/Constraint/Preference)
    to a Skill node. This links learned knowledge to specific decisions so agents
    can surface the source material when explaining a decision.
    """
    if not hasattr(graph, "_tx_write"):
        raise HTTPException(status_code=501, detail="Backend does not support graph writes")
    try:
        import datetime as _dt
        graph._tx_write(
            """
            MATCH (m {id: $node_id}), (s:Skill {id: $skill_id})
            MERGE (m)-[r:RELATES_TO {type: 'augmented_by'}]->(s)
            SET r.created_at = $ts
            RETURN count(r) AS n
            """,
            node_id=node_id,
            skill_id=skill_id,
            ts=_dt.datetime.utcnow().isoformat(),
        )
        return {"ok": True, "node_id": node_id, "skill_id": skill_id}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/skills/fetch", summary="Fetch and index a URL as a skill")
async def fetch_skill(req: FetchSkillRequest):
    """
    Fetch a URL, extract its text content, and store it as a skill.
    Useful for indexing API docs, README pages, or integration guides.
    """
    import httpx, re as _re
    from urllib.parse import urlparse
    import ipaddress

    # SSRF prevention (OWASP A10:2021) — block internal/private URLs
    try:
        parsed = urlparse(req.url)
        if parsed.scheme not in ("http", "https"):
            raise HTTPException(status_code=400, detail=f"URL scheme must be http or https, got: {parsed.scheme}")
        import socket
        resolved_ip = socket.gethostbyname(parsed.hostname)
        ip = ipaddress.ip_address(resolved_ip)
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved:
            raise HTTPException(status_code=400, detail="URL resolves to a private/internal address — blocked for security.")
    except (socket.gaierror, ValueError) as e:
        raise HTTPException(status_code=400, detail=f"Invalid URL: {e}")

    try:
        async with httpx.AsyncClient(timeout=15.0, follow_redirects=True) as client:
            resp = await client.get(req.url, headers={"User-Agent": "collab-memory/0.2"})
            resp.raise_for_status()
            raw = resp.text
        # Strip HTML tags (basic)
        clean = _re.sub(r"<[^>]+>", " ", raw)
        clean = _re.sub(r"\s+", " ", clean).strip()
        content_preview = clean[:8000]
        name = req.name or req.url.split("/")[-1] or req.url
        try:
            src_type = SkillSourceType(req.source_type)
        except ValueError:
            src_type = SkillSourceType.api_docs
        skill = Skill(
            name=name,
            url=req.url,
            summary=f"Auto-fetched from {req.url}",
            content=content_preview,
            tags=req.tags,
            source_type=src_type,
            added_by="agent",
        )
        if hasattr(graph, "save_skill"):
            graph.save_skill(skill)
        return {
            "skill_id": skill.id,
            "name": skill.name,
            "content_length": len(content_preview),
            "ok": True,
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))



# ── Server-Sent Events — real-time graph updates ───────────────────────────

@app.get("/stream/events", summary="SSE stream of real-time graph events",
         tags=["stream"], include_in_schema=True)
async def stream_events(request: Request):
    """Server-Sent Events endpoint for live graph updates.

    Events: node.created, node.updated, edge.created, agent.connected,
    agent.active, pipeline.stage.  Frontend subscribes via EventSource.
    """
    from .sse import subscribe, unsubscribe

    queue = subscribe()

    async def event_generator():
        try:
            # Send initial heartbeat so the client knows we're connected
            yield f"data: {json.dumps({'type': 'connected', 'subscribers': 1})}\n\n"
            while True:
                # Check if client disconnected
                if await request.is_disconnected():
                    break
                try:
                    event = await asyncio.wait_for(queue.get(), timeout=30.0)
                    yield f"data: {json.dumps(event)}\n\n"
                except asyncio.TimeoutError:
                    # Send keepalive comment to prevent proxy/CDN timeouts
                    yield ": keepalive\n\n"
        finally:
            unsubscribe(queue)

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",  # Disable Nginx buffering
        },
    )


@app.get("/memory/context", summary="Get session context brief")
@limiter.limit(LIMIT_MEMORY)
def get_context(
    request: Request,
    entity: Optional[str] = Query(None, description="Entity ID to scope context to"),
    task_type: Optional[str] = Query(None, description="Type of task for this session"),
    project_id: Optional[str] = Query(None, description="Scope to a specific project"),
    module: Optional[str] = Query(None, description="Scope to a specific module"),
    category: Optional[str] = Query(None, description="Scope to a specific category"),
    since: Optional[str] = Query(None, description="ISO 8601 datetime or Unix timestamp — only return nodes created after this time"),
    agent_id: Optional[str] = Query(None, description="Calling agent identity (for audit logging)"),
    limit: Optional[int] = Query(None, description="Max nodes per category (1-50, default 10)"),
    confidence_min: Optional[float] = Query(None, description="Minimum confidence threshold (0.0-1.0)"),
    origin: Optional[str] = Query(None, description="Filter by origin: explicit, inferred, or all"),
):
    """
    Returns a structured brief: active decisions, constraints, inferred
    preferences, recent attempts, and caution flags.
    This is what an agent calls at the start of a new session.

    Supports scoped filtering via project_id, module, category, since,
    agent_id (audit), limit, confidence_min, and origin parameters.
    """
    import time as _time
    from .audit import (
        validate_since, validate_agent_id, validate_limit,
        validate_confidence_min, validate_origin, record_audit, ValidationError,
    )

    _start = _time.time()
    try:
        since_dt = validate_since(since)
        agent_id_clean = validate_agent_id(agent_id)
        limit_val = validate_limit(limit)
        conf_min = validate_confidence_min(confidence_min)
        origin_val = validate_origin(origin)
    except ValidationError as ve:
        raise HTTPException(status_code=400, detail=ve.message)

    # Sprint 23: Resolve tenant_id from ABAC context
    _agent_ctx = getattr(request.state, "agent", None)
    _tenant_id = getattr(_agent_ctx, "tenant_id", "default") if _agent_ctx else "default"

    # Project membership enforcement for JWT users
    _check_project_access(request, project_id)

    # TTL cache — same params within 60s return cached result
    _cache_key = f"{_tenant_id}:{project_id}:{module}:{category}:{since}:{origin_val}:{conf_min}:{limit_val}"
    result = _context_cache_get(_cache_key)
    if result is None:
        result = graph.build_context_brief(
            entity_id=entity, task_type=task_type, project_id=project_id,
            tenant_id=_tenant_id,
            module=module, category=category, since=since_dt,
            origin=origin_val, confidence_min=conf_min, limit=limit_val,
        )
        _context_cache_put(_cache_key, result)

    # Audit logging
    record_audit(
        endpoint="/memory/context",
        agent_id=agent_id_clean,
        project_id=project_id,
        params={"since": since, "limit": limit_val, "confidence_min": conf_min, "origin": origin_val, "module": module, "category": category},
        result_counts={
            "decisions": len(result.get("active_decisions", [])),
            "constraints": len(result.get("active_constraints", [])),
            "preferences": len(result.get("inferred_preferences", [])),
            "attempts": len(result.get("recent_attempts", [])),
        },
        response_chars=len(str(result)),
        latency_ms=(_time.time() - _start) * 1000,
    )

    return result


@app.get("/memory/context/prompt", summary="Get session context as a system prompt string")
@limiter.limit(LIMIT_MEMORY)
def get_context_prompt(
    request: Request,
    entity: Optional[str] = Query(None),
    task_type: Optional[str] = Query(None),
    project_id: Optional[str] = Query(None, description="Scope to a specific project (e.g. 'collab-memory')"),
    module: Optional[str] = Query(None, description="Scope to a specific module (e.g. 'pipeline')"),
    category: Optional[str] = Query(None, description="Scope to a specific category (e.g. 'decision')"),
    q: Optional[str] = Query(None, description="Semantic search query — returns only contextually relevant nodes (HNSW/BM25). When omitted, returns full context brief."),
    since: Optional[str] = Query(None, description="ISO 8601 datetime or Unix timestamp — only return nodes created after this time"),
    agent_id: Optional[str] = Query(None, description="Calling agent identity (for audit logging)"),
    limit: Optional[int] = Query(None, description="Max nodes per category (1-50, default 10)"),
    confidence_min: Optional[float] = Query(None, description="Minimum confidence threshold (0.0-1.0)"),
    origin: Optional[str] = Query(None, description="Filter by origin: explicit, inferred, or all"),
):
    """
    Returns a ready-to-paste system prompt string built from the current graph context.
    Scoped by project_id, module, category, since, confidence_min, and origin.
    When ?q= is provided, uses HNSW semantic search to return only nodes relevant to the
    query rather than the full context dump. Falls back to BM25 if HNSW indexes are absent.

    Scoped parameters:
    - since: ISO 8601 or Unix timestamp — only nodes created after this time
    - agent_id: calling agent identity for audit trail
    - limit: max nodes per category (1-50, default 10)
    - confidence_min: minimum confidence threshold (0.0-1.0)
    - origin: explicit | inferred | all
    - q: semantic search query (HNSW/BM25)
    """
    import time as _time
    from .audit import (
        validate_since, validate_agent_id, validate_limit,
        validate_confidence_min, validate_origin, record_audit, ValidationError,
    )

    _start = _time.time()
    try:
        since_dt = validate_since(since)
        agent_id_clean = validate_agent_id(agent_id)
        limit_val = validate_limit(limit)
        conf_min = validate_confidence_min(confidence_min)
        origin_val = validate_origin(origin)
    except ValidationError as ve:
        raise HTTPException(status_code=400, detail=ve.message)

    # Sprint 23: tenant scope
    _agent_ctx = getattr(request.state, "agent", None)
    _tid = getattr(_agent_ctx, "tenant_id", "default") if _agent_ctx else "default"

    # Project membership enforcement for JWT users
    _check_project_access(request, project_id)

    # ── Semantic retrieval path ─────────────────────────────────────────
    if q and q.strip() and hasattr(graph, 'semantic_search'):
        try:
            results = graph.semantic_search(
                query=q.strip(),
                node_types=["Decision", "Constraint", "Preference", "Attempt"],
                limit=limit_val or 20,
                project_id=project_id,
                tenant_id=_tid,
            )
            if results:
                brief = {
                    "active_decisions":      [r for r in results if r.get("node_type") == "Decision"],
                    "active_constraints":    [r for r in results if r.get("node_type") == "Constraint"],
                    "inferred_preferences":  [r for r in results if r.get("node_type") == "Preference"],
                    "recent_attempts":       [r for r in results if r.get("node_type") == "Attempt"],
                    "pending_count":         0,
                    "backend":               "Neo4jBackend",
                    "_search_path":          results[0].get("_search_path", "bm25") if results else "none",
                    "_query":                q.strip(),
                }
            else:
                brief = graph.build_context_brief(
                    entity_id=entity, task_type=task_type, project_id=project_id,
                    tenant_id=_tid,
                    module=module, category=category, since=since_dt,
                    origin=origin_val, confidence_min=conf_min, limit=limit_val,
                )
        except Exception:
            brief = graph.build_context_brief(
                entity_id=entity, task_type=task_type, project_id=project_id,
                tenant_id=_tid,
                module=module, category=category, since=since_dt,
                origin=origin_val, confidence_min=conf_min, limit=limit_val,
            )
    else:
        # ── Full context dump path with scoped filtering ──────────────────
        brief = graph.build_context_brief(
            entity_id=entity, task_type=task_type, project_id=project_id,
            tenant_id=_tid,
            module=module, category=category, since=since_dt,
            origin=origin_val, confidence_min=conf_min, limit=limit_val,
        )

    lines = ["## Memory Context (collab-memory)\n"]

    # Terms that indicate cross-project contamination (CRE, real estate, slide decks, etc.)
    _NOISE = {
        "csv", "xls", "portfolio", "listing", "mls", "cap rate", "noi", "rent roll",
        "vercel kv", "zoning", "sqft", "cre ", "property", "tenant", "landlord",
        "mckinsey", "hbr", "microsite", "slide", "pitch deck", "boulevard",
        "seaside", "nj elite", "realty", "market data", "traffic data",
        "showings", "loi", "tool selection", "partner listing", "partner agent",
        "conversion track", "1916", "what the tests prove", "keyword scorer",
        "partner_submission", "tracking:\n",
    }

    # Constraints/gaps resolved in Sprints 19-20.5 — exclude from context until nodes invalidated.
    _RESOLVED_GAPS = {
        "no project scoping", "no temporal", "no point-in-time retrieval",
        "no semantic/resonance retrieval", "no within-session state",
        "session-start workflow requires bash", "requires bash/curl",
        "render free tier", "render (free tier)", "cold starts (~30s)",
        "no automatic ingest at session end",
    }

    def _is_noise(text: str) -> bool:
        t = text.lower()
        return any(term in t for term in _NOISE) or any(gap in t for gap in _RESOLVED_GAPS)

    def _dedup(
        items: list,
        key: str = "description",
        limit: int = 12,
        *,
        apply_noise_filter: bool = True,
    ) -> list:
        seen: set = set()
        result = []
        for item in sorted(items, key=lambda x: x.get("confidence", 0), reverse=True):
            text = (item.get(key) or "").strip()
            if not text:
                continue
            if apply_noise_filter and _is_noise(text):
                continue
            fingerprint = text.lower()[:80]
            if fingerprint in seen:
                continue
            seen.add(fingerprint)
            result.append(item)
            if len(result) >= limit:
                break
        return result

    raw_decisions = brief.get("active_decisions", [])
    raw_constraints = brief.get("active_constraints", [])
    raw_prefs = brief.get("inferred_preferences", [])
    raw_attempts = brief.get("recent_attempts", [])

    decisions = _dedup(raw_decisions, limit=12)
    if decisions:
        lines.append("### Standing Decisions — Do Not Re-Litigate")
        for d in decisions:
            conf = d.get("confidence", 0)
            lines.append(f"- {d['description']} ({int(conf*100)}% confidence)")
        lines.append("")

    constraints = _dedup(raw_constraints, limit=10)
    if constraints:
        lines.append("### Active Constraints")
        for c in constraints:
            origin = " [inferred]" if c.get("origin") == "inferred" else ""
            lines.append(f"- {c['description']}{origin}")
        lines.append("")

    prefs = _dedup(raw_prefs, limit=8)
    if prefs:
        lines.append("### Inferred Preferences")
        for p in prefs:
            lines.append(f"- [{p.get('type','process')}] {p['description']}")
        lines.append("")

    attempts = _dedup(raw_attempts, limit=5)
    if attempts:
        lines.append("### Don't Revisit These Approaches")
        for a in attempts:
            lines.append(f"- {a['description']}")
        lines.append("")

    # If aggressive noise filters wipe out all surfaced items while the raw brief is populated,
    # fall back to unfiltered dedup so agents are never bootstrapped with a false-empty context.
    filter_note = None
    raw_total = len(raw_decisions) + len(raw_constraints) + len(raw_prefs) + len(raw_attempts)
    surfaced_total = len(decisions) + len(constraints) + len(prefs) + len(attempts)
    if raw_total > 0 and surfaced_total == 0:
        decisions = _dedup(raw_decisions, limit=12, apply_noise_filter=False)
        constraints = _dedup(raw_constraints, limit=10, apply_noise_filter=False)
        prefs = _dedup(raw_prefs, limit=8, apply_noise_filter=False)
        attempts = _dedup(raw_attempts, limit=5, apply_noise_filter=False)
        filter_note = "fallback_unfiltered_due_empty_filtered_context"

        if decisions:
            lines.append("### Standing Decisions — Do Not Re-Litigate")
            for d in decisions:
                conf = d.get("confidence", 0)
                lines.append(f"- {d['description']} ({int(conf*100)}% confidence)")
            lines.append("")
        if constraints:
            lines.append("### Active Constraints")
            for c in constraints:
                origin = " [inferred]" if c.get("origin") == "inferred" else ""
                lines.append(f"- {c['description']}{origin}")
            lines.append("")
        if prefs:
            lines.append("### Inferred Preferences")
            for p in prefs:
                lines.append(f"- [{p.get('type','process')}] {p['description']}")
            lines.append("")
        if attempts:
            lines.append("### Don't Revisit These Approaches")
            for a in attempts:
                lines.append(f"- {a['description']}")
            lines.append("")

        lines.append(
            "_Context safety fallback: surfaced unfiltered context because filter rules hid all items._"
        )
        lines.append("")

    pending = brief.get("pending_count", 0)
    if pending:
        lines.append(f"### ⏳ {pending} inference(s) awaiting your review")
        lines.append("- Check: GET /memory/pending to confirm or reject")
        lines.append("")

    # Clean summary — computed from filtered counts, not raw graph text
    backend = brief.get("backend", "Neo4jBackend")
    lines.append(
        f"*{len(decisions)} decisions · {len(constraints)} constraints · "
        f"{len(prefs)} preferences · backend: {backend}*"
    )

    prompt = "\n".join(lines)

    # Audit logging
    record_audit(
        endpoint="/memory/context/prompt",
        agent_id=agent_id_clean,
        project_id=project_id,
        params={"since": since, "limit": limit_val, "confidence_min": conf_min, "origin": origin_val, "module": module, "category": category, "q": q},
        result_counts={
            "decisions": len(decisions),
            "constraints": len(constraints),
            "preferences": len(prefs),
            "attempts": len(attempts),
        },
        response_chars=len(prompt),
        latency_ms=(_time.time() - _start) * 1000,
    )

    return {
        "prompt": prompt,
        "char_count": len(prompt),
        "backend": backend,
        "counts": {
            "raw": {
                "decisions": len(raw_decisions),
                "constraints": len(raw_constraints),
                "preferences": len(raw_prefs),
                "attempts": len(raw_attempts),
            },
            "display": {
                "decisions": len(decisions),
                "constraints": len(constraints),
                "preferences": len(prefs),
                "attempts": len(attempts),
            },
        },
        "filter_note": filter_note,
        "_search_path": brief.get("_search_path"),    # "hnsw", "bm25", or None (full dump)
        "_query": brief.get("_query"),                 # echoes back the ?q= value used
    }


@app.get("/agent-manifest.json", summary="Machine-readable agent manifest")
def agent_manifest():
    """Returns the agent-agnostic knowledge manifest for collab-memory.
    Any AI agent platform can parse this to understand capabilities, endpoints, and schema."""
    import json
    manifest_path = Path(__file__).parent.parent.parent.parent / "agent-manifest.json"
    if manifest_path.exists():
        return json.loads(manifest_path.read_text())
    return {"error": "Manifest not found", "hint": "agent-manifest.json should be in the project root"}


@app.get("/agent/onboarding", summary="Agent onboarding \u2014 alias for /agent/bootstrap")
def agent_onboarding(request: Request):
    """Alias for /agent/bootstrap. Returns full project context for any agent platform."""
    return agent_bootstrap(request)


@app.get("/agent/bootstrap", summary="Bootstrap any agent with full project context + API instructions")
def agent_bootstrap(request: Request):
    """
    One-call agent onboarding. Returns everything an agent needs to immediately
    understand the project, communicate back to the graph, and behave according
    to the user's preferences — no setup, no SDK, no MCP required.

    Agents should call this URL once at session start and use the response to:
    - Inject system_prompt into their context window
    - Learn which endpoints to call (record decisions, store artifacts, queue inferences)
    - Understand the user's verified preferences
    - Confirm the connection is live

    Compatible with: Manus, Claude web, GPT-4, n8n, Zapier, any HTTP-capable agent.
    """
    base_url = str(request.base_url).rstrip("/")
    brief = graph.build_context_brief()
    backend = brief.get("backend", "Neo4jBackend")
    _agent_ctx = getattr(request.state, "agent", None)
    _tid = getattr(_agent_ctx, "tenant_id", "default") if _agent_ctx else "default"

    # ── System prompt (same as /memory/context/prompt) ──────────────────────
    prompt_resp = get_context_prompt(
        request, entity=None, task_type=None, project_id=None,
        module=None, category=None, q=None, since=None,
        agent_id=None, limit=None, confidence_min=None, origin=None,
    )
    system_prompt = prompt_resp.get("prompt", "")

    # ── User preferences (high-confidence only) ───────────────────────────────
    try:
        raw_prefs = graph.get_preferences(confidence_min=0.8, min_reinforcements=1, tenant_id=_tid)
        preferences = [
            {"type": p.type, "description": p.description, "confidence": p.confidence}
            for p in raw_prefs[:10]
        ]
    except Exception:
        preferences = []

    # ── API instructions (what endpoints to call and when) ───────────────────
    api_instructions = {
        "base_url": base_url,
        "auth": "None required (open access). If X-API-Key header is required, it will be documented in your onboarding config.",
        "endpoints": {
            "load_context": {
                "method": "GET",
                "url": f"{base_url}/memory/context/prompt",
                "when": "At session start, before any work. Returns formatted system prompt.",
            },
            "record_decision": {
                "method": "POST",
                "url": f"{base_url}/memory/ingest",
                "when": "When the user EXPLICITLY states a decision, constraint, or preference.",
                "body": {"human_turn": "<what the user said>", "agent_turn": "", "session_id": "<your agent name>"},
            },
            "queue_inference": {
                "method": "POST",
                "url": f"{base_url}/memory/queue_inference",
                "when": "When you INFER something not explicitly stated. Do NOT write guesses directly — queue for human review.",
                "body": {"node_type": "decision|constraint|preference", "description": "<what you inferred>", "confidence": 0.7, "session_id": "<your agent name>"},
            },
            "store_artifact": {
                "method": "POST",
                "url": f"{base_url}/artifacts",
                "when": "When you produce a file, report, script, or any work product worth keeping across sessions.",
                "body": {"name": "<filename>", "content": "<full text content>", "artifact_type": "code|html|markdown|other", "session_id": "<your agent name>"},
            },
            "get_artifact": {
                "method": "GET",
                "url": f"{base_url}/artifacts/<artifact_id>",
                "when": "To retrieve a previously stored artifact from any agent or session.",
            },
            "search_skills": {
                "method": "GET",
                "url": f"{base_url}/skills/search?q=<keywords>",
                "when": "Before implementing anything — check if a skill already documents the correct approach.",
            },
            "explain_decision": {
                "method": "GET",
                "url": f"{base_url}/memory/why?decision=<decision_id>",
                "when": "To understand the causal chain behind a decision before challenging it.",
            },
            "review_pending": {
                "method": "GET",
                "url": f"{base_url}/memory/pending",
                "when": "To see inferences awaiting human confirmation.",
            },
            "health_check": {
                "method": "GET",
                "url": f"{base_url}/health",
                "when": "To verify the backend is online.",
            },
            "send_message": {
                "method": "POST",
                "url": f"{base_url}/agent/inbox",
                "when": "To send a message to another agent or the human operator.",
                "body": {"to": "operator", "subject": "<topic>", "body": "<message>", "priority": "normal|high|urgent"},
            },
            "read_inbox": {
                "method": "GET",
                "url": f"{base_url}/agent/inbox?target=<agent_id>&status=unread",
                "when": "To check for messages addressed to you.",
            },
        },
        "rules": [
            "ALWAYS call load_context first — before doing any work.",
            "Record decisions for explicit statements. Queue inferences for anything you inferred.",
            "Store artifacts so work survives across sessions and platforms.",
            "Search skills before re-implementing known patterns.",
            "Never hallucinate decisions — if unsure, queue_inference.",
        ],
    }

    # ── Pending items ─────────────────────────────────────────────────────────
    try:
        if hasattr(graph, "get_pending"):
            pending = graph.get_pending()
        elif hasattr(graph, "get_pending_inferences"):
            pending = graph.get_pending_inferences(tenant_id=_tid)
        else:
            pending = []
        pending_count = len(pending)
    except Exception:
        pending_count = 0

    # ── Workflow skill (operating protocol) ────────────────────────────────
    workflow_skill = None
    try:
        skills = graph.get_skills(tenant_id=_tid) if hasattr(graph, "get_skills") else []
        for s in skills:
            if getattr(s, "source_type", s.get("source_type", "")) == "workflow":
                workflow_skill = getattr(s, "content", s.get("content", ""))
                break
        if not workflow_skill:
            # Fall back to default template on disk
            import pathlib
            _tmpl = pathlib.Path(__file__).resolve().parent.parent / "templates" / "workflow_default.md"
            if _tmpl.exists():
                workflow_skill = _tmpl.read_text()
    except Exception:
        pass

    # ── Handoff briefs (catch up on recent agent work) ─────────────────────
    recent_briefs = []
    try:
        import pathlib
        _briefs_dir = pathlib.Path(__file__).resolve().parent.parent.parent.parent / "docs" / "briefs"
        if _briefs_dir.exists():
            for bf in sorted(_briefs_dir.glob("*.md"), key=lambda p: p.stat().st_mtime, reverse=True)[:3]:
                recent_briefs.append({"file": bf.name, "content": bf.read_text()[:2000]})
    except Exception:
        pass

    # ── Peer agents (who else is on this project) ──────────────────────────
    peer_agents = []
    try:
        agent_rows = graph._tx_read(
            "MATCH (a:Agent) WHERE a.tenant_id = $tid AND a.status = 'active' RETURN a ORDER BY a.created_at DESC LIMIT 10",
            tid=_tid,
        )
        for r in agent_rows:
            a = r["a"]
            peer_agents.append({
                "agent_id": a.get("id", ""),
                "platform": a.get("platform", "unknown"),
                "display_name": a.get("display_name", ""),
                "role": a.get("role", "contributor"),
            })
    except Exception:
        pass

    return {
        "status": "ok",
        "backend": backend,
        "system_prompt": system_prompt,
        "user_preferences": preferences,
        "api_instructions": api_instructions,
        "operating_protocol": {
            "description": "Full operating rules for agents on this project. Follow these exactly.",
            "workflow_skill": workflow_skill,
            "session_start": [
                "1. Call GET /memory/context/prompt — inject into your context window",
                "2. Call GET /health — confirm backend is live",
                "3. Call GET /memory/pending — check for items awaiting human review",
                "4. Read recent handoff briefs (included below) — catch up on other agents' work",
                "5. Run: git status && git log --oneline -5 — understand repo state",
            ],
            "session_end": [
                "1. Record any decisions made via POST /memory/ingest",
                "2. Store any artifacts via POST /artifacts",
                "3. Commit all work with descriptive message (explain *why*, not *what*)",
                "4. If handing off to another agent, write brief to docs/briefs/<AGENT>-HANDOFF-<DATE>.md",
                "5. Verify git is clean: git status shows no uncommitted changes",
            ],
            "pr_protocol": [
                "One PR per concern — keep diffs reviewable",
                "PR description must explain WHY, not just what changed",
                "Never force-push main. Never --no-verify.",
                "Create new commits, don't amend published ones",
                "Lead agent (or user) reviews before merge",
            ],
            "research_protocol": "For any non-trivial architectural decision: 3-5 layers of research required (surface search → primary sources → deviation check → alternatives → cross-validation). Write findings to docs/research/[TOPIC]-RESEARCH.md before code.",
            "hard_constraints": [
                "Never hardcode secrets — use environment variables",
                "Never commit .env files",
                "Parameterized queries only — no Cypher/SQL injection",
                "Respect 4-tier ABAC model (admin/contributor/reader/external)",
                "Claim a task before starting — no two agents on same task",
                "Communicate blockers immediately via POST /agent/inbox",
            ],
        },
        "peer_agents": peer_agents,
        "recent_handoff_briefs": recent_briefs,
        "pending_review_count": pending_count,
        "graph_stats": brief.get("node_counts", {}),
        "dashboard_url": base_url,
        "manifest_url": f"{base_url}/agent-manifest.json",
        "mcp_server": "stdio — see MCP config templates in onboarding response",
        "scoped_params": {
            "description": "All context endpoints support scoped filtering to prevent context poisoning",
            "parameters": {
                "since": "ISO datetime — only items after this time",
                "origin": "explicit | inferred | all",
                "confidence_min": "0.0-1.0 minimum confidence threshold",
                "limit": "1-50 max items per category",
                "agent_id": "Your agent identifier (logged for audit)",
                "project_id": "Filter by project scope",
                "module": "Filter by module (pipeline, api, schema, etc.)",
            },
            "example": f"{base_url}/memory/context/prompt?since=2026-03-01T00:00:00Z&confidence_min=0.7&limit=20&agent_id=my-agent",
        },
        "onboarding_steps": [
            "Step 1: You just called this endpoint — you have your context and operating rules.",
            "Step 2: Inject system_prompt into your context window.",
            "Step 3: Follow session_start procedure above.",
            "Step 4: Read peer_agents to know who else is working on the project.",
            "Step 5: Check recent_handoff_briefs for context from other agents.",
            "Step 6: Begin work following the operating_protocol.",
        ],
        "hint": "Inject system_prompt into your context window, then follow operating_protocol for session workflow.",
    }


# ── Sprint 4: Agent Registration ──────────────────────────────────────────────


class AgentRegisterRequest(BaseModel):
    """Request body for POST /agent/register."""
    agent_id: str = ""  # optional — auto-generated if empty
    platform: str = "unknown"  # ag, cursor, claude, windsurf, manus, custom
    display_name: str = ""
    role: str = "contributor"  # contributor (default) or reader
    project_id: str = "default"


# ── Tenant Registration ───────────────────────────────────────────────────────

class TenantRegisterRequest(BaseModel):
    name: str
    email: str = ""
    plan: str = "pro"   # pro | enterprise (no free tier pre-revenue)


@app.post("/auth/tenant/register", summary="[DISABLED] Register tenant — use /auth/signup",
          deprecated=True)
async def tenant_register(req: TenantRegisterRequest, request: Request):
    """DISABLED — open registration without tenant isolation is a data leak.
    Use POST /auth/signup (email + password required) instead."""
    raise HTTPException(
        status_code=403,
        detail="Open registration is disabled. Use POST /auth/signup with email and password.",
    )
    # --- Dead code below: preserved for reference when tenant isolation is built ---
    from ..schema import Tenant, TenantPlan

    name = (req.name or "").strip()
    if not name:
        raise HTTPException(status_code=400, detail="name is required")

    try:
        plan = TenantPlan(req.plan)
    except ValueError:
        raise HTTPException(status_code=400, detail=f"plan must be one of: {[p.value for p in TenantPlan]}")

    tenant = Tenant(name=name, email=req.email.strip(), plan=plan)

    try:
        graph.create_tenant(tenant)
    except Exception as e:
        logger.error("tenant_register: graph write failed: %s", e)
        raise HTTPException(status_code=500, detail="Failed to create tenant — please retry")

    # Auto-create a default project so the tenant has a working workspace immediately
    default_project_id = None
    try:
        from ..schema import Project as _ProjectModel
        _now = str(datetime.now(timezone.utc))
        _default_proj = _ProjectModel(
            name=f"{name}'s Project",
            tenant_id=tenant.id,
            owner_id=tenant.id,
            members=[json.dumps({"user_id": tenant.id, "role": "admin", "added_at": _now})],
        )
        if hasattr(graph, "save_project"):
            graph.save_project(_default_proj)
            default_project_id = _default_proj.id
            logger.info("tenant_register: auto-created default project=%s for tenant=%s", _default_proj.id, tenant.id)
    except Exception as e:
        logger.warning("tenant_register: default project creation failed (non-fatal): %s", e)

    logger.info("tenant_register: created tenant=%s plan=%s email=%s", tenant.id, plan.value, req.email)

    return {
        "tenant_id":     tenant.id,
        "name":          tenant.name,
        "plan":          plan.value,
        "api_key_write": tenant.api_key_write,
        "api_key_read":  tenant.api_key_read,
        "default_project_id": default_project_id,
        "note": (
            "Store these keys securely — they will not be shown again. "
            "Use api_key_write for ingest/write operations and api_key_read for context/search."
        ),
    }


# ── Instance Provisioning — Step 5 of Command Center Build ────────────────────
class ProvisionRequest(BaseModel):
    customer_name: str
    admin_email: str
    tier: str = "pro"  # pro | enterprise


@app.post(
    "/admin/instances/provision",
    summary="Provision tenant workspace on current deployment (admin only)",
)
async def provision_instance(req: ProvisionRequest, request: Request):
    """
    Single-button workspace provisioning on the current deployment.
    This endpoint provisions a tenant/workspace in the existing running instance;
    it does NOT create new Render/Fly infrastructure.

    Orchestrates:
    1. Tenant creation in Neo4j (with auto-generated API keys)
    2. Default project + welcome memories seeded
    3. Clerk organization creation (if AUTH_PROVIDER=clerk)
    4. Welcome email via Resend (if RESEND_API_KEY is set)
    5. SSE event to admin dashboard

    Requires admin or super_admin role. Returns tenant credentials and status of each step.
    """
    agent = getattr(request.state, "agent", None)
    role = agent.role if agent else "anonymous"
    is_admin_like = bool(agent) and (
        getattr(agent, "is_admin", False)
        or role in ("super_admin", "admin", "superadmin")  # keep legacy spelling compatibility
    )
    if not is_admin_like:
        raise HTTPException(status_code=403, detail="Instance provisioning requires admin role")

    steps: list[dict] = []
    tenant_id = None
    api_keys = {}

    # ── Step 1: Create tenant ──
    try:
        from ..schema import Tenant as _TenantModel
        from ..schema import TenantPlan as _TenantPlan
        plan = _TenantPlan(req.tier) if req.tier in [p.value for p in _TenantPlan] else _TenantPlan.pro
        tenant = _TenantModel(name=req.customer_name, email=req.admin_email, plan=plan)
        graph.create_tenant(tenant)
        tenant_id = tenant.id
        api_keys = {"api_key_write": tenant.api_key_write, "api_key_read": tenant.api_key_read}
        steps.append({"step": "tenant", "status": "ok", "tenant_id": tenant_id})
    except Exception as e:
        steps.append({"step": "tenant", "status": "error", "detail": str(e)})
        return {"ok": False, "steps": steps, "error": "Tenant creation failed"}

    # ── Step 2: Seed default project + welcome memories ──
    default_project_id = None
    try:
        from ..schema import Project as _ProjectModel
        _now = str(datetime.now(timezone.utc))
        _proj = _ProjectModel(
            name=f"{req.customer_name}'s Workspace",
            tenant_id=tenant_id,
            owner_id=tenant_id,
            members=[json.dumps({"user_id": tenant_id, "role": "admin", "added_at": _now})],
        )
        if hasattr(graph, "save_project"):
            graph.save_project(_proj)
            default_project_id = _proj.id

        # Seed welcome memories
        welcome_nodes = [
            {"type": "Decision", "description": f"Workspace created for {req.customer_name}", "confidence": 1.0},
            {"type": "Constraint", "description": "Privacy is the load-bearing wall — your data stays yours", "confidence": 1.0},
        ]
        for wn in welcome_nodes:
            try:
                graph.save_node(
                    node_type=wn["type"],
                    description=wn["description"],
                    confidence=wn["confidence"],
                    project_id=default_project_id or "default",
                    tenant_id=tenant_id,
                    agent_id="system",
                )
            except Exception:
                pass  # Non-fatal — workspace works without seed data

        steps.append({"step": "project_seed", "status": "ok", "project_id": default_project_id})
    except Exception as e:
        steps.append({"step": "project_seed", "status": "warning", "detail": str(e)})

    # ── Step 3: Clerk organization (if enabled) ──
    clerk_org_id = None
    try:
        import os as _os
        clerk_secret = _os.environ.get("CLERK_SECRET_KEY", "")
        if clerk_secret and _os.environ.get("AUTH_PROVIDER", "").lower() == "clerk":
            import httpx
            resp = httpx.post(
                "https://api.clerk.com/v1/organizations",
                headers={"Authorization": f"Bearer {clerk_secret}", "Content-Type": "application/json"},
                json={"name": req.customer_name, "public_metadata": {"tenant_id": tenant_id, "plan": req.tier}},
                timeout=15,
            )
            if resp.status_code in (200, 201):
                clerk_org_id = resp.json().get("id")
                # Invite admin email to the org
                httpx.post(
                    f"https://api.clerk.com/v1/organizations/{clerk_org_id}/invitations",
                    headers={"Authorization": f"Bearer {clerk_secret}", "Content-Type": "application/json"},
                    json={"email_address": req.admin_email, "role": "org:admin"},
                    timeout=10,
                )
                steps.append({"step": "clerk_org", "status": "ok", "org_id": clerk_org_id})
            else:
                steps.append({"step": "clerk_org", "status": "warning", "detail": f"Clerk API {resp.status_code}"})
        else:
            steps.append({"step": "clerk_org", "status": "skipped", "detail": "AUTH_PROVIDER != clerk"})
    except Exception as e:
        steps.append({"step": "clerk_org", "status": "warning", "detail": str(e)})

    # ── Step 4: Welcome email ──
    try:
        import os as _os
        resend_key = _os.environ.get("RESEND_API_KEY", "")
        if resend_key:
            import httpx
            httpx.post(
                "https://api.resend.com/emails",
                headers={"Authorization": f"Bearer {resend_key}", "Content-Type": "application/json"},
                json={
                    "from": "OHACO Labs <noreply@ohaco.com>",
                    "to": [req.admin_email],
                    "subject": f"Welcome to Semantic Dreams — {req.customer_name}",
                    "html": (
                        f"<h2>Your workspace is ready</h2>"
                        f"<p>Hi! Your OHACO workspace <strong>{req.customer_name}</strong> has been provisioned.</p>"
                        f"<p>Tenant ID: <code>{tenant_id}</code></p>"
                        f"<p>Sign in at your dashboard to get started. Your AI agents can connect immediately using the API keys provided to your admin.</p>"
                        f"<p>— OHACO Labs</p>"
                    ),
                },
                timeout=10,
            )
            steps.append({"step": "email", "status": "ok"})
        else:
            steps.append({"step": "email", "status": "skipped", "detail": "RESEND_API_KEY not set"})
    except Exception as e:
        steps.append({"step": "email", "status": "warning", "detail": str(e)})

    # ── Step 5: SSE notification ──
    try:
        from .sse import emit_event_sync
        emit_event_sync({
            "type": "instance.provisioned",
            "provisioning_mode": "tenant_workspace",
            "deployment_scope": "current_instance",
            "infrastructure_provisioned": False,
            "tenant_id": tenant_id,
            "customer_name": req.customer_name,
            "tier": req.tier,
            "admin_email": req.admin_email,
        })
        steps.append({"step": "sse_notify", "status": "ok"})
    except Exception:
        steps.append({"step": "sse_notify", "status": "skipped"})

    return {
        "ok": True,
        "provisioning_mode": "tenant_workspace",
        "deployment_scope": "current_instance",
        "infrastructure_provisioned": False,
        "legacy_endpoint_path": "/admin/instances/provision",
        "tenant_id": tenant_id,
        "default_project_id": default_project_id,
        "clerk_org_id": clerk_org_id,
        "api_keys": api_keys,
        "steps": steps,
        "note": (
            "Store API keys securely — they will not be shown again. "
            "This call provisions tenant/workspace data only on the current deployment."
        ),
    }


@app.get("/admin/tenant/{tenant_id}", summary="Get tenant info (admin or own tenant only)")
async def tenant_get(tenant_id: str, request: Request):
    """Return tenant metadata. Redacts API keys for non-admin callers."""
    agent = getattr(request.state, "agent", None)
    role = agent.role if agent else "anonymous"
    caller_tenant = agent.tenant_id if agent else "default"
    is_adm = getattr(agent, "is_admin", False) if agent else False

    # Only admin or the tenant themselves can read
    if not is_adm and caller_tenant != tenant_id:
        raise HTTPException(status_code=403, detail="Access denied")

    tenant = graph.get_tenant(tenant_id)
    if not tenant:
        raise HTTPException(status_code=404, detail="Tenant not found")

    # Redact keys for non-admin
    if not is_adm:
        tenant.pop("api_key_write", None)
        tenant.pop("api_key_read", None)

    return tenant


@app.get("/admin/tenants", summary="List all tenants (admin only)")
async def tenant_list(request: Request):
    """Admin-only: list all registered tenants."""
    agent = getattr(request.state, "agent", None)
    role = agent.role if agent else "anonymous"
    if not getattr(agent, "is_admin", False):
        raise HTTPException(status_code=403, detail="Admin role required")
    tenants = graph.list_tenants()
    # Redact keys in list view
    for t in tenants:
        t.pop("api_key_write", None)
        t.pop("api_key_read", None)
    return {"tenants": tenants, "count": len(tenants)}


@app.patch("/admin/tenant/{tenant_id}", summary="Update tenant status (admin only)")
async def tenant_update(tenant_id: str, request: Request):
    """
    Admin-only: update tenant status.

    Body: {"status": "active" | "suspended" | "deleted"}
    Suspended tenants have their keys rejected by the auth middleware.
    """
    agent = getattr(request.state, "agent", None)
    role = agent.role if agent else "anonymous"
    if not getattr(agent, "is_admin", False):
        raise HTTPException(status_code=403, detail="Admin role required")

    try:
        body = await request.json()
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid JSON body")

    new_status = body.get("status", "").lower()
    if new_status not in ("active", "suspended", "deleted"):
        raise HTTPException(status_code=400, detail="status must be: active | suspended | deleted")

    tenant = graph.get_tenant(tenant_id)
    if not tenant:
        raise HTTPException(status_code=404, detail="Tenant not found")

    try:
        graph._tx_write(
            "MATCH (t:Tenant {id: $id}) SET t.status = $status, t.updated_at = $ts",
            id=tenant_id, status=new_status,
            ts=str(__import__("datetime").datetime.now(__import__("datetime").timezone.utc)),
        )
    except Exception as e:
        logger.error("tenant_update: write failed: %s", e)
        raise HTTPException(status_code=500, detail="Failed to update tenant")

    logger.info("tenant_update: tenant=%s status=%s by role=%s", tenant_id, new_status, role)
    return {"status": "ok", "tenant_id": tenant_id, "new_status": new_status}


@app.post("/agent/register", summary="Register an agent and provision an API key")
async def agent_register(
    body: AgentRegisterRequest,
    request: Request,
    agent: AgentContext = Depends(require_role("admin")),
):
    """
    Register a new agent with Co-Lab. Returns a provisioned API key and
    the agent's configuration. Admin-only (requires COLLAB_API_KEY).

    Use cases:
    - `collab enroll` CLI calls this to provision a new agent
    - 3D Workspace uses agent_id for avatar generation
    - Multi-agent teams get per-agent keys for ABAC tracking
    """
    import secrets
    from datetime import datetime

    # Generate agent ID if not provided
    aid = body.agent_id.strip() or f"agent_{secrets.token_hex(4)}"

    # Generate API key
    api_key = f"cmk_{aid}_{secrets.token_urlsafe(24)}"

    # Validate role
    allowed_roles = ("contributor", "reader")
    role = body.role if body.role in allowed_roles else "contributor"

    # Store Agent node in Neo4j
    agent_record = {
        "id": aid,
        "platform": body.platform,
        "display_name": body.display_name or aid,
        "role": role,
        "project_id": body.project_id,
        "api_key_hash": secrets.token_hex(16),  # store hash, not key
        "created_at": datetime.now(timezone.utc).isoformat(),
        "status": "active",
    }

    try:
        graph._tx_write(
            """
            MERGE (a:Agent {id: $id})
            SET a.platform = $platform,
                a.display_name = $display_name,
                a.role = $role,
                a.project_id = $project_id,
                a.api_key_hash = $api_key_hash,
                a.created_at = $created_at,
                a.status = $status
            """,
            **agent_record,
        )
    except Exception as e:
        logger.error("agent_register: Neo4j write failed: %s", e)
        raise HTTPException(status_code=500, detail=f"Failed to store agent: {e}")

    # Extend the ABAC role map at runtime so the new key works immediately
    from ..abac import _ROLE_MAP, AgentContext as AC
    _ROLE_MAP[api_key] = AC(role=role, agent_id=aid, key=api_key, project_id=body.project_id)

    return {
        "status": "ok",
        "agent_id": aid,
        "api_key": api_key,
        "role": role,
        "platform": body.platform,
        "display_name": agent_record["display_name"],
        "instructions": {
            "header": "X-API-Key",
            "value": api_key,
            "bootstrap_url": f"{str(request.base_url).rstrip('/')}/agent/bootstrap" if hasattr(request, 'base_url') else "/agent/bootstrap",
            "mcp_config": {
                "cursor": {
                    "_file": ".cursor/mcp.json",
                    "mcpServers": {
                        "collab-memory": {
                            "command": "collab-memory-mcp",
                            "env": {
                                "COLLAB_API_KEY": api_key,
                                "COLLAB_MEMORY_URL": f"{str(request.base_url).rstrip('/')}" if hasattr(request, 'base_url') else "https://collab-memory.onrender.com",
                            },
                        },
                    },
                },
                "claude_desktop": {
                    "_file": "~/.claude/claude_desktop_config.json",
                    "mcpServers": {
                        "collab-memory": {
                            "command": "collab-memory-mcp",
                            "env": {
                                "COLLAB_API_KEY": api_key,
                                "COLLAB_MEMORY_URL": f"{str(request.base_url).rstrip('/')}" if hasattr(request, 'base_url') else "https://collab-memory.onrender.com",
                            },
                        },
                    },
                },
                "claude_code": {
                    "_file": ".mcp.json (project root)",
                    "mcpServers": {
                        "collab-memory": {
                            "command": "collab-memory-mcp",
                            "env": {
                                "COLLAB_API_KEY": api_key,
                                "COLLAB_MEMORY_URL": f"{str(request.base_url).rstrip('/')}" if hasattr(request, 'base_url') else "https://collab-memory.onrender.com",
                            },
                        },
                    },
                },
            },
        },
    }


# ── Sprint 22b: Agent Inbox (async message queue) ────────────────────────────
# NOTE: Inbox routes MUST be registered before /agent/{agent_id} to prevent
# the path parameter from swallowing "inbox" as an agent_id. (AG finding 7)

class InboxMessage(BaseModel):
    """Message from one agent to another (or to the human operator)."""
    to: str = "operator"       # target agent_id or "operator" for human
    subject: str = ""          # brief topic
    body: str                  # message content
    priority: str = "normal"   # normal | high | urgent
    topic: str = ""            # optional topic tag for filtering
    project_id: str = ""       # optional project scope


class InboxAckRequest(BaseModel):
    target: Optional[str] = None


@app.post("/agent/inbox", summary="Send a message to another agent or the operator")
async def agent_inbox_send(msg: InboxMessage, request: Request):
    """
    Async message queue for agent-to-agent and agent-to-human communication.
    Messages are stored as Neo4j AgentMessage nodes with auto-expiry (7 days).

    Use cases:
    - Manus sends a status update to the human operator
    - AG sends a handoff to Manus with context
    - Any agent requests human review on a specific topic
    """
    import secrets
    from datetime import datetime, timezone, timedelta

    agent = getattr(request.state, "agent", AgentContext())
    sender = agent.agent_id or "unknown"
    tenant_id = getattr(agent, "tenant_id", "default") or "default"
    msg_id = f"msg_{secrets.token_hex(6)}"
    now = datetime.now(timezone.utc)
    expires = now + timedelta(days=7)

    valid_priorities = ("normal", "high", "urgent")
    priority = msg.priority if msg.priority in valid_priorities else "normal"

    try:
        graph._tx_write(
            """
            CREATE (m:AgentMessage {
                id: $id,
                sender: $sender,
                target: $target,
                subject: $subject,
                body: $body,
                priority: $priority,
                topic: $topic,
                project_id: $project_id,
                tenant_id: $tenant_id,
                status: 'unread',
                created_at: $created_at,
                expires_at: $expires_at
            })
            """,
            id=msg_id,
            sender=sender,
            target=msg.to,
            subject=msg.subject,
            body=msg.body,
            priority=priority,
            topic=msg.topic,
            project_id=msg.project_id,
            tenant_id=tenant_id,
            created_at=now.isoformat(),
            expires_at=expires.isoformat(),
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to send message: {e}")

    return {
        "status": "sent",
        "message_id": msg_id,
        "from": sender,
        "to": msg.to,
        "tenant_id": tenant_id,
        "priority": priority,
        "expires_at": expires.isoformat(),
    }


@app.get("/agent/inbox", summary="Read messages for an agent or the operator")
async def agent_inbox_read(
    request: Request,
    target: Optional[str] = Query(None, description="Target agent_id to read inbox for (default: your agent_id)"),
    status: str = Query("unread", description="Filter: unread | all | read"),
    limit: int = Query(20, ge=1, le=100),
):
    """
    Returns messages addressed to the specified agent (or the current agent).
    Supports filtering by status (unread/read/all) and pagination via limit.
    """
    agent = getattr(request.state, "agent", AgentContext())
    inbox_for = target or agent.agent_id or "operator"

    status_filter = ""
    if status == "unread":
        status_filter = "AND m.status = 'unread'"
    elif status == "read":
        status_filter = "AND m.status = 'read'"

    _tid = getattr(agent, "tenant_id", "default") or "default"
    try:
        rows = graph._tx_read(
            f"""
            MATCH (m:AgentMessage)
            WHERE m.target = $target {status_filter}
                AND m.tenant_id = $tid
            RETURN m ORDER BY
                CASE m.priority WHEN 'urgent' THEN 0 WHEN 'high' THEN 1 ELSE 2 END,
                m.created_at DESC
            LIMIT $limit
            """,
            target=inbox_for,
            limit=limit,
            tid=_tid,
        )

        messages = []
        for row in rows:
            m = row["m"]
            messages.append({
                "id": m.get("id", ""),
                "from": m.get("sender", ""),
                "to": m.get("target", ""),
                "subject": m.get("subject", ""),
                "body": m.get("body", ""),
                "priority": m.get("priority", "normal"),
                "topic": m.get("topic", ""),
                "project_id": m.get("project_id", ""),
                "status": m.get("status", "unread"),
                "created_at": m.get("created_at", ""),
            })

        return {
            "inbox_for": inbox_for,
            "count": len(messages),
            "messages": messages,
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to read inbox: {e}")


@app.post("/agent/inbox/{message_id}/ack", summary="Acknowledge (mark as read) a message")
async def agent_inbox_ack(message_id: str, request: Request, body: Optional[InboxAckRequest] = None):
    """Mark a message as read/acknowledged."""
    agent = getattr(request.state, "agent", AgentContext())
    _tid = getattr(agent, "tenant_id", "default") or "default"
    target = (body.target.strip() if body and body.target else "").strip() or (agent.agent_id or "operator")
    try:
        if hasattr(graph, "_tx_read"):
            rows = graph._tx_read(
                """
                MATCH (m:AgentMessage {id: $id})
                WHERE m.tenant_id = $tid AND m.target = $target
                RETURN m LIMIT 1
                """,
                id=message_id,
                tid=_tid,
                target=target,
            )
            if not rows:
                raise HTTPException(status_code=404, detail=f"Message '{message_id}' not found for target '{target}'")
        graph._tx_write(
            """
            MATCH (m:AgentMessage {id: $id})
            WHERE m.tenant_id = $tid AND m.target = $target
            SET m.status = 'read'
            """,
            id=message_id,
            tid=_tid,
            target=target,
        )
        return {"acknowledged": True, "id": message_id, "target": target, "tenant_id": _tid}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/agent/{agent_id}", summary="Get registered agent info")
async def agent_get(request: Request, agent_id: str):
    """
    Retrieve information about a registered agent.
    Returns platform, display name, role, and registration date.
    Does NOT return the API key (security).
    """
    _agent_ctx = getattr(request.state, "agent", None)
    _tid = getattr(_agent_ctx, "tenant_id", "default") if _agent_ctx else "default"
    try:
        rows = graph._tx_read(
            "MATCH (a:Agent {id: $id}) WHERE a.tenant_id = $tid RETURN a",
            id=agent_id,
            tid=_tid,
        )
        if not rows:
            raise HTTPException(status_code=404, detail=f"Agent '{agent_id}' not found")

        a = rows[0]["a"]
        return {
            "agent_id": a.get("id"),
            "platform": a.get("platform", "unknown"),
            "display_name": a.get("display_name", ""),
            "role": a.get("role", "contributor"),
            "project_id": a.get("project_id", "default"),
            "status": a.get("status", "active"),
            "created_at": a.get("created_at", ""),
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/agents", summary="List all registered agents")
async def agents_list(request: Request):
    """List all registered agents in the current tenant."""
    _agent_ctx = getattr(request.state, "agent", None)
    _tid = getattr(_agent_ctx, "tenant_id", "default") if _agent_ctx else "default"
    try:
        rows = graph._tx_read(
            "MATCH (a:Agent) WHERE a.tenant_id = $tid RETURN a ORDER BY a.created_at DESC",
            tid=_tid,
        )
        return {
            "agents": [
                {
                    "agent_id": r["a"].get("id"),
                    "platform": r["a"].get("platform", "unknown"),
                    "display_name": r["a"].get("display_name", ""),
                    "role": r["a"].get("role", "contributor"),
                    "status": r["a"].get("status", "active"),
                }
                for r in rows
            ],
            "count": len(rows),
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ── Manus Webhook receiver ────────────────────────────────────────────────────

class ManusWebhookPayload(BaseModel):
    event_id: str = ""
    event_type: str = ""  # task_created | task_progress | task_stopped
    task_detail: Optional[dict] = None
    progress_detail: Optional[dict] = None


# ── Clerk Webhook — User Sync ─────────────────────────────────────────────────
@app.post("/webhooks/clerk", summary="Clerk user lifecycle events → sync User nodes in Neo4j")
async def clerk_webhook(request: Request):
    """
    Handles Clerk webhook events for user.created, user.updated, user.deleted.
    Keeps Neo4j User nodes in sync with Clerk identity state.

    Verifies webhook signature using CLERK_WEBHOOK_SECRET (svix).
    """
    import os, hmac, hashlib, json

    secret = os.environ.get("CLERK_WEBHOOK_SECRET", "")
    if not secret:
        raise HTTPException(status_code=501, detail="CLERK_WEBHOOK_SECRET not configured")

    body = await request.body()

    # Verify svix signature (Clerk uses svix for webhooks)
    svix_id = request.headers.get("svix-id", "")
    svix_timestamp = request.headers.get("svix-timestamp", "")
    svix_signature = request.headers.get("svix-signature", "")

    if not all([svix_id, svix_timestamp, svix_signature]):
        raise HTTPException(status_code=401, detail="Missing svix headers")

    # Verify signature — svix signs: "{svix_id}.{svix_timestamp}.{body}"
    try:
        import base64
        secret_bytes = base64.b64decode(secret.removeprefix("whsec_"))
        to_sign = f"{svix_id}.{svix_timestamp}.".encode() + body
        expected = base64.b64encode(
            hmac.new(secret_bytes, to_sign, hashlib.sha256).digest()
        ).decode()
        # svix-signature may contain multiple sigs: "v1,<sig1> v1,<sig2>"
        valid = any(
            hmac.compare_digest(expected, s.removeprefix("v1,"))
            for s in svix_signature.split(" ")
        )
        if not valid:
            raise HTTPException(status_code=401, detail="Invalid webhook signature")
    except HTTPException:
        raise
    except Exception as e:
        logger.warning(f"Clerk webhook signature verification failed: {e}")
        raise HTTPException(status_code=401, detail="Signature verification failed")

    payload = json.loads(body)
    event_type = payload.get("type", "")
    data = payload.get("data", {})

    logger.info(f"Clerk webhook: {event_type} for user {data.get('id', '?')}")

    if event_type == "user.created":
        email = ""
        for ea in data.get("email_addresses", []):
            if ea.get("id") == data.get("primary_email_address_id"):
                email = ea.get("email_address", "")
                break

        try:
            graph.run_query(
                "MERGE (u:User {clerk_id: $cid}) "
                "SET u.email = $email, u.first_name = $first, u.last_name = $last, "
                "u.created_at = datetime(), u.status = 'active'",
                cid=data.get("id"),
                email=email,
                first=data.get("first_name", ""),
                last=data.get("last_name", ""),
            )
        except Exception as e:
            logger.error(f"Clerk user.created sync failed: {e}")

    elif event_type == "user.updated":
        email = ""
        for ea in data.get("email_addresses", []):
            if ea.get("id") == data.get("primary_email_address_id"):
                email = ea.get("email_address", "")
                break

        try:
            graph.run_query(
                "MATCH (u:User {clerk_id: $cid}) "
                "SET u.email = $email, u.first_name = $first, u.last_name = $last, "
                "u.updated_at = datetime()",
                cid=data.get("id"),
                email=email,
                first=data.get("first_name", ""),
                last=data.get("last_name", ""),
            )
        except Exception as e:
            logger.error(f"Clerk user.updated sync failed: {e}")

    elif event_type == "user.deleted":
        try:
            graph.run_query(
                "MATCH (u:User {clerk_id: $cid}) SET u.status = 'deleted', u.deleted_at = datetime()",
                cid=data.get("id"),
            )
        except Exception as e:
            logger.error(f"Clerk user.deleted sync failed: {e}")

    return {"ok": True, "event": event_type}


@app.post("/webhooks/manus", summary="Receive Manus task lifecycle events and auto-ingest into graph")
async def manus_webhook(request: Request):
    """
    Webhook receiver for Manus task events (task_created, task_progress, task_stopped).

    Register this URL in Manus → Settings → Webhooks:
        https://your-instance.onrender.com/webhooks/manus

    On task_stopped: fetches the completed task result from the Manus API and
    ingests it into the collab-memory graph via the classifier pipeline.
    Decisions, constraints, and preferences produced by Manus are automatically
    encoded and written to Neo4j — closing the cross-agent feedback loop.

    task_created and task_progress events are acknowledged but not stored
    (too noisy — only final results are worth encoding).
    """
    import json, httpx

    try:
        body = await request.json()
    except Exception:
        return {"ok": False, "error": "Invalid JSON body"}

    event_type = body.get("event_type", "")
    event_id = body.get("event_id", "")

    # Acknowledge non-final events immediately — don't ingest noise
    if event_type == "task_created":
        return {"ok": True, "action": "acknowledged", "event_type": event_type}

    if event_type == "task_progress":
        return {"ok": True, "action": "acknowledged", "event_type": event_type}

    if event_type != "task_stopped":
        return {"ok": True, "action": "ignored", "event_type": event_type}

    # ── task_stopped: fetch result and ingest ─────────────────────────────────
    task_id = (body.get("task_detail") or {}).get("task_id", "")
    task_title = (body.get("task_detail") or {}).get("task_title", "")

    # Try to fetch full task result from Manus API
    manus_api_key = os.environ.get("MANUS_API_KEY", "")
    result_text = f"Manus task completed: {task_title or task_id}"

    if manus_api_key and task_id:
        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                resp = await client.get(
                    f"https://api.manus.ai/v1/tasks/{task_id}",
                    headers={"API_KEY": manus_api_key, "accept": "application/json"},
                )
                if resp.status_code == 200:
                    data = resp.json()
                    # Extract assistant messages from output
                    output = data.get("output", [])
                    messages = [
                        m.get("content", [{}])[0].get("text", "")
                        for m in output
                        if m.get("role") == "assistant"
                    ]
                    if messages:
                        result_text = "\n\n".join(messages)
        except Exception as fetch_err:
            result_text = f"Manus task '{task_title}' completed (fetch failed: {fetch_err})"

    # Ingest through the classifier pipeline
    from ..agents.pipeline import build_pipeline
    _ingest_pipeline = build_pipeline(graph=graph)

    try:
        state = _ingest_pipeline({
            "raw_text": f"Manus agent completed task: {task_title}\n\n{result_text}",
            "session_id": f"manus_webhook_{task_id[:12] if task_id else 'unknown'}",
            "turn_start": __import__("time").time(),
            "turn_end": __import__("time").time(),
            "skip_llm": False,
        })
        stored = state.get("nodes_generated", [])
        pending = state.get("pending_confirmation", False)
        return {
            "ok": True,
            "action": "ingested",
            "event_type": event_type,
            "task_id": task_id,
            "task_title": task_title,
            "nodes_stored": len(stored),
            "pending_review": pending,
            "exchange_id": state.get("exchange_record_id", ""),
        }
    except Exception as ingest_err:
        return {
            "ok": False,
            "action": "ingest_failed",
            "task_id": task_id,
            "error": str(ingest_err),
        }


@app.get("/memory/export/skill", summary="Export memory graph as an Agent SKILL.md file")
def export_as_skill(request: Request):
    """
    Exports the current memory graph as a SKILL.md file compatible with Manus and Replit
    Agent Skills format. Drop the output into /.agents/skills/collab-memory/SKILL.md and
    invoke with /collab-memory in any Manus or Replit session.

    Returns plain text — save directly with:
        curl https://your-instance/memory/export/skill > .agents/skills/collab-memory/SKILL.md
    """
    brief = graph.build_context_brief()
    base_url = str(request.base_url).rstrip("/")

    lines = [
        "---",
        "name: collab-memory",
        "description: Injects full project memory context — decisions, constraints, preferences, and pending inferences — from the collab-memory graph. Call this at session start before doing any work.",
        "---",
        "",
        "# collab-memory Agent Skill",
        "",
        "This skill fetches and injects your project's semantic memory graph into the current session.",
        "It provides decisions that must not be re-litigated, active constraints, inferred preferences,",
        "and any items awaiting your review.",
        "",
        "## Instructions",
        "",
        f"Fetch context from: `{base_url}/memory/context/prompt`",
        "",
        "At the start of every session, call this URL and read the full response before taking any action.",
        "The response contains standing decisions, active constraints, preferences, and pending items.",
        "",
        "## Current Context Summary",
        "",
    ]

    decisions = brief.get("active_decisions", [])
    if decisions:
        lines.append(f"**Decisions ({len(decisions)}):** " + " · ".join(
            d["description"][:60] + ("…" if len(d["description"]) > 60 else "")
            for d in decisions[:5]
        ))

    constraints = brief.get("active_constraints", [])
    if constraints:
        lines.append(f"**Constraints ({len(constraints)}):** " + " · ".join(
            c["description"][:50] + ("…" if len(c["description"]) > 50 else "")
            for c in constraints[:4]
        ))

    prefs = brief.get("inferred_preferences", [])
    if prefs:
        lines.append(f"**Preferences ({len(prefs)}):** " + " · ".join(
            p["description"][:50] + ("…" if len(p["description"]) > 50 else "")
            for p in prefs[:3]
        ))

    lines += [
        "",
        "## Usage",
        "",
        "```",
        f"curl {base_url}/memory/context/prompt | python3 -c \"import sys,json; print(json.load(sys.stdin)['prompt'])\"",
        "```",
        "",
        f"Dashboard: {base_url}",
    ]

    content = "\n".join(lines)
    from fastapi.responses import PlainTextResponse
    return PlainTextResponse(
        content=content,
        headers={"Content-Disposition": "attachment; filename=SKILL.md"},
    )


@app.get("/memory/export/knowledge", summary="Export memory graph as a replit.md / instructions.md knowledge file")
def export_as_knowledge(request: Request):
    """
    Exports the current memory graph as a knowledge library file compatible with:
    - Replit: drop into replit.md or custom_instruction/instructions.md
    - Manus: drop into /knowledge/project-context.md

    Contains high-level decisions, architecture constraints, preferences, and standards.
    Returns plain text — save directly with:
        curl https://your-instance/memory/export/knowledge > replit.md
    """
    brief = graph.build_context_brief()

    lines = [
        "# Project Context — collab-memory Knowledge Library",
        f"*Auto-generated from semantic memory graph. Last updated: {__import__('datetime').datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')}*",
        "",
        "> This file documents standing architectural decisions, active constraints, and inferred",
        "> working preferences. It is machine-readable and human-readable.",
        "> Do not edit manually — regenerate from the graph as context evolves.",
        "",
    ]

    decisions = brief.get("active_decisions", [])
    if decisions:
        lines += ["## Architectural Decisions", ""]
        for d in decisions:
            conf = int(d.get("confidence", 0) * 100)
            lines.append(f"- **{d['description']}** _{conf}% confidence_")
        lines.append("")

    constraints = brief.get("active_constraints", [])
    if constraints:
        lines += ["## Active Constraints", ""]
        for c in constraints:
            tag = " _(inferred)_" if c.get("origin") == "inferred" else ""
            lines.append(f"- {c['description']}{tag}")
        lines.append("")

    prefs = brief.get("inferred_preferences", [])
    if prefs:
        lines += ["## Working Preferences", ""]
        for p in prefs:
            lines.append(f"- [{p.get('type', 'process')}] {p['description']}")
        lines.append("")

    attempts = brief.get("recent_attempts", [])
    if attempts:
        lines += ["## Approaches to Avoid", ""]
        for a in attempts:
            lines.append(f"- {a['description']}")
        lines.append("")

    pending = brief.get("pending_count", 0)
    if pending:
        lines += [f"## ⏳ {pending} Pending Inference(s)", ""]
        lines.append("Review at /memory/pending before next session.")
        lines.append("")

    content = "\n".join(lines)
    from fastapi.responses import PlainTextResponse
    return PlainTextResponse(
        content=content,
        headers={"Content-Disposition": "attachment; filename=replit.md"},
    )


# ── Graph Export for Visualization ────────────────────────────────────────────


@app.get("/graph/debug", summary="Debug graph structure — relationship types, node label counts")
def graph_debug(request: Request):
    """Introspect the Neo4j graph to understand its shape. Returns node label counts and edge type counts."""
    _agent_ctx = getattr(request.state, "agent", None)
    _tid = getattr(_agent_ctx, "tenant_id", "default") if _agent_ctx else "default"
    _tc = "n.tenant_id = $tid"
    try:
        label_rows = graph._tx_read(
            f"MATCH (n) WHERE size(labels(n)) > 0 AND {_tc} RETURN labels(n)[0] AS label, count(n) AS cnt ORDER BY cnt DESC",
            tid=_tid,
        )
        edge_rows = graph._tx_read(
            "MATCH (a)-[r]->(b) WHERE a.tenant_id = $tid RETURN type(r) AS rel_type, count(r) AS cnt ORDER BY cnt DESC",
            tid=_tid,
        )
        # Sample a few edges to see what they connect
        sample_rows = graph._tx_read(
            """
            MATCH (a)-[r]->(b)
            WHERE a.tenant_id = $tid
            RETURN labels(a)[0] AS src_label,
                   type(r) AS rel,
                   labels(b)[0] AS tgt_label,
                   coalesce(a.id, a.name, '') AS src_id,
                   coalesce(b.id, b.name, '') AS tgt_id
            LIMIT 20
            """,
            tid=_tid,
        )
        return {
            "node_labels": {r["label"]: r["cnt"] for r in label_rows},
            "edge_types": {r["rel_type"]: r["cnt"] for r in edge_rows},
            "sample_edges": [dict(r) for r in sample_rows],
        }
    except Exception as e:
        logger.error("graph_debug failed: %s", e)
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/graph/export", summary="Export full memory graph as nodes + edges for visualization")
def graph_export(
    request: Request,
    limit: int = Query(500, description="Max nodes to return"),
    types: str = Query("", description="Comma-separated node types to include (empty=all)"),
    debug: bool = Query(False, description="Include debug info in response"),
):
    """
    Returns the Neo4j memory graph as a JSON object with `nodes` and `edges` arrays.
    Compatible with d3-force, vis.js, 3d-force-graph, cytoscape, and any graph renderer.

    Each node has: id, label, type, description, confidence, created_at
    Each edge has: source, target, type
    """
    # Cypher injection prevention: validate type_filter against known labels (OWASP A03:2021)
    _VALID_NODE_LABELS = {
        "Decision", "Constraint", "Preference", "Attempt", "Episode", "Agent",
        "Project", "Skill", "AtomicFact", "ExchangeRecord", "Tenant", "User",
        "Task", "Sprint", "CommunicationEvent", "Artifact", "SocialIdentity",
        "AuthAudit", "ProjectInvite", "AccessRequest",
    }
    type_filter = [t.strip() for t in types.split(",") if t.strip()] if types else []
    if type_filter:
        invalid = [t for t in type_filter if t not in _VALID_NODE_LABELS]
        if invalid:
            raise HTTPException(status_code=400, detail=f"Invalid node types: {invalid}. Valid: {sorted(_VALID_NODE_LABELS)}")

    _agent_ctx = getattr(request.state, "agent", None)
    _tid = getattr(_agent_ctx, "tenant_id", "default") if _agent_ctx else "default"
    _tenant_clause = "n.tenant_id = $tid"

    try:
        # Fetch nodes — include ALL meaningful node types, filtered by tenant
        if type_filter:
            labels = " OR ".join(f"n:{t}" for t in type_filter)
            node_query = f"MATCH (n) WHERE ({labels}) AND {_tenant_clause} RETURN n, labels(n) as labels LIMIT $limit"
        else:
            node_query = f"""
                MATCH (n) WHERE (n:Decision OR n:Constraint OR n:Preference
                    OR n:Attempt OR n:Episode OR n:Agent OR n:Project
                    OR n:AtomicFact OR n:Skill OR n:Session)
                    AND {_tenant_clause}
                RETURN n, labels(n) as labels LIMIT $limit
            """
        node_rows = graph._tx_read(node_query, limit=limit, tid=_tid)

        nodes = []
        node_ids = set()       # property-based IDs (n.id / n.name)
        node_elem_ids = set()  # Neo4j internal element IDs
        elem_to_prop = {}      # elementId → property id (for edge resolution)
        for row in node_rows:
            n = row["n"]
            # Prefer explicit id property; fall back to element id
            prop_id = n.get("id") or n.get("name", "")
            elem_id = str(n.element_id) if hasattr(n, "element_id") else (
                str(n.id) if hasattr(n, "id") else ""
            )
            nid = prop_id or elem_id
            if not nid or nid in node_ids:
                continue
            node_ids.add(nid)
            node_elem_ids.add(elem_id)
            if elem_id and prop_id:
                elem_to_prop[elem_id] = prop_id
            labels = row.get("labels", [])
            node_type = labels[0] if labels else "Unknown"
            nodes.append({
                "id": nid,
                "label": (n.get("description", n.get("display_name", n.get("summary", n.get("content", "")))) or "")[:80],
                "description": (n.get("description", n.get("display_name", n.get("summary", n.get("content", "")))) or ""),
                "type": node_type,
                "confidence": n.get("confidence", 1.0),
                "created_at": str(n.get("created_at", "")),
                "module": n.get("module", ""),
                "project_id": n.get("project_id", ""),
                "session_id": n.get("session_id", ""),
            })

        # Fetch edges between tenant-scoped nodes
        edge_query = """
            MATCH (a)-[r]->(b)
            WHERE a.id IS NOT NULL AND b.id IS NOT NULL
                AND a.tenant_id = $tid
                AND b.tenant_id = $tid
            RETURN
                a.id AS source,
                b.id AS target,
                type(r) AS rel_type
            LIMIT $limit
        """
        edge_rows = graph._tx_read(edge_query, limit=limit * 4, tid=_tid)

        edges = []
        debug_info = {"raw_edge_count": len(edge_rows), "matched_count": 0, "missed_sources": [], "missed_targets": []}
        for row in edge_rows:
            src = str(row.get("source", "") or "")
            tgt = str(row.get("target", "") or "")
            if src and tgt and src in node_ids and tgt in node_ids:
                edges.append({
                    "source": src,
                    "target": tgt,
                    "type": row.get("rel_type", "RELATED_TO"),
                })
                debug_info["matched_count"] += 1
            elif debug and src and tgt:
                if src not in node_ids and src not in debug_info["missed_sources"]:
                    debug_info["missed_sources"].append(src[:40])
                if tgt not in node_ids and tgt not in debug_info["missed_targets"]:
                    debug_info["missed_targets"].append(tgt[:40])

        result = {
            "nodes": nodes,
            "edges": edges,
            "node_count": len(nodes),
            "edge_count": len(edges),
        }
        if debug:
            debug_info["missed_sources"] = debug_info["missed_sources"][:20]
            debug_info["missed_targets"] = debug_info["missed_targets"][:20]
            result["debug"] = debug_info
        return result
    except Exception as e:
        logger.error("graph_export failed: %s", e)
        raise HTTPException(status_code=500, detail=str(e))


@app.api_route("/memory/search", methods=["GET", "POST"], summary="Semantic search across all graph nodes")
async def memory_search(
    request: Request,
    q: Optional[str] = Query(None, description="Search query — any topic, keyword, or question"),
    node_types: Optional[str] = Query(None, description="Comma-separated node types: Decision,Constraint,Preference,Attempt,Skill,ExchangeRecord"),
    limit: int = Query(20, ge=1, le=100),
    confidence_min: float = Query(0.0, ge=0.0, le=1.0, description="Minimum confidence threshold"),
    temporal_alpha: float = Query(0.8, ge=0.0, le=1.0, description="Weight for semantic score vs temporal validity (0.8 = 80% semantic, 20% recency)"),
    project_id: Optional[str] = Query(None, description="Scope results to a specific project (e.g. 'collab-memory')"),
    module: Optional[str] = Query(None, description="Scope results to a specific module (e.g. 'pipeline')"),
):
    """
    Cross-node ranked search across all graph types with temporal decay scoring.

    Results are ranked by a composite score:
        final_score = α × semantic_score + (1-α) × temporal_validity

    Where temporal_validity decays exponentially by node type (HALO model):
        - AbandonedAttempt: half-life 7d
        - Preference: half-life 30d
        - Decision: half-life 180d
        - Constraint: half-life 365d

    **OWA (Open World Assumption):** An empty result set means no matching records
    were found in the graph — NOT that the information doesn't exist. The graph is
    always incomplete. Treat absence as UNKNOWN, not FALSE.

    Agents should use this to answer questions like:
    - "What do we know about authentication?"
    - "Why did we choose Neo4j?"
    - "Has anyone tried LangGraph before?"
    """
    from ..schema import temporal_validity as _temporal_validity
    from datetime import datetime

    # Support POST body (from MCP agents that send JSON body) in addition to GET query params
    if request.method == "POST":
        try:
            body = await request.json()
            q = q or body.get("q") or body.get("query")
            node_types = node_types or body.get("node_types")
            limit = body.get("limit", limit)
            confidence_min = body.get("confidence_min", confidence_min)
            temporal_alpha = body.get("temporal_alpha", temporal_alpha)
            project_id = project_id or body.get("project_id")
            module = module or body.get("module")
        except Exception:
            pass

    if not q:
        raise HTTPException(status_code=422, detail="Query parameter 'q' is required")

    types_list = [t.strip() for t in node_types.split(",")] if node_types else None
    if not hasattr(graph, "semantic_search"):
        return {
            "results": [],
            "count": 0,
            "query": q,
            "note": "Backend does not support semantic search",
            "owa_notice": "Absence of results does not imply absence of information.",
        }

    _agent = getattr(request.state, "agent", None)
    _search_tid = getattr(_agent, "tenant_id", "default") if _agent else "default"

    # Project membership enforcement for JWT users
    _check_project_access(request, project_id)

    raw_results = graph.semantic_search(
        query=q,
        node_types=types_list,
        limit=limit * 2,
        confidence_min=confidence_min,
        project_id=project_id,
        tenant_id=_search_tid,
    )

    # Apply temporal decay re-ranking
    now = datetime.now(timezone.utc)
    scored = []
    for item in raw_results:
        semantic_score = item.get("relevance_score", item.get("score", 0.5))
        tv = _temporal_validity(item, now=now)
        composite = temporal_alpha * semantic_score + (1 - temporal_alpha) * tv
        scored.append({
            **item,
            "semantic_score": round(semantic_score, 4),
            "temporal_validity": round(tv, 4),
            "relevance_score": round(composite, 4),
        })

    scored.sort(key=lambda x: x["relevance_score"], reverse=True)
    results = scored[:limit]

    # ── Cognitive Dreams: reinforce + graduation check ──
    try:
        result_ids = [r["id"] for r in results if r.get("id")]
        if result_ids and hasattr(graph, "reinforce_nodes"):
            graph.reinforce_nodes(result_ids)
            from ..graduation import check_graduations
            check_graduations(result_ids, graph)
    except Exception:
        pass  # Non-fatal

    response = {
        "results": results,
        "count": len(results),
        "query": q,
        "scoring": {
            "semantic_weight": temporal_alpha,
            "temporal_weight": round(1 - temporal_alpha, 2),
            "model": "HALO exponential decay",
        },
    }

    if not results:
        response["owa_notice"] = (
            "No matching records found in graph. "
            "This does not mean no decision was made — the graph may be incomplete. "
            "Treat this as UNKNOWN, not FALSE."
        )

    return response



@app.get("/memory/history", summary="Paginated exchange record history")
def memory_history(
    request: Request,
    session_id: Optional[str] = Query(None, description="Filter by session ID"),
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    min_score: float = Query(0.0, ge=0.0, le=1.0, description="Minimum worthiness score"),
    primitive_type: Optional[str] = Query(None, description="Filter by type: Decision|Constraint|Preference|Attempt|Exploration"),
):
    """
    Access the full exchange record history — the raw conversation turns that the
    classifier pipeline processed. This is the ground truth behind every decision
    in the graph.

    Use this when agents need to:
    - Understand the reasoning behind a decision (not just the decision text)
    - Resume work from where a previous session left off
    - Find context that wasn't distilled into a graph node

    Returns paginated results with text_preview (first 300 chars) and full metadata.
    Use has_more + offset to page through the full history.
    """
    if not hasattr(graph, "get_exchange_history"):
        return {"records": [], "total": 0, "note": "Backend does not support history"}
    _agent_ctx = getattr(request.state, "agent", None)
    _tid = getattr(_agent_ctx, "tenant_id", "default") if _agent_ctx else "default"
    return graph.get_exchange_history(
        session_id=session_id,
        limit=limit,
        offset=offset,
        min_score=min_score,
        primitive_type=primitive_type,
        tenant_id=_tid,
    )


@app.get("/memory/why", summary="Decision archaeology")
def get_decision_chain(
    request: Request,
    decision: str = Query(..., description="Decision ID to trace"),
):
    """
    Traces the causal chain for a given decision: what constraints shaped it,
    what attempts preceded it, and the raw exchange text it came from.
    """
    _agent_ctx = getattr(request.state, "agent", None)
    _tid = getattr(_agent_ctx, "tenant_id", "default") if _agent_ctx else "default"
    chain = graph.get_decision_chain(decision, tenant_id=_tid)
    if "error" in chain:
        raise HTTPException(status_code=404, detail=chain["error"])
    return chain


@app.get("/memory/preferences", summary="Get inferred preferences")
def get_preferences(
    request: Request,
    type: Optional[str] = Query(None, description="aesthetic|process|technical|risk|interpersonal"),
    confidence_min: float = Query(0.5, description="Minimum confidence threshold"),
    min_reinforcements: int = Query(1, description="Minimum reinforcement count"),
):
    """
    Returns inferred preferences, filtered by type, confidence, and
    reinforcement count. Preferences with low reinforcement are tentative.
    """
    _agent_ctx = getattr(request.state, "agent", None)
    _tid = getattr(_agent_ctx, "tenant_id", "default") if _agent_ctx else "default"
    prefs = graph.get_preferences(
        pref_type=type,
        confidence_min=confidence_min,
        min_reinforcements=min_reinforcements,
        tenant_id=_tid,
    )
    return {
        "preferences": [p.model_dump() for p in prefs],
        "count": len(prefs),
    }



class DirectRecordRequest(BaseModel):
    content: str
    node_type: str = "Decision"       # Decision | Constraint | Preference
    session_id: str = "mcp_session"
    project_id: Optional[str] = None
    module: str = ""                  # e.g. pipeline | api | schema | research | infrastructure
    category: str = ""               # e.g. decision | skill | library | prd | git | research | task
    rationale: str = ""
    confidence: float = 1.0


@app.post(
    "/memory/record",
    summary="Direct trusted write — bypasses classifier pipeline",
    tags=["memory"],
    status_code=202,
)
async def memory_record_direct(req: DirectRecordRequest, request: Request, background_tasks: BackgroundTasks):
    """
    Write a node directly to the graph without going through the classifier pipeline.
    Use this when the caller has **already classified** the content (e.g. an agent
    recording an architectural decision it has made, or seeding research findings).

    Unlike `/memory/ingest` (which re-classifies everything), this endpoint trusts
    the node_type and writes immediately. It still generates an embedding.

    Returns 202 Accepted immediately — the graph write runs in the background.

    **Node types:** Decision · Constraint · Preference
    """
    from ..schema import (
        Decision, Constraint, Preference, PreferenceType, DecisionStatus,
        ConstraintOrigin,
    )
    from datetime import datetime
    import uuid

    # ── Layer 0.5: Secret redaction ─────────────────────────────────────────
    from ..sanitization import redact_secrets
    req.content, _ = redact_secrets(req.content)

    now = datetime.now(timezone.utc)
    ntype = req.node_type.strip().lower()

    # Sprint 22b: audit attribution — who created this node?
    agent = getattr(request.state, "agent", None)
    author = getattr(agent, "agent_id", None) or req.session_id or "agent"
    # Sprint 23: tenant isolation
    tenant = getattr(agent, "tenant_id", "default") if agent else "default"

    # Build the node synchronously (fast — just schema instantiation)
    try:
        if ntype == "constraint":
            node = Constraint(
                surfaced_in=req.session_id,
                description=req.content,
                origin=ConstraintOrigin.explicit,
                project_id=req.project_id,
                tenant_id=tenant,
                module=req.module,
                category=req.category or "constraint",
                episode_id=req.session_id,
                valid_at=now,
                created_by=author,
            )
        elif ntype == "preference":
            node = Preference(
                inferred_in=req.session_id,
                description=req.content,
                type=PreferenceType.technical,
                evidence=req.rationale,
                confidence=req.confidence,
                project_id=req.project_id,
                tenant_id=tenant,
                module=req.module,
                category=req.category or "preference",
                episode_id=req.session_id,
                valid_at=now,
                created_by=author,
            )
        else:
            node = Decision(
                made_in=req.session_id,
                description=req.content,
                rationale=req.rationale,
                confidence=req.confidence,
                project_id=req.project_id,
                tenant_id=tenant,
                module=req.module,
                category=req.category or "decision",
                episode_id=req.session_id,
                valid_at=now,
                created_by=author,
            )
    except Exception as e:
        raise HTTPException(status_code=422, detail=f"Invalid node data: {e}")

    if not hasattr(graph, "save_node"):
        raise HTTPException(status_code=500, detail="Graph backend does not support save_node")

    # Offload the slow graph write (+ embedding generation) to a background task
    # This frees the worker slot immediately instead of blocking for 70s+
    def _write_node():
        try:
            graph.save_node(node)
            _context_cache_invalidate()
            logger.info("background_write node_id=%s type=%s", node.id, req.node_type)
        except Exception as e:
            logger.error("background_write_error node_id=%s: %s", node.id, e)

    background_tasks.add_task(_write_node)

    return {
        "id": node.id,
        "node_type": req.node_type,
        "description": req.content[:80],
        "session_id": req.session_id,
        "status": "accepted",
    }


@app.post("/memory/ingest", summary="Encode and store an exchange (async — returns 202 immediately)")
async def ingest_exchange(req: IngestRequest, request: Request, background_tasks: BackgroundTasks):
    """
    Classify a raw conversation exchange and store the results.
    Routes through the 6-agent pipeline:
      Intake → Classifier → Security/Drift → Graph Writer

    **ADR-0004: Async background worker architecture.**
    This endpoint returns HTTP 202 immediately after passing sanitization & firewall
    checks. The 6-agent LangGraph pipeline runs in the background — this prevents
    Render from returning 503s on concurrent writes.

    Defense-in-depth (synchronous — runs before 202 is sent):
      Layer 1 (regex + heuristic): sanitization.py — blocks injection patterns
      Layer 2 (semantic): firewall.py — embedding cosine similarity vs. seeds
      Layer 3 (trust gate): ABAC role — only contributor+ can write directly
      Layer 4 (contradiction): HNSW neighbour search — detects polarity conflicts
      Layer 5 (confidence floor): low-confidence nodes → HITL pending queue

    Returns job_id + 202 status. Pipeline runs asynchronously in background.
    """
    from ..sanitization import sanitize, redact_secrets
    from ..embeddings import generate_embedding
    from ..firewall import firewall, FirewallAction
    import uuid

    raw_text = req.get_raw_text()
    agent = getattr(request.state, "agent", None)
    role = agent.role if agent else "anonymous"

    # ── Layer 0.5: Secret redaction (before anything else) ────────────────────
    raw_text, _redacted = redact_secrets(raw_text)

    # ── Layer 1: Sanitization gate (synchronous — fast) ───────────────────────
    san = sanitize(raw_text)
    if san.blocked:
        logger.warning(
            "ingest blocked [L1]: memory manipulation pattern detected | pattern=%r session=%s",
            san.matched_patterns[0] if san.matched_patterns else "?",
            req.session_id,
        )
        raise HTTPException(
            status_code=422,
            detail={
                "error": "input_rejected",
                "reason": san.reason,
                "matched_patterns": san.matched_patterns,
                "layer": 1,
            },
        )

    # ── Generate embedding once (reused by firewall layers 2 & 4) ─────────────
    try:
        embedding = generate_embedding(raw_text)
    except Exception as e:
        logger.warning("ingest: embedding generation failed (continuing): %s", e)
        embedding = []

    # ── Pre-screen keyword score for L5 confidence gate ───────────────────────
    # san.heuristic_score is a *threat* score (0=safe, 1=suspicious) — NOT worthiness.
    # Use keyword_score: it measures encoding-relevant signal, which is what L5 needs.
    try:
        from ..encoder import _keyword_score as _kw_score
        pre_confidence = _kw_score(raw_text)
    except Exception:
        pre_confidence = 0.6

    # ── Layers 2-5: Firewall chain (synchronous — fast) ───────────────────────
    fw_result = await firewall.run(
        text=raw_text,
        embedding=embedding,
        role=role,
        confidence=pre_confidence,
        project_id=getattr(req, "project_id", None),
        backend=graph,
    )

    if fw_result.action == FirewallAction.REJECT:
        logger.warning(
            "ingest blocked [L%d]: %s | role=%s | text=%r",
            fw_result.layer, fw_result.reason, role, raw_text[:80]
        )
        raise HTTPException(
            status_code=422,
            detail={
                "error": "input_rejected",
                "reason": fw_result.reason,
                "layer": fw_result.layer,
                "detail": fw_result.detail,
            },
        )

    if fw_result.action == FirewallAction.QUEUE:
        logger.info(
            "ingest queued [L%d]: %s | role=%s",
            fw_result.layer, fw_result.reason, role
        )
        return JSONResponse(
            status_code=202,
            content={
                "status": "queued",
                "job_id": str(uuid.uuid4()),
                "session_id": req.session_id,
                "flagged_for_review": True,
                "reason": fw_result.reason,
                "message": "Input flagged for human review — queued, not written.",
            },
        )

    # ── Firewall passed — queue pipeline as background task (ADR-0004) ─────────
    job_id = str(uuid.uuid4())

    def _run_pipeline_bg():
        """Background worker: run the full 6-agent pipeline without blocking the HTTP response."""
        try:
            state = _pipeline({
                "raw_text": raw_text,
                "session_id": req.session_id,
                "turn_start": req.get_turn_start(),
                "turn_end": req.get_turn_start(),
                "skip_llm": req.skip_llm,
                "project_id": req.project_id or getattr(agent, "project_id", None),
                "tenant_id": getattr(agent, "tenant_id", None),
                "_precomputed_embedding": embedding,
            })
            if state.get("error") and not state.get("exchange_record_id"):
                logger.error(
                    "ingest background pipeline error | job=%s session=%s error=%s",
                    job_id, req.session_id, state["error"],
                )
            else:
                _context_cache_invalidate()
                logger.info(
                    "ingest background pipeline complete | job=%s session=%s type=%s score=%.2f nodes=%d",
                    job_id,
                    req.session_id,
                    state.get("primitive_type", "?"),
                    state.get("final_score", 0.0),
                    len(state.get("nodes_generated", [])),
                )
                # ── Post-ingest security scan (non-blocking) ─────────────
                try:
                    from ..agents.watcher import create_watcher
                    _watcher = create_watcher(graph=graph)
                    _agent_ctx = getattr(request.state, "agent", None)
                    _scan_tid = getattr(_agent_ctx, "tenant_id", "default") if _agent_ctx else "default"
                    _scan_report = _watcher.scan_post_ingest(
                        raw_text=raw_text,
                        nodes_written=state.get("nodes_generated", []),
                        tenant_id=_scan_tid,
                    )
                    if _scan_report.critical_count > 0:
                        logger.warning(
                            "SECURITY WATCHER: %d critical finding(s) in job %s | %s",
                            _scan_report.critical_count, job_id,
                            _scan_report.findings[0].description,
                        )
                        _watcher.save_report(_scan_report, tenant_id=_scan_tid)
                except Exception as _we:
                    logger.debug("Post-ingest watcher scan skipped: %s", _we)
        except Exception as exc:
            logger.error(
                "ingest background pipeline exception | job=%s session=%s: %s",
                job_id, req.session_id, exc,
            )

    background_tasks.add_task(_run_pipeline_bg)

    # ── Return 202 immediately — pipeline is running in background ────────────
    return JSONResponse(
        status_code=202,
        content={
            "status": "queued",
            "job_id": job_id,
            "session_id": req.session_id,
            "message": "Exchange accepted. Pipeline running in background.",
            "note": "ADR-0004: async background worker — no longer blocks on pipeline completion.",
        },
    )



from ..schema import Project as ProjectModel, DEFAULT_PROJECT

VALID_LEAD_AGENTS = frozenset({
    "ohaco",
    "claude",
    "gemini",
    "gemma",  # Google Gemma family (distinct from Gemini in product labeling)
    "gpt",
    "cursor",
    "manus",
    "deepseek",
    "kimi",  # Moonshot Kimi
    "ollama",
})


def _parse_github_repo_url(url: str) -> tuple[str, str] | None:
    import re

    s = (url or "").strip()
    if not s:
        return None
    m = re.match(r"https?://github\.com/([^/]+)/([^/#?\s]+)", s, re.I)
    if not m:
        m = re.match(r"git@github\.com:([^/]+)/([^/#?\s]+)", s, re.I)
    if not m:
        return None
    owner, repo = m.group(1), m.group(2).rstrip("/")
    if repo.lower().endswith(".git"):
        repo = repo[:-4]
    return owner, repo


class ProjectCreateRequest(BaseModel):
    name: str
    description: str = ""
    tags: list[str] = []
    lead_agent: str = "ohaco"  # see VALID_LEAD_AGENTS
    repo_url: str = ""
    deploy_url: str = ""
    docs_url: str = ""


class ProjectUpdateRequest(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[str] = None
    tags: Optional[list[str]] = None
    lead_agent: Optional[str] = None
    repo_url: Optional[str] = None
    deploy_url: Optional[str] = None
    docs_url: Optional[str] = None


class ProjectMemberRequest(BaseModel):
    user_id: str
    role: str = "contributor"  # contributor | reader | admin


@app.get("/projects", summary="List projects (tenant-scoped)")
def list_projects(request: Request):
    """Return projects visible to the current tenant."""
    _agent_ctx = getattr(request.state, "agent", None)
    _tid = getattr(_agent_ctx, "tenant_id", "default") if _agent_ctx else "default"
    if hasattr(graph, "get_projects"):
        projects = graph.get_projects(tenant_id=_tid)
        return {"projects": projects, "tenant_id": _tid}
    return {"projects": [], "note": "Project support requires Neo4j backend"}


@app.post("/projects", summary="Create a new project")
def create_project(req: ProjectCreateRequest, request: Request):
    """Create a new Project node. Auto-assigns tenant_id and owner from caller context."""
    _agent_ctx = getattr(request.state, "agent", None)
    _tid = getattr(_agent_ctx, "tenant_id", "default") if _agent_ctx else "default"
    _owner = getattr(_agent_ctx, "agent_id", "unknown") if _agent_ctx else "unknown"

    _la = req.lead_agent.lower().strip()
    lead = _la if _la in VALID_LEAD_AGENTS else "ohaco"

    project = ProjectModel(
        name=req.name,
        description=req.description,
        tenant_id=_tid,
        owner_id=_owner,
        members=[json.dumps({"user_id": _owner, "role": "admin", "added_at": str(datetime.now(timezone.utc))})],
        tags=req.tags,
        lead_agent=lead,
    )
    if hasattr(graph, "save_project"):
        graph.save_project(project)
    # Store extra link fields directly on the node if provided
    if (req.repo_url or req.deploy_url or req.docs_url) and hasattr(graph, "_tx_write"):
        updates = {}
        if req.repo_url:   updates["repo_url"]   = req.repo_url
        if req.deploy_url: updates["deploy_url"]  = req.deploy_url
        if req.docs_url:   updates["docs_url"]    = req.docs_url
        if updates:
            set_clause = ", ".join(f"p.{k} = ${k}" for k in updates)
            graph._tx_write(
                f"MATCH (p:Project {{id: $pid}}) SET {set_clause}",
                pid=project.id, **updates,
            )
    return {
        "id": project.id,
        "name": project.name,
        "description": project.description,
        "tenant_id": _tid,
        "owner_id": _owner,
        "lead_agent": lead,
        "status": "active",
        "repo_url": req.repo_url,
        "deploy_url": req.deploy_url,
        "tags": req.tags,
        "created_at": str(project.created_at),
        "created": True,
    }


@app.get("/integrations/github-repo", summary="Public GitHub repo metadata for dashboard auto-fill")
def integrations_github_repo(
    repo_url: str = Query(..., description="https://github.com/owner/repo or git@github.com:owner/repo.git"),
):
    """Fetches public repo JSON from GitHub (unauthenticated). Private repos return 404."""
    import urllib.error
    import urllib.parse
    import urllib.request

    parsed = _parse_github_repo_url(repo_url)
    if not parsed:
        raise HTTPException(status_code=400, detail="Not a GitHub repository URL")
    owner, repo = parsed
    enc_o, enc_r = urllib.parse.quote(owner), urllib.parse.quote(repo)
    api_url = f"https://api.github.com/repos/{enc_o}/{enc_r}"
    req = urllib.request.Request(
        api_url,
        headers={
            "Accept": "application/vnd.github+json",
            "User-Agent": "collab-memory-dashboard",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=12) as resp:
            data = json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        if e.code == 404:
            raise HTTPException(
                status_code=404,
                detail="Repository not found or not accessible without a token",
            )
        raise HTTPException(status_code=502, detail=f"GitHub API error ({e.code})")
    except urllib.error.URLError as e:
        raise HTTPException(status_code=502, detail=str(e.reason or e))

    homepage = (data.get("homepage") or "").strip()
    desc = (data.get("description") or "").strip()
    return {
        "owner": owner,
        "repo": repo,
        "name": data.get("name") or repo,
        "description": desc,
        "homepage": homepage,
        "html_url": data.get("html_url") or f"https://github.com/{owner}/{repo}",
        "default_branch": data.get("default_branch") or "main",
    }


@app.get("/projects/{project_id}", summary="Get project details")
def get_project(project_id: str, request: Request):
    """Get a specific project by ID. Tenant-scoped."""
    _agent_ctx = getattr(request.state, "agent", None)
    _tid = getattr(_agent_ctx, "tenant_id", "default") if _agent_ctx else "default"

    if hasattr(graph, "get_project"):
        project = graph.get_project(project_id, tenant_id=_tid)
        if project:
            return {"project": project}
    raise HTTPException(status_code=404, detail=f"Project {project_id} not found in tenant {_tid}")


@app.put("/projects/{project_id}", summary="Update project")
def update_project(project_id: str, req: ProjectUpdateRequest, request: Request):
    """Update project metadata. Only owner or admin can update."""
    _agent_ctx = getattr(request.state, "agent", None)
    _tid = getattr(_agent_ctx, "tenant_id", "default") if _agent_ctx else "default"

    updates = {k: v for k, v in req.model_dump().items() if v is not None}
    if not updates:
        raise HTTPException(status_code=400, detail="No fields to update")

    if "lead_agent" in updates:
        _la = str(updates["lead_agent"]).lower().strip()
        updates["lead_agent"] = _la if _la in VALID_LEAD_AGENTS else "ohaco"

    updates["updated_at"] = str(datetime.now(timezone.utc))

    if hasattr(graph, "_tx_write"):
        set_clause = ", ".join(f"p.{k} = ${k}" for k in updates)
        graph._tx_write(
            f"MATCH (p:Project {{id: $pid, tenant_id: $tid}}) SET {set_clause}",
            pid=project_id, tid=_tid, **updates,
        )
        return {"id": project_id, "updated": list(updates.keys())}
    raise HTTPException(status_code=501, detail="Backend does not support project updates")


@app.post("/projects/{project_id}/members", summary="Add member to project")
def add_project_member(project_id: str, req: ProjectMemberRequest, request: Request):
    """Add a member to a project. Only project owner or admin can add members."""
    _agent_ctx = getattr(request.state, "agent", None)
    _tid = getattr(_agent_ctx, "tenant_id", "default") if _agent_ctx else "default"

    if hasattr(graph, "_tx_write"):
        # Store member as a relationship: (User)-[:MEMBER_OF {role}]->(Project)
        graph._tx_write(
            """
            MATCH (p:Project {id: $pid, tenant_id: $tid})
            MERGE (u:User {user_id: $uid})
            MERGE (u)-[r:MEMBER_OF]->(p)
            SET r.role = $role, r.added_at = $now
            """,
            pid=project_id, tid=_tid, uid=req.user_id,
            role=req.role, now=str(datetime.now(timezone.utc)),
        )
        return {
            "project_id": project_id,
            "user_id": req.user_id,
            "role": req.role,
            "added": True,
        }
    raise HTTPException(status_code=501, detail="Backend does not support member management")


@app.post("/projects/{project_id}/invites", summary="Generate an invite link for a project")
def create_project_invite(
    project_id: str,
    role: str = Query("contributor", description="Role to grant: contributor | reader"),
    expires_hours: int = Query(72, ge=1, le=168, description="Link expiry in hours (1–168)"),
    email: str = Query("", description="Recipient email — sends invite via Resend if set"),
    request: Request = None,
):
    """
    Generate a signed invite token for a project.

    Returns a token + invite URL. The recipient visits /invites/{token}/accept
    to be added to the project with the specified role.
    No email system required — share the link however you like.
    """
    import secrets

    _agent_ctx = getattr(request.state, "agent", None) if request else None
    _tid = getattr(_agent_ctx, "tenant_id", "default") if _agent_ctx else "default"

    if role not in ("contributor", "reader", "admin"):
        raise HTTPException(status_code=400, detail="role must be contributor | reader | admin")
    if not _project_exists_for_tenant(project_id, _tid):
        raise HTTPException(status_code=404, detail="Project not found in this workspace")

    token = secrets.token_urlsafe(32)
    expires_at = datetime.now(timezone.utc).replace(tzinfo=None) + timedelta(hours=expires_hours)

    if hasattr(graph, "_tx_write"):
        graph._tx_write(
            """
            CREATE (inv:ProjectInvite {
                token: $token,
                project_id: $pid,
                tenant_id: $tid,
                role: $role,
                expires_at: $exp,
                created_at: $now,
                status: 'pending'
            })
            """,
            token=token, pid=project_id, tid=_tid, role=role,
            exp=str(expires_at), now=str(datetime.now(timezone.utc).replace(tzinfo=None)),
        )

    base = (
        os.environ.get("COLLAB_PUBLIC_URL", "").rstrip("/")
        or (str(request.base_url).rstrip("/") if request else "")
    )
    invite_url = f"{base}/invites/{token}/accept"

    # Send invite email via Resend if email provided
    if email:
        try:
            from ..auth.email import send_invite_email
            _proj = graph.get_project(project_id, tenant_id=_tid) if hasattr(graph, "get_project") else None
            _proj_name = (_proj or {}).get("name", "a project")
            send_invite_email(email, invite_url, _proj_name)
        except Exception as mail_err:
            import logging
            logging.getLogger(__name__).warning("Invite email failed (non-fatal): %s", mail_err)

    return {
        "token": token,
        "invite_url": invite_url,
        "project_id": project_id,
        "role": role,
        "expires_at": str(expires_at),
        "expires_hours": expires_hours,
    }


@app.get("/invites/{token}", summary="Preview an invite (no auth required)")
def preview_invite(token: str):
    """Return invite metadata so the recipient can see what they're accepting."""
    inv = _load_pending_invite(token)

    # Fetch project name for display
    proj = graph.get_project(inv["project_id"], tenant_id=inv.get("tenant_id", "")) if hasattr(graph, "get_project") else {}
    return {
        "project_id": inv["project_id"],
        "project_name": (proj or {}).get("name", inv["project_id"]),
        "role": inv.get("role", "contributor"),
        "expires_at": str(inv.get("expires_at", "")),
        "status": inv.get("status"),
    }


@app.get("/invites/{token}/accept", include_in_schema=False)
def invite_accept_redirect(token: str, request: Request):
    """
    Browser-safe landing for invite links in email.

    Redirects to signup with invite token so recipients don't hit a POST-only API URL.
    """
    _load_pending_invite(token)  # validates token before redirect
    base = (
        os.environ.get("COLLAB_PUBLIC_URL", "").rstrip("/")
        or str(request.base_url).rstrip("/")
    )
    return RedirectResponse(url=f"{base}/signup?invite_token={token}", status_code=302)


@app.post("/invites/{token}/accept", summary="Accept a project invite")
def accept_invite(
    token: str,
    request: Request,
    user_id: str = Query("", description="Optional; defaults to authenticated user"),
):
    """
    Accept a project invite. Adds the user to the project with the invite's role.
    Marks the invite as used.
    """
    auth_user_id, auth_tenant_id = _require_authenticated_invite_user(request)
    inv = _load_pending_invite(token, tenant_id=auth_tenant_id)
    resolved_user_id = auth_user_id
    if user_id and user_id != auth_user_id:
        raise HTTPException(status_code=403, detail="Authenticated user does not match invite acceptance user_id")

    graph._tx_write(
        """
        MATCH (p:Project {id: $pid, tenant_id: $tid})
        MERGE (u:User {user_id: $uid})
        MERGE (u)-[r:MEMBER_OF]->(p)
        SET r.role = $role, r.added_at = $now
        """,
        pid=inv["project_id"], tid=auth_tenant_id, uid=resolved_user_id, role=inv.get("role", "contributor"),
        now=str(datetime.now(timezone.utc).replace(tzinfo=None)),
    )
    graph._tx_write(
        "MATCH (inv:ProjectInvite {token: $token}) SET inv.status = 'accepted', inv.accepted_by = $uid",
        token=token, uid=resolved_user_id,
    )

    return {
        "accepted": True,
        "project_id": inv["project_id"],
        "user_id": resolved_user_id,
        "role": inv.get("role", "contributor"),
    }


@app.get("/projects/{project_id}/members", summary="List project members")
def list_project_members(project_id: str, request: Request):
    """Return all members of a project with their roles."""
    if not hasattr(graph, "_tx_read"):
        return {"members": []}
    _tid = _resolve_tenant(request)
    rows = graph._tx_read(
        """
        MATCH (u:User)-[r:MEMBER_OF]->(p:Project {id: $pid, tenant_id: $tid})
        RETURN u.user_id AS user_id, u.email AS email, r.role AS role, r.added_at AS added_at
        ORDER BY r.added_at DESC
        """,
        pid=project_id,
        tid=_tid,
    )
    return {"project_id": project_id, "members": [dict(r) for r in rows]}


@app.delete("/projects/{project_id}/members/{user_id}", summary="Remove a project member")
def remove_project_member(project_id: str, user_id: str, request: Request):
    """Remove a user from a project."""
    if not hasattr(graph, "_tx_write"):
        raise HTTPException(status_code=501, detail="Backend does not support member management")
    _tid = _resolve_tenant(request)
    graph._tx_write(
        "MATCH (u:User {user_id: $uid})-[r:MEMBER_OF]->(p:Project {id: $pid, tenant_id: $tid}) DELETE r",
        uid=user_id, pid=project_id, tid=_tid,
    )
    return {"removed": True, "project_id": project_id, "user_id": user_id}


@app.put("/projects/{project_id}/members/{user_id}/role", summary="Change a member's role")
def change_member_role(
    project_id: str,
    user_id: str,
    role: str = Query(..., description="New role: admin | contributor | reader"),
    request: Request = None,
):
    """Change an existing member's role on a project. Admin or project owner only."""
    if role not in ("admin", "contributor", "reader"):
        raise HTTPException(status_code=400, detail="role must be admin | contributor | reader")

    if not hasattr(graph, "_tx_write"):
        raise HTTPException(status_code=501, detail="Backend does not support member management")

    _tid = _resolve_tenant(request)
    # Verify user is a member in this tenant/project
    rows = graph._tx_read(
        "MATCH (u:User {user_id: $uid})-[r:MEMBER_OF]->(p:Project {id: $pid, tenant_id: $tid}) RETURN r",
        uid=user_id, pid=project_id, tid=_tid,
    )
    if not rows:
        raise HTTPException(status_code=404, detail=f"User {user_id} is not a member of project {project_id}")

    graph._tx_write(
        """
        MATCH (u:User {user_id: $uid})-[r:MEMBER_OF]->(p:Project {id: $pid, tenant_id: $tid})
        SET r.role = $role, r.updated_at = $now
        """,
        uid=user_id, pid=project_id, tid=_tid, role=role,
        now=str(datetime.now(timezone.utc).replace(tzinfo=None)),
    )
    return {"project_id": project_id, "user_id": user_id, "role": role, "updated": True}


@app.get("/projects/{project_id}/invites", summary="List pending invites for a project")
def list_project_invites(project_id: str, request: Request):
    """Return all pending (unused, unexpired) invites for a project."""
    if not hasattr(graph, "_tx_read"):
        return {"invites": []}
    _tid = _resolve_tenant(request)
    rows = graph._tx_read(
        """
        MATCH (inv:ProjectInvite {project_id: $pid, tenant_id: $tid, status: 'pending'})
        RETURN inv.token AS token, inv.role AS role,
               inv.expires_at AS expires_at, inv.created_at AS created_at
        ORDER BY inv.created_at DESC
        """,
        pid=project_id, tid=_tid,
    )
    return {"project_id": project_id, "invites": [dict(r) for r in rows], "count": len(rows)}


@app.delete("/projects/{project_id}/invites/{token}", summary="Revoke an invite")
def revoke_invite(project_id: str, token: str, request: Request):
    """Revoke a pending invite so it can no longer be accepted."""
    if not hasattr(graph, "_tx_write"):
        raise HTTPException(status_code=501, detail="Backend does not support invites")
    _tid = _resolve_tenant(request)
    graph._tx_write(
        "MATCH (inv:ProjectInvite {token: $token, project_id: $pid, tenant_id: $tid}) SET inv.status = 'revoked'",
        token=token, pid=project_id, tid=_tid,
    )
    return {"revoked": True, "token": token}


@app.post("/projects/{project_id}/keys", summary="Create a project-scoped API key", tags=["projects"])
def create_project_key(
    project_id: str,
    request: Request,
    role: str = Query("contributor", description="Role for this key (contributor or reader)"),
    agent_id: str = Query("scoped-agent", description="Agent identifier for this key"),
):
    """
    Generate a project-scoped API key.

    The key grants access ONLY to the specified project's data.
    Stored as a ProjectKey node in Neo4j.
    Requires admin role.
    """
    agent = getattr(request.state, "agent", None)
    if not agent or not getattr(agent, "is_admin", False):
        raise HTTPException(status_code=403, detail="Only admins can create project-scoped keys")

    tid = _resolve_tenant(request)
    if not hasattr(graph, "_tx_write"):
        raise HTTPException(status_code=501, detail="Backend does not support project keys")

    import secrets as _secrets
    api_key = f"pk_{_secrets.token_urlsafe(32)}"
    safe_role = role if role in ("contributor", "reader") else "contributor"

    graph._tx_write(
        """
        CREATE (pk:ProjectKey {
            api_key: $key, project_id: $pid, tenant_id: $tid,
            role: $role, agent_id: $agent_id, status: 'active',
            created_at: datetime(), created_by: $author
        })
        """,
        key=api_key, pid=project_id, tid=tid,
        role=safe_role, agent_id=agent_id, author=_resolve_author(request),
    )

    return {
        "api_key": api_key,
        "project_id": project_id,
        "role": safe_role,
        "agent_id": agent_id,
        "note": "This key only grants access to data in this project.",
    }


@app.get("/projects/{project_id}/keys", summary="List project-scoped keys", tags=["projects"])
def list_project_keys(project_id: str, request: Request):
    """List active project-scoped API keys (admin only). Keys are masked."""
    agent = getattr(request.state, "agent", None)
    if not agent or not getattr(agent, "is_admin", False):
        raise HTTPException(status_code=403, detail="Only admins can view project keys")

    if not hasattr(graph, "_tx_read"):
        return {"keys": []}

    _tid = getattr(agent, "tenant_id", "") if agent else ""
    rows = graph._tx_read(
        "MATCH (pk:ProjectKey {project_id: $pid, tenant_id: $tid, status: 'active'}) RETURN pk",
        pid=project_id,
        tid=_tid,
    )
    keys = []
    for r in (rows or []):
        pk = dict(r["pk"])
        pk["api_key"] = pk["api_key"][:8] + "..." + pk["api_key"][-4:]  # Mask
        keys.append(pk)
    return {"keys": keys, "count": len(keys)}


@app.delete("/projects/{project_id}/keys/{key_prefix}", summary="Revoke a project-scoped key", tags=["projects"])
def revoke_project_key(project_id: str, key_prefix: str, request: Request):
    """Revoke a project-scoped key by its prefix (first 8 chars)."""
    agent = getattr(request.state, "agent", None)
    if not agent or not getattr(agent, "is_admin", False):
        raise HTTPException(status_code=403, detail="Only admins can revoke project keys")

    if not hasattr(graph, "_tx_write"):
        raise HTTPException(status_code=501, detail="Backend does not support project keys")

    graph._tx_write(
        "MATCH (pk:ProjectKey {project_id: $pid, status: 'active'}) WHERE pk.api_key STARTS WITH $prefix SET pk.status = 'revoked'",
        pid=project_id, prefix=key_prefix,
    )
    return {"revoked": True, "key_prefix": key_prefix}


@app.post("/invites/{token}/signup-and-accept", summary="Sign up and accept invite in one step")
def signup_and_accept_invite(
    token: str,
    email: str = Query(..., description="Email for new account"),
    password: str = Query(..., description="Password for new account"),
):
    """
    One-step onboarding: create account + accept project invite.

    For new users who received an invite link — they sign up and get
    added to the project in a single request.
    """
    inv = _load_pending_invite(token)
    invite_tenant_id = str(inv.get("tenant_id") or "").strip()
    invite_project_id = str(inv.get("project_id") or "").strip()
    if not invite_tenant_id:
        raise HTTPException(status_code=400, detail="Invite is missing tenant scope")
    if not invite_project_id:
        raise HTTPException(status_code=400, detail="Invite is missing project scope")
    if not _project_exists_for_tenant(invite_project_id, invite_tenant_id):
        raise HTTPException(status_code=404, detail="Project not found for this invite")

    # Sign up (canonical email — same as /auth/signup)
    from collab_memory.auth.jwt_provider import normalize_email
    from collab_memory.auth.middleware import get_auth_client

    email = normalize_email(email)
    if not email or "@" not in email:
        raise HTTPException(status_code=400, detail="A valid email is required")

    auth_client = get_auth_client()
    signup_result = auth_client.signup(
        email,
        password,
        "workspace",
        tenant_id_override=invite_tenant_id,
        bootstrap_workspace=False,
        bypass_signup_policy=True,
    )
    if "error" in signup_result:
        status = 409 if "already exists" in signup_result.get("error", "") else 400
        raise HTTPException(status_code=status, detail=signup_result)

    user_id = signup_result["user_id"]

    # Add to project
    graph._tx_write(
        """
        MATCH (p:Project {id: $pid, tenant_id: $tid})
        MERGE (u:User {user_id: $uid})
        SET u.email = $email
        MERGE (u)-[r:MEMBER_OF]->(p)
        SET r.role = $role, r.added_at = $now
        """,
        pid=invite_project_id, tid=invite_tenant_id, uid=user_id, email=email,
        role=inv.get("role", "contributor"),
        now=str(datetime.now(timezone.utc).replace(tzinfo=None)),
    )

    # Mark invite as accepted
    graph._tx_write(
        "MATCH (inv:ProjectInvite {token: $token}) SET inv.status = 'accepted', inv.accepted_by = $uid, inv.accepted_email = $email",
        token=token, uid=user_id, email=email,
    )

    return {
        "status": "ok",
        "user_id": user_id,
        "email": email,
        "project_id": invite_project_id,
        "tenant_id": invite_tenant_id,
        "role": inv.get("role", "contributor"),
        "access_token": signup_result.get("access_token"),
        "refresh_token": signup_result.get("refresh_token"),
    }


@app.put("/projects/{project_id}/threshold", summary="Set per-project worthiness threshold")
def set_project_threshold(
    project_id: str,
    threshold: float = Query(..., ge=0.1, le=0.9, description="Worthiness threshold (0.1–0.9)"),
):
    """
    Override the global worthiness threshold (default 0.4) for this project.
    Lower = more items captured (noisier). Higher = only high-confidence items.

    HITL reject_rate > 30% → suggest raising threshold.
    HITL reject_rate < 10% → suggest lowering threshold.
    """
    if not hasattr(graph, "_tx_write"):
        raise HTTPException(status_code=501, detail="Backend does not support project updates")
    graph._tx_write(
        "MATCH (p:Project {id: $pid}) SET p.worthiness_threshold = $t",
        pid=project_id, t=threshold,
    )
    return {"project_id": project_id, "worthiness_threshold": threshold, "ok": True}


class ProjectSnapshotCreateRequest(BaseModel):
    session_id: str = ""
    summary: str = ""
    prompt: str = ""
    screenshot_data_url: str = ""
    state: dict[str, Any] = {}
    tags: list[str] = []


@app.post("/projects/{project_id}/snapshots", summary="Create a visual snapshot for project resume")
def create_project_snapshot(project_id: str, req: ProjectSnapshotCreateRequest, request: Request):
    """
    Stores a lightweight project snapshot as an Artifact node:
    - optional screenshot (data URL) saved as image artifact
    - snapshot JSON (summary, prompt, state, linked screenshot) saved as JSON artifact
    """
    tid = _resolve_tenant(request)
    author = _resolve_author(request)
    ts = datetime.now(timezone.utc)

    screenshot_artifact_id: Optional[str] = None
    screenshot_url = ""
    screenshot_mime = ""
    screenshot_bytes = 0
    data_url = (req.screenshot_data_url or "").strip()
    if data_url:
        if not data_url.startswith("data:image/"):
            raise HTTPException(status_code=400, detail="screenshot_data_url must be a data:image/* URL")
        try:
            header, b64 = data_url.split(",", 1)
            screenshot_mime = header.split(";")[0].replace("data:", "").strip() or "image/png"
            raw = base64.b64decode(b64, validate=True)
        except Exception:
            raise HTTPException(status_code=400, detail="Invalid screenshot_data_url encoding")
        if len(raw) > 2_000_000:
            raise HTTPException(status_code=413, detail="Screenshot too large (max 2MB)")

        screenshot_bytes = len(raw)
        screenshot_ext = "png"
        if "/" in screenshot_mime:
            maybe_ext = screenshot_mime.split("/", 1)[1].split("+", 1)[0]
            if maybe_ext:
                screenshot_ext = maybe_ext
        screenshot_artifact = Artifact(
            name=f"project-snapshot-{project_id}-{ts.strftime('%Y%m%d-%H%M%S')}.{screenshot_ext}",
            content=data_url,
            artifact_type=ArtifactType.image,
            mime_type=screenshot_mime,
            description=f"Project snapshot screenshot for {project_id}",
            session_id=req.session_id or "",
            project_id=project_id,
            tags=["project_snapshot", "cover", *req.tags],
            created_by=author,
            size_bytes=screenshot_bytes,
            tenant_id=tid,
        )
        if hasattr(graph, "save_artifact"):
            graph.save_artifact(screenshot_artifact)
        screenshot_artifact_id = screenshot_artifact.id
        screenshot_url = f"/artifacts/{screenshot_artifact.id}/preview"

    # Keep state lean and JSON-serializable
    _state_raw = req.state if isinstance(req.state, dict) else {}
    state_limit = 20_000
    state_json = json.dumps(_state_raw, ensure_ascii=False)[:state_limit]
    state_payload = json.loads(state_json) if state_json else {}

    payload = {
        "schema": "ohaco.project_snapshot.v1",
        "project_id": project_id,
        "tenant_id": tid,
        "saved_at": ts.isoformat(),
        "saved_by": author,
        "session_id": (req.session_id or "").strip(),
        "summary": (req.summary or "").strip()[:500],
        "prompt": (req.prompt or "").strip()[:4000],
        "state": state_payload,
        "screenshot_artifact_id": screenshot_artifact_id,
        "screenshot_url": screenshot_url,
        "tags": list(dict.fromkeys(["project_snapshot", *req.tags])),
    }

    snapshot_artifact = Artifact(
        name=f"project-snapshot-{project_id}-{ts.strftime('%Y%m%d-%H%M%S')}.json",
        content=json.dumps(payload, ensure_ascii=False),
        artifact_type=ArtifactType.json,
        mime_type="application/json",
        description=f"Project snapshot payload for resume ({project_id})",
        session_id=req.session_id or "",
        project_id=project_id,
        tags=["project_snapshot", *req.tags],
        created_by=author,
        size_bytes=len(json.dumps(payload).encode()),
        tenant_id=tid,
    )
    if hasattr(graph, "save_artifact"):
        graph.save_artifact(snapshot_artifact)

    if hasattr(graph, "_tx_write"):
        graph._tx_write(
            "MATCH (p:Project {id: $pid, tenant_id: $tid}) "
            "SET p.last_snapshot_id = $sid, p.last_snapshot_at = $sat, p.last_updated_at = $sat, p.updated_at = $sat",
            pid=project_id,
            tid=tid,
            sid=snapshot_artifact.id,
            sat=ts.isoformat(),
        )

    return {
        "ok": True,
        "project_id": project_id,
        "snapshot_id": snapshot_artifact.id,
        "screenshot_artifact_id": screenshot_artifact_id,
        "saved_at": payload["saved_at"],
        "summary": payload["summary"],
        "screenshot_bytes": screenshot_bytes,
    }


@app.get("/projects/{project_id}/snapshots", summary="List saved visual snapshots for a project")
def list_project_snapshots(
    project_id: str,
    request: Request,
    limit: int = Query(20, ge=1, le=100),
):
    if not hasattr(graph, "get_artifacts"):
        return {"project_id": project_id, "snapshots": [], "count": 0}
    rows = graph.get_artifacts(
        project_id=project_id,
        artifact_type="json",
        limit=max(limit * 3, limit),
        tenant_id=_resolve_tenant(request),
    )
    out = []
    for a in rows:
        tags = a.get("tags") or []
        if "project_snapshot" not in tags:
            continue
        raw = a.get("content", "") or ""
        payload = {}
        try:
            payload = json.loads(raw) if raw else {}
        except Exception:
            payload = {}
        out.append({
            "id": a.get("id"),
            "name": a.get("name"),
            "saved_at": payload.get("saved_at") or a.get("updated_at") or a.get("created_at"),
            "summary": payload.get("summary", ""),
            "prompt": payload.get("prompt", ""),
            "session_id": payload.get("session_id", ""),
            "state": payload.get("state", {}),
            "screenshot_artifact_id": payload.get("screenshot_artifact_id"),
            "screenshot_url": payload.get("screenshot_url", ""),
            "project_id": payload.get("project_id") or project_id,
        })
        if len(out) >= limit:
            break
    return {"project_id": project_id, "snapshots": out, "count": len(out)}


@app.get("/projects/{project_id}/snapshots/latest", summary="Get latest snapshot for quick resume")
def latest_project_snapshot(project_id: str, request: Request):
    data = list_project_snapshots(project_id=project_id, request=request, limit=1)
    snaps = data.get("snapshots", [])
    return {"project_id": project_id, "snapshot": snaps[0] if snaps else None}


@app.get("/projects/{project_id}/calibration", summary="HITL calibration stats for threshold tuning")
def get_calibration(project_id: str):
    """
    Returns HITL confirm/reject counts and a threshold recommendation.
    Reject rate > 30% → raise threshold. < 10% and confirms > 20 → consider lowering.
    """
    rows = graph._tx_read(
        "MATCH (p:Project {id: $pid}) RETURN p.hitl_confirm_count AS c, "
        "p.hitl_reject_count AS r, p.worthiness_threshold AS t LIMIT 1",
        pid=project_id,
    )
    if not rows:
        raise HTTPException(status_code=404, detail="Project not found")
    confirmed = rows[0]["c"] or 0
    rejected  = rows[0]["r"] or 0
    current_t = rows[0]["t"] or 0.4
    total = confirmed + rejected
    reject_rate = round(rejected / total, 3) if total > 0 else None

    recommendation = None
    if reject_rate is not None:
        if reject_rate > 0.30:
            recommendation = {
                "action": "raise_threshold",
                "suggested": min(round(current_t + 0.05, 2), 0.85),
                "reason": f"Reject rate {round(reject_rate*100)}% is high — threshold too permissive",
            }
        elif reject_rate < 0.10 and confirmed >= 20:
            recommendation = {
                "action": "lower_threshold",
                "suggested": max(round(current_t - 0.05, 2), 0.15),
                "reason": f"Reject rate {round(reject_rate*100)}% is low — may be missing valid signals",
            }

    return {
        "project_id": project_id,
        "current_threshold": current_t,
        "hitl_confirmed": confirmed,
        "hitl_rejected": rejected,
        "reject_rate": reject_rate,
        "recommendation": recommendation,
    }


# ─── Task & Sprint Endpoints ─────────────────────────────────────────────────

from ..schema import (
    Task as TaskModel, Sprint as SprintModel, CommunicationEvent,
    TaskStatus, TaskPriority, SprintStatus,
)


class TaskCreateRequest(BaseModel):
    title: str
    description: str = ""
    status: str = "todo"
    priority: str = "medium"
    assignee: str = ""
    project_id: Optional[str] = None
    sprint_id: Optional[str] = None
    tags: list[str] = []
    due_date: Optional[str] = None
    estimate_hours: Optional[float] = None
    related_decision_ids: list[str] = []
    blocked_by_ids: list[str] = []


class TaskUpdateRequest(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    status: Optional[str] = None
    priority: Optional[str] = None
    assignee: Optional[str] = None
    sprint_id: Optional[str] = None
    tags: Optional[list[str]] = None
    due_date: Optional[str] = None
    estimate_hours: Optional[float] = None
    actual_hours: Optional[float] = None
    related_decision_ids: Optional[list[str]] = None
    blocked_by_ids: Optional[list[str]] = None
    # Coordination protocol fields (optional; legacy clients can keep using status/assignee)
    protocol_action: Optional[str] = None
    handoff_to: Optional[str] = None
    note: Optional[str] = None


class TaskProtocolRequest(BaseModel):
    action: str
    handoff_to: Optional[str] = None
    note: Optional[str] = None


class TaskLeaseRequest(BaseModel):
    ttl_seconds: int = 300
    note: Optional[str] = None

    @field_validator("ttl_seconds")
    @classmethod
    def _validate_ttl_seconds(cls, v: int) -> int:
        if v < 30 or v > 3600:
            raise ValueError("ttl_seconds must be between 30 and 3600")
        return v


class SprintCreateRequest(BaseModel):
    name: str
    description: str = ""
    project_id: Optional[str] = None
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    goal: str = ""


class SprintUpdateRequest(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[str] = None
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    goal: Optional[str] = None


def _resolve_tenant(request: Request) -> str:
    _agent_ctx = getattr(request.state, "agent", None)
    if not _agent_ctx:
        return "default"
    tid = getattr(_agent_ctx, "tenant_id", "default") or "default"
    # Local dev convenience: seed env-key admin traffic into a stable tenant namespace.
    if (
        not _IS_PRODUCTION
        and tid == "default"
        and getattr(_agent_ctx, "role", "") == "admin"
        and getattr(_agent_ctx, "agent_id", "") in ("local", "admin", "local-admin")
    ):
        return "local-dev"
    return tid


def _resolve_author(request: Request) -> str:
    _agent_ctx = getattr(request.state, "agent", None)
    return getattr(_agent_ctx, "agent_id", "unknown") if _agent_ctx else "unknown"


def _check_project_access(request: Request, project_id: Optional[str]) -> None:
    """Verify user has access to the requested project. Raises 403 if not.

    Bypass conditions (no check needed):
    - No project_id requested (tenant-level access)
    - Role is admin or super_admin
    - Auth is via API key (agent-level, tenant-scoped)
    - JWT user has MEMBER_OF edge to the project
    """
    if not project_id:
        return
    _agent_ctx = getattr(request.state, "agent", None)
    if not _agent_ctx:
        return
    role = getattr(_agent_ctx, "role", "")
    if role in ("admin", "super_admin"):
        return
    # API key auth (agent_id set, no user_id) = tenant-level access, no project check
    user_id = getattr(_agent_ctx, "user_id", None)
    if not user_id:
        return
    # JWT user: check project membership
    tid = getattr(_agent_ctx, "tenant_id", "default")
    rows = graph._tx_read(
        "MATCH (u:User {user_id: $uid})-[:MEMBER_OF]->(p:Project {id: $pid, tenant_id: $tid}) RETURN u.user_id AS uid",
        uid=user_id, pid=project_id, tid=tid,
    )
    if not rows:
        raise HTTPException(
            status_code=403,
            detail=f"Not a member of project '{project_id}'. Ask a project admin to invite you.",
        )


_TASK_STATUS_VALUES = {s.value for s in TaskStatus}
_TASK_PRIORITY_VALUES = {p.value for p in TaskPriority}
_TASK_PROTOCOL_ACTIONS = {
    "claim",
    "handoff",
    "submit_review",
    "approve",
    "block",
    "unblock",
    "cancel",
    "reopen",
}

_TASK_PROTOCOL_MESSAGE_TYPES = {"info", "request", "response", "decision", "handoff"}

# Strict lifecycle for parallel coordination (claim → work → review → done).
# Admin can bypass in emergency, contributors must follow transitions.
_TASK_PROTOCOL_TRANSITIONS: dict[str, set[str]] = {
    "backlog": {"todo", "cancelled"},
    "todo": {"in_progress", "blocked", "cancelled", "backlog"},
    "in_progress": {"review", "blocked", "todo", "cancelled"},
    "blocked": {"todo", "in_progress", "cancelled"},
    "review": {"done", "in_progress", "blocked", "cancelled"},
    "done": set(),
    "cancelled": set(),
}


def _is_admin_agent(request: Request) -> bool:
    _agent_ctx = getattr(request.state, "agent", None)
    role = getattr(_agent_ctx, "role", "")
    return role in ("admin", "super_admin")


def _resolve_task_project_id(task: dict) -> str:
    return str(task.get("project_id", "") or "")


def _resolve_task_recipient(task: dict) -> str:
    return str(task.get("assignee", "") or "broadcast")


def _write_coordination_event(
    *,
    sender: str,
    recipient: str,
    message: str,
    message_type: str,
    task_id: str,
    project_id: str,
    tenant_id: str,
) -> None:
    """Best-effort coordination log for protocol enforcement auditability."""
    if not hasattr(graph, "_tx_write"):
        return
    import secrets as _secrets
    event_id = f"com_{_secrets.token_hex(5)}"
    try:
        graph._tx_write(
            """
            CREATE (c:CommunicationEvent {
                id: $id,
                sender: $sender,
                recipient: $recipient,
                message: $message,
                message_type: $message_type,
                task_id: $task_id,
                project_id: $project_id,
                tenant_id: $tenant_id,
                created_at: $created_at
            })
            """,
            id=event_id,
            sender=sender,
            recipient=recipient or "broadcast",
            message=message,
            message_type=message_type,
            task_id=task_id,
            project_id=project_id or "",
            tenant_id=tenant_id,
            created_at=datetime.now(timezone.utc).isoformat(),
        )
    except Exception:
        # Non-fatal: protocol enforcement must still proceed.
        pass


def _emit_task_update_event(
    *,
    actor: str,
    previous: dict,
    updates: dict[str, Any],
    tenant_id: str,
) -> None:
    """Emit generic task transition events when protocol_action is not used."""
    prev_status = str(previous.get("status", "") or "")
    new_status = str(updates.get("status", prev_status) or prev_status)
    prev_assignee = str(previous.get("assignee", "") or "")
    new_assignee = str(updates.get("assignee", prev_assignee) or prev_assignee)
    task_id = str(previous.get("id", "") or "")
    project_id = _resolve_task_project_id(previous)

    if new_status != prev_status:
        _write_coordination_event(
            sender=actor,
            recipient=new_assignee or "broadcast",
            message=f"Task status changed: {prev_status} → {new_status}",
            message_type="info",
            task_id=task_id,
            project_id=project_id,
            tenant_id=tenant_id,
        )
    if new_assignee != prev_assignee:
        _write_coordination_event(
            sender=actor,
            recipient=new_assignee or "broadcast",
            message=f"Task reassigned: {prev_assignee or 'unassigned'} → {new_assignee or 'unassigned'}",
            message_type="handoff",
            task_id=task_id,
            project_id=project_id,
            tenant_id=tenant_id,
        )


def _task_as_response(task: dict) -> dict:
    """Normalize task payload for API responses."""
    claim_locked_by = task.get("claim_locked_by") or task.get("locked_by") or ""
    claim_locked_until = (
        task.get("claim_locked_until")
        or task.get("claim_expires_at")
        or task.get("locked_until")
        or ""
    )
    return {
        "id": task.get("id", ""),
        "title": task.get("title", ""),
        "status": task.get("status", "todo"),
        "assignee": task.get("assignee", ""),
        "project_id": task.get("project_id", ""),
        "priority": task.get("priority", "medium"),
        "updated_at": task.get("updated_at", ""),
        "claim_locked_by": claim_locked_by,
        "claim_locked_until": claim_locked_until,
    }


def _load_task_for_update(task_id: str, tenant_id: str) -> dict:
    if not hasattr(graph, "_tx_read"):
        raise HTTPException(status_code=500, detail="Task support requires Neo4j backend")
    rows = graph._tx_read(
        "MATCH (t:Task {id: $id}) WHERE t.tenant_id = $tid RETURN t",
        id=task_id,
        tid=tenant_id,
    )
    if not rows:
        raise HTTPException(status_code=404, detail=f"Task {task_id} not found")
    return dict(rows[0]["t"])


def _normalize_status(status: Optional[str]) -> Optional[str]:
    if status is None:
        return None
    s = status.strip()
    if not s:
        return None
    if s not in _TASK_STATUS_VALUES:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid task status '{s}'. Must be one of: {sorted(_TASK_STATUS_VALUES)}",
        )
    return s


def _normalize_priority(priority: Optional[str]) -> Optional[str]:
    if priority is None:
        return None
    p = priority.strip()
    if not p:
        return None
    if p not in _TASK_PRIORITY_VALUES:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid task priority '{p}'. Must be one of: {sorted(_TASK_PRIORITY_VALUES)}",
        )
    return p


def _apply_protocol_action(
    *,
    action: str,
    current: dict,
    actor_id: str,
    is_admin: bool,
    handoff_to: Optional[str],
    updates: dict[str, Any],
) -> dict[str, str]:
    """
    Map protocol actions to state/assignee updates with guardrails.
    Returns metadata for coordination event logging.
    """
    act = (action or "").strip()
    if act not in _TASK_PROTOCOL_ACTIONS:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid protocol action '{act}'. Must be one of: {sorted(_TASK_PROTOCOL_ACTIONS)}",
        )

    current_status = str(current.get("status", "todo") or "todo")
    current_assignee = str(current.get("assignee", "") or "")

    def _owner_or_admin(required_msg: str = "Only task assignee or admin may do this.") -> None:
        if is_admin:
            return
        if not current_assignee or current_assignee != actor_id:
            raise HTTPException(status_code=403, detail=required_msg)

    lock_active, lock_owner = _is_active_claim_lock(current)

    if act == "claim":
        if lock_active and lock_owner and lock_owner != actor_id and not is_admin:
            raise HTTPException(
                status_code=409,
                detail=f"Task has an active claim lease by '{lock_owner}'. Wait for expiry or request handoff.",
            )
        if current_assignee and current_assignee != actor_id and not is_admin:
            raise HTTPException(
                status_code=409,
                detail=f"Task already claimed by '{current_assignee}'. Use handoff or admin override.",
            )
        updates["assignee"] = actor_id
        updates["status"] = "in_progress"
        return {"message_type": "request", "recipient": actor_id, "message": f"Task claimed by {actor_id}"}

    if act == "handoff":
        _owner_or_admin("Only current assignee or admin may hand off a task.")
        target = (handoff_to or "").strip()
        if not target:
            raise HTTPException(status_code=400, detail="handoff_to is required for protocol action 'handoff'")
        updates["assignee"] = target
        updates["status"] = "todo"
        return {"message_type": "handoff", "recipient": target, "message": f"Task handed off from {actor_id} to {target}"}

    if act == "submit_review":
        _owner_or_admin()
        updates["status"] = "review"
        return {"message_type": "response", "recipient": "operator", "message": f"Task submitted for review by {actor_id}"}

    if act == "approve":
        if current_status != "review" and not is_admin:
            raise HTTPException(status_code=409, detail="Task must be in 'review' before it can be approved.")
        updates["status"] = "done"
        return {"message_type": "decision", "recipient": current_assignee or "operator", "message": f"Task approved by {actor_id}"}

    if act == "block":
        _owner_or_admin()
        updates["status"] = "blocked"
        return {"message_type": "info", "recipient": "operator", "message": f"Task blocked by {actor_id}"}

    if act == "unblock":
        if current_status != "blocked" and not is_admin:
            raise HTTPException(status_code=409, detail="Task is not currently blocked.")
        if current_assignee and current_assignee != actor_id and not is_admin:
            raise HTTPException(status_code=403, detail="Only current assignee or admin may unblock this task.")
        updates["status"] = "todo"
        return {"message_type": "info", "recipient": current_assignee or actor_id, "message": f"Task unblocked by {actor_id}"}

    if act == "cancel":
        _owner_or_admin()
        updates["status"] = "cancelled"
        return {"message_type": "decision", "recipient": "broadcast", "message": f"Task cancelled by {actor_id}"}

    # act == "reopen"
    if current_status not in ("done", "cancelled") and not is_admin:
        raise HTTPException(status_code=409, detail="Only completed/cancelled tasks can be reopened.")
    if current_assignee and current_assignee != actor_id and not is_admin:
        raise HTTPException(status_code=403, detail="Only current assignee or admin may reopen this task.")
    updates["status"] = "todo"
    return {"message_type": "info", "recipient": current_assignee or actor_id, "message": f"Task reopened by {actor_id}"}


def _validate_transition_and_ownership(
    *,
    current: dict,
    updates: dict[str, Any],
    actor_id: str,
    is_admin: bool,
) -> None:
    """Enforce coordination protocol on generic PUT updates."""
    current_status = str(current.get("status", "todo") or "todo")
    current_assignee = str(current.get("assignee", "") or "")
    next_status = updates.get("status")
    next_assignee = updates.get("assignee", current_assignee)

    if next_assignee is None:
        next_assignee = ""

    # Lock down terminal states for non-admin users.
    if current_status in {"done", "cancelled"} and next_status and next_status != current_status and not is_admin:
        raise HTTPException(
            status_code=409,
            detail=f"Task in terminal status '{current_status}' can only be changed by admin or protocol action 'reopen'.",
        )

    # Status transition validation for contributors/readers.
    if next_status and next_status != current_status and not is_admin:
        allowed = _TASK_PROTOCOL_TRANSITIONS.get(current_status, set())
        if next_status not in allowed:
            raise HTTPException(
                status_code=409,
                detail=f"Invalid status transition '{current_status}' → '{next_status}'. Allowed: {sorted(allowed)}",
            )

    # Only owner/admin can modify task assignee while work is active.
    if "assignee" in updates and next_assignee != current_assignee:
        if current_status in {"in_progress", "review"} and not is_admin and current_assignee and current_assignee != actor_id:
            raise HTTPException(
                status_code=403,
                detail="Only current assignee or admin may reassign an active task. Use protocol action 'handoff'.",
            )

    # Claim semantics: entering in_progress requires ownership.
    if next_status == "in_progress":
        if not next_assignee:
            if actor_id and actor_id != "unknown":
                updates["assignee"] = actor_id
                next_assignee = actor_id
            else:
                raise HTTPException(
                    status_code=400,
                    detail="Cannot move task to in_progress without an assignee.",
                )
        if not is_admin and current_assignee and current_assignee != actor_id and next_assignee != actor_id:
            raise HTTPException(
                status_code=409,
                detail=f"Task already claimed by '{current_assignee}'. Use protocol action 'handoff' or admin override.",
            )

    # Review/Done gate: must be assignee or admin.
    if next_status in {"review", "done", "cancelled"} and not is_admin:
        effective_assignee = next_assignee or current_assignee
        if effective_assignee and effective_assignee != actor_id:
            raise HTTPException(
                status_code=403,
                detail=f"Only assignee '{effective_assignee}' or admin may move task to '{next_status}'.",
            )
        if next_status == "done" and current_status != "review":
            raise HTTPException(
                status_code=409,
                detail="Task must be in 'review' before it can be marked 'done'. Use submit_review first.",
            )


def _enforce_claim_lock(
    *,
    current: dict,
    updates: dict[str, Any],
    actor_id: str,
    is_admin: bool,
) -> None:
    """Prevent parallel ownership conflicts using claim lease metadata."""
    if is_admin:
        return
    active_lock, lock_owner = _is_active_claim_lock(current)
    if not active_lock or not lock_owner:
        return
    if lock_owner == actor_id:
        return

    # Allow transitions back to todo when an owner hands off explicitly.
    next_status = str(updates.get("status", current.get("status", "")) or "")
    next_assignee = str(updates.get("assignee", current.get("assignee", "")) or "")
    if next_status == "todo" and next_assignee and next_assignee != lock_owner:
        return

    raise HTTPException(
        status_code=409,
        detail=f"Task is lock-held by '{lock_owner}' until lease expiry. Use handoff or wait for lease timeout.",
    )


def _load_task_claim_lock(task: dict) -> tuple[str, datetime | None]:
    """
    Parse claim lock metadata from a task row.
    Supports both `claim_locked_by/claim_expires_at` and legacy `locked_by/locked_until`.
    """
    owner = str(task.get("claim_locked_by") or task.get("locked_by") or "")
    exp_raw = task.get("claim_expires_at") or task.get("claim_locked_until") or task.get("locked_until")
    if not exp_raw:
        return owner, None
    try:
        exp = datetime.fromisoformat(str(exp_raw).replace("Z", "+00:00"))
        if exp.tzinfo is None:
            exp = exp.replace(tzinfo=timezone.utc)
        return owner, exp
    except Exception:
        return owner, None


def _is_active_claim_lock(task: dict, *, now: datetime | None = None) -> tuple[bool, str]:
    """Return (is_active, lock_owner) for the current claim lock."""
    owner, exp = _load_task_claim_lock(task)
    if not owner or not exp:
        return False, owner
    _now = now or datetime.now(timezone.utc)
    return exp > _now, owner


def _set_task_claim_lock(
    task_id: str,
    tenant_id: str,
    *,
    owner: str,
    ttl_seconds: int,
) -> str:
    """Persist claim lock owner + expiry and return ISO expiry."""
    expires_at = datetime.now(timezone.utc) + timedelta(seconds=ttl_seconds)
    expires_iso = expires_at.isoformat()
    if hasattr(graph, "_tx_write"):
        graph._tx_write(
            """
            MATCH (t:Task {id: $id}) WHERE t.tenant_id = $tid
            SET t.claim_locked_by = $claim_locked_by,
                t.claim_expires_at = $claim_expires_at,
                t.claim_locked_until = $claim_locked_until,
                t.locked_by = $locked_by,
                t.locked_until = $locked_until
            """,
            id=task_id,
            tid=tenant_id,
            claim_locked_by=owner,
            claim_expires_at=expires_iso,
            claim_locked_until=expires_iso,
            locked_by=owner,
            locked_until=expires_iso,
        )
    return expires_iso


def _clear_task_claim_lock(task_id: str, tenant_id: str) -> None:
    """Clear claim lock metadata after handoff/completion/cancel."""
    if hasattr(graph, "_tx_write"):
        graph._tx_write(
            """
            MATCH (t:Task {id: $id}) WHERE t.tenant_id = $tid
            REMOVE t.claim_locked_by, t.claim_expires_at, t.claim_locked_until, t.locked_by, t.locked_until
            """,
            id=task_id,
            tid=tenant_id,
        )
def _project_exists_for_tenant(project_id: str, tenant_id: str) -> bool:
    if hasattr(graph, "get_project"):
        return bool(graph.get_project(project_id, tenant_id=tenant_id))
    if not hasattr(graph, "_tx_read"):
        return False
    rows = graph._tx_read(
        "MATCH (p:Project {id: $pid, tenant_id: $tid}) RETURN p.id AS id LIMIT 1",
        pid=project_id,
        tid=tenant_id,
    )
    return bool(rows)


def _require_authenticated_invite_user(request: Request) -> tuple[str, str]:
    agent = getattr(request.state, "agent", None)
    if not agent:
        raise HTTPException(status_code=401, detail="Authentication required")
    if not getattr(agent, "agent_id", "") or not getattr(agent, "tenant_id", ""):
        raise HTTPException(status_code=401, detail="Authentication required")
    if agent.agent_id in ("public", "local", "unconfigured", "unknown"):
        raise HTTPException(status_code=401, detail="Authentication required")
    return str(agent.agent_id), str(agent.tenant_id)


# ── Tasks ────────────────────────────────────────────────────────────────────

@app.post("/tasks", summary="Create a task", tags=["tasks"])
def create_task(req: TaskCreateRequest, request: Request):
    """Create a new Task node in the graph."""
    tid = _resolve_tenant(request)
    author = _resolve_author(request)
    due = None
    if req.due_date:
        try:
            due = datetime.fromisoformat(req.due_date.replace("Z", "+00:00"))
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid due_date format")

    normalized_status = _normalize_status(req.status) or TaskStatus.todo.value
    normalized_priority = _normalize_priority(req.priority) or TaskPriority.medium.value
    assignee = (req.assignee or "").strip()
    if normalized_status == "in_progress" and not assignee and author != "unknown":
        # Claim semantics at creation time: active work must have an owner.
        assignee = author

    task = TaskModel(
        title=req.title,
        description=req.description,
        status=TaskStatus(normalized_status),
        priority=TaskPriority(normalized_priority),
        assignee=assignee,
        project_id=req.project_id,
        sprint_id=req.sprint_id,
        tenant_id=tid,
        tags=req.tags,
        due_date=due,
        estimate_hours=req.estimate_hours,
        related_decision_ids=req.related_decision_ids,
        blocked_by_ids=req.blocked_by_ids,
        created_by=author,
    )

    props = {
        "id": task.id,
        "title": task.title,
        "description": task.description,
        "status": task.status.value,
        "priority": task.priority.value,
        "assignee": task.assignee,
        "project_id": task.project_id or "",
        "sprint_id": task.sprint_id or "",
        "tenant_id": tid,
        "tags": task.tags,
        "due_date": str(due) if due else "",
        "estimate_hours": task.estimate_hours or 0,
        "related_decision_ids": task.related_decision_ids,
        "blocked_by_ids": task.blocked_by_ids,
        "created_by": author,
        "created_at": str(task.created_at),
        "updated_at": str(task.updated_at),
    }
    assignments = ", ".join(f"n.{k} = ${k}" for k in props if k != "id")
    if hasattr(graph, "_tx_write"):
        graph._tx_write(f"MERGE (n:Task {{id: $id}}) SET {assignments}", **props)
        # Link to project
        if task.project_id:
            graph._tx_write(
                "MATCH (t:Task {id: $tid}), (p:Project {id: $pid}) "
                "MERGE (t)-[:BELONGS_TO]->(p)",
                tid=task.id, pid=task.project_id,
            )
        # Link to sprint
        if task.sprint_id:
            graph._tx_write(
                "MATCH (t:Task {id: $tid}), (s:Sprint {id: $sid}) "
                "MERGE (t)-[:IN_SPRINT]->(s)",
                tid=task.id, sid=task.sprint_id,
            )
        # BLOCKED_BY edges
        for blocker_id in task.blocked_by_ids:
            graph._tx_write(
                "MATCH (t:Task {id: $tid}), (b:Task {id: $bid}) "
                "MERGE (t)-[:BLOCKED_BY]->(b)",
                tid=task.id, bid=blocker_id,
            )

    _write_coordination_event(
        sender=author,
        recipient=task.assignee or "broadcast",
        message=f"Task created: {task.title}",
        message_type="info",
        task_id=task.id,
        project_id=task.project_id or "",
        tenant_id=tid,
    )

    return {"id": task.id, "title": task.title, "status": task.status.value, "created": True}


@app.get("/tasks", summary="List tasks", tags=["tasks"])
def list_tasks(
    request: Request,
    project_id: Optional[str] = Query(None),
    sprint_id: Optional[str] = Query(None),
    status: Optional[str] = Query(None),
    assignee: Optional[str] = Query(None),
    limit: int = Query(50, ge=1, le=200),
):
    """List tasks, optionally filtered by project, sprint, status, or assignee."""
    tid = _resolve_tenant(request)
    q = "MATCH (t:Task) WHERE t.tenant_id = $tid"
    params: dict[str, Any] = {"tid": tid, "limit": limit}
    if project_id:
        q += " AND t.project_id = $project_id"
        params["project_id"] = project_id
    if sprint_id:
        q += " AND t.sprint_id = $sprint_id"
        params["sprint_id"] = sprint_id
    if status:
        q += " AND t.status = $status"
        params["status"] = status
    if assignee:
        q += " AND t.assignee = $assignee"
        params["assignee"] = assignee
    q += " RETURN t ORDER BY t.created_at DESC LIMIT $limit"

    if not hasattr(graph, "_tx_read"):
        return {"tasks": [], "note": "Task support requires Neo4j backend"}
    rows = graph._tx_read(q, **params)
    tasks = [dict(r["t"]) for r in rows] if rows else []
    return {"tasks": tasks, "count": len(tasks)}


@app.get("/tasks/{task_id}", summary="Get task details", tags=["tasks"])
def get_task(task_id: str, request: Request):
    """Get a specific task by ID."""
    tid = _resolve_tenant(request)
    if not hasattr(graph, "_tx_read"):
        raise HTTPException(status_code=500, detail="Requires Neo4j backend")
    rows = graph._tx_read(
        "MATCH (t:Task {id: $id}) WHERE t.tenant_id = $tid RETURN t",
        id=task_id, tid=tid,
    )
    if not rows:
        raise HTTPException(status_code=404, detail=f"Task {task_id} not found")
    return {"task": dict(rows[0]["t"])}


@app.put("/tasks/{task_id}", summary="Update a task", tags=["tasks"])
def update_task(task_id: str, req: TaskUpdateRequest, request: Request):
    """Update task fields with coordination protocol enforcement."""
    tid = _resolve_tenant(request)
    actor = _resolve_author(request)
    is_admin = _is_admin_agent(request)
    current = _load_task_for_update(task_id, tid)

    updates: dict[str, Any] = {}
    if req.title is not None:
        updates["title"] = req.title
    if req.description is not None:
        updates["description"] = req.description

    norm_status = _normalize_status(req.status)
    if norm_status is not None:
        updates["status"] = norm_status

    norm_priority = _normalize_priority(req.priority)
    if norm_priority is not None:
        updates["priority"] = norm_priority

    if req.assignee is not None:
        updates["assignee"] = req.assignee.strip()
    if req.sprint_id is not None:
        updates["sprint_id"] = req.sprint_id
    if req.tags is not None:
        updates["tags"] = req.tags
    if req.due_date is not None:
        updates["due_date"] = req.due_date
    if req.estimate_hours is not None:
        updates["estimate_hours"] = req.estimate_hours
    if req.actual_hours is not None:
        updates["actual_hours"] = req.actual_hours
    if req.related_decision_ids is not None:
        updates["related_decision_ids"] = req.related_decision_ids
    if req.blocked_by_ids is not None:
        updates["blocked_by_ids"] = req.blocked_by_ids

    event_meta: Optional[dict[str, str]] = None
    if req.protocol_action:
        event_meta = _apply_protocol_action(
            action=req.protocol_action,
            current=current,
            actor_id=actor,
            is_admin=is_admin,
            handoff_to=req.handoff_to,
            updates=updates,
        )

    _enforce_claim_lock(
        current=current,
        updates=updates,
        actor_id=actor,
        is_admin=is_admin,
    )
    _validate_transition_and_ownership(
        current=current,
        updates=updates,
        actor_id=actor,
        is_admin=is_admin,
    )

    if not updates:
        raise HTTPException(status_code=400, detail="No fields to update")

    now_iso = datetime.now(timezone.utc).isoformat()
    if updates.get("status") == "in_progress":
        updates["started_at"] = now_iso
    if updates.get("status") == "done":
        updates["completed_at"] = now_iso
    updates["updated_at"] = now_iso
    if updates.get("status") == "in_progress":
        _set_task_claim_lock(task_id, tid, owner=(updates.get("assignee") or actor or "unknown"), ttl_seconds=300)

    set_clause = ", ".join(f"t.{k} = ${k}" for k in updates)
    if hasattr(graph, "_tx_write"):
        graph._tx_write(
            f"MATCH (t:Task {{id: $id}}) WHERE t.tenant_id = $tid SET {set_clause}",
            id=task_id,
            tid=tid,
            **updates,
        )

    # Emit protocol audit event for agent coordination observability.
    if event_meta:
        note_suffix = f" Note: {req.note.strip()}" if req.note and req.note.strip() else ""
        _write_coordination_event(
            sender=actor,
            recipient=event_meta.get("recipient", "broadcast"),
            message=f"{event_meta.get('message', 'Task protocol action applied.')} [task={task_id}]{note_suffix}",
            message_type=event_meta.get("message_type", "info"),
            task_id=task_id,
            project_id=str(current.get("project_id", "") or ""),
            tenant_id=tid,
        )

    if not event_meta:
        _emit_task_update_event(
            actor=actor,
            previous=current,
            updates=updates,
            tenant_id=tid,
        )

    # Terminal or returned-to-queue states release any active claim lease.
    next_status = str(updates.get("status", current.get("status", "")) or "")
    if next_status in {"todo", "blocked", "review", "done", "cancelled"}:
        _clear_task_claim_lock(task_id, tid)
    current_after = current.copy()
    current_after.update(updates)
    return {
        "id": task_id,
        "updated": sorted(list(updates.keys())),
        "status": current_after.get("status", current.get("status")),
        "assignee": current_after.get("assignee", current.get("assignee", "")),
        "protocol_action": req.protocol_action or None,
    }


@app.post("/tasks/{task_id}/protocol", summary="Apply task coordination protocol action", tags=["tasks"])
def apply_task_protocol(task_id: str, req: TaskProtocolRequest, request: Request):
    """
    Enforce coordination lifecycle actions for parallel agent execution.

    Actions:
    - claim: assign to current agent and move to in_progress
    - handoff: reassign to handoff_to and move to todo
    - submit_review: move assignee-owned task to review
    - approve: move review task to done
    - block / unblock / cancel / reopen
    """
    update_payload = TaskUpdateRequest(
        protocol_action=req.action,
        handoff_to=req.handoff_to,
        note=req.note,
    )
    result = update_task(task_id, update_payload, request)
    current = _load_task_for_update(task_id, _resolve_tenant(request))
    return {
        "task_id": task_id,
        "action": req.action,
        "updated": result.get("updated", []),
        "task": current,
    }


@app.post("/tasks/{task_id}/heartbeat", summary="Renew task claim lease for active worker", tags=["tasks"])
def task_claim_heartbeat(task_id: str, request: Request, req: Optional[TaskLeaseRequest] = None):
    """
    Renew claim lease for an in-progress task.

    Operational intent:
    - Parallel agents must periodically heartbeat while actively working.
    - Lease expiration allows safe takeover if an agent crashes or stalls.
    """
    req = req or TaskLeaseRequest()
    tid = _resolve_tenant(request)
    actor = _resolve_author(request)
    is_admin = _is_admin_agent(request)
    current = _load_task_for_update(task_id, tid)

    current_status = str(current.get("status", "todo") or "todo")
    current_assignee = str(current.get("assignee", "") or "")
    if current_status != "in_progress":
        raise HTTPException(status_code=409, detail="Heartbeat allowed only for tasks in 'in_progress'.")
    if not is_admin and current_assignee and current_assignee != actor:
        raise HTTPException(
            status_code=403,
            detail=f"Only current assignee '{current_assignee}' or admin may renew this lease.",
        )

    now = datetime.now(timezone.utc)
    claim_expires_at = (now + timedelta(seconds=req.ttl_seconds)).isoformat()
    note = (req.note or "").strip()
    updates = {
        "claim_expires_at": claim_expires_at,
        "claim_locked_until": claim_expires_at,
        "locked_until": claim_expires_at,
        "claim_locked_by": current_assignee or actor,
        "locked_by": current_assignee or actor,
        "updated_at": now.isoformat(),
    }
    if note:
        updates["last_heartbeat_note"] = note[:300]

    set_clause = ", ".join(f"t.{k} = ${k}" for k in updates)
    if hasattr(graph, "_tx_write"):
        graph._tx_write(
            f"MATCH (t:Task {{id: $id}}) WHERE t.tenant_id = $tid SET {set_clause}",
            id=task_id,
            tid=tid,
            **updates,
        )

    _write_coordination_event(
        sender=actor,
        recipient=current_assignee or actor,
        message=f"Task lease heartbeat renewed for {req.ttl_seconds}s",
        message_type="info",
        task_id=task_id,
        project_id=str(current.get("project_id", "") or ""),
        tenant_id=tid,
    )

    current_after = current.copy()
    current_after.update(updates)
    return {
        "task_id": task_id,
        "status": "in_progress",
        "assignee": current_assignee,
        "claim_expires_at": claim_expires_at,
        "ttl_seconds": req.ttl_seconds,
        "task": _task_as_response(current_after),
    }


@app.delete("/tasks/{task_id}", summary="Delete a task", tags=["tasks"])
def delete_task(task_id: str, request: Request):
    """Delete a task and its edges."""
    tid = _resolve_tenant(request)
    if hasattr(graph, "_tx_write"):
        graph._tx_write(
            "MATCH (t:Task {id: $id}) WHERE t.tenant_id = $tid DETACH DELETE t",
            id=task_id, tid=tid,
        )
    return {"id": task_id, "deleted": True}


# ── Sprints ──────────────────────────────────────────────────────────────────

@app.post("/sprints", summary="Create a sprint", tags=["tasks"])
def create_sprint(req: SprintCreateRequest, request: Request):
    """Create a new Sprint node."""
    tid = _resolve_tenant(request)
    start = end = None
    try:
        if req.start_date:
            start = datetime.fromisoformat(req.start_date.replace("Z", "+00:00"))
        if req.end_date:
            end = datetime.fromisoformat(req.end_date.replace("Z", "+00:00"))
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid date format")

    sprint = SprintModel(
        name=req.name,
        description=req.description,
        project_id=req.project_id,
        tenant_id=tid,
        start_date=start,
        end_date=end,
        goal=req.goal,
    )

    props = {
        "id": sprint.id,
        "name": sprint.name,
        "description": sprint.description,
        "status": sprint.status.value,
        "project_id": sprint.project_id or "",
        "tenant_id": tid,
        "start_date": str(start) if start else "",
        "end_date": str(end) if end else "",
        "goal": sprint.goal,
        "created_at": str(sprint.created_at),
    }
    assignments = ", ".join(f"n.{k} = ${k}" for k in props if k != "id")
    if hasattr(graph, "_tx_write"):
        graph._tx_write(f"MERGE (n:Sprint {{id: $id}}) SET {assignments}", **props)
        if sprint.project_id:
            graph._tx_write(
                "MATCH (s:Sprint {id: $sid}), (p:Project {id: $pid}) "
                "MERGE (s)-[:BELONGS_TO]->(p)",
                sid=sprint.id, pid=sprint.project_id,
            )

    return {"id": sprint.id, "name": sprint.name, "status": sprint.status.value, "created": True}


@app.get("/sprints", summary="List sprints", tags=["tasks"])
def list_sprints(
    request: Request,
    project_id: Optional[str] = Query(None),
    status: Optional[str] = Query(None),
    limit: int = Query(20, ge=1, le=100),
):
    """List sprints for a tenant, optionally filtered by project and status."""
    tid = _resolve_tenant(request)
    q = "MATCH (s:Sprint) WHERE s.tenant_id = $tid"
    params: dict[str, Any] = {"tid": tid, "limit": limit}
    if project_id:
        q += " AND s.project_id = $project_id"
        params["project_id"] = project_id
    if status:
        q += " AND s.status = $status"
        params["status"] = status
    q += " RETURN s ORDER BY s.created_at DESC LIMIT $limit"

    if not hasattr(graph, "_tx_read"):
        return {"sprints": [], "note": "Sprint support requires Neo4j backend"}
    rows = graph._tx_read(q, **params)
    sprints = [dict(r["s"]) for r in rows] if rows else []
    return {"sprints": sprints, "count": len(sprints)}


@app.get("/sprints/{sprint_id}", summary="Get sprint details", tags=["tasks"])
def get_sprint(sprint_id: str, request: Request):
    """Get a sprint and its tasks."""
    tid = _resolve_tenant(request)
    if not hasattr(graph, "_tx_read"):
        raise HTTPException(status_code=500, detail="Requires Neo4j backend")
    rows = graph._tx_read(
        "MATCH (s:Sprint {id: $id}) WHERE s.tenant_id = $tid RETURN s",
        id=sprint_id, tid=tid,
    )
    if not rows:
        raise HTTPException(status_code=404, detail=f"Sprint {sprint_id} not found")
    sprint = dict(rows[0]["s"])
    # Get tasks in this sprint
    task_rows = graph._tx_read(
        "MATCH (t:Task) WHERE t.sprint_id = $sid AND t.tenant_id = $tid "
        "RETURN t ORDER BY t.priority, t.created_at",
        sid=sprint_id, tid=tid,
    )
    tasks = [dict(r["t"]) for r in task_rows] if task_rows else []
    return {"sprint": sprint, "tasks": tasks, "task_count": len(tasks)}


@app.put("/sprints/{sprint_id}", summary="Update a sprint", tags=["tasks"])
def update_sprint(sprint_id: str, req: SprintUpdateRequest, request: Request):
    """Update sprint fields."""
    tid = _resolve_tenant(request)
    updates: dict[str, Any] = {}
    if req.name is not None:
        updates["name"] = req.name
    if req.description is not None:
        updates["description"] = req.description
    if req.status is not None:
        updates["status"] = req.status
    if req.start_date is not None:
        updates["start_date"] = req.start_date
    if req.end_date is not None:
        updates["end_date"] = req.end_date
    if req.goal is not None:
        updates["goal"] = req.goal

    if not updates:
        raise HTTPException(status_code=400, detail="No fields to update")

    set_clause = ", ".join(f"s.{k} = ${k}" for k in updates)
    if hasattr(graph, "_tx_write"):
        graph._tx_write(
            f"MATCH (s:Sprint {{id: $id}}) WHERE s.tenant_id = $tid SET {set_clause}",
            id=sprint_id, tid=tid, **updates,
        )

    return {"id": sprint_id, "updated": list(updates.keys())}


# ─── Conflict Endpoints ───────────────────────────────────────────────────────

@app.get("/memory/conflicts", summary="List unresolved write conflicts")
def list_conflicts(request: Request, project_id: str = Query(default=""), limit: int = Query(default=50)):
    """List ConflictEvent nodes with status='pending'. Created by safe_write() on version mismatch."""
    _agent_ctx = getattr(request.state, "agent", None)
    _tid = getattr(_agent_ctx, "tenant_id", "default") if _agent_ctx else "default"
    q = "MATCH (c:ConflictEvent) WHERE c.status = 'pending' AND c.tenant_id = $tid"
    params: dict = {"limit": limit, "tid": _tid}
    if project_id:
        q += " AND c.project_id = $pid"
        params["pid"] = project_id
    q += " RETURN c ORDER BY c.created_at DESC LIMIT $limit"
    rows = graph._tx_read(q, **params)
    return {"conflicts": [dict(r["c"]) for r in rows], "count": len(rows)}


@app.post("/memory/conflicts/{conflict_id}/resolve", summary="Resolve a write conflict")
def resolve_conflict(
    conflict_id: str,
    resolution: str = Query(..., description="keep_a | keep_b | merge"),
):
    """
    Resolve a ConflictEvent.
    - keep_a: accept the version already in the graph (discard agent_b's write)
    - keep_b: apply agent_b's rejected payload to the node
    - merge: mark as merged (manual resolution expected — closes the conflict ticket)
    """
    import datetime as _dt
    rows = graph._tx_read(
        "MATCH (c:ConflictEvent {id: $id}) RETURN c LIMIT 1", id=conflict_id
    )
    if not rows:
        raise HTTPException(status_code=404, detail="Conflict not found")
    conflict = dict(rows[0]["c"])

    status_map = {"keep_a": "resolved_a", "keep_b": "resolved_b", "merge": "merged"}
    new_status = status_map.get(resolution)
    if not new_status:
        raise HTTPException(status_code=400, detail="resolution must be keep_a | keep_b | merge")

    graph._tx_write(
        "MATCH (c:ConflictEvent {id: $id}) SET c.status = $s, c.resolved_at = $ts",
        id=conflict_id, s=new_status, ts=_dt.datetime.utcnow().isoformat(),
    )

    if resolution == "keep_b":
        # Apply agent_b's payload to the node (deserialize stored string dict)
        import ast
        try:
            payload = ast.literal_eval(conflict.get("payload_b", "{}"))
            if payload and conflict.get("node_type") and conflict.get("node_id"):
                set_clause = ", ".join(f"n.{k} = ${k}" for k in payload)
                graph._tx_write(
                    f"MATCH (n:{conflict['node_type']} {{id: $nid}}) SET {set_clause}, n.version = n.version + 1",
                    nid=conflict["node_id"], **payload,
                )
        except Exception:
            pass  # payload parse failed — conflict is still marked resolved

    return {"ok": True, "conflict_id": conflict_id, "resolution": new_status}


# ─── Version History Endpoints ────────────────────────────────────────────────


@app.get("/memory/versions/{node_id}", summary="Get version chain for a node")
def get_version_chain(
    request: Request,
    node_id: str,
    node_type: str = Query(default="Decision", description="Node label: Decision, Constraint, or Preference"),
):
    """
    Walk the SUPERSEDED_BY chain for a node and return all versions,
    oldest first. Useful for auditing what changed and when.
    """
    _agent_ctx = getattr(request.state, "agent", None)
    _tid = getattr(_agent_ctx, "tenant_id", "default") if _agent_ctx else "default"
    chain = graph.get_version_chain(node_id, node_type=node_type, tenant_id=_tid)
    return {"node_id": node_id, "node_type": node_type, "versions": chain, "count": len(chain)}


@app.post("/memory/supersede", summary="Manually supersede a node with a newer one")
def supersede_node(
    old_id: str = Query(..., description="ID of the node to mark as superseded"),
    new_id: str = Query(..., description="ID of the replacement node"),
    node_type: str = Query(default="Decision", description="Node label"),
    reason: str = Query(default="manual", description="Why this was superseded"),
):
    """
    Explicitly mark a node as superseded by another. Creates a SUPERSEDED_BY edge.
    Use this when an agent or human recognizes a decision/constraint/preference
    has been replaced but the system didn't auto-detect it.
    """
    graph.supersede_node(old_id=old_id, new_id=new_id, node_type=node_type, reason=reason)
    return {"ok": True, "superseded": old_id, "superseded_by": new_id, "reason": reason}


# ─── Artifact Endpoints ───────────────────────────────────────────────────────

from ..schema import Artifact, ArtifactType

class ArtifactCreateRequest(BaseModel):
    name: str
    content: str = ""
    artifact_type: str = "other"
    mime_type: str = "text/plain"
    path: str = ""
    description: str = ""
    session_id: str = ""
    project_id: Optional[str] = None
    tags: list[str] = []
    preview_url: str = ""


@app.post("/artifacts", summary="Upload or update an artifact (file)")
def create_artifact(req: ArtifactCreateRequest, request: Request):
    """
    Store any digital artifact — code, HTML, markdown, config, prompts.
    Content up to 100KB stored inline in Neo4j; larger files store path reference.
    Any agent on any platform can call this to persist files across sessions.
    """
    try:
        atype = ArtifactType(req.artifact_type)
    except ValueError:
        atype = ArtifactType.other

    artifact = Artifact(
        name=req.name,
        content=req.content,
        artifact_type=atype,
        mime_type=req.mime_type,
        path=req.path,
        description=req.description,
        session_id=req.session_id,
        project_id=req.project_id,
        tags=req.tags,
        preview_url=req.preview_url,
        created_by="agent",
        size_bytes=len(req.content.encode()),
        tenant_id=_resolve_tenant(request),
    )
    if hasattr(graph, "save_artifact"):
        graph.save_artifact(artifact)
    return {
        "id": artifact.id,
        "name": artifact.name,
        "size_bytes": artifact.size_bytes,
        "stored": True,
    }


@app.get("/artifacts", summary="List artifacts (optionally filtered)")
def list_artifacts(
    request: Request,
    project_id: Optional[str] = None,
    artifact_type: Optional[str] = None,
    session_id: Optional[str] = None,
    limit: int = 50,
):
    """List stored artifacts. Filter by project, type, or session. Returns metadata only (no content)."""
    if not hasattr(graph, "get_artifacts"):
        return {"artifacts": []}
    artifacts = graph.get_artifacts(
        project_id=project_id,
        artifact_type=artifact_type,
        session_id=session_id,
        limit=limit,
        tenant_id=_resolve_tenant(request),
    )
    # Strip content from list view — use GET /artifacts/{id} for full content
    slim = [{k: v for k, v in a.items() if k != "content"} for a in artifacts]
    return {"artifacts": slim, "count": len(slim)}


def _artifact_for_tenant_or_404(artifact_id: str, request: Request) -> dict:
    if not hasattr(graph, "get_artifact"):
        raise HTTPException(status_code=501, detail="Artifact storage not available")
    artifact = graph.get_artifact(artifact_id)
    if not artifact:
        raise HTTPException(status_code=404, detail=f"Artifact {artifact_id} not found")
    tid = _resolve_tenant(request)
    if artifact.get("tenant_id") != tid:
        raise HTTPException(status_code=404, detail=f"Artifact {artifact_id} not found")
    return artifact


@app.get("/artifacts/{artifact_id}", summary="Fetch a single artifact with full content")
def get_artifact(artifact_id: str, request: Request):
    """Retrieve full artifact including file content. Agents use this to read files across sessions."""
    return _artifact_for_tenant_or_404(artifact_id, request)


class MemoryNodeUpdateRequest(BaseModel):
    content: Optional[str] = None
    rationale: Optional[str] = None
    status: Optional[str] = None          # active | archived | invalidated
    confidence: Optional[float] = None
    tags: Optional[list[str]] = None


@app.put("/memory/nodes/{node_id}", summary="Update a memory node's editable fields")
def update_memory_node(node_id: str, req: MemoryNodeUpdateRequest):
    """
    Patch editable fields on any memory node (Decision, Constraint, Preference, etc.).
    Only provided fields are updated — omitted fields are left unchanged.
    status='archived' is a soft-archive (excluded from context but kept for audit).
    """
    if not hasattr(graph, "_tx_write"):
        raise HTTPException(status_code=501, detail="Backend does not support node writes")

    updates: dict = {}
    if req.content    is not None: updates["content"]    = req.content
    if req.rationale  is not None: updates["rationale"]  = req.rationale
    if req.confidence is not None: updates["confidence"] = req.confidence
    if req.tags       is not None: updates["tags"]       = json.dumps(req.tags)
    if req.status     is not None:
        if req.status not in ("active", "archived", "invalidated"):
            raise HTTPException(status_code=400, detail="status must be active | archived | invalidated")
        updates["status"] = req.status
        if req.status == "archived":
            updates["archived_at"] = str(datetime.now(timezone.utc))
        elif req.status == "invalidated":
            updates["invalid_at"] = str(datetime.now(timezone.utc))

    if not updates:
        raise HTTPException(status_code=400, detail="No fields provided to update")

    updates["updated_at"] = str(datetime.now(timezone.utc))
    set_clause = ", ".join(f"n.{k} = ${k}" for k in updates)
    try:
        graph._tx_write(
            f"MATCH (n {{id: $nid}}) SET {set_clause}",
            nid=node_id, **updates,
        )
        return {"updated": True, "id": node_id, "fields": list(updates.keys())}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Update failed: {e}")


@app.delete("/memory/nodes/{node_id}", summary="Soft-delete a memory node")
def delete_memory_node(
    node_id: str,
    reason: Optional[str] = Query(None, description="Reason for deletion (audit trail)"),
):
    """Bi-temporal soft-delete: sets invalid_at + status='invalidated' on the node.
    The node remains in the graph for audit purposes but is excluded from context retrieval.
    Requires X-API-Key (enforced by middleware on DELETE)."""
    if not hasattr(graph, "invalidate_node"):
        raise HTTPException(status_code=501, detail="Invalidation not available on this backend")
    try:
        graph.invalidate_node(node_id)
        # Log the deletion in audit trail
        try:
            from .audit import log_context_retrieval
            log_context_retrieval(
                agent_id="dashboard-user",
                filters={"action": "delete", "node_id": node_id, "reason": reason or "user-initiated"},
                result_counts={"deleted": 1},
            )
        except Exception:
            pass  # Audit logging is best-effort
        return {"invalidated": True, "id": node_id, "reason": reason}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to invalidate node: {e}")


@app.delete("/artifacts/{artifact_id}", summary="Delete an artifact")
def delete_artifact(artifact_id: str, request: Request):
    """Remove an artifact from the store."""
    _artifact_for_tenant_or_404(artifact_id, request)
    if not hasattr(graph, "delete_artifact"):
        raise HTTPException(status_code=501, detail="Artifact storage not available")
    deleted = graph.delete_artifact(artifact_id)
    if not deleted:
        raise HTTPException(status_code=404, detail=f"Artifact {artifact_id} not found")
    return {"deleted": True, "id": artifact_id}


@app.get("/artifacts/{artifact_id}/preview", summary="Render an HTML artifact in browser")
def preview_artifact(artifact_id: str, request: Request):
    """
    Render an HTML artifact directly in the browser.
    Works locally (localhost) and on Render — no special setup needed.
    For non-HTML types, returns raw content with appropriate MIME type.
    """
    from fastapi.responses import HTMLResponse, PlainTextResponse
    artifact = _artifact_for_tenant_or_404(artifact_id, request)
    content = artifact.get("content", "") or ""
    atype = artifact.get("artifact_type", "other")
    if atype == "html":
        return HTMLResponse(content=content)
    if atype == "image":
        mime = artifact.get("mime_type", "image/png") or "image/png"
        if content.startswith("data:image/"):
            try:
                _, b64 = content.split(",", 1)
                raw = base64.b64decode(b64)
                return Response(content=raw, media_type=mime)
            except Exception:
                return PlainTextResponse(content="Invalid image artifact encoding", status_code=422)
        return PlainTextResponse(content=content)
    return PlainTextResponse(content=content)


@app.post("/ops/agent/reset", summary="Reset a specific pipeline agent's cached state")
def ops_agent_reset(agent: str = ""):
    """
    Reset a named agent. Pipeline agents are stateless functions —
    this clears any in-memory caches and confirms the agent module is importable.
    Useful when an agent is behaving unexpectedly after a code deploy.
    """
    VALID_AGENTS = {"intake", "classifier", "security", "graph_writer", "retrieval", "pipeline"}
    agent = agent.lower().strip()
    if not agent:
        return {"reset": True, "agents": list(VALID_AGENTS), "note": "no agent specified — all confirmed ok"}
    if agent not in VALID_AGENTS:
        raise HTTPException(status_code=400, detail=f"Unknown agent '{agent}'. Valid: {sorted(VALID_AGENTS)}")
    # Stateless — just confirm importable
    try:
        if agent == "intake":
            from ..agents.intake import run_intake  # noqa
        elif agent == "classifier":
            from ..agents.classifier import run_classifier  # noqa
        elif agent == "security":
            from ..agents.security import run_security  # noqa
        elif agent == "graph_writer":
            from ..agents.graph_writer import run_graph_writer  # noqa
        elif agent == "retrieval":
            from ..agents.retrieval import run_retrieval  # noqa
        elif agent == "pipeline":
            from ..agents.pipeline import build_pipeline  # noqa
        return {"reset": True, "agent": agent, "status": "ok — module loaded cleanly"}
    except Exception as e:
        return {"reset": False, "agent": agent, "error": str(e)}


@app.get("/health")
def health():
    h = {"status": "ok", "version": _VERSION, "backend": type(graph).__name__}
    if _GIT_SHA:
        h["git_commit"] = _GIT_SHA
    return h


# ── Security / CVE endpoints ──────────────────────────────────────────────────

@app.get("/security/cves", summary="CVEs affecting the monitored stack")
def security_cves(
    severity: Optional[str] = Query(None, description="Filter: CRITICAL, HIGH, MEDIUM, LOW, exploited"),
    limit: int = Query(50, ge=1, le=200),
):
    """
    Returns CVE Skill nodes ingested by the CVE watcher.
    Prioritises actively exploited (CISA KEV) → CRITICAL → HIGH.

    Used by: dashboard security panel, agent context brief, CI/CD security gates.
    """
    try:
        rows = graph._tx_read(
            """
            MATCH (s:Skill)
            WHERE 'cve' IN s.tags AND 'active' IN s.tags
            RETURN s.id AS id, s.name AS name, s.summary AS summary,
                   s.tags AS tags, s.created_at AS created_at,
                   s.url AS url
            ORDER BY s.created_at DESC
            LIMIT 500
            """
        )
    except Exception as e:
        raise HTTPException(status_code=503, detail=f"Graph unavailable: {e}")

    results = []
    for r in rows:
        tags = r.get("tags") or []
        if severity:
            sev_lower = severity.lower()
            if sev_lower == "exploited":
                if "exploited" not in tags and "kev" not in tags:
                    continue
            elif sev_lower not in tags:
                continue
        results.append({
            "id": r["id"],
            "name": r["name"],
            "summary": r["summary"],
            "tags": tags,
            "url": r.get("url"),
            "created_at": r.get("created_at"),
            "exploited_in_wild": "exploited" in tags or "kev" in tags,
        })

    results = results[:limit]
    return {
        "cves": results,
        "total": len(results),
        "filtered_by": severity,
        "monitored_packages": len([]),  # populated from watcher if available
        "watcher_status": getattr(
            getattr(app.state, "cve_watcher", None), "status", lambda: None
        )(),
    }


@app.get("/security/audit", summary="Full security posture brief")
def security_audit():
    """
    Comprehensive security brief: CVE summary + firewall stats + ABAC summary.
    Intended for agent session start and compliance reporting.
    """
    from ..workers.cve_watcher import get_security_brief
    brief = get_security_brief(graph)
    return {
        "security_brief": brief,
        "layers": {
            "abac": "4-tier role model (admin/contributor/reader/external)",
            "sanitization": "2-layer regex+heuristic pre-filter on all ingest",
            "firewall": "5-layer: regex, semantic injection, ABAC trust, contradiction, confidence floor",
            "proposal_queue": "agent-inferred nodes go to HITL before graph commit",
            "novelty_detection": "semantic similarity gate at write time",
        },
        "cve_monitoring": {
            "feeds": ["OSV (api.osv.dev)", "CISA KEV"],
            "poll_interval_hours": int(os.environ.get("CVE_POLL_INTERVAL_HOURS", "6")),
            "watcher_status": getattr(
                getattr(app.state, "cve_watcher", None), "status", lambda: None
            )(),
        },
    }


@app.get("/ops/config", summary="Get current runtime LLM + pipeline configuration")
def ops_config_get(request: Request):
    """Return the active LLM provider, model, and key availability without exposing secrets."""
    import os as _os
    provider = _os.environ.get("LLM_PROVIDER", "anthropic")
    return {
        "llm_provider": provider,
        "anthropic_model": _os.environ.get("ANTHROPIC_MODEL", "claude-haiku-4-5"),
        "anthropic_key_set": bool(_os.environ.get("ANTHROPIC_API_KEY")),
        "ollama_model": _os.environ.get("OLLAMA_MODEL", "qwen2.5:32b"),
        "ollama_base_url": _os.environ.get("OLLAMA_BASE_URL", "http://localhost:11434"),
        "openai_model": _os.environ.get("OPENAI_MODEL", "gpt-4o-mini"),
        "openai_key_set": bool(_os.environ.get("OPENAI_API_KEY")),
        "gemini_key_set": bool(_os.environ.get("GOOGLE_API_KEY")),
    }


@app.post("/ops/config", summary="Update runtime LLM provider and model (no restart required)")
async def ops_config_set(request: Request):
    """
    Hot-swap the LLM provider at runtime — takes effect immediately for all new ingest calls.
    Does NOT persist across server restarts; update .env for permanent changes.

    Body fields (all optional):
      llm_provider     : "anthropic" | "ollama" | "openai" | "gemini"
      anthropic_model  : e.g. "claude-haiku-4-5"
      ollama_model     : e.g. "qwen2.5:32b"
      ollama_base_url  : e.g. "http://localhost:11434"
      openai_model     : e.g. "gpt-4o-mini"
    """
    import os as _os
    import importlib
    import collab_memory.encoder as _encoder_mod

    agent = getattr(request.state, "agent", None)
    role = agent.role if agent else "anonymous"
    if role not in ("admin", "internal"):
        raise HTTPException(status_code=403, detail="Config changes require admin or internal role")

    try:
        body = await request.json()
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid JSON body")

    _VALID_PROVIDERS = {"anthropic", "ollama", "openai", "gemini"}
    changed = {}

    if "llm_provider" in body:
        val = str(body["llm_provider"]).lower()
        if val not in _VALID_PROVIDERS:
            raise HTTPException(status_code=400, detail=f"llm_provider must be one of: {sorted(_VALID_PROVIDERS)}")
        _os.environ["LLM_PROVIDER"] = val
        _encoder_mod.LLM_PROVIDER = val
        changed["llm_provider"] = val

    if "anthropic_model" in body:
        val = str(body["anthropic_model"])
        _os.environ["ANTHROPIC_MODEL"] = val
        changed["anthropic_model"] = val

    if "ollama_model" in body:
        val = str(body["ollama_model"])
        _os.environ["OLLAMA_MODEL"] = val
        _encoder_mod.OLLAMA_MODEL = val
        changed["ollama_model"] = val

    if "ollama_base_url" in body:
        val = str(body["ollama_base_url"]).rstrip("/")
        _os.environ["OLLAMA_BASE_URL"] = val
        _encoder_mod.OLLAMA_BASE_URL = val
        changed["ollama_base_url"] = val

    if "openai_model" in body:
        val = str(body["openai_model"])
        _os.environ["OPENAI_MODEL"] = val
        changed["openai_model"] = val

    logger.info("ops/config updated | role=%s | changes=%s", role, changed)
    return {"status": "ok", "applied": changed, "note": "Active immediately. Update .env to persist across restarts."}


@app.get("/ops/ping", summary="Keepalive ping — prevents Render cold starts")
def ops_ping():
    """
    Lightweight endpoint for UptimeRobot / external cron to ping every 14 minutes.
    Keeps Render free-tier instance warm — eliminates cold-start delays on all other endpoints.
    Configure: https://uptimerobot.com → New Monitor → HTTP(s) → URL → /ops/ping → every 14 min
    """
    return {"pong": True}


@app.get("/ops/logs", summary="In-memory service log ring buffer (last 500 lines)")
def ops_logs(
    limit: int = 200,
    level: str = "",
    api_key: str = "",
    request: Request = None,
):
    """
    Returns the last N log records captured since server startup.
    Used by the Memory Dashboard to display real-time service logs without
    requiring Render dashboard access.

    Auth: X-API-Key header or ?api_key= query param (read-only key accepted).
    Level filter: ?level=ERROR  or  ?level=WARNING  (case-insensitive).
    """
    # Auth gate — same pattern as other read-only endpoints
    provided = api_key
    if not provided and request:
        provided = request.headers.get("X-API-Key", "")
    valid = {os.environ.get("COLLAB_API_KEY", ""), os.environ.get("COLLAB_API_KEY_READONLY", "")}
    valid.discard("")
    if valid and provided not in valid:
        from fastapi import HTTPException as _HTTPException
        raise _HTTPException(status_code=403, detail="Invalid API key")

    entries = list(_LOG_BUFFER)
    if level:
        lvl = level.upper()
        entries = [e for e in entries if e["level"] == lvl]
    entries = entries[-limit:]
    return {"count": len(entries), "logs": entries}


def _require_full_collab_api_key(request: Request, api_key_query: str = "") -> None:
    """Primary API key only (not read-only). If no keys configured, allow (local dev)."""
    provided = (api_key_query or request.headers.get("X-API-Key", "") or "").strip()
    full = os.environ.get("COLLAB_API_KEY", "").strip()
    ro = os.environ.get("COLLAB_API_KEY_READONLY", "").strip()
    if full:
        if provided != full:
            raise HTTPException(
                status_code=403,
                detail="Invalid or missing API key (primary COLLAB_API_KEY required).",
            )
        return
    if ro:
        raise HTTPException(
            status_code=503,
            detail="COLLAB_API_KEY must be set for this endpoint (read-only key is not sufficient).",
        )


def _report_video_enforcement_mode() -> str:
    """
    Delivery-report video enforcement mode:
    - strict (default): missing `video_urls` returns HTTP 400
    - warn: allow request, include warning in response metadata
    """
    mode = os.environ.get("WORK_REPORT_VIDEO_ENFORCEMENT", "strict").strip().lower()
    return "warn" if mode in {"warn", "soft", "off"} else "strict"


_EMAIL_REPORTING_MODES = frozenset({"off", "text_only", "full"})
_EMAIL_REPORTING_MODE_DEFAULT = (
    os.environ.get("EMAIL_REPORTING_MODE", "text_only").strip().lower() or "text_only"
)
if _EMAIL_REPORTING_MODE_DEFAULT not in _EMAIL_REPORTING_MODES:
    _EMAIL_REPORTING_MODE_DEFAULT = "text_only"
_EMAIL_REPORTING_MODE = _EMAIL_REPORTING_MODE_DEFAULT


def _email_reporting_mode() -> str:
    global _EMAIL_REPORTING_MODE
    env_mode = (os.environ.get("EMAIL_REPORTING_MODE", "").strip().lower() or "")
    mode = env_mode or _EMAIL_REPORTING_MODE or _EMAIL_REPORTING_MODE_DEFAULT
    if mode not in _EMAIL_REPORTING_MODES:
        mode = _EMAIL_REPORTING_MODE_DEFAULT
    _EMAIL_REPORTING_MODE = mode
    return mode


def _set_email_reporting_mode(mode: str) -> str:
    global _EMAIL_REPORTING_MODE
    m = str(mode or "").strip().lower()
    if m not in _EMAIL_REPORTING_MODES:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid reporting mode '{m}'. Must be one of: {sorted(_EMAIL_REPORTING_MODES)}",
        )
    _EMAIL_REPORTING_MODE = m
    os.environ["EMAIL_REPORTING_MODE"] = m
    return _EMAIL_REPORTING_MODE


def _email_reporting_policy_payload() -> dict[str, Any]:
    mode = _email_reporting_mode()
    return {
        "mode": mode,
        "allowed_modes": sorted(_EMAIL_REPORTING_MODES),
        "reports_enabled": mode != "off",
        "media_enabled": mode == "full",
        "default_mode": _EMAIL_REPORTING_MODE_DEFAULT,
    }


_ACCESS_REQUEST_STATUS_VALUES = frozenset({
    "pending",
    "approved",
    "rejected",
    "invited",
    "provisioned",
    "contacted",
    "declined",
})


class OpsAccessRequestStatusBody(BaseModel):
    status: str
    note: str = ""

    @field_validator("status")
    @classmethod
    def _norm_status(cls, v: object) -> str:
        s = str(v or "").strip().lower()
        if s not in _ACCESS_REQUEST_STATUS_VALUES:
            raise ValueError(
                f"status must be one of: {', '.join(sorted(_ACCESS_REQUEST_STATUS_VALUES))}"
            )
        return s

    @field_validator("note", mode="before")
    @classmethod
    def _clip_note(cls, v: object) -> str:
        return str(v or "")[:2000]


class OpsTransactionalMailBody(BaseModel):
    """Send branded test and/or instance onboarding email (primary API key only)."""

    kind: str
    to: str
    role_description: str = "workspace administrator"
    # Work report fields (optional unless kind=work_report)
    subject: str = ""
    repo_name: str = ""
    repo_url: str = ""
    branch_name: str = ""
    commit_sha: str = ""
    pr_url: str = ""
    task_summary: str = ""
    changes: list[str] = []
    updates: list[str] = []
    enhancements: list[str] = []
    existing_code: list[str] = []
    tests: list[str] = []
    implementation_impact: list[str] = []
    suggestions: list[str] = []
    video_urls: list[str] = []
    screenshot_urls: list[str] = []
    implementation_notes: list[str] = []
    risk_notes: list[str] = []
    # Release decision fields (optional unless kind=release_decision)
    decision: str = ""
    target_branch: str = "main"
    project_id: str = ""
    include_latest_snapshot: bool = True
    approved_prs: list[str] = Field(default_factory=list)
    blocked_prs: list[str] = Field(default_factory=list)
    summary: str = ""
    blockers: list[str] = Field(default_factory=list)
    next_actions: list[str] = Field(default_factory=list)
    artifacts: list[str] = Field(default_factory=list)

    @field_validator("kind")
    @classmethod
    def _norm_kind(cls, v: object) -> str:
        s = str(v or "").strip().lower()
        allowed = frozenset({"test", "instance_invite", "test_and_invite", "work_report", "release_decision"})
        if s not in allowed:
            raise ValueError(f"kind must be one of: {', '.join(sorted(allowed))}")
        return s

    @field_validator("to", mode="before")
    @classmethod
    def _strip_to(cls, v: object) -> str:
        return str(v or "").strip()

    @field_validator(
        "subject",
        "repo_name",
        "repo_url",
        "branch_name",
        "commit_sha",
        "pr_url",
        "task_summary",
        mode="before",
    )
    @classmethod
    def _strip_text_fields(cls, v: object) -> str:
        return str(v or "").strip()

    @field_validator(
        "changes",
        "updates",
        "enhancements",
        "existing_code",
        "tests",
        "implementation_impact",
        "suggestions",
        "video_urls",
        "screenshot_urls",
        "implementation_notes",
        "risk_notes",
        mode="before",
    )
    @classmethod
    def _normalize_str_list(cls, v: object) -> list[str]:
        if v is None:
            return []
        if isinstance(v, str):
            s = v.strip()
            return [s] if s else []
        if isinstance(v, (list, tuple)):
            out: list[str] = []
            for item in v:
                s = str(item or "").strip()
                if s:
                    out.append(s[:1000])
            return out[:50]
        return []

    @field_validator("decision", "target_branch", "summary", mode="before")
    @classmethod
    def _strip_text(cls, v: object) -> str:
        return str(v or "").strip()


class OpsEmailReportingPolicyBody(BaseModel):
    mode: str

    @field_validator("mode", mode="before")
    @classmethod
    def _norm_mode(cls, v: object) -> str:
        s = str(v or "").strip().lower()
        if s not in _EMAIL_REPORTING_MODES:
            raise ValueError(f"mode must be one of: {', '.join(sorted(_EMAIL_REPORTING_MODES))}")
        return s


def _public_base_url(request: Request) -> str:
    configured = os.environ.get("COLLAB_PUBLIC_URL", "").strip().rstrip("/")
    if configured:
        return configured
    try:
        return str(request.base_url).rstrip("/")
    except Exception:
        return ""


def _latest_snapshot_artifacts_for_release(project_id: str, request: Request, include_media: bool = True) -> list[str]:
    pid = (project_id or "").strip()
    if not pid:
        return []
    try:
        data = list_project_snapshots(project_id=pid, request=request, limit=1)
    except Exception:
        return []
    snaps = data.get("snapshots") if isinstance(data, dict) else []
    if not snaps:
        return []
    snap = snaps[0] or {}
    artifacts: list[str] = []

    snapshot_id = str(snap.get("id") or "").strip()
    if snapshot_id:
        artifacts.append(f"project_snapshot_id:{snapshot_id}")
    saved_at = str(snap.get("saved_at") or "").strip()
    if saved_at:
        artifacts.append(f"project_snapshot_saved_at:{saved_at}")
    summary = str(snap.get("summary") or "").strip()
    if summary:
        artifacts.append(f"project_snapshot_summary:{summary[:240]}")
    screenshot_id = str(snap.get("screenshot_artifact_id") or "").strip()
    if include_media and screenshot_id:
        artifacts.append(f"project_snapshot_preview:{_public_base_url(request)}/artifacts/{screenshot_id}/preview")
    return artifacts[:10]


def _artifact_has_media_reference(value: str) -> bool:
    s = str(value or "").strip().lower()
    if not s:
        return False
    media_markers = (
        ".mp4",
        ".webm",
        ".mov",
        ".avi",
        ".png",
        ".jpg",
        ".jpeg",
        ".gif",
        ".webp",
        "<video",
        "<img",
        "project_snapshot_preview:",
    )
    return any(m in s for m in media_markers)


@app.get("/ops/instance-access-summary", summary="Redacted instance / email env summary (primary key only)")
def ops_instance_access_summary(request: Request, api_key: str = Query("", description="Same as X-API-Key header")):
    """Counts only — no email addresses returned. Use to confirm super-admin / allowlist / tenant env is set."""
    _require_full_collab_api_key(request, api_key)
    from collab_memory.auth.instance_access import (
        allowed_instance_login_emails,
        count_instance_admin_emails,
        count_super_admin_emails,
        instance_zero_member_emails,
        instance_zero_tenant_id,
    )

    al = allowed_instance_login_emails()
    sa_n = count_super_admin_emails()
    ia_n = count_instance_admin_emails()
    iz = instance_zero_member_emails()
    return {
        "collab_public_url": (os.environ.get("COLLAB_PUBLIC_URL", "").strip().rstrip("/") or None),
        "allowed_instance_login_configured": len(al) > 0,
        "allowed_instance_login_count": len(al),
        "super_admin_emails_count": sa_n,
        "instance_admin_emails_count": ia_n,
        "instance_zero_tenant_id_configured": bool(instance_zero_tenant_id()),
        "instance_zero_member_emails_count": len(iz),
        "resend_api_key_configured": bool(os.environ.get("RESEND_API_KEY", "").strip()),
        "from_email_configured": bool(os.environ.get("FROM_EMAIL", "").strip()),
        "email_reporting_policy": _email_reporting_policy_payload(),
    }


@app.get("/ops/email-reporting-policy", summary="Get email reporting policy (primary key only)")
def ops_email_reporting_policy(
    request: Request,
    api_key: str = Query("", description="Same as X-API-Key header"),
):
    _require_full_collab_api_key(request, api_key)
    return _email_reporting_policy_payload()


@app.patch("/ops/email-reporting-policy", summary="Update email reporting policy (primary key only)")
def ops_set_email_reporting_policy(
    body: OpsEmailReportingPolicyBody,
    request: Request,
    api_key: str = Query("", description="Same as X-API-Key header"),
):
    _require_full_collab_api_key(request, api_key)
    mode = _set_email_reporting_mode(body.mode)
    payload = _email_reporting_policy_payload()
    payload["updated"] = True
    payload["mode"] = mode
    return payload


@app.post("/ops/transactional-mail", summary="Send branded test and/or instance invite email")
def ops_transactional_mail(
    request: Request,
    body: OpsTransactionalMailBody,
    api_key: str = Query("", description="Same as X-API-Key header"),
):
    """
    ``kind`` options:
    - ``test``: smoke-test email
    - ``instance_invite``: onboarding copy for a teammate
    - ``test_and_invite``: both test + invite
    - ``work_report``: structured engineering review report (videos/tests/impact)
    - ``release_decision``: lead-agent go/no-go decision summary
    Does not create users — set Render env (allowlist + role maps) first.

    Auth: primary ``COLLAB_API_KEY`` only.
    """
    _require_full_collab_api_key(request, api_key)
    from collab_memory.auth.email import (
        send_delivery_report_email,
        send_branded_test_email,
        send_instance_team_invite_email,
        send_release_decision_email,
    )
    from collab_memory.auth.jwt_provider import normalize_email

    to_norm = normalize_email(body.to)
    if not to_norm or "@" not in to_norm:
        raise HTTPException(status_code=400, detail="Invalid 'to' email")

    kind = body.kind
    reporting_mode = _email_reporting_mode()
    if kind in {"work_report", "release_decision"} and reporting_mode == "off":
        raise HTTPException(
            status_code=403,
            detail="Email reporting is disabled (email_reporting_mode=off).",
        )
    if kind == "test":
        return {"ok": True, "result": send_branded_test_email(to_norm)}
    if kind == "instance_invite":
        return {
            "ok": True,
            "result": send_instance_team_invite_email(
                to_norm, role_description=(body.role_description or "workspace administrator").strip()[:200],
            ),
        }
    if kind == "work_report":
        enforcement_mode = _report_video_enforcement_mode()
        warnings: list[str] = []
        video_urls = list(body.video_urls or [])
        screenshot_urls = list(body.screenshot_urls or [])
        if reporting_mode == "text_only":
            if video_urls or screenshot_urls:
                raise HTTPException(
                    status_code=400,
                    detail=(
                        "email_reporting_mode=text_only blocks video_urls and screenshot_urls. "
                        "Send a text-only report payload without media fields."
                    ),
                )
            video_urls = []
            screenshot_urls = []
        if reporting_mode == "full" and not video_urls:
            if enforcement_mode == "strict":
                raise HTTPException(
                    status_code=400,
                    detail="work_report requires at least one walkthrough video URL in `video_urls`",
                )
            warnings.append(
                "work_report_missing_video_urls_allowed_in_warn_mode"
            )
        result = send_delivery_report_email(
            to_norm,
            project_name=(body.repo_name or "collab-memory").strip()[:160],
            repo_url=(body.repo_url or "").strip()[:800],
            branch=(body.branch_name or "").strip()[:200],
            pr_url=(body.pr_url or "").strip()[:800],
            commit_sha=(body.commit_sha or "").strip()[:120],
            task_summary=(body.task_summary or "").strip()[:4000],
            changes=body.changes,
            updates=body.updates,
            enhancements=body.enhancements,
            suggestions=body.suggestions,
            existing_code_notes=(body.existing_code + body.implementation_notes),
            tests_run=body.tests,
            implementation_impact=body.implementation_impact,
            video_urls=video_urls,
            image_urls=screenshot_urls,
            additional_notes="\n".join(body.risk_notes)[:4000],
            subject_override=(body.subject or "").strip()[:220],
        )
        return {
            "ok": True,
            "kind": "work_report",
            "reporting_mode": reporting_mode,
            "enforcement_mode": enforcement_mode,
            "warnings": warnings,
            "video_urls_present": bool(video_urls),
            "result": result,
        }
    if kind == "release_decision":
        decision = (body.decision or "").strip().lower()
        if decision not in {"go", "no_go"}:
            raise HTTPException(status_code=400, detail="release_decision requires decision=go|no_go")

        def _clean_list(items: list[str], max_items: int = 50, max_len: int = 500) -> list[str]:
            out: list[str] = []
            for item in items or []:
                text = str(item or "").strip()
                if not text:
                    continue
                out.append(text[:max_len])
                if len(out) >= max_items:
                    break
            return out

        approved_prs = _clean_list(body.approved_prs, max_items=100, max_len=120)
        blocked_prs = _clean_list(body.blocked_prs, max_items=100, max_len=120)
        blockers = _clean_list(body.blockers, max_items=100)
        next_actions = _clean_list(body.next_actions, max_items=100)
        tests = _clean_list(body.tests, max_items=200)
        artifacts = _clean_list(body.artifacts, max_items=200)
        summary = (body.summary or "").strip()[:2000]
        target_branch = (body.target_branch or "main").strip()[:120] or "main"
        auto_snapshot_artifacts: list[str] = []
        if decision == "go" and target_branch == "main" and body.include_latest_snapshot:
            auto_snapshot_artifacts = _latest_snapshot_artifacts_for_release(
                body.project_id,
                request,
                include_media=(reporting_mode == "full"),
            )
            for marker in auto_snapshot_artifacts:
                if marker not in artifacts:
                    artifacts.append(marker)
            if len(artifacts) > 200:
                artifacts = artifacts[:200]
        if reporting_mode == "text_only":
            artifacts = [a for a in artifacts if not _artifact_has_media_reference(a)]

        missing: list[str] = []
        if not summary:
            missing.append("summary")
        if decision == "go":
            if not approved_prs:
                missing.append("approved_prs")
        else:
            if not blockers:
                missing.append("blockers")
            if not next_actions:
                missing.append("next_actions")
        if missing:
            raise HTTPException(
                status_code=400,
                detail=f"release_decision missing required fields for decision={decision}: {', '.join(missing)}",
            )

        result = send_release_decision_email(
            to_norm,
            decision=decision,
            target_branch=target_branch,
            approved_prs=approved_prs,
            blocked_prs=blocked_prs,
            summary=summary,
            blockers=blockers,
            next_actions=next_actions,
            tests=tests,
            artifacts=artifacts,
        )
        payload: dict[str, Any] = {
            "ok": True,
            "result": result,
            "kind": "release_decision",
            "reporting_mode": reporting_mode,
        }
        if auto_snapshot_artifacts:
            payload["auto_snapshot"] = {"project_id": body.project_id, "artifacts_added": auto_snapshot_artifacts}
        return payload
    r1 = send_branded_test_email(to_norm)
    r2 = send_instance_team_invite_email(
        to_norm, role_description=(body.role_description or "workspace administrator").strip()[:200],
    )
    return {"ok": True, "test": r1, "instance_invite": r2}


@app.get("/ops/access-requests", summary="List access applications (apply form)")
def ops_access_requests(
    request: Request,
    status: str = Query("", description="Filter by status (e.g. pending)"),
    limit: int = Query(100, ge=1, le=500),
    api_key: str = Query("", description="Same as X-API-Key header"),
):
    """
    Returns ``AccessRequest`` nodes from Neo4j (submissions from ``/apply``).

    Auth: **primary** ``COLLAB_API_KEY`` only (header ``X-API-Key`` or ``?api_key=``).
    The read-only key cannot call this endpoint (emails are sensitive).
    """
    _require_full_collab_api_key(request, api_key)
    if not hasattr(graph, "_tx_read"):
        raise HTTPException(
            status_code=501,
            detail="Active graph backend does not support this query (Neo4j required).",
        )
    st = (status or "").strip().lower()
    try:
        if st:
            rows = graph._tx_read(
                """
                MATCH (a:AccessRequest)
                WHERE toLower(trim(a.status)) = $st
                RETURN a.id AS id, a.email AS email, a.full_name AS full_name,
                       a.tracks_json AS tracks_json, a.message AS message,
                       a.status AS status, a.created_at AS created_at, a.source AS source,
                       a.review_note AS review_note, a.reviewed_at AS reviewed_at
                ORDER BY a.created_at DESC
                LIMIT $lim
                """,
                st=st,
                lim=limit,
            )
        else:
            rows = graph._tx_read(
                """
                MATCH (a:AccessRequest)
                RETURN a.id AS id, a.email AS email, a.full_name AS full_name,
                       a.tracks_json AS tracks_json, a.message AS message,
                       a.status AS status, a.created_at AS created_at, a.source AS source,
                       a.review_note AS review_note, a.reviewed_at AS reviewed_at
                ORDER BY a.created_at DESC
                LIMIT $lim
                """,
                lim=limit,
            )
    except Exception as e:
        import logging
        logging.getLogger(__name__).warning("ops/access-requests query failed: %s", e)
        raise HTTPException(status_code=500, detail="Failed to list access requests")

    items = []
    for r in rows or []:
        tj = r.get("tracks_json") or "[]"
        try:
            tracks = json.loads(tj) if isinstance(tj, str) else []
        except Exception:
            tracks = []
        items.append({**dict(r), "tracks": tracks})

    return {"count": len(items), "requests": items}


@app.patch("/ops/access-requests/{request_id}", summary="Update access request review status")
def ops_access_request_set_status(
    request_id: str,
    body: OpsAccessRequestStatusBody,
    request: Request,
    api_key: str = Query(""),
):
    """
    Set ``status`` and optional ``review_note`` / ``reviewed_at`` on an ``AccessRequest``.
    Use after manual review (approve → invite / provision).
    """
    _require_full_collab_api_key(request, api_key)
    if not hasattr(graph, "_tx_write"):
        raise HTTPException(
            status_code=501,
            detail="Active graph backend does not support writes (Neo4j required).",
        )
    rid = (request_id or "").strip()
    if not rid:
        raise HTTPException(status_code=400, detail="Invalid id")
    now = datetime.now(timezone.utc).replace(tzinfo=None).isoformat() + "Z"
    try:
        graph._tx_write(
            """
            MATCH (a:AccessRequest {id: $id})
            SET a.status = $st,
                a.review_note = $note,
                a.reviewed_at = $now
            """,
            id=rid,
            st=body.status,
            note=body.note.strip(),
            now=now,
        )
        chk = graph._tx_read(
            "MATCH (a:AccessRequest {id: $id}) RETURN a.status AS status LIMIT 1",
            id=rid,
        )
    except Exception as e:
        import logging
        logging.getLogger(__name__).warning("ops/access-requests PATCH failed: %s", e)
        raise HTTPException(status_code=500, detail="Update failed")

    if not chk:
        raise HTTPException(status_code=404, detail="AccessRequest not found")
    return {"ok": True, "id": rid, "status": chk[0].get("status", body.status)}


class GitSyncRequest(BaseModel):
    message: str = ""   # Optional commit message; auto-generated if blank


@app.get("/ops/secrets/status", summary="Secret vault resolution status")
def ops_secrets_status():
    """
    Shows which secret resolution layer is active: Doppler → .env → os.environ.
    Never exposes secret values — safe to call publicly.
    Agents use this to verify their secret chain before making LLM calls.
    """
    from ..secrets import get_secrets_status
    return get_secrets_status()


@app.get("/ops/email/status", summary="Transactional email delivery status")
def ops_email_status():
    """Return non-secret email delivery posture for operational diagnostics."""
    from ..auth.email import email_config_status

    return email_config_status()


@app.post("/ops/github/push", summary="GitHub push webhook — writes agent activity into Co-Lab graph")
async def ops_github_push(request: Request):
    """
    GitHub webhook endpoint. Register at:
      GitHub repo → Settings → Webhooks → Add webhook
      URL: https://collab-memory.onrender.com/ops/github/push
      Content-type: application/json
      Secret: $GITHUB_WEBHOOK_SECRET
      Events: Push events

    On each Manus (or any agent) push, creates an ExchangeRecord so the
    Neo4j poll watcher processes it into MemoryNodes, which Antigravity
    will see at the start of the next session via /memory/context.
    """
    # ── Validate GitHub HMAC signature ──────────────────────────────────────
    import hmac, hashlib
    secret = os.environ.get("GITHUB_WEBHOOK_SECRET", "")
    if secret:
        sig_header = request.headers.get("X-Hub-Signature-256", "")
        body = await request.body()
        expected = "sha256=" + hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
        if not hmac.compare_digest(expected, sig_header):
            from fastapi import HTTPException
            raise HTTPException(status_code=403, detail="Invalid webhook signature")
    else:
        body = await request.body()

    # ── Parse push event ─────────────────────────────────────────────────────
    try:
        payload = json.loads(body)
    except Exception:
        return {"status": "ignored", "reason": "non-JSON payload"}

    event_type = request.headers.get("X-GitHub-Event", "")
    if event_type not in ("push", "pull_request"):
        return {"status": "ignored", "event": event_type}

    ref = payload.get("ref", "")
    branch = ref.replace("refs/heads/", "")
    pusher = payload.get("pusher", {}).get("name", payload.get("sender", {}).get("login", "unknown"))
    commits = payload.get("commits", [])
    repo = payload.get("repository", {}).get("full_name", "")

    if not commits and event_type == "push":
        return {"status": "ignored", "reason": "no commits"}

    # Build summary text for the pipeline
    commit_lines = "\n".join(
        f"  [{c.get('id','')[:7]}] {c.get('message','').splitlines()[0]}"
        for c in commits[:5]
    )
    raw_text = (
        f"AGENT PUSH EVENT — {pusher} pushed to {repo}/{branch}\n\n"
        f"Commits ({len(commits)}):\n{commit_lines}\n\n"
        f"[collab-memory] This push was recorded automatically by the GitHub webhook. "
        f"Review and merge as appropriate."
    )

    try:
        record = graph.save_exchange_record(
            session_id=f"github_push_{branch}",
            raw_text=raw_text,
            project_id="collab-memory",
            worthiness_score=0.6,
        )
        return {"status": "recorded", "record_id": getattr(record, "id", "?"), "branch": branch, "pusher": pusher}
    except Exception as e:
        logger.warning("GitHub webhook: failed to save exchange record: %s", e)
        return {"status": "error", "detail": str(e)}


# ─── GitHub PR Management ──────────────────────────────────────────────────────

_GH_REPO = os.environ.get("GITHUB_REPO", "OHACO-LABS/collab-memory")
_GH_TOKEN = os.environ.get("GITHUB_TOKEN", "").strip()


@app.get("/ops/github/prs", summary="List open pull requests")
async def list_open_prs():
    """
    Returns open PRs from the configured GitHub repository.
    Reads are public (no auth needed). GITHUB_TOKEN env var adds PR status checks.

    Dashboard: drives the 🔀 PRs tab with merge buttons.
    """
    import urllib.request as _ur
    import urllib.error as _ue

    url = f"https://api.github.com/repos/{_GH_REPO}/pulls?state=open&per_page=20"
    headers = {
        "Accept": "application/vnd.github+json",
        "User-Agent": "collab-memory/1.0",
    }
    if _GH_TOKEN:
        headers["Authorization"] = f"Bearer {_GH_TOKEN}"

    try:
        req = _ur.Request(url, headers=headers)
        with _ur.urlopen(req, timeout=10) as r:
            pulls = json.loads(r.read().decode())
    except _ue.HTTPError as e:
        raise HTTPException(status_code=502, detail=f"GitHub API error: {e.code} {e.reason}")
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"GitHub unreachable: {e}")

    result = []
    for pr in pulls:
        result.append({
            "number":     pr["number"],
            "title":      pr["title"],
            "author":     pr["user"]["login"],
            "branch":     pr["head"]["ref"],
            "base":       pr["base"]["ref"],
            "url":        pr["html_url"],
            "created_at": pr["created_at"],
            "updated_at": pr["updated_at"],
            "additions":  pr.get("additions", 0),
            "deletions":  pr.get("deletions", 0),
            "draft":      pr.get("draft", False),
            "mergeable":  pr.get("mergeable", None),
            "body_preview": (pr.get("body") or "")[:200].strip(),
        })
    return {"prs": result, "count": len(result), "repo": _GH_REPO}


class PRMergeRequest(BaseModel):
    merge_method: str = "squash"     # squash | merge | rebase
    commit_title: str = ""
    commit_message: str = ""


@app.post("/ops/github/prs/{pr_number}/merge", summary="Merge a pull request (admin only)")
async def merge_pr(pr_number: int, req: PRMergeRequest = PRMergeRequest(), request: Request = None):
    """
    Merge an open PR using the GitHub API.

    Requires:
    - X-API-Key with admin ABAC role
    - GITHUB_TOKEN env var with repo write permissions

    Enforced by ABAC middleware (admin role), so the dashboard merge button
    must include the admin API key header.
    """
    import urllib.request as _ur
    import urllib.error as _ue

    # Extra safety: only admin role can reach this via ABAC middleware.
    # But also enforce the token is present.
    if not _GH_TOKEN:
        raise HTTPException(
            status_code=503,
            detail={
                "error": "GITHUB_TOKEN not configured",
                "hint": "Add GITHUB_TOKEN to Render env vars (needs repo write scope)"
            }
        )

    url = f"https://api.github.com/repos/{_GH_REPO}/pulls/{pr_number}/merge"
    payload = {"merge_method": req.merge_method}
    if req.commit_title:
        payload["commit_title"] = req.commit_title
    if req.commit_message:
        payload["commit_message"] = req.commit_message

    body = json.dumps(payload).encode()
    headers = {
        "Accept":        "application/vnd.github+json",
        "Authorization": f"Bearer {_GH_TOKEN}",
        "Content-Type":  "application/json",
        "User-Agent":    "collab-memory/1.0",
    }

    try:
        merge_req = _ur.Request(url, data=body, headers=headers, method="PUT")
        with _ur.urlopen(merge_req, timeout=15) as r:
            result = json.loads(r.read().decode())
        return {
            "ok":      True,
            "merged":  True,
            "sha":     result.get("sha", ""),
            "message": result.get("message", "Merged successfully"),
            "pr":      pr_number,
        }
    except _ue.HTTPError as e:
        body_text = e.read().decode()
        try:
            detail = json.loads(body_text)
        except Exception:
            detail = body_text
        raise HTTPException(status_code=e.code, detail=detail)
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"GitHub unreachable: {e}")


@app.post("/ops/git/sync", summary="Commit + push code and docs to Git")

def ops_git_sync(req: GitSyncRequest = GitSyncRequest()):
    """
    Auto-commit and push the working directory to Git.
    Called automatically by the dashboard 💾 Save Session flow so that
    DB ingest + Git backup happen in one action.
    Safe to call when nothing has changed — git handles the no-op cleanly.
    """
    import subprocess
    from datetime import datetime, timezone

    msg = req.message.strip() or f"chore: session auto-backup {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M')} UTC"

    try:
        subprocess.run(["git", "add", "-A"], check=True, capture_output=True)
        result = subprocess.run(
            ["git", "commit", "-m", msg],
            capture_output=True, text=True,
        )
        # "nothing to commit" is fine — not an error
        committed = result.returncode == 0
        commit_out = result.stdout.strip()

        push_out = ""
        if committed:
            push = subprocess.run(["git", "push"], capture_output=True, text=True)
            push_out = push.stdout.strip() or push.stderr.strip()

        return {
            "ok": True,
            "committed": committed,
            "message": msg,
            "commit_output": commit_out,
            "push_output": push_out,
        }
    except subprocess.CalledProcessError as e:
        raise HTTPException(status_code=500, detail=f"Git error: {e.stderr or str(e)}")


class SessionSaveRequest(BaseModel):
    session_id: str
    lines: list[str]           # One summary item per line
    skip_llm: bool = True      # Default: keyword-only for speed


@app.post("/memory/session/save", summary="Batch-save session summary lines")
def session_save(req: SessionSaveRequest):
    """
    Batch ingest for end-of-session saves.
    Accepts session_id + list of text lines and ingests each one.
    Used by the dashboard 💾 Save Session modal — one HTTP call instead of N.
    Returns per-line status and a count of successfully stored items.
    """
    results = []
    ok = 0
    for i, line in enumerate(req.lines):
        line = line.strip()
        if not line:
            continue
        try:
            state = _pipeline({
                "raw_text": line,
                "session_id": req.session_id,
                "turn_start": i,
                "skip_llm": req.skip_llm,
            })
            results.append({"line": i, "ok": True, "id": state.get("exchange_record_id", "")})
            ok += 1
        except Exception as e:
            results.append({"line": i, "ok": False, "error": str(e)})

    return {
        "session_id": req.session_id,
        "total": len(req.lines),
        "saved": ok,
        "results": results,
    }


@app.post("/memory/import", summary="Import a Claude or ChatGPT conversation export")
async def import_conversation(
    file: UploadFile = File(...),
    session_id: str = Query("imported_session", description="Session ID to tag ingested records"),
    format: str = Query("auto", description="claude | chatgpt | auto"),
    max_turns: int = Query(200, description="Max turns to ingest (most recent)"),
    skip_llm: bool = Query(False, description="Skip LLM classifier for speed"),
):
    """
    Upload a Claude.ai or ChatGPT JSON export and bulk-ingest the conversation into the graph.

    Claude: Settings → Privacy & Data → Export → conversations.json
    ChatGPT: Settings → Data Controls → Export → conversations.json

    auto-detects format from JSON structure. Processes up to max_turns turns.
    """
    import tempfile, json as _json

    contents = await file.read()
    if not contents:
        raise HTTPException(status_code=400, detail="Empty file")

    # Write to temp file (adapters work with file paths)
    suffix = ".json"
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
        tmp.write(contents)
        tmp_path = tmp.name

    # Auto-detect format
    detected = format
    if detected == "auto":
        try:
            raw = _json.loads(contents)
            sample = raw[0] if isinstance(raw, list) and raw else raw
            if "chat_messages" in sample or "mapping" not in sample:
                detected = "claude"
            else:
                detected = "chatgpt"
        except Exception:
            detected = "claude"  # fallback

    # Parse turns
    try:
        if detected == "claude":
            turns = parse_claude_export(tmp_path, max_turns=max_turns)
        else:
            turns = parse_chatgpt_export(tmp_path, max_turns=max_turns)
    except Exception as e:
        raise HTTPException(status_code=422, detail=f"Parse error ({detected}): {e}")

    # Ingest each turn
    ok = 0
    errors = []
    for i, turn in enumerate(turns):
        try:
            result = encode_exchange(
                raw_text=turn,
                session_id=session_id,
                turn_start=i,
                skip_llm=skip_llm,
            )
            graph.ingest_result(result)
            ok += 1
        except Exception as e:
            errors.append({"turn": i, "error": str(e)})

    import os
    os.unlink(tmp_path)

    return {
        "format": detected,
        "session_id": session_id,
        "turns_parsed": len(turns),
        "turns_ingested": ok,
        "errors": errors[:10],  # Cap error list
    }

@app.get("/memory/pending", summary="List inferences awaiting confirmation")
def list_pending(
    request: Request,
    project_id: Optional[str] = Query(None, description="Optional project scope for pending rows"),
):
    """
    Returns inferred nodes awaiting human confirmation.
    These were classified as novel+inferred and not yet written to the main graph.
    Call POST /memory/confirm/{id} to accept or /memory/reject/{id} to discard.
    Protocol: agents use MCP get_pending, then confirm_pending / reject_pending.
    """
    _agent_ctx = getattr(request.state, "agent", None)
    _tid = getattr(_agent_ctx, "tenant_id", "default") if _agent_ctx else "default"
    _tid = _tid or "default"
    if hasattr(graph, "get_pending"):
        try:
            items = graph.get_pending(project_id=project_id, tenant_id=_tid)
        except TypeError:
            items = graph.get_pending(project_id=project_id)
    else:
        try:
            rows = graph._tx_read(
                "MATCH (n:PendingInference) WHERE n.status = 'pending' "
                "RETURN n ORDER BY n.created_at DESC LIMIT 50"
            )
            items = [dict(r["n"]) for r in rows]
        except Exception:
            items = []
    return {"pending": items, "count": len(items)}


@app.post("/memory/confirm/{item_id}", summary="Confirm an inferred item — write to graph")
def confirm_pending(item_id: str, request: Request):
    """
    Confirms a pending inference and writes it to the main graph.
    The PendingInference node is marked 'confirmed' and the real node is created.
    """
    _agent_ctx = getattr(request.state, "agent", None)
    _tid = getattr(_agent_ctx, "tenant_id", "default") if _agent_ctx else "default"
    _tid = _tid or "default"
    if not hasattr(graph, "confirm_pending_inference"):
        raise HTTPException(
            status_code=501,
            detail="Graph backend does not support HITL confirmation",
        )
    try:
        out = graph.confirm_pending_inference(item_id, tenant_id=_tid)
    except TypeError:
        out = graph.confirm_pending_inference(item_id)
    if not out.get("ok"):
        err = out.get("error", "confirm_failed")
        if err == "not_found":
            raise HTTPException(status_code=404, detail=f"Pending item {item_id} not found")
        if str(err).startswith("unsupported_node_type"):
            raise HTTPException(status_code=400, detail=err)
        raise HTTPException(status_code=500, detail=str(err))
    return out


@app.post("/memory/reject/{item_id}", summary="Reject an inferred item — do not write to graph")
def reject_pending(item_id: str, request: Request):
    """
    Rejects a pending inference. The PendingInference node is marked 'rejected' and discarded.
    Nothing is written to the main graph.
    """
    _agent_ctx = getattr(request.state, "agent", None)
    _tid = getattr(_agent_ctx, "tenant_id", "default") if _agent_ctx else "default"
    _tid = _tid or "default"
    if not hasattr(graph, "reject_pending_inference"):
        raise HTTPException(
            status_code=501,
            detail="Graph backend does not support HITL rejection",
        )
    try:
        out = graph.reject_pending_inference(item_id, tenant_id=_tid)
    except TypeError:
        out = graph.reject_pending_inference(item_id)
    if not out.get("ok"):
        err = out.get("error", "reject_failed")
        if err == "not_found":
            raise HTTPException(status_code=404, detail=f"Pending item {item_id} not found")
        raise HTTPException(status_code=500, detail=str(err))
    return out


@app.post("/memory/queue_inference", summary="Queue an inferred item for human review")
def queue_inference(req: dict):
    """
    Directly queue a novel inferred item for human confirmation.
    Used by agents when they infer something new that wasn't explicitly stated.
    Body: {node_type, description, session_id, confidence, raw_text}
    """
    import uuid as _uuid
    now = __import__("datetime").datetime.now(timezone.utc).isoformat()
    item_id = f"pnd_{_uuid.uuid4().hex[:8]}"
    try:
        graph._tx_write(
            """
            MERGE (n:PendingInference {id: $id})
            SET n.node_type = $node_type,
                n.description = $description,
                n.session_id = $session_id,
                n.confidence = $confidence,
                n.raw_text = $raw_text,
                n.origin = 'inferred',
                n.status = 'pending',
                n.created_at = $now
            """,
            id=item_id,
            node_type=req.get("node_type", "Decision"),
            description=req.get("description", ""),
            session_id=req.get("session_id", "unknown"),
            confidence=req.get("confidence", 0.7),
            raw_text=req.get("raw_text", ""),
            now=now,
        )
        return {"ok": True, "queued_id": item_id, "status": "pending"}
    except Exception as e:
        return {"ok": False, "error": str(e)}


@app.post("/ops/restart", summary="Trigger a server restart via Render API")
async def ops_restart():
    """
    Triggers a Render redeploy using the RENDER_API_KEY env var.
    If the key is not set, returns instructions to restart manually.
    """
    import httpx
    render_key = os.environ.get("RENDER_API_KEY", "")
    service_id = os.environ.get("RENDER_SERVICE_ID", "srv-d70ch5n5r7bs73f8g04g")
    if not render_key:
        return {
            "ok": False,
            "message": "RENDER_API_KEY not set — go to dashboard.render.com and click Manual Deploy",
            "dashboard": f"https://dashboard.render.com/web/{service_id}",
        }
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            r = await client.post(
                f"https://api.render.com/v1/services/{service_id}/deploys",
                headers={"authorization": f"Bearer {render_key}", "content-type": "application/json"},
                json={"clearCache": "do_not_clear"},
            )
        data = r.json()
        return {"ok": r.status_code == 201, "deploy_id": data.get("id"), "status": data.get("status")}
    except Exception as e:
        return {"ok": False, "message": str(e)}


@app.get("/ops/superadmin", summary="Superadmin cross-tenant overview")
async def superadmin_overview(request: Request):
    """Cross-tenant view of all users, tenants, projects, and invites.
    Only accessible to superadmin users (is_superadmin=true in JWT)."""
    agent = getattr(request.state, "agent", AgentContext())
    if not agent.is_superadmin:
        raise HTTPException(status_code=403, detail="Superadmin access required.")

    try:
        users = graph._tx_read(
            "MATCH (u:User) RETURN u.email AS email, u.display_name AS name, "
            "u.role AS role, u.tenant_id AS tenant_id, u.email_verified AS verified, "
            "u.is_superadmin AS is_superadmin, u.created_at AS created_at "
            "ORDER BY u.created_at"
        )
        tenants = graph._tx_read(
            "MATCH (t:Tenant) RETURN t.id AS id, t.name AS name, t.plan AS plan, "
            "t.owner_email AS owner_email, t.status AS status ORDER BY t.created_at"
        )
        projects = graph._tx_read(
            "MATCH (p:Project) RETURN p.id AS id, p.name AS name, "
            "p.tenant_id AS tenant_id, p.lead_agent AS lead_agent ORDER BY p.created_at"
        )
        invites = graph._tx_read(
            "MATCH (i:ProjectInvite) RETURN i.email AS email, i.role AS role, "
            "i.status AS status, i.project_id AS project_id, i.created_at AS created_at"
        )
        return {
            "users": [dict(u) for u in users] if users else [],
            "tenants": [dict(t) for t in tenants] if tenants else [],
            "projects": [dict(p) for p in projects] if projects else [],
            "invites": [dict(i) for i in invites] if invites else [],
            "counts": {
                "users": len(users) if users else 0,
                "tenants": len(tenants) if tenants else 0,
                "projects": len(projects) if projects else 0,
                "invites": len(invites) if invites else 0,
            },
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Superadmin query failed: {e}")


@app.get("/ops/status", summary="Full system status check")
async def ops_status():
    """Returns health of all components: API, Neo4j, LLM."""
    neo_ok = False
    neo_counts = {}
    if hasattr(graph, "test_connection"):
        neo_ok = graph.test_connection()
    if neo_ok and hasattr(graph, "_tx_read"):
        try:
            rows = graph._tx_read("MATCH (n) WHERE size(labels(n)) > 0 RETURN labels(n)[0] AS label, count(n) AS cnt")
            neo_counts = {r["label"]: r["cnt"] for r in rows if r.get("label")}
        except Exception:
            pass
    return {
        "api": {"ok": True, "version": _VERSION},
        "neo4j": {"ok": neo_ok, "backend": type(graph).__name__, "node_counts": neo_counts},
        "llm": {
            "ok": bool(os.environ.get("ANTHROPIC_API_KEY") or os.environ.get("OPENAI_API_KEY") or os.environ.get("GOOGLE_API_KEY")),
            "provider": os.environ.get("LLM_PROVIDER", "gemini"),
            "model": os.environ.get("ANTHROPIC_MODEL", "claude-haiku-4-5"),
        },
        "links": {
            "render": "https://dashboard.render.com/web/srv-d70ch5n5r7bs73f8g04g",
            "neo4j": "https://console.neo4j.io",
            "github": "https://github.com/OHACO-LABS/collab-memory",
        }
    }


@app.get("/memory/stats", summary="Dashboard stats summary")
def memory_stats(request: Request):
    """Counts of all stored nodes — for the cognitive-dash dashboard."""
    _agent_ctx = getattr(request.state, "agent", None)
    _tid = getattr(_agent_ctx, "tenant_id", "default") if _agent_ctx else "default"
    try:
        brief = graph.build_context_brief(tenant_id=_tid)
    except Exception:
        brief = {}
    try:
        decisions = graph.get_decisions(tenant_id=_tid)
    except Exception:
        decisions = []
    try:
        constraints = graph.get_constraints(active_only=True, tenant_id=_tid)
    except Exception:
        constraints = []
    try:
        prefs = graph.get_preferences(tenant_id=_tid)
    except Exception:
        prefs = []
    attempts = brief.get("recent_attempts", [])
    skills_count = 0
    embedding_count = 0
    embedding_coverage = 0.0
    total_nodes = 0
    total_edges = 0
    agents_count = 0
    projects_count = 0
    try:
        if hasattr(graph, "_driver") and getattr(graph, "_driver", None):
            with graph._driver.session() as session:
                total_result = session.run(
                    "MATCH (n) WHERE n.tenant_id = $tid RETURN count(n) as total",
                    tid=_tid,
                )
                total_nodes = int((total_result.single() or {}).get("total", 0) or 0)

                embedding_result = session.run(
                    "MATCH (n) WHERE n.tenant_id = $tid AND n.embedding IS NOT NULL RETURN count(n) as embedded",
                    tid=_tid,
                )
                embedding_count = int((embedding_result.single() or {}).get("embedded", 0) or 0)
                if total_nodes > 0:
                    embedding_coverage = round((embedding_count / total_nodes) * 100, 2)

                edge_result = session.run(
                    "MATCH (a)-[r]->(b) WHERE a.tenant_id = $tid RETURN count(r) as total",
                    tid=_tid,
                )
                total_edges = int((edge_result.single() or {}).get("total", 0) or 0)

                agent_result = session.run(
                    "MATCH (a:Agent) WHERE a.tenant_id = $tid RETURN count(a) as total",
                    tid=_tid,
                )
                agents_count = int((agent_result.single() or {}).get("total", 0) or 0)

                project_result = session.run(
                    "MATCH (p:Project) WHERE p.tenant_id = $tid RETURN count(p) as total",
                    tid=_tid,
                )
                projects_count = int((project_result.single() or {}).get("total", 0) or 0)

                skill_result = session.run(
                    "MATCH (s:Skill) WHERE s.tenant_id = $tid RETURN count(s) as total",
                    tid=_tid,
                )
                skills_count = int((skill_result.single() or {}).get("total", 0) or 0)
    except Exception:
        pass
    return {
        "decisions": len(decisions),
        "constraints": len(constraints),
        "preferences": len(prefs),
        "attempts": len(attempts),
        "skills": skills_count,
        "total_nodes": total_nodes,
        "total_edges": total_edges,
        "agents": agents_count,
        "projects": projects_count,
        "backend": type(graph).__name__,
        "llm_active": bool(
            os.environ.get("ANTHROPIC_API_KEY")
            or os.environ.get("OPENAI_API_KEY")
            or os.environ.get("GOOGLE_API_KEY")
        ),
        "embedding_count": embedding_count,
        "embedding_coverage": embedding_coverage,
    }


@app.get("/memory/decisions", summary="List active decisions")
def list_decisions(request: Request, limit: int = Query(50, ge=1, le=200)):
    """List active decisions for the dashboard memory panel."""
    _agent_ctx = getattr(request.state, "agent", None)
    _tid = getattr(_agent_ctx, "tenant_id", "default") if _agent_ctx else "default"
    decisions = graph.get_decisions(tenant_id=_tid)[:limit]
    return {
        "decisions": [d.model_dump() for d in decisions],
        "count": len(decisions),
    }


@app.get("/memory/constraints", summary="List active constraints")
def list_constraints(request: Request, limit: int = Query(50, ge=1, le=200)):
    """List active constraints for the dashboard memory panel."""
    _agent_ctx = getattr(request.state, "agent", None)
    _tid = getattr(_agent_ctx, "tenant_id", "default") if _agent_ctx else "default"
    constraints = graph.get_constraints(active_only=True, tenant_id=_tid)[:limit]
    return {
        "constraints": [c.model_dump() for c in constraints],
        "count": len(constraints),
    }


# ─── Handoff Document ─────────────────────────────────────────────────────────

@app.get("/projects/{project_id}/handoff", summary="Generate engineer handoff document for a project")
async def project_handoff(
    request: Request,
    project_id: str,
    fmt: str = Query("markdown", description="Output format: markdown or json"),
):
    """
    Generates a complete handoff document from the project's memory graph.

    Returns everything an engineer needs to understand, maintain, or extend
    a project built with AI assistance: architecture decisions, hard constraints,
    what was tried and abandoned, security rules, open questions, and setup
    instructions — all sourced from the live graph.

    No separate documentation step required. The graph IS the docs.
    """
    _agent_ctx = getattr(request.state, "agent", None)
    _tid = getattr(_agent_ctx, "tenant_id", "default") if _agent_ctx else "default"

    # Gather all graph data for this project
    try:
        decisions = graph.get_decisions(session_id=project_id, tenant_id=_tid)
    except Exception:
        decisions = graph.get_decisions(tenant_id=_tid) if hasattr(graph.get_decisions, "__call__") else []

    try:
        constraints = graph.get_constraints(active_only=False, tenant_id=_tid)
    except Exception:
        constraints = []

    try:
        preferences = graph.get_preferences(tenant_id=_tid)
    except Exception:
        preferences = []

    try:
        attempts = graph.get_attempts(session_id=project_id, tenant_id=_tid)
    except Exception:
        try:
            attempts = graph.get_attempts(tenant_id=_tid)
        except Exception:
            attempts = []

    skills = []
    if hasattr(graph, "get_skills"):
        try:
            skills = graph.get_skills(limit=200, tenant_id=_tid)
        except Exception:
            pass

    artifacts = []
    if hasattr(graph, "get_artifacts"):
        try:
            artifacts = graph.get_artifacts(project_id=project_id, tenant_id=_tid)
        except Exception:
            pass

    flagged = []
    try:
        flagged = graph.get_flagged_records(tenant_id=_tid)
    except Exception:
        pass

    # Categorise constraints
    security_constraints = [c for c in constraints if any(
        t in (c.description or "").lower() for t in ["secret", "key", "auth", "security", "opsec", "vault", "password"]
    ) or any(t in (getattr(c, "tags", None) or []) for t in ["security", "opsec"])]
    active_constraints = [c for c in constraints if getattr(c, "still_active", True)]
    archived_constraints = [c for c in constraints if not getattr(c, "still_active", True)]

    # Active vs reversed decisions
    active_decisions = [d for d in decisions if getattr(d, "status", "active") == "active"]
    reversed_decisions = [d for d in decisions if getattr(d, "status", "active") != "active"]

    generated_at = datetime.now(timezone.utc).isoformat()

    if fmt == "json":
        return {
            "project_id": project_id,
            "generated_at": generated_at,
            "summary": {
                "decisions": len(active_decisions),
                "constraints": len(active_constraints),
                "attempts": len(attempts),
                "preferences": len(preferences),
                "skills": len(skills),
                "open_questions": len(flagged),
            },
            "architecture": {
                "active_decisions": [d.model_dump() for d in active_decisions],
                "reversed_decisions": [d.model_dump() for d in reversed_decisions],
            },
            "constraints": {
                "active": [c.model_dump() for c in active_constraints],
                "security": [c.model_dump() for c in security_constraints],
                "archived": [c.model_dump() for c in archived_constraints],
            },
            "preferences": [p.model_dump() for p in preferences],
            "abandoned_attempts": [a.model_dump() for a in attempts if getattr(a, "abandoned_because", None)],
            "open_questions": [r.model_dump() for r in flagged],
            "skills_indexed": [{"name": s.name, "url": s.url, "tags": s.tags} for s in skills],
        }

    # ── Markdown render ──────────────────────────────────────────────────────
    def _fmt_date(s):
        if not s:
            return ""
        try:
            return str(s)[:10]
        except Exception:
            return str(s)

    lines = [
        f"# Project Handoff: `{project_id}`",
        f"> Generated {generated_at[:10]} from collab-memory graph · v{os.environ.get('COLLAB_VERSION', _VERSION)}",
        f"> This document is auto-generated. Every item below was recorded during the build and is sourced directly from the decision graph.",
        "",
        "---",
        "",
        "## Summary",
        "",
        f"| Category | Count |",
        f"|---|---|",
        f"| Architecture decisions | {len(active_decisions)} |",
        f"| Hard constraints | {len(active_constraints)} |",
        f"| Security rules | {len(security_constraints)} |",
        f"| Abandoned approaches | {len([a for a in attempts if getattr(a, 'abandoned_because', None)])} |",
        f"| Inferred preferences | {len(preferences)} |",
        f"| Open questions | {len(flagged)} |",
        f"| Reference skills | {len(skills)} |",
        "",
        "---",
        "",
        "## Architecture Decisions",
        "",
        "> These decisions are locked. Do not reverse without understanding the rationale.",
        "",
    ]

    if active_decisions:
        for d in active_decisions:
            conf = f"{int(getattr(d, 'confidence', 0) * 100)}%" if getattr(d, "confidence", None) else ""
            lines.append(f"### {d.description}")
            if getattr(d, "rationale", None):
                lines.append(f"**Rationale:** {d.rationale}")
            if conf:
                lines.append(f"**Confidence:** {conf}")
            if getattr(d, "made_at", None):
                lines.append(f"**Recorded:** {_fmt_date(d.made_at)}")
            lines.append("")
    else:
        lines += ["_No decisions recorded yet._", ""]

    if reversed_decisions:
        lines += [
            "### Reversed Decisions",
            "",
            "> These were once active but were overridden. Context matters.",
            "",
        ]
        for d in reversed_decisions:
            lines.append(f"- ~~{d.description}~~ — status: `{getattr(d, 'status', 'unknown')}`")
        lines.append("")

    lines += [
        "---",
        "",
        "## Hard Constraints",
        "",
        "> These are non-negotiable rules the system enforces. Violating them breaks the build contract.",
        "",
    ]

    if active_constraints:
        for c in active_constraints:
            origin = getattr(c, "origin", None)
            origin_str = origin.value if hasattr(origin, "value") else str(origin or "")
            lines.append(f"- **{c.description}**")
            if getattr(c, "scope", None):
                lines.append(f"  - Scope: `{c.scope}`")
            if origin_str:
                lines.append(f"  - Origin: `{origin_str}`")
            lines.append("")
    else:
        lines += ["_No constraints recorded._", ""]

    if security_constraints:
        lines += [
            "### Security Rules",
            "",
            "> Auto-extracted from constraints tagged with security/opsec keywords.",
            "",
        ]
        for c in security_constraints:
            lines.append(f"- {c.description}")
        lines.append("")

    lines += [
        "---",
        "",
        "## What Was Tried and Abandoned",
        "",
        "> Critical for any engineer picking this up. These paths were explored and rejected for a reason.",
        "",
    ]

    abandoned = [a for a in attempts if getattr(a, "abandoned_because", None)]
    if abandoned:
        for a in abandoned:
            lines.append(f"### {getattr(a, 'description', a.id)}")
            lines.append(f"**Why abandoned:** {a.abandoned_because}")
            if getattr(a, "tried_in", None):
                lines.append(f"**Session:** `{a.tried_in}`")
            lines.append("")
    else:
        lines += ["_No abandoned attempts recorded._", ""]

    lines += [
        "---",
        "",
        "## Inferred Preferences",
        "",
        "> These are working preferences inferred from behaviour during the build. They reflect how the team wants to work.",
        "",
    ]

    if preferences:
        for p in preferences:
            conf = f"{int(getattr(p, 'confidence', 0) * 100)}%" if getattr(p, "confidence", None) else ""
            ptype = getattr(p, "type", None)
            ptype_str = ptype.value if hasattr(ptype, "value") else str(ptype or "")
            lines.append(f"- **[{ptype_str}]** {p.description}")
            if conf:
                lines.append(f"  - Confidence: {conf} · Reinforcements: {getattr(p, 'reinforcement_count', '?')}")
            lines.append("")
    else:
        lines += ["_No preferences recorded._", ""]

    lines += [
        "---",
        "",
        "## Open Questions",
        "",
        "> Items flagged during the build that were not resolved. Engineer should review these before making changes.",
        "",
    ]

    if flagged:
        for r in flagged:
            lines.append(f"- {getattr(r, 'raw_text', str(r.id))[:200]}")
        lines.append("")
    else:
        lines += ["_No open questions._", ""]

    lines += [
        "---",
        "",
        "## Reference Skills & Documentation",
        "",
        "> API docs, guides, and references that were indexed during the build.",
        "",
    ]

    if skills:
        for s in skills[:30]:
            tag_str = ", ".join(s.tags[:4]) if s.tags else ""
            url_str = f" — [{s.url}]({s.url})" if getattr(s, "url", None) else ""
            lines.append(f"- **{s.name}**{url_str}")
            if tag_str:
                lines.append(f"  `{tag_str}`")
        lines.append("")
    else:
        lines += ["_No skills indexed._", ""]

    lines += [
        "---",
        "",
        "## Environment Variables Required",
        "",
        "```bash",
        "# Core",
        "GRAPH_BACKEND=neo4j          # or 'local' for dev",
        "NEO4J_URI=neo4j+s://...      # AuraDB connection string",
        "NEO4J_PASSWORD=...           # AuraDB password",
        "",
        "# LLM (optional — skip_llm=true works without it)",
        "LLM_PROVIDER=anthropic       # or 'ollama'",
        "ANTHROPIC_API_KEY=sk-ant-...",
        "",
        "# Security",
        "COLLAB_API_KEY=...           # locks all write endpoints",
        "JWT_SECRET=...               # for user auth",
        "VAULT_MASTER_KEY=...         # 32-byte hex — encrypts stored API keys",
        "",
        "# Optional features",
        "CVE_WATCHER_ENABLED=true     # live CVE monitoring",
        "POLL_WATCHER_ENABLED=true    # background pipeline processor",
        "```",
        "",
        "---",
        "",
        "## Troubleshooting",
        "",
        "| Symptom | Likely cause | Fix |",
        "|---|---|---|",
        "| `/health` returns `LocalGraphBackend` | Neo4j env vars not set | Set `NEO4J_URI`, `NEO4J_PASSWORD`, `GRAPH_BACKEND=neo4j` |",
        "| LLM inactive | No API key | Set `ANTHROPIC_API_KEY` |",
        "| `/memory/context` times out | Cold start (Render free tier) | Use Railway (no cold starts) or set UptimeRobot ping |",
        "| Pipeline drops everything | `skip_llm=False` but no key | Set API key or use `skip_llm=True` for keyword mode |",
        "| 401 on write endpoints | Missing API key header | Add `X-API-Key: <COLLAB_API_KEY>` to requests |",
        "",
        "---",
        "",
        f"*Generated by collab-memory · {generated_at} · [GitHub](https://github.com/OHACO-LABS/collab-memory)*",
    ]

    doc = "\n".join(lines)

    from fastapi.responses import PlainTextResponse
    return PlainTextResponse(doc, media_type="text/markdown")


# ─── Training Data Export ─────────────────────────────────────────────────────

@app.get("/projects/{project_id}/export-training-data",
         summary="Export project memory as LoRA fine-tuning instruction pairs")
async def export_training_data(
    request: Request,
    project_id: str,
    fmt: str = Query("jsonl", description="Output format: jsonl or json"),
    min_confidence: float = Query(
        0.5,
        ge=0.0,
        le=1.0,
        description="Minimum confidence required for exported items.",
    ),
    min_decision_recall: int = Query(
        0,
        ge=0,
        le=1000,
        description="Minimum recall_count for decision exports.",
    ),
    min_constraint_recall: int = Query(
        0,
        ge=0,
        le=1000,
        description="Minimum recall_count for constraint exports.",
    ),
    min_preference_reinforcement: int = Query(
        0,
        ge=0,
        le=1000,
        description="Minimum reinforcement_count for preference exports.",
    ),
):
    """
    Exports graph nodes as sharegpt-format instruction-following pairs for LoRA
    fine-tuning (Axolotl / LlamaFactory compatible).

    Decisions  → "What was decided about X?" / rationale answer
    Constraints → "Is X allowed?" / hard constraint answer
    Preferences → "How should we handle X?" / preference answer

    Returns JSONL (text/plain, newline-delimited) or JSON envelope.
    Supports graduation-aligned filtering controls:
    - confidence floor (`min_confidence`)
    - minimum decision/constraint recall counts
    - minimum preference reinforcement count

    Duplicate instruction/answer pairs are suppressed to reduce training noise.
    """
    import json as _json

    _agent_ctx = getattr(request.state, "agent", None)
    _tid = getattr(_agent_ctx, "tenant_id", "default") if _agent_ctx else "default"

    fmt_norm = (fmt or "jsonl").strip().lower()
    if fmt_norm not in {"json", "jsonl"}:
        raise HTTPException(status_code=400, detail="fmt must be either 'json' or 'jsonl'")

    pairs: list[dict] = []
    seen_pairs: set[tuple[str, str]] = set()
    source_counts = {"decisions": 0, "constraints": 0, "preferences": 0}
    exported_counts = {"decisions": 0, "constraints": 0, "preferences": 0}
    dropped_counts = {
        "decisions_empty": 0,
        "decisions_low_confidence": 0,
        "decisions_low_recall": 0,
        "constraints_empty": 0,
        "constraints_low_confidence": 0,
        "constraints_low_recall": 0,
        "preferences_empty": 0,
        "preferences_low_confidence": 0,
        "preferences_low_reinforcement": 0,
        "duplicate_pairs": 0,
    }

    def _append_pair(prompt: str, answer: str) -> bool:
        p = (prompt or "").strip()
        a = (answer or "").strip()
        if not p or not a:
            return False
        key = (p, a)
        if key in seen_pairs:
            dropped_counts["duplicate_pairs"] += 1
            return False
        seen_pairs.add(key)
        pairs.append({"conversations": [
            {"from": "human", "value": p},
            {"from": "gpt", "value": a},
        ]})
        return True

    # Decisions
    try:
        decisions = graph.get_decisions(project_id=project_id, tenant_id=_tid, limit=200)
        for d in decisions:
            source_counts["decisions"] += 1
            desc = getattr(d, "description", "") or ""
            if not desc.strip():
                dropped_counts["decisions_empty"] += 1
                continue
            rat = getattr(d, "rationale", "") or ""
            conf = getattr(d, "confidence", 0.0) or 0.0
            if conf < min_confidence:
                dropped_counts["decisions_low_confidence"] += 1
                continue
            recall_count = int(getattr(d, "recall_count", 0) or 0)
            if recall_count < min_decision_recall:
                dropped_counts["decisions_low_recall"] += 1
                continue
            answer = desc
            if rat:
                answer += f" Rationale: {rat}"
            # Extract topic from description (first 60 chars as topic proxy)
            topic = desc[:60].rstrip(".,:;") + ("…" if len(desc) > 60 else "")
            if _append_pair(f"What was decided about: {topic}?", answer):
                exported_counts["decisions"] += 1
    except Exception:
        pass

    # Hard constraints
    try:
        constraints = graph.get_constraints(active_only=True, project_id=project_id, tenant_id=_tid, limit=200)
        for c in constraints:
            source_counts["constraints"] += 1
            desc = getattr(c, "description", "") or ""
            if not desc.strip():
                dropped_counts["constraints_empty"] += 1
                continue
            conf = getattr(c, "confidence", 1.0) or 1.0
            if conf < min_confidence:
                dropped_counts["constraints_low_confidence"] += 1
                continue
            recall_count = int(getattr(c, "recall_count", 0) or 0)
            if recall_count < min_constraint_recall:
                dropped_counts["constraints_low_recall"] += 1
                continue
            topic = desc[:60].rstrip(".,:;") + ("…" if len(desc) > 60 else "")
            if _append_pair(f"Is this allowed in the project: {topic}?", f"No. Hard constraint: {desc}"):
                exported_counts["constraints"] += 1
    except Exception:
        pass

    # Preferences
    try:
        preferences = graph.get_preferences(project_id=project_id, tenant_id=_tid, limit=200)
        for p in preferences:
            source_counts["preferences"] += 1
            desc    = getattr(p, "description", "") or ""
            ptype   = str(getattr(p, "type", "process") or "process")
            conf    = getattr(p, "confidence", 0.0) or 0.0
            if not desc.strip():
                dropped_counts["preferences_empty"] += 1
                continue
            if conf < min_confidence:
                dropped_counts["preferences_low_confidence"] += 1
                continue
            reinf_count = int(getattr(p, "reinforcement_count", 0) or 0)
            if reinf_count < min_preference_reinforcement:
                dropped_counts["preferences_low_reinforcement"] += 1
                continue
            if _append_pair(f"How should we handle {ptype} in this project?", f"Preferred approach: {desc}"):
                exported_counts["preferences"] += 1
    except Exception:
        pass

    meta = {
        "project_id": project_id,
        "tenant_id": _tid,
        "filters": {
            "min_confidence": min_confidence,
            "min_decision_recall": min_decision_recall,
            "min_constraint_recall": min_constraint_recall,
            "min_preference_reinforcement": min_preference_reinforcement,
        },
        "source_counts": source_counts,
        "exported_counts": exported_counts,
        "dropped_counts": dropped_counts,
        "count": len(pairs),
    }

    if fmt_norm == "json":
        return JSONResponse({"pairs": pairs, **meta})

    # JSONL output
    header = f"# collab-memory training export — project: {project_id} — {len(pairs)} pairs\n"
    header += f"# meta: {_json.dumps(meta, ensure_ascii=False)}\n"
    body   = "\n".join(_json.dumps(p) for p in pairs)
    from fastapi.responses import PlainTextResponse
    return PlainTextResponse(header + body, media_type="text/plain")


# ─── Dashboard ────────────────────────────────────────────────────────────────

@app.get("/", response_class=HTMLResponse, include_in_schema=False)
async def dashboard(request: Request):
    """Serve the cognitive-dash dashboard."""
    _template_file = _TEMPLATES_DIR / "dashboard.html"
    if not _template_file.exists():
        return HTMLResponse(
            "<h1>cognitive-dash</h1>"
            "<p>Dashboard template not found.</p>"
            "<p><a href='/docs'>API docs →</a></p>",
            status_code=200,
        )
    # Detect configured social providers for login screen
    social_providers = []
    try:
        from collab_memory.auth.social import get_configured_providers
        social_providers = get_configured_providers()
    except Exception:
        pass

    api_key_configured_bool = bool(_API_KEY)
    og_image_url = os.environ.get("OG_IMAGE_URL", "")
    html = _template_file.read_text(encoding="utf-8")
    html = html.replace("{{ api_base }}", "")
    html = html.replace("{{ og_image_url }}", og_image_url)

    # Process Jinja-style conditionals manually (can't use Jinja — JS template literals conflict)
    # Uses a nesting-aware parser instead of naive regex (which breaks on nested blocks).
    import re

    def _resolve_template(html_str, variables):
        """Resolve all {% if %}/{% else %}/{% endif %}, {% for %}/{% endfor %}, and {{ var }} blocks.
        Handles arbitrary nesting by processing innermost blocks first (bottom-up)."""

        # --- Pass 1: {% for p in social_providers %} ... {% endfor %} ---
        # Loop until ALL for-blocks are resolved (dashboard has multiple)
        for_pattern = r'\{%\s*for\s+p\s+in\s+social_providers\s*%\}(.*?)\{%\s*endfor\s*%\}'
        for _guard in range(20):  # safety limit
            for_match = re.search(for_pattern, html_str, flags=re.DOTALL)
            if not for_match:
                break
            template_body = for_match.group(1)
            rendered = ""
            for p in variables.get("social_providers", []):
                rendered += template_body.replace("{{ p }}", p).replace("{{ p|capitalize }}", p.capitalize())
            html_str = html_str[:for_match.start()] + rendered + html_str[for_match.end():]

        # --- Pass 2: Resolve {% if %} blocks bottom-up (innermost first) ---
        # Find the innermost {% if ... %} ... {% endif %} (no nested {% if %} inside)
        # and resolve it, then repeat until no more remain.
        MAX_PASSES = 20
        for _ in range(MAX_PASSES):
            # Match an {% if %} block that contains NO nested {% if %} inside its body
            # Pattern: {% if [not] VAR %} BODY_NO_NESTED_IF {% endif %}
            #   where BODY may contain {% else %}
            inner_pat = re.compile(
                r'\{%\s*if\s+(not\s+)?(\w+)\s*%\}'   # {% if [not] VAR %}
                r'((?:(?!\{%\s*if\s+).)*?)'            # body (no nested {% if %})
                r'\{%\s*endif\s*%\}',                   # {% endif %}
                re.DOTALL
            )
            m = inner_pat.search(html_str)
            if not m:
                break  # No more {% if %} blocks

            negated = bool(m.group(1))       # "not " prefix
            var_name = m.group(2)            # variable name
            body = m.group(3)                # body between if and endif

            # Resolve the variable value
            raw_val = variables.get(var_name, False)
            val = bool(raw_val)
            if negated:
                val = not val

            # Split on {% else %} if present
            else_split = re.split(r'\{%\s*else\s*%\}', body, maxsplit=1)
            if_body = else_split[0]
            else_body = else_split[1] if len(else_split) > 1 else ""

            replacement = if_body if val else else_body
            html_str = html_str[:m.start()] + replacement + html_str[m.end():]

        return html_str

    html = _resolve_template(html, {
        "api_key_configured": api_key_configured_bool,
        "social_providers": social_providers,
    })

    return HTMLResponse(content=html)


@app.get("/home", response_class=HTMLResponse, include_in_schema=False)
@app.get("/landing", response_class=HTMLResponse, include_in_schema=False)
async def landing_page():
    """Public landing page — OHACO Labs informational site."""
    _landing_file = _TEMPLATES_DIR / "landing.html"
    if not _landing_file.exists():
        return HTMLResponse("<h1>OHACO Labs</h1><p>Landing page template not found.</p>", status_code=200)
    return HTMLResponse(content=_landing_file.read_text(encoding="utf-8"))


@app.get("/signup", response_class=HTMLResponse, include_in_schema=False)
async def signup_page():
    """Public onboarding page — no auth required. New users register and get API keys."""
    _signup_file = _TEMPLATES_DIR / "signup.html"
    if not _signup_file.exists():
        return HTMLResponse(
            "<h1>Signup page not found</h1><p><a href='/docs'>API docs →</a></p>",
            status_code=404,
        )
    return HTMLResponse(content=_signup_file.read_text(encoding="utf-8"))


@app.get("/apply", response_class=HTMLResponse, include_in_schema=False)
async def apply_page():
    """Public access application — waitlist, beta, community volunteer (no account)."""
    _f = _TEMPLATES_DIR / "apply.html"
    if not _f.exists():
        return HTMLResponse(
            "<h1>Apply page not found</h1><p><a href='/signup'>Signup →</a></p>",
            status_code=404,
        )
    return HTMLResponse(content=_f.read_text(encoding="utf-8"))


@app.get("/investors", response_class=HTMLResponse, include_in_schema=False)
async def investor_page():
    """Public investor intake page (NCNDA acknowledgement + deck access flow)."""
    _f = _TEMPLATES_DIR / "investors.html"
    if not _f.exists():
        return HTMLResponse(
            "<h1>Investor page not found</h1><p><a href='/home'>Back to landing →</a></p>",
            status_code=404,
        )
    return HTMLResponse(content=_f.read_text(encoding="utf-8"))


@app.get("/investor-deck", response_class=HTMLResponse, include_in_schema=False)
async def investor_deck_page():
    """Public investor deck page (web deck for email sharing)."""
    _f = _TEMPLATES_DIR / "investor-deck.html"
    if not _f.exists():
        return HTMLResponse(
            "<h1>Investor deck not found</h1><p><a href='/investors'>Investor access →</a></p>",
            status_code=404,
        )
    return HTMLResponse(content=_f.read_text(encoding="utf-8"))


@app.get("/deck", include_in_schema=False)
def redirect_deck_to_investor_deck():
    """Backward-compatible alias for investor deck links."""
    return RedirectResponse(url="/investor-deck", status_code=302)


@app.get("/waitlist", include_in_schema=False)
def redirect_waitlist_to_apply():
    return RedirectResponse(url="/apply", status_code=302)


@app.get("/beta", include_in_schema=False)
def redirect_beta_to_apply():
    return RedirectResponse(url="/apply", status_code=302)


@app.get("/early-access", include_in_schema=False)
def redirect_early_access_to_apply():
    return RedirectResponse(url="/apply", status_code=302)


@app.get("/request-access", include_in_schema=False)
def redirect_request_access_to_apply():
    return RedirectResponse(url="/apply", status_code=302)


@app.get("/terms", response_class=HTMLResponse, include_in_schema=False)
async def terms_of_service():
    """Public Terms of Service (includes Beta / Early Access NDA + limited non-compete)."""
    _f = _TEMPLATES_DIR / "terms.html"
    if not _f.exists():
        return HTMLResponse("<h1>Terms not found</h1>", status_code=404)
    return HTMLResponse(content=_f.read_text(encoding="utf-8"))


@app.get("/privacy", response_class=HTMLResponse, include_in_schema=False)
async def privacy_policy():
    """Public Privacy Policy."""
    _f = _TEMPLATES_DIR / "privacy.html"
    if not _f.exists():
        return HTMLResponse("<h1>Privacy policy not found</h1>", status_code=404)
    return HTMLResponse(content=_f.read_text(encoding="utf-8"))


def _build_keepsake_zip(base_url: str, user_note: str = "") -> bytes:
    """ZIP: printable HTML receipt + manifest.json for user archival (no secrets)."""
    import html as html_module
    import io
    import zipfile
    from datetime import datetime, timezone

    now = datetime.now(timezone.utc)
    now_iso = now.isoformat()
    note_clean = (user_note or "")[:500].strip()

    approvals = [
        {
            "id": "build",
            "title": "Deployed build identity",
            "detail": (
                f"Package version {_VERSION}"
                + (
                    f"; source commit {_GIT_SHA}"
                    if _GIT_SHA
                    else " (no commit hash recorded in this environment)"
                )
            ),
        },
        {
            "id": "archive",
            "title": "Personal archive",
            "detail": "This bundle is for your records. It does not grant API access.",
        },
    ]
    manifest = {
        "schema": "ohaco.keepsake.v1",
        "product": "collab-memory",
        "publisher": "OHACO Labs",
        "package_version": _VERSION,
        "git_commit": _GIT_SHA or None,
        "generated_at_utc": now_iso,
        "instance_base_url": base_url,
        "user_note": note_clean or None,
        "approvals": approvals,
    }

    esc_url = html_module.escape(base_url, quote=True)
    esc_ver = html_module.escape(_VERSION, quote=True)
    esc_sha = html_module.escape(_GIT_SHA or "—", quote=True)
    esc_time = html_module.escape(now_iso)
    note_block = ""
    if note_clean:
        note_block = f"<p><strong>Your note</strong></p><p>{html_module.escape(note_clean)}</p>"
    d0 = html_module.escape(approvals[0]["detail"])
    d1 = html_module.escape(approvals[1]["detail"])
    t0 = html_module.escape(approvals[0]["title"])
    t1 = html_module.escape(approvals[1]["title"])

    html_doc = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>OHACO Labs — Variation receipt</title>
<style>
  body {{ font-family: system-ui, -apple-system, sans-serif; max-width: 720px; margin: 2rem auto; padding: 0 1rem;
    color: #111; line-height: 1.55; }}
  h1 {{ font-size: 1.35rem; letter-spacing: -0.02em; }}
  .muted {{ color: #555; font-size: 0.9rem; }}
  table {{ border-collapse: collapse; width: 100%; margin: 1.25rem 0; font-size: 0.95rem; }}
  th, td {{ border: 1px solid #ccc; padding: 8px 10px; text-align: left; vertical-align: top; }}
  th {{ background: #f4f4f5; width: 34%; }}
  .approvals {{ margin-top: 1.5rem; }}
  .approvals ul {{ padding-left: 1.2rem; }}
  .approvals li {{ margin: 0.45rem 0; }}
  .sig {{ margin-top: 2rem; padding-top: 1rem; border-top: 1px solid #ccc; }}
  .line {{ margin-top: 0.65rem; border-bottom: 1px solid #333; min-height: 1.25em; }}
</style>
</head>
<body>
  <h1>Cognitive Memory — variation receipt</h1>
  <p class="muted">OHACO Labs · Keep this file when you like how this instance behaves. Open offline; pair with <code>manifest.json</code> for diffing.</p>
  <table>
    <tr><th>Instance URL</th><td>{esc_url}</td></tr>
    <tr><th>Package version</th><td>{esc_ver}</td></tr>
    <tr><th>Source commit</th><td>{esc_sha}</td></tr>
    <tr><th>Generated (UTC)</th><td>{esc_time}</td></tr>
  </table>
  {note_block}
  <div class="approvals">
    <h2 style="font-size:1.1rem">Attestations</h2>
    <ul>
      <li><strong>{t0}</strong> — {d0}</li>
      <li><strong>{t1}</strong> — {d1}</li>
    </ul>
  </div>
  <div class="sig">
    <p><strong>Your approval (optional)</strong></p>
    <p class="muted">Sign or date when this variation is the one you want in your records.</p>
    <div>Approved for my use by: <div class="line"></div></div>
    <div>Date: <div class="line"></div></div>
  </div>
</body>
</html>"""

    readme = (
        "collab-memory — variation receipt (ZIP)\n\n"
        "Files:\n"
        "  variation-receipt.html — Human-readable receipt (works offline).\n"
        "  manifest.json — Same facts for diffing / tooling.\n"
        "  README.txt — This note.\n\n"
        "Regenerate anytime from /gallery while this build is live.\n"
    )

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("manifest.json", json.dumps(manifest, indent=2))
        zf.writestr("variation-receipt.html", html_doc)
        zf.writestr("README.txt", readme)
    return buf.getvalue()


@app.get("/gallery", response_class=HTMLResponse, include_in_schema=False)
async def gallery_page():
    """Product gallery — download a versioned keepsake ZIP for your records."""
    _gf = _TEMPLATES_DIR / "gallery.html"
    if not _gf.exists():
        return HTMLResponse(
            "<h1>Gallery</h1><p><a href='/gallery/keepsake.zip'>Download variation receipt (ZIP)</a></p>",
            status_code=200,
        )
    return HTMLResponse(content=_gf.read_text(encoding="utf-8"))


@app.get("/gallery/keepsake.zip", include_in_schema=False)
async def gallery_keepsake_zip(request: Request, note: str = Query("", max_length=500, description="Optional short note stored in the manifest")):
    """ZIP: variation-receipt.html + manifest.json — archive this build before upgrades."""
    base = str(request.base_url).rstrip("/")
    body = _build_keepsake_zip(base, note)
    fname = f"collab-memory-variation-{_VERSION}.zip".replace("/", "-")
    return Response(
        content=body,
        media_type="application/zip",
        headers={"Content-Disposition": f'attachment; filename="{fname}"'},
    )


# ─── 3D Agent Workspace ──────────────────────────────────────────────────────

@app.get("/workspace", response_class=HTMLResponse, include_in_schema=False)
async def workspace(request: Request):
    """Serve the 3D Agent Workspace — immersive graph visualization."""
    _ws_file = _TEMPLATES_DIR / "workspace.html"
    if not _ws_file.exists():
        return HTMLResponse(
            "<h1>Workspace</h1>"
            "<p>workspace.html template not found.</p>"
            "<p><a href='/'>← Dashboard</a></p>",
            status_code=200,
        )
    html = _ws_file.read_text(encoding="utf-8")
    # Inject a read-only API key so workspace can fetch /graph/export (now auth-gated).
    # Priority: READONLY key > first available key > empty (local dev, no auth).
    _workspace_key = (
        os.environ.get("COLLAB_API_KEY_READONLY", "").strip()
        or os.environ.get("COLLAB_API_KEY", "").strip()
    )
    html = html.replace(
        "// ── Boot ──",
        f"const __WORKSPACE_KEY = '{_workspace_key}';\n// ── Boot ──",
    )
    return HTMLResponse(content=html)


# ─── Setup Wizard ─────────────────────────────────────────────────────────────

@app.get("/setup/status", summary="Current backend status")
def setup_status(request: Request):
    """Return current backend type and connection health.
    Config details only shown to admin role."""
    reachable = True
    if hasattr(graph, "test_connection"):
        reachable = graph.test_connection()
    result = {
        "backend": active_backend,
        "reachable": reachable,
    }
    # Only expose connection details to admin
    agent = getattr(request.state, "agent", AgentContext())
    if agent.is_admin:
        result["config"] = {
            "neo4j_uri": os.environ.get("NEO4J_URI", ""),
            "falkordb_url": os.environ.get("FALKORDB_URL", ""),
            "local_graph_path": os.environ.get("LOCAL_GRAPH_PATH", "./data/graph.json"),
        }
    return result


class TestConnectionRequest(BaseModel):
    backend: str          # "local" | "neo4j" | "falkordb" | "graphiti"
    neo4j_uri: str = ""
    neo4j_user: str = "neo4j"
    neo4j_password: str = ""
    falkordb_url: str = "redis://localhost:6379"
    local_graph_path: str = "./data/graph.json"


@app.post("/setup/test", summary="Test a backend connection")
def test_connection(req: TestConnectionRequest):
    """
    Test-connect to a graph backend without switching the live server.
    Used by the Setup Wizard before the user commits to a backend change.
    """
    try:
        if req.backend == "local":
            from pathlib import Path as _Path
            p = _Path(req.local_graph_path)
            p.parent.mkdir(parents=True, exist_ok=True)
            return {"ok": True, "backend": "local", "message": f"Path: {req.local_graph_path}"}

        elif req.backend == "neo4j":
            from ..graph.neo4j_backend import Neo4jBackend
            test_graph = Neo4jBackend(
                uri=req.neo4j_uri or "bolt://localhost:7687",
                user=req.neo4j_user,
                password=req.neo4j_password,
            )
            ok = test_graph.test_connection()
            return {"ok": ok, "backend": "neo4j", "message": "Connected to Neo4j" if ok else "Connection failed"}

        elif req.backend in ("falkordb", "graphiti"):
            # Lightweight check: just try to import and parse the URL
            from ..graph.graphiti_backend import GraphitiBackend
            return {"ok": True, "backend": req.backend, "message": f"FalkorDB URL: {req.falkordb_url} (start server to verify)"}

        else:
            return {"ok": False, "backend": req.backend, "message": f"Unknown backend: {req.backend}"}

    except ImportError as e:
        return {"ok": False, "backend": req.backend, "message": f"Missing dependency: {e}"}
    except Exception as e:
        return {"ok": False, "backend": req.backend, "message": str(e)}


@app.get("/setup", response_class=HTMLResponse, include_in_schema=False)
async def setup_wizard(request: Request):
    """Serve the Setup Wizard for first-time configuration."""
    _setup_file = _TEMPLATES_DIR / "setup.html"
    if not _setup_file.exists():
        return HTMLResponse(
            "<h1>Setup Wizard</h1><p>setup.html template not found.</p>",
            status_code=200,
        )
    api_base = str(request.base_url).rstrip("/")
    html = _setup_file.read_text(encoding="utf-8")
    html = html.replace("{{ api_base }}", api_base)
    return HTMLResponse(content=html)


# ── Pipeline Endpoints ─────────────────────────────────────────────────────────


class PipelineRunRequest(BaseModel):
    text: str
    session_id: str = "dashboard"
    label: str = ""
    skip_llm: bool = False


@app.post("/memory/pipeline/run", summary="Run a single exchange through the 6-agent pipeline")
async def pipeline_run(req: PipelineRunRequest):
    """
    Runs raw text through the full agent pipeline:
      Intake → Classifier → Security/Drift → Graph Writer

    ADR-0004: Endpoint is async; the sync LangGraph pipeline is offloaded to
    the thread pool via asyncio.to_thread so the event loop remains free for
    other HTTP requests during the LLM call (which can take 10-45s).

    This endpoint is called by the Neo4j poll watcher and directly by agents.
    """
    _ensure_pipeline()
    if not _PIPELINE_AVAILABLE or run_pipeline is None:
        raise HTTPException(
            status_code=503,
            detail="Pipeline not available. Check agents/ module installation."
        )
    try:
        import time
        t0 = time.time()
        # LangGraph invoke() is sync — offload to thread pool, free the event loop
        state = await asyncio.to_thread(
            run_pipeline,
            raw_text=req.text,
            session_id=req.session_id,
            skip_llm=req.skip_llm,
            graph=graph,
        )
        elapsed = round(time.time() - t0, 2)
        return {
            "session_id": req.session_id,
            "should_classify": state.get("should_classify", False),
            "primitive_type": state.get("primitive_type", "Unknown"),
            "worthiness_score": state.get("final_score", state.get("worthiness_score", 0.0)),
            "node_id": state.get("exchange_record_id", state.get("node_id", "")),
            "pending": state.get("pending_confirmation", state.get("pending", False)),
            "security_flagged": state.get("security_flagged", False),
            "should_encode": state.get("should_encode", False),
            "nodes_generated": state.get("nodes_generated", []),
            "classifier_reasoning": state.get("classifier_reasoning", ""),
            "summary": state.get("summary", ""),
            "elapsed_seconds": elapsed,
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/memory/pipeline/status", summary="Get pipeline configuration and status")
def pipeline_status():
    """
    Returns current pipeline backend, agent list, and availability.
    Used by the dashboard and monitoring.
    """
    _ensure_pipeline()
    if not _PIPELINE_AVAILABLE or _get_pipeline_status is None:
        return {
            "available": False,
            "backend": "unavailable",
            "agents": [],
            "reason": "Pipeline module not loaded",
        }
    status = _get_pipeline_status(graph=graph)
    status["available"] = True
    return status


# ── Watcher Endpoints ────────────────────────────────────────────────────────


@app.get("/memory/watcher/status", summary="Get poll watcher status and statistics")
def watcher_status():
    """
    Returns the Neo4j poll watcher's current state: running, poll count,
    records processed/failed, consolidation count, and timing info.
    """
    if _poll_watcher is None:
        return {
            "running": False,
            "reason": "Poll watcher not initialized (requires neo4j backend and POLL_WATCHER_ENABLED=true)",
        }
    return _poll_watcher.get_stats()


@app.post("/memory/watcher/trigger", summary="Manually trigger a poll cycle")
def watcher_trigger():
    """
    Force the poll watcher to run one poll cycle immediately.
    Useful for testing or after bulk ingestion.
    Returns the number of records processed in this cycle.
    """
    if _poll_watcher is None:
        raise HTTPException(
            status_code=503,
            detail="Poll watcher not initialized.",
        )
    return _poll_watcher.trigger_poll_now()


# ── Security Watcher Endpoints ────────────────────────────────────────────────


@app.get("/security/watcher/status", summary="Get security watcher status and trust score")
def security_watcher_status():
    """Returns security watcher trust score, mentor status, and scan history."""
    from ..agents.watcher import create_watcher
    watcher = create_watcher(graph=graph)
    return {
        "trust_score": watcher.trust_score,
        "can_auto_block": watcher.can_auto_block,
        "mentor_provider": watcher._mentor_provider or None,
        "watcher_llm_provider": watcher.__class__.__module__,
    }


@app.post("/security/scan", summary="Run a full security scan")
def security_scan_full(request: Request):
    """
    Run a comprehensive security audit: tenant leaks, secrets in graph,
    access pattern anomalies. Admin only.
    """
    from ..agents.watcher import create_watcher
    agent = getattr(request.state, "agent", None)
    tid = getattr(agent, "tenant_id", None) if agent else None

    watcher = create_watcher(graph=graph)
    report = watcher.scan_full(tenant_id=tid)
    report_id = watcher.save_report(report, tenant_id=tid or "")

    return {
        "report_id": report_id,
        "scan_type": report.scan_type,
        "findings_count": len(report.findings),
        "critical_count": report.critical_count,
        "scanned_nodes": report.scanned_nodes,
        "scanned_queries": report.scanned_queries,
        "duration_ms": round(report.duration_ms, 1),
        "watcher_trust_score": report.watcher_trust_score,
        "findings": [
            {
                "category": f.category,
                "severity": f.severity,
                "description": f.description,
                "node_id": f.node_id or None,
                "auto_blocked": f.auto_blocked,
                "escalated": f.escalated,
            }
            for f in report.findings[:50]  # cap response size
        ],
    }


@app.post("/security/watcher/feedback", summary="Submit mentor feedback on a watcher finding")
def security_watcher_feedback(confirmed: bool = Query(..., description="Was the finding correct?")):
    """
    AG (or any senior agent) confirms or rejects a watcher finding.
    This adjusts the watcher's trust score — the graduation mechanism
    that lets the free agent earn autonomy.
    """
    from ..agents.watcher import create_watcher
    watcher = create_watcher(graph=graph)
    watcher.record_mentor_feedback(finding_confirmed=confirmed)
    return {
        "trust_score": watcher.trust_score,
        "can_auto_block": watcher.can_auto_block,
        "feedback": "confirmed" if confirmed else "false_positive",
    }


# ── Sprint S5: Session Lifecycle Endpoints ────────────────────────────────────


class SessionStartRequest(BaseModel):
    session_id: str
    project_id: str = "default"
    label: str = ""


@app.post("/memory/session/start", summary="Open a new session and register it in the graph")
def session_start(req: SessionStartRequest):
    """
    Creates (or re-opens) a Session node in the graph.
    Returns the session_id to use for all subsequent /memory/ingest calls.

    Call this at the beginning of any agent session to register the session
    context in the graph. The session node is used to group all decisions,
    constraints, and preferences produced during that session.
    """
    try:
        ts = str(datetime.now(timezone.utc))
        graph._tx_write(
            """
            MERGE (s:Session {id: $sid})
            SET s.label      = $label,
                s.project_id = $project_id,
                s.started_at = COALESCE(s.started_at, $ts),
                s.last_seen  = $ts,
                s.status     = 'active'
            """,
            sid=req.session_id,
            label=req.label or req.session_id,
            project_id=req.project_id,
            ts=ts,
        )
        return {
            "ok": True,
            "session_id": req.session_id,
            "started_at": ts,
            "note": f"Session '{req.session_id}' is now active — use this session_id in all /memory/ingest calls.",
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/memory/session/{session_id}/compress", summary="Compress a session into a summary node")
def session_compress(session_id: str):
    """
    Compresses all exchange records from the given session into a single
    LLM-generated summary node stored in the graph as a Decision.

    This prevents context overflow: future /memory/context calls will include
    these compressed session summaries in the bootstrap brief instead of
    returning thousands of raw exchanges.

    Call at session end, or any time exchanges > 20.
    """
    try:
        from ..session_compressor import compress_session
        result = compress_session(session_id=session_id, graph=graph)
        if result.get("error"):
            raise HTTPException(status_code=500, detail=result["error"])
        # Mark session as closed
        graph._tx_write(
            "MATCH (s:Session {id: $sid}) SET s.status = 'closed', s.closed_at = $ts",
            sid=session_id,
            ts=str(datetime.now(timezone.utc)),
        )
        return {
            "ok": True,
            "session_id": session_id,
            "summary": result.get("summary", ""),
            "node_id": result.get("node_id", ""),
            "exchanges_compressed": result.get("exchanges_compressed", 0),
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/memory/session/{session_id}/summary", summary="Get a session's compressed summary")
def session_summary(session_id: str):
    """
    Returns the latest compressed summary node for the given session,
    if one has been created via POST /memory/session/{id}/compress.
    """
    try:
        rows = graph._tx_read(
            """
            MATCH (n:Decision)
            WHERE n.origin = 'session_summary' AND n.summary_of_session = $sid
            RETURN n ORDER BY n.created_at DESC LIMIT 1
            """,
            sid=session_id,
        )
        if not rows:
            return {"session_id": session_id, "summary": None, "note": "No summary found — call POST /memory/session/{id}/compress first"}
        node = rows[0]["n"]
        return {
            "session_id": session_id,
            "summary": node.get("description", ""),
            "node_id": node.get("id", ""),
            "exchanges_compressed": node.get("exchanges_compressed", 0),
            "created_at": str(node.get("created_at", "")),
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ── Sprint S8: Episode Consolidation (RAPTOR Layer 1) ─────────────────────────

@app.post(
    "/memory/session/{session_id}/consolidate",
    summary="Consolidate session into an Episode node (RAPTOR Layer 1)",
)
async def session_consolidate(session_id: str, project_id: Optional[str] = None):
    """
    Summarizes the session's exchanges into an **Episode node** — the first
    level of the RAPTOR memory hierarchy.

    This is the "synthetic sleep" that promotes information from episodic
    (individual exchanges) toward semantic (cross-session themes).

    **Trigger automatically** at session end, or call manually to consolidate
    any session on demand.

    The Episode node captures:
    - LLM-generated summary of what happened
    - Dominant themes (for future RAPTOR Layer 2 Sprint clustering)
    - Counts of decisions, constraints, preferences, and exchanges
    - Its own embedding for cross-session similarity search

    Source: CLS theory (McClelland et al. 1995) + RAPTOR (arxiv:2401.18059)
    """
    import traceback as _tb
    from ..agents.consolidator import consolidate_session as _consolidate

    llm_client = None
    try:
        from ..llm import get_llm_client  # optional — may not exist yet
        llm_client = get_llm_client()
    except Exception:
        llm_client = None  # graceful degradation to fallback summary

    try:
        result = await _consolidate(
            session_id=session_id,
            project_id=project_id,
            graph=graph,
            llm_client=llm_client,
        )
        if result.get("status") == "error":
            raise HTTPException(status_code=500, detail=result.get("message"))
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error("consolidation failed:\n%s", _tb.format_exc())
        raise HTTPException(status_code=500, detail=str(e))


# ── Sprint S6: Workflow Template API ──────────────────────────────────────────


def _get_workflows_dir() -> Path:
    """Resolve the .agents/workflows directory relative to the server."""
    candidates = [
        Path("/app/.agents/workflows"),                   # Docker / Render
        Path(__file__).parent.parent.parent.parent.parent / ".agents" / "workflows",  # local dev
        Path.cwd() / ".agents" / "workflows",
    ]
    for c in candidates:
        if c.is_dir():
            return c
    return Path("/app/.agents/workflows")


def _parse_workflow_file(path: Path) -> dict:
    """Parse YAML frontmatter + markdown body from a workflow .md file."""
    import re
    text = path.read_text(encoding="utf-8")
    meta: dict = {}
    body = text

    # Extract YAML frontmatter between --- delimiters
    fm_match = re.match(r"^---\s*\n(.*?)\n---\s*\n", text, re.DOTALL)
    if fm_match:
        fm_text = fm_match.group(1)
        body = text[fm_match.end():]
        # Simple YAML key: value parser (no PyYAML dep needed for flat structures)
        for line in fm_text.splitlines():
            if ":" in line and not line.strip().startswith("-") and not line.strip().startswith("#"):
                k, _, v = line.partition(":")
                k = k.strip()
                v = v.strip()
                if v.startswith("["):
                    # Parse list: [a, b, c]
                    meta[k] = [x.strip().strip('"').strip("'") for x in v.strip("[]").split(",") if x.strip()]
                elif v:
                    meta[k] = v.strip('"').strip("'")
            elif line.strip().startswith("- ") and meta:
                # Append to last list
                last_key = list(meta.keys())[-1]
                if isinstance(meta[last_key], list):
                    meta[last_key].append(line.strip()[2:].strip('"').strip("'"))

    return {
        "name": meta.get("name", path.stem),
        "description": meta.get("description", ""),
        "version": meta.get("version", "1.0"),
        "category": meta.get("category", "general"),
        "tags": meta.get("tags", []),
        "triggers": meta.get("triggers", []),
        "gates": meta.get("gates", []),
        "outputs": meta.get("outputs", []),
        "body": body.strip(),
        "filename": path.name,
    }


@app.get("/workflows", summary="List all available workflow templates")
def list_workflows():
    """
    Returns all workflow templates available in the system.
    Workflows are .md files in .agents/workflows/ with YAML frontmatter.

    Use this to discover available workflows before triggering /workflows/{name}.
    Compatible with: slash commands, agent tool calls, dashboard UI.
    """
    wdir = _get_workflows_dir()
    workflows = []
    if wdir.is_dir():
        for fpath in sorted(wdir.glob("*.md")):
            try:
                wf = _parse_workflow_file(fpath)
                workflows.append({
                    "name": wf["name"],
                    "description": wf["description"],
                    "category": wf["category"],
                    "tags": wf["tags"],
                    "triggers": wf["triggers"],
                    "gate_count": len(wf["gates"]),
                    "slug": fpath.stem,
                })
            except Exception:
                continue
    return {"workflows": workflows, "count": len(workflows), "dir": str(wdir)}


@app.get("/workflows/{slug}", summary="Get a specific workflow template with full SOP")
def get_workflow(slug: str):
    """
    Returns the full workflow definition including frontmatter metadata,
    gate questions, expected outputs, and the full SOP body.

    The 'body' field contains the human-readable step-by-step instructions
    that any AI agent can execute. Inject it directly into the agent's context.
    """
    wdir = _get_workflows_dir()
    fpath = wdir / f"{slug}.md"
    if not fpath.exists():
        raise HTTPException(status_code=404, detail=f"Workflow '{slug}' not found")
    try:
        return _parse_workflow_file(fpath)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/workflows/sync", summary="Sync workflow files into Neo4j as discoverable Skill nodes")
def sync_workflows():
    """
    Reads all .agents/workflows/*.md files and upserts them as Skill nodes
    in the graph so they appear in /memory/search and /skills/search results.

    Run this after adding new workflow files to make them semantically discoverable.
    """
    from ..schema import Skill, SkillSourceType
    import uuid

    wdir = _get_workflows_dir()
    synced = []
    errors = []

    for fpath in sorted(wdir.glob("*.md")):
        try:
            wf = _parse_workflow_file(fpath)
            skill = Skill(
                id=f"workflow_{fpath.stem}",
                name=wf["name"],
                url="",
                summary=wf["description"],
                content=wf["body"][:2000],
                tags=wf["tags"] + [wf["category"], "workflow"],
                source_type=SkillSourceType.custom,
                added_by="workflow_sync",
            )
            graph.save_skill(skill)
            synced.append(wf["name"])
        except Exception as e:
            errors.append({"file": fpath.name, "error": str(e)})

    return {"synced": synced, "errors": errors, "count": len(synced)}


# ─── Admin / Migration Endpoints ──────────────────────────────────────────────

@app.post(
    "/admin/backfill-project-id",
    summary="Backfill project_id on legacy nodes",
    tags=["admin"],
)
def admin_backfill_project_id(
    project_id: str = Query("collab-memory", description="Project ID to stamp on NULL nodes"),
    dry_run: bool = Query(False, description="If true, count affected nodes without writing"),
    only_types: Optional[str] = Query(
        None,
        description="Comma-separated node types to backfill (default: all)",
    ),
    request: Request = None,
):
    """
    Stamp all nodes missing project_id with the provided value.
    Use dry_run=true first to see how many nodes will be affected.

    This is idempotent: only nodes WHERE project_id IS NULL are updated.
    Protected by X-API-Key.
    """
    if not hasattr(graph, "backfill_project_id"):
        raise HTTPException(
            status_code=501,
            detail="Backend does not support backfill_project_id.",
        )
    types_list = [t.strip() for t in only_types.split(",")] if only_types else None
    result = graph.backfill_project_id(
        project_id=project_id,
        only_types=types_list,
        dry_run=dry_run,
    )
    return {
        **result,
        "note": (
            f"Would stamp {result['affected']} nodes — run without dry_run=true to apply."
            if dry_run
            else f"Stamped {result['affected']} nodes with project_id='{project_id}'."
        ),
    }


@app.post(
    "/admin/backfill-tenant-id",
    summary="Backfill tenant_id on legacy nodes (Sprint 23)",
    tags=["admin"],
)
def admin_backfill_tenant_id(
    tenant_id: str = Query("default", description="Tenant ID to stamp on NULL nodes"),
    dry_run: bool = Query(False, description="If true, count affected nodes without writing"),
    request: Request = None,
):
    """
    Stamp all nodes missing tenant_id with the provided value.
    Idempotent: only nodes WHERE tenant_id IS NULL are updated.
    Protected by X-API-Key (admin only).
    """
    labels = ["Decision", "Constraint", "Preference", "Attempt", "Artifact", "ExchangeRecord"]
    results = {}
    total = 0

    for label in labels:
        if dry_run:
            query = f"MATCH (n:{label}) WHERE n.tenant_id IS NULL RETURN count(n) AS cnt"
            rows = graph._tx_read(query)
            count = rows[0]["cnt"] if rows else 0
        else:
            query = f"MATCH (n:{label}) WHERE n.tenant_id IS NULL SET n.tenant_id = $tid RETURN count(n) AS cnt"
            rows = graph._tx_write(query, tid=tenant_id) or []
            # _tx_write may not return rows, count via read
            verify = graph._tx_read(f"MATCH (n:{label}) WHERE n.tenant_id = $tid RETURN count(n) AS cnt", tid=tenant_id)
            count = verify[0]["cnt"] if verify else 0
        results[label] = count
        total += count

    return {
        "tenant_id": tenant_id,
        "dry_run": dry_run,
        "results": results,
        "total_affected": total,
        "note": (
            f"Would stamp {total} nodes — run without dry_run=true to apply."
            if dry_run
            else f"Backfill complete: all NULL tenant_id nodes now = '{tenant_id}'."
        ),
    }


@app.post(
    "/admin/purge-self-loop-edges",
    summary="Delete self-referential GRADUATED_FROM edges (graduation bug cleanup)",
    tags=["admin"],
)
def admin_purge_self_loops(
    dry_run: bool = Query(True, description="If true, count edges without deleting"),
    request: Request = None,
):
    """
    Purge GRADUATED_FROM self-loop edges created by the graduation bug
    (pre-fix: MERGE (n)-[:GRADUATED_FROM]->(n) with unique timestamps).
    Idempotent and safe — node properties (graduated_from, graduated_at) are preserved.
    """
    if dry_run:
        rows = graph._tx_read(
            "MATCH (n)-[r:GRADUATED_FROM]->(n) RETURN count(r) AS cnt"
        )
        count = rows[0]["cnt"] if rows else 0
        return {"dry_run": True, "self_loop_edges": count, "note": f"Found {count} self-loop edges. Run with dry_run=false to delete."}

    graph._tx_write("MATCH (n)-[r:GRADUATED_FROM]->(n) DELETE r")
    verify = graph._tx_read(
        "MATCH (n)-[r:GRADUATED_FROM]->(n) RETURN count(r) AS cnt"
    )
    remaining = verify[0]["cnt"] if verify else 0
    return {"dry_run": False, "deleted": True, "remaining_self_loops": remaining, "note": "Self-loop GRADUATED_FROM edges purged. Node properties preserved."}


@app.get(
    "/admin/export-graduation-events",
    summary="Export self-loop GRADUATED_FROM edges as timestamped reinforcement data",
    tags=["admin"],
)
def admin_export_graduation_events(
    limit: int = Query(1000, ge=1, le=50000, description="Max edges to return per page"),
    offset: int = Query(0, ge=0, description="Skip N edges"),
    node_id: Optional[str] = Query(None, description="Filter to a specific node"),
    request: Request = None,
):
    """
    Export self-loop GRADUATED_FROM edges as structured reinforcement data.
    Each edge = one graduation attempt with a timestamp, representing
    the system's reinforcement signal for that node.
    """
    params: dict[str, Any] = {"lim": limit, "off": offset}
    where = ""
    if node_id:
        where = "WHERE n.id = $nid"
        params["nid"] = node_id

    rows = graph._tx_read(
        f"""
        MATCH (n)-[r:GRADUATED_FROM]->(n)
        {where}
        RETURN n.id AS node_id,
               labels(n) AS labels,
               n.node_type AS node_type,
               n.description AS description,
               n.project_id AS project_id,
               n.recall_count AS recall_count,
               n.reinforcement_count AS reinforcement_count,
               r.at AS graduated_at
        ORDER BY r.at
        SKIP $off LIMIT $lim
        """,
        **params,
    )

    summary_rows = graph._tx_read(
        f"""
        MATCH (n)-[r:GRADUATED_FROM]->(n)
        {where}
        RETURN count(r) AS total_edges,
               count(DISTINCT n) AS unique_nodes,
               min(r.at) AS earliest,
               max(r.at) AS latest
        """,
        **{k: v for k, v in params.items() if k == "nid"},
    )
    summary = summary_rows[0] if summary_rows else {}

    return {
        "events": [dict(r) for r in rows],
        "pagination": {"offset": offset, "limit": limit, "returned": len(rows)},
        "summary": {
            "total_edges": summary.get("total_edges", 0),
            "unique_nodes": summary.get("unique_nodes", 0),
            "earliest_event": summary.get("earliest"),
            "latest_event": summary.get("latest"),
        },
    }


# ─── Audit Trail Endpoints ───────────────────────────────────────────────────

@app.get("/audit/context", summary="View context retrieval audit log")
def audit_context_log(
    limit: int = Query(50, ge=1, le=500),
    agent_id: Optional[str] = Query(None, description="Filter by agent_id"),
):
    """
    Returns the most recent context retrieval audit entries.
    Each entry records which agent retrieved context, when, with which
    scoped parameters, and how many items were returned.

    Use this to:
    - Monitor which agents are consuming context
    - Detect unusual retrieval patterns (context poisoning signals)
    - Debug why an agent received stale or incomplete context
    """
    from .audit import get_audit_entries
    entries = get_audit_entries(limit=limit)
    if agent_id:
        entries = [e for e in entries if e.get("agent_id") == agent_id]
    return {"entries": entries, "count": len(entries)}


@app.get("/audit/context/stats", summary="Aggregate audit statistics")
def audit_context_stats():
    """
    Returns aggregate statistics about context retrieval:
    total retrievals, unique agents, per-agent counts.
    """
    from .audit import get_audit_stats
    return get_audit_stats()


# ─── Auth Audit Endpoint ─────────────────────────────────────────────────────


@app.get("/audit/auth", summary="Auth event audit log")
def audit_auth_events(
    email: str = Query(default="", description="Filter by email"),
    event: str = Query(default="", description="Filter by event type: signup, login, refresh"),
    success: Optional[bool] = Query(default=None, description="Filter by success/failure"),
    limit: int = Query(default=50, le=200),
):
    """
    Query AuthAudit nodes — login attempts, signups, token refreshes.
    Useful for detecting brute-force attempts, tracking user activity,
    and compliance auditing.
    """
    q = "MATCH (a:AuthAudit)"
    clauses = []
    params: dict = {"limit": limit}
    if email:
        clauses.append("a.email = $email")
        params["email"] = email
    if event:
        clauses.append("a.event = $event")
        params["event"] = event
    if success is not None:
        clauses.append("a.success = $success")
        params["success"] = success
    if clauses:
        q += " WHERE " + " AND ".join(clauses)
    q += " RETURN a ORDER BY a.timestamp DESC LIMIT $limit"
    try:
        rows = graph._tx_read(q, **params)
        events = [dict(r["a"]) for r in rows]
    except Exception:
        events = []
    return {"events": events, "count": len(events)}


# ─── Python Interpreter Endpoint ──────────────────────────────────────────────

class PythonRunRequest(BaseModel):
    code: str
    timeout: Optional[int] = None
    inject_vars: Optional[dict] = None


@app.post(
    "/agent/python/run",
    summary="Execute Python code in a sandboxed subprocess",
    tags=["agent"],
)
def agent_python_run(body: PythonRunRequest):
    """
    Run Python code safely in a subprocess with:
    - Hard timeout (default 30s, configurable via PYTHON_RUNNER_TIMEOUT env)
    - Memory cap 128MB (Linux only, via RLIMIT_AS)
    - No network access (blocked-import check)
    - No filesystem writes outside /tmp

    Returns stdout, stderr, exit_code, timed_out, blocked imports list.
    """
    from ..agents.python_runner import run_python as _run_python
    result = _run_python(
        code=body.code,
        timeout=body.timeout,
        inject_vars=body.inject_vars,
    )
    return result
