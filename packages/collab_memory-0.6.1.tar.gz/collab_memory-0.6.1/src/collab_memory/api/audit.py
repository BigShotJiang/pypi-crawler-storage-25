"""
Audit logging for context retrieval endpoints.

Records which agent retrieved what context, when, and with which parameters.
Phase 1: In-memory ring buffer with HTTP endpoint for retrieval.
Phase 2: Persistent storage in database.
"""

import re
import time
from collections import deque
from datetime import datetime, timezone
from typing import Any, Optional


# ── Validation helpers ────────────────────────────────────────────────────────

_AGENT_ID_RE = re.compile(r"^[a-zA-Z0-9_-]{1,64}$")
_ORIGIN_VALUES = {"explicit", "inferred", "all"}


class ValidationError(Exception):
    """Raised when a scoped query parameter fails validation."""

    def __init__(self, param: str, message: str):
        self.param = param
        self.message = message
        super().__init__(f"{param}: {message}")


def validate_since(value: Optional[str]) -> Optional[datetime]:
    """
    Parse and validate the `since` parameter.
    Accepts ISO 8601 datetime strings or numeric Unix timestamps (seconds).
    Returns a timezone-aware datetime or None.
    """
    if value is None or value.strip() == "":
        return None

    value = value.strip()

    # Try numeric Unix timestamp first
    try:
        ts = float(value)
        if 0 < ts < 4_102_444_800:  # sanity: between epoch and 2100
            return datetime.fromtimestamp(ts, tz=timezone.utc)
    except (ValueError, OverflowError):
        pass

    # Try ISO 8601
    try:
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt
    except (ValueError, AttributeError):
        pass

    raise ValidationError(
        "since",
        "Invalid since parameter. Use ISO 8601 (e.g. 2026-03-01T00:00:00Z) or Unix timestamp (seconds).",
    )


def validate_agent_id(value: Optional[str]) -> str:
    """Validate and normalize agent_id. Returns 'anonymous' if not provided."""
    if value is None or value.strip() == "":
        return "anonymous"
    value = value.strip()
    if not _AGENT_ID_RE.match(value):
        raise ValidationError(
            "agent_id",
            "Invalid agent_id. Use alphanumeric characters, hyphens, and underscores (max 64 chars).",
        )
    return value


def validate_limit(value: Optional[int]) -> int:
    """Validate limit parameter. Returns default 10 if not provided."""
    if value is None:
        return 10
    if not isinstance(value, int) or value < 1 or value > 50:
        raise ValidationError("limit", "limit must be an integer between 1 and 50.")
    return value


def validate_confidence_min(value: Optional[float]) -> float:
    """Validate confidence_min parameter. Returns 0.0 if not provided."""
    if value is None:
        return 0.0
    if not isinstance(value, (int, float)) or value < 0.0 or value > 1.0:
        raise ValidationError(
            "confidence_min", "confidence_min must be a number between 0.0 and 1.0."
        )
    return float(value)


def validate_origin(value: Optional[str]) -> str:
    """Validate origin parameter. Returns 'all' if not provided."""
    if value is None or value.strip() == "":
        return "all"
    value = value.strip().lower()
    if value not in _ORIGIN_VALUES:
        raise ValidationError(
            "origin", "origin must be one of: explicit, inferred, all."
        )
    return value


# ── Audit Log ─────────────────────────────────────────────────────────────────

_MAX_AUDIT_ENTRIES = 500
_audit_log: deque[dict[str, Any]] = deque(maxlen=_MAX_AUDIT_ENTRIES)


def record_audit(
    endpoint: str,
    agent_id: str,
    project_id: Optional[str],
    params: dict[str, Any],
    result_counts: dict[str, int],
    response_chars: int,
    latency_ms: float,
) -> None:
    """Record a context retrieval event to the in-memory audit log + SSE."""
    entry = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "endpoint": endpoint,
        "agent_id": agent_id,
        "project_id": project_id,
        "params": params,
        "result_counts": result_counts,
        "response_chars": response_chars,
        "latency_ms": round(latency_ms, 1),
    }
    _audit_log.append(entry)

    # Emit to SSE subscribers for live audit feed
    try:
        from .sse import emit_event_sync
        emit_event_sync({"type": "audit.event", "event": "context_retrieval", **entry})
    except Exception:
        pass  # SSE emission is best-effort


def get_audit_entries(limit: int = 100) -> list[dict[str, Any]]:
    """Return the most recent audit entries (newest first)."""
    entries = list(_audit_log)
    entries.reverse()
    return entries[:limit]


def get_audit_stats() -> dict[str, Any]:
    """Return aggregate audit statistics."""
    entries = list(_audit_log)
    if not entries:
        return {"total_retrievals": 0, "unique_agents": 0, "agents": []}

    agents: dict[str, int] = {}
    for e in entries:
        aid = e.get("agent_id", "anonymous")
        agents[aid] = agents.get(aid, 0) + 1

    return {
        "total_retrievals": len(entries),
        "unique_agents": len(agents),
        "agents": [
            {"agent_id": k, "retrieval_count": v}
            for k, v in sorted(agents.items(), key=lambda x: -x[1])
        ],
        "oldest_entry": entries[0]["timestamp"] if entries else None,
        "newest_entry": entries[-1]["timestamp"] if entries else None,
    }
