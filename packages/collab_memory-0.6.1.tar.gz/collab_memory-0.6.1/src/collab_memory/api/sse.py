"""
Server-Sent Events (SSE) infrastructure for real-time graph updates.

Usage from anywhere in the codebase:
    from collab_memory.api.sse import emit_event
    await emit_event({"type": "node.created", "node": {...}})

The /stream/events endpoint streams these events to connected frontends.
"""

from __future__ import annotations
import asyncio
import json
from typing import Any

# ── Global subscriber registry ──
# Each connected client gets a Queue; emit_event pushes to all queues.
_subscribers: set[asyncio.Queue[dict[str, Any]]] = set()


def subscribe() -> asyncio.Queue[dict[str, Any]]:
    """Create a new subscriber queue and register it."""
    q: asyncio.Queue[dict[str, Any]] = asyncio.Queue(maxsize=256)
    _subscribers.add(q)
    return q


def unsubscribe(q: asyncio.Queue[dict[str, Any]]) -> None:
    """Remove a subscriber queue."""
    _subscribers.discard(q)


async def emit_event(event: dict[str, Any]) -> None:
    """Push an event to all connected subscribers. Non-blocking, fire-and-forget."""
    dead: list[asyncio.Queue[dict[str, Any]]] = []
    for q in _subscribers:
        try:
            q.put_nowait(event)
        except asyncio.QueueFull:
            dead.append(q)
    # Clean up clients that fell behind
    for q in dead:
        _subscribers.discard(q)


def emit_event_sync(event: dict[str, Any]) -> None:
    """Synchronous wrapper for emit_event — safe to call from sync code.
    Schedules the emit on the running event loop if available."""
    try:
        loop = asyncio.get_running_loop()
        loop.create_task(emit_event(event))
    except RuntimeError:
        # No event loop running — drop the event (acceptable in sync contexts)
        pass


def subscriber_count() -> int:
    """Number of currently connected SSE clients."""
    return len(_subscribers)
