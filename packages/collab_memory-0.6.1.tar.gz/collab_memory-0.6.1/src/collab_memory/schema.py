"""
schema.py — Pydantic models mirroring schema_v1.md.
This file is the code-level source of truth. Any change here
must be reflected in schema_v1.md first.
"""

from __future__ import annotations
from datetime import datetime, timezone
from enum import Enum
from typing import Optional
from pydantic import BaseModel, Field
import math
import uuid


# ─── Enums ────────────────────────────────────────────────────────────────────

class EntityType(str, Enum):
    project = "project"
    system = "system"
    technology = "technology"
    person = "person"
    concept = "concept"


class MemorySource(str, Enum):
    """
    Provenance of a memory node — distinguishes direct observation from inference.
    Surfaced as a badge in the dashboard so users can audit what the system reconstructed
    vs. what was explicitly stated.
    """
    stated       = "stated"        # directly said in the exchange
    inferred     = "inferred"      # classifier extracted from context
    reconstructed = "reconstructed" # LLM reasoned over graph (Graphiti-style)
    imported     = "imported"      # loaded from external source (file/URL/handoff)
    confirmed    = "confirmed"     # user explicitly confirmed via HITL


class DecisionStatus(str, Enum):
    active = "active"
    superseded = "superseded"
    reversed = "reversed"


class ConstraintOrigin(str, Enum):
    explicit = "explicit"
    inferred = "inferred"


class PreferenceType(str, Enum):
    aesthetic = "aesthetic"        # taste in design, visual, writing style
    process = "process"            # how they like to work
    technical = "technical"        # architectural instincts, stack choices
    risk = "risk"                  # speed vs correctness, ship vs polish
    interpersonal = "interpersonal"  # how they interact with the agent


class PrimitiveType(str, Enum):
    # High-signal
    Override = "Override"
    ConstraintSurface = "ConstraintSurface"
    DecisionClose = "DecisionClose"
    PreferenceReveal = "PreferenceReveal"
    AbandonedAttempt = "AbandonedAttempt"
    # Low-signal
    Exploration = "Exploration"
    Execution = "Execution"
    Clarification = "Clarification"
    Confirmation = "Confirmation"


class SkillSourceType(str, Enum):
    api_docs    = "api_docs"      # Official API reference / swagger
    guide       = "guide"         # Integration guide or tutorial
    snippet     = "snippet"       # Reusable code example
    integration = "integration"   # Platform connector how-to
    custom      = "custom"        # Manually entered skill


HIGH_SIGNAL_PRIMITIVES = {
    PrimitiveType.Override,
    PrimitiveType.ConstraintSurface,
    PrimitiveType.DecisionClose,
    PrimitiveType.PreferenceReveal,
    PrimitiveType.AbandonedAttempt,
}

WORTHINESS_THRESHOLD = 0.4   # global default — overridable per project
AMBIGUITY_LOWER = 0.3


def get_project_threshold(project_id: Optional[str], graph=None) -> float:
    """
    Return the worthiness threshold for a project.
    Falls back to the global default if no project-specific value is set.
    Used by encoder and classifier — pass graph=None in tests.
    """
    if not project_id or graph is None:
        return WORTHINESS_THRESHOLD
    try:
        rows = graph._tx_read(
            "MATCH (p:Project {id: $pid}) RETURN p.worthiness_threshold AS t LIMIT 1",
            pid=project_id,
        )
        val = rows[0]["t"] if rows else None
        return float(val) if val is not None else WORTHINESS_THRESHOLD
    except Exception:
        return WORTHINESS_THRESHOLD


# ─── Temporal Decay (HALO-style half-lives) ──────────────────────────────────
# Source: research_deep_five_topics.md §4, HALO model
# Half-life in days for each primitive type — used to modulate retrieval scores.
# Facts are NOT deleted; they are scored lower as they age.

HALF_LIVES_DAYS: dict[str, int] = {
    "AbandonedAttempt": 7,
    "ExplorationPath":  14,
    "Preference":       30,
    "Asset":            90,
    "Decision":         180,
    "Constraint":       365,
    "Skill":            730,
}


def temporal_validity(node_dict: dict, now: Optional[datetime] = None) -> float:
    """
    Compute exponential decay score for a node.
    Returns 1.0 at creation, 0.5 at half-life, approaching 0 asymptotically.

    Args:
        node_dict: Node properties dict (must contain 'created_at' or 'last_confirmed').
        now:       Reference time (defaults to utcnow).

    Returns:
        Float in (0, 1] representing temporal validity.
    """
    if now is None:
        now = datetime.now(timezone.utc)

    created_raw = node_dict.get("last_confirmed") or node_dict.get("created_at")
    if not created_raw:
        return 1.0

    if isinstance(created_raw, str):
        try:
            created = datetime.fromisoformat(created_raw.replace("Z", "+00:00"))
            # strip tz for naive comparison
            created = created.replace(tzinfo=None)
        except (ValueError, AttributeError):
            return 1.0
    else:
        created = created_raw

    now_naive = now.replace(tzinfo=None) if now.tzinfo else now
    age_days = max((now_naive - created).days, 0)
    primitive_type = node_dict.get("primitive_type", "Decision")
    half_life = HALF_LIVES_DAYS.get(primitive_type, 90)
    lambda_ = math.log(2) / half_life
    return math.exp(-lambda_ * age_days)


# ─── Node Models ──────────────────────────────────────────────────────────────

class Session(BaseModel):
    id: str                          # conversation_id
    started_at: datetime
    ended_at: Optional[datetime] = None
    title: str
    primary_project: Optional[str] = None  # Entity.id ref
    project_id: Optional[str] = None       # Project.id scope
    summary: str = ""


# Default project scope (backward-compatible — used when project_id is omitted)
DEFAULT_PROJECT = "default"


class Project(BaseModel):
    """
    A named scope that groups Sessions, Decisions, Constraints, Preferences.
    Enables cross-project isolation — each project gets its own graph partition.
    One collab-memory instance can serve multiple independent projects.

    Sprint 23: Added tenant_id, members, status for ownership enforcement.
    """
    id: str = Field(default_factory=lambda: f"prj_{uuid.uuid4().hex[:8]}")
    name: str                        # Display name, e.g. "collab-memory", "prompt-native"
    description: str = ""
    tenant_id: str = "default"       # Tenant isolation scope
    owner_id: str = ""               # User or agent who owns this project
    members: list[str] = Field(default_factory=list)  # JSON strings of {user_id, role, added_at}
    status: str = "active"           # active | archived | deleted
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    tags: list[str] = Field(default_factory=list)
    # Lead Agent Model (Session 30): user nominates their preferred AI provider
    # as the project orchestrator. Lead agent receives admin ABAC, full context,
    # and is responsible for onboarding other agents.
    lead_agent: str = "ohaco"        # ohaco | claude | gemini | gemma | gpt | cursor | manus | deepseek | kimi | ollama
    workflow_skill_id: str = ""      # Skill node ID of the project's workflow rules
    worthiness_threshold: float = WORTHINESS_THRESHOLD  # per-project override (0.0–1.0)
    hitl_confirm_count: int = 0      # HITL confirmations — used for threshold calibration
    hitl_reject_count: int = 0       # HITL rejections — used for threshold calibration


class Entity(BaseModel):
    id: str = Field(default_factory=lambda: f"ent_{uuid.uuid4().hex[:8]}")
    name: str
    type: EntityType
    first_seen: datetime = Field(default_factory=datetime.utcnow)
    last_updated: datetime = Field(default_factory=datetime.utcnow)
    description: str = ""


class Decision(BaseModel):
    id: str = Field(default_factory=lambda: f"dec_{uuid.uuid4().hex[:8]}")
    made_in: str                     # Session.id
    made_at: datetime = Field(default_factory=datetime.utcnow)
    description: str
    rationale: str = ""              # why — extracted or inferred
    status: DecisionStatus = DecisionStatus.active
    confidence: float = 1.0
    exchange_record_id: str = ""
    project_id: Optional[str] = None  # Project scope (None = default)
    tenant_id: str = "default"         # Tenant isolation scope
    module: str = ""                 # e.g. pipeline | api | schema | research | infrastructure
    category: str = "decision"       # e.g. decision | skill | library | prd | git | research | task
    # ── Bi-temporal (Graphiti schema) ──
    valid_at: Optional[datetime] = None
    invalid_at: Optional[datetime] = None
    episode_id: str = ""
    decay_rate: str = "Decision"
    created_by: str = "agent"          # "agent" | "user" | "import" | agent_id
    memory_source: MemorySource = MemorySource.inferred  # provenance badge
    version: int = 1                   # incremented on each write; used for conflict detection
    # ── Cognitive Dreams reinforcement ──
    recall_count: int = 0              # incremented each time this node is retrieved
    last_recalled: Optional[datetime] = None  # timestamp of most recent retrieval


class Attempt(BaseModel):
    id: str = Field(default_factory=lambda: f"att_{uuid.uuid4().hex[:8]}")
    tried_in: str
    tried_at: datetime = Field(default_factory=datetime.utcnow)
    description: str
    outcome: str = ""
    abandoned_because: str = ""
    exchange_record_id: str = ""
    project_id: Optional[str] = None
    tenant_id: str = "default"
    module: str = ""
    category: str = "attempt"
    valid_at: Optional[datetime] = None
    invalid_at: Optional[datetime] = None
    episode_id: str = ""
    decay_rate: str = "AbandonedAttempt"
    created_by: str = "agent"
    # ── Cognitive Dreams reinforcement ──
    recall_count: int = 0
    last_recalled: Optional[datetime] = None


class Constraint(BaseModel):
    id: str = Field(default_factory=lambda: f"con_{uuid.uuid4().hex[:8]}")
    surfaced_in: str
    surfaced_at: datetime = Field(default_factory=datetime.utcnow)
    description: str
    origin: ConstraintOrigin = ConstraintOrigin.explicit
    scope: str = ""
    still_active: bool = True
    exchange_record_id: str = ""
    project_id: Optional[str] = None
    tenant_id: str = "default"
    module: str = ""
    category: str = "constraint"
    valid_at: Optional[datetime] = None
    invalid_at: Optional[datetime] = None
    episode_id: str = ""
    decay_rate: str = "Constraint"
    created_by: str = "agent"
    memory_source: MemorySource = MemorySource.inferred
    version: int = 1
    # ── Cognitive Dreams reinforcement ──
    recall_count: int = 0
    last_recalled: Optional[datetime] = None


class Preference(BaseModel):
    id: str = Field(default_factory=lambda: f"prf_{uuid.uuid4().hex[:8]}")
    inferred_in: str                 # Session.id
    inferred_at: datetime = Field(default_factory=datetime.utcnow)
    description: str
    type: PreferenceType
    domain: str = ""                 # specific area within type
    evidence: str = ""               # quoted or paraphrased from exchange
    confidence: float = 0.7
    last_reinforced: datetime = Field(default_factory=datetime.utcnow)
    reinforcement_count: int = 1
    exchange_record_id: str = ""
    project_id: Optional[str] = None  # Project scope
    tenant_id: str = "default"
    valid_at: Optional[datetime] = None
    invalid_at: Optional[datetime] = None
    episode_id: str = ""
    decay_rate: str = "Preference"
    created_by: str = "agent"
    memory_source: MemorySource = MemorySource.inferred
    version: int = 1


class ConflictEvent(BaseModel):
    """
    Written when two agents attempt concurrent writes to the same node
    and the version check fails. Preserves both versions for human review
    rather than silently overwriting.

    Created by: neo4j_backend.safe_write() on version mismatch.
    Resolved by: POST /memory/conflicts/{id}/resolve — picks winner or merges.
    """
    id: str = Field(default_factory=lambda: f"cfl_{uuid.uuid4().hex[:8]}")
    node_id: str                     # the node both agents tried to update
    node_type: str                   # Decision | Constraint | Preference
    agent_a: str                     # first writer (agent_id)
    agent_b: str                     # second writer (agent_id)
    version_expected: int            # version agent_b expected to find
    version_found: int               # version already written by agent_a
    payload_a: dict = Field(default_factory=dict)   # agent_a's write (current)
    payload_b: dict = Field(default_factory=dict)   # agent_b's write (rejected)
    status: str = "pending"          # pending | resolved_a | resolved_b | merged
    created_at: datetime = Field(default_factory=datetime.utcnow)
    resolved_at: Optional[datetime] = None
    project_id: Optional[str] = None


class Skill(BaseModel):
    """
    A persistent, searchable knowledge reference.
    Skills are API docs, integration guides, code snippets, or how-to notes
    stored in the graph so agents can retrieve them without re-fetching.
    """
    id: str = Field(default_factory=lambda: f"skl_{uuid.uuid4().hex[:8]}")
    name: str                        # Display name, e.g. "Manus API — Quickstart"
    url: str = ""                    # Source URL (empty for custom snippets)
    summary: str = ""                # One-liner for dashboard display
    content: str = ""                # Full indexed text content
    tags: list[str] = Field(default_factory=list)   # e.g. ["manus", "rest", "python"]
    source_type: SkillSourceType = SkillSourceType.custom
    added_at: datetime = Field(default_factory=datetime.utcnow)
    last_updated: datetime = Field(default_factory=datetime.utcnow)
    added_by: str = "user"           # "user" | "agent" | "ingest"
    tenant_id: str = "default"
    project_id: Optional[str] = None


class ArtifactType(str, Enum):
    """Type of digital artifact — what kind of file it is."""
    code        = "code"         # Python, JS, TS, etc.
    html        = "html"         # Web page or component
    css         = "css"          # Stylesheet
    markdown    = "markdown"     # Docs, READMEs, notes
    json        = "json"         # Config, data
    image       = "image"        # PNG, JPG, SVG (base64 encoded)
    notebook    = "notebook"     # Jupyter .ipynb
    schema      = "schema"       # Database schema, OpenAPI spec
    prompt      = "prompt"       # Prompt template (links to Prompt Native)
    other       = "other"        # Anything else


class Artifact(BaseModel):
    """
    A digital artifact — any file produced or used during a project.

    Agents write artifacts here so they survive session boundaries,
    can be read by any other agent, and are backed up with the graph.
    Content is stored inline (text) or as base64 (binary).
    Large artifacts (>100KB) store only path + git_ref, not content.
    """
    id: str = Field(default_factory=lambda: f"art_{uuid.uuid4().hex[:8]}")
    name: str                            # Filename, e.g. "dashboard.html"
    artifact_type: ArtifactType = ArtifactType.other
    mime_type: str = "text/plain"        # MIME type, e.g. "text/html"
    content: str = ""                   # Full file content (inline for < 100KB)
    content_base64: bool = False        # True if content is base64-encoded
    path: str = ""                      # Relative path in project, e.g. "src/app.py"
    git_ref: str = ""                   # Git commit SHA if stored in repo
    size_bytes: int = 0
    session_id: str = ""               # Session it was created in
    project_id: Optional[str] = None   # Project scope
    tenant_id: str = "default"          # Tenant isolation
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    created_by: str = "agent"          # "agent" | "user" | "import"
    description: str = ""             # What this artifact does
    tags: list[str] = Field(default_factory=list)
    preview_url: str = ""             # Live preview URL if deployed


class TenantPlan(str, Enum):
    free       = "free"        # Legacy — kept for existing tenants, not assignable to new signups
    pro        = "pro"         # Row-level isolation, shared AuraDB
    enterprise = "enterprise"  # Dedicated AuraDB instance


class Tenant(BaseModel):
    """
    Tenant — billing/auth scope for multi-tenant deployments.

    Each tenant gets isolated row-level access (tenant_id on every node).
    Pro/Enterprise tiers get dedicated database or instance (future).
    API keys are stored hashed in the graph and resolved dynamically by ABAC.
    """
    id: str = Field(default_factory=lambda: f"tnt_{uuid.uuid4().hex[:8]}")
    name: str                                    # Org or user display name
    email: str = ""                              # Contact email
    plan: TenantPlan = TenantPlan.pro            # No free tier pre-revenue (2026-04-03)
    status: str = "active"                       # active | suspended | deleted
    api_key_write: str = Field(default_factory=lambda: f"cmk_write_{uuid.uuid4().hex}")
    api_key_read:  str = Field(default_factory=lambda: f"cmk_read_{uuid.uuid4().hex}")
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    owner_id: str = ""                           # User ID if auth is enabled


class ExchangeRecord(BaseModel):
    """
    Provenance anchor — every graph node traces back to one of these.
    Created for every classified exchange, including low-signal ones archived
    as Exploration.
    """
    id: str = Field(default_factory=lambda: f"exc_{uuid.uuid4().hex[:8]}")
    session_id: str
    turn_start: int
    turn_end: int
    raw_text: str
    primitive_type: PrimitiveType
    worthiness_score: float
    extracted_at: datetime = Field(default_factory=datetime.utcnow)
    extractor_version: str = "0.1.0"
    nodes_generated: list[str] = Field(default_factory=list)
    flagged_for_review: bool = False  # True if score in ambiguity zone (0.3-0.4)
    project_id: Optional[str] = None  # Project scope
    tenant_id: str = "default"


# ─── Edge Models ──────────────────────────────────────────────────────────────

class Edge(BaseModel):
    """Generic edge between two graph nodes."""
    id: str = Field(default_factory=lambda: f"edg_{uuid.uuid4().hex[:8]}")
    type: str                        # e.g. DECIDED_IN, SUPERSEDES, REVEALS
    source_id: str
    target_id: str
    properties: dict = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    # ── Bi-temporal ──
    valid_at: Optional[datetime] = None    # when relationship became true
    invalid_at: Optional[datetime] = None  # null = currently valid
    episode_id: str = ""                   # provenance
    confidence: float = 1.0


# ─── Episode Node (RAPTOR Layer 1) ───────────────────────────────────────────

class Episode(BaseModel):
    """
    Session-level summary node — the first level of RAPTOR consolidation.
    Created at session end by the consolidator agent.
    Links to all ExchangeRecords from the session it summarizes.

    Source: research_deep_five_topics.md §5, CLS theory / RAPTOR §11
    Biological analog: hippocampal-neocortical transfer during sleep (SWR replay).
    """
    id: str = Field(default_factory=lambda: f"ep_{uuid.uuid4().hex[:8]}")
    session_id: str                         # Session this episode summarizes
    project_id: Optional[str] = None
    summary: str                            # LLM-generated session summary
    themes: list[str] = Field(default_factory=list)  # Top semantic themes
    decision_count: int = 0
    constraint_count: int = 0
    preference_count: int = 0
    exchange_count: int = 0
    created_at: datetime = Field(default_factory=datetime.utcnow)
    # Embedding stored separately in Neo4j as node property


# ─── Task & Sprint (Agent Coordination) ──────────────────────────────────────


class TaskStatus(str, Enum):
    backlog     = "backlog"
    todo        = "todo"
    in_progress = "in_progress"
    blocked     = "blocked"
    review      = "review"
    done        = "done"
    cancelled   = "cancelled"


class TaskPriority(str, Enum):
    critical = "critical"
    high     = "high"
    medium   = "medium"
    low      = "low"


class SprintStatus(str, Enum):
    planning  = "planning"
    active    = "active"
    completed = "completed"
    cancelled = "cancelled"


class Task(BaseModel):
    """
    A discrete unit of work assigned to an agent or human.
    Tasks live within a Project, optionally within a Sprint.
    Edges: ASSIGNED_TO (agent), BELONGS_TO (project), IN_SPRINT (sprint),
           BLOCKED_BY (task), DEPENDS_ON (task), RELATES_TO (decision/constraint).
    """
    id: str = Field(default_factory=lambda: f"tsk_{uuid.uuid4().hex[:8]}")
    title: str
    description: str = ""
    status: TaskStatus = TaskStatus.todo
    priority: TaskPriority = TaskPriority.medium
    assignee: str = ""                  # agent_id or user_id
    project_id: Optional[str] = None
    sprint_id: Optional[str] = None
    tenant_id: str = "default"
    tags: list[str] = Field(default_factory=list)
    # Tracking
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    due_date: Optional[datetime] = None
    created_by: str = "user"            # who created the task
    # Links to memory graph
    related_decision_ids: list[str] = Field(default_factory=list)
    blocked_by_ids: list[str] = Field(default_factory=list)
    # Estimation
    estimate_hours: Optional[float] = None
    actual_hours: Optional[float] = None


class Sprint(BaseModel):
    """
    A time-boxed iteration grouping tasks.
    Sprints belong to a Project. Tasks are linked via IN_SPRINT edges.
    """
    id: str = Field(default_factory=lambda: f"spr_{uuid.uuid4().hex[:8]}")
    name: str                           # e.g. "Sprint 26" or "Auth Hardening"
    description: str = ""
    status: SprintStatus = SprintStatus.planning
    project_id: Optional[str] = None
    tenant_id: str = "default"
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    goal: str = ""                      # sprint objective


class CommunicationEvent(BaseModel):
    """
    An inter-agent or agent-human message logged for coordination audit.
    Captures who said what to whom during multi-agent collaboration.
    """
    id: str = Field(default_factory=lambda: f"com_{uuid.uuid4().hex[:8]}")
    sender: str                         # agent_id or user_id
    recipient: str                      # agent_id, user_id, or "broadcast"
    message: str
    message_type: str = "info"          # info | request | response | decision | handoff
    task_id: Optional[str] = None       # related task
    project_id: Optional[str] = None
    tenant_id: str = "default"
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


# ─── Encoder Output ───────────────────────────────────────────────────────────

class ClassificationResult(BaseModel):
    """
    Output of the encoder for a single exchange span.
    May produce zero or multiple graph nodes.
    """
    exchange_record: ExchangeRecord
    nodes: list[Decision | Attempt | Constraint | Preference] = Field(
        default_factory=list
    )
    edges: list[Edge] = Field(default_factory=list)
    should_encode: bool              # False if below threshold or ambiguous
    classifier_reasoning: str = ""  # LLM's explanation for the classification
