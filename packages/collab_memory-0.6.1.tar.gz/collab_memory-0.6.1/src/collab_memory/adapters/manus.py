"""
adapters/manus.py — collab-memory adapter for Manus agent sessions.

Fetches completed Manus tasks and converts the conversation output
(instructions + agent responses) into collab-memory turns for ingestion.

Usage:
    from collab_memory.adapters.manus import ManusAdapter

    adapter = ManusAdapter(api_key="sk-...")
    # List all your completed tasks
    tasks = adapter.list_tasks(limit=20, status="completed")
    for task in tasks:
        print(task["id"], task["metadata"].get("task_title"))

    # Convert one task to memory turns
    turns = adapter.get_turns(task_id="task_abc123")
    print(turns)
    # ["USER: <prompt>", "AGENT: <response>", ...]

    # Or: convert a task and ingest directly
    from collab_memory import CollabMemory
    memory = CollabMemory()
    adapter.ingest_task(task_id="task_abc123", memory=memory)

CLI:
    python -m collab_memory.adapters.manus --task-id <id>
    python -m collab_memory.adapters.manus --list --limit 10
    python -m collab_memory.adapters.manus --list --ingest-all
"""

from __future__ import annotations

import os
import json
from typing import Any

import requests

_BASE_URL = "https://api.manus.ai/v1"
_COMPLETED_STATUSES = {"completed"}
_TEXT_CONTENT_TYPE = "output_text"


def _client(api_key: str) -> dict:
    """Return default headers for Manus API requests."""
    return {
        "accept": "application/json",
        "content-type": "application/json",
        "API_KEY": api_key,
    }


class ManusAdapter:
    """
    Adapter for importing Manus agent task histories into collab-memory.

    Manus tasks have:
      - instructions: the user's original prompt
      - output[]:    array of messages with role ("user" | "assistant") + content
      - metadata:    task_title, task_url

    We map:
      USER turn  → instructions (task prompt)
      AGENT turns → output messages where role == "assistant" (text only)
    """

    def __init__(self, api_key: str | None = None):
        self.api_key = api_key or os.environ.get("MANUS_API_KEY", "")
        if not self.api_key:
            raise ValueError(
                "Manus API key required. Pass api_key= or set MANUS_API_KEY env var."
            )
        self._headers = _client(self.api_key)

    # ─── List Tasks ───────────────────────────────────────────────────────────

    def list_tasks(
            self,
            limit: int = 20,
            status: str | list[str] | None = None,
            project_id: str | None = None,
            query: str | None = None,
            created_after: int | None = None,
            created_before: int | None = None,
            order: str = "desc",
            order_by: str = "created_at",
            after: str | None = None,
            all_pages: bool = False,
    ) -> list[dict]:
        """
        List Manus tasks with full filtering support.

        Args:
            limit:          Max tasks per page (1-1000, default 20).
            status:         Filter by status string or list of strings.
                            Values: "pending", "running", "completed", "failed".
            project_id:     Filter by project.
            query:          Search by title or content.
            created_after:  Unix timestamp — only tasks created after this time.
            created_before: Unix timestamp — only tasks created before this time.
            order:          Sort direction: "desc" (newest first) or "asc".
            order_by:       Sort field: "created_at" or "updated_at".
            after:          Pagination cursor (last_id from previous page).
            all_pages:      If True, auto-paginate and return all matching tasks.

        Returns:
            List of task dicts with id, status, metadata, created_at.
        """
        params: dict[str, Any] = {
            "limit": limit,
            "order": order,
            "order_by": order_by,
        }
        if status:
            params["status"] = status  # API accepts array or string
        if project_id:
            params["project_id"] = project_id
        if query:
            params["query"] = query
        if created_after:
            params["created_after"] = created_after
        if created_before:
            params["created_before"] = created_before
        if after:
            params["after"] = after

        results: list[dict] = []
        while True:
            r = requests.get(f"{_BASE_URL}/tasks", headers=self._headers, params=params)
            r.raise_for_status()
            data = r.json()

            if isinstance(data, list):
                results.extend(data)
                break

            page = data.get("data", data.get("tasks", []))
            results.extend(page)

            if not all_pages or not data.get("has_more"):
                break
            # Advance cursor for next page
            params["after"] = data.get("last_id")

        return results

    # ─── Get Single Task ──────────────────────────────────────────────────────

    def get_task(self, task_id: str) -> dict:
        """
        Fetch full task details including conversation output.

        Returns the raw Manus task object with:
          id, status, instructions, output[], metadata, created_at, updated_at
        """
        r = requests.get(
            f"{_BASE_URL}/tasks/{task_id}",
            headers=self._headers,
        )
        r.raise_for_status()
        return r.json()

    # ─── Convert to Turns ────────────────────────────────────────────────────

    def get_turns(self, task_id: str) -> list[str]:
        """
        Fetch a Manus task and return its conversation as collab-memory turns.

        Turn format:
          "USER: <instructions>"
          "AGENT: <assistant message text>"

        Only text content is included. File/image outputs are noted as
        "[file: filename.ext]" placeholders.
        """
        task = self.get_task(task_id)
        return self._task_to_turns(task)

    def turns_from_task(self, task: dict) -> list[str]:
        """
        Convert an already-fetched task dict to collab-memory turns.
        Use this if you already have the task object from list_tasks or get_task.
        """
        return self._task_to_turns(task)

    def _task_to_turns(self, task: dict) -> list[str]:
        turns: list[str] = []

        # The user's original prompt becomes the first USER turn
        instructions = (task.get("instructions") or "").strip()
        if instructions:
            turns.append(f"USER: {instructions}")

        # Walk the output messages
        output = task.get("output") or []
        for msg in output:
            role = (msg.get("role") or "").lower()
            content_blocks = msg.get("content") or []
            text_parts: list[str] = []

            for block in content_blocks:
                if block.get("type") == _TEXT_CONTENT_TYPE:
                    text = (block.get("text") or "").strip()
                    if text:
                        text_parts.append(text)
                elif block.get("fileName"):
                    text_parts.append(f"[file: {block['fileName']}]")

            if not text_parts:
                continue

            combined = " ".join(text_parts)
            if role == "user":
                turns.append(f"USER: {combined}")
            elif role == "assistant":
                turns.append(f"AGENT: {combined}")
            else:
                # fallback — keep content attributed
                turns.append(f"{role.upper() or 'AGENT'}: {combined}")

        return turns

    # ─── Ingest into CollabMemory ─────────────────────────────────────────────

    def ingest_task(self, task_id: str, memory: Any) -> dict:
        """
        Fetch a Manus task and push all turns into a CollabMemory instance.

        Args:
            task_id: The Manus task ID.
            memory:  A CollabMemory instance (or any object with push_turn()).

        Returns:
            Dict with task metadata and turn count.
        """
        task = self.get_task(task_id)
        turns = self._task_to_turns(task)
        title = (task.get("metadata") or {}).get("task_title", task_id)

        for turn in turns:
            memory.push_turn(turn)

        return {
            "task_id": task_id,
            "task_title": title,
            "task_status": task.get("status"),
            "turns_pushed": len(turns),
        }

    def ingest_all_tasks(
            self,
            memory: Any,
            limit: int = 50,
            status: str = "completed",
            skip_empty: bool = True,
    ) -> list[dict]:
        """
        Fetch and ingest all (completed) Manus tasks into memory.

        Args:
            skip_empty: Skip tasks with no instructions/output (e.g. auto-spawned
                        sub-tasks like "Wide Research Subtask"). Default True.

        Returns a list of per-task ingestion results.
        """
        tasks = self.list_tasks(limit=limit, status=status)
        results = []
        for task in tasks:
            try:
                # Skip programmatically-spawned sub-tasks with no user prompt
                if skip_empty and not (task.get("instructions") or "").strip():
                    full_task = self.get_task(task["id"])
                    has_output = any(
                        block.get("text", "").strip()
                        for msg in (full_task.get("output") or [])
                        for block in (msg.get("content") or [])
                    )
                    if not has_output:
                        title = (task.get("metadata") or {}).get("task_title", task["id"])
                        print(f"  ↷ Skipping empty sub-task: {title[:50]}")
                        continue

                result = self.ingest_task(task["id"], memory)
                if result["turns_pushed"] == 0 and skip_empty:
                    print(f"  ↷ Skipping (no turns): {result['task_title'][:50]}")
                    continue
                results.append(result)
                print(f"  ✓ {result['task_title'][:60]} ({result['turns_pushed']} turns)")
            except Exception as e:
                print(f"  ✗ {task.get('id')} — {e}")
                results.append({"task_id": task.get("id"), "error": str(e)})
        return results


# ─── Convenience functions ────────────────────────────────────────────────────

def parse_manus_task(task_id: str, api_key: str | None = None) -> list[str]:
    """Fetch a single Manus task and return its turns. Quick helper."""
    return ManusAdapter(api_key=api_key).get_turns(task_id)


def list_manus_tasks(
        limit: int = 20,
        status: str = "completed",
        api_key: str | None = None,
) -> list[dict]:
    """List Manus tasks. Quick helper."""
    return ManusAdapter(api_key=api_key).list_tasks(limit=limit, status=status)


# ─── CLI ─────────────────────────────────────────────────────────────────────

def main():
    import argparse

    parser = argparse.ArgumentParser(
        description="Manus → collab-memory adapter",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python -m collab_memory.adapters.manus --list
  python -m collab_memory.adapters.manus --list --limit 5 --status completed
  python -m collab_memory.adapters.manus --task-id task_abc123
  python -m collab_memory.adapters.manus --list --ingest-all
        """,
    )
    parser.add_argument("--api-key", default=os.environ.get("MANUS_API_KEY"),
                        help="Manus API key (or set MANUS_API_KEY env var)")
    parser.add_argument("--task-id", help="Fetch and print turns for a specific task")
    parser.add_argument("--list", action="store_true", help="List tasks")
    parser.add_argument("--limit", type=int, default=20, help="Max tasks to list")
    parser.add_argument("--status", default="completed",
                        help="Task status filter: pending/running/completed/failed")
    parser.add_argument("--ingest-all", action="store_true",
                        help="Ingest all listed tasks into local memory graph")
    parser.add_argument("--graph-path", default="./data/memory.json",
                        help="Path to local memory graph JSON")
    args = parser.parse_args()

    if not args.api_key:
        parser.error("API key required — pass --api-key or set MANUS_API_KEY")

    adapter = ManusAdapter(api_key=args.api_key)

    if args.task_id:
        turns = adapter.get_turns(args.task_id)
        print(f"\n{len(turns)} turns from task {args.task_id}:\n")
        for turn in turns:
            prefix = turn[:6]
            print(f"  {prefix}  {turn[7:100]}{'…' if len(turn) > 107 else ''}")
        return

    if args.list:
        tasks = adapter.list_tasks(limit=args.limit, status=args.status)
        print(f"\n{len(tasks)} {args.status} tasks:\n")
        for t in tasks:
            title = (t.get("metadata") or {}).get("task_title", "(no title)")
            print(f"  {t['id']}  {title[:60]}")

        if args.ingest_all:
            from collab_memory import CollabMemory
            memory = CollabMemory(graph_path=args.graph_path)
            print(f"\nIngesting into {args.graph_path}...\n")
            results = adapter.ingest_all_tasks(memory=memory, limit=args.limit, status=args.status)
            memory.flush()
            memory.save()
            ok = sum(1 for r in results if "error" not in r)
            turns_total = sum(r.get("turns_pushed", 0) for r in results)
            print(f"\n✓ {ok}/{len(results)} tasks ingested, {turns_total} total turns")
        return

    parser.print_help()


if __name__ == "__main__":
    main()
