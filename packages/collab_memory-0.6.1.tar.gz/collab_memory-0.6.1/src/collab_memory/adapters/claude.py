"""
adapters/claude.py — Claude conversation export parser.

Converts a Claude.ai JSON export into encoder-ready turn strings.

Export instructions:
  Claude.ai → Settings → Privacy & Data → Export your data
  Download → find conversations.json (or individual conversation files)

Usage:
    from collab_memory.adapters.claude import parse_claude_export
    turns = parse_claude_export("claude_export.json", conversation_id="abc123")
    results = encode_session(turns, session_id="claude_proj_001")
"""

from __future__ import annotations
import json
from pathlib import Path


def parse_claude_export(
    path: str,
    conversation_id: str | None = None,
    conversation_title: str | None = None,
    max_turns: int | None = None,
) -> list[str]:
    """
    Parse a Claude.ai export into turn strings.

    Claude exports come in two possible formats:
    1. A list of conversation objects (bulk export)
    2. A single conversation object

    Args:
        path: Path to the Claude export JSON file.
        conversation_id: Filter to a specific conversation by UUID.
        conversation_title: Filter by title substring.
        max_turns: Cap on number of turns returned.

    Returns:
        List of "USER: ..." / "AGENT: ..." strings ready for encode_session().
    """
    raw = json.loads(Path(path).read_text())

    # Normalize to list
    conversations = raw if isinstance(raw, list) else [raw]

    # Filter
    if conversation_id:
        conversations = [c for c in conversations if c.get("uuid") == conversation_id or c.get("id") == conversation_id]
    elif conversation_title:
        conversations = [
            c for c in conversations
            if conversation_title.lower() in (c.get("name") or c.get("title") or "").lower()
        ]

    turns = []
    for conv in conversations:
        messages = conv.get("chat_messages") or conv.get("messages") or []
        for msg in messages:
            role = msg.get("sender") or msg.get("role") or ""
            # Extract text content
            content = _extract_content(msg)
            if not content or not content.strip():
                continue

            if role in ("human", "user"):
                turns.append(f"USER: {content.strip()}")
            elif role in ("assistant", "claude"):
                turns.append(f"AGENT: {content.strip()}")

    if max_turns:
        turns = turns[-max_turns:]

    return turns


def _extract_content(msg: dict) -> str:
    """Extract text from a Claude message, handling multiple content formats."""
    # Direct text field
    if "text" in msg:
        return str(msg["text"])

    # Content array (newer Claude format)
    content = msg.get("content", [])
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        texts = []
        for block in content:
            if isinstance(block, dict) and block.get("type") == "text":
                texts.append(block.get("text", ""))
            elif isinstance(block, str):
                texts.append(block)
        return " ".join(texts)

    return ""


def list_conversations(path: str) -> list[dict]:
    """List available conversations in an export file."""
    raw = json.loads(Path(path).read_text())
    conversations = raw if isinstance(raw, list) else [raw]
    return [
        {
            "id": c.get("uuid") or c.get("id", ""),
            "title": c.get("name") or c.get("title", "(untitled)"),
            "message_count": len(c.get("chat_messages") or c.get("messages") or []),
        }
        for c in conversations
    ]
