"""
adapters/__init__.py
"""
from .chatgpt import parse_chatgpt_export
from .claude import parse_claude_export
from .linear import parse_linear_issues, list_teams as list_linear_teams
from .manus import ManusAdapter, parse_manus_task, list_manus_tasks
from .github import GitHubAdapter

__all__ = [
    "parse_chatgpt_export",
    "parse_claude_export",
    "parse_linear_issues",
    "list_linear_teams",
    "ManusAdapter",
    "parse_manus_task",
    "list_manus_tasks",
    "GitHubAdapter",
]
