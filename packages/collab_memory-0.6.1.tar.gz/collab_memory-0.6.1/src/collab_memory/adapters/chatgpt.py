"""
adapters/chatgpt.py — ChatGPT conversation export parser.

Converts a ChatGPT JSON export into encoder-ready turn strings.

Export instructions:
  ChatGPT → Settings → Data Controls → Export Data
  Download the zip → extract → find conversations.json

Usage:
    from collab_memory.adapters.chatgpt import parse_chatgpt_export
    turns = parse_chatgpt_export("conversations.json", title="My Project Build")
    results = encode_session(turns, session_id="chatgpt_proj_001")
"""

from __future__ import annotations
import json
from pathlib import Path


def parse_chatgpt_export(
    path: str,
    conversation_title: str | None = None,
    conversation_id: str | None = None,
    max_turns: int | None = None,
) -> list[str]:
    """
    Parse a ChatGPT conversations.json export into turn strings.

    Args:
        path: Path to conversations.json from ChatGPT export zip.
        conversation_title: Filter to a specific conversation by title substring.
        conversation_id: Filter to a specific conversation by ID.
        max_turns: Cap on number of turns to return (most recent if capped).

    Returns:
        List of "USER: ..." / "AGENT: ..." strings ready for encode_session().
    """
    raw = json.loads(Path(path).read_text())

    # conversations.json is a list of conversation objects
    conversations = raw if isinstance(raw, list) else [raw]

    # Filter if requested
    if conversation_id:
        conversations = [c for c in conversations if c.get("id") == conversation_id]
    elif conversation_title:
        conversations = [
            c for c in conversations
            if conversation_title.lower() in (c.get("title") or "").lower()
        ]

    turns = []
    for conv in conversations:
        mapping = conv.get("mapping", {})
        # Traverse message tree in order
        messages = _flatten_message_tree(mapping)
        for msg in messages:
            role = msg.get("author", {}).get("role", "")
            content = _extract_text(msg.get("content", {}))
            if not content or not content.strip():
                continue
            if role == "user":
                turns.append(f"USER: {content.strip()}")
            elif role == "assistant":
                turns.append(f"AGENT: {content.strip()}")
            # system messages skipped

    if max_turns:
        turns = turns[-max_turns:]

    return turns


def _flatten_message_tree(mapping: dict) -> list[dict]:
    """Walk the ChatGPT message tree and return messages in conversation order."""
    # Find root (message with no parent or parent not in mapping)
    root_id = None
    parent_map = {}
    for node_id, node in mapping.items():
        parent = node.get("parent")
        if parent and parent in mapping:
            parent_map[node_id] = parent
        else:
            root_id = node_id

    if not root_id:
        return []

    # Build children map
    children: dict[str, list[str]] = {}
    for node_id, parent_id in parent_map.items():
        children.setdefault(parent_id, []).append(node_id)

    # DFS traversal
    result = []
    stack = [root_id]
    while stack:
        node_id = stack.pop(0)
        node = mapping.get(node_id, {})
        msg = node.get("message")
        if msg:
            result.append(msg)
        # Add children (take last child = newest branch)
        node_children = children.get(node_id, [])
        stack = node_children[-1:] + stack  # depth-first, prefer last branch

    return result


def _extract_text(content: dict) -> str:
    """Extract plain text from a ChatGPT content block."""
    if isinstance(content, str):
        return content
    if isinstance(content, dict):
        content_type = content.get("content_type", "")
        if content_type == "text":
            parts = content.get("parts", [])
            return " ".join(str(p) for p in parts if p)
    return ""


def list_conversations(path: str) -> list[dict]:
    """List available conversations in an export file."""
    raw = json.loads(Path(path).read_text())
    conversations = raw if isinstance(raw, list) else [raw]
    return [
        {
            "id": c.get("id", ""),
            "title": c.get("title", "(untitled)"),
            "message_count": len(c.get("mapping", {})),
        }
        for c in conversations
    ]
