"""
collab_memory/auth/saml_sp.py — SAML 2.0 Service Provider

Embeds a SAML SP directly into the FastAPI app using python3-saml.
No external IdP service required — this handles the SP side of the
SAML handshake, receiving assertions from customer IdPs (Okta, Azure AD,
Google Workspace).

Architecture:
    Customer's IdP (Okta/AzureAD/Google) ←→ This SAML SP ←→ jwt_provider.py

Flow:
    1. User hits /sso/saml/login?org=<org_slug>
    2. We redirect to their IdP's SSO URL with a SAML AuthnRequest
    3. IdP authenticates user, POSTs SAML assertion to /sso/saml/acs
    4. We validate assertion, extract email/attributes
    5. Find-or-create user in Neo4j via jwt_provider
    6. Issue our JWT tokens, redirect to dashboard

Multi-tenant config:
    Each organization stores its SAML config (IdP metadata) as a
    SSOConfig node in Neo4j. The org_slug in the login URL determines
    which IdP to redirect to.

Research sprint: Session 27 (2026-04-01)
    - python3-saml v1.16.0, MIT license
    - Validated: imports clean, xmlsec 1.3.17 works on macOS + Linux
    - Needs testing: Okta, Azure AD, Google Workspace sandboxes
"""
from __future__ import annotations

import json
import logging
import os
import time
from typing import Optional
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


@dataclass
class SSOConfig:
    """SAML configuration for a single organization/tenant."""
    org_slug: str                    # URL-safe identifier (e.g., "acme-corp")
    tenant_id: str                   # Maps to our tenant system
    idp_entity_id: str               # IdP's entity ID
    idp_sso_url: str                 # IdP's SSO login URL
    idp_slo_url: str = ""            # IdP's Single Logout URL (optional)
    idp_x509_cert: str = ""          # IdP's signing certificate (PEM, no headers)
    attribute_map: dict = field(default_factory=lambda: {
        "email": "email",            # SAML attribute name → our field
        "first_name": "firstName",
        "last_name": "lastName",
        "role": "role",
    })
    enabled: bool = True
    created_at: float = 0.0


class SAMLServiceProvider:
    """
    SAML 2.0 Service Provider backed by python3-saml.

    Handles:
    - AuthnRequest generation (SP-initiated login)
    - Assertion Consumer Service (validate IdP response)
    - SP metadata generation
    - Multi-tenant config storage in Neo4j
    """

    def __init__(self, neo4j_backend=None):
        self._neo4j = neo4j_backend
        self._configs: dict[str, SSOConfig] = {}  # In-memory cache

        # SP identity — set via env or derived from public URL
        self._sp_entity_id = os.environ.get(
            "SAML_SP_ENTITY_ID",
            os.environ.get("COLLAB_PUBLIC_URL", "http://localhost:8784")
        )
        self._sp_acs_url = f"{self._sp_entity_id}/sso/saml/acs"
        self._sp_slo_url = f"{self._sp_entity_id}/sso/saml/slo"
        self._sp_metadata_url = f"{self._sp_entity_id}/sso/saml/metadata"

        # SP signing key (optional — for signed AuthnRequests)
        self._sp_cert = os.environ.get("SAML_SP_CERT", "")
        self._sp_key = os.environ.get("SAML_SP_KEY", "")

        logger.info("SAML SP initialized (entity_id=%s)", self._sp_entity_id)

    def get_config(self, org_slug: str) -> Optional[SSOConfig]:
        """Load SAML config for an organization."""
        # Memory cache first
        if org_slug in self._configs:
            return self._configs[org_slug]

        # Neo4j lookup
        if self._neo4j:
            try:
                rows = self._neo4j._tx_read(
                    "MATCH (s:SSOConfig {org_slug: $slug, enabled: true}) RETURN s {.*} AS config",
                    slug=org_slug,
                )
                if rows:
                    data = rows[0]["config"]
                    config = SSOConfig(
                        org_slug=data.get("org_slug", org_slug),
                        tenant_id=data.get("tenant_id", ""),
                        idp_entity_id=data.get("idp_entity_id", ""),
                        idp_sso_url=data.get("idp_sso_url", ""),
                        idp_slo_url=data.get("idp_slo_url", ""),
                        idp_x509_cert=data.get("idp_x509_cert", ""),
                        attribute_map=json.loads(data.get("attribute_map", "{}")),
                        enabled=data.get("enabled", True),
                        created_at=data.get("created_at", 0),
                    )
                    self._configs[org_slug] = config
                    return config
            except Exception as e:
                logger.warning("SAML config lookup failed for %s: %s", org_slug, e)

        return None

    def save_config(self, config: SSOConfig) -> None:
        """Store SAML config in Neo4j."""
        if not self._neo4j:
            self._configs[config.org_slug] = config
            return

        self._neo4j._tx_write(
            """
            MERGE (s:SSOConfig {org_slug: $slug})
            SET s.tenant_id      = $tenant_id,
                s.idp_entity_id  = $entity_id,
                s.idp_sso_url    = $sso_url,
                s.idp_slo_url    = $slo_url,
                s.idp_x509_cert  = $cert,
                s.attribute_map  = $attr_map,
                s.enabled        = $enabled,
                s.created_at     = COALESCE(s.created_at, $now),
                s.updated_at     = $now
            """,
            slug=config.org_slug,
            tenant_id=config.tenant_id,
            entity_id=config.idp_entity_id,
            sso_url=config.idp_sso_url,
            slo_url=config.idp_slo_url,
            cert=config.idp_x509_cert,
            attr_map=json.dumps(config.attribute_map),
            enabled=config.enabled,
            now=time.time(),
        )
        self._configs[config.org_slug] = config
        logger.info("SAML config saved for org=%s", config.org_slug)

    def _build_saml_settings(self, config: SSOConfig) -> dict:
        """Build the python3-saml settings dict for a specific org."""
        return {
            "strict": True,
            "debug": os.environ.get("SAML_DEBUG", "false").lower() == "true",
            "sp": {
                "entityId": self._sp_entity_id,
                "assertionConsumerService": {
                    "url": self._sp_acs_url,
                    "binding": "urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST",
                },
                "singleLogoutService": {
                    "url": self._sp_slo_url,
                    "binding": "urn:oasis:names:tc:SAML:2.0:bindings:HTTP-Redirect",
                },
                "NameIDFormat": "urn:oasis:names:tc:SAML:1.1:nameid-format:emailAddress",
                "x509cert": self._sp_cert,
                "privateKey": self._sp_key,
            },
            "idp": {
                "entityId": config.idp_entity_id,
                "singleSignOnService": {
                    "url": config.idp_sso_url,
                    "binding": "urn:oasis:names:tc:SAML:2.0:bindings:HTTP-Redirect",
                },
                "singleLogoutService": {
                    "url": config.idp_slo_url,
                    "binding": "urn:oasis:names:tc:SAML:2.0:bindings:HTTP-Redirect",
                } if config.idp_slo_url else {},
                "x509cert": config.idp_x509_cert,
            },
            "security": {
                "nameIdEncrypted": False,
                "authnRequestsSigned": bool(self._sp_key),
                "logoutRequestSigned": bool(self._sp_key),
                "logoutResponseSigned": bool(self._sp_key),
                "signMetadata": bool(self._sp_key),
                "wantMessagesSigned": True,
                "wantAssertionsSigned": True,
                "wantNameIdEncrypted": False,
                "wantAssertionsEncrypted": False,
                "wantAttributeStatement": True,
                # Reject assertions older than 5 minutes
                "rejectDeprecatedAlgorithm": True,
                "allowRepeatAttributeName": True,
            },
        }

    def prepare_request(self, request_data: dict) -> dict:
        """
        Prepare a python3-saml-compatible request dict from FastAPI request.

        python3-saml expects a specific dict format, not a raw ASGI request.
        This bridges the gap.
        """
        return {
            "https": "on" if request_data.get("scheme") == "https" else "off",
            "http_host": request_data.get("host", "localhost"),
            "script_name": request_data.get("path", ""),
            "get_data": request_data.get("get_data", {}),
            "post_data": request_data.get("post_data", {}),
            "server_port": request_data.get("port", 443),
        }

    def initiate_login(self, config: SSOConfig, request_data: dict) -> tuple[str, Optional[str]]:
        """
        Generate SAML AuthnRequest and return the redirect URL.

        Returns:
            (redirect_url, request_id) — redirect user to this URL
        """
        from onelogin.saml2.auth import OneLogin_Saml2_Auth

        settings = self._build_saml_settings(config)
        prepared = self.prepare_request(request_data)
        auth = OneLogin_Saml2_Auth(prepared, settings)

        redirect_url = auth.login()
        request_id = auth.get_last_request_id()

        logger.info("SAML login initiated for org=%s, request_id=%s", config.org_slug, request_id)
        return redirect_url, request_id

    def process_response(
        self, config: SSOConfig, request_data: dict
    ) -> tuple[bool, Optional[dict], list[str]]:
        """
        Validate SAML assertion from IdP and extract user attributes.

        Returns:
            (success, user_attrs, errors)
            user_attrs: {"email": ..., "first_name": ..., "last_name": ..., ...}
        """
        from onelogin.saml2.auth import OneLogin_Saml2_Auth

        settings = self._build_saml_settings(config)
        prepared = self.prepare_request(request_data)
        auth = OneLogin_Saml2_Auth(prepared, settings)

        auth.process_response()
        errors = auth.get_errors()

        if errors:
            logger.warning(
                "SAML assertion validation failed for org=%s: %s (reason: %s)",
                config.org_slug, errors, auth.get_last_error_reason(),
            )
            return False, None, errors

        if not auth.is_authenticated():
            logger.warning("SAML assertion not authenticated for org=%s", config.org_slug)
            return False, None, ["User not authenticated"]

        # Extract attributes using the org's attribute map
        attrs = auth.get_attributes()
        name_id = auth.get_nameid()
        attr_map = config.attribute_map

        user_attrs = {
            "email": name_id,  # NameID is typically the email
            "name_id": name_id,
            "session_index": auth.get_session_index(),
            "org_slug": config.org_slug,
            "tenant_id": config.tenant_id,
        }

        # Map IdP attributes to our fields
        for our_field, idp_field in attr_map.items():
            values = attrs.get(idp_field, [])
            if values:
                user_attrs[our_field] = values[0] if len(values) == 1 else values

        # If email wasn't in NameID, try the attribute map
        if not user_attrs.get("email") or "@" not in str(user_attrs.get("email", "")):
            email_from_attrs = attrs.get(attr_map.get("email", "email"), [])
            if email_from_attrs:
                user_attrs["email"] = email_from_attrs[0]

        logger.info(
            "SAML assertion validated for org=%s, email=%s",
            config.org_slug, user_attrs.get("email"),
        )
        return True, user_attrs, []

    def get_metadata(self) -> str:
        """Generate SP metadata XML for IdP configuration."""
        from onelogin.saml2.settings import OneLogin_Saml2_Settings

        # Use a minimal config — metadata doesn't need IdP details
        settings_dict = {
            "strict": True,
            "sp": {
                "entityId": self._sp_entity_id,
                "assertionConsumerService": {
                    "url": self._sp_acs_url,
                    "binding": "urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST",
                },
                "singleLogoutService": {
                    "url": self._sp_slo_url,
                    "binding": "urn:oasis:names:tc:SAML:2.0:bindings:HTTP-Redirect",
                },
                "NameIDFormat": "urn:oasis:names:tc:SAML:1.1:nameid-format:emailAddress",
                "x509cert": self._sp_cert,
                "privateKey": self._sp_key,
            },
            "idp": {
                "entityId": "https://placeholder.example.com",
                "singleSignOnService": {
                    "url": "https://placeholder.example.com/sso",
                    "binding": "urn:oasis:names:tc:SAML:2.0:bindings:HTTP-Redirect",
                },
            },
        }

        settings = OneLogin_Saml2_Settings(settings_dict, sp_validation_only=True)
        metadata = settings.get_sp_metadata()
        errors = settings.validate_metadata(metadata)

        if errors:
            logger.warning("SP metadata validation errors: %s", errors)

        return metadata.decode("utf-8") if isinstance(metadata, bytes) else metadata
