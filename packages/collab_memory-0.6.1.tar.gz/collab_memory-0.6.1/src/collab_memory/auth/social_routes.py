"""
collab_memory/auth/social_routes.py — Social Login API Routes

Routes:
    GET  /auth/social/providers        — List configured social login providers
    GET  /auth/social/{provider}/login — Redirect to OAuth provider
    GET  /auth/social/{provider}/callback — OAuth callback (provider redirects here)
"""
from __future__ import annotations

import logging
import uuid
from typing import Optional

from urllib.parse import quote, urlencode

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import RedirectResponse

from collab_memory.auth.jwt_provider import normalize_email

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/auth/social", tags=["social-auth"])

# Module-level OAuth client — initialized lazily
_oauth = None


# ── Social Identity helpers ────────────────────────────────────────────────

def _find_user_by_social_identity(auth_client, provider: str, provider_user_id: str) -> Optional[dict]:
    """Look up a user by their linked social identity (SocialIdentity → LINKED_VIA → User)."""
    if not provider_user_id or not auth_client._neo4j:
        return None
    try:
        rows = auth_client._neo4j._tx_read(
            """
            MATCH (si:SocialIdentity {provider: $provider, provider_user_id: $pid})
                  -[:LINKED_VIA]->(u:User)
            RETURN u.user_id AS user_id, u.email AS email,
                   u.tenant_id AS tenant_id, u.plan AS plan, u.role AS role
            """,
            provider=provider, pid=provider_user_id,
        )
        if rows:
            return dict(rows[0])
    except Exception as e:
        logger.warning("Social identity lookup failed: %s", e)
    return None


def _create_social_identity(auth_client, user_id: str, profile: dict) -> None:
    """Create a SocialIdentity node and LINKED_VIA edge to the User."""
    if not auth_client._neo4j:
        return
    from datetime import datetime, timezone
    now = datetime.now(timezone.utc).isoformat()
    try:
        auth_client._neo4j._tx_write(
            """
            MERGE (si:SocialIdentity {provider: $provider, provider_user_id: $pid})
            SET si.email = $email,
                si.email_verified = $verified,
                si.display_name = $name,
                si.avatar_url = $avatar,
                si.profile_url = $profile_url,
                si.linked_at = $now,
                si.last_login = $now
            WITH si
            MATCH (u:User {user_id: $uid})
            MERGE (si)-[:LINKED_VIA]->(u)
            """,
            provider=profile.get("provider", ""),
            pid=profile.get("provider_user_id", ""),
            email=profile.get("email", ""),
            verified=profile.get("email_verified", False),
            name=profile.get("display_name", ""),
            avatar=profile.get("avatar_url", ""),
            profile_url=profile.get("profile_url", ""),
            uid=user_id,
            now=now,
        )
    except Exception as e:
        logger.warning("Failed to create social identity: %s", e)


def _update_social_login_time(auth_client, provider: str, provider_user_id: str) -> None:
    """Bump last_login on an existing SocialIdentity."""
    if not auth_client._neo4j:
        return
    from datetime import datetime, timezone
    try:
        auth_client._neo4j._tx_write(
            "MATCH (si:SocialIdentity {provider: $p, provider_user_id: $pid}) SET si.last_login = $now",
            p=provider, pid=provider_user_id, now=datetime.now(timezone.utc).isoformat(),
        )
    except Exception:
        pass


def _issue_tokens(auth_client, user: dict) -> tuple[str | None, str | None]:
    """Issue access + refresh tokens (same as password login — dashboard needs both)."""
    base = auth_client._find_user_by_email(user.get("email", "")) or user
    prepared = auth_client.prepare_user_for_session({**base})
    if not prepared:
        return None, None
    access_token = auth_client._create_token(
        prepared["user_id"], prepared["email"], prepared["tenant_id"],
        prepared.get("plan", "free"), prepared.get("role", "contributor"),
        auth_client._access_ttl,
    )
    refresh_token = auth_client._create_token(
        prepared["user_id"], prepared["email"], prepared["tenant_id"],
        prepared.get("plan", "free"), prepared.get("role", "contributor"),
        auth_client._refresh_ttl, is_refresh=True,
    )
    return access_token, refresh_token


def _get_oauth():
    """Lazy-init the OAuth client."""
    global _oauth
    if _oauth is None:
        try:
            from collab_memory.auth.social import create_oauth_client
            _oauth = create_oauth_client()
        except ImportError:
            logger.warning("authlib not installed — social login disabled")
            return None
    return _oauth


def _get_callback_url(request: Request, provider: str) -> str:
    """Build the OAuth callback URL from the current request."""
    import os
    base = os.environ.get("COLLAB_PUBLIC_URL", "").rstrip("/")
    if not base:
        base = str(request.base_url).rstrip("/")
    return f"{base}/auth/social/{provider}/callback"


def _consume_oauth_return_base(request: Request) -> str:
    """Where to send the user after OAuth (dashboard). Pops optional session override."""
    import os
    base = request.session.pop("oauth_redirect", "").rstrip("/")
    if not base:
        base = os.environ.get("COLLAB_PUBLIC_URL", "").rstrip("/")
    if not base:
        base = str(request.base_url).rstrip("/")
    return base


def _social_error_redirect(request: Request, reason: str, message: str = "") -> RedirectResponse:
    """Browser-friendly OAuth failure — never leave users on a raw JSON error page."""
    base = _consume_oauth_return_base(request)
    frag = f"social=error&reason={quote(reason, safe='')}"
    if message:
        frag += f"&message={quote(message[:400], safe='')}"
    return RedirectResponse(url=f"{base}#{frag}", status_code=302)


@router.get("/providers", summary="List configured social login providers")
async def list_providers():
    """Return which social login providers are available."""
    from collab_memory.auth.social import get_configured_providers, is_social_available
    return {
        "social_login_available": is_social_available(),
        "providers": get_configured_providers(),
    }


@router.get("/{provider}/login", summary="Redirect to social login provider")
async def social_login(provider: str, request: Request, redirect: str = ""):
    """Initiate OAuth login — redirects user to GitHub or Google.
    
    Pass ?redirect=https://your-site.com/callback to control where
    the user lands after authentication. Without it, defaults to the
    collab-memory dashboard.
    """
    oauth = _get_oauth()
    if not oauth:
        raise HTTPException(status_code=503, detail="Social login not available (authlib not installed)")

    client = getattr(oauth, provider, None)
    if not client:
        raise HTTPException(
            status_code=404,
            detail=f"Provider '{provider}' not configured. Set {provider.upper()}_CLIENT_ID and {provider.upper()}_CLIENT_SECRET env vars.",
        )

    # Store redirect URL in session so callback can use it
    if redirect:
        request.session["oauth_redirect"] = redirect

    callback_url = _get_callback_url(request, provider)
    return await client.authorize_redirect(request, callback_url)


@router.get("/{provider}/callback", summary="OAuth callback handler")
async def social_callback(provider: str, request: Request):
    """Handle OAuth callback from provider.

    Exchanges code for tokens, fetches user email, finds-or-creates
    the user, issues our JWT, and redirects to dashboard.
    """
    oauth = _get_oauth()
    if not oauth:
        return _social_error_redirect(
            request,
            "unavailable",
            "Social login is not available on this server.",
        )

    client = getattr(oauth, provider, None)
    if not client:
        return _social_error_redirect(
            request,
            "not_configured",
            f"Sign-in with {provider} is not configured.",
        )

    try:
        token = await client.authorize_access_token(request)
    except Exception as e:
        logger.error("OAuth token exchange failed for %s: %s", provider, e)
        cb = _get_callback_url(request, provider)
        return _social_error_redirect(
            request,
            "oauth_failed",
            "Sign-in was cancelled or the OAuth redirect failed (wrong callback URL, expired state, or denied access). "
            f"Your app’s callback URL must exactly match: {cb} "
            "(set COLLAB_PUBLIC_URL on the server to your public origin).",
        )

    # Extract full profile with verification status
    profile = {}
    if provider == "github":
        from collab_memory.auth.social import fetch_github_profile
        profile = await fetch_github_profile(token)
    elif provider == "google":
        from collab_memory.auth.social import fetch_google_userinfo
        profile = await fetch_google_userinfo(token)

    # Canonical email so GitHub/Google matches the same User as password signup
    # (strip + lowercase — same as /auth/signup).
    email = normalize_email(profile.get("email") or "")
    if not email:
        if provider == "github":
            ne = (
                "GitHub did not return an email. Verify an address at https://github.com/settings/emails "
                "and ensure the OAuth app requests the user:email scope."
            )
        else:
            ne = f"{provider.title()} did not return an email for this account."
        return _social_error_redirect(request, "no_email", ne)
    profile = {**profile, "email": email}

    email_verified = profile.get("email_verified", False)
    provider_user_id = profile.get("provider_user_id", "")

    # Find or create user + link social identity
    #
    # Design: one human per canonical email when the IdP attests it (verified).
    # 1) Same GitHub/Google account → reuse via SocialIdentity (provider + provider_user_id).
    # 2) New IdP account but verified email matches existing User → auto-link (no duplicate).
    # 3) Email matches but IdP did not verify → 409 (avoid account takeover); use password + settings link.
    # 4) No match → signup + link SocialIdentity.
    access_token: str | None = None
    refresh_token: str | None = None
    try:
        from collab_memory.auth.middleware import get_auth_client
        auth_client = get_auth_client()

        # 1. Check if this social identity is already linked to a user
        linked_user = _find_user_by_social_identity(auth_client, provider, provider_user_id)

        if linked_user:
            # Known social identity → issue tokens for the linked user
            user = linked_user
            access_token, refresh_token = _issue_tokens(auth_client, user)
            if not access_token or not refresh_token:
                return _social_error_redirect(
                    request,
                    "not_authorized",
                    "This account is not authorized for this instance.",
                )
            auth_client._audit_log("social_login", user["email"], True, f"provider={provider},linked=true")

        else:
            # 2. Check if canonical email matches an existing account (password or prior link)
            existing = auth_client._find_user_by_email(email)

            if existing and email_verified:
                # Verified email matches → auto-link
                user = existing
                _create_social_identity(auth_client, user["user_id"], profile)
                access_token, refresh_token = _issue_tokens(auth_client, user)
                if not access_token or not refresh_token:
                    return _social_error_redirect(
                        request,
                        "not_authorized",
                        "This account is not authorized for this instance.",
                    )
                auth_client._audit_log("social_login", email, True,
                                       f"provider={provider},auto_linked=true,email_verified=true")
                logger.info("Auto-linked %s to existing account %s (verified email)", provider, email)

            elif existing and not email_verified:
                # Unverified email matches existing account → reject, require password login to link
                auth_client._audit_log("social_login", email, False,
                                       f"provider={provider},rejected=unverified_email_conflict")
                return _social_error_redirect(
                    request,
                    "email_not_verified",
                    f"An account already uses {email}. GitHub has not verified that email yet — "
                    "verify it on GitHub, or sign in with your password and link "
                    f"{provider} under Account → Linked.",
                )

            else:
                # 3. New user — create account + social identity
                result = auth_client.signup(email, uuid.uuid4().hex + "Aa1!", "default")
                if "error" in result:
                    err = result.get("error", "unknown")
                    el = err.lower()
                    if (
                        "signup is disabled" in el
                        or "public signup" in el
                        or "self-serve signup" in el
                    ):
                        return _social_error_redirect(
                            request,
                            "signup_disabled",
                            "New accounts are not open here. Request access at /apply, use an invite, "
                            "or sign in with an existing account and link GitHub from Account → Linked.",
                        )
                    return _social_error_redirect(
                        request,
                        "signup_failed",
                        f"Could not create account: {err}",
                    )
                access_token = result["access_token"]
                refresh_token = result["refresh_token"]
                _create_social_identity(auth_client, result["user_id"], profile)
                auth_client._audit_log("social_login", email, True,
                                       f"provider={provider},new_user=true")

        if not access_token or not refresh_token:
            return _social_error_redirect(
                request,
                "server_error",
                "Sign-in did not return a valid session. Try again or use email/password.",
            )

    except Exception as e:
        logger.error("Social login user provisioning failed: %s", e)
        return _social_error_redirect(
            request,
            "server_error",
            "Sign-in failed while creating your session. Try again or use email/password.",
        )

    # Redirect to the calling site (or dashboard if no redirect specified)
    redirect_base = _consume_oauth_return_base(request)
    # Fragment (#) avoids sending tokens to servers/logs/Referer (OWASP ASVS V3.1.1).
    # Include refresh_token so the dashboard can recover from 401s (same as email login).
    frag = urlencode(
        {
            "social": "success",
            "provider": provider,
            "token": access_token,
            "refresh": refresh_token,
        },
        quote_via=quote,
    )
    redirect_url = f"{redirect_base}#{frag}"

    logger.info("Social login successful: email=%s, provider=%s", email, provider)
    return RedirectResponse(url=redirect_url, status_code=302)


# ── Account linking (authenticated user adds a social provider) ────────────

@router.get("/linked-accounts", summary="List linked social identities")
async def list_linked_accounts(request: Request):
    """Return all social identities linked to the current user."""
    from collab_memory.auth.middleware import get_auth_client
    auth_client = get_auth_client()
    user = _get_current_user(request, auth_client)

    if not auth_client._neo4j:
        return {"linked_accounts": []}

    rows = auth_client._neo4j._tx_read(
        """
        MATCH (si:SocialIdentity)-[:LINKED_VIA]->(u:User {user_id: $uid})
        RETURN si.provider AS provider, si.email AS email,
               si.display_name AS display_name, si.avatar_url AS avatar_url,
               si.linked_at AS linked_at, si.last_login AS last_login
        """,
        uid=user["user_id"],
    )
    return {"linked_accounts": [dict(r) for r in rows]}


@router.delete("/linked-accounts/{provider}", summary="Unlink a social provider")
async def unlink_provider(provider: str, request: Request):
    """Remove a linked social identity. Requires at least one login method remains."""
    from collab_memory.auth.middleware import get_auth_client
    auth_client = get_auth_client()
    user = _get_current_user(request, auth_client)

    if not auth_client._neo4j:
        raise HTTPException(status_code=503, detail="Graph backend unavailable")

    # Ensure user has at least one other login method
    has_password = bool(user.get("password_hash"))
    linked = auth_client._neo4j._tx_read(
        "MATCH (si:SocialIdentity)-[:LINKED_VIA]->(u:User {user_id: $uid}) RETURN count(si) AS cnt",
        uid=user["user_id"],
    )
    link_count = linked[0]["cnt"] if linked else 0

    if not has_password and link_count <= 1:
        raise HTTPException(
            status_code=400,
            detail="Cannot unlink — this is your only login method. Set a password first.",
        )

    auth_client._neo4j._tx_write(
        """
        MATCH (si:SocialIdentity {provider: $provider})-[r:LINKED_VIA]->(u:User {user_id: $uid})
        DELETE r, si
        """,
        provider=provider, uid=user["user_id"],
    )
    auth_client._audit_log("social_unlink", user["email"], True, f"provider={provider}")
    return {"status": "ok", "message": f"{provider} account unlinked"}


def _get_current_user(request: Request, auth_client) -> dict:
    """Extract current user from Authorization header."""
    auth_header = request.headers.get("Authorization", "")
    if not auth_header.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Authorization required")
    payload = auth_client._decode_token(auth_header[7:])
    if not payload:
        raise HTTPException(status_code=401, detail="Invalid token")
    user = auth_client._find_user_by_email(payload["email"])
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user
