"""
collab_memory/auth/middleware.py — Dual Auth Middleware (JWT + X-API-Key)

Provides FastAPI dependencies for authenticating requests via either:
1. Self-hosted JWT (Bearer token) — for user/dashboard requests
2. X-API-Key header — for agent/MCP requests (existing system)

Both paths resolve to the same AgentContext, maintaining backward
compatibility while adding tenant-scoped authentication.

Design per NIST SP 800-207 Zero Trust:
- Every request is authenticated regardless of origin
- No implicit trust based on network location
"""

from __future__ import annotations

import logging
from typing import Optional

from fastapi import Request, HTTPException

from collab_memory.auth.jwt_provider import JWTAuthProvider, AuthUser
from collab_memory.auth.clerk_provider import verify_clerk_token, is_clerk_enabled, ClerkUser

logger = logging.getLogger(__name__)

# Module-level singleton — initialized once
_auth_client: Optional[JWTAuthProvider] = None


def get_auth_client() -> JWTAuthProvider:
    """Get or create the singleton JWT auth provider."""
    global _auth_client
    if _auth_client is None:
        _auth_client = JWTAuthProvider()
    return _auth_client


def init_auth_client(neo4j_backend=None) -> JWTAuthProvider:
    """Initialize the auth client with optional Neo4j backend.

    Call this during app startup to wire Neo4j user storage.
    """
    global _auth_client
    _auth_client = JWTAuthProvider(neo4j_backend=neo4j_backend)
    return _auth_client


def get_current_user(request: Request) -> Optional[AuthUser]:
    """Extract authenticated user from request.

    Checks (in order):
    1. Authorization: Bearer <jwt> header
    2. Falls back to X-API-Key (existing ABAC system)

    Returns AuthUser if JWT valid, None if using API key or unauthenticated.
    The existing ABAC middleware handles API key auth separately.
    """
    auth_header = request.headers.get("Authorization", "")

    if auth_header.startswith("Bearer "):
        token = auth_header[7:].strip()
        if token and token != "bypass-token":
            # Try Clerk first if enabled
            if is_clerk_enabled():
                clerk_user = verify_clerk_token(token)
                if clerk_user:
                    return AuthUser(
                        user_id=clerk_user.user_id,
                        email=clerk_user.email,
                        tenant_id=clerk_user.tenant_id,
                        role=clerk_user.role,
                    )
                logger.debug("Clerk verification failed — trying self-hosted JWT")

            # Fall back to self-hosted JWT
            client = get_auth_client()
            user = client.get_user(token)
            if user:
                return user
            else:
                logger.warning("JWT verification failed — falling through to API key auth")

    return None


async def jwt_or_apikey_auth(request: Request) -> Optional[AuthUser]:
    """FastAPI dependency: resolve user from JWT or fall through to API key.

    This is non-blocking — if neither JWT nor API key is present,
    the existing ABAC middleware handles the 401 response.

    Usage:
        @app.get("/my-endpoint")
        async def my_endpoint(user: Optional[AuthUser] = Depends(jwt_or_apikey_auth)):
            if user:
                # JWT-authenticated — use user.tenant_id
                ...
            else:
                # Falling through to X-API-Key path
                ...
    """
    user = get_current_user(request)
    if user:
        # Attach to request state for downstream access
        request.state.auth_user = user
        request.state.tenant_id = user.tenant_id
    return user


def require_jwt(request: Request) -> AuthUser:
    """FastAPI dependency: require JWT auth (no API key fallback).

    Used for user-specific endpoints like /auth/me, /auth/keys.

    Raises 401 if no valid JWT.
    """
    user = get_current_user(request)
    if not user:
        raise HTTPException(
            status_code=401,
            detail="This endpoint requires JWT authentication. Use Authorization: Bearer <token>",
        )
    return user
