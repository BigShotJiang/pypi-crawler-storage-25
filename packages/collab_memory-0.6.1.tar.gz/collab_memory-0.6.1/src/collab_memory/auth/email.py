"""
collab_memory/auth/email.py — Transactional email via Resend REST API.

Sends verification, password reset, and invite emails.
Requires RESEND_API_KEY env var. Falls back to logging if not set.

Resend docs: https://resend.com/docs/api-reference/emails/send-email
"""
from __future__ import annotations

import logging
import os
import json
import html
import urllib.request
import urllib.error
import html as html_module

from collab_memory.secrets import get_secret

logger = logging.getLogger(__name__)

_DEFAULT_PUBLIC_URL = "https://collab-memory.onrender.com"


def _resend_api_key() -> str:
    # Prefer explicit env first (fast path), then shared secret resolver chain.
    direct = (os.environ.get("RESEND_API_KEY", "")
              or os.environ.get("RESEND_API_KEY_LIVE", "")).strip()
    if direct:
        return direct
    for key in ("RESEND_API_KEY", "RESEND_API_KEY_LIVE"):
        try:
            val = (get_secret(key, required=False) or "").strip()
            if val:
                return val
        except Exception:
            # Resolver failures should not crash auth/email flows.
            pass
    return ""


def _from_email() -> str:
    direct = os.environ.get("FROM_EMAIL", "").strip()
    if direct:
        return direct
    try:
        resolved = (get_secret("FROM_EMAIL", required=False) or "").strip()
        if resolved:
            return resolved
    except Exception:
        pass
    return "OHACO Labs <info@ohaco.org>"


def _public_url() -> str:
    """Resolve canonical browser origin used in outbound auth/invite links."""
    for name in ("COLLAB_PUBLIC_URL", "PUBLIC_APP_URL", "APP_URL"):
        val = os.environ.get(name, "").strip().rstrip("/")
        if val:
            return val
    for name in ("COLLAB_PUBLIC_URL", "PUBLIC_APP_URL", "APP_URL"):
        try:
            val = (get_secret(name, required=False) or "").strip().rstrip("/")
            if val:
                return val
        except Exception:
            pass
    return _DEFAULT_PUBLIC_URL


def _send(to: str, subject: str, html: str) -> dict:
    """Send an email via Resend REST API. Returns response dict or error."""
    resend_api_key = _resend_api_key()
    if not resend_api_key:
        logger.warning("RESEND_API_KEY not set — email to %s not sent: %s", to, subject)
        return {"status": "skipped", "reason": "RESEND_API_KEY not set"}

    payload = json.dumps({
        "from": _from_email(),
        "to": [to],
        "subject": subject,
        "html": html,
    }).encode()

    req = urllib.request.Request(
        "https://api.resend.com/emails",
        data=payload,
        headers={
            "Authorization": f"Bearer {resend_api_key}",
            "Content-Type": "application/json",
            "User-Agent": "collab-memory-email/1.0",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read())
            logger.info("Email sent to %s: %s (id=%s)", to, subject, data.get("id"))
            return {"status": "sent", "id": data.get("id")}
    except urllib.error.HTTPError as e:
        body = e.read().decode() if e.fp else ""
        logger.error("Resend error %d sending to %s: %s", e.code, to, body)
        return {"status": "error", "code": e.code, "detail": body}
    except Exception as e:
        logger.error("Email send failed for %s: %s", to, e)
        return {"status": "error", "detail": str(e)}


def email_config_status() -> dict:
    """Return non-secret email config posture for ops diagnostics."""
    key = _resend_api_key()
    sender = _from_email()
    return {
        "delivery_enabled": bool(key),
        "from_email": sender,
        "reason": "" if key else "RESEND_API_KEY missing from vault/env chain",
    }


def send_verification_email(to: str, token: str, display_name: str = "") -> dict:
    """Send email verification link."""
    verify_url = f"{_public_url()}/auth/verify-email?token={token}"
    name = display_name or to.split("@")[0]
    html = f"""
    <div style="font-family: -apple-system, sans-serif; max-width: 480px; margin: 0 auto; padding: 32px;">
        <h2 style="color: #6c5ce7;">Welcome to OHACO Labs</h2>
        <p>Hi {name},</p>
        <p>Verify your email to activate your Semantic Dreams workspace:</p>
        <a href="{verify_url}"
           style="display: inline-block; background: #6c5ce7; color: #fff; padding: 12px 24px;
                  border-radius: 6px; text-decoration: none; font-weight: 600; margin: 16px 0;">
            Verify Email
        </a>
        <p style="color: #888; font-size: 13px;">Or copy this link: {verify_url}</p>
        <hr style="border: none; border-top: 1px solid #333; margin: 24px 0;">
        <p style="color: #666; font-size: 12px;">OHACO Labs — Semantic Dreams<br>
        Your data. Your memory. Your AI.</p>
    </div>
    """
    return _send(to, "Verify your OHACO email", html)


def send_password_reset_email(to: str, token: str) -> dict:
    """Send password reset link."""
    reset_url = f"{_public_url()}/?reset_token={token}"
    html = f"""
    <div style="font-family: -apple-system, sans-serif; max-width: 480px; margin: 0 auto; padding: 32px;">
        <h2 style="color: #6c5ce7;">Password Reset</h2>
        <p>You requested a password reset for your OHACO account.</p>
        <a href="{reset_url}"
           style="display: inline-block; background: #6c5ce7; color: #fff; padding: 12px 24px;
                  border-radius: 6px; text-decoration: none; font-weight: 600; margin: 16px 0;">
            Reset Password
        </a>
        <p style="color: #888; font-size: 13px;">This link expires in 1 hour.</p>
        <p style="color: #888; font-size: 13px;">If you didn't request this, ignore this email.</p>
        <hr style="border: none; border-top: 1px solid #333; margin: 24px 0;">
        <p style="color: #666; font-size: 12px;">OHACO Labs — Semantic Dreams</p>
    </div>
    """
    return _send(to, "Reset your OHACO password", html)


def send_invite_email(to: str, invite_url: str, project_name: str, inviter: str = "OHACO Labs") -> dict:
    """Send project invite link."""
    html = f"""
    <div style="font-family: -apple-system, sans-serif; max-width: 480px; margin: 0 auto; padding: 32px;">
        <h2 style="color: #6c5ce7;">You're Invited</h2>
        <p>{inviter} invited you to join <strong>{project_name}</strong> on Semantic Dreams by OHACO Labs.</p>
        <a href="{invite_url}"
           style="display: inline-block; background: #6c5ce7; color: #fff; padding: 12px 24px;
                  border-radius: 6px; text-decoration: none; font-weight: 600; margin: 16px 0;">
            Accept Invite
        </a>
        <p style="color: #888; font-size: 13px;">Or copy this link: {invite_url}</p>
        <hr style="border: none; border-top: 1px solid #333; margin: 24px 0;">
        <p style="color: #666; font-size: 12px;">OHACO Labs — Semantic Dreams<br>
        Your data. Your memory. Your AI.</p>
    </div>
    """
    return _send(to, f"Join {project_name} on OHACO", html)


def send_branded_test_email(to: str) -> dict:
    """Send a branded smoke-test email to verify Resend + template wiring."""
    public_url = _public_url()
    try:
        from collab_memory.auth.email_layout import render_branded_email
        html = render_branded_email(
            title="Test Email",
            preheader="This is a test from Semantic Dreams by OHACO Labs",
            inner_html="<p>If you're reading this, transactional email is working.</p>",
            cta_href=public_url,
            cta_label="Open Dashboard",
        )
    except ImportError:
        html = """
        <div style="font-family: -apple-system, sans-serif; max-width: 480px; margin: 0 auto; padding: 32px;">
            <h2 style="color: #6c5ce7;">OHACO Test Email</h2>
            <p>If you're reading this, transactional email is working.</p>
        </div>
        """
    return _send(to, "OHACO — Test Email", html)


def send_access_request_notification(
    applicant_email: str,
    full_name: str,
    tracks: list[str],
    message: str,
    request_id: str,
) -> dict:
    """Notify admin(s) of a new access request AND send confirmation to the applicant.

    Admin list comes from SUPER_ADMIN_EMAILS env var.
    """
    public_url = _public_url()
    tracks_display = ", ".join(t.replace("_", " ").title() for t in tracks)
    name_display = full_name or applicant_email.split("@")[0]
    track_steps: dict[str, str] = {
        "launch_waitlist": "Launch notifications: you will receive launch and onboarding updates by email.",
        "beta_tester": "Early beta: approved testers receive invite and setup instructions.",
        "community_volunteer": "Community volunteer: we follow up with contribution options and next actions.",
        "investor_advisor": "Investor/advisor: complete NCNDA intake and review the investor deck.",
    }
    selected_steps = [track_steps[t] for t in tracks if t in track_steps]
    steps_html = "".join(f"<li>{s}</li>" for s in selected_steps)

    # ── 1. Email to admin(s) ──────────────────────────────────────────────
    admin_html = f"""
    <div style="font-family: -apple-system, sans-serif; max-width: 520px; margin: 0 auto; padding: 32px;">
        <h2 style="color: #6c5ce7;">New Access Request</h2>
        <table style="width: 100%; border-collapse: collapse; margin: 16px 0;">
            <tr><td style="padding: 8px 0; color: #888; font-size: 13px;">Email</td>
                <td style="padding: 8px 0; font-size: 14px;">{applicant_email}</td></tr>
            <tr><td style="padding: 8px 0; color: #888; font-size: 13px;">Name</td>
                <td style="padding: 8px 0; font-size: 14px;">{name_display}</td></tr>
            <tr><td style="padding: 8px 0; color: #888; font-size: 13px;">Tracks</td>
                <td style="padding: 8px 0; font-size: 14px;">{tracks_display}</td></tr>
            <tr><td style="padding: 8px 0; color: #888; font-size: 13px;">Message</td>
                <td style="padding: 8px 0; font-size: 14px;">{message or '(none)'}</td></tr>
            <tr><td style="padding: 8px 0; color: #888; font-size: 13px;">ID</td>
                <td style="padding: 8px 0; font-size: 12px; font-family: monospace;">{request_id}</td></tr>
        </table>
        <a href="{public_url}/docs#/default/ops_access_requests_ops_access_requests_get"
           style="display: inline-block; background: #6c5ce7; color: #fff; padding: 12px 24px;
                  border-radius: 6px; text-decoration: none; font-weight: 600; margin: 16px 0;">
            Review in Dashboard
        </a>
        <hr style="border: none; border-top: 1px solid #333; margin: 24px 0;">
        <p style="color: #666; font-size: 12px;">OHACO Labs — Semantic Dreams</p>
    </div>
    """

    admin_results = []
    admin_emails_raw = os.environ.get("SUPER_ADMIN_EMAILS", "").strip()
    if not admin_emails_raw:
        try:
            admin_emails_raw = (get_secret("SUPER_ADMIN_EMAILS", required=False) or "").strip()
        except Exception:
            admin_emails_raw = ""
    if admin_emails_raw:
        for addr in admin_emails_raw.split(","):
            addr = addr.strip().lower()
            if addr and "@" in addr:
                r = _send(addr, f"Access request from {applicant_email}", admin_html)
                admin_results.append(r)
    else:
        logger.warning("SUPER_ADMIN_EMAILS not set — no admin notified of access request %s", request_id)

    # ── 2. Confirmation email to applicant ────────────────────────────────
    applicant_html = f"""
    <div style="font-family: -apple-system, sans-serif; max-width: 480px; margin: 0 auto; padding: 32px;">
        <h2 style="color: #6c5ce7;">We got your request</h2>
        <p>Hi {name_display},</p>
        <p>Thanks for your interest in <strong>Semantic Dreams</strong> by OHACO Labs.
        We received your request for: <strong>{tracks_display}</strong>.</p>
        <p>We review applications manually and will follow up by email if there is a fit.
        Approved beta testers get a full instance through our invite flow.</p>
        <p style="margin-top: 14px;"><strong>What happens next:</strong></p>
        <ul style="margin: 8px 0 0 18px; color: #cbd5e1; font-size: 13px; line-height: 1.5;">
            {steps_html or '<li>We review your request and follow up with the next action by email.</li>'}
        </ul>
        <p style="color: #888; font-size: 13px; margin-top: 24px;">
        Reference: <code>{request_id[:8]}</code></p>
        <hr style="border: none; border-top: 1px solid #333; margin: 24px 0;">
        <p style="color: #666; font-size: 12px;">OHACO Labs — Semantic Dreams<br>
        Your data. Your memory. Your AI.</p>
    </div>
    """
    applicant_result = _send(applicant_email, "We received your access request — OHACO Labs", applicant_html)

    return {
        "admin_notified": len(admin_results),
        "admin_results": admin_results,
        "applicant_result": applicant_result,
    }


def send_investor_inquiry_notification(
    investor_email: str,
    full_name: str,
    organization: str,
    role: str,
    website: str,
    check_size: str,
    stage_focus: str,
    ncnnda_acknowledged: bool,
    request_id: str,
) -> dict:
    """Notify admins and send acknowledgement for investor inquiries."""
    public_url = _public_url()
    name_display = full_name or investor_email.split("@")[0]
    org_display = organization or "(not provided)"
    role_display = role or "(not provided)"
    website_display = website or "(not provided)"
    check_display = check_size or "(not provided)"
    stage_display = stage_focus or "(not provided)"
    ncnnda_display = "Yes" if ncnnda_acknowledged else "No"

    admin_html = f"""
    <div style="font-family: -apple-system, sans-serif; max-width: 540px; margin: 0 auto; padding: 32px;">
        <h2 style="color: #6c5ce7;">New Investor Inquiry</h2>
        <table style="width: 100%; border-collapse: collapse; margin: 16px 0;">
            <tr><td style="padding: 8px 0; color: #888; font-size: 13px;">Email</td>
                <td style="padding: 8px 0; font-size: 14px;">{investor_email}</td></tr>
            <tr><td style="padding: 8px 0; color: #888; font-size: 13px;">Name</td>
                <td style="padding: 8px 0; font-size: 14px;">{name_display}</td></tr>
            <tr><td style="padding: 8px 0; color: #888; font-size: 13px;">Organization</td>
                <td style="padding: 8px 0; font-size: 14px;">{org_display}</td></tr>
            <tr><td style="padding: 8px 0; color: #888; font-size: 13px;">Role</td>
                <td style="padding: 8px 0; font-size: 14px;">{role_display}</td></tr>
            <tr><td style="padding: 8px 0; color: #888; font-size: 13px;">Website</td>
                <td style="padding: 8px 0; font-size: 14px;">{website_display}</td></tr>
            <tr><td style="padding: 8px 0; color: #888; font-size: 13px;">Check size</td>
                <td style="padding: 8px 0; font-size: 14px;">{check_display}</td></tr>
            <tr><td style="padding: 8px 0; color: #888; font-size: 13px;">Stage focus</td>
                <td style="padding: 8px 0; font-size: 14px;">{stage_display}</td></tr>
            <tr><td style="padding: 8px 0; color: #888; font-size: 13px;">NCNDA acknowledged</td>
                <td style="padding: 8px 0; font-size: 14px;">{ncnnda_display}</td></tr>
            <tr><td style="padding: 8px 0; color: #888; font-size: 13px;">Reference</td>
                <td style="padding: 8px 0; font-size: 12px; font-family: monospace;">{request_id}</td></tr>
        </table>
        <a href="{public_url}/investor-deck"
           style="display: inline-block; background: #6c5ce7; color: #fff; padding: 12px 24px;
                  border-radius: 6px; text-decoration: none; font-weight: 600; margin: 16px 0;">
            Open Investor Deck
        </a>
        <hr style="border: none; border-top: 1px solid #333; margin: 24px 0;">
        <p style="color: #666; font-size: 12px;">OHACO Labs — Semantic Dreams</p>
    </div>
    """

    admin_results = []
    admin_emails_raw = os.environ.get("SUPER_ADMIN_EMAILS", "").strip()
    if not admin_emails_raw:
        try:
            admin_emails_raw = (get_secret("SUPER_ADMIN_EMAILS", required=False) or "").strip()
        except Exception:
            admin_emails_raw = ""
    if admin_emails_raw:
        for addr in admin_emails_raw.split(","):
            addr = addr.strip().lower()
            if addr and "@" in addr:
                r = _send(addr, f"Investor inquiry from {investor_email}", admin_html)
                admin_results.append(r)
    else:
        logger.warning("SUPER_ADMIN_EMAILS not set — no admin notified of investor inquiry %s", request_id)

    applicant_html = f"""
    <div style="font-family: -apple-system, sans-serif; max-width: 500px; margin: 0 auto; padding: 32px;">
        <h2 style="color: #6c5ce7;">Investor inquiry received</h2>
        <p>Hi {name_display},</p>
        <p>Thanks for your interest in <strong>Semantic Dreams by OHACO Labs</strong>.</p>
        <p>We received your inquiry and NCNDA acknowledgement. You can review the current investor deck here:</p>
        <a href="{public_url}/investor-deck"
           style="display: inline-block; background: #6c5ce7; color: #fff; padding: 12px 24px;
                  border-radius: 6px; text-decoration: none; font-weight: 600; margin: 16px 0;">
            Open Investor Deck
        </a>
        <p style="color: #888; font-size: 13px;">Reference: <code>{request_id[:8]}</code></p>
        <hr style="border: none; border-top: 1px solid #333; margin: 24px 0;">
        <p style="color: #666; font-size: 12px;">OHACO Labs — Semantic Dreams<br>
        Your data. Your memory. Your AI.</p>
    </div>
    """
    applicant_result = _send(investor_email, "Investor inquiry received — OHACO Labs", applicant_html)

    return {
        "admin_notified": len(admin_results),
        "admin_results": admin_results,
        "applicant_result": applicant_result,
    }


def send_instance_team_invite_email(to: str, role_description: str = "workspace administrator") -> dict:
    """Send instance-level team invite (branded, with role context)."""
    public_url = _public_url()
    try:
        from collab_memory.auth.email_layout import render_branded_email
        html = render_branded_email(
            title="You're Invited",
            preheader=f"Join Semantic Dreams by OHACO Labs as {role_description}",
            inner_html=f"""
                <p>You've been invited to join <strong>Semantic Dreams</strong>
                as a <strong>{role_description}</strong>.</p>
                <p>Click below to set up your account and start building your semantic memory graph.</p>
            """,
            cta_href=f"{public_url}/signup",
            cta_label="Accept Invite",
        )
    except ImportError:
        html = f"""
        <div style="font-family: -apple-system, sans-serif; max-width: 480px; margin: 0 auto; padding: 32px;">
            <h2 style="color: #6c5ce7;">You're Invited</h2>
            <p>You've been invited to join Semantic Dreams as a <strong>{role_description}</strong>.</p>
            <a href="{public_url}/signup"
               style="display: inline-block; background: #6c5ce7; color: #fff; padding: 12px 24px;
                      border-radius: 6px; text-decoration: none; font-weight: 600; margin: 16px 0;">
                Accept Invite
            </a>
        </div>
        """
    return _send(to, "You're invited to Semantic Dreams by OHACO Labs", html)


def _clip_items(items: list[str] | None, *, max_items: int = 25, max_chars: int = 300) -> list[str]:
    """Normalize report bullet lists for reliable transactional email rendering."""
    out: list[str] = []
    for raw in (items or []):
        s = str(raw or "").strip()
        if not s:
            continue
        out.append(s[:max_chars])
        if len(out) >= max_items:
            break
    return out


def _bullet_section(title: str, items: list[str] | None) -> str:
    clean = _clip_items(items)
    if not clean:
        return ""
    lis = "".join(f"<li style='margin: 0 0 6px 0;'>{html_module.escape(i)}</li>" for i in clean)
    return (
        f"<h3 style='margin:20px 0 8px 0;font-size:15px;color:#f0f0f8;'>{html_module.escape(title)}</h3>"
        f"<ul style='margin:0;padding-left:18px;'>{lis}</ul>"
    )


def _link_section(title: str, links: list[str] | None) -> str:
    clean = _clip_items(links, max_items=20, max_chars=500)
    if not clean:
        return ""
    lis = "".join(
        "<li style='margin: 0 0 6px 0;'>"
        f"<a href='{html_module.escape(u, quote=True)}' style='color:#a29bfe;text-decoration:none;'>{html_module.escape(u)}</a>"
        "</li>"
        for u in clean
    )
    return (
        f"<h3 style='margin:20px 0 8px 0;font-size:15px;color:#f0f0f8;'>{html_module.escape(title)}</h3>"
        f"<ul style='margin:0;padding-left:18px;'>{lis}</ul>"
    )


def send_delivery_report_email(
    to: str,
    *,
    project_name: str = "collab-memory",
    repo_url: str = "",
    branch: str = "",
    pr_url: str = "",
    commit_sha: str = "",
    task_summary: str = "",
    changes: list[str] | None = None,
    updates: list[str] | None = None,
    enhancements: list[str] | None = None,
    suggestions: list[str] | None = None,
    existing_code_notes: list[str] | None = None,
    tests_run: list[str] | None = None,
    implementation_impact: list[str] | None = None,
    video_urls: list[str] | None = None,
    image_urls: list[str] | None = None,
    additional_notes: str = "",
    subject_override: str = "",
) -> dict:
    """Send a senior-review style delivery report including walkthrough artifacts."""
    from collab_memory.auth.email_layout import render_branded_email

    project = (project_name or "collab-memory").strip()[:120]
    summary = (task_summary or "").strip()[:2000]
    notes = (additional_notes or "").strip()[:4000]
    safe_sha = (commit_sha or "").strip()[:80]

    repo_block = (
        "<h3 style='margin:0 0 8px 0;font-size:15px;color:#f0f0f8;'>Repo Context</h3>"
        "<table style='width:100%;border-collapse:collapse;margin:0 0 12px 0;'>"
        f"<tr><td style='padding:4px 0;color:#7a7a92;font-size:12px;'>Project</td><td style='padding:4px 0;font-size:13px;'>{html_module.escape(project)}</td></tr>"
        f"<tr><td style='padding:4px 0;color:#7a7a92;font-size:12px;'>Branch</td><td style='padding:4px 0;font-size:13px;font-family:monospace;'>{html_module.escape(branch or '(not provided)')}</td></tr>"
        f"<tr><td style='padding:4px 0;color:#7a7a92;font-size:12px;'>Commit</td><td style='padding:4px 0;font-size:13px;font-family:monospace;'>{html_module.escape(safe_sha or '(not provided)')}</td></tr>"
        f"<tr><td style='padding:4px 0;color:#7a7a92;font-size:12px;'>Repo URL</td><td style='padding:4px 0;font-size:13px;'>{html_module.escape(repo_url or '(not provided)')}</td></tr>"
        f"<tr><td style='padding:4px 0;color:#7a7a92;font-size:12px;'>PR URL</td><td style='padding:4px 0;font-size:13px;'>{html_module.escape(pr_url or '(not provided)')}</td></tr>"
        "</table>"
    )

    summary_block = (
        f"<h3 style='margin:20px 0 8px 0;font-size:15px;color:#f0f0f8;'>Task Summary</h3>"
        f"<p style='margin:0 0 8px 0;'>{html_module.escape(summary or '(not provided)')}</p>"
    )

    body = [
        repo_block,
        summary_block,
        _bullet_section("Changes", changes),
        _bullet_section("Updates", updates),
        _bullet_section("Enhancements", enhancements),
        _bullet_section("Suggestions", suggestions),
        _bullet_section("Existing Code Notes", existing_code_notes),
        _bullet_section("Tests Run", tests_run),
        _bullet_section("Implementation Impact", implementation_impact),
        _link_section("Walkthrough Videos", video_urls),
        _link_section("Walkthrough Screenshots", image_urls),
    ]
    if notes:
        body.append(
            f"<h3 style='margin:20px 0 8px 0;font-size:15px;color:#f0f0f8;'>Additional Notes</h3>"
            f"<p style='margin:0 0 8px 0;'>{html_module.escape(notes)}</p>"
        )

    html = render_branded_email(
        title="Engineering Delivery Report",
        preheader=f"Implementation report for {project}",
        inner_html="".join(x for x in body if x),
        cta_href=(pr_url or repo_url or _public_url()),
        cta_label="Open Review Context",
    )
    subject = (subject_override or "").strip()[:220] or f"OHACO Delivery Report — {project}"
    return _send(to, subject, html)


def send_release_decision_email(
    to: str,
    *,
    decision: str,
    target_branch: str,
    approved_prs: list[str],
    blocked_prs: list[str],
    summary: str,
    blockers: list[str],
    next_actions: list[str],
    tests: list[str],
    artifacts: list[str],
) -> dict:
    """Send lead-agent release decision email (go/no-go)."""

    def _ul(items: list[str]) -> str:
        clean = [str(i or "").strip() for i in items or []]
        clean = [i for i in clean if i]
        if not clean:
            return "<p style='color:#888;'>None</p>"
        parts = "".join(f"<li>{html.escape(i)}</li>" for i in clean[:100])
        return f"<ul style='margin:8px 0 16px 18px; padding:0;'>{parts}</ul>"

    dec = (decision or "").strip().lower()
    pretty_decision = "GO" if dec == "go" else "NO-GO"
    summary_safe = html.escape((summary or "").strip())
    target_safe = html.escape((target_branch or "main").strip() or "main")

    if dec == "go":
        title = "Release Decision: GO"
        pre = f"Approved for push to {target_safe}"
        decision_line = (
            f"<p><strong>Decision:</strong> <span style='color:#16a34a;'>{pretty_decision}</span></p>"
            f"<p><strong>Target branch:</strong> {target_safe}</p>"
            f"<p><strong>Summary:</strong> {summary_safe}</p>"
        )
    else:
        title = "Release Decision: NO-GO"
        pre = f"Push blocked for {target_safe}"
        decision_line = (
            f"<p><strong>Decision:</strong> <span style='color:#dc2626;'>{pretty_decision}</span></p>"
            f"<p><strong>Target branch:</strong> {target_safe}</p>"
            f"<p><strong>Summary:</strong> {summary_safe}</p>"
        )

    inner_html = (
        f"{decision_line}"
        "<h3 style='margin:16px 0 8px;'>Approved PRs</h3>"
        f"{_ul(approved_prs)}"
        "<h3 style='margin:16px 0 8px;'>Blocked PRs</h3>"
        f"{_ul(blocked_prs)}"
        "<h3 style='margin:16px 0 8px;'>Blockers</h3>"
        f"{_ul(blockers)}"
        "<h3 style='margin:16px 0 8px;'>Next Actions</h3>"
        f"{_ul(next_actions)}"
        "<h3 style='margin:16px 0 8px;'>Tests</h3>"
        f"{_ul(tests)}"
        "<h3 style='margin:16px 0 8px;'>Artifacts</h3>"
        f"{_ul(artifacts)}"
    )

    try:
        from collab_memory.auth.email_layout import render_branded_email

        html_body = render_branded_email(
            title=title,
            preheader=pre,
            inner_html=inner_html,
            cta_href=f"{_public_url()}/docs#/default/ops_transactional_mail_ops_transactional_mail_post",
            cta_label="Open Ops Mail API",
        )
    except ImportError:
        html_body = (
            "<div style='font-family:-apple-system,sans-serif;max-width:520px;margin:0 auto;padding:32px;'>"
            f"<h2>{html.escape(title)}</h2>{inner_html}</div>"
        )

    return _send(to, f"OHACO Release Decision — {pretty_decision}", html_body)
