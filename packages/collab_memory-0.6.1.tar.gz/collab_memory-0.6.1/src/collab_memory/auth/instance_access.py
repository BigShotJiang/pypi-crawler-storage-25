"""Single-instance access control: allowlisted emails, shared tenant, session roles.

Env (all optional unless noted):
  ALLOWED_INSTANCE_LOGIN_EMAILS — comma-separated. When set, only these emails may
    sign up or hold a session on this deployment.
  INSTANCE_ZERO_TENANT_ID — Neo4j tenant UUID shared by instance members.
  INSTANCE_ZERO_MEMBER_EMAILS — comma-separated; members are rehomed to INSTANCE_ZERO_TENANT_ID on login.
  SUPER_ADMIN_EMAILS — session role ``super_admin`` (JWT + ABAC; above ``admin``).
  INSTANCE_ADMIN_EMAILS — session role ``admin`` when not super-admin (overrides DB role for tokens).
"""

from __future__ import annotations

import os


def normalize_instance_email(email: str | None) -> str:
    """Lowercase/strip for env lists (same rules as jwt_provider.normalize_email)."""
    if email is None:
        return ""
    s = str(email).strip()
    return s.lower() if s else ""


def _env_email_set(env_name: str) -> set[str]:
    raw = os.environ.get(env_name, "").strip()
    if not raw:
        return set()
    out: set[str] = set()
    for part in raw.split(","):
        e = normalize_instance_email(part)
        if e:
            out.add(e)
    return out


def allowed_instance_login_emails() -> set[str]:
    return _env_email_set("ALLOWED_INSTANCE_LOGIN_EMAILS")


def instance_zero_tenant_id() -> str:
    return os.environ.get("INSTANCE_ZERO_TENANT_ID", "").strip()


def instance_zero_member_emails() -> set[str]:
    return _env_email_set("INSTANCE_ZERO_MEMBER_EMAILS")


def instance_login_denied_reason(email_norm: str) -> str | None:
    """If this email may not use the instance, return a short error message."""
    allowed = allowed_instance_login_emails()
    if not allowed:
        return None
    if not email_norm or email_norm not in allowed:
        return "This instance only accepts pre-authorized accounts."
    return None


def instance_signup_denied_reason(email_norm: str) -> str | None:
    """Same gate as login — used by signup policy."""
    r = instance_login_denied_reason(email_norm)
    if r:
        return r
    return None


def resolve_session_role(email_norm: str, db_role: str) -> str:
    """JWT / ABAC role after env overrides (super admin > instance admin > DB)."""
    if email_norm in _env_email_set("SUPER_ADMIN_EMAILS"):
        return "super_admin"
    if email_norm in _env_email_set("INSTANCE_ADMIN_EMAILS"):
        return "admin"
    return db_role if db_role else "contributor"


def count_super_admin_emails() -> int:
    return len(_env_email_set("SUPER_ADMIN_EMAILS"))


def count_instance_admin_emails() -> int:
    return len(_env_email_set("INSTANCE_ADMIN_EMAILS"))
