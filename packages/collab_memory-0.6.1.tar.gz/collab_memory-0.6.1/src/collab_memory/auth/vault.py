"""
collab_memory/auth/vault.py — AES-256-GCM Encrypted Key Vault

Encrypts user-provided LLM API keys at rest.
Per NIST SP 800-53 SC-28 and Supabase Vault pattern:
- Encryption key stored OUTSIDE the database (env var)
- Each value gets a unique IV (nonce)
- Authentication tag prevents tampering
- Keys never appear in logs

Requires: VAULT_MASTER_KEY env var (32-byte hex string)
"""

from __future__ import annotations

import os
import base64
import logging
import secrets
from typing import Optional

logger = logging.getLogger(__name__)

# AES-256-GCM constants
_KEY_BYTES = 32  # 256 bits
_IV_BYTES = 12   # 96-bit nonce (NIST recommended)
_TAG_BYTES = 16  # 128-bit auth tag


class LLMKeyVault:
    """AES-256-GCM encrypted storage for user LLM API keys.

    Storage format: base64(IV || ciphertext || tag)
    Master key: loaded from VAULT_MASTER_KEY env var
    """

    def __init__(self, master_key_hex: Optional[str] = None):
        # Only fall back to env var when master_key_hex is None (not explicitly passed)
        hex_key = master_key_hex if master_key_hex is not None else os.environ.get("VAULT_MASTER_KEY", "")
        if hex_key:
            try:
                self._key = bytes.fromhex(hex_key)
                if len(self._key) != _KEY_BYTES:
                    raise ValueError(f"Key must be {_KEY_BYTES} bytes, got {len(self._key)}")
                self._configured = True
                logger.info("Vault initialized with master key")
            except ValueError as e:
                logger.error(f"Invalid VAULT_MASTER_KEY: {e}")
                self._key = None
                self._configured = False
        else:
            logger.warning("VAULT_MASTER_KEY not set — vault in plaintext mode (dev only)")
            self._key = None
            self._configured = False

    @property
    def is_configured(self) -> bool:
        return self._configured

    def encrypt(self, plaintext: str) -> str:
        """Encrypt an LLM API key. Returns base64-encoded blob.

        Format: base64(iv[12] || ciphertext[n] || tag[16])
        """
        if not self._key:
            # Dev mode: base64 encode but NOT encrypted
            logger.warning("Vault not configured — storing key in base64 (NOT ENCRYPTED)")
            return "PLAIN:" + base64.b64encode(plaintext.encode()).decode()

        try:
            from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        except ImportError:
            logger.error("cryptography package not installed — cannot encrypt")
            raise RuntimeError("pip install cryptography required for vault encryption")

        iv = secrets.token_bytes(_IV_BYTES)
        aesgcm = AESGCM(self._key)
        ciphertext = aesgcm.encrypt(iv, plaintext.encode("utf-8"), None)
        # ciphertext includes the tag appended by AESGCM
        blob = iv + ciphertext
        return base64.b64encode(blob).decode("ascii")

    def decrypt(self, encrypted: str) -> str:
        """Decrypt an LLM API key from base64 blob."""
        if encrypted.startswith("PLAIN:"):
            # Dev mode: just base64 decode
            return base64.b64decode(encrypted[6:]).decode()

        if not self._key:
            raise RuntimeError("Cannot decrypt — VAULT_MASTER_KEY not configured")

        try:
            from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        except ImportError:
            raise RuntimeError("pip install cryptography required for vault decryption")

        blob = base64.b64decode(encrypted)
        iv = blob[:_IV_BYTES]
        ciphertext = blob[_IV_BYTES:]

        aesgcm = AESGCM(self._key)
        plaintext = aesgcm.decrypt(iv, ciphertext, None)
        return plaintext.decode("utf-8")

    @staticmethod
    def generate_master_key() -> str:
        """Generate a new 256-bit master key as hex string.

        Usage: export VAULT_MASTER_KEY=$(python -c 'from collab_memory.auth.vault import LLMKeyVault; print(LLMKeyVault.generate_master_key())')
        """
        return secrets.token_hex(_KEY_BYTES)
