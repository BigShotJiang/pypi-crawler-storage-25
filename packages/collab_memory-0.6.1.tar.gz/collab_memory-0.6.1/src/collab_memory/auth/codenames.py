"""
collab_memory/auth/codenames.py — Random codename generator for user identity.

Generates memorable PascalCase codenames from themed word lists.
Assigned at signup; users can pick from options or type their own.
"""
from __future__ import annotations

import random

_ADJECTIVES = [
    "Shadow", "Neon", "Iron", "Void", "Crypto", "Phantom", "Quantum",
    "Stealth", "Ember", "Frost", "Thunder", "Rogue", "Nova", "Onyx",
    "Pulse", "Cobalt", "Zenith", "Apex", "Prism", "Viper", "Echo",
    "Raven", "Storm", "Flux", "Binary", "Cipher", "Drift", "Haze",
    "Omega", "Aether", "Velvet", "Obsidian", "Lunar", "Solar", "Astral",
    "Crimson", "Azure", "Jade", "Sonic", "Turbo",
]

_NOUNS = [
    "Forge", "Phoenix", "Runner", "Muse", "Wraith", "Falcon", "Sentinel",
    "Oracle", "Nexus", "Vertex", "Spectre", "Matrix", "Vector", "Catalyst",
    "Vortex", "Titan", "Harbinger", "Architect", "Weaver", "Striker",
    "Nomad", "Pioneer", "Ranger", "Hunter", "Blade", "Spark", "Wolf",
    "Hawk", "Fox", "Lynx", "Sage", "Helix", "Comet", "Pulse", "Drift",
    "Moth", "Wren", "Crane", "Orca", "Mantis",
]


def generate_codename() -> str:
    """Generate a single random codename. ~30% chance of trailing digit."""
    adj = random.choice(_ADJECTIVES)
    noun = random.choice(_NOUNS)
    suffix = str(random.randint(0, 9)) if random.random() < 0.3 else ""
    return f"{adj}{noun}{suffix}"


def generate_codename_options(n: int = 3) -> list[str]:
    """Generate n unique codename options for a user to choose from."""
    options: set[str] = set()
    attempts = 0
    while len(options) < n and attempts < n * 10:
        options.add(generate_codename())
        attempts += 1
    return sorted(options)
