"""
collab_memory/auth/clerk_provider.py — Clerk JWT Verification

Verifies Clerk-issued RS256 JWTs using Clerk's JWKS endpoint.
Extracts user identity, organization (tenant), and role from claims.

This replaces the self-hosted JWT flow when AUTH_PROVIDER=clerk.
The existing API key flow is unaffected — agents continue using X-API-Key.

Design:
- JWKS keys are cached for 1 hour (Clerk rotates infrequently)
- No Clerk SDK dependency on the backend — pure JWT verification
- Claims map: sub → user_id, org_id → tenant_id, org_role → role
"""

from __future__ import annotations

import logging
import os
import time
from dataclasses import dataclass
from typing import Optional

logger = logging.getLogger(__name__)

# Lazy imports — only needed if Clerk is enabled
_jwks_cache: Optional[dict] = None
_jwks_fetched_at: float = 0
_JWKS_TTL = 3600  # 1 hour


@dataclass
class ClerkUser:
    """Resolved identity from a Clerk JWT."""
    user_id: str
    email: str
    tenant_id: Optional[str]
    role: str
    plan: str
    raw_claims: dict


def _get_clerk_domain() -> str:
    """Clerk frontend API domain from env."""
    # Clerk publishable key encodes the domain: pk_live_xxx or pk_test_xxx
    # But we use the explicit domain env var if set
    domain = os.environ.get("CLERK_DOMAIN", "")
    if domain:
        return domain.rstrip("/")

    # Derive from CLERK_PUBLISHABLE_KEY if domain not set
    pk = os.environ.get("CLERK_PUBLISHABLE_KEY", "")
    if pk:
        # pk_live_abc123 → the instance domain is available via Clerk API
        # For now require explicit CLERK_DOMAIN
        pass

    return ""


def _fetch_jwks() -> dict:
    """Fetch and cache Clerk's public keys."""
    global _jwks_cache, _jwks_fetched_at

    if _jwks_cache and (time.time() - _jwks_fetched_at) < _JWKS_TTL:
        return _jwks_cache

    domain = _get_clerk_domain()
    if not domain:
        raise ValueError("CLERK_DOMAIN env var not set — cannot verify Clerk tokens")

    import httpx
    url = f"https://{domain}/.well-known/jwks.json"
    resp = httpx.get(url, timeout=10)
    resp.raise_for_status()
    _jwks_cache = resp.json()
    _jwks_fetched_at = time.time()
    return _jwks_cache


def verify_clerk_token(token: str) -> Optional[ClerkUser]:
    """Verify a Clerk JWT and extract identity claims.

    Returns ClerkUser on success, None on failure.
    """
    try:
        import jwt as pyjwt
        from jwt.algorithms import RSAAlgorithm
    except ImportError:
        logger.error("PyJWT not installed — cannot verify Clerk tokens")
        return None

    try:
        jwks = _fetch_jwks()

        # Decode header to find the right key
        header = pyjwt.get_unverified_header(token)
        kid = header.get("kid")
        if not kid:
            logger.warning("Clerk token missing kid header")
            return None

        # Find matching key
        key_data = None
        for k in jwks.get("keys", []):
            if k.get("kid") == kid:
                key_data = k
                break

        if not key_data:
            # Key not found — maybe rotated. Force refresh.
            global _jwks_fetched_at
            _jwks_fetched_at = 0
            jwks = _fetch_jwks()
            for k in jwks.get("keys", []):
                if k.get("kid") == kid:
                    key_data = k
                    break

        if not key_data:
            logger.warning(f"Clerk JWKS key {kid} not found")
            return None

        public_key = RSAAlgorithm.from_jwk(key_data)

        claims = pyjwt.decode(
            token,
            public_key,
            algorithms=["RS256"],
            options={"verify_aud": False},  # Clerk tokens may not have aud
        )

        # Extract identity
        user_id = claims.get("sub", "")
        email = claims.get("email", "") or claims.get("user_email", "")

        # Organization = tenant
        org_id = claims.get("org_id") or claims.get("org", {}).get("id")
        org_role = claims.get("org_role", "org:member")

        # Metadata overrides (set via Clerk dashboard or API)
        metadata = claims.get("metadata", {}) or claims.get("public_metadata", {})
        role = metadata.get("ohaco_role") or _map_org_role(org_role)
        plan = metadata.get("plan", "pro")

        # Tenant fallback: personal workspace if no org
        tenant_id = org_id or f"personal_{user_id}" if user_id else None

        return ClerkUser(
            user_id=user_id,
            email=email,
            tenant_id=tenant_id,
            role=role,
            plan=plan,
            raw_claims=claims,
        )

    except pyjwt.ExpiredSignatureError:
        logger.info("Clerk token expired")
        return None
    except pyjwt.InvalidTokenError as e:
        logger.warning(f"Clerk token invalid: {e}")
        return None
    except Exception as e:
        logger.error(f"Clerk verification error: {e}")
        return None


def _map_org_role(org_role: str) -> str:
    """Map Clerk organization role to OHACO ABAC role."""
    mapping = {
        "org:admin": "admin",
        "org:member": "contributor",
        "org:viewer": "reader",
        "admin": "admin",
        "member": "contributor",
        "viewer": "reader",
    }
    return mapping.get(org_role, "reader")


def is_clerk_enabled() -> bool:
    """Check if Clerk auth is configured."""
    provider = os.environ.get("AUTH_PROVIDER", "").lower()
    return provider == "clerk" and bool(_get_clerk_domain())
