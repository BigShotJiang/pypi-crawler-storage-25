"""
collab_memory/auth/jwt_provider.py — Self-Hosted JWT Auth Provider

Drop-in replacement for supabase_client.py. No external auth vendor.

Stack:
- argon2-cffi for password hashing (OWASP recommended)
- PyJWT for JWT signing/verification (replaces abandoned python-jose)
- Neo4j User nodes for user storage

Design:
- Same AuthUser dataclass and method signatures as SupabaseAuthClient
- Same bypass mode for local dev (no JWT_SECRET → admin bypass)
- Tokens: 1h access + 7d refresh (configurable via env)

Migration note (Sprint 27, 2026-04-01):
    Replaced python-jose with PyJWT. python-jose is abandoned since 2021,
    has known CVEs, and breaks on Python 3.10+. PyJWT is actively maintained,
    already a transitive dep (via mcp), and supports HS256/RS256/ES256.
"""

from __future__ import annotations

import os
import uuid
import logging
import time
from dataclasses import dataclass
from typing import Optional

from collab_memory.auth.instance_access import (
    instance_login_denied_reason,
    instance_zero_member_emails,
    instance_zero_tenant_id,
    resolve_session_role,
)

logger = logging.getLogger(__name__)


def normalize_email(email: str | None) -> str:
    """Canonical form for lookups and storage (lowercase + strip).

    Prevents duplicate User nodes that differ only by ASCII case or surrounding
    whitespace (e.g. ``info@ohaco.org`` vs ``Info@OHACO.org``).
    """
    if email is None:
        return ""
    s = str(email).strip()
    return s.lower() if s else ""


@dataclass
class AuthUser:
    """Authenticated user extracted from JWT."""
    user_id: str
    email: str
    tenant_id: str
    plan: str = "pro"
    role: str = "contributor"


class JWTAuthProvider:
    """Self-hosted JWT auth provider backed by Neo4j.

    If JWT_SECRET is not set, operates in 'bypass' mode —
    returns a default admin user for local dev.

    Env vars:
        JWT_SECRET          — HMAC signing key (required for production)
        JWT_ACCESS_TTL      — Access token lifetime in seconds (default: 3600)
        JWT_REFRESH_TTL     — Refresh token lifetime in seconds (default: 604800)
    """

    def __init__(self, neo4j_backend=None):
        self._secret = os.environ.get("JWT_SECRET", "")
        self._access_ttl = int(os.environ.get("JWT_ACCESS_TTL", "3600"))
        self._refresh_ttl = int(os.environ.get("JWT_REFRESH_TTL", "604800"))
        self._neo4j = neo4j_backend  # Optional: passed when Neo4j is available
        self._users: dict[str, dict] = {}  # In-memory fallback if no Neo4j

        self._env = os.environ.get("COLLAB_ENV", "development").lower()
        self._is_production = self._env in ("production", "prod", "staging")

        if self._secret:
            logger.info("JWT Auth provider initialized (self-hosted)")
        elif self._is_production:
            logger.warning(
                "JWT_SECRET not set in production — auth endpoints will return 503. "
                "Set JWT_SECRET to enable user authentication."
            )
        else:
            logger.info("JWT_SECRET not set — auth in bypass mode (local dev)")

    @property
    def is_configured(self) -> bool:
        """Whether JWT signing is actually configured."""
        return bool(self._secret)

    # ── Password Policy ─────────────────────────────────────────────────

    # NIST SP 800-63B-4: minimum 8 chars, check for complexity.
    # We require at least one uppercase, one lowercase, one digit.
    # No maximum length (argon2 handles any length safely).
    _MIN_PASSWORD_LENGTH = 8

    @staticmethod
    def validate_password(password: str) -> str | None:
        """Validate password against policy. Returns error string or None if valid.

        Policy (NIST SP 800-63B-4 aligned):
        - Minimum 8 characters
        - At least one uppercase letter
        - At least one lowercase letter
        - At least one digit
        - No maximum length (argon2 handles safely)
        """
        if len(password) < 8:
            return "Password must be at least 8 characters"
        if not any(c.isupper() for c in password):
            return "Password must contain at least one uppercase letter"
        if not any(c.islower() for c in password):
            return "Password must contain at least one lowercase letter"
        if not any(c.isdigit() for c in password):
            return "Password must contain at least one digit"
        return None

    # ── Audit Logging ───────────────────────────────────────────────────

    def _audit_log(self, event: str, email: str, success: bool, detail: str = "") -> None:
        """Log an auth event for security audit trail.

        Writes to both Python logger and (if available) Neo4j AuthAudit nodes.
        """
        level = logging.INFO if success else logging.WARNING
        logger.log(level, "AUTH_AUDIT event=%s email=%s success=%s detail=%s", event, email, success, detail)

        if self._neo4j:
            try:
                self._neo4j._tx_write(
                    """
                    CREATE (a:AuthAudit {
                        id: $id, event: $event, email: $email,
                        success: $success, detail: $detail,
                        timestamp: $ts, ip: $ip
                    })
                    """,
                    id=f"aud_{uuid.uuid4().hex[:8]}",
                    event=event,
                    email=email,
                    success=success,
                    detail=detail,
                    ts=time.time(),
                    ip="",  # populated by middleware if available
                )
            except Exception:
                pass  # Never block auth for audit write failure

        # Emit to SSE for live audit feed
        try:
            from collab_memory.api.sse import emit_event_sync
            emit_event_sync({
                "type": "audit.event",
                "event": event,
                "email": email,
                "success": success,
                "detail": detail,
                "timestamp": time.time(),
            })
        except Exception:
            pass

    # ── Core Methods ─────────────────────────────────────────────────────

    def signup(
        self,
        email: str,
        password: str,
        tenant_name: str = "default",
        tenant_id_override: str | None = None,
        bootstrap_workspace: bool = True,
        *,
        bypass_signup_policy: bool = False,
    ) -> dict:
        """Create a new user + tenant.

        Hashes password with argon2, stores User node in Neo4j.
        Returns: {"user_id": ..., "tenant_id": ..., "access_token": ..., "refresh_token": ...}
        """
        if not self._secret:
            return self._bypass_response(email, "signup")

        email = normalize_email(email)
        if not email or "@" not in email:
            self._audit_log("signup", email or "", False, "invalid_email")
            return {"error": "A valid email is required"}

        # Password policy check
        pw_error = self.validate_password(password)
        if pw_error:
            self._audit_log("signup", email, False, pw_error)
            return {"error": pw_error}

        try:
            from argon2 import PasswordHasher
        except ImportError:
            return {"error": "argon2-cffi not installed"}

        if not bypass_signup_policy:
            from collab_memory.auth.signup_policy import signup_policy_error

            pol = signup_policy_error(self._neo4j, email)
            if pol:
                self._audit_log("signup", email, False, pol)
                return {"error": pol}

        # Check if user already exists
        existing = self._find_user_by_email(email)
        if existing:
            self._audit_log("signup", email, False, "duplicate_email")
            return {"error": "User already exists", "detail": f"Account for {email} already registered"}

        ph = PasswordHasher()
        user_id = str(uuid.uuid4())
        override_tid = (tenant_id_override or "").strip()
        shared_tid = instance_zero_tenant_id()
        shared_members = instance_zero_member_emails()
        is_shared_member = bool(shared_tid and email in shared_members)

        if override_tid:
            tenant_id = override_tid
        elif is_shared_member:
            tenant_id = shared_tid
            # Shared community tenant should not spawn per-user bootstrap projects.
            bootstrap_workspace = False
        else:
            tenant_id = str(uuid.uuid4())
        password_hash = ph.hash(password)

        # Generate email verification token (24h expiry; distinct JWT type from session access)
        verify_token = self._create_token(
            user_id, email, tenant_id, "pro", "contributor", 86400, purpose="verify",
        )

        user_data = {
            "user_id": user_id,
            "email": email,
            "password_hash": password_hash,
            "tenant_id": tenant_id,
            "tenant_name": tenant_name,
            "plan": "pro",
            "role": "contributor",
            "created_at": time.time(),
            "email_verified": False,
            "verify_token": verify_token,
            "verify_expires": int(time.time()) + 86400,
        }

        # Store user
        self._store_user(user_data)

        # Provision Tenant node so the user's keys are reachable via ABAC + tenant API
        api_key_write = None
        api_key_read = None
        if self._neo4j:
            try:
                should_provision_tenant = not override_tid and not is_shared_member
                if should_provision_tenant:
                    from collab_memory.schema import Tenant, TenantPlan
                    tenant_obj = Tenant(
                        id=tenant_id,
                        name=tenant_name or email,
                        email=email,
                        plan=TenantPlan.pro,
                        owner_id=user_id,
                    )
                    self._neo4j.create_tenant(tenant_obj)
                    api_key_write = tenant_obj.api_key_write
                    api_key_read = tenant_obj.api_key_read

                # Auto-create default project so user has a working workspace immediately
                if bootstrap_workspace:
                    try:
                        from collab_memory.schema import Project as _ProjectModel
                        import json as _json
                        _now = str(datetime.fromtimestamp(time.time()))
                        _default_proj = _ProjectModel(
                            name=f"{tenant_name or email}'s Project",
                            tenant_id=tenant_id,
                            owner_id=user_id,
                            members=[_json.dumps({"user_id": user_id, "role": "admin", "added_at": _now})],
                        )
                        if hasattr(self._neo4j, "save_project"):
                            self._neo4j.save_project(_default_proj)
                            logger.info("signup: auto-created default project=%s for tenant=%s", _default_proj.id, tenant_id)

                            # Seed demo memories so the project isn't empty on first visit
                            try:
                                self._seed_demo_memories(self._neo4j, _default_proj.id, tenant_id)
                            except Exception as seed_err:
                                logger.warning("signup: demo memory seeding failed (non-fatal): %s", seed_err)
                    except Exception as proj_err:
                        logger.warning("signup: default project creation failed (non-fatal): %s", proj_err)

            except Exception as e:
                logger.warning(f"Failed to create Tenant node during signup: {e}")

        self._audit_log("signup", email, True, f"user_id={user_id}")

        prepared = self.prepare_user_for_session({**user_data})
        if not prepared:
            return {"error": "This instance only accepts pre-authorized email addresses."}
        access_token = self._create_token(
            prepared["user_id"], prepared["email"], prepared["tenant_id"],
            prepared.get("plan", "free"), prepared.get("role", "contributor"),
            self._access_ttl,
        )
        refresh_token = self._create_token(
            prepared["user_id"], prepared["email"], prepared["tenant_id"],
            prepared.get("plan", "free"), prepared.get("role", "contributor"),
            self._refresh_ttl, is_refresh=True,
        )

        return {
            "user_id": prepared["user_id"],
            "email": prepared["email"],
            "tenant_id": prepared["tenant_id"],
            "email_verified": False,
            "verify_token": verify_token,
            "api_key_write": api_key_write,
            "api_key_read": api_key_read,
            "access_token": access_token,
            "refresh_token": refresh_token,
        }

    # ── Demo memory seeding ────────────────────────────────────────────────────

    @staticmethod
    def _seed_demo_memories(graph, project_id: str, tenant_id: str):
        """
        Seed 3 realistic memory nodes into a new user's default project so
        they see immediate value — not an empty dashboard.

        Nodes demonstrate the three core memory types: Decision, Constraint,
        Preference. Content is generic enough to apply to any project but
        specific enough to show how Semantic Memory captures real decisions.
        """
        from collab_memory.schema import Decision, Constraint, Preference

        demo_nodes = [
            Decision(
                description="Use Semantic Memory as the persistent context layer — every agent session starts with graph context, not a blank slate.",
                rationale="Re-explaining project decisions to AI agents wastes 30-50% of every session. Persistent memory eliminates this.",
                confidence=0.92,
                session_id=f"demo-{project_id}",
                project_id=project_id,
                tenant_id=tenant_id,
                created_by="seed",
                origin="user_stated",
                status="active",
            ),
            Constraint(
                description="All agent-generated outputs must link back to a source decision or conversation — no ungrounded conclusions.",
                confidence=0.95,
                session_id=f"demo-{project_id}",
                project_id=project_id,
                tenant_id=tenant_id,
                created_by="seed",
                origin="user_stated",
                still_active=True,
            ),
            Preference(
                description="Prefer concise, actionable responses over lengthy explanations. Lead with the recommendation, follow with rationale only if asked.",
                confidence=0.88,
                session_id=f"demo-{project_id}",
                project_id=project_id,
                tenant_id=tenant_id,
                created_by="seed",
                type="workflow",
            ),
        ]

        saved = 0
        for node in demo_nodes:
            try:
                graph.save_node(node)
                saved += 1
            except Exception:
                pass
        if saved:
            logger.info("signup: seeded %d demo memories into project=%s", saved, project_id)

    # ── Account lockout (NIST 800-63B §5.2.2, OWASP ASVS V2.2.3) ────────────
    MAX_FAILED_ATTEMPTS = 5
    LOCKOUT_DURATION_SECONDS = 900  # 15 minutes

    def _check_lockout(self, user: dict) -> Optional[dict]:
        """Check if account is locked due to failed attempts. Returns error dict or None."""
        failed = int(user.get("failed_login_attempts", 0))
        if failed < self.MAX_FAILED_ATTEMPTS:
            return None
        locked_at = user.get("locked_at")
        if not locked_at:
            return None
        import time
        try:
            lock_time = float(locked_at)
        except (ValueError, TypeError):
            return None
        remaining = self.LOCKOUT_DURATION_SECONDS - (time.time() - lock_time)
        if remaining > 0:
            return {
                "error": "Account temporarily locked due to too many failed attempts.",
                "retry_after_seconds": int(remaining),
            }
        # Lockout expired — reset
        self._reset_failed_attempts(user["email"])
        return None

    def _increment_failed_attempts(self, email: str) -> None:
        """Increment failed login counter and lock if threshold reached."""
        import time
        en = normalize_email(email)
        if not en:
            return
        if self._neo4j:
            try:
                self._neo4j._tx_write(
                    "MATCH (u:User) WHERE toLower(trim(u.email)) = $email_norm "
                    "SET u.failed_login_attempts = coalesce(u.failed_login_attempts, 0) + 1, "
                    "    u.locked_at = CASE WHEN coalesce(u.failed_login_attempts, 0) + 1 >= $max "
                    "                       THEN $now ELSE u.locked_at END",
                    email_norm=en, max=self.MAX_FAILED_ATTEMPTS, now=str(time.time()),
                )
            except Exception as e:
                logger.warning(f"Failed to increment lockout counter: {e}")

    def _reset_failed_attempts(self, email: str) -> None:
        """Reset failed login counter after successful login."""
        en = normalize_email(email)
        if not en:
            return
        if self._neo4j:
            try:
                self._neo4j._tx_write(
                    "MATCH (u:User) WHERE toLower(trim(u.email)) = $email_norm "
                    "SET u.failed_login_attempts = 0, u.locked_at = null",
                    email_norm=en,
                )
            except Exception:
                pass

    def set_password(self, email: str, new_password: str) -> dict:
        """Set or reset password for an existing user.

        Used for:
        - Superadmin accounts created without passwords (direct Neo4j provisioning)
        - Password reset flows
        - Instance bootstrapping

        Returns: {"status": "ok"} or {"error": "..."}
        """
        email = normalize_email(email)
        if not email:
            return {"error": "A valid email is required"}

        pw_error = self.validate_password(new_password)
        if pw_error:
            return {"error": pw_error}

        try:
            from argon2 import PasswordHasher
        except ImportError:
            return {"error": "argon2-cffi not installed"}

        user = self._find_user_by_email(email)
        if not user:
            self._audit_log("set_password", email, False, "user_not_found")
            return {"error": "User not found"}

        ph = PasswordHasher()
        user["password_hash"] = ph.hash(new_password)
        self._store_user(user)
        self._audit_log("set_password", email, True)
        return {"status": "ok", "email": email}

    def login(self, email: str, password: str) -> dict:
        """Authenticate user and return JWT tokens.

        Returns: {"user_id": ..., "tenant_id": ..., "access_token": ..., "refresh_token": ...}
        """
        if not self._secret:
            return self._bypass_response(email, "login")

        email = normalize_email(email)
        if not email:
            self._audit_log("login", "", False, "invalid_email")
            return {"error": "Login failed — invalid credentials"}

        try:
            from argon2 import PasswordHasher
            from argon2.exceptions import VerifyMismatchError
        except ImportError:
            return {"error": "argon2-cffi not installed"}

        user = self._find_user_by_email(email)
        if not user:
            self._audit_log("login", email, False, "user_not_found")
            return {"error": "Login failed — invalid credentials"}

        # Check account lockout
        lockout = self._check_lockout(user)
        if lockout:
            self._audit_log("login", email, False, "account_locked")
            return lockout

        ph = PasswordHasher()
        try:
            ph.verify(user["password_hash"], password)
        except VerifyMismatchError:
            self._increment_failed_attempts(email)
            self._audit_log("login", email, False, "bad_password")
            return {"error": "Login failed — invalid credentials"}

        # Successful login — reset failed attempts
        self._reset_failed_attempts(email)

        # Rehash if argon2 params changed
        if ph.check_needs_rehash(user["password_hash"]):
            user["password_hash"] = ph.hash(password)
            self._store_user(user)

        user = self.prepare_user_for_session({**user})
        if not user:
            self._audit_log("login", email, False, "instance_allowlist")
            return {"error": "This account is not authorized for this instance."}

        role = user.get("role", "contributor")
        # Superadmins always get admin role regardless of what's stored
        if user.get("is_superadmin"):
            role = "admin"

        access_token = self._create_token(
            user["user_id"], user["email"], user["tenant_id"],
            user.get("plan", "pro"), role,
            self._access_ttl,
            extra={"is_superadmin": True} if user.get("is_superadmin") else {},
        )
        refresh_token = self._create_token(
            user["user_id"], user["email"], user["tenant_id"],
            user.get("plan", "pro"), role,
            self._refresh_ttl, is_refresh=True,
            extra={"is_superadmin": True} if user.get("is_superadmin") else {},
        )

        self._audit_log("login", email, True)
        return {
            "user_id": user["user_id"],
            "email": user["email"],
            "tenant_id": user["tenant_id"],
            "plan": user.get("plan", "free"),
            "access_token": access_token,
            "refresh_token": refresh_token,
        }

    def get_user(self, access_token: str) -> Optional[AuthUser]:
        """Verify JWT and return session-ready user info.

        Used by middleware to validate incoming requests.
        This method intentionally re-applies session preparation so tenant repair,
        instance allowlist checks, and role overrides stay consistent across requests.
        """
        if not self._secret:
            return AuthUser(
                user_id="local-dev",
                email="dev@localhost",
                tenant_id="local-tenant",
                plan="enterprise",
                role="admin",
            )

        payload = self._decode_token(access_token)
        if not payload:
            return None

        if payload.get("type") == "refresh":
            logger.warning("Refresh token used as access token — rejected")
            return None

        email = payload.get("email", "")
        # Prefer DB-backed identity for current role/tenant correctness.
        db_user = self._find_user_by_email(email) if email else None
        if db_user:
            db_user = self.prepare_user_for_session({**db_user})
            if not db_user:
                self._audit_log("session_validate", email, False, "instance_allowlist")
                return None
            return AuthUser(
                user_id=db_user.get("user_id", payload.get("sub", "")),
                email=db_user.get("email", email),
                tenant_id=db_user.get("tenant_id", ""),
                plan=db_user.get("plan", "free"),
                role=db_user.get("role", "contributor"),
            )

        # Fallback to token payload if user row is unavailable.
        # Still enforce current instance allowlist + role override semantics.
        prepared = self.prepare_user_for_session({
            "user_id": payload.get("sub", ""),
            "email": email,
            "tenant_id": payload.get("tenant_id", ""),
            "plan": payload.get("plan", "free"),
            "role": payload.get("role", "contributor"),
            "tenant_name": "",
            "password_hash": "",
        })
        if not prepared:
            self._audit_log("session_validate", email, False, "instance_allowlist")
            return None

        return AuthUser(
            user_id=prepared.get("user_id", payload.get("sub", "")),
            email=prepared.get("email", email),
            tenant_id=prepared.get("tenant_id", ""),
            plan=prepared.get("plan", "free"),
            role=prepared.get("role", "contributor"),
        )

    def refresh_session(self, refresh_token: str) -> dict:
        """Exchange refresh token for new access + refresh pair."""
        if not self._secret:
            return self._bypass_response("dev@localhost", "refresh")

        payload = self._decode_token(refresh_token)
        if not payload:
            self._audit_log("refresh", "unknown", False, "invalid_token")
            return {"error": "Refresh failed — invalid token"}

        if payload.get("type") != "refresh":
            self._audit_log("refresh", payload.get("email", ""), False, "wrong_token_type")
            return {"error": "Refresh failed — not a refresh token"}

        email = payload.get("email", "")
        db_user = self._find_user_by_email(email) if email else None
        if db_user:
            db_user = self.prepare_user_for_session({**db_user})
            if not db_user:
                self._audit_log("refresh", email, False, "instance_allowlist")
                return {"error": "Refresh failed — this session is no longer authorized."}
            sub = db_user["user_id"]
            tid = db_user["tenant_id"]
            plan = db_user.get("plan", "free")
            role = db_user.get("role", "contributor")
        else:
            sub = payload["sub"]
            tid = payload.get("tenant_id", "")
            plan = payload.get("plan", "free")
            role = payload.get("role", "contributor")

        access_token = self._create_token(
            sub, email or payload.get("email", ""), tid,
            plan, role,
            self._access_ttl,
        )
        new_refresh = self._create_token(
            sub, email or payload.get("email", ""), tid,
            plan, role,
            self._refresh_ttl, is_refresh=True,
        )

        self._audit_log("refresh", payload.get("email", ""), True)
        return {
            "access_token": access_token,
            "refresh_token": new_refresh,
        }

    # ── Token Helpers ────────────────────────────────────────────────────

    def _create_token(
        self, user_id: str, email: str, tenant_id: str,
        plan: str, role: str, ttl: int, is_refresh: bool = False,
        extra: dict | None = None,
        *, purpose: Optional[str] = None,
    ) -> str:
        """Create a signed JWT using PyJWT.

        ``purpose="verify"`` sets ``type: verify`` (email confirmation). Session tokens use
        ``access`` or ``refresh``. Legacy verification JWTs may still show ``type: access``
        but remain valid until they expire or are rotated.
        """
        import jwt

        now = time.time()
        if is_refresh:
            typ = "refresh"
        elif purpose == "verify":
            typ = "verify"
        else:
            typ = "access"
        payload = {
            "sub": user_id,
            "email": email,
            "tenant_id": tenant_id,
            "plan": plan,
            "role": role,
            "iat": int(now),
            "exp": int(now + ttl),
            "type": typ,
        }
        if extra:
            payload.update(extra)
        return jwt.encode(payload, self._secret, algorithm="HS256")

    def _decode_token(self, token: str) -> Optional[dict]:
        """Decode and verify a JWT using PyJWT. Returns payload or None."""
        import jwt

        try:
            return jwt.decode(token, self._secret, algorithms=["HS256"])
        except jwt.InvalidTokenError as e:
            logger.warning(f"JWT decode failed: {e}")
            return None

    # ── User Storage ─────────────────────────────────────────────────────

    def ensure_valid_tenant_for_user(self, user: dict) -> dict:
        """Ensure user has a real tenant UUID (not missing, empty, or legacy 'default').

        JWT write middleware rejects tenant_id ``default``; older or social-linked users
        may lack a proper tenant. Persists the user and creates a Tenant node when Neo4j
        is available (same idea as signup provisioning).
        """
        if not user or not self._secret:
            return user
        tid = (user.get("tenant_id") or "").strip()
        if tid and tid != "default":
            return user

        new_tid = str(uuid.uuid4())
        user["tenant_id"] = new_tid
        if not (user.get("tenant_name") or "").strip():
            user["tenant_name"] = (user.get("email") or "workspace").split("@")[0] or "workspace"

        if self._neo4j:
            try:
                from collab_memory.schema import Tenant, TenantPlan

                tenant_obj = Tenant(
                    id=new_tid,
                    name=user.get("tenant_name") or user.get("email", ""),
                    email=user.get("email", ""),
                    plan=TenantPlan.free,
                    owner_id=user.get("user_id", ""),
                )
                self._neo4j.create_tenant(tenant_obj)
            except Exception as e:
                logger.warning("ensure_valid_tenant_for_user: create_tenant failed (user still updated): %s", e)

        try:
            self._store_user(user)
        except Exception as e:
            logger.warning("ensure_valid_tenant_for_user: store_user failed: %s", e)

        self._audit_log("tenant_repair", user.get("email", ""), True, f"new_tenant_id={new_tid}")
        return user

    def _rehome_instance_zero_if_configured(self, user: dict) -> dict:
        """Point INSTANCE_ZERO_MEMBER_EMAILS users at INSTANCE_ZERO_TENANT_ID (shared workspace)."""
        zero_tid = instance_zero_tenant_id()
        members = instance_zero_member_emails()
        if not zero_tid or not members:
            return user
        email_norm = normalize_email(user.get("email", ""))
        if email_norm not in members:
            return user
        cur = (user.get("tenant_id") or "").strip()
        if cur == zero_tid:
            return user
        user = {**user, "tenant_id": zero_tid}
        try:
            self._store_user(user)
        except Exception as e:
            logger.warning("instance zero rehome: store_user failed: %s", e)
        self._audit_log(
            "tenant_rehome",
            email_norm,
            True,
            f"instance_zero_tenant_id={zero_tid}",
        )
        return user

    def prepare_user_for_session(self, user: dict) -> Optional[dict]:
        """Ensure tenant, apply instance-zero rehome, resolve JWT role. None if email barred."""
        if not user:
            return None
        email_norm = normalize_email(user.get("email", ""))
        if instance_login_denied_reason(email_norm):
            return None
        u = {**user}
        u = self.ensure_valid_tenant_for_user(u)
        u = self._rehome_instance_zero_if_configured(u)
        u["role"] = resolve_session_role(email_norm, u.get("role", "contributor"))
        return u

    def _find_user_by_email(self, email: str) -> Optional[dict]:
        """Find user by email — Neo4j first, in-memory fallback (case-insensitive)."""
        en = normalize_email(email)
        if not en:
            return None
        if self._neo4j:
            try:
                u = self._neo4j_find_user(en)
                if u:
                    u["email"] = normalize_email(u.get("email", "")) or en
                return u
            except Exception as e:
                logger.warning(f"Neo4j user lookup failed: {e} — using in-memory")

        return self._users.get(en)

    def _store_user(self, user_data: dict) -> None:
        """Store user — Neo4j first, in-memory fallback."""
        email = normalize_email(user_data.get("email", ""))
        if not email:
            raise ValueError("Cannot store user without a valid email")
        user_data = {**user_data, "email": email}

        if self._neo4j:
            try:
                self._neo4j_store_user(user_data)
                logger.info(f"User {email} stored in Neo4j")
            except Exception as e:
                logger.warning(f"Neo4j user store failed: {e} — using in-memory")
                self._users[email] = user_data
        else:
            self._users[email] = user_data
            logger.info(f"User {email} stored in-memory (no Neo4j)")

    def _neo4j_find_user(self, email_norm: str) -> Optional[dict]:
        """Query Neo4j for user by normalized email (case-insensitive on stored value)."""
        rows = self._neo4j._tx_read(
            "MATCH (u:User) WHERE toLower(trim(u.email)) = $email_norm "
            "RETURN u {.*} AS user LIMIT 2",
            email_norm=email_norm,
        )
        if len(rows) > 1:
            logger.warning(
                "Multiple User nodes for normalized email %s — using first match",
                email_norm,
            )
        if rows:
            return rows[0].get("user")
        return None

    def _neo4j_store_user(self, user_data: dict) -> None:
        """Create or update User in Neo4j; always persist canonical lowercase email."""
        data = {
            "email_verified": False,
            "verify_token": None,
            "verify_expires": None,
        }
        data.update(user_data)
        email = normalize_email(data["email"])
        if not email:
            raise ValueError("Cannot store user without a valid email")
        data["email"] = email
        email_norm = email

        existing = self._neo4j._tx_read(
            "MATCH (u:User) WHERE toLower(trim(u.email)) = $email_norm RETURN 1 AS ok LIMIT 2",
            email_norm=email_norm,
        )
        if len(existing) > 1:
            logger.warning(
                "Duplicate User nodes for %s — update applies to one row only",
                email_norm,
            )

        if existing:
            self._neo4j._tx_write(
                """
                MATCH (u:User)
                WHERE toLower(trim(u.email)) = $email_norm
                WITH u LIMIT 1
                SET u.email = $email,
                    u.user_id = $user_id,
                    u.password_hash = $password_hash,
                    u.tenant_id = $tenant_id,
                    u.tenant_name = $tenant_name,
                    u.plan = $plan,
                    u.role = $role,
                    u.created_at = $created_at,
                    u.email_verified = COALESCE($email_verified, u.email_verified, false),
                    u.verify_token = $verify_token,
                    u.verify_expires = $verify_expires,
                    u.updated_at = timestamp()
                """,
                email_norm=email_norm,
                **data,
            )
        else:
            self._neo4j._tx_write(
                """
                CREATE (u:User {
                    email: $email,
                    user_id: $user_id,
                    password_hash: $password_hash,
                    tenant_id: $tenant_id,
                    tenant_name: $tenant_name,
                    plan: $plan,
                    role: $role,
                    created_at: $created_at,
                    email_verified: COALESCE($email_verified, false),
                    verify_token: $verify_token,
                    verify_expires: $verify_expires
                })
                SET u.updated_at = timestamp()
                """,
                **data,
            )

    def request_password_reset(self, email: str) -> dict:
        """Generate a short-lived reset token and store it on the User node.

        In production, this token would be emailed. For self-hosted deployments
        the token is returned directly so the operator can relay it out-of-band.
        Token expires in 1 hour.
        """
        if not self._secret:
            return {"reset_token": "bypass-reset", "email": email, "_bypass": True}

        email = normalize_email(email)
        user = self._find_user_by_email(email)
        if not user:
            # Don't reveal whether the account exists
            return {"status": "ok", "message": "If that email is registered, a reset token has been issued."}

        user = self.ensure_valid_tenant_for_user({**user})

        cemail = normalize_email(user.get("email", ""))
        reset_token = self._create_token(
            user["user_id"], cemail, user["tenant_id"],
            user.get("plan", "free"), user.get("role", "contributor"),
            3600, is_refresh=False,
        )

        if self._neo4j:
            try:
                self._neo4j._tx_write(
                    "MATCH (u:User) WHERE toLower(trim(u.email)) = $email_norm "
                    "SET u.reset_token = $token, u.reset_expires = $exp",
                    email_norm=cemail,
                    token=reset_token,
                    exp=int(time.time()) + 3600,
                )
            except Exception as e:
                logger.warning(f"Failed to store reset token: {e}")

        return {
            "status": "ok",
            "reset_token": reset_token,
            "message": "Reset token issued. Use POST /auth/reset-password with the token and new password.",
            "expires_in": 3600,
        }

    def reset_password(self, reset_token: str, new_password: str) -> dict:
        """Verify reset token and update password."""
        if not self._secret:
            return {"status": "ok", "message": "Password reset (bypass mode)"}

        payload = self._decode_token(reset_token)
        if not payload:
            return {"error": "Invalid or expired reset token"}

        email = normalize_email(payload.get("email", ""))
        user = self._find_user_by_email(email)
        if not user:
            return {"error": "Invalid reset token"}

        # Verify token matches what's stored (prevents token reuse after rotation)
        if self._neo4j:
            try:
                rows = self._neo4j._tx_read(
                    "MATCH (u:User) WHERE toLower(trim(u.email)) = $email_norm "
                    "RETURN u.reset_token AS token, u.reset_expires AS exp",
                    email_norm=email,
                )
                if not rows or rows[0].get("token") != reset_token:
                    return {"error": "Reset token already used or invalid"}
                if rows[0].get("exp", 0) < int(time.time()):
                    return {"error": "Reset token has expired"}
            except Exception as e:
                logger.warning(f"Reset token verification failed: {e}")

        # Enforce password policy on reset (same as signup)
        policy_err = self.validate_password(new_password)
        if policy_err:
            return {"error": policy_err}

        try:
            from argon2 import PasswordHasher
        except ImportError:
            return {"error": "argon2-cffi not installed"}

        ph = PasswordHasher()
        user["password_hash"] = ph.hash(new_password)
        self._store_user(user)

        # Invalidate the token
        if self._neo4j:
            try:
                self._neo4j._tx_write(
                    "MATCH (u:User) WHERE toLower(trim(u.email)) = $email_norm "
                    "REMOVE u.reset_token, u.reset_expires",
                    email_norm=email,
                )
            except Exception as e:
                logger.warning(f"Failed to clear reset token: {e}")

        return {"status": "ok", "message": "Password updated. You can now log in with your new password."}

    # ── Email verification ──────────────────────────────────────────────────
    VERIFY_GRACE_PERIOD = 86400  # 24h — users can log in unverified for this long

    def verify_email(self, verify_token: str) -> dict:
        """Validate verification token and mark email as verified."""
        if not self._secret:
            return {"status": "ok", "message": "Email verified (bypass mode)"}

        payload = self._decode_token(verify_token)
        if not payload:
            return {"error": "Invalid or expired verification token"}

        email = normalize_email(payload.get("email", ""))
        user = self._find_user_by_email(email)
        if not user:
            return {"error": "Invalid verification token"}

        if user.get("email_verified"):
            return {"status": "ok", "message": "Email already verified."}

        # Verify token matches stored token
        stored_token = user.get("verify_token", "")
        if stored_token and stored_token != verify_token:
            return {"error": "Verification token already used or invalid"}

        cemail = normalize_email(user.get("email", "")) or email

        # Mark verified
        if self._neo4j:
            try:
                self._neo4j._tx_write(
                    """MATCH (u:User) WHERE toLower(trim(u.email)) = $email_norm
                    SET u.email_verified = true
                    REMOVE u.verify_token, u.verify_expires""",
                    email_norm=cemail,
                )
            except Exception as e:
                logger.warning(f"Email verification update failed: {e}")
        else:
            user["email_verified"] = True
            user.pop("verify_token", None)
            self._users[cemail] = user

        self._audit_log("email_verify", cemail, True)
        return {"status": "ok", "message": "Email verified successfully."}

    def resend_verification(self, email: str) -> dict:
        """Generate a new verification token for an unverified user."""
        if not self._secret:
            return {"status": "ok", "verify_token": "bypass-verify"}

        user = self._find_user_by_email(email)
        if not user:
            return {"status": "ok", "message": "If that email is registered, a verification link has been sent."}

        if user.get("email_verified"):
            return {"status": "ok", "message": "Email already verified."}

        cemail = normalize_email(user.get("email", ""))

        verify_token = self._create_token(
            user["user_id"], cemail, user["tenant_id"],
            user.get("plan", "free"), user.get("role", "contributor"),
            86400,
            purpose="verify",
        )

        if self._neo4j:
            try:
                self._neo4j._tx_write(
                    "MATCH (u:User) WHERE toLower(trim(u.email)) = $email_norm "
                    "SET u.verify_token = $token, u.verify_expires = $exp",
                    email_norm=cemail, token=verify_token, exp=int(time.time()) + 86400,
                )
            except Exception as e:
                logger.warning(f"Failed to store verification token: {e}")

        return {
            "status": "ok",
            "verify_token": verify_token,
            "message": "Verification token issued. Valid for 24 hours.",
        }

    def is_email_verified(self, email: str) -> bool:
        """Check if user's email is verified. Returns True if verified or in grace period."""
        user = self._find_user_by_email(email)
        if not user:
            return False
        if user.get("email_verified"):
            return True
        # Grace period: allow login for 24h after signup
        created = user.get("created_at", 0)
        if time.time() - created < self.VERIFY_GRACE_PERIOD:
            return True  # still in grace period
        return False

    # ── Bypass ───────────────────────────────────────────────────────────

    def _bypass_response(self, email: str, action: str) -> dict:
        """Return mock response when JWT_SECRET is not configured."""
        if self._is_production:
            raise ValueError(
                "JWT_SECRET is not set. Authentication is disabled in production. "
                "Set the JWT_SECRET environment variable to enable user auth."
            )
        logger.debug(f"Auth bypass: {action} for {email}")
        return {
            "user_id": "local-dev",
            "email": email,
            "tenant_id": "local-tenant",
            "plan": "enterprise",
            "access_token": "bypass-token",
            "refresh_token": "bypass-refresh",
            "_bypass": True,
        }
