"""
collab_memory/auth/saml_routes.py — SAML SSO API Routes

Routes:
    GET  /sso/saml/login?org=<slug>     — Redirect to IdP for SSO login
    POST /sso/saml/acs                  — Assertion Consumer Service (IdP callback)
    GET  /sso/saml/metadata             — SP metadata XML for IdP configuration
    POST /sso/saml/configure            — Admin: configure SAML for an org
    GET  /sso/saml/status               — Check if SAML SSO is available

Integration with existing auth:
    On successful SAML assertion, we find-or-create the user via jwt_provider,
    issue our standard JWT tokens, and redirect to the dashboard.
    The user is indistinguishable from a password-authenticated user after login.
"""
from __future__ import annotations

import logging
from typing import Optional

from fastapi import APIRouter, HTTPException, Query, Request
from fastapi.responses import RedirectResponse, Response
from pydantic import BaseModel

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/sso", tags=["sso"])

# Module-level SAML SP — initialized lazily
_saml_sp = None


def _get_saml_sp():
    """Lazy-init the SAML SP with the Neo4j backend."""
    global _saml_sp
    if _saml_sp is None:
        try:
            from collab_memory.auth.saml_sp import SAMLServiceProvider
            from collab_memory.api import server as _server
            neo4j = getattr(_server, "graph", None)
            _saml_sp = SAMLServiceProvider(neo4j_backend=neo4j)
        except ImportError:
            logger.warning("python3-saml not installed — SSO disabled")
            return None
    return _saml_sp


def _extract_request_data(request: Request) -> dict:
    """Extract request data in the format python3-saml expects."""
    return {
        "scheme": request.url.scheme,
        "host": request.url.hostname or "localhost",
        "port": request.url.port or (443 if request.url.scheme == "https" else 80),
        "path": request.url.path,
        "get_data": dict(request.query_params),
        "post_data": {},  # Will be populated for POST requests
    }


# ── Request models ───────────────────────────────────────────────────────────

class SAMLConfigRequest(BaseModel):
    """Admin request to configure SAML SSO for an organization."""
    org_slug: str
    tenant_id: str
    idp_entity_id: str
    idp_sso_url: str
    idp_slo_url: str = ""
    idp_x509_cert: str
    attribute_map: dict = {}


# ── Routes ───────────────────────────────────────────────────────────────────

@router.get("/saml/login", summary="Initiate SAML SSO login")
async def saml_login(
    request: Request,
    org: str = Query(..., description="Organization slug for SAML config lookup"),
):
    """
    Redirect user to their organization's IdP for SSO authentication.

    The org parameter determines which IdP to redirect to.
    After authentication, the IdP will POST back to /sso/saml/acs.
    """
    sp = _get_saml_sp()
    if not sp:
        raise HTTPException(status_code=503, detail="SAML SSO is not available (python3-saml not installed)")

    config = sp.get_config(org)
    if not config:
        raise HTTPException(
            status_code=404,
            detail=f"No SAML configuration found for organization '{org}'",
        )

    if not config.enabled:
        raise HTTPException(status_code=403, detail=f"SAML SSO is disabled for '{org}'")

    request_data = _extract_request_data(request)

    try:
        redirect_url, request_id = sp.initiate_login(config, request_data)
    except Exception as e:
        logger.error("SAML login initiation failed for org=%s: %s", org, e)
        raise HTTPException(status_code=500, detail=f"SAML login failed: {e}")

    return RedirectResponse(url=redirect_url, status_code=302)


@router.post("/saml/acs", summary="SAML Assertion Consumer Service")
async def saml_acs(request: Request):
    """
    Receive and validate SAML assertion from the IdP.

    This is the callback URL that the IdP POSTs to after user authentication.
    On success: find-or-create user, issue JWT, redirect to dashboard.
    On failure: return error details for debugging.
    """
    sp = _get_saml_sp()
    if not sp:
        raise HTTPException(status_code=503, detail="SAML SSO is not available")

    # Parse the POST body
    form_data = await request.form()
    saml_response = form_data.get("SAMLResponse", "")
    relay_state = form_data.get("RelayState", "")

    if not saml_response:
        raise HTTPException(status_code=400, detail="Missing SAMLResponse in POST body")

    # We need to determine which org this response is for.
    # RelayState typically carries the org slug or return URL.
    org_slug = relay_state or ""

    # If RelayState doesn't have the org, try to decode the response to find the issuer
    # For now, require RelayState to contain the org slug
    if not org_slug:
        raise HTTPException(
            status_code=400,
            detail="Missing RelayState — cannot determine organization. "
                   "Ensure your IdP is configured to send RelayState.",
        )

    config = sp.get_config(org_slug)
    if not config:
        raise HTTPException(status_code=404, detail=f"No SAML config for org '{org_slug}'")

    request_data = _extract_request_data(request)
    request_data["post_data"] = {"SAMLResponse": saml_response}

    # Validate the assertion
    success, user_attrs, errors = sp.process_response(config, request_data)

    if not success:
        logger.warning("SAML ACS validation failed: %s", errors)
        raise HTTPException(
            status_code=401,
            detail={
                "error": "SAML authentication failed",
                "errors": errors,
                "hint": "Check IdP certificate, clock skew, and assertion signing.",
            },
        )

    # ── Find or create user ──────────────────────────────────────────────
    email = user_attrs.get("email", "")
    if not email:
        raise HTTPException(status_code=400, detail="SAML assertion did not contain an email address")

    try:
        from collab_memory.auth.middleware import get_auth_client
        auth_client = get_auth_client()

        # Try to find existing user
        existing = auth_client._find_user_by_email(email)

        if existing:
            # Existing user — issue tokens
            access_token = auth_client._create_token(
                existing["user_id"], email, config.tenant_id,
                existing.get("plan", "free"), existing.get("role", "contributor"),
                auth_client._access_ttl,
            )
            refresh_token = auth_client._create_token(
                existing["user_id"], email, config.tenant_id,
                existing.get("plan", "free"), existing.get("role", "contributor"),
                auth_client._refresh_ttl, is_refresh=True,
            )
        else:
            # New user via SSO — create account (no password needed)
            import uuid
            result = auth_client.signup(
                email,
                uuid.uuid4().hex,
                config.tenant_id,
                bypass_signup_policy=True,
            )
            if "error" in result:
                raise HTTPException(status_code=500, detail=f"User creation failed: {result['error']}")
            access_token = result["access_token"]
            refresh_token = result["refresh_token"]

    except HTTPException:
        raise
    except Exception as e:
        logger.error("SAML user provisioning failed: %s", e)
        raise HTTPException(status_code=500, detail=f"User provisioning failed: {e}")

    # Redirect to dashboard with tokens
    # In production, set tokens as httpOnly cookies instead of URL params
    base_url = str(request.base_url).rstrip("/")
    redirect_url = f"{base_url}/?sso=success&token={access_token}"

    logger.info("SAML SSO login successful: email=%s, org=%s", email, org_slug)
    return RedirectResponse(url=redirect_url, status_code=302)


@router.get("/saml/metadata", summary="SP metadata XML")
async def saml_metadata():
    """
    Return SAML SP metadata XML.

    Provide this URL to your IdP administrator when configuring SSO.
    The metadata contains our entity ID, ACS URL, and signing certificate.
    """
    sp = _get_saml_sp()
    if not sp:
        raise HTTPException(status_code=503, detail="SAML SSO is not available")

    try:
        metadata = sp.get_metadata()
        return Response(content=metadata, media_type="application/xml")
    except Exception as e:
        logger.error("SP metadata generation failed: %s", e)
        raise HTTPException(status_code=500, detail=f"Metadata generation failed: {e}")


@router.post("/saml/configure", summary="Configure SAML for an organization")
async def saml_configure(req: SAMLConfigRequest, request: Request):
    """
    Admin endpoint: configure SAML SSO for a tenant/organization.

    Requires admin API key. Stores the IdP metadata so users from this
    org can authenticate via /sso/saml/login?org=<slug>.
    """
    from collab_memory.abac import AgentContext
    agent = getattr(request.state, "agent", AgentContext())
    if not getattr(agent, "is_admin", False):
        raise HTTPException(status_code=403, detail="SAML configuration requires admin role")

    sp = _get_saml_sp()
    if not sp:
        raise HTTPException(status_code=503, detail="SAML SSO is not available")

    from collab_memory.auth.saml_sp import SSOConfig
    config = SSOConfig(
        org_slug=req.org_slug,
        tenant_id=req.tenant_id,
        idp_entity_id=req.idp_entity_id,
        idp_sso_url=req.idp_sso_url,
        idp_slo_url=req.idp_slo_url,
        idp_x509_cert=req.idp_x509_cert,
        attribute_map=req.attribute_map or {
            "email": "email",
            "first_name": "firstName",
            "last_name": "lastName",
        },
    )

    try:
        sp.save_config(config)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Config save failed: {e}")

    return {
        "status": "ok",
        "org_slug": config.org_slug,
        "tenant_id": config.tenant_id,
        "idp_entity_id": config.idp_entity_id,
        "acs_url": sp._sp_acs_url,
        "metadata_url": sp._sp_metadata_url,
        "message": f"SAML configured for '{config.org_slug}'. "
                   f"Give your IdP admin the ACS URL and metadata URL above.",
    }


@router.get("/saml/status", summary="SAML SSO availability check")
async def saml_status():
    """Check whether SAML SSO is available and configured."""
    sp = _get_saml_sp()
    available = sp is not None

    orgs = []
    if sp and sp._neo4j:
        try:
            rows = sp._neo4j._tx_read(
                "MATCH (s:SSOConfig {enabled: true}) RETURN s.org_slug AS slug"
            )
            orgs = [r["slug"] for r in rows]
        except Exception:
            pass

    return {
        "saml_available": available,
        "configured_orgs": orgs,
        "sp_entity_id": sp._sp_entity_id if sp else None,
        "sp_acs_url": sp._sp_acs_url if sp else None,
        "sp_metadata_url": sp._sp_metadata_url if sp else None,
    }
