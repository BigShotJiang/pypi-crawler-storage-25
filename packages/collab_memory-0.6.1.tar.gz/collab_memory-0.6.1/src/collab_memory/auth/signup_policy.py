"""Shared rules for whether self-serve signup (email/password or social provision) is allowed."""

from __future__ import annotations

import logging
import os
from typing import Any, Optional

from collab_memory.auth.instance_access import instance_signup_denied_reason
from collab_memory.auth.jwt_provider import normalize_email

logger = logging.getLogger(__name__)

SIGNUP_CLOSED_DETAIL = (
    "Self-serve signup is disabled. Request access at /apply or use an invite link."
)

# AccessRequest.status values that mean “may create an account” (after ops review).
_ACCESS_GRANT_STATUSES = frozenset({"approved", "invited", "provisioned"})


def _env_truthy(name: str, default: bool = False) -> bool:
    raw = os.environ.get(name, "")
    if raw == "":
        return default
    return raw.strip().lower() in ("true", "1", "yes")


def _owner_login_allowlist() -> set[str]:
    """Comma-separated OWNER_LOGIN_EMAILS (normalized) — always allowed to self-provision."""
    raw = os.environ.get("OWNER_LOGIN_EMAILS", "").strip()
    if not raw:
        return set()
    out: set[str] = set()
    for part in raw.split(","):
        e = normalize_email(part)
        if e:
            out.add(e)
    return out


def _access_request_allows_signup(neo4j: Any, email_norm: str) -> bool:
    if not neo4j or not email_norm:
        return False
    try:
        rows = neo4j._tx_read(
            """
            MATCH (a:AccessRequest)
            WHERE toLower(trim(a.email)) = $email
              AND toLower(trim(coalesce(a.status, ''))) IN $statuses
            RETURN count(a) AS c
            """,
            email=email_norm,
            statuses=list(_ACCESS_GRANT_STATUSES),
        )
        return bool(rows and int(rows[0].get("c", 0)) > 0)
    except Exception as e:
        logger.warning("signup policy: AccessRequest check failed: %s", e)
        return False


def signup_policy_error(neo4j: Any, applicant_email: Optional[str] = None) -> Optional[str]:
    """Return a user-facing error string if signup must be rejected, else None.

    Precedence:
    0. ``ALLOWED_INSTANCE_LOGIN_EMAILS`` (when set) → only listed emails may sign up.
    1. ``ALLOW_PUBLIC_SIGNUP`` → allow anyone (still subject to 0).
    2. Applicant email in ``OWNER_LOGIN_EMAILS`` → allow (instance owner / ops).
    3. Applicant email has ``AccessRequest`` with status approved / invited / provisioned → allow.
    4. ``ALLOW_BOOTSTRAP_SIGNUP`` and (no Neo4j or zero users) → allow (local / first deploy).
    5. Otherwise → closed (use invites or /apply).
    """
    email_norm = normalize_email(applicant_email) if applicant_email else ""

    inst_err = instance_signup_denied_reason(email_norm)
    if inst_err:
        return inst_err

    if _env_truthy("ALLOW_PUBLIC_SIGNUP", default=False):
        return None

    if email_norm and email_norm in _owner_login_allowlist():
        return None

    if email_norm and _access_request_allows_signup(neo4j, email_norm):
        return None

    if _env_truthy("ALLOW_BOOTSTRAP_SIGNUP", default=False):
        if neo4j:
            try:
                rows = neo4j._tx_read("MATCH (u:User) RETURN count(u) AS c")
                cnt = int(rows[0].get("c", 0)) if rows else 0
                if cnt == 0:
                    return None
            except Exception as e:
                logger.warning("signup policy: user count read failed: %s", e)
                return "Signup temporarily unavailable — cannot verify account policy."
        else:
            return None

    return SIGNUP_CLOSED_DETAIL


def is_policy_unavailable_error(message: str) -> bool:
    return "temporarily unavailable" in (message or "").lower()
