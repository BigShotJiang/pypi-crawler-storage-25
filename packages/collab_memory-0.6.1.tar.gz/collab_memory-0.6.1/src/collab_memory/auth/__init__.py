"""
collab_memory/auth — Self-Hosted JWT Auth Integration

Provides user authentication, tenant isolation, and encrypted
LLM key vault for the Co-Lab proxy layer.

Modules:
    jwt_provider    — Self-hosted JWT auth (argon2 + PyJWT + Neo4j)
    middleware      — FastAPI JWT + X-API-Key dual auth middleware
    vault           — AES-256-GCM encrypted storage for user LLM keys
    routes          — /auth/* endpoints (signup, login, keys, me)
"""

from collab_memory.auth.jwt_provider import JWTAuthProvider, AuthUser
from collab_memory.auth.vault import LLMKeyVault
from collab_memory.auth.middleware import get_current_user, jwt_or_apikey_auth, init_auth_client

__all__ = [
    "JWTAuthProvider",
    "AuthUser",
    "LLMKeyVault",
    "get_current_user",
    "jwt_or_apikey_auth",
    "init_auth_client",
]
