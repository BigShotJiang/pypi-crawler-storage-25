"""OHACO transactional email shell — table layout, inline CSS, dark header (email-client safe)."""

from __future__ import annotations

import html as html_module


def render_branded_email(
    *,
    title: str,
    preheader: str,
    inner_html: str,
    cta_href: str = "",
    cta_label: str = "",
) -> str:
    """Return a full HTML document. ``inner_html`` is already safe or trusted caller HTML."""
    t = html_module.escape(title)
    ph = html_module.escape(preheader)
    year = "2026"

    cta_block = ""
    if cta_href and cta_label:
        safe_href = html_module.escape(cta_href, quote=True)
        safe_label = html_module.escape(cta_label)
        cta_block = f"""
        <tr>
          <td style="padding:8px 0 28px 0;">
            <a href="{safe_href}" style="display:inline-block;background:linear-gradient(135deg,#6c5ce7,#a29bfe);color:#ffffff !important;text-decoration:none;font-weight:700;font-size:15px;padding:14px 28px;border-radius:10px;font-family:Inter,-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;">
              {safe_label}
            </a>
          </td>
        </tr>"""

    return f"""<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>{t}</title>
</head>
<body style="margin:0;padding:0;background:#0c0c12;">
  <div style="display:none;font-size:1px;color:#0c0c12;line-height:1px;max-height:0;max-width:0;opacity:0;overflow:hidden;">
    {ph}
  </div>
  <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="background:#0c0c12;">
    <tr>
      <td align="center" style="padding:32px 16px 48px 16px;">
        <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="max-width:560px;background:#12121c;border-radius:16px;border:1px solid #2a2a3c;overflow:hidden;">
          <tr>
            <td style="background:linear-gradient(135deg,#1a1535 0%,#12121c 55%,#15102a 100%);padding:28px 32px 22px 32px;border-bottom:1px solid #2a2a3c;">
              <div style="font-family:Inter,-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;font-size:11px;font-weight:700;letter-spacing:0.2em;text-transform:uppercase;color:#a29bfe;margin-bottom:8px;">OHACO Labs</div>
              <div style="font-family:Inter,-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;font-size:22px;font-weight:700;line-height:1.25;color:#f0f0f8;">{t}</div>
            </td>
          </tr>
          <tr>
            <td style="padding:28px 32px 8px 32px;font-family:Inter,-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;font-size:15px;line-height:1.6;color:#d8d8e8;">
              {inner_html}
            </td>
          </tr>
          {cta_block}
          <tr>
            <td style="padding:0 32px 28px 32px;font-family:Inter,-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;font-size:12px;line-height:1.55;color:#7a7a92;">
              Semantic Dreams — your data, your graph, your agents. Questions? Reply to this email if your mailbox allows it, or contact your workspace owner.
            </td>
          </tr>
          <tr>
            <td style="padding:16px 32px 24px 32px;border-top:1px solid #2a2a3c;font-family:Inter,-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;font-size:11px;color:#5c5c72;line-height:1.5;">
              © {year} OHACO Labs · <a href="https://ohaco.org" style="color:#a29bfe;text-decoration:none;">ohaco.org</a>
              <span style="color:#3d3d52;"> · </span>
              <a href="https://ohaco.ai" style="color:#a29bfe;text-decoration:none;">ohaco.ai</a>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>"""
