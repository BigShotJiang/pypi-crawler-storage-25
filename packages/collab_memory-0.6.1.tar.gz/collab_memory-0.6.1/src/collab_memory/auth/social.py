"""
collab_memory/auth/social.py — OAuth 2.0 Social Login (GitHub + Google)

Uses Authlib for OAuth 2.0 / OIDC integration. Supports:
- GitHub OAuth (login with GitHub account)
- Google OIDC (login with Google account)

Flow:
    1. User hits GET /auth/social/{provider}/login → redirect to provider
    2. Provider authenticates user, redirects back to /auth/social/{provider}/callback
    3. We exchange the code for tokens, fetch user profile
    4. Find-or-create user via jwt_provider, issue our JWT tokens
    5. Redirect to dashboard with tokens

Env vars:
    GITHUB_CLIENT_ID        — GitHub OAuth app client ID
    GITHUB_CLIENT_SECRET    — GitHub OAuth app client secret
    GOOGLE_CLIENT_ID        — Google OAuth client ID
    GOOGLE_CLIENT_SECRET    — Google OAuth client secret
    COLLAB_PUBLIC_URL       — Public origin for OAuth callback (no trailing slash).
                              Must match the “Authorization callback URL” in the GitHub OAuth app:
                              {COLLAB_PUBLIC_URL}/auth/social/github/callback
                              If unset, the request host is used (often wrong behind proxies).

Troubleshooting: **docs/design/GITHUB-OAUTH-TROUBLESHOOTING.md**
"""
from __future__ import annotations

import logging
import os
from typing import Optional

logger = logging.getLogger(__name__)

_AUTHLIB_AVAILABLE = False
try:
    from authlib.integrations.starlette_client import OAuth
    _AUTHLIB_AVAILABLE = True
except ImportError:
    pass


def is_social_available() -> bool:
    """Check if Authlib is installed."""
    return _AUTHLIB_AVAILABLE


# ── Provider Configuration ──────────────────────────────────────────────────

PROVIDERS = {
    "github": {
        "client_id_env": "GITHUB_CLIENT_ID",
        "client_secret_env": "GITHUB_CLIENT_SECRET",
        "authorize_url": "https://github.com/login/oauth/authorize",
        "access_token_url": "https://github.com/login/oauth/access_token",
        "api_base_url": "https://api.github.com/",
        "userinfo_endpoint": "https://api.github.com/user",
        "scope": "user:email",
    },
    "google": {
        "client_id_env": "GOOGLE_CLIENT_ID",
        "client_secret_env": "GOOGLE_CLIENT_SECRET",
        "server_metadata_url": "https://accounts.google.com/.well-known/openid-configuration",
        "scope": "openid email profile",
    },
}


def get_configured_providers() -> list[str]:
    """Return list of providers that have client credentials configured."""
    configured = []
    for name, config in PROVIDERS.items():
        client_id = os.environ.get(config["client_id_env"], "")
        client_secret = os.environ.get(config["client_secret_env"], "")
        if client_id and client_secret:
            configured.append(name)
    return configured


def create_oauth_client() -> Optional["OAuth"]:
    """Create and configure the Authlib OAuth client.

    Registers GitHub and Google if their env vars are set.
    Returns None if Authlib is not installed.
    """
    if not _AUTHLIB_AVAILABLE:
        return None

    oauth = OAuth()

    # GitHub
    gh_id = os.environ.get("GITHUB_CLIENT_ID", "")
    gh_secret = os.environ.get("GITHUB_CLIENT_SECRET", "")
    if gh_id and gh_secret:
        oauth.register(
            name="github",
            client_id=gh_id,
            client_secret=gh_secret,
            authorize_url=PROVIDERS["github"]["authorize_url"],
            access_token_url=PROVIDERS["github"]["access_token_url"],
            api_base_url=PROVIDERS["github"]["api_base_url"],
            client_kwargs={"scope": PROVIDERS["github"]["scope"]},
        )
        logger.info("Social login: GitHub registered")

    # Google (OIDC — auto-discovers endpoints)
    g_id = os.environ.get("GOOGLE_CLIENT_ID", "")
    g_secret = os.environ.get("GOOGLE_CLIENT_SECRET", "")
    if g_id and g_secret:
        oauth.register(
            name="google",
            client_id=g_id,
            client_secret=g_secret,
            server_metadata_url=PROVIDERS["google"]["server_metadata_url"],
            client_kwargs={"scope": PROVIDERS["google"]["scope"]},
        )
        logger.info("Social login: Google registered")

    return oauth


async def fetch_github_email(token: dict) -> Optional[str]:
    """Fetch the user's primary email from GitHub API.

    GitHub may not include email in the user profile if it's set to private.
    We need to call /user/emails to get the verified primary email.
    """
    try:
        import httpx
        # GitHub REST: OAuth access tokens use Bearer (token prefix is legacy)
        headers = {"Authorization": f"Bearer {token['access_token']}", "Accept": "application/vnd.github+json"}
        async with httpx.AsyncClient() as client:
            # Try profile first
            resp = await client.get("https://api.github.com/user", headers=headers)
            if resp.status_code == 200:
                data = resp.json()
                if data.get("email"):
                    return data["email"]

            # Fallback: /user/emails for private emails
            resp = await client.get("https://api.github.com/user/emails", headers=headers)
            if resp.status_code == 200:
                emails = resp.json()
                for e in emails:
                    if e.get("primary") and e.get("verified"):
                        return e["email"]
                # If no primary, take first verified
                for e in emails:
                    if e.get("verified"):
                        return e["email"]
    except Exception as ex:
        logger.warning("GitHub email fetch failed: %s", ex)

    return None


async def fetch_github_profile(token: dict) -> dict:
    """Fetch full GitHub profile including email verification status."""
    try:
        import httpx
        headers = {"Authorization": f"Bearer {token['access_token']}", "Accept": "application/vnd.github+json"}
        async with httpx.AsyncClient() as client:
            # Get profile
            resp = await client.get("https://api.github.com/user", headers=headers)
            profile = resp.json() if resp.status_code == 200 else {}

            # Get emails with verification status
            resp = await client.get("https://api.github.com/user/emails", headers=headers)
            emails = resp.json() if resp.status_code == 200 else []

            profile_email_norm = (profile.get("email") or "").strip().lower()
            primary = None
            # Prefer verified entry that matches public /user email (avoids "not associated" / link failures)
            if profile_email_norm:
                for e in emails:
                    if (e.get("email") or "").strip().lower() == profile_email_norm and e.get("verified"):
                        primary = e
                        break
            if not primary:
                for e in emails:
                    if e.get("primary") and e.get("verified"):
                        primary = e
                        break
            if not primary:
                for e in emails:
                    if e.get("verified"):
                        primary = e
                        break

            pub_email = profile.get("email")
            return {
                "provider": "github",
                "provider_user_id": str(profile.get("id", "")),
                "email": primary["email"] if primary else pub_email,
                "email_verified": primary.get("verified", False) if primary else False,
                "display_name": profile.get("name") or profile.get("login", ""),
                "avatar_url": profile.get("avatar_url", ""),
                "profile_url": profile.get("html_url", ""),
            }
    except Exception as ex:
        logger.warning("GitHub profile fetch failed: %s", ex)
        return {}


async def fetch_google_userinfo(token: dict) -> dict:
    """Extract user info from Google OIDC token.

    Google OIDC returns user info in the id_token claims.
    Google always verifies email for OIDC — email_verified is in the claims.
    """
    try:
        userinfo = token.get("userinfo", {})
        if userinfo:
            return {
                "provider": "google",
                "provider_user_id": userinfo.get("sub", ""),
                "email": userinfo.get("email", ""),
                "email_verified": userinfo.get("email_verified", False),
                "display_name": userinfo.get("name", ""),
                "avatar_url": userinfo.get("picture", ""),
                "profile_url": "",
            }
    except Exception as ex:
        logger.warning("Google userinfo extraction failed: %s", ex)

    return {}
