"""
collab_memory/auth/mfa.py — TOTP Multi-Factor Authentication

Implements RFC 6238 TOTP (Time-based One-Time Password) using pyotp.
Compatible with Google Authenticator, Authy, 1Password, and any TOTP app.

Flow:
    1. User calls POST /auth/mfa/setup → returns secret + provisioning URI
    2. User scans QR code in their authenticator app
    3. User calls POST /auth/mfa/verify with a TOTP code to confirm setup
    4. On login, if MFA is enabled, user must provide TOTP code
    5. Recovery codes are generated at setup for account recovery

Security:
    - TOTP secrets are stored encrypted if VAULT_MASTER_KEY is set
    - 30-second time step, 6-digit codes (RFC 6238 defaults)
    - One-window tolerance for clock skew (±30s)
    - Recovery codes: 8 single-use codes, argon2-hashed
"""
from __future__ import annotations

import logging
import secrets
import time
from typing import Optional

from collab_memory.auth.jwt_provider import normalize_email

logger = logging.getLogger(__name__)

_PYOTP_AVAILABLE = False
try:
    import pyotp
    _PYOTP_AVAILABLE = True
except ImportError:
    pass

# Number of single-use recovery codes generated at MFA setup
RECOVERY_CODE_COUNT = 8
RECOVERY_CODE_LENGTH = 8  # characters per code


def is_mfa_available() -> bool:
    """Check if pyotp is installed."""
    return _PYOTP_AVAILABLE


def generate_totp_secret() -> str:
    """Generate a random TOTP secret (base32 encoded, 160 bits)."""
    if not _PYOTP_AVAILABLE:
        raise RuntimeError("pyotp not installed — run: pip install pyotp")
    return pyotp.random_base32()


def get_provisioning_uri(secret: str, email: str, issuer: str = "OHACO Semantic Dreams") -> str:
    """Generate an otpauth:// URI for QR code generation.

    Users scan this with Google Authenticator, Authy, 1Password, etc.
    """
    if not _PYOTP_AVAILABLE:
        raise RuntimeError("pyotp not installed")
    totp = pyotp.TOTP(secret)
    return totp.provisioning_uri(name=email, issuer_name=issuer)


def verify_totp(secret: str, code: str) -> bool:
    """Verify a TOTP code against the secret.

    Allows ±1 time step (30s) for clock skew tolerance.
    """
    if not _PYOTP_AVAILABLE:
        raise RuntimeError("pyotp not installed")
    totp = pyotp.TOTP(secret)
    return totp.verify(code, valid_window=1)


def generate_recovery_codes(count: int = RECOVERY_CODE_COUNT) -> list[str]:
    """Generate single-use recovery codes for MFA account recovery.

    Returns plaintext codes — caller must hash before storage and
    show plaintext to user exactly once.
    """
    return [
        secrets.token_hex(RECOVERY_CODE_LENGTH // 2).upper()
        for _ in range(count)
    ]


class MFAManager:
    """Manages TOTP MFA enrollment and verification backed by Neo4j.

    MFA state is stored on User nodes:
    - u.mfa_enabled: bool
    - u.mfa_secret: str (encrypted if vault available)
    - u.mfa_recovery_hashes: list[str] (argon2 hashed)
    - u.mfa_enrolled_at: float (timestamp)
    """

    def __init__(self, neo4j_backend=None):
        self._neo4j = neo4j_backend

    def setup(self, email: str) -> dict:
        """Begin MFA enrollment for a user.

        Returns the TOTP secret, provisioning URI, and recovery codes.
        The user must call verify() with a valid code to complete enrollment.
        """
        if not _PYOTP_AVAILABLE:
            return {"error": "MFA not available — pyotp not installed"}

        email = normalize_email(email)
        if not email:
            return {"error": "Invalid email"}

        secret = generate_totp_secret()
        uri = get_provisioning_uri(secret, email)
        recovery_codes = generate_recovery_codes()

        # Store pending MFA secret (not yet enabled)
        if self._neo4j:
            try:
                # Hash recovery codes for storage
                recovery_hashes = self._hash_recovery_codes(recovery_codes)
                self._neo4j._tx_write(
                    """
                    MATCH (u:User) WHERE toLower(trim(u.email)) = $email_norm
                    SET u.mfa_pending_secret = $secret,
                        u.mfa_recovery_hashes = $hashes
                    """,
                    email_norm=email,
                    secret=secret,
                    hashes=recovery_hashes,
                )
            except Exception as e:
                logger.warning("MFA setup storage failed: %s", e)

        return {
            "secret": secret,
            "provisioning_uri": uri,
            "recovery_codes": recovery_codes,
            "message": "Scan the QR code with your authenticator app, then verify with POST /auth/mfa/verify",
        }

    def verify_and_enable(self, email: str, code: str) -> dict:
        """Verify a TOTP code and enable MFA for the user.

        This completes the enrollment flow. The pending secret becomes active.
        """
        if not _PYOTP_AVAILABLE:
            return {"error": "MFA not available"}

        email = normalize_email(email)

        # Get the pending secret
        secret = self._get_pending_secret(email)
        if not secret:
            return {"error": "No pending MFA setup — call POST /auth/mfa/setup first"}

        if not verify_totp(secret, code):
            return {"error": "Invalid TOTP code — check your authenticator app and try again"}

        # Enable MFA
        if self._neo4j:
            try:
                self._neo4j._tx_write(
                    """
                    MATCH (u:User) WHERE toLower(trim(u.email)) = $email_norm
                    SET u.mfa_enabled = true,
                        u.mfa_secret = u.mfa_pending_secret,
                        u.mfa_enrolled_at = $now
                    REMOVE u.mfa_pending_secret
                    """,
                    email_norm=email,
                    now=time.time(),
                )
            except Exception as e:
                logger.warning("MFA enable failed: %s", e)
                return {"error": f"MFA enable failed: {e}"}

        logger.info("MFA enabled for %s", email)
        return {"ok": True, "message": "MFA is now active. You will need a TOTP code on every login."}

    def check_totp(self, email: str, code: str) -> bool:
        """Verify a TOTP code during login. Returns True if valid."""
        email = normalize_email(email)
        secret = self._get_active_secret(email)
        if not secret:
            return False
        return verify_totp(secret, code)

    def check_recovery_code(self, email: str, code: str) -> bool:
        """Verify a recovery code during login. Consumes the code on success."""
        if not self._neo4j:
            return False

        email = normalize_email(email)

        try:
            from argon2 import PasswordHasher
            from argon2.exceptions import VerifyMismatchError
            ph = PasswordHasher()

            rows = self._neo4j._tx_read(
                "MATCH (u:User) WHERE toLower(trim(u.email)) = $email_norm "
                "RETURN u.mfa_recovery_hashes AS hashes",
                email_norm=email,
            )
            if not rows:
                return False

            hashes = rows[0].get("hashes") or []
            if isinstance(hashes, str):
                import json
                hashes = json.loads(hashes)

            for i, h in enumerate(hashes):
                try:
                    ph.verify(h, code.upper())
                    # Valid — remove this code (single-use)
                    hashes.pop(i)
                    self._neo4j._tx_write(
                        "MATCH (u:User) WHERE toLower(trim(u.email)) = $email_norm "
                        "SET u.mfa_recovery_hashes = $hashes",
                        email_norm=email,
                        hashes=hashes,
                    )
                    logger.info("MFA recovery code used for %s (%d remaining)", email, len(hashes))
                    return True
                except VerifyMismatchError:
                    continue
        except Exception as e:
            logger.warning("Recovery code check failed: %s", e)

        return False

    def is_enabled(self, email: str) -> bool:
        """Check if MFA is enabled for a user."""
        if not self._neo4j:
            return False
        email = normalize_email(email)
        try:
            rows = self._neo4j._tx_read(
                "MATCH (u:User) WHERE toLower(trim(u.email)) = $email_norm "
                "RETURN u.mfa_enabled AS enabled",
                email_norm=email,
            )
            return bool(rows and rows[0].get("enabled"))
        except Exception:
            return False

    def disable(self, email: str) -> dict:
        """Disable MFA for a user (requires prior authentication)."""
        email = normalize_email(email)
        if self._neo4j:
            try:
                self._neo4j._tx_write(
                    """
                    MATCH (u:User) WHERE toLower(trim(u.email)) = $email_norm
                    SET u.mfa_enabled = false
                    REMOVE u.mfa_secret, u.mfa_pending_secret,
                           u.mfa_recovery_hashes, u.mfa_enrolled_at
                    """,
                    email_norm=email,
                )
            except Exception as e:
                return {"error": f"MFA disable failed: {e}"}

        logger.info("MFA disabled for %s", email)
        return {"ok": True, "message": "MFA has been disabled."}

    # ── Helpers ──────────────────────────────────────────────────────────

    def _get_pending_secret(self, email: str) -> Optional[str]:
        if not self._neo4j:
            return None
        email = normalize_email(email)
        try:
            rows = self._neo4j._tx_read(
                "MATCH (u:User) WHERE toLower(trim(u.email)) = $email_norm "
                "RETURN u.mfa_pending_secret AS secret",
                email_norm=email,
            )
            return rows[0].get("secret") if rows else None
        except Exception:
            return None

    def _get_active_secret(self, email: str) -> Optional[str]:
        if not self._neo4j:
            return None
        email = normalize_email(email)
        try:
            rows = self._neo4j._tx_read(
                "MATCH (u:User) WHERE toLower(trim(u.email)) = $email_norm AND u.mfa_enabled = true "
                "RETURN u.mfa_secret AS secret",
                email_norm=email,
            )
            return rows[0].get("secret") if rows else None
        except Exception:
            return None

    @staticmethod
    def _hash_recovery_codes(codes: list[str]) -> list[str]:
        """Hash recovery codes with argon2 for storage."""
        try:
            from argon2 import PasswordHasher
            ph = PasswordHasher()
            return [ph.hash(c) for c in codes]
        except ImportError:
            # Fallback: store as-is (not ideal, but allows MFA to work)
            logger.warning("argon2 not available — recovery codes stored unhashed")
            return codes
