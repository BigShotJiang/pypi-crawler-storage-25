"""
collab_memory/auth/routes.py — Auth API Endpoints

Provides user-facing auth endpoints:
    POST /auth/signup    — Create account + tenant (policy-gated)
    POST /auth/access-request — Apply for waitlist / beta / volunteer (no account)
    POST /auth/login     — Authenticate and get JWT
    POST /auth/refresh   — Refresh access token
    GET  /auth/me        — Current user info
    POST /auth/email/self-test — Branded test email to self (JWT)
    POST /auth/email/invite-teammate — Instance onboarding email (JWT admin+)
    POST /auth/keys      — Store encrypted LLM API key
    GET  /auth/keys      — List stored keys (metadata only)
    DELETE /auth/keys/{provider} — Remove a stored key
"""

from __future__ import annotations

import json
import logging
import os
import uuid
from datetime import datetime, timezone
from typing import Optional

from fastapi import APIRouter, HTTPException, Depends, Request, Query
from fastapi.responses import RedirectResponse
from pydantic import BaseModel, field_validator

from collab_memory.auth.jwt_provider import AuthUser, normalize_email
from collab_memory.auth.middleware import get_auth_client, require_jwt
from collab_memory.auth.signup_policy import is_policy_unavailable_error, signup_policy_error
from collab_memory.auth.vault import LLMKeyVault

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/auth", tags=["auth"])

# ── Rate limiting for auth endpoints (NIST 800-63B §5.2.2) ──────────────────
# Auth endpoints get stricter limits than the rest of the API to prevent
# credential stuffing, brute-force, and TOTP enumeration.
try:
    from collab_memory.rate_limit import limiter
    _limit_login = limiter.limit("5/minute")
    _limit_signup = limiter.limit("3/minute")
    _limit_mfa = limiter.limit("5/minute")
    _limit_reset = limiter.limit("3/minute")
    _limit_mail = limiter.limit("5/minute")
except ImportError:
    def _noop(f): return f
    _limit_login = _limit_signup = _limit_mfa = _limit_reset = _limit_mail = _noop

# Module-level vault — initialized once
_vault: Optional[LLMKeyVault] = None


def get_vault() -> LLMKeyVault:
    global _vault
    if _vault is None:
        _vault = LLMKeyVault()
    return _vault


def _public_app_base(request: Request) -> str:
    """Canonical browser URL for redirects (verification links, etc.)."""
    env = os.environ.get("COLLAB_PUBLIC_URL", "").strip().rstrip("/")
    if env:
        return env
    return str(request.base_url).rstrip("/")


# ── Request models ───────────────────────────────────────────────────────────

def _validate_email_field(v: object) -> str:
    n = normalize_email(str(v) if v is not None else "")
    if not n or "@" not in n:
        raise ValueError("A valid email is required")
    return n


class SignupRequest(BaseModel):
    email: str
    password: str
    tenant_name: str = "default"

    @field_validator("email", mode="before")
    @classmethod
    def _norm_signup_email(cls, v: object) -> str:
        return _validate_email_field(v)


class LoginRequest(BaseModel):
    email: str
    password: str

    @field_validator("email", mode="before")
    @classmethod
    def _norm_login_email(cls, v: object) -> str:
        return _validate_email_field(v)

class RefreshRequest(BaseModel):
    refresh_token: str

class StoreKeyRequest(BaseModel):
    provider: str  # openai | anthropic | gemini | groq
    api_key: str

class MFALoginRequest(BaseModel):
    email: str
    password: str
    code: str  # TOTP code or recovery code

    @field_validator("email", mode="before")
    @classmethod
    def _norm_mfa_login_email(cls, v: object) -> str:
        return _validate_email_field(v)


class PasswordResetRequest(BaseModel):
    email: str

    @field_validator("email", mode="before")
    @classmethod
    def _norm_reset_email(cls, v: object) -> str:
        return _validate_email_field(v)

class PasswordResetConfirmRequest(BaseModel):
    reset_token: str
    new_password: str

class VerifyEmailRequest(BaseModel):
    verify_token: str

class ResendVerificationRequest(BaseModel):
    email: str

    @field_validator("email", mode="before")
    @classmethod
    def _norm_resend_email(cls, v: object) -> str:
        return _validate_email_field(v)


_ACCESS_TRACKS = frozenset({
    "launch_waitlist",
    "beta_tester",
    "community_volunteer",
    "investor_advisor",
})

_ACCESS_TRACK_DETAILS: dict[str, dict[str, str]] = {
    "launch_waitlist": {
        "label": "Launch notifications",
        "next_step": "You will receive launch and onboarding updates by email.",
    },
    "beta_tester": {
        "label": "Early beta",
        "next_step": "Ops reviews fit and approved testers receive invite/setup instructions.",
    },
    "community_volunteer": {
        "label": "Community volunteer",
        "next_step": "Community ops follows up with role options and contribution paths.",
    },
    "investor_advisor": {
        "label": "Investor / advisor",
        "next_step": "Submit NCNDA intake; you can access the investor deck immediately.",
    },
}

_REQUEST_DUP_CACHE: dict[str, str] = {}


def _access_workflow_next(tracks: list[str]) -> list[dict[str, str]]:
    """Return track-specific next steps for API/UI messaging."""
    out: list[dict[str, str]] = []
    seen: set[str] = set()
    for track in tracks:
        if track in seen:
            continue
        seen.add(track)
        detail = _ACCESS_TRACK_DETAILS.get(track)
        if not detail:
            continue
        out.append(
            {
                "track": track,
                "label": detail["label"],
                "next_step": detail["next_step"],
                "endpoint": "/auth/access-request",
            }
        )
    return out


def _find_pending_access_request(
    graph,
    *,
    email: str,
    tracks_json: str,
    source: str,
) -> tuple[str, str, str, str, str] | None:
    """Return existing pending AccessRequest tuple if one already exists.

    Tuple fields: (id, created_at, source, tracks_json, status)
    """
    if not graph:
        return None
    try:
        rows = graph._tx_read(
            """
            MATCH (a:AccessRequest)
            WHERE toLower(trim(a.email)) = toLower(trim($email))
              AND coalesce(a.status, 'pending') = 'pending'
              AND coalesce(a.source, '') = $source
              AND coalesce(a.tracks_json, '') = $tracks_json
            RETURN a.id AS id,
                   coalesce(a.created_at, '') AS created_at,
                   coalesce(a.source, '') AS source,
                   coalesce(a.tracks_json, '') AS tracks_json,
                   coalesce(a.status, 'pending') AS status
            ORDER BY a.created_at DESC
            LIMIT 1
            """,
            email=email,
            source=source,
            tracks_json=tracks_json,
        )
        if not rows:
            return None
        row = rows[0]
        rid = str(row.get("id") or "").strip()
        if not rid:
            return None
        return (
            rid,
            str(row.get("created_at") or ""),
            str(row.get("source") or ""),
            str(row.get("tracks_json") or ""),
            str(row.get("status") or "pending"),
        )
    except Exception as e:
        logger.warning("AccessRequest duplicate check failed (non-fatal): %s", e)
        return None


def _dedupe_cache_key(*, email: str, tracks_json: str, source: str) -> str:
    return f"{email.strip().lower()}|{source}|{tracks_json}"


def _find_pending_access_request_cached(
    *,
    email: str,
    tracks_json: str,
    source: str,
) -> tuple[str, str, str, str, str] | None:
    """Fallback duplicate check when graph reads are unavailable."""
    key = _dedupe_cache_key(email=email, tracks_json=tracks_json, source=source)
    rid = (_REQUEST_DUP_CACHE.get(key) or "").strip()
    if not rid:
        return None
    return (rid, "", source, tracks_json, "pending")


def _remember_pending_access_request_cached(
    *,
    email: str,
    tracks_json: str,
    source: str,
    request_id: str,
) -> None:
    """Remember pending request id for lightweight duplicate suppression."""
    rid = (request_id or "").strip()
    if not rid:
        return
    key = _dedupe_cache_key(email=email, tracks_json=tracks_json, source=source)
    _REQUEST_DUP_CACHE[key] = rid


class AccessRequestBody(BaseModel):
    """Single form: user may select one or more interest tracks."""

    email: str
    tracks: list[str]
    full_name: str = ""
    message: str = ""

    @field_validator("email", mode="before")
    @classmethod
    def _norm_access_email(cls, v: object) -> str:
        return _validate_email_field(v)

    @field_validator("tracks")
    @classmethod
    def _validate_tracks(cls, v: list[str]) -> list[str]:
        if not v:
            raise ValueError("Select at least one option")
        bad = [t for t in v if t not in _ACCESS_TRACKS]
        if bad:
            raise ValueError(f"Invalid track(s): {bad}")
        seen: set[str] = set()
        out: list[str] = []
        for t in v:
            if t not in seen:
                seen.add(t)
                out.append(t)
        return out


class InvestorRequestBody(BaseModel):
    """Investor / mentor / advisor inquiry with NCNDA acknowledgement."""

    email: str
    full_name: str = ""
    role: str = "investor"
    firm: str = ""
    website: str = ""
    check_size: str = ""
    timeline: str = ""
    message: str = ""
    ncnnda_ack: bool = False

    @field_validator("email", mode="before")
    @classmethod
    def _norm_investor_email(cls, v: object) -> str:
        return _validate_email_field(v)

    @field_validator("role")
    @classmethod
    def _validate_role(cls, v: str) -> str:
        role = (v or "").strip().lower()
        allowed = {"investor", "advisor", "mentor", "operator", "other"}
        if role not in allowed:
            raise ValueError(f"Invalid role: {v}")
        return role

    @field_validator("website")
    @classmethod
    def _validate_website(cls, v: str) -> str:
        url = (v or "").strip()
        if not url:
            return ""
        if not (url.startswith("http://") or url.startswith("https://")):
            raise ValueError("website must start with http:// or https://")
        return url


@router.post("/investor-request", summary="Investor / advisor request with NCNDA acknowledgement")
@_limit_signup
async def investor_request(request: Request, body: InvestorRequestBody):
    """Store investor-facing intake and notify ops.

    This endpoint is public-facing for the investor page and intentionally
    does not create an account.
    """
    if not body.ncnnda_ack:
        raise HTTPException(status_code=400, detail="Please acknowledge NCNDA intent before submitting.")

    now = datetime.now(timezone.utc).isoformat()
    fn = (body.full_name or "").strip()[:500]
    firm = (body.firm or "").strip()[:500]
    site = (body.website or "").strip()[:1000]
    check_size = (body.check_size or "").strip()[:200]
    timeline = (body.timeline or "").strip()[:200]
    role = (body.role or "investor").strip().lower()[:50]
    msg = (body.message or "").strip()[:5000]

    # Persist in AccessRequest for dashboard compatibility (single review queue).
    tracks = ["investor_advisor"]
    tracks_json = json.dumps(tracks)
    rid = str(uuid.uuid4())

    client = get_auth_client()
    graph = getattr(client, "_neo4j", None)
    existing = _find_pending_access_request(
        graph,
        email=body.email,
        tracks_json=tracks_json,
        source="investor_form",
    ) or _find_pending_access_request_cached(
        email=body.email,
        tracks_json=tracks_json,
        source="investor_form",
    )
    if existing:
        existing_id = existing[0]
        return {
            "status": "received",
            "request_id": existing_id,
            "duplicate": True,
            "detail": "A pending investor request already exists for this email and track.",
            "next": {
                "deck_url": "/investor-deck",
                "ncnnda_url": "/terms#2-beta--early-access--confidentiality-nda",
                "workflow_steps": [
                    {
                        "track": "investor_advisor",
                        "label": "Investor / advisor",
                        "next_step": "Review the investor deck now. Our team follows up after intake review.",
                        "endpoint": "/auth/investor-request",
                    }
                ],
            },
        }
    if graph:
        try:
            graph._tx_write(
                """
                CREATE (a:AccessRequest {
                    id: $id,
                    email: $email,
                    full_name: $fn,
                    tracks_json: $tj,
                    message: $msg,
                    status: 'pending',
                    created_at: $now,
                    source: 'investor_form',
                    role: $role,
                    firm: $firm,
                    website: $site,
                    check_size: $check_size,
                    timeline: $timeline,
                    ncnnda_ack: true
                })
                """,
                id=rid,
                email=body.email,
                fn=fn,
                tj=tracks_json,
                msg=msg,
                now=now,
                role=role,
                firm=firm,
                site=site,
                check_size=check_size,
                timeline=timeline,
            )
        except Exception as e:
            logger.warning("Investor request persist failed (non-fatal): %s", e)
    _remember_pending_access_request_cached(
        email=body.email,
        tracks_json=tracks_json,
        source="investor_form",
        request_id=rid,
    )

    # Notify ops/admin using investor-specific email copy.
    mail_result = None
    try:
        from .email import send_investor_inquiry_notification

        mail_result = send_investor_inquiry_notification(
            investor_email=body.email,
            full_name=fn,
            organization=firm,
            role=role,
            website=site,
            check_size=check_size,
            stage_focus=timeline,
            ncnnda_acknowledged=True,
            request_id=rid,
        )
    except Exception as e:
        logger.warning("Investor request notify email failed: %s", e)
        mail_result = {"status": "error", "detail": str(e)}

    return {
        "status": "received",
        "request_id": rid,
        "detail": "Investor request received. We will follow up by email after NCNDA review.",
        "notification": mail_result,
        "next": {
            "deck_url": "/investor-deck",
            "ncnnda_url": "/terms#2-beta--early-access--confidentiality-nda",
            "workflow_steps": [
                {
                    "track": "investor_advisor",
                    "label": "Investor / advisor",
                    "next_step": "Review the investor deck now. Our team follows up after intake review.",
                    "endpoint": "/auth/investor-request",
                }
            ],
        },
    }


# ── Endpoints ────────────────────────────────────────────────────────────────

@router.post("/signup", summary="Create account + tenant")
@_limit_signup
async def signup(request: Request, req: SignupRequest):
    """Create a new user account and associated tenant.

    Returns JWT access + refresh tokens on success.
    Tenant is auto-provisioned from the signup.

    Public signup is off by default. Otherwise allowed when: ``OWNER_LOGIN_EMAILS``,
    an approved ``AccessRequest`` (approved / invited / provisioned), empty DB +
    ``ALLOW_BOOTSTRAP_SIGNUP``, or an invite flow. Set ``ALLOW_PUBLIC_SIGNUP=true``
    for open registration.
    """
    client = get_auth_client()
    neo = getattr(client, "_neo4j", None)
    pol = signup_policy_error(neo, req.email)
    if pol:
        if is_policy_unavailable_error(pol):
            raise HTTPException(status_code=503, detail=pol)
        raise HTTPException(status_code=403, detail=pol)

    result = client.signup(req.email, req.password, req.tenant_name)

    if "error" in result:
        status = 409 if "already exists" in result.get("error", "") else 400
        raise HTTPException(status_code=status, detail=result)

    # Assign a codename to the new user
    codename = ""
    try:
        from .codenames import generate_codename
        codename = generate_codename()
        user_id = result.get("user_id")
        if user_id and hasattr(client, "_neo4j") and client._neo4j:
            client._neo4j._tx_write(
                "MATCH (u:User {user_id: $uid}) SET u.codename = $cn",
                uid=user_id, cn=codename,
            )
    except Exception as cn_err:
        logger.warning("Codename assignment failed (non-fatal): %s", cn_err)

    # Send verification email via Resend (requires RESEND_API_KEY)
    verify_token = result.get("verify_token")
    mail_info = None
    if verify_token and req.email:
        try:
            from .email import send_verification_email
            mail_info = send_verification_email(req.email, verify_token)
        except Exception as mail_err:
            logger.warning("Verification email failed (non-fatal): %s", mail_err)
            mail_info = {"status": "error", "detail": str(mail_err)}

    out = {
        "status": "ok",
        "user_id": result.get("user_id"),
        "tenant_id": result.get("tenant_id"),
        "codename": codename,
        "email_verified": result.get("email_verified", False),
        "verify_token": result.get("verify_token"),
        "access_token": result.get("access_token"),
        "refresh_token": result.get("refresh_token"),
        "api_key_write": result.get("api_key_write"),
        "api_key_read": result.get("api_key_read"),
    }
    if mail_info is not None:
        out["verification_email"] = mail_info
    return out


@router.post("/access-request", summary="Request access (waitlist / beta / volunteer)")
@_limit_signup
async def access_request(request: Request, body: AccessRequestBody):
    """Store an application in the graph and optionally notify ops by email.

    Does not create an account. Approved beta applicants are provisioned out-of-band
    (invite or admin action), not automatically from this endpoint.
    """
    now = datetime.now(timezone.utc).isoformat()
    tracks_json = json.dumps(body.tracks)
    fn = (body.full_name or "").strip()[:500]
    msg = (body.message or "").strip()[:5000]
    rid = str(uuid.uuid4())

    client = get_auth_client()
    graph = getattr(client, "_neo4j", None)
    existing = _find_pending_access_request(
        graph,
        email=body.email,
        tracks_json=tracks_json,
        source="apply_form",
    ) or _find_pending_access_request_cached(
        email=body.email,
        tracks_json=tracks_json,
        source="apply_form",
    )
    if existing:
        existing_id = existing[0]
        return {
            "status": "received",
            "request_id": existing_id,
            "duplicate": True,
            "detail": "A pending request already exists for this email and selected track(s).",
            "next": {
                "workflow_steps": _access_workflow_next(body.tracks),
                "signup_path": "/signup",
                "apply_path": "/apply",
            },
        }
    if graph:
        try:
            graph._tx_write(
                """
                CREATE (a:AccessRequest {
                    id: $id,
                    email: $email,
                    full_name: $fn,
                    tracks_json: $tj,
                    message: $msg,
                    status: 'pending',
                    created_at: $now,
                    source: 'apply_form'
                })
                """,
                id=rid,
                email=body.email,
                fn=fn,
                tj=tracks_json,
                msg=msg,
                now=now,
            )
        except Exception as e:
            logger.warning("AccessRequest persist failed (non-fatal): %s", e)
    _remember_pending_access_request_cached(
        email=body.email,
        tracks_json=tracks_json,
        source="apply_form",
        request_id=rid,
    )

    mail_result = None
    try:
        from .email import send_access_request_notification
        mail_result = send_access_request_notification(
            body.email, fn, body.tracks, msg, rid,
        )
    except Exception as e:
        logger.warning("Access request notify email failed: %s", e)
        mail_result = {"status": "error", "detail": str(e)}

    return {
        "status": "received",
        "request_id": rid,
        "detail": "Thanks — we will follow up by email if there is a fit.",
        "notification": mail_result,
        "next": {
            "workflow_steps": _access_workflow_next(body.tracks),
            "signup_path": "/signup",
            "apply_path": "/apply",
        },
    }


@router.post("/login", summary="Authenticate and get JWT")
@_limit_login
async def login(request: Request, req: LoginRequest):
    """Authenticate with email/password. Returns JWT tokens.

    If MFA is enabled, returns mfa_required=True instead of tokens.
    The client must then call POST /auth/mfa/login with the TOTP code.
    """
    client = get_auth_client()
    result = client.login(req.email, req.password)

    if "error" in result:
        raise HTTPException(status_code=401, detail=result)

    # Check if MFA is required
    try:
        from collab_memory.auth.mfa import MFAManager, is_mfa_available
        if is_mfa_available():
            graph = _get_graph()
            mgr = MFAManager(neo4j_backend=graph)
            if mgr.is_enabled(req.email):
                # Don't issue full tokens yet — require TOTP
                return {
                    "status": "mfa_required",
                    "mfa_required": True,
                    "user_id": result.get("user_id"),
                    "tenant_id": result.get("tenant_id"),
                    "message": "MFA is enabled. Provide TOTP code via POST /auth/mfa/login",
                }
    except Exception:
        pass  # MFA check failure should not block login

    return {
        "status": "ok",
        "user_id": result.get("user_id"),
        "tenant_id": result.get("tenant_id"),
        "plan": result.get("plan", "free"),
        "access_token": result.get("access_token"),
        "refresh_token": result.get("refresh_token"),
    }


@router.post("/mfa/login", summary="Complete MFA login with TOTP code")
@_limit_mfa
async def mfa_login(request: Request, req: MFALoginRequest):
    """Second step of MFA login: verify password + TOTP code, return full tokens.

    Accepts either a 6-digit TOTP code or an 8-character recovery code.
    """
    client = get_auth_client()
    result = client.login(req.email, req.password)

    if "error" in result:
        raise HTTPException(status_code=401, detail=result)

    from collab_memory.auth.mfa import MFAManager, is_mfa_available
    if not is_mfa_available():
        raise HTTPException(status_code=503, detail="MFA not available")

    graph = _get_graph()
    mgr = MFAManager(neo4j_backend=graph)

    # Try TOTP code first, then recovery code
    if mgr.check_totp(req.email, req.code):
        pass  # Valid TOTP
    elif mgr.check_recovery_code(req.email, req.code):
        pass  # Valid recovery code (consumed)
    else:
        raise HTTPException(status_code=401, detail="Invalid MFA code")

    return {
        "status": "ok",
        "user_id": result.get("user_id"),
        "tenant_id": result.get("tenant_id"),
        "plan": result.get("plan", "free"),
        "access_token": result.get("access_token"),
        "refresh_token": result.get("refresh_token"),
    }


@router.post("/refresh", summary="Refresh access token")
async def refresh(req: RefreshRequest):
    """Exchange refresh token for new access + refresh pair."""
    client = get_auth_client()
    result = client.refresh_session(req.refresh_token)

    if "error" in result:
        raise HTTPException(status_code=401, detail=result)

    return {
        "status": "ok",
        "access_token": result.get("access_token"),
        "refresh_token": result.get("refresh_token"),
    }


@router.post("/logout", summary="Sign out and invalidate session")
async def logout(request: Request, user: AuthUser = Depends(require_jwt)):
    """Sign out — clears failed attempts, logs the event.

    Note: With stateless JWTs, the access token remains valid until expiry.
    The client must discard stored tokens. For full revocation, a token
    blocklist (Redis/DB) would be needed — tracked for future implementation.
    """
    client = get_auth_client()
    # Reset any lockout state on logout
    client._reset_failed_attempts(user.email)
    client._audit_log("logout", user.email, True)
    return {"status": "ok", "message": "Signed out successfully."}


@router.get("/me", summary="Current user info")
async def me(user: AuthUser = Depends(require_jwt)):
    """Return info about the currently authenticated user."""
    client = get_auth_client()
    email_verified = client.is_email_verified(user.email)
    return {
        "user_id": user.user_id,
        "email": user.email,
        "tenant_id": user.tenant_id,
        "plan": user.plan,
        "role": user.role,
        "is_super_admin": user.role == "super_admin",
        "email_verified": email_verified,
    }


class InviteTeammateEmailBody(BaseModel):
    to: str
    role_description: str = "workspace administrator"

    @field_validator("to", mode="before")
    @classmethod
    def _strip_to(cls, v: object) -> str:
        return str(v or "").strip()

    @field_validator("role_description", mode="before")
    @classmethod
    def _clip_role(cls, v: object) -> str:
        return str(v or "").strip()[:200]


@router.post("/email/self-test", summary="Send branded test email to your login address")
@_limit_mail
async def email_self_test(request: Request, user: AuthUser = Depends(require_jwt)):
    """Uses server ``RESEND_API_KEY`` / ``FROM_EMAIL`` — no ops API key required."""
    from collab_memory.auth.email import send_branded_test_email

    to = normalize_email(user.email)
    result = send_branded_test_email(to)
    return {"ok": True, "to": to, "mail": result}


@router.post("/email/invite-teammate", summary="Send instance onboarding email (admin or super-admin)")
@_limit_mail
async def email_invite_teammate(
    request: Request,
    body: InviteTeammateEmailBody,
    user: AuthUser = Depends(require_jwt),
):
    """Branded invite; recipient must be allowlisted on the host for signup/login if you use instance locks."""
    if user.role not in ("admin", "super_admin"):
        raise HTTPException(
            status_code=403,
            detail="Only workspace administrators can send teammate onboarding email.",
        )
    from collab_memory.auth.email import send_instance_team_invite_email

    to = normalize_email(body.to)
    if not to or "@" not in to:
        raise HTTPException(status_code=400, detail="Invalid recipient email")
    rd = (body.role_description or "workspace administrator").strip()[:200] or "workspace administrator"
    result = send_instance_team_invite_email(to, role_description=rd)
    return {"ok": True, "to": to, "mail": result}


def _get_graph():
    """Get the Neo4j backend from the server module (avoids circular import)."""
    try:
        from collab_memory.api import server as _server
        return getattr(_server, "graph", None)
    except Exception:
        return None


@router.post("/forgot-password", summary="Request a password reset token")
@_limit_reset
async def forgot_password(request: Request, req: PasswordResetRequest):
    """Issue a password reset token for the given email.

    For self-hosted deployments the token is returned in the response
    so the operator can relay it via their own email system.
    Token expires in 1 hour.
    """
    client = get_auth_client()
    result = client.request_password_reset(req.email)
    # Send reset email via Resend (best-effort)
    reset_token = result.get("reset_token")
    if reset_token:
        try:
            from .email import send_password_reset_email
            send_password_reset_email(req.email, reset_token)
        except Exception as mail_err:
            logger.warning("Password reset email failed (non-fatal): %s", mail_err)
    # Always return 200 — don't reveal whether email is registered
    return result


@router.post("/reset-password", summary="Complete password reset with token")
@_limit_reset
async def reset_password(request: Request, req: PasswordResetConfirmRequest):
    """Set a new password using the reset token from /forgot-password."""
    if not req.new_password or len(req.new_password) < 8:
        raise HTTPException(status_code=400, detail="Password must be at least 8 characters")
    client = get_auth_client()
    result = client.reset_password(req.reset_token, req.new_password)
    if "error" in result:
        raise HTTPException(status_code=400, detail=result["error"])
    return result


@router.get("/verify-email", include_in_schema=False)
async def verify_email_from_link(request: Request, token: str = Query(..., min_length=20)):
    """One-click verify from the link in transactional email (GET).

    Emails point here with ?token=…; POST /auth/verify-email remains for API clients.
    """
    client = get_auth_client()
    result = client.verify_email(token)
    base = _public_app_base(request)
    if "error" in result:
        return RedirectResponse(url=f"{base}/?email_verify=error", status_code=302)
    return RedirectResponse(url=f"{base}/?email_verified=1", status_code=302)


@router.post("/verify-email", summary="Verify email address")
async def verify_email(req: VerifyEmailRequest):
    """Verify a user's email using the token from signup or resend."""
    client = get_auth_client()
    result = client.verify_email(req.verify_token)
    if "error" in result:
        raise HTTPException(status_code=400, detail=result["error"])
    return result


@router.post("/resend-verification", summary="Resend email verification token")
@_limit_signup
async def resend_verification(request: Request, req: ResendVerificationRequest):
    """Resend a verification token for unverified accounts."""
    client = get_auth_client()
    result = dict(client.resend_verification(req.email))

    verify_token = result.get("verify_token")
    if verify_token and req.email and verify_token != "bypass-verify":
        try:
            from .email import send_verification_email
            result["verification_email"] = send_verification_email(req.email, verify_token)
        except Exception as mail_err:
            logger.warning("Resend verification email failed (non-fatal): %s", mail_err)
            result["verification_email"] = {"status": "error", "detail": str(mail_err)}

    return result


class SetPasswordRequest(BaseModel):
    email: str
    new_password: str

    @field_validator("email", mode="before")
    @classmethod
    def _norm_set_pw_email(cls, v: object) -> str:
        return _validate_email_field(v)


@router.post("/set-password", summary="Set password for an existing user (admin)")
@_limit_reset
async def set_password(request: Request, req: SetPasswordRequest):
    """Set or reset password for a user who was provisioned without one.

    Requires admin-level API key or superadmin JWT. This is for:
    - Superadmin accounts created via direct provisioning
    - Password recovery when email is unavailable
    - Instance bootstrapping
    """
    # Auth routes skip the main API key middleware, so resolve auth here directly.
    agent = getattr(request.state, "agent", None)
    if not agent:
        # Check API key header — resolve admin role from ABAC
        api_key = request.headers.get("X-API-Key", "").strip()
        if api_key:
            try:
                from collab_memory.abac import resolve_agent_context
                graph = _get_graph()
                agent = resolve_agent_context(api_key, graph=graph)
            except Exception:
                pass
        # Check JWT Bearer
        if not agent:
            auth_header = request.headers.get("Authorization", "").strip()
            if auth_header.startswith("Bearer "):
                try:
                    client = get_auth_client()
                    payload = client._decode_token(auth_header[7:])
                    if payload and payload.get("sub"):
                        from collab_memory.abac import AgentContext
                        agent = AgentContext(
                            role=payload.get("role", "contributor"),
                            agent_id=payload.get("sub", "jwt-user"),
                            tenant_id=payload.get("tenant_id", ""),
                            is_superadmin=bool(payload.get("is_superadmin")),
                        )
                except Exception:
                    pass

    if not agent:
        raise HTTPException(status_code=401, detail="Authentication required")
    role = getattr(agent, "role", "reader")
    is_sa = getattr(agent, "is_superadmin", False)
    if role not in ("admin", "super_admin", "superadmin") and not is_sa:
        raise HTTPException(status_code=403, detail="Admin access required")

    client = get_auth_client()
    result = client.set_password(req.email, req.new_password)
    if "error" in result:
        raise HTTPException(status_code=400, detail=result["error"])
    return result


@router.get("/api-keys", summary="Get your tenant API keys")
async def get_api_keys(user: AuthUser = Depends(require_jwt)):
    """Return the current user's tenant API keys for MCP/REST integration.

    Only the tenant owner or admin can view keys.
    """
    graph = _get_graph()
    if not graph:
        raise HTTPException(status_code=503, detail="Graph not available")

    try:
        rows = graph._tx_read(
            "MATCH (t:Tenant {id: $tid}) RETURN t.api_key_write AS write_key, t.api_key_read AS read_key",
            tid=user.tenant_id,
        )
        if not rows:
            raise HTTPException(status_code=404, detail="Tenant not found")
        return {
            "tenant_id": user.tenant_id,
            "api_key_write": rows[0].get("write_key"),
            "api_key_read": rows[0].get("read_key"),
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.warning(f"API key lookup failed: {e}")
        raise HTTPException(status_code=500, detail="Failed to retrieve keys")


class RegenerateApiKeysBody(BaseModel):
    """Rotate write key, read key, or both. Other key is unchanged when rotating one."""

    which: str = "both"

    @field_validator("which", mode="before")
    @classmethod
    def _norm_which(cls, v: object) -> str:
        s = str(v or "both").lower().strip()
        if s not in ("write", "read", "both"):
            raise ValueError("which must be write, read, or both")
        return s


@router.post("/api-keys/regenerate", summary="Regenerate tenant API keys")
async def regenerate_api_keys(
    body: RegenerateApiKeysBody = RegenerateApiKeysBody(),
    user: AuthUser = Depends(require_jwt),
):
    """Generate new API key(s) for the tenant. Old key(s) in scope are invalidated immediately."""
    import uuid as _uuid
    graph = _get_graph()
    if not graph:
        raise HTTPException(status_code=503, detail="Graph not available")

    try:
        rows = graph._tx_read(
            "MATCH (t:Tenant {id: $tid}) RETURN t.api_key_write AS write_key, t.api_key_read AS read_key",
            tid=user.tenant_id,
        )
        if not rows:
            raise HTTPException(status_code=404, detail="Tenant not found")
        cur_w = rows[0].get("write_key") or ""
        cur_r = rows[0].get("read_key") or ""
    except HTTPException:
        raise
    except Exception as e:
        logger.warning(f"API key read before regenerate failed: {e}")
        raise HTTPException(status_code=500, detail="Failed to read tenant keys")

    new_write = f"cmk_write_{_uuid.uuid4().hex}" if body.which in ("write", "both") else cur_w
    new_read = f"cmk_read_{_uuid.uuid4().hex}" if body.which in ("read", "both") else cur_r

    try:
        graph._tx_write(
            "MATCH (t:Tenant {id: $tid}) SET t.api_key_write = $wk, t.api_key_read = $rk",
            tid=user.tenant_id, wk=new_write, rk=new_read,
        )
    except Exception as e:
        logger.warning(f"API key regeneration failed: {e}")
        raise HTTPException(status_code=500, detail="Failed to regenerate keys")

    logger.info("Regenerated API keys for tenant %s (which=%s)", user.tenant_id, body.which)
    msg = {
        "both": "Keys regenerated. Old keys are now invalid.",
        "write": "Write key rotated. Read key unchanged.",
        "read": "Read key rotated. Write key unchanged.",
    }[body.which]
    return {
        "tenant_id": user.tenant_id,
        "api_key_write": new_write,
        "api_key_read": new_read,
        "which": body.which,
        "message": msg,
    }


@router.post("/keys", summary="Store encrypted LLM API key")
async def store_key(req: StoreKeyRequest, user: AuthUser = Depends(require_jwt)):
    """Encrypt and store a user's LLM API key in the graph.

    The key is encrypted with AES-256-GCM before storage.
    The plaintext key is never logged or stored unencrypted.
    """
    vault = get_vault()

    valid_providers = {"openai", "anthropic", "gemini", "groq", "mistral", "azure", "ollama"}
    if req.provider not in valid_providers:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid provider. Must be one of: {', '.join(sorted(valid_providers))}",
        )

    encrypted = vault.encrypt(req.api_key)
    graph = _get_graph()

    if graph:
        try:
            graph._tx_write(
                """
                MERGE (k:LLMKey {tenant_id: $tid, provider: $provider})
                SET k.encrypted_key = $enc,
                    k.vault_configured = $vault_ok,
                    k.updated_at = $ts
                """,
                tid=user.tenant_id,
                provider=req.provider,
                enc=encrypted,
                vault_ok=vault.is_configured,
                ts=str(__import__("datetime").datetime.utcnow()),
            )
        except Exception as e:
            logger.warning(f"LLMKey store failed: {e}")
            raise HTTPException(status_code=500, detail="Failed to store key")

    logger.info(f"Stored {req.provider} key for tenant {user.tenant_id}")
    return {
        "status": "ok",
        "provider": req.provider,
        "tenant_id": user.tenant_id,
        "encrypted": vault.is_configured,
        "message": f"{req.provider} API key stored successfully",
    }


@router.get("/keys", summary="List stored LLM keys (metadata only)")
async def list_keys(user: AuthUser = Depends(require_jwt)):
    """List stored LLM API keys for the current user. Returns metadata only."""
    graph = _get_graph()
    keys = []
    if graph:
        try:
            rows = graph._tx_read(
                "MATCH (k:LLMKey {tenant_id: $tid}) RETURN k.provider AS provider, k.updated_at AS updated_at",
                tid=user.tenant_id,
            )
            keys = [{"provider": r["provider"], "updated_at": r["updated_at"]} for r in rows]
        except Exception as e:
            logger.warning(f"LLMKey list failed: {e}")

    return {"tenant_id": user.tenant_id, "keys": keys}


@router.delete("/keys/{provider}", summary="Remove a stored key")
async def delete_key(provider: str, user: AuthUser = Depends(require_jwt)):
    """Delete a stored LLM API key for a specific provider."""
    graph = _get_graph()
    if graph:
        try:
            graph._tx_write(
                "MATCH (k:LLMKey {tenant_id: $tid, provider: $provider}) DETACH DELETE k",
                tid=user.tenant_id, provider=provider,
            )
        except Exception as e:
            logger.warning(f"LLMKey delete failed: {e}")

    logger.info(f"Deleted {provider} key for tenant {user.tenant_id}")
    return {"status": "ok", "provider": provider, "tenant_id": user.tenant_id}


# ── MFA Endpoints ───────────────────────────────────────────────────────────


class MFAVerifyRequest(BaseModel):
    code: str


@router.post("/mfa/setup", summary="Begin TOTP MFA enrollment")
async def mfa_setup(user: AuthUser = Depends(require_jwt)):
    """Generate a TOTP secret and provisioning URI for the authenticated user.

    Returns the secret, QR code URI, and recovery codes. The user must
    scan the QR code with their authenticator app, then call /auth/mfa/verify
    to complete enrollment.
    """
    from collab_memory.auth.mfa import MFAManager, is_mfa_available
    if not is_mfa_available():
        raise HTTPException(status_code=503, detail="MFA not available — pyotp not installed")

    graph = _get_graph()
    mgr = MFAManager(neo4j_backend=graph)

    # Check if already enabled
    if mgr.is_enabled(user.email):
        raise HTTPException(status_code=409, detail="MFA is already enabled for this account")

    result = mgr.setup(user.email)
    if "error" in result:
        raise HTTPException(status_code=500, detail=result["error"])

    return result


@router.post("/mfa/verify", summary="Verify TOTP code and enable MFA")
async def mfa_verify(req: MFAVerifyRequest, user: AuthUser = Depends(require_jwt)):
    """Complete MFA enrollment by verifying a TOTP code from the authenticator app."""
    from collab_memory.auth.mfa import MFAManager, is_mfa_available
    if not is_mfa_available():
        raise HTTPException(status_code=503, detail="MFA not available")

    graph = _get_graph()
    mgr = MFAManager(neo4j_backend=graph)
    result = mgr.verify_and_enable(user.email, req.code)

    if "error" in result:
        raise HTTPException(status_code=400, detail=result["error"])

    return result


@router.post("/mfa/disable", summary="Disable MFA")
async def mfa_disable(req: MFAVerifyRequest, user: AuthUser = Depends(require_jwt)):
    """Disable MFA for the authenticated user. Requires a valid TOTP code to confirm."""
    from collab_memory.auth.mfa import MFAManager, is_mfa_available
    if not is_mfa_available():
        raise HTTPException(status_code=503, detail="MFA not available")

    graph = _get_graph()
    mgr = MFAManager(neo4j_backend=graph)

    # Must provide valid code to disable
    if not mgr.check_totp(user.email, req.code):
        raise HTTPException(status_code=401, detail="Invalid TOTP code — MFA not disabled")

    result = mgr.disable(user.email)
    if "error" in result:
        raise HTTPException(status_code=500, detail=result["error"])

    return result


@router.get("/mfa/status", summary="Check MFA status")
async def mfa_status(user: AuthUser = Depends(require_jwt)):
    """Check whether MFA is enabled for the authenticated user."""
    from collab_memory.auth.mfa import MFAManager, is_mfa_available
    graph = _get_graph()
    mgr = MFAManager(neo4j_backend=graph)
    return {
        "mfa_available": is_mfa_available(),
        "mfa_enabled": mgr.is_enabled(user.email),
        "email": user.email,
    }
