"""
encoder.py — Exchange classifier and worthiness scorer.

Takes a raw conversation span (one or more turns) and produces a
ClassificationResult: primitive type, worthiness score, and extracted
graph nodes ready for storage.

Architecture:
  1. Keyword pre-screen (fast, cheap) → rough worthiness score
  2. LLM classification (Gemini) → primitive type + extracted fields
  3. Merge scores → final worthiness
  4. If above threshold → build graph nodes from extracted fields
"""

from __future__ import annotations

import json
import os
import re
import time
from datetime import datetime
from typing import Optional

from dotenv import load_dotenv

from .schema import (
    AMBIGUITY_LOWER,
    HIGH_SIGNAL_PRIMITIVES,
    WORTHINESS_THRESHOLD,
    Attempt,
    ClassificationResult,
    Constraint,
    ConstraintOrigin,
    Decision,
    DecisionStatus,
    Edge,
    ExchangeRecord,
    Preference,
    PreferenceType,
    PrimitiveType,
)

load_dotenv()

# ─── LLM Provider ─────────────────────────────────────────────────────────────

EXTRACTOR_VERSION = os.environ.get("EXTRACTOR_VERSION", "0.1.0")
LLM_PROVIDER = os.environ.get("LLM_PROVIDER", "anthropic").lower()
GEMINI_MODEL = os.environ.get("GEMINI_MODEL", "gemini-2.0-flash")
OLLAMA_MODEL = os.environ.get("OLLAMA_MODEL", "qwen2.5:14b")
OLLAMA_BASE_URL = os.environ.get("OLLAMA_BASE_URL", "http://localhost:11434")


def _call_llm_gemini(prompt: str) -> dict:
    import google.genai as genai
    from google.genai import types as genai_types
    api_key = os.environ.get("GOOGLE_API_KEY")
    if not api_key:
        raise RuntimeError("GOOGLE_API_KEY not set")
    client = genai.Client(api_key=api_key)
    response = client.models.generate_content(
        model=GEMINI_MODEL,
        contents=prompt,
        config=genai_types.GenerateContentConfig(
            response_mime_type="application/json",
        ),
    )
    return json.loads(response.text)


def _call_llm_openai(prompt: str) -> dict:
    from openai import OpenAI
    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        raise RuntimeError("OPENAI_API_KEY not set")
    client = OpenAI(api_key=api_key)
    response = client.chat.completions.create(
        model=os.environ.get("OPENAI_MODEL", "gpt-4o-mini"),
        messages=[{"role": "user", "content": prompt}],
        response_format={"type": "json_object"},
    )
    return json.loads(response.choices[0].message.content)


def _call_llm_anthropic(prompt: str) -> dict:
    import anthropic
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        raise RuntimeError("ANTHROPIC_API_KEY not set")

    # Sprint 23: validate model name — invalid names cause cascading 503s
    model = os.environ.get("ANTHROPIC_MODEL", "claude-haiku-4-5")
    _VALID_PREFIXES = ("claude-3", "claude-haiku", "claude-sonnet", "claude-opus")
    if not model.startswith(_VALID_PREFIXES):
        import logging
        logging.getLogger(__name__).warning(
            "ANTHROPIC_MODEL='%s' looks invalid — falling back to claude-haiku-4-5", model
        )
        model = "claude-haiku-4-5"

    client = anthropic.Anthropic(api_key=api_key, timeout=20.0)
    response = client.messages.create(
        model=model,
        max_tokens=1024,
        messages=[{"role": "user", "content": prompt}],
        system="You are a JSON-only responder. Always return valid JSON matching the requested structure. No prose.",
    )
    raw = response.content[0].text.strip()
    # Strip markdown fences if present
    if raw.startswith("```"):
        raw = re.sub(r"^```[a-z]*\n?", "", raw)
        raw = re.sub(r"\n?```$", "", raw.strip())
    return json.loads(raw)


def _call_llm_ollama(prompt: str) -> dict:
    """Call a local Ollama model (default: qwen2.5:14b).

    Uses Ollama's OpenAI-compatible /v1/chat/completions endpoint with
    format=json to enforce structured output. Falls back to the native
    /api/generate endpoint if the compat layer isn't available.
    """
    import urllib.request
    import urllib.error

    payload = json.dumps({
        "model": OLLAMA_MODEL,
        "messages": [{"role": "user", "content": prompt}],
        "format": "json",
        "stream": False,
        "options": {
            "temperature": 0.1,       # low temp = consistent classification
            "num_predict": 1024,
        },
    }).encode()

    url = f"{OLLAMA_BASE_URL}/v1/chat/completions"
    req = urllib.request.Request(
        url, data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=120) as r:
            data = json.loads(r.read().decode())
        text = data["choices"][0]["message"]["content"].strip()
    except Exception:
        # Fallback: native /api/generate endpoint
        payload2 = json.dumps({
            "model": OLLAMA_MODEL,
            "prompt": prompt,
            "format": "json",
            "stream": False,
            "options": {"temperature": 0.1, "num_predict": 1024},
        }).encode()
        req2 = urllib.request.Request(
            f"{OLLAMA_BASE_URL}/api/generate", data=payload2,
            headers={"Content-Type": "application/json"}, method="POST",
        )
        with urllib.request.urlopen(req2, timeout=120) as r:
            data = json.loads(r.read().decode())
        text = data.get("response", "").strip()

    # Strip markdown fences if model adds them
    text = re.sub(r"^```(?:json)?\s*", "", text)
    text = re.sub(r"\s*```$", "", text.strip())
    return json.loads(text)


def _call_llm_litellm(prompt: str) -> dict:
    """
    Use LiteLLM as a universal LLM router — supports 100+ providers
    (OpenRouter, Bedrock, vLLM, Groq, Mistral, Together, etc.) with a
    single interface. Set LLM_MODEL env var to any LiteLLM-supported model.

    Install: pip install litellm
    Config:  LLM_PROVIDER=litellm  LLM_MODEL=openrouter/anthropic/claude-3.5-sonnet
    """
    try:
        from litellm import completion
    except ImportError:
        raise RuntimeError(
            "litellm not installed. Run: pip install litellm\n"
            "Or switch to a built-in provider: LLM_PROVIDER=anthropic|gemini|openai|ollama"
        )

    model = os.environ.get("LLM_MODEL", "anthropic/claude-haiku-4-5")
    response = completion(
        model=model,
        messages=[
            {"role": "system", "content": "You are a JSON-only responder. Always return valid JSON matching the requested structure. No prose."},
            {"role": "user", "content": prompt},
        ],
        response_format={"type": "json_object"},
        timeout=30,
    )
    raw = response.choices[0].message.content.strip()
    # Strip markdown fences if present
    raw = re.sub(r"^```(?:json)?\s*", "", raw)
    raw = re.sub(r"\s*```$", "", raw.strip())
    return json.loads(raw)


_PROVIDER_MAP = {
    "gemini": _call_llm_gemini,
    "openai": _call_llm_openai,
    "anthropic": _call_llm_anthropic,
    "ollama": _call_llm_ollama,
    "litellm": _call_llm_litellm,
}


def _is_provider_credit_error(err: str) -> bool:
    low = (err or "").lower()
    markers = (
        "credit balance is too low",
        "insufficient_quota",
        "quota",
        "billing",
        "invalid_request_error",
    )
    return any(m in low for m in markers)


# ─── Context-Grounded Classification Prompt ──────────────────────────────────
# Injected when graph_context is available. Structured with XML tags for
# Qwen 2.5's training distribution — gives clear parsing boundaries and
# dramatically improves Override/PreferenceReveal accuracy.

_CONTEXT_CLASSIFICATION_PROMPT = """\
<task>
You are a memory extraction agent for a software collaboration system.
Classify the exchange below into ONE primitive type and extract structured metadata.
Your ONLY output is valid JSON matching the schema. No prose outside the JSON.
</task>

<primitive_types>
HIGH_SIGNAL (create graph nodes):
- Override: Human redirects mid-task ("no, let's do X instead", "actually...", "scratch that")
- ConstraintSurface: A constraint becomes explicit ("we can't use X because...", "must always...")
- DecisionClose: A path definitively chosen, alternatives ruled out
- PreferenceReveal: Human pushback revealing taste, values, or working style
- AbandonedAttempt: Something tried and explicitly dropped or failed

LOW_SIGNAL (do not create nodes):
- Exploration: Open brainstorm without resolution
- Execution: Routine implementation of an already-decided pattern
- Clarification: Agent asks, human answers, no redirection
- Confirmation: Human confirms agent plan without modification
</primitive_types>

<project_memory>
These already exist in the graph. Use them to:
1. Detect OVERRIDE — if this exchange contradicts or supersedes a decision below, classify as Override and set is_override_of to that decision's id
2. Avoid re-encoding — if this exchange restates something already captured, classify as Confirmation or Exploration (low-signal)
3. Detect REINFORCEMENT — if a preference below is reinforced, still classify as PreferenceReveal but note reinforcement_count will increase
4. Score novelty — novel insight = higher confidence; already-known = lower

<active_decisions>
{decisions}
</active_decisions>

<active_constraints>
{constraints}
</active_constraints>

<known_preferences>
{preferences}
</known_preferences>
</project_memory>

<exchange>
{exchange_text}
</exchange>

<output_schema>
Return exactly this JSON structure:
{{
  "primitive_type": "Override|ConstraintSurface|DecisionClose|PreferenceReveal|AbandonedAttempt|Exploration|Execution|Clarification|Confirmation",
  "confidence": 0.0,
  "description": "concise description of what happened in this exchange",
  "rationale": "why this path was chosen or abandoned — extract from text",
  "evidence": "direct quote or close paraphrase that best reveals the primitive",
  "preference_type": "aesthetic|process|technical|risk|interpersonal|null",
  "preference_domain": "specific domain e.g. API architecture or null",
  "constraint_scope": "what this constrains or null",
  "constraint_origin": "explicit|inferred|null",
  "abandoned_because": "reason for abandonment or null",
  "is_override_of": "id of the decision being overridden from active_decisions above, or null",
  "reasoning": "brief explanation of your classification decision"
}}
</output_schema>"""


def _build_context_prompt(exchange_text: str, graph_context: dict) -> str:
    """Build a context-grounded classification prompt from graph state."""
    decisions = graph_context.get("active_decisions", [])
    constraints = graph_context.get("active_constraints", [])
    preferences = graph_context.get("inferred_preferences", [])

    def _fmt_decisions(items):
        if not items:
            return "  (none yet)"
        return "\n".join(
            f"  [{d.get('id', '?')}] {d.get('description', '')[:120]}"
            for d in items[:15]
        )

    def _fmt_constraints(items):
        if not items:
            return "  (none yet)"
        return "\n".join(
            f"  - {c.get('description', '')[:120]}"
            for c in items[:10]
        )

    def _fmt_preferences(items):
        if not items:
            return "  (none yet)"
        return "\n".join(
            f"  [{p.get('type', '?')}] {p.get('description', '')[:100]}"
            for p in items[:10]
        )

    return _CONTEXT_CLASSIFICATION_PROMPT.format(
        decisions=_fmt_decisions(decisions),
        constraints=_fmt_constraints(constraints),
        preferences=_fmt_preferences(preferences),
        exchange_text=exchange_text,
    )


# ─── Keyword Pre-Screen ───────────────────────────────────────────────────────

_OVERRIDE_PATTERNS = re.compile(
    r"\b(no[,\s]|let'?s?\s+(?:not|do|use|go|try)|actually[,\s]|instead[,\s]|"
    r"scratch that|wait[,\s]|hold on|change|pivot|different approach|rather)\b",
    re.IGNORECASE,
)
_DECISION_PATTERNS = re.compile(
    r"\b(we'?ll\s+use|we'?re\s+going\s+with|decided|we\s+decided|locked\s+in|final(?:ly)?[,\s]|"
    r"that'?s?\s+the\s+one|going\s+with|sticking\s+with|settled\s+on|"
    r"let'?s?\s+(?:go|proceed|build|start|use)|I\s+think\s+we\s+can\s+proceed|"
    r"looks?\s+good[,\s]|good\s+to\s+go|ship\s+it|approved|"
    r"(?:^|[\n.!])\s*Decision:|going\s+forward|from\s+now\s+on|"
    r"the\s+decision\s+is|we\s+(?:agreed|chose|picked|selected|opted))",
    re.IGNORECASE | re.MULTILINE,
)
_ABANDON_PATTERNS = re.compile(
    r"\b(won'?t\s+work|doesn'?t\s+work|abandon|drop(?:ping)?|"
    r"too\s+complex|overkill|not\s+worth|skip\s+that|forget\s+it|scratch)\b",
    re.IGNORECASE,
)
_CONSTRAINT_PATTERNS = re.compile(
    r"\b(can'?t|cannot|must|always|never|need\s+to|have\s+to|"
    r"required?|blocked|limit(?:ation)?|constraint|no\s+budget|no\s+time)\b",
    re.IGNORECASE,
)
_PREFERENCE_PATTERNS = re.compile(
    r"\b(I\s+prefer|I\s+like\s+to|prefer\s+to|usually\s+(?:we|I)|"
    r"tend\s+to|my\s+preference|default\s+to|rather\s+(?:use|have|do)|"
    r"fan\s+of|go-?to|comfortable\s+with|style\s+is)\b",
    re.IGNORECASE,
)
_SKILL_PATTERNS = re.compile(
    r"\b((?:steps?\s+to|how\s+to|process\s+for|workflow|procedure)\b|"
    r"to\s+deploy|to\s+(?:set\s+up|configure|install|build|run|test|debug)|"
    r"recipe\s+for|playbook|run\s*book|SOP|standard\s+operating)\b",
    re.IGNORECASE,
)
_EXECUTION_PATTERNS = re.compile(
    r"\b(done|completed|implemented|added|created|fixed|updated|wrote)\b",
    re.IGNORECASE,
)


def _keyword_score(text: str) -> float:
    """Fast heuristic pre-screen. Returns 0.0–1.0."""
    score = 0.0
    if _OVERRIDE_PATTERNS.search(text):
        score += 0.4
    if _DECISION_PATTERNS.search(text):
        score += 0.3
    if _ABANDON_PATTERNS.search(text):
        score += 0.3
    if _CONSTRAINT_PATTERNS.search(text):
        score += 0.3
    if _PREFERENCE_PATTERNS.search(text):
        score += 0.3
    if _SKILL_PATTERNS.search(text):
        score += 0.3
    if _EXECUTION_PATTERNS.search(text) and score == 0.0:
        score -= 0.3
    return max(0.0, min(1.0, score))


# ─── LLM Classification ───────────────────────────────────────────────────────

_CLASSIFICATION_PROMPT = """\
You are classifying a conversation exchange between a human and an AI agent.
Your job is to identify the most significant primitive type and extract structured data.

The conversation is from a real software development collaboration session.

## Primitive Types
HIGH-SIGNAL (generate graph nodes):
- Override: Human redirects the agent mid-task ("no, let's do X instead", "actually...")
- ConstraintSurface: A constraint becomes explicit that was implicit ("we can't use X because...")
- DecisionClose: A path is definitively chosen, alternatives ruled out
- PreferenceReveal: Human pushes back in a way that reveals taste or values
- AbandonedAttempt: Something was tried and explicitly dropped

LOW-SIGNAL (skip or archive only):
- Exploration: Open-ended brainstorming without resolution
- Execution: Routine implementation of a known pattern
- Clarification: Agent asks, human answers, no redirection
- Confirmation: Human confirms agent's plan without modification

## Preference Types (if PreferenceReveal)
- aesthetic: taste in design, visual, writing style
- process: how they like to work, pace, planning depth
- technical: architectural instincts, stack choices, complexity tolerance
- risk: how they weigh speed vs correctness, ship vs polish
- interpersonal: how they interact with the agent

## Exchange Text
{exchange_text}

## Instructions
Respond with ONLY valid JSON in this exact structure:
{{
  "primitive_type": "<one of the types above>",
  "confidence": <0.0 to 1.0 — how certain you are of this classification>,
  "description": "<concise description of what happened in this exchange>",
  "rationale": "<why this path was chosen or abandoned — extract from text>",
  "evidence": "<direct quote or close paraphrase that best reveals the primitive>",
  "preference_type": "<aesthetic|process|technical|risk|interpersonal or null>",
  "preference_domain": "<specific domain e.g. 'API architecture' or null>",
  "constraint_scope": "<what this constrains or null>",
  "constraint_origin": "<explicit|inferred or null>",
  "abandoned_because": "<reason for abandonment or null>",
  "reasoning": "<brief explanation of your classification>"
}}
"""


def _call_llm(exchange_text: str, graph_context: dict | None = None) -> dict:
    """
    Call the configured LLM provider to classify an exchange.
    Provider is set via LLM_PROVIDER env var: gemini | openai | anthropic | ollama
    When graph_context is provided, uses the context-grounded Qwen prompt.
    Retries up to 3 times on rate limit errors.
    """
    provider_fn = _PROVIDER_MAP.get(LLM_PROVIDER)
    if not provider_fn:
        raise RuntimeError(f"Unknown LLM_PROVIDER: '{LLM_PROVIDER}'. Choose: gemini, openai, anthropic, ollama")

    if graph_context:
        prompt = _build_context_prompt(exchange_text, graph_context)
    else:
        prompt = _CLASSIFICATION_PROMPT.format(exchange_text=exchange_text)

    for attempt in range(3):
        try:
            return provider_fn(prompt)
        except Exception as e:
            err = str(e)
            # Anthropic quota failures are common on hosted tiers.
            # If Google key exists, fail over to Gemini so classification still works.
            if (
                LLM_PROVIDER == "anthropic"
                and os.environ.get("GOOGLE_API_KEY")
                and _is_provider_credit_error(err)
            ):
                print("\n[anthropic quota] falling back to gemini for classification")
                return _call_llm_gemini(prompt)
            is_rate_limit = any(x in err for x in ["429", "RESOURCE_EXHAUSTED", "rate_limit", "RateLimitError", "overloaded"])
            if is_rate_limit and attempt < 2:
                wait = 20 * (attempt + 1)
                print(f"\n[{LLM_PROVIDER} rate limit] waiting {wait}s (retry {attempt + 1}/3)...")
                time.sleep(wait)
            else:
                raise
    raise RuntimeError(f"LLM call failed after 3 retries ({LLM_PROVIDER})")  # unreachable but satisfies type checker


def _call_llm_text(system: str, user: str) -> str:
    """
    Call the configured LLM and return the raw text response.
    Unlike _call_llm, this does NOT apply the classification prompt and
    does NOT JSON-parse the response. Used by fact_extractor and other
    modules that manage their own prompts and parsing.
    """
    api_key_anthropic = os.environ.get("ANTHROPIC_API_KEY")
    api_key_google = os.environ.get("GOOGLE_API_KEY")

    for attempt in range(3):
        try:
            if LLM_PROVIDER == "ollama":
                # Route fact_extractor + consolidator through Ollama (text mode, no JSON enforcement)
                import urllib.request as _ulr
                _payload = json.dumps({
                    "model": OLLAMA_MODEL,
                    "messages": [
                        {"role": "system", "content": system},
                        {"role": "user", "content": user},
                    ],
                    "stream": False,
                    "options": {"temperature": 0.2, "num_predict": 2048},
                }).encode()
                _req = _ulr.Request(
                    f"{OLLAMA_BASE_URL}/v1/chat/completions", data=_payload,
                    headers={"Content-Type": "application/json"}, method="POST",
                )
                with _ulr.urlopen(_req, timeout=120) as _r:
                    _data = json.loads(_r.read().decode())
                return _data["choices"][0]["message"]["content"].strip()
            elif LLM_PROVIDER == "anthropic" and api_key_anthropic:
                import anthropic
                model = os.environ.get("ANTHROPIC_MODEL", "claude-haiku-4-5")
                _VALID_PREFIXES = ("claude-3", "claude-haiku", "claude-sonnet", "claude-opus")
                if not model.startswith(_VALID_PREFIXES):
                    model = "claude-haiku-4-5"
                client = anthropic.Anthropic(api_key=api_key_anthropic, timeout=20.0)
                response = client.messages.create(
                    model=model,
                    max_tokens=2048,
                    system=system,
                    messages=[{"role": "user", "content": user}],
                )
                return response.content[0].text
            elif LLM_PROVIDER == "gemini" and api_key_google:
                import google.genai as genai
                client = genai.Client(api_key=api_key_google)
                combined = f"{system}\n\n{user}"
                response = client.models.generate_content(
                    model=GEMINI_MODEL,
                    contents=combined,
                )
                return response.text
            else:
                # OpenAI fallback
                from openai import OpenAI
                api_key = os.environ.get("OPENAI_API_KEY", "")
                client = OpenAI(api_key=api_key)
                response = client.chat.completions.create(
                    model=os.environ.get("OPENAI_MODEL", "gpt-4o-mini"),
                    messages=[
                        {"role": "system", "content": system},
                        {"role": "user", "content": user},
                    ],
                )
                return response.choices[0].message.content or ""
        except Exception as e:
            err = str(e)
            if (
                LLM_PROVIDER == "anthropic"
                and api_key_google
                and _is_provider_credit_error(err)
            ):
                import google.genai as genai
                client = genai.Client(api_key=api_key_google)
                combined = f"{system}\n\n{user}"
                response = client.models.generate_content(
                    model=GEMINI_MODEL,
                    contents=combined,
                )
                return response.text
            is_rate_limit = any(x in err for x in ["429", "RESOURCE_EXHAUSTED", "rate_limit", "RateLimitError", "overloaded"])
            if is_rate_limit and attempt < 2:
                wait = 20 * (attempt + 1)
                time.sleep(wait)
            else:
                raise
    return ""


# ─── Node Builder ─────────────────────────────────────────────────────────────

def _build_nodes(
    llm_result: dict,
    exchange_record: ExchangeRecord,
    session_id: str,
) -> tuple[list, list[Edge]]:
    """
    Build graph nodes and edges from LLM classification result.
    Returns (nodes, edges).
    """
    nodes = []
    edges = []
    ptype = exchange_record.primitive_type

    if ptype == PrimitiveType.DecisionClose or ptype == PrimitiveType.Override:
        node = Decision(
            made_in=session_id,
            description=llm_result.get("description", ""),
            rationale=llm_result.get("rationale", ""),
            status=DecisionStatus.active,
            confidence=llm_result.get("confidence", 0.7),
            exchange_record_id=exchange_record.id,
        )
        nodes.append(node)
        edges.append(Edge(
            type="DECIDED_IN",
            source_id=node.id,
            target_id=session_id,
        ))

    if ptype == PrimitiveType.AbandonedAttempt:
        node = Attempt(
            tried_in=session_id,
            description=llm_result.get("description", ""),
            abandoned_because=llm_result.get("abandoned_because", ""),
            exchange_record_id=exchange_record.id,
        )
        nodes.append(node)
        edges.append(Edge(
            type="ATTEMPTED_IN",
            source_id=node.id,
            target_id=session_id,
        ))

    if ptype == PrimitiveType.ConstraintSurface:
        origin_raw = llm_result.get("constraint_origin", "explicit")
        try:
            origin = ConstraintOrigin(origin_raw)
        except ValueError:
            origin = ConstraintOrigin.explicit

        node = Constraint(
            surfaced_in=session_id,
            description=llm_result.get("description", ""),
            origin=origin,
            scope=llm_result.get("constraint_scope", ""),
            exchange_record_id=exchange_record.id,
        )
        nodes.append(node)
        edges.append(Edge(
            type="SURFACED_IN",
            source_id=node.id,
            target_id=session_id,
        ))

    if ptype == PrimitiveType.PreferenceReveal or (
        ptype == PrimitiveType.Override and llm_result.get("preference_type")
    ):
        pref_type_raw = llm_result.get("preference_type") or "technical"
        try:
            pref_type = PreferenceType(pref_type_raw)
        except ValueError:
            pref_type = PreferenceType.technical

        node = Preference(
            inferred_in=session_id,
            description=llm_result.get("description", ""),
            type=pref_type,
            domain=llm_result.get("preference_domain", ""),
            evidence=llm_result.get("evidence", ""),
            confidence=llm_result.get("confidence", 0.6),
            exchange_record_id=exchange_record.id,
        )
        nodes.append(node)
        edges.append(Edge(
            type="REVEALS",
            source_id=exchange_record.id,
            target_id=node.id,
        ))

    return nodes, edges


# ─── Main Encoder ─────────────────────────────────────────────────────────────

def encode_exchange(
    raw_text: str,
    session_id: str,
    turn_start: int,
    turn_end: Optional[int] = None,
    skip_llm: bool = False,
) -> ClassificationResult:
    """
    Classify a conversation exchange and produce graph-ready output.

    Args:
        raw_text: The raw conversation text (one or more turns).
        session_id: The Session.id this exchange belongs to.
        turn_start: Index of the first turn in this exchange.
        turn_end: Index of the last turn (defaults to turn_start).
        skip_llm: If True, use keyword scorer only (for testing).

    Returns:
        ClassificationResult with exchange_record, nodes, edges, and
        a should_encode flag.
    """
    if turn_end is None:
        turn_end = turn_start

    # Step 1: Keyword pre-screen
    keyword_score = _keyword_score(raw_text)

    if skip_llm:
        # Test mode: keyword only, minimal classification
        ptype = PrimitiveType.Exploration
        if keyword_score >= WORTHINESS_THRESHOLD:
            if _OVERRIDE_PATTERNS.search(raw_text):
                ptype = PrimitiveType.Override
            elif _DECISION_PATTERNS.search(raw_text):
                ptype = PrimitiveType.DecisionClose
            elif _ABANDON_PATTERNS.search(raw_text):
                ptype = PrimitiveType.AbandonedAttempt
            elif _CONSTRAINT_PATTERNS.search(raw_text):
                ptype = PrimitiveType.ConstraintSurface

        llm_result = {
            "primitive_type": ptype.value,
            "confidence": keyword_score,
            "description": raw_text[:200],
            "rationale": "",
            "evidence": "",
            "reasoning": "keyword-only mode",
        }
        final_score = keyword_score
    else:
        # Step 2: LLM classification
        llm_result = _call_llm(raw_text)
        llm_confidence = float(llm_result.get("confidence", 0.5))

        # Step 3: Merge keyword + LLM scores (weighted average)
        final_score = (keyword_score * 0.3) + (llm_confidence * 0.7)

        ptype_raw = llm_result.get("primitive_type", "Exploration")
        try:
            ptype = PrimitiveType(ptype_raw)
        except ValueError:
            ptype = PrimitiveType.Exploration

    # Step 4: Threshold logic (>= 0.4 encodes; 0.3-0.4 is ambiguous)
    flagged = AMBIGUITY_LOWER <= final_score < WORTHINESS_THRESHOLD
    should_encode = final_score >= WORTHINESS_THRESHOLD and ptype in HIGH_SIGNAL_PRIMITIVES

    # Step 5: Build ExchangeRecord (always created)
    exchange_record = ExchangeRecord(
        session_id=session_id,
        turn_start=turn_start,
        turn_end=turn_end,
        raw_text=raw_text,
        primitive_type=ptype,
        worthiness_score=round(final_score, 3),
        extractor_version=EXTRACTOR_VERSION,
        flagged_for_review=flagged,
    )

    # Step 6: Build graph nodes if high-signal and above threshold
    nodes: list = []
    graph_edges: list[Edge] = []

    if should_encode:
        nodes, graph_edges = _build_nodes(llm_result, exchange_record, session_id)
        exchange_record.nodes_generated = [n.id for n in nodes]

    return ClassificationResult(
        exchange_record=exchange_record,
        nodes=nodes,
        edges=graph_edges,
        should_encode=should_encode,
        classifier_reasoning=llm_result.get("reasoning", ""),
    )


def encode_session(
    turns: list[str],
    session_id: str,
    skip_llm: bool = False,
) -> list[ClassificationResult]:
    """
    Encode an entire session's turns, applying the multi-turn pending buffer.

    Each turn is evaluated individually. If a high-signal opening is detected
    but not yet resolved, subsequent turns are appended to the buffer up to
    the 6-turn resolution window.

    Args:
        turns: List of raw turn strings (alternating human/agent or flat).
        session_id: The session identifier.
        skip_llm: Bypass LLM for keyword-only testing.

    Returns:
        List of ClassificationResults, one per resolved exchange span.
    """
    results = []
    i = 0
    pending_buffer: list[str] = []
    pending_start: Optional[int] = None
    MAX_WINDOW = 6

    while i < len(turns):
        turn = turns[i]

        if pending_buffer:
            pending_buffer.append(turn)
            span_text = "\n".join(pending_buffer)
            span_len = len(pending_buffer)

            # Check if this turn resolves the pending span
            score = _keyword_score(span_text)
            resolved = score >= WORTHINESS_THRESHOLD or span_len >= MAX_WINDOW

            if resolved:
                result = encode_exchange(
                    raw_text=span_text,
                    session_id=session_id,
                    turn_start=pending_start,
                    turn_end=i,
                    skip_llm=skip_llm,
                )
                results.append(result)
                pending_buffer = []
                pending_start = None
        else:
            score = _keyword_score(turn)
            if score >= WORTHINESS_THRESHOLD:
                # Immediate resolution
                result = encode_exchange(
                    raw_text=turn,
                    session_id=session_id,
                    turn_start=i,
                    turn_end=i,
                    skip_llm=skip_llm,
                )
                results.append(result)
            elif score > 0.15:
                # High-signal opening, start pending buffer
                pending_buffer = [turn]
                pending_start = i
            # else: low signal, skip

        i += 1

    # Flush any remaining pending buffer
    if pending_buffer:
        result = encode_exchange(
            raw_text="\n".join(pending_buffer),
            session_id=session_id,
            turn_start=pending_start,
            turn_end=i - 1,
            skip_llm=skip_llm,
        )
        results.append(result)

    return results
