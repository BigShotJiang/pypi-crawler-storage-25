"""
session_ingester.py — On-startup ingestion of the Antigravity brain folder.

Sprint S9: Routes chunks through /memory/ingest (full pipeline with Fact Extractor)
instead of flat /memory/record writes. Each chunk is now:
  1. Classified by the LLM (Decision / Constraint / Preference / Observation)
  2. Deduplicated via Memory Consolidator (ADD / UPDATE / DELETE / NOOP)
  3. Tagged with project_id, module, category

Falls back to /memory/record (direct write) on pipeline failure (e.g. 502).

Usage (set in mcp_config.json env):
    ANTIGRAVITY_BRAIN_DIR=/path/to/brain/<conversation-id>
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import time
import urllib.error
import urllib.request

logger = logging.getLogger(__name__)

# Files to skip even if present in the brain folder
_SKIP_PATTERNS = {
    "walkthrough.md",           # proof-of-work notes only
    ".system_generated",        # AI-internal logs
}

# Max bytes per chunk sent to the pipeline
_MAX_CHUNK = 2000

# Map filename patterns to module + category for taxonomy tagging
_FILE_MODULE_MAP: list[tuple[str, str, str]] = [
    # (filename_contains, module, category)
    ("task",              "project-mgmt",    "task"),
    ("implementation",    "architecture",    "prd"),
    ("walkthrough",       "project-mgmt",    "prd"),
    ("research",          "research",        "research"),
    ("sprint",            "architecture",    "decision"),
    ("schema",            "data-layer",      "decision"),
    ("pipeline",          "pipeline",        "decision"),
    ("api",               "api",             "decision"),
    ("skill",             "skills",          "skill"),
    ("workflow",          "skills",          "skill"),
    ("architecture",      "architecture",    "decision"),
    ("master",            "architecture",    "decision"),
]


def _classify_file(filename: str) -> tuple[str, str]:
    """Return (module, category) for a given filename using the taxonomy map."""
    fname = filename.lower()
    for pattern, module, category in _FILE_MODULE_MAP:
        if pattern in fname:
            return module, category
    return "general", "research"


def _chunk_markdown(text: str, source_file: str) -> list[dict]:
    """
    Split a markdown document into meaningful chunks by heading.
    Each chunk includes the heading as context prefix.

    Returns list of dicts: {content, heading, source}.
    """
    chunks = []
    sections = re.split(r"(?m)^(#{1,3} .+)$", text.strip())
    current_heading = os.path.basename(source_file)
    buffer = ""

    for part in sections:
        if re.match(r"^#{1,3} ", part):
            if buffer.strip():
                chunks.append({
                    "content": f"{current_heading}\n\n{buffer.strip()}"[:_MAX_CHUNK],
                    "heading": current_heading,
                    "source": source_file,
                })
                buffer = ""
            current_heading = part.strip()
        else:
            buffer += part

    if buffer.strip():
        chunks.append({
            "content": f"{current_heading}\n\n{buffer.strip()}"[:_MAX_CHUNK],
            "heading": current_heading,
            "source": source_file,
        })

    # No headings → chunk by size
    if not chunks and text.strip():
        for i in range(0, len(text), _MAX_CHUNK):
            chunks.append({
                "content": text[i: i + _MAX_CHUNK],
                "heading": os.path.basename(source_file),
                "source": source_file,
            })

    return chunks


def _post_ingest(
    base_url: str,
    api_key: str,
    content: str,
    session_id: str,
    project_id: str = "",
) -> bool:
    """
    POST to /memory/ingest — runs through the full pipeline
    (Classifier → Fact Extractor → Memory Consolidator → Graph Writer).
    Returns True on success, False on any error.
    """
    url = f"{base_url}/memory/ingest"
    payload = json.dumps({
        "raw_text": content,
        "session_id": session_id,
        "project_id": project_id or None,
    }).encode()
    headers = {"Content-Type": "application/json", "X-API-Key": api_key}
    req = urllib.request.Request(url, data=payload, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=90) as r:
            result = json.loads(r.read().decode())
            return "id" in result or result.get("status") != "error"
    except urllib.error.HTTPError as e:
        logger.debug("session_ingester: /ingest HTTP %s: %s", e.code, e.reason)
        return False
    except Exception as e:
        logger.debug("session_ingester: /ingest error: %s", e)
        return False


def _post_record(
    base_url: str,
    api_key: str,
    content: str,
    session_id: str,
    project_id: str = "",
    module: str = "",
    category: str = "research",
) -> bool:
    """
    Fallback: POST to /memory/record (direct write, no Fact Extractor).
    Used when /memory/ingest fails (e.g. Render cold-start 502).
    """
    url = f"{base_url}/memory/record"
    payload = json.dumps({
        "content": content,
        "node_type": "Decision",
        "session_id": session_id,
        "project_id": project_id or None,
        "module": module,
        "category": category,
        "rationale": "Auto-ingested from Antigravity brain session folder (fallback)",
    }).encode()
    headers = {"Content-Type": "application/json", "X-API-Key": api_key}
    req = urllib.request.Request(url, data=payload, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            result = json.loads(r.read().decode())
            return result.get("status") == "written"
    except urllib.error.HTTPError as e:
        logger.warning("session_ingester: /record HTTP %s: %s", e.code, e.reason)
        return False
    except Exception as e:
        logger.warning("session_ingester: /record error: %s", e)
        return False


def _post_chunk(
    base_url: str,
    api_key: str,
    content: str,
    session_id: str,
    project_id: str = "",
    module: str = "",
    category: str = "research",
) -> bool:
    """
    Route a chunk through the pipeline (/memory/ingest), falling back to
    /memory/record if the pipeline fails. Returns True on any success.
    """
    # Try pipeline first
    ok = _post_ingest(base_url, api_key, content, session_id, project_id)
    if ok:
        return True
    # Fallback: direct write
    logger.debug("session_ingester: pipeline failed, using direct write fallback")
    return _post_record(base_url, api_key, content, session_id, project_id, module, category)


def _file_hash(path: str) -> str:
    """SHA-1 of file contents for change detection."""
    h = hashlib.sha1()
    with open(path, "rb") as f:
        h.update(f.read())
    return h.hexdigest()


def ingest_brain_folder(
    brain_dir: str,
    base_url: str,
    api_key: str,
    session_id: str | None = None,
    project_id: str | None = None,
    delay_between_posts: float = 0.8,
) -> dict:
    """
    Read all .md files in brain_dir and route each meaningful chunk through
    the collab-memory pipeline for typed extraction and consolidation.

    Args:
        brain_dir:           Path to the AG brain folder for this conversation.
        base_url:            collab-memory API base URL.
        api_key:             COLLAB_API_KEY.
        session_id:          Session label (defaults to folder name = conversation ID).
        project_id:          Project scope for all nodes (e.g. 'collab-memory').
        delay_between_posts: Seconds between POSTs — prevents Render overload.

    Returns:
        Summary: files_scanned, chunks_sent, chunks_ok, chunks_failed, chunks_skipped.
    """
    if not os.path.isdir(brain_dir):
        logger.error("session_ingester: brain_dir not found: %s", brain_dir)
        return {"error": f"Directory not found: {brain_dir}"}

    if not session_id:
        session_id = os.path.basename(brain_dir.rstrip("/"))

    # Resolve project_id from env if not explicitly provided
    if not project_id:
        project_id = os.environ.get("COLLAB_PROJECT_ID", "")

    manifest_path = os.path.join(brain_dir, ".collab_ingested")
    manifest: dict = {}
    if os.path.exists(manifest_path):
        try:
            with open(manifest_path) as f:
                manifest = json.load(f)
        except Exception:
            manifest = {}

    files_scanned = 0
    chunks_sent = 0
    chunks_ok = 0
    chunks_failed = 0
    files_skipped = 0

    for filename in sorted(os.listdir(brain_dir)):
        if not filename.endswith(".md"):
            continue
        if any(skip in filename for skip in _SKIP_PATTERNS):
            continue

        filepath = os.path.join(brain_dir, filename)
        files_scanned += 1

        current_hash = _file_hash(filepath)
        if manifest.get(filename) == current_hash:
            files_skipped += 1
            logger.debug("session_ingester: skip unchanged %s", filename)
            continue

        try:
            with open(filepath, encoding="utf-8") as f:
                text = f.read()
        except Exception as e:
            logger.warning("session_ingester: could not read %s: %s", filename, e)
            continue

        # Determine taxonomy tagging for this file
        module, category = _classify_file(filename)
        chunks = _chunk_markdown(text, filename)
        logger.info(
            "session_ingester: ingesting %s → %d chunks (module=%s, category=%s)",
            filename, len(chunks), module, category,
        )

        for chunk in chunks:
            content = chunk["content"].strip()
            if not content or len(content) < 50:
                continue

            chunks_sent += 1
            ok = _post_chunk(
                base_url, api_key, content, session_id,
                project_id=project_id, module=module, category=category,
            )
            if ok:
                chunks_ok += 1
            else:
                chunks_failed += 1

            if delay_between_posts > 0:
                time.sleep(delay_between_posts)

        manifest[filename] = current_hash

    try:
        with open(manifest_path, "w") as f:
            json.dump(manifest, f, indent=2)
    except Exception as e:
        logger.warning("session_ingester: could not write manifest: %s", e)

    summary = {
        "brain_dir": brain_dir,
        "session_id": session_id,
        "project_id": project_id or "default",
        "files_scanned": files_scanned,
        "files_skipped": files_skipped,
        "chunks_sent": chunks_sent,
        "chunks_ok": chunks_ok,
        "chunks_failed": chunks_failed,
        "pipeline_first": True,  # S9: routes through Fact Extractor + Memory Consolidator
    }
    logger.info("session_ingester: done — %s", summary)
    return summary
