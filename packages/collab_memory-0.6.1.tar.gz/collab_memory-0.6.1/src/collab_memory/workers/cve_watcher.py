"""
workers/cve_watcher.py — Live CVE monitoring for the collab-memory stack.

Polls OSV (Open Source Vulnerabilities) and CISA KEV (Known Exploited
Vulnerabilities) every 6 hours. New CVEs are ingested as Skill nodes
tagged ["security", "cve", "active"] so they're immediately queryable
by agents via semantic search and surface in get_context() security_brief.

No external dependencies beyond httpx (already available via anthropic sdk)
or falls back to urllib. Zero new pip requirements.

Security philosophy: ambient threat awareness baked into every session.
Agents arrive knowing what's actively exploited in the stack — no manual
security review required.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import os
from datetime import datetime, timezone
from typing import TYPE_CHECKING
from urllib.request import urlopen, Request
from urllib.error import URLError

if TYPE_CHECKING:
    from ..graph.neo4j_backend import Neo4jBackend

logger = logging.getLogger(__name__)

# ── Stack packages to monitor ─────────────────────────────────────────────────
# Derived from pyproject.toml core dependencies.
# Add new packages here when the stack changes.
MONITORED_PACKAGES = [
    ("fastapi",        "PyPI"),
    ("pydantic",       "PyPI"),
    ("neo4j",          "PyPI"),
    ("langgraph",      "PyPI"),
    ("anthropic",      "PyPI"),
    ("gunicorn",       "PyPI"),
    ("uvicorn",        "PyPI"),
    ("python-jose",    "PyPI"),
    ("argon2-cffi",    "PyPI"),
    ("slowapi",        "PyPI"),
    ("mcp",            "PyPI"),
    ("graphiti-core",  "PyPI"),
]

_POLL_INTERVAL_SECONDS = int(os.environ.get("CVE_POLL_INTERVAL_HOURS", "6")) * 3600
_OSV_QUERY_URL = "https://api.osv.dev/v1/query"
_CISA_KEV_URL  = "https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json"


# ── HTTP helpers (urllib only — no new deps) ──────────────────────────────────

def _post_json(url: str, payload: dict, timeout: int = 15) -> dict:
    data = json.dumps(payload).encode()
    req = Request(url, data=data, headers={"Content-Type": "application/json"})
    with urlopen(req, timeout=timeout) as r:
        return json.loads(r.read())


def _get_json(url: str, timeout: int = 20) -> dict:
    req = Request(url, headers={"Accept": "application/json"})
    with urlopen(req, timeout=timeout) as r:
        return json.loads(r.read())


# ── CVE node helpers ──────────────────────────────────────────────────────────

def _cve_skill_id(cve_id: str) -> str:
    return "cve_" + hashlib.md5(cve_id.encode()).hexdigest()[:12]


def _severity_from_osv(vuln: dict) -> str:
    """Extract highest severity string from OSV vulnerability record."""
    for sev in vuln.get("severity", []):
        score_str = sev.get("score", "")
        if "CRITICAL" in score_str.upper():
            return "CRITICAL"
        if "HIGH" in score_str.upper():
            return "HIGH"
    # Fallback: check database_specific
    db_specific = vuln.get("database_specific", {})
    severity = db_specific.get("severity", "").upper()
    if severity in ("CRITICAL", "HIGH", "MEDIUM", "LOW"):
        return severity
    return "UNKNOWN"


def _affected_packages(vuln: dict) -> list[str]:
    return [
        a.get("package", {}).get("name", "")
        for a in vuln.get("affected", [])
        if a.get("package", {}).get("name")
    ]


def _fixed_versions(vuln: dict) -> list[str]:
    versions = []
    for affected in vuln.get("affected", []):
        for rng in affected.get("ranges", []):
            for event in rng.get("events", []):
                fixed = event.get("fixed")
                if fixed:
                    versions.append(fixed)
    return versions


# ── OSV client ────────────────────────────────────────────────────────────────

def fetch_osv_vulns(package: str, ecosystem: str) -> list[dict]:
    """Query OSV for all known vulnerabilities in a package."""
    try:
        result = _post_json(_OSV_QUERY_URL, {
            "package": {"name": package, "ecosystem": ecosystem}
        })
        return result.get("vulns", [])
    except (URLError, json.JSONDecodeError, Exception) as e:
        logger.warning("OSV query failed for %s: %s", package, e)
        return []


# ── CISA KEV client ───────────────────────────────────────────────────────────

def fetch_cisa_kev() -> list[dict]:
    """Fetch the full CISA Known Exploited Vulnerabilities catalog."""
    try:
        data = _get_json(_CISA_KEV_URL)
        return data.get("vulnerabilities", [])
    except (URLError, json.JSONDecodeError, Exception) as e:
        logger.warning("CISA KEV fetch failed: %s", e)
        return []


# ── Ingestion ─────────────────────────────────────────────────────────────────

def ingest_osv_vuln(vuln: dict, graph: "Neo4jBackend", package: str) -> bool:
    """Ingest a single OSV vulnerability as a Skill node. Returns True if new."""
    from ..schema import Skill, SkillSourceType

    cve_ids = vuln.get("aliases", []) + [vuln.get("id", "")]
    # Prefer CVE-XXXX-XXXXX id if present
    primary_id = next((i for i in cve_ids if i.startswith("CVE-")), vuln.get("id", ""))
    if not primary_id:
        return False

    skill_id = _cve_skill_id(primary_id)
    severity = _severity_from_osv(vuln)
    packages = _affected_packages(vuln) or [package]
    fixed = _fixed_versions(vuln)
    summary = vuln.get("summary") or vuln.get("details", "")[:300]
    details = vuln.get("details", "")

    tags = ["security", "cve", "active"] + [p.lower() for p in packages[:3]]
    if severity in ("CRITICAL", "HIGH"):
        tags.append(severity.lower())

    content = (
        f"**{primary_id}** — {severity}\n\n"
        f"Affected packages: {', '.join(packages)}\n"
        f"{('Fixed in: ' + ', '.join(fixed) + chr(10)) if fixed else ''}"
        f"\n{details[:2000]}"
    )

    skill = Skill(
        id=skill_id,
        name=f"{primary_id}: {summary[:80]}",
        url=f"https://osv.dev/vulnerability/{vuln.get('id', primary_id)}",
        summary=f"[{severity}] {summary[:300]}",
        content=content,
        tags=tags,
        source_type=SkillSourceType.guide,
        added_by="cve_watcher",
    )

    try:
        graph.save_skill(skill)
        return True
    except Exception as e:
        logger.error("Failed to ingest CVE %s: %s", primary_id, e)
        return False


def ingest_cisa_kev_entry(entry: dict, graph: "Neo4jBackend") -> bool:
    """Ingest a CISA KEV entry as a Skill node. Returns True if new/updated."""
    from ..schema import Skill, SkillSourceType

    cve_id = entry.get("cveID", "")
    if not cve_id:
        return False

    skill_id = _cve_skill_id(cve_id)
    product = entry.get("product", "")
    vendor = entry.get("vendorProject", "")
    description = entry.get("shortDescription", "")
    due_date = entry.get("dueDate", "")
    date_added = entry.get("dateAdded", "")
    required_action = entry.get("requiredAction", "")

    # KEV entries are always HIGH or CRITICAL by definition (actively exploited)
    tags = ["security", "cve", "active", "exploited", "kev"]
    if product:
        tags.append(product.lower().replace(" ", "-")[:20])

    content = (
        f"**{cve_id}** — ACTIVELY EXPLOITED (CISA KEV)\n\n"
        f"Product: {vendor} {product}\n"
        f"Added to KEV: {date_added}\n"
        f"Required action by: {due_date}\n\n"
        f"{description}\n\n"
        f"**Required action:** {required_action}"
    )

    skill = Skill(
        id=skill_id,
        name=f"{cve_id} [EXPLOITED]: {description[:60]}",
        url=f"https://www.cisa.gov/known-exploited-vulnerabilities-catalog",
        summary=f"[CRITICAL/EXPLOITED] {description[:300]}",
        content=content,
        tags=tags,
        source_type=SkillSourceType.guide,
        added_by="cve_watcher_kev",
    )

    try:
        graph.save_skill(skill)
        return True
    except Exception as e:
        logger.error("Failed to ingest KEV %s: %s", cve_id, e)
        return False


# ── Watcher class ─────────────────────────────────────────────────────────────

class CVEWatcher:
    """
    Background asyncio task that polls CVE feeds and ingests into the graph.

    Usage:
        watcher = CVEWatcher(graph)
        task = asyncio.create_task(watcher.run())
        # on shutdown:
        task.cancel()
    """

    def __init__(self, graph: "Neo4jBackend"):
        self.graph = graph
        self._last_run: datetime | None = None
        self._stats = {"ingested": 0, "errors": 0, "runs": 0}

    async def run(self) -> None:
        """Main loop — waits 60s after startup, then polls every interval."""
        logger.info("[CVEWatcher] Starting — first poll in 60s, then every %dh", _POLL_INTERVAL_SECONDS // 3600)
        await asyncio.sleep(60)  # let server stabilize before heavy I/O
        while True:
            try:
                await asyncio.get_event_loop().run_in_executor(None, self._poll_once)
            except Exception as e:
                logger.error("[CVEWatcher] Poll cycle failed: %s", e)
                self._stats["errors"] += 1
            await asyncio.sleep(_POLL_INTERVAL_SECONDS)

    def _poll_once(self) -> None:
        """Synchronous poll — runs in thread executor to avoid blocking event loop."""
        logger.info("[CVEWatcher] Polling CVE feeds…")
        ingested = 0

        # 1. OSV — query each monitored package
        for package, ecosystem in MONITORED_PACKAGES:
            vulns = fetch_osv_vulns(package, ecosystem)
            for vuln in vulns:
                if ingest_osv_vuln(vuln, self.graph, package):
                    ingested += 1

        # 2. CISA KEV — ingest all actively exploited entries
        kev_entries = fetch_cisa_kev()
        for entry in kev_entries:
            if ingest_cisa_kev_entry(entry, self.graph):
                ingested += 1

        self._last_run = datetime.now(timezone.utc)
        self._stats["ingested"] += ingested
        self._stats["runs"] += 1
        logger.info("[CVEWatcher] Done — %d CVEs ingested/updated this cycle", ingested)

    def status(self) -> dict:
        return {
            "last_run": self._last_run.isoformat() if self._last_run else None,
            "poll_interval_hours": _POLL_INTERVAL_SECONDS // 3600,
            "monitored_packages": len(MONITORED_PACKAGES),
            "total_ingested": self._stats["ingested"],
            "total_runs": self._stats["runs"],
            "errors": self._stats["errors"],
        }


# ── Security brief query (used by build_context_brief) ───────────────────────

def get_security_brief(graph: "Neo4jBackend", limit: int = 5) -> dict:
    """
    Returns a compact security brief for inclusion in get_context() responses.
    Queries the graph for recent CVE Skill nodes, prioritizing CRITICAL/HIGH/KEV.
    """
    try:
        rows = graph._tx_read(
            """
            MATCH (s:Skill)
            WHERE 'cve' IN s.tags AND 'active' IN s.tags
            RETURN s.id AS id, s.name AS name, s.summary AS summary,
                   s.tags AS tags, s.created_at AS created_at
            ORDER BY s.created_at DESC
            LIMIT 50
            """
        )
    except Exception as e:
        logger.warning("[CVEWatcher] security_brief query failed: %s", e)
        return {"available": False, "error": str(e)}

    if not rows:
        return {"available": True, "total": 0, "highlights": [], "as_of": None}

    # Tier by severity
    critical, high, exploited, other = [], [], [], []
    for r in rows:
        tags = r.get("tags") or []
        name = r.get("name", "")
        summary = r.get("summary", "")
        entry = {"id": r["id"], "name": name[:120], "summary": (summary or "")[:200]}
        if "exploited" in tags or "kev" in tags:
            exploited.append(entry)
        elif "critical" in tags:
            critical.append(entry)
        elif "high" in tags:
            high.append(entry)
        else:
            other.append(entry)

    highlights = (exploited + critical + high + other)[:limit]

    return {
        "available": True,
        "total": len(rows),
        "critical": len(critical),
        "high": len(high),
        "exploited_in_wild": len(exploited),
        "highlights": highlights,
        "as_of": datetime.now(timezone.utc).isoformat(),
        "note": "CVEs affecting monitored stack packages. Updated every 6h.",
    }
