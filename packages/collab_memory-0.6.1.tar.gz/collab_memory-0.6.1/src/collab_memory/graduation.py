"""
collab_memory/graduation.py — Cognitive Dreams graduation engine.

Promotes nodes through the memory hierarchy based on recall reinforcement:

    Detail → Preference    (recall_count >= 3)
    Preference → Rule      (cross-project recall in >= 3 distinct projects)
    Rule → Hard Rule       (user-promoted only — never automatic)

Called after reinforcement (neo4j_backend.reinforce_nodes) to check if
any retrieved nodes have crossed a graduation threshold.

Hard Rules are NEVER automatically created — they require explicit user
promotion via POST /memory/promote or the dashboard HITL confirm flow.
This is a safety constraint: ambient assumptions must be human-approved.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any

logger = logging.getLogger(__name__)

# ── Graduation thresholds (from CLAUDE.md) ──

RECALL_TO_PREFERENCE = 3       # recall_count >= 3 → promote to Preference
CROSS_PROJECT_TO_RULE = 3      # distinct project_ids >= 3 → promote to Rule


@dataclass
class GraduationEvent:
    """Record of a single node promotion."""
    node_id: str
    from_type: str
    to_type: str
    reason: str
    recall_count: int = 0
    project_count: int = 0


def check_graduations(
    node_ids: list[str],
    backend: Any,
) -> list[GraduationEvent]:
    """
    Check a batch of nodes for graduation eligibility and execute promotions.

    Only promotes:
      - Decision/Constraint/Attempt → Preference (if recall_count >= 3)
      - Preference → Rule (if recalled in >= 3 distinct projects)

    Rule → HardRule is intentionally excluded — requires user action.

    Args:
        node_ids: Node IDs to check (typically from a recent retrieval).
        backend:  Neo4j backend instance for reads and writes.

    Returns:
        List of GraduationEvents for nodes that were promoted.
    """
    if not node_ids:
        return []

    events: list[GraduationEvent] = []

    try:
        # Batch fetch recall_count and type for all candidate nodes
        rows = backend._tx_read(
            """
            UNWIND $ids AS nid
            MATCH (n) WHERE n.id = nid
            RETURN n.id AS id,
                   labels(n)[0] AS node_type,
                   COALESCE(n.recall_count, 0) AS recall_count,
                   COALESCE(n.reinforcement_count, 0) AS reinforcement_count,
                   n.project_id AS project_id,
                   n.graduated_at AS graduated_at
            """,
            ids=node_ids,
        )
    except Exception as e:
        logger.warning("graduation: failed to fetch node data: %s", e)
        return []

    # ── Phase 1: Detail → Preference ──
    # "Detail" types are Decision, Constraint, Attempt that have been recalled enough
    detail_types = {"Decision", "Constraint", "Attempt"}
    for row in rows:
        ntype = row.get("node_type", "")
        recall = max(row.get("recall_count", 0), row.get("reinforcement_count", 0))
        nid = row["id"]

        if ntype in detail_types and recall >= RECALL_TO_PREFERENCE and not row.get("graduated_at"):
            try:
                _promote_to_preference(nid, ntype, backend)
                events.append(GraduationEvent(
                    node_id=nid,
                    from_type=ntype,
                    to_type="Preference",
                    reason=f"Recalled {recall} times (threshold: {RECALL_TO_PREFERENCE})",
                    recall_count=recall,
                ))
                logger.info("graduation: %s %s → Preference (recall_count=%d)", ntype, nid, recall)
            except Exception as e:
                logger.warning("graduation: failed to promote %s %s: %s", ntype, nid, e)

    # ── Phase 2: Preference → Rule ──
    # Check if Preferences have been recalled across multiple projects
    pref_ids = [r["id"] for r in rows if r.get("node_type") == "Preference"]
    if pref_ids:
        try:
            cross_project = backend._tx_read(
                """
                UNWIND $ids AS nid
                MATCH (n:Preference) WHERE n.id = nid
                WITH n
                OPTIONAL MATCH (n)-[:RELATES_TO]-(other)
                WHERE other.project_id IS NOT NULL AND other.project_id <> n.project_id
                WITH n, COLLECT(DISTINCT other.project_id) + [n.project_id] AS projects
                WHERE SIZE(projects) >= $threshold
                RETURN n.id AS id,
                       COALESCE(n.recall_count, n.reinforcement_count, 0) AS recall_count,
                       SIZE(projects) AS project_count
                """,
                ids=pref_ids,
                threshold=CROSS_PROJECT_TO_RULE,
            )
            for row in cross_project:
                nid = row["id"]
                try:
                    _promote_to_rule(nid, backend)
                    events.append(GraduationEvent(
                        node_id=nid,
                        from_type="Preference",
                        to_type="Rule",
                        reason=f"Applied across {row['project_count']} projects (threshold: {CROSS_PROJECT_TO_RULE})",
                        recall_count=row.get("recall_count", 0),
                        project_count=row["project_count"],
                    ))
                    logger.info("graduation: Preference %s → Rule (projects=%d)", nid, row["project_count"])
                except Exception as e:
                    logger.warning("graduation: failed to promote Preference %s to Rule: %s", nid, e)
        except Exception as e:
            logger.warning("graduation: cross-project check failed: %s", e)

    return events


def _promote_to_preference(node_id: str, from_type: str, backend: Any) -> None:
    """Add Preference label. Lineage tracked in node properties (graduated_from, graduated_at)."""
    import datetime as _dt
    now = _dt.datetime.now(_dt.timezone.utc).isoformat()
    backend._tx_write(
        """
        MATCH (n) WHERE n.id = $nid AND n.graduated_at IS NULL
        SET n:Preference,
            n.graduated_from = $from_type,
            n.graduated_at = $now
        """,
        nid=node_id,
        from_type=from_type,
        now=now,
    )


def _promote_to_rule(node_id: str, backend: Any) -> None:
    """Add Rule label. Lineage tracked in node properties (graduated_from, graduated_at)."""
    import datetime as _dt
    now = _dt.datetime.now(_dt.timezone.utc).isoformat()
    backend._tx_write(
        """
        MATCH (n:Preference) WHERE n.id = $nid
        SET n:Rule,
            n.graduated_from = 'Preference',
            n.graduated_at = $now
        """,
        nid=node_id,
        now=now,
    )
