"""
collab_memory/secrets.py — Cross-platform secret resolution.

Secret resolution chain (priority order):
  1. Doppler CLI   — if `doppler` binary is in PATH and configured
  2. Local .env    — dotenv loaded from project root
  3. OS env vars   — standard os.environ

Agents call: get_secret("GOOGLE_API_KEY")
Always returns the secret or raises SecretNotFoundError — never exposes which
layer it came from, keeping the agent code platform-neutral.

Usage:
    from collab_memory.secrets import get_secret, list_available_secrets
    key = get_secret("GOOGLE_API_KEY")
"""
from __future__ import annotations

import os
import subprocess
import json
from typing import Optional


class SecretNotFoundError(Exception):
    pass


def _try_doppler(key: str) -> Optional[str]:
    """Try fetching a single secret via Doppler CLI."""
    try:
        result = subprocess.run(
            ["doppler", "secrets", "get", key, "--plain"],
            capture_output=True,
            text=True,
            timeout=3,
        )
        if result.returncode == 0:
            return result.stdout.strip() or None
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass
    return None


def _try_env(key: str) -> Optional[str]:
    """Try OS environment variables (loaded from .env by dotenv)."""
    return os.environ.get(key) or None


def get_secret(key: str, required: bool = True) -> Optional[str]:
    """
    Resolve a secret from Doppler → .env → os.environ.

    Args:
        key:      Secret name, e.g. "GOOGLE_API_KEY"
        required: If True, raises SecretNotFoundError when not found.

    Returns:
        Secret value string, or None if not required and not found.
    """
    # Layer 1: Doppler (cross-platform, team-shared, zero-copy)
    value = _try_doppler(key)
    if value:
        return value

    # Layer 2 + 3: .env + os.environ (dotenv loaded at server startup)
    value = _try_env(key)
    if value:
        return value

    if required:
        raise SecretNotFoundError(
            f"Secret '{key}' not found. "
            f"Add it via: doppler secrets set {key}=<value>  "
            f"or set it in your .env file."
        )
    return None


def get_secrets_status() -> dict:
    """
    Return a status dict showing which resolution layers are available.
    Safe to expose via API — never returns actual secret values.
    """
    layers = {}

    # Check Doppler
    try:
        result = subprocess.run(
            ["doppler", "secrets", "--json"],
            capture_output=True, text=True, timeout=3,
        )
        if result.returncode == 0:
            d = json.loads(result.stdout)
            layers["doppler"] = {
                "available": True,
                "secret_count": len(d),
                "keys": sorted(d.keys()),
            }
        else:
            layers["doppler"] = {"available": False, "reason": "not configured (run: doppler setup)"}
    except FileNotFoundError:
        layers["doppler"] = {"available": False, "reason": "CLI not installed (brew install dopplerhq/cli/doppler)"}
    except Exception as e:
        layers["doppler"] = {"available": False, "reason": str(e)}

    # Check .env
    from pathlib import Path
    env_path = Path(".env")
    if env_path.exists():
        keys = [
            line.split("=")[0].strip()
            for line in env_path.read_text().splitlines()
            if "=" in line and not line.strip().startswith("#")
        ]
        layers["dotenv"] = {"available": True, "key_count": len(keys), "keys": keys}
    else:
        layers["dotenv"] = {"available": False, "reason": ".env file not found"}

    # Check OS env for known required secrets
    required = ["GOOGLE_API_KEY", "OPENAI_API_KEY", "ANTHROPIC_API_KEY", "NEO4J_PASSWORD"]
    env_found = [k for k in required if os.environ.get(k)]
    layers["os_env"] = {
        "available": bool(env_found),
        "required_found": env_found,
        "required_missing": [k for k in required if k not in env_found],
    }

    active_layer = next(
        (name for name, l in layers.items() if l.get("available")), "none"
    )

    return {
        "active_layer": active_layer,
        "layers": layers,
        "recommendation": (
            "Doppler is active — secrets are synced cross-platform."
            if layers["doppler"].get("available")
            else "Install Doppler for cross-platform secrets: brew install dopplerhq/cli/doppler && doppler setup"
        ),
    }
