"""
collab_memory/session_compressor.py — Sprint S5: Within-Session Memory Management

Prevents context window overflow by compressing long sessions into summaries.
The compressed summary is stored as a node in the graph and included in
future session bootstraps via /memory/context.

Design:
  - Each session accumulates ExchangeRecord nodes during ingest
  - When a session is "closed" (POST /memory/session/{id}/end), this module
    generates an LLM summary of the session's decisions, constraints, and
    preferences, stores it as a Decision node with origin='session_summary'
  - On session start (/agent/bootstrap), recent session summaries are
    included in the context brief alongside live graph nodes

This replaces the need for LangMem/MemGPT as external libraries:
the same context compression is built directly into the graph layer.
"""
from __future__ import annotations

import os
import json
from datetime import datetime, timezone
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .graph.neo4j_backend import Neo4jBackend


MAX_SESSION_TURNS = int(os.environ.get("COLLAB_MAX_SESSION_TURNS", "20"))
SUMMARY_MODEL = os.environ.get("ANTHROPIC_MODEL", "claude-haiku-4-5")


def _call_llm_summary(exchanges_text: str, session_id: str) -> str:
    """
    Call the configured LLM to summarize session exchanges into a
    compact decision/constraint/preference extract.
    """
    system_prompt = (
        "You are a session memory compressor for Co-Lab (collab-memory). "
        "Your job: extract the 3-5 most important information items from the session below. "
        "Focus on: decisions made, constraints identified, preferences expressed, open questions. "
        "Format: one clear sentence per item, starting with the item type. "
        "Example: 'Decision: Use Neo4j as the graph backend for production.' "
        "Be specific, not vague. Skip small talk and routine acknowledgments."
    )
    user_prompt = (
        f"Session ID: {session_id}\n\n"
        f"Session exchanges:\n{exchanges_text[:6000]}\n\n"
        "Compress the above into 3-5 key items:"
    )

    # Try Anthropic first
    try:
        anthropic_key = os.environ.get("ANTHROPIC_API_KEY", "")
        if anthropic_key:
            import anthropic
            client = anthropic.Anthropic(api_key=anthropic_key)
            msg = client.messages.create(
                model=SUMMARY_MODEL,
                max_tokens=512,
                system=system_prompt,
                messages=[{"role": "user", "content": user_prompt}],
            )
            return msg.content[0].text.strip()
    except Exception:
        pass

    # Try Google Gemini
    try:
        gemini_key = os.environ.get("GOOGLE_API_KEY") or os.environ.get("GEMINI_API_KEY")
        if gemini_key:
            import google.genai as genai
            client = genai.Client(api_key=gemini_key)
            result = client.models.generate_content(
                model="gemini-1.5-flash",
                contents=f"{system_prompt}\n\n{user_prompt}",
            )
            return result.text.strip()
    except Exception:
        pass

    # Fallback: extract first sentence of each exchange
    lines = [ln.strip() for ln in exchanges_text.splitlines() if ln.strip()]
    return " | ".join(lines[:5])


def compress_session(session_id: str, graph: "Neo4jBackend") -> dict:
    """
    Compress a session's exchanges into a single summary node stored in the graph.

    Returns:
        dict with 'summary', 'node_id', 'exchanges_compressed', 'session_id'
    """
    try:
        # Get exchanges for this session
        exchanges = graph.get_exchange_history(session_id=session_id, limit=200, offset=0)
        if not exchanges:
            return {"summary": "", "node_id": "", "exchanges_compressed": 0, "session_id": session_id}

        # Build text for LLM
        rows = exchanges.get("records", []) if isinstance(exchanges, dict) else []
        text_parts = []
        for i, ex in enumerate(rows[:50]):  # cap at 50 exchanges
            preview = ex.get("text_preview", "") or ""
            if preview:
                text_parts.append(f"[{i+1}] {preview[:300]}")

        exchanges_text = "\n".join(text_parts)
        exchange_count = len(rows)

        # Generate LLM summary
        summary = _call_llm_summary(exchanges_text, session_id)
        if not summary:
            return {"summary": "", "node_id": "", "exchanges_compressed": exchange_count, "session_id": session_id}

        # Store as a Decision node with origin=session_summary
        import uuid
        node_id = f"session_summary_{session_id}_{uuid.uuid4().hex[:8]}"
        ts = str(datetime.now(timezone.utc))
        graph._tx_write(
            """
            MERGE (n:Decision {id: $id})
            SET n.description = $desc,
                n.session_id = $sid,
                n.origin = 'session_summary',
                n.status = 'confirmed',
                n.confidence = 0.85,
                n.rationale = $rationale,
                n.is_superseded = false,
                n.created_at = $ts,
                n.summary_of_session = $sid,
                n.exchanges_compressed = $count
            """,
            id=node_id,
            desc=f"[Session Summary] {session_id}: {summary[:500]}",
            sid=session_id,
            rationale=f"Auto-compressed from {exchange_count} exchanges using LLM",
            ts=ts,
            count=exchange_count,
        )

        return {
            "summary": summary,
            "node_id": node_id,
            "exchanges_compressed": exchange_count,
            "session_id": session_id,
        }
    except Exception as e:
        return {"error": str(e), "session_id": session_id, "exchanges_compressed": 0}


def get_recent_session_summaries(graph: "Neo4jBackend", limit: int = 3) -> list[dict]:
    """
    Return the most recent session summary nodes from the graph.
    Used in build_context_brief() to give agents a compressed history window.
    """
    try:
        rows = graph._tx_read(
            """
            MATCH (n:Decision)
            WHERE n.origin = 'session_summary'
            RETURN n
            ORDER BY n.created_at DESC
            LIMIT $lim
            """,
            lim=limit,
        )
        summaries = []
        for r in rows:
            node = r["n"]
            summaries.append({
                "session_id": node.get("summary_of_session", node.get("session_id", "")),
                "summary": node.get("description", "").replace("[Session Summary] ", "", 1),
                "exchanges_compressed": node.get("exchanges_compressed", 0),
                "created_at": str(node.get("created_at", "")),
            })
        return summaries
    except Exception:
        return []
