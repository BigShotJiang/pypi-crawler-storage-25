"""
scripts/hnsw_migration.py — Create the Neo4j HNSW vector index for semantic search.

Run this ONCE against the live AuraDB instance to enable native vector search.
After running, semantic_search() will use db.index.vector.queryNodes() instead of
loading all nodes into Python and computing cosine similarity in a loop.

BEFORE RUNNING:
  1. Ensure GEMINI_API_KEY is set (generates embeddings for existing nodes)
  2. Ensure NEO4J_URI, NEO4J_USERNAME, NEO4J_PASSWORD are set
  3. Run: python -m collab_memory.scripts.hnsw_migration

Idempotent: checks if index exists before creating it.

Source: research_gap_deep_dive.md §Gap 2 (HNSW index)
        Neo4j Vector Index docs (neo4j.com/docs/cypher-manual/current/indexes/semantic-indexes/vector-indexes/)
"""
from __future__ import annotations

import logging
import os
import sys
import time

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
log = logging.getLogger("hnsw_migration")

# ── Neo4j connection ──────────────────────────────────────────────────────────

def _get_driver():
    from neo4j import GraphDatabase
    uri  = os.environ["NEO4J_URI"]
    user = os.environ.get("NEO4J_USERNAME", "neo4j")
    pw   = os.environ["NEO4J_PASSWORD"]
    return GraphDatabase.driver(uri, auth=(user, pw))


def _read(driver, cypher, **kwargs):
    with driver.session() as s:
        return list(s.run(cypher, **kwargs))


def _write(driver, cypher, **kwargs):
    with driver.session() as s:
        s.run(cypher, **kwargs)


# ── Index configuration ───────────────────────────────────────────────────────

# gemini-embedding-001 returns 768-dim vectors.
# HNSW parameters from research_gap_deep_dive.md §Gap 2:
#   M=16 (edges per node, 24 above 500K nodes)
#   efConstruction=200 (quality of build-time graph)
#   similarity=cosine (we use normalized vectors)
VECTOR_DIM   = 768
HNSW_M       = 16
HNSW_EF_CONSTRUCTION = 200
SIMILARITY   = "cosine"

# Labels to index
INDEXED_LABELS = ["Decision", "Constraint", "Preference", "Attempt", "Episode", "Skill"]


def index_name(label: str) -> str:
    return f"idx_vector_{label.lower()}"


# ── Step 1: Create vector indexes ─────────────────────────────────────────────

def create_indexes(driver) -> None:
    """Create HNSW vector indexes for all node types. Idempotent."""
    rows = _read(driver, "SHOW VECTOR INDEXES")
    existing = {r["name"] for r in rows}

    for label in INDEXED_LABELS:
        name = index_name(label)
        if name in existing:
            log.info("Index already exists: %s — skipping", name)
            continue

        log.info("Creating HNSW index: %s (label=%s, dim=%d)", name, label, VECTOR_DIM)
        _write(
            driver,
            f"""
            CREATE VECTOR INDEX {name} IF NOT EXISTS
            FOR (n:{label}) ON (n.embedding)
            OPTIONS {{
              indexConfig: {{
                `vector.dimensions`: $dim,
                `vector.similarity_function`: $sim,
                `hnsw.m`: $m,
                `efConstruction`: $ef
              }}
            }}
            """,
            dim=VECTOR_DIM,
            sim=SIMILARITY,
            m=HNSW_M,
            ef=HNSW_EF_CONSTRUCTION,
        )
        log.info("  ✓ Created %s", name)


# ── Step 2: Backfill embeddings on existing nodes ─────────────────────────────

BATCH_SIZE   = 50    # nodes per fetch from Neo4j
RATE_DELAY   = 0.12  # seconds between embedding API calls (~8 req/s, under Gemini limit)
MAX_ERRORS   = 20    # abort a label after this many consecutive errors

def backfill_embeddings(driver, labels: list[str] | None = None, dry_run: bool = False) -> None:
    """
    Backfill embeddings on all nodes that lack them.

    Paginated: iterates in BATCH_SIZE chunks until no un-embedded nodes remain.
    Resumable: uses SKIP/LIMIT — safe to re-run, already-embedded nodes are skipped.
    Rate-limited: RATE_DELAY between API calls.
    Fault-tolerant: skips individual failures, aborts a label after MAX_ERRORS.

    Args:
        labels:  subset of INDEXED_LABELS to process (default: all)
        dry_run: count missing embeddings without writing anything
    """
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

    try:
        from collab_memory.embeddings import generate_embedding
    except ImportError:
        log.error("Could not import collab_memory.embeddings — run from the project root")
        return

    targets = labels or INDEXED_LABELS
    grand_total = 0

    for label in targets:
        text_field = "summary" if label in ("Episode", "Skill") else "description"

        # How many need backfilling?
        count_rows = _read(
            driver,
            f"MATCH (n:{label}) WHERE n.embedding IS NULL AND n.{text_field} IS NOT NULL "
            f"RETURN count(n) AS cnt",
        )
        total_missing = count_rows[0]["cnt"] if count_rows else 0

        if total_missing == 0:
            log.info("%s: all nodes already have embeddings — skipping", label)
            continue

        log.info("%s: %d nodes need embeddings%s", label, total_missing,
                 " (dry run)" if dry_run else "")
        if dry_run:
            grand_total += total_missing
            continue

        done = 0
        consecutive_errors = 0
        offset = 0

        while True:
            batch = _read(
                driver,
                f"MATCH (n:{label}) WHERE n.embedding IS NULL AND n.{text_field} IS NOT NULL "
                f"RETURN n.id AS id, n.{text_field} AS text "
                f"SKIP $skip LIMIT $limit",
                skip=offset,
                limit=BATCH_SIZE,
            )
            if not batch:
                break  # all done for this label

            for row in batch:
                node_id = row["id"]
                text    = (row["text"] or "").strip()
                if not text:
                    offset += 1
                    continue
                try:
                    emb = generate_embedding(text)
                    if emb:
                        _write(
                            driver,
                            f"MATCH (n:{label} {{id: $id}}) SET n.embedding = $emb",
                            id=node_id,
                            emb=emb,
                        )
                        done += 1
                        consecutive_errors = 0
                        if done % 50 == 0:
                            pct = round(done / total_missing * 100)
                            log.info("  %s: %d/%d (%d%%) embedded", label, done, total_missing, pct)
                    time.sleep(RATE_DELAY)
                except Exception as e:
                    consecutive_errors += 1
                    log.warning("  %s %s: embedding failed (%d): %s", label, node_id, consecutive_errors, e)
                    if consecutive_errors >= MAX_ERRORS:
                        log.error("  %s: %d consecutive errors — stopping this label", label, MAX_ERRORS)
                        break
                    time.sleep(RATE_DELAY * 3)  # back off on errors

            else:
                # Inner loop completed without break — advance offset only if no errors stopped us
                # Since we write to nodes, re-querying from offset=0 would re-fetch remaining nulls.
                # Keep offset=0 so each batch fetches the next un-embedded nodes naturally.
                continue
            break  # consecutive_errors hit MAX_ERRORS

        log.info("  %s: done — %d/%d embedded", label, done, total_missing)
        grand_total += done

    if dry_run:
        log.info("Dry run complete: %d nodes need embeddings across all labels", grand_total)
    else:
        log.info("Backfill complete: %d nodes updated", grand_total)


# ── Step 3: Verify ────────────────────────────────────────────────────────────

def verify(driver) -> None:
    """Quick smoke test: query the vector index."""
    from collab_memory.embeddings import generate_embedding

    test_query = "what embedding model do we use"
    log.info("Running smoke test query: '%s'", test_query)

    emb = generate_embedding(test_query)
    if not emb:
        log.error("Could not generate test embedding — check GEMINI_API_KEY")
        return

    rows = _read(
        driver,
        """
        CALL db.index.vector.queryNodes('idx_vector_decision', 3, $emb)
        YIELD node, score
        RETURN node.description AS desc, score
        ORDER BY score DESC
        """,
        emb=emb,
    )

    if rows:
        log.info("✓ HNSW query returned %d results:", len(rows))
        for r in rows:
            log.info("  [%.4f] %s", r["score"], (r["desc"] or "")[:80])
    else:
        log.warning("HNSW query returned 0 results (index may still be populating)")


# ── Entry point ───────────────────────────────────────────────────────────────

def main():
    import argparse
    parser = argparse.ArgumentParser(description="HNSW index creation + embedding backfill for collab-memory")
    parser.add_argument("--dry-run",  action="store_true", help="Count missing embeddings without writing")
    parser.add_argument("--labels",   nargs="+", choices=INDEXED_LABELS, help="Only process these labels")
    parser.add_argument("--skip-index",   action="store_true", help="Skip index creation (backfill only)")
    parser.add_argument("--skip-backfill", action="store_true", help="Skip backfill (index creation only)")
    parser.add_argument("--skip-verify",  action="store_true", help="Skip smoke test")
    args = parser.parse_args()

    log.info("=== HNSW Migration — collab-memory ===")
    if args.dry_run:
        log.info("DRY RUN — no writes will be made")

    log.info("Connecting to Neo4j...")
    try:
        driver = _get_driver()
        _read(driver, "RETURN 1")
        log.info("✓ Connected")
    except Exception as e:
        log.error("Neo4j connection failed: %s", e)
        log.error("Set NEO4J_URI, NEO4J_USERNAME (or NEO4J_USER), NEO4J_PASSWORD")
        sys.exit(1)

    if not args.skip_index and not args.dry_run:
        log.info("\n--- Step 1: Create vector indexes ---")
        create_indexes(driver)

    if not args.skip_backfill:
        log.info("\n--- Step 2: Backfill embeddings ---")
        backfill_embeddings(driver, labels=args.labels, dry_run=args.dry_run)

    if not args.skip_verify and not args.dry_run:
        log.info("\n--- Step 3: Smoke test ---")
        verify(driver)

    log.info("\n✓ Done.")
    driver.close()


if __name__ == "__main__":
    main()
