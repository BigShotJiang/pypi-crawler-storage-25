"""
scripts/seed_workflow.py — Seed the default workflow skill into the graph.

Run once against the live Neo4j instance to make the default workflow skill
available as a Skill node. After this, _get_workflow_brief() returns it from
the graph instead of falling back to the bundled template file.

Usage:
    python -m collab_memory.scripts.seed_workflow

    # Preview without writing:
    python -m collab_memory.scripts.seed_workflow --dry-run

    # Force re-seed even if a default workflow already exists:
    python -m collab_memory.scripts.seed_workflow --force
"""
from __future__ import annotations

import argparse
import logging
import os
import pathlib
import sys

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
log = logging.getLogger("seed_workflow")


def main() -> None:
    parser = argparse.ArgumentParser(description="Seed default workflow skill into Neo4j")
    parser.add_argument("--dry-run", action="store_true", help="Print what would be written without writing")
    parser.add_argument("--force",   action="store_true", help="Re-seed even if a default workflow already exists")
    args = parser.parse_args()

    # Load the template
    tmpl_path = pathlib.Path(__file__).parent.parent / "templates" / "workflow_default.md"
    if not tmpl_path.exists():
        log.error("Template not found: %s", tmpl_path)
        sys.exit(1)

    content = tmpl_path.read_text()
    log.info("Loaded template: %s (%d chars)", tmpl_path.name, len(content))

    if args.dry_run:
        log.info("DRY RUN — would seed Skill node:")
        log.info("  name: Default Workflow")
        log.info("  source_type: workflow")
        log.info("  tags: [workflow, default, agile, opsec, testing]")
        log.info("  content: %d chars", len(content))
        return

    # Connect to graph
    try:
        from collab_memory.graph.neo4j_backend import Neo4jBackend
        graph = Neo4jBackend(
            uri=os.environ["NEO4J_URI"],
            user=os.environ.get("NEO4J_USER", os.environ.get("NEO4J_USERNAME", "neo4j")),
            password=os.environ["NEO4J_PASSWORD"],
            database=os.environ.get("NEO4J_DATABASE", "neo4j"),
        )
    except Exception as e:
        log.error("Could not connect to Neo4j: %s", e)
        log.error("Set NEO4J_URI, NEO4J_USER (or NEO4J_USERNAME), NEO4J_PASSWORD")
        sys.exit(1)

    # Check if default already exists
    if not args.force:
        try:
            rows = graph._tx_read(
                "MATCH (s:Skill) WHERE s.source_type = 'workflow' "
                "AND (s.project_id IS NULL OR s.project_id = 'default') "
                "RETURN s.id AS id, s.name AS name LIMIT 1"
            )
            if rows:
                log.info("Default workflow skill already exists: %s (%s)", rows[0]["name"], rows[0]["id"])
                log.info("Use --force to re-seed.")
                return
        except Exception as e:
            log.warning("Could not check for existing workflow skill: %s", e)

    # Build and save the Skill node
    from collab_memory.schema import Skill
    skill = Skill(
        name="Default Workflow",
        url="",
        summary=(
            "Default build rules for collab-memory projects. Covers build approach, "
            "security requirements, testing gates, launch checklist, agent protocol, "
            "and vendor integrations. Fork and customize per project."
        ),
        content=content,
        tags=["workflow", "default", "agile", "opsec", "testing"],
        source_type="workflow",
        added_by="system",
    )

    try:
        graph.save_skill(skill)
        log.info("✓ Seeded workflow skill: %s (%s)", skill.name, skill.id)
        log.info("  Agents will now receive this as workflow_brief in GET /memory/context")
    except Exception as e:
        log.error("Failed to save skill: %s", e)
        sys.exit(1)


if __name__ == "__main__":
    main()
