"""
collab_memory.scripts.watch — CLI entrypoint for `collab-memory-watch`.

Watches a conversation log file or directory and ingests new turns as they appear.

Usage:
    collab-memory-watch                        # watches ./session.log by default
    collab-memory-watch --path ./session.log   # explicit file
    collab-memory-watch --dir ./logs           # watch directory for *.log files
    collab-memory-watch --graph ./data/memory.json
    collab-memory-watch --interval 5           # poll every 5s (default 3)

Environment:
    LOCAL_GRAPH_PATH   — path to the graph JSON (overrides --graph)
    ANTHROPIC_API_KEY  — enables LLM classification
    OPENAI_API_KEY     — alternative LLM for classification
"""

from __future__ import annotations

import argparse
import os
import sys
import time
from pathlib import Path


def _tail_file(path: Path, last_pos: int) -> tuple[list[str], int]:
    """Read new lines from a file since last_pos. Returns (new_lines, new_pos)."""
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            f.seek(last_pos)
            new_content = f.read()
            new_pos = f.tell()
        lines = [l.strip() for l in new_content.splitlines() if l.strip()]
        return lines, new_pos
    except OSError:
        return [], last_pos


def watch_file(
        watch_path: Path,
        graph_path: str,
        interval: int = 3,
        verbose: bool = False,
) -> None:
    """Watch a single log file and ingest new lines into the memory graph."""
    from collab_memory import CollabMemory

    print(f"[collab-memory-watch] Watching: {watch_path}")
    print(f"[collab-memory-watch] Graph: {graph_path}")
    print(f"[collab-memory-watch] Interval: {interval}s — Ctrl+C to stop\n")

    memory = CollabMemory(graph_path=graph_path)
    last_pos = 0
    pending: list[str] = []
    flush_every = 10  # flush to disk every N new turns

    try:
        while True:
            new_lines, last_pos = _tail_file(watch_path, last_pos)
            if new_lines:
                count_before = len(pending)
                for line in new_lines:
                    memory.push_turn(line)
                    pending.append(line)
                    if verbose:
                        print(f"  → {line[:80]}")

                if len(pending) - count_before > 0 and len(pending) % flush_every == 0:
                    memory.flush()
                    memory.save()
                    if verbose:
                        print(f"  [flushed {len(pending)} turns to graph]")

            time.sleep(interval)

    except KeyboardInterrupt:
        print("\n[collab-memory-watch] Stopping — flushing final turns...")
        memory.flush()
        memory.save()
        print(f"[collab-memory-watch] Done. {len(pending)} total turns ingested.")


def watch_directory(
        watch_dir: Path,
        graph_path: str,
        interval: int = 3,
        verbose: bool = False,
) -> None:
    """Watch a directory and ingest new lines from any .log or .txt files."""
    from collab_memory import CollabMemory

    print(f"[collab-memory-watch] Directory: {watch_dir}")
    print(f"[collab-memory-watch] Graph: {graph_path}")
    print(f"[collab-memory-watch] Interval: {interval}s — Ctrl+C to stop\n")

    memory = CollabMemory(graph_path=graph_path)
    file_positions: dict[Path, int] = {}
    total_turns = 0

    try:
        while True:
            for log_file in sorted(watch_dir.glob("*.log")) + sorted(watch_dir.glob("*.txt")):
                if log_file not in file_positions:
                    file_positions[log_file] = 0
                    print(f"  [+] Tracking: {log_file.name}")

                new_lines, file_positions[log_file] = _tail_file(
                    log_file, file_positions[log_file]
                )
                for line in new_lines:
                    memory.push_turn(line)
                    total_turns += 1
                    if verbose:
                        print(f"  {log_file.name}: {line[:80]}")

            if total_turns > 0 and total_turns % 10 == 0:
                memory.flush()
                memory.save()

            time.sleep(interval)

    except KeyboardInterrupt:
        print("\n[collab-memory-watch] Stopping — flushing...")
        memory.flush()
        memory.save()
        print(f"[collab-memory-watch] Done. {total_turns} total turns ingested.")


def main():
    parser = argparse.ArgumentParser(
        description="collab-memory-watch — watch session logs and ingest turns in real-time",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  collab-memory-watch                                # watches ./session.log
  collab-memory-watch --path ./chats/session.log
  collab-memory-watch --dir ./logs --interval 5
  collab-memory-watch --graph ./data/memory.json --verbose
        """,
    )
    parser.add_argument(
        "--path",
        default=os.environ.get("WATCH_PATH", "./session.log"),
        help="Path to log file to watch (default: ./session.log)",
    )
    parser.add_argument(
        "--dir",
        default=None,
        help="Watch a directory of .log/.txt files instead of a single file",
    )
    parser.add_argument(
        "--graph",
        default=os.environ.get("LOCAL_GRAPH_PATH", "./data/memory.json"),
        help="Path to local graph JSON (default: ./data/memory.json)",
    )
    parser.add_argument(
        "--interval",
        type=int,
        default=3,
        help="Poll interval in seconds (default: 3)",
    )
    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Print each turn as it is ingested",
    )
    args = parser.parse_args()

    if args.dir:
        watch_dir = Path(args.dir)
        if not watch_dir.is_dir():
            print(f"Error: {args.dir} is not a directory", file=sys.stderr)
            sys.exit(1)
        watch_directory(watch_dir, args.graph, args.interval, args.verbose)
    else:
        watch_path = Path(args.path)
        if not watch_path.exists():
            print(f"Waiting for {watch_path} to appear...")
            while not watch_path.exists():
                time.sleep(1)
        watch_file(watch_path, args.graph, args.interval, args.verbose)


if __name__ == "__main__":
    main()
