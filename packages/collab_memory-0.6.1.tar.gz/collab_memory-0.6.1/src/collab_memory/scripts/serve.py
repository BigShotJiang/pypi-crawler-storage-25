"""collab_memory.scripts.serve — CLI entrypoint for collab-memory-serve command."""
import os
import sys

def main():
    import uvicorn
    port = int(os.environ.get("PORT", "8000"))
    host = os.environ.get("HOST", "0.0.0.0")
    uvicorn.run(
        "collab_memory.api.server:app",
        host=host,
        port=port,
        reload=False,
        workers=1,              # Render free tier: 512MB hard limit — never spawn multiple
        limit_concurrency=12,   # Sprint 23: bumped from 4 → 12 to prevent 503 cascade
        backlog=64,             # Queue requests beyond concurrent limit
        timeout_keep_alive=10,  # Free up connections quickly to reclaim memory

    )

if __name__ == "__main__":
    main()
