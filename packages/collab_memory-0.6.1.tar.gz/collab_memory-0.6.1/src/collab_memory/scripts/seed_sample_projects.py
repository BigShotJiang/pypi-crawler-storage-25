"""
Seed OHACO sample projects into a tenant's graph for demo and testing.

Usage:
    python -m collab_memory.scripts.seed_sample_projects --tenant-id <tid>

If --tenant-id is omitted, seeds into the default tenant.
"""

import argparse
import logging
import os
import sys
import json
from datetime import datetime, timezone

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
log = logging.getLogger("seed_sample_projects")

SAMPLE_PROJECTS = [
    {
        "name": "SpinDoctor.pro",
        "description": "AI-powered audio production tool. Automated mixing, mastering, and sound design with persistent memory of client preferences and style guides.",
        "stack": ["Python", "FastAPI", "FFmpeg", "Whisper", "Neo4j"],
    },
    {
        "name": "Professor CAI's Audio Tool",
        "description": "Educational AI audio assistant for music theory, production techniques, and creative workflows. Remembers student progress and adapts teaching style.",
        "stack": ["Python", "LangGraph", "Whisper", "TTS", "Neo4j"],
    },
    {
        "name": "Mindforge",
        "description": "Strategic AI workspace for complex problem solving. Multi-agent collaboration with persistent decision graphs, constraint tracking, and reasoning chains.",
        "stack": ["Python", "FastAPI", "LangGraph", "Neo4j", "React"],
    },
    {
        "name": "CRE Listing Agent",
        "description": "Commercial real estate listing intelligence. Automated property analysis, comp generation, market positioning, and deal pipeline management.",
        "stack": ["Python", "FastAPI", "PostgreSQL", "Mapbox", "Neo4j"],
    },
    {
        "name": "Site Selection / Analytics Engine",
        "description": "Data-driven site selection for commercial real estate. Demographics, traffic patterns, competition analysis, and predictive scoring with full decision provenance.",
        "stack": ["Python", "FastAPI", "PostGIS", "Mapbox", "Neo4j", "scikit-learn"],
    },
]

# Sample decisions/constraints per project to make the graph non-empty
SAMPLE_MEMORIES = {
    "SpinDoctor.pro": [
        ("Decision", "Use FFmpeg for all audio transcoding — battle-tested, handles every format", 0.92),
        ("Constraint", "Audio files must never leave the user's storage — stream processing only, no server-side copies", 0.95),
        ("Preference", "Default to 48kHz/24-bit for all production workflows unless client specifies otherwise", 0.85),
    ],
    "Professor CAI's Audio Tool": [
        ("Decision", "Adaptive difficulty — track student success rate per topic and adjust complexity automatically", 0.88),
        ("Constraint", "Student data is never shared across accounts — full isolation per learner", 0.97),
        ("Preference", "Use conversational tone, not academic. Students learn better when it feels like a mentor, not a textbook", 0.90),
    ],
    "Mindforge": [
        ("Decision", "Multi-agent architecture — each reasoning step is a separate agent with its own context window", 0.91),
        ("Constraint", "All reasoning chains must be traceable — no black-box conclusions, every output links to its inputs", 0.96),
        ("Preference", "Favor depth over breadth in analysis — better to fully explore one path than superficially scan five", 0.82),
    ],
    "CRE Listing Agent": [
        ("Decision", "Use Mapbox for all map rendering — better pricing than Google Maps at scale", 0.87),
        ("Constraint", "Deal pipeline data is encrypted at rest — client financials are the most sensitive asset", 0.98),
        ("Preference", "Default comp radius of 1 mile for urban, 5 miles for suburban, 15 miles for rural", 0.84),
    ],
    "Site Selection / Analytics Engine": [
        ("Decision", "PostGIS for all spatial queries — native geometry support beats application-level calculations", 0.93),
        ("Constraint", "Demographic data must cite source and vintage year — no undated statistics in reports", 0.94),
        ("Preference", "Weight traffic count data 2x over census data for retail site scoring — foot traffic predicts revenue better", 0.86),
    ],
}


def seed(tenant_id: str, owner_id: str = "system"):
    """Seed sample projects and memories into the graph."""
    from collab_memory.graph.neo4j_backend import Neo4jBackend
    from collab_memory.schema import Project, Decision, Constraint, Preference

    graph = Neo4jBackend()
    now = datetime.now(timezone.utc)
    created = []

    for proj_data in SAMPLE_PROJECTS:
        proj = Project(
            name=proj_data["name"],
            description=proj_data["description"],
            tenant_id=tenant_id,
            owner_id=owner_id,
            members=[json.dumps({"user_id": owner_id, "role": "admin", "added_at": str(now)})],
        )
        try:
            graph.save_project(proj)
            log.info("Created project: %s (id=%s)", proj.name, proj.id)
            created.append(proj)
        except Exception as e:
            log.error("Failed to create project %s: %s", proj.name, e)
            continue

        # Seed sample memories for this project
        memories = SAMPLE_MEMORIES.get(proj_data["name"], [])
        for node_type, description, confidence in memories:
            try:
                if node_type == "Decision":
                    node = Decision(
                        description=description,
                        confidence=confidence,
                        session_id=f"seed-{proj.id}",
                        project_id=proj.id,
                        tenant_id=tenant_id,
                        created_by="seed",
                        origin="user_stated",
                        status="active",
                    )
                elif node_type == "Constraint":
                    node = Constraint(
                        description=description,
                        confidence=confidence,
                        session_id=f"seed-{proj.id}",
                        project_id=proj.id,
                        tenant_id=tenant_id,
                        created_by="seed",
                        origin="user_stated",
                        still_active=True,
                    )
                elif node_type == "Preference":
                    node = Preference(
                        description=description,
                        confidence=confidence,
                        session_id=f"seed-{proj.id}",
                        project_id=proj.id,
                        tenant_id=tenant_id,
                        created_by="seed",
                        type="technical",
                    )
                else:
                    continue

                graph.save_node(node)
                log.info("  + %s: %s", node_type, description[:60])
            except Exception as e:
                log.warning("  ! Failed to save %s: %s", node_type, e)

    log.info("Seeded %d projects with sample data for tenant=%s", len(created), tenant_id)
    return created


def main():
    parser = argparse.ArgumentParser(description="Seed OHACO sample projects")
    parser.add_argument("--tenant-id", default="default", help="Tenant ID to seed into")
    parser.add_argument("--owner-id", default="system", help="Owner user ID")
    parser.add_argument("--dry-run", action="store_true", help="Print what would be created without writing")
    args = parser.parse_args()

    if args.dry_run:
        for p in SAMPLE_PROJECTS:
            print(f"  Project: {p['name']}")
            print(f"    {p['description']}")
            print(f"    Stack: {', '.join(p['stack'])}")
            for node_type, desc, conf in SAMPLE_MEMORIES.get(p["name"], []):
                print(f"    + {node_type} ({conf}): {desc[:70]}")
            print()
        print(f"Would create {len(SAMPLE_PROJECTS)} projects for tenant={args.tenant_id}")
        return

    seed(args.tenant_id, args.owner_id)


if __name__ == "__main__":
    main()
