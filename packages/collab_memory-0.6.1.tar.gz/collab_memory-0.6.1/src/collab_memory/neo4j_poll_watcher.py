"""
collab_memory/neo4j_poll_watcher.py — Neo4j-native poll watcher.

Replaces the file-based SessionWatcher (watcher.py) which cannot work on
Render because web service and worker run in separate containers with
separate filesystems.

This watcher polls Neo4j directly for ExchangeRecord nodes with
`processed: false`, runs each through the 6-agent pipeline, and marks
them as processed. It also triggers Episode consolidation after an idle
period (no new records for N minutes).

Design decisions:
  - Polls Neo4j, not a file. Works on Render, Docker, local, anywhere.
  - Runs as a background thread inside the FastAPI process (no separate worker).
  - Respects project_id on all nodes (multi-tenancy ready).
  - Idle consolidation uses the existing consolidator.py Episode contract.
  - Graceful degradation: if pipeline fails on one record, it logs and continues.

Usage:
    # Start from server.py at boot time
    from .neo4j_poll_watcher import Neo4jPollWatcher
    watcher = Neo4jPollWatcher(graph=graph, poll_interval=30)
    watcher.start()

    # Or from CLI
    python -m collab_memory.neo4j_poll_watcher --uri bolt://... --password ...
"""
from __future__ import annotations

import logging
import os
import threading
import time
from datetime import datetime, timezone
from typing import Any, Optional

logger = logging.getLogger(__name__)


class Neo4jPollWatcher:
    """
    Background daemon that polls Neo4j for unprocessed ExchangeRecord nodes
    and runs them through the pipeline.

    This replaces the file-based SessionWatcher for deployed environments
    where the filesystem is not shared between processes.
    """

    def __init__(
        self,
        graph: Any = None,
        poll_interval: float = 30.0,
        batch_size: int = 10,
        idle_consolidate_after: float = 600.0,  # 10 minutes
        enabled: bool = True,
    ):
        """
        Args:
            graph:                  Neo4j graph backend instance.
            poll_interval:          Seconds between polls (default 30s).
            batch_size:             Max records to process per poll cycle.
            idle_consolidate_after: Seconds of inactivity before triggering
                                    Episode consolidation (default 10 min).
            enabled:                Set False to create but not run (for testing).
        """
        self.graph = graph
        self.poll_interval = poll_interval
        self.batch_size = batch_size
        self.idle_consolidate_after = idle_consolidate_after
        self.enabled = enabled

        self._stop_event = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._last_activity: float = 0.0
        self._consolidation_triggered: bool = False
        self._stats = {
            "polls": 0,
            "records_processed": 0,
            "records_failed": 0,
            "consolidations": 0,
            "last_poll_at": None,
            "last_process_at": None,
            "started_at": None,
        }

    # ─── Neo4j Queries ───────────────────────────────────────────────────────

    def _get_unprocessed_records(self) -> list[dict]:
        """
        Query Neo4j for ExchangeRecord nodes that have not been processed
        by the pipeline yet.

        We look for nodes where:
          - processed IS NULL or processed = false
          - raw_text is not empty
        Ordered by created_at ASC (oldest first — FIFO).
        """
        if not hasattr(self.graph, '_tx_read'):
            logger.warning("neo4j_poll_watcher: graph backend has no _tx_read")
            return []

        try:
            rows = self.graph._tx_read(
                """
                MATCH (e:ExchangeRecord)
                WHERE (e.processed IS NULL OR e.processed = false)
                  AND e.raw_text IS NOT NULL
                  AND size(e.raw_text) > 10
                RETURN e
                ORDER BY e.created_at ASC
                LIMIT $limit
                """,
                limit=self.batch_size,
            )
            records = []
            for r in rows:
                node = dict(r["e"])
                records.append({
                    "id": node.get("id", ""),
                    "raw_text": node.get("raw_text", ""),
                    "session_id": node.get("session_id", "unknown"),
                    "project_id": node.get("project_id"),
                    "created_at": str(node.get("created_at", "")),
                    "worthiness_score": node.get("worthiness_score", 0.0),
                })
            return records
        except Exception as e:
            logger.error("neo4j_poll_watcher: query failed: %s", e)
            return []

    def _mark_processed(self, record_id: str, success: bool = True) -> None:
        """Mark an ExchangeRecord as processed in Neo4j."""
        if not hasattr(self.graph, '_tx_write'):
            return
        try:
            self.graph._tx_write(
                """
                MATCH (e:ExchangeRecord {id: $id})
                SET e.processed = true,
                    e.processed_at = $now,
                    e.pipeline_success = $success
                """,
                id=record_id,
                now=datetime.now(timezone.utc).isoformat(),
                success=success,
            )
        except Exception as e:
            logger.error("neo4j_poll_watcher: mark_processed failed for %s: %s", record_id, e)

    def _get_active_sessions(self) -> list[str]:
        """Get session IDs that have unprocessed records (for consolidation targeting)."""
        if not hasattr(self.graph, '_tx_read'):
            return []
        try:
            rows = self.graph._tx_read(
                """
                MATCH (e:ExchangeRecord)
                WHERE e.processed = true
                  AND e.processed_at IS NOT NULL
                RETURN DISTINCT e.session_id AS session_id
                ORDER BY session_id
                """
            )
            return [r["session_id"] for r in rows if r.get("session_id")]
        except Exception:
            return []

    # ─── Pipeline Execution ──────────────────────────────────────────────────

    def _run_pipeline_on_record(self, record: dict) -> bool:
        """
        Run the 6-agent pipeline on a single ExchangeRecord.
        Returns True on success, False on failure.
        """
        try:
            from .agents.pipeline import run_pipeline

            raw_text = record.get("raw_text", "")

            # ── Type guard: legacy nodes may store raw_text as a dict or non-str ──
            # This was the root cause of the extraction_node crash loop (OOM).
            if isinstance(raw_text, dict):
                raw_text = (
                    raw_text.get("text") or raw_text.get("raw_text")
                    or raw_text.get("content") or ""
                )
                logger.warning(
                    "neo4j_poll_watcher: corrupt legacy node %s had dict raw_text — coerced to str",
                    record.get("id", "?")[:12],
                )
            raw_text = str(raw_text) if raw_text else ""

            if not raw_text.strip():
                logger.debug("neo4j_poll_watcher: skipping empty record %s", record.get("id"))
                return True  # Not a failure, just nothing to process

            # Sanity cap: ignore absurdly large nodes that would OOM the pipeline
            if len(raw_text) > 50_000:
                logger.warning(
                    "neo4j_poll_watcher: record %s too large (%d chars), skipping",
                    record.get("id", "?")[:12], len(raw_text),
                )
                return True

            session_id = record.get("session_id", "unknown")
            project_id = record.get("project_id")

            result = run_pipeline(
                raw_text=raw_text,
                session_id=session_id,
                graph=self.graph,
                project_id=project_id,
            )

            # Check if pipeline produced meaningful output
            primitive_type = result.get("primitive_type", "unknown")
            should_encode = result.get("should_encode", False)

            logger.info(
                "neo4j_poll_watcher: processed %s → %s (encode=%s, session=%s)",
                record.get("id", "?")[:12],
                primitive_type,
                should_encode,
                session_id,
            )
            return True

        except Exception as e:
            logger.error(
                "neo4j_poll_watcher: pipeline failed for %s: %s",
                record.get("id", "?"),
                e,
            )
            return False

    # ─── Consolidation ───────────────────────────────────────────────────────

    def _trigger_consolidation(self) -> None:
        """
        Trigger Episode consolidation for sessions that have processed records.
        Uses the existing consolidator.py contract.
        """
        try:
            from .agents.consolidator import consolidate_session
            from .agents.pipeline import _LLMClientAdapter
            import asyncio

            sessions = self._get_active_sessions()
            if not sessions:
                logger.debug("neo4j_poll_watcher: no sessions to consolidate")
                return

            llm_client = _LLMClientAdapter()

            for session_id in sessions[:5]:  # Cap at 5 sessions per consolidation
                try:
                    loop = asyncio.new_event_loop()
                    result = loop.run_until_complete(
                        consolidate_session(
                            session_id=session_id,
                            graph=self.graph,
                            llm_client=llm_client,
                        )
                    )
                    loop.close()

                    status = result.get("status", "unknown")
                    episode_id = result.get("episode_id", "?")
                    logger.info(
                        "neo4j_poll_watcher: consolidation %s → %s (episode=%s)",
                        session_id, status, episode_id,
                    )
                    self._stats["consolidations"] += 1

                except Exception as e:
                    logger.warning(
                        "neo4j_poll_watcher: consolidation failed for %s: %s",
                        session_id, e,
                    )

            self._consolidation_triggered = True

        except ImportError as e:
            logger.warning("neo4j_poll_watcher: consolidator not available: %s", e)

    # ─── Main Loop ───────────────────────────────────────────────────────────

    def _poll_cycle(self) -> int:
        """
        Run one poll cycle: fetch unprocessed records, run pipeline, mark done.
        Returns the number of records processed.
        """
        self._stats["polls"] += 1
        self._stats["last_poll_at"] = datetime.now(timezone.utc).isoformat()

        records = self._get_unprocessed_records()
        if not records:
            return 0

        processed = 0
        consecutive_failures = 0
        MAX_CONSECUTIVE_FAILURES = 3  # circuit breaker — stop batch if 3 in a row fail

        for record in records:
            if consecutive_failures >= MAX_CONSECUTIVE_FAILURES:
                logger.warning(
                    "neo4j_poll_watcher: circuit breaker triggered after %d consecutive failures — "
                    "pausing batch to prevent OOM. Will retry next poll cycle.",
                    consecutive_failures,
                )
                break

            record_id = record.get("id", "")
            success = self._run_pipeline_on_record(record)
            self._mark_processed(record_id, success=success)

            if success:
                self._stats["records_processed"] += 1
                processed += 1
                consecutive_failures = 0  # reset on success
            else:
                self._stats["records_failed"] += 1
                consecutive_failures += 1

        if processed > 0:
            self._last_activity = time.time()
            self._consolidation_triggered = False
            self._stats["last_process_at"] = datetime.now(timezone.utc).isoformat()

        return processed

    def _watch_loop(self) -> None:
        """Main loop: poll → process → consolidate (if idle)."""
        logger.info(
            "neo4j_poll_watcher: started (interval=%ss, batch=%d, idle_consolidate=%sm)",
            self.poll_interval,
            self.batch_size,
            self.idle_consolidate_after / 60,
        )
        self._last_activity = time.time()
        self._stats["started_at"] = datetime.now(timezone.utc).isoformat()

        while not self._stop_event.is_set():
            try:
                processed = self._poll_cycle()

                # Auto-consolidation after idle period
                if (
                    not self._consolidation_triggered
                    and self._last_activity > 0
                    and (time.time() - self._last_activity) >= self.idle_consolidate_after
                ):
                    logger.info(
                        "neo4j_poll_watcher: idle %.0fm — triggering consolidation",
                        self.idle_consolidate_after / 60,
                    )
                    self._trigger_consolidation()

            except Exception as e:
                logger.error("neo4j_poll_watcher: poll cycle error: %s", e)

            self._stop_event.wait(self.poll_interval)

        logger.info("neo4j_poll_watcher: stopped")

    # ─── Public API ──────────────────────────────────────────────────────────

    def start(self, daemon: bool = True) -> "Neo4jPollWatcher":
        """Start the watcher in a background thread."""
        if not self.enabled:
            logger.info("neo4j_poll_watcher: disabled, not starting")
            return self
        if self._thread and self._thread.is_alive():
            return self
        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._watch_loop,
            daemon=daemon,
            name="neo4j-poll-watcher",
        )
        self._thread.start()
        return self

    def stop(self) -> None:
        """Stop the watcher thread."""
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=10)

    def get_stats(self) -> dict:
        """Return watcher statistics for the /memory/watcher/status endpoint."""
        return {
            **self._stats,
            "running": self._thread is not None and self._thread.is_alive(),
            "poll_interval": self.poll_interval,
            "batch_size": self.batch_size,
            "idle_consolidate_after_minutes": self.idle_consolidate_after / 60,
        }

    def trigger_poll_now(self) -> dict:
        """Manually trigger a poll cycle (for testing or admin use)."""
        processed = self._poll_cycle()
        return {
            "processed": processed,
            "stats": self.get_stats(),
        }


# ─── CLI Entry Point ─────────────────────────────────────────────────────────

def run_poll_watcher_cli() -> None:
    """Entry point for standalone CLI usage."""
    import argparse

    parser = argparse.ArgumentParser(
        description="collab-memory Neo4j Poll Watcher — processes unprocessed ExchangeRecords"
    )
    parser.add_argument("--uri", default=os.environ.get("NEO4J_URI", "bolt://localhost:7687"))
    parser.add_argument("--user", default=os.environ.get("NEO4J_USER", "neo4j"))
    parser.add_argument("--password", default=os.environ.get("NEO4J_PASSWORD", ""))
    parser.add_argument("--database", default=os.environ.get("NEO4J_DATABASE", "neo4j"))
    parser.add_argument("--interval", type=float, default=30.0, help="Poll interval in seconds")
    parser.add_argument("--batch-size", type=int, default=10, help="Max records per poll")
    parser.add_argument("--idle-consolidate", type=float, default=600.0, help="Idle seconds before consolidation")
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")

    from .graph.neo4j_backend import Neo4jBackend
    graph = Neo4jBackend(
        uri=args.uri,
        user=args.user,
        password=args.password,
        database=args.database,
    )

    watcher = Neo4jPollWatcher(
        graph=graph,
        poll_interval=args.interval,
        batch_size=args.batch_size,
        idle_consolidate_after=args.idle_consolidate,
    )
    watcher.start(daemon=False)  # blocking in CLI mode


if __name__ == "__main__":
    run_poll_watcher_cli()
