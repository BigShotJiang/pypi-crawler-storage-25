# collab-memory

Semantic memory sidecar for multi-agent and human+AI collaboration.

`collab-memory` helps agents keep durable project context across sessions by storing decisions, constraints, preferences, artifacts, and session summaries in a scoped graph.

## Install

```bash
pip install collab-memory
```

## What it provides

- Session bootstrap context via `GET /memory/context` and `GET /memory/context/prompt`
- Trusted writes and pipeline ingestion via `POST /memory/record` and `POST /memory/ingest`
- Graph export for visual clients via `GET /graph/export`
- Training-data export for adapter tuning via `GET /projects/{project_id}/export-training-data`
- MCP server entrypoint (`collab-memory-mcp`) for IDE agent workflows

## Quick start

```bash
collab-memory-start
```

Then open:

- API docs: `http://localhost:8000/docs`
- Dashboard: `http://localhost:8000/`

## License

This distribution is under the **OHACO Labs Proprietary License - Lockdown** (see `LICENSE`).

Historical copies that were previously released under MIT remain governed by the terms attached to those specific historical artifacts (see `NOTICE`).

## Links

- Repository: https://github.com/OHACO-LABS/collab-memory
- Issues: https://github.com/OHACO-LABS/collab-memory/issues
- Product: https://github.com/OHACO-LABS/collab-memory/blob/main/docs/PRODUCT.md
