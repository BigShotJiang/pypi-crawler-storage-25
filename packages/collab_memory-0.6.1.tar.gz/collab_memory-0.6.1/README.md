# collab-memory — Developer README

**Semantic working memory for AI agents and human+AI collaboration.**
`pip install collab-memory` · [GitHub](https://github.com/OHACO-LABS/collab-memory) · **Proprietary (lockdown)**

**License lockdown:** New distributions of this repository and package are under the **OHACO Labs Proprietary License — Lockdown** in **`LICENSE`**. There is **no** permissive open-source grant unless OHACO Labs has **authorized you in writing** (beta / contract / employment / other explicit permission). **Historical** PyPI or Git artifacts that shipped under **MIT** stay MIT **only for those copies** — see **`NOTICE`**. Hosted OHACO services are governed by your program terms and **`/terms`**. Product split and roadmap: **`docs/PRODUCT.md`**.

**IP & security:** Copyright and contractual terms are in **`LICENSE`**. Trademarks, prior MIT releases, and patent posture (plain language) are in **`NOTICE`**. Report vulnerabilities per **`SECURITY.md`** — not via public issues.

[![Deploy on Railway](https://railway.app/button.svg)](https://railway.app/new/template?template=https://github.com/OHACO-LABS/collab-memory)

> *An agent on Gemini, Manus, Cursor, or ChatGPT stores a decision.
> Any other agent on any other platform reads it — instantly, without copy-paste.*

---

## What it does

collab-memory gives AI agents a shared, persistent graph of:
- **Decisions** — architectural, product, and creative choices that shouldn't be re-litigated
- **Constraints** — hard rules and trade-offs the team has agreed to
- **Preferences** — style, tooling, and workflow preferences inferred from behaviour
- **Artifacts** — files, HTML, code, and documents stored across sessions
- **Projects** — isolated namespaces so multiple projects don't bleed into each other

Every session starts with a context brief. Every decision made during the session is classified, contradiction-checked, and written to the graph. Next session — any agent, any platform — is fully briefed before the human types a word.

---

## Quickstart (5 steps)

### Option A — Local (fastest, no cloud account)

```bash
# 1. Install
pip install collab-memory

# 2. Start the server (uses local JSON graph by default)
collab-memory-start

# 3. Open the dashboard
open http://localhost:8000

# 4. Get your context brief (paste this into any AI system prompt)
curl http://localhost:8000/memory/context/prompt | python3 -c "import sys,json; print(json.load(sys.stdin)['prompt'])"

# 5. Ingest a decision
curl -X POST http://localhost:8000/memory/ingest \
  -H "Content-Type: application/json" \
  -d '{"raw_text": "We will use FastAPI. No Flask.", "session_id": "my_project", "turn_start": 1}'
```

### Option B — Railway (one click, no cold starts, $5/mo free credit)

[![Deploy on Railway](https://railway.app/button.svg)](https://railway.app/new/template?template=https://github.com/OHACO-LABS/collab-memory)

Or manually:
1. Fork https://github.com/OHACO-LABS/collab-memory
2. Go to [railway.app](https://railway.app) → New Project → Deploy from GitHub repo
3. Set environment variables:

```bash
GRAPH_BACKEND=neo4j
NEO4J_URI=neo4j+s://your-instance.databases.neo4j.io
NEO4J_PASSWORD=your-password
LLM_PROVIDER=anthropic          # optional — LLM classification
ANTHROPIC_API_KEY=sk-ant-...    # optional — skip_llm=true works without it
COLLAB_API_KEY=your-secret      # recommended — locks your instance
```

4. Railway auto-detects Python, runs `python -m collab_memory.scripts.serve`, health-checks `/health`.

No sleep on inactivity. No cold starts. Your instance stays live.

### Option C — Render (free tier, sleeps after 15min inactivity)

```bash
# Prerequisites: free accounts on Neo4j AuraDB + Render

# 1. Fork https://github.com/OHACO-LABS/collab-memory
# 2. Create free Neo4j AuraDB instance at console.neo4j.io
# 3. Deploy fork to Render (render.com → New Web Service → connect repo)
# 4. Set same environment variables as Option B in Render dashboard
# 5. Your instance is live:
curl https://your-app.onrender.com/health
```

---

## Using with any AI agent

### Inject context at session start
```bash
# Get the bootstrap prompt
PROMPT=$(curl -s http://localhost:8000/memory/context/prompt | python3 -c "import sys,json; print(json.load(sys.stdin)['prompt'])")

# Paste into your AI tool's system prompt, or use in API call:
curl https://api.anthropic.com/v1/messages \
  -H "x-api-key: $ANTHROPIC_API_KEY" \
  -H "Content-Type: application/json" \
  -d "{\"model\":\"claude-haiku-4-5\",\"max_tokens\":1024,\"system\":\"$PROMPT\",\"messages\":[...]}"
```

### Store a decision during the session
```bash
curl -X POST http://localhost:8000/memory/ingest \
  -H "Content-Type: application/json" \
  -H "X-API-Key: your-secret" \          # only if COLLAB_API_KEY is set
  -d '{
    "raw_text": "We decided to use Postgres, not MongoDB. Firm constraint.",
    "session_id": "project_alpha",
    "turn_start": 5
  }'
```

### Cross-agent handoff
```bash
# AG stores a decision and artifact → Manus reads it → ChatGPT bootstraps from prompt
# Full demo:
python3 scripts/cross_agent_handoff.py
```

---

## Run the pipeline manually (from dashboard or API)

In the dashboard: **Ops tab → ▶ Run Pipeline → paste text → Run Agents**

Or via API:
```bash
curl -X POST http://localhost:8000/memory/pipeline/run \
  -H "Content-Type: application/json" \
  -d '{"text": "We must never use Redis in this project.", "session_id": "test"}'
```

Returns per-agent trace: Intake score → Classifier type → Security check → Graph Writer result.

---

## API Reference (key endpoints)

| Method | Endpoint | Description |
|---|---|---|
| GET | `/health` | Service health + version |
| GET | `/memory/context` | Context brief (decisions, constraints, preferences) |
| GET | `/memory/context/prompt` | Ready-to-paste system prompt string |
| POST | `/memory/ingest` | Run text through the 6-agent pipeline |
| POST | `/memory/pipeline/run` | Manually fire pipeline, get per-agent trace |
| GET | `/memory/pending` | Inferred items awaiting HITL review |
| POST | `/memory/confirm/{id}` | Approve a pending inference |
| POST | `/memory/reject/{id}` | Reject a pending inference |
| POST | `/artifacts` | Store a file (any type, up to 100KB inline) |
| GET | `/artifacts/{id}/preview` | Render HTML artifact in browser |
| POST | `/projects` | Create a project namespace |
| GET | `/ops/ping` | Keepalive (UptimeRobot-compatible) |

Full interactive docs: `http://localhost:8000/docs`

---

## Architecture

```
Any Agent (Gemini / Claude / GPT / Manus / Cursor plugin)
    │
    ▼
collab-memory API  (FastAPI · port 8000 · local or Render)
    │
    ▼
6-Agent LangGraph Pipeline
  Intake → Classifier → Security/Drift → Graph Writer → Retrieval
    │
    ▼
Graph Backend  (Neo4j AuraDB · or local JSON for dev)
    │
    ▼
GET /memory/context/prompt → any agent reads the shared brain
```

---

## Auth

Set `COLLAB_API_KEY` environment variable to lock your instance.  
Add `X-API-Key: <your-key>` header to all API requests.  
Public endpoints (no key required): `/health`, `/ops/ping`, `/docs`

Without `COLLAB_API_KEY` set: open access (good for local dev).

---

## Tech stack

- **FastAPI** — API server + dashboard
- **LangGraph** — 6-agent pipeline orchestration  
- **Neo4j AuraDB** — graph storage (free tier available)
- **Anthropic Claude** — LLM classification (optional, `skip_llm=true` works without it)
- **Pydantic** — schema + validation

---

## Contributing

```bash
git clone https://github.com/OHACO-LABS/collab-memory
cd collab-memory
pip install -e ".[dev]"
pytest tests/          # 242 tests, 0 failures
```

**Release version:** bump `src/collab_memory/_version.py` only — `pyproject.toml` reads it for builds (`python -m build`). Tag Git when you publish (e.g. `v0.6.0`).

Proprietary (see LICENSE) · Built by [Esther Anglade](https://github.com/OHACO-LABS) / OHACO Labs · AI-assisted development
