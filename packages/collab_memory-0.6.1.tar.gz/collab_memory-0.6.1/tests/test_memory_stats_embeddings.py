from __future__ import annotations

from starlette.testclient import TestClient


class _StatsGraphStub:
    def __init__(self, *, fail_driver: bool = False):
        self.fail_driver = fail_driver
        self.driver_queries: list[tuple[str, dict]] = []

    def build_context_brief(self, tenant_id: str):
        return {"recent_attempts": [{"id": "att_1"}, {"id": "att_2"}]}

    def get_decisions(self, tenant_id: str):
        return [{"id": "dec_1"}, {"id": "dec_2"}, {"id": "dec_3"}]

    def get_constraints(self, active_only: bool, tenant_id: str):
        return [{"id": "con_1"}]

    def get_preferences(self, tenant_id: str):
        return [{"id": "pref_1"}, {"id": "pref_2"}]

    def get_skills(self, limit: int = 500):
        return [{"id": "sk_1"}]

    @property
    def _driver(self):
        return _DriverStub(parent=self)


class _DriverStub:
    def __init__(self, *, parent: _StatsGraphStub):
        self.parent = parent

    def session(self):
        return _SessionStub(parent=self.parent)


class _SessionStub:
    def __init__(self, *, parent: _StatsGraphStub):
        self.parent = parent

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return None

    def run(self, query: str, **params):
        if self.parent.fail_driver:
            raise RuntimeError("driver unavailable")
        self.parent.driver_queries.append((query, params))
        if "count(n) as total" in query:
            return _ResultStub(100)
        if "count(n) as embedded" in query:
            return _ResultStub(45)
        return _ResultStub(0)


class _ResultStub:
    def __init__(self, value: int):
        self._value = value

    def single(self):
        return {"total": self._value, "embedded": self._value}


def _make_client(monkeypatch, *, fail_driver: bool = False):
    from collab_memory.abac import AgentContext
    from collab_memory.api import server as srv

    stub = _StatsGraphStub(fail_driver=fail_driver)
    monkeypatch.setattr(srv, "graph", stub)
    monkeypatch.setattr(srv, "_API_KEY", "test_key")
    monkeypatch.setattr(srv, "_VALID_API_KEYS", {"test_key"})

    def _resolve_agent_context(_key, graph=None):
        return AgentContext(
            role="contributor",
            agent_id="agent_stats",
            key="test_key",
            tenant_id="tenant_stats",
            plan="pro",
        )

    monkeypatch.setattr(srv, "resolve_agent_context", _resolve_agent_context)
    return TestClient(srv.app), stub


def test_memory_stats_includes_embedding_metrics(monkeypatch):
    client, stub = _make_client(monkeypatch, fail_driver=False)
    resp = client.get("/memory/stats", headers={"X-API-Key": "test_key"})
    assert resp.status_code == 200
    body = resp.json()

    assert body["decisions"] == 3
    assert body["constraints"] == 1
    assert body["preferences"] == 2
    assert body["attempts"] == 2
    assert body["skills"] == 1

    assert body["total_nodes"] == 100
    assert body["embedding_count"] == 45
    assert body["embedding_coverage"] == 45.0

    assert len(stub.driver_queries) == 2
    first_query, first_params = stub.driver_queries[0]
    assert "n.tenant_id = $tid" in first_query
    assert first_params["tid"] == "tenant_stats"


def test_memory_stats_embedding_metrics_fallback_on_driver_error(monkeypatch):
    client, _stub = _make_client(monkeypatch, fail_driver=True)
    resp = client.get("/memory/stats", headers={"X-API-Key": "test_key"})
    assert resp.status_code == 200
    body = resp.json()

    assert body["embedding_count"] == 0
    assert body["embedding_coverage"] == 0.0
    assert body["total_nodes"] == 0
