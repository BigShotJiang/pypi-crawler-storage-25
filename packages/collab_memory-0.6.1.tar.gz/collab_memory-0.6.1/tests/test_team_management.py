"""
tests/test_team_management.py — Team management, invites, role changes.

Tests the team gating and provisioning endpoints:
- Invite generation and preview
- Invite acceptance (existing user + new signup)
- Member listing and role changes
- Invite revocation and expiry
"""
import pytest
from unittest.mock import MagicMock, patch
import json


@pytest.fixture
def client():
    from starlette.testclient import TestClient
    from collab_memory.api.server import app

    return TestClient(app)


class TestInviteGeneration:
    """Test project invite link creation."""

    def test_invite_creates_node_with_token(self):
        """Verify invite creates a ProjectInvite node in the graph."""
        import inspect
        from collab_memory.api import server
        source = inspect.getsource(server.create_project_invite)
        assert "ProjectInvite" in source
        assert "token_urlsafe" in source
        assert "expires_at" in source

    def test_invite_role_validation(self):
        """Verify only valid roles are accepted."""
        import inspect
        from collab_memory.api import server
        source = inspect.getsource(server.create_project_invite)
        assert "contributor" in source
        assert "reader" in source
        assert "admin" in source


class TestInviteAcceptance:
    """Test invite acceptance flow."""

    def test_accept_invite_creates_member_of_edge(self):
        """Verify accept creates a MEMBER_OF relationship."""
        import inspect
        from collab_memory.api import server
        source = inspect.getsource(server.accept_invite)
        assert "MEMBER_OF" in source
        assert "accepted" in source

    def test_signup_and_accept_creates_user_and_member(self):
        """Verify one-step onboarding creates user + project membership."""
        import inspect
        from collab_memory.api import server
        source = inspect.getsource(server.signup_and_accept_invite)
        assert "signup" in source
        assert "MEMBER_OF" in source
        assert "access_token" in source


class TestMemberManagement:
    """Test member listing, role changes, and removal."""

    def test_list_members_query(self):
        """Verify list members queries MEMBER_OF edges."""
        import inspect
        from collab_memory.api import server
        source = inspect.getsource(server.list_project_members)
        assert "MEMBER_OF" in source
        assert "role" in source

    def test_change_role_validates_input(self):
        """Verify role change only accepts valid roles."""
        import inspect
        from collab_memory.api import server
        source = inspect.getsource(server.change_member_role)
        assert "admin" in source
        assert "contributor" in source
        assert "reader" in source
        assert "400" in source  # bad role returns 400

    def test_change_role_checks_membership(self):
        """Verify role change verifies user is actually a member."""
        import inspect
        from collab_memory.api import server
        source = inspect.getsource(server.change_member_role)
        assert "404" in source  # not a member returns 404

    def test_remove_member_deletes_edge(self):
        """Verify remove member deletes the MEMBER_OF relationship."""
        import inspect
        from collab_memory.api import server
        source = inspect.getsource(server.remove_project_member)
        assert "DELETE r" in source


class TestInviteManagement:
    """Test invite listing and revocation."""

    def test_list_invites_filters_pending(self):
        """Verify list invites only returns pending status."""
        import inspect
        from collab_memory.api import server
        source = inspect.getsource(server.list_project_invites)
        assert "pending" in source

    def test_revoke_invite_sets_status(self):
        """Verify revoke sets invite status to 'revoked'."""
        import inspect
        from collab_memory.api import server
        source = inspect.getsource(server.revoke_invite)
        assert "revoked" in source

    def test_preview_invite_checks_expiry(self):
        """Verify preview delegates expiry enforcement to invite loader helper."""
        import inspect
        from collab_memory.api import server
        source = inspect.getsource(server.preview_invite)
        assert "_load_pending_invite" in source

    def test_preview_invite_checks_status(self):
        """Verify preview delegates pending-status enforcement to invite loader helper."""
        import inspect
        from collab_memory.api import server
        source = inspect.getsource(server.preview_invite)
        assert "_load_pending_invite" in source


class TestTeamEndpointStructure:
    """Verify all team endpoints exist on the app."""

    def test_all_team_routes_registered(self):
        from collab_memory.api.server import app

        route_paths = [r.path for r in app.routes if hasattr(r, "path")]

        assert "/projects/{project_id}/members" in route_paths
        assert "/projects/{project_id}/invites" in route_paths
        assert "/invites/{token}" in route_paths
        assert "/invites/{token}/accept" in route_paths
        assert "/invites/{token}/signup-and-accept" in route_paths
        assert "/projects/{project_id}/members/{user_id}/role" in route_paths
        assert "/projects/{project_id}/invites/{token}" in route_paths

    def test_auth_routes_include_mfa(self):
        from collab_memory.api.server import app

        route_paths = [r.path for r in app.routes if hasattr(r, "path")]
        assert "/auth/mfa/setup" in route_paths
        assert "/auth/mfa/verify" in route_paths
        assert "/auth/mfa/status" in route_paths

    def test_social_routes_registered(self):
        from collab_memory.api.server import app

        route_paths = [r.path for r in app.routes if hasattr(r, "path")]
        assert "/auth/social/providers" in route_paths
        assert "/auth/social/{provider}/login" in route_paths
        assert "/auth/social/{provider}/callback" in route_paths


def test_invite_accept_get_redirects_to_signup(client):
    from collab_memory.api import server as srv

    with patch.object(srv, "graph") as mock_graph:
        mock_graph._tx_read.return_value = [{
            "inv": {
                "token": "tok123",
                "project_id": "prj_1",
                "tenant_id": "tenant_a",
                "role": "contributor",
                "status": "pending",
                "expires_at": "2099-01-01T00:00:00",
            }
        }]
        resp = client.get("/invites/tok123/accept", follow_redirects=False)
    assert resp.status_code == 302
    assert "/signup?invite_token=tok123" in resp.headers.get("location", "")


def test_signup_and_accept_uses_invite_tenant_override(client):
    from collab_memory.api import server as srv

    with patch.object(srv, "graph") as mock_graph:
        mock_graph._tx_read.return_value = [{
            "inv": {
                "token": "tok_signup",
                "project_id": "prj_abc",
                "tenant_id": "tenant_from_invite",
                "role": "contributor",
                "status": "pending",
                "expires_at": "2099-01-01T00:00:00",
            }
        }]
        with patch.object(srv, "_project_exists_for_tenant", return_value=True):
            with patch("collab_memory.auth.middleware.get_auth_client") as mock_get_auth_client:
                mock_client = MagicMock()
                mock_client.signup.return_value = {
                    "user_id": "u-new",
                    "access_token": "at",
                    "refresh_token": "rt",
                }
                mock_get_auth_client.return_value = mock_client

                resp = client.post(
                    "/invites/tok_signup/signup-and-accept",
                    params={"email": "new@user.test", "password": "Str0ngP4ss!"},
                )

    assert resp.status_code == 200
    body = resp.json()
    assert body["project_id"] == "prj_abc"
    # Critical regression guard: signup tenant comes from invite.tenant_id, not tenant_name.
    args, kwargs = mock_client.signup.call_args
    assert args[0] == "new@user.test"
    assert args[1] == "Str0ngP4ss!"
    assert args[2] == "workspace"
    assert kwargs["tenant_id_override"] == "tenant_from_invite"
    assert kwargs["bootstrap_workspace"] is False
    assert kwargs["bypass_signup_policy"] is True
