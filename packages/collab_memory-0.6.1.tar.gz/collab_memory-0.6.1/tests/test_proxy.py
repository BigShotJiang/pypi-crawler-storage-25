"""
tests/test_proxy.py — LLM Proxy Tests

Tests for:
    - Provider resolution from model names
    - Config defaults
    - Anthropic→OpenAI response conversion
    - Anthropic body conversion
    - Request model validation
    - API key resolution
"""

import pytest
import os
from unittest.mock import patch, MagicMock


# ── Config Tests ─────────────────────────────────────────────────────────────

class TestProxyConfig:
    """Test proxy configuration."""

    def test_default_config(self):
        from collab_memory.proxy.config import ProxyConfig
        config = ProxyConfig()
        assert config.injection_budget == 2000
        assert config.response_budget == 4096
        assert config.capture_enabled is False
        assert "openai" in config.api_bases
        assert "anthropic" in config.api_bases

    def test_custom_config(self):
        from collab_memory.proxy.config import ProxyConfig
        config = ProxyConfig(injection_budget=4000, capture_enabled=True)
        assert config.injection_budget == 4000
        assert config.capture_enabled is True


class TestProviderResolution:
    """Test model→provider mapping."""

    def test_openai_models(self):
        from collab_memory.proxy.config import resolve_provider
        assert resolve_provider("gpt-4o") == "openai"
        assert resolve_provider("gpt-4o-mini") == "openai"
        assert resolve_provider("o1") == "openai"
        assert resolve_provider("o3-mini") == "openai"

    def test_anthropic_models(self):
        from collab_memory.proxy.config import resolve_provider
        assert resolve_provider("claude-3.5-sonnet") == "anthropic"
        assert resolve_provider("claude-haiku-4-5") == "anthropic"
        assert resolve_provider("claude-sonnet-4-5") == "anthropic"

    def test_gemini_models(self):
        from collab_memory.proxy.config import resolve_provider
        assert resolve_provider("gemini-2.5-pro") == "gemini"
        assert resolve_provider("gemini-2.5-flash") == "gemini"

    def test_groq_models(self):
        from collab_memory.proxy.config import resolve_provider
        assert resolve_provider("llama-3.3-70b-versatile") == "groq"
        assert resolve_provider("mixtral-8x7b-32768") == "groq"

    def test_mistral_models(self):
        from collab_memory.proxy.config import resolve_provider
        assert resolve_provider("mistral-large-latest") == "mistral"

    def test_unknown_model_fallback(self):
        from collab_memory.proxy.config import resolve_provider
        # Prefix-based fallback
        assert resolve_provider("gpt-5-turbo") == "openai"
        assert resolve_provider("claude-4-opus") == "anthropic"
        assert resolve_provider("gemini-3.0-ultra") == "gemini"
        # Unknown defaults to openai
        assert resolve_provider("totally-unknown-model") == "openai"


# ── Response Conversion Tests ────────────────────────────────────────────────

class TestAnthropicConversion:
    """Test Anthropic↔OpenAI format conversion."""

    def test_response_conversion(self):
        from collab_memory.proxy.routes import _anthropic_to_openai_response

        anthropic_resp = {
            "id": "msg_123",
            "content": [
                {"type": "text", "text": "Hello from Claude!"}
            ],
            "stop_reason": "end_turn",
            "usage": {
                "input_tokens": 10,
                "output_tokens": 5,
            },
        }

        result = _anthropic_to_openai_response(anthropic_resp, "claude-3.5-sonnet")

        assert result["object"] == "chat.completion"
        assert result["model"] == "claude-3.5-sonnet"
        assert result["choices"][0]["message"]["content"] == "Hello from Claude!"
        assert result["choices"][0]["finish_reason"] == "stop"
        assert result["usage"]["prompt_tokens"] == 10
        assert result["usage"]["completion_tokens"] == 5
        assert result["usage"]["total_tokens"] == 15

    def test_body_conversion_with_system(self):
        from collab_memory.proxy.routes import _build_anthropic_body, ChatCompletionRequest

        req = ChatCompletionRequest(
            model="claude-3.5-sonnet",
            messages=[
                {"role": "system", "content": "You are helpful."},
                {"role": "user", "content": "Hello"},
            ],
            temperature=0.7,
            max_tokens=1000,
        )

        body = _build_anthropic_body(req)

        assert body["system"] == "You are helpful."
        assert len(body["messages"]) == 1  # system removed from messages
        assert body["messages"][0]["role"] == "user"
        assert body["temperature"] == 0.7
        assert body["max_tokens"] == 1000

    def test_body_conversion_without_system(self):
        from collab_memory.proxy.routes import _build_anthropic_body, ChatCompletionRequest

        req = ChatCompletionRequest(
            model="claude-3.5-sonnet",
            messages=[
                {"role": "user", "content": "Hello"},
            ],
        )

        body = _build_anthropic_body(req)

        assert "system" not in body
        assert len(body["messages"]) == 1
        assert body["max_tokens"] == 4096  # default

    def test_stop_reason_mapping(self):
        from collab_memory.proxy.routes import _map_anthropic_stop
        assert _map_anthropic_stop("end_turn") == "stop"
        assert _map_anthropic_stop("max_tokens") == "length"
        assert _map_anthropic_stop("stop_sequence") == "stop"
        assert _map_anthropic_stop("unknown") == "stop"


# ── API Key Resolution Tests ────────────────────────────────────────────────

class TestKeyResolution:
    """Test API key resolution from graph vault and env fallback."""

    def test_tenant_key_from_graph_vault(self):
        from collab_memory.proxy import routes
        from collab_memory.proxy.routes import _resolve_api_key
        from collab_memory.auth.jwt_provider import AuthUser
        from collab_memory.auth.vault import LLMKeyVault

        user = AuthUser(user_id="test", email="t@t.com", tenant_id="tenant-1")
        vault = LLMKeyVault(master_key_hex="")
        mock_graph = MagicMock()
        mock_graph._tx_read.return_value = [{"encrypted_key": "PLAIN:c2stdmF1bHQta2V5"}]  # base64("sk-vault-key")

        with patch.object(routes, "_graph_backend", mock_graph):
            with patch.dict(os.environ, {}, clear=True):
                key = _resolve_api_key(user, "openai", vault)

        assert key == "sk-vault-key"

    def test_openai_from_env(self):
        from collab_memory.proxy.routes import _resolve_api_key
        from collab_memory.auth.jwt_provider import AuthUser
        from collab_memory.auth.vault import LLMKeyVault

        user = AuthUser(user_id="test", email="t@t.com", tenant_id="t1")
        vault = LLMKeyVault(master_key_hex="")

        with patch.dict(os.environ, {"OPENAI_API_KEY": "sk-test-123"}):
            key = _resolve_api_key(user, "openai", vault)
            assert key == "sk-test-123"

    def test_anthropic_from_env(self):
        from collab_memory.proxy.routes import _resolve_api_key
        from collab_memory.auth.jwt_provider import AuthUser
        from collab_memory.auth.vault import LLMKeyVault

        user = AuthUser(user_id="test", email="t@t.com", tenant_id="t1")
        vault = LLMKeyVault(master_key_hex="")

        with patch.dict(os.environ, {"ANTHROPIC_API_KEY": "sk-ant-test"}):
            key = _resolve_api_key(user, "anthropic", vault)
            assert key == "sk-ant-test"

    def test_missing_key_returns_none(self):
        from collab_memory.proxy.routes import _resolve_api_key
        from collab_memory.auth.jwt_provider import AuthUser
        from collab_memory.auth.vault import LLMKeyVault

        user = AuthUser(user_id="test", email="t@t.com", tenant_id="t1")
        vault = LLMKeyVault(master_key_hex="")

        with patch.dict(os.environ, {}, clear=True):
            key = _resolve_api_key(user, "openai", vault)
            assert key is None


class TestStreamingExtraction:
    def test_extract_openai_delta_text(self):
        from collab_memory.proxy.routes import _extract_openai_delta_text

        line = 'data: {"choices":[{"delta":{"content":"Hello "}}]}'
        assert _extract_openai_delta_text(line) == "Hello "

    def test_extract_anthropic_delta_text(self):
        from collab_memory.proxy.routes import _extract_anthropic_delta_text

        payload = '{"type":"content_block_delta","delta":{"text":"world"}}'
        assert _extract_anthropic_delta_text(payload) == "world"


# ── Model Validation Tests ───────────────────────────────────────────────────

class TestRequestModel:
    """Test ChatCompletionRequest model."""

    def test_minimal_request(self):
        from collab_memory.proxy.routes import ChatCompletionRequest

        req = ChatCompletionRequest(
            model="gpt-4o",
            messages=[{"role": "user", "content": "Hello"}],
        )
        assert req.model == "gpt-4o"
        assert req.stream is False
        assert req.temperature is None

    def test_full_request(self):
        from collab_memory.proxy.routes import ChatCompletionRequest

        req = ChatCompletionRequest(
            model="claude-3.5-sonnet",
            messages=[
                {"role": "system", "content": "You are helpful."},
                {"role": "user", "content": "Hello"},
            ],
            temperature=0.8,
            max_tokens=2000,
            stream=True,
            top_p=0.9,
        )
        assert req.stream is True
        assert req.temperature == 0.8
        assert req.max_tokens == 2000
