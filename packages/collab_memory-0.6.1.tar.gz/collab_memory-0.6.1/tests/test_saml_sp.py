"""
tests/test_saml_sp.py — SAML SP unit tests.

Tests the SAML Service Provider module without hitting real IdPs.
Validates config storage, settings generation, metadata output,
and request preparation.

Integration tests against real Okta/AzureAD/Google sandboxes are
separate (marked @pytest.mark.integration).
"""
import pytest
import json
from unittest.mock import MagicMock, patch


class TestSSOConfig:
    """Test SAML configuration dataclass."""

    def test_default_attribute_map(self):
        from collab_memory.auth.saml_sp import SSOConfig
        config = SSOConfig(
            org_slug="test-org",
            tenant_id="tenant_123",
            idp_entity_id="https://idp.example.com",
            idp_sso_url="https://idp.example.com/sso",
        )
        assert config.attribute_map["email"] == "email"
        assert config.enabled is True

    def test_custom_attribute_map(self):
        from collab_memory.auth.saml_sp import SSOConfig
        config = SSOConfig(
            org_slug="azure-org",
            tenant_id="tenant_456",
            idp_entity_id="https://login.microsoftonline.com/...",
            idp_sso_url="https://login.microsoftonline.com/.../saml2",
            attribute_map={
                "email": "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress",
                "first_name": "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/givenname",
            },
        )
        assert "email" in config.attribute_map
        assert "schemas.xmlsoap.org" in config.attribute_map["email"]


class TestSAMLServiceProvider:
    """Test the SP without a real IdP."""

    def test_init_defaults(self):
        from collab_memory.auth.saml_sp import SAMLServiceProvider
        sp = SAMLServiceProvider()
        assert sp._sp_entity_id  # Should have a default
        assert "/sso/saml/acs" in sp._sp_acs_url
        assert "/sso/saml/metadata" in sp._sp_metadata_url

    def test_init_with_env(self, monkeypatch):
        monkeypatch.setenv("SAML_SP_ENTITY_ID", "https://memory.ohaco.com")
        from collab_memory.auth.saml_sp import SAMLServiceProvider
        sp = SAMLServiceProvider()
        assert sp._sp_entity_id == "https://memory.ohaco.com"
        assert sp._sp_acs_url == "https://memory.ohaco.com/sso/saml/acs"

    def test_in_memory_config_storage(self):
        from collab_memory.auth.saml_sp import SAMLServiceProvider, SSOConfig
        sp = SAMLServiceProvider()
        config = SSOConfig(
            org_slug="test",
            tenant_id="t1",
            idp_entity_id="https://idp.test",
            idp_sso_url="https://idp.test/sso",
            idp_x509_cert="MIIC...",
        )
        sp.save_config(config)
        loaded = sp.get_config("test")
        assert loaded is not None
        assert loaded.tenant_id == "t1"
        assert loaded.idp_entity_id == "https://idp.test"

    def test_missing_config_returns_none(self):
        from collab_memory.auth.saml_sp import SAMLServiceProvider
        sp = SAMLServiceProvider()
        assert sp.get_config("nonexistent") is None

    def test_build_saml_settings_structure(self):
        from collab_memory.auth.saml_sp import SAMLServiceProvider, SSOConfig
        sp = SAMLServiceProvider()
        config = SSOConfig(
            org_slug="test",
            tenant_id="t1",
            idp_entity_id="https://idp.test",
            idp_sso_url="https://idp.test/sso",
            idp_x509_cert="MIICtest",
        )
        settings = sp._build_saml_settings(config)

        # Verify structure
        assert "sp" in settings
        assert "idp" in settings
        assert "security" in settings
        assert settings["strict"] is True
        assert settings["sp"]["entityId"] == sp._sp_entity_id
        assert settings["idp"]["entityId"] == "https://idp.test"
        assert settings["idp"]["singleSignOnService"]["url"] == "https://idp.test/sso"

        # Security defaults
        assert settings["security"]["wantMessagesSigned"] is True
        assert settings["security"]["wantAssertionsSigned"] is True
        assert settings["security"]["rejectDeprecatedAlgorithm"] is True

    def test_prepare_request_https(self):
        from collab_memory.auth.saml_sp import SAMLServiceProvider
        sp = SAMLServiceProvider()
        prepared = sp.prepare_request({
            "scheme": "https",
            "host": "memory.ohaco.com",
            "port": 443,
            "path": "/sso/saml/acs",
            "get_data": {},
            "post_data": {"SAMLResponse": "base64..."},
        })
        assert prepared["https"] == "on"
        assert prepared["http_host"] == "memory.ohaco.com"

    def test_prepare_request_http(self):
        from collab_memory.auth.saml_sp import SAMLServiceProvider
        sp = SAMLServiceProvider()
        prepared = sp.prepare_request({
            "scheme": "http",
            "host": "localhost",
            "port": 8784,
        })
        assert prepared["https"] == "off"

    def test_metadata_generation(self):
        from collab_memory.auth.saml_sp import SAMLServiceProvider
        sp = SAMLServiceProvider()
        metadata = sp.get_metadata()
        assert "EntityDescriptor" in metadata
        assert "AssertionConsumerService" in metadata
        assert sp._sp_entity_id in metadata

    def test_settings_without_sp_key_disables_signing(self):
        from collab_memory.auth.saml_sp import SAMLServiceProvider, SSOConfig
        sp = SAMLServiceProvider()
        sp._sp_key = ""
        sp._sp_cert = ""
        config = SSOConfig(
            org_slug="test",
            tenant_id="t1",
            idp_entity_id="https://idp.test",
            idp_sso_url="https://idp.test/sso",
        )
        settings = sp._build_saml_settings(config)
        assert settings["security"]["authnRequestsSigned"] is False
        assert settings["security"]["logoutRequestSigned"] is False


class TestSAMLRouteHelpers:
    """Test route helper functions."""

    def test_extract_request_data(self):
        from collab_memory.auth.saml_routes import _extract_request_data
        mock_request = MagicMock()
        mock_request.url.scheme = "https"
        mock_request.url.hostname = "memory.ohaco.com"
        mock_request.url.port = 443
        mock_request.url.path = "/sso/saml/login"
        mock_request.query_params = {"org": "acme"}

        data = _extract_request_data(mock_request)
        assert data["scheme"] == "https"
        assert data["host"] == "memory.ohaco.com"
        assert data["get_data"]["org"] == "acme"


class TestSAMLConfigRequest:
    """Test the config request model."""

    def test_minimal_config(self):
        from collab_memory.auth.saml_routes import SAMLConfigRequest
        req = SAMLConfigRequest(
            org_slug="acme",
            tenant_id="t1",
            idp_entity_id="https://okta.example.com",
            idp_sso_url="https://okta.example.com/app/sso",
            idp_x509_cert="MIICtest...",
        )
        assert req.org_slug == "acme"
        assert req.attribute_map == {}  # defaults to empty, SP fills defaults
