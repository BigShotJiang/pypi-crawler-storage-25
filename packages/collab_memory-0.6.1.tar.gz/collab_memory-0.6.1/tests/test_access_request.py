"""POST /auth/access-request and strict signup policy."""

import pytest
from starlette.testclient import TestClient


@pytest.fixture
def client() -> TestClient:
    from collab_memory.api.server import app

    return TestClient(app)


def test_access_request_empty_tracks_422(client: TestClient) -> None:
    r = client.post("/auth/access-request", json={"email": "a@b.co", "tracks": []})
    assert r.status_code == 422


def test_access_request_invalid_track_422(client: TestClient) -> None:
    r = client.post("/auth/access-request", json={"email": "a@b.co", "tracks": ["not_a_track"]})
    assert r.status_code == 422


def test_access_request_multiple_tracks_200(client: TestClient) -> None:
    r = client.post(
        "/auth/access-request",
        json={
            "email": "apply-test@example.com",
            "full_name": "Apply Test",
            "tracks": ["launch_waitlist", "community_volunteer"],
            "message": "hello",
        },
    )
    assert r.status_code == 200
    data = r.json()
    assert data.get("status") == "received"
    assert "detail" in data


def test_signup_forbidden_when_strict_and_no_public(monkeypatch: pytest.MonkeyPatch, client: TestClient) -> None:
    monkeypatch.setenv("ALLOW_PUBLIC_SIGNUP", "false")
    monkeypatch.setenv("ALLOW_BOOTSTRAP_SIGNUP", "false")
    monkeypatch.delenv("OWNER_LOGIN_EMAILS", raising=False)
    r = client.post(
        "/auth/signup",
        json={
            "email": "strict-gate@example.com",
            "password": "Str0ngP4ss!",
            "tenant_name": "strict",
        },
    )
    assert r.status_code == 403
    assert "apply" in (r.json().get("detail") or "").lower()


def test_signup_allowed_when_email_on_owner_allowlist(monkeypatch: pytest.MonkeyPatch, client: TestClient) -> None:
    monkeypatch.setenv("ALLOW_PUBLIC_SIGNUP", "false")
    monkeypatch.setenv("ALLOW_BOOTSTRAP_SIGNUP", "false")
    monkeypatch.setenv("OWNER_LOGIN_EMAILS", "owner-allow@example.com")
    r = client.post(
        "/auth/signup",
        json={
            "email": "owner-allow@example.com",
            "password": "Str0ngP4ss!",
            "tenant_name": "owner-tenant",
        },
    )
    assert r.status_code != 403


def test_signup_blocked_when_instance_allowlist_excludes_email(
    monkeypatch: pytest.MonkeyPatch, client: TestClient,
) -> None:
    monkeypatch.setenv("ALLOW_PUBLIC_SIGNUP", "true")
    monkeypatch.setenv("ALLOWED_INSTANCE_LOGIN_EMAILS", "only-one@example.com")
    r = client.post(
        "/auth/signup",
        json={
            "email": "other@example.com",
            "password": "Str0ngP4ss!",
            "tenant_name": "x",
        },
    )
    assert r.status_code == 403
    assert "pre-authorized" in (r.json().get("detail") or "").lower()


def test_instance_access_resolve_session_role() -> None:
    import os
    from collab_memory.auth.instance_access import resolve_session_role

    old = {k: os.environ.pop(k, None) for k in ("SUPER_ADMIN_EMAILS", "INSTANCE_ADMIN_EMAILS")}
    try:
        os.environ["SUPER_ADMIN_EMAILS"] = "boss@example.com"
        os.environ["INSTANCE_ADMIN_EMAILS"] = "staff@example.com"
        assert resolve_session_role("boss@example.com", "contributor") == "super_admin"
        assert resolve_session_role("staff@example.com", "contributor") == "admin"
        assert resolve_session_role("boss@example.com", "admin") == "super_admin"
        assert resolve_session_role("other@example.com", "contributor") == "contributor"
    finally:
        for k, v in old.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v
