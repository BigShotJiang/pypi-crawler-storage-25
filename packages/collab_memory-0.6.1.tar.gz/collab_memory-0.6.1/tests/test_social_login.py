"""
tests/test_social_login.py — Social login unit tests.

Tests the OAuth 2.0 social login module without hitting real providers.
Validates configuration, provider detection, email extraction, and
route helpers.
"""
import pytest
from unittest.mock import MagicMock, patch, AsyncMock


class TestSocialConfig:
    """Test provider configuration detection."""

    def test_no_providers_configured_by_default(self):
        from collab_memory.auth.social import get_configured_providers
        with patch.dict("os.environ", {}, clear=True):
            providers = get_configured_providers()
            # May or may not be empty depending on env, but should be a list
            assert isinstance(providers, list)

    def test_github_configured(self, monkeypatch):
        monkeypatch.setenv("GITHUB_CLIENT_ID", "test-id")
        monkeypatch.setenv("GITHUB_CLIENT_SECRET", "test-secret")
        monkeypatch.delenv("GOOGLE_CLIENT_ID", raising=False)
        monkeypatch.delenv("GOOGLE_CLIENT_SECRET", raising=False)
        from collab_memory.auth.social import get_configured_providers
        providers = get_configured_providers()
        assert "github" in providers

    def test_google_configured(self, monkeypatch):
        monkeypatch.setenv("GOOGLE_CLIENT_ID", "test-id")
        monkeypatch.setenv("GOOGLE_CLIENT_SECRET", "test-secret")
        monkeypatch.delenv("GITHUB_CLIENT_ID", raising=False)
        monkeypatch.delenv("GITHUB_CLIENT_SECRET", raising=False)
        from collab_memory.auth.social import get_configured_providers
        providers = get_configured_providers()
        assert "google" in providers

    def test_both_configured(self, monkeypatch):
        monkeypatch.setenv("GITHUB_CLIENT_ID", "gh-id")
        monkeypatch.setenv("GITHUB_CLIENT_SECRET", "gh-secret")
        monkeypatch.setenv("GOOGLE_CLIENT_ID", "g-id")
        monkeypatch.setenv("GOOGLE_CLIENT_SECRET", "g-secret")
        from collab_memory.auth.social import get_configured_providers
        providers = get_configured_providers()
        assert "github" in providers
        assert "google" in providers

    def test_is_social_available(self):
        from collab_memory.auth.social import is_social_available
        assert is_social_available() is True


class TestOAuthClient:
    """Test OAuth client creation."""

    def test_create_oauth_client_returns_oauth(self, monkeypatch):
        monkeypatch.setenv("GITHUB_CLIENT_ID", "test-id")
        monkeypatch.setenv("GITHUB_CLIENT_SECRET", "test-secret")
        from collab_memory.auth.social import create_oauth_client
        oauth = create_oauth_client()
        assert oauth is not None
        assert hasattr(oauth, "github")

    def test_create_oauth_client_no_creds(self, monkeypatch):
        monkeypatch.delenv("GITHUB_CLIENT_ID", raising=False)
        monkeypatch.delenv("GITHUB_CLIENT_SECRET", raising=False)
        monkeypatch.delenv("GOOGLE_CLIENT_ID", raising=False)
        monkeypatch.delenv("GOOGLE_CLIENT_SECRET", raising=False)
        from collab_memory.auth.social import create_oauth_client
        oauth = create_oauth_client()
        # Returns an OAuth instance even with no providers
        assert oauth is not None


class TestGitHubEmailFetch:
    """Test GitHub email extraction."""

    @pytest.mark.asyncio
    async def test_fetch_email_from_profile(self):
        from collab_memory.auth.social import fetch_github_email
        import httpx

        mock_response_profile = MagicMock()
        mock_response_profile.status_code = 200
        mock_response_profile.json.return_value = {"email": "user@github.com", "login": "testuser"}

        with patch("httpx.AsyncClient") as MockClient:
            instance = AsyncMock()
            instance.get.return_value = mock_response_profile
            instance.__aenter__ = AsyncMock(return_value=instance)
            instance.__aexit__ = AsyncMock(return_value=False)
            MockClient.return_value = instance

            email = await fetch_github_email({"access_token": "fake-token"})
            assert email == "user@github.com"

    @pytest.mark.asyncio
    async def test_fetch_email_from_emails_endpoint(self):
        from collab_memory.auth.social import fetch_github_email
        import httpx

        # Profile returns no email
        mock_profile = MagicMock()
        mock_profile.status_code = 200
        mock_profile.json.return_value = {"email": None, "login": "testuser"}

        # Emails endpoint returns verified primary
        mock_emails = MagicMock()
        mock_emails.status_code = 200
        mock_emails.json.return_value = [
            {"email": "private@example.com", "primary": True, "verified": True},
            {"email": "other@example.com", "primary": False, "verified": True},
        ]

        with patch("httpx.AsyncClient") as MockClient:
            instance = AsyncMock()
            instance.get.side_effect = [mock_profile, mock_emails]
            instance.__aenter__ = AsyncMock(return_value=instance)
            instance.__aexit__ = AsyncMock(return_value=False)
            MockClient.return_value = instance

            email = await fetch_github_email({"access_token": "fake-token"})
            assert email == "private@example.com"


class TestGoogleUserinfo:
    """Test Google OIDC userinfo extraction."""

    @pytest.mark.asyncio
    async def test_extract_userinfo_from_token(self):
        from collab_memory.auth.social import fetch_google_userinfo

        token = {
            "access_token": "ya29.xxx",
            "userinfo": {
                "email": "user@gmail.com",
                "name": "Test User",
                "picture": "https://lh3.googleusercontent.com/photo.jpg",
            },
        }
        info = await fetch_google_userinfo(token)
        assert info["email"] == "user@gmail.com"
        assert info["display_name"] == "Test User"

    @pytest.mark.asyncio
    async def test_missing_userinfo(self):
        from collab_memory.auth.social import fetch_google_userinfo

        token = {"access_token": "ya29.xxx"}
        info = await fetch_google_userinfo(token)
        assert info == {}


class TestProviderConstants:
    """Test that provider metadata is correct."""

    def test_github_provider_config(self):
        from collab_memory.auth.social import PROVIDERS
        gh = PROVIDERS["github"]
        assert "github.com" in gh["authorize_url"]
        assert "api.github.com" in gh["userinfo_endpoint"]
        assert "user:email" in gh["scope"]

    def test_google_provider_config(self):
        from collab_memory.auth.social import PROVIDERS
        g = PROVIDERS["google"]
        assert "accounts.google.com" in g["server_metadata_url"]
        assert "openid" in g["scope"]
        assert "email" in g["scope"]
