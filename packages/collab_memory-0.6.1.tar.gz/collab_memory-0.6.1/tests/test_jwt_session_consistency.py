from collab_memory.auth.jwt_provider import JWTAuthProvider


def test_get_user_prefers_prepared_db_user(monkeypatch):
    monkeypatch.setenv("JWT_SECRET", "unit-test-jwt-secret-key-min-32-chars!!")
    p = JWTAuthProvider(neo4j_backend=None)

    token = p._create_token(
        user_id="u_payload",
        email="user@example.com",
        tenant_id="default",  # stale tenant in token
        plan="pro",
        role="contributor",
        ttl=3600,
    )

    # Simulate persisted user state requiring session preparation.
    persisted = {
        "user_id": "u_db",
        "email": "user@example.com",
        "tenant_id": "default",
        "plan": "pro",
        "role": "contributor",
        "password_hash": "hash",
        "tenant_name": "workspace",
    }
    monkeypatch.setattr(p, "_find_user_by_email", lambda _e: {**persisted})

    def _prepared(user):
        out = {**user}
        out["tenant_id"] = "tenant_fixed"
        out["role"] = "admin"
        return out

    monkeypatch.setattr(p, "prepare_user_for_session", _prepared)

    u = p.get_user(token)
    assert u is not None
    assert u.user_id == "u_db"
    assert u.tenant_id == "tenant_fixed"
    assert u.role == "admin"
