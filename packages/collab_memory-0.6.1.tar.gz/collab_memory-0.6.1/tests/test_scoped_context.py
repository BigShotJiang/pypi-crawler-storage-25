"""
Tests for scoped context endpoints and audit module.
Tests validation, parameter parsing, and audit logging.
"""

import pytest
from datetime import datetime, timezone


# ── Audit module tests ───────────────────────────────────────────────────────


class TestValidateSince:
    """Test the since parameter validation."""

    def test_none_returns_none(self):
        from collab_memory.api.audit import validate_since
        assert validate_since(None) is None

    def test_empty_string_returns_none(self):
        from collab_memory.api.audit import validate_since
        assert validate_since("") is None
        assert validate_since("  ") is None

    def test_unix_timestamp(self):
        from collab_memory.api.audit import validate_since
        result = validate_since("1711929600")
        assert isinstance(result, datetime)
        assert result.tzinfo is not None

    def test_iso_datetime(self):
        from collab_memory.api.audit import validate_since
        result = validate_since("2026-03-01T00:00:00Z")
        assert isinstance(result, datetime)
        assert result.year == 2026
        assert result.month == 3

    def test_iso_datetime_without_tz(self):
        from collab_memory.api.audit import validate_since
        result = validate_since("2026-03-01T00:00:00")
        assert isinstance(result, datetime)
        assert result.tzinfo == timezone.utc  # Should default to UTC

    def test_invalid_string_raises(self):
        from collab_memory.api.audit import validate_since, ValidationError
        with pytest.raises(ValidationError) as exc_info:
            validate_since("not-a-date")
        assert exc_info.value.param == "since"

    def test_negative_timestamp_raises(self):
        from collab_memory.api.audit import validate_since, ValidationError
        with pytest.raises(ValidationError):
            validate_since("-100")


class TestValidateAgentId:
    """Test the agent_id parameter validation."""

    def test_none_returns_anonymous(self):
        from collab_memory.api.audit import validate_agent_id
        assert validate_agent_id(None) == "anonymous"

    def test_empty_returns_anonymous(self):
        from collab_memory.api.audit import validate_agent_id
        assert validate_agent_id("") == "anonymous"

    def test_valid_agent_id(self):
        from collab_memory.api.audit import validate_agent_id
        assert validate_agent_id("manus-agent-01") == "manus-agent-01"
        assert validate_agent_id("claude_3_5") == "claude_3_5"
        assert validate_agent_id("devin") == "devin"

    def test_invalid_agent_id_raises(self):
        from collab_memory.api.audit import validate_agent_id, ValidationError
        with pytest.raises(ValidationError) as exc_info:
            validate_agent_id("agent with spaces")
        assert exc_info.value.param == "agent_id"

    def test_too_long_agent_id_raises(self):
        from collab_memory.api.audit import validate_agent_id, ValidationError
        with pytest.raises(ValidationError):
            validate_agent_id("a" * 65)

    def test_special_chars_raise(self):
        from collab_memory.api.audit import validate_agent_id, ValidationError
        with pytest.raises(ValidationError):
            validate_agent_id("agent@domain.com")


class TestValidateLimit:
    """Test the limit parameter validation."""

    def test_none_returns_default(self):
        from collab_memory.api.audit import validate_limit
        assert validate_limit(None) == 10

    def test_valid_limit(self):
        from collab_memory.api.audit import validate_limit
        assert validate_limit(5) == 5
        assert validate_limit(50) == 50
        assert validate_limit(1) == 1

    def test_zero_raises(self):
        from collab_memory.api.audit import validate_limit, ValidationError
        with pytest.raises(ValidationError):
            validate_limit(0)

    def test_over_50_raises(self):
        from collab_memory.api.audit import validate_limit, ValidationError
        with pytest.raises(ValidationError):
            validate_limit(51)


class TestValidateConfidenceMin:
    """Test the confidence_min parameter validation."""

    def test_none_returns_zero(self):
        from collab_memory.api.audit import validate_confidence_min
        assert validate_confidence_min(None) == 0.0

    def test_valid_values(self):
        from collab_memory.api.audit import validate_confidence_min
        assert validate_confidence_min(0.0) == 0.0
        assert validate_confidence_min(0.5) == 0.5
        assert validate_confidence_min(1.0) == 1.0

    def test_negative_raises(self):
        from collab_memory.api.audit import validate_confidence_min, ValidationError
        with pytest.raises(ValidationError):
            validate_confidence_min(-0.1)

    def test_over_one_raises(self):
        from collab_memory.api.audit import validate_confidence_min, ValidationError
        with pytest.raises(ValidationError):
            validate_confidence_min(1.1)


class TestValidateOrigin:
    """Test the origin parameter validation."""

    def test_none_returns_all(self):
        from collab_memory.api.audit import validate_origin
        assert validate_origin(None) == "all"

    def test_valid_values(self):
        from collab_memory.api.audit import validate_origin
        assert validate_origin("explicit") == "explicit"
        assert validate_origin("inferred") == "inferred"
        assert validate_origin("all") == "all"
        assert validate_origin("  EXPLICIT  ") == "explicit"  # Case + whitespace

    def test_invalid_raises(self):
        from collab_memory.api.audit import validate_origin, ValidationError
        with pytest.raises(ValidationError) as exc_info:
            validate_origin("unknown")
        assert exc_info.value.param == "origin"


class TestAuditLog:
    """Test the in-memory audit log."""

    def test_record_and_retrieve(self):
        from collab_memory.api.audit import record_audit, get_audit_entries, _audit_log
        # Clear log
        _audit_log.clear()

        record_audit(
            endpoint="/memory/context/prompt",
            agent_id="test-agent",
            project_id="test-project",
            params={"since": "2026-03-01"},
            result_counts={"decisions": 5, "constraints": 3},
            response_chars=1200,
            latency_ms=45.3,
        )

        entries = get_audit_entries(limit=10)
        assert len(entries) == 1
        assert entries[0]["agent_id"] == "test-agent"
        assert entries[0]["project_id"] == "test-project"
        assert entries[0]["result_counts"]["decisions"] == 5
        assert entries[0]["latency_ms"] == 45.3

    def test_entries_newest_first(self):
        from collab_memory.api.audit import record_audit, get_audit_entries, _audit_log
        _audit_log.clear()

        for i in range(3):
            record_audit(
                endpoint="/memory/context/prompt",
                agent_id=f"agent-{i}",
                project_id=None,
                params={},
                result_counts={},
                response_chars=0,
                latency_ms=0,
            )

        entries = get_audit_entries(limit=10)
        assert entries[0]["agent_id"] == "agent-2"
        assert entries[2]["agent_id"] == "agent-0"

    def test_stats_aggregation(self):
        from collab_memory.api.audit import record_audit, get_audit_stats, _audit_log
        _audit_log.clear()

        for _ in range(3):
            record_audit(
                endpoint="/test",
                agent_id="agent-a",
                project_id=None,
                params={},
                result_counts={},
                response_chars=0,
                latency_ms=0,
            )
        record_audit(
            endpoint="/test",
            agent_id="agent-b",
            project_id=None,
            params={},
            result_counts={},
            response_chars=0,
            latency_ms=0,
        )

        stats = get_audit_stats()
        assert stats["total_retrievals"] == 4
        assert stats["unique_agents"] == 2
        # agent-a should be first (3 retrievals)
        assert stats["agents"][0]["agent_id"] == "agent-a"
        assert stats["agents"][0]["retrieval_count"] == 3

    def test_empty_stats(self):
        from collab_memory.api.audit import get_audit_stats, _audit_log
        _audit_log.clear()
        stats = get_audit_stats()
        assert stats["total_retrievals"] == 0
        assert stats["unique_agents"] == 0
