"""Tests for Cognitive Dreams recall reinforcement — schema + neo4j method."""
import pytest
from datetime import datetime, timezone


# ── Schema field tests ──

def test_decision_has_recall_fields():
    from collab_memory.schema import Decision
    d = Decision(made_in="s1", description="Use React")
    assert d.recall_count == 0
    assert d.last_recalled is None


def test_constraint_has_recall_fields():
    from collab_memory.schema import Constraint
    c = Constraint(surfaced_in="s1", description="No public API keys")
    assert c.recall_count == 0
    assert c.last_recalled is None


def test_attempt_has_recall_fields():
    from collab_memory.schema import Attempt
    a = Attempt(tried_in="s1", description="Tried GraphQL")
    assert a.recall_count == 0
    assert a.last_recalled is None


def test_preference_has_reinforcement_fields():
    """Preference already had reinforcement_count — verify it's still there."""
    from collab_memory.schema import Preference, PreferenceType
    p = Preference(
        inferred_in="s1",
        description="Prefers dark mode",
        type=PreferenceType.aesthetic,
    )
    assert p.reinforcement_count == 1  # Default is 1 (initial observation)
    assert p.last_reinforced is not None


# ── reinforce_nodes method tests (mocked Neo4j) ──

class FakeNeo4jBackend:
    """Minimal mock to test reinforce_nodes logic."""

    def __init__(self):
        self._queries = []
        self._db = "neo4j"

    class _FakeSession:
        def __init__(self, store):
            self._store = store

        def __enter__(self):
            return self

        def __exit__(self, *a):
            pass

        def run(self, query, **params):
            self._store.append({"query": query, "params": params})
            # Return a fake result with count
            return [{"updated": len(params.get("ids", []))}]

    class _FakeDriver:
        def __init__(self, store):
            self._store = store

        def session(self, database=None):
            return FakeNeo4jBackend._FakeSession(self._store)

    def __init__(self):
        self._queries = []
        self._driver = self._FakeDriver(self._queries)
        self._db = "neo4j"


def test_reinforce_nodes_empty():
    from collab_memory.graph.neo4j_backend import Neo4jBackend
    backend = FakeNeo4jBackend()
    # Monkey-patch the method onto our fake
    backend.reinforce_nodes = Neo4jBackend.reinforce_nodes.__get__(backend)
    result = backend.reinforce_nodes([])
    assert result == 0
    assert len(backend._queries) == 0


def test_reinforce_nodes_batch():
    from collab_memory.graph.neo4j_backend import Neo4jBackend
    backend = FakeNeo4jBackend()
    backend.reinforce_nodes = Neo4jBackend.reinforce_nodes.__get__(backend)
    backend._tx_read = Neo4jBackend._tx_read.__get__(backend)

    result = backend.reinforce_nodes(["dec_abc", "con_def", "prf_ghi"])
    assert result == 3
    assert len(backend._queries) == 1
    q = backend._queries[0]
    assert "recall_count" in q["query"]
    assert "reinforcement_count" in q["query"]
    assert q["params"]["ids"] == ["dec_abc", "con_def", "prf_ghi"]


def test_reinforce_nodes_handles_error():
    """reinforce_nodes should return 0 on error, not raise."""
    from collab_memory.graph.neo4j_backend import Neo4jBackend

    class BrokenBackend:
        _db = "neo4j"

        def _tx_read(self, query, **params):
            raise RuntimeError("Connection lost")

    backend = BrokenBackend()
    backend.reinforce_nodes = Neo4jBackend.reinforce_nodes.__get__(backend)
    result = backend.reinforce_nodes(["dec_abc"])
    assert result == 0  # Graceful failure
