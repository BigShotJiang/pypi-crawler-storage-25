"""
tests/test_abac.py — Unit tests for the ABAC access control layer.

Tests cover:
  - Role resolution from env-var key map
  - AgentContext properties (can_write, can_delete, requires_hitl)
  - require_role dependency enforcement
  - reader_view normalization and confidence filtering
  - External role redirect/block logic
"""
import os
import pytest
import asyncio
from unittest.mock import MagicMock


# ── Fixtures ─────────────────────────────────────────────────────────────────

@pytest.fixture(autouse=True)
def env_keys(monkeypatch):
    """Set a known ABAC key environment for each test."""
    monkeypatch.setenv("COLLAB_API_KEY", "admin-key")
    monkeypatch.setenv("COLLAB_API_KEY_MANUS", "manus-key")
    monkeypatch.setenv("COLLAB_API_KEY_READONLY", "reader-key")
    monkeypatch.setenv("COLLAB_API_KEY_EXTERNAL", "external-key")
    monkeypatch.setenv("COLLAB_API_KEY_BOT", "bot-key")


def fresh_abac():
    """Reimport abac module to pick up monkeypatched env vars."""
    import importlib
    import collab_memory.abac as abac_mod
    importlib.reload(abac_mod)
    return abac_mod


# ── Role map construction ────────────────────────────────────────────────────

class TestRoleMap:
    def test_admin_key_resolved(self):
        abac = fresh_abac()
        ctx = abac.resolve_agent_context("admin-key")
        assert ctx.role == "admin"
        assert ctx.agent_id == "admin"

    def test_manus_contributor(self):
        abac = fresh_abac()
        ctx = abac.resolve_agent_context("manus-key")
        assert ctx.role == "contributor"
        assert ctx.agent_id == "manus"

    def test_readonly_reader(self):
        abac = fresh_abac()
        ctx = abac.resolve_agent_context("reader-key")
        assert ctx.role == "reader"
        assert ctx.agent_id == "readonly"

    def test_external_role(self):
        abac = fresh_abac()
        ctx = abac.resolve_agent_context("external-key")
        assert ctx.role == "external"
        assert ctx.agent_id == "external"

    def test_unknown_suffix_defaults_contributor(self):
        # COLLAB_API_KEY_BOT → contributor (safe default)
        abac = fresh_abac()
        ctx = abac.resolve_agent_context("bot-key")
        assert ctx.role == "contributor"
        assert ctx.agent_id == "bot"

    def test_empty_key_returns_anonymous(self):
        abac = fresh_abac()
        ctx = abac.resolve_agent_context("")
        assert ctx.role == "anonymous"

    def test_unregistered_key_falls_back_contributor(self):
        abac = fresh_abac()
        ctx = abac.resolve_agent_context("some-random-key")
        assert ctx.role == "contributor"  # unknown but valid → contributor


# ── AgentContext properties ──────────────────────────────────────────────────

class TestAgentContextProperties:
    def test_admin_full_access(self):
        abac = fresh_abac()
        ctx = abac.resolve_agent_context("admin-key")
        assert ctx.can_write is True
        assert ctx.can_delete is True
        assert ctx.requires_hitl is False

    def test_contributor_write_no_delete(self):
        abac = fresh_abac()
        ctx = abac.resolve_agent_context("manus-key")
        assert ctx.can_write is True
        assert ctx.can_delete is False
        assert ctx.requires_hitl is False

    def test_reader_read_only(self):
        abac = fresh_abac()
        ctx = abac.resolve_agent_context("reader-key")
        assert ctx.can_write is False
        assert ctx.can_delete is False
        assert ctx.requires_hitl is False

    def test_external_requires_hitl(self):
        abac = fresh_abac()
        ctx = abac.resolve_agent_context("external-key")
        assert ctx.can_write is False
        assert ctx.can_delete is False
        assert ctx.requires_hitl is True


# ── External redirect/block logic ────────────────────────────────────────────

class TestExternalRouting:
    def test_memory_record_redirects(self):
        abac = fresh_abac()
        assert abac.should_redirect_external_to_hitl("/memory/record", "POST") is True

    def test_memory_ingest_redirects(self):
        abac = fresh_abac()
        assert abac.should_redirect_external_to_hitl("/memory/ingest", "POST") is True

    def test_artifacts_redirects(self):
        abac = fresh_abac()
        assert abac.should_redirect_external_to_hitl("/artifacts", "POST") is True

    def test_delete_never_redirects(self):
        # DELETE should be hard-blocked, not redirected
        abac = fresh_abac()
        assert abac.should_redirect_external_to_hitl("/memory/record", "DELETE") is False

    def test_ops_git_sync_blocked(self):
        abac = fresh_abac()
        assert abac.is_blocked_for_external("/ops/git/sync") is True

    def test_ops_redeploy_blocked(self):
        abac = fresh_abac()
        assert abac.is_blocked_for_external("/ops/redeploy") is True

    def test_memory_nodes_blocked(self):
        abac = fresh_abac()
        assert abac.is_blocked_for_external("/memory/nodes/abc") is True

    def test_unrelated_path_not_blocked(self):
        abac = fresh_abac()
        assert abac.is_blocked_for_external("/health") is False
        assert abac.is_blocked_for_external("/memory/context") is False


# ── reader_view normalization ────────────────────────────────────────────────

class TestReaderView:
    def test_decision_normalized(self):
        abac = fresh_abac()
        node = {"node_type": "Decision", "description": "Use Neo4j", "confidence": 0.9, "id": "abc"}
        result = abac.reader_view(node)
        assert result["type"] == "architectural_decision"
        assert result["summary"] == "Use Neo4j"
        assert result["confidence"] == 0.9
        assert result["ref"] == "abc"
        assert "node_type" not in result  # raw label stripped

    def test_constraint_normalized(self):
        abac = fresh_abac()
        node = {"node_type": "Constraint", "description": "No Redis", "confidence": 0.8}
        result = abac.reader_view(node)
        assert result["type"] == "constraint"

    def test_attempt_normalized(self):
        abac = fresh_abac()
        node = {"node_type": "Attempt", "description": "Tried DynamoDB", "confidence": 0.7}
        result = abac.reader_view(node)
        assert result["type"] == "approach_tried"

    def test_low_confidence_filtered(self):
        abac = fresh_abac()
        node = {"node_type": "Decision", "description": "Weak signal", "confidence": 0.3}
        result = abac.reader_view(node)
        assert result == {}  # filtered out

    def test_exactly_at_threshold_passes(self):
        abac = fresh_abac()
        node = {"node_type": "Decision", "description": "Borderline", "confidence": 0.5}
        result = abac.reader_view(node)
        assert result != {}

    def test_unknown_type_lowercased(self):
        abac = fresh_abac()
        node = {"node_type": "CustomType", "description": "Novel", "confidence": 0.8}
        result = abac.reader_view(node)
        assert result["type"] == "customtype"

    def test_missing_fields_safe(self):
        abac = fresh_abac()
        node = {"confidence": 0.9}  # no description, no type
        result = abac.reader_view(node)
        assert result["summary"] == ""
        assert result["type"] == ""


# ── require_role dependency ─────────────────────────────────────────────────

class TestRequireRole:
    def _make_request(self, role: str):
        import importlib
        abac = fresh_abac()
        request = MagicMock()
        request.state.agent = abac.AgentContext(role=role, agent_id="test")
        return request

    def test_admin_passes_admin(self):
        abac = fresh_abac()
        dep = abac.require_role("admin")
        request = self._make_request("admin")
        result = asyncio.get_event_loop().run_until_complete(dep(request))
        assert result.role == "admin"

    def test_reader_fails_contributor(self):
        from fastapi import HTTPException
        abac = fresh_abac()
        dep = abac.require_role("contributor")
        request = self._make_request("reader")
        with pytest.raises(HTTPException) as exc:
            asyncio.get_event_loop().run_until_complete(dep(request))
        assert exc.value.status_code == 403

    def test_contributor_passes_contributor(self):
        abac = fresh_abac()
        dep = abac.require_role("contributor")
        request = self._make_request("contributor")
        result = asyncio.get_event_loop().run_until_complete(dep(request))
        assert result.role == "contributor"

    def test_contributor_fails_admin(self):
        from fastapi import HTTPException
        abac = fresh_abac()
        dep = abac.require_role("admin")
        request = self._make_request("contributor")
        with pytest.raises(HTTPException) as exc:
            asyncio.get_event_loop().run_until_complete(dep(request))
        assert exc.value.status_code == 403


# ── check_route_permission (write ladder) ───────────────────────────────────

class TestCheckRoutePermission:
    """Documents ABAC write rules: admin > contributor > reader > external."""

    def test_get_always_allowed_even_for_reader(self):
        abac = fresh_abac()
        ctx = abac.AgentContext(role="reader", tenant_id="t1")
        ok, _ = abac.check_route_permission("/memory/record", "GET", ctx)
        assert ok is True

    def test_reader_blocked_on_trusted_write_path(self):
        abac = fresh_abac()
        ctx = abac.AgentContext(role="reader", tenant_id="t1")
        ok, need = abac.check_route_permission("/memory/record", "POST", ctx)
        assert ok is False
        assert need == "contributor"

    def test_contributor_can_memory_record_post(self):
        abac = fresh_abac()
        ctx = abac.AgentContext(role="contributor", tenant_id="t1")
        ok, _ = abac.check_route_permission("/memory/record", "POST", ctx)
        assert ok is True

    def test_contributor_blocked_on_node_delete(self):
        abac = fresh_abac()
        ctx = abac.AgentContext(role="contributor", tenant_id="t1")
        ok, need = abac.check_route_permission("/memory/nodes/n1", "DELETE", ctx)
        assert ok is False
        assert need == "admin"

    def test_admin_bypasses_route_min_table(self):
        abac = fresh_abac()
        ctx = abac.AgentContext(role="admin", tenant_id="t1")
        ok, _ = abac.check_route_permission("/memory/nodes/n1", "DELETE", ctx)
        assert ok is True

    def test_external_blocked_default_write(self):
        abac = fresh_abac()
        ctx = abac.AgentContext(role="external", tenant_id="t1")
        ok, need = abac.check_route_permission("/projects", "POST", ctx)
        assert ok is False
        assert need == "contributor"
