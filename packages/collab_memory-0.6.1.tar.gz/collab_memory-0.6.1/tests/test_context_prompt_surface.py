from starlette.testclient import TestClient


class _GraphPromptStub:
    def __init__(self, brief):
        self._brief = brief

    def build_context_brief(self, **_kwargs):
        return self._brief

    def semantic_search(self, **_kwargs):
        return []


def _make_client(monkeypatch, brief):
    from collab_memory.api import server as srv
    from collab_memory.abac import AgentContext

    monkeypatch.setattr(srv, "graph", _GraphPromptStub(brief))
    monkeypatch.setattr(srv, "_API_KEY", "test_key")
    monkeypatch.setattr(srv, "_VALID_API_KEYS", {"test_key"})

    def _resolve_agent_context(_key, graph=None):
        return AgentContext(
            role="contributor",
            agent_id="agent_prompt",
            key="test_key",
            tenant_id="tenant_test",
            plan="pro",
        )

    monkeypatch.setattr(srv, "resolve_agent_context", _resolve_agent_context)
    return TestClient(srv.app)


def test_context_prompt_exposes_raw_and_display_counts(monkeypatch):
    brief = {
        "active_decisions": [{"description": "Use React for dashboard", "confidence": 0.9}],
        "active_constraints": [{"description": "Do not store secrets in graph", "origin": "explicit"}],
        "inferred_preferences": [{"description": "Prefers concise updates", "type": "process"}],
        "recent_attempts": [],
        "pending_count": 0,
        "backend": "neo4j",
    }
    client = _make_client(monkeypatch, brief)

    resp = client.get("/memory/context/prompt", headers={"X-API-Key": "test_key"})
    assert resp.status_code == 200
    body = resp.json()

    assert body["counts"]["raw"]["decisions"] == 1
    assert body["counts"]["raw"]["constraints"] == 1
    assert body["counts"]["raw"]["preferences"] == 1
    assert body["counts"]["display"]["decisions"] >= 1
    assert body["counts"]["display"]["constraints"] >= 1
    assert body["counts"]["display"]["preferences"] >= 1
    assert body["filter_note"] is None
    assert "Memory Context (collab-memory)" in body["prompt"]


def test_context_prompt_fallback_when_noise_filter_hides_everything(monkeypatch):
    # "property" appears in _NOISE and would normally hide these entries.
    brief = {
        "active_decisions": [{"description": "Property roadmap checkpoint", "confidence": 0.91}],
        "active_constraints": [{"description": "Property ingestion policy", "origin": "explicit"}],
        "inferred_preferences": [{"description": "Property-focused communication", "type": "process"}],
        "recent_attempts": [],
        "pending_count": 0,
        "backend": "neo4j",
    }
    client = _make_client(monkeypatch, brief)

    resp = client.get("/memory/context/prompt", headers={"X-API-Key": "test_key"})
    assert resp.status_code == 200
    body = resp.json()

    assert body["counts"]["raw"]["decisions"] == 1
    assert body["counts"]["raw"]["constraints"] == 1
    assert body["counts"]["raw"]["preferences"] == 1
    assert body["counts"]["display"]["decisions"] == 1
    assert body["counts"]["display"]["constraints"] == 1
    assert body["counts"]["display"]["preferences"] == 1
    assert body["filter_note"] == "fallback_unfiltered_due_empty_filtered_context"
    assert "Context safety fallback" in body["prompt"]
    assert "Property roadmap checkpoint" in body["prompt"]
