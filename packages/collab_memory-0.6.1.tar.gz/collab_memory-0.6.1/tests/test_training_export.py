from __future__ import annotations

import json
from types import SimpleNamespace

from starlette.testclient import TestClient


class _ExportGraphStub:
    def __init__(self):
        self.calls: list[tuple[str, dict]] = []

    def get_decisions(self, **kwargs):
        self.calls.append(("decisions", kwargs))
        return [
            SimpleNamespace(description="Use Neo4j for memory graph", rationale="Latency and query power", confidence=0.9, recall_count=3),
            SimpleNamespace(description="Use Neo4j for memory graph", rationale="Latency and query power", confidence=0.9, recall_count=3),  # duplicate
            SimpleNamespace(description="Ship docs first", rationale="", confidence=0.4, recall_count=4),  # low confidence
            SimpleNamespace(description="Adopt staged rollout", rationale="", confidence=0.9, recall_count=0),  # low recall
        ]

    def get_constraints(self, **kwargs):
        self.calls.append(("constraints", kwargs))
        return [
            SimpleNamespace(description="Never expose tenant data across boundaries", confidence=1.0, recall_count=1),
            SimpleNamespace(description="", confidence=1.0, recall_count=2),  # empty
        ]

    def get_preferences(self, **kwargs):
        self.calls.append(("preferences", kwargs))
        return [
            SimpleNamespace(description="Keep updates concise", type="process", confidence=0.7, reinforcement_count=2),
            SimpleNamespace(description="Keep updates concise", type="process", confidence=0.7, reinforcement_count=2),  # duplicate
            SimpleNamespace(description="Use playful tone", type="interpersonal", confidence=0.8, reinforcement_count=0),  # low reinforcement
        ]


def _make_client(monkeypatch):
    from collab_memory.abac import AgentContext
    from collab_memory.api import server as srv

    graph = _ExportGraphStub()
    monkeypatch.setattr(srv, "graph", graph)
    monkeypatch.setattr(srv, "_API_KEY", "test_key")
    monkeypatch.setattr(srv, "_VALID_API_KEYS", {"test_key"})

    def _resolve_agent_context(_key, graph=None):
        return AgentContext(
            role="contributor",
            agent_id="agent_export",
            key="test_key",
            tenant_id="tenant_export",
            plan="pro",
        )

    monkeypatch.setattr(srv, "resolve_agent_context", _resolve_agent_context)
    return TestClient(srv.app), graph


def test_export_training_data_json_filters_and_metadata(monkeypatch):
    client, graph = _make_client(monkeypatch)
    resp = client.get(
        "/projects/prj_export/export-training-data",
        headers={"X-API-Key": "test_key"},
        params={
            "fmt": "json",
            "min_confidence": 0.5,
            "min_decision_recall": 2,
            "min_constraint_recall": 1,
            "min_preference_reinforcement": 1,
        },
    )
    assert resp.status_code == 200, resp.text
    body = resp.json()

    assert body["project_id"] == "prj_export"
    assert body["tenant_id"] == "tenant_export"
    assert body["count"] == 3
    assert body["source_counts"] == {"decisions": 4, "constraints": 2, "preferences": 3}
    assert body["exported_counts"] == {"decisions": 1, "constraints": 1, "preferences": 1}
    assert body["dropped_counts"]["decisions_low_confidence"] == 1
    assert body["dropped_counts"]["decisions_low_recall"] == 1
    assert body["dropped_counts"]["constraints_empty"] == 1
    assert body["dropped_counts"]["preferences_low_reinforcement"] == 1
    assert body["dropped_counts"]["duplicate_pairs"] == 2

    # Ensure tenant/project scoping is passed to graph read methods.
    for _label, kwargs in graph.calls:
        assert kwargs["project_id"] == "prj_export"
        assert kwargs["tenant_id"] == "tenant_export"


def test_export_training_data_jsonl_includes_meta_header(monkeypatch):
    client, _graph = _make_client(monkeypatch)
    resp = client.get(
        "/projects/prj_export/export-training-data",
        headers={"X-API-Key": "test_key"},
        params={"fmt": "jsonl"},
    )
    assert resp.status_code == 200, resp.text
    lines = [ln for ln in resp.text.splitlines() if ln.strip()]
    assert lines[0].startswith("# collab-memory training export")
    assert lines[1].startswith("# meta: ")

    meta_json = lines[1].replace("# meta: ", "", 1)
    meta = json.loads(meta_json)
    assert meta["project_id"] == "prj_export"
    assert "filters" in meta


def test_export_training_data_rejects_invalid_format(monkeypatch):
    client, _graph = _make_client(monkeypatch)
    resp = client.get(
        "/projects/prj_export/export-training-data",
        headers={"X-API-Key": "test_key"},
        params={"fmt": "yaml"},
    )
    assert resp.status_code == 400
    assert "fmt must be either 'json' or 'jsonl'" in resp.text
