"""
tests/test_adapters.py — Tests for platform export adapters.

Tests chatgpt.py and claude.py using bundled fixture files.
Verifies output format is compatible with encode_session().

Run with: pytest tests/test_adapters.py -v
"""

from __future__ import annotations

import pytest
from pathlib import Path

from src.collab_memory.adapters.chatgpt import parse_chatgpt_export, list_conversations as list_chatgpt
from src.collab_memory.adapters.claude import parse_claude_export, list_conversations as list_claude
from src.collab_memory.encoder import encode_session

FIXTURES_DIR = Path(__file__).parent / "fixtures"
CHATGPT_FIXTURE = str(FIXTURES_DIR / "chatgpt_sample.json")
CLAUDE_FIXTURE = str(FIXTURES_DIR / "claude_sample.json")


# ─── ChatGPT Adapter ──────────────────────────────────────────────────────────

class TestChatGPTAdapter:

    def test_parse_returns_list(self):
        turns = parse_chatgpt_export(CHATGPT_FIXTURE)
        assert isinstance(turns, list)

    def test_parse_returns_nonempty(self):
        turns = parse_chatgpt_export(CHATGPT_FIXTURE)
        assert len(turns) > 0

    def test_turns_are_strings(self):
        turns = parse_chatgpt_export(CHATGPT_FIXTURE)
        for turn in turns:
            assert isinstance(turn, str), f"Expected str, got {type(turn)}"

    def test_turns_have_role_prefix(self):
        """All turns should start with USER: or AGENT:"""
        turns = parse_chatgpt_export(CHATGPT_FIXTURE)
        for turn in turns:
            assert turn.startswith("USER:") or turn.startswith("AGENT:"), (
                f"Turn missing role prefix: '{turn[:60]}'"
            )

    def test_filter_by_title(self):
        turns = parse_chatgpt_export(CHATGPT_FIXTURE, conversation_title="graph layer")
        # Should only include turns from the matching conversation
        assert len(turns) > 0

    def test_filter_by_title_no_match(self):
        turns = parse_chatgpt_export(CHATGPT_FIXTURE, conversation_title="nonexistent_title_xyz")
        assert turns == []

    def test_filter_by_id(self):
        turns = parse_chatgpt_export(CHATGPT_FIXTURE, conversation_id="conv_001_chatgpt")
        assert len(turns) > 0

    def test_max_turns_cap(self):
        turns_full = parse_chatgpt_export(CHATGPT_FIXTURE)
        turns_capped = parse_chatgpt_export(CHATGPT_FIXTURE, max_turns=2)
        assert len(turns_capped) <= 2
        assert len(turns_capped) <= len(turns_full)

    def test_list_conversations(self):
        convs = list_chatgpt(CHATGPT_FIXTURE)
        assert isinstance(convs, list)
        assert len(convs) == 2
        for c in convs:
            assert "id" in c
            assert "title" in c
            assert "message_count" in c

    def test_encode_session_compatible(self):
        """Output must feed directly into encode_session() without errors."""
        turns = parse_chatgpt_export(CHATGPT_FIXTURE)
        results = encode_session(turns, session_id="chatgpt_test_001", skip_llm=True)
        assert isinstance(results, list)

    def test_encode_captures_high_signal(self):
        """The abandon-vector-DB turn should be detected as high-signal."""
        turns = parse_chatgpt_export(CHATGPT_FIXTURE, conversation_id="conv_001_chatgpt")
        results = encode_session(turns, session_id="chatgpt_test_002", skip_llm=True)
        encoded = [r for r in results if r.should_encode]
        assert len(encoded) >= 1, "Expected at least one high-signal exchange from the fixture"


# ─── Claude Adapter ───────────────────────────────────────────────────────────

class TestClaudeAdapter:

    def test_parse_returns_list(self):
        turns = parse_claude_export(CLAUDE_FIXTURE)
        assert isinstance(turns, list)

    def test_parse_returns_nonempty(self):
        turns = parse_claude_export(CLAUDE_FIXTURE)
        assert len(turns) > 0

    def test_turns_are_strings(self):
        turns = parse_claude_export(CLAUDE_FIXTURE)
        for turn in turns:
            assert isinstance(turn, str)

    def test_turns_have_role_prefix(self):
        """All turns should start with USER: or AGENT:"""
        turns = parse_claude_export(CLAUDE_FIXTURE)
        for turn in turns:
            assert turn.startswith("USER:") or turn.startswith("AGENT:"), (
                f"Turn missing role prefix: '{turn[:60]}'"
            )

    def test_filter_by_id(self):
        turns = parse_claude_export(CLAUDE_FIXTURE, conversation_id="claude_conv_001")
        assert len(turns) > 0

    def test_filter_by_title(self):
        turns = parse_claude_export(CLAUDE_FIXTURE, conversation_title="graph layer")
        assert len(turns) > 0

    def test_filter_by_title_no_match(self):
        turns = parse_claude_export(CLAUDE_FIXTURE, conversation_title="nonexistent_xyz")
        assert turns == []

    def test_max_turns_cap(self):
        turns_full = parse_claude_export(CLAUDE_FIXTURE)
        turns_capped = parse_claude_export(CLAUDE_FIXTURE, max_turns=1)
        assert len(turns_capped) <= 1

    def test_list_conversations(self):
        convs = list_claude(CLAUDE_FIXTURE)
        assert isinstance(convs, list)
        assert len(convs) == 2
        for c in convs:
            assert "id" in c
            assert "title" in c

    def test_content_array_format_parsed(self):
        """Second fixture conversation uses content-array format (newer Claude export)."""
        turns = parse_claude_export(CLAUDE_FIXTURE, conversation_id="claude_conv_002")
        assert len(turns) > 0
        for turn in turns:
            assert len(turn) > len("USER: ")  # has actual content

    def test_encode_session_compatible(self):
        """Output must feed directly into encode_session() without errors."""
        turns = parse_claude_export(CLAUDE_FIXTURE)
        results = encode_session(turns, session_id="claude_test_001", skip_llm=True)
        assert isinstance(results, list)

    def test_encode_captures_high_signal(self):
        """The abandon-vector-DB turn should be detected as high-signal."""
        turns = parse_claude_export(CLAUDE_FIXTURE, conversation_id="claude_conv_001")
        results = encode_session(turns, session_id="claude_test_002", skip_llm=True)
        encoded = [r for r in results if r.should_encode]
        assert len(encoded) >= 1, "Expected at least one high-signal exchange from the fixture"


# ─── Cross-Adapter Compatibility ──────────────────────────────────────────────

class TestCrossAdapterCompatibility:

    def test_chatgpt_and_claude_outputs_have_same_format(self):
        """Both adapters must produce the same USER:/AGENT: format."""
        chatgpt_turns = parse_chatgpt_export(CHATGPT_FIXTURE)
        claude_turns = parse_claude_export(CLAUDE_FIXTURE)

        for turn in chatgpt_turns + claude_turns:
            assert turn.startswith("USER:") or turn.startswith("AGENT:")

    def test_interleaved_sessions_encode_cleanly(self):
        """Mix turns from both sources — encode_session should handle it."""
        chatgpt_turns = parse_chatgpt_export(CHATGPT_FIXTURE, conversation_id="conv_001_chatgpt")
        claude_turns = parse_claude_export(CLAUDE_FIXTURE, conversation_id="claude_conv_001")
        combined = chatgpt_turns[:2] + claude_turns[:2]

        results = encode_session(combined, session_id="mixed_test_001", skip_llm=True)
        assert isinstance(results, list)
