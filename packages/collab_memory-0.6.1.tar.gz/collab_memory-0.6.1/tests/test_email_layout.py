"""Branded email shell + ops transactional mail wiring + JWT mail triggers."""

import time
import uuid

import jwt
import pytest
from unittest.mock import MagicMock, patch
from starlette.testclient import TestClient

from collab_memory.auth.email_layout import render_branded_email


def test_render_branded_email_contains_brand_and_cta() -> None:
    html = render_branded_email(
        title="Hello",
        preheader="Hidden preview",
        inner_html="<p>Body</p>",
        cta_href="https://example.com/x",
        cta_label="Go",
    )
    assert "OHACO Labs" in html
    assert "Hello" in html
    assert "https://example.com/x" in html
    assert "Go" in html
    assert "Hidden preview" in html


@pytest.fixture
def client() -> TestClient:
    from collab_memory.api.server import app

    return TestClient(app)


def test_ops_instance_access_summary_requires_key(monkeypatch: pytest.MonkeyPatch, client: TestClient) -> None:
    monkeypatch.setenv("COLLAB_API_KEY", "primary-key")
    r = client.get("/ops/instance-access-summary")
    assert r.status_code in (401, 403)


def test_ops_instance_access_summary_ok(monkeypatch: pytest.MonkeyPatch, client: TestClient) -> None:
    monkeypatch.setenv("COLLAB_API_KEY", "primary-key")
    monkeypatch.setenv("SUPER_ADMIN_EMAILS", "a@b.co")
    monkeypatch.setenv("INSTANCE_ADMIN_EMAILS", "c@d.co")
    monkeypatch.setenv("ALLOWED_INSTANCE_LOGIN_EMAILS", "a@b.co,c@d.co")
    r = client.get("/ops/instance-access-summary", headers={"X-API-Key": "primary-key"})
    assert r.status_code == 200
    d = r.json()
    assert d["super_admin_emails_count"] == 1
    assert d["instance_admin_emails_count"] == 1
    assert d["allowed_instance_login_count"] == 2


def test_ops_transactional_mail_skipped_without_resend(monkeypatch: pytest.MonkeyPatch, client: TestClient) -> None:
    monkeypatch.setenv("COLLAB_API_KEY", "primary-key")
    monkeypatch.delenv("RESEND_API_KEY", raising=False)
    # Module-level caches built at import time; patch so middleware + handler see the key
    import collab_memory.api.server as _srv
    monkeypatch.setattr(_srv, "_API_KEY", "primary-key")
    monkeypatch.setattr(_srv, "_VALID_API_KEYS", {"primary-key"})
    r = client.post(
        "/ops/transactional-mail",
        headers={"X-API-Key": "primary-key"},
        json={"kind": "test", "to": "hello@example.com"},
    )
    assert r.status_code == 200, f"Expected 200, got {r.status_code}: {r.text}"
    assert r.json().get("result", {}).get("status") == "skipped"


def test_ops_transactional_mail_work_report_payload(
    monkeypatch: pytest.MonkeyPatch, client: TestClient
) -> None:
    monkeypatch.setenv("COLLAB_API_KEY", "primary-key")
    monkeypatch.setenv("EMAIL_REPORTING_MODE", "full")
    monkeypatch.delenv("RESEND_API_KEY", raising=False)
    import collab_memory.api.server as _srv
    monkeypatch.setattr(_srv, "_API_KEY", "primary-key")
    monkeypatch.setattr(_srv, "_VALID_API_KEYS", {"primary-key"})

    payload = {
        "kind": "work_report",
        "to": "lead@example.com",
        "task_title": "Build Protocol Report — Provisioning Scope Slice",
        "repo_url": "https://github.com/OHACO-LABS/collab-memory",
        "branch": "cursor/comprehensive-audit-roadmap-finish-plan-f6d5",
        "commit_sha": "7867ab8",
        "pr_url": "https://github.com/OHACO-LABS/collab-memory/pull/73",
        "summary": "Provisioning truth alignment + dual-path operator copy",
        "changes": [
            "Clarified /admin/instances/provision semantics",
            "Added explicit provisioning scope response fields",
        ],
        "tests_run": [
            "pytest -q tests/test_admin_provisioning.py",
            "npm run -s build",
        ],
        "implementation_impact": [
            "Prevents operator confusion between workspace provisioning and infra deploy",
            "Improves reviewability with explicit scope metadata in API/UI",
        ],
        "suggestions": [
            "Introduce dedicated control-plane endpoint for enterprise infra provisioning",
        ],
        "video_urls": [
            "https://example.com/video1.mp4",
            "https://example.com/video2.mp4",
        ],
    }

    r = client.post(
        "/ops/transactional-mail",
        headers={"X-API-Key": "primary-key"},
        json=payload,
    )
    assert r.status_code == 200, r.text
    body = r.json()
    assert body.get("ok") is True
    assert body.get("kind") == "work_report"
    assert body.get("result", {}).get("status") == "skipped"


def test_ops_transactional_mail_work_report_requires_video(
    monkeypatch: pytest.MonkeyPatch, client: TestClient
) -> None:
    monkeypatch.setenv("COLLAB_API_KEY", "primary-key")
    monkeypatch.setenv("EMAIL_REPORTING_MODE", "full")
    monkeypatch.delenv("RESEND_API_KEY", raising=False)
    import collab_memory.api.server as _srv
    monkeypatch.setattr(_srv, "_API_KEY", "primary-key")
    monkeypatch.setattr(_srv, "_VALID_API_KEYS", {"primary-key"})

    r = client.post(
        "/ops/transactional-mail",
        headers={"X-API-Key": "primary-key"},
        json={
            "kind": "work_report",
            "to": "lead@example.com",
            "repo_url": "https://github.com/OHACO-LABS/collab-memory",
            "summary": "Missing videos should fail",
        },
    )
    assert r.status_code == 400
    assert "video_urls" in r.text


def test_ops_transactional_mail_work_report_allows_missing_video_when_flag_off(
    monkeypatch: pytest.MonkeyPatch, client: TestClient
) -> None:
    monkeypatch.setenv("COLLAB_API_KEY", "primary-key")
    monkeypatch.setenv("EMAIL_REPORTING_MODE", "full")
    monkeypatch.setenv("WORK_REPORT_VIDEO_ENFORCEMENT", "warn")
    monkeypatch.delenv("RESEND_API_KEY", raising=False)
    import collab_memory.api.server as _srv
    monkeypatch.setattr(_srv, "_API_KEY", "primary-key")
    monkeypatch.setattr(_srv, "_VALID_API_KEYS", {"primary-key"})

    r = client.post(
        "/ops/transactional-mail",
        headers={"X-API-Key": "primary-key"},
        json={
            "kind": "work_report",
            "to": "lead@example.com",
            "repo_url": "https://github.com/OHACO-LABS/collab-memory",
            "task_summary": "No videos in soft mode should not fail",
            "changes": ["Soft rollout mode for non-UI tasks"],
            "tests": ["pytest -q tests/test_email_layout.py"],
        },
    )
    assert r.status_code == 200, r.text
    body = r.json()
    assert body.get("ok") is True
    assert body.get("kind") == "work_report"
    assert body.get("enforcement_mode") == "warn"
    assert "work_report_missing_video_urls_allowed_in_warn_mode" in body.get("warnings", [])
    assert body.get("video_urls_present") is False


def _jwt(monkeypatch: pytest.MonkeyPatch, *, role: str = "contributor", email: str = "me@example.com") -> str:
    sec = "unit-test-jwt-secret-key-min-32-chars!!"
    monkeypatch.setenv("JWT_SECRET", sec)
    from collab_memory.auth.middleware import init_auth_client

    init_auth_client(neo4j_backend=None)
    now = int(time.time())
    payload = {
        "sub": "u-test",
        "email": email,
        "tenant_id": str(uuid.uuid4()),
        "plan": "free",
        "role": role,
        "iat": now,
        "exp": now + 3600,
        "type": "access",
    }
    return jwt.encode(payload, sec, algorithm="HS256")


def test_auth_email_self_test_401_without_token(client: TestClient) -> None:
    r = client.post("/auth/email/self-test")
    assert r.status_code == 401


def test_auth_email_self_test_skipped(monkeypatch: pytest.MonkeyPatch, client: TestClient) -> None:
    monkeypatch.delenv("RESEND_API_KEY", raising=False)
    tok = _jwt(monkeypatch, email="self@example.com")
    r = client.post("/auth/email/self-test", headers={"Authorization": f"Bearer {tok}"})
    assert r.status_code == 200
    d = r.json()
    assert d.get("mail", {}).get("status") == "skipped"


def test_auth_email_invite_forbidden_for_contributor(monkeypatch: pytest.MonkeyPatch, client: TestClient) -> None:
    tok = _jwt(monkeypatch, role="contributor")
    r = client.post(
        "/auth/email/invite-teammate",
        headers={"Authorization": f"Bearer {tok}", "Content-Type": "application/json"},
        json={"to": "other@example.com"},
    )
    assert r.status_code == 403


def test_auth_email_invite_admin_skipped(monkeypatch: pytest.MonkeyPatch, client: TestClient) -> None:
    monkeypatch.delenv("RESEND_API_KEY", raising=False)
    tok = _jwt(monkeypatch, role="admin", email="admin@example.com")
    r = client.post(
        "/auth/email/invite-teammate",
        headers={"Authorization": f"Bearer {tok}", "Content-Type": "application/json"},
        json={"to": "other@example.com", "role_description": "admin"},
    )
    assert r.status_code == 200
    assert r.json().get("mail", {}).get("status") == "skipped"


def test_invite_signup_path_is_public_with_api_key_enabled(monkeypatch: pytest.MonkeyPatch, client: TestClient) -> None:
    """Invite onboarding should work without pre-existing auth headers."""
    monkeypatch.setenv("COLLAB_API_KEY", "primary-key")
    import collab_memory.api.server as _srv
    monkeypatch.setattr(_srv, "_API_KEY", "primary-key")
    monkeypatch.setattr(_srv, "_VALID_API_KEYS", {"primary-key"})

    with pytest.MonkeyPatch.context() as mp:
        mp.setattr(
            _srv,
            "_load_pending_invite",
            lambda token: {
                "token": token,
                "project_id": "prj_public_invite",
                "tenant_id": "tenant_public_invite",
                "role": "contributor",
                "status": "pending",
                "expires_at": "2099-01-01T00:00:00",
            },
        )
        mp.setattr(_srv, "_project_exists_for_tenant", lambda _pid, _tid: True)
        with patch.object(_srv, "graph") as mock_graph:
            mock_graph._tx_write = MagicMock()
            with patch("collab_memory.auth.middleware.get_auth_client") as mock_get_auth_client:
                mock_client = mock_get_auth_client.return_value
                mock_client.signup.return_value = {
                    "user_id": "u-public",
                    "access_token": "tok_access",
                    "refresh_token": "tok_refresh",
                }
                r = client.post(
                    "/invites/tok-public/signup-and-accept",
                    params={"email": "invitee@example.com", "password": "Str0ngP4ss!"},
                )

    assert r.status_code == 200


def test_ops_transactional_mail_release_decision_go_skipped_without_resend(
    monkeypatch: pytest.MonkeyPatch, client: TestClient
) -> None:
    monkeypatch.setenv("COLLAB_API_KEY", "primary-key")
    monkeypatch.delenv("RESEND_API_KEY", raising=False)
    import collab_memory.api.server as _srv

    monkeypatch.setattr(_srv, "_API_KEY", "primary-key")
    monkeypatch.setattr(_srv, "_VALID_API_KEYS", {"primary-key"})
    r = client.post(
        "/ops/transactional-mail",
        headers={"X-API-Key": "primary-key"},
        json={
            "kind": "release_decision",
            "to": "lead@example.com",
            "decision": "go",
            "target_branch": "main",
            "approved_prs": ["#71", "#72"],
            "summary": "All approvals complete and checks pass.",
            "tests": ["pytest tests/test_email_layout.py"],
            "artifacts": ["/opt/cursor/artifacts/release_go.mp4"],
        },
    )
    assert r.status_code == 200, f"Expected 200, got {r.status_code}: {r.text}"
    body = r.json()
    assert body.get("ok") is True
    assert body.get("result", {}).get("status") == "skipped"


def test_ops_transactional_mail_release_decision_no_go_requires_blockers(
    monkeypatch: pytest.MonkeyPatch, client: TestClient
) -> None:
    monkeypatch.setenv("COLLAB_API_KEY", "primary-key")
    import collab_memory.api.server as _srv

    monkeypatch.setattr(_srv, "_API_KEY", "primary-key")
    monkeypatch.setattr(_srv, "_VALID_API_KEYS", {"primary-key"})
    r = client.post(
        "/ops/transactional-mail",
        headers={"X-API-Key": "primary-key"},
        json={
            "kind": "release_decision",
            "to": "lead@example.com",
            "decision": "no_go",
            "target_branch": "main",
            "summary": "Main push blocked pending auth key availability.",
            "next_actions": ["Obtain write-capable API key"],
        },
    )
    assert r.status_code == 400
    assert "missing required fields" in r.json().get("detail", "")


def test_ops_transactional_mail_release_decision_rejects_invalid_decision(
    monkeypatch: pytest.MonkeyPatch, client: TestClient
) -> None:
    monkeypatch.setenv("COLLAB_API_KEY", "primary-key")
    import collab_memory.api.server as _srv

    monkeypatch.setattr(_srv, "_API_KEY", "primary-key")
    monkeypatch.setattr(_srv, "_VALID_API_KEYS", {"primary-key"})
    r = client.post(
        "/ops/transactional-mail",
        headers={"X-API-Key": "primary-key"},
        json={
            "kind": "release_decision",
            "to": "lead@example.com",
            "decision": "shipit",
            "target_branch": "main",
            "summary": "Invalid decision should fail.",
            "approved_prs": ["#71"],
        },
    )
    assert r.status_code == 400
    assert "decision=go|no_go" in r.json().get("detail", "")


def test_ops_transactional_mail_release_decision_go_auto_attaches_latest_snapshot(
    monkeypatch: pytest.MonkeyPatch, client: TestClient
) -> None:
    monkeypatch.setenv("COLLAB_API_KEY", "primary-key")
    monkeypatch.setenv("EMAIL_REPORTING_MODE", "full")
    monkeypatch.delenv("RESEND_API_KEY", raising=False)
    import collab_memory.api.server as _srv

    monkeypatch.setattr(_srv, "_API_KEY", "primary-key")
    monkeypatch.setattr(_srv, "_VALID_API_KEYS", {"primary-key"})
    with patch.object(_srv, "list_project_snapshots") as mock_list_snapshots:
        mock_list_snapshots.return_value = {
            "project_id": "prj_snap",
            "snapshots": [
                {
                    "id": "snap_123",
                    "summary": "Ready for push",
                    "saved_at": "2026-04-15T10:00:00Z",
                    "screenshot_artifact_id": "art_img_123",
                    "screenshot_url": "/artifacts/art_img_123/preview",
                }
            ],
        }
        r = client.post(
            "/ops/transactional-mail",
            headers={"X-API-Key": "primary-key"},
            json={
                "kind": "release_decision",
                "to": "lead@example.com",
                "decision": "go",
                "target_branch": "main",
                "approved_prs": ["#75"],
                "summary": "Merge approved.",
                "project_id": "prj_snap",
            },
        )
    assert r.status_code == 200, f"Expected 200, got {r.status_code}: {r.text}"
    body = r.json()
    assert body.get("ok") is True
    assert body.get("result", {}).get("status") == "skipped"
    auto = body.get("auto_snapshot")
    assert isinstance(auto, dict)
    assert auto.get("project_id") == "prj_snap"
    assert auto.get("artifacts_added")
    artifacts_added = auto.get("artifacts_added", [])
    assert any(item == "project_snapshot_id:snap_123" for item in artifacts_added)
    assert any(item == "project_snapshot_saved_at:2026-04-15T10:00:00Z" for item in artifacts_added)
    assert any(item == "project_snapshot_summary:Ready for push" for item in artifacts_added)
    assert any(item.startswith("project_snapshot_preview:") for item in artifacts_added)


def test_ops_transactional_mail_work_report_text_only_mode_blocks_media(
    monkeypatch: pytest.MonkeyPatch, client: TestClient
) -> None:
    monkeypatch.setenv("COLLAB_API_KEY", "primary-key")
    import collab_memory.api.server as _srv
    _srv._set_email_reporting_mode("text_only")
    monkeypatch.delenv("RESEND_API_KEY", raising=False)

    monkeypatch.setattr(_srv, "_API_KEY", "primary-key")
    monkeypatch.setattr(_srv, "_VALID_API_KEYS", {"primary-key"})
    r = client.post(
        "/ops/transactional-mail",
        headers={"X-API-Key": "primary-key"},
        json={
            "kind": "work_report",
            "to": "lead@example.com",
            "repo_url": "https://github.com/OHACO-LABS/collab-memory",
            "task_summary": "Text-only mode should block media fields.",
            "changes": ["Enable report policy controls"],
            "tests": ["pytest -q tests/test_email_layout.py"],
            "video_urls": ["https://example.com/demo.mp4"],
        },
    )
    assert r.status_code == 400
    assert "text_only" in r.json().get("detail", "")


def test_ops_transactional_mail_release_decision_off_mode_disabled(
    monkeypatch: pytest.MonkeyPatch, client: TestClient
) -> None:
    monkeypatch.setenv("COLLAB_API_KEY", "primary-key")
    import collab_memory.api.server as _srv
    _srv._set_email_reporting_mode("off")
    monkeypatch.setattr(_srv, "_API_KEY", "primary-key")
    monkeypatch.setattr(_srv, "_VALID_API_KEYS", {"primary-key"})
    r = client.post(
        "/ops/transactional-mail",
        headers={"X-API-Key": "primary-key"},
        json={
            "kind": "release_decision",
            "to": "lead@example.com",
            "decision": "go",
            "target_branch": "main",
            "approved_prs": ["#75"],
            "summary": "Disabled mode should reject this.",
        },
    )
    assert r.status_code == 403
    assert "disabled" in r.json().get("detail", "")


def test_email_reporting_policy_update_and_readback(
    monkeypatch: pytest.MonkeyPatch, client: TestClient
) -> None:
    monkeypatch.setenv("COLLAB_API_KEY", "primary-key")
    import collab_memory.api.server as _srv

    monkeypatch.setattr(_srv, "_API_KEY", "primary-key")
    monkeypatch.setattr(_srv, "_VALID_API_KEYS", {"primary-key"})
    r_set = client.patch(
        "/ops/email-reporting-policy",
        headers={"X-API-Key": "primary-key"},
        json={"mode": "text_only"},
    )
    assert r_set.status_code == 200
    assert r_set.json().get("mode") == "text_only"

    r_get = client.get("/ops/email-reporting-policy", headers={"X-API-Key": "primary-key"})
    assert r_get.status_code == 200
    policy = r_get.json()
    assert policy.get("mode") == "text_only"
    assert policy.get("media_enabled") is False
