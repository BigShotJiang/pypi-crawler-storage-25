"""Investor intake and deck route wiring tests."""

from starlette.testclient import TestClient


def _client() -> TestClient:
    from collab_memory.api.server import app

    return TestClient(app)


def test_investor_request_requires_ncnda_ack() -> None:
    client = _client()
    headers = {"X-API-Key": "test-investor-ncnda"}
    r = client.post(
        "/auth/investor-request",
        json={
            "email": "investor@example.com",
            "full_name": "Investor One",
            "role": "investor",
            "firm": "Example Capital",
            "message": "Interested in product and moat.",
            "ncnnda_ack": False,
        },
        headers=headers,
    )
    assert r.status_code == 400
    assert "acknowledge" in (r.json().get("detail") or "").lower()


def test_investor_request_returns_canonical_deck_url() -> None:
    client = _client()
    headers = {"X-API-Key": "test-investor-canonical-deck"}
    r = client.post(
        "/auth/investor-request",
        json={
            "email": "advisor@example.com",
            "full_name": "Advisor One",
            "role": "advisor",
            "firm": "Advisory Group",
            "timeline": "strategic_advisor",
            "message": "Happy to review and mentor.",
            "ncnnda_ack": True,
        },
        headers=headers,
    )
    assert r.status_code == 200
    data = r.json()
    assert data.get("status") == "received"
    assert data.get("next", {}).get("deck_url") == "/investor-deck"


def test_deck_alias_redirects_to_canonical_path() -> None:
    client = _client()
    r = client.get("/deck", follow_redirects=False)
    assert r.status_code == 302
    assert r.headers.get("location", "").endswith("/investor-deck")


def test_investor_duplicate_submission_reuses_pending_request_id() -> None:
    client = _client()
    headers = {"X-API-Key": "test-investor-duplicate"}
    payload = {
        "email": "dup-investor@example.com",
        "full_name": "Dup Investor",
        "role": "investor",
        "firm": "Dup Capital",
        "timeline": "seed_investment",
        "message": "first submit",
        "ncnnda_ack": True,
    }
    first = client.post("/auth/investor-request", json=payload, headers=headers)
    assert first.status_code == 200
    first_data = first.json()
    second = client.post("/auth/investor-request", json=payload, headers=headers)
    assert second.status_code == 200
    second_data = second.json()
    assert second_data.get("duplicate") is True
    assert second_data.get("request_id") == first_data.get("request_id")
