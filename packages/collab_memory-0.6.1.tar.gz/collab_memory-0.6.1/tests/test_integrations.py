"""Tests for the Integration Hub — base adapter pattern + GitHub integration."""

import pytest
import asyncio

from collab_memory.integrations.base import Integration, IntegrationStatus, SyncResult
from collab_memory.integrations.github import (
    GitHubIntegration,
    _pr_to_node,
    _issue_to_node,
    _commit_to_node,
)


# ── Base adapter tests ──

class TestSyncResult:
    def test_empty_result_is_ok(self):
        r = SyncResult()
        assert r.ok is True
        assert r.nodes_created == []

    def test_result_with_errors_not_ok(self):
        r = SyncResult(errors=["something went wrong"])
        assert r.ok is False

    def test_result_with_nodes(self):
        r = SyncResult(nodes_created=[{"type": "Task"}])
        assert r.ok is True
        assert len(r.nodes_created) == 1


class TestIntegrationStatus:
    def test_default_disconnected(self):
        s = IntegrationStatus()
        assert s.connected is False
        assert s.error is None

    def test_connected_with_metadata(self):
        s = IntegrationStatus(connected=True, metadata={"login": "octocat"})
        assert s.connected is True
        assert s.metadata["login"] == "octocat"


# ── GitHub PR conversion ──

class TestPRToNode:
    def test_opened_pr(self):
        pr = {
            "number": 47,
            "title": "feat: Command Center",
            "html_url": "https://github.com/OHACO-LABS/collab-memory/pull/47",
            "user": {"login": "esther"},
            "head": {"ref": "feat/command-center"},
            "merged": False,
        }
        node = _pr_to_node(pr, "opened", "tenant_1")
        assert node is not None
        assert node["type"] == "Task"
        assert node["status"] == "open"
        assert "PR #47" in node["label"]
        assert node["tenant_id"] == "tenant_1"
        assert node["metadata"]["github_number"] == 47

    def test_merged_pr(self):
        pr = {"number": 47, "title": "feat: CC", "merged": True, "user": {}, "head": {}}
        node = _pr_to_node(pr, "closed", "t1")
        assert node["status"] == "merged"

    def test_closed_not_merged(self):
        pr = {"number": 47, "title": "feat: CC", "merged": False, "user": {}, "head": {}}
        node = _pr_to_node(pr, "closed", "t1")
        assert node["status"] == "closed"

    def test_irrelevant_action_returns_none(self):
        assert _pr_to_node({}, "edited", "t1") is None
        assert _pr_to_node({}, "labeled", "t1") is None


# ── GitHub Issue conversion ──

class TestIssueToNode:
    def test_opened_issue(self):
        issue = {
            "number": 10,
            "title": "Bug: login fails",
            "html_url": "https://github.com/OHACO-LABS/collab-memory/issues/10",
            "user": {"login": "pierre"},
        }
        node = _issue_to_node(issue, "opened", "tenant_2")
        assert node is not None
        assert node["type"] == "Task"
        assert "Issue #10" in node["label"]
        assert node["status"] == "open"

    def test_closed_issue(self):
        issue = {"number": 10, "title": "Bug", "user": {}}
        node = _issue_to_node(issue, "closed", "t1")
        assert node["status"] == "closed"

    def test_irrelevant_action(self):
        assert _issue_to_node({}, "edited", "t1") is None


# ── GitHub Commit conversion ──

class TestCommitToNode:
    def test_commit_to_exchange_record(self):
        commit = {
            "id": "abc123def456",
            "message": "fix: resolve auth bug\n\nMore details here",
            "author": {"username": "cc", "name": "Claude Code"},
            "url": "https://github.com/OHACO-LABS/collab-memory/commit/abc123",
        }
        push = {
            "repository": {"full_name": "OHACO-LABS/collab-memory"},
            "ref": "refs/heads/main",
        }
        node = _commit_to_node(commit, push, "tenant_1")
        assert node is not None
        assert node["type"] == "ExchangeRecord"
        assert "fix: resolve auth bug" in node["content"]
        assert node["created_by"] == "cc"
        assert node["metadata"]["github_branch"] == "main"
        assert node["metadata"]["github_sha"] == "abc123def456"

    def test_empty_message_returns_none(self):
        assert _commit_to_node({"message": "", "author": {}}, {}, "t1") is None


# ── GitHub Integration async methods ──

class TestGitHubIntegration:
    def test_name(self):
        g = GitHubIntegration()
        assert g.name == "github"

    def test_connect_no_token(self):
        g = GitHubIntegration()
        result = asyncio.get_event_loop().run_until_complete(g.connect("t1", {}))
        assert result.connected is False
        assert "No token" in (result.error or "")

    def test_sync_inbound_pr(self):
        g = GitHubIntegration()
        payload = {
            "action": "opened",
            "pull_request": {
                "number": 48,
                "title": "Sprint 48",
                "user": {"login": "esther"},
                "head": {"ref": "feat/sprint-48"},
            },
        }
        result = asyncio.get_event_loop().run_until_complete(g.sync_inbound("t1", payload))
        assert result.ok
        assert len(result.nodes_created) == 1
        assert result.nodes_created[0]["type"] == "Task"

    def test_sync_inbound_push(self):
        g = GitHubIntegration()
        payload = {
            "ref": "refs/heads/main",
            "repository": {"full_name": "OHACO-LABS/collab-memory"},
            "commits": [
                {"id": "abc123", "message": "fix: something", "author": {"username": "cc"}},
                {"id": "def456", "message": "docs: update", "author": {"name": "AG"}},
            ],
        }
        result = asyncio.get_event_loop().run_until_complete(g.sync_inbound("t1", payload))
        assert result.ok
        assert len(result.nodes_created) == 2
        assert result.nodes_created[0]["type"] == "ExchangeRecord"

    def test_sync_inbound_empty(self):
        g = GitHubIntegration()
        result = asyncio.get_event_loop().run_until_complete(g.sync_inbound("t1", {}))
        assert result.ok
        assert len(result.nodes_created) == 0
