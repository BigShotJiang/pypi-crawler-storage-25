"""Legacy tenant_id repair (default / empty) for JWT-backed users."""
from __future__ import annotations

import os
import uuid
from unittest.mock import MagicMock

import pytest

from collab_memory.auth.jwt_provider import JWTAuthProvider


@pytest.fixture
def jwt_secret(monkeypatch):
    monkeypatch.setenv("JWT_SECRET", "unit-test-jwt-secret-key-min-32-chars!!")


def test_ensure_noop_when_tenant_is_real_uuid(jwt_secret):
    neo = MagicMock()
    p = JWTAuthProvider(neo4j_backend=neo)
    tid = str(uuid.uuid4())
    u = {
        "email": "a@b.co",
        "user_id": "u1",
        "password_hash": "ph",
        "tenant_id": tid,
        "plan": "free",
        "role": "contributor",
        "tenant_name": "Acme",
    }
    out = p.ensure_valid_tenant_for_user({**u})
    assert out["tenant_id"] == tid
    neo.create_tenant.assert_not_called()


def test_ensure_replaces_default_and_creates_tenant(jwt_secret):
    neo = MagicMock()
    p = JWTAuthProvider(neo4j_backend=neo)
    u = {
        "email": "legacy@b.co",
        "user_id": "u2",
        "password_hash": "ph",
        "tenant_id": "default",
        "plan": "free",
        "role": "contributor",
        "tenant_name": "",
    }
    out = p.ensure_valid_tenant_for_user({**u})
    assert out["tenant_id"] != "default"
    uuid.UUID(out["tenant_id"])  # valid UUID
    neo.create_tenant.assert_called_once()
    neo._tx_write.assert_called()


def test_ensure_replaces_empty_tenant_id(jwt_secret):
    neo = MagicMock()
    p = JWTAuthProvider(neo4j_backend=neo)
    u = {
        "email": "empty@b.co",
        "user_id": "u3",
        "password_hash": "ph",
        "tenant_id": "",
        "plan": "free",
        "role": "contributor",
    }
    out = p.ensure_valid_tenant_for_user({**u})
    assert out["tenant_id"]
    assert out["tenant_id"] != "default"


def test_ensure_skipped_in_bypass_mode(monkeypatch):
    monkeypatch.delenv("JWT_SECRET", raising=False)
    p = JWTAuthProvider(neo4j_backend=None)
    u = {"email": "x@y.z", "user_id": "u", "tenant_id": "default"}
    assert p.ensure_valid_tenant_for_user(u) is u
    assert u["tenant_id"] == "default"


def test_ensure_persists_in_memory_when_no_neo4j(jwt_secret):
    p = JWTAuthProvider(neo4j_backend=None)
    u = {
        "email": "mem@b.co",
        "user_id": "u4",
        "password_hash": "ph",
        "tenant_id": "default",
        "plan": "free",
        "role": "contributor",
    }
    out = p.ensure_valid_tenant_for_user({**u})
    assert out["tenant_id"] != "default"
    stored = p._users.get("mem@b.co")
    assert stored is not None
    assert stored["tenant_id"] == out["tenant_id"]
