"""Project snapshot API + image preview behavior."""

from __future__ import annotations

import base64
from unittest.mock import MagicMock

import pytest
from starlette.testclient import TestClient


@pytest.fixture
def client() -> TestClient:
    from collab_memory.api.server import app

    return TestClient(app)


def _png_data_url() -> str:
    # 1x1 transparent PNG
    b64 = (
        "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8"
        "/w8AAn8B9BfB8QAAAABJRU5ErkJggg=="
    )
    return f"data:image/png;base64,{b64}"


def test_snapshot_create_list_latest(client: TestClient, monkeypatch: pytest.MonkeyPatch) -> None:
    from collab_memory.api import server

    store: dict[str, dict] = {}

    def save_artifact(artifact):
        store[artifact.id] = artifact.model_dump()

    def get_artifacts(project_id=None, artifact_type=None, session_id=None, limit=50, tenant_id="default"):
        rows = list(store.values())
        rows = [r for r in rows if r.get("tenant_id") == tenant_id]
        if project_id:
            rows = [r for r in rows if r.get("project_id") == project_id]
        if artifact_type:
            rows = [r for r in rows if r.get("artifact_type") == artifact_type]
        rows.sort(key=lambda x: x.get("updated_at", ""), reverse=True)
        return rows[:limit]

    def get_artifact(artifact_id):
        return store.get(artifact_id)

    fake_graph = MagicMock()
    fake_graph.save_artifact.side_effect = save_artifact
    fake_graph.get_artifacts.side_effect = get_artifacts
    fake_graph.get_artifact.side_effect = get_artifact

    monkeypatch.setattr(server, "graph", fake_graph)

    r_create = client.post(
        "/projects/prj_demo/snapshots",
        json={
            "session_id": "sess_1",
            "summary": "Baseline polished",
            "prompt": "Use neon cards and compact spacing",
            "screenshot_data_url": _png_data_url(),
            "state": {"project_tab": "overview"},
            "tags": ["manual-test"],
        },
    )
    assert r_create.status_code == 200
    created = r_create.json()
    assert created["ok"] is True
    assert created["project_id"] == "prj_demo"
    assert created["snapshot_id"]
    assert created["screenshot_artifact_id"]

    r_list = client.get("/projects/prj_demo/snapshots")
    assert r_list.status_code == 200
    listed = r_list.json()
    assert listed["count"] == 1
    snap = listed["snapshots"][0]
    assert snap["summary"] == "Baseline polished"
    assert snap["prompt"] == "Use neon cards and compact spacing"
    assert snap["screenshot_artifact_id"]

    r_latest = client.get("/projects/prj_demo/snapshots/latest")
    assert r_latest.status_code == 200
    latest = r_latest.json()["snapshot"]
    assert latest
    assert latest["id"] == snap["id"]


def test_snapshot_rejects_non_image_data_url(client: TestClient, monkeypatch: pytest.MonkeyPatch) -> None:
    from collab_memory.api import server

    fake_graph = MagicMock()
    monkeypatch.setattr(server, "graph", fake_graph)

    r = client.post(
        "/projects/prj_demo/snapshots",
        json={
            "summary": "bad",
            "screenshot_data_url": "data:text/plain;base64,SGVsbG8=",
        },
    )
    assert r.status_code == 400
    assert "data:image" in str(r.json().get("detail", ""))


def test_artifact_preview_image_decodes_data_url(client: TestClient, monkeypatch: pytest.MonkeyPatch) -> None:
    from collab_memory.api import server

    raw = base64.b64decode(_png_data_url().split(",", 1)[1])
    fake_graph = MagicMock()
    fake_graph.get_artifact.return_value = {
        "id": "art_img",
        "tenant_id": "local-dev",
        "artifact_type": "image",
        "mime_type": "image/png",
        "content": _png_data_url(),
    }
    monkeypatch.setattr(server, "graph", fake_graph)

    r = client.get("/artifacts/art_img/preview", headers={"X-API-Key": "demo-key"})
    assert r.status_code == 200
    assert r.headers.get("content-type", "").startswith("image/png")
    assert r.content == raw

