"""Duplicate handling tests for /auth/access-request."""

from starlette.testclient import TestClient


def _client() -> TestClient:
    from collab_memory.api.server import app

    return TestClient(app)


def test_access_request_duplicate_submission_reuses_pending_request_id() -> None:
    client = _client()
    payload = {
        "email": "dup-access@example.com",
        "full_name": "Dup Access",
        "tracks": ["launch_waitlist", "beta_tester"],
        "message": "duplicate path test",
    }
    first = client.post("/auth/access-request", json=payload)
    assert first.status_code == 200
    first_data = first.json()

    second = client.post("/auth/access-request", json=payload)
    assert second.status_code == 200
    second_data = second.json()

    assert second_data.get("duplicate") is True
    assert second_data.get("request_id") == first_data.get("request_id")
    assert second_data.get("next", {}).get("workflow_steps")
