"""
tests/test_integration_scoring.py — Integration tests for encoder → firewall pipeline

Verifies that realistic text inputs produce scores that land in the
correct firewall zone:
  >= 0.45  → PASS (encode directly)
  < 0.45   → QUEUE (HITL review)

Tests use skip_llm=True (keyword scoring only) to run offline.
"""
import asyncio
import importlib
import pytest

from collab_memory.encoder import _keyword_score, encode_exchange, WORTHINESS_THRESHOLD


# ── Keyword scorer: realistic inputs ─────────────────────────────────────────

class TestKeywordScoringRealistic:
    """Verify realistic text hits the right score bands."""

    # --- Single-type matches (expect 0.3 — below 0.45 floor, queued for HITL) ---

    def test_single_decision_scores_0_3(self):
        text = "We decided to use Neo4j for the graph layer."
        score = _keyword_score(text)
        assert score == pytest.approx(0.3, abs=0.05), f"Single decision match should score ~0.3, got {score}"

    def test_single_constraint_scores_0_3(self):
        text = "We must never expose internal API keys to the frontend."
        score = _keyword_score(text)
        assert score >= 0.3, f"Constraint should score >= 0.3, got {score}"

    def test_single_preference_scores_0_3(self):
        text = "I prefer to use TypeScript over JavaScript for new projects."
        score = _keyword_score(text)
        assert score >= 0.3, f"Preference should score >= 0.3, got {score}"

    def test_single_skill_scores_0_3(self):
        text = "Here's the workflow for deploying to Render."
        score = _keyword_score(text)
        assert score >= 0.3, f"Skill should score >= 0.3, got {score}"

    # --- Multi-type matches (expect >= 0.45 — passes firewall directly) ---

    def test_decision_plus_constraint_clears_floor(self):
        text = "We decided to use Neo4j and we must always filter by tenant_id."
        score = _keyword_score(text)
        assert score >= 0.45, f"Decision + constraint should clear 0.45 floor, got {score}"

    def test_preference_plus_constraint_clears_floor(self):
        text = "I prefer async handlers and we must never block the event loop."
        score = _keyword_score(text)
        assert score >= 0.45, f"Preference + constraint should clear 0.45 floor, got {score}"

    def test_decision_plus_abandon_clears_floor(self):
        text = "We decided to drop Supabase, it doesn't work for our use case."
        score = _keyword_score(text)
        assert score >= 0.45, f"Decision + abandon should clear 0.45 floor, got {score}"

    def test_skill_plus_constraint_clears_floor(self):
        text = "The steps to deploy require that you must set NEO4J_URI first."
        score = _keyword_score(text)
        assert score >= 0.45, f"Skill + constraint should clear 0.45 floor, got {score}"

    # --- Override (expect 0.4+ — single match clears threshold) ---

    def test_override_scores_high(self):
        text = "No, stop. Don't use Redis — actually switch to Neo4j."
        score = _keyword_score(text)
        assert score >= 0.4, f"Override should score >= 0.4, got {score}"

    # --- Low-signal (expect 0.0 or near-zero — should be dropped) ---

    def test_execution_only_scores_zero(self):
        text = "I added the new endpoint and updated the tests."
        score = _keyword_score(text)
        assert score == 0.0, f"Pure execution should score 0.0, got {score}"

    def test_casual_chat_scores_zero(self):
        text = "Sounds good, let me know when you're ready."
        score = _keyword_score(text)
        assert score == 0.0, f"Casual chat should score 0.0, got {score}"

    def test_question_scores_zero(self):
        text = "What do you think about using a message queue?"
        score = _keyword_score(text)
        assert score == 0.0, f"Open question should score 0.0, got {score}"


# ── Encoder → Firewall: end-to-end with keyword mode ────────────────────────

class TestEncoderFirewallPipeline:
    """Test that encode_exchange produces scores that interact correctly
    with the firewall's CONFIDENCE_FLOOR of 0.45."""

    def _reload_firewall(self):
        import collab_memory.firewall as fw
        importlib.reload(fw)
        return fw

    def test_multi_signal_text_passes_firewall(self):
        """Text with decision + constraint should encode AND pass firewall."""
        text = "We decided to use argon2 for hashing — we must never store plaintext passwords."
        result = encode_exchange(text, session_id="test_session", turn_start=0, skip_llm=True)

        fw = self._reload_firewall()
        assert fw.CONFIDENCE_FLOOR == 0.45, f"CONFIDENCE_FLOOR should be 0.45, got {fw.CONFIDENCE_FLOOR}"

        # The keyword score for this multi-signal text should clear the floor
        score = _keyword_score(text)
        assert score >= 0.45, f"Multi-signal text should score >= 0.45, got {score}"

        firewall_result = fw.layer5_confidence_gate(score, "contributor")
        assert firewall_result.action == fw.FirewallAction.PASS, \
            f"Score {score} >= 0.45 should PASS firewall, got {firewall_result.action}"

    def test_single_signal_text_queued_by_firewall(self):
        """Text with only one signal type (0.3) should be queued for HITL."""
        text = "I prefer dark mode for the dashboard UI."
        result = encode_exchange(text, session_id="test_session", turn_start=0, skip_llm=True)

        fw = self._reload_firewall()
        score = _keyword_score(text)
        firewall_result = fw.layer5_confidence_gate(score, "contributor")

        assert firewall_result.action == fw.FirewallAction.QUEUE, \
            f"Single-signal text (score={score}) should be QUEUED, got {firewall_result.action}"

    def test_execution_text_dropped(self):
        """Pure execution text should score 0.0 and not encode."""
        text = "Done. I updated the README and fixed the typo."
        score = _keyword_score(text)
        assert score == 0.0, f"Execution text should score 0.0, got {score}"

    def test_firewall_floor_is_correct(self):
        """Sanity check: CONFIDENCE_FLOOR is 0.45, not the broken 0.15."""
        fw = self._reload_firewall()
        assert fw.CONFIDENCE_FLOOR == 0.45, \
            f"CONFIDENCE_FLOOR regression: expected 0.45, got {fw.CONFIDENCE_FLOOR}"


# ── Full chain: realistic FirewallChain run ──────────────────────────────────

class TestFullChainIntegration:
    """Run FirewallChain.run() with realistic inputs end-to-end."""

    def _run_chain(self, text, role, confidence):
        import collab_memory.firewall as fw
        importlib.reload(fw)
        fw._SEED_EMBEDDINGS = []  # skip L2 seed loading
        chain = fw.FirewallChain()
        return asyncio.get_event_loop().run_until_complete(
            chain.run(text, [], role, confidence)
        ), fw

    def test_high_confidence_contributor_passes(self):
        result, fw = self._run_chain(
            "We decided to use Neo4j AuraDB and must always scope queries by tenant_id.",
            "contributor", 0.6
        )
        assert result.action == fw.FirewallAction.PASS

    def test_low_confidence_contributor_queued(self):
        result, fw = self._run_chain(
            "Maybe we should consider using GraphQL?",
            "contributor", 0.2
        )
        assert result.action == fw.FirewallAction.QUEUE
        assert result.layer == 5

    def test_admin_with_low_confidence_queued(self):
        """Even admin gets queued when confidence is below floor."""
        result, fw = self._run_chain(
            "Some random thought about architecture.",
            "admin", 0.1
        )
        assert result.action == fw.FirewallAction.QUEUE

    def test_reader_always_queued_regardless_of_confidence(self):
        result, fw = self._run_chain(
            "We decided to use Kubernetes for orchestration.",
            "reader", 0.95
        )
        assert result.action == fw.FirewallAction.QUEUE
