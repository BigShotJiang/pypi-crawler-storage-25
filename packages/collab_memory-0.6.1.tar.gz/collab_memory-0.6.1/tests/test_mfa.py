"""
tests/test_mfa.py — TOTP MFA unit tests.

Tests the MFA module without hitting real authenticator apps.
Validates secret generation, TOTP verification, recovery codes,
and the MFAManager enrollment/verification flow.
"""
import pytest
from unittest.mock import MagicMock, patch


class TestTOTPFunctions:
    """Test standalone TOTP functions."""

    def test_generate_secret(self):
        from collab_memory.auth.mfa import generate_totp_secret
        secret = generate_totp_secret()
        assert len(secret) == 32  # base32 encoded, 160 bits
        # Should be valid base32
        import base64
        base64.b32decode(secret)

    def test_provisioning_uri(self):
        from collab_memory.auth.mfa import generate_totp_secret, get_provisioning_uri
        secret = generate_totp_secret()
        uri = get_provisioning_uri(secret, "test@example.com")
        assert uri.startswith("otpauth://totp/")
        assert "test%40example.com" in uri or "test@example.com" in uri
        assert "OHACO" in uri
        assert secret in uri

    def test_verify_valid_code(self):
        import pyotp
        from collab_memory.auth.mfa import verify_totp
        secret = pyotp.random_base32()
        totp = pyotp.TOTP(secret)
        code = totp.now()
        assert verify_totp(secret, code) is True

    def test_verify_invalid_code(self):
        from collab_memory.auth.mfa import generate_totp_secret, verify_totp
        secret = generate_totp_secret()
        assert verify_totp(secret, "000000") is False

    def test_generate_recovery_codes(self):
        from collab_memory.auth.mfa import generate_recovery_codes
        codes = generate_recovery_codes(8)
        assert len(codes) == 8
        assert all(len(c) == 8 for c in codes)
        # All unique
        assert len(set(codes)) == 8
        # All hex uppercase
        assert all(c == c.upper() for c in codes)

    def test_mfa_available(self):
        from collab_memory.auth.mfa import is_mfa_available
        assert is_mfa_available() is True


class TestMFAManager:
    """Test MFAManager with mocked Neo4j."""

    def test_setup_returns_secret_and_uri(self):
        from collab_memory.auth.mfa import MFAManager
        mock_neo4j = MagicMock()
        mock_neo4j._tx_read.return_value = []
        mgr = MFAManager(neo4j_backend=mock_neo4j)

        result = mgr.setup("test@example.com")
        assert "secret" in result
        assert "provisioning_uri" in result
        assert "recovery_codes" in result
        assert len(result["recovery_codes"]) == 8
        assert result["provisioning_uri"].startswith("otpauth://")

    def test_setup_stores_pending_secret(self):
        from collab_memory.auth.mfa import MFAManager
        mock_neo4j = MagicMock()
        mgr = MFAManager(neo4j_backend=mock_neo4j)

        mgr.setup("test@example.com")
        mock_neo4j._tx_write.assert_called_once()
        call_args = mock_neo4j._tx_write.call_args
        assert "mfa_pending_secret" in call_args[0][0]

    def test_verify_and_enable_with_valid_code(self):
        import pyotp
        from collab_memory.auth.mfa import MFAManager

        secret = pyotp.random_base32()
        code = pyotp.TOTP(secret).now()

        mock_neo4j = MagicMock()
        mock_neo4j._tx_read.return_value = [{"secret": secret}]
        mgr = MFAManager(neo4j_backend=mock_neo4j)

        result = mgr.verify_and_enable("test@example.com", code)
        assert result.get("ok") is True
        # Should have written mfa_enabled=true
        write_call = mock_neo4j._tx_write.call_args
        assert "mfa_enabled = true" in write_call[0][0]

    def test_verify_and_enable_with_invalid_code(self):
        import pyotp
        from collab_memory.auth.mfa import MFAManager

        secret = pyotp.random_base32()
        mock_neo4j = MagicMock()
        mock_neo4j._tx_read.return_value = [{"secret": secret}]
        mgr = MFAManager(neo4j_backend=mock_neo4j)

        result = mgr.verify_and_enable("test@example.com", "000000")
        assert "error" in result

    def test_verify_without_pending_setup(self):
        from collab_memory.auth.mfa import MFAManager
        mock_neo4j = MagicMock()
        mock_neo4j._tx_read.return_value = []
        mgr = MFAManager(neo4j_backend=mock_neo4j)

        result = mgr.verify_and_enable("test@example.com", "123456")
        assert "error" in result
        assert "setup" in result["error"].lower()

    def test_is_enabled_true(self):
        from collab_memory.auth.mfa import MFAManager
        mock_neo4j = MagicMock()
        mock_neo4j._tx_read.return_value = [{"enabled": True}]
        mgr = MFAManager(neo4j_backend=mock_neo4j)
        assert mgr.is_enabled("test@example.com") is True

    def test_is_enabled_false(self):
        from collab_memory.auth.mfa import MFAManager
        mock_neo4j = MagicMock()
        mock_neo4j._tx_read.return_value = [{"enabled": False}]
        mgr = MFAManager(neo4j_backend=mock_neo4j)
        assert mgr.is_enabled("test@example.com") is False

    def test_is_enabled_no_user(self):
        from collab_memory.auth.mfa import MFAManager
        mock_neo4j = MagicMock()
        mock_neo4j._tx_read.return_value = []
        mgr = MFAManager(neo4j_backend=mock_neo4j)
        assert mgr.is_enabled("nonexistent@example.com") is False

    def test_check_totp_valid(self):
        import pyotp
        from collab_memory.auth.mfa import MFAManager

        secret = pyotp.random_base32()
        code = pyotp.TOTP(secret).now()

        mock_neo4j = MagicMock()
        mock_neo4j._tx_read.return_value = [{"secret": secret}]
        mgr = MFAManager(neo4j_backend=mock_neo4j)
        assert mgr.check_totp("test@example.com", code) is True

    def test_disable_removes_mfa_fields(self):
        from collab_memory.auth.mfa import MFAManager
        mock_neo4j = MagicMock()
        mgr = MFAManager(neo4j_backend=mock_neo4j)

        result = mgr.disable("test@example.com")
        assert result.get("ok") is True
        write_call = mock_neo4j._tx_write.call_args
        assert "mfa_enabled = false" in write_call[0][0]
        assert "REMOVE" in write_call[0][0]

    def test_setup_without_neo4j(self):
        from collab_memory.auth.mfa import MFAManager
        mgr = MFAManager(neo4j_backend=None)
        result = mgr.setup("test@example.com")
        # Should still return secret and URI even without storage
        assert "secret" in result
        assert "provisioning_uri" in result
