from starlette.testclient import TestClient


class _PipelineCapture:
    def __init__(self):
        self.last_state = None

    def __call__(self, state):
        self.last_state = state
        return {
            "exchange_record_id": "ex_test",
            "primitive_type": "DecisionClose",
            "final_score": 0.9,
            "nodes_generated": [],
        }


def test_memory_ingest_passes_project_and_tenant_to_pipeline(monkeypatch):
    from collab_memory.abac import AgentContext
    from collab_memory.api import server as srv

    capture = _PipelineCapture()
    monkeypatch.setattr(srv, "_pipeline", capture)
    monkeypatch.setattr(srv, "_context_cache_invalidate", lambda: None)
    monkeypatch.setattr(srv, "_API_KEY", "test_key")
    monkeypatch.setattr(srv, "_VALID_API_KEYS", {"test_key"})

    # Keep firewall path simple and deterministic for this endpoint test.
    class _AllowResult:
        action = "pass"
        layer = 0
        reason = ""
        detail = {}

    async def _allow_run(**kwargs):
        return _AllowResult()

    import collab_memory.firewall as fw_mod
    monkeypatch.setattr(fw_mod.firewall, "run", _allow_run)
    def _resolve_agent_context(_key, graph=None):
        return AgentContext(
            role="contributor",
            agent_id="agent_ingest",
            key="test_key",
            tenant_id="tenant_test_ingest",
            plan="pro",
        )

    monkeypatch.setattr(srv, "resolve_agent_context", _resolve_agent_context)

    client = TestClient(srv.app)
    resp = client.post(
        "/memory/ingest",
        headers={"X-API-Key": "test_key"},
        json={
            "raw_text": "Decision: use strict project scoping",
            "session_id": "sess_ingest",
            "project_id": "prj_ingest_scope",
        },
    )
    assert resp.status_code == 202
    assert capture.last_state is not None
    assert capture.last_state.get("project_id") == "prj_ingest_scope"
    assert capture.last_state.get("tenant_id") == "tenant_test_ingest"
