"""
Graphiti Sprint — Gate 1: Validation Tests
==========================================
Tests that graphiti-core >= 0.28.2 is installed,
the Cypher injection fix (CVE-2026-32247) is present,
and group_id isolation works correctly.

These tests validate the library itself, not our backend wrapper.
They run without a live Neo4j/FalkorDB instance where possible.
"""
import importlib
import re
import pytest


# ─── Test 1: Version Pin ─────────────────────────────────────────────────────

def test_graphiti_core_importable():
    """graphiti-core must be importable."""
    try:
        import graphiti_core
        assert graphiti_core is not None
    except ImportError:
        pytest.skip("graphiti-core not installed in this environment — install with: pip install 'collab-memory[graphiti]'")


def test_graphiti_core_version_minimum():
    """graphiti-core version must be >= 0.28.2 (CVE-2026-32247 fix)."""
    try:
        import graphiti_core
    except ImportError:
        pytest.skip("graphiti-core not installed")

    version = getattr(graphiti_core, "__version__", None)
    if version is None:
        # Try importlib.metadata
        try:
            from importlib.metadata import version as get_version
            version = get_version("graphiti-core")
        except Exception:
            pytest.skip("Cannot determine graphiti-core version")

    # Parse version
    parts = version.split(".")
    major, minor, patch = int(parts[0]), int(parts[1]), int(re.match(r"(\d+)", parts[2]).group(1))

    assert (major, minor, patch) >= (0, 28, 2), (
        f"graphiti-core {version} is vulnerable to CVE-2026-32247 (Cypher injection). "
        f"Minimum required: 0.28.2"
    )


# ─── Test 2: Cypher Injection Fix Validation ─────────────────────────────────

def test_search_filters_sanitize_node_labels():
    """
    CVE-2026-32247: node_labels were concatenated directly into Cypher queries.
    In >= 0.28.2, SearchFilters should sanitize or reject malicious labels.
    """
    try:
        from graphiti_core.search.search_filters import SearchFilters
    except ImportError:
        pytest.skip("graphiti-core not installed or SearchFilters not available")

    # Attempt to create SearchFilters with a malicious node_label
    # containing Cypher injection payload
    malicious_label = "Entity` RETURN n UNION MATCH (m) RETURN m //"

    try:
        sf = SearchFilters(node_labels=[malicious_label])
        # If it creates without error, check that the label is sanitized
        # The fix should either reject or sanitize the input
        if hasattr(sf, 'node_labels') and sf.node_labels:
            for label in sf.node_labels:
                # The sanitized label should not contain backticks or injection patterns
                assert "`" not in label or label == malicious_label.replace("`", ""), (
                    f"SearchFilters did not sanitize Cypher injection in node_labels: {label}"
                )
    except (ValueError, TypeError) as e:
        # Good — the fix rejects malicious input
        pass


# ─── Test 3: group_id Isolation Logic ────────────────────────────────────────

def test_graphiti_backend_group_id_default():
    """GraphitiBackend should default to 'collab_memory' group_id."""
    try:
        from collab_memory.graph.graphiti_backend import GraphitiBackend
    except ImportError:
        pytest.skip("collab_memory not importable")

    # We can't instantiate without a live DB, but we can check the class signature
    import inspect
    sig = inspect.signature(GraphitiBackend.__init__)
    params = sig.parameters

    assert "group_id" in params, "GraphitiBackend.__init__ must accept group_id parameter"
    default = params["group_id"].default
    assert default == "collab_memory", f"Default group_id should be 'collab_memory', got '{default}'"


def test_graphiti_backend_search_uses_group_id():
    """_search method must scope queries by group_id / project_id."""
    try:
        from collab_memory.graph.graphiti_backend import GraphitiBackend
    except ImportError:
        pytest.skip("collab_memory not importable")

    import inspect
    source = inspect.getsource(GraphitiBackend._search)

    # Verify group_ids is passed to the search call
    assert "group_ids" in source, (
        "_search must pass group_ids to Graphiti search for tenant isolation"
    )
    assert "project_id" in source, (
        "_search must accept project_id parameter for per-project scoping"
    )


def test_graphiti_backend_write_uses_group_id():
    """Write methods (save_decision, save_constraint, etc.) must pass group_id."""
    try:
        from collab_memory.graph.graphiti_backend import GraphitiBackend
    except ImportError:
        pytest.skip("collab_memory not importable")

    import inspect

    # Check that save methods include group_id in their add_episode calls
    for method_name in ["save_decision", "save_constraint", "save_preference", "save_attempt"]:
        method = getattr(GraphitiBackend, method_name, None)
        if method is None:
            continue
        source = inspect.getsource(method)
        assert "group_id" in source, (
            f"{method_name} must pass group_id to add_episode for tenant isolation"
        )


def test_graphiti_backend_project_scoping():
    """save_project should use project.id as group_id for namespace isolation."""
    try:
        from collab_memory.graph.graphiti_backend import GraphitiBackend
    except ImportError:
        pytest.skip("collab_memory not importable")

    import inspect
    source = inspect.getsource(GraphitiBackend.save_project)

    assert "group_id=project.id" in source.replace(" ", "").replace("\n", ""), (
        "save_project must use project.id as group_id for proper namespace isolation"
    )


# ─── Test 4: pyproject.toml Version Pin ──────────────────────────────────────

def test_pyproject_pins_minimum_version():
    """pyproject.toml must pin graphiti-core >= 0.28.2."""
    import pathlib

    # Find pyproject.toml relative to test location
    test_dir = pathlib.Path(__file__).parent
    pyproject = test_dir.parent / "pyproject.toml"

    if not pyproject.exists():
        pytest.skip("pyproject.toml not found")

    content = pyproject.read_text()

    # Find the graphiti-core version constraint
    match = re.search(r'"graphiti-core>=([\d.]+)"', content)
    assert match, "pyproject.toml must contain a graphiti-core version pin"

    pinned_version = match.group(1)
    parts = pinned_version.split(".")
    major, minor, patch = int(parts[0]), int(parts[1]), int(parts[2])

    assert (major, minor, patch) >= (0, 28, 2), (
        f"pyproject.toml pins graphiti-core>={pinned_version} but minimum must be >=0.28.2 "
        f"for CVE-2026-32247 fix"
    )
