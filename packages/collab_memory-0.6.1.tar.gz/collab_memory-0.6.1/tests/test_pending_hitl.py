"""HITL pending queue: LocalGraphBackend save_pending / get_pending / confirm / reject."""

from __future__ import annotations

import pytest

from src.collab_memory.graph.local import LocalGraphBackend
from src.collab_memory.schema import Decision, DecisionStatus


@pytest.fixture
def graph(tmp_path):
    return LocalGraphBackend(path=str(tmp_path / "hitl.json"))


def test_save_pending_then_get_pending(graph):
    d = Decision(
        description="Inferred choice from pipeline",
        made_in="sess_1",
        confidence=0.55,
        status=DecisionStatus.active,
        project_id=None,
    )
    pid = graph.save_pending(d)
    assert pid.startswith("pnd_")
    items = graph.get_pending()
    assert len(items) == 1
    assert items[0]["id"] == pid
    assert items[0]["node_type"] == "Decision"
    assert items[0]["status"] == "pending"


def test_confirm_pending_writes_decision(graph):
    d = Decision(description="To confirm", made_in="s2", confidence=0.5, status=DecisionStatus.active)
    pid = graph.save_pending(d)
    out = graph.confirm_pending_inference(pid)
    assert out["ok"] is True
    assert graph.get_pending() == []
    decisions = graph.get_decisions()
    assert len(decisions) == 1
    assert decisions[0].description == "To confirm"


def test_reject_pending_no_decision(graph):
    d = Decision(description="Drop me", made_in="s3", confidence=0.5, status=DecisionStatus.active)
    pid = graph.save_pending(d)
    out = graph.reject_pending_inference(pid)
    assert out["ok"] is True
    assert graph.get_decisions() == []
    stored = graph._data["pending_inferences"][pid]
    assert stored["status"] == "rejected"
