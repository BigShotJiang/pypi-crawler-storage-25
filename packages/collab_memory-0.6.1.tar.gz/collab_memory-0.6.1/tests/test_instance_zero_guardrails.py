"""Regression guards for instance-0 tenant resolution safety."""

from __future__ import annotations

from pathlib import Path


def _server_source() -> str:
    return Path("src/collab_memory/api/server.py").read_text(encoding="utf-8")


def test_local_dev_fallback_requires_primary_key_and_non_production() -> None:
    src = _server_source()

    assert src.count("and key == _API_KEY") == 2
    assert src.count('and (not agent.tenant_id or agent.tenant_id == "default")') == 3


def test_local_dev_fallback_does_not_use_valid_key_membership() -> None:
    src = _server_source()
    assert '(not agent.tenant_id or agent.tenant_id == "default") and key in _VALID_API_KEYS' not in src
