"""
Tests for Clerk JWT verification and role mapping.

These tests run without a real Clerk account — they verify:
1. Role mapping from Clerk org roles to OHACO ABAC roles
2. is_clerk_enabled() env var behavior
3. Token verification error handling (expired, malformed, missing kid)
4. ClerkUser dataclass structure
"""

import os
import unittest
from unittest.mock import patch, MagicMock

from collab_memory.auth.clerk_provider import (
    ClerkUser,
    _map_org_role,
    is_clerk_enabled,
    verify_clerk_token,
)


class TestRoleMapping(unittest.TestCase):
    """Clerk org roles → OHACO ABAC roles."""

    def test_admin_maps(self):
        assert _map_org_role("org:admin") == "admin"

    def test_member_maps_to_contributor(self):
        assert _map_org_role("org:member") == "contributor"

    def test_viewer_maps_to_reader(self):
        assert _map_org_role("org:viewer") == "reader"

    def test_unknown_defaults_to_reader(self):
        assert _map_org_role("org:custom_weird") == "reader"

    def test_short_form_admin(self):
        assert _map_org_role("admin") == "admin"

    def test_short_form_member(self):
        assert _map_org_role("member") == "contributor"


class TestIsClerkEnabled(unittest.TestCase):
    """is_clerk_enabled() checks env vars."""

    @patch.dict(os.environ, {"AUTH_PROVIDER": "clerk", "CLERK_DOMAIN": "test.clerk.accounts.dev"})
    def test_enabled_when_both_set(self):
        assert is_clerk_enabled() is True

    @patch.dict(os.environ, {"AUTH_PROVIDER": "jwt", "CLERK_DOMAIN": "test.clerk.accounts.dev"})
    def test_disabled_when_provider_not_clerk(self):
        assert is_clerk_enabled() is False

    @patch.dict(os.environ, {"AUTH_PROVIDER": "clerk"}, clear=False)
    def test_disabled_when_no_domain(self):
        env = os.environ.copy()
        env.pop("CLERK_DOMAIN", None)
        with patch.dict(os.environ, env, clear=True):
            # No CLERK_DOMAIN and no CLERK_PUBLISHABLE_KEY
            assert is_clerk_enabled() is False

    @patch.dict(os.environ, {}, clear=True)
    def test_disabled_when_no_env(self):
        assert is_clerk_enabled() is False


class TestVerifyClerkToken(unittest.TestCase):
    """verify_clerk_token error handling."""

    def test_returns_none_for_empty_string(self):
        # Should not crash — just return None
        result = verify_clerk_token("")
        assert result is None

    def test_returns_none_for_garbage(self):
        result = verify_clerk_token("not.a.jwt")
        assert result is None

    def test_returns_none_for_none_like_input(self):
        result = verify_clerk_token("null")
        assert result is None

    @patch("collab_memory.auth.clerk_provider._fetch_jwks")
    def test_returns_none_when_kid_not_found(self, mock_jwks):
        """Token has kid=abc but JWKS has no matching key."""
        mock_jwks.return_value = {"keys": [{"kid": "xyz", "kty": "RSA"}]}

        # Minimal JWT with kid=abc in header
        import base64, json
        header = base64.urlsafe_b64encode(json.dumps({"alg": "RS256", "kid": "abc"}).encode()).decode().rstrip("=")
        payload = base64.urlsafe_b64encode(json.dumps({"sub": "user_123"}).encode()).decode().rstrip("=")
        fake_token = f"{header}.{payload}.fakesig"

        result = verify_clerk_token(fake_token)
        assert result is None


class TestClerkUserDataclass(unittest.TestCase):
    """ClerkUser structure."""

    def test_fields(self):
        u = ClerkUser(
            user_id="user_abc",
            email="test@ohaco.com",
            tenant_id="org_xyz",
            role="admin",
            plan="pro",
            raw_claims={"sub": "user_abc"},
        )
        assert u.user_id == "user_abc"
        assert u.email == "test@ohaco.com"
        assert u.tenant_id == "org_xyz"
        assert u.role == "admin"
        assert u.plan == "pro"

    def test_optional_tenant(self):
        u = ClerkUser(
            user_id="user_abc",
            email="",
            tenant_id=None,
            role="reader",
            plan="pro",
            raw_claims={},
        )
        assert u.tenant_id is None


if __name__ == "__main__":
    unittest.main()
