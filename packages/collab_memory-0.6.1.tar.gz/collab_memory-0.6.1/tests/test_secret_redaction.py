"""Tests for Layer 0.5 — secret redaction in sanitization.py."""
import pytest
from collab_memory.sanitization import redact_secrets


# ── API key patterns ──

@pytest.mark.parametrize("key,label", [
    ("sk-ant-api03-ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "Anthropic"),
    ("sk-proj-ABCDEFGHIJKLMNOP1234567890abcdef", "OpenAI project"),
    ("sk-ABCDEFGHIJKLMNOP1234567890", "OpenAI legacy"),
    ("re_A1B2C3D4E5F6G7H8I9J0K1L2M3N4O5", "Resend"),
    ("rnd_ABCDEFGHIJKLMNOP1234567890", "Render"),
    ("cmk_ABC123_DEF456_GHI789_JKL0", "collab-memory"),
    ("AIzaSyABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", "Google"),
    ("lsv2_sk_ABCDEFGHIJKLMNOP1234567890", "LangSmith"),
    ("sk_live_ABCDEFGHIJKLMNOP1234567890", "Stripe live"),
    ("pk_test_ABCDEFGHIJKLMNOP1234567890", "Stripe test"),
    ("ghp_ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefgh", "GitHub PAT"),
    ("ghs_ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefgh", "GitHub server"),
    ("AKIAIOSFODNN7EXAMPLE", "AWS access key"),
    ("xoxb-123456789012-ABCDEFGHIJKLMNOP", "Slack bot"),
    ("SG.abcdefghijklmnopqrstuv.ABCDEFGHIJKLMNOPQRSTUVWXYZ", "Sendgrid"),
    ("dp.st.ABCDEFGHIJKLMNOP1234567890", "Doppler"),
])
def test_redacts_api_keys(key, label):
    text = f"The key is {key} and it works"
    redacted, types = redact_secrets(text)
    assert key not in redacted, f"Failed to redact {label} key"
    assert "[REDACTED:" in redacted
    assert len(types) >= 1


# ── JWTs ──

def test_redacts_jwt():
    jwt = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.dozjgNryP4J3jVmNHl0w5N_XgL0n3I9PlFUP0THsR8U"
    text = f"Token: {jwt}"
    redacted, types = redact_secrets(text)
    assert "eyJ" not in redacted
    assert "jwt" in types


# ── Connection strings ──

@pytest.mark.parametrize("conn", [
    "neo4j+s://user:pass@host.databases.neo4j.io",
    "postgresql://admin:secret@db.render.com:5432/mydb",
    "mongodb+srv://user:pass@cluster.mongodb.net",
    "mysql://root:password@localhost/dbname",
    "redis://default:abc123@redis-host:6379",
    "amqps://guest:guest@rabbitmq.example.com",
])
def test_redacts_connection_strings(conn):
    text = f"Connect to {conn} for data"
    redacted, types = redact_secrets(text)
    assert conn not in redacted
    assert "connection_string" in types


# ── Bearer tokens ──

def test_redacts_bearer_token():
    text = "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.abc.def"
    redacted, types = redact_secrets(text)
    assert "Bearer" not in redacted or "[REDACTED:" in redacted


# ── Private keys ──

def test_redacts_private_key_header():
    text = "-----BEGIN RSA PRIVATE KEY-----\nMIIE..."
    redacted, types = redact_secrets(text)
    assert "PRIVATE KEY" not in redacted
    assert "private_key" in types


def test_redacts_openssh_key():
    text = "-----BEGIN OPENSSH PRIVATE KEY-----\nb3Blbn..."
    redacted, types = redact_secrets(text)
    assert "PRIVATE KEY" not in redacted


# ── Env var assignments ──

@pytest.mark.parametrize("line", [
    "PASSWORD=mysupersecretpassword123",
    "API_KEY: sk-something-long-here-1234",
    "CLIENT_SECRET=abcdefghijklmnop",
    "ACCESS_KEY=AKIAIOSFODNN7EXAMPLE",
])
def test_redacts_env_assignments(line):
    text = f"Set {line} in your env"
    redacted, types = redact_secrets(text)
    assert "env_secret" in types


# ── Hex secrets ──

def test_redacts_long_hex_strings():
    hex_str = "a" * 40
    text = f"The hash is {hex_str} computed yesterday"
    redacted, types = redact_secrets(text)
    assert hex_str not in redacted
    assert "hex_secret" in types


# ── Safe text passes through ──

@pytest.mark.parametrize("safe", [
    "We decided to use React for the frontend",
    "The API returns JSON with status 200",
    "Deploy to Render using the dashboard",
    "The project has 42 nodes in the graph",
    "sk-short",  # Too short to match
])
def test_safe_text_passes_through(safe):
    redacted, types = redact_secrets(safe)
    assert redacted == safe
    assert types == []


# ── Multiple secrets in one text ──

def test_multiple_secrets():
    text = (
        "Use sk-ant-api03-AAAAAAAAAAAAAAAAAAAAAA for auth "
        "and connect to neo4j+s://user:pass@db.neo4j.io"
    )
    redacted, types = redact_secrets(text)
    assert "sk-ant" not in redacted
    assert "neo4j+s://" not in redacted
    assert len(types) >= 2


# ── Empty/None ──

def test_empty_string():
    redacted, types = redact_secrets("")
    assert redacted == ""
    assert types == []
