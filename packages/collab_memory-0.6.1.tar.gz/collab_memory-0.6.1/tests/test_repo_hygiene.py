from __future__ import annotations

from pathlib import Path


def test_gitignore_has_no_markdown_code_fences():
    """
    Guard against accidental .gitignore corruption (e.g. markdown fenced blocks).
    A prior pending PR snapshot contained triple-backtick fences, which break gitignore.
    """
    content = Path(".gitignore").read_text(encoding="utf-8")
    assert "```" not in content, ".gitignore must not contain markdown code fences"

