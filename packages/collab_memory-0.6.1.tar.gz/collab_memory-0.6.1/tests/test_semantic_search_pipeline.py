"""
Semantic search pipeline — embeddings, API contract, tenant scoping.

Runs without live Neo4j or LLM keys (ngram embedding fallback).
Production verification: use scripts/seed_fixture_project.py + docs/FIXTURE-PROJECT-SEMANTIC.md.
"""
from __future__ import annotations

from unittest.mock import MagicMock

import pytest
from starlette.testclient import TestClient


class TestEmbeddingFallback:
    """generate_embedding must never return empty for real text (ngram path)."""

    def test_ngram_embedding_non_empty_without_api_keys(self, monkeypatch):
        monkeypatch.delenv("GOOGLE_API_KEY", raising=False)
        monkeypatch.delenv("GEMINI_API_KEY", raising=False)
        monkeypatch.delenv("OPENAI_API_KEY", raising=False)

        from collab_memory.embeddings import generate_embedding

        vec = generate_embedding("fixture semantic violet penguin 99")
        assert isinstance(vec, list)
        assert len(vec) == 128  # _ngram_vector default dims
        assert any(abs(x) > 1e-9 for x in vec)

    def test_empty_text_returns_empty(self):
        from collab_memory.embeddings import generate_embedding

        assert generate_embedding("") == []
        assert generate_embedding("   ") == []


class TestMemorySearchEndpoint:
    """GET/POST /memory/search → graph.semantic_search with request tenant."""

    @pytest.fixture
    def client_and_capture(self, monkeypatch):
        from collab_memory.abac import AgentContext
        from collab_memory.api import server as srv

        captured: dict = {}

        class _GraphWithSearch:
            def semantic_search(self, **kwargs):
                captured.clear()
                captured.update(kwargs)
                return [
                    {
                        "id": "dec_fixture_1",
                        "node_type": "Decision",
                        "description": "Fixture: violet penguin baseline for semantic QA",
                        "confidence": 0.95,
                        "relevance_score": 0.91,
                        "project_id": "prj_fixture_semantic_lab",
                        "rationale": "",
                        "created_at": "",
                        "last_confirmed": "",
                    }
                ]

        monkeypatch.setattr(srv, "graph", _GraphWithSearch())
        monkeypatch.setattr(srv, "_API_KEY", "test_fixture_key")
        monkeypatch.setattr(srv, "_VALID_API_KEYS", {"test_fixture_key"})

        def fake_resolve(key, graph=None):
            return AgentContext(
                role="contributor",
                agent_id="fixture_agent",
                key=key or "",
                tenant_id="tnt_fixture_semantic_lab",
                plan="free",
            )

        monkeypatch.setattr(srv, "resolve_agent_context", fake_resolve)

        return TestClient(srv.app), captured

    def test_get_search_requires_query(self, client_and_capture):
        client, _ = client_and_capture
        r = client.get(
            "/memory/search",
            headers={"X-API-Key": "test_fixture_key"},
        )
        assert r.status_code == 422

    def test_get_search_passes_tenant_and_query(self, client_and_capture):
        client, cap = client_and_capture
        r = client.get(
            "/memory/search",
            params={"q": "violet penguin", "project_id": "prj_fixture_semantic_lab", "limit": 5},
            headers={"X-API-Key": "test_fixture_key"},
        )
        assert r.status_code == 200
        data = r.json()
        assert data["count"] >= 1
        assert "results" in data
        assert cap.get("tenant_id") == "tnt_fixture_semantic_lab"
        assert cap.get("query") == "violet penguin"
        assert cap.get("project_id") == "prj_fixture_semantic_lab"

    def test_post_search_json_body(self, client_and_capture):
        client, cap = client_and_capture
        r = client.post(
            "/memory/search",
            headers={"X-API-Key": "test_fixture_key", "Content-Type": "application/json"},
            json={"q": "semantic QA", "limit": 3, "project_id": "prj_fixture_semantic_lab"},
        )
        assert r.status_code == 200
        assert cap.get("query") == "semantic QA"


class TestNeo4jSemanticSearchContract:
    """Neo4jBackend.semantic_search delegates to HNSW then BM25 (smoke with mock)."""

    def test_semantic_search_empty_query_returns_empty(self):
        from collab_memory.graph.neo4j_backend import Neo4jBackend

        b = Neo4jBackend.__new__(Neo4jBackend)
        b._tx_read = MagicMock()
        b._tx_write = MagicMock()
        assert Neo4jBackend.semantic_search(b, query="  ", tenant_id="t1") == []

    def test_bm25_path_called_when_hnsw_raises(self, monkeypatch):
        from collab_memory.graph.neo4j_backend import Neo4jBackend

        b = Neo4jBackend.__new__(Neo4jBackend)
        b._tx_read = MagicMock(return_value=[])

        def boom(*_a, **_k):
            raise RuntimeError("index missing")

        monkeypatch.setattr("collab_memory.embeddings.generate_embedding", boom)
        bm25 = MagicMock(return_value=[{"id": "x", "relevance_score": 0.5}])
        monkeypatch.setattr(b, "_bm25_search", bm25)

        out = Neo4jBackend.semantic_search(
            b,
            query="hello world test",
            tenant_id="tnt_x",
            limit=3,
        )
        assert len(out) == 1
        bm25.assert_called_once()
        call_kw = bm25.call_args.kwargs
        assert call_kw["tenant_id"] == "tnt_x"
        assert call_kw["query"] == "hello world test"
