"""
tests/test_pipeline.py — Unit + integration tests for the 6-agent pipeline.

Tests each agent node in isolation, then the full pipeline end-to-end
using skip_llm=True (keyword-only, no API calls required).

Pipeline agents (5): intake → classifier → security → graph_writer → extraction

Run with: pytest tests/test_pipeline.py -v
"""
from __future__ import annotations

import pytest
from src.collab_memory.agents.state import PipelineState
from src.collab_memory.agents.intake import run_intake, route_after_intake
from src.collab_memory.agents.classifier import run_classifier
from src.collab_memory.agents.security import run_security, _word_overlap
from src.collab_memory.agents.pipeline import (
    build_pipeline,
    run_pipeline,
    get_pipeline_status,
    PIPELINE_STAGE_AGENT_IDS,
)
from src.collab_memory.graph.local import LocalGraphBackend


# ─── Fixtures ─────────────────────────────────────────────────────────────────

FIXTURE_DECISION = (
    "USER: better - I think we can proceed\n"
    "AGENT: Schema is hardened. Session 2 ready to begin."
)

FIXTURE_OVERRIDE = (
    "USER: actually, let's not use a vector database for this\n"
    "AGENT: Agreed — abandon the vector DB path."
)

FIXTURE_EXECUTION = (
    "AGENT: I've updated the schema to include the ExchangeRecord node type.\n"
    "The file has been saved to schema_v1.md."
)

FIXTURE_CONSTRAINT = (
    "USER: we can't use external APIs here, budget constraint\n"
    "AGENT: Noted — no external API calls in this module."
)

FIXTURE_LOW_SIGNAL = "USER: ok\nAGENT: Sure."

SESSION_ID = "pipeline_test_001"


def make_local_graph():
    """Create a fresh local graph backend for testing."""
    return LocalGraphBackend(path=":memory:")  # or temp path


# ─── Intake Agent Tests ────────────────────────────────────────────────────────

class TestIntakeAgent:

    def test_drops_empty_text(self):
        state = run_intake({"raw_text": "", "session_id": SESSION_ID, "turn_start": 0})
        assert state["should_classify"] is False
        assert state["keyword_score"] == 0.0

    def test_drops_very_low_signal(self):
        state = run_intake({"raw_text": FIXTURE_LOW_SIGNAL, "session_id": SESSION_ID, "turn_start": 0})
        assert state["keyword_score"] < 0.15
        # "ok" alone scores near zero

    def test_passes_decision_text(self):
        state = run_intake({"raw_text": FIXTURE_DECISION, "session_id": SESSION_ID, "turn_start": 0})
        assert state["should_classify"] is True
        assert state["keyword_score"] > 0.10

    def test_passes_override_text(self):
        state = run_intake({"raw_text": FIXTURE_OVERRIDE, "session_id": SESSION_ID, "turn_start": 0})
        assert state["should_classify"] is True

    def test_passes_constraint_text(self):
        state = run_intake({"raw_text": FIXTURE_CONSTRAINT, "session_id": SESSION_ID, "turn_start": 0})
        assert state["should_classify"] is True

    def test_route_after_intake_classify(self):
        state: PipelineState = {"should_classify": True}
        assert route_after_intake(state) == "classify"

    def test_route_after_intake_drop(self):
        state: PipelineState = {"should_classify": False}
        assert route_after_intake(state) == "drop"


# ─── Classifier Agent Tests ────────────────────────────────────────────────────

class TestClassifierAgent:

    def _base_state(self, text: str) -> PipelineState:
        s = run_intake({"raw_text": text, "session_id": SESSION_ID, "turn_start": 0})
        return s

    def test_skip_llm_decision(self):
        state = self._base_state(FIXTURE_DECISION)
        state["skip_llm"] = True
        result = run_classifier(state)
        assert "primitive_type" in result
        assert "final_score" in result
        assert "should_encode" in result

    def test_skip_llm_override_classified(self):
        state = self._base_state(FIXTURE_OVERRIDE)
        state["skip_llm"] = True
        result = run_classifier(state)
        # Override pattern should classify as Override or DecisionClose
        assert result["primitive_type"] in ("Override", "DecisionClose", "AbandonedAttempt")

    def test_skip_llm_execution_low_score(self):
        state = self._base_state(FIXTURE_EXECUTION)
        state["skip_llm"] = True
        result = run_classifier(state)
        # Execution fixture should have low worthiness and should_encode=False
        assert result["should_encode"] is False or result["final_score"] < 0.4

    def test_final_score_in_range(self):
        state = self._base_state(FIXTURE_DECISION)
        state["skip_llm"] = True
        result = run_classifier(state)
        assert 0.0 <= result["final_score"] <= 1.0

    def test_classifier_reasoning_present(self):
        state = self._base_state(FIXTURE_DECISION)
        state["skip_llm"] = True
        result = run_classifier(state)
        assert "classifier_reasoning" in result


# ─── Security Agent Tests ──────────────────────────────────────────────────────

class TestSecurityAgent:

    def test_word_overlap_identical(self):
        assert _word_overlap("we decided to use Neo4j", "we decided to use Neo4j") == 1.0

    def test_word_overlap_zero(self):
        assert _word_overlap("fastapi backend", "postgres database") == 0.0

    def test_word_overlap_partial(self):
        score = _word_overlap("we use Neo4j graph database", "Neo4j graph schema")
        assert 0.0 < score < 1.0

    def test_no_contradiction_without_graph(self):
        state: PipelineState = {
            "raw_text": FIXTURE_DECISION,
            "primitive_type": "DecisionClose",
            "llm_result": {"description": "Use Neo4j as graph backend"},
        }
        result = run_security(state, graph=None)
        assert result["contradiction_detected"] is False

    def test_non_decision_types_skipped(self):
        state: PipelineState = {
            "raw_text": FIXTURE_EXECUTION,
            "primitive_type": "Execution",
            "llm_result": {"description": "Updated schema file"},
        }
        result = run_security(state, graph=None)
        assert result["contradiction_detected"] is False


# ─── Full Pipeline Integration Tests ──────────────────────────────────────────

class TestPipeline:

    def test_pipeline_builds(self):
        """Pipeline builds without error, langgraph or plain fallback."""
        pipeline = build_pipeline(graph=None)
        assert callable(pipeline)

    def test_pipeline_backend_set(self):
        pipeline = build_pipeline(graph=None)
        assert hasattr(pipeline, "_backend")
        assert pipeline._backend in ("langgraph", "plain")

    def test_pipeline_drops_low_signal(self):
        state = run_pipeline(
            raw_text=FIXTURE_LOW_SIGNAL,
            session_id=SESSION_ID,
            skip_llm=True,
        )
        # Low signal → Intake drops → no exchange_record_id set
        assert state.get("should_classify") is False

    def test_pipeline_full_decision(self):
        state = run_pipeline(
            raw_text=FIXTURE_DECISION,
            session_id=SESSION_ID,
            turn_start=0,
            skip_llm=True,
            graph=None,  # no graph = graph_writer sets error on write but doesn't raise
        )
        # Should classify successfully
        assert state.get("should_classify") is True
        assert state.get("primitive_type") is not None

    def test_pipeline_full_override(self):
        state = run_pipeline(
            raw_text=FIXTURE_OVERRIDE,
            session_id=SESSION_ID,
            turn_start=1,
            skip_llm=True,
            graph=None,
        )
        assert state.get("should_classify") is True
        assert state.get("primitive_type") in ("Override", "DecisionClose", "AbandonedAttempt")

    def test_pipeline_with_local_graph(self, tmp_path):
        """Full pipeline run with a real local graph backend."""
        graph = LocalGraphBackend(path=str(tmp_path / "graph.json"))
        state = run_pipeline(
            raw_text=FIXTURE_OVERRIDE,
            session_id="integration_test_001",
            turn_start=0,
            skip_llm=True,
            graph=graph,
        )
        assert state.get("should_classify") is True
        # Exchange record should be written
        assert state.get("exchange_record_id") or state.get("error")

    def test_pipeline_status(self):
        status = get_pipeline_status(graph=None)
        assert "backend" in status
        assert "agents" in status
        assert status["agents"] == list(PIPELINE_STAGE_AGENT_IDS)

    def test_pipeline_constraint_detection(self):
        state = run_pipeline(
            raw_text=FIXTURE_CONSTRAINT,
            session_id=SESSION_ID,
            skip_llm=True,
            graph=None,
        )
        assert state.get("should_classify") is True
        assert state.get("primitive_type") is not None
