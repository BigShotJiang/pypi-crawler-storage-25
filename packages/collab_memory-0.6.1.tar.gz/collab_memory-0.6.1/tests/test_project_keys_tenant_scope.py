from starlette.testclient import TestClient


class _GraphKeysStub:
    def __init__(self):
        self.rows = [
            {
                "pk": {
                    "api_key": "cmk_proj_key_tenant_a_1234567890",
                    "project_id": "prj_shared",
                    "tenant_id": "tenant_a",
                    "role": "contributor",
                    "agent_id": "agent_a",
                    "status": "active",
                }
            },
            {
                "pk": {
                    "api_key": "cmk_proj_key_tenant_b_abcdefghij",
                    "project_id": "prj_shared",
                    "tenant_id": "tenant_b",
                    "role": "contributor",
                    "agent_id": "agent_b",
                    "status": "active",
                }
            },
        ]
        self.last_tid = None

    def _tx_read(self, _query: str, **params):
        self.last_tid = params.get("tid")
        pid = params.get("pid")
        tid = params.get("tid")
        return [
            r for r in self.rows
            if r["pk"]["project_id"] == pid and r["pk"]["tenant_id"] == tid
        ]


def test_list_project_keys_filters_by_tenant(monkeypatch):
    from collab_memory.abac import AgentContext
    from collab_memory.api import server as srv

    g = _GraphKeysStub()
    monkeypatch.setattr(srv, "graph", g)
    monkeypatch.setattr(srv, "_API_KEY", "test_key")
    monkeypatch.setattr(srv, "_VALID_API_KEYS", {"test_key"})

    def _resolve_agent_context(_key, graph=None):
        return AgentContext(
            role="admin",
            agent_id="admin_keys",
            key="test_key",
            tenant_id="tenant_a",
            plan="pro",
        )

    monkeypatch.setattr(srv, "resolve_agent_context", _resolve_agent_context)

    client = TestClient(srv.app)
    resp = client.get("/projects/prj_shared/keys", headers={"X-API-Key": "test_key"})
    assert resp.status_code == 200
    body = resp.json()
    assert body["count"] == 1
    assert g.last_tid == "tenant_a"
    assert body["keys"][0]["tenant_id"] == "tenant_a"
    assert body["keys"][0]["api_key"].startswith("cmk_proj")
