"""Tests for context auto-injection (proxy hooks)."""
import pytest
from collab_memory.proxy.hooks import (
    inject_memory_into_messages,
    extract_user_message,
    estimate_tokens,
    fetch_context_from_graph,
    MEMORY_INJECTION_HEADER,
)


# ── inject_memory_into_messages ──

def test_inject_appends_to_system_message():
    messages = [
        {"role": "system", "content": "You are helpful."},
        {"role": "user", "content": "Hello"},
    ]
    result = inject_memory_into_messages(messages, "Decision: Use React")
    assert len(result) == 2
    assert "COGNITIVE MEMORY CONTEXT" in result[0]["content"]
    assert "Decision: Use React" in result[0]["content"]
    assert result[0]["content"].startswith("You are helpful.")


def test_inject_creates_system_message_if_missing():
    messages = [
        {"role": "user", "content": "Hello"},
    ]
    result = inject_memory_into_messages(messages, "Constraint: No eval()")
    assert len(result) == 2
    assert result[0]["role"] == "system"
    assert "COGNITIVE MEMORY CONTEXT" in result[0]["content"]
    assert "Constraint: No eval()" in result[0]["content"]


def test_inject_noop_on_empty_context():
    messages = [{"role": "user", "content": "Hello"}]
    result = inject_memory_into_messages(messages, "")
    assert result == messages


def test_inject_noop_on_whitespace_context():
    messages = [{"role": "user", "content": "Hello"}]
    result = inject_memory_into_messages(messages, "   \n  ")
    assert result == messages


def test_inject_does_not_mutate_original():
    messages = [
        {"role": "system", "content": "Original"},
        {"role": "user", "content": "Hello"},
    ]
    original_content = messages[0]["content"]
    inject_memory_into_messages(messages, "Some context")
    assert messages[0]["content"] == original_content


# ── extract_user_message ──

def test_extract_last_user_message():
    messages = [
        {"role": "user", "content": "First"},
        {"role": "assistant", "content": "Reply"},
        {"role": "user", "content": "Second question"},
    ]
    assert extract_user_message(messages) == "Second question"


def test_extract_empty_on_no_user():
    messages = [{"role": "system", "content": "Only system"}]
    assert extract_user_message(messages) == ""


def test_extract_multimodal_content():
    """Content can be a list of objects (vision API format)."""
    messages = [
        {"role": "user", "content": [
            {"type": "text", "text": "Describe this"},
            {"type": "image_url", "image_url": {"url": "..."}}
        ]},
    ]
    result = extract_user_message(messages)
    assert "Describe this" in result


# ── estimate_tokens ──

def test_estimate_tokens():
    assert estimate_tokens("hello world") >= 1
    assert estimate_tokens("a" * 400) == 100  # ~4 chars per token
    assert estimate_tokens("") == 1  # minimum 1


# ── fetch_context_from_graph ──

@pytest.mark.asyncio
async def test_fetch_context_returns_empty_on_none_graph():
    result = await fetch_context_from_graph(None)
    assert result == ""


@pytest.mark.asyncio
async def test_fetch_context_formats_decisions():
    class FakeGraph:
        def build_context_brief(self, **kw):
            return {
                "active_decisions": [
                    {"description": "Use React for frontend", "confidence": 0.9, "rationale": "Best DX"},
                ],
                "active_constraints": [
                    {"description": "No eval() in production", "origin": "explicit"},
                ],
                "inferred_preferences": [
                    {"description": "Prefers TypeScript over JavaScript"},
                ],
            }

    result = await fetch_context_from_graph(FakeGraph())
    assert "Use React for frontend" in result
    assert "No eval() in production" in result
    assert "Prefers TypeScript" in result
    assert "90%" in result  # confidence display


@pytest.mark.asyncio
async def test_fetch_context_handles_error():
    class BrokenGraph:
        def build_context_brief(self, **kw):
            raise RuntimeError("DB down")

    result = await fetch_context_from_graph(BrokenGraph())
    assert result == ""
