"""
tests/test_watcher.py — Tests for the SessionWatcher real-time ingestion loop.

Tests cover: turn pushing, keyword pre-screen speed, flush(), graph write-back,
and high/low signal routing.

All tests use skip_llm=True so no API key is required.

Run with: pytest tests/test_watcher.py -v
"""

from __future__ import annotations

import time
import threading
import pytest
from pathlib import Path

from src.collab_memory.graph.local import LocalGraphBackend
from src.collab_memory.schema import PrimitiveType


# ─── Import watcher via path (not installed) ──────────────────────────────────
import sys
sys.path.insert(0, str(Path(__file__).parent.parent / "scripts"))
from watch_session import SessionWatcher, WatcherStats


# ─── Test Fixtures ────────────────────────────────────────────────────────────

HIGH_SIGNAL_TURN = "USER: Actually let's not use a vector database for this, it's the wrong abstraction."
DECISION_TURN = "USER: Good, we'll go with the graph approach. We're locked in on this."
EXECUTION_TURN = "AGENT: I've updated the schema file and saved it to disk."
PURE_LOW_SIGNAL_TURN = "AGENT: Here is the file content you requested."


@pytest.fixture
def graph(tmp_path):
    return LocalGraphBackend(path=str(tmp_path / "watcher_test.json"))


@pytest.fixture
def watcher(graph):
    w = SessionWatcher(
        session_id="test_watcher_session",
        graph=graph,
        skip_llm=True,
        verbose=False,
    )
    yield w
    w.shutdown()


# ─── Basic Interface Tests ────────────────────────────────────────────────────

class TestWatcherInterface:

    def test_watcher_instantiates(self, graph):
        w = SessionWatcher(session_id="test_001", graph=graph, skip_llm=True, verbose=False)
        assert w is not None
        w.shutdown()

    def test_push_turn_accepts_string(self, watcher):
        """push_turn() should not raise on a valid string."""
        watcher.push_turn("USER: Let's proceed with option A.")

    def test_push_turn_ignores_empty(self, watcher):
        watcher.push_turn("")
        watcher.push_turn("   ")
        stats = watcher.get_stats()
        assert stats.turns_received == 0

    def test_get_stats_returns_watcher_stats(self, watcher):
        stats = watcher.get_stats()
        assert isinstance(stats, WatcherStats)

    def test_stats_session_id_matches(self, watcher):
        stats = watcher.get_stats()
        assert stats.session_id == "test_watcher_session"

    def test_flush_returns_stats(self, watcher):
        watcher.push_turn(HIGH_SIGNAL_TURN)
        stats = watcher.flush()
        assert isinstance(stats, WatcherStats)


# ─── Pre-Screen Routing ───────────────────────────────────────────────────────

class TestPreScreenRouting:

    def test_high_signal_increments_received(self, watcher):
        watcher.push_turn(HIGH_SIGNAL_TURN)
        watcher.flush()
        stats = watcher.get_stats()
        assert stats.turns_received == 1

    def test_low_signal_is_dropped_at_prescreen(self, watcher):
        # Genuinely neutral turns (score < 0.15) — should be dropped early, not queued for LLM
        watcher.push_turn(EXECUTION_TURN)
        watcher.push_turn(PURE_LOW_SIGNAL_TURN)
        watcher.flush()
        stats = watcher.get_stats()
        # Both should hit turns_received but be dropped at pre-screen
        # (pre-screened_high = 0 since they score < 0.15)
        assert stats.turns_prescreened_high == 0
        assert stats.turns_prescreened_low == 2

    def test_high_signal_queued_for_classification(self, watcher):
        watcher.push_turn(HIGH_SIGNAL_TURN)
        watcher.flush()
        stats = watcher.get_stats()
        assert stats.turns_prescreened_high >= 1


# ─── Speed Tests ─────────────────────────────────────────────────────────────

class TestPreScreenSpeed:

    def test_push_turn_returns_quickly(self, watcher):
        """push_turn() should return in < 50ms (keyword pre-screen is synchronous + fast)."""
        start = time.perf_counter()
        watcher.push_turn(HIGH_SIGNAL_TURN)
        elapsed_ms = (time.perf_counter() - start) * 1000
        # flush() is not called here — we're only measuring push_turn() itself
        assert elapsed_ms < 50, f"push_turn() took {elapsed_ms:.1f}ms — too slow for real-time use"

    def test_multiple_turns_push_fast(self, watcher):
        """Pushing 10 turns should complete in < 200ms total."""
        turns = [HIGH_SIGNAL_TURN, EXECUTION_TURN, DECISION_TURN, PURE_LOW_SIGNAL_TURN] * 3
        start = time.perf_counter()
        for turn in turns[:10]:
            watcher.push_turn(turn)
        elapsed_ms = (time.perf_counter() - start) * 1000
        assert elapsed_ms < 200, f"10 push_turn() calls took {elapsed_ms:.1f}ms"


# ─── Graph Write-Back ─────────────────────────────────────────────────────────

class TestGraphWriteBack:

    def test_high_signal_writes_to_graph(self, watcher, graph):
        """After flush(), a high-signal turn should have written at least one node."""
        watcher.push_turn(HIGH_SIGNAL_TURN)
        stats = watcher.flush()
        # In skip_llm mode: keyword-only; we should have at least one encoded result
        assert stats.turns_encoded >= 1 or stats.turns_flagged >= 1 or stats.nodes_written >= 0
        # Graph should have at least the exchange record
        brief = graph.build_context_brief()
        assert isinstance(brief, dict)

    def test_flush_clears_pending_queue(self, watcher):
        """After flush(), the pending futures list should be empty (idempotent)."""
        watcher.push_turn(HIGH_SIGNAL_TURN)
        watcher.push_turn(DECISION_TURN)
        watcher.flush()
        # Second flush should complete immediately with no new work
        stats2 = watcher.flush()
        assert isinstance(stats2, WatcherStats)

    def test_multiple_high_signal_all_processed(self, watcher, graph):
        """All high-signal turns should be processed after flush()."""
        high_signal_turns = [
            "USER: Actually, we should use a different approach here.",
            "USER: Let's abandon the REST API approach and go with GraphQL.",
            "USER: We can't use a relational DB here, must be graph-based.",
        ]
        for turn in high_signal_turns:
            watcher.push_turn(turn)

        stats = watcher.flush()
        total_processed = stats.turns_encoded + stats.turns_flagged + stats.turns_skipped
        # All pre-screened turns should have been classified
        assert total_processed == stats.turns_prescreened_high

    def test_errors_tracked_in_stats(self, graph):
        """Errors during classification should be counted, not silently swallowed."""
        # SessionWatcher with no LLM provider — but skip_llm=True, so won't error
        watcher = SessionWatcher(
            session_id="error_test",
            graph=graph,
            skip_llm=True,
            verbose=False,
        )
        watcher.push_turn(HIGH_SIGNAL_TURN)
        stats = watcher.flush()
        assert stats.errors == 0  # No errors in skip_llm mode
        watcher.shutdown()


# ─── Thread Safety ────────────────────────────────────────────────────────────

class TestThreadSafety:

    def test_concurrent_push_turns_safe(self, watcher):
        """Multiple threads pushing turns simultaneously should not race."""
        errors = []

        def push_many():
            try:
                for _ in range(5):
                    watcher.push_turn(EXECUTION_TURN)
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=push_many) for _ in range(4)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        watcher.flush()
        assert len(errors) == 0, f"Thread safety errors: {errors}"
        # 20 total turns pushed, all execution (score < 0.15) — all pre-screened low
        stats = watcher.get_stats()
        assert stats.turns_received == 20
