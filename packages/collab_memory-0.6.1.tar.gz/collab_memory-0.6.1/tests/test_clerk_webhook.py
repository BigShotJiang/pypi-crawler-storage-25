"""
Tests for Clerk webhook endpoint signature verification and routing.

Tests run against the FastAPI test client without a real Clerk account.
Verifies: signature rejection, event routing, and payload handling.
"""

import json
import hmac
import hashlib
import base64
import os
import unittest
from unittest.mock import patch, MagicMock

from fastapi.testclient import TestClient


def _make_client():
    """Create a test client with the Clerk webhook secret set."""
    os.environ.setdefault("COLLAB_API_KEY", "test-key-123")
    from collab_memory.api.server import app
    return TestClient(app)


class TestClerkWebhookAuth(unittest.TestCase):
    """Webhook signature verification."""

    def setUp(self):
        self.client = _make_client()

    def test_rejects_missing_headers(self):
        """No svix headers → 401."""
        r = self.client.post(
            "/webhooks/clerk",
            json={"type": "user.created", "data": {}},
        )
        # Either 401 (missing headers) or 501 (no secret configured)
        assert r.status_code in (401, 501)

    @patch.dict(os.environ, {"CLERK_WEBHOOK_SECRET": ""})
    def test_rejects_no_secret_configured(self):
        """CLERK_WEBHOOK_SECRET empty → 501."""
        r = self.client.post(
            "/webhooks/clerk",
            json={"type": "user.created", "data": {}},
            headers={
                "svix-id": "msg_123",
                "svix-timestamp": "1234567890",
                "svix-signature": "v1,fakesig",
            },
        )
        assert r.status_code == 501

    @patch.dict(os.environ, {"CLERK_WEBHOOK_SECRET": "whsec_" + base64.b64encode(b"testsecret1234567890123456").decode()})
    def test_rejects_bad_signature(self):
        """Wrong signature → 401."""
        r = self.client.post(
            "/webhooks/clerk",
            content=json.dumps({"type": "user.created", "data": {"id": "user_abc"}}),
            headers={
                "Content-Type": "application/json",
                "svix-id": "msg_123",
                "svix-timestamp": "1234567890",
                "svix-signature": "v1,definitelywrongsignature",
            },
        )
        assert r.status_code == 401

    @patch.dict(os.environ, {"CLERK_WEBHOOK_SECRET": "whsec_" + base64.b64encode(b"testsecret1234567890123456").decode()})
    def test_accepts_valid_signature(self):
        """Correct svix signature → 200."""
        secret_bytes = b"testsecret1234567890123456"
        body = json.dumps({"type": "user.created", "data": {"id": "user_abc", "email_addresses": [], "first_name": "Test", "last_name": "User"}})
        svix_id = "msg_test123"
        svix_timestamp = "1234567890"

        to_sign = f"{svix_id}.{svix_timestamp}.".encode() + body.encode()
        sig = base64.b64encode(
            hmac.new(secret_bytes, to_sign, hashlib.sha256).digest()
        ).decode()

        with patch("collab_memory.api.server.graph") as mock_graph:
            mock_graph.run_query = MagicMock(return_value=[])
            r = self.client.post(
                "/webhooks/clerk",
                content=body,
                headers={
                    "Content-Type": "application/json",
                    "svix-id": svix_id,
                    "svix-timestamp": svix_timestamp,
                    "svix-signature": f"v1,{sig}",
                },
            )

        assert r.status_code == 200
        assert r.json()["event"] == "user.created"


class TestClerkWebhookEvents(unittest.TestCase):
    """Event type routing."""

    def _signed_request(self, body_dict):
        """Build a properly signed webhook request."""
        secret_bytes = b"testsecret1234567890123456"
        body = json.dumps(body_dict)
        svix_id = "msg_test456"
        svix_timestamp = "1234567890"
        to_sign = f"{svix_id}.{svix_timestamp}.".encode() + body.encode()
        sig = base64.b64encode(
            hmac.new(secret_bytes, to_sign, hashlib.sha256).digest()
        ).decode()
        return body, {
            "Content-Type": "application/json",
            "svix-id": svix_id,
            "svix-timestamp": svix_timestamp,
            "svix-signature": f"v1,{sig}",
        }

    @patch.dict(os.environ, {"CLERK_WEBHOOK_SECRET": "whsec_" + base64.b64encode(b"testsecret1234567890123456").decode()})
    def test_user_deleted_event(self):
        body, headers = self._signed_request({
            "type": "user.deleted",
            "data": {"id": "user_to_delete"},
        })
        client = _make_client()
        with patch("collab_memory.api.server.graph") as mock_graph:
            mock_graph.run_query = MagicMock(return_value=[])
            r = client.post("/webhooks/clerk", content=body, headers=headers)

        assert r.status_code == 200
        assert r.json()["event"] == "user.deleted"
        # Verify run_query was called with soft-delete SET
        call_args = mock_graph.run_query.call_args
        assert "status = 'deleted'" in call_args[0][0]


if __name__ == "__main__":
    unittest.main()
