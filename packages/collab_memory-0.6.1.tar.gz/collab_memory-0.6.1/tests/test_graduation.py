"""Tests for Cognitive Dreams graduation engine."""
import pytest
from collab_memory.graduation import (
    check_graduations,
    GraduationEvent,
    RECALL_TO_PREFERENCE,
    CROSS_PROJECT_TO_RULE,
)


class MockBackend:
    """Mock Neo4j backend that returns configurable node data."""

    def __init__(self, nodes=None, cross_project_rows=None):
        self._nodes = nodes or []
        self._cross_project_rows = cross_project_rows or []
        self._writes = []

    def _tx_read(self, query, **params):
        if "labels(n)" in query:
            # Phase 1: return node type + recall data
            return [n for n in self._nodes if n["id"] in params.get("ids", [])]
        if "project_count" in query or "SIZE(projects)" in query:
            # Phase 2: cross-project check
            return [r for r in self._cross_project_rows if r["id"] in params.get("ids", [])]
        return []

    def _tx_write(self, query, **params):
        self._writes.append({"query": query, "params": params})


# ── Phase 1: Detail → Preference ──

def test_decision_graduates_at_threshold():
    backend = MockBackend(nodes=[
        {"id": "dec_abc", "node_type": "Decision", "recall_count": 3, "reinforcement_count": 3, "project_id": "p1"},
    ])
    events = check_graduations(["dec_abc"], backend)
    assert len(events) == 1
    assert events[0].from_type == "Decision"
    assert events[0].to_type == "Preference"
    assert events[0].recall_count == 3
    assert len(backend._writes) == 1
    assert "Preference" in backend._writes[0]["query"]


def test_constraint_graduates():
    backend = MockBackend(nodes=[
        {"id": "con_xyz", "node_type": "Constraint", "recall_count": 5, "reinforcement_count": 5, "project_id": "p1"},
    ])
    events = check_graduations(["con_xyz"], backend)
    assert len(events) == 1
    assert events[0].from_type == "Constraint"
    assert events[0].to_type == "Preference"


def test_attempt_graduates():
    backend = MockBackend(nodes=[
        {"id": "att_123", "node_type": "Attempt", "recall_count": 4, "reinforcement_count": 4, "project_id": "p1"},
    ])
    events = check_graduations(["att_123"], backend)
    assert len(events) == 1
    assert events[0].from_type == "Attempt"


def test_below_threshold_no_graduation():
    backend = MockBackend(nodes=[
        {"id": "dec_low", "node_type": "Decision", "recall_count": 2, "reinforcement_count": 2, "project_id": "p1"},
    ])
    events = check_graduations(["dec_low"], backend)
    assert events == []
    assert len(backend._writes) == 0


def test_already_graduated_skipped():
    """Nodes that already have graduated_at set must not be re-promoted."""
    backend = MockBackend(nodes=[
        {"id": "dec_done", "node_type": "Decision", "recall_count": 10, "reinforcement_count": 10,
         "project_id": "p1", "graduated_at": "2026-04-01T00:00:00+00:00"},
    ])
    events = check_graduations(["dec_done"], backend)
    assert events == []
    assert len(backend._writes) == 0


def test_preference_not_graduated_to_preference():
    """Preferences should not be re-graduated to Preference."""
    backend = MockBackend(nodes=[
        {"id": "prf_abc", "node_type": "Preference", "recall_count": 10, "reinforcement_count": 10, "project_id": "p1"},
    ])
    events = check_graduations(["prf_abc"], backend)
    # Phase 1 shouldn't promote Preference → Preference
    assert all(e.from_type != "Preference" or e.to_type != "Preference" for e in events)


# ── Phase 2: Preference → Rule ──

def test_preference_graduates_to_rule():
    backend = MockBackend(
        nodes=[
            {"id": "prf_multi", "node_type": "Preference", "recall_count": 8, "reinforcement_count": 8, "project_id": "p1"},
        ],
        cross_project_rows=[
            {"id": "prf_multi", "recall_count": 8, "project_count": 4},
        ],
    )
    events = check_graduations(["prf_multi"], backend)
    assert any(e.to_type == "Rule" for e in events)
    rule_event = [e for e in events if e.to_type == "Rule"][0]
    assert rule_event.project_count == 4


def test_preference_below_project_threshold():
    backend = MockBackend(
        nodes=[
            {"id": "prf_single", "node_type": "Preference", "recall_count": 5, "reinforcement_count": 5, "project_id": "p1"},
        ],
        cross_project_rows=[],  # Not enough projects
    )
    events = check_graduations(["prf_single"], backend)
    assert not any(e.to_type == "Rule" for e in events)


# ── Rule → HardRule: intentionally blocked ──

def test_rule_never_auto_graduates():
    """Rules should NEVER automatically become HardRules."""
    backend = MockBackend(nodes=[
        {"id": "rule_abc", "node_type": "Rule", "recall_count": 100, "reinforcement_count": 100, "project_id": "p1"},
    ])
    events = check_graduations(["rule_abc"], backend)
    assert not any(e.to_type == "HardRule" for e in events)


# ── Edge cases ──

def test_empty_ids():
    backend = MockBackend()
    events = check_graduations([], backend)
    assert events == []


def test_multiple_nodes_mixed():
    backend = MockBackend(nodes=[
        {"id": "dec_a", "node_type": "Decision", "recall_count": 5, "reinforcement_count": 5, "project_id": "p1"},
        {"id": "dec_b", "node_type": "Decision", "recall_count": 1, "reinforcement_count": 1, "project_id": "p1"},
        {"id": "con_c", "node_type": "Constraint", "recall_count": 3, "reinforcement_count": 3, "project_id": "p2"},
    ])
    events = check_graduations(["dec_a", "dec_b", "con_c"], backend)
    # dec_a and con_c should graduate, dec_b should not
    graduated_ids = {e.node_id for e in events}
    assert "dec_a" in graduated_ids
    assert "con_c" in graduated_ids
    assert "dec_b" not in graduated_ids


def test_backend_error_returns_empty():
    class BrokenBackend:
        def _tx_read(self, query, **params):
            raise RuntimeError("DB down")

    events = check_graduations(["dec_abc"], BrokenBackend())
    assert events == []


# ── Threshold constants ──

def test_thresholds():
    assert RECALL_TO_PREFERENCE == 3
    assert CROSS_PROJECT_TO_RULE == 3
