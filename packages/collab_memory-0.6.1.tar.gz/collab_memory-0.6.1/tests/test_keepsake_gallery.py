"""Variation receipt ZIP + gallery routes (user archival bundles)."""
from __future__ import annotations

import io
import json
import zipfile

import pytest
from starlette.testclient import TestClient


@pytest.fixture
def client():
    from collab_memory.api.server import app

    return TestClient(app)


def test_gallery_page_ok(client):
    r = client.get("/gallery")
    assert r.status_code == 200
    assert "gallery" in r.text.lower() or "variation" in r.text.lower()


def test_keepsake_zip_structure(client):
    r = client.get("/gallery/keepsake.zip")
    assert r.status_code == 200
    assert r.headers.get("content-type", "").startswith("application/zip")
    assert "attachment" in r.headers.get("content-disposition", "").lower()

    zf = zipfile.ZipFile(io.BytesIO(r.content))
    names = set(zf.namelist())
    assert "manifest.json" in names
    assert "variation-receipt.html" in names
    assert "README.txt" in names

    manifest = json.loads(zf.read("manifest.json").decode())
    assert manifest.get("schema") == "ohaco.keepsake.v1"
    assert manifest.get("product") == "collab-memory"
    assert "package_version" in manifest
    assert "approvals" in manifest
    assert manifest.get("instance_base_url")


def test_keepsake_note_query(client):
    r = client.get("/gallery/keepsake.zip?note=hello%20world")
    assert r.status_code == 200
    zf = zipfile.ZipFile(io.BytesIO(r.content))
    manifest = json.loads(zf.read("manifest.json").decode())
    assert manifest.get("user_note") == "hello world"
