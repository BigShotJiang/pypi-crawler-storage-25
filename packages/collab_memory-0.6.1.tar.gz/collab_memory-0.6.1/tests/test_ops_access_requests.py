"""Ops endpoints for AccessRequest queue + public redirects to /apply."""

import pytest
from starlette.testclient import TestClient


@pytest.fixture
def client() -> TestClient:
    from collab_memory.api.server import app

    return TestClient(app)


@pytest.mark.parametrize(
    "path",
    ["/waitlist", "/beta", "/early-access", "/request-access"],
)
def test_apply_url_aliases_redirect(client: TestClient, path: str) -> None:
    r = client.get(path, follow_redirects=False)
    assert r.status_code == 302
    assert r.headers.get("location", "").endswith("/apply")


def test_ops_access_requests_requires_primary_key(monkeypatch: pytest.MonkeyPatch, client: TestClient) -> None:
    monkeypatch.setenv("COLLAB_API_KEY", "ops-secret-key")
    monkeypatch.delenv("COLLAB_API_KEY_READONLY", raising=False)
    r = client.get("/ops/access-requests")
    # Handler enforces primary key from live os.environ (403). If the app was imported with
    # COLLAB_API_KEY already set, middleware may return 401 first.
    assert r.status_code in (401, 403)


def test_ops_access_requests_with_key_local_backend_501(monkeypatch: pytest.MonkeyPatch, client: TestClient) -> None:
    monkeypatch.setenv("COLLAB_API_KEY", "ops-secret-key")
    r = client.get("/ops/access-requests", headers={"X-API-Key": "ops-secret-key"})
    # Local JSON backend has no Cypher; Neo4j deployments return 200 + list.
    assert r.status_code in (200, 501)
    if r.status_code == 200:
        data = r.json()
        assert "requests" in data and "count" in data


def test_ops_access_requests_readonly_only_503(monkeypatch: pytest.MonkeyPatch, client: TestClient) -> None:
    monkeypatch.delenv("COLLAB_API_KEY", raising=False)
    monkeypatch.setenv("COLLAB_API_KEY_READONLY", "ro-only")
    r = client.get("/ops/access-requests", headers={"X-API-Key": "ro-only"})
    assert r.status_code == 503
