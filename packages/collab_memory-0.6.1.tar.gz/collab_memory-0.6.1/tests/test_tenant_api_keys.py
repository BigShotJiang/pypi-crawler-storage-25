"""Tenant read/write API key rotation (selective vs both)."""

import time
import uuid
from unittest.mock import MagicMock

import jwt
import pytest
from starlette.testclient import TestClient


@pytest.fixture
def client() -> TestClient:
    from collab_memory.api.server import app

    return TestClient(app)


def _jwt(monkeypatch: pytest.MonkeyPatch, *, tenant_id: str | None = None) -> str:
    sec = "unit-test-jwt-secret-key-min-32-chars!!"
    monkeypatch.setenv("JWT_SECRET", sec)
    from collab_memory.auth.middleware import init_auth_client

    init_auth_client(neo4j_backend=None)
    now = int(time.time())
    tid = tenant_id or str(uuid.uuid4())
    payload = {
        "sub": "u-test",
        "email": "keys@example.com",
        "tenant_id": tid,
        "plan": "free",
        "role": "admin",
        "iat": now,
        "exp": now + 3600,
        "type": "access",
    }
    return jwt.encode(payload, sec, algorithm="HS256")


def test_regenerate_api_keys_write_only(monkeypatch: pytest.MonkeyPatch, client: TestClient) -> None:
    from collab_memory.auth import routes as ar

    w_old, r_keep = "cmk_write_aaa", "cmk_read_bbb"
    mock_g = MagicMock()
    mock_g._tx_read.return_value = [{"write_key": w_old, "read_key": r_keep}]
    monkeypatch.setattr(ar, "_get_graph", lambda: mock_g)
    tok = _jwt(monkeypatch)
    r = client.post(
        "/auth/api-keys/regenerate",
        headers={"Authorization": f"Bearer {tok}"},
        json={"which": "write"},
    )
    assert r.status_code == 200
    d = r.json()
    assert d["which"] == "write"
    assert d["api_key_read"] == r_keep
    assert d["api_key_write"] != w_old
    assert d["api_key_write"].startswith("cmk_write_")
    mock_g._tx_write.assert_called_once()


def test_regenerate_api_keys_read_only(monkeypatch: pytest.MonkeyPatch, client: TestClient) -> None:
    from collab_memory.auth import routes as ar

    w_keep, r_old = "cmk_write_www", "cmk_read_rrr"
    mock_g = MagicMock()
    mock_g._tx_read.return_value = [{"write_key": w_keep, "read_key": r_old}]
    monkeypatch.setattr(ar, "_get_graph", lambda: mock_g)
    tok = _jwt(monkeypatch)
    r = client.post(
        "/auth/api-keys/regenerate",
        headers={"Authorization": f"Bearer {tok}"},
        json={"which": "read"},
    )
    assert r.status_code == 200
    d = r.json()
    assert d["which"] == "read"
    assert d["api_key_write"] == w_keep
    assert d["api_key_read"] != r_old
    assert d["api_key_read"].startswith("cmk_read_")


def test_regenerate_api_keys_default_both(monkeypatch: pytest.MonkeyPatch, client: TestClient) -> None:
    from collab_memory.auth import routes as ar

    mock_g = MagicMock()
    mock_g._tx_read.return_value = [{"write_key": "cmk_w", "read_key": "cmk_r"}]
    monkeypatch.setattr(ar, "_get_graph", lambda: mock_g)
    tok = _jwt(monkeypatch)
    r = client.post(
        "/auth/api-keys/regenerate",
        headers={"Authorization": f"Bearer {tok}"},
    )
    assert r.status_code == 200
    d = r.json()
    assert d["which"] == "both"
    assert d["api_key_write"].startswith("cmk_write_")
    assert d["api_key_read"].startswith("cmk_read_")


def test_regenerate_api_keys_invalid_which_422(client: TestClient, monkeypatch: pytest.MonkeyPatch) -> None:
    tok = _jwt(monkeypatch)
    r = client.post(
        "/auth/api-keys/regenerate",
        headers={"Authorization": f"Bearer {tok}"},
        json={"which": "delete_all"},
    )
    assert r.status_code == 422
