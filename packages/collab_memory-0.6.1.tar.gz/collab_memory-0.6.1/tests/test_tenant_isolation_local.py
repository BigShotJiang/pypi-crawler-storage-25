"""Local backend tenant isolation tests.

These guard against cross-account leakage when GRAPH_BACKEND=local.
"""

from __future__ import annotations

import pytest

from src.collab_memory.graph.local import LocalGraphBackend
from src.collab_memory.schema import Decision, DecisionStatus


@pytest.fixture
def graph(tmp_path):
    return LocalGraphBackend(path=str(tmp_path / "tenant_isolation.json"))


def test_get_decisions_filters_by_tenant(graph):
    d1 = Decision(
        description="Tenant 1 decision",
        made_in="s1",
        confidence=0.8,
        status=DecisionStatus.active,
        tenant_id="t1",
        project_id=None,
        module="api",
        category="decision",
        exchange_record_id="",
        rationale="",
    )
    d2 = Decision(
        description="Tenant 2 decision",
        made_in="s2",
        confidence=0.9,
        status=DecisionStatus.active,
        tenant_id="t2",
        project_id=None,
        module="api",
        category="decision",
        exchange_record_id="",
        rationale="",
    )

    graph.save_node(d1)
    graph.save_node(d2)

    t1 = graph.get_decisions(tenant_id="t1")
    assert len(t1) == 1
    assert t1[0].description == "Tenant 1 decision"

    t2 = graph.get_decisions(tenant_id="t2")
    assert len(t2) == 1
    assert t2[0].description == "Tenant 2 decision"


def test_build_context_brief_filters_by_tenant(graph):
    d1 = Decision(
        description="Tenant 1 active",
        made_in="s1",
        confidence=0.8,
        status=DecisionStatus.active,
        tenant_id="t1",
        project_id=None,
        module="api",
        category="decision",
        exchange_record_id="",
        rationale="",
    )
    d2 = Decision(
        description="Tenant 2 active",
        made_in="s2",
        confidence=0.7,
        status=DecisionStatus.active,
        tenant_id="t2",
        project_id=None,
        module="api",
        category="decision",
        exchange_record_id="",
        rationale="",
    )
    graph.save_node(d1)
    graph.save_node(d2)

    ctx = graph.build_context_brief(tenant_id="t1", project_id=None)
    descriptions = {d["description"] for d in ctx.get("active_decisions", [])}
    assert "Tenant 1 active" in descriptions
    assert "Tenant 2 active" not in descriptions


def test_pending_queue_filters_and_enforces_tenant(graph):
    d1 = Decision(
        description="Pending for t1",
        made_in="s1",
        confidence=0.6,
        status=DecisionStatus.active,
        tenant_id="t1",
        project_id=None,
        module="pipeline",
        category="decision",
        exchange_record_id="",
        rationale="",
    )
    d2 = Decision(
        description="Pending for t2",
        made_in="s2",
        confidence=0.6,
        status=DecisionStatus.active,
        tenant_id="t2",
        project_id=None,
        module="pipeline",
        category="decision",
        exchange_record_id="",
        rationale="",
    )

    pid1 = graph.save_pending(d1)
    pid2 = graph.save_pending(d2)

    pending_t1 = graph.get_pending(tenant_id="t1")
    assert {x["id"] for x in pending_t1} == {pid1}

    pending_t2 = graph.get_pending(tenant_id="t2")
    assert {x["id"] for x in pending_t2} == {pid2}

    # Can't confirm across tenant boundaries
    out = graph.confirm_pending_inference(pid1, tenant_id="t2")
    assert out["ok"] is False
    assert out.get("error") == "not_found"

