"""Tests for /admin/instances/provision endpoint behavior."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest
from starlette.testclient import TestClient


@pytest.fixture
def client() -> TestClient:
    from collab_memory.api.server import app

    return TestClient(app)


def _mock_admin_ctx(role: str = "admin"):
    from collab_memory.abac import AgentContext

    return AgentContext(role=role, agent_id="tester", tenant_id="tenant_test")


def test_provision_allows_super_admin_and_emits_typed_sse(
    monkeypatch: pytest.MonkeyPatch, client: TestClient
) -> None:
    """
    Regression:
    - super_admin role should be accepted (not blocked by spelling mismatch)
    - SSE emit should be called with a single dict containing event type
    """
    monkeypatch.delenv("RESEND_API_KEY", raising=False)
    monkeypatch.delenv("CLERK_SECRET_KEY", raising=False)
    monkeypatch.setenv("AUTH_PROVIDER", "none")

    from collab_memory.api import server as srv

    with patch.object(srv, "_API_KEY", "primary-key"), patch.object(srv, "_VALID_API_KEYS", {"test-any"}):
        with patch.object(srv, "resolve_agent_context", return_value=_mock_admin_ctx("super_admin")):
            with patch.object(srv, "graph") as mock_graph:
                mock_graph.create_tenant = MagicMock()
                mock_graph.save_project = MagicMock()
                mock_graph.save_node = MagicMock()

                with patch("collab_memory.api.sse.emit_event_sync") as mock_emit:
                    r = client.post(
                        "/admin/instances/provision",
                        headers={"X-API-Key": "test-any"},
                        json={
                            "customer_name": "Acme Labs",
                            "admin_email": "owner@acme.test",
                            "tier": "pro",
                        },
                    )

    assert r.status_code == 200
    body = r.json()
    assert body["ok"] is True
    assert body["provisioning_mode"] == "tenant_workspace"
    assert body["deployment_scope"] == "current_instance"
    assert body["infrastructure_provisioned"] is False
    assert any(step["step"] == "sse_notify" and step["status"] == "ok" for step in body["steps"])
    mock_emit.assert_called_once()
    event = mock_emit.call_args[0][0]
    assert isinstance(event, dict)
    assert event.get("type") == "instance.provisioned"
    assert event.get("customer_name") == "Acme Labs"
    assert event.get("provisioning_mode") == "tenant_workspace"
    assert event.get("infrastructure_provisioned") is False


def test_provision_rejects_non_admin_role(
    monkeypatch: pytest.MonkeyPatch, client: TestClient
) -> None:
    """Reader role should receive 403."""
    from collab_memory.api import server as srv

    with patch.object(srv, "_API_KEY", "primary-key"), patch.object(srv, "_VALID_API_KEYS", {"test-any"}):
        with patch.object(srv, "resolve_agent_context", return_value=_mock_admin_ctx("reader")):
            r = client.post(
                "/admin/instances/provision",
                headers={"X-API-Key": "test-any"},
                json={
                    "customer_name": "Denied Co",
                    "admin_email": "reader@denied.test",
                    "tier": "pro",
                },
            )

    assert r.status_code == 403


def test_provision_response_declares_tenant_workspace_mode(
    monkeypatch: pytest.MonkeyPatch, client: TestClient
) -> None:
    """Provision endpoint must explicitly declare it does not deploy infrastructure."""
    monkeypatch.delenv("RESEND_API_KEY", raising=False)
    monkeypatch.delenv("CLERK_SECRET_KEY", raising=False)
    monkeypatch.setenv("AUTH_PROVIDER", "none")

    from collab_memory.api import server as srv

    with patch.object(srv, "_API_KEY", "primary-key"), patch.object(srv, "_VALID_API_KEYS", {"test-any"}):
        with patch.object(srv, "resolve_agent_context", return_value=_mock_admin_ctx("admin")):
            with patch.object(srv, "graph") as mock_graph:
                mock_graph.create_tenant = MagicMock()
                mock_graph.save_project = MagicMock()
                mock_graph.save_node = MagicMock()
                with patch("collab_memory.api.sse.emit_event_sync"):
                    r = client.post(
                        "/admin/instances/provision",
                        headers={"X-API-Key": "test-any"},
                        json={
                            "customer_name": "Provision Scope Co",
                            "admin_email": "admin@scope.test",
                            "tier": "enterprise",
                        },
                    )

    assert r.status_code == 200
    body = r.json()
    assert body["ok"] is True
    assert body["provisioning_mode"] == "tenant_workspace"
    assert body["deployment_scope"] == "current_instance"
    assert body["infrastructure_provisioned"] is False
    assert "tenant/workspace data only" in body["note"]
