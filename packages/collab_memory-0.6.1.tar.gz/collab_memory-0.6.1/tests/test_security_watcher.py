"""Tests for the SecurityWatcher agent (agents/watcher.py).

Tests cover: trust graduation, post-ingest scanning, secret detection,
escalation behavior, and report aggregation.

Run with: pytest tests/test_security_watcher.py -v
"""
import pytest
from collab_memory.agents.watcher import SecurityWatcher, WatcherFinding, WatcherReport


class TestWatcherTrustScore:
    """Trust graduation: free agent earns autonomy through confirmed findings."""

    def test_initial_trust_is_zero(self):
        w = SecurityWatcher()
        assert w.trust_score == 0.0
        assert not w.can_auto_block

    def test_confirmed_finding_increases_trust(self):
        w = SecurityWatcher()
        w.record_mentor_feedback(finding_confirmed=True)
        assert w.trust_score == 0.1

    def test_false_positive_decreases_trust(self):
        w = SecurityWatcher()
        w._trust_score = 0.5
        w.record_mentor_feedback(finding_confirmed=False)
        assert w.trust_score == 0.45

    def test_trust_capped_at_1(self):
        w = SecurityWatcher()
        w._trust_score = 0.95
        w.record_mentor_feedback(finding_confirmed=True)
        assert w.trust_score == 1.0

    def test_trust_floored_at_0(self):
        w = SecurityWatcher()
        w._trust_score = 0.02
        w.record_mentor_feedback(finding_confirmed=False)
        assert w.trust_score == 0.0

    def test_auto_block_at_threshold(self):
        w = SecurityWatcher()
        w._trust_score = 0.7
        assert w.can_auto_block

    def test_no_auto_block_below_threshold(self):
        w = SecurityWatcher()
        w._trust_score = 0.69
        assert not w.can_auto_block

    def test_graduation_sequence(self):
        """7 confirmed findings = trust 0.7 = auto-block earned."""
        w = SecurityWatcher()
        for _ in range(7):
            w.record_mentor_feedback(finding_confirmed=True)
        assert w.trust_score == pytest.approx(0.7, abs=0.01)
        assert w.can_auto_block

    def test_mixed_feedback_sequence(self):
        """5 confirmed, 2 false positives = 0.5 - 0.1 = 0.4."""
        w = SecurityWatcher()
        for _ in range(5):
            w.record_mentor_feedback(finding_confirmed=True)
        for _ in range(2):
            w.record_mentor_feedback(finding_confirmed=False)
        assert w.trust_score == pytest.approx(0.4, abs=0.01)


class TestPostIngestScan:
    """Post-ingest scans detect secrets, tenant issues, and injections."""

    def test_detects_anthropic_api_key(self):
        w = SecurityWatcher()
        report = w.scan_post_ingest(
            raw_text="Use this key: sk-ant-api03-abcdefghijklmnopqrstuvwxyz",
            nodes_written=[],
            tenant_id="test-tenant",
        )
        assert report.has_findings
        assert report.findings[0].category == "secret_exposure"
        assert report.findings[0].severity == "critical"

    def test_detects_jwt_in_text(self):
        w = SecurityWatcher()
        report = w.scan_post_ingest(
            raw_text="Token: eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.abc123def456ghi",
            nodes_written=[],
            tenant_id="test-tenant",
        )
        assert any(f.category == "secret_exposure" for f in report.findings)

    def test_detects_connection_string(self):
        w = SecurityWatcher()
        report = w.scan_post_ingest(
            raw_text="Connect to neo4j+s://admin:password@db.neo4j.io",
            nodes_written=[],
            tenant_id="test-tenant",
        )
        assert any(f.category == "secret_exposure" for f in report.findings)

    def test_clean_text_no_findings(self):
        w = SecurityWatcher()
        report = w.scan_post_ingest(
            raw_text="We decided to use React Three Fiber for 3D visualization",
            nodes_written=[],
            tenant_id="test-tenant",
        )
        assert not report.has_findings

    def test_high_unicode_ratio_flagged(self):
        w = SecurityWatcher()
        # Simulate homoglyph attack (Cyrillic characters mimicking Latin)
        text = "\u0430" * 40 + " normal text here"  # Cyrillic 'а' U+0430
        report = w.scan_post_ingest(
            raw_text=text,
            nodes_written=[],
            tenant_id="test-tenant",
        )
        assert any(f.category == "injection" for f in report.findings)

    def test_report_metadata(self):
        w = SecurityWatcher()
        w._trust_score = 0.5
        report = w.scan_post_ingest(
            raw_text="Clean text",
            nodes_written=[],
            tenant_id="test-tenant",
        )
        assert report.scan_type == "post_ingest"
        assert report.watcher_trust_score == 0.5
        assert report.duration_ms >= 0


class TestWatcherReportAggregation:
    """Report aggregation and properties."""

    def test_critical_count(self):
        report = WatcherReport(scan_type="test")
        report.findings = [
            WatcherFinding(category="a", severity="critical", description="x"),
            WatcherFinding(category="b", severity="high", description="y"),
            WatcherFinding(category="c", severity="critical", description="z"),
        ]
        assert report.critical_count == 2

    def test_has_findings(self):
        empty = WatcherReport(scan_type="test")
        assert not empty.has_findings

        nonempty = WatcherReport(scan_type="test")
        nonempty.findings = [WatcherFinding(category="a", severity="low", description="x")]
        assert nonempty.has_findings


class TestEscalationBehavior:
    """Findings below trust threshold get escalated, above get auto-blocked."""

    def test_low_trust_escalates(self):
        w = SecurityWatcher()
        w._trust_score = 0.3
        report = w.scan_post_ingest(
            raw_text="Secret: sk-ant-api03-abcdefghijklmnopqrstuvwxyz",
            nodes_written=[],
            tenant_id="test",
        )
        finding = report.findings[0]
        assert finding.escalated
        assert not finding.auto_blocked

    def test_high_trust_auto_blocks(self):
        w = SecurityWatcher()
        w._trust_score = 0.8
        report = w.scan_post_ingest(
            raw_text="Secret: sk-ant-api03-abcdefghijklmnopqrstuvwxyz",
            nodes_written=[],
            tenant_id="test",
        )
        finding = report.findings[0]
        assert finding.auto_blocked
        assert not finding.escalated

    def test_no_mentor_available(self):
        w = SecurityWatcher()
        result = w.escalate_to_mentor(
            WatcherFinding(category="test", severity="low", description="test")
        )
        assert result is None  # No mentor configured
