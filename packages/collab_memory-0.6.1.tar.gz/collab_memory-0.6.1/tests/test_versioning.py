"""
tests/test_versioning.py — Automatic document versioning tests.

Tests the SUPERSEDED_BY chain, auto-duplicate detection, and version
filtering in read paths. This ensures agents never retrieve stale
decisions/constraints/preferences when a newer version exists.
"""
import pytest
from unittest.mock import MagicMock, patch, call
from datetime import datetime, timezone


class TestSupersedNode:
    """Test the supersede_node() primitive."""

    def test_supersede_sets_flags_and_creates_edge(self):
        from collab_memory.graph.neo4j_backend import Neo4jBackend

        backend = Neo4jBackend.__new__(Neo4jBackend)
        backend._configs = {}

        writes = []
        def mock_tx_write(query, **params):
            writes.append((query.strip(), params))
        backend._tx_write = mock_tx_write

        backend.supersede_node(
            old_id="dec_old1",
            new_id="dec_new1",
            node_type="Decision",
            reason="test_supersede",
        )

        # Should have 3 writes: mark superseded, set status, create edge
        assert len(writes) == 3
        # First write marks is_superseded
        assert "is_superseded = true" in writes[0][0]
        assert writes[0][1]["old_id"] == "dec_old1"
        assert writes[0][1]["new_id"] == "dec_new1"
        # Second sets status='superseded' for Decision
        assert "status = 'superseded'" in writes[1][0]
        # Third creates SUPERSEDED_BY edge
        assert "SUPERSEDED_BY" in writes[2][0]
        assert writes[2][1]["old_id"] == "dec_old1"
        assert writes[2][1]["new_id"] == "dec_new1"

    def test_supersede_constraint_skips_status_update(self):
        from collab_memory.graph.neo4j_backend import Neo4jBackend

        backend = Neo4jBackend.__new__(Neo4jBackend)
        writes = []
        def mock_tx_write(query, **params):
            writes.append((query.strip(), params))
        backend._tx_write = mock_tx_write

        backend.supersede_node(
            old_id="con_old1",
            new_id="con_new1",
            node_type="Constraint",
            reason="updated_scope",
        )

        # Constraint: 2 writes (mark superseded + edge), no status update
        assert len(writes) == 2
        for q, _ in writes:
            assert "status = 'superseded'" not in q


class TestFindSemanticDuplicate:
    """Test duplicate detection logic."""

    def test_exact_match_found(self):
        from collab_memory.graph.neo4j_backend import Neo4jBackend

        backend = Neo4jBackend.__new__(Neo4jBackend)
        backend._tx_read = MagicMock(return_value=[{"id": "dec_existing"}])

        result = backend._find_semantic_duplicate(
            node_type="Decision",
            description="Use Neo4j for graph storage",
            project_id="prj_test",
            module="infrastructure",
            exclude_id="dec_new",
        )

        assert result == "dec_existing"
        # Should only need exact match (first call)
        assert backend._tx_read.call_count == 1

    def test_no_match_returns_none(self):
        from collab_memory.graph.neo4j_backend import Neo4jBackend

        backend = Neo4jBackend.__new__(Neo4jBackend)
        backend._tx_read = MagicMock(return_value=[])

        result = backend._find_semantic_duplicate(
            node_type="Decision",
            description="Brand new decision that doesn't exist yet in the graph at all",
            project_id="prj_test",
        )

        assert result is None

    def test_short_description_skipped(self):
        from collab_memory.graph.neo4j_backend import Neo4jBackend

        backend = Neo4jBackend.__new__(Neo4jBackend)
        backend._tx_read = MagicMock()

        result = backend._find_semantic_duplicate(
            node_type="Decision",
            description="short",
            project_id="prj_test",
        )

        assert result is None
        backend._tx_read.assert_not_called()

    def test_prefix_match_for_minor_edits(self):
        from collab_memory.graph.neo4j_backend import Neo4jBackend

        backend = Neo4jBackend.__new__(Neo4jBackend)
        # First call (exact) returns nothing, second call (prefix) finds a match
        backend._tx_read = MagicMock(side_effect=[[], [{"id": "dec_prefix"}]])

        result = backend._find_semantic_duplicate(
            node_type="Decision",
            description="Use Neo4j AuraDB for graph storage — picked free tier for MVP development phase",
            project_id="prj_test",
        )

        assert result == "dec_prefix"
        assert backend._tx_read.call_count == 2


class TestAutoVersioningInSaveNode:
    """Test that save_node() auto-supersedes duplicates."""

    def test_save_node_auto_supersedes_duplicate(self):
        from collab_memory.graph.neo4j_backend import Neo4jBackend
        from collab_memory.schema import Decision

        backend = Neo4jBackend.__new__(Neo4jBackend)
        backend._tx_write = MagicMock()
        backend._tx_read = MagicMock(return_value=[])

        # Mock _find_semantic_duplicate to return an old node
        backend._find_semantic_duplicate = MagicMock(return_value="dec_old123")
        backend.supersede_node = MagicMock()

        node = Decision(
            id="dec_new456",
            made_in="session_1",
            description="Use PyJWT instead of python-jose",
            project_id="prj_test",
        )
        backend.save_node(node)

        # Should call supersede_node with old_id
        backend.supersede_node.assert_called_once_with(
            old_id="dec_old123",
            new_id="dec_new456",
            node_type="Decision",
            reason="auto_duplicate_detection",
        )

    def test_save_node_no_supersede_when_no_duplicate(self):
        from collab_memory.graph.neo4j_backend import Neo4jBackend
        from collab_memory.schema import Decision

        backend = Neo4jBackend.__new__(Neo4jBackend)
        backend._tx_write = MagicMock()
        backend._tx_read = MagicMock(return_value=[])
        backend._find_semantic_duplicate = MagicMock(return_value=None)
        backend.supersede_node = MagicMock()

        node = Decision(
            id="dec_unique",
            made_in="session_1",
            description="Completely new decision",
            project_id="prj_test",
        )
        backend.save_node(node)

        backend.supersede_node.assert_not_called()

    def test_save_node_skips_versioning_for_attempt(self):
        from collab_memory.graph.neo4j_backend import Neo4jBackend
        from collab_memory.schema import Attempt

        backend = Neo4jBackend.__new__(Neo4jBackend)
        backend._tx_write = MagicMock()
        backend._tx_read = MagicMock(return_value=[])
        backend._find_semantic_duplicate = MagicMock()

        node = Attempt(
            id="att_1",
            tried_in="session_1",
            description="Tried using Redis",
        )
        backend.save_node(node)

        # Attempts are not versioned
        backend._find_semantic_duplicate.assert_not_called()


class TestGetVersionChain:
    """Test version history retrieval."""

    def test_chain_returns_ordered_history(self):
        from collab_memory.graph.neo4j_backend import Neo4jBackend

        backend = Neo4jBackend.__new__(Neo4jBackend)
        backend._tx_read = MagicMock(return_value=[
            {"id": "dec_v1", "description": "Use Redis", "version": 1,
             "created_at": "2026-03-01", "is_superseded": True,
             "superseded_by": "dec_v2", "superseded_reason": "auto"},
            {"id": "dec_v2", "description": "Use Neo4j", "version": 2,
             "created_at": "2026-03-15", "is_superseded": False,
             "superseded_by": None, "superseded_reason": None},
        ])

        chain = backend.get_version_chain("dec_v2", node_type="Decision")
        assert len(chain) == 2
        assert chain[0]["id"] == "dec_v1"
        assert chain[1]["id"] == "dec_v2"

    def test_single_node_no_chain(self):
        from collab_memory.graph.neo4j_backend import Neo4jBackend

        backend = Neo4jBackend.__new__(Neo4jBackend)
        # First call (chain query) returns empty, second call (single) returns the node
        backend._tx_read = MagicMock(side_effect=[
            [],
            [{"id": "dec_solo", "description": "Solo decision", "version": 1,
              "created_at": "2026-04-01", "is_superseded": None,
              "superseded_by": None, "superseded_reason": None}],
        ])

        chain = backend.get_version_chain("dec_solo", node_type="Decision")
        assert len(chain) == 1
        assert chain[0]["id"] == "dec_solo"


class TestSupersededFiltering:
    """Test that superseded nodes are filtered out of read paths."""

    def test_get_decisions_filters_superseded(self):
        """Decisions already had is_superseded filtering — verify it's present."""
        import inspect
        from collab_memory.graph.neo4j_backend import Neo4jBackend
        source = inspect.getsource(Neo4jBackend.get_decisions)
        assert "is_superseded" in source

    def test_get_constraints_filters_superseded(self):
        """Constraints should now filter superseded nodes."""
        import inspect
        from collab_memory.graph.neo4j_backend import Neo4jBackend
        source = inspect.getsource(Neo4jBackend.get_constraints)
        assert "is_superseded" in source

    def test_get_preferences_filters_superseded(self):
        """Preferences should now filter superseded nodes."""
        import inspect
        from collab_memory.graph.neo4j_backend import Neo4jBackend
        source = inspect.getsource(Neo4jBackend.get_preferences)
        assert "is_superseded" in source
