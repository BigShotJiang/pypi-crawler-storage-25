"""
Agent inbox + task lease hardening tests.

Focuses on:
- Inbox tenant_id write/read parity and tenant-scoped ack behavior
- Task claim lease fields and heartbeat refresh
"""
from __future__ import annotations

from starlette.testclient import TestClient


class _CoordinationGraphStub:
    def __init__(self):
        self.tasks: dict[str, dict] = {}
        self.messages: dict[str, dict] = {}
        self.events: list[dict] = []

    def _tx_read(self, query: str, **params):
        q = " ".join(query.split())
        if "MATCH (t:Task {id: $id})" in q and "RETURN t" in q:
            t = self.tasks.get(params["id"])
            return [{"t": t.copy()}] if t and t.get("tenant_id") == params.get("tid") else []
        if "MATCH (m:AgentMessage)" in q and "RETURN m" in q:
            out = []
            for m in self.messages.values():
                if m.get("target") != params.get("target"):
                    continue
                if m.get("tenant_id") != params.get("tid"):
                    continue
                if "m.status = 'unread'" in q and m.get("status") != "unread":
                    continue
                if "m.status = 'read'" in q and m.get("status") != "read":
                    continue
                out.append({"m": m.copy()})
            return out[: params.get("limit", 20)]
        if "MATCH (m:AgentMessage {id: $id})" in q and "RETURN m" in q:
            m = self.messages.get(params["id"])
            if not m:
                return []
            # Mirror server-side ownership guard for ack lookups.
            if "tid" in params and m.get("tenant_id") != params.get("tid"):
                return []
            if "target" in params and m.get("target") != params.get("target"):
                return []
            return [{"m": m.copy()}]
        return []

    def _tx_write(self, query: str, **params):
        q = " ".join(query.split())
        if "CREATE (m:AgentMessage" in q:
            self.messages[params["id"]] = {
                "id": params["id"],
                "sender": params["sender"],
                "target": params["target"],
                "subject": params["subject"],
                "body": params["body"],
                "priority": params["priority"],
                "topic": params["topic"],
                "project_id": params["project_id"],
                "tenant_id": params["tenant_id"],
                "status": "unread",
                "created_at": params["created_at"],
                "expires_at": params["expires_at"],
            }
            return
        if "MATCH (m:AgentMessage {id: $id})" in q and "SET m.status = 'read'" in q:
            m = self.messages.get(params["id"])
            if not m:
                return
            if m.get("tenant_id") != params.get("tid"):
                return
            if m.get("target") != params.get("target"):
                return
            m["status"] = "read"
            return
        if "MERGE (n:Task {id: $id}) SET" in q:
            task = self.tasks.get(params["id"], {}).copy()
            for k, v in params.items():
                task[k] = v
            self.tasks[params["id"]] = task
            return
        if "MATCH (t:Task {id: $id}) WHERE t.tenant_id = $tid SET" in q:
            task = self.tasks.get(params["id"])
            if not task or task.get("tenant_id") != params.get("tid"):
                return
            # Claim lock helper writes owner/expiry params while Cypher maps them
            # to canonical task fields.
            if "t.claim_locked_by = $owner" in q and "t.claim_expires_at = $exp" in q:
                task["claim_locked_by"] = params.get("owner", "")
                task["claim_expires_at"] = params.get("exp", "")
                task["locked_by"] = params.get("owner", "")
                task["locked_until"] = params.get("exp", "")
                self.tasks[params["id"]] = task
                return
            if "REMOVE t.claim_locked_by, t.claim_expires_at, t.locked_by, t.locked_until" in q:
                task.pop("claim_locked_by", None)
                task.pop("claim_expires_at", None)
                task.pop("locked_by", None)
                task.pop("locked_until", None)
                self.tasks[params["id"]] = task
                return
            for k, v in params.items():
                if k not in {"id", "tid"}:
                    task[k] = v
            self.tasks[params["id"]] = task
            return
        if "CREATE (c:CommunicationEvent" in q:
            self.events.append(params.copy())
            return
        # Ignore relationship writes for this stub.
        return


def _make_client(monkeypatch, *, role: str = "contributor", agent_id: str = "agent_alpha", tenant_id: str = "tenant_test"):
    from collab_memory.api import server as srv
    from collab_memory.abac import AgentContext

    graph = _CoordinationGraphStub()
    monkeypatch.setattr(srv, "graph", graph)
    monkeypatch.setattr(srv, "_API_KEY", "test_key")
    monkeypatch.setattr(srv, "_VALID_API_KEYS", {"test_key"})

    def _resolve_agent_context(_key, graph=None):
        return AgentContext(
            role=role,
            agent_id=agent_id,
            key="test_key",
            tenant_id=tenant_id,
            plan="pro",
        )

    monkeypatch.setattr(srv, "resolve_agent_context", _resolve_agent_context)
    return TestClient(srv.app), graph


def test_agent_inbox_persists_tenant_and_reads_in_scope(monkeypatch):
    client, graph = _make_client(monkeypatch, tenant_id="tenant_a")

    sent = client.post(
        "/agent/inbox",
        json={"to": "agent_alpha", "subject": "handoff", "body": "context", "project_id": "prj_1"},
        headers={"X-API-Key": "test_key"},
    )
    assert sent.status_code == 200
    msg_id = sent.json()["message_id"]
    assert graph.messages[msg_id]["tenant_id"] == "tenant_a"

    inbox = client.get("/agent/inbox", headers={"X-API-Key": "test_key"})
    assert inbox.status_code == 200
    assert inbox.json()["count"] == 1
    assert inbox.json()["messages"][0]["id"] == msg_id


def test_agent_inbox_ack_enforces_tenant_and_target(monkeypatch):
    # Sender in tenant_a posts to agent_beta.
    client_a, graph = _make_client(monkeypatch, agent_id="agent_alpha", tenant_id="tenant_a")
    sent = client_a.post(
        "/agent/inbox",
        json={"to": "agent_beta", "subject": "handoff", "body": "please take over"},
        headers={"X-API-Key": "test_key"},
    )
    msg_id = sent.json()["message_id"]
    assert graph.messages[msg_id]["status"] == "unread"

    # Different tenant cannot ack.
    from collab_memory.api import server as srv
    from collab_memory.abac import AgentContext

    def _resolve_other_tenant(_key, graph=None):
        return AgentContext(
            role="contributor",
            agent_id="agent_beta",
            key="test_key",
            tenant_id="tenant_b",
            plan="pro",
        )

    monkeypatch.setattr(srv, "resolve_agent_context", _resolve_other_tenant)
    client_b = TestClient(srv.app)
    bad = client_b.post(f"/agent/inbox/{msg_id}/ack", headers={"X-API-Key": "test_key"})
    assert bad.status_code == 404
    assert graph.messages[msg_id]["status"] == "unread"


def test_task_claim_sets_lease_and_heartbeat_renews(monkeypatch):
    client, _graph = _make_client(monkeypatch)
    created = client.post("/tasks", json={"title": "Lease claim task"}, headers={"X-API-Key": "test_key"})
    task_id = created.json()["id"]

    claim = client.post(
        f"/tasks/{task_id}/protocol",
        json={"action": "claim"},
        headers={"X-API-Key": "test_key"},
    )
    assert claim.status_code == 200
    task = claim.json()["task"]
    assert task["status"] == "in_progress"
    assert task["claim_locked_by"] == "agent_alpha"
    assert task["claim_expires_at"]

    hb = client.post(
        f"/tasks/{task_id}/heartbeat",
        json={"ttl_seconds": 300},
        headers={"X-API-Key": "test_key"},
    )
    assert hb.status_code == 200
    hb_data = hb.json()
    assert hb_data["task_id"] == task_id
    assert hb_data["status"] == "in_progress"
    assert hb_data["assignee"] == "agent_alpha"
    assert hb_data["claim_expires_at"]


def test_claim_lock_blocks_other_agent_until_expiry(monkeypatch):
    client, graph = _make_client(monkeypatch, agent_id="agent_alpha", tenant_id="tenant_a")
    created = client.post("/tasks", json={"title": "Lock contention task"}, headers={"X-API-Key": "test_key"})
    task_id = created.json()["id"]
    claim = client.post(f"/tasks/{task_id}/protocol", json={"action": "claim"}, headers={"X-API-Key": "test_key"})
    assert claim.status_code == 200

    # Switch identity to another agent in same tenant; should be blocked by active lease.
    from collab_memory.api import server as srv
    from collab_memory.abac import AgentContext

    def _resolve_beta(_key, graph=None):
        return AgentContext(
            role="contributor",
            agent_id="agent_beta",
            key="test_key",
            tenant_id="tenant_a",
            plan="pro",
        )

    monkeypatch.setattr(srv, "resolve_agent_context", _resolve_beta)
    client_beta = TestClient(srv.app)
    blocked = client_beta.put(
        f"/tasks/{task_id}",
        json={"status": "in_progress"},
        headers={"X-API-Key": "test_key"},
    )
    assert blocked.status_code == 409
    detail = blocked.json()["detail"]
    assert ("lock-held" in detail) or ("already claimed" in detail)


def test_agent_inbox_ack_succeeds_for_target_in_same_tenant(monkeypatch):
    from collab_memory.api import server as srv
    from collab_memory.abac import AgentContext

    client_a, graph = _make_client(monkeypatch, agent_id="agent_alpha", tenant_id="tenant_a")
    sent = client_a.post(
        "/agent/inbox",
        json={"to": "agent_beta", "subject": "handoff", "body": "please take over"},
        headers={"X-API-Key": "test_key"},
    )
    assert sent.status_code == 200
    msg_id = sent.json()["message_id"]
    assert graph.messages[msg_id]["status"] == "unread"

    def _resolve_target_same_tenant(_key, graph=None):
        return AgentContext(
            role="contributor",
            agent_id="agent_beta",
            key="test_key",
            tenant_id="tenant_a",
            plan="pro",
        )

    monkeypatch.setattr(srv, "resolve_agent_context", _resolve_target_same_tenant)
    client_b = TestClient(srv.app)
    ok = client_b.post(f"/agent/inbox/{msg_id}/ack", headers={"X-API-Key": "test_key"})
    assert ok.status_code == 200
    assert ok.json()["acknowledged"] is True
    assert graph.messages[msg_id]["status"] == "read"

