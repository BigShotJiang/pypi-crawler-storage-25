"""
Task coordination protocol enforcement tests.

Validates strict claim/handoff/review/done transitions and ownership guards
for parallel multi-agent execution.
"""
from __future__ import annotations

from starlette.testclient import TestClient


class _GraphStub:
    def __init__(self):
        self.tasks: dict[str, dict] = {}
        self.events: list[dict] = []

    def _tx_read(self, query: str, **params):
        q = " ".join(query.split())
        if "MATCH (t:Task {id: $id})" in q and "RETURN t" in q:
            t = self.tasks.get(params["id"])
            return [{"t": t.copy()}] if t and t.get("tenant_id") == params.get("tid") else []
        if "MATCH (t:Task) WHERE t.tenant_id = $tid" in q and "RETURN t" in q:
            out = [t.copy() for t in self.tasks.values() if t.get("tenant_id") == params.get("tid")]
            return [{"t": t} for t in out]
        return []

    def _tx_write(self, query: str, **params):
        q = " ".join(query.split())
        if "MERGE (n:Task {id: $id}) SET" in q:
            task = self.tasks.get(params["id"], {}).copy()
            for k, v in params.items():
                task[k] = v
            self.tasks[params["id"]] = task
            return
        if "MATCH (t:Task {id: $id}) WHERE t.tenant_id = $tid SET" in q:
            task = self.tasks.get(params["id"])
            if not task or task.get("tenant_id") != params.get("tid"):
                return
            for k, v in params.items():
                if k not in {"id", "tid"}:
                    task[k] = v
            self.tasks[params["id"]] = task
            return
        if "CREATE (c:CommunicationEvent" in q:
            self.events.append(params.copy())
            return
        if "DETACH DELETE t" in q:
            self.tasks.pop(params["id"], None)
            return
        # Ignore edge writes in this unit stub (BELONGS_TO/IN_SPRINT/BLOCKED_BY)
        return


def _make_client(monkeypatch):
    from collab_memory.api import server as srv
    from collab_memory.abac import AgentContext

    graph = _GraphStub()
    monkeypatch.setattr(srv, "graph", graph)
    monkeypatch.setattr(srv, "_API_KEY", "test_key")
    monkeypatch.setattr(srv, "_VALID_API_KEYS", {"test_key"})

    def _resolve_agent_context(_key, graph=None):
        return AgentContext(
            role="contributor",
            agent_id="agent_alpha",
            key="test_key",
            tenant_id="tenant_test",
            plan="pro",
        )

    monkeypatch.setattr(srv, "resolve_agent_context", _resolve_agent_context)
    return TestClient(srv.app), graph


def test_claim_sets_assignee_and_in_progress(monkeypatch):
    client, _ = _make_client(monkeypatch)
    created = client.post("/tasks", json={"title": "Coordination task"}, headers={"X-API-Key": "test_key"})
    assert created.status_code == 200
    task_id = created.json()["id"]

    resp = client.post(
        f"/tasks/{task_id}/protocol",
        json={"action": "claim", "note": "starting work"},
        headers={"X-API-Key": "test_key"},
    )
    assert resp.status_code == 200
    body = resp.json()
    assert body["task"]["status"] == "in_progress"
    assert body["task"]["assignee"] == "agent_alpha"


def test_done_requires_review_first(monkeypatch):
    client, _ = _make_client(monkeypatch)
    created = client.post("/tasks", json={"title": "Review gate task"}, headers={"X-API-Key": "test_key"})
    task_id = created.json()["id"]
    client.post(f"/tasks/{task_id}/protocol", json={"action": "claim"}, headers={"X-API-Key": "test_key"})

    bad = client.put(
        f"/tasks/{task_id}",
        json={"status": "done"},
        headers={"X-API-Key": "test_key"},
    )
    assert bad.status_code == 409
    assert "review" in bad.json()["detail"]


def test_handoff_requires_target(monkeypatch):
    client, _ = _make_client(monkeypatch)
    created = client.post("/tasks", json={"title": "Handoff task"}, headers={"X-API-Key": "test_key"})
    task_id = created.json()["id"]
    client.post(f"/tasks/{task_id}/protocol", json={"action": "claim"}, headers={"X-API-Key": "test_key"})

    bad = client.post(
        f"/tasks/{task_id}/protocol",
        json={"action": "handoff"},
        headers={"X-API-Key": "test_key"},
    )
    assert bad.status_code == 400
    assert "handoff_to" in bad.json()["detail"]


def test_submit_review_then_approve_done(monkeypatch):
    client, graph = _make_client(monkeypatch)
    created = client.post("/tasks", json={"title": "Protocol completion task"}, headers={"X-API-Key": "test_key"})
    task_id = created.json()["id"]
    client.post(f"/tasks/{task_id}/protocol", json={"action": "claim"}, headers={"X-API-Key": "test_key"})
    r1 = client.post(f"/tasks/{task_id}/protocol", json={"action": "submit_review"}, headers={"X-API-Key": "test_key"})
    assert r1.status_code == 200
    assert r1.json()["task"]["status"] == "review"

    r2 = client.post(f"/tasks/{task_id}/protocol", json={"action": "approve"}, headers={"X-API-Key": "test_key"})
    assert r2.status_code == 200
    assert r2.json()["task"]["status"] == "done"
    assert graph.events, "Protocol action should create a coordination CommunicationEvent"
