"""
tests/test_auth.py — Auth Module Tests

Tests for:
    - Supabase client bypass mode (local dev)
    - Vault encryption/decryption (AES-256-GCM)
    - Vault dev mode (plaintext base64)
    - Middleware JWT extraction
    - Middleware API key fallback
    - Route models
"""

import pytest
import os
from unittest.mock import MagicMock, patch


# ── Vault Tests ──────────────────────────────────────────────────────────────

class TestLLMKeyVault:
    """Test AES-256-GCM vault encryption."""

    def test_generate_master_key(self):
        from collab_memory.auth.vault import LLMKeyVault
        key = LLMKeyVault.generate_master_key()
        assert len(key) == 64  # 32 bytes = 64 hex chars
        # Should be valid hex
        bytes.fromhex(key)

    def test_encrypt_decrypt_with_key(self):
        from collab_memory.auth.vault import LLMKeyVault
        key = LLMKeyVault.generate_master_key()
        vault = LLMKeyVault(master_key_hex=key)

        assert vault.is_configured

        plaintext = "sk-ant-api03-FAKE-KEY-1234567890"
        encrypted = vault.encrypt(plaintext)

        # Should not contain plaintext
        assert plaintext not in encrypted
        # Should not start with PLAIN: prefix
        assert not encrypted.startswith("PLAIN:")

        # Decrypt should return original
        decrypted = vault.decrypt(encrypted)
        assert decrypted == plaintext

    def test_different_ivs_produce_different_ciphertexts(self):
        """Each encryption should use a unique IV."""
        from collab_memory.auth.vault import LLMKeyVault
        key = LLMKeyVault.generate_master_key()
        vault = LLMKeyVault(master_key_hex=key)

        plaintext = "sk-test-key-same-input"
        enc1 = vault.encrypt(plaintext)
        enc2 = vault.encrypt(plaintext)

        # Same plaintext should produce different ciphertexts
        assert enc1 != enc2

        # Both should decrypt to same value
        assert vault.decrypt(enc1) == plaintext
        assert vault.decrypt(enc2) == plaintext

    def test_dev_mode_no_key(self):
        """Without master key, vault stores as base64 (dev mode)."""
        from collab_memory.auth.vault import LLMKeyVault
        vault = LLMKeyVault(master_key_hex="")

        assert not vault.is_configured

        plaintext = "sk-dev-mode-test"
        encrypted = vault.encrypt(plaintext)

        assert encrypted.startswith("PLAIN:")
        decrypted = vault.decrypt(encrypted)
        assert decrypted == plaintext

    def test_invalid_key_length(self):
        """Key with wrong length should fail gracefully."""
        from collab_memory.auth.vault import LLMKeyVault
        vault = LLMKeyVault(master_key_hex="abcd1234")  # Too short
        assert not vault.is_configured

    def test_tampered_ciphertext_fails(self):
        """Modifying ciphertext should fail decryption (GCM auth tag)."""
        from collab_memory.auth.vault import LLMKeyVault
        import base64

        key = LLMKeyVault.generate_master_key()
        vault = LLMKeyVault(master_key_hex=key)

        encrypted = vault.encrypt("sk-secure-key")

        # Tamper with the ciphertext
        blob = bytearray(base64.b64decode(encrypted))
        blob[15] ^= 0xFF  # Flip a byte
        tampered = base64.b64encode(bytes(blob)).decode()

        with pytest.raises(Exception):
            vault.decrypt(tampered)


# ── Supabase Client Tests ────────────────────────────────────────────────────

class TestSupabaseClient:
    """Test Supabase client in bypass mode."""

    def test_bypass_mode_no_env(self):
        """Without SUPABASE_URL, should enter bypass mode."""
        # Ensure no Supabase env vars
        with patch.dict(os.environ, {}, clear=True):
            from collab_memory.auth.jwt_provider import JWTAuthProvider
            client = JWTAuthProvider()
            assert not client.is_configured

    def test_bypass_signup(self):
        with patch.dict(os.environ, {}, clear=True):
            from collab_memory.auth.jwt_provider import JWTAuthProvider
            client = JWTAuthProvider()
            result = client.signup("test@example.com", "password123")

            assert result["email"] == "test@example.com"
            assert result["tenant_id"] == "local-tenant"
            assert result["_bypass"] is True

    def test_bypass_login(self):
        with patch.dict(os.environ, {}, clear=True):
            from collab_memory.auth.jwt_provider import JWTAuthProvider
            client = JWTAuthProvider()
            result = client.login("test@example.com", "password123")

            assert result["email"] == "test@example.com"
            assert result.get("access_token") == "bypass-token"

    def test_bypass_get_user(self):
        with patch.dict(os.environ, {}, clear=True):
            from collab_memory.auth.jwt_provider import JWTAuthProvider
            client = JWTAuthProvider()
            user = client.get_user("any-token")

            assert user is not None
            assert user.user_id == "local-dev"
            assert user.tenant_id == "local-tenant"
            assert user.plan == "enterprise"
            assert user.role == "admin"


class TestInstanceZeroSignup:
    def test_signup_rehomes_configured_shared_member(self, monkeypatch):
        pytest.importorskip("argon2")
        monkeypatch.setenv("JWT_SECRET", "x" * 32)
        monkeypatch.setenv("INSTANCE_ZERO_TENANT_ID", "tenant-shared-demo")
        monkeypatch.setenv("INSTANCE_ZERO_MEMBER_EMAILS", "shared@demo.test")

        from collab_memory.auth.jwt_provider import JWTAuthProvider
        provider = JWTAuthProvider(neo4j_backend=None)

        result = provider.signup("shared@demo.test", "Password1")
        assert "error" not in result
        assert result["tenant_id"] == "tenant-shared-demo"


# ── Middleware Tests ─────────────────────────────────────────────────────────

class TestMiddleware:
    """Test JWT middleware with mock requests."""

    def test_no_auth_header_returns_none(self):
        from collab_memory.auth.middleware import get_current_user

        request = MagicMock()
        request.headers = MagicMock()
        request.headers.get = MagicMock(return_value="")

        user = get_current_user(request)
        assert user is None

    def test_apikey_header_returns_none(self):
        """X-API-Key should NOT be handled by JWT middleware."""
        from collab_memory.auth.middleware import get_current_user

        request = MagicMock()
        request.headers = MagicMock()
        request.headers.get = MagicMock(side_effect=lambda key, default="": {
            "Authorization": "",
            "X-API-Key": "some-key",
        }.get(key, default))

        user = get_current_user(request)
        assert user is None  # JWT middleware doesn't handle API keys

    def test_bearer_bypass_token(self):
        """Bypass token should fall through (not treated as real JWT)."""
        from collab_memory.auth.middleware import get_current_user

        request = MagicMock()
        request.headers = MagicMock()
        request.headers.get = MagicMock(side_effect=lambda key, default="": {
            "Authorization": "Bearer bypass-token",
        }.get(key, default))

        user = get_current_user(request)
        assert user is None  # bypass-token explicitly skipped


# ── Auth User Model Tests ────────────────────────────────────────────────────

class TestAuthUser:
    """Test AuthUser dataclass."""

    def test_defaults(self):
        from collab_memory.auth.jwt_provider import AuthUser

        user = AuthUser(
            user_id="test-id",
            email="test@example.com",
            tenant_id="tenant-123",
        )
        assert user.plan == "pro"
        assert user.role == "contributor"

    def test_custom_values(self):
        from collab_memory.auth.jwt_provider import AuthUser

        user = AuthUser(
            user_id="test-id",
            email="test@example.com",
            tenant_id="tenant-123",
            plan="pro",
            role="admin",
        )
        assert user.plan == "pro"
        assert user.role == "admin"


# ── Password Policy Tests ───────────────────────────────────────────────────


class TestPasswordPolicy:
    """Test NIST SP 800-63B-4 aligned password policy."""

    def test_valid_password(self):
        from collab_memory.auth.jwt_provider import JWTAuthProvider
        assert JWTAuthProvider.validate_password("StrongP4ss") is None

    def test_too_short(self):
        from collab_memory.auth.jwt_provider import JWTAuthProvider
        err = JWTAuthProvider.validate_password("Sh0rt")
        assert err is not None
        assert "8 characters" in err

    def test_no_uppercase(self):
        from collab_memory.auth.jwt_provider import JWTAuthProvider
        err = JWTAuthProvider.validate_password("alllower1")
        assert err is not None
        assert "uppercase" in err

    def test_no_lowercase(self):
        from collab_memory.auth.jwt_provider import JWTAuthProvider
        err = JWTAuthProvider.validate_password("ALLUPPER1")
        assert err is not None
        assert "lowercase" in err

    def test_no_digit(self):
        from collab_memory.auth.jwt_provider import JWTAuthProvider
        err = JWTAuthProvider.validate_password("NoDigitsHere")
        assert err is not None
        assert "digit" in err

    def test_long_password_ok(self):
        from collab_memory.auth.jwt_provider import JWTAuthProvider
        assert JWTAuthProvider.validate_password("A" * 50 + "a1") is None

    def test_signup_rejects_weak_password(self):
        from collab_memory.auth.jwt_provider import JWTAuthProvider
        provider = JWTAuthProvider.__new__(JWTAuthProvider)
        provider._secret = "test-secret"
        provider._is_production = False
        provider._neo4j = None
        provider._users = {}
        result = provider.signup("test@test.com", "weak")
        assert "error" in result
        assert "8 characters" in result["error"]


# ── Email uniqueness (normalized) ───────────────────────────────────────────


class TestEmailNormalization:
    def test_normalize_email(self):
        from collab_memory.auth.jwt_provider import normalize_email

        assert normalize_email("  A@B.C  ") == "a@b.c"
        assert normalize_email(None) == ""
        assert normalize_email("") == ""

    def test_in_memory_signup_rejects_case_variant_duplicate(self, monkeypatch):
        pytest.importorskip("argon2")
        monkeypatch.setenv("JWT_SECRET", "x" * 32)
        from collab_memory.auth.jwt_provider import JWTAuthProvider

        c = JWTAuthProvider(neo4j_backend=None)
        r1 = c.signup("User@Example.COM", "Password1")
        assert "error" not in r1
        assert r1["email"] == "user@example.com"
        r2 = c.signup("user@example.com", "Password1")
        assert "error" in r2
        assert "already" in r2["error"].lower() or "exists" in r2["error"].lower()

    def test_in_memory_login_is_case_insensitive(self, monkeypatch):
        pytest.importorskip("argon2")
        monkeypatch.setenv("JWT_SECRET", "x" * 32)
        from collab_memory.auth.jwt_provider import JWTAuthProvider

        c = JWTAuthProvider(neo4j_backend=None)
        assert "error" not in c.signup("Ab@Cd.ef", "Password1")
        r = c.login("AB@CD.EF", "Password1")
        assert "error" not in r
        assert r["email"] == "ab@cd.ef"


# ── Audit Logging Tests ─────────────────────────────────────────────────────


class TestAuditLogging:
    """Test auth audit event logging."""

    def test_audit_log_writes_to_neo4j(self):
        from collab_memory.auth.jwt_provider import JWTAuthProvider

        provider = JWTAuthProvider.__new__(JWTAuthProvider)
        provider._secret = "test-secret"
        provider._is_production = False
        mock_neo4j = MagicMock()
        provider._neo4j = mock_neo4j

        provider._audit_log("login", "test@test.com", True, "ok")

        mock_neo4j._tx_write.assert_called_once()
        call_args = mock_neo4j._tx_write.call_args
        assert "AuthAudit" in call_args[0][0]
        assert call_args[1]["event"] == "login"
        assert call_args[1]["email"] == "test@test.com"
        assert call_args[1]["success"] is True

    def test_audit_log_without_neo4j_does_not_crash(self):
        from collab_memory.auth.jwt_provider import JWTAuthProvider

        provider = JWTAuthProvider.__new__(JWTAuthProvider)
        provider._secret = "test-secret"
        provider._is_production = False
        provider._neo4j = None

        # Should not raise
        provider._audit_log("login", "test@test.com", False, "bad_password")

    def test_failed_login_creates_audit_entry(self):
        from collab_memory.auth.jwt_provider import JWTAuthProvider

        provider = JWTAuthProvider.__new__(JWTAuthProvider)
        provider._secret = "test-secret"
        provider._is_production = False
        provider._neo4j = None
        provider._users = {}

        result = provider.login("nonexistent@test.com", "anything")
        assert "error" in result
        # The audit log was called (we can't easily check without mocking logger,
        # but we verify the login path completes without errors)
