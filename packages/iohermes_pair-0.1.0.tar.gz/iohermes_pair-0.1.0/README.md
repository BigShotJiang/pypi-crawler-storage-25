# iohermes-pair

One-command pair tool for the **iosHermes** mobile app.

```bash
pip install iohermes-pair
iohermes-pair
```

That's it. The command:

1. Generates a unique pairing credential (stored in `~/.iohermes/bridge.json`).
2. Starts a tiny background daemon that proxies requests from your phone to your
   local Hermes / OpenAI-compatible LLM server (default: `http://127.0.0.1:8765`).
3. Saves a QR PNG (`./iohermes_pair.png`) and prints an ASCII QR.

Open the **iosHermes** iOS app → **My** → **+** → **Scan QR** and point at the
PNG. You'll be online from anywhere — 4G, hotel Wi-Fi, etc.

## Options

```text
iohermes-pair                       # default: connects to 127.0.0.1:8765
iohermes-pair --port 8642           # custom local port
iohermes-pair --name "My-Mac"       # custom display name
iohermes-pair --out ~/Desktop/p.png # custom PNG output
iohermes-pair --foreground          # don't daemonize (debug)
iohermes-pair --status              # is the daemon running?
iohermes-pair --stop                # stop the daemon
iohermes-pair --reset               # rotate credentials (old phones lose access)
iohermes-pair --json                # print only the JSON payload
```

## How it works

```
[ iOS App ]  ──websocket──▶  [ Relay (cloud) ]  ──websocket──▶  [ Daemon on your machine ]
                                                                           │
                                                                           ▼
                                                                  http://127.0.0.1:PORT
                                                                  (your Hermes / agent)
```

The daemon makes a single outbound WebSocket connection to the relay; no
inbound port is opened on your machine. All traffic is end-to-end between
your phone and your machine through a thin relay.

## Requirements

- Python 3.8+
- A Hermes-compatible / OpenAI-API-compatible HTTP server running on
  `localhost:PORT`. iosHermes works with any OpenAI-compatible chat completion
  endpoint at `/v1/chat/completions` (or the convenience wrapper at `/api/chat`).

## License

MIT
