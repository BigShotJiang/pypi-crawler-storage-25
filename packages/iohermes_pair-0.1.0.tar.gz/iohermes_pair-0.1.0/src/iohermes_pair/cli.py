"""
iohermes-pair · command-line interface.

Public commands:
    iohermes-pair                 # generate QR + start daemon
    iohermes-pair --status        # is the daemon running?
    iohermes-pair --stop          # stop the daemon
    iohermes-pair --reset         # rotate credentials
    iohermes-pair --foreground    # don't daemonize (debug)
    iohermes-pair --json          # print only the JSON payload

See `iohermes-pair --help` for the full option list.
"""
from __future__ import annotations

import argparse
import json
import os
import secrets
import signal
import socket
import subprocess
import sys
import time
from pathlib import Path
from typing import Optional

from . import __version__, bridge as _bridge
from ._relay import RELAY_BRIDGE_URL, RELAY_APP_URL, DEFAULT_LOCAL_PORT

# ── Paths ──────────────────────────────────────────────────────
CONFIG_DIR = Path.home() / ".iohermes"
CONFIG_FILE = CONFIG_DIR / "bridge.json"
PID_FILE = CONFIG_DIR / "bridge.pid"
LOG_FILE = CONFIG_DIR / "bridge.log"


# ── Pretty print helpers ───────────────────────────────────────
def _isatty() -> bool:
    try:
        return sys.stdout.isatty()
    except Exception:
        return False


def _c(s, code): return f"\033[{code}m{s}\033[0m" if _isatty() else s
def B(s): return _c(s, "1")
def D(s): return _c(s, "2")
def C(s): return _c(s, "36")
def G(s): return _c(s, "32")
def Y(s): return _c(s, "33")
def R(s): return _c(s, "31")


# ── Config ─────────────────────────────────────────────────────
def load_or_create_config() -> dict:
    cfg = {}
    if CONFIG_FILE.exists():
        try:
            cfg = json.loads(CONFIG_FILE.read_text())
        except Exception:
            cfg = {}
    changed = False
    if not cfg.get("bridgeId"):
        cfg["bridgeId"] = secrets.token_hex(12)
        changed = True
    if not cfg.get("bridgeSecret"):
        cfg["bridgeSecret"] = secrets.token_hex(32)
        changed = True
    cfg.setdefault("relayUrl", RELAY_BRIDGE_URL)
    cfg.setdefault("appRelayUrl", RELAY_APP_URL)
    if changed:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        CONFIG_FILE.write_text(json.dumps(cfg, indent=2))
        try:
            CONFIG_FILE.chmod(0o600)
        except Exception:
            pass
    return cfg


def reset_config() -> dict:
    if CONFIG_FILE.exists():
        try:
            cfg = json.loads(CONFIG_FILE.read_text())
        except Exception:
            cfg = {}
        cfg.pop("bridgeId", None)
        cfg.pop("bridgeSecret", None)
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        CONFIG_FILE.write_text(json.dumps(cfg, indent=2))
    return load_or_create_config()


# ── Daemon management ──────────────────────────────────────────
def _read_pid() -> Optional[int]:
    if not PID_FILE.exists():
        return None
    try:
        return int(PID_FILE.read_text().strip())
    except Exception:
        return None


def _is_running(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def stop_daemon() -> bool:
    pid = _read_pid()
    if pid and _is_running(pid):
        try:
            os.kill(pid, signal.SIGTERM)
            for _ in range(30):
                if not _is_running(pid):
                    break
                time.sleep(0.1)
            if _is_running(pid):
                os.kill(pid, signal.SIGKILL)
        except Exception as e:
            print(R(f"✗ stop failed: {e}"))
            return False
        try:
            PID_FILE.unlink()
        except Exception:
            pass
        return True
    if PID_FILE.exists():
        try:
            PID_FILE.unlink()
        except Exception:
            pass
    return False


def spawn_daemon(port: int) -> int:
    """Spawn `python -m iohermes_pair --__bridge_run --port PORT` detached."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    log = open(LOG_FILE, "ab", buffering=0)
    proc = subprocess.Popen(
        [sys.executable, "-m", "iohermes_pair",
         "--__bridge_run", "--port", str(port)],
        stdin=subprocess.DEVNULL,
        stdout=log,
        stderr=log,
        start_new_session=True,
        close_fds=True,
    )
    PID_FILE.write_text(str(proc.pid))
    time.sleep(1.0)
    if proc.poll() is not None:
        print(R(f"✗ daemon failed to start, see log: {LOG_FILE}"))
        sys.exit(1)
    return proc.pid


# ── QR rendering ───────────────────────────────────────────────
def make_payload(cfg: dict, name: Optional[str] = None) -> dict:
    return {
        "mode": "relay",
        "name": name or socket.gethostname() or "Hermes",
        "relayUrl": cfg.get("appRelayUrl", RELAY_APP_URL),
        "bridgeId": cfg["bridgeId"],
        "bridgeSecret": cfg["bridgeSecret"],
    }


def print_ascii_qr(text: str):
    import qrcode
    qr = qrcode.QRCode(border=1)
    qr.add_data(text)
    qr.make(fit=True)
    qr.print_ascii(invert=True)


def save_png(text: str, out: Path):
    import qrcode
    from qrcode.constants import ERROR_CORRECT_M
    img = qrcode.make(text, error_correction=ERROR_CORRECT_M,
                      box_size=10, border=4)
    out.parent.mkdir(parents=True, exist_ok=True)
    img.save(out)


# ── Main ───────────────────────────────────────────────────────
def main():
    p = argparse.ArgumentParser(
        prog="iohermes-pair",
        description="One-command pair tool for the iosHermes mobile app.",
    )
    p.add_argument("--version", action="version",
                   version=f"%(prog)s {__version__}")
    p.add_argument("--port", type=int, default=DEFAULT_LOCAL_PORT,
                   help=f"local Hermes / LLM server port "
                        f"(default: {DEFAULT_LOCAL_PORT})")
    p.add_argument("--name", default=None,
                   help="display name shown in the iOS app (default: hostname)")
    p.add_argument("--out", default="iohermes_pair.png",
                   help="QR PNG output path (default: ./iohermes_pair.png)")
    p.add_argument("--reset", action="store_true",
                   help="rotate credentials (paired devices will be lost)")
    p.add_argument("--status", action="store_true",
                   help="check if the daemon is running and exit")
    p.add_argument("--stop", action="store_true",
                   help="stop the daemon and exit")
    p.add_argument("--foreground", action="store_true",
                   help="run the bridge in foreground (no daemon)")
    p.add_argument("--json", action="store_true",
                   help="print only the JSON payload (no QR, no daemon)")
    # Hidden: re-execed by spawn_daemon to actually run the bridge loop
    p.add_argument("--__bridge_run", action="store_true",
                   help=argparse.SUPPRESS)
    args = p.parse_args()

    # Bridge loop entry (only used by spawn_daemon child process)
    if getattr(args, "__bridge_run"):
        cfg = load_or_create_config()
        _bridge.run(cfg, args.port, pid_file=PID_FILE)
        return

    if args.status:
        pid = _read_pid()
        if pid and _is_running(pid):
            print(G(f"● daemon running pid={pid}"))
            print(D(f"  log: {LOG_FILE}"))
        else:
            print(Y("○ daemon not running"))
        return

    if args.stop:
        ok = stop_daemon()
        print(G("✓ stopped") if ok else Y("○ was not running"))
        return

    cfg = reset_config() if args.reset else load_or_create_config()
    payload = make_payload(cfg, args.name)
    payload_json = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))

    if args.json:
        print(payload_json)
        return

    out_path = Path(args.out).expanduser().resolve()
    save_png(payload_json, out_path)

    print()
    print(B(C("  🔗 iosHermes pair QR")))
    print()
    print_ascii_qr(payload_json)
    print()
    print(f"  {D('name  :')} {G(payload['name'])}")
    print(f"  {D('bridge:')} {payload['bridgeId'][:12]}...")
    print(f"  {D('PNG   :')} {out_path}")
    print()

    if args.foreground:
        print(Y("[foreground] press Ctrl+C to stop"))
        _bridge.run(cfg, args.port, pid_file=None)
        return

    pid = _read_pid()
    if pid and _is_running(pid):
        stop_daemon()
    new_pid = spawn_daemon(args.port)

    print(G(f"✓ daemon started pid={new_pid} → 127.0.0.1:{args.port}"))
    print(f"  {D('log   :')} {LOG_FILE}")
    print(f"  {D('stop  :')} iohermes-pair --stop")
    print()
    print(B("  Open iosHermes app → My → + → Scan QR → done."))
    print()


if __name__ == "__main__":
    main()
