"""
Bridge daemon: keeps a WebSocket open to the relay and forwards every
incoming request envelope to a local HTTP server (your Hermes / OpenAI-API
compatible LLM gateway).
"""
from __future__ import annotations

import asyncio
import json
import signal
import sys
from pathlib import Path

from ._relay import RELAY_BRIDGE_URL


def _strip_hop_by_hop(headers: dict) -> dict:
    out = {}
    drop = {"host", "content-length", "connection"}
    for k, v in headers.items():
        if k.lower() in drop:
            continue
        out[k] = v
    return out


async def _forward(http, ws, env, hermes_url):
    import aiohttp

    req_id = env.get("reqId", "")
    method = (env.get("method") or "GET").upper()
    path = env.get("path") or "/"
    headers = _strip_hop_by_hop(dict(env.get("headers") or {}))
    body = env.get("body") or ""
    stream = bool(env.get("stream", False))
    url = hermes_url + path

    try:
        if stream:
            async with http.request(
                method, url, headers=headers,
                data=body.encode("utf-8") if isinstance(body, str) else body,
                timeout=aiohttp.ClientTimeout(total=None, sock_read=600),
            ) as resp:
                await ws.send_str(json.dumps({
                    "reqId": req_id, "type": "stream_start",
                    "status": resp.status,
                    "headers": dict(resp.headers),
                }))
                async for chunk in resp.content.iter_any():
                    if not chunk:
                        continue
                    await ws.send_str(json.dumps({
                        "reqId": req_id, "type": "stream_chunk",
                        "data": chunk.decode("utf-8", errors="replace"),
                    }))
                await ws.send_str(json.dumps({
                    "reqId": req_id, "type": "stream_end",
                }))
        else:
            async with http.request(
                method, url, headers=headers,
                data=body.encode("utf-8") if isinstance(body, str) else body,
                timeout=aiohttp.ClientTimeout(total=60),
            ) as resp:
                text = await resp.text()
                await ws.send_str(json.dumps({
                    "reqId": req_id,
                    "status": resp.status,
                    "headers": dict(resp.headers),
                    "body": text,
                }))
    except Exception as e:
        try:
            await ws.send_str(json.dumps({
                "reqId": req_id, "status": 502,
                "body": f"bridge error: {e}",
            }))
        except Exception:
            pass


async def _run_once(http, cfg, port):
    import aiohttp
    hermes_url = f"http://127.0.0.1:{port}"
    relay_url = f"{cfg['relayUrl']}?id={cfg['bridgeId']}&secret={cfg['bridgeSecret']}"
    print(f"[bridge] connecting...", flush=True)
    async with http.ws_connect(relay_url, heartbeat=30,
                               max_msg_size=16 * 1024 * 1024) as ws:
        print(f"[bridge] connected bridgeId={cfg['bridgeId'][:8]}...",
              flush=True)
        async for msg in ws:
            if msg.type == aiohttp.WSMsgType.TEXT:
                try:
                    env = json.loads(msg.data)
                except Exception:
                    continue
                asyncio.create_task(_forward(http, ws, env, hermes_url))
            elif msg.type in (aiohttp.WSMsgType.ERROR,
                              aiohttp.WSMsgType.CLOSED):
                break


async def _supervisor(cfg, port):
    import aiohttp
    backoff = 1.0
    async with aiohttp.ClientSession() as http:
        while True:
            try:
                await _run_once(http, cfg, port)
                backoff = 1.0
            except Exception as e:
                print(f"[bridge] disconnected: {e}; retry in {backoff:.1f}s",
                      flush=True)
            await asyncio.sleep(backoff)
            backoff = min(backoff * 1.8, 30.0)


def run(cfg: dict, port: int, pid_file: Path | None = None):
    """Entry-point for the daemon process. Blocks until killed."""

    def _sig(*_):
        if pid_file is not None:
            try:
                pid_file.unlink()
            except Exception:
                pass
        sys.exit(0)

    signal.signal(signal.SIGTERM, _sig)
    signal.signal(signal.SIGINT, _sig)

    asyncio.run(_supervisor(cfg, port))
