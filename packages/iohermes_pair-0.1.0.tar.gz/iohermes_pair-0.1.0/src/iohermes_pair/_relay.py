"""
Internal relay endpoint configuration.

These addresses are part of the iosHermes service infrastructure and are not
considered part of the public package API. They may change between versions.
"""

# Bridge side WebSocket (this daemon connects here)
RELAY_BRIDGE_URL = "wss://hermes.gjds.vip/ws/bridge"

# App side WebSocket (the iOS app connects here)
RELAY_APP_URL = "wss://hermes.gjds.vip/ws/app"

# Default local port the daemon forwards to
DEFAULT_LOCAL_PORT = 8765
