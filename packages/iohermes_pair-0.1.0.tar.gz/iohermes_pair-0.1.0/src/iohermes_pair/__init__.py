"""iohermes-pair · one-command pair tool for iosHermes."""

__version__ = "0.1.0"
