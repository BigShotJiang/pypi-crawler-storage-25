# import os
# from dataclasses import dataclass
# from pathlib import Path

# from dotenv import load_dotenv


# @dataclass(frozen=True)
# class KaananConfig:
#     api_key: str
#     model: str


# def load_config() -> KaananConfig:
#     """
#     Reads .env from the directory where the user runs `kaanan`.
#     Equivalent to Pydantic BaseSettings with env_file=".env".
#     """
#     env_path = Path.cwd() / ".env"

#     if not env_path.exists():
#         raise FileNotFoundError(
#             f"No .env file found in {Path.cwd()}.\n"
#             "Create one with KAANAN_API_KEY and KAANAN_MODEL."
#         )

#     load_dotenv(dotenv_path=env_path, override=True)

#     api_key = os.getenv("KAANAN_API_KEY", "").strip()
#     model = os.getenv("KAANAN_MODEL", "").strip()

#     if not api_key:
#         raise ValueError("KAANAN_API_KEY is missing or empty in your .env file.")
#     if not model:
#         raise ValueError("KAANAN_MODEL is missing or empty in your .env file.")

#     return KaananConfig(api_key=api_key, model=model)
import os
from dataclasses import dataclass


@dataclass(frozen=True)
class KaananConfig:
    api_key: str
    model: str


def load_config() -> KaananConfig:
    """
    Reads config purely from environment variables.
    Set these as GitHub Actions secrets or export them in your shell for local dev.

    GitHub Actions:
        secrets.KAANAN_API_KEY  → env: KAANAN_API_KEY
        secrets.KAANAN_MODEL    → env: KAANAN_MODEL

    Local dev (PowerShell):
        $env:KAANAN_API_KEY = "sk-..."
        $env:KAANAN_MODEL   = "gpt-4o"

    Local dev (bash/zsh):
        export KAANAN_API_KEY="sk-..."
        export KAANAN_MODEL="gpt-4o"
    """
    api_key = os.getenv("KAANAN_API_KEY", "").strip()
    model = os.getenv("KAANAN_MODEL", "").strip()

    if not api_key:
        raise ValueError(
            "KAANAN_API_KEY is not set.\n"
            "  GitHub Actions: add it under repo Settings → Secrets and variables → Actions\n"
            "  Local (PowerShell): $env:KAANAN_API_KEY = 'sk-...'\n"
            "  Local (bash): export KAANAN_API_KEY='sk-...'"
        )
    if not model:
        raise ValueError(
            "KAANAN_MODEL is not set.\n"
            "  GitHub Actions: add it under repo Settings → Secrets and variables → Actions\n"
            "  Local (PowerShell): $env:KAANAN_MODEL = 'gpt-4o'\n"
            "  Local (bash): export KAANAN_MODEL='gpt-4o'"
        )

    return KaananConfig(api_key=api_key, model=model)