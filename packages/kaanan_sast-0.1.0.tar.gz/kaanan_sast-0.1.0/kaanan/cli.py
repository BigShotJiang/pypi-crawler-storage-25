from pathlib import Path

import typer
from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich import print as rprint

app = typer.Typer(
    name="kaanan",
    help="Kaanan — AI-driven SAST and VAPT tool.",
    add_completion=False,
    rich_markup_mode="rich",
    no_args_is_help=True,
)

console = Console()


def _print_setup_guide() -> None:
    console.print()
    console.print(Panel.fit(
        "[bold cyan]Kaanan[/bold cyan] — AI-driven SAST & VAPT\n"
        "[dim]Powered by LiteLLM. Works with OpenAI, Anthropic, Ollama, and more.[/dim]",
        border_style="cyan",
    ))

    console.print("""
[bold white]QUICK START[/bold white]
[dim]─────────────────────────────────────────────────────────────────[/dim]

  [bold]Step 1[/bold]  Install Kaanan
    [cyan]pip install kaanan[/cyan]

  [bold]Step 2[/bold]  Create a [bold].env[/bold] file in your project root

    [dim]Option A — scaffold automatically:[/dim]
      [cyan]kaanan init[/cyan]

    [dim]Option B — create manually:[/dim]
      [cyan]echo "KAANAN_API_KEY=your_key_here" > .env[/cyan]
      [cyan]echo "KAANAN_MODEL=gpt-4o"          >> .env[/cyan]

  [bold]Step 3[/bold]  Run a scan
    [cyan]kaanan scan --dir ./src[/cyan]
    [cyan]kaanan scan --dir .   --output ./reports/security.pdf[/cyan]

  [bold]Step 4[/bold]  Open the PDF report
    [dim]Default output:[/dim] [cyan]kaanan_report.pdf[/cyan] [dim]in your current directory[/dim]

[bold white]SUPPORTED LLM PROVIDERS[/bold white]
[dim]─────────────────────────────────────────────────────────────────[/dim]

  Provider        KAANAN_MODEL value
  ──────────────  ─────────────────────────────────────────────
  OpenAI          [cyan]gpt-4o[/cyan]  /  [cyan]gpt-4o-mini[/cyan]  /  [cyan]gpt-4-turbo[/cyan]
  Anthropic       [cyan]claude-3-5-sonnet-20241022[/cyan]  /  [cyan]claude-3-opus-20240229[/cyan]
  Google          [cyan]gemini/gemini-1.5-pro[/cyan]
  Local (Ollama)  [cyan]ollama/llama3[/cyan]  /  [cyan]ollama/mistral[/cyan]
  Azure OpenAI    [cyan]azure/your-deployment-name[/cyan]
  AWS Bedrock     [cyan]bedrock/anthropic.claude-3-sonnet[/cyan]

  [dim]Full provider list: https://docs.litellm.ai/docs/providers[/dim]

[bold white].ENV FILE FORMAT[/bold white]
[dim]─────────────────────────────────────────────────────────────────[/dim]

  [cyan]KAANAN_API_KEY=sk-...[/cyan]            [dim]# Your provider API key[/dim]
  [cyan]KAANAN_MODEL=gpt-4o[/cyan]              [dim]# LiteLLM model string[/dim]

  [dim]The .env file must be in the directory where you run kaanan.[/dim]
  [dim]It is never uploaded or shared — read locally only.[/dim]

[bold white]WHITELIST (OPTIONAL)[/bold white]
[dim]─────────────────────────────────────────────────────────────────[/dim]

  Create [cyan]kaanan_whitelist.txt[/cyan] to control which file types are scanned.
  One extension per line. If the file is absent, Kaanan uses defaults:
  [dim].py  .js  .ts  .java  .go  .php  .rb  .cs  .cpp  .c[/dim]

  Example [cyan]kaanan_whitelist.txt[/cyan]:
    [dim].py[/dim]
    [dim].js[/dim]
    [dim].ts[/dim]

[bold white]REPORT[/bold white]
[dim]─────────────────────────────────────────────────────────────────[/dim]

  Output is a self-contained PDF with:
  • Severity summary (CRITICAL / HIGH / MEDIUM / LOW counts)
  • Per-file findings with CWE ID and OWASP Top 10 category
  • Exact vulnerable code snippet with line highlighting
  • Impact assessment and actionable remediation per finding
  • Kaanan.ai branding — ready to share with your team or client

[bold white]COMMANDS[/bold white]
[dim]─────────────────────────────────────────────────────────────────[/dim]

  [cyan]kaanan --help[/cyan]              Show this guide
  [cyan]kaanan init[/cyan]               Scaffold .env + kaanan_whitelist.txt
  [cyan]kaanan scan --help[/cyan]        Show scan command options
  [cyan]kaanan scan --dir PATH[/cyan]    Run a full SAST scan

[bold white]EXAMPLES[/bold white]
[dim]─────────────────────────────────────────────────────────────────[/dim]

  [dim]# Scan your entire project[/dim]
  [cyan]kaanan scan --dir .[/cyan]

  [dim]# Scan only the src folder, save report elsewhere[/dim]
  [cyan]kaanan scan --dir ./src --output ./reports/$(date +%Y%m%d)_scan.pdf[/cyan]

  [dim]# Use a local Ollama model (no API key needed)[/dim]
  [dim]# Set KAANAN_MODEL=ollama/llama3 in .env, KAANAN_API_KEY=dummy[/dim]
  [cyan]kaanan scan --dir ./src[/cyan]
""")
    console.print(Panel(
        """[bold yellow]  IMPORTANT — PLEASE READ BEFORE USE[/bold yellow]

  [bold white]Data Privacy[/bold white]
  Kaanan does [bold]not[/bold] collect, store, transmit, or log your source code.
  Your code never touches Kaanan'''s servers. All processing is local.

  [bold white]Third-Party LLM Risk[/bold white]
  Kaanan sends your source code directly to the LLM provider you configure
  (e.g. OpenAI, Anthropic, Google). Kaanan has no control over how those
  providers handle your data. Many commercial API tiers [bold]may use your
  inputs to train or improve their models[/bold] by default.

  Before scanning production or proprietary code, you are strongly advised to:
    [cyan]*[/cyan] Review your LLM provider'''s data usage and privacy policy
    [cyan]*[/cyan] Opt out of training data collection if your provider offers it
    [cyan]*[/cyan] Use an enterprise or zero-data-retention API tier
    [cyan]*[/cyan] Use a local model (e.g. [cyan]ollama/llama3[/cyan]) for maximum privacy

  [bold white]Acceptance of Risk[/bold white]
  By installing and using Kaanan, you acknowledge and accept all risks
  associated with transmitting your source code to third-party LLM providers.
  Kaanan and its authors accept no liability for data exposure, model training
  on your code, or any consequences thereof.""",
        title="[bold yellow]DISCLAIMER[/bold yellow]",
        border_style="yellow",
        padding=(0, 2),
    ))


@app.callback(invoke_without_command=True)
def main(ctx: typer.Context) -> None:
    """
    [bold cyan]Kaanan[/bold cyan] — AI-driven SAST and VAPT tool.

    Run [bold]kaanan --help[/bold] for the full setup guide.
    Run [bold]kaanan scan --help[/bold] for scan options.
    """
    if ctx.invoked_subcommand is None:
        _print_setup_guide()


@app.command()
def scan(
    directory: Path = typer.Option(
        ...,
        "--dir", "-d",
        help="Target directory to scan. Must exist.",
        exists=True,
        file_okay=False,
        dir_okay=True,
        readable=True,
        resolve_path=True,
    ),
    output: Path = typer.Option(
        Path("kaanan_report.pdf"),
        "--output", "-o",
        help="Output path for the PDF report. Default: kaanan_report.pdf",
    ),
):
    """
    [bold cyan]Scan[/bold cyan] a directory for security vulnerabilities using AI-powered SAST.

    Reads [bold]KAANAN_API_KEY[/bold] and [bold]KAANAN_MODEL[/bold] from a [bold].env[/bold] file
    in your current working directory.

    [dim]Examples:[/dim]
      kaanan scan --dir ./src
      kaanan scan --dir .
      kaanan scan --dir ./src --output ./reports/security.pdf
    """
    from kaanan.config import load_config

    try:
        config = load_config()
    except (FileNotFoundError, ValueError) as exc:
        console.print(f"\n[bold red]Config Error:[/bold red] {exc}\n")
        console.print("[dim]Run [cyan]kaanan --help[/cyan] for setup instructions.[/dim]\n")
        raise typer.Exit(code=1)

    from kaanan.scanner import run_scan

    try:
        results = run_scan(target_dir=directory, config=config)
    except (FileNotFoundError, ValueError) as exc:
        console.print(f"\n[bold red]Scan Error:[/bold red] {exc}\n")
        raise typer.Exit(code=1)

    if not results:
        console.print("[yellow]No files were scanned. Check your whitelist or directory.[/yellow]")
        raise typer.Exit(code=0)

    from kaanan.report import generate_report

    try:
        generate_report(results=results, output_path=output)
    except Exception as exc:
        console.print(f"\n[bold red]Report Error:[/bold red] {exc}\n")
        raise typer.Exit(code=1)

    total_vulns = sum(len(r.vulnerabilities) for r in results)
    console.print(
        f"\n[bold green]Scan complete.[/bold green] "
        f"[bold]{total_vulns}[/bold] issue(s) found across "
        f"[bold]{len(results)}[/bold] file(s)."
    )
    console.print(f"[bold]Report:[/bold] [cyan]{output.resolve()}[/cyan]\n")


@app.command()
def init():
    """
    Scaffold a [bold].env[/bold] and [bold]kaanan_whitelist.txt[/bold] in the current directory.

    Safe to run multiple times — will not overwrite existing files.
    """
    env_path       = Path.cwd() / ".env"
    whitelist_path = Path.cwd() / "kaanan_whitelist.txt"

    console.print()
    if not env_path.exists():
        env_path.write_text(
            "KAANAN_API_KEY=your_api_key_here\n"
            "KAANAN_MODEL=gpt-4o\n"
            "# Anthropic: KAANAN_MODEL=claude-3-5-sonnet-20241022\n"
            "# Ollama:    KAANAN_MODEL=ollama/llama3  (set API_KEY=dummy)\n"
            "# Azure:     KAANAN_MODEL=azure/your-deployment\n",
            encoding="utf-8",
        )
        console.print(f"  [green]Created[/green]  {env_path}")
    else:
        console.print(f"  [yellow]Skipped[/yellow]  {env_path} (already exists)")

    if not whitelist_path.exists():
        whitelist_path.write_text(
            "# File extensions Kaanan will scan. One per line.\n"
            "# Lines starting with # are ignored.\n"
            ".py\n.js\n.ts\n.java\n.go\n.php\n.rb\n.cs\n",
            encoding="utf-8",
        )
        console.print(f"  [green]Created[/green]  {whitelist_path}")
    else:
        console.print(f"  [yellow]Skipped[/yellow]  {whitelist_path} (already exists)")

    console.print("""
  [bold]Next steps:[/bold]

    1. Open [cyan].env[/cyan] and set your real [bold]KAANAN_API_KEY[/bold] and [bold]KAANAN_MODEL[/bold]
    2. Optionally edit [cyan]kaanan_whitelist.txt[/cyan] for your stack
    3. Run: [bold cyan]kaanan scan --dir ./src[/bold cyan]

  [dim]Need help? Run:[/dim] [cyan]kaanan --help[/cyan]
""")