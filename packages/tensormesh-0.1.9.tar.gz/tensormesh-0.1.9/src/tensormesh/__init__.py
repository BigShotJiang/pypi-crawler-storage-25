from __future__ import annotations

from importlib import import_module
from typing import Any

from . import types
from ._client import Tensormesh
from ._constants import DEFAULT_CONTROL_PLANE_BASE_URL
from ._constants import DEFAULT_MAX_RETRIES
from ._constants import DEFAULT_SERVERLESS_BASE_URL
from ._constants import DEFAULT_STREAM_READ_TIMEOUT_SECONDS
from ._constants import DEFAULT_TIMEOUT_SECONDS
from ._constants import ENV_CA_BUNDLE
from ._constants import ENV_CONTROL_PLANE_BASE_URL
from ._constants import ENV_CONTROL_PLANE_TOKEN
from ._constants import ENV_INFERENCE_API_KEY
from ._constants import ENV_MAX_RETRIES
from ._constants import ENV_ON_DEMAND_BASE_URL
from ._constants import ENV_ON_DEMAND_USER_ID
from ._constants import ENV_SERVERLESS_BASE_URL
from ._constants import ENV_TIMEOUT_SECONDS
from ._exceptions import APIConnectionError
from ._exceptions import APIError
from ._exceptions import APIStatusError
from ._exceptions import APITimeoutError
from ._exceptions import AuthenticationError
from ._exceptions import BadRequestError
from ._exceptions import ConfigurationError
from ._exceptions import ConflictError
from ._exceptions import InternalServerError
from ._exceptions import NotFoundError
from ._exceptions import PermissionDeniedError
from ._exceptions import ProtocolError
from ._exceptions import RateLimitError
from ._exceptions import StreamError
from ._exceptions import TensormeshError
from ._exceptions import UnprocessableEntityError
from ._streaming import AsyncChatCompletionStream
from ._streaming import ChatCompletionStream
from .build_info import __version__

__all__ = [
    "APIConnectionError",
    "APIError",
    "APIStatusError",
    "APITimeoutError",
    "AsyncBufferedResponse",
    "AuthenticationError",
    "AsyncChatCompletionStream",
    "AsyncStreamResponse",
    "AsyncTensormesh",
    "BadRequestError",
    "ConfigurationError",
    "ConflictError",
    "DEFAULT_CONTROL_PLANE_BASE_URL",
    "DEFAULT_MAX_RETRIES",
    "DEFAULT_STREAM_READ_TIMEOUT_SECONDS",
    "DEFAULT_SERVERLESS_BASE_URL",
    "DEFAULT_TIMEOUT_SECONDS",
    "ENV_CA_BUNDLE",
    "ENV_CONTROL_PLANE_BASE_URL",
    "ENV_CONTROL_PLANE_TOKEN",
    "ENV_INFERENCE_API_KEY",
    "ENV_MAX_RETRIES",
    "ENV_ON_DEMAND_BASE_URL",
    "ENV_ON_DEMAND_USER_ID",
    "ENV_SERVERLESS_BASE_URL",
    "ENV_TIMEOUT_SECONDS",
    "InternalServerError",
    "NotFoundError",
    "PermissionDeniedError",
    "ProtocolError",
    "RateLimitError",
    "StreamError",
    "ChatCompletionStream",
    "Tensormesh",
    "TensormeshError",
    "UnprocessableEntityError",
    "__version__",
    "types",
]

_LAZY_EXPORTS = {
    "AsyncBufferedResponse": ("._async_transport", "AsyncBufferedResponse"),
    "AsyncStreamResponse": ("._async_transport", "AsyncStreamResponse"),
    "AsyncTensormesh": ("._async_client", "AsyncTensormesh"),
}


def __getattr__(name: str) -> Any:
    target = _LAZY_EXPORTS.get(name)
    if target is None:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
    module_name, attr_name = target
    value = getattr(import_module(module_name, __name__), attr_name)
    globals()[name] = value
    return value
