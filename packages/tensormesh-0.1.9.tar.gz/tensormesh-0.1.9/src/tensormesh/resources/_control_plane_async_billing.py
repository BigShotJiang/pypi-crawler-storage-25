from __future__ import annotations

from typing import Any, AsyncIterator, Mapping

from tensormesh.resources._control_plane_shared import \
    AsyncControlPlaneSurfaceProtocol as _AsyncControlPlaneSurfaceProtocol
from tensormesh.resources._control_plane_shared import \
    coerce_request as _coerce_request
from tensormesh.resources._control_plane_shared import \
    compact_params as _compact_params
from tensormesh.resources._control_plane_shared import \
    require_response_list_field as _require_response_list_field
from tensormesh.resources._control_plane_shared import \
    require_response_mapping_field as _require_response_mapping_field
from tensormesh.types.control_plane import AttachStripePaymentMethodRequest
from tensormesh.types.control_plane import BillingAddress
from tensormesh.types.control_plane import BillingStripeCustomer
from tensormesh.types.control_plane import BillingStripePaymentIntent
from tensormesh.types.control_plane import BillingStripePaymentMethodsPage
from tensormesh.types.control_plane import BillingStripeSetupIntent
from tensormesh.types.control_plane import BillingTransaction
from tensormesh.types.control_plane import BillingTransactionsPage
from tensormesh.types.control_plane import ConfirmStripePaymentIntentRequest
from tensormesh.types.control_plane import CreateStripePaymentIntentRequest
from tensormesh.types.control_plane import CreateStripeSetupIntentRequest
from tensormesh.types.control_plane import EmptyResult
from tensormesh.types.control_plane import GpuPricing
from tensormesh.types.control_plane import Money
from tensormesh.types.control_plane import ServerlessPricing
from tensormesh.types.control_plane import SpendingBucket
from tensormesh.types.control_plane import SpendingSummary
from tensormesh.types.control_plane import UpdateBillingAddressRequest


class AsyncBillingBalanceClient:

    def __init__(self, surface: _AsyncControlPlaneSurfaceProtocol) -> None:
        self._surface = surface

    async def get(
        self,
        *,
        user_id: str | None = None,
        timeout: float | None = None,
    ) -> Money | None:
        response = await self._surface.request(
            "GET",
            "/v1/billing/balance",
            params=_compact_params({"userId": user_id}),
            timeout=timeout,
        )
        return Money.from_dict(
            _require_response_mapping_field(
                response.json(),
                "balance",
                context="billing balance response",
            ))


class AsyncBillingAddressClient:

    def __init__(self, surface: _AsyncControlPlaneSurfaceProtocol) -> None:
        self._surface = surface

    async def get(
        self,
        *,
        user_id: str | None = None,
        timeout: float | None = None,
    ) -> BillingAddress | None:
        response = await self._surface.request(
            "GET",
            "/v1/billing/address",
            params=_compact_params({"userId": user_id}),
            timeout=timeout,
        )
        return BillingAddress.from_dict(
            _require_response_mapping_field(
                response.json(),
                "address",
                context="billing address response",
            ))

    async def update(
        self,
        *,
        request: UpdateBillingAddressRequest | Mapping[str, Any] | None = None,
        user_id: str | None = None,
        address: BillingAddress | Mapping[str, Any] | None = None,
        timeout: float | None = None,
    ) -> EmptyResult:
        payload = _coerce_request(
            request=request,
            request_cls=UpdateBillingAddressRequest,
            request_name="billing address update request",
            fields={
                "user_id": user_id,
                "address": address,
            },
        )
        response = await self._surface.request(
            "PUT",
            "/v1/billing/address",
            json_body=payload.to_dict(),
            timeout=timeout,
        )
        return EmptyResult.from_dict(
            _require_response_mapping_field(
                response.json(),
                "empty",
                context="billing address update response",
            ))


class AsyncBillingTransactionsClient:

    def __init__(self, surface: _AsyncControlPlaneSurfaceProtocol) -> None:
        self._surface = surface

    async def list(
        self,
        *,
        user_id: str | None = None,
        page_size: int | None = None,
        page_token: str | None = None,
        timeout: float | None = None,
    ) -> BillingTransactionsPage:
        response = await self._surface.request(
            "GET",
            "/v1/billing/transactions",
            params=_compact_params({
                "userId": user_id,
                "pageSize": page_size,
                "pageToken": page_token,
            }),
            timeout=timeout,
        )
        return BillingTransactionsPage.from_dict(response.json())

    async def auto_paging_iter(
        self,
        *,
        user_id: str | None = None,
        page_size: int | None = None,
        page_token: str | None = None,
        timeout: float | None = None,
    ) -> AsyncIterator[BillingTransaction]:
        current_page_token = page_token
        while True:
            current = await self.list(
                user_id=user_id,
                page_size=page_size,
                page_token=current_page_token,
                timeout=timeout,
            )
            for transaction in current.transactions:
                yield transaction
            if not current.next_page_token:
                return
            current_page_token = current.next_page_token


class AsyncBillingSpendingClient:

    def __init__(self, surface: _AsyncControlPlaneSurfaceProtocol) -> None:
        self._surface = surface

    async def history(
        self,
        *,
        user_id: str | None = None,
        timeout: float | None = None,
    ) -> list[SpendingBucket]:
        response = await self._surface.request(
            "GET",
            "/v1/billing/spending/history",
            params=_compact_params({"userId": user_id}),
            timeout=timeout,
        )
        body = response.json()
        return [
            SpendingBucket.from_dict(item)
            for item in _require_response_list_field(
                body,
                "buckets",
                context="billing spending history response",
            )
        ]

    async def summary(
        self,
        *,
        user_id: str | None = None,
        timeout: float | None = None,
    ) -> SpendingSummary:
        response = await self._surface.request(
            "GET",
            "/v1/billing/spending/summary",
            params=_compact_params({"userId": user_id}),
            timeout=timeout,
        )
        return SpendingSummary.from_dict(response.json())


class AsyncStripeCustomerClient:

    def __init__(self, surface: _AsyncControlPlaneSurfaceProtocol) -> None:
        self._surface = surface

    async def get_or_create(
        self,
        *,
        user_id: str | None = None,
        timeout: float | None = None,
    ) -> BillingStripeCustomer:
        response = await self._surface.request(
            "GET",
            "/v1/billing/stripe/customers",
            params=_compact_params({"userId": user_id}),
            timeout=timeout,
        )
        return BillingStripeCustomer.from_dict(response.json())


class AsyncStripePaymentMethodsClient:

    def __init__(self, surface: _AsyncControlPlaneSurfaceProtocol) -> None:
        self._surface = surface

    async def list(
        self,
        *,
        user_id: str | None = None,
        timeout: float | None = None,
    ) -> BillingStripePaymentMethodsPage:
        response = await self._surface.request(
            "GET",
            "/v1/billing/stripe/customers/payment-methods",
            params=_compact_params({"userId": user_id}),
            timeout=timeout,
        )
        return BillingStripePaymentMethodsPage.from_dict(response.json())

    async def attach(
        self,
        *,
        request: AttachStripePaymentMethodRequest | Mapping[str, Any]
        | None = None,
        stripe_payment_method_id: str | None = None,
        user_id: str | None = None,
        timeout: float | None = None,
    ) -> EmptyResult:
        payload = _coerce_request(
            request=request,
            request_cls=AttachStripePaymentMethodRequest,
            request_name="stripe payment method attach request",
            fields={
                "stripe_payment_method_id": stripe_payment_method_id,
                "user_id": user_id,
            },
        )
        response = await self._surface.request(
            "POST",
            "/v1/billing/stripe/customers/payment-methods",
            json_body=payload.to_dict(),
            timeout=timeout,
        )
        return EmptyResult.from_dict(
            _require_response_mapping_field(
                response.json(),
                "empty",
                context="stripe payment method attach response",
            ))

    async def detach(
        self,
        stripe_payment_method_id: str,
        *,
        user_id: str | None = None,
        timeout: float | None = None,
    ) -> EmptyResult:
        response = await self._surface.request(
            "DELETE",
            "/v1/billing/stripe/customers/payment-methods",
            params=_compact_params({
                "userId":
                user_id,
                "stripePaymentMethodId":
                stripe_payment_method_id,
            }),
            timeout=timeout,
        )
        return EmptyResult.from_dict(
            _require_response_mapping_field(
                response.json(),
                "empty",
                context="stripe payment method detach response",
            ))


class AsyncStripePaymentIntentsClient:

    def __init__(self, surface: _AsyncControlPlaneSurfaceProtocol) -> None:
        self._surface = surface

    async def create(
        self,
        *,
        request: CreateStripePaymentIntentRequest | Mapping[str, Any]
        | None = None,
        amount: Money | Mapping[str, Any] | float | int | None = None,
        stripe_payment_method_id: str | None = None,
        user_id: str | None = None,
        timeout: float | None = None,
    ) -> BillingStripePaymentIntent:
        payload = _coerce_request(
            request=request,
            request_cls=CreateStripePaymentIntentRequest,
            request_name="stripe payment intent create request",
            fields={
                "amount": amount,
                "stripe_payment_method_id": stripe_payment_method_id,
                "user_id": user_id,
            },
        )
        response = await self._surface.request(
            "POST",
            "/v1/billing/stripe/payment-intents",
            json_body=payload.to_dict(),
            timeout=timeout,
        )
        return BillingStripePaymentIntent.from_dict(response.json())

    async def confirm(
        self,
        *,
        request: ConfirmStripePaymentIntentRequest | Mapping[str, Any]
        | None = None,
        stripe_payment_intent_id: str | None = None,
        user_id: str | None = None,
        timeout: float | None = None,
    ) -> EmptyResult:
        payload = _coerce_request(
            request=request,
            request_cls=ConfirmStripePaymentIntentRequest,
            request_name="stripe payment intent confirm request",
            fields={
                "stripe_payment_intent_id": stripe_payment_intent_id,
                "user_id": user_id,
            },
        )
        response = await self._surface.request(
            "POST",
            "/v1/billing/stripe/payment-intents/confirm",
            json_body=payload.to_dict(),
            timeout=timeout,
        )
        return EmptyResult.from_dict(
            _require_response_mapping_field(
                response.json(),
                "empty",
                context="stripe payment intent confirm response",
            ))


class AsyncStripeSetupIntentsClient:

    def __init__(self, surface: _AsyncControlPlaneSurfaceProtocol) -> None:
        self._surface = surface

    async def create(
        self,
        *,
        request: CreateStripeSetupIntentRequest | Mapping[str, Any]
        | None = None,
        user_id: str | None = None,
        timeout: float | None = None,
    ) -> BillingStripeSetupIntent:
        payload = _coerce_request(
            request=request,
            request_cls=CreateStripeSetupIntentRequest,
            request_name="stripe setup intent create request",
            fields={"user_id": user_id},
        )
        response = await self._surface.request(
            "POST",
            "/v1/billing/stripe/setup-intents",
            json_body=payload.to_dict(),
            timeout=timeout,
        )
        return BillingStripeSetupIntent.from_dict(response.json())


class AsyncBillingStripeClient:

    def __init__(self, surface: _AsyncControlPlaneSurfaceProtocol) -> None:
        self.customer = AsyncStripeCustomerClient(surface)
        self.payment_methods = AsyncStripePaymentMethodsClient(surface)
        self.payment_intents = AsyncStripePaymentIntentsClient(surface)
        self.setup_intents = AsyncStripeSetupIntentsClient(surface)


class AsyncGpuPricingClient:

    def __init__(self, surface: _AsyncControlPlaneSurfaceProtocol) -> None:
        self._surface = surface

    async def list(
        self,
        *,
        cloud_provider: str | None = None,
        gpu_type: str | None = None,
        active_only: bool | None = None,
        timeout: float | None = None,
    ) -> list[GpuPricing]:
        response = await self._surface.request(
            "GET",
            "/v1/billing/gpu-pricing",
            params=_compact_params({
                "cloudProvider": cloud_provider,
                "gpuType": gpu_type,
                "activeOnly": active_only,
            }),
            timeout=timeout,
        )
        body = response.json()
        return [
            GpuPricing.from_dict(item)
            for item in _require_response_list_field(
                body,
                "pricing",
                context="GPU pricing list response",
            )
        ]


class AsyncServerlessPricingClient:

    def __init__(self, surface: _AsyncControlPlaneSurfaceProtocol) -> None:
        self._surface = surface

    async def list(
        self,
        *,
        model: str | None = None,
        active_only: bool | None = None,
        timeout: float | None = None,
    ) -> list[ServerlessPricing]:
        response = await self._surface.request(
            "GET",
            "/v1/billing/serverless-pricing",
            params=_compact_params({
                "model": model,
                "activeOnly": active_only,
            }),
            timeout=timeout,
        )
        body = response.json()
        return [
            ServerlessPricing.from_dict(item)
            for item in _require_response_list_field(
                body,
                "pricing",
                context="serverless pricing list response",
            )
        ]


class AsyncBillingPricingClient:

    def __init__(self, surface: _AsyncControlPlaneSurfaceProtocol) -> None:
        self.gpu = AsyncGpuPricingClient(surface)
        self.serverless = AsyncServerlessPricingClient(surface)


class AsyncBillingClient:

    def __init__(self, surface: _AsyncControlPlaneSurfaceProtocol) -> None:
        self.balance = AsyncBillingBalanceClient(surface)
        self.address = AsyncBillingAddressClient(surface)
        self.transactions = AsyncBillingTransactionsClient(surface)
        self.spending = AsyncBillingSpendingClient(surface)
        self.stripe = AsyncBillingStripeClient(surface)
        self.pricing = AsyncBillingPricingClient(surface)
