from __future__ import annotations

from typing import Any, Mapping, Protocol, Sequence

from tensormesh._streaming import AsyncChatCompletionStream
from tensormesh.resources._inference_openai_shared import \
    build_detokenize_request
from tensormesh.resources._inference_openai_shared import \
    build_response_create_request
from tensormesh.resources._inference_openai_shared import \
    build_text_completion_request
from tensormesh.resources._inference_openai_shared import \
    build_tokenize_request
from tensormesh.resources._inference_openai_shared import \
    normalize_response_wrapper_request
from tensormesh.resources._inference_openai_shared import \
    normalize_text_completion_wrapper_request
from tensormesh.resources._inference_shared import \
    build_chat_completion_request
from tensormesh.types.inference import ChatCompletionFunction
from tensormesh.types.inference import ChatCompletionRequest
from tensormesh.types.inference import ChatCompletionResponse
from tensormesh.types.inference import ChatCompletionTool
from tensormesh.types.inference import ChatMessage
from tensormesh.types.inference import DetokenizeRequest
from tensormesh.types.inference import DetokenizeResponse
from tensormesh.types.inference import FunctionNameSpec
from tensormesh.types.inference import FunctionSelection
from tensormesh.types.inference import HealthResponse
from tensormesh.types.inference import InferenceModelList
from tensormesh.types.inference import PredictedOutput
from tensormesh.types.inference import ResponseCreateRequest
from tensormesh.types.inference import ResponseCreateResponse
from tensormesh.types.inference import ResponseFormat
from tensormesh.types.inference import StreamOptions
from tensormesh.types.inference import TextCompletionRequest
from tensormesh.types.inference import TextCompletionResponse
from tensormesh.types.inference import ThinkingConfigDisabled
from tensormesh.types.inference import ThinkingConfigEnabled
from tensormesh.types.inference import TokenizeRequest
from tensormesh.types.inference import TokenizeResponse
from tensormesh.types.inference import VersionResponse


class _AsyncInferenceSurfaceProtocol(Protocol):

    async def request(
        self,
        method: str,
        path: str,
        *,
        params: Mapping[str, object] | None = None,
        json_body: Any | None = None,
        headers: Mapping[str, str] | None = None,
        timeout: float | None = None,
        user_id: str | None = None,
    ) -> Any:
        ...

    async def stream_request(
        self,
        method: str,
        path: str,
        *,
        params: Mapping[str, object] | None = None,
        json_body: Any | None = None,
        headers: Mapping[str, str] | None = None,
        timeout: float | None = None,
        read_timeout: float | None = None,
        user_id: str | None = None,
    ) -> Any:
        ...


class AsyncChatNamespace:

    def __init__(self, surface: Any) -> None:
        self.completions = AsyncChatCompletionsClient(surface)


class AsyncModelsClient:

    def __init__(self, surface: _AsyncInferenceSurfaceProtocol) -> None:
        self._surface = surface

    async def list(self,
                   *,
                   timeout: float | None = None) -> InferenceModelList:
        response = await self._surface.request("GET",
                                               "/v1/models",
                                               timeout=timeout)
        return InferenceModelList.from_dict(response.json())


class AsyncTextCompletionsClient:

    def __init__(self, surface: _AsyncInferenceSurfaceProtocol) -> None:
        self._surface = surface
        self.with_raw_response = AsyncTextCompletionsWithRawResponse(self)
        self.with_streaming_response = (
            AsyncTextCompletionsWithStreamingResponse(self))

    async def create(
        self,
        *,
        request: TextCompletionRequest | Mapping[str, Any] | None = None,
        model: str | None = None,
        prompt: str | list[str] | None = None,
        max_tokens: int | None = None,
        stream: bool | None = None,
        temperature: float | None = None,
        extra_body: Mapping[str, Any] | None = None,
        timeout: float | None = None,
        stream_idle_timeout: float | None = None,
    ) -> TextCompletionResponse | Any:
        return await self._create_response(
            request=request,
            model=model,
            prompt=prompt,
            max_tokens=max_tokens,
            stream=stream,
            temperature=temperature,
            extra_body=extra_body,
            timeout=timeout,
            stream_idle_timeout=stream_idle_timeout,
        )

    async def _create_response(
        self,
        *,
        request: TextCompletionRequest | Mapping[str, Any] | None = None,
        model: str | None = None,
        prompt: str | list[str] | None = None,
        max_tokens: int | None = None,
        stream: bool | None = None,
        temperature: float | None = None,
        extra_body: Mapping[str, Any] | None = None,
        timeout: float | None = None,
        stream_idle_timeout: float | None = None,
        return_raw_response: bool = False,
        return_streaming_response: bool = False,
    ) -> TextCompletionResponse | Any:
        built_request = build_text_completion_request(
            request=request,
            model=model,
            prompt=prompt,
            max_tokens=max_tokens,
            stream=stream,
            temperature=temperature,
            extra_body=extra_body,
        )
        payload = built_request.to_dict()
        if built_request.stream is True or return_streaming_response:
            return await self._surface.stream_request(
                "POST",
                "/v1/completions",
                json_body=payload,
                headers={"Accept": "text/event-stream"},
                timeout=timeout,
                read_timeout=stream_idle_timeout,
            )
        response = await self._surface.request(
            "POST",
            "/v1/completions",
            json_body=payload,
            timeout=timeout,
        )
        if return_raw_response:
            return response
        return TextCompletionResponse.from_dict(response.json())


class AsyncResponsesClient:

    def __init__(self, surface: _AsyncInferenceSurfaceProtocol) -> None:
        self._surface = surface
        self.with_raw_response = AsyncResponsesWithRawResponse(self)
        self.with_streaming_response = AsyncResponsesWithStreamingResponse(
            self)

    async def create(
        self,
        *,
        request: ResponseCreateRequest | Mapping[str, Any] | None = None,
        model: str | None = None,
        input: str | list[dict[str, Any]] | None = None,
        max_output_tokens: int | None = None,
        stream: bool | None = None,
        extra_body: Mapping[str, Any] | None = None,
        timeout: float | None = None,
        stream_idle_timeout: float | None = None,
    ) -> ResponseCreateResponse | Any:
        return await self._create_response(
            request=request,
            model=model,
            input=input,
            max_output_tokens=max_output_tokens,
            stream=stream,
            extra_body=extra_body,
            timeout=timeout,
            stream_idle_timeout=stream_idle_timeout,
        )

    async def _create_response(
        self,
        *,
        request: ResponseCreateRequest | Mapping[str, Any] | None = None,
        model: str | None = None,
        input: str | list[dict[str, Any]] | None = None,
        max_output_tokens: int | None = None,
        stream: bool | None = None,
        extra_body: Mapping[str, Any] | None = None,
        timeout: float | None = None,
        stream_idle_timeout: float | None = None,
        return_raw_response: bool = False,
        return_streaming_response: bool = False,
    ) -> ResponseCreateResponse | Any:
        built_request = build_response_create_request(
            request=request,
            model=model,
            input=input,
            max_output_tokens=max_output_tokens,
            stream=stream,
            extra_body=extra_body,
        )
        payload = built_request.to_dict()
        if built_request.stream is True or return_streaming_response:
            return await self._surface.stream_request(
                "POST",
                "/v1/responses",
                json_body=payload,
                headers={"Accept": "text/event-stream"},
                timeout=timeout,
                read_timeout=stream_idle_timeout,
            )
        response = await self._surface.request(
            "POST",
            "/v1/responses",
            json_body=payload,
            timeout=timeout,
        )
        if return_raw_response:
            return response
        return ResponseCreateResponse.from_dict(response.json())


class AsyncTextCompletionsWithRawResponse:

    def __init__(self, client: AsyncTextCompletionsClient) -> None:
        self._client = client

    async def create(self, **kwargs: Any) -> Any:
        request = normalize_text_completion_wrapper_request(
            kwargs.get("request"),
            stream=False,
        )
        if request is not None:
            kwargs["request"] = request
        elif kwargs.get("stream") is True:
            raise ValueError(
                "`with_raw_response.create` does not support `stream=True`. "
                "Use `with_streaming_response.create(...)` for SSE responses.")
        else:
            kwargs["stream"] = False
        return await self._client._create_response(
            return_raw_response=True,
            **kwargs,
        )


class AsyncTextCompletionsWithStreamingResponse:

    def __init__(self, client: AsyncTextCompletionsClient) -> None:
        self._client = client

    async def create(self, **kwargs: Any) -> Any:
        request = normalize_text_completion_wrapper_request(
            kwargs.get("request"),
            stream=True,
        )
        if request is not None:
            kwargs["request"] = request
        elif kwargs.get("stream") is False:
            raise ValueError(
                "`with_streaming_response.create` requires streaming. "
                "Omit `stream` or pass `True`.")
        else:
            kwargs["stream"] = True
        return await self._client._create_response(
            return_streaming_response=True,
            **kwargs,
        )


class AsyncResponsesWithRawResponse:

    def __init__(self, client: AsyncResponsesClient) -> None:
        self._client = client

    async def create(self, **kwargs: Any) -> Any:
        request = normalize_response_wrapper_request(
            kwargs.get("request"),
            stream=False,
        )
        if request is not None:
            kwargs["request"] = request
        elif kwargs.get("stream") is True:
            raise ValueError(
                "`with_raw_response.create` does not support `stream=True`. "
                "Use `with_streaming_response.create(...)` for SSE responses.")
        else:
            kwargs["stream"] = False
        return await self._client._create_response(
            return_raw_response=True,
            **kwargs,
        )


class AsyncResponsesWithStreamingResponse:

    def __init__(self, client: AsyncResponsesClient) -> None:
        self._client = client

    async def create(self, **kwargs: Any) -> Any:
        request = normalize_response_wrapper_request(
            kwargs.get("request"),
            stream=True,
        )
        if request is not None:
            kwargs["request"] = request
        elif kwargs.get("stream") is False:
            raise ValueError(
                "`with_streaming_response.create` requires streaming. "
                "Omit `stream` or pass `True`.")
        else:
            kwargs["stream"] = True
        return await self._client._create_response(
            return_streaming_response=True,
            **kwargs,
        )


class AsyncTokenizeClient:

    def __init__(self, surface: _AsyncInferenceSurfaceProtocol) -> None:
        self._surface = surface

    async def create(
        self,
        *,
        request: TokenizeRequest | Mapping[str, Any] | None = None,
        model: str | None = None,
        prompt: str | list[str] | None = None,
        messages: list[ChatMessage | dict[str, Any]] | None = None,
        extra_body: Mapping[str, Any] | None = None,
        timeout: float | None = None,
    ) -> TokenizeResponse:
        built_request = build_tokenize_request(
            request=request,
            model=model,
            prompt=prompt,
            messages=messages,
            extra_body=extra_body,
        )
        response = await self._surface.request(
            "POST",
            "/tokenize",
            json_body=built_request.to_dict(),
            timeout=timeout,
        )
        return TokenizeResponse.from_dict(response.json())


class AsyncDetokenizeClient:

    def __init__(self, surface: _AsyncInferenceSurfaceProtocol) -> None:
        self._surface = surface

    async def create(
        self,
        *,
        request: DetokenizeRequest | Mapping[str, Any] | None = None,
        model: str | None = None,
        tokens: list[int] | None = None,
        extra_body: Mapping[str, Any] | None = None,
        timeout: float | None = None,
    ) -> DetokenizeResponse:
        built_request = build_detokenize_request(
            request=request,
            model=model,
            tokens=tokens,
            extra_body=extra_body,
        )
        response = await self._surface.request(
            "POST",
            "/detokenize",
            json_body=built_request.to_dict(),
            timeout=timeout,
        )
        return DetokenizeResponse.from_dict(response.json())


class AsyncHealthClient:

    def __init__(self, surface: _AsyncInferenceSurfaceProtocol) -> None:
        self._surface = surface

    async def get(self, *, timeout: float | None = None) -> HealthResponse:
        response = await self._surface.request("GET",
                                               "/health",
                                               timeout=timeout)
        return HealthResponse.from_dict(response.json())


class AsyncVersionClient:

    def __init__(self, surface: _AsyncInferenceSurfaceProtocol) -> None:
        self._surface = surface

    async def get(self, *, timeout: float | None = None) -> VersionResponse:
        response = await self._surface.request("GET",
                                               "/version",
                                               timeout=timeout)
        return VersionResponse.from_dict(response.json())


class AsyncChatCompletionsWithRawResponse:

    def __init__(self, client: AsyncChatCompletionsClient) -> None:
        self._client = client

    async def create(self, **kwargs: Any) -> Any:
        if kwargs.get("stream") is True:
            raise ValueError(
                "`with_raw_response.create` does not support `stream=True`. "
                "Use `with_streaming_response.create(...)` for SSE responses.")
        kwargs["stream"] = False
        return await self._client._create_response(
            return_raw_response=True,
            **kwargs,
        )


class AsyncChatCompletionsWithStreamingResponse:

    def __init__(self, client: AsyncChatCompletionsClient) -> None:
        self._client = client

    async def create(self, **kwargs: Any) -> Any:
        if kwargs.get("stream") is False:
            raise ValueError(
                "`with_streaming_response.create` requires streaming. "
                "Omit `stream` or pass `True`.")
        kwargs["stream"] = True
        return await self._client._create_response(
            return_streaming_response=True,
            **kwargs,
        )


class AsyncChatCompletionsClient:

    def __init__(self, surface: _AsyncInferenceSurfaceProtocol) -> None:
        self._surface = surface
        self.with_raw_response = AsyncChatCompletionsWithRawResponse(self)
        self.with_streaming_response = (
            AsyncChatCompletionsWithStreamingResponse(self))

    async def create(
        self,
        *,
        request: ChatCompletionRequest | Mapping[str, Any] | None = None,
        model: str | None = None,
        messages: Sequence[ChatMessage | Mapping[str, Any]] | None = None,
        temperature: float | None = None,
        top_p: float | None = None,
        max_tokens: int | None = None,
        max_completion_tokens: int | None = None,
        n: int | None = None,
        stop: str | list[str] | None = None,
        top_k: int | None = None,
        min_p: float | None = None,
        typical_p: float | None = None,
        seed: int | None = None,
        repetition_penalty: float | None = None,
        mirostat_target: float | None = None,
        mirostat_lr: float | None = None,
        stream: bool = False,
        stream_options: StreamOptions | Mapping[str, Any] | None = None,
        response_format: ResponseFormat | Mapping[str, Any] | None = None,
        tools: Sequence[ChatCompletionTool | Mapping[str, Any]] | None = None,
        tool_choice: str | FunctionSelection | Mapping[str, Any] | None = None,
        parallel_tool_calls: bool | None = None,
        presence_penalty: float | None = None,
        frequency_penalty: float | None = None,
        logprobs: bool | None = None,
        top_logprobs: int | None = None,
        logit_bias: Mapping[str, float] | None = None,
        user: str | None = None,
        metadata: Mapping[str, Any] | None = None,
        prompt_truncate_len: int | None = None,
        context_length_exceeded_behavior: str | None = None,
        return_token_ids: bool | None = None,
        prompt_cache_isolation_key: str | None = None,
        raw_output: bool | None = None,
        perf_metrics_in_response: bool | None = None,
        echo: bool | None = None,
        echo_last: int | None = None,
        ignore_eos: bool | None = None,
        speculation: str | list[int] | None = None,
        prediction: PredictedOutput | str | Mapping[str, Any] | None = None,
        reasoning_effort: str | int | bool | None = None,
        reasoning_history: str | None = None,
        thinking: ThinkingConfigEnabled | ThinkingConfigDisabled
        | Mapping[str, Any] | None = None,
        functions: Sequence[ChatCompletionFunction | Mapping[str, Any]]
        | None = None,
        function_call: str | FunctionNameSpec | Mapping[str, Any]
        | None = None,
        extra_body: Mapping[str, Any] | None = None,
        timeout: float | None = None,
        stream_idle_timeout: float | None = None,
        user_id: str | None = None,
    ) -> ChatCompletionResponse | AsyncChatCompletionStream:
        return await self._create_response(
            request=request,
            model=model,
            messages=messages,
            temperature=temperature,
            top_p=top_p,
            max_tokens=max_tokens,
            max_completion_tokens=max_completion_tokens,
            n=n,
            stop=stop,
            top_k=top_k,
            min_p=min_p,
            typical_p=typical_p,
            seed=seed,
            repetition_penalty=repetition_penalty,
            mirostat_target=mirostat_target,
            mirostat_lr=mirostat_lr,
            stream=stream,
            stream_options=stream_options,
            response_format=response_format,
            tools=tools,
            tool_choice=tool_choice,
            parallel_tool_calls=parallel_tool_calls,
            presence_penalty=presence_penalty,
            frequency_penalty=frequency_penalty,
            logprobs=logprobs,
            top_logprobs=top_logprobs,
            logit_bias=logit_bias,
            user=user,
            metadata=metadata,
            prompt_truncate_len=prompt_truncate_len,
            context_length_exceeded_behavior=context_length_exceeded_behavior,
            return_token_ids=return_token_ids,
            prompt_cache_isolation_key=prompt_cache_isolation_key,
            raw_output=raw_output,
            perf_metrics_in_response=perf_metrics_in_response,
            echo=echo,
            echo_last=echo_last,
            ignore_eos=ignore_eos,
            speculation=speculation,
            prediction=prediction,
            reasoning_effort=reasoning_effort,
            reasoning_history=reasoning_history,
            thinking=thinking,
            functions=functions,
            function_call=function_call,
            extra_body=extra_body,
            timeout=timeout,
            stream_idle_timeout=stream_idle_timeout,
            user_id=user_id,
        )

    async def _create_response(
        self,
        *,
        request: ChatCompletionRequest | Mapping[str, Any] | None = None,
        model: str | None = None,
        messages: Sequence[ChatMessage | Mapping[str, Any]] | None = None,
        temperature: float | None = None,
        top_p: float | None = None,
        max_tokens: int | None = None,
        max_completion_tokens: int | None = None,
        n: int | None = None,
        stop: str | list[str] | None = None,
        top_k: int | None = None,
        min_p: float | None = None,
        typical_p: float | None = None,
        seed: int | None = None,
        repetition_penalty: float | None = None,
        mirostat_target: float | None = None,
        mirostat_lr: float | None = None,
        stream: bool = False,
        stream_options: StreamOptions | Mapping[str, Any] | None = None,
        response_format: ResponseFormat | Mapping[str, Any] | None = None,
        tools: Sequence[ChatCompletionTool | Mapping[str, Any]] | None = None,
        tool_choice: str | FunctionSelection | Mapping[str, Any] | None = None,
        parallel_tool_calls: bool | None = None,
        presence_penalty: float | None = None,
        frequency_penalty: float | None = None,
        logprobs: bool | None = None,
        top_logprobs: int | None = None,
        logit_bias: Mapping[str, float] | None = None,
        user: str | None = None,
        metadata: Mapping[str, Any] | None = None,
        prompt_truncate_len: int | None = None,
        context_length_exceeded_behavior: str | None = None,
        return_token_ids: bool | None = None,
        prompt_cache_isolation_key: str | None = None,
        raw_output: bool | None = None,
        perf_metrics_in_response: bool | None = None,
        echo: bool | None = None,
        echo_last: int | None = None,
        ignore_eos: bool | None = None,
        speculation: str | list[int] | None = None,
        prediction: PredictedOutput | str | Mapping[str, Any] | None = None,
        reasoning_effort: str | int | bool | None = None,
        reasoning_history: str | None = None,
        thinking: ThinkingConfigEnabled | ThinkingConfigDisabled
        | Mapping[str, Any] | None = None,
        functions: Sequence[ChatCompletionFunction | Mapping[str, Any]]
        | None = None,
        function_call: str | FunctionNameSpec | Mapping[str, Any]
        | None = None,
        extra_body: Mapping[str, Any] | None = None,
        timeout: float | None = None,
        stream_idle_timeout: float | None = None,
        user_id: str | None = None,
        return_raw_response: bool = False,
        return_streaming_response: bool = False,
    ) -> ChatCompletionResponse | AsyncChatCompletionStream | Any:
        built_request = build_chat_completion_request(
            request=request,
            model=model,
            messages=messages,
            temperature=temperature,
            top_p=top_p,
            max_tokens=max_tokens,
            max_completion_tokens=max_completion_tokens,
            n=n,
            stop=stop,
            top_k=top_k,
            min_p=min_p,
            typical_p=typical_p,
            seed=seed,
            repetition_penalty=repetition_penalty,
            mirostat_target=mirostat_target,
            mirostat_lr=mirostat_lr,
            stream=stream,
            stream_options=stream_options,
            response_format=response_format,
            tools=tools,
            tool_choice=tool_choice,
            parallel_tool_calls=parallel_tool_calls,
            presence_penalty=presence_penalty,
            frequency_penalty=frequency_penalty,
            logprobs=logprobs,
            top_logprobs=top_logprobs,
            logit_bias=logit_bias,
            user=user,
            metadata=metadata,
            prompt_truncate_len=prompt_truncate_len,
            context_length_exceeded_behavior=context_length_exceeded_behavior,
            return_token_ids=return_token_ids,
            prompt_cache_isolation_key=prompt_cache_isolation_key,
            raw_output=raw_output,
            perf_metrics_in_response=perf_metrics_in_response,
            echo=echo,
            echo_last=echo_last,
            ignore_eos=ignore_eos,
            speculation=speculation,
            prediction=prediction,
            reasoning_effort=reasoning_effort,
            reasoning_history=reasoning_history,
            thinking=thinking,
            functions=functions,
            function_call=function_call,
            extra_body=extra_body,
        )
        payload = built_request.to_dict()

        if stream or return_streaming_response:
            response = await self._surface.stream_request(
                "POST",
                "/v1/chat/completions",
                json_body=payload,
                headers={"Accept": "text/event-stream"},
                timeout=timeout,
                read_timeout=stream_idle_timeout,
                user_id=user_id,
            )
            if return_streaming_response:
                return response
            return AsyncChatCompletionStream(response)

        response = await self._surface.request(
            "POST",
            "/v1/chat/completions",
            json_body=payload,
            timeout=timeout,
            user_id=user_id,
        )
        if return_raw_response:
            return response
        return ChatCompletionResponse.from_dict(response.json())
