from __future__ import annotations

from typing import Any, Mapping, Sequence

from tensormesh.types.inference import ChatCompletionFunction
from tensormesh.types.inference import ChatCompletionRequest
from tensormesh.types.inference import ChatCompletionTool
from tensormesh.types.inference import ChatMessage
from tensormesh.types.inference import FunctionNameSpec
from tensormesh.types.inference import FunctionSelection
from tensormesh.types.inference import PredictedOutput
from tensormesh.types.inference import ResponseFormat
from tensormesh.types.inference import StreamOptions
from tensormesh.types.inference import ThinkingConfigDisabled
from tensormesh.types.inference import ThinkingConfigEnabled

__all__ = ["build_chat_completion_request"]


def build_chat_completion_request(
    *,
    request: ChatCompletionRequest | Mapping[str, Any] | None,
    model: str | None,
    messages: Sequence[ChatMessage | Mapping[str, Any]] | None,
    temperature: float | None,
    top_p: float | None,
    max_tokens: int | None,
    max_completion_tokens: int | None,
    n: int | None,
    stop: str | list[str] | None,
    top_k: int | None,
    min_p: float | None,
    typical_p: float | None,
    seed: int | None,
    repetition_penalty: float | None,
    mirostat_target: float | None,
    mirostat_lr: float | None,
    stream: bool,
    stream_options: StreamOptions | Mapping[str, Any] | None,
    response_format: ResponseFormat | Mapping[str, Any] | None,
    tools: Sequence[ChatCompletionTool | Mapping[str, Any]] | None,
    tool_choice: str | FunctionSelection | Mapping[str, Any] | None,
    parallel_tool_calls: bool | None,
    presence_penalty: float | None,
    frequency_penalty: float | None,
    logprobs: bool | None,
    top_logprobs: int | None,
    logit_bias: Mapping[str, float] | None,
    user: str | None,
    metadata: Mapping[str, Any] | None,
    prompt_truncate_len: int | None,
    context_length_exceeded_behavior: str | None,
    return_token_ids: bool | None,
    prompt_cache_isolation_key: str | None,
    raw_output: bool | None,
    perf_metrics_in_response: bool | None,
    echo: bool | None,
    echo_last: int | None,
    ignore_eos: bool | None,
    speculation: str | list[int] | None,
    prediction: PredictedOutput | str | Mapping[str, Any] | None,
    reasoning_effort: str | int | bool | None,
    reasoning_history: str | None,
    thinking: ThinkingConfigEnabled | ThinkingConfigDisabled
    | Mapping[str, Any] | None,
    functions: Sequence[ChatCompletionFunction | Mapping[str, Any]] | None,
    function_call: str | FunctionNameSpec | Mapping[str, Any] | None,
    extra_body: Mapping[str, Any] | None,
) -> ChatCompletionRequest:
    if request is not None:
        if any(value is not None for value in (
                model,
                messages,
                temperature,
                top_p,
                max_tokens,
                max_completion_tokens,
                n,
                stop,
                top_k,
                min_p,
                typical_p,
                seed,
                repetition_penalty,
                mirostat_target,
                mirostat_lr,
                stream_options,
                response_format,
                tools,
                tool_choice,
                parallel_tool_calls,
                presence_penalty,
                frequency_penalty,
                logprobs,
                top_logprobs,
                logit_bias,
                user,
                metadata,
                prompt_truncate_len,
                context_length_exceeded_behavior,
                return_token_ids,
                prompt_cache_isolation_key,
                raw_output,
                perf_metrics_in_response,
                echo,
                echo_last,
                ignore_eos,
                speculation,
                prediction,
                reasoning_effort,
                reasoning_history,
                thinking,
                functions,
                function_call,
                extra_body,
        )):
            raise ValueError(
                "Pass either `request=` or individual chat completion fields, not both."
            )

        built_request = (request if isinstance(request, ChatCompletionRequest)
                         else ChatCompletionRequest.from_dict(dict(request)))
        if stream:
            built_request = ChatCompletionRequest.from_dict(
                built_request.to_dict())
            built_request.stream = True
        return built_request

    if model is None or messages is None:
        raise ValueError(
            "Missing required fields. `model` and `messages` are required.")

    return ChatCompletionRequest(
        model=model,
        messages=[_coerce_chat_message(item) for item in messages],
        temperature=temperature,
        top_p=top_p,
        max_tokens=max_tokens,
        max_completion_tokens=max_completion_tokens,
        n=n,
        stop=stop,
        top_k=top_k,
        min_p=min_p,
        typical_p=typical_p,
        seed=seed,
        repetition_penalty=repetition_penalty,
        mirostat_target=mirostat_target,
        mirostat_lr=mirostat_lr,
        stream=stream or None,
        stream_options=_coerce_stream_options(stream_options),
        response_format=_coerce_response_format(response_format),
        tools=(None if tools is None else
               [_coerce_chat_tool(item) for item in tools]),
        tool_choice=_coerce_tool_choice(tool_choice),
        parallel_tool_calls=parallel_tool_calls,
        presence_penalty=presence_penalty,
        frequency_penalty=frequency_penalty,
        logprobs=logprobs,
        top_logprobs=top_logprobs,
        logit_bias=(dict(logit_bias) if logit_bias is not None else None),
        user=user,
        metadata=(dict(metadata) if metadata is not None else None),
        prompt_truncate_len=prompt_truncate_len,
        context_length_exceeded_behavior=context_length_exceeded_behavior,
        return_token_ids=return_token_ids,
        prompt_cache_isolation_key=prompt_cache_isolation_key,
        raw_output=raw_output,
        perf_metrics_in_response=perf_metrics_in_response,
        echo=echo,
        echo_last=echo_last,
        ignore_eos=ignore_eos,
        speculation=speculation,
        prediction=_coerce_prediction(prediction),
        reasoning_effort=reasoning_effort,
        reasoning_history=reasoning_history,
        thinking=_coerce_thinking(thinking),
        functions=(None if functions is None else
                   [_coerce_chat_function(item) for item in functions]),
        function_call=_coerce_function_call(function_call),
        extra=(dict(extra_body) if extra_body is not None else {}),
    )


def _coerce_chat_message(
        value: ChatMessage | Mapping[str, Any]) -> ChatMessage:
    if isinstance(value, ChatMessage):
        return value
    return ChatMessage.from_dict(dict(value))


def _coerce_chat_function(
    value: ChatCompletionFunction | Mapping[str, Any],
) -> ChatCompletionFunction:
    if isinstance(value, ChatCompletionFunction):
        return value
    return ChatCompletionFunction.from_dict(dict(value))


def _coerce_chat_tool(
    value: ChatCompletionTool | Mapping[str, Any], ) -> ChatCompletionTool:
    if isinstance(value, ChatCompletionTool):
        return value
    return ChatCompletionTool.from_dict(dict(value))


def _coerce_stream_options(
    value: StreamOptions | Mapping[str, Any] | None, ) -> StreamOptions | None:
    if value is None or isinstance(value, StreamOptions):
        return value
    return StreamOptions.from_dict(dict(value))


def _coerce_response_format(
    value: ResponseFormat | Mapping[str, Any] | None,
) -> ResponseFormat | None:
    if value is None or isinstance(value, ResponseFormat):
        return value
    return ResponseFormat.from_dict(dict(value))


def _coerce_tool_choice(
    value: str | FunctionSelection | Mapping[str, Any] | None,
) -> str | FunctionSelection | None:
    if value is None or isinstance(value, str) or isinstance(
            value, FunctionSelection):
        return value
    return FunctionSelection.from_dict(dict(value))


def _coerce_prediction(
    value: PredictedOutput | str | Mapping[str, Any] | None,
) -> PredictedOutput | str | None:
    if value is None or isinstance(value, str) or isinstance(
            value, PredictedOutput):
        return value
    return PredictedOutput.from_dict(dict(value))


def _coerce_thinking(
    value: ThinkingConfigEnabled | ThinkingConfigDisabled | Mapping[str, Any]
    | None,
) -> ThinkingConfigEnabled | ThinkingConfigDisabled | None:
    if value is None or isinstance(
            value, (ThinkingConfigEnabled, ThinkingConfigDisabled)):
        return value
    payload = dict(value)
    if payload.get("type") == "disabled":
        return ThinkingConfigDisabled.from_dict(payload)
    return ThinkingConfigEnabled.from_dict(payload)


def _coerce_function_call(
    value: str | FunctionNameSpec | Mapping[str, Any] | None,
) -> str | FunctionNameSpec | None:
    if value is None or isinstance(value, str) or isinstance(
            value, FunctionNameSpec):
        return value
    return FunctionNameSpec.from_dict(dict(value))
