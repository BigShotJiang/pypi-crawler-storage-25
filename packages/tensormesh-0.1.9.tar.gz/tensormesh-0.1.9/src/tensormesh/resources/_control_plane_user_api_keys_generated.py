from __future__ import annotations

from typing import Any, Mapping

from tensormesh.resources._control_plane_shared import coerce_request
from tensormesh.resources._control_plane_shared import compact_params
from tensormesh.resources._control_plane_shared import \
    ControlPlaneOperationSpec
from tensormesh.resources._control_plane_shared import \
    require_response_list_field
from tensormesh.resources._control_plane_shared import \
    require_response_mapping_field
from tensormesh.types.control_plane import ApiKey
from tensormesh.types.control_plane import CreateUserApiKeyRequest
from tensormesh.types.control_plane import EmptyResult

__all__ = [
    "USER_API_KEYS_CREATE_OPERATION",
    "USER_API_KEYS_DELETE_OPERATION",
    "USER_API_KEYS_LIST_OPERATION",
    "build_user_api_keys_create_payload",
    "build_user_api_keys_delete_params",
    "build_user_api_keys_list_params",
    "parse_user_api_keys_create_response",
    "parse_user_api_keys_delete_response",
    "parse_user_api_keys_list_response",
]

USER_API_KEYS_LIST_OPERATION = ControlPlaneOperationSpec(
    method="GET",
    path="/v1/users/api-keys",
)
USER_API_KEYS_DELETE_OPERATION = ControlPlaneOperationSpec(
    method="DELETE",
    path="/v1/users/api-keys",
)
USER_API_KEYS_CREATE_OPERATION = ControlPlaneOperationSpec(
    method="POST",
    path="/v1/users/api-keys",
)


def build_user_api_keys_list_params(
    *,
    user_id: str | None,
    include_deleted: bool | None,
) -> dict[str, object]:
    return compact_params({
        "userId": user_id,
        "includeDeleted": include_deleted,
    })


def parse_user_api_keys_list_response(body: Mapping[str, Any]) -> list[ApiKey]:
    items = require_response_list_field(body,
                                        "apiKeys",
                                        context="user api keys list response")
    return [ApiKey.from_dict(item) for item in items]


def build_user_api_keys_delete_params(
    *,
    user_id: str | None,
    api_key: str | None,
) -> dict[str, object]:
    return compact_params({
        "userId": user_id,
        "apiKey": api_key,
    })


def parse_user_api_keys_delete_response(
        body: Mapping[str, Any]) -> EmptyResult:
    if not body:
        return EmptyResult()
    if body.get("empty") is None and "empty" in body:
        return EmptyResult()
    empty = require_response_mapping_field(
        body, "empty", context="user api keys delete response")
    return EmptyResult.from_dict(empty)


def build_user_api_keys_create_payload(
    *,
    request: CreateUserApiKeyRequest | Mapping[str, Any] | None,
    user_id: str | None,
    name: str | None,
    scopes: list[str] | None,
    expires_at: str | None,
) -> CreateUserApiKeyRequest:
    return coerce_request(
        request=request,
        request_cls=CreateUserApiKeyRequest,
        request_name="API key create request",
        fields={
            "user_id": user_id,
            "name": name,
            "scopes": scopes,
            "expires_at": expires_at,
        },
    )


def parse_user_api_keys_create_response(
    body: Mapping[str, Any], ) -> ApiKey | None:
    api_key = require_response_mapping_field(
        body, "apiKey", context="user api keys create response")
    return ApiKey.from_dict(api_key)
