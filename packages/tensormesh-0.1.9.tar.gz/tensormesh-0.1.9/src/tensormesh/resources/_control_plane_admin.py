from __future__ import annotations

from typing import Any, Iterator, Mapping

from tensormesh.resources._control_plane_models_generated import \
    ADMIN_MODELS_DELETE_OPERATION
from tensormesh.resources._control_plane_models_generated import \
    ADMIN_MODELS_LIST_OPERATION
from tensormesh.resources._control_plane_models_generated import \
    build_admin_models_delete_params
from tensormesh.resources._control_plane_models_generated import \
    build_admin_models_delete_path
from tensormesh.resources._control_plane_models_generated import \
    build_admin_models_list_params
from tensormesh.resources._control_plane_models_generated import \
    models_next_numbered_page
from tensormesh.resources._control_plane_models_generated import \
    parse_admin_models_delete_response
from tensormesh.resources._control_plane_models_generated import \
    parse_admin_models_list_response
from tensormesh.resources._control_plane_shared import \
    coerce_request as _coerce_request
from tensormesh.resources._control_plane_shared import \
    compact_params as _compact_params
from tensormesh.resources._control_plane_shared import \
    ControlPlaneSurfaceProtocol as _ControlPlaneSurfaceProtocol
from tensormesh.resources._control_plane_shared import \
    numbered_page_next as _numbered_page_next
from tensormesh.resources._control_plane_shared import \
    quote_path_value as _quote_path_value
from tensormesh.resources._control_plane_shared import \
    require_response_list_field as _require_response_list_field
from tensormesh.resources._control_plane_shared import \
    require_response_mapping_field as _require_response_mapping_field
from tensormesh.types.control_plane import AdminBalanceAddRequest
from tensormesh.types.control_plane import AdminBalancesLookupRequest
from tensormesh.types.control_plane import AdminSpendingSummaryRequest
from tensormesh.types.control_plane import AdminUserChangeRoleRequest
from tensormesh.types.control_plane import EmptyResult
from tensormesh.types.control_plane import GpuPricing
from tensormesh.types.control_plane import GpuPricingUpsertRequest
from tensormesh.types.control_plane import Model
from tensormesh.types.control_plane import ModelsPage
from tensormesh.types.control_plane import Money
from tensormesh.types.control_plane import Product
from tensormesh.types.control_plane import ProductUpsertRequest
from tensormesh.types.control_plane import ServerlessPricing
from tensormesh.types.control_plane import ServerlessPricingUpsertRequest
from tensormesh.types.control_plane import User
from tensormesh.types.control_plane import UserBalanceInfo
from tensormesh.types.control_plane import UsersPage
from tensormesh.types.control_plane import UserSpendingSummary


class AdminModelsClient:

    def __init__(self, surface: _ControlPlaneSurfaceProtocol) -> None:
        self._surface = surface

    def list(
        self,
        *,
        user_id: str | None = None,
        page: int | None = None,
        size: int | None = None,
        timeout: float | None = None,
    ) -> ModelsPage:
        response = self._surface.request(
            ADMIN_MODELS_LIST_OPERATION.method,
            ADMIN_MODELS_LIST_OPERATION.path,
            params=build_admin_models_list_params(user_id=user_id,
                                                  page=page,
                                                  size=size),
            timeout=timeout,
        )
        return parse_admin_models_list_response(response.json())

    def auto_paging_iter(
        self,
        *,
        user_id: str | None = None,
        page: int | None = None,
        size: int | None = None,
        timeout: float | None = None,
    ) -> Iterator[Model]:
        current_page = 1 if page is None else page
        while True:
            current = self.list(
                user_id=user_id,
                page=current_page,
                size=size,
                timeout=timeout,
            )
            for model in current.models:
                yield model

            has_more, next_page = models_next_numbered_page(
                current, current_page=current_page, size=size)
            if not has_more:
                return
            current_page = next_page

    def delete(
        self,
        model_id: str,
        *,
        user_id: str | None = None,
        timeout: float | None = None,
    ) -> EmptyResult:
        response = self._surface.request(
            ADMIN_MODELS_DELETE_OPERATION.method,
            build_admin_models_delete_path(model_id),
            params=build_admin_models_delete_params(user_id=user_id),
            timeout=timeout,
        )
        return parse_admin_models_delete_response(response.json())


class AdminUsersClient:

    def __init__(self, surface: _ControlPlaneSurfaceProtocol) -> None:
        self._surface = surface

    def list(
        self,
        *,
        user_id: str | None = None,
        page: int | None = None,
        size: int | None = None,
        timeout: float | None = None,
    ) -> UsersPage:
        response = self._surface.request(
            "GET",
            "/v1/admin/users",
            params=_compact_params({
                "userId": user_id,
                "page": page,
                "size": size,
            }),
            timeout=timeout,
        )
        return UsersPage.from_dict(response.json())

    def auto_paging_iter(
        self,
        *,
        user_id: str | None = None,
        page: int | None = None,
        size: int | None = None,
        timeout: float | None = None,
    ) -> Iterator[User]:
        current_page = 1 if page is None else page
        while True:
            current = self.list(
                user_id=user_id,
                page=current_page,
                size=size,
                timeout=timeout,
            )
            for user in current.users:
                yield user

            has_more, next_page = _numbered_page_next(
                page_field=current.page,
                size_field=current.size,
                total_field=current.total,
                current_item_count=len(current.users),
                current_page=current_page,
                size=size,
            )
            if not has_more:
                return
            current_page = next_page

    def change_role(
        self,
        *,
        request: AdminUserChangeRoleRequest | Mapping[str, Any] | None = None,
        target_user_id: str | None = None,
        target_user_role: str | None = None,
        user_id: str | None = None,
        timeout: float | None = None,
    ) -> User | None:
        payload = _coerce_request(
            request=request,
            request_cls=AdminUserChangeRoleRequest,
            request_name="admin user role change request",
            fields={
                "target_user_id": target_user_id,
                "target_user_role": target_user_role,
                "user_id": user_id,
            },
        )
        response = self._surface.request(
            "POST",
            "/v1/admin/users/change_role",
            json_body=payload.to_dict(),
            timeout=timeout,
        )
        return User.from_dict(
            _require_response_mapping_field(
                response.json(),
                "user",
                context="admin user role change response",
            ))


class AdminBillingBalancesClient:

    def __init__(self, surface: _ControlPlaneSurfaceProtocol) -> None:
        self._surface = surface

    def get(
        self,
        *,
        request: AdminBalancesLookupRequest | Mapping[str, Any] | None = None,
        user_id: str | None = None,
        target_user_ids: list[str] | None = None,
        timeout: float | None = None,
    ) -> list[UserBalanceInfo]:
        payload = _coerce_request(
            request=request,
            request_cls=AdminBalancesLookupRequest,
            request_name="admin balances lookup request",
            fields={
                "user_id": user_id,
                "target_user_ids": target_user_ids,
            },
        )
        response = self._surface.request(
            "POST",
            "/v1/admin/billing/balances",
            json_body=payload.to_dict(),
            timeout=timeout,
        )
        body = response.json()
        return [
            UserBalanceInfo.from_dict(item)
            for item in _require_response_list_field(
                body,
                "balances",
                context="admin balances lookup response",
            )
        ]

    def add(
        self,
        *,
        request: AdminBalanceAddRequest | Mapping[str, Any] | None = None,
        target_user_id: str | None = None,
        amount: Money | Mapping[str, Any] | None = None,
        user_id: str | None = None,
        timeout: float | None = None,
    ) -> Money | None:
        payload = _coerce_request(
            request=request,
            request_cls=AdminBalanceAddRequest,
            request_name="admin balance add request",
            fields={
                "target_user_id": target_user_id,
                "amount": amount,
                "user_id": user_id,
            },
        )
        response = self._surface.request(
            "POST",
            "/v1/admin/billing/balances:add",
            json_body=payload.to_dict(),
            timeout=timeout,
        )
        return Money.from_dict(
            _require_response_mapping_field(
                response.json(),
                "balance",
                context="admin balance add response",
            ))


class AdminBillingSpendingClient:

    def __init__(self, surface: _ControlPlaneSurfaceProtocol) -> None:
        self._surface = surface

    def summary(
        self,
        *,
        request: AdminSpendingSummaryRequest | Mapping[str, Any] | None = None,
        user_id: str | None = None,
        target_user_ids: list[str] | None = None,
        timeout: float | None = None,
    ) -> list[UserSpendingSummary]:
        payload = _coerce_request(
            request=request,
            request_cls=AdminSpendingSummaryRequest,
            request_name="admin spending summary request",
            fields={
                "user_id": user_id,
                "target_user_ids": target_user_ids,
            },
        )
        response = self._surface.request(
            "POST",
            "/v1/admin/billing/spending/summary",
            json_body=payload.to_dict(),
            timeout=timeout,
        )
        body = response.json()
        return [
            UserSpendingSummary.from_dict(item)
            for item in _require_response_list_field(
                body,
                "summaries",
                context="admin spending summary response",
            )
        ]


class AdminGpuPricingClient:

    def __init__(self, surface: _ControlPlaneSurfaceProtocol) -> None:
        self._surface = surface

    def upsert(
        self,
        *,
        request: GpuPricingUpsertRequest | Mapping[str, Any] | None = None,
        pricing: GpuPricing | Mapping[str, Any] | None = None,
        method: str = "POST",
        timeout: float | None = None,
    ) -> GpuPricing | None:
        payload = _coerce_request(
            request=request,
            request_cls=GpuPricingUpsertRequest,
            request_name="GPU pricing upsert request",
            fields={"pricing": pricing},
        )
        normalized_method = method.upper()
        if normalized_method not in {"POST", "PUT"}:
            raise ValueError("`method` must be 'POST' or 'PUT'.")
        response = self._surface.request(
            normalized_method,
            "/v1/admin/billing/gpu-pricing",
            json_body=payload.to_dict(),
            timeout=timeout,
        )
        return GpuPricing.from_dict(
            _require_response_mapping_field(
                response.json(),
                "pricing",
                context="admin GPU pricing upsert response",
            ))

    def create(
        self,
        *,
        request: GpuPricingUpsertRequest | Mapping[str, Any] | None = None,
        pricing: GpuPricing | Mapping[str, Any] | None = None,
        timeout: float | None = None,
    ) -> GpuPricing | None:
        return self.upsert(
            request=request,
            pricing=pricing,
            method="POST",
            timeout=timeout,
        )

    def update(
        self,
        *,
        request: GpuPricingUpsertRequest | Mapping[str, Any] | None = None,
        pricing: GpuPricing | Mapping[str, Any] | None = None,
        timeout: float | None = None,
    ) -> GpuPricing | None:
        return self.upsert(
            request=request,
            pricing=pricing,
            method="PUT",
            timeout=timeout,
        )

    def delete(
        self,
        gpu_type: str,
        cloud_provider: str,
        *,
        timeout: float | None = None,
    ) -> EmptyResult:
        response = self._surface.request(
            "DELETE",
            ("/v1/admin/billing/gpu-pricing/"
             f"{_quote_path_value(gpu_type)}/{_quote_path_value(cloud_provider)}"
             ),
            timeout=timeout,
        )
        return EmptyResult.from_dict(
            _require_response_mapping_field(
                response.json(),
                "empty",
                context="admin GPU pricing delete response",
            ))


class AdminServerlessPricingClient:

    def __init__(self, surface: _ControlPlaneSurfaceProtocol) -> None:
        self._surface = surface

    def list(
        self,
        *,
        model: str | None = None,
        active_only: bool | None = None,
        timeout: float | None = None,
    ) -> list[ServerlessPricing]:
        response = self._surface.request(
            "GET",
            "/v1/admin/billing/serverless-pricing",
            params=_compact_params({
                "model": model,
                "activeOnly": active_only,
            }),
            timeout=timeout,
        )
        body = response.json()
        return [
            ServerlessPricing.from_dict(item)
            for item in _require_response_list_field(
                body,
                "pricing",
                context="admin serverless pricing list response",
            )
        ]

    def upsert(
        self,
        *,
        request: ServerlessPricingUpsertRequest | Mapping[str, Any]
        | None = None,
        pricing: ServerlessPricing | Mapping[str, Any] | None = None,
        method: str = "POST",
        timeout: float | None = None,
    ) -> ServerlessPricing | None:
        payload = _coerce_request(
            request=request,
            request_cls=ServerlessPricingUpsertRequest,
            request_name="serverless pricing upsert request",
            fields={"pricing": pricing},
        )
        normalized_method = method.upper()
        if normalized_method not in {"POST", "PUT"}:
            raise ValueError("`method` must be 'POST' or 'PUT'.")
        response = self._surface.request(
            normalized_method,
            "/v1/admin/billing/serverless-pricing",
            json_body=payload.to_dict(),
            timeout=timeout,
        )
        return ServerlessPricing.from_dict(
            _require_response_mapping_field(
                response.json(),
                "pricing",
                context="admin serverless pricing upsert response",
            ))

    def create(
        self,
        *,
        request: ServerlessPricingUpsertRequest | Mapping[str, Any]
        | None = None,
        pricing: ServerlessPricing | Mapping[str, Any] | None = None,
        timeout: float | None = None,
    ) -> ServerlessPricing | None:
        return self.upsert(
            request=request,
            pricing=pricing,
            method="POST",
            timeout=timeout,
        )

    def update(
        self,
        *,
        request: ServerlessPricingUpsertRequest | Mapping[str, Any]
        | None = None,
        pricing: ServerlessPricing | Mapping[str, Any] | None = None,
        timeout: float | None = None,
    ) -> ServerlessPricing | None:
        return self.upsert(
            request=request,
            pricing=pricing,
            method="PUT",
            timeout=timeout,
        )

    def delete(
        self,
        pricing_id: str,
        *,
        timeout: float | None = None,
    ) -> EmptyResult:
        response = self._surface.request(
            "DELETE",
            "/v1/admin/billing/serverless-pricing",
            params={"id": pricing_id},
            timeout=timeout,
        )
        return EmptyResult.from_dict(
            _require_response_mapping_field(
                response.json(),
                "empty",
                context="admin serverless pricing delete response",
            ))


class AdminBillingPricingClient:

    def __init__(self, surface: _ControlPlaneSurfaceProtocol) -> None:
        self.gpu = AdminGpuPricingClient(surface)
        self.serverless = AdminServerlessPricingClient(surface)


class AdminBillingClient:

    def __init__(self, surface: _ControlPlaneSurfaceProtocol) -> None:
        self.balances = AdminBillingBalancesClient(surface)
        self.spending = AdminBillingSpendingClient(surface)
        self.pricing = AdminBillingPricingClient(surface)


class AdminProductsClient:

    def __init__(self, surface: _ControlPlaneSurfaceProtocol) -> None:
        self._surface = surface

    def list(self, *, timeout: float | None = None) -> list[Product]:
        response = self._surface.request(
            "GET",
            "/v1/admin/products",
            timeout=timeout,
        )
        body = response.json()
        return [
            Product.from_dict(item) for item in _require_response_list_field(
                body,
                "products",
                context="admin product list response",
            )
        ]

    def upsert(
        self,
        *,
        request: ProductUpsertRequest | Mapping[str, Any] | None = None,
        product: Product | Mapping[str, Any] | None = None,
        timeout: float | None = None,
    ) -> Product | None:
        payload = _coerce_request(
            request=request,
            request_cls=ProductUpsertRequest,
            request_name="product upsert request",
            fields={"product": product},
        )
        response = self._surface.request(
            "POST",
            "/v1/admin/products",
            json_body=payload.to_dict(),
            timeout=timeout,
        )
        return Product.from_dict(
            _require_response_mapping_field(
                response.json(),
                "product",
                context="admin product upsert response",
            ))


class AdminClient:

    def __init__(self, surface: _ControlPlaneSurfaceProtocol) -> None:
        self.billing = AdminBillingClient(surface)
        self.models = AdminModelsClient(surface)
        self.products = AdminProductsClient(surface)
        self.users = AdminUsersClient(surface)
