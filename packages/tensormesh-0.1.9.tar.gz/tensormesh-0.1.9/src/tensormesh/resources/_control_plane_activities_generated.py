from __future__ import annotations

from typing import Any, Mapping

from tensormesh.resources._control_plane_shared import compact_params
from tensormesh.resources._control_plane_shared import \
    ControlPlaneOperationSpec
from tensormesh.resources._control_plane_shared import numbered_page_next
from tensormesh.resources._control_plane_shared import quote_path_value
from tensormesh.resources._control_plane_shared import \
    require_response_mapping_field
from tensormesh.types.control_plane import ActivitiesPage
from tensormesh.types.control_plane import Activity

__all__ = [
    "ACTIVITIES_GET_OPERATION",
    "ACTIVITIES_LIST_OPERATION",
    "activities_next_numbered_page",
    "build_activities_get_path",
    "build_activities_list_params",
    "parse_activities_get_response",
    "parse_activities_list_response",
]

ACTIVITIES_LIST_OPERATION = ControlPlaneOperationSpec(
    method="GET",
    path="/v1/activities",
)
ACTIVITIES_GET_OPERATION = ControlPlaneOperationSpec(
    method="GET",
    path="/v1/activities/{activity_id}",
)


def build_activities_list_params(
    *,
    user_id: str | None,
    action: str | None,
    resource_type: str | None,
    resource_id: str | None,
    start_time: str | None,
    end_time: str | None,
    page: int | None,
    size: int | None,
) -> dict[str, object]:
    return compact_params({
        "userId": user_id,
        "action": action,
        "resourceType": resource_type,
        "resourceId": resource_id,
        "startTime": start_time,
        "endTime": end_time,
        "page": page,
        "size": size,
    })


def parse_activities_list_response(body: Mapping[str, Any]) -> ActivitiesPage:
    return ActivitiesPage.from_dict(body)


def build_activities_get_path(activity_id: str) -> str:
    return f"/v1/activities/{quote_path_value(activity_id)}"


def parse_activities_get_response(body: Mapping[str, Any]) -> Activity | None:
    activity = require_response_mapping_field(
        body, "activity", context="activities get response")
    return Activity.from_dict(activity)


def activities_next_numbered_page(
    page: ActivitiesPage,
    *,
    current_page: int,
    size: int | None,
) -> tuple[bool, int]:
    """Return (has_more, next_page_number) for ActivitiesPage pagination.

    Typed wrapper over the shared numbered_page_next helper that binds the
    page/size/total fields and item count for ActivitiesPage responses.
    """
    return numbered_page_next(
        page_field=page.page,
        size_field=page.size,
        total_field=page.total,
        current_item_count=len(page.activities),
        current_page=current_page,
        size=size,
    )
