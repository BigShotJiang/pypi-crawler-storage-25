from __future__ import annotations

from typing import Any, Mapping

from tensormesh.resources._control_plane_shared import compact_params
from tensormesh.resources._control_plane_shared import \
    ControlPlaneOperationSpec
from tensormesh.resources._control_plane_shared import numbered_page_next
from tensormesh.resources._control_plane_shared import quote_path_value
from tensormesh.resources._control_plane_shared import \
    require_response_list_field
from tensormesh.resources._control_plane_shared import \
    require_response_mapping_field
from tensormesh.types.control_plane import EmptyResult
from tensormesh.types.control_plane import Model
from tensormesh.types.control_plane import ModelsPage

__all__ = [
    "ADMIN_MODELS_DELETE_OPERATION",
    "ADMIN_MODELS_LIST_OPERATION",
    "MODELS_DELETE_OPERATION",
    "MODELS_GET_OPERATION",
    "MODELS_LIST_OPERATION",
    "build_admin_models_delete_params",
    "build_admin_models_delete_path",
    "build_admin_models_list_params",
    "build_models_delete_params",
    "build_models_delete_path",
    "build_models_get_path",
    "build_models_list_params",
    "models_next_numbered_page",
    "parse_admin_models_delete_response",
    "parse_admin_models_list_response",
    "parse_models_delete_response",
    "parse_models_get_response",
    "parse_models_list_response",
]

# --------------------------------------------------------------------------
# Public models — /v1/models
# --------------------------------------------------------------------------

MODELS_LIST_OPERATION = ControlPlaneOperationSpec(
    method="GET",
    path="/v1/models",
)
MODELS_GET_OPERATION = ControlPlaneOperationSpec(
    method="GET",
    path="/v1/models/{model_id}",
)
MODELS_DELETE_OPERATION = ControlPlaneOperationSpec(
    method="DELETE",
    path="/v1/models/{model_id}",
)


def build_models_list_params(
    *,
    user_id: str | None,
) -> dict[str, object]:
    return compact_params({
        "userId": user_id,
    })


def parse_models_list_response(body: Mapping[str, Any]) -> list[Model]:
    items = require_response_list_field(body,
                                        "models",
                                        context="models list response")
    return [Model.from_dict(item) for item in items]


def build_models_get_path(model_id: str) -> str:
    return f"/v1/models/{quote_path_value(model_id)}"


def build_models_get_params(
    *,
    user_id: str | None,
) -> dict[str, object]:
    return compact_params({
        "userId": user_id,
    })


def parse_models_get_response(body: Mapping[str, Any]) -> Model | None:
    model = require_response_mapping_field(body,
                                           "model",
                                           context="models get response")
    return Model.from_dict(model)


def build_models_delete_path(model_id: str) -> str:
    return f"/v1/models/{quote_path_value(model_id)}"


def build_models_delete_params(
    *,
    user_id: str | None,
) -> dict[str, object]:
    return compact_params({
        "userId": user_id,
    })


def parse_models_delete_response(body: Mapping[str, Any]) -> EmptyResult:
    if not body:
        return EmptyResult()
    if body.get("empty") is None and "empty" in body:
        return EmptyResult()
    empty = require_response_mapping_field(body,
                                           "empty",
                                           context="models delete response")
    return EmptyResult.from_dict(empty)


# --------------------------------------------------------------------------
# Admin models — /v1/admin/models
# --------------------------------------------------------------------------

ADMIN_MODELS_LIST_OPERATION = ControlPlaneOperationSpec(
    method="GET",
    path="/v1/admin/models",
)
ADMIN_MODELS_DELETE_OPERATION = ControlPlaneOperationSpec(
    method="DELETE",
    path="/v1/admin/models/{model_id}",
)


def build_admin_models_list_params(
    *,
    user_id: str | None,
    page: int | None,
    size: int | None,
) -> dict[str, object]:
    return compact_params({
        "userId": user_id,
        "page": page,
        "size": size,
    })


def parse_admin_models_list_response(body: Mapping[str, Any]) -> ModelsPage:
    return ModelsPage.from_dict(body)


def build_admin_models_delete_path(model_id: str) -> str:
    return f"/v1/admin/models/{quote_path_value(model_id)}"


def build_admin_models_delete_params(
    *,
    user_id: str | None,
) -> dict[str, object]:
    return compact_params({
        "userId": user_id,
    })


def parse_admin_models_delete_response(body: Mapping[str, Any]) -> EmptyResult:
    if not body:
        return EmptyResult()
    if body.get("empty") is None and "empty" in body:
        return EmptyResult()
    empty = require_response_mapping_field(
        body, "empty", context="admin models delete response")
    return EmptyResult.from_dict(empty)


def models_next_numbered_page(
    page: ModelsPage,
    *,
    current_page: int,
    size: int | None,
) -> tuple[bool, int]:
    """Return (has_more, next_page_number) for ModelsPage pagination.

    Typed wrapper over the shared numbered_page_next helper that binds the
    page/size/total fields and item count for ModelsPage responses.
    """
    return numbered_page_next(
        page_field=page.page,
        size_field=page.size,
        total_field=page.total,
        current_item_count=len(page.models),
        current_page=current_page,
        size=size,
    )
