from __future__ import annotations

from dataclasses import dataclass
from dataclasses import fields as dataclass_fields
from dataclasses import is_dataclass
from dataclasses import MISSING
from typing import Any, Mapping, Protocol
from urllib.parse import quote

from tensormesh._exceptions import ProtocolError

__all__ = [
    "AsyncControlPlaneSurfaceProtocol",
    "ControlPlaneSurfaceProtocol",
    "ControlPlaneOperationSpec",
    "coerce_request",
    "compact_params",
    "numbered_page_next",
    "quote_path_value",
    "require_response_list_field",
    "require_response_mapping_field",
]


@dataclass(frozen=True)
class ControlPlaneOperationSpec:
    method: str
    path: str


class ControlPlaneSurfaceProtocol(Protocol):

    def request(
        self,
        method: str,
        path: str,
        *,
        params: Mapping[str, object] | None = None,
        json_body: Any | None = None,
        headers: Mapping[str, str] | None = None,
        timeout: float | None = None,
    ) -> Any:
        ...


class AsyncControlPlaneSurfaceProtocol(Protocol):

    async def request(
        self,
        method: str,
        path: str,
        *,
        params: Mapping[str, object] | None = None,
        json_body: Any | None = None,
        headers: Mapping[str, str] | None = None,
        timeout: float | None = None,
    ) -> Any:
        ...


def compact_params(values: Mapping[str, object | None]) -> dict[str, object]:
    return {key: value for key, value in values.items() if value is not None}


def quote_path_value(value: str) -> str:
    return quote(value, safe="")


def _require_response_object(
    payload: Any,
    *,
    context: str,
) -> Mapping[str, Any]:
    if not isinstance(payload, Mapping):
        raise ProtocolError(
            f"Malformed success response for {context}: expected JSON object.")
    return payload


def _require_response_field(
    payload: Any,
    field_name: str,
    *,
    context: str,
) -> Any:
    body = _require_response_object(payload, context=context)
    value = body.get(field_name)
    if value is None:
        raise ProtocolError(
            f"Malformed success response for {context}: missing `{field_name}`."
        )
    return value


def require_response_mapping_field(
    payload: Any,
    field_name: str,
    *,
    context: str,
) -> Mapping[str, Any]:
    value = _require_response_field(payload, field_name, context=context)
    if not isinstance(value, Mapping):
        raise ProtocolError(
            f"Malformed success response for {context}: field `{field_name}` must be an object."
        )
    return value


def require_response_list_field(
    payload: Any,
    field_name: str,
    *,
    context: str,
) -> list[Any]:
    value = _require_response_field(payload, field_name, context=context)
    if not isinstance(value, list):
        raise ProtocolError(
            f"Malformed success response for {context}: field `{field_name}` must be a list."
        )
    return value


def _coerce_optional_int(value: object | None) -> int | None:
    if value is None or isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, str):
        stripped = value.strip()
        if not stripped:
            return None
        try:
            return int(stripped)
        except ValueError:
            return None
    return None


def _has_more_numbered_pages(
    *,
    page_number: int | None,
    page_size: int | None,
    total_items: int | None,
    current_item_count: int,
) -> bool:
    if current_item_count <= 0:
        return False
    if total_items is not None and page_number is not None and page_size is not None:
        return page_number * page_size < total_items
    if page_size is not None:
        return current_item_count >= page_size
    return False


def numbered_page_next(
    *,
    page_field: object | None,
    size_field: object | None,
    total_field: object | None,
    current_item_count: int,
    current_page: int,
    size: int | None,
) -> tuple[bool, int]:
    """Return (has_more, next_page_number) from a numbered-page response.

    Coerces the raw page/size/total fields from a response body, then delegates
    to has_more_numbered_pages.  Resource-specific helpers (e.g.
    activities_next_numbered_page) wrap this to bind the typed page fields.
    """
    page_number = _coerce_optional_int(page_field) or current_page
    page_size = _coerce_optional_int(size_field) or size
    total_items = _coerce_optional_int(total_field)
    if not _has_more_numbered_pages(
            page_number=page_number,
            page_size=page_size,
            total_items=total_items,
            current_item_count=current_item_count,
    ):
        return False, page_number
    return True, page_number + 1


def _required_request_field_names(request_cls: type[Any]) -> list[str]:
    if not is_dataclass(request_cls):
        return []
    return [
        field.name for field in dataclass_fields(request_cls) if field.init
        and field.default is MISSING and field.default_factory is MISSING
    ]


def _missing_required_request_error(
    request_name: str,
    field_names: list[str],
) -> ValueError:
    joined = ", ".join(f"`{field_name}`" for field_name in field_names)
    return ValueError(f"Missing required fields for {request_name}: {joined}.")


def coerce_request(
    *,
    request: Any | None,
    request_cls: type[Any],
    request_name: str,
    fields: Mapping[str, Any],
) -> Any:
    supplied_fields = {
        key: value
        for key, value in fields.items() if value is not None
    }
    if request is not None and supplied_fields:
        raise ValueError(
            f"Pass either `request=` or individual {request_name} "
            "fields, not both.")
    if request is None:
        missing_required_fields = [
            field_name
            for field_name in _required_request_field_names(request_cls)
            if supplied_fields.get(field_name) is None
        ]
        if missing_required_fields:
            raise _missing_required_request_error(request_name,
                                                  missing_required_fields)
        return request_cls(**supplied_fields)
    if isinstance(request, request_cls):
        return request
    if isinstance(request, Mapping):
        try:
            return request_cls.from_dict(request)
        except KeyError as exc:
            raise _missing_required_request_error(request_name,
                                                  [str(exc.args[0])]) from exc
    raise TypeError(
        f"`request` must be a `{request_cls.__name__}` or mapping.")
