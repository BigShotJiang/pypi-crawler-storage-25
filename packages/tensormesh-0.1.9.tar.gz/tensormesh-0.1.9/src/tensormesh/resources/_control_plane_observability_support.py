from __future__ import annotations

from typing import Any, Iterator, Mapping

from tensormesh.resources._control_plane_shared import \
    coerce_request as _coerce_request
from tensormesh.resources._control_plane_shared import \
    compact_params as _compact_params
from tensormesh.resources._control_plane_shared import \
    ControlPlaneSurfaceProtocol as _ControlPlaneSurfaceProtocol
from tensormesh.resources._control_plane_shared import \
    numbered_page_next as _numbered_page_next
from tensormesh.resources._control_plane_shared import \
    quote_path_value as _quote_path_value
from tensormesh.resources._control_plane_shared import \
    require_response_list_field as _require_response_list_field
from tensormesh.resources._control_plane_shared import \
    require_response_mapping_field as _require_response_mapping_field
from tensormesh.types.control_plane import AppendTicketMessageRequest
from tensormesh.types.control_plane import ConversationMessage
from tensormesh.types.control_plane import CreateTicketRequest
from tensormesh.types.control_plane import LogEntry
from tensormesh.types.control_plane import Metric
from tensormesh.types.control_plane import ReservedDeploymentSubmission
from tensormesh.types.control_plane import SubmitReservedDeploymentRequest
from tensormesh.types.control_plane import Ticket
from tensormesh.types.control_plane import TicketsPage


class DeploymentLogsClient:

    def __init__(self, surface: _ControlPlaneSurfaceProtocol) -> None:
        self._surface = surface

    def list(
        self,
        deployment_id: str,
        *,
        user_id: str | None = None,
        start_time: str | None = None,
        end_time: str | None = None,
        limit: int | None = None,
        direction: str | None = None,
        timeout: float | None = None,
    ) -> list[LogEntry]:
        response = self._surface.request(
            "GET",
            f"/v1/observability/deployments/{_quote_path_value(deployment_id)}/logs",
            params=_compact_params({
                "userId": user_id,
                "startTime": start_time,
                "endTime": end_time,
                "limit": limit,
                "direction": direction,
            }),
            timeout=timeout,
        )
        body = response.json()
        return [
            LogEntry.from_dict(item) for item in _require_response_list_field(
                body,
                "logs",
                context="deployment logs response",
            )
        ]


class DeploymentMetricsClient:

    def __init__(self, surface: _ControlPlaneSurfaceProtocol) -> None:
        self._surface = surface

    def get(
        self,
        deployment_id: str,
        *,
        user_id: str | None = None,
        start_time: str | None = None,
        end_time: str | None = None,
        step_seconds: float | None = None,
        timeout: float | None = None,
    ) -> list[Metric]:
        response = self._surface.request(
            "GET",
            f"/v1/observability/deployments/{_quote_path_value(deployment_id)}/metrics",
            params=_compact_params({
                "userId": user_id,
                "startTime": start_time,
                "endTime": end_time,
                "stepSeconds": step_seconds,
            }),
            timeout=timeout,
        )
        body = response.json()
        return [
            Metric.from_dict(item) for item in _require_response_list_field(
                body,
                "metrics",
                context="deployment metrics response",
            )
        ]


class ObservabilityDeploymentsClient:

    def __init__(self, surface: _ControlPlaneSurfaceProtocol) -> None:
        self.logs = DeploymentLogsClient(surface)
        self.metrics = DeploymentMetricsClient(surface)


class UserMetricsClient:

    def __init__(self, surface: _ControlPlaneSurfaceProtocol) -> None:
        self._surface = surface

    def get(
        self,
        *,
        user_id: str | None = None,
        start_time: str | None = None,
        end_time: str | None = None,
        step_seconds: float | None = None,
        timeout: float | None = None,
    ) -> list[Metric]:
        response = self._surface.request(
            "GET",
            "/v1/observability/users/metrics",
            params=_compact_params({
                "userId": user_id,
                "startTime": start_time,
                "endTime": end_time,
                "stepSeconds": step_seconds,
            }),
            timeout=timeout,
        )
        body = response.json()
        return [
            Metric.from_dict(item) for item in _require_response_list_field(
                body,
                "metrics",
                context="user metrics response",
            )
        ]


class ObservabilityUsersClient:

    def __init__(self, surface: _ControlPlaneSurfaceProtocol) -> None:
        self.metrics = UserMetricsClient(surface)


class ObservabilityClient:

    def __init__(self, surface: _ControlPlaneSurfaceProtocol) -> None:
        self.deployments = ObservabilityDeploymentsClient(surface)
        self.users = ObservabilityUsersClient(surface)


class TicketsClient:

    def __init__(self, surface: _ControlPlaneSurfaceProtocol) -> None:
        self._surface = surface

    def list(
        self,
        *,
        user_id: str | None = None,
        status: str | None = None,
        page: int | None = None,
        size: int | None = None,
        timeout: float | None = None,
    ) -> TicketsPage:
        response = self._surface.request(
            "GET",
            "/v1/support/tickets",
            params=_compact_params({
                "userId": user_id,
                "status": status,
                "page": page,
                "size": size,
            }),
            timeout=timeout,
        )
        return TicketsPage.from_dict(response.json())

    def auto_paging_iter(
        self,
        *,
        user_id: str | None = None,
        status: str | None = None,
        page: int | None = None,
        size: int | None = None,
        timeout: float | None = None,
    ) -> Iterator[Ticket]:
        current_page = 1 if page is None else page
        while True:
            current = self.list(
                user_id=user_id,
                status=status,
                page=current_page,
                size=size,
                timeout=timeout,
            )
            for ticket in current.tickets:
                yield ticket

            has_more, next_page = _numbered_page_next(
                page_field=current.page,
                size_field=current.size,
                total_field=current.total,
                current_item_count=len(current.tickets),
                current_page=current_page,
                size=size,
            )
            if not has_more:
                return
            current_page = next_page

    def create(
        self,
        *,
        request: CreateTicketRequest | Mapping[str, Any] | None = None,
        subject: str | None = None,
        message: str | None = None,
        user_id: str | None = None,
        ticket_type: str | None = None,
        timeout: float | None = None,
    ) -> Ticket | None:
        payload = _coerce_request(
            request=request,
            request_cls=CreateTicketRequest,
            request_name="ticket create request",
            fields={
                "subject": subject,
                "message": message,
                "user_id": user_id,
                "ticket_type": ticket_type,
            },
        )
        response = self._surface.request(
            "POST",
            "/v1/support/tickets",
            json_body=payload.to_dict(),
            timeout=timeout,
        )
        return Ticket.from_dict(
            _require_response_mapping_field(
                response.json(),
                "ticket",
                context="ticket create response",
            ))

    def get(
        self,
        ticket_id: str,
        *,
        timeout: float | None = None,
    ) -> Ticket | None:
        response = self._surface.request(
            "GET",
            f"/v1/support/tickets/{_quote_path_value(ticket_id)}",
            timeout=timeout,
        )
        return Ticket.from_dict(
            _require_response_mapping_field(
                response.json(),
                "ticket",
                context="ticket lookup response",
            ))

    def close(
        self,
        ticket_id: str,
        *,
        user_id: str | None = None,
        timeout: float | None = None,
    ) -> Ticket | None:
        response = self._surface.request(
            "DELETE",
            f"/v1/support/tickets/{_quote_path_value(ticket_id)}",
            params=_compact_params({"userId": user_id}),
            timeout=timeout,
        )
        return Ticket.from_dict(
            _require_response_mapping_field(
                response.json(),
                "ticket",
                context="ticket close response",
            ))

    def add_message(
        self,
        ticket_id: str,
        *,
        request: AppendTicketMessageRequest | Mapping[str, Any] | None = None,
        message: str | ConversationMessage | Mapping[str, Any] | None = None,
        user_id: str | None = None,
        timeout: float | None = None,
    ) -> Ticket | None:
        if isinstance(request, Mapping):
            if message is not None or user_id is not None:
                raise ValueError(
                    "Pass either `request=` or individual ticket message request fields, not both."
                )
            payload = dict(request)
        else:
            payload = _coerce_request(
                request=request,
                request_cls=AppendTicketMessageRequest,
                request_name="ticket message request",
                fields={
                    "message": message,
                    "user_id": user_id,
                },
            )
        response = self._surface.request(
            "POST",
            f"/v1/support/tickets/{_quote_path_value(ticket_id)}/messages",
            json_body=(payload.to_dict() if isinstance(
                payload, AppendTicketMessageRequest) else payload),
            timeout=timeout,
        )
        return Ticket.from_dict(
            _require_response_mapping_field(
                response.json(),
                "ticket",
                context="ticket message response",
            ))


class ReservedDeploymentsClient:

    def __init__(self, surface: _ControlPlaneSurfaceProtocol) -> None:
        self._surface = surface

    def submit(
        self,
        *,
        request: SubmitReservedDeploymentRequest | Mapping[str, Any]
        | None = None,
        full_name: str | None = None,
        work_email: str | None = None,
        company: str | None = None,
        job_title: str | None = None,
        preferred_gpu: str | None = None,
        total_gpus_needed: str | None = None,
        deployment_timeline: str | None = None,
        workload_use_case: str | None = None,
        networking_storage: str | None = None,
        other_notes: str | None = None,
        timeout: float | None = None,
    ) -> ReservedDeploymentSubmission:
        payload = _coerce_request(
            request=request,
            request_cls=SubmitReservedDeploymentRequest,
            request_name="reserved deployment request",
            fields={
                "full_name": full_name,
                "work_email": work_email,
                "company": company,
                "job_title": job_title,
                "preferred_gpu": preferred_gpu,
                "total_gpus_needed": total_gpus_needed,
                "deployment_timeline": deployment_timeline,
                "workload_use_case": workload_use_case,
                "networking_storage": networking_storage,
                "other_notes": other_notes,
            },
        )
        response = self._surface.request(
            "POST",
            "/v1/support/reserved-deployments",
            json_body=payload.to_dict(),
            timeout=timeout,
        )
        return ReservedDeploymentSubmission.from_dict(response.json())


class SupportClient:

    def __init__(self, surface: _ControlPlaneSurfaceProtocol) -> None:
        self.tickets = TicketsClient(surface)
        self.reserved_deployments = ReservedDeploymentsClient(surface)
