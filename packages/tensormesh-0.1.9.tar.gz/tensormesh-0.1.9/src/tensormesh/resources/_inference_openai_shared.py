from __future__ import annotations

from typing import Any, Mapping

from tensormesh.types.inference import ChatMessage
from tensormesh.types.inference import DetokenizeRequest
from tensormesh.types.inference import ResponseCreateRequest
from tensormesh.types.inference import TextCompletionRequest
from tensormesh.types.inference import TokenizeRequest

__all__ = [
    "build_detokenize_request",
    "build_response_create_request",
    "build_text_completion_request",
    "build_tokenize_request",
    "normalize_response_wrapper_request",
    "normalize_text_completion_wrapper_request",
]


def _normalize_wrapper_request(
    *,
    request: Any,
    stream: bool,
    stream_true_error: str,
    stream_false_error: str,
) -> Any:
    if request is None:
        return None

    if hasattr(request, "to_dict"):
        payload = request.to_dict()
    else:
        payload = dict(request)

    current_stream = payload.get("stream")
    if stream:
        if current_stream is False:
            raise ValueError(stream_false_error)
        payload["stream"] = True
    else:
        if current_stream is True:
            raise ValueError(stream_true_error)
        payload.pop("stream", None)

    return payload


def normalize_text_completion_wrapper_request(
    request: TextCompletionRequest | Mapping[str, Any] | None,
    *,
    stream: bool,
) -> TextCompletionRequest | Mapping[str, Any] | None:
    return _normalize_wrapper_request(
        request=request,
        stream=stream,
        stream_true_error=(
            "`with_raw_response.create` does not support `stream=True`. "
            "Use `with_streaming_response.create(...)` for SSE responses."),
        stream_false_error=(
            "`with_streaming_response.create` requires streaming. "
            "Omit `stream` or pass `True`."),
    )


def normalize_response_wrapper_request(
    request: ResponseCreateRequest | Mapping[str, Any] | None,
    *,
    stream: bool,
) -> ResponseCreateRequest | Mapping[str, Any] | None:
    return _normalize_wrapper_request(
        request=request,
        stream=stream,
        stream_true_error=(
            "`with_raw_response.create` does not support `stream=True`. "
            "Use `with_streaming_response.create(...)` for SSE responses."),
        stream_false_error=(
            "`with_streaming_response.create` requires streaming. "
            "Omit `stream` or pass `True`."),
    )


def build_text_completion_request(
    *,
    request: TextCompletionRequest | Mapping[str, Any] | None,
    model: str | None,
    prompt: str | list[str] | None,
    max_tokens: int | None,
    stream: bool | None,
    temperature: float | None,
    extra_body: Mapping[str, Any] | None,
) -> TextCompletionRequest:
    if request is not None:
        if any(value is not None
               for value in (model, prompt, max_tokens, stream, temperature,
                             extra_body)):
            raise ValueError(
                "Pass either `request=` or individual completion fields, not both."
            )
        if isinstance(request, TextCompletionRequest):
            return request
        return TextCompletionRequest.from_dict(dict(request))

    if model is None or prompt is None:
        raise ValueError(
            "Missing required fields. `model` and `prompt` are required.")

    return TextCompletionRequest(
        model=model,
        prompt=prompt,
        max_tokens=max_tokens,
        stream=stream,
        temperature=temperature,
        extra=dict(extra_body or {}),
    )


def build_response_create_request(
    *,
    request: ResponseCreateRequest | Mapping[str, Any] | None,
    model: str | None,
    input: str | list[dict[str, Any]] | None,
    max_output_tokens: int | None,
    stream: bool | None,
    extra_body: Mapping[str, Any] | None,
) -> ResponseCreateRequest:
    if request is not None:
        if any(value is not None for value in (model, input, max_output_tokens,
                                               stream, extra_body)):
            raise ValueError(
                "Pass either `request=` or individual response fields, not both."
            )
        if isinstance(request, ResponseCreateRequest):
            return request
        return ResponseCreateRequest.from_dict(dict(request))

    if model is None or input is None:
        raise ValueError(
            "Missing required fields. `model` and `input` are required.")

    return ResponseCreateRequest(
        model=model,
        input=input,
        max_output_tokens=max_output_tokens,
        stream=stream,
        extra=dict(extra_body or {}),
    )


def build_tokenize_request(
    *,
    request: TokenizeRequest | Mapping[str, Any] | None,
    model: str | None,
    prompt: str | list[str] | None,
    messages: list[ChatMessage | dict[str, Any]] | None,
    extra_body: Mapping[str, Any] | None,
) -> TokenizeRequest:
    if request is not None:
        if any(value is not None
               for value in (model, prompt, messages, extra_body)):
            raise ValueError(
                "Pass either `request=` or individual tokenize fields, not both."
            )
        if isinstance(request, TokenizeRequest):
            return request
        return TokenizeRequest.from_dict(dict(request))

    if model is None or (prompt is None and messages is None):
        raise ValueError(
            "Missing required fields. `model` and one of `prompt` or `messages` are required."
        )

    return TokenizeRequest(
        model=model,
        prompt=prompt,
        messages=messages,
        extra=dict(extra_body or {}),
    )


def build_detokenize_request(
    *,
    request: DetokenizeRequest | Mapping[str, Any] | None,
    model: str | None,
    tokens: list[int] | None,
    extra_body: Mapping[str, Any] | None,
) -> DetokenizeRequest:
    if request is not None:
        if any(value is not None for value in (model, tokens, extra_body)):
            raise ValueError(
                "Pass either `request=` or individual detokenize fields, not both."
            )
        if isinstance(request, DetokenizeRequest):
            return request
        return DetokenizeRequest.from_dict(dict(request))

    if model is None or tokens is None:
        raise ValueError(
            "Missing required fields. `model` and `tokens` are required.")

    return DetokenizeRequest(
        model=model,
        tokens=[int(item) for item in tokens],
        extra=dict(extra_body or {}),
    )
