from __future__ import annotations

import json
from typing import AsyncIterator, Iterator

import requests

from ._exceptions import StreamError
from ._reasoning import LeadingReasoningTextFilter
from .types.inference import ChatCompletionChunk

__all__ = ["AsyncChatCompletionStream", "ChatCompletionStream"]


def _decode_stream_event(data: str) -> ChatCompletionChunk:
    try:
        event = json.loads(data)
    except json.JSONDecodeError as exc:
        raise StreamError(f"Invalid stream event JSON: {data}") from exc

    if isinstance(event, dict) and "error" in event:
        raise StreamError(f"Stream error: {event.get('error')}")

    if not isinstance(event, dict):
        raise StreamError("Invalid stream event payload.")

    return ChatCompletionChunk.from_dict(event)


def _normalize_sse_line(line: object) -> str:
    if isinstance(line, bytes):
        return line.decode("utf-8")
    return str(line)


def _sse_data_value(line: str) -> str | None:
    if not line.startswith("data:"):
        return None
    data = line[len("data:"):]
    if data.startswith(" "):
        data = data[1:]
    return data


def _starts_new_sse_event(data: str) -> bool:
    stripped = data.lstrip()
    return stripped == "[DONE]" or stripped.startswith("{")


class _SSEEventAccumulator:

    def __init__(self) -> None:
        self._event_lines: list[str] = []

    def feed_line(self, raw_line: object) -> list[str]:
        line = _normalize_sse_line(raw_line)
        if not line:
            return self._flush()
        if line.startswith(":"):
            return []
        data = _sse_data_value(line)
        if data is None:
            return []
        events: list[str] = []
        if self._event_lines and _starts_new_sse_event(data):
            events.extend(self._flush())
        self._event_lines.append(data)
        return events

    def finalize(self) -> list[str]:
        return self._flush()

    def _flush(self) -> list[str]:
        if not self._event_lines:
            return []
        event = "\n".join(self._event_lines)
        self._event_lines = []
        return [event]


class ChatCompletionStream(Iterator[ChatCompletionChunk]):
    """Iterates over SSE chat completion chunks."""

    def __init__(self, response: requests.Response) -> None:
        self._response = response
        self._iterator = iter(response.iter_lines(decode_unicode=True))
        self._event_iterator = self._iter_events()
        self._closed = False

    def __iter__(self) -> ChatCompletionStream:
        return self

    def _iter_events(self) -> Iterator[str]:
        accumulator = _SSEEventAccumulator()
        for raw_line in self._iterator:
            yield from accumulator.feed_line(raw_line)
        yield from accumulator.finalize()

    def __next__(self) -> ChatCompletionChunk:
        for data in self._event_iterator:
            if data == "[DONE]":
                self.close()
                raise StopIteration

            try:
                return _decode_stream_event(data)
            except StreamError:
                self.close()
                raise

        self.close()
        raise StopIteration

    def text_deltas(self) -> Iterator[str]:
        filters: dict[int, LeadingReasoningTextFilter] = {}
        for chunk in self:
            for choice in chunk.choices:
                filter_state = filters.setdefault(
                    choice.index,
                    LeadingReasoningTextFilter(),
                )
                visible = filter_state.feed(choice.delta.content)
                if visible:
                    yield visible

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        close = getattr(self._response, "close", None)
        if callable(close):
            close()

    def __enter__(self) -> ChatCompletionStream:
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: object | None,
    ) -> None:
        self.close()


class AsyncChatCompletionStream(AsyncIterator[ChatCompletionChunk]):
    """Asynchronously iterates over SSE chat completion chunks."""

    def __init__(self, response: object) -> None:
        self._response = response
        self._iterator = response.iter_lines()
        self._event_iterator = self._iter_events()
        self._closed = False

    def __aiter__(self) -> AsyncChatCompletionStream:
        return self

    async def _iter_events(self) -> AsyncIterator[str]:
        accumulator = _SSEEventAccumulator()
        async for raw_line in self._iterator:
            for event in accumulator.feed_line(raw_line):
                yield event
        for event in accumulator.finalize():
            yield event

    async def __anext__(self) -> ChatCompletionChunk:
        async for data in self._event_iterator:
            if data == "[DONE]":
                await self.close()
                raise StopAsyncIteration

            try:
                return _decode_stream_event(data)
            except StreamError:
                await self.close()
                raise

        await self.close()
        raise StopAsyncIteration

    async def text_deltas(self) -> AsyncIterator[str]:
        filters: dict[int, LeadingReasoningTextFilter] = {}
        async for chunk in self:
            for choice in chunk.choices:
                filter_state = filters.setdefault(
                    choice.index,
                    LeadingReasoningTextFilter(),
                )
                visible = filter_state.feed(choice.delta.content)
                if visible:
                    yield visible

    async def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        close = getattr(self._response, "close", None)
        if callable(close):
            maybe = close()
            if hasattr(maybe, "__await__"):
                await maybe

    async def __aenter__(self) -> AsyncChatCompletionStream:
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: object | None,
    ) -> None:
        await self.close()
