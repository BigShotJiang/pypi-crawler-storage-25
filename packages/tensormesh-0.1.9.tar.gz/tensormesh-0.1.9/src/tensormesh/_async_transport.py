from __future__ import annotations

import asyncio
from dataclasses import dataclass
import json
import ssl
from typing import Any, AsyncIterator, Awaitable, Callable, Mapping

import aiohttp

from ._constants import DEFAULT_STREAM_READ_TIMEOUT_SECONDS
from ._exceptions import APIConnectionError
from ._exceptions import APITimeoutError
from ._exceptions import make_status_error
from ._transport import _exponential_backoff_s
from ._transport import _format_status_error_message
from ._transport import _response_retry_delay_s
from ._transport import is_idempotent_method
from ._transport import resolve_timeout_s

__all__ = [
    "AsyncBufferedResponse",
    "AsyncStreamResponse",
    "AsyncTransport",
]


@dataclass(frozen=True)
class AsyncBufferedResponse:
    status_code: int
    headers: dict[str, str]
    text: str

    def json(self) -> Any:
        return json.loads(self.text)


class AsyncStreamResponse:

    def __init__(self, response: aiohttp.ClientResponse) -> None:
        self._response = response
        self.status_code = int(response.status)
        self.headers = dict(response.headers)
        self._closed = False

    async def iter_lines(self) -> AsyncIterator[str]:
        while True:
            raw_line = await self._response.content.readline()
            if not raw_line:
                break
            yield raw_line.decode("utf-8", errors="replace").rstrip("\r\n")

    async def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        self._response.close()


class AsyncTransport:

    def __init__(
        self,
        *,
        verify: bool | str = True,
        timeout_seconds: float = 30.0,
        max_retries: int = 0,
        session: aiohttp.ClientSession | None = None,
    ) -> None:
        self._verify = verify
        self._timeout_seconds = resolve_timeout_s(
            timeout_s=timeout_seconds,
            default_timeout_s=timeout_seconds,
        )
        self._max_retries = int(max_retries)
        if self._max_retries < 0:
            raise ValueError("Max retries must be greater than or equal to 0.")
        self._session = session
        self._owns_session = session is None
        self._ssl = self._build_ssl_context(verify)

    async def close(self) -> None:
        if self._owns_session and self._session is not None:
            await self._session.close()
            self._session = None

    async def _ensure_session(self) -> aiohttp.ClientSession:
        if self._session is None:
            self._session = aiohttp.ClientSession()
        return self._session

    @staticmethod
    def _build_ssl_context(verify: bool | str) -> ssl.SSLContext | bool | None:
        if verify is True:
            return None
        if verify is False:
            return False
        context = ssl.create_default_context(cafile=str(verify))
        return context

    async def _request_once(
        self,
        method: str,
        url: str,
        *,
        headers: Mapping[str, str] | None = None,
        params: Mapping[str, object] | None = None,
        json_body: Any | None = None,
        timeout_s: float,
        read_timeout_s: float | None = None,
        stream: bool = False,
    ) -> aiohttp.ClientResponse:
        session = await self._ensure_session()
        if stream:
            timeout = aiohttp.ClientTimeout(
                total=None,
                connect=timeout_s,
                sock_connect=timeout_s,
                sock_read=read_timeout_s
                or DEFAULT_STREAM_READ_TIMEOUT_SECONDS,
            )
        else:
            timeout = aiohttp.ClientTimeout(total=timeout_s)
        return await session.request(
            method.upper().strip(),
            url,
            headers=dict(headers or {}),
            params=dict(params or {}),
            json=json_body,
            timeout=timeout,
            ssl=self._ssl,
        )

    async def _close_raw_response(self, response: Any) -> None:
        release = getattr(response, "release", None)
        if callable(release):
            maybe = release()
            if asyncio.iscoroutine(maybe):
                await maybe
        close = getattr(response, "close", None)
        if callable(close):
            maybe = close()
            if asyncio.iscoroutine(maybe):
                await maybe

    @staticmethod
    def _response_status_code(raw_response: Any) -> int:
        if hasattr(raw_response, "status"):
            return int(raw_response.status)
        if hasattr(raw_response, "status_code"):
            return int(raw_response.status_code)
        raise AttributeError("Response object is missing a status attribute.")

    async def request(
        self,
        method: str,
        url: str,
        *,
        headers: Mapping[str, str] | None = None,
        params: Mapping[str, object] | None = None,
        json_body: Any | None = None,
        timeout_s: float | None = None,
        idempotent: bool | None = None,
        status_hints: Mapping[int, str] | None = None,
        error_context: Mapping[str, str] | None = None,
        request_fn: Callable[..., Awaitable[Any]] | None = None,
    ) -> AsyncBufferedResponse:
        request_callable = request_fn or self._request_once
        effective_timeout_s = resolve_timeout_s(
            timeout_s=timeout_s,
            configured_timeout_s=self._timeout_seconds,
            default_timeout_s=self._timeout_seconds,
        )
        use_idempotent = (is_idempotent_method(method)
                          if idempotent is None else bool(idempotent))
        attempts = 1 + (self._max_retries if use_idempotent else 0)

        last_exc: Exception | None = None
        next_delay_s: float | None = None
        for attempt in range(attempts):
            if attempt > 0:
                await asyncio.sleep(next_delay_s if next_delay_s is not None
                                    else _exponential_backoff_s(attempt))
                next_delay_s = None
            try:
                raw_response = await request_callable(
                    method,
                    url,
                    headers=headers,
                    params=params,
                    json_body=json_body,
                    timeout_s=effective_timeout_s,
                    read_timeout_s=None,
                    stream=False,
                )
            except asyncio.TimeoutError as exc:
                last_exc = exc
                if use_idempotent and attempt < attempts - 1:
                    next_delay_s = _exponential_backoff_s(attempt + 1)
                    continue
                raise APITimeoutError(f"Request timed out: {exc}") from exc
            except aiohttp.ClientError as exc:
                last_exc = exc
                if use_idempotent and attempt < attempts - 1:
                    next_delay_s = _exponential_backoff_s(attempt + 1)
                    continue
                raise APIConnectionError(
                    f"Request failed (network error): {exc}") from exc

            status_code = self._response_status_code(raw_response)
            if (use_idempotent and status_code in (429, 500, 502, 503, 504)
                    and attempt < attempts - 1):
                next_delay_s = _response_retry_delay_s(raw_response,
                                                       attempt + 1)
                await self._close_raw_response(raw_response)
                continue

            body_text = await raw_response.text()
            await self._close_raw_response(raw_response)
            buffered = AsyncBufferedResponse(
                status_code=status_code,
                headers=dict(getattr(raw_response, "headers", {})),
                text=body_text,
            )
            if buffered.status_code >= 400:
                message, body = _format_status_error_message(
                    buffered,
                    status_hints=status_hints,
                    error_context=error_context,
                )
                raise make_status_error(response=buffered,
                                        message=message,
                                        body=body)
            return buffered

        assert last_exc is not None
        if isinstance(last_exc, asyncio.TimeoutError):
            raise APITimeoutError(
                f"Request timed out: {last_exc}") from last_exc
        raise APIConnectionError(
            f"Request failed (network error): {last_exc}") from last_exc

    async def request_stream(
        self,
        method: str,
        url: str,
        *,
        headers: Mapping[str, str] | None = None,
        params: Mapping[str, object] | None = None,
        json_body: Any | None = None,
        timeout_s: float | None = None,
        read_timeout_s: float | None = None,
        status_hints: Mapping[int, str] | None = None,
        error_context: Mapping[str, str] | None = None,
        request_fn: Callable[..., Awaitable[Any]] | None = None,
    ) -> AsyncStreamResponse:
        request_callable = request_fn or self._request_once
        effective_timeout_s = resolve_timeout_s(
            timeout_s=timeout_s,
            configured_timeout_s=self._timeout_seconds,
            default_timeout_s=self._timeout_seconds,
        )
        effective_read_timeout_s = resolve_timeout_s(
            timeout_s=read_timeout_s,
            configured_timeout_s=DEFAULT_STREAM_READ_TIMEOUT_SECONDS,
            default_timeout_s=DEFAULT_STREAM_READ_TIMEOUT_SECONDS,
        )

        try:
            raw_response = await request_callable(
                method,
                url,
                headers=headers,
                params=params,
                json_body=json_body,
                timeout_s=effective_timeout_s,
                read_timeout_s=effective_read_timeout_s,
                stream=True,
            )
        except asyncio.TimeoutError as exc:
            raise APITimeoutError(f"Request timed out: {exc}") from exc
        except aiohttp.ClientError as exc:
            raise APIConnectionError(
                f"Request failed (network error): {exc}") from exc

        status_code = self._response_status_code(raw_response)
        if status_code >= 400:
            body_text = await raw_response.text()
            await self._close_raw_response(raw_response)
            buffered = AsyncBufferedResponse(
                status_code=status_code,
                headers=dict(getattr(raw_response, "headers", {})),
                text=body_text,
            )
            message, body = _format_status_error_message(
                buffered,
                status_hints=status_hints,
                error_context=error_context,
            )
            raise make_status_error(response=buffered,
                                    message=message,
                                    body=body)
        return AsyncStreamResponse(raw_response)
