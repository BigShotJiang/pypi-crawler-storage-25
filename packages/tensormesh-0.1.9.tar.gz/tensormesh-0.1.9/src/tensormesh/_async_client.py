from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Literal, Mapping

from ._async_transport import AsyncTransport
from ._auth import ClientConfig
from ._auth import normalize_on_demand_user_id
from ._auth import resolve_client_config
from ._client_shared import default_json_headers
from ._client_shared import find_header_key_case_insensitive
from ._client_shared import require_control_plane_token
from ._client_shared import require_inference_api_key
from ._client_shared import require_on_demand_base_url
from ._client_shared import resolve_on_demand_user_id
from ._client_shared import setdefault_header_case_insensitive
from ._client_shared import setdefault_header_case_insensitive_lazy
from ._constants import DEFAULT_SERVERLESS_BASE_URL
from ._constants import DEFAULT_STREAM_READ_TIMEOUT_SECONDS
from ._exceptions import ConfigurationError
from ._transport import build_url
from .resources.control_plane_async import AsyncActivitiesClient
from .resources.control_plane_async import AsyncAdminClient
from .resources.control_plane_async import AsyncBillingClient
from .resources.control_plane_async import \
    AsyncModelsClient as ControlPlaneModelsClient
from .resources.control_plane_async import AsyncObservabilityClient
from .resources.control_plane_async import AsyncProductsClient
from .resources.control_plane_async import AsyncSupportClient
from .resources.control_plane_async import AsyncUsersClient
from .resources.inference_async import AsyncChatNamespace
from .resources.inference_async import AsyncDetokenizeClient
from .resources.inference_async import AsyncHealthClient
from .resources.inference_async import \
    AsyncModelsClient as InferenceModelsClient
from .resources.inference_async import AsyncResponsesClient
from .resources.inference_async import AsyncTextCompletionsClient
from .resources.inference_async import AsyncTokenizeClient
from .resources.inference_async import AsyncVersionClient

__all__ = ["AsyncTensormesh"]


class AsyncTensormesh:
    """Asynchronous Tensormesh client."""

    def __init__(
        self,
        *,
        control_plane_token: str | None = None,
        control_plane_base_url: str | None = None,
        inference_api_key: str | None = None,
        serverless_base_url: str | None = None,
        on_demand_base_url: str | None = None,
        on_demand_user_id: str | None = None,
        timeout: float | None = None,
        max_retries: int | None = None,
        ca_bundle: str | None = None,
        env: Mapping[str, str] | None = None,
        _transport: AsyncTransport | None = None,
    ) -> None:
        self._config = resolve_client_config(
            control_plane_token=control_plane_token,
            control_plane_base_url=control_plane_base_url,
            inference_api_key=inference_api_key,
            serverless_base_url=serverless_base_url,
            on_demand_base_url=on_demand_base_url,
            on_demand_user_id=on_demand_user_id,
            timeout=timeout,
            max_retries=max_retries,
            ca_bundle=ca_bundle,
            env=env,
        )
        self._transport = _transport or AsyncTransport(
            verify=self._config.verify,
            timeout_seconds=self._config.timeout_seconds,
            max_retries=self._config.max_retries,
        )
        self.control_plane = AsyncControlPlaneClient(self)
        self.inference = AsyncInferenceClient(self)

    @property
    def config(self) -> ClientConfig:
        return self._config

    async def close(self) -> None:
        await self._transport.close()

    async def __aenter__(self) -> AsyncTensormesh:
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: object | None,
    ) -> None:
        await self.close()

    async def _request(
        self,
        *,
        method: str,
        url: str,
        headers: Mapping[str, str] | None = None,
        params: Mapping[str, object] | None = None,
        json_body: Any | None = None,
        timeout: float | None = None,
        idempotent: bool | None = None,
        status_hints: Mapping[int, str] | None = None,
        error_context: Mapping[str, str] | None = None,
    ) -> Any:
        return await self._transport.request(
            method,
            url,
            headers=headers,
            params=params,
            json_body=json_body,
            timeout_s=timeout,
            idempotent=idempotent,
            status_hints=status_hints,
            error_context=error_context,
        )

    async def _stream_request(
        self,
        *,
        method: str,
        url: str,
        headers: Mapping[str, str] | None = None,
        params: Mapping[str, object] | None = None,
        json_body: Any | None = None,
        timeout: float | None = None,
        read_timeout: float | None = None,
        status_hints: Mapping[int, str] | None = None,
        error_context: Mapping[str, str] | None = None,
    ) -> Any:
        return await self._transport.request_stream(
            method,
            url,
            headers=headers,
            params=params,
            json_body=json_body,
            timeout_s=timeout,
            read_timeout_s=read_timeout,
            status_hints=status_hints,
            error_context=error_context,
        )


class AsyncControlPlaneClient:

    def __init__(self, client: AsyncTensormesh) -> None:
        self._client = client
        self.activities = AsyncActivitiesClient(self)
        self.admin = AsyncAdminClient(self)
        self.billing = AsyncBillingClient(self)
        self.models = ControlPlaneModelsClient(self)
        self.observability = AsyncObservabilityClient(self)
        self.products = AsyncProductsClient(self)
        self.support = AsyncSupportClient(self)
        self.users = AsyncUsersClient(self)

    async def request(
        self,
        method: str,
        path: str,
        *,
        params: Mapping[str, object] | None = None,
        json_body: Any | None = None,
        headers: Mapping[str, str] | None = None,
        timeout: float | None = None,
    ) -> Any:
        request_headers = default_json_headers(
            json_body=json_body,
            headers=headers,
        )
        setdefault_header_case_insensitive_lazy(
            request_headers,
            "Authorization",
            lambda:
            f"Bearer {require_control_plane_token(self._client.config)}",
        )
        url = build_url(self._client.config.control_plane_base_url, path)
        return await self._client._request(
            method=method,
            url=url,
            headers=request_headers,
            params=params,
            json_body=json_body,
            timeout=timeout,
            error_context={"url": url},
        )


class AsyncInferenceClient:

    def __init__(self, client: AsyncTensormesh) -> None:
        self.serverless = AsyncServerlessInferenceClient(client)
        self.on_demand = AsyncOnDemandInferenceClient(client)


@dataclass(frozen=True)
class _InferenceSurfacePolicy:
    base_url_kind: Literal["serverless", "on_demand"]
    requires_user_id: bool
    public_get_paths: frozenset[str]


class _BaseOpenAIInferenceSurface:

    def __init__(
        self,
        client: AsyncTensormesh,
        *,
        policy: _InferenceSurfacePolicy,
    ) -> None:
        self._client = client
        self._policy = policy
        self.chat = AsyncChatNamespace(self)
        self.models = InferenceModelsClient(self)
        self.completions = AsyncTextCompletionsClient(self)
        self.responses = AsyncResponsesClient(self)
        self.tokenize = AsyncTokenizeClient(self)
        self.detokenize = AsyncDetokenizeClient(self)
        self.health = AsyncHealthClient(self)
        self.version = AsyncVersionClient(self)

    @staticmethod
    def _reject_user_id(user_id: str | None) -> None:
        if user_id is not None:
            raise ConfigurationError(
                "Serverless inference does not accept `user_id`. Pass `user_id` only for on-demand inference."
            )

    def _prepare_request(
        self,
        *,
        method: str,
        path: str,
        headers: Mapping[str, str] | None,
        json_body: Any | None,
        user_id: str | None,
    ) -> tuple[dict[str, str], str]:
        request_headers = default_json_headers(
            json_body=json_body,
            headers=headers,
        )
        if self._policy.base_url_kind == "serverless":
            self._reject_user_id(user_id)
            self._set_serverless_authorization_header(
                request_headers,
                method=method,
                path=path,
            )
            return request_headers, self._client.config.serverless_base_url

        header_user_id_key = find_header_key_case_insensitive(
            request_headers, "X-User-Id")
        header_has_user_id = header_user_id_key is not None
        base_url = require_on_demand_base_url(
            self._client.config,
            has_user_id=header_has_user_id or bool(user_id),
        )
        normalized_user_id = None
        if header_user_id_key is not None:
            request_headers[header_user_id_key] = normalize_on_demand_user_id(
                request_headers[header_user_id_key])
        else:
            normalized_user_id = resolve_on_demand_user_id(
                self._client.config,
                user_id,
            )

        setdefault_header_case_insensitive_lazy(
            request_headers,
            "Authorization",
            lambda: f"Bearer {require_inference_api_key(self._client.config)}",
        )
        if normalized_user_id is not None:
            setdefault_header_case_insensitive(
                request_headers,
                "X-User-Id",
                normalized_user_id,
            )
        return request_headers, base_url

    def _set_serverless_authorization_header(
        self,
        request_headers: dict[str, str],
        *,
        method: str,
        path: str,
    ) -> None:
        if find_header_key_case_insensitive(request_headers,
                                            "Authorization") is not None:
            return
        api_key = self._client.config.inference_api_key
        if api_key:
            request_headers["Authorization"] = f"Bearer {api_key}"
            return
        if (self._client.config.serverless_base_url
                == DEFAULT_SERVERLESS_BASE_URL and method.upper() == "GET"
                and path in self._policy.public_get_paths):
            return
        request_headers["Authorization"] = (
            f"Bearer {require_inference_api_key(self._client.config)}")

    async def request(
        self,
        method: str,
        path: str,
        *,
        params: Mapping[str, object] | None = None,
        json_body: Any | None = None,
        headers: Mapping[str, str] | None = None,
        timeout: float | None = None,
        user_id: str | None = None,
    ) -> Any:
        request_headers, base_url = self._prepare_request(
            method=method,
            path=path,
            headers=headers,
            json_body=json_body,
            user_id=user_id,
        )
        url = build_url(base_url, path)
        return await self._client._request(
            method=method,
            url=url,
            headers=request_headers,
            params=params,
            json_body=json_body,
            timeout=timeout,
            error_context={"url": url},
        )

    async def stream_request(
        self,
        method: str,
        path: str,
        *,
        params: Mapping[str, object] | None = None,
        json_body: Any | None = None,
        headers: Mapping[str, str] | None = None,
        timeout: float | None = None,
        read_timeout: float | None = None,
        user_id: str | None = None,
    ) -> Any:
        request_headers, base_url = self._prepare_request(
            method=method,
            path=path,
            headers=headers,
            json_body=json_body,
            user_id=user_id,
        )
        url = build_url(base_url, path)
        return await self._client._stream_request(
            method=method,
            url=url,
            headers=request_headers,
            params=params,
            json_body=json_body,
            timeout=timeout,
            read_timeout=read_timeout or DEFAULT_STREAM_READ_TIMEOUT_SECONDS,
            error_context={"url": url},
        )


class AsyncServerlessInferenceClient(_BaseOpenAIInferenceSurface):
    _PUBLIC_GET_PATHS = frozenset({
        "/v1/models",
        "/health",
        "/version",
    })

    def __init__(self, client: AsyncTensormesh) -> None:
        super().__init__(
            client,
            policy=_InferenceSurfacePolicy(
                base_url_kind="serverless",
                requires_user_id=False,
                public_get_paths=self._PUBLIC_GET_PATHS,
            ),
        )


class AsyncOnDemandInferenceClient(_BaseOpenAIInferenceSurface):

    def __init__(self, client: AsyncTensormesh) -> None:
        super().__init__(
            client,
            policy=_InferenceSurfacePolicy(
                base_url_kind="on_demand",
                requires_user_id=True,
                public_get_paths=frozenset(),
            ),
        )
