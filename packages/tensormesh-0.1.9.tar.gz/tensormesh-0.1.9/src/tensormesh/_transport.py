from __future__ import annotations

from dataclasses import dataclass
from email.utils import parsedate_to_datetime
import json
import time
from typing import Any, Callable, Mapping

import requests

from ._constants import DEFAULT_STREAM_READ_TIMEOUT_SECONDS
from ._exceptions import APIConnectionError
from ._exceptions import APITimeoutError
from ._exceptions import make_status_error

__all__ = [
    "DEFAULT_STREAM_READ_TIMEOUT_SECONDS",
    "SyncTransport",
    "TransportConfig",
    "build_url",
    "is_idempotent_method",
    "normalize_timeout_s",
    "request_with_retries",
    "resolve_timeout_s",
]

MAX_RETRY_DELAY_SECONDS = 8.0
_ORIGINAL_REQUESTS_REQUEST = requests.request


@dataclass(frozen=True)
class TransportConfig:
    verify: bool | str
    timeout_seconds: float
    max_retries: int


def build_url(base_url: str, path: str) -> str:
    base = (base_url or "").strip().rstrip("/")
    if not base:
        raise ValueError("Base URL must be a non-empty string.")
    normalized_path = path if path.startswith("/") else f"/{path}"
    return f"{base}{normalized_path}"


def normalize_timeout_s(timeout_s: float) -> float:
    timeout = float(timeout_s)
    if timeout <= 0:
        raise ValueError("Timeout must be greater than 0 seconds.")
    return timeout


def resolve_timeout_s(
    *,
    timeout_s: float | None,
    configured_timeout_s: object | None = None,
    default_timeout_s: float = 30.0,
) -> float:
    raw_timeout_s = timeout_s
    if raw_timeout_s is None:
        raw_timeout_s = configured_timeout_s
    if raw_timeout_s is None:
        raw_timeout_s = default_timeout_s
    return normalize_timeout_s(float(raw_timeout_s))


def is_idempotent_method(method: str) -> bool:
    return method.upper().strip() in ("GET", "HEAD", "OPTIONS", "PUT",
                                      "DELETE")


def _exponential_backoff_s(attempt: int) -> float:
    return min(MAX_RETRY_DELAY_SECONDS, 0.5 * (2**(attempt - 1)))


def _clamp_retry_delay_s(delay_s: float) -> float:
    return min(MAX_RETRY_DELAY_SECONDS, max(0.0, delay_s))


def _retry_after_delay_s(resp: requests.Response) -> float | None:
    raw_value = resp.headers.get("Retry-After") or resp.headers.get(
        "retry-after")
    if raw_value is None:
        return None

    value = raw_value.strip()
    if not value:
        return None

    try:
        seconds = float(value)
    except ValueError:
        try:
            retry_at = parsedate_to_datetime(value)
        except (TypeError, ValueError, IndexError, OverflowError):
            return None
        return _clamp_retry_delay_s(retry_at.timestamp() - time.time())
    return _clamp_retry_delay_s(seconds)


def _response_retry_delay_s(resp: requests.Response, attempt: int) -> float:
    retry_after_s = _retry_after_delay_s(resp)
    if retry_after_s is not None:
        return retry_after_s
    return _exponential_backoff_s(attempt)


def _close_response(resp: Any) -> None:
    close = getattr(resp, "close", None)
    if callable(close):
        close()


def _new_requests_session() -> requests.Session | None:
    session_factory = getattr(requests, "Session", None)
    if not callable(session_factory):
        return None
    return session_factory()


def request_with_retries(
    method: str,
    url: str,
    *,
    headers: Mapping[str, str] | None = None,
    params: Mapping[str, object] | None = None,
    json_body: Any | None = None,
    timeout_s: float = 30.0,
    verify: bool | str = True,
    max_retries: int = 0,
    idempotent: bool | None = None,
    log_attempt: Callable[[int, int], None] | None = None,
    request_callable: Callable[..., requests.Response] | None = None,
) -> requests.Response:
    normalized_timeout_s = normalize_timeout_s(timeout_s)
    method_u = method.upper().strip()
    use_idempotent = (is_idempotent_method(method_u)
                      if idempotent is None else bool(idempotent))
    attempts = 1 + (int(max_retries) if use_idempotent else 0)
    request_func = request_callable or requests.request

    last_exc: Exception | None = None
    next_delay_s: float | None = None
    for attempt in range(attempts):
        if attempt > 0:
            time.sleep(next_delay_s if next_delay_s is not None else
                       _exponential_backoff_s(attempt))
            next_delay_s = None

        if log_attempt is not None:
            log_attempt(attempt + 1, attempts)

        try:
            resp = request_func(
                method_u,
                url,
                headers=dict(headers or {}),
                params=dict(params or {}),
                json=json_body,
                timeout=normalized_timeout_s,
                verify=verify,
            )
        except requests.RequestException as exc:
            last_exc = exc
            if use_idempotent and attempt < attempts - 1:
                next_delay_s = _exponential_backoff_s(attempt + 1)
            continue

        if (use_idempotent and resp.status_code in (429, 500, 502, 503, 504)
                and attempt < attempts - 1):
            next_delay_s = _response_retry_delay_s(resp, attempt + 1)
            _close_response(resp)
            continue

        return resp

    assert last_exc is not None
    raise last_exc


def _response_body_and_text(resp: requests.Response) -> tuple[Any | None, str]:
    try:
        body = resp.json()
    except ValueError:
        text = (resp.text or "").strip()
        return text or None, text

    return body, json.dumps(body, ensure_ascii=False, sort_keys=False)


def _format_status_error_message(
    resp: requests.Response,
    *,
    status_hints: Mapping[int, str] | None = None,
    error_context: Mapping[str, str] | None = None,
) -> tuple[str, Any | None]:
    message = f"Request failed: HTTP {resp.status_code}"
    request_id = resp.headers.get("x-request-id") or resp.headers.get(
        "X-Request-Id")
    if request_id:
        message += f" (request_id={request_id})"

    body, body_text = _response_body_and_text(resp)
    if body_text:
        if len(body_text) > 4000:
            body_text = body_text[:4000] + "..."
        message += f": {body_text}"

    hint = (status_hints or {}).get(resp.status_code)
    if hint:
        message += f"\nHint: {hint}"

    if error_context:
        detail_lines = [
            f"{key}={value}" for key, value in error_context.items()
        ]
        if detail_lines:
            message += "\n" + "\n".join(detail_lines)

    return message, body


class SyncTransport:

    def __init__(
        self,
        *,
        verify: bool | str = True,
        timeout_seconds: float = 30.0,
        max_retries: int = 0,
        session: requests.Session | None = None,
    ) -> None:
        self._config = TransportConfig(
            verify=verify,
            timeout_seconds=resolve_timeout_s(
                timeout_s=timeout_seconds,
                default_timeout_s=timeout_seconds,
            ),
            max_retries=int(max_retries),
        )
        if self._config.max_retries < 0:
            raise ValueError("Max retries must be greater than or equal to 0.")
        if session is not None:
            self._session = session
            self._owns_session = False
        else:
            self._session = _new_requests_session()
            self._owns_session = self._session is not None

    @property
    def config(self) -> TransportConfig:
        return self._config

    def close(self) -> None:
        if self._owns_session and self._session is not None:
            self._session.close()
            self._session = None

    def _ensure_session(self) -> requests.Session:
        if self._session is None:
            self._session = _new_requests_session()
            self._owns_session = self._session is not None
        if self._session is None:
            raise RuntimeError("requests.Session is unavailable.")
        return self._session

    def request(
        self,
        method: str,
        url: str,
        *,
        headers: Mapping[str, str] | None = None,
        params: Mapping[str, object] | None = None,
        json_body: Any | None = None,
        timeout_s: float | None = None,
        idempotent: bool | None = None,
        status_hints: Mapping[int, str] | None = None,
        error_context: Mapping[str, str] | None = None,
        request_fn: Callable[..., requests.Response] | None = None,
        log_attempt: Callable[[int, int], None] | None = None,
    ) -> requests.Response:
        if request_fn is None:
            session = self._ensure_session()
            base_request_callable = (requests.request if requests.request
                                     is not _ORIGINAL_REQUESTS_REQUEST else
                                     session.request)
            request_callable: Callable[..., requests.Response] = (
                lambda method, url, **kwargs: request_with_retries(
                    method,
                    url,
                    request_callable=base_request_callable,
                    **kwargs,
                ))
        else:
            request_callable = request_fn
        effective_timeout_s = resolve_timeout_s(
            timeout_s=timeout_s,
            configured_timeout_s=self._config.timeout_seconds,
            default_timeout_s=self._config.timeout_seconds,
        )

        try:
            resp = request_callable(
                method,
                url,
                headers=headers,
                params=params,
                json_body=json_body,
                timeout_s=effective_timeout_s,
                verify=self._config.verify,
                max_retries=self._config.max_retries,
                idempotent=idempotent,
                log_attempt=log_attempt,
            )
        except requests.Timeout as exc:
            raise APITimeoutError(f"Request timed out: {exc}") from exc
        except requests.RequestException as exc:
            raise APIConnectionError(
                f"Request failed (network error): {exc}") from exc

        if resp.status_code >= 400:
            message, body = _format_status_error_message(
                resp,
                status_hints=status_hints,
                error_context=error_context,
            )
            raise make_status_error(response=resp, message=message, body=body)
        return resp

    def request_stream(
        self,
        method: str,
        url: str,
        *,
        headers: Mapping[str, str] | None = None,
        params: Mapping[str, object] | None = None,
        json_body: Any | None = None,
        timeout_s: float | None = None,
        read_timeout_s: float | None = None,
        status_hints: Mapping[int, str] | None = None,
        error_context: Mapping[str, str] | None = None,
        request_fn: Callable[..., requests.Response] | None = None,
    ) -> requests.Response:
        if request_fn is None:
            session = self._ensure_session()
            request_callable = (requests.request if requests.request
                                is not _ORIGINAL_REQUESTS_REQUEST else
                                session.request)
        else:
            request_callable = request_fn
        effective_timeout_s = resolve_timeout_s(
            timeout_s=timeout_s,
            configured_timeout_s=self._config.timeout_seconds,
            default_timeout_s=self._config.timeout_seconds,
        )
        effective_read_timeout_s = resolve_timeout_s(
            timeout_s=read_timeout_s,
            configured_timeout_s=DEFAULT_STREAM_READ_TIMEOUT_SECONDS,
            default_timeout_s=DEFAULT_STREAM_READ_TIMEOUT_SECONDS,
        )

        try:
            resp = request_callable(
                method.upper().strip(),
                url,
                headers=dict(headers or {}),
                params=dict(params or {}),
                json=json_body,
                stream=True,
                timeout=(effective_timeout_s, effective_read_timeout_s),
                verify=self._config.verify,
            )
        except requests.Timeout as exc:
            raise APITimeoutError(f"Request timed out: {exc}") from exc
        except requests.RequestException as exc:
            raise APIConnectionError(
                f"Request failed (network error): {exc}") from exc

        if resp.status_code >= 400:
            message, body = _format_status_error_message(
                resp,
                status_hints=status_hints,
                error_context=error_context,
            )
            close = getattr(resp, "close", None)
            if callable(close):
                close()
            raise make_status_error(response=resp, message=message, body=body)
        return resp
