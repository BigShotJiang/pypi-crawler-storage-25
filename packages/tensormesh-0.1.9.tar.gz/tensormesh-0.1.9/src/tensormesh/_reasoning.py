from __future__ import annotations

import re

_LEADING_THINK_BLOCK_RE = re.compile(r"^\s*(?:<think>.*?</think>\s*)+",
                                     re.DOTALL)
_THINK_BLOCK_RE = re.compile(r"<think>(.*?)</think>", re.DOTALL)


def normalize_leading_reasoning_content(
    content: str | None,
    reasoning: str | None,
) -> tuple[str | None, str | None]:
    if not isinstance(content, str):
        return content, reasoning

    match = _LEADING_THINK_BLOCK_RE.match(content)
    if match is None:
        return content, reasoning

    leaked_reasoning = [
        part.strip() for part in _THINK_BLOCK_RE.findall(match.group(0))
        if part.strip()
    ]
    normalized_content = content[match.end():] or None
    if reasoning is not None or not leaked_reasoning:
        return normalized_content, reasoning

    return normalized_content, "\n\n".join(leaked_reasoning)


class LeadingReasoningTextFilter:

    def __init__(self) -> None:
        self._buffer = ""
        self._mode = "prefix"

    def feed(self, text: str | None) -> str | None:
        if not text:
            return None
        if self._mode == "visible":
            return text

        self._buffer += text
        output: list[str] = []

        while True:
            if self._mode == "visible":
                if self._buffer:
                    output.append(self._buffer)
                    self._buffer = ""
                break

            if self._mode == "prefix":
                stripped = self._buffer.lstrip()
                if not stripped:
                    break
                if stripped.startswith("<think>"):
                    self._buffer = stripped[len("<think>"):]
                    self._mode = "reasoning"
                    continue
                if "<think>".startswith(stripped):
                    break
                self._mode = "visible"
                continue

            end = self._buffer.find("</think>")
            if end == -1:
                break
            self._buffer = self._buffer[end + len("</think>"):]
            self._mode = "prefix"

        visible = "".join(output)
        return visible or None
