from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from dataclasses import field
from typing import Any

from ._shared import coerce_model as _coerce_model
from ._shared import coerce_model_list as _coerce_model_list
from ._shared import extras as _extras
from ._shared import mapping as _mapping
from ._shared import serialize_model as _serialize_model
from ._shared import serialize_optional_fields as _serialize_optional_fields


def _serialize_conversation_message_payload(value: Any) -> Any:
    if isinstance(value, str):
        return {"content": value}
    return _serialize_model(value)


@dataclass(slots=True)
class EmptyResult:
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return dict(self.extra)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any] | None) -> EmptyResult:
        payload = _mapping(data or {})
        return cls(extra=payload)


@dataclass(slots=True)
class DeletionResult:
    deleted: bool | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({"deleted": self.deleted})
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any] | None) -> DeletionResult:
        payload = _mapping(data or {})
        return cls(
            deleted=payload.get("deleted"),
            extra=_extras(payload, {"deleted"}),
        )


@dataclass(slots=True)
class Money:
    currency_code: str | None = None
    units: str | None = None
    nanos: int | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "currencyCode": self.currency_code,
            "units": self.units,
            "nanos": self.nanos,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> Money:
        if not isinstance(data, Mapping):
            if isinstance(data, bool):
                raise TypeError("Expected a money mapping, not a boolean.")
            return cls(units=str(data))
        payload = _mapping(data)
        units = payload.get("units")
        if isinstance(units, int):
            units = str(units)
        return cls(
            currency_code=payload.get("currencyCode"),
            units=units,
            nanos=payload.get("nanos"),
            extra=_extras(payload, {"currencyCode", "units", "nanos"}),
        )


@dataclass(slots=True)
class BillingAddress:
    line1: str | None = None
    line2: str | None = None
    city: str | None = None
    state: str | None = None
    postal_code: str | None = None
    country: str | None = None
    company: str | None = None
    phone: str | None = None
    name: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "line1": self.line1,
            "line2": self.line2,
            "city": self.city,
            "state": self.state,
            "postalCode": self.postal_code,
            "country": self.country,
            "company": self.company,
            "phone": self.phone,
            "name": self.name,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> BillingAddress:
        payload = _mapping(data)
        return cls(
            line1=payload.get("line1"),
            line2=payload.get("line2"),
            city=payload.get("city"),
            state=payload.get("state"),
            postal_code=payload.get("postalCode"),
            country=payload.get("country"),
            company=payload.get("company"),
            phone=payload.get("phone"),
            name=payload.get("name"),
            extra=_extras(
                payload, {
                    "line1",
                    "line2",
                    "city",
                    "state",
                    "postalCode",
                    "country",
                    "company",
                    "phone",
                    "name",
                }),
        )


@dataclass(slots=True)
class BillingStripeCustomer:
    stripe_customer_id: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "stripeCusId":
            self.stripe_customer_id,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> BillingStripeCustomer:
        payload = _mapping(data)
        return cls(
            stripe_customer_id=payload.get("stripeCusId"),
            extra=_extras(payload, {"stripeCusId"}),
        )


@dataclass(slots=True)
class BillingStripePaymentMethod:
    stripe_payment_method_id: str | None = None
    type: str | None = None
    brand: str | None = None
    last4: str | None = None
    exp_month: int | None = None
    exp_year: int | None = None
    is_default: bool | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "stripePaymentMethodId": self.stripe_payment_method_id,
            "type": self.type,
            "brand": self.brand,
            "last4": self.last4,
            "expMonth": self.exp_month,
            "expYear": self.exp_year,
            "isDefault": self.is_default,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> BillingStripePaymentMethod:
        payload = _mapping(data)
        return cls(
            stripe_payment_method_id=payload.get("stripePaymentMethodId"),
            type=payload.get("type"),
            brand=payload.get("brand"),
            last4=payload.get("last4"),
            exp_month=payload.get("expMonth"),
            exp_year=payload.get("expYear"),
            is_default=payload.get("isDefault"),
            extra=_extras(
                payload, {
                    "stripePaymentMethodId",
                    "type",
                    "brand",
                    "last4",
                    "expMonth",
                    "expYear",
                    "isDefault",
                }),
        )


@dataclass(slots=True)
class BillingStripePaymentMethodsPage:
    stripe_payment_method_ids: list[str] = field(default_factory=list)
    payment_methods: list[BillingStripePaymentMethod] = field(
        default_factory=list)
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "stripePaymentMethodIds":
            self.stripe_payment_method_ids,
            "paymentMethods":
            self.payment_methods,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(
        cls,
        data: Mapping[str, Any],
    ) -> BillingStripePaymentMethodsPage:
        payload = _mapping(data)
        return cls(
            stripe_payment_method_ids=(list(payload["stripePaymentMethodIds"])
                                       if payload.get("stripePaymentMethodIds")
                                       is not None else []),
            payment_methods=(_coerce_model_list(payload.get("paymentMethods"),
                                                BillingStripePaymentMethod)
                             or []),
            extra=_extras(payload,
                          {"stripePaymentMethodIds", "paymentMethods"}),
        )


@dataclass(slots=True)
class BillingStripePaymentIntent:
    stripe_payment_intent_id: str | None = None
    client_secret: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "stripePaymentIntentId": self.stripe_payment_intent_id,
            "clientSecret": self.client_secret,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> BillingStripePaymentIntent:
        payload = _mapping(data)
        return cls(
            stripe_payment_intent_id=payload.get("stripePaymentIntentId"),
            client_secret=payload.get("clientSecret"),
            extra=_extras(payload, {"stripePaymentIntentId", "clientSecret"}),
        )


@dataclass(slots=True)
class BillingStripeSetupIntent:
    stripe_setup_intent_id: str | None = None
    client_secret: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "stripeSetupIntentId": self.stripe_setup_intent_id,
            "clientSecret": self.client_secret,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> BillingStripeSetupIntent:
        payload = _mapping(data)
        return cls(
            stripe_setup_intent_id=payload.get("stripeSetupIntentId"),
            client_secret=payload.get("clientSecret"),
            extra=_extras(payload, {"stripeSetupIntentId", "clientSecret"}),
        )


@dataclass(slots=True)
class BillingTransaction:
    transaction_id: str | None = None
    stripe_payment_intent_id: str | None = None
    payment_method_id: str | None = None
    created_at: str | None = None
    amount: Money | None = None
    description: str | None = None
    status: str | None = None
    type: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "transactionId": self.transaction_id,
            "stripePaymentIntentId": self.stripe_payment_intent_id,
            "paymentMethodId": self.payment_method_id,
            "createdAt": self.created_at,
            "amount": self.amount,
            "description": self.description,
            "status": self.status,
            "type": self.type,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> BillingTransaction:
        payload = _mapping(data)
        return cls(
            transaction_id=payload.get("transactionId"),
            stripe_payment_intent_id=payload.get("stripePaymentIntentId"),
            payment_method_id=payload.get("paymentMethodId"),
            created_at=payload.get("createdAt"),
            amount=_coerce_model(payload.get("amount"), Money),
            description=payload.get("description"),
            status=payload.get("status"),
            type=payload.get("type"),
            extra=_extras(
                payload, {
                    "transactionId",
                    "stripePaymentIntentId",
                    "paymentMethodId",
                    "createdAt",
                    "amount",
                    "description",
                    "status",
                    "type",
                }),
        )


@dataclass(slots=True)
class BillingTransactionsPage:
    transactions: list[BillingTransaction] = field(default_factory=list)
    next_page_token: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "transactions":
            self.transactions,
            "nextPageToken":
            self.next_page_token,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> BillingTransactionsPage:
        payload = _mapping(data)
        return cls(
            transactions=_coerce_model_list(payload.get("transactions"),
                                            BillingTransaction) or [],
            next_page_token=payload.get("nextPageToken"),
            extra=_extras(payload, {"transactions", "nextPageToken"}),
        )


@dataclass(slots=True)
class SpendingBucket:
    bucket_start: str | None = None
    amount: Money | None = None
    cost_saving: Money | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "bucketStart": self.bucket_start,
            "amount": self.amount,
            "costSaving": self.cost_saving,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> SpendingBucket:
        payload = _mapping(data)
        return cls(
            bucket_start=payload.get("bucketStart"),
            amount=_coerce_model(payload.get("amount"), Money),
            cost_saving=_coerce_model(payload.get("costSaving"), Money),
            extra=_extras(payload, {"bucketStart", "amount", "costSaving"}),
        )


@dataclass(slots=True)
class SpendingSummary:
    spend_24h: Money | None = None
    spend_7d: Money | None = None
    spend_30d: Money | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "spend24h": self.spend_24h,
            "spend7d": self.spend_7d,
            "spend30d": self.spend_30d,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> SpendingSummary:
        payload = _mapping(data)
        return cls(
            spend_24h=_coerce_model(payload.get("spend24h"), Money),
            spend_7d=_coerce_model(payload.get("spend7d"), Money),
            spend_30d=_coerce_model(payload.get("spend30d"), Money),
            extra=_extras(payload, {"spend24h", "spend7d", "spend30d"}),
        )


@dataclass(slots=True)
class UserBalanceInfo:
    user_id: str | None = None
    balance: Money | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "userId": self.user_id,
            "balance": self.balance,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> UserBalanceInfo:
        payload = _mapping(data)
        return cls(
            user_id=payload.get("userId"),
            balance=_coerce_model(payload.get("balance"), Money),
            extra=_extras(payload, {"userId", "balance"}),
        )


@dataclass(slots=True)
class UserSpendingSummary:
    user_id: str | None = None
    spend_24h: Money | None = None
    spend_7d: Money | None = None
    spend_30d: Money | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "userId": self.user_id,
            "spend24h": self.spend_24h,
            "spend7d": self.spend_7d,
            "spend30d": self.spend_30d,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> UserSpendingSummary:
        payload = _mapping(data)
        return cls(
            user_id=payload.get("userId"),
            spend_24h=_coerce_model(payload.get("spend24h"), Money),
            spend_7d=_coerce_model(payload.get("spend7d"), Money),
            spend_30d=_coerce_model(payload.get("spend30d"), Money),
            extra=_extras(payload,
                          {"userId", "spend24h", "spend7d", "spend30d"}),
        )


@dataclass(slots=True)
class GpuPricing:
    gpu_type: str | None = None
    cloud_provider: str | None = None
    hourly_rate: Money | None = None
    is_active: bool | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "gpuType": self.gpu_type,
            "cloudProvider": self.cloud_provider,
            "hourlyRate": self.hourly_rate,
            "isActive": self.is_active,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> GpuPricing:
        payload = _mapping(data)
        return cls(
            gpu_type=payload.get("gpuType"),
            cloud_provider=payload.get("cloudProvider"),
            hourly_rate=_coerce_model(payload.get("hourlyRate"), Money),
            is_active=payload.get("isActive"),
            extra=_extras(
                payload,
                {"gpuType", "cloudProvider", "hourlyRate", "isActive"}),
        )


@dataclass(slots=True)
class ServerlessPricing:
    id: str | None = None
    name: str | None = None
    model: str | None = None
    input_token_price: Money | None = None
    output_token_price: Money | None = None
    cached_token_price: Money | None = None
    is_active: bool | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "id": self.id,
            "name": self.name,
            "model": self.model,
            "inputTokenPrice": self.input_token_price,
            "outputTokenPrice": self.output_token_price,
            "cachedTokenPrice": self.cached_token_price,
            "isActive": self.is_active,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ServerlessPricing:
        payload = _mapping(data)
        return cls(
            id=payload.get("id"),
            name=payload.get("name"),
            model=payload.get("model"),
            input_token_price=_coerce_model(payload.get("inputTokenPrice"),
                                            Money),
            output_token_price=_coerce_model(payload.get("outputTokenPrice"),
                                             Money),
            cached_token_price=_coerce_model(payload.get("cachedTokenPrice"),
                                             Money),
            is_active=payload.get("isActive"),
            extra=_extras(
                payload, {
                    "id",
                    "name",
                    "model",
                    "inputTokenPrice",
                    "outputTokenPrice",
                    "cachedTokenPrice",
                    "isActive",
                }),
        )


@dataclass(slots=True)
class Product:
    id: str | None = None
    name: str | None = None
    required_gpu_num: int | None = None
    family: str | None = None
    is_active: bool | None = None
    spec: dict[str, Any] | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "id": self.id,
            "name": self.name,
            "requiredGpuNum": self.required_gpu_num,
            "family": self.family,
            "isActive": self.is_active,
            "spec": self.spec,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> Product:
        payload = _mapping(data)
        return cls(
            id=payload.get("id"),
            name=payload.get("name"),
            required_gpu_num=payload.get("requiredGpuNum"),
            family=payload.get("family"),
            is_active=payload.get("isActive"),
            spec=(dict(payload["spec"]) if isinstance(
                payload.get("spec"), Mapping) else payload.get("spec")),
            extra=_extras(payload, {
                "id",
                "name",
                "requiredGpuNum",
                "family",
                "isActive",
                "spec",
            }),
        )


@dataclass(slots=True)
class LogEntry:
    timestamp: str | None = None
    message: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "timestamp": self.timestamp,
            "message": self.message,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> LogEntry:
        payload = _mapping(data)
        return cls(
            timestamp=payload.get("timestamp"),
            message=payload.get("message"),
            extra=_extras(payload, {"timestamp", "message"}),
        )


@dataclass(slots=True)
class MetricData:
    timestamp: str | None = None
    value: float | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "timestamp": self.timestamp,
            "value": self.value,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> MetricData:
        payload = _mapping(data)
        return cls(
            timestamp=payload.get("timestamp"),
            value=payload.get("value"),
            extra=_extras(payload, {"timestamp", "value"}),
        )


@dataclass(slots=True)
class Metric:
    name: str | None = None
    data: list[MetricData] | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "name": self.name,
            "data": self.data,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> Metric:
        payload = _mapping(data)
        return cls(
            name=payload.get("name"),
            data=_coerce_model_list(payload.get("data"), MetricData),
            extra=_extras(payload, {"name", "data"}),
        )


@dataclass(slots=True)
class ConversationMessage:
    user_id: str | None = None
    user_name: str | None = None
    user_role: str | None = None
    content: str | None = None
    created_at: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "userId": self.user_id,
            "userName": self.user_name,
            "userRole": self.user_role,
            "content": self.content,
            "createdAt": self.created_at,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ConversationMessage:
        payload = _mapping(data)
        return cls(
            user_id=payload.get("userId"),
            user_name=payload.get("userName"),
            user_role=payload.get("userRole"),
            content=payload.get("content"),
            created_at=payload.get("createdAt"),
            extra=_extras(payload, {
                "userId",
                "userName",
                "userRole",
                "content",
                "createdAt",
            }),
        )


@dataclass(slots=True)
class Ticket:
    ticket_id: str | None = None
    subject: str | None = None
    requester_user_id: str | None = None
    status: str | None = None
    type: str | None = None
    conversations: list[ConversationMessage] | None = None
    created_at: str | None = None
    updated_at: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "ticketId": self.ticket_id,
            "subject": self.subject,
            "requesterUserId": self.requester_user_id,
            "status": self.status,
            "type": self.type,
            "conversations": self.conversations,
            "createdAt": self.created_at,
            "updatedAt": self.updated_at,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> Ticket:
        payload = _mapping(data)
        return cls(
            ticket_id=payload.get("ticketId"),
            subject=payload.get("subject"),
            requester_user_id=payload.get("requesterUserId"),
            status=payload.get("status"),
            type=payload.get("type"),
            conversations=_coerce_model_list(payload.get("conversations"),
                                             ConversationMessage),
            created_at=payload.get("createdAt"),
            updated_at=payload.get("updatedAt"),
            extra=_extras(
                payload, {
                    "ticketId",
                    "subject",
                    "requesterUserId",
                    "status",
                    "type",
                    "conversations",
                    "createdAt",
                    "updatedAt",
                }),
        )


@dataclass(slots=True)
class TicketsPage:
    tickets: list[Ticket] = field(default_factory=list)
    next_page_token: str | None = None
    page: int | None = None
    size: int | None = None
    total: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "tickets": self.tickets,
            "nextPageToken": self.next_page_token,
            "page": self.page,
            "size": self.size,
            "total": self.total,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> TicketsPage:
        payload = _mapping(data)
        return cls(
            tickets=_coerce_model_list(payload.get("tickets"), Ticket) or [],
            next_page_token=payload.get("nextPageToken"),
            page=payload.get("page"),
            size=payload.get("size"),
            total=payload.get("total"),
            extra=_extras(
                payload,
                {"tickets", "nextPageToken", "page", "size", "total"}),
        )


@dataclass(slots=True)
class ReservedDeploymentSubmission:
    request_id: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({"requestId": self.request_id})
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str,
                                     Any]) -> ReservedDeploymentSubmission:
        payload = _mapping(data)
        return cls(
            request_id=payload.get("requestId"),
            extra=_extras(payload, {"requestId"}),
        )


@dataclass(slots=True)
class Activity:
    activity_id: str | None = None
    actor_type: str | None = None
    user_id: str | None = None
    action: str | None = None
    resource_type: str | None = None
    resource_id: str | None = None
    description: str | None = None
    metadata: dict[str, Any] | None = None
    occurred_at: str | None = None
    recorded_at: str | None = None
    actor_id: str | None = None
    actor_display: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "activityId": self.activity_id,
            "actorType": self.actor_type,
            "userId": self.user_id,
            "action": self.action,
            "resourceType": self.resource_type,
            "resourceId": self.resource_id,
            "description": self.description,
            "metadata": self.metadata,
            "occurredAt": self.occurred_at,
            "recordedAt": self.recorded_at,
            "actorId": self.actor_id,
            "actorDisplay": self.actor_display,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> Activity:
        payload = _mapping(data)
        return cls(
            activity_id=payload.get("activityId"),
            actor_type=payload.get("actorType"),
            user_id=payload.get("userId"),
            action=payload.get("action"),
            resource_type=payload.get("resourceType"),
            resource_id=payload.get("resourceId"),
            description=payload.get("description"),
            metadata=(dict(payload["metadata"]) if isinstance(
                payload.get("metadata"), Mapping) else
                      payload.get("metadata")),
            occurred_at=payload.get("occurredAt"),
            recorded_at=payload.get("recordedAt"),
            actor_id=payload.get("actorId"),
            actor_display=payload.get("actorDisplay"),
            extra=_extras(
                payload, {
                    "activityId",
                    "actorType",
                    "userId",
                    "action",
                    "resourceType",
                    "resourceId",
                    "description",
                    "metadata",
                    "occurredAt",
                    "recordedAt",
                    "actorId",
                    "actorDisplay",
                }),
        )


@dataclass(slots=True)
class ActivitiesPage:
    activities: list[Activity] = field(default_factory=list)
    total: int | None = None
    page: int | None = None
    size: int | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "activities": self.activities,
            "total": self.total,
            "page": self.page,
            "size": self.size,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ActivitiesPage:
        payload = _mapping(data)
        return cls(
            activities=_coerce_model_list(payload.get("activities"), Activity)
            or [],
            total=payload.get("total"),
            page=payload.get("page"),
            size=payload.get("size"),
            extra=_extras(payload, {"activities", "total", "page", "size"}),
        )


@dataclass(slots=True)
class ApiKey:
    id: str | None = None
    name: str | None = None
    scopes: list[str] | None = None
    created_at: str | None = None
    expires_at: str | None = None
    deleted_at: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "id": self.id,
            "name": self.name,
            "scopes": self.scopes,
            "createdAt": self.created_at,
            "expiresAt": self.expires_at,
            "deletedAt": self.deleted_at,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ApiKey:
        payload = _mapping(data)
        return cls(
            id=payload.get("id"),
            name=payload.get("name"),
            scopes=(list(payload["scopes"])
                    if payload.get("scopes") is not None else None),
            created_at=payload.get("createdAt"),
            expires_at=payload.get("expiresAt"),
            deleted_at=payload.get("deletedAt"),
            extra=_extras(payload, {
                "id",
                "name",
                "scopes",
                "createdAt",
                "expiresAt",
                "deletedAt",
            }),
        )


@dataclass(slots=True)
class InfraConfig:
    cloud_provider: str | None = None
    nebius_region: str | None = None
    lambda_region: str | None = None
    onprem_region: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "cloudProvider": self.cloud_provider,
            "nebiusRegion": self.nebius_region,
            "lambdaRegion": self.lambda_region,
            "onpremRegion": self.onprem_region,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> InfraConfig:
        payload = _mapping(data)
        return cls(
            cloud_provider=payload.get("cloudProvider"),
            nebius_region=payload.get("nebiusRegion"),
            lambda_region=payload.get("lambdaRegion"),
            onprem_region=payload.get("onpremRegion"),
            extra=_extras(payload, {
                "cloudProvider",
                "nebiusRegion",
                "lambdaRegion",
                "onpremRegion",
            }),
        )


@dataclass(slots=True)
class ModelEvent:
    created_at: str | None = None
    log: str | None = None
    event_type: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "createdAt": self.created_at,
            "log": self.log,
            "eventType": self.event_type,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ModelEvent:
        payload = _mapping(data)
        return cls(
            created_at=payload.get("createdAt"),
            log=payload.get("log"),
            event_type=payload.get("eventType"),
            extra=_extras(payload, {"createdAt", "log", "eventType"}),
        )


@dataclass(slots=True)
class Model:
    model_id: str | None = None
    deployment_id: str | None = None
    user_id: str | None = None
    description: str | None = None
    model_path: str | None = None
    model_name: str | None = None
    status: str | None = None
    events: list[ModelEvent] | None = None
    created_at: str | None = None
    updated_at: str | None = None
    model_spec: dict[str, Any] | None = None
    infra: InfraConfig | None = None
    gpu_count: int | None = None
    gpu_type: str | None = None
    replicas: int | None = None
    endpoint: str | None = None
    api_key: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "modelId": self.model_id,
            "deploymentId": self.deployment_id,
            "userId": self.user_id,
            "description": self.description,
            "modelPath": self.model_path,
            "modelName": self.model_name,
            "status": self.status,
            "events": self.events,
            "createdAt": self.created_at,
            "updatedAt": self.updated_at,
            "modelSpec": self.model_spec,
            "infra": self.infra,
            "gpuCount": self.gpu_count,
            "gpuType": self.gpu_type,
            "replicas": self.replicas,
            "endpoint": self.endpoint,
            "apiKey": self.api_key,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> Model:
        payload = _mapping(data)
        return cls(
            model_id=payload.get("modelId"),
            deployment_id=payload.get("deploymentId"),
            user_id=payload.get("userId"),
            description=payload.get("description"),
            model_path=payload.get("modelPath"),
            model_name=payload.get("modelName"),
            status=payload.get("status"),
            events=_coerce_model_list(payload.get("events"), ModelEvent),
            created_at=payload.get("createdAt"),
            updated_at=payload.get("updatedAt"),
            model_spec=(dict(payload["modelSpec"]) if isinstance(
                payload.get("modelSpec"), Mapping) else
                        payload.get("modelSpec")),
            infra=_coerce_model(payload.get("infra"), InfraConfig),
            gpu_count=payload.get("gpuCount"),
            gpu_type=payload.get("gpuType"),
            replicas=payload.get("replicas"),
            endpoint=payload.get("endpoint"),
            api_key=payload.get("apiKey"),
            extra=_extras(
                payload, {
                    "modelId",
                    "deploymentId",
                    "userId",
                    "description",
                    "modelPath",
                    "modelName",
                    "status",
                    "events",
                    "createdAt",
                    "updatedAt",
                    "modelSpec",
                    "infra",
                    "gpuCount",
                    "gpuType",
                    "replicas",
                    "endpoint",
                    "apiKey",
                }),
        )


@dataclass(slots=True)
class ModelsPage:
    models: list[Model] = field(default_factory=list)
    page: int | None = None
    size: int | None = None
    total: int | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "models": self.models,
            "page": self.page,
            "size": self.size,
            "total": self.total,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ModelsPage:
        payload = _mapping(data)
        return cls(
            models=_coerce_model_list(payload.get("models"), Model) or [],
            page=payload.get("page"),
            size=payload.get("size"),
            total=payload.get("total"),
            extra=_extras(payload, {"models", "page", "size", "total"}),
        )


@dataclass(slots=True)
class User:
    id: str | None = None
    first_name: str | None = None
    last_name: str | None = None
    display_name: str | None = None
    user_email: str | None = None
    auth_provider: str | None = None
    auth_provider_id: str | None = None
    avatar_url: str | None = None
    stripe_customer_id: str | None = None
    user_role: str | None = None
    company: str | None = None
    tos_accepted_at: str | None = None
    survey_completed_at: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "id":
            self.id,
            "firstName":
            self.first_name,
            "lastName":
            self.last_name,
            "displayName":
            self.display_name,
            "userEmail":
            self.user_email,
            "authProvider":
            self.auth_provider,
            "authProviderId":
            self.auth_provider_id,
            "avatarUrl":
            self.avatar_url,
            "stripeCusId":
            self.stripe_customer_id,
            "userRole":
            self.user_role,
            "company":
            self.company,
            "tosAcceptedAt":
            self.tos_accepted_at,
            "surveyCompletedAt":
            self.survey_completed_at,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> User:
        payload = _mapping(data)
        return cls(
            id=payload.get("id"),
            first_name=payload.get("firstName"),
            last_name=payload.get("lastName"),
            display_name=payload.get("displayName"),
            user_email=payload.get("userEmail"),
            auth_provider=payload.get("authProvider"),
            auth_provider_id=payload.get("authProviderId"),
            avatar_url=payload.get("avatarUrl"),
            stripe_customer_id=payload.get("stripeCusId"),
            user_role=payload.get("userRole"),
            company=payload.get("company"),
            tos_accepted_at=payload.get("tosAcceptedAt"),
            survey_completed_at=payload.get("surveyCompletedAt"),
            extra=_extras(
                payload, {
                    "id",
                    "firstName",
                    "lastName",
                    "displayName",
                    "userEmail",
                    "authProvider",
                    "authProviderId",
                    "avatarUrl",
                    "stripeCusId",
                    "userRole",
                    "company",
                    "tosAcceptedAt",
                    "surveyCompletedAt",
                    "apiKey",
                }),
        )


@dataclass(slots=True)
class UsersPage:
    users: list[User] = field(default_factory=list)
    page: int | None = None
    size: int | None = None
    total: int | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "users": self.users,
            "page": self.page,
            "size": self.size,
            "total": self.total,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> UsersPage:
        payload = _mapping(data)
        return cls(
            users=_coerce_model_list(payload.get("users"), User) or [],
            page=payload.get("page"),
            size=payload.get("size"),
            total=payload.get("total"),
            extra=_extras(payload, {"users", "page", "size", "total"}),
        )


@dataclass(slots=True)
class ValidationResult:
    is_valid: bool | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({"isValid": self.is_valid})
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ValidationResult:
        payload = _mapping(data)
        return cls(
            is_valid=payload.get("isValid"),
            extra=_extras(payload, {"isValid"}),
        )


@dataclass(slots=True)
class ModelCheckResult:
    required_gpu_memory_gib: float | None = None
    required_lm_cache_memory_gib: float | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "requiredGpuMemoryGib":
            self.required_gpu_memory_gib,
            "requiredLmCacheMemoryGib":
            self.required_lm_cache_memory_gib,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ModelCheckResult:
        payload = _mapping(data)
        return cls(
            required_gpu_memory_gib=payload.get("requiredGpuMemoryGib"),
            required_lm_cache_memory_gib=payload.get(
                "requiredLmCacheMemoryGib"),
            extra=_extras(payload, {
                "requiredGpuMemoryGib",
                "requiredLmCacheMemoryGib",
            }),
        )


@dataclass(slots=True)
class ModelChatResponse:
    response: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({"response": self.response})
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ModelChatResponse:
        payload = _mapping(data)
        return cls(
            response=payload.get("response"),
            extra=_extras(payload, {"response"}),
        )
