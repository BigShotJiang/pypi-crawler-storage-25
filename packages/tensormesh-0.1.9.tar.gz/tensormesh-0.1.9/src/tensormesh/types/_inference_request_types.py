from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from dataclasses import field
from typing import Any

from ._shared import coerce_model as _coerce_model
from ._shared import coerce_model_list as _coerce_model_list
from ._shared import extras as _extras
from ._shared import mapping as _mapping
from ._shared import serialize_model as _serialize_model
from ._shared import serialize_optional_fields as _serialize_optional_fields


@dataclass(slots=True)
class StreamOptions:
    include_usage: bool | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields(
            {"include_usage": self.include_usage})
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> StreamOptions:
        payload = _mapping(data)
        return cls(
            include_usage=payload.get("include_usage"),
            extra=_extras(payload, {"include_usage"}),
        )


@dataclass(slots=True)
class ResponseFormat:
    type: str

    def __post_init__(self) -> None:
        _validate_response_format_type(self.type)

    def to_dict(self) -> dict[str, Any]:
        return {"type": self.type}

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ResponseFormat:
        payload = _mapping(data)
        extra = _extras(payload, {"type"})
        if extra:
            extra_keys = ", ".join(sorted(extra))
            raise ValueError(
                "Unsupported response_format keys for this inference surface: "
                f"{extra_keys}")
        return cls(type=str(payload["type"]))


def _validate_response_format_type(value: str) -> None:
    if value not in {"json_object", "text"}:
        raise ValueError(
            "Unsupported response_format.type for this inference surface: "
            f"{value!r}. Supported values are 'json_object' and 'text'.")


def _validate_constant_type(owner: str, value: str, expected: str) -> None:
    if value != expected:
        raise ValueError(f"{owner}.type must be {expected!r}, got {value!r}.")


@dataclass(slots=True)
class PredictedOutput:
    content: str | list[dict[str, Any]]
    type: str = "content"
    extra: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        _validate_constant_type("PredictedOutput", self.type, "content")

    def to_dict(self) -> dict[str, Any]:
        data = {"content": _serialize_model(self.content), "type": self.type}
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> PredictedOutput:
        payload = _mapping(data)
        return cls(
            content=payload["content"],
            type=str(payload.get("type", "content")),
            extra=_extras(payload, {"content", "type"}),
        )


@dataclass(slots=True)
class ThinkingConfigEnabled:
    budget_tokens: int | None = None
    type: str = "enabled"
    extra: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        _validate_constant_type("ThinkingConfigEnabled", self.type, "enabled")

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "type": self.type,
            "budget_tokens": self.budget_tokens,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ThinkingConfigEnabled:
        payload = _mapping(data)
        return cls(
            budget_tokens=payload.get("budget_tokens"),
            type=str(payload.get("type", "enabled")),
            extra=_extras(payload, {"budget_tokens", "type"}),
        )


@dataclass(slots=True)
class ThinkingConfigDisabled:
    type: str = "disabled"
    extra: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        _validate_constant_type("ThinkingConfigDisabled", self.type,
                                "disabled")

    def to_dict(self) -> dict[str, Any]:
        data = {"type": self.type}
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ThinkingConfigDisabled:
        payload = _mapping(data)
        return cls(
            type=str(payload.get("type", "disabled")),
            extra=_extras(payload, {"type"}),
        )


@dataclass(slots=True)
class ChatCompletionFunction:
    name: str
    description: str | None = None
    parameters: dict[str, Any] | None = None
    strict: bool | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "name": self.name,
            "description": self.description,
            "parameters": self.parameters,
            "strict": self.strict,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ChatCompletionFunction:
        payload = _mapping(data)
        return cls(
            name=str(payload["name"]),
            description=payload.get("description"),
            parameters=(dict(payload["parameters"]) if isinstance(
                payload.get("parameters"), Mapping) else
                        payload.get("parameters")),
            strict=payload.get("strict"),
            extra=_extras(payload,
                          {"name", "description", "parameters", "strict"}),
        )


@dataclass(slots=True)
class ChatCompletionTool:
    function: ChatCompletionFunction
    type: str = "function"
    extra: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        _validate_constant_type("ChatCompletionTool", self.type, "function")

    def to_dict(self) -> dict[str, Any]:
        data = {
            "type": self.type,
            "function": self.function.to_dict(),
        }
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ChatCompletionTool:
        payload = _mapping(data)
        return cls(
            function=_coerce_model(payload["function"],
                                   ChatCompletionFunction),
            type=str(payload.get("type", "function")),
            extra=_extras(payload, {"function", "type"}),
        )


@dataclass(slots=True)
class FunctionNameSpec:
    name: str
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = {"name": self.name}
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> FunctionNameSpec:
        payload = _mapping(data)
        return cls(name=str(payload["name"]), extra=_extras(payload, {"name"}))


@dataclass(slots=True)
class FunctionSelection:
    function: FunctionNameSpec | None = None
    type: str = "function"
    extra: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        _validate_constant_type("FunctionSelection", self.type, "function")

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "type": self.type,
            "function": self.function,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> FunctionSelection:
        payload = _mapping(data)
        return cls(
            function=_coerce_model(payload.get("function"), FunctionNameSpec),
            type=str(payload.get("type", "function")),
            extra=_extras(payload, {"function", "type"}),
        )


@dataclass(slots=True)
class ChatCompletionMessageToolCallFunction:
    name: str | None = None
    arguments: str | dict[str, Any] | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "name": self.name,
            "arguments": self.arguments,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(
        cls,
        data: Mapping[str, Any],
    ) -> ChatCompletionMessageToolCallFunction:
        payload = _mapping(data)
        return cls(
            name=payload.get("name"),
            arguments=payload.get("arguments"),
            extra=_extras(payload, {"name", "arguments"}),
        )


@dataclass(slots=True)
class ChatCompletionMessageToolCall:
    function: ChatCompletionMessageToolCallFunction
    id: str | None = None
    type: str = "function"
    extra: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        _validate_constant_type("ChatCompletionMessageToolCall", self.type,
                                "function")

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "id": self.id,
            "type": self.type,
            "function": self.function,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str,
                                     Any]) -> ChatCompletionMessageToolCall:
        payload = _mapping(data)
        return cls(
            function=_coerce_model(payload["function"],
                                   ChatCompletionMessageToolCallFunction),
            id=payload.get("id"),
            type=str(payload.get("type", "function")),
            extra=_extras(payload, {"function", "id", "type"}),
        )


@dataclass(slots=True)
class ChatMessage:
    role: str
    content: str | None = None
    name: str | None = None
    reasoning_content: str | None = None
    tool_call_id: str | None = None
    tool_calls: list[ChatCompletionMessageToolCall] | None = None
    reasoning: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "role": self.role,
            "content": self.content,
            "name": self.name,
            "reasoning_content": self.reasoning_content,
            "tool_call_id": self.tool_call_id,
            "tool_calls": self.tool_calls,
            "reasoning": self.reasoning,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ChatMessage:
        payload = _mapping(data)
        return cls(
            role=str(payload["role"]),
            content=payload.get("content"),
            name=payload.get("name"),
            reasoning_content=payload.get("reasoning_content"),
            tool_call_id=payload.get("tool_call_id"),
            tool_calls=_coerce_model_list(payload.get("tool_calls"),
                                          ChatCompletionMessageToolCall),
            reasoning=payload.get("reasoning"),
            extra=_extras(
                payload, {
                    "role",
                    "content",
                    "name",
                    "reasoning_content",
                    "tool_call_id",
                    "tool_calls",
                    "reasoning",
                }),
        )


@dataclass(slots=True)
class ChatCompletionRequest:
    model: str
    messages: list[ChatMessage]
    temperature: float | None = None
    top_p: float | None = None
    max_tokens: int | None = None
    max_completion_tokens: int | None = None
    n: int | None = None
    stop: str | list[str] | None = None
    top_k: int | None = None
    min_p: float | None = None
    typical_p: float | None = None
    seed: int | None = None
    repetition_penalty: float | None = None
    mirostat_target: float | None = None
    mirostat_lr: float | None = None
    stream: bool | None = None
    stream_options: StreamOptions | None = None
    response_format: ResponseFormat | None = None
    tools: list[ChatCompletionTool] | None = None
    tool_choice: str | FunctionSelection | None = None
    parallel_tool_calls: bool | None = None
    presence_penalty: float | None = None
    frequency_penalty: float | None = None
    logprobs: bool | None = None
    top_logprobs: int | None = None
    logit_bias: dict[str, float] | None = None
    user: str | None = None
    metadata: dict[str, Any] | None = None
    prompt_truncate_len: int | None = None
    context_length_exceeded_behavior: str | None = None
    return_token_ids: bool | None = None
    prompt_cache_isolation_key: str | None = None
    raw_output: bool | None = None
    perf_metrics_in_response: bool | None = None
    echo: bool | None = None
    echo_last: int | None = None
    ignore_eos: bool | None = None
    speculation: str | list[int] | None = None
    prediction: PredictedOutput | str | None = None
    reasoning_effort: str | int | bool | None = None
    reasoning_history: str | None = None
    thinking: ThinkingConfigEnabled | ThinkingConfigDisabled | None = None
    functions: list[ChatCompletionFunction] | None = None
    function_call: str | FunctionNameSpec | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "model":
            self.model,
            "messages":
            self.messages,
            "temperature":
            self.temperature,
            "top_p":
            self.top_p,
            "max_tokens":
            self.max_tokens,
            "max_completion_tokens":
            self.max_completion_tokens,
            "n":
            self.n,
            "stop":
            self.stop,
            "top_k":
            self.top_k,
            "min_p":
            self.min_p,
            "typical_p":
            self.typical_p,
            "seed":
            self.seed,
            "repetition_penalty":
            self.repetition_penalty,
            "mirostat_target":
            self.mirostat_target,
            "mirostat_lr":
            self.mirostat_lr,
            "stream":
            self.stream,
            "stream_options":
            self.stream_options,
            "response_format":
            self.response_format,
            "tools":
            self.tools,
            "tool_choice":
            self.tool_choice,
            "parallel_tool_calls":
            self.parallel_tool_calls,
            "presence_penalty":
            self.presence_penalty,
            "frequency_penalty":
            self.frequency_penalty,
            "logprobs":
            self.logprobs,
            "top_logprobs":
            self.top_logprobs,
            "logit_bias":
            self.logit_bias,
            "user":
            self.user,
            "metadata":
            self.metadata,
            "prompt_truncate_len":
            self.prompt_truncate_len,
            "context_length_exceeded_behavior":
            self.context_length_exceeded_behavior,
            "return_token_ids":
            self.return_token_ids,
            "prompt_cache_isolation_key":
            self.prompt_cache_isolation_key,
            "raw_output":
            self.raw_output,
            "perf_metrics_in_response":
            self.perf_metrics_in_response,
            "echo":
            self.echo,
            "echo_last":
            self.echo_last,
            "ignore_eos":
            self.ignore_eos,
            "speculation":
            self.speculation,
            "prediction":
            self.prediction,
            "reasoning_effort":
            self.reasoning_effort,
            "reasoning_history":
            self.reasoning_history,
            "thinking":
            self.thinking,
            "functions":
            self.functions,
            "function_call":
            self.function_call,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ChatCompletionRequest:
        payload = _mapping(data)
        return cls(
            model=str(payload["model"]),
            messages=[
                _coerce_model(item, ChatMessage)
                for item in payload.get("messages", [])
            ],
            temperature=payload.get("temperature"),
            top_p=payload.get("top_p"),
            max_tokens=payload.get("max_tokens"),
            max_completion_tokens=payload.get("max_completion_tokens"),
            n=payload.get("n"),
            stop=payload.get("stop"),
            top_k=payload.get("top_k"),
            min_p=payload.get("min_p"),
            typical_p=payload.get("typical_p"),
            seed=payload.get("seed"),
            repetition_penalty=payload.get("repetition_penalty"),
            mirostat_target=payload.get("mirostat_target"),
            mirostat_lr=payload.get("mirostat_lr"),
            stream=payload.get("stream"),
            stream_options=_coerce_model(payload.get("stream_options"),
                                         StreamOptions),
            response_format=_coerce_model(payload.get("response_format"),
                                          ResponseFormat),
            tools=_coerce_model_list(payload.get("tools"), ChatCompletionTool),
            tool_choice=(payload.get("tool_choice")
                         if isinstance(payload.get("tool_choice"), str) or
                         payload.get("tool_choice") is None else _coerce_model(
                             payload.get("tool_choice"), FunctionSelection)),
            parallel_tool_calls=payload.get("parallel_tool_calls"),
            presence_penalty=payload.get("presence_penalty"),
            frequency_penalty=payload.get("frequency_penalty"),
            logprobs=payload.get("logprobs"),
            top_logprobs=payload.get("top_logprobs"),
            logit_bias=(dict(payload["logit_bias"]) if isinstance(
                payload.get("logit_bias"), Mapping) else
                        payload.get("logit_bias")),
            user=payload.get("user"),
            metadata=(dict(payload["metadata"]) if isinstance(
                payload.get("metadata"), Mapping) else
                      payload.get("metadata")),
            prompt_truncate_len=payload.get("prompt_truncate_len"),
            context_length_exceeded_behavior=payload.get(
                "context_length_exceeded_behavior"),
            return_token_ids=payload.get("return_token_ids"),
            prompt_cache_isolation_key=payload.get(
                "prompt_cache_isolation_key"),
            raw_output=payload.get("raw_output"),
            perf_metrics_in_response=payload.get("perf_metrics_in_response"),
            echo=payload.get("echo"),
            echo_last=payload.get("echo_last"),
            ignore_eos=payload.get("ignore_eos"),
            speculation=payload.get("speculation"),
            prediction=(payload.get("prediction")
                        if isinstance(payload.get("prediction"), str) or
                        payload.get("prediction") is None else _coerce_model(
                            payload.get("prediction"), PredictedOutput)),
            reasoning_effort=payload.get("reasoning_effort"),
            reasoning_history=payload.get("reasoning_history"),
            thinking=(None if payload.get("thinking") is None else
                      ThinkingConfigDisabled.from_dict(payload["thinking"])
                      if payload["thinking"].get("type") == "disabled" else
                      ThinkingConfigEnabled.from_dict(payload["thinking"])),
            functions=_coerce_model_list(payload.get("functions"),
                                         ChatCompletionFunction),
            function_call=(payload.get("function_call")
                           if isinstance(payload.get("function_call"), str)
                           or payload.get("function_call") is None else
                           _coerce_model(payload.get("function_call"),
                                         FunctionNameSpec)),
            extra=_extras(
                payload, {
                    "model",
                    "messages",
                    "temperature",
                    "top_p",
                    "max_tokens",
                    "max_completion_tokens",
                    "n",
                    "stop",
                    "top_k",
                    "min_p",
                    "typical_p",
                    "seed",
                    "repetition_penalty",
                    "mirostat_target",
                    "mirostat_lr",
                    "stream",
                    "stream_options",
                    "response_format",
                    "tools",
                    "tool_choice",
                    "parallel_tool_calls",
                    "presence_penalty",
                    "frequency_penalty",
                    "logprobs",
                    "top_logprobs",
                    "logit_bias",
                    "user",
                    "metadata",
                    "prompt_truncate_len",
                    "context_length_exceeded_behavior",
                    "return_token_ids",
                    "prompt_cache_isolation_key",
                    "raw_output",
                    "perf_metrics_in_response",
                    "echo",
                    "echo_last",
                    "ignore_eos",
                    "speculation",
                    "prediction",
                    "reasoning_effort",
                    "reasoning_history",
                    "thinking",
                    "functions",
                    "function_call",
                }),
        )
