from __future__ import annotations

from collections.abc import Mapping
from typing import Any

__all__ = [
    "coerce_mapping",
    "coerce_model",
    "coerce_model_list",
    "extras",
    "mapping",
    "serialize_model",
    "serialize_optional_fields",
]


def mapping(data: Mapping[str, Any] | dict[str, Any]) -> dict[str, Any]:
    return dict(data)


def extras(data: Mapping[str, Any], known: set[str]) -> dict[str, Any]:
    return {key: value for key, value in data.items() if key not in known}


def serialize_model(value: Any) -> Any:
    if hasattr(value, "to_dict") and callable(value.to_dict):
        return value.to_dict()
    if isinstance(value, list):
        return [serialize_model(item) for item in value]
    return value


def serialize_optional_fields(values: Mapping[str, Any]) -> dict[str, Any]:
    return {
        key: serialize_model(value)
        for key, value in values.items() if value is not None
    }


def coerce_mapping(value: Any) -> dict[str, Any]:
    if isinstance(value, Mapping):
        return dict(value)
    raise TypeError("Expected a mapping.")


def coerce_model(value: Any, cls: type[Any]) -> Any:
    if value is None or isinstance(value, cls):
        return value
    return cls.from_dict(coerce_mapping(value))


def coerce_model_list(value: Any, cls: type[Any]) -> list[Any] | None:
    if value is None:
        return None
    return [coerce_model(item, cls) for item in list(value)]
