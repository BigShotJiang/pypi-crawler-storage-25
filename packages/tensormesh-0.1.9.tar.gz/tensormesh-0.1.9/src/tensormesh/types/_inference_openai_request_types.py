from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from dataclasses import field
from typing import Any

from ._inference_request_types import ChatMessage
from ._shared import extras as _extras
from ._shared import mapping as _mapping
from ._shared import serialize_optional_fields as _serialize_optional_fields


@dataclass(slots=True)
class TextCompletionRequest:
    model: str
    prompt: str | list[str]
    max_tokens: int | None = None
    stream: bool | None = None
    temperature: float | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "model": self.model,
            "prompt": self.prompt,
            "max_tokens": self.max_tokens,
            "stream": self.stream,
            "temperature": self.temperature,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> TextCompletionRequest:
        payload = _mapping(data)
        return cls(
            model=str(payload["model"]),
            prompt=payload["prompt"],
            max_tokens=payload.get("max_tokens"),
            stream=payload.get("stream"),
            temperature=payload.get("temperature"),
            extra=_extras(
                payload,
                {"model", "prompt", "max_tokens", "stream", "temperature"}),
        )


@dataclass(slots=True)
class ResponseCreateRequest:
    model: str
    input: str | list[dict[str, Any]]
    max_output_tokens: int | None = None
    stream: bool | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "model": self.model,
            "input": self.input,
            "max_output_tokens": self.max_output_tokens,
            "stream": self.stream,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ResponseCreateRequest:
        payload = _mapping(data)
        return cls(
            model=str(payload["model"]),
            input=payload["input"],
            max_output_tokens=payload.get("max_output_tokens"),
            stream=payload.get("stream"),
            extra=_extras(
                payload,
                {"model", "input", "max_output_tokens", "stream"},
            ),
        )


@dataclass(slots=True)
class TokenizeRequest:
    model: str
    prompt: str | list[str] | None = None
    messages: list[ChatMessage | dict[str, Any]] | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        serialized_messages = None
        if self.messages is not None:
            serialized_messages = [
                item.to_dict() if isinstance(item, ChatMessage) else item
                for item in self.messages
            ]
        data = _serialize_optional_fields({
            "model": self.model,
            "prompt": self.prompt,
            "messages": serialized_messages,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> TokenizeRequest:
        payload = _mapping(data)
        return cls(
            model=str(payload["model"]),
            prompt=payload.get("prompt"),
            messages=payload.get("messages"),
            extra=_extras(payload, {"model", "prompt", "messages"}),
        )


@dataclass(slots=True)
class DetokenizeRequest:
    model: str
    tokens: list[int]
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = {
            "model": self.model,
            "tokens": self.tokens,
        }
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> DetokenizeRequest:
        payload = _mapping(data)
        return cls(
            model=str(payload["model"]),
            tokens=[int(item) for item in list(payload["tokens"])],
            extra=_extras(payload, {"model", "tokens"}),
        )
