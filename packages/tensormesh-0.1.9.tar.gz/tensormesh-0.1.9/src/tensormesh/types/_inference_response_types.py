from __future__ import annotations

from collections.abc import Mapping
from collections.abc import Sequence
from dataclasses import dataclass
from dataclasses import field
from typing import Any

from tensormesh._reasoning import normalize_leading_reasoning_content

from ._inference_request_types import ChatCompletionMessageToolCall
from ._shared import coerce_model as _coerce_model
from ._shared import coerce_model_list as _coerce_model_list
from ._shared import extras as _extras
from ._shared import mapping as _mapping
from ._shared import serialize_optional_fields as _serialize_optional_fields


@dataclass(slots=True)
class ChatCompletionMessage:
    role: str
    content: str | None = None
    refusal: str | None = None
    annotations: list[dict[str, Any]] | None = None
    audio: dict[str, Any] | None = None
    function_call: dict[str, Any] | None = None
    tool_calls: list[ChatCompletionMessageToolCall] | None = None
    reasoning: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "role": self.role,
            "content": self.content,
            "refusal": self.refusal,
            "annotations": self.annotations,
            "audio": self.audio,
            "function_call": self.function_call,
            "tool_calls": self.tool_calls,
            "reasoning": self.reasoning,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ChatCompletionMessage:
        payload = _mapping(data)
        content, reasoning = normalize_leading_reasoning_content(
            payload.get("content"),
            payload.get("reasoning"),
        )
        return cls(
            role=str(payload["role"]),
            content=content,
            refusal=payload.get("refusal"),
            annotations=(list(payload["annotations"])
                         if isinstance(payload.get("annotations"), Sequence)
                         and not isinstance(payload.get("annotations"),
                                            (str, bytes)) else
                         payload.get("annotations")),
            audio=(dict(payload["audio"]) if isinstance(
                payload.get("audio"), Mapping) else payload.get("audio")),
            function_call=(dict(payload["function_call"]) if isinstance(
                payload.get("function_call"), Mapping) else
                           payload.get("function_call")),
            tool_calls=_coerce_model_list(payload.get("tool_calls"),
                                          ChatCompletionMessageToolCall),
            reasoning=reasoning,
            extra=_extras(
                payload, {
                    "role",
                    "content",
                    "refusal",
                    "annotations",
                    "audio",
                    "function_call",
                    "tool_calls",
                    "reasoning",
                }),
        )


@dataclass(slots=True)
class ChatCompletionResponseChoice:
    index: int
    message: ChatCompletionMessage
    finish_reason: str | None = None
    logprobs: dict[str, Any] | None = None
    raw_output: dict[str, Any] | None = None
    stop_reason: str | None = None
    token_ids: list[int] | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "index": self.index,
            "message": self.message,
            "finish_reason": self.finish_reason,
            "logprobs": self.logprobs,
            "raw_output": self.raw_output,
            "stop_reason": self.stop_reason,
            "token_ids": self.token_ids,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(
        cls,
        data: Mapping[str, Any],
    ) -> ChatCompletionResponseChoice:
        payload = _mapping(data)
        return cls(
            index=int(payload["index"]),
            message=_coerce_model(payload["message"], ChatCompletionMessage),
            finish_reason=payload.get("finish_reason"),
            logprobs=(dict(payload["logprobs"]) if isinstance(
                payload.get("logprobs"), Mapping) else
                      payload.get("logprobs")),
            raw_output=(dict(payload["raw_output"]) if isinstance(
                payload.get("raw_output"), Mapping) else
                        payload.get("raw_output")),
            stop_reason=payload.get("stop_reason"),
            token_ids=(list(payload["token_ids"])
                       if isinstance(payload.get("token_ids"), Sequence)
                       and not isinstance(payload.get("token_ids"),
                                          (str, bytes)) else
                       payload.get("token_ids")),
            extra=_extras(
                payload, {
                    "index",
                    "message",
                    "finish_reason",
                    "logprobs",
                    "raw_output",
                    "stop_reason",
                    "token_ids",
                }),
        )


@dataclass(slots=True)
class UsageInfo:
    prompt_tokens: int
    total_tokens: int
    completion_tokens: int | None = None
    prompt_tokens_details: dict[str, Any] | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "prompt_tokens":
            self.prompt_tokens,
            "total_tokens":
            self.total_tokens,
            "completion_tokens":
            self.completion_tokens,
            "prompt_tokens_details":
            self.prompt_tokens_details,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> UsageInfo:
        payload = _mapping(data)
        return cls(
            prompt_tokens=int(payload["prompt_tokens"]),
            total_tokens=int(payload["total_tokens"]),
            completion_tokens=payload.get("completion_tokens"),
            prompt_tokens_details=(dict(
                payload["prompt_tokens_details"]) if isinstance(
                    payload.get("prompt_tokens_details"), Mapping) else
                                   payload.get("prompt_tokens_details")),
            extra=_extras(
                payload, {
                    "prompt_tokens",
                    "total_tokens",
                    "completion_tokens",
                    "prompt_tokens_details",
                }),
        )


@dataclass(slots=True)
class ChatCompletionResponse:
    id: str
    created: int
    model: str
    choices: list[ChatCompletionResponseChoice]
    object: str = "chat.completion"
    usage: UsageInfo | None = None
    perf_metrics: dict[str, Any] | None = None
    prompt_token_ids: list[int] | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "id":
            self.id,
            "object":
            self.object,
            "created":
            self.created,
            "model":
            self.model,
            "choices":
            self.choices,
            "usage":
            self.usage,
            "perf_metrics":
            self.perf_metrics,
            "prompt_token_ids":
            self.prompt_token_ids,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ChatCompletionResponse:
        payload = _mapping(data)
        return cls(
            id=str(payload["id"]),
            object=str(payload.get("object", "chat.completion")),
            created=int(payload["created"]),
            model=str(payload["model"]),
            choices=[
                _coerce_model(item, ChatCompletionResponseChoice)
                for item in payload.get("choices", [])
            ],
            usage=_coerce_model(payload.get("usage"), UsageInfo),
            perf_metrics=(dict(payload["perf_metrics"]) if isinstance(
                payload.get("perf_metrics"), Mapping) else
                          payload.get("perf_metrics")),
            prompt_token_ids=(
                list(payload["prompt_token_ids"])
                if isinstance(payload.get("prompt_token_ids"), Sequence)
                and not isinstance(payload.get("prompt_token_ids"),
                                   (str, bytes)) else
                payload.get("prompt_token_ids")),
            extra=_extras(
                payload, {
                    "id",
                    "object",
                    "created",
                    "model",
                    "choices",
                    "usage",
                    "perf_metrics",
                    "prompt_token_ids",
                }),
        )


@dataclass(slots=True)
class DeltaMessage:
    role: str | None = None
    content: str | None = None
    reasoning: str | None = None
    tool_calls: list[ChatCompletionMessageToolCall] | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "role": self.role,
            "content": self.content,
            "reasoning": self.reasoning,
            "tool_calls": self.tool_calls,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> DeltaMessage:
        payload = _mapping(data)
        content, reasoning = normalize_leading_reasoning_content(
            payload.get("content"),
            payload.get("reasoning"),
        )
        return cls(
            role=payload.get("role"),
            content=content,
            reasoning=reasoning,
            tool_calls=_coerce_model_list(payload.get("tool_calls"),
                                          ChatCompletionMessageToolCall),
            extra=_extras(payload,
                          {"role", "content", "reasoning", "tool_calls"}),
        )


@dataclass(slots=True)
class ChatCompletionStreamChoice:
    index: int
    delta: DeltaMessage
    finish_reason: str | None = None
    logprobs: dict[str, Any] | None = None
    token_ids: list[int] | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "index": self.index,
            "delta": self.delta,
            "finish_reason": self.finish_reason,
            "logprobs": self.logprobs,
            "token_ids": self.token_ids,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ChatCompletionStreamChoice:
        payload = _mapping(data)
        return cls(
            index=int(payload["index"]),
            delta=_coerce_model(payload["delta"], DeltaMessage),
            finish_reason=payload.get("finish_reason"),
            logprobs=(dict(payload["logprobs"]) if isinstance(
                payload.get("logprobs"), Mapping) else
                      payload.get("logprobs")),
            token_ids=(list(payload["token_ids"])
                       if isinstance(payload.get("token_ids"), Sequence)
                       and not isinstance(payload.get("token_ids"),
                                          (str, bytes)) else
                       payload.get("token_ids")),
            extra=_extras(payload, {
                "index",
                "delta",
                "finish_reason",
                "logprobs",
                "token_ids",
            }),
        )


@dataclass(slots=True)
class ChatCompletionChunk:
    id: str
    created: int
    model: str
    choices: list[ChatCompletionStreamChoice]
    object: str = "chat.completion.chunk"
    usage: UsageInfo | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "id": self.id,
            "object": self.object,
            "created": self.created,
            "model": self.model,
            "choices": self.choices,
            "usage": self.usage,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ChatCompletionChunk:
        payload = _mapping(data)
        return cls(
            id=str(payload["id"]),
            object=str(payload.get("object", "chat.completion.chunk")),
            created=int(payload["created"]),
            model=str(payload["model"]),
            choices=[
                _coerce_model(item, ChatCompletionStreamChoice)
                for item in payload.get("choices", [])
            ],
            usage=_coerce_model(payload.get("usage"), UsageInfo),
            extra=_extras(payload, {
                "id",
                "object",
                "created",
                "model",
                "choices",
                "usage",
            }),
        )
