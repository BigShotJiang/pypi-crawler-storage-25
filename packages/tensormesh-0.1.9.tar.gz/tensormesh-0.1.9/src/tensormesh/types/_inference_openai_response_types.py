from __future__ import annotations

from collections.abc import Mapping
from collections.abc import Sequence
from dataclasses import dataclass
from dataclasses import field
from typing import Any

from ._inference_response_types import UsageInfo
from ._shared import coerce_model as _coerce_model
from ._shared import coerce_model_list as _coerce_model_list
from ._shared import extras as _extras
from ._shared import mapping as _mapping
from ._shared import serialize_optional_fields as _serialize_optional_fields


@dataclass(slots=True)
class InferenceModel:
    id: str
    object: str
    created: int | None = None
    owned_by: str | None = None
    root: str | None = None
    parent: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "id": self.id,
            "object": self.object,
            "created": self.created,
            "owned_by": self.owned_by,
            "root": self.root,
            "parent": self.parent,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> InferenceModel:
        payload = _mapping(data)
        return cls(
            id=str(payload["id"]),
            object=str(payload["object"]),
            created=payload.get("created"),
            owned_by=payload.get("owned_by"),
            root=payload.get("root"),
            parent=payload.get("parent"),
            extra=_extras(
                payload,
                {"id", "object", "created", "owned_by", "root", "parent"}),
        )


@dataclass(slots=True)
class InferenceModelList:
    data: list[InferenceModel]
    object: str = "list"
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = {
            "object": self.object,
            "data": self.data,
        }
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> InferenceModelList:
        payload = _mapping(data)
        return cls(
            object=str(payload.get("object", "list")),
            data=_coerce_model_list(payload.get("data"), InferenceModel) or [],
            extra=_extras(payload, {"object", "data"}),
        )


@dataclass(slots=True)
class TextCompletionChoice:
    index: int
    text: str | None = None
    finish_reason: str | None = None
    logprobs: dict[str, Any] | None = None
    stop_reason: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "index": self.index,
            "text": self.text,
            "finish_reason": self.finish_reason,
            "logprobs": self.logprobs,
            "stop_reason": self.stop_reason,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> TextCompletionChoice:
        payload = _mapping(data)
        return cls(
            index=int(payload["index"]),
            text=payload.get("text"),
            finish_reason=payload.get("finish_reason"),
            logprobs=(dict(payload["logprobs"]) if isinstance(
                payload.get("logprobs"), Mapping) else
                      payload.get("logprobs")),
            stop_reason=payload.get("stop_reason"),
            extra=_extras(
                payload,
                {"index", "text", "finish_reason", "logprobs", "stop_reason"}),
        )


@dataclass(slots=True)
class TextCompletionResponse:
    id: str
    created: int
    model: str
    choices: list[TextCompletionChoice]
    object: str = "text_completion"
    usage: UsageInfo | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "id": self.id,
            "object": self.object,
            "created": self.created,
            "model": self.model,
            "choices": self.choices,
            "usage": self.usage,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> TextCompletionResponse:
        payload = _mapping(data)
        return cls(
            id=str(payload["id"]),
            object=str(payload.get("object", "text_completion")),
            created=int(payload["created"]),
            model=str(payload["model"]),
            choices=_coerce_model_list(payload.get("choices"),
                                       TextCompletionChoice) or [],
            usage=_coerce_model(payload.get("usage"), UsageInfo),
            extra=_extras(
                payload,
                {"id", "object", "created", "model", "choices", "usage"}),
        )


@dataclass(slots=True)
class ResponseOutputContent:
    type: str
    text: str | None = None
    annotations: list[dict[str, Any]] | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "type": self.type,
            "text": self.text,
            "annotations": self.annotations,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ResponseOutputContent:
        payload = _mapping(data)
        annotations = payload.get("annotations")
        return cls(
            type=str(payload["type"]),
            text=payload.get("text"),
            annotations=(list(annotations)
                         if isinstance(annotations, Sequence)
                         and not isinstance(annotations,
                                            (str, bytes)) else annotations),
            extra=_extras(payload, {"type", "text", "annotations"}),
        )


@dataclass(slots=True)
class ResponseOutputItem:
    id: str | None = None
    type: str | None = None
    role: str | None = None
    status: str | None = None
    content: list[ResponseOutputContent] | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "id": self.id,
            "type": self.type,
            "role": self.role,
            "status": self.status,
            "content": self.content,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ResponseOutputItem:
        payload = _mapping(data)
        return cls(
            id=payload.get("id"),
            type=payload.get("type"),
            role=payload.get("role"),
            status=payload.get("status"),
            content=_coerce_model_list(payload.get("content"),
                                       ResponseOutputContent),
            extra=_extras(payload,
                          {"id", "type", "role", "status", "content"}),
        )


@dataclass(slots=True)
class ResponseCreateResponse:
    id: str
    created_at: int | None = None
    model: str | None = None
    object: str = "response"
    status: str | None = None
    output: list[ResponseOutputItem] | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "id": self.id,
            "created_at": self.created_at,
            "model": self.model,
            "object": self.object,
            "status": self.status,
            "output": self.output,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ResponseCreateResponse:
        payload = _mapping(data)
        return cls(
            id=str(payload["id"]),
            created_at=payload.get("created_at"),
            model=payload.get("model"),
            object=str(payload.get("object", "response")),
            status=payload.get("status"),
            output=_coerce_model_list(payload.get("output"),
                                      ResponseOutputItem),
            extra=_extras(
                payload,
                {"id", "created_at", "model", "object", "status", "output"}),
        )


@dataclass(slots=True)
class TokenizeResponse:
    tokens: list[int]
    count: int | None = None
    max_model_len: int | None = None
    token_strs: list[str] | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "tokens": self.tokens,
            "count": self.count,
            "max_model_len": self.max_model_len,
            "token_strs": self.token_strs,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> TokenizeResponse:
        payload = _mapping(data)
        return cls(
            tokens=[int(item) for item in list(payload.get("tokens", []))],
            count=payload.get("count"),
            max_model_len=payload.get("max_model_len"),
            token_strs=([
                str(item) for item in list(payload.get("token_strs", []))
            ] if payload.get("token_strs") is not None else None),
            extra=_extras(payload,
                          {"tokens", "count", "max_model_len", "token_strs"}),
        )


@dataclass(slots=True)
class DetokenizeResponse:
    prompt: str
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = {"prompt": self.prompt}
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> DetokenizeResponse:
        payload = _mapping(data)
        return cls(
            prompt=str(payload["prompt"]),
            extra=_extras(payload, {"prompt"}),
        )


@dataclass(slots=True)
class HealthResponse:
    status: str
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = {"status": self.status}
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> HealthResponse:
        payload = _mapping(data)
        return cls(
            status=str(payload["status"]),
            extra=_extras(payload, {"status"}),
        )


@dataclass(slots=True)
class VersionResponse:
    version: str
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = {"version": self.version}
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> VersionResponse:
        payload = _mapping(data)
        return cls(
            version=str(payload["version"]),
            extra=_extras(payload, {"version"}),
        )
