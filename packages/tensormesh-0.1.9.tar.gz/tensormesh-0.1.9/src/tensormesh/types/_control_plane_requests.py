from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from dataclasses import field
from typing import Any

from ._control_plane_entities import _serialize_conversation_message_payload
from ._control_plane_entities import BillingAddress
from ._control_plane_entities import ConversationMessage
from ._control_plane_entities import GpuPricing
from ._control_plane_entities import InfraConfig
from ._control_plane_entities import Money
from ._control_plane_entities import Product
from ._control_plane_entities import ServerlessPricing
from ._shared import coerce_model as _coerce_model
from ._shared import extras as _extras
from ._shared import mapping as _mapping
from ._shared import serialize_optional_fields as _serialize_optional_fields


@dataclass(slots=True)
class UpdateUserProfileRequest:
    first_name: str | None = None
    last_name: str | None = None
    display_name: str | None = None
    company: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "firstName": self.first_name,
            "lastName": self.last_name,
            "displayName": self.display_name,
            "company": self.company,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> UpdateUserProfileRequest:
        payload = _mapping(data)
        return cls(
            first_name=payload.get("firstName"),
            last_name=payload.get("lastName"),
            display_name=payload.get("displayName"),
            company=payload.get("company"),
            extra=_extras(payload, {
                "firstName",
                "lastName",
                "displayName",
                "company",
            }),
        )


@dataclass(slots=True)
class UpdateBillingAddressRequest:
    address: BillingAddress | Mapping[str, Any]
    user_id: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "userId": self.user_id,
            "address": self.address,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> UpdateBillingAddressRequest:
        payload = _mapping(data)
        return cls(
            address=_coerce_model(payload["address"], BillingAddress),
            user_id=payload.get("userId"),
            extra=_extras(payload, {"address", "userId"}),
        )


@dataclass(slots=True)
class AdminUserChangeRoleRequest:
    target_user_id: str
    target_user_role: str
    user_id: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "userId":
            self.user_id,
            "targetUserId":
            self.target_user_id,
            "targetUserRole":
            self.target_user_role,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> AdminUserChangeRoleRequest:
        payload = _mapping(data)
        return cls(
            target_user_id=str(payload["targetUserId"]),
            target_user_role=str(payload["targetUserRole"]),
            user_id=payload.get("userId"),
            extra=_extras(payload,
                          {"userId", "targetUserId", "targetUserRole"}),
        )


@dataclass(slots=True)
class AdminBalancesLookupRequest:
    user_id: str | None = None
    target_user_ids: list[str] | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "userId":
            self.user_id,
            "targetUserIds":
            self.target_user_ids,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> AdminBalancesLookupRequest:
        payload = _mapping(data)
        return cls(
            user_id=payload.get("userId"),
            target_user_ids=(list(payload["targetUserIds"])
                             if payload.get("targetUserIds") is not None else
                             None),
            extra=_extras(payload, {"userId", "targetUserIds"}),
        )


@dataclass(slots=True)
class AdminBalanceAddRequest:
    target_user_id: str
    amount: Money | Mapping[str, Any] | float | int
    user_id: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "userId": self.user_id,
            "targetUserId": self.target_user_id,
            "amount": self.amount,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> AdminBalanceAddRequest:
        payload = _mapping(data)
        amount = payload["amount"]
        if isinstance(amount, Mapping):
            amount = _coerce_model(amount, Money)
        return cls(
            target_user_id=str(payload["targetUserId"]),
            amount=amount,
            user_id=payload.get("userId"),
            extra=_extras(payload, {"userId", "targetUserId", "amount"}),
        )


@dataclass(slots=True)
class AdminSpendingSummaryRequest:
    user_id: str | None = None
    target_user_ids: list[str] | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "userId":
            self.user_id,
            "targetUserIds":
            self.target_user_ids,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> AdminSpendingSummaryRequest:
        payload = _mapping(data)
        return cls(
            user_id=payload.get("userId"),
            target_user_ids=(list(payload["targetUserIds"])
                             if payload.get("targetUserIds") is not None else
                             None),
            extra=_extras(payload, {"userId", "targetUserIds"}),
        )


@dataclass(slots=True)
class ProductUpsertRequest:
    product: Product | Mapping[str, Any]
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({"product": self.product})
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ProductUpsertRequest:
        payload = _mapping(data)
        return cls(
            product=_coerce_model(payload["product"], Product),
            extra=_extras(payload, {"product"}),
        )


@dataclass(slots=True)
class GpuPricingUpsertRequest:
    pricing: GpuPricing | Mapping[str, Any]
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({"pricing": self.pricing})
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> GpuPricingUpsertRequest:
        payload = _mapping(data)
        return cls(
            pricing=_coerce_model(payload["pricing"], GpuPricing),
            extra=_extras(payload, {"pricing"}),
        )


@dataclass(slots=True)
class ServerlessPricingUpsertRequest:
    pricing: ServerlessPricing | Mapping[str, Any]
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({"pricing": self.pricing})
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(
        cls,
        data: Mapping[str, Any],
    ) -> ServerlessPricingUpsertRequest:
        payload = _mapping(data)
        return cls(
            pricing=_coerce_model(payload["pricing"], ServerlessPricing),
            extra=_extras(payload, {"pricing"}),
        )


@dataclass(slots=True)
class DeployModelRequest:
    model_name: str | None = None
    user_id: str | None = None
    description: str | None = None
    infra: InfraConfig | Mapping[str, Any] | None = None
    model_path: str | None = None
    gpu_count: int | None = None
    gpu_type: str | None = None
    model_spec: dict[str, Any] | None = None
    api_key: str | None = None
    hf_token: str | None = None
    kv_cache_enabled: bool | None = None
    cpu_offloading_enabled: bool | None = None
    node_id: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "modelName": self.model_name,
            "userId": self.user_id,
            "description": self.description,
            "infra": self.infra,
            "modelPath": self.model_path,
            "gpuCount": self.gpu_count,
            "gpuType": self.gpu_type,
            "modelSpec": self.model_spec,
            "apiKey": self.api_key,
            "hfToken": self.hf_token,
            "kvCacheEnabled": self.kv_cache_enabled,
            "cpuOffloadingEnabled": self.cpu_offloading_enabled,
            "nodeId": self.node_id,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> DeployModelRequest:
        payload = _mapping(data)
        return cls(
            model_name=payload.get("modelName"),
            user_id=payload.get("userId"),
            description=payload.get("description"),
            infra=_coerce_model(payload.get("infra"), InfraConfig),
            model_path=payload.get("modelPath"),
            gpu_count=payload.get("gpuCount"),
            gpu_type=payload.get("gpuType"),
            model_spec=(dict(payload["modelSpec"]) if isinstance(
                payload.get("modelSpec"), Mapping) else
                        payload.get("modelSpec")),
            api_key=payload.get("apiKey"),
            hf_token=payload.get("hfToken"),
            kv_cache_enabled=payload.get("kvCacheEnabled"),
            cpu_offloading_enabled=payload.get("cpuOffloadingEnabled"),
            node_id=payload.get("nodeId"),
            extra=_extras(
                payload, {
                    "modelName",
                    "userId",
                    "description",
                    "infra",
                    "modelPath",
                    "gpuCount",
                    "gpuType",
                    "modelSpec",
                    "apiKey",
                    "hfToken",
                    "kvCacheEnabled",
                    "cpuOffloadingEnabled",
                    "nodeId",
                }),
        )


@dataclass(slots=True)
class ModelCheckRequest:
    model_id: str
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({"modelId": self.model_id})
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ModelCheckRequest:
        payload = _mapping(data)
        return cls(
            model_id=str(payload["modelId"]),
            extra=_extras(payload, {"modelId"}),
        )


@dataclass(slots=True)
class CreateTicketRequest:
    subject: str
    message: str
    user_id: str | None = None
    ticket_type: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "subject": self.subject,
            "message": self.message,
            "userId": self.user_id,
            "type": self.ticket_type,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> CreateTicketRequest:
        payload = _mapping(data)
        return cls(
            subject=str(payload["subject"]),
            message=str(payload["message"]),
            user_id=payload.get("userId"),
            ticket_type=payload.get("type"),
            extra=_extras(payload, {"subject", "message", "userId", "type"}),
        )


@dataclass(slots=True)
class AttachStripePaymentMethodRequest:
    stripe_payment_method_id: str
    user_id: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "userId":
            self.user_id,
            "stripePaymentMethodId":
            self.stripe_payment_method_id,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(
        cls,
        data: Mapping[str, Any],
    ) -> AttachStripePaymentMethodRequest:
        payload = _mapping(data)
        return cls(
            stripe_payment_method_id=str(payload["stripePaymentMethodId"]),
            user_id=payload.get("userId"),
            extra=_extras(payload, {"userId", "stripePaymentMethodId"}),
        )


@dataclass(slots=True)
class CreateStripePaymentIntentRequest:
    amount: Money | Mapping[str, Any] | float | int
    user_id: str | None = None
    stripe_payment_method_id: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "userId":
            self.user_id,
            "amount":
            self.amount,
            "stripePaymentMethodId":
            self.stripe_payment_method_id,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(
        cls,
        data: Mapping[str, Any],
    ) -> CreateStripePaymentIntentRequest:
        payload = _mapping(data)
        amount = payload["amount"]
        if isinstance(amount, Mapping):
            amount = _coerce_model(amount, Money)
        return cls(
            amount=amount,
            user_id=payload.get("userId"),
            stripe_payment_method_id=payload.get("stripePaymentMethodId"),
            extra=_extras(payload,
                          {"userId", "amount", "stripePaymentMethodId"}),
        )


@dataclass(slots=True)
class ConfirmStripePaymentIntentRequest:
    stripe_payment_intent_id: str
    user_id: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "userId":
            self.user_id,
            "stripePaymentIntentId":
            self.stripe_payment_intent_id,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(
        cls,
        data: Mapping[str, Any],
    ) -> ConfirmStripePaymentIntentRequest:
        payload = _mapping(data)
        return cls(
            stripe_payment_intent_id=str(payload["stripePaymentIntentId"]),
            user_id=payload.get("userId"),
            extra=_extras(payload, {"userId", "stripePaymentIntentId"}),
        )


@dataclass(slots=True)
class CreateStripeSetupIntentRequest:
    user_id: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "userId": self.user_id,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(
        cls,
        data: Mapping[str, Any],
    ) -> CreateStripeSetupIntentRequest:
        payload = _mapping(data)
        return cls(
            user_id=payload.get("userId"),
            extra=_extras(payload, {"userId"}),
        )


@dataclass(slots=True)
class AppendTicketMessageRequest:
    message: str | ConversationMessage | Mapping[str, Any]
    user_id: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "userId":
            self.user_id,
            "message":
            _serialize_conversation_message_payload(self.message),
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> AppendTicketMessageRequest:
        payload = _mapping(data)
        message = payload["message"]
        if isinstance(message, Mapping):
            message = ConversationMessage.from_dict(message)
        return cls(
            message=message,
            user_id=payload.get("userId"),
            extra=_extras(payload, {"message", "userId"}),
        )


@dataclass(slots=True)
class SubmitReservedDeploymentRequest:
    full_name: str | None = None
    work_email: str | None = None
    company: str | None = None
    job_title: str | None = None
    preferred_gpu: str | None = None
    total_gpus_needed: str | None = None
    deployment_timeline: str | None = None
    workload_use_case: str | None = None
    networking_storage: str | None = None
    other_notes: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "fullName": self.full_name,
            "workEmail": self.work_email,
            "company": self.company,
            "jobTitle": self.job_title,
            "preferredGpu": self.preferred_gpu,
            "totalGpusNeeded": self.total_gpus_needed,
            "deploymentTimeline": self.deployment_timeline,
            "workloadUseCase": self.workload_use_case,
            "networkingStorage": self.networking_storage,
            "otherNotes": self.other_notes,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str,
                                     Any]) -> SubmitReservedDeploymentRequest:
        payload = _mapping(data)
        return cls(
            full_name=payload.get("fullName"),
            work_email=payload.get("workEmail"),
            company=payload.get("company"),
            job_title=payload.get("jobTitle"),
            preferred_gpu=payload.get("preferredGpu"),
            total_gpus_needed=payload.get("totalGpusNeeded"),
            deployment_timeline=payload.get("deploymentTimeline"),
            workload_use_case=payload.get("workloadUseCase"),
            networking_storage=payload.get("networkingStorage"),
            other_notes=payload.get("otherNotes"),
            extra=_extras(
                payload, {
                    "fullName",
                    "workEmail",
                    "company",
                    "jobTitle",
                    "preferredGpu",
                    "totalGpusNeeded",
                    "deploymentTimeline",
                    "workloadUseCase",
                    "networkingStorage",
                    "otherNotes",
                }),
        )


@dataclass(slots=True)
class CreateUserApiKeyRequest:
    user_id: str
    name: str | None = None
    scopes: list[str] | None = None
    expires_at: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "userId": self.user_id,
            "name": self.name,
            "scopes": self.scopes,
            "expiresAt": self.expires_at,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> CreateUserApiKeyRequest:
        payload = _mapping(data)
        return cls(
            user_id=str(payload["userId"]),
            name=payload.get("name"),
            scopes=(list(payload["scopes"])
                    if payload.get("scopes") is not None else None),
            expires_at=payload.get("expiresAt"),
            extra=_extras(payload, {"userId", "name", "scopes", "expiresAt"}),
        )


@dataclass(slots=True)
class ValidateModelNameRequest:
    model_name: str
    user_id: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "modelName": self.model_name,
            "userId": self.user_id,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ValidateModelNameRequest:
        payload = _mapping(data)
        return cls(
            model_name=str(payload["modelName"]),
            user_id=payload.get("userId"),
            extra=_extras(payload, {"modelName", "userId"}),
        )


@dataclass(slots=True)
class ModelChatRequest:
    body: str
    user_id: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = _serialize_optional_fields({
            "body": self.body,
            "userId": self.user_id,
        })
        data.update(self.extra)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ModelChatRequest:
        payload = _mapping(data)
        return cls(
            body=str(payload["body"]),
            user_id=payload.get("userId"),
            extra=_extras(payload, {"body", "userId"}),
        )
