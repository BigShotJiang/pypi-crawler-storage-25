from __future__ import annotations

from pathlib import Path
from typing import TypeVar
import uuid

__all__ = [
    "normalize_uuid_string",
    "resolve_ca_bundle_verify_value",
]

_ExceptionT = TypeVar("_ExceptionT", bound=Exception)


def normalize_uuid_string(
    value: str | None,
    *,
    missing_message: str,
    invalid_message: str,
    error_type: type[_ExceptionT],
) -> str:
    raw = (value or "").strip()
    if not raw:
        raise error_type(missing_message)
    try:
        return str(uuid.UUID(raw))
    except ValueError as exc:
        raise error_type(invalid_message) from exc


def resolve_ca_bundle_verify_value(
    ca_bundle: str | None,
    *,
    hint: str,
    error_type: type[_ExceptionT],
) -> bool | str:
    path_text = (ca_bundle or "").strip()
    if not path_text:
        return True

    path = Path(path_text).expanduser()
    if not path.exists():
        raise error_type(
            f"CA bundle path does not exist: {path}\nHint: {hint}")
    if not path.is_file():
        raise error_type(f"CA bundle path is not a file: {path}\nHint: {hint}")
    return str(path)
