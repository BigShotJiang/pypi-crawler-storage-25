from __future__ import annotations

from typing import Any, Mapping, Protocol

__all__ = [
    "APIConnectionError",
    "APIError",
    "ProtocolError",
    "APIStatusError",
    "APITimeoutError",
    "AuthenticationError",
    "BadRequestError",
    "ConfigurationError",
    "ConflictError",
    "InternalServerError",
    "NotFoundError",
    "PermissionDeniedError",
    "RateLimitError",
    "StreamError",
    "TensormeshError",
    "UnprocessableEntityError",
    "make_status_error",
]


class ResponseLike(Protocol):
    status_code: int
    headers: Mapping[str, str]


class TensormeshError(Exception):
    """Base class for all Tensormesh SDK errors."""


class ConfigurationError(TensormeshError):
    """Raised when client configuration is missing or invalid."""


class APIError(TensormeshError):
    """Base class for API and transport-related errors."""


class ProtocolError(APIError):
    """Raised when the API returns a malformed success payload."""


class APIConnectionError(APIError):
    """Raised when the SDK cannot reach the API."""


class APITimeoutError(APIConnectionError):
    """Raised when a request times out."""


class APIStatusError(APIError):
    """Raised when the API returns a non-success status code."""

    def __init__(
        self,
        message: str,
        *,
        response: ResponseLike,
        status_code: int,
        request_id: str | None = None,
        body: Any | None = None,
    ) -> None:
        super().__init__(message)
        self.response = response
        self.status_code = int(status_code)
        self.request_id = request_id
        self.body = body


class BadRequestError(APIStatusError):
    """Raised for HTTP 400 responses."""


class AuthenticationError(APIStatusError):
    """Raised for HTTP 401 responses."""


class PermissionDeniedError(APIStatusError):
    """Raised for HTTP 403 responses."""


class NotFoundError(APIStatusError):
    """Raised for HTTP 404 responses."""


class ConflictError(APIStatusError):
    """Raised for HTTP 409 responses."""


class UnprocessableEntityError(APIStatusError):
    """Raised for HTTP 422 responses."""


class RateLimitError(APIStatusError):
    """Raised for HTTP 429 responses."""


class InternalServerError(APIStatusError):
    """Raised for HTTP 5xx responses."""


class StreamError(APIError):
    """Raised when a streamed response cannot be decoded or contains an error."""


def make_status_error(
    *,
    response: ResponseLike,
    message: str,
    body: Any | None = None,
) -> APIStatusError:
    request_id = response.headers.get("x-request-id") or response.headers.get(
        "X-Request-Id")
    status_code = int(response.status_code)

    error_cls: type[APIStatusError]
    if status_code == 400:
        error_cls = BadRequestError
    elif status_code == 401:
        error_cls = AuthenticationError
    elif status_code == 403:
        error_cls = PermissionDeniedError
    elif status_code == 404:
        error_cls = NotFoundError
    elif status_code == 409:
        error_cls = ConflictError
    elif status_code == 422:
        error_cls = UnprocessableEntityError
    elif status_code == 429:
        error_cls = RateLimitError
    elif status_code >= 500:
        error_cls = InternalServerError
    else:
        error_cls = APIStatusError

    return error_cls(
        message,
        response=response,
        status_code=status_code,
        request_id=request_id,
        body=body,
    )
