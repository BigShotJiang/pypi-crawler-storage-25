from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Literal, Mapping

import requests

from ._auth import ClientConfig
from ._auth import normalize_on_demand_user_id
from ._auth import resolve_client_config
from ._client_shared import default_json_headers
from ._client_shared import find_header_key_case_insensitive
from ._client_shared import require_control_plane_token
from ._client_shared import require_inference_api_key
from ._client_shared import require_on_demand_base_url
from ._client_shared import resolve_on_demand_user_id
from ._client_shared import setdefault_header_case_insensitive
from ._client_shared import setdefault_header_case_insensitive_lazy
from ._constants import DEFAULT_SERVERLESS_BASE_URL
from ._constants import DEFAULT_STREAM_READ_TIMEOUT_SECONDS
from ._exceptions import ConfigurationError
from ._transport import build_url
from ._transport import SyncTransport
from .resources.control_plane import ActivitiesClient
from .resources.control_plane import AdminClient
from .resources.control_plane import BillingClient
from .resources.control_plane import ModelsClient as ControlPlaneModelsClient
from .resources.control_plane import ObservabilityClient
from .resources.control_plane import ProductsClient
from .resources.control_plane import SupportClient
from .resources.control_plane import UsersClient
from .resources.inference import ChatNamespace
from .resources.inference import DetokenizeClient
from .resources.inference import HealthClient
from .resources.inference import ModelsClient as InferenceModelsClient
from .resources.inference import ResponsesClient
from .resources.inference import TextCompletionsClient
from .resources.inference import TokenizeClient
from .resources.inference import VersionClient

__all__ = ["Tensormesh"]


class Tensormesh:
    """Synchronous Tensormesh client."""

    def __init__(
        self,
        *,
        control_plane_token: str | None = None,
        control_plane_base_url: str | None = None,
        inference_api_key: str | None = None,
        serverless_base_url: str | None = None,
        on_demand_base_url: str | None = None,
        on_demand_user_id: str | None = None,
        timeout: float | None = None,
        max_retries: int | None = None,
        ca_bundle: str | None = None,
        env: Mapping[str, str] | None = None,
        _transport: SyncTransport | None = None,
    ) -> None:
        self._config = resolve_client_config(
            control_plane_token=control_plane_token,
            control_plane_base_url=control_plane_base_url,
            inference_api_key=inference_api_key,
            serverless_base_url=serverless_base_url,
            on_demand_base_url=on_demand_base_url,
            on_demand_user_id=on_demand_user_id,
            timeout=timeout,
            max_retries=max_retries,
            ca_bundle=ca_bundle,
            env=env,
        )
        self._transport = _transport or SyncTransport(
            verify=self._config.verify,
            timeout_seconds=self._config.timeout_seconds,
            max_retries=self._config.max_retries,
        )
        self.control_plane = ControlPlaneClient(self)
        self.inference = InferenceClient(self)

    @property
    def config(self) -> ClientConfig:
        return self._config

    def close(self) -> None:
        self._transport.close()

    def __enter__(self) -> Tensormesh:
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: object | None,
    ) -> None:
        self.close()

    def _request(
        self,
        *,
        method: str,
        url: str,
        headers: Mapping[str, str] | None = None,
        params: Mapping[str, object] | None = None,
        json_body: Any | None = None,
        timeout: float | None = None,
        idempotent: bool | None = None,
        status_hints: Mapping[int, str] | None = None,
        error_context: Mapping[str, str] | None = None,
    ) -> requests.Response:
        return self._transport.request(
            method,
            url,
            headers=headers,
            params=params,
            json_body=json_body,
            timeout_s=timeout,
            idempotent=idempotent,
            status_hints=status_hints,
            error_context=error_context,
        )

    def _stream_request(
        self,
        *,
        method: str,
        url: str,
        headers: Mapping[str, str] | None = None,
        params: Mapping[str, object] | None = None,
        json_body: Any | None = None,
        timeout: float | None = None,
        read_timeout: float | None = None,
        status_hints: Mapping[int, str] | None = None,
        error_context: Mapping[str, str] | None = None,
    ) -> requests.Response:
        return self._transport.request_stream(
            method,
            url,
            headers=headers,
            params=params,
            json_body=json_body,
            timeout_s=timeout,
            read_timeout_s=read_timeout,
            status_hints=status_hints,
            error_context=error_context,
        )


class ControlPlaneClient:

    def __init__(self, client: Tensormesh) -> None:
        self._client = client
        self.activities = ActivitiesClient(self)
        self.admin = AdminClient(self)
        self.billing = BillingClient(self)
        self.models = ControlPlaneModelsClient(self)
        self.observability = ObservabilityClient(self)
        self.products = ProductsClient(self)
        self.support = SupportClient(self)
        self.users = UsersClient(self)

    def request(
        self,
        method: str,
        path: str,
        *,
        params: Mapping[str, object] | None = None,
        json_body: Any | None = None,
        headers: Mapping[str, str] | None = None,
        timeout: float | None = None,
    ) -> requests.Response:
        request_headers = default_json_headers(
            json_body=json_body,
            headers=headers,
        )
        setdefault_header_case_insensitive_lazy(
            request_headers,
            "Authorization",
            lambda:
            f"Bearer {require_control_plane_token(self._client.config)}",
        )
        url = build_url(self._client.config.control_plane_base_url, path)
        return self._client._request(
            method=method,
            url=url,
            headers=request_headers,
            params=params,
            json_body=json_body,
            timeout=timeout,
            error_context={"url": url},
        )


class InferenceClient:

    def __init__(self, client: Tensormesh) -> None:
        self.serverless = ServerlessInferenceClient(client)
        self.on_demand = OnDemandInferenceClient(client)


@dataclass(frozen=True)
class _InferenceSurfacePolicy:
    base_url_kind: Literal["serverless", "on_demand"]
    requires_user_id: bool
    public_get_paths: frozenset[str]


class _BaseOpenAIInferenceSurface:

    def __init__(
        self,
        client: Tensormesh,
        *,
        policy: _InferenceSurfacePolicy,
    ) -> None:
        self._client = client
        self._policy = policy
        self.chat = ChatNamespace(self)
        self.models = InferenceModelsClient(self)
        self.completions = TextCompletionsClient(self)
        self.responses = ResponsesClient(self)
        self.tokenize = TokenizeClient(self)
        self.detokenize = DetokenizeClient(self)
        self.health = HealthClient(self)
        self.version = VersionClient(self)

    @staticmethod
    def _reject_user_id(user_id: str | None) -> None:
        if user_id is not None:
            raise ConfigurationError(
                "Serverless inference does not accept `user_id`. Pass `user_id` only for on-demand inference."
            )

    def _prepare_request(
        self,
        *,
        method: str,
        path: str,
        headers: Mapping[str, str] | None,
        json_body: Any | None,
        user_id: str | None,
    ) -> tuple[dict[str, str], str]:
        request_headers = default_json_headers(
            json_body=json_body,
            headers=headers,
        )
        if self._policy.base_url_kind == "serverless":
            self._reject_user_id(user_id)
            self._set_serverless_authorization_header(
                request_headers,
                method=method,
                path=path,
            )
            return request_headers, self._client.config.serverless_base_url

        header_user_id_key = find_header_key_case_insensitive(
            request_headers, "X-User-Id")
        header_has_user_id = header_user_id_key is not None
        base_url = require_on_demand_base_url(
            self._client.config,
            has_user_id=header_has_user_id or bool(user_id),
        )
        normalized_user_id = None
        if header_user_id_key is not None:
            request_headers[header_user_id_key] = normalize_on_demand_user_id(
                request_headers[header_user_id_key])
        else:
            normalized_user_id = resolve_on_demand_user_id(
                self._client.config,
                user_id,
            )

        setdefault_header_case_insensitive_lazy(
            request_headers,
            "Authorization",
            lambda: f"Bearer {require_inference_api_key(self._client.config)}",
        )
        if normalized_user_id is not None:
            setdefault_header_case_insensitive(
                request_headers,
                "X-User-Id",
                normalized_user_id,
            )
        return request_headers, base_url

    def _set_serverless_authorization_header(
        self,
        request_headers: dict[str, str],
        *,
        method: str,
        path: str,
    ) -> None:
        if find_header_key_case_insensitive(request_headers,
                                            "Authorization") is not None:
            return
        api_key = self._client.config.inference_api_key
        if api_key:
            request_headers["Authorization"] = f"Bearer {api_key}"
            return
        if (self._client.config.serverless_base_url
                == DEFAULT_SERVERLESS_BASE_URL and method.upper() == "GET"
                and path in self._policy.public_get_paths):
            return
        request_headers["Authorization"] = (
            f"Bearer {require_inference_api_key(self._client.config)}")

    def request(
        self,
        method: str,
        path: str,
        *,
        params: Mapping[str, object] | None = None,
        json_body: Any | None = None,
        headers: Mapping[str, str] | None = None,
        timeout: float | None = None,
        user_id: str | None = None,
    ) -> requests.Response:
        request_headers, base_url = self._prepare_request(
            method=method,
            path=path,
            headers=headers,
            json_body=json_body,
            user_id=user_id,
        )
        url = build_url(base_url, path)
        return self._client._request(
            method=method,
            url=url,
            headers=request_headers,
            params=params,
            json_body=json_body,
            timeout=timeout,
            error_context={"url": url},
        )

    def stream_request(
        self,
        method: str,
        path: str,
        *,
        params: Mapping[str, object] | None = None,
        json_body: Any | None = None,
        headers: Mapping[str, str] | None = None,
        timeout: float | None = None,
        read_timeout: float | None = None,
        user_id: str | None = None,
    ) -> requests.Response:
        request_headers, base_url = self._prepare_request(
            method=method,
            path=path,
            headers=headers,
            json_body=json_body,
            user_id=user_id,
        )
        url = build_url(base_url, path)
        return self._client._stream_request(
            method=method,
            url=url,
            headers=request_headers,
            params=params,
            json_body=json_body,
            timeout=timeout,
            read_timeout=read_timeout or DEFAULT_STREAM_READ_TIMEOUT_SECONDS,
            error_context={"url": url},
        )


class ServerlessInferenceClient(_BaseOpenAIInferenceSurface):
    _PUBLIC_GET_PATHS = frozenset({
        "/v1/models",
        "/health",
        "/version",
    })

    def __init__(self, client: Tensormesh) -> None:
        super().__init__(
            client,
            policy=_InferenceSurfacePolicy(
                base_url_kind="serverless",
                requires_user_id=False,
                public_get_paths=self._PUBLIC_GET_PATHS,
            ),
        )


class OnDemandInferenceClient(_BaseOpenAIInferenceSurface):

    def __init__(self, client: Tensormesh) -> None:
        super().__init__(
            client,
            policy=_InferenceSurfacePolicy(
                base_url_kind="on_demand",
                requires_user_id=True,
                public_get_paths=frozenset(),
            ),
        )
