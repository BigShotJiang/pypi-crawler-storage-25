from __future__ import annotations

from dataclasses import dataclass
import os
from typing import Mapping

from ._constants import DEFAULT_CONTROL_PLANE_BASE_URL
from ._constants import DEFAULT_MAX_RETRIES
from ._constants import DEFAULT_SERVERLESS_BASE_URL
from ._constants import DEFAULT_TIMEOUT_SECONDS
from ._constants import ENV_CA_BUNDLE
from ._constants import ENV_CONTROL_PLANE_BASE_URL
from ._constants import ENV_CONTROL_PLANE_TOKEN
from ._constants import ENV_INFERENCE_API_KEY
from ._constants import ENV_MAX_RETRIES
from ._constants import ENV_ON_DEMAND_BASE_URL
from ._constants import ENV_ON_DEMAND_USER_ID
from ._constants import ENV_SERVERLESS_BASE_URL
from ._constants import ENV_TIMEOUT_SECONDS
from ._exceptions import ConfigurationError
from ._transport import resolve_timeout_s
from ._validation import normalize_uuid_string
from ._validation import resolve_ca_bundle_verify_value

__all__ = [
    "ClientConfig",
    "missing_control_plane_token_message",
    "missing_inference_api_key_message",
    "missing_on_demand_base_url_message",
    "missing_on_demand_user_id_message",
    "normalize_on_demand_user_id",
    "resolve_client_config",
    "resolve_verify_value",
]


@dataclass(frozen=True)
class ClientConfig:
    control_plane_token: str | None
    control_plane_base_url: str
    inference_api_key: str | None
    serverless_base_url: str
    on_demand_base_url: str | None
    on_demand_user_id: str | None
    timeout_seconds: float
    max_retries: int
    ca_bundle: str | None
    verify: bool | str


def _clean_optional_string(value: object | None) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def _normalize_base_url(
    value: str | None,
    *,
    label: str,
    required: bool,
) -> str | None:
    text = _clean_optional_string(value)
    if text is None:
        if required:
            raise ConfigurationError(f"{label} must be a non-empty string.")
        return None
    return text.rstrip("/")


def _resolve_raw_value(
    explicit: object | None,
    env: Mapping[str, str],
    env_key: str,
    *,
    default: object | None = None,
) -> object | None:
    if explicit is not None:
        return explicit
    if env_key in env:
        return env[env_key]
    return default


def _resolve_base_url(
    explicit: str | None,
    env: Mapping[str, str],
    env_key: str,
    *,
    default: str | None = None,
    label: str,
    required: bool,
) -> str | None:
    if explicit is not None:
        raw_value: object | None = explicit
    elif env_key in env:
        raw_value = env[env_key]
        if _clean_optional_string(raw_value) is None:
            raw_value = default
    else:
        raw_value = default

    return _normalize_base_url(
        _clean_optional_string(raw_value),
        label=label,
        required=required,
    )


def _resolve_int(
    explicit: int | None,
    env: Mapping[str, str],
    env_key: str,
    *,
    default: int,
) -> int:
    if explicit is not None:
        raw: object | None = explicit
    elif env_key in env:
        cleaned = _clean_optional_string(env[env_key])
        raw = default if cleaned is None else cleaned
    else:
        raw = default
    try:
        value = int(raw)
    except (TypeError, ValueError) as exc:
        raise ConfigurationError(
            f"{env_key} must be an integer when provided.") from exc
    if value < 0:
        raise ConfigurationError(
            f"{env_key} must be greater than or equal to 0.")
    return value


def normalize_on_demand_user_id(value: str) -> str:
    return normalize_uuid_string(
        value,
        missing_message=("On-demand user id is required. Set "
                         f"`on_demand_user_id` or {ENV_ON_DEMAND_USER_ID}."),
        invalid_message=
        "Invalid on-demand user id. `X-User-Id` must be a UUID.",
        error_type=ConfigurationError,
    )


def missing_control_plane_token_message() -> str:
    return ("Missing control plane token. Set `control_plane_token` or "
            "`TENSORMESH_CONTROL_PLANE_TOKEN`.")


def missing_inference_api_key_message() -> str:
    return ("Missing inference API key. Set `inference_api_key` or "
            "`TENSORMESH_INFERENCE_API_KEY`.")


def missing_on_demand_base_url_message(*, has_user_id: bool) -> str:
    message = ("Missing on-demand base URL. Set `on_demand_base_url` or "
               "`TENSORMESH_ON_DEMAND_BASE_URL`.")
    if has_user_id:
        message += (
            "\nHint: on-demand inference requires both a base URL and user id; "
            "a user id is already configured.")
    return message


def missing_on_demand_user_id_message(*, has_base_url: bool) -> str:
    message = (
        "Missing on-demand user id. Set `on_demand_user_id`, pass `user_id` "
        "on the request, or set `TENSORMESH_ON_DEMAND_USER_ID`.")
    if has_base_url:
        message += (
            "\nHint: on-demand inference requires both a base URL and user id; "
            "a base URL is already configured.")
    return message


def resolve_verify_value(ca_bundle: str | None) -> bool | str:
    return resolve_ca_bundle_verify_value(
        ca_bundle,
        hint=f"set `ca_bundle` or {ENV_CA_BUNDLE} to a readable PEM file.",
        error_type=ConfigurationError,
    )


def resolve_client_config(
    *,
    control_plane_token: str | None = None,
    control_plane_base_url: str | None = None,
    inference_api_key: str | None = None,
    serverless_base_url: str | None = None,
    on_demand_base_url: str | None = None,
    on_demand_user_id: str | None = None,
    timeout: float | None = None,
    max_retries: int | None = None,
    ca_bundle: str | None = None,
    env: Mapping[str, str] | None = None,
) -> ClientConfig:
    env_map = dict(os.environ if env is None else env)

    resolved_control_plane_token = _clean_optional_string(
        _resolve_raw_value(control_plane_token, env_map,
                           ENV_CONTROL_PLANE_TOKEN))
    resolved_control_plane_base_url = _resolve_base_url(
        control_plane_base_url,
        env_map,
        ENV_CONTROL_PLANE_BASE_URL,
        default=DEFAULT_CONTROL_PLANE_BASE_URL,
        label="control_plane_base_url",
        required=True,
    )
    resolved_inference_api_key = _clean_optional_string(
        _resolve_raw_value(inference_api_key, env_map, ENV_INFERENCE_API_KEY))
    resolved_serverless_base_url = _resolve_base_url(
        serverless_base_url,
        env_map,
        ENV_SERVERLESS_BASE_URL,
        default=DEFAULT_SERVERLESS_BASE_URL,
        label="serverless_base_url",
        required=True,
    )
    resolved_on_demand_base_url = _resolve_base_url(
        on_demand_base_url,
        env_map,
        ENV_ON_DEMAND_BASE_URL,
        label="on_demand_base_url",
        required=False,
    )

    raw_user_id = _clean_optional_string(
        _resolve_raw_value(on_demand_user_id, env_map, ENV_ON_DEMAND_USER_ID))
    if on_demand_user_id is not None:
        resolved_on_demand_user_id = (normalize_on_demand_user_id(raw_user_id)
                                      if raw_user_id is not None else None)
    else:
        resolved_on_demand_user_id = raw_user_id

    resolved_timeout_seconds = resolve_timeout_s(
        timeout_s=timeout,
        configured_timeout_s=_clean_optional_string(
            _resolve_raw_value(None,
                               env_map,
                               ENV_TIMEOUT_SECONDS,
                               default=DEFAULT_TIMEOUT_SECONDS)),
        default_timeout_s=DEFAULT_TIMEOUT_SECONDS,
    )
    resolved_max_retries = _resolve_int(max_retries,
                                        env_map,
                                        ENV_MAX_RETRIES,
                                        default=DEFAULT_MAX_RETRIES)
    resolved_ca_bundle = _clean_optional_string(
        _resolve_raw_value(ca_bundle, env_map, ENV_CA_BUNDLE))

    return ClientConfig(
        control_plane_token=resolved_control_plane_token,
        control_plane_base_url=resolved_control_plane_base_url,
        inference_api_key=resolved_inference_api_key,
        serverless_base_url=resolved_serverless_base_url,
        on_demand_base_url=resolved_on_demand_base_url,
        on_demand_user_id=resolved_on_demand_user_id,
        timeout_seconds=resolved_timeout_seconds,
        max_retries=resolved_max_retries,
        ca_bundle=resolved_ca_bundle,
        verify=resolve_verify_value(resolved_ca_bundle),
    )
