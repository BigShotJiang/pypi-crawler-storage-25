from __future__ import annotations

from collections.abc import Callable
from collections.abc import Mapping
from typing import Any

from ._auth import ClientConfig
from ._auth import missing_control_plane_token_message
from ._auth import missing_inference_api_key_message
from ._auth import missing_on_demand_base_url_message
from ._auth import missing_on_demand_user_id_message
from ._auth import normalize_on_demand_user_id
from ._exceptions import ConfigurationError


def has_header_key(headers: Mapping[str, str], key: str) -> bool:
    wanted = key.lower()
    return any(existing.lower() == wanted for existing in headers)


def find_header_key_case_insensitive(
    headers: Mapping[str, str],
    key: str,
) -> str | None:
    wanted = key.lower()
    for existing in headers:
        if existing.lower() == wanted:
            return existing
    return None


def setdefault_header_case_insensitive(
    headers: dict[str, str],
    key: str,
    value: str,
) -> None:
    if not has_header_key(headers, key):
        headers[key] = value


def setdefault_header_case_insensitive_lazy(
    headers: dict[str, str],
    key: str,
    value_factory: Callable[[], str],
) -> None:
    if not has_header_key(headers, key):
        headers[key] = value_factory()


def default_json_headers(
    *,
    json_body: Any | None,
    headers: Mapping[str, str] | None,
) -> dict[str, str]:
    merged = dict(headers or {})
    if json_body is not None and not has_header_key(merged, "Content-Type"):
        merged["Content-Type"] = "application/json"
    return merged


def require_control_plane_token(config: ClientConfig) -> str:
    token = config.control_plane_token
    if token is None:
        raise ConfigurationError(missing_control_plane_token_message())
    return token


def require_inference_api_key(config: ClientConfig) -> str:
    api_key = config.inference_api_key
    if api_key is None:
        raise ConfigurationError(missing_inference_api_key_message())
    return api_key


def require_on_demand_base_url(
    config: ClientConfig,
    *,
    has_user_id: bool,
) -> str:
    base_url = config.on_demand_base_url
    if base_url is None:
        raise ConfigurationError(
            missing_on_demand_base_url_message(
                has_user_id=has_user_id or bool(config.on_demand_user_id)))
    return base_url


def resolve_on_demand_user_id(
    config: ClientConfig,
    user_id: str | None,
) -> str:
    resolved_user_id = user_id or config.on_demand_user_id
    if resolved_user_id is None:
        raise ConfigurationError(
            missing_on_demand_user_id_message(
                has_base_url=bool(config.on_demand_base_url)))
    return normalize_on_demand_user_id(resolved_user_id)
