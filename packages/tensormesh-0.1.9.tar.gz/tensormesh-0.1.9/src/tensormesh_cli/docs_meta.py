from __future__ import annotations

from dataclasses import dataclass
from dataclasses import field
from typing import cast

import click

__all__ = [
    "CommandDocsMeta",
    "CommandExampleMeta",
    "attach_command_docs",
    "get_command_docs",
]


@dataclass(frozen=True)
class CommandExampleMeta:
    command: str
    description: str


@dataclass(frozen=True)
class CommandDocsMeta:
    summary: str | None = None
    overview_title: str | None = None
    overview_markdown: str | None = None
    examples: list[CommandExampleMeta] = field(default_factory=list)
    auth_scope: list[str] = field(default_factory=list)
    env_vars: list[str] = field(default_factory=list)
    prerequisites: list[str] = field(default_factory=list)
    caveats: list[str] = field(default_factory=list)
    related_commands: list[str] = field(default_factory=list)


def _render_help_epilog(metadata: CommandDocsMeta) -> str:
    sections: list[str] = []
    if metadata.examples:
        sections.append("Examples:")
        for example in metadata.examples:
            sections.append(f"  {example.command}")
            sections.append(f"    {example.description}")
    if metadata.auth_scope:
        if sections:
            sections.append("")
        sections.append("Auth scope:")
        sections.extend(f"  - {item}" for item in metadata.auth_scope)
    if metadata.env_vars:
        if sections:
            sections.append("")
        sections.append("Environment variables:")
        sections.extend(f"  - {item}" for item in metadata.env_vars)
    if metadata.prerequisites:
        if sections:
            sections.append("")
        sections.append("Prerequisites:")
        sections.extend(f"  - {item}" for item in metadata.prerequisites)
    if metadata.caveats:
        if sections:
            sections.append("")
        sections.append("Caveats:")
        sections.extend(f"  - {item}" for item in metadata.caveats)
    if metadata.related_commands:
        if sections:
            sections.append("")
        sections.append("Related commands:")
        sections.extend(f"  - {item}" for item in metadata.related_commands)
    return "\n".join(sections).strip()


def attach_command_docs(
    command: click.Command,
    *,
    summary: str | None = None,
    overview_title: str | None = None,
    overview_markdown: str | None = None,
    examples: list[CommandExampleMeta] | None = None,
    auth_scope: list[str] | None = None,
    env_vars: list[str] | None = None,
    prerequisites: list[str] | None = None,
    caveats: list[str] | None = None,
    related_commands: list[str] | None = None,
) -> click.Command:
    metadata = CommandDocsMeta(
        summary=summary,
        overview_title=overview_title,
        overview_markdown=overview_markdown,
        examples=list(examples or []),
        auth_scope=list(auth_scope or []),
        env_vars=list(env_vars or []),
        prerequisites=list(prerequisites or []),
        caveats=list(caveats or []),
        related_commands=list(related_commands or []),
    )
    command._tm_docs_meta = metadata  # type: ignore[attr-defined]
    if metadata.summary and not command.short_help:
        command.short_help = metadata.summary
    rendered_epilog = _render_help_epilog(metadata)
    if rendered_epilog:
        existing_epilog = (command.epilog or "").strip()
        command.epilog = (f"{existing_epilog}\n\n{rendered_epilog}".strip()
                          if existing_epilog else rendered_epilog)
    return command


def get_command_docs(command: click.Command) -> CommandDocsMeta | None:
    value = getattr(command, "_tm_docs_meta", None)
    if isinstance(value, CommandDocsMeta):
        return cast(CommandDocsMeta, value)
    return None
