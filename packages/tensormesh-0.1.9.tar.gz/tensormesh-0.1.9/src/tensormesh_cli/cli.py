from __future__ import annotations

import os

import click

from . import __version__
from .app_context import build_pending_app_context
from .commands.activities_cmd import activities_group
from .commands.admin_cmd import admin_group
from .commands.auth_cmd import auth_group
from .commands.billing_cmd import billing_group
from .commands.completion_cmd import completion_cmd
from .commands.config_cmd import config_group
from .commands.doctor_cmd import doctor_cmd
from .commands.infer_cmd import infer_group
from .commands.init_cmd import init_cmd
from .commands.logs_cmd import logs_cmd
from .commands.metrics_cmd import metrics_group
from .commands.models_cmd import models_group
from .commands.products_cmd import products_group
from .commands.reserved_deployments_cmd import reserved_deployments_group
from .commands.tickets_cmd import tickets_group
from .commands.users_cmd import users_group
from .commands.version_cmd import version_cmd
from .config.constants import ENV_CA_BUNDLE
from .config.constants import ENV_CONFIG_HOME
from .config.constants import ENV_MAX_RETRIES
from .config.constants import ENV_TIMEOUT_SECONDS
from .config.constants import GATEWAY_PROVIDER_NAMES
from .config.paths import default_config_path
from .config.paths import default_config_path_display
from .docs_meta import attach_command_docs
from .docs_meta import CommandExampleMeta

_GATEWAY_PROVIDER_TEXT = ", ".join(GATEWAY_PROVIDER_NAMES)
_IMPORTED_DEFAULT_CONFIG_PATH = str(default_config_path())
_DEFAULT_CONFIG_PATH_TEXT = default_config_path_display()


@click.group(
    help="Tensormesh CLI for Control Plane and Inference API workflows.",
    epilog=
    ("Config precedence: flags > env > config.toml ([overrides] before [managed]) > defaults.\n"
     "\n"
     "Standard persistent setup:\n"
     "  tm auth login\n"
     "  tm init --sync\n"
     "  # updates [managed] in the active config.toml state root\n"
     "\n"
     "Global options such as --output must come before the subcommand:\n"
     "  tm --output json auth status\n"
     "\n"
     "Gateway credentials (gateway_api_key, gateway_user_id, gateway_model_id) have no\n"
     "environment variable equivalents. Set them in [overrides] in config.toml or use\n"
     "tm init --sync to sync [managed]. Control Plane auth uses auth.json under the\n"
     "active state root; inference commands normally read gateway credentials from [managed].\n"
     "\n"
     "Quickstart:\n"
     "  tm auth login\n"
     "  tm init --sync\n"
     "  tm auth status\n"
     "  tm infer chat --json '[{\"role\":\"user\",\"content\":\"hi\"}]'\n"),
    context_settings={"help_option_names": ["-h", "--help"]},
)
@click.version_option(__version__, "--version", "-V", prog_name="tm")
@click.option(
    "--config",
    "config_path",
    type=click.Path(dir_okay=False, path_type=str),
    default=_IMPORTED_DEFAULT_CONFIG_PATH,
    show_default=True,
    help="Path to config TOML file",
)
@click.option(
    "--output",
    "output",
    type=click.Choice(["text", "json", "yaml", "raw", "table"],
                      case_sensitive=False),
    default="text",
    show_default=True,
    help="Output format (text is human-readable; json is machine-friendly).",
)
@click.option("--quiet",
              is_flag=True,
              default=False,
              help="Suppress non-essential output.")
@click.option("--debug",
              is_flag=True,
              default=False,
              help="Print debug logs to stderr (secrets redacted).")
@click.option(
    "--ca-bundle",
    "ca_bundle",
    type=click.Path(dir_okay=False, path_type=str),
    default=None,
    help=
    f"Path to a PEM CA bundle for TLS verification (overrides {ENV_CA_BUNDLE}).",
)
@click.option(
    "--timeout",
    "timeout_s",
    type=float,
    default=None,
    help=
    f"Default HTTP timeout in seconds (overrides {ENV_TIMEOUT_SECONDS}; subcommands may override).",
)
@click.option(
    "--max-retries",
    "max_retries",
    type=int,
    default=None,
    help=
    f"Max retries for idempotent HTTP requests on transient errors (overrides {ENV_MAX_RETRIES}; subcommands may override).",
)
@click.option(
    "--controlplane-base",
    "controlplane_base",
    default=None,
    help="Override the Control Plane base URL.",
)
@click.option(
    "--gateway-provider",
    "gateway_provider",
    default=None,
    help=
    f"Inference Gateway provider for built-in host selection ({_GATEWAY_PROVIDER_TEXT}).",
)
@click.pass_context
def cli(
    ctx: click.Context,
    config_path: str,
    output: str,
    quiet: bool,
    debug: bool,
    ca_bundle: str | None,
    timeout_s: float | None,
    max_retries: int | None,
    controlplane_base: str | None,
    gateway_provider: str | None,
) -> None:
    env_map = dict(os.environ)
    effective_config_path = config_path
    if config_path == _IMPORTED_DEFAULT_CONFIG_PATH:
        effective_config_path = str(default_config_path())
    ctx.obj = build_pending_app_context(
        env=env_map,
        config_path=effective_config_path,
        output=output,
        quiet=quiet,
        debug=debug,
        controlplane_base=controlplane_base,
        ca_bundle=ca_bundle,
        timeout_seconds=timeout_s,
        max_retries=max_retries,
        gateway_provider=gateway_provider,
    )


cli = attach_command_docs(
    cli,
    summary="Tensormesh command-line interface.",
    overview_title="Before You Use `tm`",
    overview_markdown=
    ("- Install the CLI first if `tm` is not already on your `PATH`. In this repo checkout, use `./.venv/bin/tm` until your shell already exposes `tm`.\n"
     "- Start with `tm init` if you are not sure what is already configured locally.\n"
     "- Use `tm auth login` followed by `tm init --sync` for the standard persistent On-Demand setup flow.\n"
     "- Put global options such as `--output json` before the subcommand.\n"
     f"- Set `{ENV_CONFIG_HOME}` when you need an alternate config and auth root for local scripting.\n"
     "- Use `tm auth status`, `tm infer doctor`, and `tm doctor` for local readiness checks.\n"
     "- Use `tm auth whoami` for a live Control Plane auth check and `tm infer chat` for an end-to-end inference check."
     ),
    env_vars=[
        ENV_CA_BUNDLE,
        ENV_TIMEOUT_SECONDS,
        ENV_MAX_RETRIES,
        ENV_CONFIG_HOME,
    ],
    examples=[
        CommandExampleMeta(
            command="tm init",
            description=
            "Inspect local setup and print the shortest path to a working request.",
        ),
        CommandExampleMeta(
            command="tm infer doctor",
            description="Inspect gateway readiness before the first request.",
        ),
        CommandExampleMeta(
            command="tm auth status",
            description="Inspect local Control Plane and inference auth state.",
        ),
        CommandExampleMeta(
            command=
            "tm infer chat --json '[{\"role\":\"user\",\"content\":\"hi\"}]'",
            description=
            "Send a basic chat request after the standard On-Demand setup flow.",
        ),
    ],
    related_commands=["tm init", "tm config show", "tm doctor"],
)

cli.add_command(auth_group)
cli.add_command(init_cmd)
cli.add_command(admin_group)
cli.add_command(billing_group)
cli.add_command(doctor_cmd)
cli.add_command(completion_cmd)
cli.add_command(models_group)
cli.add_command(activities_group)
cli.add_command(products_group)
cli.add_command(reserved_deployments_group)
cli.add_command(tickets_group)
cli.add_command(users_group)
cli.add_command(logs_cmd)
cli.add_command(metrics_group)
cli.add_command(config_group)
cli.add_command(infer_group)
cli.add_command(version_cmd)
