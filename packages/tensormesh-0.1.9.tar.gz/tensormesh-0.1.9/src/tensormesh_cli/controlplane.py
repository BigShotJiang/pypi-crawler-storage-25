from __future__ import annotations

from pathlib import Path
from typing import Any, Mapping

import click

from tensormesh import ConfigurationError
from tensormesh import Tensormesh
from tensormesh.types import User
from tensormesh_cli import auth
from tensormesh_cli.app_context import AppContext
from tensormesh_cli.app_context import build_request_runtime
from tensormesh_cli.app_context import get_app_context
from tensormesh_cli.http.context_request import RequestConfigError
from tensormesh_cli.http.context_request import RequestExecutionError
from tensormesh_cli.http.gateway import normalize_gateway_user_id
from tensormesh_cli.http.sdk_response import BufferedResponseJSONError
from tensormesh_cli.http.sdk_response import SDKBufferedResponse
from tensormesh_cli.http.sdk_transport import \
    ControlPlaneSDKTransport as _CLIControlPlaneSDKTransport

__all__ = [
    "build_controlplane_sdk_client",
    "execute_controlplane_sdk",
    "has_controlplane_access_token",
    "resolve_gateway_user_id_from_controlplane",
    "resolve_controlplane_access_token",
]


def build_controlplane_sdk_client(
    ctx: click.Context,
    *,
    status_hints: Mapping[int, str] | None = None,
) -> tuple[Tensormesh, _CLIControlPlaneSDKTransport]:
    app = get_app_context(ctx)
    try:
        runtime = build_request_runtime(app)
    except RequestConfigError as exc:
        raise click.UsageError(str(exc), ctx=ctx) from exc

    transport = _CLIControlPlaneSDKTransport(
        runtime=runtime,
        status_hints=status_hints
        or {401: "run `tm auth login` to authenticate to the control plane."},
    )

    try:
        client = Tensormesh(
            control_plane_token=resolve_controlplane_access_token(ctx),
            control_plane_base_url=app.controlplane_base,
            env={},
            _transport=transport,
        )
    except ConfigurationError as exc:
        raise click.UsageError(str(exc), ctx=ctx) from exc
    return client, transport


def execute_controlplane_sdk(
    ctx: click.Context,
    action: Any,
    *,
    status_hints: Mapping[int, str] | None = None,
) -> tuple[Any, SDKBufferedResponse | None]:
    client, transport = build_controlplane_sdk_client(
        ctx,
        status_hints=status_hints,
    )
    try:
        result = action(client)
    except RequestConfigError as exc:
        raise click.UsageError(str(exc), ctx=ctx) from exc
    except RequestExecutionError as exc:
        raise click.ClickException(str(exc)) from exc
    except BufferedResponseJSONError as exc:
        raise click.ClickException(
            f"Invalid JSON response: expected JSON. Raw response: {exc.raw}"
        ) from exc
    return result, transport.last_buffered_response


def _load_controlplane_access_token(app: AppContext) -> str | None:
    auth_json_path = str(app.controlplane_auth_json or "").strip()
    if not auth_json_path:
        return None

    token = (auth.access_token(Path(auth_json_path).expanduser())
             or "").strip()
    return token or None


def has_controlplane_access_token(ctx: click.Context) -> bool:
    try:
        return _load_controlplane_access_token(
            get_app_context(ctx)) is not None
    except RuntimeError:
        return False


def resolve_controlplane_access_token(ctx: click.Context) -> str:
    try:
        token = _load_controlplane_access_token(get_app_context(ctx))
    except RuntimeError as exc:
        raise click.ClickException(str(exc)) from exc
    if not token:
        raise click.UsageError(
            "No control plane access token found. Run `tm auth login` first.",
            ctx=ctx,
        )
    return token


def resolve_gateway_user_id_from_controlplane(
    ctx: click.Context,
    *,
    timeout_s: float | None = None,
) -> str:
    try:
        profile, _ = execute_controlplane_sdk(
            ctx,
            lambda client: client.control_plane.users.get_auth_profile(
                timeout=timeout_s),
        )
    except click.UsageError:
        raise
    except click.ClickException as exc:
        raise click.ClickException(
            "Failed to derive gateway user id from the control plane profile.\n"
            f"{exc.message}") from exc

    if profile is None:
        raise click.ClickException(
            "Failed to derive gateway user id from the control plane profile.\n"
            "Missing user profile in GET /auth/profile response.")

    if not isinstance(profile, User):
        raise click.ClickException(
            "Failed to derive gateway user id from the control plane profile.\n"
            "Unexpected user profile object returned by the SDK.")

    user_id = (profile.id or "").strip()
    if not user_id:
        user_id = str(
            profile.extra.get("user", {}).get("id") if isinstance(
                profile.extra.get("user"), Mapping) else "").strip()

    if not user_id:
        raise click.ClickException(
            "Failed to derive gateway user id from the control plane profile.\n"
            "Missing `user.id` in GET /auth/profile response.")

    try:
        return normalize_gateway_user_id(user_id)
    except ValueError as exc:
        raise click.ClickException(
            "Failed to derive gateway user id from the control plane profile.\n"
            f"{exc}") from exc
