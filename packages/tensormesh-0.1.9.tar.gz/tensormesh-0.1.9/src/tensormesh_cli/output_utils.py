from __future__ import annotations

from typing import Mapping

__all__ = [
    "debug_log",
    "redact_headers",
    "redact_secret",
]


def redact_secret(value: str | None) -> str | None:
    if value is None:
        return None
    s = value.strip()
    if not s:
        return None
    if len(s) <= 8:
        return "***"
    return f"{s[:4]}...{s[-4:]}"


def redact_headers(headers: Mapping[str, str]) -> dict[str, str]:
    redacted: dict[str, str] = {}
    for key, value in headers.items():
        lowered = key.lower()
        if lowered in ("authorization", "cookie", "set-cookie"):
            if lowered == "authorization" and value.lower().startswith(
                    "bearer "):
                redacted[key] = "Bearer ***"
            else:
                redacted[key] = "***"
            continue

        if any(token in lowered for token in ("api-key", "apikey", "token",
                                              "secret", "password")):
            redacted[key] = "***"
            continue

        redacted[key] = value
    return redacted


def debug_log(*, enabled: bool, quiet: bool, message: str) -> None:
    if not enabled or quiet:
        return
    import click

    click.echo(message, err=True)
