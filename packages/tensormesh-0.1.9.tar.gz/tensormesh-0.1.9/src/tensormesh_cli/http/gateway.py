from __future__ import annotations

from tensormesh._validation import normalize_uuid_string

__all__ = ["normalize_gateway_user_id"]


def normalize_gateway_user_id(value: str) -> str:
    return normalize_uuid_string(
        value,
        missing_message=("Missing gateway user id. Set --user-id, configure "
                         "gateway_user_id, or run `tm auth login` plus "
                         "`tm init --sync`."),
        invalid_message="Invalid gateway user id. `X-User-Id` must be a UUID.",
        error_type=ValueError,
    )
