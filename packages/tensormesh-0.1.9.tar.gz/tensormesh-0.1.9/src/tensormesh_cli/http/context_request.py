from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Mapping

import requests

from tensormesh import APIConnectionError
from tensormesh import APIStatusError
from tensormesh import APITimeoutError
from tensormesh._transport import is_idempotent_method
from tensormesh._transport import request_with_retries
from tensormesh._transport import SyncTransport
from tensormesh_cli.output_utils import redact_headers

__all__ = [
    "RequestConfigError",
    "RequestExecutionError",
    "RequestRuntime",
    "build_sync_transport",
    "execute_request",
    "run_transport_request",
]


@dataclass(frozen=True)
class RequestRuntime:
    verify: bool | str
    timeout_seconds: float
    max_retries: int
    debug: bool = False
    emit_debug: Callable[[str], None] | None = None


class RequestConfigError(ValueError):
    pass


class RequestExecutionError(RuntimeError):
    pass


def _request_execution_message(exc: Exception) -> str:
    if isinstance(exc, APITimeoutError):
        cause = exc.__cause__
        detail = str(cause) if cause is not None else str(exc).removeprefix(
            "Request timed out: ")
        return f"Request failed (network error): {detail}"
    return str(exc)


def build_sync_transport(runtime: RequestRuntime) -> SyncTransport:
    try:
        return SyncTransport(
            verify=runtime.verify,
            timeout_seconds=runtime.timeout_seconds,
            max_retries=runtime.max_retries,
        )
    except ValueError as exc:
        raise RequestConfigError(str(exc)) from exc


def run_transport_request(
    request_fn: Callable[[], requests.Response], ) -> requests.Response:
    try:
        return request_fn()
    except (APITimeoutError, APIConnectionError, APIStatusError) as exc:
        raise RequestExecutionError(_request_execution_message(exc)) from exc


def execute_request(
    runtime: RequestRuntime,
    *,
    method: str,
    url: str,
    headers: Mapping[str, str] | None = None,
    params: Mapping[str, str] | None = None,
    json_body: Any | None = None,
    timeout_s: float | None = None,
    default_timeout_s: float = 30.0,
    status_hints: Mapping[int, str] | None = None,
    error_context: Mapping[str, str] | None = None,
    request_fn: Callable[..., requests.Response] = request_with_retries,
) -> requests.Response:
    method_u = method.upper().strip()
    transport = build_sync_transport(runtime)
    if default_timeout_s != 30.0 and timeout_s is None:
        transport = SyncTransport(
            verify=transport.config.verify,
            timeout_seconds=default_timeout_s,
            max_retries=transport.config.max_retries,
        )

    max_retries = int(runtime.max_retries)
    idempotent = is_idempotent_method(method_u)
    attempts = 1 + (max_retries if idempotent else 0)
    request_headers = dict(headers or {})

    def _log_attempt(attempt: int, total: int) -> None:
        details: list[str] = [
            f"debug: {method_u} {url}",
            f"headers={redact_headers(request_headers)}",
        ]
        if params:
            details.append(f"params={dict(params)}")
        details.append(f"attempt={attempt}/{total}")
        if runtime.debug and runtime.emit_debug is not None:
            runtime.emit_debug(" ".join(details))

    return run_transport_request(lambda: transport.request(
        method_u,
        url,
        headers=request_headers,
        params=dict(params or {}),
        json_body=json_body,
        timeout_s=timeout_s,
        idempotent=idempotent,
        status_hints=status_hints,
        error_context=error_context,
        request_fn=request_fn,
        log_attempt=_log_attempt if attempts > 1 or runtime.debug else None,
    ))
