from __future__ import annotations

import click

from tensormesh._validation import resolve_ca_bundle_verify_value
from tensormesh_cli.app_context import get_app_context

__all__ = ["resolve_requests_verify", "resolve_verify_value"]


def resolve_verify_value(ca_bundle: str | None) -> bool | str:
    return resolve_ca_bundle_verify_value(
        ca_bundle,
        hint="set --ca-bundle or TENSORMESH_CA_BUNDLE to a readable PEM file.",
        error_type=ValueError,
    )


def resolve_requests_verify(ctx: click.Context) -> bool | str:
    try:
        return resolve_verify_value(get_app_context(ctx).ca_bundle)
    except ValueError as exc:
        raise click.UsageError(str(exc), ctx=ctx) from exc
