from __future__ import annotations

from typing import Any, Callable, Mapping

import requests

from tensormesh_cli.http.context_request import build_sync_transport
from tensormesh_cli.http.context_request import execute_request
from tensormesh_cli.http.context_request import RequestRuntime
from tensormesh_cli.http.context_request import run_transport_request
from tensormesh_cli.http.sdk_response import SDKBufferedResponse
from tensormesh_cli.output_utils import redact_headers

__all__ = [
    "ControlPlaneSDKTransport",
    "InferenceSDKTransport",
]

DEFAULT_STREAM_READ_TIMEOUT_S = 300.0


def _serialize_controlplane_params(
    params: Mapping[str, object] | None, ) -> dict[str, str] | None:
    if not params:
        return None
    serialized: dict[str, str] = {}
    for key, value in params.items():
        if isinstance(value, bool):
            serialized[key] = "true" if value else "false"
        else:
            serialized[key] = str(value)
    return serialized


class _BufferedSDKTransport:

    def __init__(
        self,
        *,
        runtime: RequestRuntime,
        status_hints: Mapping[int, str] | None = None,
        serialize_params: Callable[[Mapping[str, object] | None],
                                   Mapping[str, object] | None] | None = None,
    ) -> None:
        self._runtime = runtime
        self._status_hints = dict(status_hints or {})
        self._serialize_params = serialize_params
        self.last_buffered_response: SDKBufferedResponse | None = None

    def request(
        self,
        method: str,
        url: str,
        *,
        headers: Mapping[str, str] | None = None,
        params: Mapping[str, object] | None = None,
        json_body: Any | None = None,
        timeout_s: float | None = None,
        idempotent: bool | None = None,
        status_hints: Mapping[int, str] | None = None,
        error_context: Mapping[str, str] | None = None,
    ) -> SDKBufferedResponse:
        del idempotent
        response = execute_request(
            self._runtime,
            method=method,
            url=url,
            headers=headers,
            params=(self._serialize_params(params)
                    if self._serialize_params is not None else params),
            json_body=json_body,
            timeout_s=timeout_s,
            status_hints=status_hints or self._status_hints,
            error_context=error_context or {"url": url},
        )
        buffered = SDKBufferedResponse(response)
        self.last_buffered_response = buffered
        return buffered


class ControlPlaneSDKTransport(_BufferedSDKTransport):

    def __init__(
        self,
        *,
        runtime: RequestRuntime,
        status_hints: Mapping[int, str] | None = None,
    ) -> None:
        super().__init__(runtime=runtime,
                         status_hints=status_hints,
                         serialize_params=_serialize_controlplane_params)


class InferenceSDKTransport(_BufferedSDKTransport):

    def request_stream(
        self,
        method: str,
        url: str,
        *,
        headers: Mapping[str, str] | None = None,
        params: Mapping[str, object] | None = None,
        json_body: Any | None = None,
        timeout_s: float | None = None,
        read_timeout_s: float | None = None,
        status_hints: Mapping[int, str] | None = None,
        error_context: Mapping[str, str] | None = None,
    ) -> requests.Response:
        del error_context
        method_u = method.upper().strip()
        request_headers = dict(headers or {})
        request_params = dict(params or {})

        if self._runtime.debug and self._runtime.emit_debug is not None:
            self._runtime.emit_debug(
                f"debug: {method_u} {url} stream=true headers={redact_headers(request_headers)}"
            )

        transport = build_sync_transport(self._runtime)
        return run_transport_request(lambda: transport.request_stream(
            method_u,
            url,
            headers=request_headers,
            params=request_params,
            json_body=json_body,
            timeout_s=timeout_s,
            read_timeout_s=read_timeout_s or DEFAULT_STREAM_READ_TIMEOUT_S,
            status_hints=status_hints or self._status_hints,
            error_context={"url": url},
        ))
