from __future__ import annotations

import json
from pathlib import Path
import sys
from typing import TextIO

__all__ = ["load_json_optional", "load_json_required"]


def _loads_json(value: str, *, error_prefix: str) -> object:
    try:
        return json.loads(value)
    except json.JSONDecodeError as exc:
        raise ValueError(f"{error_prefix}: {exc}") from exc


def _load_json_path(path: Path, *, read_error_prefix: str) -> object:
    try:
        return _loads_json(path.read_text(encoding="utf-8"),
                           error_prefix=f"Invalid JSON in file: {path}")
    except OSError as exc:
        raise ValueError(f"{read_error_prefix}: {path}: {exc}") from exc


def load_json_optional(*,
                       json_arg: str | None,
                       file_path: str | None,
                       stdin: TextIO | None = None) -> object | None:
    """Load JSON from --json/--file/stdin if provided; otherwise returns None.

    Supports:
      --json '{"a":1}'
      --json @payload.json
      --file payload.json
      stdin (if piped)
    """
    return _load_json_impl(json_arg=json_arg,
                           file_path=file_path,
                           stdin=stdin,
                           required=False)


def load_json_required(*,
                       json_arg: str | None,
                       file_path: str | None,
                       stdin: TextIO | None = None) -> object:
    """Load JSON from --json/--file/stdin; raises ValueError if missing."""
    out = _load_json_impl(json_arg=json_arg,
                          file_path=file_path,
                          stdin=stdin,
                          required=True)
    assert out is not None
    return out


def _load_json_impl(*, json_arg: str | None, file_path: str | None,
                    stdin: TextIO | None, required: bool) -> object | None:
    src = stdin if stdin is not None else sys.stdin

    if json_arg is not None:
        if json_arg.startswith("@"):
            p = Path(json_arg[1:]).expanduser()
            return _load_json_path(
                p, read_error_prefix="Failed to read JSON file")
        return _loads_json(json_arg, error_prefix="Invalid JSON")

    if file_path is not None:
        p = Path(file_path).expanduser()
        return _load_json_path(p, read_error_prefix="Failed to read file")

    if not src.isatty():
        raw = src.read()
        if raw.strip():
            try:
                return json.loads(raw)
            except json.JSONDecodeError as exc:
                raise ValueError(f"Invalid JSON on stdin: {exc}") from exc

    if required:
        raise ValueError(
            "No input provided. Use --json, --file, or pipe JSON on stdin.")
    return None
