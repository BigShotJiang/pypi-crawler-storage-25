from __future__ import annotations

from typing import Any

import requests

__all__ = [
    "BufferedResponseJSONError",
    "SDKBufferedResponse",
]


class BufferedResponseJSONError(ValueError):

    def __init__(self, raw: str) -> None:
        super().__init__("Invalid JSON response.")
        self.raw = raw


class SDKBufferedResponse:

    def __init__(self, response: requests.Response) -> None:
        self._response = response
        self.status_code = response.status_code
        self.headers = dict(response.headers)
        self.text = response.text

    def json(self) -> Any:
        try:
            return self._response.json()
        except ValueError as exc:
            raise BufferedResponseJSONError(self.text) from exc
