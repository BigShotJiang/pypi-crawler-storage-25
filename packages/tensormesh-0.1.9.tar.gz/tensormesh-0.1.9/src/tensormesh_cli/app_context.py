from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Mapping

import click

from tensormesh_cli.config.load import flatten_resolved_config_file
from tensormesh_cli.config.load import load_config_file
from tensormesh_cli.config.model import ResolvedConfig
from tensormesh_cli.config.resolve import resolve_config

__all__ = [
    "AppContext",
    "PendingAppContext",
    "build_request_runtime",
    "build_app_context",
    "build_pending_app_context",
    "get_app_context",
]


@dataclass(frozen=True)
class AppContext:
    env: Mapping[str, str]
    resolved_config: ResolvedConfig
    output: str
    quiet: bool
    debug: bool

    @property
    def timeout_seconds(self) -> float:
        return self.resolved_config.timeout_seconds

    @property
    def max_retries(self) -> int:
        return self.resolved_config.max_retries

    @property
    def controlplane_base(self) -> str:
        return self.resolved_config.controlplane_base

    @property
    def controlplane_auth_json(self) -> str:
        return self.resolved_config.controlplane_auth_json

    @property
    def gateway_base(self) -> str:
        return self.resolved_config.gateway_base

    @property
    def gateway_api_key(self) -> str | None:
        return self.resolved_config.gateway_api_key

    @property
    def gateway_user_id(self) -> str | None:
        return self.resolved_config.gateway_user_id

    @property
    def gateway_model_id(self) -> str | None:
        return self.resolved_config.gateway_model_id

    @property
    def ca_bundle(self) -> str | None:
        return self.resolved_config.ca_bundle


@dataclass(frozen=True)
class PendingAppContext:
    env: Mapping[str, str]
    config_path: str
    output: str
    quiet: bool
    debug: bool
    controlplane_base: str | None
    ca_bundle: str | None
    timeout_seconds: float | None
    max_retries: int | None
    gateway_provider: str | None


def build_app_context(
    *,
    env: Mapping[str, str],
    resolved_config: ResolvedConfig,
    output: str,
    quiet: bool,
    debug: bool,
) -> AppContext:
    return AppContext(
        env=dict(env),
        resolved_config=resolved_config,
        output=output.lower(),
        quiet=quiet,
        debug=debug,
    )


def build_pending_app_context(
    *,
    env: Mapping[str, str],
    config_path: str,
    output: str,
    quiet: bool,
    debug: bool,
    controlplane_base: str | None,
    ca_bundle: str | None,
    timeout_seconds: float | None,
    max_retries: int | None,
    gateway_provider: str | None,
) -> PendingAppContext:
    return PendingAppContext(
        env=dict(env),
        config_path=config_path,
        output=output.lower(),
        quiet=quiet,
        debug=debug,
        controlplane_base=controlplane_base,
        ca_bundle=ca_bundle,
        timeout_seconds=timeout_seconds,
        max_retries=max_retries,
        gateway_provider=gateway_provider,
    )


def _resolve_pending_app_context(pending: PendingAppContext) -> AppContext:
    env_map = dict(pending.env)
    raw_file_cfg = load_config_file(Path(pending.config_path).expanduser())
    merged_file_cfg, merged_file_sources = flatten_resolved_config_file(
        raw_file_cfg)
    resolved = resolve_config(
        cli={
            "config_path": pending.config_path,
            "controlplane_base": pending.controlplane_base,
            "gateway_provider": pending.gateway_provider,
            "gateway_api_key": None,
            "gateway_user_id": None,
            "ca_bundle": pending.ca_bundle,
            "timeout_seconds": pending.timeout_seconds,
            "max_retries": pending.max_retries,
        },
        file_cfg=merged_file_cfg,
        file_sources=merged_file_sources,
        env=env_map,
    )
    return build_app_context(
        env=env_map,
        resolved_config=resolved,
        output=pending.output,
        quiet=pending.quiet,
        debug=pending.debug,
    )


def build_request_runtime(app: AppContext):
    from tensormesh_cli.http.context_request import RequestConfigError
    from tensormesh_cli.http.context_request import RequestRuntime
    from tensormesh_cli.http.tls import resolve_verify_value
    from tensormesh_cli.output_utils import debug_log

    try:
        verify = resolve_verify_value(app.ca_bundle)
    except ValueError as exc:
        raise RequestConfigError(str(exc)) from exc

    return RequestRuntime(
        verify=verify,
        timeout_seconds=app.timeout_seconds,
        max_retries=app.max_retries,
        debug=app.debug,
        emit_debug=lambda message: debug_log(
            enabled=True, quiet=app.quiet, message=message),
    )


def get_app_context(ctx: click.Context) -> AppContext:
    obj = ctx.obj
    if isinstance(obj, AppContext):
        return obj
    if isinstance(obj, PendingAppContext):
        try:
            app = _resolve_pending_app_context(obj)
        except RuntimeError as exc:
            raise click.ClickException(str(exc)) from exc
        ctx.obj = app
        return app
    raise click.ClickException("App context missing from Click context.")
