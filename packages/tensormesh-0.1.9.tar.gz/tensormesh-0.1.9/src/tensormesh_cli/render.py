from __future__ import annotations

import json
from typing import Any, Callable, Mapping, Sequence

import click

from tensormesh_cli.app_context import AppContext
from tensormesh_cli.app_context import get_app_context
from tensormesh_cli.app_context import PendingAppContext


def _json_compact(data: Any) -> str:
    return json.dumps(
        data,
        ensure_ascii=False,
        sort_keys=False,
    )


def _response_text(resp: Any) -> str:
    return getattr(resp, "text", "")


def _response_json(resp: Any, *, raw: str) -> Any:
    try:
        return resp.json()
    except ValueError as exc:
        raise click.ClickException(
            f"Invalid JSON response: expected JSON. Raw response: {raw}"
        ) from exc


def _echo_raw_response_if_requested(*, output: str, raw: str) -> bool:
    if output.lower() != "raw":
        return False
    echo_output(output="raw", raw=raw)
    return True


def _truncate(value: str, max_len: int) -> str:
    if len(value) <= max_len:
        return value
    if max_len <= 1:
        return value[:max_len]
    return value[:max_len - 1] + "…"


def _table_rows_from_data(data: Any) -> list[dict[str, Any]] | None:
    if isinstance(data, list) and all(isinstance(x, dict) for x in data):
        return [dict(x) for x in data]  # shallow copy
    if isinstance(data, dict):
        for key in ("items", "models", "users", "tickets", "transactions",
                    "pricing", "logs", "products", "activities", "apiKeys"):
            v = data.get(key)
            if isinstance(v, list) and all(isinstance(x, dict) for x in v):
                return [dict(x) for x in v]

        # If the response is shaped like {<single_list_key>: [...]}, try that.
        list_keys: list[str] = []
        for k, v in data.items():
            if isinstance(v, list) and all(isinstance(x, dict) for x in v):
                list_keys.append(str(k))
        if len(list_keys) == 1:
            v = data.get(list_keys[0])
            if isinstance(v, list):
                return [dict(x) for x in v if isinstance(x, dict)]
    return None


def _echo_table_rows(rows: list[dict[str, Any]]) -> None:
    if not rows:
        return

    columns: list[str] = []
    seen: set[str] = set()
    for row in rows:
        for k in row.keys():
            ks = str(k)
            if ks in seen:
                continue
            seen.add(ks)
            columns.append(ks)

    def cell(v: Any) -> str:
        if v is None:
            return ""
        if isinstance(v, (str, int, float, bool)):
            return str(v)
        return json.dumps(v, ensure_ascii=False, sort_keys=False)

    max_width = 48
    widths: dict[str, int] = {}
    for c in columns:
        widths[c] = len(c)
    for row in rows:
        for c in columns:
            widths[c] = max(widths[c],
                            len(_truncate(cell(row.get(c)), max_width)))

    header = "  ".join(c.ljust(widths[c]) for c in columns)
    sep = "  ".join("-" * widths[c] for c in columns)
    click.echo(header)
    click.echo(sep)
    for row in rows:
        line = "  ".join(
            _truncate(cell(row.get(c)), max_width).ljust(widths[c])
            for c in columns)
        click.echo(line)


def _echo_table_kv(data: Mapping[str, Any]) -> None:
    rows = [{"key": str(k), "value": v} for k, v in data.items()]
    _echo_table_rows(rows)


def echo_output(*,
                output: str,
                data: Any = None,
                raw: str | None = None) -> None:
    out = output.lower()
    if out == "text":
        # Human-readable default for structured data.
        out = "yaml"
    if out == "raw":
        if raw is None:
            if isinstance(data, str):
                raw = data
            elif data is None:
                raw = ""
            else:
                try:
                    raw = _json_compact(data)
                except TypeError:
                    raw = str(data)
        click.echo(raw, nl=True)
        return
    if out == "json":
        click.echo(
            json.dumps(
                data,
                indent=2,
                ensure_ascii=False,
                sort_keys=False,
            ),
            nl=True,
        )
        return
    if out == "table":
        rows = _table_rows_from_data(data)
        if rows is not None:
            _echo_table_rows(rows)
            return
        if isinstance(data, Mapping):
            _echo_table_kv(data)
            return
        click.echo(str(data) if data is not None else "", nl=True)
        return
    if out == "yaml":
        import yaml

        # PyYAML emits a trailing newline; avoid doubling it.
        click.echo(yaml.safe_dump(data, sort_keys=False), nl=False)
        return
    raise click.ClickException(f"Unknown output format: {output}")


def maybe_echo_structured_output(
    ctx: click.Context,
    *,
    data: Any,
    structured_outputs: tuple[str, ...] = ("json", "yaml", "raw", "table"),
) -> bool:
    out = context_output(ctx)
    if out not in structured_outputs:
        return False
    echo_output(output=out, data=data)
    return True


def echo_status_screen(
        title: str,
        *,
        lines: Sequence[str] = (),
        missing: Sequence[str] = (),
        warnings: Sequence[str] = (),
        next_steps: Sequence[str] = (),
) -> None:
    click.echo(title)
    click.echo("")

    for line in lines:
        click.echo(line)

    if missing:
        click.echo("")
        click.echo("Missing:")
        for item in missing:
            click.echo(f"- {item}")

    if warnings:
        click.echo("")
        click.echo("Warnings:")
        for item in warnings:
            click.echo(f"- {item}")

    if next_steps:
        click.echo("")
        click.echo("Next steps:")
        for index, step in enumerate(next_steps, start=1):
            click.echo(f"{index}. {step}")


def echo_http_response(*, output: str, resp: Any) -> None:
    raw = _response_text(resp)
    if _echo_raw_response_if_requested(output=output, raw=raw):
        return
    data = _response_json(resp, raw=raw)
    echo_output(output=output.lower(), data=data, raw=raw)


def echo_http_response_with_text_extractor(
        *,
        output: str,
        resp: Any,
        extract_text: Callable[[Any], str | None],
        transform_data: Callable[[Any], Any] | None = None,
        structured_outputs: tuple[str, ...] = ("json", "yaml", "table"),
) -> None:
    out = output.lower()
    raw = _response_text(resp)
    if _echo_raw_response_if_requested(output=out, raw=raw):
        return

    data = _response_json(resp, raw=raw)
    if transform_data is not None:
        data = transform_data(data)
    if out in structured_outputs:
        echo_output(output=out, data=data, raw=raw)
        return

    preferred_text = extract_text(data)
    if preferred_text is not None:
        click.echo(preferred_text)
        return

    echo_output(output=out, data=data, raw=raw)


def context_output(ctx: click.Context, *, default: str = "text") -> str:
    obj = ctx.obj
    if isinstance(obj, (AppContext, PendingAppContext)):
        return str(obj.output or default).lower()
    return str(get_app_context(ctx).output or default).lower()


def echo_http_response_for_ctx(
    ctx: click.Context,
    resp: Any,
    *,
    default: str = "text",
) -> None:
    echo_http_response(output=context_output(ctx, default=default), resp=resp)
