"""
Click command groups for the Tensormesh CLI.

Kept in a separate package to keep `src/tensormesh_cli/cli.py` small and focused on
global options + command registration.
"""
