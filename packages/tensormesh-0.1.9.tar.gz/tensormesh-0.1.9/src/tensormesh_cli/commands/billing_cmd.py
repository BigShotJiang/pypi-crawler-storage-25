from __future__ import annotations

import click

from tensormesh_cli.commands._generated_controlplane_gap_cmd import \
    attach_generated_billing_gap_commands
from tensormesh_cli.commands.click_helpers import cloud_provider_option
from tensormesh_cli.commands.click_helpers import gpu_type_option
from tensormesh_cli.commands.click_helpers import timeout_option
from tensormesh_cli.commands.click_helpers import user_id_option
from tensormesh_cli.commands.controlplane_actions import \
    execute_controlplane_sdk_and_render
from tensormesh_cli.docs_meta import attach_command_docs
from tensormesh_cli.docs_meta import CommandExampleMeta


@click.group(name="billing")
def billing_group() -> None:
    """Billing and usage (Control Plane)."""
    pass


@billing_group.command(name="balance")
@user_id_option(help="Optional user id to scope authorization.")
@timeout_option()
@click.pass_context
def balance_cmd(ctx: click.Context, user_id: str | None,
                timeout_s: float | None) -> None:
    """Get current balance (GET /v1/billing/balance)."""
    execute_controlplane_sdk_and_render(
        ctx,
        lambda client: client.control_plane.billing.balance.get(
            user_id=user_id,
            timeout=timeout_s,
        ),
        default="json",
    )


@billing_group.group(name="transactions")
def transactions_group() -> None:
    """Billing transactions."""
    pass


@transactions_group.command(name="list")
@user_id_option(help="Optional user id to scope authorization.")
@click.option("--page-size",
              type=int,
              default=None,
              help="Number of items per page.")
@click.option("--page-token", default=None, help="Pagination token.")
@timeout_option()
@click.pass_context
def transactions_list_cmd(
    ctx: click.Context,
    user_id: str | None,
    page_size: int | None,
    page_token: str | None,
    timeout_s: float | None,
) -> None:
    """List billing transactions (GET /v1/billing/transactions)."""
    execute_controlplane_sdk_and_render(
        ctx,
        lambda client: client.control_plane.billing.transactions.list(
            user_id=user_id,
            page_size=page_size,
            page_token=page_token,
            timeout=timeout_s,
        ),
        default="json",
    )


@billing_group.group(name="spending")
def spending_group() -> None:
    """Spending summaries."""
    pass


@spending_group.command(name="summary")
@user_id_option(help="Optional user id to scope authorization.")
@timeout_option()
@click.pass_context
def spending_summary_cmd(ctx: click.Context, user_id: str | None,
                         timeout_s: float | None) -> None:
    """Get spending summary (GET /v1/billing/spending/summary)."""
    execute_controlplane_sdk_and_render(
        ctx,
        lambda client: client.control_plane.billing.spending.summary(
            user_id=user_id,
            timeout=timeout_s,
        ),
        default="json",
    )


@spending_group.command(name="history")
@user_id_option(help="Optional user id to scope authorization.")
@timeout_option()
@click.pass_context
def spending_history_cmd(ctx: click.Context, user_id: str | None,
                         timeout_s: float | None) -> None:
    """Get spending history (GET /v1/billing/spending/history)."""
    execute_controlplane_sdk_and_render(
        ctx,
        lambda client: client.control_plane.billing.spending.history(
            user_id=user_id,
            timeout=timeout_s,
        ),
        default="json",
    )


@billing_group.group(name="pricing")
def pricing_group() -> None:
    """Pricing info (Control Plane)."""
    pass


@pricing_group.command(name="list")
@cloud_provider_option(help="Filter by cloud provider enum.")
@gpu_type_option(help="Filter by GPU type enum.")
@click.option("--active-only",
              is_flag=True,
              default=False,
              help="Return active pricing only.")
@timeout_option()
@click.pass_context
def pricing_list_cmd(
    ctx: click.Context,
    cloud_provider: str | None,
    gpu_type: str | None,
    active_only: bool,
    timeout_s: float | None,
) -> None:
    """List GPU pricing (GET /v1/billing/gpu-pricing)."""
    execute_controlplane_sdk_and_render(
        ctx,
        lambda client: client.control_plane.billing.pricing.gpu.list(
            cloud_provider=cloud_provider,
            gpu_type=gpu_type,
            active_only=True if active_only else None,
            timeout=timeout_s,
        ),
        default="json",
    )


@pricing_group.group(name="serverless")
def pricing_serverless_group() -> None:
    """Serverless pricing info (Control Plane)."""
    pass


@pricing_serverless_group.command(name="list")
@click.option("--model", default=None, help="Filter by model name.")
@click.option("--active-only",
              is_flag=True,
              default=False,
              help="Return active pricing only.")
@timeout_option()
@click.pass_context
def pricing_serverless_list_cmd(
    ctx: click.Context,
    model: str | None,
    active_only: bool,
    timeout_s: float | None,
) -> None:
    """List serverless pricing (GET /v1/billing/serverless-pricing)."""
    execute_controlplane_sdk_and_render(
        ctx,
        lambda client: client.control_plane.billing.pricing.serverless.list(
            model=model,
            active_only=True if active_only else None,
            timeout=timeout_s,
        ),
        default="json",
    )


pricing_serverless_list_cmd = attach_command_docs(
    pricing_serverless_list_cmd,
    summary="List serverless pricing (GET /v1/billing/serverless-pricing).",
    overview_title="When To Use This",
    overview_markdown=
    ("Use `tm billing pricing serverless list` when you have Control Plane access for the current Tensormesh environment and need to discover published serverless model names.\n\n"
     "Use the returned `pricing[].model` value as the `--model` input for `tm infer chat --surface serverless`, the SDK, or raw HTTP requests.\n\n"
     "Example response shape:\n\n"
     "```yaml\n"
     "pricing:\n"
     "  - name: MiniMaxAI/MiniMax-M2.5\n"
     "    model: MiniMaxAI/MiniMax-M2.5\n"
     "    isActive: true\n"
     "```\n\n"
     "Use `model` when sending inference requests. `id` is the pricing-record id, and `name` is display-oriented."
     ),
    prerequisites=[
        "Run `tm auth login` first, or otherwise provide Control Plane auth for the same Tensormesh environment you want to inspect."
    ],
    caveats=[
        "This command lists pricing records for the current Tensormesh Control Plane environment. If you are targeting a different serverless host override, confirm the model name for that host separately."
    ],
    related_commands=["tm infer chat", "tm auth whoami"],
    examples=[
        CommandExampleMeta(
            command="tm billing pricing serverless list",
            description="List published serverless pricing records.",
        ),
        CommandExampleMeta(
            command=
            "tm --output json billing pricing serverless list --active-only",
            description=
            "Inspect only active pricing records and copy `pricing[].model` from structured output.",
        ),
        CommandExampleMeta(
            command=
            "tm billing pricing serverless list --model MiniMaxAI/MiniMax-M2.5",
            description=
            "Filter the pricing list to one known serverless model name.",
        ),
    ],
)

billing_group = attach_command_docs(
    billing_group,
    summary="Billing and usage (Control Plane).",
    examples=[
        CommandExampleMeta(
            command="tm billing balance",
            description="Inspect the current user billing balance.",
        ),
    ],
)

transactions_group = attach_command_docs(
    transactions_group,
    summary="Billing transactions.",
    examples=[
        CommandExampleMeta(
            command="tm billing transactions list",
            description="List billing transactions for the current user.",
        ),
    ],
)

spending_group = attach_command_docs(
    spending_group,
    summary="Spending summaries.",
    examples=[
        CommandExampleMeta(
            command="tm billing spending summary",
            description="Inspect the current spending summary.",
        ),
    ],
)

pricing_group = attach_command_docs(
    pricing_group,
    summary="Pricing info (Control Plane).",
    examples=[
        CommandExampleMeta(
            command="tm billing pricing list",
            description="List GPU pricing records from the Control Plane.",
        ),
    ],
)

pricing_serverless_group = attach_command_docs(
    pricing_serverless_group,
    summary="Serverless pricing info (Control Plane).",
    examples=[
        CommandExampleMeta(
            command="tm billing pricing serverless list",
            description=
            "List serverless pricing records from the Control Plane.",
        ),
    ],
)

attach_generated_billing_gap_commands(billing_group)
