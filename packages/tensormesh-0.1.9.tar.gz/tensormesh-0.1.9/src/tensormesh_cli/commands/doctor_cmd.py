from __future__ import annotations

from pathlib import Path
from typing import Any

import click

from tensormesh_cli.app_context import get_app_context
from tensormesh_cli.commands.click_helpers import exit_status_option
from tensormesh_cli.commands.readiness import build_doctor_status
from tensormesh_cli.commands.readiness import controlplane_status_data
from tensormesh_cli.commands.readiness import gateway_status_data
from tensormesh_cli.commands.readiness import inspect_readiness
from tensormesh_cli.config.constants import ENV_CA_BUNDLE
from tensormesh_cli.config.public import resolved_config_public_dict
from tensormesh_cli.docs_meta import attach_command_docs
from tensormesh_cli.docs_meta import CommandExampleMeta
from tensormesh_cli.render import echo_status_screen
from tensormesh_cli.render import maybe_echo_structured_output


@click.command(name="doctor")
@exit_status_option()
@click.pass_context
def doctor_cmd(ctx: click.Context, exit_status: bool) -> None:
    """Diagnose configuration and credentials."""
    app = get_app_context(ctx)
    cfg = app.resolved_config

    try:
        config_exists = Path(cfg.config_path).expanduser().exists()
    except (OSError, TypeError):
        config_exists = False
    try:
        ca_bundle_exists = (Path(cfg.ca_bundle).expanduser().exists()
                            if cfg.ca_bundle else False)
    except (OSError, TypeError):
        ca_bundle_exists = False
    snapshot = inspect_readiness(cfg)
    auth_state = snapshot.auth_state
    gateway_state = snapshot.gateway_state
    control_plane = controlplane_status_data(cfg, auth_state)
    gateway = gateway_status_data(cfg, gateway_state)

    control_plane_ready = snapshot.control_plane_ready
    gateway_ready = snapshot.gateway_ready
    overall_ready = snapshot.overall_ready

    missing, warnings, lines = build_doctor_status(cfg, snapshot)
    warnings.append(
        "Local readiness only. `tm doctor` does not live-validate the current Control Plane token or inference endpoint."
    )

    if not gateway_state.model_id_present:
        warnings.append(
            "gateway_model_id not set (run `tm init --sync` or pass --model when required)"
        )
    if cfg.ca_bundle and not ca_bundle_exists:
        warnings.append(
            f"ca_bundle is set but file is missing (set --ca-bundle/{ENV_CA_BUNDLE} to a readable PEM file)"
        )
    data: dict[str, Any] = {
        "ok": overall_ready,
        "ready": {
            "control_plane": control_plane_ready,
            "gateway": gateway_ready,
            "overall": overall_ready,
        },
        "missing": missing,
        "warnings": warnings,
        "files": {
            "config_path": cfg.config_path,
            "config_exists": config_exists,
            "auth_json_path": auth_state.auth_json_path,
            "auth_json_exists": auth_state.auth_json_exists,
            "ca_bundle_path": cfg.ca_bundle,
            "ca_bundle_exists": ca_bundle_exists,
        },
        "config": resolved_config_public_dict(cfg),
        "control_plane": control_plane,
        "gateway": gateway,
    }

    if not maybe_echo_structured_output(
            ctx, data=data, structured_outputs=("json", "yaml", "raw")):
        lines = [
            f"Config file: {cfg.config_path} ({'ok' if config_exists else 'missing'})"
        ] + lines
        if cfg.ca_bundle:
            lines.append(
                f"CA bundle: {cfg.ca_bundle} ({'ok' if ca_bundle_exists else 'missing'})"
            )
        echo_status_screen("tm doctor",
                           lines=lines,
                           missing=missing,
                           warnings=warnings)

    if exit_status and not data["ok"]:
        ctx.exit(1)


doctor_cmd = attach_command_docs(
    doctor_cmd,
    summary="Diagnose configuration and credentials.",
    overview_title="What This Checks",
    overview_markdown=
    ("`tm doctor` is a broad local diagnosis command. It inspects configuration and credential readiness across the CLI, but it does not prove that a live API call will succeed.\n\n"
     "Use [`tm auth whoami`](/cli/reference/auth/whoami) for a live Control Plane auth check and [`tm infer chat`](/cli/reference/infer/chat) for an end-to-end inference check."
     ),
    caveats=[
        "Reports local readiness only. Use `tm auth whoami` to live-validate Control Plane auth and `tm infer chat` for an end-to-end inference check.",
        "Use `tm infer doctor` for direct gateway gating and `tm auth status`/`tm auth whoami` for Control Plane-specific checks."
    ],
    related_commands=[
        "tm config show", "tm auth whoami", "tm infer doctor", "tm infer chat"
    ],
    examples=[
        CommandExampleMeta(
            command="tm doctor",
            description=
            "Check the current CLI configuration and credential state.",
        ),
        CommandExampleMeta(
            command="tm doctor --exit-status",
            description=
            "Use shell-friendly exit codes when required credentials are missing.",
        ),
    ],
)
