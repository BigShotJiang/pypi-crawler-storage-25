from __future__ import annotations

import click

from tensormesh_cli.commands._generated_controlplane_gap_cmd import \
    attach_generated_admin_models_gap_commands
from tensormesh_cli.commands.click_helpers import json_input_options
from tensormesh_cli.commands.click_helpers import timeout_option
from tensormesh_cli.commands.click_helpers import user_id_option
from tensormesh_cli.commands.click_helpers import yes_option
from tensormesh_cli.commands.controlplane_actions import confirm_or_abort
from tensormesh_cli.commands.controlplane_actions import \
    execute_controlplane_sdk_and_render
from tensormesh_cli.commands.request_utils import require_non_empty_value
from tensormesh_cli.commands.request_utils import resolve_command_payload


@click.group(name="models")
def admin_models_group() -> None:
    """Admin model tools."""
    pass


@admin_models_group.command(name="delete")
@click.argument("model_id", type=str)
@user_id_option(help="Optional admin user id for authorization.")
@yes_option()
@json_input_options(
    json_help="JSON request body or @file.json (overrides --user-id).",
    file_help="Read JSON request body from file (overrides --user-id).",
)
@timeout_option()
@click.pass_context
def admin_models_delete_cmd(
    ctx: click.Context,
    model_id: str,
    user_id: str | None,
    yes: bool,
    json_arg: str | None,
    file_path: str | None,
    timeout_s: float | None,
) -> None:
    """Delete a model as admin (DELETE /v1/admin/models/{modelId})."""
    mid = require_non_empty_value(ctx=ctx, value=model_id, label="MODEL_ID")
    request_payload = resolve_command_payload(
        ctx=ctx,
        json_arg=json_arg,
        file_path=file_path,
        build_from_values=lambda: {"userId": user_id}
        if user_id is not None else {},
        build_from_json=lambda body: body,
        to_payload=lambda payload: payload,
    )

    confirm_or_abort(
        yes=yes,
        message=
        (f"Delete model {mid!r} as admin? This may stop inference and may be irreversible."
         ),
    )
    execute_controlplane_sdk_and_render(
        ctx,
        lambda client: client.control_plane.admin.models.delete(
            mid,
            user_id=(str(request_payload.get("userId")).strip() or None)
            if request_payload.get("userId") is not None else None,
            timeout=timeout_s,
        ),
        default="json",
    )


attach_generated_admin_models_gap_commands(admin_models_group)
