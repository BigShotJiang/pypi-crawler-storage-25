from __future__ import annotations

from dataclasses import asdict
from pathlib import Path
import sys
from typing import Callable

import click

from tensormesh._transport import normalize_timeout_s
from tensormesh._transport import resolve_timeout_s
from tensormesh_cli import auth
from tensormesh_cli.app_context import AppContext
from tensormesh_cli.app_context import get_app_context
from tensormesh_cli.commands.click_helpers import exit_status_option
from tensormesh_cli.commands.click_helpers import timeout_option
from tensormesh_cli.commands.readiness import build_auth_status_lines
from tensormesh_cli.commands.readiness import controlplane_status_data
from tensormesh_cli.commands.readiness import gateway_status_data
from tensormesh_cli.commands.readiness import inspect_readiness
from tensormesh_cli.controlplane import resolve_controlplane_access_token
from tensormesh_cli.docs_meta import attach_command_docs
from tensormesh_cli.docs_meta import CommandExampleMeta
from tensormesh_cli.http.tls import resolve_requests_verify
from tensormesh_cli.render import echo_status_screen
from tensormesh_cli.render import maybe_echo_structured_output


@click.group(name="auth")
def auth_group() -> None:
    """Authenticate to the Tensormesh Control Plane."""
    pass


def _run_auth_runtime_action(
    ctx: click.Context,
    *,
    timeout_s: float | None,
    action: Callable[[AppContext, float, bool | str], None],
    failure_message: Callable[[AppContext, str], str],
    success_message: str | None = None,
) -> AppContext:
    app = get_app_context(ctx)
    try:
        effective_timeout_s = resolve_timeout_s(
            timeout_s=timeout_s,
            configured_timeout_s=app.timeout_seconds,
            default_timeout_s=10.0,
        )
    except ValueError as exc:
        raise click.UsageError(str(exc), ctx=ctx) from exc
    verify = resolve_requests_verify(ctx)
    try:
        action(app, effective_timeout_s, verify)
    except RuntimeError as exc:
        raise click.ClickException(failure_message(app, str(exc))) from exc
    if success_message and not app.quiet:
        click.echo(success_message)
    return app


def _should_confirm_auth_file_delete() -> bool:
    return sys.stdin.isatty() and sys.stdout.isatty()


@auth_group.command()
@click.option(
    "--no-open-browser",
    "no_browser",
    is_flag=True,
    default=False,
    help="Do not open the browser automatically (prints URL instead).",
)
@click.option(
    "--max-wait-seconds",
    "max_wait_seconds",
    default=300.0,
    show_default=True,
    type=float,
    help="Maximum total wait time for the browser login flow before failing.",
)
@timeout_option(help="HTTP timeout in seconds for the login flow.")
@click.pass_context
def login(ctx: click.Context, no_browser: bool, max_wait_seconds: float,
          timeout_s: float | None) -> None:
    """Login via browser and store Control Plane tokens."""
    try:
        effective_max_wait_s = normalize_timeout_s(max_wait_seconds)
    except ValueError as exc:
        raise click.UsageError(str(exc), ctx=ctx) from exc

    def _login_log(message: str) -> None:
        if app.quiet and (not no_browser
                          or not message.startswith("Open browser: ")):
            return
        click.echo(message, err=True)

    app = get_app_context(ctx)
    _run_auth_runtime_action(
        ctx,
        timeout_s=timeout_s,
        action=lambda app, effective_timeout_s, verify: auth.login(
            app.controlplane_base,
            Path(app.controlplane_auth_json),
            open_browser=not no_browser,
            timeout_s=effective_timeout_s,
            max_wait_s=effective_max_wait_s,
            verify=verify,
            log=_login_log if (not app.quiet or no_browser) else None,
        ),
        failure_message=lambda app, message: f"{message}\n\nHints:\n"
        f"- Token path: {app.controlplane_auth_json}",
    )


@auth_group.command()
@timeout_option(help="HTTP timeout in seconds for the refresh call.")
@click.pass_context
def refresh(ctx: click.Context, timeout_s: float | None) -> None:
    """Refresh stored Control Plane tokens."""
    _run_auth_runtime_action(
        ctx,
        timeout_s=timeout_s,
        action=lambda app, effective_timeout_s, verify: auth.refresh(
            app.controlplane_base,
            Path(app.controlplane_auth_json),
            timeout_s=effective_timeout_s,
            verify=verify,
        ),
        failure_message=lambda app, message: f"{message}\n\nHints:\n"
        f"- Run: tm auth login\n"
        f"- Token path: {app.controlplane_auth_json}",
        success_message="Refresh success. Tokens updated.",
    )


@auth_group.command()
@timeout_option(help="HTTP timeout in seconds for the profile call.")
@click.pass_context
def whoami(ctx: click.Context, timeout_s: float | None) -> None:
    """Show the authenticated Control Plane user profile."""
    try:
        resolve_controlplane_access_token(ctx)
    except click.UsageError as exc:
        raise click.UsageError(
            f"{exc.message}\n"
            "Note: gateway API keys do not authenticate the control plane.",
            ctx=ctx,
        ) from exc
    try:
        from tensormesh_cli.commands.controlplane_actions import \
            execute_controlplane_sdk_and_render

        execute_controlplane_sdk_and_render(
            ctx,
            lambda client: client.control_plane.users.get_auth_profile(
                timeout=timeout_s),
            default="json",
        )
    except click.ClickException as exc:
        raise click.ClickException(
            "Whoami failed.\n"
            f"{exc.message}"
            "\n\nHints:\n- Try: tm auth refresh") from exc


@auth_group.command(name="logout")
@click.option("--yes",
              is_flag=True,
              default=False,
              help="Skip confirmation prompt.")
@click.pass_context
def logout_cmd(ctx: click.Context, yes: bool) -> None:
    """Delete the local Control Plane token file."""
    app = get_app_context(ctx)
    token_path = Path(app.controlplane_auth_json).expanduser()
    if not token_path.exists():
        if not app.quiet:
            click.echo(f"Already logged out (no token file): {token_path}")
        return
    if not yes and _should_confirm_auth_file_delete():
        click.confirm(f"Delete token file: {token_path}?",
                      default=False,
                      abort=True)
    try:
        token_path.unlink()
    except OSError as exc:
        raise click.ClickException(
            f"Failed to delete token file: {token_path}: {exc}") from exc
    if not app.quiet:
        click.echo(f"Deleted token file: {token_path}")


@auth_group.command(name="print-token")
@click.option(
    "--yes-i-know",
    is_flag=True,
    default=False,
    help="Acknowledge that printing tokens may leak secrets (required).",
)
@click.pass_context
def print_token_cmd(ctx: click.Context, yes_i_know: bool) -> None:
    """Print the Control Plane access token to stdout (for scripting)."""
    if not yes_i_know:
        raise click.ClickException(
            "Refusing to print access token without explicit acknowledgement.\n"
            "Re-run with: tm auth print-token --yes-i-know")

    try:
        token = resolve_controlplane_access_token(ctx)
    except click.UsageError as exc:
        raise click.ClickException(exc.message) from exc

    # Deliberately print only the raw token (machine-friendly).
    click.echo(token)


@auth_group.command(name="status")
@exit_status_option(
    help=
    "Exit non-zero when Control Plane or Gateway auth prerequisites are missing."
)
@click.pass_context
def status_cmd(ctx: click.Context, exit_status: bool) -> None:
    """Show local Control Plane and Gateway auth status."""
    app = get_app_context(ctx)
    cfg = app.resolved_config
    snapshot = inspect_readiness(cfg)
    auth_state = snapshot.auth_state
    gateway_state = snapshot.gateway_state
    control_plane = controlplane_status_data(cfg, auth_state)
    gateway = gateway_status_data(cfg, gateway_state)

    warnings = snapshot.build_common_warnings()
    warnings.append(
        "Local status only. Use `tm auth whoami` to live-validate Control Plane auth."
    )

    control_plane_ready = snapshot.control_plane_ready
    gateway_ready = snapshot.gateway_ready
    overall_ready = snapshot.overall_ready

    data = {
        "ready": {
            "control_plane": control_plane_ready,
            "gateway": gateway_ready,
            "overall": overall_ready,
        },
        "control_plane": control_plane,
        "gateway": gateway,
        "sources": asdict(cfg.sources),
        "warnings": warnings,
    }

    if not maybe_echo_structured_output(ctx, data=data):
        echo_status_screen("tm auth status",
                           lines=build_auth_status_lines(cfg, snapshot),
                           warnings=warnings)

    if exit_status and not overall_ready:
        ctx.exit(1)


auth_group = attach_command_docs(
    auth_group,
    summary="Authenticate to the Tensormesh Control Plane.",
    examples=[
        CommandExampleMeta(
            command="tm auth login",
            description="Start the Control Plane login flow.",
        ),
        CommandExampleMeta(
            command="tm auth status",
            description=
            "Inspect the local Control Plane and Gateway auth state.",
        ),
        CommandExampleMeta(
            command="tm auth whoami",
            description=
            "Confirm the current authenticated Control Plane identity.",
        ),
    ],
)

login = attach_command_docs(
    login,
    summary="Login via browser and store Control Plane tokens.",
    auth_scope=["controlplane-browser-login"],
    prerequisites=[
        "Access to a browser that can complete the Tensormesh login flow."
    ],
    caveats=[
        "Tokens are stored locally after login completes.",
        "The login flow fails closed after 300 seconds unless `--max-wait-seconds` overrides it."
    ],
    related_commands=["tm auth whoami", "tm auth refresh"],
    examples=[
        CommandExampleMeta(
            command="tm auth login",
            description=
            "Start the browser login flow and store Control Plane tokens locally.",
        ),
        CommandExampleMeta(
            command="tm auth login --no-open-browser",
            description=
            "Print the login URL instead of opening a browser automatically.",
        ),
        CommandExampleMeta(
            command="tm auth login --no-open-browser --max-wait-seconds 60",
            description=
            "Fail the login flow if the browser exchange is still pending after 60 seconds.",
        ),
    ],
)

print_token_cmd = attach_command_docs(
    print_token_cmd,
    summary="Print the Control Plane access token to stdout (for scripting).",
    auth_scope=["controlplane-access-token"],
    prerequisites=[
        "Run tm auth login first.",
        "Use a controlled shell environment that will not echo or log the token."
    ],
    caveats=[
        "Writes the raw bearer token to stdout.",
        "Prefer short-lived shell variables over copying tokens into files or shell history."
    ],
    related_commands=["tm auth whoami", "tm auth login", "tm auth refresh"],
    examples=[
        CommandExampleMeta(
            command="tm auth print-token --yes-i-know",
            description=
            "Print the current Control Plane bearer token for a controlled script.",
        ),
    ],
)

whoami = attach_command_docs(
    whoami,
    summary="Show the authenticated Control Plane user profile.",
    overview_title="What This Checks",
    overview_markdown=
    ("`tm auth whoami` is a live Control Plane check. It calls the profile endpoint with the current bearer token and confirms that the token is accepted by the current Control Plane base URL.\n\n"
     "Use [`tm auth status`](/cli/reference/auth/status) when you only need to inspect local credential presence without making a network call."
     ),
    auth_scope=["controlplane-access-token"],
    prerequisites=["Run tm auth login first."],
    caveats=[
        "Uses `GET /auth/profile` to live-validate the current bearer token."
    ],
    related_commands=["tm auth login", "tm auth refresh"],
    examples=[
        CommandExampleMeta(
            command="tm auth whoami",
            description=
            "Show the current authenticated Control Plane identity.",
        ),
        CommandExampleMeta(
            command="tm --output json auth whoami",
            description=
            "Show the current authenticated Control Plane identity in structured JSON output.",
        ),
    ],
)

status_cmd = attach_command_docs(
    status_cmd,
    summary="Show local Control Plane and Gateway auth status.",
    overview_title="What This Checks",
    overview_markdown=
    ("`tm auth status` is a local readiness check. It inspects whether the expected Control Plane and gateway credentials are present locally. It does not make a live API request.\n\n"
     "Use [`tm auth whoami`](/cli/reference/auth/whoami) when you want to verify that the current bearer token works against the Control Plane."
     ),
    prerequisites=[
        "If you want gateway status to include synced managed values, run `tm init --sync` first."
    ],
    caveats=[
        "Reports local credential presence. Use `tm auth whoami` to live-validate Control Plane auth."
    ],
    examples=[
        CommandExampleMeta(
            command="tm auth status",
            description="Show local Control Plane and Gateway auth state.",
        ),
        CommandExampleMeta(
            command="tm auth status --exit-status",
            description=
            "Use shell-friendly exit codes when Control Plane or Gateway auth is not ready.",
        ),
    ],
    related_commands=[
        "tm auth login", "tm auth whoami", "tm config show", "tm doctor"
    ],
)
