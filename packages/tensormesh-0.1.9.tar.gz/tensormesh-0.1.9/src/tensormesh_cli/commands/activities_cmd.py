from __future__ import annotations

import click

from tensormesh_cli.commands.click_helpers import end_time_option
from tensormesh_cli.commands.click_helpers import page_option
from tensormesh_cli.commands.click_helpers import size_option
from tensormesh_cli.commands.click_helpers import start_time_option
from tensormesh_cli.commands.click_helpers import timeout_option
from tensormesh_cli.commands.click_helpers import user_id_option
from tensormesh_cli.commands.controlplane_actions import \
    execute_controlplane_sdk_and_render
from tensormesh_cli.docs_meta import attach_command_docs
from tensormesh_cli.docs_meta import CommandExampleMeta


@click.group(name="activities")
def activities_group() -> None:
    """Activities (Control Plane)."""
    pass


@activities_group.command(name="list")
@user_id_option(help="Filter by user id.")
@click.option("--action", default=None, help="Filter by action.")
@click.option("--resource-type",
              "resource_type",
              default=None,
              help="Filter by resource type.")
@click.option("--resource-id",
              "resource_id",
              default=None,
              help="Filter by resource id.")
@start_time_option(help="Filter by start time (server-defined format).")
@end_time_option(help="Filter by end time (server-defined format).")
@page_option()
@size_option()
@timeout_option()
@click.pass_context
def activities_list_cmd(
    ctx: click.Context,
    user_id: str | None,
    action: str | None,
    resource_type: str | None,
    resource_id: str | None,
    start_time: str | None,
    end_time: str | None,
    page: int | None,
    size: int | None,
    timeout_s: float | None,
) -> None:
    """List activities (GET /v1/activities)."""
    execute_controlplane_sdk_and_render(
        ctx,
        lambda client: client.control_plane.activities.list(
            user_id=user_id,
            action=action,
            resource_type=resource_type,
            resource_id=resource_id,
            start_time=start_time,
            end_time=end_time,
            page=page,
            size=size,
            timeout=timeout_s,
        ),
        default="json",
    )


@activities_group.command(name="get")
@click.argument("activity_id")
@timeout_option()
@click.pass_context
def activities_get_cmd(ctx: click.Context, activity_id: str,
                       timeout_s: float | None) -> None:
    """Get an activity (GET /v1/activities/{activityId})."""
    execute_controlplane_sdk_and_render(
        ctx,
        lambda client: client.control_plane.activities.get(
            activity_id,
            timeout=timeout_s,
        ),
        default="json",
    )


activities_group = attach_command_docs(
    activities_group,
    summary="Activities (Control Plane).",
    examples=[
        CommandExampleMeta(
            command="tm activities list --user-id USER_ID",
            description=
            "List recent activities for a user in the Control Plane.",
        ),
    ],
)
