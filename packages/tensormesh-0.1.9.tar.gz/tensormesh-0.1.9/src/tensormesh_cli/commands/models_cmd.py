from __future__ import annotations

import click

from tensormesh.types import DeployModelRequest
from tensormesh.types import ModelChatRequest
from tensormesh.types import ValidateModelNameRequest
from tensormesh_cli.commands._generated_controlplane_gap_cmd import \
    attach_generated_models_gap_commands
from tensormesh_cli.commands.click_helpers import json_input_options
from tensormesh_cli.commands.click_helpers import timeout_option
from tensormesh_cli.commands.click_helpers import user_id_option
from tensormesh_cli.commands.click_helpers import yes_option
from tensormesh_cli.commands.controlplane_actions import \
    confirm_and_execute_controlplane_sdk_and_render
from tensormesh_cli.commands.controlplane_actions import \
    execute_controlplane_sdk_and_render
from tensormesh_cli.commands.controlplane_actions import \
    execute_controlplane_sdk_and_render_with_text_extractor
from tensormesh_cli.commands.request_utils import \
    load_command_json_object_required
from tensormesh_cli.commands.request_utils import \
    load_validated_command_json_request
from tensormesh_cli.commands.request_utils import require_non_empty_value
from tensormesh_cli.commands.request_utils import require_payload_string_fields
from tensormesh_cli.commands.request_utils import resolve_command_payload
from tensormesh_cli.docs_meta import attach_command_docs
from tensormesh_cli.docs_meta import CommandExampleMeta


@click.group(name="models")
def models_group() -> None:
    """Control Plane model resources."""
    pass


@models_group.command(name="list")
@user_id_option(help="Optional user id to scope results.")
@timeout_option()
@click.pass_context
def list_cmd(ctx: click.Context, user_id: str | None,
             timeout_s: float | None) -> None:
    """List models (GET /v1/models)."""
    execute_controlplane_sdk_and_render(
        ctx,
        lambda client: client.control_plane.models.list(
            user_id=user_id,
            timeout=timeout_s,
        ),
        default="json",
    )


@models_group.command(name="get")
@click.argument("model_id", type=str)
@user_id_option(help="Optional user id to scope results.")
@timeout_option()
@click.pass_context
def get_cmd(ctx: click.Context, model_id: str, user_id: str | None,
            timeout_s: float | None) -> None:
    """Get a model by id (GET /v1/models/{modelId})."""
    mid = require_non_empty_value(ctx=ctx, value=model_id, label="MODEL_ID")
    execute_controlplane_sdk_and_render(
        ctx,
        lambda client: client.control_plane.models.get(
            mid,
            user_id=user_id,
            timeout=timeout_s,
        ),
        default="json",
    )


@models_group.command(name="delete")
@click.argument("model_id", type=str)
@user_id_option(help="Optional user id to scope authorization.")
@yes_option()
@timeout_option()
@click.pass_context
def delete_cmd(
    ctx: click.Context,
    model_id: str,
    user_id: str | None,
    yes: bool,
    timeout_s: float | None,
) -> None:
    """Delete a model (DELETE /v1/models/{modelId})."""
    mid = require_non_empty_value(ctx=ctx, value=model_id, label="MODEL_ID")
    confirm_and_execute_controlplane_sdk_and_render(
        ctx,
        yes=yes,
        message=
        f"Delete model {mid!r}? This may stop inference and may be irreversible.",
        action=lambda client: client.control_plane.models.delete(
            mid,
            user_id=user_id,
            timeout=timeout_s,
        ),
        default="json",
    )


@models_group.command(name="validate-name")
@click.option("--name",
              "model_name",
              default=None,
              help="Model name to validate.")
@user_id_option(help="Optional user id for authorization.")
@json_input_options(
    json_help="JSON request body or @file.json (overrides --name).",
    file_help="Read JSON request body from file (overrides --name).",
)
@timeout_option()
@click.pass_context
def validate_name_cmd(
    ctx: click.Context,
    model_name: str | None,
    user_id: str | None,
    json_arg: str | None,
    file_path: str | None,
    timeout_s: float | None,
) -> None:
    """Validate a model name (POST /v1/models:validate)."""
    request_payload = resolve_command_payload(
        ctx=ctx,
        json_arg=json_arg,
        file_path=file_path,
        build_from_values=lambda: ValidateModelNameRequest(
            model_name=model_name or "",
            user_id=user_id,
        ),
        build_from_json=lambda body: ValidateModelNameRequest.from_dict(body),
        value_error_message=lambda exc:
        "Missing model name. Provide --name or a JSON body via --json/--file/stdin."
        if "modelName" in str(exc) else str(exc),
        to_payload=lambda request: request.to_dict(),
    )
    require_payload_string_fields(
        ctx=ctx,
        payload=request_payload,
        field_names=("modelName", ),
        message=
        "Missing model name. Provide --name or a JSON body via --json/--file/stdin.",
    )
    execute_controlplane_sdk_and_render(
        ctx,
        lambda client: client.control_plane.models.validate_name(
            request=request_payload,
            timeout=timeout_s,
        ),
        default="json",
    )


@models_group.command(name="search-by-infra")
@json_input_options(
    json_help="JSON request body or @file.json.",
    file_help="Read JSON request body from file.",
)
@timeout_option()
@click.pass_context
def search_by_infra_cmd(
    ctx: click.Context,
    json_arg: str | None,
    file_path: str | None,
    timeout_s: float | None,
) -> None:
    """Search models by infrastructure (POST /v1/models:search-by-infra)."""
    body_obj = load_command_json_object_required(
        ctx=ctx,
        json_arg=json_arg,
        file_path=file_path,
    )
    execute_controlplane_sdk_and_render(
        ctx,
        lambda client: client.control_plane.models.search_by_infra(
            request=body_obj,
            timeout=timeout_s,
        ),
        default="json",
    )


@models_group.command(name="chat")
@click.argument("model_id", type=str)
@click.option("--message",
              "message",
              default=None,
              help="Chat message body (string).")
@user_id_option(help="Optional user id for authorization.")
@json_input_options(
    json_help="JSON request body or @file.json (overrides --message).",
    file_help="Read JSON request body from file (overrides --message).",
)
@timeout_option()
@click.pass_context
def chat_with_model_cmd(
    ctx: click.Context,
    model_id: str,
    message: str | None,
    user_id: str | None,
    json_arg: str | None,
    file_path: str | None,
    timeout_s: float | None,
) -> None:
    """Chat with a deployed model (POST /v1/models/{modelId}:chat)."""
    mid = require_non_empty_value(ctx=ctx, value=model_id, label="MODEL_ID")
    request_payload = resolve_command_payload(
        ctx=ctx,
        json_arg=json_arg,
        file_path=file_path,
        build_from_values=lambda: ModelChatRequest(
            body=message or "",
            user_id=user_id,
        ),
        build_from_json=lambda body: ModelChatRequest.from_dict(body),
        value_error_message=lambda exc:
        "No input provided. Use --message, --json/--file, or pipe JSON on stdin."
        if "body" in str(exc) else str(exc),
        to_payload=lambda request: request.to_dict(),
    )
    require_payload_string_fields(
        ctx=ctx,
        payload=request_payload,
        field_names=("body", ),
        message=
        "No input provided. Use --message, --json/--file, or pipe JSON on stdin.",
    )
    execute_controlplane_sdk_and_render_with_text_extractor(
        ctx,
        lambda client: client.control_plane.models.chat(
            mid,
            request=request_payload,
            timeout=timeout_s,
        ),
        extract_text=lambda data: data.get("response") if isinstance(
            data, dict) and isinstance(data.get("response"), str) else None,
    )


@models_group.command(name="deploy")
@yes_option()
@json_input_options(
    json_help="JSON request body or @file.json.",
    file_help="Read JSON request body from file.",
)
@timeout_option()
@click.pass_context
def deploy_cmd(
    ctx: click.Context,
    yes: bool,
    json_arg: str | None,
    file_path: str | None,
    timeout_s: float | None,
) -> None:
    """Create a model deployment (POST /v1/models)."""
    request_payload = load_validated_command_json_request(
        ctx=ctx,
        json_arg=json_arg,
        file_path=file_path,
        validate_from_dict=DeployModelRequest.from_dict,
        message="Deploy request must be a JSON object.",
    )
    confirm_and_execute_controlplane_sdk_and_render(
        ctx,
        yes=yes,
        message="Create a model deployment? This may incur cost.",
        action=lambda client: client.control_plane.models.deploy(
            request=request_payload,
            timeout=timeout_s,
        ),
        default="json",
    )


models_group = attach_command_docs(
    models_group,
    summary="Control Plane model resources.",
    examples=[
        CommandExampleMeta(
            command="tm models list",
            description="List models visible from the Control Plane.",
        ),
    ],
)

attach_generated_models_gap_commands(models_group)
