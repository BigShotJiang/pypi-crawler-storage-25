from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from tensormesh_cli import auth
from tensormesh_cli.config.constants import DEFAULT_SERVERLESS_BASE
from tensormesh_cli.config.model import ResolvedConfig
from tensormesh_cli.http.gateway import normalize_gateway_user_id
from tensormesh_cli.output_utils import redact_secret

__all__ = [
    "build_auth_status_lines",
    "ControlPlaneAuthInspection",
    "GatewayInspection",
    "ReadinessSnapshot",
    "ServerlessInspection",
    "build_doctor_status",
    "build_first_request_command",
    "build_gateway_setup_steps",
    "build_gateway_summary_line",
    "build_serverless_first_request_command",
    "build_serverless_summary_line",
    "build_control_plane_summary_line",
    "controlplane_status_data",
    "gateway_status_data",
    "inspect_controlplane_auth",
    "inspect_gateway_config",
    "inspect_readiness",
    "inspect_serverless_config",
    "serverless_status_data",
]


@dataclass(frozen=True)
class ControlPlaneAuthInspection:
    auth_json_path: str
    auth_json_exists: bool
    access_token_present: bool
    error: str | None


@dataclass(frozen=True)
class GatewayInspection:
    api_key_present: bool
    user_id_present: bool
    user_id_value: str | None
    user_id_valid: bool
    user_id_error: str | None
    user_id_derived_from_controlplane: bool
    model_id_present: bool

    @property
    def ready_for_direct_request(self) -> bool:
        return self.api_key_present and self.user_id_ready and self.model_id_present

    @property
    def user_id_ready(self) -> bool:
        return self.user_id_valid or self.user_id_derived_from_controlplane


@dataclass(frozen=True)
class ReadinessSnapshot:
    auth_state: ControlPlaneAuthInspection
    gateway_state: GatewayInspection

    @property
    def control_plane_ready(self) -> bool:
        return self.auth_state.access_token_present and self.auth_state.error is None

    @property
    def gateway_ready(self) -> bool:
        return self.gateway_state.api_key_present and self.gateway_state.user_id_ready

    @property
    def overall_ready(self) -> bool:
        return self.control_plane_ready and self.gateway_ready

    @property
    def ready_for_direct_request(self) -> bool:
        return self.gateway_state.ready_for_direct_request

    @property
    def auth_error_warning(self) -> str | None:
        if self.auth_state.error is None:
            return None
        return f"control_plane_auth_json invalid ({self.auth_state.error})"

    @property
    def gateway_user_warning(self) -> str | None:
        return self.gateway_state.user_id_error

    def build_common_warnings(
        self,
        *,
        include_auth_error: bool = True,
        include_gateway_user_error: bool = True,
    ) -> list[str]:
        warnings: list[str] = []
        if include_auth_error and self.auth_error_warning is not None:
            warnings.append(self.auth_error_warning)
        if include_gateway_user_error and self.gateway_user_warning is not None:
            warnings.append(self.gateway_user_warning)
        return warnings


@dataclass(frozen=True)
class ServerlessInspection:
    api_key_present: bool
    model_id_present: bool

    @property
    def ready_for_direct_request(self) -> bool:
        return self.api_key_present and self.model_id_present


def _present(value: str | None) -> bool:
    return bool((value or "").strip())


def inspect_controlplane_auth(
        auth_json_path: str | Path) -> ControlPlaneAuthInspection:
    path = Path(auth_json_path).expanduser()
    if not path.exists():
        return ControlPlaneAuthInspection(auth_json_path=str(path),
                                          auth_json_exists=False,
                                          access_token_present=False,
                                          error=None)
    try:
        access_token_present = auth.access_token(path) is not None
        error = None
    except RuntimeError as exc:
        access_token_present = False
        error = str(exc)
    return ControlPlaneAuthInspection(
        auth_json_path=str(path),
        auth_json_exists=True,
        access_token_present=access_token_present,
        error=error)


def inspect_gateway_config(
    cfg: ResolvedConfig,
    auth_state: ControlPlaneAuthInspection | None = None,
    *,
    api_key_override: str | None = None,
    user_id_override: str | None = None,
    model_id_override: str | None = None,
) -> GatewayInspection:
    api_key_value = ((api_key_override or "").strip()
                     or (cfg.gateway_api_key or "").strip())
    override_user_id_value = (user_id_override or "").strip() or None
    if override_user_id_value is not None:
        user_id_value = override_user_id_value
    else:
        user_id_value = (cfg.gateway_user_id or "").strip() or None
    user_id_valid = False
    user_id_error: str | None = None
    user_id_derived_from_controlplane = False
    if user_id_value is not None:
        try:
            normalize_gateway_user_id(user_id_value)
            user_id_valid = True
        except ValueError as exc:
            user_id_error = str(exc)
    elif (auth_state is not None and auth_state.access_token_present
          and auth_state.error is None):
        user_id_derived_from_controlplane = True
    model_id_value = ((model_id_override or "").strip()
                      or (cfg.gateway_model_id or "").strip())
    return GatewayInspection(
        api_key_present=_present(api_key_value),
        user_id_present=user_id_value is not None,
        user_id_value=user_id_value,
        user_id_valid=user_id_valid,
        user_id_error=user_id_error,
        user_id_derived_from_controlplane=user_id_derived_from_controlplane,
        model_id_present=_present(model_id_value),
    )


def inspect_readiness(cfg: ResolvedConfig, ) -> ReadinessSnapshot:
    auth_state = inspect_controlplane_auth(cfg.controlplane_auth_json)
    return ReadinessSnapshot(
        auth_state=auth_state,
        gateway_state=inspect_gateway_config(cfg, auth_state),
    )


def inspect_serverless_config(
    cfg: ResolvedConfig,
    *,
    api_key_override: str | None = None,
    model_id_override: str | None = None,
) -> ServerlessInspection:
    return ServerlessInspection(
        api_key_present=_present((api_key_override or "").strip()
                                 or cfg.gateway_api_key),
        model_id_present=_present((model_id_override or "").strip()),
    )


def controlplane_status_data(
    cfg: ResolvedConfig,
    auth_state: ControlPlaneAuthInspection,
) -> dict[str, Any]:
    return {
        "base": cfg.controlplane_base,
        "auth_json_path": auth_state.auth_json_path,
        "auth_json_exists": auth_state.auth_json_exists,
        "access_token_present": auth_state.access_token_present,
        "auth_json_source": cfg.sources.controlplane_auth_json,
        "error": auth_state.error,
    }


def gateway_status_data(
    cfg: ResolvedConfig,
    gateway_state: GatewayInspection,
    *,
    base: str | None = None,
    base_source: str | None = None,
    api_key_source: str | None = None,
    api_key_value: str | None = None,
    user_id_source: str | None = None,
    model_id_source: str | None = None,
    model_id_value: str | None = None,
) -> dict[str, Any]:
    return {
        "provider":
        cfg.gateway_provider,
        "base":
        base or cfg.gateway_base,
        "base_source":
        base_source or cfg.sources.gateway_base,
        "api_key_present":
        gateway_state.api_key_present,
        "api_key_source":
        api_key_source or cfg.sources.gateway_api_key,
        "api_key_value":
        redact_secret(api_key_value if api_key_value is not None else cfg.
                      gateway_api_key),
        "user_id_present":
        gateway_state.user_id_present,
        "user_id_value":
        gateway_state.user_id_value,
        "user_id_valid":
        gateway_state.user_id_valid,
        "user_id_ready":
        gateway_state.user_id_ready,
        "user_id_derived_from_controlplane":
        gateway_state.user_id_derived_from_controlplane,
        "user_id_error":
        gateway_state.user_id_error,
        "user_id_source":
        user_id_source or cfg.sources.gateway_user_id
        or ("derived-from:controlplane-auth"
            if gateway_state.user_id_derived_from_controlplane else None),
        "model_id_present":
        gateway_state.model_id_present,
        "model_id_source":
        model_id_source or cfg.sources.gateway_model_id,
        "model_id_value":
        model_id_value if model_id_value is not None else cfg.gateway_model_id,
    }


def serverless_status_data(
    cfg: ResolvedConfig,
    serverless_state: ServerlessInspection,
    *,
    base: str | None = None,
    base_source: str | None = None,
    api_key_source: str | None = None,
    api_key_value: str | None = None,
    model_id_source: str | None = None,
    model_id_value: str | None = None,
) -> dict[str, Any]:
    return {
        "base":
        base or DEFAULT_SERVERLESS_BASE,
        "base_source":
        base_source or "default:serverless-base",
        "api_key_present":
        serverless_state.api_key_present,
        "api_key_source":
        api_key_source or cfg.sources.gateway_api_key,
        "api_key_value":
        redact_secret(api_key_value if api_key_value is not None else cfg.
                      gateway_api_key),
        "model_id_present":
        serverless_state.model_id_present,
        "model_id_source":
        model_id_source,
        "model_id_value":
        model_id_value,
        "model_requirement":
        "explicit --model required",
    }


def build_control_plane_summary_line(
    *,
    base: str,
    access_token_present: bool,
    auth_json_path: str | None = None,
    auth_json_source: str | None = None,
) -> str:
    line = (
        "Control Plane: "
        f"base={base} token={'present' if access_token_present else 'missing'}"
    )
    if auth_json_path is not None:
        line += f" auth_json={auth_json_path}"
    if auth_json_source is not None:
        line += f" source={auth_json_source}"
    return line


def build_gateway_summary_line(
    *,
    provider: str,
    base: str,
    gateway_state: GatewayInspection,
    model_present: bool | None = None,
) -> str:
    resolved_model_present = (gateway_state.model_id_present
                              if model_present is None else model_present)
    if gateway_state.user_id_valid:
        user_id_status = "present"
    elif gateway_state.user_id_derived_from_controlplane:
        user_id_status = "derived"
    else:
        user_id_status = "missing"
    return (
        "Gateway: "
        f"provider={provider} base={base} "
        f"api_key={'present' if gateway_state.api_key_present else 'missing'} "
        f"user_id={user_id_status} "
        f"model_id={'present' if resolved_model_present else 'missing'}")


def build_serverless_summary_line(
    *,
    base: str,
    api_key_present: bool,
    model_id_present: bool,
) -> str:
    return (
        "Serverless: "
        f"base={base} api_key={'present' if api_key_present else 'missing'} "
        f"model={'present' if model_id_present else 'missing'}")


def build_auth_status_lines(
    cfg: ResolvedConfig,
    snapshot: ReadinessSnapshot,
) -> list[str]:
    return [
        build_control_plane_summary_line(
            base=cfg.controlplane_base,
            access_token_present=snapshot.auth_state.access_token_present,
            auth_json_path=snapshot.auth_state.auth_json_path,
            auth_json_source=cfg.sources.controlplane_auth_json,
        ),
        build_gateway_summary_line(
            provider=cfg.gateway_provider,
            base=cfg.gateway_base,
            gateway_state=snapshot.gateway_state,
        ),
    ]


def build_doctor_status(
    cfg: ResolvedConfig,
    snapshot: ReadinessSnapshot,
) -> tuple[list[str], list[str], list[str]]:
    auth_state = snapshot.auth_state
    gateway_state = snapshot.gateway_state

    control_plane_blockers: list[str] = []
    if not auth_state.access_token_present:
        control_plane_blockers.append(
            "control_plane_access_token (run `tm auth login`)")

    gateway_blockers: list[str] = []
    if not gateway_state.api_key_present:
        gateway_blockers.append(
            "gateway_api_key (set in config/runtime or run `tm init --sync`)")
    if (not gateway_state.user_id_present
            and not gateway_state.user_id_derived_from_controlplane):
        gateway_blockers.append(
            "gateway_user_id (set in config/runtime or run `tm init --sync`)")
    elif not gateway_state.user_id_valid:
        gateway_blockers.append(
            "gateway_user_id invalid (set a UUID in config/runtime or rerun `tm init --sync`)"
        )

    missing: list[str] = []
    warnings = snapshot.build_common_warnings(include_gateway_user_error=False)
    if snapshot.overall_ready:
        if not snapshot.control_plane_ready:
            warnings.extend(
                f"{item} is optional for direct gateway requests but required for Control Plane commands and `--model @latest`"
                for item in control_plane_blockers)
        if not snapshot.gateway_ready:
            warnings.extend(
                f"{item} is optional for Control Plane-only workflows but required for direct inference requests"
                for item in gateway_blockers)
    else:
        missing.extend(control_plane_blockers)
        missing.extend(gateway_blockers)

    return missing, warnings, [
        build_control_plane_summary_line(
            base=cfg.controlplane_base,
            access_token_present=auth_state.access_token_present,
        ),
        build_gateway_summary_line(
            provider=cfg.gateway_provider,
            base=cfg.gateway_base,
            gateway_state=gateway_state,
        ),
    ]


def build_first_request_command(
    *,
    model_available: bool,
    model_override: str | None = None,
) -> str:
    if model_override is not None:
        rendered_model = (model_override if model_override == "@latest" else
                          f'"{model_override}"')
        return (f"tm infer chat --model {rendered_model} "
                "--json '[{\"role\":\"user\",\"content\":\"Say hello.\"}]'")
    if model_available:
        return "tm infer chat --json '[{\"role\":\"user\",\"content\":\"Say hello.\"}]'"
    return ('tm infer chat --model "YOUR_SERVED_GATEWAY_MODEL_NAME" '
            "--json '[{\"role\":\"user\",\"content\":\"Say hello.\"}]'")


def build_serverless_first_request_command(
    *,
    api_key_available: bool,
    model_id: str | None = None,
    base_url: str | None = None,
) -> str:
    command = "tm infer chat --surface serverless "
    if base_url:
        command += f'--base-url "{base_url}" '
    if not api_key_available:
        command += '--api-key "YOUR_INFERENCE_API_KEY" '
    command += '--model '
    if model_id and model_id.strip():
        command += f'"{model_id}" '
    else:
        command += '"YOUR_SERVERLESS_MODEL_NAME" '
    command += "--json '[{\"role\":\"user\",\"content\":\"Say hello.\"}]'"
    return command


def build_gateway_setup_steps(
    gateway_state: GatewayInspection,
    *,
    controlplane_ready: bool,
    include_model_id: bool = True,
) -> list[str]:
    needs_runtime_sync = (not gateway_state.api_key_present
                          or (include_model_id
                              and not gateway_state.model_id_present)
                          or not gateway_state.user_id_ready)
    if not needs_runtime_sync:
        return []
    if controlplane_ready:
        return ["tm init --sync"]
    return ["tm auth login", "tm init --sync"]
