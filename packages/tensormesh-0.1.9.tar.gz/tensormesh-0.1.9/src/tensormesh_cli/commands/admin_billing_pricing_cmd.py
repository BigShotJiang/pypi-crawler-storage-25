from __future__ import annotations

import click

from tensormesh.types import GpuPricingUpsertRequest
from tensormesh.types import ServerlessPricingUpsertRequest
from tensormesh_cli.commands.click_helpers import cloud_provider_option
from tensormesh_cli.commands.click_helpers import gpu_type_option
from tensormesh_cli.commands.click_helpers import json_input_options
from tensormesh_cli.commands.click_helpers import timeout_option
from tensormesh_cli.commands.click_helpers import yes_option
from tensormesh_cli.commands.controlplane_actions import \
    confirm_and_execute_controlplane_sdk_and_render
from tensormesh_cli.commands.controlplane_actions import \
    execute_controlplane_sdk_and_render
from tensormesh_cli.commands.request_utils import \
    load_validated_command_json_request


@click.group(name="pricing")
def admin_pricing_group() -> None:
    """Admin GPU pricing."""
    pass


@admin_pricing_group.command(name="upsert")
@click.option("--method",
              type=click.Choice(["post", "put"], case_sensitive=False),
              default="post",
              show_default=True,
              help="HTTP method to use for upsert.")
@yes_option()
@json_input_options(
    json_help="JSON request body or @file.json.",
    file_help="Read JSON request body from file.",
)
@timeout_option()
@click.pass_context
def pricing_upsert_cmd(
    ctx: click.Context,
    method: str,
    yes: bool,
    json_arg: str | None,
    file_path: str | None,
    timeout_s: float | None,
) -> None:
    """Insert/update GPU pricing via validated request object (POST|PUT /v1/admin/billing/gpu-pricing)."""
    request_payload = load_validated_command_json_request(
        ctx=ctx,
        json_arg=json_arg,
        file_path=file_path,
        validate_from_dict=GpuPricingUpsertRequest.from_dict,
        wrap_key="pricing",
    )
    confirm_and_execute_controlplane_sdk_and_render(
        ctx,
        yes=yes,
        message=
        "Upsert GPU pricing? This affects billing and may impact costs.",
        action=lambda client: client.control_plane.admin.billing.pricing.gpu.
        upsert(
            request=request_payload,
            method=method.upper(),
            timeout=timeout_s,
        ),
        default="json",
    )


@admin_pricing_group.command(name="delete")
@gpu_type_option(help="GPU type enum (path param).", required=True)
@cloud_provider_option(help="Cloud provider enum (path param).", required=True)
@yes_option()
@timeout_option()
@click.pass_context
def pricing_delete_cmd(
    ctx: click.Context,
    gpu_type: str,
    cloud_provider: str,
    yes: bool,
    timeout_s: float | None,
) -> None:
    """Delete GPU pricing (DELETE /v1/admin/billing/gpu-pricing/{gpuType}/{cloudProvider})."""
    confirm_and_execute_controlplane_sdk_and_render(
        ctx,
        yes=yes,
        message=
        f"Delete GPU pricing gpuType={gpu_type!r} cloudProvider={cloud_provider!r}?",
        action=lambda client: client.control_plane.admin.billing.pricing.gpu.
        delete(
            gpu_type,
            cloud_provider,
            timeout=timeout_s,
        ),
        default="json",
    )


@admin_pricing_group.group(name="serverless")
def admin_serverless_pricing_group() -> None:
    """Admin serverless pricing."""
    pass


@admin_serverless_pricing_group.command(name="list")
@click.option("--model", default=None, help="Filter by model name.")
@click.option("--active-only",
              is_flag=True,
              default=False,
              help="Return active pricing only.")
@timeout_option()
@click.pass_context
def admin_serverless_pricing_list_cmd(
    ctx: click.Context,
    model: str | None,
    active_only: bool,
    timeout_s: float | None,
) -> None:
    """List serverless pricing as admin (GET /v1/admin/billing/serverless-pricing)."""
    execute_controlplane_sdk_and_render(
        ctx,
        lambda client: client.control_plane.admin.billing.pricing.serverless.
        list(
            model=(model or "").strip() or None,
            active_only=True if active_only else None,
            timeout=timeout_s,
        ),
        default="json",
    )


@admin_serverless_pricing_group.command(name="upsert")
@click.option("--method",
              type=click.Choice(["post", "put"], case_sensitive=False),
              default="post",
              show_default=True,
              help="HTTP method to use for upsert.")
@yes_option()
@json_input_options(
    json_help="JSON request body or @file.json.",
    file_help="Read JSON request body from file.",
)
@timeout_option()
@click.pass_context
def admin_serverless_pricing_upsert_cmd(
    ctx: click.Context,
    method: str,
    yes: bool,
    json_arg: str | None,
    file_path: str | None,
    timeout_s: float | None,
) -> None:
    """Insert/update serverless pricing via validated request object (POST|PUT /v1/admin/billing/serverless-pricing)."""
    request_payload = load_validated_command_json_request(
        ctx=ctx,
        json_arg=json_arg,
        file_path=file_path,
        validate_from_dict=ServerlessPricingUpsertRequest.from_dict,
        wrap_key="pricing",
    )
    confirm_and_execute_controlplane_sdk_and_render(
        ctx,
        yes=yes,
        message=
        "Upsert serverless pricing? This affects billing and may impact costs.",
        action=lambda client: client.control_plane.admin.billing.pricing.
        serverless.upsert(
            request=request_payload,
            method=method.upper(),
            timeout=timeout_s,
        ),
        default="json",
    )


@admin_serverless_pricing_group.command(name="delete")
@click.option("--id",
              "pricing_id",
              required=True,
              help="Serverless pricing id.")
@yes_option()
@timeout_option()
@click.pass_context
def admin_serverless_pricing_delete_cmd(
    ctx: click.Context,
    pricing_id: str,
    yes: bool,
    timeout_s: float | None,
) -> None:
    """Delete serverless pricing (DELETE /v1/admin/billing/serverless-pricing?id=...)."""
    confirm_and_execute_controlplane_sdk_and_render(
        ctx,
        yes=yes,
        message=f"Delete serverless pricing id={pricing_id!r}?",
        action=lambda client: client.control_plane.admin.billing.pricing.
        serverless.delete(
            pricing_id,
            timeout=timeout_s,
        ),
        default="json",
    )
