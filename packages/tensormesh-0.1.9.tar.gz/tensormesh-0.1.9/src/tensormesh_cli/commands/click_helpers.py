from __future__ import annotations

from typing import Any, Callable

import click

__all__ = [
    "cloud_provider_option",
    "exit_status_option",
    "gpu_type_option",
    "json_input_options",
    "page_option",
    "size_option",
    "start_time_option",
    "step_seconds_option",
    "end_time_option",
    "target_user_id_option",
    "timeout_option",
    "user_id_option",
    "yes_option",
]


def timeout_option(
    *,
    help: str = "HTTP timeout in seconds.",
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    return click.option(
        "--timeout",
        "timeout_s",
        type=float,
        default=None,
        help=help,
    )


def user_id_option(
    *,
    help: str,
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    return click.option("--user-id", "user_id", default=None, help=help)


def target_user_id_option(
    *,
    help: str,
    param_name: str = "target_user_id",
    multiple: bool = False,
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    return click.option(
        "--target-user-id",
        param_name,
        default=None if not multiple else (),
        multiple=multiple,
        help=help,
    )


def start_time_option(
    *,
    help: str,
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    return click.option("--start-time", "start_time", default=None, help=help)


def end_time_option(
    *,
    help: str,
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    return click.option("--end-time", "end_time", default=None, help=help)


def page_option(
    *,
    help: str = "Page number.",
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    return click.option("--page", type=int, default=None, help=help)


def size_option(
    *,
    help: str = "Page size.",
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    return click.option("--size", type=int, default=None, help=help)


def step_seconds_option(
    *,
    help: str,
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    return click.option("--step-seconds",
                        "step_seconds",
                        type=int,
                        default=None,
                        help=help)


def cloud_provider_option(
    *,
    help: str,
    required: bool = False,
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    return click.option("--cloud-provider",
                        "cloud_provider",
                        default=None,
                        required=required,
                        help=help)


def gpu_type_option(
    *,
    help: str,
    required: bool = False,
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    return click.option("--gpu-type",
                        "gpu_type",
                        default=None,
                        required=required,
                        help=help)


def yes_option(
    *,
    help: str = "Skip confirmation prompt.",
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    return click.option("--yes", is_flag=True, default=False, help=help)


def exit_status_option(
    *,
    help: str = "Exit non-zero when checks report a not-ready state.",
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    return click.option("--exit-status",
                        "exit_status",
                        is_flag=True,
                        default=False,
                        help=help)


def json_input_options(
    *,
    json_help: str,
    file_help: str,
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:

    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        wrapped = click.option(
            "--file",
            "file_path",
            type=click.Path(dir_okay=False, path_type=str),
            default=None,
            help=file_help,
        )(func)
        return click.option(
            "--json",
            "json_arg",
            default=None,
            help=
            f"{json_help.rstrip()} When omitted, reads piped stdin if available.",
        )(wrapped)

    return decorator
