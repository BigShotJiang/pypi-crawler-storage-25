from __future__ import annotations

import click

from tensormesh.types import AdminBalanceAddRequest
from tensormesh.types import AdminBalancesLookupRequest
from tensormesh_cli.commands.click_helpers import json_input_options
from tensormesh_cli.commands.click_helpers import target_user_id_option
from tensormesh_cli.commands.click_helpers import timeout_option
from tensormesh_cli.commands.click_helpers import user_id_option
from tensormesh_cli.commands.click_helpers import yes_option
from tensormesh_cli.commands.controlplane_actions import \
    confirm_and_execute_controlplane_sdk_and_render
from tensormesh_cli.commands.controlplane_actions import \
    execute_controlplane_sdk_and_render
from tensormesh_cli.commands.request_utils import require_payload
from tensormesh_cli.commands.request_utils import require_payload_string_fields
from tensormesh_cli.commands.request_utils import resolve_command_payload
from tensormesh_cli.commands.request_utils import resolve_command_request


@click.group(name="balances")
def admin_balances_group() -> None:
    """Admin user balances."""
    pass


@admin_balances_group.command(name="get")
@user_id_option(help="Admin user id for authorization (optional).")
@target_user_id_option(help="Target user id (repeatable).",
                       param_name="target_user_ids",
                       multiple=True)
@json_input_options(
    json_help="JSON request body or @file.json (overrides flags).",
    file_help="Read JSON request body from file (overrides flags).",
)
@timeout_option()
@click.pass_context
def balances_get_cmd(
    ctx: click.Context,
    user_id: str | None,
    target_user_ids: tuple[str, ...],
    json_arg: str | None,
    file_path: str | None,
    timeout_s: float | None,
) -> None:
    """Get balances for users (POST /v1/admin/billing/balances)."""
    resolved = resolve_command_request(
        ctx=ctx,
        json_arg=json_arg,
        file_path=file_path,
        build_from_values=lambda: AdminBalancesLookupRequest(
            user_id=user_id,
            target_user_ids=list(target_user_ids) or None,
        ),
        build_from_json=lambda body: AdminBalancesLookupRequest.from_dict(body
                                                                          ),
        to_payload=lambda request: request.to_dict(),
    )
    execute_controlplane_sdk_and_render(
        ctx,
        lambda client: client.control_plane.admin.billing.balances.get(
            request=resolved.payload,
            timeout=timeout_s,
        ),
        default="json",
    )


@admin_balances_group.command(name="add")
@user_id_option(help="Admin user id for authorization (optional).")
@target_user_id_option(help="Target user id.")
@click.option("--amount",
              type=float,
              default=None,
              help="Amount to add (number).")
@yes_option()
@json_input_options(
    json_help="JSON request body or @file.json (overrides flags).",
    file_help="Read JSON request body from file (overrides flags).",
)
@timeout_option()
@click.pass_context
def balances_add_cmd(
    ctx: click.Context,
    user_id: str | None,
    target_user_id: str | None,
    amount: float | None,
    yes: bool,
    json_arg: str | None,
    file_path: str | None,
    timeout_s: float | None,
) -> None:
    """Add balance for a user (POST /v1/admin/billing/balances:add)."""
    request_payload = resolve_command_payload(
        ctx=ctx,
        json_arg=json_arg,
        file_path=file_path,
        build_from_values=lambda: AdminBalanceAddRequest(
            target_user_id=target_user_id or "",
            amount=amount,
            user_id=user_id,
        ),
        build_from_json=lambda body: AdminBalanceAddRequest.from_dict(body),
        value_error_message=lambda exc:
        "Missing required fields. Provide --target-user-id and --amount (or pass JSON via --json/--file/stdin)."
        if "targetUserId" in str(exc) or "amount" in str(exc) else str(exc),
        to_payload=lambda request: request.to_dict(),
    )
    require_payload_string_fields(
        ctx=ctx,
        payload=request_payload,
        field_names=("targetUserId", ),
        message=
        "Missing required fields. Provide --target-user-id and --amount (or pass JSON via --json/--file/stdin).",
    )
    require_payload(
        ctx=ctx,
        payload=request_payload,
        predicate=lambda payload: payload.get("amount") is not None,
        message=
        "Missing required fields. Provide --target-user-id and --amount (or pass JSON via --json/--file/stdin).",
    )
    confirm_and_execute_controlplane_sdk_and_render(
        ctx,
        yes=yes,
        message="Add user balance? This affects billing and may impact costs.",
        action=lambda client: client.control_plane.admin.billing.balances.add(
            request=request_payload,
            timeout=timeout_s,
        ),
        default="json",
    )
