from __future__ import annotations

from collections.abc import Callable
from collections.abc import Mapping
import json
import sys
from typing import Any

import click
import requests

from tensormesh._reasoning import LeadingReasoningTextFilter
from tensormesh.types import ChatCompletionResponse

_GATEWAY_STATUS_HINTS: dict[int, str] = {
    401:
    "set --api-key, configure gateway_api_key, or run `tm init --sync`. Control plane tokens (`tm auth login`) do not authenticate the gateway.",
    400:
    "ensure X-User-Id is set via --user-id, config/runtime, or `tm auth login` plus `tm init --sync` so tm can derive it.",
    404:
    "ensure X-User-Id is set via --user-id, config/runtime, or `tm auth login` plus `tm init --sync` so tm can derive it.",
}


def build_payload(
    *,
    source: Any,
    model: str | None,
    stream: bool,
) -> dict[str, Any]:
    if isinstance(source, list):
        if not model:
            raise ValueError(
                "Missing --model (required when input is a messages array).")
        payload: dict[str, Any] = {"model": model, "messages": source}
    elif isinstance(source, dict):
        payload = dict(source)
        if model:
            payload["model"] = model
        if "model" not in payload or not isinstance(
                payload.get("model"), str) or not payload["model"].strip():
            raise ValueError(
                "Missing model. Provide --model or include it in the JSON payload."
            )
        if "messages" not in payload:
            raise ValueError(
                "Missing messages. Provide a messages array or include it in the JSON payload."
            )
    else:
        raise ValueError(
            "Input JSON must be an object (request) or an array (messages).")

    if stream:
        payload["stream"] = True

    return payload


def _stream_choice_text(choice: dict[str, Any]) -> str | None:
    delta = choice.get("delta")
    if isinstance(delta, dict) and isinstance(delta.get("content"), str):
        return delta["content"]

    message = choice.get("message")
    if isinstance(message, dict) and isinstance(message.get("content"), str):
        return message["content"]

    return None


def _iter_sse_events(resp: requests.Response) -> Any:
    for line in resp.iter_lines(decode_unicode=True):
        if not line or line.startswith(":") or not line.startswith("data:"):
            continue
        data = line[len("data:"):].strip()
        if data == "[DONE]":
            return
        try:
            event = json.loads(data)
        except json.JSONDecodeError:
            raise click.ClickException(
                f"Invalid stream event JSON: {data}") from None

        if isinstance(event, dict) and "error" in event:
            raise click.ClickException(f"Stream error: {event.get('error')}")
        yield event


def stream_sse(resp: requests.Response) -> None:
    filters: dict[int, LeadingReasoningTextFilter] = {}
    for event in _iter_sse_events(resp):
        choices = event.get("choices") if isinstance(event, dict) else None
        if not isinstance(choices, list):
            continue
        for choice in choices:
            if not isinstance(choice, dict):
                continue
            choice_index = choice.get("index")
            if not isinstance(choice_index, int):
                choice_index = 0
            chunk_text = filters.setdefault(
                choice_index,
                LeadingReasoningTextFilter(),
            ).feed(_stream_choice_text(choice))
            if chunk_text is not None:
                sys.stdout.write(chunk_text)
                sys.stdout.flush()


def stream_sse_text(
    resp: requests.Response,
    *,
    extract_text: Callable[[Any], str | None],
) -> None:
    for event in _iter_sse_events(resp):
        chunk_text = extract_text(event)
        if chunk_text:
            sys.stdout.write(chunk_text)
            sys.stdout.flush()


def normalize_chat_completion_response_payload(data: Any) -> Any:
    if not isinstance(data, Mapping):
        return data
    if not {"id", "created", "model", "choices"} <= set(data.keys()):
        return data
    try:
        return ChatCompletionResponse.from_dict(data).to_dict()
    except (KeyError, TypeError, ValueError):
        return data
