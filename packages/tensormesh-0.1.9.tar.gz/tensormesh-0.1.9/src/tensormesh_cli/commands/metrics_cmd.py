from __future__ import annotations

import click

from tensormesh_cli.commands.click_helpers import end_time_option
from tensormesh_cli.commands.click_helpers import start_time_option
from tensormesh_cli.commands.click_helpers import step_seconds_option
from tensormesh_cli.commands.click_helpers import timeout_option
from tensormesh_cli.commands.click_helpers import user_id_option
from tensormesh_cli.commands.controlplane_actions import \
    execute_controlplane_sdk_and_render
from tensormesh_cli.commands.request_utils import require_non_empty_value
from tensormesh_cli.docs_meta import attach_command_docs
from tensormesh_cli.docs_meta import CommandExampleMeta


@click.group(name="metrics")
def metrics_group() -> None:
    """Observability metrics (Control Plane)."""
    pass


@metrics_group.command(name="deployment")
@click.argument("deployment_id", type=str)
@user_id_option(help="Optional user id to scope results.")
@start_time_option(help="Start time (RFC3339 / timestamp) depending on API.")
@end_time_option(help="End time (RFC3339 / timestamp) depending on API.")
@step_seconds_option(help="Metrics step size in seconds.")
@timeout_option()
@click.pass_context
def metrics_deployment_cmd(
    ctx: click.Context,
    deployment_id: str,
    user_id: str | None,
    start_time: str | None,
    end_time: str | None,
    step_seconds: int | None,
    timeout_s: float | None,
) -> None:
    """Fetch deployment metrics (GET /v1/observability/deployments/{deploymentId}/metrics)."""
    did = require_non_empty_value(
        ctx=ctx,
        value=deployment_id,
        label="DEPLOYMENT_ID",
    )
    execute_controlplane_sdk_and_render(
        ctx,
        lambda client: client.control_plane.observability.deployments.metrics.
        get(
            did,
            user_id=user_id,
            start_time=start_time,
            end_time=end_time,
            step_seconds=step_seconds,
            timeout=timeout_s,
        ),
        default="json",
    )


@metrics_group.command(name="user")
@user_id_option(help="Optional user id to scope results.")
@start_time_option(help="Start time (RFC3339 / timestamp) depending on API.")
@end_time_option(help="End time (RFC3339 / timestamp) depending on API.")
@step_seconds_option(help="Metrics step size in seconds.")
@timeout_option()
@click.pass_context
def metrics_user_cmd(
    ctx: click.Context,
    user_id: str | None,
    start_time: str | None,
    end_time: str | None,
    step_seconds: int | None,
    timeout_s: float | None,
) -> None:
    """Fetch user metrics (GET /v1/observability/users/metrics)."""
    execute_controlplane_sdk_and_render(
        ctx,
        lambda client: client.control_plane.observability.users.metrics.get(
            user_id=user_id,
            start_time=start_time,
            end_time=end_time,
            step_seconds=step_seconds,
            timeout=timeout_s,
        ),
        default="json",
    )


metrics_group = attach_command_docs(
    metrics_group,
    summary="Observability metrics (Control Plane).",
    examples=[
        CommandExampleMeta(
            command="tm metrics deployment DEPLOYMENT_ID",
            description="Fetch deployment-level observability metrics.",
        ),
    ],
)
