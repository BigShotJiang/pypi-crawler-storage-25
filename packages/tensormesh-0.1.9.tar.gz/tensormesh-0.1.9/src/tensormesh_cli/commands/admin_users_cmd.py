from __future__ import annotations

import click

from tensormesh.types import AdminUserChangeRoleRequest
from tensormesh_cli.commands.click_helpers import json_input_options
from tensormesh_cli.commands.click_helpers import target_user_id_option
from tensormesh_cli.commands.click_helpers import timeout_option
from tensormesh_cli.commands.click_helpers import user_id_option
from tensormesh_cli.commands.click_helpers import yes_option
from tensormesh_cli.commands.controlplane_actions import \
    confirm_and_execute_controlplane_sdk_and_render
from tensormesh_cli.commands.controlplane_actions import \
    execute_controlplane_sdk_and_render
from tensormesh_cli.commands.request_utils import require_payload_string_fields
from tensormesh_cli.commands.request_utils import resolve_command_payload


@click.group(name="users")
def admin_users_group() -> None:
    """Admin user tools."""
    pass


@admin_users_group.command(name="list")
@timeout_option()
@click.pass_context
def admin_users_list_cmd(ctx: click.Context, timeout_s: float | None) -> None:
    """List users (GET /v1/admin/users)."""
    execute_controlplane_sdk_and_render(
        ctx,
        lambda client: client.control_plane.admin.users.list(timeout=timeout_s
                                                             ),
        default="json",
    )


@admin_users_group.command(name="change-role")
@target_user_id_option(help="Target user id.")
@click.option("--target-user-role",
              "target_user_role",
              type=click.Choice([
                  "USER_ROLE_USER",
                  "USER_ROLE_ADMIN",
                  "USER_ROLE_SUPER_ADMIN",
              ],
                                case_sensitive=False),
              default=None,
              help="Target user role enum.")
@user_id_option(help="Admin user id for authorization (optional).")
@yes_option()
@json_input_options(
    json_help="JSON request body or @file.json (overrides flags).",
    file_help="Read JSON request body from file (overrides flags).",
)
@timeout_option()
@click.pass_context
def admin_users_change_role_cmd(
    ctx: click.Context,
    target_user_id: str | None,
    target_user_role: str | None,
    user_id: str | None,
    yes: bool,
    json_arg: str | None,
    file_path: str | None,
    timeout_s: float | None,
) -> None:
    """Change a user's role (POST /v1/admin/users/change_role)."""
    request_payload = resolve_command_payload(
        ctx=ctx,
        json_arg=json_arg,
        file_path=file_path,
        build_from_values=lambda: AdminUserChangeRoleRequest(
            target_user_id=target_user_id or "",
            target_user_role=target_user_role or "",
            user_id=user_id,
        ),
        build_from_json=lambda body: AdminUserChangeRoleRequest.from_dict(body
                                                                          ),
        value_error_message=lambda exc:
        "Missing required fields. Provide --target-user-id and --target-user-role (or pass JSON via --json/--file/stdin)."
        if "targetUserId" in str(exc) or "targetUserRole" in str(exc) else str(
            exc),
        to_payload=lambda request: request.to_dict(),
    )
    require_payload_string_fields(
        ctx=ctx,
        payload=request_payload,
        field_names=("targetUserId", "targetUserRole"),
        message=
        "Missing required fields. Provide --target-user-id and --target-user-role (or pass JSON via --json/--file/stdin).",
    )
    confirm_and_execute_controlplane_sdk_and_render(
        ctx,
        yes=yes,
        message=(f"Change role for user {request_payload['targetUserId']!r} "
                 f"to {request_payload['targetUserRole']!r}?"),
        action=lambda client: client.control_plane.admin.users.change_role(
            request=request_payload,
            timeout=timeout_s,
        ),
        default="json",
    )
