from __future__ import annotations

import json
import math
import time
from typing import Any

import click

from tensormesh_cli.commands.click_helpers import end_time_option
from tensormesh_cli.commands.click_helpers import start_time_option
from tensormesh_cli.commands.click_helpers import timeout_option
from tensormesh_cli.commands.click_helpers import user_id_option
from tensormesh_cli.commands.controlplane_actions import \
    execute_controlplane_sdk_and_render
from tensormesh_cli.commands.request_utils import build_query_params
from tensormesh_cli.commands.request_utils import map_controlplane_params
from tensormesh_cli.controlplane import execute_controlplane_sdk
from tensormesh_cli.docs_meta import attach_command_docs
from tensormesh_cli.docs_meta import CommandExampleMeta
from tensormesh_cli.render import context_output
from tensormesh_cli.render import echo_output

_LOG_DIRECTION_CHOICES = [
    "asc",
    "desc",
    "LOG_DIRECTION_UNSPECIFIED",
    "LOG_DIRECTION_FORWARD",
    "LOG_DIRECTION_BACKWARD",
]


def _render_log_item(item: object) -> str:
    if isinstance(item, dict):
        ts = item.get("timestamp")
        msg = item.get("message")
        ts_s = str(ts).strip() if isinstance(ts, str) else ""
        msg_s = str(msg).rstrip() if isinstance(msg, str) else ""
        if ts_s and msg_s:
            return f"{ts_s} {msg_s}"
        if msg_s:
            return msg_s
    elif isinstance(item, str):
        return item.rstrip()
    return str(item)


def _iter_log_lines(data: object) -> list[str]:
    # Observability spec: {logs: [{timestamp, message}, ...]}
    if not isinstance(data, dict):
        raise ValueError("expected a JSON object with a top-level logs list")

    logs = data.get("logs")
    if not isinstance(logs, list):
        raise ValueError("expected response shape {logs:[...]}")

    out: list[str] = []
    for item in logs:
        out.append(_render_log_item(item))
    return out


def _logs_params(
    *,
    user_id: str | None,
    start_time: str | None,
    end_time: str | None,
    limit: int | None,
    direction: str | None,
) -> dict[str, str]:
    normalized_direction = None
    if direction:
        lowered = direction.lower()
        if lowered == "asc":
            normalized_direction = "LOG_DIRECTION_FORWARD"
        elif lowered == "desc":
            normalized_direction = "LOG_DIRECTION_BACKWARD"
        else:
            normalized_direction = direction.upper()
    return build_query_params(**map_controlplane_params(
        user_id=user_id,
        start_time=start_time,
        end_time=end_time,
        limit=limit,
        direction=normalized_direction,
    ))


def _fetch_logs_data(
    ctx: click.Context,
    *,
    deployment_id: str,
    params: dict[str, str],
    timeout_s: float | None,
) -> list[Any]:
    try:
        data, _ = execute_controlplane_sdk(
            ctx,
            lambda client: client.control_plane.observability.deployments.logs.
            list(
                deployment_id,
                user_id=params.get("userId"),
                start_time=params.get("startTime"),
                end_time=params.get("endTime"),
                limit=int(params["limit"]) if "limit" in params else None,
                direction=params.get("direction"),
                timeout=timeout_s,
            ),
        )
    except click.ClickException as exc:
        message = exc.message
        if message.startswith("Invalid JSON response: expected JSON."):
            message = message.replace("Invalid JSON response",
                                      "Invalid logs response", 1)
        raise click.ClickException(message) from exc
    return [
        item.to_dict()
        if hasattr(item, "to_dict") and callable(item.to_dict) else item
        for item in data
    ]


def _follow_item_key(item: object) -> str:
    if isinstance(item, dict):
        return json.dumps(item,
                          sort_keys=True,
                          ensure_ascii=False,
                          default=str)
    if isinstance(item, str):
        return item
    return repr(item)


def _emit_follow_log_item(*, output: str, item: object) -> None:
    if output in ("text", "raw"):
        line = _render_log_item(item)
        if line:
            click.echo(line)
        return
    echo_output(output=output, data=item)


def _emit_follow_logs_iteration(
    data: list[Any],
    seen: set[str],
    *,
    output: str,
) -> None:
    if not isinstance(data, list):
        raise click.ClickException(
            "Invalid logs response: expected response shape {logs:[...]}")

    for item in data:
        key = _follow_item_key(item)
        if key in seen:
            continue
        _emit_follow_log_item(output=output, item=item)
        seen.add(key)


@click.command(name="logs")
@click.argument("deployment_id", type=str)
@click.option("-f",
              "--follow",
              is_flag=True,
              default=False,
              help="Follow logs (polls periodically).")
@click.option("--interval",
              "interval_s",
              type=float,
              default=2.0,
              show_default=True,
              help="Polling interval in seconds when following.")
@user_id_option(help="Optional user id to scope results.")
@start_time_option(help="Start time (RFC3339 / timestamp) depending on API.")
@end_time_option(help="End time (RFC3339 / timestamp) depending on API.")
@click.option("--limit",
              type=int,
              default=None,
              help="Max number of log lines/events.")
@click.option(
    "--direction",
    type=click.Choice(_LOG_DIRECTION_CHOICES, case_sensitive=False),
    default=None,
    help=
    "Sort direction. Accepts friendly aliases asc/desc or LOG_DIRECTION_* values."
)
@timeout_option()
@click.pass_context
def logs_cmd(
    ctx: click.Context,
    deployment_id: str,
    follow: bool,
    interval_s: float,
    user_id: str | None,
    start_time: str | None,
    end_time: str | None,
    limit: int | None,
    direction: str | None,
    timeout_s: float | None,
) -> None:
    """Fetch deployment logs (GET /v1/observability/deployments/{deploymentId}/logs)."""
    did = (deployment_id or "").strip()
    if not did:
        raise click.UsageError("DEPLOYMENT_ID is required.", ctx=ctx)

    if follow and (not math.isfinite(interval_s) or interval_s <= 0):
        raise click.UsageError(
            "`--interval` must be a finite number greater than 0.",
            ctx=ctx,
        )

    if follow and limit is None:
        limit = 200
    if follow and not direction:
        direction = "asc"
    params = _logs_params(user_id=user_id,
                          start_time=start_time,
                          end_time=end_time,
                          limit=limit,
                          direction=direction)

    if not follow:
        execute_controlplane_sdk_and_render(
            ctx,
            lambda client: client.control_plane.observability.deployments.logs.
            list(
                did,
                user_id=params.get("userId"),
                start_time=params.get("startTime"),
                end_time=params.get("endTime"),
                limit=int(params["limit"]) if "limit" in params else None,
                direction=params.get("direction"),
                timeout=timeout_s,
            ),
            default="json",
        )
        return

    # Follow mode: poll and print log lines as they appear (best-effort de-dupe).
    output = context_output(ctx)
    seen: set[str] = set()
    try:
        while True:
            data = _fetch_logs_data(
                ctx,
                deployment_id=did,
                params=params,
                timeout_s=timeout_s,
            )
            _emit_follow_logs_iteration(data, seen, output=output)

            time.sleep(interval_s)
    except KeyboardInterrupt:
        return


logs_cmd = attach_command_docs(
    logs_cmd,
    summary=
    "Fetch deployment logs (GET /v1/observability/deployments/{deploymentId}/logs).",
    caveats=[
        "`asc` maps to `LOG_DIRECTION_FORWARD` and `desc` maps to `LOG_DIRECTION_BACKWARD` before the request is sent."
    ],
    examples=[
        CommandExampleMeta(
            command="tm logs DEPLOYMENT_ID",
            description="Fetch logs for a deployment from the Control Plane.",
        ),
        CommandExampleMeta(
            command="tm logs DEPLOYMENT_ID --direction desc",
            description=
            "Fetch newest logs first while still sending the published LOG_DIRECTION enum upstream.",
        ),
    ],
)
