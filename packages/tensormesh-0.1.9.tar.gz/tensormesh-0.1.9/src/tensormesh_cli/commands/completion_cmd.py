from __future__ import annotations

from typing import Literal

import click

from tensormesh_cli.docs_meta import attach_command_docs
from tensormesh_cli.docs_meta import CommandExampleMeta


@click.command(name="completion")
@click.argument("shell",
                type=click.Choice(["bash", "zsh", "fish"],
                                  case_sensitive=False))
@click.option(
    "--prog",
    "prog_name",
    default="tm",
    show_default=True,
    help="Program name to generate completions for (usually 'tm').",
)
def completion_cmd(shell: Literal["bash", "zsh", "fish"],
                   prog_name: str) -> None:
    """Print a shell completion script for Bash/Zsh/Fish.

    Examples:

      source <(tm completion bash)
      source <(tm completion zsh)
      tm completion fish | source
    """
    shell_l = shell.lower()
    prog = (prog_name or "tm").strip() or "tm"
    # Click's docs: env var is _<PROG_NAME>_COMPLETE where PROG_NAME is the
    # executable name in uppercase with dashes replaced by underscores.
    complete_var = f"_{prog.replace('-', '_').upper()}_COMPLETE"
    if shell_l in ("bash", "zsh"):
        click.echo(f'eval "$({complete_var}={shell_l}_source {prog})"')
        return
    click.echo(f"env {complete_var}={shell_l}_source {prog} | source")


completion_cmd = attach_command_docs(
    completion_cmd,
    summary="Print a shell completion script for Bash/Zsh/Fish.",
    examples=[
        CommandExampleMeta(
            command="tm completion zsh",
            description="Print shell completion output for Zsh.",
        ),
    ],
)
