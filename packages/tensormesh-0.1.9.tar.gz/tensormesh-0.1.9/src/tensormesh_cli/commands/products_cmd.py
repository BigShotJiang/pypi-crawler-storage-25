from __future__ import annotations

import click

from tensormesh_cli.commands.click_helpers import timeout_option
from tensormesh_cli.commands.controlplane_actions import \
    execute_controlplane_sdk_and_render
from tensormesh_cli.docs_meta import attach_command_docs
from tensormesh_cli.docs_meta import CommandExampleMeta


@click.group(name="products")
def products_group() -> None:
    """Products (Control Plane)."""
    pass


@products_group.command(name="list")
@timeout_option()
@click.pass_context
def products_list_cmd(ctx: click.Context, timeout_s: float | None) -> None:
    """List available products (GET /v1/products)."""
    execute_controlplane_sdk_and_render(
        ctx,
        lambda client: client.control_plane.products.list(timeout=timeout_s),
        default="json",
    )


products_group = attach_command_docs(
    products_group,
    summary="Products (Control Plane).",
    examples=[
        CommandExampleMeta(
            command="tm products list",
            description="List products available through the Control Plane.",
        ),
    ],
)
