from __future__ import annotations

import click

from tensormesh.types import Product
from tensormesh.types import ProductUpsertRequest
from tensormesh_cli.commands.click_helpers import json_input_options
from tensormesh_cli.commands.click_helpers import timeout_option
from tensormesh_cli.commands.click_helpers import yes_option
from tensormesh_cli.commands.controlplane_actions import \
    confirm_and_execute_controlplane_sdk_and_render
from tensormesh_cli.commands.controlplane_actions import \
    execute_controlplane_sdk_and_render
from tensormesh_cli.commands.request_utils import load_command_json_required
from tensormesh_cli.commands.request_utils import require_non_empty_value
from tensormesh_cli.commands.request_utils import require_payload
from tensormesh_cli.commands.request_utils import resolve_command_payload


@click.group(name="products")
def admin_products_group() -> None:
    """Admin product tools."""
    pass


@admin_products_group.command(name="list")
@timeout_option()
@click.pass_context
def admin_products_list_cmd(ctx: click.Context,
                            timeout_s: float | None) -> None:
    """List products (GET /v1/admin/products)."""
    execute_controlplane_sdk_and_render(
        ctx,
        lambda client: client.control_plane.admin.products.list(timeout=
                                                                timeout_s),
        default="json",
    )


@admin_products_group.command(name="upsert")
@click.option("--id", "product_id", default=None, help="Product id.")
@click.option("--name", default=None, help="Product name.")
@click.option("--required-gpu-num",
              "required_gpu_num",
              type=int,
              default=None,
              help="Required GPU count.")
@click.option("--family", default=None, help="Product family.")
@click.option("--active/--inactive",
              "active",
              default=None,
              help="Set product active state.")
@click.option("--spec-json",
              "spec_json",
              default=None,
              help="JSON object for product-specific configuration.")
@yes_option()
@json_input_options(
    json_help=
    "JSON request body (either {\"product\":{...}} or a raw product object) or @file.json.",
    file_help="Read JSON request body from file.",
)
@timeout_option()
@click.pass_context
def admin_products_upsert_cmd(
    ctx: click.Context,
    product_id: str | None,
    name: str | None,
    required_gpu_num: int | None,
    family: str | None,
    active: bool | None,
    spec_json: str | None,
    yes: bool,
    json_arg: str | None,
    file_path: str | None,
    timeout_s: float | None,
) -> None:
    """Upsert a product (POST /v1/admin/products)."""
    spec_obj: object | None = None
    if spec_json:
        spec_obj = load_command_json_required(ctx=ctx,
                                              json_arg=spec_json,
                                              file_path=None)

    request_payload = resolve_command_payload(
        ctx=ctx,
        json_arg=json_arg,
        file_path=file_path,
        build_from_values=lambda: ProductUpsertRequest(product=Product(
            id=product_id,
            name=name,
            required_gpu_num=required_gpu_num,
            family=family,
            is_active=active,
            spec=spec_obj if isinstance(spec_obj, dict) else None,
        )),
        build_from_json=lambda body: ProductUpsertRequest.from_dict(
            body if isinstance(body, dict) and "product" in body else
            {"product": body}, ),
        to_payload=lambda request: request.to_dict(),
    )
    require_payload(
        ctx=ctx,
        payload=request_payload,
        predicate=lambda payload: bool(payload.get("product")),
        message="Request body must define a product.",
    )
    confirm_and_execute_controlplane_sdk_and_render(
        ctx,
        yes=yes,
        message="Upsert product? This may affect billing/admin behavior.",
        action=lambda client: client.control_plane.admin.products.upsert(
            request=request_payload,
            timeout=timeout_s,
        ),
        default="json",
    )


@admin_products_group.command(name="delete")
@click.argument("product_id")
@yes_option()
@timeout_option()
@click.pass_context
def admin_products_delete_cmd(
    ctx: click.Context,
    product_id: str,
    yes: bool,
    timeout_s: float | None,
) -> None:
    """Delete a product (DELETE /v1/products/{id})."""
    pid = require_non_empty_value(ctx=ctx,
                                  value=product_id,
                                  label="PRODUCT_ID")
    confirm_and_execute_controlplane_sdk_and_render(
        ctx,
        yes=yes,
        message=f"Delete product {pid!r}?",
        action=lambda client: client.control_plane.products.delete(
            pid,
            timeout=timeout_s,
        ),
        default="json",
    )
