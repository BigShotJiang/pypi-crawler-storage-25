from __future__ import annotations

import click

from tensormesh.types import UpdateUserProfileRequest
from tensormesh_cli.commands.click_helpers import json_input_options
from tensormesh_cli.commands.click_helpers import timeout_option
from tensormesh_cli.commands.controlplane_actions import \
    execute_controlplane_sdk_and_render
from tensormesh_cli.commands.request_utils import require_non_empty_value
from tensormesh_cli.commands.request_utils import require_payload
from tensormesh_cli.commands.request_utils import resolve_command_payload
from tensormesh_cli.commands.user_api_keys_cmd import user_api_keys_group
from tensormesh_cli.docs_meta import attach_command_docs
from tensormesh_cli.docs_meta import CommandExampleMeta


@click.group(name="users")
def users_group() -> None:
    """User profile resources (Control Plane)."""
    pass


@users_group.command(name="update")
@click.argument("user_id", type=str)
@click.option("--first-name", default=None, help="First name.")
@click.option("--last-name", default=None, help="Last name.")
@click.option("--display-name", default=None, help="Display name.")
@click.option("--company", default=None, help="Company.")
@json_input_options(
    json_help="JSON request body or @file.json (overrides flags).",
    file_help="Read JSON request body from file (overrides flags).",
)
@timeout_option()
@click.pass_context
def update_cmd(
    ctx: click.Context,
    user_id: str,
    first_name: str | None,
    last_name: str | None,
    display_name: str | None,
    company: str | None,
    json_arg: str | None,
    file_path: str | None,
    timeout_s: float | None,
) -> None:
    """Update a user profile (PUT /v1/users/{userId})."""
    uid = require_non_empty_value(ctx=ctx, value=user_id, label="USER_ID")
    request_payload = resolve_command_payload(
        ctx=ctx,
        json_arg=json_arg,
        file_path=file_path,
        build_from_values=lambda: UpdateUserProfileRequest(
            first_name=first_name,
            last_name=last_name,
            display_name=display_name,
            company=company,
        ),
        build_from_json=lambda body: UpdateUserProfileRequest.from_dict(body),
        value_error_message=lambda exc:
        "No updates provided. Use flags or pass JSON via --json/--file/stdin."
        if "must include at least one field" in str(exc) else str(exc),
        to_payload=lambda request: request.to_dict(),
    )
    require_payload(
        ctx=ctx,
        payload=request_payload,
        predicate=bool,
        message=
        "No updates provided. Use flags or pass JSON via --json/--file/stdin.",
    )
    execute_controlplane_sdk_and_render(
        ctx,
        lambda client: client.control_plane.users.update(
            uid,
            request=request_payload,
            timeout=timeout_s,
        ),
        default="json",
    )


@users_group.command(name="accept-tos")
@timeout_option()
@click.pass_context
def accept_tos_cmd(ctx: click.Context, timeout_s: float | None) -> None:
    """Accept terms of service (POST /v1/users/accept-tos)."""
    execute_controlplane_sdk_and_render(
        ctx,
        lambda client: client.control_plane.users.accept_tos(timeout=timeout_s
                                                             ),
        default="json",
    )


users_group.add_command(user_api_keys_group)

users_group = attach_command_docs(
    users_group,
    summary="User profile resources (Control Plane).",
    examples=[
        CommandExampleMeta(
            command="tm users api-keys list",
            description="List user API keys from the Control Plane.",
        ),
    ],
)
