from __future__ import annotations

import click

from tensormesh.types import CreateUserApiKeyRequest
from tensormesh_cli.commands.click_helpers import json_input_options
from tensormesh_cli.commands.click_helpers import timeout_option
from tensormesh_cli.commands.click_helpers import user_id_option
from tensormesh_cli.commands.click_helpers import yes_option
from tensormesh_cli.commands.controlplane_actions import confirm_or_abort
from tensormesh_cli.commands.controlplane_actions import \
    execute_controlplane_sdk_and_render
from tensormesh_cli.commands.request_utils import require_payload_string_fields
from tensormesh_cli.commands.request_utils import resolve_command_payload
from tensormesh_cli.commands.request_utils import resolve_command_request
from tensormesh_cli.docs_meta import attach_command_docs
from tensormesh_cli.docs_meta import CommandExampleMeta


@click.group(name="api-keys")
def user_api_keys_group() -> None:
    """User API key management."""
    pass


@user_api_keys_group.command(name="list")
@user_id_option(help="Optional user id to scope authorization.")
@click.option("--include-deleted",
              is_flag=True,
              default=False,
              help="Include soft-deleted keys.")
@timeout_option()
@click.pass_context
def list_user_api_keys_cmd(
    ctx: click.Context,
    user_id: str | None,
    include_deleted: bool,
    timeout_s: float | None,
) -> None:
    """List user API keys (GET /v1/users/api-keys)."""
    execute_controlplane_sdk_and_render(
        ctx,
        lambda client: client.control_plane.users.api_keys.list(
            user_id=user_id,
            include_deleted=True if include_deleted else None,
            timeout=timeout_s,
        ),
        default="json",
    )


@user_api_keys_group.command(name="create")
@user_id_option(help="User id for the new API key.")
@click.option("--name", default=None, help="Optional display name.")
@click.option("--scope",
              "scopes",
              multiple=True,
              help="Optional scope. Repeat for multiple scopes.")
@click.option("--expires-at",
              "expires_at",
              default=None,
              help="Optional expiration timestamp.")
@yes_option()
@json_input_options(
    json_help="JSON request body or @file.json (overrides flags).",
    file_help="Read JSON request body from file (overrides flags).",
)
@timeout_option()
@click.pass_context
def create_user_api_key_cmd(
    ctx: click.Context,
    user_id: str | None,
    name: str | None,
    scopes: tuple[str, ...],
    expires_at: str | None,
    yes: bool,
    json_arg: str | None,
    file_path: str | None,
    timeout_s: float | None,
) -> None:
    """Create a user API key (POST /v1/users/api-keys)."""
    resolved = resolve_command_request(
        ctx=ctx,
        json_arg=json_arg,
        file_path=file_path,
        build_from_values=lambda: CreateUserApiKeyRequest(
            user_id=(user_id or "").strip(),
            name=name,
            scopes=list(scopes) or None,
            expires_at=expires_at,
        ),
        build_from_json=lambda body: CreateUserApiKeyRequest.from_dict(body),
        value_error_message=lambda exc:
        "Missing user id. Provide --user-id or pass JSON via --json/--file/stdin."
        if "userId" in str(exc) else str(exc),
        to_payload=lambda request: request.to_dict(),
    )
    require_payload_string_fields(
        ctx=ctx,
        payload=resolved.payload,
        field_names=("userId", ),
        message=
        "Missing user id. Provide --user-id or pass JSON via --json/--file/stdin.",
    )
    confirm_or_abort(
        yes=yes,
        message="Create a user API key?",
    )
    execute_controlplane_sdk_and_render(
        ctx,
        lambda client: client.control_plane.users.api_keys.create(
            request=resolved.payload,
            timeout=timeout_s,
        ),
        default="json",
    )


@user_api_keys_group.command(name="delete")
@click.option("--api-key", "api_key", default=None, help="API key to delete.")
@user_id_option(help="Optional user id for the key owner.")
@yes_option()
@json_input_options(
    json_help="JSON request body or @file.json (overrides flags).",
    file_help="Read JSON request body from file (overrides flags).",
)
@timeout_option()
@click.pass_context
def delete_user_api_key_cmd(
    ctx: click.Context,
    api_key: str | None,
    user_id: str | None,
    yes: bool,
    json_arg: str | None,
    file_path: str | None,
    timeout_s: float | None,
) -> None:
    """Delete a user API key (DELETE /v1/users/api-keys)."""
    request_payload = resolve_command_payload(
        ctx=ctx,
        json_arg=json_arg,
        file_path=file_path,
        build_from_values=lambda: {
            "apiKey": api_key,
            "userId": user_id,
        },
        build_from_json=lambda body: body,
        to_payload=lambda payload: payload,
    )
    require_payload_string_fields(
        ctx=ctx,
        payload=request_payload,
        field_names=("apiKey", ),
        message=
        "Missing API key. Provide --api-key or pass JSON via --json/--file/stdin.",
    )
    resolved_api_key = str(request_payload["apiKey"]).strip()
    confirm_or_abort(yes=yes,
                     message=f"Delete user API key {resolved_api_key!r}?")
    execute_controlplane_sdk_and_render(
        ctx,
        lambda client: client.control_plane.users.api_keys.delete(
            api_key=resolved_api_key,
            user_id=(str(request_payload.get("userId")).strip() or None)
            if request_payload.get("userId") is not None else None,
            timeout=timeout_s,
        ),
        default="json",
    )


user_api_keys_group = attach_command_docs(
    user_api_keys_group,
    summary="User API key management.",
    examples=[
        CommandExampleMeta(
            command="tm users api-keys list",
            description=
            "List user API keys for the current Control Plane identity.",
        ),
        CommandExampleMeta(
            command=
            "tm users api-keys create --user-id YOUR_USER_ID --name ci-key --scope read",
            description="Create a user API key for automation.",
        ),
    ],
)
