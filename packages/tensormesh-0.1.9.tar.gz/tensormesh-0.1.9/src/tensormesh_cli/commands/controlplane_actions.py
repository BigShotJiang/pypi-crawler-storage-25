from __future__ import annotations

from typing import Any, Callable

import click

import tensormesh_cli.controlplane as controlplane
from tensormesh_cli.render import context_output
from tensormesh_cli.render import echo_http_response_for_ctx
from tensormesh_cli.render import echo_http_response_with_text_extractor

__all__ = [
    "confirm_and_execute_controlplane_sdk_and_render",
    "confirm_or_abort",
    "execute_controlplane_sdk_and_render",
    "execute_controlplane_sdk_and_render_with_text_extractor",
]


def confirm_or_abort(*, yes: bool, message: str) -> None:
    if yes:
        return
    click.confirm(message, default=False, abort=True)


def execute_controlplane_sdk_and_render(
    ctx: click.Context,
    action: Callable[[Any], Any],
    *,
    default: str = "text",
) -> Any:
    result, resp = controlplane.execute_controlplane_sdk(ctx, action)
    if resp is None:
        raise click.ClickException(
            "SDK call did not produce a buffered response.")
    echo_http_response_for_ctx(ctx, resp, default=default)
    return result


def confirm_and_execute_controlplane_sdk_and_render(
    ctx: click.Context,
    *,
    yes: bool,
    message: str,
    action: Callable[[Any], Any],
    default: str = "text",
) -> Any:
    confirm_or_abort(yes=yes, message=message)
    return execute_controlplane_sdk_and_render(ctx, action, default=default)


def execute_controlplane_sdk_and_render_with_text_extractor(
        ctx: click.Context,
        action: Callable[[Any], Any],
        *,
        extract_text: Callable[[Any], str | None],
        structured_outputs: tuple[str, ...] = ("json", "yaml", "table"),
) -> Any:
    result, resp = controlplane.execute_controlplane_sdk(ctx, action)
    if resp is None:
        raise click.ClickException(
            "SDK call did not produce a buffered response.")
    echo_http_response_with_text_extractor(
        output=context_output(ctx),
        resp=resp,
        extract_text=extract_text,
        structured_outputs=structured_outputs,
    )
    return result
