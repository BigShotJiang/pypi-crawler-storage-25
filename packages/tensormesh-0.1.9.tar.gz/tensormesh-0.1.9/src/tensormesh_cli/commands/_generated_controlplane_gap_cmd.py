from __future__ import annotations

import click

from tensormesh.types import AdminSpendingSummaryRequest
from tensormesh.types import AttachStripePaymentMethodRequest
from tensormesh.types import ConfirmStripePaymentIntentRequest
from tensormesh.types import CreateStripePaymentIntentRequest
from tensormesh.types import CreateStripeSetupIntentRequest
from tensormesh.types import ModelCheckRequest
from tensormesh.types import UpdateBillingAddressRequest
from tensormesh_cli.commands.click_helpers import json_input_options
from tensormesh_cli.commands.click_helpers import page_option
from tensormesh_cli.commands.click_helpers import size_option
from tensormesh_cli.commands.click_helpers import target_user_id_option
from tensormesh_cli.commands.click_helpers import timeout_option
from tensormesh_cli.commands.click_helpers import user_id_option
from tensormesh_cli.commands.controlplane_actions import \
    execute_controlplane_sdk_and_render
from tensormesh_cli.commands.request_utils import \
    load_validated_command_json_request
from tensormesh_cli.commands.request_utils import require_non_empty_value
from tensormesh_cli.commands.request_utils import require_payload_string_fields
from tensormesh_cli.commands.request_utils import resolve_command_payload
from tensormesh_cli.docs_meta import attach_command_docs
from tensormesh_cli.docs_meta import CommandExampleMeta

__all__ = [
    "attach_generated_admin_billing_gap_commands",
    "attach_generated_admin_models_gap_commands",
    "attach_generated_billing_gap_commands",
    "attach_generated_models_gap_commands",
]


@click.command(name="get")
@user_id_option(help="Optional user id to scope authorization.")
@timeout_option()
@click.pass_context
def billing_address_get_cmd(ctx: click.Context, user_id: str | None,
                            timeout_s: float | None) -> None:
    """Get billing address (GET /v1/billing/address)."""
    execute_controlplane_sdk_and_render(
        ctx,
        lambda client: client.control_plane.billing.address.get(
            user_id=user_id,
            timeout=timeout_s,
        ),
        default="json",
    )


billing_address_get_cmd = attach_command_docs(
    billing_address_get_cmd,
    summary="Get billing address (GET /v1/billing/address).",
    examples=[
        CommandExampleMeta(
            command="tm billing address get",
            description="Fetch the current billing address.",
        ),
    ],
)


@click.command(name="update")
@json_input_options(
    json_help="JSON request body or @file.json.",
    file_help="Read JSON request body from file.",
)
@timeout_option()
@click.pass_context
def billing_address_update_cmd(ctx: click.Context, json_arg: str | None,
                               file_path: str | None,
                               timeout_s: float | None) -> None:
    """Update billing address (PUT /v1/billing/address)."""
    request_payload = load_validated_command_json_request(
        ctx=ctx,
        json_arg=json_arg,
        file_path=file_path,
        validate_from_dict=UpdateBillingAddressRequest.from_dict,
        message="Billing address update request must be a JSON object.",
    )
    execute_controlplane_sdk_and_render(
        ctx,
        lambda client: client.control_plane.billing.address.update(
            request=request_payload,
            timeout=timeout_s,
        ),
        default="json",
    )


billing_address_update_cmd = attach_command_docs(
    billing_address_update_cmd,
    summary="Update billing address (PUT /v1/billing/address).",
    examples=[
        CommandExampleMeta(
            command=
            "tm billing address update --json '{\"address\":{\"line1\":\"123 Main St\",\"city\":\"HCMC\",\"country\":\"VN\"}}'",
            description="Update the billing address with a JSON request body.",
        ),
    ],
)


@click.command(name="get")
@user_id_option(help="Optional user id to scope authorization.")
@timeout_option()
@click.pass_context
def billing_stripe_customer_get_cmd(ctx: click.Context, user_id: str | None,
                                    timeout_s: float | None) -> None:
    """Get or create Stripe customer (GET /v1/billing/stripe/customers)."""
    execute_controlplane_sdk_and_render(
        ctx,
        lambda client: client.control_plane.billing.stripe.customer.
        get_or_create(
            user_id=user_id,
            timeout=timeout_s,
        ),
        default="json",
    )


billing_stripe_customer_get_cmd = attach_command_docs(
    billing_stripe_customer_get_cmd,
    summary="Get or create Stripe customer (GET /v1/billing/stripe/customers).",
)


@click.command(name="list")
@user_id_option(help="Optional user id to scope authorization.")
@timeout_option()
@click.pass_context
def billing_stripe_payment_methods_list_cmd(ctx: click.Context,
                                            user_id: str | None,
                                            timeout_s: float | None) -> None:
    """List Stripe payment methods (GET /v1/billing/stripe/customers/payment-methods)."""
    execute_controlplane_sdk_and_render(
        ctx,
        lambda client: client.control_plane.billing.stripe.payment_methods.
        list(
            user_id=user_id,
            timeout=timeout_s,
        ),
        default="json",
    )


billing_stripe_payment_methods_list_cmd = attach_command_docs(
    billing_stripe_payment_methods_list_cmd,
    summary=
    "List Stripe payment methods (GET /v1/billing/stripe/customers/payment-methods).",
)


@click.command(name="attach")
@click.option("--stripe-payment-method-id",
              "stripe_payment_method_id",
              default=None,
              help="Stripe payment method id to attach.")
@user_id_option(help="Optional user id to scope authorization.")
@json_input_options(
    json_help="JSON request body or @file.json (overrides scalar flags).",
    file_help="Read JSON request body from file (overrides scalar flags).",
)
@timeout_option()
@click.pass_context
def billing_stripe_payment_methods_attach_cmd(
    ctx: click.Context,
    stripe_payment_method_id: str | None,
    user_id: str | None,
    json_arg: str | None,
    file_path: str | None,
    timeout_s: float | None,
) -> None:
    """Attach Stripe payment method (POST /v1/billing/stripe/customers/payment-methods)."""
    request_payload = resolve_command_payload(
        ctx=ctx,
        json_arg=json_arg,
        file_path=file_path,
        build_from_values=lambda: AttachStripePaymentMethodRequest(
            stripe_payment_method_id=stripe_payment_method_id or "",
            user_id=user_id,
        ),
        build_from_json=lambda body: AttachStripePaymentMethodRequest.
        from_dict(body),
        value_error_message=lambda exc:
        "Missing Stripe payment method id. Provide --stripe-payment-method-id or a JSON body."
        if "stripePaymentMethodId" in str(exc) else str(exc),
        to_payload=lambda request: request.to_dict(),
    )
    require_payload_string_fields(
        ctx=ctx,
        payload=request_payload,
        field_names=("stripePaymentMethodId", ),
        message=
        "Missing Stripe payment method id. Provide --stripe-payment-method-id or a JSON body.",
    )
    execute_controlplane_sdk_and_render(
        ctx,
        lambda client: client.control_plane.billing.stripe.payment_methods.
        attach(
            request=request_payload,
            timeout=timeout_s,
        ),
        default="json",
    )


billing_stripe_payment_methods_attach_cmd = attach_command_docs(
    billing_stripe_payment_methods_attach_cmd,
    summary=
    "Attach Stripe payment method (POST /v1/billing/stripe/customers/payment-methods).",
)


@click.command(name="detach")
@click.option("--stripe-payment-method-id",
              "stripe_payment_method_id",
              default=None,
              help="Stripe payment method id to detach.")
@user_id_option(help="Optional user id to scope authorization.")
@timeout_option()
@click.pass_context
def billing_stripe_payment_methods_detach_cmd(
    ctx: click.Context,
    stripe_payment_method_id: str | None,
    user_id: str | None,
    timeout_s: float | None,
) -> None:
    """Detach Stripe payment method (DELETE /v1/billing/stripe/customers/payment-methods)."""
    payment_method_id = require_non_empty_value(
        ctx=ctx,
        value=stripe_payment_method_id or "",
        label="STRIPE_PAYMENT_METHOD_ID",
    )
    execute_controlplane_sdk_and_render(
        ctx,
        lambda client: client.control_plane.billing.stripe.payment_methods.
        detach(
            payment_method_id,
            user_id=user_id,
            timeout=timeout_s,
        ),
        default="json",
    )


billing_stripe_payment_methods_detach_cmd = attach_command_docs(
    billing_stripe_payment_methods_detach_cmd,
    summary=
    "Detach Stripe payment method (DELETE /v1/billing/stripe/customers/payment-methods).",
)


@click.command(name="create")
@json_input_options(
    json_help="JSON request body or @file.json.",
    file_help="Read JSON request body from file.",
)
@timeout_option()
@click.pass_context
def billing_stripe_payment_intents_create_cmd(ctx: click.Context,
                                              json_arg: str | None,
                                              file_path: str | None,
                                              timeout_s: float | None) -> None:
    """Create Stripe payment intent (POST /v1/billing/stripe/payment-intents)."""
    request_payload = load_validated_command_json_request(
        ctx=ctx,
        json_arg=json_arg,
        file_path=file_path,
        validate_from_dict=CreateStripePaymentIntentRequest.from_dict,
        message="Stripe payment intent request must be a JSON object.",
    )
    execute_controlplane_sdk_and_render(
        ctx,
        lambda client: client.control_plane.billing.stripe.payment_intents.
        create(
            request=request_payload,
            timeout=timeout_s,
        ),
        default="json",
    )


billing_stripe_payment_intents_create_cmd = attach_command_docs(
    billing_stripe_payment_intents_create_cmd,
    summary=
    "Create Stripe payment intent (POST /v1/billing/stripe/payment-intents).",
)


@click.command(name="confirm")
@click.option("--stripe-payment-intent-id",
              "stripe_payment_intent_id",
              default=None,
              help="Stripe payment intent id to confirm.")
@user_id_option(help="Optional user id to scope authorization.")
@json_input_options(
    json_help="JSON request body or @file.json (overrides scalar flags).",
    file_help="Read JSON request body from file (overrides scalar flags).",
)
@timeout_option()
@click.pass_context
def billing_stripe_payment_intents_confirm_cmd(
    ctx: click.Context,
    stripe_payment_intent_id: str | None,
    user_id: str | None,
    json_arg: str | None,
    file_path: str | None,
    timeout_s: float | None,
) -> None:
    """Confirm Stripe payment intent (POST /v1/billing/stripe/payment-intents/confirm)."""
    request_payload = resolve_command_payload(
        ctx=ctx,
        json_arg=json_arg,
        file_path=file_path,
        build_from_values=lambda: ConfirmStripePaymentIntentRequest(
            stripe_payment_intent_id=stripe_payment_intent_id or "",
            user_id=user_id,
        ),
        build_from_json=lambda body: ConfirmStripePaymentIntentRequest.
        from_dict(body),
        value_error_message=lambda exc:
        "Missing Stripe payment intent id. Provide --stripe-payment-intent-id or a JSON body."
        if "stripePaymentIntentId" in str(exc) else str(exc),
        to_payload=lambda request: request.to_dict(),
    )
    require_payload_string_fields(
        ctx=ctx,
        payload=request_payload,
        field_names=("stripePaymentIntentId", ),
        message=
        "Missing Stripe payment intent id. Provide --stripe-payment-intent-id or a JSON body.",
    )
    execute_controlplane_sdk_and_render(
        ctx,
        lambda client: client.control_plane.billing.stripe.payment_intents.
        confirm(
            request=request_payload,
            timeout=timeout_s,
        ),
        default="json",
    )


billing_stripe_payment_intents_confirm_cmd = attach_command_docs(
    billing_stripe_payment_intents_confirm_cmd,
    summary=
    "Confirm Stripe payment intent (POST /v1/billing/stripe/payment-intents/confirm).",
)


@click.command(name="create")
@user_id_option(help="Optional user id to scope authorization.")
@json_input_options(
    json_help="JSON request body or @file.json (overrides --user-id).",
    file_help="Read JSON request body from file (overrides --user-id).",
)
@timeout_option()
@click.pass_context
def billing_stripe_setup_intents_create_cmd(ctx: click.Context,
                                            user_id: str | None,
                                            json_arg: str | None,
                                            file_path: str | None,
                                            timeout_s: float | None) -> None:
    """Create Stripe setup intent (POST /v1/billing/stripe/setup-intents)."""
    request_payload = resolve_command_payload(
        ctx=ctx,
        json_arg=json_arg,
        file_path=file_path,
        build_from_values=lambda: CreateStripeSetupIntentRequest(user_id=
                                                                 user_id),
        build_from_json=lambda body: CreateStripeSetupIntentRequest.from_dict(
            body),
        to_payload=lambda request: request.to_dict(),
    )
    execute_controlplane_sdk_and_render(
        ctx,
        lambda client: client.control_plane.billing.stripe.setup_intents.
        create(
            request=request_payload,
            timeout=timeout_s,
        ),
        default="json",
    )


billing_stripe_setup_intents_create_cmd = attach_command_docs(
    billing_stripe_setup_intents_create_cmd,
    summary=
    "Create Stripe setup intent (POST /v1/billing/stripe/setup-intents).",
)


@click.command(name="summary")
@user_id_option(help="Optional admin user id to scope authorization.")
@target_user_id_option(
    help="Target user id to include in the spending summary.", multiple=True)
@json_input_options(
    json_help="JSON request body or @file.json (overrides scalar flags).",
    file_help="Read JSON request body from file (overrides scalar flags).",
)
@timeout_option()
@click.pass_context
def admin_billing_spending_summary_cmd(ctx: click.Context, user_id: str | None,
                                       target_user_id: tuple[str, ...],
                                       json_arg: str | None,
                                       file_path: str | None,
                                       timeout_s: float | None) -> None:
    """Get admin spending summary (POST /v1/admin/billing/spending/summary)."""
    request_payload = resolve_command_payload(
        ctx=ctx,
        json_arg=json_arg,
        file_path=file_path,
        build_from_values=lambda: AdminSpendingSummaryRequest(
            user_id=user_id,
            target_user_ids=list(target_user_id) or None,
        ),
        build_from_json=lambda body: AdminSpendingSummaryRequest.from_dict(body
                                                                           ),
        to_payload=lambda request: request.to_dict(),
    )
    execute_controlplane_sdk_and_render(
        ctx,
        lambda client: client.control_plane.admin.billing.spending.summary(
            request=request_payload,
            timeout=timeout_s,
        ),
        default="json",
    )


admin_billing_spending_summary_cmd = attach_command_docs(
    admin_billing_spending_summary_cmd,
    summary=
    "Get admin spending summary (POST /v1/admin/billing/spending/summary).",
)


@click.command(name="list")
@user_id_option(help="Optional admin user id to scope authorization.")
@page_option(help="Page number.")
@size_option(help="Page size.")
@timeout_option()
@click.pass_context
def admin_models_list_cmd(ctx: click.Context, user_id: str | None,
                          page: int | None, size: int | None,
                          timeout_s: float | None) -> None:
    """List models as admin (GET /v1/admin/models)."""
    execute_controlplane_sdk_and_render(
        ctx,
        lambda client: client.control_plane.admin.models.list(
            user_id=user_id,
            page=page,
            size=size,
            timeout=timeout_s,
        ),
        default="json",
    )


admin_models_list_cmd = attach_command_docs(
    admin_models_list_cmd,
    summary="List models as admin (GET /v1/admin/models).",
)


@click.command(name="check")
@json_input_options(
    json_help="JSON request body or @file.json.",
    file_help="Read JSON request body from file.",
)
@timeout_option()
@click.pass_context
def models_check_cmd(ctx: click.Context, json_arg: str | None,
                     file_path: str | None, timeout_s: float | None) -> None:
    """Check model deployment feasibility (POST /v1/models/check)."""
    request_payload = load_validated_command_json_request(
        ctx=ctx,
        json_arg=json_arg,
        file_path=file_path,
        validate_from_dict=ModelCheckRequest.from_dict,
        message="Model check request must be a JSON object.",
    )
    execute_controlplane_sdk_and_render(
        ctx,
        lambda client: client.control_plane.models.check(
            request=request_payload,
            timeout=timeout_s,
        ),
        default="json",
    )


models_check_cmd = attach_command_docs(
    models_check_cmd,
    summary="Check model deployment feasibility (POST /v1/models/check).",
)


def attach_generated_billing_gap_commands(billing_group: click.Group) -> None:

    @click.group(name="address")
    def address_group() -> None:
        """Billing address tools."""
        pass

    @click.group(name="customer")
    def stripe_customer_group() -> None:
        """Stripe customer tools."""
        pass

    @click.group(name="payment-methods")
    def stripe_payment_methods_group() -> None:
        """Stripe payment method tools."""
        pass

    @click.group(name="payment-intents")
    def stripe_payment_intents_group() -> None:
        """Stripe payment intent tools."""
        pass

    @click.group(name="setup-intents")
    def stripe_setup_intents_group() -> None:
        """Stripe setup intent tools."""
        pass

    @click.group(name="stripe")
    def stripe_group() -> None:
        """Stripe-backed billing tools."""
        pass

    address_group.add_command(billing_address_get_cmd)
    address_group.add_command(billing_address_update_cmd)
    stripe_customer_group.add_command(billing_stripe_customer_get_cmd)
    stripe_payment_methods_group.add_command(
        billing_stripe_payment_methods_list_cmd)
    stripe_payment_methods_group.add_command(
        billing_stripe_payment_methods_attach_cmd)
    stripe_payment_methods_group.add_command(
        billing_stripe_payment_methods_detach_cmd)
    stripe_payment_intents_group.add_command(
        billing_stripe_payment_intents_create_cmd)
    stripe_payment_intents_group.add_command(
        billing_stripe_payment_intents_confirm_cmd)
    stripe_setup_intents_group.add_command(
        billing_stripe_setup_intents_create_cmd)

    stripe_customer_group = attach_command_docs(
        stripe_customer_group,
        summary="Stripe customer tools.",
    )
    stripe_payment_methods_group = attach_command_docs(
        stripe_payment_methods_group,
        summary="Stripe payment method tools.",
    )
    stripe_payment_intents_group = attach_command_docs(
        stripe_payment_intents_group,
        summary="Stripe payment intent tools.",
    )
    stripe_setup_intents_group = attach_command_docs(
        stripe_setup_intents_group,
        summary="Stripe setup intent tools.",
    )

    stripe_group.add_command(stripe_customer_group)
    stripe_group.add_command(stripe_payment_methods_group)
    stripe_group.add_command(stripe_payment_intents_group)
    stripe_group.add_command(stripe_setup_intents_group)

    address_group = attach_command_docs(
        address_group,
        summary="Billing address tools.",
    )
    stripe_group = attach_command_docs(
        stripe_group,
        summary="Stripe-backed billing tools.",
    )

    billing_group.add_command(address_group)
    billing_group.add_command(stripe_group)


def attach_generated_admin_billing_gap_commands(
        admin_billing_group: click.Group) -> None:

    @click.group(name="spending")
    def spending_group() -> None:
        """Admin spending tools."""
        pass

    spending_group.add_command(admin_billing_spending_summary_cmd)
    spending_group = attach_command_docs(
        spending_group,
        summary="Admin spending tools.",
    )
    admin_billing_group.add_command(spending_group)


def attach_generated_admin_models_gap_commands(
        admin_models_group: click.Group) -> None:
    admin_models_group.add_command(admin_models_list_cmd)


def attach_generated_models_gap_commands(models_group: click.Group) -> None:
    models_group.add_command(models_check_cmd)
