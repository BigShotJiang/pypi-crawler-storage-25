from __future__ import annotations

from dataclasses import dataclass
import math
import sys
from typing import Any

import click
import requests

from tensormesh import ConfigurationError
from tensormesh import Tensormesh
from tensormesh._transport import resolve_timeout_s
from tensormesh_cli.app_context import build_request_runtime
from tensormesh_cli.app_context import get_app_context
from tensormesh_cli.commands.click_helpers import exit_status_option
from tensormesh_cli.commands.click_helpers import json_input_options
from tensormesh_cli.commands.click_helpers import timeout_option
from tensormesh_cli.commands.infer_chat_support import _GATEWAY_STATUS_HINTS
from tensormesh_cli.commands.infer_chat_support import build_payload
from tensormesh_cli.commands.infer_chat_support import \
    normalize_chat_completion_response_payload
from tensormesh_cli.commands.infer_chat_support import stream_sse
from tensormesh_cli.commands.infer_chat_support import stream_sse_text
from tensormesh_cli.commands.infer_latest import resolve_latest_gateway_model
from tensormesh_cli.commands.readiness import build_first_request_command
from tensormesh_cli.commands.readiness import build_gateway_setup_steps
from tensormesh_cli.commands.readiness import build_gateway_summary_line
from tensormesh_cli.commands.readiness import \
    build_serverless_first_request_command
from tensormesh_cli.commands.readiness import build_serverless_summary_line
from tensormesh_cli.commands.readiness import gateway_status_data
from tensormesh_cli.commands.readiness import inspect_controlplane_auth
from tensormesh_cli.commands.readiness import inspect_gateway_config
from tensormesh_cli.commands.readiness import inspect_serverless_config
from tensormesh_cli.commands.readiness import serverless_status_data
from tensormesh_cli.commands.request_utils import \
    load_command_json_object_required
from tensormesh_cli.commands.request_utils import load_command_json_required
from tensormesh_cli.config.constants import DEFAULT_SERVERLESS_BASE
from tensormesh_cli.controlplane import has_controlplane_access_token
from tensormesh_cli.controlplane import \
    resolve_gateway_user_id_from_controlplane
from tensormesh_cli.docs_meta import attach_command_docs
from tensormesh_cli.docs_meta import CommandExampleMeta
from tensormesh_cli.http.context_request import RequestConfigError
from tensormesh_cli.http.context_request import RequestExecutionError
from tensormesh_cli.http.gateway import normalize_gateway_user_id
from tensormesh_cli.http.sdk_transport import \
    InferenceSDKTransport as _CLIInferenceSDKTransport
from tensormesh_cli.render import context_output
from tensormesh_cli.render import echo_http_response
from tensormesh_cli.render import echo_http_response_with_text_extractor
from tensormesh_cli.render import echo_status_screen
from tensormesh_cli.render import maybe_echo_structured_output

SURFACE_ON_DEMAND = "on-demand"
SURFACE_SERVERLESS = "serverless"
SURFACE_CHOICES = (SURFACE_ON_DEMAND, SURFACE_SERVERLESS)


@dataclass(frozen=True)
class ResolvedInferChatConfig:
    surface: str
    base_url: str
    api_key: str
    user_id: str | None
    model: str | None
    timeout_s: float
    status_hints: dict[int, str]


_SERVERLESS_STATUS_HINTS: dict[int, str] = {
    401:
    "set --api-key explicitly or configure gateway_api_key. Control plane tokens (`tm auth login`) do not authenticate the serverless endpoint.",
}


def _option_source(value: str | None, option_name: str) -> str | None:
    if (value or "").strip():
        return f"option:{option_name}"
    return None


def _build_inference_sdk_client(
    ctx: click.Context,
    *,
    config: ResolvedInferChatConfig,
) -> tuple[Tensormesh, _CLIInferenceSDKTransport]:
    app = get_app_context(ctx)
    try:
        runtime = build_request_runtime(app)
    except RequestConfigError as exc:
        raise click.UsageError(str(exc), ctx=ctx) from exc

    transport = _CLIInferenceSDKTransport(
        runtime=runtime,
        status_hints=config.status_hints,
    )

    client_kwargs: dict[str, Any] = {
        "inference_api_key": config.api_key,
        "env": {},
        "_transport": transport,
    }
    if config.surface == SURFACE_ON_DEMAND:
        client_kwargs["on_demand_base_url"] = config.base_url
        client_kwargs["on_demand_user_id"] = config.user_id
    else:
        client_kwargs["serverless_base_url"] = config.base_url

    try:
        client = Tensormesh(**client_kwargs)
    except ConfigurationError as exc:
        raise click.UsageError(str(exc), ctx=ctx) from exc
    return client, transport


def _sdk_inference_surface(
    client: Tensormesh,
    *,
    config: ResolvedInferChatConfig,
) -> Any:
    if config.surface == SURFACE_ON_DEMAND:
        return client.inference.on_demand
    return client.inference.serverless


def _resolve_infer_chat_config(
    ctx: click.Context,
    *,
    surface: str,
    model: str | None,
    user_id: str | None,
    api_key: str | None,
    base_url: str | None,
    timeout_s: float | None,
    require_model: bool = True,
) -> ResolvedInferChatConfig:
    app = get_app_context(ctx)

    try:
        effective_timeout_s = resolve_timeout_s(
            timeout_s=timeout_s,
            configured_timeout_s=app.timeout_seconds,
        )
    except ValueError as exc:
        raise click.UsageError(str(exc), ctx=ctx) from exc

    if surface == SURFACE_ON_DEMAND:
        resolved_api_key = ((api_key or "").strip()
                            or (app.gateway_api_key or "").strip())
        resolved_base_url = ((base_url or "").strip()
                             or app.gateway_base).rstrip("/")
        resolved_user_id = ((user_id or "").strip()
                            or (app.gateway_user_id or "").strip())
        resolved_model = ((model or "").strip()
                          or (app.gateway_model_id or "").strip() or None)

        if not resolved_api_key:
            msg = ("Missing gateway API key. Set --api-key, configure "
                   "gateway_api_key, or run `tm init --sync`.")
            if has_controlplane_access_token(ctx):
                msg += " Note: you appear logged into the control plane; that token is not a gateway API key."
            raise click.UsageError(msg, ctx=ctx)
        if not resolved_user_id:
            if has_controlplane_access_token(ctx):
                resolved_user_id = resolve_gateway_user_id_from_controlplane(
                    ctx, timeout_s=effective_timeout_s)
            else:
                raise click.UsageError(
                    "Missing gateway user id. Set --user-id, configure gateway_user_id, or run `tm auth login` plus `tm init --sync` so tm can derive and persist it from your control plane profile.",
                    ctx=ctx,
                )
        try:
            normalized_user_id = normalize_gateway_user_id(resolved_user_id)
        except ValueError as exc:
            raise click.UsageError(str(exc), ctx=ctx) from exc

        if resolved_model is not None and resolved_model.strip() == "@latest":
            resolved_model = resolve_latest_gateway_model(
                ctx,
                timeout_s=effective_timeout_s,
            )

        return ResolvedInferChatConfig(
            surface=surface,
            base_url=resolved_base_url,
            api_key=resolved_api_key,
            user_id=normalized_user_id,
            model=resolved_model,
            timeout_s=effective_timeout_s,
            status_hints=_GATEWAY_STATUS_HINTS,
        )

    resolved_api_key = ((api_key or "").strip()
                        or (app.gateway_api_key or "").strip())
    resolved_base_url = ((base_url or "").strip()
                         or DEFAULT_SERVERLESS_BASE).rstrip("/")
    resolved_model = ((model or "").strip() or None)

    if (user_id or "").strip():
        raise click.UsageError(
            "--user-id is only used for --surface on-demand.", ctx=ctx)
    if not resolved_api_key:
        msg = ("Missing serverless API key. Set --api-key or configure "
               "gateway_api_key.")
        if has_controlplane_access_token(ctx):
            msg += " Note: you appear logged into the control plane; that token is not a serverless API key."
        raise click.UsageError(msg, ctx=ctx)
    if resolved_model is not None and resolved_model == "@latest":
        raise click.UsageError(
            "`--model @latest` is only supported for --surface on-demand.",
            ctx=ctx)
    if require_model and not resolved_model:
        raise click.UsageError(
            "Missing serverless model name. Set --model when using --surface serverless.",
            ctx=ctx,
        )
    if not resolved_base_url:
        raise click.UsageError("Missing serverless base URL.", ctx=ctx)

    return ResolvedInferChatConfig(
        surface=surface,
        base_url=resolved_base_url,
        api_key=resolved_api_key,
        user_id=None,
        model=resolved_model,
        timeout_s=effective_timeout_s,
        status_hints=_SERVERLESS_STATUS_HINTS,
    )


def _resolve_serverless_infer_config(
    ctx: click.Context,
    *,
    model: str | None,
    api_key: str | None,
    base_url: str | None,
    timeout_s: float | None,
    require_model: bool,
    require_api_key: bool = True,
) -> ResolvedInferChatConfig:
    if require_api_key:
        return _resolve_infer_chat_config(
            ctx,
            surface=SURFACE_SERVERLESS,
            model=model,
            user_id=None,
            api_key=api_key,
            base_url=base_url,
            timeout_s=timeout_s,
            require_model=require_model,
        )

    app = get_app_context(ctx)
    try:
        effective_timeout_s = resolve_timeout_s(
            timeout_s=timeout_s,
            configured_timeout_s=app.timeout_seconds,
        )
    except ValueError as exc:
        raise click.UsageError(str(exc), ctx=ctx) from exc

    resolved_base_url = ((base_url or "").strip()
                         or DEFAULT_SERVERLESS_BASE).rstrip("/")
    resolved_model = ((model or "").strip() or None)

    if require_model and not resolved_model:
        raise click.UsageError(
            "Missing serverless model name. Set --model when using --surface serverless.",
            ctx=ctx,
        )
    if not resolved_base_url:
        raise click.UsageError("Missing serverless base URL.", ctx=ctx)

    return ResolvedInferChatConfig(
        surface=SURFACE_SERVERLESS,
        base_url=resolved_base_url,
        api_key=((api_key or "").strip()
                 or (app.gateway_api_key or "").strip()),
        user_id=None,
        model=resolved_model,
        timeout_s=effective_timeout_s,
        status_hints=_SERVERLESS_STATUS_HINTS,
    )


def _resolve_openai_endpoint_config(
    ctx: click.Context,
    *,
    surface: str,
    model: str | None,
    user_id: str | None,
    api_key: str | None,
    base_url: str | None,
    timeout_s: float | None,
    require_model: bool,
    require_serverless_api_key: bool = True,
) -> ResolvedInferChatConfig:
    if surface == SURFACE_SERVERLESS:
        return _resolve_serverless_infer_config(
            ctx,
            model=model,
            api_key=api_key,
            base_url=base_url,
            timeout_s=timeout_s,
            require_model=require_model,
            require_api_key=require_serverless_api_key,
        )
    return _resolve_infer_chat_config(
        ctx,
        surface=SURFACE_ON_DEMAND,
        model=model,
        user_id=user_id,
        api_key=api_key,
        base_url=base_url,
        timeout_s=timeout_s,
        require_model=require_model,
    )


def _load_openai_request_payload(
    *,
    ctx: click.Context,
    json_arg: str | None,
    file_path: str | None,
) -> dict[str, Any]:
    return load_command_json_object_required(
        ctx=ctx,
        json_arg=json_arg,
        file_path=file_path,
    )


def _request_model_name(payload: dict[str, Any]) -> str | None:
    request_model = payload.get("model")
    if isinstance(request_model, str) and request_model.strip():
        return request_model.strip()
    return None


def _finalize_openai_request_payload(
    *,
    ctx: click.Context,
    payload: dict[str, Any],
    cli_model: str | None,
    resolved_model: str | None,
    surface: str,
) -> dict[str, Any]:
    cli_model_name = ((cli_model or "").strip() or None)
    request_model_name = _request_model_name(payload)
    resolved_model_name = ((resolved_model or "").strip() or None)

    if cli_model_name is not None:
        payload["model"] = resolved_model_name or cli_model_name
    elif request_model_name == "@latest" and resolved_model_name is not None:
        payload["model"] = resolved_model_name
    elif request_model_name is None and resolved_model_name is not None:
        payload["model"] = resolved_model_name

    if _request_model_name(payload) is None:
        raise click.UsageError(
            f"Missing {surface} model name. Set --model or include `model` in the JSON request body.",
            ctx=ctx,
        )
    return payload


def _extract_text_completion_text(data: Any) -> str | None:
    if not isinstance(data, dict):
        return None
    choices = data.get("choices")
    if not isinstance(choices, list) or not choices:
        return None
    choice = choices[0]
    if not isinstance(choice, dict):
        return None
    text = choice.get("text")
    if isinstance(text, str) and text.strip():
        return text
    return None


def _extract_text_completion_stream_text(data: Any) -> str | None:
    if not isinstance(data, dict):
        return None
    choices = data.get("choices")
    if not isinstance(choices, list):
        return None
    chunks = [
        choice.get("text") for choice in choices if isinstance(choice, dict)
        and isinstance(choice.get("text"), str) and choice.get("text")
    ]
    if not chunks:
        return None
    return "".join(chunks)


def _extract_response_output_text(data: Any) -> str | None:
    if not isinstance(data, dict):
        return None
    output = data.get("output")
    if not isinstance(output, list):
        return None
    fallback_text: str | None = None
    for item in output:
        if not isinstance(item, dict):
            continue
        item_type = item.get("type")
        content = item.get("content")
        if not isinstance(content, list):
            continue
        for chunk in content:
            if not isinstance(chunk, dict):
                continue
            text = chunk.get("text")
            if not isinstance(text, str) or not text.strip():
                continue
            chunk_type = chunk.get("type")
            if item_type == "message" and chunk_type == "output_text":
                return text
            if fallback_text is None:
                fallback_text = text
    return fallback_text


def _extract_scalar_field(field_name: str) -> Any:

    def extractor(data: Any) -> str | None:
        if not isinstance(data, dict):
            return None
        value = data.get(field_name)
        if isinstance(value, str) and value.strip():
            return value
        return None

    return extractor


def _execute_streaming_chat_request(
    *,
    ctx: click.Context,
    config: ResolvedInferChatConfig,
    payload: dict[str, object],
    stream_idle_timeout_s: float,
) -> None:
    try:
        client, _transport = _build_inference_sdk_client(ctx, config=config)
        resp = _sdk_inference_surface(
            client,
            config=config,
        ).stream_request(
            "POST",
            "/v1/chat/completions",
            json_body=payload,
            headers={"Accept": "text/event-stream"},
            timeout=config.timeout_s,
            read_timeout=stream_idle_timeout_s,
        )
    except RequestExecutionError as exc:
        raise click.ClickException(str(exc)) from exc

    try:
        stream_sse(resp)
    finally:
        close = getattr(resp, "close", None)
        if callable(close):
            close()
    sys.stdout.write("\n")
    sys.stdout.flush()


def _execute_streaming_inference_request(
    *,
    ctx: click.Context,
    config: ResolvedInferChatConfig,
    path: str,
    payload: dict[str, object],
    stream_idle_timeout_s: float,
    extract_text: Any,
) -> None:
    try:
        client, _transport = _build_inference_sdk_client(ctx, config=config)
        resp = _sdk_inference_surface(
            client,
            config=config,
        ).stream_request(
            "POST",
            path,
            json_body=payload,
            headers={"Accept": "text/event-stream"},
            timeout=config.timeout_s,
            read_timeout=stream_idle_timeout_s,
        )
    except RequestExecutionError as exc:
        raise click.ClickException(str(exc)) from exc

    try:
        stream_sse_text(resp, extract_text=extract_text)
    finally:
        close = getattr(resp, "close", None)
        if callable(close):
            close()
    sys.stdout.write("\n")
    sys.stdout.flush()


def _execute_inference_request(
    *,
    ctx: click.Context,
    config: ResolvedInferChatConfig,
    method: str,
    path: str,
    payload: dict[str, Any] | None = None,
    headers: dict[str, str] | None = None,
) -> requests.Response:
    try:
        client, _transport = _build_inference_sdk_client(ctx, config=config)
        request_kwargs: dict[str, Any] = {
            "json_body": payload,
            "timeout": config.timeout_s,
        }
        if headers is not None:
            request_kwargs["headers"] = headers
        return _sdk_inference_surface(
            client,
            config=config,
        ).request(
            method,
            path,
            **request_kwargs,
        )
    except RequestExecutionError as exc:
        raise click.ClickException(str(exc)) from exc


def _execute_chat_request(
    *,
    ctx: click.Context,
    config: ResolvedInferChatConfig,
    payload: dict[str, object],
) -> requests.Response:
    return _execute_inference_request(
        ctx=ctx,
        config=config,
        method="POST",
        path="/v1/chat/completions",
        payload=payload,
    )


@click.group(name="infer")
def infer_group() -> None:
    """Inference commands for shared OpenAI-compatible Serverless and On-Demand endpoints."""
    pass


@infer_group.command(name="doctor")
@click.option("--surface",
              type=click.Choice(SURFACE_CHOICES, case_sensitive=False),
              default=SURFACE_ON_DEMAND,
              show_default=True,
              help="Inference surface to inspect.")
@click.option("--model",
              default=None,
              help="Model name to inspect for the next request.")
@click.option(
    "--user-id",
    "user_id",
    default=None,
    help="X-User-Id header to inspect. Only used for --surface on-demand.")
@click.option("--api-key",
              "api_key",
              default=None,
              help="Inference API key to inspect.")
@click.option("--base-url",
              "base_url",
              default=None,
              help="Override the base URL for the selected surface.")
@exit_status_option()
@click.pass_context
def doctor_cmd(
    ctx: click.Context,
    surface: str,
    model: str | None,
    user_id: str | None,
    api_key: str | None,
    base_url: str | None,
    exit_status: bool,
) -> None:
    """Inspect inference readiness for the next request."""
    app = get_app_context(ctx)
    cfg = app.resolved_config
    if surface == SURFACE_ON_DEMAND:
        auth_state = inspect_controlplane_auth(cfg.controlplane_auth_json)
        effective_base = ((base_url or "").strip()
                          or cfg.gateway_base).rstrip("/")
        effective_api_key = ((api_key or "").strip()
                             or (cfg.gateway_api_key or "").strip())
        effective_model = ((model or "").strip()
                           or (cfg.gateway_model_id or "").strip())
        latest_requested = effective_model == "@latest"
        gateway_state = inspect_gateway_config(
            cfg,
            auth_state,
            api_key_override=api_key,
            user_id_override=user_id,
            model_id_override=model,
        )
        latest_resolution_token_present = (auth_state.access_token_present
                                           and auth_state.error is None)
        if latest_requested:
            model_ready = False
            model_id_source = _option_source(model, "--model")
        else:
            model_ready = gateway_state.model_id_present
            model_id_source = (_option_source(model, "--model")
                               or cfg.sources.gateway_model_id)
        user_id_source = (_option_source(user_id, "--user-id")
                          or (cfg.sources.gateway_user_id
                              if gateway_state.user_id_present else None))
        if gateway_state.user_id_derived_from_controlplane:
            user_id_source = "derived-from:controlplane-auth"
        gateway = gateway_status_data(
            cfg,
            gateway_state,
            base=effective_base,
            base_source=_option_source(base_url, "--base-url")
            or cfg.sources.gateway_base,
            api_key_source=_option_source(api_key, "--api-key")
            or cfg.sources.gateway_api_key,
            api_key_value=effective_api_key,
            user_id_source=user_id_source,
            model_id_source=model_id_source,
            model_id_value=effective_model or None,
        )
        gateway["model_id_present"] = model_ready

        warnings: list[str] = []
        if gateway_state.user_id_error is not None:
            warnings.append(gateway_state.user_id_error)
        if latest_requested and not latest_resolution_token_present:
            warnings.append(
                "control plane auth is not ready, so `--model @latest` cannot be resolved yet"
            )
        if latest_requested and latest_resolution_token_present:
            warnings.append(
                "control plane auth is present, but `--model @latest` still requires a live request to confirm the current Control Plane inventory can resolve it"
            )
        warnings.append(
            "Local readiness only. `tm infer doctor` does not live-validate the current inference endpoint or API key."
        )

        next_steps: list[str] = []
        gateway_setup_steps = build_gateway_setup_steps(
            gateway_state,
            controlplane_ready=latest_resolution_token_present,
            include_model_id=not latest_requested,
        )
        next_steps.extend(gateway_setup_steps)
        if (latest_requested and not latest_resolution_token_present
                and "tm auth login" not in gateway_setup_steps):
            next_steps.append("tm auth login")
        next_steps.append(
            build_first_request_command(
                model_available=model_ready,
                model_override="@latest" if latest_requested else None,
            ))

        ready_for_direct_request = (gateway_state.api_key_present
                                    and gateway_state.user_id_ready
                                    and model_ready)
        data = {
            "surface": surface,
            "ready_for_direct_request": ready_for_direct_request,
            "gateway": gateway,
            "latest_resolution": {
                "control_plane_token_present": latest_resolution_token_present,
                "validated_live": False,
                "requires": "control-plane-access-token",
                "requested": latest_requested,
            },
            "warnings": warnings,
            "next_steps": next_steps,
        }

        if not maybe_echo_structured_output(ctx, data=data):
            lines = [
                build_gateway_summary_line(
                    provider=cfg.gateway_provider,
                    base=effective_base,
                    gateway_state=gateway_state,
                    model_present=model_ready,
                ),
                ("Latest model resolution prerequisite: "
                 f"{'control plane token present (not live-validated)' if latest_resolution_token_present else 'missing control plane auth'}"
                 ),
            ]
            echo_status_screen("tm infer doctor",
                               lines=lines,
                               warnings=warnings,
                               next_steps=next_steps)
    else:
        effective_base = ((base_url or "").strip()
                          or DEFAULT_SERVERLESS_BASE).rstrip("/")
        effective_api_key = ((api_key or "").strip()
                             or (cfg.gateway_api_key or "").strip())
        effective_model = ((model or "").strip() or None)
        if (user_id or "").strip():
            raise click.UsageError(
                "--user-id is only used for --surface on-demand.", ctx=ctx)
        serverless_state = inspect_serverless_config(
            cfg,
            api_key_override=api_key,
            model_id_override=model,
        )
        serverless = serverless_status_data(
            cfg,
            serverless_state,
            base=effective_base,
            base_source=_option_source(base_url, "--base-url")
            or "default:serverless-base",
            api_key_source=_option_source(api_key, "--api-key")
            or cfg.sources.gateway_api_key,
            api_key_value=effective_api_key,
            model_id_source=_option_source(model, "--model"),
            model_id_value=effective_model,
        )
        warnings = []
        if not serverless_state.api_key_present:
            warnings.append(
                "inference API key is not configured. Set gateway_api_key or pass --api-key when sending a request."
            )
        if not serverless_state.model_id_present:
            warnings.append(
                "serverless requests require --model because model names are not resolved from local config."
            )
        warnings.append(
            "Local readiness only. `tm infer doctor` does not live-validate the current inference endpoint or API key."
        )
        next_steps = [
            build_serverless_first_request_command(
                api_key_available=serverless_state.api_key_present,
                model_id=effective_model,
                base_url=base_url,
            )
        ]
        ready_for_direct_request = serverless_state.ready_for_direct_request
        data = {
            "surface": surface,
            "ready_for_direct_request": ready_for_direct_request,
            "serverless": serverless,
            "warnings": warnings,
            "next_steps": next_steps,
        }

        if not maybe_echo_structured_output(ctx, data=data):
            lines = [
                build_serverless_summary_line(
                    base=serverless["base"],
                    api_key_present=serverless_state.api_key_present,
                    model_id_present=serverless_state.model_id_present,
                ),
            ]
            echo_status_screen("tm infer doctor",
                               lines=lines,
                               warnings=warnings,
                               next_steps=next_steps)

    if exit_status and not ready_for_direct_request:
        ctx.exit(1)


@infer_group.command(name="chat")
@click.option("--surface",
              type=click.Choice(SURFACE_CHOICES, case_sensitive=False),
              default=SURFACE_ON_DEMAND,
              show_default=True,
              help="Inference surface to use.")
@click.option("--model", default=None, help="Model name to use.")
@click.option(
    "--user-id",
    "user_id",
    default=None,
    help="X-User-Id header (UUID). Only used for --surface on-demand.")
@click.option("--api-key",
              "api_key",
              default=None,
              help="Inference API key (Authorization: Bearer ...).")
@click.option("--base-url",
              "base_url",
              default=None,
              help="Override the base URL for the selected surface.")
@click.option("--stream",
              is_flag=True,
              default=False,
              help="Stream tokens via SSE.")
@click.option(
    "--stream-idle-timeout",
    "stream_idle_timeout_s",
    default=300.0,
    show_default=True,
    type=float,
    help="Maximum idle read timeout in seconds for --stream responses.",
)
@json_input_options(
    json_help="JSON payload or @file.json (object or messages array).",
    file_help="Read JSON payload/messages from file.",
)
@timeout_option(
    help="HTTP connect timeout in seconds for the inference request.")
@click.pass_context
def chat_cmd(
    ctx: click.Context,
    surface: str,
    model: str | None,
    user_id: str | None,
    api_key: str | None,
    base_url: str | None,
    stream: bool,
    stream_idle_timeout_s: float,
    json_arg: str | None,
    file_path: str | None,
    timeout_s: float | None,
) -> None:
    """Call POST /v1/chat/completions on On-Demand or Serverless inference."""
    source = load_command_json_required(ctx=ctx,
                                        json_arg=json_arg,
                                        file_path=file_path)
    input_model = (source.get("model").strip() if isinstance(source, dict)
                   and isinstance(source.get("model"), str)
                   and source.get("model", "").strip() else None)
    config = _resolve_infer_chat_config(ctx,
                                        surface=surface,
                                        model=model or input_model,
                                        user_id=user_id,
                                        api_key=api_key,
                                        base_url=base_url,
                                        timeout_s=timeout_s)
    try:
        payload = build_payload(source=source,
                                model=config.model,
                                stream=stream)
    except ValueError as exc:
        raise click.UsageError(str(exc), ctx=ctx) from exc
    if payload.get("stream") is True and not stream:
        raise click.UsageError(
            "Input JSON enables streaming. Re-run with `--stream` or remove `stream` from the JSON payload.",
            ctx=ctx,
        )

    if stream:
        if (not math.isfinite(stream_idle_timeout_s)
                or stream_idle_timeout_s <= 0):
            raise click.UsageError(
                "`--stream-idle-timeout` must be a finite number greater than 0.",
                ctx=ctx,
            )
        output = context_output(ctx)
        if output != "text":
            raise click.UsageError(
                "`tm infer chat --stream` currently supports only `--output text`.",
                ctx=ctx,
            )
        _execute_streaming_chat_request(
            ctx=ctx,
            config=config,
            payload=payload,
            stream_idle_timeout_s=stream_idle_timeout_s)
        return

    resp = _execute_chat_request(ctx=ctx, config=config, payload=payload)

    echo_http_response_with_text_extractor(
        output=context_output(ctx),
        resp=resp,
        transform_data=normalize_chat_completion_response_payload,
        extract_text=lambda data:
        (data["choices"][0]["message"]["content"]
         if isinstance(data, dict) and isinstance(data.get("choices"), list)
         and data["choices"] and isinstance(data["choices"][0], dict) and
         isinstance(data["choices"][0].get("message"), dict) and isinstance(
             data["choices"][0]["message"].get("content"), str) and data[
                 "choices"][0]["message"]["content"].strip() else None),
        structured_outputs=("json", "yaml", "table"),
    )


@infer_group.command(name="models")
@click.option("--surface",
              type=click.Choice(SURFACE_CHOICES, case_sensitive=False),
              default=SURFACE_SERVERLESS,
              show_default=True,
              help="Inference surface to target.")
@click.option(
    "--user-id",
    "user_id",
    default=None,
    help="X-User-Id header to send. Only used for --surface on-demand.")
@click.option("--api-key",
              "api_key",
              default=None,
              help="Inference API key (Authorization: Bearer ...).")
@click.option("--base-url",
              "base_url",
              default=None,
              help="Override the base URL for the selected surface.")
@timeout_option(
    help="HTTP connect timeout in seconds for the inference request.")
@click.pass_context
def models_cmd(
    ctx: click.Context,
    surface: str,
    user_id: str | None,
    api_key: str | None,
    base_url: str | None,
    timeout_s: float | None,
) -> None:
    """Call GET /v1/models on Serverless or On-Demand inference."""
    config = _resolve_openai_endpoint_config(
        ctx,
        surface=surface,
        model=None,
        user_id=user_id,
        api_key=api_key,
        base_url=base_url,
        timeout_s=timeout_s,
        require_model=False,
        require_serverless_api_key=False,
    )
    resp = _execute_inference_request(
        ctx=ctx,
        config=config,
        method="GET",
        path="/v1/models",
    )
    echo_http_response(output=context_output(ctx), resp=resp)


@infer_group.command(name="completions")
@click.option("--surface",
              type=click.Choice(SURFACE_CHOICES, case_sensitive=False),
              default=SURFACE_SERVERLESS,
              show_default=True,
              help="Inference surface to target.")
@click.option(
    "--model",
    default=None,
    help="Model name to use. Overrides `model` in the JSON request body.")
@click.option(
    "--user-id",
    "user_id",
    default=None,
    help="X-User-Id header to send. Only used for --surface on-demand.")
@click.option("--api-key",
              "api_key",
              default=None,
              help="Inference API key (Authorization: Bearer ...).")
@click.option("--base-url",
              "base_url",
              default=None,
              help="Override the base URL for the selected surface.")
@click.option("--stream",
              is_flag=True,
              default=False,
              help="Stream tokens via SSE.")
@click.option(
    "--stream-idle-timeout",
    "stream_idle_timeout_s",
    default=300.0,
    show_default=True,
    type=float,
    help="Maximum idle read timeout in seconds for --stream responses.",
)
@json_input_options(
    json_help="JSON request body or @file.json.",
    file_help="Read JSON request body from file.",
)
@timeout_option(
    help="HTTP connect timeout in seconds for the inference request.")
@click.pass_context
def completions_cmd(
    ctx: click.Context,
    surface: str,
    model: str | None,
    user_id: str | None,
    api_key: str | None,
    base_url: str | None,
    stream: bool,
    stream_idle_timeout_s: float,
    json_arg: str | None,
    file_path: str | None,
    timeout_s: float | None,
) -> None:
    """Call POST /v1/completions on Serverless or On-Demand inference."""
    payload = _load_openai_request_payload(
        ctx=ctx,
        json_arg=json_arg,
        file_path=file_path,
    )
    input_model = _request_model_name(payload)
    config = _resolve_openai_endpoint_config(
        ctx,
        surface=surface,
        model=model or input_model,
        user_id=user_id,
        api_key=api_key,
        base_url=base_url,
        timeout_s=timeout_s,
        require_model=False,
    )
    payload = _finalize_openai_request_payload(
        ctx=ctx,
        payload=payload,
        cli_model=model,
        resolved_model=config.model,
        surface=surface,
    )
    if payload.get("stream") is True and not stream:
        raise click.UsageError(
            "Input JSON enables streaming. Re-run with `--stream` or remove `stream` from the JSON payload.",
            ctx=ctx,
        )
    if stream:
        if (not math.isfinite(stream_idle_timeout_s)
                or stream_idle_timeout_s <= 0):
            raise click.UsageError(
                "`--stream-idle-timeout` must be a finite number greater than 0.",
                ctx=ctx,
            )
        output = context_output(ctx)
        if output != "text":
            raise click.UsageError(
                "`tm infer completions --stream` currently supports only `--output text`.",
                ctx=ctx,
            )
        payload["stream"] = True
        _execute_streaming_inference_request(
            ctx=ctx,
            config=config,
            path="/v1/completions",
            payload=payload,
            stream_idle_timeout_s=stream_idle_timeout_s,
            extract_text=_extract_text_completion_stream_text,
        )
        return
    resp = _execute_inference_request(
        ctx=ctx,
        config=config,
        method="POST",
        path="/v1/completions",
        payload=payload,
    )
    echo_http_response_with_text_extractor(
        output=context_output(ctx),
        resp=resp,
        extract_text=_extract_text_completion_text,
        structured_outputs=("json", "yaml", "table"),
    )


@infer_group.command(name="responses")
@click.option("--surface",
              type=click.Choice(SURFACE_CHOICES, case_sensitive=False),
              default=SURFACE_SERVERLESS,
              show_default=True,
              help="Inference surface to target.")
@click.option(
    "--model",
    default=None,
    help="Model name to use. Overrides `model` in the JSON request body.")
@click.option(
    "--user-id",
    "user_id",
    default=None,
    help="X-User-Id header to send. Only used for --surface on-demand.")
@click.option("--api-key",
              "api_key",
              default=None,
              help="Inference API key (Authorization: Bearer ...).")
@click.option("--base-url",
              "base_url",
              default=None,
              help="Override the base URL for the selected surface.")
@click.option("--stream",
              is_flag=True,
              default=False,
              help="Stream tokens via SSE.")
@click.option(
    "--stream-idle-timeout",
    "stream_idle_timeout_s",
    default=300.0,
    show_default=True,
    type=float,
    help="Maximum idle read timeout in seconds for --stream responses.",
)
@json_input_options(
    json_help="JSON request body or @file.json.",
    file_help="Read JSON request body from file.",
)
@timeout_option(
    help="HTTP connect timeout in seconds for the inference request.")
@click.pass_context
def responses_cmd(
    ctx: click.Context,
    surface: str,
    model: str | None,
    user_id: str | None,
    api_key: str | None,
    base_url: str | None,
    stream: bool,
    stream_idle_timeout_s: float,
    json_arg: str | None,
    file_path: str | None,
    timeout_s: float | None,
) -> None:
    """Call POST /v1/responses on Serverless or On-Demand inference."""
    payload = _load_openai_request_payload(
        ctx=ctx,
        json_arg=json_arg,
        file_path=file_path,
    )
    input_model = _request_model_name(payload)
    config = _resolve_openai_endpoint_config(
        ctx,
        surface=surface,
        model=model or input_model,
        user_id=user_id,
        api_key=api_key,
        base_url=base_url,
        timeout_s=timeout_s,
        require_model=False,
    )
    payload = _finalize_openai_request_payload(
        ctx=ctx,
        payload=payload,
        cli_model=model,
        resolved_model=config.model,
        surface=surface,
    )
    if payload.get("stream") is True and not stream:
        raise click.UsageError(
            "Input JSON enables streaming. Re-run with `--stream` or remove `stream` from the JSON payload.",
            ctx=ctx,
        )
    if stream:
        if (not math.isfinite(stream_idle_timeout_s)
                or stream_idle_timeout_s <= 0):
            raise click.UsageError(
                "`--stream-idle-timeout` must be a finite number greater than 0.",
                ctx=ctx,
            )
        output = context_output(ctx)
        if output != "text":
            raise click.UsageError(
                "`tm infer responses --stream` currently supports only `--output text`.",
                ctx=ctx,
            )
        payload["stream"] = True
        _execute_streaming_inference_request(
            ctx=ctx,
            config=config,
            path="/v1/responses",
            payload=payload,
            stream_idle_timeout_s=stream_idle_timeout_s,
            extract_text=_extract_response_output_text,
        )
        return
    resp = _execute_inference_request(
        ctx=ctx,
        config=config,
        method="POST",
        path="/v1/responses",
        payload=payload,
    )
    echo_http_response_with_text_extractor(
        output=context_output(ctx),
        resp=resp,
        extract_text=_extract_response_output_text,
        structured_outputs=("json", "yaml", "table"),
    )


@infer_group.command(name="tokenize")
@click.option("--surface",
              type=click.Choice(SURFACE_CHOICES, case_sensitive=False),
              default=SURFACE_SERVERLESS,
              show_default=True,
              help="Inference surface to target.")
@click.option(
    "--model",
    default=None,
    help="Model name to use. Overrides `model` in the JSON request body.")
@click.option(
    "--user-id",
    "user_id",
    default=None,
    help="X-User-Id header to send. Only used for --surface on-demand.")
@click.option("--api-key",
              "api_key",
              default=None,
              help="Inference API key (Authorization: Bearer ...).")
@click.option("--base-url",
              "base_url",
              default=None,
              help="Override the base URL for the selected surface.")
@json_input_options(
    json_help="JSON request body or @file.json.",
    file_help="Read JSON request body from file.",
)
@timeout_option(
    help="HTTP connect timeout in seconds for the inference request.")
@click.pass_context
def tokenize_cmd(
    ctx: click.Context,
    surface: str,
    model: str | None,
    user_id: str | None,
    api_key: str | None,
    base_url: str | None,
    json_arg: str | None,
    file_path: str | None,
    timeout_s: float | None,
) -> None:
    """Call POST /tokenize on Serverless or On-Demand inference."""
    payload = _load_openai_request_payload(
        ctx=ctx,
        json_arg=json_arg,
        file_path=file_path,
    )
    input_model = _request_model_name(payload)
    config = _resolve_openai_endpoint_config(
        ctx,
        surface=surface,
        model=model or input_model,
        user_id=user_id,
        api_key=api_key,
        base_url=base_url,
        timeout_s=timeout_s,
        require_model=False,
    )
    payload = _finalize_openai_request_payload(
        ctx=ctx,
        payload=payload,
        cli_model=model,
        resolved_model=config.model,
        surface=surface,
    )
    resp = _execute_inference_request(
        ctx=ctx,
        config=config,
        method="POST",
        path="/tokenize",
        payload=payload,
    )
    echo_http_response(output=context_output(ctx), resp=resp)


@infer_group.command(name="detokenize")
@click.option("--surface",
              type=click.Choice(SURFACE_CHOICES, case_sensitive=False),
              default=SURFACE_SERVERLESS,
              show_default=True,
              help="Inference surface to target.")
@click.option(
    "--model",
    default=None,
    help="Model name to use. Overrides `model` in the JSON request body.")
@click.option(
    "--user-id",
    "user_id",
    default=None,
    help="X-User-Id header to send. Only used for --surface on-demand.")
@click.option("--api-key",
              "api_key",
              default=None,
              help="Inference API key (Authorization: Bearer ...).")
@click.option("--base-url",
              "base_url",
              default=None,
              help="Override the base URL for the selected surface.")
@json_input_options(
    json_help="JSON request body or @file.json.",
    file_help="Read JSON request body from file.",
)
@timeout_option(
    help="HTTP connect timeout in seconds for the inference request.")
@click.pass_context
def detokenize_cmd(
    ctx: click.Context,
    surface: str,
    model: str | None,
    user_id: str | None,
    api_key: str | None,
    base_url: str | None,
    json_arg: str | None,
    file_path: str | None,
    timeout_s: float | None,
) -> None:
    """Call POST /detokenize on Serverless or On-Demand inference."""
    payload = _load_openai_request_payload(
        ctx=ctx,
        json_arg=json_arg,
        file_path=file_path,
    )
    input_model = _request_model_name(payload)
    config = _resolve_openai_endpoint_config(
        ctx,
        surface=surface,
        model=model or input_model,
        user_id=user_id,
        api_key=api_key,
        base_url=base_url,
        timeout_s=timeout_s,
        require_model=False,
    )
    payload = _finalize_openai_request_payload(
        ctx=ctx,
        payload=payload,
        cli_model=model,
        resolved_model=config.model,
        surface=surface,
    )
    resp = _execute_inference_request(
        ctx=ctx,
        config=config,
        method="POST",
        path="/detokenize",
        payload=payload,
    )
    echo_http_response_with_text_extractor(
        output=context_output(ctx),
        resp=resp,
        extract_text=_extract_scalar_field("prompt"),
        structured_outputs=("json", "yaml", "table"),
    )


@infer_group.command(name="health")
@click.option("--surface",
              type=click.Choice(SURFACE_CHOICES, case_sensitive=False),
              default=SURFACE_SERVERLESS,
              show_default=True,
              help="Inference surface to target.")
@click.option(
    "--user-id",
    "user_id",
    default=None,
    help="X-User-Id header to send. Only used for --surface on-demand.")
@click.option("--api-key",
              "api_key",
              default=None,
              help="Inference API key (Authorization: Bearer ...).")
@click.option("--base-url",
              "base_url",
              default=None,
              help="Override the base URL for the selected surface.")
@timeout_option(
    help="HTTP connect timeout in seconds for the inference request.")
@click.pass_context
def health_cmd(
    ctx: click.Context,
    surface: str,
    user_id: str | None,
    api_key: str | None,
    base_url: str | None,
    timeout_s: float | None,
) -> None:
    """Call GET /health on Serverless or On-Demand inference."""
    config = _resolve_openai_endpoint_config(
        ctx,
        surface=surface,
        model=None,
        user_id=user_id,
        api_key=api_key,
        base_url=base_url,
        timeout_s=timeout_s,
        require_model=False,
        require_serverless_api_key=False,
    )
    resp = _execute_inference_request(
        ctx=ctx,
        config=config,
        method="GET",
        path="/health",
    )
    echo_http_response_with_text_extractor(
        output=context_output(ctx),
        resp=resp,
        extract_text=_extract_scalar_field("status"),
        structured_outputs=("json", "yaml", "table"),
    )


@infer_group.command(name="version")
@click.option("--surface",
              type=click.Choice(SURFACE_CHOICES, case_sensitive=False),
              default=SURFACE_SERVERLESS,
              show_default=True,
              help="Inference surface to target.")
@click.option(
    "--user-id",
    "user_id",
    default=None,
    help="X-User-Id header to send. Only used for --surface on-demand.")
@click.option("--api-key",
              "api_key",
              default=None,
              help="Inference API key (Authorization: Bearer ...).")
@click.option("--base-url",
              "base_url",
              default=None,
              help="Override the base URL for the selected surface.")
@timeout_option(
    help="HTTP connect timeout in seconds for the inference request.")
@click.pass_context
def version_cmd(
    ctx: click.Context,
    surface: str,
    user_id: str | None,
    api_key: str | None,
    base_url: str | None,
    timeout_s: float | None,
) -> None:
    """Call GET /version on Serverless or On-Demand inference."""
    config = _resolve_openai_endpoint_config(
        ctx,
        surface=surface,
        model=None,
        user_id=user_id,
        api_key=api_key,
        base_url=base_url,
        timeout_s=timeout_s,
        require_model=False,
        require_serverless_api_key=False,
    )
    resp = _execute_inference_request(
        ctx=ctx,
        config=config,
        method="GET",
        path="/version",
    )
    echo_http_response_with_text_extractor(
        output=context_output(ctx),
        resp=resp,
        extract_text=_extract_scalar_field("version"),
        structured_outputs=("json", "yaml", "table"),
    )


infer_group = attach_command_docs(
    infer_group,
    summary=
    "Inference commands for shared serverless and On-Demand OpenAI-compatible endpoints.",
    examples=[
        CommandExampleMeta(
            command="tm infer doctor",
            description=
            "Inspect On-Demand readiness and `@latest` support before sending a request.",
        ),
        CommandExampleMeta(
            command="tm infer doctor --surface serverless",
            description=
            "Inspect Serverless readiness before sending a request.",
        ),
        CommandExampleMeta(
            command=
            "tm infer chat --json '[{\"role\":\"user\",\"content\":\"Say hello.\"}]'",
            description=
            "Send an On-Demand chat request from the CLI after `tm auth login` and `tm init --sync`.",
        ),
        CommandExampleMeta(
            command=
            "tm infer chat --surface serverless --api-key YOUR_INFERENCE_API_KEY --model YOUR_SERVERLESS_MODEL_NAME --json '[{\"role\":\"user\",\"content\":\"Say hello.\"}]'",
            description=
            "Send a Serverless chat-completions request with an explicit inference API key.",
        ),
        CommandExampleMeta(
            command="tm infer models",
            description="List models from the default serverless host.",
        ),
        CommandExampleMeta(
            command=
            "tm infer models --surface on-demand --api-key YOUR_INFERENCE_API_KEY --user-id YOUR_TENSORMESH_USER_ID --base-url https://external.nebius.tensormesh.ai",
            description="List models from a routed On-Demand host.",
        ),
    ],
)

doctor_cmd = attach_command_docs(
    doctor_cmd,
    summary="Inspect inference readiness for the next request.",
    overview_title="What This Checks",
    overview_markdown=
    ("`tm infer doctor` is a local readiness check for the next inference request. It helps you confirm that the CLI has the inputs it needs, but it does not send a live inference request.\n\n"
     "Use [`tm infer chat`](/cli/reference/infer/chat) for an end-to-end gateway check, and use [`tm auth whoami`](/cli/reference/auth/whoami) if you also need to confirm the current Control Plane bearer token."
     ),
    caveats=[
        "Reports local readiness only. Use `tm auth whoami` to live-validate Control Plane auth and `tm infer chat` for an end-to-end inference check.",
        "`tm infer doctor` accepts the same local targeting overrides as `tm infer chat` for `--model`, `--user-id`, `--api-key`, and `--base-url`.",
        "`--surface on-demand` checks local prerequisites for X-User-Id and `--model @latest` resolution.",
        "`--surface serverless` checks the shared inference API key (`gateway_api_key`) and selected host, but does not live-validate the upstream endpoint.",
        "Use `tm billing pricing serverless list` to discover published serverless model names when you have Control Plane access for the same Tensormesh environment. `tm infer doctor` can check whether `--model` is present, but it does not enumerate them itself.",
        "`--model @latest` readiness only applies to `--surface on-demand` and only checks for a local Control Plane token; it does not live-validate that token."
    ],
    prerequisites=[
        "For the default On-Demand flow, run `tm init --sync` first so the CLI can reuse the synced managed gateway settings."
    ],
    examples=[
        CommandExampleMeta(
            command="tm infer doctor",
            description=
            "Inspect On-Demand readiness for a direct request and for `--model @latest`.",
        ),
        CommandExampleMeta(
            command="tm infer doctor --surface serverless",
            description=
            "Inspect Serverless readiness for a direct request that will provide `--model` explicitly.",
        ),
        CommandExampleMeta(
            command=
            "tm infer doctor --surface serverless --model YOUR_SERVERLESS_MODEL_NAME --base-url https://serverless.tensormesh.ai",
            description=
            "Inspect the effective Serverless target after applying explicit request overrides.",
        ),
        CommandExampleMeta(
            command="tm infer doctor --exit-status",
            description=
            "Use shell-friendly exit codes when direct gateway prerequisites are missing.",
        ),
    ],
    related_commands=[
        "tm init", "tm auth status", "tm infer chat", "tm doctor"
    ],
)

chat_cmd = attach_command_docs(
    chat_cmd,
    summary=
    "Call POST /v1/chat/completions on On-Demand or Serverless inference.",
    overview_title="When To Use This",
    overview_markdown=
    ("Use `tm infer chat` when you want to send an actual inference request through the CLI.\n\n"
     "- Choose `--surface serverless` when you already know the serverless model name you want.\n"
     "- Use the default On-Demand flow after `tm auth login` and `tm init --sync` when you want the CLI to reuse the synced managed gateway settings."
     ),
    auth_scope=["inference-api-key"],
    prerequisites=[
        "For the default On-Demand flow, run `tm auth login` and `tm init --sync` first so the CLI has the synced inference API key, X-User-Id, and served model name.",
        "Provide `--model` when using `--surface serverless`.",
        "If you have Control Plane access for the same Tensormesh environment, discover published serverless model names with `tm billing pricing serverless list`, then pass the returned `pricing[].model` value with `--model`.",
        "If you only have inference credentials, or you are targeting a different serverless host override, get the model name from your Tensormesh environment before using `--surface serverless`."
    ],
    caveats=[
        "`--surface on-demand` requires an inference API key and X-User-Id; the standard way to populate both is `tm auth login` followed by `tm init --sync`.",
        "`--surface serverless` does not send X-User-Id, defaults to https://serverless.tensormesh.ai, and reuses `gateway_api_key` as the shared inference API key when `--api-key` is omitted.",
        "`gateway_api_key` is the stored inference API key used by the SDK as `inference_api_key`.",
        "`tm billing pricing serverless list` helps discover published serverless model names for the current Tensormesh Control Plane environment. If you are targeting a different serverless host override, confirm the model name for that host separately.",
        "`--stream` currently supports only `--output text`.",
        "`--model @latest` is only supported for `--surface on-demand`."
    ],
    related_commands=[
        "tm init", "tm billing pricing serverless list", "tm models list",
        "tm doctor"
    ],
    examples=[
        CommandExampleMeta(
            command=
            "tm infer chat --json '[{\"role\":\"user\",\"content\":\"Say hello.\"}]'",
            description=
            "Send a non-streaming On-Demand chat request after `tm auth login` and `tm init --sync`.",
        ),
        CommandExampleMeta(
            command=
            "tm infer chat --surface serverless --api-key YOUR_INFERENCE_API_KEY --model YOUR_SERVERLESS_MODEL_NAME --json '[{\"role\":\"user\",\"content\":\"Say hello.\"}]'",
            description=
            "Send a non-streaming Serverless request with an explicit inference API key.",
        ),
        CommandExampleMeta(
            command=
            "echo '[{\"role\":\"user\",\"content\":\"Stream tokens.\"}]' | tm infer chat --stream --stream-idle-timeout 30",
            description=
            "Stream tokens from the selected surface after the usual On-Demand setup, and fail a stalled stream after 30 seconds of upstream silence.",
        ),
    ],
)

models_cmd = attach_command_docs(
    models_cmd,
    summary="Call GET /v1/models on Serverless or On-Demand inference.",
    overview_title="When To Use This",
    overview_markdown=
    ("Use `tm infer models` when you want to enumerate models from the selected inference host.\n\n"
     "On the default Tensormesh serverless host, this route works without an inference API key. On On-Demand, it requires both `Authorization` and `X-User-Id`."
     ),
    caveats=[
        "The returned `id` value is the model string to pass back as `model` in serverless requests.",
        "For On-Demand, the returned `id` value is the served model name to reuse in routed requests.",
    ],
    related_commands=[
        "tm billing pricing serverless list", "tm infer chat",
        "tm infer completions"
    ],
    examples=[
        CommandExampleMeta(
            command="tm infer models",
            description="List models from the default serverless host.",
        ),
        CommandExampleMeta(
            command=
            "tm infer models --surface on-demand --api-key YOUR_INFERENCE_API_KEY --user-id YOUR_TENSORMESH_USER_ID --base-url https://external.nebius.tensormesh.ai",
            description="List models from a routed On-Demand host.",
        ),
    ],
)

completions_cmd = attach_command_docs(
    completions_cmd,
    summary="Call POST /v1/completions on Serverless or On-Demand inference.",
    overview_title="When To Use This",
    overview_markdown=
    ("Use `tm infer completions` when you want the text-completions endpoint instead of chat completions on the selected surface.\n\n"
     "Provide the request body as JSON and either include `model` in the body or pass `--model` to override it."
     ),
    auth_scope=["inference-api-key"],
    caveats=[
        "On-Demand also requires `--user-id` and a routed base URL.",
        "`--model` overrides the `model` field inside the JSON request body.",
        "`--stream` currently supports only `--output text`.",
    ],
    related_commands=[
        "tm infer chat", "tm infer responses", "tm infer models"
    ],
    examples=[
        CommandExampleMeta(
            command=
            "tm infer completions --api-key YOUR_INFERENCE_API_KEY --model YOUR_SERVERLESS_MODEL_NAME --json '{\"prompt\":\"Say hello.\"}'",
            description="Send a serverless text-completions request.",
        ),
        CommandExampleMeta(
            command=
            "tm infer completions --surface on-demand --api-key YOUR_INFERENCE_API_KEY --user-id YOUR_TENSORMESH_USER_ID --base-url https://external.nebius.tensormesh.ai --model YOUR_SERVED_GATEWAY_MODEL_NAME --json '{\"prompt\":\"Say hello.\"}'",
            description="Send a routed On-Demand text-completions request.",
        ),
        CommandExampleMeta(
            command=
            "tm infer completions --stream --stream-idle-timeout 30 --api-key YOUR_INFERENCE_API_KEY --model YOUR_SERVERLESS_MODEL_NAME --json '{\"prompt\":\"Stream a short reply.\"}'",
            description=
            "Stream text-completion tokens over SSE and fail a stalled stream after 30 seconds of upstream silence.",
        ),
    ],
)

responses_cmd = attach_command_docs(
    responses_cmd,
    summary="Call POST /v1/responses on Serverless or On-Demand inference.",
    overview_title="When To Use This",
    overview_markdown=
    ("Use `tm infer responses` when you want the `/v1/responses` endpoint from the CLI on the selected surface.\n\n"
     "Provide the request body as JSON and either include `model` in the body or pass `--model` to override it."
     ),
    auth_scope=["inference-api-key"],
    caveats=[
        "On-Demand also requires `--user-id` and a routed base URL.",
        "`--model` overrides the `model` field inside the JSON request body.",
        "`--stream` currently supports only `--output text`.",
    ],
    related_commands=[
        "tm infer completions", "tm infer chat", "tm infer models"
    ],
    examples=[
        CommandExampleMeta(
            command=
            "tm infer responses --api-key YOUR_INFERENCE_API_KEY --model YOUR_SERVERLESS_MODEL_NAME --json '{\"input\":\"Say hello.\"}'",
            description="Send a serverless responses request.",
        ),
        CommandExampleMeta(
            command=
            "tm infer responses --surface on-demand --api-key YOUR_INFERENCE_API_KEY --user-id YOUR_TENSORMESH_USER_ID --base-url https://external.nebius.tensormesh.ai --model YOUR_SERVED_GATEWAY_MODEL_NAME --json '{\"input\":\"Say hello.\"}'",
            description="Send a routed On-Demand responses request.",
        ),
        CommandExampleMeta(
            command=
            "tm infer responses --stream --stream-idle-timeout 30 --api-key YOUR_INFERENCE_API_KEY --model YOUR_SERVERLESS_MODEL_NAME --json '{\"input\":\"Stream a short reply.\"}'",
            description=
            "Stream response output text over SSE and fail a stalled stream after 30 seconds of upstream silence.",
        ),
    ],
)

tokenize_cmd = attach_command_docs(
    tokenize_cmd,
    summary="Call POST /tokenize on Serverless or On-Demand inference.",
    auth_scope=["inference-api-key"],
    caveats=[
        "On-Demand also requires `--user-id` and a routed base URL.",
        "`--model` overrides the `model` field inside the JSON request body.",
        "The live endpoint accepts either `prompt` or `messages` in the JSON request body.",
    ],
    related_commands=["tm infer detokenize", "tm infer models"],
    examples=[
        CommandExampleMeta(
            command=
            "tm infer tokenize --api-key YOUR_INFERENCE_API_KEY --model YOUR_SERVERLESS_MODEL_NAME --json '{\"prompt\":\"Hello\"}'",
            description="Tokenize text with the selected serverless model.",
        ),
        CommandExampleMeta(
            command=
            "tm infer tokenize --surface on-demand --api-key YOUR_INFERENCE_API_KEY --user-id YOUR_TENSORMESH_USER_ID --base-url https://external.nebius.tensormesh.ai --model YOUR_SERVED_GATEWAY_MODEL_NAME --json '{\"prompt\":\"Hello\"}'",
            description=
            "Tokenize text with the selected routed On-Demand model.",
        ),
    ],
)

detokenize_cmd = attach_command_docs(
    detokenize_cmd,
    summary="Call POST /detokenize on Serverless or On-Demand inference.",
    auth_scope=["inference-api-key"],
    caveats=[
        "On-Demand also requires `--user-id` and a routed base URL.",
        "`--model` overrides the `model` field inside the JSON request body.",
    ],
    related_commands=["tm infer tokenize", "tm infer models"],
    examples=[
        CommandExampleMeta(
            command=
            "tm infer detokenize --api-key YOUR_INFERENCE_API_KEY --model YOUR_SERVERLESS_MODEL_NAME --json '{\"tokens\":[15496,0]}'",
            description=
            "Detokenize token ids with the selected serverless model.",
        ),
        CommandExampleMeta(
            command=
            "tm infer detokenize --surface on-demand --api-key YOUR_INFERENCE_API_KEY --user-id YOUR_TENSORMESH_USER_ID --base-url https://external.nebius.tensormesh.ai --model YOUR_SERVED_GATEWAY_MODEL_NAME --json '{\"tokens\":[15496,0]}'",
            description=
            "Detokenize token ids with the selected routed On-Demand model.",
        ),
    ],
)

health_cmd = attach_command_docs(
    health_cmd,
    summary="Call GET /health on Serverless or On-Demand inference.",
    overview_title="When To Use This",
    overview_markdown=
    ("Use `tm infer health` when you want a quick reachability check against the selected inference host.\n\n"
     "The default Tensormesh serverless host currently serves this route without an inference API key. On On-Demand, it requires both `Authorization` and `X-User-Id`."
     ),
    caveats=["On-Demand also requires `--user-id` and a routed base URL."],
    related_commands=["tm infer version", "tm infer models"],
    examples=[
        CommandExampleMeta(
            command="tm infer health",
            description="Check the verified serverless health endpoint.",
        ),
        CommandExampleMeta(
            command=
            "tm infer health --surface on-demand --api-key YOUR_INFERENCE_API_KEY --user-id YOUR_TENSORMESH_USER_ID --base-url https://external.nebius.tensormesh.ai",
            description="Check the routed On-Demand health endpoint.",
        ),
    ],
)

version_cmd = attach_command_docs(
    version_cmd,
    summary="Call GET /version on Serverless or On-Demand inference.",
    overview_title="When To Use This",
    overview_markdown=
    ("Use `tm infer version` when you want the current version string from the selected inference host.\n\n"
     "The default Tensormesh serverless host currently serves this route without an inference API key. On On-Demand, it requires both `Authorization` and `X-User-Id`."
     ),
    caveats=["On-Demand also requires `--user-id` and a routed base URL."],
    related_commands=["tm infer health", "tm infer models"],
    examples=[
        CommandExampleMeta(
            command="tm infer version",
            description="Read the verified serverless version endpoint.",
        ),
        CommandExampleMeta(
            command=
            "tm infer version --surface on-demand --api-key YOUR_INFERENCE_API_KEY --user-id YOUR_TENSORMESH_USER_ID --base-url https://external.nebius.tensormesh.ai",
            description="Read the routed On-Demand version endpoint.",
        ),
    ],
)
