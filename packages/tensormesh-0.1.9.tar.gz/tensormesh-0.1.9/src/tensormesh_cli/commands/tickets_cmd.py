from __future__ import annotations

import click

from tensormesh.types import AppendTicketMessageRequest
from tensormesh.types import CreateTicketRequest
from tensormesh_cli.commands.click_helpers import json_input_options
from tensormesh_cli.commands.click_helpers import page_option
from tensormesh_cli.commands.click_helpers import size_option
from tensormesh_cli.commands.click_helpers import timeout_option
from tensormesh_cli.commands.click_helpers import user_id_option
from tensormesh_cli.commands.click_helpers import yes_option
from tensormesh_cli.commands.controlplane_actions import \
    confirm_and_execute_controlplane_sdk_and_render
from tensormesh_cli.commands.controlplane_actions import \
    execute_controlplane_sdk_and_render
from tensormesh_cli.commands.request_utils import \
    load_command_json_object_optional
from tensormesh_cli.commands.request_utils import require_non_empty_value
from tensormesh_cli.commands.request_utils import require_payload_string_fields
from tensormesh_cli.commands.request_utils import resolve_command_payload
from tensormesh_cli.docs_meta import attach_command_docs
from tensormesh_cli.docs_meta import CommandExampleMeta


@click.group(name="tickets")
def tickets_group() -> None:
    """Support tickets (Control Plane)."""
    pass


@tickets_group.command(name="list")
@user_id_option(help="Optional user id to scope tickets.")
@click.option("--status", default=None, help="Filter by ticket status.")
@page_option()
@size_option()
@timeout_option()
@click.pass_context
def list_cmd(
    ctx: click.Context,
    user_id: str | None,
    status: str | None,
    page: int | None,
    size: int | None,
    timeout_s: float | None,
) -> None:
    """List tickets (GET /v1/support/tickets)."""
    execute_controlplane_sdk_and_render(
        ctx,
        lambda client: client.control_plane.support.tickets.list(
            user_id=user_id,
            status=status,
            page=page,
            size=size,
            timeout=timeout_s,
        ),
        default="json",
    )


@tickets_group.command(name="get")
@click.argument("ticket_id", type=str)
@timeout_option()
@click.pass_context
def get_cmd(ctx: click.Context, ticket_id: str,
            timeout_s: float | None) -> None:
    """Get a ticket (GET /v1/support/tickets/{ticketId})."""
    tid = require_non_empty_value(ctx=ctx, value=ticket_id, label="TICKET_ID")
    execute_controlplane_sdk_and_render(
        ctx,
        lambda client: client.control_plane.support.tickets.get(
            tid,
            timeout=timeout_s,
        ),
        default="json",
    )


@tickets_group.command(name="create")
@click.option("--subject", default=None, help="Ticket subject.")
@click.option("--type", "ticket_type", default=None, help="Ticket type.")
@click.option("--message", default=None, help="Initial message.")
@user_id_option(help="Optional user id for authorization.")
@json_input_options(
    json_help="JSON request body or @file.json (overrides flags).",
    file_help="Read JSON request body from file (overrides flags).",
)
@timeout_option()
@click.pass_context
def create_cmd(
    ctx: click.Context,
    subject: str | None,
    ticket_type: str | None,
    message: str | None,
    user_id: str | None,
    json_arg: str | None,
    file_path: str | None,
    timeout_s: float | None,
) -> None:
    """Create a ticket (POST /v1/support/tickets)."""
    request_payload = resolve_command_payload(
        ctx=ctx,
        json_arg=json_arg,
        file_path=file_path,
        build_from_values=lambda: CreateTicketRequest(
            subject=subject or "",
            message=message or "",
            ticket_type=ticket_type,
            user_id=user_id,
        ),
        build_from_json=lambda body: CreateTicketRequest.from_dict(body),
        value_error_message=lambda exc:
        "Missing required fields. Provide --subject and --message (or pass JSON via --json/--file/stdin)."
        if "must be a non-empty string" in str(exc) else str(exc),
        to_payload=lambda request: request.to_dict(),
    )
    require_payload_string_fields(
        ctx=ctx,
        payload=request_payload,
        field_names=("subject", "message"),
        message=
        "Missing required fields. Provide --subject and --message (or pass JSON via --json/--file/stdin).",
    )
    execute_controlplane_sdk_and_render(
        ctx,
        lambda client: client.control_plane.support.tickets.create(
            request=request_payload,
            timeout=timeout_s,
        ),
        default="json",
    )


@tickets_group.command(name="message")
@click.argument("ticket_id", type=str)
@click.option("--message", default=None, help="Message to append.")
@user_id_option(help="Optional user id for authorization.")
@json_input_options(
    json_help="JSON request body or @file.json (overrides flags).",
    file_help="Read JSON request body from file (overrides flags).",
)
@timeout_option()
@click.pass_context
def message_cmd(
    ctx: click.Context,
    ticket_id: str,
    message: str | None,
    user_id: str | None,
    json_arg: str | None,
    file_path: str | None,
    timeout_s: float | None,
) -> None:
    """Append a message to a ticket (POST /v1/support/tickets/{ticketId}/messages)."""
    tid = require_non_empty_value(ctx=ctx, value=ticket_id, label="TICKET_ID")
    body_obj = load_command_json_object_optional(
        ctx=ctx,
        json_arg=json_arg,
        file_path=file_path,
        message="Ticket message request must be a JSON object.",
    )
    try:
        request_obj = (AppendTicketMessageRequest.from_dict(body_obj)
                       if body_obj is not None else AppendTicketMessageRequest(
                           message=message or "",
                           user_id=user_id,
                       ))
    except (TypeError, ValueError) as exc:
        raise click.UsageError(str(exc), ctx=ctx) from exc

    request_payload = request_obj.to_dict()
    message_payload = request_payload.get("message")
    if not isinstance(message_payload, dict) or not isinstance(
            message_payload.get("content"),
            str) or not message_payload["content"].strip():
        raise click.UsageError(
            "Missing message. Provide --message or pass JSON via --json/--file/stdin.",
            ctx=ctx,
        )
    execute_controlplane_sdk_and_render(
        ctx,
        lambda client: client.control_plane.support.tickets.add_message(
            tid,
            request=request_payload,
            timeout=timeout_s,
        ),
        default="json",
    )


@tickets_group.command(name="close")
@click.argument("ticket_id", type=str)
@yes_option()
@timeout_option()
@click.pass_context
def close_cmd(ctx: click.Context, ticket_id: str, yes: bool,
              timeout_s: float | None) -> None:
    """Close/delete a ticket (DELETE /v1/support/tickets/{ticketId})."""
    tid = require_non_empty_value(ctx=ctx, value=ticket_id, label="TICKET_ID")
    confirm_and_execute_controlplane_sdk_and_render(
        ctx,
        yes=yes,
        message=f"Close ticket {tid!r}?",
        action=lambda client: client.control_plane.support.tickets.close(
            tid,
            timeout=timeout_s,
        ),
        default="json",
    )


tickets_group = attach_command_docs(
    tickets_group,
    summary="Support tickets (Control Plane).",
    examples=[
        CommandExampleMeta(
            command="tm tickets list",
            description="List support tickets for the current user.",
        ),
    ],
)
