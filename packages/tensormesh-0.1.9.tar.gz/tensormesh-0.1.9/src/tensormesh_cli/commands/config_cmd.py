from __future__ import annotations

from dataclasses import asdict
import json
from pathlib import Path
from typing import Any, Mapping

import click

from tensormesh_cli.app_context import get_app_context
from tensormesh_cli.config.constants import CANONICAL_CONTROLPLANE_ENV_VARS
from tensormesh_cli.config.constants import DEFAULT_MAX_RETRIES
from tensormesh_cli.config.constants import DEFAULT_TIMEOUT_SECONDS
from tensormesh_cli.config.constants import ENV_CA_BUNDLE
from tensormesh_cli.config.constants import ENV_MAX_RETRIES
from tensormesh_cli.config.constants import ENV_TIMEOUT_SECONDS
from tensormesh_cli.config.load import load_config_file
from tensormesh_cli.config.paths import default_config_path
from tensormesh_cli.config.public import resolved_config_public_dict
from tensormesh_cli.config.schema import MANAGED_KEY_ORDER
from tensormesh_cli.config.schema import MANAGED_SECTION
from tensormesh_cli.config.schema import OVERRIDES_SECTION
from tensormesh_cli.config.write import write_private_text
from tensormesh_cli.docs_meta import attach_command_docs
from tensormesh_cli.docs_meta import CommandExampleMeta
from tensormesh_cli.render import echo_output

_SUPPORTED_ENV_VARS = (
    *CANONICAL_CONTROLPLANE_ENV_VARS,
    ENV_TIMEOUT_SECONDS,
    ENV_MAX_RETRIES,
    ENV_CA_BUNDLE,
)
_SUPPORTED_ENV_VARS_TEXT = "\n".join(f"#   {env_var}"
                                     for env_var in _SUPPORTED_ENV_VARS)
_IMPORTED_DEFAULT_CONFIG_PATH = str(default_config_path())


def _toml_scalar(value: object) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        return repr(value)
    if isinstance(value, str):
        return json.dumps(value)
    raise RuntimeError(
        f"Unsupported value while writing config.toml template: {value!r}")


def _render_template(managed_cfg: Mapping[str, Any] | None = None) -> str:
    lines = [
        "# Tensormesh CLI config (TOML)",
        "#",
        "# Precedence:",
        "#   CLI flags > env vars > [overrides] > [managed] > defaults",
        "#",
        "# Environment variables supported:",
        _SUPPORTED_ENV_VARS_TEXT,
        "",
        "# Request behavior defaults (overridable per-command)",
        '# controlplane_base = "https://api.tensormesh.ai"',
        "# timeout_seconds must be > 0",
        "# max_retries must be an integer >= 0",
        f"timeout_seconds = {int(DEFAULT_TIMEOUT_SECONDS)}",
        f"max_retries = {DEFAULT_MAX_RETRIES}",
        '# ca_bundle = "~/.config/tensormesh/ca-bundle.pem"',
        "",
        f"[{OVERRIDES_SECTION}]",
        "# Manual gateway overrides. Uncomment only when you want config.toml to override",
        "# the managed values written by `tm init --sync`.",
        '# gateway_provider = "nebius"',
        '# gateway_api_key = "..."  # stored inference API key; SDK uses this as `inference_api_key`',
        '# gateway_user_id = "00000000-0000-0000-0000-000000000000"  # optional when tm auth is available',
        '# gateway_model_id = "your-served-model-name"  # compatibility key; value is sent as `model`',
        "",
        f"[{MANAGED_SECTION}]",
        "# Managed gateway values written by `tm init --sync`.",
    ]
    if managed_cfg:
        written: set[str] = set()
        for key in MANAGED_KEY_ORDER:
            if key in managed_cfg:
                lines.append(f"{key} = {_toml_scalar(managed_cfg[key])}")
                written.add(key)
        for key, value in managed_cfg.items():
            if key in written:
                continue
            lines.append(f"{key} = {_toml_scalar(value)}")
    else:
        lines.extend([
            '# synced_at = "2026-03-23T00:00:00Z"',
            '# gateway_provider = "nebius"',
            '# gateway_api_key = "..."  # stored inference API key; SDK uses this as `inference_api_key`',
            '# gateway_user_id = "00000000-0000-0000-0000-000000000000"',
            '# gateway_model_id = "your-served-model-name"  # compatibility key; value is sent as `model`',
        ])
    lines.append("")
    return "\n".join(lines)


@click.group(name="config")
def config_group() -> None:
    """Manage Tensormesh CLI configuration."""
    pass


@config_group.command(name="init")
@click.option(
    "--path",
    type=click.Path(dir_okay=False, path_type=str),
    default=_IMPORTED_DEFAULT_CONFIG_PATH,
    show_default=True,
    help="Path to write the config file.",
)
@click.option(
    "--force",
    is_flag=True,
    default=False,
    help=
    "Overwrite starter sections if the file exists, while preserving existing [managed] values."
)
def init_cmd(path: str, force: bool) -> None:
    if path == _IMPORTED_DEFAULT_CONFIG_PATH:
        path = str(default_config_path())
    p = Path(path).expanduser()

    if p.exists() and not force:
        raise click.ClickException(
            f"Config already exists: {p} (use --force to overwrite)")

    managed_cfg: Mapping[str, Any] | None = None
    if p.exists():
        existing_cfg = load_config_file(p)
        existing_managed = existing_cfg.get(MANAGED_SECTION)
        if existing_managed is not None:
            if not isinstance(existing_managed, Mapping):
                raise click.ClickException(
                    f"Invalid config file: {p}: [managed] must be a TOML table."
                )
            managed_cfg = dict(existing_managed)

    write_private_text(p, _render_template(managed_cfg))
    click.echo(str(p))


@config_group.command(name="show")
@click.option(
    "--sources",
    is_flag=True,
    default=False,
    help="Include where each resolved config value came from.",
)
@click.pass_context
def show_cmd(ctx: click.Context, sources: bool) -> None:
    """Print resolved configuration (secrets redacted)."""
    app = get_app_context(ctx)
    cfg = app.resolved_config
    data = resolved_config_public_dict(cfg)
    if sources:
        data = {
            "values": data,
            "sources": asdict(cfg.sources),
        }
    echo_output(output=app.output, data=data)


config_group = attach_command_docs(
    config_group,
    summary="Manage Tensormesh CLI configuration.",
    examples=[
        CommandExampleMeta(
            command="tm config init",
            description="Create a starter CLI config file.",
        ),
        CommandExampleMeta(
            command="tm config show",
            description="Inspect the currently resolved config values.",
        ),
    ],
)

init_cmd = attach_command_docs(
    init_cmd,
    summary="Write a starter Tensormesh CLI config template.",
    related_commands=["tm config show", "tm doctor"],
    examples=[
        CommandExampleMeta(
            command="tm config init",
            description=
            "Create the default config template in the standard location.",
        ),
        CommandExampleMeta(
            command="tm config init --path ./tensormesh.toml",
            description="Write the starter config to a project-local file.",
        ),
    ],
)

show_cmd = attach_command_docs(
    show_cmd,
    summary="Print resolved configuration (secrets redacted).",
    caveats=[
        "`gateway_api_key` is the stored inference API key used by the SDK as `inference_api_key`.",
        "`gateway_model_id` remains a config compatibility key; its value is the served model name string sent as `model`."
    ],
    related_commands=["tm config init", "tm auth status", "tm doctor"],
    examples=[
        CommandExampleMeta(
            command="tm config show",
            description="Print the currently resolved CLI configuration.",
        ),
        CommandExampleMeta(
            command="tm config show --sources",
            description=
            "Show both resolved values and where each value came from.",
        ),
    ],
)
