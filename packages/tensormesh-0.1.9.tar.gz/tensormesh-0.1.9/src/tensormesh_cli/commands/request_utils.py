from __future__ import annotations

from dataclasses import dataclass
import sys
from typing import Any, Callable, Generic, TypeVar

import click

from tensormesh_cli.http.json_input import load_json_optional
from tensormesh_cli.http.json_input import load_json_required

__all__ = [
    "ResolvedCommandRequest",
    "build_query_params",
    "load_command_json_object_optional",
    "load_command_json_object_required",
    "load_command_json_optional",
    "load_command_json_required",
    "load_validated_command_json_request",
    "map_controlplane_params",
    "require_json_object",
    "require_non_empty_value",
    "require_payload",
    "require_payload_string_fields",
    "resolve_command_payload",
    "resolve_command_request",
]

RequestT = TypeVar("RequestT")
ValueT = TypeVar("ValueT")
QueryValue = str | int | float | bool | None


@dataclass(frozen=True)
class ResolvedCommandRequest(Generic[RequestT]):
    request: RequestT
    payload: object


def build_query_params(**values: str | int | float | bool | None,
                       ) -> dict[str, str]:
    params: dict[str, str] = {}
    for key, value in values.items():
        if value is None:
            continue
        if isinstance(value, str):
            stripped = value.strip()
            if not stripped:
                continue
            params[key] = stripped
            continue
        if isinstance(value, bool):
            params[key] = "true" if value else "false"
            continue
        params[key] = str(value)
    return params


def _usage_error(ctx: click.Context, message: str) -> click.UsageError:
    return click.UsageError(message, ctx=ctx)


def _usage_error_from_value_error(
    ctx: click.Context,
    exc: ValueError,
    message: str | Callable[[ValueError], str] | None = None,
) -> click.UsageError:
    if callable(message):
        resolved_message = message(exc)
    elif message is not None:
        resolved_message = message
    else:
        resolved_message = str(exc)
    return _usage_error(ctx, resolved_message)


def _load_command_json(
    *,
    ctx: click.Context,
    json_arg: str | None,
    file_path: str | None,
    loader: Callable[..., ValueT],
) -> ValueT:
    try:
        return loader(json_arg=json_arg, file_path=file_path, stdin=sys.stdin)
    except ValueError as exc:
        raise _usage_error_from_value_error(ctx, exc) from exc


def load_command_json_optional(
    *,
    ctx: click.Context,
    json_arg: str | None,
    file_path: str | None,
) -> object | None:
    return _load_command_json(ctx=ctx,
                              json_arg=json_arg,
                              file_path=file_path,
                              loader=load_json_optional)


def load_command_json_required(
    *,
    ctx: click.Context,
    json_arg: str | None,
    file_path: str | None,
) -> object:
    return _load_command_json(ctx=ctx,
                              json_arg=json_arg,
                              file_path=file_path,
                              loader=load_json_required)


def load_command_json_object_optional(
    *,
    ctx: click.Context,
    json_arg: str | None,
    file_path: str | None,
    message: str = "Request body must be a JSON object.",
) -> dict[str, Any] | None:
    body_obj = load_command_json_optional(ctx=ctx,
                                          json_arg=json_arg,
                                          file_path=file_path)
    if body_obj is None:
        return None
    return require_json_object(ctx=ctx, body_obj=body_obj, message=message)


def load_command_json_object_required(
    *,
    ctx: click.Context,
    json_arg: str | None,
    file_path: str | None,
    message: str = "Request body must be a JSON object.",
) -> dict[str, Any]:
    body_obj = load_command_json_required(ctx=ctx,
                                          json_arg=json_arg,
                                          file_path=file_path)
    return require_json_object(ctx=ctx, body_obj=body_obj, message=message)


def require_json_object(
    *,
    ctx: click.Context,
    body_obj: object,
    message: str = "Request body must be a JSON object.",
) -> dict[str, Any]:
    if not isinstance(body_obj, dict):
        raise _usage_error(ctx, message)
    return body_obj


def resolve_command_request(
    *,
    ctx: click.Context,
    json_arg: str | None,
    file_path: str | None,
    build_from_values: Callable[[], RequestT],
    build_from_json: Callable[[object], RequestT],
    value_error_message: str | Callable[[ValueError], str] | None = None,
    to_payload: Callable[[RequestT], object] | None = None,
) -> ResolvedCommandRequest[RequestT]:
    body_obj = load_command_json_optional(ctx=ctx,
                                          json_arg=json_arg,
                                          file_path=file_path)
    if body_obj is None:
        try:
            request_obj = build_from_values()
        except ValueError as exc:
            raise _usage_error_from_value_error(ctx, exc,
                                                value_error_message) from exc
    else:
        try:
            request_obj = build_from_json(body_obj)
        except ValueError as exc:
            raise _usage_error_from_value_error(ctx, exc) from exc

    payload = (to_payload(request_obj)
               if to_payload is not None else request_obj.to_payload())
    return ResolvedCommandRequest(request=request_obj, payload=payload)


def resolve_command_payload(
    *,
    ctx: click.Context,
    json_arg: str | None,
    file_path: str | None,
    build_from_values: Callable[[], RequestT],
    build_from_json: Callable[[object], RequestT],
    value_error_message: str | Callable[[ValueError], str] | None = None,
    to_payload: Callable[[RequestT], object] | None = None,
    message: str = "Request body must be a JSON object.",
) -> dict[str, Any]:
    resolved = resolve_command_request(
        ctx=ctx,
        json_arg=json_arg,
        file_path=file_path,
        build_from_values=build_from_values,
        build_from_json=build_from_json,
        value_error_message=value_error_message,
        to_payload=to_payload,
    )
    return require_json_object(ctx=ctx,
                               body_obj=resolved.payload,
                               message=message)


def require_non_empty_value(
    *,
    ctx: click.Context,
    value: str,
    label: str,
) -> str:
    normalized = (value or "").strip()
    if normalized:
        return normalized
    raise click.UsageError(f"{label} is required.", ctx=ctx)


def require_payload_string_fields(
    *,
    ctx: click.Context,
    payload: dict[str, Any],
    field_names: tuple[str, ...],
    message: str,
) -> None:
    for field_name in field_names:
        if str(payload.get(field_name) or "").strip():
            continue
        raise click.UsageError(message, ctx=ctx)


def require_payload(
    *,
    ctx: click.Context,
    payload: dict[str, Any],
    predicate: Callable[[dict[str, Any]], bool],
    message: str,
) -> dict[str, Any]:
    if predicate(payload):
        return payload
    raise click.UsageError(message, ctx=ctx)


def map_controlplane_params(**command_values: QueryValue,
                            ) -> dict[str, QueryValue]:
    return {
        name.split("_", 1)[0] + "".join(part.capitalize()
                                        for part in name.split("_")[1:]): value
        for name, value in command_values.items()
    }


def load_validated_command_json_request(
    *,
    ctx: click.Context,
    json_arg: str | None,
    file_path: str | None,
    validate_from_dict: Callable[[dict[str, Any]], object],
    wrap_key: str | None = None,
    message: str = "Request body must be a JSON object.",
) -> dict[str, Any]:
    body_obj = load_command_json_required(
        ctx=ctx,
        json_arg=json_arg,
        file_path=file_path,
    )
    if wrap_key is None:
        payload = require_json_object(ctx=ctx,
                                      body_obj=body_obj,
                                      message=message)
    elif isinstance(body_obj, dict) and wrap_key in body_obj:
        payload = body_obj
    else:
        payload = {wrap_key: body_obj}
    try:
        validate_from_dict(payload)
    except (TypeError, ValueError, KeyError) as exc:
        raise click.UsageError(str(exc), ctx=ctx) from exc
    return payload
