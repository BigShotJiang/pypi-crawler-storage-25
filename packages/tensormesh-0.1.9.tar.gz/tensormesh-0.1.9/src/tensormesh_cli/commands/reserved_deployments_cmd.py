from __future__ import annotations

import click

from tensormesh.types import SubmitReservedDeploymentRequest
from tensormesh_cli.commands.click_helpers import json_input_options
from tensormesh_cli.commands.click_helpers import timeout_option
from tensormesh_cli.commands.controlplane_actions import \
    execute_controlplane_sdk_and_render
from tensormesh_cli.commands.request_utils import resolve_command_request
from tensormesh_cli.docs_meta import attach_command_docs
from tensormesh_cli.docs_meta import CommandExampleMeta


@click.group(name="reserved-deployments")
def reserved_deployments_group() -> None:
    """Reserved deployments (Support; Control Plane)."""
    pass


@reserved_deployments_group.command(name="submit")
@click.option("--full-name", "full_name", default=None, help="Full name.")
@click.option("--work-email", "work_email", default=None, help="Work email.")
@click.option("--company", default=None, help="Company name.")
@click.option("--job-title", "job_title", default=None, help="Job title.")
@click.option("--preferred-gpu",
              "preferred_gpu",
              default=None,
              help="Preferred GPU type enum.")
@click.option("--total-gpus-needed",
              "total_gpus_needed",
              default=None,
              help="Total GPUs needed (freeform, e.g. '<8 GPUs').")
@click.option("--deployment-timeline",
              "deployment_timeline",
              default=None,
              help="Deployment timeline (freeform, e.g. '1-3 months').")
@click.option("--workload-use-case",
              "workload_use_case",
              default=None,
              help="Workload / use case.")
@click.option("--networking-storage",
              "networking_storage",
              default=None,
              help="Networking / storage requirements.")
@click.option("--other-notes",
              "other_notes",
              default=None,
              help="Additional notes.")
@json_input_options(
    json_help="JSON request body or @file.json (overrides flags).",
    file_help="Read JSON request body from file (overrides flags).",
)
@timeout_option()
@click.pass_context
def reserved_deployments_submit_cmd(
    ctx: click.Context,
    full_name: str | None,
    work_email: str | None,
    company: str | None,
    job_title: str | None,
    preferred_gpu: str | None,
    total_gpus_needed: str | None,
    deployment_timeline: str | None,
    workload_use_case: str | None,
    networking_storage: str | None,
    other_notes: str | None,
    json_arg: str | None,
    file_path: str | None,
    timeout_s: float | None,
) -> None:
    """Submit reserved deployment request (POST /v1/support/reserved-deployments)."""
    resolved = resolve_command_request(
        ctx=ctx,
        json_arg=json_arg,
        file_path=file_path,
        build_from_values=lambda: SubmitReservedDeploymentRequest(
            full_name=full_name,
            work_email=work_email,
            company=company,
            job_title=job_title,
            preferred_gpu=preferred_gpu,
            total_gpus_needed=total_gpus_needed,
            deployment_timeline=deployment_timeline,
            workload_use_case=workload_use_case,
            networking_storage=networking_storage,
            other_notes=other_notes,
        ),
        build_from_json=lambda body: SubmitReservedDeploymentRequest.from_dict(
            body),
        to_payload=lambda request: request.to_dict(),
    )
    execute_controlplane_sdk_and_render(
        ctx,
        lambda client: client.control_plane.support.reserved_deployments.
        submit(
            request=resolved.payload,
            timeout=timeout_s,
        ),
        default="json",
    )


reserved_deployments_group = attach_command_docs(
    reserved_deployments_group,
    summary="Reserved deployments (Support; Control Plane).",
    examples=[
        CommandExampleMeta(
            command="tm reserved-deployments submit --help",
            description="Inspect the reserved deployment submission flow.",
        ),
    ],
)
