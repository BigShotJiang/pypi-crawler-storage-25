from __future__ import annotations

from pathlib import Path
from typing import Any

import click

from tensormesh_cli.app_context import get_app_context
from tensormesh_cli.commands.readiness import build_control_plane_summary_line
from tensormesh_cli.commands.readiness import build_first_request_command
from tensormesh_cli.commands.readiness import build_gateway_setup_steps
from tensormesh_cli.commands.readiness import build_gateway_summary_line
from tensormesh_cli.commands.readiness import \
    build_serverless_first_request_command
from tensormesh_cli.commands.readiness import controlplane_status_data
from tensormesh_cli.commands.readiness import gateway_status_data
from tensormesh_cli.commands.readiness import inspect_readiness
from tensormesh_cli.config.paths import default_config_path_display
from tensormesh_cli.config.runtime import sync_runtime_gateway_config
from tensormesh_cli.docs_meta import attach_command_docs
from tensormesh_cli.docs_meta import CommandExampleMeta
from tensormesh_cli.render import echo_status_screen
from tensormesh_cli.render import maybe_echo_structured_output

_DEFAULT_CONFIG_PATH_TEXT = default_config_path_display()


def _append_unique_steps(target: list[str], *steps: str) -> None:
    for step in steps:
        if step not in target:
            target.append(step)


@click.command(name="init")
@click.option(
    "--sync",
    "sync_runtime",
    is_flag=True,
    default=False,
    help=
    f"Sync the available gateway settings from the control plane, update [managed] in {_DEFAULT_CONFIG_PATH_TEXT}, and persist controlplane_base only when this command is run with --controlplane-base.",
)
@click.pass_context
def init_cmd(ctx: click.Context, sync_runtime: bool) -> None:
    """Guide first-time CLI setup for Control Plane and Gateway workflows."""
    app = get_app_context(ctx)
    cfg = app.resolved_config

    if sync_runtime:
        synced = sync_runtime_gateway_config(ctx,
                                             timeout_s=app.timeout_seconds)
        gateway_api_key_present = bool((synced.gateway_api_key or "").strip())
        data = {
            "synced": True,
            "config_path": synced.config_path,
            "gateway_provider": synced.gateway_provider,
            "gateway_api_key_present": gateway_api_key_present,
            "gateway_user_id": synced.gateway_user_id,
            "gateway_model_id": synced.gateway_model_id,
            "synced_at": synced.synced_at,
        }
        if maybe_echo_structured_output(ctx, data=data):
            return
        click.echo(f"Synced managed config: {synced.config_path}")
        provider_text = synced.gateway_provider or "unset"
        model_text = synced.gateway_model_id or "unset"
        click.echo(
            f"Gateway: provider={provider_text} api_key={'present' if gateway_api_key_present else 'missing'} user_id={synced.gateway_user_id} model_id={model_text}"
        )
        return

    config_exists = Path(cfg.config_path).expanduser().exists()

    snapshot = inspect_readiness(cfg)
    auth_state = snapshot.auth_state
    gateway_state = snapshot.gateway_state
    control_plane = controlplane_status_data(cfg, auth_state)
    gateway = gateway_status_data(cfg, gateway_state)

    ready_for_first_request = snapshot.ready_for_direct_request
    next_steps: list[str] = []
    optional_next_steps: list[str] = []
    warnings = snapshot.build_common_warnings()

    gateway_setup_steps = build_gateway_setup_steps(
        gateway_state, controlplane_ready=snapshot.control_plane_ready)
    next_steps.extend(gateway_setup_steps)
    if not ready_for_first_request:
        next_steps.append("tm infer doctor")
    next_steps.append(
        build_first_request_command(
            model_available=gateway_state.model_id_present))
    if not config_exists:
        optional_next_steps.append("tm config init")
    if (not auth_state.access_token_present
            and "tm auth login" not in gateway_setup_steps):
        optional_next_steps.append("tm auth login")
    if auth_state.error is None and not auth_state.access_token_present:
        warnings.append(
            "control plane auth is optional for a direct gateway request, but required for Control Plane commands and `--model @latest`"
        )
    warnings.append(
        "Local status only. Use `tm auth whoami` and `tm infer chat` for live verification."
    )
    if not auth_state.access_token_present:
        _append_unique_steps(optional_next_steps, "tm auth login")
    _append_unique_steps(
        optional_next_steps,
        "tm billing pricing serverless list",
        build_serverless_first_request_command(api_key_available=False),
    )
    filtered_optional_next_steps = [
        step for step in optional_next_steps if step not in next_steps
    ]

    data: dict[str, Any] = {
        "ready_for_first_request": ready_for_first_request,
        "config": {
            "path": cfg.config_path,
            "exists": config_exists,
            "source": cfg.sources.config_path,
        },
        "control_plane": {
            **control_plane,
            "ready": auth_state.access_token_present,
        },
        "gateway": {
            **gateway,
            "api_key_ready": gateway_state.api_key_present,
            "user_id_ready": gateway_state.user_id_ready,
            "model_id_ready": gateway_state.model_id_present,
        },
        "warnings": warnings,
        "next_steps": next_steps,
    }
    if filtered_optional_next_steps:
        data["optional_next_steps"] = filtered_optional_next_steps

    if maybe_echo_structured_output(ctx, data=data):
        return

    lines = [
        f"Config: {'ok' if data['config']['exists'] else 'missing'} ({cfg.config_path})",
        build_control_plane_summary_line(
            base=cfg.controlplane_base,
            access_token_present=auth_state.access_token_present,
        ),
        build_gateway_summary_line(
            provider=cfg.gateway_provider,
            base=cfg.gateway_base,
            gateway_state=gateway_state,
        ),
    ]
    if auth_state.error:
        lines.extend(["", f"Control Plane token error: {auth_state.error}"])
    echo_status_screen("tm init",
                       lines=lines,
                       warnings=warnings,
                       next_steps=next_steps)
    if filtered_optional_next_steps:
        click.echo("")
        click.echo("Optional next steps:")
        for index, step in enumerate(filtered_optional_next_steps, start=1):
            click.echo(f"{index}. {step}")


init_cmd = attach_command_docs(
    init_cmd,
    summary=
    "Guide first-time CLI setup for Control Plane and Gateway workflows.",
    examples=[
        CommandExampleMeta(
            command="tm init",
            description=
            "Inspect local setup and print the next commands required for a first request.",
        ),
        CommandExampleMeta(
            command="tm init --sync",
            description=
            f"Sync the available gateway settings from the control plane, store them under [managed] in {_DEFAULT_CONFIG_PATH_TEXT}, and persist controlplane_base for later commands when this command is run with --controlplane-base.",
        ),
    ],
    related_commands=[
        "tm auth status", "tm billing pricing serverless list",
        "tm config show", "tm infer doctor", "tm infer chat"
    ],
)
