from __future__ import annotations

import click

from tensormesh_cli.controlplane_models import select_latest_controlplane_model


def resolve_latest_gateway_model(
    ctx: click.Context,
    *,
    timeout_s: float,
) -> str:
    try:
        from tensormesh_cli.controlplane import execute_controlplane_sdk

        models, _ = execute_controlplane_sdk(
            ctx,
            lambda client: client.control_plane.models.list(timeout=timeout_s),
        )
    except click.ClickException as exc:
        prefix = "Invalid JSON response: expected JSON. Raw response: "
        if exc.message.startswith(prefix):
            raise click.ClickException(
                "Failed to resolve @latest: control plane returned non-JSON: "
                f"{exc.message[len(prefix):]}") from exc
        raise

    data = {"models": [model.to_dict() for model in models]}

    return select_latest_controlplane_model(controlplane_data=data)
