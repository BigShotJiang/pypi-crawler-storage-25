from __future__ import annotations

from importlib.util import find_spec
from pathlib import Path
import platform
import sys

import click

from tensormesh_cli import __version__
from tensormesh_cli.build_info import INSTALL_GUIDE
from tensormesh_cli.build_info import REQUIRES_PYTHON
from tensormesh_cli.docs_meta import attach_command_docs
from tensormesh_cli.docs_meta import CommandExampleMeta
from tensormesh_cli.render import context_output
from tensormesh_cli.render import echo_output


def _distribution_model(package_root: str) -> str:
    if getattr(sys, "frozen", False):
        return "standalone-binary"

    normalized = package_root.replace("\\", "/").lower()
    if "/site-packages/" in normalized or "/dist-packages/" in normalized:
        return "python-package"

    return "python-source"


@click.command(name="version")
@click.pass_context
def version_cmd(ctx: click.Context) -> None:
    """Show CLI version and runtime details."""
    spec = find_spec("tensormesh_cli")
    package_root = ""
    if spec is not None and spec.origin is not None:
        package_root = str(Path(spec.origin).resolve().parent)
    data = {
        "cli_version": __version__,
        "python_version": platform.python_version(),
        "python_implementation": platform.python_implementation(),
        "platform": platform.platform(),
        "executable": sys.executable,
        "package_root": package_root,
        "requires_python": REQUIRES_PYTHON,
        "distribution_model": _distribution_model(package_root),
        "install_guide": INSTALL_GUIDE,
    }
    out = context_output(ctx)

    if out == "raw":
        click.echo(data["cli_version"])
        return
    if out in ("json", "yaml", "table"):
        echo_output(output=out, data=data)
        return

    click.echo("tm version")
    click.echo("")
    click.echo(f"CLI version: {data['cli_version']}")
    click.echo(
        f"Python: {data['python_version']} ({data['python_implementation']})")
    click.echo(f"Requires Python: {data['requires_python']}")
    click.echo(f"Distribution: {data['distribution_model']}")
    click.echo(f"Platform: {data['platform']}")
    click.echo(f"Executable: {data['executable']}")
    click.echo(f"Package root: {data['package_root']}")


version_cmd = attach_command_docs(
    version_cmd,
    summary="Show CLI version and runtime details.",
    examples=[
        CommandExampleMeta(
            command="tm version",
            description="Show the installed CLI version and runtime details.",
        ),
        CommandExampleMeta(
            command="tm --output json version",
            description=
            "Emit version and runtime details in machine-readable JSON.",
        ),
    ],
    related_commands=["tm init", "tm config show"],
)
