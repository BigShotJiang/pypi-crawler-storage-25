from __future__ import annotations

import click

from tensormesh_cli.commands._generated_controlplane_gap_cmd import \
    attach_generated_admin_billing_gap_commands
from tensormesh_cli.commands.admin_billing_balances_cmd import \
    admin_balances_group
from tensormesh_cli.commands.admin_billing_pricing_cmd import \
    admin_pricing_group
from tensormesh_cli.commands.admin_models_cmd import admin_models_group
from tensormesh_cli.commands.admin_products_cmd import admin_products_group
from tensormesh_cli.commands.admin_users_cmd import admin_users_group
from tensormesh_cli.docs_meta import attach_command_docs
from tensormesh_cli.docs_meta import CommandExampleMeta


@click.group(name="billing")
def admin_billing_group() -> None:
    """Admin billing tools."""
    pass


@click.group(name="admin")
def admin_group() -> None:
    """Admin-only commands (Control Plane)."""
    pass


admin_billing_group.add_command(admin_pricing_group)
admin_billing_group.add_command(admin_balances_group)
attach_generated_admin_billing_gap_commands(admin_billing_group)
admin_group.add_command(admin_billing_group)
admin_group.add_command(admin_models_group)
admin_group.add_command(admin_users_group)
admin_group.add_command(admin_products_group)

admin_billing_group = attach_command_docs(
    admin_billing_group,
    summary="Admin billing tools.",
    examples=[
        CommandExampleMeta(
            command="tm admin billing pricing serverless list",
            description="Inspect admin serverless pricing records.",
        ),
    ],
)

admin_group = attach_command_docs(
    admin_group,
    summary="Admin-only commands (Control Plane).",
    examples=[
        CommandExampleMeta(
            command="tm admin users list",
            description="Inspect the admin-only user management surface.",
        ),
    ],
)
