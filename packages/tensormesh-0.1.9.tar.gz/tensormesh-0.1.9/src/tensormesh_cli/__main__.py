from __future__ import annotations

from tensormesh_cli.cli import cli

if __name__ == "__main__":
    cli()
