from __future__ import annotations

from datetime import datetime
from datetime import timezone
from typing import Any, Callable

import click

__all__ = [
    "controlplane_gateway_api_key",
    "controlplane_gateway_model_id",
    "controlplane_gateway_provider",
    "is_resolvable_latest_controlplane_model",
    "is_syncable_controlplane_model",
    "required_controlplane_gateway_model_id",
    "select_latest_controlplane_model",
    "select_latest_controlplane_model_record",
]

_EPOCH = datetime.fromtimestamp(0, tz=timezone.utc)
_CONTROLPLANE_PROVIDER_TO_GATEWAY = {
    "CLOUD_PROVIDER_NEBIUS": "nebius",
    "CLOUD_PROVIDER_LAMBDA": "lambda",
    "CLOUD_PROVIDER_YOTTA": "yotta",
}


def _parse_dt(value: object, *, field: str) -> datetime | None:
    if value is None:
        return None
    if not isinstance(value, str):
        raise ValueError(f"{field} must be an RFC3339 string when present.")
    s = value.strip()
    if not s:
        return None
    try:
        if s.endswith("Z"):
            s = s[:-1] + "+00:00"
        dt = datetime.fromisoformat(s)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt
    except ValueError as exc:
        raise ValueError(
            f"{field} must be a valid RFC3339 timestamp.") from exc


def _first_present_string(model: dict[str, Any], *keys: str) -> str | None:
    for key in keys:
        value = model.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return None


def _controlplane_model_label(model: dict[str, Any]) -> str:
    return (_first_present_string(model, "modelName", "deploymentId",
                                  "modelId") or "<unknown>")


def controlplane_gateway_model_id(model: dict[str, Any]) -> str | None:
    return _first_present_string(model, "modelName", "deploymentId")


def required_controlplane_gateway_model_id(
    model: dict[str, Any],
    *,
    error_prefix: str,
) -> str:
    model_id = controlplane_gateway_model_id(model)
    if model_id is None:
        raise click.ClickException(
            f"{error_prefix}: selected control plane model is missing modelName/deploymentId."
        )
    return model_id


def controlplane_gateway_provider(
    model: dict[str, Any],
    *,
    error_prefix: str,
) -> str:
    infra = model.get("infra")
    provider = infra.get("cloudProvider") if isinstance(infra, dict) else None
    if not isinstance(provider, str) or not provider.strip():
        raise click.ClickException(
            f"{error_prefix}: selected control plane model is missing infra.cloudProvider."
        )
    resolved = _CONTROLPLANE_PROVIDER_TO_GATEWAY.get(provider.strip())
    if resolved is None:
        raise click.ClickException(
            f"{error_prefix}: selected control plane model uses an unsupported provider."
        )
    return resolved


def controlplane_gateway_api_key(
    model: dict[str, Any],
    *,
    error_prefix: str,
) -> str:
    api_key = model.get("apiKey")
    if not isinstance(api_key, str) or not api_key.strip():
        raise click.ClickException(
            f"{error_prefix}: selected control plane model is missing apiKey.")
    return api_key.strip()


def is_resolvable_latest_controlplane_model(model: dict[str, Any]) -> bool:
    return (controlplane_gateway_model_id(model) is not None
            and model.get("status") == "MODEL_STATUS_UP")


def is_syncable_controlplane_model(model: dict[str, Any]) -> bool:
    infra = model.get("infra")
    provider = infra.get("cloudProvider") if isinstance(infra, dict) else None
    api_key = model.get("apiKey")
    return (isinstance(provider, str)
            and provider.strip() in _CONTROLPLANE_PROVIDER_TO_GATEWAY
            and isinstance(api_key, str) and api_key.strip()
            and is_resolvable_latest_controlplane_model(model))


def _controlplane_candidate_score(
    model: dict[str, Any],
    *,
    invalid_metadata_prefix: str,
) -> tuple[int, int, datetime, datetime]:
    name_rank = 1 if isinstance(model.get("modelName"), str) and str(
        model.get("modelName") or "").strip() else 0
    status_rank = 1 if model.get("status") == "MODEL_STATUS_UP" else 0
    try:
        updated = _parse_dt(model.get("updatedAt"),
                            field="updatedAt") or _EPOCH
        created = _parse_dt(model.get("createdAt"),
                            field="createdAt") or _EPOCH
    except ValueError as exc:
        raise click.ClickException(
            f"{invalid_metadata_prefix}: model {_controlplane_model_label(model)!r} has invalid metadata: {exc}"
        ) from exc
    return (name_rank, status_rank, updated, created)


def select_latest_controlplane_model_record(
    *,
    controlplane_data: object,
    candidate_filter: Callable[[dict[str, Any]], bool] | None = None,
    failure_message: str | None = None,
    invalid_metadata_prefix: str = "Failed to resolve @latest",
) -> dict[str, Any]:
    controlplane_models = (controlplane_data.get("models") if isinstance(
        controlplane_data, dict) else None)
    if not isinstance(controlplane_models, list):
        raise click.ClickException(
            f"{invalid_metadata_prefix}: unexpected /v1/models response shape (expected {{models:[...]}})."
        )

    candidates: list[dict[str, Any]] = []
    for model in controlplane_models:
        if not isinstance(model, dict):
            continue
        if controlplane_gateway_model_id(model) is None:
            continue
        if candidate_filter is not None and not candidate_filter(model):
            continue
        status = model.get("status")
        if isinstance(status, str) and status == "MODEL_STATUS_DELETED":
            continue
        candidates.append(model)

    if not candidates:
        raise click.ClickException(
            failure_message or
            "Failed to resolve @latest: no models with modelName/deploymentId found in control plane inventory.\n"
            "Hint: try `tm --output json models list` to inspect Control Plane inventory / On-Demand served names (requires Control Plane auth).",
        )

    return sorted(
        candidates,
        key=lambda model: _controlplane_candidate_score(
            model, invalid_metadata_prefix=invalid_metadata_prefix),
        reverse=True,
    )[0]


def select_latest_controlplane_model(
    *,
    controlplane_data: object,
    error_prefix: str = "Failed to resolve @latest",
) -> str:
    best = select_latest_controlplane_model_record(
        controlplane_data=controlplane_data,
        candidate_filter=is_resolvable_latest_controlplane_model,
        failure_message=(
            "Failed to resolve @latest: no served models with "
            "modelName/deploymentId found in control plane inventory.\n"
            "Hint: try `tm --output json models list` and look for records "
            "with `status = MODEL_STATUS_UP`."),
        invalid_metadata_prefix=error_prefix,
    )
    return required_controlplane_gateway_model_id(best,
                                                  error_prefix=error_prefix)
