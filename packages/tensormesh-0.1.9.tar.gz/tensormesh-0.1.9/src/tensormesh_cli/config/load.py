from __future__ import annotations

from pathlib import Path
import tomllib
from typing import Any, Mapping

from .schema import GATEWAY_KEYS
from .schema import is_reserved_top_level_config_key
from .schema import MANAGED_SECTION
from .schema import OVERRIDES_SECTION

__all__ = [
    "flatten_resolved_config_file",
    "load_config_file",
]


def load_config_file(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    try:
        data = tomllib.loads(path.read_text(encoding="utf-8"))
    except OSError as exc:
        raise RuntimeError(
            f"Failed to read config file: {path}: {exc}") from exc
    except tomllib.TOMLDecodeError as exc:
        raise RuntimeError(
            f"Invalid config file (TOML): {path}: {exc}") from exc
    return data


def flatten_resolved_config_file(
    raw_cfg: Mapping[str, Any], ) -> tuple[dict[str, Any], dict[str, str]]:
    managed = raw_cfg.get(MANAGED_SECTION, {})
    overrides = raw_cfg.get(OVERRIDES_SECTION, {})
    if MANAGED_SECTION in raw_cfg and not isinstance(managed, Mapping):
        raise RuntimeError(
            "Invalid config file: [managed] must be a TOML table.")
    if OVERRIDES_SECTION in raw_cfg and not isinstance(overrides, Mapping):
        raise RuntimeError(
            "Invalid config file: [overrides] must be a TOML table.")

    managed_map = dict(managed) if isinstance(managed, Mapping) else {}
    overrides_map = dict(overrides) if isinstance(overrides, Mapping) else {}

    resolved: dict[str, Any] = {}
    sources: dict[str, str] = {}

    for key, value in raw_cfg.items():
        key_str = str(key)
        if is_reserved_top_level_config_key(key_str):
            if key_str in GATEWAY_KEYS:
                # Top-level gateway_* keys are no longer part of the supported
                # schema. Ignore them here so only [managed]/[overrides] drive
                # the resolved gateway config, while `tm init --sync` can still
                # rewrite stale files into the canonical layout.
                continue
            continue
        resolved[key_str] = value
        sources[key_str] = f"config:{key_str}"

    for key in GATEWAY_KEYS:
        if key in managed_map:
            resolved[key] = managed_map[key]
            sources[key] = f"managed:{key}"

    for key in GATEWAY_KEYS:
        if key in overrides_map:
            resolved[key] = overrides_map[key]
            sources[key] = f"config:{key}"

    return resolved, sources
