from __future__ import annotations

import os
from pathlib import Path

from .constants import ENV_CONFIG_HOME

__all__ = [
    "default_config_home",
    "default_config_home_display",
    "default_auth_json_path",
    "default_auth_json_path_display",
    "default_config_path",
    "default_config_path_display",
]


def _override_config_home() -> str | None:
    value = os.environ.get(ENV_CONFIG_HOME)
    if value is None:
        return None
    value = value.strip()
    return value or None


def _display_path(path: Path) -> str:
    home = Path.home()
    try:
        relative = path.relative_to(home)
    except ValueError:
        return str(path)
    return str(Path("~") / relative)


def default_config_home() -> Path:
    override = _override_config_home()
    if override is not None:
        return Path(override).expanduser()
    return Path.home() / ".config" / "tensormesh"


def default_config_home_display() -> str:
    override = _override_config_home()
    if override is not None:
        return f"${ENV_CONFIG_HOME}"
    return "~/.config/tensormesh"


def default_auth_json_path() -> Path:
    return default_config_home() / "auth.json"


def default_auth_json_path_display() -> str:
    override = _override_config_home()
    if override is not None:
        return f"${ENV_CONFIG_HOME}/auth.json"
    return _display_path(default_auth_json_path())


def default_config_path() -> Path:
    return default_config_home() / "config.toml"


def default_config_path_display() -> str:
    override = _override_config_home()
    if override is not None:
        return f"${ENV_CONFIG_HOME}/config.toml"
    return _display_path(default_config_path())
