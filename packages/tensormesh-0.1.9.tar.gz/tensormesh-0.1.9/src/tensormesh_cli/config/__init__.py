"""Configuration package for the Tensormesh CLI."""
