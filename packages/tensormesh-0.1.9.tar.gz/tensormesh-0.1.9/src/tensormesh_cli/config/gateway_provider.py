from __future__ import annotations

from .constants import DEFAULT_GATEWAY_BASES
from .constants import GATEWAY_PROVIDER_NAMES

__all__ = [
    "GATEWAY_PROVIDER_EXPECTED_TEXT",
    "gateway_base_for_provider",
    "normalize_gateway_provider",
]

_GATEWAY_PROVIDER_ALIASES = {
    "nebius": "nebius",
    "lambda": "lambda",
    "yotta": "yotta",
}

GATEWAY_PROVIDER_EXPECTED_TEXT = f"one of: {', '.join(GATEWAY_PROVIDER_NAMES)}"


def normalize_gateway_provider(value: str | None) -> str | None:
    if value is None:
        return None
    normalized = value.strip().lower()
    if not normalized:
        return None
    return _GATEWAY_PROVIDER_ALIASES.get(normalized)


def gateway_base_for_provider(value: str | None) -> str | None:
    normalized = normalize_gateway_provider(value)
    if normalized is None:
        return None
    return DEFAULT_GATEWAY_BASES.get(normalized)
