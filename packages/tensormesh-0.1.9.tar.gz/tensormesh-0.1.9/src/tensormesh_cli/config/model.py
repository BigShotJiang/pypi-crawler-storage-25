from __future__ import annotations

from dataclasses import dataclass

__all__ = ["ResolvedConfig", "ResolvedConfigSources"]


@dataclass(frozen=True)
class ResolvedConfigSources:
    config_path: str
    controlplane_base: str
    controlplane_auth_json: str
    gateway_provider: str
    gateway_base: str
    gateway_api_key: str | None
    gateway_user_id: str | None
    gateway_model_id: str | None
    ca_bundle: str | None
    timeout_seconds: str
    max_retries: str


@dataclass(frozen=True)
class ResolvedConfig:
    config_path: str
    controlplane_base: str
    controlplane_auth_json: str
    gateway_provider: str
    gateway_base: str
    gateway_api_key: str | None
    gateway_user_id: str | None
    gateway_model_id: str | None
    ca_bundle: str | None
    timeout_seconds: float
    max_retries: int
    sources: ResolvedConfigSources
