from __future__ import annotations

__all__ = [
    "GATEWAY_KEYS",
    "MANAGED_KEY_ORDER",
    "MANAGED_SECTION",
    "OVERRIDES_SECTION",
    "is_reserved_top_level_config_key",
]

MANAGED_SECTION = "managed"
OVERRIDES_SECTION = "overrides"
GATEWAY_KEYS = (
    "gateway_provider",
    "gateway_api_key",
    "gateway_user_id",
    "gateway_model_id",
)
MANAGED_KEY_ORDER = ("synced_at", *GATEWAY_KEYS)


def is_reserved_top_level_config_key(key: str) -> bool:
    return key in (MANAGED_SECTION, OVERRIDES_SECTION, *GATEWAY_KEYS)
