from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from datetime import timezone
import json
from pathlib import Path
from typing import Any, Mapping

import click

from tensormesh.types import ApiKey
from tensormesh_cli.app_context import get_app_context
from tensormesh_cli.config.load import load_config_file
from tensormesh_cli.config.schema import is_reserved_top_level_config_key
from tensormesh_cli.config.schema import MANAGED_KEY_ORDER
from tensormesh_cli.config.schema import MANAGED_SECTION
from tensormesh_cli.config.schema import OVERRIDES_SECTION
from tensormesh_cli.config.write import write_private_text
from tensormesh_cli.controlplane import execute_controlplane_sdk
from tensormesh_cli.controlplane import \
    resolve_gateway_user_id_from_controlplane
from tensormesh_cli.controlplane_models import controlplane_gateway_api_key
from tensormesh_cli.controlplane_models import controlplane_gateway_provider
from tensormesh_cli.controlplane_models import is_syncable_controlplane_model
from tensormesh_cli.controlplane_models import \
    required_controlplane_gateway_model_id
from tensormesh_cli.controlplane_models import \
    select_latest_controlplane_model_record

__all__ = ["RuntimeGatewayConfig", "sync_runtime_gateway_config"]


@dataclass(frozen=True)
class RuntimeGatewayConfig:
    config_path: str
    gateway_provider: str | None
    gateway_api_key: str
    gateway_user_id: str
    gateway_model_id: str | None
    synced_at: str


def _should_persist_controlplane_base(source: str | None) -> bool:
    return source == "--controlplane-base"


def _parse_rfc3339(value: str | None, *, field: str) -> datetime | None:
    if value is None:
        return None
    s = value.strip()
    if not s:
        return None
    try:
        if s.endswith("Z"):
            s = s[:-1] + "+00:00"
        dt = datetime.fromisoformat(s)
    except ValueError as exc:
        raise click.ClickException(
            f"Failed to sync managed gateway config: API key metadata field "
            f"{field!r} must be a valid RFC3339 timestamp.") from exc
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt


def _select_latest_controlplane_api_key(api_keys: list[ApiKey]) -> str:
    now = datetime.now(tz=timezone.utc)
    candidates: list[tuple[datetime, str]] = []
    for api_key in api_keys:
        key_id = (api_key.id or "").strip()
        if not key_id:
            continue
        deleted_at = _parse_rfc3339(api_key.deleted_at, field="deletedAt")
        if deleted_at is not None:
            continue
        expires_at = _parse_rfc3339(api_key.expires_at, field="expiresAt")
        if expires_at is not None and expires_at <= now:
            continue
        created_at = (_parse_rfc3339(api_key.created_at, field="createdAt")
                      or datetime.fromtimestamp(0, tz=timezone.utc))
        candidates.append((created_at, key_id))
    if not candidates:
        raise click.ClickException(
            "Failed to sync managed gateway config: no active user API keys "
            "found in control plane inventory.")
    candidates.sort(reverse=True)
    return candidates[0][1]


def _toml_value(value: object) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        return repr(value)
    if isinstance(value, str):
        return json.dumps(value)
    if isinstance(value, (list, tuple)):
        return "[" + ", ".join(_toml_value(item) for item in value) + "]"
    raise RuntimeError(
        f"Unsupported value while writing config.toml: {value!r}")


def _write_table(lines: list[str],
                 name: str,
                 values: Mapping[str, Any],
                 key_order: tuple[str, ...] | None = None) -> None:
    lines.append(f"[{name}]")
    written: set[str] = set()
    nested_tables: list[tuple[str, Mapping[str, Any]]] = []
    if key_order is not None:
        for key in key_order:
            if key in values:
                value = values[key]
                if isinstance(value, Mapping):
                    raise RuntimeError(
                        f"Nested table {name}.{key} is not supported for ordered table keys."
                    )
                lines.append(f"{key} = {_toml_value(value)}")
                written.add(key)
    for key, value in values.items():
        if key in written:
            continue
        if isinstance(value, Mapping):
            nested_tables.append((key, value))
            continue
        lines.append(f"{key} = {_toml_value(value)}")
    for key, value in nested_tables:
        lines.append("")
        _write_table(lines, f"{name}.{key}", value)


def _render_config_toml(
    existing_cfg: Mapping[str, Any],
    managed_cfg: Mapping[str, object],
) -> str:
    lines = [
        "# Tensormesh CLI config (TOML)",
        "# Managed gateway values are written by `tm init --sync` under [managed].",
        "# Edit top-level request settings or [overrides] for manual overrides.",
    ]

    top_level_keys: list[str] = []
    top_level_values: dict[str, object] = {}
    top_level_tables: list[tuple[str, Mapping[str, Any]]] = []
    for key, value in existing_cfg.items():
        key_str = str(key)
        if is_reserved_top_level_config_key(key_str):
            continue
        if isinstance(value, Mapping):
            top_level_tables.append((key_str, value))
            continue
        top_level_keys.append(key_str)
        top_level_values[key_str] = value

    if top_level_keys:
        lines.append("")
        for key in top_level_keys:
            lines.append(f"{key} = {_toml_value(top_level_values[key])}")

    for key, value in top_level_tables:
        lines.append("")
        _write_table(lines, key, value)

    existing_overrides = existing_cfg.get(OVERRIDES_SECTION, {})
    if existing_overrides and not isinstance(existing_overrides, Mapping):
        raise RuntimeError(
            "Invalid config file: [overrides] must be a TOML table.")
    overrides_map = dict(existing_overrides) if isinstance(
        existing_overrides, Mapping) else {}

    lines.append("")
    _write_table(lines, MANAGED_SECTION, managed_cfg, MANAGED_KEY_ORDER)
    lines.append("")
    _write_table(lines, OVERRIDES_SECTION, overrides_map)
    lines.append("")
    return "\n".join(lines)


def sync_runtime_gateway_config(
    ctx: click.Context,
    *,
    timeout_s: float,
) -> RuntimeGatewayConfig:
    app = get_app_context(ctx)
    user_id = resolve_gateway_user_id_from_controlplane(ctx,
                                                        timeout_s=timeout_s)
    models, _ = execute_controlplane_sdk(
        ctx,
        lambda client: client.control_plane.models.list(timeout=timeout_s),
    )
    data = {"models": [model.to_dict() for model in models]}

    config_path = Path(app.resolved_config.config_path).expanduser()
    config_path.parent.mkdir(parents=True, exist_ok=True)
    existing_cfg = load_config_file(config_path)
    if _should_persist_controlplane_base(
            app.resolved_config.sources.controlplane_base):
        existing_cfg = dict(existing_cfg)
        existing_cfg[
            "controlplane_base"] = app.resolved_config.controlplane_base
    synced_at = datetime.now(tz=timezone.utc).isoformat().replace(
        "+00:00", "Z")

    try:
        model = select_latest_controlplane_model_record(
            controlplane_data=data,
            candidate_filter=is_syncable_controlplane_model,
            failure_message=
            "Failed to sync managed gateway config: no served models with modelName/deploymentId plus infra.cloudProvider and apiKey found in control plane inventory.",
            invalid_metadata_prefix="Failed to sync managed gateway config",
        )
    except click.ClickException as exc:
        if "no served models with modelName/deploymentId plus infra.cloudProvider and apiKey found in control plane inventory." not in str(
                exc):
            raise
        api_keys, _ = execute_controlplane_sdk(
            ctx,
            lambda client: client.control_plane.users.api_keys.list(
                user_id=user_id,
                timeout=timeout_s,
            ),
        )
        config = RuntimeGatewayConfig(
            config_path=str(config_path),
            gateway_provider=None,
            gateway_api_key=_select_latest_controlplane_api_key(api_keys),
            gateway_user_id=user_id,
            gateway_model_id=None,
            synced_at=synced_at,
        )
    else:
        config = RuntimeGatewayConfig(
            config_path=str(config_path),
            gateway_provider=controlplane_gateway_provider(
                model, error_prefix="Failed to sync managed gateway config"),
            gateway_api_key=controlplane_gateway_api_key(
                model, error_prefix="Failed to sync managed gateway config"),
            gateway_user_id=user_id,
            gateway_model_id=required_controlplane_gateway_model_id(
                model, error_prefix="Failed to sync managed gateway config"),
            synced_at=synced_at,
        )

    managed_cfg: dict[str, object] = {
        "synced_at": config.synced_at,
        "gateway_api_key": config.gateway_api_key,
        "gateway_user_id": config.gateway_user_id,
    }
    if config.gateway_provider is not None:
        managed_cfg["gateway_provider"] = config.gateway_provider
    if config.gateway_model_id is not None:
        managed_cfg["gateway_model_id"] = config.gateway_model_id
    write_private_text(config_path,
                       _render_config_toml(existing_cfg, managed_cfg))
    return config
