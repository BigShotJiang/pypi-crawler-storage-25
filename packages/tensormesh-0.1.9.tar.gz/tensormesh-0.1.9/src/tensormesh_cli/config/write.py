from __future__ import annotations

import os
from pathlib import Path
import tempfile


def write_private_text(path: Path, contents: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)

    tmp_name: str | None = None
    dir_fd: int | None = None
    try:
        dir_fd = os.open(str(path.parent), os.O_RDONLY)
        fd, tmp_name = tempfile.mkstemp(
            prefix=f".{path.name}.",
            suffix=".tmp",
            dir=str(path.parent),
        )
        os.fchmod(fd, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as file_obj:
            file_obj.write(contents)
            file_obj.flush()
            os.fsync(file_obj.fileno())
        os.replace(tmp_name, str(path))
        tmp_name = None
        os.chmod(str(path), 0o600)
        os.fsync(dir_fd)
    finally:
        if dir_fd is not None:
            try:
                os.close(dir_fd)
            except OSError:
                pass
        if tmp_name is not None:
            try:
                os.unlink(tmp_name)
            except OSError:
                pass
