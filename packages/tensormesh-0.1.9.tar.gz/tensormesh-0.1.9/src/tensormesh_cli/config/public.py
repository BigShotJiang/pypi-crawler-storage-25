from __future__ import annotations

from .model import ResolvedConfig

__all__ = ["resolved_config_public_dict"]


def resolved_config_public_dict(cfg: ResolvedConfig) -> dict[str, object]:
    from tensormesh_cli.output_utils import redact_secret

    return {
        "config_path": cfg.config_path,
        "controlplane_base": cfg.controlplane_base,
        "gateway_provider": cfg.gateway_provider,
        "gateway_base": cfg.gateway_base,
        "controlplane_auth_json": cfg.controlplane_auth_json,
        "gateway_api_key": redact_secret(cfg.gateway_api_key),
        "gateway_user_id": cfg.gateway_user_id,
        "gateway_model_id": cfg.gateway_model_id,
        "ca_bundle": cfg.ca_bundle,
        "timeout_seconds": cfg.timeout_seconds,
        "max_retries": cfg.max_retries,
    }
