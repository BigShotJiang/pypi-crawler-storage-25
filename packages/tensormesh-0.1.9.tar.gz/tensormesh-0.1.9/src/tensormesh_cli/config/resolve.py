from __future__ import annotations

from dataclasses import dataclass
import os
from pathlib import Path
from typing import Callable, Mapping, TypeVar

from .constants import DEFAULT_CONTROLPLANE_BASE
from .constants import DEFAULT_GATEWAY_PROVIDER
from .constants import DEFAULT_MAX_RETRIES
from .constants import DEFAULT_TIMEOUT_SECONDS
from .constants import ENV_CA_BUNDLE
from .constants import ENV_CONTROL_PLANE_BASE_URL
from .constants import ENV_MAX_RETRIES
from .constants import ENV_TIMEOUT_SECONDS
from .gateway_provider import gateway_base_for_provider
from .gateway_provider import GATEWAY_PROVIDER_EXPECTED_TEXT
from .gateway_provider import normalize_gateway_provider
from .model import ResolvedConfig
from .model import ResolvedConfigSources
from .paths import default_auth_json_path
from .paths import default_auth_json_path_display
from .paths import default_config_path

__all__ = ["resolve_config"]
NumberT = TypeVar("NumberT", int, float)


def _removed_config_key_hints() -> dict[str, str]:
    return {
        "profile":
        "named profiles are no longer supported; move those values to top-level keys in config.toml.",
        "profiles":
        "named profiles are no longer supported; flatten [profiles.*] into top-level keys in config.toml.",
        "controlplane_auth_json":
        f"control plane auth always uses {default_auth_json_path_display()}.",
    }


@dataclass(frozen=True)
class _ResolveInputs:
    cli: Mapping[str, object]
    env: Mapping[str, str]
    env_sources: Mapping[str, str] | None
    file_cfg: Mapping[str, object]
    file_sources: Mapping[str, str] | None
    defaults: Mapping[str, object]


@dataclass(frozen=True)
class _ResolvedConfigContext:
    config_path: str
    config_path_source: str
    file_map: Mapping[str, object]


@dataclass(frozen=True)
class _ResolvedCredentialFields:
    controlplane_auth_json: str
    controlplane_auth_json_source: str | None
    gateway_api_key: str | None
    gateway_api_key_source: str | None
    gateway_user_id: str | None
    gateway_user_id_source: str | None
    gateway_model_id: str | None
    gateway_model_id_source: str | None
    ca_bundle: str | None
    ca_bundle_source: str | None


@dataclass(frozen=True)
class _ResolvedRuntimeFields:
    timeout_seconds: float
    timeout_seconds_source: str
    max_retries: int
    max_retries_source: str


def _clean_str(value: object) -> str | None:
    if value is None:
        return None
    if isinstance(value, Path):
        return str(value)
    if not isinstance(value, str):
        return None
    s = value.strip()
    return s if s else None


def _clean_int(value: object) -> int | None:
    if value is None:
        return None
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, str):
        s = value.strip()
        if not s:
            return None
        try:
            return int(s, 10)
        except ValueError:
            return None
    return None


def _clean_float(value: object) -> float | None:
    if value is None:
        return None
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, str):
        s = value.strip()
        if not s:
            return None
        try:
            return float(s)
        except ValueError:
            return None
    return None


def _pick_numeric_with_source(
    *,
    cli: Mapping[str, object],
    env: Mapping[str, str],
    env_sources: Mapping[str, str] | None,
    file_cfg: Mapping[str, object],
    file_sources: Mapping[str, str] | None,
    defaults: Mapping[str, object],
    key: str,
    env_key: str,
    default_value: NumberT,
    cleaner: Callable[[object], NumberT | None],
    expected: str,
) -> tuple[NumberT, str]:
    for raw_value, source in _iter_candidates(cli=cli,
                                              env=env,
                                              env_sources=env_sources,
                                              file_cfg=file_cfg,
                                              file_sources=file_sources,
                                              defaults=defaults,
                                              key=key,
                                              env_key=env_key,
                                              default_value=default_value):
        if raw_value is None:
            continue
        value = cleaner(raw_value)
        if value is None:
            if isinstance(raw_value, str) and not raw_value.strip():
                continue
            raise _invalid_value_error(key=key,
                                       source=source,
                                       raw_value=raw_value,
                                       expected=expected)
        return value, source
    raise RuntimeError(f"Missing required numeric value for {key}.")


def _iter_candidates(
    *,
    cli: Mapping[str, object],
    env: Mapping[str, str],
    env_sources: Mapping[str, str] | None,
    file_cfg: Mapping[str, object],
    file_sources: Mapping[str, str] | None,
    defaults: Mapping[str, object],
    key: str,
    env_key: str | None = None,
    default_value: object | None = None,
):
    yield cli.get(key), f"--{key.replace('_', '-')}"
    if env_key is not None:
        source = env_key
        if env_sources is not None:
            source = env_sources.get(env_key, env_key)
        yield env.get(env_key), source
    file_source = (file_sources.get(key)
                   if file_sources is not None else None) or f"config:{key}"
    yield file_cfg.get(key), file_source
    yield defaults.get(key), f"defaults:{key}"
    if default_value is not None:
        yield default_value, f"built-in:{key}"


def _invalid_value_error(
    *,
    key: str,
    source: str,
    raw_value: object,
    expected: str,
) -> RuntimeError:
    return RuntimeError(
        f"Invalid value for {key} from {source}: {raw_value!r}. Expected {expected}."
    )


def _pick_string_with_source(
    *,
    cli: Mapping[str, object],
    env: Mapping[str, str],
    env_sources: Mapping[str, str] | None,
    file_cfg: Mapping[str, object],
    file_sources: Mapping[str, str] | None,
    defaults: Mapping[str, object],
    key: str,
    env_key: str | None,
    default_value: object | None,
) -> tuple[str | None, str | None]:
    for raw_value, source in _iter_candidates(cli=cli,
                                              env=env,
                                              env_sources=env_sources,
                                              file_cfg=file_cfg,
                                              file_sources=file_sources,
                                              defaults=defaults,
                                              key=key,
                                              env_key=env_key,
                                              default_value=default_value):
        if raw_value is None:
            continue
        if isinstance(raw_value, Path):
            return str(raw_value), source
        if not isinstance(raw_value, str):
            raise _invalid_value_error(key=key,
                                       source=source,
                                       raw_value=raw_value,
                                       expected="a string")
        value = raw_value.strip()
        if not value:
            continue
        return value, source
    return None, None


def _resolve_gateway_provider_with_source(
    *,
    cli: Mapping[str, object],
    env: Mapping[str, str],
    env_sources: Mapping[str, str] | None,
    file_cfg: Mapping[str, object],
    file_sources: Mapping[str, str] | None,
    defaults: Mapping[str, object],
) -> tuple[str, str]:
    for raw_value, source in _iter_candidates(
            cli=cli,
            env=env,
            env_sources=env_sources,
            file_cfg=file_cfg,
            file_sources=file_sources,
            defaults=defaults,
            key="gateway_provider",
            env_key=None,
            default_value=DEFAULT_GATEWAY_PROVIDER):
        if raw_value is None:
            continue
        if not isinstance(raw_value, str):
            raise _invalid_value_error(key="gateway_provider",
                                       source=source,
                                       raw_value=raw_value,
                                       expected=GATEWAY_PROVIDER_EXPECTED_TEXT)
        value = raw_value.strip()
        if not value:
            continue
        normalized = normalize_gateway_provider(value)
        if normalized is None:
            raise _invalid_value_error(key="gateway_provider",
                                       source=source,
                                       raw_value=raw_value,
                                       expected=GATEWAY_PROVIDER_EXPECTED_TEXT)
        return normalized, source
    raise RuntimeError("Missing required value for gateway_provider.")


def _pick_float_with_source(
    *,
    cli: Mapping[str, object],
    env: Mapping[str, str],
    env_sources: Mapping[str, str] | None,
    file_cfg: Mapping[str, object],
    file_sources: Mapping[str, str] | None,
    defaults: Mapping[str, object],
    key: str,
    env_key: str,
    default_value: float,
) -> tuple[float, str]:
    return _pick_numeric_with_source(
        cli=cli,
        env=env,
        env_sources=env_sources,
        file_cfg=file_cfg,
        file_sources=file_sources,
        defaults=defaults,
        key=key,
        env_key=env_key,
        default_value=default_value,
        cleaner=_clean_float,
        expected="a number",
    )


def _pick_int_with_source(
    *,
    cli: Mapping[str, object],
    env: Mapping[str, str],
    env_sources: Mapping[str, str] | None,
    file_cfg: Mapping[str, object],
    file_sources: Mapping[str, str] | None,
    defaults: Mapping[str, object],
    key: str,
    env_key: str,
    default_value: int,
) -> tuple[int, str]:
    return _pick_numeric_with_source(
        cli=cli,
        env=env,
        env_sources=env_sources,
        file_cfg=file_cfg,
        file_sources=file_sources,
        defaults=defaults,
        key=key,
        env_key=env_key,
        default_value=default_value,
        cleaner=_clean_int,
        expected="an integer",
    )


def _build_resolve_inputs(
    *,
    cli: Mapping[str, object],
    env: Mapping[str, str] | None,
    env_sources: Mapping[str, str] | None,
    file_cfg: Mapping[str, object] | None,
    file_sources: Mapping[str, str] | None,
    defaults: Mapping[str, object] | None,
) -> _ResolveInputs:
    return _ResolveInputs(
        cli=cli,
        env=env if env is not None else os.environ,
        env_sources=env_sources,
        file_cfg=file_cfg if file_cfg is not None else {},
        file_sources=file_sources,
        defaults=defaults if defaults is not None else {},
    )


def _reject_removed_config_keys(
    *,
    file_cfg: Mapping[str, object],
    source: str,
) -> None:
    removed_config_key_hints = _removed_config_key_hints()
    removed_keys = [key for key in removed_config_key_hints if key in file_cfg]
    if not removed_keys:
        return

    details = "\n".join(f"- {key}: {removed_config_key_hints[key]}"
                        for key in removed_keys)
    keys_text = ", ".join(removed_keys)
    raise RuntimeError(f"Unsupported keys in {source}: {keys_text}\n"
                       f"{details}")


def _resolve_config_context(inputs: _ResolveInputs) -> _ResolvedConfigContext:
    default_config = str(default_config_path())
    cli_config_path = _clean_str(inputs.cli.get("config_path"))
    config_path = cli_config_path or default_config
    config_path_source = "--config"
    if cli_config_path is None or cli_config_path == default_config:
        config_path_source = "built-in:config_path"
    _reject_removed_config_keys(file_cfg=inputs.file_cfg, source=config_path)
    return _ResolvedConfigContext(config_path=config_path,
                                  config_path_source=config_path_source,
                                  file_map=inputs.file_cfg)


@dataclass(frozen=True)
class _ResolvedConnectionFields:
    controlplane_base: str
    controlplane_base_source: str | None
    gateway_provider: str
    gateway_provider_source: str
    gateway_base: str
    gateway_base_source: str


def _resolve_connection_fields(
    inputs: _ResolveInputs,
    context: _ResolvedConfigContext,
) -> _ResolvedConnectionFields:
    controlplane_base, controlplane_base_source = _pick_string_with_source(
        cli=inputs.cli,
        env=inputs.env,
        env_sources=inputs.env_sources,
        file_cfg=context.file_map,
        file_sources=inputs.file_sources,
        defaults=inputs.defaults,
        key="controlplane_base",
        env_key=ENV_CONTROL_PLANE_BASE_URL,
        default_value=DEFAULT_CONTROLPLANE_BASE,
    )
    gateway_provider, gateway_provider_source = _resolve_gateway_provider_with_source(
        cli=inputs.cli,
        env=inputs.env,
        env_sources=inputs.env_sources,
        file_cfg=context.file_map,
        file_sources=inputs.file_sources,
        defaults=inputs.defaults,
    )
    return _ResolvedConnectionFields(
        controlplane_base=controlplane_base or DEFAULT_CONTROLPLANE_BASE,
        controlplane_base_source=controlplane_base_source,
        gateway_provider=gateway_provider,
        gateway_provider_source=gateway_provider_source,
        gateway_base=gateway_base_for_provider(gateway_provider),
        gateway_base_source=f"derived-from:{gateway_provider_source}",
    )


def _resolve_credential_fields(
    inputs: _ResolveInputs,
    context: _ResolvedConfigContext,
) -> _ResolvedCredentialFields:
    controlplane_auth_json = str(default_auth_json_path())
    controlplane_auth_json_source = "built-in:controlplane_auth_json"
    gateway_api_key, gateway_api_key_source = _pick_string_with_source(
        cli=inputs.cli,
        env=inputs.env,
        env_sources=inputs.env_sources,
        file_cfg=context.file_map,
        file_sources=inputs.file_sources,
        defaults=inputs.defaults,
        key="gateway_api_key",
        env_key=None,
        default_value=None)
    gateway_user_id, gateway_user_id_source = _pick_string_with_source(
        cli=inputs.cli,
        env=inputs.env,
        env_sources=inputs.env_sources,
        file_cfg=context.file_map,
        file_sources=inputs.file_sources,
        defaults=inputs.defaults,
        key="gateway_user_id",
        env_key=None,
        default_value=None)
    gateway_model_id, gateway_model_id_source = _pick_string_with_source(
        cli=inputs.cli,
        env=inputs.env,
        env_sources=inputs.env_sources,
        file_cfg=context.file_map,
        file_sources=inputs.file_sources,
        defaults=inputs.defaults,
        key="gateway_model_id",
        env_key=None,
        default_value=None)
    ca_bundle, ca_bundle_source = _pick_string_with_source(
        cli=inputs.cli,
        env=inputs.env,
        env_sources=inputs.env_sources,
        file_cfg=context.file_map,
        file_sources=inputs.file_sources,
        defaults=inputs.defaults,
        key="ca_bundle",
        env_key=ENV_CA_BUNDLE,
        default_value=None)
    return _ResolvedCredentialFields(
        controlplane_auth_json=controlplane_auth_json,
        controlplane_auth_json_source=controlplane_auth_json_source,
        gateway_api_key=gateway_api_key,
        gateway_api_key_source=gateway_api_key_source,
        gateway_user_id=gateway_user_id,
        gateway_user_id_source=gateway_user_id_source,
        gateway_model_id=gateway_model_id,
        gateway_model_id_source=gateway_model_id_source,
        ca_bundle=str(Path(ca_bundle).expanduser())
        if _clean_str(ca_bundle) else None,
        ca_bundle_source=ca_bundle_source,
    )


def _resolve_runtime_fields(
    inputs: _ResolveInputs,
    context: _ResolvedConfigContext,
) -> _ResolvedRuntimeFields:
    timeout_seconds, timeout_seconds_source = _pick_float_with_source(
        cli=inputs.cli,
        env=inputs.env,
        env_sources=inputs.env_sources,
        file_cfg=context.file_map,
        file_sources=inputs.file_sources,
        defaults=inputs.defaults,
        key="timeout_seconds",
        env_key=ENV_TIMEOUT_SECONDS,
        default_value=float(DEFAULT_TIMEOUT_SECONDS))
    if timeout_seconds <= 0:
        raise RuntimeError("Timeout must be greater than 0 seconds.")

    max_retries, max_retries_source = _pick_int_with_source(
        cli=inputs.cli,
        env=inputs.env,
        env_sources=inputs.env_sources,
        file_cfg=context.file_map,
        file_sources=inputs.file_sources,
        defaults=inputs.defaults,
        key="max_retries",
        env_key=ENV_MAX_RETRIES,
        default_value=int(DEFAULT_MAX_RETRIES))
    if max_retries < 0:
        raise RuntimeError("Max retries must be greater than or equal to 0.")

    return _ResolvedRuntimeFields(
        timeout_seconds=float(timeout_seconds),
        timeout_seconds_source=timeout_seconds_source,
        max_retries=int(max_retries),
        max_retries_source=max_retries_source)


def resolve_config(
    *,
    cli: Mapping[str, object],
    env: Mapping[str, str] | None = None,
    env_sources: Mapping[str, str] | None = None,
    file_cfg: Mapping[str, object] | None = None,
    file_sources: Mapping[str, str] | None = None,
    defaults: Mapping[str, object] | None = None,
) -> ResolvedConfig:
    inputs = _build_resolve_inputs(cli=cli,
                                   env=env,
                                   env_sources=env_sources,
                                   file_cfg=file_cfg,
                                   file_sources=file_sources,
                                   defaults=defaults)
    context = _resolve_config_context(inputs)
    connection = _resolve_connection_fields(inputs, context)
    credentials = _resolve_credential_fields(inputs, context)
    runtime = _resolve_runtime_fields(inputs, context)

    return ResolvedConfig(
        config_path=str(Path(context.config_path).expanduser()),
        controlplane_base=connection.controlplane_base.rstrip("/"),
        gateway_provider=connection.gateway_provider,
        gateway_base=connection.gateway_base.rstrip("/"),
        controlplane_auth_json=credentials.controlplane_auth_json,
        gateway_api_key=credentials.gateway_api_key,
        gateway_user_id=credentials.gateway_user_id,
        gateway_model_id=credentials.gateway_model_id,
        ca_bundle=credentials.ca_bundle,
        timeout_seconds=runtime.timeout_seconds,
        max_retries=runtime.max_retries,
        sources=ResolvedConfigSources(
            config_path=context.config_path_source,
            controlplane_base=connection.controlplane_base_source
            or "built-in:controlplane_base",
            controlplane_auth_json=credentials.controlplane_auth_json_source
            or "built-in:controlplane_auth_json",
            gateway_provider=connection.gateway_provider_source,
            gateway_base=connection.gateway_base_source,
            gateway_api_key=credentials.gateway_api_key_source,
            gateway_user_id=credentials.gateway_user_id_source,
            gateway_model_id=credentials.gateway_model_id_source,
            ca_bundle=credentials.ca_bundle_source,
            timeout_seconds=runtime.timeout_seconds_source,
            max_retries=runtime.max_retries_source,
        ),
    )
