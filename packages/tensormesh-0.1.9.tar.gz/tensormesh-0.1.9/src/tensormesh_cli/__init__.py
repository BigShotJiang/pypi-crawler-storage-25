from __future__ import annotations

from tensormesh.build_info import __version__

__all__ = ["__version__"]
