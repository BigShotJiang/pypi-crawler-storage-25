from __future__ import annotations

import json
import os
from pathlib import Path
import tempfile
from typing import Any

__all__ = [
    "access_token",
    "load_tokens",
    "save_tokens",
]


def save_tokens(token_path: Path, data: dict[str, Any]) -> None:
    token_path.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(data, indent=2) + "\n"
    # Write atomically via a same-directory temp file, then replace in one step.
    tmp_name: str | None = None
    dir_fd: int | None = None
    try:
        dir_fd = os.open(str(token_path.parent), os.O_RDONLY)
        fd, tmp_name = tempfile.mkstemp(
            prefix=f".{token_path.name}.",
            suffix=".tmp",
            dir=str(token_path.parent),
        )
        os.fchmod(fd, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as file_obj:
            file_obj.write(payload)
            file_obj.flush()
            os.fsync(file_obj.fileno())
        os.replace(tmp_name, str(token_path))
        tmp_name = None
        os.chmod(str(token_path), 0o600)
        os.fsync(dir_fd)
    finally:
        if dir_fd is not None:
            try:
                os.close(dir_fd)
            except OSError:
                pass
        if tmp_name is not None:
            try:
                os.unlink(tmp_name)
            except OSError:
                pass


def load_tokens(token_path: Path) -> dict[str, Any] | None:
    if not token_path.exists():
        return None
    try:
        data = json.loads(token_path.read_text(encoding="utf-8"))
    except OSError as exc:
        raise RuntimeError(
            f"Failed to read token file: {token_path}: {exc}") from exc
    except json.JSONDecodeError as exc:
        raise RuntimeError(
            f"Invalid token file JSON: {token_path}: {exc}") from exc
    if not isinstance(data, dict):
        raise RuntimeError(
            f"Invalid token file JSON: expected a JSON object: {token_path}")
    return data


def access_token(token_path: Path) -> str | None:
    tokens = load_tokens(token_path)
    if tokens is None:
        return None
    token = tokens.get("access_token")
    if not isinstance(token, str) or not token.strip():
        raise RuntimeError(
            f"Invalid token file: missing or invalid 'access_token': {token_path}"
        )
    return token
