from __future__ import annotations

from pathlib import Path
import time
from typing import Any, Callable
import webbrowser

import requests

from .storage import load_tokens
from .storage import save_tokens

__all__ = ["login", "refresh"]

DEFAULT_LOGIN_MAX_WAIT_S = 300.0


def _post_json(
    url: str,
    *,
    json_body: dict[str, Any] | None = None,
    timeout_s: float,
    verify: bool | str,
    error_prefix: str,
) -> requests.Response:
    try:
        return requests.post(url,
                             json=json_body,
                             timeout=timeout_s,
                             verify=verify)
    except requests.RequestException as exc:
        raise RuntimeError(
            f"{error_prefix} (network error). url={url} error={exc}") from exc


def _require_str_field(data: dict[str, Any], *, field: str,
                       error_prefix: str) -> str:
    value = data.get(field)
    if not isinstance(value, str) or not value.strip():
        raise RuntimeError(
            f"{error_prefix}: missing or invalid {field!r} in JSON response.")
    return value


def _response_json(resp: requests.Response, *,
                   error_prefix: str) -> dict[str, Any]:
    try:
        data = resp.json()
    except ValueError as exc:
        raise RuntimeError(
            f"{error_prefix}: invalid JSON response: {resp.text}") from exc
    if not isinstance(data, dict):
        raise RuntimeError(
            f"{error_prefix}: invalid JSON response: {resp.text}")
    return data


def login(
    controlplane_base: str,
    token_path: Path,
    *,
    open_browser: bool = True,
    timeout_s: float = 10,
    max_wait_s: float = DEFAULT_LOGIN_MAX_WAIT_S,
    verify: bool | str = True,
    log: Callable[[str], None] | None = print,
) -> None:
    start_url = f"{controlplane_base}/auth/cli/start"
    start_resp = _post_json(start_url,
                            timeout_s=timeout_s,
                            verify=verify,
                            error_prefix="Login start failed")
    if start_resp.status_code != 200:
        raise RuntimeError(
            f"Login start failed: {start_resp.status_code} {start_resp.text}")

    start_data = _response_json(start_resp, error_prefix="Login start failed")
    auth_url = _require_str_field(start_data,
                                  field="auth_url",
                                  error_prefix="Login start failed")
    cli_code = _require_str_field(start_data,
                                  field="cli_code",
                                  error_prefix="Login start failed")
    interval = float(start_data.get("interval", 2))

    if log is not None:
        log(f"Open browser: {auth_url}")
    if open_browser:
        webbrowser.open(auth_url)

    exchange_url = f"{controlplane_base}/auth/cli/exchange"
    deadline = time.monotonic() + max_wait_s
    try:
        while True:
            if time.monotonic() >= deadline:
                raise RuntimeError(
                    f"Login timed out after {max_wait_s:g} seconds.")
            exchange_resp = _post_json(exchange_url,
                                       json_body={"cli_code": cli_code},
                                       timeout_s=timeout_s,
                                       verify=verify,
                                       error_prefix="Login exchange failed")

            if exchange_resp.status_code == 200:
                tokens = _response_json(exchange_resp,
                                        error_prefix="Login exchange failed")
                save_tokens(token_path, tokens)
                if log is not None:
                    log(f"Login success. Tokens saved to {token_path}")
                return

            if exchange_resp.status_code == 202:
                remaining_s = deadline - time.monotonic()
                if remaining_s <= 0:
                    raise RuntimeError(
                        f"Login timed out after {max_wait_s:g} seconds.")
                time.sleep(min(interval, remaining_s))
                continue

            raise RuntimeError(
                f"Login failed: {exchange_resp.status_code} {exchange_resp.text}"
            )
    except KeyboardInterrupt as exc:
        raise RuntimeError("Login cancelled.") from exc


def refresh(controlplane_base: str,
            token_path: Path,
            *,
            timeout_s: float = 10,
            verify: bool | str = True) -> None:
    tokens = load_tokens(token_path)
    if not tokens or "refresh_token" not in tokens:
        raise RuntimeError("No refresh token found. Please login first.")

    refresh_url = f"{controlplane_base}/auth/cli/refresh"
    refresh_resp = _post_json(
        refresh_url,
        json_body={"refresh_token": tokens["refresh_token"]},
        timeout_s=timeout_s,
        verify=verify,
        error_prefix="Refresh failed",
    )
    if refresh_resp.status_code != 200:
        raise RuntimeError(
            f"Refresh failed: {refresh_resp.status_code} {refresh_resp.text}")

    tokens = _response_json(refresh_resp, error_prefix="Refresh failed")
    save_tokens(token_path, tokens)
