from __future__ import annotations

from pathlib import Path
import re
import shlex
from typing import Any

from tests.cli_test_utils import controlplane_env
from tests.cli_test_utils import gateway_env
from tests.cli_test_utils import invoke_tm
from tests.cli_test_utils import patch_controlplane_base
from tests.cli_test_utils import patch_gateway_provider_base
from tests.http_test_utils import assert_last_request
from tests.http_test_utils import json_response
from tests.http_test_utils import RequestRecorder
from tests.http_test_utils import serve_controlplane_routes
from tests.http_test_utils import serve_http_server
from tests.infer_chat_test_utils import make_chat_completion_handler
from tests.response_test_utils import AsyncJSONResponse
from tests.response_test_utils import AsyncLineStreamResponse
from tests.response_test_utils import JSONResponse

REPO_ROOT = Path(__file__).resolve().parents[1]


def _python_blocks(text: str) -> list[str]:
    return re.findall(r"```python\n(.*?)```", text, flags=re.DOTALL)


def _shell_blocks(text: str) -> list[str]:
    return re.findall(r"```sh\n(.*?)```", text, flags=re.DOTALL)


def _normalize_shell_block(block: str) -> list[str]:
    lines: list[str] = []
    current = ""
    for raw_line in block.splitlines():
        line = raw_line.rstrip()
        if not line.strip():
            if current:
                lines.append(current.strip())
                current = ""
            continue
        if line.endswith("\\"):
            current += line[:-1].rstrip() + " "
            continue
        current += line.strip()
        lines.append(current.strip())
        current = ""
    if current:
        lines.append(current.strip())
    return lines


def _python_block_containing(path: Path, needle: str) -> str:
    text = path.read_text(encoding="utf-8")
    for block in _python_blocks(text):
        if needle in block:
            return block
    raise AssertionError(
        f"{path.name}: expected Python block containing {needle!r}")


def _tm_command_containing(path: Path, needle: str) -> list[str]:
    text = path.read_text(encoding="utf-8")
    for block in _shell_blocks(text):
        for line in _normalize_shell_block(block):
            if line.startswith("tm ") and needle in line:
                return shlex.split(line)
    raise AssertionError(
        f"{path.name}: expected tm command containing {needle!r}")


def _exec_python_snippet(snippet: str) -> dict[str, Any]:
    namespace = {"__name__": "__main__"}
    exec(snippet, namespace)
    return namespace


def _cp_models_routes(payload: dict[str, Any]) -> dict[tuple[str, str], Any]:
    return {
        ("GET", "/v1/models"): json_response(payload),
    }


def _install_sync_example_transport(monkeypatch: Any) -> None:
    import tensormesh._transport as transport

    def fake_request(method: str, url: str, **kwargs: Any) -> JSONResponse:
        if url.endswith("/v1/chat/completions"):
            if kwargs.get("stream") is True:
                return JSONResponse(
                    status_code=200,
                    headers={"Content-Type": "text/event-stream"},
                    lines=[
                        'data: {"id":"chunk_1","object":"chat.completion.chunk","created":1,"model":"MODEL_ID","choices":[{"index":0,"delta":{"content":"hel"}}]}',
                        'data: {"id":"chunk_1","object":"chat.completion.chunk","created":1,"model":"MODEL_ID","choices":[{"index":0,"delta":{"content":"lo"},"finish_reason":"stop"}]}',
                        "data: [DONE]",
                    ],
                )
            return JSONResponse(
                status_code=200,
                payload={
                    "id":
                    "cmpl_123",
                    "object":
                    "chat.completion",
                    "created":
                    1,
                    "model":
                    "MODEL_ID",
                    "choices": [{
                        "index": 0,
                        "message": {
                            "role": "assistant",
                            "content": "hello",
                        },
                        "finish_reason": "stop",
                    }],
                },
            )
        if url.endswith("/auth/profile"):
            return JSONResponse(payload={
                "user": {
                    "id": "user-1",
                    "displayName": "Demo User",
                }
            })
        if url.endswith("/v1/users/api-keys"):
            return JSONResponse(payload={"apiKeys": [{"name": "default"}]})
        if url.endswith("/v1/models"):
            return JSONResponse(payload={
                "models": [{
                    "modelId": "model-1",
                    "modelName": "Demo Model",
                }]
            })
        raise AssertionError(f"Unhandled sync example request: {method} {url}")

    monkeypatch.setattr(transport.requests, "request", fake_request)


def _install_async_example_transport(
        monkeypatch: Any) -> AsyncLineStreamResponse:
    import tensormesh._async_transport as async_transport

    stream_response = AsyncLineStreamResponse(lines=[
        'data: {"choices":[{"delta":{"content":"hel"}}]}',
        'data: {"choices":[{"delta":{"content":"lo"}}]}',
        "data: [DONE]",
    ])

    async def fake_request(
        self: Any,
        method: str,
        url: str,
        **kwargs: Any,
    ) -> AsyncJSONResponse:
        del self, kwargs
        if url.endswith("/v1/chat/completions"):
            return AsyncJSONResponse(
                payload={
                    "id":
                    "cmpl_async",
                    "object":
                    "chat.completion",
                    "created":
                    1,
                    "model":
                    "MODEL_ID",
                    "choices": [{
                        "index": 0,
                        "message": {
                            "role": "assistant",
                            "content": "hello",
                        },
                        "finish_reason": "stop",
                    }],
                })
        if url.endswith("/v1/support/tickets"):
            return AsyncJSONResponse(
                payload={
                    "tickets": [{
                        "ticketId": "ticket-1",
                        "subject": "Need help",
                    }],
                    "page": 1,
                    "size": 20,
                    "total": "1",
                })
        raise AssertionError(
            f"Unhandled async example request: {method} {url}")

    async def fake_request_stream(
        self: Any,
        method: str,
        url: str,
        **kwargs: Any,
    ) -> AsyncLineStreamResponse:
        del self, method, kwargs
        if url.endswith("/v1/chat/completions"):
            return stream_response
        raise AssertionError(f"Unhandled async example stream request: {url}")

    monkeypatch.setattr(async_transport.AsyncTransport, "request",
                        fake_request)
    monkeypatch.setattr(async_transport.AsyncTransport, "request_stream",
                        fake_request_stream)
    return stream_response


def test_readme_python_sdk_quick_start_executes(monkeypatch: Any) -> None:
    _install_sync_example_transport(monkeypatch)

    snippet = _python_block_containing(
        REPO_ROOT / "README.md",
        "profile = client.control_plane.users.get_auth_profile()")
    namespace = _exec_python_snippet(snippet)

    completion = namespace["completion"]
    profile = namespace["profile"]
    models = namespace["models"]
    assert completion.choices[0].message.content == "hello"
    assert profile.display_name == "Demo User"
    assert models[0].model_id == "model-1"


def test_sdk_getting_started_async_example_executes(
    monkeypatch: Any,
    capsys: Any,
) -> None:
    _install_async_example_transport(monkeypatch)

    snippet = _python_block_containing(
        REPO_ROOT / "docs" / "sdk" / "guides" / "getting-started.mdx",
        "async with AsyncTensormesh",
    )
    _exec_python_snippet(snippet)

    assert capsys.readouterr().out == "hello\n"


def test_sdk_sync_examples_use_context_managers() -> None:
    readme = (REPO_ROOT / "README.md").read_text(encoding="utf-8")
    getting_started = (REPO_ROOT / "docs" / "sdk" / "guides" /
                       "getting-started.mdx").read_text(encoding="utf-8")
    inference = (REPO_ROOT / "docs" / "sdk" / "guides" /
                 "inference.mdx").read_text(encoding="utf-8")

    assert "with Tensormesh(inference_api_key=" in readme
    assert "with Tensormesh(" in getting_started
    assert "with Tensormesh(" in inference
    assert "client = Tensormesh(" not in readme
    assert "client = Tensormesh(" not in getting_started
    assert "client = Tensormesh(" not in inference


def test_sdk_getting_started_sync_example_executes(
    monkeypatch: Any,
    capsys: Any,
) -> None:
    _install_sync_example_transport(monkeypatch)

    snippet = _python_block_containing(
        REPO_ROOT / "docs" / "sdk" / "guides" / "getting-started.mdx",
        "with Tensormesh(",
    )
    _exec_python_snippet(snippet)

    assert capsys.readouterr().out == "hello\n"


def test_sdk_auth_and_config_constructor_example_executes() -> None:
    snippet = _python_block_containing(
        REPO_ROOT / "docs" / "sdk" / "guides" / "auth-and-config.mdx",
        'control_plane_token="YOUR_CONTROL_PLANE_TOKEN"',
    )
    namespace = _exec_python_snippet(snippet)

    client = namespace["client"]
    assert client.config.control_plane_token == "YOUR_CONTROL_PLANE_TOKEN"
    assert client.config.inference_api_key == "YOUR_INFERENCE_API_KEY"
    assert client.config.on_demand_base_url == "https://YOUR_ON_DEMAND_BASE_URL"
    assert client.config.on_demand_user_id == (
        "00000000-0000-0000-0000-000000000000")


def test_sdk_inference_streaming_example_executes(
    monkeypatch: Any,
    capsys: Any,
) -> None:
    _install_sync_example_transport(monkeypatch)

    snippet = _python_block_containing(
        REPO_ROOT / "docs" / "sdk" / "guides" / "inference.mdx",
        "for text in stream.text_deltas()",
    )
    _exec_python_snippet(snippet)

    assert capsys.readouterr().out == "hello"


def test_sdk_inference_structured_output_example_executes(
    monkeypatch: Any,
    capsys: Any,
) -> None:
    _install_sync_example_transport(monkeypatch)

    snippet = _python_block_containing(
        REPO_ROOT / "docs" / "sdk" / "guides" / "inference.mdx",
        'ResponseFormat(type="json_object")',
    )
    _exec_python_snippet(snippet)

    assert capsys.readouterr().out == "hello\n"


def test_sdk_migration_guide_serverless_example_executes(
    monkeypatch: Any,
    capsys: Any,
) -> None:
    _install_sync_example_transport(monkeypatch)

    snippet = _python_block_containing(
        REPO_ROOT / "docs" / "sdk" / "guides" /
        "migration-from-openai-fireworks.mdx",
        "serverless_model_name",
    )
    _exec_python_snippet(snippet)

    assert capsys.readouterr().out == "hello\n"


def test_sdk_migration_guide_on_demand_example_executes(
    monkeypatch: Any,
    capsys: Any,
) -> None:
    _install_sync_example_transport(monkeypatch)

    snippet = _python_block_containing(
        REPO_ROOT / "docs" / "sdk" / "guides" /
        "migration-from-openai-fireworks.mdx",
        "served_gateway_model_name",
    )
    _exec_python_snippet(snippet)

    assert capsys.readouterr().out == "hello\n"


def test_sdk_inference_async_streaming_response_example_executes(
    monkeypatch: Any,
    capsys: Any,
) -> None:
    stream_response = _install_async_example_transport(monkeypatch)

    snippet = _python_block_containing(
        REPO_ROOT / "docs" / "sdk" / "guides" / "inference.mdx",
        "raw_stream = await client.inference.serverless.chat.completions.with_streaming_response.create",
    )
    _exec_python_snippet(snippet)

    assert capsys.readouterr().out == (
        "data: {\"choices\":[{\"delta\":{\"content\":\"hel\"}}]}\n"
        "data: {\"choices\":[{\"delta\":{\"content\":\"lo\"}}]}\n"
        "data: [DONE]\n")
    assert stream_response.closed is True


def test_sdk_control_plane_example_executes(
    monkeypatch: Any,
    capsys: Any,
) -> None:
    _install_sync_example_transport(monkeypatch)

    snippet = _python_block_containing(
        REPO_ROOT / "docs" / "sdk" / "guides" / "control-plane.mdx",
        "api_keys = client.control_plane.users.api_keys.list()",
    )
    _exec_python_snippet(snippet)

    assert capsys.readouterr().out == "Demo User\n['default']\n"


def test_sdk_control_plane_async_example_executes(
    monkeypatch: Any,
    capsys: Any,
) -> None:
    _install_async_example_transport(monkeypatch)

    snippet = _python_block_containing(
        REPO_ROOT / "docs" / "sdk" / "guides" / "control-plane.mdx",
        "tickets = await client.control_plane.support.tickets.list(size=20)",
    )
    _exec_python_snippet(snippet)

    assert capsys.readouterr().out == "['Need help']\n"


def test_cli_getting_started_infer_doctor_example_executes() -> None:
    command = _tm_command_containing(
        REPO_ROOT / "docs" / "cli" / "guides" / "getting-started.mdx",
        "infer doctor",
    )
    result = invoke_tm(command[1:], env=gateway_env())

    assert result.exit_code == 0, result.output
    assert "tm infer doctor" in result.output
    assert "Next steps:" in result.output
    assert "tm infer chat --json" in result.output


def test_cli_getting_started_auth_login_example_executes(
    monkeypatch: Any,
    tmp_path: Path,
) -> None:
    command = _tm_command_containing(
        REPO_ROOT / "docs" / "cli" / "guides" / "getting-started.mdx",
        "auth login",
    )

    captured: dict[str, Any] = {}

    def fake_login(base: str, token_path: Path, *, open_browser: bool,
                   timeout_s: float, max_wait_s: float, verify: bool | str,
                   log: Any) -> None:
        captured.update({
            "base": base,
            "token_path": token_path,
            "open_browser": open_browser,
            "timeout_s": timeout_s,
            "max_wait_s": max_wait_s,
            "verify": verify,
            "log_type": type(log).__name__,
        })

    import tensormesh_cli.commands.auth_cmd as auth_cmd

    monkeypatch.setattr(auth_cmd.auth, "login", fake_login)

    with patch_controlplane_base("https://control.example"):
        result = invoke_tm(command[1:], env=controlplane_env(home=tmp_path))

    assert result.exit_code == 0, result.output
    assert captured["base"] == "https://control.example"
    assert captured["token_path"].name == "auth.json"
    assert captured["open_browser"] is True
    assert captured["timeout_s"] == 30.0
    assert captured["max_wait_s"] == 300.0
    assert captured["verify"] is True
    assert captured["log_type"] == "function"


def test_cli_first_request_example_executes(monkeypatch: Any) -> None:
    command = _tm_command_containing(
        REPO_ROOT / "docs" / "cli" / "guides" / "first-request.mdx",
        "infer chat --json",
    )

    with serve_http_server(
            make_chat_completion_handler(
                expected_auth="Bearer gw_key")) as base:
        patch_gateway_provider_base(monkeypatch, base=base)
        result = invoke_tm(command[1:], env=gateway_env())

    assert result.exit_code == 0, result.output
    assert result.output == "ok\n"


def test_cli_first_request_latest_example_executes(monkeypatch: Any) -> None:
    command = _tm_command_containing(
        REPO_ROOT / "docs" / "cli" / "guides" / "first-request.mdx",
        "infer chat --model @latest",
    )

    recorder = RequestRecorder()
    payload = {
        "models": [
            {
                "modelId": "m_old",
                "modelName": "gw_old",
                "deploymentId": "dep_old",
                "status": "MODEL_STATUS_UP",
                "updatedAt": "2024-01-01T00:00:00Z",
            },
            {
                "modelId": "m_new",
                "modelName": "gw_new",
                "deploymentId": "dep_new",
                "status": "MODEL_STATUS_UP",
                "updatedAt": "2024-02-01T00:00:00Z",
            },
        ]
    }

    with serve_controlplane_routes(
            _cp_models_routes(payload),
            expected_auth="Bearer cp_tok",
    ), serve_http_server(
            make_chat_completion_handler(
                recorder=recorder,
                expected_auth="Bearer gw_key",
            )) as gw_base:
        patch_gateway_provider_base(monkeypatch, base=gw_base)
        result = invoke_tm(
            command[1:],
            env={
                **controlplane_env(access_token="cp_tok"),
                **gateway_env(api_key="gw_key", model_id="unused"),
            },
        )

    assert result.exit_code == 0, result.output
    request = assert_last_request(recorder, path="/v1/chat/completions")
    assert isinstance(request.body, dict)
    assert request.body["model"] == "gw_new"
