from __future__ import annotations

import json
from typing import Any

import pytest

from tests.cli_test_utils import gateway_env
from tests.cli_test_utils import invoke_tm
from tests.http_test_utils import assert_last_request
from tests.http_test_utils import bytes_response
from tests.http_test_utils import json_response
from tests.http_test_utils import make_http_handler
from tests.http_test_utils import RequestRecorder
from tests.http_test_utils import serve_http_server


@pytest.mark.parametrize(
    ("command", "path", "response_payload"),
    [
        ("models", "/v1/models", {
            "object": "list",
            "data": [],
        }),
        ("health", "/health", {
            "status": "healthy"
        }),
        ("version", "/version", {
            "version": "0.0.0"
        }),
    ],
)
def test_infer_on_demand_get_commands_require_routed_headers(
    command: str,
    path: str,
    response_payload: dict[str, Any],
) -> None:
    recorder = RequestRecorder()
    routes = {
        ("GET", path): json_response(response_payload),
    }

    with serve_http_server(make_http_handler(routes=routes,
                                             recorder=recorder)) as base:
        result = invoke_tm([
            "infer",
            command,
            "--surface",
            "on-demand",
            "--api-key",
            "test_key",
            "--user-id",
            "00000000-0000-0000-0000-000000000000",
            "--base-url",
            base,
        ])

    assert result.exit_code == 0, result.output
    assert_last_request(
        recorder,
        method="GET",
        path=path,
        headers={
            "Authorization": "Bearer test_key",
            "X-User-Id": "00000000-0000-0000-0000-000000000000",
        },
    )


@pytest.mark.parametrize(
    ("command", "path", "body"),
    [
        ("completions", "/v1/completions", {
            "model": "served-model",
            "prompt": "Say ok.",
        }),
        ("responses", "/v1/responses", {
            "model": "served-model",
            "input": "Say hello.",
        }),
        ("tokenize", "/tokenize", {
            "model": "served-model",
            "messages": [{
                "role": "user",
                "content": "Hello",
            }],
        }),
        ("detokenize", "/detokenize", {
            "model": "served-model",
            "tokens": [15496, 0],
        }),
    ],
)
def test_infer_on_demand_post_commands_require_routed_headers(
    command: str,
    path: str,
    body: dict[str, Any],
) -> None:
    recorder = RequestRecorder()
    routes = {
        ("POST", path): json_response({"ok": True}),
    }

    with serve_http_server(make_http_handler(routes=routes,
                                             recorder=recorder)) as base:
        result = invoke_tm([
            "--output",
            "json",
            "infer",
            command,
            "--surface",
            "on-demand",
            "--api-key",
            "test_key",
            "--user-id",
            "00000000-0000-0000-0000-000000000000",
            "--base-url",
            base,
            "--json",
            json.dumps(body),
        ])

    assert result.exit_code == 0, result.output
    assert_last_request(
        recorder,
        method="POST",
        path=path,
        body=body,
        headers={
            "Authorization": "Bearer test_key",
            "Content-Type": "application/json",
            "X-User-Id": "00000000-0000-0000-0000-000000000000",
        },
    )


def test_infer_on_demand_responses_stream_requires_routed_headers_and_prints_text(
) -> None:
    recorder = RequestRecorder()
    routes = {
        ("POST", "/v1/responses"):
        bytes_response(
            (b'data: {"output":[{"type":"message","content":[{"type":"output_text","text":"po"}]}]}\n\n'
             b'data: {"output":[{"type":"message","content":[{"type":"output_text","text":"ng"}]}]}\n\n'
             b"data: [DONE]\n\n"),
            headers={"Content-Type": "text/event-stream"},
        ),
    }

    with serve_http_server(make_http_handler(routes=routes,
                                             recorder=recorder)) as base:
        result = invoke_tm([
            "infer",
            "responses",
            "--surface",
            "on-demand",
            "--stream",
            "--api-key",
            "test_key",
            "--user-id",
            "00000000-0000-0000-0000-000000000000",
            "--base-url",
            base,
            "--json",
            json.dumps({
                "model": "served-model",
                "input": "Say pong.",
            }),
        ])

    assert result.exit_code == 0, result.output
    assert result.output == "pong\n"
    assert_last_request(
        recorder,
        method="POST",
        path="/v1/responses",
        body={
            "model": "served-model",
            "input": "Say pong.",
            "stream": True,
        },
        headers={
            "Authorization": "Bearer test_key",
            "Content-Type": "application/json",
            "Accept": "text/event-stream",
            "X-User-Id": "00000000-0000-0000-0000-000000000000",
        },
    )


@pytest.mark.parametrize(
    ("command", "path", "body"),
    [
        ("completions", "/v1/completions", {
            "model": "explicit-served-model",
            "prompt": "Say ok.",
        }),
        ("responses", "/v1/responses", {
            "model": "explicit-served-model",
            "input": "Say hello.",
        }),
        ("tokenize", "/tokenize", {
            "model": "explicit-served-model",
            "prompt": "Hello",
        }),
        ("detokenize", "/detokenize", {
            "model": "explicit-served-model",
            "tokens": [15496, 0],
        }),
    ],
)
def test_infer_on_demand_post_commands_preserve_explicit_json_model_without_cli_override(
    command: str,
    path: str,
    body: dict[str, Any],
) -> None:
    recorder = RequestRecorder()
    routes = {
        ("POST", path): json_response({"ok": True}),
    }

    with serve_http_server(make_http_handler(routes=routes,
                                             recorder=recorder)) as base:
        result = invoke_tm(
            [
                "--output",
                "json",
                "infer",
                command,
                "--surface",
                "on-demand",
                "--api-key",
                "test_key",
                "--user-id",
                "00000000-0000-0000-0000-000000000000",
                "--base-url",
                base,
                "--json",
                json.dumps(body),
            ],
            env=gateway_env(
                api_key="managed_key",
                user_id="00000000-0000-0000-0000-000000000000",
                model_id="managed-served-model",
            ),
        )

    assert result.exit_code == 0, result.output
    assert_last_request(
        recorder,
        method="POST",
        path=path,
        body=body,
        headers={
            "Authorization": "Bearer test_key",
            "Content-Type": "application/json",
            "X-User-Id": "00000000-0000-0000-0000-000000000000",
        },
    )
