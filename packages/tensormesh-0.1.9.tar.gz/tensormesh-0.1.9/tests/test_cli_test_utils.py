from __future__ import annotations

from pathlib import Path

from tests.cli_test_utils import controlplane_auth_json_path
from tests.cli_test_utils import controlplane_env
from tests.cli_test_utils import invoke_tm
from tests.cli_test_utils import write_runtime_home


def test_invoke_tm_default_home_does_not_clobber_existing_runtime() -> None:
    home = Path(
        write_runtime_home(
            gateway_provider="nebius",
            gateway_api_key="gw_key",
            gateway_user_id="00000000-0000-0000-0000-000000000000",
            gateway_model_id="test_model",
        ))
    config_path = home / ".config" / "tensormesh" / "config.toml"

    result = invoke_tm(["version"])

    assert result.exit_code == 0, result.output
    runtime_contents = config_path.read_text(encoding="utf-8")
    assert 'gateway_api_key = "gw_key"' in runtime_contents
    assert 'gateway_model_id = "test_model"' in runtime_contents


def test_controlplane_env_seed_file_false_without_path_keeps_auth_missing(
) -> None:
    env = controlplane_env(seed_file=False)
    auth_path = controlplane_auth_json_path(env["HOME"])

    assert not auth_path.exists()
