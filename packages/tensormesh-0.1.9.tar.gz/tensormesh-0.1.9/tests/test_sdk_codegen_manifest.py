from __future__ import annotations

from pathlib import Path

from tests.script_test_utils import load_script_module

REPO_ROOT = Path(__file__).resolve().parents[1]
SCRIPT_PATH = REPO_ROOT / "scripts" / "validate-sdk-codegen-manifest.py"


def test_sdk_codegen_manifest_matches_current_spec_inventory() -> None:
    mod = load_script_module(SCRIPT_PATH)
    errors = mod.validate_manifest(REPO_ROOT)
    assert errors == []


def test_sdk_codegen_manifest_documents_path_bearing_specs_as_non_schema_only(
) -> None:
    mod = load_script_module(SCRIPT_PATH)
    manifest = mod._load_json(REPO_ROOT / "openapi" / "tensormesh" /
                              "sdk-codegen-manifest.json")

    assert manifest["specs"]["model/v1/model_service.swagger.json"][
        "category"] == "semi_generated"
    assert manifest["specs"]["billing/v1/stripe_service.swagger.json"][
        "category"] == "semi_generated"
    assert manifest["specs"]["billing/v1/stripe_service.swagger.json"][
        "public_namespace"] == "client.control_plane.billing.stripe"
    assert manifest["specs"]["autoscaler/v1/autoscaler.swagger.json"][
        "category"] == "schema_only"
    assert manifest["specs"]["inference/common"]["category"] == "hand_shaped"


def test_sdk_codegen_manifest_points_to_raw_normalized_control_plane_specs(
) -> None:
    mod = load_script_module(SCRIPT_PATH)
    manifest = mod._load_json(REPO_ROOT / "openapi" / "tensormesh" /
                              "sdk-codegen-manifest.json")

    assert manifest["generated_from"]["control_plane_normalized_output"] == (
        "openapi/.generated/tensormesh-api/specs/**/*.openapi.json")
