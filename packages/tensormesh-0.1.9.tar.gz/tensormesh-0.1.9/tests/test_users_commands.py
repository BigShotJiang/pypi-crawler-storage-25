from __future__ import annotations

from tests.cli_test_utils import controlplane_env
from tests.cli_test_utils import invoke_tm
from tests.http_test_utils import assert_last_request
from tests.http_test_utils import json_response
from tests.http_test_utils import serve_controlplane_routes


def test_users_group_help_omits_removed_lookup_commands() -> None:
    result = invoke_tm(["users", "--help"], env=controlplane_env())

    assert result.exit_code == 0, result.output
    assert "get-by-email" not in result.output
    assert "users get " not in result.output


def test_users_update_puts_requested_fields() -> None:
    with serve_controlplane_routes({
        ("PUT", "/v1/users/u1"):
            json_response({"empty": {}}),
    }) as recorder:
        result = invoke_tm(
            [
                "--output", "json", "users", "update", "u1", "--display-name",
                "d"
            ],
            env=controlplane_env(),
        )
    assert result.exit_code == 0, result.output
    assert_last_request(
        recorder,
        method="PUT",
        path="/v1/users/u1",
    )
