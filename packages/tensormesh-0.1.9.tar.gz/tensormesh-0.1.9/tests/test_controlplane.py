from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

import click
import pytest

from tensormesh.types import User
from tensormesh_cli.app_context import build_app_context
from tensormesh_cli.config.model import ResolvedConfig
from tensormesh_cli.config.model import ResolvedConfigSources


def _controlplane_test_ctx(
    tmp_path: Path,
    *,
    controlplane_base: str = "https://control.example/",
    controlplane_auth_json: str | None = None,
) -> click.Context:
    auth_json = controlplane_auth_json
    if auth_json is None:
        auth_json = str(tmp_path / "auth.json")
    cfg = ResolvedConfig(
        config_path=str(tmp_path / "config.toml"),
        controlplane_base=controlplane_base,
        controlplane_auth_json=auth_json,
        gateway_provider="nebius",
        gateway_base="https://gateway.example",
        gateway_api_key=None,
        gateway_user_id=None,
        gateway_model_id=None,
        ca_bundle=None,
        timeout_seconds=9.0,
        max_retries=2,
        sources=ResolvedConfigSources(
            config_path="--config",
            controlplane_base="defaults:controlplane_base",
            controlplane_auth_json="defaults:controlplane_auth_json",
            gateway_provider="defaults:gateway_provider",
            gateway_base="derived-from:defaults:gateway_provider",
            gateway_api_key=None,
            gateway_user_id=None,
            gateway_model_id=None,
            ca_bundle=None,
            timeout_seconds="defaults:timeout_seconds",
            max_retries="defaults:max_retries",
        ),
    )
    app = build_app_context(
        env={},
        resolved_config=cfg,
        output="json",
        quiet=False,
        debug=False,
    )
    return click.Context(click.Command("controlplane-test"), obj=app)


def test_controlplane_token_helpers_cover_missing_and_invalid_sources(
        tmp_path: Path) -> None:
    import tensormesh_cli.controlplane as cp

    blank_ctx = _controlplane_test_ctx(tmp_path, controlplane_auth_json="   ")
    assert cp.has_controlplane_access_token(blank_ctx) is False

    invalid_ctx = _controlplane_test_ctx(tmp_path)
    with patch("tensormesh_cli.controlplane.auth.access_token",
               side_effect=RuntimeError("bad auth file")):
        assert cp.has_controlplane_access_token(invalid_ctx) is False
        with pytest.raises(click.ClickException, match="bad auth file"):
            cp.resolve_controlplane_access_token(invalid_ctx)

    with patch("tensormesh_cli.controlplane.auth.access_token",
               return_value="   "):
        with pytest.raises(click.UsageError,
                           match="No control plane access token found"):
            cp.resolve_controlplane_access_token(invalid_ctx)


def test_execute_controlplane_sdk_propagates_click_failures(
        tmp_path: Path) -> None:
    import tensormesh_cli.controlplane as cp

    ctx = _controlplane_test_ctx(tmp_path)
    with patch("tensormesh_cli.controlplane.build_controlplane_sdk_client",
               side_effect=click.UsageError("bad verify config", ctx=ctx)):
        with pytest.raises(click.UsageError, match="bad verify config"):
            cp.execute_controlplane_sdk(ctx, lambda client: client)

    class _Boom(click.ClickException):
        pass

    class _FakeTransport:
        last_buffered_response = None

    with patch(
            "tensormesh_cli.controlplane.build_controlplane_sdk_client",
            return_value=(object(), _FakeTransport()),
    ):
        with pytest.raises(_Boom, match="boom"):
            cp.execute_controlplane_sdk(
                ctx,
                lambda client: (_ for _ in ()).throw(_Boom("boom")),
            )


def test_resolve_gateway_user_id_from_controlplane_uses_profile_response(
        tmp_path: Path) -> None:
    import tensormesh_cli.controlplane as cp

    ctx = _controlplane_test_ctx(tmp_path)

    with patch("tensormesh_cli.controlplane.execute_controlplane_sdk",
               return_value=(User(id="60b01a41-c8a4-4234-80a5-ef18309b560c"),
                             None)):
        assert cp.resolve_gateway_user_id_from_controlplane(
            ctx) == "60b01a41-c8a4-4234-80a5-ef18309b560c"


def test_resolve_gateway_user_id_from_controlplane_rejects_invalid_profile_payload(
        tmp_path: Path) -> None:
    import tensormesh_cli.controlplane as cp

    ctx = _controlplane_test_ctx(tmp_path)

    with patch("tensormesh_cli.controlplane.execute_controlplane_sdk",
               return_value=(None, None)):
        with pytest.raises(click.ClickException, match="Missing user profile"):
            cp.resolve_gateway_user_id_from_controlplane(ctx)

    with patch("tensormesh_cli.controlplane.execute_controlplane_sdk",
               return_value=(User(id="not-a-uuid"), None)):
        with pytest.raises(click.ClickException,
                           match="Invalid gateway user id"):
            cp.resolve_gateway_user_id_from_controlplane(ctx)
