from __future__ import annotations

from tests.cli_test_utils import controlplane_env
from tests.cli_test_utils import invoke_tm
from tests.http_test_utils import assert_last_request
from tests.http_test_utils import json_response
from tests.http_test_utils import serve_controlplane_routes


def _support_routes():
    return {
        ("POST", "/v1/support/tickets"):
        json_response({"ticket": {
            "id": "t1"
        }}),
        ("POST", "/v1/support/tickets/t1/messages"):
        json_response({"ticket": {
            "id": "t1"
        }}),
        ("DELETE", "/v1/support/tickets/t1"):
        json_response({"ticket": {
            "id": "t1"
        }}),
        ("POST", "/v1/support/reserved-deployments"):
        json_response({"ok": True}),
    }


def test_tickets_create_posts_request_body() -> None:
    with serve_controlplane_routes(_support_routes()) as recorder:
        result = invoke_tm(
            [
                "--output",
                "json",
                "tickets",
                "create",
                "--subject",
                "s",
                "--message",
                "m",
            ],
            env=controlplane_env(),
        )

    assert result.exit_code == 0, result.output
    assert_last_request(
        recorder,
        method="POST",
        path="/v1/support/tickets",
        body={
            "subject": "s",
            "message": "m",
        },
    )


def test_tickets_message_posts_request_body() -> None:
    with serve_controlplane_routes(_support_routes()) as recorder:
        result = invoke_tm(
            [
                "--output",
                "json",
                "tickets",
                "message",
                "t1",
                "--message",
                "hello",
            ],
            env=controlplane_env(),
        )

    assert result.exit_code == 0, result.output
    assert_last_request(
        recorder,
        method="POST",
        path="/v1/support/tickets/t1/messages",
        body={"message": {
            "content": "hello"
        }},
    )


def test_tickets_message_json_overrides_flags() -> None:
    with serve_controlplane_routes(_support_routes()) as recorder:
        result = invoke_tm(
            [
                "--output",
                "json",
                "tickets",
                "message",
                "t1",
                "--message",
                "flag-message",
                "--user-id",
                "flag-user",
                "--json",
                '{"message":"json-message","userId":"json-user"}',
            ],
            env=controlplane_env(),
        )

    assert result.exit_code == 0, result.output
    assert_last_request(
        recorder,
        method="POST",
        path="/v1/support/tickets/t1/messages",
        body={
            "message": {
                "content": "json-message",
            },
            "userId": "json-user",
        },
    )


def test_tickets_message_accepts_nested_message_json() -> None:
    with serve_controlplane_routes(_support_routes()) as recorder:
        result = invoke_tm(
            [
                "--output",
                "json",
                "tickets",
                "message",
                "t1",
                "--json",
                '{"message":{"content":"json-message"},"userId":"json-user"}',
            ],
            env=controlplane_env(),
        )

    assert result.exit_code == 0, result.output
    assert_last_request(
        recorder,
        method="POST",
        path="/v1/support/tickets/t1/messages",
        body={
            "message": {
                "content": "json-message",
            },
            "userId": "json-user",
        },
    )


def test_tickets_message_nested_json_overrides_flags() -> None:
    with serve_controlplane_routes(_support_routes()) as recorder:
        result = invoke_tm(
            [
                "--output",
                "json",
                "tickets",
                "message",
                "t1",
                "--message",
                "flag-message",
                "--user-id",
                "flag-user",
                "--json",
                '{"message":{"content":"json-message"},"userId":"json-user"}',
            ],
            env=controlplane_env(),
        )

    assert result.exit_code == 0, result.output
    assert_last_request(
        recorder,
        method="POST",
        path="/v1/support/tickets/t1/messages",
        body={
            "message": {
                "content": "json-message",
            },
            "userId": "json-user",
        },
    )


def test_tickets_message_rejects_empty_nested_message_content() -> None:
    with serve_controlplane_routes(_support_routes()):
        result = invoke_tm(
            [
                "--output",
                "json",
                "tickets",
                "message",
                "t1",
                "--json",
                '{"message":{"content":"   "}}',
            ],
            env=controlplane_env(),
        )

    assert result.exit_code != 0
    assert "Missing message." in result.output


def test_tickets_close_requires_confirmation_or_yes() -> None:
    with serve_controlplane_routes(_support_routes()) as recorder:
        r_abort = invoke_tm(
            ["tickets", "close", "t1"],
            env=controlplane_env(),
            input_text="n\n",
        )
        assert r_abort.exit_code != 0

        result = invoke_tm(
            ["--output", "json", "tickets", "close", "t1", "--yes"],
            env=controlplane_env(),
        )

    assert result.exit_code == 0, result.output
    assert_last_request(
        recorder,
        method="DELETE",
        path="/v1/support/tickets/t1",
    )


def test_reserved_deployments_submit_builds_request_body() -> None:
    with serve_controlplane_routes(_support_routes()) as recorder:
        result = invoke_tm(
            [
                "--output",
                "json",
                "reserved-deployments",
                "submit",
                "--full-name",
                "Ada",
                "--work-email",
                "ada@example.com",
            ],
            env=controlplane_env(),
        )
    assert result.exit_code == 0, result.output
    request = assert_last_request(
        recorder,
        method="POST",
        path="/v1/support/reserved-deployments",
    )
    assert isinstance(request.body, dict)
    assert request.body.get("fullName") == "Ada"
