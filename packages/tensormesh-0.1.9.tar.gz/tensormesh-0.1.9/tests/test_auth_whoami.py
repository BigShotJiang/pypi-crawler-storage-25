from __future__ import annotations

from pathlib import Path
from typing import Any

from tests.cli_test_utils import controlplane_auth_json_path
from tests.cli_test_utils import controlplane_env
from tests.cli_test_utils import gateway_env
from tests.cli_test_utils import invoke_tm
from tests.http_test_utils import assert_last_request
from tests.http_test_utils import json_response
from tests.http_test_utils import serve_controlplane_routes
from tests.http_test_utils import text_response


def _profile_routes(response: object):
    return {
        ("GET", "/auth/profile"): response,
    }


def test_auth_whoami_wraps_control_plane_request_errors(monkeypatch) -> None:
    import tensormesh_cli.commands.auth_cmd as auth_cmd
    import tensormesh_cli.commands.controlplane_actions as controlplane_actions

    def fail_request(ctx: Any, action: Any, default: str = "json") -> None:
        del ctx, action, default
        raise auth_cmd.click.ClickException("Request failed: HTTP 503")

    monkeypatch.setattr(controlplane_actions,
                        "execute_controlplane_sdk_and_render", fail_request)

    result = invoke_tm(
        ["auth", "whoami"],
        env=controlplane_env(),
    )

    assert result.exit_code != 0
    assert "Whoami failed." in result.output
    assert "Request failed: HTTP 503" in result.output
    assert "Try: tm auth refresh" in result.output


def test_auth_whoami_calls_profile_endpoint() -> None:
    with serve_controlplane_routes(
            _profile_routes(json_response({"user": {
                "id": "u1"
            }})), ) as recorder:
        result = invoke_tm(
            [
                "--output",
                "json",
                "auth",
                "whoami",
            ],
            env=controlplane_env(),
        )

    assert result.exit_code == 0, result.output
    assert_last_request(
        recorder,
        method="GET",
        path="/auth/profile",
        headers={"Authorization": "Bearer tok"},
    )


def test_auth_whoami_fails_on_invalid_json_response() -> None:
    with serve_controlplane_routes(_profile_routes(text_response("not-json"))):
        result = invoke_tm(
            [
                "--output",
                "json",
                "auth",
                "whoami",
            ],
            env=controlplane_env(),
        )

    assert result.exit_code != 0
    assert "Invalid JSON response: expected JSON." in result.output
    assert "Raw response: not-json" in result.output


def test_auth_whoami_fails_fast_for_invalid_token_file(tmp_path: Path) -> None:
    auth_json = controlplane_auth_json_path(tmp_path)
    auth_json.write_text("{not-json", encoding="utf-8")

    result = invoke_tm(
        [
            "auth",
            "whoami",
        ],
        env=controlplane_env(home=tmp_path, seed_file=False),
    )

    assert result.exit_code != 0
    assert "Invalid token file JSON" in result.output


def test_auth_whoami_fails_fast_for_missing_access_token_field(
    tmp_path: Path, ) -> None:
    auth_json = controlplane_auth_json_path(tmp_path)
    auth_json.write_text('{"refresh_token":"refresh"}\n', encoding="utf-8")

    result = invoke_tm(
        [
            "auth",
            "whoami",
        ],
        env=controlplane_env(home=tmp_path, seed_file=False),
    )

    assert result.exit_code != 0
    assert "Invalid token file: missing or invalid 'access_token'" in result.output


def test_auth_whoami_fails_fast_for_non_object_token_file(
    tmp_path: Path, ) -> None:
    auth_json = controlplane_auth_json_path(tmp_path)
    auth_json.write_text('["not","an","object"]\n', encoding="utf-8")

    result = invoke_tm(
        [
            "auth",
            "whoami",
        ],
        env=controlplane_env(home=tmp_path, seed_file=False),
    )

    assert result.exit_code != 0
    assert "Invalid token file JSON: expected a JSON object" in result.output


def test_auth_whoami_mentions_gateway_credentials_do_not_authenticate_control_plane(
    isolated_home: Path, ) -> None:
    result = invoke_tm(
        [
            "auth",
            "whoami",
        ],
        env={
            **gateway_env(home=isolated_home, api_key="gw_key"),
            **controlplane_env(home=isolated_home, seed_file=False),
        },
    )

    assert result.exit_code != 0
    assert "No control plane access token found." in result.output
    assert "gateway API keys do not authenticate the control plane" in result.output


def test_auth_print_token_reports_missing_control_plane_token(
    isolated_home: Path, ) -> None:
    result = invoke_tm(
        [
            "auth",
            "print-token",
            "--yes-i-know",
        ],
        env={
            **gateway_env(home=isolated_home, api_key="gw_key"),
            **controlplane_env(home=isolated_home, seed_file=False),
        },
    )

    assert result.exit_code != 0
    assert "No control plane access token found. Run `tm auth login` first." in result.output
