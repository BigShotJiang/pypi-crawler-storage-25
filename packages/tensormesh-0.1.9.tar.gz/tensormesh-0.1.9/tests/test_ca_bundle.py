from __future__ import annotations

from pathlib import Path
from typing import Any

import pytest

from tensormesh_cli.cli import cli
from tensormesh_cli.http.tls import resolve_verify_value
from tests.cli_test_utils import controlplane_env
from tests.cli_test_utils import gateway_env
from tests.cli_test_utils import patch_gateway_provider_base
from tests.response_test_utils import JSONResponse


def test_controlplane_sdk_transport_uses_ca_bundle(monkeypatch: Any,
                                                   tmp_path: Path,
                                                   runner) -> None:
    ca = tmp_path / "ca.pem"
    ca.write_text("dummy", encoding="utf-8")
    captured: dict[str, Any] = {}

    import tensormesh._transport as transport

    class _FakeRequests:

        def request(self, method: str, url: str,
                    **kwargs: Any) -> JSONResponse:
            captured["verify"] = kwargs.get("verify")
            return JSONResponse(status_code=200, payload={"models": []})

    monkeypatch.setattr(transport, "requests", _FakeRequests())

    result = runner.invoke(
        cli,
        [
            "--ca-bundle",
            str(ca),
            "--output",
            "json",
            "models",
            "list",
        ],
        env=controlplane_env(),
    )
    assert result.exit_code == 0, result.output
    assert captured.get("verify") == str(ca)


def test_gateway_requests_use_ca_bundle(monkeypatch: Any, tmp_path: Path,
                                        runner) -> None:
    ca = tmp_path / "ca.pem"
    ca.write_text("dummy", encoding="utf-8")
    captured: dict[str, Any] = {}

    import tensormesh._transport as transport

    class _FakeRequests:

        def request(self, method: str, url: str,
                    **kwargs: Any) -> JSONResponse:
            captured["verify"] = kwargs.get("verify")
            body = kwargs.get("json") or {}
            payload = {
                "id":
                "cmpl",
                "object":
                "chat.completion",
                "created":
                0,
                "model":
                body.get("model") if isinstance(body, dict) else None,
                "choices": [{
                    "index": 0,
                    "message": {
                        "role": "assistant",
                        "content": "ok"
                    },
                    "finish_reason": "stop",
                }],
            }
            return JSONResponse(status_code=200, payload=payload)

    monkeypatch.setattr(transport, "requests", _FakeRequests())
    patch_gateway_provider_base(monkeypatch, base="https://gateway.example")

    result = runner.invoke(
        cli,
        [
            "--ca-bundle",
            str(ca),
            "--output",
            "json",
            "infer",
            "chat",
            "--model",
            "m",
            "--api-key",
            "k",
            "--user-id",
            "00000000-0000-0000-0000-000000000000",
            "--json",
            '[{"role":"user","content":"hi"}]',
        ],
        env=gateway_env(api_key="k", model_id="unused"),
    )
    assert result.exit_code == 0, result.output
    assert captured.get("verify") == str(ca)


def test_resolve_verify_value_rejects_missing_path(tmp_path: Path) -> None:
    missing = tmp_path / "missing.pem"
    with pytest.raises(ValueError, match="does not exist"):
        resolve_verify_value(str(missing))


def test_resolve_verify_value_rejects_directory(tmp_path: Path) -> None:
    with pytest.raises(ValueError, match="not a file"):
        resolve_verify_value(str(tmp_path))


def test_repo_cert_bundles_are_pem_only_without_transcript_noise() -> None:
    repo_root = Path(__file__).resolve().parents[1]

    for rel_path in ("certs/extra-ca.pem", "certs/gts-root-r1-cross.pem"):
        text = (repo_root / rel_path).read_text(encoding="utf-8")
        assert "Server certificate" not in text
        assert "subject=" not in text
        assert "Verify return code:" not in text


def test_repo_extra_ca_bundle_includes_required_public_roots() -> None:
    repo_root = Path(__file__).resolve().parents[1]
    extra_bundle = (repo_root / "certs" /
                    "extra-ca.pem").read_text(encoding="utf-8")

    for rel_path in ("certs/isrgrootx1.pem", "certs/globalsign-root-ca.pem"):
        expected = (repo_root / rel_path).read_text(encoding="utf-8").strip()
        assert expected in extra_bundle


def test_repo_extra_ca_bundle_has_balanced_pem_blocks() -> None:
    repo_root = Path(__file__).resolve().parents[1]
    extra_bundle = (repo_root / "certs" /
                    "extra-ca.pem").read_text(encoding="utf-8")

    assert extra_bundle.count(
        "-----BEGIN CERTIFICATE-----") == extra_bundle.count(
            "-----END CERTIFICATE-----")
