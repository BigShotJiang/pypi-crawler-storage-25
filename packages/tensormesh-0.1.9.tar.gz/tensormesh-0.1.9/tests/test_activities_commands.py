from __future__ import annotations

from tests.cli_test_utils import controlplane_env
from tests.cli_test_utils import invoke_tm
from tests.http_test_utils import assert_last_request
from tests.http_test_utils import json_response
from tests.http_test_utils import serve_controlplane_routes


def _activity_routes():
    return {
        ("GET", "/v1/activities"):
        json_response({"activities": [{
            "id": "a1"
        }]}),
        ("GET", "/v1/activities/a1"): json_response({"activity": {
            "id": "a1"
        }}),
    }


def test_activities_list_hits_collection_endpoint() -> None:
    with serve_controlplane_routes(_activity_routes()) as recorder:
        result = invoke_tm(
            [
                "--output",
                "json",
                "activities",
                "list",
                "--size",
                "20",
            ],
            env=controlplane_env(),
        )

    assert result.exit_code == 0, result.output
    assert_last_request(
        recorder,
        method="GET",
        path="/v1/activities",
    )


def test_activities_get_hits_resource_endpoint() -> None:
    with serve_controlplane_routes(_activity_routes()) as recorder:
        result = invoke_tm(
            ["--output", "json", "activities", "get", "a1"],
            env=controlplane_env(),
        )

    assert result.exit_code == 0, result.output
    assert_last_request(
        recorder,
        method="GET",
        path="/v1/activities/a1",
    )
