from __future__ import annotations

import json
import os
from pathlib import Path

import pytest

from tensormesh_cli.auth import access_token
from tensormesh_cli.auth import load_tokens
from tensormesh_cli.auth import save_tokens
import tensormesh_cli.auth.storage as auth_storage


def test_save_and_load_tokens_roundtrip(tmp_path: Path) -> None:
    token_path = tmp_path / "auth.json"
    data = {"access_token": "a", "refresh_token": "r"}
    save_tokens(token_path, data)
    loaded = load_tokens(token_path)
    assert loaded == data
    assert access_token(token_path) == "a"


def test_load_tokens_invalid_json_raises(tmp_path: Path) -> None:
    token_path = tmp_path / "auth.json"
    token_path.write_text("{not-json", encoding="utf-8")
    with pytest.raises(RuntimeError, match="Invalid token file JSON"):
        load_tokens(token_path)


def test_load_tokens_rejects_non_object_json(tmp_path: Path) -> None:
    token_path = tmp_path / "auth.json"
    token_path.write_text('["not", "an", "object"]\n', encoding="utf-8")

    with pytest.raises(RuntimeError, match="expected a JSON object"):
        load_tokens(token_path)


def test_access_token_missing_field_raises(tmp_path: Path) -> None:
    token_path = tmp_path / "auth.json"
    token_path.write_text('{"refresh_token":"r"}\n', encoding="utf-8")

    with pytest.raises(RuntimeError,
                       match="missing or invalid 'access_token'"):
        access_token(token_path)


def test_save_tokens_preserves_existing_file_if_replace_fails(
        monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    token_path = tmp_path / "auth.json"
    token_path.write_text(json.dumps({"access_token": "old"}) + "\n",
                          encoding="utf-8")
    token_path.chmod(0o600)

    def fail_replace(src: str, dst: str) -> None:
        raise OSError("replace failed")

    monkeypatch.setattr(auth_storage.os, "replace", fail_replace)

    with pytest.raises(OSError, match="replace failed"):
        save_tokens(token_path, {"access_token": "new", "refresh_token": "r"})

    assert json.loads(token_path.read_text(encoding="utf-8")) == {
        "access_token": "old"
    }
    assert list(tmp_path.glob(".auth.json.*.tmp")) == []
    assert os.stat(token_path).st_mode & 0o777 == 0o600


def test_save_tokens_swallows_cleanup_errors_after_replace_failure(
        monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    token_path = tmp_path / "auth.json"

    def fail_replace(src: str, dst: str) -> None:
        raise OSError("replace failed")

    def fail_close(fd: int) -> None:
        raise OSError("close failed")

    def fail_unlink(path: str) -> None:
        raise OSError("unlink failed")

    monkeypatch.setattr(auth_storage.os, "replace", fail_replace)
    monkeypatch.setattr(auth_storage.os, "close", fail_close)
    monkeypatch.setattr(auth_storage.os, "unlink", fail_unlink)

    with pytest.raises(OSError, match="replace failed"):
        save_tokens(token_path, {"access_token": "new", "refresh_token": "r"})


def test_load_tokens_read_error_and_missing_access_token_file(
        monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    token_path = tmp_path / "auth.json"
    token_path.write_text('{"access_token":"tok"}\n', encoding="utf-8")

    def fail_read_text(self: Path, encoding: str = "utf-8") -> str:
        raise OSError("read failed")

    monkeypatch.setattr(Path, "read_text", fail_read_text)

    with pytest.raises(RuntimeError, match="Failed to read token file"):
        load_tokens(token_path)

    assert access_token(tmp_path / "missing-auth.json") is None
