from __future__ import annotations

from pathlib import Path

from tests.cli_test_utils import controlplane_env
from tests.cli_test_utils import gateway_env
from tests.cli_test_utils import invoke_tm
from tests.cli_test_utils import parse_result_json
from tests.readiness_test_utils import invoke_tm_json
from tests.readiness_test_utils import merge_env
from tests.readiness_test_utils import write_raw_controlplane_auth_json


def _auth_status_json(
    *,
    env: dict[str, str],
    output: str = "json",
    exit_status: bool = False,
):
    args = ["--output", output, "auth", "status"]
    if exit_status:
        args.append("--exit-status")
    return invoke_tm_json(args, env=env)


def test_auth_status_reports_control_plane_and_gateway_state_json() -> None:
    _, data = _auth_status_json(env=merge_env(controlplane_env(),
                                              gateway_env()), )
    assert data["ready"]["overall"] is True
    assert data["control_plane"]["access_token_present"] is True
    assert data["gateway"]["api_key_present"] is True
    assert data["gateway"]["user_id_present"] is True
    assert data["gateway"]["model_id_present"] is True
    assert data["gateway"]["api_key_source"] == "managed:gateway_api_key"


def test_auth_status_raw_output_is_json_for_structured_local_data() -> None:
    _, data = _auth_status_json(
        output="raw",
        env=merge_env(controlplane_env(), gateway_env()),
    )
    assert data["ready"]["overall"] is True
    assert data["gateway"]["api_key_present"] is True


def test_auth_status_warns_for_invalid_control_plane_auth_json(
    tmp_path: Path, ) -> None:
    write_raw_controlplane_auth_json(tmp_path, "{not-json")

    _, data = _auth_status_json(env=merge_env(
        gateway_env(home=tmp_path),
        controlplane_env(home=tmp_path, seed_file=False),
    ), )
    assert any("control_plane_auth_json invalid" in item
               for item in data["warnings"])


def test_auth_status_human_output_reports_warnings(tmp_path: Path) -> None:
    write_raw_controlplane_auth_json(tmp_path, "{not-json")

    result = invoke_tm(
        [
            "auth",
            "status",
        ],
        env={
            **gateway_env(home=tmp_path),
            **controlplane_env(home=tmp_path, seed_file=False),
        },
    )

    assert result.exit_code == 0, result.output
    assert "tm auth status" in result.output
    assert "Control Plane:" in result.output
    assert "Gateway:" in result.output
    assert "Warnings:" in result.output
    assert "Local status only." in result.output
    assert "control_plane_auth_json invalid" in result.output


def test_auth_status_exit_status_fails_when_prerequisites_missing(
    isolated_home: Path, ) -> None:
    result = invoke_tm(
        [
            "auth",
            "status",
            "--exit-status",
        ],
        env=controlplane_env(home=isolated_home, seed_file=False),
    )

    assert result.exit_code == 1, result.output
    assert "token=missing" in result.output
    assert "api_key=missing" in result.output


def test_auth_status_exit_status_succeeds_when_prerequisites_present() -> None:
    result = invoke_tm(
        ["auth", "status", "--exit-status"],
        env={
            **controlplane_env(),
            **gateway_env(),
        },
    )

    assert result.exit_code == 0, result.output


def test_auth_status_exit_status_succeeds_with_derived_gateway_user_id(
    tmp_path: Path, ) -> None:
    result, data = _auth_status_json(
        exit_status=True,
        env=merge_env(
            controlplane_env(home=tmp_path),
            gateway_env(home=tmp_path, api_key="gw_key", user_id=None),
        ),
    )
    assert result.exit_code == 0, result.output
    assert data["ready"]["gateway"] is True
    assert data["gateway"]["user_id_derived_from_controlplane"] is True


def test_auth_status_human_output_marks_derived_gateway_user_id() -> None:
    result = invoke_tm(
        ["auth", "status"],
        env={
            **controlplane_env(),
            **gateway_env(api_key="gw_key", user_id=None),
        },
    )

    assert result.exit_code == 0, result.output
    assert "user_id=derived" in result.output


def test_auth_status_exit_status_fails_for_invalid_gateway_user_id() -> None:
    result = invoke_tm(
        ["--output", "json", "auth", "status", "--exit-status"],
        env={
            **controlplane_env(),
            **gateway_env(api_key="gw_key", user_id="not-a-uuid"),
        },
    )

    assert result.exit_code == 1, result.output
    data = parse_result_json(result)
    assert data["ready"]["gateway"] is False
    assert data["ready"]["overall"] is False
    assert data["gateway"]["user_id_valid"] is False
    assert any("Invalid gateway user id" in item for item in data["warnings"])
