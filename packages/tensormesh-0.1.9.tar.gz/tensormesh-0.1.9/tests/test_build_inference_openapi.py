from __future__ import annotations

from pathlib import Path

import yaml

from tests.script_test_utils import load_script_module

SCRIPT_PATH = (Path(__file__).resolve().parents[1] / "scripts" /
               "build-inference-openapi.py")
REPO_ROOT = Path(__file__).resolve().parents[1]


def test_build_inference_specs_emits_both_surfaces() -> None:
    mod = load_script_module(SCRIPT_PATH)

    generated = mod.build_inference_specs(write_output=False)

    assert sorted(generated) == ["on-demand", "serverless"]


def test_build_inference_specs_keeps_shared_request_shape() -> None:
    mod = load_script_module(SCRIPT_PATH)
    generated = mod.build_inference_specs(write_output=False)

    on_demand_properties = generated["on-demand"]["components"]["schemas"][
        "ChatCompletionRequest"]["properties"]
    serverless_properties = generated["serverless"]["components"]["schemas"][
        "ChatCompletionRequest"]["properties"]

    assert list(on_demand_properties) == list(serverless_properties)
    assert "X-User-Id" == generated["on-demand"]["paths"][
        "/v1/chat/completions"]["post"]["parameters"][0]["name"]
    assert "parameters" not in generated["serverless"]["paths"][
        "/v1/chat/completions"]["post"]


def test_build_inference_specs_preserves_surface_specific_compatibility_text(
) -> None:
    mod = load_script_module(SCRIPT_PATH)
    generated = mod.build_inference_specs(write_output=False)

    on_demand_description = generated["on-demand"]["info"]["description"]
    serverless_description = generated["serverless"]["info"]["description"]

    assert "Near-compatible chat completions endpoint" in on_demand_description
    assert "X-User-Id" in on_demand_description
    assert "OpenAI-compatible chat completions endpoint" in (
        serverless_description)


def test_build_inference_specs_document_serverless_model_discovery_command(
) -> None:
    mod = load_script_module(SCRIPT_PATH)
    generated = mod.build_inference_specs(write_output=False)

    serverless_description = generated["serverless"]["info"]["description"]
    model_description = generated["serverless"]["components"]["schemas"][
        "ChatCompletionRequest"]["properties"]["model"]["description"]

    for text in (serverless_description, model_description):
        normalized = " ".join(text.split())
        assert "tm billing pricing serverless list" in normalized
        assert "pricing[].model" in normalized
        assert "same Tensormesh environment" in normalized


def test_build_inference_specs_include_verified_serverless_vllm_routes(
) -> None:
    mod = load_script_module(SCRIPT_PATH)
    generated = mod.build_inference_specs(write_output=False)

    serverless_paths = generated["serverless"]["paths"]

    assert set(serverless_paths) == {
        "/v1/chat/completions",
        "/v1/models",
        "/v1/completions",
        "/v1/responses",
        "/tokenize",
        "/detokenize",
        "/health",
        "/version",
    }
    assert "/v1/embeddings" not in serverless_paths
    assert "/v1/audio/transcriptions" not in serverless_paths


def test_build_inference_specs_include_on_demand_openai_compatible_routes(
) -> None:
    mod = load_script_module(SCRIPT_PATH)
    generated = mod.build_inference_specs(write_output=False)

    on_demand_paths = generated["on-demand"]["paths"]

    assert set(on_demand_paths) == {
        "/v1/chat/completions",
        "/v1/models",
        "/v1/completions",
        "/v1/responses",
        "/tokenize",
        "/detokenize",
        "/health",
        "/version",
    }


def test_build_inference_specs_require_routing_headers_for_all_on_demand_routes(
) -> None:
    mod = load_script_module(SCRIPT_PATH)
    generated = mod.build_inference_specs(write_output=False)

    on_demand_paths = generated["on-demand"]["paths"]

    for _path, methods in on_demand_paths.items():
        operation = methods[next(iter(methods))]
        assert operation["parameters"][0]["name"] == "X-User-Id"
        assert operation["security"] == [{"BearerAuth": []}]


def test_build_inference_specs_allow_prompt_or_messages_for_serverless_tokenize(
) -> None:
    mod = load_script_module(SCRIPT_PATH)
    generated = mod.build_inference_specs(write_output=False)

    tokenize_schema = generated["serverless"]["components"]["schemas"][
        "TokenizeRequest"]
    tokenize_properties = tokenize_schema["properties"]
    tokenize_example = generated["serverless"]["paths"]["/tokenize"]["post"][
        "requestBody"]["content"]["application/json"]["example"]

    assert "prompt" in tokenize_properties
    assert "messages" in tokenize_properties
    assert tokenize_schema["required"] == ["model"]
    assert tokenize_schema["anyOf"] == [
        {
            "required": ["prompt"]
        },
        {
            "required": ["messages"]
        },
    ]
    assert "text" not in tokenize_schema
    assert tokenize_example["prompt"] == "Hello!"
    assert "text" not in tokenize_example


def test_build_inference_specs_keep_public_serverless_get_routes_unauthenticated(
) -> None:
    mod = load_script_module(SCRIPT_PATH)
    generated = mod.build_inference_specs(write_output=False)

    serverless_paths = generated["serverless"]["paths"]
    serverless_description = generated["serverless"]["info"]["description"]

    assert serverless_paths["/v1/models"]["get"]["security"] == []
    assert serverless_paths["/health"]["get"]["security"] == []
    assert serverless_paths["/version"]["get"]["security"] == []
    normalized = " ".join(serverless_description.split())
    assert "GET /v1/models" in normalized
    assert "GET /health" in normalized
    assert "GET /version" in normalized
    assert "without auth" in normalized


def test_build_inference_specs_include_shared_response_fields_present_in_sdk(
) -> None:
    mod = load_script_module(SCRIPT_PATH)
    generated = mod.build_inference_specs(write_output=False)

    for surface in ("serverless", "on-demand"):
        components = generated[surface]["components"]["schemas"]
        assert "logprobs" in components["TextCompletionChoice"]["properties"]
        assert "stop_reason" in components["TextCompletionChoice"][
            "properties"]
        assert "usage" in components["TextCompletionResponse"]["properties"]
        assert "annotations" in components["ResponseOutputContent"][
            "properties"]
        assert "role" in components["ResponseOutputItem"]["properties"]
        assert "status" in components["ResponseOutputItem"]["properties"]
        assert "status" in components["ResponseCreateResponse"]["properties"]


def test_build_inference_specs_document_non_chat_sse_responses() -> None:
    mod = load_script_module(SCRIPT_PATH)
    generated = mod.build_inference_specs(write_output=False)

    for surface in ("serverless", "on-demand"):
        completions_content = generated[surface]["paths"]["/v1/completions"][
            "post"]["responses"]["200"]["content"]
        responses_content = generated[surface]["paths"]["/v1/responses"][
            "post"]["responses"]["200"]["content"]

        assert "text/event-stream" in completions_content
        assert "text/event-stream" in responses_content
        assert "data: [DONE]" in completions_content["text/event-stream"][
            "example"]
        assert "data: [DONE]" in responses_content["text/event-stream"][
            "example"]


def test_build_inference_specs_document_rate_limit_responses() -> None:
    mod = load_script_module(SCRIPT_PATH)
    generated = mod.build_inference_specs(write_output=False)

    for surface in ("serverless", "on-demand"):
        for path in ("/v1/chat/completions", "/v1/completions",
                     "/v1/responses"):
            responses = generated[surface]["paths"][path]["post"]["responses"]
            assert "429" in responses
            assert responses["429"]["description"] == "Rate Limited"


def test_checked_in_inference_openapi_matches_generator(
        tmp_path: Path) -> None:
    mod = load_script_module(SCRIPT_PATH)
    generated = mod.build_inference_specs(write_output=False)

    checked_in_on_demand = yaml.safe_load(
        (REPO_ROOT / "docs" / "api-reference" /
         "on-demand.openapi.yaml").read_text(encoding="utf-8"))
    checked_in_serverless = yaml.safe_load(
        (REPO_ROOT / "docs" / "api-reference" /
         "serverless.openapi.yaml").read_text(encoding="utf-8"))

    assert generated["on-demand"] == checked_in_on_demand
    assert generated["serverless"] == checked_in_serverless
