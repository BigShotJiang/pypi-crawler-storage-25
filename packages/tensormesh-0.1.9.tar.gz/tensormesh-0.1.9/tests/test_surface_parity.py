from __future__ import annotations

import json
from pathlib import Path
import subprocess
import sys

import yaml

REPO_ROOT = Path(__file__).resolve().parents[1]
SURFACE_PARITY_SCRIPT = REPO_ROOT / "scripts" / "check-surface-parity.py"


def test_public_surface_contract_doc_records_key_alignment_rules() -> None:
    contract = (REPO_ROOT / "dev" /
                "public-surface-contract.md").read_text(encoding="utf-8")

    assert "Source of truth" in contract
    assert "openapi/tensormesh/sdk-codegen-manifest.json" in contract
    assert "TM_CONFIG_HOME" in contract
    assert "model name" in contract
    assert "config compatibility key" in contract
    assert "same underlying inference API key" in contract
    assert "Stripe webhook delivery" in contract
    assert "Control Plane base setup" in contract
    assert "DEFAULT_CONTROL_PLANE_BASE_URL" in contract
    assert "current default Control Plane host is `https://api.tensormesh.ai`" in contract
    assert "env-only overrides stay session-scoped" in contract


def test_surface_parity_script_passes_for_current_repo(tmp_path: Path) -> None:
    report_path = tmp_path / "surface-parity.json"

    result = subprocess.run(
        [
            sys.executable,
            str(SURFACE_PARITY_SCRIPT),
            "--report",
            str(report_path),
        ],
        cwd=REPO_ROOT,
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stdout + result.stderr
    assert "ok: surface parity" in result.stdout

    report = json.loads(report_path.read_text(encoding="utf-8"))
    assert report["status"] == "ok"
    assert report["checks"]
    assert any(check["name"] == "stripe-public-surface"
               for check in report["checks"])
    assert any(check["name"] == "inference-model-terminology"
               for check in report["checks"])
    assert any(check["name"] == "cli-config-root-docs"
               for check in report["checks"])
    assert any(check["name"] == "control-plane-base-setup"
               for check in report["checks"])
    assert any(check["name"] == "on-demand-user-id-docs"
               for check in report["checks"])
    assert any(check["name"] == "workflow-docs" for check in report["checks"])


def test_verify_paths_run_surface_parity_check() -> None:
    verify_script = (REPO_ROOT / "scripts" /
                     "verify.sh").read_text(encoding="utf-8")
    workflow = yaml.safe_load((REPO_ROOT / ".github" / "workflows" /
                               "verify.yml").read_text(encoding="utf-8"))

    assert '"$PYTHON_BIN" ./scripts/check-surface-parity.py' in verify_script

    python_steps = workflow["jobs"]["verify-python"]["steps"]
    step_by_name = {
        step["name"]: step
        for step in python_steps if isinstance(step, dict) and "name" in step
    }
    assert step_by_name["Check docs/SDK/CLI surface parity"][
        "run"] == "python ./scripts/check-surface-parity.py"
