from __future__ import annotations

import json

from tests.cli_test_utils import controlplane_env
from tests.cli_test_utils import invoke_tm
from tests.http_test_utils import assert_last_request
from tests.http_test_utils import json_response
from tests.http_test_utils import serve_controlplane_routes


def _models_routes():
    return {
        ("POST", "/v1/models:validate"): json_response({"isValid": True}),
        ("POST", "/v1/models:search-by-infra"): json_response({"models": []}),
        ("POST", "/v1/models/m1:chat"): json_response({"response": "ok"}),
        ("POST", "/v1/models"): json_response({"model": {
            "modelId": "m1"
        }}),
        ("DELETE", "/v1/models/m1"): json_response({"empty": {}}),
    }


def test_models_validate_name_builds_payload_from_flags() -> None:
    with serve_controlplane_routes(_models_routes()) as recorder:
        result = invoke_tm(
            ["--output", "json", "models", "validate-name", "--name", "abc"],
            env=controlplane_env(),
        )

    assert result.exit_code == 0, result.output
    request = assert_last_request(
        recorder,
        method="POST",
        path="/v1/models:validate",
    )
    assert isinstance(request.body, dict)
    assert request.body.get("modelName") == "abc"


def test_models_search_by_infra_forwards_json_body() -> None:
    with serve_controlplane_routes(_models_routes()) as recorder:
        payload = {"infra": {"cloudProvider": "CLOUD_PROVIDER_NEBIUS"}}
        result = invoke_tm(
            [
                "--output",
                "json",
                "models",
                "search-by-infra",
                "--json",
                json.dumps(payload),
            ],
            env=controlplane_env(),
        )

    assert result.exit_code == 0, result.output
    assert_last_request(
        recorder,
        method="POST",
        path="/v1/models:search-by-infra",
        body=payload,
    )


def test_models_chat_builds_payload_from_message() -> None:
    with serve_controlplane_routes(_models_routes()) as recorder:
        result = invoke_tm(
            [
                "--output",
                "json",
                "models",
                "chat",
                "m1",
                "--message",
                "hi",
                "--user-id",
                "u1",
            ],
            env=controlplane_env(),
        )

    assert result.exit_code == 0, result.output
    assert_last_request(
        recorder,
        method="POST",
        path="/v1/models/m1:chat",
        body={
            "body": "hi",
            "userId": "u1"
        },
    )


def test_models_chat_default_output_prints_response_text() -> None:
    with serve_controlplane_routes(_models_routes()):
        result = invoke_tm(
            [
                "models",
                "chat",
                "m1",
                "--message",
                "hi",
            ],
            env=controlplane_env(),
        )

    assert result.exit_code == 0, result.output
    assert result.output == "ok\n"


def test_models_delete_requires_confirmation_or_yes() -> None:
    with serve_controlplane_routes(_models_routes()) as recorder:
        # Without --yes, aborting confirmation yields non-zero.
        r_abort = invoke_tm(
            ["models", "delete", "m1"],
            env=controlplane_env(),
            input_text="n\n",
        )
        assert r_abort.exit_code != 0

        # With --yes, no prompt and request is sent.
        r_yes = invoke_tm(
            ["--output", "json", "models", "delete", "m1", "--yes"],
            env=controlplane_env(),
        )

    assert r_yes.exit_code == 0, r_yes.output
    assert_last_request(
        recorder,
        method="DELETE",
        path="/v1/models/m1",
    )


def test_models_deploy_posts_json_and_requires_yes_or_confirm() -> None:
    with serve_controlplane_routes(_models_routes()) as recorder:
        r_abort = invoke_tm(
            ["models", "deploy", "--json", "{}"],
            env=controlplane_env(),
            input_text="n\n",
        )
        assert r_abort.exit_code != 0

        payload = {"modelName": "x"}
        r_yes = invoke_tm(
            [
                "--output", "json", "models", "deploy", "--yes", "--json",
                json.dumps(payload)
            ],
            env=controlplane_env(),
        )

    assert r_yes.exit_code == 0, r_yes.output
    assert_last_request(
        recorder,
        method="POST",
        path="/v1/models",
        body=payload,
    )
