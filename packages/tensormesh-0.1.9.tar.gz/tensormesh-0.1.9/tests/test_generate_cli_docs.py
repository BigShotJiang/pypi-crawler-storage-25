from __future__ import annotations

import json
from pathlib import Path
import subprocess
import sys
from typing import Iterable

from tests.script_test_utils import load_script_module

SCRIPT_PATH = (Path(__file__).resolve().parents[1] / "scripts" /
               "generate-cli-docs.py")
REPO_ROOT = Path(__file__).resolve().parents[1]


def _iter_relative_files(base: Path) -> Iterable[Path]:
    for path in sorted(base.rglob("*")):
        if path.is_file():
            yield path.relative_to(base)


def test_build_cli_docs_model_enumerates_public_command_tree() -> None:
    mod = load_script_module(SCRIPT_PATH)
    model = mod.build_cli_docs_model(mod.cli)
    by_path = {command.path: command for command in model.commands}

    assert model.root_command == "tm"
    assert model.command_count == 108
    assert "tm billing address get" in by_path
    assert "tm billing address update" in by_path
    assert "tm billing stripe customer get" in by_path
    assert "tm billing stripe payment-methods list" in by_path
    assert "tm billing stripe payment-methods attach" in by_path
    assert "tm billing stripe payment-methods detach" in by_path
    assert "tm billing stripe payment-intents create" in by_path
    assert "tm billing stripe payment-intents confirm" in by_path
    assert "tm billing stripe setup-intents create" in by_path
    assert "tm admin billing spending summary" in by_path
    assert "tm admin models list" in by_path
    assert "tm models check" in by_path
    assert "tm infer chat" in by_path
    assert "tm infer models" in by_path
    assert "tm infer completions" in by_path
    assert "tm infer responses" in by_path
    assert "tm infer tokenize" in by_path
    assert "tm infer detokenize" in by_path
    assert "tm infer health" in by_path
    assert "tm infer version" in by_path
    assert "tm init" in by_path
    assert "tm version" in by_path
    assert "tm users api-keys create" in by_path
    assert by_path["tm auth"].kind == "group"
    assert by_path["tm auth"].subcommands == [
        "login",
        "logout",
        "print-token",
        "refresh",
        "status",
        "whoami",
    ]


def test_build_cli_docs_model_uses_in_code_metadata_and_normalizes_defaults(
) -> None:
    mod = load_script_module(SCRIPT_PATH)
    model = mod.build_cli_docs_model(mod.cli)
    by_path = {command.path: command for command in model.commands}

    infer_chat = by_path["tm infer chat"]
    assert infer_chat.examples
    assert infer_chat.auth_scope == ["inference-api-key"]
    assert infer_chat.env_vars == []
    assert infer_chat.related_commands == [
        "tm init", "tm billing pricing serverless list", "tm models list",
        "tm doctor"
    ]
    assert (
        by_path["tm infer"].summary ==
        "Inference commands for shared serverless and On-Demand OpenAI-compatible endpoints."
    )

    pricing_serverless = by_path["tm billing pricing serverless"]
    assert pricing_serverless.examples
    assert pricing_serverless.examples[0].command == (
        "tm billing pricing serverless list")

    user_api_keys = by_path["tm users api-keys"]
    assert user_api_keys.examples
    assert user_api_keys.examples[0].command == "tm users api-keys list"

    config_option = next(param for param in by_path["tm"].parameters
                         if "--config" in param.param_decls)
    assert config_option.default == "~/.config/tensormesh/config.toml"

    inherited = next(param for param in infer_chat.inherited_global_options
                     if "--config" in param.param_decls)
    assert inherited.inherited is True
    assert inherited.default == "~/.config/tensormesh/config.toml"
    assert all("--timeout" not in param.param_decls
               for param in infer_chat.inherited_global_options)


def test_script_writes_stable_model_json(tmp_path: Path) -> None:
    output_path = tmp_path / "cli-model.json"

    result = subprocess.run(
        [
            sys.executable,
            str(SCRIPT_PATH),
            "--output",
            str(output_path),
        ],
        cwd=REPO_ROOT,
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr
    payload = json.loads(output_path.read_text(encoding="utf-8"))
    infer_chat = next(item for item in payload["commands"]
                      if item["path"] == "tm infer chat")

    assert payload["command_count"] == 108
    assert infer_chat["page_path"] == "cli/reference/infer/chat.mdx"
    assert infer_chat["examples"][0]["description"] == (
        "Send a non-streaming On-Demand chat request after `tm auth login` and `tm init --sync`."
    )


def test_render_reference_pages_writes_expected_mdx(tmp_path: Path) -> None:
    mod = load_script_module(SCRIPT_PATH)
    model = mod.build_cli_docs_model(mod.cli)

    written = mod.render_reference_pages(model, tmp_path / "reference")
    written_paths = {path.relative_to(tmp_path).as_posix() for path in written}
    infer_chat_page = tmp_path / "reference" / "infer" / "chat.mdx"
    auth_group_page = tmp_path / "reference" / "auth" / "index.mdx"

    assert "reference/infer/chat.mdx" in written_paths
    assert "reference/auth/index.mdx" in written_paths

    infer_chat_text = infer_chat_page.read_text(encoding="utf-8")
    assert 'title: "tm infer chat"' in infer_chat_text
    assert "## When To Use This" in infer_chat_text
    assert "## Usage" in infer_chat_text
    assert "## Examples" in infer_chat_text
    assert ("[`tm billing pricing serverless list`]"
            "(/cli/reference/billing/pricing/serverless/list)"
            in infer_chat_text)
    assert ("Discover valid serverless model names with "
            "`tm billing pricing serverless list`" not in infer_chat_text)
    assert ("same Tensormesh environment" in infer_chat_text)
    assert ("returned `pricing[].model` value" in infer_chat_text)
    assert ("different serverless host override" in infer_chat_text)
    assert (
        "`gateway_api_key` is the stored inference API key used by the SDK as `inference_api_key`."
        in infer_chat_text)
    assert "```sh\ntm infer chat --json" in infer_chat_text
    assert infer_chat_text.count("| `--timeout` |") == 1
    assert "## Additional Notes" not in infer_chat_text
    assert "YOUR_SERVERLESS_MODEL_NAME" in infer_chat_text
    assert "MiniMaxAI/MiniMax-M2.5" not in infer_chat_text

    config_show_text = (tmp_path / "reference" / "config" /
                        "show.mdx").read_text(encoding="utf-8")
    assert (
        "`gateway_api_key` is the stored inference API key used by the SDK as `inference_api_key`."
        in config_show_text)
    assert (
        "`gateway_model_id` remains a config compatibility key; its value is the served model name string sent as `model`."
        in config_show_text)

    init_text = (tmp_path / "reference" /
                 "init.mdx").read_text(encoding="utf-8")
    assert ("persist controlplane_base for later commands when this command "
            "is run with --controlplane-base." in init_text)
    assert ("[`tm billing pricing serverless list`]"
            "(/cli/reference/billing/pricing/serverless/list)" in init_text)
    assert "explicit non-default controlplane_base" not in init_text

    pricing_serverless_text = (tmp_path / "reference" / "billing" / "pricing" /
                               "serverless" /
                               "list.mdx").read_text(encoding="utf-8")
    assert "## When To Use This" in pricing_serverless_text
    assert "pricing[].model" in pricing_serverless_text
    assert "tm --output json billing pricing serverless list --active-only" in pricing_serverless_text

    billing_address_update_text = (tmp_path / "reference" / "billing" /
                                   "address" /
                                   "update.mdx").read_text(encoding="utf-8")
    assert (
        "tm billing address update --json '{\"address\":{\"line1\":\"123 Main St\",\"city\":\"HCMC\",\"country\":\"VN\"}}'"
        in billing_address_update_text)

    infer_index_text = (tmp_path / "reference" / "infer" /
                        "index.mdx").read_text(encoding="utf-8")
    assert ("Inference commands for shared serverless and On-Demand "
            "OpenAI-compatible endpoints." in infer_index_text)
    assert "[`tm infer models`](/cli/reference/infer/models)" in infer_index_text
    assert "[`tm infer version`](/cli/reference/infer/version)" in infer_index_text

    auth_group_text = auth_group_page.read_text(encoding="utf-8")
    assert "## Subcommands" in auth_group_text
    assert "[`tm auth login`](/cli/reference/auth/login)" in auth_group_text


def test_render_reference_pages_do_not_repeat_frontmatter_summary(
        tmp_path: Path) -> None:
    mod = load_script_module(SCRIPT_PATH)
    model = mod.build_cli_docs_model(mod.cli)

    mod.render_reference_pages(model, tmp_path / "reference")

    auth_status_text = (tmp_path / "reference" / "auth" /
                        "status.mdx").read_text(encoding="utf-8")
    auth_status_body = auth_status_text.split("---\n\n", 1)[1]
    assert auth_status_body.startswith("## What This Checks")

    config_show_text = (tmp_path / "reference" / "config" /
                        "show.mdx").read_text(encoding="utf-8")
    config_show_body = config_show_text.split("---\n\n", 1)[1]
    assert config_show_body.startswith("## Usage")


def test_script_can_render_reference_tree(tmp_path: Path) -> None:
    reference_dir = tmp_path / "reference"

    result = subprocess.run(
        [
            sys.executable,
            str(SCRIPT_PATH),
            "--reference-dir",
            str(reference_dir),
        ],
        cwd=REPO_ROOT,
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr
    assert (reference_dir / "index.mdx").exists()
    assert (reference_dir / "auth" / "login.mdx").exists()
    assert (reference_dir / "infer" / "chat.mdx").exists()


def test_script_check_passes_for_checked_in_reference_tree() -> None:
    result = subprocess.run(
        [
            sys.executable,
            str(SCRIPT_PATH),
            "--check",
            "--reference-dir",
            str(REPO_ROOT / "docs" / "cli" / "reference"),
        ],
        cwd=REPO_ROOT,
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stdout + result.stderr


def test_script_check_detects_reference_drift(tmp_path: Path) -> None:
    reference_dir = tmp_path / "reference"
    mod = load_script_module(SCRIPT_PATH,
                             module_name="generate_cli_docs_check")
    mod.render_reference_pages(mod.build_cli_docs_model(mod.cli),
                               reference_dir)
    chat_page = reference_dir / "infer" / "chat.mdx"
    chat_page.write_text(
        chat_page.read_text(encoding="utf-8").replace("tm infer chat",
                                                      "tm infer drift", 1),
        encoding="utf-8",
    )

    result = subprocess.run(
        [
            sys.executable,
            str(SCRIPT_PATH),
            "--check",
            "--reference-dir",
            str(reference_dir),
        ],
        cwd=REPO_ROOT,
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 1
    assert "generated" in result.stdout


def test_build_cli_docs_model_requires_summaries_and_top_level_examples(
) -> None:
    mod = load_script_module(SCRIPT_PATH)
    model = mod.build_cli_docs_model(mod.cli)

    missing_summaries = [
        command.path for command in model.commands
        if not command.summary.strip()
    ]
    missing_top_level_examples = [
        command.path for command in model.commands
        if len(command.segments) == 2 and not command.examples
    ]

    assert missing_summaries == []
    assert missing_top_level_examples == []


def test_checked_in_cli_reference_matches_generator(tmp_path: Path) -> None:
    mod = load_script_module(SCRIPT_PATH)
    model = mod.build_cli_docs_model(mod.cli)
    generated_dir = tmp_path / "reference"
    checked_in_dir = REPO_ROOT / "docs" / "cli" / "reference"

    mod.render_reference_pages(model, generated_dir)

    generated_files = list(_iter_relative_files(generated_dir))
    checked_in_files = list(_iter_relative_files(checked_in_dir))

    assert generated_files == checked_in_files
    for rel_path in generated_files:
        generated_text = (generated_dir / rel_path).read_text(encoding="utf-8")
        checked_in_text = (checked_in_dir /
                           rel_path).read_text(encoding="utf-8")
        assert generated_text == checked_in_text, rel_path.as_posix()
