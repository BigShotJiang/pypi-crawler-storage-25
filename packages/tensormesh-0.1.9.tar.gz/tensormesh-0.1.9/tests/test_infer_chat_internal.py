from __future__ import annotations

from pathlib import Path
from typing import Any
from unittest.mock import patch

import click
import pytest

from tensormesh_cli.commands import infer_chat_support as support
from tensormesh_cli.http.context_request import RequestConfigError
from tensormesh_cli.http.context_request import RequestExecutionError
from tests.infer_chat_test_utils import _infer_test_ctx
from tests.response_test_utils import JSONResponse


class _FakeInferenceSurface:

    def __init__(
        self,
        *,
        request_result: Any = None,
        stream_result: Any = None,
        request_error: Exception | None = None,
        stream_error: Exception | None = None,
    ) -> None:
        self.request_result = request_result
        self.stream_result = stream_result
        self.request_error = request_error
        self.stream_error = stream_error
        self.request_calls: list[dict[str, Any]] = []
        self.stream_calls: list[dict[str, Any]] = []

    def request(self, method: str, path: str, **kwargs: Any) -> Any:
        self.request_calls.append({
            "method": method,
            "path": path,
            **kwargs,
        })
        if self.request_error is not None:
            raise self.request_error
        return self.request_result

    def stream_request(self, method: str, path: str, **kwargs: Any) -> Any:
        self.stream_calls.append({
            "method": method,
            "path": path,
            **kwargs,
        })
        if self.stream_error is not None:
            raise self.stream_error
        return self.stream_result


class _FakeInferenceClient:

    def __init__(self, surface: _FakeInferenceSurface) -> None:
        self.on_demand = surface
        self.serverless = surface


class _FakeSDKClient:

    def __init__(self, surface: _FakeInferenceSurface) -> None:
        self.inference = _FakeInferenceClient(surface)


class _FakeTransport:

    def __init__(self, *, buffered_response: Any | None = None) -> None:
        self.last_buffered_response = buffered_response


class _FakeStream:

    def __init__(
        self,
        *,
        deltas: list[str] | None = None,
        error: Exception | None = None,
    ) -> None:
        self._deltas = list(deltas or [])
        self._error = error
        self.closed = False

    def text_deltas(self):
        if self._error is not None:
            raise self._error
        yield from self._deltas

    def close(self) -> None:
        self.closed = True


def test_infer_chat_support_build_payload_validates_and_overrides_model(
) -> None:
    with pytest.raises(ValueError, match="Missing --model"):
        support.build_payload(
            source=[{
                "role": "user",
                "content": "hi"
            }],
            model=None,
            stream=False,
        )

    payload = support.build_payload(
        source={
            "model": "from-body",
            "messages": [{
                "role": "user",
                "content": "hi"
            }],
        },
        model="override-model",
        stream=True,
    )
    assert payload["model"] == "override-model"
    assert payload["stream"] is True

    with pytest.raises(ValueError, match="Missing model"):
        support.build_payload(
            source={
                "model": "   ",
                "messages": []
            },
            model=None,
            stream=False,
        )

    with pytest.raises(ValueError, match="Missing messages"):
        support.build_payload(
            source={"model": "test-model"},
            model=None,
            stream=False,
        )

    with pytest.raises(
            ValueError,
            match=
            r"Input JSON must be an object \(request\) or an array \(messages\)\.",
    ):
        support.build_payload(
            source="bad-input",
            model="test-model",
            stream=False,
        )


def test_infer_chat_support_stream_helpers_cover_edge_cases(
    capsys: Any, ) -> None:
    assert support._stream_choice_text({"delta": {"content": "po"}}) == "po"
    assert support._stream_choice_text({"message": {"content": "ng"}}) == "ng"
    assert support._stream_choice_text({"message": "not-a-dict"}) is None

    support.stream_sse(
        JSONResponse(lines=[
            "",
            ": keepalive",
            "event: ping",
            'data: {"choices":"bad-shape"}',
            'data: {"choices":["bad-choice", {"message":{"content":"pong"}}]}',
            "data: [DONE]",
        ]))

    assert capsys.readouterr().out == "pong"


def test_infer_chat_support_stream_sse_strips_leading_reasoning(
    capsys: Any, ) -> None:
    support.stream_sse(
        JSONResponse(lines=[
            'data: {"choices":[{"index":0,"delta":{"content":"<th"}}]}',
            'data: {"choices":[{"index":0,"delta":{"content":"ink>hidden"}}]}',
            'data: {"choices":[{"index":0,"delta":{"content":"</think>pong"}}]}',
            "data: [DONE]",
        ]))

    assert capsys.readouterr().out == "pong"


def test_infer_chat_uses_render_extractor_for_non_streaming_output(
    tmp_path: Path, ) -> None:
    import tensormesh_cli.commands.infer_cmd as infer

    ctx = _infer_test_ctx(tmp_path)
    resp = JSONResponse(payload={"choices": []}, text='{"choices":[]}')

    with patch(
            "tensormesh_cli.commands.infer_cmd._execute_chat_request",
            return_value=resp,
    ), patch(
            "tensormesh_cli.commands.infer_cmd.echo_http_response_with_text_extractor",
    ) as mock_echo:
        with ctx.scope():
            infer.chat_cmd.callback(
                surface="on-demand",
                model="test-model",
                user_id="00000000-0000-0000-0000-000000000000",
                api_key="gw_key",
                base_url=None,
                stream=False,
                stream_idle_timeout_s=300.0,
                json_arg='[{"role":"user","content":"hi"}]',
                file_path=None,
                timeout_s=None,
            )

    mock_echo.assert_called_once()
    assert mock_echo.call_args.kwargs["output"] == "text"
    assert mock_echo.call_args.kwargs["resp"] is resp
    transform_data = mock_echo.call_args.kwargs["transform_data"]
    assert mock_echo.call_args.kwargs["structured_outputs"] == (
        "json",
        "yaml",
        "table",
    )
    extract_text = mock_echo.call_args.kwargs["extract_text"]
    normalized = transform_data({
        "id":
        "cmpl_1",
        "object":
        "chat.completion",
        "created":
        1,
        "model":
        "m1",
        "choices": [{
            "index": 0,
            "message": {
                "role": "assistant",
                "content": "<think>hidden</think>ok",
            },
        }],
    })
    assert extract_text(None) is None
    assert extract_text({}) is None
    assert extract_text({"choices": []}) is None
    assert extract_text({"choices": ["bad-choice"]}) is None
    assert extract_text({"choices": [{"message": "bad-message"}]}) is None
    assert extract_text({"choices": [{"message": {"content": "   "}}]}) is None
    assert extract_text({"choices": [{"message": {"content": "ok"}}]}) == "ok"
    assert normalized["choices"][0]["message"] == {
        "role": "assistant",
        "content": "ok",
        "reasoning": "hidden",
    }
    assert extract_text(normalized) == "ok"


def test_infer_chat_rejects_payload_stream_without_stream_flag(
    tmp_path: Path, ) -> None:
    import tensormesh_cli.commands.infer_cmd as infer

    ctx = _infer_test_ctx(tmp_path, output="json")

    with patch(
            "tensormesh_cli.commands.infer_cmd.load_command_json_required",
            return_value={
                "model": "test-model",
                "stream": True,
                "messages": [{
                    "role": "user",
                    "content": "hi"
                }],
            },
    ):
        with ctx.scope():
            with pytest.raises(
                    click.UsageError,
                    match=
                    "Input JSON enables streaming. Re-run with `--stream` or remove `stream` from the JSON payload.",
            ):
                infer.chat_cmd.callback(
                    surface="on-demand",
                    model=None,
                    user_id=None,
                    api_key=None,
                    base_url=None,
                    stream=False,
                    stream_idle_timeout_s=300.0,
                    json_arg="unused",
                    file_path=None,
                    timeout_s=None,
                )


def test_infer_cmd_request_helpers_wrap_config_and_execution_failures(
    tmp_path: Path, ) -> None:
    import tensormesh_cli.commands.infer_cmd as infer

    ctx = _infer_test_ctx(tmp_path)
    config = infer.ResolvedInferChatConfig(
        surface="on-demand",
        base_url="https://gateway.example",
        api_key="gw_key",
        user_id="00000000-0000-0000-0000-000000000000",
        model="test-model",
        timeout_s=5.0,
        status_hints=infer._GATEWAY_STATUS_HINTS,
    )

    with patch(
            "tensormesh_cli.commands.infer_cmd.build_request_runtime",
            side_effect=RequestConfigError("bad CA bundle"),
    ):
        with pytest.raises(click.UsageError, match="bad CA bundle"):
            infer._execute_chat_request(
                ctx=ctx,
                config=config,
                payload={"messages": []},
            )

    with patch(
            "tensormesh_cli.commands.infer_cmd._build_inference_sdk_client",
            side_effect=click.UsageError("bad gateway config"),
    ):
        with pytest.raises(click.UsageError, match="bad gateway config"):
            infer._execute_chat_request(
                ctx=ctx,
                config=config,
                payload={"messages": []},
            )

    surface = _FakeInferenceSurface(
        request_error=RequestExecutionError("upstream timed out"))
    with patch(
            "tensormesh_cli.commands.infer_cmd._build_inference_sdk_client",
            return_value=(
                _FakeSDKClient(surface),
                _FakeTransport(buffered_response=JSONResponse(
                    payload={"choices": []}, text='{"choices":[]}')),
            ),
    ):
        with pytest.raises(click.ClickException, match="upstream timed out"):
            infer._execute_chat_request(
                ctx=ctx,
                config=config,
                payload={"messages": []},
            )


def test_infer_cmd_non_streaming_chat_uses_sdk_client(
    tmp_path: Path, ) -> None:
    import tensormesh_cli.commands.infer_cmd as infer

    ctx = _infer_test_ctx(tmp_path)
    config = infer.ResolvedInferChatConfig(
        surface="on-demand",
        base_url="https://gateway.example",
        api_key="gw_key",
        user_id="00000000-0000-0000-0000-000000000000",
        model="test-model",
        timeout_s=5.0,
        status_hints=infer._GATEWAY_STATUS_HINTS,
    )
    response = JSONResponse(payload={"choices": []}, text='{"choices":[]}')
    surface = _FakeInferenceSurface(request_result=response)

    with patch(
            "tensormesh_cli.commands.infer_cmd._build_inference_sdk_client",
            return_value=(
                _FakeSDKClient(surface),
                _FakeTransport(buffered_response=response),
            ),
    ):
        result = infer._execute_chat_request(
            ctx=ctx,
            config=config,
            payload={
                "model": "test-model",
                "messages": []
            },
        )

    assert result is response
    assert surface.request_calls == [{
        "method": "POST",
        "path": "/v1/chat/completions",
        "json_body": {
            "model": "test-model",
            "messages": [],
        },
        "timeout": 5.0,
    }]


def test_infer_cmd_resolve_config_handles_latest_and_invalid_timeout(
    tmp_path: Path, ) -> None:
    import tensormesh_cli.commands.infer_cmd as infer

    ctx = _infer_test_ctx(tmp_path)

    with patch(
            "tensormesh_cli.commands.infer_cmd.resolve_latest_gateway_model",
            return_value="latest-model",
    ):
        cfg = infer._resolve_infer_chat_config(
            ctx,
            surface="on-demand",
            model="@latest",
            user_id=None,
            api_key=None,
            base_url=None,
            timeout_s=None,
        )

    assert cfg.base_url == "https://gateway.example"
    assert cfg.api_key == "gw_key"
    assert cfg.user_id == "00000000-0000-0000-0000-000000000000"
    assert cfg.model == "latest-model"
    assert cfg.timeout_s == 9.0

    with pytest.raises(
            click.UsageError,
            match="Timeout must be greater than 0 seconds.",
    ):
        infer._resolve_infer_chat_config(
            ctx,
            surface="on-demand",
            model="configured-model",
            user_id=None,
            api_key=None,
            base_url=None,
            timeout_s=0,
        )

    serverless_cfg = infer._resolve_infer_chat_config(
        ctx,
        surface="serverless",
        model="MiniMaxAI/MiniMax-M2.5",
        user_id=None,
        api_key="serverless_key",
        base_url=None,
        timeout_s=None,
    )
    assert serverless_cfg.surface == "serverless"
    assert serverless_cfg.base_url == infer.DEFAULT_SERVERLESS_BASE
    assert serverless_cfg.user_id is None
    assert serverless_cfg.model == "MiniMaxAI/MiniMax-M2.5"

    with pytest.raises(
            click.UsageError,
            match=
            r"`--model @latest` is only supported for --surface on-demand.",
    ):
        infer._resolve_infer_chat_config(
            ctx,
            surface="serverless",
            model="@latest",
            user_id=None,
            api_key="serverless_key",
            base_url=None,
            timeout_s=None,
        )


def test_infer_cmd_request_helpers_surface_stream_and_request_failures(
    tmp_path: Path, ) -> None:
    import tensormesh_cli.commands.infer_cmd as infer

    ctx = _infer_test_ctx(tmp_path)
    config = infer.ResolvedInferChatConfig(
        surface="on-demand",
        base_url="https://gateway.example",
        api_key="gw_key",
        user_id="00000000-0000-0000-0000-000000000000",
        model="test-model",
        timeout_s=5.0,
        status_hints=infer._GATEWAY_STATUS_HINTS,
    )

    unauthorized_error = RequestExecutionError(
        "Request failed: HTTP 401 (request_id=req-123): {\"error\": \"bad token\"}\nHint: set --api-key, configure gateway_api_key, or run `tm init --sync`. Control plane tokens (`tm auth login`) do not authenticate the gateway."
    )

    with patch(
            "tensormesh_cli.commands.infer_cmd._build_inference_sdk_client",
            return_value=(
                _FakeSDKClient(
                    _FakeInferenceSurface(stream_error=unauthorized_error)),
                _FakeTransport(),
            ),
    ):
        with pytest.raises(click.ClickException, match="HTTP 401"):
            infer._execute_streaming_chat_request(
                ctx=ctx,
                config=config,
                payload={"messages": []},
                stream_idle_timeout_s=30.0,
            )

    with patch(
            "tensormesh_cli.commands.infer_cmd._build_inference_sdk_client",
            return_value=(
                _FakeSDKClient(
                    _FakeInferenceSurface(stream_error=RequestExecutionError(
                        "stream connection dropped"))),
                _FakeTransport(),
            ),
    ):
        with pytest.raises(click.ClickException,
                           match="stream connection dropped"):
            infer._execute_streaming_chat_request(
                ctx=ctx,
                config=config,
                payload={"messages": []},
                stream_idle_timeout_s=30.0,
            )

    with patch(
            "tensormesh_cli.commands.infer_cmd._build_inference_sdk_client",
            return_value=(
                _FakeSDKClient(
                    _FakeInferenceSurface(request_error=RequestExecutionError(
                        "chat request failed"))),
                _FakeTransport(),
            ),
    ):
        with pytest.raises(click.ClickException, match="chat request failed"):
            infer._execute_chat_request(
                ctx=ctx,
                config=config,
                payload={"messages": []},
            )

    with patch(
            "tensormesh_cli.commands.infer_cmd._build_inference_sdk_client",
            return_value=(
                _FakeSDKClient(
                    _FakeInferenceSurface(stream_error=unauthorized_error)),
                _FakeTransport(),
            ),
    ):
        with pytest.raises(click.ClickException) as exc_info:
            infer._execute_streaming_chat_request(
                ctx=ctx,
                config=config,
                payload={"messages": []},
                stream_idle_timeout_s=30.0,
            )

    message = str(exc_info.value)
    assert "request_id=req-123" in message
    assert "bad token" in message
    assert "Control plane tokens" in message


def test_infer_chat_stream_idle_timeout_is_forwarded(
    monkeypatch: Any,
    tmp_path: Path,
) -> None:
    import tensormesh_cli.commands.infer_cmd as infer

    ctx = _infer_test_ctx(tmp_path)
    config = infer.ResolvedInferChatConfig(
        surface="on-demand",
        base_url="https://gateway.example",
        api_key="gw_key",
        user_id="00000000-0000-0000-0000-000000000000",
        model="test-model",
        timeout_s=5.0,
        status_hints=infer._GATEWAY_STATUS_HINTS,
    )
    surface = _FakeInferenceSurface(stream_result=JSONResponse(lines=[]))

    monkeypatch.setattr(
        infer,
        "_build_inference_sdk_client",
        lambda ctx, config: (
            _FakeSDKClient(surface),
            _FakeTransport(),
        ),
    )
    monkeypatch.setattr(infer, "stream_sse", lambda resp: None)

    infer._execute_streaming_chat_request(
        ctx=ctx,
        config=config,
        payload={"messages": []},
        stream_idle_timeout_s=45.0,
    )

    assert surface.stream_calls == [{
        "method": "POST",
        "path": "/v1/chat/completions",
        "json_body": {
            "messages": [],
        },
        "headers": {
            "Accept": "text/event-stream",
        },
        "timeout": 5.0,
        "read_timeout": 45.0,
    }]
    assert surface.stream_result.closed is True


def test_infer_chat_streaming_closes_response_on_stream_error(
    monkeypatch: Any,
    tmp_path: Path,
) -> None:
    import tensormesh_cli.commands.infer_cmd as infer

    ctx = _infer_test_ctx(tmp_path)
    config = infer.ResolvedInferChatConfig(
        surface="on-demand",
        base_url="https://gateway.example",
        api_key="gw_key",
        user_id="00000000-0000-0000-0000-000000000000",
        model="test-model",
        timeout_s=5.0,
        status_hints=infer._GATEWAY_STATUS_HINTS,
    )
    response = JSONResponse(lines=[])
    surface = _FakeInferenceSurface(stream_result=response)

    monkeypatch.setattr(
        infer,
        "_build_inference_sdk_client",
        lambda ctx, config: (
            _FakeSDKClient(surface),
            _FakeTransport(),
        ),
    )

    def _raise_stream_error(resp: Any) -> None:
        raise click.ClickException("stream decode failed")

    monkeypatch.setattr(infer, "stream_sse", _raise_stream_error)

    with pytest.raises(click.ClickException, match="stream decode failed"):
        infer._execute_streaming_chat_request(
            ctx=ctx,
            config=config,
            payload={"messages": []},
            stream_idle_timeout_s=45.0,
        )

    assert response.closed is True
