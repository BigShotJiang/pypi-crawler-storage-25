from __future__ import annotations

from pathlib import Path

import pytest

from tensormesh_cli.config import resolve as resolve_module
from tensormesh_cli.config.load import flatten_resolved_config_file
from tensormesh_cli.config.load import load_config_file
from tensormesh_cli.config.resolve import resolve_config


def test_resolve_clean_helpers_cover_edge_cases(tmp_path: Path) -> None:
    assert resolve_module._clean_str(tmp_path / "cfg.toml") == str(tmp_path /
                                                                   "cfg.toml")
    assert resolve_module._clean_str(123) is None

    assert resolve_module._clean_int(None) is None
    assert resolve_module._clean_int(True) is None
    assert resolve_module._clean_int(7) == 7
    assert resolve_module._clean_int("  ") is None
    assert resolve_module._clean_int("bad") is None
    assert resolve_module._clean_int([]) is None

    assert resolve_module._clean_float(None) is None
    assert resolve_module._clean_float(True) is None
    assert resolve_module._clean_float(7) == 7.0
    assert resolve_module._clean_float("  ") is None
    assert resolve_module._clean_float("bad") is None
    assert resolve_module._clean_float({}) is None


def test_resolve_config_ignores_blank_env_values_and_uses_fallbacks(
        tmp_path: Path) -> None:
    cfg = resolve_config(
        cli={"config_path": str(tmp_path / "cfg.toml")},
        env={
            "TENSORMESH_TIMEOUT_SECONDS": "   ",
            "TENSORMESH_MAX_RETRIES": "   ",
        },
        defaults={
            "gateway_api_key": "defaults-token",
            "timeout_seconds": 9.5,
            "max_retries": 4,
        },
    )

    assert cfg.gateway_provider == resolve_module.DEFAULT_GATEWAY_PROVIDER
    assert cfg.gateway_base == "https://external.nebius.tensormesh.ai"
    assert cfg.gateway_api_key == "defaults-token"
    assert cfg.controlplane_auth_json == str(
        resolve_module.default_auth_json_path())
    assert cfg.timeout_seconds == 9.5
    assert cfg.max_retries == 4


@pytest.mark.parametrize("section_name", ["managed", "overrides"])
def test_flatten_resolved_config_file_rejects_empty_non_table_sections(
    section_name: str, ) -> None:
    with pytest.raises(
            RuntimeError,
            match=
            rf"Invalid config file: \[{section_name}\] must be a TOML table."):
        flatten_resolved_config_file({section_name: []})


def test_resolve_config_uses_tm_config_home_for_default_paths(
    monkeypatch,
    tmp_path: Path,
) -> None:
    config_home = tmp_path / "tm-state"
    monkeypatch.setenv("TM_CONFIG_HOME", str(config_home))

    cfg = resolve_config(cli={})

    assert cfg.config_path == str(config_home / "config.toml")
    assert cfg.controlplane_auth_json == str(config_home / "auth.json")
    assert cfg.sources.config_path == "built-in:config_path"
    assert cfg.sources.controlplane_auth_json == "built-in:controlplane_auth_json"


def test_resolve_config_flag_overrides_tm_config_home_default(
    monkeypatch,
    tmp_path: Path,
) -> None:
    monkeypatch.setenv("TM_CONFIG_HOME", str(tmp_path / "tm-state"))
    explicit_config = tmp_path / "custom.toml"

    cfg = resolve_config(cli={"config_path": str(explicit_config)})

    assert cfg.config_path == str(explicit_config)
    assert cfg.sources.config_path == "--config"


def test_resolve_config_rejects_invalid_scalar_types(tmp_path: Path) -> None:
    with pytest.raises(RuntimeError,
                       match="Invalid value for gateway_api_key"):
        resolve_config(
            cli={"config_path": str(tmp_path / "cfg.toml")},
            file_cfg={"gateway_api_key": 123},
        )

    with pytest.raises(RuntimeError,
                       match="Invalid value for gateway_provider"):
        resolve_config(
            cli={"config_path": str(tmp_path / "cfg.toml")},
            file_cfg={"gateway_provider": 1},
        )

    with pytest.raises(RuntimeError,
                       match="Invalid value for timeout_seconds"):
        resolve_config(cli={
            "config_path": str(tmp_path / "cfg.toml"),
            "timeout_seconds": True,
        }, )

    with pytest.raises(RuntimeError, match="Invalid value for max_retries"):
        resolve_config(cli={
            "config_path": str(tmp_path / "cfg.toml"),
            "max_retries": True,
        }, )


def test_resolve_config_precedence_flags_over_env_over_file_over_defaults(
        tmp_path: Path) -> None:
    cfg = resolve_config(
        cli={
            "config_path": str(tmp_path / "cfg.toml"),
            "gateway_provider": "yotta",
            "gateway_api_key": "flags_api_key",
            "gateway_user_id": "flags_user_id",
            "timeout_seconds": 5,
            "max_retries": 7,
        },
        env={
            "TENSORMESH_TIMEOUT_SECONDS": "15",
            "TENSORMESH_MAX_RETRIES": "2",
        },
        file_cfg={
            "gateway_provider": "yotta",
            "gateway_api_key": "file_api_key",
            "gateway_user_id": "file_user_id",
            "timeout_seconds": 25,
            "max_retries": 3,
        },
        defaults={
            "gateway_provider": "nebius",
            "gateway_api_key": "defaults_api_key",
            "gateway_user_id": "defaults_user_id",
            "timeout_seconds": 35,
            "max_retries": 4,
        },
    )

    assert cfg.controlplane_base == resolve_module.DEFAULT_CONTROLPLANE_BASE
    assert cfg.gateway_provider == "yotta"
    assert cfg.gateway_base == "https://external.yotta.tensormesh.ai"
    assert cfg.controlplane_auth_json == str(
        resolve_module.default_auth_json_path())
    assert cfg.gateway_api_key == "flags_api_key"
    assert cfg.gateway_user_id == "flags_user_id"
    assert cfg.timeout_seconds == 5.0
    assert cfg.max_retries == 7
    assert cfg.sources.controlplane_base == "built-in:controlplane_base"
    assert cfg.sources.gateway_provider == "--gateway-provider"
    assert cfg.sources.controlplane_auth_json == "built-in:controlplane_auth_json"
    assert cfg.sources.gateway_api_key == "--gateway-api-key"
    assert cfg.sources.gateway_user_id == "--gateway-user-id"
    assert cfg.sources.timeout_seconds == "--timeout-seconds"
    assert cfg.sources.max_retries == "--max-retries"
    assert cfg.sources.gateway_base == "derived-from:--gateway-provider"


def test_resolve_config_derives_gateway_base_from_gateway_provider(
        tmp_path: Path) -> None:
    cfg = resolve_config(
        cli={"config_path": str(tmp_path / "cfg.toml")},
        file_cfg={"gateway_provider": "lambda"},
    )

    assert cfg.gateway_provider == "lambda"
    assert cfg.gateway_base == "https://external.lambda.tensormesh.ai"


def test_resolve_config_rejects_control_plane_style_gateway_provider_alias(
        tmp_path: Path) -> None:
    with pytest.raises(RuntimeError,
                       match="Invalid value for gateway_provider"):
        resolve_config(
            cli={"config_path": str(tmp_path / "cfg.toml")},
            file_cfg={"gateway_provider": "CLOUD_PROVIDER_LAMBDA"},
        )


def test_resolve_config_rejects_invalid_gateway_provider(
        tmp_path: Path) -> None:
    with pytest.raises(RuntimeError,
                       match="Invalid value for gateway_provider"):
        resolve_config(
            cli={"config_path": str(tmp_path / "cfg.toml")},
            file_cfg={"gateway_provider": "unknown"},
        )


def test_resolve_config_prefers_controlplane_base_flag_over_env_over_file(
        tmp_path: Path) -> None:
    cfg = resolve_config(
        cli={
            "config_path": str(tmp_path / "cfg.toml"),
            "controlplane_base": "https://flags.control",
        },
        env={
            "TENSORMESH_CONTROL_PLANE_BASE_URL": "https://env.control",
        },
        file_cfg={
            "controlplane_base": "https://file.control",
        },
    )

    assert cfg.controlplane_base == "https://flags.control"
    assert cfg.sources.controlplane_base == "--controlplane-base"


def test_resolve_config_uses_controlplane_base_env_when_flag_missing(
        tmp_path: Path) -> None:
    cfg = resolve_config(
        cli={"config_path": str(tmp_path / "cfg.toml")},
        env={
            "TENSORMESH_CONTROL_PLANE_BASE_URL": "https://env.control/",
        },
        file_cfg={
            "controlplane_base": "https://file.control",
        },
    )

    assert cfg.controlplane_base == "https://env.control"
    assert cfg.sources.controlplane_base == "TENSORMESH_CONTROL_PLANE_BASE_URL"


def test_resolve_config_uses_controlplane_base_from_config_file(
        tmp_path: Path) -> None:
    cfg = resolve_config(
        cli={"config_path": str(tmp_path / "cfg.toml")},
        file_cfg={
            "controlplane_base": "https://file.control/",
        },
    )

    assert cfg.controlplane_base == "https://file.control"
    assert cfg.sources.controlplane_base == "config:controlplane_base"


def test_resolve_config_preserves_zero_numeric_overrides(
        tmp_path: Path) -> None:
    cfg = resolve_config(
        cli={
            "config_path": str(tmp_path / "cfg.toml"),
            "timeout_seconds": 5,
            "max_retries": 0,
        },
        env={
            "TENSORMESH_TIMEOUT_SECONDS": "15",
            "TENSORMESH_MAX_RETRIES": "5",
        },
        file_cfg={
            "timeout_seconds": 25,
            "max_retries": 3,
        },
        defaults={
            "timeout_seconds": 35,
            "max_retries": 4,
        },
    )

    assert cfg.timeout_seconds == 5.0
    assert cfg.max_retries == 0


def test_resolve_config_rejects_non_positive_timeout(tmp_path: Path) -> None:
    with pytest.raises(RuntimeError,
                       match="Timeout must be greater than 0 seconds."):
        resolve_config(cli={
            "config_path": str(tmp_path / "cfg.toml"),
            "timeout_seconds": 0,
        }, )


def test_resolve_config_rejects_invalid_timeout_env_value(
        tmp_path: Path) -> None:
    with pytest.raises(RuntimeError,
                       match="Invalid value for timeout_seconds"):
        resolve_config(
            cli={"config_path": str(tmp_path / "cfg.toml")},
            env={"TENSORMESH_TIMEOUT_SECONDS": "abc"},
        )


def test_resolve_config_rejects_invalid_max_retries_env_value(
        tmp_path: Path) -> None:
    with pytest.raises(RuntimeError, match="Invalid value for max_retries"):
        resolve_config(
            cli={"config_path": str(tmp_path / "cfg.toml")},
            env={"TENSORMESH_MAX_RETRIES": "abc"},
        )


def test_resolve_config_rejects_negative_max_retries(tmp_path: Path) -> None:
    with pytest.raises(
            RuntimeError,
            match="Max retries must be greater than or equal to 0."):
        resolve_config(cli={
            "config_path": str(tmp_path / "cfg.toml"),
            "max_retries": -1,
        }, )


def test_load_config_file_invalid_toml_raises_runtime_error(
        tmp_path: Path) -> None:
    config_path = tmp_path / "config.toml"
    config_path.write_text("profiles = [\n", encoding="utf-8")

    with pytest.raises(RuntimeError, match="Invalid config file \\(TOML\\)"):
        load_config_file(config_path)


def test_resolve_config_reports_config_and_built_in_sources(
        tmp_path: Path) -> None:
    cfg = resolve_config(
        cli={"config_path": str(tmp_path / "cfg.toml")},
        file_cfg={"gateway_api_key": "file_api_key"},
        defaults={},
    )

    assert cfg.sources.config_path == "--config"
    assert cfg.sources.controlplane_base == "built-in:controlplane_base"
    assert cfg.sources.controlplane_auth_json == "built-in:controlplane_auth_json"
    assert cfg.sources.gateway_provider == "built-in:gateway_provider"
    assert cfg.sources.gateway_base == "derived-from:built-in:gateway_provider"
    assert cfg.sources.gateway_api_key == "config:gateway_api_key"
    assert cfg.sources.gateway_user_id is None
    assert cfg.sources.gateway_model_id is None
    assert cfg.sources.ca_bundle is None


def test_resolve_config_uses_runtime_sources_when_provided(
        tmp_path: Path) -> None:
    cfg = resolve_config(
        cli={"config_path": str(tmp_path / "cfg.toml")},
        file_cfg={
            "gateway_provider": "yotta",
            "gateway_api_key": "runtime_api_key",
            "gateway_user_id": "00000000-0000-0000-0000-000000000000",
            "gateway_model_id": "runtime-model",
        },
        file_sources={
            "gateway_provider": "managed:gateway_provider",
            "gateway_api_key": "managed:gateway_api_key",
            "gateway_user_id": "managed:gateway_user_id",
            "gateway_model_id": "managed:gateway_model_id",
        },
    )

    assert cfg.gateway_provider == "yotta"
    assert cfg.sources.gateway_provider == "managed:gateway_provider"
    assert cfg.sources.gateway_base == "derived-from:managed:gateway_provider"
    assert cfg.sources.gateway_api_key == "managed:gateway_api_key"
    assert cfg.sources.gateway_user_id == "managed:gateway_user_id"
    assert cfg.sources.gateway_model_id == "managed:gateway_model_id"
