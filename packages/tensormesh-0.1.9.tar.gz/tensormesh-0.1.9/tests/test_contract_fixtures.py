from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from tensormesh_cli.cli import cli
from tests.cli_test_utils import controlplane_env
from tests.cli_test_utils import gateway_env
from tests.cli_test_utils import load_result_json
from tests.cli_test_utils import patch_gateway_provider_base
from tests.http_test_utils import json_response
from tests.http_test_utils import serve_controlplane_routes
from tests.response_test_utils import JSONResponse

FIXTURES_DIR = Path(__file__).resolve().parent / "fixtures"


def _fixture(name: str) -> Any:
    return json.loads((FIXTURES_DIR / name).read_text(encoding="utf-8"))


class _FakeInferenceSurface:

    def __init__(self, payload: Any) -> None:
        self._payload = payload
        self.request_calls: list[dict[str, Any]] = []

    def request(self, method: str, path: str, **kwargs: Any) -> JSONResponse:
        self.request_calls.append({
            "method": method,
            "path": path,
            **kwargs,
        })
        return JSONResponse(status_code=200, payload=self._payload)


class _FakeInferenceClient:

    def __init__(self, surface: _FakeInferenceSurface) -> None:
        self.on_demand = surface
        self.serverless = surface


class _FakeSDKClient:

    def __init__(self, surface: _FakeInferenceSurface) -> None:
        self.inference = _FakeInferenceClient(surface)


class _FakeTransport:

    def __init__(self, *, buffered_response: Any | None = None) -> None:
        self.last_buffered_response = buffered_response


def test_select_latest_controlplane_model_uses_recorded_inventory_fixture(
) -> None:
    from tensormesh_cli.commands.infer_latest import \
        select_latest_controlplane_model

    model_id = select_latest_controlplane_model(
        controlplane_data=_fixture("controlplane_models_inventory.json"))

    assert model_id == "Qwen/Qwen2.5-72B-Instruct"


def test_chat_latest_uses_recorded_contract_fixtures(
    monkeypatch: Any,
    runner,
) -> None:
    import tensormesh_cli.commands.infer_cmd as infer

    cp_payload = _fixture("controlplane_models_inventory.json")
    chat_payload = _fixture("gateway_chat_completion_openai.json")
    surface = _FakeInferenceSurface(chat_payload)

    monkeypatch.setattr(
        infer,
        "_build_inference_sdk_client",
        lambda ctx, config:
        (_FakeSDKClient(surface),
         _FakeTransport(buffered_response=JSONResponse(status_code=200,
                                                       payload=chat_payload))),
    )
    patch_gateway_provider_base(monkeypatch, base="https://gateway.example")
    with serve_controlplane_routes(
        {
            ("GET", "/v1/models"): json_response(cp_payload),
        },
            expected_auth="Bearer cp_tok"):
        result = runner.invoke(
            cli,
            [
                "--output",
                "json",
                "infer",
                "chat",
                "--model",
                "@latest",
                "--api-key",
                "gw_key",
                "--user-id",
                "00000000-0000-0000-0000-000000000000",
                "--json",
                '[{"role":"user","content":"ping"}]',
            ],
            env={
                **controlplane_env(access_token="cp_tok"),
                **gateway_env(api_key="gw_key", model_id="unused"),
            },
        )

    data = load_result_json(result)
    assert data["model"] == "Qwen/Qwen2.5-72B-Instruct"
    assert surface.request_calls[0]["path"] == "/v1/chat/completions"
    assert surface.request_calls[0]["json_body"][
        "model"] == "Qwen/Qwen2.5-72B-Instruct"


def test_models_list_table_renders_recorded_inventory_fixture(
        monkeypatch: Any, runner) -> None:
    payload = _fixture("controlplane_models_inventory.json")
    with serve_controlplane_routes(
        {
            ("GET", "/v1/models"): json_response(payload),
        },
            expected_auth="Bearer cp_tok"):
        result = runner.invoke(
            cli,
            [
                "--output",
                "table",
                "models",
                "list",
            ],
            env=controlplane_env(access_token="cp_tok"),
        )

    assert result.exit_code == 0, result.output
    assert "modelId" in result.output
    assert "modelName" in result.output
    assert "Qwen/Qwen2.5-72B-Instruct" in result.output
    assert "MODEL_STATUS_UP" in result.output
