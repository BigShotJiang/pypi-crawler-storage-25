from __future__ import annotations

from tests.cli_test_utils import controlplane_env
from tests.cli_test_utils import invoke_tm
from tests.http_test_utils import assert_last_request
from tests.http_test_utils import json_response
from tests.http_test_utils import serve_controlplane_routes


def _read_routes():
    return {
        ("GET", "/v1/models"):
        json_response({"models": []}),
        ("GET", "/v1/models/m_123"):
        json_response({"model": {
            "modelId": "m_123"
        }}),
        ("GET", "/v1/observability/deployments/d1/logs"):
        json_response({"logs": []}),
        ("GET", "/v1/observability/deployments/d2/metrics"):
        json_response({"metrics": []}),
        ("GET", "/v1/observability/users/metrics"):
        json_response({"metrics": []}),
    }


def test_models_list_sends_bearer_and_optional_user_id_query() -> None:
    with serve_controlplane_routes(_read_routes()) as recorder:
        result = invoke_tm(
            ["--output", "json", "models", "list", "--user-id", "u1"],
            env=controlplane_env(),
        )

    assert result.exit_code == 0, result.output
    request = assert_last_request(
        recorder,
        path="/v1/models",
        headers={"Authorization": "Bearer tok"},
    )
    assert request.query.get("userId") == ["u1"]


def test_models_get_sends_bearer_and_uses_model_id() -> None:
    with serve_controlplane_routes(_read_routes()) as recorder:
        result = invoke_tm(
            ["--output", "json", "models", "get", "m_123"],
            env=controlplane_env(),
        )

    assert result.exit_code == 0, result.output
    assert_last_request(
        recorder,
        path="/v1/models/m_123",
        headers={"Authorization": "Bearer tok"},
    )


def test_logs_endpoint_maps_desc_direction_to_backward() -> None:
    with serve_controlplane_routes(_read_routes()) as recorder:
        result = invoke_tm(
            [
                "--output", "json", "logs", "d1", "--limit", "10",
                "--direction", "desc"
            ],
            env=controlplane_env(),
        )

    assert result.exit_code == 0, result.output
    request = assert_last_request(
        recorder,
        path="/v1/observability/deployments/d1/logs",
    )
    assert request.query.get("direction") == ["LOG_DIRECTION_BACKWARD"]


def test_deployment_metrics_endpoint_uses_deployment_path() -> None:
    with serve_controlplane_routes(_read_routes()) as recorder:
        result = invoke_tm(
            [
                "--output", "json", "metrics", "deployment", "d2",
                "--step-seconds", "60"
            ],
            env=controlplane_env(),
        )

    assert result.exit_code == 0, result.output
    assert_last_request(
        recorder,
        path="/v1/observability/deployments/d2/metrics",
    )


def test_user_metrics_endpoint_uses_user_metrics_path() -> None:
    with serve_controlplane_routes(_read_routes()) as recorder:
        result = invoke_tm(
            ["--output", "json", "metrics", "user", "--step-seconds", "60"],
            env=controlplane_env(),
        )

    assert result.exit_code == 0, result.output
    assert_last_request(
        recorder,
        path="/v1/observability/users/metrics",
    )
