from __future__ import annotations

from pathlib import Path

from tests.cli_test_utils import controlplane_env
from tests.cli_test_utils import gateway_env
from tests.cli_test_utils import invoke_tm
from tests.readiness_test_utils import invoke_tm_json
from tests.readiness_test_utils import merge_env


def _infer_doctor_json(
    *,
    env: dict[str, str],
    output: str = "json",
    surface: str | None = None,
    extra_args: list[str] | None = None,
):
    args = ["--output", output, "infer", "doctor"]
    if surface is not None:
        args.extend(["--surface", surface])
    if extra_args:
        args.extend(extra_args)
    return invoke_tm_json(
        args,
        env=env,
    )


def test_infer_doctor_reports_gateway_readiness_json() -> None:
    _, data = _infer_doctor_json(env=gateway_env())
    assert data["surface"] == "on-demand"
    assert data["ready_for_direct_request"] is True
    assert data["gateway"]["api_key_source"] == "managed:gateway_api_key"
    assert data["gateway"]["user_id_valid"] is True


def test_infer_doctor_warns_for_invalid_gateway_user_id() -> None:
    _, data = _infer_doctor_json(env=gateway_env(user_id="not-a-uuid"))
    assert data["ready_for_direct_request"] is False
    assert any("Invalid gateway user id" in item for item in data["warnings"])


def test_infer_doctor_notes_latest_requires_control_plane_auth() -> None:
    _, data = _infer_doctor_json(env=gateway_env(),
                                 extra_args=["--model", "@latest"])
    assert data["latest_resolution"]["control_plane_token_present"] is False
    assert data["latest_resolution"]["requested"] is True
    assert data["ready_for_direct_request"] is False
    assert data["latest_resolution"]["validated_live"] is False
    assert any("`--model @latest` cannot be resolved yet" in item
               for item in data["warnings"])


def test_infer_doctor_does_not_warn_about_latest_when_not_requested() -> None:
    _, data = _infer_doctor_json(env=gateway_env())
    assert data["latest_resolution"]["requested"] is False
    assert all("`--model @latest` cannot be resolved yet" not in item
               for item in data["warnings"])


def test_infer_doctor_accepts_user_id_derived_from_controlplane() -> None:
    _, data = _infer_doctor_json(env=merge_env(
        controlplane_env(access_token="cp_tok"),
        gateway_env(api_key="gw_key", user_id=None, model_id="test_model"),
    ), )
    assert data["ready_for_direct_request"] is True
    assert data["gateway"]["user_id_ready"] is True
    assert data["gateway"]["user_id_derived_from_controlplane"] is True


def test_infer_doctor_does_not_claim_latest_is_ready_from_token_presence_alone(
) -> None:
    env = merge_env(
        controlplane_env(access_token="cp_tok"),
        gateway_env(
            home=controlplane_env(access_token="cp_tok")["HOME"],
            api_key="gw_key",
            user_id="00000000-0000-0000-0000-000000000000",
            model_id="unused",
        ),
    )
    _, data = _infer_doctor_json(env=env, extra_args=["--model", "@latest"])

    assert data["latest_resolution"]["control_plane_token_present"] is True
    assert data["latest_resolution"]["validated_live"] is False
    assert data["ready_for_direct_request"] is False
    assert any("`--model @latest` still requires a live request" in item
               for item in data["warnings"])
    assert any("--model @latest" in step for step in data["next_steps"])


def test_infer_doctor_raw_output_is_machine_readable() -> None:
    _, data = _infer_doctor_json(output="raw", env=gateway_env())
    assert data["ready_for_direct_request"] is True
    assert data["gateway"]["api_key_value"] == "***"


def test_infer_doctor_reports_serverless_readiness_json() -> None:
    _, data = _infer_doctor_json(
        env=gateway_env(),
        surface="serverless",
        extra_args=["--model", "MiniMaxAI/MiniMax-M2.5"],
    )
    assert data["surface"] == "serverless"
    assert data["ready_for_direct_request"] is True
    assert data["serverless"]["api_key_source"] == "managed:gateway_api_key"
    assert data["serverless"]["model_id_source"] == "option:--model"
    assert data["serverless"]["model_id_value"] == "MiniMaxAI/MiniMax-M2.5"
    assert data["serverless"][
        "model_requirement"] == "explicit --model required"
    assert any("--surface serverless" in step for step in data["next_steps"])


def test_infer_doctor_serverless_warns_when_api_key_missing() -> None:
    _, data = _infer_doctor_json(env=gateway_env(api_key=""),
                                 surface="serverless")
    assert data["ready_for_direct_request"] is False
    assert any("inference API key is not configured" in item
               for item in data["warnings"])
    assert any("serverless requests require --model" in item
               for item in data["warnings"])
    assert any("--api-key \"YOUR_INFERENCE_API_KEY\"" in step
               for step in data["next_steps"])


def test_infer_doctor_respects_on_demand_overrides() -> None:
    _, data = _infer_doctor_json(
        env=gateway_env(api_key="", user_id="", model_id=""),
        extra_args=[
            "--api-key",
            "override_key",
            "--user-id",
            "00000000-0000-0000-0000-000000000000",
            "--model",
            "override-model",
            "--base-url",
            "https://override.example.com",
        ],
    )
    assert data["ready_for_direct_request"] is True
    assert data["gateway"]["base"] == "https://override.example.com"
    assert data["gateway"]["base_source"] == "option:--base-url"
    assert data["gateway"]["api_key_source"] == "option:--api-key"
    assert data["gateway"]["user_id_source"] == "option:--user-id"
    assert data["gateway"]["model_id_source"] == "option:--model"
    assert data["gateway"]["model_id_value"] == "override-model"


def test_infer_doctor_respects_serverless_base_override() -> None:
    _, data = _infer_doctor_json(
        env=gateway_env(),
        surface="serverless",
        extra_args=[
            "--model",
            "MiniMaxAI/MiniMax-M2.5",
            "--base-url",
            "https://staging.serverless.example.com",
        ],
    )
    assert data["serverless"][
        "base"] == "https://staging.serverless.example.com"
    assert data["serverless"]["base_source"] == "option:--base-url"


def test_infer_doctor_human_output_surfaces_next_steps(
    isolated_home: Path, ) -> None:
    Path(".ignored-local-config").write_text(
        "IGNORED_LOCAL_KEY=from-local-file\n",
        encoding="utf-8",
    )
    result = invoke_tm(
        ["infer", "doctor"],
        env={"HOME": str(isolated_home)},
    )

    assert result.exit_code == 0, result.output
    assert "tm infer doctor" in result.output
    assert "Local readiness only." in result.output
    assert "Next steps:" in result.output
    assert "tm auth login" in result.output
    assert "tm init --sync" in result.output
    assert "tm infer chat --model \"YOUR_SERVED_GATEWAY_MODEL_NAME\"" in result.output


def test_infer_doctor_json_uses_plain_first_request_command(
    isolated_home: Path, ) -> None:
    _, data = _infer_doctor_json(env=gateway_env(home=isolated_home,
                                                 api_key="gw_key",
                                                 model_id="gw-model"), )
    assert data["ready_for_direct_request"] is True
    assert any(
        step.startswith("tm infer chat --json") for step in data["next_steps"])


def test_infer_doctor_exit_status_fails_when_gateway_not_ready() -> None:
    result = invoke_tm(
        [
            "infer",
            "doctor",
            "--exit-status",
        ],
        env=gateway_env(user_id="not-a-uuid"),
    )

    assert result.exit_code == 1, result.output
    assert "Invalid gateway user id" in result.output


def test_infer_doctor_exit_status_succeeds_when_gateway_ready() -> None:
    result = invoke_tm(
        [
            "infer",
            "doctor",
            "--exit-status",
        ],
        env=gateway_env(),
    )

    assert result.exit_code == 0, result.output


def test_infer_doctor_exit_status_fails_when_serverless_not_ready() -> None:
    result = invoke_tm(
        [
            "infer",
            "doctor",
            "--surface",
            "serverless",
            "--exit-status",
        ],
        env=gateway_env(api_key=""),
    )

    assert result.exit_code == 1, result.output
    assert "inference API key is not configured" in result.output
