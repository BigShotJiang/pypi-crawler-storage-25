from __future__ import annotations

import json
from pathlib import Path

from tests.script_test_utils import load_script_module

REPO_ROOT = Path(__file__).resolve().parents[1]
DOCS_JSON_SCRIPT_PATH = REPO_ROOT / "scripts" / "update-tensormesh-docs-json.py"


def _load_generated_spec(rel_path: str) -> dict:
    docs_json_mod = load_script_module(
        DOCS_JSON_SCRIPT_PATH,
        module_name="update_tensormesh_docs_json_shapes_test",
    )
    docs_json_mod.build_docs_json(
        REPO_ROOT,
        write_output=False,
        write_published_specs=True,
        write_docs_json=False,
    )
    path = REPO_ROOT / docs_json_mod.PUBLISHED_CONTROL_PLANE_SPECS_DIR / rel_path
    return json.loads(path.read_text(encoding="utf-8"))


def test_user_service_publishes_auth_profile_endpoint() -> None:
    spec = _load_generated_spec("user/v1/user_service.openapi.json")
    path = spec["paths"]["/auth/profile"]["get"]

    assert path["operationId"] == "UserService_GetAuthProfile"
    assert path["responses"]["200"]["content"]["application/json"]["schema"][
        "$ref"] == "#/components/schemas/v1GetUserProfileResponse"


def test_user_service_excludes_internal_api_key_introspection_endpoint(
) -> None:
    spec = _load_generated_spec("user/v1/user_service.openapi.json")

    assert "/internal/auth/api-keys/introspect" not in spec["paths"]


def test_billing_specs_publish_operation_descriptions_for_docs_pages() -> None:
    pricing = _load_generated_spec("billing/v1/pricing_service.openapi.json")
    product = _load_generated_spec("billing/v1/product_service.openapi.json")
    stripe = _load_generated_spec("billing/v1/stripe_service.openapi.json")

    for spec in (pricing, product):
        for methods in spec["paths"].values():
            for operation in methods.values():
                assert operation.get("description")

    assert stripe["paths"]["/v1/billing/stripe/customers"]["get"].get(
        "description")


def test_published_control_plane_specs_omit_servers() -> None:
    spec = _load_generated_spec("user/v1/user_service.openapi.json")

    assert "servers" not in spec
