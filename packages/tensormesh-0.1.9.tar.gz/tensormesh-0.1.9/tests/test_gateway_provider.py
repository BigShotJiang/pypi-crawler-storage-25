from __future__ import annotations

from tensormesh_cli.config.gateway_provider import gateway_base_for_provider
from tensormesh_cli.config.gateway_provider import \
    GATEWAY_PROVIDER_EXPECTED_TEXT
from tensormesh_cli.config.gateway_provider import normalize_gateway_provider


def test_gateway_provider_normalization_and_base_resolution() -> None:
    assert "nebius" in GATEWAY_PROVIDER_EXPECTED_TEXT
    assert normalize_gateway_provider(None) is None
    assert normalize_gateway_provider("   ") is None
    assert normalize_gateway_provider(" CLOUD_PROVIDER_LAMBDA ") is None
    assert normalize_gateway_provider("unknown") is None

    assert gateway_base_for_provider(None) is None
    assert gateway_base_for_provider("unknown") is None
    assert gateway_base_for_provider(
        "yotta") == "https://external.yotta.tensormesh.ai"
