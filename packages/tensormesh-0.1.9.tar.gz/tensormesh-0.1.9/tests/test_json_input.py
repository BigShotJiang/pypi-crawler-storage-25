from __future__ import annotations

from io import StringIO
from pathlib import Path

import pytest

from tensormesh_cli.http.json_input import load_json_optional
from tensormesh_cli.http.json_input import load_json_required


class _FakeStdin(StringIO):

    def __init__(self, value: str, *, is_tty: bool) -> None:
        super().__init__(value)
        self._is_tty = is_tty

    def isatty(self) -> bool:
        return self._is_tty


def test_load_json_optional_reads_inline_json() -> None:
    result = load_json_optional(
        json_arg='{"name":"ada"}',
        file_path=None,
        stdin=_FakeStdin("", is_tty=True),
    )

    assert result == {"name": "ada"}


def test_load_json_optional_reads_at_prefixed_file(tmp_path: Path) -> None:
    payload = tmp_path / "payload.json"
    payload.write_text('{"ok": true}\n', encoding="utf-8")

    result = load_json_optional(
        json_arg=f"@{payload}",
        file_path=None,
        stdin=_FakeStdin("", is_tty=True),
    )

    assert result == {"ok": True}


def test_load_json_optional_reads_file_path_argument(tmp_path: Path) -> None:
    payload = tmp_path / "payload.json"
    payload.write_text('{"count": 2}\n', encoding="utf-8")

    result = load_json_optional(
        json_arg=None,
        file_path=str(payload),
        stdin=_FakeStdin("", is_tty=True),
    )

    assert result == {"count": 2}


def test_load_json_optional_reads_piped_stdin_when_non_empty() -> None:
    result = load_json_optional(
        json_arg=None,
        file_path=None,
        stdin=_FakeStdin('{"source":"stdin"}\n', is_tty=False),
    )

    assert result == {"source": "stdin"}


def test_load_json_required_raises_when_no_input_is_provided() -> None:
    with pytest.raises(
            ValueError,
            match=
            "No input provided. Use --json, --file, or pipe JSON on stdin."):
        load_json_required(
            json_arg=None,
            file_path=None,
            stdin=_FakeStdin("", is_tty=True),
        )


def test_load_json_optional_preserves_at_file_read_error_prefix(
        tmp_path: Path) -> None:
    missing = tmp_path / "missing.json"

    with pytest.raises(ValueError,
                       match=r"Failed to read JSON file: .*missing\.json"):
        load_json_optional(
            json_arg=f"@{missing}",
            file_path=None,
            stdin=_FakeStdin("", is_tty=True),
        )


def test_load_json_optional_preserves_file_flag_read_error_prefix(
        tmp_path: Path) -> None:
    missing = tmp_path / "missing.json"

    with pytest.raises(ValueError,
                       match=r"Failed to read file: .*missing\.json"):
        load_json_optional(
            json_arg=None,
            file_path=str(missing),
            stdin=_FakeStdin("", is_tty=True),
        )
