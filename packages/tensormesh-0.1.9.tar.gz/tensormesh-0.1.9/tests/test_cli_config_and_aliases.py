from __future__ import annotations

from pathlib import Path

from tests.cli_test_utils import controlplane_env
from tests.cli_test_utils import invoke_tm
from tests.cli_test_utils import load_result_json


def test_config_init_uses_tm_config_home_for_default_path(
    isolated_home: Path, ) -> None:
    config_home = isolated_home / "tm-state"

    result = invoke_tm(
        ["config", "init"],
        env={
            "HOME": str(isolated_home),
            "TM_CONFIG_HOME": str(config_home),
        },
    )

    expected_path = config_home / "config.toml"
    assert result.exit_code == 0, result.output
    assert result.output == f"{expected_path}\n"
    assert expected_path.exists()
    assert not (isolated_home / ".config" / "tensormesh" /
                "config.toml").exists()


def test_auth_status_reads_token_from_tm_config_home(
    isolated_home: Path, ) -> None:
    config_home = isolated_home / "tm-state"
    config_home.mkdir(parents=True, exist_ok=True)
    (config_home / "auth.json").write_text(
        '{"access_token":"tok","refresh_token":"refresh"}\n',
        encoding="utf-8",
    )

    result = invoke_tm(
        ["--output", "json", "auth", "status"],
        env={
            "HOME": str(isolated_home),
            "TM_CONFIG_HOME": str(config_home),
        },
    )

    data = load_result_json(result)
    assert data["control_plane"]["access_token_present"] is True
    assert data["control_plane"]["auth_json_path"] == str(config_home /
                                                          "auth.json")


def test_auth_print_token_requires_ack_and_prints_raw_token() -> None:
    result = invoke_tm(["auth", "print-token"])
    assert result.exit_code != 0
    assert "--yes-i-know" in result.output

    token = "test_access_token"
    result = invoke_tm(
        ["auth", "print-token", "--yes-i-know"],
        env=controlplane_env(access_token=token),
    )
    assert result.exit_code == 0, result.output
    assert result.output == f"{token}\n"


def test_config_show_fails_fast_for_invalid_timeout_env_value() -> None:
    result = invoke_tm(
        ["--output", "json", "config", "show"],
        env={
            **controlplane_env(seed_file=False),
            "TENSORMESH_TIMEOUT_SECONDS":
            "abc",
        },
    )
    assert result.exit_code != 0
    assert "Invalid value for timeout_seconds" in result.output


def test_config_show_sources_reports_values_and_source_metadata(
    isolated_home: Path, ) -> None:
    Path("cfg.toml").write_text(
        '[managed]\n'
        'gateway_api_key = "gw_key"\n'
        'gateway_user_id = "00000000-0000-0000-0000-000000000000"\n',
        encoding="utf-8",
    )
    result = invoke_tm([
        "--output",
        "json",
        "--config",
        "cfg.toml",
        "config",
        "show",
        "--sources",
    ],
                       env={"HOME": str(isolated_home)})

    data = load_result_json(result)
    assert data["values"]["gateway_api_key"] == "***"
    assert data["values"][
        "gateway_user_id"] == "00000000-0000-0000-0000-000000000000"
    assert data["sources"]["gateway_api_key"] == "managed:gateway_api_key"
    assert data["sources"]["gateway_user_id"] == "managed:gateway_user_id"


def test_config_show_sources_reports_controlplane_base_env_source(
    isolated_home: Path, ) -> None:
    result = invoke_tm(
        ["--output", "json", "config", "show", "--sources"],
        env={
            "HOME": str(isolated_home),
            "TENSORMESH_CONTROL_PLANE_BASE_URL": "https://env.control/",
        },
    )

    data = load_result_json(result)
    assert data["values"]["controlplane_base"] == "https://env.control"
    assert data["sources"][
        "controlplane_base"] == "TENSORMESH_CONTROL_PLANE_BASE_URL"


def test_config_show_raw_output_is_json_for_structured_local_data(
    isolated_home: Path, ) -> None:
    Path("cfg.toml").write_text(
        '[managed]\ngateway_provider = "lambda"\n',
        encoding="utf-8",
    )
    result = invoke_tm(
        ["--output", "raw", "--config", "cfg.toml", "config", "show"],
        env={"HOME": str(isolated_home)},
    )

    data = load_result_json(result)
    assert data["gateway_provider"] == "lambda"
    assert data["gateway_base"] == "https://external.lambda.tensormesh.ai"
