from __future__ import annotations

import json
from pathlib import Path
from typing import Any
from unittest.mock import patch

from tests.cli_test_utils import controlplane_env
from tests.cli_test_utils import gateway_env
from tests.cli_test_utils import invoke_tm
from tests.cli_test_utils import patch_gateway_provider_base
from tests.http_test_utils import assert_last_request
from tests.http_test_utils import bytes_response
from tests.http_test_utils import RequestRecorder
from tests.http_test_utils import serve_http_server
from tests.infer_chat_test_utils import make_chat_completion_handler


def test_infer_chat_forms_request_headers_and_body(monkeypatch: Any) -> None:
    recorder = RequestRecorder()
    with serve_http_server(
            make_chat_completion_handler(recorder=recorder)) as base:
        patch_gateway_provider_base(monkeypatch, base=base)
        messages = [{"role": "user", "content": "hi"}]
        result = invoke_tm(
            [
                "infer",
                "chat",
                "--api-key",
                "test_key",
                "--user-id",
                "00000000-0000-0000-0000-000000000000",
                "--model",
                "test_model",
                "--json",
                json.dumps(messages),
            ],
            env=gateway_env(api_key="test_key", model_id=None),
        )

    assert result.exit_code == 0, result.output
    request = assert_last_request(
        recorder,
        path="/v1/chat/completions",
        headers={
            "Authorization": "Bearer test_key",
            "X-User-Id": "00000000-0000-0000-0000-000000000000",
            "Content-Type": "application/json",
        },
    )
    assert isinstance(request.body, dict)
    assert request.body["model"] == "test_model"
    assert request.body["messages"] == messages
    assert request.body.get("stream") is not True


def test_infer_chat_default_output_prints_assistant_message(
    monkeypatch: Any, ) -> None:
    with serve_http_server(make_chat_completion_handler()) as base:
        patch_gateway_provider_base(monkeypatch, base=base)
        result = invoke_tm(
            [
                "infer",
                "chat",
                "--api-key",
                "test_key",
                "--user-id",
                "00000000-0000-0000-0000-000000000000",
                "--model",
                "test_model",
                "--json",
                '[{"role":"user","content":"hi"}]',
            ],
            env=gateway_env(api_key="test_key", model_id=None),
        )

    assert result.exit_code == 0, result.output
    assert result.output == "ok\n"


def test_infer_chat_stream_prints_sse_content(monkeypatch: Any) -> None:
    recorder = RequestRecorder()
    with serve_http_server(
            make_chat_completion_handler(
                recorder=recorder,
                response_factory=lambda request: bytes_response(
                    b'data: {"choices":[{"delta":{"content":"po"}}]}\n\n'
                    b'data: {"choices":[{"delta":{"content":"ng"}}]}\n\n'
                    b"data: [DONE]\n\n",
                    headers={"Content-Type": "text/event-stream"},
                ),
            )) as base:
        patch_gateway_provider_base(monkeypatch, base=base)
        result = invoke_tm(
            [
                "infer",
                "chat",
                "--api-key",
                "test_key",
                "--user-id",
                "00000000-0000-0000-0000-000000000000",
                "--model",
                "test_model",
                "--stream",
                "--json",
                '[{"role":"user","content":"hi"}]',
            ],
            env=gateway_env(api_key="test_key", model_id=None),
        )

    assert result.exit_code == 0, result.output
    request = assert_last_request(
        recorder,
        path="/v1/chat/completions",
        headers={"Accept": "text/event-stream"},
    )
    assert isinstance(request.body, dict)
    assert request.body.get("stream") is True
    assert result.output == "pong\n"


def test_infer_chat_stream_rejects_non_text_output(monkeypatch: Any) -> None:
    with serve_http_server(make_chat_completion_handler()) as base:
        patch_gateway_provider_base(monkeypatch, base=base)
        result = invoke_tm(
            [
                "--output",
                "json",
                "infer",
                "chat",
                "--api-key",
                "test_key",
                "--user-id",
                "00000000-0000-0000-0000-000000000000",
                "--model",
                "test_model",
                "--stream",
                "--json",
                '[{"role":"user","content":"hi"}]',
            ],
            env=gateway_env(api_key="test_key", model_id="unused"),
        )

    assert result.exit_code != 0
    assert "`tm infer chat --stream` currently supports only `--output text`." in result.output


def test_infer_chat_table_output_uses_structured_response(
    monkeypatch: Any, ) -> None:
    with serve_http_server(make_chat_completion_handler()) as base:
        patch_gateway_provider_base(monkeypatch, base=base)
        result = invoke_tm(
            [
                "--output",
                "table",
                "infer",
                "chat",
                "--api-key",
                "test_key",
                "--user-id",
                "00000000-0000-0000-0000-000000000000",
                "--model",
                "test_model",
                "--json",
                '[{"role":"user","content":"hi"}]',
            ],
            env=gateway_env(api_key="test_key", model_id="unused"),
        )

    assert result.exit_code == 0, result.output
    assert "index" in result.output
    assert "message" in result.output
    assert "finish_reason" in result.output


def test_infer_chat_serverless_accepts_model_from_json_object(
    monkeypatch: Any, ) -> None:
    recorder = RequestRecorder()
    with serve_http_server(
            make_chat_completion_handler(recorder=recorder)) as base:
        patch_gateway_provider_base(monkeypatch, base=base)
        result = invoke_tm(
            [
                "infer",
                "chat",
                "--surface",
                "serverless",
                "--api-key",
                "test_key",
                "--base-url",
                base,
                "--json",
                '{"model":"serverless-model","messages":[{"role":"user","content":"hi"}]}',
            ],
            env=gateway_env(api_key="test_key", model_id="unused"),
        )

    assert result.exit_code == 0, result.output
    request = assert_last_request(
        recorder,
        path="/v1/chat/completions",
        headers={"Authorization": "Bearer test_key"},
    )
    assert isinstance(request.body, dict)
    assert request.body["model"] == "serverless-model"


def test_infer_chat_stream_rejects_non_positive_idle_timeout(
    monkeypatch: Any, ) -> None:
    with serve_http_server(make_chat_completion_handler()) as base:
        patch_gateway_provider_base(monkeypatch, base=base)
        result = invoke_tm(
            [
                "infer",
                "chat",
                "--api-key",
                "test_key",
                "--user-id",
                "00000000-0000-0000-0000-000000000000",
                "--model",
                "test_model",
                "--stream",
                "--stream-idle-timeout",
                "0",
                "--json",
                '[{"role":"user","content":"hi"}]',
            ],
            env=gateway_env(api_key="test_key", model_id="unused"),
        )

    assert result.exit_code != 0
    assert "`--stream-idle-timeout` must be a finite number greater than 0." in result.output


def test_infer_chat_stream_rejects_non_finite_idle_timeout(
    monkeypatch: Any, ) -> None:
    with serve_http_server(make_chat_completion_handler()) as base:
        patch_gateway_provider_base(monkeypatch, base=base)
        result = invoke_tm(
            [
                "infer",
                "chat",
                "--api-key",
                "test_key",
                "--user-id",
                "00000000-0000-0000-0000-000000000000",
                "--model",
                "test_model",
                "--stream",
                "--stream-idle-timeout",
                "nan",
                "--json",
                '[{"role":"user","content":"hi"}]',
            ],
            env=gateway_env(api_key="test_key", model_id="unused"),
        )

    assert result.exit_code != 0
    assert "`--stream-idle-timeout` must be a finite number greater than 0." in result.output


def test_infer_chat_requires_model_for_messages_array(
    monkeypatch: Any, ) -> None:
    with serve_http_server(make_chat_completion_handler()) as base:
        patch_gateway_provider_base(monkeypatch, base=base)
        result = invoke_tm(
            [
                "infer",
                "chat",
                "--api-key",
                "test_key",
                "--user-id",
                "00000000-0000-0000-0000-000000000000",
                "--json",
                '[{"role":"user","content":"hi"}]',
            ],
            env=gateway_env(api_key="test_key", model_id=None),
        )

    assert result.exit_code != 0
    assert "Missing --model" in result.output
    assert "Traceback" not in result.output


def test_infer_chat_rejects_missing_messages_in_request_object(
    monkeypatch: Any, ) -> None:
    with serve_http_server(make_chat_completion_handler()) as base:
        patch_gateway_provider_base(monkeypatch, base=base)
        result = invoke_tm(
            [
                "infer",
                "chat",
                "--api-key",
                "test_key",
                "--user-id",
                "00000000-0000-0000-0000-000000000000",
                "--json",
                '{"model":"test_model"}',
            ],
            env=gateway_env(api_key="test_key", model_id="unused"),
        )

    assert result.exit_code != 0
    assert "Missing messages" in result.output
    assert "Traceback" not in result.output


def test_infer_chat_rejects_invalid_top_level_json_shape(
    monkeypatch: Any, ) -> None:
    with serve_http_server(make_chat_completion_handler()) as base:
        patch_gateway_provider_base(monkeypatch, base=base)
        result = invoke_tm(
            [
                "infer",
                "chat",
                "--api-key",
                "test_key",
                "--user-id",
                "00000000-0000-0000-0000-000000000000",
                "--model",
                "test_model",
                "--json",
                '"bad-input"',
            ],
            env=gateway_env(api_key="test_key", model_id="unused"),
        )

    assert result.exit_code != 0
    assert "Input JSON must be an object" in result.output
    assert "Traceback" not in result.output


def test_infer_chat_stream_rejects_infinite_idle_timeout(
    monkeypatch: Any, ) -> None:
    with serve_http_server(make_chat_completion_handler()) as base:
        patch_gateway_provider_base(monkeypatch, base=base)
        result = invoke_tm(
            [
                "infer",
                "chat",
                "--api-key",
                "test_key",
                "--user-id",
                "00000000-0000-0000-0000-000000000000",
                "--model",
                "test_model",
                "--stream",
                "--stream-idle-timeout",
                "inf",
                "--json",
                '[{"role":"user","content":"hi"}]',
            ],
            env=gateway_env(api_key="test_key", model_id="unused"),
        )

    assert result.exit_code != 0
    assert "`--stream-idle-timeout` must be a finite number greater than 0." in result.output


def test_infer_chat_help_mentions_stdin_input() -> None:
    result = invoke_tm(["infer", "chat", "--help"])

    assert result.exit_code == 0, result.output
    normalized = " ".join(result.output.split())
    assert ("--json TEXT JSON payload or @file.json (object or messages "
            "array). When omitted, reads piped stdin if available."
            in normalized)


def test_infer_chat_stream_surfaces_stream_error_event(
    monkeypatch: Any, ) -> None:
    with serve_http_server(
            make_chat_completion_handler(
                response_factory=lambda request: bytes_response(
                    b'data: {"error":"upstream unavailable"}\n\n',
                    headers={"Content-Type": "text/event-stream"},
                ), )) as base:
        patch_gateway_provider_base(monkeypatch, base=base)
        result = invoke_tm(
            [
                "infer",
                "chat",
                "--api-key",
                "test_key",
                "--user-id",
                "00000000-0000-0000-0000-000000000000",
                "--model",
                "test_model",
                "--stream",
                "--json",
                '[{"role":"user","content":"hi"}]',
            ],
            env=gateway_env(api_key="test_key", model_id="unused"),
        )

    assert result.exit_code != 0
    assert "Stream error: upstream unavailable" in result.output


def test_infer_chat_stream_fails_for_malformed_sse_json(
    monkeypatch: Any, ) -> None:
    with serve_http_server(
            make_chat_completion_handler(
                response_factory=lambda request: bytes_response(
                    b"data: not-json\n\n",
                    headers={"Content-Type": "text/event-stream"},
                ), )) as base:
        patch_gateway_provider_base(monkeypatch, base=base)
        result = invoke_tm(
            [
                "infer",
                "chat",
                "--api-key",
                "test_key",
                "--user-id",
                "00000000-0000-0000-0000-000000000000",
                "--model",
                "test_model",
                "--stream",
                "--json",
                '[{"role":"user","content":"hi"}]',
            ],
            env=gateway_env(api_key="test_key", model_id="unused"),
        )

    assert result.exit_code != 0
    assert "Invalid stream event JSON: not-json" in result.output


def test_infer_chat_fails_for_malformed_json_response(
    monkeypatch: Any, ) -> None:
    with serve_http_server(
            make_chat_completion_handler(
                response_factory=lambda request: bytes_response(
                    b"not-json",
                    headers={"Content-Type": "text/plain"},
                ), )) as base:
        patch_gateway_provider_base(monkeypatch, base=base)
        result = invoke_tm(
            [
                "infer",
                "chat",
                "--api-key",
                "test_key",
                "--user-id",
                "00000000-0000-0000-0000-000000000000",
                "--model",
                "test_model",
                "--json",
                '[{"role":"user","content":"hi"}]',
            ],
            env=gateway_env(api_key="test_key", model_id="unused"),
        )

    assert result.exit_code != 0
    assert "Invalid JSON response: expected JSON." in result.output
    assert "Raw response: not-json" in result.output


def test_infer_chat_uses_gateway_model_id_from_resolved_config(
    monkeypatch: Any,
    tmp_path: Path,
) -> None:
    recorder = RequestRecorder()
    config_path = tmp_path / "config.toml"
    config_path.write_text(
        '[managed]\ngateway_model_id = "config_model"\n',
        encoding="utf-8",
    )

    with serve_http_server(
            make_chat_completion_handler(recorder=recorder)) as base:
        patch_gateway_provider_base(monkeypatch, base=base)
        messages = [{"role": "user", "content": "hi"}]
        result = invoke_tm(
            [
                "--config",
                str(config_path),
                "infer",
                "chat",
                "--api-key",
                "test_key",
                "--user-id",
                "00000000-0000-0000-0000-000000000000",
                "--json",
                json.dumps(messages),
            ],
            env=gateway_env(api_key="test_key", model_id=""),
        )

    assert result.exit_code == 0, result.output
    request = assert_last_request(recorder, path="/v1/chat/completions")
    assert isinstance(request.body, dict)
    assert request.body["model"] == "config_model"


def test_infer_chat_rejects_zero_timeout_from_config(
    monkeypatch: Any,
    tmp_path: Path,
) -> None:
    captured: dict[str, Any] = {"called": False}

    def fake_build_client(*args: Any, **kwargs: Any) -> None:
        captured["called"] = True
        return None

    import tensormesh_cli.commands.infer_cmd as infer

    monkeypatch.setattr(infer, "_build_inference_sdk_client",
                        fake_build_client)

    config_path = tmp_path / "config.toml"
    config_path.write_text("timeout_seconds = 0\n", encoding="utf-8")

    result = invoke_tm([
        "--config",
        str(config_path),
        "infer",
        "chat",
        "--model",
        "test_model",
        "--api-key",
        "test_key",
        "--user-id",
        "00000000-0000-0000-0000-000000000000",
        "--json",
        '[{"role":"user","content":"hi"}]',
    ], )

    assert result.exit_code != 0
    assert "Timeout must be greater than 0 seconds." in result.output
    assert captured["called"] is False


def test_infer_chat_rejects_invalid_gateway_user_id(monkeypatch: Any) -> None:
    captured: dict[str, Any] = {"called": False}

    def fake_build_client(*args: Any, **kwargs: Any) -> None:
        captured["called"] = True
        return None

    import tensormesh_cli.commands.infer_cmd as infer

    monkeypatch.setattr(infer, "_build_inference_sdk_client",
                        fake_build_client)

    result = invoke_tm([
        "--gateway-provider",
        "nebius",
        "infer",
        "chat",
        "--model",
        "test_model",
        "--api-key",
        "test_key",
        "--user-id",
        "not-a-uuid",
        "--json",
        '[{"role":"user","content":"hi"}]',
    ], )

    assert result.exit_code != 0
    assert "Invalid gateway user id" in result.output
    assert captured["called"] is False


def test_infer_chat_missing_api_key_mentions_controlplane_token() -> None:
    result = invoke_tm(
        [
            "infer",
            "chat",
            "--model",
            "test_model",
            "--user-id",
            "00000000-0000-0000-0000-000000000000",
            "--json",
            '[{"role":"user","content":"hi"}]',
        ],
        env={
            **gateway_env(api_key=""),
            **controlplane_env(access_token="cp_tok"),
        },
    )

    assert result.exit_code != 0
    assert "Missing gateway API key" in result.output
    assert "you appear logged into the control plane" in result.output


def test_infer_cmd_resolves_user_id_from_controlplane_when_missing(
    tmp_path: Path, ) -> None:
    import tensormesh_cli.commands.infer_cmd as infer
    from tests.infer_chat_test_utils import _infer_test_ctx

    ctx = _infer_test_ctx(tmp_path, gateway_user_id=None)

    with patch(
            "tensormesh_cli.commands.infer_cmd.has_controlplane_access_token",
            return_value=True,
    ), patch(
            "tensormesh_cli.commands.infer_cmd.resolve_gateway_user_id_from_controlplane",
            return_value="60b01a41-c8a4-4234-80a5-ef18309b560c",
    ) as mock_resolve:
        cfg = infer._resolve_infer_chat_config(
            ctx,
            surface="on-demand",
            model="test_model",
            user_id=None,
            api_key="gw_key",
            base_url=None,
            timeout_s=None,
        )

    assert cfg.user_id == "60b01a41-c8a4-4234-80a5-ef18309b560c"
    mock_resolve.assert_called_once()


def test_infer_chat_missing_user_id_suggests_login_when_not_available(
) -> None:
    result = invoke_tm(
        [
            "infer",
            "chat",
            "--model",
            "test_model",
            "--api-key",
            "gw_key",
            "--json",
            '[{"role":"user","content":"hi"}]',
        ],
        env=gateway_env(user_id=""),
    )

    assert result.exit_code != 0
    assert "Missing gateway user id" in result.output
    assert "run `tm auth login`" in result.output


def test_infer_serverless_chat_forms_request_headers_and_body() -> None:
    recorder = RequestRecorder()
    with serve_http_server(
            make_chat_completion_handler(recorder=recorder)) as base:
        messages = [{"role": "user", "content": "hi"}]
        result = invoke_tm(
            [
                "infer",
                "chat",
                "--surface",
                "serverless",
                "--base-url",
                base,
                "--api-key",
                "test_key",
                "--model",
                "MiniMaxAI/MiniMax-M2.5",
                "--json",
                json.dumps(messages),
            ],
            env=gateway_env(api_key="test_key", model_id="unused"),
        )

    assert result.exit_code == 0, result.output
    request = assert_last_request(
        recorder,
        path="/v1/chat/completions",
        headers={
            "Authorization": "Bearer test_key",
            "Content-Type": "application/json",
        },
    )
    assert "X-User-Id" not in request.headers
    assert isinstance(request.body, dict)
    assert request.body["model"] == "MiniMaxAI/MiniMax-M2.5"
    assert request.body["messages"] == messages
    assert request.body.get("stream") is not True


def test_infer_serverless_chat_stream_prints_sse_content() -> None:
    recorder = RequestRecorder()
    with serve_http_server(
            make_chat_completion_handler(
                recorder=recorder,
                response_factory=lambda request: bytes_response(
                    b'data: {"choices":[{"delta":{"content":"po"}}]}\n\n'
                    b'data: {"choices":[{"delta":{"content":"ng"}}]}\n\n'
                    b"data: [DONE]\n\n",
                    headers={"Content-Type": "text/event-stream"},
                ),
            )) as base:
        result = invoke_tm(
            [
                "infer",
                "chat",
                "--surface",
                "serverless",
                "--base-url",
                base,
                "--api-key",
                "test_key",
                "--model",
                "MiniMaxAI/MiniMax-M2.5",
                "--stream",
                "--json",
                '[{"role":"user","content":"hi"}]',
            ],
            env=gateway_env(api_key="test_key", model_id="unused"),
        )

    assert result.exit_code == 0, result.output
    request = assert_last_request(
        recorder,
        path="/v1/chat/completions",
        headers={"Accept": "text/event-stream"},
    )
    assert "X-User-Id" not in request.headers
    assert isinstance(request.body, dict)
    assert request.body.get("stream") is True
    assert result.output == "pong\n"


def test_infer_serverless_chat_uses_managed_api_key_when_not_overridden(
) -> None:
    recorder = RequestRecorder()
    with serve_http_server(
            make_chat_completion_handler(
                recorder=recorder,
                expected_auth="Bearer managed_key",
            )) as base:
        result = invoke_tm(
            [
                "infer",
                "chat",
                "--surface",
                "serverless",
                "--base-url",
                base,
                "--model",
                "MiniMaxAI/MiniMax-M2.5",
                "--json",
                '[{"role":"user","content":"hi"}]',
            ],
            env=gateway_env(api_key="managed_key", model_id="unused"),
        )

    assert result.exit_code == 0, result.output
    request = assert_last_request(
        recorder,
        path="/v1/chat/completions",
        headers={"Authorization": "Bearer managed_key"},
    )
    assert "X-User-Id" not in request.headers


def test_infer_serverless_chat_missing_api_key_mentions_controlplane_token(
) -> None:
    result = invoke_tm(
        [
            "infer",
            "chat",
            "--surface",
            "serverless",
            "--model",
            "MiniMaxAI/MiniMax-M2.5",
            "--json",
            '[{"role":"user","content":"hi"}]',
        ],
        env={
            **gateway_env(api_key=""),
            **controlplane_env(access_token="cp_tok"),
        },
    )

    assert result.exit_code != 0
    assert "Missing serverless API key" in result.output
    assert "you appear logged into the control plane" in result.output


def test_infer_serverless_chat_missing_model_mentions_model_name() -> None:
    result = invoke_tm(
        [
            "infer",
            "chat",
            "--surface",
            "serverless",
            "--api-key",
            "test_key",
            "--json",
            '[{"role":"user","content":"hi"}]',
        ],
        env=gateway_env(api_key="test_key", model_id="unused"),
    )

    assert result.exit_code != 0
    assert "Missing serverless model name" in result.output


def test_infer_serverless_chat_rejects_user_id_override() -> None:
    result = invoke_tm(
        [
            "infer",
            "chat",
            "--surface",
            "serverless",
            "--user-id",
            "00000000-0000-0000-0000-000000000000",
            "--model",
            "MiniMaxAI/MiniMax-M2.5",
            "--api-key",
            "test_key",
            "--json",
            '[{"role":"user","content":"hi"}]',
        ],
        env=gateway_env(api_key="test_key", model_id="unused"),
    )

    assert result.exit_code != 0
    assert "--user-id is only used for --surface on-demand" in result.output
