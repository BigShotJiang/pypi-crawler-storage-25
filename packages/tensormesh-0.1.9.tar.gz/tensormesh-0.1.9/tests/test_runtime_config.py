from __future__ import annotations

from pathlib import Path
import tomllib
from unittest.mock import patch

import click
import pytest

from tensormesh.types import ApiKey
from tensormesh.types import Model
from tensormesh_cli.app_context import build_app_context
from tensormesh_cli.config.model import ResolvedConfig
from tensormesh_cli.config.model import ResolvedConfigSources
from tensormesh_cli.config.runtime import sync_runtime_gateway_config


def _runtime_test_ctx(
    tmp_path: Path,
    *,
    controlplane_base: str = "https://api.tensormesh.ai",
    controlplane_base_source: str = "built-in:controlplane_base",
) -> click.Context:
    cfg = ResolvedConfig(
        config_path=str(tmp_path / "config.toml"),
        controlplane_base=controlplane_base,
        controlplane_auth_json=str(tmp_path / ".config" / "tensormesh" /
                                   "auth.json"),
        gateway_provider="nebius",
        gateway_base="https://external.nebius.tensormesh.ai",
        gateway_api_key=None,
        gateway_user_id=None,
        gateway_model_id=None,
        ca_bundle=None,
        timeout_seconds=9.0,
        max_retries=2,
        sources=ResolvedConfigSources(
            config_path="--config",
            controlplane_base=controlplane_base_source,
            controlplane_auth_json="built-in:controlplane_auth_json",
            gateway_provider="built-in:gateway_provider",
            gateway_base="derived-from:built-in:gateway_provider",
            gateway_api_key=None,
            gateway_user_id=None,
            gateway_model_id=None,
            ca_bundle=None,
            timeout_seconds="built-in:timeout_seconds",
            max_retries="built-in:max_retries",
        ),
    )
    app = build_app_context(
        env={},
        resolved_config=cfg,
        output="json",
        quiet=False,
        debug=False,
    )
    return click.Context(click.Command("runtime-test"), obj=app)


def test_sync_runtime_gateway_config_selects_latest_syncable_model(
    tmp_path: Path,
    monkeypatch,
) -> None:
    ctx = _runtime_test_ctx(tmp_path)
    monkeypatch.setenv("HOME", str(tmp_path))

    models = [
        Model.from_dict({
            "modelName": "new-unsyncable",
            "status": "MODEL_STATUS_UP",
            "updatedAt": "2024-03-01T00:00:00Z",
            "infra": {
                "cloudProvider": "CLOUD_PROVIDER_NEBIUS"
            },
        }),
        Model.from_dict({
            "modelName": "older-syncable",
            "status": "MODEL_STATUS_UP",
            "updatedAt": "2024-02-01T00:00:00Z",
            "infra": {
                "cloudProvider": "CLOUD_PROVIDER_LAMBDA"
            },
            "apiKey": "gw_key_syncable",
        }),
    ]

    with patch(
            "tensormesh_cli.config.runtime.execute_controlplane_sdk",
            return_value=(models, None),
    ), patch(
            "tensormesh_cli.config.runtime.resolve_gateway_user_id_from_controlplane",
            return_value="60b01a41-c8a4-4234-80a5-ef18309b560c"):
        synced = sync_runtime_gateway_config(ctx, timeout_s=4.0)

    assert synced.config_path == str(tmp_path / "config.toml")
    assert synced.gateway_provider == "lambda"
    assert synced.gateway_api_key == "gw_key_syncable"
    assert synced.gateway_model_id == "older-syncable"
    assert synced.gateway_user_id == "60b01a41-c8a4-4234-80a5-ef18309b560c"

    config_data = tomllib.loads(
        Path(synced.config_path).read_text(encoding="utf-8"))
    managed = config_data["managed"]
    assert managed["gateway_provider"] == "lambda"
    assert managed["gateway_api_key"] == "gw_key_syncable"
    assert managed["gateway_model_id"] == "older-syncable"


def test_sync_runtime_gateway_config_writes_valid_toml_for_escaped_values(
    tmp_path: Path,
    monkeypatch,
) -> None:
    ctx = _runtime_test_ctx(tmp_path)
    monkeypatch.setenv("HOME", str(tmp_path))

    models = [
        Model.from_dict({
            "modelName": 'model "quoted"\\name',
            "status": "MODEL_STATUS_UP",
            "updatedAt": "2024-02-01T00:00:00Z",
            "infra": {
                "cloudProvider": "CLOUD_PROVIDER_YOTTA"
            },
            "apiKey": 'gw_"quoted"\nline',
        }),
    ]

    with patch(
            "tensormesh_cli.config.runtime.execute_controlplane_sdk",
            return_value=(models, None),
    ), patch(
            "tensormesh_cli.config.runtime.resolve_gateway_user_id_from_controlplane",
            return_value="60b01a41-c8a4-4234-80a5-ef18309b560c"):
        synced = sync_runtime_gateway_config(ctx, timeout_s=4.0)

    config_data = tomllib.loads(
        Path(synced.config_path).read_text(encoding="utf-8"))
    managed = config_data["managed"]
    assert managed["gateway_provider"] == "yotta"
    assert managed["gateway_api_key"] == 'gw_"quoted"\nline'
    assert managed["gateway_model_id"] == 'model "quoted"\\name'
    assert Path(synced.config_path).stat().st_mode & 0o777 == 0o600


def test_sync_runtime_gateway_config_preserves_unrelated_top_level_tables(
    tmp_path: Path,
    monkeypatch,
) -> None:
    ctx = _runtime_test_ctx(tmp_path)
    monkeypatch.setenv("HOME", str(tmp_path))
    config_path = tmp_path / "config.toml"
    config_path.write_text(
        'timeout_seconds = 11\n'
        '\n'
        '[custom]\n'
        'enabled = true\n'
        'hosts = ["a", "b"]\n'
        '\n'
        '[custom.nested]\n'
        'region = "sg"\n',
        encoding="utf-8",
    )

    models = [
        Model.from_dict({
            "modelName": "synced-model",
            "status": "MODEL_STATUS_UP",
            "updatedAt": "2024-03-01T00:00:00Z",
            "infra": {
                "cloudProvider": "CLOUD_PROVIDER_NEBIUS"
            },
            "apiKey": "gw_key_syncable",
        }),
    ]

    with patch(
            "tensormesh_cli.config.runtime.execute_controlplane_sdk",
            return_value=(models, None),
    ), patch(
            "tensormesh_cli.config.runtime.resolve_gateway_user_id_from_controlplane",
            return_value="60b01a41-c8a4-4234-80a5-ef18309b560c"):
        synced = sync_runtime_gateway_config(ctx, timeout_s=4.0)

    config_data = tomllib.loads(
        Path(synced.config_path).read_text(encoding="utf-8"))
    assert config_data["timeout_seconds"] == 11
    assert config_data["custom"]["enabled"] is True
    assert config_data["custom"]["hosts"] == ["a", "b"]
    assert config_data["custom"]["nested"]["region"] == "sg"
    assert config_data["managed"]["gateway_provider"] == "nebius"


def test_sync_runtime_gateway_config_persists_explicit_controlplane_base(
    tmp_path: Path,
    monkeypatch,
) -> None:
    ctx = _runtime_test_ctx(
        tmp_path,
        controlplane_base="https://api.gcpdev.tensormesh.ai",
        controlplane_base_source="--controlplane-base",
    )
    monkeypatch.setenv("HOME", str(tmp_path))

    models = [
        Model.from_dict({
            "modelName": "synced-model",
            "status": "MODEL_STATUS_UP",
            "updatedAt": "2024-03-01T00:00:00Z",
            "infra": {
                "cloudProvider": "CLOUD_PROVIDER_NEBIUS"
            },
            "apiKey": "gw_key_syncable",
        }),
    ]

    with patch(
            "tensormesh_cli.config.runtime.execute_controlplane_sdk",
            return_value=(models, None),
    ), patch(
            "tensormesh_cli.config.runtime.resolve_gateway_user_id_from_controlplane",
            return_value="60b01a41-c8a4-4234-80a5-ef18309b560c"):
        synced = sync_runtime_gateway_config(ctx, timeout_s=4.0)

    config_data = tomllib.loads(
        Path(synced.config_path).read_text(encoding="utf-8"))
    assert config_data[
        "controlplane_base"] == "https://api.gcpdev.tensormesh.ai"
    assert config_data["managed"]["gateway_model_id"] == "synced-model"


def test_sync_runtime_gateway_config_does_not_persist_env_controlplane_base(
    tmp_path: Path,
    monkeypatch,
) -> None:
    ctx = _runtime_test_ctx(
        tmp_path,
        controlplane_base="https://api.gcpdev.tensormesh.ai",
        controlplane_base_source="TENSORMESH_CONTROL_PLANE_BASE_URL",
    )
    monkeypatch.setenv("HOME", str(tmp_path))

    models = [
        Model.from_dict({
            "modelName": "synced-model",
            "status": "MODEL_STATUS_UP",
            "updatedAt": "2024-03-01T00:00:00Z",
            "infra": {
                "cloudProvider": "CLOUD_PROVIDER_NEBIUS"
            },
            "apiKey": "gw_key_syncable",
        }),
    ]

    with patch(
            "tensormesh_cli.config.runtime.execute_controlplane_sdk",
            return_value=(models, None),
    ), patch(
            "tensormesh_cli.config.runtime.resolve_gateway_user_id_from_controlplane",
            return_value="60b01a41-c8a4-4234-80a5-ef18309b560c"):
        synced = sync_runtime_gateway_config(ctx, timeout_s=4.0)

    config_data = tomllib.loads(
        Path(synced.config_path).read_text(encoding="utf-8"))
    assert "controlplane_base" not in config_data
    assert config_data["managed"]["gateway_model_id"] == "synced-model"


def test_sync_runtime_gateway_config_falls_back_to_user_api_key_without_model(
    tmp_path: Path,
    monkeypatch,
) -> None:
    ctx = _runtime_test_ctx(tmp_path)
    monkeypatch.setenv("HOME", str(tmp_path))

    api_keys = [
        ApiKey(
            id="ak-old",
            name="older",
            created_at="2024-02-01T00:00:00Z",
        ),
        ApiKey(
            id="ak-new",
            name="newer",
            created_at="2024-03-01T00:00:00Z",
        ),
    ]

    def fake_execute_controlplane_sdk(_ctx, callback):

        class _UsersApiKeys:

            def list(self, **kwargs):
                return api_keys

        class _Users:
            api_keys = _UsersApiKeys()

        class _Models:

            def list(self, **kwargs):
                return []

        class _ControlPlane:
            models = _Models()
            users = _Users()

        class _Client:
            control_plane = _ControlPlane()

        return callback(_Client()), None

    with patch(
            "tensormesh_cli.config.runtime.execute_controlplane_sdk",
            side_effect=fake_execute_controlplane_sdk,
    ), patch(
            "tensormesh_cli.config.runtime.resolve_gateway_user_id_from_controlplane",
            return_value="60b01a41-c8a4-4234-80a5-ef18309b560c",
    ):
        synced = sync_runtime_gateway_config(ctx, timeout_s=4.0)

    assert synced.gateway_provider is None
    assert synced.gateway_api_key == "ak-new"
    assert synced.gateway_model_id is None
    assert synced.gateway_user_id == "60b01a41-c8a4-4234-80a5-ef18309b560c"

    config_data = tomllib.loads(
        Path(synced.config_path).read_text(encoding="utf-8"))
    managed = config_data["managed"]
    assert managed["gateway_api_key"] == "ak-new"
    assert managed["gateway_user_id"] == "60b01a41-c8a4-4234-80a5-ef18309b560c"
    assert "gateway_provider" not in managed
    assert "gateway_model_id" not in managed


def test_sync_runtime_gateway_config_clears_stale_model_when_only_init_models_exist(
    tmp_path: Path,
    monkeypatch,
) -> None:
    ctx = _runtime_test_ctx(tmp_path)
    monkeypatch.setenv("HOME", str(tmp_path))

    config_path = tmp_path / "config.toml"
    config_path.write_text(
        'controlplane_base = "https://api.tensormesh.ai"\n'
        '\n'
        '[managed]\n'
        'synced_at = "2024-02-01T00:00:00Z"\n'
        'gateway_provider = "nebius"\n'
        'gateway_api_key = "stale_key"\n'
        'gateway_user_id = "60b01a41-c8a4-4234-80a5-ef18309b560c"\n'
        'gateway_model_id = "stale-model"\n'
        '\n'
        '[overrides]\n',
        encoding="utf-8",
    )

    models = [
        Model.from_dict({
            "modelName": "init-model",
            "status": "MODEL_STATUS_INIT",
            "updatedAt": "2024-03-01T00:00:00Z",
            "infra": {
                "cloudProvider": "CLOUD_PROVIDER_NEBIUS"
            },
            "apiKey": "model_api_key",
        }),
    ]
    api_keys = [
        ApiKey(
            id="ak-new",
            name="newer",
            created_at="2024-03-01T00:00:00Z",
        ),
    ]

    def fake_execute_controlplane_sdk(_ctx, callback):

        class _UsersApiKeys:

            def list(self, **kwargs):
                return api_keys

        class _Users:
            api_keys = _UsersApiKeys()

        class _Models:

            def list(self, **kwargs):
                return models

        class _ControlPlane:
            models = _Models()
            users = _Users()

        class _Client:
            control_plane = _ControlPlane()

        return callback(_Client()), None

    with patch(
            "tensormesh_cli.config.runtime.execute_controlplane_sdk",
            side_effect=fake_execute_controlplane_sdk,
    ), patch(
            "tensormesh_cli.config.runtime.resolve_gateway_user_id_from_controlplane",
            return_value="60b01a41-c8a4-4234-80a5-ef18309b560c",
    ):
        synced = sync_runtime_gateway_config(ctx, timeout_s=4.0)

    assert synced.gateway_model_id is None
    assert synced.gateway_api_key == "ak-new"

    config_data = tomllib.loads(config_path.read_text(encoding="utf-8"))
    managed = config_data["managed"]
    assert managed["gateway_api_key"] == "ak-new"
    assert managed["gateway_user_id"] == "60b01a41-c8a4-4234-80a5-ef18309b560c"
    assert "gateway_model_id" not in managed


def test_sync_runtime_gateway_config_errors_when_no_model_and_no_active_api_key(
    tmp_path: Path,
    monkeypatch,
) -> None:
    ctx = _runtime_test_ctx(tmp_path)
    monkeypatch.setenv("HOME", str(tmp_path))

    api_keys = [
        ApiKey(
            id="ak-deleted",
            deleted_at="2024-03-01T00:00:00Z",
        ),
        ApiKey(
            id="ak-expired",
            expires_at="2024-01-01T00:00:00Z",
        ),
    ]

    def fake_execute_controlplane_sdk(_ctx, callback):

        class _UsersApiKeys:

            def list(self, **kwargs):
                return api_keys

        class _Users:
            api_keys = _UsersApiKeys()

        class _Models:

            def list(self, **kwargs):
                return []

        class _ControlPlane:
            models = _Models()
            users = _Users()

        class _Client:
            control_plane = _ControlPlane()

        return callback(_Client()), None

    with patch(
            "tensormesh_cli.config.runtime.execute_controlplane_sdk",
            side_effect=fake_execute_controlplane_sdk,
    ), patch(
            "tensormesh_cli.config.runtime.resolve_gateway_user_id_from_controlplane",
            return_value="60b01a41-c8a4-4234-80a5-ef18309b560c",
    ), pytest.raises(
            click.ClickException,
            match="no active user API keys found in control plane inventory",
    ):
        sync_runtime_gateway_config(ctx, timeout_s=4.0)
