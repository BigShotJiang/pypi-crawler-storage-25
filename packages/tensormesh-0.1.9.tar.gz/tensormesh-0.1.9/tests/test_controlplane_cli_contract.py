from __future__ import annotations

import json
from pathlib import Path
import re

from tests.script_test_utils import load_script_module

REPO_ROOT = Path(__file__).resolve().parents[1]
SCRIPT_PATH = REPO_ROOT / "scripts" / "generate-cli-docs.py"
DOCS_JSON_SCRIPT_PATH = REPO_ROOT / "scripts" / "update-tensormesh-docs-json.py"
ALLOWED_METHODS = {"GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS", "HEAD"}

EXPECTED_DOCUMENTED_CONTROLPLANE_OPERATIONS = {
    ("tm activities get", "GET", "/v1/activities/{activityId}"),
    ("tm activities list", "GET", "/v1/activities"),
    ("tm admin billing balances add", "POST",
     "/v1/admin/billing/balances:add"),
    ("tm admin billing balances get", "POST", "/v1/admin/billing/balances"),
    ("tm admin billing pricing delete", "DELETE",
     "/v1/admin/billing/gpu-pricing/{gpuType}/{cloudProvider}"),
    ("tm admin billing pricing serverless delete", "DELETE",
     "/v1/admin/billing/serverless-pricing?id=..."),
    ("tm admin billing pricing serverless list", "GET",
     "/v1/admin/billing/serverless-pricing"),
    ("tm admin billing pricing serverless upsert", "POST",
     "/v1/admin/billing/serverless-pricing"),
    ("tm admin billing pricing serverless upsert", "PUT",
     "/v1/admin/billing/serverless-pricing"),
    ("tm admin billing pricing upsert", "POST",
     "/v1/admin/billing/gpu-pricing"),
    ("tm admin billing pricing upsert", "PUT",
     "/v1/admin/billing/gpu-pricing"),
    ("tm admin billing spending summary", "POST",
     "/v1/admin/billing/spending/summary"),
    ("tm admin models list", "GET", "/v1/admin/models"),
    ("tm admin models delete", "DELETE", "/v1/admin/models/{modelId}"),
    ("tm admin products delete", "DELETE", "/v1/products/{id}"),
    ("tm admin products list", "GET", "/v1/admin/products"),
    ("tm admin products upsert", "POST", "/v1/admin/products"),
    ("tm admin users change-role", "POST", "/v1/admin/users/change_role"),
    ("tm admin users list", "GET", "/v1/admin/users"),
    ("tm auth whoami", "GET", "/auth/profile"),
    ("tm billing balance", "GET", "/v1/billing/balance"),
    ("tm billing address get", "GET", "/v1/billing/address"),
    ("tm billing address update", "PUT", "/v1/billing/address"),
    ("tm billing pricing list", "GET", "/v1/billing/gpu-pricing"),
    ("tm billing pricing serverless list", "GET",
     "/v1/billing/serverless-pricing"),
    ("tm billing spending history", "GET", "/v1/billing/spending/history"),
    ("tm billing spending summary", "GET", "/v1/billing/spending/summary"),
    ("tm billing stripe customer get", "GET", "/v1/billing/stripe/customers"),
    ("tm billing stripe payment-intents confirm", "POST",
     "/v1/billing/stripe/payment-intents/confirm"),
    ("tm billing stripe payment-intents create", "POST",
     "/v1/billing/stripe/payment-intents"),
    ("tm billing stripe payment-methods attach", "POST",
     "/v1/billing/stripe/customers/payment-methods"),
    ("tm billing stripe payment-methods detach", "DELETE",
     "/v1/billing/stripe/customers/payment-methods"),
    ("tm billing stripe payment-methods list", "GET",
     "/v1/billing/stripe/customers/payment-methods"),
    ("tm billing stripe setup-intents create", "POST",
     "/v1/billing/stripe/setup-intents"),
    ("tm billing transactions list", "GET", "/v1/billing/transactions"),
    ("tm logs", "GET", "/v1/observability/deployments/{deploymentId}/logs"),
    ("tm metrics deployment", "GET",
     "/v1/observability/deployments/{deploymentId}/metrics"),
    ("tm metrics user", "GET", "/v1/observability/users/metrics"),
    ("tm models chat", "POST", "/v1/models/{modelId}:chat"),
    ("tm models delete", "DELETE", "/v1/models/{modelId}"),
    ("tm models deploy", "POST", "/v1/models"),
    ("tm models get", "GET", "/v1/models/{modelId}"),
    ("tm models check", "POST", "/v1/models/check"),
    ("tm models list", "GET", "/v1/models"),
    ("tm models search-by-infra", "POST", "/v1/models:search-by-infra"),
    ("tm models validate-name", "POST", "/v1/models:validate"),
    ("tm products list", "GET", "/v1/products"),
    ("tm reserved-deployments submit", "POST",
     "/v1/support/reserved-deployments"),
    ("tm tickets close", "DELETE", "/v1/support/tickets/{ticketId}"),
    ("tm tickets create", "POST", "/v1/support/tickets"),
    ("tm tickets get", "GET", "/v1/support/tickets/{ticketId}"),
    ("tm tickets list", "GET", "/v1/support/tickets"),
    ("tm tickets message", "POST", "/v1/support/tickets/{ticketId}/messages"),
    ("tm users accept-tos", "POST", "/v1/users/accept-tos"),
    ("tm users api-keys create", "POST", "/v1/users/api-keys"),
    ("tm users api-keys delete", "DELETE", "/v1/users/api-keys"),
    ("tm users api-keys list", "GET", "/v1/users/api-keys"),
    ("tm users update", "PUT", "/v1/users/{userId}"),
}


def _normalize_path(path: str) -> str:
    path = re.sub(r"\{[^}]+\}", "{}", path)
    path = re.sub(r"\?id=\.\.\.$", "", path)
    return path


def _extract_documented_controlplane_operations() -> set[tuple[str, str, str]]:
    mod = load_script_module(SCRIPT_PATH)
    model = mod.build_cli_docs_model(mod.cli)
    patterns = (
        re.compile(
            r"\((GET|POST|PUT|PATCH|DELETE|OPTIONS|HEAD)(?:\|(GET|POST|PUT|PATCH|DELETE|OPTIONS|HEAD))?\s+([^\)]+)\)"
        ),
        re.compile(r"`(GET|POST|PUT|PATCH|DELETE|OPTIONS|HEAD)\s+([^`]+)`"),
    )

    operations: set[tuple[str, str, str]] = set()
    for command in model.commands:
        if command.kind == "group":
            continue
        texts = [command.summary, command.long_help, *command.caveats]
        for text in texts:
            for pattern in patterns:
                for match in pattern.finditer(text or ""):
                    if len(match.groups()) == 3:
                        methods = [match.group(1)]
                        if match.group(2):
                            methods.append(match.group(2))
                        path = match.group(3)
                    else:
                        methods = [match.group(1)]
                        path = match.group(2)
                    for method in methods:
                        if path.startswith("/"):
                            operations.add((command.path, method, path))
    return operations


def _load_published_operations() -> set[tuple[str, str]]:
    docs_json_mod = load_script_module(
        DOCS_JSON_SCRIPT_PATH, module_name="update_tensormesh_docs_json_test")
    docs_json_mod.build_docs_json(
        REPO_ROOT,
        write_output=False,
        write_published_specs=True,
        write_docs_json=False,
    )
    operations: set[tuple[str, str]] = set()
    specs_dir = REPO_ROOT / docs_json_mod.PUBLISHED_CONTROL_PLANE_SPECS_DIR
    for spec_path in sorted(specs_dir.rglob("*.openapi.json")):
        spec = json.loads(spec_path.read_text(encoding="utf-8"))
        for path, path_item in (spec.get("paths") or {}).items():
            if not isinstance(path_item, dict):
                continue
            for method, operation in path_item.items():
                method_upper = method.upper()
                if method_upper in ALLOWED_METHODS and isinstance(
                        operation, dict):
                    operations.add((method_upper, _normalize_path(path)))
    return operations


def test_documented_controlplane_cli_operations_snapshot() -> None:
    assert _extract_documented_controlplane_operations(
    ) == EXPECTED_DOCUMENTED_CONTROLPLANE_OPERATIONS


def test_documented_controlplane_cli_operations_exist_in_published_specs(
) -> None:
    published = _load_published_operations()

    missing = sorted((command_path, method, path) for command_path, method,
                     path in EXPECTED_DOCUMENTED_CONTROLPLANE_OPERATIONS
                     if (method, _normalize_path(path)) not in published)

    assert missing == []
