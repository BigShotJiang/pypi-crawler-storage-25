from __future__ import annotations

import json
from types import SimpleNamespace
from typing import Any
from unittest.mock import patch

import click
import pytest

from tensormesh_cli.output_utils import debug_log
from tensormesh_cli.output_utils import redact_headers
from tensormesh_cli.output_utils import redact_secret
from tensormesh_cli.render import _echo_table_rows
from tensormesh_cli.render import _table_rows_from_data
from tensormesh_cli.render import _truncate
from tensormesh_cli.render import context_output
from tensormesh_cli.render import echo_http_response
from tensormesh_cli.render import echo_http_response_with_text_extractor
from tensormesh_cli.render import echo_output
from tests.response_test_utils import JSONResponse


def test_redact_secret_and_headers() -> None:
    assert redact_secret(None) is None
    assert redact_secret("   ") is None
    assert redact_secret("abcdefghijk") == "abcd...hijk"
    assert redact_secret("short") == "***"
    assert redact_headers({
        "Authorization": "Bearer secret",
        "X-Api-Key": "secret",
        "Cookie": "a=b",
        "X-User-Id": "u1",
    }) == {
        "Authorization": "Bearer ***",
        "X-Api-Key": "***",
        "Cookie": "***",
        "X-User-Id": "u1",
    }


def test_echo_output_table_and_raw(capsys: Any) -> None:
    echo_output(output="table", data={"items": [{"id": "a1", "name": "Ada"}]})
    table_out = capsys.readouterr().out
    assert "id" in table_out
    assert "Ada" in table_out

    echo_output(output="table", data={"meta": "ok", "count": 2})
    kv_out = capsys.readouterr().out
    assert "key" in kv_out
    assert "meta" in kv_out

    echo_output(output="table", data="fallback-value")
    fallback_out = capsys.readouterr().out
    assert fallback_out == "fallback-value\n"

    echo_output(output="text", data={"hello": "world"})
    text_out = capsys.readouterr().out
    assert "hello: world" in text_out

    echo_output(output="raw", raw="hello")
    raw_out = capsys.readouterr().out
    assert raw_out == "hello\n"

    echo_output(output="raw", data={"ok": True, "items": [1, 2]})
    structured_raw_out = capsys.readouterr().out
    assert structured_raw_out == '{"ok": true, "items": [1, 2]}\n'


def test_echo_output_yaml_and_unknown_format(capsys: Any) -> None:
    echo_output(output="yaml", data={"items": [{"id": "a1"}]})
    yaml_out = capsys.readouterr().out
    assert "items:" in yaml_out
    assert "- id: a1" in yaml_out

    with pytest.raises(click.ClickException, match="Unknown output format"):
        echo_output(output="xml", data={"ok": True})


def test_render_table_helpers_and_truncation(capsys: Any) -> None:
    assert _truncate("abcdef", 1) == "a"
    assert _truncate("abcdef", 0) == ""

    assert _table_rows_from_data([{
        "id": "a1"
    }, {
        "id": "a2"
    }]) == [{
        "id": "a1"
    }, {
        "id": "a2"
    }]
    assert _table_rows_from_data({"records": [{
        "id": "a1"
    }, {
        "id": "a2"
    }]}) == [{
        "id": "a1"
    }, {
        "id": "a2"
    }]
    assert _table_rows_from_data({"items": ["bad"]}) is None

    _echo_table_rows([])
    assert capsys.readouterr().out == ""

    echo_output(
        output="table",
        data=[{
            "id": "a1",
            "extra": {
                "nested": True
            },
            "nullable": None,
            "flag": True,
            "long": "x" * 60,
        }],
    )
    out = capsys.readouterr().out
    assert "extra" in out
    assert '{"nested": true}' in out
    assert "flag" in out
    assert "True" in out
    assert "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx…" in out

    echo_output(output="raw", data=123)
    assert capsys.readouterr().out == "123\n"

    echo_output(output="raw", data="plain-text")
    assert capsys.readouterr().out == "plain-text\n"


def test_echo_http_response_with_text_extractor_prefers_text(
        capsys: Any) -> None:
    resp = JSONResponse(
        payload={"choices": [{
            "message": {
                "content": "pong"
            }
        }]},
        text=json.dumps({"choices": []}))

    echo_http_response_with_text_extractor(
        output="text",
        resp=resp,
        extract_text=lambda data: data["choices"][0]["message"]["content"],
    )

    assert capsys.readouterr().out == "pong\n"


def test_echo_http_response_with_text_extractor_fails_on_invalid_json(
) -> None:
    resp = JSONResponse(payload=ValueError("bad json"), text="plain-text")

    with pytest.raises(
            click.ClickException,
            match=
            "Invalid JSON response: expected JSON. Raw response: plain-text"):
        echo_http_response_with_text_extractor(
            output="text",
            resp=resp,
            extract_text=lambda data: None,
        )


def test_echo_http_response_fails_on_invalid_json() -> None:
    resp = JSONResponse(payload=ValueError("bad json"), text="plain-text")

    with pytest.raises(
            click.ClickException,
            match=
            "Invalid JSON response: expected JSON. Raw response: plain-text"):
        echo_http_response(output="json", resp=resp)


def test_echo_http_response_raw_passthrough(capsys: Any) -> None:
    resp = JSONResponse(payload={"ok": True}, text="raw-body")

    echo_http_response(output="raw", resp=resp)

    assert capsys.readouterr().out == "raw-body\n"


def test_echo_http_response_with_text_extractor_structured_output(
        capsys: Any) -> None:
    resp = JSONResponse(payload={"items": [{
        "id": "a1"
    }]},
                        text=json.dumps({"items": [{
                            "id": "a1"
                        }]}))

    echo_http_response_with_text_extractor(
        output="table",
        resp=resp,
        extract_text=lambda data: "should not be used",
    )

    out = capsys.readouterr().out
    assert "id" in out
    assert "a1" in out


def test_echo_http_response_with_text_extractor_applies_transform_data(
        capsys: Any) -> None:
    resp = JSONResponse(payload={"status": "raw"},
                        text=json.dumps({"status": "raw"}))

    echo_http_response_with_text_extractor(
        output="json",
        resp=resp,
        extract_text=lambda data: None,
        transform_data=lambda data: {"status": "normalized"},
    )

    assert json.loads(capsys.readouterr().out) == {"status": "normalized"}


def test_echo_http_response_with_text_extractor_raw_and_fallback(
        capsys: Any) -> None:
    raw_resp = JSONResponse(payload={"ok": True}, text="raw-line")
    echo_http_response_with_text_extractor(
        output="raw",
        resp=raw_resp,
        extract_text=lambda data: "unused",
    )
    assert capsys.readouterr().out == "raw-line\n"

    fallback_resp = JSONResponse(payload={"status": "ok"},
                                 text=json.dumps({"status": "ok"}))
    echo_http_response_with_text_extractor(
        output="text",
        resp=fallback_resp,
        extract_text=lambda data: None,
    )
    fallback_out = capsys.readouterr().out
    assert "status: ok" in fallback_out


def test_context_output_and_debug_log(runner) -> None:

    @click.command()
    def cmd() -> None:
        debug_log(enabled=True, quiet=False, message="debug-on")
        debug_log(enabled=False, quiet=False, message="debug-off")
        debug_log(enabled=True, quiet=True, message="debug-muted")

    ctx = click.Context(cmd)
    with patch("tensormesh_cli.render.get_app_context",
               return_value=SimpleNamespace(output="text")):
        assert context_output(ctx) == "text"
        assert context_output(ctx, default="json") == "text"

    with patch("tensormesh_cli.render.get_app_context",
               return_value=SimpleNamespace(output="")):
        assert context_output(ctx, default="json") == "json"

    result = runner.invoke(cmd, [])
    assert result.exit_code == 0, result.output
    assert "debug-on" in result.output
