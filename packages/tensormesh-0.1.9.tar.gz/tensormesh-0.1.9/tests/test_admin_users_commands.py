from __future__ import annotations

from tests.cli_test_utils import controlplane_env
from tests.cli_test_utils import invoke_tm
from tests.http_test_utils import assert_last_request
from tests.http_test_utils import json_response
from tests.http_test_utils import serve_controlplane_routes


def _admin_user_routes():
    return {
        ("POST", "/v1/admin/users/change_role"):
        json_response({"user": {
            "id": "u1",
            "userRole": "USER_ROLE_ADMIN",
        }}),
    }


def test_admin_users_change_role_builds_payload() -> None:
    with serve_controlplane_routes(_admin_user_routes()) as recorder:
        result = invoke_tm(
            [
                "--output",
                "json",
                "admin",
                "users",
                "change-role",
                "--target-user-id",
                "u1",
                "--target-user-role",
                "USER_ROLE_ADMIN",
                "--yes",
            ],
            env=controlplane_env(),
        )

    assert result.exit_code == 0, result.output
    assert_last_request(
        recorder,
        method="POST",
        path="/v1/admin/users/change_role",
        body={
            "targetUserId": "u1",
            "targetUserRole": "USER_ROLE_ADMIN",
        },
    )


def test_admin_users_change_role_confirmation_uses_json_payload_values(
) -> None:
    with serve_controlplane_routes(_admin_user_routes()):
        result = invoke_tm(
            [
                "admin",
                "users",
                "change-role",
                "--json",
                '{"targetUserId":"u1","targetUserRole":"USER_ROLE_ADMIN"}',
            ],
            env=controlplane_env(),
            input_text="n\n",
        )

    assert result.exit_code != 0
    assert "Change role for user 'u1' to 'USER_ROLE_ADMIN'?" in result.output


def test_admin_users_change_role_rejects_legacy_role_alias() -> None:
    with serve_controlplane_routes(_admin_user_routes()):
        result = invoke_tm(
            [
                "admin",
                "users",
                "change-role",
                "--target-user-id",
                "u1",
                "--target-user-role",
                "ROLE_ADMIN",
                "--yes",
            ],
            env=controlplane_env(),
        )

    assert result.exit_code != 0
    assert "Invalid value for '--target-user-role'" in result.output
