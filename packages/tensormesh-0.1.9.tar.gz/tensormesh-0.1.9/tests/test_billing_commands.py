from __future__ import annotations

import json

from tests.cli_test_utils import controlplane_env
from tests.cli_test_utils import invoke_tm
from tests.http_test_utils import assert_last_request
from tests.http_test_utils import json_response
from tests.http_test_utils import serve_controlplane_routes


def _billing_routes():
    return {
        ("GET", "/v1/billing/balance"):
        json_response(
            {"balance": {
                "currencyCode": "USD",
                "units": "1",
                "nanos": 0,
            }}),
        ("GET", "/v1/billing/transactions"):
        json_response({"transactions": []}),
        ("GET", "/v1/billing/serverless-pricing"):
        json_response({"pricing": []}),
        ("GET", "/v1/admin/billing/serverless-pricing"):
        json_response({"pricing": []}),
        ("POST", "/v1/admin/billing/balances:add"):
        json_response({"balance": {
            "currencyCode": "USD",
            "units": "1",
        }}),
        ("POST", "/v1/admin/billing/serverless-pricing"):
        json_response({"pricing": {
            "id": "sp_1"
        }}),
        ("POST", "/v1/admin/billing/gpu-pricing"):
        json_response({"pricing": {
            "gpuType": "GPU_TYPE_A100"
        }}),
        ("PUT", "/v1/admin/billing/serverless-pricing"):
        json_response({"pricing": {
            "id": "sp_1"
        }}),
        ("PUT", "/v1/admin/billing/gpu-pricing"):
        json_response({"pricing": {
            "gpuType": "GPU_TYPE_H100"
        }}),
        ("DELETE", "/v1/admin/billing/serverless-pricing"):
        json_response({"empty": {}}),
    }


def test_billing_balance_hits_balance_endpoint() -> None:
    with serve_controlplane_routes(_billing_routes()) as recorder:
        result = invoke_tm(
            ["--output", "json", "billing", "balance"],
            env=controlplane_env(),
        )

    assert result.exit_code == 0, result.output
    assert_last_request(
        recorder,
        method="GET",
        path="/v1/billing/balance",
    )


def test_billing_transactions_list_hits_transactions_endpoint() -> None:
    with serve_controlplane_routes(_billing_routes()) as recorder:
        result = invoke_tm(
            [
                "--output",
                "json",
                "billing",
                "transactions",
                "list",
                "--page-size",
                "10",
            ],
            env=controlplane_env(),
        )

    assert result.exit_code == 0, result.output
    request = assert_last_request(
        recorder,
        method="GET",
        path="/v1/billing/transactions",
    )
    assert request.query.get("pageSize") == ["10"]


def test_billing_serverless_pricing_list_builds_query() -> None:
    with serve_controlplane_routes(_billing_routes()) as recorder:
        result = invoke_tm(
            [
                "--output",
                "json",
                "billing",
                "pricing",
                "serverless",
                "list",
                "--model",
                "llama-4",
                "--active-only",
            ],
            env=controlplane_env(),
        )

    assert result.exit_code == 0, result.output
    assert_last_request(
        recorder,
        method="GET",
        path="/v1/billing/serverless-pricing",
        query={
            "model": ["llama-4"],
            "activeOnly": ["true"],
        },
    )


def test_admin_billing_balances_add_requires_confirmation_or_yes() -> None:
    with serve_controlplane_routes(_billing_routes()) as recorder:
        r_abort = invoke_tm(
            [
                "admin", "billing", "balances", "add", "--target-user-id",
                "u2", "--amount", "1"
            ],
            env=controlplane_env(),
            input_text="n\n",
        )
        assert r_abort.exit_code != 0

        r_yes = invoke_tm(
            [
                "--output",
                "json",
                "admin",
                "billing",
                "balances",
                "add",
                "--target-user-id",
                "u2",
                "--amount",
                "1",
                "--yes",
            ],
            env=controlplane_env(),
        )

    assert r_yes.exit_code == 0, r_yes.output
    assert_last_request(
        recorder,
        method="POST",
        path="/v1/admin/billing/balances:add",
    )


def test_admin_serverless_pricing_list_builds_query() -> None:
    with serve_controlplane_routes(_billing_routes()) as recorder:
        result = invoke_tm(
            [
                "--output",
                "json",
                "admin",
                "billing",
                "pricing",
                "serverless",
                "list",
                "--model",
                "llama-4",
                "--active-only",
            ],
            env=controlplane_env(),
        )

    assert result.exit_code == 0, result.output
    assert_last_request(
        recorder,
        method="GET",
        path="/v1/admin/billing/serverless-pricing",
        query={
            "model": ["llama-4"],
            "activeOnly": ["true"],
        },
    )


def test_admin_serverless_pricing_upsert_puts_payload() -> None:
    payload = {"pricing": {"model": "llama-4"}}
    with serve_controlplane_routes(_billing_routes()) as recorder:
        result = invoke_tm(
            [
                "--output",
                "json",
                "admin",
                "billing",
                "pricing",
                "serverless",
                "upsert",
                "--method",
                "put",
                "--json",
                json.dumps(payload),
                "--yes",
            ],
            env=controlplane_env(),
        )

    assert result.exit_code == 0, result.output
    assert_last_request(
        recorder,
        method="PUT",
        path="/v1/admin/billing/serverless-pricing",
        body=payload,
    )


def test_admin_serverless_pricing_delete_builds_query() -> None:
    with serve_controlplane_routes(_billing_routes()) as recorder:
        result = invoke_tm(
            [
                "--output",
                "json",
                "admin",
                "billing",
                "pricing",
                "serverless",
                "delete",
                "--id",
                "sp_1",
                "--yes",
            ],
            env=controlplane_env(),
        )

    assert result.exit_code == 0, result.output
    assert_last_request(
        recorder,
        method="DELETE",
        path="/v1/admin/billing/serverless-pricing",
        query={"id": ["sp_1"]},
    )


def test_admin_gpu_pricing_upsert_post_normalizes_payload() -> None:
    with serve_controlplane_routes(_billing_routes()) as recorder:
        result = invoke_tm(
            [
                "--output",
                "json",
                "admin",
                "billing",
                "pricing",
                "upsert",
                "--json",
                json.dumps({
                    "gpuType": "GPU_TYPE_A100",
                    "hourlyRate": {
                        "currencyCode": "USD",
                        "units": 1,
                        "nanos": 0,
                    },
                }),
                "--yes",
            ],
            env=controlplane_env(),
        )

    assert result.exit_code == 0, result.output
    assert_last_request(
        recorder,
        method="POST",
        path="/v1/admin/billing/gpu-pricing",
        body={
            "pricing": {
                "gpuType": "GPU_TYPE_A100",
                "hourlyRate": {
                    "currencyCode": "USD",
                    "units": "1",
                    "nanos": 0,
                },
            }
        },
    )


def test_admin_gpu_pricing_upsert_put_keeps_wrapped_payload() -> None:
    with serve_controlplane_routes(_billing_routes()) as recorder:
        result = invoke_tm(
            [
                "--output",
                "json",
                "admin",
                "billing",
                "pricing",
                "upsert",
                "--method",
                "put",
                "--json",
                json.dumps({
                    "pricing": {
                        "gpuType": "GPU_TYPE_H100",
                        "isActive": True,
                    }
                }),
                "--yes",
            ],
            env=controlplane_env(),
        )

    assert result.exit_code == 0, result.output
    assert_last_request(
        recorder,
        method="PUT",
        path="/v1/admin/billing/gpu-pricing",
        body={"pricing": {
            "gpuType": "GPU_TYPE_H100",
            "isActive": True,
        }},
    )
