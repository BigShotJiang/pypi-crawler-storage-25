from __future__ import annotations

from tests.cli_test_utils import controlplane_env
from tests.cli_test_utils import invoke_tm
from tests.http_test_utils import assert_last_request
from tests.http_test_utils import json_response
from tests.http_test_utils import serve_controlplane_routes


def test_admin_models_delete_requires_confirmation_or_yes() -> None:
    with serve_controlplane_routes({
        ("DELETE", "/v1/admin/models/m1"):
            json_response({"empty": {}}),
    }) as recorder:
        r_abort = invoke_tm(
            ["admin", "models", "delete", "m1"],
            env=controlplane_env(),
            input_text="n\n",
        )
        assert r_abort.exit_code != 0

        r_yes = invoke_tm(
            [
                "--output",
                "json",
                "admin",
                "models",
                "delete",
                "m1",
                "--user-id",
                "admin-1",
                "--yes",
            ],
            env=controlplane_env(),
        )

    assert r_yes.exit_code == 0, r_yes.output
    assert_last_request(
        recorder,
        method="DELETE",
        path="/v1/admin/models/m1",
        query={"userId": ["admin-1"]},
    )


def test_admin_models_delete_json_overrides_user_id_flag() -> None:
    with serve_controlplane_routes({
        ("DELETE", "/v1/admin/models/m1"):
            json_response({"empty": {}}),
    }) as recorder:
        result = invoke_tm(
            [
                "--output",
                "json",
                "admin",
                "models",
                "delete",
                "m1",
                "--user-id",
                "flag-user",
                "--json",
                '{"userId":"json-user"}',
                "--yes",
            ],
            env=controlplane_env(),
        )

    assert result.exit_code == 0, result.output
    assert_last_request(
        recorder,
        method="DELETE",
        path="/v1/admin/models/m1",
        query={"userId": ["json-user"]},
    )
