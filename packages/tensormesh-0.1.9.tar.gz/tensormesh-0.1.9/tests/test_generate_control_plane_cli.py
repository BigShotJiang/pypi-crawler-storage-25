from __future__ import annotations

import copy
from pathlib import Path
import subprocess
import sys

from tests.script_test_utils import load_script_module

SCRIPT_PATH = (Path(__file__).resolve().parents[1] / "scripts" /
               "generate-control-plane-cli.py")
REPO_ROOT = Path(__file__).resolve().parents[1]


def test_build_generated_control_plane_cli_module_contains_expected_registrars(
) -> None:
    mod = load_script_module(SCRIPT_PATH)
    rendered = mod.render_generated_module(mod.load_manifest())

    assert "def attach_generated_billing_gap_commands(" in rendered
    assert "def attach_generated_admin_billing_gap_commands(" in rendered
    assert "def attach_generated_admin_models_gap_commands(" in rendered
    assert "def attach_generated_models_gap_commands(" in rendered
    assert 'name="payment-methods"' in rendered
    assert 'name="payment-intents"' in rendered
    assert 'name="setup-intents"' in rendered


def test_render_generated_module_uses_manifest_metadata() -> None:
    mod = load_script_module(SCRIPT_PATH)
    manifest = copy.deepcopy(mod.load_manifest())
    target = next(item for item in manifest["commands"]
                  if item["id"] == "billing_stripe_customer_get")
    target["summary"] = "Synthetic summary from manifest."
    target["sdk_call"] = "client.synthetic.customer.get"

    rendered = mod.render_generated_module(manifest)

    assert "Synthetic summary from manifest." in rendered
    assert "client.synthetic.customer.get(" in rendered


def test_generator_check_passes_for_checked_in_output() -> None:
    result = subprocess.run(
        [sys.executable, str(SCRIPT_PATH), "--check"],
        cwd=REPO_ROOT,
        capture_output=True,
        text=True,
        check=False,
    )
    assert result.returncode == 0, result.stdout + result.stderr
