from __future__ import annotations

import json
from pathlib import Path

import pytest

from tests.script_test_utils import load_script_module

REPO_ROOT = Path(__file__).resolve().parents[1]
SCRIPT_PATH = REPO_ROOT / "scripts" / "resolve-released-client.py"


def test_resolve_release_assets_selects_manifest_and_wheel_details() -> None:
    mod = load_script_module(SCRIPT_PATH)

    release_payload = {
        "tag_name":
        "v1.2.3",
        "assets": [{
            "name":
            "RELEASE-MANIFEST.json",
            "url":
            "https://api.github.com/repos/example/repo/releases/assets/1",
        }, {
            "name":
            "tensormesh-1.2.3-py3-none-any.whl",
            "url":
            "https://api.github.com/repos/example/repo/releases/assets/2",
        }],
    }
    manifest_payload = {
        "package_version":
        "1.2.3",
        "artifacts": [{
            "filename": "tensormesh-1.2.3-py3-none-any.whl",
            "sha256": "abc123",
        }],
    }

    resolved = mod.resolve_release_assets(release_payload, manifest_payload)

    assert resolved == {
        "tag": "v1.2.3",
        "package_version": "1.2.3",
        "manifest_url":
        "https://api.github.com/repos/example/repo/releases/assets/1",
        "wheel_filename": "tensormesh-1.2.3-py3-none-any.whl",
        "wheel_url":
        "https://api.github.com/repos/example/repo/releases/assets/2",
        "wheel_sha256": "abc123",
    }


def test_resolve_release_assets_requires_wheel_asset() -> None:
    mod = load_script_module(SCRIPT_PATH)

    release_payload = {
        "tag_name":
        "v1.2.3",
        "assets": [{
            "name":
            "RELEASE-MANIFEST.json",
            "url":
            "https://api.github.com/repos/example/repo/releases/assets/1",
        }],
    }
    manifest_payload = {
        "package_version":
        "1.2.3",
        "artifacts": [{
            "filename": "tensormesh-1.2.3-py3-none-any.whl",
            "sha256": "abc123",
        }],
    }

    with pytest.raises(SystemExit, match="Missing wheel asset"):
        mod.resolve_release_assets(release_payload, manifest_payload)


def test_resolve_release_assets_rejects_malformed_release_assets_shape(
) -> None:
    mod = load_script_module(SCRIPT_PATH)

    release_payload = {
        "tag_name": "v1.2.3",
        "assets": {
            "name": "RELEASE-MANIFEST.json",
        },
    }
    manifest_payload = {
        "package_version":
        "1.2.3",
        "artifacts": [{
            "filename": "tensormesh-1.2.3-py3-none-any.whl",
            "sha256": "abc123",
        }],
    }

    with pytest.raises(
            SystemExit,
            match=
            "Malformed GitHub release payload: assets must be a list of objects",
    ):
        mod.resolve_release_assets(release_payload, manifest_payload)


def test_resolve_release_assets_rejects_non_object_release_payload() -> None:
    mod = load_script_module(SCRIPT_PATH)

    release_payload = []
    manifest_payload = {
        "package_version":
        "1.2.3",
        "artifacts": [{
            "filename": "tensormesh-1.2.3-py3-none-any.whl",
            "sha256": "abc123",
        }],
    }

    with pytest.raises(
            SystemExit,
            match="Malformed GitHub release payload: expected object",
    ):
        mod.resolve_release_assets(release_payload, manifest_payload)


def test_resolve_release_assets_rejects_missing_wheel_sha256() -> None:
    mod = load_script_module(SCRIPT_PATH)

    release_payload = {
        "tag_name":
        "v1.2.3",
        "assets": [{
            "name":
            "RELEASE-MANIFEST.json",
            "url":
            "https://api.github.com/repos/example/repo/releases/assets/1",
        }, {
            "name":
            "tensormesh-1.2.3-py3-none-any.whl",
            "url":
            "https://api.github.com/repos/example/repo/releases/assets/2",
        }],
    }
    manifest_payload = {
        "package_version": "1.2.3",
        "artifacts": [{
            "filename": "tensormesh-1.2.3-py3-none-any.whl",
        }],
    }

    with pytest.raises(
            SystemExit,
            match="Malformed release manifest artifact: missing sha256",
    ):
        mod.resolve_release_assets(release_payload, manifest_payload)


def test_resolve_release_assets_falls_back_to_release_wheel_and_sha256sums(
) -> None:
    mod = load_script_module(SCRIPT_PATH)

    release_payload = {
        "tag_name":
        "v1.2.3",
        "assets": [{
            "name":
            "RELEASE-MANIFEST.json",
            "url":
            "https://api.github.com/repos/example/repo/releases/assets/1",
        }, {
            "name":
            "SHA256SUMS",
            "url":
            "https://api.github.com/repos/example/repo/releases/assets/2",
        }, {
            "name":
            "tensormesh-1.2.3-py3-none-any.whl",
            "url":
            "https://api.github.com/repos/example/repo/releases/assets/3",
        }],
    }
    manifest_payload = {
        "package_version": "1.2.3",
        "artifacts": [],
    }

    resolved = mod.resolve_release_assets(
        release_payload,
        manifest_payload,
        sha256sums_text=("abc123  tensormesh-1.2.3-py3-none-any.whl\n"),
    )

    assert resolved == {
        "tag": "v1.2.3",
        "package_version": "1.2.3",
        "manifest_url":
        "https://api.github.com/repos/example/repo/releases/assets/1",
        "wheel_filename": "tensormesh-1.2.3-py3-none-any.whl",
        "wheel_url":
        "https://api.github.com/repos/example/repo/releases/assets/3",
        "wheel_sha256": "abc123",
    }


def test_resolve_release_assets_falls_back_to_release_wheel_asset_digest(
) -> None:
    mod = load_script_module(SCRIPT_PATH)

    release_payload = {
        "tag_name":
        "v1.2.3",
        "assets": [{
            "name":
            "RELEASE-MANIFEST.json",
            "url":
            "https://api.github.com/repos/example/repo/releases/assets/1",
        }, {
            "name": "tensormesh-1.2.3-py3-none-any.whl",
            "url":
            "https://api.github.com/repos/example/repo/releases/assets/3",
            "digest": "sha256:def456",
        }],
    }
    manifest_payload = {
        "package_version": "1.2.3",
        "artifacts": [],
    }

    resolved = mod.resolve_release_assets(release_payload, manifest_payload)

    assert resolved == {
        "tag": "v1.2.3",
        "package_version": "1.2.3",
        "manifest_url":
        "https://api.github.com/repos/example/repo/releases/assets/1",
        "wheel_filename": "tensormesh-1.2.3-py3-none-any.whl",
        "wheel_url":
        "https://api.github.com/repos/example/repo/releases/assets/3",
        "wheel_sha256": "def456",
    }


def test_resolve_release_assets_handles_v3_manifest_with_surfaces() -> None:
    mod = load_script_module(SCRIPT_PATH)

    release_payload = {
        "tag_name":
        "v1.2.3",
        "assets": [{
            "name":
            "RELEASE-MANIFEST.json",
            "url":
            "https://api.github.com/repos/example/repo/releases/assets/1",
        }, {
            "name":
            "tensormesh-1.2.3-py3-none-any.whl",
            "url":
            "https://api.github.com/repos/example/repo/releases/assets/2",
        }],
    }
    manifest_payload = {
        "manifest_version": 3,
        "git_tag": "v1.2.3",
        "surfaces": {
            "sdk": {
                "package_version":
                "1.2.3",
                "artifacts": [{
                    "filename": "tensormesh-1.2.3-py3-none-any.whl",
                    "sha256": "abc123",
                }],
            },
            "cli": {
                "cli_version":
                "1.2.3",
                "artifacts": [{
                    "filename": "tm-linux-amd64.tar.gz",
                    "sha256": "def456",
                }],
            },
        },
    }

    resolved = mod.resolve_release_assets(release_payload, manifest_payload)

    assert resolved == {
        "tag": "v1.2.3",
        "package_version": "1.2.3",
        "manifest_url":
        "https://api.github.com/repos/example/repo/releases/assets/1",
        "wheel_filename": "tensormesh-1.2.3-py3-none-any.whl",
        "wheel_url":
        "https://api.github.com/repos/example/repo/releases/assets/2",
        "wheel_sha256": "abc123",
    }


def test_resolve_release_assets_v3_no_sdk_falls_back_to_wheel_asset() -> None:
    mod = load_script_module(SCRIPT_PATH)

    release_payload = {
        "tag_name":
        "v1.2.3",
        "assets": [{
            "name":
            "RELEASE-MANIFEST.json",
            "url":
            "https://api.github.com/repos/example/repo/releases/assets/1",
        }, {
            "name": "tensormesh-1.2.3-py3-none-any.whl",
            "url":
            "https://api.github.com/repos/example/repo/releases/assets/2",
            "digest": "sha256:fallback789",
        }],
    }
    manifest_payload = {
        "manifest_version": 3,
        "git_tag": "v1.2.3",
        "surfaces": {
            "cli": {
                "cli_version":
                "1.2.3",
                "artifacts": [{
                    "filename": "tm-linux-amd64.tar.gz",
                    "sha256": "def456",
                }],
            },
        },
    }

    resolved = mod.resolve_release_assets(release_payload, manifest_payload)

    assert resolved["package_version"] == "1.2.3"
    assert resolved["wheel_filename"] == "tensormesh-1.2.3-py3-none-any.whl"
    assert resolved["wheel_sha256"] == "fallback789"


def test_fetch_json_uses_github_json_accept_for_release_metadata(
        monkeypatch: pytest.MonkeyPatch) -> None:
    mod = load_script_module(SCRIPT_PATH,
                             module_name="resolve_released_client_auth")
    requests: list[object] = []

    class FakeResponse:

        def __enter__(self) -> "FakeResponse":
            return self

        def __exit__(self, exc_type, exc, tb) -> None:
            return None

        def read(self) -> bytes:
            return json.dumps({"ok": True}).encode("utf-8")

    def fake_urlopen(request):  # type: ignore[no-untyped-def]
        requests.append(request)
        return FakeResponse()

    monkeypatch.setattr(mod, "urlopen", fake_urlopen)
    monkeypatch.setenv("GITHUB_TOKEN", "secret-token")

    payload = mod.fetch_json(
        "https://api.github.com/repos/example/repo/releases/latest")

    assert payload == {"ok": True}
    assert len(requests) == 1
    req = requests[0]
    assert req.full_url == "https://api.github.com/repos/example/repo/releases/latest"
    assert req.get_header("Authorization") == "Bearer secret-token"
    assert req.get_header("Accept") == "application/vnd.github+json"


def test_fetch_json_uses_octet_stream_accept_for_release_asset_api(
        monkeypatch: pytest.MonkeyPatch) -> None:
    mod = load_script_module(SCRIPT_PATH,
                             module_name="resolve_released_client_asset_auth")
    requests: list[object] = []

    class FakeResponse:

        def __enter__(self) -> "FakeResponse":
            return self

        def __exit__(self, exc_type, exc, tb) -> None:
            return None

        def read(self) -> bytes:
            return json.dumps({
                "package_version": "1.2.3",
                "artifacts": []
            }).encode("utf-8")

    def fake_urlopen(request):  # type: ignore[no-untyped-def]
        requests.append(request)
        return FakeResponse()

    monkeypatch.setattr(mod, "urlopen", fake_urlopen)
    monkeypatch.setenv("GITHUB_TOKEN", "secret-token")

    mod.fetch_json(
        "https://api.github.com/repos/example/repo/releases/assets/1")

    req = requests[0]
    assert req.get_header("Authorization") == "Bearer secret-token"
    assert req.get_header("Accept") == "application/octet-stream"
