from __future__ import annotations

import json
from pathlib import Path

from tests.script_test_utils import load_script_module

REPO_ROOT = Path(__file__).resolve().parents[1]
RENDER_INSTALLER_SCRIPT = REPO_ROOT / "scripts" / "render-public-cli-installer.py"
WRITE_LATEST_JSON_SCRIPT = (REPO_ROOT / "scripts" /
                            "write-public-cli-latest-json.py")
SYNC_PUBLIC_CLI_SCRIPT = REPO_ROOT / "scripts" / "sync-public-cli-release.py"


def test_render_public_installer_points_to_public_repo(tmp_path: Path) -> None:
    mod = load_script_module(RENDER_INSTALLER_SCRIPT)

    output_path = tmp_path / "install-tm.sh"
    mod.render_installer(
        public_repo="Tensormesh-Production/tensormesh-cli",
        output_path=output_path,
    )

    text = output_path.read_text(encoding="utf-8")
    assert 'REPO_SLUG="Tensormesh-Production/tensormesh-cli"' in text
    assert 'LATEST_JSON_URL=' in text
    assert 'raw.githubusercontent.com/$REPO_SLUG/main/latest.json' in text


def test_write_public_cli_latest_json_uses_public_release_urls(
    tmp_path: Path, ) -> None:
    mod = load_script_module(WRITE_LATEST_JSON_SCRIPT)

    output_path = tmp_path / "latest.json"
    mod.write_latest_json(
        tag="v0.1.4",
        public_repo="Tensormesh-Production/tensormesh-cli",
        output_path=output_path,
        published_at="2026-04-09T00:00:00Z",
    )

    payload = json.loads(output_path.read_text(encoding="utf-8"))
    assert payload["version"] == "v0.1.4"
    assert payload["published_at"] == "2026-04-09T00:00:00Z"
    assert payload["assets"]["linux-amd64"].endswith(
        "/releases/download/v0.1.4/tm-linux-amd64.tar.gz")
    assert payload["assets"]["linux-arm64"].endswith(
        "/releases/download/v0.1.4/tm-linux-arm64.tar.gz")
    assert payload["assets"]["darwin-amd64"].endswith(
        "/releases/download/v0.1.4/tm-darwin-amd64.tar.gz")
    assert payload["assets"]["darwin-arm64"].endswith(
        "/releases/download/v0.1.4/tm-darwin-arm64.tar.gz")
    assert payload["checksums_url"].endswith(
        "/releases/download/v0.1.4/SHA256SUMS")
    assert payload["manifest_url"].endswith(
        "/releases/download/v0.1.4/RELEASE-MANIFEST.json")
    assert payload["installer_url"].endswith(
        "/releases/download/v0.1.4/install-tm.sh")


def test_sync_public_release_updates_latest_only_after_asset_publish() -> None:
    mod = load_script_module(SYNC_PUBLIC_CLI_SCRIPT)
    events: list[str] = []

    mod.sync_public_release(
        upload_assets=lambda: events.append("upload"),
        verify_assets=lambda: events.append("verify"),
        update_stable_metadata=lambda: events.append("latest"),
    )

    assert events == ["upload", "verify", "latest"]
