from __future__ import annotations

from pathlib import Path

from tests.cli_test_utils import controlplane_env
from tests.cli_test_utils import gateway_env
from tests.cli_test_utils import invoke_tm
from tests.readiness_test_utils import invoke_tm_json
from tests.readiness_test_utils import write_raw_controlplane_auth_json


def _doctor_json(
    *,
    env: dict[str, str],
    config_path: Path | str,
):
    return invoke_tm_json(
        ["--output", "json", "--config",
         str(config_path), "doctor"],
        env=env,
    )


def test_doctor_json_includes_missing_and_status(tmp_path: Path) -> None:
    cfg = tmp_path / "config.toml"
    cfg.write_text("", encoding="utf-8")

    _, data = _doctor_json(
        config_path=cfg,
        env=controlplane_env(home=tmp_path, seed_file=False),
    )
    assert "ok" in data
    assert "missing" in data
    assert "warnings" in data
    assert "control_plane" in data
    assert "gateway" in data


def test_doctor_json_warns_for_invalid_token_file(tmp_path: Path) -> None:
    cfg = tmp_path / "config.toml"
    cfg.write_text("", encoding="utf-8")
    write_raw_controlplane_auth_json(tmp_path, "{not-json")

    _, data = _doctor_json(
        config_path=cfg,
        env=controlplane_env(home=tmp_path, seed_file=False),
    )
    assert any("control_plane_auth_json invalid" in item
               for item in data["warnings"])


def test_doctor_json_warns_for_missing_access_token_field(
    tmp_path: Path, ) -> None:
    cfg = tmp_path / "config.toml"
    cfg.write_text("", encoding="utf-8")
    write_raw_controlplane_auth_json(tmp_path, '{"refresh_token":"refresh"}\n')

    _, data = _doctor_json(
        config_path=cfg,
        env=controlplane_env(home=tmp_path, seed_file=False),
    )
    assert any("missing or invalid 'access_token'" in item
               for item in data["warnings"])


def test_doctor_json_partial_readiness_keeps_overall_false(
    isolated_home: Path, ) -> None:
    cfg = Path("cfg.toml")
    cfg.write_text(
        '[managed]\n'
        'gateway_api_key = "gw_key"\n'
        'gateway_user_id = "00000000-0000-0000-0000-000000000000"\n'
        'gateway_model_id = "gw_model"\n',
        encoding="utf-8",
    )

    _, data = _doctor_json(
        config_path=cfg,
        env=controlplane_env(home=isolated_home, seed_file=False),
    )
    assert data["ok"] is False
    assert data["ready"] == {
        "control_plane": False,
        "gateway": True,
        "overall": False,
    }


def test_doctor_json_warns_for_non_object_token_file(tmp_path: Path) -> None:
    cfg = tmp_path / "config.toml"
    cfg.write_text("", encoding="utf-8")
    write_raw_controlplane_auth_json(tmp_path, '["not","an","object"]\n')

    _, data = _doctor_json(
        config_path=cfg,
        env=controlplane_env(home=tmp_path, seed_file=False),
    )
    assert any("expected a JSON object" in item for item in data["warnings"])


def test_doctor_json_uses_selected_config_managed_values(
    tmp_path: Path, ) -> None:
    cfg = tmp_path / "config.toml"
    cfg.write_text(
        '[managed]\n'
        'gateway_api_key = "gw_key"\n'
        'gateway_user_id = "00000000-0000-0000-0000-000000000000"\n'
        'gateway_model_id = "gw_model"\n',
        encoding="utf-8",
    )
    write_raw_controlplane_auth_json(tmp_path, '{"access_token":"tok"}\n')

    _, data = _doctor_json(
        config_path=cfg,
        env=controlplane_env(home=tmp_path, seed_file=False),
    )
    assert data["gateway"]["api_key_present"] is True
    assert data["gateway"]["user_id_present"] is True
    assert data["gateway"]["model_id_present"] is True


def test_doctor_ignores_unmanaged_local_files(isolated_home: Path) -> None:
    Path("cfg.toml").write_text("", encoding="utf-8")
    Path(".ignored-local-config").write_text(
        "IGNORED_LOCAL_KEY=gw_key\n",
        encoding="utf-8",
    )

    _, data = _doctor_json(
        config_path="cfg.toml",
        env={"HOME": str(isolated_home)},
    )
    assert "unmanaged_local_files_available" not in data["files"]
    assert all("ignored_local" not in item.lower()
               for item in data["warnings"])


def test_doctor_human_output_shows_missing_and_warnings(
    isolated_home: Path, ) -> None:
    Path("cfg.toml").write_text("", encoding="utf-8")
    Path(".ignored-local-config.local").write_text(
        "IGNORED_LOCAL_KEY=gw_key\n", encoding="utf-8")
    write_raw_controlplane_auth_json(isolated_home, "{not-json")

    result = invoke_tm(
        [
            "--config",
            "cfg.toml",
            "--ca-bundle",
            "missing-ca.pem",
            "doctor",
        ],
        env=controlplane_env(home=isolated_home, seed_file=False),
    )

    assert result.exit_code == 0, result.output
    assert "tm doctor" in result.output
    assert "Config file: cfg.toml (ok)" in result.output
    assert "CA bundle: missing-ca.pem (missing)" in result.output
    assert "Missing:" in result.output
    assert "Warnings:" in result.output
    assert "Local readiness only." in result.output
    assert "control_plane_access_token" in result.output
    assert "gateway_user_id" in result.output
    assert "control_plane_auth_json invalid" in result.output
    assert "ca_bundle is set but file is missing" in result.output


def test_doctor_table_output_preserves_human_summary(
    isolated_home: Path, ) -> None:
    Path("cfg.toml").write_text("", encoding="utf-8")

    result = invoke_tm([
        "--output",
        "table",
        "--config",
        "cfg.toml",
        "doctor",
    ],
                       env={"HOME": str(isolated_home)})

    assert result.exit_code == 0, result.output
    assert "tm doctor" in result.output
    assert "Control Plane:" in result.output
    assert "Gateway:" in result.output


def test_doctor_exit_status_fails_when_not_ready(isolated_home: Path) -> None:
    Path("cfg.toml").write_text("", encoding="utf-8")

    result = invoke_tm(
        [
            "--config",
            "cfg.toml",
            "doctor",
            "--exit-status",
        ],
        env=controlplane_env(home=isolated_home, seed_file=False),
    )

    assert result.exit_code == 1, result.output
    assert "Missing:" in result.output


def test_doctor_exit_status_succeeds_when_ready(isolated_home: Path) -> None:
    write_raw_controlplane_auth_json(
        isolated_home,
        '{"access_token":"tok","refresh_token":"refresh"}\n',
    )
    cfg = Path("cfg.toml")
    cfg.write_text(
        '[managed]\n'
        'gateway_api_key = "gw_key"\n'
        'gateway_model_id = "gw_model"\n',
        encoding="utf-8",
    )

    result = invoke_tm(
        [
            "--config",
            str(cfg),
            "doctor",
            "--exit-status",
        ],
        env=controlplane_env(home=isolated_home, seed_file=False),
    )

    assert result.exit_code == 0, result.output


def test_doctor_exit_status_fails_for_gateway_only_ready(
    isolated_home: Path, ) -> None:
    Path("cfg.toml").write_text("", encoding="utf-8")

    result = invoke_tm(
        [
            "--config",
            "cfg.toml",
            "doctor",
            "--exit-status",
        ],
        env={
            **gateway_env(home=isolated_home,
                          api_key="gw_key",
                          model_id="gw_model"),
            **controlplane_env(home=isolated_home, seed_file=False),
        },
    )

    assert result.exit_code == 1, result.output
    assert "control_plane_access_token" in result.output


def test_doctor_exit_status_fails_for_control_plane_only_ready(
    isolated_home: Path, ) -> None:
    write_raw_controlplane_auth_json(
        isolated_home,
        '{"access_token":"tok","refresh_token":"refresh"}\n',
    )
    Path("cfg.toml").write_text("", encoding="utf-8")

    result = invoke_tm(
        [
            "--config",
            "cfg.toml",
            "doctor",
            "--exit-status",
        ],
        env={
            **gateway_env(home=isolated_home, api_key="", model_id=""),
            **controlplane_env(home=isolated_home, seed_file=False),
        },
    )

    assert result.exit_code == 1, result.output
    assert "gateway_api_key" in result.output


def test_doctor_fails_fast_for_negative_max_retries_env_value() -> None:
    result = invoke_tm(
        ["--output", "json", "doctor"],
        env={
            **controlplane_env(seed_file=False),
            "TENSORMESH_MAX_RETRIES": "-1",
        },
    )
    assert result.exit_code != 0
    assert "Max retries must be greater than or equal to 0." in result.output
