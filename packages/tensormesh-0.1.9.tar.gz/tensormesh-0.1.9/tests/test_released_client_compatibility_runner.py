from __future__ import annotations

from pathlib import Path

import pytest

from tests.script_test_utils import load_script_module

REPO_ROOT = Path(__file__).resolve().parents[1]
SCRIPT_PATH = REPO_ROOT / "scripts" / "run-released-client-compatibility.py"
VERIFY_SCRIPT_PATH = REPO_ROOT / "scripts" / "verify-released-client-compatibility.sh"


def test_build_auth_tokens_payload_returns_refresh_token_and_placeholder_access(
) -> None:
    mod = load_script_module(SCRIPT_PATH)

    assert mod.build_auth_tokens_payload("live-refresh-token") == {
        "access_token": "compat-access-placeholder",
        "refresh_token": "live-refresh-token",
    }


def test_build_auth_tokens_payload_trims_and_rejects_blank() -> None:
    mod = load_script_module(SCRIPT_PATH)

    assert mod.build_auth_tokens_payload("  live-refresh-token  ") == {
        "access_token": "compat-access-placeholder",
        "refresh_token": "live-refresh-token",
    }
    with pytest.raises(SystemExit,
                       match="Missing TM_COMPAT_CONTROL_PLANE_REFRESH_TOKEN."):
        mod.build_auth_tokens_payload("   ")


def test_read_auth_access_token_rejects_unrefreshed_placeholder(
        tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    mod = load_script_module(SCRIPT_PATH,
                             module_name="released_client_compat_read_auth")
    auth_path = tmp_path / "auth.json"
    auth_path.write_text(
        '{"access_token": "compat-access-placeholder", "refresh_token": "r"}',
        encoding="utf-8",
    )
    monkeypatch.setattr(mod, "AUTH_PATH", auth_path)

    with pytest.raises(SystemExit,
                       match="still contains the placeholder access_token"):
        mod._read_auth_access_token()


def test_read_auth_access_token_returns_refreshed_value(
        tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    mod = load_script_module(SCRIPT_PATH,
                             module_name="released_client_compat_read_auth_ok")
    auth_path = tmp_path / "auth.json"
    auth_path.write_text(
        '{"access_token": "fresh-access", "refresh_token": "r"}',
        encoding="utf-8",
    )
    monkeypatch.setattr(mod, "AUTH_PATH", auth_path)

    assert mod._read_auth_access_token() == "fresh-access"


def test_build_runtime_config_toml_writes_controlplane_base_only() -> None:
    mod = load_script_module(SCRIPT_PATH)

    rendered = mod.build_runtime_config_toml(
        control_plane_base_url="https://control.example.test")

    assert 'controlplane_base = "https://control.example.test"' in rendered
    assert "[managed]" not in rendered


def test_build_runtime_config_toml_omits_controlplane_base_when_unset(
) -> None:
    mod = load_script_module(SCRIPT_PATH)

    rendered = mod.build_runtime_config_toml(control_plane_base_url=None)

    assert "controlplane_base" not in rendered
    assert "[managed]" not in rendered


def test_should_run_optional_on_demand_smoke_requires_explicit_model_id(
) -> None:
    mod = load_script_module(SCRIPT_PATH)

    assert mod.should_run_optional_on_demand_smoke(
        {
            "TM_COMPAT_INFERENCE_API_KEY": "infer-token",
            "TM_COMPAT_GATEWAY_BASE_URL": "https://gateway.example.test",
            "TM_COMPAT_ON_DEMAND_USER_ID":
            "00000000-0000-0000-0000-000000000000",
        }) is False

    assert mod.should_run_optional_on_demand_smoke(
        {
            "TM_COMPAT_INFERENCE_API_KEY": "infer-token",
            "TM_COMPAT_GATEWAY_BASE_URL": "https://gateway.example.test",
            "TM_COMPAT_ON_DEMAND_USER_ID":
            "00000000-0000-0000-0000-000000000000",
            "TM_COMPAT_GATEWAY_MODEL_ID": "accounts/demo/models/test",
        }) is True


def test_venv_dir_uses_sys_prefix_without_resolving_interpreter_path(
        monkeypatch: pytest.MonkeyPatch) -> None:
    mod = load_script_module(SCRIPT_PATH,
                             module_name="released_client_compat_prefix")

    monkeypatch.setattr(mod.sys, "prefix", "/tmp/compat-venv")
    monkeypatch.setattr(mod.sys, "executable",
                        "/private/tmp/compat-venv/bin/python")

    assert mod._venv_dir() == Path("/tmp/compat-venv")


def test_verify_wrapper_uses_scrubbed_environment_for_child_runner() -> None:
    script = VERIFY_SCRIPT_PATH.read_text(encoding="utf-8")

    assert "env -i \\" in script
    assert 'HOME="$HOME_DIR"' in script
    assert 'TM_COMPAT_CONTROL_PLANE_REFRESH_TOKEN="$TM_COMPAT_CONTROL_PLANE_REFRESH_TOKEN"' in script
    assert "TM_COMPAT_CONTROL_PLANE_TOKEN" not in script


def test_verify_wrapper_uses_github_token_for_authenticated_wheel_download(
) -> None:
    script = VERIFY_SCRIPT_PATH.read_text(encoding="utf-8")

    assert 'GITHUB_TOKEN="${GITHUB_TOKEN:-}"' in script
    assert 'AUTH_HEADER=()' in script
    assert 'AUTH_HEADER=(-H "Authorization: Bearer $GITHUB_TOKEN")' in script
    assert 'curl -fsSL -H "Accept: application/octet-stream" "${AUTH_HEADER[@]}" "$WHEEL_URL" -o "$WHEEL_PATH"' in script


def test_verify_wrapper_verifies_wheel_digest_before_install() -> None:
    script = VERIFY_SCRIPT_PATH.read_text(encoding="utf-8")

    assert 'WHEEL_SHA256="$(jq -r \'.wheel_sha256 // empty\'' in script
    assert 'if [[ -z "$WHEEL_SHA256" ]]; then' in script
    assert '"$PYTHON_BIN" - "$WHEEL_PATH" "$WHEEL_SHA256" <<\'PY\'' in script
    assert 'hashlib.sha256' in script
    assert 'Wheel digest mismatch.' in script
    assert 'env -u PYTHONPATH "$VENV_DIR/bin/pip" install "$WHEEL_PATH"' in script
