from __future__ import annotations

import json
from typing import Any

import pytest

from tests.cli_test_utils import controlplane_env
from tests.cli_test_utils import gateway_env
from tests.cli_test_utils import invoke_tm
from tests.cli_test_utils import patch_gateway_provider_base
from tests.http_test_utils import assert_last_request
from tests.http_test_utils import json_response
from tests.http_test_utils import make_http_handler
from tests.http_test_utils import RequestRecorder
from tests.http_test_utils import serve_controlplane_routes
from tests.http_test_utils import serve_http_server
from tests.infer_chat_test_utils import make_chat_completion_handler

_MESSAGES = [{"role": "user", "content": "hi"}]


def _cp_models_routes(payload: dict[str, Any]):
    return {
        ("GET", "/v1/models"): json_response(payload),
    }


def test_chat_model_latest_resolves_via_control_plane_models_list(
        monkeypatch: Any) -> None:
    payload = {
        "models": [
            {
                "modelId": "m_old",
                "modelName": "gw_old",
                "deploymentId": "dep_old",
                "status": "MODEL_STATUS_UP",
                "updatedAt": "2024-01-01T00:00:00Z",
            },
            {
                "modelId": "m_new",
                "modelName": "gw_new",
                "deploymentId": "dep_new",
                "status": "MODEL_STATUS_UP",
                "updatedAt": "2024-02-01T00:00:00Z",
            },
        ]
    }
    recorder = RequestRecorder()
    with serve_controlplane_routes(
            _cp_models_routes(payload),
            expected_auth="Bearer cp_tok",
    ), serve_http_server(
            make_chat_completion_handler(
                recorder=recorder,
                expected_auth="Bearer gw_key",
            ), ) as gw_base:
        patch_gateway_provider_base(monkeypatch, base=gw_base)
        result = invoke_tm(
            [
                "infer",
                "chat",
                "--api-key",
                "gw_key",
                "--user-id",
                "00000000-0000-0000-0000-000000000000",
                "--model",
                "@latest",
                "--json",
                json.dumps(_MESSAGES),
            ],
            env={
                **controlplane_env(access_token="cp_tok"),
                **gateway_env(api_key="gw_key", model_id="unused"),
            },
        )

    assert result.exit_code == 0, result.output
    request = assert_last_request(recorder, path="/v1/chat/completions")
    assert isinstance(request.body, dict)
    assert request.body.get("model") == "gw_new"


def test_chat_model_latest_fails_when_control_plane_inventory_is_empty(
        monkeypatch: Any) -> None:
    recorder = RequestRecorder()
    with serve_controlplane_routes(
            _cp_models_routes({"models": []}),
            expected_auth="Bearer cp_tok",
    ), serve_http_server(
            make_chat_completion_handler(
                recorder=recorder,
                expected_auth="Bearer gw_key",
            )) as gw_base:
        patch_gateway_provider_base(monkeypatch, base=gw_base)
        result = invoke_tm(
            [
                "infer",
                "chat",
                "--api-key",
                "gw_key",
                "--user-id",
                "00000000-0000-0000-0000-000000000000",
                "--model",
                "@latest",
                "--json",
                json.dumps(_MESSAGES),
            ],
            env={
                **controlplane_env(access_token="cp_tok"),
                **gateway_env(api_key="gw_key", model_id="unused"),
            },
        )

    assert result.exit_code != 0
    assert "Failed to resolve @latest" in result.output
    assert "no served models with modelName/deploymentId found" in result.output
    assert recorder.requests == []


def test_chat_model_latest_fails_when_only_non_served_models_exist(
        monkeypatch: Any) -> None:
    payload = {
        "models": [
            {
                "modelId": "m_init",
                "modelName": "gw_init",
                "deploymentId": "dep_init",
                "status": "MODEL_STATUS_INIT",
                "updatedAt": "2024-02-01T00:00:00Z",
            },
        ]
    }
    recorder = RequestRecorder()
    with serve_controlplane_routes(
            _cp_models_routes(payload),
            expected_auth="Bearer cp_tok",
    ), serve_http_server(
            make_chat_completion_handler(
                recorder=recorder,
                expected_auth="Bearer gw_key",
            )) as gw_base:
        patch_gateway_provider_base(monkeypatch, base=gw_base)
        result = invoke_tm(
            [
                "infer",
                "chat",
                "--api-key",
                "gw_key",
                "--user-id",
                "00000000-0000-0000-0000-000000000000",
                "--model",
                "@latest",
                "--json",
                json.dumps(_MESSAGES),
            ],
            env={
                **controlplane_env(access_token="cp_tok"),
                **gateway_env(api_key="gw_key", model_id="unused"),
            },
        )

    assert result.exit_code != 0
    assert "Failed to resolve @latest" in result.output
    assert "no served models with modelName/deploymentId found" in result.output
    assert recorder.requests == []


def test_chat_model_latest_fails_for_invalid_control_plane_timestamps(
        monkeypatch: Any) -> None:
    payload = {
        "models": [
            {
                "modelId": "m_bad",
                "modelName": "gw_bad",
                "deploymentId": "dep_bad",
                "status": "MODEL_STATUS_UP",
                "updatedAt": "not-a-timestamp",
            },
        ]
    }
    recorder = RequestRecorder()
    with serve_controlplane_routes(
            _cp_models_routes(payload),
            expected_auth="Bearer cp_tok",
    ), serve_http_server(
            make_chat_completion_handler(
                recorder=recorder,
                expected_auth="Bearer gw_key",
            )) as gw_base:
        patch_gateway_provider_base(monkeypatch, base=gw_base)
        result = invoke_tm(
            [
                "infer",
                "chat",
                "--api-key",
                "gw_key",
                "--user-id",
                "00000000-0000-0000-0000-000000000000",
                "--model",
                "@latest",
                "--json",
                json.dumps(_MESSAGES),
            ],
            env={
                **controlplane_env(access_token="cp_tok"),
                **gateway_env(api_key="gw_key", model_id="unused"),
            },
        )

    assert result.exit_code != 0
    assert "Failed to resolve @latest" in result.output
    assert "gw_bad" in result.output
    assert "updatedAt must be a valid RFC3339 timestamp." in result.output
    assert recorder.requests == []


@pytest.mark.parametrize(
    ("command", "path", "body", "response_payload"),
    [
        (
            "completions",
            "/v1/completions",
            {
                "prompt": "Say ok.",
            },
            {
                "id": "cmpl_1",
                "object": "text_completion",
                "created": 1,
                "model": "gw_new",
                "choices": [{
                    "index": 0,
                    "text": "ok",
                    "finish_reason": "stop",
                }],
            },
        ),
        (
            "responses",
            "/v1/responses",
            {
                "input": "Say hello.",
            },
            {
                "id":
                "resp_1",
                "object":
                "response",
                "created_at":
                1,
                "model":
                "gw_new",
                "output":
                [{
                    "id": "out_1",
                    "type": "message",
                    "content": [{
                        "type": "output_text",
                        "text": "hello",
                    }],
                }],
            },
        ),
        (
            "tokenize",
            "/tokenize",
            {
                "prompt": "Hello",
            },
            {
                "count": 2,
                "max_model_len": 131072,
                "tokens": [15496, 0],
                "token_strs": ["Hello", "!"],
            },
        ),
        (
            "detokenize",
            "/detokenize",
            {
                "tokens": [15496, 0],
            },
            {
                "prompt": "Hello!",
            },
        ),
    ],
)
def test_openai_compat_commands_model_latest_resolves_via_control_plane_models_list(
    monkeypatch: Any,
    command: str,
    path: str,
    body: dict[str, Any],
    response_payload: dict[str, Any],
) -> None:
    payload = {
        "models": [
            {
                "modelId": "m_old",
                "modelName": "gw_old",
                "deploymentId": "dep_old",
                "status": "MODEL_STATUS_UP",
                "updatedAt": "2024-01-01T00:00:00Z",
            },
            {
                "modelId": "m_new",
                "modelName": "gw_new",
                "deploymentId": "dep_new",
                "status": "MODEL_STATUS_UP",
                "updatedAt": "2024-02-01T00:00:00Z",
            },
        ]
    }
    recorder = RequestRecorder()
    routes = {
        ("POST", path): json_response(response_payload),
    }

    with serve_controlplane_routes(
            _cp_models_routes(payload),
            expected_auth="Bearer cp_tok",
    ), serve_http_server(make_http_handler(routes=routes,
                                           recorder=recorder)) as gw_base:
        patch_gateway_provider_base(monkeypatch, base=gw_base)
        result = invoke_tm(
            [
                "--output",
                "json",
                "infer",
                command,
                "--surface",
                "on-demand",
                "--api-key",
                "gw_key",
                "--user-id",
                "00000000-0000-0000-0000-000000000000",
                "--model",
                "@latest",
                "--json",
                json.dumps(body),
            ],
            env={
                **controlplane_env(access_token="cp_tok"),
                **gateway_env(api_key="gw_key", model_id="unused"),
            },
        )

    assert result.exit_code == 0, result.output
    request = assert_last_request(recorder, method="POST", path=path)
    assert isinstance(request.body, dict)
    assert request.body.get("model") == "gw_new"
