from __future__ import annotations

import ast
import json
from pathlib import Path
import re
import shlex

import click

from tensormesh_cli.cli import cli
from tests.script_test_utils import load_script_module

REPO_ROOT = Path(__file__).resolve().parents[1]
CLI_DOCS_SCRIPT = REPO_ROOT / "scripts" / "generate-cli-docs.py"


def _shell_blocks(text: str) -> list[str]:
    return re.findall(r"```sh\n(.*?)```", text, flags=re.DOTALL)


def _normalize_shell_block(block: str) -> list[str]:
    lines: list[str] = []
    current = ""
    for raw_line in block.splitlines():
        line = raw_line.rstrip()
        if not line.strip():
            if current:
                lines.append(current.strip())
                current = ""
            continue
        if line.endswith("\\"):
            current += line[:-1].rstrip() + " "
            continue
        current += line.strip()
        lines.append(current.strip())
        current = ""
    if current:
        lines.append(current.strip())
    return lines


def _iter_tm_commands(text: str) -> list[list[str]]:
    commands: list[list[str]] = []
    for block in _shell_blocks(text):
        for line in _normalize_shell_block(block):
            for segment in re.split(r"\s*(?:\|\||&&|[|;])\s*", line):
                segment = segment.strip()
                if not segment or "$(" in segment:
                    continue
                start = segment.find("./.venv/bin/tm ")
                prefix_len = len("./.venv/bin/tm ")
                if start < 0:
                    start = segment.find("tm ")
                    prefix_len = len("tm ")
                if start < 0:
                    continue
                command_text = "tm " + segment[start + prefix_len:].strip()
                commands.append(shlex.split(command_text))
    return commands


def _option_map(command: click.Command) -> dict[str, click.Option]:
    options: dict[str, click.Option] = {}
    for param in command.params:
        if isinstance(param, click.Option):
            for opt in (*param.opts, *param.secondary_opts):
                options[opt] = param
    return options


def _consume_option(command: click.Command, tokens: list[str], index: int,
                    context: str) -> int:
    token = tokens[index]
    opt_name = token.split("=", 1)[0]
    if opt_name in {"--help", "-h"}:
        return index + 1
    option = _option_map(command).get(opt_name)
    assert option is not None, f"{context}: unknown option {opt_name!r}"
    if "=" in token or option.is_flag:
        return index + 1
    if index + option.nargs >= len(tokens):
        return len(tokens)
    return index + 1 + max(option.nargs, 1)


def _validate_tm_command(tokens: list[str], source: str) -> None:
    assert tokens and tokens[0] == "tm", f"{source}: expected tm command"
    ctx = click.Context(cli)
    current: click.Command = cli
    index = 1

    while index < len(tokens):
        token = tokens[index]
        if token.startswith("-"):
            index = _consume_option(current, tokens, index, source)
            continue
        if isinstance(current, click.Group):
            next_command = current.get_command(ctx, token)
            if next_command is not None:
                current = next_command
                ctx = click.Context(current, parent=ctx)
                index += 1
                continue
        break

    while index < len(tokens):
        token = tokens[index]
        if token.startswith("-"):
            index = _consume_option(current, tokens, index, source)
        else:
            index += 1


def test_cli_landing_page_links_guides_and_reference() -> None:
    landing = REPO_ROOT / "docs" / "cli" / "index.mdx"
    text = landing.read_text(encoding="utf-8")

    assert "[Installation](/cli/guides/installation)" in text
    assert "[Getting Started](/cli/guides/getting-started)" in text
    assert "[Authentication](/cli/guides/authentication)" in text
    assert "[First Inference Request](/cli/guides/first-request)" in text
    assert ("shared OpenAI-compatible Serverless and On-Demand endpoints"
            in text)
    assert ("explicit `X-User-Id` routing on On-Demand" in text)
    assert "[Config And Environment](/cli/guides/config-and-env)" in text
    assert "[Admin Workflows](/cli/guides/admin-workflows)" in text
    assert "[Troubleshooting](/cli/guides/troubleshooting)" in text
    assert "[Root Command](/cli/reference)" in text
    assert "[Version Command](/cli/reference/version)" in text
    assert "[Init Command](/cli/reference/init)" in text
    assert "[Inference Commands](/cli/reference/infer)" in text


def test_sdk_landing_page_links_guides_and_reference() -> None:
    landing = REPO_ROOT / "docs" / "sdk" / "index.mdx"
    text = landing.read_text(encoding="utf-8")

    assert "[Getting Started](/sdk/guides/getting-started)" in text
    assert "[Auth And Config](/sdk/guides/auth-and-config)" in text
    assert "[Inference](/sdk/guides/inference)" in text
    assert ("[Migration From OpenAI And Fireworks]"
            "(/sdk/guides/migration-from-openai-fireworks)" in text)
    assert "[Control Plane](/sdk/guides/control-plane)" in text
    assert "[Raw Inference API Reference](/api-reference)" in text
    assert "[CLI Guides](/cli)" in text


def test_docs_home_links_sdk_and_cli_control_plane_starters() -> None:
    docs_home = (REPO_ROOT / "docs" / "index.mdx").read_text(encoding="utf-8")

    assert "[SDK Control Plane Guide](/sdk/guides/control-plane)" in docs_home
    assert "[CLI Control Plane Workflows](/cli/guides/control-plane-workflows)" in docs_home


def test_docs_home_sends_fresh_cli_users_to_installation_first() -> None:
    docs_home = (REPO_ROOT / "docs" / "index.mdx").read_text(encoding="utf-8")
    cli_index = (REPO_ROOT / "docs" / "cli" /
                 "index.mdx").read_text(encoding="utf-8")

    assert "[CLI Installation](/cli/guides/installation)" in docs_home
    assert "Install the CLI first" in cli_index


def test_first_request_guide_mentions_installation_and_active_config_root(
) -> None:
    first_request = (REPO_ROOT / "docs" / "cli" / "guides" /
                     "first-request.mdx").read_text(encoding="utf-8")

    assert "[Installation](/cli/guides/installation)" in first_request
    assert "active `config.toml` state root" in first_request


def test_getting_started_guide_uses_active_config_root_wording() -> None:
    getting_started = (REPO_ROOT / "docs" / "cli" / "guides" /
                       "getting-started.mdx").read_text(encoding="utf-8")

    assert "active\n`config.toml` state root" in getting_started or "active `config.toml` state root" in getting_started


def test_cli_guides_link_back_to_reference_pages() -> None:
    guides = {
        "installation.mdx": "/cli/reference/version",
        "getting-started.mdx": "/cli/reference/init",
        "authentication.mdx": "/cli/reference/auth/login",
        "first-request.mdx": "/cli/reference/infer/doctor",
        "config-and-env.mdx": "/cli/reference/config/show",
        "admin-workflows.mdx": "/cli/reference/admin",
        "troubleshooting.mdx": "/cli/reference/doctor",
    }

    for guide_name, reference_link in guides.items():
        guide_path = REPO_ROOT / "docs" / "cli" / "guides" / guide_name
        text = guide_path.read_text(encoding="utf-8")

        assert "## Related Reference" in text
        assert f"]({reference_link})" in text


def test_cli_guides_present_serverless_and_on_demand_entry_paths() -> None:
    cli_index = (REPO_ROOT / "docs" / "cli" /
                 "index.mdx").read_text(encoding="utf-8")
    getting_started = (REPO_ROOT / "docs" / "cli" / "guides" /
                       "getting-started.mdx").read_text(encoding="utf-8")
    first_request = (REPO_ROOT / "docs" / "cli" / "guides" /
                     "first-request.mdx").read_text(encoding="utf-8")

    for text in (cli_index, getting_started, first_request):
        assert "--surface serverless" in text
        assert "YOUR_SERVERLESS_MODEL_NAME" in text

    assert "Use the On-Demand path when you want the standard CLI-assisted setup flow:" in cli_index
    assert "Choose this when you want the most guided CLI flow" in getting_started
    assert "This page covers the standard On-Demand first-request flow." in first_request


def test_cli_installation_avoids_broken_internal_release_links() -> None:
    installation = (REPO_ROOT / "docs" / "cli" / "guides" /
                    "installation.mdx").read_text(encoding="utf-8")

    assert "pip install tensormesh" in installation


def test_cli_installation_describes_standalone_binary_as_alternate_cli_only_path(
) -> None:
    installation = (REPO_ROOT / "docs" / "cli" / "guides" /
                    "installation.mdx").read_text(encoding="utf-8")

    assert "official one-click install path for the SDK and bundled CLI" in installation
    assert "Install with pip when you want the Python SDK and `tm` together." in installation
    assert "Python `3.12` or newer is required for this path." in installation
    assert "Standalone install is available for macOS and Linux through the public `tensormesh-cli` distribution repo." in installation
    assert "https://raw.githubusercontent.com/Tensormesh-Production/tensormesh-cli/main/install-tm.sh" in installation
    assert "Use the standalone installer when you only want the CLI" in installation
    assert "YOUR_RELEASE_HOST" not in installation
    assert "GitHub Releases remain the supported alternate CLI-only install surface." not in installation


def test_cli_latest_examples_keep_managed_setup_step() -> None:
    getting_started = (REPO_ROOT / "docs" / "cli" / "guides" /
                       "getting-started.mdx").read_text(encoding="utf-8")
    first_request = (REPO_ROOT / "docs" / "cli" / "guides" /
                     "first-request.mdx").read_text(encoding="utf-8")

    assert "tm init --sync" in getting_started.split(
        "## First Working On-Demand Request")[0]
    assert "tm init --sync" in first_request.split("## Using `@latest`")[1]
    assert "tm auth login\ntm infer chat --model @latest" not in getting_started
    assert "tm auth login\ntm infer chat --model @latest" not in first_request


def test_cli_serverless_discovery_stays_within_cli_reference() -> None:
    cli_index = (REPO_ROOT / "docs" / "cli" /
                 "index.mdx").read_text(encoding="utf-8")
    getting_started = (REPO_ROOT / "docs" / "cli" / "guides" /
                       "getting-started.mdx").read_text(encoding="utf-8")
    first_request = (REPO_ROOT / "docs" / "cli" / "guides" /
                     "first-request.mdx").read_text(encoding="utf-8")

    for text in (cli_index, getting_started, first_request):
        assert "](/cli/reference/billing/pricing/serverless/list)" in text


def test_infer_chat_reference_spells_out_on_demand_requirements() -> None:
    infer_chat = (REPO_ROOT / "docs" / "cli" / "reference" / "infer" /
                  "chat.mdx").read_text(encoding="utf-8")

    assert "after `tm auth login` and `tm init --sync`" in infer_chat
    assert "inference API key" in infer_chat
    assert "X-User-Id" in infer_chat


def test_cli_reference_pages_do_not_repeat_frontmatter_summary() -> None:
    auth_status = (REPO_ROOT / "docs" / "cli" / "reference" / "auth" /
                   "status.mdx").read_text(encoding="utf-8")
    auth_status_body = auth_status.split("---\n\n", 1)[1]
    assert auth_status_body.startswith("## What This Checks")

    config_show = (REPO_ROOT / "docs" / "cli" / "reference" / "config" /
                   "show.mdx").read_text(encoding="utf-8")
    config_show_body = config_show.split("---\n\n", 1)[1]
    assert config_show_body.startswith("## Usage")


def test_sdk_async_streaming_example_closes_raw_stream() -> None:
    sdk_inference = (REPO_ROOT / "docs" / "sdk" / "guides" /
                     "inference.mdx").read_text(encoding="utf-8")

    assert "finally:" in sdk_inference
    assert "await raw_stream.close()" in sdk_inference


def test_cli_latest_hint_explains_control_plane_scope() -> None:
    source = (REPO_ROOT / "src" / "tensormesh_cli" /
              "controlplane_models.py").read_text(encoding="utf-8")

    assert "Control Plane inventory / On-Demand served names" in source
    assert "requires Control Plane auth" in source


def test_sdk_guides_link_to_other_sdk_or_reference_pages() -> None:
    guides = {
        "getting-started.mdx": "/sdk/guides/auth-and-config",
        "auth-and-config.mdx": "/sdk/guides/inference",
        "migration-from-openai-fireworks.mdx": "/sdk/guides/inference",
        "inference.mdx": "/api-reference/on-demand",
        "control-plane.mdx": "/sdk/guides/inference",
    }

    for guide_name, expected_link in guides.items():
        guide_path = REPO_ROOT / "docs" / "sdk" / "guides" / guide_name
        text = guide_path.read_text(encoding="utf-8")

        assert f"]({expected_link})" in text


def test_sdk_inference_guide_uses_api_reference_index_routes() -> None:
    guide = (REPO_ROOT / "docs" / "sdk" / "guides" /
             "inference.mdx").read_text(encoding="utf-8")

    assert "](/api-reference/on-demand)" in guide
    assert "](/api-reference/serverless)" in guide
    assert "/api-reference/on-demand/post/v1/chat/completions" not in guide
    assert "/api-reference/serverless/post/v1/chat/completions" not in guide


def test_api_quickstart_exports_controlplane_base_before_curl_examples(
) -> None:
    guide = (REPO_ROOT / "docs" /
             "api-quickstart.mdx").read_text(encoding="utf-8")

    assert "tm --output json config show --sources" in guide
    assert "tm --controlplane-base https://api.gcpstaging.tensormesh.ai auth login" in guide
    assert (
        "CONTROLPLANE_BASE=\"$(tm --output json config show | python3 -c "
        "'import json,sys; print(json.load(sys.stdin)[\\\"controlplane_base\\\"])')\""
        in guide)
    assert "current default Control Plane host is `https://api.tensormesh.ai`" in guide
    assert "Look at `values.controlplane_base`" not in guide


def test_cli_guides_describe_auth_status_as_combined_local_readiness() -> None:
    production = (REPO_ROOT / "docs" / "cli" / "guides" /
                  "production-scripting.mdx").read_text(encoding="utf-8")
    troubleshooting = (REPO_ROOT / "docs" / "cli" / "guides" /
                       "troubleshooting.mdx").read_text(encoding="utf-8")

    assert ("local Control Plane token plus gateway credential prerequisites"
            in production)
    assert ("local readiness check for both the Control Plane token and the "
            "current gateway credentials" in troubleshooting)
    assert "broader local auth-and-gateway prerequisites" in troubleshooting


def test_sdk_docs_avoid_repo_local_cli_paths_and_version_pinned_artifacts(
) -> None:
    sdk_docs = [REPO_ROOT / "docs" / "sdk" / "index.mdx"]
    sdk_docs.extend(
        sorted((REPO_ROOT / "docs" / "sdk" / "guides").glob("*.mdx")))

    for doc_path in sdk_docs:
        text = doc_path.read_text(encoding="utf-8")

        assert "./.venv/bin/tm" not in text
        assert "tensormesh-0.1.0-py3-none-any.whl" not in text
        assert "api.gcpstaging.tensormesh.ai" not in text


def test_docs_json_exposes_sdk_tab_with_guides() -> None:
    docs_json = json.loads(
        (REPO_ROOT / "docs" / "docs.json").read_text(encoding="utf-8"))
    tabs = docs_json["navigation"]["tabs"]
    sdk_tab = next(tab for tab in tabs if tab["tab"] == "Python SDK")
    groups = {group["group"]: group["pages"] for group in sdk_tab["groups"]}

    assert groups["Overview"] == ["sdk/index"]
    assert groups["Guides"] == [
        "sdk/guides/getting-started",
        "sdk/guides/auth-and-config",
        "sdk/guides/inference",
        "sdk/guides/migration-from-openai-fireworks",
        "sdk/guides/control-plane",
    ]


def test_docs_json_exposes_api_reference_pages_with_stable_routes() -> None:
    docs_json = json.loads(
        (REPO_ROOT / "docs" / "docs.json").read_text(encoding="utf-8"))
    tabs = docs_json["navigation"]["tabs"]
    api_tab = next(tab for tab in tabs if tab["tab"] == "Inference API")
    groups = {group["group"]: group["pages"] for group in api_tab["groups"]}

    assert groups["Overview"] == ["api-reference/index"]
    assert groups["On-Demand"] == [
        "api-reference/on-demand",
        "api-reference/on-demand/models",
        "api-reference/on-demand/completions",
        "api-reference/on-demand/responses",
        "api-reference/on-demand/tokenize",
        "api-reference/on-demand/detokenize",
        "api-reference/on-demand/health",
        "api-reference/on-demand/version",
    ]
    assert groups["Serverless"] == [
        "api-reference/serverless",
        "api-reference/serverless/models",
        "api-reference/serverless/completions",
        "api-reference/serverless/responses",
        "api-reference/serverless/tokenize",
        "api-reference/serverless/detokenize",
        "api-reference/serverless/health",
        "api-reference/serverless/version",
    ]

    redirects = docs_json["redirects"]
    assert {
        "source": "/api-reference/on-demand/post/v1/chat/completions",
        "destination": "/api-reference/on-demand",
    } in redirects
    assert {
        "source": "/api-reference/serverless/post/v1/chat/completions",
        "destination": "/api-reference/serverless",
    } in redirects


def test_docs_json_exposes_cli_tab_with_guides_and_reference_groups() -> None:
    docs_json = json.loads(
        (REPO_ROOT / "docs" / "docs.json").read_text(encoding="utf-8"))
    tabs = docs_json["navigation"]["tabs"]
    cli_tab = next(tab for tab in tabs if tab["tab"] == "CLI")
    groups = {group["group"]: group["pages"] for group in cli_tab["groups"]}

    assert groups["Overview"] == ["cli/index"]
    assert "cli/guides/installation" in groups["Guides"]
    assert "cli/guides/getting-started" in groups["Guides"]
    assert "cli/guides/authentication" in groups["Guides"]
    assert groups["Common Commands"] == [
        "cli/reference/auth/login",
        "cli/reference/auth/status",
        "cli/reference/auth/whoami",
        "cli/reference/config/show",
        "cli/reference/infer/doctor",
        "cli/reference/infer/chat",
        "cli/reference/billing/pricing/serverless/list",
    ]
    assert "cli/reference/version" in groups["Reference - Core"]
    assert "cli/reference/init" in groups["Reference - Core"]
    assert "cli/reference/index" in groups["Reference - Core"]
    assert "cli/reference/admin/index" in groups["Reference - Admin"]


def test_docs_json_redirects_nested_cli_reference_roots_to_index_pages(
) -> None:
    docs_json = json.loads(
        (REPO_ROOT / "docs" / "docs.json").read_text(encoding="utf-8"))
    redirects = {(item["source"], item["destination"])
                 for item in docs_json["redirects"]}

    expected = set()
    for index_path in (REPO_ROOT / "docs" / "cli" /
                       "reference").rglob("index.mdx"):
        rel = index_path.parent.relative_to(REPO_ROOT / "docs").as_posix()
        if rel == "cli/reference":
            continue
        expected.add((f"/{rel}", f"/{rel}/index"))

    assert expected <= redirects


def test_control_plane_docs_use_task_shaped_group_labels() -> None:
    docs_json = json.loads(
        (REPO_ROOT / "docs" / "docs.json").read_text(encoding="utf-8"))
    tabs = docs_json["navigation"]["tabs"]
    control_plane_tab = next(tab for tab in tabs
                             if tab["tab"] == "Control Plane API")
    labels = [group["group"] for group in control_plane_tab["groups"]]

    assert labels[:5] == [
        "Overview", "Users", "Admin Users", "Models", "Admin Models"
    ]
    assert "Users" in labels
    assert "Admin Users" in labels
    assert "Models" in labels
    assert "Pricing" in labels
    assert "Transactions" in labels
    assert "Observability" in labels


def test_repo_docs_cutover_points_cli_users_to_published_docs() -> None:
    readme = (REPO_ROOT / "README.md").read_text(encoding="utf-8")
    docs_index = (REPO_ROOT / "docs" / "index.mdx").read_text(encoding="utf-8")
    docs_system = (REPO_ROOT / "dev" /
                   "docs-system.md").read_text(encoding="utf-8")

    assert "[docs/cli/index.mdx](docs/cli/index.mdx)" in readme
    assert "[docs/sdk/index.mdx](docs/sdk/index.mdx)" in readme
    assert "This docs site publishes the user-facing Tensormesh surfaces" in docs_index
    assert "If you are working in the repository" not in docs_index
    assert "this repository" not in docs_index
    assert "docs/api-reference/*.yaml" not in docs_index
    assert "openapi/tensormesh/**/*.swagger.json" not in docs_index
    assert "User-facing CLI docs live in `docs/cli/`." in docs_system
    assert "User-facing Python SDK docs live in `docs/sdk/`." in docs_system
    assert ("The SDK does not read CLI config or auth\nfiles by default."
            in readme)
    assert not (REPO_ROOT / "dev" / "cli.md").exists()


def test_config_guide_covers_schema_and_source_debugging() -> None:
    guide = (REPO_ROOT / "docs" / "cli" / "guides" /
             "config-and-env.mdx").read_text(encoding="utf-8")

    assert "## Config File Schema" in guide
    assert "`TENSORMESH_CONTROL_PLANE_BASE_URL`" in guide
    assert "`controlplane_base`" in guide
    assert '# gateway_provider = "nebius"' in guide
    assert "## Single-File Design" in guide
    assert "tm --config ./tensormesh.toml config show --sources" in guide
    assert "## Interpreting `config show --sources`" in guide
    assert "derived-from:managed:gateway_provider" in guide


def test_config_guide_documents_supported_managed_secret_export_pattern(
) -> None:
    guide = (REPO_ROOT / "docs" / "cli" / "guides" /
             "config-and-env.mdx").read_text(encoding="utf-8")

    assert "## Exporting Managed Values For Automation" in guide
    assert "tm config show" in guide
    assert "redact secrets such as" in guide
    assert "config.toml" in guide
    assert "GATEWAY_API_KEY" in guide
    assert "GATEWAY_USER_ID" in guide
    assert "GATEWAY_MODEL_NAME" in guide


def test_serverless_docs_point_to_the_real_model_discovery_flow() -> None:
    api_quickstart = (REPO_ROOT / "docs" /
                      "api-quickstart.mdx").read_text(encoding="utf-8")
    sdk_getting_started = (REPO_ROOT / "docs" / "sdk" / "guides" /
                           "getting-started.mdx").read_text(encoding="utf-8")
    sdk_inference = (REPO_ROOT / "docs" / "sdk" / "guides" /
                     "inference.mdx").read_text(encoding="utf-8")

    for text in (api_quickstart, sdk_getting_started, sdk_inference):
        normalized = " ".join(text.split())
        assert "tm billing pricing serverless list" in normalized
        assert "pricing[].model" in normalized
        assert "same Tensormesh environment" in normalized


def test_sdk_guides_explain_how_to_get_credentials_and_use_placeholder_models(
) -> None:
    getting_started = (REPO_ROOT / "docs" / "sdk" / "guides" /
                       "getting-started.mdx").read_text(encoding="utf-8")
    auth_and_config = (REPO_ROOT / "docs" / "sdk" / "guides" /
                       "auth-and-config.mdx").read_text(encoding="utf-8")
    inference = (REPO_ROOT / "docs" / "sdk" / "guides" /
                 "inference.mdx").read_text(encoding="utf-8")

    assert "## 3. Get Credentials" in getting_started
    assert "/cli/guides/authentication" in getting_started
    assert "tm users api-keys create --user-id \"$USER_ID\" --name sdk-key --yes" in getting_started
    assert "YOUR_SERVERLESS_MODEL_NAME" in getting_started
    assert "MiniMaxAI/MiniMax-M2.5" not in getting_started
    assert "## Get Credentials" in auth_and_config
    assert "tm users api-keys create --user-id \"$USER_ID\" --name sdk-key --yes" in auth_and_config
    assert "gateway_model_id" in auth_and_config
    assert "`gateway_api_key`" in auth_and_config
    assert "`inference_api_key`" in auth_and_config
    assert "stored inference API key" in auth_and_config
    assert "YOUR_SERVERLESS_MODEL_NAME" in inference
    assert "gateway_model_id" in inference


def test_cli_and_sdk_docs_clarify_shared_inference_credential_and_model_key(
) -> None:
    config_guide = (REPO_ROOT / "docs" / "cli" / "guides" /
                    "config-and-env.mdx").read_text(encoding="utf-8")
    infer_chat_ref = (REPO_ROOT / "docs" / "cli" / "reference" / "infer" /
                      "chat.mdx").read_text(encoding="utf-8")
    config_show_ref = (REPO_ROOT / "docs" / "cli" / "reference" / "config" /
                       "show.mdx").read_text(encoding="utf-8")

    expected_parts = (
        "`gateway_api_key`",
        "`inference_api_key`",
        "stored inference API key",
    )
    compatibility_note = (
        "`gateway_model_id` remains a config compatibility "
        "key; its value is the served model name string sent "
        "as `model`.")

    for text in (config_guide, infer_chat_ref, config_show_ref):
        for part in expected_parts:
            assert part in text
    for text in (config_guide, config_show_ref):
        assert compatibility_note in text


def test_control_plane_workflows_api_key_example_includes_required_inputs(
) -> None:
    guide = (REPO_ROOT / "docs" / "cli" / "guides" /
             "control-plane-workflows.mdx").read_text(encoding="utf-8")

    assert 'USER_ID="$(tm --output json auth whoami | python3 -c ' in guide
    assert 'tm users api-keys create --user-id "$USER_ID" --name ci-key --yes' in guide
    assert "tm users api-keys create --name ci-key" not in guide


def test_control_plane_landing_page_calls_out_extended_public_groups() -> None:
    landing = (REPO_ROOT / "docs" / "tensormesh-api" /
               "index.mdx").read_text(encoding="utf-8")
    docs_home = (REPO_ROOT / "docs" / "index.mdx").read_text(encoding="utf-8")

    assert "starter list, not a complete catalog" in landing
    assert "[SDK Control Plane Guide](/sdk/guides/control-plane)" in landing
    assert "[CLI Control Plane Workflows](/cli/guides/control-plane-workflows)" in landing
    assert "[Activities](/tensormesh-api/activity/v1/activity_service)" in landing
    assert "products, activities, reserved deployments" in docs_home


def test_sdk_docs_distinguish_sdk_scope_from_inference_scope() -> None:
    sdk_index = (REPO_ROOT / "docs" / "sdk" /
                 "index.mdx").read_text(encoding="utf-8")
    getting_started = (REPO_ROOT / "docs" / "sdk" / "guides" /
                       "getting-started.mdx").read_text(encoding="utf-8")
    auth_and_config = (REPO_ROOT / "docs" / "sdk" / "guides" /
                       "auth-and-config.mdx").read_text(encoding="utf-8")
    inference = (REPO_ROOT / "docs" / "sdk" / "guides" /
                 "inference.mdx").read_text(encoding="utf-8")
    shared_scope_text = (
        "The public inference surface exposes `chat.completions`, "
        "`models`, `completions`, `responses`, `tokenize`, `detokenize`, "
        "`health`, and `version` on both surfaces.")

    assert "client.control_plane" in sdk_index
    assert "The public Python SDK currently covers chat completions only." not in sdk_index
    for text in (getting_started, auth_and_config, inference):
        assert "The public SDK currently covers chat completions only." not in text
        assert "The public inference surface currently covers chat completions only." not in text
        assert shared_scope_text in text
    assert "without an inference API key" in sdk_index
    assert "without one" in auth_and_config
    assert "without an inference API key" in inference


def test_serverless_docs_note_public_get_routes_can_be_anonymous() -> None:
    api_index = (REPO_ROOT / "docs" / "api-reference" /
                 "index.mdx").read_text(encoding="utf-8")
    quickstart = (REPO_ROOT / "docs" /
                  "api-quickstart.mdx").read_text(encoding="utf-8")
    models_page = (REPO_ROOT / "docs" / "api-reference" / "serverless" /
                   "models.mdx").read_text(encoding="utf-8")
    health_page = (REPO_ROOT / "docs" / "api-reference" / "serverless" /
                   "health.mdx").read_text(encoding="utf-8")
    version_page = (REPO_ROOT / "docs" / "api-reference" / "serverless" /
                    "version.mdx").read_text(encoding="utf-8")

    assert "without auth" in api_index
    assert "without auth" in quickstart
    for text in (models_page, health_page, version_page):
        assert "none required on the public host" in text


def test_inference_reference_and_cli_docs_use_model_name_terminology() -> None:
    serverless_ref = (REPO_ROOT / "docs" / "api-reference" /
                      "serverless.openapi.yaml").read_text(encoding="utf-8")
    on_demand_ref = (REPO_ROOT / "docs" / "api-reference" /
                     "on-demand.openapi.yaml").read_text(encoding="utf-8")
    infer_chat_ref = (REPO_ROOT / "docs" / "cli" / "reference" / "infer" /
                      "chat.mdx").read_text(encoding="utf-8")
    doctor_ref = (REPO_ROOT / "docs" / "cli" / "reference" / "infer" /
                  "doctor.mdx").read_text(encoding="utf-8")

    assert "Serverless model name to use." in serverless_ref
    assert "The On-Demand served model name to use." in on_demand_ref
    assert "Serverless model id to use." not in serverless_ref
    assert "served model id" not in on_demand_ref
    assert "Model name to use." in infer_chat_ref
    assert "Model name to inspect for the next request." in doctor_ref
    assert "Model id to use." not in infer_chat_ref
    assert "Model id to inspect for the next request." not in doctor_ref


def test_public_docs_avoid_repo_internal_wording_in_entry_pages() -> None:
    api_quickstart = (REPO_ROOT / "docs" /
                      "api-quickstart.mdx").read_text(encoding="utf-8")
    auth_guide = (REPO_ROOT / "docs" / "cli" / "guides" /
                  "authentication.mdx").read_text(encoding="utf-8")

    assert "This page covers the fastest raw-API paths in this repo." not in api_quickstart
    assert "repo default" not in api_quickstart
    assert "stable bearer-token validation endpoint in this repo" not in api_quickstart
    assert "repo default" not in auth_guide
    assert "/auth/cli/start" not in auth_guide
    assert "/auth/cli/exchange" not in auth_guide
    assert "/auth/cli/refresh" not in auth_guide


def test_cli_installation_follow_on_guides_keep_tm_binary_path_explicit(
) -> None:
    getting_started = (REPO_ROOT / "docs" / "cli" / "guides" /
                       "getting-started.mdx").read_text(encoding="utf-8")
    authentication = (REPO_ROOT / "docs" / "cli" / "guides" /
                      "authentication.mdx").read_text(encoding="utf-8")

    for text in (getting_started, authentication):
        assert "If `tm` is not already on your `PATH`" in text
        assert "./.venv/bin/tm" in text


def test_docs_home_avoids_duplicate_site_title() -> None:
    docs_home = (REPO_ROOT / "docs" / "index.mdx").read_text(encoding="utf-8")

    assert "title: Tensormesh Docs" not in docs_home


def test_auth_docs_explain_sensitive_token_and_logout_flows() -> None:
    auth_guide = (REPO_ROOT / "docs" / "cli" / "guides" /
                  "authentication.mdx").read_text(encoding="utf-8")
    auth_logout_ref = (REPO_ROOT / "docs" / "cli" / "reference" / "auth" /
                       "logout.mdx").read_text(encoding="utf-8")

    assert "tm auth print-token --yes-i-know" in auth_guide
    assert "tm auth logout --yes" in auth_guide
    assert "| `--yes` | `boolean` | no | `false` | Skip confirmation prompt. Boolean flag. |" in auth_logout_ref


def test_config_docs_and_help_explain_tm_config_home_override() -> None:
    readme = (REPO_ROOT / "README.md").read_text(encoding="utf-8")
    config_guide = (REPO_ROOT / "docs" / "cli" / "guides" /
                    "config-and-env.mdx").read_text(encoding="utf-8")
    cli_reference = (REPO_ROOT / "docs" / "cli" / "reference" /
                     "index.mdx").read_text(encoding="utf-8")

    assert "TM_CONFIG_HOME" in readme
    assert "TM_CONFIG_HOME" in config_guide
    assert "TM_CONFIG_HOME" in cli_reference
    assert "auth.json" in config_guide


def test_cli_reference_keeps_auth_path_aligned_with_tm_config_home() -> None:
    cli_reference = (REPO_ROOT / "docs" / "cli" / "reference" /
                     "index.mdx").read_text(encoding="utf-8")

    assert "active state root" in cli_reference
    assert "always read from ~/.config/tensormesh/auth.json" not in cli_reference


def test_readme_and_contributing_explain_repo_map_and_token_free_validation(
) -> None:
    readme = (REPO_ROOT / "README.md").read_text(encoding="utf-8")
    contributing = (REPO_ROOT / "CONTRIBUTING.md").read_text(encoding="utf-8")

    assert "three primary surfaces" in readme
    assert "No credentials are required for most local validation" in readme
    assert "default GitHub Actions CI path is token-free" in readme
    assert "GitHub Actions CI is token-free" not in readme
    assert "No credentials are required for most local validation" in contributing


def test_readme_respects_tm_config_home_for_auth_path_and_network_verify(
) -> None:
    readme = (REPO_ROOT / "README.md").read_text(encoding="utf-8")
    troubleshooting = (REPO_ROOT / "dev" /
                       "troubleshooting.md").read_text(encoding="utf-8")

    assert "always read from `~/.config/tensormesh/auth.json`" not in readme
    assert "When `TM_CONFIG_HOME` is unset" in readme
    assert "requires a synced `gateway_api_key`" in readme
    assert "fails before running the live probes" not in troubleshooting
    assert "fails when the required live inputs are missing" in troubleshooting


def test_readme_controlplane_base_setup_matches_cli_defaults() -> None:
    readme = (REPO_ROOT / "README.md").read_text(encoding="utf-8")
    dev_setup = (REPO_ROOT / "dev" / "setup.md").read_text(encoding="utf-8")
    config_guide = (REPO_ROOT / "docs" / "cli" / "guides" /
                    "config-and-env.mdx").read_text(encoding="utf-8")

    assert "https://api.tensormesh.ai" in readme
    assert "https://api.gcpstaging.tensormesh.ai" not in readme
    assert "`--controlplane-base`" in readme
    assert "`TENSORMESH_CONTROL_PLANE_BASE_URL`" in readme
    assert "`controlplane_base`" in readme
    assert "./.venv/bin/tm auth login" in readme
    assert "./.venv/bin/tm init --sync" in readme
    assert "tm init --sync` updates `[managed]`" in readme
    assert "persists that `controlplane_base`" in readme
    assert "explicit non-default `--controlplane-base`" not in readme
    assert "The SDK default Control Plane base in this repo is `https://api.tensormesh.ai`" in dev_setup
    assert "explicit non-default `--controlplane-base`" not in dev_setup
    assert "session-only `TENSORMESH_CONTROL_PLANE_BASE_URL` override" in config_guide
    assert "`tm init --sync` does not write that env override into `config.toml`" in config_guide


def test_sdk_inference_docs_cover_tool_and_response_format_limits() -> None:
    sdk_inference = (REPO_ROOT / "docs" / "sdk" / "guides" /
                     "inference.mdx").read_text(encoding="utf-8")

    assert "## Tool Calling" in sdk_inference
    assert "tool_choice" in sdk_inference
    assert "## Structured Output" in sdk_inference
    assert "JSON Schema-style" in sdk_inference
    assert ("unsupported extra keys inside `response_format` are rejected "
            "explicitly by the SDK" in sdk_inference)


def test_api_quickstart_distinguishes_serverless_and_on_demand_compatibility(
) -> None:
    api_quickstart = (REPO_ROOT / "docs" /
                      "api-quickstart.mdx").read_text(encoding="utf-8")

    assert ("Serverless: OpenAI-compatible `POST /v1/chat/completions`"
            in api_quickstart)
    assert ("On-Demand: near-compatible `POST /v1/chat/completions`"
            in api_quickstart)


def test_api_quickstart_and_reference_include_raw_streaming_examples() -> None:
    api_quickstart = (REPO_ROOT / "docs" /
                      "api-quickstart.mdx").read_text(encoding="utf-8")
    serverless_reference = (REPO_ROOT / "docs" / "api-reference" /
                            "serverless.mdx").read_text(encoding="utf-8")

    assert "curl -N" in api_quickstart
    assert "\"Accept: text/event-stream\"" in api_quickstart
    assert "\"stream\": true" in api_quickstart
    assert "`data: [DONE]`" in api_quickstart
    assert "OpenAI-compatible chat completions" in serverless_reference


def test_non_chat_openapi_docs_include_sse_response_contract() -> None:
    serverless_openapi = (REPO_ROOT / "docs" / "api-reference" /
                          "serverless.openapi.yaml").read_text(
                              encoding="utf-8")
    on_demand_openapi = (REPO_ROOT / "docs" / "api-reference" /
                         "on-demand.openapi.yaml").read_text(encoding="utf-8")

    for text in (serverless_openapi, on_demand_openapi):
        assert "text/event-stream" in text
        assert "data: [DONE]" in text


def test_serverless_api_reference_pages_cover_verified_vllm_routes() -> None:
    docs_base = json.loads(
        (REPO_ROOT / "docs" / "docs.base.json").read_text(encoding="utf-8"))
    tabs = docs_base["navigation"]["tabs"]
    inference_tab = next(tab for tab in tabs if tab["tab"] == "Inference API")
    serverless_group = next(group for group in inference_tab["groups"]
                            if group["group"] == "Serverless")

    assert serverless_group["pages"] == [
        "api-reference/serverless",
        "api-reference/serverless/models",
        "api-reference/serverless/completions",
        "api-reference/serverless/responses",
        "api-reference/serverless/tokenize",
        "api-reference/serverless/detokenize",
        "api-reference/serverless/health",
        "api-reference/serverless/version",
    ]


def test_on_demand_api_reference_pages_cover_openai_compatible_routes(
) -> None:
    docs_base = json.loads(
        (REPO_ROOT / "docs" / "docs.base.json").read_text(encoding="utf-8"))
    tabs = docs_base["navigation"]["tabs"]
    inference_tab = next(tab for tab in tabs if tab["tab"] == "Inference API")
    on_demand_group = next(group for group in inference_tab["groups"]
                           if group["group"] == "On-Demand")

    assert on_demand_group["pages"] == [
        "api-reference/on-demand",
        "api-reference/on-demand/models",
        "api-reference/on-demand/completions",
        "api-reference/on-demand/responses",
        "api-reference/on-demand/tokenize",
        "api-reference/on-demand/detokenize",
        "api-reference/on-demand/health",
        "api-reference/on-demand/version",
    ]


def test_api_quickstart_respects_tm_config_home_when_exporting_managed_values(
) -> None:
    api_quickstart = (REPO_ROOT / "docs" /
                      "api-quickstart.mdx").read_text(encoding="utf-8")

    assert 'os.environ.get("TM_CONFIG_HOME", "~/.config/tensormesh")' in api_quickstart
    assert ('config_path = Path.home() / ".config" / "tensormesh" / '
            '"config.toml"' not in api_quickstart)


def test_inference_and_control_plane_landing_pages_explain_first_steps(
) -> None:
    inference_index = (REPO_ROOT / "docs" / "api-reference" /
                       "index.mdx").read_text(encoding="utf-8")
    control_plane_index = (REPO_ROOT / "docs" / "tensormesh-api" /
                           "index.mdx").read_text(encoding="utf-8")

    assert "provider-specific external host" in inference_index
    assert "tm auth login" in control_plane_index
    assert "tm auth print-token --yes-i-know" in control_plane_index
    assert "Admin" in control_plane_index


def test_control_plane_landing_page_explains_mixed_public_and_admin_groups(
) -> None:
    control_plane_index = (REPO_ROOT / "docs" / "tensormesh-api" /
                           "index.mdx").read_text(encoding="utf-8")

    assert "some groups mix standard and admin routes" in control_plane_index
    assert "groups without `Admin` are standard authenticated Control Plane operations" not in control_plane_index
    assert "Stripe webhook delivery and other internal-only routes are intentionally omitted" in control_plane_index


def test_control_plane_service_pages_use_public_titles_and_canonical_links(
) -> None:
    expectations = {
        REPO_ROOT / "docs" / "tensormesh-api" / "billing" / "v1" / "billing_address_service.mdx":
        ("title: Billing Addresses", "/billingaddressservice/"),
        REPO_ROOT / "docs" / "tensormesh-api" / "billing" / "v1" / "stripe_service.mdx":
        ("title: Stripe", "/stripeservice/"),
        REPO_ROOT / "docs" / "tensormesh-api" / "observability" / "v1" / "observability_service.mdx":
        ("title: Observability", "/observabilityservice/"),
        REPO_ROOT / "docs" / "tensormesh-api" / "support" / "v1" / "support_service.mdx":
        ("title: Support", "/support/"),
    }

    for path, (title, canonical_fragment) in expectations.items():
        text = path.read_text(encoding="utf-8")
        assert title in text
        assert canonical_fragment in text
        assert "/get/v1/" not in text
        assert "/post/v1/" not in text
        assert "/delete/v1/" not in text
        assert "/put/v1/" not in text


def test_docs_json_does_not_publish_stripe_webhook_page() -> None:
    docs_json = json.loads(
        (REPO_ROOT / "docs" / "docs.json").read_text(encoding="utf-8"))
    tabs = docs_json["navigation"]["tabs"]
    api_tab = next(tab for tab in tabs if tab["tab"] == "Control Plane API")
    stripe_group = next(group for group in api_tab["groups"]
                        if group["group"] == "Stripe")

    assert "POST /v1/billing/stripe/webhook" not in stripe_group["pages"]


def test_control_plane_docs_include_pagination_and_retry_guide() -> None:
    control_plane_index = (REPO_ROOT / "docs" / "tensormesh-api" /
                           "index.mdx").read_text(encoding="utf-8")
    pagination_guide = (REPO_ROOT / "docs" / "tensormesh-api" /
                        "pagination-and-retries.mdx").read_text(
                            encoding="utf-8")
    docs_json = json.loads(
        (REPO_ROOT / "docs" / "docs.json").read_text(encoding="utf-8"))
    tabs = docs_json["navigation"]["tabs"]
    api_tab = next(tab for tab in tabs if tab["tab"] == "Control Plane API")
    overview_group = next(group for group in api_tab["groups"]
                          if group["group"] == "Overview")

    assert "[Pagination And Retries](/tensormesh-api/pagination-and-retries)" in control_plane_index
    assert "Retry-After" in pagination_guide
    assert "page/size" in pagination_guide
    assert "page-token" in pagination_guide
    assert overview_group["pages"] == [
        "tensormesh-api/index",
        "tensormesh-api/pagination-and-retries",
    ]


def test_inference_api_entry_points_document_retry_and_rate_limit_behavior(
) -> None:
    api_index = (REPO_ROOT / "docs" / "api-reference" /
                 "index.mdx").read_text(encoding="utf-8")
    quickstart = (REPO_ROOT / "docs" /
                  "api-quickstart.mdx").read_text(encoding="utf-8")

    assert "429" in api_index
    assert "Retry-After" in api_index
    assert "429" in quickstart
    assert "Retry-After" in quickstart


def test_public_docs_tree_excludes_internal_superpowers_specs() -> None:
    assert not (REPO_ROOT / "docs" / "superpowers").exists()


def test_on_demand_reference_marks_extra_routing_as_near_compatible() -> None:
    on_demand_reference = (REPO_ROOT / "docs" / "api-reference" /
                           "on-demand.mdx").read_text(encoding="utf-8")
    on_demand_overlay = (REPO_ROOT / "docs" / "api-reference" / "src" /
                         "on-demand.overlay.yaml").read_text(encoding="utf-8")
    on_demand_openapi = (REPO_ROOT / "docs" / "api-reference" /
                         "on-demand.openapi.yaml").read_text(encoding="utf-8")

    assert "required `X-User-Id: <uuid>`" in on_demand_reference
    assert "Near-compatible chat completions endpoint" in on_demand_overlay
    assert "Attribution/Routing: `X-User-Id: <uuid>`" in on_demand_overlay
    assert "Near-compatible chat completions endpoint" in on_demand_openapi


def test_on_demand_reference_mentions_full_endpoint_inventory() -> None:
    on_demand_reference = (REPO_ROOT / "docs" / "api-reference" /
                           "on-demand.mdx").read_text(encoding="utf-8")

    for text in (
            "List Models",
            "Create Completion",
            "Create Response",
            "Tokenize Text",
            "Detokenize Tokens",
            "Health Check",
            "Get Version",
    ):
        assert text in on_demand_reference


def test_sdk_migration_and_inference_guides_make_scope_and_caveats_explicit(
) -> None:
    migration = (REPO_ROOT / "docs" / "sdk" / "guides" /
                 "migration-from-openai-fireworks.mdx").read_text(
                     encoding="utf-8")
    inference = (REPO_ROOT / "docs" / "sdk" / "guides" /
                 "inference.mdx").read_text(encoding="utf-8")

    assert "no embeddings client" in migration
    assert "serverless Responses client" in migration
    assert "not drop-in compatible" in migration
    assert "JSON Schema-style" in migration
    assert "## Tool Calling" in inference
    assert "## Structured Output" in inference
    assert "text-oriented helper" in inference


def test_cli_guides_shell_commands_match_real_command_and_option_surface(
) -> None:
    for guide_path in sorted(
        (REPO_ROOT / "docs" / "cli" / "guides").glob("*.mdx")):
        text = guide_path.read_text(encoding="utf-8")
        commands = _iter_tm_commands(text)
        assert commands, f"{guide_path.name}: expected at least one tm command"
        for tokens in commands:
            _validate_tm_command(tokens,
                                 f"{guide_path.name}: {' '.join(tokens)}")


def test_cli_docs_base_navigation_covers_generated_reference_surface() -> None:
    mod = load_script_module(CLI_DOCS_SCRIPT)
    model = mod.build_cli_docs_model(mod.cli)
    docs_base = json.loads(
        (REPO_ROOT / "docs" / "docs.base.json").read_text(encoding="utf-8"))
    tabs = docs_base["navigation"]["tabs"]
    cli_tab = next(tab for tab in tabs if tab["tab"] == "CLI")

    nav_reference_pages = {
        page
        for group in cli_tab["groups"] for page in group["pages"]
        if page.startswith("cli/reference/")
    }
    generated_pages = {
        command.page_path.removesuffix(".mdx")
        for command in model.commands
    }
    top_level_generated_pages = {
        command.page_path.removesuffix(".mdx")
        for command in model.commands if len(command.segments) <= 2
    }

    assert nav_reference_pages <= generated_pages
    assert top_level_generated_pages <= nav_reference_pages


def _python_blocks(text: str) -> list[str]:
    """Extract fenced ```python ... ``` code blocks from Markdown/MDX."""
    return re.findall(r"```python\n(.*?)```", text, flags=re.DOTALL)


def test_sdk_guide_python_snippets_parse_as_valid_python() -> None:
    """Every Python code block in every SDK guide must parse without SyntaxError."""
    guides_dir = REPO_ROOT / "docs" / "sdk" / "guides"
    for guide_path in sorted(guides_dir.glob("*.mdx")):
        text = guide_path.read_text(encoding="utf-8")
        for i, block in enumerate(_python_blocks(text)):
            try:
                ast.parse(block)
            except SyntaxError as exc:
                raise AssertionError(
                    f"{guide_path.name}: Python block {i + 1} has a syntax error: {exc}\n"
                    f"Block:\n{block}") from exc


def test_sdk_guide_python_snippets_use_correct_api_names() -> None:
    """SDK guide snippets must not reference API names that do not exist on the SDK."""
    from tensormesh.types.control_plane import Model
    from tensormesh.types.control_plane import User

    guides_dir = REPO_ROOT / "docs" / "sdk" / "guides"
    all_text = "\n".join(
        (guides_dir / name).read_text(encoding="utf-8")
        for name in ("control-plane.mdx", "getting-started.mdx"))
    # models.list() returns list[Model] — no size parameter, no .models attribute
    assert "models.list(size=" not in all_text, (
        "models.list() has no size parameter; use admin.models.list() for paged results"
    )
    assert "models_page.models" not in all_text, (
        "models.list() returns list[Model], not a page — iterate directly")
    # Model type does not have display_name
    model_fields = {f.name for f in Model.__dataclass_fields__.values()}
    assert "display_name" not in model_fields  # guard: keeps this test honest
    assert ".display_name" not in "\n".join(
        block for block in _python_blocks(all_text)
        if "models" in block and "Model" not in block.split("import", 1)[0]
    ), ("Model does not have a display_name attribute; use model.model_name")
    # User does have display_name — check it stays available
    user_fields = {f.name for f in User.__dataclass_fields__.values()}
    assert "display_name" in user_fields, (
        "User.display_name was removed — update sdk guide snippets that reference it"
    )
