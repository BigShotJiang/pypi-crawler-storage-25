from __future__ import annotations

import importlib
import inspect
from pathlib import Path
import re
import subprocess
import sys

REPO_ROOT = Path(__file__).resolve().parents[1]
RESOURCES_ROOT = REPO_ROOT / "src" / "tensormesh" / "resources"


def _normalized_source(path: Path) -> str:
    source = path.read_text(encoding="utf-8")
    source = source.replace("\\\n", " ")
    source = re.sub(r"[ \t]+", " ", source)
    return source


def _resource_source(name: str) -> str:
    return (RESOURCES_ROOT / name).read_text(encoding="utf-8")


def test_async_control_plane_uses_shared_helper_module() -> None:
    sources = [
        _resource_source("_control_plane_async_public.py"),
        _resource_source("_control_plane_async_billing.py"),
        _resource_source("_control_plane_async_admin.py"),
        _resource_source("_control_plane_async_observability_support.py"),
    ]

    for source in sources:
        assert "from tensormesh.resources._control_plane_shared import " in source
        assert "from tensormesh.resources.control_plane import _coerce_request" not in source
        assert "from tensormesh.resources.control_plane import _compact_params" not in source


def test_control_plane_surface_protocols_live_in_shared_module() -> None:
    shared_source = _resource_source("_control_plane_shared.py")
    sync_sources = [
        _resource_source("_control_plane_public.py"),
        _resource_source("_control_plane_billing.py"),
        _resource_source("_control_plane_admin.py"),
        _resource_source("_control_plane_observability_support.py"),
    ]
    async_sources = [
        _resource_source("_control_plane_async_public.py"),
        _resource_source("_control_plane_async_billing.py"),
        _resource_source("_control_plane_async_admin.py"),
        _resource_source("_control_plane_async_observability_support.py"),
    ]

    assert "class ControlPlaneSurfaceProtocol(Protocol):" in shared_source
    assert "class AsyncControlPlaneSurfaceProtocol(Protocol):" in shared_source

    for source in sync_sources:
        assert "ControlPlaneSurfaceProtocol as _ControlPlaneSurfaceProtocol" in source
        assert "class _ControlPlaneSurfaceProtocol(Protocol):" not in source

    for source in async_sources:
        assert "AsyncControlPlaneSurfaceProtocol as _AsyncControlPlaneSurfaceProtocol" in source
        assert "class _AsyncControlPlaneSurfaceProtocol(Protocol):" not in source


def test_sync_control_plane_uses_import_aliases_not_wrapper_functions(
) -> None:
    source = _resource_source("_control_plane_public.py")

    # Wrapper functions were replaced with direct alias imports matching the
    # async file's style.  Ensure none of the old wrapper definitions remain.
    assert "def _compact_params(" not in source
    assert "def _quote_path_value(" not in source
    assert "def _coerce_optional_int(" not in source
    assert "def _has_more_numbered_pages(" not in source
    assert "def _coerce_request(" not in source

    # The aliases must still be importable from the shared module.
    assert "compact_params as _compact_params" in source
    assert "quote_path_value as _quote_path_value" in source
    assert "coerce_request as _coerce_request" in source


def test_user_api_keys_clients_use_generated_pilot_module() -> None:
    sync_source = _resource_source("_control_plane_public.py")
    async_source = _resource_source("_control_plane_async_public.py")

    assert "from tensormesh.resources._control_plane_user_api_keys_generated import " in sync_source
    assert "from tensormesh.resources._control_plane_user_api_keys_generated import " in async_source


def test_activities_clients_use_generated_pilot_module() -> None:
    sync_source = _resource_source("_control_plane_public.py")
    async_source = _resource_source("_control_plane_async_public.py")

    assert "from tensormesh.resources._control_plane_activities_generated import " in sync_source
    assert "from tensormesh.resources._control_plane_activities_generated import " in async_source


def test_activities_clients_do_not_inline_pagination_logic() -> None:
    sync_source = _resource_source("_control_plane_public.py")
    async_source = _resource_source("_control_plane_async_public.py")

    # Both sync and async files must call activities_next_numbered_page rather than
    # inlining the coerce/has-more pagination logic inside ActivitiesClient.
    assert "activities_next_numbered_page(" in sync_source
    assert "activities_next_numbered_page(" in async_source


def test_numbered_page_next_is_in_shared_module() -> None:
    shared_source = (REPO_ROOT / "src" / "tensormesh" / "resources" /
                     "_control_plane_shared.py").read_text(encoding="utf-8")
    activities_source = (REPO_ROOT / "src" / "tensormesh" / "resources" /
                         "_control_plane_activities_generated.py").read_text(
                             encoding="utf-8")

    # Generic helper lives in shared, not reimplemented in generated files.
    assert "def numbered_page_next(" in shared_source
    assert "numbered_page_next" in shared_source.split("__all__")[1]
    assert "def numbered_page_next(" not in activities_source
    assert "from tensormesh.resources._control_plane_shared import numbered_page_next" in activities_source


def test_pagination_logic_not_inlined_in_resource_clients() -> None:
    sync_sources = [
        _resource_source("_control_plane_public.py"),
        _resource_source("_control_plane_admin.py"),
        _resource_source("_control_plane_observability_support.py"),
    ]
    async_sources = [
        _resource_source("_control_plane_async_public.py"),
        _resource_source("_control_plane_async_admin.py"),
        _resource_source("_control_plane_async_observability_support.py"),
    ]

    # The old three-line coerce/has-more block must not appear in either file.
    for source in (*sync_sources, *async_sources):
        assert "_coerce_optional_int(current.page)" not in source
        assert "_has_more_numbered_pages(" not in source


def test_cli_import_does_not_require_aiohttp_for_docs_generation() -> None:
    script = """
import importlib.abc
import pathlib
import sys

root = pathlib.Path.cwd()
sys.path.insert(0, str(root / "src"))

class _BlockAiohttp(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname == "aiohttp" or fullname.startswith("aiohttp."):
            raise ModuleNotFoundError("blocked aiohttp import")
        return None

sys.meta_path.insert(0, _BlockAiohttp())

import tensormesh_cli.cli  # noqa: F401
print("ok")
""".strip()

    result = subprocess.run(
        [sys.executable, "-c", script],
        cwd=REPO_ROOT,
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr
    assert result.stdout.strip() == "ok"

    # The grouped modules must still route pagination through shared helpers.
    assert "_numbered_page_next(" in _resource_source(
        "_control_plane_admin.py")
    assert "_numbered_page_next(" in _resource_source(
        "_control_plane_async_admin.py")
    assert "_numbered_page_next(" in _resource_source(
        "_control_plane_observability_support.py")
    assert "_numbered_page_next(" in _resource_source(
        "_control_plane_async_observability_support.py")


def test_operation_spec_is_defined_in_shared_module_not_generated_files(
) -> None:
    shared_source = _normalized_source(REPO_ROOT / "src" / "tensormesh" /
                                       "resources" /
                                       "_control_plane_shared.py")
    user_api_keys_source = _normalized_source(
        REPO_ROOT / "src" / "tensormesh" / "resources" /
        "_control_plane_user_api_keys_generated.py")
    activities_source = _normalized_source(
        REPO_ROOT / "src" / "tensormesh" / "resources" /
        "_control_plane_activities_generated.py")

    assert "class ControlPlaneOperationSpec" in shared_source
    assert "class ControlPlaneOperationSpec" not in user_api_keys_source
    assert "class ControlPlaneOperationSpec" not in activities_source
    assert "from tensormesh.resources._control_plane_shared import ControlPlaneOperationSpec" in user_api_keys_source
    assert "from tensormesh.resources._control_plane_shared import ControlPlaneOperationSpec" in activities_source


def test_inference_modules_use_shared_request_builder() -> None:
    sync_source = _normalized_source(RESOURCES_ROOT / "_inference_client.py")
    async_source = _normalized_source(RESOURCES_ROOT /
                                      "_inference_async_client.py")

    assert "from tensormesh.resources._inference_shared import build_chat_completion_request" in sync_source
    assert "from tensormesh.resources._inference_shared import build_chat_completion_request" in async_source
    assert "from tensormesh.resources.inference import build_chat_completion_request" not in async_source


def test_inference_wrapper_helpers_live_in_client_modules() -> None:
    sync_source = _normalized_source(RESOURCES_ROOT / "_inference_client.py")
    async_source = _normalized_source(RESOURCES_ROOT /
                                      "_inference_async_client.py")
    sync_public = _normalized_source(RESOURCES_ROOT / "inference.py")
    async_public = _normalized_source(RESOURCES_ROOT / "inference_async.py")

    assert "class ChatNamespace:" in sync_source
    assert "class ChatCompletionsWithRawResponse:" in sync_source
    assert "class ChatCompletionsWithStreamingResponse:" in sync_source
    assert "from ._inference_wrappers import" not in sync_source

    assert "class AsyncChatNamespace:" in async_source
    assert "class AsyncChatCompletionsWithRawResponse:" in async_source
    assert "class AsyncChatCompletionsWithStreamingResponse:" in async_source
    assert "from ._inference_async_wrappers import" not in async_source

    assert "from ._inference_client import ChatNamespace" in sync_public
    assert "from ._inference_wrappers import ChatNamespace" not in sync_public
    assert "from ._inference_async_client import AsyncChatNamespace" in async_public
    assert "from ._inference_async_wrappers import AsyncChatNamespace" not in async_public


def test_async_client_preserves_sync_helpers_and_awaited_close() -> None:
    source = _normalized_source(REPO_ROOT / "src" / "tensormesh" /
                                "_async_client.py")

    assert "async def close(self) -> None:" in source
    assert "await self._transport.close()" in source
    assert "@staticmethod" in source
    assert "def _reject_user_id(user_id: str | None) -> None:" in source
    assert "@staticmethod async def _reject_user_id" not in source
    assert "def _prepare_request(" in source
    assert "async def _prepare_request(" not in source
    assert "def _set_serverless_authorization_header(" in source
    assert "async def _set_serverless_authorization_header(" not in source


def test_sync_inference_surface_protocol_declares_stream_request() -> None:
    source = _resource_source("_inference_client.py")
    protocol_block = source.split("class ChatCompletionsClient:", 1)[0]

    assert "class _InferenceSurfaceProtocol(Protocol):" in protocol_block
    assert "def stream_request(" in protocol_block


# ---------------------------------------------------------------------------
# Public namespace completeness
# ---------------------------------------------------------------------------


def test_models_clients_use_generated_pilot_module() -> None:
    sync_source = _resource_source("_control_plane_public.py")
    async_source = _resource_source("_control_plane_async_public.py")

    assert "from tensormesh.resources._control_plane_models_generated import " in sync_source
    assert "from tensormesh.resources._control_plane_models_generated import " in async_source


def test_models_clients_use_typed_pagination_wrapper() -> None:
    sync_source = _resource_source("_control_plane_admin.py")
    async_source = _resource_source("_control_plane_async_admin.py")

    # AdminModelsClient must delegate to the typed wrapper, not inline numbered_page_next.
    assert "models_next_numbered_page(" in sync_source
    assert "models_next_numbered_page(" in async_source


def test_models_generated_module_uses_shared_infrastructure() -> None:
    models_source = _normalized_source(REPO_ROOT / "src" / "tensormesh" /
                                       "resources" /
                                       "_control_plane_models_generated.py")

    assert "from tensormesh.resources._control_plane_shared import ControlPlaneOperationSpec" in models_source
    assert "from tensormesh.resources._control_plane_shared import numbered_page_next" in models_source
    assert "class ControlPlaneOperationSpec" not in models_source
    assert "def numbered_page_next(" not in models_source


def test_all_public_names_are_importable_from_tensormesh() -> None:
    import tensormesh
    for name in tensormesh.__all__:
        assert hasattr(tensormesh, name), (
            f"tensormesh.__all__ contains '{name}' but it is not importable")


# ---------------------------------------------------------------------------
# Sync / async resource client parity
# ---------------------------------------------------------------------------


def _public_methods(cls: type) -> set[str]:
    return {
        name
        for name in dir(cls)
        if not name.startswith("_") and callable(getattr(cls, name))
    }


def test_control_plane_resource_clients_have_async_parity() -> None:
    sync_mod = importlib.import_module("tensormesh.resources.control_plane")
    async_mod = importlib.import_module(
        "tensormesh.resources.control_plane_async")

    for name, obj in inspect.getmembers(sync_mod, inspect.isclass):
        if not name.endswith("Client"):
            continue
        async_name = f"Async{name}"
        async_cls = getattr(async_mod, async_name, None)
        assert async_cls is not None, (
            f"Async counterpart missing: expected '{async_name}' in control_plane_async"
        )
        sync_methods = _public_methods(obj)
        async_methods = _public_methods(async_cls)
        missing = sync_methods - async_methods
        assert not missing, (
            f"{async_name} is missing methods present in {name}: {sorted(missing)}"
        )


def test_inference_resource_clients_have_async_parity() -> None:
    sync_mod = importlib.import_module("tensormesh.resources.inference")
    async_mod = importlib.import_module("tensormesh.resources.inference_async")

    for name, obj in inspect.getmembers(sync_mod, inspect.isclass):
        if obj.__module__ != sync_mod.__name__ or name.startswith("_"):
            continue
        async_name = f"Async{name}"
        async_cls = getattr(async_mod, async_name, None)
        assert async_cls is not None, (
            f"Async counterpart missing: expected '{async_name}' in inference_async"
        )
        sync_methods = _public_methods(obj)
        async_methods = _public_methods(async_cls)
        missing = sync_methods - async_methods
        assert not missing, (
            f"{async_name} is missing methods present in {name}: {sorted(missing)}"
        )


def test_generated_pilot_modules_match_generator_output() -> None:
    """Generator --check mode must exit 0; drift means generated files are stale."""
    script = REPO_ROOT / "scripts" / "generate-control-plane-resources.py"
    result = subprocess.run(
        [sys.executable, str(script), "--check"],
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, (
        "Generator --check detected drift in generated pilot modules.\n"
        "Run: python3 scripts/generate-control-plane-resources.py\n" +
        result.stdout)


def test_async_sdk_mirrors_match_generator_output() -> None:
    script = REPO_ROOT / "scripts" / "generate-async-sdk.py"
    result = subprocess.run(
        [sys.executable, str(script), "--check"],
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, (
        "Async SDK generator --check detected drift in generated async mirrors.\n"
        "Run: python3 scripts/generate-async-sdk.py\n" + result.stdout)


def test_sync_script_regenerates_control_plane_resource_modules() -> None:
    script = REPO_ROOT / "scripts" / "sync-tensormesh-api.sh"
    contents = script.read_text(encoding="utf-8")

    assert "./scripts/generate-control-plane-resources.py" in contents
