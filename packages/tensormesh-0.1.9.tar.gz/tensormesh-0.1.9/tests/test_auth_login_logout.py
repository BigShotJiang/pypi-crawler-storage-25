from __future__ import annotations

from pathlib import Path
from typing import Any
from unittest.mock import patch

from tests.cli_test_utils import controlplane_auth_json_path
from tests.cli_test_utils import controlplane_env
from tests.cli_test_utils import invoke_tm
from tests.cli_test_utils import patch_controlplane_base


def test_auth_login_invokes_flow_with_resolved_runtime(
    monkeypatch,
    tmp_path: Path,
) -> None:
    captured: dict[str, Any] = {}

    def fake_login(base: str, token_path: Path, *, open_browser: bool,
                   timeout_s: float, max_wait_s: float, verify: bool | str,
                   log) -> None:
        captured.update({
            "base": base,
            "token_path": token_path,
            "open_browser": open_browser,
            "timeout_s": timeout_s,
            "max_wait_s": max_wait_s,
            "verify": verify,
            "log_type": type(log).__name__,
        })
        if log is not None:
            log("visit https://control.example/login")

    import tensormesh_cli.commands.auth_cmd as auth_cmd

    monkeypatch.setattr(auth_cmd.auth, "login", fake_login)

    auth_json = controlplane_auth_json_path(tmp_path)
    with patch_controlplane_base("https://control.example"):
        result = invoke_tm(
            [
                "auth",
                "login",
                "--no-open-browser",
                "--max-wait-seconds",
                "45",
                "--timeout",
                "5",
            ],
            env=controlplane_env(home=tmp_path),
        )

    assert result.exit_code == 0, result.output
    assert captured == {
        "base": "https://control.example",
        "token_path": auth_json,
        "open_browser": False,
        "timeout_s": 5.0,
        "max_wait_s": 45.0,
        "verify": True,
        "log_type": "function",
    }
    assert "visit https://control.example/login" in result.output


def test_auth_login_rejects_invalid_timeout_and_runtime_failures(
    monkeypatch,
    tmp_path: Path,
) -> None:
    auth_json = controlplane_auth_json_path(tmp_path)

    invalid_timeout = invoke_tm(
        [
            "auth",
            "login",
            "--timeout",
            "0",
        ],
        env=controlplane_env(home=tmp_path),
    )

    assert invalid_timeout.exit_code != 0
    assert "Timeout must be greater than 0 seconds." in invalid_timeout.output

    invalid_max_wait = invoke_tm(
        [
            "auth",
            "login",
            "--max-wait-seconds",
            "0",
        ],
        env=controlplane_env(home=tmp_path),
    )

    assert invalid_max_wait.exit_code != 0
    assert "Timeout must be greater than 0 seconds." in invalid_max_wait.output

    import tensormesh_cli.commands.auth_cmd as auth_cmd

    def fail_login(base: str, token_path: Path, *, open_browser: bool,
                   timeout_s: float, max_wait_s: float, verify: bool | str,
                   log) -> None:
        raise RuntimeError("browser launch failed")

    monkeypatch.setattr(auth_cmd.auth, "login", fail_login)

    with patch_controlplane_base("https://control.example"):
        failed = invoke_tm(
            [
                "auth",
                "login",
            ],
            env=controlplane_env(home=tmp_path),
        )

    assert failed.exit_code != 0
    assert "browser launch failed" in failed.output
    assert f"Token path: {auth_json}" in failed.output


def test_auth_login_quiet_suppresses_login_flow_logs(
    monkeypatch,
    tmp_path: Path,
) -> None:
    seen: list[str] = []

    def fake_login(base: str, token_path: Path, *, open_browser: bool,
                   timeout_s: float, max_wait_s: float, verify: bool | str,
                   log) -> None:
        if log is not None:
            log("visit https://control.example/login")
        seen.append(type(log).__name__)

    import tensormesh_cli.commands.auth_cmd as auth_cmd

    monkeypatch.setattr(auth_cmd.auth, "login", fake_login)

    with patch_controlplane_base("https://control.example"):
        result = invoke_tm(
            [
                "--quiet",
                "auth",
                "login",
            ],
            env=controlplane_env(home=tmp_path),
        )

    assert result.exit_code == 0, result.output
    assert seen == ["NoneType"]
    assert "visit https://control.example/login" not in result.output


def test_auth_login_quiet_no_open_browser_still_prints_login_url(
    monkeypatch,
    tmp_path: Path,
) -> None:
    seen: list[str] = []

    def fake_login(base: str, token_path: Path, *, open_browser: bool,
                   timeout_s: float, max_wait_s: float, verify: bool | str,
                   log) -> None:
        if log is not None:
            log("Open browser: https://control.example/login")
            log(f"Login success. Tokens saved to {token_path}")
        seen.append(type(log).__name__)

    import tensormesh_cli.commands.auth_cmd as auth_cmd

    monkeypatch.setattr(auth_cmd.auth, "login", fake_login)

    with patch_controlplane_base("https://control.example"):
        result = invoke_tm(
            [
                "--quiet",
                "auth",
                "login",
                "--no-open-browser",
            ],
            env=controlplane_env(home=tmp_path),
        )

    assert result.exit_code == 0, result.output
    assert seen == ["function"]
    assert "Open browser: https://control.example/login" in result.output
    assert "Login success. Tokens saved" not in result.output


def test_auth_refresh_invokes_flow_and_prints_success(
    monkeypatch,
    tmp_path: Path,
) -> None:
    captured: dict[str, Any] = {}

    def fake_refresh(base: str, token_path: Path, *, timeout_s: float,
                     verify: bool | str) -> None:
        captured.update({
            "base": base,
            "token_path": token_path,
            "timeout_s": timeout_s,
            "verify": verify,
        })

    import tensormesh_cli.commands.auth_cmd as auth_cmd

    monkeypatch.setattr(auth_cmd.auth, "refresh", fake_refresh)

    auth_json = controlplane_auth_json_path(tmp_path)
    with patch_controlplane_base("https://control.example"):
        result = invoke_tm(
            [
                "auth",
                "refresh",
                "--timeout",
                "6",
            ],
            env=controlplane_env(home=tmp_path),
        )

    assert result.exit_code == 0, result.output
    assert "Refresh success. Tokens updated." in result.output
    assert captured == {
        "base": "https://control.example",
        "token_path": auth_json,
        "timeout_s": 6.0,
        "verify": True,
    }


def test_auth_logout_deletes_token_file(tmp_path: Path) -> None:
    auth_json = controlplane_auth_json_path(tmp_path)
    auth_json.write_text('{"access_token":"tok"}\n', encoding="utf-8")

    result = invoke_tm(
        [
            "auth",
            "logout",
        ],
        env=controlplane_env(home=tmp_path, seed_file=False),
    )

    assert result.exit_code == 0, result.output
    assert not auth_json.exists()
    assert "Deleted token file" in result.output


def test_auth_logout_handles_missing_and_undeletable_token_file(
    tmp_path: Path,
    monkeypatch,
) -> None:
    missing_result = invoke_tm(
        [
            "auth",
            "logout",
        ],
        env=controlplane_env(home=tmp_path, seed_file=False),
    )

    assert missing_result.exit_code == 0, missing_result.output
    assert "Already logged out (no token file)" in missing_result.output

    auth_json = controlplane_auth_json_path(tmp_path)
    auth_json.write_text('{"access_token":"tok"}\n', encoding="utf-8")

    def fail_unlink(self: Path) -> None:
        raise OSError("permission denied")

    with patch.object(Path, "unlink", fail_unlink):
        failed = invoke_tm(
            [
                "auth",
                "logout",
            ],
            env=controlplane_env(home=tmp_path, seed_file=False),
        )

    assert failed.exit_code != 0
    assert "Failed to delete token file" in failed.output
    assert "permission denied" in failed.output


def test_auth_logout_prompts_for_confirmation_in_interactive_shell(
    tmp_path: Path, ) -> None:
    auth_json = controlplane_auth_json_path(tmp_path)
    auth_json.write_text('{"access_token":"tok"}\n', encoding="utf-8")

    with patch(
            "tensormesh_cli.commands.auth_cmd._should_confirm_auth_file_delete",
            return_value=True):
        result = invoke_tm(
            [
                "auth",
                "logout",
            ],
            env=controlplane_env(home=tmp_path, seed_file=False),
            input_text="y\n",
        )

    assert result.exit_code == 0, result.output
    assert "Delete token file:" in result.output
    assert not auth_json.exists()


def test_auth_logout_yes_skips_interactive_confirmation(
        tmp_path: Path) -> None:
    auth_json = controlplane_auth_json_path(tmp_path)
    auth_json.write_text('{"access_token":"tok"}\n', encoding="utf-8")

    with patch(
            "tensormesh_cli.commands.auth_cmd._should_confirm_auth_file_delete",
            return_value=True):
        result = invoke_tm(
            [
                "auth",
                "logout",
                "--yes",
            ],
            env=controlplane_env(home=tmp_path, seed_file=False),
        )

    assert result.exit_code == 0, result.output
    assert "Delete token file:" not in result.output
    assert not auth_json.exists()
