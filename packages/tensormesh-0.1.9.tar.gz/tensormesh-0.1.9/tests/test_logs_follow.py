from __future__ import annotations

import json

import click

from tensormesh_cli.cli import cli
import tensormesh_cli.commands.logs_cmd as logs_cmd
from tests.cli_test_utils import controlplane_env
from tests.http_test_utils import json_response
from tests.http_test_utils import serve_controlplane_routes
from tests.http_test_utils import text_response


def _logs_route():
    state = {"polls": 0}

    def _route(_request):
        state["polls"] += 1
        logs = [{"timestamp": "2024-01-01T00:00:00Z", "message": "a"}]
        if state["polls"] >= 2:
            logs.append({"timestamp": "2024-01-01T00:00:01Z", "message": "b"})
        return json_response({"logs": logs})

    return {
        ("GET", "/v1/observability/deployments/dep1/logs"): _route,
    }


def test_logs_follow_polls_and_prints_new_lines(runner) -> None:
    sleep_calls = {"count": 0}

    def fake_sleep(seconds: float) -> None:
        sleep_calls["count"] += 1
        if sleep_calls["count"] >= 2:
            raise KeyboardInterrupt()

    with serve_controlplane_routes(_logs_route()):
        original_sleep = logs_cmd.time.sleep
        logs_cmd.time.sleep = fake_sleep
        try:
            result = runner.invoke(
                cli,
                [
                    "logs",
                    "dep1",
                    "--follow",
                    "--interval",
                    "1",
                ],
                env=controlplane_env(),
            )
        finally:
            logs_cmd.time.sleep = original_sleep

    assert result.exit_code == 0, result.output
    assert "2024-01-01T00:00:00Z a" in result.output
    assert "2024-01-01T00:00:01Z b" in result.output


def test_logs_follow_fails_on_non_json_response(runner) -> None:
    with serve_controlplane_routes({
        ("GET", "/v1/observability/deployments/dep1/logs"):
            text_response("not-json"),
    }):
        result = runner.invoke(
            cli,
            [
                "logs",
                "dep1",
                "--follow",
                "--interval",
                "1",
            ],
            env=controlplane_env(),
        )

    assert result.exit_code != 0
    assert "Invalid logs response: expected JSON." in result.output
    assert "Raw response: not-json" in result.output


def test_render_log_item_formats_supported_shapes() -> None:
    assert logs_cmd._render_log_item({
        "timestamp": "2024-01-01T00:00:00Z",
        "message": "hello\n",
    }) == "2024-01-01T00:00:00Z hello"
    assert logs_cmd._render_log_item({"message": "hello\n"}) == "hello"
    assert logs_cmd._render_log_item("hello\n") == "hello"
    assert logs_cmd._render_log_item({"other":
                                      "value"}) == "{'other': 'value'}"


def test_logs_follow_rejects_non_positive_interval(runner,
                                                   monkeypatch) -> None:

    def fail_fetch(*args, **kwargs):
        raise click.ClickException("follow fetch should not run")

    monkeypatch.setattr(logs_cmd, "_fetch_logs_data", fail_fetch)
    result = runner.invoke(
        cli,
        [
            "logs",
            "dep1",
            "--follow",
            "--interval",
            "0",
        ],
        env=controlplane_env(),
    )

    assert result.exit_code != 0
    assert "`--interval` must be a finite number greater than 0." in result.output


def test_logs_follow_preserves_repeated_identical_lines(runner) -> None:
    sleep_calls = {"count": 0}

    def fake_sleep(seconds: float) -> None:
        sleep_calls["count"] += 1
        raise KeyboardInterrupt()

    def route(_request):
        return json_response({
            "logs": [
                {
                    "timestamp": "2024-01-01T00:00:00Z",
                    "message": "same",
                    "id": "log-1",
                },
                {
                    "timestamp": "2024-01-01T00:00:00Z",
                    "message": "same",
                    "id": "log-2",
                },
            ]
        })

    with serve_controlplane_routes({
        ("GET", "/v1/observability/deployments/dep1/logs"):
            route,
    }):
        original_sleep = logs_cmd.time.sleep
        logs_cmd.time.sleep = fake_sleep
        try:
            result = runner.invoke(
                cli,
                [
                    "logs",
                    "dep1",
                    "--follow",
                    "--interval",
                    "1",
                ],
                env=controlplane_env(),
            )
        finally:
            logs_cmd.time.sleep = original_sleep

    assert result.exit_code == 0, result.output
    assert result.output.count("2024-01-01T00:00:00Z same\n") == 2


def test_logs_follow_honors_json_output(runner) -> None:
    sleep_calls = {"count": 0}

    def fake_sleep(seconds: float) -> None:
        sleep_calls["count"] += 1
        raise KeyboardInterrupt()

    with serve_controlplane_routes(_logs_route()):
        original_sleep = logs_cmd.time.sleep
        logs_cmd.time.sleep = fake_sleep
        try:
            result = runner.invoke(
                cli,
                [
                    "--output",
                    "json",
                    "logs",
                    "dep1",
                    "--follow",
                    "--interval",
                    "1",
                ],
                env=controlplane_env(),
            )
        finally:
            logs_cmd.time.sleep = original_sleep

    assert result.exit_code == 0, result.output
    data = json.loads(result.output)
    assert data["timestamp"] == "2024-01-01T00:00:00Z"
    assert data["message"] == "a"


def test_logs_follow_honors_yaml_output(runner) -> None:
    sleep_calls = {"count": 0}

    def fake_sleep(seconds: float) -> None:
        sleep_calls["count"] += 1
        raise KeyboardInterrupt()

    with serve_controlplane_routes(_logs_route()):
        original_sleep = logs_cmd.time.sleep
        logs_cmd.time.sleep = fake_sleep
        try:
            result = runner.invoke(
                cli,
                [
                    "--output",
                    "yaml",
                    "logs",
                    "dep1",
                    "--follow",
                    "--interval",
                    "1",
                ],
                env=controlplane_env(),
            )
        finally:
            logs_cmd.time.sleep = original_sleep

    assert result.exit_code == 0, result.output
    assert "timestamp: '2024-01-01T00:00:00Z'" in result.output
    assert "message: a" in result.output


def test_logs_follow_honors_raw_output(runner) -> None:
    sleep_calls = {"count": 0}

    def fake_sleep(seconds: float) -> None:
        sleep_calls["count"] += 1
        raise KeyboardInterrupt()

    with serve_controlplane_routes(_logs_route()):
        original_sleep = logs_cmd.time.sleep
        logs_cmd.time.sleep = fake_sleep
        try:
            result = runner.invoke(
                cli,
                [
                    "--output",
                    "raw",
                    "logs",
                    "dep1",
                    "--follow",
                    "--interval",
                    "1",
                ],
                env=controlplane_env(),
            )
        finally:
            logs_cmd.time.sleep = original_sleep

    assert result.exit_code == 0, result.output
    assert result.output == "2024-01-01T00:00:00Z a\n"


def test_logs_follow_honors_table_output(runner) -> None:
    sleep_calls = {"count": 0}

    def fake_sleep(seconds: float) -> None:
        sleep_calls["count"] += 1
        raise KeyboardInterrupt()

    with serve_controlplane_routes(_logs_route()):
        original_sleep = logs_cmd.time.sleep
        logs_cmd.time.sleep = fake_sleep
        try:
            result = runner.invoke(
                cli,
                [
                    "--output",
                    "table",
                    "logs",
                    "dep1",
                    "--follow",
                    "--interval",
                    "1",
                ],
                env=controlplane_env(),
            )
        finally:
            logs_cmd.time.sleep = original_sleep

    assert result.exit_code == 0, result.output
    assert "timestamp" in result.output
    assert "message" in result.output
    assert "2024-01-01T00:00:00Z" in result.output
