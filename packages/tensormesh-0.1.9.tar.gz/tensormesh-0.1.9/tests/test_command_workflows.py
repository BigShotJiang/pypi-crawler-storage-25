from __future__ import annotations

from tests.cli_test_utils import controlplane_env
from tests.cli_test_utils import invoke_tm
from tests.http_test_utils import assert_last_request
from tests.http_test_utils import json_response
from tests.http_test_utils import serve_controlplane_routes


def _workflow_routes():
    return {
        ("POST", "/v1/admin/billing/balances"): json_response({"balances":
                                                               []}),
        ("POST", "/v1/users/accept-tos"): json_response({"user": {
            "id": "u1"
        }}),
        ("GET", "/v1/admin/users"): json_response({"users": []}),
        ("GET", "/v1/support/tickets/t1"):
        json_response({"ticket": {
            "id": "t1"
        }}),
        ("GET", "/v1/users/u1"): json_response({"user": {
            "id": "u1"
        }}),
    }


def test_admin_billing_balances_get_builds_payload_from_flags() -> None:
    with serve_controlplane_routes(_workflow_routes()) as recorder:
        result = invoke_tm(
            [
                "--output",
                "json",
                "admin",
                "billing",
                "balances",
                "get",
                "--user-id",
                "admin1",
                "--target-user-id",
                "u1",
                "--target-user-id",
                "u2",
            ],
            env=controlplane_env(),
        )

    assert result.exit_code == 0, result.output
    assert_last_request(
        recorder,
        method="POST",
        path="/v1/admin/billing/balances",
        body={
            "userId": "admin1",
            "targetUserIds": ["u1", "u2"],
        },
    )


def test_admin_billing_balances_get_builds_payload_from_json() -> None:
    with serve_controlplane_routes(_workflow_routes()) as recorder:
        result = invoke_tm(
            [
                "--output",
                "json",
                "admin",
                "billing",
                "balances",
                "get",
                "--json",
                '{"userId":"admin2","targetUserIds":["u4"]}',
            ],
            env=controlplane_env(),
        )

    assert result.exit_code == 0, result.output
    assert_last_request(
        recorder,
        method="POST",
        path="/v1/admin/billing/balances",
        body={
            "userId": "admin2",
            "targetUserIds": ["u4"],
        },
    )


def test_users_accept_tos_posts_empty_object() -> None:
    with serve_controlplane_routes(_workflow_routes()) as recorder:
        result = invoke_tm(
            ["--output", "json", "users", "accept-tos"],
            env=controlplane_env(),
        )

    assert result.exit_code == 0, result.output
    assert_last_request(
        recorder,
        method="POST",
        path="/v1/users/accept-tos",
        body={},
    )


def test_admin_users_list_hits_collection_endpoint() -> None:
    with serve_controlplane_routes(_workflow_routes()) as recorder:
        result = invoke_tm(
            ["--output", "json", "admin", "users", "list"],
            env=controlplane_env(),
        )

    assert result.exit_code == 0, result.output
    assert_last_request(
        recorder,
        method="GET",
        path="/v1/admin/users",
        query={},
    )


def test_tickets_get_builds_resource_path() -> None:
    with serve_controlplane_routes(_workflow_routes()) as recorder:
        result = invoke_tm(
            ["--output", "json", "tickets", "get", "t1"],
            env=controlplane_env(),
        )

    assert result.exit_code == 0, result.output
    assert_last_request(
        recorder,
        method="GET",
        path="/v1/support/tickets/t1",
        query={},
    )
