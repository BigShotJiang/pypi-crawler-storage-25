from __future__ import annotations

import pytest

from tensormesh_cli.http.gateway import normalize_gateway_user_id


def test_normalize_gateway_user_id_returns_normalized_uuid() -> None:
    assert normalize_gateway_user_id(
        "00000000-0000-0000-0000-000000000000"
    ) == "00000000-0000-0000-0000-000000000000"


def test_normalize_gateway_user_id_rejects_missing_value() -> None:
    with pytest.raises(ValueError, match="Missing gateway user id."):
        normalize_gateway_user_id(" ")


def test_normalize_gateway_user_id_rejects_invalid_uuid() -> None:
    with pytest.raises(ValueError, match="Invalid gateway user id."):
        normalize_gateway_user_id("not-a-uuid")
