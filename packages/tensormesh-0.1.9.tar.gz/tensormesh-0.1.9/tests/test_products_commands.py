from __future__ import annotations

from tests.cli_test_utils import controlplane_env
from tests.cli_test_utils import invoke_tm
from tests.http_test_utils import assert_last_request
from tests.http_test_utils import json_response
from tests.http_test_utils import serve_controlplane_routes


def _product_routes():
    return {
        ("GET", "/v1/products"): json_response({"products": [{
            "id": "p1"
        }]}),
        ("GET", "/v1/admin/products"):
        json_response({"products": [{
            "id": "p1"
        }]}),
        ("POST", "/v1/admin/products"):
        json_response({"product": {
            "id": "p1"
        }}),
        ("DELETE", "/v1/products/p1"): json_response({"ok": True}),
    }


def test_products_list_hits_collection_endpoint() -> None:
    with serve_controlplane_routes(_product_routes()) as recorder:
        result = invoke_tm(
            ["--output", "json", "products", "list"],
            env=controlplane_env(),
        )

    assert result.exit_code == 0, result.output
    assert_last_request(
        recorder,
        method="GET",
        path="/v1/products",
    )


def test_admin_products_list_hits_admin_collection_endpoint() -> None:
    with serve_controlplane_routes(_product_routes()) as recorder:
        result = invoke_tm(
            ["--output", "json", "admin", "products", "list"],
            env=controlplane_env(),
        )

    assert result.exit_code == 0, result.output
    assert_last_request(
        recorder,
        method="GET",
        path="/v1/admin/products",
    )


def test_admin_products_upsert_posts_payload() -> None:
    payload = {
        "product": {
            "id": "p1",
            "name": "Starter",
            "requiredGpuNum": 1,
            "family": "gpu",
            "isActive": True,
        }
    }
    with serve_controlplane_routes(_product_routes()) as recorder:
        result = invoke_tm(
            [
                "--output",
                "json",
                "admin",
                "products",
                "upsert",
                "--json",
                '{"product":{"id":"p1","name":"Starter","requiredGpuNum":1,"family":"gpu","isActive":true}}',
                "--yes",
            ],
            env=controlplane_env(),
        )

    assert result.exit_code == 0, result.output
    assert_last_request(
        recorder,
        method="POST",
        path="/v1/admin/products",
        body=payload,
    )


def test_admin_products_delete_requires_confirmation_or_yes() -> None:
    with serve_controlplane_routes(_product_routes()) as recorder:
        r_abort = invoke_tm(
            ["admin", "products", "delete", "p1"],
            env=controlplane_env(),
            input_text="n\n",
        )
        assert r_abort.exit_code != 0

        result = invoke_tm(
            [
                "--output",
                "json",
                "admin",
                "products",
                "delete",
                "p1",
                "--yes",
            ],
            env=controlplane_env(),
        )

    assert result.exit_code == 0, result.output
    assert_last_request(
        recorder,
        method="DELETE",
        path="/v1/products/p1",
    )
