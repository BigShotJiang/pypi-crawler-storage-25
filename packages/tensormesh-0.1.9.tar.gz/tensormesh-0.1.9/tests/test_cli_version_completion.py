from __future__ import annotations

import sys
from unittest.mock import patch

from tensormesh.build_info import __version__
from tests.cli_test_utils import invoke_tm
from tests.cli_test_utils import load_result_json


def test_version_flag_prints_package_version() -> None:
    result = invoke_tm(["--version"])
    assert result.exit_code == 0, result.output
    assert __version__ in result.output


def test_version_command_supports_human_and_json_output() -> None:
    text_result = invoke_tm(["version"])
    assert text_result.exit_code == 0, text_result.output
    assert f"CLI version: {__version__}" in text_result.output
    assert "Python:" in text_result.output

    json_result = invoke_tm(["--output", "json", "version"])
    data = load_result_json(json_result)
    assert data["cli_version"] == __version__
    assert "python_version" in data
    assert "platform" in data
    assert data["requires_python"] == ">=3.12"
    assert data["distribution_model"] == "python-source"
    assert data["install_guide"] == "/cli/guides/installation"


def test_version_command_reports_python_package_when_imported_from_site_packages(
) -> None:
    with patch("tensormesh_cli.commands.version_cmd.find_spec") as find_spec:

        class _Spec:
            origin = "/tmp/venv/lib/python3.12/site-packages/tensormesh_cli/cli.py"

        find_spec.return_value = _Spec()
        result = invoke_tm(["--output", "json", "version"])

    data = load_result_json(result)
    assert data["distribution_model"] == "python-package"


def test_version_command_reports_standalone_binary_for_frozen_runtime(
) -> None:
    with patch("tensormesh_cli.commands.version_cmd.find_spec") as find_spec, \
            patch.object(sys, "frozen", True, create=True):

        class _Spec:
            origin = "/tmp/_MEI123/tensormesh_cli/cli.py"

        find_spec.return_value = _Spec()
        result = invoke_tm(["--output", "json", "version"])

    data = load_result_json(result)
    assert data["distribution_model"] == "standalone-binary"


def test_version_command_raw_output_is_version_only() -> None:
    result = invoke_tm(["--output", "raw", "version"])
    assert result.exit_code == 0, result.output
    assert result.output == f"{__version__}\n"


def test_completion_bash_outputs_click_completion_snippet_or_script() -> None:
    result = invoke_tm(["completion", "bash"])
    assert result.exit_code == 0, result.output
    assert "_TM_COMPLETE" in result.output
