from __future__ import annotations

import json
from typing import Any

import pytest

from tests.cli_test_utils import gateway_env
from tests.cli_test_utils import invoke_tm
from tests.http_test_utils import assert_last_request
from tests.http_test_utils import bytes_response
from tests.http_test_utils import json_response
from tests.http_test_utils import make_http_handler
from tests.http_test_utils import RequestRecorder
from tests.http_test_utils import serve_http_server


def test_infer_models_lists_serverless_models() -> None:
    recorder = RequestRecorder()
    routes = {
        ("GET", "/v1/models"): {
            "object":
            "list",
            "data": [{
                "id": "openai/gpt-oss-20b",
                "object": "model",
                "owned_by": "vllm",
            }],
        }
    }

    with serve_http_server(make_http_handler(routes=routes,
                                             recorder=recorder)) as base:
        result = invoke_tm(
            [
                "--output",
                "json",
                "infer",
                "models",
                "--api-key",
                "test_key",
                "--base-url",
                base,
            ],
            env=gateway_env(api_key="test_key"),
        )

    assert result.exit_code == 0, result.output
    assert_last_request(
        recorder,
        method="GET",
        path="/v1/models",
        headers={"Authorization": "Bearer test_key"},
    )
    payload = json.loads(result.output)
    assert payload["data"][0]["id"] == "openai/gpt-oss-20b"


@pytest.mark.parametrize(("command", "path"), [
    ("models", "/v1/models"),
    ("health", "/health"),
    ("version", "/version"),
])
def test_infer_serverless_public_get_commands_require_api_key_on_custom_base_url(
    command: str,
    path: str,
) -> None:
    recorder = RequestRecorder()
    routes = {
        ("GET", path): json_response({"ok": True}),
    }

    with serve_http_server(make_http_handler(routes=routes,
                                             recorder=recorder)) as base:
        result = invoke_tm(
            [
                "--output",
                "json" if command == "models" else "text",
                "infer",
                command,
                "--base-url",
                base,
            ],
            env={},
        )

    assert result.exit_code != 0
    assert result.exception is not None
    assert "Missing inference API key" in str(result.exception)
    assert recorder.requests == []


@pytest.mark.parametrize(
    ("command", "path", "body", "response_payload", "expected_output"),
    [
        (
            "completions",
            "/v1/completions",
            {
                "model": "openai/gpt-oss-20b",
                "prompt": "Say ok.",
            },
            {
                "id": "cmpl_1",
                "object": "text_completion",
                "created": 1,
                "model": "openai/gpt-oss-20b",
                "choices": [{
                    "text": "ok",
                    "index": 0,
                    "finish_reason": "stop",
                }],
            },
            "ok\n",
        ),
        (
            "responses",
            "/v1/responses",
            {
                "model": "openai/gpt-oss-20b",
                "input": "Say hello.",
            },
            {
                "id":
                "resp_1",
                "object":
                "response",
                "created_at":
                1,
                "model":
                "openai/gpt-oss-20b",
                "output":
                [{
                    "id": "out_1",
                    "type": "message",
                    "content": [{
                        "type": "output_text",
                        "text": "hello",
                    }],
                }],
            },
            "hello\n",
        ),
        (
            "tokenize",
            "/tokenize",
            {
                "model": "openai/gpt-oss-20b",
                "prompt": "Hello",
            },
            {
                "count": 2,
                "max_model_len": 131072,
                "tokens": [15496, 0],
                "token_strs": ["Hello", "!"],
            },
            None,
        ),
        (
            "tokenize",
            "/tokenize",
            {
                "model": "openai/gpt-oss-20b",
                "messages": [{
                    "role": "user",
                    "content": "Hello",
                }],
            },
            {
                "count": 2,
                "max_model_len": 131072,
                "tokens": [15496, 0],
                "token_strs": ["Hello", "!"],
            },
            None,
        ),
        (
            "detokenize",
            "/detokenize",
            {
                "model": "openai/gpt-oss-20b",
                "tokens": [15496, 0],
            },
            {
                "prompt": "Hello!",
            },
            None,
        ),
    ],
)
def test_infer_serverless_post_commands_hit_verified_paths(
    command: str,
    path: str,
    body: dict[str, Any],
    response_payload: dict[str, Any],
    expected_output: str | None,
) -> None:
    recorder = RequestRecorder()
    routes = {
        ("POST", path): json_response(response_payload),
    }

    with serve_http_server(make_http_handler(routes=routes,
                                             recorder=recorder)) as base:
        result = invoke_tm(
            [
                "infer",
                command,
                "--api-key",
                "test_key",
                "--base-url",
                base,
                "--json",
                json.dumps(body),
            ],
            env=gateway_env(api_key="test_key"),
        )

    assert result.exit_code == 0, result.output
    assert_last_request(
        recorder,
        method="POST",
        path=path,
        body=body,
        headers={
            "Authorization": "Bearer test_key",
            "Content-Type": "application/json",
        },
    )
    if expected_output is not None:
        assert result.output == expected_output


@pytest.mark.parametrize(
    ("command", "path", "response_payload", "expected_output"),
    [
        ("health", "/health", {
            "status": "healthy"
        }, "healthy\n"),
        ("version", "/version", {
            "version": "0.0.0"
        }, "0.0.0\n"),
    ],
)
def test_infer_serverless_get_commands_hit_verified_paths(
    command: str,
    path: str,
    response_payload: dict[str, Any],
    expected_output: str,
) -> None:
    recorder = RequestRecorder()
    routes = {
        ("GET", path): json_response(response_payload),
    }

    with serve_http_server(make_http_handler(routes=routes,
                                             recorder=recorder)) as base:
        result = invoke_tm(
            [
                "infer",
                command,
                "--api-key",
                "test_key",
                "--base-url",
                base,
            ],
            env=gateway_env(api_key="test_key"),
        )

    assert result.exit_code == 0, result.output
    assert_last_request(
        recorder,
        method="GET",
        path=path,
        headers={"Authorization": "Bearer test_key"},
    )
    assert result.output == expected_output


def test_infer_responses_prefers_final_message_text_over_reasoning() -> None:
    recorder = RequestRecorder()
    routes = {
        ("POST", "/v1/responses"):
        json_response({
            "id":
            "resp_1",
            "object":
            "response",
            "created_at":
            1,
            "model":
            "openai/gpt-oss-20b",
            "output": [
                {
                    "id":
                    "rs_1",
                    "type":
                    "reasoning",
                    "content": [{
                        "type": "reasoning_text",
                        "text": "internal chain",
                    }],
                },
                {
                    "id": "msg_1",
                    "type": "message",
                    "content": [{
                        "type": "output_text",
                        "text": "final-answer",
                    }],
                },
            ],
        }),
    }

    with serve_http_server(make_http_handler(routes=routes,
                                             recorder=recorder)) as base:
        result = invoke_tm(
            [
                "infer",
                "responses",
                "--api-key",
                "test_key",
                "--base-url",
                base,
                "--json",
                json.dumps({
                    "model": "openai/gpt-oss-20b",
                    "input": "Say final-answer.",
                }),
            ],
            env=gateway_env(api_key="test_key"),
        )

    assert result.exit_code == 0, result.output
    assert result.output == "final-answer\n"


def test_infer_serverless_completions_stream_prints_sse_text() -> None:
    recorder = RequestRecorder()
    routes = {
        ("POST", "/v1/completions"):
        bytes_response(
            (b'data: {"choices":[{"text":"po"}]}\n\n'
             b'data: {"choices":[{"text":"ng"}]}\n\n'
             b"data: [DONE]\n\n"),
            headers={"Content-Type": "text/event-stream"},
        ),
    }

    with serve_http_server(make_http_handler(routes=routes,
                                             recorder=recorder)) as base:
        result = invoke_tm(
            [
                "infer",
                "completions",
                "--stream",
                "--api-key",
                "test_key",
                "--base-url",
                base,
                "--json",
                json.dumps({
                    "model": "openai/gpt-oss-20b",
                    "prompt": "Say pong.",
                }),
            ],
            env=gateway_env(api_key="test_key"),
        )

    assert result.exit_code == 0, result.output
    assert result.output == "pong\n"
    assert_last_request(
        recorder,
        method="POST",
        path="/v1/completions",
        body={
            "model": "openai/gpt-oss-20b",
            "prompt": "Say pong.",
            "stream": True,
        },
        headers={
            "Authorization": "Bearer test_key",
            "Content-Type": "application/json",
            "Accept": "text/event-stream",
        },
    )


def test_infer_serverless_responses_stream_prints_sse_text() -> None:
    recorder = RequestRecorder()
    routes = {
        ("POST", "/v1/responses"):
        bytes_response(
            (b'data: {"output":[{"type":"message","content":[{"type":"output_text","text":"po"}]}]}\n\n'
             b'data: {"output":[{"type":"message","content":[{"type":"output_text","text":"ng"}]}]}\n\n'
             b"data: [DONE]\n\n"),
            headers={"Content-Type": "text/event-stream"},
        ),
    }

    with serve_http_server(make_http_handler(routes=routes,
                                             recorder=recorder)) as base:
        result = invoke_tm(
            [
                "infer",
                "responses",
                "--stream",
                "--api-key",
                "test_key",
                "--base-url",
                base,
                "--json",
                json.dumps({
                    "model": "openai/gpt-oss-20b",
                    "input": "Say pong.",
                }),
            ],
            env=gateway_env(api_key="test_key"),
        )

    assert result.exit_code == 0, result.output
    assert result.output == "pong\n"
    assert_last_request(
        recorder,
        method="POST",
        path="/v1/responses",
        body={
            "model": "openai/gpt-oss-20b",
            "input": "Say pong.",
            "stream": True,
        },
        headers={
            "Authorization": "Bearer test_key",
            "Content-Type": "application/json",
            "Accept": "text/event-stream",
        },
    )


def test_infer_serverless_completions_stream_rejects_non_text_output() -> None:
    result = invoke_tm(
        [
            "--output",
            "json",
            "infer",
            "completions",
            "--stream",
            "--api-key",
            "test_key",
            "--base-url",
            "https://serverless.example.test",
            "--json",
            json.dumps({
                "model": "openai/gpt-oss-20b",
                "prompt": "Say pong.",
            }),
        ],
        env=gateway_env(api_key="test_key"),
    )

    assert result.exit_code != 0
    assert isinstance(result.exception, SystemExit)
    assert ("`tm infer completions --stream` currently supports only "
            "`--output text`." in result.output)


def test_infer_serverless_responses_stream_rejects_non_positive_idle_timeout(
) -> None:
    result = invoke_tm(
        [
            "infer",
            "responses",
            "--stream",
            "--stream-idle-timeout",
            "0",
            "--api-key",
            "test_key",
            "--base-url",
            "https://serverless.example.test",
            "--json",
            json.dumps({
                "model": "openai/gpt-oss-20b",
                "input": "Say pong.",
            }),
        ],
        env=gateway_env(api_key="test_key"),
    )

    assert result.exit_code != 0
    assert isinstance(result.exception, SystemExit)
    assert ("`--stream-idle-timeout` must be a finite number greater than 0."
            in result.output)
