from __future__ import annotations

import os
from pathlib import Path
import runpy
import subprocess
import sys

from click.testing import CliRunner
import pytest

from tensormesh_cli.cli import cli
from tests.cli_test_utils import gateway_env
from tests.cli_test_utils import load_result_json


def test_root_help_shows_v1_command_groups_only(runner: CliRunner) -> None:
    result = runner.invoke(cli, ["--help"])
    assert result.exit_code == 0, result.output

    # Core v1 command groups
    assert "auth" in result.output
    assert "init" in result.output
    assert "version" in result.output
    assert "config" in result.output
    assert "infer" in result.output
    assert "\n  chat" not in result.output
    assert "\n  whoami" not in result.output
    assert "active state root" in " ".join(result.output.split())
    assert "Global options such as --output" in result.output
    assert "Examples:" in result.output
    assert "Related commands:" in result.output


def test_root_help_respects_tm_config_home_for_auth_and_config_paths() -> None:
    repo_root = Path(__file__).resolve().parents[1]
    script = ("import sys\n"
              "from click.testing import CliRunner\n"
              f"sys.path.insert(0, {str(repo_root / 'src')!r})\n"
              "from tensormesh_cli.cli import cli\n"
              "result = CliRunner().invoke(cli, ['--help'])\n"
              "sys.stdout.write(result.output)\n"
              "raise SystemExit(result.exit_code)\n")
    result = subprocess.run(
        [sys.executable, "-c", script],
        cwd=repo_root,
        env={
            **os.environ, "TM_CONFIG_HOME": "/tmp/tm-state"
        },
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stdout + result.stderr
    normalized = " ".join(result.stdout.split())
    assert "/tmp/tm-" in result.stdout
    assert "state/config.toml" in result.stdout
    assert "Path to config TOML file [default:" in normalized
    assert "active state root" in " ".join(result.stdout.split())
    assert "always read from ~/.config/tensormesh/auth.json" not in result.stdout


def test_init_command_guides_missing_setup(
    runner: CliRunner,
    isolated_home: Path,
) -> None:
    result = runner.invoke(
        cli,
        [
            "--output",
            "json",
            "--config",
            "cfg.toml",
            "init",
        ],
        env={"HOME": str(isolated_home)},
    )
    data = load_result_json(result)
    assert isinstance(data, dict)
    assert data["ready_for_first_request"] is False
    assert any("Local status only." in item for item in data["warnings"])
    assert "tm config init" in data["optional_next_steps"]
    assert "tm auth login" in data["next_steps"]
    assert "tm init --sync" in data["next_steps"]
    assert "tm auth login" not in data["optional_next_steps"]


def test_init_command_detects_ready_gateway_state(
    runner: CliRunner,
    isolated_home: Path,
) -> None:
    auth_json = Path(".config/tensormesh/auth.json")
    auth_json.parent.mkdir(parents=True, exist_ok=True)
    auth_json.write_text(
        '{"access_token":"tok","refresh_token":"refresh"}\n',
        encoding="utf-8",
    )
    cfg = Path("cfg.toml")
    cfg.write_text(
        '[managed]\n'
        'gateway_api_key = "gw_key"\n'
        'gateway_model_id = "gw_model"\n',
        encoding="utf-8",
    )

    result = runner.invoke(
        cli,
        [
            "--output",
            "json",
            "--config",
            str(cfg),
            "init",
        ],
        env={"HOME": str(isolated_home)},
    )
    data = load_result_json(result)
    assert isinstance(data, dict)
    assert data["ready_for_first_request"] is True
    assert any("Local status only." in item for item in data["warnings"])
    assert data["gateway"]["api_key_source"] == "managed:gateway_api_key"
    assert data["gateway"]["model_id_source"] == "managed:gateway_model_id"
    assert data["gateway"]["user_id_ready"] is True
    assert data["gateway"]["user_id_derived_from_controlplane"] is True
    assert any(
        step.startswith("tm infer chat --json") for step in data["next_steps"])
    assert "tm auth login" not in data["next_steps"]
    assert data["optional_next_steps"] == [
        "tm billing pricing serverless list",
        ('tm infer chat --surface serverless --api-key '
         '"YOUR_INFERENCE_API_KEY" --model "YOUR_SERVERLESS_MODEL_NAME" '
         '--json \'[{"role":"user","content":"Say hello."}]\''),
    ]


def test_init_command_keeps_serverless_flow_optional_without_control_plane_auth(
    runner: CliRunner,
    isolated_home: Path,
) -> None:
    cfg = Path("cfg.toml")
    cfg.write_text(
        '[managed]\n'
        'gateway_api_key = "gw_key"\n'
        'gateway_user_id = "00000000-0000-0000-0000-000000000000"\n'
        'gateway_model_id = "gw_model"\n',
        encoding="utf-8",
    )

    result = runner.invoke(
        cli,
        [
            "--output",
            "json",
            "--config",
            str(cfg),
            "init",
        ],
        env={"HOME": str(isolated_home)},
    )

    data = load_result_json(result)
    assert isinstance(data, dict)
    assert data["next_steps"] == [
        "tm infer chat --json '[{\"role\":\"user\",\"content\":\"Say hello.\"}]'"
    ]
    assert data["optional_next_steps"] == [
        "tm auth login",
        "tm billing pricing serverless list",
        ('tm infer chat --surface serverless --api-key '
         '"YOUR_INFERENCE_API_KEY" --model "YOUR_SERVERLESS_MODEL_NAME" '
         '--json \'[{"role":"user","content":"Say hello."}]\''),
    ]


def test_init_command_rejects_invalid_gateway_user_id_for_first_request(
    runner: CliRunner,
    isolated_home: Path,
) -> None:
    result = runner.invoke(
        cli,
        [
            "--output",
            "json",
            "init",
        ],
        env=gateway_env(home=isolated_home,
                        api_key="gw_key",
                        user_id="not-a-uuid",
                        model_id="gw_model"),
    )

    data = load_result_json(result)
    assert isinstance(data, dict)
    assert data["ready_for_first_request"] is False
    assert data["gateway"]["user_id_valid"] is False
    assert any("Invalid gateway user id" in item for item in data["warnings"])
    assert "tm init --sync" in data["next_steps"]


def test_init_command_human_output_surfaces_auth_errors_and_next_steps(
    runner: CliRunner,
    isolated_home: Path,
) -> None:
    auth_json = Path(".config/tensormesh/auth.json")
    auth_json.parent.mkdir(parents=True, exist_ok=True)
    auth_json.write_text("{not-json", encoding="utf-8")
    cfg = Path("cfg.toml")
    cfg.write_text("", encoding="utf-8")

    result = runner.invoke(
        cli,
        [
            "--config",
            str(cfg),
            "init",
        ],
        env={"HOME": str(isolated_home)},
    )

    assert result.exit_code == 0, result.output
    assert "tm init" in result.output
    assert "Control Plane token error:" in result.output
    assert "Next steps:" in result.output
    assert "tm infer doctor" in result.output
    assert "tm auth login" in result.output
    assert "tm init --sync" in result.output
    assert "Local status only." in result.output
    assert 'tm infer chat --model "YOUR_SERVED_GATEWAY_MODEL_NAME"' in result.output
    optional_steps = result.output.split("Optional next steps:", 1)[1]
    assert optional_steps.count("tm auth login") == 0
    assert "tm billing pricing serverless list" in optional_steps
    assert ('tm infer chat --surface serverless --api-key '
            '"YOUR_INFERENCE_API_KEY" --model "YOUR_SERVERLESS_MODEL_NAME"'
            in optional_steps)


def test_init_help_respects_tm_config_home_in_sync_text() -> None:
    tm_path = Path(sys.executable).with_name("tm")
    result = subprocess.run(
        [str(tm_path), "init", "--help"],
        cwd=Path(__file__).resolve().parents[1],
        env={
            **os.environ, "TM_CONFIG_HOME": "/tmp/tm-state"
        },
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stdout + result.stderr
    assert "$TM_CONFIG_HOME/config.toml" in result.stdout
    assert "~/.config/tensormesh/config.toml" not in result.stdout


def test_config_init_template_uses_portable_auth_json_path(
    runner: CliRunner,
    isolated_home: Path,
) -> None:
    result = runner.invoke(cli, ["config", "init", "--path", "cfg.toml"])
    assert result.exit_code == 0, result.output

    contents = Path("cfg.toml").read_text(encoding="utf-8")
    assert '# gateway_provider = "nebius"' in contents
    assert '\ngateway_provider = "nebius"\n' not in contents
    assert "controlplane_auth_json" not in contents
    assert Path("cfg.toml").stat().st_mode & 0o777 == 0o600


def test_cli_help_lists_controlplane_base_global_option(
    runner: CliRunner, ) -> None:
    result = runner.invoke(cli, ["--help"])
    assert result.exit_code == 0, result.output
    assert "--controlplane-base" in result.output


def test_cli_help_includes_generated_control_plane_gap_branches(
        runner: CliRunner) -> None:
    result = runner.invoke(cli,
                           ["billing", "stripe", "payment-methods", "--help"])
    assert result.exit_code == 0, result.output
    assert "attach" in result.output
    assert "detach" in result.output
    assert "list" in result.output

    result = runner.invoke(cli, ["admin", "billing", "spending", "--help"])
    assert result.exit_code == 0, result.output
    assert "summary" in result.output

    result = runner.invoke(cli, ["models", "--help"])
    assert result.exit_code == 0, result.output
    assert "check" in result.output


def test_config_init_template_includes_controlplane_base_comment(
    runner: CliRunner,
    isolated_home: Path,
) -> None:
    result = runner.invoke(cli, ["config", "init", "--path", "cfg.toml"])
    assert result.exit_code == 0, result.output

    contents = Path("cfg.toml").read_text(encoding="utf-8")
    assert '# controlplane_base = "https://api.tensormesh.ai"' in contents


def test_config_init_template_keeps_managed_provider_authoritative(
    runner: CliRunner,
    isolated_home: Path,
) -> None:
    init_result = runner.invoke(
        cli,
        ["config", "init", "--path", "cfg.toml"],
    )
    assert init_result.exit_code == 0, init_result.output

    cfg = Path("cfg.toml")
    contents = cfg.read_text(encoding="utf-8")
    managed_stub = (
        '[managed]\n'
        '# Managed gateway values written by `tm init --sync`.\n'
        '# synced_at = "2026-03-23T00:00:00Z"\n'
        '# gateway_provider = "nebius"\n'
        '# gateway_api_key = "..."  # stored inference API key; SDK uses this as `inference_api_key`\n'
        '# gateway_user_id = "00000000-0000-0000-0000-000000000000"\n'
        '# gateway_model_id = "your-served-model-name"  # compatibility key; value is sent as `model`\n'
    )
    cfg.write_text(
        contents.replace(
            managed_stub,
            '[managed]\n'
            'synced_at = "2026-03-23T00:00:00Z"\n'
            'gateway_provider = "yotta"\n'
            'gateway_api_key = "gw_key"\n'
            'gateway_user_id = "00000000-0000-0000-0000-000000000000"\n'
            'gateway_model_id = "test_model"\n',
        ),
        encoding="utf-8",
    )

    show_result = runner.invoke(
        cli,
        [
            "--output",
            "json",
            "--config",
            "cfg.toml",
            "config",
            "show",
        ],
    )
    data = load_result_json(show_result)
    assert isinstance(data, dict)
    assert data["gateway_provider"] == "yotta"
    assert data["gateway_base"] == "https://external.yotta.tensormesh.ai"


def test_config_init_force_preserves_existing_managed_values(
    runner: CliRunner,
    isolated_home: Path,
) -> None:
    cfg = Path("cfg.toml")
    cfg.write_text(
        'timeout_seconds = 99\n'
        '\n'
        '[managed]\n'
        'synced_at = "2026-03-23T00:00:00Z"\n'
        'gateway_provider = "yotta"\n'
        'gateway_api_key = "gw_key"\n'
        'gateway_user_id = "00000000-0000-0000-0000-000000000000"\n'
        'gateway_model_id = "test_model"\n',
        encoding="utf-8",
    )

    result = runner.invoke(
        cli,
        ["config", "init", "--path", "cfg.toml", "--force"],
    )

    assert result.exit_code == 0, result.output
    contents = cfg.read_text(encoding="utf-8")
    assert "timeout_seconds = 30" in contents
    assert "timeout_seconds = 99" not in contents
    assert 'gateway_provider = "yotta"' in contents
    assert 'gateway_api_key = "gw_key"' in contents
    assert 'gateway_model_id = "test_model"' in contents


def test_shared_click_helpers_preserve_common_help_surface(
    runner: CliRunner, ) -> None:

    billing_help = runner.invoke(cli, ["billing", "--help"])
    assert billing_help.exit_code == 0, billing_help.output
    assert "transactions" in billing_help.output
    assert "spending" in billing_help.output
    assert "pricing" in billing_help.output

    models_help = runner.invoke(cli, ["models", "validate-name", "--help"])
    assert models_help.exit_code == 0, models_help.output
    assert "--json" in models_help.output
    assert "--file" in models_help.output
    assert "--timeout" in models_help.output

    admin_help = runner.invoke(cli,
                               ["admin", "users", "change-role", "--help"])
    assert admin_help.exit_code == 0, admin_help.output
    assert "--yes" in admin_help.output
    assert "--json" in admin_help.output
    assert "--file" in admin_help.output
    assert "--timeout" in admin_help.output

    infer_help = runner.invoke(cli, ["infer", "chat", "--help"])
    assert infer_help.exit_code == 0, infer_help.output
    assert "--json" in infer_help.output
    assert "--file" in infer_help.output
    assert "--timeout" in infer_help.output
    assert "--gateway-base" not in infer_help.output

    metrics_help = runner.invoke(cli, ["metrics", "deployment", "--help"])
    assert metrics_help.exit_code == 0, metrics_help.output
    assert "--user-id" in metrics_help.output
    assert "--start-time" in metrics_help.output
    assert "--end-time" in metrics_help.output
    assert "--step-seconds" in metrics_help.output

    activities_help = runner.invoke(cli, ["activities", "list", "--help"])
    assert activities_help.exit_code == 0, activities_help.output
    assert "--user-id" in activities_help.output
    assert "--start-time" in activities_help.output
    assert "--end-time" in activities_help.output
    assert "--page" in activities_help.output
    assert "--size" in activities_help.output

    pricing_help = runner.invoke(cli, ["billing", "pricing", "list", "--help"])
    assert pricing_help.exit_code == 0, pricing_help.output
    assert "--cloud-provider" in pricing_help.output
    assert "--gpu-type" in pricing_help.output

    pricing_group_help = runner.invoke(cli, ["billing", "pricing", "--help"])
    assert pricing_group_help.exit_code == 0, pricing_group_help.output
    assert "serverless" in pricing_group_help.output

    serverless_pricing_help = runner.invoke(
        cli, ["billing", "pricing", "serverless", "list", "--help"])
    assert serverless_pricing_help.exit_code == 0, serverless_pricing_help.output
    assert "--model" in serverless_pricing_help.output
    assert "--active-only" in serverless_pricing_help.output

    user_api_keys_help = runner.invoke(cli, ["users", "api-keys", "--help"])
    assert user_api_keys_help.exit_code == 0, user_api_keys_help.output
    assert "create" in user_api_keys_help.output
    assert "delete" in user_api_keys_help.output
    assert "list" in user_api_keys_help.output

    admin_models_help = runner.invoke(cli,
                                      ["admin", "models", "delete", "--help"])
    assert admin_models_help.exit_code == 0, admin_models_help.output
    assert "--yes" in admin_models_help.output
    assert "--json" in admin_models_help.output
    assert "--file" in admin_models_help.output

    admin_serverless_help = runner.invoke(
        cli, ["admin", "billing", "pricing", "serverless", "list", "--help"])
    assert admin_serverless_help.exit_code == 0, admin_serverless_help.output
    assert "--model" in admin_serverless_help.output
    assert "--active-only" in admin_serverless_help.output


def test_python_module_entrypoint_shows_help(
        capsys: pytest.CaptureFixture[str]) -> None:
    with pytest.raises(SystemExit) as exc:
        from unittest.mock import patch

        with patch("sys.argv", ["tensormesh_cli", "--help"]):
            runpy.run_module("tensormesh_cli.__main__", run_name="__main__")

    assert exc.value.code == 0
    captured = capsys.readouterr()
    assert "Usage:" in captured.out
    assert "auth" in captured.out


def test_command_help_includes_structured_docs_metadata_sections(
    runner: CliRunner, ) -> None:

    login_help = runner.invoke(cli, ["auth", "login", "--help"])
    assert login_help.exit_code == 0, login_help.output
    assert "Examples:" in login_help.output
    assert "Prerequisites:" in login_help.output
    assert "Caveats:" in login_help.output
    assert "Related commands:" in login_help.output
    assert "tm auth login --no-open-browser" in login_help.output

    whoami_help = runner.invoke(cli, ["auth", "whoami", "--help"])
    assert whoami_help.exit_code == 0, whoami_help.output
    assert "Auth scope:" in whoami_help.output
    assert "GET /auth/profile" in whoami_help.output
