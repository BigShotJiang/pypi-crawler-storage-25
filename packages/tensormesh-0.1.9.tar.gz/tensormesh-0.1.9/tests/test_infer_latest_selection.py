from __future__ import annotations

import click
import pytest

from tensormesh_cli.commands.infer_latest import \
    select_latest_controlplane_model


def test_select_latest_controlplane_model_falls_back_to_deployment_id(
) -> None:
    selected = select_latest_controlplane_model(
        controlplane_data={
            "models": [{
                "modelId": "m1",
                "deploymentId": "dep_only",
                "status": "MODEL_STATUS_UP",
                "updatedAt": "2024-01-01T00:00:00Z",
            }]
        })

    assert selected == "dep_only"


def test_select_latest_controlplane_model_rejects_non_served_models() -> None:
    with pytest.raises(
            click.ClickException,
            match=
            "Failed to resolve @latest: no served models with modelName/deploymentId found",
    ):
        select_latest_controlplane_model(
            controlplane_data={
                "models": [{
                    "modelId": "m1",
                    "modelName": "gw_init",
                    "status": "MODEL_STATUS_INIT",
                    "updatedAt": "2024-01-01T00:00:00Z",
                }]
            })
