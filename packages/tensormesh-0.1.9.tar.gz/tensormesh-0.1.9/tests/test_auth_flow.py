from __future__ import annotations

from pathlib import Path
from typing import Any

import pytest

from tensormesh_cli.auth.flow import login
from tensormesh_cli.auth.flow import refresh
from tests.response_test_utils import JSONResponse


def test_login_polls_exchange_and_saves_tokens(monkeypatch: pytest.MonkeyPatch,
                                               tmp_path: Path) -> None:
    token_path = tmp_path / "auth.json"
    calls: list[tuple[str, dict[str, Any] | None]] = []
    saved: dict[str, Any] = {}
    opened: list[str] = []
    logs: list[str] = []

    responses = [
        JSONResponse(status_code=200,
                     payload={
                         "auth_url": "https://auth.example/start",
                         "cli_code": "cli123",
                         "interval": 0,
                     }),
        JSONResponse(status_code=202, payload={"status": "pending"}),
        JSONResponse(status_code=200,
                     payload={
                         "access_token": "a",
                         "refresh_token": "r",
                     }),
    ]

    def fake_post(url: str,
                  *,
                  json: dict[str, Any] | None = None,
                  **kwargs: Any) -> JSONResponse:
        calls.append((url, json))
        return responses.pop(0)

    import tensormesh_cli.auth.flow as flow

    monkeypatch.setattr(flow.requests, "post", fake_post)
    monkeypatch.setattr(
        flow, "save_tokens", lambda path, tokens: saved.update({
            "path": path,
            "tokens": tokens
        }))
    monkeypatch.setattr(flow.webbrowser, "open", opened.append)
    monkeypatch.setattr(flow.time, "sleep", lambda seconds: None)

    login("https://control.example",
          token_path,
          timeout_s=5,
          verify=True,
          log=logs.append)

    assert calls == [
        ("https://control.example/auth/cli/start", None),
        ("https://control.example/auth/cli/exchange", {
            "cli_code": "cli123"
        }),
        ("https://control.example/auth/cli/exchange", {
            "cli_code": "cli123"
        }),
    ]
    assert opened == ["https://auth.example/start"]
    assert saved["path"] == token_path
    assert saved["tokens"] == {
        "access_token": "a",
        "refresh_token": "r",
    }
    assert any("Open browser" in line for line in logs)
    assert any("Login success" in line for line in logs)


def test_login_times_out_when_exchange_never_completes(
        monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    token_path = tmp_path / "auth.json"
    clock = {"now": 0.0}

    def fake_post(url: str,
                  *,
                  json: dict[str, Any] | None = None,
                  **kwargs: Any) -> JSONResponse:
        if url.endswith("/start"):
            return JSONResponse(status_code=200,
                                payload={
                                    "auth_url": "https://auth.example/start",
                                    "cli_code": "cli123",
                                    "interval": 0.6,
                                })
        return JSONResponse(status_code=202, payload={"status": "pending"})

    import tensormesh_cli.auth.flow as flow

    monkeypatch.setattr(flow.requests, "post", fake_post)
    monkeypatch.setattr(flow.time, "monotonic", lambda: clock["now"])
    monkeypatch.setattr(
        flow.time, "sleep",
        lambda seconds: clock.__setitem__("now", clock["now"] + seconds))

    with pytest.raises(RuntimeError, match="Login timed out after 1 seconds."):
        login("https://control.example",
              token_path,
              open_browser=False,
              max_wait_s=1,
              log=None)


def test_refresh_updates_saved_tokens(monkeypatch: pytest.MonkeyPatch,
                                      tmp_path: Path) -> None:
    token_path = tmp_path / "auth.json"
    saved: dict[str, Any] = {}

    def fake_post(url: str,
                  *,
                  json: dict[str, Any] | None = None,
                  **kwargs: Any) -> JSONResponse:
        assert url == "https://control.example/auth/cli/refresh"
        assert json == {"refresh_token": "old-refresh"}
        return JSONResponse(status_code=200,
                            payload={
                                "access_token": "new-access",
                                "refresh_token": "new-refresh",
                            })

    import tensormesh_cli.auth.flow as flow

    monkeypatch.setattr(flow, "load_tokens",
                        lambda path: {"refresh_token": "old-refresh"})
    monkeypatch.setattr(flow.requests, "post", fake_post)
    monkeypatch.setattr(
        flow, "save_tokens", lambda path, tokens: saved.update({
            "path": path,
            "tokens": tokens
        }))

    refresh("https://control.example", token_path)

    assert saved["path"] == token_path
    assert saved["tokens"] == {
        "access_token": "new-access",
        "refresh_token": "new-refresh",
    }


def test_refresh_raises_for_invalid_json_response(
        monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    token_path = tmp_path / "auth.json"

    def fake_post(url: str,
                  *,
                  json: dict[str, Any] | None = None,
                  **kwargs: Any) -> JSONResponse:
        return JSONResponse(status_code=200,
                            payload=ValueError("bad json"),
                            text="not-json")

    import tensormesh_cli.auth.flow as flow

    monkeypatch.setattr(flow, "load_tokens",
                        lambda path: {"refresh_token": "old-refresh"})
    monkeypatch.setattr(flow.requests, "post", fake_post)

    with pytest.raises(
            RuntimeError,
            match="Refresh failed: invalid JSON response: not-json"):
        refresh("https://control.example", token_path)


def test_refresh_raises_for_non_object_json_response(
        monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    token_path = tmp_path / "auth.json"

    def fake_post(url: str,
                  *,
                  json: dict[str, Any] | None = None,
                  **kwargs: Any) -> JSONResponse:
        return JSONResponse(status_code=200,
                            payload=["bad", "payload"],
                            text='["bad","payload"]')

    import tensormesh_cli.auth.flow as flow

    monkeypatch.setattr(flow, "load_tokens",
                        lambda path: {"refresh_token": "old-refresh"})
    monkeypatch.setattr(flow.requests, "post", fake_post)

    with pytest.raises(
            RuntimeError,
            match=
            r"Refresh failed: invalid JSON response: \[\"bad\",\"payload\"\]"):
        refresh("https://control.example", token_path)


def test_login_raises_for_invalid_start_payload(
        monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    token_path = tmp_path / "auth.json"

    def fake_post(url: str,
                  *,
                  json: dict[str, Any] | None = None,
                  **kwargs: Any) -> JSONResponse:
        return JSONResponse(status_code=200,
                            payload={"cli_code": "missing-auth-url"})

    import tensormesh_cli.auth.flow as flow

    monkeypatch.setattr(flow.requests, "post", fake_post)

    with pytest.raises(RuntimeError, match="missing or invalid 'auth_url'"):
        login("https://control.example",
              token_path,
              open_browser=False,
              log=None)


def test_login_raises_for_invalid_start_json_response(
        monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    token_path = tmp_path / "auth.json"

    def fake_post(url: str,
                  *,
                  json: dict[str, Any] | None = None,
                  **kwargs: Any) -> JSONResponse:
        return JSONResponse(status_code=200,
                            payload=ValueError("bad json"),
                            text="not-json")

    import tensormesh_cli.auth.flow as flow

    monkeypatch.setattr(flow.requests, "post", fake_post)

    with pytest.raises(
            RuntimeError,
            match="Login start failed: invalid JSON response: not-json"):
        login("https://control.example",
              token_path,
              open_browser=False,
              log=None)


def test_login_raises_for_invalid_exchange_json_response(
        monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    token_path = tmp_path / "auth.json"

    responses = [
        JSONResponse(status_code=200,
                     payload={
                         "auth_url": "https://auth.example/start",
                         "cli_code": "cli123",
                         "interval": 0,
                     }),
        JSONResponse(status_code=200,
                     payload=ValueError("bad json"),
                     text="not-json"),
    ]

    def fake_post(url: str,
                  *,
                  json: dict[str, Any] | None = None,
                  **kwargs: Any) -> JSONResponse:
        return responses.pop(0)

    import tensormesh_cli.auth.flow as flow

    monkeypatch.setattr(flow.requests, "post", fake_post)

    with pytest.raises(
            RuntimeError,
            match="Login exchange failed: invalid JSON response: not-json"):
        login("https://control.example",
              token_path,
              open_browser=False,
              log=None)


def test_login_raises_for_start_network_and_status_failures(
        monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    token_path = tmp_path / "auth.json"

    import tensormesh_cli.auth.flow as flow

    def fail_post(url: str,
                  *,
                  json: dict[str, Any] | None = None,
                  **kwargs: Any) -> JSONResponse:
        raise flow.requests.RequestException("boom")

    monkeypatch.setattr(flow.requests, "post", fail_post)

    with pytest.raises(RuntimeError,
                       match=r"Login start failed \(network error\)"):
        login("https://control.example",
              token_path,
              open_browser=False,
              log=None)

    monkeypatch.setattr(
        flow.requests,
        "post",
        lambda url, **kwargs: JSONResponse(status_code=503, text="unavailable"
                                           ),
    )

    with pytest.raises(RuntimeError,
                       match="Login start failed: 503 unavailable"):
        login("https://control.example",
              token_path,
              open_browser=False,
              log=None)


def test_login_raises_for_non_dict_start_json_and_exchange_failures(
        monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    token_path = tmp_path / "auth.json"

    import tensormesh_cli.auth.flow as flow

    monkeypatch.setattr(
        flow.requests, "post", lambda url, **kwargs: JSONResponse(
            status_code=200, payload=["not", "a", "dict"], text='["not"]'))

    with pytest.raises(
            RuntimeError,
            match=r"Login start failed: invalid JSON response: \[\"not\"\]"):
        login("https://control.example",
              token_path,
              open_browser=False,
              log=None)

    responses = [
        JSONResponse(status_code=200,
                     payload={
                         "auth_url": "https://auth.example/start",
                         "cli_code": "cli123",
                         "interval": 0,
                     }),
        JSONResponse(status_code=500, text="server-error"),
    ]

    monkeypatch.setattr(flow.requests, "post",
                        lambda url, **kwargs: responses.pop(0))

    with pytest.raises(RuntimeError, match="Login failed: 500 server-error"):
        login("https://control.example",
              token_path,
              open_browser=False,
              log=None)


def test_login_raises_for_keyboard_interrupt_during_exchange(
        monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    token_path = tmp_path / "auth.json"

    responses = [
        JSONResponse(status_code=200,
                     payload={
                         "auth_url": "https://auth.example/start",
                         "cli_code": "cli123",
                         "interval": 0,
                     })
    ]

    def fake_post(url: str,
                  *,
                  json: dict[str, Any] | None = None,
                  **kwargs: Any) -> JSONResponse:
        if responses:
            return responses.pop(0)
        raise KeyboardInterrupt

    import tensormesh_cli.auth.flow as flow

    monkeypatch.setattr(flow.requests, "post", fake_post)

    with pytest.raises(RuntimeError, match="Login cancelled."):
        login("https://control.example",
              token_path,
              open_browser=False,
              log=None)


def test_refresh_raises_for_missing_refresh_token_and_failure_status(
        monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    token_path = tmp_path / "auth.json"

    import tensormesh_cli.auth.flow as flow

    monkeypatch.setattr(flow, "load_tokens", lambda path: {})

    with pytest.raises(RuntimeError,
                       match="No refresh token found. Please login first."):
        refresh("https://control.example", token_path)

    monkeypatch.setattr(flow, "load_tokens",
                        lambda path: {"refresh_token": "old-refresh"})
    monkeypatch.setattr(
        flow.requests,
        "post",
        lambda url, **kwargs: JSONResponse(status_code=500, text="refresh-bad"
                                           ),
    )

    with pytest.raises(RuntimeError, match="Refresh failed: 500 refresh-bad"):
        refresh("https://control.example", token_path)
