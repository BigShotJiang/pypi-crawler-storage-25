from __future__ import annotations

import json
from pathlib import Path

from tensormesh import Tensormesh

REPO_ROOT = Path(__file__).resolve().parents[1]


def test_stripe_manifest_matches_shipped_sdk_surface() -> None:
    manifest = json.loads(
        (REPO_ROOT / "openapi" / "tensormesh" /
         "sdk-codegen-manifest.json").read_text(encoding="utf-8"))
    stripe_spec = manifest["specs"]["billing/v1/stripe_service.swagger.json"]

    assert stripe_spec["category"] == "semi_generated"
    assert stripe_spec[
        "public_namespace"] == "client.control_plane.billing.stripe"

    client = Tensormesh(control_plane_token="test-token")

    assert hasattr(client.control_plane.billing, "stripe")
    assert hasattr(client.control_plane.billing.stripe, "customer")
    assert hasattr(client.control_plane.billing.stripe, "payment_methods")
    assert hasattr(client.control_plane.billing.stripe, "payment_intents")
    assert hasattr(client.control_plane.billing.stripe, "setup_intents")
