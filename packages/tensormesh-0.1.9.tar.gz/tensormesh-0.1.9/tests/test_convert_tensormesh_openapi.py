from __future__ import annotations

import json
from pathlib import Path
import shutil
import stat
import subprocess
import textwrap

from tests.script_test_utils import load_script_module

REPO_ROOT = Path(__file__).resolve().parents[1]
DOCS_JSON_SCRIPT_PATH = REPO_ROOT / "scripts" / "update-tensormesh-docs-json.py"
RAW_SPECS_DIR = Path("openapi/.generated/tensormesh-api/specs")


def _copy_repo_script(rel_path: str, dest_root: Path) -> Path:
    src = REPO_ROOT / rel_path
    dest = dest_root / rel_path
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(src.read_text(encoding="utf-8"), encoding="utf-8")
    dest.chmod(dest.stat().st_mode | stat.S_IXUSR)
    return dest


def _write_fake_swagger2openapi(repo_root: Path,
                                *,
                                stderr_text: str = "") -> None:
    fake_bin = repo_root / "node_modules" / ".bin" / "swagger2openapi"
    stderr_block = ""
    if stderr_text:
        stderr_block = "\n".join(f'printf %s\\\\n {line!r} >&2'
                                 for line in stderr_text.splitlines())
    fake_bin.parent.mkdir(parents=True, exist_ok=True)
    fake_bin.write_text(
        textwrap.dedent(f"""\
            #!/usr/bin/env bash
            set -euo pipefail

            input=""
            outfile=""
            while [[ "$#" -gt 0 ]]; do
              case "$1" in
                --outfile)
                  outfile="$2"
                  shift 2
                  ;;
                --patch|--targetVersion)
                  shift
                  if [[ "${1:-}" != "" && "$0" != "${1:-}" && "$1" != --* ]]; then
                    shift
                  fi
                  ;;
                *)
                  if [[ -z "$input" ]]; then
                    input="$1"
                  fi
                  shift
                  ;;
              esac
            done

            {stderr_block}
            cp "$input" "$outfile"
        """),
        encoding="utf-8",
    )
    fake_bin.chmod(fake_bin.stat().st_mode | stat.S_IXUSR)


def test_convert_tensormesh_openapi_fails_on_zero_path_source(
    tmp_path: Path, ) -> None:
    if shutil.which("jq") is None:
        return

    repo = tmp_path / "repo"
    (repo / "openapi" / "tensormesh" / "user" / "v1").mkdir(parents=True)
    (repo / "certs").mkdir(parents=True)

    _copy_repo_script("scripts/convert-tensormesh-openapi.sh", repo)
    _copy_repo_script("scripts/lib/common.sh", repo)
    _copy_repo_script("scripts/normalize-openapi-spec.py", repo)
    _copy_repo_script("scripts/lib/openapi_text.py", repo)
    _copy_repo_script("src/tensormesh/_constants.py", repo)
    _write_fake_swagger2openapi(repo)
    allowlist = repo / "openapi" / "tensormesh" / "zero-path-allowlist.txt"
    allowlist.parent.mkdir(parents=True, exist_ok=True)
    allowlist.write_text("", encoding="utf-8")

    swagger_path = (repo / "openapi" / "tensormesh" / "user" / "v1" /
                    "user_service.swagger.json")
    swagger_path.write_text(
        textwrap.dedent("""
            {
              "swagger": "2.0",
              "info": {
                "title": "Broken Service",
                "version": "0.1.0"
              },
              "paths": {}
            }
        """).strip() + "\n",
        encoding="utf-8",
    )

    result = subprocess.run(
        ["bash", "./scripts/convert-tensormesh-openapi.sh"],
        cwd=repo,
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode != 0
    assert ("openapi/tensormesh/user/v1/user_service.swagger.json has zero "
            "paths and is not allowlisted." in result.stderr)
    assert "zero-path-allowlist.txt" in result.stderr


def test_convert_tensormesh_openapi_skips_allowlisted_zero_path_source(
    tmp_path: Path, ) -> None:
    if shutil.which("jq") is None:
        return

    repo = tmp_path / "repo"
    (repo / "openapi" / "tensormesh" / "user" / "v1").mkdir(parents=True)
    (repo / "openapi" / "tensormesh" / "model" / "v1").mkdir(parents=True)
    (repo / "certs").mkdir(parents=True)

    _copy_repo_script("scripts/convert-tensormesh-openapi.sh", repo)
    _copy_repo_script("scripts/lib/common.sh", repo)
    _copy_repo_script("scripts/normalize-openapi-spec.py", repo)
    _copy_repo_script("scripts/lib/openapi_text.py", repo)
    _copy_repo_script("src/tensormesh/_constants.py", repo)
    _write_fake_swagger2openapi(repo)

    allowlist = repo / "openapi" / "tensormesh" / "zero-path-allowlist.txt"
    allowlist.write_text("user/v1/user_service.swagger.json\n",
                         encoding="utf-8")

    zero_path_swagger = (repo / "openapi" / "tensormesh" / "user" / "v1" /
                         "user_service.swagger.json")
    zero_path_swagger.write_text(
        textwrap.dedent("""
            {
              "swagger": "2.0",
              "info": {
                "title": "Schema Only",
                "version": "0.1.0"
              },
              "paths": {}
            }
        """).strip() + "\n",
        encoding="utf-8",
    )

    non_empty_swagger = (repo / "openapi" / "tensormesh" / "model" / "v1" /
                         "model_service.swagger.json")
    non_empty_swagger.write_text(
        textwrap.dedent("""
            {
              "swagger": "2.0",
              "info": {
                "title": "Model Service",
                "version": "0.1.0"
              },
              "paths": {
                "/v1/models": {
                  "get": {
                    "operationId": "ModelService_ListModels",
                    "responses": {
                      "200": {
                        "description": "ok"
                      }
                    }
                  }
                }
              }
            }
        """).strip() + "\n",
        encoding="utf-8",
    )

    result = subprocess.run(
        ["bash", "./scripts/convert-tensormesh-openapi.sh"],
        cwd=repo,
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr
    assert "skipped_allowed_zero_paths=1" in result.stdout
    assert (repo / RAW_SPECS_DIR / "model" / "v1" /
            "model_service.openapi.json").exists()
    assert not (repo / RAW_SPECS_DIR / "user" / "v1" /
                "user_service.openapi.json").exists()


def test_convert_tensormesh_openapi_filters_only_known_punycode_warning(
    tmp_path: Path, ) -> None:
    if shutil.which("jq") is None:
        return

    repo = tmp_path / "repo"
    (repo / "openapi" / "tensormesh" / "model" / "v1").mkdir(parents=True)
    (repo / "certs").mkdir(parents=True)

    _copy_repo_script("scripts/convert-tensormesh-openapi.sh", repo)
    _copy_repo_script("scripts/lib/common.sh", repo)
    _copy_repo_script("scripts/normalize-openapi-spec.py", repo)
    _copy_repo_script("scripts/lib/openapi_text.py", repo)
    _copy_repo_script("src/tensormesh/_constants.py", repo)
    _write_fake_swagger2openapi(
        repo,
        stderr_text=
        ("(node:123) [DEP0040] DeprecationWarning: The `punycode` module is deprecated. Please use a userland alternative instead.\n"
         "(Use `node --trace-deprecation ...` to show where the warning was created)\n"
         "custom warning: keep me"),
    )

    allowlist = repo / "openapi" / "tensormesh" / "zero-path-allowlist.txt"
    allowlist.write_text("", encoding="utf-8")

    swagger_path = (repo / "openapi" / "tensormesh" / "model" / "v1" /
                    "model_service.swagger.json")
    swagger_path.write_text(
        textwrap.dedent("""
            {
              "swagger": "2.0",
              "info": {
                "title": "Model Service",
                "version": "0.1.0"
              },
              "paths": {
                "/v1/models": {
                  "get": {
                    "operationId": "ModelService_ListModels",
                    "responses": {
                      "200": {
                        "description": "ok"
                      }
                    }
                  }
                }
              }
            }
        """).strip() + "\n",
        encoding="utf-8",
    )

    result = subprocess.run(
        ["bash", "./scripts/convert-tensormesh-openapi.sh"],
        cwd=repo,
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr
    assert "custom warning: keep me" in result.stderr
    assert "punycode" not in result.stderr


def test_convert_tensormesh_openapi_omits_default_control_plane_host(
    tmp_path: Path, ) -> None:
    if shutil.which("jq") is None:
        return

    repo = tmp_path / "repo"
    (repo / "openapi" / "tensormesh" / "model" / "v1").mkdir(parents=True)
    (repo / "certs").mkdir(parents=True)

    _copy_repo_script("scripts/convert-tensormesh-openapi.sh", repo)
    _copy_repo_script("scripts/lib/common.sh", repo)
    _copy_repo_script("scripts/normalize-openapi-spec.py", repo)
    _copy_repo_script("scripts/lib/openapi_text.py", repo)
    _write_fake_swagger2openapi(repo)

    allowlist = repo / "openapi" / "tensormesh" / "zero-path-allowlist.txt"
    allowlist.write_text("", encoding="utf-8")

    swagger_path = (repo / "openapi" / "tensormesh" / "model" / "v1" /
                    "model_service.swagger.json")
    swagger_path.write_text(
        textwrap.dedent("""
            {
              "swagger": "2.0",
              "info": {
                "title": "Model Service",
                "version": "0.1.0"
              },
              "paths": {
                "/v1/models": {
                  "get": {
                    "operationId": "ModelService_ListModels",
                    "responses": {
                      "200": {
                        "description": "ok"
                      }
                    }
                  }
                }
              }
            }
        """).strip() + "\n",
        encoding="utf-8",
    )

    result = subprocess.run(
        ["bash", "./scripts/convert-tensormesh-openapi.sh"],
        cwd=repo,
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr
    generated = json.loads(
        (repo / RAW_SPECS_DIR / "model" / "v1" /
         "model_service.openapi.json").read_text(encoding="utf-8"))
    assert "servers" not in generated


def test_convert_tensormesh_openapi_omits_servers_in_generated_specs(
    tmp_path: Path, ) -> None:
    if shutil.which("jq") is None:
        return

    repo = tmp_path / "repo"
    (repo / "openapi" / "tensormesh" / "model" / "v1").mkdir(parents=True)
    (repo / "certs").mkdir(parents=True)

    _copy_repo_script("scripts/convert-tensormesh-openapi.sh", repo)
    _copy_repo_script("scripts/lib/common.sh", repo)
    _copy_repo_script("scripts/normalize-openapi-spec.py", repo)
    _copy_repo_script("scripts/lib/openapi_text.py", repo)
    _copy_repo_script("src/tensormesh/_constants.py", repo)
    _write_fake_swagger2openapi(repo)

    allowlist = repo / "openapi" / "tensormesh" / "zero-path-allowlist.txt"
    allowlist.write_text("", encoding="utf-8")

    swagger_path = (repo / "openapi" / "tensormesh" / "model" / "v1" /
                    "model_service.swagger.json")
    swagger_path.write_text(
        textwrap.dedent("""
            {
              "swagger": "2.0",
              "info": {
                "title": "Model Service",
                "version": "0.1.0"
              },
              "paths": {
                "/v1/models": {
                  "get": {
                    "operationId": "ModelService_ListModels",
                    "responses": {
                      "200": {
                        "description": "ok"
                      }
                    }
                  }
                }
              }
            }
        """).strip() + "\n",
        encoding="utf-8",
    )

    result = subprocess.run(
        ["bash", "./scripts/convert-tensormesh-openapi.sh"],
        cwd=repo,
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr
    generated = json.loads(
        (repo / RAW_SPECS_DIR / "model" / "v1" /
         "model_service.openapi.json").read_text(encoding="utf-8"))
    assert "servers" not in generated


def test_repo_raw_control_plane_specs_are_checked_in_as_raw_inputs() -> None:
    docs_json_mod = load_script_module(
        DOCS_JSON_SCRIPT_PATH,
        module_name="update_tensormesh_docs_json_convert_test",
    )
    docs_json_mod.build_docs_json(
        REPO_ROOT,
        write_output=False,
        write_published_specs=True,
        write_docs_json=False,
    )
    raw_model_spec = REPO_ROOT / RAW_SPECS_DIR / "model" / "v1" / (
        "model_service.openapi.json")
    raw_billing_model_spec = REPO_ROOT / RAW_SPECS_DIR / "billing" / "v1" / (
        "billing_model_service.openapi.json")
    raw_merged_model_spec = REPO_ROOT / RAW_SPECS_DIR / "model" / "v1" / (
        "model.openapi.json")
    published_merged_model_spec = (
        REPO_ROOT / docs_json_mod.PUBLISHED_CONTROL_PLANE_SPECS_DIR / "model" /
        "v1" / "model.openapi.json")

    assert raw_model_spec.exists()
    assert raw_billing_model_spec.exists()
    assert not raw_merged_model_spec.exists()
    assert published_merged_model_spec.exists()
