from __future__ import annotations

from typing import Any
from unittest.mock import patch

import click
import pytest


class _Model:

    def __init__(self, payload: dict[str, Any]) -> None:
        self._payload = payload

    def to_dict(self) -> dict[str, Any]:
        return dict(self._payload)


def test_resolve_latest_gateway_model_reads_models_inventory() -> None:
    import tensormesh_cli.commands.infer_latest as infer_latest

    ctx = click.Context(click.Command("infer-latest-test"))

    with patch(
            "tensormesh_cli.controlplane.execute_controlplane_sdk",
            return_value=([
                _Model({
                    "modelId": "m1",
                    "modelName": "gw_new",
                    "status": "MODEL_STATUS_UP",
                    "updatedAt": "2024-02-01T00:00:00Z",
                })
            ], None),
    ) as mock_request:
        model = infer_latest.resolve_latest_gateway_model(ctx, timeout_s=4.0)

    assert model == "gw_new"
    mock_request.assert_called_once()


def test_resolve_latest_gateway_model_wraps_non_json_controlplane_response(
) -> None:
    import tensormesh_cli.commands.infer_latest as infer_latest

    ctx = click.Context(click.Command("infer-latest-test"))

    with patch(
            "tensormesh_cli.controlplane.execute_controlplane_sdk",
            side_effect=click.ClickException(
                "Invalid JSON response: expected JSON. Raw response: not-json"
            ),
    ):
        with pytest.raises(
                click.ClickException,
                match=
                "Failed to resolve @latest: control plane returned non-JSON: not-json"
        ):
            infer_latest.resolve_latest_gateway_model(ctx, timeout_s=4.0)
