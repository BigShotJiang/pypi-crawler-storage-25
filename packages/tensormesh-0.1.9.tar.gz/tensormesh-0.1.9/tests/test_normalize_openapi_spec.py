from __future__ import annotations

from pathlib import Path

from tests.script_test_utils import load_script_module

SCRIPT_PATH = (Path(__file__).resolve().parents[1] / "scripts" /
               "normalize-openapi-spec.py")


def test_normalize_openapi_spec_reuses_shared_titleization_policy() -> None:
    mod = load_script_module(SCRIPT_PATH)
    spec = {
        "paths": {
            "/v1/models:search-by-infra": {
                "post": {
                    "operationId": "model_service_searchByInfra",
                    "summary": "searchByInfra Search models by infra",
                }
            }
        },
        "components": {
            "schemas": {
                "ModelChatRequest": {
                    "description": "Chat payload",
                }
            }
        },
    }

    normalized = mod.normalize_openapi_spec(spec,
                                            title="Title",
                                            server="https://api.example")
    operation = normalized["paths"]["/v1/models:search-by-infra"]["post"]

    assert operation["summary"] == "Search By Infra"
    assert operation["description"] == "Search models by infra"


def test_normalize_openapi_spec_dedupes_request_body_description() -> None:
    mod = load_script_module(SCRIPT_PATH)
    spec = {
        "paths": {
            "/v1/models/{modelId}:chat": {
                "post": {
                    "requestBody": {
                        "description": "Chat payload",
                        "content": {
                            "application/json": {
                                "schema": {
                                    "$ref":
                                    "#/components/schemas/ModelChatRequest"
                                }
                            }
                        },
                    }
                }
            }
        },
        "components": {
            "schemas": {
                "ModelChatRequest": {
                    "description": "Chat payload",
                }
            }
        },
    }

    normalized = mod.normalize_openapi_spec(spec,
                                            title="Title",
                                            server="https://api.example")
    request_body = normalized["paths"]["/v1/models/{modelId}:chat"]["post"][
        "requestBody"]

    assert "description" not in request_body
