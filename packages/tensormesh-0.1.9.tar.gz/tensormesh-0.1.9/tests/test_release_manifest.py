from __future__ import annotations

import json
from pathlib import Path
import subprocess

import pytest

from tensormesh.build_info import __version__
from tests.script_test_utils import load_script_module

REPO_ROOT = Path(__file__).resolve().parents[1]
MANIFEST_SCRIPT = REPO_ROOT / "scripts" / "build-release-manifest.py"
RELEASE_READINESS_SCRIPT = REPO_ROOT / "scripts" / "check-release-readiness.py"
PUBLIC_CLI_RELEASE_SCRIPT = REPO_ROOT / "scripts" / "verify-public-cli-release-surface.py"
RELEASE_NOTES_SCRIPT = REPO_ROOT / "scripts" / "build-release-notes.py"


def test_sdk_surface_declares_package_metadata(tmp_path: Path) -> None:
    wheel_path = tmp_path / f"tensormesh-{__version__}-py3-none-any.whl"
    wheel_path.write_bytes(b"wheel")

    mod = load_script_module(MANIFEST_SCRIPT)
    manifest = mod.build_manifest(sdk_dist_dir=tmp_path)

    assert manifest["manifest_version"] == 3
    assert manifest["git_tag"] == f"v{__version__}"
    assert "surfaces" in manifest
    sdk = manifest["surfaces"]["sdk"]
    assert sdk["package_name"] == "tensormesh"
    assert sdk["package_version"] == __version__
    assert sdk["artifacts"][0]["filename"] == wheel_path.name


def test_cli_surface_declares_binary_artifacts(tmp_path: Path) -> None:
    artifact_path = tmp_path / "tm-darwin-arm64.tar.gz"
    artifact_path.write_bytes(b"cli")

    mod = load_script_module(MANIFEST_SCRIPT)
    manifest = mod.build_manifest(cli_dist_dir=tmp_path)

    assert manifest["manifest_version"] == 3
    cli = manifest["surfaces"]["cli"]
    assert cli["artifacts"][0]["platform"] == "darwin-arm64"
    assert cli["artifacts"][0]["filename"] == artifact_path.name
    assert "install-tm.sh" in cli["artifacts"][0]["install_command"]
    assert f"TM_VERSION=v{__version__}" in cli["artifacts"][0][
        "install_command"]
    assert f"/v{__version__}/install-tm.sh" in cli["artifacts"][0][
        "install_command"]


def test_merged_manifest_contains_both_surfaces(tmp_path: Path) -> None:
    sdk_dir = tmp_path / "sdk"
    sdk_dir.mkdir()
    (sdk_dir /
     f"tensormesh-{__version__}-py3-none-any.whl").write_bytes(b"wheel")

    cli_dir = tmp_path / "cli"
    cli_dir.mkdir()
    (cli_dir / "tm-linux-amd64.tar.gz").write_bytes(b"cli")

    mod = load_script_module(MANIFEST_SCRIPT)
    manifest = mod.build_manifest(sdk_dist_dir=sdk_dir, cli_dist_dir=cli_dir)

    assert manifest["manifest_version"] == 3
    assert "sdk" in manifest["surfaces"]
    assert "cli" in manifest["surfaces"]
    assert manifest["surfaces"]["sdk"]["package_version"] == __version__
    assert manifest["surfaces"]["cli"]["cli_version"] == __version__


def test_cli_surface_allows_runtime_public_repo_override(
        tmp_path: Path) -> None:
    artifact_path = tmp_path / "tm-linux-amd64.tar.gz"
    artifact_path.write_bytes(b"cli")

    mod = load_script_module(MANIFEST_SCRIPT)
    manifest = mod.build_manifest(
        cli_dist_dir=tmp_path,
        public_release_repo="example-org/example-cli",
    )

    assert "example-org/example-cli" in manifest["surfaces"]["cli"][
        "artifacts"][0]["install_command"]
    assert "Tensormesh-Production/tensormesh-cli" not in manifest["surfaces"][
        "cli"]["artifacts"][0]["install_command"]


def test_cli_artifact_names_include_os_and_arch() -> None:
    names = [
        "tm-darwin-arm64.tar.gz",
        "tm-darwin-amd64.tar.gz",
        "tm-linux-amd64.tar.gz",
        "tm-linux-arm64.tar.gz",
    ]
    for name in names:
        assert name.startswith("tm-")
        assert name.endswith(".tar.gz")


def test_cli_smoke_script_checks_version_and_help_commands() -> None:
    text = (REPO_ROOT / "scripts" /
            "smoke-test-cli-dist.sh").read_text(encoding="utf-8")

    assert '"$tm_bin" version' in text
    assert '"$tm_bin" --help' in text
    assert '"$tm_bin" init --help' in text


def test_cli_release_readiness_accepts_cli_artifact_set(
        tmp_path: Path) -> None:
    repo_root = tmp_path / "repo"
    build_info_dir = repo_root / "src" / "tensormesh"
    build_info_dir.mkdir(parents=True)
    build_info_dir.joinpath("build_info.py").write_text(
        '__version__ = "0.2.0"\n',
        encoding="utf-8",
    )
    repo_root.joinpath("CHANGELOG.md").write_text(
        "# Changelog\n\n## 0.2.0\n\n- release\n",
        encoding="utf-8",
    )
    policy_dir = repo_root / "dev"
    policy_dir.mkdir()
    (policy_dir / "sdk-release-policy.md").write_text("# policy\n",
                                                      encoding="utf-8")
    dist_dir = repo_root / "dist" / "cli"
    dist_dir.mkdir(parents=True)
    artifact_name = "tm-linux-amd64.tar.gz"
    artifact_contents = b"cli"
    (dist_dir / artifact_name).write_bytes(artifact_contents)
    digest = subprocess.run(
        [
            "python3",
            "-c",
            "from hashlib import sha256; print(sha256(b'cli').hexdigest())",
        ],
        cwd=REPO_ROOT,
        capture_output=True,
        text=True,
        check=True,
    ).stdout.strip()
    (dist_dir / "SHA256SUMS").write_text(
        f"{digest}  {artifact_name}\n",
        encoding="utf-8",
    )
    (dist_dir / "RELEASE-MANIFEST.json").write_text(
        json.dumps({
            "manifest_version": 3,
            "git_tag": "v0.2.0",
            "surfaces": {
                "cli": {
                    "cli_version":
                    "0.2.0",
                    "install_guide":
                    "/cli/guides/installation",
                    "artifacts": [{
                        "filename":
                        "tm-linux-amd64.tar.gz",
                        "platform":
                        "linux-amd64",
                        "sha256":
                        digest,
                        "install_command":
                        "curl -fsSL .../v0.2.0/scripts/install-tm.sh | TM_VERSION=v0.2.0 sh",
                    }],
                }
            },
        }),
        encoding="utf-8",
    )

    mod = load_script_module(RELEASE_READINESS_SCRIPT)
    errors = mod.validate_release_readiness(
        repo_root,
        version="0.2.0",
        tag="v0.2.0",
        dist_dir=dist_dir,
        require_artifacts=True,
        surface="cli",
    )

    assert errors == []


def test_public_cli_release_surface_verifier_checks_expected_urls() -> None:
    mod = load_script_module(PUBLIC_CLI_RELEASE_SCRIPT)
    seen: list[str] = []

    def _fetch(url: str) -> tuple[int, str]:
        seen.append(url)
        return 200, url

    errors = mod.verify_public_cli_release_surface(
        repo_full_name="Tensormesh-Production/tensormesh-cli",
        git_tag="v0.2.0",
        artifact_filenames=["tm-linux-amd64.tar.gz", "tm-darwin-arm64.tar.gz"],
        fetch_url=_fetch,
    )

    assert errors == []
    assert seen == [
        "https://github.com/Tensormesh-Production/tensormesh-cli/releases",
        "https://raw.githubusercontent.com/Tensormesh-Production/tensormesh-cli/main/install-tm.sh",
        "https://raw.githubusercontent.com/Tensormesh-Production/tensormesh-cli/main/latest.json",
        "https://github.com/Tensormesh-Production/tensormesh-cli/releases/download/v0.2.0/SHA256SUMS",
        "https://github.com/Tensormesh-Production/tensormesh-cli/releases/download/v0.2.0/RELEASE-MANIFEST.json",
        "https://github.com/Tensormesh-Production/tensormesh-cli/releases/download/v0.2.0/install-tm.sh",
        "https://github.com/Tensormesh-Production/tensormesh-cli/releases/download/v0.2.0/tm-linux-amd64.tar.gz",
        "https://github.com/Tensormesh-Production/tensormesh-cli/releases/download/v0.2.0/tm-darwin-arm64.tar.gz",
    ]


def test_public_cli_release_surface_verifier_reports_unreachable_assets(
) -> None:
    mod = load_script_module(PUBLIC_CLI_RELEASE_SCRIPT)

    def _fetch(url: str) -> tuple[int, str]:
        if url.endswith("/releases"):
            return 404, url
        return 200, url

    errors = mod.verify_public_cli_release_surface(
        repo_full_name="Tensormesh-Production/tensormesh-cli",
        git_tag="v0.2.0",
        artifact_filenames=["tm-linux-amd64.tar.gz"],
        fetch_url=_fetch,
    )

    assert errors == [
        "public CLI release URL returned HTTP 404: https://github.com/Tensormesh-Production/tensormesh-cli/releases"
    ]


def test_public_cli_release_surface_verifier_reports_network_errors() -> None:
    mod = load_script_module(PUBLIC_CLI_RELEASE_SCRIPT)

    def _fetch(url: str) -> tuple[int, str]:
        return 599, url

    errors = mod.verify_public_cli_release_surface(
        repo_full_name="Tensormesh-Production/tensormesh-cli",
        git_tag="v0.2.0",
        artifact_filenames=["tm-linux-amd64.tar.gz"],
        fetch_url=_fetch,
    )

    assert errors == [
        "public CLI release URL returned HTTP 599: https://github.com/Tensormesh-Production/tensormesh-cli/releases",
        "public CLI release URL returned HTTP 599: https://raw.githubusercontent.com/Tensormesh-Production/tensormesh-cli/main/install-tm.sh",
        "public CLI release URL returned HTTP 599: https://raw.githubusercontent.com/Tensormesh-Production/tensormesh-cli/main/latest.json",
        "public CLI release URL returned HTTP 599: https://github.com/Tensormesh-Production/tensormesh-cli/releases/download/v0.2.0/SHA256SUMS",
        "public CLI release URL returned HTTP 599: https://github.com/Tensormesh-Production/tensormesh-cli/releases/download/v0.2.0/RELEASE-MANIFEST.json",
        "public CLI release URL returned HTTP 599: https://github.com/Tensormesh-Production/tensormesh-cli/releases/download/v0.2.0/install-tm.sh",
        "public CLI release URL returned HTTP 599: https://github.com/Tensormesh-Production/tensormesh-cli/releases/download/v0.2.0/tm-linux-amd64.tar.gz",
    ]


def test_build_release_notes_extracts_requested_version(
        tmp_path: Path) -> None:
    changelog = tmp_path / "CHANGELOG.md"
    changelog.write_text(
        "# Changelog\n\n## Unreleased\n\n- Pending\n\n## 0.1.1\n\n- Added clean release notes.\n- Published changelog body.\n\n## 0.1.0\n\n- Initial release.\n",
        encoding="utf-8",
    )

    mod = load_script_module(RELEASE_NOTES_SCRIPT)
    notes = mod.build_release_notes(changelog_path=changelog, version="0.1.1")

    assert notes == (
        "## 0.1.1\n\n- Added clean release notes.\n- Published changelog body.\n"
    )


def test_build_release_notes_accepts_v_prefixed_tag(tmp_path: Path) -> None:
    changelog = tmp_path / "CHANGELOG.md"
    changelog.write_text(
        "# Changelog\n\n## 0.1.1\n\n- Added clean release notes.\n",
        encoding="utf-8",
    )

    mod = load_script_module(RELEASE_NOTES_SCRIPT)
    notes = mod.build_release_notes(changelog_path=changelog, version="v0.1.1")

    assert notes == "## 0.1.1\n\n- Added clean release notes.\n"


def test_build_release_notes_rejects_missing_or_empty_section(
        tmp_path: Path) -> None:
    changelog = tmp_path / "CHANGELOG.md"
    changelog.write_text("# Changelog\n\n## 0.1.1\n\n", encoding="utf-8")

    mod = load_script_module(RELEASE_NOTES_SCRIPT)

    with pytest.raises(SystemExit,
                       match="CHANGELOG.md section for 0.1.1 is empty"):
        mod.main([
            "--tag",
            "v0.1.1",
            "--changelog",
            str(changelog),
            "--output",
            str(tmp_path / "notes.md"),
        ])
