from __future__ import annotations

import os
from pathlib import Path
import tempfile

import pytest

from tensormesh_cli.config.write import write_private_text


def test_write_private_text_creates_parent_and_writes_private_file(
    tmp_path: Path, ) -> None:
    target = tmp_path / "nested" / "config.toml"

    write_private_text(target, 'token = "secret"\n')

    assert target.read_text(encoding="utf-8") == 'token = "secret"\n'
    assert oct(target.stat().st_mode & 0o777) == "0o600"


def test_write_private_text_ignores_close_error_after_success(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    target = tmp_path / "config.toml"
    real_close = os.close
    closed_fds: list[int] = []

    def fake_close(fd: int) -> None:
        closed_fds.append(fd)
        if len(closed_fds) == 1:
            raise OSError("close failed")
        real_close(fd)

    monkeypatch.setattr("tensormesh_cli.config.write.os.close", fake_close)

    write_private_text(target, "ok\n")

    assert target.read_text(encoding="utf-8") == "ok\n"
    assert closed_fds


def test_write_private_text_cleans_temp_file_when_replace_fails(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    target = tmp_path / "config.toml"
    created_tmp: list[Path] = []
    real_mkstemp = tempfile.mkstemp

    def fake_mkstemp(*args, **kwargs):
        fd, name = real_mkstemp(*args, **kwargs)
        created_tmp.append(Path(name))
        return fd, name

    def fake_replace(src: str, dst: str) -> None:
        raise OSError("replace failed")

    monkeypatch.setattr("tensormesh_cli.config.write.tempfile.mkstemp",
                        fake_mkstemp)
    monkeypatch.setattr("tensormesh_cli.config.write.os.replace", fake_replace)

    with pytest.raises(OSError, match="replace failed"):
        write_private_text(target, "broken\n")

    assert not target.exists()
    assert created_tmp
    assert created_tmp[0].exists() is False


def test_write_private_text_ignores_unlink_error_during_cleanup(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    target = tmp_path / "config.toml"
    unlink_calls: list[str] = []

    def fake_replace(src: str, dst: str) -> None:
        raise OSError("replace failed")

    def fake_unlink(path: str) -> None:
        unlink_calls.append(path)
        raise OSError("unlink failed")

    monkeypatch.setattr("tensormesh_cli.config.write.os.replace", fake_replace)
    monkeypatch.setattr("tensormesh_cli.config.write.os.unlink", fake_unlink)

    with pytest.raises(OSError, match="replace failed"):
        write_private_text(target, "broken\n")

    assert unlink_calls
