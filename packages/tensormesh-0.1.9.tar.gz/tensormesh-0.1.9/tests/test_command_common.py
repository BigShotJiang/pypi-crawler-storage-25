from __future__ import annotations

from io import StringIO

import click
import pytest

from tensormesh_cli.commands.request_utils import build_query_params
from tensormesh_cli.commands.request_utils import require_json_object
from tensormesh_cli.commands.request_utils import resolve_command_request


class _FakeStdin(StringIO):

    def isatty(self) -> bool:
        return True


def _ctx() -> click.Context:
    return click.Context(click.Command("test"))


def test_build_query_params_skips_empty_strings_and_formats_bools() -> None:
    assert build_query_params(
        user_id="  u1  ",
        empty="   ",
        enabled=True,
        disabled=False,
        limit=10,
        missing=None,
    ) == {
        "user_id": "u1",
        "enabled": "true",
        "disabled": "false",
        "limit": "10",
    }


def test_require_json_object_raises_usage_error_for_non_object() -> None:
    with pytest.raises(click.UsageError,
                       match="Request body must be a JSON object."):
        require_json_object(ctx=_ctx(), body_obj=["not", "an", "object"])


def test_resolve_command_request_uses_callable_value_error_message(
        monkeypatch: pytest.MonkeyPatch) -> None:
    import tensormesh_cli.commands.request_utils as request_utils

    monkeypatch.setattr(request_utils.sys, "stdin", _FakeStdin(""))

    with pytest.raises(click.UsageError, match="wrapped: boom"):
        resolve_command_request(
            ctx=_ctx(),
            json_arg=None,
            file_path=None,
            build_from_values=lambda:
            (_ for _ in ()).throw(ValueError("boom")),
            build_from_json=lambda body: body,
            value_error_message=lambda exc: f"wrapped: {exc}",
            to_payload=lambda request: request,
        )


def test_resolve_command_request_uses_to_payload_override(
        monkeypatch: pytest.MonkeyPatch) -> None:
    import tensormesh_cli.commands.request_utils as request_utils

    monkeypatch.setattr(request_utils.sys, "stdin", _FakeStdin(""))

    resolved = resolve_command_request(
        ctx=_ctx(),
        json_arg=None,
        file_path=None,
        build_from_values=lambda: {"request": "ok"},
        build_from_json=lambda body: body,
        to_payload=lambda request: {"payload": request["request"]},
    )

    assert resolved.request == {"request": "ok"}
    assert resolved.payload == {"payload": "ok"}
