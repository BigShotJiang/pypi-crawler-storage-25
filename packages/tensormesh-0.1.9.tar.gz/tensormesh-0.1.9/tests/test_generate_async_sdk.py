from __future__ import annotations

from pathlib import Path

import pytest

from tests.script_test_utils import load_script_module

SCRIPT_PATH = (Path(__file__).resolve().parents[1] / "scripts" /
               "generate-async-sdk.py")


def test_generator_inventory_uses_explicit_module_specs() -> None:
    mod = load_script_module(SCRIPT_PATH)

    spec_names = [spec.target_path.name for spec in mod.GENERATORS]

    assert spec_names == [
        "_async_client.py",
        "_control_plane_async_public.py",
        "_control_plane_async_admin.py",
        "_control_plane_async_billing.py",
        "_control_plane_async_observability_support.py",
    ]


def test_async_client_validation_rejects_sync_only_residue() -> None:
    mod = load_script_module(SCRIPT_PATH)
    spec = next(spec for spec in mod.GENERATORS
                if spec.target_path.name == "_async_client.py")

    with pytest.raises(
            ValueError,
            match="forbidden sync residue.*SyncTransport",
    ):
        mod._validate_generated_module(
            spec,
            "\n".join([
                "from ._transport import SyncTransport",
                "class AsyncTensormesh:",
                "    async def __aenter__(self):",
                "        return self",
                "    async def __aexit__(self, exc_type, exc, tb):",
                "        return None",
                "    async def close(self) -> None:",
                "        return None",
                "    async def request(self):",
                "        await self._transport.request()",
                "        await self._transport.request_stream()",
            ]) + "\n",
        )


def test_async_resource_validation_requires_async_protocol_and_iterator(
) -> None:
    mod = load_script_module(SCRIPT_PATH)
    spec = next(spec for spec in mod.GENERATORS
                if spec.target_path.name == "_control_plane_async_public.py")

    with pytest.raises(
            ValueError,
            match="missing required async marker.*AsyncIterator",
    ):
        mod._validate_generated_module(
            spec,
            "from typing import Iterator\nclass AsyncModelsClient:\n    pass\n",
        )
