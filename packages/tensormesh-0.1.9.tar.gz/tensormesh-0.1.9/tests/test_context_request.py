from __future__ import annotations

from typing import Any

import pytest
import requests

from tensormesh_cli.http.context_request import execute_request
from tensormesh_cli.http.context_request import RequestConfigError
from tensormesh_cli.http.context_request import RequestExecutionError
from tensormesh_cli.http.context_request import RequestRuntime
from tests.response_test_utils import JSONResponse


def test_execute_request_uses_runtime_values_and_emits_debug() -> None:
    captured: dict[str, Any] = {}
    debug_messages: list[str] = []

    def fake_request(method: str, url: str, **kwargs: Any) -> JSONResponse:
        captured["method"] = method
        captured["url"] = url
        captured["kwargs"] = kwargs
        log_attempt = kwargs.get("log_attempt")
        if callable(log_attempt):
            log_attempt(1, 2)
        return JSONResponse(status_code=200, payload={"ok": True})

    runtime = RequestRuntime(
        verify="/tmp/ca.pem",
        timeout_seconds=12.0,
        max_retries=1,
        debug=True,
        emit_debug=debug_messages.append,
    )

    resp = execute_request(runtime,
                           method="GET",
                           url="https://example.test/v1/models",
                           headers={"Authorization": "Bearer tok"},
                           params={"limit": "10"},
                           request_fn=fake_request)

    assert resp.status_code == 200
    assert captured["method"] == "GET"
    assert captured["url"] == "https://example.test/v1/models"
    assert captured["kwargs"]["verify"] == "/tmp/ca.pem"
    assert captured["kwargs"]["timeout_s"] == 12.0
    assert captured["kwargs"]["max_retries"] == 1
    assert captured["kwargs"]["idempotent"] is True
    assert debug_messages
    assert "Authorization" in debug_messages[0]


def test_execute_request_raises_config_error_for_invalid_timeout() -> None:
    runtime = RequestRuntime(verify=True, timeout_seconds=0, max_retries=0)

    with pytest.raises(RequestConfigError,
                       match="Timeout must be greater than 0 seconds."):
        execute_request(runtime,
                        method="GET",
                        url="https://example.test/v1/models")


def test_execute_request_raises_execution_error_for_http_error() -> None:

    def fake_request(method: str, url: str, **kwargs: Any) -> JSONResponse:
        return JSONResponse(status_code=503, payload={"error": "unavailable"})

    runtime = RequestRuntime(verify=True, timeout_seconds=30, max_retries=0)

    with pytest.raises(RequestExecutionError, match="HTTP 503"):
        execute_request(runtime,
                        method="GET",
                        url="https://example.test/v1/models",
                        request_fn=fake_request)


def test_execute_request_raises_execution_error_for_network_failure() -> None:

    def fake_request(method: str, url: str, **kwargs: Any) -> JSONResponse:
        raise requests.Timeout("boom")

    runtime = RequestRuntime(verify=True, timeout_seconds=30, max_retries=0)

    with pytest.raises(RequestExecutionError,
                       match="Request failed \\(network error\\): boom"):
        execute_request(runtime,
                        method="GET",
                        url="https://example.test/v1/models",
                        request_fn=fake_request)
