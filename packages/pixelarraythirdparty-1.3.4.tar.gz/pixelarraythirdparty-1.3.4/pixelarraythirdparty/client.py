import aiohttp
from typing import Dict, Any, Tuple


class AsyncClient:
    def __init__(self, api_key: str):
        """
        description:
            初始化异步客户端
        parameters:
            api_key(str): API密钥，用于身份验证
        """
        self.base_url = "https://thirdparty.pixelarrayai.com"
        self.api_key = api_key
        self.headers = {
            "Content-Type": "application/json",
            "X-API-Key": self.api_key,
        }

    async def _request(
        self, method: str, url: str, **kwargs
    ) -> Tuple[Dict[str, Any], bool]:
        """
        description:
            发送异步HTTP请求的通用方法
        parameters:
            method(str): HTTP方法，如"GET"、"POST"、"PUT"、"DELETE"等
            url(str): 请求URL路径（相对于base_url）
            **kwargs: 其他请求参数，如json、params、headers等
        return:
            data(Dict[str, Any]): 成功时为服务端 data 字段；失败时为包含 message/status_code 等的字典，调用方可通过 message 查看失败原因
            success(bool): 请求是否成功
        """
        headers = self.headers.copy()
        if "headers" in kwargs:
            headers.update(kwargs["headers"])
            kwargs = {k: v for k, v in kwargs.items() if k != "headers"}

        result = None
        raw_text = ""
        resp_status = 0

        async with aiohttp.ClientSession() as session:
            req_method = getattr(session, method.lower())
            async with req_method(
                f"{self.base_url}{url}", headers=headers, **kwargs
            ) as resp:
                raw_text = await resp.text()
                resp_status = resp.status
                if resp.status == 200:
                    try:
                        import json
                        result = json.loads(raw_text)
                        if result.get("success") is True:
                            return result.get("data", {}), True
                        data_val = result.get("data")
                        if data_val is not None and (
                            (isinstance(data_val, dict) and data_val)
                            or (isinstance(data_val, list) and data_val)
                        ):
                            return result.get("data", {}), True
                    except Exception:
                        pass
                elif raw_text:
                    try:
                        import json
                        result = json.loads(raw_text)
                    except Exception:
                        pass
                # 失败时返回包含 message 的字典，便于调用方展示具体失败原因
                err = {
                    "message": (result.get("message") if result and isinstance(result, dict) else None) or (raw_text[:500] if raw_text else None) or "请求失败",
                    "status_code": (result.get("status_code") if result and isinstance(result, dict) else None) or resp_status,
                }
                if result and isinstance(result, dict) and "data" in result:
                    err["data"] = result.get("data")
                return err, False

    async def _request_raw(
        self, method: str, url: str, **kwargs
    ) -> Tuple[int, Dict[str, Any]]:
        """
        description:
            发送异步HTTP请求的原始方法，返回完整的HTTP状态码和响应数据
        parameters:
            method(str): HTTP方法，如"GET"、"POST"、"PUT"、"DELETE"等
            url(str): 请求URL路径（相对于base_url）
            **kwargs: 其他请求参数，如json、params、headers等
        return:
            status_code(int): HTTP状态码
            data(Dict[str, Any]): 响应数据字典，如果解析失败则返回空字典
        """
        headers = self.headers.copy()
        if "headers" in kwargs:
            headers.update(kwargs["headers"])
            kwargs = {k: v for k, v in kwargs.items() if k != "headers"}

        async with aiohttp.ClientSession() as session:
            req_method = getattr(session, method.lower())
            async with req_method(
                f"{self.base_url}{url}", headers=headers, **kwargs
            ) as resp:
                try:
                    data = await resp.json()
                except:
                    data = {}
                return resp.status, data
