from .unified_login import (
    OAuth2Login,
    GoogleLogin,
    WechatLogin,
    GitHubLogin,
    DouyinLogin,
    TiktokLogin,
    GitLabLogin,
    SMSLogin,
    EmailLogin,
    PasswordLogin,
)

__all__ = [
    "OAuth2Login",
    "GoogleLogin",
    "WechatLogin",
    "GitHubLogin",
    "DouyinLogin",
    "TiktokLogin",
    "GitLabLogin",
    "SMSLogin",
    "EmailLogin",
    "PasswordLogin",
]

