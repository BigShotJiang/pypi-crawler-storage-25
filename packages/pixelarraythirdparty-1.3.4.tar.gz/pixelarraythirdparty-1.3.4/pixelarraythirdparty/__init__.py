#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
PixelArray 第三方微服务客户端
这个库包含了常用的开发工具和服务集成：
- order: 订单管理模块和支付模块
- product: 产品管理模块
- cron: 定时任务管理模块
- user: 用户管理模块
- unified_login: 统一登录模块
- feedback: 客户反馈模块
- project: 项目管理模块
- support_chat: 在线客服（临时会话链接）
- custom_events: 自定义事件（新建定义、上报与报表查询）
- project_dashboard: 项目看板（按 scope 查询 DNU/DAU/留存）
"""

from .support_chat.support_chat import SupportChatManagerAsync
from .custom_events.custom_events import CustomEventsManagerAsync
from .project_dashboard.project_dashboard import ProjectDashboardManagerAsync

__version__ = "1.3.4"
__author__ = "Lu qi"
__email__ = "qi.lu@pixelarrayai.com"

# 导出主要模块
__all__ = [
    "product",
    "cron",
    "user",
    "order",
    "feedback",
    "project",
    "support_chat",
    "custom_events",
    "project_dashboard",
    "SupportChatManagerAsync",
    "CustomEventsManagerAsync",
    "ProjectDashboardManagerAsync",
]
