# -*- coding: utf-8 -*-
from pixelarraythirdparty.project_dashboard.project_dashboard import (
    ProjectDashboardManagerAsync,
)

__all__ = ["ProjectDashboardManagerAsync"]
