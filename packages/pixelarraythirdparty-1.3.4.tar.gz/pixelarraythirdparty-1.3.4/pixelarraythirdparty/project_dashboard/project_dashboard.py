# -*- coding: utf-8 -*-
from typing import Any, Dict, Optional, Tuple

from pixelarraythirdparty.client import AsyncClient


def _resolve_dashboard_path(scope: str) -> Optional[str]:
    s = (scope or "").strip()
    if s.upper() == "DNU":
        return "/api/project-dashboard/dashboard/dnu"
    if s.upper() == "DAU":
        return "/api/project-dashboard/dashboard/dau"
    if s.upper() == "RETENTION" or s == "留存":
        return "/api/project-dashboard/dashboard/retention"
    return None


class ProjectDashboardManagerAsync(AsyncClient):
    """项目看板：按 scope 查询 DNU / DAU / 留存（与 Portal 同源接口，需 API Key）。"""

    async def query_dashboard(
        self,
        project_name: str,
        scope: str,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        retention_days: Optional[str] = None,
    ) -> Tuple[Dict[str, Any], bool]:
        """
        description:
            查询项目看板指标；scope 为 DNU、DAU、RETENTION 或中文「留存」。
        parameters:
            project_name(str): 项目名称（与统一登录 project_name 一致）
            scope(str): DNU | DAU | RETENTION | 留存
            start_date(str, optional): 开始日期 YYYY-MM-DD；不传则服务端默认 T-7
            end_date(str, optional): 结束日期 YYYY-MM-DD；不传则服务端默认 T-0
            retention_days(str, optional): 仅 scope 为留存时有效；逗号分隔天数，如 2,7,14,20；不传则服务端默认
        return:
            data(dict): 成功时为 DauData / DnuData / RetentionData 结构（见接口文档）
            success(bool): 是否成功
        """
        path = _resolve_dashboard_path(scope)
        if not path:
            return (
                {"message": "scope 无效，应为 DNU、DAU、RETENTION 或 留存"},
                False,
            )
        params: Dict[str, Any] = {"project_name": project_name}
        if start_date:
            params["start_date"] = start_date
        if end_date:
            params["end_date"] = end_date
        if retention_days:
            params["retention_days"] = retention_days
        return await self._request("GET", path, params=params)
