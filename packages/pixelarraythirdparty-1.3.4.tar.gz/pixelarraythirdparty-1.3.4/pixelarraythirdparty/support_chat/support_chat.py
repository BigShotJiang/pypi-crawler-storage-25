from pixelarraythirdparty.client import AsyncClient


class SupportChatManagerAsync(AsyncClient):
    async def create_support_chat_link(
        self,
        expires_in_hours: int = 24,
    ):
        """
        description:
            创建在线客服临时会话链接。其它服务调用此接口后，将返回的 chat_url 下发给用户，
            用户打开链接即可与客服对话（无需登录）。链接有时效。
        parameters:
            expires_in_hours(int, optional): 链接有效小时数，默认 24，范围 1～720
        return:
            data(dict): 成功时包含
                - chat_url(str): 客服聊天页完整 URL
                - token(str): 会话 token
                - session_id(int): 会话 ID
                - expires_at(str): 过期时间
            success(bool): 操作是否成功
        """
        payload = {"expires_in_hours": expires_in_hours}
        data, success = await self._request(
            "POST", "/api/support-chat/create-link", json=payload
        )
        if not success:
            return data, False
        return data, True
