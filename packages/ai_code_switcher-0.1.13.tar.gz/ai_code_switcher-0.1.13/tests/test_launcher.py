import os
import pytest
from unittest.mock import patch, MagicMock
from src.code_ai.models import ApiProfile, LoginProfile
from src.code_ai.launcher import (
    prepare_environment,
    resolve_default_args,
    merge_launch_args,
)


def test_prepare_env_api_mode():
    """Test environment preparation for API mode"""
    profile = ApiProfile(
        name="test-api",
        type="claude",
        base_url="https://api.anthropic.com",
        token="sk-ant-test"
    )

    env = prepare_environment(profile)

    assert env["ANTHROPIC_BASE_URL"] == "https://api.anthropic.com"
    assert env["ANTHROPIC_AUTH_TOKEN"] == "sk-ant-test"


def test_prepare_env_api_mode_clears_stale_managed_vars():
    """API mode should not inherit stale managed vars from the parent shell"""
    with patch.dict(os.environ, {
        "ANTHROPIC_BASE_URL": "https://old.url",
        "ANTHROPIC_AUTH_TOKEN": "old-token",
        "CLAUDE_CONFIG_DIR": "/tmp/old-claude",
        "OPENAI_API_KEY": "old-openai-key",
        "HTTP_PROXY": "http://127.0.0.1:9999",
        "HTTPS_PROXY": "http://127.0.0.1:9999",
    }):
        profile = ApiProfile(
            name="test-api",
            type="claude",
            base_url="https://api.anthropic.com",
            token="sk-ant-test"
        )

        env = prepare_environment(profile)

        assert env["ANTHROPIC_BASE_URL"] == "https://api.anthropic.com"
        assert env["ANTHROPIC_AUTH_TOKEN"] == "sk-ant-test"
        assert "CLAUDE_CONFIG_DIR" not in env
        assert "OPENAI_API_KEY" not in env
        assert "HTTP_PROXY" not in env
        assert "HTTPS_PROXY" not in env


def test_prepare_env_login_mode():
    """Test environment preparation for login mode"""
    profile = LoginProfile(
        name="test-login",
        type="claude",
        credentials_path="~/.claude-profiles/account-a"
    )

    env = prepare_environment(profile)

    # Should NOT have API environment variables
    assert "ANTHROPIC_BASE_URL" not in env
    assert "ANTHROPIC_AUTH_TOKEN" not in env
    # Should have CLAUDE_CONFIG_DIR with expanded path
    expected_path = os.path.expanduser("~/.claude-profiles/account-a")
    assert env["CLAUDE_CONFIG_DIR"] == expected_path


def test_prepare_env_with_proxy():
    """Test environment preparation with proxy"""
    profile = ApiProfile(
        name="test-proxy",
        type="gemini",
        base_url="https://generativelanguage.googleapis.com",
        api_key="AIza-test",
        proxy="http://127.0.0.1:7890"
    )

    env = prepare_environment(profile)

    assert env["HTTP_PROXY"] == "http://127.0.0.1:7890"
    assert env["HTTPS_PROXY"] == "http://127.0.0.1:7890"


def test_prepare_env_login_clears_api_vars():
    """Test that login mode clears API environment variables"""
    # Set up environment with existing API variables
    with patch.dict(os.environ, {
        "ANTHROPIC_BASE_URL": "https://old.url",
        "ANTHROPIC_AUTH_TOKEN": "old-token"
    }):
        profile = LoginProfile(
            name="test-login",
            type="claude",
            credentials_path="~/.claude-profiles/account-a"
        )

        env = prepare_environment(profile)

        # Should be cleared
        assert "ANTHROPIC_BASE_URL" not in env
        assert "ANTHROPIC_AUTH_TOKEN" not in env


def test_prepare_env_codex_api_mode():
    """Test environment preparation for codex API mode"""
    profile = ApiProfile(
        name="test-codex-api",
        type="codex",
        base_url="https://api.openai.com/v1",
        api_key="sk-test"
    )

    env = prepare_environment(profile)

    # Should have both OPENAI_API_KEY and OPENAI_BASE_URL
    assert env["OPENAI_API_KEY"] == "sk-test"
    assert env["OPENAI_BASE_URL"] == "https://api.openai.com/v1"


def test_prepare_env_codex_login_mode():
    """Test environment preparation for codex login mode"""
    profile = LoginProfile(
        name="test-codex-login",
        type="codex",
        credentials_path="~/.codex-profiles/account-a"
    )

    env = prepare_environment(profile)

    # Should NOT have API environment variables
    assert "OPENAI_API_KEY" not in env
    # Should have CODEX_HOME with expanded path
    expected_path = os.path.expanduser("~/.codex-profiles/account-a")
    assert env["CODEX_HOME"] == expected_path


# ---------------------------------------------------------------------------
# default_args handling
# ---------------------------------------------------------------------------

def test_resolve_default_args_none():
    assert resolve_default_args(None) == []


def test_resolve_default_args_empty():
    assert resolve_default_args("") == []
    assert resolve_default_args([]) == []


def test_resolve_default_args_list_passthrough():
    assert resolve_default_args(["--model", "opus"]) == ["--model", "opus"]


def test_resolve_default_args_string_split():
    assert resolve_default_args("--model claude-opus-4-5 -p hi") == [
        "--model", "claude-opus-4-5", "-p", "hi"
    ]


def test_resolve_default_args_string_with_quotes():
    # POSIX shlex preserves quoted whitespace as a single token
    assert resolve_default_args('--prompt "hello world"') == [
        "--prompt", "hello world"
    ]


def test_resolve_default_args_invalid_type_raises():
    with pytest.raises(TypeError):
        resolve_default_args(42)


def test_merge_launch_args_no_defaults():
    """No profile defaults → returns extra_args unchanged."""
    assert merge_launch_args(["--resume"], None) == ["--resume"]


def test_merge_launch_args_only_defaults():
    """No CLI extras, only profile defaults."""
    assert merge_launch_args([], ["--model", "opus"]) == ["--model", "opus"]


def test_merge_launch_args_order_b_extras_before_defaults():
    """Q3 design = B: command-line first, defaults appended (defaults win)."""
    result = merge_launch_args(
        ["--model", "sonnet"],
        ["--model", "opus", "--dangerously-skip-permissions"],
    )
    assert result == [
        "--model", "sonnet",
        "--model", "opus", "--dangerously-skip-permissions",
    ]


def test_merge_launch_args_string_form_defaults():
    """default_args as string is shlex-split before merging."""
    result = merge_launch_args(["-p", "hi"], "--model opus")
    assert result == ["-p", "hi", "--model", "opus"]


def test_merge_launch_args_use_default_false_skips():
    """--no-default-args escape hatch: defaults dropped entirely."""
    result = merge_launch_args(
        ["--model", "sonnet"],
        ["--model", "opus"],
        use_default_args=False,
    )
    assert result == ["--model", "sonnet"]
