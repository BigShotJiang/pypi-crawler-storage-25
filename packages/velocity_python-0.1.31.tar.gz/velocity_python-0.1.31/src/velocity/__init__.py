__version__ = version = "0.1.31"

import importlib as _importlib

from . import db
from . import misc

__all__ = ["aws", "db", "misc"]

_LAZY_SUBMODULES = {"aws"}


def __getattr__(name: str):
    if name in _LAZY_SUBMODULES:
        return _importlib.import_module(f".{name}", __name__)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
