"""Tests for Solutions API methods on QuickbaseClient."""

from unittest.mock import MagicMock, patch

import pytest

from quickbase_api.client import QuickbaseClient
from quickbase_api.exceptions import QuickbaseAPIError

# Reuse the sample QBL from test_qbl
SAMPLE_QBL = """\
Version: '0.12'
ParameterDefinitions:
  $Param_App_Name:
    Value: My Test App
Resources:
  $App_My_Test_App:
    Type: QB::Application
    Properties:
      AppColor: '#1a73e8'
      AppIcon: Briefcase
      Manager: owner@example.com
    Tables:
      $Table_Tasks:
        Type: QB::Table
        Properties:
          Name: Tasks
"""

SAMPLE_TARGET_QBL = """\
Version: '0.12'
ParameterDefinitions:
  $Param_App_Name:
    Value: Target App
  $Param_App_AppColor:
    Value: '#ff0000'
  $Param_App_AppIcon:
    Value: Globe
Resources:
  $App_Target_App:
    Type: QB::Application
    Properties:
      Name: !Var
        Name: $Param_App_Name
      AppColor: !Var
        Name: $Param_App_AppColor
      AppIcon: !Var
        Name: $Param_App_AppIcon
      Manager: other@example.com
    Tables:
      $Table_Tasks:
        Type: QB::Table
        Properties:
          Name: Tasks
"""


@pytest.fixture
def client():
    return QuickbaseClient("test.quickbase.com", "fake-token")


class TestExportSolution:

    def test_returns_qbl_string(self, client):
        with patch.object(client._rm, "make_request", return_value=(SAMPLE_QBL, 200)):
            result = client.export_solution("sol-123")
            assert "Version" in result
            assert "Resources" in result

    def test_raises_on_error(self, client):
        error = {"message": "Not found"}
        with patch.object(client._rm, "make_request", return_value=(error, 404)):
            with pytest.raises(QuickbaseAPIError):
                client.export_solution("bad-id")


class TestGetSolution:

    def test_returns_dict(self, client):
        response = {"solutionId": "sol-123", "resources": []}
        with patch.object(client._rm, "get", return_value=(response, 200)):
            result = client.get_solution("sol-123")
            assert result["solutionId"] == "sol-123"

    def test_raises_on_error(self, client):
        error = {"message": "Not found"}
        with patch.object(client._rm, "get", return_value=(error, 404)):
            with pytest.raises(QuickbaseAPIError):
                client.get_solution("bad-id")


class TestCreateSolution:

    def test_returns_response(self, client):
        response = {"solutionId": "sol-new"}
        with patch.object(client._rm, "make_request", return_value=(response, 200)):
            result = client.create_solution(SAMPLE_QBL)
            assert result["solutionId"] == "sol-new"

    def test_passes_body_not_data(self, client):
        response = {"solutionId": "sol-new"}
        with patch.object(client._rm, "make_request", return_value=(response, 200)) as mock:
            client.create_solution(SAMPLE_QBL)
            _, kwargs = mock.call_args
            assert kwargs["body"] == SAMPLE_QBL

    def test_raises_on_error(self, client):
        error = {"message": "Bad QBL"}
        with patch.object(client._rm, "make_request", return_value=(error, 400)):
            with pytest.raises(QuickbaseAPIError):
                client.create_solution(SAMPLE_QBL)


class TestUpdateSolution:

    def test_returns_response(self, client):
        response = {"status": "updated"}
        with patch.object(client._rm, "make_request", return_value=(response, 200)):
            result = client.update_solution("sol-123", qbl=SAMPLE_QBL)
            assert result["status"] == "updated"

    def test_raises_on_error(self, client):
        error = {"message": "Failed"}
        with patch.object(client._rm, "make_request", return_value=(error, 400)):
            with pytest.raises(QuickbaseAPIError):
                client.update_solution("sol-123", qbl=SAMPLE_QBL)


class TestListSolutionChanges:

    def test_returns_changeset(self, client):
        response = {"changes": ["add field", "modify report"]}
        with patch.object(client._rm, "make_request", return_value=(response, 200)):
            result = client.list_solution_changes("sol-123", qbl=SAMPLE_QBL)
            assert len(result["changes"]) == 2

    def test_raises_on_error(self, client):
        error = {"message": "Failed"}
        with patch.object(client._rm, "make_request", return_value=(error, 400)):
            with pytest.raises(QuickbaseAPIError):
                client.list_solution_changes("sol-123", qbl=SAMPLE_QBL)


class TestPushSolution:

    def test_preview_returns_changeset(self, client):
        changeset = {"changes": ["add field"]}
        with patch.object(
            client._rm,
            "make_request",
            side_effect=[
                (SAMPLE_QBL, 200),  # export source
                (SAMPLE_TARGET_QBL, 200),  # export target
                (changeset, 200),  # list changes
            ],
        ):
            result = client.push_solution(
                "sol-source",
                "sol-target",
                preview_only=True,
            )
            assert result["changes"] == ["add field"]

    def test_apply_returns_result_and_diagnostics(self, client):
        update_response = {"status": "updated"}
        with patch.object(
            client._rm,
            "make_request",
            side_effect=[
                (SAMPLE_QBL, 200),  # export source
                (SAMPLE_TARGET_QBL, 200),  # export target
                (update_response, 200),  # update
            ],
        ):
            result, diagnostics = client.push_solution(
                "sol-source",
                "sol-target",
            )
            assert result["status"] == "updated"
            assert isinstance(diagnostics, object)

    def test_rejects_same_ids(self, client):
        with pytest.raises(ValueError, match="same"):
            client.push_solution("sol-123", "sol-123")

    def test_raises_on_source_export_error(self, client):
        error = {"message": "Not found"}
        with patch.object(client._rm, "make_request", return_value=(error, 404)):
            with pytest.raises(QuickbaseAPIError):
                client.push_solution("bad-id", "sol-target")

    def test_modifies_qbl_to_match_target(self, client):
        """Verify the QBL sent to update has the target's name, not the source's."""
        update_response = {"status": "updated"}
        calls = []

        original_make_request = client._rm.make_request

        def capture_calls(method, endpoint, **kwargs):
            calls.append((method, endpoint, kwargs))
            if len(calls) == 1:
                return (SAMPLE_QBL, 200)
            elif len(calls) == 2:
                return (SAMPLE_TARGET_QBL, 200)
            else:
                return (update_response, 200)

        with patch.object(client._rm, "make_request", side_effect=capture_calls):
            client.push_solution("sol-source", "sol-target")

        # The third call is the update — check the body
        _, _, kwargs = calls[2]
        body = kwargs["body"]
        assert "Target App" in body
        assert "My Test App" not in body
