"""Tests for QBL parsing, modification, and serialization."""

import pytest

from quickbase_api.qbl import (
    QBLDiagnostics,
    collect_bad_refs,
    extract_app_properties,
    modify_qbl,
    parse_qbl,
    serialize_qbl,
)

# ── Sample QBL for testing ────────────────────────────────────────────

SAMPLE_QBL = """\
Version: '0.12'
ParameterDefinitions:
  $Param_App_Name:
    Value: My Test App
  $Param_App_AppColor:
    Value: '#1a73e8'
  $Param_App_AppIcon:
    Value: Briefcase
Resources:
  $App_My_Test_App:
    Type: QB::Application
    Properties:
      Name: !Var
        Name: $Param_App_Name
      AppColor: !Var
        Name: $Param_App_AppColor
      AppIcon: !Var
        Name: $Param_App_AppIcon
      Manager: owner@example.com
    Tables:
      $Table_Tasks:
        Type: QB::Table
        Properties:
          Name: Tasks
        Fields:
          $Field_Name:
            Type: QB::Field
            Properties:
              Label: Name
              FieldType: text
          $Field_Status:
            Type: QB::Field
            Properties:
              Label: Status
              FieldType: text
              FormulaRef: !Ref $Field_Name
          $Field_Owner:
            Type: QB::Field
            Properties:
              Label: Owner
              FieldType: text
              LookupRef: !BadRef $Field_Deleted_User
        Relationships:
          $Relationship_to_Projects_1:
            Type: QB::Relationship
            Properties:
              ParentTable: !Ref $Table_Projects
      $Table_Projects:
        Type: QB::Table
        Properties:
          Name: Projects
        Fields:
          $Field_Project_Name:
            Type: QB::Field
            Properties:
              Label: Project Name
              FieldType: text
"""

SAMPLE_QBL_NO_MANAGER = """\
Version: '0.12'
ParameterDefinitions:
  $Param_App_Name:
    Value: My Test App
  $Param_App_AppColor:
    Value: '#1a73e8'
  $Param_App_AppIcon:
    Value: Briefcase
Resources:
  $App_My_Test_App:
    Type: QB::Application
    Properties:
      Name: !Var
        Name: $Param_App_Name
      AppColor: !Var
        Name: $Param_App_AppColor
      AppIcon: !Var
        Name: $Param_App_AppIcon
    Tables:
      $Table_Tasks:
        Type: QB::Table
        Properties:
          Name: Tasks
"""


# ── parse_qbl / serialize_qbl ────────────────────────────────────────


class TestParseAndSerialize:
    """Tests for QBL round-tripping."""

    def test_parse_returns_dict_like(self):
        data = parse_qbl(SAMPLE_QBL)
        assert "Version" in data
        assert "Resources" in data
        assert "ParameterDefinitions" in data

    def test_round_trip_preserves_structure(self):
        data = parse_qbl(SAMPLE_QBL)
        result = serialize_qbl(data)
        reparsed = parse_qbl(result)
        assert reparsed["Version"] == "0.12"
        assert "ParameterDefinitions" in reparsed
        assert "Resources" in reparsed

    def test_round_trip_preserves_ref_tags(self):
        data = parse_qbl(SAMPLE_QBL)
        result = serialize_qbl(data)
        assert "!Ref" in result

    def test_round_trip_preserves_bad_ref_tags(self):
        data = parse_qbl(SAMPLE_QBL)
        result = serialize_qbl(data)
        assert "!BadRef" in result

    def test_parse_nested_tables(self):
        data = parse_qbl(SAMPLE_QBL)
        app_key = list(data["Resources"].keys())[0]
        tables = data["Resources"][app_key]["Tables"]
        assert "$Table_Tasks" in tables
        assert "$Table_Projects" in tables


# ── extract_app_properties ───────────────────────────────────────────


class TestExtractAppProperties:
    """Tests for reading app identity from QBL."""

    def test_extracts_name(self):
        props = extract_app_properties(SAMPLE_QBL)
        assert props["name"] == "My Test App"

    def test_extracts_color(self):
        props = extract_app_properties(SAMPLE_QBL)
        assert props["app_color"] == "#1a73e8"

    def test_extracts_icon(self):
        props = extract_app_properties(SAMPLE_QBL)
        assert props["app_icon"] == "Briefcase"

    def test_missing_name_returns_no_key(self):
        qbl = """\
Version: '0.12'
ParameterDefinitions:
  $Param_Other:
    Value: something
Resources:
  $App_Test:
    Type: QB::Application
    Properties:
      AppColor: '#000000'
"""
        props = extract_app_properties(qbl)
        assert "name" not in props


# ── collect_bad_refs ─────────────────────────────────────────────────


class TestCollectBadRefs:
    """Tests for !BadRef collection."""

    def test_finds_bad_refs(self):
        data = parse_qbl(SAMPLE_QBL)
        bad_refs = collect_bad_refs(data)
        assert len(bad_refs) > 0

    def test_bad_ref_includes_path(self):
        data = parse_qbl(SAMPLE_QBL)
        bad_refs = collect_bad_refs(data)
        paths = [path for path, _ in bad_refs]
        assert any("LookupRef" in p for p in paths)

    def test_bad_ref_includes_value(self):
        data = parse_qbl(SAMPLE_QBL)
        bad_refs = collect_bad_refs(data)
        values = [value for _, value in bad_refs]
        assert any("Deleted_User" in v for v in values)

    def test_no_bad_refs_in_clean_qbl(self):
        qbl = """\
Version: '0.12'
ParameterDefinitions:
  $Param_App_Name:
    Value: Clean App
Resources:
  $App_Clean_App:
    Type: QB::Application
    Properties:
      AppColor: '#000000'
"""
        data = parse_qbl(qbl)
        bad_refs = collect_bad_refs(data)
        assert len(bad_refs) == 0

    def test_does_not_flag_good_refs(self):
        data = parse_qbl(SAMPLE_QBL)
        bad_refs = collect_bad_refs(data)
        values = [value for _, value in bad_refs]
        assert not any("Table_Projects" in v for v in values)


# ── modify_qbl ───────────────────────────────────────────────────────


class TestModifyQBL:
    """Tests for QBL modification."""

    def test_changes_app_name(self):
        modified, _ = modify_qbl(SAMPLE_QBL, name="New Name")
        data = parse_qbl(modified)
        # ParameterDefinitions is stripped by modify_qbl, so check
        # the resolved Name property directly
        app_key = list(data["Resources"].keys())[0]
        props = data["Resources"][app_key]["Properties"]
        assert props["Name"] == "New Name"

    def test_updates_resource_logical_id(self):
        modified, _ = modify_qbl(SAMPLE_QBL, name="New Name")
        data = parse_qbl(modified)
        resources = data["Resources"]
        assert "$App_New_Name" in resources
        assert "$App_My_Test_App" not in resources

    def test_changes_color(self):
        modified, _ = modify_qbl(SAMPLE_QBL, app_color="#ff0000")
        data = parse_qbl(modified)
        app_key = list(data["Resources"].keys())[0]
        props = data["Resources"][app_key]["Properties"]
        assert props["AppColor"] == "#ff0000"

    def test_changes_icon(self):
        modified, _ = modify_qbl(SAMPLE_QBL, app_icon="Calendar")
        data = parse_qbl(modified)
        app_key = list(data["Resources"].keys())[0]
        props = data["Resources"][app_key]["Properties"]
        assert props["AppIcon"] == "Calendar"

    def test_invalid_icon_falls_back_to_default(self):
        modified, diagnostics = modify_qbl(SAMPLE_QBL, app_icon="InvalidIcon")
        data = parse_qbl(modified)
        app_key = list(data["Resources"].keys())[0]
        props = data["Resources"][app_key]["Properties"]
        assert props["AppIcon"] == "Application"
        assert any("InvalidIcon" in w for w in diagnostics.warnings)

    def test_strips_manager(self):
        modified, diagnostics = modify_qbl(SAMPLE_QBL, name="New Name")
        assert "Manager" not in modified or "manager_removed" in diagnostics.summary()
        data = parse_qbl(modified)
        app_key = list(data["Resources"].keys())[0]
        props = data["Resources"][app_key]["Properties"]
        assert "Manager" not in props

    def test_reports_stripped_manager(self):
        _, diagnostics = modify_qbl(SAMPLE_QBL, name="New Name")
        assert diagnostics.manager_removed == "owner@example.com"

    def test_no_manager_to_strip(self):
        _, diagnostics = modify_qbl(SAMPLE_QBL_NO_MANAGER, name="New Name")
        assert diagnostics.manager_removed is None

    def test_preserves_ref_tags(self):
        modified, _ = modify_qbl(SAMPLE_QBL, name="New Name")
        assert "!Ref" in modified

    def test_preserves_bad_ref_tags(self):
        modified, _ = modify_qbl(SAMPLE_QBL, name="New Name")
        assert "!BadRef" in modified

    def test_collects_bad_refs(self):
        _, diagnostics = modify_qbl(SAMPLE_QBL, name="New Name")
        assert diagnostics.has_bad_refs
        assert len(diagnostics.bad_refs) > 0

    def test_no_modifications_returns_valid_qbl(self):
        modified, _ = modify_qbl(SAMPLE_QBL)
        data = parse_qbl(modified)
        assert "Resources" in data


# ── QBLDiagnostics ───────────────────────────────────────────────────


class TestQBLDiagnostics:
    """Tests for the diagnostics dataclass."""

    def test_empty_diagnostics(self):
        diag = QBLDiagnostics()
        assert not diag.has_bad_refs
        assert diag.manager_removed is None
        assert diag.summary() == "No issues found."

    def test_has_bad_refs(self):
        diag = QBLDiagnostics(bad_refs=[("path.to.field", "$Field_Deleted")])
        assert diag.has_bad_refs

    def test_summary_includes_manager(self):
        diag = QBLDiagnostics(manager_removed="owner@example.com")
        assert "owner@example.com" in diag.summary()

    def test_summary_includes_bad_refs(self):
        diag = QBLDiagnostics(bad_refs=[("path.to.field", "$Field_Deleted")])
        summary = diag.summary()
        assert "BadRef" in summary
        assert "path.to.field" in summary

    def test_summary_includes_warnings(self):
        diag = QBLDiagnostics(warnings=["Something went wrong"])
        assert "Something went wrong" in diag.summary()
