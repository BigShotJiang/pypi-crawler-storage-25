# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [0.3.0] - 2026-03-28

### Added

- **`copy_app` method** — Copy an existing Quickbase app with optional name/description
  fallbacks from the original app and configurable properties (`keep_data`,
  `exclude_files`, `users_and_roles`, `assign_user_token`).

- **`summarize_upsert` helper** — Builds a convenience summary dict from the full
  `upsert_records` response with keys: `processed`, `created`, `updated`,
  `unchanged`, `errored`, `errored_details`.

- **`_require_legacy_success` method** — Validates legacy API responses by checking
  both HTTP status codes and XML-level `<errcode>` values. Legacy endpoints can
  return HTTP 200 with an error payload; this now catches those cases.

- **`_legacy_url` helper** — Centralizes legacy endpoint URL construction
  (`https://{realm}/db/{dbid}`).

- **`_build_qdbapi` on `LegacyMethod`** — Converts a Python dict to a `<qdbapi>`
  XML request body using `xmltodict.unparse`. Legacy API calls now send data as
  XML bodies instead of URL query parameters.

- **XML body support on `LegacyMethod`** — `make_request` and `post` accept an
  optional `data` dict that is serialized to XML and sent with the appropriate
  `Content-Type: application/xml` header.

- **Keyword-only argument enforcement** — All optional and easily-confused parameters
  now require keyword syntax (`*` separator) across every method.

- **Domain-based file organization** — API methods split into focused mixin files:
  - `_apps.py` — App methods
  - `_tables.py` — Table methods
  - `_fields.py` — Field methods
  - `_records.py` — Record methods
  - `_reports.py` — Report methods
  - `_users_and_roles.py` — User and role methods
  - `_solutions.py` — Solution methods
  - `client.py` — Thin facade combining all mixins

- **New and updated tests** — Full coverage for `copy_app`, `summarize_upsert`,
  `_require_legacy_success`, `_legacy_url`, `_build_qdbapi`, XML body handling,
  XML-level error detection, keyword-only enforcement, and return type validation.

- **`!Var` resolution and `ParameterDefinitions` stripping in `modify_qbl`**
  Added `_resolve_vars()` helper that recursively resolves all `!Var` tagged
  mappings to their plain values from `ParameterDefinitions`. The
  `ParameterDefinitions` section is then removed from the output, matching
  the format required by the Solutions API push payload.

### Changed

- **Standardized return types** — All API wrapper methods now return the full
  response `dict`. Helper/orchestration methods may return other types as
  appropriate.

- **Explicit parameters for `create_table`** — Replaced raw `properties` dict with
  keyword arguments: `name`, `description`, `single_record_name`,
  `plural_record_name`, `icon_name`, `color`.

- **Explicit parameters for `create_field`** — Replaced raw `properties` dict with
  keyword arguments: `label`, `field_type`, `description`, `no_wrap`, `bold`,
  `required`, `appears_by_default`, `find_enabled`, `unique`, `field_help`,
  `add_to_forms`, `type_properties`, `permissions`.

- **`create_fields` uses `**` unpacking** — List items now use Pythonic keys
  (e.g., `field_type` instead of `fieldType`) and are unpacked into `create_field`.

- **`delete_app` parameter order** — Changed from `(app_name, app_id)` to
  `(app_id, *, app_name)` for consistency with all other methods that take
  `app_id` as the primary positional argument.

- **Standardized error handling** — All REST methods use `_require_success`. All
  legacy methods use `_require_legacy_success`. Removed ad-hoc `if resp_code`
  checks.

- **Legacy API calls use XML bodies** — `set_key_field`, `get_user`, and
  `add_user_to_role` now send data as XML request bodies instead of URL
  query parameters. The API action (`a=API_...`) remains as a URL parameter.

- **`__init__.py`** — Import path changed from `quickbase_api.api` to
  `quickbase_api.client`.

- **`KNOWN_ICONS` and `DEFAULT_ICON` moved to `constants.py`**
  Icon set and default icon value relocated from `qbl.py` to a dedicated
  `constants.py` module. `ADMIN_ROLE_ID = 12` also added to constants.

- **`KNOWN_ICONS` expanded**
  Updated from 18 entries to the full set of ~280 known valid Quickbase
  app icon names.

### Breaking Changes

| Change | Migration |
|---|---|
| `create_app` returns `dict` | `client.create_app(...)` → `client.create_app(...)["id"]` |
| `create_table` returns `dict` | `client.create_table(...)` → `client.create_table(...)["id"]` |
| `delete_records` returns `dict` | `client.delete_records(...)` → `client.delete_records(...)["numberDeleted"]` |
| `set_key_field` returns `dict` | Was `True`, now response dict (still truthy) |
| `set_required_field` returns `dict` | Was `True`, now response dict (still truthy) |
| `add_user_to_role` returns `dict` | Was `True`, now response dict (still truthy) |
| `upsert_records` returns full response | Use `client.summarize_upsert(result)` for old format |
| `delete_app(app_name, app_id)` | Now `delete_app(app_id, *, app_name=)` |
| `create_table(app_id, properties={})` | Now `create_table(app_id, *, name=, ...)` |
| `create_field(table_id, properties={})` | Now `create_field(table_id, *, label=, field_type=, ...)` |
| `create_fields` list items | Use `field_type` not `fieldType` |
| All optional params are keyword-only | Cannot pass positionally |
| `from quickbase_api.api import ...` | Use `from quickbase_api import ...` or `from quickbase_api.client import ...` |

### Fixed

- **Fixed `TypeError: unhashable type: 'CommentedMap'` in `modify_qbl`**
  Added `isinstance(app_icon, str)` check before validating against `KNOWN_ICONS`.
  Structured YAML values (e.g., `!Var` mappings) are now passed through as-is.

## [0.2.0] - 2026-03-25

### Added
- Solutions API support
  - `get_solution` — get solution metadata and resource information
  - `export_solution` — export QBL schema definition
  - `create_solution` — create an app from QBL
  - `update_solution` — apply QBL to an existing solution
  - `list_solution_changes` — preview changes without applying
  - `clone_solution` — clone an app with name/color/icon customization
  - `push_solution` — push schema changes between solutions with preview option
- QBL utilities module (`quickbase_api.qbl`)
  - `parse_qbl` / `serialize_qbl` — round-trip QBL YAML preserving `!Ref` and `!BadRef` tags
  - `modify_qbl` — modify app name, color, icon and strip Manager field
  - `extract_app_properties` — read app identity from QBL
  - `collect_bad_refs` — collect all `!BadRef` entries with paths for diagnostics
  - `QBLDiagnostics` — structured diagnostics for QBL modification

### Dependencies
- Added `ruamel.yaml` >= 0.19.1

## [0.1.0] - 2025-03-06

### Added
- Initial release
- App management (create, get, delete)
- Table management (create, get, list, delete)
- Field management (create, get, list, key field, required field)
- Record operations (upsert, query, delete)
- Report operations (list, get, run)
- Automatic retry with exponential backoff
- Environment variable authentication support
