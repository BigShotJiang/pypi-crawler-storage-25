"""User and role-related API methods."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from quickbase_api.client import QuickbaseClient

logger = logging.getLogger(__name__)


class UsersAndRolesMixin:
    """User and role-related methods for the Quickbase client."""

    # ── API Methods ───────────────────────────────────────────────────

    def get_user(
        self: QuickbaseClient,
        email: str,
    ) -> dict | None:
        """Look up a single user by email address using the legacy API.

        Args:
            email: The email address to search for.

        Returns:
            A dict containing the user's id, firstName, lastName,
            and email, or None if the user is not found.

        Raises:
            QuickbaseAPIError: If the API request fails.
        """
        resp_data, resp_code = self._lm.post(
            self._legacy_url("main"),
            params={"a": "API_GetUserInfo"},
            data={"email": email.lower()},
        )
        self._require_legacy_success(resp_data, resp_code, f"get user '{email}'")

        user_element = resp_data.get("user")
        if not user_element:
            logger.warning("No user found for email %s", email)
            return None

        user = {
            "id": user_element.get("@id"),
            "firstName": user_element.get("firstName"),
            "lastName": user_element.get("lastName"),
            "login": user_element.get("login"),
            "email": user_element.get("email"),
        }

        logger.info("Found user %s for email %s", user["id"], email)
        return user

    def add_user_to_role(
        self: QuickbaseClient,
        dbid: str,
        *,
        user_id: str,
        role_id: int,
    ) -> dict:
        """Add a user to a role using the legacy API.

        Args:
            dbid: The app or table ID.
            user_id: The user's Quickbase hash ID (e.g., '58351651.xc1').
            role_id: The role ID to assign (e.g., 12 for Administrator).

        Returns:
            True if the user was added to the role successfully.

        Raises:
            QuickbaseAPIError: If the API request fails.
        """
        resp_json, resp_code = self._lm.post(
            self._legacy_url(dbid),
            params={"a": "API_AddUserToRole"},
            data={"userid": user_id, "roleid": role_id},
        )
        self._require_legacy_success(resp_json, resp_code, f"add user '{user_id}' to role '{role_id}' in '{dbid}'")

        logger.info("Added user %s to role %d in %s", user_id, role_id, dbid)
        return resp_json
