"""Client for Quickbase's legacy XML/URL-based API endpoints."""

from __future__ import annotations

import logging

import xmltodict

from quickbase_api.session import create_session

logger = logging.getLogger(__name__)


class LegacyMethod:
    """Low-level HTTP client for legacy Quickbase API endpoints.

    Used for older API actions (e.g., API_SetKeyField) that are not
    available through the modern REST API.
    """

    def __init__(self, realm: str, user_token: str):
        self.realm = realm
        self.session = create_session(realm, user_token)

    @staticmethod
    def _build_qdbapi(params: dict) -> str:
        """Convert a dictionary to a <qdbapi> XML request body.

        Args:
            params: A dictionary of parameter names to values.

        Returns:
            The XML string.
        """
        return xmltodict.unparse({"qdbapi": params}, full_document=True)

    def make_request(
        self,
        method: str,
        url: str,
        params: dict = None,
        data: dict = None,
    ) -> tuple[dict, int]:
        """Execute an HTTP request against a legacy Quickbase endpoint.

        Legacy endpoints return XML. The response is parsed into a dict
        with the outer <qdbapi> wrapper unwrapped for convenience.

        Args:
            method: HTTP method (GET, POST, DELETE).
            url: Full URL for the legacy endpoint.
            params: Optional query string parameters.
            data: Optional dictionary to send as a <qdbapi> XML body.

        Returns:
            A tuple of (response_body_dict, status_code). The dict
            contains the contents of the <qdbapi> element.
        """
        body = None
        headers = {}
        if data is not None:
            body = self._build_qdbapi(data)
            headers["Content-Type"] = "application/xml"

        response = self.session.request(
            method=method,
            url=url,
            params=params,
            data=body,
            headers=headers,
        )

        parsed = self._parse_response(response)

        if response.status_code >= 400:
            logger.error(
                "Legacy API error %d on %s %s: %s",
                response.status_code,
                method,
                url,
                parsed,
            )

        return parsed, response.status_code

    @staticmethod
    def _parse_response(response) -> dict:
        """Parse a legacy API response, handling XML, JSON, and raw text.

        Quickbase legacy endpoints return XML wrapped in a <qdbapi> root
        element. This method parses the XML and unwraps that outer element
        so callers get a flat dict of the response fields.

        Args:
            response: The requests Response object.

        Returns:
            A dict of the parsed response body.
        """
        content_type = response.headers.get("Content-Type", "")
        text = response.text

        # Most legacy endpoints return XML
        if "xml" in content_type or text.strip().startswith("<?xml") or text.strip().startswith("<"):
            try:
                parsed = xmltodict.parse(text)
                # Unwrap the <qdbapi> root element that wraps all legacy responses
                return parsed.get("qdbapi", parsed)
            except Exception:
                logger.warning("Failed to parse XML response, falling back to raw text")
                return {"raw_response": text}

        # Some endpoints might return JSON
        try:
            return response.json()
        except (ValueError, Exception):
            return {"raw_response": text}

    def get(self, url: str, params: dict = None) -> tuple[dict, int]:
        """Send a GET request."""
        return self.make_request("GET", url, params=params)

    def post(
        self,
        url: str,
        params: dict = None,
        data: dict = None,
    ) -> tuple[dict, int]:
        """Send a POST request with an optional XML body."""
        return self.make_request("POST", url, params=params, data=data)

    def delete(self, url: str, params: dict = None) -> tuple[dict, int]:
        """Send a DELETE request."""
        return self.make_request("DELETE", url, params=params)