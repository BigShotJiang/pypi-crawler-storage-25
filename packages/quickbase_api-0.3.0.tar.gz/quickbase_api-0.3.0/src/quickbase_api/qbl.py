"""QBL parsing, modification, and serialization utilities for the Quickbase Solutions API."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from io import StringIO

from ruamel.yaml import YAML  # type: ignore[import-unresolved]

from quickbase_api.constants import DEFAULT_APP_ICON, KNOWN_APP_ICONS

logger = logging.getLogger(__name__)


@dataclass
class QBLDiagnostics:
    """Collects issues found during QBL parsing and modification.

    Attributes:
        bad_refs: List of (path, value) tuples for every !BadRef found.
        warnings: General warnings encountered during modification.
        manager_removed: The manager value that was stripped, if any.
    """

    bad_refs: list[tuple[str, str]] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    manager_removed: str | None = None

    @property
    def has_bad_refs(self) -> bool:
        return len(self.bad_refs) > 0

    def summary(self) -> str:
        """Return a human-readable summary of diagnostics."""
        lines = []
        if self.manager_removed:
            lines.append(f"Stripped Manager: {self.manager_removed}")
        if self.bad_refs:
            lines.append(f"Found {len(self.bad_refs)} !BadRef entries:")
            for path, value in self.bad_refs:
                lines.append(f"  {path}: {value}")
        if self.warnings:
            lines.append(f"Warnings ({len(self.warnings)}):")
            for w in self.warnings:
                lines.append(f"  {w}")
        return "\n".join(lines) if lines else "No issues found."


def _create_yaml_handler() -> YAML:
    """Create a ruamel.yaml handler configured for QBL round-tripping."""
    handler = YAML()
    handler.preserve_quotes = True
    # Allow arbitrary custom tags (!Ref, !BadRef, etc.) to pass through
    # without raising errors. ruamel.yaml round-trip mode does this by default.
    return handler


def parse_qbl(qbl: str) -> dict:
    """Parse a QBL YAML string into a round-trip-safe data structure.

    The returned object preserves tags, comments, and key ordering
    so it can be modified and re-serialized without losing !Ref entries.

    Args:
        qbl: The raw QBL YAML string.

    Returns:
        A ruamel.yaml CommentedMap (dict-like) preserving all tags.
    """
    handler = _create_yaml_handler()
    return handler.load(qbl)


def serialize_qbl(data) -> str:
    """Serialize a parsed QBL structure back to a YAML string.

    Preserves custom tags (!Ref, !BadRef) and key ordering.

    Args:
        data: The parsed QBL data (from parse_qbl).

    Returns:
        The QBL YAML string, ready to send to the Solutions API.
    """
    handler = _create_yaml_handler()
    stream = StringIO()
    handler.dump(data, stream)
    return stream.getvalue()


def collect_bad_refs(data, path: str = "") -> list[tuple[str, str]]:
    """Walk a parsed QBL structure and collect all !BadRef entries.

    Args:
        data: The parsed QBL data (or a subtree).
        path: The current dot-delimited path (used for recursion).

    Returns:
        A list of (path, value) tuples for each !BadRef found.
    """
    results = []

    # ruamel.yaml tagged scalars have a .tag attribute
    if hasattr(data, "tag") and data.tag is not None:
        tag_str = str(data.tag)
        if "BadRef" in tag_str:
            results.append((path or "(root)", str(data)))

    if isinstance(data, dict):
        for key, value in data.items():
            child_path = f"{path}.{key}" if path else str(key)
            results.extend(collect_bad_refs(value, child_path))
    elif isinstance(data, list):
        for i, item in enumerate(data):
            child_path = f"{path}[{i}]"
            results.extend(collect_bad_refs(item, child_path))

    return results


def _resolve_vars(data, param_lookup: dict):
    """Recursively resolve all !Var tagged mappings to their plain values.

    A !Var node looks like:
        !Var
          Name: App_Name_1

    This replaces it with the corresponding Value from ParameterDefinitions.

    Args:
        data: The parsed QBL data (or subtree).
        param_lookup: dict mapping parameter key → plain value string.

    Returns:
        The resolved data (may be the same object or a replacement scalar).
    """
    # Check if this node is a !Var reference
    if isinstance(data, dict) and hasattr(data, "tag") and data.tag is not None:
        tag_str = str(data.tag)
        if tag_str == "!Var":
            ref_name = data.get("Name")
            if ref_name and str(ref_name) in param_lookup:
                return param_lookup[str(ref_name)]
            # If we can't resolve it, leave it as-is
            return data

    # Recurse into dicts
    if isinstance(data, dict):
        for key in list(data.keys()):
            data[key] = _resolve_vars(data[key], param_lookup)

    # Recurse into lists
    elif isinstance(data, list):
        for i in range(len(data)):
            data[i] = _resolve_vars(data[i], param_lookup)

    return data


def modify_qbl(
    qbl: str,
    name: str = None,
    *,
    app_color: str = None,
    app_icon: str = None,
    header_background_color: str = None,
    header_text_color: str = None,
) -> tuple[str, QBLDiagnostics]:
    """Modify properties in a QBL definition for cloning/pushing.

    Handles:
    - Resolving all !Var references to their plain values
    - Stripping ParameterDefinitions (not needed in the push payload)
    - Renaming the app (Resource logical ID + Name property)
    - Changing the app color, icon, and header branding colors
    - Stripping the Manager field (the API assigns the caller)
    - Collecting all !BadRef entries for diagnostic review

    Args:
        qbl: The original QBL YAML string.
        name: New app name (e.g., 'MyApp-Dev').
        app_color: New app color hex (e.g., '#72509a').
        app_icon: New app icon name (e.g., 'Accreditations').
        header_background_color: Hex color for the app header background.
        header_text_color: Color for the app header text (e.g., 'white').

    Returns:
        A tuple of (modified_qbl_string, diagnostics).
    """
    diagnostics = QBLDiagnostics()
    data = parse_qbl(qbl)

    # ── Collect !BadRef entries ───────────────────────────────────────
    diagnostics.bad_refs = collect_bad_refs(data)
    if diagnostics.bad_refs:
        logger.warning(
            "QBL contains %d !BadRef entries. See diagnostics for details.",
            len(diagnostics.bad_refs),
        )

    # ── Build parameter lookup and resolve !Var references ────────────
    param_lookup = {}
    param_defs = data.get("ParameterDefinitions", {})
    for param_key, param_def in param_defs.items():
        param_lookup[str(param_key)] = param_def["Value"]

    data = _resolve_vars(data, param_lookup)

    # ── Strip ParameterDefinitions ────────────────────────────────────
    if "ParameterDefinitions" in data:
        del data["ParameterDefinitions"]

    # ── Validate and default the icon ─────────────────────────────────
    if app_icon is not None and isinstance(app_icon, str) and app_icon not in KNOWN_APP_ICONS:
        diagnostics.warnings.append(f"Icon '{app_icon}' not in known set; falling back to '{DEFAULT_APP_ICON}'")
        app_icon = DEFAULT_APP_ICON

    # ── Find the original app name for logical ID renaming ────────────
    original_name = None
    resources = data.get("Resources", {})

    for key, resource in resources.items():
        if not isinstance(resource, dict):
            continue
        if resource.get("Type") != "QB::Application":
            continue

        props = resource.get("Properties", {})
        original_name = props.get("Name")

        # ── Apply property overrides ──────────────────────────────
        if name is not None:
            props["Name"] = name
        if app_color is not None:
            props["AppColor"] = app_color
        if app_icon is not None:
            props["AppIcon"] = app_icon

        # ── Update branding header colors ─────────────────────────
        if header_background_color is not None or header_text_color is not None:
            branding = props.get("Branding")
            if branding is None:
                props["Branding"] = {}
                branding = props["Branding"]

            app_header = branding.get("AppHeader")
            if app_header is None:
                branding["AppHeader"] = {}
                app_header = branding["AppHeader"]

            if header_background_color is not None:
                app_header["BackgroundColor"] = header_background_color
            if header_text_color is not None:
                app_header["TextColor"] = header_text_color

        # ── Strip the Manager ─────────────────────────────────────
        if "Manager" in props:
            diagnostics.manager_removed = props.pop("Manager")
            logger.info("Stripped Manager '%s' from QBL", diagnostics.manager_removed)

        break  # Only one application resource

    # ── Rename the logical ID under Resources ─────────────────────────
    if name is not None and original_name is not None:
        old_logical_id = f"$App_{str(original_name).replace(' ', '_')}"
        new_logical_id = f"$App_{name.replace(' ', '_')}"
        if old_logical_id in resources:
            resources.insert(
                list(resources.keys()).index(old_logical_id),
                new_logical_id,
                resources.pop(old_logical_id),
            )
        else:
            diagnostics.warnings.append(f"Could not find resource '{old_logical_id}' to rename.")
    elif name is not None:
        diagnostics.warnings.append("Could not determine original app name; logical ID not renamed.")

    modified_qbl = serialize_qbl(data)
    return modified_qbl, diagnostics


def extract_app_properties(qbl: str) -> dict:
    """Extract app properties from the ParameterDefinitions in a QBL definition.

    These correspond to the !Var references used in the Application resource:
      - App_Name           → name
      - App_AppIcon        → app_icon
      - App_AppColor       → app_color
      - App_Branding_AppHeader_BackgroundColor → header_background_color
      - App_Branding_AppHeader_TextColor       → header_text_color

    Args:
        qbl: The QBL YAML string.

    Returns:
        A dict with keys: name, app_icon, app_color,
        header_background_color, header_text_color.
    """
    data = parse_qbl(qbl)

    # Map parameter key substrings to output property names
    param_map = {
        "App_Name": "name",
        "App_AppIcon": "app_icon",
        "App_AppColor": "app_color",
        "App_Branding_AppHeader_BackgroundColor": "header_background_color",
        "App_Branding_AppHeader_TextColor": "header_text_color",
    }

    props = {}

    param_defs = data.get("ParameterDefinitions", {})
    for param_key, param_def in param_defs.items():
        key_str = str(param_key)
        for substring, prop_name in param_map.items():
            if substring in key_str:
                props[prop_name] = param_def["Value"]
                break

    return props
