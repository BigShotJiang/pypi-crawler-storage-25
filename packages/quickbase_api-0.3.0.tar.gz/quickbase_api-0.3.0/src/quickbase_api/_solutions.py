"""Solution-related API methods."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from quickbase_api.qbl import QBLDiagnostics, extract_app_properties, modify_qbl

if TYPE_CHECKING:
    from quickbase_api.client import QuickbaseClient

logger = logging.getLogger(__name__)


class SolutionsMixin:
    """Solution-related methods for the Quickbase client."""

    # ── API Methods ───────────────────────────────────────────────────

    def export_solution(
        self: QuickbaseClient,
        solution_id: str,
    ) -> str:
        result, resp_code = self._rm.make_request("GET", f"solutions/{solution_id}")
        self._require_success(result, resp_code, f"export solution '{solution_id}'")
        logger.info("Exported solution '%s'", solution_id)
        return result

    def create_solution(
        self: QuickbaseClient,
        qbl: str,
    ) -> dict:
        result, resp_code = self._rm.make_request("POST", "solutions", body=qbl)
        self._require_success(result, resp_code, "create solution")
        logger.info("Created solution from QBL")
        return result

    def update_solution(
        self: QuickbaseClient,
        solution_id: str,
        *,
        qbl: str,
    ) -> dict:
        result, resp_code = self._rm.make_request("PUT", f"solutions/{solution_id}", body=qbl)
        self._require_success(result, resp_code, f"update solution '{solution_id}'")
        logger.info("Updated solution '%s'", solution_id)
        return result

    def list_solution_changes(
        self: QuickbaseClient,
        solution_id: str,
        *,
        qbl: str,
    ) -> dict:
        result, resp_code = self._rm.make_request("PUT", f"solutions/{solution_id}/changeset", body=qbl)
        self._require_success(result, resp_code, f"list changes for solution '{solution_id}'")
        logger.info("Retrieved changeset for solution '%s'", solution_id)
        return result

    def get_solution(
        self: QuickbaseClient,
        solution_id: str,
    ) -> dict:
        resp_json, resp_code = self._rm.get(f"solutions/{solution_id}/resources")
        self._require_success(resp_json, resp_code, f"get solution '{solution_id}'")
        return resp_json

    # ── Helpers ───────────────────────────────────────────────────────

    def push_solution(
        self: QuickbaseClient,
        source_solution_id: str,
        target_solution_id: str,
        *,
        preview_only: bool = False,
    ) -> dict | tuple[dict, QBLDiagnostics]:
        if source_solution_id == target_solution_id:
            raise ValueError(
                f"Source and target solution IDs are the same: '{source_solution_id}'. "
                "This would be a no-op at best."
            )

        source_qbl = self.export_solution(source_solution_id)
        target_qbl = self.export_solution(target_solution_id)
        target_props = extract_app_properties(target_qbl)

        modified_qbl, diagnostics = modify_qbl(
            source_qbl,
            name=target_props.get("name"),
            app_color=target_props.get("app_color"),
            app_icon=target_props.get("app_icon"),
            header_background_color=target_props.get("header_background_color"),
            header_text_color=target_props.get("header_text_color"),
        )

        if preview_only:
            logger.info(
                "Previewing push from '%s' to '%s'",
                source_solution_id,
                target_solution_id,
            )
            return self.list_solution_changes(target_solution_id, qbl=modified_qbl)

        logger.info(
            "Pushing solution '%s' to '%s'",
            source_solution_id,
            target_solution_id,
        )
        result = self.update_solution(target_solution_id, qbl=modified_qbl)
        logger.info("Push complete: '%s' → '%s'", source_solution_id, target_solution_id)
        return result, diagnostics
