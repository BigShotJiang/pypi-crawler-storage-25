"""RosServiceClientMixin — non-blocking ROS 2 service client for BTEng nodes."""

from __future__ import annotations

from bteng import NodeStatus
from bteng_ros2._mixin import RosNodeMixin


class RosServiceClientMixin(RosNodeMixin):
    """Adds non-blocking ROS 2 service client capability to any BTEng node.

    Typical usage with StatefulActionNode:

        class SetParam(RosServiceClientMixin, StatefulActionNode):
            def on_start(self):
                from rcl_interfaces.srv import SetParameters
                self._init_service_client(SetParameters, "/my_node/set_parameters")
                self.call_service(self._build_request())

            def on_running(self):
                return self.service_status()
    """

    def _init_service_client(self, srv_type, srv_name: str) -> None:
        node = self._require_ros_node()
        self.__srv_client = node.create_client(srv_type, srv_name)
        self.__srv_response = None
        self.__srv_done = False

    def call_service(self, request) -> None:
        self.__srv_done = False
        self.__srv_response = None
        future = self.__srv_client.call_async(request)
        future.add_done_callback(self.__on_response)

    def __on_response(self, future) -> None:
        self.__srv_response = future.result()
        self.__srv_done = True

    def service_status(self) -> NodeStatus:
        """Return current NodeStatus based on service call state. Call in on_running()."""
        if not self.__srv_done:
            return NodeStatus.RUNNING
        if self.__srv_response is None:
            return NodeStatus.FAILURE
        return NodeStatus.SUCCESS

    @property
    def service_response(self):
        """Response from the last completed service call, or None."""
        return self.__srv_response

    def service_is_ready(self) -> bool:
        return self.__srv_client.service_is_ready()
