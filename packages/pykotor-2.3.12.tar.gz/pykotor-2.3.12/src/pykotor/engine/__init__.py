"""Abstract engine interfaces for PyKotor.

This module provides abstract base classes and interfaces that can be implemented
by different rendering backends (OpenGL, Qt5 or Qt6, Panda3D, etc.).

This package contains backend-specific engine implementations.

All backend-specific implementations should inherit from these base classes to ensure
compatibility and code reuse across different rendering systems.

References:
----------
        Observed retail KotOR I and KotOR II behavior.


"""

from __future__ import annotations

__all__ = []
