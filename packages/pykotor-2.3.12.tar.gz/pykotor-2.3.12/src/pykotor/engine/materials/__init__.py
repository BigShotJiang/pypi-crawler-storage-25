"""Abstract material system interfaces.

This package defines backend-agnostic interfaces for material handling that can
be implemented by different rendering engines (OpenGL, Qt5 or Qt6, Panda3D, etc.).

References:
----------
        Observed retail KotOR I and KotOR II behavior.


"""

from __future__ import annotations

from pykotor.engine.materials.base import IMaterial, IMaterialManager

__all__ = [
    "IMaterial",
    "IMaterialManager",
]
