"""diff operations-driven comparison command for PyKotor CLI."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from argparse import Namespace

    from loggerplus import RobustLogger as Logger


def cmd_diff_installation(args: Namespace, logger: Logger) -> int:
    """Run the diff operations tool via the kotordiff package.

    This command delegates to the `kotordiff` package if installed.
    If not available, provides a helpful error message.

    Args:
    ----
        args: Parsed command line arguments
        logger: Logger instance

    Returns:
    -------
        Exit code (0 for success, non-zero for error)
    """
    try:
        # Use pykotor.diff_tool
        from pykotor.diff_tool.__main__ import main as kotordiff_main

        # Reconstruct argv from args namespace
        argv: list[str] = []
        if hasattr(args, "path1") and args.path1:
            argv.extend(["--path1", str(args.path1)])
        if hasattr(args, "path2") and args.path2:
            argv.extend(["--path2", str(args.path2)])
        if hasattr(args, "path3") and args.path3:
            argv.extend(["--path3", str(args.path3)])
        if hasattr(args, "extra_paths") and args.extra_paths:
            for path in args.extra_paths:
                argv.extend(["--path", str(path)])
        if hasattr(args, "tslpatchdata") and args.tslpatchdata:
            argv.extend(["--tslpatchdata", str(args.tslpatchdata)])
        if hasattr(args, "ini") and args.ini:
            argv.extend(["--ini", str(args.ini)])
        if hasattr(args, "output_log") and args.output_log:
            argv.extend(["--output-log", str(args.output_log)])
        if hasattr(args, "log_level") and args.log_level:
            argv.extend(["--log-level", str(args.log_level)])
        if hasattr(args, "output_mode") and args.output_mode:
            argv.extend(
                [
                    "--output-mode",
                    args.output_mode.value
                    if hasattr(args.output_mode, "value")
                    else str(args.output_mode),
                ]
            )
        if hasattr(args, "no_color") and args.no_color:
            argv.append("--no-color")
        if hasattr(args, "compare_hashes") and args.compare_hashes is not None:
            if args.compare_hashes:
                argv.append("--compare-hashes")
            else:
                argv.append("--no-compare-hashes")
        if hasattr(args, "filter") and args.filter:
            for f in args.filter:
                argv.extend(["--filter", str(f)])
        if hasattr(args, "logging") and args.logging is not None:
            if args.logging:
                argv.append("--logging")
            else:
                argv.append("--no-logging")
        if hasattr(args, "use_profiler") and args.use_profiler:
            argv.append("--use-profiler")
        if hasattr(args, "use_incremental_writer") and args.use_incremental_writer:
            argv.append("--incremental")
        if hasattr(args, "merge_tslpatcher") and args.merge_tslpatcher:
            argv.append("--merge-tslpatcher")
        if hasattr(args, "merge_source") and args.merge_source:
            argv.extend(["--merge-source", str(args.merge_source)])
        if hasattr(args, "merge_resource") and args.merge_resource:
            argv.extend(["--merge-resource", str(args.merge_resource)])
        if hasattr(args, "merge_resource_type") and args.merge_resource_type:
            argv.extend(["--merge-resource-type", str(args.merge_resource_type)])
        if hasattr(args, "merge_module") and args.merge_module:
            argv.extend(["--merge-module", str(args.merge_module)])
        if hasattr(args, "merge_paths") and args.merge_paths:
            for merge_path in args.merge_paths:
                argv.extend(["--merge-path", str(merge_path)])
        if hasattr(args, "merge_conflict_policy") and args.merge_conflict_policy:
            argv.extend(["--merge-conflict-policy", str(args.merge_conflict_policy)])
        if hasattr(args, "console") and args.console:
            argv.append("--console")
        if hasattr(args, "gui") and args.gui:
            argv.append("--gui")

        return kotordiff_main(argv)
    except ImportError:
        logger.error(
            "diff operations functionality requires the 'kotordiff' package to be installed.\nInstall it with: pip install kotordiff\nOr use the standalone kotordiff tool.",
        )
        return 1
    except Exception:
        logger.exception("diff operations execution failed")
        return 1
