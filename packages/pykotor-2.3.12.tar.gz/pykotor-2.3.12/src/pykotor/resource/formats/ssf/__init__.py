"""SSF package: sound set (strref to wave) and binary/XML I/O."""

from __future__ import annotations
from pykotor.resource.formats.ssf.ssf_data import SSF, SSFSound
from pykotor.resource.formats.ssf.io_ssf import (
    SSFBinaryReader,
    SSFBinaryWriter,
)
from pykotor.resource.formats.ssf.io_ssf_xml import (
    SSFXMLReader,
    SSFXMLWriter,
)
from pykotor.resource.formats.ssf.ssf_auto import (
    bytes_ssf,
    read_ssf,
    write_ssf,
)

__all__ = [
    "SSF",
    "SSFBinaryReader",
    "SSFBinaryWriter",
    "SSFJSONReader",
    "SSFJSONWriter",
    "SSFSound",
    "SSFXMLReader",
    "SSFXMLWriter",
    "bytes_ssf",
    "read_ssf",
    "write_ssf",
]
