# !/usr/bin/python
# coding=utf-8
import sys
import os
from typing import Optional, TYPE_CHECKING
from uitk import Switchboard
from uitk.handlers.ui_handler import UiHandler

try:
    from mayatk.ui_utils import maya_native_menus
except ImportError:
    maya_native_menus = None

if TYPE_CHECKING:
    from qtpy import QtWidgets


class MayaUiHandler(UiHandler):
    """UI Handler for Maya applications.

    Extends the generic UiHandler with Maya-specific menu wrapping
    and discovery of mayatk UI files.
    """

    def __init__(
        self,
        switchboard: Switchboard = None,
        log_level: str = "WARNING",
        **kwargs,
    ) -> None:
        """Initialize Maya UI Handler.

        ``switchboard`` is optional. When omitted, a fresh ``Switchboard``
        is constructed so the handler can be stood up by a shelf script
        without any prior setup. Production callers (e.g. tentacle's
        ``tcl_maya``) still pass an explicit instance to share state
        with the rest of the application.
        """
        self.root_dir = os.path.dirname(sys.modules["mayatk"].__file__)

        if switchboard is None:
            from uitk import Switchboard as _Switchboard

            switchboard = _Switchboard()

        super().__init__(
            switchboard=switchboard,
            ui_root=self.root_dir,
            slot_root=self.root_dir,
            discover_slots=True,
            recursive=True,
            log_level=log_level,
            source_tags={"mayatk"},
            **kwargs,
        )

    @classmethod
    def instance(cls, switchboard: Switchboard = None, **kwargs) -> "MayaUiHandler":
        """Return the MayaUiHandler singleton, bootstrapping if needed.

        Overrides :meth:`UiHandler.instance` so a shelf-style call works
        regardless of prior setup state:

        - **Pre-existing handler** (e.g. tentacle's ``tcl_maya`` already
          ran ``MayaUiHandler.instance(switchboard=tentacle_sb)``): the
          existing instance is returned, even when this call is made
          without a switchboard argument. The base implementation keys
          singletons by ``id(switchboard)``, which would otherwise treat
          ``id(None)`` as a separate slot and try to build a fresh,
          broken handler.
        - **No handler yet, switchboard given**: standard UiHandler path,
          singleton keyed by ``id(switchboard)``.
        - **No handler yet, no switchboard**: ``MayaUiHandler.__init__``
          bootstraps a fresh ``Switchboard`` (see __init__).

        This makes the one-liner pattern reliable from a Maya shelf::

            from mayatk.ui_utils.maya_ui_handler import MayaUiHandler
            MayaUiHandler.instance().editors.show("browser")
        """
        if switchboard is None:
            # SingletonMixin._instances is shared across all subclasses;
            # filter to our class so we don't return a sibling handler.
            for inst in cls._instances.values():
                if isinstance(inst, cls):
                    return inst
        return super().instance(switchboard=switchboard, **kwargs)

    def get(self, name: str, reload: bool = False, **kwargs) -> "QtWidgets.QMainWindow":
        """Retrieve a UI, checking Maya menus first."""
        # Check if name corresponds to a Maya menu
        if maya_native_menus and name in maya_native_menus.MayaNativeMenus.MENU_MAPPING:
            return self._load_maya_ui(menu_key=name, **kwargs)

        return super().get(name, reload=reload, **kwargs)

    def apply_styles(self, ui, style=None):
        """Override to give mayatk-sourced UIs a hide button instead of pin."""
        import copy

        style = copy.deepcopy(style or self.DEFAULT_STYLE)
        try:
            if ui.has_tags(["mayatk"]):
                style["header_buttons"] = ("menu", "collapse", "hide")
        except AttributeError:
            pass
        # Pass pre-built style so the base skips its own deepcopy.
        super().apply_styles(ui, style=style)

    def _load_maya_ui(
        self,
        menu_key: str,
        header: bool = True,
        overwrite: bool = False,
    ) -> Optional["QtWidgets.QMainWindow"]:
        """Load and wrap a Maya menu by key."""
        if not maya_native_menus:
            return None

        if not hasattr(self, "_maya_native_menus"):
            self._maya_native_menus = maya_native_menus.MayaNativeMenus()
        handler = self._maya_native_menus

        if not overwrite:
            cached = self.sb.loaded_ui.peek(menu_key)
            if cached is not None:
                self.logger.debug(f"[{menu_key}] Returning cached Maya UI")
                return cached

        menu_widget = handler.get_menu(menu_key)
        if not menu_widget:
            self.sb.logger.warning(f"Could not retrieve Maya menu for '{menu_key}'")
            return None

        # Retrieve Maya Main Window for correct parenting (ensures Z-order on top)
        try:
            from mayatk.ui_utils._ui_utils import UiUtils

            maya_window = UiUtils.get_main_window()
        except ImportError:
            maya_window = None

        self.logger.debug(f"[{menu_key}] Creating MainWindow wrapper for Maya menu")
        ui = self.sb.add_ui(
            widget=menu_widget,
            name=menu_key,
            tags={"maya", "menu"},
            overwrite=overwrite,
            add_footer=False,
            restore_window_size=False,
            parent=maya_window,
        )

        # Add Window flag without clobbering anything MainWindow already set.
        # When a QMainWindow has a parent, Qt treats it as an embedded child;
        # the Window flag keeps it a floating tool window.
        ui.set_flags(Window=True)

        if header:
            ui.header = self.sb.registered_widgets.Header()
            ui.header.setTitle(ui.objectName().upper())
            ui.header.attach_to(ui.centralWidget())
            ui.style.set(ui.header, "dark", "Header")
            self.logger.debug(
                f"[{menu_key}] Header attached: hasattr(ui, 'header')={hasattr(ui, 'header')}, "
                f"header.window() is ui: {ui.header.window() is ui}"
            )

        ui.edit_tags(add="maya_menu")
        self.logger.debug(f"[{menu_key}] Maya UI created with tags={ui.tags}")

        # Apply styles (including header buttons) through the normal pipeline.
        # Maya native menus don't have the 'mayatk' tag, so they get the
        # default pin button from DEFAULT_STYLE.
        self.apply_styles(ui)

        # Menu is fully populated (synchronous in get_menu); lock the
        # window to exact content size before it is ever shown.
        menu_widget.fit_to_window()

        return ui
