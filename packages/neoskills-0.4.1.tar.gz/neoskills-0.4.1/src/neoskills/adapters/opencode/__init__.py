"""OpenCode adapter."""
