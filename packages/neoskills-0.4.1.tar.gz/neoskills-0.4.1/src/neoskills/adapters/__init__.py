"""Agent ecosystem adapters."""
