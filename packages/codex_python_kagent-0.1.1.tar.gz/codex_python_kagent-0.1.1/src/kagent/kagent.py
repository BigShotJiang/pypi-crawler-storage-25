"""Kagent client object."""

from __future__ import annotations

import os
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path

from kagent.thread import (
    DEFAULT_APPROVAL,
    DEFAULT_MODEL,
    DEFAULT_RUNNER,
    DEFAULT_SANDBOX,
    ApprovalPolicy,
    KagentError,
    Runner,
    SandboxMode,
    Thread,
)


@dataclass(frozen=True, slots=True)
class Kagent:
    """Small client for authenticated Codex-backed threads."""

    workspace: str | Path = "."
    model: str = DEFAULT_MODEL
    runner: Runner = DEFAULT_RUNNER
    ask_for_approval: ApprovalPolicy = DEFAULT_APPROVAL
    sandbox: SandboxMode = DEFAULT_SANDBOX
    skip_git_repo_check: bool = True
    yolo: bool = True
    codex_bin: str | Path | None = None
    store_path: str | Path | None = None

    @classmethod
    def login(
        cls,
        *,
        api_key: str | None = None,
        api_key_env: str | None = None,
        codex_bin: str | Path | None = None,
        workspace: str | Path = ".",
        model: str = DEFAULT_MODEL,
        runner: Runner = DEFAULT_RUNNER,
        ask_for_approval: ApprovalPolicy = DEFAULT_APPROVAL,
        sandbox: SandboxMode = DEFAULT_SANDBOX,
        skip_git_repo_check: bool = True,
        yolo: bool = True,
        store_path: str | Path | None = None,
    ) -> Kagent:
        """Log in through Codex, then return a configured Kagent client."""

        resolved_codex_bin = _codex_bin(codex_bin)
        resolved_api_key = _api_key(api_key, api_key_env)

        if resolved_api_key is None:
            _run([resolved_codex_bin, "login"])
        else:
            _run(
                [resolved_codex_bin, "login", "--with-api-key"],
                input=f"{resolved_api_key}\n",
            )

        return cls(
            workspace=workspace,
            model=model,
            runner=runner,
            ask_for_approval=ask_for_approval,
            sandbox=sandbox,
            skip_git_repo_check=skip_git_repo_check,
            yolo=yolo,
            codex_bin=resolved_codex_bin,
            store_path=store_path,
        )

    @classmethod
    def status(cls, *, codex_bin: str | Path | None = None) -> str:
        """Return Codex login status text."""

        result = _run([_codex_bin(codex_bin), "login", "status"], capture=True)
        return result.stdout

    @classmethod
    def logout(cls, *, codex_bin: str | Path | None = None) -> None:
        """Remove Codex login credentials."""

        _run([_codex_bin(codex_bin), "logout"])

    def thread(
        self,
        id: str,
        *,
        workspace: str | Path | None = None,
        model: str | None = None,
        runner: Runner | None = None,
        ask_for_approval: ApprovalPolicy | None = None,
        sandbox: SandboxMode | None = None,
        skip_git_repo_check: bool | None = None,
        yolo: bool | None = None,
        store_path: str | Path | None = None,
    ) -> Thread:
        """Create a named thread using this client's defaults."""

        return Thread(
            id,
            workspace=self.workspace if workspace is None else workspace,
            model=self.model if model is None else model,
            runner=self.runner if runner is None else runner,
            ask_for_approval=(
                self.ask_for_approval if ask_for_approval is None else ask_for_approval
            ),
            sandbox=self.sandbox if sandbox is None else sandbox,
            skip_git_repo_check=(
                self.skip_git_repo_check if skip_git_repo_check is None else skip_git_repo_check
            ),
            yolo=self.yolo if yolo is None else yolo,
            codex_bin=self.codex_bin,
            store_path=self.store_path if store_path is None else store_path,
        )


def _api_key(api_key: str | None, api_key_env: str | None) -> str | None:
    if api_key is not None:
        if not api_key:
            raise KagentError("API key cannot be empty.")
        return api_key

    if api_key_env is None:
        return None

    env_api_key = os.environ.get(api_key_env)
    if env_api_key is None:
        raise KagentError(f"{api_key_env} is not set.")
    return env_api_key


def _codex_bin(codex_bin: str | Path | None) -> str:
    resolved = str(codex_bin) if codex_bin is not None else shutil.which("codex")
    if resolved is None:
        raise KagentError("Install the Codex CLI first.")
    return resolved


def _run(
    command: list[str],
    *,
    input: str | None = None,
    capture: bool = False,
) -> subprocess.CompletedProcess[str]:
    result = subprocess.run(
        command,
        input=input,
        text=True,
        check=False,
        capture_output=capture,
    )

    if result.returncode != 0:
        message = result.stderr or result.stdout or f"Command failed: {' '.join(command)}"
        raise KagentError(message)

    return result
