"""Thread API for running Codex-backed coding-agent tasks."""

from __future__ import annotations

import asyncio
import json
import shelve
import shutil
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal

Runner = Literal["sdk", "cli"]
ApprovalPolicy = Literal["untrusted", "on-failure", "on-request", "never"]
SandboxMode = Literal["read-only", "workspace-write", "danger-full-access"]
Goal = bool | str

DEFAULT_MODEL = "gpt-5.4-mini"
DEFAULT_RUNNER: Runner = "cli"
DEFAULT_APPROVAL: ApprovalPolicy = "never"
DEFAULT_SANDBOX: SandboxMode = "danger-full-access"


class KagentError(RuntimeError):
    """Raised when kagent cannot run the requested Codex task."""


@dataclass(frozen=True, slots=True)
class Run:
    """Result returned by a kagent thread run."""

    text: str | None
    thread_id: str | None
    thread: str


class Thread:
    """A named, persistent Codex thread."""

    def __init__(
        self,
        id: str,
        *,
        workspace: str | Path = ".",
        model: str = DEFAULT_MODEL,
        runner: Runner = DEFAULT_RUNNER,
        ask_for_approval: ApprovalPolicy = DEFAULT_APPROVAL,
        sandbox: SandboxMode = DEFAULT_SANDBOX,
        skip_git_repo_check: bool = True,
        yolo: bool = True,
        codex_bin: str | Path | None = None,
        store_path: str | Path | None = None,
    ) -> None:
        thread_id = id.strip()
        if not thread_id:
            raise ValueError("Thread id must be a non-empty string.")

        self.id = thread_id
        self.workspace = Path(workspace).resolve()
        self.model = model
        self.runner = runner
        self.ask_for_approval = ask_for_approval
        self.sandbox = sandbox
        self.skip_git_repo_check = skip_git_repo_check
        self.yolo = yolo
        self.codex_bin = str(codex_bin) if codex_bin is not None else None
        self.store_path = Path(store_path or self.workspace / ".kagent" / "threads")

    async def run(self, prompt: str, *, goal: Goal = False) -> Run:
        """Run one prompt on this thread."""

        self.workspace.mkdir(parents=True, exist_ok=True)

        if self.runner == "cli" or goal:
            return await self._run_cli(self._build_prompt(prompt, goal))

        return await self._run_sdk(prompt)

    async def _run_sdk(self, prompt: str) -> Run:
        try:
            from openai_codex import ApprovalMode, AppServerConfig, AsyncCodex
            from openai_codex.generated.v2_all import SandboxMode as CodexSandboxMode
        except ModuleNotFoundError as exc:
            raise KagentError(
                "Install the experimental Codex SDK before using runner='sdk'."
            ) from exc

        self.store_path.parent.mkdir(parents=True, exist_ok=True)
        approval_mode = self._approval_mode(ApprovalMode)
        sandbox = CodexSandboxMode(self.sandbox)

        with shelve.open(str(self.store_path)) as store:
            saved = store.get(self.id)

            async with AsyncCodex(config=AppServerConfig(codex_bin=self._codex_bin())) as codex:
                if saved:
                    thread = await codex.thread_resume(
                        saved["thread_id"],
                        approval_mode=approval_mode,
                        cwd=str(self.workspace),
                        sandbox=sandbox,
                    )
                else:
                    thread = await codex.thread_start(
                        approval_mode=approval_mode,
                        cwd=str(self.workspace),
                        model=self.model,
                        sandbox=sandbox,
                    )
                    store[self.id] = {
                        "provider": "codex",
                        "thread_id": thread.id,
                        "workspace": str(self.workspace),
                        "model": self.model,
                    }

                result = await thread.run(prompt, approval_mode=approval_mode)

        return Run(text=result.final_response, thread_id=thread.id, thread=self.id)

    async def _run_cli(self, prompt: str) -> Run:
        saved_thread_id = self._saved_thread_id()

        with tempfile.TemporaryDirectory(prefix="kagent-") as temp_dir:
            output_file = Path(temp_dir) / "last-message.txt"
            command = self._cli_command(prompt, output_file, saved_thread_id)
            process = await asyncio.create_subprocess_exec(
                *command,
                stdin=asyncio.subprocess.DEVNULL,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await process.communicate()

            output = stdout.decode()
            error = stderr.decode()

            if process.returncode != 0:
                raise KagentError(error or output)

            parsed_thread_id, parsed_text = self._parse_cli_output(output)
            thread_id = parsed_thread_id or saved_thread_id
            text = self._read_output_file(output_file) or parsed_text or output

            if thread_id is not None:
                self._save_thread_id(thread_id, provider="codex-cli")

        return Run(text=text, thread_id=thread_id, thread=self.id)

    def _cli_command(
        self,
        prompt: str,
        output_file: Path,
        saved_thread_id: str | None,
    ) -> list[str]:
        command = [
            self._codex_bin(),
            "-a",
            self.ask_for_approval,
        ]

        if self.yolo:
            command.append("--dangerously-bypass-approvals-and-sandbox")
        else:
            command.extend(["--sandbox", self.sandbox])

        if saved_thread_id is None:
            command.extend(["exec", "--json", "-o", str(output_file)])
        else:
            command.extend(["exec", "resume", "--json", "-o", str(output_file)])

        if self.skip_git_repo_check:
            command.append("--skip-git-repo-check")

        command.extend(["-m", self.model])

        if saved_thread_id is None:
            command.extend(["-C", str(self.workspace), prompt])
        else:
            command.extend([saved_thread_id, prompt])

        return command

    def _codex_bin(self) -> str:
        resolved = self.codex_bin or shutil.which("codex")
        if resolved is None:
            raise KagentError("Install the codex CLI first.")
        return resolved

    def _approval_mode(self, approval_mode_type: Any) -> Any:
        if self.ask_for_approval == "never":
            return approval_mode_type.deny_all
        return approval_mode_type.auto_review

    @staticmethod
    def _build_prompt(prompt: str, goal: Goal) -> str:
        if not goal:
            return prompt
        if goal is True:
            return f"/goal {prompt.strip()}"
        return f"/goal {goal.strip()}\n\n{prompt.strip()}"

    @staticmethod
    def _parse_cli_output(output: str) -> tuple[str | None, str | None]:
        thread_id: str | None = None
        text: str | None = None

        for line in output.splitlines():
            try:
                event = json.loads(line)
            except json.JSONDecodeError:
                continue

            if not isinstance(event, dict):
                continue

            if event.get("type") == "thread.started" and isinstance(event.get("thread_id"), str):
                thread_id = event["thread_id"]

            item = event.get("item")
            if isinstance(item, dict) and item.get("type") == "agent_message":
                item_text = item.get("text")
                if isinstance(item_text, str):
                    text = item_text

        return thread_id, text

    @staticmethod
    def _read_output_file(path: Path) -> str | None:
        if not path.exists():
            return None

        text = path.read_text()
        return text or None

    def _saved_thread_id(self) -> str | None:
        self.store_path.parent.mkdir(parents=True, exist_ok=True)

        with shelve.open(str(self.store_path)) as store:
            saved = store.get(self.id)

        if not isinstance(saved, dict):
            return None

        thread_id = saved.get("thread_id")
        if isinstance(thread_id, str):
            return thread_id
        return None

    def _save_thread_id(self, thread_id: str, *, provider: str) -> None:
        self.store_path.parent.mkdir(parents=True, exist_ok=True)

        with shelve.open(str(self.store_path)) as store:
            store[self.id] = {
                "provider": provider,
                "thread_id": thread_id,
                "workspace": str(self.workspace),
                "model": self.model,
            }
