"""agent-replay — record and replay LLM agent traces for deterministic regression testing.

Framework-agnostic. Works with OpenAI, Anthropic, LiteLLM, LangChain, CrewAI,
or any custom agent. No LLM calls during replay — tests are fast, free, deterministic.

Quick start:
    from agent_replay import Recorder, Replayer

    # Record an agent run
    with Recorder(save_to="cassettes/test_math.yaml") as rec:
        result = agent.run("What is 2+2?")

    # Replay deterministically (zero API calls)
    with Replayer("cassettes/test_math.yaml"):
        result = agent.run("What is 2+2?")
        assert result == "4"

    # Also works async:
    async with Recorder(save_to="cassettes/test.yaml") as rec:
        result = await agent.arun("What is 2+2?")
"""

from agent_replay._types import (
    EventType,
    Trace,
    TraceEvent,
    TraceMetadata,
)
from agent_replay.assertions import (
    AgentLoopError,
    BudgetExceededError,
    assert_cost_under,
    assert_max_llm_calls,
    assert_no_loops,
    assert_tokens_under,
)
from agent_replay.cassette import (
    CassetteMismatchError,
    CassetteNotFoundError,
    load_cassette,
    save_cassette,
)
from agent_replay.diff import TraceDiff, assert_trace_unchanged, diff_traces
from agent_replay.normalize import (
    NormalizedResponse,
    NormalizedToolCall,
    normalize_for_comparison,
    normalize_response,
)
from agent_replay.recorder import Recorder
from agent_replay.replayer import Replayer
from agent_replay.reporters.cost_dashboard import CostDashboard, CostSummary

__version__ = "0.4.0"

__all__ = [
    # Core
    "Recorder",
    "Replayer",
    # Types
    "Trace",
    "TraceEvent",
    "TraceMetadata",
    "EventType",
    # Cassette
    "save_cassette",
    "load_cassette",
    "CassetteNotFoundError",
    "CassetteMismatchError",
    # Diff
    "TraceDiff",
    "diff_traces",
    "assert_trace_unchanged",
    # Normalization
    "NormalizedToolCall",
    "NormalizedResponse",
    "normalize_response",
    "normalize_for_comparison",
    # Assertions
    "assert_cost_under",
    "assert_tokens_under",
    "assert_max_llm_calls",
    "assert_no_loops",
    "BudgetExceededError",
    "AgentLoopError",
    # Reporters
    "CostDashboard",
    "CostSummary",
]
