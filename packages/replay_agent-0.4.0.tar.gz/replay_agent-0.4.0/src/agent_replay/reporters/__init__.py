"""Trace visualisation and reporting for agent-replay.

Available reporters:
  - terminal: Rich-based interactive time-travel debugger
  - html: Single-file HTML trace report generator
"""
