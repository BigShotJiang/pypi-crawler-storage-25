"""Tests for subscriptions mode resolution and merging."""

from pathlib import Path
from unittest.mock import patch

import pytest

from noscroll.subscriptions import (
    load_effective_subscriptions,
    normalize_subscriptions_mode,
    resolve_subscription_sources,
)


def test_normalize_subscriptions_mode_aliases():
    assert normalize_subscriptions_mode("external") == "external-only"
    assert normalize_subscriptions_mode("internal-only") == "builtin-only"
    assert normalize_subscriptions_mode(None) == "auto"


def test_resolve_subscription_sources_auto_prefers_configured(tmp_path: Path):
    configured = tmp_path / "custom.toml"
    configured.write_text("", encoding="utf-8")
    builtin = tmp_path / "builtin.toml"
    builtin.write_text("", encoding="utf-8")

    with patch("noscroll.subscriptions.resolve_builtin_subscriptions_path", return_value=builtin):
        paths = resolve_subscription_sources(str(configured), "auto")

    assert paths == [configured]


def test_load_effective_subscriptions_merge_dedupes_and_prefers_external(tmp_path: Path):
    configured = tmp_path / "custom.toml"
    configured.write_text(
        """
[[feeds]]
name = "External Override"
feed_url = "https://example.com/feed-a.xml"

[[feeds]]
name = "External New"
feed_url = "https://example.com/feed-c.xml"

[[sites]]
name = "External Site"
url = "https://example.com/blog"
enabled = false

[hackernews]
enabled = false

[[x_users]]
username = "alice"

[[x_users]]
username = "charlie"
""".strip(),
        encoding="utf-8",
    )
    builtin = tmp_path / "builtin.toml"
    builtin.write_text(
        """
[[feeds]]
name = "Builtin Feed A"
feed_url = "https://example.com/feed-a.xml"

[[feeds]]
name = "Builtin Feed B"
feed_url = "https://example.com/feed-b.xml"

[[sites]]
name = "Builtin Site"
url = "https://example.com/blog"
enabled = true

[sites_defaults]
max_posts = 20

[hackernews]
enabled = true
top_n = 30

[[x_users]]
username = "alice"

[[x_users]]
username = "bob"
""".strip(),
        encoding="utf-8",
    )

    with patch("noscroll.subscriptions.resolve_builtin_subscriptions_path", return_value=builtin):
        subscriptions = load_effective_subscriptions(str(configured), "merge")

    assert [feed.title for feed in subscriptions.feeds] == [
        "External Override",
        "External New",
        "Builtin Feed B",
    ]
    assert [feed.xml_url for feed in subscriptions.feeds] == [
        "https://example.com/feed-a.xml",
        "https://example.com/feed-c.xml",
        "https://example.com/feed-b.xml",
    ]
    assert subscriptions.sites == [
        {
            "name": "External Site",
            "url": "https://example.com/blog",
            "enabled": False,
        }
    ]
    assert subscriptions.sites_defaults == {"max_posts": 20}
    assert subscriptions.hackernews == {"enabled": False, "top_n": 30}
    assert subscriptions.x_users == [
        {"username": "alice"},
        {"username": "charlie"},
        {"username": "bob"},
    ]


def test_load_effective_subscriptions_external_only_requires_configured_file(tmp_path: Path):
    configured = tmp_path / "missing.toml"
    builtin = tmp_path / "builtin.toml"
    builtin.write_text("", encoding="utf-8")

    with patch("noscroll.subscriptions.resolve_builtin_subscriptions_path", return_value=builtin):
        with pytest.raises(FileNotFoundError):
            load_effective_subscriptions(str(configured), "external-only")
