"""Tests for X source fetching and cache behavior."""

from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from noscroll.sources.providers import fetch_x_items
from noscroll.sources.x import _fetch_user_posts


class _FakeResponse:
    def __init__(self, payload):
        self._payload = payload

    def raise_for_status(self):
        return None

    def json(self):
        return self._payload


class _FakeClient:
    def __init__(self, payloads):
        self.payloads = payloads
        self.calls = []

    async def get(self, url, headers=None, params=None):
        self.calls.append(
            {
                "url": url,
                "headers": dict(headers or {}),
                "params": dict(params or {}),
            }
        )
        return _FakeResponse(self.payloads[len(self.calls) - 1])


@pytest.mark.asyncio
async def test_fetch_user_posts_includes_end_time_and_paginates():
    client = _FakeClient(
        [
            {
                "data": [
                    {
                        "id": "1",
                        "text": "first tweet",
                        "created_at": "2024-01-01T01:00:00Z",
                    }
                ],
                "meta": {"next_token": "page-2"},
            },
            {
                "data": [
                    {
                        "id": "2",
                        "text": "second tweet",
                        "created_at": "2024-01-01T02:00:00Z",
                    }
                ],
                "meta": {},
            },
        ]
    )
    start_dt = datetime(2024, 1, 1, tzinfo=timezone.utc)
    end_dt = datetime(2024, 1, 2, tzinfo=timezone.utc)

    items = await _fetch_user_posts(
        client=client,
        user_id="123",
        username="jack",
        bearer_token="test-token",
        start_time=start_dt,
        end_time=end_dt,
        debug=False,
    )

    assert len(items) == 2
    assert client.calls[0]["params"]["start_time"] == "2024-01-01T00:00:00Z"
    assert client.calls[0]["params"]["end_time"] == "2024-01-02T00:00:00Z"
    assert "pagination_token" not in client.calls[0]["params"]
    assert client.calls[1]["params"]["pagination_token"] == "page-2"


@pytest.mark.asyncio
async def test_fetch_x_items_uses_full_window_cache_key():
    cfg = MagicMock()
    cfg.subscriptions_path = "/tmp/subscriptions.toml"
    cfg.subscriptions_mode = "merge"
    cfg.x_bearer_token = "token"
    start_dt = datetime(2024, 1, 5, tzinfo=timezone.utc)
    end_dt = datetime(2024, 1, 7, tzinfo=timezone.utc)
    cached_items = []

    with patch("noscroll.sources.providers._load_x_cache", return_value=cached_items) as mock_load:
        result = await fetch_x_items(cfg, start_dt, end_dt, debug=False, refresh=False)

    assert result == cached_items
    mock_load.assert_called_once_with("20240105T000000Z__20240107T000000Z")


@pytest.mark.asyncio
async def test_fetch_x_items_saves_full_window_cache_key():
    cfg = MagicMock()
    cfg.subscriptions_path = "/tmp/subscriptions.toml"
    cfg.subscriptions_mode = "merge"
    cfg.x_bearer_token = "token"
    start_dt = datetime(2024, 1, 5, tzinfo=timezone.utc)
    end_dt = datetime(2024, 1, 7, tzinfo=timezone.utc)
    items = [MagicMock()]
    subscriptions = MagicMock(x_defaults={"enabled": True}, x_users=[{"username": "jack"}])

    with patch("noscroll.sources.providers._load_x_cache", return_value=None):
        with patch("noscroll.sources.providers.load_effective_subscriptions", return_value=subscriptions):
            with patch("noscroll.sources.x.fetch_x_users", new_callable=AsyncMock) as mock_fetch:
                with patch("noscroll.sources.providers._save_x_cache") as mock_save:
                    mock_fetch.return_value = items
                    result = await fetch_x_items(cfg, start_dt, end_dt, debug=False, refresh=False)

    assert result == items
    mock_save.assert_called_once_with("20240105T000000Z__20240107T000000Z", items)
