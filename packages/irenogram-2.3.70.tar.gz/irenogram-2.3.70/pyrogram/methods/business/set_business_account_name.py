#  Irenogram - Telegram MTProto API Client Library for Python
#  Copyright (C) 2025-present Abir Arafat Chawdhury <https://github.com/abirxdhack>
#
#  This file is part of Irenogram.
#
#  Irenogram is free software: you can redistribute it and/or modify
#  it under the terms of the GNU Lesser General Public License as published
#  by the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  Irenogram is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU Lesser General Public License for more details.
#
#  You should have received a copy of the GNU Lesser General Public License
#  along with Irenogram.  If not, see <http://www.gnu.org/licenses/>.

import pyrogram
from pyrogram import raw


class SetBusinessAccountName:
    async def set_business_account_name(
        self: "pyrogram.Client",
        business_connection_id: str,
        first_name: str,
        last_name: str = ""
    ) -> bool:
        """Changes the first and last name of a managed business account.

        Parameters:
            business_connection_id (``str``):
                Unique identifier of the business connection.

            first_name (``str``):
                New value of the first name; 1-64 characters.

            last_name (``str``, *optional*):
                New value of the last name; 0-64 characters.

        Returns:
            ``bool``: True on success.
        """
        r = await self.invoke(
            raw.functions.InvokeWithBusinessConnection(
                connection_id=business_connection_id,
                query=raw.functions.account.UpdateProfile(
                    first_name=first_name,
                    last_name=last_name
                )
            )
        )
        return bool(r)
