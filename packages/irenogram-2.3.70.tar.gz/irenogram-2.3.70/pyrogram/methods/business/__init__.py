#  Irenogram - Telegram MTProto API Client Library for Python
#  Copyright (C) 2017-present Dan <https://github.com/delivrance>
#  Copyright (C) 2025-present Abir Arafat Chawdhury <https://github.com/abirxdhack>
#
#  This file is part of Irenogram.
#
#  Irenogram is free software: you can redistribute it and/or modify
#  it under the terms of the GNU Lesser General Public License as published
#  by the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  Irenogram is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU Lesser General Public License for more details.
#
#  You should have received a copy of the GNU Lesser General Public License
#  along with Irenogram.  If not, see <http://www.gnu.org/licenses/>.

from .answer_pre_checkout_query import AnswerPreCheckoutQuery
from .answer_shipping_query import AnswerShippingQuery
from .delete_business_messages import DeleteBusinessMessages
from .get_business_connection import GetBusinessConnection
from .get_business_account_gifts import GetBusinessAccountGifts
from .get_business_account_star_balance import GetBusinessAccountStarBalance
from .transfer_business_account_stars import TransferBusinessAccountStars
from .set_business_account_name import SetBusinessAccountName
from .set_business_account_username import SetBusinessAccountUsername
from .set_business_account_bio import SetBusinessAccountBio
from .set_business_account_profile_photo import SetBusinessAccountProfilePhoto
from .remove_business_account_profile_photo import RemoveBusinessAccountProfilePhoto
from .set_business_account_gift_settings import SetBusinessAccountGiftSettings
from .read_business_message import ReadBusinessMessage


class TelegramBusiness(
    AnswerPreCheckoutQuery,
    AnswerShippingQuery,
    DeleteBusinessMessages,
    GetBusinessConnection,
    GetBusinessAccountGifts,
    GetBusinessAccountStarBalance,
    TransferBusinessAccountStars,
    SetBusinessAccountName,
    SetBusinessAccountUsername,
    SetBusinessAccountBio,
    SetBusinessAccountProfilePhoto,
    RemoveBusinessAccountProfilePhoto,
    SetBusinessAccountGiftSettings,
    ReadBusinessMessage,
):
    pass
