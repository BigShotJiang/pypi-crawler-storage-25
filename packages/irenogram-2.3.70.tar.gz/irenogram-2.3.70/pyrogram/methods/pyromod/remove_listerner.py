#  Irenogram - Telegram MTProto API Client Library for Python
#  Copyright (C) 2020 Cezar H. <https://github.com/usernein>
#  Copyright (C) 2025-present Abir Arafat Chawdhury <https://github.com/abirxdhack>
#
#  This file is part of Irenogram.
#
#  Irenogram is free software: you can redistribute it and/or modify
#  it under the terms of the GNU Lesser General Public License as published
#  by the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  Irenogram is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU Lesser General Public License for more details.
#
#  You should have received a copy of the GNU Lesser General Public License
#  along with Irenogram.  If not, see <http://www.gnu.org/licenses/>.

import pyrogram
from pyrogram.types import Listener

class RemoveListener:
    def remove_listener(
        self: "pyrogram.Client",
        listener: Listener
    ):
        """Removes a listener from the :meth:`~pyrogram.Client.listeners` dictionary.

        .. include:: /_includes/usable-by/users-bots.rst

        Parameters:
            listener (:obj:`~pyrogram.types.Listener`):
                The listener to remove.
        """
        try:
            self.listeners[listener.listener_type].remove(listener)
        except ValueError:
            pass
