#  Irenogram - Telegram MTProto API Client Library for Python
#  Copyright (C) 2017-present Dan <https://github.com/delivrance>
#  Copyright (C) 2025-present Abir Arafat Chawdhury <https://github.com/abirxdhack>
#
#  This file is part of Irenogram.
#
#  Irenogram is free software: you can redistribute it and/or modify
#  it under the terms of the GNU Lesser General Public License as published
#  by the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  Irenogram is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU Lesser General Public License for more details.
#
#  You should have received a copy of the GNU Lesser General Public License
#  along with Irenogram.  If not, see <http://www.gnu.org/licenses/>.

from typing import Union

import pyrogram
from pyrogram import raw, types


class SuggestBirthday:
    async def suggest_birthday(
        self: "pyrogram.Client",
        user_id: Union[int, str],
        day: int,
        month: int,
        year: int = None,
    ) -> bool:
        """Suggest a birthday date for another user.

        Sends a birthday suggestion to a contact.  The recipient can accept
        or ignore the suggestion from their own profile settings.

        This method calls ``users.suggestBirthday`` (TL Layer 207+).

        .. include:: /_includes/usable-by/users.rst

        Parameters:
            user_id (``int`` | ``str``):
                Unique identifier or username of the target user.

            day (``int``):
                Suggested day of birth (1–31).

            month (``int``):
                Suggested month of birth (1–12).

            year (``int``, *optional*):
                Suggested year of birth.
                Omit to suggest only a day and month without a year.

        Returns:
            ``bool``: True on success.

        Raises:
            :class:`~pyrogram.errors.RPCError`: On Telegram API error.

        Example:
            .. code-block:: python

                # Suggest January 1st (any year) to a user
                await app.suggest_birthday("username", day=1, month=1)

                # Suggest a full date
                await app.suggest_birthday(123456789, day=15, month=6, year=1990)
        """
        peer = await self.resolve_peer(user_id)

        # resolve_peer may return InputPeerUser; we need InputUser
        if isinstance(peer, raw.types.InputPeerUser):
            input_user = raw.types.InputUser(
                user_id=peer.user_id,
                access_hash=peer.access_hash,
            )
        elif isinstance(peer, raw.types.InputPeerSelf):
            input_user = raw.types.InputUserSelf()
        else:
            raise ValueError(f"user_id must resolve to a user, got {type(peer)}")

        birthday = raw.types.Birthday(
            day=day,
            month=month,
            year=year,
        )

        r = await self.invoke(
            raw.functions.users.SuggestBirthday(
                id=input_user,
                birthday=birthday,
            )
        )

        return bool(r)
