#  Irenogram - Telegram MTProto API Client Library for Python
#  Copyright (C) 2017-present Dan <https://github.com/delivrance>
#  Copyright (C) 2025-present Abir Arafat Chawdhury <https://github.com/abirxdhack>
#
#  This file is part of Irenogram.
#
#  Irenogram is free software: you can redistribute it and/or modify
#  it under the terms of the GNU Lesser General Public License as published
#  by the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  Irenogram is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU Lesser General Public License for more details.
#
#  You should have received a copy of the GNU Lesser General Public License
#  along with Irenogram.  If not, see <http://www.gnu.org/licenses/>.

from typing import Union

import pyrogram
from pyrogram import raw


class DeleteStoryAlbum:
    async def delete_story_album(
        self: "pyrogram.Client",
        chat_id: Union[int, str],
        album_id: int,
    ) -> bool:
        """Delete a story album.

        The stories inside the album are not deleted — only the album itself
        is removed.

        .. include:: /_includes/usable-by/users.rst

        Parameters:
            chat_id (``int`` | ``str``):
                Unique identifier or username of the peer who owns the album.

            album_id (``int``):
                ID of the album to delete.

        Returns:
            ``bool``: True on success.

        Example:
            .. code-block:: python

                await app.delete_story_album("me", album_id=1)
        """
        peer = await self.resolve_peer(chat_id)

        return await self.invoke(
            raw.functions.stories.DeleteAlbum(
                peer=peer,
                album_id=album_id,
            )
        )
