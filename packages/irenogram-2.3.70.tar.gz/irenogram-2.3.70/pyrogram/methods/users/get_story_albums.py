#  Irenogram - Telegram MTProto API Client Library for Python
#  Copyright (C) 2017-present Dan <https://github.com/delivrance>
#  Copyright (C) 2025-present Abir Arafat Chawdhury <https://github.com/abirxdhack>
#
#  This file is part of Irenogram.
#
#  Irenogram is free software: you can redistribute it and/or modify
#  it under the terms of the GNU Lesser General Public License as published
#  by the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  Irenogram is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU Lesser General Public License for more details.
#
#  You should have received a copy of the GNU Lesser General Public License
#  along with Irenogram.  If not, see <http://www.gnu.org/licenses/>.

from typing import List, Union

import pyrogram
from pyrogram import raw, types


class GetStoryAlbums:
    async def get_story_albums(
        self: "pyrogram.Client",
        chat_id: Union[int, str],
    ) -> List["types.StoryAlbum"]:
        """Get all story albums for a user or channel.

        .. include:: /_includes/usable-by/users.rst

        Parameters:
            chat_id (``int`` | ``str``):
                Unique identifier or username of the target peer.
                Use ``"me"`` or ``"self"`` for your own profile.

        Returns:
            List of :obj:`~pyrogram.types.StoryAlbum`: All albums belonging to
            the peer. Returns an empty list if no albums exist.

        Example:
            .. code-block:: python

                albums = await app.get_story_albums("me")
                for album in albums:
                    print(album.album_id, album.title)
        """
        peer = await self.resolve_peer(chat_id)

        r = await self.invoke(
            raw.functions.stories.GetAlbums(peer=peer, hash=0)
        )

        # stories.albumsNotModified is returned when hash matches server hash
        if isinstance(r, raw.types.stories.AlbumsNotModified):
            return types.List()

        return types.List(
            [await types.StoryAlbum._parse(self, album) for album in r.albums]
        )
