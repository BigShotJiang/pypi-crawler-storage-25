#  Irenogram - Telegram MTProto API Client Library for Python
#  Copyright (C) 2017-present Dan <https://github.com/delivrance>
#  Copyright (C) 2025-present Abir Arafat Chawdhury <https://github.com/abirxdhack>
#
#  This file is part of Irenogram.
#
#  Irenogram is free software: you can redistribute it and/or modify
#  it under the terms of the GNU Lesser General Public License as published
#  by the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  Irenogram is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU Lesser General Public License for more details.
#
#  You should have received a copy of the GNU Lesser General Public License
#  along with Irenogram.  If not, see <http://www.gnu.org/licenses/>.

import pyrogram
from pyrogram import raw


class HideGift:
    async def hide_gift(
        self: "pyrogram.Client",
        message_id: int
    ) -> bool:
        """Hide the star gift from your profile.

        .. include:: /_includes/usable-by/users.rst

        Parameters:
            message_id (``int``):
                Unique message identifier of star gift.

        Returns:
            ``bool``: On success, True is returned.

        Example:
            .. code-block:: python

                # Hide gift
                app.hide_gift(message_id=123)
        """
        r = await self.invoke(
            raw.functions.payments.SaveStarGift(
                stargift=raw.types.InputSavedStarGiftUser(
                    msg_id=message_id
                ),
                unsave=True
            )
        )

        return r
