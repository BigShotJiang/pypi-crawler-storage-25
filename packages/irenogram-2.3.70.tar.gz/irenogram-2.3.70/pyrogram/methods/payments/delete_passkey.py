#  Irenogram - Telegram MTProto API Client Library for Python
#  Copyright (C) 2017-present Dan <https://github.com/delivrance>
#  Copyright (C) 2025-present Abir Arafat Chawdhury <https://github.com/abirxdhack>
#
#  This file is part of Irenogram.
#
#  Irenogram is free software: you can redistribute it and/or modify
#  it under the terms of the GNU Lesser General Public License as published
#  by the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  Irenogram is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU Lesser General Public License for more details.
#
#  You should have received a copy of the GNU Lesser General Public License
#  along with Irenogram.  If not, see <http://www.gnu.org/licenses/>.

import pyrogram
from pyrogram import raw


class DeletePasskey:
    async def delete_passkey(
        self: "pyrogram.Client",
        passkey_id: str,
    ) -> bool:
        """Delete a registered passkey from the current account.

        .. include:: /_includes/usable-by/users.rst

        Parameters:
            passkey_id (``str``):
                The unique credential ID of the passkey to delete.
                Obtain this from :meth:`~pyrogram.Client.get_passkeys`.

        Returns:
            ``bool``: True on success.

        Raises:
            :class:`~pyrogram.errors.RPCError`: On Telegram API error.

        Example:
            .. code-block:: python

                # Delete a specific passkey by its ID
                await app.delete_passkey(passkey_id="abc123")

                # Delete all passkeys
                passkeys = await app.get_passkeys()
                for pk in passkeys:
                    await app.delete_passkey(pk.id)
        """
        return await self.invoke(
            raw.functions.account.DeletePasskey(id=passkey_id)
        )
