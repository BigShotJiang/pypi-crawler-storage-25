#  Irenogram - Telegram MTProto API Client Library for Python
#  Copyright (C) 2017-present Dan <https://github.com/delivrance>
#  Copyright (C) 2025-present Abir Arafat Chawdhury <https://github.com/abirxdhack>
#
#  This file is part of Irenogram.
#
#  Irenogram is free software: you can redistribute it and/or modify
#  it under the terms of the GNU Lesser General Public License as published
#  by the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  Irenogram is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU Lesser General Public License for more details.
#
#  You should have received a copy of the GNU Lesser General Public License
#  along with Irenogram.  If not, see <http://www.gnu.org/licenses/>.

from typing import List

import pyrogram
from pyrogram import raw, types


class GetPasskeys:
    async def get_passkeys(
        self: "pyrogram.Client",
    ) -> List["types.Passkey"]:
        """Get the list of passkeys registered for the current account.

        Passkeys are hardware or software credentials used instead of a
        password for Telegram login.

        .. include:: /_includes/usable-by/users.rst

        Returns:
            List of :obj:`~pyrogram.types.Passkey`: On success, a list of
            registered passkeys is returned. Returns an empty list if no
            passkeys are registered.

        Example:
            .. code-block:: python

                passkeys = await app.get_passkeys()
                for pk in passkeys:
                    print(pk.name, pk.date)
        """
        r = await self.invoke(
            raw.functions.account.GetPasskeys()
        )

        # r is account.Passkeys containing a list of Passkey objects
        return types.List(
            [types.Passkey._parse(self, p) for p in r.passkeys]
        )
