#  Irenogram - Telegram MTProto API Client Library for Python
#  Copyright (C) 2025-present Abir Arafat Chawdhury <https://github.com/abirxdhack>
#
#  This file is part of Irenogram.
#
#  Irenogram is free software: you can redistribute it and/or modify
#  it under the terms of the GNU Lesser General Public License as published
#  by the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  Irenogram is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU Lesser General Public License for more details.
#
#  You should have received a copy of the GNU Lesser General Public License
#  along with Irenogram.  If not, see <http://www.gnu.org/licenses/>.

from typing import Union

import pyrogram
from pyrogram import raw


class RemoveChatVerification:
    async def remove_chat_verification(
        self: "pyrogram.Client",
        chat_id: Union[int, str]
    ) -> bool:
        """Removes verification from a chat that is currently verified on behalf of the organization.

        Parameters:
            chat_id (``int`` | ``str``):
                Unique identifier of the target chat or username.

        Returns:
            ``bool``: True on success.
        """
        r = await self.invoke(
            raw.functions.bots.SetCustomVerification(
                peer=await self.resolve_peer(chat_id),
                enabled=False
            )
        )
        return bool(r)
