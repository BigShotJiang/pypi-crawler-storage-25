"""Trust-gating middleware for Python web frameworks using AgentScore."""

from typing import Any

from agentscore_commerce.identity._denial import (
    FIXABLE_DENIAL_REASONS,
    build_contact_support_next_steps,
    build_signer_mismatch_body,
    denial_reason_status,
    is_fixable_denial,
    verification_agent_instructions,
)
from agentscore_commerce.identity._response import denial_reason_to_body
from agentscore_commerce.identity.a2a import (
    UCP_A2A_EXTENSION_URI,
    A2AAgentCard,
    A2AAgentCardCapabilities,
    A2AAgentCardExtension,
    A2AAgentCardSignature,
    A2AAgentInterface,
    A2AAgentProvider,
    A2AAgentSkill,
    build_a2a_agent_card,
    ucp_a2a_extension,
)
from agentscore_commerce.identity.client import GateClient
from agentscore_commerce.identity.policy import (
    EnforcementMode,
    GateResult,
    IdentityStatus,
    PolicyBlock,
    build_gate_from_policy,
    run_gate_with_enforcement,
    shipping_country_allowed,
    shipping_state_allowed,
)
from agentscore_commerce.identity.signer import extract_x402_signer
from agentscore_commerce.identity.types import (
    AgentIdentity,
    AgentMemoryHint,
    AssessResult,
    DenialCode,
    DenialReason,
    OperatorVerification,
    SignerSanctions,
    SignerVerdict,
    VerifyWalletSignerResult,
    build_agent_memory_hint,
)
from agentscore_commerce.identity.ucp import (
    AGENTSCORE_UCP_CAPABILITY,
    AgentScoreGatePolicy,
    UCPCapabilityBinding,
    UCPPaymentHandlerBinding,
    UCPProfile,
    UCPProfileBody,
    UCPServiceBinding,
    UCPSigningKey,
    build_ucp_profile,
    mpp_payment_handler,
    stripe_spt_payment_handler,
    x402_payment_handler,
)
from agentscore_commerce.identity.ucp_jwks import (
    GeneratedUCPKey,
    UCPVerificationError,
    build_jwks_response,
    generate_ucp_signing_key,
    sign_ucp_profile,
    verify_ucp_profile,
)


# ASGI middleware is the default import (re-exported as CreateSessionOnMissing too).
# Framework adapters are imported from their own submodules:
#   from agentscore_commerce.identity.fastapi import AgentScoreGate, get_agentscore_data  # native Depends()
#   from agentscore_commerce.identity.flask import agentscore_gate
#   from agentscore_commerce.identity.django import AgentScoreMiddleware
#   from agentscore_commerce.identity.aiohttp import agentscore_gate_middleware
#   from agentscore_commerce.identity.sanic import agentscore_gate
def _load_asgi_middleware() -> tuple[Any, Any]:
    try:
        from agentscore_commerce.identity.middleware import AgentScoreGate as _AgentScoreGate
        from agentscore_commerce.identity.middleware import CreateSessionOnMissing as _CreateSessionOnMissing

        return _AgentScoreGate, _CreateSessionOnMissing
    except ImportError:
        # starlette not installed
        return None, None


AgentScoreGate, CreateSessionOnMissing = _load_asgi_middleware()

__all__ = [
    "AGENTSCORE_UCP_CAPABILITY",
    "FIXABLE_DENIAL_REASONS",
    "UCP_A2A_EXTENSION_URI",
    "A2AAgentCard",
    "A2AAgentCardCapabilities",
    "A2AAgentCardExtension",
    "A2AAgentCardSignature",
    "A2AAgentInterface",
    "A2AAgentProvider",
    "A2AAgentSkill",
    "AgentIdentity",
    "AgentMemoryHint",
    "AgentScoreGate",
    "AgentScoreGatePolicy",
    "AssessResult",
    "CreateSessionOnMissing",
    "DenialCode",
    "DenialReason",
    "EnforcementMode",
    "GateClient",
    "GateResult",
    "GeneratedUCPKey",
    "IdentityStatus",
    "OperatorVerification",
    "PolicyBlock",
    "SignerSanctions",
    "SignerVerdict",
    "UCPCapabilityBinding",
    "UCPPaymentHandlerBinding",
    "UCPProfile",
    "UCPProfileBody",
    "UCPServiceBinding",
    "UCPSigningKey",
    "UCPVerificationError",
    "VerifyWalletSignerResult",
    "build_a2a_agent_card",
    "build_agent_memory_hint",
    "build_contact_support_next_steps",
    "build_gate_from_policy",
    "build_jwks_response",
    "build_signer_mismatch_body",
    "build_ucp_profile",
    "denial_reason_status",
    "denial_reason_to_body",
    "extract_x402_signer",
    "generate_ucp_signing_key",
    "is_fixable_denial",
    "mpp_payment_handler",
    "run_gate_with_enforcement",
    "shipping_country_allowed",
    "shipping_state_allowed",
    "sign_ucp_profile",
    "stripe_spt_payment_handler",
    "ucp_a2a_extension",
    "verification_agent_instructions",
    "verify_ucp_profile",
    "x402_payment_handler",
]
