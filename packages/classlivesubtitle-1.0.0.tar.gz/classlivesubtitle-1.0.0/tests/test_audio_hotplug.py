"""Tests for device hotplug detection."""
import sys
from unittest.mock import MagicMock, patch


class TestLinuxHotplugThread:
    def test_thread_sets_up_subscription(self):
        from src.audio.hotplug import LinuxHotplugThread

        mock_pulsectl = MagicMock()
        mock_pulse = MagicMock()
        mock_pulse.event_listen.side_effect = lambda: None
        mock_pulsectl.Pulse.return_value.__enter__ = MagicMock(return_value=mock_pulse)
        mock_pulsectl.Pulse.return_value.__exit__ = MagicMock(return_value=False)

        callback = MagicMock()

        with patch.dict(sys.modules, {"pulsectl": mock_pulsectl}):
            thread = LinuxHotplugThread(callback)
            thread.daemon = True
            thread.start()
            thread.join(timeout=2.0)

        mock_pulse.event_mask_set.assert_called_once_with("source")
        assert mock_pulse.event_callback_set.called


class TestWindowsHotplugPoller:
    def test_detects_device_change(self):
        from src.audio.hotplug import WindowsHotplugPoller

        dm = MagicMock()
        callback = MagicMock()

        initial = [{"id": "0", "name": "Mic A"}]
        changed = [{"id": "0", "name": "Mic A"}, {"id": "1", "name": "Mic B"}]

        dm.list_devices.side_effect = [
            initial,   # start() baseline
            initial,   # first poll — no change
            changed,   # second poll — change detected
        ]

        poller = WindowsHotplugPoller(dm, callback, interval=0.1)
        poller.start()  # sets _last_devices and schedules timer
        poller._timer.cancel()  # stop the scheduled timer

        poller._poll_once()
        callback.assert_not_called()

        poller._poll_once()
        callback.assert_called_once()
