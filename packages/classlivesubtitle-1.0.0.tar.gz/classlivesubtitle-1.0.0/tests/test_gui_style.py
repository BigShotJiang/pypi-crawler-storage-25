"""Tests for style.py — font loading and system theme detection."""

from gui.style import get_system_theme, STYLE_PRESETS


class TestStylePresets:
    def test_three_presets_exist(self):
        assert len(STYLE_PRESETS) == 3
        assert "Dark" in STYLE_PRESETS
        assert "Light" in STYLE_PRESETS
        assert "Transparent" in STYLE_PRESETS

    def test_dark_preset_has_bg_and_text(self):
        assert "bg" in STYLE_PRESETS["Dark"]
        assert "text" in STYLE_PRESETS["Dark"]


class TestGetSystemTheme:
    def test_returns_string(self):
        theme = get_system_theme()
        assert theme in ("light", "dark")
