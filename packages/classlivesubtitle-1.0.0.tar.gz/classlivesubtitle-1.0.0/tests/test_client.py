"""Tests for AST WebSocket client."""
import pytest
from unittest.mock import AsyncMock, MagicMock
from src.client import ASTClient
from src.config import Config
from src.protocol import EventType


def make_config(**overrides) -> Config:
    defaults = {
        "api_key": "test-key",
        "resource_id": "volc.service_type.10053",
        "ws_url": "ws://localhost:8765",
        "mode": "s2t",
        "source_language": "zh",
        "target_language": "en",
    }
    defaults.update(overrides)
    return Config(**defaults)


class TestASTClientInit:
    def test_creates_client_with_config(self):
        config = make_config()
        client = ASTClient(config)
        assert client.config is config
        assert client._session_id is None

    def test_builds_auth_headers(self):
        config = make_config()
        client = ASTClient(config)
        headers = client._build_headers("conn-123")
        assert headers["X-Api-Key"] == "test-key"
        assert headers["X-Api-Resource-Id"] == "volc.service_type.10053"


class TestASTClientSession:
    @pytest.mark.asyncio
    async def test_start_session_sends_correct_event(self):
        config = make_config()
        client = ASTClient(config)
        mock_ws = AsyncMock()
        client._ws = mock_ws

        await client._send_start_session("test-session-id")

        mock_ws.send.assert_called_once()
        sent_data = mock_ws.send.call_args[0][0]
        assert isinstance(sent_data, bytes)

    @pytest.mark.asyncio
    async def test_send_audio_sends_task_request(self):
        config = make_config()
        client = ASTClient(config)
        mock_ws = AsyncMock()
        client._ws = mock_ws

        await client._send_audio(b"\x00" * 2560)

        mock_ws.send.assert_called_once()

    @pytest.mark.asyncio
    async def test_finish_session_sends_finish_event(self):
        config = make_config()
        client = ASTClient(config)
        mock_ws = AsyncMock()
        client._ws = mock_ws

        await client._send_finish()

        mock_ws.send.assert_called_once()
