"""Tests for gui.worker — QThread with mock translation backend."""

import asyncio
import time

from gui.bridge import Bridge
from gui.worker import Worker
from gui.status import SessionStatus
from src.protocol import EventType


def _make_config():
    from src.config import Config
    return Config(
        api_key="test-key",
        source_language="en",
        target_language="zh",
        mode="s2t",
    )


def _drain_events(app, duration):
    """Process Qt events for *duration* seconds so queued signals arrive."""
    deadline = time.monotonic() + duration
    while time.monotonic() < deadline:
        app.processEvents()
        time.sleep(0.05)


def test_worker_has_bridge(qapp):
    worker = Worker()
    assert isinstance(worker.bridge, Bridge)


def test_worker_initial_state_is_idle(qapp):
    worker = Worker()
    assert worker.isRunning() is False


def test_worker_start_creates_asyncio_loop(qapp):
    worker = Worker()
    worker.start()
    time.sleep(0.2)
    assert worker.isRunning()
    assert worker.loop is not None
    worker.stop_session()
    worker.quit()
    worker.wait(2000)


def test_worker_stop_session(qapp):
    worker = Worker()
    worker.start()
    time.sleep(0.2)
    assert worker.isRunning()
    worker.stop_session()
    time.sleep(0.3)
    assert worker.isRunning()
    worker.quit()
    worker.wait(2000)


def test_worker_emits_mock_subtitles(qapp):
    """_mock_session still emits fake subtitles when called directly."""
    worker = Worker()
    config = _make_config()
    received = []
    worker.bridge.translation_subtitle.connect(
        lambda et, txt: received.append((et, txt))
    )
    worker.bridge.source_subtitle.connect(
        lambda et, txt: received.append((et, txt))
    )
    worker.start()
    _drain_events(qapp, 0.3)
    # Schedule _mock_session directly to test mock subtitle emission
    asyncio.run_coroutine_threadsafe(
        worker._mock_session(config), worker.loop
    )
    _drain_events(qapp, 2.5)
    worker.stop_session()
    worker.quit()
    worker.wait(2000)
    assert len(received) > 0


def test_worker_run_session_creates_mic_and_client(qapp):
    """_run_session should instantiate MicrophoneCapture and ASTClient."""
    from unittest.mock import AsyncMock, MagicMock, patch

    worker = Worker()
    worker.start()
    time.sleep(0.2)

    config = _make_config()

    with patch("gui.worker.MicrophoneCapture") as MockMic, \
         patch("gui.worker.ASTClient") as MockClient:
        mock_client = MockClient.return_value
        mock_client.run = AsyncMock()

        worker.start_session(config, device_id="2")
        _drain_events(qapp, 0.3)

        MockMic.assert_called_once_with(device_id="2")
        MockClient.assert_called_once_with(config)

    worker.stop_session()
    worker.quit()
    worker.wait(2000)


def test_worker_run_session_routes_events(qapp):
    """Events from ASTClient should appear on bridge signals."""
    from unittest.mock import AsyncMock, patch

    worker = Worker()
    worker.start()
    time.sleep(0.2)

    config = _make_config()
    received = []
    worker.bridge.translation_subtitle.connect(
        lambda et, txt: received.append((et, txt))
    )

    on_event_callback = None

    def capture_callback(handler):
        nonlocal on_event_callback
        on_event_callback = handler

    with patch("gui.worker.MicrophoneCapture") as MockMic, \
         patch("gui.worker.ASTClient") as MockClient:
        mock_client = MockClient.return_value
        mock_client.on_event.side_effect = capture_callback
        mock_client.run = AsyncMock()

        worker.start_session(config)
        _drain_events(qapp, 0.3)

        assert on_event_callback is not None
        on_event_callback({"event": EventType.TRANSLATION_SUBTITLE_RESPONSE, "text": "你好世界"})
        _drain_events(qapp, 0.1)

    worker.stop_session()
    worker.quit()
    worker.wait(2000)

    assert (EventType.TRANSLATION_SUBTITLE_RESPONSE, "你好世界") in received


def test_worker_run_session_stops_mic_on_cancel(qapp):
    """Stopping a real session should call mic.stop()."""
    from unittest.mock import AsyncMock, patch

    worker = Worker()
    worker.start()
    time.sleep(0.2)

    config = _make_config()

    with patch("gui.worker.MicrophoneCapture") as MockMic, \
         patch("gui.worker.ASTClient") as MockClient:
        mock_mic = MockMic.return_value
        mock_client = MockClient.return_value
        mock_client.run = AsyncMock()

        worker.start_session(config, device_id="1")
        _drain_events(qapp, 0.3)

        worker.stop_session()
        _drain_events(qapp, 0.3)

        mock_mic.stop.assert_called_once()

    worker.quit()
    worker.wait(2000)


def test_worker_reconnect_on_disconnect(qapp):
    """On disconnect, worker should retry up to 3 times."""
    from unittest.mock import AsyncMock, MagicMock, patch

    worker = Worker()
    worker.start()
    time.sleep(0.2)

    config = _make_config()
    statuses = []
    worker.bridge.status_changed.connect(lambda s: statuses.append(s))
    errors = []
    worker.bridge.error_occurred.connect(lambda e: errors.append(e))

    with patch("gui.worker.MicrophoneCapture") as MockMic, \
         patch("gui.worker.ASTClient") as MockClient, \
         patch("gui.worker.asyncio.sleep", new_callable=AsyncMock):
        MockClient.return_value.on_event = MagicMock()
        MockClient.return_value.run = AsyncMock(
            side_effect=ConnectionError("WebSocket disconnected")
        )
        worker.start_session(config)
        _drain_events(qapp, 1.0)

    worker.stop_session()
    worker.quit()
    worker.wait(2000)

    assert MockClient.call_count == 4
    assert statuses.count(SessionStatus.RECONNECTING) == 3
    assert len(errors) == 1
    assert "连接翻译服务失败" in errors[0]


def test_worker_reconnect_succeeds(qapp):
    """Reconnect should work if connection returns within 3 retries."""
    from unittest.mock import AsyncMock, MagicMock, patch

    worker = Worker()
    worker.start()
    time.sleep(0.2)

    config = _make_config()
    statuses = []
    worker.bridge.status_changed.connect(lambda s: statuses.append(s))
    call_count = 0

    def make_client(cfg):
        nonlocal call_count
        call_count += 1
        instance = MagicMock()
        instance.on_event = MagicMock()
        if call_count <= 2:
            instance.run = AsyncMock(side_effect=ConnectionError("disconnected"))
        else:
            instance.run = AsyncMock()
        return instance

    with patch("gui.worker.MicrophoneCapture") as MockMic, \
         patch("gui.worker.ASTClient", side_effect=make_client), \
         patch("gui.worker.asyncio.sleep", new_callable=AsyncMock):
        worker.start_session(config)
        _drain_events(qapp, 1.0)

    worker.stop_session()
    worker.quit()
    worker.wait(2000)

    assert SessionStatus.CONNECTED in statuses
    assert SessionStatus.RECONNECTING in statuses
    assert call_count == 3


def test_worker_reconnect_backoff(qapp):
    """Reconnect should use exponential backoff: 2s, 4s, 8s."""
    from unittest.mock import AsyncMock, MagicMock, patch

    worker = Worker()
    worker.start()
    time.sleep(0.2)

    config = _make_config()
    sleep_args = []

    async def mock_sleep(seconds):
        sleep_args.append(seconds)

    with patch("gui.worker.MicrophoneCapture") as MockMic, \
         patch("gui.worker.ASTClient") as MockClient, \
         patch("gui.worker.asyncio.sleep", side_effect=mock_sleep):
        MockClient.return_value.on_event = MagicMock()
        MockClient.return_value.run = AsyncMock(
            side_effect=ConnectionError("disconnected")
        )
        worker.start_session(config)
        _drain_events(qapp, 1.0)

    worker.stop_session()
    worker.quit()
    worker.wait(2000)

    # Verify backoff values [2, 4, 8] appear in order as a subsequence.
    # Other sleep calls (e.g., 0.1 from residual _mock_session tasks)
    # may be interspersed — we only care that 2→4→8 occurs in order.
    expected = [2, 4, 8]
    idx = 0
    for val in sleep_args:
        if idx < len(expected) and val == expected[idx]:
            idx += 1
    assert idx == len(expected), f"Backoff {expected} not found in order in: {sleep_args}"


def test_worker_reconnect_mic_stays_alive(qapp):
    """MicrophoneCapture should NOT be restarted during reconnection."""
    from unittest.mock import AsyncMock, MagicMock, patch

    worker = Worker()
    worker.start()
    time.sleep(0.2)

    config = _make_config()

    with patch("gui.worker.MicrophoneCapture") as MockMic, \
         patch("gui.worker.ASTClient") as MockClient, \
         patch("gui.worker.asyncio.sleep", new_callable=AsyncMock):
        MockClient.return_value.on_event = MagicMock()
        MockClient.return_value.run = AsyncMock(
            side_effect=ConnectionError("disconnected")
        )
        worker.start_session(config)
        _drain_events(qapp, 1.0)

        mock_mic = MockMic.return_value
        mock_mic.start.assert_called_once()
        # mic.stop() is expected in finally after session ends; what matters
        # is that start() was called only once (no restart during reconnect).

    worker.stop_session()
    worker.quit()
    worker.wait(2000)


def test_worker_catches_mic_device_error(qapp):
    """MicDeviceError from mic.start() should emit error_occurred and status_detail, no reconnect."""
    from unittest.mock import AsyncMock, MagicMock, patch
    from src.backends.base import MicDeviceError

    worker = Worker()
    worker.start()
    time.sleep(0.2)

    config = _make_config()
    errors = []
    details = []
    worker.bridge.error_occurred.connect(lambda e: errors.append(e))
    worker.bridge.status_detail.connect(lambda d: details.append(d))

    with patch("gui.worker.MicrophoneCapture") as MockMic, \
         patch("gui.worker.ASTClient") as MockClient:
        MockMic.return_value.start.side_effect = MicDeviceError("Invalid sample rate")
        worker.start_session(config, device_id="13")
        _drain_events(qapp, 0.5)

    worker.stop_session()
    worker.quit()
    worker.wait(2000)

    assert len(errors) >= 1
    assert "麦克风设备错误" in errors[0]
    assert any("麦克风设备错误" in d for d in details)
    MockClient.assert_not_called()


def test_worker_mock_mode_defaults_false(qapp):
    """Worker._mock_mode should default to False."""
    worker = Worker()
    assert worker._mock_mode is False


def test_worker_set_mock_mode(qapp):
    """set_mock_mode() should update the mock mode flag."""
    worker = Worker()
    assert worker._mock_mode is False
    worker.set_mock_mode(True)
    assert worker._mock_mode is True
    worker.set_mock_mode(False)
    assert worker._mock_mode is False



def test_worker_start_session_routes_to_mock_when_mock_mode(qapp):
    """When _mock_mode is True, start_session should call _mock_session."""
    worker = Worker()
    worker.start()
    time.sleep(0.2)

    config = _make_config()
    worker._mock_mode = True
    received = []
    worker.bridge.translation_subtitle.connect(
        lambda et, txt: received.append((et, txt))
    )

    worker.start_session(config)
    _drain_events(qapp, 1.5)

    worker.stop_session()
    worker.quit()
    worker.wait(2000)
    assert len(received) > 0


def test_worker_start_session_routes_to_real_when_not_mock_mode(qapp):
    """When _mock_mode is False, start_session should call _run_session."""
    from unittest.mock import AsyncMock, MagicMock, patch

    worker = Worker()
    worker.start()
    time.sleep(0.2)

    config = _make_config()

    with patch("gui.worker.MicrophoneCapture") as MockMic, \
         patch("gui.worker.ASTClient") as MockClient:
        MockClient.return_value.on_event = MagicMock()
        MockClient.return_value.run = AsyncMock()

        worker._mock_mode = False
        worker.start_session(config, device_id="0")
        _drain_events(qapp, 0.3)

        MockMic.assert_called_once_with(device_id="0")

    worker.stop_session()
    worker.quit()
    worker.wait(2000)


def test_worker_start_test_capture(qapp):
    """start_test_capture should create MicrophoneCapture with compute_level=True."""
    import time
    from unittest.mock import patch, MagicMock

    worker = Worker()
    worker.start()
    time.sleep(0.2)

    with patch("gui.worker.MicrophoneCapture") as MockMic:
        mock_mic = MockMic.return_value
        mock_mic.chunks.return_value = iter([])

        worker.start_test_capture(device_id="0")
        time.sleep(0.3)

        MockMic.assert_called_once_with(device_id="0")
        mock_mic.start.assert_called_once_with(compute_level=True, device_manager=None)

    worker.stop_test_capture()
    worker.quit()
    worker.wait(2000)


def test_worker_stop_test_capture_stops_mic(qapp):
    """stop_test_capture should stop the test capture mic."""
    import time
    from unittest.mock import patch

    worker = Worker()
    worker.start()
    time.sleep(0.2)

    with patch("gui.worker.MicrophoneCapture") as MockMic:
        mock_mic = MockMic.return_value
        mock_mic.chunks.return_value = iter([])

        worker.start_test_capture(device_id="0")
        time.sleep(0.3)

        worker.stop_test_capture()
        time.sleep(0.2)

        mock_mic.stop.assert_called()

    worker.quit()
    worker.wait(2000)
