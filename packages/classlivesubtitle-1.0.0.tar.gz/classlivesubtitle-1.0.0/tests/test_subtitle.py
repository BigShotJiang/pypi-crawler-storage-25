"""Tests for subtitle renderer."""
import pytest
from src.subtitle import SubtitleRenderer, format_session_summary


class TestSubtitleRenderer:
    def test_render_source_text(self, capsys):
        renderer = SubtitleRenderer()
        renderer.render_source("你好世界")
        captured = capsys.readouterr()
        assert "你好世界" in captured.out
        assert "原文" in captured.out

    def test_render_translation(self, capsys):
        renderer = SubtitleRenderer()
        renderer.render_translation("Hello world")
        captured = capsys.readouterr()
        assert "Hello world" in captured.out
        assert "译文" in captured.out

    def test_render_header(self, capsys):
        renderer = SubtitleRenderer()
        renderer.render_header(mode="s2s", source="en", target="zh")
        captured = capsys.readouterr()
        assert "s2s" in captured.out
        assert "en" in captured.out
        assert "zh" in captured.out


class TestFormatSessionSummary:
    def test_formats_duration_and_tokens(self):
        summary = format_session_summary(duration_sec=45.2, text_tokens=128)
        assert "45.2" in summary
        assert "128" in summary

    def test_handles_zero_tokens(self):
        summary = format_session_summary(duration_sec=10.0, text_tokens=0)
        assert "10.0" in summary
