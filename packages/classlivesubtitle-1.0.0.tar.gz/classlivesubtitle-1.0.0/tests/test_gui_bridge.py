"""Tests for gui.bridge — Qt Signal definitions and event routing."""

from gui.bridge import Bridge
from gui.status import SessionStatus
from src.protocol import EventType


def test_bridge_has_source_subtitle_signal(qapp):
    bridge = Bridge()
    assert hasattr(bridge, "source_subtitle")


def test_bridge_has_translation_subtitle_signal(qapp):
    bridge = Bridge()
    assert hasattr(bridge, "translation_subtitle")


def test_bridge_has_status_changed_signal(qapp):
    bridge = Bridge()
    assert hasattr(bridge, "status_changed")


def test_bridge_has_error_occurred_signal(qapp):
    bridge = Bridge()
    assert hasattr(bridge, "error_occurred")


def test_bridge_has_notification_signal(qapp):
    bridge = Bridge()
    assert hasattr(bridge, "notification")


def test_source_subtitle_signal_emits(qapp):
    bridge = Bridge()
    received = []
    bridge.source_subtitle.connect(lambda et, txt: received.append((et, txt)))
    bridge.source_subtitle.emit(EventType.SOURCE_SUBTITLE_START, "Hello")
    assert received == [(EventType.SOURCE_SUBTITLE_START, "Hello")]


def test_translation_subtitle_signal_emits(qapp):
    bridge = Bridge()
    received = []
    bridge.translation_subtitle.connect(lambda et, txt: received.append((et, txt)))
    bridge.translation_subtitle.emit(EventType.TRANSLATION_SUBTITLE_START, "你好")
    assert received == [(EventType.TRANSLATION_SUBTITLE_START, "你好")]


def test_status_changed_signal_emits(qapp):
    bridge = Bridge()
    received = []
    bridge.status_changed.connect(lambda s: received.append(s))
    bridge.status_changed.emit(SessionStatus.CONNECTED)
    assert received == [SessionStatus.CONNECTED]


def test_route_source_events(qapp):
    bridge = Bridge()
    received = []
    bridge.source_subtitle.connect(lambda et, txt: received.append(("src", et, txt)))
    bridge.route_event(EventType.SOURCE_SUBTITLE_START, "start text")
    bridge.route_event(EventType.SOURCE_SUBTITLE_RESPONSE, "response text")
    bridge.route_event(EventType.SOURCE_SUBTITLE_END, "end text")
    assert len(received) == 3
    assert received[0] == ("src", EventType.SOURCE_SUBTITLE_START, "start text")


def test_route_translation_events(qapp):
    bridge = Bridge()
    received = []
    bridge.translation_subtitle.connect(lambda et, txt: received.append(("tr", et, txt)))
    bridge.route_event(EventType.TRANSLATION_SUBTITLE_START, "翻译开始")
    bridge.route_event(EventType.TRANSLATION_SUBTITLE_RESPONSE, "翻译内容")
    bridge.route_event(EventType.TRANSLATION_SUBTITLE_END, "翻译结束")
    assert len(received) == 3


def test_route_status_events(qapp):
    bridge = Bridge()
    received = []
    bridge.status_changed.connect(lambda s: received.append(s))
    bridge.route_event(EventType.SESSION_STARTED, "")
    bridge.route_event(EventType.SESSION_FINISHED, "")
    bridge.route_event(EventType.SESSION_FAILED, "")
    assert received == [SessionStatus.CONNECTED, SessionStatus.DISCONNECTED, SessionStatus.DISCONNECTED]


def test_route_unknown_event_ignored(qapp):
    bridge = Bridge()
    bridge.route_event(999, "unknown")
    # Should not raise


def test_bridge_has_status_detail_signal(qapp):
    """Bridge must have a status_detail signal."""
    bridge = Bridge()
    assert hasattr(bridge, "status_detail")


def test_bridge_status_detail_signal_emits(qapp):
    """status_detail signal should emit strings."""
    bridge = Bridge()
    received = []
    bridge.status_detail.connect(lambda text: received.append(text))
    bridge.status_detail.emit("麦克风设备错误: test")
    assert received == ["麦克风设备错误: test"]


def test_bridge_has_audio_level_signal(qapp):
    """Bridge must have an audio_level signal."""
    bridge = Bridge()
    assert hasattr(bridge, "audio_level")


def test_bridge_audio_level_signal_emits(qapp):
    """audio_level signal should emit float values."""
    bridge = Bridge()
    received = []
    bridge.audio_level.connect(lambda level: received.append(level))
    bridge.audio_level.emit(0.75)
    assert received == [0.75]


def test_session_status_constants():
    """SessionStatus must expose connected/disconnected/reconnecting strings."""
    assert SessionStatus.CONNECTED == "connected"
    assert SessionStatus.DISCONNECTED == "disconnected"
    assert SessionStatus.RECONNECTING == "reconnecting"
