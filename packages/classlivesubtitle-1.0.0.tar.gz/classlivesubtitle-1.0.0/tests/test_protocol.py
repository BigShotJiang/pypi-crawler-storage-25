"""Tests for protocol module."""
import uuid
from src.protocol import (
    build_start_request,
    build_audio_request,
    build_finish_request,
    parse_response,
    EventType,
    _TranslateRequest,
    _TranslateResponse,
)


class TestEventType:
    def test_all_required_events_exist(self):
        assert EventType.START_SESSION == 100
        assert EventType.TASK_REQUEST == 200
        assert EventType.FINISH_SESSION == 102
        assert EventType.SESSION_STARTED == 150
        assert EventType.SOURCE_SUBTITLE_START == 650
        assert EventType.SOURCE_SUBTITLE_RESPONSE == 651
        assert EventType.SOURCE_SUBTITLE_END == 652
        assert EventType.TRANSLATION_SUBTITLE_START == 653
        assert EventType.TRANSLATION_SUBTITLE_RESPONSE == 654
        assert EventType.TRANSLATION_SUBTITLE_END == 655
        assert EventType.TTS_SENTENCE_START == 350
        assert EventType.TTS_RESPONSE == 352
        assert EventType.TTS_SENTENCE_END == 351
        assert EventType.SESSION_FINISHED == 152
        assert EventType.SESSION_FAILED == 153
        assert EventType.USAGE_RESPONSE == 154


class TestBuildStartRequest:
    def test_serializes_to_bytes(self):
        session_id = str(uuid.uuid4())
        data = build_start_request(
            session_id=session_id,
            mode="s2t",
            source_language="zh",
            target_language="en",
        )
        assert isinstance(data, bytes)
        assert len(data) > 0

    def test_roundtrip_start_session(self):
        session_id = str(uuid.uuid4())
        data = build_start_request(
            session_id=session_id,
            mode="s2s",
            source_language="en",
            target_language="zh",
        )
        req = _TranslateRequest()
        req.ParseFromString(data)
        assert req.event == 100
        assert req.request_meta.SessionID == session_id
        assert req.request.mode == "s2s"
        assert req.request.source_language == "en"
        assert req.request.target_language == "zh"
        assert req.source_audio.format == "wav"
        assert req.source_audio.rate == 16000
        assert req.source_audio.bits == 16
        assert req.source_audio.channel == 1


class TestBuildAudioRequest:
    def test_contains_audio_data(self):
        fake_audio = b"\x00\x01\x02\x03" * 320
        data = build_audio_request(fake_audio)
        req = _TranslateRequest()
        req.ParseFromString(data)
        assert req.event == 200
        assert req.source_audio.binary_data == fake_audio


class TestBuildFinishRequest:
    def test_finish_event(self):
        data = build_finish_request()
        req = _TranslateRequest()
        req.ParseFromString(data)
        assert req.event == 102


class TestParseResponse:
    def test_parses_session_started(self):
        resp = _TranslateResponse()
        resp.event = 150
        resp.response_meta.SessionID = "test-session"
        resp.response_meta.StatusCode = 20000000
        data = resp.SerializeToString()
        result = parse_response(data)
        assert result["event"] == 150
        assert result["session_id"] == "test-session"
        assert result["status_code"] == 20000000

    def test_parses_subtitle_text(self):
        resp = _TranslateResponse()
        resp.event = 651
        resp.text = "你好世界"
        resp.start_time = 100
        resp.end_time = 500
        data = resp.SerializeToString()
        result = parse_response(data)
        assert result["event"] == 651
        assert result["text"] == "你好世界"
        assert result["start_time"] == 100
        assert result["end_time"] == 500

    def test_parses_tts_audio(self):
        resp = _TranslateResponse()
        resp.event = 352
        resp.data = b"\xff\xfe\xfd\xfc"
        data = resp.SerializeToString()
        result = parse_response(data)
        assert result["event"] == 352
        assert result["data"] == b"\xff\xfe\xfd\xfc"
