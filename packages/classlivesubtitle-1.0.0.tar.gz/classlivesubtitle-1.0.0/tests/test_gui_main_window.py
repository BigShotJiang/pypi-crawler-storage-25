"""Tests for MainWindow — QWebEngineView container."""

import pytest
from gui.main_window import MainWindow


@pytest.fixture
def window(qapp):
    win = MainWindow()
    yield win
    win.close()


class TestMainWindow:
    def test_has_backend(self, window):
        assert window.backend is not None

    def test_has_web_view(self, window):
        from PySide6.QtWebEngineWidgets import QWebEngineView
        assert isinstance(window._view, QWebEngineView)

    def test_frameless(self, window):
        from PySide6.QtCore import Qt
        assert window.windowFlags() & Qt.WindowType.FramelessWindowHint

    def test_minimum_width_is_480(self, window):
        assert window.minimumWidth() == 480

    def test_backend_state_defaults(self, window):
        assert window.backend.state["language"] == "en"
        assert window.backend.state["font_size"] == 24

    def test_set_audio_level_delegates(self, window):
        received = []
        window.backend.level_updated.connect(lambda v: received.append(v))
        window.set_audio_level(0.5)
        assert received == [50]

    def test_set_running_delegates(self, window):
        received = []
        window.backend.running_changed.connect(lambda v: received.append(v))
        window.set_running(True)
        assert received == [True]

    def test_selected_device_id_delegates(self, window):
        window.backend.select_device("test_id")
        assert window.selected_device_id() == "test_id"

    def test_display_mode_delegates(self, window):
        window.backend.set_display_mode("dual")
        assert window.display_mode() == "dual"

    def test_font_size_delegates(self, window):
        window.backend.set_font_size(28)
        assert window.font_size() == 28

    def test_signals_exist(self, window):
        assert hasattr(window, "start_requested")
        assert hasattr(window, "stop_requested")
        assert hasattr(window, "config_changed")
        assert hasattr(window, "display_mode_changed")
        assert hasattr(window, "font_size_changed")
        assert hasattr(window, "style_preset_changed")
        assert hasattr(window, "device_disconnected")
        assert hasattr(window, "test_mic_requested")
