"""Tests for gui.app — QApplication entry point."""

import time
from unittest.mock import patch

from PySide6.QtWidgets import QApplication, QSystemTrayIcon

from gui.app import create_app
from gui.bridge import Bridge
from gui.main_window import MainWindow
from gui.overlay import OverlayWindow
from gui.status import SessionStatus
from gui.tray import TRAY_ICON_COLORS
from gui.worker import Worker


def _drain_events(app, duration):
    """Process Qt events for *duration* seconds."""
    deadline = time.monotonic() + duration
    while time.monotonic() < deadline:
        app.processEvents()
        time.sleep(0.05)


def test_returns_qapplication(qapp):
    """create_app should return the existing QApplication."""
    app = create_app()
    assert isinstance(app, QApplication)


def test_returns_existing_instance(qapp):
    """create_app should reuse the session-scoped QApplication."""
    app = create_app()
    assert app is qapp


def test_does_not_quit_on_last_window_close(qapp):
    """App must not quit when no windows are open (tray-only mode)."""
    app = create_app()
    assert app.quitOnLastWindowClosed() is False


def test_creates_exactly_one_tray_icon(qapp):
    """create_app should create exactly one tray icon (idempotent)."""
    create_app()
    create_app()
    assert len(qapp.findChildren(QSystemTrayIcon)) == 1


def test_create_app_creates_settings_panel(qapp):
    """create_app() should create a MainWindow."""
    create_app()
    assert isinstance(qapp._settings_panel, MainWindow)


def test_create_app_idempotent_settings(qapp):
    """create_app() should not create duplicate settings panels."""
    create_app()
    panel_before = qapp._settings_panel
    create_app()
    panel_after = qapp._settings_panel
    assert panel_before is panel_after


def test_create_app_creates_worker(qapp):
    """create_app() should create a Worker thread."""
    create_app()
    workers = qapp.findChildren(Worker)
    assert len(workers) >= 1


def test_create_app_creates_bridge(qapp):
    """create_app() should create a Bridge (owned by Worker)."""
    create_app()
    bridges = qapp.findChildren(Bridge)
    assert len(bridges) >= 1


def test_create_app_does_not_create_overlay(qapp):
    """create_app() should NOT create an OverlayWindow — deferred to CONNECTED."""
    if hasattr(qapp, "_overlay"):
        delattr(qapp, "_overlay")
    create_app()
    assert not hasattr(qapp, "_overlay")


def test_overlay_created_on_connected(qapp):
    """Overlay should be created when status changes to CONNECTED."""
    app = create_app()
    workers = app.findChildren(Worker)
    assert workers
    workers[0].bridge.status_changed.emit(SessionStatus.CONNECTED)
    _drain_events(qapp, 0.1)
    assert hasattr(app, "_overlay")
    assert isinstance(app._overlay, OverlayWindow)


def test_overlay_visible_after_first_connected(qapp):
    """Overlay must be visible and show waiting notification on first CONNECTED."""
    app = create_app()
    workers = app.findChildren(Worker)
    workers[0].bridge.status_changed.emit(SessionStatus.CONNECTED)
    _drain_events(qapp, 0.1)
    assert app._overlay.isVisible()
    assert "等待语音" in app._overlay._notification_label.text()


def test_overlay_reused_across_sessions(qapp):
    """Same overlay instance should be reused across CONNECTED/DISCONNECTED cycles."""
    app = create_app()
    workers = app.findChildren(Worker)
    bridge = workers[0].bridge
    bridge.status_changed.emit(SessionStatus.CONNECTED)
    _drain_events(qapp, 0.1)
    first_overlay = app._overlay
    bridge.status_changed.emit(SessionStatus.DISCONNECTED)
    _drain_events(qapp, 0.1)
    bridge.status_changed.emit(SessionStatus.CONNECTED)
    _drain_events(qapp, 0.1)
    assert app._overlay is first_overlay


def test_overlay_position_restored_on_creation(qapp):
    """Overlay should receive move() with persisted coordinates on creation."""
    from unittest.mock import patch
    if hasattr(qapp, "_overlay"):
        delattr(qapp, "_overlay")
    app = create_app()
    app._persistence.set("overlay_x", 42)
    app._persistence.set("overlay_y", 99)
    with patch("gui.overlay.OverlayWindow.move") as mock_move:
        workers = app.findChildren(Worker)
        workers[0].bridge.status_changed.emit(SessionStatus.CONNECTED)
        _drain_events(qapp, 0.1)
        mock_move.assert_any_call(42, 99)


# --- Task 5 wiring tests ---


def test_error_occurred_connected_to_overlay(qapp):
    """bridge.error_occurred should show notification on overlay."""
    app = create_app()
    workers = app.findChildren(Worker)
    assert workers
    workers[0].bridge.status_changed.emit(SessionStatus.CONNECTED)
    _drain_events(qapp, 0.1)
    assert hasattr(app, "_overlay")
    workers[0].bridge.error_occurred.emit("测试错误")
    _drain_events(qapp, 0.1)
    assert "测试错误" in app._overlay._notification_label.text()


def test_status_connected_updates_tray_icon(qapp):
    """status_changed('connected') should set tray icon to blue."""
    app = create_app()
    workers = app.findChildren(Worker)
    trays = app.findChildren(QSystemTrayIcon)
    assert workers and trays
    workers[0].bridge.status_changed.emit(SessionStatus.CONNECTED)
    _drain_events(qapp, 0.1)
    from PySide6.QtGui import QColor
    expected = QColor(TRAY_ICON_COLORS["connected"])
    pixel = trays[0].icon().pixmap(32, 32).toImage().pixelColor(26, 26)
    assert abs(pixel.red() - expected.red()) < 10


def test_status_reconnecting_updates_tray_icon(qapp):
    """status_changed('reconnecting') should set tray icon to yellow."""
    app = create_app()
    workers = app.findChildren(Worker)
    trays = app.findChildren(QSystemTrayIcon)
    assert workers and trays
    workers[0].bridge.status_changed.emit(SessionStatus.RECONNECTING)
    _drain_events(qapp, 0.1)
    from PySide6.QtGui import QColor
    expected = QColor(TRAY_ICON_COLORS["connecting"])
    pixel = trays[0].icon().pixmap(32, 32).toImage().pixelColor(26, 26)
    assert abs(pixel.green() - expected.green()) < 10


def test_toggle_overlay_visibility(qapp):
    """_toggle_overlay_visibility should toggle overlay visibility."""
    from gui.app import _toggle_overlay_visibility
    app = create_app()
    workers = app.findChildren(Worker)
    workers[0].bridge.status_changed.emit(SessionStatus.CONNECTED)
    _drain_events(qapp, 0.1)
    workers[0].bridge.status_changed.emit(SessionStatus.DISCONNECTED)
    _drain_events(qapp, 0.1)
    assert app._overlay.isHidden()
    _toggle_overlay_visibility(app)
    qapp.processEvents()
    assert app._overlay.isVisible()
    _toggle_overlay_visibility(app)
    qapp.processEvents()
    assert app._overlay.isHidden()


def test_config_change_triggers_restart_when_running(qapp):
    """Changing config during active session should call restart_session."""
    import asyncio
    from unittest.mock import MagicMock, patch as upatch
    from src.config import Config

    app = create_app()
    workers = app.findChildren(Worker)
    worker = workers[0]
    worker.start()
    time.sleep(0.2)

    config = Config(
        api_key="test-key",
        source_language="en",
        target_language="zh",
        mode="s2t",
    )
    restart_count = []

    original_restart = worker.restart_session
    def track_restart(cfg, device_id=None):
        restart_count.append(True)
        original_restart(cfg, device_id)
    worker.restart_session = track_restart

    async def _hang_forever(chunks):
        """Block until cancelled so the session stays 'running'."""
        try:
            await asyncio.Event().wait()
        except asyncio.CancelledError:
            pass

    with upatch("gui.worker.ASTClient") as MockClient, \
         upatch("gui.worker.MicrophoneCapture"):
        MockClient.return_value.on_event = MagicMock()
        MockClient.return_value.run = _hang_forever
        worker.start_session(config)
        _drain_events(qapp, 0.3)

        # Trigger config change via the settings panel signal
        app._settings_panel.config_changed.emit()

        _drain_events(qapp, 0.3)

    worker.stop_session()
    worker.quit()
    worker.wait(2000)
    assert len(restart_count) >= 1


def test_status_detail_connected_to_settings_panel(qapp):
    """bridge.status_detail should update settings panel via backend."""
    app = create_app()
    workers = app.findChildren(Worker)
    assert workers
    workers[0].bridge.status_detail.emit("测试状态详情")
    _drain_events(qapp, 0.1)
    # Backend receives the status update via set_status_detail
    # Check that the backend's status_updated signal was wired
    received = []
    app._settings_panel.backend.status_updated.connect(
        lambda s, d: received.append((s, d))
    )
    app._settings_panel.set_status_detail("测试状态详情")
    _drain_events(qapp, 0.1)
    assert any("测试状态详情" in d for s, d in received)


def test_main_installs_sigint_handler():
    """main() should call signal.signal with SIGINT."""
    import signal
    from unittest.mock import patch, MagicMock

    mock_app = MagicMock()
    mock_app.exec.return_value = 0

    with patch("gui.app.create_app", return_value=mock_app), \
         patch("signal.signal") as mock_sig, \
         patch("sys.exit"):
        from gui.__main__ import main
        main()

        sigint_calls = [c for c in mock_sig.call_args_list
                        if c.args[0] == signal.SIGINT]
        assert len(sigint_calls) == 1
        handler = sigint_calls[0].args[1]
        handler(signal.SIGINT, None)
        mock_app.quit.assert_called_once()


def test_sigint_handler_calls_quit(qapp):
    """SIGINT handler lambda should call app.quit()."""
    app = create_app()
    quit_calls = []
    app.quit = lambda: quit_calls.append(True)
    sigint_handler = lambda *_: app.quit()
    sigint_handler(None, None)
    assert len(quit_calls) == 1


def test_shutdown_closes_overlay_and_hides_tray(qapp):
    """_shutdown should close overlay and hide+detach tray icon."""
    from gui.app import _shutdown

    app = create_app()
    workers = app.findChildren(Worker)
    workers[0].bridge.status_changed.emit(SessionStatus.CONNECTED)
    _drain_events(qapp, 0.1)
    _shutdown(app)
    _drain_events(qapp, 0.3)

    assert hasattr(app, "_overlay")
    assert not app._overlay.isVisible()

    assert hasattr(app, "_tray")
    assert app._tray.parent() is None


def test_shutdown_worker_timeout_is_500ms(qapp):
    """Worker thread wait timeout should be 500ms after Ctrl+C, not 2000ms."""
    from gui.app import _shutdown_worker

    app = create_app()
    worker = app.findChildren(Worker)[0]
    worker._loop = None  # avoid call_soon_threadsafe on closed loop

    with patch.object(worker, "stop_session"), \
         patch.object(worker, "quit"), \
         patch.object(worker, "wait") as mock_wait:
        _shutdown_worker(worker)
        mock_wait.assert_called_once_with(500)


def test_shutdown_hides_tray_before_worker_stop(qapp):
    """Tray icon must be hidden before worker thread is stopped."""
    from gui.app import _shutdown

    app = create_app()
    workers = app.findChildren(Worker)
    workers[0].bridge.status_changed.emit(SessionStatus.CONNECTED)
    _drain_events(qapp, 0.1)

    call_order = []
    original_hide = app._tray.hide
    app._tray.hide = lambda: (call_order.append("tray_hide"), original_hide())

    with patch("gui.app._shutdown_worker", side_effect=lambda w: call_order.append("worker_stop")):
        _shutdown(app)

    _drain_events(qapp, 0.1)
    assert call_order.index("tray_hide") < call_order.index("worker_stop")


def test_shutdown_calls_process_events_after_tray_hide(qapp):
    """processEvents should be called after tray hide to flush UI updates."""
    from gui.app import _shutdown

    app = create_app()
    workers = app.findChildren(Worker)
    workers[0].bridge.status_changed.emit(SessionStatus.CONNECTED)
    _drain_events(qapp, 0.1)

    call_order = []
    original_hide = app._tray.hide
    app._tray.hide = lambda: (call_order.append("tray_hide"), original_hide())

    with patch.object(app, "processEvents", side_effect=lambda: call_order.append("processEvents")):
        _shutdown(app)

    assert call_order.index("tray_hide") < call_order.index("processEvents")


def test_no_overlay_widget_at_startup(qapp):
    """No overlay should exist after create_app — deferred to CONNECTED."""
    if hasattr(qapp, "_overlay"):
        delattr(qapp, "_overlay")
    app = create_app()
    assert not hasattr(app, "_overlay")


def test_debug_toggle_sets_worker_mock_mode(qapp):
    """Toggling 调试模式 should set worker._mock_mode and update tray icon."""
    app = create_app()
    workers = app.findChildren(Worker)
    assert workers
    worker = workers[0]
    assert worker._mock_mode is False

    # Find the debug action in tray menu
    trays = app.findChildren(QSystemTrayIcon)
    assert trays
    menu = trays[0].contextMenu()
    debug_action = None
    for action in menu.actions():
        if action.text() == "调试模式":
            debug_action = action
            break
    assert debug_action is not None

    # Toggle on (trigger() toggles checked state and emits signal)
    debug_action.trigger()
    _drain_events(qapp, 0.1)
    assert worker._mock_mode is True

    # Toggle off
    debug_action.trigger()
    _drain_events(qapp, 0.1)
    assert worker._mock_mode is False


# --- API key .env loading tests (Issue #22) ---


def test_start_button_disabled_when_no_api_key(qapp):
    """Backend api_key_status signal should emit False when no key."""
    if hasattr(qapp, "_api_key_checked"):
        delattr(qapp, "_api_key_checked")
    with patch("gui.main_window.load_api_key", return_value=None):
        app = create_app()
    received = []
    app._settings_panel.backend.api_key_status.connect(
        lambda v: received.append(v)
    )
    app._settings_panel.set_api_key_available(False)
    _drain_events(qapp, 0.1)
    assert False in received


def test_status_bar_shows_error_when_no_api_key(qapp):
    """Backend should receive api_key_status(False) when no key."""
    if hasattr(qapp, "_api_key_checked"):
        delattr(qapp, "_api_key_checked")
    with patch("gui.main_window.load_api_key", return_value=None):
        app = create_app()
    received = []
    app._settings_panel.backend.api_key_status.connect(
        lambda v: received.append(v)
    )
    # The create_app already called set_api_key_available(False)
    assert False in received or hasattr(app, "_api_key_checked")


def test_start_button_enabled_when_api_key_present(qapp):
    """Backend api_key_status signal should emit True when key present."""
    if hasattr(qapp, "_api_key_checked"):
        delattr(qapp, "_api_key_checked")
    app = create_app()
    received = []
    app._settings_panel.backend.api_key_status.connect(
        lambda v: received.append(v)
    )
    app._settings_panel.set_api_key_available(True)
    _drain_events(qapp, 0.1)
    assert True in received


def test_settings_panel_receives_device_manager(qapp):
    """create_app should set DeviceManager on settings panel."""
    app = create_app()
    # set_device_manager is a no-op in new MainWindow but should not raise
    assert hasattr(app, "_device_manager")


# --- Startup theme from persistence (Issue #36) ---


def test_create_app_applies_persisted_dark_theme(qapp, tmp_path):
    """When persistence has theme='dark', app should push dark theme to backend."""
    import json
    from gui.persistence import SettingsManager

    # Clean up previous test state
    for attr in ("_settings_panel", "_theme_applied", "_persistence",
                 "_theme_from_persistence", "_device_manager", "_shutdown_wired",
                 "_fonts_loaded"):
        if hasattr(qapp, attr):
            delattr(qapp, attr)

    # Write settings with dark theme
    path = tmp_path / "settings.json"
    path.write_text(json.dumps({"theme": "dark"}))

    with patch("gui.app.SettingsManager", return_value=SettingsManager(path=path)), \
         patch("gui.app.get_system_theme", return_value="light"):
        app = create_app()
        # Backend should have received the dark theme
        assert app._settings_panel.backend.state["theme"] == "dark"
