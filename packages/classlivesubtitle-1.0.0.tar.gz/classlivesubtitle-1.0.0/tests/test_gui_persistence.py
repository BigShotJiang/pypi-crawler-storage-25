"""Tests for gui.persistence — JSON settings persistence."""

import json
from pathlib import Path

from gui.persistence import SettingsManager


def test_settings_manager_creates_file_with_defaults(tmp_path):
    path = tmp_path / "settings.json"
    sm = SettingsManager(path=path)
    sm.save()
    assert path.exists()
    data = json.loads(path.read_text())
    assert data == SettingsManager.DEFAULTS


def test_settings_manager_load_existing(tmp_path):
    path = tmp_path / "settings.json"
    path.write_text(json.dumps({"device_id": "alsa_input.test", "font_size": 30}))
    sm = SettingsManager(path=path)
    assert sm.get("device_id") == "alsa_input.test"
    assert sm.get("font_size") == 30


def test_settings_manager_defaults_on_missing_file(tmp_path):
    path = tmp_path / "nonexistent" / "settings.json"
    sm = SettingsManager(path=path)
    assert sm.get("source_language") == "en"
    assert sm.get("font_size") == 24
    assert sm.get("device_id") is None


def test_settings_manager_set_saves_immediately(tmp_path):
    path = tmp_path / "settings.json"
    sm = SettingsManager(path=path)
    sm.set("font_size", 32)
    data = json.loads(path.read_text())
    assert data["font_size"] == 32


def test_settings_manager_set_overwrite(tmp_path):
    path = tmp_path / "settings.json"
    sm = SettingsManager(path=path)
    sm.set("font_size", 28)
    assert sm.get("font_size") == 28
    sm.set("font_size", 20)
    assert sm.get("font_size") == 20


def test_settings_manager_validate_device_valid(tmp_path):
    path = tmp_path / "settings.json"
    sm = SettingsManager(path=path)
    sm.set("device_id", "alsa_input.test")
    devices = [{"id": "alsa_input.test", "name": "Mic"}, {"id": "other", "name": "Other"}]
    assert sm.validate_device(devices) is True
    assert sm.get("device_id") == "alsa_input.test"


def test_settings_manager_validate_device_invalid_resets(tmp_path):
    path = tmp_path / "settings.json"
    sm = SettingsManager(path=path)
    sm.set("device_id", "nonexistent")
    devices = [{"id": "alsa_input.test", "name": "Mic"}]
    assert sm.validate_device(devices) is False
    assert sm.get("device_id") is None


def test_settings_manager_validate_device_none_passes(tmp_path):
    path = tmp_path / "settings.json"
    sm = SettingsManager(path=path)
    assert sm.validate_device([]) is True
    assert sm.get("device_id") is None


def test_settings_manager_round_trip(tmp_path):
    path = tmp_path / "settings.json"
    sm1 = SettingsManager(path=path)
    sm1.set("device_id", "alsa_input.test")
    sm1.set("source_language", "de")
    sm1.set("display_mode", "source_and_translation")
    sm1.set("font_size", 28)
    sm1.set("overlay_x", 200)
    sm1.set("overlay_y", 600)

    sm2 = SettingsManager(path=path)
    assert sm2.get("device_id") == "alsa_input.test"
    assert sm2.get("source_language") == "de"
    assert sm2.get("display_mode") == "source_and_translation"
    assert sm2.get("font_size") == 28
    assert sm2.get("overlay_x") == 200
    assert sm2.get("overlay_y") == 600


def test_settings_manager_handles_corrupt_json(tmp_path):
    path = tmp_path / "settings.json"
    path.write_text("{invalid json!!!")
    sm = SettingsManager(path=path)
    assert sm.get("font_size") == 24


def test_default_includes_style_preset():
    from gui.persistence import SettingsManager
    assert "style_preset" in SettingsManager.DEFAULTS
    assert SettingsManager.DEFAULTS["style_preset"] == "Transparent"


# --- Style preset migration tests (Issue #33) ---


def test_loads_old_preset_dark_migrates_to_new_name(tmp_path):
    path = tmp_path / "settings.json"
    path.write_text(json.dumps({"style_preset": "dark"}))
    sm = SettingsManager(path=path)
    assert sm.get("style_preset") == "Dark"
    saved = json.loads(path.read_text())
    assert saved["style_preset"] == "Dark"


def test_loads_old_preset_light_migrates_to_new_name(tmp_path):
    path = tmp_path / "settings.json"
    path.write_text(json.dumps({"style_preset": "light"}))
    sm = SettingsManager(path=path)
    assert sm.get("style_preset") == "Light"


def test_loads_old_preset_transparent_migrates_to_new_name(tmp_path):
    path = tmp_path / "settings.json"
    path.write_text(json.dumps({"style_preset": "transparent"}))
    sm = SettingsManager(path=path)
    assert sm.get("style_preset") == "Transparent"


def test_new_preset_names_loaded_unchanged(tmp_path):
    path = tmp_path / "settings.json"
    path.write_text(json.dumps({"style_preset": "Dark"}))
    sm = SettingsManager(path=path)
    assert sm.get("style_preset") == "Dark"


def test_default_includes_theme():
    assert "theme" in SettingsManager.DEFAULTS
    assert SettingsManager.DEFAULTS["theme"] == "auto"


# --- Device ID migration tests (Issue #28) ---


def test_loads_old_device_index_migrates_to_none(tmp_path):
    """Old device_index values should be dropped on load."""
    path = tmp_path / "settings.json"
    path.write_text(json.dumps({"device_index": 5, "source_language": "en"}))
    sm = SettingsManager(path=path)
    assert sm.get("device_id") is None
    assert sm.get("device_index") is None


def test_saves_device_id_as_string(tmp_path):
    """device_id should be stored as a string."""
    path = tmp_path / "settings.json"
    path.write_text("{}")
    sm = SettingsManager(path=path)
    sm.set("device_id", "alsa_input.pci-0000_00_1f.3.analog-stereo")
    saved = json.loads(path.read_text())
    assert saved["device_id"] == "alsa_input.pci-0000_00_1f.3.analog-stereo"
    assert "device_index" not in saved


def test_default_uses_device_id_not_index():
    """DEFAULTS should have device_id, not device_index."""
    assert "device_id" in SettingsManager.DEFAULTS
    assert "device_index" not in SettingsManager.DEFAULTS


# --- Theme persistence tests (Issue #36) ---


def test_theme_persistence_roundtrip(tmp_path):
    path = tmp_path / "settings.json"
    sm1 = SettingsManager(path=path)
    sm1.set("theme", "dark")
    sm2 = SettingsManager(path=path)
    assert sm2.get("theme") == "dark"


def test_theme_default_is_auto(tmp_path):
    path = tmp_path / "settings.json"
    sm = SettingsManager(path=path)
    assert sm.get("theme") == "auto"
