"""Tests for gui.tray — system tray icon creation."""

from PySide6.QtGui import QColor, QIcon
from PySide6.QtWidgets import QSystemTrayIcon

from gui.tray import create_tray_icon


def test_returns_system_tray_icon(qapp):
    """create_tray_icon should return a QSystemTrayIcon."""
    tray = create_tray_icon()
    assert isinstance(tray, QSystemTrayIcon)


def test_tray_icon_is_not_null(qapp):
    """Tray icon should have a non-null QIcon."""
    tray = create_tray_icon()
    icon = tray.icon()
    assert isinstance(icon, QIcon)
    assert not icon.isNull()


def test_tray_icon_pixmap_has_correct_size(qapp):
    """Generated icon pixmap should be 32x32."""
    tray = create_tray_icon()
    icon = tray.icon()
    pixmap = icon.pixmap(32, 32)
    assert not pixmap.isNull()
    assert pixmap.width() == 32
    assert pixmap.height() == 32


def test_tray_menu_has_correct_actions(qapp):
    """Tray context menu should have Start Translation, Settings..., and Exit."""
    tray = create_tray_icon()
    menu = tray.contextMenu()
    assert menu is not None
    texts = [a.text() for a in menu.actions() if a.text()]
    assert "Start Translation" in texts
    assert "Settings..." in texts
    assert "Exit" in texts


def test_tray_menu_exit_is_last(qapp):
    """Exit should remain the last menu action."""
    tray = create_tray_icon()
    actions = tray.contextMenu().actions()
    assert actions[-1].text() == "Exit"


def test_generate_icon_accepts_color_parameter(qapp):
    """_generate_icon should accept a color parameter and use it."""
    from gui.tray import _generate_icon
    icon = _generate_icon(color="#ffcc00")
    assert isinstance(icon, QIcon)
    assert not icon.isNull()


def test_generate_icon_uses_specified_color(qapp):
    """_generate_icon should paint the status dot with the specified color."""
    from gui.tray import _generate_icon
    icon_yellow = _generate_icon(color="#ffcc00")
    icon_gray = _generate_icon(color="#999999")
    pm_yellow = icon_yellow.pixmap(32, 32).toImage()
    pm_gray = icon_gray.pixmap(32, 32).toImage()
    assert pm_yellow.pixelColor(26, 26) != pm_gray.pixelColor(26, 26)


def test_update_tray_icon_changes_icon(qapp):
    """update_tray_icon should change the status dot color."""
    from gui.tray import _generate_icon, create_tray_icon, update_tray_icon
    tray = create_tray_icon()
    original = tray.icon()
    update_tray_icon(tray, "#ffcc00")
    assert tray.icon().pixmap(32, 32).toImage().pixelColor(26, 26) != original.pixmap(32, 32).toImage().pixelColor(26, 26)


def test_tray_icon_colors_defined():
    """TRAY_ICON_COLORS must define idle, connected, connecting."""
    from gui.tray import TRAY_ICON_COLORS
    assert "idle" in TRAY_ICON_COLORS
    assert "connected" in TRAY_ICON_COLORS
    assert "connecting" in TRAY_ICON_COLORS
    for color in TRAY_ICON_COLORS.values():
        QColor(color)


def test_tray_icon_default_is_idle_color(qapp):
    """Default tray icon status dot should use idle (gray) color."""
    from gui.tray import TRAY_ICON_COLORS, create_tray_icon
    tray = create_tray_icon()
    img = tray.icon().pixmap(32, 32).toImage()
    expected = QColor(TRAY_ICON_COLORS["idle"])
    pixel = img.pixelColor(26, 26)
    assert abs(pixel.red() - expected.red()) < 5
    assert abs(pixel.green() - expected.green()) < 5
    assert abs(pixel.blue() - expected.blue()) < 5


def test_tray_menu_has_show_hide_subtitle(qapp):
    """Tray menu should include a Show/Hide Subtitle action."""
    from gui.tray import create_tray_icon
    tray = create_tray_icon()
    texts = [a.text() for a in tray.contextMenu().actions() if a.text()]
    assert "Show/Hide Subtitle" in texts


def test_tray_menu_show_hide_before_exit(qapp):
    """Show/Hide Subtitle should appear before the separator and Exit."""
    from gui.tray import create_tray_icon
    tray = create_tray_icon()
    texts = [a.text() for a in tray.contextMenu().actions() if a.text()]
    assert texts.index("Show/Hide Subtitle") < texts.index("Exit")


def test_tray_menu_has_debug_toggle(qapp):
    """Tray menu should include a checkable '调试模式' action."""
    tray = create_tray_icon()
    texts = [a.text() for a in tray.contextMenu().actions() if a.text()]
    assert "调试模式" in texts


def test_tray_debug_toggle_is_checkable(qapp):
    """调试模式 menu action should be checkable."""
    tray = create_tray_icon()
    for action in tray.contextMenu().actions():
        if action.text() == "调试模式":
            assert action.isCheckable()
            return
    assert False, "调试模式 action not found"


def test_tray_icon_colors_has_debug():
    """TRAY_ICON_COLORS should define a 'debug' color."""
    from gui.tray import TRAY_ICON_COLORS
    assert "debug" in TRAY_ICON_COLORS
    QColor(TRAY_ICON_COLORS["debug"])
