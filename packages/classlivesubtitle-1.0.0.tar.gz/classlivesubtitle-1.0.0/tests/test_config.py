"""Tests for the config module."""

import os
import tempfile
from pathlib import Path
from unittest.mock import patch

import pytest

from src.config import Config, load_config


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _write_env_file(tmp_path: Path, content: str) -> Path:
    """Write content to a .env file in tmp_path and return its path."""
    env_file = tmp_path / ".env"
    env_file.write_text(content)
    return env_file


# ---------------------------------------------------------------------------
# test_default_values
# ---------------------------------------------------------------------------

def test_default_values():
    """Config should have correct defaults when constructed directly."""
    cfg = Config(api_key="test-key")

    assert cfg.api_key == "test-key"
    assert cfg.resource_id == "volc.service_type.10053"
    assert cfg.ws_url == "wss://openspeech.bytedance.com/api/v4/ast/v2/translate"
    assert cfg.mode == "s2t"
    assert cfg.source_language == "zh"
    assert cfg.target_language == "en"
    assert cfg.audio_file is None
    assert cfg.speaker_id is None
    assert cfg.speech_rate == 0


# ---------------------------------------------------------------------------
# test_loads_from_env_file
# ---------------------------------------------------------------------------

def test_loads_from_env_file(tmp_path):
    """load_config should read values from the specified .env file."""
    env_file = _write_env_file(
        tmp_path,
        "AST_API_KEY=from-env-key\n"
        "AST_RESOURCE_ID=custom-resource\n"
        "AST_SOURCE_LANGUAGE=ja\n"
        "AST_TARGET_LANGUAGE=en\n"
        "AST_MODE=s2s\n",
    )

    cfg = load_config(env_path=str(env_file))

    assert cfg.api_key == "from-env-key"
    assert cfg.resource_id == "custom-resource"
    assert cfg.source_language == "ja"
    assert cfg.target_language == "en"
    assert cfg.mode == "s2s"


# ---------------------------------------------------------------------------
# test_cli_args_override_env
# ---------------------------------------------------------------------------

def test_cli_args_override_env(tmp_path):
    """CLI overrides should take precedence over .env values."""
    env_file = _write_env_file(
        tmp_path,
        "AST_API_KEY=env-key\n"
        "AST_SOURCE_LANGUAGE=zh\n",
    )

    cfg = load_config(
        env_path=str(env_file),
        cli_overrides={
            "source_language": "de",
            "target_language": "fr",
        },
    )

    assert cfg.api_key == "env-key"  # from .env
    assert cfg.source_language == "de"  # overridden by CLI
    assert cfg.target_language == "fr"  # overridden by CLI


# ---------------------------------------------------------------------------
# test_raises_if_no_api_key
# ---------------------------------------------------------------------------

def test_raises_if_no_api_key(tmp_path):
    """load_config must raise ValueError when AST_API_KEY is absent."""
    env_file = _write_env_file(tmp_path, "AST_MODE=s2t\n")

    with pytest.raises(ValueError, match="AST_API_KEY"):
        load_config(env_path=str(env_file))


# ---------------------------------------------------------------------------
# test_validates_language_codes
# ---------------------------------------------------------------------------

def test_validates_language_codes(tmp_path):
    """All supported language codes should be accepted."""
    supported = {"zh", "en", "ja", "id", "es", "pt", "de", "fr", "zhen"}

    for lang in supported:
        env_file = _write_env_file(
            tmp_path,
            f"AST_API_KEY=key\nAST_SOURCE_LANGUAGE={lang}\n",
        )
        cfg = load_config(env_path=str(env_file))
        assert cfg.source_language == lang


# ---------------------------------------------------------------------------
# test_rejects_invalid_language
# ---------------------------------------------------------------------------

def test_rejects_invalid_language(tmp_path):
    """An unsupported language code should raise ValueError."""
    env_file = _write_env_file(
        tmp_path,
        "AST_API_KEY=key\nAST_SOURCE_LANGUAGE=xx\n",
    )

    with pytest.raises(ValueError, match="[Ll]anguage"):
        load_config(env_path=str(env_file))


# ---------------------------------------------------------------------------
# test_validates_mode
# ---------------------------------------------------------------------------

def test_validates_mode(tmp_path):
    """Both s2t and s2s modes should be accepted; others rejected."""
    # Valid modes
    for mode in ("s2t", "s2s"):
        env_file = _write_env_file(
            tmp_path,
            f"AST_API_KEY=key\nAST_MODE={mode}\n",
        )
        cfg = load_config(env_path=str(env_file))
        assert cfg.mode == mode

    # Invalid mode
    env_file = _write_env_file(
        tmp_path,
        "AST_API_KEY=key\nAST_MODE=invalid\n",
    )
    with pytest.raises(ValueError, match="[Mm]ode"):
        load_config(env_path=str(env_file))


# ---------------------------------------------------------------------------
# _resolve_env_path tests (Issue #27)
# ---------------------------------------------------------------------------

def test_resolve_env_path_returns_dotenv_when_not_frozen():
    """Non-frozen (development) should resolve to '.env'."""
    from src.config import _resolve_env_path
    with patch("src.config.sys") as mock_sys:
        if hasattr(mock_sys, 'frozen'):
            del mock_sys.frozen
        assert _resolve_env_path() == ".env"


def test_resolve_env_path_returns_exe_dir_when_frozen():
    """Frozen (PyInstaller) should resolve to .env next to executable."""
    from src.config import _resolve_env_path
    with patch("src.config.sys") as mock_sys:
        mock_sys.frozen = True
        mock_sys.executable = "/path/to/voice.exe"
        result = _resolve_env_path()
        assert result == "/path/to/.env"


def test_load_config_uses_resolved_path(tmp_path):
    """load_config() should find .env when no explicit path given."""
    from src.config import load_config
    env_file = tmp_path / ".env"
    env_file.write_text("AST_API_KEY=resolved-key\n")
    with patch("src.config._resolve_env_path", return_value=str(env_file)):
        cfg = load_config()
    assert cfg.api_key == "resolved-key"
