"""Tests for BackendAPI — Python↔JS bridge with state mirror."""

import json

import pytest

from gui.web_api import BackendAPI


@pytest.fixture
def api(qapp):
    api = BackendAPI()
    yield api


class TestStateMirror:
    def test_initial_state_defaults(self, api):
        assert api.state["device_id"] is None
        assert api.state["language"] == "en"
        assert api.state["font_size"] == 24
        assert api.state["display_mode"] == "translation_only"
        assert api.state["style_preset"] == "Transparent"
        assert api.state["theme"] == "light"

    def test_select_language_updates_state(self, api):
        api.select_language("ja")
        assert api.state["language"] == "ja"

    def test_select_device_updates_state(self, api):
        api.select_device("device_123")
        assert api.state["device_id"] == "device_123"

    def test_select_device_empty_string_sets_none(self, api):
        api.select_device("device_123")
        api.select_device("")
        assert api.state["device_id"] is None

    def test_set_font_size_updates_state(self, api):
        api.set_font_size(28)
        assert api.state["font_size"] == 28

    def test_set_display_mode_updates_state(self, api):
        api.set_display_mode("dual")
        assert api.state["display_mode"] == "dual"

    def test_select_style_preset_updates_state(self, api):
        api.select_style_preset("Dark")
        assert api.state["style_preset"] == "Dark"

    def test_set_theme_updates_state(self, api):
        api.set_theme("dark")
        assert api.state["theme"] == "dark"

    def test_state_property_returns_dict(self, api):
        assert isinstance(api.state, dict)


class TestSignals:
    def test_update_devices_emits_signal(self, api):
        received = []
        api.devices_updated.connect(lambda d: received.append(d))
        api.update_devices(json.dumps([{"id": "d1", "name": "Mic"}]))
        assert len(received) == 1
        assert json.loads(received[0]) == [{"id": "d1", "name": "Mic"}]

    def test_update_status_emits_signal(self, api):
        received = []
        api.status_updated.connect(lambda s, d: received.append((s, d)))
        api.update_status("connected", "Connected to server")
        assert received[0] == ("connected", "Connected to server")

    def test_update_level_emits_signal(self, api):
        received = []
        api.level_updated.connect(lambda v: received.append(v))
        api.update_level(72)
        assert received[0] == 72

    def test_update_running_emits_signal(self, api):
        received = []
        api.running_changed.connect(lambda v: received.append(v))
        api.update_running(True)
        assert received[0] is True

    def test_update_api_key_status_emits_signal(self, api):
        received = []
        api.api_key_status.connect(lambda v: received.append(v))
        api.update_api_key_status(True)
        assert received[0] is True

    def test_update_test_capture_error_emits_signal(self, api):
        received = []
        api.test_capture_error.connect(lambda e: received.append(e))
        api.update_test_capture_error("Device not found")
        assert received[0] == "Device not found"

    def test_update_notification_emits_signal(self, api):
        received = []
        api.notification.connect(lambda m: received.append(m))
        api.update_notification("Switched to default mic")
        assert received[0] == "Switched to default mic"

    def test_push_settings_emits_signal(self, api):
        received = []
        api.settings_loaded.connect(lambda s: received.append(s))
        api.push_settings({"language": "ja", "font_size": 20})
        assert len(received) == 1
        assert json.loads(received[0]) == {"language": "ja", "font_size": 20}

    def test_push_theme_emits_signal(self, api):
        received = []
        api.theme_changed.connect(lambda t: received.append(t))
        api.push_theme("dark")
        assert received[0] == "dark"

    def test_push_theme_updates_state(self, api):
        api.push_theme("dark")
        assert api.state["theme"] == "dark"


class TestSlotsExist:
    """Verify all JS-callable slots and signals exist."""

    def test_start_translation_signal(self, api):
        assert hasattr(api, "start_translation")

    def test_stop_translation_signal(self, api):
        assert hasattr(api, "stop_translation")

    def test_test_microphone_signal(self, api):
        assert hasattr(api, "test_microphone")

    def test_refresh_devices_slot(self, api):
        api.refresh_devices()

    def test_select_device_slot(self, api):
        api.select_device("dev1")

    def test_select_language_slot(self, api):
        api.select_language("en")

    def test_select_style_preset_slot(self, api):
        api.select_style_preset("Transparent")

    def test_set_font_size_slot(self, api):
        api.set_font_size(24)

    def test_set_display_mode_slot(self, api):
        api.set_display_mode("translation_only")

    def test_set_theme_slot(self, api):
        api.set_theme("light")

    def test_minimize_window_slot(self, api):
        api.minimize_window()

    def test_close_window_slot(self, api):
        api.close_window()

    def test_move_window_slot(self, api):
        api.move_window(10, 20)


class TestBuildConfig:
    def test_build_config_returns_config(self, api):
        from src.config import Config
        config = api.build_config("test_api_key")
        assert isinstance(config, Config)
        assert config.api_key == "test_api_key"
        assert config.source_language == "en"
        assert config.target_language == "zh"
        assert config.mode == "s2t"

    def test_build_config_uses_current_language(self, api):
        api.select_language("ja")
        config = api.build_config("key")
        assert config.source_language == "ja"


class TestSelectedDeviceId:
    def test_default_is_none(self, api):
        assert api.selected_device_id() is None

    def test_returns_selected_device(self, api):
        api.select_device("dev_abc")
        assert api.selected_device_id() == "dev_abc"

    def test_returns_none_after_deselect(self, api):
        api.select_device("dev_abc")
        api.select_device("")
        assert api.selected_device_id() is None
