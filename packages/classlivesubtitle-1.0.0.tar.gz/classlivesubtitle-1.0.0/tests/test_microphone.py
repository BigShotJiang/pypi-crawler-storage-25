# tests/test_microphone.py
"""Tests for the public microphone API."""
import asyncio
from unittest.mock import MagicMock, patch

import pytest

from src.backends.base import MicEvent, MicDeviceError, MicBackendError
from src.microphone import (
    MicrophoneCapture,
    list_audio_devices,
    calculate_chunk_size,
    CHUNK_DURATION_MS,
    SAMPLE_RATE,
    SAMPLE_WIDTH,
    CHANNELS,
)


class TestAudioChunkCalculation:
    def test_chunk_size_bytes(self):
        assert calculate_chunk_size() == 2560

    def test_chunk_size_calculation_formula(self):
        expected = int(SAMPLE_RATE * SAMPLE_WIDTH * CHANNELS * (CHUNK_DURATION_MS / 1000))
        assert calculate_chunk_size() == expected

    def test_constants(self):
        assert SAMPLE_RATE == 16000
        assert SAMPLE_WIDTH == 2
        assert CHANNELS == 1
        assert CHUNK_DURATION_MS == 80


class TestMicrophoneCaptureEvents:
    def test_on_event_registers_callback(self):
        mic = MicrophoneCapture()
        callback = MagicMock()
        mic.on_event(callback)
        assert mic._event_callback is callback

    def test_start_emits_started_event(self):
        mic = MicrophoneCapture()
        events = []
        mic.on_event(lambda e, p: events.append((e, p)))

        mock_backend = MagicMock()
        with patch("src.microphone.create_backend", return_value=mock_backend):
            mic.start()

        mock_backend.start.assert_called_once()
        # Simulate the backend calling our internal callback
        callback_arg = mock_backend.start.call_args[0][1]  # the MicCallback
        callback_arg(MicEvent.STARTED, {"device": "Test", "sample_rate": 16000})
        assert events[-1][0] == MicEvent.STARTED

    def test_stop_emits_stopped_event(self):
        mic = MicrophoneCapture()
        events = []
        mic.on_event(lambda e, p: events.append((e, p)))

        mock_backend = MagicMock()
        with patch("src.microphone.create_backend", return_value=mock_backend):
            mic.start()
            mic.stop()

        mock_backend.stop.assert_called_once()

    def test_start_raises_mic_device_error(self):
        mic = MicrophoneCapture()
        mock_backend = MagicMock()
        mock_backend.start.side_effect = MicDeviceError("No device")

        with patch("src.microphone.create_backend", return_value=mock_backend):
            with pytest.raises(MicDeviceError, match="No device"):
                mic.start()


class TestMicrophoneCaptureChunks:
    def test_chunks_yields_audio_data(self):
        mic = MicrophoneCapture()
        mock_backend = MagicMock()

        chunks = [b"chunk1", b"chunk2", None]

        def fake_read():
            return chunks.pop(0)

        mock_backend.read_chunk = fake_read

        with patch("src.microphone.create_backend", return_value=mock_backend):
            mic.start()

        # Replace internal backend for chunk reading
        mic._backend = mock_backend

        async def collect():
            result = []
            async for chunk in mic.chunks():
                result.append(chunk)
            return result

        collected = asyncio.run(collect())
        assert collected == [b"chunk1", b"chunk2"]


class TestMicrophoneCaptureDeviceId:
    def test_start_passes_none_to_backend_on_linux(self):
        mic = MicrophoneCapture(device_id="alsa_input.test")
        mock_backend = MagicMock()
        mock_dm = MagicMock()

        with patch("src.microphone.create_backend", return_value=mock_backend):
            with patch("src.microphone.sys") as mock_sys:
                mock_sys.platform = "linux"
                mic.start(compute_level=False, device_manager=mock_dm)

        mock_backend.start.assert_called_once()
        assert mock_backend.start.call_args[0][0] is None

    def test_start_passes_int_to_backend_on_windows(self):
        mic = MicrophoneCapture(device_id="5")
        mock_backend = MagicMock()
        mock_dm = MagicMock()

        with patch("src.microphone.create_backend", return_value=mock_backend):
            with patch("src.microphone.sys") as mock_sys:
                mock_sys.platform = "win32"
                mic.start(compute_level=False, device_manager=mock_dm)

        mock_backend.start.assert_called_once()
        assert mock_backend.start.call_args[0][0] == 5

    def test_start_calls_route_stream_on_linux(self):
        mic = MicrophoneCapture(device_id="alsa_input.test")
        mock_backend = MagicMock()
        mock_dm = MagicMock()

        with patch("src.microphone.create_backend", return_value=mock_backend):
            with patch("src.microphone.sys") as mock_sys:
                mock_sys.platform = "linux"
                mic.start(compute_level=False, device_manager=mock_dm)

        mock_dm.route_stream.assert_called_once_with("alsa_input.test")

    def test_start_with_none_device_id_uses_default(self):
        mic = MicrophoneCapture(device_id=None)
        mock_backend = MagicMock()
        mock_dm = MagicMock()

        with patch("src.microphone.create_backend", return_value=mock_backend):
            with patch("src.microphone.sys") as mock_sys:
                mock_sys.platform = "linux"
                mic.start(compute_level=False, device_manager=mock_dm)

        mock_backend.start.assert_called_once()
        assert mock_backend.start.call_args[0][0] is None
        mock_dm.route_stream.assert_called_once_with(None)

    def test_start_without_device_manager_works(self):
        mic = MicrophoneCapture(device_id=None)
        mock_backend = MagicMock()

        with patch("src.microphone.create_backend", return_value=mock_backend):
            mic.start(compute_level=False)

        mock_backend.start.assert_called_once()


class TestListAudioDevices:
    def test_delegates_to_backend(self):
        mock_devices = [{"index": 0, "name": "Mic", "sample_rate": 16000, "channels": 1}]
        with patch("src.microphone.create_backend") as mock_factory:
            mock_factory.return_value.list_devices.return_value = mock_devices
            devices = list_audio_devices()
            assert devices == mock_devices
