"""Tests for platform-aware DeviceManager."""
import sys
from unittest.mock import MagicMock, patch

import pytest

from src.audio.device_manager import (
    DeviceManager,
    LinuxDeviceManager,
    WindowsDeviceManager,
)


class TestDeviceManagerProtocol:
    def test_linux_device_manager_satisfies_protocol(self):
        assert isinstance(LinuxDeviceManager(), DeviceManager)

    def test_windows_device_manager_satisfies_protocol(self):
        assert isinstance(WindowsDeviceManager(), DeviceManager)


class TestLinuxDeviceManagerListDevices:
    def _make_source(self, index, name, description, channels=2):
        src = MagicMock()
        src.index = index
        src.name = name
        src.description = description
        src.channel_count = channels
        return src

    def test_returns_non_monitor_sources(self):
        sources = [
            self._make_source(68, "alsa_input.pci.audio", "Built-in Audio"),
            self._make_source(66, "alsa_output.hdmi.monitor", "Monitor of HDMI"),
            self._make_source(67, "alsa_output.audio.monitor", "Monitor of Audio"),
        ]
        mock_pulsectl = MagicMock()
        mock_pulse = MagicMock()
        mock_pulse.source_list.return_value = sources
        mock_pulsectl.Pulse.return_value.__enter__ = MagicMock(return_value=mock_pulse)
        mock_pulsectl.Pulse.return_value.__exit__ = MagicMock(return_value=False)

        dm = LinuxDeviceManager()
        with patch.dict(sys.modules, {"pulsectl": mock_pulsectl}):
            devices = dm.list_devices()

        assert len(devices) == 1
        assert devices[0]["id"] == "alsa_input.pci.audio"
        assert devices[0]["name"] == "Built-in Audio"

    def test_returns_empty_when_no_sources(self):
        mock_pulsectl = MagicMock()
        mock_pulse = MagicMock()
        mock_pulse.source_list.return_value = []
        mock_pulsectl.Pulse.return_value.__enter__ = MagicMock(return_value=mock_pulse)
        mock_pulsectl.Pulse.return_value.__exit__ = MagicMock(return_value=False)

        dm = LinuxDeviceManager()
        with patch.dict(sys.modules, {"pulsectl": mock_pulsectl}):
            assert dm.list_devices() == []

    def test_falls_back_when_no_pulsectl(self):
        dm = LinuxDeviceManager()
        with patch.dict(sys.modules, {"pulsectl": None}):
            with patch.object(dm, "_fallback_list_devices", return_value=[]) as mock_fb:
                devices = dm.list_devices()
        mock_fb.assert_called_once()

    def test_fallback_on_exception(self):
        mock_pulsectl = MagicMock()
        mock_pulsectl.Pulse.side_effect = Exception("PulseAudio not running")

        dm = LinuxDeviceManager()
        with patch.dict(sys.modules, {"pulsectl": mock_pulsectl}):
            with patch.object(dm, "_fallback_list_devices", return_value=[]) as mock_fb:
                devices = dm.list_devices()
        mock_fb.assert_called_once()


class TestLinuxDeviceManagerRouteStream:
    def _setup_pulsectl_mock(self):
        mock_pulsectl = MagicMock()
        mock_pulse = MagicMock()
        mock_pulsectl.Pulse.return_value.__enter__ = MagicMock(return_value=mock_pulse)
        mock_pulsectl.Pulse.return_value.__exit__ = MagicMock(return_value=False)
        return mock_pulsectl, mock_pulse

    def test_finds_and_moves_our_stream(self):
        mock_output = MagicMock()
        mock_output.index = 99
        mock_output.name = "ALSA Capture"
        mock_output.client = 10  # int, matching client.index

        mock_client = MagicMock()
        mock_client.index = 10
        mock_client.name = "PipeWire ALSA [python3.14]"
        mock_client.proplist = {"application.process.id": "12345"}

        mock_pulsectl, mock_pulse = self._setup_pulsectl_mock()
        mock_pulse.source_output_list.return_value = [mock_output]
        mock_pulse.client_list.return_value = [mock_client]
        mock_source = MagicMock()
        mock_source.index = 55
        mock_source.name = "alsa_input.test"
        mock_pulse.source_list.return_value = [mock_source]

        dm = LinuxDeviceManager()
        with patch.dict(sys.modules, {"pulsectl": mock_pulsectl}):
            with patch("src.audio.device_manager.os.getpid", return_value=12345):
                with patch("src.audio.device_manager.time"):
                    dm.route_stream("alsa_input.test")

        mock_pulse.source_output_move.assert_called_once_with(99, 55)

    def test_noop_when_device_id_is_none(self):
        dm = LinuxDeviceManager()
        dm.route_stream(None)  # Should not raise

    def test_skips_wrong_pid(self):
        mock_output = MagicMock()
        mock_output.index = 99
        mock_output.name = "ALSA Capture"
        mock_output.client = 10

        mock_client = MagicMock()
        mock_client.index = 10
        mock_client.name = "PipeWire ALSA [python3.14]"
        mock_client.proplist = {"application.process.id": "99999"}

        mock_pulsectl, mock_pulse = self._setup_pulsectl_mock()
        mock_pulse.source_output_list.return_value = [mock_output]
        mock_pulse.client_list.return_value = [mock_client]
        mock_source = MagicMock()
        mock_source.index = 55
        mock_source.name = "alsa_input.test"
        mock_pulse.source_list.return_value = [mock_source]

        dm = LinuxDeviceManager()
        with patch.dict(sys.modules, {"pulsectl": mock_pulsectl}):
            with patch("src.audio.device_manager.os.getpid", return_value=12345):
                with patch("src.audio.device_manager.time"):
                    dm.route_stream("alsa_input.test")

        mock_pulse.source_output_move.assert_not_called()


class TestLinuxDeviceManagerGetDefaultName:
    def _setup_pulsectl_mock(self, sources, default_source_name):
        mock_pulsectl = MagicMock()
        mock_pulse = MagicMock()
        mock_pulse.source_list.return_value = sources
        mock_server = MagicMock()
        mock_server.default_source_name = default_source_name
        mock_pulse.server_info.return_value = mock_server
        mock_pulsectl.Pulse.return_value.__enter__ = MagicMock(return_value=mock_pulse)
        mock_pulsectl.Pulse.return_value.__exit__ = MagicMock(return_value=False)
        return mock_pulsectl

    def _make_source(self, index, name, description, channels=2):
        src = MagicMock()
        src.index = index
        src.name = name
        src.description = description
        src.channel_count = channels
        return src

    def test_returns_default_source_description(self):
        sources = [
            self._make_source(0, "alsa_input.pci.audio", "Built-in Audio"),
            self._make_source(1, "alsa_input.usb.mic", "USB Microphone"),
        ]
        mock_pulsectl = self._setup_pulsectl_mock(sources, "alsa_input.pci.audio")

        dm = LinuxDeviceManager()
        with patch.dict(sys.modules, {"pulsectl": mock_pulsectl}):
            name = dm.get_default_device_name()

        assert name == "Built-in Audio"

    def test_returns_none_when_no_default(self):
        mock_pulsectl = self._setup_pulsectl_mock([], None)

        dm = LinuxDeviceManager()
        with patch.dict(sys.modules, {"pulsectl": mock_pulsectl}):
            name = dm.get_default_device_name()

        assert name is None

    def test_returns_none_on_exception(self):
        mock_pulsectl = MagicMock()
        mock_pulsectl.Pulse.side_effect = Exception("PulseAudio error")

        dm = LinuxDeviceManager()
        with patch.dict(sys.modules, {"pulsectl": mock_pulsectl}):
            name = dm.get_default_device_name()

        assert name is None

    def test_returns_none_when_no_pulsectl(self):
        dm = LinuxDeviceManager()
        with patch.dict(sys.modules, {"pulsectl": None}):
            name = dm.get_default_device_name()

        assert name is None


class TestWindowsDeviceManagerListDevices:
    def test_returns_string_ids(self):
        mock_sd = MagicMock()
        mock_sd.query_devices.return_value = [
            {"name": "Mic A", "max_input_channels": 2},
            {"name": "Speaker", "max_input_channels": 0},
            {"name": "Mic B", "max_input_channels": 1},
        ]
        dm = WindowsDeviceManager()
        with patch.dict(sys.modules, {"sounddevice": mock_sd}):
            devices = dm.list_devices()

        assert len(devices) == 2
        assert devices[0] == {"id": "0", "name": "Mic A", "channels": 2}
        assert devices[1] == {"id": "2", "name": "Mic B", "channels": 1}

    def test_route_stream_is_noop(self):
        dm = WindowsDeviceManager()
        dm.route_stream("5")  # Should not raise


class TestWindowsDeviceManagerGetDefaultName:
    def test_returns_default_device_name(self):
        mock_sd = MagicMock()
        mock_sd.default.device = [0, -1]
        mock_sd.query_devices.return_value = {"name": "Default Mic", "max_input_channels": 2}

        dm = WindowsDeviceManager()
        with patch.dict(sys.modules, {"sounddevice": mock_sd}):
            name = dm.get_default_device_name()

        assert name == "Default Mic"

    def test_returns_none_when_no_default(self):
        mock_sd = MagicMock()
        mock_sd.default.device = [-1, -1]

        dm = WindowsDeviceManager()
        with patch.dict(sys.modules, {"sounddevice": mock_sd}):
            name = dm.get_default_device_name()

        assert name is None

    def test_returns_none_on_exception(self):
        mock_sd = MagicMock()
        mock_sd.default.device = [0, -1]
        mock_sd.query_devices.side_effect = Exception("Device error")

        dm = WindowsDeviceManager()
        with patch.dict(sys.modules, {"sounddevice": mock_sd}):
            name = dm.get_default_device_name()

        assert name is None


class TestFactory:
    def test_linux_creates_linux_device_manager(self):
        with patch("src.audio.sys") as mock_sys:
            mock_sys.platform = "linux"
            with patch.dict(sys.modules, {"pulsectl": MagicMock()}):
                from src.audio import create_device_manager
                dm = create_device_manager()
                assert isinstance(dm, LinuxDeviceManager)

    def test_windows_creates_windows_device_manager(self):
        with patch("src.audio.sys") as mock_sys:
            mock_sys.platform = "win32"
            from src.audio import create_device_manager
            dm = create_device_manager()
            assert isinstance(dm, WindowsDeviceManager)
