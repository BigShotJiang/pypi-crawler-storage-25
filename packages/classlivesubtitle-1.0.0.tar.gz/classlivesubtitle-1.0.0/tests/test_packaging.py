"""Packaging validation tests — TDD RED phase for Slice 8 PyInstaller packaging.

Tests in TestSpecFile and TestBuildScript will FAIL until Tasks 3-4 create
the packaging artifacts. TestRuntimeImports and TestNoExternalResources test
existing code and should pass immediately.
"""

import ast
import subprocess
import sys
from importlib import import_module
from pathlib import Path

import pytest

PROJECT_ROOT = Path(__file__).resolve().parent.parent
SPEC_FILE = PROJECT_ROOT / "packaging" / "ClassLiveSubtitle.spec"
BUILD_SCRIPT = PROJECT_ROOT / "packaging" / "build.py"


# ---------------------------------------------------------------------------
# TestSpecFile — validates packaging/ClassLiveSubtitle.spec
# ---------------------------------------------------------------------------

class TestSpecFile:
    """Validate the PyInstaller spec file structure."""

    def test_spec_file_exists(self):
        assert SPEC_FILE.is_file(), f"Spec file not found: {SPEC_FILE}"

    def test_spec_file_is_valid_python(self):
        source = SPEC_FILE.read_text(encoding="utf-8")
        ast.parse(source)

    def test_spec_declares_onefile(self):
        source = SPEC_FILE.read_text(encoding="utf-8")
        tree = ast.parse(source)
        exe_names = [
            kw.value.value
            for node in ast.walk(tree)
            if isinstance(node, ast.Call)
            for kw in node.keywords
            if isinstance(kw, ast.keyword)
            and kw.arg == "name"
            and isinstance(kw.value, ast.Constant)
        ]
        assert "ClassLiveSubtitle" in exe_names, f"EXE name='ClassLiveSubtitle' not found; got: {exe_names}"

    def test_spec_entry_point_is_gui_main(self):
        source = SPEC_FILE.read_text(encoding="utf-8")
        assert "gui/__main__.py" in source or "gui" in source, (
            "Spec does not reference gui/__main__.py"
        )


# ---------------------------------------------------------------------------
# TestBuildScript — validates packaging/build.py (will FAIL until Task 4)
# ---------------------------------------------------------------------------

class TestBuildScript:
    """Validate the build script structure."""

    def test_build_script_exists(self):
        assert BUILD_SCRIPT.is_file(), f"Build script not found: {BUILD_SCRIPT}"

    def test_build_script_is_valid_python(self):
        source = BUILD_SCRIPT.read_text(encoding="utf-8")
        ast.parse(source)

    def test_build_script_references_spec_file(self):
        source = BUILD_SCRIPT.read_text(encoding="utf-8")
        assert "ClassLiveSubtitle.spec" in source, "Build script does not reference ClassLiveSubtitle.spec"


# ---------------------------------------------------------------------------
# TestRuntimeImports — verifies dependencies are importable (should PASS)
# ---------------------------------------------------------------------------

class TestRuntimeImports:
    """Verify all runtime dependencies can be imported."""

    @pytest.mark.parametrize(
        "module_name",
        [
            "PySide6.QtWidgets",
            "sounddevice",
            "pyaudio",
            "websockets",
            "google.protobuf",
        ],
    )
    def test_dependency_importable(self, module_name: str):
        try:
            result = subprocess.run(
                [sys.executable, "-c",
                 f"from importlib import import_module; import_module({module_name!r})"],
                timeout=10, capture_output=True, text=True,
            )
        except subprocess.TimeoutExpired:
            pytest.skip(f"{module_name} import timed out (audio subsystem unavailable)")
        assert result.returncode == 0, (
            f"Failed to import {module_name}:\n{result.stderr}"
        )


# ---------------------------------------------------------------------------
# TestNoExternalResources — verifies no external file dependencies (should PASS)
# ---------------------------------------------------------------------------

class TestNoExternalResources:
    """Verify the app does not depend on external resource files."""

    def test_tray_icon_is_programmatic(self, qapp):
        from gui.tray import create_tray_icon

        tray = create_tray_icon()
        assert tray is not None
        icon = tray.icon()
        assert not icon.isNull(), "Tray icon is null — should be a programmatic circle"

    def test_api_key_loading_available(self):
        """load_api_key() should be importable from gui.main_window."""
        from gui.main_window import load_api_key
        assert callable(load_api_key)
