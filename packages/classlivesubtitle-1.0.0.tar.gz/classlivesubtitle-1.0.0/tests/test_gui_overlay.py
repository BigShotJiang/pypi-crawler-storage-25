"""Tests for gui.overlay — transparent subtitle display window."""

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QLabel

from gui.overlay import OverlayWindow
from gui.status import SessionStatus
from src.protocol import EventType


def test_overlay_is_frameless(qapp):
    overlay = OverlayWindow()
    flags = overlay.windowFlags()
    assert flags & Qt.WindowType.FramelessWindowHint


def test_overlay_is_always_on_top(qapp):
    overlay = OverlayWindow()
    flags = overlay.windowFlags()
    assert flags & Qt.WindowType.WindowStaysOnTopHint


def test_overlay_has_translucent_background(qapp):
    overlay = OverlayWindow()
    assert overlay.testAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)


def test_overlay_is_click_through(qapp):
    overlay = OverlayWindow()
    assert overlay.testAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)


def test_overlay_subtitle_labels_exist(qapp):
    overlay = OverlayWindow()
    labels = overlay.findChildren(QLabel)
    assert len(labels) >= 2


def test_overlay_updates_translation_text(qapp):
    overlay = OverlayWindow()
    overlay.update_subtitle(EventType.TRANSLATION_SUBTITLE_START, "翻译开始")
    assert overlay.translation_text() == "翻译开始"


def test_overlay_updates_translation_streaming(qapp):
    overlay = OverlayWindow()
    overlay.update_subtitle(EventType.TRANSLATION_SUBTITLE_START, "正在翻译")
    assert overlay.translation_text() == "正在翻译"
    overlay.update_subtitle(EventType.TRANSLATION_SUBTITLE_RESPONSE, "正在翻译这句话")
    assert overlay.translation_text() == "正在翻译这句话"


def test_overlay_max_three_lines(qapp):
    overlay = OverlayWindow()
    assert overlay.max_lines() == 3


def test_overlay_translation_only_hides_source(qapp):
    overlay = OverlayWindow()
    overlay.set_display_mode("translation_only")
    overlay.update_subtitle(EventType.SOURCE_SUBTITLE_START, "Hello")
    assert overlay._source_label.text() == ""
    assert overlay._source_label.isHidden()


def test_overlay_source_and_translation_shows_source(qapp):
    overlay = OverlayWindow()
    overlay.show()
    overlay.set_display_mode("source_and_translation")
    overlay.update_subtitle(EventType.SOURCE_SUBTITLE_START, "Hello")
    assert overlay._source_label.text() == "Hello"
    assert overlay._source_label.isVisible()


def test_overlay_set_display_mode_hides_existing_source(qapp):
    overlay = OverlayWindow()
    overlay.show()
    overlay.set_display_mode("source_and_translation")
    overlay.update_subtitle(EventType.SOURCE_SUBTITLE_START, "Hello")
    assert overlay._source_label.isVisible()
    overlay.set_display_mode("translation_only")
    assert overlay._source_label.text() == ""
    assert overlay._source_label.isHidden()


def test_overlay_set_font_size_updates_labels(qapp):
    overlay = OverlayWindow()
    overlay.update_subtitle(EventType.TRANSLATION_SUBTITLE_START, "测试")
    overlay.set_font_size(30)
    assert "30px" in overlay._translation_label.styleSheet()


def test_overlay_set_font_size_updates_source_label(qapp):
    overlay = OverlayWindow()
    overlay.set_display_mode("source_and_translation")
    overlay.update_subtitle(EventType.SOURCE_SUBTITLE_START, "Hello")
    overlay.set_font_size(28)
    # Source label uses max(font_size - 4, 12), so 28 -> 24px
    assert "24px" in overlay._source_label.styleSheet()


def test_overlay_show_notification(qapp):
    overlay = OverlayWindow()
    overlay.show()
    overlay.show_notification("已切换到默认麦克风")
    assert overlay._notification_label.text() == "已切换到默认麦克风"
    assert overlay._notification_label.isVisible()


def test_overlay_notification_not_visible_by_default(qapp):
    overlay = OverlayWindow()
    assert overlay._notification_label.isHidden()


def test_overlay_subtitle_overrides_notification(qapp):
    overlay = OverlayWindow()
    overlay.show()
    overlay.show_notification("通知文字")
    assert overlay._notification_label.isVisible()
    overlay.update_subtitle(EventType.TRANSLATION_SUBTITLE_START, "真实字幕")
    assert overlay._notification_label.isHidden()


def test_overlay_drag_disabled_by_default(qapp):
    overlay = OverlayWindow()
    assert overlay.testAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)


def test_overlay_set_drag_enabled_disables_click_through(qapp):
    overlay = OverlayWindow()
    overlay.set_drag_enabled(True)
    assert not overlay.testAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)


def test_overlay_set_drag_false_restores_click_through(qapp):
    overlay = OverlayWindow()
    overlay.set_drag_enabled(True)
    overlay.set_drag_enabled(False)
    assert overlay.testAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)


def test_overlay_toggle_drag(qapp):
    """toggle_drag() should flip drag state."""
    overlay = OverlayWindow()
    assert overlay.testAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
    overlay.toggle_drag()
    assert not overlay.testAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
    overlay.toggle_drag()
    assert overlay.testAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)


def test_overlay_shows_on_connected(qapp):
    """Overlay should show itself when status becomes 'connected'."""
    overlay = OverlayWindow()
    overlay.hide()
    assert overlay.isHidden()
    overlay.on_status_changed(SessionStatus.CONNECTED)
    assert overlay.isVisible()


def test_overlay_hides_on_disconnected(qapp):
    """Overlay should hide itself when status becomes 'disconnected'."""
    overlay = OverlayWindow()
    overlay.show()
    assert overlay.isVisible()
    overlay.on_status_changed(SessionStatus.DISCONNECTED)
    assert overlay.isHidden()


def test_overlay_shows_waiting_notification_on_connected(qapp):
    """Connected status should show '等待语音...' notification."""
    overlay = OverlayWindow()
    overlay.hide()
    overlay.on_status_changed(SessionStatus.CONNECTED)
    assert overlay.isVisible()
    assert overlay._notification_label.text() == "等待语音..."
    assert overlay._notification_label.isVisible()


def test_overlay_apply_style_preset_dark(qapp):
    overlay = OverlayWindow()
    overlay.apply_style_preset("Dark")
    style = overlay._translation_label.styleSheet()
    assert "rgba(0,0,0,0.85)" in style
    assert "#ffffff" in style


def test_overlay_apply_style_preset_light(qapp):
    overlay = OverlayWindow()
    overlay.apply_style_preset("Light")
    style = overlay._translation_label.styleSheet()
    assert "rgba(255,255,255,0.9)" in style
    assert "#1a1a1a" in style


def test_overlay_apply_style_preset_transparent(qapp):
    overlay = OverlayWindow()
    overlay.apply_style_preset("Transparent")
    style = overlay._translation_label.styleSheet()
    assert "rgba(0,0,0,0.4)" in style
    assert "#ffffff" in style


def test_overlay_apply_style_preset_updates_both_labels(qapp):
    overlay = OverlayWindow()
    overlay.apply_style_preset("Dark")
    # _translation_label is the compat alias; check its stylesheet
    assert "rgba(0,0,0,0.85)" in overlay._translation_label.styleSheet()


def test_overlay_default_preset_is_transparent(qapp):
    overlay = OverlayWindow()
    style = overlay._translation_label.styleSheet()
    assert "rgba(0,0,0,0.4)" in style


def test_overlay_multi_line_subtitle_labels(qapp):
    """Multiple TRANSLATION_SUBTITLE_START events should create multiple labels."""
    overlay = OverlayWindow()
    overlay.update_subtitle(EventType.TRANSLATION_SUBTITLE_START, "第一行")
    overlay.update_subtitle(EventType.TRANSLATION_SUBTITLE_END, "第一行")
    overlay.update_subtitle(EventType.TRANSLATION_SUBTITLE_START, "第二行")
    assert len(overlay._subtitle_labels) == 2


def test_overlay_evicts_oldest_beyond_max(qapp):
    """More than 3 subtitle lines should evict the oldest."""
    overlay = OverlayWindow()
    for i in range(5):
        overlay.update_subtitle(EventType.TRANSLATION_SUBTITLE_START, f"Line {i}")
        overlay.update_subtitle(EventType.TRANSLATION_SUBTITLE_END, f"Line {i}")
    assert len(overlay._subtitle_labels) == 3


def test_overlay_disconnected_clears_subtitle_labels(qapp):
    """DISCONNECTED should clear all subtitle labels."""
    overlay = OverlayWindow()
    overlay.update_subtitle(EventType.TRANSLATION_SUBTITLE_START, "测试")
    assert len(overlay._subtitle_labels) == 1
    overlay.on_status_changed(SessionStatus.DISCONNECTED)
    assert len(overlay._subtitle_labels) == 0
