"""Async WebSocket client for Volcengine AST 2.0."""
from __future__ import annotations

import asyncio
import logging
import uuid
from typing import AsyncIterator, Callable, Optional

import websockets
from websockets import Headers

from src.config import Config
from src.protocol import (
    EventType,
    build_start_request,
    build_audio_request,
    build_finish_request,
    parse_response,
)

logger = logging.getLogger(__name__)

EventHandler = Callable[[dict], None]


class ASTClient:
    """Async WebSocket client for the AST 2.0 API."""

    def __init__(self, config: Config) -> None:
        self.config = config
        self._ws: Optional[websockets.WebSocketClientProtocol] = None
        self._session_id: Optional[str] = None
        self._running = False
        self._on_event: Optional[EventHandler] = None

    def on_event(self, handler: EventHandler) -> None:
        """Register a callback for server events."""
        self._on_event = handler

    def _build_headers(self, connection_id: str) -> Headers:
        """Build WebSocket HTTP headers with auth.

        Supports both new (X-Api-Key) and legacy (X-Api-App-Key + X-Api-Access-Key) auth.
        If access_key is set, use legacy mode; otherwise use the simplified new mode.
        """
        if self.config.access_key:
            return Headers({
                "X-Api-App-Key": self.config.api_key,
                "X-Api-Access-Key": self.config.access_key,
                "X-Api-Resource-Id": self.config.resource_id,
                "X-Api-Connect-Id": connection_id,
            })
        return Headers({
            "X-Api-Key": self.config.api_key,
            "X-Api-Resource-Id": self.config.resource_id,
            "X-Api-Connect-Id": connection_id,
        })

    async def connect(self) -> None:
        """Connect to AST WebSocket server."""
        connection_id = str(uuid.uuid4())
        headers = self._build_headers(connection_id)
        self._ws = await websockets.connect(
            self.config.ws_url,
            additional_headers=headers,
            max_size=100_000_000,
            ping_interval=None,
        )
        log_id = self._ws.response.headers.get("X-Tt-Logid", "unknown")
        logger.info("Connected to AST server (log_id=%s)", log_id)

    async def _send_start_session(self, session_id: str) -> None:
        """Send StartSession request."""
        self._session_id = session_id
        data = build_start_request(
            session_id=session_id,
            mode=self.config.mode,
            source_language=self.config.source_language,
            target_language=self.config.target_language,
            speaker_id=self.config.speaker_id,
            speech_rate=self.config.speech_rate,
        )
        await self._ws.send(data)
        logger.info("StartSession sent (session_id=%s)", session_id)

    async def _send_audio(self, chunk: bytes) -> None:
        """Send audio data chunk."""
        data = build_audio_request(chunk)
        await self._ws.send(data)

    async def _send_finish(self) -> None:
        """Send FinishSession request."""
        data = build_finish_request()
        await self._ws.send(data)
        logger.info("FinishSession sent")

    async def _receive_events(self) -> None:
        """Receive and dispatch server events until session ends."""
        while self._running:
            try:
                raw = await self._ws.recv()
                resp = parse_response(raw)

                if self._on_event:
                    self._on_event(resp)

                event = resp["event"]

                if event == EventType.SESSION_FAILED:
                    logger.error(
                        "Session failed: %s (status=%s)",
                        resp["message"],
                        resp["status_code"],
                    )
                    self._running = False
                elif event == EventType.SESSION_FINISHED:
                    logger.info("Session finished")
                    self._running = False
            except websockets.exceptions.ConnectionClosed:
                logger.info("Connection closed")
                self._running = False

    async def run(self, audio_source: AsyncIterator[bytes]) -> None:
        """Run the full session: connect, start, stream, finish, receive."""
        await self.connect()

        session_id = str(uuid.uuid4())
        await self._send_start_session(session_id)

        # Wait for SessionStarted
        raw = await self._ws.recv()
        resp = parse_response(raw)
        if resp["event"] != EventType.SESSION_STARTED:
            raise RuntimeError(
                f"Expected SessionStarted, got event={resp['event']} "
                f"message={resp['message']}"
            )
        logger.info("Session started (session_id=%s)", session_id)

        self._running = True

        async def send_audio():
            async for chunk in audio_source:
                if not self._running:
                    break
                await self._send_audio(chunk)
                await asyncio.sleep(0.08)
            if self._running:
                await self._send_finish()

        sender = asyncio.create_task(send_audio())
        await self._receive_events()
        await sender

        await self._ws.close()

    async def stop(self) -> None:
        """Gracefully stop the session."""
        self._running = False
        if self._ws:
            try:
                await self._send_finish()
            except Exception:
                pass
