"""Protocol wrapper for Volcengine AST 2.0 protobuf messages."""

import sys
from pathlib import Path

# Ensure project root is on sys.path so python_protogen imports resolve
_PROJECT_ROOT = str(Path(__file__).resolve().parent.parent)
sys.path.insert(0, _PROJECT_ROOT)

from python_protogen.common import events_pb2
from python_protogen.common import rpcmeta_pb2
from python_protogen.products.understanding.ast import ast_service_pb2
from python_protogen.products.understanding.base import au_base_pb2

# Re-export raw protobuf message classes for test access
_TranslateRequest = ast_service_pb2.TranslateRequest
_TranslateResponse = ast_service_pb2.TranslateResponse


class EventType:
    """Constants for AST 2.0 event type codes."""

    START_SESSION = 100
    FINISH_SESSION = 102
    SESSION_STARTED = 150
    SESSION_FINISHED = 152
    SESSION_FAILED = 153
    USAGE_RESPONSE = 154
    TASK_REQUEST = 200
    AUDIO_MUTED = 250
    TTS_SENTENCE_START = 350
    TTS_SENTENCE_END = 351
    TTS_RESPONSE = 352
    SOURCE_SUBTITLE_START = 650
    SOURCE_SUBTITLE_RESPONSE = 651
    SOURCE_SUBTITLE_END = 652
    TRANSLATION_SUBTITLE_START = 653
    TRANSLATION_SUBTITLE_RESPONSE = 654
    TRANSLATION_SUBTITLE_END = 655


def build_start_request(
    session_id: str,
    mode: str,
    source_language: str,
    target_language: str,
    speaker_id: str | None = None,
    speech_rate: int = 0,
    target_audio_format: str = "ogg_opus",
    target_audio_rate: int = 24000,
) -> bytes:
    """Create a StartSession TranslateRequest and return serialized bytes."""
    req = ast_service_pb2.TranslateRequest()
    req.event = EventType.START_SESSION
    req.request_meta.SessionID = session_id
    req.user.uid = "ast_cli"
    req.user.did = "ast_cli"
    req.source_audio.format = "wav"
    req.source_audio.codec = "raw"
    req.source_audio.rate = 16000
    req.source_audio.bits = 16
    req.source_audio.channel = 1
    req.target_audio.format = target_audio_format
    req.target_audio.rate = target_audio_rate
    req.request.mode = mode
    req.request.source_language = source_language
    req.request.target_language = target_language
    req.request.speech_rate = speech_rate
    if speaker_id is not None:
        req.request.speaker_id = speaker_id
    return req.SerializeToString()


def build_audio_request(audio_data: bytes) -> bytes:
    """Build a TaskRequest (event=200) with audio data."""
    req = ast_service_pb2.TranslateRequest()
    req.event = EventType.TASK_REQUEST
    req.source_audio.binary_data = audio_data
    return req.SerializeToString()


def build_finish_request() -> bytes:
    """Build a FinishSession request (event=102)."""
    req = ast_service_pb2.TranslateRequest()
    req.event = EventType.FINISH_SESSION
    return req.SerializeToString()


def parse_response(data: bytes) -> dict:
    """Parse a TranslateResponse from raw bytes into a dict."""
    resp = ast_service_pb2.TranslateResponse()
    resp.ParseFromString(data)
    return {
        "event": resp.event,
        "session_id": resp.response_meta.SessionID,
        "sequence": resp.response_meta.Sequence,
        "status_code": resp.response_meta.StatusCode,
        "message": resp.response_meta.Message,
        "text": resp.text,
        "data": resp.data,
        "start_time": resp.start_time,
        "end_time": resp.end_time,
        "spk_chg": resp.spk_chg,
        "muted_duration_ms": resp.muted_duration_ms,
    }
