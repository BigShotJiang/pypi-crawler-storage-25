# src/microphone.py
"""Real-time microphone audio capture for AST 2.0."""
from __future__ import annotations

import asyncio
import sys
from typing import AsyncIterator, Callable, Optional, TYPE_CHECKING

from src.backends import create_backend
from src.backends.base import (
    MicCallback,
    MicEvent,
    SAMPLE_RATE,
    SAMPLE_WIDTH,
    CHANNELS,
    CHUNK_DURATION_MS,
)

if TYPE_CHECKING:
    from src.audio.device_manager import DeviceManager


def calculate_chunk_size() -> int:
    """Calculate bytes per chunk for 80ms of 16kHz/16bit/mono audio."""
    return int(SAMPLE_RATE * SAMPLE_WIDTH * CHANNELS * (CHUNK_DURATION_MS / 1000))


def list_audio_devices() -> list[dict]:
    """List all available audio input devices."""
    backend = create_backend()
    return backend.list_devices()


class MicrophoneCapture:
    """Async microphone capture producing 80ms PCM chunks."""

    def __init__(self, device_id: Optional[str] = None) -> None:
        self._device_id = device_id
        self._backend = None
        self._event_callback: Optional[MicCallback] = None
        self._device_manager: Optional["DeviceManager"] = None

    def on_event(self, callback: MicCallback) -> None:
        """Register a callback for mic events."""
        self._event_callback = callback

    def _on_backend_event(self, event: str, payload: dict) -> None:
        if self._event_callback:
            self._event_callback(event, payload)

    def start(self, compute_level: bool = False, device_manager: Optional["DeviceManager"] = None) -> None:
        """Start capturing audio."""
        self._device_manager = device_manager
        self._backend = create_backend()

        backend_device = self._resolve_backend_device()
        self._backend.start(backend_device, self._on_backend_event, compute_level=compute_level)

        if device_manager is not None:
            device_manager.route_stream(self._device_id)

    def _resolve_backend_device(self) -> Optional[int]:
        """Convert device_id to PortAudio device index for the backend."""
        if self._device_id is None:
            return None
        if sys.platform == "linux":
            return None  # Always ALSA default — routing handles device selection
        try:
            return int(self._device_id)
        except (ValueError, TypeError):
            return None

    def stop(self) -> None:
        """Stop capturing audio."""
        if self._backend:
            self._backend.stop()
            self._backend = None

    async def chunks(self) -> AsyncIterator[bytes]:
        """Yield audio chunks as an async iterator."""
        loop = asyncio.get_running_loop()
        while self._backend:
            chunk = await loop.run_in_executor(None, self._backend.read_chunk)
            if chunk is None:
                break
            yield chunk
