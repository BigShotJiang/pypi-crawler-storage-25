"""Audio playback for TTS output in s2s mode."""
from __future__ import annotations

import asyncio
from typing import Optional

import pyaudio


class AudioPlayer:
    """Async audio player for TTS response data."""

    def __init__(self, rate: int = 24000, channels: int = 1) -> None:
        self._rate = rate
        self._channels = channels
        self._pa: Optional[pyaudio.PyAudio] = None
        self._stream: Optional[pyaudio.Stream] = None

    def start(self) -> None:
        """Start the audio player."""
        self._pa = pyaudio.PyAudio()
        self._stream = self._pa.open(
            format=pyaudio.paInt16,
            channels=self._channels,
            rate=self._rate,
            output=True,
        )

    def stop(self) -> None:
        """Stop the audio player."""
        if self._stream:
            self._stream.stop_stream()
            self._stream.close()
        if self._pa:
            self._pa.terminate()

    async def play(self, audio_data: bytes) -> None:
        """Queue audio data for playback."""
        if self._stream:
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(None, self._stream.write, audio_data)

    async def drain(self) -> None:
        """Wait for all queued audio to finish playing."""
        if self._stream:
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(None, self._stream.stop_stream)
