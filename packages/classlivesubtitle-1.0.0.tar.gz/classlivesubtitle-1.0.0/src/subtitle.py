"""Terminal subtitle renderer for live interpretation display."""
from __future__ import annotations

import sys

_GREEN = "\033[92m"
_CYAN = "\033[96m"
_YELLOW = "\033[93m"
_RESET = "\033[0m"
_BOLD = "\033[1m"
_DIM = "\033[2m"

_LABEL_SOURCE = "[原文]"
_LABEL_TARGET = "[译文]"
_SEP = "━" * 40
_HEADER = "\U0001f3a4  同声传译系统"


class SubtitleRenderer:
    """Renders real-time subtitles to the terminal."""

    def render_header(self, mode: str, source: str, target: str) -> None:
        """Print session header."""
        print(f"\n{_BOLD}{_HEADER}{_RESET}")
        print(_SEP)
        mode_desc = "语音→语音" if mode == "s2s" else "语音→文字"
        print(f" 模式: {mode} ({mode_desc}) | {source} → {target}")
        print(" 麦克风: 16kHz/16bit/单声道 | 80ms/包")
        print(" 按 Ctrl+C 停止")
        print(_SEP)
        sys.stdout.flush()

    def render_source(self, text: str) -> None:
        """Display source (original) text."""
        label = f"{_CYAN}{_LABEL_SOURCE}{_RESET}"
        print(f"{label} {text}")
        sys.stdout.flush()

    def render_translation(self, text: str) -> None:
        """Display translation text."""
        label = f"{_GREEN}{_LABEL_TARGET}{_RESET}"
        print(f"{label} {text}")
        sys.stdout.flush()

    def render_info(self, message: str) -> None:
        """Display info message."""
        print(f"{_DIM}{message}{_RESET}")
        sys.stdout.flush()

    def render_error(self, message: str) -> None:
        """Display error message."""
        print(f"{_YELLOW}⚠ {message}{_RESET}", file=sys.stderr)
        sys.stderr.flush()


def format_session_summary(duration_sec: float, text_tokens: int = 0) -> str:
    """Format session end summary string."""
    return (
        f"{_SEP}\n会话结束 | 时长: {duration_sec:.1f}s | Token: {text_tokens}\n{_SEP}"
    )
