"""Simultaneous interpretation CLI tool."""
