# src/backends/__init__.py
"""Microphone backend factory and device utilities."""
from __future__ import annotations

from src.backends.base import (
    MicBackend,
    MicCallback,
    MicDeviceError,
    MicBackendError,
    SAMPLE_RATE,
)

try:
    from src.backends.sounddevice_backend import SoundDeviceBackend
except ImportError:
    SoundDeviceBackend = None

try:
    from src.backends.pyaudio_backend import PyAudioBackend
except ImportError:
    PyAudioBackend = None


def create_backend() -> MicBackend:
    """Try sounddevice first, fall back to PyAudio, raise if neither works."""
    if SoundDeviceBackend is not None and SoundDeviceBackend.is_available():
        return SoundDeviceBackend()
    if PyAudioBackend is not None and PyAudioBackend.is_available():
        return PyAudioBackend()
    raise MicBackendError(
        "No audio backend available. Install sounddevice or pyaudio."
    )


def list_audio_devices() -> list[dict]:
    """List available audio input devices using the active backend."""
    backend = create_backend()
    return backend.list_devices()


__all__ = [
    "create_backend",
    "list_audio_devices",
    "MicBackend",
    "MicCallback",
    "MicDeviceError",
    "MicBackendError",
]
