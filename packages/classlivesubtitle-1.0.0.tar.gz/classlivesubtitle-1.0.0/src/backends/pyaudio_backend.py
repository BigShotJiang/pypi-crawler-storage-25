"""PyAudio-based microphone capture backend."""
from __future__ import annotations

import logging
import queue
from typing import Optional

from src.backends.base import (
    CHUNK_DURATION_MS,
    CHUNK_SIZE,
    CHANNELS,
    SAMPLE_RATE,
    MicCallback,
    MicDeviceError,
    MicEvent,
    resample_chunk,
)

logger = logging.getLogger(__name__)


class PyAudioBackend:
    """Microphone capture using PyAudio (fallback backend)."""

    def __init__(self) -> None:
        self._queue: queue.Queue[bytes | None] = queue.Queue()
        self._pa = None
        self._stream = None
        self._callback: Optional[MicCallback] = None
        self._compute_level: bool = False
        self._native_rate: int = SAMPLE_RATE

    @staticmethod
    def is_available() -> bool:
        try:
            import pyaudio  # noqa: F401
            return True
        except ImportError:
            return False

    def _audio_callback(self, in_data: bytes, frame_count: int, time_info, status) -> tuple:
        """PyAudio stream callback — pushes chunks to the queue."""
        data = in_data
        if self._native_rate != SAMPLE_RATE:
            data = resample_chunk(data, self._native_rate, SAMPLE_RATE)
        self._queue.put(data)
        if self._compute_level and self._callback:
            audio = memoryview(data).cast('h')
            peak = max(abs(s) for s in audio) / 32768.0
            self._callback(MicEvent.LEVEL, {"level": float(peak)})
        import pyaudio
        return (None, pyaudio.paContinue)

    def start(self, device_index: Optional[int], callback: MicCallback, compute_level: bool = False) -> None:
        """Start capturing audio."""
        import pyaudio

        self._compute_level = compute_level
        self._callback = callback
        self._native_rate = SAMPLE_RATE
        self._pa = pyaudio.PyAudio()
        frames_per_buffer = int(SAMPLE_RATE * CHUNK_DURATION_MS / 1000)

        # Fast path: try 16kHz first (works for PipeWire/PulseAudio/WASAPI)
        try:
            self._stream = self._pa.open(
                format=pyaudio.paInt16,
                channels=CHANNELS,
                rate=SAMPLE_RATE,
                input=True,
                input_device_index=device_index,
                frames_per_buffer=frames_per_buffer,
                stream_callback=self._audio_callback,
            )
            self._stream.start_stream()
            if device_index is not None:
                device_info = self._pa.get_device_info_by_index(device_index)
            else:
                default_idx = self._pa.get_default_input_device_info()["index"]
                device_info = self._pa.get_device_info_by_index(default_idx)
            callback(MicEvent.STARTED, {
                "device": device_info["name"],
                "sample_rate": SAMPLE_RATE,
            })
            return
        except (IOError, OSError):
            pass  # Fall through to native rate fallback

        # Fallback: open at device native rate and resample to 16kHz
        try:
            if device_index is not None:
                device_info = self._pa.get_device_info_by_index(device_index)
            else:
                default_idx = self._pa.get_default_input_device_info()["index"]
                device_info = self._pa.get_device_info_by_index(default_idx)
            native_rate = int(device_info["defaultSampleRate"])
            native_frames = int(native_rate * CHUNK_DURATION_MS / 1000)
            self._native_rate = native_rate

            logger.warning(
                "Device '%s': 16kHz not supported, using native %dHz with resampling",
                device_info["name"], native_rate,
            )

            self._stream = self._pa.open(
                format=pyaudio.paInt16,
                channels=CHANNELS,
                rate=native_rate,
                input=True,
                input_device_index=device_index,
                frames_per_buffer=native_frames,
                stream_callback=self._audio_callback,
            )
            self._stream.start_stream()
            callback(MicEvent.STARTED, {
                "device": device_info["name"],
                "sample_rate": native_rate,
            })
        except (IOError, OSError) as e:
            if self._pa:
                try:
                    devices = self.list_devices()
                except Exception:
                    devices = []
                self._pa.terminate()
            else:
                devices = []
            raise MicDeviceError(str(e), available_devices=devices) from e

    def stop(self) -> None:
        """Stop capturing audio."""
        if self._stream:
            self._stream.stop_stream()
            self._stream.close()
            self._stream = None
        if self._pa:
            self._pa.terminate()
            self._pa = None
        self._queue.put(None)  # Sentinel
        if self._callback:
            self._callback(MicEvent.STOPPED, {"reason": "user"})

    def read_chunk(self) -> Optional[bytes]:
        """Read one audio chunk (blocking). Returns None when stopped."""
        return self._queue.get()

    def list_devices(self) -> list[dict]:
        """List available audio input devices."""
        import pyaudio

        pa = pyaudio.PyAudio()
        devices = []
        for i in range(pa.get_device_count()):
            info = pa.get_device_info_by_index(i)
            if info["maxInputChannels"] > 0:
                devices.append({
                    "index": i,
                    "name": info["name"],
                    "sample_rate": int(info["defaultSampleRate"]),
                    "channels": info["maxInputChannels"],
                })
        pa.terminate()
        return devices

