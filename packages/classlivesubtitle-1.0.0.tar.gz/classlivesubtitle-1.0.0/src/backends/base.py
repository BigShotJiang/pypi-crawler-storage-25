"""Microphone backend protocol, events, and exceptions."""
from __future__ import annotations

import array
from typing import Callable, Optional, Protocol, runtime_checkable


# Audio format constants — shared across all backends.
SAMPLE_RATE = 16000
SAMPLE_WIDTH = 2   # 16-bit = 2 bytes
CHANNELS = 1
CHUNK_DURATION_MS = 80
CHUNK_SIZE = int(SAMPLE_RATE * SAMPLE_WIDTH * CHANNELS * (CHUNK_DURATION_MS / 1000))


def resample_chunk(data: bytes, native_rate: int, target_rate: int) -> bytes:
    """Resample 16-bit mono PCM from native_rate to target_rate.

    Integer ratios use decimation (take every Nth sample).
    Non-integer ratios use linear interpolation.
    """
    if native_rate == target_rate:
        return data

    samples = memoryview(data).cast('h')

    if native_rate % target_rate == 0:
        step = native_rate // target_rate
        return bytes(samples[::step])

    n_input = len(samples)
    ratio = native_rate / target_rate
    n_output = int(n_input / ratio)

    result = array.array('h', [0] * n_output)
    for i in range(n_output):
        src_pos = i * ratio
        idx = int(src_pos)
        frac = src_pos - idx
        if idx + 1 < n_input:
            result[i] = int(samples[idx] + frac * (samples[idx + 1] - samples[idx]))
        else:
            result[i] = samples[idx]

    return bytes(result)


class MicEvent:
    """Event names emitted by microphone backends."""
    STARTED = "started"
    STOPPED = "stopped"
    ERROR = "error"
    LEVEL = "level"


MicCallback = Callable[[str, dict], None]


@runtime_checkable
class MicBackend(Protocol):
    """Protocol for microphone capture backends."""

    def start(self, device_index: Optional[int], callback: MicCallback, compute_level: bool = False) -> None:
        """Start capturing audio from the given device."""
        ...

    def stop(self) -> None:
        """Stop capturing audio."""
        ...

    def read_chunk(self) -> Optional[bytes]:
        """Read one audio chunk (blocking). Returns None when stopped."""
        ...

    @staticmethod
    def is_available() -> bool:
        """Check if this backend's library is installed."""
        ...


class MicDeviceError(Exception):
    """Raised when a microphone device is unavailable or invalid."""

    def __init__(self, message: str, available_devices: Optional[list[dict]] = None) -> None:
        super().__init__(message)
        self.available_devices = available_devices or []


class MicBackendError(Exception):
    """Raised when no audio backend library is available."""
    pass
