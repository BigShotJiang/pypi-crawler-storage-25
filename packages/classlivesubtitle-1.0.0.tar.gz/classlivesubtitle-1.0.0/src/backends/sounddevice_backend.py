"""SoundDevice-based microphone capture backend."""
from __future__ import annotations

import logging
import queue
from typing import Optional

from src.backends.base import (
    CHUNK_DURATION_MS,
    CHUNK_SIZE,
    CHANNELS,
    SAMPLE_RATE,
    MicCallback,
    MicDeviceError,
    MicEvent,
    resample_chunk,
)

logger = logging.getLogger(__name__)


class SoundDeviceBackend:
    """Microphone capture using the sounddevice library (primary backend)."""

    def __init__(self) -> None:
        self._queue: queue.Queue[bytes | None] = queue.Queue()
        self._stream = None
        self._callback: Optional[MicCallback] = None
        self._compute_level: bool = False
        self._native_rate: int = SAMPLE_RATE

    @staticmethod
    def is_available() -> bool:
        try:
            import sounddevice  # noqa: F401
            return True
        except ImportError:
            return False

    def _audio_callback(self, indata: bytes, frames: int, time_info, status) -> None:
        """sounddevice RawInputStream callback — pushes PCM bytes to queue."""
        data = bytes(indata)
        if self._native_rate != SAMPLE_RATE:
            data = resample_chunk(data, self._native_rate, SAMPLE_RATE)
        self._queue.put(data)
        if self._compute_level and self._callback:
            audio = memoryview(data).cast('h')
            peak = max(abs(s) for s in audio) / 32768.0
            self._callback(MicEvent.LEVEL, {"level": float(peak)})

    def start(self, device_index: Optional[int], callback: MicCallback, compute_level: bool = False) -> None:
        """Start capturing audio."""
        import sounddevice as sd

        self._compute_level = compute_level
        self._callback = callback
        self._native_rate = SAMPLE_RATE
        frames_per_buffer = int(SAMPLE_RATE * CHUNK_DURATION_MS / 1000)

        # Fast path: try 16kHz first (works for PipeWire/PulseAudio/WASAPI)
        try:
            self._stream = sd.RawInputStream(
                device=device_index,
                channels=CHANNELS,
                samplerate=SAMPLE_RATE,
                dtype="int16",
                blocksize=frames_per_buffer,
                callback=self._audio_callback,
            )
            self._stream.start()
            dev_idx = device_index if device_index is not None else sd.default.device[0]
            device_info = sd.query_devices(dev_idx)
            callback(MicEvent.STARTED, {
                "device": device_info["name"],
                "sample_rate": SAMPLE_RATE,
            })
            return
        except Exception:
            pass  # Fall through to native rate fallback

        # Fallback: open at device native rate and resample to 16kHz
        try:
            dev_idx = device_index if device_index is not None else sd.default.device[0]
            device_info = sd.query_devices(dev_idx)
            native_rate = int(device_info["default_samplerate"])
            native_frames = int(native_rate * CHUNK_DURATION_MS / 1000)
            self._native_rate = native_rate

            logger.warning(
                "Device '%s': 16kHz not supported, using native %dHz with resampling",
                device_info["name"], native_rate,
            )

            self._stream = sd.RawInputStream(
                device=device_index,
                channels=CHANNELS,
                samplerate=native_rate,
                dtype="int16",
                blocksize=native_frames,
                callback=self._audio_callback,
            )
            self._stream.start()
            callback(MicEvent.STARTED, {
                "device": device_info["name"],
                "sample_rate": native_rate,
            })
        except Exception as e:
            try:
                devices = self.list_devices()
            except Exception:
                devices = []
            raise MicDeviceError(str(e), available_devices=devices) from e

    def stop(self) -> None:
        """Stop capturing audio."""
        if self._stream:
            self._stream.stop()
            self._stream.close()
            self._stream = None
        self._queue.put(None)  # Sentinel
        if self._callback:
            self._callback(MicEvent.STOPPED, {"reason": "user"})

    def read_chunk(self) -> Optional[bytes]:
        """Read one audio chunk (blocking). Returns None when stopped."""
        return self._queue.get()

    def list_devices(self) -> list[dict]:
        """List available audio input devices."""
        import sounddevice as sd

        devices = []
        for i, dev in enumerate(sd.query_devices()):
            if dev["max_input_channels"] > 0:
                devices.append({
                    "index": i,
                    "name": dev["name"],
                    "sample_rate": int(dev["default_samplerate"]),
                    "channels": dev["max_input_channels"],
                })
        return devices

