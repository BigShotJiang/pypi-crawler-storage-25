"""Platform-aware audio device management."""
import sys
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from src.audio.device_manager import DeviceManager


def create_device_manager() -> "DeviceManager":
    """Create the platform-appropriate DeviceManager."""
    if sys.platform == "linux":
        from src.audio.device_manager import LinuxDeviceManager
        return LinuxDeviceManager()
    else:
        from src.audio.device_manager import WindowsDeviceManager
        return WindowsDeviceManager()


def list_audio_devices():
    """Convenience wrapper — list devices via platform DeviceManager."""
    return create_device_manager().list_devices()
