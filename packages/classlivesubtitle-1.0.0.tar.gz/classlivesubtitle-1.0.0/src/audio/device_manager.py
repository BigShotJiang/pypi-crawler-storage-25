"""Platform-aware device enumeration and routing."""
from __future__ import annotations

import logging
import os
import time
from typing import Optional, Protocol, runtime_checkable

logger = logging.getLogger(__name__)


@runtime_checkable
class DeviceManager(Protocol):
    def list_devices(self) -> list[dict]:
        """List available audio input devices. Each has 'id' (str), 'name' (str), 'channels' (int)."""
        ...

    def route_stream(self, device_id: Optional[str]) -> None:
        """Route our capture stream to the selected device. No-op on non-Linux."""
        ...

    def on_devices_changed(self, callback) -> None:
        """Subscribe to device hotplug events."""
        ...

    def get_default_device_name(self) -> Optional[str]:
        """Return the human-readable name of the current system default input."""
        ...


class LinuxDeviceManager:
    """Device enumeration and routing using pulsectl (PipeWire/PulseAudio)."""

    def __init__(self) -> None:
        self._hotplug_callback = None
        self._hotplug_thread = None

    def list_devices(self) -> list[dict]:
        try:
            import pulsectl
        except ImportError:
            logger.warning("pulsectl not installed, falling back to sounddevice")
            return self._fallback_list_devices()

        try:
            with pulsectl.Pulse("device-enum") as pulse:
                devices = []
                for source in pulse.source_list():
                    if source.name.endswith(".monitor"):
                        continue
                    devices.append({
                        "id": source.name,
                        "name": source.description,
                        "channels": source.channel_count,
                    })
                return devices
        except Exception:
            logger.warning("pulsectl enumeration failed, falling back to sounddevice")
            return self._fallback_list_devices()

    def _fallback_list_devices(self) -> list[dict]:
        import sounddevice as sd
        devices = []
        for i, dev in enumerate(sd.query_devices()):
            if dev["max_input_channels"] > 0 and dev["hostapi"] == 0:
                devices.append({
                    "id": str(i),
                    "name": dev["name"],
                    "channels": dev["max_input_channels"],
                })
        return devices

    def route_stream(self, device_id: Optional[str]) -> None:
        if device_id is None:
            return

        try:
            import pulsectl
        except ImportError:
            return

        my_pid = os.getpid()
        target_index = self._find_source_index(device_id)
        if target_index is None:
            logger.warning("Target source '%s' not found, using system default", device_id)
            return

        for attempt in range(5):
            time.sleep(0.1)
            try:
                with pulsectl.Pulse("router") as pulse:
                    for output in pulse.source_output_list():
                        clients = {c.index: c for c in pulse.client_list()}
                        client_id = output.client if isinstance(output.client, int) else output.client.index
                        client = clients.get(client_id)
                        if not client:
                            continue
                        if "python" not in client.name:
                            continue
                        if "Capture" not in output.name:
                            continue
                        client_pid = int(client.proplist.get("application.process.id", 0))
                        if client_pid != my_pid:
                            continue
                        pulse.source_output_move(output.index, target_index)
                        return
            except Exception:
                pass
        logger.warning("Could not find capture stream for routing after 500ms")

    def _find_source_index(self, source_name: str) -> Optional[int]:
        try:
            import pulsectl
            with pulsectl.Pulse("source-lookup") as pulse:
                for source in pulse.source_list():
                    if source.name == source_name:
                        return source.index
        except Exception:
            pass
        return None

    def on_devices_changed(self, callback) -> None:
        from src.audio.hotplug import LinuxHotplugThread
        if self._hotplug_thread is not None:
            return
        self._hotplug_callback = callback
        self._hotplug_thread = LinuxHotplugThread(callback)
        self._hotplug_thread.daemon = True
        self._hotplug_thread.start()

    def get_default_device_name(self) -> Optional[str]:
        try:
            import pulsectl
        except ImportError:
            return None
        try:
            with pulsectl.Pulse("default-source") as pulse:
                default_name = pulse.server_info().default_source_name
                if not default_name:
                    return None
                for source in pulse.source_list():
                    if source.name == default_name:
                        return source.description
                return default_name
        except Exception:
            return None


class WindowsDeviceManager:
    """Device enumeration using sounddevice (WASAPI). No routing needed."""

    def __init__(self) -> None:
        self._poll_timer = None
        self._last_devices = None

    def list_devices(self) -> list[dict]:
        import sounddevice as sd
        devices = []
        for i, dev in enumerate(sd.query_devices()):
            if dev["max_input_channels"] > 0:
                devices.append({
                    "id": str(i),
                    "name": dev["name"],
                    "channels": dev["max_input_channels"],
                })
        return devices

    def route_stream(self, device_id: Optional[str]) -> None:
        pass

    def on_devices_changed(self, callback) -> None:
        from src.audio.hotplug import WindowsHotplugPoller
        if self._poll_timer is not None:
            return
        self._poll_timer = WindowsHotplugPoller(self, callback)
        self._poll_timer.start()

    def get_default_device_name(self) -> Optional[str]:
        import sounddevice as sd
        try:
            idx = sd.default.device[0]
            if idx < 0:
                return None
            dev = sd.query_devices(idx)
            return dev["name"]
        except Exception:
            return None
