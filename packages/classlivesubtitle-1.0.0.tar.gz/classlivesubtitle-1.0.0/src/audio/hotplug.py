"""Device hotplug detection for Linux (pulsectl) and Windows (polling)."""
from __future__ import annotations

import logging
import threading
from typing import Callable, Optional

logger = logging.getLogger(__name__)


class LinuxHotplugThread(threading.Thread):
    """Background thread monitoring PipeWire source changes via pulsectl."""

    def __init__(self, callback: Callable[[], None]) -> None:
        super().__init__(name="audio-hotplug")
        self._callback = callback

    def run(self) -> None:
        try:
            import pulsectl
        except ImportError:
            return
        try:
            with pulsectl.Pulse("hotplug") as pulse:
                pulse.event_mask_set("source")
                pulse.event_callback_set(self._on_event)
                pulse.event_listen()
        except Exception:
            logger.warning("Hotplug monitoring stopped unexpectedly")

    def _on_event(self, event):
        self._callback()


class WindowsHotplugPoller:
    """Periodic polling for device changes on Windows."""

    def __init__(self, device_manager, callback: Callable[[], None], interval: float = 5.0) -> None:
        self._dm = device_manager
        self._callback = callback
        self._interval = interval
        self._last_devices: Optional[list[dict]] = None
        self._timer: Optional[threading.Timer] = None

    def start(self) -> None:
        self._last_devices = self._dm.list_devices()
        self._schedule()

    def stop(self) -> None:
        if self._timer:
            self._timer.cancel()
            self._timer = None

    def _schedule(self) -> None:
        self._timer = threading.Timer(self._interval, self._poll_once)
        self._timer.daemon = True
        self._timer.start()

    def _poll_once(self) -> None:
        try:
            current = self._dm.list_devices()
            if current != self._last_devices:
                self._last_devices = current
                self._callback()
        except Exception:
            pass
        finally:
            self._schedule()
