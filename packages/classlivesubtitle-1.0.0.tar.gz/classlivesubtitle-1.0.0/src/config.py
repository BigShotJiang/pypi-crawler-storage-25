"""Configuration loading for the simultaneous interpretation CLI.

Reads settings from a .env file (via python-dotenv) and optional CLI
overrides, validates them, and returns a frozen ``Config`` dataclass.
"""

from __future__ import annotations

import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from dotenv import dotenv_values

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

VALID_LANGUAGES = {"zh", "en", "ja", "id", "es", "pt", "de", "fr", "zhen"}
VALID_MODES = {"s2t", "s2s"}


def _resolve_env_path() -> str:
    if getattr(sys, 'frozen', False):
        return str(Path(sys.executable).parent / ".env")
    return ".env"


# Mapping from .env variable names to Config field names.
_ENV_MAP = {
    "AST_API_KEY": "api_key",
    "AST_ACCESS_KEY": "access_key",
    "AST_RESOURCE_ID": "resource_id",
    "AST_WS_URL": "ws_url",
    "AST_MODE": "mode",
    "AST_SOURCE_LANGUAGE": "source_language",
    "AST_TARGET_LANGUAGE": "target_language",
    "AST_AUDIO_FILE": "audio_file",
    "AST_SPEAKER_ID": "speaker_id",
    "AST_SPEECH_RATE": "speech_rate",
}

# Fields whose values should be coerced to int.
_INT_FIELDS = {"speech_rate"}


# ---------------------------------------------------------------------------
# Config dataclass
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class Config:
    """Immutable configuration for the AST client."""

    api_key: str
    access_key: Optional[str] = None
    resource_id: str = "volc.service_type.10053"
    ws_url: str = (
        "wss://openspeech.bytedance.com/api/v4/ast/v2/translate"
    )
    mode: str = "s2t"
    source_language: str = "zh"
    target_language: str = "en"
    audio_file: Optional[str] = None
    speaker_id: Optional[str] = None
    speech_rate: int = 0


# ---------------------------------------------------------------------------
# Validation helpers
# ---------------------------------------------------------------------------

def _validate_language(value: str, field: str) -> None:
    if value not in VALID_LANGUAGES:
        raise ValueError(
            f"Invalid language code '{value}' for {field}. "
            f"Must be one of: {sorted(VALID_LANGUAGES)}"
        )


def _validate_mode(value: str) -> None:
    if value not in VALID_MODES:
        raise ValueError(
            f"Invalid mode '{value}'. Must be one of: {sorted(VALID_MODES)}"
        )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def load_config(env_path: str = None, cli_overrides: Optional[dict] = None) -> Config:
    """Load configuration from a .env file with optional CLI overrides.

    Parameters
    ----------
    env_path:
        Path to the ``.env`` file.  Passed straight to ``python-dotenv``.
    cli_overrides:
        Optional dict of field-name -> value pairs that take precedence over
        both the environment and the ``.env`` file.

    Returns
    -------
    Config
        A validated, frozen configuration object.

    Raises
    ------
    ValueError
        If ``AST_API_KEY`` is missing, or if language / mode values are
        invalid.
    """
    actual_path = env_path or _resolve_env_path()
    # Read .env file into a dict without polluting os.environ.
    env_values = dotenv_values(actual_path)

    # Build a dict of field values from the parsed .env content.
    values: dict = {}
    for env_key, field_name in _ENV_MAP.items():
        raw = env_values.get(env_key)
        if raw is not None:
            if field_name in _INT_FIELDS:
                values[field_name] = int(raw)
            else:
                values[field_name] = raw

    # CLI overrides win over everything else.
    if cli_overrides:
        values.update(cli_overrides)

    # api_key is required.
    if not values.get("api_key"):
        raise ValueError("AST_API_KEY is required but was not provided")

    # Build the Config so we can read values with defaults applied.
    cfg = Config(**values)

    # Validate.
    _validate_language(cfg.source_language, "source_language")
    _validate_language(cfg.target_language, "target_language")
    _validate_mode(cfg.mode)

    return cfg
