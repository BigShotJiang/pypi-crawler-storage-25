"""CLI argument parsing and main orchestration."""
from __future__ import annotations

import argparse
import asyncio
import logging
import time
from typing import Optional

from src.backends.base import MicDeviceError, MicBackendError
from src.client import ASTClient
from src.config import Config, load_config
from src.microphone import MicrophoneCapture, list_audio_devices, calculate_chunk_size
from src.player import AudioPlayer
from src.protocol import EventType
from src.subtitle import SubtitleRenderer, format_session_summary

logger = logging.getLogger(__name__)

LANGUAGES = ["zh", "en", "ja", "id", "es", "pt", "de", "fr", "zhen"]


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="同声传译 CLI - 实时语音翻译工具",
    )
    parser.add_argument(
        "--mode", choices=["s2t", "s2s"], default="s2t",
        help="模式: s2t=语音→文字, s2s=语音→语音 (default: s2t)",
    )
    parser.add_argument(
        "--source", default="zh", choices=LANGUAGES,
        help="源语言 (default: zh)",
    )
    parser.add_argument(
        "--target", default="en", choices=LANGUAGES,
        help="目标语言 (default: en)",
    )
    parser.add_argument(
        "--file", default=None,
        help="音频文件路径 (不传则用麦克风)",
    )
    parser.add_argument(
        "--device", type=int, default=None,
        help="麦克风设备索引号",
    )
    parser.add_argument(
        "--api-key", default=None,
        help="API Key (优先于 .env 文件)",
    )
    parser.add_argument(
        "--list-devices", action="store_true",
        help="列出可用的音频输入设备",
    )
    parser.add_argument(
        "--debug", action="store_true",
        help="启用调试日志",
    )
    return parser


async def _read_file_chunks(file_path: str):
    """Async generator that yields 80ms chunks from a WAV file."""
    chunk_size = calculate_chunk_size()
    with open(file_path, "rb") as f:
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            yield chunk


async def _run_session(config: Config, opts, renderer: SubtitleRenderer) -> None:
    """Run the full interpretation session."""
    client = ASTClient(config)
    player = AudioPlayer() if config.mode == "s2s" else None
    mic = None
    start_time = time.time()

    def handle_event(resp: dict):
        event = resp["event"]
        text = resp.get("text", "")

        if event == EventType.SOURCE_SUBTITLE_RESPONSE:
            if text:
                renderer.render_source(text)
        elif event == EventType.TRANSLATION_SUBTITLE_RESPONSE:
            if text:
                renderer.render_translation(text)
        elif event == EventType.TTS_RESPONSE:
            data = resp.get("data", b"")
            if data and player:
                asyncio.create_task(player.play(data))
        elif event == EventType.USAGE_RESPONSE:
            logger.debug("Usage: %s", resp)
        elif event == EventType.AUDIO_MUTED:
            ms = resp.get("muted_duration_ms", 0)
            renderer.render_info(f"静音 {ms}ms")
        elif event == EventType.SESSION_FAILED:
            renderer.render_error(f"会话失败: {resp.get('message', 'unknown')}")
        elif event == EventType.SESSION_FINISHED:
            elapsed = time.time() - start_time
            print(format_session_summary(duration_sec=elapsed))

    client.on_event(handle_event)

    if player:
        player.start()

    try:
        if config.audio_file:
            audio_source = _read_file_chunks(config.audio_file)
        else:
            mic = MicrophoneCapture(device_index=opts.device)
            try:
                mic.start()
            except (MicDeviceError, MicBackendError) as e:
                renderer.render_error(f"麦克风错误: {e}")
                if isinstance(e, MicDeviceError) and e.available_devices:
                    print("  可用设备:")
                    for d in e.available_devices:
                        print(f"    [{d['index']}] {d['name']} ({d['sample_rate']}Hz)")
                    print("  请使用 --device <编号> 指定设备")
                return
            audio_source = mic.chunks()

        await client.run(audio_source)
    except KeyboardInterrupt:
        renderer.render_info("\n正在结束会话...")
        await client.stop()
    except Exception as e:
        renderer.render_error(f"连接失败: {e}")
        logger.exception("Session error")
    finally:
        if mic:
            mic.stop()
        if player:
            player.stop()
        elapsed = time.time() - start_time
        print(format_session_summary(duration_sec=elapsed))


def main(args: Optional[list[str]] = None) -> int:
    """Main entry point."""
    parser = build_parser()
    opts = parser.parse_args(args)

    if opts.debug:
        logging.basicConfig(level=logging.DEBUG)
    else:
        logging.basicConfig(level=logging.INFO)

    if opts.list_devices:
        devices = list_audio_devices()
        print("可用音频输入设备:")
        for d in devices:
            print(f"  [{d['index']}] {d['name']} ({d['sample_rate']}Hz)")
        return 0

    cli_overrides = {
        "mode": opts.mode,
        "source_language": opts.source,
        "target_language": opts.target,
    }
    if opts.api_key:
        cli_overrides["api_key"] = opts.api_key
    if opts.file:
        cli_overrides["audio_file"] = opts.file

    config = load_config(cli_overrides=cli_overrides)

    renderer = SubtitleRenderer()
    renderer.render_header(
        mode=config.mode,
        source=config.source_language,
        target=config.target_language,
    )

    asyncio.run(_run_session(config, opts, renderer))
    return 0
