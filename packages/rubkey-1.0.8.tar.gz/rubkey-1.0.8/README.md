# Rubkey - Rubika Bot API Library

> **Official Rubika Channel:** [@library_rubkey](https://rubika.ir/library_rubkey)

Rubika Bot API library - Simple and powerful bot framework for Rubika messenger

## Source Code

For source code of the Rubkey library, visit the GitHub page:

[https://github.com/codetansarian/Source-code-of-the-Rubkey-library](https://github.com/codetansarian/Source-code-of-the-Rubkey-library)

## Features

- Send text messages with Chat Keypad and Inline Keypad
- Send polls
- Send files (image, video, file, voice, music, gif)
- Chat Keypad with button types: Simple, AskMyPhoneNumber, Textbox, File, GalleryImage, GalleryVideo, CameraImage, CameraVideo, Audio, RecordAudio, Barcode
- Inline Keypad with auto-updating data (counter, stats, etc.)
- Inline Keypad with advanced buttons: Selection, NumberPicker, StringPicker, Link, Barcode, Textbox
- Textbox button with SingleLine/MultiLine and String/Number keypad
- Markdown parse mode: Bold, Italic, Underline, Strike, Spoiler, Quote, Link
- Metadata system for text formatting (Bold, Italic, Underline, Strike, Spoiler, Mono, Pre, Link, Mention, Quote)
- Admin system with ADMIN_ID and ADMIN_PASSWORD
- Admin-specific commands, buttons, and keypads
- Ban system with ban/unban users
- Edit and delete messages
- Edit message with Inline Keypad update
- Edit and remove Chat Keypad
- Forward messages
- Message handlers for commands, buttons, and all messages
- Command and message filters with regex
- Rate limiting to prevent spam
- Cache system for faster responses
- Error handling with automatic retry (exponential backoff)
- Analytics for tracking user behavior
- Auto-delete messages with rules
- Session management with auto offset saving
- User session storage (JSON)
- SQLite database for messages and users
- Async bot support (asyncio + aiohttp)
- Webhook support (aiohttp async server)
- Contact and file receiving from users
- Built-in user counter (total_users, user_ids)
- Group support with GroupBot and GroupHandlers
- Group admin system (first on start, first N users)
- Group auto-delete with admin bypass
- Group-specific commands, messages, and buttons
- Group data storage
- Get group info (title, chat_id, type)
- Channel support with ChannelBot and ChannelHandlers
- Channel commands, messages, and data storage
- Get channel info (title, chat_id, type, username)
- Plugin system with auto-loading and reloading
- QR/Barcode scanning

## Methods

- `send_message(chat_id, text, keypad=None, inline_keypad=None, reply_to=None, metadata=None, parse_mode=None)` — Send text message
- `edit_message(chat_id, message_id, text, inline_keypad=None, metadata=None, parse_mode=None)` — Edit message
- `delete_message(chat_id, message_id)` — Delete message
- `send_poll(chat_id, question, options)` — Send poll
- `forward_message(from_chat_id, to_chat_id, message_id)` — Forward message
- `get_chat(chat_id)` — Get chat information
- `get_me()` — Get bot information
- `remove_keypad(chat_id)` — Remove Chat Keypad
- `edit_chat_keypad(chat_id, keypad)` — Edit Chat Keypad
- `set_commands(commands)` — Set bot commands
- `delete_commands()` — Delete all commands
- `get_updates(limit=10)` — Get updates
- `poll_updates(limit=10, sleep=1)` — Continuous updates generator
- `run()` — Start bot polling

## Markdown Parse Mode

- `**text**` — Bold
- `*text*` — Italic
- `__text__` — Underline
- `~~text~~` — Strike
- `||text||` — Spoiler
- `> text` — Quote
- `[text](url)` — Link

Usage: `bot.send_message(chat_id, "**Bold** *Italic*", parse_mode="Markdown")`

## Metadata System

- `Metadata()` — Create metadata object
- `metadata.add_part(MetadataPart(type, from_index, length, **kwargs))` — Add metadata part
- Types: Bold, Italic, Underline, Strike, Spoiler, Mono, Pre, Link, Mention, Quote

## Auto-Delete System

- `set_auto_delete(rules)` — Set auto-delete rules (list of words/patterns)
- `admins_can_bypass_delete` — Admins bypass auto-delete

## Webhook

- `set_webhook(url)` — Set webhook URL
- `delete_webhook()` — Delete webhook
- `get_webhook_info()` — Get webhook information
- `WebhookServer(bot, host="0.0.0.0", port=5000)` — Create aiohttp webhook server
- `server.run()` — Start webhook server
- `server.run_in_thread()` — Start webhook server in background thread

## Ban System

- `ban_user(user_id)` — Ban a user
- `unban_user(user_id)` — Unban a user
- `admin_ban(msg, user_id)` — Ban user by admin only
- `banned_users` — Set of banned user IDs

## Analytics

- `get_analytics(user_id=None)` — Get analytics for a user or all users
- `set_rate_limit(max_per_second=5, window=1)` — Set rate limit
- `set_cache_ttl(ttl)` — Set cache TTL in seconds

## File Methods (SendFile)

- `SendFile(bot)` — Create file sender
- `sendfile.request_send_file(file_type="Image")` — Request upload URL
- `sendfile.upload_file(upload_url, file_path)` — Upload file to server
- `sendfile.send_file(chat_id, file_id, text="")` — Send file to chat

## Handlers

- `@bot.command("name", pattern=None)` — Handle specific command with optional regex
- `@bot.on_message(pattern=None)` — Handle all messages with optional regex
- `@bot.on_button("button_id")` — Handle button clicks (Chat Keypad)

## Filters

- `Filters.command("name")` — Filter by command
- `Filters.text("text")` — Filter by text
- `Filters.regex(pattern)` — Filter by regex
- `Filters.chat_type("private/group/channel")` — Filter by chat type
- `Filters.has_file()` — Filter messages with file
- `Filters.has_contact()` — Filter messages with contact
- `Filters.has_button("id")` — Filter by button ID
- `Filters.is_admin()` — Filter by admin status
- `Filters.and_filter(...)` / `Filters.or_filter(...)` / `Filters.not_filter(...)` — Combine filters

## Middleware

- `bot.add_middleware(func)` — Add middleware function
- `MiddlewareManager()` — Create middleware manager

## Router

- `Router()` — Create router
- `router.command("name", filters=...)` — Add command with filters
- `router.on_message(filters=...)` — Add message handler with filters
- `router.on_button("id", filters=...)` — Add button handler with filters
- `bot.include_router(router)` — Include router in bot

## Admin System

- `bot.ADMIN_ID` — Set admin by sender_id or chat_id
- `bot.ADMIN_PASSWORD` — Set admin by password
- `@bot.admin_command("name")` — Admin-only command
- `@bot.admin_on_message()` — Handle all admin messages
- `@bot.admin_on_button("button_id")` — Handle admin button clicks

## Group System

- `GroupBot(token, session_file=None)` — Create group-compatible bot
- `bot.set_group_handlers(handlers)` — Set group handlers
- `bot.get_group_info(chat_id)` — Get group info (title, chat_id, type)
- `bot.set_group_admin(group_id, user_id)` — Set group admin
- `bot.first_admin_on_start` — First user to /start becomes admin
- `bot.first_n_admins` — Number of first users to become admins
- `bot.no_admin_mode` — Disable admin system
- `GroupHandlers()` — Create group handlers

### Group Handlers

- `handlers.command("name", group_only=True)` — Command for group or both
- `handlers.on_message(group_only=True)` — Message handler for group or both
- `handlers.on_button("button_id", group_only=True)` — Button handler for group or both
- `handlers.set_data(group_id, key, value)` — Store group-specific data
- `handlers.get_data(group_id, key, default=None)` — Get group-specific data

### group_info Object

- `group_info['title']` — Group title
- `group_info['chat_id']` — Group ID
- `group_info['type']` — Chat type (Group)
- `group_info` is `None` in private chat

## Channel System

- `ChannelBot(token, session_file=None)` — Create channel-compatible bot
- `bot.set_channel_handlers(handlers)` — Set channel handlers
- `bot.get_channel_info(chat_id)` — Get channel info (title, chat_id, type, username)
- `bot.send_to_channel(channel_id, text)` — Send message to channel
- `bot.edit_in_channel(channel_id, message_id, text)` — Edit message in channel
- `bot.delete_in_channel(channel_id, message_id)` — Delete message in channel
- `bot.forward_to_channel(from_chat_id, channel_id, message_id)` — Forward to channel
- `bot.send_poll_to_channel(channel_id, question, options)` — Send poll to channel
- `ChannelHandlers()` — Create channel handlers

### Channel Handlers

- `handlers.command("name")` — Channel command
- `handlers.on_message()` — Channel message handler
- `handlers.set_data(channel_id, key, value)` — Store channel data
- `handlers.get_data(channel_id, key, default=None)` — Get channel data

### channel_info Object

- `channel_info['title']` — Channel title
- `channel_info['chat_id']` — Channel ID
- `channel_info['type']` — Chat type (Channel)
- `channel_info['username']` — Channel username

## Session

- `Session(session_file="session.json")` — Create session storage
- `session.set(user_id, key, value)` — Store user data
- `session.get(user_id, key, default=None)` — Get user data
- `session.delete(user_id, key=None)` — Delete user data
- `session.clear()` — Clear all session data

## Database (SQLite)

- `Database(db_path="rubkey.db")` — Create database connection
- `database.init()` — Initialize database tables
- `database.save_message(message_id, chat_id, sender_id, text, time)` — Save message
- `database.save_user(user_id, first_name, last_name, username, phone)` — Save user
- `database.get_messages(chat_id=None, limit=50)` — Get messages
- `database.get_user(user_id)` — Get user information

## Plugin System

- `PluginLoader(bot, plugin_dir="plugins")` — Create plugin loader
- `loader.load_all()` — Load all plugins from directory
- `loader.reload_all()` — Reload all plugins
- `Plugin(info)` — Create plugin
- `PluginInfo(name, version, author, description)` — Plugin information

### Plugin Methods

- `@plugin.command("name", pattern=None)` — Plugin command
- `@plugin.on_message(pattern=None)` — Plugin message handler
- `@plugin.on_button("button_id")` — Plugin button handler
- `@plugin.admin_command("name")` — Plugin admin command
- `@plugin.admin_on_message()` — Plugin admin message handler
- `@plugin.admin_on_button("button_id")` — Plugin admin button handler

## Async Bot

- `AsyncBot(token, session_file=None)` — Create async bot
- `await bot.run()` — Start async bot polling
- `await bot.send_message(chat_id, text, ...)` — Send message async
- `@bot.command("name")` — Handle command async
- `@bot.on_message()` — Handle messages async

## Keypad Classes

- `Keypad(resize=True, one_time=False)` — Create Chat Keypad
- `keypad.add_row(*buttons)` — Add button row
- `KeyButton(button_id, text, button_type="Simple")` — Create Chat Keypad button
- `TextboxButton(button_id, text, type_line="SingleLine", type_keypad="String", place_holder="", title="")` — Create Textbox button
- `FileButton(button_id, text, file_type="File")` — Create file picker button
- `BarcodeButton(button_id, text)` — Create barcode scanner button
- `InlineKeypad()` — Create Inline Keypad
- `inline_keypad.add_row(*buttons)` — Add button row
- `InlineButton(button_id, text, button_type="Simple")` — Create Inline Keypad button

## Advanced Inline Buttons

- `SelectionButton(button_id, text, selection_id, items, is_multi_selection=False, columns_count="1", title="")` — Selection list
- `NumberPickerButton(button_id, text, min_value, max_value, default_value=None, title="")` — Number picker
- `StringPickerButton(button_id, text, items, default_value=None, title="")` — String picker
- `LinkButton(button_id, text, link_url)` — Link button
- `BarcodeInlineButton(button_id, text)` — Barcode scanner (inline)
- `TextboxInlineButton(button_id, text, type_line="SingleLine", type_keypad="String", place_holder="", title="")` — Textbox (inline)

## Message Object

- `msg.text` — Message text
- `msg.chat_id` — Chat ID
- `msg.message_id` — Message ID
- `msg.sender_id` — Sender ID
- `msg.time` — Message time
- `msg.is_edited` — Edit status
- `msg.button_id` — Clicked button ID
- `msg.contact` — Contact information
- `msg.file` — File information (file_id, file_name, size)
- `msg.poll` — Poll information
- `msg.aux_data` — Auxiliary data
- `msg.reply_to_message_id` — Reply message ID
- `msg.reply(text, keypad=None, inline_keypad=None, metadata=None, parse_mode=None)` — Reply to message
- `msg.edit(text, inline_keypad=None, metadata=None, parse_mode=None)` — Edit message
- `msg.delete()` — Delete message