class MiddlewareManager:
    def __init__(self):
        self.middlewares = []

    def add(self, func):
        self.middlewares.append(func)

    async def process(self, msg, bot):
        modified_msg = msg
        for middleware in self.middlewares:
            try:
                result = middleware(modified_msg, bot)
                if result is False:
                    return None
                if result is not None and result is not True:
                    modified_msg = result
            except Exception as e:
                print(f"Middleware error: {e}")
        return modified_msg

    def process_sync(self, msg, bot):
        modified_msg = msg
        for middleware in self.middlewares:
            try:
                result = middleware(modified_msg, bot)
                if result is False:
                    return None
                if result is not None and result is not True:
                    modified_msg = result
            except Exception as e:
                print(f"Middleware error: {e}")
        return modified_msg