class KeyButton:
    def __init__(self, button_id, text, button_type="Simple"):
        self.id = button_id
        self.text = text
        self.type = button_type
    
    def to_dict(self):
        return {"id": self.id, "type": self.type, "button_text": self.text}


class Keypad:
    def __init__(self, resize=True, one_time=False):
        self.rows = []
        self.resize = resize
        self.one_time = one_time
    
    def add_row(self, *buttons):
        self.rows.append(list(buttons))
        return self
    
    def to_dict(self):
        return {
            "rows": [{"buttons": [btn.to_dict() for btn in row]} for row in self.rows],
            "resize_keyboard": self.resize,
            "one_time_keyboard": self.one_time
        }