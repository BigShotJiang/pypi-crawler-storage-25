class Router:
    def __init__(self):
        self.commands = {}
        self.messages = None
        self.buttons = {}
        self.filters = {}

    def command(self, name, filters=None):
        def decorator(func):
            self.commands[name] = {"func": func, "filters": filters}
            return func
        return decorator

    def on_message(self, filters=None):
        def decorator(func):
            self.messages = {"func": func, "filters": filters}
            return func
        return decorator

    def on_button(self, button_id, filters=None):
        def decorator(func):
            self.buttons[button_id] = {"func": func, "filters": filters}
            return func
        return decorator

    def _check_filters(self, filters, msg):
        if filters is None:
            return True
        if callable(filters):
            return filters(msg)
        return True