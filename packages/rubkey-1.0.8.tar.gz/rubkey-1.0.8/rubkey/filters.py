import re

class Filters:
    @staticmethod
    def command(commands=None):
        def check(msg):
            text = (msg.text or "").strip()
            if not text.startswith("/"):
                return False
            if commands is None:
                return True
            cmd = text[1:].split()[0]
            return cmd in commands if isinstance(commands, list) else cmd == commands
        return check

    @staticmethod
    def text(texts=None):
        def check(msg):
            txt = (msg.text or "").strip()
            if texts is None:
                return bool(txt)
            return txt in texts if isinstance(texts, list) else txt == texts
        return check

    @staticmethod
    def regex(pattern):
        def check(msg):
            text = msg.text or ""
            return bool(re.match(pattern, text))
        return check

    @staticmethod
    def chat_type(chat_types):
        def check(msg):
            if isinstance(chat_types, str):
                chat_types_list = [chat_types]
            else:
                chat_types_list = chat_types
            chat_id = msg.chat_id
            for ct in chat_types_list:
                if ct == "private" and chat_id.startswith("b"):
                    return True
                if ct == "group" and chat_id.startswith("g"):
                    return True
                if ct == "channel" and chat_id.startswith("c"):
                    return True
            return False
        return check

    @staticmethod
    def has_file():
        def check(msg):
            return msg.file is not None
        return check

    @staticmethod
    def has_contact():
        def check(msg):
            return msg.contact is not None
        return check

    @staticmethod
    def has_button(button_id=None):
        def check(msg):
            if button_id is None:
                return bool(msg.button_id)
            return msg.button_id == button_id
        return check

    @staticmethod
    def is_admin():
        def check(msg):
            return msg._bot._is_admin(msg) if msg._bot else False
        return check

    @staticmethod
    def and_filter(*filters):
        def check(msg):
            return all(f(msg) for f in filters)
        return check

    @staticmethod
    def or_filter(*filters):
        def check(msg):
            return any(f(msg) for f in filters)
        return check

    @staticmethod
    def not_filter(f):
        def check(msg):
            return not f(msg)
        return check