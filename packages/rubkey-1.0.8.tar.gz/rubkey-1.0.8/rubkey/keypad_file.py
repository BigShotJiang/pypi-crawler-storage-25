class FileButton:
    def __init__(self, button_id, text, file_type="File"):
        self.id = button_id
        self.text = text
        self.type = file_type
    
    def to_dict(self):
        return {"id": self.id, "type": self.type, "button_text": self.text}