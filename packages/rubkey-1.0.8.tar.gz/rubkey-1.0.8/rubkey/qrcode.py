class BarcodeButton:
    def __init__(self, button_id, text):
        self.id = button_id
        self.text = text
        self.type = "Barcode"
    
    def to_dict(self):
        return {"id": self.id, "type": self.type, "button_text": self.text}