from aiohttp import web
import threading
import asyncio

class WebhookServer:
    def __init__(self, bot, host="0.0.0.0", port=5000):
        self.bot = bot
        self.host = host
        self.port = port
        self.app = web.Application()
        self._setup_routes()
        self._runner = None
    
    def _setup_routes(self):
        self.app.router.add_post("/webhook", self._handle_webhook)
    
    async def _handle_webhook(self, request):
        data = await request.json()
        if data and data.get("type") == "ReceiveInlineMessage":
            inline_data = data.get("data", {})
            msg_data = {
                "chat_id": inline_data.get("chat_id", ""),
                "text": inline_data.get("text", ""),
                "message_id": inline_data.get("message_id", ""),
                "sender_id": inline_data.get("sender_id", ""),
                "aux_data": inline_data.get("aux_data", {})
            }
            await self.bot._process_message(msg_data)
        elif data and data.get("type") == "ReceiveUpdate":
            updates = data.get("data", {}).get("updates", [])
            for update in updates:
                msg_data = update.get("new_message") or update.get("updated_message")
                if msg_data:
                    msg_data["chat_id"] = update.get("chat_id", "")
                    await self.bot._process_message(msg_data)
        return web.json_response({"status": "OK"})
    
    async def _start_runner(self):
        self._runner = web.AppRunner(self.app)
        await self._runner.setup()
        site = web.TCPSite(self._runner, self.host, self.port)
        await site.start()
        print(f"Webhook server running on http://{self.host}:{self.port}")
    
    def run(self):
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            loop.run_until_complete(self._start_runner())
            loop.run_forever()
        except KeyboardInterrupt:
            pass
        finally:
            loop.close()
    
    def run_in_thread(self):
        thread = threading.Thread(target=self.run, daemon=True)
        thread.start()
        return thread