import os
import importlib
import sys

class PluginLoader:
    def __init__(self, bot, plugin_dir="plugins"):
        self.bot = bot
        self.plugin_dir = plugin_dir
        self.plugins = []
    def load_all(self):
        if not os.path.exists(self.plugin_dir):
            os.makedirs(self.plugin_dir)
            return
        sys.path.insert(0, os.path.abspath(self.plugin_dir))
        for f in sorted(os.listdir(self.plugin_dir)):
            if f.endswith(".py") and not f.startswith("_"):
                name = f[:-3]
                try:
                    mod = importlib.import_module(name)
                    if hasattr(mod, "setup"):
                        mod.setup(self.bot)
                        self.plugins.append(name)
                        print(f"Plugin loaded: {name}")
                except Exception as e:
                    print(f"Failed to load plugin {name}: {e}")
        sys.path.pop(0)
    def reload_all(self):
        for plugin in self.plugins:
            try:
                mod = importlib.import_module(plugin)
                importlib.reload(mod)
                if hasattr(mod, "setup"):
                    mod.setup(self.bot)
            except Exception as e:
                print(f"Failed to reload plugin {plugin}: {e}")