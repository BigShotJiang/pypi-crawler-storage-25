class PluginInfo:
    def __init__(self, name, version, author, description=""):
        self.name = name
        self.version = version
        self.author = author
        self.description = description