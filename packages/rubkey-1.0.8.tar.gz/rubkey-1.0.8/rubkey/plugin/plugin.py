class Plugin:
    def __init__(self, info):
        self.info = info
        self.commands = {}
        self.messages = None
        self.buttons = {}
        self.admin_commands = {}
        self.admin_messages = None
        self.admin_buttons = {}
    def command(self, name, pattern=None):
        def decorator(func):
            self.commands[name] = {"func": func, "pattern": pattern}
            return func
        return decorator
    def on_message(self, pattern=None):
        def decorator(func):
            self.messages = {"func": func, "pattern": pattern}
            return func
        return decorator
    def on_button(self, button_id):
        def decorator(func):
            self.buttons[button_id] = func
            return func
        return decorator
    def admin_command(self, name):
        def decorator(func):
            self.admin_commands[name] = func
            return func
        return decorator
    def admin_on_message(self):
        def decorator(func):
            self.admin_messages = func
            return func
        return decorator
    def admin_on_button(self, button_id):
        def decorator(func):
            self.admin_buttons[button_id] = func
            return func
        return decorator