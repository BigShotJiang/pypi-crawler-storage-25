from ..bot import Bot
from ..types import Message

class GroupBot(Bot):
    def __init__(self, token, session_file=None):
        super().__init__(token, session_file)
        self.group_handlers = None
        self.group_info = {}
        self.group_admins = {}
        self.first_admin_on_start = False
        self.first_n_admins = 1
        self.admin_count = {}
        self.no_admin_mode = False
    def set_group_handlers(self, handlers):
        self.group_handlers = handlers
    def _is_group(self, chat_id):
        return chat_id.startswith("g")
    def get_group_info(self, chat_id):
        if chat_id in self.group_info:
            return self.group_info[chat_id]
        result = self._api("getChat", {"chat_id": chat_id})
        data = result.get("data", result)
        chat = data.get("chat", data)
        info = {
            "chat_id": chat.get("chat_id", chat_id),
            "title": chat.get("title", "بدون نام"),
            "type": chat.get("chat_type", "Group")
        }
        self.group_info[chat_id] = info
        return info
    def set_group_admin(self, group_id, user_id):
        if group_id not in self.group_admins:
            self.group_admins[group_id] = set()
        self.group_admins[group_id].add(user_id)
    def _is_group_admin(self, group_id, user_id):
        if self.no_admin_mode:
            return False
        return user_id in self.group_admins.get(group_id, set())
    def _process_message(self, msg_data):
        msg = Message(msg_data, bot=self)
        text = (msg.text or "").strip()
        button_id = msg.button_id
        chat_id = msg.chat_id
        user_id = msg.sender_id
        is_group = self._is_group(chat_id)
        if is_group and self.auto_delete_rules and self._should_delete(text):
            if not (self.admins_can_bypass_delete and self._is_group_admin(chat_id, user_id)):
                self.delete_message(chat_id, msg.message_id)
                return
        if is_group and text == "/start" and self.first_admin_on_start:
            if chat_id not in self.admin_count:
                self.admin_count[chat_id] = 0
            self.admin_count[chat_id] += 1
            if self.admin_count[chat_id] <= self.first_n_admins:
                self.set_group_admin(chat_id, user_id)
        if self.group_handlers:
            if is_group:
                if button_id and button_id in self.group_handlers.group_buttons:
                    btn = self.group_handlers.group_buttons[button_id]
                    btn["func"](msg, self.get_group_info(chat_id))
                    return
                if text.startswith("/"):
                    cmd = text[1:].split()[0]
                    if cmd in self.group_handlers.group_commands:
                        cmd_info = self.group_handlers.group_commands[cmd]
                        cmd_info["func"](msg, self.get_group_info(chat_id))
                        return
                if text in self.group_handlers.group_commands:
                    cmd_info = self.group_handlers.group_commands[text]
                    cmd_info["func"](msg, self.get_group_info(chat_id))
                    return
                if self.group_handlers.group_messages:
                    self.group_handlers.group_messages["func"](msg, self.get_group_info(chat_id))
                    return
            if not is_group:
                if text.startswith("/"):
                    cmd = text[1:].split()[0]
                    if cmd in self.group_handlers.group_commands:
                        cmd_info = self.group_handlers.group_commands[cmd]
                        if not cmd_info.get("group_only", True):
                            cmd_info["func"](msg, None)
                            return
                if text in self.group_handlers.group_commands:
                    cmd_info = self.group_handlers.group_commands[text]
                    if not cmd_info.get("group_only", True):
                        cmd_info["func"](msg, None)
                        return
                if self.group_handlers.group_messages:
                    if not self.group_handlers.group_messages.get("group_only", True):
                        self.group_handlers.group_messages["func"](msg, None)
                        return
        super()._process_message(msg_data)