class GroupHandlers:
    def __init__(self):
        self.group_commands = {}
        self.group_messages = None
        self.group_buttons = {}
        self.group_data = {}
    
    def command(self, name, group_only=True):
        def decorator(func):
            self.group_commands[name] = {"func": func, "group_only": group_only}
            return func
        return decorator
    
    def on_message(self, group_only=True):
        def decorator(func):
            self.group_messages = {"func": func, "group_only": group_only}
            return func
        return decorator
    
    def on_button(self, button_id, group_only=True):
        def decorator(func):
            self.group_buttons[button_id] = {"func": func, "group_only": group_only}
            return func
        return decorator
    
    def set_data(self, group_id, key, value):
        if group_id not in self.group_data:
            self.group_data[group_id] = {}
        self.group_data[group_id][key] = value
    
    def get_data(self, group_id, key, default=None):
        return self.group_data.get(group_id, {}).get(key, default)