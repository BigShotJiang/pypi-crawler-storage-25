class SelectionButton:
    def __init__(self, button_id, text, selection_id, items, is_multi_selection=False, columns_count="1", title=""):
        self.id = button_id
        self.text = text
        self.type = "Selection"
        self.selection_id = selection_id
        self.items = items
        self.is_multi_selection = is_multi_selection
        self.columns_count = columns_count
        self.title = title
    def to_dict(self):
        return {
            "id": self.id,
            "type": self.type,
            "button_text": self.text,
            "button_selection": {
                "selection_id": self.selection_id,
                "search_type": "Local",
                "get_type": "Local",
                "is_multi_selection": self.is_multi_selection,
                "columns_count": self.columns_count,
                "title": self.title,
                "items": self.items
            }
        }

class NumberPickerButton:
    def __init__(self, button_id, text, min_value, max_value, default_value=None, title=""):
        self.id = button_id
        self.text = text
        self.type = "NumberPicker"
        self.min_value = min_value
        self.max_value = max_value
        self.default_value = default_value
        self.title = title
    def to_dict(self):
        result = {
            "id": self.id,
            "type": self.type,
            "button_text": self.text,
            "button_number_picker": {
                "min_value": str(self.min_value),
                "max_value": str(self.max_value),
                "title": self.title
            }
        }
        if self.default_value is not None:
            result["button_number_picker"]["default_value"] = str(self.default_value)
        return result

class StringPickerButton:
    def __init__(self, button_id, text, items, default_value=None, title=""):
        self.id = button_id
        self.text = text
        self.type = "StringPicker"
        self.items = items
        self.default_value = default_value
        self.title = title
    def to_dict(self):
        result = {
            "id": self.id,
            "type": self.type,
            "button_text": self.text,
            "button_string_picker": {
                "items": self.items,
                "title": self.title
            }
        }
        if self.default_value is not None:
            result["button_string_picker"]["default_value"] = self.default_value
        return result

class LinkButton:
    def __init__(self, button_id, text, link_url):
        self.id = button_id
        self.text = text
        self.type = "Link"
        self.link_url = link_url
    def to_dict(self):
        return {
            "id": self.id,
            "type": self.type,
            "button_text": self.text,
            "link_url": self.link_url
        }

class BarcodeInlineButton:
    def __init__(self, button_id, text):
        self.id = button_id
        self.text = text
        self.type = "Barcode"
    def to_dict(self):
        return {"id": self.id, "type": self.type, "button_text": self.text}

class TextboxInlineButton:
    def __init__(self, button_id, text, type_line="SingleLine", type_keypad="String", place_holder="", title=""):
        self.id = button_id
        self.text = text
        self.type = "Textbox"
        self.type_line = type_line
        self.type_keypad = type_keypad
        self.place_holder = place_holder
        self.title = title
    def to_dict(self):
        return {
            "id": self.id,
            "type": self.type,
            "button_text": self.text,
            "button_textbox": {
                "type_line": self.type_line,
                "type_keypad": self.type_keypad,
                "place_holder": self.place_holder,
                "title": self.title
            }
        }