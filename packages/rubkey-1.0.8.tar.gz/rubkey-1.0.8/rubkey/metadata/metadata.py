class MetadataPart:
    def __init__(self, meta_type, from_index, length, **kwargs):
        self.type = meta_type
        self.from_index = from_index
        self.length = length
        self.extras = kwargs

    def to_dict(self):
        result = {
            "type": self.type,
            "from_index": self.from_index,
            "length": self.length
        }
        if self.type == "Link" and "link_url" in self.extras:
            result["link_url"] = self.extras["link_url"]
        if self.type == "MentionText" and "mention_text_user_id" in self.extras:
            result["mention_text_user_id"] = self.extras["mention_text_user_id"]
        return result


class Metadata:
    def __init__(self):
        self.parts = []

    def add_part(self, part):
        self.parts.append(part)
        return self

    def to_dict(self):
        return {
            "meta_data_parts": [part.to_dict() for part in self.parts]
        }