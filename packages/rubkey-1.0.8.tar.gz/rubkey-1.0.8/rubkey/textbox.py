class TextboxButton:
    def __init__(self, button_id, text, type_line="SingleLine", type_keypad="String", place_holder="", title=""):
        self.id = button_id
        self.text = text
        self.type = "Textbox"
        self.type_line = type_line
        self.type_keypad = type_keypad
        self.place_holder = place_holder
        self.title = title
    
    def to_dict(self):
        return {
            "id": self.id,
            "type": self.type,
            "button_text": self.text,
            "button_textbox": {
                "type_line": self.type_line,
                "type_keypad": self.type_keypad,
                "place_holder": self.place_holder,
                "title": self.title
            }
        }