import aiosqlite
import os

class Database:
    def __init__(self, db_path="rubkey.db"):
        self.db_path = db_path
    
    async def init(self):
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("""
                CREATE TABLE IF NOT EXISTS messages (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    message_id TEXT,
                    chat_id TEXT,
                    sender_id TEXT,
                    text TEXT,
                    time INTEGER,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            await db.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    user_id TEXT PRIMARY KEY,
                    first_name TEXT,
                    last_name TEXT,
                    username TEXT,
                    phone TEXT,
                    joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            await db.commit()
    
    async def save_message(self, message_id, chat_id, sender_id, text, time_stamp):
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute(
                "INSERT INTO messages (message_id, chat_id, sender_id, text, time) VALUES (?, ?, ?, ?, ?)",
                (message_id, chat_id, sender_id, text, time_stamp)
            )
            await db.commit()
    
    async def save_user(self, user_id, first_name="", last_name="", username="", phone=""):
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute(
                "INSERT OR REPLACE INTO users (user_id, first_name, last_name, username, phone) VALUES (?, ?, ?, ?, ?)",
                (user_id, first_name, last_name, username, phone)
            )
            await db.commit()
    
    async def get_messages(self, chat_id=None, limit=50):
        async with aiosqlite.connect(self.db_path) as db:
            if chat_id:
                cursor = await db.execute(
                    "SELECT * FROM messages WHERE chat_id = ? ORDER BY time DESC LIMIT ?",
                    (chat_id, limit)
                )
            else:
                cursor = await db.execute(
                    "SELECT * FROM messages ORDER BY time DESC LIMIT ?",
                    (limit,)
                )
            return await cursor.fetchall()
    
    async def get_user(self, user_id):
        async with aiosqlite.connect(self.db_path) as db:
            cursor = await db.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
            return await cursor.fetchone()
