from ..bot import Bot
from ..types import Message

class ChannelBot(Bot):
    def __init__(self, token, session_file=None):
        super().__init__(token, session_file)
        self.channel_handlers = None
        self.channel_info = {}
    def set_channel_handlers(self, handlers):
        self.channel_handlers = handlers
    def _is_channel(self, chat_id):
        return chat_id.startswith("c")
    def get_channel_info(self, chat_id):
        if chat_id in self.channel_info:
            return self.channel_info[chat_id]
        result = self._api("getChat", {"chat_id": chat_id})
        data = result.get("data", result)
        chat = data.get("chat", data)
        info = {
            "chat_id": chat.get("chat_id", chat_id),
            "title": chat.get("title", "بدون نام"),
            "type": chat.get("chat_type", "Channel"),
            "username": chat.get("username", "ندارد")
        }
        self.channel_info[chat_id] = info
        return info
    def send_to_channel(self, channel_id, text, keypad=None, inline_keypad=None):
        return self.send_message(channel_id, text, keypad=keypad, inline_keypad=inline_keypad)
    def edit_in_channel(self, channel_id, message_id, text):
        return self.edit_message(channel_id, message_id, text)
    def delete_in_channel(self, channel_id, message_id):
        return self.delete_message(channel_id, message_id)
    def forward_to_channel(self, from_chat_id, channel_id, message_id):
        return self.forward_message(from_chat_id, channel_id, message_id)
    def send_poll_to_channel(self, channel_id, question, options):
        return self.send_poll(channel_id, question, options)
    def _process_message(self, msg_data):
        msg = Message(msg_data, bot=self)
        text = (msg.text or "").strip()
        button_id = msg.button_id
        chat_id = msg.chat_id
        is_channel = self._is_channel(chat_id)
        if self.channel_handlers and is_channel:
            if text.startswith("/"):
                cmd = text[1:].split()[0]
                if cmd in self.channel_handlers.channel_commands:
                    cmd_info = self.channel_handlers.channel_commands[cmd]
                    cmd_info["func"](msg, self.get_channel_info(chat_id))
                    return
            if text in self.channel_handlers.channel_commands:
                cmd_info = self.channel_handlers.channel_commands[text]
                cmd_info["func"](msg, self.get_channel_info(chat_id))
                return
            if self.channel_handlers.channel_messages:
                self.channel_handlers.channel_messages["func"](msg, self.get_channel_info(chat_id))
                return
        super()._process_message(msg_data)