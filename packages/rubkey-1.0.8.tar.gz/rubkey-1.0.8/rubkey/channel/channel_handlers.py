class ChannelHandlers:
    def __init__(self):
        self.channel_commands = {}
        self.channel_messages = None
        self.channel_data = {}
    def command(self, name):
        def decorator(func):
            self.channel_commands[name] = {"func": func}
            return func
        return decorator
    def on_message(self):
        def decorator(func):
            self.channel_messages = {"func": func}
            return func
        return decorator
    def set_data(self, channel_id, key, value):
        if channel_id not in self.channel_data:
            self.channel_data[channel_id] = {}
        self.channel_data[channel_id][key] = value
    def get_data(self, channel_id, key, default=None):
        return self.channel_data.get(channel_id, {}).get(key, default)