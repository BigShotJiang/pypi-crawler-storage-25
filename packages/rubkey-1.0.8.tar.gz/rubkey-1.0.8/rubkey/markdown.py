from .metadata import Metadata, MetadataPart
import re

class MarkdownParser:
    @staticmethod
    def parse(text):
        meta = Metadata()
        patterns = [
            ("Bold", r"\*\*(.+?)\*\*"),
            ("Spoiler", r"\|\|(.+?)\|\|"),
            ("Italic", r"(?<!\*)\*(?!\*)(.+?)(?<!\*)\*(?!\*)"),
            ("Underline", r"__(.+?)__"),
            ("Strike", r"~~(.+?)~~"),
            ("Quote", r"> (.+)"),
            ("Link", r"\[(.+?)\]\((.+?)\)"),
        ]
        
        clean_text = text
        for meta_type, pattern in patterns:
            for match in re.finditer(pattern, text):
                if meta_type == "Link":
                    link_text = match.group(1)
                    url = match.group(2)
                    pos = clean_text.find(f"[{link_text}]({url})")
                    if pos >= 0:
                        meta.add_part(MetadataPart(meta_type, pos, len(link_text), link_url=url))
                        clean_text = clean_text[:pos] + link_text + clean_text[pos + len(f"[{link_text}]({url})"):]
                else:
                    content = match.group(1)
                    full = match.group(0)
                    pos = clean_text.find(full)
                    if pos >= 0:
                        meta.add_part(MetadataPart(meta_type, pos, len(content)))
                        clean_text = clean_text[:pos] + content + clean_text[pos + len(full):]
        
        return clean_text, meta