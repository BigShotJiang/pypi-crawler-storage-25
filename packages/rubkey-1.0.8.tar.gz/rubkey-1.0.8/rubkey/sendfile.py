import requests

class SendFile:
    def __init__(self, bot):
        self.bot = bot
    
    def request_send_file(self, file_type="Image"):
        result = self.bot._api("requestSendFile", {"type": file_type})
        return result.get("data", result)
    
    def upload_file(self, upload_url, file_path):
        try:
            with open(file_path, "rb") as f:
                r = requests.post(upload_url, files={"file": f}, timeout=120)
                if r.status_code == 200 and r.text.strip():
                    return r.json()
        except Exception as e:
            print(f"Upload Error: {e}")
        return {}
    
    def send_file(self, chat_id, file_id, text=""):
        data = {"chat_id": chat_id, "file_id": file_id, "text": text}
        result = self.bot._api("sendFile", data)
        return result.get("data", result)