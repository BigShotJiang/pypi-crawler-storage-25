import json
import os
import time

class Session:
    def __init__(self, session_file="session.json"):
        self.session_file = session_file
        self.data = {}
        self._load()
    
    def _load(self):
        if os.path.exists(self.session_file):
            try:
                with open(self.session_file, "r") as f:
                    self.data = json.load(f)
            except:
                self.data = {}
    
    def _save(self):
        try:
            with open(self.session_file, "w") as f:
                json.dump(self.data, f)
        except:
            pass
    
    def set(self, user_id, key, value):
        if user_id not in self.data:
            self.data[user_id] = {}
        self.data[user_id][key] = {"value": value, "timestamp": int(time.time())}
        self._save()
    
    def get(self, user_id, key, default=None):
        user_data = self.data.get(user_id, {})
        item = user_data.get(key, {})
        return item.get("value", default)
    
    def delete(self, user_id, key=None):
        if key:
            if user_id in self.data and key in self.data[user_id]:
                del self.data[user_id][key]
        else:
            if user_id in self.data:
                del self.data[user_id]
        self._save()
    
    def clear(self):
        self.data = {}
        self._save()