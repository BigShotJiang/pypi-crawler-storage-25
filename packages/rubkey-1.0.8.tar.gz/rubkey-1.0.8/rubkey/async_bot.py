import asyncio
import aiohttp
import json
import time
import os
from .types import Message

class AsyncBot:
    def __init__(self, token, session_file=None):
        self.token = token
        self.api_url = f"https://botapi.rubika.ir/v3/{token}"
        self.handlers = {}
        self.button_handlers = {}
        self.default_handler = None
        self._running = False
        self.session_file = session_file
        self.offset = None
        self.banned_users = set()
        self.rate_limit = {}
        self.rate_limit_max = 5
        self.rate_limit_window = 1
        self.cache = {}
        self.cache_ttl = 300
        self.analytics = {}
        self.retry_count = 3
        self.retry_delay = 1
        if session_file:
            self.session_file = session_file if session_file.endswith('.rubkey') else f"{session_file}.rubkey"
            self._load_offset()
    def _load_offset(self):
        if self.session_file and os.path.exists(self.session_file):
            try:
                with open(self.session_file, "r") as f:
                    data = f.read().strip()
                    self.offset = data if data else None
            except:
                pass
    def _save_offset(self):
        if self.session_file and self.offset:
            try:
                with open(self.session_file, "w") as f:
                    f.write(str(self.offset))
            except:
                pass
    async def _api(self, method, data=None, retry=0):
        if data is None:
            data = {}
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(f"{self.api_url}/{method}", json=data, timeout=30) as r:
                    if r.status == 200:
                        text = await r.text()
                        if text.strip():
                            return json.loads(text)
        except Exception as e:
            if retry < self.retry_count:
                await asyncio.sleep(self.retry_delay * (2 ** retry))
                return await self._api(method, data, retry + 1)
            print(f"API Error: {e}")
        return {}
    async def send_message(self, chat_id, text, keypad=None, inline_keypad=None, reply_to=None):
        data = {"chat_id": chat_id, "text": text}
        if keypad:
            data["chat_keypad_type"] = "New"
            data["chat_keypad"] = keypad.to_dict()
        if inline_keypad:
            data["inline_keypad"] = inline_keypad.to_dict()
        if reply_to:
            data["reply_to_message_id"] = reply_to
        result = await self._api("sendMessage", data)
        return result.get("data", result)
    async def run(self):
        print("Async Rubkey bot run...")
        self._running = True
        while self._running:
            try:
                body = {"limit": 10}
                if self.offset:
                    body["offset_id"] = self.offset
                result = await self._api("getUpdates", body)
                data = result.get("data", result)
                if data.get("next_offset_id"):
                    self.offset = data["next_offset_id"]
                    self._save_offset()
                for update in data.get("updates", []):
                    msg_data = update.get("new_message") or update.get("updated_message")
                    if msg_data:
                        msg_data["chat_id"] = update.get("chat_id", "")
                        asyncio.create_task(self._process_message(msg_data))
                await asyncio.sleep(1)
            except KeyboardInterrupt:
                print("\nBot stopped.")
                break
            except Exception as e:
                print(f"Error: {e}")
                await asyncio.sleep(2)
    async def _process_message(self, msg_data):
        msg = Message(msg_data, bot=self)
        text = (msg.text or "").strip()
        if text.startswith("/"):
            cmd = text[1:].split()[0]
            if cmd in self.handlers:
                await self.handlers[cmd](msg)
                return
        if text in self.handlers:
            await self.handlers[text](msg)
            return
        if self.default_handler:
            await self.default_handler(msg)
    def command(self, name):
        def decorator(func):
            self.handlers[name] = func
            return func
        return decorator
    def on_message(self):
        def decorator(func):
            self.default_handler = func
            return func
        return decoratorr