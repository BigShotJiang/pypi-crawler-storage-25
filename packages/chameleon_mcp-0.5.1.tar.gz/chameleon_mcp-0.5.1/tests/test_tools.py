"""Tests for tool helper functions: _truncate, _clean_response, _estimate_tokens, _credentials_guide."""

import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from server import (
    _clean_response,
    _credentials_guide,
    _estimate_tokens,
    _extract_content,
    _load_skills,
    _save_skills,
    _truncate,
    session,
)


class TestTruncate:
    def test_short_text_unchanged(self):
        text = "Hello, world!"
        result = _truncate(text, max_tokens=1500)
        assert result == text

    def test_long_text_truncated(self):
        # 1500 tokens * 4 chars/token = 6000 chars
        text = "X" * 10_000
        result = _truncate(text, max_tokens=1500)
        assert len(result) < len(text)
        assert "[...truncated" in result

    def test_truncation_note_includes_token_count(self):
        text = "A" * 10_000
        result = _truncate(text, max_tokens=100)
        assert "100" in result

    def test_exact_limit_not_truncated(self):
        # exactly 400 chars = 100 tokens
        text = "B" * 400
        result = _truncate(text, max_tokens=100)
        assert "[...truncated" not in result
        assert result == text


class TestCleanResponse:
    def test_strips_markdown_links(self):
        text = "See [this link](https://example.com) for details."
        result = _clean_response(text)
        assert "this link" in result
        assert "https://example.com" not in result
        assert "[" not in result

    def test_strips_images(self):
        text = "Here is ![an image](https://img.example.com/pic.jpg) shown."
        result = _clean_response(text)
        assert "![" not in result

    def test_collapses_blank_lines(self):
        text = "Line 1\n\n\n\nLine 2"
        result = _clean_response(text)
        assert "\n\n\n" not in result

    def test_collapses_spaces(self):
        text = "Word1   Word2    Word3"
        result = _clean_response(text)
        assert "   " not in result

    def test_strips_surrounding_whitespace(self):
        text = "  \n  content  \n  "
        result = _clean_response(text)
        assert result == "content"


class TestEstimateTokens:
    def test_string_estimate(self):
        text = "A" * 400  # 400 chars / 4 = 100 tokens
        assert _estimate_tokens(text) == 100

    def test_list_estimate(self):
        items = [{"name": "tool1"}, {"name": "tool2"}]
        result = _estimate_tokens(items)
        assert isinstance(result, int)
        assert result > 0

    def test_empty_string(self):
        assert _estimate_tokens("") == 0

    def test_non_string_coerced(self):
        result = _estimate_tokens(12345)
        assert isinstance(result, int)


class TestCredentialsGuide:
    def test_no_missing_returns_empty(self):
        credentials = {"apiKey": "Your API key"}
        resolved = {"apiKey": "sk-123"}
        result = _credentials_guide("test-server", credentials, resolved)
        assert result == ""

    def test_missing_cred_returns_guide(self):
        credentials = {"apiKey": "Your API key"}
        resolved = {}
        result = _credentials_guide("test-server", credentials, resolved)
        assert "test-server" in result
        assert "apiKey" in result
        assert "API_KEY" in result  # env var conversion

    def test_shows_key_command(self):
        credentials = {"apiKey": "API key description"}
        resolved = {}
        result = _credentials_guide("my-server", credentials, resolved)
        assert "key(" in result

    def test_shows_inline_call_example(self):
        credentials = {"token": "Auth token", "secret": "Secret value"}
        resolved = {}
        result = _credentials_guide("my-server", credentials, resolved)
        assert "call(" in result
        assert '"token"' in result

    def test_multiple_missing_all_shown(self):
        credentials = {
            "apiKey": "Key A",
            "token": "Key B",
            "secret": "Key C",
        }
        resolved = {"apiKey": "already-set"}
        result = _credentials_guide("multi-server", credentials, resolved)
        assert "token" in result
        assert "secret" in result
        # apiKey is resolved so should not appear in missing list


class TestExtractContent:
    def test_single_text_part_extracted(self):
        result = {"content": [{"type": "text", "text": "Hello world"}]}
        assert _extract_content(result) == "Hello world"

    def test_multiple_text_parts_joined(self):
        result = {"content": [
            {"type": "text", "text": "Part 1"},
            {"type": "text", "text": "Part 2"},
        ]}
        assert _extract_content(result) == "Part 1\nPart 2"

    def test_non_text_content_falls_back_to_json(self):
        result = {"content": [{"type": "image", "data": "abc123"}]}
        out = _extract_content(result)
        assert "image" in out  # JSON dump includes the type field

    def test_empty_content_falls_back_to_json_result(self):
        result = {"someKey": "someValue"}
        out = _extract_content(result)
        assert "someKey" in out


class TestSkillPersistence:
    """_load_skills / _save_skills round-trip tests."""

    def _make_skill(self, name="test-skill", content="do the thing"):
        return {
            "name": name,
            "content": content,
            "tokens": len(content) // 4,
            "installed_at": "2026-01-01T00:00:00",
        }

    def test_save_and_load_round_trip(self, tmp_path, monkeypatch):
        import chameleon_mcp.session as sess_mod

        skills_file = tmp_path / "skills.json"
        monkeypatch.setattr(sess_mod, "SKILLS_PATH", skills_file)

        session["skills"]["org/my-skill"] = self._make_skill()
        _save_skills()

        assert skills_file.exists()
        data = json.loads(skills_file.read_text())
        assert "org/my-skill" in data
        assert data["org/my-skill"]["content"] == "do the thing"

    def test_load_populates_session(self, tmp_path, monkeypatch):
        import chameleon_mcp.session as sess_mod

        skills_file = tmp_path / "skills.json"
        skills_file.write_text(json.dumps({"org/loaded-skill": self._make_skill("loaded")}))
        monkeypatch.setattr(sess_mod, "SKILLS_PATH", skills_file)

        # Clear session and reload
        session["skills"].clear()
        _load_skills()

        assert "org/loaded-skill" in session["skills"]
        assert session["skills"]["org/loaded-skill"]["name"] == "loaded"

    def test_load_missing_file_is_silent(self, tmp_path, monkeypatch):
        import chameleon_mcp.session as sess_mod

        monkeypatch.setattr(sess_mod, "SKILLS_PATH", tmp_path / "nonexistent.json")
        session["skills"].clear()
        _load_skills()  # should not raise
        assert session["skills"] == {}

    def test_load_corrupt_file_is_silent(self, tmp_path, monkeypatch):
        import chameleon_mcp.session as sess_mod

        skills_file = tmp_path / "skills.json"
        skills_file.write_text("not valid json{{{")
        monkeypatch.setattr(sess_mod, "SKILLS_PATH", skills_file)

        session["skills"].clear()
        _load_skills()  # should not raise
        assert session["skills"] == {}
