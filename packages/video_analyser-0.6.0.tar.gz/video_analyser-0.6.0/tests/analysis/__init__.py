"""Tests for analysis modules."""
