"""Report generation tests."""
