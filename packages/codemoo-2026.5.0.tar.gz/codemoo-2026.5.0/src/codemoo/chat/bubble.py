"""ChatBubble widget for displaying a single chat message."""

from textual.app import ComposeResult
from textual.widget import Widget
from textual.widgets import Label, Markdown, Static


class _BubbleContent(Widget):
    """Inner widget holding the header and Markdown body of a chat bubble."""

    DEFAULT_CSS = """
    _BubbleContent {
        height: auto;
        width: 4fr;
    }
    """

    def __init__(
        self,
        name: str,
        emoji: str,
        text: str,
        thinking_time: int | None,
        css_class: str,
    ) -> None:
        super().__init__(classes=css_class)
        self._sender_name = name
        self._sender_emoji = emoji
        self._text = text
        self._thinking_time = thinking_time
        self._css_class = css_class

    def compose(self) -> ComposeResult:
        """Yield a header label and a body widget appropriate to the bubble type."""
        header = f"{self._sender_emoji} [bold]{self._sender_name}[/bold]"
        if self._thinking_time is not None:
            header += f" [dim]({self._thinking_time}s)[/dim]"
        yield Label(header, classes="bubble-header", markup=True)
        if self._css_class == "bubble--commentator":
            yield Static(self._text, markup=True)
        else:
            yield Markdown(self._text)


class ChatBubble(Widget):
    """A full-width row containing a spacer and a styled chat bubble.

    Human messages are right-aligned: [spacer | content].
    Bot messages are left-aligned:    [content | spacer].

    Fractional widths (1fr / 4fr) handle the split at any terminal width,
    avoiding the need for percentage-based margins which Textual does not support.
    Structural layout (height, direction, fractional widths) is defined in DEFAULT_CSS;
    visual styling (colors, borders, spacing) lives in the external TCSS stylesheet.
    """

    DEFAULT_CSS = """
    ChatBubble {
        height: auto;
        layout: horizontal;
    }
    ChatBubble > .bubble-spacer {
        width: 1fr;
    }
    """

    def __init__(  # noqa: PLR0913
        self,
        name: str,
        emoji: str,
        text: str,
        *,
        thinking_time: int | None = None,
        is_human: bool,
        css_class: str | None = None,
    ) -> None:
        """Initialise the bubble with sender info and message content."""
        super().__init__()
        self._sender_name = name
        self._sender_emoji = emoji
        self._text = text
        self._thinking_time = thinking_time
        self._is_human = is_human
        self._css_class = css_class

    def compose(self) -> ComposeResult:
        """Yield spacer and content in the order that produces the correct alignment."""
        css_class = self._css_class or (
            "bubble--human" if self._is_human else "bubble--bot"
        )
        content = _BubbleContent(
            self._sender_name,
            self._sender_emoji,
            self._text,
            self._thinking_time,
            css_class,
        )
        spacer = Static("", classes="bubble-spacer")
        if self._is_human:
            yield spacer
            yield content
        else:
            yield content
            yield spacer
