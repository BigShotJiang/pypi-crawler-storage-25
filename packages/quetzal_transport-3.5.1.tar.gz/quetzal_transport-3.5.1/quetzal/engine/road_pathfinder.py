import numpy as np
import geopandas as gpd
import pandas as pd
import polars as pl
from quetzal.engine.pathfinder_utils import build_index, get_path
from quetzal.engine.msa_trackers.links_tracker import LinksTracker
from quetzal.engine.msa_utils import (
    get_derivative,
    init_ab_volumes,
    assign_volume_parallel,
    jam_time,
    apply_segment_cost,
    find_phi,
    find_beta,
    get_bfw_auxiliary_flow,
    shortest_path,
    init_numba_volumes,
    assign_volume_on_links_parallel,
    get_relgap,
    get_sparse_volumes,
)
from typing import List, Dict, Tuple

# base vdf
free_flow = 'time'
default_bpr = 'time * (1 + {alpha} * (flow/capacity)**{beta})'.format(alpha=0.15, beta=4)


def to_polars(df):
    return pl.DataFrame(df.drop(columns=['geometry'], errors='ignore'))


def init_network(
    sm, method='aon', segments=['car'], time_col='time', access_time='time', ntleg_penalty=10e9, log=False
):
    """
    Initialize the road network for the pathfinder.
    return links and zone_to_road concat with the correct columns
    """
    road_links = sm.road_links.copy()
    zone_to_road = sm.zone_to_road.copy()
    assert not road_links.set_index(['a', 'b']).index.has_duplicates, (
        'there is duplicated road links (same a,b for a link) please remove duplicated'
    )
    assert time_col in road_links.columns, f'time_column: {time_col} not found in road_links.'
    aon = method == 'aon'

    test_zone_to_road_network(road_links, zone_to_road)
    zone_to_road = zone_to_road_preparation(zone_to_road, segments, time_col, access_time, ntleg_penalty, aon, log)
    # create DataFrame with road_links and zone to road
    network = concat_connectors_to_roads(road_links, zone_to_road, segments, time_col, aon, log)

    # assert_links_are_polars_compatible
    to_polars(network)  # just to try

    return network


def init_volumes(sm, od_set=None):
    # apply od_set to self.volumes
    try:
        volumes = sm.volumes.copy()
        if od_set is not None:
            od = pd.DataFrame(od_set, columns=['origin', 'destination'])
            volumes = od.merge(volumes, on=['origin', 'destination'], how='left').fillna(0)
    except AttributeError:
        print('self.volumes does not exist. od generated with self.zones, od_set')
        if od_set is None:
            zones = sm.zones.index.values
            od_set = []
            for o in zones:
                for d in zones:
                    od_set.append((o, d))
        volumes = pd.DataFrame(od_set, columns=['origin', 'destination'])
        volumes['volume'] = 0

    assert len(volumes) > 0
    test_zone_to_road_volumes(volumes, sm.zone_to_road)

    return volumes


def test_zone_to_road_network(road_links, zone_to_road):
    """
    test that all nodes in zone_to_road are in the road_links
    """
    assert 'direction' in zone_to_road, 'need direction with {access | eggress} in zone_to_road'

    access_nodes = set(zone_to_road[zone_to_road['direction'] == 'access']['b'])
    eggress_nodes = set(zone_to_road[zone_to_road['direction'] == 'eggress']['a'])

    nodes_set = set(road_links['a']).union(set(road_links['b']))

    if not access_nodes.issubset(nodes_set):
        missing_nodes = access_nodes - nodes_set
        raise ValueError('access: Some road_nodes in zone_to_road are missing in road_links', missing_nodes)
    if not eggress_nodes.issubset(nodes_set):
        missing_nodes = eggress_nodes - nodes_set
        raise ValueError('eggress: Some road_nodes in zone_to_road are missing in road_links', missing_nodes)


def test_zone_to_road_volumes(volumes, zone_to_road):
    zone_to_road_set = set(zone_to_road['a']).union(set(zone_to_road['b']))
    volumes_set = set(volumes['origin']).union(set(volumes['destination']))
    # check if all zones in volumes_set are in zone_to_road_set
    if not volumes_set.issubset(zone_to_road_set):
        # print elements that are not in zone_to_road_set
        missing_zones = volumes_set - zone_to_road_set
        raise ValueError(
            'Some zones in volumes are not in zone_to_road. add to zones_to_road or drop in volumes.', missing_zones
        )


def zone_to_road_preparation(
    zone_to_road, segments, time_col='time', access_time='time', ntleg_penalty=1e9, aon=False, log=False
):
    # prepare zone_to_road_links to the same format as road_links
    zone_to_road = zone_to_road.copy()
    zone_to_road[time_col] = zone_to_road[access_time] + ntleg_penalty
    if not aon:
        if 'vdf' not in zone_to_road.columns:
            print("vdf not found in zone_to_road columns. Values set to 'free_flow'") if log else None
            zone_to_road['vdf'] = 'free_flow'
        if 'segments' not in zone_to_road.columns:
            print("segments not found in zone_to_road columns. set all segments allow'") if log else None
            zone_to_road['segments'] = [set(segments) for _ in range(len(zone_to_road))]

    return zone_to_road


def concat_connectors_to_roads(road_links, zone_to_road, segments, time_col='time', aon=False, log=False):
    if aon:
        columns = ['a', 'b', time_col]
        links = pd.concat([road_links[columns], zone_to_road[columns]])
        # links.index = links.index.astype(str)
        return links
    else:
        if 'vdf' not in road_links.columns:
            print("vdf not found in road_links columns. Values set to 'default_bpr'") if log else None
            road_links['vdf'] = 'default_bpr'
        if 'segments' not in road_links.columns:
            print("segments not found in road_links columns. set all segments allowed on each links'") if log else None
            road_links['segments'] = [set(segments) for _ in range(len(road_links))]

        links = pd.concat([road_links, zone_to_road])
        # links.index = links.index.astype(str)

        links['flow'] = 0
        links['auxiliary_flow'] = 0
        for seg in segments:
            links[(seg, 'flow')] = 0
            links[(seg, 'auxiliary_flow')] = 0

        if 'base_flow' not in links.columns:
            links['base_flow'] = 0
        links['base_flow'] = links['base_flow'].fillna(0)

        links['jam_time'] = links[time_col]  # temporary. to test the cost function
        # vdf keys to string. polars doesnt like mixed key (int and str)
        # later we will convert vdf to str keys. vdf = {str(key): val for key, val in vdf.items()}
        links['vdf'] = links['vdf'].apply(str)
    return links


def assert_vdf_on_links(links, vdf):
    keys = set(links['vdf'])
    missing_vdf = keys - set(vdf.keys())
    assert len(missing_vdf) == 0, 'you should provide methods for the following vdf keys' + str(missing_vdf)


def assert_segs_in_cost_functions(segments, cost_functions):
    keys = set(segments)
    miss = keys - set(cost_functions.keys())
    assert len(miss) == 0, 'you should provide Cost function for the following segments' + str(miss)


def test_cost_functions(links: pd.DataFrame, cost_functions: dict):
    for seg, expr in cost_functions.items():
        test = np.isfinite(apply_segment_cost(links, expr))
        if not all(test):
            loc = np.where(~test)[0]
            print(f'evaluating the cost function yield NaN on some links. {seg} : {expr}')
            print('make sure the zone_to_road also contains every fields in the cost_function')
            print(links.iloc[loc].index)


def get_car_los(volumes, links, index, zones, weight_col, num_cores=1):
    """get the car los paths for the given volumes and links"""
    reversed_index = {v: k for k, v in index.items()}
    car_los = volumes[['origin', 'destination', 'origin_sparse', 'destination_sparse']]
    _, predecessors = shortest_path(links, weight_col, index, zones, num_cores=num_cores)
    odlist = list(zip(car_los['origin_sparse'].values, car_los['destination_sparse'].values))

    path_dict = {}
    for origin, destination in odlist:
        path = get_path(predecessors, origin, destination)
        path = [*map(reversed_index.get, path)]
        path_dict[(origin, destination)] = path

    car_los['path'] = car_los.set_index(['origin_sparse', 'destination_sparse']).index.map(path_dict)
    car_los = car_los.drop(columns=['origin_sparse', 'destination_sparse'])

    return car_los


def get_car_los_time(car_los, links, zone_to_road, time_col='jam_time', access_time='time'):
    """
    Calculate the time for each path in car_los with on the road_links and zone_to_road.
    params:
        time_col: time column in road_links
        access_time: time column in zone_to_road
    return:
         car_los with [time, gtime, edge_path] columns
    """
    car_los['edge_path'] = car_los['path'].apply(lambda ls: list(zip(ls, ls[1:])))

    time_dict = {}
    time_dict.update(links.set_index(['a', 'b'])[time_col].to_dict())
    time_dict.update(zone_to_road.set_index(['a', 'b'])[access_time].to_dict())
    car_los['time'] = car_los['edge_path'].apply(lambda ls: sum([*map(time_dict.get, ls)]))

    car_los.loc[car_los['origin'] == car_los['destination'], 'time'] = 0.0
    car_los['gtime'] = car_los['time']
    return car_los


def links_to_expanded_links(links_with_zone_to_road: gpd.GeoDataFrame, u_turns=False):
    df = links_with_zone_to_road.reset_index()
    df1 = df.rename(columns={'index': 'from_link', 'a': 'a1', 'b': 'b1'})
    df2 = df[['index', 'a', 'b']].rename(columns={'index': 'to_link', 'a': 'a2', 'b': 'b2'})

    expanded_links = pd.merge(df1, df2, left_on='b1', right_on='a2')
    if not u_turns:  # remove U turn
        expanded_links = expanded_links[expanded_links['a1'] != expanded_links['b2']].reset_index(drop=True)

    # rename, reorder, clean
    expanded_links = expanded_links.rename(columns={'a1': 'from_node', 'b2': 'to_node', 'a2': 'mid_node'}).drop(
        columns=['b1']
    )
    expanded_links.index.name = 'index'
    expanded_links.index = 'ex_link_' + expanded_links.index.astype(str)

    def _reorder_columns(df, first=['from_link', 'to_link', 'from_node', 'mid_node', 'to_node']):
        all_cols = df.columns.tolist()
        remaining_cols = [col for col in all_cols if col not in first]
        return df[first + remaining_cols]

    expanded_links = _reorder_columns(expanded_links)
    return expanded_links


def expanded_path_to_nodes(path: List[str], links_to_nodes_dict: Dict[str, Tuple[str, str]]) -> List[str]:
    """
    Convert a path of links to a path of nodes, removing duplicate nodes from overlaps.
    First and last elements are zones. The rest are link IDs.
    Example: ['zone1', 'link1', 'link2', 'zone2'] => ['zone1', 'node1', 'node2', 'node3', 'zone2']
    """
    if len(path) <= 2:
        return path  # just zone-to-zone, no links

    nodes = [path[0]]  # origin (zone)
    nodes.append(links_to_nodes_dict.get(path[1])[0])  # first node a
    for link_id in path[1:-1]:
        node_b = links_to_nodes_dict.get(link_id)[1]
        nodes.append(node_b)  # only append the new one
    nodes.append(path[-1])  # destination (zone)
    return nodes


def fix_zone_to_road(
    expanded_links: gpd.GeoDataFrame, volumes: gpd.geodataframe, create_zone_to_road=False
) -> gpd.GeoDataFrame:
    """
    change zone_to_road expanded links to only the zone index.
    Usefull to do routing on zones when the graph is on links.
    Also, remove links that go through zones and zone-to-zone links.
    """
    links = expanded_links.copy()
    zones_set = set(volumes['origin']).union(set(volumes['destination']))
    # remove links that go through zones.
    links = links[~links['mid_node'].isin(zones_set)]
    # remove zone to zone links.
    links = links[~(links['from_node'].isin(zones_set) & links['to_node'].isin(zones_set))]
    if create_zone_to_road:
        # add virtual links to connect zones to its zone_to_road
        cond = links['from_node'].isin(zones_set)
        access = links.loc[cond]
        access['to_link'] = access['from_link']
        access['from_link'] = access['from_node']

        cond = links['to_node'].isin(zones_set)
        eggress = links.loc[cond]
        eggress['from_link'] = eggress['to_link']
        eggress['to_link'] = eggress['to_node']
        links = pd.concat([links, access, eggress])
    else:
        # rename zone-to-link
        cond = links['from_node'].isin(zones_set)
        links.loc[cond, 'from_link'] = links.loc[cond, 'from_node']
        # rename link-to-zone
        cond = links['to_node'].isin(zones_set)
        links.loc[cond, 'to_link'] = links.loc[cond, 'to_node']

    return links


def aon_roadpathfinder(links, volumes, time_col='time', num_cores=1):
    index = build_index(links[['a', 'b']].values)
    links['sparse_a'] = links['a'].apply(lambda x: index.get(x))
    links['sparse_b'] = links['b'].apply(lambda x: index.get(x))
    links = links.set_index(['sparse_a', 'sparse_b'])
    # sparsify volumes keys
    volumes, origins = get_sparse_volumes(volumes, index)

    return get_car_los(volumes, links, index, origins, time_col, num_cores)


def msa_roadpathfinder(
    links,
    volumes,
    segments=['volume'],
    vdf={'default_bpr': default_bpr, 'free_flow': free_flow},
    method='bfw',
    maxiters=10,
    tolerance=0.01,
    log=False,
    time_col='time',
    tracker_plugin: LinksTracker = LinksTracker(),
    cost_functions=None,
    return_car_los=True,
    num_cores=1,
):
    """
    links: road_network with zone_to_road
    volumes: volumes to assign
    segments: list of segments (in volumes) to assign
    vdf = dict of function for the jam time.
    method = bfw, fw, msa
    maxiters = 10 : number of iteration.
    tolerance = 0.01 : stop condition for RelGap. (in percent)
    log = False : log data on each iteration.
    time_col='freeflow time column'. replace 'time' in vdf
    tracker_plugin=LinksTracker() track OD using a selected links
    cost_functions : if None return dict {seg:'jam_time'} for each segments.
    return_car_los: return the car los.,
    num_cores = 1 : for parallelization.
    """
    # preparation
    # vdf kets must be string for polars.
    vdf = {str(key): val for key, val in vdf.items()}
    assert_vdf_on_links(links, vdf)

    # if no cost function provided. just use jam_time for each segments
    if cost_functions is None:
        cost_functions = {seg: 'jam_time' for seg in segments}

    assert_segs_in_cost_functions(segments, cost_functions)
    test_cost_functions(links, cost_functions)
    # reindex links to sparse indexes (a,b)
    index = build_index(links[['a', 'b']].values)  # a:sparse
    links['sparse_a'] = links['a'].apply(lambda x: index.get(x))
    links['sparse_b'] = links['b'].apply(lambda x: index.get(x))
    links = links.reset_index().set_index(['sparse_a', 'sparse_b'])

    # make lut
    tup_to_index = {tup: i for i, tup in enumerate(links.index)}
    lut = np.empty((len(links), len(links)), dtype=np.int32)
    for tup, i in tup_to_index.items():
        lut[tup] = i

    # initialization
    links['jam_time'] = jam_time(to_polars(links), vdf, 'flow', time_col=time_col)
    for seg in segments:
        links[(seg, 'cost')] = apply_segment_cost(links, cost_functions.get(seg))

    # init track links

    if tracker_plugin():
        # only use for tracker. should change tracker to not use ab_volumes
        ab_volumes = init_ab_volumes(links.index)  # index is a,b here
        _tmp_dict = links['index'].to_dict()
        links_to_sparse = {v: k for k, v in _tmp_dict.items()}
        tracker_plugin.init(links_sparse_index=links.index, links_to_sparse=links_to_sparse)

    # pred origins and odv for each segments for quick access as it doesnt change between iteration
    segment_origins = {}
    segment_odv = {}
    for seg in segments:
        segment_volumes, origins = get_sparse_volumes(volumes[volumes[seg] > 0], index)
        odv = segment_volumes[['origin_sparse', 'destination_sparse', seg]].values
        segment_origins[seg] = origins
        segment_odv[seg] = odv

    relgap = np.inf
    relgap_list = []
    phi = 1  # first iteration is AON
    beta = [1, 0, 0]  # bfw coefficients
    print('it  |  Phi    |  Rel Gap (%)') if log else None
    # note: first iteration i == 0 is AON to initialized.
    for i in range(maxiters + 1):
        #
        # Routing and assignment
        #

        for seg in segments:
            origins = segment_origins[seg]
            odv = segment_odv[seg]
            segment_links = links[links['segments'].apply(lambda x: seg in x)]  # filter links to allowed segment
            _, pred = shortest_path(segment_links, (seg, 'cost'), index, origins, num_cores=num_cores)

            links[(seg, 'auxiliary_flow')] = assign_volume_parallel(odv, pred, lut, num_cores)

            if tracker_plugin():
                tracker_plugin.assign(ab_volumes, odv, pred, seg, i)

        flow_cols = [(seg, 'auxiliary_flow') for seg in segments] + ['base_flow']
        links['auxiliary_flow'] = links[flow_cols].sum(axis=1)

        #
        # Get relGap with AON flow
        #
        if i > 0:  # Skip first iteration (AON and relgap = -inf)
            relgap = get_relgap(links, segments)
            relgap_list.append(relgap)
            print(f'{i:2}  |  {phi:.3f}  |  {relgap:.8f} ') if log else None

        #
        # find Phi, and BFW auxiliary flow modification
        #
        if i == 0:
            pass
        elif method == 'bfw':  # if biconjugate: takes the 2 last direction
            links['derivative'] = get_derivative(to_polars(links), vdf, cost_functions, segments, time_col=time_col)
            if i > 2:
                beta = find_beta(links, phi, segments)  # this is the previous phi (phi_-1)
            links = get_bfw_auxiliary_flow(links, beta, segments)
            links['auxiliary_flow'] = links[flow_cols].sum(axis=1)
            max_phi = 1 / i**0.5  # limit search space
            phi = find_phi(to_polars(links), segments, vdf, cost_functions, bounds=(0, max_phi), time_col=time_col)
        elif method == 'fw':
            max_phi = 1 / i**0.5  # limit search space
            phi = find_phi(to_polars(links), segments, vdf, cost_functions, bounds=(0, max_phi), time_col=time_col)
        else:  # msa
            phi = 1 / (i + 2)

        if tracker_plugin():
            tracker_plugin.add_weights(phi, beta, i)
        #
        # Update flow and jam_time (frank-wolfe)
        #
        for seg in segments:  # track per segments
            links[(seg, 'flow')] = (1 - phi) * links[(seg, 'flow')] + (phi * links[(seg, 'auxiliary_flow')])
        flow_cols = [(seg, 'flow') for seg in segments] + ['base_flow']
        links['flow'] = links[flow_cols].sum(axis=1)

        #
        # Update Time on links
        #
        links['jam_time'] = jam_time(to_polars(links), vdf, 'flow', time_col=time_col)
        for seg in segments:
            links[(seg, 'cost')] = apply_segment_cost(links, cost_functions.get(seg))

        # skip first iteration (AON asignment) as relgap in -inf
        if relgap <= tolerance:
            print('tolerance reached') if log else None
            break
    #
    # Finish: reindex back and get car_los
    #

    # drop columns
    to_drop = ['x1', 'x2', 'result', 'new_flow', 'derivative', 'auxiliary_flow']
    to_drop += [(seg, 's_k-1') for seg in segments]
    to_drop += [(seg, 's_k-2') for seg in segments]
    to_drop += [(seg, 'auxiliary_flow') for seg in segments]
    links = links.drop(columns=to_drop, errors='ignore')

    car_los = pd.DataFrame()

    if return_car_los:
        for seg in segments:
            # filter links to allowed segment
            segment_volumes, origins = get_sparse_volumes(volumes[volumes[seg] > 0], index)
            segment_links = links[links['segments'].apply(lambda x: seg in x)]  # filter links to allowed segment
            temp_los = get_car_los(segment_volumes, segment_links, index, origins, (seg, 'cost'), num_cores)
            temp_los['segment'] = seg
            car_los = pd.concat([car_los, temp_los], ignore_index=True)

    links = links.set_index(['a', 'b'])  # go back to original indexes

    return links, car_los, relgap_list


def expanded_roadpathfinder(
    links,
    volumes,
    segments=['volume'],
    vdf={'default_bpr': default_bpr, 'free_flow': free_flow},
    method='bfw',
    maxiters=10,
    tolerance=0.01,
    log=False,
    time_col='time',
    zone_penalty=10e9,
    turn_penalty=10e3,
    tracker_plugin: LinksTracker = LinksTracker(),
    turn_penalties={},
    cost_functions=None,
    return_car_los=True,
    num_cores=1,
):
    """
    links: road_network with zone_to_road
    volumes: volumes to assign
    segments: list of segments (in volumes) to assign
    vdf = dict of function for the jam time.
    method = bfw, fw, msa, aon
    maxiters = 10 : number of iteration.
    tolerance = 0.01 : stop condition for RelGap. (in percent)
    log = False : log data on each iteration.
    time_col='freeflow time column'. replace 'time' in vdf
    zone_penalty = 10e9 : penalty for zone to road links.
    turn_penalty = 10e3 : penalty for turn links.
    track_links_list=[] list of link index to track flow at each iteration
    turn_penalties: dict of turn penalties {from_link: [to_link]}
    cost_functions : if None return dict {seg:'jam_time'} for each segments.
    return_car_los: return car los
    num_cores = 1 : for parallelization.
    """
    # vdf keys  must be string for polars
    vdf = {str(key): val for key, val in vdf.items()}
    assert_vdf_on_links(links, vdf)

    # if no cost function provided. just use jam_time for each segments
    if cost_functions is None:
        cost_functions = {seg: 'jam_time' for seg in segments}
    assert_segs_in_cost_functions(segments, cost_functions)
    test_cost_functions(links, cost_functions)

    # preparation
    #

    expanded_links = links_to_expanded_links(links, u_turns=False)
    expanded_links = fix_zone_to_road(expanded_links, volumes)
    expanded_links = expanded_links.rename(columns={'from_link': 'a', 'to_link': 'b'})
    expanded_links = expanded_links[['a', 'b', 'from_node', 'mid_node', 'to_node', time_col, 'segments']]

    # reindex links to sparse indexes
    index = build_index(expanded_links[['a', 'b']].values)
    expanded_links['sparse_a'] = expanded_links['a'].apply(lambda x: index.get(x))
    expanded_links['sparse_b'] = expanded_links['b'].apply(lambda x: index.get(x))
    expanded_links['sparse_index'] = expanded_links['sparse_a']  # original link_a to add cost.
    expanded_links = expanded_links.reset_index().set_index(['sparse_a', 'sparse_b'])

    # turn penalties to sparse index tuple dict {(0,1): turn_penalty}
    turn_penalties = {(index.get(k), index.get(v)): turn_penalty for k, ls in turn_penalties.items() for v in ls}
    expanded_links['turn_penalty'] = expanded_links.index.map(turn_penalties).fillna(0)

    # add sparse index to links
    links['sparse_index'] = links.index.map(index)
    # remove zone to road here. dont need them anymore.
    links = links[~links['sparse_index'].isnull()]
    links = links.reset_index().set_index('sparse_index')  # keep index as column
    links.index = links.index.astype(int)
    nlen = max(links.index) + 1  # use in assigment. links may drop some index because we drop zones

    # initialization time
    links['jam_time'] = jam_time(to_polars(links), vdf, 'flow', time_col=time_col)
    for seg in segments:
        links[(seg, 'cost')] = apply_segment_cost(links, cost_functions.get(seg))
        _dict = links[(seg, 'cost')].to_dict()
        expanded_links[(seg, 'cost')] = expanded_links['sparse_index'].apply(lambda x: _dict.get(x, zone_penalty))
        expanded_links[(seg, 'cost')] += expanded_links['turn_penalty']

    # init track links
    if tracker_plugin():
        # only use for tracker. should change tracker to not use ab_volumes
        ab_volumes = init_numba_volumes(links.index)
        tracker_plugin.init(links_sparse_index=links.index, links_to_sparse=index)

    # pred origins and odv for each segments fro quick access as it doesnt change between iteration
    segment_origins = {}
    segment_odv = {}
    for seg in segments:
        segment_volumes, origins = get_sparse_volumes(volumes[volumes[seg] > 0], index)
        odv = segment_volumes[['origin_sparse', 'destination_sparse', seg]].values
        segment_origins[seg] = origins
        segment_odv[seg] = odv

    relgap = np.inf
    relgap_list = []
    phi = 1  # first iteration is AON
    beta = [1, 0, 0]  # bfw coefficients
    print('it  |  Phi    |  Rel Gap (%)') if log else None
    # note: first iteration i == 0 is AON to initialized.
    for i in range(maxiters + 1):
        #
        # Routing and assignment
        #
        for seg in segments:
            # filter links to allowed segment
            origins = segment_origins[seg]
            odv = segment_odv[seg]
            segment_links = expanded_links[expanded_links['segments'].apply(lambda x: seg in x)]
            _, pred = shortest_path(segment_links, (seg, 'cost'), index, origins, num_cores=num_cores)
            # assign volume
            volumes_arr = assign_volume_on_links_parallel(odv, pred, nlen, num_cores)
            links[(seg, 'auxiliary_flow')] = volumes_arr[links.index]  # links index may be not sorted are missing
            if tracker_plugin():
                tracker_plugin.assign(ab_volumes, odv, pred, seg, i)

        auxiliary_flow_cols = [(seg, 'auxiliary_flow') for seg in segments] + ['base_flow']
        links['auxiliary_flow'] = links[auxiliary_flow_cols].sum(axis=1)  # for phi and relgap

        #
        # Get relGap with AON flow
        #
        if i > 0:  # Skip first iteration (AON and relgap = -inf)
            relgap = get_relgap(links, segments)
            relgap_list.append(relgap)
            print(f'{i:2}  |  {phi:.3f}  |  {relgap:.8f}') if log else None

        #
        # find Phi, and BFW auxiliary flow modification
        #

        if i == 0:
            pass
        elif method == 'bfw':  # if biconjugate: takes the 2 last direction
            links['derivative'] = get_derivative(to_polars(links), vdf, cost_functions, segments, time_col=time_col)
            if i > 2:
                beta = find_beta(links, phi, segments)  # this is the previous phi (phi_-1)
            links = get_bfw_auxiliary_flow(links, beta, segments)
            links['auxiliary_flow'] = links[auxiliary_flow_cols].sum(axis=1)
            max_phi = 1 / i**0.5  # limit search space
            phi = find_phi(to_polars(links), segments, vdf, cost_functions, bounds=(0, max_phi), time_col=time_col)
        elif method == 'fw':
            max_phi = 1 / i**0.5  # limit search space
            phi = find_phi(to_polars(links), segments, vdf, cost_functions, bounds=(0, max_phi), time_col=time_col)
        else:  # msa
            phi = 1 / (i + 2)

        if tracker_plugin():
            tracker_plugin.add_weights(phi, beta, i)
        #
        # Update flow on links
        #

        for seg in segments:  # track per segments
            links[(seg, 'flow')] = (1 - phi) * links[(seg, 'flow')] + (phi * links[(seg, 'auxiliary_flow')])

        flow_cols = [(seg, 'flow') for seg in segments] + ['base_flow']
        links['flow'] = links[flow_cols].sum(axis=1)

        #
        # Update Time on links
        #

        links['jam_time'] = jam_time(to_polars(links), vdf, 'flow', time_col=time_col)
        for seg in segments:
            links[(seg, 'cost')] = apply_segment_cost(links, cost_functions.get(seg))
            _dict = links[(seg, 'cost')].to_dict()
            expanded_links[(seg, 'cost')] = expanded_links['sparse_index'].apply(lambda x: _dict.get(x, zone_penalty))
            expanded_links[(seg, 'cost')] += expanded_links['turn_penalty']

        # skip first iteration (AON asignment) as relgap in -inf
        if relgap <= tolerance:
            print('tolerance reached') if log else None
            break
    #
    # Finish: reindex back and get car_los
    #

    # drop columns
    to_drop = ['x1', 'x2', 'result', 'new_flow', 'derivative', 'auxiliary_flow']
    to_drop += [(seg, 's_k-1') for seg in segments]
    to_drop += [(seg, 's_k-2') for seg in segments]
    to_drop += [(seg, 'auxiliary_flow') for seg in segments]
    links = links.drop(columns=to_drop, errors='ignore')
    # go back to original indexes
    links = links.set_index(['a', 'b'])
    car_los = pd.DataFrame()
    if return_car_los:
        for seg in segments:
            # filter links to allowed segment
            segment_volumes, origins = get_sparse_volumes(volumes[volumes[seg] > 0], index)
            segment_links = expanded_links[expanded_links['segments'].apply(lambda x: seg in x)]
            temp_los = get_car_los(segment_volumes, segment_links, index, origins, (seg, 'cost'), num_cores)
            temp_los['segment'] = seg
            car_los = pd.concat([car_los, temp_los], ignore_index=True)

        # change path of links to path of nodes
        links_to_nodes_dict = {v: k for k, v in links['index'].to_dict().items()}
        car_los['path'] = car_los['path'].apply(lambda ls: expanded_path_to_nodes(ls, links_to_nodes_dict))

    return links, car_los, relgap_list
