"""Top-level scan orchestrator."""

from __future__ import annotations

from collections import Counter
from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import Path

from licensehound.parsers import parse_package_lock, parse_uv_lock
from licensehound.types import Package


@dataclass
class ScanResult:
    packages: list[Package]
    lockfiles: list[tuple[str, int]]  # (path, package count)
    license_counts: Counter[str]
    no_license_count: int


def find_lockfiles(root: Path) -> list[Path]:
    """Find supported lockfiles under root. Skips node_modules / .venv / .git."""
    skip_dirs = {"node_modules", ".venv", "venv", ".git", "dist", "build", "target", ".tox"}
    targets = {"package-lock.json", "uv.lock"}
    found: list[Path] = []
    for path in root.rglob("*"):
        if path.is_dir():
            continue
        if any(part in skip_dirs for part in path.parts):
            continue
        if path.name in targets:
            found.append(path)
    return sorted(found)


def scan(root: Path) -> ScanResult:
    """Walk root, parse every supported lockfile, return a unified result."""
    lockfiles = find_lockfiles(root)
    all_packages: list[Package] = []
    counts: list[tuple[str, int]] = []

    for lf in lockfiles:
        if lf.name == "package-lock.json":
            pkgs = parse_package_lock(lf)
        elif lf.name == "uv.lock":
            pkgs = parse_uv_lock(lf)
        else:
            continue
        all_packages.extend(pkgs)
        counts.append((str(lf), len(pkgs)))

    return ScanResult(
        packages=all_packages,
        lockfiles=counts,
        license_counts=_count_licenses(all_packages),
        no_license_count=sum(1 for p in all_packages if not p.license),
    )


def _count_licenses(packages: Iterable[Package]) -> Counter[str]:
    return Counter(p.license for p in packages if p.license)
