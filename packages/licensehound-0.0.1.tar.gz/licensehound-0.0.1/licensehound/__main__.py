"""CLI entry point: `licensehound scan [path]`."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from licensehound import __version__
from licensehound.scan import ScanResult, scan


def _format_human(result: ScanResult) -> str:
    lines: list[str] = []

    if not result.lockfiles:
        return (
            "No supported lockfiles found.\n"
            "LicenseHound v0.0.1 supports: package-lock.json (npm v2/v3), uv.lock (Python uv).\n"
            "More ecosystems coming — see https://github.com/istefanov87-svg/licensehound"
        )

    lines.append("Lockfiles scanned:")
    for path, n in result.lockfiles:
        lines.append(f"  ✓ {path} ({n} packages)")
    lines.append("")

    if result.license_counts:
        max_w = max(len(lic) for lic in result.license_counts) + 2
        lines.append("License summary:")
        for lic, n in result.license_counts.most_common():
            lines.append(f"  {lic.ljust(max_w)}{n} packages")

    if result.no_license_count:
        lines.append("")
        lines.append(
            f"  ⚠ {result.no_license_count} package(s) had no license metadata in the lockfile."
        )
        lines.append("    Review manually or upgrade your lockfile.")

    return "\n".join(lines)


def _format_json(result: ScanResult) -> str:
    return json.dumps(
        {
            "version": __version__,
            "lockfiles": [{"path": p, "package_count": n} for p, n in result.lockfiles],
            "license_counts": dict(result.license_counts),
            "no_license_count": result.no_license_count,
            "packages": [
                {
                    "ecosystem": p.ecosystem,
                    "name": p.name,
                    "version": p.version,
                    "license": p.license,
                    "source_lockfile": p.source_lockfile,
                }
                for p in result.packages
            ],
        },
        indent=2,
    )


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="licensehound",
        description="Find the open-source licenses in your dependency tree.",
    )
    parser.add_argument("--version", action="version", version=f"licensehound {__version__}")
    sub = parser.add_subparsers(dest="cmd", required=True)

    scan_p = sub.add_parser("scan", help="Scan a project directory for license info.")
    scan_p.add_argument("path", nargs="?", default=".", help="Project root (default: cwd)")
    scan_p.add_argument(
        "--json", action="store_true", help="Output JSON instead of human-readable."
    )

    args = parser.parse_args(argv)

    if args.cmd == "scan":
        root = Path(args.path).resolve()
        if not root.exists():
            print(f"error: {root} does not exist", file=sys.stderr)
            return 2
        result = scan(root)
        if args.json:
            print(_format_json(result))
        else:
            print(_format_human(result))
        return 0

    return 0


if __name__ == "__main__":
    sys.exit(main())
