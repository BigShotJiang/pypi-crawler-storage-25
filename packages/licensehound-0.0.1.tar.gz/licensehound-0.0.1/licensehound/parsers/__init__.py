"""Lockfile parsers, one module per ecosystem."""

from licensehound.parsers.npm import parse_package_lock
from licensehound.parsers.python_uv import parse_uv_lock

__all__ = ["parse_package_lock", "parse_uv_lock"]
