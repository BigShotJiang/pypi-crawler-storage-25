"""uv.lock parser. uv writes a TOML lockfile with one [[package]] entry per resolved dep."""

from __future__ import annotations

import tomllib
from pathlib import Path

from licensehound.types import Package


def parse_uv_lock(path: Path) -> list[Package]:
    """Each [[package]] entry has name, version, and may carry a license.

    uv records licenses in the `license` or `license-expression` field of each
    [[package]] entry. When neither is present, license metadata isn't in the
    lockfile and we'd have to fetch from PyPI — left for v0.0.2.
    """
    data = tomllib.loads(path.read_text())
    out: list[Package] = []
    seen: set[tuple[str, str]] = set()

    for pkg in data.get("package", []):
        name = pkg.get("name")
        version = pkg.get("version")
        if not name or not version:
            continue
        identity = (name, version)
        if identity in seen:
            continue
        seen.add(identity)

        # Prefer `license-expression` (SPDX expression) over `license` (free-form).
        license_raw: str | None = pkg.get("license-expression") or pkg.get("license") or None
        if isinstance(license_raw, dict):
            license_raw = license_raw.get("text") or None

        out.append(
            Package(
                ecosystem="pypi",
                name=name,
                version=version,
                license=license_raw,
                source_lockfile=str(path),
            )
        )

    return out
