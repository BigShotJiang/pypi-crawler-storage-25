"""npm package-lock.json parser. Supports lockfile v2 and v3 (npm 7+)."""

from __future__ import annotations

import json
from pathlib import Path

from licensehound.types import Package


def parse_package_lock(path: Path) -> list[Package]:
    """Walk the `packages` map and yield one Package per resolved entry.

    package-lock.json v2/v3 stores every resolved package — including transitive
    dependencies — under the `packages` key, with paths like "node_modules/foo"
    or "node_modules/foo/node_modules/bar". The root project lives at the empty
    key "" and we skip it.
    """
    data = json.loads(path.read_text())
    version = data.get("lockfileVersion", 1)
    if version < 2:
        # v1 doesn't have the rich `packages` map; fall back to `dependencies` walk.
        # For v0.0.1 we just refuse and ask the user to upgrade.
        raise ValueError(
            f"{path}: lockfileVersion {version} is not supported. "
            "Run `npm install` with npm 7+ to upgrade to v2."
        )

    out: list[Package] = []
    seen: set[tuple[str, str]] = set()  # dedupe by (name, version)

    for key, info in data.get("packages", {}).items():
        if key == "":
            continue
        # Last segment after node_modules/ is the package name.
        name = key.rsplit("node_modules/", 1)[-1]
        if not name:
            continue
        version_str = info.get("version", "")
        if not version_str:
            continue
        # Some entries are aliases or links to workspaces — skip if no version.
        identity = (name, version_str)
        if identity in seen:
            continue
        seen.add(identity)

        license_raw = info.get("license")
        # license can be a string ("MIT") or an object ({type: "MIT", url: ...}) in
        # very old packages. Normalise to the string form, or None.
        if isinstance(license_raw, dict):
            license_raw = license_raw.get("type") or None
        elif not isinstance(license_raw, str):
            license_raw = None

        out.append(
            Package(
                ecosystem="npm",
                name=name,
                version=version_str,
                license=license_raw,
                source_lockfile=str(path),
            )
        )

    return out
