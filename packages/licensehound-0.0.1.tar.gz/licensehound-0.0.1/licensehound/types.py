"""Shared types for the scanner."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Package:
    """A single package's identity + license, as resolved from a lockfile.

    `license` is the raw string from the lockfile; classification into SPDX
    happens in licensehound.spdx. `None` means the lockfile had no license
    metadata for this package — surface to the user, don't guess.
    """

    ecosystem: str  # "npm" | "pypi" | "cargo" | "go" | ...
    name: str
    version: str
    license: str | None
    source_lockfile: str
