"""uv.lock parser tests."""

from __future__ import annotations

from pathlib import Path

from licensehound.parsers.python_uv import parse_uv_lock

FIXTURE = Path(__file__).parent / "fixtures" / "sample-uv.lock"


def test_parse_uv_lock_extracts_all_packages() -> None:
    pkgs = parse_uv_lock(FIXTURE)
    names = {p.name for p in pkgs}
    assert names == {"requests", "urllib3", "pytest", "no-license-pkg"}


def test_license_expression_preferred_over_license() -> None:
    pkgs = parse_uv_lock(FIXTURE)
    urllib3 = next(p for p in pkgs if p.name == "urllib3")
    # Fixture has license-expression="MIT" — that's the SPDX expression we want.
    assert urllib3.license == "MIT"


def test_plain_license_field_works() -> None:
    pkgs = parse_uv_lock(FIXTURE)
    requests = next(p for p in pkgs if p.name == "requests")
    assert requests.license == "Apache-2.0"


def test_missing_license_yields_none() -> None:
    pkgs = parse_uv_lock(FIXTURE)
    no_lic = next(p for p in pkgs if p.name == "no-license-pkg")
    assert no_lic.license is None
