"""npm package-lock.json parser tests."""

from __future__ import annotations

from pathlib import Path

import pytest

from licensehound.parsers.npm import parse_package_lock

FIXTURE = Path(__file__).parent / "fixtures" / "sample-package-lock.json"


def test_parse_package_lock_v3_extracts_packages() -> None:
    pkgs = parse_package_lock(FIXTURE)
    names = {p.name for p in pkgs}
    assert "express" in names
    assert "accepts" in names
    # The duplicate accepts (transitive of express) is deduped because (name, version) match.
    assert sum(1 for p in pkgs if p.name == "accepts") == 1


def test_old_style_license_object_normalises_to_string() -> None:
    pkgs = parse_package_lock(FIXTURE)
    old = next(p for p in pkgs if p.name == "old-style-license")
    assert old.license == "BSD-2-Clause"


def test_missing_license_yields_none() -> None:
    pkgs = parse_package_lock(FIXTURE)
    no_lic = next(p for p in pkgs if p.name == "no-license-pkg")
    assert no_lic.license is None


def test_v1_lockfile_raises(tmp_path: Path) -> None:
    p = tmp_path / "package-lock.json"
    p.write_text('{"lockfileVersion": 1, "packages": {}}')
    with pytest.raises(ValueError, match="lockfileVersion 1"):
        parse_package_lock(p)
