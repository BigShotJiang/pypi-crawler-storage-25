"""Top-level scan orchestrator tests."""

from __future__ import annotations

import shutil
from pathlib import Path

import pytest

from licensehound.scan import find_lockfiles, scan

FIXTURES = Path(__file__).parent / "fixtures"


@pytest.fixture
def project_root(tmp_path: Path) -> Path:
    """A throwaway project tree with both a package-lock.json and a uv.lock."""
    shutil.copy(FIXTURES / "sample-package-lock.json", tmp_path / "package-lock.json")
    shutil.copy(FIXTURES / "sample-uv.lock", tmp_path / "uv.lock")
    # Add a node_modules subtree to verify it's skipped.
    nm = tmp_path / "node_modules" / "some-pkg"
    nm.mkdir(parents=True)
    (nm / "package-lock.json").write_text("{}")
    return tmp_path


def test_find_lockfiles_picks_up_supported(project_root: Path) -> None:
    found = find_lockfiles(project_root)
    names = {p.name for p in found}
    assert names == {"package-lock.json", "uv.lock"}
    # The node_modules one is excluded.
    assert all("node_modules" not in str(p) for p in found)


def test_scan_combines_results(project_root: Path) -> None:
    result = scan(project_root)
    # Both lockfiles surface in the report.
    assert len(result.lockfiles) == 2
    # We have at least the unique packages from both fixtures.
    names = {p.name for p in result.packages}
    assert "express" in names
    assert "requests" in names
    # License counts roll up correctly.
    assert result.license_counts["MIT"] >= 2
    # The packages with no license are flagged.
    assert result.no_license_count >= 2  # one from each fixture


def test_scan_empty_dir(tmp_path: Path) -> None:
    result = scan(tmp_path)
    assert result.packages == []
    assert result.lockfiles == []
    assert result.no_license_count == 0
