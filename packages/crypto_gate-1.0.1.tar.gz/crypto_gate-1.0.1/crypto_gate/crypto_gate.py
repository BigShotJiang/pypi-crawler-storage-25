"""
crypto_gate — Universal Cryptographic Toolkit (Python)
Built by Analytics With Harry - Squid Consultancy Group Limited

Zero external dependencies. Pure Python standard library.
Python >= 3.7 required.

Covers:
  - Password Hashing     : scrypt, PBKDF2-SHA512
  - Symmetric Encryption : AES-256-GCM
  - Hashing              : SHA-256/384/512, SHA3-256/512, BLAKE2b/BLAKE2s, MD5
  - HMAC                 : HMAC-SHA256/SHA512
  - Key Derivation       : scrypt, PBKDF2
  - Secure Tokens        : UUID, OTP, API keys, recovery keys
  - Timing-safe compare
"""

import hashlib
import hmac as _hmac
import secrets
import base64
import os
import struct
import uuid as _uuid_mod
from typing import Optional, Tuple, Dict, Any

__version__ = "1.0.0"
__all__ = [
    "PasswordHasher",
    "AESCipher",
    "Hasher",
    "KeyDeriver",
    "TokenGenerator",
    "Encoder",
    "CryptoGate",
    "timing_safe_equal",
]

# ─── Constants ──────────────────────────────────────────────────────────────

_SALT_LENGTH     = 32   # 256-bit salt
_HASH_VERSION    = "v1"
_AES_KEY_LENGTH  = 32   # 256-bit AES key
_AES_IV_LENGTH   = 12   # 96-bit GCM IV
_AES_TAG_LENGTH  = 16   # 128-bit GCM tag

_SCRYPT_DEFAULTS = {"n": 32768, "r": 8, "p": 1, "keylen": 64}
_PBKDF2_DEFAULTS = {"iterations": 310000, "keylen": 64, "digest": "sha512"}


def _resolve_scrypt_maxmem(n: int, r: int) -> int:
    """Return a safe maxmem value for scrypt on constrained OpenSSL builds."""
    required = 128 * n * r
    return max(256 * 1024 * 1024, required + 1024 * 1024)

# ─── Utilities ──────────────────────────────────────────────────────────────

def timing_safe_equal(a: str, b: str) -> bool:
    """Timing-safe string comparison. Prevents timing-based side-channel attacks."""
    ba = a.encode("utf-8") if isinstance(a, str) else a
    bb = b.encode("utf-8") if isinstance(b, str) else b
    return _hmac.compare_digest(ba, bb)


def _assert_string(value: Any, name: str) -> None:
    if not isinstance(value, (str, bytes)) or len(value) == 0:
        raise TypeError(f"[CryptoGate] {name} must be a non-empty string or bytes")


# ─── Password Hashing ───────────────────────────────────────────────────────

class PasswordHasher:
    """
    Secure password hashing using scrypt (memory-hard) and PBKDF2-SHA512.

    Hash format (scrypt):  $cgscrypt$v1$N$r$p$<salt_hex>$<hash_hex>
    Hash format (PBKDF2):  $cgpbkdf2$v1$iterations$digest$<salt_hex>$<hash_hex>
    """

    @staticmethod
    def hash(
        password: str,
        n: int = _SCRYPT_DEFAULTS["n"],
        r: int = _SCRYPT_DEFAULTS["r"],
        p: int = _SCRYPT_DEFAULTS["p"],
        keylen: int = _SCRYPT_DEFAULTS["keylen"],
    ) -> str:
        """
        Hash a password using scrypt (memory-hard, superior to bcrypt/md5/sha).

        Args:
            password: The password to hash
            n:        CPU/memory cost factor (power of 2, default 32768)
            r:        Block size (default 8)
            p:        Parallelisation factor (default 1)
            keylen:   Output key length in bytes (default 64)

        Returns:
            Encoded hash string: $cgscrypt$v1$N$r$p$<salt_hex>$<hash_hex>
        """
        _assert_string(password, "password")
        pw = password.encode("utf-8") if isinstance(password, str) else password
        if len(pw) > 1024:
            raise ValueError("[CryptoGate] Password exceeds maximum length of 1024 bytes")

        salt = secrets.token_bytes(_SALT_LENGTH)
        key  = hashlib.scrypt(
            pw,
            salt=salt,
            n=n,
            r=r,
            p=p,
            dklen=keylen,
            maxmem=_resolve_scrypt_maxmem(n, r),
        )

        return f"$cgscrypt${_HASH_VERSION}${n}${r}${p}${salt.hex()}${key.hex()}"

    @staticmethod
    def verify(password: str, encoded: str) -> bool:
        """
        Verify a password against a stored scrypt hash. Uses timing-safe comparison.

        Args:
            password: The password to test
            encoded:  Hash produced by hash()

        Returns:
            True if password matches, False otherwise
        """
        _assert_string(password, "password")
        _assert_string(encoded, "encoded")

        parts = encoded.split("$")
        # $cgscrypt$v1$N$r$p$salt$hash → parts[0]='' [1]='cgscrypt' ...
        if len(parts) != 8 or parts[1] != "cgscrypt":
            raise ValueError("[CryptoGate] Invalid hash format")

        n      = int(parts[3])
        r      = int(parts[4])
        p      = int(parts[5])
        salt   = bytes.fromhex(parts[6])
        stored = bytes.fromhex(parts[7])
        keylen = len(stored)

        pw = password.encode("utf-8") if isinstance(password, str) else password
        derived = hashlib.scrypt(
            pw,
            salt=salt,
            n=n,
            r=r,
            p=p,
            dklen=keylen,
            maxmem=_resolve_scrypt_maxmem(n, r),
        )
        return _hmac.compare_digest(derived, stored)

    @staticmethod
    def hash_pbkdf2(
        password: str,
        iterations: int = _PBKDF2_DEFAULTS["iterations"],
        keylen: int = _PBKDF2_DEFAULTS["keylen"],
        digest: str = _PBKDF2_DEFAULTS["digest"],
    ) -> str:
        """
        Hash a password using PBKDF2-SHA512 (310,000 iterations — OWASP recommended).

        Returns:
            Encoded hash: $cgpbkdf2$v1$iterations$digest$<salt_hex>$<hash_hex>
        """
        _assert_string(password, "password")
        pw   = password.encode("utf-8") if isinstance(password, str) else password
        salt = secrets.token_bytes(_SALT_LENGTH)
        key  = hashlib.pbkdf2_hmac(digest, pw, salt, iterations, dklen=keylen)
        return f"$cgpbkdf2${_HASH_VERSION}${iterations}${digest}${salt.hex()}${key.hex()}"

    @staticmethod
    def verify_pbkdf2(password: str, encoded: str) -> bool:
        """Verify a password against a stored PBKDF2 hash."""
        _assert_string(password, "password")
        _assert_string(encoded, "encoded")

        parts = encoded.split("$")
        if len(parts) != 7 or parts[1] != "cgpbkdf2":
            raise ValueError("[CryptoGate] Invalid PBKDF2 hash format")

        iterations = int(parts[3])
        digest     = parts[4]
        salt       = bytes.fromhex(parts[5])
        stored     = bytes.fromhex(parts[6])
        keylen     = len(stored)

        pw = password.encode("utf-8") if isinstance(password, str) else password
        derived = hashlib.pbkdf2_hmac(digest, pw, salt, iterations, dklen=keylen)
        return _hmac.compare_digest(derived, stored)

    @staticmethod
    def analyze_strength(password: str) -> Dict[str, Any]:
        """
        Analyze password strength.

        Returns:
            dict with keys: score (int), strength (str), suggestions (list[str])
        """
        import re
        _assert_string(password, "password")

        score = 0
        suggestions = []

        if len(password) >= 8:  score += 1
        else: suggestions.append("Use at least 8 characters")

        if len(password) >= 12: score += 1
        else: suggestions.append("Use at least 12 characters for better security")

        if len(password) >= 16: score += 1

        if re.search(r"[a-z]", password): score += 1
        else: suggestions.append("Add lowercase letters")

        if re.search(r"[A-Z]", password): score += 1
        else: suggestions.append("Add uppercase letters")

        if re.search(r"[0-9]", password): score += 1
        else: suggestions.append("Add numbers")

        if re.search(r"[^a-zA-Z0-9]", password): score += 1
        else: suggestions.append("Add special characters (!@#$%^&*)")

        if not re.search(r"(.)\1{2,}", password): score += 1
        else: suggestions.append("Avoid repeating characters")

        levels = ["Very Weak", "Weak", "Weak", "Fair", "Good",
                  "Strong", "Very Strong", "Excellent", "Excellent"]
        return {"score": score, "strength": levels[score], "suggestions": suggestions}


# ─── Symmetric Encryption (AES-256-GCM) ─────────────────────────────────────

class AESCipher:
    """
    AES-256-GCM authenticated encryption.

    Requires Python 3.7+ with the `cryptography` package OR uses
    a pure stdlib fallback via `ssl`/`ctypes`. For full AES-GCM support
    this module uses the `cryptography` package if available, with a
    clear error message if not installed.

    To install: pip install cryptography
    """

    @staticmethod
    def _get_backend():
        try:
            from cryptography.hazmat.primitives.ciphers.aead import AESGCM
            return AESGCM
        except ImportError:
            raise ImportError(
                "[CryptoGate] AES-256-GCM requires: pip install cryptography"
            )

    @staticmethod
    def generate_key() -> str:
        """Generate a cryptographically secure 256-bit AES key (64-char hex)."""
        return secrets.token_bytes(_AES_KEY_LENGTH).hex()

    @staticmethod
    def encrypt(data: str, key: str) -> str:
        """
        Encrypt data using AES-256-GCM.

        Args:
            data: Plaintext string to encrypt
            key:  64-char hex key (from generate_key()) or any passphrase

        Returns:
            Encrypted payload: <iv_hex>:<tag_hex>:<ciphertext_hex>
        """
        _assert_string(data, "data")
        _assert_string(key, "key")

        AESGCM = AESCipher._get_backend()
        key_bytes = AESCipher._resolve_key(key)
        iv = secrets.token_bytes(_AES_IV_LENGTH)
        aesgcm = AESGCM(key_bytes)

        data_bytes = data.encode("utf-8") if isinstance(data, str) else data
        # encrypt returns ciphertext + tag
        ct_and_tag = aesgcm.encrypt(iv, data_bytes, None)
        # AESGCM appends 16-byte tag at end
        ciphertext = ct_and_tag[:-_AES_TAG_LENGTH]
        tag        = ct_and_tag[-_AES_TAG_LENGTH:]

        return f"{iv.hex()}:{tag.hex()}:{ciphertext.hex()}"

    @staticmethod
    def decrypt(payload: str, key: str) -> str:
        """
        Decrypt AES-256-GCM encrypted payload.

        Args:
            payload: Output from encrypt()
            key:     Same key used for encryption

        Returns:
            Plaintext string
        """
        _assert_string(payload, "payload")
        _assert_string(key, "key")

        AESGCM = AESCipher._get_backend()
        parts = payload.split(":")
        if len(parts) != 3:
            raise ValueError("[CryptoGate] Invalid AES payload format")

        iv         = bytes.fromhex(parts[0])
        tag        = bytes.fromhex(parts[1])
        ciphertext = bytes.fromhex(parts[2])
        key_bytes  = AESCipher._resolve_key(key)

        aesgcm = AESGCM(key_bytes)
        # decrypt expects ciphertext + tag concatenated
        decrypted = aesgcm.decrypt(iv, ciphertext + tag, None)
        return decrypted.decode("utf-8")

    @staticmethod
    def derive_key(passphrase: str, salt: Optional[str] = None) -> Dict[str, str]:
        """
        Derive a 256-bit AES key from a passphrase using scrypt.

        Args:
            passphrase: Any string
            salt:       Hex salt (generated if not provided)

        Returns:
            dict with 'key' (hex) and 'salt' (hex)
        """
        _assert_string(passphrase, "passphrase")
        salt_bytes = bytes.fromhex(salt) if salt else secrets.token_bytes(_SALT_LENGTH)
        pw = passphrase.encode("utf-8") if isinstance(passphrase, str) else passphrase
        key = hashlib.scrypt(
            pw,
            salt=salt_bytes,
            n=16384,
            r=8,
            p=1,
            dklen=_AES_KEY_LENGTH,
            maxmem=_resolve_scrypt_maxmem(16384, 8),
        )
        return {"key": key.hex(), "salt": salt_bytes.hex()}

    @staticmethod
    def _resolve_key(key: str) -> bytes:
        """Resolve key from hex string or passphrase."""
        if isinstance(key, bytes) and len(key) == _AES_KEY_LENGTH:
            return key
        if isinstance(key, str) and len(key) == 64:
            try:
                k = bytes.fromhex(key)
                if len(k) == _AES_KEY_LENGTH:
                    return k
            except ValueError:
                pass
        # Derive 32 bytes from any string via SHA-256
        k = key.encode("utf-8") if isinstance(key, str) else key
        return hashlib.sha256(k).digest()


# ─── Hashing ────────────────────────────────────────────────────────────────

class Hasher:
    """
    One-stop hashing: SHA-256/384/512, SHA3-256/512, BLAKE2b, BLAKE2s,
    MD5, HMAC-SHA256/512.
    """

    @staticmethod
    def sha256(data, encoding: str = "hex") -> str:
        d = data.encode("utf-8") if isinstance(data, str) else data
        h = hashlib.sha256(d).digest()
        return Hasher._encode(h, encoding)

    @staticmethod
    def sha384(data, encoding: str = "hex") -> str:
        d = data.encode("utf-8") if isinstance(data, str) else data
        h = hashlib.sha384(d).digest()
        return Hasher._encode(h, encoding)

    @staticmethod
    def sha512(data, encoding: str = "hex") -> str:
        d = data.encode("utf-8") if isinstance(data, str) else data
        h = hashlib.sha512(d).digest()
        return Hasher._encode(h, encoding)

    @staticmethod
    def sha3_256(data, encoding: str = "hex") -> str:
        d = data.encode("utf-8") if isinstance(data, str) else data
        h = hashlib.sha3_256(d).digest()
        return Hasher._encode(h, encoding)

    @staticmethod
    def sha3_512(data, encoding: str = "hex") -> str:
        d = data.encode("utf-8") if isinstance(data, str) else data
        h = hashlib.sha3_512(d).digest()
        return Hasher._encode(h, encoding)

    @staticmethod
    def blake2b(data, digest_size: int = 64, encoding: str = "hex") -> str:
        d = data.encode("utf-8") if isinstance(data, str) else data
        h = hashlib.blake2b(d, digest_size=digest_size).digest()
        return Hasher._encode(h, encoding)

    @staticmethod
    def blake2s(data, digest_size: int = 32, encoding: str = "hex") -> str:
        d = data.encode("utf-8") if isinstance(data, str) else data
        h = hashlib.blake2s(d, digest_size=digest_size).digest()
        return Hasher._encode(h, encoding)

    @staticmethod
    def md5(data) -> str:
        """MD5 — for legacy/non-security use only."""
        d = data.encode("utf-8") if isinstance(data, str) else data
        return hashlib.md5(d).hexdigest()

    @staticmethod
    def hmac_sha256(data, key, encoding: str = "hex") -> str:
        d = data.encode("utf-8") if isinstance(data, str) else data
        k = key.encode("utf-8") if isinstance(key, str) else key
        h = _hmac.new(k, d, hashlib.sha256).digest()
        return Hasher._encode(h, encoding)

    @staticmethod
    def hmac_sha512(data, key, encoding: str = "hex") -> str:
        d = data.encode("utf-8") if isinstance(data, str) else data
        k = key.encode("utf-8") if isinstance(key, str) else key
        h = _hmac.new(k, d, hashlib.sha512).digest()
        return Hasher._encode(h, encoding)

    @staticmethod
    def hmac(data, key, algorithm: str = "sha256", encoding: str = "hex") -> str:
        """HMAC with custom hashlib algorithm name."""
        d = data.encode("utf-8") if isinstance(data, str) else data
        k = key.encode("utf-8") if isinstance(key, str) else key
        digestmod = getattr(hashlib, algorithm)
        h = _hmac.new(k, d, digestmod).digest()
        return Hasher._encode(h, encoding)

    @staticmethod
    def compare(a: str, b: str) -> bool:
        """Timing-safe comparison of two hash strings."""
        return timing_safe_equal(a, b)

    @staticmethod
    def _encode(digest: bytes, encoding: str) -> str:
        if encoding == "hex":
            return digest.hex()
        elif encoding == "base64":
            return base64.b64encode(digest).decode("ascii")
        elif encoding == "base64url":
            return base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")
        elif encoding == "bytes":
            return digest
        raise ValueError(f"[CryptoGate] Unknown encoding: {encoding}")


# ─── Key Derivation ─────────────────────────────────────────────────────────

class KeyDeriver:
    """Key derivation using scrypt and PBKDF2."""

    @staticmethod
    def scrypt(
        password,
        salt: Optional[str] = None,
        keylen: int = 64,
        n: int = 32768,
        r: int = 8,
        p: int = 1,
    ) -> Dict[str, str]:
        """
        Derive key using scrypt.

        Returns:
            dict with 'key' (hex) and 'salt' (hex)
        """
        pw = password.encode("utf-8") if isinstance(password, str) else password
        salt_bytes = bytes.fromhex(salt) if salt else secrets.token_bytes(_SALT_LENGTH)
        key = hashlib.scrypt(
            pw,
            salt=salt_bytes,
            n=n,
            r=r,
            p=p,
            dklen=keylen,
            maxmem=_resolve_scrypt_maxmem(n, r),
        )
        return {"key": key.hex(), "salt": salt_bytes.hex()}

    @staticmethod
    def pbkdf2(
        password,
        salt: Optional[str] = None,
        keylen: int = 64,
        iterations: int = 310000,
        digest: str = "sha512",
    ) -> Dict[str, str]:
        """
        Derive key using PBKDF2.

        Returns:
            dict with 'key' (hex) and 'salt' (hex)
        """
        pw = password.encode("utf-8") if isinstance(password, str) else password
        salt_bytes = bytes.fromhex(salt) if salt else secrets.token_bytes(_SALT_LENGTH)
        key = hashlib.pbkdf2_hmac(digest, pw, salt_bytes, iterations, dklen=keylen)
        return {"key": key.hex(), "salt": salt_bytes.hex()}


# ─── Secure Token Generation ─────────────────────────────────────────────────

class TokenGenerator:
    """Cryptographically secure token generation."""

    @staticmethod
    def random(num_bytes: int = 32, encoding: str = "hex") -> str:
        """Generate a random token."""
        buf = secrets.token_bytes(num_bytes)
        if encoding == "hex":
            return buf.hex()
        elif encoding == "base64":
            return base64.b64encode(buf).decode("ascii")
        elif encoding == "base64url":
            return base64.urlsafe_b64encode(buf).rstrip(b"=").decode("ascii")
        raise ValueError(f"[CryptoGate] Unknown encoding: {encoding}")

    @staticmethod
    def uuid() -> str:
        """Generate a UUID v4."""
        return str(_uuid_mod.uuid4())

    @staticmethod
    def otp(digits: int = 6) -> str:
        """Generate a numeric OTP (One-Time Password)."""
        if digits < 4 or digits > 10:
            raise ValueError("[CryptoGate] OTP digits must be between 4 and 10")
        max_val = 10 ** digits
        # Use secrets.randbelow for unbiased random
        n = secrets.randbelow(max_val)
        return str(n).zfill(digits)

    @staticmethod
    def api_key(prefix: str = "live", num_bytes: int = 24) -> str:
        """Generate an API key: cg_<prefix>_<randomhex>."""
        return f"cg_{prefix}_{secrets.token_hex(num_bytes)}"

    @staticmethod
    def recovery_key(groups: int = 4) -> str:
        """
        Generate a human-readable recovery key.
        e.g. 'A3F2-88BC-4E19-DD73'
        """
        raw = secrets.token_bytes(groups * 2).hex().upper()
        return "-".join(raw[i:i+4] for i in range(0, len(raw), 4))

    @staticmethod
    def bytes(length: int) -> bytes:
        """Generate raw random bytes."""
        return secrets.token_bytes(length)

    @staticmethod
    def random_int(min_val: int, max_val: int) -> int:
        """Generate a secure random integer in [min_val, max_val] inclusive."""
        return secrets.randbelow(max_val - min_val + 1) + min_val


# ─── Encoding Helpers ────────────────────────────────────────────────────────

class Encoder:
    """Encoding and decoding utilities."""

    @staticmethod
    def to_base64(data) -> str:
        d = data.encode("utf-8") if isinstance(data, str) else data
        return base64.b64encode(d).decode("ascii")

    @staticmethod
    def from_base64(s: str) -> str:
        return base64.b64decode(s).decode("utf-8")

    @staticmethod
    def to_base64url(data) -> str:
        d = data.encode("utf-8") if isinstance(data, str) else data
        return base64.urlsafe_b64encode(d).rstrip(b"=").decode("ascii")

    @staticmethod
    def from_base64url(s: str) -> str:
        padding = 4 - len(s) % 4
        if padding != 4:
            s += "=" * padding
        return base64.urlsafe_b64decode(s).decode("utf-8")

    @staticmethod
    def to_hex(data) -> str:
        d = data.encode("utf-8") if isinstance(data, str) else data
        return d.hex()

    @staticmethod
    def from_hex(s: str) -> str:
        return bytes.fromhex(s).decode("utf-8")

    @staticmethod
    def bytes_to_hex(b: bytes) -> str:
        return b.hex()

    @staticmethod
    def hex_to_bytes(s: str) -> bytes:
        return bytes.fromhex(s)


# ─── Main CryptoGate Class ───────────────────────────────────────────────────

class CryptoGate:
    """
    crypto-gate — Universal Cryptographic Toolkit

    A unified interface to all crypto primitives.

    Usage:
        from crypto_gate import CryptoGate

        cg = CryptoGate()
        hash = cg.password.hash("mypassword")
        valid = cg.password.verify("mypassword", hash)
        token = cg.token.uuid()
        digest = cg.hash.sha256("hello")
    """

    def __init__(self):
        self.password = PasswordHasher
        self.aes      = AESCipher
        self.hash     = Hasher
        self.kdf      = KeyDeriver
        self.token    = TokenGenerator
        self.encode   = Encoder
        self.utils    = {"timing_safe_equal": timing_safe_equal}
        self.version  = __version__

    @staticmethod
    def supported_algorithms():
        """List all supported hashlib algorithms."""
        return sorted(hashlib.algorithms_available)
