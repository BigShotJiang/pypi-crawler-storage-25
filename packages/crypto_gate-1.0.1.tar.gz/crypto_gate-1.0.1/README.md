# crypto-gate (Python)

**Universal Cryptographic Toolkit** — by [Analytics With Harry](https://github.com/analyticswithharry) · Squid Consultancy Group Limited

[![PyPI version](https://img.shields.io/pypi/v/crypto-gate.svg)](https://pypi.org/project/crypto-gate/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![Python ≥3.7](https://img.shields.io/badge/python-%3E%3D3.7-blue.svg)](https://python.org/)

---

## Why crypto-gate?

> **One package. Every crypto primitive you need. Minimal dependencies.**

`crypto-gate` wraps Python's built-in `hashlib`, `hmac`, and `secrets` modules into a clean, consistent API.

- **Password Hashing** — `scrypt` (memory-hard) + `PBKDF2-SHA512`
- **Symmetric Encryption** — `AES-256-GCM` authenticated encryption (via `cryptography`)
- **Hashing** — `SHA-256/384/512`, `SHA3-256/512`, `BLAKE2b/BLAKE2s`, `MD5`
- **HMAC** — `HMAC-SHA256/SHA512`
- **Key Derivation** — `scrypt`, `PBKDF2`
- **Secure Tokens** — UUID v4, OTP, API keys, recovery keys
- **Timing-safe comparison**

---

## Installation

```bash
pip install crypto-gate
```

Requires **Python ≥ 3.7**.

---

## Quick Start

```python
from crypto_gate import PasswordHasher, Hasher, TokenGenerator

# Hash a password
hash = PasswordHasher.hash("my-secret-password")
print(hash)  # $cgscrypt$v1$32768$8$1$<salt>$<hash>

# Verify
ok = PasswordHasher.verify("my-secret-password", hash)
print(ok)  # True

# SHA-256
print(Hasher.sha256("hello world"))

# UUID
print(TokenGenerator.uuid())

# OTP
print(TokenGenerator.otp(6))  # 847291
```

---

## API Reference

### PasswordHasher

```python
# scrypt (memory-hard, NIST-recommended)
hash = PasswordHasher.hash("password", n=32768, r=8, p=1, keylen=64)
ok   = PasswordHasher.verify("password", hash)

# PBKDF2-SHA512
hash = PasswordHasher.hash_pbkdf2("password", iterations=310000, keylen=64, digest="sha512")
ok   = PasswordHasher.verify_pbkdf2("password", hash)

# Strength analysis
result = PasswordHasher.analyze_strength("P@ssw0rd!")
# {"score": 7, "strength": "Very Strong", "suggestions": []}
```

### AESCipher

```python
from crypto_gate import AESCipher

key = AESCipher.generate_key()
enc = AESCipher.encrypt("sensitive data", key)
dec = AESCipher.decrypt(enc, key)

# Key from passphrase
kd = AESCipher.derive_key("my-passphrase")
enc = AESCipher.encrypt("data", kd["key"])
```

### Hasher

```python
from crypto_gate import Hasher

Hasher.sha256("data")          # hex
Hasher.sha512("data")          # hex
Hasher.sha3_256("data")        # hex
Hasher.sha3_512("data")        # hex
Hasher.blake2b("data")         # hex (64-byte digest)
Hasher.blake2s("data")         # hex (32-byte digest)
Hasher.md5("data")             # hex (legacy only)

# HMAC
Hasher.hmac_sha256("msg", "key")
Hasher.hmac_sha512("msg", "key")
Hasher.hmac("msg", "key", algorithm="sha384")

# Encodings
Hasher.sha256("data", encoding="base64")
Hasher.sha256("data", encoding="bytes")    # returns bytes

# Timing-safe compare
Hasher.compare(hash_a, hash_b)
```

### KeyDeriver

```python
from crypto_gate import KeyDeriver

r = KeyDeriver.scrypt("password", salt=None, keylen=64, n=32768, r=8, p=1)
# r = {"key": "hex...", "salt": "hex..."}

r = KeyDeriver.pbkdf2("password", salt=None, keylen=64, iterations=310000, digest="sha512")
```

### TokenGenerator

```python
from crypto_gate import TokenGenerator

TokenGenerator.random(32, "hex")         # 64-char hex token
TokenGenerator.random(32, "base64url")   # URL-safe base64

TokenGenerator.uuid()                    # "550e8400-e29b-41d4-a716-..."
TokenGenerator.otp(6)                    # "847291"
TokenGenerator.api_key("live")           # "cg_live_3f7a8b9c..."
TokenGenerator.recovery_key(4)           # "A3F2-88BC-4E19-DD73"
TokenGenerator.bytes(16)                 # b'\x3a\x7f...' — raw bytes
TokenGenerator.random_int(1, 100)        # secure random int in [1, 100]
```

### Encoder

```python
from crypto_gate import Encoder

Encoder.to_base64("hello")          # 'aGVsbG8='
Encoder.from_base64('aGVsbG8=')     # 'hello'
Encoder.to_base64url("hello world")
Encoder.from_base64url(s)
Encoder.to_hex("hello")             # '68656c6c6f'
Encoder.from_hex('68656c6c6f')      # 'hello'
Encoder.bytes_to_hex(b"data")
Encoder.hex_to_bytes("646174")
```

### `timing_safe_equal`

```python
from crypto_gate import timing_safe_equal

timing_safe_equal(hash_a, hash_b)  # bool — constant-time comparison
```

---

## Security Notes

- **scrypt vs bcrypt**: `scrypt` is memory-hard and more resistant to GPU/ASIC attacks. Recommended for new systems.
- **AES-256-GCM**: Authenticated encryption provides both confidentiality and integrity.
- **Timing-safe comparison**: Always use `timing_safe_equal` or `Hasher.compare` for secret comparison.

---

## Node.js Package

A companion Node.js implementation is available on npm with the same API structure, using only the built-in `crypto` module.

```bash
npm install crypto-gate
```

---

## License

MIT © [Analytics With Harry - Squid Consultancy Group Limited](https://github.com/analyticswithharry)
