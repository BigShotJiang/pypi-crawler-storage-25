from setuptools import setup, find_packages

with open("README.md", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="crypto-gate",
    version="1.0.1",
    description="Universal cryptographic toolkit — password hashing, AES-256-GCM, SHA3, BLAKE2, PBKDF2, scrypt, secure tokens. Zero external dependencies.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Analytics With Harry - Squid Consultancy Group Limited",
    author_email="hemantthapa1998@gmail.com",
    url="https://github.com/analyticswithharry/crypto-gate",
    project_urls={
        "Bug Reports": "https://github.com/analyticswithharry/crypto-gate/issues",
        "Source":      "https://github.com/analyticswithharry/crypto-gate",
        "Documentation": "https://github.com/analyticswithharry/crypto-gate#readme",
        "Homepage":    "https://github.com/analyticswithharry/crypto-gate",
    },
    packages=find_packages(),
    python_requires=">=3.7",
    install_requires=[
        # AES-256-GCM support (optional, fallback error message if missing)
        "cryptography>=3.4",
    ],
    extras_require={
        "dev": ["pytest>=7.0"],
    },
    keywords=[
        "crypto", "cryptography", "password-hashing", "scrypt", "pbkdf2",
        "aes", "aes-256-gcm", "sha256", "sha512", "sha3", "blake2", "hmac",
        "encryption", "decryption", "token", "otp", "uuid", "key-derivation",
        "security", "authentication",
    ],
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Security :: Cryptography",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Operating System :: OS Independent",
    ],
    license="MIT",
)
