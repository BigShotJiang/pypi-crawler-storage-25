CODE_EXP1 = """from sklearn import datasets
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

# Load iris dataset
iris = datasets.load_iris()

# Create dataframe
df = pd.DataFrame(iris.data, columns=iris.feature_names)
df['variety'] = iris.target

# ---------------- UNIVARIATE ----------------
plt.scatter(df['sepal width (cm)'], np.zeros_like(df['sepal width (cm)']))
plt.xlabel("Sepal Width")
plt.title("Univariate")
plt.show()

# ---------------- BIVARIATE ----------------
sns.scatterplot(x=df['sepal length (cm)'],
                y=df['petal length (cm)'],
                hue='variety',
                data=df)
plt.title("BIvariate")
plt.show()

# ---------------- MULTIVARIATE ----------------
sns.pairplot(df, hue='variety')
plt.title("Multivariate")
plt.show()

print("Analysis completed")"""

CODE_EXP2 = """import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from sklearn.linear_model import LinearRegression

# Load dataset
data = pd.read_csv("headbrain.csv")

# Input and output
x = np.array(data['Head Size(cm^3)'])
y = np.array(data['Brain Weight(grams)'])

# Mean values
x_mean = np.mean(x)
y_mean = np.mean(y)

# Calculate slope (m) and intercept (c)
m = np.sum((x - x_mean) * (y - y_mean)) / np.sum((x - x_mean)**2)
c = y_mean - m * x_mean

print("Slope =", m)
print("Intercept =", c)

# Regression line
Y = m * x + c

# Plot graph
plt.scatter(x, y, color='green')
plt.plot(x, Y, color='red')
plt.xlabel("Head Size(cm^3)")
plt.ylabel("Brain Weight(grams)")
plt.show()

# Using sklearn
x = x.reshape(-1, 1)

model = LinearRegression()
model.fit(x, y)

print("Accuracy:", model.score(x, y))

print("Regression completed")"""

CODE_EXP3 = """import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression

data = pd.DataFrame({
    "X": [1, 2, 3, 4, 5],
    "Y": [2, 4, 5, 4, 5]
})

X = data[["X"]]
y = data["Y"]

model = LinearRegression()
model.fit(X, y)

print("Slope:", model.coef_[0])
print("Intercept:", model.intercept_)
print("accuracy: ",model.score(X,y))
print("Prediction for X=6:", model.predict([[6]]))

# Graph
plt.scatter(X, y)
plt.plot(X, model.predict(X))
plt.title("Linear Regression")
plt.xlabel("X")
plt.ylabel("Y")
plt.show()"""

CODE_EXP4 = """# Logistic Regression

from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import matplotlib.pyplot as plt

# Sample data
# [Hours Studied, Attendance]
X = [
    [2, 50],
    [4, 60],
    [6, 70],
    [8, 80],
    [10, 90]
]

# Result (0 = Fail, 1 = Pass)
y = [0, 0, 1, 1, 1]

# Split dataset
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=1
)

# Create Logistic Regression model
model = LogisticRegression()

# Train model
model.fit(X_train, y_train)

# Predict
y_pred = model.predict(X_test)

# Accuracy
print("Accuracy:", accuracy_score(y_test, y_pred))

# Predict new data
new_data = [[7, 75]]

prediction = model.predict(new_data)

print("Prediction for", new_data, "=", prediction[0])

# Probability prediction
print("Prediction Probability:", model.predict_proba(new_data))

# Simple graph
hours = [i[0] for i in X]
attendance = [i[1] for i in X]

plt.scatter(hours, attendance)
plt.xlabel("Hours Studied")
plt.ylabel("Attendance")
plt.title("Student Data")


plt.scatter(new_data[0][0],new_data[0][1],marker='X',s=300)
plt.show()"""

CODE_EXP5 = """import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LogisticRegression

data = pd.DataFrame({
    "Age": [2,4,6,8,10],
    "Salary": [50,60,70,80,90],
    "Purchased": [0, 0, 1, 1, 1]
})

X = data[["Age", "Salary"]]
y = data["Purchased"]

model = LogisticRegression()
model.fit(X, y)

print("Prediction:", model.predict([[7, 75]]))
print("accuracy",model.score(X,y))
print("Pred probability",model.predict_proba([[7, 75]]))

# Graph
plt.scatter(data["Age"], data["Salary"])
plt.title("Logistic Regression")
plt.xlabel("Age")
plt.ylabel("Salary")
plt.show()"""

CODE_EXP6 = """# Decision Tree Classifier

from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn import tree
import matplotlib.pyplot as plt

# Sample data
# [Hours Studied, Attendance]
X = [
    [2, 50],
    [4, 60],
    [6, 70],
    [8, 80],
    [10, 90]
]

# Result (0 = Fail, 1 = Pass)
y = [0, 0, 1, 1, 1]

# Split dataset
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=1
)

# Create Decision Tree model
model = DecisionTreeClassifier()

# Train model
model.fit(X_train, y_train)

# Predict
y_pred = model.predict(X_test)

# Accuracy
print("Accuracy:", accuracy_score(y_test, y_pred))

# Predict new data
new_data = [[7, 75]]

prediction = model.predict(new_data)

print("Prediction for", new_data, "=", prediction[0])

tree.plot_tree(model, filled=True)
plt.show()"""

CODE_EXP7 = """# Boosting using AdaBoost

from sklearn.ensemble import AdaBoostClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

# Sample dataset
X = [
    [1, 20],
    [2, 25],
    [3, 30],
    [4, 35],
    [5, 40],
    [6, 45],
    [7, 50],
    [8, 55]
]

# Labels
y = [0, 0, 0, 1, 1, 1, 1, 1]

# Split dataset
X_train, X_test, y_train, y_test = train_test_split(
    X, y,
    test_size=0.2,
    random_state=1
)

# Create AdaBoost model
model = AdaBoostClassifier(
    estimator=DecisionTreeClassifier(max_depth=1),
    n_estimators=50,
    random_state=1
)

# Train model
model.fit(X_train, y_train)

# Predict test data
y_pred = model.predict(X_test)

# Accuracy
print("Accuracy:", accuracy_score(y_test, y_pred))

# New data prediction
new_data = [[5, 42]]

prediction = model.predict(new_data)

print("\nNew Data:", new_data)
print("Predicted Output:", prediction[0])"""

CODE_EXP8 = """# K-Nearest Neighbors (KNN)

from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score

# Dataset
X = [
    [150, 50],
    [152, 52],
    [155, 54],
    [160, 60],
    [165, 65],
    [170, 70],
    [175, 75],
    [180, 80],
    [185, 85],
    [190, 90]
]

# Labels
y = [
    'Small',
    'Small',
    'Small',
    'Medium',
    'Medium',
    'Medium',
    'Large',
    'Large',
    'Large',
    'Large'
]

# Split dataset
X_train, X_test, y_train, y_test = train_test_split(
    X, y,
    test_size=0.2,
    random_state=1
)

# Feature Scaling
scaler = StandardScaler()

X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# Create KNN model
model = KNeighborsClassifier(n_neighbors=3)

# Train model
model.fit(X_train, y_train)

# Predict test data
y_pred = model.predict(X_test)

# Accuracy
print("Accuracy:", accuracy_score(y_test, y_pred))

# New data prediction
new_data = [[172, 72]]

# Scale new data
new_data_scaled = scaler.transform(new_data)

# Predict
prediction = model.predict(new_data_scaled)

print("\nNew Data:", new_data)
print("Predicted Category:", prediction[0])"""

CODE_EXP9 = """# K-Means Clustering

import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans

# Sample data
X = np.array([
    [1, 2],
    [2, 3],
    [3, 3],
    [8, 7],
    [8, 8],
    [7, 8]
])

# Create K-Means model
model = KMeans(
    n_clusters=2,
    n_init=10,
    random_state=0
)

# Train model
model.fit(X)

# Cluster labels
labels = model.labels_

# Cluster centers
centers = model.cluster_centers_

# Print results
print("Cluster Labels:")
print(labels)

print("\nCluster Centers:")
print(centers)


x1=[i[0] for i in X]
x2=[i[1] for i in X]
# Plot clusters
plt.scatter(x1,x2)

c1=[i[0] for i in centers]
c2=[i[1] for i in centers]

# Plot centers
plt.scatter(
    c1,c2,
    marker='X',
    s=200
)

plt.xlabel("X")
plt.ylabel("Y")
plt.title("K-Means Clustering")

plt.show()"""

CODE_EXP10 = """# PCA - Principal Component Analysis

import numpy as np
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA

# Sample data
X = np.array([
    [2.5, 2.4],
    [0.5, 0.7],
    [2.2, 2.9],
    [1.9, 2.2],
    [3.1, 3.0],
    [2.3, 2.7],
    [2.0, 1.6],
    [1.0, 1.1],
    [1.5, 1.6],
    [1.1, 0.9]
])

# Create PCA model
pca = PCA(n_components=1)

# Reduce dimensions
X_pca = pca.fit_transform(X)

# Print reduced data
print("Reduced Data:\n")
print(X_pca)

# Plot original data
plt.scatter(X[:, 0], X[:, 1])

plt.xlabel("Feature 1")
plt.ylabel("Feature 2")
plt.title("Original Data")

plt.show()

# Plot reduced data
plt.scatter(X_pca, np.zeros_like(X_pca))

plt.xlabel("Principal Component")
plt.title("Data after PCA")

plt.show()"""

CODE_EXP11 = """# Support Vector Machine (SVM) Classifier

from sklearn.svm import SVC
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

# Sample dataset
# [Hours Studied, Attendance]
X = [
    [2, 50],
    [3, 55],
    [4, 60],
    [5, 65],
    [6, 70],
    [7, 75],
    [8, 80],
    [9, 85]
]

# Labels
# 0 = Fail, 1 = Pass
y = [0, 0, 0, 0, 1, 1, 1, 1]

# Split dataset
X_train, X_test, y_train, y_test = train_test_split(
    X, y,
    test_size=0.2,
    random_state=1
)

# Create SVM model
model = SVC(kernel='linear')

# Train model
model.fit(X_train, y_train)

# Predict test data
y_pred = model.predict(X_test)

# Accuracy
accuracy = accuracy_score(y_test, y_pred)

print("Accuracy:", accuracy)

# Predict new data
new_data = [[7, 72]]

prediction = model.predict(new_data)

print("\nNew Data:", new_data)
print("Predicted Output:", prediction[0])"""

CODE_EXP12 = """# Single Layer Perceptron

import numpy as np

# Input data (AND Gate)
X = np.array([
    [0, 0],
    [0, 1],
    [1, 0],
    [1, 1]
])

# Target output
y = np.array([0, 0, 0, 1])

# Initialize weights and bias
weights = np.zeros(2)
bias = 0

# Learning rate
lr = 0.1

# Number of iterations
epochs = 10

# Training
for epoch in range(epochs):

    for i in range(len(X)):

        # Weighted sum
        net = np.dot(X[i], weights) + bias

        # Activation function
        output = 1 if net >= 0 else 0

        # Error
        error = y[i] - output

        # Update weights and bias
        weights = weights + lr * error * X[i]
        bias = bias + lr * error

# Print final weights and bias
print("Final Weights:", weights)
print("Final Bias:", bias)

# Testing
print("\nTesting Perceptron")

for i in range(len(X)):

    net = np.dot(X[i], weights) + bias
    output = 1 if net >= 0 else 0

    print(X[i], "->", output)"""

CODE_EXP13 = """import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import Perceptron

X = np.array([
    [0, 0],
    [0, 1],
    [1, 0],
    [1, 1]
])

y = np.array([0, 0, 0, 1])

model = Perceptron()
model.fit(X, y)

print("Prediction:", model.predict([[1, 1]]))

# Graph
plt.scatter(X[:,0], X[:,1], c=y)
plt.title("Perceptron")
plt.xlabel("X1")
plt.ylabel("X2")
plt.show()"""

CODE_EXP14 = """# Multi Layer Perceptron with Back Propagation

import numpy as np

# Input data (XOR Gate)
X = np.array([
    [0, 0],
    [0, 1],
    [1, 0],
    [1, 1]
])

# Target output
y = np.array([
    [0],
    [1],
    [1],
    [0]
])

# Sigmoid activation function
def sigmoid(x):
    return 1 / (1 + np.exp(-x))

# Derivative of sigmoid
def sigmoid_derivative(x):
    return x * (1 - x)

# Initialize weights
np.random.seed(1)

input_neurons = 2
hidden_neurons = 2
output_neurons = 1

# Weights and bias
wh = np.random.uniform(size=(input_neurons, hidden_neurons))
bh = np.random.uniform(size=(1, hidden_neurons))

wo = np.random.uniform(size=(hidden_neurons, output_neurons))
bo = np.random.uniform(size=(1, output_neurons))

# Learning rate
lr = 0.1

# Training
epochs = 10000

for i in range(epochs):

    # Forward Propagation

    hidden_input = np.dot(X, wh) + bh
    hidden_output = sigmoid(hidden_input)

    final_input = np.dot(hidden_output, wo) + bo
    predicted_output = sigmoid(final_input)

    # Error
    error = y - predicted_output

    # Back Propagation

    d_output = error * sigmoid_derivative(predicted_output)

    error_hidden = d_output.dot(wo.T)
    d_hidden = error_hidden * sigmoid_derivative(hidden_output)

    # Update weights and bias

    wo += hidden_output.T.dot(d_output) * lr
    bo += np.sum(d_output, axis=0, keepdims=True) * lr

    wh += X.T.dot(d_hidden) * lr
    bh += np.sum(d_hidden, axis=0, keepdims=True) * lr

# Output
print("Predicted Output after Training:\n")

print(predicted_output)"""

CODE_EXP15 = """import pandas as pd
import matplotlib.pyplot as plt
from sklearn.neural_network import MLPClassifier

data = pd.DataFrame({
    "X1": [1, 2, 3, 4, 5],
    "X2": [2, 3, 4, 5, 6],
    "Class": [0, 0, 1, 1, 1]
})

X = data[["X1", "X2"]]
y = data["Class"]

model = MLPClassifier(max_iter=1000)
model.fit(X, y)

print("Prediction:", model.predict([[3, 4]]))

# Loss curve graph
plt.plot(model.loss_curve_)
plt.title("MLP Loss Curve")
plt.xlabel("Iterations")
plt.ylabel("Loss")
plt.show()"""

