# ML New2 Experiments

This package contains machine learning experiments extracted from a Jupyter notebook `new2.ipynb`.

The experiments cover:
- Univariate, Bivariate, Multivariate analysis
- Linear Regression
- Logistic Regression
- Decision Trees
- AdaBoost
- K-Nearest Neighbors (KNN)
- K-Means Clustering
- Principal Component Analysis (PCA)
- Support Vector Machines (SVM)
- Single and Multi Layer Perceptrons
