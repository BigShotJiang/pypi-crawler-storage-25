"""Neruva MCP server (Python).

Thin stdio Model Context Protocol wrapper over the Neruva REST API.
"""

__version__ = "0.1.0"
