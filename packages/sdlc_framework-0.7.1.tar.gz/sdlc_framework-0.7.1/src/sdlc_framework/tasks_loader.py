"""Read automation/tasks/*.yaml task files and compute current stage per task.

Inject as Phase 3 Tasks sub-track items into engine state.
"""
from __future__ import annotations

import json as _json
import subprocess
from pathlib import Path

import yaml

VALID_STAGES = ["pending", "write-tests", "write-code", "review", "done"]
HIGH_RISK_HINTS = ["auth", "crypto", "payment", "secrets", "iam", "migration"]


def load_tasks(target: Path) -> list[dict]:
    """Load all automation/tasks/*.yaml. Returns task dicts (passes through unchanged)."""
    tasks_dir = target / "automation" / "tasks"
    if not tasks_dir.exists():
        return []
    out: list[dict] = []
    for f in sorted(tasks_dir.glob("*.yaml")):
        try:
            data = yaml.safe_load(f.read_text(encoding="utf-8")) or {}
        except yaml.YAMLError:
            continue
        if not isinstance(data, dict) or not data.get("id"):
            continue
        out.append(data)
    return out


def _glob_count(target: Path, pattern: str) -> int:
    """Count files matching glob from target root, handling brace expansion."""
    from sdlc_framework import engine
    saved = engine.ROOT
    try:
        engine.ROOT = target
        return len(engine._glob(pattern))
    finally:
        engine.ROOT = saved


def _pr_status(branch: str, target: Path) -> str:
    """Return 'open', 'merged', or 'none' for a PR matching the head branch."""
    if not branch:
        return "none"
    try:
        result = subprocess.run(
            ["gh", "pr", "view", "--head", branch, "--json", "state"],
            capture_output=True, text=True, timeout=5, cwd=str(target),
        )
        if result.returncode != 0:
            return "none"
        data = _json.loads(result.stdout or "{}")
        state = (data.get("state") or "").upper()
        if state == "MERGED":
            return "merged"
        if state in ("OPEN", "DRAFT"):
            return "open"
    except Exception:
        pass
    return "none"


def detect_stage(task: dict, target: Path) -> str:
    """Determine the task's current stage from filesystem + git/gh state."""
    code_glob = task.get("code_glob") or ""
    test_glob = task.get("test_glob") or ""
    pr_branch = task.get("pr_branch") or ""

    n_code = _glob_count(target, code_glob) if code_glob else 0
    n_test = _glob_count(target, test_glob) if test_glob else 0

    if n_code == 0 and n_test == 0:
        return "pending"
    if n_test > 0 and n_code == 0:
        return "write-tests"
    # Both files exist (or only code files exist).
    if n_test < n_code:
        # TDD violation: more code than tests, regress to write-tests.
        return "write-tests"
    # tests >= code; check PR.
    if pr_branch:
        pr = _pr_status(pr_branch, target)
        if pr == "merged":
            return "done"
        if pr == "open":
            return "review"
    return "write-code"


def stage_to_subagent(task: dict, stage: str) -> str | None:
    """Map current stage to subagent name to invoke for the next transition."""
    label = (task.get("label") or "") + " " + (task.get("id") or "")
    is_sensitive = any(h in label.lower() for h in HIGH_RISK_HINTS)
    return {
        "pending": "test-author",
        "write-tests": "developer-agent",
        "write-code": "security-reviewer" if is_sensitive else "code-reviewer",
        "review": None,  # waits for human merge
        "done": None,
    }.get(stage)


def evaluate_task_as_item(task: dict, target: Path) -> dict:
    """Convert a task dict into a Phase-3-compatible item dict for state.json."""
    stage = detect_stage(task, target)
    return {
        "id": task["id"],
        "label": task.get("label") or task["id"],
        "subtrack": "tasks",
        "done": stage == "done",
        "drafted": stage in ("write-tests", "write-code", "review", "done"),
        "verified": stage == "done",
        "stage": stage,
        "stages": VALID_STAGES,
        "next_subagent": stage_to_subagent(task, stage),
        "priority": task.get("priority") or "medium",
        "code_glob": task.get("code_glob"),
        "test_glob": task.get("test_glob"),
        "pr_branch": task.get("pr_branch"),
        "story": task.get("story"),
        "checks": [{
            "rule": {"type": "task_stage"},
            "ok": stage == "done",
            "msg": f"current stage: {stage}",
        }],
    }
