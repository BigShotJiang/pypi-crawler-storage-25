---
mode: agent
description: Retrofit SDLC framework on an existing running project (auto-detect existing PRDs, designs, code, runbooks).
---

The user wants to onboard SDLC framework on a project that already has code, designs, or runbooks.

## Steps

1. Run via integrated terminal: `sdlc adopt` (pass `--auto` for non-interactive, `--dry-run` to preview).
2. The CLI scans for existing assets and asks the user (per phase) if the artifacts are complete and approved. On `y`, it creates symlinks (or copies) into canonical SDLC paths and auto-verifies them.
3. For Phase 3, it asks how to treat existing code:
   - Legacy mode (recommended) — adds `legacy_code_globs: ["src/**"]` to `project.yaml`; existing code is grandfathered (no TDD enforcement)
   - Skip mode — manage tasks manually
4. After completion, suggest `sdlc resume` to see the starting point, then `sdlc next`.

## Idempotency

Re-running `sdlc adopt` is a no-op (won't duplicate symlinks or verifications).

## When NOT to use

- Brand-new project → use `sdlc setup` instead
- Project on framework v0.6.x → use `sdlc migrate-v2` to upgrade schema first
