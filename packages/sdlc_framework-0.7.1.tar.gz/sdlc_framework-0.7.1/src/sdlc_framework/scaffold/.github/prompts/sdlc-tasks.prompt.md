---
mode: agent
description: Manage Phase 3 task definitions (bootstrap, list, create, remove).
---

The user wants to manage Phase 3 tasks under `automation/tasks/`.

## Sub-commands

- `bootstrap` — auto-create one task per user story heading in `01-Planning/02-User-Stories.md`
- `list` — show all tasks with current stage
- `new <id>` — manually create a task (flags: `--label`, `--code-glob`, `--test-glob`, `--pr-branch`, `--priority`)
- `rm <id>` — delete a task

## Steps

1. Run via integrated terminal: `sdlc tasks <subcommand> [args]`.
2. Report the result.
3. After `bootstrap` or `new`, suggest `sdlc next` to begin work on the highest-priority pending task.

## Task lifecycle reminder

Each task progresses through 5 stages, sequential TDD strict:

```
pending → write-tests → write-code → review → done
```

Stage detection is automatic (filesystem + `gh pr view`). The dashboard renders task rows with stage pills. Each stage transition invokes a different subagent in a fresh context.
