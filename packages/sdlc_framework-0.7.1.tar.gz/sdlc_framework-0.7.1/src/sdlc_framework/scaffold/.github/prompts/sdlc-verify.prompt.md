---
mode: agent
description: Mark a Phase 1/2/4 artifact as verified by the user.
---

The user wants to verify a DoD artifact. The argument is the item id (e.g. `prd-exists`, `architecture-doc`, `test-plan-written`).

## Steps

1. Run via the integrated terminal: `sdlc verify <item-id>`. Pass `--name=<who>` if the user specified one.
2. Report the result:
   - On success, the CLI appends an `<!-- sdlc:verified-by: ... -->` marker to all files matching the rule's glob.
   - On error, surface the message and suggest a fix (e.g. "the file doesn't exist yet — has the AI drafted the artifact?").
3. Suggest `sdlc scan --print` to see the updated phase progress, or `sdlc next` to continue.

## When to use

- Phase 1 artifacts: `prd-exists`, `user-stories-with-ac`, `nfr-quantified`, `stakeholder-raci`, `risks-mitigated`
- Phase 2 artifacts: `architecture-doc`, `api-spec`, `db-schema`, `adr-logged`, `threat-model`, `ui-spec`, `wireframes`, `design-system`, `accessibility`
- Phase 4 artifacts: `test-plan-written`, `load-test-results`
- Phase 5 artifacts (selected): `deploy-runbook-written`, `slo-monitoring`, `incident-response`

Phase 3 setup items use file-existence checks, not the verify mechanism.
