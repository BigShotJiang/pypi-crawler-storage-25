"""SDLC Framework — local-only multi-AI SDLC tooling."""
__version__ = "0.7.1"
