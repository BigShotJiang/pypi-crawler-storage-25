"""
Tests for the alphainfo Python SDK.

These tests verify client construction, input validation, response parsing,
and error handling — all without hitting the real API (mocked with httpx).
"""

import json
import pytest
import httpx

from alphainfo import (
    AlphaInfo,
    AsyncAlphaInfo,
    AnalysisResult,
    BatchResult,
    VectorResult,
    MarketResult,
    AuditReplay,
    HealthStatus,
)
from alphainfo.exceptions import (
    AlphaInfoError,
    AuthError,
    RateLimitError,
    ValidationError,
    NotFoundError,
    APIError,
)


# ---------------------------------------------------------------------------
# Fixtures & helpers
# ---------------------------------------------------------------------------

MOCK_ANALYSIS_RESPONSE = {
    "structural_score": 0.85,
    "change_detected": True,
    "change_score": 0.42,
    "confidence_band": "transition",
    "engine_version": "abc123",
    "analysis_id": "550e8400-e29b-41d4-a716-446655440000",
    "metrics": {"method": "curvature"},
    "provenance": None,
    "semantic": {"alert_level": "warning"},
}

MOCK_BATCH_RESPONSE = {
    "results": [
        {
            "index": 0,
            "structural_score": 0.95,
            "change_detected": False,
            "change_score": 0.01,
            "confidence_band": "stable",
            "engine_version": "abc123",
            "analysis_id": "id-0",
        },
        {
            "index": 1,
            "error": "signal too short",
        },
    ],
    "analyses_consumed": 1,
    "total_signals": 2,
}

MOCK_VECTOR_RESPONSE = {
    "analysis_id": "vec-001",
    "structural_score": 0.72,
    "change_detected": True,
    "n_channels": 2,
    "channels": {
        "ch1": {
            "structural_score": 0.72,
            "change_detected": True,
            "change_score": 0.30,
            "confidence_band": "transition",
            "engine_version": "abc123",
        },
        "ch2": {
            "structural_score": 0.95,
            "change_detected": False,
            "change_score": 0.02,
            "confidence_band": "stable",
            "engine_version": "abc123",
        },
    },
    "analyses_consumed": 1,
}

MOCK_HEALTH_RESPONSE = {
    "status": "healthy",
    "version": "2.2.1",
    "message": "alphainfo API is running",
}


def _mock_transport(response_data, status_code=200, headers=None):
    """Create a mock httpx transport that returns a fixed response."""
    resp_headers = {"content-type": "application/json"}
    if headers:
        resp_headers.update(headers)

    def handler(request):
        return httpx.Response(
            status_code=status_code,
            json=response_data,
            headers=resp_headers,
        )

    return httpx.MockTransport(handler)


# ---------------------------------------------------------------------------
# Client construction
# ---------------------------------------------------------------------------

class TestClientConstruction:
    def test_requires_api_key(self):
        with pytest.raises(ValueError, match="api_key"):
            AlphaInfo(api_key="")

    def test_default_base_url(self):
        client = AlphaInfo(api_key="ai_test")
        assert client._base_url == "https://alphainfo.io"
        client.close()

    def test_custom_base_url(self):
        client = AlphaInfo(api_key="ai_test", base_url="https://custom.example.com/")
        assert client._base_url == "https://custom.example.com"
        client.close()

    def test_context_manager(self):
        with AlphaInfo(api_key="ai_test") as client:
            assert client._api_key == "ai_test"


# ---------------------------------------------------------------------------
# Input validation
# ---------------------------------------------------------------------------

class TestInputValidation:
    def test_analyze_empty_signal(self):
        client = AlphaInfo(api_key="ai_test")
        with pytest.raises(ValidationError, match="empty"):
            client.analyze(signal=[], sampling_rate=250.0)
        client.close()

    def test_analyze_negative_rate(self):
        client = AlphaInfo(api_key="ai_test")
        with pytest.raises(ValidationError, match="positive"):
            client.analyze(signal=[1.0, 2.0], sampling_rate=-1.0)
        client.close()

    def test_batch_empty(self):
        client = AlphaInfo(api_key="ai_test")
        with pytest.raises(ValidationError, match="empty"):
            client.analyze_batch(signals=[], sampling_rate=250.0)
        client.close()

    def test_batch_too_large(self):
        client = AlphaInfo(api_key="ai_test")
        with pytest.raises(ValidationError, match="100"):
            client.analyze_batch(signals=[[] for _ in range(101)], sampling_rate=250.0)
        client.close()

    def test_vector_empty_channels(self):
        client = AlphaInfo(api_key="ai_test")
        with pytest.raises(ValidationError, match="empty"):
            client.analyze_vector(channels={}, sampling_rate=250.0)
        client.close()

    def test_market_empty_symbol(self):
        client = AlphaInfo(api_key="ai_test")
        with pytest.raises(ValidationError, match="empty"):
            client.analyze_market(symbol="")
        client.close()

    def test_audit_empty_id(self):
        client = AlphaInfo(api_key="ai_test")
        with pytest.raises(ValidationError, match="empty"):
            client.audit_replay(analysis_id="")
        client.close()


# ---------------------------------------------------------------------------
# Response parsing
# ---------------------------------------------------------------------------

class TestResponseParsing:
    def test_analyze_response(self):
        transport = _mock_transport(MOCK_ANALYSIS_RESPONSE)
        client = AlphaInfo(api_key="ai_test")
        client._client = httpx.Client(transport=transport)

        result = client.analyze(signal=[1.0] * 100, sampling_rate=250.0)

        assert isinstance(result, AnalysisResult)
        assert result.structural_score == 0.85
        assert result.change_detected is True
        assert result.confidence_band == "transition"
        assert result.analysis_id == "550e8400-e29b-41d4-a716-446655440000"
        assert result.semantic == {"alert_level": "warning"}
        client.close()

    def test_batch_response(self):
        transport = _mock_transport(MOCK_BATCH_RESPONSE)
        client = AlphaInfo(api_key="ai_test")
        client._client = httpx.Client(transport=transport)

        result = client.analyze_batch(
            signals=[[1.0] * 100, [2.0] * 5],
            sampling_rate=250.0,
        )

        assert isinstance(result, BatchResult)
        assert result.total_signals == 2
        assert len(result.successful) == 1
        assert len(result.failed) == 1
        assert result.results[0].structural_score == 0.95
        assert result.results[1].error == "signal too short"
        client.close()

    def test_vector_response(self):
        transport = _mock_transport(MOCK_VECTOR_RESPONSE)
        client = AlphaInfo(api_key="ai_test")
        client._client = httpx.Client(transport=transport)

        result = client.analyze_vector(
            channels={"ch1": [1.0] * 100, "ch2": [2.0] * 100},
            sampling_rate=250.0,
        )

        assert isinstance(result, VectorResult)
        assert result.n_channels == 2
        assert result.change_detected is True
        assert "ch1" in result.channels
        assert result.channels["ch2"].confidence_band == "stable"
        client.close()

    def test_health_response(self):
        transport = _mock_transport(MOCK_HEALTH_RESPONSE)
        client = AlphaInfo(api_key="ai_test")
        client._client = httpx.Client(transport=transport)

        health = client.health()

        assert isinstance(health, HealthStatus)
        assert health.is_healthy()
        assert health.version == "2.2.1"
        client.close()


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------

class TestErrorHandling:
    def test_401_raises_auth_error(self):
        transport = _mock_transport({"detail": "Invalid API key"}, status_code=401)
        client = AlphaInfo(api_key="ai_bad", max_retries=0)
        client._client = httpx.Client(transport=transport)

        with pytest.raises(AuthError):
            client.analyze(signal=[1.0] * 100, sampling_rate=250.0)
        client.close()

    def test_400_raises_validation_error(self):
        transport = _mock_transport({"detail": "signal too short"}, status_code=400)
        client = AlphaInfo(api_key="ai_test", max_retries=0)
        client._client = httpx.Client(transport=transport)

        with pytest.raises(ValidationError):
            client.analyze(signal=[1.0] * 100, sampling_rate=250.0)
        client.close()

    def test_404_raises_not_found(self):
        transport = _mock_transport({"detail": "Analysis not found"}, status_code=404)
        client = AlphaInfo(api_key="ai_test", max_retries=0)
        client._client = httpx.Client(transport=transport)

        with pytest.raises(NotFoundError):
            client.audit_replay("nonexistent-id")
        client.close()

    def test_429_raises_rate_limit(self):
        transport = _mock_transport(
            {"detail": {"error": "rate_limit", "message": "Too many requests"}},
            status_code=429,
            headers={"Retry-After": "30"},
        )
        client = AlphaInfo(api_key="ai_test", max_retries=0)
        client._client = httpx.Client(transport=transport)

        with pytest.raises(RateLimitError) as exc_info:
            client.analyze(signal=[1.0] * 100, sampling_rate=250.0)
        assert exc_info.value.retry_after == 30
        client.close()

    def test_500_raises_api_error(self):
        transport = _mock_transport({"detail": "Internal error"}, status_code=500)
        client = AlphaInfo(api_key="ai_test", max_retries=0)
        client._client = httpx.Client(transport=transport)

        with pytest.raises(APIError):
            client.analyze(signal=[1.0] * 100, sampling_rate=250.0)
        client.close()


# ---------------------------------------------------------------------------
# Rate limit tracking
# ---------------------------------------------------------------------------

class TestRateLimit:
    def test_extracts_rate_limit_headers(self):
        transport = _mock_transport(
            MOCK_ANALYSIS_RESPONSE,
            headers={
                "x-ratelimit-limit": "1000",
                "x-ratelimit-remaining": "999",
                "x-ratelimit-reset": "1700000000",
            },
        )
        client = AlphaInfo(api_key="ai_test")
        client._client = httpx.Client(transport=transport)

        client.analyze(signal=[1.0] * 100, sampling_rate=250.0)

        info = client.rate_limit_info
        assert info is not None
        assert info.limit == 1000
        assert info.remaining == 999
        client.close()

    def test_no_rate_limit_headers(self):
        transport = _mock_transport(MOCK_HEALTH_RESPONSE)
        client = AlphaInfo(api_key="ai_test")
        client._client = httpx.Client(transport=transport)

        client.health()
        assert client.rate_limit_info is None
        client.close()


# ---------------------------------------------------------------------------
# Repr & properties
# ---------------------------------------------------------------------------

class TestRepr:
    def test_analysis_result_repr(self):
        from alphainfo.models import AnalysisResult
        r = AnalysisResult(
            structural_score=0.85, change_detected=True, change_score=0.42,
            confidence_band="transition", engine_version="v1", analysis_id="id-1",
        )
        assert "0.850" in repr(r)
        assert "transition" in repr(r)

    def test_batch_result_properties(self):
        from alphainfo.models import BatchResult, BatchItemResult
        items = [
            BatchItemResult(index=0, structural_score=0.9, confidence_band="stable"),
            BatchItemResult(index=1, error="too short"),
        ]
        batch = BatchResult(results=items, analyses_consumed=1, total_signals=2)
        assert len(batch.successful) == 1
        assert len(batch.failed) == 1


# ---------------------------------------------------------------------------
# Security: ensure NO engine code is exposed
# ---------------------------------------------------------------------------

class TestSecurity:
    """Verify the SDK contains zero proprietary engine code."""

    def test_no_engine_imports(self):
        """SDK must not import from core/, metrics/, or config/."""
        import alphainfo
        import alphainfo.client
        import alphainfo.models
        import alphainfo.exceptions

        for mod in [alphainfo, alphainfo.client, alphainfo.models, alphainfo.exceptions]:
            source = open(mod.__file__).read()
            assert "from core" not in source, f"{mod.__name__} imports from core/"
            assert "from metrics" not in source, f"{mod.__name__} imports from metrics/"
            assert "from config" not in source, f"{mod.__name__} imports from config/"
            assert "structural_engine" not in source.lower(), f"{mod.__name__} references engine"
            assert "curvature_fisher" not in source.lower(), f"{mod.__name__} references curvature"
            assert "fisher_info" not in source.lower(), f"{mod.__name__} references fisher"

    def test_no_algorithm_exposure(self):
        """SDK must not contain algorithmic details."""
        import alphainfo.client
        import alphainfo.models

        for mod in [alphainfo.client, alphainfo.models]:
            source = open(mod.__file__).read()
            # No numpy / scipy / signal processing
            assert "import numpy" not in source
            assert "import scipy" not in source
            assert "from numpy" not in source
            # No algorithm names
            assert "eigenvalue" not in source.lower()
            assert "hessian" not in source.lower()
            assert "kolmogorov" not in source.lower()
            assert "wasserstein" not in source.lower()
