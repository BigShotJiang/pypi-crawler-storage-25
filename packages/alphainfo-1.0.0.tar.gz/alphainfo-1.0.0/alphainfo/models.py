"""
alphainfo SDK — Typed Data Models

All response objects are dataclasses with full type annotations.
This module contains ONLY public API contract types — no engine internals.
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


# ---------------------------------------------------------------------------
# Core analysis result
# ---------------------------------------------------------------------------

@dataclass
class AnalysisResult:
    """Result from a single structural analysis."""

    structural_score: float
    """Structural preservation score [0, 1]. Higher = more preserved."""

    change_detected: bool
    """Whether a structural regime change was detected."""

    change_score: float
    """Change magnitude score [0, 1]. Higher = larger change."""

    confidence_band: str
    """Classification: 'stable', 'transition', or 'unstable'."""

    engine_version: str
    """Engine version that produced this result."""

    analysis_id: str
    """Unique UUID for audit trail and replay."""

    metrics: Optional[Dict[str, Any]] = None
    """Additional analysis metrics (when available)."""

    provenance: Optional[Dict[str, Any]] = None
    """Data provenance information."""

    semantic: Optional[Dict[str, Any]] = None
    """Semantic interpretation (when include_semantic=True)."""

    def __repr__(self) -> str:
        return (
            f"AnalysisResult(score={self.structural_score:.3f}, "
            f"change={self.change_detected}, "
            f"band={self.confidence_band!r}, "
            f"id={self.analysis_id!r})"
        )


# ---------------------------------------------------------------------------
# Market analysis result
# ---------------------------------------------------------------------------

@dataclass
class MarketResult(AnalysisResult):
    """Result from a market data analysis (extends AnalysisResult)."""

    symbol: Optional[str] = None
    """Trading symbol analyzed (e.g., 'AAPL', 'BTC-USD')."""

    interval: Optional[str] = None
    """Time interval of the data (e.g., '1h', '1d')."""

    exchange: Optional[str] = None
    """Exchange where the symbol trades."""

    def __repr__(self) -> str:
        return (
            f"MarketResult(symbol={self.symbol!r}, "
            f"score={self.structural_score:.3f}, "
            f"band={self.confidence_band!r})"
        )


# ---------------------------------------------------------------------------
# Batch analysis result
# ---------------------------------------------------------------------------

@dataclass
class BatchItemResult:
    """Result for a single signal within a batch."""

    index: int
    """Position in the original batch (0-based)."""

    structural_score: Optional[float] = None
    change_detected: Optional[bool] = None
    change_score: Optional[float] = None
    confidence_band: Optional[str] = None
    engine_version: Optional[str] = None
    analysis_id: Optional[str] = None
    metrics: Optional[Dict[str, Any]] = None
    semantic: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    """Error message if this signal failed analysis."""

    @property
    def success(self) -> bool:
        """Whether this signal was analyzed successfully."""
        return self.error is None

    def __repr__(self) -> str:
        if self.error:
            return f"BatchItemResult(index={self.index}, error={self.error!r})"
        return (
            f"BatchItemResult(index={self.index}, "
            f"score={self.structural_score:.3f}, "
            f"band={self.confidence_band!r})"
        )


@dataclass
class BatchResult:
    """Result from a batch analysis request."""

    results: List[BatchItemResult]
    """Per-signal results."""

    analyses_consumed: int
    """Number of analyses deducted from quota."""

    total_signals: int
    """Total number of signals submitted."""

    @property
    def successful(self) -> List[BatchItemResult]:
        """Return only successfully analyzed items."""
        return [r for r in self.results if r.success]

    @property
    def failed(self) -> List[BatchItemResult]:
        """Return only failed items."""
        return [r for r in self.results if not r.success]

    def __repr__(self) -> str:
        ok = len(self.successful)
        fail = len(self.failed)
        return f"BatchResult(total={self.total_signals}, ok={ok}, failed={fail})"


# ---------------------------------------------------------------------------
# Vector (multi-channel) analysis result
# ---------------------------------------------------------------------------

@dataclass
class ChannelResult:
    """Result for a single channel within a vector analysis."""

    name: str
    """Channel name."""

    structural_score: Optional[float] = None
    change_detected: Optional[bool] = None
    change_score: Optional[float] = None
    confidence_band: Optional[str] = None
    engine_version: Optional[str] = None
    error: Optional[str] = None

    @property
    def success(self) -> bool:
        return self.error is None

    def __repr__(self) -> str:
        if self.error:
            return f"ChannelResult(name={self.name!r}, error={self.error!r})"
        return (
            f"ChannelResult(name={self.name!r}, "
            f"score={self.structural_score:.3f}, "
            f"band={self.confidence_band!r})"
        )


@dataclass
class VectorResult:
    """Result from a multi-channel vector analysis."""

    analysis_id: str
    """Unique UUID for the vector analysis."""

    structural_score: float
    """Aggregated score (worst-case across channels)."""

    change_detected: bool
    """True if ANY channel detected a change."""

    n_channels: int
    """Number of channels analyzed."""

    channels: Dict[str, ChannelResult]
    """Per-channel results keyed by channel name."""

    analyses_consumed: int = 1
    """Vector analysis always consumes 1 analysis."""

    semantic: Optional[Dict[str, Any]] = None

    def __repr__(self) -> str:
        return (
            f"VectorResult(channels={self.n_channels}, "
            f"score={self.structural_score:.3f}, "
            f"change={self.change_detected})"
        )


# ---------------------------------------------------------------------------
# Audit trail models
# ---------------------------------------------------------------------------

@dataclass
class AuditReplay:
    """Full replay of a past analysis with all inputs and outputs."""

    analysis_id: str
    timestamp: str
    signal_length: int
    sampling_rate: float
    parameters: Dict[str, Any]
    """Original request parameters."""

    output: Dict[str, Any]
    """Original analysis output."""

    engine_version: str
    client_id: Optional[str] = None
    request_id: Optional[str] = None

    def __repr__(self) -> str:
        return (
            f"AuditReplay(id={self.analysis_id!r}, "
            f"length={self.signal_length}, "
            f"score={self.output.get('structural_score', '?')})"
        )


@dataclass
class AuditSummary:
    """Summary of a past analysis (from audit list)."""

    analysis_id: str
    timestamp: str
    signal_length: int
    domain: Optional[str] = None
    structural_score: Optional[float] = None
    change_detected: Optional[bool] = None

    def __repr__(self) -> str:
        return f"AuditSummary(id={self.analysis_id!r}, score={self.structural_score})"


# ---------------------------------------------------------------------------
# Health & infrastructure
# ---------------------------------------------------------------------------

@dataclass
class HealthStatus:
    """API health check response."""

    status: str
    """'healthy' or 'degraded'."""

    version: str
    """API version string."""

    message: str
    """Status message."""

    def is_healthy(self) -> bool:
        return self.status == "healthy"

    def __repr__(self) -> str:
        return f"HealthStatus(status={self.status!r}, version={self.version!r})"


@dataclass
class PlanInfo:
    """Billing plan information."""

    id: int
    name: str
    slug: str
    price_cents: int
    currency: str = "USD"
    monthly_limit: int = 0
    features: Optional[Dict[str, Any]] = None
    stripe_price_id: Optional[str] = None

    def __repr__(self) -> str:
        return (
            f"PlanInfo(name={self.name!r}, "
            f"${self.price_cents / 100:.2f}/mo, "
            f"limit={self.monthly_limit})"
        )


@dataclass
class RateLimitInfo:
    """Rate limit info extracted from response headers."""

    limit: int
    """Total allowed in the window."""

    remaining: int
    """Remaining in the current window."""

    reset: int
    """Unix timestamp when limit resets."""

    def __repr__(self) -> str:
        return f"RateLimitInfo({self.remaining}/{self.limit} remaining)"
