"""
alphainfo — Python client for the Structural Intelligence API

Detect structural regime changes in time series data: biomedical signals,
financial markets, energy grids, seismic data, IoT sensors, and more.

Quick start:
    >>> from alphainfo import AlphaInfo
    >>> client = AlphaInfo(api_key="ai_your_key")
    >>> result = client.analyze(signal=[...], sampling_rate=250.0)
    >>> print(result.confidence_band)  # 'stable', 'transition', or 'unstable'

Async:
    >>> from alphainfo import AsyncAlphaInfo
    >>> async with AsyncAlphaInfo(api_key="ai_your_key") as client:
    ...     result = await client.analyze(signal=[...], sampling_rate=250.0)
"""

from .client import AlphaInfo, AsyncAlphaInfo
from .models import (
    AnalysisResult,
    AuditReplay,
    AuditSummary,
    BatchItemResult,
    BatchResult,
    ChannelResult,
    HealthStatus,
    MarketResult,
    PlanInfo,
    RateLimitInfo,
    VectorResult,
)
from .exceptions import (
    AlphaInfoError,
    APIError,
    AuthError,
    NetworkError,
    NotFoundError,
    RateLimitError,
    TimeoutError,
    ValidationError,
)

__version__ = "1.0.0"
__all__ = [
    # Clients
    "AlphaInfo",
    "AsyncAlphaInfo",
    # Result models
    "AnalysisResult",
    "MarketResult",
    "BatchResult",
    "BatchItemResult",
    "VectorResult",
    "ChannelResult",
    # Audit
    "AuditReplay",
    "AuditSummary",
    # Infrastructure
    "HealthStatus",
    "PlanInfo",
    "RateLimitInfo",
    # Exceptions
    "AlphaInfoError",
    "APIError",
    "AuthError",
    "NetworkError",
    "NotFoundError",
    "RateLimitError",
    "TimeoutError",
    "ValidationError",
]
