import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient
from tigrbl import TigrblApp
from tigrbl.shortcuts.engine import mem
from tigrbl.orm.mixins import BulkCapable, Mergeable, Replaceable
from tigrbl.orm.tables import TableBase
from tigrbl._spec import IO, F, S
from tigrbl.shortcuts.column import acol
from tigrbl.types import Integer, Mapped, String, uuid4


@pytest_asyncio.fixture()
async def client_and_model():
    TableBase.metadata.clear()
    TableBase.registry.dispose()

    class Gadget(TableBase):
        __tablename__ = "gadgets"
        __allow_unmapped__ = True

        id: Mapped[int] = acol(
            storage=S(type_=Integer, primary_key=True, autoincrement=True)
        )
        name: Mapped[str] = acol(
            storage=S(type_=String, nullable=False),
            field=F(required_in=("create",)),
            io=IO(
                in_verbs=("create", "update", "replace"),
                out_verbs=("read", "list"),
            ),
        )
        age: Mapped[int] = acol(
            storage=S(type_=Integer, nullable=False, default=0),
            io=IO(
                in_verbs=("create", "update", "replace"),
                out_verbs=("read", "list"),
            ),
        )

        __tigrbl_cols__ = {"id": id, "name": name, "age": age}

    app = TigrblApp(engine=mem(async_=False))
    app.include_table(Gadget, prefix="")
    app.mount_jsonrpc()
    await app.initialize()
    transport = ASGITransport(app=app)
    client = AsyncClient(transport=transport, base_url="http://test")
    try:
        yield client, Gadget
    finally:
        await client.aclose()


@pytest.mark.i9n
@pytest.mark.asyncio
@pytest.mark.parametrize(
    "verb",
    ["create", "read", "update", "replace", "delete", "list", "clear"],
)
async def test_rpc_methods(verb, client_and_model):
    client, _ = client_and_model

    async def rpc(method, params, id_=1):
        payload = {"jsonrpc": "2.0", "method": method, "params": params, "id": id_}
        return await client.post("/rpc", json=payload)

    if verb == "create":
        resp = await rpc("Gadget.create", {"name": "A", "age": 1})
        assert resp.status_code == 200
        data = resp.json()["result"]
        assert data["name"] == "A"
        assert data["age"] == 1

    elif verb == "read":
        created = await rpc("Gadget.create", {"name": "A", "age": 1})
        gid = created.json()["result"]["id"]
        resp = await rpc("Gadget.read", {"id": gid}, id_=2)
        assert resp.status_code == 200
        assert resp.json()["result"]["id"] == gid

    elif verb == "update":
        created = await rpc("Gadget.create", {"name": "A", "age": 1})
        gid = created.json()["result"]["id"]
        resp = await rpc("Gadget.update", {"id": gid, "name": "B", "age": 2}, id_=2)
        assert resp.status_code == 200
        data = resp.json()["result"]
        assert data["name"] == "B"
        assert data["age"] == 2

    elif verb == "replace":
        created = await rpc("Gadget.create", {"name": "A", "age": 1})
        gid = created.json()["result"]["id"]
        resp = await rpc("Gadget.replace", {"id": gid, "name": "C", "age": 5}, id_=2)
        assert resp.status_code == 200
        data = resp.json()["result"]
        assert data["name"] == "C"
        assert data["age"] == 5

    elif verb == "delete":
        created = await rpc("Gadget.create", {"name": "A", "age": 1})
        gid = created.json()["result"]["id"]
        resp = await rpc("Gadget.delete", {"id": gid}, id_=2)
        assert resp.status_code == 200
        assert resp.json()["result"]["deleted"] == 1
        follow = await rpc("Gadget.read", {"id": gid}, id_=3)
        assert "error" in follow.json()

    elif verb == "list":
        await rpc("Gadget.create", {"name": "A", "age": 1})
        await rpc("Gadget.create", {"name": "B", "age": 2})
        resp = await rpc("Gadget.list", {}, id_=3)
        assert resp.status_code == 200
        names = {item["name"] for item in resp.json()["result"]}
        assert names == {"A", "B"}

    elif verb == "clear":
        await rpc("Gadget.create", {"name": "A", "age": 1})
        await rpc("Gadget.create", {"name": "B", "age": 2})
        resp = await rpc("Gadget.clear", {}, id_=3)
        assert resp.status_code == 200
        assert resp.json()["result"]["deleted"] == 2
        remain = await rpc("Gadget.list", {}, id_=4)
        assert remain.json()["result"] == []


@pytest.mark.i9n
@pytest.mark.asyncio
async def test_bulk_methods_absent(client_and_model):
    _, Gadget = client_and_model
    for name in (
        "bulk_create",
        "bulk_update",
        "bulk_replace",
        "bulk_merge",
        "bulk_delete",
    ):
        assert not hasattr(Gadget.rpc, name)


@pytest_asyncio.fixture()
async def wrapper_field_client_and_model():
    TableBase.metadata.clear()
    TableBase.registry.dispose()

    class WrapperNamed(TableBase):
        __tablename__ = "wrapper_named"
        __allow_unmapped__ = True

        id: Mapped[int] = acol(
            storage=S(type_=Integer, primary_key=True, autoincrement=True)
        )
        data: Mapped[str] = acol(
            storage=S(type_=String, nullable=False),
            field=F(required_in=("create",)),
            io=IO(in_verbs=("create", "update"), out_verbs=("read", "list")),
        )

        __tigrbl_cols__ = {"id": id, "data": data}

    app = TigrblApp(engine=mem(async_=False))
    app.include_table(WrapperNamed, prefix="")
    app.mount_jsonrpc()
    await app.initialize()
    transport = ASGITransport(app=app)
    client = AsyncClient(transport=transport, base_url="http://test")
    try:
        yield client, WrapperNamed
    finally:
        await client.aclose()


@pytest.mark.i9n
@pytest.mark.asyncio
async def test_rpc_create_allows_schema_defined_wrapper_like_fields(
    wrapper_field_client_and_model,
):
    client, _ = wrapper_field_client_and_model
    payload = {
        "jsonrpc": "2.0",
        "method": "WrapperNamed.create",
        "params": {"data": "legit"},
        "id": 99,
    }

    response = await client.post("/rpc", json=payload)

    assert response.status_code == 200
    body = response.json()
    assert "error" not in body
    assert body["result"]["data"] == "legit"


@pytest.mark.i9n
@pytest.mark.asyncio
@pytest.mark.parametrize("wrapper_key", ["data", "payload", "body", "item"])
async def test_rpc_create_rejects_wrapper_object(wrapper_key, client_and_model):
    client, _ = client_and_model
    payload = {
        "jsonrpc": "2.0",
        "method": "Gadget.create",
        "params": {wrapper_key: {"name": "Wrapped", "age": 7}},
        "id": 11,
    }

    response = await client.post("/rpc", json=payload)

    assert response.status_code == 200
    error = response.json()["error"]
    assert error["code"] == -32602
    assert error["message"] == "Invalid params"
    assert error["data"]["disallowed_keys"] == [wrapper_key]


@pytest.mark.i9n
@pytest.mark.asyncio
@pytest.mark.parametrize("wrapper_key", ["data", "payload", "body", "item"])
async def test_rest_create_rejects_wrapper_object(wrapper_key, client_and_model):
    client, _ = client_and_model

    response = await client.post(
        "/gadget",
        json={wrapper_key: {"name": "Wrapped", "age": 7}},
    )

    assert response.status_code == 422


@pytest_asyncio.fixture()
async def bulk_client_and_model():
    TableBase.metadata.clear()
    TableBase.registry.dispose()

    class Gadget(TableBase, BulkCapable, Replaceable, Mergeable):
        __tablename__ = "gadgets"
        __allow_unmapped__ = True

        id: Mapped[int] = acol(
            storage=S(type_=Integer, primary_key=True, autoincrement=True)
        )
        name: Mapped[str] = acol(
            storage=S(type_=String, nullable=False),
            field=F(required_in=("create",)),
            io=IO(
                in_verbs=("create", "update", "replace", "merge"),
                out_verbs=("read", "list"),
            ),
        )
        age: Mapped[int] = acol(
            storage=S(type_=Integer, nullable=False, default=0),
            io=IO(
                in_verbs=("create", "update", "replace", "merge"),
                out_verbs=("read", "list"),
            ),
        )

        __tigrbl_cols__ = {"id": id, "name": name, "age": age}

    app = TigrblApp(engine=mem(async_=False))
    app.include_table(Gadget, prefix="")
    app.mount_jsonrpc()
    await app.initialize()
    transport = ASGITransport(app=app)
    client = AsyncClient(transport=transport, base_url="http://test")
    try:
        yield client, Gadget
    finally:
        await client.aclose()


@pytest.mark.i9n
@pytest.mark.asyncio
@pytest.mark.parametrize("wrapper_key", ["data", "payload", "body", "item"])
async def test_rpc_bulk_create_rejects_wrapper_object_items(
    wrapper_key,
    bulk_client_and_model,
):
    client, _ = bulk_client_and_model

    payload = {
        "jsonrpc": "2.0",
        "method": "Gadget.bulk_create",
        "params": [{wrapper_key: {"name": "Wrapped", "age": 7}}],
        "id": 20,
    }

    response = await client.post("/rpc", json=payload)

    assert response.status_code == 200
    error = response.json()["error"]
    assert error["code"] == -32602
    assert error["message"] == "Invalid params"
    assert error["data"]["disallowed_keys"] == [wrapper_key]


@pytest.mark.i9n
@pytest.mark.asyncio
async def test_rpc_bulk_ops(bulk_client_and_model):
    client, _ = bulk_client_and_model

    async def rpc(method, params, id_=1):
        payload = {"jsonrpc": "2.0", "method": method, "params": params, "id": id_}
        return await client.post("/rpc", json=payload)

    resp = await rpc(
        "Gadget.bulk_create",
        [{"name": "A", "age": 1}, {"name": "B", "age": 2}],
    )
    assert resp.status_code == 200
    ids = [row["id"] for row in resp.json()["result"]]

    resp = await rpc(
        "Gadget.bulk_update",
        [{"id": ids[0], "age": 3}, {"id": ids[1], "age": 4}],
        id_=2,
    )
    assert resp.status_code == 200

    resp = await rpc(
        "Gadget.bulk_replace",
        [
            {"id": ids[0], "name": "C", "age": 5},
            {"id": ids[1], "name": "D", "age": 6},
        ],
        id_=3,
    )
    assert resp.status_code == 200
    resp = await rpc(
        "Gadget.bulk_merge",
        [
            {"id": ids[0], "name": "E", "age": 7},
            {"id": ids[1], "age": 8},
        ],
        id_=4,
    )
    assert resp.status_code == 200
    merged = resp.json()["result"]
    assert merged[0]["id"] == ids[0]
    assert merged[0]["name"] == "E"

    resp = await rpc("Gadget.bulk_delete", ids + [str(uuid4())], id_=5)
    assert resp.status_code == 200
    assert resp.json()["result"]["deleted"] == 2
