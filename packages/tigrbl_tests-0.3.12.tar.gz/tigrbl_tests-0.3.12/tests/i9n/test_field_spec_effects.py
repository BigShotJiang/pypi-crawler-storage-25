from types import SimpleNamespace

import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient
from sqlalchemy.orm import sessionmaker
from tigrbl import TigrblApp, TigrblRouter
from tigrbl import resolver as _resolver
from tigrbl.shortcuts.engine import mem
from tigrbl.orm.mixins import GUIDPk
from tigrbl.orm.tables import TableBase
from tigrbl_atoms.atoms.schema.collect_in import _run as collect_in_run
from tigrbl._spec import IO, F, S
from tigrbl.shortcuts.column import acol
from tigrbl.types import String


@pytest_asyncio.fixture
async def fs_app():
    TableBase.metadata.clear()
    cfg = mem(async_=False)
    _resolver.set_default(cfg)
    prov = _resolver.resolve_provider()
    engine, maker = prov.ensure()
    SessionLocal = sessionmaker(bind=engine, expire_on_commit=False)

    class FSItem(TableBase, GUIDPk):
        __tablename__ = "fs_items"
        name = acol(
            storage=S(type_=String, nullable=False),
            field=F(
                constraints={"max_length": 5},
                required_in=("create",),
                allow_null_in=("update",),
            ),
            io=IO(in_verbs=("create", "update"), out_verbs=("read",)),
        )

    TableBase.metadata.create_all(engine)
    app = TigrblApp()
    router = TigrblRouter(engine=cfg)
    app.include_table(FSItem)
    app.initialize()
    app.include_router(router)
    transport = ASGITransport(app=app)
    client = AsyncClient(transport=transport, base_url="http://test")
    try:
        yield client, app, SessionLocal, FSItem
    finally:
        await client.aclose()
        engine.dispose()
        _resolver.set_default(None)


@pytest.mark.i9n
@pytest.mark.asyncio
async def test_field_spec_openapi(fs_app):
    client, _, _, _ = fs_app
    spec = (await client.get("/openapi.json")).json()
    schema = spec["components"]["schemas"]["FSItemCreateRequest"]
    assert "name" in schema["required"]
    assert schema["properties"]["name"]["type"] == "string"


@pytest.mark.i9n
@pytest.mark.asyncio
async def test_field_spec_column_length(fs_app):
    _, _, _, FSItem = fs_app
    assert FSItem.__table__.c.name.type.length == 5


@pytest.mark.i9n
@pytest.mark.asyncio
async def test_field_spec_rest_required(fs_app):
    client, _, _, _ = fs_app
    resp = await client.post("/fsitem", json={})
    assert resp.status_code == 422


@pytest.mark.i9n
@pytest.mark.asyncio
async def test_field_spec_allow_null_update(fs_app):
    client, _, SessionLocal, FSItem = fs_app
    create = await client.post("/fsitem", json={"name": "ok"})
    item_id = create.json()["id"]
    upd = await client.patch(f"/fsitem/{item_id}", json={"name": None})
    assert upd.status_code == 422


@pytest.mark.i9n
@pytest.mark.asyncio
async def test_field_spec_rpc_required(fs_app):
    _, app, SessionLocal, FSItem = fs_app
    with SessionLocal() as session:
        with pytest.raises(Exception):
            await app.rpc_call(FSItem, "create", payload={}, db=session)


@pytest.mark.i9n
@pytest.mark.asyncio
async def test_field_spec_core_crud_create(fs_app):
    _, app, SessionLocal, FSItem = fs_app
    with SessionLocal() as session:
        obj = await app.core.FSItem.create({"name": "hi"}, db=session)
        assert obj["name"] == "hi"


@pytest.mark.i9n
@pytest.mark.asyncio
async def test_field_spec_collect_in_atom(fs_app):
    _, _, _, FSItem = fs_app
    specs = FSItem.__tigrbl_cols__
    ctx = SimpleNamespace(specs=specs, op="create", temp={})
    collect_in_run(None, ctx)
    schema = ctx.temp["schema_in"]
    assert schema["by_field"]["name"]["required"] is True
