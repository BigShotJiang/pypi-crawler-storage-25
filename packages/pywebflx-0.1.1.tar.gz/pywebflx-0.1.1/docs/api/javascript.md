# JavaScript

Methods for executing custom JavaScript on the page.

---

## execute_js

Executes JavaScript code and returns the result.

```python
result = await browser.execute_js("return document.title")
```

### Examples

```python
# Page title
title = await browser.execute_js("return document.title")

# Current URL
url = await browser.execute_js("return window.location.href")

# Scroll to bottom
await browser.execute_js("return window.scrollTo(0, document.body.scrollHeight)")
```

!!! note "Limitation"
    `execute_js` supports simple expressions with `return`. For complex logic, use `extract_data` or manipulate via `click`/`type_into`.

---

## inject_js

Executes JavaScript without waiting for a return value.

```python
await browser.inject_js("window.scrollTo(0, 0)")
```

---

## switch_to (iframes)

Switches the context into an iframe.

```python
async with browser.switch_to("#iframe-content") as frame:
    await frame.click("#btn-inside-iframe")
    text = await frame.get_text(".result")
```

!!! warning "Under development"
    Iframe support is planned for v2. Currently `switch_to` returns the same context.
