# Navigation

Methods for navigating between pages, refreshing, and closing tabs.

---

## navigate_to

Navigates to a URL in the current tab.

```python
await browser.navigate_to("https://portal.example.com/dashboard")
```

---

## go_back

Goes back in the browser history.

```python
await browser.go_back()
```

---

## go_forward

Goes forward in the browser history.

```python
await browser.go_forward()
```

---

## refresh

Reloads the current page.

```python
await browser.refresh()
```

---

## close_tab

Closes the current tab.

```python
await browser.close_tab()
```

---

## close_browser

Closes the browser (all tabs).

```python
await browser.close_browser()
```
