# Synchronization

Methods for waiting for elements to appear, disappear, or checking existence.

---

## element_exists

Checks whether an element exists on the page.

```python
exists = await browser.element_exists(selector, timeout=0)
```

### Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `selector` | `str` | -- | CSS selector or XPath |
| `timeout` | `float` | `0` | If > 0, waits up to N seconds |

### Examples

```python
# Instant check
if await browser.element_exists("#success-modal"):
    print("Success!")

# Wait up to 5 seconds
if await browser.element_exists("#result", timeout=5):
    text = await browser.get_text("#result")
```

---

## wait_element

Waits for an element to meet a condition. Raises an error on timeout.

```python
await browser.wait_element(selector, condition="visible", timeout=None)
```

### Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `selector` | `str` | -- | CSS selector or XPath |
| `condition` | `str` | `"visible"` | `"visible"`, `"clickable"`, `"present"` |
| `timeout` | `float` | config | Timeout in seconds |

### Example

```python
await browser.wait_element("#loading", condition="visible", timeout=10)
await browser.click("#loading")
```

### Exception

Raises `ElementTimeoutError` if the condition is not met within the timeout.

---

## wait_element_vanish

Waits for an element to disappear from the page.

```python
await browser.wait_element_vanish(selector, timeout=None)
```

### Example

```python
await browser.click("#btn-save")
await browser.wait_element_vanish("#spinner", timeout=15)
print("Saved successfully!")
```

### Exception

Raises `ElementTimeoutError` if the element still exists after the timeout.

---

## find_element

Finds an element and returns information about it.

```python
info = await browser.find_element(selector)
```

### Return

```python
{
    "tag": "button",
    "id": "btn-login",
    "classes": ["btn", "btn-primary"],
    "text": "Sign In",
    "visible": True,
}
```

### Example

```python
el = await browser.find_element("#btn-submit")
if el["visible"]:
    await browser.click("#btn-submit")
```
