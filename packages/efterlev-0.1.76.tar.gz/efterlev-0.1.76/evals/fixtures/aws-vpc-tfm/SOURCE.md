# Source attribution — `aws-vpc-tfm` eval fixture

The Terraform under `infra/` is vendored verbatim from the
[`terraform-aws-modules/terraform-aws-vpc`](https://github.com/terraform-aws-modules/terraform-aws-vpc)
project at tag **v6.6.1** (commit `3ffbd46fb1c7733e1b34d8666893280454e27436`).
Vendored 2026-05-11.

## Why this corpus

This is **the** most-used VPC module in the Terraform AWS ecosystem
(by Terraform Registry download count). It exercises the canonical
real-world pattern of variable-driven, conditional-resource AWS
networking that a FedRAMP-pursuing customer's boundary actually
looks like — not the synthetic resource-per-detector shape the
in-repo eval fixtures (`govnotes-v1`, `encryption-mixed`, etc.) use
to lock specific detector behavior.

It's the first **Phase 2 lite** fixture per the strategic-arc
decision recorded in CLAUDE.md (2026-05-11 "Strategic arc post-
v0.1.58 — quality scaffolding before market expansion"). The
synthetic in-repo fixtures all hit 1.000 / 0.000 on the eval
metrics — overfit because the prompts were tuned against them.
Real-shape fixtures from third-party Terraform are the regression
instrument that catches that overfit.

## License

Apache 2.0 — full text in `infra/LICENSE`. Original copyright by
the terraform-aws-modules contributors. This fixture is a
derivative work used solely for testing efterlev's classification
quality; no modifications to the upstream code (the `infra/`
subdirectory mirrors the upstream repo root exactly).

## Updating

To update the vendored snapshot to a new upstream tag:

```bash
TAG="v6.7.0"  # or whatever
mkdir -p /tmp/tfm-vpc-update && cd /tmp/tfm-vpc-update
for f in main.tf variables.tf outputs.tf versions.tf LICENSE; do
  curl -sSL "https://raw.githubusercontent.com/terraform-aws-modules/terraform-aws-vpc/${TAG}/${f}" -o "${f}"
done
cp /tmp/tfm-vpc-update/* /path/to/efterlev/evals/fixtures/aws-vpc-tfm/infra/
# Then bump the tag + commit SHA in this SOURCE.md, re-run the eval
# harness against the new fixture, and re-grade GROUND_TRUTH.yaml
# entries the upstream changes invalidate.
```

## What this fixture exercises

The upstream module's `main.tf` declares (variable-conditioned)
~50 raw `aws_*` resource types across:
- VPC + IPv6 + DHCP options
- Subnets (public, private, database, redshift, elasticache,
  intra) — each with their own routing
- Internet Gateway, NAT Gateways, Egress-Only IGW
- Route tables + routes
- Network ACLs (per subnet tier)
- VPN gateway + routes
- Default security group + default NACL + default route table
  hardening
- Customer gateways

This shape is what efterlev's HCL parser sees on a real customer
scan. Many resource attributes are `var.x` references (unresolved
without a `terraform plan -out`), so the fixture also exercises
the `unparseable` evidence path the v0.1.5+ plan-JSON-recommendation
code recommends in that case.

The resource diversity should exercise — at minimum — these
detector dimensions: KSI-MLA-* (flow logs, when var-enabled),
KSI-CNA-* (subnet segmentation, NACL coverage), KSI-CMT-* (VPC
route-table hygiene). Many won't fire because the conditional
resources are gated on input variables that look "off" to a static
parser; the GROUND_TRUTH labeling work captures which KSIs the
fixture honestly evidences vs which the agent should classify
`evidence_layer_inapplicable`.
