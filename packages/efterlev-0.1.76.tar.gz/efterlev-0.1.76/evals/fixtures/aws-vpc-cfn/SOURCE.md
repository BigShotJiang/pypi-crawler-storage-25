# Source attribution — `aws-vpc-cfn` eval fixture

The CloudFormation template under `infra/` is vendored verbatim from
the [`aws-quickstart/quickstart-aws-vpc`](https://github.com/aws-quickstart/quickstart-aws-vpc)
project at commit **`e7ab8614e05bcaf0b87aadbafa8c1916274a07c7`** (main HEAD
as of 2026-05-12).

## Why this corpus

First Phase 2 lite **CFN-shape** fixture (Tier 5 #1 PR β scope per
DECISIONS 2026-05-12). The companion to `aws-vpc-tfm` on the
Terraform side: same conceptual shape (real-shape AWS VPC with
subnets + NACLs + routing), AWS-published, Apache 2.0, well-known.
Lets us validate the CFN parser + adapter against a non-trivial
real-world template.

It's the AWS Quick Start VPC reference architecture — used by
thousands of FedRAMP-pursuing customers as the foundation for their
boundary's networking layer.

## License

Apache 2.0 — full text in `infra/LICENSE.txt`. Original copyright by
the AWS Quick Start contributors. This fixture is a derivative work
used solely for testing efterlev's CFN parser + adapter; no
modifications to the upstream code (the `infra/` subdirectory mirrors
the upstream repo's `templates/aws-vpc.template.yaml` exactly).

## What this fixture exercises (v0.1.72 plumbing)

The upstream template declares ~80 raw `AWS::EC2::*` resources
(VPCs, Subnets, RouteTables, Routes, InternetGateway, NATGateway,
EIPs, NetworkAcls, NetworkAclEntries, FlowLogs, EIPAssociations,
plus Conditions / Mappings / Parameters).

At v0.1.72 (PR β plumbing-only):
- The parser correctly loads all CFN intrinsics (`!Ref`, `!Sub`,
  `!GetAtt`, `!If`, `!Equals`, `!Join`, `!FindInMap`, etc.)
- The adapter translates types: `AWS::EC2::VPC` → `aws_vpc`,
  `AWS::EC2::Subnet` → `aws_subnet`, etc.
- Existing Terraform-source detectors filter the CFN-adapted
  resources via `r.type` and SEE them, but read no property data
  (per-detector property-mapping is PR γ work).

The "GROUND_TRUTH.yaml is empty for now" pattern matches v0.1.63's
`aws-vpc-tfm` initial-state — labels accumulate after PR γ ships
property mapping that lets detectors actually emit evidence on
CFN-shaped resources.

## Updating

```bash
TAG="vX.Y.Z"   # or commit SHA from main
mkdir -p /tmp/aws-vpc-cfn-update && cd /tmp/aws-vpc-cfn-update
curl -sSL -o aws-vpc.template.yaml \
    "https://raw.githubusercontent.com/aws-quickstart/quickstart-aws-vpc/${TAG}/templates/aws-vpc.template.yaml"
curl -sSL -o LICENSE.txt \
    "https://raw.githubusercontent.com/aws-quickstart/quickstart-aws-vpc/${TAG}/LICENSE.txt"
cp aws-vpc.template.yaml LICENSE.txt /path/to/efterlev/evals/fixtures/aws-vpc-cfn/infra/
# Then bump the SHA in this SOURCE.md.
```
