# Source attribution — `aws-lambda-tfm` eval fixture

The Terraform under `infra/` is vendored verbatim from the
[`terraform-aws-modules/terraform-aws-lambda`](https://github.com/terraform-aws-modules/terraform-aws-lambda)
project at tag **v8.8.0** (commit
`b842374147fc07731d79028517223e9e0cbaab6d`). Vendored 2026-05-11.

## Why this corpus

Third Phase 2 lite fixture. Where `aws-vpc-tfm` exercises
network/segmentation and `aws-s3-bucket-tfm` exercises
storage/encryption, this fixture exercises the **serverless
compute** detector dimensions — `aws.lambda_logging_configured`,
`aws.lambda_vpc_isolation`, `aws.lambda_env_kms_encryption` (when
KMS-encrypted env vars are present), plus the AU-class
log-aggregation detectors. Different shape from VPC + S3; rounds
out the per-detector-family Phase 2 lite coverage to the three
most-common AWS workload patterns.

## License

Apache 2.0 — full text in `infra/LICENSE`. Original copyright by
the terraform-aws-modules contributors. This fixture is a derivative
work used solely for testing efterlev's classification quality; no
modifications to the upstream code (the `infra/` subdirectory mirrors
the upstream repo root exactly).

## Updating

```bash
TAG="v8.9.0"  # or whatever
mkdir -p /tmp/tfm-lambda-update && cd /tmp/tfm-lambda-update
for f in main.tf variables.tf outputs.tf versions.tf LICENSE; do
  curl -sSL "https://raw.githubusercontent.com/terraform-aws-modules/terraform-aws-lambda/${TAG}/${f}" -o "${f}"
done
cp /tmp/tfm-lambda-update/* /path/to/efterlev/evals/fixtures/aws-lambda-tfm/infra/
# Then bump the tag + commit SHA in this SOURCE.md.
```

## What this fixture exercises

The upstream module's `main.tf` declares ~15 raw `aws_*` and
`null_*` resource types focused on Lambda function lifecycle:
`aws_lambda_function`, `aws_lambda_layer_version`,
`aws_lambda_permission` (×2), `aws_lambda_event_source_mapping`,
`aws_lambda_function_event_invoke_config`,
`aws_lambda_function_recursion_config`, `aws_lambda_function_url`,
`aws_cloudwatch_log_group` (×2), data sources for caller identity
+ region.

Detectors that fire (4 evidence records emitted from a clean scan):
- `aws.lambda_logging_configured` — `logging_state: unverifiable`
  because `function_name = var.function_name` blocks log-group
  linkage at parse time.
- `aws.lambda_vpc_isolation` — `isolation_state: internet_facing`
  (function has no vpc_config block; runs in default VPC pool).
- `aws.centralized_log_aggregation` — `aggregation_state:
  producers_only` (2 log groups exist but no centralization
  primitive).
- `aws.terraform_inventory` — always-fires `tracked`.

The "internet_facing" verdict on `lambda_vpc_isolation` is
particularly interesting: it's the canonical real-customer pattern
where a Lambda module declares a function with no VPC config, and
the caller is expected to provide one. Whether THIS is honest
`not_implemented` (the module ships a non-isolated Lambda) or
`partial` (the module supports VPC config; just doesn't enable
it by default) is exactly the kind of judgment call Phase 2 lite
labeling should resolve.
