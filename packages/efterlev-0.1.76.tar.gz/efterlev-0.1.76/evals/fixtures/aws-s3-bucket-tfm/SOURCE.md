# Source attribution — `aws-s3-bucket-tfm` eval fixture

The Terraform under `infra/` is vendored verbatim from the
[`terraform-aws-modules/terraform-aws-s3-bucket`](https://github.com/terraform-aws-modules/terraform-aws-s3-bucket)
project at tag **v5.13.0** (commit
`af0286ff37a66c2b79faf360e6e2663744b8e5b5`). Vendored 2026-05-11.

## Why this corpus

Companion to `aws-vpc-tfm` (also from the terraform-aws-modules
ecosystem). Where `aws-vpc-tfm` exercises the network/segmentation
detector dimensions, this fixture exercises the **storage +
encryption** dimensions — `aws_s3_bucket`, server-side encryption
configuration, public-access-block, lifecycle, replication, ownership
controls, and bucket policy. Different shape from VPC; broadens the
Phase 2 lite regression instrument across the detector library.

It's the second **Phase 2 lite** fixture per the strategic-arc
decision recorded in CLAUDE.md (2026-05-11 "Strategic arc post-
v0.1.58"). One fixture per detector family is the long-term
target; v0.1.64 shipped fixture #1 (VPC), v0.1.65 ships fixture
#2 (S3 bucket), with IAM and RDS as natural next vendoring picks.

## License

Apache 2.0 — full text in `infra/LICENSE`. Original copyright by
the terraform-aws-modules contributors. This fixture is a derivative
work used solely for testing efterlev's classification quality; no
modifications to the upstream code (the `infra/` subdirectory mirrors
the upstream repo root exactly).

## Updating

To update the vendored snapshot to a new upstream tag:

```bash
TAG="v5.14.0"  # or whatever
mkdir -p /tmp/tfm-s3-update && cd /tmp/tfm-s3-update
for f in main.tf variables.tf outputs.tf versions.tf LICENSE; do
  curl -sSL "https://raw.githubusercontent.com/terraform-aws-modules/terraform-aws-s3-bucket/${TAG}/${f}" -o "${f}"
done
cp /tmp/tfm-s3-update/* /path/to/efterlev/evals/fixtures/aws-s3-bucket-tfm/infra/
# Then bump the tag + commit SHA in this SOURCE.md, re-run the
# eval harness against the new fixture, and re-grade
# GROUND_TRUTH.yaml entries the upstream changes invalidate.
```

## What this fixture exercises

The upstream module's `main.tf` declares (variable-conditioned)
~20 `aws_*` resource types focused on bucket lifecycle, including:
- `aws_s3_bucket` (the bucket itself)
- `aws_s3_bucket_server_side_encryption_configuration` (KSI-AFR-UCM
  via `aws.encryption_s3_at_rest`; KSI-SVC-PRR via
  `aws.svc_at_rest_encryption_coverage`)
- `aws_s3_bucket_public_access_block` (`aws.s3_public_access_block`)
- `aws_s3_bucket_acl` (`aws.s3_bucket_public_acl`)
- `aws_s3_bucket_lifecycle_configuration`
  (`aws.s3_lifecycle_policies`)
- `aws_s3_bucket_logging` (`aws.centralized_log_aggregation`)
- `aws_s3_bucket_versioning`
- `aws_s3_bucket_ownership_controls`
- `aws_s3_bucket_policy`
- `aws_s3_bucket_replication_configuration`
- `aws_s3_bucket_object_lock_configuration`
- `aws_s3_bucket_intelligent_tiering_configuration`
- `aws_s3_bucket_inventory`
- `aws_s3_bucket_metric`
- `aws_s3_bucket_request_payment_configuration`

Many resources are gated on `var.create_bucket`-style conditionals;
the parser sees the `count = var.X ? 1 : 0` pattern and emits
`unparseable` evidence for those attributes. The detectors that
read literal values (e.g. checking
`server_side_encryption_configuration.rule.apply_server_side_encryption_by_default.sse_algorithm`)
will report what they can resolve and fall back to `unparseable`
elsewhere — the same real-customer signal the VPC fixture exercises,
applied to a different resource family.
