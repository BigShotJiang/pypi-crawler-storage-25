# Phase 2 lite maintainer validation (v0.1.69)

The maintainer-review-pass step from `PHASE_2_LITE_LABEL_REVIEW.md`
("Step 2: run the harness against each fixture, compare to my labels")
has been executed. Results: **67/67 labels validated, 100% precision
+ 100% recall on every fixture, 0 overrides needed**.

This document records the side-by-side comparison and the
implications for the strategic-arc gate (CFN synth-mode now genuinely
unblocked).

---

## Methodology

For each of the 3 Phase 2 lite real-shape fixtures, ran:

```
python -m evals run --fixture evals/fixtures/<id> \
  --llm-backend anthropic --llm-model claude-haiku-4-5
```

Captured the agent's per-KSI verdicts from
`<run-dir>/workspace/.efterlev/reports/gap-*.json` and compared to
the labels in `evals/fixtures/<id>/GROUND_TRUTH.yaml` (post-v0.1.67
revisions).

---

## Per-fixture results

### aws-vpc-tfm (revision 3, 21 labels)

```
status_precision      100.0%  (21/21)
status_recall         100.0%  (21/21)
poam_scope_discipline 100.0%  (2/2)
```

| KSI | Drafted label | Agent verdict | Match |
|---|---|---|---|
| **KSIs WITH detector evidence** | | | |
| KSI-CNA-MAT | `partial\|not_implemented` | `partial` | ✅ |
| KSI-CNA-RNT | `partial\|not_implemented` | `partial` | ✅ |
| KSI-CNA-ULN | `partial\|not_implemented` | `partial` | ✅ |
| KSI-PIY-GIV | `partial` | `partial` | ✅ |
| **Procedural-only KSIs (17)** | all `evidence_layer_inapplicable\|not_applicable` | all `evidence_layer_inapplicable` | all ✅ |
| KSI-PIY-RSD | `not_implemented\|evidence_layer_inapplicable` | `evidence_layer_inapplicable` | ✅ |

All 4 alternation labels for the WITH-evidence KSIs resolved to
`partial` — the agent never picked `not_implemented`. The v0.1.67
loosenings (CNA-MAT and CNA-RNT alternation expansion from `partial`
to `partial|not_implemented`) were defensive and weren't exercised
by the agent's actual verdicts, but the looser label still matched.

### aws-s3-bucket-tfm (revision 2, 25 labels)

```
status_precision      100.0%  (25/25)
status_recall         100.0%  (25/25)
poam_scope_discipline 100.0%  (2/2)
```

| KSI | Drafted label | Agent verdict | Match |
|---|---|---|---|
| **KSIs WITH detector evidence** | | | |
| KSI-AFR-UCM | `partial` (post-v0.1.67 tightening) | `partial` | ✅ |
| KSI-CNA-MAT | `not_implemented\|partial` | `partial` | ✅ |
| KSI-CNA-RNT | `not_implemented\|partial` | `partial` | ✅ |
| KSI-CNA-OFA | `partial` | `partial` | ✅ |
| KSI-IAM-AAM | `partial` | `partial` | ✅ |
| KSI-PIY-GIV | `partial` | `partial` | ✅ |
| KSI-RPL-ABO | `not_implemented\|partial` | `partial` | ✅ |
| KSI-SVC-RUD | `not_implemented\|partial` (post-v0.1.67 loosening) | `not_implemented` | ✅ |
| **Procedural-only KSIs (17)** | all `evidence_layer_inapplicable\|not_applicable` | all `evidence_layer_inapplicable` | all ✅ |

**v0.1.67 tightening confirmed:** AFR-UCM revised from
`partial|not_implemented` → `partial` was correct — the agent picks
exactly `partial` (recognizing the split-resource SSE pattern as real
encryption). If I'd kept the `partial|not_implemented` alternation,
this would still have matched, but the tightened label is more
informative as a regression-detection signal.

**v0.1.67 loosening exercised:** SVC-RUD revised from
`not_implemented` → `not_implemented|partial` — the agent picks
`not_implemented` (the placeholder-lifecycle reading). If I'd left
the original `not_implemented`, this would still match. The
alternation captures the "you could honestly call either" framing
without changing the validated outcome.

### aws-lambda-tfm (revision 2, 21 labels)

```
status_precision      100.0%  (21/21)
status_recall         100.0%  (21/21)
poam_scope_discipline 100.0%  (2/2)
```

| KSI | Drafted label | Agent verdict | Match |
|---|---|---|---|
| **KSIs WITH detector evidence** | | | |
| KSI-CNA-MAT | `not_implemented` (post-v0.1.67 tightening) | `not_implemented` | ✅ |
| KSI-MLA-LET | `partial` (post-v0.1.67 tightening) | `partial` | ✅ |
| KSI-MLA-OSM | `not_implemented` | `not_implemented` | ✅ |
| KSI-PIY-GIV | `partial` | `partial` | ✅ |
| **Procedural-only KSIs (17)** | all `evidence_layer_inapplicable\|not_applicable` | all `evidence_layer_inapplicable` | all ✅ |

**Both v0.1.67 tightenings on this fixture nailed the agent's exact
verdict:**
- KSI-CNA-MAT: revised `not_implemented|partial` → `not_implemented`
  — agent picks `not_implemented`. The `partial` alternation was
  reading-into-the-future (as the v0.1.67 review noted); dropping
  it produces a sharper regression-detection target.
- KSI-MLA-LET: revised `not_implemented|partial` → `partial` —
  agent picks `partial`. The fixture's 2 `aws_cloudwatch_log_group`
  resources are real logging infrastructure; the agent correctly
  recognizes them despite the unparseable function-name link.

---

## Aggregate

| Fixture | Labels | Precision | Recall | Overrides needed |
|---|---|---|---|---|
| aws-vpc-tfm | 21 | 100% | 100% | 0 |
| aws-s3-bucket-tfm | 25 | 100% | 100% | 0 |
| aws-lambda-tfm | 21 | 100% | 100% | 0 |
| **Total** | **67** | **100%** | **100%** | **0** |

POAM scope discipline (M5) also scored 100% on every fixture.

LLM cost for the validation pass: ~67k input + ~8k output tokens
per fixture on Haiku 4.5 = roughly $0.10-0.15 total across the
three fixtures.

---

## Implications

### The labels are usable as a regression instrument

Phase 2 lite was designed to catch the regression class
"prompt change works fine on hand-crafted fixtures but degrades
on real-customer variable-driven Terraform" (per the strategic-arc
memory). Now that 67 labels validate against the current
Haiku 4.5 prompts at 100/100, the harness has:

- **A baseline** — the current state that future runs are measured against.
- **Real-shape exposure** — every label was validated against
  vendored real-world Terraform (`terraform-aws-modules/*`), not
  synthetic in-repo fixtures.
- **Bidirectional sensitivity** — both M1 (precision: false-positive
  catches) and M2 (recall: false-negative catches) are computable
  and fully exercised.

### What this validation does NOT prove

- **The labels won't degrade on a different model.** Haiku 4.5 was
  the validation target. Switching CI to a different model (e.g.,
  Sonnet, or a future Haiku 5) requires re-running this validation
  pass to see whether labels survive.
- **The labels won't degrade on prompt changes.** That's the whole
  point — they're a regression *instrument*. The first prompt
  change after this validation will tell us whether labels move
  with the change (instrument-bug) or stay stable (catches a real
  regression).
- **The labels are "right" in any deeper sense.** The agent and the
  evidence-based reasoning both produced the same verdict. That's
  internal consistency, not external truth. A FedRAMP 3PAO might
  read one of these fixtures and disagree with both — that's a
  ground-truth question separate from instrument calibration.

### Strategic-arc gate

Per the 2026-05-11 strategic-arc memory: Phase 2 lite was the gating
prerequisite before CFN synth-mode market-expansion work, because
"expanding IaC surface area without a regression instrument
multiplies exposure to disappointment."

**The instrument is now operational.** Three fixtures, 67 labels,
100/100 baseline. The CFN synth-mode design discussion is unblocked
on this dimension.

---

## Suggested next steps

1. **Add Phase 2 lite to the e2e-smoke / pre-merge gate cadence.**
   Currently the harness runs locally on demand; promoting it to
   "any prompt-touching PR triggers a Phase 2 lite eval run with
   regression flag" is the v0.3.0 Phase 3 work referenced in
   `docs/v0.2-eval-harness-plan.md`. With validated labels, this is
   now safe to start scoping.
2. **Vendor 1-2 more fixtures (RDS, IAM standalone)** if you want
   broader coverage before CFN expansion. The IAM cluster is
   particularly under-exercised in the current 3-fixture corpus.
3. **Start the CFN synth-mode DECISIONS entry.** Cover scope (e.g.,
   `cdk synth` JSON output as the input format), detector-IR
   refactor question, design-partner recruitment plan.

The 3 are independent; can be parallelized.
