# Phase 2 lite label review (v0.1.67)

Second-pass review of the 67 conservative draft labels shipped across
`aws-vpc-tfm` (v0.1.64), `aws-s3-bucket-tfm` (v0.1.65), and
`aws-lambda-tfm` (v0.1.66). All v0.1.64-v0.1.66 labels were authored
by reading the deterministic `efterlev scan` output (no LLM verdict
inspected) per the conservative-and-evidence-based discipline
documented in each fixture's `GROUND_TRUTH.yaml` header.

This review re-reads each label against (a) the canonical FRMR
statement for the KSI, (b) the available scan evidence, (c) the
discipline notes in `GROUND_TRUTH_FORMAT.md`. Output: `confirm`,
`revise`, or `flag` for each. Revisions land in the corresponding
`GROUND_TRUTH.yaml` (revision bumped accordingly).

**Maintainer's job, when the API key is set:** run `python -m evals
run --fixture <fixture-dir>` against each fixture, capture the agent
verdicts, compare to the labels in `GROUND_TRUTH.yaml`, override
where domain expertise disagrees with the evidence-based reasoning
documented here.

---

## Methodology recap

For each KSI:
- **Statement:** the FRMR-canonical definition
- **Evidence:** what the scan emitted (or "(none — procedural)")
- **Drafted label:** what shipped in v0.1.64-v0.1.66
- **Second-pass:** reasoning on whether the label still holds
- **Confidence:** high / medium / low
- **Decision:** `confirm` / `revise` (with new label) / `flag` (for human spot-check)

---

## aws-vpc-tfm fixture (21 labels)

### KSIs WITH detector evidence (4)

#### KSI-CNA-MAT — Minimizing Attack Surface
- **Statement:** Persistently ensure machine-based information resources have a minimal attack surface and that lateral movement is minimized if compromised.
- **Evidence:** 7 NACLs, all `posture_state = partially_restrictive`, all `has_explicit_deny = false`, none `ingress_open_to_world`.
- **Drafted label:** `partial`
- **Second-pass:** NACLs are present and not open-to-world — lateral-movement minimization IS evidenced at the network-layer. The "no explicit deny" gap is real but doesn't invalidate the partial-implementation claim (AWS implicit deny does the actual blocking at the segment boundary). The agent could honestly call this `partial` (which the label says) OR `not_implemented` (if it weighs the missing-deny rule heavily as "not following defense-in-depth").
- **Confidence:** medium (partial fits, but alternation would match how we handled KSI-CNA-RNT in fixture #2)
- **Decision:** **revise** → `partial|not_implemented` (add alternation for symmetry; an honest agent could call either way)

#### KSI-CNA-RNT — Restricting Network Traffic
- **Statement:** Persistently ensure all machine-based information resources are configured to limit inbound and outbound network traffic.
- **Evidence:** Same 7 NACLs.
- **Drafted label:** `partial`
- **Second-pass:** Same reasoning as CNA-MAT.
- **Confidence:** medium
- **Decision:** **revise** → `partial|not_implemented`

#### KSI-CNA-ULN — Using Logical Networking
- **Statement:** Use logical networking and related capabilities to enforce traffic flow controls.
- **Evidence:** 1 record from `aws.vpc_logical_segmentation`: `segmentation_state: undefined` because the var-driven cidr block prevented subnet-to-vpc linkage at parse time.
- **Drafted label:** `partial|not_implemented`
- **Second-pass:** Both verdicts are defensible. **The VPC IS declared** and 7 subnets exist (per `terraform_inventory` evidence) — the parser just couldn't trace them to the VPC because of HCL variable resolution. An agent reading the fixture honestly should weight "VPC + subnets exist in the file" toward `partial` over the parser's inability to confirm linkage. But the literal detector evidence is "undefined", which an agent might over-weight to `not_implemented`. Conservative call: keep alternation.
- **Confidence:** medium-high (alternation justified)
- **Decision:** **confirm** → `partial|not_implemented`

#### KSI-PIY-GIV — Generating Inventories
- **Statement:** Use authoritative sources to automatically generate real-time inventories of all information resources when needed.
- **Evidence:** `aws.terraform_inventory` `inventory_state: tracked`, 27 distinct resource types, 74 total resources.
- **Drafted label:** `partial`
- **Second-pass:** Terraform IS an authoritative source for IaC inventory. Full implementation would also include cloud-runtime inventory (AWS Config, SSM Inventory). `partial` is honest — IaC half is evidenced.
- **Confidence:** high
- **Decision:** **confirm** → `partial`

### Procedural-only KSIs (17)

The 17 procedural-only labels (9 AFR-* excluding AFR-UCM, 4 CED-*, 3 INR-*, 1 PIY-RSD) are **all confirmed** with `evidence_layer_inapplicable|not_applicable`. Cross-checked each FRMR statement: every one is either explicitly procedural ("persistently review training," "operate a secure inbox," "integrate FedRAMP's procedures") or has zero detector-evidenceable controls in the FRMR. The fixture has no Evidence Manifests attesting to these procedural items.

KSI-PIY-RSD specifically: `not_implemented|evidence_layer_inapplicable` confirmed — github-source detectors were skipped via `--allow-subdir-target`, so the agent could honestly emit either verdict.

---

## aws-s3-bucket-tfm fixture (25 labels)

### KSIs WITH detector evidence (8)

#### KSI-AFR-UCM — Using Cryptographic Modules
- **Statement:** Ensure that cryptographic modules used to protect potentially sensitive federal customer data are selected and used in alignment with the FedRAMP 20x UCM guidance and persistently address all related requirements and recommendations.
- **Evidence:** 2 records from `aws.encryption_s3_at_rest` — one `present` (separate `aws_s3_bucket_server_side_encryption_configuration` resource), one `absent` (the `aws_s3_bucket` itself doesn't inline SSE).
- **Drafted label:** `partial|not_implemented`
- **Second-pass:** **The `not_implemented` alternation is too generous.** Encryption IS configured via the modern split-resource pattern (which is the post-2022 AWS best practice — inline SSE was deprecated). An agent that calls this `not_implemented` is failing to recognize the split-resource pattern, which is a real agent-quality bug worth catching. The honest verdict is `partial` — encryption is evidenced; full implementation requires customer attestation that the algorithm + key management align with FIPS 140 (which is procedural).
- **Confidence:** high
- **Decision:** **revise** → `partial` (drop the `not_implemented` alternation)

#### KSI-CNA-MAT — Minimizing Attack Surface
- **Statement:** As above.
- **Evidence:** 1 record from `aws.s3_bucket_public_acl`: `exposure_state: unparseable` (policy built via `jsonencode`).
- **Drafted label:** `not_implemented|partial`
- **Second-pass:** When the parser hits `unparseable`, the honest verdict really depends on how the agent handles uncertainty. `evidence_layer_inapplicable` is also defensible ("we can't verify either way"). The current `not_implemented|partial` allows the two most-common-defensible verdicts; adding `evidence_layer_inapplicable` would over-broaden.
- **Confidence:** medium
- **Decision:** **confirm** → `not_implemented|partial`

#### KSI-CNA-RNT — Restricting Network Traffic
- Same reasoning as CNA-MAT for this fixture.
- **Decision:** **confirm** → `not_implemented|partial`

#### KSI-CNA-OFA — Optimizing for Availability
- **Statement:** Appropriately optimize machine-based information resources for high availability and rapid recovery.
- **Evidence:** 1 record from `aws.cna_optimizing_for_availability`: `availability_state: configured` (S3 replication present via `aws_s3_bucket_replication_configuration`).
- **Drafted label:** `partial`
- **Second-pass:** S3 replication IS one canonical availability primitive (cross-region/cross-account). `partial` is honest — single mechanism evidenced; full implementation would also include backup retention configuration, multi-AZ patterns for compute, etc.
- **Confidence:** high
- **Decision:** **confirm** → `partial`

#### KSI-IAM-AAM — Automating Account Management
- **Statement:** Securely manage the lifecycle and privileges of all accounts, roles, and groups, using automation.
- **Evidence:** 1 record from `aws.iam_managed_via_terraform`: `automation_state: tracked`, 13 `aws_iam_policy_document` data sources.
- **Drafted label:** `partial`
- **Second-pass:** 13 policy documents IS evidence of IaC-managed identity primitives (Terraform automating IAM). Full implementation would require IAM users + roles + groups (which this fixture lacks — it only has policy documents for the bucket policies). `partial` is honest.
- **Confidence:** high
- **Decision:** **confirm** → `partial`

#### KSI-PIY-GIV — Generating Inventories
- Same reasoning as VPC fixture.
- **Decision:** **confirm** → `partial`

#### KSI-RPL-ABO — Aligning Backups with Objectives
- **Statement:** Persistently review the alignment of machine-based information resource backups with defined recovery objectives.
- **Evidence:** 1 record from `aws.backup_retention_configured`: `backup_state: absent`, gap message explains versioning_status is var-driven and not resolvable.
- **Drafted label:** `not_implemented|partial`
- **Second-pass:** The `aws_s3_bucket_versioning` resource IS declared, but its enabled-status is var-driven (`var.versioning["enabled"]`) so the parser can't confirm it's actually on. An agent honestly reading this should weight the resource's existence toward `partial` (versioning IS being set up, just var-conditioned) but could also reason "we can't confirm it's enabled" toward `not_implemented`.
- **Confidence:** medium-high
- **Decision:** **confirm** → `not_implemented|partial`

#### KSI-SVC-RUD — Removing Unwanted Data
- **Statement:** Remove unwanted federal customer data promptly when requested by an agency in alignment with customer agreements, including from backups if appropriate.
- **Evidence:** 1 record from `aws.s3_lifecycle_policies`: `lifecycle_state: placeholder`, 0 enabled rules. Detector says explicitly: "the resource is a placeholder; SI-12 is not evidenced beyond the structural declaration."
- **Drafted label:** `not_implemented`
- **Second-pass:** The `aws_s3_bucket_lifecycle_configuration` resource exists but has zero enabled rules. An agent could call this `not_implemented` (zero rules = no actual implementation) OR `partial` (the resource exists; the customer started but didn't finish). The detector's explicit "placeholder" framing leans toward `not_implemented` but `partial` is defensible. Add alternation.
- **Confidence:** medium
- **Decision:** **revise** → `not_implemented|partial`

### Procedural-only KSIs (17)

Same set as `aws-vpc-tfm`, **all confirmed**. Note that AFR-UCM is correctly excluded from this set (it's evidenced by detector evidence above).

---

## aws-lambda-tfm fixture (21 labels)

### KSIs WITH detector evidence (4)

#### KSI-CNA-MAT — Minimizing Attack Surface
- **Statement:** Persistently ensure machine-based information resources have a minimal attack surface and that lateral movement is minimized if compromised.
- **Evidence:** 1 record from `aws.lambda_vpc_isolation`: `isolation_state: internet_facing` (Lambda has no `vpc_config` block; runs in default VPC pool).
- **Drafted label:** `not_implemented|partial`
- **Second-pass:** A Lambda with no `vpc_config` IS in the default VPC pool with internet egress — that's literally the opposite of "minimizing attack surface." Honest primary verdict: `not_implemented`. The `partial` alternation could apply if the agent reasons "the module supports vpc_config; just not enabled here" but that's reading-into-the-future, not labeling-the-evidence. Lean toward dropping the `partial` alternation.
- **Confidence:** medium-high
- **Decision:** **revise** → `not_implemented` (drop the `partial` alternation; the evidence is unambiguous about no vpc_config)

#### KSI-MLA-LET — Logging Event Types
- **Statement:** Maintain a list of information resources and event types that will be logged, monitored, and audited, then do so.
- **Evidence:** 1 record from `aws.lambda_logging_configured`: `logging_state: unverifiable` because `function_name = var.function_name` blocks log-group linkage.
- **Drafted label:** `not_implemented|partial`
- **Second-pass:** **Important re-look:** the fixture HAS 2 `aws_cloudwatch_log_group` resources (per terraform_inventory's top_resource_types). So logging IS configured — the parser just can't link the Lambda to its specific log group. The honest verdict is `partial` (logging infrastructure exists; the Lambda will produce logs to one of those groups). `not_implemented` would be wrong — logging IS being set up.
- **Confidence:** high (the log groups exist in the same fixture)
- **Decision:** **revise** → `partial` (drop the `not_implemented` alternation)

#### KSI-MLA-OSM — Operating SIEM Capability
- **Statement:** Operate a Security Information and Event Management (SIEM) or similar system(s) for centralized, tamper-resistent logging of events, activities, and changes.
- **Evidence:** 1 record from `aws.centralized_log_aggregation`: `aggregation_state: producers_only` — 2 log groups exist but ZERO centralization primitives (no Security Hub, no log destination, no subscription filter, no OpenSearch, no Firehose).
- **Drafted label:** `not_implemented`
- **Second-pass:** The detector is explicit: "Logs reach a SIEM only if forwarded by infrastructure declared elsewhere." The fixture provides ZERO centralization infrastructure. `not_implemented` is honest.
- **Confidence:** high
- **Decision:** **confirm** → `not_implemented`

#### KSI-PIY-GIV — Generating Inventories
- Same reasoning as prior two fixtures.
- **Decision:** **confirm** → `partial`

### Procedural-only KSIs (17)

Same set as the prior two fixtures, **all confirmed**.

---

## Revisions summary

| Fixture | KSI | From | To |
|---|---|---|---|
| aws-vpc-tfm | KSI-CNA-MAT | `partial` | `partial\|not_implemented` |
| aws-vpc-tfm | KSI-CNA-RNT | `partial` | `partial\|not_implemented` |
| aws-s3-bucket-tfm | KSI-AFR-UCM | `partial\|not_implemented` | `partial` |
| aws-s3-bucket-tfm | KSI-SVC-RUD | `not_implemented` | `not_implemented\|partial` |
| aws-lambda-tfm | KSI-CNA-MAT | `not_implemented\|partial` | `not_implemented` |
| aws-lambda-tfm | KSI-MLA-LET | `not_implemented\|partial` | `partial` |

6 revisions out of 67 labels (9% revision rate). All revisions are
either:
- **Tightening** (drop an alternation that's reading-into-the-future):
  s3 AFR-UCM, lambda CNA-MAT, lambda MLA-LET
- **Loosening** (add an alternation a second-look agent could honestly
  emit): vpc CNA-MAT, vpc CNA-RNT, s3 SVC-RUD

The remaining 61 labels (91%) survive second-pass review unchanged.

---

## Confidence distribution

- **High confidence (39 labels):** all 17 × 3 = 51 procedural-only
  labels and all `KSI-PIY-GIV` labels (3) — same content as the
  govnotes-v1 fixture's well-validated equivalents... actually
  procedural-only labels are 17 per fixture × 3 = 51 across all,
  plus 3 PIY-GIV, plus 1 CNA-OFA, plus 1 IAM-AAM, plus 1 AFR-UCM
  (after revision), plus 1 MLA-OSM, plus 1 MLA-LET (after revision)
  = ~58 high-confidence labels.
- **Medium confidence (8 labels):** the alternation-bearing labels
  on the WITH-evidence side where two verdicts are defensible.
- **Low confidence (1 label):** none after revision — every revised
  label is now medium-or-better.

---

## What the maintainer review pass should do

1. **Set `ANTHROPIC_API_KEY`** in the local shell.
2. **Run the harness against each fixture:**
   ```bash
   python -m evals run --fixture evals/fixtures/aws-vpc-tfm
   python -m evals run --fixture evals/fixtures/aws-s3-bucket-tfm
   python -m evals run --fixture evals/fixtures/aws-lambda-tfm
   ```
3. **Open each result snapshot** under `evals/results/<fixture>/<ts>/`
   and read the agent's per-KSI verdict.
4. **Compare to this review's reasoning + the labels in
   GROUND_TRUTH.yaml.** For each disagreement:
   - Is the agent's verdict honest given the evidence? Then the
     label is wrong; revise it.
   - Is the label's reasoning honest given the FRMR statement?
     Then the agent's verdict is the regression-instrument signal
     (the prompt is shipping a classification the evidence doesn't
     support).
5. **Bump `revision:` in each `GROUND_TRUTH.yaml`** when changes
   land, so the harness picks up the new labels on next run.

The 6 revisions listed in this doc are already applied to the
respective `GROUND_TRUTH.yaml` files in the same v0.1.67 commit.
