"""CFN→TF property-mapping table — per-resource-type body translators.

Per DECISIONS 2026-05-12 (Tier 5 #1, option (D)): a centralized table
mapping CFN property paths to TF body keys, with structural transforms
for the cases where CFN and TF disagree on nesting.

**Why this module exists.** The v0.1.72 adapter (PR beta) translates
only the CFN resource *type name* (`AWS::S3::Bucket` → `aws_s3_bucket`).
Detectors then filter by `r.type == "aws_s3_bucket"` and pass, but
when they reach into `r.body["server_side_encryption_configuration"]`
they find an empty dict — CFN's `BucketEncryption` block wasn't
translated. This module adds the property-translation layer, keeping
the change localized to a single table rather than fanning out into
every detector or refactoring the IR.

Module design — dict-of-functions, not pure data
================================================
Each entry is a `MappingFn`: takes the CFN `Properties` dict, returns
a list of `MappedResource` records. Most resource types emit a single
record (1→1 type translation, body restructured). A few resources whose
CFN structure folds multiple TF resources into one (notably
`AWS::S3::Bucket`'s `PublicAccessBlockConfiguration`) emit multiple
records — one TF-resource per logical concern.

We considered three alternatives before settling on this shape:

1. **Pure dict-of-dicts** (CFN path → TF path strings): simpler but
   can't express the structural transforms TF nested blocks require
   (e.g. CFN's flat `ServerSideEncryptionConfiguration: [ {...} ]`
   becomes TF's `server_side_encryption_configuration: [{"rule": [...
   ]}]` — an extra layer of wrapping the data path can't represent
   with renames alone).
2. **Pydantic schema models** per resource type: heavy for what is
   effectively a lookup table. The schema is the function body anyway.
3. **Per-detector dual-mode reads** (option (B) from DECISIONS
   2026-05-12): rejected because it scales as O(detectors), not
   O(resource types) — and we have ~10x more detectors than resource
   types planned. It also inflates the detector-count metric in
   misleading ways.

The dict-of-functions strikes the balance: each entry is readable
end-to-end (10-30 lines), powerful enough for structural transforms,
and the call site in the adapter stays trivially small.

Coverage at v0.1.74 (PR gamma.2 batch 1)
========================================
S3 + ELBv2 (v0.1.73 PR gamma):
- `AWS::S3::Bucket`                       → `aws_s3_bucket` + optional
                                            synthesized
                                            `aws_s3_bucket_public_access_block`
- `AWS::S3::BucketPolicy`                 → `aws_s3_bucket_policy`
- `AWS::ElasticLoadBalancingV2::Listener` → `aws_lb_listener`

EC2 + Logs (v0.1.74 PR gamma.2 batch 1):
- `AWS::EC2::FlowLog`                     → `aws_flow_log` (with
                                            `ResourceType`/`ResourceId`
                                            dispatch to vpc_id /
                                            subnet_id / eni_id)
- `AWS::EC2::SecurityGroup`               → `aws_security_group` (with
                                            CFN `SecurityGroupIngress`/
                                            `Egress` list translation
                                            into TF inline-block shape)
- `AWS::EC2::Volume`                      → `aws_ebs_volume`
- `AWS::Logs::LogGroup`                   → `aws_cloudwatch_log_group`

KMS + RDS + Lambda (v0.1.76 PR gamma.2 batch 3):
- `AWS::KMS::Key`                         → `aws_kms_key` (with
                                            `KeySpec` →
                                            `customer_master_key_spec`
                                            translation for legacy TF
                                            attribute name)
- `AWS::RDS::DBInstance`                  → `aws_db_instance`
- `AWS::Lambda::Function`                 → `aws_lambda_function` (with
                                            `Environment.Variables` and
                                            `VpcConfig` flat-dict-to-
                                            list-wrapped-block
                                            translation)

IAM (v0.1.75 PR gamma.2 batch 2):
- `AWS::IAM::Role`                        → `aws_iam_role` + synthesized
                                            `aws_iam_role_policy_attachment`
                                            per `ManagedPolicyArns` entry
                                            + synthesized
                                            `aws_iam_role_policy` per
                                            inline `Policies` entry
                                            (1→1+N+M)
- `AWS::IAM::ManagedPolicy`               → `aws_iam_policy`
- `AWS::IAM::User`                        → `aws_iam_user` + synthesized
                                            `aws_iam_user_policy_attachment`
                                            per `ManagedPolicyArns` entry
                                            + synthesized
                                            `aws_iam_user_policy` per
                                            inline `Policies` entry

The v0.1.73 batch validated the mapping shape against three sample
detectors. The v0.1.74 batch covers the EC2 family that the existing
`aws-vpc-cfn` fixture immediately exercises. The v0.1.75 batch (IAM)
introduces the most-detector-dense family: 5+ detectors read IAM TF
resources, but several read TF separation-of-concerns resources
(role-policy-attachment, role-policy) that CFN bundles inline — the
1→1+N+M synthesis pattern handles this.

Extension pattern
=================
Add a function and register it in `_MAPPINGS`. Detectors don't change.
"""

from __future__ import annotations

import json
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class MappedResource:
    """One TF-shape resource produced by mapping a CFN resource.

    A single CFN resource may yield multiple `MappedResource`s when its
    CFN structure folds multiple TF concerns together — e.g. an
    `AWS::S3::Bucket` with `PublicAccessBlockConfiguration` set yields
    both an `aws_s3_bucket` and a synthesized
    `aws_s3_bucket_public_access_block`.
    """

    body: dict[str, Any] = field(default_factory=dict)
    """TF-shape body. Keys + nested structure match what python-hcl2 would
    emit for an equivalent Terraform resource."""

    tf_type: str | None = None
    """The TF resource type. If None, the adapter uses the default
    `cfn_type_to_tf_type()` translation of the source CFN type. If a
    string, that's the synthetic TF type (e.g.
    `"aws_s3_bucket_public_access_block"` when synthesizing a sub-resource
    from a property block)."""

    name_suffix: str = ""
    """Appended to the source CFN `LogicalId` to form the TF resource
    name. Empty by default. Required for sub-resource synthesis so that
    the primary and synthesized resources have distinct names — e.g.
    `_pab` so that bucket `MyBucket` yields the synthesized PAB resource
    as `MyBucket_pab`."""


MappingFn = Callable[[dict[str, Any]], list[MappedResource]]


# --- AWS::S3::Bucket -------------------------------------------------------


def _map_s3_bucket(props: dict[str, Any]) -> list[MappedResource]:
    """Map `AWS::S3::Bucket` properties to `aws_s3_bucket` body.

    Emits a second `MappedResource` of type
    `aws_s3_bucket_public_access_block` (suffix `_pab`) when the source
    has a `PublicAccessBlockConfiguration` property — this matches the
    Terraform convention of separating PAB into its own resource.
    """
    body: dict[str, Any] = {}

    if "BucketName" in props:
        body["bucket"] = props["BucketName"]

    # CFN's BucketEncryption.ServerSideEncryptionConfiguration[*]
    # .ServerSideEncryptionByDefault.SSEAlgorithm maps to TF's
    # server_side_encryption_configuration[0].rule[*]
    # .apply_server_side_encryption_by_default[0].sse_algorithm.
    #
    # CFN omits TF's `rule` wrapper layer; we synthesize it. Each CFN
    # ServerSideEncryptionConfiguration entry becomes one TF `rule` entry.
    sse_in = props.get("BucketEncryption")
    if isinstance(sse_in, dict):
        sse_cfg = sse_in.get("ServerSideEncryptionConfiguration")
        if isinstance(sse_cfg, list) and sse_cfg:
            rules: list[dict[str, Any]] = []
            for entry in sse_cfg:
                if not isinstance(entry, dict):
                    continue
                ssebd = entry.get("ServerSideEncryptionByDefault")
                if isinstance(ssebd, dict):
                    algo = ssebd.get("SSEAlgorithm")
                    if isinstance(algo, str):
                        rule: dict[str, Any] = {
                            "apply_server_side_encryption_by_default": [{"sse_algorithm": algo}]
                        }
                        rules.append(rule)
            if rules:
                body["server_side_encryption_configuration"] = [{"rule": rules}]

    out: list[MappedResource] = [MappedResource(body=body)]

    pab_cfg = props.get("PublicAccessBlockConfiguration")
    if isinstance(pab_cfg, dict):
        pab_body: dict[str, Any] = {}
        pab_key_map = {
            "BlockPublicAcls": "block_public_acls",
            "IgnorePublicAcls": "ignore_public_acls",
            "BlockPublicPolicy": "block_public_policy",
            "RestrictPublicBuckets": "restrict_public_buckets",
        }
        for cfn_key, tf_key in pab_key_map.items():
            if cfn_key in pab_cfg:
                pab_body[tf_key] = pab_cfg[cfn_key]
        if pab_body:
            out.append(
                MappedResource(
                    body=pab_body,
                    tf_type="aws_s3_bucket_public_access_block",
                    name_suffix="_pab",
                )
            )

    return out


# --- AWS::S3::BucketPolicy -------------------------------------------------


def _map_s3_bucket_policy(props: dict[str, Any]) -> list[MappedResource]:
    """Map `AWS::S3::BucketPolicy` properties to `aws_s3_bucket_policy` body.

    CFN allows the policy as a YAML/JSON dict; Terraform stores it as a
    JSON-string. We stringify dicts; pass strings through.
    """
    body: dict[str, Any] = {}
    if "Bucket" in props:
        body["bucket"] = props["Bucket"]

    policy_doc = props.get("PolicyDocument")
    if isinstance(policy_doc, dict):
        body["policy"] = json.dumps(policy_doc, sort_keys=True, default=str)
    elif isinstance(policy_doc, str):
        body["policy"] = policy_doc

    # Explicit override: default cfn_type_to_tf_type() yields
    # `aws_s3_bucketpolicy` (multi-word `BucketPolicy` segment); TF
    # canonical is `aws_s3_bucket_policy`.
    return [MappedResource(body=body, tf_type="aws_s3_bucket_policy")]


# --- AWS::ElasticLoadBalancingV2::Listener --------------------------------


def _map_elbv2_listener(props: dict[str, Any]) -> list[MappedResource]:
    """Map `AWS::ElasticLoadBalancingV2::Listener` to `aws_lb_listener` body.

    First entry of CFN's `Certificates` list becomes TF's
    `certificate_arn` (TF supports additional certs via the separate
    `aws_lb_listener_certificate` resource — synthesizing those is a
    PR gamma.2 follow-on).
    """
    body: dict[str, Any] = {}

    simple_key_map = {
        "Protocol": "protocol",
        "Port": "port",
        "SslPolicy": "ssl_policy",
        "LoadBalancerArn": "load_balancer_arn",
    }
    for cfn_key, tf_key in simple_key_map.items():
        if cfn_key in props:
            body[tf_key] = props[cfn_key]

    certs = props.get("Certificates")
    if isinstance(certs, list) and certs:
        first = certs[0]
        if isinstance(first, dict) and "CertificateArn" in first:
            body["certificate_arn"] = first["CertificateArn"]

    # Explicit override: default cfn_type_to_tf_type() yields
    # `aws_elasticloadbalancingv2_listener`; TF canonical is
    # `aws_lb_listener` (TF aliases the v1 and v2 namespaces under
    # the `aws_lb_*` prefix).
    return [MappedResource(body=body, tf_type="aws_lb_listener")]


# --- AWS::EC2::FlowLog (PR gamma.2 batch 1) -------------------------------


# CFN's `ResourceType` discriminator names which target field TF wants:
# AWS::EC2::FlowLog has one `ResourceId` + one `ResourceType` (VPC/Subnet/
# NetworkInterface), but `aws_flow_log` uses three separate fields and
# expects exactly one to be set.
_FLOW_LOG_TARGET_FIELDS = {
    "VPC": "vpc_id",
    "Subnet": "subnet_id",
    "NetworkInterface": "eni_id",
}


def _map_ec2_flow_log(props: dict[str, Any]) -> list[MappedResource]:
    """Map `AWS::EC2::FlowLog` properties to `aws_flow_log` body.

    Dispatches CFN's (`ResourceType`, `ResourceId`) pair to the matching
    TF target field (`vpc_id` / `subnet_id` / `eni_id`). Other CFN keys
    rename per the `simple_key_map` table.
    """
    body: dict[str, Any] = {}

    resource_type = props.get("ResourceType")
    resource_id = props.get("ResourceId")
    if isinstance(resource_type, str) and resource_id is not None:
        target_field = _FLOW_LOG_TARGET_FIELDS.get(resource_type)
        if target_field is not None:
            body[target_field] = resource_id

    simple_key_map = {
        "TrafficType": "traffic_type",
        "LogDestinationType": "log_destination_type",
        "LogDestination": "log_destination",
        "LogGroupName": "log_group_name",
        "DeliverLogsPermissionArn": "iam_role_arn",
        "MaxAggregationInterval": "max_aggregation_interval",
    }
    for cfn_key, tf_key in simple_key_map.items():
        if cfn_key in props:
            body[tf_key] = props[cfn_key]

    return [MappedResource(body=body, tf_type="aws_flow_log")]


# --- AWS::EC2::SecurityGroup (PR gamma.2 batch 1) -------------------------


def _map_ec2_security_group(props: dict[str, Any]) -> list[MappedResource]:
    """Map `AWS::EC2::SecurityGroup` to `aws_security_group` body.

    Translates `SecurityGroupIngress`/`SecurityGroupEgress` lists into TF
    `ingress`/`egress` block lists with field-shape conversion: CFN's
    singular `CidrIp` (string) becomes TF's `cidr_blocks` (list-wrapped);
    `IpProtocol` becomes `protocol`; etc.

    The detector
    (`aws.security_group_open_ingress`) reads the inline `ingress` blocks;
    matching that shape is the value-add of this mapping.
    """
    body: dict[str, Any] = {}

    if "GroupName" in props:
        body["name"] = props["GroupName"]
    if "GroupDescription" in props:
        body["description"] = props["GroupDescription"]
    if "VpcId" in props:
        body["vpc_id"] = props["VpcId"]

    ingress = props.get("SecurityGroupIngress")
    if isinstance(ingress, list):
        body["ingress"] = [_translate_sg_rule(r) for r in ingress if isinstance(r, dict)]

    egress = props.get("SecurityGroupEgress")
    if isinstance(egress, list):
        body["egress"] = [_translate_sg_rule(r) for r in egress if isinstance(r, dict)]

    return [MappedResource(body=body, tf_type="aws_security_group")]


def _translate_sg_rule(rule: dict[str, Any]) -> dict[str, Any]:
    """Translate one CFN SG rule dict to TF inline block shape.

    Wraps CFN scalar `CidrIp`/`CidrIpv6`/`SourcePrefixListId` into TF
    list shape (TF detectors expect `cidr_blocks: [...]`).
    """
    out: dict[str, Any] = {}
    scalar_to_list_map = {
        "CidrIp": "cidr_blocks",
        "CidrIpv6": "ipv6_cidr_blocks",
        "SourcePrefixListId": "prefix_list_ids",
    }
    for cfn_key, tf_key in scalar_to_list_map.items():
        val = rule.get(cfn_key)
        if val is not None:
            out[tf_key] = [val] if isinstance(val, str) else val
    simple_map = {
        "FromPort": "from_port",
        "ToPort": "to_port",
        "IpProtocol": "protocol",
        "Description": "description",
        "SourceSecurityGroupId": "source_security_group_id",
    }
    for cfn_key, tf_key in simple_map.items():
        if cfn_key in rule:
            out[tf_key] = rule[cfn_key]
    return out


# --- AWS::EC2::Volume (PR gamma.2 batch 1) --------------------------------


def _map_ec2_volume(props: dict[str, Any]) -> list[MappedResource]:
    """Map `AWS::EC2::Volume` to `aws_ebs_volume` body.

    Read by `aws.encryption_ebs` for `encrypted` + `kms_key_id`.
    """
    body: dict[str, Any] = {}
    simple_map = {
        "Encrypted": "encrypted",
        "KmsKeyId": "kms_key_id",
        "Size": "size",
        "VolumeType": "type",
        "AvailabilityZone": "availability_zone",
        "Iops": "iops",
        "Throughput": "throughput",
    }
    for cfn_key, tf_key in simple_map.items():
        if cfn_key in props:
            body[tf_key] = props[cfn_key]
    return [MappedResource(body=body, tf_type="aws_ebs_volume")]


# --- AWS::Logs::LogGroup (PR gamma.2 batch 1) -----------------------------


def _map_logs_log_group(props: dict[str, Any]) -> list[MappedResource]:
    """Map `AWS::Logs::LogGroup` to `aws_cloudwatch_log_group` body.

    Read by `aws.centralized_log_aggregation` (inventory) and may be
    referenced by other log-aware detectors. Default
    `cfn_type_to_tf_type()` yields `aws_logs_loggroup`; explicit override
    to TF canonical `aws_cloudwatch_log_group`.
    """
    body: dict[str, Any] = {}
    simple_map = {
        "LogGroupName": "name",
        "RetentionInDays": "retention_in_days",
        "KmsKeyId": "kms_key_id",
    }
    for cfn_key, tf_key in simple_map.items():
        if cfn_key in props:
            body[tf_key] = props[cfn_key]
    return [MappedResource(body=body, tf_type="aws_cloudwatch_log_group")]


# --- AWS::IAM::Role (PR gamma.2 batch 2) ----------------------------------


def _map_iam_role(props: dict[str, Any]) -> list[MappedResource]:
    """Map `AWS::IAM::Role` to `aws_iam_role` + synthesized attachment/policy resources.

    CFN bundles managed-policy attachments and inline policies into the
    Role's own properties; TF separates them into `aws_iam_role_policy_attachment`
    (per ARN) and `aws_iam_role_policy` (per inline policy) resources.
    The detectors `aws.iam_admin_policy_usage` and
    `aws.iam_inline_policies_audit` read those separate resources, so the
    mapping must synthesize them.

    name_suffix scheme:
      - `_attach_<idx>` for each ManagedPolicyArn
      - `_inline_<PolicyName>` for each inline Policies entry
    """
    role_body: dict[str, Any] = {}

    simple_map = {
        "RoleName": "name",
        "Path": "path",
        "Description": "description",
        "MaxSessionDuration": "max_session_duration",
        "PermissionsBoundary": "permissions_boundary",
    }
    for cfn_key, tf_key in simple_map.items():
        if cfn_key in props:
            role_body[tf_key] = props[cfn_key]

    # AssumeRolePolicyDocument is the trust policy. CFN allows dict; TF
    # stores as JSON-string in `assume_role_policy`.
    arpd = props.get("AssumeRolePolicyDocument")
    if isinstance(arpd, dict):
        role_body["assume_role_policy"] = json.dumps(arpd, sort_keys=True, default=str)
    elif isinstance(arpd, str):
        role_body["assume_role_policy"] = arpd

    out: list[MappedResource] = [MappedResource(body=role_body, tf_type="aws_iam_role")]

    # Synthesize one aws_iam_role_policy_attachment per ManagedPolicyArn.
    managed_arns = props.get("ManagedPolicyArns")
    if isinstance(managed_arns, list):
        for idx, arn in enumerate(managed_arns):
            if not isinstance(arn, str):
                continue
            out.append(
                MappedResource(
                    body={"policy_arn": arn},
                    tf_type="aws_iam_role_policy_attachment",
                    name_suffix=f"_attach_{idx}",
                )
            )

    # Synthesize one aws_iam_role_policy per inline Policies entry.
    inline_policies = props.get("Policies")
    if isinstance(inline_policies, list):
        for entry in inline_policies:
            if not isinstance(entry, dict):
                continue
            policy_name = entry.get("PolicyName")
            policy_doc = entry.get("PolicyDocument")
            policy_str: str | None = None
            if isinstance(policy_doc, dict):
                policy_str = json.dumps(policy_doc, sort_keys=True, default=str)
            elif isinstance(policy_doc, str):
                policy_str = policy_doc
            if not isinstance(policy_name, str) or policy_str is None:
                continue
            out.append(
                MappedResource(
                    body={"name": policy_name, "policy": policy_str},
                    tf_type="aws_iam_role_policy",
                    name_suffix=f"_inline_{policy_name}",
                )
            )

    return out


# --- AWS::IAM::ManagedPolicy (PR gamma.2 batch 2) ------------------------


def _map_iam_managed_policy(props: dict[str, Any]) -> list[MappedResource]:
    """Map `AWS::IAM::ManagedPolicy` to `aws_iam_policy` body.

    Default cfn_type_to_tf_type() yields `aws_iam_managedpolicy`; TF
    canonical is `aws_iam_policy`. Explicit override.
    """
    body: dict[str, Any] = {}
    simple_map = {
        "ManagedPolicyName": "name",
        "Path": "path",
        "Description": "description",
    }
    for cfn_key, tf_key in simple_map.items():
        if cfn_key in props:
            body[tf_key] = props[cfn_key]

    policy_doc = props.get("PolicyDocument")
    if isinstance(policy_doc, dict):
        body["policy"] = json.dumps(policy_doc, sort_keys=True, default=str)
    elif isinstance(policy_doc, str):
        body["policy"] = policy_doc

    return [MappedResource(body=body, tf_type="aws_iam_policy")]


# --- AWS::IAM::User (PR gamma.2 batch 2) ---------------------------------


def _map_iam_user(props: dict[str, Any]) -> list[MappedResource]:
    """Map `AWS::IAM::User` to `aws_iam_user` + synthesized policy attachments.

    Same 1→(1+N+M) pattern as IAM::Role: User-side managed-policy
    attachments and inline policies become separate TF resources.
    """
    user_body: dict[str, Any] = {}
    simple_map = {
        "UserName": "name",
        "Path": "path",
        "PermissionsBoundary": "permissions_boundary",
    }
    for cfn_key, tf_key in simple_map.items():
        if cfn_key in props:
            user_body[tf_key] = props[cfn_key]

    out: list[MappedResource] = [MappedResource(body=user_body, tf_type="aws_iam_user")]

    managed_arns = props.get("ManagedPolicyArns")
    if isinstance(managed_arns, list):
        for idx, arn in enumerate(managed_arns):
            if not isinstance(arn, str):
                continue
            out.append(
                MappedResource(
                    body={"policy_arn": arn},
                    tf_type="aws_iam_user_policy_attachment",
                    name_suffix=f"_attach_{idx}",
                )
            )

    inline_policies = props.get("Policies")
    if isinstance(inline_policies, list):
        for entry in inline_policies:
            if not isinstance(entry, dict):
                continue
            policy_name = entry.get("PolicyName")
            policy_doc = entry.get("PolicyDocument")
            policy_str: str | None = None
            if isinstance(policy_doc, dict):
                policy_str = json.dumps(policy_doc, sort_keys=True, default=str)
            elif isinstance(policy_doc, str):
                policy_str = policy_doc
            if not isinstance(policy_name, str) or policy_str is None:
                continue
            out.append(
                MappedResource(
                    body={"name": policy_name, "policy": policy_str},
                    tf_type="aws_iam_user_policy",
                    name_suffix=f"_inline_{policy_name}",
                )
            )

    return out


# --- AWS::KMS::Key (PR gamma.2 batch 3) -----------------------------------


def _map_kms_key(props: dict[str, Any]) -> list[MappedResource]:
    """Map `AWS::KMS::Key` to `aws_kms_key` body.

    Read by `aws.kms_key_rotation` (`enable_key_rotation`) and
    `aws.kms_customer_managed_keys` (`customer_master_key_spec`).

    Naming nuance: TF's primary attribute is `customer_master_key_spec`
    (the legacy AWS name). CFN's modern name is `KeySpec`. We translate
    `KeySpec` → `customer_master_key_spec` so existing TF detectors work
    without modification.
    """
    body: dict[str, Any] = {}
    simple_map = {
        "EnableKeyRotation": "enable_key_rotation",
        "KeySpec": "customer_master_key_spec",
        "KeyUsage": "key_usage",
        "Description": "description",
        "MultiRegion": "multi_region",
        "PendingWindowInDays": "deletion_window_in_days",
        "Enabled": "is_enabled",
    }
    for cfn_key, tf_key in simple_map.items():
        if cfn_key in props:
            body[tf_key] = props[cfn_key]

    key_policy = props.get("KeyPolicy")
    if isinstance(key_policy, dict):
        body["policy"] = json.dumps(key_policy, sort_keys=True, default=str)
    elif isinstance(key_policy, str):
        body["policy"] = key_policy

    return [MappedResource(body=body, tf_type="aws_kms_key")]


# --- AWS::RDS::DBInstance (PR gamma.2 batch 3) -----------------------------


def _map_rds_db_instance(props: dict[str, Any]) -> list[MappedResource]:
    """Map `AWS::RDS::DBInstance` to `aws_db_instance` body.

    Read by `aws.rds_encryption_at_rest` (`storage_encrypted`,
    `kms_key_id`) and `aws.rds_public_accessibility` (`publicly_accessible`).
    """
    body: dict[str, Any] = {}
    simple_map = {
        "DBInstanceIdentifier": "identifier",
        "DBInstanceClass": "instance_class",
        "Engine": "engine",
        "EngineVersion": "engine_version",
        "AllocatedStorage": "allocated_storage",
        "StorageEncrypted": "storage_encrypted",
        "KmsKeyId": "kms_key_id",
        "PubliclyAccessible": "publicly_accessible",
        "MultiAZ": "multi_az",
        "BackupRetentionPeriod": "backup_retention_period",
        "DeletionProtection": "deletion_protection",
        "MasterUsername": "username",
        "DBName": "db_name",
        "Port": "port",
        "VPCSecurityGroups": "vpc_security_group_ids",
        "DBSubnetGroupName": "db_subnet_group_name",
    }
    for cfn_key, tf_key in simple_map.items():
        if cfn_key in props:
            body[tf_key] = props[cfn_key]

    return [MappedResource(body=body, tf_type="aws_db_instance")]


# --- AWS::Lambda::Function (PR gamma.2 batch 3) ----------------------------


def _map_lambda_function(props: dict[str, Any]) -> list[MappedResource]:
    """Map `AWS::Lambda::Function` to `aws_lambda_function` body.

    Read by `aws.lambda_env_kms_encryption` (needs `environment` block +
    `kms_key_arn`), `aws.lambda_vpc_isolation` (needs `vpc_config`), and
    `aws.lambda_logging_configured` (inventory).

    Nested-block translation: CFN's flat `Environment.Variables` and
    `VpcConfig.{SubnetIds,SecurityGroupIds}` become TF's list-wrapped
    nested-block shape (matching python-hcl2's `[{...}]` convention),
    so the detectors' `_normalize_block` helpers (which accept both
    dict and `[dict]`) work uniformly.
    """
    body: dict[str, Any] = {}
    simple_map = {
        "FunctionName": "function_name",
        "Runtime": "runtime",
        "Handler": "handler",
        "Role": "role",
        "Timeout": "timeout",
        "MemorySize": "memory_size",
        "KmsKeyArn": "kms_key_arn",
        "Description": "description",
    }
    for cfn_key, tf_key in simple_map.items():
        if cfn_key in props:
            body[tf_key] = props[cfn_key]

    # Environment.Variables (dict) → environment[0].variables (TF
    # list-of-dict-of-dict shape; detector reads variables dict).
    env = props.get("Environment")
    if isinstance(env, dict):
        variables = env.get("Variables")
        if isinstance(variables, dict):
            body["environment"] = [{"variables": variables}]

    # VpcConfig.{SubnetIds, SecurityGroupIds} → vpc_config[0].{subnet_ids, security_group_ids}
    vpc_cfg = props.get("VpcConfig")
    if isinstance(vpc_cfg, dict):
        vpc_block: dict[str, Any] = {}
        if "SubnetIds" in vpc_cfg:
            vpc_block["subnet_ids"] = vpc_cfg["SubnetIds"]
        if "SecurityGroupIds" in vpc_cfg:
            vpc_block["security_group_ids"] = vpc_cfg["SecurityGroupIds"]
        if vpc_block:
            body["vpc_config"] = [vpc_block]

    return [MappedResource(body=body, tf_type="aws_lambda_function")]


_MAPPINGS: dict[str, MappingFn] = {
    "AWS::EC2::FlowLog": _map_ec2_flow_log,
    "AWS::EC2::SecurityGroup": _map_ec2_security_group,
    "AWS::EC2::Volume": _map_ec2_volume,
    "AWS::ElasticLoadBalancingV2::Listener": _map_elbv2_listener,
    "AWS::IAM::ManagedPolicy": _map_iam_managed_policy,
    "AWS::IAM::Role": _map_iam_role,
    "AWS::IAM::User": _map_iam_user,
    "AWS::KMS::Key": _map_kms_key,
    "AWS::Lambda::Function": _map_lambda_function,
    "AWS::Logs::LogGroup": _map_logs_log_group,
    "AWS::RDS::DBInstance": _map_rds_db_instance,
    "AWS::S3::Bucket": _map_s3_bucket,
    "AWS::S3::BucketPolicy": _map_s3_bucket_policy,
}


def has_mapping(cfn_type: str) -> bool:
    """True iff a property mapping is registered for `cfn_type`."""
    return cfn_type in _MAPPINGS


def apply_mapping(cfn_type: str, props: dict[str, Any]) -> list[MappedResource]:
    """Apply the registered mapping for `cfn_type`. KeyError if unmapped."""
    try:
        fn = _MAPPINGS[cfn_type]
    except KeyError as e:
        raise KeyError(f"no property mapping registered for CFN type {cfn_type!r}") from e
    return fn(props)


def mapped_cfn_types() -> tuple[str, ...]:
    """All CFN types with a registered mapping (sorted, deterministic)."""
    return tuple(sorted(_MAPPINGS))
