"""Contradiction detection engine.

Ported from Gnosia's engine/contradiction.py, generalized for any markdown
vault. Strips KN-* prefix and `## Key Concepts` section assumption; uses the
full document's bold text (label-filtered) and full-text negation extraction.

Two detection modes:
  * Numerical: same concept appears in both notes with different numbers
    sharing the same unit, differing by >2x.
  * Negation: note A negates a specific phrase that B asserts affirmatively.

Precision > Recall: the detector is tuned to minimize false positives at the
cost of missing some real conflicts. In practice this is the right tradeoff —
users quickly lose trust in a detector that cries wolf.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path


_FRONTMATTER_RE = re.compile(r'^---\s*\n(.*?)\n---', re.DOTALL)
_TITLE_RE = re.compile(r'^title:\s*"?(.+?)"?\s*$', re.MULTILINE)
_BOLD_RE = re.compile(r'\*\*(.+?)\*\*')

# Numbers (e.g., "42", "1,000", "3.14") followed by a unit
_NUMBER_RE = re.compile(
    r'(\d+[\d,.]*)\s*(percent|%|ms|seconds|minutes|hours|days|weeks|months|years|'
    r'neurons|synapses|bytes|kb|mb|gb|tb|items|slots|bits|dollars|usd|eur|kg|lb|'
    r'miles|km|meters|m|celsius|fahrenheit|degrees)',
    re.IGNORECASE,
)

_NEGATION_WORDS = r"(?:not|never|cannot|doesn't|don't|isn't|aren't|wasn't|weren't|no)"
_NEGATION_SENTENCE_RE = re.compile(
    rf"[^.]*\b{_NEGATION_WORDS}\b[^.]*\.",
    re.IGNORECASE,
)
_NEGATION_PHRASE_RE = re.compile(
    rf"\b{_NEGATION_WORDS}\b\s+(\w+(?:\s+\w+){{1,3}})",
    re.IGNORECASE,
)


@dataclass
class Claim:
    kind: str   # "number" | "negation"
    text: str   # the raw claim
    concept: str | None = None    # for negations near a concept
    number: str | None = None     # for numerical
    unit: str | None = None


@dataclass
class Note:
    note_id: str
    path: Path
    title: str
    concepts: set[str] = field(default_factory=set)
    numbers: list[tuple[str, str]] = field(default_factory=list)
    negations: list[str] = field(default_factory=list)
    content_lower: str = ""


@dataclass
class Conflict:
    note_a: str
    note_b: str
    title_a: str
    title_b: str
    shared_concepts: list[str]
    issues: list[dict]

    def to_dict(self) -> dict:
        return {
            "note_a": self.note_a,
            "note_b": self.note_b,
            "title_a": self.title_a,
            "title_b": self.title_b,
            "shared_concepts": self.shared_concepts,
            "issues": self.issues,
        }


def _extract_concepts(content: str) -> set[str]:
    """Extract candidate concepts: label-filtered bold text.

    Same filter rule as the other Gnosia-derived MCPs: if the bold text
    contains or ends with a colon, it's a metadata label (`**Hub:**`),
    not a research concept.
    """
    concepts: set[str] = set()
    for raw in _BOLD_RE.findall(content):
        raw = raw.strip()
        if not raw or raw[-1] in ":;,.!?" or ":" in raw:
            continue
        concepts.add(raw.lower())
    return concepts


_MARKDOWN_EMPHASIS_RE = re.compile(r'[*_]+')


def _strip_emphasis(text: str) -> str:
    """Strip `*`, `_` (markdown emphasis) so patterns like `**7**` are scannable."""
    return _MARKDOWN_EMPHASIS_RE.sub(' ', text)


def load_note(path: Path) -> Note:
    """Load a single note and extract concepts, numbers, negations."""
    path = Path(path).expanduser().resolve()
    content = path.read_text(encoding="utf-8", errors="ignore")

    title_match = _TITLE_RE.search(content)
    title = title_match.group(1).strip() if title_match else path.stem

    # Concepts come from ORIGINAL content (needs ** markers to find bold).
    concepts = _extract_concepts(content)

    # Numbers + negations scan the emphasis-stripped, lowercased body so the
    # number regex can reach values wrapped in `**...**`.
    plain = _strip_emphasis(content.lower())
    numbers = [(num.strip(), unit.lower().strip())
               for num, unit in _NUMBER_RE.findall(plain)]
    negations = [s.strip() for s in _NEGATION_SENTENCE_RE.findall(plain)][:20]

    return Note(
        note_id=path.stem,
        path=path,
        title=title,
        concepts=concepts,
        numbers=numbers,
        negations=negations,
        content_lower=plain,  # downstream context checks also benefit
    )


def load_vault_notes(vault_path: Path | str) -> list[Note]:
    """Load all .md notes under vault_path."""
    vault = Path(vault_path).expanduser().resolve()
    return [load_note(f) for f in vault.rglob("*.md")]


def _get_context(text: str, concept: str, number: str, window: int = 100) -> bool:
    """True if the number appears within `window` chars of the concept in text."""
    concept_pos = text.find(concept)
    number_pos = text.find(number)
    if concept_pos < 0 or number_pos < 0:
        return False
    return abs(concept_pos - number_pos) < window


def _find_numerical_conflicts(
    a: Note, b: Note, shared: set[str]
) -> list[dict]:
    """Same concept, same unit, values differ >2x → numerical conflict."""
    issues: list[dict] = []
    for concept in shared:
        for num_a, unit_a in a.numbers:
            if not _get_context(a.content_lower, concept, num_a):
                continue
            for num_b, unit_b in b.numbers:
                if unit_a != unit_b:
                    continue
                if not _get_context(b.content_lower, concept, num_b):
                    continue
                try:
                    val_a = float(num_a.replace(",", ""))
                    val_b = float(num_b.replace(",", ""))
                except ValueError:
                    continue
                if val_a == val_b or min(val_a, val_b) <= 0:
                    continue
                ratio = max(val_a, val_b) / min(val_a, val_b)
                if ratio >= 1.5:
                    issues.append({
                        "type": "numerical",
                        "concept": concept,
                        "value_a": f"{num_a} {unit_a}",
                        "value_b": f"{num_b} {unit_b}",
                        "ratio": round(ratio, 2),
                    })
    return issues


def _find_negation_conflicts(
    a: Note, b: Note, shared: set[str]
) -> list[dict]:
    """A says 'not X Y', B says 'X Y' affirmatively → negation conflict.

    Precision-tightened: only the specific phrase after a negation counts,
    and the occurrence in B must not itself be preceded by a negation word
    within 40 chars.
    """
    issues: list[dict] = []
    for neg_sentence in a.negations:
        for concept in shared:
            if concept not in neg_sentence:
                continue
            phrase_match = _NEGATION_PHRASE_RE.search(neg_sentence)
            if not phrase_match:
                continue
            phrase = phrase_match.group(1).strip()
            if len(phrase) < 6:
                continue
            for m in re.finditer(re.escape(phrase), b.content_lower):
                before = b.content_lower[max(0, m.start() - 40):m.start()]
                if re.search(rf"\b{_NEGATION_WORDS}\b", before, re.IGNORECASE):
                    continue
                issues.append({
                    "type": "negation",
                    "concept": concept,
                    "claim_a": neg_sentence.strip()[:120],
                    "phrase": phrase,
                })
                break
    return issues


def find_pair_conflicts(a: Note, b: Note, min_shared: int = 3) -> Conflict | None:
    """Return a Conflict if the pair has shared concepts AND detected issues."""
    shared = a.concepts & b.concepts
    if len(shared) < min_shared:
        return None

    issues: list[dict] = []
    issues.extend(_find_numerical_conflicts(a, b, shared))
    issues.extend(_find_negation_conflicts(a, b, shared))

    if not issues:
        return None

    return Conflict(
        note_a=a.note_id,
        note_b=b.note_id,
        title_a=a.title,
        title_b=b.title,
        shared_concepts=sorted(list(shared))[:10],
        issues=issues,
    )


def find_all_conflicts(
    notes: list[Note],
    min_shared_concepts: int = 3,
    limit: int = 50,
) -> list[Conflict]:
    """Pairwise contradiction scan across the vault."""
    conflicts: list[Conflict] = []
    for i in range(len(notes)):
        for j in range(i + 1, len(notes)):
            c = find_pair_conflicts(notes[i], notes[j], min_shared=min_shared_concepts)
            if c:
                conflicts.append(c)
                if len(conflicts) >= limit:
                    return conflicts
    return conflicts


def extract_note_claims(note: Note) -> dict:
    """Structured claim extraction for a single note."""
    return {
        "note_id": note.note_id,
        "title": note.title,
        "path": str(note.path),
        "concept_count": len(note.concepts),
        "concepts": sorted(note.concepts)[:20],
        "quantitative_claims": [
            {"number": num, "unit": unit}
            for num, unit in note.numbers
        ],
        "negation_claims": [
            {"sentence": sentence, "phrase": _phrase_from_negation(sentence)}
            for sentence in note.negations
        ],
    }


def _phrase_from_negation(sentence: str) -> str:
    m = _NEGATION_PHRASE_RE.search(sentence)
    return m.group(1).strip() if m else ""


def build_reconciliation_prompt(a: Note, b: Note, conflict: Conflict) -> str:
    """Produce an LLM-ready reconciliation prompt from a detected conflict.

    The prompt includes both notes' titles, the shared concepts, each
    specific issue, and short context snippets around each disputed claim.
    Designed to be fed to Claude / GPT / any capable model to reason through
    the conflict and propose a resolution note or a dismissal.
    """
    lines: list[str] = []
    lines.append("# Knowledge Base Reconciliation Request")
    lines.append("")
    lines.append(f"Two notes in a knowledge base appear to contradict each other.")
    lines.append(f"Your job: analyze the disagreement and propose a resolution.")
    lines.append("")
    lines.append(f"## Note A — \"{a.title}\" ({a.note_id})")
    lines.append("")
    lines.append(f"## Note B — \"{b.title}\" ({b.note_id})")
    lines.append("")
    lines.append("## Shared concepts")
    lines.append("")
    for c in conflict.shared_concepts:
        lines.append(f"- {c}")
    lines.append("")
    lines.append("## Detected conflicts")
    lines.append("")
    for i, issue in enumerate(conflict.issues, 1):
        lines.append(f"### Conflict {i} — {issue['type']}")
        if issue["type"] == "numerical":
            lines.append(f"Concept: **{issue['concept']}**")
            lines.append(f"Note A says: {issue['value_a']}")
            lines.append(f"Note B says: {issue['value_b']}")
            lines.append(f"Ratio: {issue.get('ratio', '?')}")
        elif issue["type"] == "negation":
            lines.append(f"Concept: **{issue['concept']}**")
            lines.append(f"Note A negates: \"{issue['claim_a']}\"")
            lines.append(f"Note B affirms phrase: \"{issue['phrase']}\"")
        lines.append("")
    lines.append("## Task")
    lines.append("")
    lines.append("1. Decide whether this is a genuine contradiction or a false positive")
    lines.append("   (context could make both claims compatible).")
    lines.append("2. If genuine: suggest which claim is more likely correct, and why.")
    lines.append("3. If false positive: explain why the detector was fooled.")
    lines.append("4. Output either a short reconciliation note (1-3 paragraphs) or")
    lines.append("   a dismissal with reasoning.")
    lines.append("")
    lines.append("---")
    lines.append("## Note A full context")
    lines.append("")
    lines.append(f"```markdown")
    lines.append(a.path.read_text(encoding='utf-8', errors='ignore')[:3000])
    lines.append(f"```")
    lines.append("")
    lines.append("## Note B full context")
    lines.append("")
    lines.append(f"```markdown")
    lines.append(b.path.read_text(encoding='utf-8', errors='ignore')[:3000])
    lines.append(f"```")
    return "\n".join(lines)
