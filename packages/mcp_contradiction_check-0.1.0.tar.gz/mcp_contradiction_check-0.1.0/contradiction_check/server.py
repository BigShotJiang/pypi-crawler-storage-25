"""mcp-contradiction-check MCP Server.

Find where your notes disagree — contradiction detection for markdown vaults.
"""
import json
from pathlib import Path

from mcp.server.fastmcp import FastMCP
from starlette.requests import Request
from starlette.responses import JSONResponse

from .detector import (
    build_reconciliation_prompt,
    extract_note_claims,
    find_all_conflicts,
    find_pair_conflicts,
    load_note,
    load_vault_notes,
)
from .license import License, require_feature_error

_license: License | None = None


def set_license(license: License | None) -> None:
    global _license
    _license = license


mcp_server = FastMCP(
    "mcp-contradiction-check",
    instructions="Find where your notes disagree — contradiction detection for markdown vaults.",
)


@mcp_server.custom_route("/health", methods=["GET"])
async def health_check(request: Request) -> JSONResponse:
    return JSONResponse({"status": "healthy"})


def _validate_path(path_str: str, must_be_dir: bool = False) -> dict | None:
    p = Path(path_str).expanduser()
    if not p.exists():
        return {"error": f"path does not exist: {path_str}", "status": "bad_request"}
    if must_be_dir and not p.is_dir():
        return {"error": f"path is not a directory: {path_str}", "status": "bad_request"}
    if not must_be_dir and p.is_dir():
        return {"error": f"expected a file, got a directory: {path_str}", "status": "bad_request"}
    return None


def _resolve_note_path(spec: str, vault_hint: str | None = None) -> Path | None:
    """Accept either an absolute path or a note stem. If a stem is given and
    vault_hint is provided, search for the stem in the vault."""
    p = Path(spec).expanduser()
    if p.is_absolute() and p.exists():
        return p.resolve()
    if p.exists():
        return p.resolve()
    if vault_hint:
        vault = Path(vault_hint).expanduser().resolve()
        if vault.is_dir():
            matches = list(vault.rglob(f"{spec}.md"))
            if matches:
                return matches[0]
    return None


@mcp_server.tool(name="find_contradictions", annotations={"readOnlyHint": True})
def tool_find_contradictions(
    vault_path: str, min_shared_concepts: int = 3, limit: int = 20
) -> str:
    """Scan the vault for note pairs with high concept overlap but conflicting
    numerical or qualitative claims."""
    err = _validate_path(vault_path, must_be_dir=True)
    if err:
        return json.dumps(err, indent=2)

    notes = load_vault_notes(vault_path)
    conflicts = find_all_conflicts(notes, min_shared_concepts=min_shared_concepts, limit=limit)
    return json.dumps({
        "vault_path": str(Path(vault_path).expanduser().resolve()),
        "total_notes": len(notes),
        "min_shared_concepts": min_shared_concepts,
        "total_conflicts": len(conflicts),
        "conflicts": [c.to_dict() for c in conflicts],
    }, indent=2)


@mcp_server.tool(name="check_pair", annotations={"readOnlyHint": True})
def tool_check_pair(note_a_path: str, note_b_path: str) -> str:
    """Run the full contradiction check between two specific notes. Accepts
    absolute paths or filename stems (within a vault that can be inferred)."""
    pa = _resolve_note_path(note_a_path)
    pb = _resolve_note_path(note_b_path)
    if pa is None:
        return json.dumps({"error": f"note_a_path not found: {note_a_path}",
                           "status": "bad_request"}, indent=2)
    if pb is None:
        return json.dumps({"error": f"note_b_path not found: {note_b_path}",
                           "status": "bad_request"}, indent=2)

    a = load_note(pa)
    b = load_note(pb)
    conflict = find_pair_conflicts(a, b, min_shared=1)
    return json.dumps({
        "note_a": {"id": a.note_id, "title": a.title, "path": str(a.path)},
        "note_b": {"id": b.note_id, "title": b.title, "path": str(b.path)},
        "shared_concepts": sorted(list(a.concepts & b.concepts))[:20],
        "shared_count": len(a.concepts & b.concepts),
        "conflict": conflict.to_dict() if conflict else None,
        "verdict": "CONFLICT" if conflict else "OK",
    }, indent=2)


@mcp_server.tool(name="extract_claims", annotations={"readOnlyHint": True})
def tool_extract_claims(note_path: str) -> str:
    """[Pro] Pull all quantitative claims (numbers with units) and negation
    patterns from a single note — structured output for your verification pipeline."""
    if _license is None or not _license.has_feature("claim_extraction"):
        return json.dumps(require_feature_error("claim_extraction"), indent=2)

    p = _resolve_note_path(note_path)
    if p is None:
        return json.dumps({"error": f"note_path not found: {note_path}",
                           "status": "bad_request"}, indent=2)

    note = load_note(p)
    return json.dumps(extract_note_claims(note), indent=2)


@mcp_server.tool(name="generate_reconciliation_prompt", annotations={"readOnlyHint": True})
def tool_generate_reconciliation_prompt(note_a_path: str, note_b_path: str) -> str:
    """[Pro] For a detected contradiction between two notes, produce a structured
    LLM-ready prompt for reasoning through the conflict and suggesting resolution."""
    if _license is None or not _license.has_feature("reconciliation_prompts"):
        return json.dumps(require_feature_error("reconciliation_prompts"), indent=2)

    pa = _resolve_note_path(note_a_path)
    pb = _resolve_note_path(note_b_path)
    if pa is None or pb is None:
        return json.dumps({"error": "one or both paths not found", "status": "bad_request"}, indent=2)

    a = load_note(pa)
    b = load_note(pb)
    conflict = find_pair_conflicts(a, b, min_shared=1)

    if conflict is None:
        return json.dumps({
            "verdict": "OK",
            "message": "No contradiction detected between these notes. No prompt needed.",
        }, indent=2)

    prompt = build_reconciliation_prompt(a, b, conflict)
    return json.dumps({
        "note_a": a.note_id,
        "note_b": b.note_id,
        "conflict_summary": conflict.to_dict(),
        "llm_prompt": prompt,
    }, indent=2)
