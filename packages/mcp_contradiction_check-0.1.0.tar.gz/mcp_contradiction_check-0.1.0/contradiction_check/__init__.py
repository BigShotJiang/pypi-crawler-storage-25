"""Find pairs of notes in your markdown knowledge base that have high
concept overlap but disagree — quantitative conflicts (different
numbers with the same unit on the same concept) and negation
conflicts (one note claims "X is not Y", another claims "X is Y").
Prevents knowledge corruption by surfacing disputes before they
propagate. Designed to pair with hebbian-vault's usage-weighted
retrieval to flag notes that shouldn't be strengthened yet.
"""
__version__ = "0.1.0"
