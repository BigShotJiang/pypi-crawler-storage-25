"""CLI entry point for mcp-contradiction-check MCP server.

Dual-mode: stdio (default, for Claude Desktop / uvx / local MCP clients),
streamable-http (for MCPize-hosted Cloud Run, via explicit flag).
"""
import argparse
import os
import sys


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="mcp-contradiction-check",
        description="Find where your notes disagree — contradiction detection for markdown vaults.",
    )
    parser.add_argument(
        "--license-key",
        default=None,
        help="Pro license JWT. Overrides CONTRADICTION_CHECK_LICENSE env var and ~/.mcp-contradiction-check/license.jwt",
    )
    parser.add_argument(
        "--transport",
        choices=["stdio", "streamable-http", "sse"],
        default="stdio",
        help="MCP transport (default: stdio for local Claude Desktop / uvx).",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=8000,
        help="Port for streamable-http transport (default: 8000, ignored for stdio).",
    )
    args = parser.parse_args()

    from .license import load_license
    license = load_license(args.license_key)

    from .server import mcp_server, set_license
    set_license(license)

    if args.transport in ("streamable-http", "sse"):
        port = int(os.environ.get("PORT") or args.port)
        mcp_server.settings.host = "0.0.0.0"
        mcp_server.settings.port = port
        mcp_server.settings.stateless_http = True
        print(f"mcp-contradiction-check: binding {args.transport} on 0.0.0.0:{port} (stateless)",
              file=sys.stderr)

    if license:
        print(f"mcp-contradiction-check: Pro license active (plan={license.plan}, sub={license.subject})",
              file=sys.stderr)

    mcp_server.run(transport=args.transport)


if __name__ == "__main__":
    main()
