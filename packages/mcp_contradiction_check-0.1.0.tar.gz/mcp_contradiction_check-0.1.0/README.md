<!-- mcp-name: io.github.onetrueclaude-creator/mcp-contradiction-check -->

# mcp-contradiction-check

**Find where your notes disagree — contradiction detection for markdown vaults.**

Find pairs of notes in your markdown knowledge base that have high
concept overlap but disagree — quantitative conflicts (different
numbers with the same unit on the same concept) and negation
conflicts (one note claims "X is not Y", another claims "X is Y").
Prevents knowledge corruption by surfacing disputes before they
propagate. Designed to pair with hebbian-vault's usage-weighted
retrieval to flag notes that shouldn't be strengthened yet.


## Install

```bash
pip install mcp-contradiction-check
# or
uvx mcp-contradiction-check
```

## Usage

### Claude Code

```bash
claude mcp add mcp-contradiction-check -- mcp-contradiction-check
```

### Claude Desktop

Add to `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "contradiction_check": {
      "command": "uvx",
      "args": ["mcp-contradiction-check"]
    }
  }
}
```

## MCP Tools

| Tool | Tier | Description |
|------|------|-------------|
| `find_contradictions` | Free | Scan the vault for note pairs with high concept overlap but conflicting numerical or qualitative claims. Returns all detected conflicts with the specific issues flagged. |
| `check_pair` | Free | Run the full contradiction check between two specific notes (by path or filename stem). Returns the detailed conflict analysis — shared concepts, quantitative conflicts, negation conflicts. |
| `extract_claims` | **Pro** | Pull all quantitative claims (numbers with units) and negation patterns from a single note. Useful as input to your own verification pipeline. |
| `generate_reconciliation_prompt` | **Pro** | For a detected contradiction, produce a structured prompt you can feed to an LLM to reason through the conflict and suggest a resolution. Preserves the exact claims + shared concepts + both notes' context windows. |


## Pro tier

Unlocks detailed claim extraction per note and LLM-ready reconciliation prompt generation for resolving disputes.

License activation — any one of these works:

```bash
# 1. Environment variable
export CONTRADICTION_CHECK_LICENSE="eyJhbGc..."

# 2. CLI flag
mcp-contradiction-check --license-key "eyJhbGc..."

# 3. Config file
echo "eyJhbGc..." > ~/.mcp-contradiction-check/license.jwt
```

Licenses are verified fully offline — no phone-home, no activation server. Get a license at **https://github.com/onetrueclaude-creator/mcp-contradiction-check#pro-tier**.

## Requirements

- Python 3.10+

## License

MIT
