from __future__ import annotations

import base64
import zipfile
from pathlib import Path

import pytest

from jakal_hwpx import (
    BinaryDataPart,
    ContentHpfPart,
    HeaderPart,
    HwpxDocument,
    HwpxValidationError,
    OleXml,
    PreviewTextPart,
    SectionPart,
    ValidationIssue,
)


HEAD_NS = {"hh": "http://www.hancom.co.kr/hwpml/2011/head", "hc": "http://www.hancom.co.kr/hwpml/2011/core"}
PARA_NS = {
    "hp": "http://www.hancom.co.kr/hwpml/2011/paragraph",
    "hc": "http://www.hancom.co.kr/hwpml/2011/core",
}
REPO_ROOT = Path(__file__).resolve().parents[1]
OLE_SAMPLE_PATH = REPO_ROOT / "ole_test.hwpx"
UNICODE_STRESS_TEXT = "안성민은 자칼이다つㄹשׁשׁㄹㅇㄹㅇ 😱🎅🏦🌩⏩💵🔥"


def test_open_exposes_expected_parts(sample_hwpx_path: Path) -> None:
    document = HwpxDocument.open(sample_hwpx_path)

    assert isinstance(document.content_hpf, ContentHpfPart)
    assert isinstance(document.header, HeaderPart)
    assert document.sections
    assert all(isinstance(section, SectionPart) for section in document.sections)
    assert document.mimetype.mime == "application/hwp+zip"
    assert document.validation_errors() == []


def test_default_constructor_builds_blank_document_in_memory() -> None:
    document = HwpxDocument()
    expected_part_paths = [
        "mimetype",
        "version.xml",
        "Contents/content.hpf",
        "Contents/header.xml",
        "Contents/section0.xml",
        "settings.xml",
        "META-INF/container.xml",
    ]

    assert isinstance(document.content_hpf, ContentHpfPart)
    assert isinstance(document.header, HeaderPart)
    assert document.sections
    assert all(isinstance(section, SectionPart) for section in document.sections)
    assert document.list_part_paths() == expected_part_paths
    assert document.source_path is None
    assert document.validation_errors() == []
    assert document.get_document_text() == ""

    reopened = HwpxDocument.from_bytes(document.compile())
    reopened.validate()
    assert reopened.get_document_text() == ""


def test_append_native_memo_roundtrip(tmp_path: Path) -> None:
    document = HwpxDocument.blank()

    memo = document.append_memo("comment-body", section_index=0)
    assert memo.text == "comment-body"
    assert len(document.memos()) == 1
    assert document.fields() == []

    output_path = tmp_path / "memo_roundtrip.hwpx"
    document.save(output_path)

    reopened = HwpxDocument.open(output_path)
    reopened.validate()

    memos = reopened.memos()
    assert len(memos) == 1
    assert memos[0].text == "comment-body"
    assert reopened.sections[0].root_element.xpath(".//hp:hiddenComment", namespaces=PARA_NS)
    assert reopened.fields() == []


def test_append_native_memo_shape_roundtrip(tmp_path: Path) -> None:
    document = HwpxDocument.blank()

    memo_shape = document.append_memo_shape(
        width=16384,
        line_width=24,
        line_type="DOT",
        line_color="#112233",
        fill_color="#FFF4CC",
        active_color="#FFAA00",
        memo_type="USER_INSERT",
    )
    document.section_settings().set_memo_shape_id(memo_shape.memo_shape_id)
    document.append_memo("comment-body", section_index=0)

    output_path = tmp_path / "memo_shape_roundtrip.hwpx"
    document.save(output_path)

    reopened = HwpxDocument.open(output_path)
    reopened.validate()

    memo_shapes = reopened.memo_shapes()
    assert len(memo_shapes) == 1
    assert memo_shapes[0].memo_shape_id == "0"
    assert memo_shapes[0].width == 16384
    assert memo_shapes[0].line_width == 24
    assert memo_shapes[0].line_type == "DOT"
    assert memo_shapes[0].line_color == "#112233"
    assert memo_shapes[0].fill_color == "#FFF4CC"
    assert memo_shapes[0].active_color == "#FFAA00"
    assert memo_shapes[0].memo_type == "USER_INSERT"
    assert reopened.section_settings().memo_shape_id == "0"
    assert reopened.header.root_element.xpath(".//hh:memoProperties/hh:memoPr[@id='0']", namespaces=HEAD_NS)


def test_append_native_form_roundtrip(tmp_path: Path) -> None:
    document = HwpxDocument.blank()

    checkbox = document.append_form(
        "Consent",
        form_type="CHECKBOX",
        name="consent",
        checked=True,
        value="CHECKED",
        section_index=0,
    )
    edit = document.append_form(
        "Approval",
        form_type="INPUT",
        name="approval",
        value="pending",
        placeholder="Type status",
        section_index=0,
    )
    combo = document.append_form(
        "Status",
        form_type="COMBOBOX",
        name="status",
        value="approved",
        items=["pending", "approved"],
        locked=True,
        section_index=0,
    )

    assert checkbox.form_type == "CHECKBOX"
    assert checkbox.checked is True
    assert edit.label == "Approval"
    assert edit.value == "pending"
    assert edit.placeholder == "Type status"
    assert combo.items == ["pending", "approved"]
    assert combo.locked is True

    output_path = tmp_path / "form_roundtrip.hwpx"
    document.save(output_path)

    reopened = HwpxDocument.open(output_path)
    reopened.validate()

    forms = reopened.forms()
    assert [form.form_type for form in forms] == ["CHECKBOX", "INPUT", "COMBOBOX"]
    assert forms[0].checked is True
    assert forms[0].label == "Consent"
    assert forms[1].label == "Approval"
    assert forms[1].value == "pending"
    assert forms[1].placeholder == "Type status"
    assert forms[2].items == ["pending", "approved"]
    assert forms[2].locked is True
    assert reopened.fields() == []
    assert reopened.sections[0].root_element.xpath(".//hp:checkBtn", namespaces=PARA_NS)
    assert reopened.sections[0].root_element.xpath(".//hp:edit", namespaces=PARA_NS)
    assert reopened.sections[0].root_element.xpath(".//hp:comboBox", namespaces=PARA_NS)
    assert reopened.sections[0].root_element.xpath(
        ".//hp:edit/hp:caption/hp:subList/hp:p/hp:run/hp:t[text()='Approval']",
        namespaces=PARA_NS,
    )
    assert reopened.sections[0].root_element.xpath(
        ".//hp:comboBox/hp:caption/hp:subList/hp:p/hp:run/hp:t[text()='Status']",
        namespaces=PARA_NS,
    )
    edit_nodes = reopened.sections[0].root_element.xpath(".//hp:edit", namespaces=PARA_NS)
    assert edit_nodes
    assert "label" not in edit_nodes[0].get("command", "")
    combo_nodes = reopened.sections[0].root_element.xpath(".//hp:comboBox[@enabled='0']", namespaces=PARA_NS)
    assert combo_nodes
    assert combo_nodes[0].xpath("./hp:caption/hp:subList", namespaces=PARA_NS)
    assert "locked" not in combo_nodes[0].get("command", "")
    assert "label" not in combo_nodes[0].get("command", "")


def test_append_native_chart_roundtrip(tmp_path: Path) -> None:
    document = HwpxDocument.blank()

    chart = document.append_chart(
        "Revenue",
        chart_type="LINE",
        categories=["Q1", "Q2"],
        series=[{"name": "Sales", "values": [10, 20]}],
        data_ref="dataset-7",
        legend_visible=False,
        width=3600,
        height=2100,
        shape_comment="chart-note",
        section_index=0,
    )
    chart.set_layout(text_wrap="SQUARE", text_flow="LEFT_ONLY", treat_as_char=False)
    chart.set_out_margins(left=1, right=2, top=3, bottom=4)
    chart.set_rotation(angle=15, center_x=120, center_y=240)

    output_path = tmp_path / "chart_roundtrip.hwpx"
    document.save(output_path)

    reopened = HwpxDocument.open(output_path)
    reopened.validate()

    charts = reopened.charts()
    assert len(charts) == 1
    assert charts[0].title == "Revenue"
    assert charts[0].chart_type == "LINE"
    assert charts[0].categories == ["Q1", "Q2"]
    assert charts[0].series == [{"name": "Sales", "values": [10, 20]}]
    assert charts[0].data_ref == "dataset-7"
    assert charts[0].legend_visible is False
    assert charts[0].shape_comment == "chart-note"
    assert charts[0].layout()["textFlow"] == "LEFT_ONLY"
    assert charts[0].rotation()["angle"] == "15"
    assert charts[0].rotation()["centerX"] == "120"
    assert charts[0].rotation()["centerY"] == "240"
    assert reopened.oles() == []
    assert reopened.sections[0].root_element.xpath(".//hp:chart", namespaces=PARA_NS)
    assert reopened.sections[0].root_element.xpath(".//hp:chart/hp:shapeComment[text()='chart-note']", namespaces=PARA_NS)
    assert reopened.sections[0].root_element.xpath(".//hp:default/hp:ole", namespaces=PARA_NS)
    assert reopened.sections[0].root_element.xpath(
        ".//hp:switch[hp:case/hp:chart]/hp:default/hp:ole/hp:rotationInfo[@angle='15'][@centerX='120'][@centerY='240']",
        namespaces=PARA_NS,
    )
    assert "Chart/chart1.xml" in reopened.list_part_paths()
    assert "BinData/ole1.ole" in reopened.list_part_paths()
    with zipfile.ZipFile(output_path) as archive:
        section_xml = archive.read("Contents/section0.xml").decode("utf-8")
    with zipfile.ZipFile(output_path) as archive:
        chart_xml = archive.read("Chart/chart1.xml").decode("utf-8")
    assert "<hp:shapeComment>chart-note</hp:shapeComment>" in section_xml
    assert "<mc:AlternateContent" in chart_xml
    assert "<c14:style val=\"102\"/>" in chart_xml
    assert "<ho:hncChartStyle" in chart_xml
    assert "<c:txPr>" in chart_xml
    assert "<c:spPr>" in chart_xml
    assert "<c:auto val=\"1\"/>" in chart_xml
    assert "<c:tickMarkSkip val=\"1\"/>" in chart_xml
    assert "<c:f>'dataset-7'!$A$2:$A$3</c:f>" in chart_xml
    assert "<c:f>'dataset-7'!$B$2:$B$3</c:f>" in chart_xml
    assert "dataRef" not in chart_xml
    assert "shapeComment" not in chart_xml
    assert "\"rotation\":" not in chart_xml
    assert "<hp:rotationInfo angle=\"15\" centerX=\"120\" centerY=\"240\"" in section_xml


def test_edit_save_and_reopen_roundtrip(sample_hwpx_path: Path, tmp_path: Path) -> None:
    document = HwpxDocument.open(sample_hwpx_path)
    original_section_count = len(document.sections)
    original_body_text = document.get_document_text()
    inserted_text = "JAKAL_INSERTED_PARAGRAPH"

    document.set_metadata(title="Roundtrip Title", creator="jakal-hwpx", keyword="roundtrip")
    document.set_preview_text("preview generated by test")
    document.append_paragraph(inserted_text, section_index=0)

    old_fragment = next((fragment for fragment in original_body_text.split() if len(fragment) >= 2), "JAKAL")
    expected_inserted_text = inserted_text.replace(old_fragment, "REPLACED", 1)
    replacements = document.replace_text(old_fragment, "REPLACED", count=1)

    assert replacements == 1

    document.add_section(text="Second section paragraph")
    document.add_or_replace_binary(
        "unit-test.bin",
        b"abc123",
        media_type="application/octet-stream",
        manifest_id="unit_test_bin",
    )

    output_path = tmp_path / "edited.hwpx"
    document.save(output_path)

    reopened = HwpxDocument.open(output_path)
    reopened.validate()

    assert reopened.metadata().title == "Roundtrip Title"
    assert reopened.metadata().creator == "jakal-hwpx"
    assert reopened.metadata().keyword == "roundtrip"
    assert isinstance(reopened.preview_text, PreviewTextPart)
    assert reopened.preview_text.text == "preview generated by test"
    assert expected_inserted_text in reopened.get_document_text()
    assert "Second section paragraph" in reopened.get_document_text()
    assert "REPLACED" in reopened.get_document_text()
    assert len(reopened.sections) == original_section_count + 1

    part = reopened.get_part("BinData/unit-test.bin", BinaryDataPart)
    assert part.data == b"abc123"


def test_missing_preview_rootfile_reference_is_tolerated() -> None:
    document = HwpxDocument()
    document.container.ensure_rootfile("Preview/PrvText.txt", "text/plain")

    assert document.validation_errors() == []


def test_open_exposes_ole_objects_from_real_sample() -> None:
    if not OLE_SAMPLE_PATH.exists():
        pytest.skip("ole_test.hwpx sample is not available in this workspace.")

    document = HwpxDocument.open(OLE_SAMPLE_PATH)

    oles = document.oles()
    assert len(oles) == 1
    ole = oles[0]
    assert isinstance(ole, OleXml)
    assert ole.kind == "ole"
    assert ole.binary_item_id == "ole1"
    assert ole.object_type == "EMBEDDED"
    assert ole.draw_aspect == "CONTENT"
    assert ole.has_moniker is False
    assert ole.extent() == {"x": 42001, "y": 13501}
    assert ole.binary_data()
    assert any(isinstance(shape, OleXml) for shape in document.shapes())


def test_append_table_picture_and_shape_roundtrip(tmp_path: Path) -> None:
    document = HwpxDocument.blank()
    image_bytes = base64.b64decode(
        "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO8B3ioAAAAASUVORK5CYII="
    )

    table = document.append_table(
        2,
        2,
        cell_texts=[["A1", "B1"], ["A2", "B2"]],
        section_index=0,
        treat_as_char=False,
        vert_align="CENTER",
        horz_align="RIGHT",
        vert_offset=120,
        horz_offset=240,
        out_margin_left=10,
        out_margin_right=20,
    )
    picture = document.append_picture(
        "pixel.png",
        image_bytes,
        width=2400,
        height=2400,
        section_index=0,
        shape_comment="Inserted picture",
        treat_as_char=False,
        allow_overlap=True,
        vert_align="CENTER",
        horz_align="RIGHT",
        vert_offset=333,
        horz_offset=444,
        out_margin_left=11,
        out_margin_right=22,
        out_margin_top=33,
        out_margin_bottom=44,
    )
    shape = document.append_shape(
        section_index=0,
        text="Inserted shape",
        width=8000,
        height=2400,
        shape_comment="Inserted shape comment",
        treat_as_char=False,
        allow_overlap=True,
        vert_align="BOTTOM",
        horz_align="CENTER",
        vert_offset=555,
        horz_offset=666,
        out_margin_left=12,
        out_margin_right=24,
    )

    assert table.cell(1, 1).text == "B2"
    assert picture.binary_data() == image_bytes
    assert shape.text == "Inserted shape"

    output_path = tmp_path / "inserted_controls.hwpx"
    document.save(output_path)

    reopened = HwpxDocument.open(output_path)
    reopened.validate()

    reopened_table = reopened.tables()[0]
    assert reopened_table.row_count == 2
    assert reopened_table.column_count == 2
    assert reopened_table.cell(0, 0).text == "A1"
    assert reopened_table.cell(1, 1).text == "B2"
    assert reopened_table.element.getparent().tag.endswith("run")

    reopened_picture = reopened.pictures()[0]
    assert reopened_picture.binary_data() == image_bytes
    assert reopened_picture.shape_comment == "Inserted picture"
    assert reopened_picture.layout()["treatAsChar"] == "0"
    assert reopened_picture.layout()["allowOverlap"] == "1"
    assert reopened_picture.layout()["vertAlign"] == "CENTER"
    assert reopened_picture.layout()["horzOffset"] == "444"
    assert reopened_picture.out_margins() == {"left": 11, "right": 22, "top": 33, "bottom": 44}
    assert reopened_picture.element.getparent().tag.endswith("run")

    reopened_shape = reopened.shapes()[0]
    assert reopened_shape.kind == "rect"
    assert reopened_shape.text == "Inserted shape"
    assert reopened_shape.shape_comment == "Inserted shape comment"
    assert reopened_shape.layout()["treatAsChar"] == "0"
    assert reopened_shape.layout()["allowOverlap"] == "1"
    assert reopened_shape.layout()["vertAlign"] == "BOTTOM"
    assert reopened_shape.layout()["horzAlign"] == "CENTER"
    assert reopened_shape.out_margins()["left"] == 12
    assert reopened_shape.out_margins()["right"] == 24
    assert reopened_shape.element.getparent().tag.endswith("run")


def test_append_shape_supports_additional_kinds(tmp_path: Path) -> None:
    document = HwpxDocument.blank()
    document.append_shape(kind="line", section_index=0, width=4000, height=1000)
    document.append_shape(kind="textart", section_index=0, text="Banner", width=7000, height=2200)
    document.append_shape(kind="container", section_index=0, text="Group", width=6000, height=2000)

    output_path = tmp_path / "extra_shapes.hwpx"
    document.save(output_path)

    reopened = HwpxDocument.open(output_path)
    reopened.validate()

    kinds = [shape.kind for shape in reopened.shapes()]
    assert "line" in kinds
    assert "textart" in kinds
    assert "container" in kinds
    assert any(shape.kind == "textart" and shape.text == "Banner" for shape in reopened.shapes())


def test_append_ole_roundtrip(tmp_path: Path) -> None:
    payload = b"JAKAL_OLE_PAYLOAD"

    document = HwpxDocument.blank()
    ole = document.append_ole(
        "sample.ole",
        payload,
        width=42001,
        height=13501,
        shape_comment="Inserted OLE",
        allow_overlap=True,
        vert_align="CENTER",
        horz_align="RIGHT",
        vert_offset=111,
        horz_offset=222,
        out_margin_left=10,
        out_margin_right=20,
        out_margin_top=30,
        out_margin_bottom=40,
    )

    assert ole.binary_data() == payload

    output_path = tmp_path / "inserted_ole.hwpx"
    document.save(output_path)

    reopened = HwpxDocument.open(output_path)
    reopened.validate()
    assert reopened.reference_validation_errors() == []

    reopened_ole = reopened.oles()[0]
    assert reopened_ole.binary_data() == payload
    assert reopened_ole.binary_item_id == "sample"
    assert reopened_ole.object_type == "EMBEDDED"
    assert reopened_ole.draw_aspect == "CONTENT"
    assert reopened_ole.extent() == {"x": 42001, "y": 13501}
    assert reopened_ole.shape_comment == "Inserted OLE"
    assert reopened_ole.layout()["allowOverlap"] == "1"
    assert reopened_ole.layout()["vertAlign"] == "CENTER"
    assert reopened_ole.layout()["horzAlign"] == "RIGHT"
    assert reopened_ole.layout()["vertOffset"] == "111"
    assert reopened_ole.layout()["horzOffset"] == "222"
    assert reopened_ole.out_margins() == {"left": 10, "right": 20, "top": 30, "bottom": 40}
    manifest_item = next(item for item in reopened.content_hpf.manifest_items() if item.get("id") == reopened_ole.binary_item_id)
    assert manifest_item.get("media-type") == "application/ole"
    assert manifest_item.get("isEmbeded") == "0"
    assert isinstance(reopened.shapes()[0], OleXml)
    assert reopened_ole.element.getparent().tag.endswith("run")


def test_low_level_authoring_roundtrip(tmp_path: Path) -> None:
    image_bytes = base64.b64decode(
        "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO8B3ioAAAAASUVORK5CYII="
    )

    document = HwpxDocument.blank()
    para_style = document.append_paragraph_style()
    para_style.set_auto_spacing(e_asian_eng=True, e_asian_num=False)
    char_style = document.append_character_style()
    char_style.set_effects(shade_color="#EEEEEE", use_font_space=True, use_kerning=True, sym_mark="DOT_ABOVE")

    settings = document.section_settings(0)
    settings.set_grid(line_grid=42, char_grid=21, wonggoji_format=True)
    settings.set_start_numbers(page_starts_on="ODD", page=7, pic=8, tbl=9, equation=10)

    picture = document.append_picture("pixel-lowlevel.png", image_bytes, width=2400, height=2400)
    picture.set_size(width=3333, height=4444, original_width=5555, original_height=6666, current_width=3333, current_height=4444)
    picture.set_rotation(angle=15, center_x=111, center_y=222, rotate_image=False)
    picture.set_image_adjustment(bright=5, contrast=6, effect="GRAY_SCALE", alpha=7)
    picture.set_crop(left=1, right=2222, top=2, bottom=3333)

    shape = document.append_shape(kind="rect", text="shape", width=5000, height=2000)
    shape.set_size(width=5100, height=2200, original_width=5300, original_height=2400, current_width=5100, current_height=2200)
    shape.set_rotation(angle=25, center_x=333, center_y=444)
    shape.set_line_style(color="#112233", width=55, style="SOLID", alpha=9)
    shape.set_fill_style(face_color="#ABCDEF", hatch_color="#123456", alpha=11)
    shape.set_text_margins(left=1, right=2, top=3, bottom=4)

    equation = document.append_equation("x=y", width=3000, height=1800)
    equation.set_size(width=3200, height=1900)
    equation.set_rotation(angle=35, center_x=555, center_y=666)

    ole = document.append_ole("lowlevel.ole", b"OLE_LOW_LEVEL", width=42001, height=13501)
    ole.set_size(width=43000, height=14000, original_width=43000, original_height=14000, current_width=123, current_height=456)
    ole.set_rotation(angle=45, center_x=777, center_y=888)
    ole.set_line_style(color="#445566", width=77, style="DASH")
    ole.set_object_metadata(object_type="LINK", draw_aspect="ICON", has_moniker=True, eq_baseline=12)
    ole.set_extent(x=43000, y=14000)

    output_path = tmp_path / "low_level_authoring.hwpx"
    document.save(output_path)

    reopened = HwpxDocument.open(output_path)
    reopened.validate()

    reopened_para_style = reopened.get_paragraph_style(para_style.style_id or "")
    reopened_char_style = reopened.get_character_style(char_style.style_id or "")
    reopened_settings = reopened.section_settings(0)
    reopened_picture = reopened.pictures()[0]
    reopened_shape = next(item for item in reopened.shapes() if item.kind == "rect")
    reopened_equation = reopened.equations()[0]
    reopened_ole = reopened.oles()[0]

    assert reopened_para_style.element.xpath("./hh:autoSpacing/@eAsianEng", namespaces=HEAD_NS)[0] == "1"
    assert reopened_para_style.element.xpath("./hh:autoSpacing/@eAsianNum", namespaces=HEAD_NS)[0] == "0"
    assert reopened_char_style.element.get("shadeColor") == "#EEEEEE"
    assert reopened_char_style.element.get("useFontSpace") == "1"
    assert reopened_char_style.element.get("useKerning") == "1"
    assert reopened_char_style.element.get("symMark") == "DOT_ABOVE"

    assert reopened_settings.grid() == {"lineGrid": 42, "charGrid": 21, "wonggojiFormat": 1}
    assert reopened_settings.start_numbers() == {
        "pageStartsOn": "ODD",
        "page": "7",
        "pic": "8",
        "tbl": "9",
        "equation": "10",
    }

    assert reopened_picture.size() == {"width": 3333, "height": 4444}
    assert reopened_picture.rotation()["angle"] == "15"
    assert reopened_picture.rotation()["rotateimage"] == "0"
    assert reopened_picture.image_adjustment() == {"bright": "5", "contrast": "6", "effect": "GRAY_SCALE", "alpha": "7"}
    assert reopened_picture.crop() == {"left": 1, "right": 2222, "top": 2, "bottom": 3333}

    assert reopened_shape.size() == {"width": 5100, "height": 2200}
    assert reopened_shape.rotation()["angle"] == "25"
    assert reopened_shape.rotation()["centerX"] == "333"
    assert reopened_shape.rotation()["centerY"] == "444"
    assert reopened_shape.line_style()["color"] == "#112233"
    assert reopened_shape.line_style()["width"] == "55"
    assert reopened_shape.fill_style() == {"faceColor": "#ABCDEF", "hatchColor": "#123456", "alpha": "11"}
    assert reopened_shape.text_margins() == {"left": 1, "right": 2, "top": 3, "bottom": 4}

    assert reopened_equation.size() == {"width": 3200, "height": 1900}
    assert reopened_equation.rotation()["angle"] == "35"

    assert reopened_ole.size() == {"width": 43000, "height": 14000}
    assert reopened_ole.rotation()["angle"] == "45"
    assert reopened_ole.line_style()["color"] == "#445566"
    assert reopened_ole.object_type == "LINK"
    assert reopened_ole.draw_aspect == "ICON"
    assert reopened_ole.has_moniker is True
    assert reopened_ole.extent() == {"x": 43000, "y": 14000}


def test_hard_example_like_generation_roundtrip(tmp_path: Path) -> None:
    image_bytes = base64.b64decode(
        "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO8B3ioAAAAASUVORK5CYII="
    )

    document = HwpxDocument.blank()
    document.set_paragraph_text(0, 0, f" {UNICODE_STRESS_TEXT}")
    document.append_paragraph("너 안성민")
    document.append_paragraph("")
    document.append_paragraph("너 안성민은 안성민이 아니다")
    document.append_footnote(f"각주: {UNICODE_STRESS_TEXT}", number=1)
    document.append_hyperlink("https://example.com/hard", display_text="hard-link")
    document.append_auto_number(number=1, number_type="FIGURE", kind="autoNum")
    document.append_equation("x=1+2", shape_comment="Hard-like equation", treat_as_char=False, allow_overlap=True)
    document.append_picture(
        "hard-like.bmp",
        image_bytes,
        width=4200,
        height=4200,
        shape_comment="Hard-like picture",
        treat_as_char=False,
        allow_overlap=True,
    )
    document.append_shape(
        kind="rect",
        text=f"rect: {UNICODE_STRESS_TEXT}",
        width=12000,
        height=2600,
        shape_comment="Hard-like rect",
        treat_as_char=False,
        allow_overlap=True,
    )
    document.append_shape(
        kind="textart",
        text="너 안성민",
        width=9000,
        height=2400,
        shape_comment="Hard-like textart",
    )
    document.append_ole(
        "hard-like.ole",
        b"HARD_LIKE_OLE",
        width=42001,
        height=13501,
        shape_comment="Hard-like OLE",
        treat_as_char=False,
    )

    output_path = tmp_path / "hard_like.hwpx"
    document.save(output_path)

    reopened = HwpxDocument.open(output_path)
    reopened.validate()
    assert reopened.reference_validation_errors() == []

    assert UNICODE_STRESS_TEXT in reopened.get_document_text()
    assert len(reopened.pictures()) == 1
    assert len(reopened.oles()) == 1
    assert len(reopened.equations()) == 1
    assert any(note.kind == "footNote" for note in reopened.notes())
    assert len(reopened.fields()) == 1
    assert len(reopened.auto_numbers()) == 1
    kinds = [shape.kind for shape in reopened.shapes()]
    assert "rect" in kinds
    assert "textart" in kinds
    assert "ole" in kinds


def test_generic_xml_authoring_supports_unsupported_features_roundtrip(tmp_path: Path) -> None:
    document = HwpxDocument.blank()

    section_xml = document.section_xml(0)
    header_xml = document.header_xml()
    settings_xml = document.settings_xml()
    content_hpf_xml = document.content_hpf_xml()

    assert section_xml.local_name == "sec"
    assert header_xml.local_name == "head"
    assert settings_xml.local_name == "HWPApplicationSetting"
    assert content_hpf_xml.local_name == "package"
    assert document.xml_part("Contents/section0.xml").local_name == "sec"

    line_number_shape = section_xml.find(".//hp:lineNumberShape")
    assert line_number_shape is not None
    line_number_shape.set_attr("countBy", 3).set_attr("distance", 150)

    sec_pr = section_xml.find(".//hp:secPr")
    assert sec_pr is not None

    footnote_placement = section_xml.find(".//hp:footNotePr/hp:placement")
    if footnote_placement is None:
        sec_pr.append_xml(
            '<hp:footNotePr xmlns:hp="http://www.hancom.co.kr/hwpml/2011/paragraph">'
            '<hp:autoNumFormat type="DIGIT" userChar="" prefixChar="" suffixChar=")" supscript="0"/>'
            '<hp:noteLine length="-1" type="SOLID" width="0.12 mm" color="#000000"/>'
            '<hp:noteSpacing betweenNotes="283" belowLine="567" aboveLine="850"/>'
            '<hp:numbering type="CONTINUOUS" newNum="1"/>'
            '<hp:placement place="EACH_COLUMN" beneathText="0"/>'
            '</hp:footNotePr>'
        )
        footnote_placement = section_xml.find(".//hp:footNotePr/hp:placement")
    assert footnote_placement is not None
    footnote_placement.set_attr("place", "END_OF_DOCUMENT").set_attr("beneathText", 1)

    page_border_fill = section_xml.find(".//hp:pageBorderFill[@type='BOTH']")
    if page_border_fill is None:
        sec_pr.append_xml(
            '<hp:pageBorderFill xmlns:hp="http://www.hancom.co.kr/hwpml/2011/paragraph" '
            'type="BOTH" borderFillIDRef="1" textBorder="PAPER" headerInside="0" footerInside="0" fillArea="PAPER">'
            '<hp:offset left="1417" right="1417" top="1417" bottom="1417"/>'
            '</hp:pageBorderFill>'
        )
        page_border_fill = section_xml.find(".//hp:pageBorderFill[@type='BOTH']")
    assert page_border_fill is not None
    page_border_fill.set_attr("fillArea", "BORDER")
    page_border_offset = page_border_fill.find("./hp:offset")
    assert page_border_offset is not None
    page_border_offset.set_attr("left", 2222).set_attr("right", 3333)

    inserted_colpr = document.append_control_xml(
        '<hp:colPr xmlns:hp="http://www.hancom.co.kr/hwpml/2011/paragraph" '
        'id="" type="NEWSPAPER" layout="LEFT" colCount="2" sameSz="1" sameGap="0"/>'
    )
    assert inserted_colpr.local_name == "colPr"

    output_path = tmp_path / "generic_xml_authoring.hwpx"
    document.save(output_path)

    reopened = HwpxDocument.open(output_path)
    reopened.validate()

    reopened_section_xml = reopened.section_xml(0)
    reopened_line_number = reopened_section_xml.find(".//hp:lineNumberShape")
    assert reopened_line_number is not None
    assert reopened_line_number.get_attr("countBy") == "3"
    assert reopened_line_number.get_attr("distance") == "150"

    reopened_footnote_placement = reopened_section_xml.find(".//hp:footNotePr/hp:placement")
    assert reopened_footnote_placement is not None
    assert reopened_footnote_placement.get_attr("place") == "END_OF_DOCUMENT"
    assert reopened_footnote_placement.get_attr("beneathText") == "1"

    reopened_page_border = reopened_section_xml.find(".//hp:pageBorderFill[@type='BOTH']")
    assert reopened_page_border is not None
    assert reopened_page_border.get_attr("fillArea") == "BORDER"
    reopened_offset = reopened_page_border.find("./hp:offset")
    assert reopened_offset is not None
    assert reopened_offset.get_attr("left") == "2222"
    assert reopened_offset.get_attr("right") == "3333"

    colpr_nodes = reopened_section_xml.findall(".//hp:colPr")
    assert any(node.get_attr("colCount") == "2" for node in colpr_nodes)


def test_append_header_footer_notes_number_equation_and_styles_roundtrip(tmp_path: Path) -> None:
    document = HwpxDocument.blank()

    para_style = document.append_paragraph_style(alignment_horizontal="CENTER", line_spacing=180)
    para_style.set_margin(left=111, right=222, prev=333, next=444, intent=555)
    para_style.set_break_setting(keep_with_next=True, keep_lines=True, page_break_before=True, line_wrap="BREAK")
    char_style = document.append_character_style(text_color="#224466", height=1250)
    char_style.set_font_refs(hangul="1", latin="1")
    char_style.set_relative_shape("spacing", hangul=5, latin=6)
    char_style.set_relative_shape("ratio", hangul=95, latin=96)
    char_style.set_relative_shape("offset", hangul=2, latin=3)
    char_style.set_underline(underline_type="NONE", shape="SOLID", color="#224466")
    style = document.append_style(
        "Inserted Style",
        english_name="Inserted Style",
        para_pr_id=para_style.style_id,
        char_pr_id=char_style.style_id,
    )
    style.configure(next_style_id=style.style_id, lang_id="1033", lock_form=True)

    header = document.append_header("Inserted header", apply_page_type="EVEN", hide_first=True)
    footer = document.append_footer("Inserted footer", apply_page_type="ODD", hide_first=False)
    header.set_apply_page_type("BOTH")
    footer.set_apply_page_type("EVEN")
    document.append_footnote("Inserted footnote", number=1)
    document.append_endnote("Inserted endnote", number=2)
    document.append_auto_number(number=7, number_type="PAGE", kind="newNum")
    document.append_auto_number(number=3, number_type="EQUATION", kind="autoNum")
    document.section_settings(0).set_margins(header=321, footer=654)
    document.section_settings(0).set_visibility(hide_first_header=False, hide_first_footer=True)
    document.append_equation(
        "x=1+2",
        shape_comment="Inserted equation",
        treat_as_char=False,
        allow_overlap=True,
        vert_align="CENTER",
        horz_align="RIGHT",
        vert_offset=77,
        horz_offset=88,
        out_margin_left=13,
        out_margin_right=26,
    )
    document.append_paragraph(
        "Styled paragraph",
        section_index=0,
        style_id=style.style_id,
        para_pr_id=para_style.style_id,
        char_pr_id=char_style.style_id,
    )

    output_path = tmp_path / "inserted_missing_apis.hwpx"
    document.save(output_path)

    reopened = HwpxDocument.open(output_path)
    reopened.validate()
    assert reopened.reference_validation_errors() == []

    assert reopened.headers()[0].text == "Inserted header"
    assert reopened.headers()[0].apply_page_type == "BOTH"
    assert reopened.footers()[0].text == "Inserted footer"
    assert reopened.footers()[0].apply_page_type == "EVEN"
    assert any(note.kind == "footNote" and note.text == "Inserted footnote" for note in reopened.notes())
    assert any(note.kind == "endNote" and note.text == "Inserted endnote" for note in reopened.notes())
    assert any(item.kind == "newNum" and item.number == "7" for item in reopened.auto_numbers())
    assert any(item.kind == "autoNum" and item.number == "3" for item in reopened.auto_numbers())
    assert reopened.equations()[0].script == "x=1+2"
    assert reopened.equations()[0].shape_comment == "Inserted equation"
    assert reopened.equations()[0].layout()["treatAsChar"] == "0"
    assert reopened.equations()[0].layout()["allowOverlap"] == "1"
    assert reopened.equations()[0].layout()["horzAlign"] == "RIGHT"
    assert reopened.equations()[0].out_margins()["left"] == 13
    assert reopened.equations()[0].element.getparent().tag.endswith("run")
    assert reopened.section_settings(0).margins()["header"] == 321
    assert reopened.section_settings(0).margins()["footer"] == 654
    assert reopened.section_settings(0).visibility()["hideFirstHeader"] == "0"
    assert reopened.section_settings(0).visibility()["hideFirstFooter"] == "1"

    reopened_style = next(item for item in reopened.styles() if item.name == "Inserted Style")
    reopened_para_style = reopened.get_paragraph_style(para_style.style_id or "")
    reopened_char_style = reopened.get_character_style(char_style.style_id or "")
    assert reopened_style.para_pr_id == para_style.style_id
    assert reopened_style.char_pr_id == char_style.style_id
    assert reopened_style.element.get("nextStyleIDRef") == style.style_id
    assert reopened_style.element.get("langID") == "1033"
    assert reopened_style.element.get("lockForm") == "1"
    assert reopened_para_style.alignment_horizontal == "CENTER"
    assert reopened_para_style.line_spacing == "180"
    assert reopened_para_style.element.xpath("./hh:margin/hc:left/@value", namespaces=HEAD_NS)[0] == "111"
    assert reopened_para_style.element.xpath("./hh:breakSetting/@keepWithNext", namespaces=HEAD_NS)[0] == "1"
    assert reopened_char_style.text_color == "#224466"
    assert reopened_char_style.height == "1250"
    assert reopened_char_style.element.xpath("./hh:fontRef/@hangul", namespaces=HEAD_NS)[0] == "1"
    assert reopened_char_style.element.xpath("./hh:spacing/@hangul", namespaces=HEAD_NS)[0] == "5"
    assert reopened_char_style.element.xpath("./hh:ratio/@hangul", namespaces=HEAD_NS)[0] == "95"
    assert reopened_char_style.element.xpath("./hh:offset/@hangul", namespaces=HEAD_NS)[0] == "2"


def test_validation_errors_return_structured_issues() -> None:
    document = HwpxDocument()
    document.remove_part("Contents/header.xml")

    issues = document.validation_errors()

    assert issues
    assert all(isinstance(issue, ValidationIssue) for issue in issues)
    missing_header = next(issue for issue in issues if issue.part_path == "Contents/header.xml")
    assert missing_header.kind == "missing_part"
    assert missing_header.code == "missing_part"
    assert "Missing required part" in missing_header.message
    assert missing_header.to_dict()["code"] == "missing_part"
    assert missing_header.to_dict()["part_path"] == "Contents/header.xml"


def test_strict_lint_reports_llm_prone_hwpx_package_issues() -> None:
    document = HwpxDocument()
    first_paragraph = document.sections[0].root_element.xpath("./hp:p", namespaces=PARA_NS)[0]
    first_run = first_paragraph.xpath("./hp:run", namespaces=PARA_NS)[0]
    first_run.attrib.pop("charPrIDRef", None)

    document.add_part("BinData/orphan.bin", b"ORPHAN-BINARY")
    document.add_or_replace_binary(
        "manifest-only.png",
        b"MANIFEST-ONLY",
        media_type="image/jpeg",
        manifest_id="manifest_only_png",
    )

    mimetype_info = zipfile.ZipInfo("mimetype")
    mimetype_info.compress_type = zipfile.ZIP_DEFLATED
    document._zip_infos["mimetype"] = mimetype_info
    document._part_order = [path for path in document._part_order if path != "mimetype"] + ["mimetype"]

    document.append_form("Approval", form_type="INPUT", name="approval", value="pending")
    document.append_memo("comment-body")
    document.append_memo_shape(memo_shape_id="2")
    document.append_memo_shape(memo_shape_id="2")
    document.section_settings().set_memo_shape_id("7")
    document.append_chart(
        "Revenue",
        chart_type="LINE",
        categories=["Q1", "Q2"],
        series=[{"name": "Sales", "values": [10, 20]}],
    )

    form_node = document.sections[0].root_element.xpath(".//hp:edit", namespaces=PARA_NS)[0]
    form_pos = form_node.xpath("./hp:pos", namespaces=PARA_NS)[0]
    form_node.remove(form_pos)
    form_caption = form_node.xpath("./hp:caption", namespaces=PARA_NS)[0]
    form_caption_sublist = form_caption.xpath("./hp:subList", namespaces=PARA_NS)[0]
    form_caption.remove(form_caption_sublist)
    form_node.set("command", "JAKAL_FORM_META:{oops")

    memo_node = document.sections[0].root_element.xpath(".//hp:hiddenComment", namespaces=PARA_NS)[0]
    memo_sublist = memo_node.xpath("./hp:subList", namespaces=PARA_NS)[0]
    memo_node.remove(memo_sublist)

    chart_switch = document.sections[0].root_element.xpath(".//hp:switch[hp:case/hp:chart]", namespaces=PARA_NS)[0]
    chart_default = chart_switch.xpath("./hp:default", namespaces=PARA_NS)[0]
    chart_switch.remove(chart_default)
    memo_properties = document.header.root_element.xpath(".//hh:memoProperties", namespaces=HEAD_NS)[0]
    memo_properties.set("itemCnt", "1")

    issues = document.strict_lint_errors()
    issue_codes = {issue.code for issue in issues}
    issue_messages = "\n".join(issue.message for issue in issues)
    report = document.strict_lint_report()
    formatted = document.format_strict_lint_errors()

    assert "style_binding" in issue_codes
    assert "binary_closure" in issue_codes
    assert "binary_media_type" in issue_codes
    assert "mimetype_packaging" in issue_codes
    assert "control_subtree" in issue_codes
    assert "metadata_schema" in issue_codes
    assert "chart_closure" in issue_codes
    assert "memo_reference" in issue_codes
    assert "run is missing charPrIDRef" in issue_messages
    assert "BinData part is not referenced by content.hpf manifest: BinData/orphan.bin" in issue_messages
    assert "manifest binary item is not referenced by any control: manifest_only_png" in issue_messages
    assert "mimetype must be the first package entry" in issue_messages
    assert "mimetype must be stored without compression" in issue_messages
    assert "edit is missing hp:pos" in issue_messages
    assert "edit caption is missing hp:subList" in issue_messages
    assert "edit command metadata must be valid JSON" in issue_messages
    assert "hiddenComment is missing hp:subList" in issue_messages
    assert "memoProperties itemCnt=1 does not match memoPr count=2" in issue_messages
    assert "Duplicate hh:memoPr id: 2" in issue_messages
    assert "memoShapeIDRef points to unknown hh:memoPr id 7" in issue_messages
    assert "native hp:chart control is missing hp:default/hp:ole fallback" in issue_messages
    assert any(item["code"] == "style_binding" for item in report)
    assert "[style_binding]" in formatted

    with pytest.raises(HwpxValidationError):
        document.strict_validate()


def test_strict_lint_reports_missing_chart_fallback_rotation_info() -> None:
    document = HwpxDocument.blank()
    document.append_chart("Revenue", chart_type="BAR", categories=["Q1"], series=[{"name": "Sales", "values": [10]}])

    rotation_node = document.sections[0].root_element.xpath(
        ".//hp:switch[hp:case/hp:chart]/hp:default/hp:ole/hp:rotationInfo",
        namespaces=PARA_NS,
    )[0]
    rotation_node.getparent().remove(rotation_node)

    issues = document.strict_lint_errors()
    issue_messages = "\n".join(issue.message for issue in issues)

    assert "native hp:chart fallback hp:ole is missing hp:rotationInfo" in issue_messages


def test_strict_lint_reports_invalid_form_placeholder_metadata() -> None:
    document = HwpxDocument.blank()
    document.append_form("Approval", form_type="INPUT", name="approval", value="pending")

    form_node = document.sections[0].root_element.xpath(".//hp:edit", namespaces=PARA_NS)[0]
    form_node.set("command", 'JAKAL_FORM_META:{"placeholder":123,"items":"bad","label":456}')

    issues = document.strict_lint_errors()
    issue_messages = "\n".join(issue.message for issue in issues)

    assert "edit placeholder metadata must be a string." in issue_messages
    assert "edit items metadata must be a list." in issue_messages
    assert "edit label metadata must be a string." in issue_messages


def test_strict_lint_reports_invalid_form_metadata_items_entries() -> None:
    document = HwpxDocument.blank()
    document.append_form("Approval", form_type="INPUT", name="approval", value="pending")

    form_node = document.sections[0].root_element.xpath(".//hp:edit", namespaces=PARA_NS)[0]
    form_node.set("command", 'JAKAL_FORM_META:{"items":["ok",1]}')

    issues = document.strict_lint_errors()
    issue_messages = "\n".join(issue.message for issue in issues)

    assert "edit items metadata entries must be strings." in issue_messages


def test_strict_lint_reports_invalid_jakal_memo_carrier_parameters() -> None:
    document = HwpxDocument.blank()
    document.append_memo("comment-body")
    document.append_field(
        field_type="JAKAL_MEMO",
        display_text="comment-body",
        name="memo-1",
        parameters={"Visible": "maybe", "Order": "NaN", "Author": "Alice"},
    )

    issues = document.strict_lint_errors()
    issue_messages = "\n".join(issue.message for issue in issues)

    assert "JAKAL_MEMO carrier Visible parameter must be a bool-like literal." in issue_messages
    assert "JAKAL_MEMO carrier Order parameter must be an integer." in issue_messages
