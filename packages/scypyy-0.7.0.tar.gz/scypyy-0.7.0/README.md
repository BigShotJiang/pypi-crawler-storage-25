# scypyy

A curated collection.
## Installation

```bash
pip install scypyy
```

## Usage

```python
import scypyy

print(scypyy.get())
```

This prints a help.
