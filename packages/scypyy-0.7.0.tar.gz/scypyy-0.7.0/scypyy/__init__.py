"""scypyy - A curated collection of common Python imports for data science."""

from .core import get

__all__ = ["get"]
