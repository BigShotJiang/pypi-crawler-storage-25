# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Workspace layout assumption

Path references in this file assume Steward is checked out **alongside** its sibling Culture projects in the same parent directory — i.e. `<workspace>/steward/`, `<workspace>/culture/`, `<workspace>/daria/`. If your checkout layout differs, treat sibling paths below as descriptive (they name the project, not a guaranteed filesystem location).

## What this project is

Steward aligns and maintains **resident agents** across Culture projects. It is a sibling to [`culture`](https://github.com/agentculture/culture) (the IRC-based agent mesh) and [`daria`](https://github.com/agentculture/daria) (the awareness agent) within the broader Organic Development framework — see the workspace-level `CLAUDE.md` (one directory above this repo, when present) for the cross-project overview and the all-backends rule that governs Culture.

"Resident agents" here means the long-lived agent processes that Culture spawns per machine/peer (e.g. `culture start <agent-name>`). Steward's role is to keep those agents' configuration, prompts, and lifecycle policies coherent across the mesh — not to run agents itself.

## Steward's lane: file issues, never edit siblings

**Steward modifies only its own repo.** It never writes files into, scaffolds,
or branches/commits inside another repo. To bring a sibling up to the stack —
"onboard", "align", "set up", "update with our stack", "set up the pipelines" —
the deliverable is a **GitHub issue filed on that sibling's repo** with a
self-contained brief, using the `communicate` skill's `post-issue.sh`. The
sibling's own resident agent does the scaffolding.

This holds even under direct imperatives. "Set them up" / "update X with our
stack" is an instruction about the *action* (file the brief), not permission to
edit the sibling. If you find yourself running `Write`/`Edit` against a path
outside this repo, stop — that is the bug this rule exists to prevent. The one
exception is steward's *own* artifacts that happen to describe siblings (e.g.
adding a consumer to `docs/skill-sources.md`), which are edits to this repo.

### What "the works" / "our stack" means

When a brief says to bring a sibling up to "the works" (a.k.a. "our stack"),
it means the full AgentCulture sibling pattern. Two source-of-truth docs define
it; quote the relevant parts into the brief so it stays self-contained:

- **`docs/sibling-pattern.md`** — the required artifacts (toolchain, top-level
  package, afi-cli CLI scaffold with agent-first verbs `whoami`/`learn`/`explain`,
  dry-run-by-default writes, tests, CI `tests.yml` + `publish.yml`, changelog,
  lint configs, per-machine `skills.local.yaml.example`, and the system-prompt
  file for the declared backend).
- **`docs/skill-sources.md`** — the canonical skill set to vendor (cite, don't
  import): `cicd`, `communicate`, `version-bump`, `run-tests`, `sonarclaude`,
  `doc-test-alignment`. steward is the upstream for all six.

For an `acp` / locally-hosted (e.g. vLLM) agent rather than a Claude-backed one,
the runtime prompt is `AGENTS.md` (not `CLAUDE.md`) and `culture.yaml` declares
`backend: acp` + a `model: vllm-local/...` + an inline `system_prompt` +
`acp_command` — `daria` is the worked example. A `CLAUDE.md` may also be present
as dev guidance for a Claude that resides in the repo to help; the two coexist.

## Project shape

Distributed as **`steward-cli`** on PyPI (Trusted Publishing). The Python package is `steward`; the binary is `steward`. Layout follows the afi-cli pattern (top-level package, no `src/`):

```text
steward/                    # Python package (pip install steward-cli)
├── __init__.py             # __version__ via importlib.metadata("steward-cli")
├── __main__.py             # python -m steward
└── cli/
    ├── __init__.py         # argparse main(); _StewardArgumentParser
    ├── _errors.py          # StewardError + EXIT_USER_ERROR / EXIT_ENV_ERROR
    ├── _output.py          # emit_result / emit_error / emit_diagnostic
    └── _commands/          # subcommand modules; each has register(sub) + handler
        ├── show.py         # `steward show <target>` → wraps agent-config skill
        ├── doctor.py       # `steward doctor` → single-repo or corpus diagnosis
        ├── _corpus.py      # corpus helpers used by `doctor --scope siblings`
        ├── overview.py     # `steward overview` → ecosystem sense-making evidence pack
        └── _graph.py       # typed relationship graph + extractors + renderers (overview)
tests/                      # pytest suite
.claude/skills/             # see "Skills convention" below
.github/workflows/          # tests.yml + publish.yml (OIDC Trusted Publishing)
pyproject.toml              # version source-of-truth
CHANGELOG.md                # Keep-a-Changelog
```

## Build / test / publish

- **Install for dev:** `uv sync` (or `uv pip install -e .` then `uv pip install --group dev`).
- **Run CLI from source:** `uv run steward --version` / `uv run python -m steward show ../culture`.
- **Tests:** `uv run pytest -n auto -v`. CI runs on every PR + push to main.
- **Version bump:** `python3 .claude/skills/version-bump/scripts/bump.py {patch|minor|major}` — updates `pyproject.toml` and prepends a CHANGELOG entry. **Required on every PR** (the `version-check` CI job comments on the PR and fails the run if the version matches main; AgentCulture rule, no exceptions for docs/config-only changes).
- **Publish:** push to `main` triggers `.github/workflows/publish.yml` → builds with `uv build` → publishes `steward-cli` to PyPI via Trusted Publishing (no API tokens). PRs publish a `.dev<run_number>` to TestPyPI for smoke-testing. Fork PRs are skipped (no OIDC context). The release is whatever version is in `pyproject.toml` at merge time.
- The CLI is also exposed as `agents-lens` (a second console script, same entry point as `steward`).

## Finishing a branch: default to a PR, never pause for the menu

When work on a branch is complete and tests pass, **proceed directly to
pushing the branch and opening a Pull Request** — do not present an
interactive "what would you like to do?" menu and wait for a choice.

This overrides the Superpowers `finishing-a-development-branch` skill,
whose default is to stop and ask the user to pick among *merge locally /
create PR / keep as-is / discard*. That pause breaks the flow. In steward
— and in every AgentCulture sibling — the standing choice is **always
option 2, "Push and create a Pull Request,"** done via the `cicd` skill
(`workflow.sh open` / `agex pr open`). It is the integration point for the
whole `branch → implement → bump version → PR` workflow.

Merge-locally, keep-as-is, and discard remain available, but only when the
user explicitly asks for one of them. Absent that, finishing a branch
means opening the PR.

## Conventions in use

- **Packaging:** `uv` + `pyproject.toml` (hatchling backend), `[project.scripts]` entry point.
- **Tests:** `pytest` (xdist + cov-xml in CI). Tests live under `tests/`.
- **Lint:** `flake8`, `bandit`, `black`, `isort`. Run via uv (`uv run black steward tests`, etc.).
- **Versioning:** single source of truth in `pyproject.toml`. `steward.__version__` is read at import time from package metadata — there is no separate `__version__` literal to keep in sync.
- **Markdown:** `markdownlint-cli2` against a repo-local `.markdownlint-cli2.yaml` once one is committed. Don't depend on a per-user home-directory config.

## Skills convention

Every skill in `.claude/skills/<name>/` ships:

1. `SKILL.md` — explains *why* and *when* to use it. Frontmatter + short prose; no inline 10-step walk-throughs.
2. `scripts/<entry-point>.sh` (or `.py`) — the script that automates the workflow. Following the skill should be "run this script," not "do these ten manual steps." If a skill doesn't have a script, write one before relying on it.
3. **No external path dependencies.** Scripts must not reach into another skill's home-directory copy or any other location outside this repo. If a skill needs functionality from elsewhere, vendor it into the skill's own `scripts/` directory. This makes skills portable across Culture projects (Steward's mission is alignment; that requires copy-paste portability).

Per-machine paths (Culture server manifest location, sibling-project paths, etc.) live in **`.claude/skills.local.yaml`** (git-ignored). A committed `.claude/skills.local.yaml.example` documents every key. Skills read the local file, falling back to the example when the local copy hasn't been created yet.

Steward is a "skills supplier" for the Culture mesh. The canonical
upstream/downstream map lives in `docs/skill-sources.md`; that file's
"Downstream copies" column is the source of truth for who consumes what.

**When you ship a behavior change to a skill in this repo's
`.claude/skills/<name>/`** (new script, changed flag surface,
hardened existing script — anything beyond identifier-only or
doc-only edits), broadcast a migration brief to the consumers
listed in the ledger:

```bash
steward announce-skill-update --skill <name> --since <last-stable-version>
```

The verb renders the canonical six-section brief from live state
(the upstream `scripts/` listing, the `CHANGELOG.md` excerpt since
`<last-stable-version>`, and the consumer list from
`docs/skill-sources.md`) and pipes it through this repo's
`.claude/skills/communicate/scripts/post-issue.sh` per consumer. Use
`--dry-run` to preview, `--list` to sanity-check the consumer list.
Don't broadcast on identifier-only or doc-only edits.

If `docs/skill-sources.md`'s downstream column is missing a known
consumer (e.g. a sibling whose `SKILL.md` openly cites
`vendored from ../steward/...`), edit the ledger first — the
broadcast is only as good as the consumer list. The all-backends
rule applied to skills.

## Roadmap (CLI surface)

The CLI ships three verbs today: `steward show`, `steward doctor`, and
`steward overview`. Doctor runs in two modes — single-repo diagnosis (the
original "verify" flow, folded into doctor) and corpus mode (the
agent-iteration flow). The `--apply` repair mode is the next layer on top.

`doctor` and `overview` are complementary: `doctor` asks *"is this sibling
healthy and aligned?"* (health / compliance); `overview` asks *"what exists,
how does it fit together, and what seems missing?"* (sense-making).

- `steward doctor <path>` (default `--scope self`) — score a target repo
  against `docs/sibling-pattern.md`. Aggregates findings across all
  selected checks, then exits non-zero if any finding was reported.
  Human-readable findings go to stderr; `--json` emits the structured
  findings list to stdout. Today: `portability` (runs steward's own
  vendored `.claude/skills/cicd/scripts/portability-lint.sh` against
  the target, so the target doesn't need to vendor it) and
  `skills-convention` (every `SKILL.md` has a sibling `scripts/`
  entry-point and matching frontmatter `name`).
- `steward doctor --scope siblings` — walks every `culture.yaml` in the
  workspace (`<workspace-root>/*/culture.yaml`, sibling-only by default),
  tallies field/skill/CLAUDE.md-section frequency across the corpus to
  synthesize `docs/perfect-patient.md`, scores every declared agent
  against that baseline, and writes per-target feedback into
  `<target>/docs/steward/steward-suggestions.md` (gated by a marker line
  so hand-written content in that path is preserved). Diagnostic-only —
  exits 0 even when individual agents drift from the baseline; that is
  reported in the per-target file rather than as a CLI failure.
- `steward overview [target]` (default `--scope self`) — sense-making
  companion to `doctor`. Deterministically assembles a typed relationship
  graph (repo / agent / skill / channel / package nodes; declares /
  supplies / consumes / present_on / depends_on / references edges, each
  citing its source) from `culture.yaml`, `docs/skill-sources.md`, sibling
  `pyproject.toml` deps, and CLAUDE.md/README cross-references, plus
  candidate signals (orphan / unowned skill, ledger gap, overlap,
  over-connected agent, isolated repo). Emits markdown-with-mermaid by
  default, or a neo4j-loadable `--json` `{nodes, edges, signals}` structure.
  `--scope self <target>` shows that repo's ego graph (the repo + its
  directly-incident edges); `--scope siblings` shows the full corpus graph.
  Steward stops at observed facts + neutral signals; the agent that ran it
  narrates the inferred-relationships and suggestions layers. No LLM, no
  repo mutation. That narration is driven by this repo's `org-overview` skill
  (`.claude/skills/org-overview/`), which runs `steward overview` and speaks
  the three layers in chat, reflect-only.
- `steward doctor --apply` *(planned)* — repair what diagnosis flagged,
  where the repair is unambiguous (missing `scripts/` directory, missing
  `.markdownlint-cli2.yaml`, missing `.claude/skills.local.yaml.example`,
  etc.). Larger emissions (CLI scaffold) land later as additional repair
  handlers, eventually consuming `../afi-cli/afi/cite/_engine.py` rather
  than re-implementing it.

Per-skill upstreams (which repo owns the canonical copy of `version-bump`,
`cicd`, `communicate`, etc.) are recorded in `docs/skill-sources.md` so
`doctor` can vendor deterministically.

## Working with Culture from here

Steward will need to read or write Culture artifacts (agent definitions, server configs, mesh links). Useful entry points:

- Culture CLI: `culture` (server lifecycle, agent start/stop, mesh linking).
- Culture project: [`agentculture/culture`](https://github.com/agentculture/culture) — has its own `CLAUDE.md` with the all-backends rule (any feature added to one of `claude`/`codex`/`copilot`/`acp` backends must land in all four). Sibling-relative path: `../culture` (assumes the workspace layout above).
- Daria: [`agentculture/daria`](https://github.com/agentculture/daria) — reference for an agent that observes and acts on Culture state. Sibling-relative path: `../daria`.

If Steward grows a config schema or CLI surface, treat the all-backends rule as load-bearing: alignment logic must not silently assume one backend.
