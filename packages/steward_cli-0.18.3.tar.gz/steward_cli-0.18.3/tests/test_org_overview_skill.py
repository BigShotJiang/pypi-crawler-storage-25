"""End-to-end tests for the org-overview skill's runner script.

The script (`.claude/skills/org-overview/scripts/org-overview.sh`) is thin
deterministic glue: it resolves how to invoke steward, picks the scope, and
delegates to `steward overview`. These tests pin that glue against a fake
workspace, mirroring tests/test_cli_overview.py's fixture style.
"""

from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path

import pytest
import yaml

REPO_ROOT = Path(__file__).resolve().parent.parent
SCRIPT = REPO_ROOT / ".claude" / "skills" / "org-overview" / "scripts" / "org-overview.sh"


@pytest.fixture(autouse=True)
def _require_bash() -> None:
    if shutil.which("bash") is None:
        pytest.skip("bash not available")


def _seed(workspace: Path, name: str, agents: list[dict]) -> Path:
    repo = workspace / name
    repo.mkdir()
    (repo / "culture.yaml").write_text(yaml.safe_dump({"agents": agents}))
    return repo


def _run(args: list[str]) -> subprocess.CompletedProcess[str]:
    # cwd=REPO_ROOT so steward resolves its own repo root + ledger, matching
    # test_cli_overview.py's chdir(REPO_ROOT).
    return subprocess.run(
        ["bash", str(SCRIPT), *args],
        cwd=REPO_ROOT,
        capture_output=True,
        text=True,
        timeout=30,
    )


def test_no_target_runs_siblings_scope(tmp_path: Path) -> None:
    workspace = tmp_path / "ws"
    workspace.mkdir()
    _seed(workspace, "alpha", [{"suffix": "a", "backend": "claude"}])
    _seed(workspace, "beta", [{"suffix": "b", "backend": "acp"}])

    result = _run(["--workspace-root", str(workspace)])

    assert result.returncode == 0, result.stderr
    assert "# AgentCulture ecosystem overview" in result.stdout
    assert "```mermaid" in result.stdout
    assert "## For the narrating agent" in result.stdout


def test_target_runs_self_scope(tmp_path: Path) -> None:
    workspace = tmp_path / "ws"
    workspace.mkdir()
    alpha = _seed(workspace, "alpha", [{"suffix": "a", "backend": "claude"}])
    _seed(workspace, "beta", [{"suffix": "b", "backend": "claude"}])

    result = _run([str(alpha), "--workspace-root", str(workspace)])

    assert result.returncode == 0, result.stderr
    assert "# Overview: alpha" in result.stdout
    # alpha and beta are unconnected → the ego graph excludes beta.
    assert "beta" not in result.stdout


def test_json_passthrough(tmp_path: Path) -> None:
    workspace = tmp_path / "ws"
    workspace.mkdir()
    _seed(workspace, "alpha", [{"suffix": "a", "backend": "claude"}])

    result = _run(["--json", "--workspace-root", str(workspace)])

    assert result.returncode == 0, result.stderr
    payload = json.loads(result.stdout)
    assert payload["scope"] == "siblings"


def test_explicit_scope_not_doubled(tmp_path: Path) -> None:
    # When the caller passes --scope explicitly, the runner must not inject a
    # second --scope. Passing --scope siblings (no target) must still succeed.
    workspace = tmp_path / "ws"
    workspace.mkdir()
    _seed(workspace, "alpha", [{"suffix": "a", "backend": "claude"}])

    result = _run(["--scope", "siblings", "--json", "--workspace-root", str(workspace)])

    assert result.returncode == 0, result.stderr
    payload = json.loads(result.stdout)
    assert payload["scope"] == "siblings"
