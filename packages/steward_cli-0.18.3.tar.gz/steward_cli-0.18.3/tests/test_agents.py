"""Unit tests for backend detection (steward.cli._commands._agents)."""

from __future__ import annotations

from pathlib import Path

import yaml

from steward.cli._commands import _agents


def _touch(repo: Path, *relpaths: str) -> None:
    for rel in relpaths:
        p = repo / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text("x")


def test_codex_repo_uses_agents_md(tmp_path: Path) -> None:
    _touch(tmp_path, "AGENTS.md", ".agents/keep")
    prof = _agents.detect(tmp_path, ["codex"])
    assert prof.prompt_files == ["AGENTS.md"]
    assert prof.owner == "codex"
    assert prof.dual_agent is False
    assert prof.mismatch is False


def test_acp_kiro_repo(tmp_path: Path) -> None:
    _touch(tmp_path, "AGENTS.md", ".kiro/steering.md")
    prof = _agents.detect(tmp_path, ["acp"])
    assert prof.prompt_files == ["AGENTS.md"]
    assert prof.owner == "acp"
    assert prof.mismatch is False


def test_claude_repo(tmp_path: Path) -> None:
    _touch(tmp_path, "CLAUDE.md", ".claude/settings.json")
    prof = _agents.detect(tmp_path, ["claude"])
    assert prof.prompt_files == ["CLAUDE.md"]
    assert prof.owner == "claude"


def test_dual_agent_when_two_prompt_files(tmp_path: Path) -> None:
    _touch(tmp_path, "CLAUDE.md", "AGENTS.md")
    prof = _agents.detect(tmp_path, ["claude"])
    assert prof.dual_agent is True


def test_mismatch_claude_declared_but_only_agents_md(tmp_path: Path) -> None:
    _touch(tmp_path, "AGENTS.md")
    prof = _agents.detect(tmp_path, ["claude"])
    assert prof.mismatch is True
    assert "CLAUDE.md" in (prof.mismatch_reason or "")


def test_mismatch_foreign_steering_dir(tmp_path: Path) -> None:
    # Declared claude with CLAUDE.md present, but codex steering dir present.
    _touch(tmp_path, "CLAUDE.md", ".codex/config")
    prof = _agents.detect(tmp_path, ["claude"])
    assert prof.mismatch is True
    assert ".codex" in (prof.mismatch_reason or "")


def test_owner_expected_prompt_ordered_first(tmp_path: Path) -> None:
    _touch(tmp_path, "AGENTS.md", "CLAUDE.md")
    prof = _agents.detect(tmp_path, ["codex"])
    assert prof.prompt_files[0] == "AGENTS.md"  # owner's expected prompt first


def test_fallback_constant_matches_registry_yaml() -> None:
    registry = (
        Path(__file__).resolve().parents[1]
        / ".claude/skills/agent-config/data/backend-fingerprints.yaml"
    )
    data = yaml.safe_load(registry.read_text())
    assert data["backends"] == _agents._FALLBACK_FINGERPRINTS
    assert data["prompt_fallback"] == _agents._PROMPT_FALLBACK
    assert data["shared_steering"] == _agents._SHARED_STEERING


def test_agents_dir_is_not_foreign_to_claude(tmp_path: Path) -> None:
    _touch(tmp_path, "CLAUDE.md", ".agents/keep")
    prof = _agents.detect(tmp_path, ["claude"])
    assert prof.mismatch is False


def test_infer_owner_from_distinct_prompt_when_undeclared(tmp_path: Path) -> None:
    _touch(tmp_path, "CLAUDE.md")
    prof = _agents.detect(tmp_path, [])
    assert prof.owner == "claude"


def test_infer_owner_none_for_ambiguous_agents_md(tmp_path: Path) -> None:
    _touch(tmp_path, "AGENTS.md")
    prof = _agents.detect(tmp_path, [])
    assert prof.owner is None


def test_codex_repo_with_claude_code_settings_is_not_mismatch(tmp_path: Path) -> None:
    # .claude/settings.local.json is generic Claude Code tooling, not a
    # claude-backend steering signal — must not flag a codex repo.
    _touch(tmp_path, "AGENTS.md", ".codex/config", ".claude/settings.local.json")
    prof = _agents.detect(tmp_path, ["codex"])
    assert prof.mismatch is False


def test_claude_declared_with_codex_dir_still_mismatches(tmp_path: Path) -> None:
    _touch(tmp_path, "CLAUDE.md", ".codex/config")
    prof = _agents.detect(tmp_path, ["claude"])
    assert prof.mismatch is True


def test_copilot_instructions_is_not_foreign_to_codex(tmp_path: Path) -> None:
    # .github/copilot-instructions.md is generic editor tooling, not a
    # backend-ownership signal — must not flag a codex repo.
    _touch(tmp_path, "AGENTS.md", ".codex/config", ".github/copilot-instructions.md")
    prof = _agents.detect(tmp_path, ["codex"])
    assert prof.mismatch is False
