# tests/test_cli_overview.py
"""End-to-end tests for `steward overview`.

Mirrors test_cli_doctor_siblings.py: fakes a workspace under tmp_path,
runs the CLI via --workspace-root, and chdir's into the real steward
checkout so steward-root + ledger resolution works.
"""

from __future__ import annotations

import json
import os
from pathlib import Path

import pytest
import yaml

from steward.cli import main
from steward.cli._errors import EXIT_USER_ERROR

REPO_ROOT = Path(__file__).resolve().parent.parent


def _seed(workspace: Path, name: str, agents: list[dict]) -> Path:
    repo = workspace / name
    repo.mkdir()
    (repo / "culture.yaml").write_text(yaml.safe_dump({"agents": agents}))
    return repo


def test_overview_siblings_json(tmp_path: Path, capsys: pytest.CaptureFixture[str]):
    workspace = tmp_path / "ws"
    workspace.mkdir()
    _seed(workspace, "alpha", [{"suffix": "a", "backend": "claude"}])
    _seed(workspace, "beta", [{"suffix": "b", "backend": "acp"}])

    cwd = os.getcwd()
    os.chdir(REPO_ROOT)
    try:
        rc = main(["overview", "--scope", "siblings", "--json", "--workspace-root", str(workspace)])
    finally:
        os.chdir(cwd)

    captured = capsys.readouterr()
    assert rc == 0, captured.err
    payload = json.loads(captured.out)
    assert payload["scope"] == "siblings"
    node_ids = {n["id"] for n in payload["nodes"]}
    assert {"alpha", "beta", "alpha/a", "beta/b"} <= node_ids


def test_overview_siblings_markdown_has_mermaid(tmp_path: Path, capsys: pytest.CaptureFixture[str]):
    workspace = tmp_path / "ws"
    workspace.mkdir()
    _seed(workspace, "alpha", [{"suffix": "a", "backend": "claude"}])

    cwd = os.getcwd()
    os.chdir(REPO_ROOT)
    try:
        rc = main(["overview", "--scope", "siblings", "--workspace-root", str(workspace)])
    finally:
        os.chdir(cwd)

    captured = capsys.readouterr()
    assert rc == 0, captured.err
    assert "# AgentCulture ecosystem overview" in captured.out
    assert "```mermaid" in captured.out
    assert "## For the narrating agent" in captured.out


def test_overview_self_subgraph(tmp_path: Path, capsys: pytest.CaptureFixture[str]):
    workspace = tmp_path / "ws"
    workspace.mkdir()
    alpha = _seed(workspace, "alpha", [{"suffix": "a", "backend": "claude"}])
    _seed(workspace, "beta", [{"suffix": "b", "backend": "claude"}])

    cwd = os.getcwd()
    os.chdir(REPO_ROOT)
    try:
        rc = main(["overview", str(alpha), "--workspace-root", str(workspace)])
    finally:
        os.chdir(cwd)

    captured = capsys.readouterr()
    assert rc == 0, captured.err
    assert "# Overview: alpha" in captured.out
    # alpha and beta are unconnected, so the 1-hop self subgraph excludes beta.
    assert "beta" not in captured.out


def test_overview_self_json_scope(tmp_path: Path, capsys: pytest.CaptureFixture[str]):
    workspace = tmp_path / "ws"
    workspace.mkdir()
    alpha = _seed(workspace, "alpha", [{"suffix": "a", "backend": "claude"}])
    _seed(workspace, "beta", [{"suffix": "b", "backend": "claude"}])

    cwd = os.getcwd()
    os.chdir(REPO_ROOT)
    try:
        rc = main(["overview", str(alpha), "--json", "--workspace-root", str(workspace)])
    finally:
        os.chdir(cwd)

    captured = capsys.readouterr()
    assert rc == 0, captured.err
    payload = json.loads(captured.out)
    assert payload["scope"] == "self"
    node_ids = {n["id"] for n in payload["nodes"]}
    assert "alpha" in node_ids
    assert "beta" not in node_ids  # 1-hop subgraph boundary


def test_overview_siblings_json_surfaces_manifest_warnings(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
):
    workspace = tmp_path / "ws"
    workspace.mkdir()
    _seed(workspace, "alpha", [{"suffix": "a", "backend": "claude"}])
    # A culture.yaml that won't parse must surface as a JSON warning, not vanish.
    broken = workspace / "broken"
    broken.mkdir()
    (broken / "culture.yaml").write_text("agents: [unterminated\n")

    cwd = os.getcwd()
    os.chdir(REPO_ROOT)
    try:
        rc = main(["overview", "--scope", "siblings", "--json", "--workspace-root", str(workspace)])
    finally:
        os.chdir(cwd)

    captured = capsys.readouterr()
    assert rc == 0, captured.err
    payload = json.loads(captured.out)
    assert any("broken" in w for w in payload.get("warnings", []))


def test_overview_self_requires_target(capsys: pytest.CaptureFixture[str]):
    cwd = os.getcwd()
    os.chdir(REPO_ROOT)
    try:
        rc = main(["overview"])
    finally:
        os.chdir(cwd)
    captured = capsys.readouterr()
    assert rc == EXIT_USER_ERROR
    assert "target path is required" in captured.err
