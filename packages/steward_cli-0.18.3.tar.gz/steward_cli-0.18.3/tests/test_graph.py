# tests/test_graph.py
"""Unit tests for the steward overview graph model + extractors."""

from __future__ import annotations

import json
from pathlib import Path

from steward.cli._commands import _corpus, _graph


def test_add_node_merges_props():
    g = _graph.Graph()
    g.add_node("culture", _graph.NODE_REPO, path="/x")
    g.add_node("culture", _graph.NODE_REPO, extra=1)
    assert g.nodes["culture"].type == _graph.NODE_REPO
    assert g.nodes["culture"].props == {"path": "/x", "extra": 1}


def test_add_edge_dedups_on_source_target_type():
    g = _graph.Graph()
    g.add_edge("a", "b", _graph.EDGE_REFERENCES, "first")
    g.add_edge("a", "b", _graph.EDGE_REFERENCES, "second")
    assert len(g.edges) == 1
    assert g.edges[0].basis == "first"  # first basis wins


def test_ego_graph_keeps_only_center_incident_edges():
    g = _graph.Graph()
    for n in ("a", "b", "c", "d"):
        g.add_node(n, _graph.NODE_REPO)
    g.add_edge("a", "b", _graph.EDGE_REFERENCES, "x")  # incident to center a
    g.add_edge("c", "a", _graph.EDGE_REFERENCES, "x")  # incident to center a
    g.add_edge("b", "c", _graph.EDGE_REFERENCES, "x")  # neighbor-to-neighbor: dropped
    g.add_edge("c", "d", _graph.EDGE_REFERENCES, "x")  # outside: dropped
    ego = _graph.ego_graph(g, "a")
    # center + its direct neighbors only; d (2 hops) excluded
    assert set(ego.nodes) == {"a", "b", "c"}
    # only edges touching `a` survive (b->c is dropped even though b,c are kept)
    assert {(e.source, e.target) for e in ego.edges} == {("a", "b"), ("c", "a")}


def test_ego_graph_isolated_center_is_present():
    g = _graph.Graph()
    g.add_node("solo", _graph.NODE_REPO, path="/s")
    ego = _graph.ego_graph(g, "solo")
    assert set(ego.nodes) == {"solo"}
    assert ego.edges == []


def _agent(suffix: str, repo: str, **raw) -> _corpus.Agent:
    repo_path = Path("/ws") / repo
    return _corpus.Agent(
        suffix=suffix,
        backend=raw.get("backend", ""),
        repo_path=repo_path,
        manifest_path=repo_path / "culture.yaml",
        raw={"suffix": suffix, **raw},
    )


def test_add_inventory_builds_repo_agent_channel_nodes():
    g = _graph.Graph()
    _graph.add_inventory(
        g, [_agent("culture", "culture", backend="claude", channels=["#general"], tags=["t"])]
    )
    assert g.nodes["culture"].type == _graph.NODE_REPO
    agent = g.nodes["culture/culture"]
    assert agent.type == _graph.NODE_AGENT
    assert agent.props["backend"] == "claude"
    assert agent.props["tags"] == ["t"]
    assert agent.props["has_system_prompt"] is False
    assert g.nodes["#general"].type == _graph.NODE_CHANNEL
    edges = {(e.source, e.target, e.type) for e in g.edges}
    assert ("culture", "culture/culture", _graph.EDGE_DECLARES) in edges
    assert ("culture/culture", "#general", _graph.EDGE_PRESENT_ON) in edges


_LEDGER = """\
| Skill | Upstream | Downstream copies (known) | Notes |
|-------|----------|---------------------------|-------|
| `agent-config` | `steward` (`.claude/skills/agent-config/`) | — | Steward-specific. |
| `cicd` | `steward` (`agex`) | `cfafi` (still `pr-review`), `culture` (alias) | note |
| `version-bump` | `steward` (`.claude/skills/version-bump/`) | `cfafi`, `afi-cli` | note |
| `cfafi`, `cfafi-write` | `cfafi` (`.claude/skills/cfafi*/`) | — | CloudFlare. |
"""


def test_parse_skill_ledger_rows():
    rows = dict(
        (skill, (up, tuple(down))) for skill, up, down in _graph.parse_skill_ledger(_LEDGER)
    )
    assert rows["agent-config"] == ("steward", ())
    assert rows["cicd"] == ("steward", ("cfafi", "culture"))
    assert rows["version-bump"] == ("steward", ("cfafi", "afi-cli"))
    assert rows["cfafi"] == ("cfafi", ())
    assert rows["cfafi-write"] == ("cfafi", ())


def test_add_skill_ledger_edges(tmp_path: Path):
    ledger = tmp_path / "skill-sources.md"
    ledger.write_text(_LEDGER)
    g = _graph.Graph()
    _graph.add_skill_ledger(g, ledger)
    assert g.nodes["cicd"].type == _graph.NODE_SKILL
    edges = {(e.source, e.target, e.type) for e in g.edges}
    assert ("steward", "cicd", _graph.EDGE_SUPPLIES) in edges
    assert ("culture", "cicd", _graph.EDGE_CONSUMES) in edges
    assert ("cfafi", "cicd", _graph.EDGE_CONSUMES) in edges


def _write_pyproject(repo: Path, name: str, deps: list[str]):
    repo.mkdir(parents=True, exist_ok=True)
    dep_lines = ", ".join(f'"{d}"' for d in deps)
    (repo / "pyproject.toml").write_text(
        f'[project]\nname = "{name}"\ndependencies = [{dep_lines}]\n'
    )


def test_add_dependencies_external_package_node(tmp_path: Path):
    communicate = tmp_path / "communicate"
    agtag = tmp_path / "agtag"
    _write_pyproject(communicate, "communicate-cli", ["agtag>=0.1", "requests"])
    _write_pyproject(agtag, "agtag", [])
    g = _graph.Graph()
    _graph.add_dependencies(g, [communicate, agtag])
    edges = {(e.source, e.target, e.type) for e in g.edges}
    # `requests` is external -> a package node + repo->package edge.
    assert g.nodes["requests"].type == _graph.NODE_PACKAGE
    assert ("communicate", "requests", _graph.EDGE_DEPENDS_ON) in edges


def test_add_dependencies_sibling_is_repo_edge_not_package(tmp_path: Path):
    communicate = tmp_path / "communicate"
    agtag = tmp_path / "agtag"
    # agtag is a sibling repo publishing a same-named dist -> the dependency
    # is a repo->repo edge, and agtag must NOT be conflated into a package node.
    _write_pyproject(communicate, "communicate-cli", ["agtag>=0.1"])
    _write_pyproject(agtag, "agtag", [])
    g = _graph.Graph()
    _graph.add_dependencies(g, [communicate, agtag])
    edges = {(e.source, e.target, e.type) for e in g.edges}
    assert ("communicate", "agtag", _graph.EDGE_DEPENDS_ON) in edges
    # no package node for the sibling, and no leftover sibling_repo prop
    assert "agtag" not in g.nodes or g.nodes["agtag"].type == _graph.NODE_REPO
    assert "sibling_repo" not in g.nodes.get("agtag", _graph.Node("agtag", "repo")).props


def test_add_dependencies_no_self_edge_for_own_dist(tmp_path: Path):
    # A repo depending on its own published dist must not create a self-edge.
    afi = tmp_path / "afi-cli"
    _write_pyproject(afi, "afi-cli", ["afi-cli", "click"])
    g = _graph.Graph()
    _graph.add_dependencies(g, [afi])
    assert not any(e.source == "afi-cli" and e.target == "afi-cli" for e in g.edges)
    assert ("afi-cli", "click", _graph.EDGE_DEPENDS_ON) in {
        (e.source, e.target, e.type) for e in g.edges
    }


def test_add_cross_references_low_false_positive(tmp_path: Path):
    steward = tmp_path / "steward"
    culture = tmp_path / "culture"
    daria = tmp_path / "daria"
    for d in (steward, culture, daria):
        d.mkdir()
    # steward references culture (../culture) and daria (`daria`) explicitly;
    # the bare word "culture" in prose must NOT create an edge.
    (steward / "CLAUDE.md").write_text(
        "Sibling at ../culture. See `daria` for awareness. Our culture of testing is great.\n"
    )
    (culture / "CLAUDE.md").write_text("Nothing relevant here.\n")
    g = _graph.Graph()
    _graph.add_cross_references(g, [steward, culture, daria])
    edges = {(e.source, e.target, e.type) for e in g.edges}
    assert ("steward", "culture", _graph.EDGE_REFERENCES) in edges
    assert ("steward", "daria", _graph.EDGE_REFERENCES) in edges
    # no self-reference, and culture has no outgoing references
    assert not any(e.source == "steward" and e.target == "steward" for e in g.edges)
    assert not any(e.source == "culture" for e in g.edges)


def test_add_cross_references_agentculture_slug(tmp_path: Path):
    a = tmp_path / "alpha"
    b = tmp_path / "beta"
    a.mkdir()
    b.mkdir()
    (a / "README.md").write_text("Built on agentculture/beta.\n")
    g = _graph.Graph()
    _graph.add_cross_references(g, [a, b])
    assert any(
        e.source == "alpha" and e.target == "beta" and e.type == _graph.EDGE_REFERENCES
        for e in g.edges
    )


def test_collect_repo_skill_dirs(tmp_path: Path):
    repo = tmp_path / "alpha"
    (repo / ".claude" / "skills" / "cicd" / "scripts").mkdir(parents=True)
    (repo / ".claude" / "skills" / "version-bump").mkdir(parents=True)
    got = _graph.collect_repo_skill_dirs([repo])
    assert got == {"alpha": {"cicd", "version-bump"}}


def test_detect_signals_orphan_unowned_and_isolated():
    g = _graph.Graph()
    # steward supplies cicd; nobody consumes it -> orphan-skill
    g.add_node("steward", _graph.NODE_REPO)
    g.add_node("cicd", _graph.NODE_SKILL)
    g.add_edge("steward", "cicd", _graph.EDGE_SUPPLIES, "skill-sources.md")
    # lonely repo declares an agent but is otherwise unconnected -> isolated-repo
    g.add_node("lonely", _graph.NODE_REPO)
    g.add_node("lonely/x", _graph.NODE_AGENT)
    g.add_edge("lonely", "lonely/x", _graph.EDGE_DECLARES, "culture.yaml")
    # alpha vendors `mystery` (on disk) with no ledger upstream -> unowned-skill
    repo_skill_dirs = {"alpha": {"mystery"}}
    signals = _graph.detect_signals(g, repo_skill_dirs)
    kinds = {(s.kind, s.subject) for s in signals}
    assert ("orphan-skill", "cicd") in kinds
    assert ("isolated-repo", "lonely") in kinds
    assert ("unowned-skill", "mystery") in kinds


def test_detect_signals_ledger_gap():
    g = _graph.Graph()
    g.add_node("steward", _graph.NODE_REPO)
    g.add_node("culture", _graph.NODE_REPO)
    g.add_node("cicd", _graph.NODE_SKILL)
    g.add_edge("steward", "cicd", _graph.EDGE_SUPPLIES, "skill-sources.md")
    # culture vendors cicd on disk but the ledger has no consumes edge for it
    signals = _graph.detect_signals(g, {"culture": {"cicd"}})
    assert any(s.kind == "ledger-gap" and s.subject == "culture/cicd" for s in signals)


def test_detect_signals_over_connected_agent():
    g = _graph.Graph()
    g.add_node("r/busy", _graph.NODE_AGENT)
    g.add_node("r/calm", _graph.NODE_AGENT)
    for i in range(6):  # 6 channels > default threshold of 5
        g.add_edge("r/busy", f"#c{i}", _graph.EDGE_PRESENT_ON, "culture.yaml")
    for i in range(5):  # exactly at threshold -> must NOT fire
        g.add_edge("r/calm", f"#d{i}", _graph.EDGE_PRESENT_ON, "culture.yaml")
    subjects = {(s.kind, s.subject) for s in _graph.detect_signals(g, {})}
    assert ("over-connected-agent", "r/busy") in subjects
    assert not any(k == "over-connected-agent" and subj == "r/calm" for k, subj in subjects)


def test_detect_signals_overlap_and_tagless_agents():
    g = _graph.Graph()
    g.add_node("r/a", _graph.NODE_AGENT, tags=["x", "y", "z"])
    g.add_node("r/b", _graph.NODE_AGENT, tags=["x", "y"])  # shares 2 -> overlap
    g.add_node("r/c", _graph.NODE_AGENT, tags=["x"])  # shares only 1 -> no overlap
    g.add_node("r/d", _graph.NODE_AGENT)  # tags=None -> must not crash or fire
    signals = _graph.detect_signals(g, {})
    overlaps = {s.subject for s in signals if s.kind == "overlap"}
    assert "r/a ~ r/b" in overlaps
    assert not any("r/c" in subj for subj in overlaps)
    assert not any("r/d" in subj for subj in overlaps)


def test_to_json_shape_is_loadable():
    g = _graph.Graph()
    g.add_node("steward", _graph.NODE_REPO, path="/x")
    g.add_node("cicd", _graph.NODE_SKILL)
    g.add_edge("steward", "cicd", _graph.EDGE_SUPPLIES, "skill-sources.md")
    signals = [_graph.Signal("orphan-skill", "cicd", "no consumer")]
    payload = json.loads(_graph.to_json(g, signals, scope="siblings", generated="2026-05-21"))
    assert payload["scope"] == "siblings"
    assert payload["generated"] == "2026-05-21"
    assert {"id": "cicd", "type": "skill", "props": {}} in payload["nodes"]
    assert {"id": "steward", "type": "repo", "props": {"path": "/x"}} in payload["nodes"]
    assert {
        "source": "steward",
        "target": "cicd",
        "type": "supplies",
        "basis": "skill-sources.md",
    } in payload["edges"]
    assert payload["signals"][0]["kind"] == "orphan-skill"


def test_to_mermaid_sanitizes_ids_and_labels_edges():
    g = _graph.Graph()
    g.add_node("culture/culture", _graph.NODE_AGENT, suffix="culture")
    g.add_node("#general", _graph.NODE_CHANNEL)
    g.add_edge("culture/culture", "#general", _graph.EDGE_PRESENT_ON, "culture.yaml")
    out = _graph.to_mermaid(g)
    assert out.startswith("```mermaid")
    assert "graph LR" in out
    # ids sanitized to mermaid-safe tokens; labels preserve the real id
    assert "classDef channel" in out
    assert "n__general" in out  # sanitized node id is used in the graph
    assert '"#general"' in out
    assert "present_on" in out
    assert out.rstrip().endswith("```")


def test_inventory_lines_summary_and_suppresses_empty_columns():
    g = _graph.Graph()
    g.add_node("culture", _graph.NODE_REPO)
    g.add_node(
        "culture/culture",
        _graph.NODE_AGENT,
        suffix="culture",
        backend="claude",
        has_system_prompt=True,
    )
    g.add_edge("culture", "culture/culture", _graph.EDGE_DECLARES, "culture.yaml")
    lines = _graph._inventory_lines(g)
    body = "\n".join(lines)
    assert "1 agents across 1 repos" in body
    assert "claude ×1" in body
    assert "1 with a system prompt" in body
    header = next(line for line in lines if line.startswith("| Repo"))
    # Model / Channels / Tags are entirely empty here -> suppressed
    assert "Model" not in header
    assert "Channels" not in header
    assert "Tags" not in header
    # always-shown columns stay
    assert "Backend" in header and "System prompt" in header


def test_signal_lines_groups_ledger_gap_by_skill():
    signals = [
        _graph.Signal("ledger-gap", "alpha/cicd", "..."),
        _graph.Signal("ledger-gap", "beta/cicd", "..."),
        _graph.Signal("ledger-gap", "alpha/run-tests", "..."),
        _graph.Signal("orphan-skill", "notebooklm", "supplied by `steward` ..."),
        _graph.Signal(
            "unowned-skill",
            "telegram",
            "present in `telek/.claude/skills/` but no upstream recorded in the ledger",
        ),
    ]
    body = "\n".join(_graph._signal_lines(signals))
    assert "`cicd` ← +2: alpha, beta" in body  # two repos collapse to one line
    assert "`run-tests` ← +1: alpha" in body
    assert "orphan skills (supplied, no consumer recorded): notebooklm" in body
    assert "unowned skills (on disk, no upstream): telegram (telek)" in body


def test_signal_lines_keeps_other_kinds_individual():
    signals = [_graph.Signal("overlap", "r/a ~ r/b", "share tags: x, y")]
    body = "\n".join(_graph._signal_lines(signals))
    assert "**overlap** `r/a ~ r/b`" in body


def test_index_cli_binaries_single_owner(tmp_path: Path):
    agtag = tmp_path / "agtag"
    agtag.mkdir()
    (agtag / "pyproject.toml").write_text(
        '[project]\nname = "agtag"\n[project.scripts]\nagtag = "agtag.cli:main"\n'
    )
    parsed, _ = _graph._index_pyprojects([agtag])
    assert _graph._index_cli_binaries(parsed) == {"agtag": "agtag"}


def test_index_cli_binaries_collision_resolved_by_name_match(tmp_path: Path):
    culture = tmp_path / "culture"
    sonar = tmp_path / "culture-sonar-cli"
    culture.mkdir()
    sonar.mkdir()
    (culture / "pyproject.toml").write_text(
        '[project]\nname = "culture"\n[project.scripts]\nculture = "culture.cli:main"\n'
    )
    (sonar / "pyproject.toml").write_text(
        '[project]\nname = "culture-sonar-cli"\n[project.scripts]\nculture = "culture.cli:main"\n'
    )
    parsed, _ = _graph._index_pyprojects([culture, sonar])
    # `culture` binary maps to both repos; the repo whose name == binary wins.
    assert _graph._index_cli_binaries(parsed) == {"culture": "culture"}


def test_index_cli_binaries_ambiguous_collision_dropped(tmp_path: Path):
    antoine = tmp_path / "antoine"
    seer = tmp_path / "seer-cli"
    antoine.mkdir()
    seer.mkdir()
    (antoine / "pyproject.toml").write_text(
        '[project]\nname = "antoine"\n[project.scripts]\nkata = "antoine.cli:main"\n'
    )
    (seer / "pyproject.toml").write_text(
        '[project]\nname = "seer-cli"\n[project.scripts]\nkata = "seer.cli:main"\n'
    )
    parsed, _ = _graph._index_pyprojects([antoine, seer])
    # `kata` matches neither dir/dist name -> dropped, not guessed.
    assert _graph._index_cli_binaries(parsed) == {}


def test_signal_lines_empty():
    assert _graph._signal_lines([]) == ["_No candidate signals._"]


def test_provenance_legend_covers_every_basis():
    legend = _graph._provenance_legend()
    for basis in (
        "culture.yaml",
        "skill-sources.md",
        "pyproject.toml",
        "prompt(CLAUDE/AGENTS/GEMINI)/README.md",
        "SKILL.md/scripts",
        "doc-source registry",
    ):
        assert basis in legend


def test_provenance_legend_mentions_uses_and_documents():
    legend = _graph._provenance_legend()
    assert "uses ← SKILL.md/scripts" in legend
    assert "documents ← doc-source registry" in legend


def test_dependency_spine_line_threshold_and_count():
    g = _graph.Graph()
    for r in ("a", "b", "c"):
        g.add_node(r, _graph.NODE_REPO)
    g.add_node("shared", _graph.NODE_PACKAGE)
    g.add_node("rare", _graph.NODE_PACKAGE)
    # shared: used by a,b,c (>= ceil(3/2)=2 -> spine); rare: a only (< 2 -> counted)
    for r in ("a", "b", "c"):
        g.add_edge(r, "shared", _graph.EDGE_DEPENDS_ON, "pyproject.toml")
    g.add_edge("a", "rare", _graph.EDGE_DEPENDS_ON, "pyproject.toml")
    line = _graph._dependency_spine_line(g)
    assert "shared" in line
    assert "1 further distinct external packages" in line


def test_dependency_spine_line_single_repo_is_count_only():
    g = _graph.Graph()
    g.add_node("solo", _graph.NODE_REPO)
    g.add_node("p1", _graph.NODE_PACKAGE)
    g.add_node("p2", _graph.NODE_PACKAGE)
    g.add_edge("solo", "p1", _graph.EDGE_DEPENDS_ON, "pyproject.toml")
    g.add_edge("solo", "p2", _graph.EDGE_DEPENDS_ON, "pyproject.toml")
    assert "solo depends on 2 external packages" in _graph._dependency_spine_line(g)


def test_dependency_spine_line_no_packages():
    g = _graph.Graph()
    g.add_node("solo", _graph.NODE_REPO)
    assert "none" in _graph._dependency_spine_line(g).lower()


def test_connectivity_lines_counts_by_edge_type():
    g = _graph.Graph()
    # supplier repo with no agent
    g.add_node("steward", _graph.NODE_REPO)
    g.add_node("cicd", _graph.NODE_SKILL)
    g.add_edge("steward", "cicd", _graph.EDGE_SUPPLIES, "skill-sources.md")
    # hub repo: 1 agent on 1 channel; consumes cicd; deps on a sibling + a package;
    # references the sibling; referenced by another repo
    g.add_node("culture", _graph.NODE_REPO)
    g.add_node("culture/culture", _graph.NODE_AGENT, suffix="culture")
    g.add_edge("culture", "culture/culture", _graph.EDGE_DECLARES, "culture.yaml")
    g.add_node("#general", _graph.NODE_CHANNEL)
    g.add_edge("culture/culture", "#general", _graph.EDGE_PRESENT_ON, "culture.yaml")
    g.add_edge("culture", "cicd", _graph.EDGE_CONSUMES, "skill-sources.md")
    g.add_node("afi-cli", _graph.NODE_REPO)
    g.add_edge("culture", "afi-cli", _graph.EDGE_DEPENDS_ON, "pyproject.toml")  # sibling
    g.add_node("pytest", _graph.NODE_PACKAGE)
    g.add_edge("culture", "pytest", _graph.EDGE_DEPENDS_ON, "pyproject.toml")  # package
    g.add_edge("culture", "afi-cli", _graph.EDGE_REFERENCES, "CLAUDE.md/README.md")  # refs out
    g.add_node("daria", _graph.NODE_REPO)
    g.add_edge("daria", "culture", _graph.EDGE_REFERENCES, "CLAUDE.md/README.md")  # refs in

    body = "\n".join(_graph._connectivity_lines(g))
    # full column headers (no abbreviations)
    assert "Skills supplied" in body and "References in" in body and "Packages" in body
    # steward: supplies 1, rest 0, no agents
    assert "| steward (—) | 1 | 0 | 0 | 0 | 0 | 0 | 0 |" in body
    # culture: supplied 0, consumed 1, channels 1, sibling 1, refs-in 1, refs-out 1, packages 1
    assert "| culture (culture) | 0 | 1 | 1 | 1 | 1 | 1 | 1 |" in body


def test_structural_subgraph_drops_packages_keeps_siblings():
    g = _graph.Graph()
    g.add_node("culture", _graph.NODE_REPO)
    g.add_node("afi-cli", _graph.NODE_REPO)
    g.add_node("pytest", _graph.NODE_PACKAGE)
    g.add_edge("culture", "afi-cli", _graph.EDGE_DEPENDS_ON, "pyproject.toml")  # sibling: keep
    g.add_edge("culture", "pytest", _graph.EDGE_DEPENDS_ON, "pyproject.toml")  # package: drop
    sub = _graph._structural_subgraph(g)
    assert "pytest" not in sub.nodes
    assert {"culture", "afi-cli"} <= set(sub.nodes)
    edges = {(e.source, e.target) for e in sub.edges}
    assert ("culture", "afi-cli") in edges
    assert ("culture", "pytest") not in edges


def _make_cli_repo(root: Path, name: str, binary: str, *, dist: str | None = None) -> Path:
    repo = root / name
    repo.mkdir()
    (repo / "pyproject.toml").write_text(
        f'[project]\nname = "{dist or name}"\n'
        f'[project.scripts]\n{binary} = "{name.replace("-", "_")}.cli:main"\n'
    )
    return repo


def _add_skill(repo: Path, skill: str, *, skill_md: str = "", script: str = "") -> None:
    sdir = repo / ".claude" / "skills" / skill
    sdir.mkdir(parents=True)
    if skill_md:
        (sdir / "SKILL.md").write_text(skill_md)
    if script:
        scripts = sdir / "scripts"
        scripts.mkdir()
        (scripts / "run.sh").write_text(script)


def test_add_cli_usage_emits_skill_and_repo_edges(tmp_path: Path):
    agex = _make_cli_repo(tmp_path, "agex-cli", "agex")
    steward = _make_cli_repo(tmp_path, "steward", "steward")
    _add_skill(steward, "cicd", script='#!/bin/bash\nexec agex pr lint "$@"\n')
    g = _graph.Graph()
    _graph.add_cli_usage(g, [agex, steward])
    edges = {(e.source, e.target, e.type, e.basis) for e in g.edges}
    assert ("cicd", "agex-cli", _graph.EDGE_USES, "SKILL.md/scripts") in edges
    assert ("steward", "agex-cli", _graph.EDGE_USES, "SKILL.md/scripts") in edges


def test_add_cli_usage_matches_backticked_skill_md(tmp_path: Path):
    agtag = _make_cli_repo(tmp_path, "agtag", "agtag")
    afi = _make_cli_repo(tmp_path, "afi-cli", "afi")
    _add_skill(afi, "communicate", skill_md="Issue I/O is backed by `agtag`.\n")
    g = _graph.Graph()
    _graph.add_cli_usage(g, [agtag, afi])
    edges = {(e.source, e.target, e.type) for e in g.edges}
    assert ("communicate", "agtag", _graph.EDGE_USES) in edges
    assert ("afi-cli", "agtag", _graph.EDGE_USES) in edges


def test_add_cli_usage_boundary_guard_no_false_positive(tmp_path: Path):
    agex = _make_cli_repo(tmp_path, "agex-cli", "agex")
    other = _make_cli_repo(tmp_path, "other", "other")
    # `agex-cli` and `myagex` must NOT match the bare `agex` binary.
    _add_skill(other, "doc", skill_md="See agex-cli docs and the myagex tool.\n")
    g = _graph.Graph()
    _graph.add_cli_usage(g, [agex, other])
    assert all(e.target != "agex-cli" for e in g.edges)


def test_add_cli_usage_boundary_guard_blocks_trailing_dot(tmp_path: Path):
    agex = _make_cli_repo(tmp_path, "agex-cli", "agex")
    other = _make_cli_repo(tmp_path, "other", "other")
    # `agex.sh` (binary followed by a dotted extension) must NOT match `agex`.
    _add_skill(other, "doc", script="run agex.sh now\n")
    g = _graph.Graph()
    _graph.add_cli_usage(g, [agex, other])
    assert all(e.target != "agex-cli" for e in g.edges)


def test_add_cli_usage_no_self_edge(tmp_path: Path):
    steward = _make_cli_repo(tmp_path, "steward", "steward")
    _add_skill(steward, "selfref", script="steward show .\n")
    g = _graph.Graph()
    _graph.add_cli_usage(g, [steward])
    assert g.edges == []


def test_add_cli_usage_no_skills_dir_is_noop(tmp_path: Path):
    agex = _make_cli_repo(tmp_path, "agex-cli", "agex")
    bare = _make_cli_repo(tmp_path, "bare", "bare")  # has pyproject, no .claude/skills/
    g = _graph.Graph()
    _graph.add_cli_usage(g, [agex, bare])
    assert g.edges == []


def test_read_skill_text_skips_undecodable_file(tmp_path: Path):
    skill = tmp_path / "skills" / "demo"
    (skill / "scripts").mkdir(parents=True)
    (skill / "SKILL.md").write_text("hello\n")
    # Non-UTF-8 bytes in a script file must be skipped, not raise.
    (skill / "scripts" / "blob.bin").write_bytes(b"\xff\xfe\x00\x01binarytext")
    text = _graph._read_skill_text(skill)
    assert "hello" in text  # SKILL.md still read; undecodable file skipped without error


def test_read_skill_text_skips_symlink_and_oversized(tmp_path: Path):
    skill = tmp_path / "skills" / "demo"
    (skill / "scripts").mkdir(parents=True)
    (skill / "SKILL.md").write_text("realcontent\n")
    # A symlink in scripts/ pointing outside the repo must not be followed/read.
    secret = tmp_path / "secret.txt"
    secret.write_text("SECRET_SHOULD_NOT_APPEAR\n")
    (skill / "scripts" / "link.sh").symlink_to(secret)
    # An oversized regular file is skipped (deterministic, no decode/stall).
    (skill / "scripts" / "big.sh").write_text("BIGMARKER" + "X" * _graph._MAX_SKILL_FILE_BYTES)
    text = _graph._read_skill_text(skill)
    assert "realcontent" in text
    assert "SECRET_SHOULD_NOT_APPEAR" not in text
    assert "BIGMARKER" not in text


_DOC_REGISTRY = """\
- id: afi-cli
  docs_mode: pull-reference
- id: agtag
  docs_mode: pull
- id: tipalti
  docs_mode: skip
"""


def test_add_doc_sources_emits_documents_edges_for_in_scope(tmp_path: Path):
    katvan = tmp_path / "katvan"
    afi = tmp_path / "afi-cli"
    agtag = tmp_path / "agtag"
    for d in (katvan, afi, agtag):
        d.mkdir()
    registry = katvan / "site" / "_data"
    registry.mkdir(parents=True)
    (registry / "agentculture_repos.yml").write_text(_DOC_REGISTRY)
    g = _graph.Graph()
    _graph.add_doc_sources(g, [katvan, afi, agtag])
    edges = {(e.source, e.target, e.type, e.basis) for e in g.edges}
    assert ("katvan", "afi-cli", _graph.EDGE_DOCUMENTS, "doc-source registry") in edges
    assert ("katvan", "agtag", _graph.EDGE_DOCUMENTS, "doc-source registry") in edges
    # `tipalti` is in the registry but not in scope -> dropped.
    assert all(e.target != "tipalti" for e in g.edges)


def test_add_doc_sources_no_registry_is_noop(tmp_path: Path):
    repo = tmp_path / "afi-cli"
    repo.mkdir()
    g = _graph.Graph()
    _graph.add_doc_sources(g, [repo])
    assert g.edges == []


def test_add_doc_sources_malformed_yaml_is_noop(tmp_path: Path):
    katvan = tmp_path / "katvan"
    afi = tmp_path / "afi-cli"
    for d in (katvan, afi):
        d.mkdir()
    reg = katvan / "site" / "_data"
    reg.mkdir(parents=True)
    # Invalid YAML (unclosed bracket).
    (reg / "agentculture_repos.yml").write_text("- id: [afi-cli\n")
    g = _graph.Graph()
    _graph.add_doc_sources(g, [katvan, afi])
    assert g.edges == []


def test_add_doc_sources_non_list_and_non_dict_entries_skipped(tmp_path: Path):
    katvan = tmp_path / "katvan"
    afi = tmp_path / "afi-cli"
    for d in (katvan, afi):
        d.mkdir()
    reg = katvan / "site" / "_data"
    reg.mkdir(parents=True)
    # A registry whose root is a mapping (not a list) -> skipped entirely.
    (reg / "agentculture_repos.yml").write_text("not: a-list\n")
    g = _graph.Graph()
    _graph.add_doc_sources(g, [katvan, afi])
    assert g.edges == []


def test_add_doc_sources_list_with_bare_and_idless_entries(tmp_path: Path):
    katvan = tmp_path / "katvan"
    afi = tmp_path / "afi-cli"
    for d in (katvan, afi):
        d.mkdir()
    reg = katvan / "site" / "_data"
    reg.mkdir(parents=True)
    # Bare string entry + dict entry with no `id` are both ignored;
    # the valid entry still produces its edge.
    (reg / "agentculture_repos.yml").write_text(
        "- just-a-string\n- docs_mode: pull\n- id: afi-cli\n  docs_mode: pull\n"
    )
    g = _graph.Graph()
    _graph.add_doc_sources(g, [katvan, afi])
    edges = {(e.source, e.target, e.type) for e in g.edges}
    assert edges == {("katvan", "afi-cli", _graph.EDGE_DOCUMENTS)}


def test_build_graph_runs_cli_and_doc_extractors(tmp_path: Path):
    agtag = _make_cli_repo(tmp_path, "agtag", "agtag")
    afi = _make_cli_repo(tmp_path, "afi-cli", "afi")
    _add_skill(afi, "communicate", skill_md="Backed by `agtag`.\n")
    reg = afi / "site" / "_data"
    reg.mkdir(parents=True)
    (reg / "agentculture_repos.yml").write_text("- id: agtag\n  docs_mode: pull\n")
    ledger = tmp_path / "skill-sources.md"
    ledger.write_text("| Skill | Upstream | Downstream |\n|---|---|---|\n")
    g = _graph.build_graph([], [agtag, afi], ledger)
    types = {(e.source, e.target, e.type) for e in g.edges}
    assert ("communicate", "agtag", _graph.EDGE_USES) in types
    assert ("afi-cli", "agtag", _graph.EDGE_DOCUMENTS) in types


def test_doc_coverage_gap_flags_undocumented_agent_repos():
    g = _graph.Graph()
    for repo in ("katvan", "afi-cli", "agtag", "reachy_nova"):
        g.add_node(repo, _graph.NODE_REPO)
        g.add_node(f"{repo}/{repo}", _graph.NODE_AGENT)
        g.add_edge(repo, f"{repo}/{repo}", _graph.EDGE_DECLARES, "culture.yaml")
    # katvan documents afi-cli + agtag, but not reachy_nova.
    g.add_edge("katvan", "afi-cli", _graph.EDGE_DOCUMENTS, "doc-source registry")
    g.add_edge("katvan", "agtag", _graph.EDGE_DOCUMENTS, "doc-source registry")
    signals = _graph.detect_signals(g, {})
    gaps = {s.subject for s in signals if s.kind == "doc-coverage-gap"}
    assert gaps == {"reachy_nova"}


def test_doc_coverage_gap_silent_without_doc_agent():
    g = _graph.Graph()
    g.add_node("afi-cli", _graph.NODE_REPO)
    g.add_node("afi-cli/afi-cli", _graph.NODE_AGENT)
    g.add_edge("afi-cli", "afi-cli/afi-cli", _graph.EDGE_DECLARES, "culture.yaml")
    signals = _graph.detect_signals(g, {})
    assert all(s.kind != "doc-coverage-gap" for s in signals)


def test_doc_coverage_gap_is_per_documenting_agent():
    # Two documentation agents; an undocumented repo yields one gap signal
    # PER doc agent (each detail names the agent), not a single merged signal.
    g = _graph.Graph()
    for repo in ("katvan", "otherdocs", "afi-cli", "reachy_nova"):
        g.add_node(repo, _graph.NODE_REPO)
        g.add_node(f"{repo}/{repo}", _graph.NODE_AGENT)
        g.add_edge(repo, f"{repo}/{repo}", _graph.EDGE_DECLARES, "culture.yaml")
    # Both doc agents document afi-cli; neither documents reachy_nova.
    g.add_edge("katvan", "afi-cli", _graph.EDGE_DOCUMENTS, "doc-source registry")
    g.add_edge("otherdocs", "afi-cli", _graph.EDGE_DOCUMENTS, "doc-source registry")
    gaps = [s for s in _graph.detect_signals(g, {}) if s.kind == "doc-coverage-gap"]
    # reachy_nova is undocumented by both -> one signal per doc agent.
    # katvan/otherdocs each also miss the *other* doc agent's repo.
    by_subject_doc = {(s.subject, s.detail) for s in gaps}
    assert ("reachy_nova", "declares an agent but is not documented by `katvan`") in by_subject_doc
    assert (
        "reachy_nova",
        "declares an agent but is not documented by `otherdocs`",
    ) in by_subject_doc
    # Per-agent granularity: reachy_nova is flagged exactly twice (once per doc agent).
    assert sum(1 for s in gaps if s.subject == "reachy_nova") == 2


def test_connectivity_table_counts_uses_and_documents():
    g = _graph.Graph()
    for repo in ("katvan", "afi-cli", "agtag"):
        g.add_node(repo, _graph.NODE_REPO)
    g.add_node("communicate", _graph.NODE_SKILL)
    # repo->repo uses (counted) + skill->repo uses (NOT counted in the table)
    g.add_edge("afi-cli", "agtag", _graph.EDGE_USES, "SKILL.md/scripts")
    g.add_edge("communicate", "agtag", _graph.EDGE_USES, "SKILL.md/scripts")
    g.add_edge("katvan", "afi-cli", _graph.EDGE_DOCUMENTS, "doc-source registry")
    lines = _graph._connectivity_lines(g)
    header = lines[0]
    assert "CLI uses" in header and "CLI used-by" in header and "Documents" in header
    # Separator integrity: 11 columns (12 pipes).
    assert lines[1].count("|") == 12
    rows = {ln.split("|")[1].strip(): ln for ln in lines[2:]}
    # agtag: used-by 1 (only the repo->repo edge, not the skill edge).
    # Repos with no declared agents have label "repo (—)" in the first column.
    assert rows["agtag (—)"].strip().endswith("| 0 | 1 | 0 |")
    # afi-cli: uses 1, used-by 0, documents 0.
    assert rows["afi-cli (—)"].strip().endswith("| 1 | 0 | 0 |")
    # katvan: documents 1.
    assert rows["katvan (—)"].strip().endswith("| 0 | 0 | 1 |")


def test_structural_subgraph_drops_repo_to_repo_uses_keeps_skill_to_repo():
    g = _graph.Graph()
    g.add_node("afi-cli", _graph.NODE_REPO)
    g.add_node("agtag", _graph.NODE_REPO)
    g.add_node("communicate", _graph.NODE_SKILL)
    g.add_edge("afi-cli", "agtag", _graph.EDGE_USES, "SKILL.md/scripts")  # dropped
    g.add_edge("communicate", "agtag", _graph.EDGE_USES, "SKILL.md/scripts")  # kept
    sub = _graph._structural_subgraph(g)
    pairs = {(e.source, e.target) for e in sub.edges if e.type == _graph.EDGE_USES}
    assert pairs == {("communicate", "agtag")}


def test_cli_usage_line_summarizes_repo_usage():
    g = _graph.Graph()
    for repo in ("afi-cli", "culture", "agtag", "agex-cli"):
        g.add_node(repo, _graph.NODE_REPO)
    g.add_edge("afi-cli", "agtag", _graph.EDGE_USES, "SKILL.md/scripts")
    g.add_edge("culture", "agtag", _graph.EDGE_USES, "SKILL.md/scripts")
    g.add_edge("culture", "agex-cli", _graph.EDGE_USES, "SKILL.md/scripts")
    line = _graph._cli_usage_line(g)
    assert "agtag ←2" in line and "agex-cli ←1" in line
    # Descending in-degree: the more-used CLI is listed first.
    assert line.index("agtag") < line.index("agex-cli")


def test_cli_usage_line_none():
    assert "none" in _graph._cli_usage_line(_graph.Graph())


def test_agents_md_reference_creates_edge(tmp_path):
    from steward.cli._commands import _graph

    (tmp_path / "codexd").mkdir()
    (tmp_path / "culture").mkdir()
    (tmp_path / "codexd" / "AGENTS.md").write_text("see `culture` for the mesh")
    g = _graph.Graph()
    _graph.add_cross_references(g, [tmp_path / "codexd", tmp_path / "culture"])
    assert any(e.type == _graph.EDGE_REFERENCES and e.source == "codexd" for e in g.edges)


def test_backend_signals_flag_dual_and_mismatch(tmp_path):
    from steward.cli._commands import _graph

    repo = tmp_path / "weird"
    repo.mkdir()
    (repo / "CLAUDE.md").write_text("x")
    (repo / "AGENTS.md").write_text("x")  # two prompts -> dual-agent
    g = _graph.Graph()
    g.add_node("weird", _graph.NODE_REPO, path=str(repo))
    g.add_node("weird/w", _graph.NODE_AGENT, suffix="w", backend="claude")
    g.add_edge("weird", "weird/w", _graph.EDGE_DECLARES, "culture.yaml")
    signals = _graph.detect_signals(g, {})
    kinds = {s.kind for s in signals}
    assert "dual-agent" in kinds


def test_backend_signals_flag_mismatch(tmp_path):
    from steward.cli._commands import _graph

    repo = tmp_path / "wrong"
    repo.mkdir()
    (repo / "AGENTS.md").write_text("x")  # claude declared but no CLAUDE.md -> mismatch
    g = _graph.Graph()
    g.add_node("wrong", _graph.NODE_REPO, path=str(repo))
    g.add_node("wrong/w", _graph.NODE_AGENT, suffix="w", backend="claude")
    g.add_edge("wrong", "wrong/w", _graph.EDGE_DECLARES, "culture.yaml")
    signals = _graph.detect_signals(g, {})
    kinds = {s.kind for s in signals}
    assert "backend-mismatch" in kinds


def test_render_markdown_has_all_sections():
    g = _graph.Graph()
    g.add_node("steward", _graph.NODE_REPO, path="/x")
    g.add_node(
        "steward/steward",
        _graph.NODE_AGENT,
        suffix="steward",
        backend="claude",
        has_system_prompt=False,
    )
    g.add_edge("steward", "steward/steward", _graph.EDGE_DECLARES, "culture.yaml")
    g.add_node("cicd", _graph.NODE_SKILL)
    g.add_edge("steward", "cicd", _graph.EDGE_SUPPLIES, "skill-sources.md")
    signals = [_graph.Signal("orphan-skill", "cicd", "no consumer")]
    md = _graph.render_markdown(
        g,
        signals,
        scope="siblings",
        generated="2026-05-21",
        title="AgentCulture ecosystem overview",
    )
    assert "# AgentCulture ecosystem overview" in md
    assert "## Inventory" in md
    assert "## Org connectivity (per repo / agent)" in md
    assert "## Org graph (structural edges)" in md
    assert "```mermaid" in md
    assert "## Candidate signals" in md
    assert "orphan skills (supplied, no consumer recorded): cicd" in md
    assert "## For the narrating agent" in md
    # the duplicated per-edge prose list is gone; legend carries provenance
    assert "--supplies-->" not in md
    assert "Provenance by edge type" in md
