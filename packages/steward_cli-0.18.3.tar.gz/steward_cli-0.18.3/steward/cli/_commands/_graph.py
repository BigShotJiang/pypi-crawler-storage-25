# steward/cli/_commands/_graph.py
"""Typed property graph for ``steward overview``.

Pure model + extractors + renderers — no argparse. The overview command
imports from here to assemble a deterministic "evidence pack": a typed
graph (repo/agent/skill/channel/package nodes; declares/supplies/consumes/
present_on/depends_on/references edges, each carrying provenance) plus
candidate signals. The agent that ran steward narrates the inferred
relationships and suggestions layers from this evidence.

Lives in its own module for the same reason ``_corpus.py`` does: it adds
enough logic that bundling it into ``overview.py`` would bury the
dispatcher, and the pieces are testable in isolation without argparse.
"""

from __future__ import annotations

import json
import re
import tomllib
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path

import yaml

from steward.cli._commands import _agents

# Node types.
NODE_REPO = "repo"
NODE_AGENT = "agent"
NODE_SKILL = "skill"
NODE_CHANNEL = "channel"
NODE_PACKAGE = "package"

# Edge types. All observed; each edge also carries a `basis` (provenance).
EDGE_DECLARES = "declares"  # repo -> agent
EDGE_SUPPLIES = "supplies"  # repo -> skill
EDGE_CONSUMES = "consumes"  # repo -> skill
EDGE_PRESENT_ON = "present_on"  # agent -> channel
EDGE_DEPENDS_ON = "depends_on"  # repo -> package, and repo -> repo
EDGE_REFERENCES = "references"  # repo -> repo
EDGE_USES = "uses"  # skill -> repo, and repo -> repo (sibling CLI invoked in skills)
EDGE_DOCUMENTS = "documents"  # repo -> repo (a docs-site agent's documented siblings)


@dataclass
class Node:
    id: str
    type: str
    props: dict = field(default_factory=dict)


@dataclass
class Edge:
    source: str
    target: str
    type: str
    basis: str


@dataclass
class Signal:
    kind: str
    subject: str
    detail: str


@dataclass
class Graph:
    nodes: dict[str, Node] = field(default_factory=dict)
    edges: list[Edge] = field(default_factory=list)
    _edge_keys: set = field(default_factory=set, compare=False, repr=False)

    def add_node(self, node_id: str, node_type: str, **props) -> Node:
        # Type is set at first registration; later add_node calls for the
        # same id only merge props (a node can't change kind mid-build).
        existing = self.nodes.get(node_id)
        if existing is None:
            self.nodes[node_id] = Node(id=node_id, type=node_type, props=dict(props))
        else:
            existing.props.update(props)
        return self.nodes[node_id]

    def add_edge(self, source: str, target: str, edge_type: str, basis: str) -> None:
        key = (source, target, edge_type)
        if key in self._edge_keys:
            return
        self._edge_keys.add(key)
        self.edges.append(Edge(source=source, target=target, type=edge_type, basis=basis))


def ego_graph(graph: Graph, center: str) -> Graph:
    """Focused single-repo view: ``center`` plus its directly-connected
    neighbors, keeping **only edges incident to ``center``**.

    This is deliberately *not* the induced subgraph. Because shared dev
    tooling (pytest, black, …) makes package nodes high-degree hubs, an
    induced 1-hop neighborhood would pull in unrelated neighbor-to-neighbor
    edges (e.g. another repo's dependency on a package ``center`` also uses).
    The ego graph drops that noise so ``overview <repo>`` stays about that
    repo. The center node is always present, even with no incident edges.
    """
    ego = Graph()
    center_node = graph.nodes.get(center)
    if center_node is not None:
        ego.add_node(center_node.id, center_node.type, **center_node.props)
    else:
        ego.add_node(center, NODE_REPO)
    for e in graph.edges:
        if e.source != center and e.target != center:
            continue
        for nid in (e.source, e.target):
            node = graph.nodes.get(nid)
            if node is not None:
                ego.add_node(node.id, node.type, **node.props)
        ego.add_edge(e.source, e.target, e.type, e.basis)
    return ego


def add_inventory(graph: Graph, agents) -> None:
    """Add repo/agent/channel nodes + declares/present_on edges from agents.

    ``agents`` is a list of :class:`steward.cli._commands._corpus.Agent`.
    """
    for a in agents:
        repo_id = a.repo_name
        graph.add_node(repo_id, NODE_REPO, path=str(a.repo_path))
        agent_id = f"{repo_id}/{a.suffix}"
        props: dict = {"suffix": a.suffix, "backend": a.backend}
        model = a.raw.get("model")
        if model:
            props["model"] = str(model)
        tags = a.raw.get("tags")
        if isinstance(tags, list):
            props["tags"] = [str(t) for t in tags]
        props["has_system_prompt"] = bool(a.raw.get("system_prompt"))
        profile = _agents.detect(a.repo_path, [a.backend])
        if profile.prompt_files:
            props["prompt"] = profile.prompt_files[0]
        if profile.owner:
            props["owner"] = profile.owner
        graph.add_node(agent_id, NODE_AGENT, **props)
        graph.add_edge(repo_id, agent_id, EDGE_DECLARES, "culture.yaml")
        channels = a.raw.get("channels")
        if isinstance(channels, list):
            for ch in channels:
                ch_id = str(ch)
                graph.add_node(ch_id, NODE_CHANNEL)
                graph.add_edge(agent_id, ch_id, EDGE_PRESENT_ON, "culture.yaml")


_BACKTICK_RE = re.compile(r"`([^`]+)`")


def _first_backtick(cell: str) -> str | None:
    m = _BACKTICK_RE.search(cell)
    return m.group(1).strip() if m else None


def _first_backtick_per_chunk(cell: str) -> list[str]:
    """First backticked token of each comma-separated chunk of a table cell.

    For column 1 this yields the skill name(s); for the downstream column
    it yields the consumer repo of each chunk (ignoring parenthetical
    notes that may carry their own backticks, e.g. ``(still named
    `pr-review`)``).
    """
    out: list[str] = []
    for chunk in cell.split(","):
        tok = _first_backtick(chunk)
        if tok:
            out.append(tok)
    return out


def parse_skill_ledger(text: str) -> list[tuple[str, str, list[str]]]:
    """Parse the markdown table in docs/skill-sources.md.

    Returns ``(skill, upstream_repo, [downstream_repos])`` per skill. The
    skill column may list several comma-separated skills sharing one
    upstream. Header and separator rows are skipped.
    """
    rows: list[tuple[str, str, list[str]]] = []
    for line in text.splitlines():
        line = line.strip()
        if not line.startswith("|"):
            continue
        cells = [c.strip() for c in line.strip("|").split("|")]
        if len(cells) < 3:
            continue
        if cells[0].lower() == "skill" or set(cells[0]) <= {"-", ":", " "}:
            continue
        skills = _first_backtick_per_chunk(cells[0])
        upstream = _first_backtick(cells[1])
        downstream = _first_backtick_per_chunk(cells[2])
        if not skills or not upstream:
            continue
        for skill in skills:
            # Copy downstream per skill so multi-skill rows don't share one
            # mutable list (keeps the output independent, per the signature).
            rows.append((skill, upstream, list(downstream)))
    return rows


def add_skill_ledger(graph: Graph, ledger_path: Path) -> None:
    """Add skill nodes + supplies/consumes edges from a skill-sources.md."""
    try:
        text = ledger_path.read_text()
    except OSError:
        return
    for skill, upstream, downstream in parse_skill_ledger(text):
        graph.add_node(skill, NODE_SKILL)
        graph.add_node(upstream, NODE_REPO)
        graph.add_edge(upstream, skill, EDGE_SUPPLIES, "skill-sources.md")
        for repo in downstream:
            graph.add_node(repo, NODE_REPO)
            graph.add_edge(repo, skill, EDGE_CONSUMES, "skill-sources.md")


_DEP_NAME_RE = re.compile(r"^([A-Za-z0-9._-]+)")

# unowned-skill detail format: "present in `<repo>/.claude/skills/` but ...".
# The repo is recovered for display; the structured form stays in --json.
_UNOWNED_REPO_RE = re.compile(r"present in `([^/`]+)/")

# Filename read for dependency discovery, and the provenance basis stamped on
# the depends_on edges it produces (same string, single-sourced).
_PYPROJECT = "pyproject.toml"


def _normalize_pkg(name: str) -> str:
    # PEP 503 canonical form: collapse runs of -_. to a single - and lowercase,
    # so a dep `zope.interface` matches a sibling dist `zope-interface`.
    return re.sub(r"[-_.]+", "-", name.strip()).lower()


def _dep_name(spec: str) -> str | None:
    m = _DEP_NAME_RE.match(spec.strip())
    return _normalize_pkg(m.group(1)) if m else None


def _load_pyproject(pyproject: Path) -> dict | None:
    try:
        return tomllib.loads(pyproject.read_text())
    except (OSError, tomllib.TOMLDecodeError, UnicodeDecodeError):
        return None


def _project_name(data: dict) -> str | None:
    name = (data.get("project") or {}).get("name")
    return _normalize_pkg(str(name)) if name else None


def _dependency_specs(data: dict) -> list[str]:
    specs: list[str] = []
    project = data.get("project") or {}
    specs.extend(project.get("dependencies") or [])
    for group in (project.get("optional-dependencies") or {}).values():
        specs.extend(group or [])
    for group in (data.get("dependency-groups") or {}).values():
        specs.extend(item for item in (group or []) if isinstance(item, str))
    return specs


def _index_pyprojects(repo_paths) -> tuple[dict[str, dict], dict[str, str]]:
    """Return ``(parsed_by_repo_name, dist_name_to_repo_name)``.

    Skips repos without a readable pyproject.toml. The second map lets a
    dependency be recognised as a sibling when its distribution name matches
    a repo's published ``[project].name``.
    """
    parsed: dict[str, dict] = {}
    name_to_repo: dict[str, str] = {}
    for repo in repo_paths:
        data = _load_pyproject(repo / _PYPROJECT)
        if data is None:
            continue
        parsed[repo.name] = data
        pname = _project_name(data)
        if pname:
            name_to_repo[pname] = repo.name
    return parsed, name_to_repo


def _index_cli_binaries(parsed_by_repo: dict[str, dict]) -> dict[str, str]:
    """Map console-script binary name -> owning repo, resolving collisions.

    Built from each repo's ``[project.scripts]`` keys, so the CLI list is
    self-maintaining (no hardcoded names). A binary that maps to more than
    one repo is kept only when exactly one candidate repo's dir name or
    normalized dist name equals the binary; otherwise it is dropped rather
    than guessed (e.g. ``kata`` -> {antoine, seer-cli} is ambiguous).
    """
    candidates: dict[str, set[str]] = {}
    dist_of: dict[str, str | None] = {}
    for repo, data in parsed_by_repo.items():
        dist_of[repo] = _project_name(data)
        scripts = (data.get("project") or {}).get("scripts") or {}
        for binary in scripts:
            candidates.setdefault(binary, set()).add(repo)
    out: dict[str, str] = {}
    for binary, repos in candidates.items():
        if len(repos) == 1:
            out[binary] = next(iter(repos))
            continue
        nb = _normalize_pkg(binary)
        matches = [r for r in repos if _normalize_pkg(r) == nb or dist_of.get(r) == nb]
        if len(matches) == 1:
            out[binary] = matches[0]
    return out


# Per-file read cap for skill scanning. A real SKILL.md / script is tiny; a
# file larger than this is pathological, so skip it rather than decode it
# (avoids stalling graph construction on a huge or device-backed file).
_MAX_SKILL_FILE_BYTES = 1_000_000


def _read_text_capped(f: Path) -> str | None:
    """Read a regular, reasonably-sized UTF-8 file, else ``None``.

    Skips symlinks (a symlinked entry could point outside the scanned repo)
    and files over ``_MAX_SKILL_FILE_BYTES``, and treats unreadable /
    undecodable files as absent. The skip is deterministic.
    """
    if f.is_symlink():
        return None
    try:
        if f.stat().st_size > _MAX_SKILL_FILE_BYTES:
            return None
        return f.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return None


def _read_skill_text(skill_dir: Path) -> str:
    """Concatenated SKILL.md + every readable file under scripts/ (sorted).

    Symlinked and oversized files are skipped deterministically (see
    ``_read_text_capped``) so scanning a skill can't follow a symlink out of
    the repo or stall decoding a pathological file.
    """
    parts: list[str] = []
    skill_md = skill_dir / "SKILL.md"
    if skill_md.is_file():
        text = _read_text_capped(skill_md)
        if text is not None:
            parts.append(text)
    scripts_dir = skill_dir / "scripts"
    if scripts_dir.is_dir():
        for f in sorted(scripts_dir.rglob("*")):
            if f.is_file():
                text = _read_text_capped(f)
                if text is not None:
                    parts.append(text)
    return "\n".join(parts)


def _binary_pattern(binary: str) -> re.Pattern:
    """Whole-token match for a CLI binary: not inside a longer word or path,
    so `agex` matches `agex pr` but not `agex-cli`, `/usr/bin/agex`, `myagex`,
    or `agex.sh` (trailing dot also rejected)."""
    return re.compile(r"(?<![\w./-])" + re.escape(binary) + r"(?![\w.-])")


def _emit_skill_cli_edges(
    graph: Graph,
    repo_name: str,
    skill_name: str,
    text: str,
    bin_to_repo: dict[str, str],
    patterns: dict[str, re.Pattern],
) -> None:
    """Emit skill->repo + repo->repo ``uses`` edges for one skill's text.

    For each sibling binary whose pattern appears in ``text`` (and which the
    repo doesn't itself own), add the attribution edge (skill -> CLI repo) and
    the breadth edge (this repo -> CLI repo). Basis: ``SKILL.md/scripts``.
    """
    for binary, pat in patterns.items():
        target = bin_to_repo[binary]
        if target == repo_name or not pat.search(text):
            continue
        graph.add_node(target, NODE_REPO)
        graph.add_node(skill_name, NODE_SKILL)
        graph.add_edge(skill_name, target, EDGE_USES, "SKILL.md/scripts")
        graph.add_edge(repo_name, target, EDGE_USES, "SKILL.md/scripts")


def add_cli_usage(graph: Graph, repo_paths) -> None:
    """Add ``uses`` edges where a repo's skills invoke a sibling's CLI binary.

    Scans each repo's ``.claude/skills/*/SKILL.md`` + ``scripts/`` for the
    console-script binaries declared by sibling pyproject ``[project.scripts]``
    tables. Emits both a skill -> repo edge (attribution) and a repo -> repo
    edge (breadth) per detected (skill, binary). A repo's own binaries are
    skipped (no self-edge). Basis: ``SKILL.md/scripts``.
    """
    repo_paths = list(repo_paths)
    parsed, _ = _index_pyprojects(repo_paths)
    bin_to_repo = _index_cli_binaries(parsed)
    patterns = {b: _binary_pattern(b) for b in bin_to_repo}
    for repo in repo_paths:
        skills_dir = repo / ".claude" / "skills"
        if not skills_dir.is_dir():
            continue
        for skill_dir in sorted(p for p in skills_dir.iterdir() if p.is_dir()):
            text = _read_skill_text(skill_dir)
            if text:
                _emit_skill_cli_edges(graph, repo.name, skill_dir.name, text, bin_to_repo, patterns)


def _add_dependency_edge(
    graph: Graph, repo_name: str, dep: str, name_to_repo: dict[str, str]
) -> None:
    """Add the one depends_on edge a single dependency warrants.

    Sibling dep → repo→repo edge; external dep → package node + repo→package
    edge; a dep on the repo's own dist → nothing (no self-edge).
    """
    sibling = name_to_repo.get(dep)
    if sibling is None:
        graph.add_node(dep, NODE_PACKAGE)
        graph.add_edge(repo_name, dep, EDGE_DEPENDS_ON, _PYPROJECT)
    elif sibling != repo_name:
        graph.add_node(sibling, NODE_REPO)
        graph.add_edge(repo_name, sibling, EDGE_DEPENDS_ON, _PYPROJECT)


def add_dependencies(graph: Graph, repo_paths) -> None:
    """Add depends_on edges from each repo's pyproject.toml.

    ``repo_paths`` is an iterable of sibling repo dirs. A first pass maps
    each repo's published distribution name to its dir name. A dependency
    is then classified as exactly one of:

    * **sibling** (the dist name resolves to another repo dir) → a
      repo → repo ``depends_on`` edge, no package node;
    * **external** → a `package` node + a repo → package ``depends_on`` edge.

    Keeping the two disjoint avoids the repo/package id collision that
    arose when a sibling's dist name equals its dir name (e.g. repo
    ``agtag`` publishing dist ``agtag``): a sibling repo is represented by
    its repo node, never a duplicate package node. A dependency on the
    repo's own dist is dropped (no self-edge). Repos without a
    pyproject.toml (e.g. Jekyll sites) are skipped.
    """
    repo_paths = list(repo_paths)
    parsed, name_to_repo = _index_pyprojects(repo_paths)
    for repo in repo_paths:
        data = parsed.get(repo.name)
        if data is None:
            continue
        for spec in _dependency_specs(data):
            dep = _dep_name(spec)
            if dep:
                _add_dependency_edge(graph, repo.name, dep, name_to_repo)


def _ref_patterns(name: str) -> list[re.Pattern]:
    """Compiled patterns matching low-false-positive references to ``name``."""
    esc = re.escape(name)
    return [
        re.compile(rf"\.\./{esc}(?![\w-])"),  # ../name (sibling-relative path)
        re.compile(rf"agentculture/{esc}(?![\w-])"),  # agentculture/name (GH slug)
        re.compile(rf"`{esc}`"),  # `name` (backticked identifier)
    ]


def _read_repo_docs(repo: Path) -> str:
    """Concatenated prompt file(s) + README.md text for a repo.

    Presence-based: reads whichever of the recognized prompt files exist
    (CLAUDE.md / AGENTS.md / GEMINI.md) plus README.md, so cross-repo
    references written in a non-Claude prompt are not missed.
    """
    text = ""
    for fname in ("CLAUDE.md", "AGENTS.md", "GEMINI.md", "README.md"):
        f = repo / fname
        if f.is_file():
            try:
                text += "\n" + f.read_text(encoding="utf-8")
            except (OSError, UnicodeDecodeError):
                continue
    return text


def add_cross_references(graph: Graph, repo_paths) -> None:
    """Add references edges where one repo names another sibling.

    Only low-false-positive forms count (``../name``, ``agentculture/name``,
    `` `name` ``) so the common-word case (e.g. "culture" in prose) does
    not create spurious edges. Scans the detected prompt file(s)
    (CLAUDE.md / AGENTS.md / GEMINI.md) + README.md.
    """
    repo_paths = list(repo_paths)
    names = {p.name for p in repo_paths}
    for repo in repo_paths:
        text = _read_repo_docs(repo)
        if not text:
            continue
        for other in sorted(names):
            if other != repo.name and any(pat.search(text) for pat in _ref_patterns(other)):
                graph.add_node(other, NODE_REPO)
                graph.add_edge(repo.name, other, EDGE_REFERENCES, "prompt/README.md")


# A docs-site agent declares the siblings it documents in this registry
# (relative to the repo root). Today only katvan ships it.
_DOC_REGISTRY_REL = Path("site") / "_data" / "agentculture_repos.yml"


def _load_doc_registry(registry: Path) -> list | None:
    """Parse a doc-source registry file to a list, else ``None``.

    Returns ``None`` when the file is absent, unreadable, malformed YAML, or
    not a top-level list — so the caller can treat every "no usable registry"
    case uniformly.
    """
    if not registry.is_file():
        return None
    try:
        data = yaml.safe_load(registry.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, yaml.YAMLError):
        return None
    return data if isinstance(data, list) else None


def _emit_doc_edges(graph: Graph, repo_name: str, entries: list, names: set[str]) -> None:
    """Emit ``documents`` edges for each registry entry naming an in-scope sibling.

    Non-dict entries and entries without a string ``id`` are skipped; the id
    must be in ``names`` (the corpus) and not the documenting repo itself.
    """
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        doc_id = entry.get("id")
        if isinstance(doc_id, str) and doc_id in names and doc_id != repo_name:
            graph.add_node(doc_id, NODE_REPO)
            graph.add_edge(repo_name, doc_id, EDGE_DOCUMENTS, "doc-source registry")


def add_doc_sources(graph: Graph, repo_paths) -> None:
    """Add ``documents`` edges from a docs-site agent's source registry.

    For any repo carrying a ``site/_data/agentculture_repos.yml`` registry,
    emit a repo -> repo ``documents`` edge for each registry entry whose
    ``id`` is an in-scope sibling (intersected with the corpus, like
    ``add_cross_references``, so out-of-scope entries are dropped).
    ``docs_mode`` is not filtered on. Basis: ``doc-source registry``.
    """
    repo_paths = list(repo_paths)
    names = {p.name for p in repo_paths}
    for repo in repo_paths:
        entries = _load_doc_registry(repo / _DOC_REGISTRY_REL)
        if entries is not None:
            _emit_doc_edges(graph, repo.name, entries, names)


def collect_repo_skill_dirs(repo_paths) -> dict[str, set[str]]:
    """Map repo dir name -> set of skill dir names under .claude/skills/."""
    out: dict[str, set[str]] = {}
    for repo in repo_paths:
        skills_dir = repo / ".claude" / "skills"
        if not skills_dir.is_dir():
            continue
        names = {p.name for p in skills_dir.iterdir() if p.is_dir()}
        if names:
            out[repo.name] = names
    return out


def build_graph(agents, repo_paths, ledger_path: Path) -> Graph:
    """Assemble the full evidence graph from all six extractors."""
    graph = Graph()
    add_inventory(graph, agents)
    add_skill_ledger(graph, ledger_path)
    add_dependencies(graph, repo_paths)
    add_cross_references(graph, repo_paths)
    add_cli_usage(graph, repo_paths)
    add_doc_sources(graph, repo_paths)
    return graph


def _supply_index(graph: Graph) -> tuple[dict[str, str], dict[str, set[str]]]:
    """Return ``(supplier_of_skill, consumers_of_skill)`` from ledger edges.

    First supplier wins (the ledger has one upstream per skill); consumers
    accumulate.
    """
    supplier_of: dict[str, str] = {}
    consumers: dict[str, set[str]] = {}
    for e in graph.edges:
        if e.type == EDGE_SUPPLIES:
            supplier_of.setdefault(e.target, e.source)
        elif e.type == EDGE_CONSUMES:
            consumers.setdefault(e.target, set()).add(e.source)
    return supplier_of, consumers


def _orphan_skill_signals(
    supplier_of: dict[str, str], consumers: dict[str, set[str]]
) -> list[Signal]:
    """Skills that are supplied but have no recorded downstream consumer."""
    return [
        Signal(
            "orphan-skill",
            skill,
            f"supplied by `{supplier_of[skill]}` but no downstream consumer recorded",
        )
        for skill in sorted(set(supplier_of) - set(consumers))
    ]


def _ownership_signals(
    repo_skill_dirs: dict[str, set[str]],
    supplier_of: dict[str, str],
    consumers: dict[str, set[str]],
) -> list[Signal]:
    """ledger-gap (vendored but not recorded as a consumer) + unowned-skill
    (on disk with no ledger upstream), derived from on-disk skill dirs."""
    supplied = set(supplier_of)
    out: list[Signal] = []
    unowned: dict[str, str] = {}
    for repo in sorted(repo_skill_dirs):
        for skill in sorted(repo_skill_dirs[repo]):
            if skill not in supplied:
                # First alphabetical repo wins; the signal is per-skill, not
                # per-repo-instance (a skill is unowned regardless of how many
                # repos happen to vendor it).
                unowned.setdefault(skill, repo)
                continue
            upstream = supplier_of[skill]
            if upstream != repo and repo not in consumers.get(skill, set()):
                out.append(
                    Signal(
                        "ledger-gap",
                        f"{repo}/{skill}",
                        f"`{repo}` vendors `{skill}` (upstream `{upstream}`) but the "
                        "ledger downstream column omits it",
                    )
                )
    out.extend(
        Signal(
            "unowned-skill",
            skill,
            f"present in `{repo}/.claude/skills/` but no upstream recorded in the ledger",
        )
        for skill, repo in sorted(unowned.items())
    )
    return out


def _over_connected_signals(graph: Graph, threshold: int) -> list[Signal]:
    """Agents present on more than ``threshold`` channels."""
    present_count: dict[str, int] = {}
    for e in graph.edges:
        if e.type == EDGE_PRESENT_ON:
            present_count[e.source] = present_count.get(e.source, 0) + 1
    return [
        Signal("over-connected-agent", agent, f"present on {n} channels (> {threshold})")
        for agent, n in sorted(present_count.items())
        if n > threshold
    ]


def _isolated_repo_signals(graph: Graph) -> list[Signal]:
    """Repos whose only incident edges are ``declares`` (no mesh wiring)."""
    out: list[Signal] = []
    for repo in sorted(node.id for node in graph.nodes.values() if node.type == NODE_REPO):
        incident = [e for e in graph.edges if e.source == repo or e.target == repo]
        non_declare = [e for e in incident if e.type != EDGE_DECLARES]
        if incident and not non_declare:
            out.append(
                Signal(
                    "isolated-repo",
                    repo,
                    "declares agents but has no skill/dependency/reference edges",
                )
            )
    return out


def _overlap_signals(graph: Graph) -> list[Signal]:
    """Pairs of agents sharing two or more tags."""
    agents = [n for n in sorted(graph.nodes.values(), key=lambda x: x.id) if n.type == NODE_AGENT]
    out: list[Signal] = []
    for i in range(len(agents)):
        for j in range(i + 1, len(agents)):
            shared = set(agents[i].props.get("tags") or []) & set(agents[j].props.get("tags") or [])
            if len(shared) >= 2:
                out.append(
                    Signal(
                        "overlap",
                        f"{agents[i].id} ~ {agents[j].id}",
                        f"share tags: {', '.join(sorted(shared))}",
                    )
                )
    return out


def _doc_coverage_gap_signals(graph: Graph) -> list[Signal]:
    """In-scope agent repos a documentation agent does not document.

    Active only when at least one ``documents`` edge exists. "In scope" =
    repos that declare an agent (excludes ledger-only nodes like a pure
    skill supplier). A documenting repo never flags itself.
    """
    documented: dict[str, set[str]] = {}
    for e in graph.edges:
        if e.type == EDGE_DOCUMENTS:
            documented.setdefault(e.source, set()).add(e.target)
    if not documented:
        return []
    declaring = {e.source for e in graph.edges if e.type == EDGE_DECLARES}
    out: list[Signal] = []
    for doc_repo in sorted(documented):
        for repo in sorted(declaring - documented[doc_repo] - {doc_repo}):
            out.append(
                Signal(
                    "doc-coverage-gap",
                    repo,
                    f"declares an agent but is not documented by `{doc_repo}`",
                )
            )
    return out


def _backend_signals(graph: Graph) -> list[Signal]:
    """Flag dual-agent repos and declared-vs-observed backend mismatches.

    Flags, not conclusions — consistent with the other signal helpers.
    """
    out: list[Signal] = []
    for repo in sorted(
        (n for n in graph.nodes.values() if n.type == NODE_REPO), key=lambda n: n.id
    ):
        path = repo.props.get("path")
        if not path:
            continue
        backends = [
            n.props.get("backend", "")
            for n in graph.nodes.values()
            if n.type == NODE_AGENT and n.id.startswith(f"{repo.id}/")
        ]
        profile = _agents.detect(Path(path), backends)
        if profile.dual_agent:
            out.append(
                Signal(
                    "dual-agent",
                    repo.id,
                    f"multiple prompt files present: {profile.prompt_files}",
                )
            )
        if profile.mismatch:
            out.append(Signal("backend-mismatch", repo.id, profile.mismatch_reason or ""))
    return out


def detect_signals(
    graph: Graph,
    repo_skill_dirs: dict[str, set[str]],
    *,
    over_connected_threshold: int = 5,
) -> list[Signal]:
    """Compute deterministic candidate signals (flags, not conclusions).

    Each signal kind is a focused helper; this orchestrator just concatenates
    them in a stable order. All helpers iterate sorted inputs, so the output
    is deterministic.
    """
    supplier_of, consumers = _supply_index(graph)
    return [
        *_orphan_skill_signals(supplier_of, consumers),
        *_ownership_signals(repo_skill_dirs, supplier_of, consumers),
        *_over_connected_signals(graph, over_connected_threshold),
        *_isolated_repo_signals(graph),
        *_overlap_signals(graph),
        *_doc_coverage_gap_signals(graph),
        *_backend_signals(graph),
    ]


def _sorted_nodes(graph: Graph) -> list[Node]:
    return sorted(graph.nodes.values(), key=lambda n: (n.type, n.id))


def _sorted_edges(graph: Graph) -> list[Edge]:
    return sorted(graph.edges, key=lambda e: (e.type, e.source, e.target))


def _node_type(graph: Graph, node_id: str) -> str | None:
    node = graph.nodes.get(node_id)
    return node.type if node else None


def _is_repo_to_repo(graph: Graph, e: Edge) -> bool:
    """True when both endpoints of ``e`` are repo nodes (not skill/package)."""
    return _node_type(graph, e.source) == NODE_REPO and _node_type(graph, e.target) == NODE_REPO


def _structural_subgraph(graph: Graph) -> Graph:
    """Graph minus two categories of noisy edges — for the structural mermaid.

    The markdown mermaid shows org structure only; two edge categories are
    dropped and summarized in prose instead:

    * repo->package ``depends_on`` edges (dev-tooling bulk) — summarized by
      ``_dependency_spine_line``; full edges kept in ``--json``.
    * repo->repo ``uses`` edges (CLI invocations between siblings) — summarized
      by ``_cli_usage_line``; full edges kept in ``--json``.

    Both are kept in full in ``--json``.

    Edges that survive (both endpoints / the source make them structural):

    * sibling repo->repo ``depends_on`` edges (both endpoints are repos, not
      packages).
    * skill->repo ``uses`` edges (the source is a skill node, not a repo —
      these attribute which skill invokes the CLI and appear in the diagram).
    """
    sub = Graph()
    for node in graph.nodes.values():
        if node.type == NODE_PACKAGE:
            continue
        sub.add_node(node.id, node.type, **node.props)
    for e in graph.edges:
        if _node_type(graph, e.source) == NODE_PACKAGE:
            continue
        if _node_type(graph, e.target) == NODE_PACKAGE:
            continue
        if e.type == EDGE_USES and _is_repo_to_repo(graph, e):
            continue
        sub.add_edge(e.source, e.target, e.type, e.basis)
    return sub


# Per-repo degree counters accumulated for the connectivity table (channels and
# declared agents are tracked separately as sets/lists).
_CONNECTIVITY_COUNTERS = (
    "supplied",
    "consumed",
    "sib",
    "pkg",
    "refs_in",
    "refs_out",
    "uses_out",
    "uses_in",
    "documents_out",
)


def _bump(stat: dict[str, dict], repo: str, key: str) -> None:
    """Increment a counter, ignoring endpoints that aren't in-scope repos."""
    if repo in stat:
        stat[repo][key] += 1


def _tally_edge(
    graph: Graph, e: Edge, stat: dict[str, dict], repo_of_agent: dict[str, str]
) -> None:
    """Fold one edge into the per-repo connectivity counters (dispatch by type)."""
    if e.type == EDGE_SUPPLIES:
        _bump(stat, e.source, "supplied")
    elif e.type == EDGE_CONSUMES:
        _bump(stat, e.source, "consumed")
    elif e.type == EDGE_REFERENCES:
        _bump(stat, e.source, "refs_out")
        _bump(stat, e.target, "refs_in")
    elif e.type == EDGE_DEPENDS_ON:
        _bump(stat, e.source, "sib" if _node_type(graph, e.target) == NODE_REPO else "pkg")
    elif e.type == EDGE_PRESENT_ON:
        repo = repo_of_agent.get(e.source)
        if repo is not None:
            stat[repo]["channels"].add(e.target)
    elif e.type == EDGE_USES:
        # Count repo->repo usage only; skill->repo edges are structural
        # (shown in the mermaid), so they don't inflate per-repo counts.
        if _is_repo_to_repo(graph, e):
            _bump(stat, e.source, "uses_out")
            _bump(stat, e.target, "uses_in")
    elif e.type == EDGE_DOCUMENTS and _node_type(graph, e.source) == NODE_REPO:
        _bump(stat, e.source, "documents_out")


def _connectivity_stats(graph: Graph) -> dict[str, dict]:
    """Per-repo edge counts + declared agents + channel set, in a single pass."""
    stat: dict[str, dict] = {
        n.id: {**dict.fromkeys(_CONNECTIVITY_COUNTERS, 0), "agents": [], "channels": set()}
        for n in graph.nodes.values()
        if n.type == NODE_REPO
    }
    repo_of_agent: dict[str, str] = {}
    for e in graph.edges:
        if e.type == EDGE_DECLARES and e.source in stat:
            stat[e.source]["agents"].append(e.target)
            repo_of_agent[e.target] = e.source
    for e in graph.edges:
        _tally_edge(graph, e, stat, repo_of_agent)
    return stat


def _repo_label(repo: str, agents: list[str]) -> str:
    """`repo (suffix, suffix)` — or `repo (—)` for a repo that declares no agent."""
    suffixes = [a.split("/", 1)[1] if "/" in a else a for a in sorted(agents)]
    return f"{repo} ({', '.join(suffixes)})" if suffixes else f"{repo} (—)"


def _connectivity_lines(graph: Graph) -> list[str]:
    """The org graph as per-repo statistics: degree broken down by edge type.

    One row per repo (with the agent suffixes it declares noted), so supplier
    repos that declare no agent and multi-agent repos are both represented.
    All values are observed counts — the narrating agent does the inferring.
    """
    stat = _connectivity_stats(graph)
    if not stat:
        return ["_No repos in scope._"]
    header = (
        "| Repo (agents) | Skills supplied | Skills consumed | Channels "
        "| Sibling deps | References in | References out | Packages "
        "| CLI uses | CLI used-by | Documents |"
    )
    lines = [header, "|---|---|---|---|---|---|---|---|---|---|---|"]
    for repo in sorted(stat):
        s = stat[repo]
        label = _md_cell(_repo_label(repo, s["agents"]))
        lines.append(
            f"| {label} | {s['supplied']} | {s['consumed']} | {len(s['channels'])} "
            f"| {s['sib']} | {s['refs_in']} | {s['refs_out']} | {s['pkg']} "
            f"| {s['uses_out']} | {s['uses_in']} | {s['documents_out']} |"
        )
    return lines


def _dependency_spine_line(graph: Graph) -> str:
    """One-line summary of repo->package dependency edges (dropped from the graph).

    A package depended on by >= half the repos that declare any package
    dependency is "spine" (listed); the rest are reported as a count. With a
    single such repo (e.g. --scope self) the spine notion is degenerate, so
    just report that repo's package count. Full edges remain in --json.
    """
    pkg_consumers: dict[str, set[str]] = {}  # package -> repos depending on it
    repos_with_pkgs: set[str] = set()
    for e in graph.edges:
        if e.type == EDGE_DEPENDS_ON and _node_type(graph, e.target) == NODE_PACKAGE:
            pkg_consumers.setdefault(e.target, set()).add(e.source)
            repos_with_pkgs.add(e.source)
    if not pkg_consumers:
        return "Dependency spine: none (no package dependencies in scope)."
    if len(repos_with_pkgs) <= 1:
        only = next(iter(repos_with_pkgs))
        return (
            f"Dependency spine: {only} depends on {len(pkg_consumers)} external "
            "packages (full edges in --json)."
        )
    threshold = (len(repos_with_pkgs) + 1) // 2  # ceil(n / 2)
    spine = sorted(p for p, repos in pkg_consumers.items() if len(repos) >= threshold)
    rest = len(pkg_consumers) - len(spine)
    spine_str = ", ".join(spine) if spine else "none"
    return (
        f"Dependency spine: {len(repos_with_pkgs)} repos; shared (≥{threshold} repos): "
        f"{spine_str}; {rest} further distinct external packages. "
        "Full package edges in --json."
    )


def _cli_usage_line(graph: Graph) -> str:
    """One-line summary of repo->CLI usage (the edges dropped from the mermaid).

    Mirrors `_dependency_spine_line`: the diagram stays lean, the breadth is
    reported here, and full edges remain in --json. Sorted by descending
    in-degree then name.
    """
    used_by: dict[str, set[str]] = {}
    for e in graph.edges:
        if e.type == EDGE_USES and _is_repo_to_repo(graph, e):
            used_by.setdefault(e.target, set()).add(e.source)
    if not used_by:
        return "CLI usage: none (no sibling-CLI invocations in scope)."
    parts = ", ".join(
        f"{cli} ←{len(repos)}"
        for cli, repos in sorted(used_by.items(), key=lambda kv: (-len(kv[1]), kv[0]))
    )
    return f"CLI usage (repo→CLI, summarized from the graph): {parts}. Full edges in --json."


def _provenance_legend() -> str:
    """Every edge's basis is a pure function of its type (see the extractors),
    so one legend conveys what a per-edge basis column would repeat for every edge.
    """
    return (
        "Provenance by edge type: declares, present_on ← culture.yaml · "
        "supplies, consumes ← skill-sources.md · depends_on ← pyproject.toml · "
        "references ← prompt(CLAUDE/AGENTS/GEMINI)/README.md · uses ← SKILL.md/scripts · "
        "documents ← doc-source registry"
    )


def to_json(
    graph: Graph,
    signals: list[Signal],
    *,
    scope: str,
    generated: str,
    warnings: list[str] | None = None,
) -> str:
    """Serialize the graph + signals to a script-parseable (neo4j-loadable) JSON.

    ``warnings`` (e.g. unparseable culture.yaml manifests) is included as a
    top-level ``"warnings"`` array only when non-empty, so a script reading
    stdout learns about repos that dropped out of the graph.
    """
    payload = {
        "scope": scope,
        "generated": generated,
        "nodes": [{"id": n.id, "type": n.type, "props": n.props} for n in _sorted_nodes(graph)],
        "edges": [
            {"source": e.source, "target": e.target, "type": e.type, "basis": e.basis}
            for e in _sorted_edges(graph)
        ],
        "signals": [{"kind": s.kind, "subject": s.subject, "detail": s.detail} for s in signals],
    }
    if warnings:
        payload["warnings"] = warnings
    return json.dumps(payload, indent=2)


_MERMAID_CLASSDEFS = {
    NODE_REPO: "fill:#cde,stroke:#369,color:#000",
    NODE_AGENT: "fill:#dfd,stroke:#393,color:#000",
    NODE_SKILL: "fill:#ffd,stroke:#aa3,color:#000",
    NODE_CHANNEL: "fill:#fde,stroke:#a39,color:#000",
    NODE_PACKAGE: "fill:#eee,stroke:#999,color:#000",
}


def _mermaid_id(node_id: str) -> str:
    return "n_" + re.sub(r"[^A-Za-z0-9]", "_", node_id)


def _md_cell(value: str) -> str:
    """Escape a value for a markdown table cell (a literal | splits columns)."""
    return value.replace("|", "\\|")


def to_mermaid(graph: Graph) -> str:
    lines = ["```mermaid", "graph LR"]
    for node_type, style in _MERMAID_CLASSDEFS.items():
        lines.append(f"  classDef {node_type} {style};")
    for n in _sorted_nodes(graph):
        label = n.id.replace('"', "'")
        lines.append(f'  {_mermaid_id(n.id)}["{label}"]:::{n.type}')
    for e in _sorted_edges(graph):
        # e.type is always an EDGE_* constant (no `|`); escape it if that ever changes.
        lines.append(f"  {_mermaid_id(e.source)} -->|{e.type}| {_mermaid_id(e.target)}")
    lines.append("```")
    return "\n".join(lines)


def _agent_channels(graph: Graph, agent_id: str) -> list[str]:
    return sorted(
        e.target for e in graph.edges if e.source == agent_id and e.type == EDGE_PRESENT_ON
    )


# Inventory attribute columns, defined once: (name, always_shown, backticked).
# Optional columns (always_shown=False) are dropped when every cell is "—".
_INVENTORY_COLUMNS = [
    ("Repo", True, True),
    ("Agent", True, True),
    ("Backend", True, False),
    ("Model", False, False),
    ("Channels", False, False),
    ("Tags", False, False),
    ("System prompt", True, False),
]


def _inventory_row(graph: Graph, n: Node) -> dict[str, str]:
    """One agent's attribute cells, keyed by the `_INVENTORY_COLUMNS` names."""
    p = n.props
    return {
        "Repo": n.id.split("/", 1)[0],
        "Agent": str(p.get("suffix", "")),
        "Backend": str(p.get("backend") or "—"),
        "Model": str(p.get("model") or "—"),
        "Channels": ", ".join(_agent_channels(graph, n.id)) or "—",
        "Tags": ", ".join(p.get("tags") or []) or "—",
        "System prompt": "yes" if p.get("has_system_prompt") else "no",
    }


def _inventory_lines(graph: Graph) -> list[str]:
    agents = sorted((n for n in graph.nodes.values() if n.type == NODE_AGENT), key=lambda n: n.id)
    if not agents:
        return ["_No agents in scope._"]
    repos = sum(1 for n in graph.nodes.values() if n.type == NODE_REPO)
    backends = Counter(str(n.props.get("backend") or "—") for n in agents)
    backend_str = ", ".join(f"{b} ×{c}" for b, c in sorted(backends.items()))
    sysp = sum(1 for n in agents if n.props.get("has_system_prompt"))
    on_chan = sum(1 for n in agents if _agent_channels(graph, n.id))
    summary = (
        f"{len(agents)} agents across {repos} repos · backends: {backend_str} · "
        f"{sysp} with a system prompt · {on_chan} present on channels."
    )

    rows = [_inventory_row(graph, n) for n in agents]
    shown = [
        (name, backticked)
        for name, always, backticked in _INVENTORY_COLUMNS
        if always or any(r[name] != "—" for r in rows)
    ]
    names = [name for name, _ in shown]

    lines = [
        summary,
        "",
        "| " + " | ".join(names) + " |",
        "|" + "|".join("---" for _ in names) + "|",
    ]
    for r in rows:
        cells = [f"`{_md_cell(r[name])}`" if bt else _md_cell(r[name]) for name, bt in shown]
        lines.append("| " + " | ".join(cells) + " |")
    return lines


def _signal_lines(signals: list[Signal]) -> list[str]:
    if not signals:
        return ["_No candidate signals._"]
    by_kind: dict[str, list[Signal]] = {}
    for s in signals:
        by_kind.setdefault(s.kind, []).append(s)
    lines: list[str] = []

    # ledger-gap: subject is "repo/skill"; group by skill (the unit you edit).
    gaps = by_kind.get("ledger-gap", [])
    if gaps:
        per_skill: dict[str, list[str]] = {}
        for s in gaps:
            repo, _, skill = s.subject.partition("/")
            per_skill.setdefault(skill, []).append(repo)
        lines.append("Ledger drift — skill-sources.md downstream column is missing:")
        for skill in sorted(per_skill):
            repos = sorted(per_skill[skill])
            lines.append(f"- `{skill}` ← +{len(repos)}: {', '.join(repos)}")

    orphans = sorted(s.subject for s in by_kind.get("orphan-skill", []))
    if orphans:
        lines.append("orphan skills (supplied, no consumer recorded): " + ", ".join(orphans))

    unowned = by_kind.get("unowned-skill", [])
    if unowned:
        parts = []
        for s in sorted(unowned, key=lambda x: x.subject):
            m = _UNOWNED_REPO_RE.search(s.detail)
            parts.append(f"{s.subject} ({m.group(1)})" if m else s.subject)
        lines.append("unowned skills (on disk, no upstream): " + ", ".join(parts))

    # Any other kinds (overlap / over-connected-agent / isolated-repo) are rare
    # and individually meaningful — keep one explicit line each.
    grouped = {"ledger-gap", "orphan-skill", "unowned-skill"}
    others = sorted(
        (s for s in signals if s.kind not in grouped),
        key=lambda x: (x.kind, x.subject),
    )
    for s in others:
        lines.append(f"- **{s.kind}** `{s.subject}`: {s.detail}")
    return lines


def render_markdown(
    graph: Graph,
    signals: list[Signal],
    *,
    scope: str,
    generated: str,
    title: str,
) -> str:
    lines: list[str] = [
        f"# {title}",
        "",
        f"> Generated by `steward overview` on {generated}. Scope: `{scope}`.",
        "> Edges are **observed** (provenance by type — legend under the graph).",
        "> Candidate signals are flags, **not** conclusions; the inferred and",
        "> suggestion layers are the narrating agent's job (see the final section).",
        "",
        "## Inventory",
        "",
        *_inventory_lines(graph),
        "",
        "## Org connectivity (per repo / agent)",
        "",
        *_connectivity_lines(graph),
        "",
        "## Org graph (structural edges)",
        "",
        to_mermaid(_structural_subgraph(graph)),
        "",
        _provenance_legend(),
        "",
        _dependency_spine_line(graph),
        "",
        _cli_usage_line(graph),
        "",
        "## Candidate signals (flags, not conclusions)",
        "",
        *_signal_lines(signals),
        "",
        "## For the narrating agent",
        "",
        "Narrate three separated layers: **observed facts** (the tables + graph",
        "above), **inferred relationships** (map edges onto owns / depends-on /",
        "observes / aligns / governs / overlaps-with / supports — mark as inferred),",
        "and **suggestions** (seeded by the signals). Don't present inferences as",
        "facts; read `--json` for exact per-edge / per-signal lists before acting.",
        "Full contract: `org-overview/SKILL.md`.",
        "",
    ]
    return "\n".join(lines)
