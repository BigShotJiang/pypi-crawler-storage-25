"""Backend fingerprint detection — which agent(s) own a repo, and whether
its declared backend matches what's on disk.

Pure helpers, no CLI surface. The registry of fingerprints lives as data in
``.claude/skills/agent-config/data/backend-fingerprints.yaml`` so the bash
``show.sh`` skill and this module read one table. ``_FALLBACK_FINGERPRINTS``
mirrors that file for the pip-installed-without-checkout case;
``tests/test_agents.py`` asserts they agree.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import yaml

REGISTRY_RELPATH = Path(".claude/skills/agent-config/data/backend-fingerprints.yaml")

# Mirrors backend-fingerprints.yaml. Source of truth is the YAML; this is the
# fallback when the YAML can't be located. Kept in sync by test_agents.py.
# ``AGENTS.md`` is the shared prompt file for codex / acp / copilot; named once
# to avoid duplicating the literal (SonarCloud python:S1192).
_AGENTS_MD = "AGENTS.md"
_FALLBACK_FINGERPRINTS: dict[str, dict] = {
    "claude": {"prompt": "CLAUDE.md", "steering": []},
    "codex": {"prompt": _AGENTS_MD, "steering": [".codex"]},
    "acp": {"prompt": _AGENTS_MD, "steering": [".kiro"]},
    "copilot": {"prompt": _AGENTS_MD, "steering": []},
    "gemini": {"prompt": "GEMINI.md", "steering": [".gemini"]},
}
_PROMPT_FALLBACK = _AGENTS_MD

# Files/dirs that are generic tooling conventions, not attributable to any one
# backend.  A repo may have these without triggering a mismatch, regardless of
# its declared backend.  Mirrors ``shared_steering`` in the YAML.
# `.claude/settings.json` and `.claude/settings.local.json` are generic Claude
# Code (editor/CLI) workspace config files — present in any repo that uses
# Claude Code as the development tool, regardless of the agent backend.
# `.github/copilot-instructions.md` is generic GitHub Copilot editor/IDE config
# — any repo may have it regardless of the declared agent backend.
_SHARED_STEERING: list[str] = [
    ".agents",
    ".claude/settings.json",
    ".claude/settings.local.json",
    ".github/copilot-instructions.md",
]


@dataclass
class RepoAgentProfile:
    prompt_files: list[str]  # recognized prompt files present, owner-expected first
    owner: str | None  # owning backend (declared is authoritative)
    dual_agent: bool  # >=2 distinct prompt files present
    mismatch: bool  # declared backend disagrees with on-disk artifacts
    mismatch_reason: str | None = None


def _find_git_root(start: Path) -> Path | None:
    for directory in (start, *start.parents):
        if (directory / ".git").exists():
            return directory
    return None


def load_registry() -> tuple[dict, list[str], str]:
    """Return ``(fingerprints, shared_steering, prompt_fallback)``.

    Prefers the shared YAML inside the current checkout (the steward dev
    case); falls back to the embedded constants when it isn't found.
    """
    root = _find_git_root(Path.cwd().resolve())
    if root is not None:
        path = root / REGISTRY_RELPATH
        if path.is_file():
            try:
                data = yaml.safe_load(path.read_text()) or {}
                backends = data.get("backends")
                if isinstance(backends, dict) and backends:
                    shared = list(data.get("shared_steering", _SHARED_STEERING))
                    return (
                        backends,
                        shared,
                        str(data.get("prompt_fallback", _PROMPT_FALLBACK)),
                    )
            except (OSError, yaml.YAMLError):
                pass
    return _FALLBACK_FINGERPRINTS, _SHARED_STEERING, _PROMPT_FALLBACK


def _known_prompts(backends: dict) -> list[str]:
    """Distinct prompt filenames across the registry, stable order."""
    seen: list[str] = []
    for fp in backends.values():
        p = fp.get("prompt")
        if p and p not in seen:
            seen.append(p)
    return seen


def _infer_owner(present: list[str], backends: dict) -> str | None:
    """Infer owner when culture.yaml declares no backend.

    Only *distinct* prompt files map to a backend — a prompt is distinct iff
    exactly one backend declares it.  A lone AGENTS.md is ambiguous
    (codex/acp/copilot) so owner stays unknown.
    """
    # Build the distinct-prompt mapping from the live registry.
    from collections import Counter

    counts: Counter[str] = Counter()
    prompt_to_backend: dict[str, str] = {}
    for bname, fp in backends.items():
        p = fp.get("prompt")
        if p:
            counts[p] += 1
            prompt_to_backend[p] = bname  # last writer wins, but only used if count==1
    distinct = {p: prompt_to_backend[p] for p, n in counts.items() if n == 1}

    if len(present) == 1 and present[0] in distinct:
        return distinct[present[0]]
    return None


def _detect_mismatch(
    repo_path: Path,
    owner: str | None,
    expected: str | None,
    present: list[str],
    backends: dict,
    shared_steering: list[str],
) -> tuple[bool, str | None]:
    if not owner:
        return False, None
    # (a) declared backend's expected prompt absent, but another prompt present.
    if expected and expected not in present and present:
        return True, f"declared backend `{owner}` expects {expected}, found {present}"
    # (b) a steering dir foreign to the owner is present.
    owner_steer = set(backends.get(owner, {}).get("steering", []))
    shared = set(shared_steering)
    for name, fp in sorted(backends.items()):
        if name == owner:
            continue
        for steer in fp.get("steering", []):
            if steer in owner_steer or steer in shared:
                continue  # owner's own dir or a generic shared dir — not foreign
            if (repo_path / steer).exists():
                return True, (
                    f"declared backend `{owner}` but found `{steer}` (steering for `{name}`)"
                )
    return False, None


def detect(repo_path: Path, declared_backends: list[str]) -> RepoAgentProfile:
    """Fingerprint a repo: prompt file(s), owner, dual-agent, mismatch."""
    backends, shared_steering, _fallback = load_registry()
    present = [p for p in _known_prompts(backends) if (repo_path / p).is_file()]
    declared = [b for b in declared_backends if b]

    owner = declared[0] if declared else _infer_owner(present, backends)
    expected = backends.get(owner, {}).get("prompt") if owner else None

    ordered: list[str] = []
    if expected and expected in present:
        ordered.append(expected)
    ordered.extend(p for p in present if p not in ordered)

    dual_agent = len(set(present)) >= 2
    mismatch, reason = _detect_mismatch(
        repo_path, owner, expected, present, backends, shared_steering
    )

    return RepoAgentProfile(
        prompt_files=ordered,
        owner=owner,
        dual_agent=dual_agent,
        mismatch=mismatch,
        mismatch_reason=reason,
    )
