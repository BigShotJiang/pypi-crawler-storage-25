# steward/cli/_commands/overview.py
"""``steward overview`` — emit a deterministic ecosystem evidence pack.

Assembles a typed relationship graph (see :mod:`_graph`) plus candidate
signals from sibling repos and prints it as markdown (with a mermaid graph)
or, with ``--json``, a script-parseable structure. Diagnostic-only: the
agent that ran steward narrates the inferred relationships + suggestions.

Two scopes, mirroring ``doctor``:

* ``--scope self <target>`` (default): the target repo's node + its 1-hop
  neighborhood, plus that repo's inventory.
* ``--scope siblings``: the full corpus graph (steward itself excluded,
  same as ``doctor --scope siblings``).
"""

from __future__ import annotations

import argparse
from datetime import date
from pathlib import Path

from steward.cli._commands import _corpus, _graph
from steward.cli._commands.doctor import (
    _resolve_steward_repo_root,
    _resolve_target,
    _resolve_workspace_root,
)
from steward.cli._errors import EXIT_USER_ERROR, StewardError
from steward.cli._output import emit_diagnostic, emit_result


def register(sub: argparse._SubParsersAction) -> None:
    parser = sub.add_parser(
        "overview",
        help="Summarize the agent ecosystem (inventory + relationship graph + signals).",
        description=(
            "Sense-making companion to `doctor`. Emits a deterministic "
            "evidence pack — agent inventory, a typed relationship graph "
            "(markdown+mermaid, or --json), and candidate signals — for an "
            "agent to narrate observed facts / inferred relationships / "
            "suggestions from. Does not call an LLM and does not mutate repos."
        ),
    )
    parser.add_argument(
        "target",
        nargs="?",
        help="Path to a sibling repo directory (required for --scope self).",
    )
    parser.add_argument(
        "--scope",
        choices=["self", "siblings"],
        default="self",
        help="self (default): TARGET + its 1-hop neighborhood. siblings: the full corpus graph.",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Emit the typed graph + signals as JSON to stdout instead of markdown.",
    )
    parser.add_argument(
        "--workspace-root",
        type=Path,
        default=None,
        help="Override the workspace root (default: parent of the steward checkout).",
    )
    parser.set_defaults(func=_handle)


def _build_full(
    args: argparse.Namespace, *, skip_steward: bool
) -> tuple[_graph.Graph, list[Path], list[_corpus.ManifestError]]:
    steward_root = _resolve_steward_repo_root()
    workspace_root = _resolve_workspace_root(args, steward_root)
    skip = {steward_root.name} if skip_steward else set()
    agents, manifest_errors = _corpus.discover_agents(workspace_root, skip_repos=skip)
    repo_paths = sorted({a.repo_path for a in agents}, key=lambda p: p.name)
    ledger_path = steward_root / "docs" / "skill-sources.md"
    graph = _graph.build_graph(agents, repo_paths, ledger_path)
    return graph, repo_paths, manifest_errors


def _handle(args: argparse.Namespace) -> int:
    generated = date.today().isoformat()

    if args.scope == "siblings":
        graph, repo_paths, manifest_errors = _build_full(args, skip_steward=True)
        repo_skill_dirs = _graph.collect_repo_skill_dirs(repo_paths)
        signals = _graph.detect_signals(graph, repo_skill_dirs)
        scope, title = "siblings", "AgentCulture ecosystem overview"
    else:
        if not args.target:
            raise StewardError(
                code=EXIT_USER_ERROR,
                message="target path is required for --scope self",
                remediation="pass a path to a sibling repo, e.g. `steward overview ../culture`",
            )
        target = _resolve_target(args.target)
        graph, _repo_paths, manifest_errors = _build_full(args, skip_steward=False)
        repo_id = target.name
        graph.add_node(repo_id, _graph.NODE_REPO, path=str(target))
        graph = _graph.ego_graph(graph, repo_id)
        signals = _graph.detect_signals(graph, _graph.collect_repo_skill_dirs([target]))
        scope, title = "self", f"Overview: {repo_id}"

    warnings = [f"manifest: [{err.repo_name}] {err.message}" for err in manifest_errors]
    for warning in warnings:
        emit_diagnostic(warning)

    if args.json:
        emit_result(
            _graph.to_json(graph, signals, scope=scope, generated=generated, warnings=warnings)
        )
    else:
        emit_result(
            _graph.render_markdown(graph, signals, scope=scope, generated=generated, title=title)
        )
    return 0
