---
name: org-overview
description: >
  Review the AgentCulture agent "org" — what agents and skills exist, how they
  relate, and what the relationships imply — like a periodic workplace
  assessment of the mesh. Runs `steward overview` (deterministic facts + typed
  graph + candidate signals), then narrates three separated layers: observed
  facts, inferred relationships, and suggestions (missing owners, overlap,
  overloaded agents, possible new/split/merged agents — i.e. hiring, reorg,
  upskilling). Use when the user asks to survey the mesh, "what agents exist and
  how do they relate", "any overlap / missing owners / overloaded agents",
  "should we split or merge an agent", or "show the graph of everything".
  Reflect-only: names follow-ups but does not act. Steward-specific.
---

# Org Overview — review the agent mesh like a workplace assessment

`steward doctor` asks *"is this agent healthy and aligned?"* (health /
compliance). **`org-overview` asks the sense-making question**: *what agents and
skills exist, how do they relate, and what do those relationships imply?* Think
of it as a periodic review of the mesh's "org" — the agents are the workforce,
their skills are job functions, and the relationships are the reporting and
collaboration lines.

The split that makes this safe: **`steward overview` (the CLI) emits only
deterministic facts** — an agent/skill inventory, a typed relationship graph
(each edge citing its `basis`), and neutral *candidate signals*. It runs no LLM
and mutates nothing. **This skill is where you, the agent, do the
interpretation** — turning those facts into inferred relationships and
suggestions. Keep the two separate: never present an inference as a fact.

## When to use

- The user asks to survey or "review" the agent ecosystem / mesh / "org".
- "What agents exist and how do they relate?" / "show me the graph of everything".
- "Is there overlap between agents?" / "any missing owners?" / "is any agent
  overloaded?"
- "Should we split or merge an agent?" / "do we need a new agent?"
- "Which existing agents are missing a skill they should have?"

## How to run

One script. Pick the scope:

```bash
# All agents — the whole-mesh corpus graph + signals (default)
.claude/skills/org-overview/scripts/org-overview.sh

# One agent — that repo's ego graph (the repo + its directly-incident edges)
.claude/skills/org-overview/scripts/org-overview.sh ../culture

# Machine-readable evidence ({nodes, edges, signals}) for precise reasoning
.claude/skills/org-overview/scripts/org-overview.sh --json

# Non-default checkout layout — passthrough flag to `steward overview`
.claude/skills/org-overview/scripts/org-overview.sh --workspace-root /path/to/workspace
```

A **subset** review (a named handful of agents, not all and not one) has no
dedicated flag — run the all-agents form and **focus your narration** on the
named subset. The full corpus graph is the right substrate because it preserves
the cross-subset edges a per-agent ego graph would drop.

The script prints the CLI's markdown by default: an inventory summary, a
per-repo/agent **connectivity table** (the graph as statistics), a lean
structural mermaid (package edges dropped — see its dependency-spine line), a
grouped candidate-signals section, and a "For the narrating agent" block. That
block is the contract this skill formalizes below. The markdown is already a
digest; the exact per-edge and per-signal lists live in `--json`.

## Narrate three layers — never blur them

1. **Observed facts.** Summarize the inventory, the connectivity table, and the
   org graph in your own words — lead with what the connectivity counts reveal
   (the supplier, the hub, the keystone, the isolated repo). Render the lean
   mermaid only when seeing the topology helps. **Do not reproduce the edge or
   signal lists verbatim** — the CLI already aggregated them; read `--json` only
   when you need an exact list to act. State only what the CLI reported.
2. **Inferred relationships** (mark these clearly as inferred). Map the observed
   edges onto the interpretive vocabulary: `owns` / `depends-on` / `observes` /
   `aligns` / `documents` / `secures` / `governs` / `overlaps-with` /
   `supports`. This is where "hidden" relationships surface — e.g. two agents
   that both `consume` the same skill *overlap-with* each other even though no
   edge directly connects them.
3. **Suggestions** (kept separate from facts). Seed these from the candidate
   signals — see the mapping below.

### Signal → suggestion (the workplace-assessment deliverables)

| Candidate signal | Suggestion (HR framing) | Named follow-up — do NOT run it |
|------------------|-------------------------|---------------------------------|
| `unowned-skill` | A job function with no owner | Assign it: edit `docs/skill-sources.md`; review the agent with the `agent-config` skill |
| `orphan-skill` | A function nobody uses | Confirm intentional, then retire or promote it |
| `ledger-gap` | A consumer using an unlisted skill | Fix the ledger: edit `docs/skill-sources.md`, then `steward announce-skill-update --skill <name>` |
| `overlap` | Two roles with overlapping duties | **Split or merge** — name the agents and the shared edges; propose the boundary |
| `over-connected-agent` | One agent doing too much | **Split the overloaded agent** — name candidate seams |
| `isolated-repo` | A repo with no relationships | **A possible new agent**, or a missing `declares` / `consumes` link |

## Reflect-only

This skill **sees, reflects, and suggests — it does not act.** For every
suggestion, name the concrete next step *and which skill or command enacts it*
(as in the table above), then stop. Filing an issue (`communicate` skill),
editing a `culture.yaml` (`agent-config` skill), or amending the ledger is a
separate, explicit step the user chooses to take. Output is the chat
conversation; this skill writes nothing to disk and mutates no repo.

## Where the design is written down

- `docs/superpowers/specs/2026-05-21-org-overview-skill-design.md` — this
  skill's design.
- `docs/superpowers/specs/2026-05-21-steward-overview-design.md` — the CLI's
  evidence-pack architecture (node/edge/signal types, the three-layer contract).
- `steward/cli/_commands/_graph.py` → `render_markdown` "For the narrating
  agent" block — the contract this skill formalizes.
