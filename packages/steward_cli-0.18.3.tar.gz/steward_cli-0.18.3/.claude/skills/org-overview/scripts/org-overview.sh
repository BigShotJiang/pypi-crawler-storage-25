#!/usr/bin/env bash
# org-overview — assemble the `steward overview` evidence pack for narration.
#
# Steward-the-agent runs this, then narrates three separated layers
# (observed facts / inferred relationships / suggestions). See SKILL.md.
# This script is deterministic glue only: it resolves how to invoke steward,
# picks the scope, and delegates to `steward overview`. No interpretation.
#
# Usage:
#   org-overview.sh                       # all agents          (--scope siblings)
#   org-overview.sh <target>              # one agent ego graph (--scope self)
#   org-overview.sh --json                # all agents, JSON evidence
#   org-overview.sh <target> --json       # one agent, JSON evidence
#   org-overview.sh --workspace-root DIR  # non-default layout (passthrough)
#
# Contract: the FIRST argument, if it does not start with '-', is the target
# (self scope). All remaining arguments pass through to `steward overview`.
#
# Exit codes:
#   0   success (delegates to `steward overview`)
#   1   environment error (no way to invoke steward)

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SKILL_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
REPO_ROOT="$(cd "$SKILL_DIR/../../.." && pwd)"

# Resolve how to invoke steward: installed console script, then uv, then module.
if command -v steward >/dev/null 2>&1; then
    STEWARD=(steward)
elif [ -f "$REPO_ROOT/pyproject.toml" ] && command -v uv >/dev/null 2>&1; then
    STEWARD=(uv run --project "$REPO_ROOT" steward)
elif command -v python3 >/dev/null 2>&1; then
    STEWARD=(python3 -m steward)
else
    echo "org-overview: cannot invoke steward (need 'steward', 'uv', or 'python3' on PATH)" >&2
    exit 1
fi

# Honor an explicit --scope passed through (advanced use); otherwise pick one.
has_scope=false
for arg in "$@"; do
    case "$arg" in
        --scope|--scope=*) has_scope=true; break ;;
    esac
done

overview_args=()
if [ "$#" -gt 0 ] && [[ "$1" != -* ]]; then
    # First arg is a target → one-agent (self) scope.
    target="$1"; shift
    overview_args+=("$target")
    $has_scope || overview_args+=(--scope self)
else
    # No leading target → whole-mesh corpus.
    $has_scope || overview_args+=(--scope siblings)
fi
overview_args+=("$@")

exec "${STEWARD[@]}" overview "${overview_args[@]}"
