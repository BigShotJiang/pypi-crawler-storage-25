# Skill supplier — canonical skills

Steward acts as the **skill supplier** for the AgentCulture mesh: it owns the
canonical copy of most cross-sibling skills (`cicd`, `version-bump`,
`run-tests`, `notebooklm`, `sonarclaude`, `pypi-maintainer`,
`agent-config`, `discord-notify`, `jekyll-test`, `doc-test-alignment`,
`communicate`).
Siblings copy those skills into their own `.claude/skills/` and may modify
them. Nothing imports across repos at runtime — this is the **cite,
don't import** pattern: each consumer owns and may diverge from its copy.

This file is the deterministic upstream/downstream map. Each skill has
exactly one canonical source repo (the **upstream** column). Other repos
hold downstream copies that may lag and should periodically re-sync from
upstream. The planned `steward doctor --apply` mode will consult this file
when vendoring a skill into a target sibling so the choice is unambiguous;
today the map is human-readable only — `--apply` is on the roadmap and the
codebase does not yet read this file.

| Skill | Upstream | Downstream copies (known) | Notes |
|-------|----------|---------------------------|-------|
| `agent-config` | `steward` (`.claude/skills/agent-config/`) | — | Steward-specific (resolves Culture agent suffixes); not portable as-is. |
| `discord-notify` | `steward` (`.claude/skills/discord-notify/`) | — | Generic webhook notifier; needs `DISCORD_WEBHOOK_URL` env. Optional in the sibling baseline. |
| `doc-test-alignment` | `steward` (`.claude/skills/doc-test-alignment/`) | `devague`, `lecodeur`, `lepenseur` | Stub; real implementation TBD. |
| `jekyll-test` | `steward` (`.claude/skills/jekyll-test/`) | — | Conditional — only meaningful for siblings that ship a Jekyll / Pages / Cloudflare Pages site (detected via `_config.yml`). |
| `notebooklm` | `steward` (`.claude/skills/notebooklm/`) | — | Generates GitHub blob URLs for repo docs; auto-detects branch + remote. |
| `org-overview` | `steward` (`.claude/skills/org-overview/`) | — | Steward-specific — the agent's reflect-only narration layer over the `steward overview` CLI (observed facts → inferred relationships → suggestions). Not portable to siblings without steward installed. |
| `cicd` | `steward` (`.claude/skills/cicd/`) — layered on `agex pr` (in `agentculture/agex-cli`) | `afi-cli`, `agex-cli` (adapted-thin delegate — owns `agex pr`; see [agex-cli#53](https://github.com/agentculture/agex-cli/pull/53)), `agtag`, `antoine`, `appsec`, `auntiepypi`, `cfafi` (still named `pr-review`), `code-lens-cli`, `culture` (still named `pr-review`), `devague`, `katvan`, `lecodeur`, `lepenseur`, `seer-cli`, `telek` | As of steward 0.12.0, the cicd skill is a thin delegate to `agex pr` for lint / open / read / reply / delta. Steward keeps two extensions on top: `status` (SonarCloud quality gate + hotspots + unresolved-thread tally + deploy-preview URL) and `await` (composes `agex pr read --wait` with `status`, exits non-zero on Sonar ERROR / unresolved threads). The `await` combo verb landed natively in [agex-cli#41](https://github.com/agentculture/agex-cli/issues/41); the remaining non-native gate bits (Sonar hotspots, deploy-preview URL, thread tally) are tracked in [agex-cli#52](https://github.com/agentculture/agex-cli/issues/52), and steward's extensions migrate out once they land. **Inverted case:** agex-cli, as the `agex pr` upstream, vendors the skill adapted-thin — a `workflow.sh`-only pure delegate ([agex-cli#53](https://github.com/agentculture/agex-cli/pull/53)) rather than the five-file shape; see the SKILL.md "agex-cli inversion" note. Renamed from `pr-review` in 0.7.0. Downstream copies may keep the old name on their own cadence. |
| `communicate` | `steward` (`.claude/skills/communicate/`) | `afi-cli`, `agex-cli` (identifier-only — vendored steward 0.11.0; scripts current as of 0.18.0), `agtag`, `antoine`, `appsec`, `auntiepypi`, `code-lens-cli`, `culture` (still named `coordinate`), `devague`, `katvan`, `lecodeur`, `lepenseur`, `seer-cli`, `telek` | Cross-repo + mesh communication: file issues / hand off briefs to sibling-repo agents (auto-signed), comment on existing issues, fetch issues from sibling repos to inline state into briefs, and send live messages to Culture mesh channels (unsigned — nick is the speaker). Renamed from `coordinate` in steward 0.8.0 when mesh-message.sh joined post-issue.sh; absorbed `gh-issues` (as `fetch-issues.sh`) in 0.9.1. As of steward 0.11.0, issue I/O is backed by `agtag` (>=0.1) — signature resolves from the local `culture.yaml` (override via `--as`). Mesh-message remains a `culture channel message` wrapper pending agtag's v0.2 mesh transport. |
| `pypi-maintainer` | `steward` (`.claude/skills/pypi-maintainer/`) | `agtag` | Switches a PyPI package install between pypi / test-pypi / local. Generalised from the original culture-specific `change-package`. |
| `run-tests` | `steward` (`.claude/skills/run-tests/`) | `agtag`, `antoine`, `appsec`, `code-lens-cli`, `culture`, `culture-sonar-cli`, `devague`, `lecodeur`, `lepenseur`, `seer-cli`, `shushu`, `telek` | Coverage source resolves from `[tool.coverage.run]` in `pyproject.toml`, so the script is portable across siblings without modification. |
| `sonarclaude` | `steward` (`.claude/skills/sonarclaude/`) | `antoine`, `appsec`, `code-lens-cli`, `devague`, `lecodeur`, `lepenseur`, `seer-cli`, `telek` | SonarCloud API client. Project key resolves from `$SONAR_PROJECT` or `--project KEY`. |
| `version-bump` | `steward` (`.claude/skills/version-bump/`) | `afi-cli`, `agtag`, `antoine`, `appsec`, `auntiepypi`, `cfafi`, `code-lens-cli`, `culture`, `devague`, `lecodeur`, `lepenseur`, `seer-cli`, `shushu`, `telek` | Pure Python, prepends Keep-a-Changelog entry; no per-repo customization needed. |
| `cfafi`, `cfafi-write` | `cfafi` (`.claude/skills/cfafi*/`) | — | CloudFlare-specific; not vendored elsewhere. |
| `poll` | `cfafi` (`.claude/skills/poll/`) | — | Background-reviewer subagent; candidate for promotion to `steward` if it stabilizes. |

> **How the downstream column is maintained.** As of the 2026-05-24 refresh,
> the "Downstream copies (known)" entries are kept in sync with steward's own
> drift detector: `steward overview --scope siblings` walks every workspace
> repo that declares an agent (`culture.yaml`) and emits a `ledger-gap` signal
> for each repo that vendors a steward skill but is absent here. After this
> refresh that signal is ~0 for scanned repos. Two classes are **not** yet
> captured (deliberate follow-up, not oversight):
>
> - **No `culture.yaml`** (invisible to the detector): `tipalti`,
>   `cultureagent`, `cultureflare`, `irc-lens`, `agentirc`, `zehut`.
> - **Old skill-dir name** (`pr-review` / `coordinate`, which the detector
>   doesn't canonicalize): `daria`, `shushu`, `culture-sonar-cli` vendor
>   `cicd` under `pr-review`. `cfafi` / `culture` are already listed with a
>   "still named `pr-review`/`coordinate`" note.
>
> `agentpypi` was **renamed to `auntiepypi`** on GitHub (the old name
> redirects); `auntiepypi` is the live consumer recorded above. A stale local
> `agentpypi` clone may still produce a `version-bump` `ledger-gap` until it is
> removed — that residual is expected.

## Vendoring policy

- **Cite, don't import.** Skills are copied into the consuming repo, not
  symlinked or installed as a dependency. Each consumer owns and may modify
  their copy.
- **Re-sync explicitly.** When upstream changes, downstream copies do not
  auto-update. `steward doctor --skill <name>` is the intended re-sync path
  (TBD).
- **Diverge intentionally.** A downstream copy may diverge for repo-specific
  reasons (e.g. `cfafi`'s `cicd` / `pr-review` adds CloudFlare-API reviewers).
  Record the divergence in the downstream `SKILL.md`'s frontmatter
  `description`.

## When a skill should be promoted upstream

A skill currently owned downstream (e.g. `poll` in `cfafi`) should be promoted
to `steward` when:

1. At least one other sibling has copy-pasted it, OR
2. Its scripts have no repo-specific assumptions (no hard-coded API
   credentials, no per-product paths), AND
3. Its `SKILL.md` describes a pattern (not a single product's workflow).

Promotion is a manual decision — `steward doctor` will not move skills
between repos.
