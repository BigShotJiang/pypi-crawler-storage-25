# `org-overview` skill — design

**Status:** implemented — branch `skill/org-overview` (steward 0.14.0)
**Date:** 2026-05-21
**Branch:** `skill/org-overview`
**Relates to:** GitHub issue #40 (the `steward overview` verb, merged in #41).
This skill is the agent-facing companion to that verb.

## Goal

Give **Steward-the-agent** a repeatable workflow for *seeing, reflecting on,
and suggesting about* the AgentCulture agent ecosystem — by running the
deterministic `steward overview` CLI and narrating its evidence pack into
three clearly separated layers (observed facts → inferred relationships →
suggestions), in chat, without mutating anything.

## Context — the load-bearing split

The architecture decided for `overview` (issue #40) is preserved exactly:

- **`steward` the CLI is deterministic code output only.** `steward overview`
  emits observed facts (agent/skill inventory), a typed relationship graph
  (`repo`/`agent`/`skill`/`channel`/`package` nodes; `declares`/`supplies`/
  `consumes`/`present_on`/`depends_on`/`references` edges, each citing a
  `basis`), and neutral **candidate signals** (`orphan-skill`,
  `unowned-skill`, `ledger-gap`, `overlap`, `over-connected-agent`,
  `isolated-repo`). No LLM, no network, no repo mutation. Its markdown output
  already ends with a "For the narrating agent" instruction block.
- **`org-overview` the skill is where the LLM interpretation lives.** Steward-the-agent
  consumes the CLI's evidence pack and produces the inferred-relationships and
  suggestions layers. This is the narration layer the CLI deliberately stops
  short of.

This skill adds **no CLI surface** and **no repo mutation**. It is a pure
read → reflect → suggest workflow whose output is ephemeral chat.

## Decisions (from brainstorming)

| Decision | Choice | Rationale |
|----------|--------|-----------|
| Output artifact | **Ephemeral chat narration** | "See, reflect and suggest" is a conversational act; no marker-gated files, no mutation. |
| Action scope | **Reflect only; name the follow-up** | For each suggestion, name the concrete next step + which skill enacts it — but do not act. Keeps the skill pure-read and uncoupled from `communicate`/`agent-config`. |
| Skill name | **`org-overview`** | HR/workplace-assessment sense ("org") tied to the `steward overview` verb it wraps; opens to three scopes (all / subset / one agent). |
| Script shape | **Thin runner (Approach A)** | The CLI's markdown is already a complete evidence pack; the script's only value-add is invocation/scope/workspace resolution, so it never drifts from the CLI's format. |

## Scope modes

The skill opens to three review scopes. The merged CLI supports two natively;
the third is handled at the narration layer (no new CLI surface):

| Mode | How | CLI call |
|------|-----|----------|
| **All** (default) | Whole-mesh corpus graph + signals | `steward overview --scope siblings` |
| **One agent** | A single repo's ego graph (repo + directly-incident edges) | `steward overview <target> --scope self` |
| **Subset** | Run the full-corpus evidence; the agent **focuses its reflection** on the named subset of agents | `steward overview --scope siblings` + focused narration |

"Subset" intentionally does **not** add a CLI filter. The full corpus graph is
the correct substrate (it preserves cross-subset edges an ego-graph-per-target
would drop); the skill simply narrows what the agent narrates.

## Components

### `SKILL.md`

Frontmatter:

```yaml
---
name: org-overview
description: >
  Review the AgentCulture agent "org" — what agents and skills exist, how they
  relate, and what the relationships imply — like a periodic workplace
  assessment of the mesh. Runs `steward overview` (deterministic facts + typed
  graph + candidate signals), then narrates three separated layers: observed
  facts, inferred relationships, and suggestions (missing owners, overlap,
  overloaded agents, possible new/split/merged agents — i.e. hiring, reorg,
  upskilling). Use when the user asks to survey the mesh, "what agents exist and
  how do they relate", "any overlap / missing owners / overloaded agents",
  "should we split or merge an agent", or "show the graph of everything".
  Reflect-only: names follow-ups but does not act. Steward-specific.
---
```

Body sections:

1. **Why / when** — the sense-making counterpart to `doctor` (doctor = health/
   compliance; org-overview = understanding). Trigger phrases.
2. **Run the script** — choose scope (all / one agent / subset). Show the one
   command.
3. **Narrate three layers, never blurring them:**
   - **Observed facts** — the inventory + graph edges, each citing its basis.
     Render the CLI's mermaid graph verbatim ("see a graph of everything").
   - **Inferred relationships** — map the observed edges onto the interpretive
     vocabulary (`owns` / `depends-on` / `observes` / `aligns` / `documents` /
     `secures` / `governs` / `overlaps-with` / `supports`), **explicitly marked
     inferred**. This is the user's "hidden relationships."
   - **Suggestions** — seeded by candidate signals, each tied to its deliverable
     (see mapping below). Kept separate from facts.
4. **Reflect-only rule** — for each suggestion, name the concrete next step
   *and which skill/command enacts it*; do **not** run it.
5. **Honesty gate** — never present inferred items or suggestions as facts
   (mirrors the CLI's own closing instruction).

#### Signal → deliverable mapping (the user's wish-list, grounded in signals)

| Candidate signal (from CLI) | Narrated suggestion (user's words) | Named follow-up (not executed) |
|------------------------------|-------------------------------------|--------------------------------|
| `unowned-skill` | Skill present but no upstream owner | Edit `docs/skill-sources.md`; consider `agent-config` to assign |
| `orphan-skill` | Skill owned upstream but consumed nowhere | Confirm intentional, or retire / promote |
| `ledger-gap` | Consumer cites a skill the ledger omits | Edit `docs/skill-sources.md` (then `steward announce-skill-update --skill <name>`) |
| `overlap` | Two agents/skills with overlapping responsibility | **Split or merge** ownership — name the agents and the shared edges |
| `over-connected-agent` | One agent carries disproportionate edges | **Split an overloaded agent** — name candidate seams |
| `isolated-repo` | Repo with no incident relationship edges | **Possible new agent**, or a missing `declares`/`consumes` link |

### `scripts/org-overview.sh`

Approach A — a thin, deterministic runner. Responsibilities:

1. Resolve how to invoke steward, in order: `steward` on `PATH` →
   `uv run steward` (if `pyproject.toml` present) → `python -m steward`.
2. Parse minimal flags:
   - positional `[target]` → one-agent mode (`<target> --scope self`)
   - no target → all mode (`--scope siblings`)
   - `--json` → passthrough (agent wants machine-precise nodes/edges/signals)
   - any other argument → passthrough to `steward overview` (notably
     `--workspace-root <path>` for a non-default checkout layout).
3. Run `steward overview` with the resolved scope/flags and print its output
   (markdown by default — which already carries the mermaid graph, the
   Candidate-signals section, and the "For the narrating agent" block).

Workspace resolution is owned by the CLI: `steward overview` already resolves
the workspace root (the parent of the steward checkout) on its own, so the
runner does **not** parse `skills.local.yaml`. A non-standard layout is handled
by passing `--workspace-root` through (the CLI's existing flag) — keeping the
runner thin and free of a YAML-parsing dependency.

Constraints (skills convention): **no external path dependencies** — the
script reaches into no other skill's copy and nothing outside this repo.
Following the skill is "run this script," not a manual sequence.

## Output

Ephemeral. The skill writes nothing to disk and mutates no repo. The agent
speaks the three layers into the conversation. Acting on any suggestion is a
separate, explicit step the user/agent takes via the named skill.

## Non-goals

- No repo mutation, no committed report, no per-sibling files.
- No acting on suggestions (no auto-filing issues, no editing `culture.yaml`).
- No new CLI surface (no subset filter added to `steward overview`).
- Does not replace `doctor` (health/compliance) — it is the sense-making
  companion.
- No LLM/network logic in the script; interpretation is the agent's, guided by
  `SKILL.md` prose.

## Housekeeping (for the implementation plan)

- **Ledger:** add `org-overview` to `docs/skill-sources.md` as **upstream =
  `steward`, downstream = —, Steward-specific** (like `agent-config`: it wraps
  steward's own CLI, so it is not portable to siblings without steward
  installed).
- **Broadcast:** **none.** Empty consumer list → `announce-skill-update` is not
  warranted (and the change is a new Steward-specific skill, not a behavior
  change to a supplied skill).
- **Version bump:** required on the PR (`version-bump` skill), per AgentCulture
  rule.
- **Lint:** `SKILL.md` and this spec must pass `markdownlint-cli2` (CI lints
  `**/*.md`).
- **Tests:** a small pytest that the script (a) resolves a steward invocation
  and (b) emits the expected top-level markdown sections against a fake
  workspace — mirroring `tests/test_cli_overview.py`'s fixture style. The
  script must be exercised so it is pinned, like `pr-reply.sh` /
  `_resolve-nick.sh` are.

## Where to read about the broader design

- `docs/superpowers/specs/2026-05-21-steward-overview-design.md` — the CLI's
  evidence-pack architecture (nodes/edges/signals, the 3-layer contract).
- `steward/cli/_commands/_graph.py` → `render_markdown` "For the narrating
  agent" block — the contract this skill formalizes.
- `CLAUDE.md` → "Skills convention" and the `overview` roadmap entry.
