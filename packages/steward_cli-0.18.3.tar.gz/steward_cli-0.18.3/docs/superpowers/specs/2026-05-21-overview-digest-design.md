# Design: `steward overview` markdown digest + lean narration

> Status: approved design, pre-implementation.
> Date: 2026-05-21.
> Builds on [`2026-05-21-steward-overview-design.md`](./2026-05-21-steward-overview-design.md)
> and [`2026-05-21-org-overview-skill-design.md`](./2026-05-21-org-overview-skill-design.md).

## 1. Problem

`steward overview --scope siblings` currently emits ~808 lines / ~43 KB of
markdown. Two structural choices make it token-heavy and hard to read:

1. **Every edge is printed twice** — once inside the mermaid block
   (`n_x -->|type| n_y`, ~390 lines) and again as a prose "Edges (with
   provenance)" list (~280 lines).
2. **Dev-tooling dependency edges dominate.** ~230 of ~280 edges are
   repo→package edges for shared tooling (`black`, `pytest`, `flake8`, …).
   They bury the ~60 org-structure edges that actually carry meaning.
3. **Signals are printed per-pair.** 43 `ledger-gap` lines (one per
   repo×skill), plus orphan/unowned lists.

The downstream effect: the narrating agent (via the `org-overview` skill) is
told to *"render the mermaid graph verbatim"* and *"state only what the CLI
reported,"* so it re-consumes and re-emits the entire list. The org-signal is
present but buried.

## 2. Goal

Make `steward overview`'s **markdown** a lean digest that a narrating agent can
read and reason over cheaply, while the `--json` output remains the lossless
record. Update the `org-overview` skill so it summarizes rather than echoes.

Non-goals (YAGNI): no `--verbose` flag, no changes to `--json`, no new
node/edge/signal *types*, no changes to the extractors (`_corpus.py`,
`build_graph`, `detect_signals`). This is a **render-layer + skill-doc** change.

## 3. Decisions (settled during brainstorming)

| # | Decision |
|---|----------|
| D1 | **JSON stays lossless**; only markdown is compressed. If the agent needs an exact list it reads `--json`. |
| D2 | **Drop the prose edge list entirely.** The mermaid encodes every structural edge; per-edge provenance is replaced by a type→source legend (see §4.1). |
| D3 | **Drop repo→package edges from the markdown graph.** Keep sibling repo→repo deps (org-structure). Packages collapse to a dependency-spine summary (§4.4). Full package edges remain in `--json`. |
| D4 | **Group signals.** `ledger-gap` collapses to one line per affected skill (with the affected repo list); orphan/unowned grouped by kind (§4.5). |
| D5 | **Add a per-repo/agent connectivity stats table** — the graph "analyzed to statistical data per agent" (§4.3). Full column headers (no abbreviations). |
| D6 | **Keep a lean mermaid** alongside the stats table: agent/repo nodes, single arrows, structural edges only (§4.2). |
| D7 | Implementation = **rewrite `render_markdown` + helpers in place** (not additive). |

### 3.1 Lossless-provenance claim (justifies D2)

In `_graph.py`, every edge's `basis` is a pure function of its `type`:

| Edge type | basis (source) | code |
|-----------|----------------|------|
| `declares`, `present_on` | `culture.yaml` | `_graph.py:132,138` |
| `supplies`, `consumes` | `skill-sources.md` | `_graph.py:203,206` |
| `depends_on` | `pyproject.toml` | `_graph.py:281,284` |
| `references` | `CLAUDE.md/README.md` | `_graph.py:356` |

So a 4-line legend conveys the same provenance the ~280-line prose list did.
Nothing is lost. (If a future edge type ever carries a non-type-determined
basis, this assumption must be revisited — note it in the legend builder.)

## 4. The new markdown structure

Sections, in order. Realistic budget for the full siblings corpus: **~180–200
lines, down from ~808 (≈ 75% reduction)**. The single biggest cut is removing
the ~280-line prose edge list and the ~290 lines of package nodes/edges. The
**lean mermaid is the largest remaining block** (~125 lines: ~52 structural
node declarations + ~65 edges); the **connectivity table (§4.3) is the dense,
~22-line at-a-glance read** the narrating agent reasons over first.

### 4.1 Header

Title, scope, date, and a one-line framing: edges are observed (provenance by
type — legend under the graph); signals are flags, not conclusions; inferred
layers are the narrator's job.

### 4.2 Inventory (trimmed)

A one-line summary, then the existing attribute table with **all-empty columns
suppressed**:

```text
## Inventory — 17 agents / 18 repos
Backends: claude ×15, acp ×2. System prompt: 2 (culture, daria/daria).
On channels: 2 (culture→#general; daria/claudia→#code-review,#culture,#general).
[attribute table: Repo | Agent | Backend | Model | Channels | Tags | System prompt,
 with any column that is entirely "—" in scope dropped]
```

Keyed per agent (attributes are agent-level).

### 4.3 Org connectivity (the graph as per-agent statistics)

The headline new section. One row **per repo**, with the agent(s) it declares
noted, so supplier repos that declare no agent (`steward`, `cfafi`) and the
two-agent `daria` repo are all represented. All values are observed degree
counts by edge type — facts, not inferences. **Full column headers:**

```text
## Org connectivity (per repo / agent)
| Repo (agents) | Skills supplied | Skills consumed | Channels | Sibling deps | References in | References out | Packages |
|---|---|---|---|---|---|---|---|
| steward (—)            | 12 | 0 | 0 | 0 | 0 | 0 | 0  |
| culture (culture)      | 0  | 2 | 1 | 3 | 3 | 4 | 28 |
| afi-cli (afi-cli)      | 0  | 1 | 0 | 0 | 6 | 1 | 12 |
| daria (claudia, daria) | 0  | 0 | 3 | 0 | 1 | 1 | 3  |
| ... one row per repo, sorted ...
```

Column → computation (over the in-scope graph):

| Column | Definition |
|--------|------------|
| Skills supplied | count of `supplies` edges with `source == repo` |
| Skills consumed | count of `consumes` edges with `source == repo` |
| Channels | distinct `present_on` targets across the repo's declared agents |
| Sibling deps | count of `depends_on` edges `repo → repo-node` |
| References in | count of `references` edges with `target == repo` |
| References out | count of `references` edges with `source == repo` |
| Packages | count of `depends_on` edges `repo → package-node` |

Rows sorted by repo name (deterministic). This table is what lets the narrator
spot the hub (high degree), keystone (high References in), supplier (high
Skills supplied), and isolated repo (near-zero) **without** parsing a drawing.

### 4.4 Org graph (lean mermaid) + provenance + spine

```text
## Org graph (structural edges)

<mermaid: structural edges only — declares / supplies / consumes /
present_on / references + sibling repo->repo depends_on; NO package nodes>

Provenance: declares,present_on<-culture.yaml · supplies,consumes<-skill-sources.md
          · depends_on<-pyproject.toml · references<-CLAUDE.md/README.md
Dependency spine: N repos share <list of packages used by >= half the in-scope
repos>; M further distinct external packages. Full package edges in --json.
```

The mermaid reuses today's `to_mermaid` machinery but over a **filtered**
graph: package nodes and repo→package edges removed. Single arrow per edge
(the graph already de-duplicates edges via `_edge_keys`).

**Dependency-spine computation:** across in-scope repos, a package depended on
by `≥ ceil(num_repos_with_pyproject / 2)` repos is "spine" and is listed
(sorted); the remaining distinct external packages are reported as a count.
In `--scope self` (one repo) the spine concept is degenerate, so that scope
just reports the single repo's package count.

### 4.5 Candidate signals (grouped)

```text
## Candidate signals (flags, not conclusions)
Ledger drift — skill-sources.md downstream column is missing:
- communicate ← +10: afi-cli, agex-cli, agtag, antoine, appsec, auntiepypi, code-lens-cli, katvan, seer-cli, telek
- version-bump ← +10: agentpypi, agtag, antoine, appsec, auntiepypi, code-lens-cli, culture, seer-cli, shushu, telek
- cicd ← +9 · run-tests ← +9 · sonarclaude ← +5 · pypi-maintainer ← +1
orphan skills (supplied, no consumer recorded): agent-config, discord-notify, ...
unowned skills (on disk, no upstream): code-lookup (code-lens-cli), eval (antoine), ...
```

`ledger-gap` signals are grouped by skill (the actionable unit for editing the
ledger), shortest groups inlined. `orphan-skill` and `unowned-skill` are each
collapsed to a single grouped line. The per-pair signals remain in `--json`.

### 4.6 For the narrating agent

Trim the 12-line block to ~3 lines: three layers (observed / inferred — mark as
inferred / suggestions — from signals); don't present inferences as facts; read
`--json` for exact lists before acting; full contract in `org-overview/SKILL.md`.

## 5. `org-overview` skill changes

The skill's "Narrate three layers" section currently instructs:

> *"Render the mermaid graph verbatim so the user can 'see the graph of
> everything.' State only what the CLI reported."*

Replace the layer-1 guidance with: **summarize** the inventory, the
connectivity table, and the org graph; render the (now-lean) mermaid only when
it aids seeing the structure; **do not reproduce the edge or signal lists
verbatim** — they are already aggregated by the CLI; read `--json` only when an
exact list is needed to act. The three-layer contract, the signal→suggestion
table, and the reflect-only stance are unchanged.

## 6. Implementation surface

All in `steward/cli/_commands/_graph.py` (render layer) + the skill doc:

- **New** `_connectivity_lines(graph)` → the §4.3 table.
- **New** `_dependency_spine_line(graph)` → the §4.4 spine summary.
- **New** `_filtered_graph_for_mermaid(graph)` (or a param to `to_mermaid`) →
  graph minus package nodes/edges.
- **New** `_provenance_legend()` → the §4.1 type→source line.
- **Rewrite** `_signal_lines` → grouped output (§4.5).
- **Rewrite** `_inventory_lines` → suppress all-empty columns + summary line.
- **Rewrite** `render_markdown` → assemble the new section order; drop the call
  to `_edge_list_lines` (function may be removed if unused elsewhere).
- **Unchanged:** `to_json`, `build_graph`, `detect_signals`, `ego_graph`,
  all extractors. `overview.py` is unchanged (same `render_markdown` signature).
- `.claude/skills/org-overview/SKILL.md` — §5 edit.

## 7. Testing

- `_connectivity_lines`: a small fixture graph asserts each column's count for a
  supplier-only repo, a hub repo, a multi-agent repo, and an isolated repo.
- `_dependency_spine_line`: threshold behaviour (a package at exactly half, just
  below, just above) and the self-scope degenerate case.
- `_filtered_graph_for_mermaid`: package nodes/edges absent, structural edges and
  sibling repo→repo deps present.
- `_signal_lines`: grouping of multiple `ledger-gap` for one skill into one line;
  empty-signals case.
- `render_markdown` golden/snapshot test on a fixed fixture corpus: assert the
  new section headers exist, the prose edge list is gone, and total line count is
  within budget.
- `to_json` snapshot unchanged (regression guard that JSON stayed lossless).

## 8. Success criteria

- `steward overview --scope siblings` markdown drops from ~808 to ~180–200
  lines (≈ 75% reduction) with no loss of org-signal (inventory, ownership,
  structural graph, grouped signals all still present), and the
  prose edge list is gone.
- Provenance still recoverable from markdown (legend) and exact per-edge/per-pair
  detail still in `--json`.
- `org-overview` skill no longer instructs verbatim reproduction.
