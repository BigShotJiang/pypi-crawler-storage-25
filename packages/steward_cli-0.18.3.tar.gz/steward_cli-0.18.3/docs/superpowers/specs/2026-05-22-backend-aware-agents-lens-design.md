# Backend-aware steward + `agents-lens` — design

> Status: approved design (2026-05-22). Next: implementation plan via
> `writing-plans`. Author: steward (Claude).

## Problem

Steward assumes every Culture agent is a Claude agent whose system prompt
lives in `CLAUDE.md`. That assumption is now wrong. Three new daemon siblings
self-scaffolded with backend-native prompts and no `CLAUDE.md`:

| Repo | `culture.yaml` backend | System prompt | Steering dir |
|------|------------------------|---------------|--------------|
| codexd | `codex` | `AGENTS.md` | `.agents/` |
| antigravityd | `acp` | `AGENTS.md` | `.agents/` |
| kirod | `acp` | `AGENTS.md` | `.kiro/` |

Two facts drive the design:

1. **`AGENTS.md` is the universal non-Claude prompt file** — all three use it.
2. **`backend` alone does not disambiguate** — antigravityd and kirod both
   declare `acp`, yet steer via different dirs (`.agents/` vs `.kiro/`).

Where steward hard-codes `CLAUDE.md` today (confirmed by inspection):

- `.claude/skills/agent-config/scripts/show.sh:86-87` — cats `$DIR/CLAUDE.md`,
  prints `(missing)` for codexd/kirod.
- `steward/cli/_commands/_corpus.py:324-331,460,534-570` — builds a
  "common `## CLAUDE.md` sections" baseline and flags
  `CLAUDE.md missing ## X` for every non-Claude agent (false positive).
- `steward/cli/_commands/_graph.py:465-493` — `references` edges scan only
  `CLAUDE.md` + `README.md`, so cross-repo refs written in `AGENTS.md` are
  invisible.

## Goals

1. Steward recognizes each backend's own system-prompt source instead of
   assuming `CLAUDE.md`.
2. Steward determines the **owner** backend of a repo, **flags dual-agent
   repos**, and **flags mismatches** (declared backend vs. observed artifacts,
   e.g. `CLAUDE.md` present but skills under `.codex/`).
3. Ship a parallel `agents-lens` name — both `steward` and `agents-lens`
   commands and packages — without code duplication.

Non-goals: running agents; mutating sibling repos; designing the daemons'
own prompts. Steward stays reflect-only.

## Approach (hybrid detection — chosen)

Rejected alternatives: a pure backend→file **lookup table** (can't
disambiguate `acp`; can't express mismatch since it *is* the declared value),
and **pure presence-based discovery** (robust, but blind to what was declared,
so it can't detect a mismatch). The **hybrid** keeps both signals: a registry
of what each backend is *expected* to carry, compared against what is
*observed* on disk.

## Architecture

### 1. Detection module — `steward/cli/_commands/_agents.py`

Single source of truth, consumed by every surface.

- **`BACKEND_FINGERPRINTS`** — registry keyed by backend:

  | Backend | Prompt file | Steering / skills markers |
  |---------|-------------|---------------------------|
  | `claude` | `CLAUDE.md` | `.claude/`, `.claude/skills/` |
  | `codex` | `AGENTS.md` | `.agents/`, `.codex/` |
  | `acp` | `AGENTS.md` | `.kiro/`, `.agents/` |
  | `copilot` | `AGENTS.md` | `.github/`, `.github/copilot-instructions.md` |
  | `gemini` | `GEMINI.md` | `.gemini/` |

  Universal prompt fallback: `AGENTS.md`. The registry is **loaded from shared
  data** (see §3), not literal'd in code.

- **`detect(repo_path, declared_agents) -> RepoAgentProfile`** returning:
  - `prompt_files`: recognized prompt files present (ordered; the first is the
    one `show` cats and `_corpus`/`_graph` read).
  - `owner`: the owning backend — the declared backend when its expected
    artifacts are present; otherwise inferred from observed markers; `None`
    if nothing recognized.
  - `observed_backends`: set inferred from markers/prompt files on disk.
  - `dual_agent: bool` — ≥2 distinct backend fingerprints observed.
  - `mismatch: bool` + `mismatch_reason: str | None` — declared backend's
    expected artifacts absent, or a *different* backend's artifacts present
    (e.g. declared `claude` but skills live under `.codex/`).

`detect` is pure (path in, dataclass out); no I/O beyond reading the repo. The
declared-agents list comes from the existing `_corpus.discover_agents` parse so
detection and corpus logic agree on what's declared.

### 2. Consumers

- **`show` / `agent-config/show.sh`** — surface the *detected* prompt file(s)
  and steering dir instead of hard-coded `CLAUDE.md`. show.sh stays a portable
  standalone bash script: it reads the shared registry (§3) and does its own
  presence scan, so it behaves identically whether run via `steward show` or
  directly. When dual-agent or mismatch is detected, it prints a one-line
  note.
- **`doctor` corpus (`_corpus.py`)** — compute the section baseline from each
  repo's *actual* prompt file (`prompt_files[0]`); drop the `CLAUDE.md`
  literal. Stop emitting "CLAUDE.md missing ## X" for non-Claude agents; the
  heading-frequency baseline is computed per prompt-file-kind so Claude repos
  aren't scored against `AGENTS.md` headings or vice-versa. Dual-agent and
  mismatch findings are written into the per-target
  `docs/steward/steward-suggestions.md`.
- **`overview` graph (`_graph.py`)** — scan the detected prompt file(s) (not
  just `CLAUDE.md`) plus `README.md` for `references` edges. Add `backend` and
  `prompt` to repo/agent node props. Emit two new **candidate signals**:
  `dual_agent` and `backend_mismatch` (flags, not conclusions — consistent
  with the existing signal contract).
- **`doctor --scope self`** — two new invariants:
  - `prompt-file-present` — every declared agent's repo has *some* recognized
    prompt file (`CLAUDE.md` OR `AGENTS.md` OR `GEMINI.md` OR a steering dir).
  - `backend-consistency` — `detect().mismatch` is false. Reported only (the
    fix needs human judgement), consistent with the portability check's
    report-don't-autofix stance.

### 3. Shared registry data — `backend-fingerprints.yaml`

The registry lives as data, not code, so the bash skill and the Python module
read **one table** and never drift. Location:
`.claude/skills/agent-config/data/backend-fingerprints.yaml` (travels with the
portable skill; the Python module resolves it the same way `show` resolves
`show.sh`). Shape:

```yaml
backends:
  claude:   { prompt: CLAUDE.md,  markers: [".claude", ".claude/skills"] }
  codex:    { prompt: AGENTS.md,  markers: [".agents", ".codex"] }
  acp:      { prompt: AGENTS.md,  markers: [".kiro", ".agents"] }
  copilot:  { prompt: AGENTS.md,  markers: [".github/copilot-instructions.md"] }
  gemini:   { prompt: GEMINI.md,  markers: [".gemini"] }
prompt_fallback: AGENTS.md
```

bash reads it with the repo's existing yaml access pattern (or a minimal
grep/`yq` per the skill's portability rules); Python with `yaml.safe_load`.

### 4. `agents-lens` dual-name

- **Now (this work):** add `agents-lens = "steward.cli:main"` to
  `[project.scripts]` in `pyproject.toml`. Both `steward` and `agents-lens`
  commands ship from one install; `--version`/help mention both names.
- **PyPI:** publish `agents-lens` as a **thin wrapper distribution** that
  depends on `steward-cli` and exposes only the `agents-lens` console script.
  Both packages, both commands, zero code duplication. The wrapper's release
  cadence follows `steward-cli`. (Mechanics — second `pyproject` in a
  `packaging/agents-lens/` subdir, or a sibling shim repo — finalized in the
  implementation plan; this design fixes the *intent*: parallel names, one
  codebase.)

The package import name stays `steward` for now (no module rename) to keep the
blast radius small; the dual *name* is delivered at the command + distribution
layer.

## Testing

- **Unit** — `detect()` against fixtures mirroring the live repos:
  `codex`+`AGENTS.md`+`.agents/`; `acp`+`AGENTS.md`+`.kiro/`;
  `claude`+`CLAUDE.md`+`.claude/`; plus a **dual-agent** fixture
  (`CLAUDE.md` + `AGENTS.md` + both steering dirs) and a **mismatch** fixture
  (declared `claude`, only `.codex/` + `AGENTS.md` present).
- **Surface tests** — `show.sh` cats `AGENTS.md` when no `CLAUDE.md`;
  `_corpus` produces no `CLAUDE.md`-missing finding for a `codex` agent;
  `_graph` emits `dual_agent`/`backend_mismatch` signals for the relevant
  fixtures.
- **Live pass** — pull codexd/antigravityd/kirod locally; run
  `steward show`, `steward doctor`, `steward overview` against the real
  scaffolds and confirm no `CLAUDE.md` false-positives and correct owner
  detection.
- **Coverage** — keep steward's existing gate; the new module is small and
  fully unit-tested.

## Rollout

1. Detection module + shared registry data + unit tests.
2. Wire the four consumers; surface tests.
3. `agents-lens` command entry point (+ wrapper-distribution scaffolding).
4. Version bump (required by the `version-check` CI job) + CHANGELOG entry.
5. Docs: note backend-awareness in `docs/sibling-pattern.md`
   (prompt-file invariant is no longer `CLAUDE.md`-specific) and in `CLAUDE.md`.
6. Live pass against the three daemon repos.
