# Design: `steward overview` — agent ecosystem sense-making

> Spec for [issue #40](https://github.com/agentculture/steward/issues/40).
> Status: approved design, pre-implementation.
> Date: 2026-05-21.

## 1. Goal

Add an `overview` verb that summarizes the AgentCulture agent ecosystem so a
human or agent can quickly grasp its current shape: which agents exist, what
each owns, how they relate, where responsibilities overlap, and where ownership
is missing.

`overview` **complements** `doctor`, it does not replace it:

```text
steward doctor    asks: Is this sibling healthy and aligned?  (health / compliance)
steward overview  asks: What exists, how does it fit together, and what seems missing?
                        (understanding / sense-making)
```

## 2. Architectural decision: evidence pack for an agent

Steward today is **purely deterministic** — no LLM, no API keys, fully
offline-testable. `overview` preserves that. It does **not** call a model and
does **not** fabricate interpretive conclusions.

Instead, `overview` deterministically assembles the corpus **evidence** — a full
inventory plus a typed relationship graph built from hard signals — and emits it
in a structured form. The agent that *ran* `steward overview` then narrates the
final three-layer overview from that evidence. This mirrors how
`doctor --scope siblings` writes a structured report an agent reasons over.

The issue's three output layers map onto this division as follows:

| Layer | Produced by | How |
|-------|-------------|-----|
| **Observed facts** | steward | Inventory + typed graph; every edge cites its `basis` (source). |
| **Inferred relationships** | the narrating agent | Maps steward's neutral observed edges onto the interpretive vocabulary (owns/depends-on/observes/aligns/documents/secures/governs/overlaps-with/supports). |
| **Suggestions** | the narrating agent | Seeded by steward's deterministic *candidate signals* (orphan skill, overlap, unowned responsibility, …), narrated by the agent. |

Steward never presents a guess as a fact: observed edges use neutral verb names
and carry provenance; candidate signals are explicitly labelled "for
interpretation, not conclusions."

## 3. Module structure

Follows the existing `doctor.py` (thin dispatcher) over `_corpus.py`
(substance) shape:

```text
steward/cli/_commands/
├── overview.py   # NEW: register(sub) + _handle(); scope dispatch; thin CLI.
└── _graph.py     # NEW: typed graph model, signal extractors, renderers,
                  #      candidate-signal detection. Pure/testable, no argparse.
```

`overview.py` reuses `_corpus.discover_agents()` for inventory + manifest-error
surfacing (no duplication of the culture.yaml walk). `_graph.py` does not import
argparse and is unit-testable in isolation, exactly like `_corpus.py`.

## 4. Data model (`_graph.py`)

A typed property graph, shaped so a future local-neo4j loader can consume the
JSON directly (nodes with a `type` + `props`, edges with a `type` + `basis`).

### Node types

| Type | `id` | Key props |
|------|------|-----------|
| `repo` | repo dir name (e.g. `culture`) | `path` |
| `agent` | `<repo>/<suffix>` (namespaced — suffixes can repeat across repos) | `suffix`, `backend`, `model`, `tags`, `has_system_prompt` |
| `skill` | skill name (e.g. `cicd`) | — |
| `channel` | channel name incl. `#` (e.g. `#general`) | — |
| `package` | PyPI distribution name (e.g. `agtag`) | `sibling_repo` (set when the package resolves to a sibling repo, else absent) |

### Edge types

All edges are **observed** and carry a `basis` string naming the source file
that produced them, so the narrating agent can weight confidence.

| Type | Direction | Source signal (`basis`) |
|------|-----------|--------------------------|
| `declares` | repo → agent | `culture.yaml` |
| `supplies` | repo → skill | `docs/skill-sources.md` (upstream column) |
| `consumes` | repo → skill | `docs/skill-sources.md` (downstream column) |
| `present_on` | agent → channel | `culture.yaml` (`channels`) |
| `depends_on` | repo → package; **and** repo → repo when the package resolves to a sibling | `pyproject.toml` |
| `references` | repo → repo | `CLAUDE.md` / `README.md` |

The interpretive vocabulary from the issue (owns, aligns, governs, observes,
overlaps-with, …) is **not** an edge type — it is the agent's inference layer
applied on top of these neutral observed edges.

### Containers

```python
@dataclass
class Node:
    id: str
    type: str        # one of the node types above
    props: dict[str, object] = field(default_factory=dict)

@dataclass
class Edge:
    source: str      # node id
    target: str      # node id
    type: str        # one of the edge types above
    basis: str       # provenance, e.g. "skill-sources.md"

@dataclass
class Graph:
    nodes: dict[str, Node]          # keyed by id; add_node merges props
    edges: list[Edge]
    # helpers: add_node, add_edge (dedup), neighbors(id), subgraph(id, hops=1)
```

`Graph` provides `subgraph(node_id, hops=1)` for `--scope self` (a repo's
1-hop neighborhood).

## 5. Signal extractors (`_graph.py`)

Each extractor reads disk and adds nodes/edges to a `Graph`. Each is independently
testable against a tiny fixture tree.

1. **Inventory + channels** — from `_corpus.discover_agents()`. Adds `repo` and
   `agent` nodes, `declares` edges, and `present_on` edges + `channel` nodes
   from each agent's `raw["channels"]`.
2. **Skill ledger** — parse the markdown table in `docs/skill-sources.md`
   (steward checkout). Each row's *Upstream* column → `supplies` edge (+ `skill`
   node); each repo named in *Downstream copies* → `consumes` edge. The parser
   reads the repo name out of the column cell (handles the
   `` `repo` (`.claude/skills/...`) `` form and bare `repo` forms; ignores `—`).
3. **Package dependencies** — `tomllib` (stdlib, py3.12) parse each sibling's
   `pyproject.toml`. First pass builds a `{pypi-name → repo}` map from each
   repo's `[project].name`. Second pass reads `[project].dependencies` (+ PEP 735
   `[dependency-groups]`), strips version specifiers to the bare package name,
   and adds a `package` node + `depends_on` edge; if the package name is in the
   sibling map, also adds a repo → repo `depends_on` edge. Non-Python siblings
   (no `pyproject.toml`) are skipped silently.
4. **Cross-references** — scan each repo's `CLAUDE.md` and `README.md` for
   *other* sibling repo names, matched **only** in low-false-positive forms to
   avoid matching common words (e.g. "culture"):
   - `../<name>` (sibling-relative path)
   - `agentculture/<name>` (GitHub slug)
   - `` `<name>` `` (backticked identifier)
   Each distinct hit adds a `references` edge (deduped; self-references skipped).

## 6. Candidate signals (deterministic, `_graph.py`)

Computed from the assembled graph + filesystem. Neutral flags, **not**
conclusions — they seed the agent's *Suggestions* layer.

| Signal `kind` | Condition |
|---------------|-----------|
| `unowned-skill` | A skill present in some repo's `.claude/skills/<name>/` but with **no** `supplies` edge in the ledger (ownership gap). |
| `orphan-skill` | A skill with a `supplies` edge but **zero** `consumes` edges (supplied, never consumed). |
| `ledger-gap` | A repo whose `.claude/skills/` vendors a skill the ledger's downstream column omits (already a maintenance rule in steward's CLAUDE.md). |
| `overlap` | Two repos that `supplies` overlapping skills, or two agents sharing ≥2 tags. |
| `over-connected-agent` | An agent whose `present_on` + inbound-`references` degree exceeds a fixed threshold (default 5). |
| `isolated-repo` | A repo node with zero incident edges of any type. |

Each signal is a record `{kind, subject, detail}` where `subject` is the node id
it concerns.

## 7. Rendering (`_graph.py`)

Two renderers over the same `Graph` + signals:

### Markdown (default, → stdout)

Sections, in order:

1. **Header** — title (`# AgentCulture ecosystem overview` for siblings, or
   `# Overview: <repo>` for self), a generated-on line, scope, and a banner
   stating that edges are observed-with-provenance and signals are for
   interpretation.
2. **Observed facts**
   - *Agent inventory* — table: repo · agent · backend · model · channels · tags · has system_prompt.
   - *Skill ownership* — supplied-by / consumed-by, from the ledger edges.
3. **Relationship graph** — a `mermaid` `graph LR` block. `classDef` per node
   type for visual distinction; edges labelled with their type. Followed by a
   plain bulleted edge list (`source --type--> target  (basis)`) so the graph is
   legible without a mermaid renderer.
4. **Candidate signals** — grouped by `kind`, each with its subject + detail,
   under an explicit "these are flags for interpretation, not conclusions" note.
5. **For the narrating agent** — a short instruction block: produce the three
   layers (observed facts [above] / inferred relationships using the interpretive
   vocabulary / suggestions seeded by the candidate signals), and do not present
   inferred items as facts.

### JSON (`--json`, → stdout)

```json
{
  "scope": "siblings",
  "generated": "2026-05-21",
  "nodes": [{"id": "...", "type": "...", "props": {}}],
  "edges": [{"source": "...", "target": "...", "type": "...", "basis": "..."}],
  "signals": [{"kind": "...", "subject": "...", "detail": "..."}]
}
```

Flat `nodes`/`edges` arrays = directly loadable by a future neo4j import script;
no schema change needed to go from markdown-first to graph-DB-backed.

## 8. CLI surface (`overview.py`)

```text
steward overview [target] [--scope self|siblings] [--json] [--workspace-root DIR]
```

- `--scope self` (**default**): requires `target` (a sibling repo path). Builds
  the full corpus graph, then emits the target's 1-hop neighborhood plus that
  repo's inventory. Errors like `doctor --scope self` when `target` is
  missing/not a directory (`EXIT_USER_ERROR`).
  (Implementation note: landed as an *ego graph* — target + directly-incident
  edges only — rather than the induced subgraph, to drop shared-package-hub noise.)
- `--scope siblings`: walks `<workspace-root>/*/culture.yaml` via
  `_corpus.discover_agents(skip_repos={steward})` — same workspace-root
  resolution + steward-skip as `doctor --scope siblings`. Emits the full graph.
- Default output: markdown to **stdout** via `emit_result`; manifest-error and
  status diagnostics to **stderr** via `emit_diagnostic` (the existing
  `_output` split).
- `--json`: emits the JSON structure to stdout instead of markdown.
- Registered in `steward/cli/__init__.py` `_build_parser()` alongside
  `show`/`doctor`/`announce-skill-update`, via `register(sub)` +
  `set_defaults(func=_handle)`.

Exit code: `overview` is diagnostic/informational — exits `0` on success
regardless of how many candidate signals fire (it reports, it does not gate).
`EXIT_USER_ERROR` only for bad invocation (missing target, bad workspace root).

## 9. Testing

Mirrors the `test_corpus.py` / `test_cli_doctor*.py` split. New files:

- `tests/test_graph.py` — model (`add_node` merge, `add_edge` dedup, `subgraph`),
  each extractor against a fixture tree (tiny culture.yaml / pyproject.toml /
  CLAUDE.md / skill-sources.md), candidate-signal detection, and both renderers
  (assert nodes/edges present, mermaid block well-formed, JSON round-trips).
- `tests/test_cli_overview.py` — CLI dispatch: `--scope self` 1-hop subgraph,
  `--scope siblings` full graph, `--json` shape, missing-target error, bad
  workspace-root error.

Cross-reference matching gets explicit negative tests (the bare word "culture"
in prose must **not** create an edge; only `../culture`, `agentculture/culture`,
or `` `culture` `` do).

## 10. Required release chores (AgentCulture rules)

- **Version bump** — `python3 .claude/skills/version-bump/scripts/bump.py minor`
  (new verb = minor). CI's `version-check` job fails the PR otherwise.
- **CHANGELOG.md** — Keep-a-Changelog entry (the bump script prepends it).
- **Docs** — add `overview` to the README/CLAUDE.md "Roadmap (CLI surface)"
  section (it currently lists only `show` + `doctor`); note that `overview` is
  sense-making, distinct from `doctor`'s health role.
- **Lint** — `black`, `isort`, `flake8`, `bandit` clean (bandit note on the one
  `tomllib`/file-read path if flagged; no `subprocess` here).

## 11. Non-goals (from the issue)

`overview` does **not**: manage live agents, mutate sibling repos, replace
`doctor`, enforce architectural decisions, create a new standalone agent, or
make unsupported claims about responsibilities. No file writes in v1 (stdout
only) — a committable artifact mode can come later if wanted.

## 12. Out of scope / future

- Local neo4j loader over the `--json` output (the JSON is already shaped for it).
- A written/committable ecosystem artifact (`--out` or auto-write under
  `docs/steward/`).
- `recursive=True` discovery of nested manifests (inherits `_corpus`'s current
  sibling-only scope).
- Richer cross-reference extraction (prose NLP) — deliberately deferred to keep
  v1 deterministic and low-false-positive.
