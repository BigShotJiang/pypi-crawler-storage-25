# Design: `steward overview` — CLI-usage and doc-source relationships

> Status: approved design, pre-implementation.
> Date: 2026-05-21.

## 1. Goal

`steward overview` misses three real relationships in the AgentCulture corpus
because it only reads four sources — `culture.yaml`, `docs/skill-sources.md`,
`pyproject.toml`, and `CLAUDE.md`/`README.md` (see `build_graph` in
`steward/cli/_commands/_graph.py`). It **never reads skill bodies (`SKILL.md`)
or skill `scripts/`**, and it has no notion of a documentation agent's published
sources. The three gaps:

1. **`agtag` "used by everyone."** Only `culture` declares `agtag>=0.1` in
   `pyproject.toml`, so `add_dependencies` records just `culture → agtag`. But
   `agtag` is invoked by the `communicate` skill's scripts, which ~13 siblings
   vendor — runtime CLI usage that a pyproject-only scan cannot see.
2. **`agex-cli` ↔ the `cicd` skill.** `cicd/scripts/workflow.sh` does
   `exec agex pr …` and `require_agex` checks `PATH`; the SKILL.md says it is
   "layered on `agex pr`." The dependency lives in script source + prose, and
   the graph has no edge type connecting a *skill* to the *CLI it is built on*.
3. **`katvan` "documents everyone."** katvan is a technical-writer agent. Its
   `culture.yaml` is bare, and its README describes a 1-to-N fan-out in prose
   ("maintains the docs of sibling AgentCulture repos"), so `add_cross_references`
   finds no per-sibling token and katvan shows as isolated.

The fix preserves steward's contract: **deterministic, no LLM, no mutation,
every edge cites a `basis`.** Each gap has an on-disk, citable source.

## 2. What changes

Two new extractors in `_graph.py`, and two new observed edge types:

| Constant | Edge | Source | Basis string |
|----------|------|--------|--------------|
| `EDGE_USES = "uses"` | skill → repo, repo → repo | `.claude/skills/*/SKILL.md` + `scripts/**` | `SKILL.md/scripts` |
| `EDGE_DOCUMENTS = "documents"` | repo → repo | a doc-source registry (`site/_data/agentculture_repos.yml`) | `doc-source registry` |

`build_graph` calls both new extractors after the existing four.

## 3. Extractor: `add_cli_usage(graph, repo_paths)` — fixes gaps 1 and 2

### 3.1 Binary → repo map (self-maintaining)

Build the map from each in-scope sibling's `[project.scripts]` table in
`pyproject.toml` (the keys are the console-script binary names). This means no
hardcoded CLI list: `agex → agex-cli`, `agtag → agtag`, `steward → steward`,
`seer → seer-cli`, etc.

**Collisions.** Some binaries map to more than one repo (`culture` →
{culture, culture-sonar-cli}, `cfafi` → {cfafi, cultureflare}, `kata` →
{antoine, seer-cli}). Resolution rule, in order:

1. If exactly one candidate repo's **dir name or normalized dist name equals the
   binary**, that repo wins (`culture` → `culture`; `cfafi` → `cfafi`).
2. Otherwise the binary is **dropped** (no edges emitted for it) rather than
   guessed (`kata` matches neither `antoine` nor `seer-cli` → dropped).

This rule is deterministic and order-independent.

### 3.2 Scan and match

For each in-scope repo, gather the text of every `.claude/skills/*/SKILL.md`
and every readable file under each skill's `scripts/`. Group the text **per
skill** (so a hit is attributable to a specific skill name).

Match a binary `B` with a boundary guard:

```text
(?<![\w./-])B(?![\w-])
```

so `agex` does not match inside `agex-cli`, a path segment, or prose like
`myagex`, while `` `agtag` `` and a bare `agex pr` command both match. Skip a
repo's **own** binaries (a skill invoking its repo's own CLI produces no edge).

### 3.3 Emit edges (both granularities)

For repo `R`, skill `S`, detected binary `B` resolving to repo `T` (with
`T != R`):

- **Skill-level (attribution):** `S --uses--> T`. The skill node `S` already
  exists from the ledger or is added. Because skill nodes are singular across
  the corpus, `communicate --uses--> agtag` and `cicd --uses--> agex-cli` are
  each emitted once (dedup via the existing `_edge_keys` set).
- **Repo-level (breadth):** `R --uses--> T`. Every repo whose vendored skills
  invoke the CLI gets one edge, so `agtag`'s in-degree reflects its real reach.

## 4. Extractor: `add_doc_sources(graph, repo_paths)` — fixes gap 3

For any in-scope repo that has a `site/_data/agentculture_repos.yml`
doc-source registry, parse its entries (each has an `id` = sibling repo name and
a `docs_mode`). Emit `<docs-repo> --documents--> <id>` for every entry whose
`id` is an **in-scope** sibling, intersecting with the corpus repo names exactly
as `add_cross_references` does (so out-of-scope registry entries such as
`agentirc`/`tipalti`/`zehut` are dropped, keeping the graph closed over the
scope). `docs_mode` is not filtered on — the site documents the repo whether the
sync is `pull`, `pull-reference`, or `skip` (hand-authored). Basis:
`doc-source registry`. Repos without the registry file no-op.

## 5. Candidate signal: `doc-coverage-gap`

Extractor #4 cheaply enables one new signal. For each repo that emits any
`documents` edge (i.e. a documentation agent), flag every **in-scope sibling
repo it does not document** as a `doc-coverage-gap` — "a repo with no
documentation owner on the site." Emitted only when at least one `documents`
edge exists (no doc agent in scope → no signal). Deterministic, sorted output,
consistent with the other `detect_signals` helpers.

In the org-overview skill's signal→suggestion mapping this reads as a function
(documentation) with a coverage hole; the narrating agent names the fix
(add the repo to the registry) without acting.

## 6. Rendering

Mirrors the existing package / dependency-spine treatment: the markdown is a
**digest**; `--json` keeps full fidelity.

- **Connectivity table** (`_connectivity_lines` / `_connectivity_stats` /
  `_tally_edge`): add three columns — `CLI uses` (out-count of repo→CLI `uses`),
  `CLI used-by` (in-count of repo→CLI `uses` targeting this repo), and
  `Documents` (out-count of `documents`). The table tallies **only repo→repo**
  `uses` edges; skill→CLI `uses` edges are structural (shown in the mermaid, not
  per-repo counts), so `agtag`'s `CLI used-by` is the ~13 consuming repos, not
  13 + the `communicate→agtag` skill edge. (11 columns total; in/out are kept as
  separate columns, not folded into one `in/out` cell.)
- **Mermaid** (`_structural_subgraph`): keep `documents` and **skill→CLI**
  `uses` edges (few, structural); **drop repo→CLI** `uses` edges to avoid an
  agtag fan-in of ~13 cluttering the diagram. Summarize the dropped edges in a
  new one-line `CLI usage:` summary (e.g. `agtag ←13, agex-cli ←2`), exactly how
  package edges are dropped from the mermaid but kept in `_dependency_spine_line`
  and in `--json`.
- **Provenance legend** (`_provenance_legend`): append
  `uses ← SKILL.md/scripts · documents ← doc-source registry`.
- **`--json`** (`to_json`): no change needed; it already serializes every node,
  edge, and signal, so the new edges and signal appear with full fidelity.

## 7. Testing

Unit tests in the existing `tests/` suite, fixture-driven (temp repo trees):

- `add_cli_usage`: binary-map collision resolution (name-match wins, ambiguous
  dropped); boundary-guard false-positive cases (`agex-cli`, paths, prose);
  both skill→repo and repo→repo edges emitted with the right basis; no
  self-edge; absent `.claude/skills/` no-ops.
- `add_doc_sources`: registry parsing; in-scope intersection (out-of-scope
  entries dropped); absent registry no-ops.
- `doc-coverage-gap`: emitted only when a doc agent is present; flags exactly
  the undocumented in-scope repos; deterministic order.
- Render layer: the three new columns; the `CLI usage:` summary line; the
  legend additions; structural subgraph keeps skill→CLI but drops repo→CLI
  `uses`.

## 8. Out of scope (deliberate)

- A general "any docs agent" convention beyond the `site/_data/agentculture_repos.yml`
  registry path. katvan's registry is the only doc-source on disk today;
  generalizing the path is a later concern.
- Further CLI-derived signals (e.g. a "hidden CLI dependency" flag where a repo
  `uses` a CLI it does not declare in `pyproject.toml`). Natural follow-up once
  the `uses` edges exist.
- Any repo mutation or LLM use — explicitly preserved as never.
