# Backend-aware steward + agents-lens Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Teach steward to recognize each backend's own system-prompt file (`CLAUDE.md` / `AGENTS.md` / `GEMINI.md`) instead of assuming `CLAUDE.md`, detect a repo's owner backend, flag dual-agent repos and declared-vs-observed mismatches, and ship a parallel `agents-lens` command.

**Architecture:** A single pure detection module (`steward/cli/_commands/_agents.py`) backed by a shared registry (`.claude/skills/agent-config/data/backend-fingerprints.yaml`). Four existing surfaces consume it: `show`/`agent-config show.sh`, `doctor` corpus scoring (`_corpus.py`), `overview` graph (`_graph.py`), and new `doctor --scope self` invariants. The dual `agents-lens` name is delivered at the command + distribution layer only — the import package stays `steward`.

**Tech Stack:** Python 3.12, `pyyaml`, `pytest` (xdist + cov), hatchling, bash (the portable `show.sh` skill).

**Spec:** `docs/superpowers/specs/2026-05-22-backend-aware-agents-lens-design.md`

---

## File Structure

- **Create** `.claude/skills/agent-config/data/backend-fingerprints.yaml` — canonical registry (data, not code). Read by `show.sh` and by the Python loader.
- **Create** `steward/cli/_commands/_agents.py` — `RepoAgentProfile`, `load_registry()`, `detect()`. Pure; no CLI surface.
- **Create** `tests/test_agents.py` — unit tests for the detection module.
- **Modify** `steward/cli/_commands/_corpus.py` — generalize prompt-section reading + scoring message off the detected prompt file.
- **Modify** `steward/cli/_commands/_graph.py` — scan detected prompt file(s) for reference edges; add `prompt`/`owner` repo-node props; emit `dual-agent` + `backend-mismatch` signals.
- **Modify** `steward/cli/_commands/doctor.py` — add `prompt-file-present` + `backend-consistency` self-scope checks.
- **Modify** `.claude/skills/agent-config/scripts/show.sh` — cat the detected prompt file(s); note steering dirs.
- **Modify** `pyproject.toml` — second console script `agents-lens`.
- **Modify** `tests/test_cli.py` — assert both entry points resolve to `main`.
- **Modify** `CHANGELOG.md` + `pyproject.toml` version + `docs/sibling-pattern.md` + `CLAUDE.md` — release bookkeeping + doc alignment.

---

## Task 1: Detection module + shared registry

**Files:**

- Create: `.claude/skills/agent-config/data/backend-fingerprints.yaml`
- Create: `steward/cli/_commands/_agents.py`
- Test: `tests/test_agents.py`

- [ ] **Step 1: Write the shared registry data file**

Create `.claude/skills/agent-config/data/backend-fingerprints.yaml`:

```yaml
# Canonical backend fingerprint registry. Read by the agent-config show.sh
# (bash) and by steward/cli/_commands/_agents.py (Python). Single source of
# truth — tests/test_agents.py asserts the Python fallback constant matches
# this file so the two never drift.
#
# `prompt`   — the backend's system-prompt filename at the repo root.
# `steering` — files/dirs distinctive enough to attribute to this backend.
#              `.agents` is intentionally shared by codex + acp (generic
#              agents dir), so it is never "foreign" to either.
backends:
  claude:  { prompt: CLAUDE.md, steering: [".claude/settings.json", ".claude/settings.local.json"] }
  codex:   { prompt: AGENTS.md, steering: [".codex", ".agents"] }
  acp:     { prompt: AGENTS.md, steering: [".kiro", ".agents"] }
  copilot: { prompt: AGENTS.md, steering: [".github/copilot-instructions.md"] }
  gemini:  { prompt: GEMINI.md, steering: [".gemini"] }
prompt_fallback: AGENTS.md
```

- [ ] **Step 2: Write the failing test**

Create `tests/test_agents.py`:

```python
"""Unit tests for backend detection (steward.cli._commands._agents)."""

from __future__ import annotations

from pathlib import Path

import yaml

from steward.cli._commands import _agents


def _touch(repo: Path, *relpaths: str) -> None:
    for rel in relpaths:
        p = repo / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text("x")


def test_codex_repo_uses_agents_md(tmp_path: Path) -> None:
    _touch(tmp_path, "AGENTS.md", ".agents/keep")
    prof = _agents.detect(tmp_path, ["codex"])
    assert prof.prompt_files == ["AGENTS.md"]
    assert prof.owner == "codex"
    assert prof.dual_agent is False
    assert prof.mismatch is False


def test_acp_kiro_repo(tmp_path: Path) -> None:
    _touch(tmp_path, "AGENTS.md", ".kiro/steering.md")
    prof = _agents.detect(tmp_path, ["acp"])
    assert prof.prompt_files == ["AGENTS.md"]
    assert prof.owner == "acp"
    assert prof.mismatch is False


def test_claude_repo(tmp_path: Path) -> None:
    _touch(tmp_path, "CLAUDE.md", ".claude/settings.json")
    prof = _agents.detect(tmp_path, ["claude"])
    assert prof.prompt_files == ["CLAUDE.md"]
    assert prof.owner == "claude"


def test_dual_agent_when_two_prompt_files(tmp_path: Path) -> None:
    _touch(tmp_path, "CLAUDE.md", "AGENTS.md")
    prof = _agents.detect(tmp_path, ["claude"])
    assert prof.dual_agent is True


def test_mismatch_claude_declared_but_only_agents_md(tmp_path: Path) -> None:
    _touch(tmp_path, "AGENTS.md")
    prof = _agents.detect(tmp_path, ["claude"])
    assert prof.mismatch is True
    assert "CLAUDE.md" in (prof.mismatch_reason or "")


def test_mismatch_foreign_steering_dir(tmp_path: Path) -> None:
    # Declared claude with CLAUDE.md present, but codex steering dir present.
    _touch(tmp_path, "CLAUDE.md", ".codex/config")
    prof = _agents.detect(tmp_path, ["claude"])
    assert prof.mismatch is True
    assert ".codex" in (prof.mismatch_reason or "")


def test_owner_expected_prompt_ordered_first(tmp_path: Path) -> None:
    _touch(tmp_path, "AGENTS.md", "CLAUDE.md")
    prof = _agents.detect(tmp_path, ["codex"])
    assert prof.prompt_files[0] == "AGENTS.md"  # owner's expected prompt first


def test_fallback_constant_matches_registry_yaml() -> None:
    registry = (
        Path(__file__).resolve().parents[1]
        / ".claude/skills/agent-config/data/backend-fingerprints.yaml"
    )
    data = yaml.safe_load(registry.read_text())
    assert data["backends"] == _agents._FALLBACK_FINGERPRINTS
    assert data["prompt_fallback"] == _agents._PROMPT_FALLBACK
```

- [ ] **Step 3: Run test to verify it fails**

Run: `uv run pytest tests/test_agents.py -x -q`
Expected: FAIL — `ModuleNotFoundError: steward.cli._commands._agents`.

- [ ] **Step 4: Write the detection module**

Create `steward/cli/_commands/_agents.py`:

```python
"""Backend fingerprint detection — which agent(s) own a repo, and whether
its declared backend matches what's on disk.

Pure helpers, no CLI surface. The registry of fingerprints lives as data in
``.claude/skills/agent-config/data/backend-fingerprints.yaml`` so the bash
``show.sh`` skill and this module read one table. ``_FALLBACK_FINGERPRINTS``
mirrors that file for the pip-installed-without-checkout case;
``tests/test_agents.py`` asserts they agree.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import yaml

REGISTRY_RELPATH = Path(".claude/skills/agent-config/data/backend-fingerprints.yaml")

# Mirrors backend-fingerprints.yaml. Source of truth is the YAML; this is the
# fallback when the YAML can't be located. Kept in sync by test_agents.py.
_FALLBACK_FINGERPRINTS: dict[str, dict] = {
    "claude": {"prompt": "CLAUDE.md", "steering": [".claude/settings.json", ".claude/settings.local.json"]},
    "codex": {"prompt": "AGENTS.md", "steering": [".codex", ".agents"]},
    "acp": {"prompt": "AGENTS.md", "steering": [".kiro", ".agents"]},
    "copilot": {"prompt": "AGENTS.md", "steering": [".github/copilot-instructions.md"]},
    "gemini": {"prompt": "GEMINI.md", "steering": [".gemini"]},
}
_PROMPT_FALLBACK = "AGENTS.md"

# Prompt files that uniquely identify a backend (AGENTS.md is shared across
# codex/acp/copilot, so it is deliberately absent here).
_DISTINCT_PROMPT = {"CLAUDE.md": "claude", "GEMINI.md": "gemini"}


@dataclass
class RepoAgentProfile:
    prompt_files: list[str]          # recognized prompt files present, owner-expected first
    owner: str | None                # owning backend (declared is authoritative)
    dual_agent: bool                 # >=2 distinct prompt files present
    mismatch: bool                   # declared backend disagrees with on-disk artifacts
    mismatch_reason: str | None = None


def _find_git_root(start: Path) -> Path | None:
    for directory in (start, *start.parents):
        if (directory / ".git").exists():
            return directory
    return None


def load_registry() -> tuple[dict, str]:
    """Return ``(fingerprints, prompt_fallback)``.

    Prefers the shared YAML inside the current checkout (the steward dev
    case); falls back to the embedded constant when it isn't found.
    """
    root = _find_git_root(Path.cwd().resolve())
    if root is not None:
        path = root / REGISTRY_RELPATH
        if path.is_file():
            try:
                data = yaml.safe_load(path.read_text()) or {}
                backends = data.get("backends")
                if isinstance(backends, dict) and backends:
                    return backends, str(data.get("prompt_fallback", _PROMPT_FALLBACK))
            except (OSError, yaml.YAMLError):
                pass
    return _FALLBACK_FINGERPRINTS, _PROMPT_FALLBACK


def _known_prompts(backends: dict) -> list[str]:
    """Distinct prompt filenames across the registry, stable order."""
    seen: list[str] = []
    for fp in backends.values():
        p = fp.get("prompt")
        if p and p not in seen:
            seen.append(p)
    return seen


def _infer_owner(present: list[str]) -> str | None:
    """Infer owner when culture.yaml declares no backend.

    Only the *distinct* prompt files map to a backend; a lone AGENTS.md is
    ambiguous (codex/acp/copilot) so owner stays unknown.
    """
    if len(present) == 1 and present[0] in _DISTINCT_PROMPT:
        return _DISTINCT_PROMPT[present[0]]
    return None


def _detect_mismatch(
    repo_path: Path, owner: str | None, expected: str | None,
    present: list[str], backends: dict,
) -> tuple[bool, str | None]:
    if not owner:
        return False, None
    # (a) declared backend's expected prompt absent, but another prompt present.
    if expected and expected not in present and present:
        return True, f"declared backend `{owner}` expects {expected}, found {present}"
    # (b) a steering dir foreign to the owner is present.
    owner_steer = set(backends.get(owner, {}).get("steering", []))
    for name, fp in sorted(backends.items()):
        if name == owner:
            continue
        for steer in fp.get("steering", []):
            if steer in owner_steer:
                continue  # shared dir (e.g. .agents) — not foreign
            if (repo_path / steer).exists():
                return True, f"declared backend `{owner}` but found `{steer}` (steering for `{name}`)"
    return False, None


def detect(repo_path: Path, declared_backends: list[str]) -> RepoAgentProfile:
    """Fingerprint a repo: prompt file(s), owner, dual-agent, mismatch."""
    backends, _fallback = load_registry()
    present = [p for p in _known_prompts(backends) if (repo_path / p).is_file()]
    declared = [b for b in declared_backends if b]

    owner = declared[0] if declared else _infer_owner(present)
    expected = backends.get(owner, {}).get("prompt") if owner else None

    ordered: list[str] = []
    if expected and expected in present:
        ordered.append(expected)
    ordered.extend(p for p in present if p not in ordered)

    dual_agent = len(set(present)) >= 2
    mismatch, reason = _detect_mismatch(repo_path, owner, expected, present, backends)

    return RepoAgentProfile(
        prompt_files=ordered,
        owner=owner,
        dual_agent=dual_agent,
        mismatch=mismatch,
        mismatch_reason=reason,
    )
```

- [ ] **Step 5: Run tests to verify they pass**

Run: `uv run pytest tests/test_agents.py -q`
Expected: PASS (8 passed).

- [ ] **Step 6: Commit**

```bash
git add steward/cli/_commands/_agents.py tests/test_agents.py \
        .claude/skills/agent-config/data/backend-fingerprints.yaml
git commit -m "feat(agents): backend fingerprint detection module + shared registry"
```

---

## Task 2: Backend-aware corpus scoring

**Files:**

- Modify: `steward/cli/_commands/_corpus.py:323-345` (`_agent_claude_md_sections`), `:563-572` (scoring message)
- Test: `tests/test_corpus.py`

- [ ] **Step 1: Write the failing test**

Append to `tests/test_corpus.py`:

```python
def test_codex_agent_scored_against_agents_md_not_claude_md(tmp_path: Path) -> None:
    """A codex repo with AGENTS.md must not be flagged 'CLAUDE.md missing'."""
    from steward.cli._commands import _corpus

    repo = tmp_path / "codexd"
    repo.mkdir()
    (repo / "culture.yaml").write_text(
        yaml.safe_dump({"agents": [{"suffix": "codexd", "backend": "codex"}]})
    )
    (repo / "AGENTS.md").write_text("# Repository Guidelines\n\n## Build\n\n## Tests\n")
    agent = _corpus.discover_agents(tmp_path)[0][0]

    sections = _corpus._agent_prompt_sections(agent)
    assert sections == {"Build", "Tests"}
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_corpus.py::test_codex_agent_scored_against_agents_md_not_claude_md -q`
Expected: FAIL — `AttributeError: module ... has no attribute '_agent_prompt_sections'`.

- [ ] **Step 3: Generalize the section reader**

In `steward/cli/_commands/_corpus.py`, add the import near the top (after `import yaml`):

```python
from steward.cli._commands import _agents
```

Replace the function `_agent_claude_md_sections` (lines 323-345) with:

```python
def _agent_prompt_sections(agent: Agent) -> set[str]:
    """Extract level-2 (`## ...`) heading titles from the agent's detected
    system-prompt file (CLAUDE.md for claude, AGENTS.md for codex/acp, …).

    Iterates lines instead of using a regex: avoids both the
    polynomial-backtracking hazard SonarCloud flags on multiline regex
    anchored to ``$``, and the cost of compiling/matching a pattern when a
    single ``startswith`` does the job.
    """
    profile = _agents.detect(agent.repo_path, [agent.backend])
    if not profile.prompt_files:
        return set()
    prompt = agent.repo_path / profile.prompt_files[0]
    try:
        text = prompt.read_text()
    except OSError:
        return set()
    sections: set[str] = set()
    for line in text.splitlines():
        if line.startswith("## ") and not line.startswith("### "):
            title = line[3:].strip()
            if title:
                sections.add(title)
    return sections
```

- [ ] **Step 4: Update the two call sites**

In `synthesize_baseline` (line ~366) change `_agent_claude_md_sections(repo_agent)` to `_agent_prompt_sections(repo_agent)`.

In `score_agent_against_baseline` (line ~537) change `sections = _agent_claude_md_sections(agent)` to `sections = _agent_prompt_sections(agent)`, and change the finding message (line ~570) to name the actual file:

```python
    profile = _agents.detect(agent.repo_path, [agent.backend])
    prompt_name = profile.prompt_files[0] if profile.prompt_files else "system prompt"
    for missing in sorted(baseline.required_claude_md_sections - sections):
        findings.append(
            AgentFinding(
                check="agent-vs-baseline",
                agent=agent.suffix,
                repo=agent.repo_name,
                severity="info",
                message=f"{prompt_name} missing `## {missing}` section (in ≥80% of corpus)",
            )
        )
```

- [ ] **Step 5: Run the corpus tests**

Run: `uv run pytest tests/test_corpus.py -q`
Expected: PASS (all existing tests + the new one).

- [ ] **Step 6: Commit**

```bash
git add steward/cli/_commands/_corpus.py tests/test_corpus.py
git commit -m "feat(doctor): score agents against their own prompt file, not CLAUDE.md"
```

---

## Task 3: Backend-aware graph (references + signals)

**Files:**

- Modify: `steward/cli/_commands/_graph.py:464-474` (`_read_repo_docs`), `:118-137` (`add_inventory`), `:718-738` (`detect_signals`)
- Test: `tests/test_graph.py`

- [ ] **Step 1: Write the failing test**

Append to `tests/test_graph.py` (import `_graph` and `_agents` at top if not present):

```python
def test_agents_md_reference_creates_edge(tmp_path):
    from steward.cli._commands import _graph

    (tmp_path / "codexd").mkdir()
    (tmp_path / "culture").mkdir()
    (tmp_path / "codexd" / "AGENTS.md").write_text("see `culture` for the mesh")
    g = _graph.Graph()
    _graph.add_cross_references(g, [tmp_path / "codexd", tmp_path / "culture"])
    assert any(e.type == _graph.EDGE_REFERENCES and e.source == "codexd" for e in g.edges)


def test_backend_signals_flag_dual_and_mismatch(tmp_path):
    from steward.cli._commands import _graph

    repo = tmp_path / "weird"
    repo.mkdir()
    (repo / "CLAUDE.md").write_text("x")
    (repo / "AGENTS.md").write_text("x")  # two prompts -> dual-agent
    g = _graph.Graph()
    g.add_node("weird", _graph.NODE_REPO, path=str(repo))
    g.add_node("weird/w", _graph.NODE_AGENT, suffix="w", backend="claude")
    g.add_edge("weird", "weird/w", _graph.EDGE_DECLARES, "culture.yaml")
    signals = _graph.detect_signals(g, {})
    kinds = {s.kind for s in signals}
    assert "dual-agent" in kinds
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/test_graph.py -k "agents_md_reference or backend_signals" -q`
Expected: FAIL — no `dual-agent` signal; AGENTS.md not scanned.

- [ ] **Step 3: Scan the detected prompt file for references**

In `steward/cli/_commands/_graph.py`, replace `_read_repo_docs` (lines 464-474):

```python
def _read_repo_docs(repo: Path) -> str:
    """Concatenated prompt file(s) + README.md text for a repo.

    Presence-based: reads whichever of the recognized prompt files exist
    (CLAUDE.md / AGENTS.md / GEMINI.md) plus README.md, so cross-repo
    references written in a non-Claude prompt are not missed.
    """
    text = ""
    for fname in ("CLAUDE.md", "AGENTS.md", "GEMINI.md", "README.md"):
        f = repo / fname
        if f.is_file():
            try:
                text += "\n" + f.read_text(encoding="utf-8")
            except (OSError, UnicodeDecodeError):
                continue
    return text
```

Update the basis string in `add_cross_references` (line ~493) from `"CLAUDE.md/README.md"` to `"prompt/README.md"`, and update the provenance legend string near line 953 from `"references ← CLAUDE.md/README.md"` to `"references ← prompt(CLAUDE/AGENTS/GEMINI)/README.md"`.

- [ ] **Step 4: Annotate agent nodes with detected prompt + owner**

In `add_inventory` (after line 135, before `graph.add_node(agent_id, NODE_AGENT, **props)`), add:

```python
        from steward.cli._commands import _agents as _agents_mod

        profile = _agents_mod.detect(a.repo_path, [a.backend])
        if profile.prompt_files:
            props["prompt"] = profile.prompt_files[0]
        if profile.owner:
            props["owner"] = profile.owner
```

- [ ] **Step 5: Add the backend signal helper + wire it in**

Add this helper just above `detect_signals` (line 718):

```python
def _backend_signals(graph: Graph) -> list[Signal]:
    """Flag dual-agent repos and declared-vs-observed backend mismatches.

    Flags, not conclusions — consistent with the other signal helpers.
    """
    from steward.cli._commands import _agents as _agents_mod

    out: list[Signal] = []
    repos = sorted(n for n in graph.nodes.values() if n.type == NODE_REPO)
    for repo in sorted(
        (n for n in graph.nodes.values() if n.type == NODE_REPO), key=lambda n: n.id
    ):
        path = repo.props.get("path")
        if not path:
            continue
        backends = [
            n.props.get("backend", "")
            for n in graph.nodes.values()
            if n.type == NODE_AGENT and n.id.startswith(f"{repo.id}/")
        ]
        profile = _agents_mod.detect(Path(path), backends)
        if profile.dual_agent:
            out.append(
                Signal("dual-agent", repo.id,
                        f"multiple prompt files present: {profile.prompt_files}")
            )
        if profile.mismatch:
            out.append(Signal("backend-mismatch", repo.id, profile.mismatch_reason or ""))
    return out
```

(Delete the stray `repos = ...` line if your editor flags it unused — the loop above re-derives the sorted list.) Then in `detect_signals` (line ~731), add `*_backend_signals(graph),` to the returned list, after `*_doc_coverage_gap_signals(graph),`.

- [ ] **Step 6: Run the graph tests**

Run: `uv run pytest tests/test_graph.py -q`
Expected: PASS.

- [ ] **Step 7: Commit**

```bash
git add steward/cli/_commands/_graph.py tests/test_graph.py
git commit -m "feat(overview): scan detected prompt files; dual-agent + backend-mismatch signals"
```

---

## Task 4: Backend-aware `show.sh`

**Files:**

- Modify: `.claude/skills/agent-config/scripts/show.sh:86-87`
- Test: `tests/test_cli_show.py`

- [ ] **Step 1: Write the failing test**

Append to `tests/test_cli_show.py` (mirror the existing path-mode test pattern in that file for how it invokes show.sh / `steward show`):

```python
def test_show_cats_agents_md_when_no_claude_md(tmp_path, run_show):
    # run_show is the existing helper that invokes `steward show <path>`;
    # if absent, invoke the script directly via subprocess as the other
    # tests in this file do.
    repo = tmp_path / "codexd"
    (repo / ".git").mkdir(parents=True)
    (repo / "AGENTS.md").write_text("# Repository Guidelines\n")
    (repo / "culture.yaml").write_text("agents:\n- suffix: codexd\n  backend: codex\n")
    out = run_show(str(repo))
    assert "AGENTS.md" in out
    assert "# Repository Guidelines" in out
```

If `tests/test_cli_show.py` has no reusable helper, copy the subprocess-invocation idiom already used by the nearest existing test in that file (do not invent a new fixture).

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_cli_show.py -k agents_md -q`
Expected: FAIL — show.sh prints `=== <dir>/CLAUDE.md ===` + `(missing)`, never reads AGENTS.md.

- [ ] **Step 3: Make show.sh prompt-file-aware**

In `.claude/skills/agent-config/scripts/show.sh`, replace lines 86-88 (the `CLAUDE.md` block) with:

```bash
# Recognized prompt filenames come from the shared registry (single source
# of truth with the Python detector). Fall back to the built-in list if the
# registry isn't present (e.g. skill vendored without the data file).
REGISTRY="$SKILL_DIR/data/backend-fingerprints.yaml"
prompt_files=()
if [ -f "$REGISTRY" ]; then
    while IFS= read -r pf; do
        [ -n "$pf" ] && prompt_files+=("$pf")
    done < <(grep -oE 'prompt:[[:space:]]*[^,}[:space:]]+' "$REGISTRY" | awk '{print $NF}' | sort -u)
fi
[ ${#prompt_files[@]} -eq 0 ] && prompt_files=(CLAUDE.md AGENTS.md GEMINI.md)

shown=0
for pf in "${prompt_files[@]}"; do
    if [ -f "$DIR/$pf" ]; then
        echo "=== $DIR/$pf ==="
        cat "$DIR/$pf"
        echo
        shown=1
    fi
done
if [ "$shown" -eq 0 ]; then
    echo "=== $DIR (system prompt) ==="
    echo "(no recognized prompt file: ${prompt_files[*]})"
    echo
fi
```

- [ ] **Step 4: Run the show tests**

Run: `uv run pytest tests/test_cli_show.py -q`
Expected: PASS (existing CLAUDE.md tests still pass — a claude repo still prints its CLAUDE.md; the new AGENTS.md test passes).

- [ ] **Step 5: Commit**

```bash
git add .claude/skills/agent-config/scripts/show.sh tests/test_cli_show.py
git commit -m "feat(show): cat the detected prompt file(s), not just CLAUDE.md"
```

---

## Task 5: Doctor self-scope invariants

**Files:**

- Modify: `steward/cli/_commands/doctor.py:198-201` (`CHECKS`), add two `_check_*` functions
- Test: `tests/test_cli_doctor.py`

- [ ] **Step 1: Write the failing test**

Append to `tests/test_cli_doctor.py`:

```python
def test_prompt_file_present_passes_for_agents_md(tmp_path):
    from steward.cli._commands import doctor

    (tmp_path / "culture.yaml").write_text("agents:\n- suffix: c\n  backend: codex\n")
    (tmp_path / "AGENTS.md").write_text("# guidelines\n")
    findings = doctor._check_prompt_file(tmp_path)
    assert findings == []


def test_prompt_file_present_flags_when_none(tmp_path):
    from steward.cli._commands import doctor

    (tmp_path / "culture.yaml").write_text("agents:\n- suffix: c\n  backend: codex\n")
    findings = doctor._check_prompt_file(tmp_path)
    assert len(findings) == 1
    assert findings[0].check == "prompt-file-present"


def test_backend_consistency_flags_mismatch(tmp_path):
    from steward.cli._commands import doctor

    (tmp_path / "culture.yaml").write_text("agents:\n- suffix: c\n  backend: claude\n")
    (tmp_path / "AGENTS.md").write_text("x")  # declared claude, no CLAUDE.md
    findings = doctor._check_backend_consistency(tmp_path)
    assert len(findings) == 1
    assert findings[0].check == "backend-consistency"
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/test_cli_doctor.py -k "prompt_file_present or backend_consistency" -q`
Expected: FAIL — `AttributeError: ... has no attribute '_check_prompt_file'`.

- [ ] **Step 3: Add a declared-backends helper + the two checks**

In `steward/cli/_commands/doctor.py`, add near the other imports:

```python
from steward.cli._commands import _agents, _corpus
```

Add these functions just above `CHECKS = {` (line 198):

```python
def _declared_backends(target: Path) -> list[str]:
    """Backends declared in the target's own culture.yaml (empty if none)."""
    manifest = target / "culture.yaml"
    if not manifest.is_file():
        return []
    data, err = _corpus._read_manifest(manifest)
    if err or not data:
        return []
    entries = _corpus._extract_agent_entries(data)
    return [str(e.get("backend") or "") for e in entries if isinstance(e, dict)]


def _check_prompt_file(target: Path) -> list[Finding]:
    """Every declared agent's repo has *some* recognized system-prompt file."""
    backends = _declared_backends(target)
    if not backends:
        return []
    profile = _agents.detect(target, backends)
    if profile.prompt_files:
        return []
    return [
        Finding(
            check="prompt-file-present",
            path=str(target),
            message="no recognized system-prompt file (CLAUDE.md / AGENTS.md / GEMINI.md)",
        )
    ]


def _check_backend_consistency(target: Path) -> list[Finding]:
    """Declared backend agrees with the prompt/steering files on disk."""
    backends = _declared_backends(target)
    if not backends:
        return []
    profile = _agents.detect(target, backends)
    if not profile.mismatch:
        return []
    return [
        Finding(
            check="backend-consistency",
            path=str(target),
            message=profile.mismatch_reason or "declared backend does not match on-disk artifacts",
        )
    ]
```

Extend the `CHECKS` dict (line 198):

```python
CHECKS = {
    "skills-convention": _check_skills_convention,
    "portability": _check_portability,
    "prompt-file-present": _check_prompt_file,
    "backend-consistency": _check_backend_consistency,
}
```

- [ ] **Step 4: Run the doctor tests**

Run: `uv run pytest tests/test_cli_doctor.py -q`
Expected: PASS. (Note: `doctor` on a repo with no `culture.yaml`, e.g. steward's own self-check fixtures, returns `[]` from both new checks — no behavior change there.)

- [ ] **Step 5: Commit**

```bash
git add steward/cli/_commands/doctor.py tests/test_cli_doctor.py
git commit -m "feat(doctor): prompt-file-present + backend-consistency self-scope checks"
```

---

## Task 6: `agents-lens` command entry point

**Files:**

- Modify: `pyproject.toml:24-25`
- Test: `tests/test_cli.py`

- [ ] **Step 1: Write the failing test**

Append to `tests/test_cli.py`:

```python
def test_agents_lens_entry_point_declared():
    import tomllib
    from pathlib import Path

    data = tomllib.load(open(Path(__file__).resolve().parents[1] / "pyproject.toml", "rb"))
    scripts = data["project"]["scripts"]
    assert scripts.get("agents-lens") == "steward.cli:main"
    assert scripts.get("steward") == "steward.cli:main"
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_cli.py -k agents_lens_entry_point -q`
Expected: FAIL — `agents-lens` key absent.

- [ ] **Step 3: Add the second console script**

In `pyproject.toml`, change the `[project.scripts]` block (lines 24-25):

```toml
[project.scripts]
steward = "steward.cli:main"
agents-lens = "steward.cli:main"
```

- [ ] **Step 4: Re-sync and verify both commands resolve**

Run:

```bash
uv sync
uv run agents-lens --version
uv run steward --version
uv run pytest tests/test_cli.py -q
```

Expected: both `--version` calls print the same version; tests PASS.

- [ ] **Step 5: Commit**

```bash
git add pyproject.toml tests/test_cli.py uv.lock
git commit -m "feat(cli): ship agents-lens as a parallel command alongside steward"
```

---

## Task 7: Version bump, changelog, docs, live pass

**Files:**

- Modify: `pyproject.toml` (version), `CHANGELOG.md`, `docs/sibling-pattern.md`, `CLAUDE.md`

- [ ] **Step 1: Bump version + changelog**

Run: `python3 .claude/skills/version-bump/scripts/bump.py minor`
(0.16.0 → 0.17.0; the script also prepends a CHANGELOG entry.) Then edit the new CHANGELOG `## [0.17.0]` block to read:

```markdown
### Added

- Backend-aware detection (`steward/cli/_commands/_agents.py` + shared
  `.claude/skills/agent-config/data/backend-fingerprints.yaml`): steward now
  recognizes each backend's own system-prompt file (`CLAUDE.md` / `AGENTS.md`
  / `GEMINI.md`) instead of assuming `CLAUDE.md`.
- `overview` candidate signals `dual-agent` and `backend-mismatch`; agent
  nodes carry `prompt` + `owner` props.
- `doctor --scope self` checks `prompt-file-present` and `backend-consistency`.
- `agents-lens` console script — a parallel name for the `steward` command.

### Changed

- `doctor` corpus scoring and `overview` reference edges read the detected
  prompt file, so non-Claude siblings are no longer mis-flagged as missing
  `CLAUDE.md` sections.
- `show` cats the detected prompt file(s) rather than only `CLAUDE.md`.
```

- [ ] **Step 2: Update sibling-pattern docs**

In `docs/sibling-pattern.md`, change the `lint-config-local`/`CLAUDE.md` invariant language so the prompt-file requirement is backend-neutral. Replace the `changelog-format`/`CLAUDE.md`-adjacent invariant text and the artifact-table row #12 "CLAUDE.md" with: "System prompt — `CLAUDE.md` (claude), `AGENTS.md` (codex/acp/copilot), or `GEMINI.md` (gemini); steward detects which." Add a one-line note under "Invariants": "`prompt-file-present` and `backend-consistency` are backend-aware (see `backend-fingerprints.yaml`)."

- [ ] **Step 3: Note the dual command in CLAUDE.md**

In `steward/CLAUDE.md`, under "Build / test / publish", add: "The CLI is also exposed as `agents-lens` (same entry point as `steward`)."

- [ ] **Step 4: Full test + lint pass**

Run:

```bash
uv run pytest -n auto -q
uv run black --check steward tests && uv run isort --check-only steward tests
uv run flake8 steward tests && uv run bandit -q -r steward
markdownlint-cli2 "docs/**/*.md" "CHANGELOG.md" 2>/dev/null || true
```

Expected: all green; coverage gate satisfied.

- [ ] **Step 5: Live pass against the real daemon repos**

Pull the three scaffolded repos into the workspace and run steward against them:

```bash
for r in codexd antigravityd kirod; do
  git -C ../$r pull --ff-only
  echo "=== show $r ==="; uv run steward show ../$r | head -5
  echo "=== doctor $r ==="; uv run steward doctor ../$r; echo "exit=$?"
done
uv run steward overview --scope siblings | grep -E "dual-agent|backend-mismatch|codexd|kirod" || true
```

Expected: `show` cats each repo's `AGENTS.md`; `doctor` reports no `CLAUDE.md`-missing false positives and a clean `backend-consistency` for codexd/antigravityd/kirod; `overview` lists them as connected agents with `prompt`/`owner` props and no spurious mismatch.

- [ ] **Step 6: Commit**

```bash
git add pyproject.toml CHANGELOG.md docs/sibling-pattern.md CLAUDE.md
git commit -m "chore: 0.17.0 — backend-aware steward + agents-lens; docs + changelog"
```

---

## Self-Review

**Spec coverage:**

- Detection module (hybrid) → Task 1. ✓
- Shared registry data → Task 1 (+ drift test). ✓
- show / agent-config → Task 4. ✓
- doctor corpus scoring → Task 2. ✓
- overview graph (references + node props + dual-agent/mismatch signals) → Task 3. ✓
- doctor self-scope invariants (prompt-file-present, backend-consistency) → Task 5. ✓
- agents-lens dual command → Task 6. ✓ (PyPI thin-wrapper *distribution* is a follow-up, flagged in the spec — not in this plan's scope; this plan delivers the parallel *command*.)
- Testing incl. live pass → Tasks 1-7. ✓

**Placeholder scan:** No "TBD"/"add error handling"/"similar to Task N"; all code steps show code. The one cross-file fixture reference (`run_show` in Task 4 Step 1) explicitly instructs the engineer to mirror the existing idiom in that test file rather than invent one — verify the helper name before writing.

**Type consistency:** `RepoAgentProfile` fields (`prompt_files`, `owner`, `dual_agent`, `mismatch`, `mismatch_reason`) used identically in Tasks 1/2/3/5. `detect(repo_path, declared_backends)` signature consistent across all callers. `Finding(check, path, message)` and `Signal(kind, subject, detail)` match the existing dataclasses.

**Deviation from spec (flagged):** the spec said the Python module loads the YAML the way `show` resolves `show.sh`; this plan loads the YAML when found in the cwd git-root and falls back to an embedded constant otherwise, with a drift test (`test_fallback_constant_matches_registry_yaml`) keeping them identical. This is more robust for the pip-installed case and preserves the single-source-of-truth intent.
