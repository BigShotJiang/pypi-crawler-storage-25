# `steward overview` Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add a `steward overview` verb that emits a deterministic "evidence pack" — agent inventory + a typed relationship graph (markdown-with-mermaid, or `--json`) + candidate signals — for an agent to narrate ecosystem sense-making from.

**Architecture:** A thin `overview.py` command (scope dispatch only) sits on top of `_graph.py` (typed graph model + four signal extractors + candidate-signal detection + renderers), exactly mirroring how `doctor.py` sits on `_corpus.py`. `overview.py` reuses `_corpus.discover_agents()` for inventory and three private resolver helpers from `doctor.py`. Steward stays deterministic — no LLM.

**Tech Stack:** Python 3.12 (stdlib `tomllib`, `re`, `json`, `dataclasses`), argparse, pytest (+ xdist/cov in CI), `pyyaml` (already a dep, used by `_corpus`).

**Reference spec:** `docs/superpowers/specs/2026-05-21-steward-overview-design.md`

---

## File Structure

| File | Responsibility |
|------|----------------|
| `steward/cli/_commands/_graph.py` (create) | Typed graph model (`Node`/`Edge`/`Graph`/`Signal`), node/edge type constants, four extractors, `collect_repo_skill_dirs`, `build_graph`, `detect_signals`, `to_json`, `to_mermaid`, `render_markdown`. No argparse. |
| `steward/cli/_commands/overview.py` (create) | `register(sub)` + `_handle(args)`; `--scope self/siblings`, `--json`, `--workspace-root`. Reuses `_corpus.discover_agents` and `doctor._resolve_*` helpers. |
| `steward/cli/__init__.py` (modify) | Import + `register(sub)` the new command in `_build_parser()`. |
| `tests/test_graph.py` (create) | Unit tests for the model, every extractor, signal detection, and both renderers. |
| `tests/test_cli_overview.py` (create) | CLI dispatch tests (self/siblings/json/error), mirroring `test_cli_doctor_siblings.py`. |
| `pyproject.toml` + `CHANGELOG.md` (modify) | `version-bump minor` (CI gate) + Keep-a-Changelog entry. |
| `README.md` / `CLAUDE.md` (modify) | Add `overview` to the roadmap/CLI-surface docs. |

---

## Task 1: Graph model (`_graph.py` core)

**Files:**

- Create: `steward/cli/_commands/_graph.py`
- Test: `tests/test_graph.py`

- [ ] **Step 1: Write the failing test**

```python
# tests/test_graph.py
"""Unit tests for the steward overview graph model + extractors."""

from __future__ import annotations

from pathlib import Path

from steward.cli._commands import _graph


def test_add_node_merges_props():
    g = _graph.Graph()
    g.add_node("culture", _graph.NODE_REPO, path="/x")
    g.add_node("culture", _graph.NODE_REPO, extra=1)
    assert g.nodes["culture"].type == _graph.NODE_REPO
    assert g.nodes["culture"].props == {"path": "/x", "extra": 1}


def test_add_edge_dedups_on_source_target_type():
    g = _graph.Graph()
    g.add_edge("a", "b", _graph.EDGE_REFERENCES, "first")
    g.add_edge("a", "b", _graph.EDGE_REFERENCES, "second")
    assert len(g.edges) == 1
    assert g.edges[0].basis == "first"  # first basis wins


def test_subgraph_one_hop():
    g = _graph.Graph()
    for n in ("a", "b", "c", "d"):
        g.add_node(n, _graph.NODE_REPO)
    g.add_edge("a", "b", _graph.EDGE_REFERENCES, "x")
    g.add_edge("b", "c", _graph.EDGE_REFERENCES, "x")
    g.add_edge("c", "d", _graph.EDGE_REFERENCES, "x")
    sub = g.subgraph("a", hops=1)
    assert set(sub.nodes) == {"a", "b"}
    assert all(e.source in sub.nodes and e.target in sub.nodes for e in sub.edges)
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_graph.py -v`
Expected: FAIL with `ModuleNotFoundError: No module named 'steward.cli._commands._graph'`

- [ ] **Step 3: Write minimal implementation**

```python
# steward/cli/_commands/_graph.py
"""Typed property graph for ``steward overview``.

Pure model + extractors + renderers — no argparse. The overview command
imports from here to assemble a deterministic "evidence pack": a typed
graph (repo/agent/skill/channel/package nodes; declares/supplies/consumes/
present_on/depends_on/references edges, each carrying provenance) plus
candidate signals. The agent that ran steward narrates the inferred
relationships and suggestions layers from this evidence.

Lives in its own module for the same reason ``_corpus.py`` does: it adds
enough logic that bundling it into ``overview.py`` would bury the
dispatcher, and the pieces are testable in isolation without argparse.
"""

from __future__ import annotations

from dataclasses import dataclass, field

# Node types.
NODE_REPO = "repo"
NODE_AGENT = "agent"
NODE_SKILL = "skill"
NODE_CHANNEL = "channel"
NODE_PACKAGE = "package"

# Edge types. All observed; each edge also carries a `basis` (provenance).
EDGE_DECLARES = "declares"  # repo -> agent
EDGE_SUPPLIES = "supplies"  # repo -> skill
EDGE_CONSUMES = "consumes"  # repo -> skill
EDGE_PRESENT_ON = "present_on"  # agent -> channel
EDGE_DEPENDS_ON = "depends_on"  # repo -> package, and repo -> repo
EDGE_REFERENCES = "references"  # repo -> repo


@dataclass
class Node:
    id: str
    type: str
    props: dict = field(default_factory=dict)


@dataclass
class Edge:
    source: str
    target: str
    type: str
    basis: str


@dataclass
class Signal:
    kind: str
    subject: str
    detail: str


@dataclass
class Graph:
    nodes: dict[str, Node] = field(default_factory=dict)
    edges: list[Edge] = field(default_factory=list)
    _edge_keys: set = field(default_factory=set, compare=False, repr=False)

    def add_node(self, node_id: str, node_type: str, **props) -> Node:
        existing = self.nodes.get(node_id)
        if existing is None:
            self.nodes[node_id] = Node(id=node_id, type=node_type, props=dict(props))
        else:
            existing.props.update(props)
        return self.nodes[node_id]

    def add_edge(self, source: str, target: str, edge_type: str, basis: str) -> None:
        key = (source, target, edge_type)
        if key in self._edge_keys:
            return
        self._edge_keys.add(key)
        self.edges.append(Edge(source=source, target=target, type=edge_type, basis=basis))

    def neighbors(self, node_id: str) -> set[str]:
        out: set[str] = set()
        for e in self.edges:
            if e.source == node_id:
                out.add(e.target)
            elif e.target == node_id:
                out.add(e.source)
        return out

    def subgraph(self, node_id: str, hops: int = 1) -> "Graph":
        keep = {node_id}
        frontier = {node_id}
        for _ in range(hops):
            nxt: set[str] = set()
            for n in frontier:
                nxt |= self.neighbors(n)
            keep |= nxt
            frontier = nxt
        sub = Graph()
        for nid in keep:
            n = self.nodes.get(nid)
            if n is not None:
                sub.add_node(n.id, n.type, **n.props)
        for e in self.edges:
            if e.source in keep and e.target in keep:
                sub.add_edge(e.source, e.target, e.type, e.basis)
        return sub
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_graph.py -v`
Expected: PASS (3 passed)

- [ ] **Step 5: Commit**

```bash
git add steward/cli/_commands/_graph.py tests/test_graph.py
git commit -m "feat(overview): typed graph model (Node/Edge/Graph)"
```

---

## Task 2: Inventory + channels extractor

**Files:**

- Modify: `steward/cli/_commands/_graph.py`
- Test: `tests/test_graph.py`

- [ ] **Step 1: Write the failing test**

```python
# add to tests/test_graph.py
from steward.cli._commands import _corpus


def _agent(suffix: str, repo: str, **raw) -> "_corpus.Agent":
    repo_path = Path("/ws") / repo
    return _corpus.Agent(
        suffix=suffix,
        backend=raw.get("backend", ""),
        repo_path=repo_path,
        manifest_path=repo_path / "culture.yaml",
        raw={"suffix": suffix, **raw},
    )


def test_add_inventory_builds_repo_agent_channel_nodes():
    g = _graph.Graph()
    _graph.add_inventory(
        g, [_agent("culture", "culture", backend="claude", channels=["#general"], tags=["t"])]
    )
    assert g.nodes["culture"].type == _graph.NODE_REPO
    agent = g.nodes["culture/culture"]
    assert agent.type == _graph.NODE_AGENT
    assert agent.props["backend"] == "claude"
    assert agent.props["tags"] == ["t"]
    assert agent.props["has_system_prompt"] is False
    assert g.nodes["#general"].type == _graph.NODE_CHANNEL
    edges = {(e.source, e.target, e.type) for e in g.edges}
    assert ("culture", "culture/culture", _graph.EDGE_DECLARES) in edges
    assert ("culture/culture", "#general", _graph.EDGE_PRESENT_ON) in edges
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_graph.py::test_add_inventory_builds_repo_agent_channel_nodes -v`
Expected: FAIL with `AttributeError: module 'steward.cli._commands._graph' has no attribute 'add_inventory'`

- [ ] **Step 3: Write minimal implementation**

```python
# append to steward/cli/_commands/_graph.py

def add_inventory(graph: Graph, agents) -> None:
    """Add repo/agent/channel nodes + declares/present_on edges from agents.

    ``agents`` is a list of :class:`steward.cli._commands._corpus.Agent`.
    """
    for a in agents:
        repo_id = a.repo_name
        graph.add_node(repo_id, NODE_REPO, path=str(a.repo_path))
        agent_id = f"{repo_id}/{a.suffix}"
        props: dict = {"suffix": a.suffix, "backend": a.backend}
        model = a.raw.get("model")
        if model:
            props["model"] = str(model)
        tags = a.raw.get("tags")
        if isinstance(tags, list):
            props["tags"] = [str(t) for t in tags]
        props["has_system_prompt"] = bool(a.raw.get("system_prompt"))
        graph.add_node(agent_id, NODE_AGENT, **props)
        graph.add_edge(repo_id, agent_id, EDGE_DECLARES, "culture.yaml")
        channels = a.raw.get("channels")
        if isinstance(channels, list):
            for ch in channels:
                ch_id = str(ch)
                graph.add_node(ch_id, NODE_CHANNEL)
                graph.add_edge(agent_id, ch_id, EDGE_PRESENT_ON, "culture.yaml")
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_graph.py -v`
Expected: PASS (4 passed)

- [ ] **Step 5: Commit**

```bash
git add steward/cli/_commands/_graph.py tests/test_graph.py
git commit -m "feat(overview): inventory + channel extractor"
```

---

## Task 3: Skill-ledger extractor

**Files:**

- Modify: `steward/cli/_commands/_graph.py`
- Test: `tests/test_graph.py`

- [ ] **Step 1: Write the failing test**

```python
# add to tests/test_graph.py

_LEDGER = """\
| Skill | Upstream | Downstream copies (known) | Notes |
|-------|----------|---------------------------|-------|
| `agent-config` | `steward` (`.claude/skills/agent-config/`) | — | Steward-specific. |
| `cicd` | `steward` (`.claude/skills/cicd/`) — layered on `agex pr` | `cfafi` (still named `pr-review`), `culture` (still named `pr-review`) | note |
| `version-bump` | `steward` (`.claude/skills/version-bump/`) | `cfafi`, `afi-cli` | note |
| `cfafi`, `cfafi-write` | `cfafi` (`.claude/skills/cfafi*/`) | — | CloudFlare. |
"""


def test_parse_skill_ledger_rows():
    rows = dict((skill, (up, tuple(down))) for skill, up, down in _graph.parse_skill_ledger(_LEDGER))
    assert rows["agent-config"] == ("steward", ())
    assert rows["cicd"] == ("steward", ("cfafi", "culture"))
    assert rows["version-bump"] == ("steward", ("cfafi", "afi-cli"))
    assert rows["cfafi-write"] == ("cfafi", ())


def test_add_skill_ledger_edges(tmp_path: Path):
    ledger = tmp_path / "skill-sources.md"
    ledger.write_text(_LEDGER)
    g = _graph.Graph()
    _graph.add_skill_ledger(g, ledger)
    assert g.nodes["cicd"].type == _graph.NODE_SKILL
    edges = {(e.source, e.target, e.type) for e in g.edges}
    assert ("steward", "cicd", _graph.EDGE_SUPPLIES) in edges
    assert ("culture", "cicd", _graph.EDGE_CONSUMES) in edges
    assert ("cfafi", "cicd", _graph.EDGE_CONSUMES) in edges
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_graph.py::test_parse_skill_ledger_rows -v`
Expected: FAIL with `AttributeError: ... has no attribute 'parse_skill_ledger'`

- [ ] **Step 3: Write minimal implementation**

```python
# append to steward/cli/_commands/_graph.py — add `import re` and `from pathlib import Path` at top of file

_BACKTICK_RE = re.compile(r"`([^`]+)`")


def _first_backtick(cell: str) -> str | None:
    m = _BACKTICK_RE.search(cell)
    return m.group(1).strip() if m else None


def _first_backtick_per_chunk(cell: str) -> list[str]:
    """First backticked token of each comma-separated chunk of a table cell.

    For column 1 this yields the skill name(s); for the downstream column
    it yields the consumer repo of each chunk (ignoring parenthetical
    notes that may carry their own backticks, e.g. ``(still named
    `pr-review`)``).
    """
    out: list[str] = []
    for chunk in cell.split(","):
        tok = _first_backtick(chunk)
        if tok:
            out.append(tok)
    return out


def parse_skill_ledger(text: str) -> list[tuple[str, str, list[str]]]:
    """Parse the markdown table in docs/skill-sources.md.

    Returns ``(skill, upstream_repo, [downstream_repos])`` per skill. The
    skill column may list several comma-separated skills sharing one
    upstream. Header and separator rows are skipped.
    """
    rows: list[tuple[str, str, list[str]]] = []
    for line in text.splitlines():
        line = line.strip()
        if not line.startswith("|"):
            continue
        cells = [c.strip() for c in line.strip("|").split("|")]
        if len(cells) < 3:
            continue
        if cells[0].lower() == "skill" or set(cells[0]) <= {"-", ":", " "}:
            continue
        skills = _first_backtick_per_chunk(cells[0])
        upstream = _first_backtick(cells[1])
        downstream = _first_backtick_per_chunk(cells[2])
        if not skills or not upstream:
            continue
        for skill in skills:
            rows.append((skill, upstream, downstream))
    return rows


def add_skill_ledger(graph: Graph, ledger_path: Path) -> None:
    """Add skill nodes + supplies/consumes edges from a skill-sources.md."""
    try:
        text = ledger_path.read_text()
    except OSError:
        return
    for skill, upstream, downstream in parse_skill_ledger(text):
        graph.add_node(skill, NODE_SKILL)
        graph.add_node(upstream, NODE_REPO)
        graph.add_edge(upstream, skill, EDGE_SUPPLIES, "skill-sources.md")
        for repo in downstream:
            graph.add_node(repo, NODE_REPO)
            graph.add_edge(repo, skill, EDGE_CONSUMES, "skill-sources.md")
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_graph.py -v`
Expected: PASS (6 passed)

- [ ] **Step 5: Commit**

```bash
git add steward/cli/_commands/_graph.py tests/test_graph.py
git commit -m "feat(overview): skill-sources.md ledger extractor"
```

---

## Task 4: Package-dependency extractor

**Files:**

- Modify: `steward/cli/_commands/_graph.py`
- Test: `tests/test_graph.py`

- [ ] **Step 1: Write the failing test**

```python
# add to tests/test_graph.py

def _write_pyproject(repo: Path, name: str, deps: list[str]):
    repo.mkdir(parents=True, exist_ok=True)
    dep_lines = ", ".join(f'"{d}"' for d in deps)
    (repo / "pyproject.toml").write_text(
        f'[project]\nname = "{name}"\ndependencies = [{dep_lines}]\n'
    )


def test_add_dependencies_package_and_sibling_edges(tmp_path: Path):
    communicate = tmp_path / "communicate"
    agtag = tmp_path / "agtag"
    _write_pyproject(communicate, "communicate-cli", ["agtag>=0.1", "requests"])
    _write_pyproject(agtag, "agtag", [])
    g = _graph.Graph()
    _graph.add_dependencies(g, [communicate, agtag])
    edges = {(e.source, e.target, e.type) for e in g.edges}
    # package node + edge for every dep
    assert g.nodes["agtag"].type == _graph.NODE_PACKAGE
    assert ("communicate", "agtag", _graph.EDGE_DEPENDS_ON) in edges  # package edge
    assert ("communicate", "requests", _graph.EDGE_DEPENDS_ON) in edges
    # agtag resolves to a sibling repo -> repo->repo edge + sibling_repo prop
    assert g.nodes["agtag"].props.get("sibling_repo") == "agtag"
```

Note: when a package name equals a sibling repo dir name (here `agtag`), the
package node id and the repo node id collide. The extractor keeps the package
node typed `package` and only stamps `sibling_repo`; the repo→repo edge points
to the _repo dir name_ via `sibling_repo`. The test above asserts the package
node carries the sibling marker; the repo→repo edge is asserted in
`test_add_dependencies_sibling_repo_edge` below.

```python
def test_add_dependencies_sibling_repo_edge(tmp_path: Path):
    communicate = tmp_path / "communicate"
    agtag = tmp_path / "agtag"
    _write_pyproject(communicate, "communicate-cli", ["agtag>=0.1"])
    _write_pyproject(agtag, "agtag", [])
    g = _graph.Graph()
    _graph.add_dependencies(g, [communicate, agtag])
    repo_repo = [
        e for e in g.edges
        if e.type == _graph.EDGE_DEPENDS_ON and e.source == "communicate" and e.target == "agtag"
    ]
    assert repo_repo, "expected a depends_on edge from communicate to sibling agtag"
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_graph.py::test_add_dependencies_package_and_sibling_edges -v`
Expected: FAIL with `AttributeError: ... has no attribute 'add_dependencies'`

- [ ] **Step 3: Write minimal implementation**

```python
# append to steward/cli/_commands/_graph.py — add `import tomllib` at top of file

_DEP_NAME_RE = re.compile(r"^([A-Za-z0-9._-]+)")


def _normalize_pkg(name: str) -> str:
    return name.strip().lower().replace("_", "-")


def _dep_name(spec: str) -> str | None:
    m = _DEP_NAME_RE.match(spec.strip())
    return _normalize_pkg(m.group(1)) if m else None


def _load_pyproject(pyproject: Path) -> dict | None:
    try:
        return tomllib.loads(pyproject.read_text())
    except (OSError, tomllib.TOMLDecodeError):
        return None


def _project_name(data: dict) -> str | None:
    name = (data.get("project") or {}).get("name")
    return _normalize_pkg(str(name)) if name else None


def _dependency_specs(data: dict) -> list[str]:
    specs: list[str] = []
    project = data.get("project") or {}
    specs.extend(project.get("dependencies") or [])
    for group in (project.get("optional-dependencies") or {}).values():
        specs.extend(group or [])
    for group in (data.get("dependency-groups") or {}).values():
        specs.extend(item for item in (group or []) if isinstance(item, str))
    return specs


def add_dependencies(graph: Graph, repo_paths) -> None:
    """Add package nodes + depends_on edges from each repo's pyproject.toml.

    ``repo_paths`` is an iterable of sibling repo dirs. A first pass maps
    each repo's published distribution name to its dir name; a dependency
    on a sibling distribution then also adds a repo -> repo edge. Repos
    without a pyproject.toml (e.g. Jekyll sites) are skipped.
    """
    repo_paths = list(repo_paths)
    name_to_repo: dict[str, str] = {}
    parsed: dict[str, dict] = {}
    for repo in repo_paths:
        data = _load_pyproject(repo / "pyproject.toml")
        if data is None:
            continue
        parsed[repo.name] = data
        pname = _project_name(data)
        if pname:
            name_to_repo[pname] = repo.name
    for repo in repo_paths:
        data = parsed.get(repo.name)
        if data is None:
            continue
        for spec in _dependency_specs(data):
            dep = _dep_name(spec)
            if not dep:
                continue
            graph.add_node(dep, NODE_PACKAGE)
            graph.add_edge(repo.name, dep, EDGE_DEPENDS_ON, "pyproject.toml")
            sibling = name_to_repo.get(dep)
            if sibling and sibling != repo.name:
                graph.nodes[dep].props["sibling_repo"] = sibling
                graph.add_node(sibling, NODE_REPO)
                graph.add_edge(repo.name, sibling, EDGE_DEPENDS_ON, "pyproject.toml")
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_graph.py -v`
Expected: PASS (8 passed)

- [ ] **Step 5: Commit**

```bash
git add steward/cli/_commands/_graph.py tests/test_graph.py
git commit -m "feat(overview): pyproject dependency extractor"
```

---

## Task 5: Cross-reference extractor

**Files:**

- Modify: `steward/cli/_commands/_graph.py`
- Test: `tests/test_graph.py`

- [ ] **Step 1: Write the failing test**

```python
# add to tests/test_graph.py

def test_add_cross_references_low_false_positive(tmp_path: Path):
    steward = tmp_path / "steward"
    culture = tmp_path / "culture"
    daria = tmp_path / "daria"
    for d in (steward, culture, daria):
        d.mkdir()
    # steward references culture (../culture) and daria (`daria`) explicitly;
    # the bare word "culture" in prose must NOT create an edge.
    (steward / "CLAUDE.md").write_text(
        "Sibling at ../culture. See `daria` for awareness. "
        "Our culture of testing is great.\n"
    )
    (culture / "CLAUDE.md").write_text("Nothing relevant here.\n")
    g = _graph.Graph()
    _graph.add_cross_references(g, [steward, culture, daria])
    edges = {(e.source, e.target, e.type) for e in g.edges}
    assert ("steward", "culture", _graph.EDGE_REFERENCES) in edges
    assert ("steward", "daria", _graph.EDGE_REFERENCES) in edges
    # no self-reference, and culture has no outgoing references
    assert not any(e.source == "steward" and e.target == "steward" for e in g.edges)
    assert not any(e.source == "culture" for e in g.edges)


def test_add_cross_references_agentculture_slug(tmp_path: Path):
    a = tmp_path / "alpha"
    b = tmp_path / "beta"
    a.mkdir()
    b.mkdir()
    (a / "README.md").write_text("Built on agentculture/beta.\n")
    g = _graph.Graph()
    _graph.add_cross_references(g, [a, b])
    assert any(
        e.source == "alpha" and e.target == "beta" and e.type == _graph.EDGE_REFERENCES
        for e in g.edges
    )
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_graph.py::test_add_cross_references_low_false_positive -v`
Expected: FAIL with `AttributeError: ... has no attribute 'add_cross_references'`

- [ ] **Step 3: Write minimal implementation**

```python
# append to steward/cli/_commands/_graph.py

def _ref_patterns(name: str) -> list[re.Pattern]:
    esc = re.escape(name)
    return [
        re.compile(rf"\.\./{esc}(?![\w-])"),  # ../name (sibling-relative path)
        re.compile(rf"agentculture/{esc}(?![\w-])"),  # agentculture/name (GH slug)
        re.compile(rf"`{esc}`"),  # `name` (backticked identifier)
    ]


def add_cross_references(graph: Graph, repo_paths) -> None:
    """Add references edges where one repo names another sibling.

    Only low-false-positive forms count (``../name``, ``agentculture/name``,
    `` `name` ``) so the common-word case (e.g. "culture" in prose) does
    not create spurious edges. Scans CLAUDE.md + README.md.
    """
    repo_paths = list(repo_paths)
    names = {p.name for p in repo_paths}
    for repo in repo_paths:
        text = ""
        for fname in ("CLAUDE.md", "README.md"):
            f = repo / fname
            if f.is_file():
                try:
                    text += "\n" + f.read_text()
                except OSError:
                    continue
        if not text:
            continue
        for other in sorted(names):
            if other == repo.name:
                continue
            if any(pat.search(text) for pat in _ref_patterns(other)):
                graph.add_node(other, NODE_REPO)
                graph.add_edge(repo.name, other, EDGE_REFERENCES, "CLAUDE.md/README.md")
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_graph.py -v`
Expected: PASS (10 passed)

- [ ] **Step 5: Commit**

```bash
git add steward/cli/_commands/_graph.py tests/test_graph.py
git commit -m "feat(overview): CLAUDE.md/README cross-reference extractor"
```

---

## Task 6: `build_graph`, `collect_repo_skill_dirs`, `detect_signals`

**Files:**

- Modify: `steward/cli/_commands/_graph.py`
- Test: `tests/test_graph.py`

- [ ] **Step 1: Write the failing test**

```python
# add to tests/test_graph.py

def test_collect_repo_skill_dirs(tmp_path: Path):
    repo = tmp_path / "alpha"
    (repo / ".claude" / "skills" / "cicd" / "scripts").mkdir(parents=True)
    (repo / ".claude" / "skills" / "version-bump").mkdir(parents=True)
    got = _graph.collect_repo_skill_dirs([repo])
    assert got == {"alpha": {"cicd", "version-bump"}}


def test_detect_signals_orphan_unowned_and_isolated():
    g = _graph.Graph()
    # steward supplies cicd; nobody consumes it -> orphan-skill
    g.add_node("steward", _graph.NODE_REPO)
    g.add_node("cicd", _graph.NODE_SKILL)
    g.add_edge("steward", "cicd", _graph.EDGE_SUPPLIES, "skill-sources.md")
    # lonely repo declares an agent but is otherwise unconnected -> isolated-repo
    g.add_node("lonely", _graph.NODE_REPO)
    g.add_node("lonely/x", _graph.NODE_AGENT)
    g.add_edge("lonely", "lonely/x", _graph.EDGE_DECLARES, "culture.yaml")
    # alpha vendors `mystery` (on disk) with no ledger upstream -> unowned-skill
    repo_skill_dirs = {"alpha": {"mystery"}}
    signals = _graph.detect_signals(g, repo_skill_dirs)
    kinds = {(s.kind, s.subject) for s in signals}
    assert ("orphan-skill", "cicd") in kinds
    assert ("isolated-repo", "lonely") in kinds
    assert ("unowned-skill", "mystery") in kinds


def test_detect_signals_ledger_gap():
    g = _graph.Graph()
    g.add_node("steward", _graph.NODE_REPO)
    g.add_node("culture", _graph.NODE_REPO)
    g.add_node("cicd", _graph.NODE_SKILL)
    g.add_edge("steward", "cicd", _graph.EDGE_SUPPLIES, "skill-sources.md")
    # culture vendors cicd on disk but the ledger has no consumes edge for it
    signals = _graph.detect_signals(g, {"culture": {"cicd"}})
    assert any(s.kind == "ledger-gap" and s.subject == "culture/cicd" for s in signals)
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_graph.py::test_collect_repo_skill_dirs -v`
Expected: FAIL with `AttributeError: ... has no attribute 'collect_repo_skill_dirs'`

- [ ] **Step 3: Write minimal implementation**

```python
# append to steward/cli/_commands/_graph.py

def collect_repo_skill_dirs(repo_paths) -> dict[str, set[str]]:
    """Map repo dir name -> set of skill dir names under .claude/skills/."""
    out: dict[str, set[str]] = {}
    for repo in repo_paths:
        skills_dir = repo / ".claude" / "skills"
        if not skills_dir.is_dir():
            continue
        names = {p.name for p in skills_dir.iterdir() if p.is_dir()}
        if names:
            out[repo.name] = names
    return out


def build_graph(agents, repo_paths, ledger_path: Path) -> Graph:
    """Assemble the full evidence graph from all four signal sources."""
    graph = Graph()
    add_inventory(graph, agents)
    add_skill_ledger(graph, ledger_path)
    add_dependencies(graph, repo_paths)
    add_cross_references(graph, repo_paths)
    return graph


def detect_signals(
    graph: Graph,
    repo_skill_dirs: dict[str, set[str]],
    *,
    over_connected_threshold: int = 5,
) -> list[Signal]:
    """Compute deterministic candidate signals (flags, not conclusions)."""
    signals: list[Signal] = []

    supplier_of: dict[str, str] = {}
    consumers: dict[str, set[str]] = {}
    for e in graph.edges:
        if e.type == EDGE_SUPPLIES:
            supplier_of.setdefault(e.target, e.source)
        elif e.type == EDGE_CONSUMES:
            consumers.setdefault(e.target, set()).add(e.source)
    supplied_skills = set(supplier_of)
    consumed_skills = set(consumers)

    # orphan-skill: supplied, never consumed.
    for skill in sorted(supplied_skills - consumed_skills):
        signals.append(
            Signal(
                "orphan-skill",
                skill,
                f"supplied by `{supplier_of[skill]}` but no downstream consumer recorded",
            )
        )

    # unowned-skill (dedup by skill) + ledger-gap, from on-disk skill dirs.
    unowned: dict[str, str] = {}
    for repo in sorted(repo_skill_dirs):
        for skill in sorted(repo_skill_dirs[repo]):
            if skill in supplied_skills:
                upstream = supplier_of[skill]
                if upstream != repo and repo not in consumers.get(skill, set()):
                    signals.append(
                        Signal(
                            "ledger-gap",
                            f"{repo}/{skill}",
                            f"`{repo}` vendors `{skill}` (upstream `{upstream}`) but the "
                            "ledger downstream column omits it",
                        )
                    )
            else:
                unowned.setdefault(skill, repo)
    for skill, repo in sorted(unowned.items()):
        signals.append(
            Signal(
                "unowned-skill",
                skill,
                f"present in `{repo}/.claude/skills/` but no upstream recorded in the ledger",
            )
        )

    # over-connected-agent: present on more than the threshold of channels.
    present_count: dict[str, int] = {}
    for e in graph.edges:
        if e.type == EDGE_PRESENT_ON:
            present_count[e.source] = present_count.get(e.source, 0) + 1
    for agent, n in sorted(present_count.items()):
        if n > over_connected_threshold:
            signals.append(
                Signal("over-connected-agent", agent, f"present on {n} channels (> {over_connected_threshold})")
            )

    # isolated-repo: a repo whose only edges are `declares`.
    for repo in sorted(n.id for n in graph.nodes.values() if n.type == NODE_REPO):
        non_declare = [
            e
            for e in graph.edges
            if (e.source == repo or e.target == repo) and e.type != EDGE_DECLARES
        ]
        declares = any(e.source == repo and e.type == EDGE_DECLARES for e in graph.edges)
        if declares and not non_declare:
            signals.append(
                Signal("isolated-repo", repo, "declares agents but has no skill/dependency/reference edges")
            )

    # overlap: two agents sharing >= 2 tags.
    agents_with_tags = [
        n for n in sorted(graph.nodes.values(), key=lambda x: x.id) if n.type == NODE_AGENT
    ]
    for i in range(len(agents_with_tags)):
        for j in range(i + 1, len(agents_with_tags)):
            t1 = set(agents_with_tags[i].props.get("tags") or [])
            t2 = set(agents_with_tags[j].props.get("tags") or [])
            shared = t1 & t2
            if len(shared) >= 2:
                signals.append(
                    Signal(
                        "overlap",
                        f"{agents_with_tags[i].id} ~ {agents_with_tags[j].id}",
                        f"share tags: {', '.join(sorted(shared))}",
                    )
                )

    return signals
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_graph.py -v`
Expected: PASS (13 passed)

- [ ] **Step 5: Commit**

```bash
git add steward/cli/_commands/_graph.py tests/test_graph.py
git commit -m "feat(overview): build_graph + candidate-signal detection"
```

---

## Task 7: JSON renderer

**Files:**

- Modify: `steward/cli/_commands/_graph.py`
- Test: `tests/test_graph.py`

- [ ] **Step 1: Write the failing test**

```python
# add to tests/test_graph.py
import json as _json


def test_to_json_shape_is_loadable():
    g = _graph.Graph()
    g.add_node("steward", _graph.NODE_REPO, path="/x")
    g.add_node("cicd", _graph.NODE_SKILL)
    g.add_edge("steward", "cicd", _graph.EDGE_SUPPLIES, "skill-sources.md")
    signals = [_graph.Signal("orphan-skill", "cicd", "no consumer")]
    payload = _json.loads(_graph.to_json(g, signals, scope="siblings", generated="2026-05-21"))
    assert payload["scope"] == "siblings"
    assert payload["generated"] == "2026-05-21"
    assert {"id": "cicd", "type": "skill", "props": {}} in payload["nodes"]
    assert {
        "source": "steward",
        "target": "cicd",
        "type": "supplies",
        "basis": "skill-sources.md",
    } in payload["edges"]
    assert payload["signals"][0]["kind"] == "orphan-skill"
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_graph.py::test_to_json_shape_is_loadable -v`
Expected: FAIL with `AttributeError: ... has no attribute 'to_json'`

- [ ] **Step 3: Write minimal implementation**

```python
# append to steward/cli/_commands/_graph.py — add `import json` at top of file

def _sorted_nodes(graph: Graph) -> list[Node]:
    return sorted(graph.nodes.values(), key=lambda n: (n.type, n.id))


def _sorted_edges(graph: Graph) -> list[Edge]:
    return sorted(graph.edges, key=lambda e: (e.type, e.source, e.target))


def to_json(graph: Graph, signals: list[Signal], *, scope: str, generated: str) -> str:
    """Serialize the graph + signals to a script-parseable (neo4j-loadable) JSON."""
    payload = {
        "scope": scope,
        "generated": generated,
        "nodes": [{"id": n.id, "type": n.type, "props": n.props} for n in _sorted_nodes(graph)],
        "edges": [
            {"source": e.source, "target": e.target, "type": e.type, "basis": e.basis}
            for e in _sorted_edges(graph)
        ],
        "signals": [{"kind": s.kind, "subject": s.subject, "detail": s.detail} for s in signals],
    }
    return json.dumps(payload, indent=2)
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_graph.py -v`
Expected: PASS (14 passed)

- [ ] **Step 5: Commit**

```bash
git add steward/cli/_commands/_graph.py tests/test_graph.py
git commit -m "feat(overview): JSON (neo4j-loadable) renderer"
```

---

## Task 8: Markdown + mermaid renderer

**Files:**

- Modify: `steward/cli/_commands/_graph.py`
- Test: `tests/test_graph.py`

- [ ] **Step 1: Write the failing test**

```python
# add to tests/test_graph.py

def test_to_mermaid_sanitizes_ids_and_labels_edges():
    g = _graph.Graph()
    g.add_node("culture/culture", _graph.NODE_AGENT, suffix="culture")
    g.add_node("#general", _graph.NODE_CHANNEL)
    g.add_edge("culture/culture", "#general", _graph.EDGE_PRESENT_ON, "culture.yaml")
    out = _graph.to_mermaid(g)
    assert out.startswith("```mermaid")
    assert "graph LR" in out
    # ids sanitized to mermaid-safe tokens; labels preserve the real id
    assert "classDef channel" in out
    assert '"#general"' in out
    assert "present_on" in out
    assert out.rstrip().endswith("```")


def test_render_markdown_has_all_sections():
    g = _graph.Graph()
    g.add_node("steward", _graph.NODE_REPO, path="/x")
    g.add_node("steward/steward", _graph.NODE_AGENT, suffix="steward", backend="claude", has_system_prompt=False)
    g.add_edge("steward", "steward/steward", _graph.EDGE_DECLARES, "culture.yaml")
    g.add_node("cicd", _graph.NODE_SKILL)
    g.add_edge("steward", "cicd", _graph.EDGE_SUPPLIES, "skill-sources.md")
    signals = [_graph.Signal("orphan-skill", "cicd", "no consumer")]
    md = _graph.render_markdown(
        g, signals, scope="siblings", generated="2026-05-21", title="AgentCulture ecosystem overview"
    )
    assert "# AgentCulture ecosystem overview" in md
    assert "## Observed facts" in md
    assert "### Agent inventory" in md
    assert "### Skill ownership" in md
    assert "## Relationship graph" in md
    assert "```mermaid" in md
    assert "## Candidate signals" in md
    assert "orphan-skill" in md
    assert "## For the narrating agent" in md
    # provenance edge list present for non-mermaid readers
    assert "supplies" in md and "skill-sources.md" in md
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_graph.py::test_to_mermaid_sanitizes_ids_and_labels_edges -v`
Expected: FAIL with `AttributeError: ... has no attribute 'to_mermaid'`

- [ ] **Step 3: Write minimal implementation**

```python
# append to steward/cli/_commands/_graph.py

_MERMAID_CLASSDEFS = {
    NODE_REPO: "fill:#cde,stroke:#369,color:#000",
    NODE_AGENT: "fill:#dfd,stroke:#393,color:#000",
    NODE_SKILL: "fill:#ffd,stroke:#aa3,color:#000",
    NODE_CHANNEL: "fill:#fde,stroke:#a39,color:#000",
    NODE_PACKAGE: "fill:#eee,stroke:#999,color:#000",
}


def _mermaid_id(node_id: str) -> str:
    return "n_" + re.sub(r"[^A-Za-z0-9]", "_", node_id)


def to_mermaid(graph: Graph) -> str:
    lines = ["```mermaid", "graph LR"]
    for node_type, style in _MERMAID_CLASSDEFS.items():
        lines.append(f"  classDef {node_type} {style};")
    for n in _sorted_nodes(graph):
        label = n.id.replace('"', "'")
        lines.append(f'  {_mermaid_id(n.id)}["{label}"]:::{n.type}')
    for e in _sorted_edges(graph):
        lines.append(f"  {_mermaid_id(e.source)} -->|{e.type}| {_mermaid_id(e.target)}")
    lines.append("```")
    return "\n".join(lines)


def _agent_channels(graph: Graph, agent_id: str) -> list[str]:
    return sorted(
        e.target for e in graph.edges if e.source == agent_id and e.type == EDGE_PRESENT_ON
    )


def _inventory_lines(graph: Graph) -> list[str]:
    agents = sorted((n for n in graph.nodes.values() if n.type == NODE_AGENT), key=lambda n: n.id)
    if not agents:
        return ["_No agents in scope._"]
    lines = [
        "| Repo | Agent | Backend | Model | Channels | Tags | System prompt |",
        "|------|-------|---------|-------|----------|------|---------------|",
    ]
    for n in agents:
        repo = n.id.split("/", 1)[0]
        p = n.props
        channels = ", ".join(_agent_channels(graph, n.id)) or "—"
        tags = ", ".join(p.get("tags") or []) or "—"
        sysp = "yes" if p.get("has_system_prompt") else "no"
        lines.append(
            f"| `{repo}` | `{p.get('suffix', '')}` | {p.get('backend') or '—'} | "
            f"{p.get('model') or '—'} | {channels} | {tags} | {sysp} |"
        )
    return lines


def _skill_ownership_lines(graph: Graph) -> list[str]:
    supplier_of: dict[str, str] = {}
    consumers: dict[str, list[str]] = {}
    for e in graph.edges:
        if e.type == EDGE_SUPPLIES:
            supplier_of.setdefault(e.target, e.source)
        elif e.type == EDGE_CONSUMES:
            consumers.setdefault(e.target, []).append(e.source)
    skills = sorted(n.id for n in graph.nodes.values() if n.type == NODE_SKILL)
    if not skills:
        return ["_No skills in scope._"]
    lines = []
    for s in skills:
        up = supplier_of.get(s, "?")
        downs = ", ".join(f"`{d}`" for d in sorted(consumers.get(s, []))) or "—"
        lines.append(f"- `{s}` — supplied by `{up}`; consumed by {downs}")
    return lines


def _edge_list_lines(graph: Graph) -> list[str]:
    if not graph.edges:
        return ["_No edges in scope._"]
    return [f"- `{e.source}` --{e.type}--> `{e.target}`  ({e.basis})" for e in _sorted_edges(graph)]


def _signal_lines(signals: list[Signal]) -> list[str]:
    if not signals:
        return ["_No candidate signals._"]
    lines = []
    for s in sorted(signals, key=lambda x: (x.kind, x.subject)):
        lines.append(f"- **{s.kind}** `{s.subject}`: {s.detail}")
    return lines


def render_markdown(
    graph: Graph,
    signals: list[Signal],
    *,
    scope: str,
    generated: str,
    title: str,
) -> str:
    lines: list[str] = [
        f"# {title}",
        "",
        f"> Generated by `steward overview` on {generated}. Scope: `{scope}`.",
        "> Graph edges are **observed** (each cites its source). Candidate",
        "> signals are deterministic flags for interpretation — **not**",
        "> conclusions. Inferred relationships and suggestions are for the",
        "> narrating agent (see the final section).",
        "",
        "## Observed facts",
        "",
        "### Agent inventory",
        "",
        *_inventory_lines(graph),
        "",
        "### Skill ownership",
        "",
        *_skill_ownership_lines(graph),
        "",
        "## Relationship graph",
        "",
        to_mermaid(graph),
        "",
        "Edges (with provenance):",
        "",
        *_edge_list_lines(graph),
        "",
        "## Candidate signals",
        "",
        "_Flags for interpretation, not conclusions._",
        "",
        *_signal_lines(signals),
        "",
        "## For the narrating agent",
        "",
        "Produce three layers from the evidence above:",
        "",
        "1. **Observed facts** — the inventory + graph edges above (each edge cites its source).",
        "2. **Inferred relationships** — map the observed edges onto the interpretive",
        "   vocabulary (owns / depends-on / observes / aligns / documents / secures /",
        "   governs / overlaps-with / supports). Mark these clearly as inferred.",
        "3. **Suggestions** — seeded by the candidate signals (missing owner, overlap,",
        "   over-loaded agent, …). Keep them separate from the factual overview.",
        "",
        "Do not present inferred items or suggestions as facts.",
        "",
    ]
    return "\n".join(lines)
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_graph.py -v`
Expected: PASS (16 passed)

- [ ] **Step 5: Commit**

```bash
git add steward/cli/_commands/_graph.py tests/test_graph.py
git commit -m "feat(overview): markdown + mermaid renderer"
```

---

## Task 9: `overview` command + registration

**Files:**

- Create: `steward/cli/_commands/overview.py`
- Modify: `steward/cli/__init__.py:35-52`
- Test: `tests/test_cli_overview.py`

- [ ] **Step 1: Write the failing test**

```python
# tests/test_cli_overview.py
"""End-to-end tests for `steward overview`.

Mirrors test_cli_doctor_siblings.py: fakes a workspace under tmp_path,
runs the CLI via --workspace-root, and chdir's into the real steward
checkout so steward-root + ledger resolution works.
"""

from __future__ import annotations

import json
import os
from pathlib import Path

import pytest
import yaml

from steward.cli import main
from steward.cli._errors import EXIT_USER_ERROR

REPO_ROOT = Path(__file__).resolve().parent.parent


def _seed(workspace: Path, name: str, agents: list[dict]) -> Path:
    repo = workspace / name
    repo.mkdir()
    (repo / "culture.yaml").write_text(yaml.safe_dump({"agents": agents}))
    return repo


def test_overview_siblings_json(tmp_path: Path, capsys: pytest.CaptureFixture[str]):
    workspace = tmp_path / "ws"
    workspace.mkdir()
    _seed(workspace, "alpha", [{"suffix": "a", "backend": "claude"}])
    _seed(workspace, "beta", [{"suffix": "b", "backend": "acp"}])

    cwd = os.getcwd()
    os.chdir(REPO_ROOT)
    try:
        rc = main(["overview", "--scope", "siblings", "--json", "--workspace-root", str(workspace)])
    finally:
        os.chdir(cwd)

    captured = capsys.readouterr()
    assert rc == 0, captured.err
    payload = json.loads(captured.out)
    assert payload["scope"] == "siblings"
    node_ids = {n["id"] for n in payload["nodes"]}
    assert {"alpha", "beta", "alpha/a", "beta/b"} <= node_ids


def test_overview_siblings_markdown_has_mermaid(tmp_path: Path, capsys: pytest.CaptureFixture[str]):
    workspace = tmp_path / "ws"
    workspace.mkdir()
    _seed(workspace, "alpha", [{"suffix": "a", "backend": "claude"}])

    cwd = os.getcwd()
    os.chdir(REPO_ROOT)
    try:
        rc = main(["overview", "--scope", "siblings", "--workspace-root", str(workspace)])
    finally:
        os.chdir(cwd)

    captured = capsys.readouterr()
    assert rc == 0, captured.err
    assert "# AgentCulture ecosystem overview" in captured.out
    assert "```mermaid" in captured.out
    assert "## For the narrating agent" in captured.out


def test_overview_self_subgraph(tmp_path: Path, capsys: pytest.CaptureFixture[str]):
    workspace = tmp_path / "ws"
    workspace.mkdir()
    alpha = _seed(workspace, "alpha", [{"suffix": "a", "backend": "claude"}])
    _seed(workspace, "beta", [{"suffix": "b", "backend": "claude"}])

    cwd = os.getcwd()
    os.chdir(REPO_ROOT)
    try:
        rc = main(["overview", str(alpha), "--workspace-root", str(workspace)])
    finally:
        os.chdir(cwd)

    captured = capsys.readouterr()
    assert rc == 0, captured.err
    assert "# Overview: alpha" in captured.out


def test_overview_self_requires_target(capsys: pytest.CaptureFixture[str]):
    cwd = os.getcwd()
    os.chdir(REPO_ROOT)
    try:
        rc = main(["overview"])
    finally:
        os.chdir(cwd)
    captured = capsys.readouterr()
    assert rc == EXIT_USER_ERROR
    assert "target path is required" in captured.err
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_cli_overview.py -v`
Expected: FAIL — argparse rejects the unknown `overview` command (`invalid choice: 'overview'`).

- [ ] **Step 3: Write minimal implementation**

Create `steward/cli/_commands/overview.py`:

```python
# steward/cli/_commands/overview.py
"""``steward overview`` — emit a deterministic ecosystem evidence pack.

Assembles a typed relationship graph (see :mod:`_graph`) plus candidate
signals from sibling repos and prints it as markdown (with a mermaid graph)
or, with ``--json``, a script-parseable structure. Diagnostic-only: the
agent that ran steward narrates the inferred relationships + suggestions.

Two scopes, mirroring ``doctor``:

* ``--scope self <target>`` (default): the target repo's node + its 1-hop
  neighborhood, plus that repo's inventory.
* ``--scope siblings``: the full corpus graph (steward itself excluded,
  same as ``doctor --scope siblings``).
"""

from __future__ import annotations

import argparse
from datetime import date

from steward.cli._commands import _corpus, _graph
from steward.cli._commands.doctor import (
    _resolve_steward_repo_root,
    _resolve_target,
    _resolve_workspace_root,
)
from steward.cli._errors import EXIT_USER_ERROR, StewardError
from steward.cli._output import emit_diagnostic, emit_result


def register(sub: argparse._SubParsersAction) -> None:
    parser = sub.add_parser(
        "overview",
        help="Summarize the agent ecosystem (inventory + relationship graph + signals).",
        description=(
            "Sense-making companion to `doctor`. Emits a deterministic "
            "evidence pack — agent inventory, a typed relationship graph "
            "(markdown+mermaid, or --json), and candidate signals — for an "
            "agent to narrate observed facts / inferred relationships / "
            "suggestions from. Does not call an LLM and does not mutate repos."
        ),
    )
    parser.add_argument(
        "target",
        nargs="?",
        help="Path to a sibling repo directory (required for --scope self).",
    )
    parser.add_argument(
        "--scope",
        choices=["self", "siblings"],
        default="self",
        help="self (default): TARGET + its 1-hop neighborhood. siblings: the full corpus graph.",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Emit the typed graph + signals as JSON to stdout instead of markdown.",
    )
    parser.add_argument(
        "--workspace-root",
        type=__import__("pathlib").Path,
        default=None,
        help="Override the workspace root (default: parent of the steward checkout).",
    )
    parser.set_defaults(func=_handle)


def _build_full(args: argparse.Namespace, *, skip_steward: bool):
    steward_root = _resolve_steward_repo_root()
    workspace_root = _resolve_workspace_root(args, steward_root)
    skip = {steward_root.name} if skip_steward else set()
    agents, manifest_errors = _corpus.discover_agents(workspace_root, skip_repos=skip)
    repo_paths = sorted({a.repo_path for a in agents}, key=lambda p: p.name)
    ledger_path = steward_root / "docs" / "skill-sources.md"
    graph = _graph.build_graph(agents, repo_paths, ledger_path)
    return graph, repo_paths, manifest_errors


def _handle(args: argparse.Namespace) -> int:
    generated = date.today().isoformat()

    if args.scope == "siblings":
        graph, repo_paths, manifest_errors = _build_full(args, skip_steward=True)
        repo_skill_dirs = _graph.collect_repo_skill_dirs(repo_paths)
        signals = _graph.detect_signals(graph, repo_skill_dirs)
        scope, title = "siblings", "AgentCulture ecosystem overview"
    else:
        if not args.target:
            raise StewardError(
                code=EXIT_USER_ERROR,
                message="target path is required for --scope self",
                remediation="pass a path to a sibling repo, e.g. `steward overview ../culture`",
            )
        target = _resolve_target(args.target)
        graph, _repo_paths, manifest_errors = _build_full(args, skip_steward=False)
        repo_id = target.name
        graph.add_node(repo_id, _graph.NODE_REPO, path=str(target))
        graph = graph.subgraph(repo_id, hops=1)
        signals = _graph.detect_signals(graph, _graph.collect_repo_skill_dirs([target]))
        scope, title = "self", f"Overview: {repo_id}"

    for err in manifest_errors:
        emit_diagnostic(f"manifest: [{err.repo_name}] {err.message}")

    if args.json:
        emit_result(_graph.to_json(graph, signals, scope=scope, generated=generated))
    else:
        emit_result(
            _graph.render_markdown(graph, signals, scope=scope, generated=generated, title=title)
        )
    return 0
```

Then register it in `steward/cli/__init__.py`. In `_build_parser()`, add the import alongside the others and the `register` call:

```python
    # in the deferred-import block (after the show/doctor/asu imports):
    from steward.cli._commands import overview as _overview_cmd

    # ... after _asu_cmd.register(sub):
    _overview_cmd.register(sub)
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_cli_overview.py -v`
Expected: PASS (4 passed)

- [ ] **Step 5: Run the full suite + lint**

Run: `uv run pytest -n auto -q && uv run black --check steward tests && uv run isort --check steward tests && uv run flake8 steward tests && uv run bandit -q -r steward`
Expected: all pass. If `black`/`isort` report changes, run them without `--check` and re-commit. (Note: the `__import__("pathlib").Path` inline in `register` is a deliberate one-liner to avoid a module-level import solely for the type; if `flake8` or review prefers it, replace with a top-level `from pathlib import Path` and use `Path` directly.)

- [ ] **Step 6: Commit**

```bash
git add steward/cli/_commands/overview.py steward/cli/__init__.py tests/test_cli_overview.py
git commit -m "feat(overview): steward overview command + registration"
```

---

## Task 10: Docs + version bump + CHANGELOG

**Files:**

- Modify: `README.md` and/or `CLAUDE.md` (the "Roadmap (CLI surface)" section)
- Modify: `pyproject.toml` + `CHANGELOG.md` (via the bump script)

- [ ] **Step 1: Update the CLI-surface docs**

In `CLAUDE.md` (and `README.md` if it carries the same roadmap), the "Roadmap
(CLI surface)" section currently says _"The CLI ships two verbs today: `steward
show` and `steward doctor`."_ Update it to include `overview` as a third verb,
with one sentence describing it. Suggested text to add after the `doctor`
description:

```markdown
- `steward overview [target] --scope self|siblings [--json]` — sense-making
  companion to `doctor`. Where `doctor` asks "is this sibling healthy?",
  `overview` asks "what exists, how does it fit together, what's missing?".
  Emits a deterministic evidence pack: agent inventory + a typed relationship
  graph (repo/agent/skill/channel/package nodes; declares/supplies/consumes/
  present_on/depends_on/references edges, each citing its source) rendered as
  markdown-with-mermaid (or `--json`), plus candidate signals (orphan skill,
  unowned skill, ledger gap, overlap, over-connected agent, isolated repo).
  Steward stops at observed facts + neutral signals; the agent that ran it
  narrates the inferred-relationships and suggestions layers. No LLM, no repo
  mutation.
```

Also flip the opening line from "two verbs" to "three verbs".

- [ ] **Step 2: Bump the version (minor — new verb)**

Run: `python3 .claude/skills/version-bump/scripts/bump.py minor`
Expected: `pyproject.toml` version goes `0.12.0 → 0.13.0` and a new
`CHANGELOG.md` entry is prepended.

- [ ] **Step 3: Fill in the CHANGELOG entry**

Edit the new `CHANGELOG.md` entry to describe the feature:

```markdown
### Added
- `steward overview [target] --scope self|siblings [--json]` — ecosystem
  sense-making companion to `doctor`. Deterministically assembles a typed
  relationship graph (repo/agent/skill/channel/package nodes; declares/
  supplies/consumes/present_on/depends_on/references edges with provenance)
  from culture.yaml, `docs/skill-sources.md`, sibling `pyproject.toml` deps,
  and CLAUDE.md/README cross-references, plus candidate signals. Emits
  markdown-with-mermaid by default or a neo4j-loadable `--json` structure.
  Observed-facts + signals only — the running agent narrates inferred
  relationships and suggestions. Closes #40.
```

- [ ] **Step 4: Verify version-check will pass + full suite green**

Run: `uv run pytest -n auto -q`
Expected: all pass.
Run: `grep -m1 version pyproject.toml`
Expected: shows `0.13.0` (different from main's `0.12.0`, so the CI
`version-check` job passes).

- [ ] **Step 5: Commit**

```bash
git add CLAUDE.md README.md pyproject.toml CHANGELOG.md
git commit -m "docs(overview): document verb; bump to 0.13.0 (#40)"
```

---

## Task 11: Open the PR

- [ ] **Step 1: Push the branch and open the PR via the cicd skill**

The `cicd` skill (delegating to `agex pr`) is the steward PR path. Open the PR
with a body that references issue #40 and summarizes the evidence-pack model.
Do not hand-sign the body — the cicd reply scripts handle signing; for the PR
description, sign `- steward (Claude)` per the repo convention.

Run (or follow the `cicd` skill):

```bash
git push -u origin feat/overview
```

Then create the PR (title: `feat(overview): steward overview for ecosystem sense-making (#40)`).

- [ ] **Step 2: Watch CI to green**

Use the `cicd` skill's `await` (SonarCloud quality gate + unresolved threads).
Expected: tests, lint, version-check, and Sonar all pass.

---

## Self-Review

**Spec coverage:**

- Evidence-pack model (no LLM) → Task 9 `_handle`, Tasks 1–8 deterministic. ✓
- Typed graph (5 node types, 6 edge types, provenance) → Task 1 constants + Tasks 2–5 extractors. ✓
- All four signal sources (ledger, channels, deps, cross-refs) → Tasks 2–5. ✓
- Channel as its own node type + distinct relationship → Task 2 (`NODE_CHANNEL`, `EDGE_PRESENT_ON`). ✓
- Candidate signals (orphan/unowned/ledger-gap/overlap/over-connected/isolated) → Task 6. ✓
- Markdown-with-mermaid + `--json` neo4j-loadable → Tasks 7–8. ✓
- `--scope self|siblings` mirroring doctor → Task 9. ✓
- stdout-only, `_output` split, exit 0 (diagnostic) / `EXIT_USER_ERROR` on bad invocation → Task 9. ✓
- Version bump + CHANGELOG + docs (CI gate) → Task 10. ✓
- Non-goals (no writes, no mutation, no LLM) → respected throughout. ✓

**Placeholder scan:** No TBD/TODO; every code step is complete. The only flagged
judgment call (the `__import__("pathlib").Path` one-liner) has an explicit
remediation in Task 9 Step 5.

**Type consistency:** `Node`/`Edge`/`Signal`/`Graph` and the `NODE_*`/`EDGE_*`
constants are defined in Task 1 and used verbatim in Tasks 2–9. `build_graph`,
`collect_repo_skill_dirs`, `detect_signals`, `to_json`, `to_mermaid`,
`render_markdown` signatures match between definition (Tasks 6–8) and call sites
(Task 9). `discover_agents` / `Agent` reused from `_corpus` with the real
signature. `_resolve_steward_repo_root`/`_resolve_workspace_root`/`_resolve_target`
imported from `doctor.py` with their real signatures.
