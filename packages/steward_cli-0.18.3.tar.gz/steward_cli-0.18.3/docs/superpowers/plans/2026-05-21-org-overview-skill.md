# `org-overview` Skill Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Ship the `org-overview` skill — Steward-the-agent's reflect-only narration layer over the deterministic `steward overview` CLI, framed as a periodic workplace review of the agent mesh.

**Architecture:** A thin bash runner (`scripts/org-overview.sh`) resolves how to invoke `steward`, picks the scope (all / one agent), and delegates to `steward overview` — adding no interpretation. The interpretation contract (three separated layers: observed facts → inferred relationships → suggestions; reflect-only) lives in `SKILL.md` prose. No LLM, no network, no repo mutation. Output is ephemeral chat.

**Tech Stack:** Bash (the runner), Python/pytest (pinning test mirroring `tests/test_cli_overview.py`), Markdown (SKILL.md + docs), the existing `steward` CLI.

---

## Context the implementer needs

- **The CLI already exists and is merged.** `steward overview` supports
  `steward overview --scope siblings` (all agents), `steward overview <target>`
  (one agent, `--scope self` is the default), `--json`, and
  `--workspace-root <path>`. Its markdown output begins with
  `# AgentCulture ecosystem overview` (siblings) or `# Overview: <name>` (self),
  contains a ` ```mermaid ` graph, a `## Candidate signals` section, and ends
  with a `## For the narrating agent` block. The `--json` form emits
  `{"scope": ..., "nodes": [...], "edges": [...], "signals": [...]}`.
- **Skills convention (enforced by `tests/test_skills_convention.py`):** every
  `.claude/skills/<name>/` ships a `SKILL.md` whose frontmatter `name:` equals
  the directory name, plus a `scripts/` directory. Script files must contain no
  hard-coded user home-directory paths and no per-user dotfile references. These tests
  auto-parametrize over existing skill dirs, so the skill must be created
  atomically (SKILL.md **and** scripts/ together) or the convention tests go
  red mid-plan.
- **Markdown lint:** CI runs `markdownlint-cli2 "**/*.md" "#node_modules" "#.local"`
  with the repo's `.markdownlint-cli2.yaml` (MD013 line-length **disabled**,
  MD060 disabled, MD024 siblings-only). Long prose lines are fine; fenced code
  needs a language; lists and tables need surrounding blank lines.
- **Python lint:** the new test file must pass `black`, `isort`, `flake8`
  (max-line-length 100). Run them via `uv run`.
- **Version bump is mandatory** on every PR (CI `version-check` fails if the
  version equals `main`'s). `main` is `0.13.0`; this PR bumps to `0.14.0`.
- **No broadcast.** This is a new Steward-specific skill (empty downstream
  consumer list), not a behavior change to a *supplied* skill, so
  `steward announce-skill-update` is not run.
- The approved design is `docs/superpowers/specs/2026-05-21-org-overview-skill-design.md`.

## File structure

| File | Responsibility |
|------|----------------|
| `.claude/skills/org-overview/SKILL.md` | Why/when + the three-layer narration contract, signal→suggestion table, reflect-only rule. |
| `.claude/skills/org-overview/scripts/org-overview.sh` | Thin deterministic runner: resolve `steward`, pick scope, delegate to `steward overview`. |
| `tests/test_org_overview_skill.py` | Pins the runner against a fake workspace (siblings scope, self scope, `--json`). |
| `docs/skill-sources.md` | Add the ledger row (upstream `steward`, downstream —, Steward-specific). |
| `CLAUDE.md` | One-sentence pointer from the `steward overview` roadmap bullet to this skill. |
| `pyproject.toml`, `CHANGELOG.md` | Version bump 0.13.0 → 0.14.0 + Added entry. |

---

## Task 1: The `org-overview` skill (runner + SKILL.md + pinning test)

**Files:**

- Create: `tests/test_org_overview_skill.py`
- Create: `.claude/skills/org-overview/scripts/org-overview.sh`
- Create: `.claude/skills/org-overview/SKILL.md`

- [ ] **Step 1: Write the failing test**

Create `tests/test_org_overview_skill.py`:

```python
"""End-to-end tests for the org-overview skill's runner script.

The script (`.claude/skills/org-overview/scripts/org-overview.sh`) is thin
deterministic glue: it resolves how to invoke steward, picks the scope, and
delegates to `steward overview`. These tests pin that glue against a fake
workspace, mirroring tests/test_cli_overview.py's fixture style.
"""

from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path

import pytest
import yaml

REPO_ROOT = Path(__file__).resolve().parent.parent
SCRIPT = REPO_ROOT / ".claude" / "skills" / "org-overview" / "scripts" / "org-overview.sh"


@pytest.fixture(autouse=True)
def _require_bash() -> None:
    if shutil.which("bash") is None:
        pytest.skip("bash not available")


def _seed(workspace: Path, name: str, agents: list[dict]) -> Path:
    repo = workspace / name
    repo.mkdir()
    (repo / "culture.yaml").write_text(yaml.safe_dump({"agents": agents}))
    return repo


def _run(args: list[str]) -> subprocess.CompletedProcess[str]:
    # cwd=REPO_ROOT so steward resolves its own repo root + ledger, matching
    # test_cli_overview.py's chdir(REPO_ROOT).
    return subprocess.run(
        ["bash", str(SCRIPT), *args],
        cwd=REPO_ROOT,
        capture_output=True,
        text=True,
    )


def test_no_target_runs_siblings_scope(tmp_path: Path) -> None:
    workspace = tmp_path / "ws"
    workspace.mkdir()
    _seed(workspace, "alpha", [{"suffix": "a", "backend": "claude"}])
    _seed(workspace, "beta", [{"suffix": "b", "backend": "acp"}])

    result = _run(["--workspace-root", str(workspace)])

    assert result.returncode == 0, result.stderr
    assert "# AgentCulture ecosystem overview" in result.stdout
    assert "```mermaid" in result.stdout
    assert "## For the narrating agent" in result.stdout


def test_target_runs_self_scope(tmp_path: Path) -> None:
    workspace = tmp_path / "ws"
    workspace.mkdir()
    alpha = _seed(workspace, "alpha", [{"suffix": "a", "backend": "claude"}])
    _seed(workspace, "beta", [{"suffix": "b", "backend": "claude"}])

    result = _run([str(alpha), "--workspace-root", str(workspace)])

    assert result.returncode == 0, result.stderr
    assert "# Overview: alpha" in result.stdout
    # alpha and beta are unconnected → the ego graph excludes beta.
    assert "beta" not in result.stdout


def test_json_passthrough(tmp_path: Path) -> None:
    workspace = tmp_path / "ws"
    workspace.mkdir()
    _seed(workspace, "alpha", [{"suffix": "a", "backend": "claude"}])

    result = _run(["--json", "--workspace-root", str(workspace)])

    assert result.returncode == 0, result.stderr
    payload = json.loads(result.stdout)
    assert payload["scope"] == "siblings"
```

- [ ] **Step 2: Run the test to verify it fails**

Run: `uv run pytest tests/test_org_overview_skill.py -v`
Expected: FAIL — the script file does not exist yet, so `bash` returns 127 and
the `result.returncode == 0` / stdout assertions fail.

- [ ] **Step 3: Create the runner script**

Create `.claude/skills/org-overview/scripts/org-overview.sh`:

```bash
#!/usr/bin/env bash
# org-overview — assemble the `steward overview` evidence pack for narration.
#
# Steward-the-agent runs this, then narrates three separated layers
# (observed facts / inferred relationships / suggestions). See SKILL.md.
# This script is deterministic glue only: it resolves how to invoke steward,
# picks the scope, and delegates to `steward overview`. No interpretation.
#
# Usage:
#   org-overview.sh                       # all agents          (--scope siblings)
#   org-overview.sh <target>              # one agent ego graph (--scope self)
#   org-overview.sh --json                # all agents, JSON evidence
#   org-overview.sh <target> --json       # one agent, JSON evidence
#   org-overview.sh --workspace-root DIR  # non-default layout (passthrough)
#
# Contract: the FIRST argument, if it does not start with '-', is the target
# (self scope). All remaining arguments pass through to `steward overview`.
#
# Exit codes:
#   0   success (delegates to `steward overview`)
#   1   environment error (no way to invoke steward)

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SKILL_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
REPO_ROOT="$(cd "$SKILL_DIR/../../.." && pwd)"

# Resolve how to invoke steward: installed console script, then uv, then module.
if command -v steward >/dev/null 2>&1; then
    STEWARD=(steward)
elif [ -f "$REPO_ROOT/pyproject.toml" ] && command -v uv >/dev/null 2>&1; then
    STEWARD=(uv run --project "$REPO_ROOT" steward)
elif command -v python3 >/dev/null 2>&1; then
    STEWARD=(python3 -m steward)
else
    echo "org-overview: cannot invoke steward (need 'steward', 'uv', or 'python3' on PATH)" >&2
    exit 1
fi

# Honor an explicit --scope passed through (advanced use); otherwise pick one.
has_scope=false
for arg in "$@"; do
    case "$arg" in
        --scope|--scope=*) has_scope=true; break ;;
    esac
done

overview_args=()
if [ "$#" -gt 0 ] && [[ "$1" != -* ]]; then
    # First arg is a target → one-agent (self) scope.
    target="$1"; shift
    overview_args+=("$target")
    $has_scope || overview_args+=(--scope self)
else
    # No leading target → whole-mesh corpus.
    $has_scope || overview_args+=(--scope siblings)
fi
overview_args+=("$@")

exec "${STEWARD[@]}" overview "${overview_args[@]}"
```

Make it executable:

```bash
chmod +x .claude/skills/org-overview/scripts/org-overview.sh
```

- [ ] **Step 4: Create `SKILL.md`**

Create `.claude/skills/org-overview/SKILL.md`:

````markdown
---
name: org-overview
description: >
  Review the AgentCulture agent "org" — what agents and skills exist, how they
  relate, and what the relationships imply — like a periodic workplace
  assessment of the mesh. Runs `steward overview` (deterministic facts + typed
  graph + candidate signals), then narrates three separated layers: observed
  facts, inferred relationships, and suggestions (missing owners, overlap,
  overloaded agents, possible new/split/merged agents — i.e. hiring, reorg,
  upskilling). Use when the user asks to survey the mesh, "what agents exist and
  how do they relate", "any overlap / missing owners / overloaded agents",
  "should we split or merge an agent", or "show the graph of everything".
  Reflect-only: names follow-ups but does not act. Steward-specific.
---

# Org Overview — review the agent mesh like a workplace assessment

`steward doctor` asks *"is this agent healthy and aligned?"* (health /
compliance). **`org-overview` asks the sense-making question**: *what agents and
skills exist, how do they relate, and what do those relationships imply?* Think
of it as a periodic review of the mesh's "org" — the agents are the workforce,
their skills are job functions, and the relationships are the reporting and
collaboration lines.

The split that makes this safe: **`steward overview` (the CLI) emits only
deterministic facts** — an agent/skill inventory, a typed relationship graph
(each edge citing its `basis`), and neutral *candidate signals*. It runs no LLM
and mutates nothing. **This skill is where you, the agent, do the
interpretation** — turning those facts into inferred relationships and
suggestions. Keep the two separate: never present an inference as a fact.

## When to use

- The user asks to survey or "review" the agent ecosystem / mesh / "org".
- "What agents exist and how do they relate?" / "show me the graph of everything".
- "Is there overlap between agents?" / "any missing owners?" / "is any agent
  overloaded?"
- "Should we split or merge an agent?" / "do we need a new agent?"
- "Which existing agents are missing a skill they should have?"

## How to run

One script. Pick the scope:

```bash
# All agents — the whole-mesh corpus graph + signals (default)
.claude/skills/org-overview/scripts/org-overview.sh

# One agent — that repo's ego graph (the repo + its directly-incident edges)
.claude/skills/org-overview/scripts/org-overview.sh ../culture

# Machine-readable evidence ({nodes, edges, signals}) for precise reasoning
.claude/skills/org-overview/scripts/org-overview.sh --json
```

A **subset** review (a named handful of agents, not all and not one) has no
dedicated flag — run the all-agents form and **focus your narration** on the
named subset. The full corpus graph is the right substrate because it preserves
the cross-subset edges a per-agent ego graph would drop.

The script prints the CLI's markdown by default: it already contains the mermaid
graph, the candidate-signals section, and a "For the narrating agent" block.
That block is the contract this skill formalizes below.

## Narrate three layers — never blur them

1. **Observed facts.** The inventory and the graph edges, each citing its basis.
   Render the mermaid graph verbatim so the user can "see the graph of
   everything." State only what the CLI reported.
2. **Inferred relationships** (mark these clearly as inferred). Map the observed
   edges onto the interpretive vocabulary: `owns` / `depends-on` / `observes` /
   `aligns` / `documents` / `secures` / `governs` / `overlaps-with` /
   `supports`. This is where "hidden" relationships surface — e.g. two agents
   that both `consume` the same skill *overlap-with* each other even though no
   edge directly connects them.
3. **Suggestions** (kept separate from facts). Seed these from the candidate
   signals — see the mapping below.

### Signal → suggestion (the workplace-assessment deliverables)

| Candidate signal | Suggestion (HR framing) | Named follow-up — do NOT run it |
|------------------|-------------------------|---------------------------------|
| `unowned-skill` | A job function with no owner | Assign it: edit `docs/skill-sources.md`; review the agent with the `agent-config` skill |
| `orphan-skill` | A function nobody uses | Confirm intentional, then retire or promote it |
| `ledger-gap` | A consumer using an unlisted skill | Fix the ledger: edit `docs/skill-sources.md`, then `steward announce-skill-update --skill <name>` |
| `overlap` | Two roles with overlapping duties | **Split or merge** — name the agents and the shared edges; propose the boundary |
| `over-connected-agent` | One agent doing too much | **Split the overloaded agent** — name candidate seams |
| `isolated-repo` | A repo with no relationships | **A possible new agent**, or a missing `declares` / `consumes` link |

## Reflect-only

This skill **sees, reflects, and suggests — it does not act.** For every
suggestion, name the concrete next step *and which skill or command enacts it*
(as in the table above), then stop. Filing an issue (`communicate` skill),
editing a `culture.yaml` (`agent-config` skill), or amending the ledger is a
separate, explicit step the user chooses to take. Output is the chat
conversation; this skill writes nothing to disk and mutates no repo.

## Where the design is written down

- `docs/superpowers/specs/2026-05-21-org-overview-skill-design.md` — this
  skill's design.
- `docs/superpowers/specs/2026-05-21-steward-overview-design.md` — the CLI's
  evidence-pack architecture (node/edge/signal types, the three-layer contract).
- `steward/cli/_commands/_graph.py` → `render_markdown` "For the narrating
  agent" block — the contract this skill formalizes.
````

- [ ] **Step 5: Run the tests to verify they pass**

Run: `uv run pytest tests/test_org_overview_skill.py tests/test_skills_convention.py -v`
Expected: PASS — the three runner tests pass, and the convention tests
(parametrized over the new `org-overview` dir) pass: `SKILL.md` present,
`scripts/` present, frontmatter `name: org-overview` matches the dir, no
per-user paths in the script.

- [ ] **Step 6: Lint the new files**

```bash
uv run black tests/test_org_overview_skill.py
uv run isort tests/test_org_overview_skill.py
uv run flake8 tests/test_org_overview_skill.py
markdownlint-cli2 ".claude/skills/org-overview/SKILL.md"
```

Expected: black/isort report no changes (or reformat in place), flake8 prints
nothing, markdownlint reports `0 error(s)`.

- [ ] **Step 7: Commit**

```bash
git add tests/test_org_overview_skill.py .claude/skills/org-overview/
git commit -m "feat(org-overview): add reflect-only narration skill over steward overview

The org-overview skill is Steward-the-agent's interpretive layer: a thin
runner delegates to \`steward overview\` (deterministic facts/graph/signals),
and SKILL.md carries the three-layer narration contract (observed facts ->
inferred relationships -> suggestions), reflect-only. Pinned by
tests/test_org_overview_skill.py.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>"
```

---

## Task 2: Ledger row + CLAUDE.md pointer

**Files:**

- Modify: `docs/skill-sources.md` (insert one table row after the `notebooklm` row)
- Modify: `CLAUDE.md:134-136` (append a sentence to the `steward overview` roadmap bullet)

- [ ] **Step 1: Add the ledger row**

In `docs/skill-sources.md`, find the `notebooklm` row:

```markdown
| `notebooklm` | `steward` (`.claude/skills/notebooklm/`) | — | Generates GitHub blob URLs for repo docs; auto-detects branch + remote. |
```

Insert this row immediately after it:

```markdown
| `org-overview` | `steward` (`.claude/skills/org-overview/`) | — | Steward-specific — the agent's reflect-only narration layer over the `steward overview` CLI (observed facts → inferred relationships → suggestions). Not portable to siblings without steward installed. |
```

- [ ] **Step 2: Append the CLAUDE.md pointer**

In `CLAUDE.md`, the `steward overview` roadmap bullet currently ends (lines
134–136):

```markdown
  Steward stops at observed facts + neutral signals; the agent that ran it
  narrates the inferred-relationships and suggestions layers. No LLM, no
  repo mutation.
```

Replace that with (adds one sentence; keeps the existing text intact):

```markdown
  Steward stops at observed facts + neutral signals; the agent that ran it
  narrates the inferred-relationships and suggestions layers. No LLM, no
  repo mutation. That narration is driven by this repo's `org-overview` skill
  (`.claude/skills/org-overview/`), which runs `steward overview` and speaks
  the three layers in chat, reflect-only.
```

- [ ] **Step 3: Verify and lint**

```bash
grep -n "org-overview" docs/skill-sources.md CLAUDE.md
markdownlint-cli2 "docs/skill-sources.md" "CLAUDE.md"
```

Expected: the `grep` shows the new ledger row and the new CLAUDE.md sentence;
markdownlint reports `0 error(s)`.

- [ ] **Step 4: Commit**

```bash
git add docs/skill-sources.md CLAUDE.md
git commit -m "docs(org-overview): record skill in ledger + CLAUDE.md roadmap

Adds the org-overview ledger row (upstream steward, downstream none,
Steward-specific) and points the overview roadmap bullet at the skill that
performs the narration.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>"
```

---

## Task 3: Version bump + CHANGELOG entry

**Files:**

- Modify: `pyproject.toml` (version 0.13.0 → 0.14.0)
- Modify: `CHANGELOG.md` (prepend the 0.14.0 entry)

- [ ] **Step 1: Bump the version with a populated Added entry**

Run (pipes the changelog entry as JSON so bump.py formats only an `### Added`
section — matching the house style of the 0.13.0 entry):

```bash
echo '{"added": ["**`org-overview` skill** — Steward-the-agent'"'"'s reflect-only narration layer over the `steward overview` CLI, framed as a periodic workplace review of the agent mesh. A thin runner (`.claude/skills/org-overview/scripts/org-overview.sh`) resolves how to invoke `steward`, picks the scope (all agents via `--scope siblings`, or one agent'"'"'s ego graph via a leading target), and delegates to `steward overview`; `SKILL.md` carries the three-layer narration contract (observed facts → inferred relationships → suggestions) and a signal→suggestion table (missing owner, overlap → split/merge, over-connected → split, isolated → possible new agent). Reflect-only: names the follow-up and which skill enacts it, but takes no action. Steward-specific; no downstream consumers."]}' \
  | python3 .claude/skills/version-bump/scripts/bump.py minor
```

- [ ] **Step 2: Verify the bump**

```bash
grep -m1 '^version' pyproject.toml
sed -n '1,20p' CHANGELOG.md
```

Expected: `version = "0.14.0"`; CHANGELOG.md now starts (after the header) with
`## [0.14.0] - <today>` followed by an `### Added` section containing the
`org-overview` bullet, then the existing `## [0.13.0]` entry.

- [ ] **Step 3: Lint the CHANGELOG**

```bash
markdownlint-cli2 "CHANGELOG.md"
```

Expected: `0 error(s)`.

- [ ] **Step 4: Confirm the full suite + lint are green**

```bash
uv run pytest -n auto -q
uv run black --check steward tests
uv run isort --check-only steward tests
uv run flake8 steward tests
uv run bandit -c pyproject.toml -r steward
markdownlint-cli2 "**/*.md" "#node_modules" "#.local"
```

Expected: all pass — pytest green (including the new test + convention tests),
black/isort report nothing to change, flake8/bandit clean, markdownlint
`0 error(s)`.

- [ ] **Step 5: Commit**

```bash
git add pyproject.toml CHANGELOG.md
git commit -m "chore(release): bump to 0.14.0 (org-overview skill)

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>"
```

---

## After all tasks

Dispatch a final code review over the whole branch, then use
**superpowers:finishing-a-development-branch** to open the PR via the `cicd`
skill (`agex pr open` / `workflow.sh open`), with a body that links the design
spec and notes "no broadcast — Steward-specific skill, empty consumer list."
Address review the usual way (`cicd` triage rules).

## Self-review notes (already checked against the spec)

- **Spec coverage:** runner + three scopes (all/one-agent natively; subset via
  focused narration, documented in SKILL.md) → Task 1; three-layer contract +
  signal→deliverable table + reflect-only → Task 1 SKILL.md; ledger entry +
  CLAUDE.md alignment → Task 2; version bump → Task 3; "no broadcast" noted in
  the Context section and the PR step. Pinning test → Task 1.
- **Placeholder scan:** none — every code block is complete and copy-pasteable.
- **Name/type consistency:** the skill dir, frontmatter `name`, script path,
  ledger row, and CHANGELOG bullet all use `org-overview`; the script's
  scope-selection logic matches the CLI flags the test asserts on
  (`--scope siblings` default, leading-target → `--scope self`, `--json`
  passthrough).
