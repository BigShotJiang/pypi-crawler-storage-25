# Overview Markdown Digest Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Compress `steward overview`'s markdown from ~808 to ~180–200 lines by replacing the duplicated prose edge list with a per-repo/agent connectivity table + a lean (package-free) mermaid, grouping signals, and updating the `org-overview` skill to summarize instead of echo.

**Architecture:** Pure render-layer change in `steward/cli/_commands/_graph.py`. The lossless `--json` (`to_json`), the extractors (`build_graph`, `_corpus`), `detect_signals`, and `overview.py` are untouched. New helpers feed a rewritten `render_markdown`; the `org-overview/SKILL.md` narration contract is updated to match.

**Tech Stack:** Python 3.11+ (stdlib `tomllib`, `re`, `collections.Counter`), pytest (+ xdist), black/isort/flake8 (line length 100).

**Spec:** `docs/superpowers/specs/2026-05-21-overview-digest-design.md`

---

## File Structure

- **Modify** `steward/cli/_commands/_graph.py` — add 5 render helpers, rewrite 2, remove 1, rewrite `render_markdown`. All changes live in the "renderers" half of the file (below `detect_signals`).
- **Modify** `tests/test_graph.py` — add unit tests for each new helper; update `test_render_markdown_has_all_sections` for the new section layout.
- **Modify** `.claude/skills/org-overview/SKILL.md` — update the layer-1 narration guidance + the "How to run" note.
- **Unchanged** `steward/cli/_commands/overview.py`, `to_json`, `tests/test_cli_overview.py`, `tests/test_org_overview_skill.py` (they assert only on the title, `` ```mermaid ``, and `## For the narrating agent`, all retained).

A note on `_md_cell` and `_agent_channels`: both already exist in `_graph.py` (lines ~571 and ~590) and are reused below — do not redefine them.

---

### Task 1: `_structural_subgraph` — drop packages from the graph for the mermaid

**Files:**

- Modify: `steward/cli/_commands/_graph.py`
- Test: `tests/test_graph.py`

- [ ] **Step 1: Write the failing test**

Add to `tests/test_graph.py`:

```python
def test_structural_subgraph_drops_packages_keeps_siblings():
    g = _graph.Graph()
    g.add_node("culture", _graph.NODE_REPO)
    g.add_node("afi-cli", _graph.NODE_REPO)
    g.add_node("pytest", _graph.NODE_PACKAGE)
    g.add_edge("culture", "afi-cli", _graph.EDGE_DEPENDS_ON, "pyproject.toml")  # sibling: keep
    g.add_edge("culture", "pytest", _graph.EDGE_DEPENDS_ON, "pyproject.toml")  # package: drop
    sub = _graph._structural_subgraph(g)
    assert "pytest" not in sub.nodes
    assert {"culture", "afi-cli"} <= set(sub.nodes)
    edges = {(e.source, e.target) for e in sub.edges}
    assert ("culture", "afi-cli") in edges
    assert ("culture", "pytest") not in edges
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_graph.py::test_structural_subgraph_drops_packages_keeps_siblings -v`
Expected: FAIL with `AttributeError: module ... has no attribute '_structural_subgraph'`

- [ ] **Step 3: Write minimal implementation**

In `steward/cli/_commands/_graph.py`, add just below `_sorted_edges` (before `to_json`):

```python
def _node_type(graph: Graph, node_id: str) -> str | None:
    node = graph.nodes.get(node_id)
    return node.type if node else None


def _structural_subgraph(graph: Graph) -> Graph:
    """Graph minus package nodes and any edge touching one.

    The markdown mermaid shows org structure only; repo->package dev-tooling
    edges (the bulk of the corpus) are summarized by `_dependency_spine_line`
    and kept in full in --json. Sibling repo->repo depends_on edges survive
    (both endpoints are repos, not packages).
    """
    sub = Graph()
    for node in graph.nodes.values():
        if node.type == NODE_PACKAGE:
            continue
        sub.add_node(node.id, node.type, **node.props)
    for e in graph.edges:
        if _node_type(graph, e.source) == NODE_PACKAGE:
            continue
        if _node_type(graph, e.target) == NODE_PACKAGE:
            continue
        sub.add_edge(e.source, e.target, e.type, e.basis)
    return sub
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_graph.py::test_structural_subgraph_drops_packages_keeps_siblings -v`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add steward/cli/_commands/_graph.py tests/test_graph.py
git commit -m "feat(overview): _structural_subgraph drops package nodes for the mermaid"
```

---

### Task 2: `_connectivity_lines` — the per-repo/agent stats table

**Files:**

- Modify: `steward/cli/_commands/_graph.py`
- Test: `tests/test_graph.py`

- [ ] **Step 1: Write the failing test**

Add to `tests/test_graph.py`:

```python
def test_connectivity_lines_counts_by_edge_type():
    g = _graph.Graph()
    # supplier repo with no agent
    g.add_node("steward", _graph.NODE_REPO)
    g.add_node("cicd", _graph.NODE_SKILL)
    g.add_edge("steward", "cicd", _graph.EDGE_SUPPLIES, "skill-sources.md")
    # hub repo: 1 agent on 1 channel; consumes cicd; deps on a sibling + a package;
    # references the sibling; referenced by another repo
    g.add_node("culture", _graph.NODE_REPO)
    g.add_node("culture/culture", _graph.NODE_AGENT, suffix="culture")
    g.add_edge("culture", "culture/culture", _graph.EDGE_DECLARES, "culture.yaml")
    g.add_node("#general", _graph.NODE_CHANNEL)
    g.add_edge("culture/culture", "#general", _graph.EDGE_PRESENT_ON, "culture.yaml")
    g.add_edge("culture", "cicd", _graph.EDGE_CONSUMES, "skill-sources.md")
    g.add_node("afi-cli", _graph.NODE_REPO)
    g.add_edge("culture", "afi-cli", _graph.EDGE_DEPENDS_ON, "pyproject.toml")  # sibling
    g.add_node("pytest", _graph.NODE_PACKAGE)
    g.add_edge("culture", "pytest", _graph.EDGE_DEPENDS_ON, "pyproject.toml")  # package
    g.add_edge("culture", "afi-cli", _graph.EDGE_REFERENCES, "CLAUDE.md/README.md")  # refs out
    g.add_node("daria", _graph.NODE_REPO)
    g.add_edge("daria", "culture", _graph.EDGE_REFERENCES, "CLAUDE.md/README.md")  # refs in

    body = "\n".join(_graph._connectivity_lines(g))
    # full column headers (no abbreviations)
    assert "Skills supplied" in body and "References in" in body and "Packages" in body
    # steward: supplies 1, rest 0, no agents
    assert "| steward (—) | 1 | 0 | 0 | 0 | 0 | 0 | 0 |" in body
    # culture: supplied 0, consumed 1, channels 1, sibling 1, refs-in 1, refs-out 1, packages 1
    assert "| culture (culture) | 0 | 1 | 1 | 1 | 1 | 1 | 1 |" in body
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_graph.py::test_connectivity_lines_counts_by_edge_type -v`
Expected: FAIL with `AttributeError: ... '_connectivity_lines'`

- [ ] **Step 3: Write minimal implementation**

In `_graph.py`, add below `_structural_subgraph`:

```python
def _connectivity_lines(graph: Graph) -> list[str]:
    """The org graph as per-repo statistics: degree broken down by edge type.

    One row per repo (with the agent suffixes it declares noted), so supplier
    repos that declare no agent and multi-agent repos are both represented.
    All values are observed counts — the narrating agent does the inferring.
    """
    repos = sorted(n.id for n in graph.nodes.values() if n.type == NODE_REPO)
    if not repos:
        return ["_No repos in scope._"]
    agents_of: dict[str, list[str]] = {}
    for e in graph.edges:
        if e.type == EDGE_DECLARES:
            agents_of.setdefault(e.source, []).append(e.target)
    header = (
        "| Repo (agents) | Skills supplied | Skills consumed | Channels "
        "| Sibling deps | References in | References out | Packages |"
    )
    lines = [header, "|---|---|---|---|---|---|---|---|"]
    for repo in repos:
        agents = sorted(agents_of.get(repo, []))
        suffixes = [a.split("/", 1)[1] if "/" in a else a for a in agents]
        label = f"{repo} ({', '.join(suffixes)})" if suffixes else f"{repo} (—)"
        agent_set = set(agents)
        supplied = consumed = sib = pkg = refs_in = refs_out = 0
        channels: set[str] = set()
        for e in graph.edges:
            if e.type == EDGE_SUPPLIES and e.source == repo:
                supplied += 1
            elif e.type == EDGE_CONSUMES and e.source == repo:
                consumed += 1
            elif e.type == EDGE_DEPENDS_ON and e.source == repo:
                if _node_type(graph, e.target) == NODE_REPO:
                    sib += 1
                else:
                    pkg += 1
            elif e.type == EDGE_REFERENCES and e.target == repo:
                refs_in += 1
            elif e.type == EDGE_REFERENCES and e.source == repo:
                refs_out += 1
            elif e.type == EDGE_PRESENT_ON and e.source in agent_set:
                channels.add(e.target)
        lines.append(
            f"| {_md_cell(label)} | {supplied} | {consumed} | {len(channels)} "
            f"| {sib} | {refs_in} | {refs_out} | {pkg} |"
        )
    return lines
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_graph.py::test_connectivity_lines_counts_by_edge_type -v`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add steward/cli/_commands/_graph.py tests/test_graph.py
git commit -m "feat(overview): _connectivity_lines renders the graph as per-repo stats"
```

---

### Task 3: `_dependency_spine_line` — collapse package edges to a one-line summary

**Files:**

- Modify: `steward/cli/_commands/_graph.py`
- Test: `tests/test_graph.py`

- [ ] **Step 1: Write the failing tests**

Add to `tests/test_graph.py`:

```python
def test_dependency_spine_line_threshold_and_count():
    g = _graph.Graph()
    for r in ("a", "b", "c"):
        g.add_node(r, _graph.NODE_REPO)
    g.add_node("shared", _graph.NODE_PACKAGE)
    g.add_node("rare", _graph.NODE_PACKAGE)
    # shared: used by a,b,c (>= ceil(3/2)=2 -> spine); rare: a only (< 2 -> counted)
    for r in ("a", "b", "c"):
        g.add_edge(r, "shared", _graph.EDGE_DEPENDS_ON, "pyproject.toml")
    g.add_edge("a", "rare", _graph.EDGE_DEPENDS_ON, "pyproject.toml")
    line = _graph._dependency_spine_line(g)
    assert "shared" in line
    assert "1 further distinct external packages" in line


def test_dependency_spine_line_single_repo_is_count_only():
    g = _graph.Graph()
    g.add_node("solo", _graph.NODE_REPO)
    g.add_node("p1", _graph.NODE_PACKAGE)
    g.add_node("p2", _graph.NODE_PACKAGE)
    g.add_edge("solo", "p1", _graph.EDGE_DEPENDS_ON, "pyproject.toml")
    g.add_edge("solo", "p2", _graph.EDGE_DEPENDS_ON, "pyproject.toml")
    assert "solo depends on 2 external packages" in _graph._dependency_spine_line(g)


def test_dependency_spine_line_no_packages():
    g = _graph.Graph()
    g.add_node("solo", _graph.NODE_REPO)
    assert "none" in _graph._dependency_spine_line(g).lower()
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/test_graph.py -k dependency_spine_line -v`
Expected: FAIL with `AttributeError: ... '_dependency_spine_line'`

- [ ] **Step 3: Write minimal implementation**

In `_graph.py`, add below `_connectivity_lines`:

```python
def _dependency_spine_line(graph: Graph) -> str:
    """One-line summary of repo->package dependency edges (dropped from the graph).

    A package depended on by >= half the repos that declare any package
    dependency is "spine" (listed); the rest are reported as a count. With a
    single such repo (e.g. --scope self) the spine notion is degenerate, so
    just report that repo's package count. Full edges remain in --json.
    """
    pkg_consumers: dict[str, set[str]] = {}  # package -> repos depending on it
    repos_with_pkgs: set[str] = set()
    for e in graph.edges:
        if e.type == EDGE_DEPENDS_ON and _node_type(graph, e.target) == NODE_PACKAGE:
            pkg_consumers.setdefault(e.target, set()).add(e.source)
            repos_with_pkgs.add(e.source)
    if not pkg_consumers:
        return "Dependency spine: none (no package dependencies in scope)."
    if len(repos_with_pkgs) <= 1:
        only = next(iter(repos_with_pkgs))
        return (
            f"Dependency spine: {only} depends on {len(pkg_consumers)} external "
            "packages (full edges in --json)."
        )
    threshold = (len(repos_with_pkgs) + 1) // 2  # ceil(n / 2)
    spine = sorted(p for p, repos in pkg_consumers.items() if len(repos) >= threshold)
    rest = len(pkg_consumers) - len(spine)
    spine_str = ", ".join(spine) if spine else "none"
    return (
        f"Dependency spine: {len(repos_with_pkgs)} repos; shared (≥{threshold} repos): "
        f"{spine_str}; {rest} further distinct external packages. "
        "Full package edges in --json."
    )
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/test_graph.py -k dependency_spine_line -v`
Expected: 3 PASS

- [ ] **Step 5: Commit**

```bash
git add steward/cli/_commands/_graph.py tests/test_graph.py
git commit -m "feat(overview): _dependency_spine_line summarizes dropped package edges"
```

---

### Task 4: `_provenance_legend` — replace per-edge basis with a type→source legend

**Files:**

- Modify: `steward/cli/_commands/_graph.py`
- Test: `tests/test_graph.py`

- [ ] **Step 1: Write the failing test**

Add to `tests/test_graph.py`:

```python
def test_provenance_legend_covers_every_basis():
    legend = _graph._provenance_legend()
    for basis in ("culture.yaml", "skill-sources.md", "pyproject.toml", "CLAUDE.md/README.md"):
        assert basis in legend
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_graph.py::test_provenance_legend_covers_every_basis -v`
Expected: FAIL with `AttributeError: ... '_provenance_legend'`

- [ ] **Step 3: Write minimal implementation**

In `_graph.py`, add below `_dependency_spine_line`:

```python
def _provenance_legend() -> str:
    """Every edge's basis is a pure function of its type (see the extractors),
    so one legend conveys what a per-edge basis column repeated for every edge.
    """
    return (
        "Provenance by edge type: declares, present_on ← culture.yaml · "
        "supplies, consumes ← skill-sources.md · depends_on ← pyproject.toml · "
        "references ← CLAUDE.md/README.md"
    )
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_graph.py::test_provenance_legend_covers_every_basis -v`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add steward/cli/_commands/_graph.py tests/test_graph.py
git commit -m "feat(overview): _provenance_legend replaces per-edge basis list"
```

---

### Task 5: Rewrite `_signal_lines` — group signals

**Files:**

- Modify: `steward/cli/_commands/_graph.py:647-653` (the current `_signal_lines`)
- Test: `tests/test_graph.py`

- [ ] **Step 1: Write the failing tests**

Add to `tests/test_graph.py`:

```python
def test_signal_lines_groups_ledger_gap_by_skill():
    signals = [
        _graph.Signal("ledger-gap", "alpha/cicd", "..."),
        _graph.Signal("ledger-gap", "beta/cicd", "..."),
        _graph.Signal("ledger-gap", "alpha/run-tests", "..."),
        _graph.Signal("orphan-skill", "notebooklm", "supplied by `steward` ..."),
        _graph.Signal(
            "unowned-skill", "telegram",
            "present in `telek/.claude/skills/` but no upstream recorded in the ledger",
        ),
    ]
    body = "\n".join(_graph._signal_lines(signals))
    assert "`cicd` ← +2: alpha, beta" in body  # two repos collapse to one line
    assert "`run-tests` ← +1: alpha" in body
    assert "orphan skills (supplied, no consumer recorded): notebooklm" in body
    assert "unowned skills (on disk, no upstream): telegram (telek)" in body


def test_signal_lines_keeps_other_kinds_individual():
    signals = [_graph.Signal("overlap", "r/a ~ r/b", "share tags: x, y")]
    body = "\n".join(_graph._signal_lines(signals))
    assert "**overlap** `r/a ~ r/b`" in body


def test_signal_lines_empty():
    assert _graph._signal_lines([]) == ["_No candidate signals._"]
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/test_graph.py -k signal_lines -v`
Expected: `test_signal_lines_groups_ledger_gap_by_skill` and `test_signal_lines_keeps_other_kinds_individual` FAIL (current output is one ungrouped bullet per signal); `test_signal_lines_empty` already passes.

- [ ] **Step 3: Write the implementation**

First add this module-level regex near the other `re.compile` definitions (e.g. just after `_DEP_NAME_RE` around line 209):

```python
# unowned-skill detail format: "present in `<repo>/.claude/skills/` but ...".
# The repo is recovered for display; the structured form stays in --json.
_UNOWNED_REPO_RE = re.compile(r"present in `([^/`]+)/")
```

Then replace the existing `_signal_lines` function:

```python
def _signal_lines(signals: list[Signal]) -> list[str]:
    if not signals:
        return ["_No candidate signals._"]
    by_kind: dict[str, list[Signal]] = {}
    for s in signals:
        by_kind.setdefault(s.kind, []).append(s)
    lines: list[str] = []

    # ledger-gap: subject is "repo/skill"; group by skill (the unit you edit).
    gaps = by_kind.get("ledger-gap", [])
    if gaps:
        per_skill: dict[str, list[str]] = {}
        for s in gaps:
            repo, _, skill = s.subject.partition("/")
            per_skill.setdefault(skill, []).append(repo)
        lines.append("Ledger drift — skill-sources.md downstream column is missing:")
        for skill in sorted(per_skill):
            repos = sorted(per_skill[skill])
            lines.append(f"- `{skill}` ← +{len(repos)}: {', '.join(repos)}")

    orphans = sorted(s.subject for s in by_kind.get("orphan-skill", []))
    if orphans:
        lines.append("orphan skills (supplied, no consumer recorded): " + ", ".join(orphans))

    unowned = by_kind.get("unowned-skill", [])
    if unowned:
        parts = []
        for s in sorted(unowned, key=lambda x: x.subject):
            m = _UNOWNED_REPO_RE.search(s.detail)
            parts.append(f"{s.subject} ({m.group(1)})" if m else s.subject)
        lines.append("unowned skills (on disk, no upstream): " + ", ".join(parts))

    # Any other kinds (overlap / over-connected-agent / isolated-repo) are rare
    # and individually meaningful — keep one explicit line each.
    grouped = {"ledger-gap", "orphan-skill", "unowned-skill"}
    others = sorted(
        (s for s in signals if s.kind not in grouped),
        key=lambda x: (x.kind, x.subject),
    )
    for s in others:
        lines.append(f"- **{s.kind}** `{s.subject}`: {s.detail}")
    return lines
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/test_graph.py -k signal_lines -v`
Expected: 3 PASS

- [ ] **Step 5: Commit**

```bash
git add steward/cli/_commands/_graph.py tests/test_graph.py
git commit -m "feat(overview): group candidate signals (ledger-gap by skill, others by kind)"
```

---

### Task 6: Rewrite `_inventory_lines` — summary line + suppress all-empty columns

**Files:**

- Modify: `steward/cli/_commands/_graph.py` (the import block at top, and `_inventory_lines` ~596-616)
- Test: `tests/test_graph.py`

- [ ] **Step 1: Write the failing test**

Add to `tests/test_graph.py`:

```python
def test_inventory_lines_summary_and_suppresses_empty_columns():
    g = _graph.Graph()
    g.add_node("culture", _graph.NODE_REPO)
    g.add_node(
        "culture/culture", _graph.NODE_AGENT,
        suffix="culture", backend="claude", has_system_prompt=True,
    )
    g.add_edge("culture", "culture/culture", _graph.EDGE_DECLARES, "culture.yaml")
    lines = _graph._inventory_lines(g)
    body = "\n".join(lines)
    assert "1 agents across 1 repos" in body
    assert "claude ×1" in body
    assert "1 with a system prompt" in body
    header = next(line for line in lines if line.startswith("| Repo"))
    # Model / Channels / Tags are entirely empty here -> suppressed
    assert "Model" not in header
    assert "Channels" not in header
    assert "Tags" not in header
    # always-shown columns stay
    assert "Backend" in header and "System prompt" in header
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_graph.py::test_inventory_lines_summary_and_suppresses_empty_columns -v`
Expected: FAIL (current `_inventory_lines` emits no summary line and always renders the fixed 7-column header, so `"Model" not in header` fails)

- [ ] **Step 3: Write the implementation**

Add the import at the top of `_graph.py` (with the other stdlib imports, after `import re`):

```python
from collections import Counter
```

Then replace the existing `_inventory_lines` function:

```python
def _inventory_lines(graph: Graph) -> list[str]:
    agents = sorted(
        (n for n in graph.nodes.values() if n.type == NODE_AGENT), key=lambda n: n.id
    )
    if not agents:
        return ["_No agents in scope._"]
    repos = sum(1 for n in graph.nodes.values() if n.type == NODE_REPO)
    backends = Counter(str(n.props.get("backend") or "—") for n in agents)
    backend_str = ", ".join(f"{b} ×{c}" for b, c in sorted(backends.items()))
    sysp = sum(1 for n in agents if n.props.get("has_system_prompt"))
    on_chan = sum(1 for n in agents if _agent_channels(graph, n.id))
    summary = (
        f"{len(agents)} agents across {repos} repos · backends: {backend_str} · "
        f"{sysp} with a system prompt · {on_chan} present on channels."
    )

    rows = []
    for n in agents:
        p = n.props
        rows.append(
            {
                "Repo": n.id.split("/", 1)[0],
                "Agent": str(p.get("suffix", "")),
                "Backend": str(p.get("backend") or "—"),
                "Model": str(p.get("model") or "—"),
                "Channels": ", ".join(_agent_channels(graph, n.id)) or "—",
                "Tags": ", ".join(p.get("tags") or []) or "—",
                "System prompt": "yes" if p.get("has_system_prompt") else "no",
            }
        )
    cols = ["Repo", "Agent", "Backend", "Model", "Channels", "Tags", "System prompt"]
    always = {"Repo", "Agent", "Backend", "System prompt"}
    shown = [c for c in cols if c in always or any(r[c] != "—" for r in rows)]

    lines = [summary, ""]
    lines.append("| " + " | ".join(shown) + " |")
    lines.append("|" + "|".join("---" for _ in shown) + "|")
    for r in rows:
        cells = [
            f"`{_md_cell(r[c])}`" if c in ("Repo", "Agent") else _md_cell(r[c]) for c in shown
        ]
        lines.append("| " + " | ".join(cells) + " |")
    return lines
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_graph.py::test_inventory_lines_summary_and_suppresses_empty_columns -v`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add steward/cli/_commands/_graph.py tests/test_graph.py
git commit -m "feat(overview): inventory summary line + suppress all-empty columns"
```

---

### Task 7: Rewrite `render_markdown` + remove the prose edge list

**Files:**

- Modify: `steward/cli/_commands/_graph.py` (`render_markdown` ~656-711; remove `_edge_list_lines` ~641-644)
- Test: `tests/test_graph.py` (update `test_render_markdown_has_all_sections`)

- [ ] **Step 1: Update the test to the new layout**

Replace the existing `test_render_markdown_has_all_sections` in `tests/test_graph.py` with:

```python
def test_render_markdown_has_all_sections():
    g = _graph.Graph()
    g.add_node("steward", _graph.NODE_REPO, path="/x")
    g.add_node(
        "steward/steward", _graph.NODE_AGENT,
        suffix="steward", backend="claude", has_system_prompt=False,
    )
    g.add_edge("steward", "steward/steward", _graph.EDGE_DECLARES, "culture.yaml")
    g.add_node("cicd", _graph.NODE_SKILL)
    g.add_edge("steward", "cicd", _graph.EDGE_SUPPLIES, "skill-sources.md")
    signals = [_graph.Signal("orphan-skill", "cicd", "no consumer")]
    md = _graph.render_markdown(
        g, signals, scope="siblings", generated="2026-05-21",
        title="AgentCulture ecosystem overview",
    )
    assert "# AgentCulture ecosystem overview" in md
    assert "## Inventory" in md
    assert "## Org connectivity (per repo / agent)" in md
    assert "## Org graph (structural edges)" in md
    assert "```mermaid" in md
    assert "## Candidate signals" in md
    assert "orphan skills (supplied, no consumer recorded): cicd" in md
    assert "## For the narrating agent" in md
    # the duplicated per-edge prose list is gone; legend carries provenance
    assert "--supplies-->" not in md
    assert "Provenance by edge type" in md
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_graph.py::test_render_markdown_has_all_sections -v`
Expected: FAIL (current render emits `## Observed facts`, the prose `--supplies-->` list, and no `## Org connectivity ...`)

- [ ] **Step 3: Rewrite `render_markdown` and delete `_edge_list_lines`**

Delete the `_edge_list_lines` function entirely (it has no other caller — confirmed in Step 4 below). Replace `render_markdown` with:

```python
def render_markdown(
    graph: Graph,
    signals: list[Signal],
    *,
    scope: str,
    generated: str,
    title: str,
) -> str:
    lines: list[str] = [
        f"# {title}",
        "",
        f"> Generated by `steward overview` on {generated}. Scope: `{scope}`.",
        "> Edges are **observed** (provenance by type — legend under the graph).",
        "> Candidate signals are flags, **not** conclusions; the inferred and",
        "> suggestion layers are the narrating agent's job (see the final section).",
        "",
        "## Inventory",
        "",
        *_inventory_lines(graph),
        "",
        "## Org connectivity (per repo / agent)",
        "",
        *_connectivity_lines(graph),
        "",
        "## Org graph (structural edges)",
        "",
        to_mermaid(_structural_subgraph(graph)),
        "",
        _provenance_legend(),
        "",
        _dependency_spine_line(graph),
        "",
        "## Candidate signals (flags, not conclusions)",
        "",
        *_signal_lines(signals),
        "",
        "## For the narrating agent",
        "",
        "Narrate three separated layers: **observed facts** (the tables + graph",
        "above), **inferred relationships** (map edges onto owns / depends-on /",
        "observes / aligns / governs / overlaps-with / supports — mark as inferred),",
        "and **suggestions** (seeded by the signals). Don't present inferences as",
        "facts; read `--json` for exact per-edge / per-signal lists before acting.",
        "Full contract: `org-overview/SKILL.md`.",
        "",
    ]
    return "\n".join(lines)
```

- [ ] **Step 4: Confirm `_edge_list_lines` has no remaining references**

Run: `grep -rn "_edge_list_lines" steward/ tests/`
Expected: no output (zero matches). If any remain, remove those call sites.

- [ ] **Step 5: Run the full graph + CLI + skill suites**

Run: `uv run pytest tests/test_graph.py tests/test_cli_overview.py tests/test_org_overview_skill.py -v`
Expected: all PASS (the CLI/skill tests assert only on the title, `` ```mermaid ``, `## For the narrating agent`, and the `beta`-exclusion — all retained).

- [ ] **Step 6: Commit**

```bash
git add steward/cli/_commands/_graph.py tests/test_graph.py
git commit -m "feat(overview): assemble lean markdown digest; drop prose edge list"
```

---

### Task 8: Update the `org-overview` skill narration contract

**Files:**

- Modify: `.claude/skills/org-overview/SKILL.md:64-72`

- [ ] **Step 1: Update the "How to run" note**

Replace this paragraph (currently lines 64-66):

```text
The script prints the CLI's markdown by default: it already contains the mermaid
graph, the candidate-signals section, and a "For the narrating agent" block.
That block is the contract this skill formalizes below.
```

with:

```text
The script prints the CLI's markdown by default: an inventory summary, a
per-repo/agent **connectivity table** (the graph as statistics), a lean
structural mermaid (package edges dropped — see its dependency-spine line), a
grouped candidate-signals section, and a "For the narrating agent" block. That
block is the contract this skill formalizes below. The markdown is already a
digest; the exact per-edge and per-signal lists live in `--json`.
```

- [ ] **Step 2: Update the layer-1 narration guidance**

Replace layer 1 (currently lines 70-72):

```text
1. **Observed facts.** The inventory and the graph edges, each citing its basis.
   Render the mermaid graph verbatim so the user can "see the graph of
   everything." State only what the CLI reported.
```

with:

```text
1. **Observed facts.** Summarize the inventory, the connectivity table, and the
   org graph in your own words — lead with what the connectivity counts reveal
   (the supplier, the hub, the keystone, the isolated repo). Render the lean
   mermaid only when seeing the topology helps. **Do not reproduce the edge or
   signal lists verbatim** — the CLI already aggregated them; read `--json` only
   when you need an exact list to act. State only what the CLI reported.
```

- [ ] **Step 3: Verify the skill still passes the convention + skill tests**

Run: `uv run pytest tests/test_skills_convention.py tests/test_org_overview_skill.py -v`
Expected: all PASS (frontmatter `name: org-overview` and the `scripts/` entry-point are unchanged; only prose changed).

- [ ] **Step 4: Commit**

```bash
git add .claude/skills/org-overview/SKILL.md
git commit -m "docs(org-overview): narrate the digest; stop echoing lists verbatim"
```

> **No skill-update broadcast needed.** This is a doc-only edit to the
> `org-overview` SKILL.md (the runner script is unchanged), and the ledger
> records no downstream consumers of `org-overview`. Both conditions mean the
> `announce-skill-update` rule in CLAUDE.md does not apply.

---

### Task 9: Lint, version bump, and full-suite verification

**Files:**

- Modify: `pyproject.toml`, `CHANGELOG.md` (via the version-bump script)

- [ ] **Step 1: Format + lint the changed Python**

Run: `uv run black steward tests && uv run isort steward tests && uv run flake8 steward tests`
Expected: black/isort report "All done"/reformatted-or-unchanged; flake8 prints nothing (exit 0). Fix any line-length (>100) or unused-import findings before continuing.

- [ ] **Step 2: Run the entire test suite**

Run: `uv run pytest -n auto -v`
Expected: all PASS.

- [ ] **Step 3: Eyeball the real corpus output shrank**

Run: `uv run steward overview --scope siblings | tee /tmp/overview.md | wc -l`
Expected: ~180–200 lines (down from ~808). Spot-check `/tmp/overview.md`: the connectivity table, the lean mermaid (no `:::package` nodes), the provenance legend, the dependency-spine line, and grouped signals are all present; there is no `--supplies-->`-style prose edge list.

- [ ] **Step 4: Confirm `--json` is byte-for-byte unchanged in shape**

Run: `uv run pytest tests/test_graph.py::test_to_json_shape_is_loadable tests/test_cli_overview.py -k json -v`
Expected: PASS (regression guard that the lossless record was not touched).

- [ ] **Step 5: Version bump (minor — new output behavior)**

Run: `python3 .claude/skills/version-bump/scripts/bump.py minor`
Expected: `pyproject.toml` version goes 0.14.0 → 0.15.0 and a new `CHANGELOG.md` entry is prepended. Edit the CHANGELOG entry to describe the digest (connectivity table, dropped prose edge list / package edges, grouped signals, lossless JSON, org-overview narration update).

- [ ] **Step 6: Commit**

```bash
git add pyproject.toml CHANGELOG.md
git commit -m "chore(release): 0.15.0 — overview markdown digest"
```

---

### Task 10: Commit the planning docs and open the PR

**Files:**

- The spec (`docs/superpowers/specs/2026-05-21-overview-digest-design.md`) is already committed on this branch.
- This plan (`docs/superpowers/plans/2026-05-21-overview-markdown-digest.md`).

- [ ] **Step 1: Commit the plan doc (if not already committed)**

```bash
git add docs/superpowers/plans/2026-05-21-overview-markdown-digest.md
git commit -m "docs(overview): implementation plan for the markdown digest"
```

- [ ] **Step 2: Open the PR via the cicd skill**

Use the `cicd` skill (it wraps `agex pr` and appends the steward signature). The PR bundles the spec, the plan, the implementation, and the version bump. Body should summarize: ~808 → ~180–200 line markdown, lossless `--json` untouched, new connectivity table, grouped signals, org-overview narration update.

- [ ] **Step 3: Await CI green**

Use the `cicd` skill's `await` (SonarCloud gate + version-check + threads). Address any findings, then the branch is ready to merge.

---

## Self-Review

**Spec coverage:**

- D1 (JSON lossless) → Task 9 Step 4 guards it; no task touches `to_json`. ✓
- D2 (drop prose edge list + legend) → Task 4 (legend) + Task 7 (remove `_edge_list_lines`). ✓
- D3 (drop package edges + spine summary) → Task 1 (`_structural_subgraph`) + Task 3 (`_dependency_spine_line`). ✓
- D4 (group signals) → Task 5. ✓
- D5 (connectivity table, full headers) → Task 2. ✓
- D6 (lean mermaid kept) → Task 7 (`to_mermaid(_structural_subgraph(...))`). ✓
- D7 (rewrite in place) + skill edit → Task 7 + Task 8. ✓
- §4.2 inventory trim → Task 6. ✓
- §7 testing (each helper + json regression) → Tasks 1–7 unit tests + Task 9. ✓
- §8 success criteria (~180–200 lines, provenance recoverable) → Task 9 Step 3. ✓

**Placeholder scan:** No TBD/TODO; every code step shows complete code; every test asserts concrete strings. ✓

**Type consistency:** `_node_type` (Task 1) is reused by `_connectivity_lines` (Task 2) and `_dependency_spine_line` (Task 3) with the same signature. `_structural_subgraph` (Task 1) is called by `render_markdown` (Task 7). `_UNOWNED_REPO_RE` defined in Task 5 is used only within the same task's `_signal_lines`. `Counter` import (Task 6) used only in `_inventory_lines`. All helper names match between definition and call sites. ✓
