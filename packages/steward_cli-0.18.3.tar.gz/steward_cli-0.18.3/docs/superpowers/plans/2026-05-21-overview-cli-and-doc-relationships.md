# Overview CLI-usage & Doc-source Relationship Detection — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Teach `steward overview` to detect two relationship classes it currently misses — sibling-CLI usage inside skill bodies/scripts (`uses`) and a technical-writer agent's documented repos (`documents`) — closing the agtag, agex-cli↔cicd, and katvan gaps.

**Architecture:** Two new pure extractors in `steward/cli/_commands/_graph.py` (`add_cli_usage`, `add_doc_sources`), wired into `build_graph`. Both read on-disk sources and cite a `basis`, preserving the no-LLM/no-mutation contract. A new `doc-coverage-gap` signal, three new connectivity columns, a `CLI usage:` summary line, and an updated provenance legend round it out. `--json` needs no change (it already serializes all edges/nodes/signals).

**Tech Stack:** Python 3.11+, `tomllib` (stdlib), `pyyaml` (already a dep), `pytest` (+ `pytest-xdist`). Spec: `docs/superpowers/specs/2026-05-21-overview-cli-and-doc-relationships-design.md`.

---

## File structure

- **Modify** `steward/cli/_commands/_graph.py` — all new model code, extractors, signal, and renderers.
- **Modify** `tests/test_graph.py` — unit tests for every new function (fixture-driven, `tmp_path`).
- **Modify** `pyproject.toml` + `CHANGELOG.md` — version bump (CI-enforced).

No new files: the graph module is the single home for the graph model + extractors + renderers by design (see its module docstring), and all changes belong there.

---

### Task 1: New edge constants + CLI-binary index

**Files:**

- Modify: `steward/cli/_commands/_graph.py` (edge constants near line 33; new helper after `_index_pyprojects`, ~line 273)
- Test: `tests/test_graph.py`

- [ ] **Step 1: Write the failing tests**

Add to `tests/test_graph.py`:

```python
def test_index_cli_binaries_single_owner(tmp_path: Path):
    agtag = tmp_path / "agtag"
    agtag.mkdir()
    (agtag / "pyproject.toml").write_text(
        '[project]\nname = "agtag"\n[project.scripts]\nagtag = "agtag.cli:main"\n'
    )
    parsed, _ = _graph._index_pyprojects([agtag])
    assert _graph._index_cli_binaries(parsed) == {"agtag": "agtag"}


def test_index_cli_binaries_collision_resolved_by_name_match(tmp_path: Path):
    culture = tmp_path / "culture"
    sonar = tmp_path / "culture-sonar-cli"
    culture.mkdir()
    sonar.mkdir()
    (culture / "pyproject.toml").write_text(
        '[project]\nname = "culture"\n[project.scripts]\nculture = "culture.cli:main"\n'
    )
    (sonar / "pyproject.toml").write_text(
        '[project]\nname = "culture-sonar-cli"\n[project.scripts]\nculture = "culture.cli:main"\n'
    )
    parsed, _ = _graph._index_pyprojects([culture, sonar])
    # `culture` binary maps to both repos; the repo whose name == binary wins.
    assert _graph._index_cli_binaries(parsed) == {"culture": "culture"}


def test_index_cli_binaries_ambiguous_collision_dropped(tmp_path: Path):
    antoine = tmp_path / "antoine"
    seer = tmp_path / "seer-cli"
    antoine.mkdir()
    seer.mkdir()
    (antoine / "pyproject.toml").write_text(
        '[project]\nname = "antoine"\n[project.scripts]\nkata = "antoine.cli:main"\n'
    )
    (seer / "pyproject.toml").write_text(
        '[project]\nname = "seer-cli"\n[project.scripts]\nkata = "seer.cli:main"\n'
    )
    parsed, _ = _graph._index_pyprojects([antoine, seer])
    # `kata` matches neither dir/dist name -> dropped, not guessed.
    assert _graph._index_cli_binaries(parsed) == {}
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/test_graph.py -k index_cli_binaries -v`
Expected: FAIL — `AttributeError: module ... has no attribute '_index_cli_binaries'`.

- [ ] **Step 3: Add the edge constants**

In `steward/cli/_commands/_graph.py`, after `EDGE_REFERENCES = "references"` (line 38):

```python
EDGE_USES = "uses"  # skill -> repo, and repo -> repo (sibling CLI invoked in skills)
EDGE_DOCUMENTS = "documents"  # repo -> repo (a docs-site agent's documented siblings)
```

- [ ] **Step 4: Add the CLI-binary index helper**

In `steward/cli/_commands/_graph.py`, after `_index_pyprojects` (ends ~line 273):

```python
def _index_cli_binaries(parsed_by_repo: dict[str, dict]) -> dict[str, str]:
    """Map console-script binary name -> owning repo, resolving collisions.

    Built from each repo's ``[project.scripts]`` keys, so the CLI list is
    self-maintaining (no hardcoded names). A binary that maps to more than
    one repo is kept only when exactly one candidate repo's dir name or
    normalized dist name equals the binary; otherwise it is dropped rather
    than guessed (e.g. ``kata`` -> {antoine, seer-cli} is ambiguous).
    """
    candidates: dict[str, set[str]] = {}
    dist_of: dict[str, str | None] = {}
    for repo, data in parsed_by_repo.items():
        dist_of[repo] = _project_name(data)
        scripts = (data.get("project") or {}).get("scripts") or {}
        for binary in scripts:
            candidates.setdefault(binary, set()).add(repo)
    out: dict[str, str] = {}
    for binary, repos in candidates.items():
        if len(repos) == 1:
            out[binary] = next(iter(repos))
            continue
        nb = _normalize_pkg(binary)
        matches = [r for r in repos if _normalize_pkg(r) == nb or dist_of.get(r) == nb]
        if len(matches) == 1:
            out[binary] = matches[0]
    return out
```

- [ ] **Step 5: Run tests to verify they pass**

Run: `uv run pytest tests/test_graph.py -k index_cli_binaries -v`
Expected: PASS (3 tests).

- [ ] **Step 6: Commit**

```bash
git add steward/cli/_commands/_graph.py tests/test_graph.py
git commit -m "feat(overview): uses/documents edge constants + CLI-binary index"
```

---

### Task 2: `add_cli_usage` extractor

**Files:**

- Modify: `steward/cli/_commands/_graph.py` (after `_index_cli_binaries`)
- Test: `tests/test_graph.py`

- [ ] **Step 1: Write the failing tests**

Add to `tests/test_graph.py`:

```python
def _make_cli_repo(root: Path, name: str, binary: str, *, dist: str | None = None) -> Path:
    repo = root / name
    repo.mkdir()
    (repo / "pyproject.toml").write_text(
        f'[project]\nname = "{dist or name}"\n'
        f'[project.scripts]\n{binary} = "{name.replace("-", "_")}.cli:main"\n'
    )
    return repo


def _add_skill(repo: Path, skill: str, *, skill_md: str = "", script: str = "") -> None:
    sdir = repo / ".claude" / "skills" / skill
    sdir.mkdir(parents=True)
    if skill_md:
        (sdir / "SKILL.md").write_text(skill_md)
    if script:
        scripts = sdir / "scripts"
        scripts.mkdir()
        (scripts / "run.sh").write_text(script)


def test_add_cli_usage_emits_skill_and_repo_edges(tmp_path: Path):
    agex = _make_cli_repo(tmp_path, "agex-cli", "agex")
    steward = _make_cli_repo(tmp_path, "steward", "steward")
    _add_skill(steward, "cicd", script="#!/bin/bash\nexec agex pr lint \"$@\"\n")
    g = _graph.Graph()
    _graph.add_cli_usage(g, [agex, steward])
    edges = {(e.source, e.target, e.type, e.basis) for e in g.edges}
    assert ("cicd", "agex-cli", _graph.EDGE_USES, "SKILL.md/scripts") in edges
    assert ("steward", "agex-cli", _graph.EDGE_USES, "SKILL.md/scripts") in edges


def test_add_cli_usage_matches_backticked_skill_md(tmp_path: Path):
    agtag = _make_cli_repo(tmp_path, "agtag", "agtag")
    afi = _make_cli_repo(tmp_path, "afi-cli", "afi")
    _add_skill(afi, "communicate", skill_md="Issue I/O is backed by `agtag`.\n")
    g = _graph.Graph()
    _graph.add_cli_usage(g, [agtag, afi])
    edges = {(e.source, e.target, e.type) for e in g.edges}
    assert ("communicate", "agtag", _graph.EDGE_USES) in edges
    assert ("afi-cli", "agtag", _graph.EDGE_USES) in edges


def test_add_cli_usage_boundary_guard_no_false_positive(tmp_path: Path):
    agex = _make_cli_repo(tmp_path, "agex-cli", "agex")
    other = _make_cli_repo(tmp_path, "other", "other")
    # `agex-cli` and `myagex` must NOT match the bare `agex` binary.
    _add_skill(other, "doc", skill_md="See agex-cli docs and the myagex tool.\n")
    g = _graph.Graph()
    _graph.add_cli_usage(g, [agex, other])
    assert all(e.target != "agex-cli" for e in g.edges)


def test_add_cli_usage_no_self_edge(tmp_path: Path):
    steward = _make_cli_repo(tmp_path, "steward", "steward")
    _add_skill(steward, "selfref", script="steward show .\n")
    g = _graph.Graph()
    _graph.add_cli_usage(g, [steward])
    assert g.edges == []
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/test_graph.py -k add_cli_usage -v`
Expected: FAIL — `add_cli_usage` not defined.

- [ ] **Step 3: Implement the extractor**

In `steward/cli/_commands/_graph.py`, after `_index_cli_binaries`:

```python
def _read_skill_text(skill_dir: Path) -> str:
    """Concatenated SKILL.md + every readable file under scripts/ (unreadable skipped)."""
    parts: list[str] = []
    skill_md = skill_dir / "SKILL.md"
    if skill_md.is_file():
        try:
            parts.append(skill_md.read_text(encoding="utf-8"))
        except (OSError, UnicodeDecodeError):
            pass
    scripts_dir = skill_dir / "scripts"
    if scripts_dir.is_dir():
        for f in sorted(scripts_dir.rglob("*")):
            if f.is_file():
                try:
                    parts.append(f.read_text(encoding="utf-8"))
                except (OSError, UnicodeDecodeError):
                    continue
    return "\n".join(parts)


def _binary_pattern(binary: str) -> re.Pattern:
    """Whole-token match for a CLI binary: not inside a longer word or path,
    so `agex` matches `agex pr` but not `agex-cli`, `/usr/bin/agex`, or `myagex`."""
    return re.compile(r"(?<![\w./-])" + re.escape(binary) + r"(?![\w-])")


def add_cli_usage(graph: Graph, repo_paths) -> None:
    """Add ``uses`` edges where a repo's skills invoke a sibling's CLI binary.

    Scans each repo's ``.claude/skills/*/SKILL.md`` + ``scripts/`` for the
    console-script binaries declared by sibling pyproject ``[project.scripts]``
    tables. Emits both a skill -> repo edge (attribution) and a repo -> repo
    edge (breadth) per detected (skill, binary). A repo's own binaries are
    skipped (no self-edge). Basis: ``SKILL.md/scripts``.
    """
    repo_paths = list(repo_paths)
    parsed, _ = _index_pyprojects(repo_paths)
    bin_to_repo = _index_cli_binaries(parsed)
    patterns = {b: _binary_pattern(b) for b in bin_to_repo}
    for repo in repo_paths:
        skills_dir = repo / ".claude" / "skills"
        if not skills_dir.is_dir():
            continue
        for skill_dir in sorted(p for p in skills_dir.iterdir() if p.is_dir()):
            text = _read_skill_text(skill_dir)
            if not text:
                continue
            for binary, pat in patterns.items():
                target = bin_to_repo[binary]
                if target == repo.name:
                    continue
                if pat.search(text):
                    graph.add_node(target, NODE_REPO)
                    graph.add_node(skill_dir.name, NODE_SKILL)
                    graph.add_edge(skill_dir.name, target, EDGE_USES, "SKILL.md/scripts")
                    graph.add_edge(repo.name, target, EDGE_USES, "SKILL.md/scripts")
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/test_graph.py -k add_cli_usage -v`
Expected: PASS (4 tests).

- [ ] **Step 5: Commit**

```bash
git add steward/cli/_commands/_graph.py tests/test_graph.py
git commit -m "feat(overview): add_cli_usage extractor (uses edges from skill scripts)"
```

---

### Task 3: `add_doc_sources` extractor

**Files:**

- Modify: `steward/cli/_commands/_graph.py` (add `import yaml` at top; helper after `add_cross_references`)
- Test: `tests/test_graph.py`

- [ ] **Step 1: Write the failing tests**

Add to `tests/test_graph.py`:

```python
_DOC_REGISTRY = """\
- id: afi-cli
  docs_mode: pull-reference
- id: agtag
  docs_mode: pull
- id: tipalti
  docs_mode: skip
"""


def test_add_doc_sources_emits_documents_edges_for_in_scope(tmp_path: Path):
    katvan = tmp_path / "katvan"
    afi = tmp_path / "afi-cli"
    agtag = tmp_path / "agtag"
    for d in (katvan, afi, agtag):
        d.mkdir()
    registry = katvan / "site" / "_data"
    registry.mkdir(parents=True)
    (registry / "agentculture_repos.yml").write_text(_DOC_REGISTRY)
    g = _graph.Graph()
    _graph.add_doc_sources(g, [katvan, afi, agtag])
    edges = {(e.source, e.target, e.type, e.basis) for e in g.edges}
    assert ("katvan", "afi-cli", _graph.EDGE_DOCUMENTS, "doc-source registry") in edges
    assert ("katvan", "agtag", _graph.EDGE_DOCUMENTS, "doc-source registry") in edges
    # `tipalti` is in the registry but not in scope -> dropped.
    assert all(e.target != "tipalti" for e in g.edges)


def test_add_doc_sources_no_registry_is_noop(tmp_path: Path):
    repo = tmp_path / "afi-cli"
    repo.mkdir()
    g = _graph.Graph()
    _graph.add_doc_sources(g, [repo])
    assert g.edges == []
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/test_graph.py -k add_doc_sources -v`
Expected: FAIL — `add_doc_sources` not defined.

- [ ] **Step 3: Implement the extractor**

At the top of `steward/cli/_commands/_graph.py`, add to the imports (after `import re`):

```python
import yaml
```

After `add_cross_references` (ends ~line 362), add:

```python
# A docs-site agent declares the siblings it documents in this registry
# (relative to the repo root). Today only katvan ships it.
_DOC_REGISTRY_REL = Path("site") / "_data" / "agentculture_repos.yml"


def add_doc_sources(graph: Graph, repo_paths) -> None:
    """Add ``documents`` edges from a docs-site agent's source registry.

    For any repo carrying a ``site/_data/agentculture_repos.yml`` registry,
    emit a repo -> repo ``documents`` edge for each registry entry whose
    ``id`` is an in-scope sibling (intersected with the corpus, like
    ``add_cross_references``, so out-of-scope entries are dropped).
    ``docs_mode`` is not filtered on. Basis: ``doc-source registry``.
    """
    repo_paths = list(repo_paths)
    names = {p.name for p in repo_paths}
    for repo in repo_paths:
        registry = repo / _DOC_REGISTRY_REL
        if not registry.is_file():
            continue
        try:
            data = yaml.safe_load(registry.read_text(encoding="utf-8"))
        except (OSError, UnicodeDecodeError, yaml.YAMLError):
            continue
        if not isinstance(data, list):
            continue
        for entry in data:
            if not isinstance(entry, dict):
                continue
            doc_id = entry.get("id")
            if isinstance(doc_id, str) and doc_id in names and doc_id != repo.name:
                graph.add_node(doc_id, NODE_REPO)
                graph.add_edge(repo.name, doc_id, EDGE_DOCUMENTS, "doc-source registry")
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/test_graph.py -k add_doc_sources -v`
Expected: PASS (2 tests).

- [ ] **Step 5: Commit**

```bash
git add steward/cli/_commands/_graph.py tests/test_graph.py
git commit -m "feat(overview): add_doc_sources extractor (documents edges from registry)"
```

---

### Task 4: Wire both extractors into `build_graph`

**Files:**

- Modify: `steward/cli/_commands/_graph.py:377-384` (`build_graph`)
- Test: `tests/test_graph.py`

- [ ] **Step 1: Write the failing test**

Add to `tests/test_graph.py`:

```python
def test_build_graph_runs_cli_and_doc_extractors(tmp_path: Path):
    agtag = _make_cli_repo(tmp_path, "agtag", "agtag")
    afi = _make_cli_repo(tmp_path, "afi-cli", "afi")
    _add_skill(afi, "communicate", skill_md="Backed by `agtag`.\n")
    reg = afi / "site" / "_data"
    reg.mkdir(parents=True)
    (reg / "agentculture_repos.yml").write_text("- id: agtag\n  docs_mode: pull\n")
    ledger = tmp_path / "skill-sources.md"
    ledger.write_text("| Skill | Upstream | Downstream |\n|---|---|---|\n")
    g = _graph.build_graph([], [agtag, afi], ledger)
    types = {(e.source, e.target, e.type) for e in g.edges}
    assert ("communicate", "agtag", _graph.EDGE_USES) in types
    assert ("afi-cli", "agtag", _graph.EDGE_DOCUMENTS) in types
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_graph.py -k build_graph_runs_cli_and_doc -v`
Expected: FAIL — the `uses`/`documents` edges are absent (`build_graph` doesn't call the new extractors yet).

- [ ] **Step 3: Wire the extractors in**

In `steward/cli/_commands/_graph.py`, edit `build_graph`:

```python
def build_graph(agents, repo_paths, ledger_path: Path) -> Graph:
    """Assemble the full evidence graph from all six extractors."""
    graph = Graph()
    add_inventory(graph, agents)
    add_skill_ledger(graph, ledger_path)
    add_dependencies(graph, repo_paths)
    add_cross_references(graph, repo_paths)
    add_cli_usage(graph, repo_paths)
    add_doc_sources(graph, repo_paths)
    return graph
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_graph.py -k build_graph_runs_cli_and_doc -v`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add steward/cli/_commands/_graph.py tests/test_graph.py
git commit -m "feat(overview): call add_cli_usage + add_doc_sources in build_graph"
```

---

### Task 5: `doc-coverage-gap` signal

**Files:**

- Modify: `steward/cli/_commands/_graph.py` (new helper near the other `_*_signals`; call it in `detect_signals` ~line 516)
- Test: `tests/test_graph.py`

- [ ] **Step 1: Write the failing tests**

Add to `tests/test_graph.py`:

```python
def test_doc_coverage_gap_flags_undocumented_agent_repos():
    g = _graph.Graph()
    for repo in ("katvan", "afi-cli", "agtag", "reachy_nova"):
        g.add_node(repo, _graph.NODE_REPO)
        g.add_node(f"{repo}/{repo}", _graph.NODE_AGENT)
        g.add_edge(repo, f"{repo}/{repo}", _graph.EDGE_DECLARES, "culture.yaml")
    # katvan documents afi-cli + agtag, but not reachy_nova.
    g.add_edge("katvan", "afi-cli", _graph.EDGE_DOCUMENTS, "doc-source registry")
    g.add_edge("katvan", "agtag", _graph.EDGE_DOCUMENTS, "doc-source registry")
    signals = _graph.detect_signals(g, {})
    gaps = {s.subject for s in signals if s.kind == "doc-coverage-gap"}
    assert gaps == {"reachy_nova"}


def test_doc_coverage_gap_silent_without_doc_agent():
    g = _graph.Graph()
    g.add_node("afi-cli", _graph.NODE_REPO)
    g.add_node("afi-cli/afi-cli", _graph.NODE_AGENT)
    g.add_edge("afi-cli", "afi-cli/afi-cli", _graph.EDGE_DECLARES, "culture.yaml")
    signals = _graph.detect_signals(g, {})
    assert all(s.kind != "doc-coverage-gap" for s in signals)
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/test_graph.py -k doc_coverage_gap -v`
Expected: FAIL — no `doc-coverage-gap` signals produced.

- [ ] **Step 3: Implement the signal helper**

In `steward/cli/_commands/_graph.py`, after `_overlap_signals` (ends ~line 501):

```python
def _doc_coverage_gap_signals(graph: Graph) -> list[Signal]:
    """In-scope agent repos a documentation agent does not document.

    Active only when at least one ``documents`` edge exists. "In scope" =
    repos that declare an agent (excludes ledger-only nodes like a pure
    skill supplier). A documenting repo never flags itself.
    """
    documented: dict[str, set[str]] = {}
    for e in graph.edges:
        if e.type == EDGE_DOCUMENTS:
            documented.setdefault(e.source, set()).add(e.target)
    if not documented:
        return []
    declaring = {e.source for e in graph.edges if e.type == EDGE_DECLARES}
    out: list[Signal] = []
    for doc_repo in sorted(documented):
        for repo in sorted(declaring - documented[doc_repo] - {doc_repo}):
            out.append(
                Signal(
                    "doc-coverage-gap",
                    repo,
                    f"declares an agent but is not documented by `{doc_repo}`",
                )
            )
    return out
```

- [ ] **Step 4: Call it in `detect_signals`**

In `detect_signals`, add to the returned list (after `*_overlap_signals(graph)`):

```python
        *_overlap_signals(graph),
        *_doc_coverage_gap_signals(graph),
    ]
```

- [ ] **Step 5: Run tests to verify they pass**

Run: `uv run pytest tests/test_graph.py -k doc_coverage_gap -v`
Expected: PASS (2 tests).

- [ ] **Step 6: Commit**

```bash
git add steward/cli/_commands/_graph.py tests/test_graph.py
git commit -m "feat(overview): doc-coverage-gap signal"
```

---

### Task 6: Connectivity table columns

**Files:**

- Modify: `steward/cli/_commands/_graph.py` — `_CONNECTIVITY_COUNTERS` (~line 563), `_tally_edge` (~line 572), `_connectivity_lines` (~line 614)
- Test: `tests/test_graph.py`

- [ ] **Step 1: Write the failing test**

Add to `tests/test_graph.py`:

```python
def test_connectivity_table_counts_uses_and_documents():
    g = _graph.Graph()
    for repo in ("katvan", "afi-cli", "agtag"):
        g.add_node(repo, _graph.NODE_REPO)
    g.add_node("communicate", _graph.NODE_SKILL)
    # repo->repo uses (counted) + skill->repo uses (NOT counted in the table)
    g.add_edge("afi-cli", "agtag", _graph.EDGE_USES, "SKILL.md/scripts")
    g.add_edge("communicate", "agtag", _graph.EDGE_USES, "SKILL.md/scripts")
    g.add_edge("katvan", "afi-cli", _graph.EDGE_DOCUMENTS, "doc-source registry")
    lines = _graph._connectivity_lines(g)
    header = lines[0]
    assert "CLI uses" in header and "CLI used-by" in header and "Documents" in header
    rows = {ln.split("|")[1].strip(): ln for ln in lines[2:]}
    # agtag: used-by 1 (only the repo->repo edge, not the skill edge).
    assert rows["agtag"].strip().endswith("| 0 | 1 | 0 |")
    # afi-cli: uses 1, used-by 0, documents 0.
    assert rows["afi-cli"].strip().endswith("| 1 | 0 | 0 |")
    # katvan: documents 1.
    assert rows["katvan"].strip().endswith("| 0 | 0 | 1 |")
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_graph.py -k connectivity_table_counts_uses -v`
Expected: FAIL — header lacks the new columns / `KeyError`.

- [ ] **Step 3: Extend the counters**

In `steward/cli/_commands/_graph.py`, edit `_CONNECTIVITY_COUNTERS`:

```python
_CONNECTIVITY_COUNTERS = (
    "supplied", "consumed", "sib", "pkg", "refs_in", "refs_out",
    "uses_out", "uses_in", "documents_out",
)
```

- [ ] **Step 4: Tally the new edge types**

In `_tally_edge`, add branches (after the `EDGE_PRESENT_ON` branch):

```python
    elif e.type == EDGE_USES:
        # Count repo->repo usage only; skill->repo edges are structural
        # (shown in the mermaid), so they don't inflate per-repo counts.
        if (
            _node_type(graph, e.source) == NODE_REPO
            and _node_type(graph, e.target) == NODE_REPO
        ):
            _bump(stat, e.source, "uses_out")
            _bump(stat, e.target, "uses_in")
    elif e.type == EDGE_DOCUMENTS:
        _bump(stat, e.source, "documents_out")
```

- [ ] **Step 5: Add the columns to the rendered table**

In `_connectivity_lines`, update the header and separator:

```python
    header = (
        "| Repo (agents) | Skills supplied | Skills consumed | Channels "
        "| Sibling deps | References in | References out | Packages "
        "| CLI uses | CLI used-by | Documents |"
    )
    lines = [header, "|---|---|---|---|---|---|---|---|---|---|---|"]
```

and the per-repo row append:

```python
        lines.append(
            f"| {label} | {s['supplied']} | {s['consumed']} | {len(s['channels'])} "
            f"| {s['sib']} | {s['refs_in']} | {s['refs_out']} | {s['pkg']} "
            f"| {s['uses_out']} | {s['uses_in']} | {s['documents_out']} |"
        )
```

- [ ] **Step 6: Run test to verify it passes**

Run: `uv run pytest tests/test_graph.py -k connectivity_table_counts_uses -v`
Expected: PASS.

- [ ] **Step 7: Commit**

```bash
git add steward/cli/_commands/_graph.py tests/test_graph.py
git commit -m "feat(overview): CLI uses/used-by + Documents connectivity columns"
```

---

### Task 7: Structural subgraph drop + `CLI usage:` summary line

**Files:**

- Modify: `steward/cli/_commands/_graph.py` — `_structural_subgraph` (~line 539), new `_cli_usage_line`, `render_markdown` (~line 855)
- Test: `tests/test_graph.py`

- [ ] **Step 1: Write the failing tests**

Add to `tests/test_graph.py`:

```python
def test_structural_subgraph_drops_repo_to_repo_uses_keeps_skill_to_repo():
    g = _graph.Graph()
    g.add_node("afi-cli", _graph.NODE_REPO)
    g.add_node("agtag", _graph.NODE_REPO)
    g.add_node("communicate", _graph.NODE_SKILL)
    g.add_edge("afi-cli", "agtag", _graph.EDGE_USES, "SKILL.md/scripts")  # dropped
    g.add_edge("communicate", "agtag", _graph.EDGE_USES, "SKILL.md/scripts")  # kept
    sub = _graph._structural_subgraph(g)
    pairs = {(e.source, e.target) for e in sub.edges if e.type == _graph.EDGE_USES}
    assert pairs == {("communicate", "agtag")}


def test_cli_usage_line_summarizes_repo_usage():
    g = _graph.Graph()
    for repo in ("afi-cli", "culture", "agtag", "agex-cli"):
        g.add_node(repo, _graph.NODE_REPO)
    g.add_edge("afi-cli", "agtag", _graph.EDGE_USES, "SKILL.md/scripts")
    g.add_edge("culture", "agtag", _graph.EDGE_USES, "SKILL.md/scripts")
    g.add_edge("culture", "agex-cli", _graph.EDGE_USES, "SKILL.md/scripts")
    line = _graph._cli_usage_line(g)
    assert "agtag ←2" in line and "agex-cli ←1" in line


def test_cli_usage_line_none():
    assert "none" in _graph._cli_usage_line(_graph.Graph())
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/test_graph.py -k "structural_subgraph_drops or cli_usage_line" -v`
Expected: FAIL — `_cli_usage_line` undefined; subgraph still keeps the repo→repo edge.

- [ ] **Step 3: Drop repo→repo `uses` from the structural subgraph**

In `_structural_subgraph`, inside the edge loop, add the skip before `sub.add_edge(...)`:

```python
        if _node_type(graph, e.source) == NODE_PACKAGE:
            continue
        if _node_type(graph, e.target) == NODE_PACKAGE:
            continue
        if (
            e.type == EDGE_USES
            and _node_type(graph, e.source) == NODE_REPO
            and _node_type(graph, e.target) == NODE_REPO
        ):
            continue
        sub.add_edge(e.source, e.target, e.type, e.basis)
```

- [ ] **Step 4: Add the summary line**

In `steward/cli/_commands/_graph.py`, after `_dependency_spine_line` (ends ~line 669):

```python
def _cli_usage_line(graph: Graph) -> str:
    """One-line summary of repo->CLI usage (the edges dropped from the mermaid).

    Mirrors `_dependency_spine_line`: the diagram stays lean, the breadth is
    reported here, and full edges remain in --json. Sorted by descending
    in-degree then name.
    """
    used_by: dict[str, set[str]] = {}
    for e in graph.edges:
        if (
            e.type == EDGE_USES
            and _node_type(graph, e.source) == NODE_REPO
            and _node_type(graph, e.target) == NODE_REPO
        ):
            used_by.setdefault(e.target, set()).add(e.source)
    if not used_by:
        return "CLI usage: none (no sibling-CLI invocations in scope)."
    parts = ", ".join(
        f"{cli} ←{len(repos)}"
        for cli, repos in sorted(used_by.items(), key=lambda kv: (-len(kv[1]), kv[0]))
    )
    return f"CLI usage (repo→CLI, summarized from the graph): {parts}. Full edges in --json."
```

- [ ] **Step 5: Render the line in `render_markdown`**

In `render_markdown`, add it right after the dependency-spine line:

```python
        _dependency_spine_line(graph),
        "",
        _cli_usage_line(graph),
        "",
```

- [ ] **Step 6: Run tests to verify they pass**

Run: `uv run pytest tests/test_graph.py -k "structural_subgraph_drops or cli_usage_line" -v`
Expected: PASS (3 tests).

- [ ] **Step 7: Commit**

```bash
git add steward/cli/_commands/_graph.py tests/test_graph.py
git commit -m "feat(overview): lean mermaid (drop repo->CLI uses) + CLI usage summary line"
```

---

### Task 8: Provenance legend covers the new bases

**Files:**

- Modify: `steward/cli/_commands/_graph.py` — `_provenance_legend` (~line 672)
- Test: `tests/test_graph.py`

- [ ] **Step 1: Write the failing test**

Add to `tests/test_graph.py`:

```python
def test_provenance_legend_mentions_uses_and_documents():
    legend = _graph._provenance_legend()
    assert "uses ← SKILL.md/scripts" in legend
    assert "documents ← doc-source registry" in legend
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_graph.py -k provenance_legend_mentions -v`
Expected: FAIL — legend lacks the new entries.

- [ ] **Step 3: Update the legend**

In `_provenance_legend`, edit the returned string:

```python
    return (
        "Provenance by edge type: declares, present_on ← culture.yaml · "
        "supplies, consumes ← skill-sources.md · depends_on ← pyproject.toml · "
        "references ← CLAUDE.md/README.md · uses ← SKILL.md/scripts · "
        "documents ← doc-source registry"
    )
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_graph.py -k provenance_legend_mentions -v`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add steward/cli/_commands/_graph.py tests/test_graph.py
git commit -m "feat(overview): legend covers uses + documents bases"
```

---

### Task 9: Full suite, lint, version bump, doc check

**Files:**

- Modify: `pyproject.toml`, `CHANGELOG.md` (via the version-bump script)

- [ ] **Step 1: Run the full test suite**

Run: `uv run pytest -n auto -v`
Expected: PASS (all existing + ~16 new tests). If `test_cli_overview.py` asserts on exact markdown/columns, update those expectations to include the three new columns, the `CLI usage:` line, and the extended legend, then re-run.

- [ ] **Step 2: Lint**

Run: `uv run black steward tests && uv run isort steward tests && uv run flake8 steward tests`
Expected: no changes / no violations. Fix any reported issues and re-run.

- [ ] **Step 3: Bump the version**

Run: `python3 .claude/skills/version-bump/scripts/bump.py minor`
Expected: `pyproject.toml` version incremented and a new `CHANGELOG.md` entry prepended. (Minor: this adds CLI-surface behavior.) Edit the CHANGELOG entry to describe the `uses`/`documents` edges, the `doc-coverage-gap` signal, and the new connectivity columns.

- [ ] **Step 4: Verify the real corpus output**

Run: `uv run python -m steward overview --scope siblings 2>&1 | sed -n '1,60p'`
Expected: the connectivity table shows `CLI uses` / `CLI used-by` / `Documents`; `agtag`'s `CLI used-by` is non-zero; a `CLI usage:` line appears; `katvan` shows `Documents > 0`; signals include `doc-coverage-gap` entries. This is a sanity check, not an assertion.

- [ ] **Step 5: Commit**

```bash
git add -A
git commit -m "chore(overview): version bump + changelog for relationship detection"
```

---

## Self-review notes

- **Spec coverage:** §3 → Tasks 1–2; §4 → Task 3; §5 → Task 5; §6 (columns) → Task 6; §6 (mermaid + summary line) → Task 7; §6 (legend) → Task 8; §6 (`--json` no-change) → asserted indirectly by existing `test_to_json_*`; wiring → Task 4; tests (§7) → embedded per task; version bump → Task 9.
- **Type consistency:** `EDGE_USES`/`EDGE_DOCUMENTS`, `add_cli_usage`, `add_doc_sources`, `_index_cli_binaries`, `_read_skill_text`, `_binary_pattern`, `_cli_usage_line`, `_doc_coverage_gap_signals`, counters `uses_out`/`uses_in`/`documents_out` are used identically across all tasks.
- **No placeholders:** every code/test step shows complete code and an exact command with expected result.
