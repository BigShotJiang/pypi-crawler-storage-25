# nltx

`nltx` is an offline Python package for serving lab content converted from raw Jupyter notebooks into structured JSON.

## Install

From the project root:

```bash
pip install .
```

After publishing to PyPI:

```bash
pip install nltx
```

## Usage

```python
from nltx import (
    details,
    cell,
    description,
    working,
    explain,
    guide,
    inputGuide,
    cautions,
    help,
)

print(details("lab1"))
print(cell("lab1", 1, "A"))
print(description("lab1", "A"))      # variant-level description
print(working("lab1", "A"))          # variant-level working mechanism
print(description("lab1", 1, "A"))   # optional cell-level description (backward compatible)
print(working("lab1", 1, "A"))       # optional cell-level working (backward compatible)
print(explain("lab1", 1, "A"))
print(guide("lab1", "A"))
print(inputGuide("lab1", "A"))
print(cautions("lab1", "A"))
print(help())
```

## Lab Data Structure

Each lab JSON file (`nltx/data/<lab>.json`) uses:

```json
{
  "title": "<lab-name>",
  "variants": {
    "A": {
      "title": "Default variant",
      "cells": [
        {
          "code": "<code>",
          "description": "<what this cell does>",
          "working": "<how this cell works>",
          "explanation": "<combined description + working>",
          "metadata": {}
        }
      ],
      "description": "<variant-level summary>",
      "differenceFromOtherVariants": "<how this variant differs from sibling variants>",
      "workingMechanism": "<step-by-step variant execution summary>",
      "cellWorkings": [
        {
          "cellNumber": 1,
          "description": "<what cell does>",
          "working": "<how cell works>"
        }
      ],
      "guide": "",
      "inputGuide": "",
      "cautions": [],
      "sourceNotebook": "raw/lab1A.ipynb",
      "introMarkdown": "",
      "rawNotebookMetadata": {}
    }
  }
}
```

## Data Workflow

- Notebook files are maintained in the project root `raw/` directory.
- JSON files in `nltx/data/` are curated manually from those notebooks.
- The package reads only packaged JSON data at runtime.
- The project does not use an in-package converter module.

## Current Scope

- Current packaged labs: `lab1`, `lab2`, `lab3`, `lab4`, `lab5`, `lab7`, `lab8`
- Multiple variants are supported per lab (`A/B/C` based on availability)
- Markdown parsing and advanced enrichment are intentionally out of scope for now
