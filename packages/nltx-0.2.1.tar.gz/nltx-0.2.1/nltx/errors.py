class LabNotFoundError(Exception):
    """Raised when a requested lab JSON file does not exist."""


class VariantNotFoundError(Exception):
    """Raised when a requested variant does not exist in a lab."""


class CellIndexError(Exception):
    """Raised when a requested cell index is outside the valid range."""

