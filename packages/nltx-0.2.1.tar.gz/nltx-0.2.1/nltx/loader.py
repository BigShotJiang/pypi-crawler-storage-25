import json
from typing import Dict, List

try:
    from importlib.resources import files
except ImportError:  # pragma: no cover - Python 3.8 fallback
    from importlib_resources import files  # type: ignore

from .errors import LabNotFoundError


def list_labs() -> List[str]:
    """Return available lab names from packaged JSON data."""
    data_dir = files("nltx").joinpath("data")
    labs: List[str] = []
    for item in data_dir.iterdir():
        if item.is_file() and item.name.endswith(".json"):
            labs.append(item.name[:-5])
    return sorted(labs)


def load_lab(lab: str) -> Dict:
    """Load a single lab JSON by lab name (without extension)."""
    lab_name = lab[:-5] if lab.endswith(".json") else lab
    lab_file = files("nltx").joinpath("data", f"{lab_name}.json")

    if not lab_file.is_file():
        raise LabNotFoundError(lab_name)

    try:
        with lab_file.open("r", encoding="utf-8") as handle:
            return json.load(handle)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Invalid JSON in lab file '{lab_name}.json'.") from exc
