from typing import Any, Dict, List, Optional, Tuple

from .errors import CellIndexError, LabNotFoundError, VariantNotFoundError
from .loader import list_labs as _list_labs, load_lab


def _build_help_text() -> str:
    lines = [
        "Available nltx functions:",
        "",
        "1. details(lab: str) -> str",
        "   Params: lab = lab id such as 'lab1'.",
        "   Output: formatted summary containing lab title, variants, cell counts, and caution counts.",
        "",
        "2. cell(lab: str, index: int, variant: str) -> str",
        "   Params: lab, index (1-based), variant (for example 'A').",
        "   Output: exact code string from the requested cell.",
        "",
        "3. code(lab: str, variant: str) -> str",
        "   Params: lab, variant.",
        "   Output: full combined code for all cells in the variant.",
        "",
        "4. explain(lab: str, index: int, variant: str) -> str",
        "   Params: lab, index (1-based), variant.",
        "   Output: explanation text for the requested cell.",
        "",
        "5. description(lab: str, variant: str) -> str",
        "   Params: lab, variant.",
        "   Output: variant-level description.",
        "",
        "6. description(lab: str, index: int, variant: str) -> str",
        "   Params: lab, index (1-based), variant.",
        "   Output: cell-level description (backward compatible call style).",
        "",
        "7. working(lab: str, variant: str) -> str",
        "   Params: lab, variant.",
        "   Output: variant-level working mechanism across the full flow.",
        "",
        "8. working(lab: str, index: int, variant: str) -> str",
        "   Params: lab, index (1-based), variant.",
        "   Output: cell-level working details (backward compatible call style).",
        "",
        "9. guide(lab: str, variant: str) -> str",
        "   Params: lab, variant.",
        "   Output: variant execution guide and change strategy.",
        "",
        "10. inputGuide(lab: str, variant: str) -> str",
        "   Params: lab, variant.",
        "   Output: expected inputs, editable fields, and output expectations.",
        "",
        "11. cautions(lab: str, variant: str) -> str",
        "    Params: lab, variant.",
        "    Output: newline-separated caution checklist for the variant.",
        "",
        "12. list_labs() -> str",
        "    Params: none.",
        "    Output: comma-separated available labs.",
        "",
        "13. list_variants(lab: str) -> str",
        "    Params: lab.",
        "    Output: comma-separated variants available for the lab.",
        "",
        "14. help() -> str",
        "    Params: none.",
        "    Output: this function reference.",
    ]
    return "\n".join(lines)


_HELP_TEXT = _build_help_text()


def _available_labs_text() -> str:
    labs = _list_labs()
    return ", ".join(labs) if labs else "(none)"


def _get_variant(lab_name: str, data: Dict[str, Any], variant: str) -> Dict[str, Any]:
    variants = data.get("variants", {})
    variant_data = variants.get(variant)
    if variant_data is None:
        raise VariantNotFoundError(
            f"Variant '{variant}' not found in {lab_name}.\n"
            f"Available variants: {', '.join(sorted(variants.keys())) or '(none)'}"
        )
    return variant_data


def _get_cell(variant_data: Dict[str, Any], index: int) -> Dict[str, Any]:
    cells = variant_data.get("cells", [])
    if not isinstance(cells, list):
        cells = []

    if not cells:
        raise CellIndexError(
            f"Cell index {index} out of range.\nValid range: none (0 cells available)"
        )

    if index < 1 or index > len(cells):
        raise CellIndexError(
            f"Cell index {index} out of range.\nValid range: 1-{len(cells)}"
        )
    return cells[index - 1]


def _format_cautions(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    if isinstance(value, list):
        cautions = [str(item).strip() for item in value if str(item).strip()]
        return "\n".join(cautions)
    return str(value)


def _parse_variant_and_index(args: Tuple[Any, ...]) -> Tuple[str, Optional[int]]:
    """
    Supported call styles:
    - description(lab, variant)
    - description(lab, index, variant)  # backward compatible
    - description(lab, variant, index)  # tolerant alternative
    """
    if len(args) == 1:
        return str(args[0]), None

    if len(args) == 2:
        first, second = args
        if isinstance(first, int):
            return str(second), int(first)
        if isinstance(second, int):
            return str(first), int(second)
        raise ValueError("Expected (variant) or (index, variant) or (variant, index).")

    raise ValueError("Expected lab + variant, with optional index.")


def details(lab: str) -> str:
    try:
        data = load_lab(lab)
        lines: List[str] = [f"Title: {data.get('title', lab)}", "", "Variants:"]
        variants = data.get("variants", {})
        for variant_name in sorted(variants.keys()):
            variant_data = variants[variant_name]
            cell_count = len(variant_data.get("cells", []))
            lines.append(f"{variant_name}:")
            lines.append(f"  Title: {variant_data.get('title', '')}")
            if variant_data.get("description"):
                lines.append(f"  Description: {variant_data.get('description', '')}")
            lines.append(f"  Cell Count: {cell_count}")
            lines.append(f"  Caution Count: {len(variant_data.get('cautions', []) or [])}")
        return "\n".join(lines)
    except LabNotFoundError:
        return f"Lab '{lab}' not found.\nAvailable labs: {_available_labs_text()}"
    except Exception as exc:
        return f"Unexpected error: {exc}"


def cell(lab: str, index: int, variant: str) -> str:
    try:
        data = load_lab(lab)
        variant_data = _get_variant(lab, data, variant)
        return _get_cell(variant_data, index).get("code", "")
    except LabNotFoundError:
        return f"Lab '{lab}' not found.\nAvailable labs: {_available_labs_text()}"
    except (VariantNotFoundError, CellIndexError) as exc:
        return str(exc)
    except Exception as exc:
        return f"Unexpected error: {exc}"


def code(lab: str, variant: str) -> str:
    try:
        data = load_lab(lab)
        variant_data = _get_variant(lab, data, variant)

        cells = variant_data.get("cells", [])
        if not isinstance(cells, list):
            return "Invalid lab data: expected 'cells' to be a list."
        if not cells:
            return (
                f"No code cells found for lab '{lab}' variant '{variant}'.\n"
                "Check whether the variant has non-empty 'cells' data."
            )

        code_chunks: List[str] = []
        for idx, cell_data in enumerate(cells, start=1):
            if not isinstance(cell_data, dict):
                return (
                    f"Invalid lab data: cell {idx} in lab '{lab}' variant '{variant}' "
                    "is not an object."
                )

            cell_code = cell_data.get("code", "")
            if cell_code is None:
                cell_code = ""

            if not isinstance(cell_code, str):
                return (
                    f"Invalid lab data: code in cell {idx} for lab '{lab}' variant '{variant}' "
                    "must be a string."
                )

            code_chunks.append(cell_code.rstrip("\n"))

        return "\n\n".join(code_chunks).strip()
    except LabNotFoundError:
        return f"Lab '{lab}' not found.\nAvailable labs: {_available_labs_text()}"
    except VariantNotFoundError as exc:
        return str(exc)
    except Exception as exc:
        return f"Unexpected error: {exc}"


def explain(lab: str, index: int, variant: str) -> str:
    try:
        data = load_lab(lab)
        variant_data = _get_variant(lab, data, variant)
        cell_data = _get_cell(variant_data, index)
        explanation = cell_data.get("explanation", "")
        if explanation:
            return explanation

        description_text = cell_data.get("description", "")
        working_text = cell_data.get("working", "")
        if description_text and working_text:
            return f"{description_text}\n\nHow it works:\n{working_text}"
        if description_text:
            return description_text
        if working_text:
            return working_text
        return ""
    except LabNotFoundError:
        return f"Lab '{lab}' not found.\nAvailable labs: {_available_labs_text()}"
    except (VariantNotFoundError, CellIndexError) as exc:
        return str(exc)
    except Exception as exc:
        return f"Unexpected error: {exc}"


def guide(lab: str, variant: str) -> str:
    try:
        data = load_lab(lab)
        variant_data = _get_variant(lab, data, variant)
        return variant_data.get("guide", "")
    except LabNotFoundError:
        return f"Lab '{lab}' not found.\nAvailable labs: {_available_labs_text()}"
    except VariantNotFoundError as exc:
        return str(exc)
    except Exception as exc:
        return f"Unexpected error: {exc}"


def inputGuide(lab: str, variant: str) -> str:
    try:
        data = load_lab(lab)
        variant_data = _get_variant(lab, data, variant)
        return variant_data.get("inputGuide", "")
    except LabNotFoundError:
        return f"Lab '{lab}' not found.\nAvailable labs: {_available_labs_text()}"
    except VariantNotFoundError as exc:
        return str(exc)
    except Exception as exc:
        return f"Unexpected error: {exc}"


def description(lab: str, *args: Any) -> str:
    try:
        variant, index = _parse_variant_and_index(args)
        data = load_lab(lab)
        variant_data = _get_variant(lab, data, variant)

        if index is None:
            return variant_data.get("description", "")

        return _get_cell(variant_data, index).get("description", "")
    except LabNotFoundError:
        return f"Lab '{lab}' not found.\nAvailable labs: {_available_labs_text()}"
    except ValueError as exc:
        return f"Invalid arguments: {exc}"
    except (VariantNotFoundError, CellIndexError) as exc:
        return str(exc)
    except Exception as exc:
        return f"Unexpected error: {exc}"


def working(lab: str, *args: Any) -> str:
    try:
        variant, index = _parse_variant_and_index(args)
        data = load_lab(lab)
        variant_data = _get_variant(lab, data, variant)

        if index is None:
            return variant_data.get("workingMechanism", "")

        return _get_cell(variant_data, index).get("working", "")
    except LabNotFoundError:
        return f"Lab '{lab}' not found.\nAvailable labs: {_available_labs_text()}"
    except ValueError as exc:
        return f"Invalid arguments: {exc}"
    except (VariantNotFoundError, CellIndexError) as exc:
        return str(exc)
    except Exception as exc:
        return f"Unexpected error: {exc}"


def cautions(lab: str, variant: str) -> str:
    try:
        data = load_lab(lab)
        variant_data = _get_variant(lab, data, variant)
        return _format_cautions(variant_data.get("cautions", []))
    except LabNotFoundError:
        return f"Lab '{lab}' not found.\nAvailable labs: {_available_labs_text()}"
    except VariantNotFoundError as exc:
        return str(exc)
    except Exception as exc:
        return f"Unexpected error: {exc}"


def list_labs() -> str:
    try:
        labs = _list_labs()
        return ", ".join(labs) if labs else "(none)"
    except Exception as exc:
        return f"Unexpected error: {exc}"


def list_variants(lab: str) -> str:
    try:
        data = load_lab(lab)
        variants = sorted(data.get("variants", {}).keys())
        return ", ".join(variants) if variants else "(none)"
    except LabNotFoundError:
        return f"Lab '{lab}' not found.\nAvailable labs: {_available_labs_text()}"
    except Exception as exc:
        return f"Unexpected error: {exc}"


def help() -> str:
    return _HELP_TEXT
