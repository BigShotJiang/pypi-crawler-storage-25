# Copyright 2026 Valuein LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Valuein SDK — Python client for US Core Fundamentals data.

The client authenticates against the Valuein edge gateway, discovers the
user's plan and current data snapshot, then downloads Parquet tables into
an in-process DuckDB instance for zero-latency SQL analytics.

Users never interact with storage directly.  The gateway resolves the
correct bucket, snapshot folder, and Parquet path from the token alone.
"""

from __future__ import annotations

import importlib.resources as pkg_resources
import io
import logging
import os
import pathlib
import re
import tempfile
import time
import warnings
from collections.abc import Iterator
from dataclasses import dataclass
from datetime import date, datetime, timezone
from typing import Any

import duckdb
import pandas as pd
import pyarrow.parquet as pq
from dotenv import load_dotenv

from .exceptions import (
    ValueinAuthError,
    ValueinConfigError,
    ValueinConnectionError,
    ValueinDataError,
    ValueinError,
    ValueinPlanError,
    ValueinValidationError,
)
from .transport import Transport

_logger = logging.getLogger("valuein_sdk")

_DEFAULT_GATEWAY = "https://data.valuein.biz"
# MCP server endpoint — agent-facing channel for docgen + reasoning tools.
# Same Bearer token, different host.
_DEFAULT_MCP_URL = "https://mcp.valuein.biz/mcp"

# Manifest data is small and changes only when the pipeline publishes a new snapshot.
# Cache it for 5 minutes to avoid a network round-trip on every manifest() call.
_MANIFEST_CACHE_TTL_S = 300.0
ALLOWED_FORM_TYPES = {"10-K", "10-K/A", "10-Q", "10-Q/A", "20-F", "20-F/A", "8-K", "8-K/A"}


def _load_bundled_concepts() -> frozenset[str]:
    """Load the bundled ``_standard_concepts.txt`` shipped with the package.

    The file is written by ``data-pipeline/run_exports.py`` and contains one
    canonical ``standard_concept`` value per line.  It is the authoritative
    seed for offline / sample-mode validation and is regenerated on every
    pipeline run.

    Returns an empty frozenset if the file is missing or unreadable — the
    caller must degrade gracefully (warn, never raise).
    """
    try:
        resource = pkg_resources.files("valuein_sdk").joinpath("_standard_concepts.txt")
        text = resource.read_text(encoding="utf-8")
        return frozenset(line.strip() for line in text.splitlines() if line.strip())
    except Exception:
        return frozenset()


# Bundled seed loaded at import time.  Used as fallback when taxonomy_guide
# is not yet loaded (sample mode, offline tests, early validation calls).
# The live set is always preferred — see ValueinClient._valid_concepts.
_BUNDLED_CONCEPTS: frozenset[str] = _load_bundled_concepts()

# ── Validation regex patterns ─────────────────────────────────────────────────
# Ticker: 1–10 uppercase alphanumeric + dot (e.g. 'AAPL', 'BRK.B')
_TICKER_RE = re.compile(r"^[A-Z0-9.]{1,10}$")
# ISO 8601 date: YYYY-MM-DD
_DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
# ISO 8601 datetime: YYYY-MM-DD HH:MM or YYYY-MM-DD HH:MM:SS (space or T separator)
_DATETIME_RE = re.compile(r"^\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}(:\d{2})?$")
# CIK: 1–10 numeric digits
_CIK_RE = re.compile(r"^\d{1,10}$")
# Frame: CY2024Q1, CY2023FY, etc.
_FRAME_RE = re.compile(r"^CY\d{4}(Q[1-4]|FY)$")
# MIC code: exactly 4 uppercase letters (ISO 10383)
_MIC_RE = re.compile(r"^[A-Z]{4}$")
# 8-K item code: N.NN format (e.g. '1.01', '5.02')
_ITEM_CODE_RE = re.compile(r"^\d+\.\d+$")

# ── Raw SQL query validation ──────────────────────────────────────────────────
# Hard cap on query length.  10 KB is generous for any analytical SQL — larger
# strings are almost certainly malformed or abusive.
_SQL_MAX_LEN: int = 10_000

# Strips -- line comments and /* */ block comments before pattern checks so that
# dangerous keywords cannot be hidden inside comments.
_SQL_COMMENT_RE = re.compile(r"/\*.*?\*/|--[^\n]*", re.DOTALL)

# DML operations that are dangerous even when embedded inside a CTE.
# Patterns are specific enough that they will not fire on column / table names
# that happen to contain these words as substrings.
_SQL_EMBEDDED_DML_RE = re.compile(
    r"\bINSERT\s+INTO?\b"
    r"|\bDELETE\s+FROM\b"
    r"|\bMERGE\s+INTO?\b"
    r"|\bUPDATE\s+\w[\w.]*\s+SET\b",
    re.IGNORECASE | re.DOTALL,
)

# File-system and network I/O functions that would bypass the R2 data layer
# and give arbitrary read access to the host filesystem or remote URLs.
_SQL_IO_FUNC_RE = re.compile(
    r"\b(?:read_parquet|parquet_scan|read_csv(?:_auto)?|csv_scan|"
    r"read_json|read_ndjson|json_scan|read_text|read_blob|"
    r"scan_parquet|glob|iceberg_scan|delta_scan|lance_scan|"
    r"http_get|http_post)\s*\(",
    re.IGNORECASE,
)

# DuckDB internal system-table functions and standard SQL catalog schemas.
# These expose configuration, installed extensions, and engine internals.
_SQL_SYSCAT_RE = re.compile(
    r"\bduckdb_\w+\s*\(\s*\)"
    r"|\binformation_schema\s*\.\s*\w+"
    r"|\bpg_catalog\s*\.\s*\w+"
    r"|\bpg_\w+\s*\(",
    re.IGNORECASE,
)

# Permitted first tokens for raw SQL submitted via run_query() / to_arrow() / stream().
_SQL_ALLOWED_FIRST_TOKENS: frozenset[str] = frozenset({"SELECT", "WITH", "EXPLAIN"})


def _strip_sql_comments(sql: str) -> str:
    """Remove SQL line and block comments before pattern-based validation.

    This prevents obfuscation such as embedding a forbidden keyword inside
    a comment that precedes or follows the actual SQL text.
    """
    return _SQL_COMMENT_RE.sub(" ", sql)


# Tables too large to download at init — served via presigned R2 URL + httpfs.
# DuckDB fetches only the Parquet footer then the specific row groups it needs,
# so a filtered query reads a tiny fraction of the file even without downloading.
# Small tables (entity, security, taxonomy_guide, etc.) continue to be downloaded
# for fast repeated local access without expiry concerns.
_REMOTE_TABLES = frozenset({"fact", "filing"})
_PRESIGN_TTL_S = 3_600  # 1-hour URL for remote table views
_PRESIGN_REFRESH_BUFFER_S = 120  # refresh when < 2 minutes remain

_SAMPLE_NOTICE = """\
Defaulting to SAMPLE dataset (S&P500, last 5 years).

Upgrade access:
  Register (free)  → Full S&P500 history
  Add API token    → Full US equities universe + complete history

Get your token: https://valuein.biz\
"""

# The 11 tables the edge-gateway exposes.  Used as fallback only when
# the manifest does not include a "tables" key.
# `references` is the denormalized flat join of entity + security + index_membership
# (one row per security) and is the recommended starting point for cross-company queries.
# `ratio` holds pipeline-computed financial ratios derived from raw SEC facts —
# unlike `fact` (immutable PIT-observed data), ratios are recomputed on each pipeline run.
# `factor_scores` and `earnings_signals` are export-time derived tables (parquet schema
# v2.3.0); see README "Data Schema" section for column lists.
_KNOWN_TABLES = frozenset(
    [
        "references",
        "entity",
        "security",
        "valuation",
        "filing",
        "fact",
        "taxonomy_guide",
        # Curated gold-standard concept catalog (~292 rows) — the dictionary for
        # fact.standard_concept (level, statement_type, definition, Bloomberg/
        # FactSet equivalents). Distinct from taxonomy_guide, which is the raw
        # SEC us-gaap tag reference for fact.concept. Exported as of pipeline
        # schema 2.10.0; resolved from the manifest at runtime, listed here so
        # the offline fallback (manifest fetch failed) still admits it.
        "standard_concept",
        "index_membership",
        "ratio",
        "factor_scores",
        "earnings_signals",
        # filing_text holds chunked XBRL TextBlock content (Risk Factors, MD&A,
        # Business, Legal Proceedings, Controls & Procedures). Semantic search
        # happens via the MCP `search_filing_text` tool (embeds into Cloudflare
        # Vectorize); this table is the SOURCE of those embeddings and also
        # queryable directly via DuckDB for substring search, chunk reassembly,
        # or custom embedding pipelines.
        "filing_text",
        # Smart-money tables (enterprise tier / full plan only).  Form 3/4/5 +
        # 13F-HR + SC 13D/G extracted from SEC bulk DERA archives + (future)
        # real-time RSS sentinel.  Tier-gated to the FULL bucket — the
        # edge-gateway returns 403 for non-full plans on these paths.
        "insider_party",
        "insider_transaction",
        "institutional_holding",
        "insider_ownership",
        # Wide-format financial statement tables (v2.5.0).  Denormalized pivots
        # of `fact` keyed by (cik, period_end, fiscal_period) with one column
        # per canonical concept — let DuckDB skip the CASE-WHEN pivot pattern
        # for the bread-and-butter statement views.  Exported alongside the
        # tall `fact` table, not replacing it.
        "wide_income",
        "wide_balance",
        "wide_cashflow",
    ]
)

# Tables that support point-in-time filtering via accepted_at.
#
# Schema note (Apr 2026): the `valuation` table no longer carries
# accepted_at — its rows are recomputed every pipeline run (one row per
# (entity_id, valuation_date, model_type)) and tagged with created_at /
# updated_at instead. `valuation` is therefore NOT a PIT table; callers
# wanting historical model output should pin a snapshot date instead of
# relying on as_of. `ratio` uses computed_at (pipeline run time, not PIT)
# — already excluded.
#
# Smart-money tables (v2.5.0) carry `accepted_at` from the parent SEC
# acceptance timestamp — backtests that mix fundamentals + smart-money
# signals would otherwise inherit silent lookahead bias because the
# institutional holdings of a Form 13F are first publicly known only on
# accepted_at, not at period_end.
_PIT_TABLES = frozenset(
    {
        "fact",
        "filing_text",
        "insider_transaction",
        "institutional_holding",
        "insider_ownership",
    }
)


@dataclass
class ValueinConfig:
    """Hardware and resource constraints for the Valuein SDK."""

    # RAM limit (e.g., '2GB', '512MB').
    # DuckDB will spill to disk once this is hit.
    memory_limit: str = "4GB"

    # Where to store temporary spill files.
    # Defaults to a secure OS-provided temp directory.
    temp_directory: str | None = None

    # Hard cap on disk usage to prevent filling up the host SSD.
    max_temp_directory_size: str = "20GB"

    # Number of CPU threads DuckDB is allowed to use.
    threads: int = 4

    # HTTP connect timeout in seconds. Increase on high-latency networks.
    connect_timeout: float = 30.0

    # HTTP read timeout in seconds. Increase when pulling very large Parquet
    # files on slow connections (e.g., full-universe `fact` table).
    read_timeout: float = 120.0

    def __post_init__(self) -> None:
        """Sanitize inputs to prevent DuckDB parser crashes."""
        self.memory_limit = self.memory_limit.strip().upper()
        self.max_temp_directory_size = self.max_temp_directory_size.strip().upper()

        # Ensure standard formatting (e.g., replacing 'G' with 'GB')
        if self.memory_limit.endswith("G"):
            self.memory_limit += "B"
        if self.max_temp_directory_size.endswith("G"):
            self.max_temp_directory_size += "B"

        # Guard against zero/negative thread counts that would crash DuckDB.
        self.threads = max(1, int(self.threads))


class ValueinClient:
    """Client for the Valuein Financial Data API.

    Connects to the Valuein edge gateway, authenticates with a Bearer
    token, and loads Parquet tables into DuckDB for SQL querying.

    Point-in-time (PIT) enforcement: the ``as_of`` parameter controls which
    facts are visible.  For tables with ``accepted_at`` (``fact``,
    ``filing_text``), only rows where ``accepted_at <= as_of`` are included
    in the DuckDB view.  Other tables (``valuation``, ``ratio``, ``entity``,
    ``references``, etc.) are loaded without PIT filtering — ``valuation``
    is recomputed each pipeline run and is not point-in-time. Pin a
    snapshot date if you need historical model output.

    Args:
        as_of: Point-in-time cutoff (timezone-aware datetime). Only facts
            known on or before this timestamp are visible.  This eliminates
            look-ahead bias for backtesting.  Must include timezone info.
            Defaults to ``datetime.now(timezone.utc)`` (latest available data).
        api_key: Valuein API token. Falls back to ``VALUEIN_API_KEY`` env var.
        gateway_url: Override the gateway URL (development only).
        tables: Restrict which tables are loaded at init.
        config: Hardware constraints (RAM/Disk/Threads) for the local engine.

    Raises:
        ValueinValidationError: If ``as_of`` is missing timezone info or
            is in the future.

    Example:
        >>> client = ValueinClient()  # latest data, key from env
        >>> from datetime import datetime, timezone
        >>> client = ValueinClient(
        ...     as_of=datetime(2024, 1, 1, tzinfo=timezone.utc),
        ...     api_key="tok_...",
        ... )
    """

    def __init__(
        self,
        as_of: datetime | None = None,
        api_key: str | None = None,
        gateway_url: str | None = None,
        tables: list[str] | None = None,
        config: ValueinConfig | None = None,
    ) -> None:
        load_dotenv()

        # ── Validate as_of ───────────────────────────────────────────────
        if as_of is None:
            as_of = datetime.now(timezone.utc)
        if not isinstance(as_of, datetime):
            raise ValueinValidationError(
                f"as_of must be a datetime instance. You provided {type(as_of).__name__}. "
                "Example: datetime(2024, 1, 1, tzinfo=timezone.utc)"
            )
        if as_of.tzinfo is None:
            raise ValueinValidationError(
                "as_of must be timezone-aware. Add tzinfo=timezone.utc. "
                f"You provided: {as_of.isoformat()}"
            )
        self._as_of: datetime = as_of
        # ISO format for DuckDB WHERE clause — calendar-day boundary comparison.
        self._as_of_iso: str = as_of.strftime("%Y-%m-%dT%H:%M:%S+00:00")

        raw_key = api_key or os.getenv("VALUEIN_API_KEY", "")
        self.api_key = raw_key  # may be empty string — sample mode

        self.gateway_url: str = (
            gateway_url or os.getenv("VALUEIN_GATEWAY_URL") or _DEFAULT_GATEWAY
        ).rstrip("/")
        # MCP server URL — used by the docgen / agent-tooling methods.
        # Env override exists for staging + integration tests.
        self.mcp_url: str = (os.getenv("VALUEIN_MCP_URL") or _DEFAULT_MCP_URL).rstrip("/")

        # Resolve config early so timeout values are available for Transport.
        self.config = config or ValueinConfig()

        self._transport = Transport(
            api_key=self.api_key,
            gateway_url=self.gateway_url,
            connect_timeout=self.config.connect_timeout,
            read_timeout=self.config.read_timeout,
        )

        # ── Discover plan & snapshot ──────────────────────────────────────
        if not raw_key:
            # No token — run in sample mode with public data, no network auth needed.
            warnings.warn(_SAMPLE_NOTICE, UserWarning, stacklevel=2)
            self._plan = "sample"
            self._me_data: dict[str, Any] = {
                "plan": "sample",
                "status": "unauthenticated",
                "email": None,
                "message": "No API key provided. Register for free at https://valuein.biz",
            }
            # Fetch the public sample manifest (no auth required). The
            # canonical path is /v1/sample/manifest — the gateway's enriched
            # manifest endpoint, which carries last_updated, snapshot, tables[],
            # and the marketing upgrade fields. An earlier release used
            # /v1/sample/_manifest.json which silently 400'd because the
            # gateway treated the path as a request for a table called
            # "_manifest.json"; the fetch was wrapped in try/except so the
            # bug never surfaced — but every guest user saw last_updated:None.
            last_updated: str | None = None
            sample_manifest: dict[str, Any] = {}
            try:
                sample_manifest = self._transport.get("/v1/sample/manifest").json()
                last_updated = sample_manifest.get("last_updated") or sample_manifest.get(
                    "created_at"
                )
            except Exception:
                pass  # Non-fatal — last_updated stays None if the fetch fails.
            # Surface the live sample tables list when present so a guest's
            # `client.list_tables()` matches what the bucket actually serves.
            sample_tables = sample_manifest.get("tables")
            self._manifest_data: dict[str, Any] = {
                "plan": "sample",
                "path": "/v1/sample",
                "last_updated": last_updated,
                "snapshot": sample_manifest.get("snapshot"),
                "tables": list(sample_tables) if isinstance(sample_tables, list) else [],
                # Preserve the upstream schema embed so get_schema() works for
                # unloaded tables in sample mode (same R2 manifest field that
                # MCP and authenticated SDK plans rely on).
                "schema": sample_manifest.get("schema"),
                "standard_concepts": sample_manifest.get("standard_concepts"),
                "message": "Sample mode — add an API key for full S&P500 or full-universe access",
            }
            self._manifest_fetched_at: float = time.monotonic()
        else:
            try:
                self._me_data = self._fetch_me()
                self._plan = self._me_data.get("plan", "sp500")
                self._manifest_data = self._fetch_manifest()
                self._manifest_fetched_at = time.monotonic()
            except ValueinError:
                # Auth/plan/rate-limit errors must propagate with their original type
                raise
            except Exception as e:
                # Wrap unexpected boot errors (DNS, SSL, etc.) in a ConnectionError
                raise ValueinConnectionError(f"Failed to initialize session: {e}") from e

        # ── Resolve table list ────────────────────────────────────────────
        manifest_tables = list(self._manifest_data.get("tables", []))
        available = manifest_tables if manifest_tables else sorted(_KNOWN_TABLES)

        if tables is not None:
            unknown = set(tables) - set(available)
            if unknown:
                raise ValueinConfigError(f"Unknown table(s): {', '.join(sorted(unknown))}")
            self._tables: list[str] = list(tables)
        else:
            self._tables = available

        # ── Resource Management ───────────────────────────────────────────
        self._managed_temp: tempfile.TemporaryDirectory | None = None
        # Tracks expiry (monotonic seconds) for remote httpfs views.
        # Populated by _load_tables when large tables are mounted via presigned URLs.
        self._remote_view_expiry: dict[str, float] = {}

        if self.config.temp_directory:
            # User provided a custom directory; we will NOT clean this up
            self._temp_dir_path = self.config.temp_directory
            os.makedirs(self._temp_dir_path, exist_ok=True)
        else:
            # SDK creates a temp directory; we MUST clean this up
            self._managed_temp = tempfile.TemporaryDirectory()
            self._temp_dir_path = self._managed_temp.name

        # ── Initialization ────────────────────────────────────────────────
        self._setup_duckdb()
        self.query_cache: dict[str, str] = {}
        # Live concept set — populated from manifest["standard_concepts"] when
        # available (authenticated plans only).  Falls back to _BUNDLED_CONCEPTS
        # for sample/offline mode via the _concept_set property.
        concepts_from_manifest = self._manifest_data.get("standard_concepts")
        # manifest standard_concepts may be a list of names (legacy) or a list of
        # concept-metadata dicts (current). Normalise to a name set either way.
        self._valid_concepts: frozenset[str] | None = (
            frozenset(
                c["standard_concept"] if isinstance(c, dict) else c for c in concepts_from_manifest
            )
            if concepts_from_manifest
            else None
        )

        if self._tables:
            self._load_tables()

        self._build_query_map()
        self._init_jinja()

    def _setup_duckdb(self) -> None:
        self.con: duckdb.DuckDBPyConnection = duckdb.connect()
        self.con.execute("SET preserve_insertion_order = false")
        self.con.execute(f"SET memory_limit = '{self.config.memory_limit}'")
        self.con.execute(f"SET temp_directory = '{self._temp_dir_path}'")
        self.con.execute(f"SET max_temp_directory_size = '{self.config.max_temp_directory_size}'")
        self.con.execute(f"SET threads = {self.config.threads}")

        # Load httpfs to enable direct remote Parquet queries via presigned URLs.
        # Non-fatal: if the extension is unavailable (air-gapped environments,
        # restricted DuckDB builds), get_presigned_url still works but the caller
        # must pass the URL to read_parquet() themselves.
        self._httpfs_available = False
        try:
            self.con.execute("INSTALL httpfs; LOAD httpfs;")
            self.con.execute("SET enable_http_metadata_cache = true;")
            self.con.execute("SET enable_object_cache = true;")
            self._httpfs_available = True
        except Exception:
            _logger.debug("httpfs extension unavailable — presigned URL direct queries disabled")

    def _fetch_me(self) -> dict[str, Any]:
        return self._transport.get("/v1/me").json()

    def _fetch_manifest(self) -> dict[str, Any]:
        return self._transport.get("/v1/manifest").json()

    def _table_endpoint(self, table: str) -> str:
        """Resolve the gateway path for a table given the caller's plan.

        Mirrors edge-gateway routing (workers/edge-gateway/src/index.ts) so
        each plan reads from its own R2 bucket:

            sample → /v1/sample/{table}  (R2_SAMPLE  — public 5yr S&P 500)
            sp500  → /v1/sp500/{table}   (R2_SP500   — full S&P 500 history)
            pro    → /v1/pro/{table}     (R2_PRO     — 4,000-entity universe)
            full   → /v1/full/{table}    (R2_FULL    — 10,000+ entities)

        Pro tokens previously fell through the else-branch and routed to
        /v1/sp500/{table} (free-tier 500 entities), silently downgrading
        paying customers to a smaller universe than they paid for. The
        explicit branches below close that hole; tests/test_plan_routing.py
        pins the mapping so a regression never re-emerges.
        """
        if self._plan == "full":
            prefix = "full"
        elif self._plan == "pro":
            prefix = "pro"
        elif self._plan == "sample":
            prefix = "sample"
        else:
            prefix = "sp500"
        return f"/v1/{prefix}/{table}"

    def _create_view(self, table: str, source_expr: str) -> None:
        """Create a DuckDB view, applying PIT filter for temporal tables.

        If the table is in ``_PIT_TABLES`` but the underlying Parquet file
        does not yet contain the ``accepted_at`` column, the view is created
        without the filter (graceful degradation during schema migration).
        """
        base_sql = f'CREATE OR REPLACE VIEW "{table}" AS SELECT * FROM {source_expr}'

        if table in _PIT_TABLES:
            pit_sql = (
                f"{base_sql} WHERE (accepted_at IS NULL OR accepted_at <= '{self._as_of_iso}')"
            )
            try:
                self.con.execute(pit_sql)
                return
            except Exception:
                _logger.debug(
                    "PIT filter failed for '%s' (accepted_at column may be absent)"
                    " — loading without temporal filter",
                    table,
                )

        self.con.execute(base_sql)

    def _load_tables(self) -> None:
        """Register tables as DuckDB views.

        Large tables (``fact``, ``filing``) are mounted via a presigned R2 URL
        when httpfs is available — no download, zero bytes transferred until a
        query actually runs.  All other tables are downloaded to the local temp
        directory for fast repeated access.
        """
        loaded: list[str] = []
        t0 = time.monotonic()

        for table in self._tables:
            # ── Remote path (large tables, httpfs available, authenticated) ─
            if self._httpfs_available and table in _REMOTE_TABLES and self._plan != "sample":
                try:
                    url = self._get_presigned_url(table, expires_in=_PRESIGN_TTL_S)
                    self._create_view(table, f"read_parquet('{url}')")
                    self._remote_view_expiry[table] = time.monotonic() + _PRESIGN_TTL_S
                    loaded.append(table)
                    _logger.debug(
                        "Mounted '%s' as remote httpfs view (presigned URL, %ds TTL)",
                        table,
                        _PRESIGN_TTL_S,
                    )
                    continue
                except Exception as exc:
                    _logger.warning(
                        "Presign failed for '%s' — falling back to local download: %s", table, exc
                    )

            # ── Local path (small tables, or remote path fallback) ────────
            endpoint = self._table_endpoint(table)
            pq_path = pathlib.Path(self._temp_dir_path) / f"{table}.parquet"

            try:
                with open(pq_path, "wb") as f:
                    self._transport.download_to_file(endpoint, f)

                self._create_view(table, f"read_parquet('{pq_path}')")
                loaded.append(table)
            except ValueinAuthError:
                if self._plan == "sample":
                    _logger.warning(
                        "Table '%s' is not accessible without an API key. "
                        "Register for free at https://valuein.biz",
                        table,
                    )
                else:
                    raise
            except ValueinPlanError:
                _logger.warning("Table '%s' requires a higher plan — skipping.", table)
            except Exception as exc:
                _logger.error("Failed to load table '%s': %s", table, exc)

        if not loaded and self._tables:
            if self._plan == "sample":
                warnings.warn(
                    "No tables could be loaded in sample mode. "
                    "The sample endpoint may require an API key — register for free at https://valuein.biz",
                    UserWarning,
                    stacklevel=3,
                )
            else:
                raise ValueinDataError("Valuein engine failed to load any requested tables.")

        self._tables = loaded
        _logger.info("Engine ready. %d tables loaded in %.2fs", len(loaded), time.monotonic() - t0)

    @property
    def _concept_set(self) -> frozenset[str]:
        """Active standard_concept allowlist for template validation.

        Returns the live set loaded from ``taxonomy_guide`` when available
        (Option 3), falling back to the bundled seed file shipped with the
        package (Option 4).  An empty frozenset means validation is skipped
        entirely — this happens only when both sources are unavailable.
        """
        if self._valid_concepts is not None:
            return self._valid_concepts
        return _BUNDLED_CONCEPTS

    @property
    def as_of(self) -> datetime:
        """The point-in-time cutoff for this client session."""
        return self._as_of

    @property
    def plan(self) -> str:
        """Data access plan: ``'sample'``, ``'sp500'``, ``'pro'``, or ``'full'``."""
        return self._plan

    def _build_query_map(self) -> None:
        self.query_cache = {}
        try:
            queries_root = str(pkg_resources.files("valuein_sdk").joinpath("queries"))
            for dirpath, _, filenames in os.walk(queries_root):
                for fname in filenames:
                    if fname.endswith(".sql"):
                        key = fname.removesuffix(".sql")
                        self.query_cache[key] = os.path.join(dirpath, fname)
        except Exception as exc:
            warnings.warn(f"Could not index SQL templates: {exc}", stacklevel=2)

    def _init_jinja(self) -> None:
        """Initialize the Jinja2 environment and persistent template cache.

        Called once in ``__init__``. The ``lru_cache`` on ``_load_jinja_template``
        must live at instance scope — defining it inside ``run_template`` creates a
        new cache object on every call, so nothing is ever reused.
        """
        from functools import lru_cache

        from jinja2 import Environment, StrictUndefined

        def _quote_sql_string(v: object) -> str:
            return "'" + str(v).replace("'", "''") + "'"

        def sql_list(value: object) -> str:
            if value is None:
                raise ValueError("List parameter cannot be None")
            if not isinstance(value, (list, tuple)):
                raise TypeError(f"Expected list/tuple, got {type(value)}")
            if not value:
                raise ValueError("List parameter cannot be empty")
            return ", ".join(_quote_sql_string(v) for v in value)

        def sql_identifier(value: object) -> str:
            if not isinstance(value, str) or not value:
                raise ValueError("Invalid SQL identifier")
            if not value.replace("_", "").isalnum():
                raise ValueError(f"Unsafe SQL identifier: {value}")
            return value

        def sql_quote(value: object) -> str:
            """Single scalar SQL string literal — safe for WHERE ``= {{ val | sql_quote }}``."""
            return _quote_sql_string(value)

        env = Environment(
            undefined=StrictUndefined,
            autoescape=False,
            trim_blocks=True,
            lstrip_blocks=True,
        )
        env.filters["sql_list"] = sql_list
        env.filters["sql_identifier"] = sql_identifier
        env.filters["sql_quote"] = sql_quote

        self._jinja_env = env

        # Defined here once — the cache persists for the client's lifetime.
        # Each unique path touches the filesystem only on the first call.
        @lru_cache(maxsize=128)
        def _load_jinja_template(path: str) -> Any:  # jinja2.Template
            with open(path) as fh:
                return env.from_string(fh.read())

        self._load_jinja_template = _load_jinja_template

    def me(self) -> dict[str, Any]:
        return dict(self._me_data)

    def manifest(self) -> dict[str, Any]:
        """Return current snapshot metadata, refreshing from the gateway at most every 5 minutes.

        In sample mode (no API key) the stub is returned directly — no network call is made.
        """
        if self._plan == "sample":
            return dict(self._manifest_data)
        now = time.monotonic()
        if now - self._manifest_fetched_at >= _MANIFEST_CACHE_TTL_S:
            self._manifest_data = self._fetch_manifest()
            self._manifest_fetched_at = now
        return dict(self._manifest_data)

    def refresh_manifest(self) -> dict[str, Any]:
        """Force a manifest refresh from the gateway, bypassing the 5-minute cache.

        Use this after a pipeline run to immediately pick up a new data snapshot
        without waiting for the TTL to expire.  In sample mode the stub is
        returned directly — no network call is made.

        Returns:
            The refreshed manifest data dict.

        Raises:
            ValueinError: If the gateway request fails.

        Example::

            client.refresh_manifest()
            print(client.manifest()["snapshot"])
        """
        if self._plan == "sample":
            return dict(self._manifest_data)
        self._manifest_data = self._fetch_manifest()
        self._manifest_fetched_at = time.monotonic()
        return dict(self._manifest_data)

    def health(self) -> dict[str, Any]:
        """Return gateway health status.

        In sample mode (no API key) a static response is returned so that callers
        can always depend on this method without triggering a 401 from the gateway.
        """
        if self._plan == "sample":
            return {
                "status": "ok",
                "mode": "sample",
                "authenticated": False,
                "message": (
                    "Running in unauthenticated sample mode. Add an API key for full access."
                ),
            }
        return self._transport.get("/health").json()

    def get(self, table: str) -> pd.DataFrame:
        all_known = sorted(set(list(self._manifest_data.get("tables", []))) | _KNOWN_TABLES)
        if table not in all_known:
            raise ValueError(f"Unknown table '{table}'. Available: {', '.join(all_known)}")

        endpoint = self._table_endpoint(table)
        try:
            response = self._transport.get(endpoint)
        except (ValueinAuthError, ValueinPlanError):
            raise
        except Exception as exc:
            raise ConnectionError(f"Failed to download '{table}': {exc}") from exc

        return pq.read_table(io.BytesIO(response.content)).to_pandas()

    def _manifest_tables_schema(self) -> dict[str, Any]:
        """Return the per-table schema dict from the in-memory R2 manifest.

        ``run_exports.py`` embeds the full ``PARQUET_SCHEMA`` in each tier's
        ``manifest.json`` (under the ``schema`` key); the SDK reads this at
        init via ``_fetch_manifest()``.  Sample mode mirrors the upstream
        sample bucket's manifest, which carries the same field.  When the
        manifest fetch failed or the bucket predates the embed, this returns
        ``{}`` and ``get_schema()`` for unloaded tables raises ``ValueError``.
        """
        schema = self._manifest_data.get("schema") or {}
        tables = schema.get("tables")
        return tables if isinstance(tables, dict) else {}

    def get_schema(self, table: str) -> dict[str, str]:
        """Return column names and their types for a table.

        When the table is loaded in DuckDB the types come from DuckDB's own
        ``DESCRIBE`` (authoritative, reflects the actual Parquet file).  When
        the table is not loaded — including in sample mode before any data has
        been downloaded — the schema is served from the ``schema`` field of
        the R2 ``manifest.json`` fetched at SDK init.

        Args:
            table: Any known table name (loaded or not).

        Returns:
            Dict mapping column name → type string,
            e.g. ``{"cik": "VARCHAR", "name": "VARCHAR", "is_active": "BOOLEAN"}``.

        Raises:
            ValueError: If ``table`` is not loaded and not found in the
                manifest schema.  Includes the case where the manifest had no
                ``schema`` field (e.g. a pre-2026-05 snapshot or an offline
                init that fell back to a stub manifest).
            ValueinDataError: If DuckDB cannot describe a loaded table.
        """
        if table in self._tables:
            try:
                rows = self.con.execute(f"DESCRIBE {table}").fetchall()
                return {row[0]: row[1] for row in rows}
            except Exception as e:
                raise ValueinDataError(f"Failed to describe table '{table}': {e}") from e

        # Fall back to the manifest's embedded schema for unloaded tables
        # (includes sample mode).  Same shape as PARQUET_SCHEMA["tables"].
        manifest_tables = self._manifest_tables_schema()
        if table in manifest_tables:
            return {
                col: meta.get("type", "UNKNOWN")
                for col, meta in manifest_tables[table]["columns"].items()
            }

        all_known = sorted(manifest_tables.keys() | set(self._tables))
        raise ValueError(f"Unknown table '{table}'. Known tables: {', '.join(all_known)}")

    def _annotate_sample_empty(self, df: pd.DataFrame) -> pd.DataFrame:
        """Attach a sample-tier conversion hint to empty DataFrames.

        Silently returning an empty DataFrame on the sample tier makes the
        sample-to-paid conversion invisible — a first-time user thinks the
        SDK is broken when in fact the ticker they queried is simply outside
        the curated ~50-ticker, 2020-2023 sample slice. This annotator:

        1. Fires a ``UserWarning`` so interactive / notebook users see the
           nudge in their output. Standard ``warnings`` filters suppress it
           when callers opt out (``warnings.simplefilter("ignore")``).
        2. Populates ``df.attrs["valuein"]`` with a machine-readable hint
           dict so programmatic callers (agents, ETL jobs) can branch on
           ``df.attrs.get("valuein", {}).get("reason")`` without scraping
           stderr. ``df.attrs`` is pandas' blessed metadata channel and
           survives most DataFrame operations.

        The hint includes ``upgrade_url`` identical to the field the MCP
        Worker returns on 4xx responses — one contract across both surfaces.

        No-op on any non-sample plan or non-empty result. See GTM plan:
        every silent failure is a conversion killed.
        """
        if self._plan != "sample" or len(df) != 0:
            return df

        # Include the canonical rate limit for the next tier up (sp500 =
        # Free) so the user sees what upgrading actually buys them. Source:
        # valuein_sdk.plans.get_plans() → /v1/plans, falls back to the
        # hardcoded mirror on gateway outage — never raises.
        from .plans import format_rate_limit

        next_tier_limits = format_rate_limit("sp500")
        message = (
            "Running on the sample tier (~50 curated tickers, 2020-2023 only). "
            "Got 0 rows — the ticker may be outside the sample slice. "
            "Sign up free for the S&P 500 tier (full history, 500+ companies, "
            f"{next_tier_limits}) at https://valuein.biz/pricing."
        )
        df.attrs["valuein"] = {
            "plan": "sample",
            "rows_returned": 0,
            "reason": "possible_sample_tier_limit",
            "message": message,
            "upgrade_url": "https://valuein.biz/pricing",
        }
        # stacklevel=3 points the warning at the CALLER of run_query() /
        # run_template(), not at this helper — the user needs to see their
        # own code, not SDK internals.
        warnings.warn(message, UserWarning, stacklevel=3)
        return df

    def run_query(self, sql: str) -> pd.DataFrame:
        """Execute a read-only SQL query against the loaded Parquet views.

        Accepts standard DuckDB SQL — ``SELECT`` statements and CTEs
        (``WITH`` clauses).  All filter values must be embedded directly in
        the query string as SQL literals; there are no external parameter
        placeholders.  For templated queries with named parameters, use
        :meth:`run_template` instead.

        **Security guarantees**:

        - Only ``SELECT`` / ``WITH`` / ``EXPLAIN`` are permitted — no DDL,
          DML, or administrative commands.
        - File-system and network I/O functions (``read_parquet``, ``glob``,
          …) are blocked.
        - DuckDB system-catalog access (``duckdb_settings()``,
          ``information_schema.*``, …) is blocked.
        - Multiple statements separated by ``;`` are rejected.
        - Presigned R2 URLs are refreshed transparently before execution.

        Args:
            sql: A DuckDB-compatible SELECT query with all values embedded
                 as SQL literals.  Examples::

                     client.run_query(
                         "SELECT * FROM references WHERE symbol = 'AAPL'"
                     )

                     client.run_query(
                         "SELECT symbol, SUM(numeric_value) AS total_revenue "
                         "FROM fact "
                         "WHERE standard_concept = 'TotalRevenue' "
                         "  AND fiscal_year >= 2020 "
                         "GROUP BY symbol "
                         "ORDER BY total_revenue DESC "
                         "LIMIT 25"
                     )

        Returns:
            A ``pandas.DataFrame`` containing the full result set.

        Raises:
            TypeError:        If ``sql`` is not a ``str``.
            ValueError:       If the query violates any security or format
                              policy (reported before DuckDB is invoked).
            ValueinDataError: If DuckDB raises a parse, binding, I/O,
                              memory, or runtime error during execution.

        Note:
            For zero-copy Arrow output use :meth:`to_arrow`.
            For Polars use :meth:`to_polars`.
            For large result sets that must not be materialised at once,
            use :meth:`stream`.
        """
        self._validate_raw_sql(sql)

        if self._remote_view_expiry:
            self._maybe_refresh_remote_views()

        t0 = time.monotonic()
        result: pd.DataFrame | None = None
        try:
            result = self.con.execute(sql).df()
            return self._annotate_sample_empty(result)
        except duckdb.ParserException as e:
            raise ValueinDataError(f"SQL syntax error: {e}") from e
        except duckdb.CatalogException as e:
            raise ValueinDataError(
                f"SQL references an unknown table or column: {e}. "
                f"Available tables: {', '.join(self.tables())}"
            ) from e
        except duckdb.BinderException as e:
            raise ValueinDataError(f"SQL binding error (check column names and types): {e}") from e
        except duckdb.InvalidInputException as e:
            raise ValueinDataError(f"Invalid input in SQL query: {e}") from e
        except duckdb.IOException as e:
            # Most likely a presigned URL that expired mid-query.
            raise ValueinDataError(
                f"Remote data read failed — the presigned URL may have expired "
                f"mid-query. Retry once; the view will be refreshed automatically. "
                f"Detail: {e}"
            ) from e
        except duckdb.OutOfMemoryException as e:
            raise ValueinDataError(
                f"Query exceeded the memory limit ({self.config.memory_limit}). "
                "Add WHERE / LIMIT clauses to reduce the result set, or increase "
                "ValueinConfig.memory_limit."
            ) from e
        except duckdb.Error as e:
            raise ValueinDataError(f"SQL execution failed: {e}") from e
        finally:
            elapsed = time.monotonic() - t0
            _logger.debug(
                "run_query() %s in %.3fs",
                f"returned {len(result)} rows" if result is not None else "raised an error",
                elapsed,
            )

    def to_arrow(self, sql: str) -> pq.Table:
        """Execute SQL and return the result as a PyArrow Table.

        Uses DuckDB's native Arrow export path — zero Python-object overhead.
        Suitable for passing directly to Spark, Polars, or any Arrow-compatible
        engine without a pandas round-trip.

        Applies the same security validation as :meth:`run_query` — only
        ``SELECT`` / ``WITH`` / ``EXPLAIN`` are permitted; file I/O functions,
        DML, and system-catalog access are blocked.

        Args:
            sql: DuckDB SQL query string.

        Returns:
            ``pyarrow.Table`` with the full result set.

        Raises:
            TypeError:        If ``sql`` is not a ``str``.
            ValueError:       If the query violates any security policy.
            ValueinDataError: If DuckDB raises during execution.

        Example::

            table = client.to_arrow(
                "SELECT r.* "
                "FROM \"references\" r "
                "JOIN index_membership im ON im.cik = r.cik "
                "WHERE im.index_name = 'SP500' AND im.removal_date IS NULL"
            )
            # Pass to Spark:
            spark_df = spark.createDataFrame(table.to_pandas())
        """
        self._validate_raw_sql(sql)

        if self._remote_view_expiry:
            self._maybe_refresh_remote_views()
        try:
            return self.con.execute(sql).fetch_arrow_table()
        except duckdb.ParserException as e:
            raise ValueinDataError(f"SQL syntax error: {e}") from e
        except duckdb.CatalogException as e:
            raise ValueinDataError(
                f"SQL references an unknown table or column: {e}. "
                f"Available tables: {', '.join(self.tables())}"
            ) from e
        except duckdb.BinderException as e:
            raise ValueinDataError(f"SQL binding error (check column names and types): {e}") from e
        except duckdb.InvalidInputException as e:
            raise ValueinDataError(f"Invalid input in SQL query: {e}") from e
        except duckdb.IOException as e:
            raise ValueinDataError(
                f"Remote data read failed — the presigned URL may have expired "
                f"mid-query. Retry once; the view will be refreshed automatically. "
                f"Detail: {e}"
            ) from e
        except duckdb.OutOfMemoryException as e:
            raise ValueinDataError(
                f"Query exceeded the memory limit ({self.config.memory_limit}). "
                "Add WHERE / LIMIT clauses to reduce the result set, or increase "
                "ValueinConfig.memory_limit."
            ) from e
        except duckdb.Error as e:
            raise ValueinDataError(f"Arrow export failed: {e}") from e

    def to_polars(self, sql: str) -> Any:
        """Execute SQL and return the result as a Polars DataFrame.

        Chains through the Arrow path for zero-copy conversion.

        Args:
            sql: DuckDB SQL query string.

        Returns:
            ``polars.DataFrame`` with the full result set.

        Raises:
            ImportError: If polars is not installed.
            ValueinDataError: If DuckDB raises during execution.

        Example::

            df = client.to_polars("SELECT symbol, sector FROM references LIMIT 100")
        """
        try:
            import polars as pl
        except ImportError:
            raise ImportError("polars is not installed. Run: pip install polars") from None
        return pl.from_arrow(self.to_arrow(sql))

    def stream(self, sql: str, batch_size: int = 10_000) -> Iterator[pd.DataFrame]:
        """Execute SQL and yield results in batches to avoid materialising a huge DataFrame.

        Useful when querying large tables such as ``fact`` where the full result set
        may not fit comfortably in RAM.

        Args:
            sql: DuckDB SQL query string.
            batch_size: Maximum number of rows per yielded DataFrame (default 10 000).

        Yields:
            Consecutive DataFrames of up to ``batch_size`` rows each.

        Raises:
            ValueinDataError: If DuckDB raises an error while preparing or streaming.

        Applies the same security validation as :meth:`run_query` — only
        ``SELECT`` / ``WITH`` / ``EXPLAIN`` are permitted; file I/O functions,
        DML, and system-catalog access are blocked.

        Example::

            for chunk in client.stream("SELECT * FROM fact WHERE fiscal_year = 2023"):
                process(chunk)
        """
        self._validate_raw_sql(sql)

        if self._remote_view_expiry:
            self._maybe_refresh_remote_views()
        try:
            cursor = self.con.cursor()
            cursor.execute(sql)
        except duckdb.ParserException as e:
            raise ValueinDataError(f"SQL syntax error: {e}") from e
        except duckdb.CatalogException as e:
            raise ValueinDataError(
                f"SQL references an unknown table or column: {e}. "
                f"Available tables: {', '.join(self.tables())}"
            ) from e
        except duckdb.BinderException as e:
            raise ValueinDataError(f"SQL binding error (check column names and types): {e}") from e
        except duckdb.InvalidInputException as e:
            raise ValueinDataError(f"Invalid input in SQL query: {e}") from e
        except duckdb.Error as e:
            raise ValueinDataError(f"SQL stream failed: {e}") from e

        # fetch_df_chunk uses DuckDB's Arrow path: zero-copy, no Python-list
        # intermediate. vectors_per_chunk maps batch_size → DuckDB vector units
        # (each vector ≈ 2048 rows by default).
        vectors_per_chunk = max(1, batch_size // 2048)
        while True:
            try:
                chunk = cursor.fetch_df_chunk(vectors_per_chunk)
            except Exception as e:
                raise ValueinDataError(f"SQL stream read failed: {e}") from e
            if chunk.shape[0] == 0:
                break
            yield chunk

    def _validate_template_params(self, params: dict[str, object]) -> None:
        """Validate all template parameters before Jinja2 rendering.

        Raises:
            TypeError: When a parameter has the wrong Python type.
            ValueError: When a parameter value fails format or allowlist checks.
        """
        for key, val in params.items():
            match key:
                case "ticker":
                    if not isinstance(val, str) or not _TICKER_RE.match(val):
                        raise ValueError(
                            f"ticker must be 1–10 uppercase alphanumeric characters "
                            f"(e.g. 'AAPL', 'BRK.B'), got {val!r}"
                        )
                case "tickers":
                    if not isinstance(val, (list, tuple)):
                        raise TypeError("tickers must be a list/tuple")
                    if not val:
                        raise ValueError("tickers cannot be empty")
                    bad = [t for t in val if not isinstance(t, str) or not _TICKER_RE.match(t)]
                    if bad:
                        raise ValueError(f"Invalid ticker(s) in tickers: {bad}")
                case "form_types":
                    if not isinstance(val, (list, tuple)):
                        raise TypeError("form_types must be a list/tuple")
                    invalid = set(val) - ALLOWED_FORM_TYPES  # type: ignore[arg-type]
                    if invalid:
                        raise ValueError(f"Invalid form_types: {sorted(invalid)}")
                case "metrics":
                    if not isinstance(val, (list, tuple)):
                        raise TypeError("metrics must be a list/tuple")
                    if not val:
                        raise ValueError("metrics cannot be empty")
                    if not all(isinstance(v, str) for v in val):  # type: ignore[union-attr]
                        raise TypeError("All metrics must be strings")
                case "metric":
                    if not isinstance(val, str):
                        raise TypeError("metric must be a string")
                    known = self._concept_set
                    if known and val not in known:
                        warnings.warn(
                            f"metric={val!r} is not a known standard_concept and may return "
                            f'zero rows. Check client.run_query("SELECT DISTINCT standard_concept '
                            f'FROM taxonomy_guide") for the full list.',
                            UserWarning,
                            stacklevel=4,
                        )
                case "start_date" | "end_date" | "backtest_date":
                    if not isinstance(val, str) or not _DATE_RE.match(val):
                        raise ValueError(
                            f"{key} must be an ISO 8601 date string 'YYYY-MM-DD', got {val!r}"
                        )
                case "simulation_timestamp":
                    if not isinstance(val, str) or not _DATETIME_RE.match(val):
                        raise ValueError(
                            f"simulation_timestamp must be an ISO 8601 datetime "
                            f"'YYYY-MM-DD HH:MM[:SS]', got {val!r}"
                        )
                case "cik":
                    if not isinstance(val, str) or not _CIK_RE.match(val):
                        raise ValueError(
                            f"cik must be a numeric string of 1–10 digits, got {val!r}"
                        )
                case "frame":
                    if not isinstance(val, str) or not _FRAME_RE.match(val):
                        raise ValueError(
                            f"frame must match CY{{YYYY}}(Q1–Q4|FY), "
                            f"e.g. 'CY2024Q1' or 'CY2023FY', got {val!r}"
                        )
                case "mic_code":
                    if not isinstance(val, str) or not _MIC_RE.match(val):
                        raise ValueError(
                            f"mic_code must be exactly 4 uppercase letters (ISO 10383 MIC), "
                            f"e.g. 'XNYS', got {val!r}"
                        )
                case "target_item_code":
                    if not isinstance(val, str) or not _ITEM_CODE_RE.match(val):
                        raise ValueError(
                            f"target_item_code must be in N.NN format "
                            f"(e.g. '1.01', '5.02'), got {val!r}"
                        )
                case "stale_days":
                    if not isinstance(val, int) or val <= 0:
                        raise ValueError(f"stale_days must be a positive integer, got {val!r}")
                case "fiscal_period":
                    if val not in {"Q1", "Q2", "Q3", "Q4", "FY"}:
                        raise ValueError(
                            f"fiscal_period must be one of Q1, Q2, Q3, Q4, FY, got {val!r}"
                        )
                case "min_fiscal_year":
                    if not isinstance(val, int) or not (1990 <= val <= 2100):
                        raise ValueError(
                            f"min_fiscal_year must be an integer between 1990 and 2100, got {val!r}"
                        )

    def _validate_raw_sql(self, sql: str) -> None:
        """Gate-check a raw SQL string before it reaches DuckDB.

        Enforces a defence-in-depth policy through five sequential checks:

        1. **Type and size** — ``sql`` must be a non-empty ``str`` under
           ``_SQL_MAX_LEN`` characters.
        2. **Single-statement constraint** — a trailing ``;`` is tolerated
           (common in notebook cells) but a ``;`` anywhere else is rejected,
           preventing multi-statement injection.
        3. **Permitted first token** — the comment-stripped body must begin
           with ``SELECT``, ``WITH``, or ``EXPLAIN``.  All DDL (``CREATE``,
           ``DROP``, …), DML (``INSERT``, ``UPDATE``, …) and administrative
           commands (``ATTACH``, ``INSTALL``, ``COPY``, …) are rejected at
           this point when used as top-level statements.
        4. **Embedded DML** — ``INSERT INTO``, ``DELETE FROM``,
           ``MERGE INTO``, and ``UPDATE … SET`` are blocked anywhere in the
           body, including inside CTEs, where the first-token check cannot
           reach them.
        5. **File I/O and system-catalog access** — function calls that read
           from the host filesystem or network (``read_parquet``, ``glob``,
           …) and references to DuckDB system tables / SQL standard catalogs
           (``duckdb_settings()``, ``information_schema.*``, …) are rejected.

        Args:
            sql: Raw SQL string to validate.

        Raises:
            TypeError:  If ``sql`` is not a ``str``.
            ValueError: If any policy check fails, with a descriptive message
                        that identifies the specific violation.
        """
        if not isinstance(sql, str):
            raise TypeError(f"sql must be a str, got {type(sql).__name__!r}")

        sql = sql.strip()
        if not sql:
            raise ValueinValidationError("SQL query cannot be empty.")

        if len(sql) > _SQL_MAX_LEN:
            raise ValueinValidationError(
                f"SQL query length ({len(sql):,} chars) exceeds the "
                f"{_SQL_MAX_LEN:,}-character limit."
            )

        # Strip comments before all pattern checks to prevent obfuscation.
        clean = _strip_sql_comments(sql)

        # ── Check 1: single-statement constraint ──────────────────────────
        # A trailing ';' is harmless and common in notebooks — strip it first.
        body = clean.rstrip().rstrip(";")
        if ";" in body:
            raise ValueinValidationError(
                "Multiple SQL statements are not permitted. Submit one SELECT query at a time."
            )

        # ── Check 2: permitted first token ────────────────────────────────
        tokens = body.split()
        first = tokens[0].upper() if tokens else ""
        if first not in _SQL_ALLOWED_FIRST_TOKENS:
            raise ValueinValidationError(
                f"Only SELECT queries are allowed (including CTEs starting with WITH "
                f"and EXPLAIN). Got statement type: '{first}'."
            )

        # ── Check 3: embedded DML (dangerous inside CTEs) ─────────────────
        m = _SQL_EMBEDDED_DML_RE.search(clean)
        if m:
            raise ValueinValidationError(
                f"Data-modification statement '{m.group().split()[0].upper()}' "
                "is not permitted in ad-hoc queries."
            )

        # ── Check 4: file-system / network I/O functions ──────────────────
        m = _SQL_IO_FUNC_RE.search(clean)
        if m:
            raise ValueinValidationError(
                f"Function '{m.group(0).rstrip('(').strip().lower()}()' bypasses the Valuein data "
                "layer and is not permitted. Query the registered table views instead."
            )

        # ── Check 5: system-catalog and DuckDB internal tables ────────────
        if _SQL_SYSCAT_RE.search(clean):
            raise ValueinValidationError(
                "Access to DuckDB system catalogs and internal tables "
                "(duckdb_*, information_schema, pg_catalog) is not permitted."
            )

    # ── Typed helpers (parquet schema 2.3.0+) ──────────────────────────────
    #
    # Each wraps ``run_query()`` for an upstream-2.3.0 table or a Bloomberg
    # Option-C column set so callers don't need to remember the table name
    # or the per-column semantics.  Helpers are intentionally thin — the
    # full power-user surface remains ``run_query()`` / ``run_template()``.

    def factor_scores(
        self,
        ticker: str | None = None,
        sector: str | None = None,
        min_composite_rank: float | None = None,
        limit: int = 100,
    ) -> pd.DataFrame:
        """Return rows from the ``factor_scores`` table.

        ``factor_scores`` ships in parquet schema 2.3.0+ and pre-computes
        cross-sectional factor columns (roe, gross_margin, operating_margin,
        net_profit_margin, revenue_growth_yoy, fcf_to_assets, debt_to_equity,
        asset_turnover, current_ratio, piotroski_f_score) plus a percentile
        ``*_rank`` for each (0.0–1.0 where 1.0 = best) and a proprietary
        ``composite_rank``.

        Args:
            ticker:              Filter to a single symbol.  Mutually exclusive
                                 with the cross-sectional filters below.
            sector:              Filter to a single sector (case-sensitive).
            min_composite_rank:  Floor on ``composite_rank`` (0.0–1.0).
            limit:               Row cap (1–10000).  Default 100.

        Example::

            top = client.factor_scores(sector="Technology", min_composite_rank=0.8, limit=20)
        """
        if not 1 <= int(limit) <= 10_000:
            raise ValueError("limit must be between 1 and 10000")
        if min_composite_rank is not None and not 0.0 <= min_composite_rank <= 1.0:
            raise ValueError("min_composite_rank must be between 0.0 and 1.0")

        where_clauses: list[str] = []
        if ticker is not None:
            t = str(ticker).strip().replace("'", "''").upper()
            where_clauses.append(f"r.symbol = '{t}'")
        if sector is not None:
            s = str(sector).strip().replace("'", "''")
            where_clauses.append(f"r.sector = '{s}'")
        if min_composite_rank is not None:
            where_clauses.append(f"fs.composite_rank >= {float(min_composite_rank)}")
        where_sql = ("WHERE " + " AND ".join(where_clauses)) if where_clauses else ""

        sql = (
            "SELECT r.symbol, r.name, r.sector, fs.* "
            "FROM factor_scores fs "
            'JOIN "references" r ON r.cik = fs.entity_id '
            f"{where_sql} "
            "ORDER BY fs.composite_rank DESC NULLS LAST "
            f"LIMIT {int(limit)}"
        )
        return self.run_query(sql)

    def earnings_signals(
        self,
        ticker: str | None = None,
        min_surprise_pct: float | None = None,
        direction: str | None = None,
        limit: int = 100,
    ) -> pd.DataFrame:
        """Return rows from the ``earnings_signals`` table.

        ``earnings_signals`` ships in parquet schema 2.3.0+ and pre-computes
        a proprietary TTM EPS trend estimate (``eps_trend_est``), the most
        recent ``eps_actual``, the surprise pct ``eps_surprise_pct`` (actual
        EPS measured against the trend estimate), and ``revenue_yoy_pct``.

        Args:
            ticker:           Filter to a single symbol.
            min_surprise_pct: Filter on ``ABS(eps_surprise_pct)`` (e.g. 0.10
                              for ±10%).  None = no surprise floor.
            direction:        ``"positive"`` | ``"negative"`` | None.
            limit:            Row cap (1–10000).  Default 100.
        """
        if not 1 <= int(limit) <= 10_000:
            raise ValueError("limit must be between 1 and 10000")
        if direction not in (None, "positive", "negative"):
            raise ValueError("direction must be 'positive', 'negative', or None")

        where_clauses: list[str] = []
        if ticker is not None:
            t = str(ticker).strip().replace("'", "''").upper()
            where_clauses.append(f"r.symbol = '{t}'")
        if min_surprise_pct is not None:
            where_clauses.append(f"ABS(es.eps_surprise_pct) >= {float(min_surprise_pct)}")
        if direction == "positive":
            where_clauses.append("es.eps_surprise_pct > 0")
        elif direction == "negative":
            where_clauses.append("es.eps_surprise_pct < 0")
        where_sql = ("WHERE " + " AND ".join(where_clauses)) if where_clauses else ""

        sql = (
            "SELECT r.symbol, r.name, r.sector, es.* "
            "FROM earnings_signals es "
            'JOIN "references" r ON r.cik = es.entity_id '
            f"{where_sql} "
            "ORDER BY ABS(es.eps_surprise_pct) DESC NULLS LAST "
            f"LIMIT {int(limit)}"
        )
        return self.run_query(sql)

    def pit_universe(
        self,
        as_of_date: str,
        index: str = "SP500",
        as_of_basis: str = "effective",
    ) -> pd.DataFrame:
        """Return a survivorship-free index universe at a historical date.

        Wraps the ``pit_universe_announcement`` SQL template so callers don't
        have to render Jinja by hand.  Returns one row per
        (entity_id, security at-the-date) with NULL ``ticker_at_date`` for
        delisted issuers.

        Args:
            as_of_date:  Historical date (``YYYY-MM-DD``).
            index:       Index short code (``SP500`` | ``NASDAQ100`` |
                         ``RUSSELL3000``).  Default ``SP500``.
            as_of_basis: ``"effective"`` (first trading day as a member —
                         passive index replication, default) or
                         ``"announcement"`` (S&P public announcement date —
                         inclusion-arbitrage backtests).  Schema 2.3.0+ —
                         pre-2015 changes generally lack press-release
                         coverage so ``announcement`` rows with
                         ``announcement_date IS NULL`` are silently skipped.
        """
        if as_of_basis not in ("effective", "announcement"):
            raise ValueError("as_of_basis must be 'effective' or 'announcement'")
        return self.run_template(
            "pit_universe_announcement",
            index=index,
            as_of_date=as_of_date,
            as_of_basis=as_of_basis,
        )

    def run_template(self, name: str, **kwargs: object) -> pd.DataFrame:
        """Execute a named SQL template from the ``queries/`` directory.

        Templates use Jinja2 syntax with ``sql_quote``, ``sql_list``, and
        ``sql_identifier`` filters for safe, injection-free SQL rendering.

        Common parameters are auto-populated with sensible defaults when omitted:

        * ``form_types``      → ``["10-K", "10-Q"]``
        * ``start_date``      → 5 years before today (ISO 8601)
        * ``end_date``        → today (ISO 8601)
        * ``stale_days``      → ``180``
        * ``fiscal_period``   → ``"Q1"``
        * ``min_fiscal_year`` → ``2020``
        * ``metrics``         → core income-statement, balance-sheet, and cash-flow concepts
        * ``tickers``         → ``[ticker]`` when a single ``ticker`` kwarg is provided

        Args:
            name:     Template key (filename without ``.sql``).
            **kwargs: Template variables.  All are validated before render.

        Returns:
            Query result as a pandas DataFrame.

        Raises:
            FileNotFoundError: If ``name`` is not in the template index.
            TypeError:         On type validation failures.
            ValueError:        On format or allowlist validation failures.
            ValueinDataError:  If DuckDB raises during execution.

        Example::

            # Minimal call — only ticker required; all other params auto-populated
            df = client.run_template("fundamentals_by_ticker", ticker="AAPL")

            # Explicit overrides
            df = client.run_template("free_cash_flow",
                                     ticker="MSFT",
                                     form_types=["10-K"],
                                     start_date="2018-01-01",
                                     end_date="2023-12-31")
        """
        from jinja2 import meta as jinja_meta

        # ── Template lookup ───────────────────────────────────────────────
        path = self.query_cache.get(name)
        if not path:
            available = sorted(self.query_cache) or ["(none)"]
            raise FileNotFoundError(
                f"Template '{name}' not found. Available: {', '.join(available)}"
            )

        # ── Load template source & discover variables ─────────────────────
        with open(path) as fh:
            source = fh.read()

        parsed_ast = self._jinja_env.parse(source)
        template_vars = jinja_meta.find_undeclared_variables(parsed_ast)

        # ── Inject smart defaults for missing common params ───────────────
        today = date.today()
        five_years_ago = today.replace(year=today.year - 5).isoformat()
        _defaults: dict[str, object] = {
            "form_types": ["10-K", "10-Q"],
            "start_date": five_years_ago,
            "end_date": today.isoformat(),
            "stale_days": 180,
            "fiscal_period": "Q1",
            "min_fiscal_year": 2020,
            "metrics": [
                "TotalRevenue",
                "GrossProfit",
                "OperatingIncome",
                "NetIncome",
                "TotalAssets",
                "TotalLiabilities",
                "StockholdersEquity",
                "OperatingCashFlow",
                "CAPEX",
            ],
            "tickers": [kwargs["ticker"]] if "ticker" in kwargs else [],
        }
        params: dict[str, object] = {}
        for var, default in _defaults.items():
            if var in template_vars and var not in kwargs:
                params[var] = default
        params.update(kwargs)

        # ── Validate ──────────────────────────────────────────────────────
        self._validate_template_params(params)

        # ── Render via Jinja2 ─────────────────────────────────────────────
        tmpl = self._load_jinja_template(path)
        try:
            rendered_sql = tmpl.render(**params)
        except Exception as e:
            raise ValueError(f"Template '{name}' render failed: {e}") from e

        # ── Execute ───────────────────────────────────────────────────────
        if self._remote_view_expiry:
            self._maybe_refresh_remote_views()
        try:
            df = self.con.execute(rendered_sql).df()
            return self._annotate_sample_empty(df)
        except Exception as e:
            raise ValueinDataError(f"Template '{name}' execution failed: {e}") from e

    def _get_presigned_url(self, table: str, expires_in: int = _PRESIGN_TTL_S) -> str:
        """Fetch a short-lived presigned R2 URL from the gateway (internal only).

        Called by ``_load_tables`` and ``_maybe_refresh_remote_views`` to mount
        large tables as remote httpfs views.  Not part of the public API.
        """
        if self._plan == "sample":
            raise ValueError("Presigned URLs require an API key.")
        response = self._transport.get(f"/v1/presign/{table}?expires_in={expires_in}")
        return response.json()["url"]

    def _maybe_refresh_remote_views(self) -> None:
        """Silently refresh any presigned-URL views that are close to expiry.

        Called at the start of every ``run_query()`` and ``stream()`` invocation.
        Views with more than ``_PRESIGN_REFRESH_BUFFER_S`` seconds remaining are
        left untouched.  On refresh failure the old view is preserved and a
        warning is emitted — the next query will retry automatically.
        """
        now = time.monotonic()
        for table, expiry in list(self._remote_view_expiry.items()):
            if expiry - now <= _PRESIGN_REFRESH_BUFFER_S:
                try:
                    url = self._get_presigned_url(table, expires_in=_PRESIGN_TTL_S)
                    self.con.execute(
                        f"CREATE OR REPLACE VIEW \"{table}\" AS SELECT * FROM read_parquet('{url}')"
                    )
                    self._remote_view_expiry[table] = now + _PRESIGN_TTL_S
                    _logger.debug("Refreshed remote view for '%s'", table)
                except Exception as exc:
                    _logger.warning("Failed to refresh remote view for '%s': %s", table, exc)

    def tables(self) -> list[str]:
        return sorted(self._tables)

    def __repr__(self) -> str:
        return (
            f"ValueinClient(plan={self.plan!r}, "
            f"snapshot={self._manifest_data.get('snapshot', 'unknown')!r}, "
            f"tables={len(self._tables)})"
        )

    # ── MCP docgen proxies ──────────────────────────────────────────────
    #
    # The MCP server's document-generation tools render structured tool
    # responses into Office files (Excel / Word) inside a 5-min CPU window
    # and upload to R2 with a 15-min presigned URL. These are the SDK
    # wrappers so Python power users can reach docgen without writing their
    # own JSON-RPC client. Pro+ tier required.

    def _call_mcp(self, name: str, arguments: dict[str, object]) -> dict[str, object]:
        """Forward a tools/call to the MCP server and return the result.

        Args:
            name: MCP tool name.
            arguments: Tool arguments dict.

        Returns:
            The MCP ``result`` envelope (typically ``content`` array +
            ``structuredContent``).
        """
        return self._transport.call_mcp_tool(self.mcp_url, name, arguments)

    def generate_dcf_xlsx(
        self,
        ticker: str,
        *,
        as_of_date: str | None = None,
        depth: str = "standard",
    ) -> dict[str, object]:
        """Render a forward DCF result into a downloadable Excel workbook.

        Calls the MCP server's ``generate_dcf_xlsx`` tool, which builds an
        OOXML workbook with Summary, 5×5 Sensitivity, and Inputs sheets
        (sensitivity uses native Excel conditional formatting) and uploads
        to R2 with a 15-minute presigned URL. Pro+ tier required.

        Args:
            ticker: Stock ticker, e.g. ``"AAPL"``.
            as_of_date: Optional point-in-time date (``YYYY-MM-DD``) for
                survivorship-free backtests. Omit for the latest data.
            depth: One of ``"quick"`` / ``"standard"`` / ``"forensic"``.
                Defaults to ``"standard"``.

        Returns:
            The MCP ``result`` envelope with a presigned download URL in
            ``structuredContent.url`` (expires in 15 min).

        Raises:
            ValueinAuthError: 401 / 402 — invalid or suspended token.
            ValueinPlanError: 403 — Pro+ tier required.
            ValueinAPIError: MCP tool error.
        """
        args: dict[str, object] = {"ticker": ticker, "depth": depth}
        if as_of_date is not None:
            args["as_of_date"] = as_of_date
        return self._call_mcp("generate_dcf_xlsx", args)

    def generate_research_brief_docx(
        self,
        ticker: str,
        *,
        as_of_date: str | None = None,
        depth: str = "full",
        peers: str | None = None,
    ) -> dict[str, object]:
        """Render a single-ticker research brief as a downloadable Word file.

        Calls the MCP server's ``generate_research_brief_docx`` tool, which
        composes fundamentals + valuation + ratios + capital allocation +
        peer comparison + recent catalysts + SEC lineage into a single
        institutional-quality .docx and uploads to R2 with a 15-minute
        presigned URL. Pro+ tier required.

        Args:
            ticker: Stock ticker, e.g. ``"AAPL"``.
            as_of_date: Optional point-in-time date (``YYYY-MM-DD``).
            depth: One of ``"quick"`` / ``"full"`` / ``"forensic"``.
                Defaults to ``"full"``.
            peers: Optional comma-separated peer tickers for the comparison
                table (e.g. ``"MSFT,GOOGL"``). Omit to auto-derive.

        Returns:
            The MCP ``result`` envelope with a presigned download URL in
            ``structuredContent.url`` (expires in 15 min).

        Raises:
            ValueinAuthError: 401 / 402 — invalid or suspended token.
            ValueinPlanError: 403 — Pro+ tier required.
            ValueinAPIError: MCP tool error.
        """
        args: dict[str, object] = {"ticker": ticker, "depth": depth}
        if as_of_date is not None:
            args["as_of_date"] = as_of_date
        if peers is not None:
            args["peers"] = peers
        return self._call_mcp("generate_research_brief_docx", args)

    def generate_comps_xlsx(
        self,
        ticker: str,
        *,
        peers: str | None = None,
        as_of_date: str | None = None,
    ) -> dict[str, object]:
        """Render a peer-comparables table as a downloadable Excel workbook.

        Calls the MCP server's ``generate_comps_xlsx`` tool, which builds a
        Comps sheet as a named Excel Table so users get one-click Insert
        Chart in Excel, and uploads to R2 with a 15-minute presigned URL.
        Pro+ tier required.

        Args:
            ticker: Subject ticker, e.g. ``"AAPL"``.
            peers: Optional comma-separated peer tickers (e.g.
                ``"MSFT,GOOGL"``). Omit to auto-derive via
                ``get_peer_comparables``.
            as_of_date: Optional point-in-time date (``YYYY-MM-DD``).

        Returns:
            The MCP ``result`` envelope with a presigned download URL in
            ``structuredContent.url`` (expires in 15 min).

        Raises:
            ValueinAuthError: 401 / 402 — invalid or suspended token.
            ValueinPlanError: 403 — Pro+ tier required.
            ValueinAPIError: MCP tool error.
        """
        args: dict[str, object] = {"ticker": ticker}
        if peers is not None:
            args["peers"] = peers
        if as_of_date is not None:
            args["as_of_date"] = as_of_date
        return self._call_mcp("generate_comps_xlsx", args)

    def close(self) -> None:
        """Explicitly close database connections and clean up managed temp files."""
        if hasattr(self, "con"):
            try:
                self.con.close()
            except Exception as exc:
                _logger.debug("DuckDB close error (suppressed): %s", exc)

        if hasattr(self, "_transport"):
            try:
                self._transport.close()
            except Exception as exc:
                _logger.debug("Transport close error (suppressed): %s", exc)

        if hasattr(self, "_managed_temp") and self._managed_temp is not None:
            try:
                self._managed_temp.cleanup()
                self._managed_temp = None
            except Exception as exc:
                _logger.debug("Temp directory cleanup error (suppressed): %s", exc)

    def __enter__(self) -> ValueinClient:
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()

    def __del__(self) -> None:
        self.close()
