"""Intelligence Object models — typed wrappers for Valuein data points.

``FactRecord`` (marketed as "Intelligence Object") wraps a single financial
data point with its full identity, temporality, and provenance chain.  The
deterministic ``fact_id`` hash enables end-to-end verification: any consumer
can recompute the hash from the five input fields and confirm it matches.

``compute_fact_id()`` is the Python-side implementation of the same SHA-256
formula used by ``data-pipeline/run_exports.py`` in Postgres.  Cross-language
parity is validated by ``tests/integration/test_fact_id.py`` in data-pipeline.
"""

from __future__ import annotations

import hashlib
from datetime import date, datetime

from pydantic import BaseModel, Field

# ── Equity-split fallback (parquet schema 2.3.0) ─────────────────────────────
#
# Schema 2.3.0 split equity into two canonical concepts:
#
#   StockholdersEquity              — parent-only (excludes NCI)
#   StockholdersEquityIncludingNCI  — institutional total (parent + NCI)
#
# Institutional consumers (banks, insurers) report consolidated balance
# sheets; these almost always want IncludingNCI.  Single-entity issuers and
# small-caps don't carry NCI, so the IncludingNCI tag is often absent and
# the parent-only tag is the only available source.
#
# Use ``EQUITY_FALLBACK_ORDER`` in your DuckDB query as the COALESCE order
# for institutional equity:
#
#   COALESCE(
#       CASE WHEN standard_concept = 'StockholdersEquityIncludingNCI'
#            THEN value_current END,
#       CASE WHEN standard_concept = 'StockholdersEquity'
#            THEN value_current END
#   ) AS equity_total
EQUITY_FALLBACK_ORDER: tuple[str, ...] = (
    "StockholdersEquityIncludingNCI",
    "StockholdersEquity",
)


def compute_fact_id(
    entity_id: str,
    accession_id: str,
    concept: str,
    period_end: date,
    unit: str,
) -> str:
    """Compute the deterministic fact identity hash.

    Formula: ``SHA-256(entity_id|accession_id|concept|YYYY-MM-DD|unit)``

    This MUST match the Postgres expression in ``run_exports.py``::

        encode(sha256(convert_to(
            entity_id || '|' || accession_id || '|' || concept
            || '|' || period_end::text || '|' || unit, 'UTF8'
        )), 'hex')

    Args:
        entity_id: SEC CIK identifier (e.g. ``"0000320193"``).
        accession_id: SEC filing accession number.
        concept: XBRL concept tag (e.g. ``"us-gaap:Revenues"``).
        period_end: Fiscal period end date.
        unit: Reporting unit (e.g. ``"USD"``, ``"USD/shares"``).

    Returns:
        64-character lowercase hex SHA-256 hash string.

    Example:
        >>> compute_fact_id("0000320193", "0000320193-24-000123",
        ...                 "us-gaap:Revenues", date(2024, 9, 28), "USD")
        'e3b0c44298fc1c14...'  # actual hash will differ
    """
    payload = f"{entity_id}|{accession_id}|{concept}|{period_end.isoformat()}|{unit}"
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


class FactRecord(BaseModel):
    """A single financial data point with full identity and provenance.

    The ``fact_id`` is a deterministic SHA-256 hash of five fields:
    ``entity_id``, ``accession_id``, ``concept``, ``period_end``, and ``unit``.
    This matches the Postgres unique constraint ``idx_fact_unique_constraint``
    and the hash computed at export time by ``run_exports.py``.

    Use ``compute_fact_id()`` to verify that a ``FactRecord``'s ``fact_id``
    matches its constituent fields — if not, the data has been tampered with
    or corrupted in transit.

    Example:
        >>> record = FactRecord(fact_id="abc...", entity_id="0000320193", ...)
        >>> expected = compute_fact_id(
        ...     record.entity_id, record.accession_id,
        ...     record.concept, record.period_end, record.unit
        ... )
        >>> assert record.fact_id == expected, "Data integrity violation!"
    """

    # ── Identity ─────────────────────────────────────────────────────────
    fact_id: str = Field(
        ...,
        description="Deterministic SHA-256 hash: entity_id|accession_id|concept|period_end|unit",
    )
    entity_id: str = Field(..., description="SEC CIK identifier (zero-padded 10-digit)")
    accession_id: str = Field(..., description="SEC filing accession number")

    # ── Semantics ────────────────────────────────────────────────────────
    concept: str = Field(..., description="XBRL concept tag (e.g. us-gaap:Revenues)")
    standard_concept: str | None = Field(
        default=None, description="Canonical standardized concept label"
    )

    # ── Temporality ──────────────────────────────────────────────────────
    period_start: date | None = Field(default=None, description="Period start date")
    period_end: date = Field(..., description="Period end date")
    fiscal_year: int | None = Field(default=None, description="Fiscal year (YYYY)")
    fiscal_period: str | None = Field(
        default=None, description="Fiscal period (FY, Q1, Q2, Q3, Q4)"
    )
    accepted_at: datetime = Field(
        ..., description="Point-in-time: when this fact became publicly known (SEC acceptance)"
    )

    # ── Value ────────────────────────────────────────────────────────────
    numeric_value: float | None = Field(default=None, description="Reported numeric value")
    derived_quarterly_value: float | None = Field(
        default=None, description="Isolated quarterly value (for YTD cash flow metrics)"
    )
    unit: str = Field(..., description="Reporting unit (USD, USD/shares, shares, etc.)")

    # ── Restatement (Option-C) ───────────────────────────────────────────
    # These four fields are computed at export time by run_exports.py using
    # a window over (entity_id, standard_concept, period_end, unit).  Every
    # row in the ledger keeps its own numeric_value (the as-observed truth),
    # but also carries the aggregate view so a consumer can ask "what's the
    # current truth?" or "was this ever restated?" without issuing a second
    # query.
    value_current: float | None = Field(
        default=None,
        description="Most-recently-known value for this (entity, concept, period, unit) "
        "tuple — latest restatement, or equal to numeric_value if never restated. "
        "Use as the default for screens and dashboards.",
    )
    value_as_filed: float | None = Field(
        default=None,
        description="Value from the original filing that first reported this tuple — "
        "the as-filed truth, useful for audit and survivorship-bias-free backtests.",
    )
    first_filed_at: datetime | None = Field(
        default=None,
        description="accepted_at of the earliest filing that reported a value for "
        "this tuple. Equals this row's accepted_at when this row IS that first filing.",
    )
    restated: bool | None = Field(
        default=None,
        description="True iff this tuple has more than one distinct numeric_value "
        "across the filing history — i.e., the company restated this figure.",
    )

    # ── Provenance ───────────────────────────────────────────────────────
    source_url: str | None = Field(
        default=None, description="SEC EDGAR filing URL for source verification"
    )
    is_audited: bool = Field(default=False, description="Whether from an audited filing (10-K)")
    is_estimated: bool = Field(default=False, description="Whether the value is estimated")
    data_quality: str | None = Field(default=None, description="Pipeline data quality flag")
    confidence_score: float | None = Field(
        default=None, description="Pipeline confidence score (0.0-1.0)"
    )

    def verify(self) -> bool:
        """Verify that fact_id matches the hash of constituent fields.

        Returns:
            True if the fact_id is valid, False if data integrity is compromised.
        """
        expected = compute_fact_id(
            self.entity_id,
            self.accession_id,
            self.concept,
            self.period_end,
            self.unit,
        )
        return self.fact_id == expected


class FilingTextRow(BaseModel):
    """One chunk of SEC filing narrative text — Risk Factors, MD&A, Business,
    etc. — extracted from an iXBRL TextBlock concept by the data-pipeline.

    Each row is a passage (≤ 1,800 chars) pre-labelled by section. Chunks are
    reconstructible in order via ``(accession_id, section, chunk_no)``; the
    ``total_chunks`` field tells you how many pieces make up the full section.

    Primary consumers:
      - Semantic search via Cloudflare Vectorize (the MCP server's
        ``search_filing_text`` tool). SDK users don't call Vectorize directly —
        embeddings are pre-computed and query embeddings happen server-side.
      - Direct DuckDB queries over ``filing_text.parquet`` for substring
        search, chunk reassembly, or custom embedding pipelines. Example::

            client = ValueinClient(tables=["references", "filing_text"])
            df = client.run_query(\"\"\"
                SELECT entity_id, section, chunk_no, text, accepted_at
                FROM filing_text
                WHERE entity_id = (SELECT cik FROM "references" WHERE symbol='AAPL')
                  AND section = 'risk_factors'
                ORDER BY accepted_at DESC, chunk_no ASC
                LIMIT 50
            \"\"\")

    PIT contract: ``accepted_at`` equals the SEC filing's acceptedDateTime —
    identical semantics to ``FactRecord.accepted_at``. Chunks are immutable
    post-ingest (``ON CONFLICT DO NOTHING`` on the Postgres primary key).
    """

    entity_id: str = Field(..., description="SEC CIK identifier (zero-padded 10-digit)")
    accession_id: str = Field(..., description="SEC filing accession number")
    section: str = Field(
        ...,
        description="Canonical section label — risk_factors | mdna | business "
        "| footnotes | controls_procedures | legal_proceedings | other",
    )
    chunk_no: int = Field(
        ..., ge=0, description="0-indexed position of this chunk within (accession_id, section)"
    )
    total_chunks: int = Field(
        ...,
        ge=1,
        description=(
            "Total chunks for this (accession_id, section); "
            "reassemble by joining chunks 0..total_chunks-1"
        ),
    )
    text: str = Field(..., min_length=1, description="The passage text (≤ 1,800 chars)")
    char_count: int = Field(
        ..., ge=1, description="len(text) — stored separately for fast filtering"
    )
    token_estimate: int | None = Field(
        default=None, description="Rough English token estimate (char_count / 4)"
    )
    report_date: datetime | None = Field(
        default=None, description="Fiscal period end of the filing (from filing.report_date)"
    )
    form_type: str | None = Field(
        default=None, description="SEC form type — 10-K, 10-K/A, 10-Q, 10-Q/A, 20-F, …"
    )
    accepted_at: datetime = Field(
        ..., description="PIT timestamp: when this filing was accepted by SEC"
    )
