# Copyright 2026 Valuein LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""HTTP transport layer for the Valuein SDK.

Wraps httpx with:
- Bearer token auth on every request
- Configurable connect / read timeouts (defaults: 30s / 120s)
- Retry with exponential backoff + jitter (3 attempts) on transient errors
- Gateway HTTP status codes mapped to the custom exception hierarchy
"""

from __future__ import annotations

import logging
import random
import time
import warnings
from typing import IO

import httpx

from .exceptions import (
    ValueinAPIError,
    ValueinAuthError,
    ValueinNotFoundError,
    ValueinPlanError,
    ValueinRateLimitError,
    ValueinTimeoutError,
)

logger = logging.getLogger("valuein_sdk")

_DEFAULT_CONNECT_TIMEOUT = 30.0
_DEFAULT_READ_TIMEOUT = 120.0  # Generous overhead for large Parquet streams
_MAX_RETRIES = 3
_RETRY_BASE_DELAY = 1.0

_RETRYABLE_STATUS = frozenset({429, 502, 503, 504})


def _backoff(attempt: int) -> float:
    """Return exponential backoff delay with jitter (0-indexed attempt)."""
    return _RETRY_BASE_DELAY * (2**attempt) + random.uniform(0.0, 0.5)


def _raise_for_status(response: httpx.Response) -> None:
    """Map gateway HTTP status codes to Valuein exceptions."""
    code = response.status_code
    # Capture ID from X-Request-ID or Cloudflare Ray
    request_id = response.headers.get("X-Request-ID") or response.headers.get("CF-Ray")

    if code == 401:
        raise ValueinAuthError("Invalid API key. Check valuein.biz/portal.", request_id=request_id)

    if code == 402:
        raise ValueinAuthError("Account suspended — payment required.", request_id=request_id)

    if code == 403:
        # Prefer structured JSON error codes over fragile body text matching.
        _PLAN_ERROR_CODES = frozenset(
            {"plan_required", "upgrade_required", "full_plan_required", "insufficient_plan"}
        )
        try:
            error_data = response.json()
            error_code = str(error_data.get("code", "") or error_data.get("error", "")).lower()
            if error_code in _PLAN_ERROR_CODES:
                raise ValueinPlanError(
                    "This resource requires a Full Dataset plan.", request_id=request_id
                )
        except (ValueError, AttributeError):
            pass
        # Fall back to body text matching when the gateway returns plain text.
        body = response.text.lower() if hasattr(response, "text") else ""
        if any(word in body for word in ["plan", "upgrade", "full"]):
            raise ValueinPlanError(
                "This resource requires a Full Dataset plan.", request_id=request_id
            )
        raise ValueinAuthError("API token has been revoked.", request_id=request_id)

    if code in (400, 404):
        try:
            url_str = str(response.url)
        except RuntimeError:
            url_str = "(unknown)"
        raise ValueinNotFoundError(f"Resource not found: {url_str}", request_id=request_id)

    if code == 429:
        retry_after = response.headers.get("Retry-After")
        wait_sec = int(retry_after) if retry_after and retry_after.isdigit() else None
        msg = f"Rate limited. Retry after {wait_sec}s." if wait_sec else "Rate limited."
        raise ValueinRateLimitError(msg, retry_after=wait_sec, request_id=request_id)

    if code >= 500:
        raise ValueinAPIError(
            f"Gateway server error (HTTP {code}).", status_code=code, request_id=request_id
        )

    if not (200 <= code < 300):
        raise ValueinAPIError(f"Unexpected HTTP {code}.", status_code=code, request_id=request_id)


class Transport:
    """Authenticated HTTP client for the Valuein gateway.

    Args:
        api_key:         Bearer token sent on every request.
        gateway_url:     Base URL of the Valuein edge gateway.
        connect_timeout: Seconds to wait while establishing the TCP connection.
                         Defaults to 30s. Increase for high-latency networks.
        read_timeout:    Seconds to wait for the server to send a response byte.
                         Defaults to 120s. Increase when pulling very large
                         Parquet files on slow connections.
    """

    def __init__(
        self,
        api_key: str,
        gateway_url: str,
        connect_timeout: float = _DEFAULT_CONNECT_TIMEOUT,
        read_timeout: float = _DEFAULT_READ_TIMEOUT,
    ) -> None:
        self._gateway_url = gateway_url.rstrip("/")
        self._connect_timeout = connect_timeout
        self._read_timeout = read_timeout
        # Held for the MCP JSON-RPC channel — same Bearer token, different host.
        self._api_key = api_key
        # Monotonic request id for JSON-RPC; not security-sensitive.
        self._mcp_id = 0

        # Defensive HTTP/2 configuration — httpx[http2] ships h2 as a dependency,
        # so a missing h2 import means the environment is broken (partial uninstall,
        # corrupted venv). Falling back gracefully is better than crashing.
        use_http2 = False
        try:
            import h2  # noqa: F401

            use_http2 = True
        except ImportError:
            warnings.warn(
                "The 'h2' package is missing from your environment. The Valuein SDK "
                "ships 'httpx[http2]' as a required dependency, so this usually indicates "
                "a corrupted virtual environment. Re-creating the venv or running "
                "'pip install --force-reinstall httpx[http2]' should restore HTTP/2 support. "
                "Falling back to HTTP/1.1 in the meantime.",
                stacklevel=2,
            )

        # Persistent Client to benefit from connection pooling.
        base_headers: dict[str, str] = {}
        if api_key:
            base_headers["Authorization"] = f"Bearer {api_key}"
        self._client = httpx.Client(
            base_url=self._gateway_url,
            headers=base_headers,
            timeout=httpx.Timeout(
                connect=connect_timeout,
                read=read_timeout,
                write=30.0,
                pool=30.0,
            ),
            http2=use_http2,
        )

    def get(self, path: str) -> httpx.Response:
        """Standard GET for small JSON payloads (manifests, health)."""
        last_exc: Exception | None = None

        for attempt in range(_MAX_RETRIES):
            try:
                response = self._client.get(path)

                if response.status_code not in _RETRYABLE_STATUS:
                    _raise_for_status(response)
                    return response

                # Trigger retry logic for 502/503/etc. by throwing the exception
                _raise_for_status(response)

            except (ValueinAuthError, ValueinPlanError, ValueinNotFoundError):
                # Hard failures should immediately bubble up to the user
                raise
            except (ValueinRateLimitError, ValueinAPIError) as exc:
                last_exc = exc
                delay = getattr(exc, "retry_after", None) or _backoff(attempt)
                logger.warning("Transient error on %s; retrying in %.1fs", path, delay)
                time.sleep(delay)
            except httpx.TimeoutException as exc:
                last_exc = exc
                delay = _backoff(attempt)
                logger.warning(
                    "Timeout on %s (attempt %d); retrying in %.1fs", path, attempt + 1, delay
                )
                time.sleep(delay)
            except httpx.ConnectError as exc:
                raise ConnectionError(f"Could not reach {self._gateway_url}.") from exc

        # Distinguish timeout exhaustion from other transient failures
        if isinstance(last_exc, httpx.TimeoutException):
            raise ValueinTimeoutError(
                f"Request to {path} timed out after {_MAX_RETRIES} attempts "
                f"(read_timeout={self._read_timeout}s). "
                "Increase ValueinConfig.read_timeout for large Parquet downloads."
            ) from last_exc

        raise ValueinAPIError(
            f"Request failed after {_MAX_RETRIES} attempts: {last_exc}"
        ) from last_exc

    def download_to_file(self, path: str, dest_file: IO[bytes]) -> None:
        """Stream a large response directly to an open file object.

        This prevents OOM crashes by never buffering the entire file in RAM.
        If a retryable error interrupts the stream, it resets the file pointer
        and tries again safely.
        """
        last_exc: Exception | None = None

        for attempt in range(_MAX_RETRIES):
            try:
                # CRITICAL: Reset file pointer to 0. If this is attempt #2 after a
                # mid-stream failure, we must overwrite the corrupted partial data.
                dest_file.seek(0)
                dest_file.truncate()

                with self._client.stream("GET", path) as response:
                    # If the gateway sends an error (403, 503, etc.) we must call
                    # response.read() before _raise_for_status; otherwise httpx
                    # raises ResponseNotRead on body access.
                    if response.status_code >= 400:
                        response.read()

                    if response.status_code not in _RETRYABLE_STATUS:
                        _raise_for_status(response)

                        # Stream in 64KB chunks directly to the file
                        for chunk in response.iter_bytes(chunk_size=65536):
                            dest_file.write(chunk)

                        # Ensure OS flushes buffer to disk before DuckDB tries to read it
                        dest_file.flush()
                        return

                    # Trigger retry logic for 502/503/etc.
                    _raise_for_status(response)

            except (ValueinAuthError, ValueinPlanError, ValueinNotFoundError):
                raise
            except (ValueinRateLimitError, ValueinAPIError, httpx.ReadError) as exc:
                last_exc = exc
                delay = getattr(exc, "retry_after", None) or _backoff(attempt)
                logger.warning("Stream interrupted on %s; retrying in %.1fs", path, delay)
                time.sleep(delay)
            except httpx.TimeoutException as exc:
                last_exc = exc
                delay = _backoff(attempt)
                logger.warning(
                    "Stream timeout on %s (attempt %d); retrying in %.1fs", path, attempt + 1, delay
                )
                time.sleep(delay)
            except httpx.ConnectError as exc:
                raise ConnectionError(f"Could not reach {self._gateway_url}.") from exc

        if isinstance(last_exc, httpx.TimeoutException):
            raise ValueinTimeoutError(
                f"Download of {path} timed out after {_MAX_RETRIES} attempts "
                f"(read_timeout={self._read_timeout}s). "
                "Increase ValueinConfig.read_timeout for large Parquet downloads."
            ) from last_exc

        raise ValueinAPIError(
            f"Download failed after {_MAX_RETRIES} attempts: {last_exc}"
        ) from last_exc

    def call_mcp_tool(
        self,
        mcp_url: str,
        name: str,
        arguments: dict[str, object],
    ) -> dict[str, object]:
        """Invoke an MCP server tool via JSON-RPC 2.0 over Streamable HTTP.

        Used by the SDK's document-generation surfaces (DCF xlsx, research
        brief docx, comps xlsx) which proxy to the MCP server's docgen tools.
        The MCP returns a structured response with a 15-min presigned R2 URL
        that the caller can download with any HTTP client.

        Args:
            mcp_url: Full URL of the MCP server endpoint (typically
                ``https://mcp.valuein.biz/mcp``).
            name: MCP tool name (e.g. ``"generate_dcf_xlsx"``).
            arguments: Tool arguments — passed through verbatim as the
                JSON-RPC ``params.arguments`` object.

        Returns:
            The MCP ``result`` envelope, which typically carries a
            ``content`` array and a ``structuredContent`` dict (the latter
            being the easier path for programmatic use).

        Raises:
            ValueinAuthError: 401 (invalid token) or 402 (suspended).
            ValueinPlanError: 403 with a plan-gate error.
            ValueinAPIError: JSON-RPC ``error`` payload or non-2xx response.
        """
        if not self._api_key:
            raise ValueinAuthError(
                "MCP tool calls require an API token. Set VALUEIN_API_KEY "
                "or pass api_key= to ValueinClient(). Sample mode is "
                "data-only — no MCP access."
            )

        self._mcp_id += 1
        payload = {
            "jsonrpc": "2.0",
            "id": self._mcp_id,
            "method": "tools/call",
            "params": {"name": name, "arguments": arguments},
        }
        headers = {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json, text/event-stream",
        }
        # Docgen tools render OOXML in-Worker — the MCP wrangler.toml grants
        # a 5-min CPU window. Use the read timeout from the existing config
        # so users on slow links can extend it via ValueinConfig.
        try:
            response = httpx.post(
                mcp_url,
                json=payload,
                headers=headers,
                timeout=httpx.Timeout(
                    connect=self._connect_timeout,
                    read=max(self._read_timeout, 300.0),
                    write=30.0,
                    pool=30.0,
                ),
            )
        except httpx.TimeoutException as exc:
            raise ValueinTimeoutError(
                f"MCP tool call '{name}' timed out. Increase "
                "ValueinConfig.read_timeout for heavy docgen tools (default 120s)."
            ) from exc
        except httpx.ConnectError as exc:
            raise ConnectionError(f"Could not reach {mcp_url}.") from exc

        _raise_for_status(response)

        body: dict[str, object] = response.json()
        if "error" in body and body["error"]:
            err = body["error"]
            msg = err.get("message", str(err)) if isinstance(err, dict) else str(err)
            raise ValueinAPIError(f"MCP tool '{name}' error: {msg}")
        result = body.get("result")
        if not isinstance(result, dict):
            raise ValueinAPIError(
                f"MCP tool '{name}' returned an unexpected response shape (no result object)."
            )
        return result

    def close(self) -> None:
        """Release connection pool resources."""
        self._client.close()

    def __enter__(self) -> Transport:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()
