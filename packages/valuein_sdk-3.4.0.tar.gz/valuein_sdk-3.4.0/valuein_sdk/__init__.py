from importlib.metadata import PackageNotFoundError, version

from .alpha import AlphaEngine, AlphaFactor, AlphaResult
from .alpha.factors import (
    ASSET_TURNOVER,
    BUILTIN_FACTORS,
    CURRENT_RATIO,
    DEBT_TO_EQUITY,
    FCF_TO_ASSETS,
    GROSS_MARGIN,
    NET_PROFIT_MARGIN,
    OPERATING_MARGIN,
    PIOTROSKI_F_SCORE,
    REVENUE_GROWTH_YOY,
    ROE,
)
from .client import ValueinClient, ValueinConfig
from .exceptions import (
    ValueinAPIError,
    ValueinAuthError,
    ValueinConfigError,
    ValueinConnectionError,
    ValueinDataError,
    ValueinError,
    ValueinNotFoundError,
    ValueinPlanError,
    ValueinRateLimitError,
    ValueinTimeoutError,
    ValueinValidationError,
)
from .models import EQUITY_FALLBACK_ORDER, FactRecord, FilingTextRow, compute_fact_id
from .plans import PLANS_FALLBACK, PlanLimit, format_rate_limit, get_plans

try:
    __version__ = version("valuein-sdk")
except PackageNotFoundError:
    __version__ = "0.0.0-dev"

__all__ = [
    # Client
    "ValueinClient",
    "ValueinConfig",
    "__version__",
    # Alpha framework
    "AlphaEngine",
    "AlphaResult",
    "AlphaFactor",
    "ROE",
    "GROSS_MARGIN",
    "OPERATING_MARGIN",
    "NET_PROFIT_MARGIN",
    "REVENUE_GROWTH_YOY",
    "FCF_TO_ASSETS",
    "DEBT_TO_EQUITY",
    "ASSET_TURNOVER",
    "CURRENT_RATIO",
    "PIOTROSKI_F_SCORE",
    "BUILTIN_FACTORS",
    # Models
    "FactRecord",
    "FilingTextRow",
    "compute_fact_id",
    "EQUITY_FALLBACK_ORDER",
    # Plans (canonical rate-limit configuration)
    "PlanLimit",
    "PLANS_FALLBACK",
    "get_plans",
    "format_rate_limit",
    # Exceptions
    "ValueinError",
    "ValueinAuthError",
    "ValueinPlanError",
    "ValueinNotFoundError",
    "ValueinRateLimitError",
    "ValueinAPIError",
    "ValueinConfigError",
    "ValueinConnectionError",
    "ValueinDataError",
    "ValueinTimeoutError",
    "ValueinValidationError",
]
