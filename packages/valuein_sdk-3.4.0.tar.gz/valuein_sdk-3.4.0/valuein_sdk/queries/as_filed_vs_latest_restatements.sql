-- Bloomberg Option-C: surface filings whose values were later restated.
--
-- Parquet schema 2.3.0+ ships four restatement columns on every fact row:
--
--   numeric_value     — what THIS filing reported
--   value_current     — latest-known value for this (entity, concept, period)
--   value_as_filed    — originally-reported value (first-ever accepted_at)
--   first_filed_at    — timestamp of first disclosure
--   restated          — TRUE if any version differs (warehouse-global flag)
--
-- This template returns rows where `restated = TRUE` and the latest-known
-- value diverges from the as-filed value by more than ``threshold_pct``.
-- Use to spot-check earnings restatements, M&A purchase-accounting revisions,
-- and audit-driven balance sheet repaints.
--
-- Note: the `restated` flag is computed against the GLOBAL warehouse state,
-- not PIT.  A query with ``as_of_date`` in the past may still see TRUE for a
-- fact whose restatement happened AFTER the cutoff.  Treat as informational.

SELECT
    r.symbol,
    r.name,
    f.standard_concept,
    f.period_end,
    f.fiscal_year,
    f.fiscal_period,
    f.value_as_filed                                      AS as_filed,
    f.value_current                                       AS latest_known,
    f.value_current - f.value_as_filed                    AS delta,
    100.0 * (f.value_current - f.value_as_filed)
          / NULLIF(ABS(f.value_as_filed), 0)              AS delta_pct,
    f.first_filed_at,
    f.accepted_at                                         AS restated_at,
    f.unit
FROM fact f
JOIN "references" r ON r.cik = f.entity_id
WHERE r.symbol IN ({{ tickers | sql_list }})
  AND f.restated = TRUE
  AND f.standard_concept IN ({{ metrics | sql_list }})
  AND f.fiscal_year >= {{ min_fiscal_year }}
  AND ABS(100.0 * (f.value_current - f.value_as_filed)
                / NULLIF(ABS(f.value_as_filed), 0)) >= {{ threshold_pct }}
ORDER BY ABS(delta_pct) DESC, f.period_end DESC;
