-- Side-by-side ratio comparison across multiple tickers for a single period.
--
-- Pivots every pre-computed ratio for the given tickers and fiscal period into
-- one row per ticker, one column per ratio category/name. Useful for peer
-- analysis, competitive benchmarking, and investment memo generation.
--
-- Parameters:
--   tickers      : list[str] — ticker symbols, e.g. ['AAPL', 'MSFT', 'GOOGL']
--   fiscal_period: str       — 'FY' | 'TTM'
--   fiscal_year  : int       — e.g. 2024
--
-- Example:
--   client.run_template(
--       "financial_ratios_comparison",
--       tickers=["AAPL", "MSFT", "GOOGL"],
--       fiscal_period="FY",
--       fiscal_year=2024,
--   )

WITH latest_per_ticker AS (
    SELECT
        ra.entity_id,
        ra.ratio_name,
        ra.value,
        ra.category,
        ra.fiscal_year,
        ra.fiscal_period,
        ra.period_end,
        ROW_NUMBER() OVER (
            PARTITION BY ra.entity_id, ra.ratio_name
            ORDER BY ra.period_end DESC
        ) AS rn
    FROM ratio ra
    WHERE ra.fiscal_period = {{ fiscal_period | sql_quote }}
      AND ra.fiscal_year   = {{ fiscal_year }}
      AND ra.value        IS NOT NULL
)
SELECT
    r.symbol,
    r.name,
    r.sector,
    lp.ratio_name,
    lp.value,
    lp.category,
    lp.fiscal_year,
    lp.fiscal_period,
    lp.period_end
FROM latest_per_ticker lp
JOIN "references" r ON r.cik = lp.entity_id
WHERE lp.rn       = 1
  AND r.symbol   IN ({{ tickers | sql_list }})
  AND r.is_active = TRUE
ORDER BY r.symbol, lp.category, lp.ratio_name
