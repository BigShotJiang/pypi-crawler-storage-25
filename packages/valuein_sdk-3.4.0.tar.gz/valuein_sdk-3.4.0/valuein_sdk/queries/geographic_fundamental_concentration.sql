-- Aggregates total capex or revenue by entity.state_of_incorporation to map out
-- regional economic hotspots or tax-haven dependencies.

SELECT
    e.state_of_incorporation,
    COUNT(DISTINCT e.cik) AS entity_count,
    SUM(f.numeric_value) AS total_regional_metric
FROM entity e
JOIN fact f ON e.cik = f.entity_id
WHERE f.standard_concept = {{ metric | sql_quote }}
  AND f.frame = {{ frame | sql_quote }}
GROUP BY e.state_of_incorporation
ORDER BY total_regional_metric DESC;
