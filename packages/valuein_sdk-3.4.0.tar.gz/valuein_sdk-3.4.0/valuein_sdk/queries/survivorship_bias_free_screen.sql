-- Pulls historical fundamentals exclusively for companies that are now bankrupt,
-- delisted, or acquired (Status != ACTIVE) to train unbiased ML models.

SELECT
    e.cik,
    e.name,
    e.status,
    e.last_seen_at,
    f.standard_concept,
    f.numeric_value
FROM entity e
JOIN fact f ON e.cik = f.entity_id
WHERE e.status != 'ACTIVE'
  AND f.period_end BETWEEN {{ start_date | sql_quote }} AND {{ end_date | sql_quote }}
  AND f.standard_concept IN ({{ metrics | sql_list }})
ORDER BY e.last_seen_at DESC;
