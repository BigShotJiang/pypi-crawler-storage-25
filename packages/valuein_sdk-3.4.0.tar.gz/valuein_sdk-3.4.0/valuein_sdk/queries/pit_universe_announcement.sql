-- Survivorship-free index universe at a historical date, with optional
-- announcement-vs-effective basis switch (parquet schema 2.4.0).
--
-- For inclusion-arbitrage backtests, what matters is the day S&P Dow Jones
-- *publicly announced* the change — usually 5–10 trading days before the
-- effective rebalance.  Schema 2.3.0 added `announcement_date` and
-- `removal_announcement_date` to `index_membership` so the same query can
-- pivot on either basis without re-fetching data.
--
-- Schema note: since pipeline migration 0015, ``index_membership`` keys on
-- ``cik`` (not ``entity_id`` / ``security_id``) — same column name as
-- ``references.cik`` and ``entity.cik``, so joins read straight across.
--
-- Parameters
--   index            : index short code (SP500 | NASDAQ100 | RUSSELL3000)
--   as_of_date       : YYYY-MM-DD historical date
--   as_of_basis      : 'effective' (default — first trading day as a member)
--                      | 'announcement' (S&P public announcement date)
--
-- Returns one row per (cik, security at-the-date), with NULL ticker
-- when the company is delisted at the as_of_date.

SELECT
    m.cik,
    e.name                    AS company_name,
    s.symbol                  AS ticker_at_date,
    e.sector,
    e.industry,
    m.effective_date,
    m.announcement_date,
    m.removal_date,
    m.removal_announcement_date,
    m.removal_reason,
    m.confidence,
    m.source
FROM index_membership m
JOIN entity e ON e.cik = m.cik
LEFT JOIN security s ON s.entity_id = m.cik
    AND s.is_primary_ticker = TRUE
    AND {{ as_of_date | sql_quote }}::DATE >= s.valid_from
    AND {{ as_of_date | sql_quote }}::DATE <  COALESCE(s.valid_to, '9999-12-31'::DATE)
WHERE m.index_name = {{ index | sql_quote }}
{% if as_of_basis == "announcement" %}
  AND m.announcement_date IS NOT NULL
  AND {{ as_of_date | sql_quote }}::DATE >= m.announcement_date
  AND {{ as_of_date | sql_quote }}::DATE <  COALESCE(m.removal_announcement_date, '9999-12-31'::DATE)
{% else %}
  AND {{ as_of_date | sql_quote }}::DATE >= m.effective_date
  AND {{ as_of_date | sql_quote }}::DATE <  COALESCE(m.removal_date, '9999-12-31'::DATE)
{% endif %}
ORDER BY e.name;
