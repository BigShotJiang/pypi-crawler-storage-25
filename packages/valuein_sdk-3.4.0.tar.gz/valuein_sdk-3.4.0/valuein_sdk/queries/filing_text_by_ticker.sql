-- filing_text_by_ticker.sql
--
-- Return the narrative sections (Risk Factors, MD&A, Business, Legal
-- Proceedings, Controls & Procedures) from a company's 10-K / 10-Q / 20-F
-- filings, ordered newest → oldest and reassembled in chunk order.
--
-- Use cases:
--   • Read the latest Risk Factors section end-to-end for a company
--   • Diff two years of MD&A to find materially new language
--   • Feed chunks into a custom embedding pipeline (the data-pipeline already
--     publishes Vectorize embeddings for you — use search_filing_text via
--     the MCP server for semantic search; this template is for SDK users
--     who want full control over tokenization / retrieval)
--
-- Inputs (Jinja):
--   ticker           REQUIRED — e.g. "AAPL"
--   section          optional — one of risk_factors | mdna | business |
--                    legal_proceedings | controls_procedures | footnotes |
--                    other. Omit for all sections.
--   start_date       optional — ISO YYYY-MM-DD lower bound on report_date.
--                    Default: ~5 years ago.
--   end_date         optional — ISO YYYY-MM-DD upper bound. Default: today.
--   limit_chunks     optional int — cap total rows returned. Default: 5000.

SELECT
    ft.entity_id,
    ft.accession_id,
    ft.section,
    ft.chunk_no,
    ft.total_chunks,
    ft.text,
    ft.char_count,
    ft.token_estimate,
    ft.report_date,
    ft.form_type,
    ft.accepted_at
FROM filing_text ft
JOIN "references" r ON r.cik = ft.entity_id
WHERE r.symbol = {{ ticker | sql_quote }}
  AND r.is_active = TRUE
  {% if section is defined and section %}
  AND ft.section = {{ section | sql_quote }}
  {% endif %}
  AND ft.report_date BETWEEN {{ start_date | sql_quote }} AND {{ end_date | sql_quote }}
ORDER BY ft.report_date DESC, ft.section, ft.chunk_no ASC
LIMIT {{ limit_chunks | default(5000) }};
