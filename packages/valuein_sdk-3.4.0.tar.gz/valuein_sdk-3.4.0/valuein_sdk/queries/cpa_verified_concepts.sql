-- CPA-verified concept catalog — the standardized concepts an accountant has
-- signed off on.  ``review_confidence`` is the catalog analogue of
-- ``fact.confidence_score``: 1.0 = CPA-reviewed (locked — the pipeline only ever
-- creates new concepts, never mutates a reviewed one); 0.7 = provisional
-- (auto-mapped, pending review).  Filter to the verified set for the
-- Bloomberg-grade concept labels you can trust for training and inference.
--
-- Params:
--   min_confidence — minimum review_confidence to include (default 1.0 = CPA-verified only).

SELECT
    standard_concept,
    level,
    statement_type,
    category,
    definition,
    unit_default,
    reviewed,
    reviewed_by,
    reviewed_at,
    review_confidence
FROM standard_concept
WHERE standard_concept <> 'Other'
  AND review_confidence >= {{ (min_confidence | default(1.0)) | float }}
ORDER BY review_confidence DESC, standard_concept;
