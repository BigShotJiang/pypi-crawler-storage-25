-- Full dividend history for a single company. Returns per-period cash dividends
-- and per-share dividend amounts with Bloomberg "Option-C" restatement columns
-- so you can see BOTH the latest restated figure and the original-as-filed value.
--
-- Inputs (Jinja):
--   ticker                REQUIRED — symbol, e.g. "AAPL"
--   start_date            optional — ISO date, defaults to ~10 years ago
--   end_date              optional — ISO date, defaults to today
--   fiscal_period_filter  optional — list; defaults to all: FY, Q1, Q2, Q3, Q4
--
-- Output columns:
--   period_end, fiscal_year, fiscal_period, accession_id, filing_date, form_type
--   dividends_paid_current          — total cash dividends this period (latest known)
--   dividends_paid_as_filed         — same, but originally reported in the first filing
--   dividend_per_share_current      — DPS declared (latest known)
--   dividend_per_share_as_filed     — DPS declared (originally reported)
--   any_restated                    — TRUE if EITHER value differs across filings
--   first_filed_at, last_known_at   — accepted_at window for this period
--
-- Example consumers:
--   dividend yield history (join with price data), payout-ratio drift, DDM inputs,
--   detect silent dividend restatements (any_restated = TRUE).
--
-- Data source: fact.parquet with the Bloomberg Option-C columns populated by
-- run_exports.py. The DISTINCT ON picks the latest filing per
-- (entity_id, standard_concept, period_end, fiscal_period, unit) so each
-- period contributes exactly one row to the pivot.

WITH target_entity AS (
    SELECT cik
    FROM "references"
    WHERE symbol = {{ ticker | sql_quote }}
      AND is_active = TRUE
    LIMIT 1
),
latest_per_period AS (
    SELECT DISTINCT ON (fa.entity_id, fa.standard_concept, fa.period_end, fa.fiscal_period, fa.unit)
        fa.entity_id,
        fa.period_end,
        fa.fiscal_year,
        fa.fiscal_period,
        fa.accession_id,
        fa.standard_concept,
        fa.value_current,
        fa.value_as_filed,
        fa.first_filed_at,
        fa.accepted_at,
        fa.restated,
        fa.unit
    FROM fact fa
    JOIN target_entity te ON fa.entity_id = te.cik
    WHERE fa.standard_concept IN ('Dividends', 'DividendPerShare')
      AND fa.period_end BETWEEN {{ start_date | sql_quote }} AND {{ end_date | sql_quote }}
      {% if fiscal_period_filter is defined and fiscal_period_filter %}
      AND fa.fiscal_period IN ({{ fiscal_period_filter | sql_list }})
      {% endif %}
    ORDER BY
        fa.entity_id,
        fa.standard_concept,
        fa.period_end,
        fa.fiscal_period,
        fa.unit,
        fa.accepted_at DESC
)
SELECT
    l.period_end,
    l.fiscal_year,
    l.fiscal_period,
    l.accession_id,
    f.filing_date,
    f.form_type,
    MAX(CASE WHEN l.standard_concept = 'Dividends'        THEN l.value_current  END) AS dividends_paid_current,
    MAX(CASE WHEN l.standard_concept = 'Dividends'        THEN l.value_as_filed END) AS dividends_paid_as_filed,
    MAX(CASE WHEN l.standard_concept = 'DividendPerShare' THEN l.value_current  END) AS dividend_per_share_current,
    MAX(CASE WHEN l.standard_concept = 'DividendPerShare' THEN l.value_as_filed END) AS dividend_per_share_as_filed,
    BOOL_OR(l.restated)                                                               AS any_restated,
    MIN(l.first_filed_at)                                                             AS first_filed_at,
    MAX(l.accepted_at)                                                               AS last_known_at
FROM latest_per_period l
JOIN filing f ON l.accession_id = f.accession_id
GROUP BY l.period_end, l.fiscal_year, l.fiscal_period, l.accession_id, f.filing_date, f.form_type
ORDER BY l.period_end DESC, l.fiscal_period;
