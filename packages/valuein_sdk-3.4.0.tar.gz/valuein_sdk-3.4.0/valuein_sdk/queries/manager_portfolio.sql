-- Full 13F portfolio of a single fund manager at a period_end, with QoQ
-- deltas vs the prior reporting quarter.
--
-- Inputs (Jinja):
--   filer_cik   REQUIRED — 10-digit CIK of the 13F filer (e.g. "0001067983" = BRK).
--   period_end  optional — YYYY-MM-DD; defaults to LATEST.
--   top_n       optional — default 25.
--
-- Output columns:
--   period_end, subject_entity_id, ticker, name_of_issuer, cusip,
--   title_of_class, shares, market_value_usd, put_call,
--   shares_change_qoq, market_value_change_qoq_usd,
--   position_type_qoq ∈ {'new','increased','decreased','unchanged'},
--   accepted_at, accession_id
--
-- Notes:
--   * "exited" classification (held t-1, absent t) is omitted from this
--     SQL template — DuckDB-side it requires a FULL OUTER JOIN that
--     materialises rows with shares=0.  The MCP equivalent
--     `get_manager_portfolio` produces those rows in TypeScript.  Use
--     `client.get_manager_portfolio()` if you need exits surfaced.
--   * subject_entity_id may be NULL for unresolved CUSIPs.
--
-- Tier: enterprise (full plan).

WITH target_period AS (
    SELECT
        {%- if period_end %}
        {{ period_end | sql_quote }}::DATE                              AS period_end
        {%- else %}
        MAX(period_end)                                                 AS period_end
        FROM institutional_holding WHERE filer_cik = {{ filer_cik | sql_quote }}
        {%- endif %}
),
prior_period AS (
    SELECT MAX(period_end)                                              AS period_end
    FROM institutional_holding
    WHERE filer_cik = {{ filer_cik | sql_quote }}
      AND period_end < (SELECT period_end FROM target_period)
),
current_q AS (
    SELECT
        period_end,
        subject_entity_id,
        cusip,
        name_of_issuer,
        title_of_class,
        put_call,
        accepted_at,
        accession_id,
        SUM(shares)             AS shares,
        SUM(market_value_usd)   AS market_value_usd
    FROM institutional_holding
    WHERE filer_cik = {{ filer_cik | sql_quote }}
      AND period_end = (SELECT period_end FROM target_period)
    GROUP BY 1, 2, 3, 4, 5, 6, 7, 8
),
prior_q AS (
    SELECT
        COALESCE(subject_entity_id, '__cusip__:' || cusip) AS join_key,
        SUM(shares)             AS prior_shares,
        SUM(market_value_usd)   AS prior_market_value_usd
    FROM institutional_holding
    WHERE filer_cik = {{ filer_cik | sql_quote }}
      AND period_end = (SELECT period_end FROM prior_period)
    GROUP BY 1
),
ticker_map AS (
    SELECT cik, MAX(symbol) AS symbol
    FROM "references"
    WHERE symbol IS NOT NULL AND is_active = TRUE
    GROUP BY cik
)
SELECT
    c.period_end,
    c.subject_entity_id,
    tm.symbol AS ticker,
    c.name_of_issuer,
    c.cusip,
    c.title_of_class,
    c.shares,
    c.market_value_usd,
    c.put_call,
    c.shares - COALESCE(p.prior_shares, 0)                         AS shares_change_qoq,
    c.market_value_usd - COALESCE(p.prior_market_value_usd, 0)     AS market_value_change_qoq_usd,
    CASE
        WHEN p.join_key IS NULL                                     THEN 'new'
        WHEN c.shares = COALESCE(p.prior_shares, 0)                 THEN 'unchanged'
        WHEN c.shares > COALESCE(p.prior_shares, 0)                 THEN 'increased'
        WHEN c.shares < COALESCE(p.prior_shares, 0)                 THEN 'decreased'
    END                                                             AS position_type_qoq,
    c.accepted_at,
    c.accession_id
FROM current_q c
LEFT JOIN prior_q p
  ON COALESCE(c.subject_entity_id, '__cusip__:' || c.cusip) = p.join_key
LEFT JOIN ticker_map tm
  ON c.subject_entity_id = tm.cik
ORDER BY market_value_usd DESC NULLS LAST
LIMIT {{ top_n | default(25) }}
;
