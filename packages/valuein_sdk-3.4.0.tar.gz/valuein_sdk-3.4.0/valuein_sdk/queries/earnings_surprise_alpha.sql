-- Earnings-surprise alpha screen using pre-computed earnings_signals.
--
-- Parquet schema 2.3.0+ ships an `earnings_signals` table that pre-computes:
--
--   eps_trend_est    — proprietary trailing EPS trend estimate
--   eps_actual       — most recent reported EPSDiluted
--   eps_surprise_pct — actual EPS vs. the trend estimate
--   revenue_yoy_pct  — quarterly revenue YoY change
--
-- Use to surface companies where the most recent quarter materially beat or
-- missed the trailing 4Q trend.  Pair with momentum / quality factors from
-- `factor_scores` for a multi-factor signal.

SELECT
    r.symbol,
    r.name,
    r.sector,
    es.fiscal_year,
    es.fiscal_period,
    es.period_end,
    es.eps_actual,
    es.eps_trend_est,
    es.eps_surprise_pct,
    es.revenue_actual,
    es.revenue_yoy_pct
FROM earnings_signals es
JOIN "references" r ON r.cik = es.entity_id
WHERE r.is_active = TRUE
  AND es.eps_surprise_pct IS NOT NULL
  AND ABS(es.eps_surprise_pct) >= {{ min_surprise_pct }}
  {% if direction == "positive" %}AND es.eps_surprise_pct > 0{% endif %}
  {% if direction == "negative" %}AND es.eps_surprise_pct < 0{% endif %}
  {% if sector %}AND r.sector = {{ sector | sql_quote }}{% endif %}
ORDER BY ABS(es.eps_surprise_pct) DESC
LIMIT {{ limit }};
