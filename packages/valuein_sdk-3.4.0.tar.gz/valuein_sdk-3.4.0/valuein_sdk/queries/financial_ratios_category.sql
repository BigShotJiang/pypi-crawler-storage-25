-- All pre-computed ratios of a given category for the latest period, across the S&P 500.
--
-- Use this to get a comprehensive view of a ratio category (e.g. all profitability
-- metrics) across the index in a single query. Returns one row per company per
-- ratio name, ordered by ratio value descending (highest performers first).
--
-- Valid categories: 'profitability' | 'liquidity' | 'leverage' |
--                   'efficiency' | 'per_share' | 'owner_earnings' | 'valuation'
--
-- Parameters:
--   category     : str  — ratio category filter, e.g. 'profitability'
--   fiscal_period: str  — 'FY' | 'TTM' | 'Q1' | 'Q2' | 'Q3' | 'Q4'
--   as_of_date   : str  — ISO date — only periods ending on or before this date
--
-- Example:
--   client.run_template(
--       "financial_ratios_category",
--       category="profitability",
--       fiscal_period="TTM",
--       as_of_date="2024-12-31",
--   )

WITH latest_per_company AS (
    SELECT
        ra.entity_id,
        ra.ratio_name,
        ra.value,
        ra.unit,
        ra.category,
        ra.fiscal_year,
        ra.fiscal_period,
        ra.period_end,
        ROW_NUMBER() OVER (
            PARTITION BY ra.entity_id, ra.ratio_name
            ORDER BY ra.period_end DESC
        ) AS rn
    FROM ratio ra
    WHERE ra.category      = {{ category | sql_quote }}
      AND ra.fiscal_period = {{ fiscal_period | sql_quote }}
      AND ra.period_end   <= {{ as_of_date | sql_quote }}
      AND ra.value        IS NOT NULL
)
SELECT
    r.symbol,
    r.name,
    r.sector,
    r.industry,
    lp.ratio_name,
    lp.value,
    lp.unit,
    lp.category,
    lp.fiscal_year,
    lp.fiscal_period,
    lp.period_end
FROM latest_per_company lp
JOIN "references"     r  ON r.cik  = lp.entity_id
JOIN index_membership im ON im.cik = r.cik
WHERE lp.rn         = 1
  AND im.index_name = 'SP500'
  AND im.removal_date IS NULL          -- current S&P 500 member
  AND r.is_active   = TRUE
ORDER BY lp.ratio_name, lp.value DESC NULLS LAST
