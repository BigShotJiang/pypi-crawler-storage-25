-- Rolls up 10-Q quarterly flow metrics into a continuous TTM view.
-- Uses COALESCE(derived_quarterly_value, numeric_value) so Q2/Q3 10-Qs (which
-- report YTD) are correctly de-cumulated before summing.
-- QUALIFY quarters_available = 4 ensures only complete 4-quarter windows are returned.

WITH target_filings AS (
    SELECT
        f.accession_id,
        f.report_date
    FROM filing f
    JOIN "references" r ON f.entity_id = r.cik
    WHERE r.symbol = {{ ticker | sql_quote }}
      AND r.is_active = TRUE
      AND f.form_type = '10-Q'
      AND f.filing_date BETWEEN {{ start_date | sql_quote }} AND {{ end_date | sql_quote }}
),
quarterly_facts AS (
    SELECT
        tf.report_date,
        fa.standard_concept,
        COALESCE(fa.derived_quarterly_value, fa.numeric_value) AS quarterly_value
    FROM target_filings tf
    JOIN fact fa ON tf.accession_id = fa.accession_id
    WHERE fa.standard_concept IN ({{ metrics | sql_list }})
)
SELECT
    report_date,
    standard_concept,
    quarterly_value,
    SUM(quarterly_value) OVER (
        PARTITION BY standard_concept
        ORDER BY report_date
        ROWS BETWEEN 3 PRECEDING AND CURRENT ROW
    ) AS ttm_value,
    COUNT(*) OVER (
        PARTITION BY standard_concept
        ORDER BY report_date
        ROWS BETWEEN 3 PRECEDING AND CURRENT ROW
    ) AS quarters_available
FROM quarterly_facts
QUALIFY quarters_available = 4
ORDER BY standard_concept, report_date DESC;
