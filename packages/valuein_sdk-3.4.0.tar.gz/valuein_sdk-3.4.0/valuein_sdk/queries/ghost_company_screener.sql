-- Identifies companies whose last_seen_at date is unusually old, indicating a halt in SEC
-- reporting or a potential de-listing event.
-- stale_days: number of days without a filing before a company is considered "ghost" (default 180).

SELECT
    cik,
    name,
    industry,
    last_seen_at,
    DATEDIFF('day', last_seen_at, CURRENT_DATE) AS days_since_last_filing
FROM entity
WHERE status = 'ACTIVE'
  AND DATEDIFF('day', last_seen_at, CURRENT_DATE) > {{ stale_days }}
ORDER BY days_since_last_filing DESC;
