-- SC 13D / 13G blockholder filings for a single issuer, with the
-- ``going_active`` flag derived in-query (filer flipped 13G → 13D within
-- the lookback window — control-change signal).  Returns the latest
-- filing per (filer, schedule prefix) by default.
--
-- Inputs (Jinja):
--   ticker             REQUIRED — symbol of the issuer
--   schedule_filter    optional — '13D' | '13G' | 'both' (default 'both')
--   lookback_days      optional — going_active detection window; default 365
--
-- Output columns:
--   filing_date, accepted_at, as_of_date, filer_cik, filer_name,
--   filer_type, schedule_type, is_activist (boolean), going_active (boolean),
--   percent_owned, shares_owned, sole_voting_power, shared_voting_power,
--   sole_dispositive_power, shared_dispositive_power, accession_id
--
-- Notes:
--   * is_activist = schedule_type LIKE 'SC 13D%'.  /A suffixes (amendments)
--     count as activist if they amend a 13D, passive if they amend a 13G.
--   * going_active = TRUE when the same filer has BOTH a 13G earlier in
--     the partition AND a 13D within ``lookback_days``.  This is the most
--     actionable signal in the dataset.
--   * latest-only: QUALIFY ROW_NUMBER picks the most recent filing per
--     (filer_key, schedule_prefix).
--
-- Tier: enterprise (full plan).

WITH target_entity AS (
    SELECT cik
    FROM "references"
    WHERE UPPER(symbol) = UPPER({{ ticker | sql_quote }}) AND is_active = TRUE
    LIMIT 1
),
all_filings AS (
    SELECT
        b.*,
        CASE
            WHEN UPPER(b.schedule_type) LIKE 'SC 13D%' THEN '13D'
            WHEN UPPER(b.schedule_type) LIKE 'SC 13G%' THEN '13G'
            ELSE 'OTHER'
        END                                              AS schedule_prefix,
        COALESCE(b.filer_cik, b.filer_name)              AS filer_key
    FROM insider_ownership b
    WHERE b.subject_entity_id = (SELECT cik FROM target_entity)
),
going_active_filers AS (
    SELECT DISTINCT filer_key
    FROM all_filings
    WHERE schedule_prefix = '13D'
      AND accepted_at >= (CURRENT_DATE - INTERVAL '{{ lookback_days | default(365) }}' DAY)
      AND filer_key IN (
          SELECT filer_key FROM all_filings WHERE schedule_prefix = '13G'
      )
),
filtered AS (
    SELECT
        f.*,
        f.filer_key IN (SELECT filer_key FROM going_active_filers) AS going_active,
        f.schedule_prefix = '13D'                                  AS is_activist
    FROM all_filings f
    WHERE 1=1
        {%- if schedule_filter == '13D' %}
        AND f.schedule_prefix = '13D'
        {%- elif schedule_filter == '13G' %}
        AND f.schedule_prefix = '13G'
        {%- endif %}
)
SELECT
    CAST(accepted_at AS DATE)         AS filing_date,
    accepted_at,
    as_of_date,
    filer_cik,
    filer_name,
    filer_type,
    schedule_type,
    is_activist,
    going_active,
    percent_owned,
    shares_owned,
    sole_voting_power,
    shared_voting_power,
    sole_dispositive_power,
    shared_dispositive_power,
    accession_id
FROM filtered
QUALIFY ROW_NUMBER() OVER (
    PARTITION BY filer_key, schedule_prefix
    ORDER BY accepted_at DESC
) = 1
ORDER BY percent_owned DESC NULLS LAST
;
