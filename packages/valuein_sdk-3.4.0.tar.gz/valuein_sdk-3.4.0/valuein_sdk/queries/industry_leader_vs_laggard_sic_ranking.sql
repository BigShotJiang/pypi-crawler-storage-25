-- Uses Window functions to rank competitors strictly within their 4-digit SIC code classification.

SELECT
    e.sic_code,
    e.name,
    f.numeric_value,
    RANK() OVER (PARTITION BY e.sic_code ORDER BY f.numeric_value DESC) AS industry_rank
FROM entity e
JOIN fact f ON e.cik = f.entity_id
WHERE f.standard_concept = {{ metric | sql_quote }}
  AND f.frame = {{ frame | sql_quote }}
ORDER BY e.sic_code, industry_rank;
