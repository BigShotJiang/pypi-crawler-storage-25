-- Ranks companies against their specific entity.sector average to find undervalued peers.
-- Uses canonical standard_concept name: TotalRevenue.

WITH sector_averages AS (
    SELECT
        e.sector,
        AVG(f.numeric_value) AS avg_sector_revenue
    FROM entity e
    JOIN fact f ON e.cik = f.entity_id
    WHERE f.standard_concept = 'TotalRevenue' AND f.frame = {{ frame | sql_quote }}
    GROUP BY e.sector
)
SELECT
    e.name,
    e.sector,
    f.numeric_value AS company_revenue,
    sa.avg_sector_revenue,
    (f.numeric_value / NULLIF(sa.avg_sector_revenue, 0)) AS sector_relative_multiple
FROM entity e
JOIN fact f ON e.cik = f.entity_id
JOIN sector_averages sa ON e.sector = sa.sector
WHERE f.standard_concept = 'TotalRevenue' AND f.frame = {{ frame | sql_quote }}
ORDER BY sector_relative_multiple DESC;
