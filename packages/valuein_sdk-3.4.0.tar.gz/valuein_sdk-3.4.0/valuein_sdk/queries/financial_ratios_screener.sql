-- Screen companies by a specific pre-computed financial ratio.
--
-- Returns the top N companies ranked by a single ratio name for the most
-- recent available period, optionally filtered by sector or S&P 500 membership.
-- All values come from the pipeline-computed ratio table (not raw facts).
--
-- Parameters:
--   ratio_name   : str   — exact ratio name, e.g. 'gross_margin', 'roe', 'current_ratio'
--   fiscal_period: str   — 'FY' | 'TTM' | 'Q1' | 'Q2' | 'Q3' | 'Q4'
--   as_of_date   : str   — ISO date — only periods ending on or before this date
--   limit        : int   — max rows to return (e.g. 25)
--
-- Example:
--   client.run_template(
--       "financial_ratios_screener",
--       ratio_name="gross_margin",
--       fiscal_period="TTM",
--       as_of_date="2024-12-31",
--       limit=25,
--   )

WITH latest_ratio AS (
    SELECT
        ra.entity_id,
        ra.ratio_name,
        ra.value,
        ra.unit,
        ra.category,
        ra.fiscal_year,
        ra.fiscal_period,
        ra.period_end,
        ROW_NUMBER() OVER (
            PARTITION BY ra.entity_id
            ORDER BY ra.period_end DESC
        ) AS rn
    FROM ratio ra
    WHERE ra.ratio_name    = {{ ratio_name | sql_quote }}
      AND ra.fiscal_period = {{ fiscal_period | sql_quote }}
      AND ra.period_end   <= {{ as_of_date | sql_quote }}
      AND ra.value        IS NOT NULL
)
SELECT
    r.symbol,
    r.name,
    r.sector,
    r.industry,
    lr.ratio_name,
    lr.value,
    lr.unit,
    lr.category,
    lr.fiscal_year,
    lr.fiscal_period,
    lr.period_end
FROM latest_ratio lr
JOIN "references" r ON r.cik = lr.entity_id
WHERE lr.rn       = 1
  AND r.is_active = TRUE
ORDER BY lr.value DESC NULLS LAST
LIMIT {{ limit }}
