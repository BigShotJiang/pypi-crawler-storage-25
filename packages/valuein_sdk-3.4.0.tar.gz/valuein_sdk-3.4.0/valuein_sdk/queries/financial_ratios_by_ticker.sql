-- Pre-computed financial ratios for a single company, ordered by period.
--
-- Returns pipeline-computed ratios from the ratio table — faster and broader
-- than computing from raw facts, but without PIT guarantees (use the fact table
-- with accepted_at for strict point-in-time backtesting).
--
-- Parameters:
--   ticker       : str  — ticker symbol, e.g. 'AAPL'
--   fiscal_period: str  — 'FY' | 'TTM' | 'Q1' | 'Q2' | 'Q3' | 'Q4' (default 'FY')
--   start_date   : str  — ISO date lower bound on period_end, e.g. '2015-01-01'
--   end_date     : str  — ISO date upper bound on period_end, e.g. '2024-12-31'
--
-- Example:
--   client.run_template(
--       "financial_ratios_by_ticker",
--       ticker="AAPL",
--       fiscal_period="FY",
--       start_date="2019-01-01",
--       end_date="2024-12-31",
--   )

SELECT
    r.symbol,
    r.name,
    ra.category,
    ra.ratio_name,
    ra.value,
    ra.unit,
    ra.fiscal_year,
    ra.fiscal_period,
    ra.is_ttm,
    ra.period_end,
    ra.computed_at
FROM ratio ra
JOIN "references" r ON r.cik = ra.entity_id
WHERE r.symbol          = {{ ticker | sql_quote }}
  AND r.is_active       = TRUE
  AND ra.fiscal_period  = {{ fiscal_period | sql_quote }}
  AND ra.period_end     BETWEEN {{ start_date | sql_quote }} AND {{ end_date | sql_quote }}
ORDER BY ra.category, ra.ratio_name, ra.period_end DESC
