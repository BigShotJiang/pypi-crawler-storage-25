-- Top-quintile cross-sectional factor screen using pre-computed factor_scores.
--
-- Parquet schema 2.3.0+ ships a `factor_scores` table with raw factor
-- values plus a percentile-rank column for each (`*_rank`, range 0.0–1.0
-- where 1.0 is best) and a proprietary `composite_rank`.  The ranks are
-- stable cross-sectional within the latest pipeline run — so this query is
-- a single scan, no join-and-rank gymnastics.
--
-- This template returns the top quintile (rank ≥ 0.8) on a chosen factor,
-- joined to references for ticker / sector context.

SELECT
    r.symbol,
    r.name,
    r.sector,
    fs.{{ factor }}            AS factor_value,
    fs.{{ factor }}_rank       AS factor_rank,
    fs.composite_rank,
    fs.period_end,
    fs.fiscal_year
FROM factor_scores fs
JOIN "references" r ON r.cik = fs.entity_id
WHERE fs.{{ factor }}_rank >= {{ min_rank }}
  AND r.is_active = TRUE
  {% if sector %}AND r.sector = {{ sector | sql_quote }}{% endif %}
ORDER BY fs.{{ factor }}_rank DESC, fs.composite_rank DESC
LIMIT {{ limit }};
