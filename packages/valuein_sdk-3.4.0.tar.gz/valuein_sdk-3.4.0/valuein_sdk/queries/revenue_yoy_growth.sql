-- Utilizes Window functions to calculate exact Year-Over-Year growth entirely in SQL.
-- Uses TotalRevenue (canonical standard_concept).

WITH target_filings AS (
    SELECT
        f.accession_id,
        f.report_date
    FROM filing f
    JOIN "references" r ON f.entity_id = r.cik
    WHERE r.symbol = {{ ticker | sql_quote }}
      AND r.is_active = TRUE
      AND f.form_type = '10-K'
      AND f.filing_date BETWEEN {{ start_date | sql_quote }} AND {{ end_date | sql_quote }}
),
raw_facts AS (
    SELECT
        tf.report_date,
        fa.numeric_value AS revenue
    FROM target_filings tf
    JOIN fact fa ON tf.accession_id = fa.accession_id
    WHERE fa.standard_concept = 'TotalRevenue'
)
SELECT
    report_date,
    revenue,
    LAG(revenue) OVER (ORDER BY report_date) AS prev_year_revenue,
    (revenue - LAG(revenue) OVER (ORDER BY report_date))
        / NULLIF(LAG(revenue) OVER (ORDER BY report_date), 0) AS yoy_growth
FROM raw_facts
ORDER BY report_date DESC;
