-- Top-N institutional holders of a single issuer at a specific period_end.
-- Returns each 13F-HR position with the filer's CIK, share count, market
-- value, and voting splits, ranked by market value descending.
--
-- Inputs (Jinja):
--   ticker        REQUIRED — symbol of the issuer
--   period_end    optional — YYYY-MM-DD; defaults to LATEST
--   top_n         optional — default 25
--
-- Output columns:
--   period_end, filer_cik, filer_name, shares, market_value_usd,
--   put_call, investment_discretion, sole_voting, shared_voting,
--   no_voting, accepted_at, accession_id
--
-- Notes:
--   * Reads the monolithic institutional_holding view; DuckDB pushes
--     the entity_id predicate through the parquet reader.
--   * subject_entity_id may be NULL on rows where CUSIP→CIK resolution
--     hasn't completed; those rows are filtered out by the WHERE.
--   * 13F filings carry a ~45-day reporting lag; latest period_end is
--     typically 60–90 days behind real time.
--
-- Tier: enterprise (full plan).

WITH target_entity AS (
    SELECT cik
    FROM "references"
    WHERE UPPER(symbol) = UPPER({{ ticker | sql_quote }}) AND is_active = TRUE
    LIMIT 1
),
target_period AS (
    SELECT
        {%- if period_end %}
        {{ period_end | sql_quote }}::DATE                           AS period_end
        {%- else %}
        MAX(period_end)                                              AS period_end
        FROM institutional_holding
        WHERE subject_entity_id = (SELECT cik FROM target_entity)
        {%- endif %}
),
filer_names AS (
    SELECT cik, name FROM "references"
)
SELECT
    h.period_end,
    h.filer_cik,
    COALESCE(f.name, h.filer_cik)            AS filer_name,
    h.shares,
    h.market_value_usd,
    h.put_call,
    h.investment_discretion,
    h.sole_voting,
    h.shared_voting,
    h.no_voting,
    h.accepted_at,
    h.accession_id
FROM institutional_holding h
LEFT JOIN filer_names f ON h.filer_cik = f.cik
WHERE h.subject_entity_id = (SELECT cik FROM target_entity)
  AND h.period_end = (SELECT period_end FROM target_period)
ORDER BY h.market_value_usd DESC NULLS LAST
LIMIT {{ top_n | default(25) }}
;
