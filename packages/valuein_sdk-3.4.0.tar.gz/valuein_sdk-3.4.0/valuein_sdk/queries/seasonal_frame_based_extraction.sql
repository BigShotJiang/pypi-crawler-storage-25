-- Aligns quarterly data across companies regardless of fiscal year end calendars,
-- by relying on standardized frame logic.
-- fiscal_period: Q1, Q2, Q3, Q4, or FY (default Q1).
-- min_fiscal_year: earliest fiscal year to include (default 2020).

SELECT
    r.name,
    f.fiscal_year,
    f.fiscal_period,
    f.numeric_value
FROM fact f
JOIN "references" r ON f.entity_id = r.cik
WHERE f.standard_concept = 'TotalRevenue'
  AND f.fiscal_period = {{ fiscal_period | sql_quote }}
  AND f.fiscal_year >= {{ min_fiscal_year }}
  AND r.is_active = TRUE
ORDER BY r.name, f.fiscal_year;
