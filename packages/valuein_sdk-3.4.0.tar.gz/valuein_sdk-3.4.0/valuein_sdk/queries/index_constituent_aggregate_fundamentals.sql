-- Reconstructs total revenue or earnings across the S&P 500 for macro analysis.
-- Membership comes from index_membership (the references.is_sp500 flag was
-- dropped 2026-05-02 — snapshot-only and single-index).  JOIN on cik = cik.
-- Uses canonical standard_concept name: TotalRevenue.
-- For other indices (RUSSELL3000, NASDAQ100, WILSHIRE5000) swap index_name.

SELECT
    f.period_end,
    SUM(f.numeric_value) AS total_sp500_revenue
FROM "references" r
JOIN index_membership im ON im.cik = r.cik
JOIN fact f               ON r.cik = f.entity_id
WHERE im.index_name   = 'SP500'
  AND im.removal_date IS NULL          -- current member
  AND r.is_active     = TRUE
  AND f.standard_concept = 'TotalRevenue'
  AND f.frame = {{ frame | sql_quote }}
GROUP BY f.period_end
ORDER BY f.period_end DESC;
