-- The ultimate quant query. Filters data strictly by accepted_at to simulate what
-- a trading algorithm would have known on a random Tuesday in 2018.

SELECT
    r.symbol,
    f.standard_concept,
    f.numeric_value,
    f.accepted_at
FROM fact f
JOIN "references" r ON f.entity_id = r.cik
WHERE r.is_active = TRUE
  AND f.accepted_at <= {{ simulation_timestamp | sql_quote }}
  AND f.standard_concept IN ({{ metrics | sql_list }})
ORDER BY f.accepted_at DESC;
