-- Joins the taxonomy_guide to generate human-readable financial reports with official definitions
-- for junior analysts or automated dashboards.

SELECT
    e.name,
    f.period_end,
    t.human_name,
    f.numeric_value,
    t.definition
FROM fact f
JOIN entity e ON f.entity_id = e.cik
JOIN taxonomy_guide t ON f.standard_concept = t.standard_concept
WHERE e.cik = {{ cik | sql_quote }}
  AND f.statement_type = 'IncomeStatement'
  AND f.frame = {{ frame | sql_quote }};
