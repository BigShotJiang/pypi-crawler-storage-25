-- Resolves multi-share class anomalies and maps standard fundamentals directly to
-- Bloomberg FIGI codes for seamless trade execution.

SELECT
    r.figi,
    r.symbol,
    r.name,
    f.standard_concept,
    f.numeric_value,
    f.period_end
FROM "references" r
JOIN fact f ON r.cik = f.entity_id
WHERE r.is_active = TRUE
  AND f.standard_concept IN ({{ metrics | sql_list }})
  AND f.accepted_at <= {{ backtest_date | sql_quote }}
ORDER BY r.figi, f.period_end DESC;
