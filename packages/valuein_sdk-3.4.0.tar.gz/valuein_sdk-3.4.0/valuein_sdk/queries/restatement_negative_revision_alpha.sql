-- Isolates is_amendment = TRUE filings to track companies that retroactively revised their
-- historical earnings downward (Quality of Earnings red flag).
-- Uses canonical standard_concept name: NetIncome.

SELECT
    filing.entity_id,
    filing.filing_date,
    filing.amendment_no,
    f.standard_concept,
    f.numeric_value
FROM filing
JOIN fact f ON filing.accession_id = f.accession_id
WHERE filing.is_amendment = TRUE
  AND f.standard_concept = 'NetIncome'
  AND filing.filing_date BETWEEN {{ start_date | sql_quote }} AND {{ end_date | sql_quote }}
ORDER BY filing.filing_date DESC;
