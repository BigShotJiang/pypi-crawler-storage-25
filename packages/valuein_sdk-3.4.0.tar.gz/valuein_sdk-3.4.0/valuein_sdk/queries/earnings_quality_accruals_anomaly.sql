-- Calculates the Sloan Accruals Anomaly (Net Income minus Operating Cash Flow, scaled by Assets).
-- High accruals predict future stock underperformance.
-- Uses canonical standard_concept names: NetIncome, OperatingCashFlow, TotalAssets.
-- COALESCE(derived_quarterly_value, numeric_value) handles Q2/Q3 10-Q YTD cash flow reporting.

WITH financials AS (
    SELECT
        entity_id,
        standard_concept,
        COALESCE(derived_quarterly_value, numeric_value) AS value
    FROM fact
    WHERE frame = {{ frame | sql_quote }}
      AND standard_concept IN ('NetIncome', 'OperatingCashFlow', 'TotalAssets')
)
SELECT
    entity_id,
    SUM(CASE WHEN standard_concept = 'NetIncome' THEN value ELSE 0 END) -
    SUM(CASE WHEN standard_concept = 'OperatingCashFlow' THEN value ELSE 0 END) AS total_accruals,
    MAX(CASE WHEN standard_concept = 'TotalAssets' THEN value END) AS total_assets,
    (
        SUM(CASE WHEN standard_concept = 'NetIncome' THEN value ELSE 0 END) -
        SUM(CASE WHEN standard_concept = 'OperatingCashFlow' THEN value ELSE 0 END)
    ) / NULLIF(MAX(CASE WHEN standard_concept = 'TotalAssets' THEN value END), 0) AS accruals_ratio
FROM financials
GROUP BY entity_id;
