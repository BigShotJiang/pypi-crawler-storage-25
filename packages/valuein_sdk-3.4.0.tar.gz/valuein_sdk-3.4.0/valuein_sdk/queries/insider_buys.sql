-- Top insider buys for a single issuer over a window. Returns each Form 4
-- "P" (open-market purchase) transaction with the insider's name, role,
-- share count, price, and dollar notional, ranked by recency and notional.
--
-- Inputs (Jinja):
--   ticker          REQUIRED — symbol of the issuer, e.g. "NVDA"
--   lookback_days   optional — how many days back from today; default 90
--   min_shares      optional — minimum |shares| floor; default 0 (no floor)
--
-- Output columns:
--   transaction_date, accepted_at, insider_name, insider_role,
--   officer_title, transaction_code, shares, price_per_share,
--   notional_usd, post_transaction_shares, ownership_form, accession_id
--
-- Notes:
--   * Filters to transaction_code = 'P' (open-market purchase) by design —
--     other codes (S=sale, A=grant, M=option exercise, F=tax withholding,
--     G=gift, J=other) carry weaker conviction signal and would dilute the
--     buy-conviction screen.
--   * Excludes derivative transactions so the score reflects direct
--     equity acquisition, not option grants.
--   * notional_usd = ABS(shares) × price_per_share when both present;
--     null when price is unreported.
--   * Joins insider_party for the human name + role array.
--
-- Tier: enterprise (full plan) — the smart-money tables are FULL bucket only.

WITH target_entity AS (
    SELECT cik
    FROM "references"
    WHERE UPPER(symbol) = UPPER({{ ticker | sql_quote }}) AND is_active = TRUE
    LIMIT 1
),
party AS (
    SELECT id, name, cik AS insider_cik, party_type
    FROM insider_party
)
SELECT
    t.transaction_date,
    t.accepted_at,
    p.name                                  AS insider_name,
    p.insider_cik                           AS insider_cik,
    t.insider_role,
    t.officer_title,
    t.transaction_code,
    t.shares,
    t.price_per_share,
    CASE
        WHEN t.price_per_share IS NOT NULL
        THEN ABS(t.shares) * t.price_per_share
        ELSE NULL
    END                                     AS notional_usd,
    t.post_transaction_shares,
    t.ownership_form,
    t.accession_id
FROM insider_transaction t
LEFT JOIN party p ON t.insider_party_id = p.id
WHERE t.entity_id = (SELECT cik FROM target_entity)
  AND t.transaction_code = 'P'
  AND t.is_derivative = FALSE
  AND t.transaction_date >= (CURRENT_DATE - INTERVAL '{{ lookback_days | default(90) }}' DAY)
  AND ABS(t.shares) >= {{ min_shares | default(0) }}
ORDER BY t.transaction_date DESC, notional_usd DESC NULLS LAST
;
