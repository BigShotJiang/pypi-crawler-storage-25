-- Extracts TotalRevenue and Capital Expenditures to calculate the CapEx-to-Revenue ratio.
-- Uses canonical standard_concept names: TotalRevenue, CAPEX.
-- COALESCE(derived_quarterly_value, numeric_value) handles Q2/Q3 10-Q YTD reporting.
-- Caller should use ABS(capex) when computing the ratio.

WITH target_filings AS (
    SELECT
        f.accession_id,
        f.report_date
    FROM filing f
    JOIN "references" r ON f.entity_id = r.cik
    WHERE r.symbol = {{ ticker | sql_quote }}
      AND r.is_active = TRUE
      AND f.form_type IN ({{ form_types | sql_list }})
      AND f.filing_date BETWEEN {{ start_date | sql_quote }} AND {{ end_date | sql_quote }}
)
SELECT
    tf.report_date,
    fa.standard_concept,
    COALESCE(fa.derived_quarterly_value, fa.numeric_value) AS numeric_value
FROM target_filings tf
JOIN fact fa
  ON tf.accession_id = fa.accession_id
WHERE fa.standard_concept IN ('TotalRevenue', 'CAPEX')
ORDER BY tf.report_date DESC;
