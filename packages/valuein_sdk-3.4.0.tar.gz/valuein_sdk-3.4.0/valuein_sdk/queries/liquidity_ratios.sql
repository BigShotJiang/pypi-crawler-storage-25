-- Extracts Current Assets, Liabilities, and Inventory for Current/Quick Ratios.
-- Uses canonical standard_concept names: CurrentAssets, CurrentLiabilities, InventoryNet.

WITH target_filings AS (
    SELECT
        f.accession_id,
        f.report_date
    FROM filing f
    JOIN "references" r ON f.entity_id = r.cik
    WHERE r.symbol = {{ ticker | sql_quote }}
      AND r.is_active = TRUE
      AND f.form_type IN ({{ form_types | sql_list }})
      AND f.filing_date BETWEEN {{ start_date | sql_quote }} AND {{ end_date | sql_quote }}
)
SELECT
    tf.report_date,
    fa.standard_concept,
    fa.numeric_value
FROM target_filings tf
JOIN fact fa
  ON tf.accession_id = fa.accession_id
WHERE fa.standard_concept IN ('CurrentAssets', 'CurrentLiabilities', 'InventoryNet')
ORDER BY tf.report_date DESC;
