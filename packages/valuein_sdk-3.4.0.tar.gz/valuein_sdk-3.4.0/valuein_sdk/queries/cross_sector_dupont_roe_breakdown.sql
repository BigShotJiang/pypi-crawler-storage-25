-- Deconstructs Return on Equity into Profit Margin, Asset Turnover, and Financial Leverage
-- across an entire sector.
-- Uses canonical standard_concept names: NetIncome, TotalRevenue, TotalAssets, StockholdersEquity.

WITH dupont_components AS (
    SELECT
        e.name,
        e.sector,
        MAX(CASE WHEN f.standard_concept = 'NetIncome' THEN f.numeric_value END) AS net_income,
        MAX(CASE WHEN f.standard_concept = 'TotalRevenue' THEN f.numeric_value END) AS revenue,
        MAX(CASE WHEN f.standard_concept = 'TotalAssets' THEN f.numeric_value END) AS assets,
        MAX(CASE WHEN f.standard_concept = 'StockholdersEquity' THEN f.numeric_value END) AS equity
    FROM fact f
    JOIN entity e ON f.entity_id = e.cik
    WHERE f.frame = {{ frame | sql_quote }}
    GROUP BY e.name, e.sector
)
SELECT
    name,
    sector,
    (net_income / NULLIF(revenue, 0)) AS profit_margin,
    (revenue / NULLIF(assets, 0)) AS asset_turnover,
    (assets / NULLIF(equity, 0)) AS equity_multiplier,
    (net_income / NULLIF(equity, 0)) AS return_on_equity
FROM dupont_components
WHERE equity > 0
ORDER BY return_on_equity DESC;
