# Copyright 2026 Valuein LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Canonical plan configuration — fetched from the Valuein edge gateway.

The source of truth lives at
``~/WebstormProjects/cloudflare/shared/plans.ts`` and is exposed via
``GET https://data.valuein.biz/v1/plans``. This module:

1. Fetches ``/v1/plans`` lazily on first call and caches in process
   (5-minute TTL). Subsequent calls in the same run are free.
2. Falls back to :data:`PLANS_FALLBACK` — a hardcoded mirror of the
   canonical numbers — when the endpoint is unreachable, so error
   messages and upgrade hints never go blank on a gateway outage.

The :func:`get_plans` API is safe to call from any code path — it never
raises. Callers get the real numbers when the gateway is reachable and
the fallback mirror when it is not.
"""

from __future__ import annotations

import logging
import os
import time
from dataclasses import dataclass
from threading import Lock
from typing import Any

import httpx

logger = logging.getLogger("valuein_sdk.plans")

_DEFAULT_ENDPOINT = "https://data.valuein.biz/v1/plans"
_FETCH_TIMEOUT = 2.0
_CACHE_TTL_SECONDS = 5 * 60


@dataclass(frozen=True)
class PlanLimit:
    """Per-plan rate limit. Mirror of the edge-gateway canonical shape."""

    per_minute: int
    per_hour: int


# Hardcoded mirror of the approved canonical numbers. Keep aligned with
# ~/WebstormProjects/cloudflare/shared/plans.ts — the CI docs-sync script
# in the MCP repo fails the build if the live endpoint and this fallback
# disagree.
PLANS_FALLBACK: dict[str, PlanLimit] = {
    "sample": PlanLimit(per_minute=15, per_hour=150),
    "sp500": PlanLimit(per_minute=60, per_hour=1_000),
    "pro": PlanLimit(per_minute=100, per_hour=3_000),
    "full": PlanLimit(per_minute=300, per_hour=10_000),
}

# Fallback upgrade URLs per plan — matches the contract the MCP Worker
# emits on every 4xx response. Keeps SDK + MCP cross-surface hints identical.
UPGRADE_URL_FALLBACK: dict[str, str] = {
    "sample": "https://valuein.biz/pricing",
    "sp500": "https://valuein.biz/pricing",
    "pro": "https://valuein.biz/pricing",
    "full": "https://valuein.biz/contact",
}


# ─────────────────────────────────────────────────────────────────────
# Module-scope cache. Process-wide; safe under the GIL for simple reads.
# ─────────────────────────────────────────────────────────────────────
_cache: dict[str, PlanLimit] | None = None
_cache_fetched_at: float = 0.0
_cache_lock = Lock()


def get_plans(endpoint: str | None = None) -> dict[str, PlanLimit]:
    """Return the canonical per-plan rate limits.

    The gateway endpoint is consulted at most once per
    :data:`_CACHE_TTL_SECONDS`. Failures — network error, non-2xx,
    malformed body — transparently fall back to :data:`PLANS_FALLBACK`
    and log at ``WARNING`` level so the user sees *something* in their
    logs without their code path failing.

    Parameters
    ----------
    endpoint:
        Override the canonical URL. Defaults to the ``VALUEIN_PLANS_ENDPOINT``
        environment variable, then :data:`_DEFAULT_ENDPOINT`. Useful for
        pointing integration tests at a staging gateway.
    """
    global _cache, _cache_fetched_at

    now = time.time()
    # Read without the lock — the caller accepts a brief race on refresh
    # (worst case: two concurrent fetches on the first call after TTL).
    if _cache is not None and now - _cache_fetched_at < _CACHE_TTL_SECONDS:
        return _cache

    url = endpoint or os.environ.get("VALUEIN_PLANS_ENDPOINT") or _DEFAULT_ENDPOINT
    plans = _fetch_plans(url)

    with _cache_lock:
        _cache = plans
        _cache_fetched_at = now
    return plans


def format_rate_limit(plan_key: str) -> str:
    """Render a plan's rate limit as ``"100 req/min · 3,000 req/hr"``.

    Useful for error messages that guide the user from a 429 back to their
    actual tier ceiling without hardcoding numbers at the call site.
    """
    plans = get_plans()
    limit = plans.get(plan_key) or PLANS_FALLBACK.get(plan_key)
    if limit is None:
        return "(rate limits unavailable)"
    return f"{limit.per_minute:,} req/min · {limit.per_hour:,} req/hr"


# ─────────────────────────────────────────────────────────────────────
# Internals
# ─────────────────────────────────────────────────────────────────────
def _fetch_plans(endpoint: str) -> dict[str, PlanLimit]:
    """Network call with normalized parsing and hard fallback on any error."""
    try:
        with httpx.Client(timeout=_FETCH_TIMEOUT) as client:
            response = client.get(endpoint)
            response.raise_for_status()
            body: dict[str, Any] = response.json()
        return _parse_plans_body(body)
    except (httpx.HTTPError, ValueError, KeyError, TypeError) as exc:
        logger.warning(
            "plans fetch failed (%s); using PLANS_FALLBACK. endpoint=%s",
            exc,
            endpoint,
        )
        return dict(PLANS_FALLBACK)


def _parse_plans_body(body: dict[str, Any]) -> dict[str, PlanLimit]:
    """Validate and normalize the /v1/plans response into PlanLimit objects."""
    plans_obj = body.get("plans")
    if not isinstance(plans_obj, dict):
        raise ValueError("plans body is missing 'plans' object")

    parsed: dict[str, PlanLimit] = {}
    for key in ("sample", "sp500", "pro", "full"):
        entry = plans_obj.get(key)
        if not isinstance(entry, dict):
            raise KeyError(f"plans body is missing key '{key}'")
        try:
            parsed[key] = PlanLimit(
                per_minute=int(entry["perMinute"]),
                per_hour=int(entry["perHour"]),
            )
        except (KeyError, TypeError, ValueError) as exc:
            raise ValueError(f"plans body has malformed entry '{key}': {exc}") from exc
    return parsed


def _clear_cache_for_tests() -> None:
    """Reset the module-scope cache. Test-only, not part of the public API."""
    global _cache, _cache_fetched_at
    with _cache_lock:
        _cache = None
        _cache_fetched_at = 0.0
