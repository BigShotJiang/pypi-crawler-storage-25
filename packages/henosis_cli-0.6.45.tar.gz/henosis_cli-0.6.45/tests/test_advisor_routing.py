import asyncio
import importlib
from types import SimpleNamespace
from pathlib import Path
import uuid


def _new_local_tmp() -> Path:
    base = Path.cwd() / ".pytest_local_tmp"
    base.mkdir(parents=True, exist_ok=True)
    p = base / f"advisor-routing-{uuid.uuid4().hex[:10]}"
    p.mkdir(parents=True, exist_ok=False)
    return p


def make_cli(tmp_path: Path):
    cli_mod = importlib.import_module("cli")
    cli = cli_mod.ChatCLI(
        server="http://127.0.0.1:8000/api",
        model=None,
        system_prompt=None,
        timeout=5.0,
        map_prefix=False,
        log_enabled=False,
        save_to_threads=False,
        server_usage_commit=False,
        verbose=False,
    )
    cli.codex_auth_file = tmp_path / "henosis_cli_codex_auth.json"
    cli.codex_shared_auth_file = tmp_path / "codex_shared_auth" / "auth.json"
    cli._clear_codex_auth_state_on_disk(clear_shared=False)
    return cli


def test_advisor_auto_route_prefers_codex_then_byok_then_backend():
    tmp_path = _new_local_tmp()
    cli = make_cli(tmp_path)
    cli.access_hub = None

    cli.advisor_auth_mode = "auto"
    cli.auth_user = "user@example.com"
    cli.codex_access_token = "access-token"
    cli.codex_refresh_token = "refresh-token"

    assert cli._advisor_route_preferences() == ["codex_oauth", "backend"]

    cli.codex_access_token = None
    cli.codex_refresh_token = None

    class _Hub:
        def has_provider_key(self, provider):
            return provider == "openai"

    cli.access_hub = _Hub()
    assert cli._advisor_route_preferences() == ["byok", "backend"]

    cli.access_hub = None
    assert cli._advisor_route_preferences() == ["backend"]


def test_codex_local_advisor_tool_uses_gpt_55_over_codex_when_auto(monkeypatch):
    tmp_path = _new_local_tmp()
    cli_mod = importlib.import_module("cli")
    cli = make_cli(tmp_path)
    cli.model = "gpt-5.4"
    cli.enable_advisor = True
    cli.advisor_model = "gpt-5.5"
    cli.advisor_reasoning_effort = "xhigh"
    cli.advisor_auth_mode = "auto"
    cli.codex_access_token = "access-token"
    cli.codex_refresh_token = "refresh-token"
    cli.codex_account_id = "acct_123"

    captured = {}

    monkeypatch.setattr(cli_mod, "HAS_LOCAL_ADVISOR", True)
    monkeypatch.setattr(
        cli_mod,
        "local_resolve_advisor_config",
        lambda _cli: SimpleNamespace(
            advisor_model=_cli.advisor_model,
            reasoning_effort=_cli.advisor_reasoning_effort,
            max_uses=2,
            enabled=True,
        ),
    )
    monkeypatch.setattr(
        cli_mod,
        "local_build_advisor_prompt",
        lambda **kwargs: "advisor transcript",
    )

    async def fake_invoke_advisor_via_codex(model_name: str, transcript: str, reasoning_effort: str):
        captured["model_name"] = model_name
        captured["transcript"] = transcript
        captured["reasoning_effort"] = reasoning_effort
        return {
            "ok": True,
            "data": {
                "text": "advisor says hi",
                "advisor_model": model_name,
                "reasoning_effort": reasoning_effort,
                "usage": {"input_tokens": 11, "output_tokens": 5, "total_tokens": 16},
                "cost_usd": 0.123,
                "auth_mode": "codex_oauth",
            },
        }

    monkeypatch.setattr(cli, "_invoke_advisor_via_codex", fake_invoke_advisor_via_codex)

    result = asyncio.run(
        cli._codex_local_advisor_tool_result([
            {"role": "user", "content": "Please advise."},
        ])
    )

    assert result["ok"] is True
    assert captured == {
        "model_name": "gpt-5.5",
        "transcript": "advisor transcript",
        "reasoning_effort": "xhigh",
    }
    assert result["data"]["advisor_model"] == "gpt-5.5"
    assert result["data"]["auth_mode"] == "codex_oauth"
