###############################################################################
# __   _            _____    _____
# | \ | |          / ____|  / ____|
# |  \| |  _   _  | |      | (___
# | . ` | | | | | | |       \___ \
# | |\  | | |_| | | |____   ____) |
# |_| \_|  \__,_|  \_____| |_____/
#
# Fast constraint solving in Python  - https://github.com/yangeorget/nucs
#
# Copyright 2024-2026 - Yan Georget
###############################################################################
from numba import njit  # type: ignore
from numpy.typing import NDArray

from nucs.constants import MAX, MIN
from nucs.heuristics.value_dom_heuristic import value_dom_heuristic


@njit(cache=True, fastmath=True)
def mid_value_dom_heuristic(
    domains_stk: NDArray,
    entailed_propagators_stk: NDArray,
    domain_update_stk: NDArray,
    unbound_variable_nb_stk: NDArray,
    stks_top: NDArray,
    variable: int,
    params: NDArray,
) -> int:
    """
    Chooses the middle value of the domain.
    :param domains_stk: the stack of domains
    :param entailed_propagators_stk: the stack of entailed propagators
    :param domain_update_stk: the stack of domain updates
    :param stks_top: the index of the top of the stacks as a Numpy array
    :param variable: the variable
    :param params: a two-dimensional parameter array, unused here
    :return: the events
    """
    return value_dom_heuristic(
        domains_stk,
        entailed_propagators_stk,
        domain_update_stk,
        unbound_variable_nb_stk,
        stks_top,
        variable,
        (domains_stk[stks_top[0], variable, MIN] + domains_stk[stks_top[0], variable, MAX]) >> 1,
        params,
    )
