###############################################################################
# __   _            _____    _____
# | \ | |          / ____|  / ____|
# |  \| |  _   _  | |      | (___
# | . ` | | | | | | |       \___ \
# | |\  | | |_| | | |____   ____) |
# |_| \_|  \__,_|  \_____| |_____/
#
# Fast constraint solving in Python  - https://github.com/yangeorget/nucs
#
# Copyright 2024-2026 - Yan Georget
###############################################################################
import sys

from numba import njit  # type: ignore
from numpy.typing import NDArray

from nucs.constants import MAX, MIN
from nucs.heuristics.value_dom_heuristic import value_dom_heuristic


@njit(cache=True, fastmath=True)
def min_cost_dom_heuristic(
    domains_stk: NDArray,
    entailed_propagators_stk: NDArray,
    domain_update_stk: NDArray,
    unbound_variable_nb_stk: NDArray,
    stks_top: NDArray,
    variable: int,
    params: NDArray,
) -> int:
    """
    Chooses the value that minimizes the cost.
    :param domains_stk: the stack of domains
    :param entailed_propagators_stk: the stack of entailed propagators
    :param domain_update_stk: the stack of domain updates
    :param stks_top: the index of the top of the stacks as a Numpy array
    :param variable: the variable
    :param params: a two-dimensional (first dimension corresponds to variables, second to values) cost array
    :return: the events
    """
    best_cost = sys.maxsize
    best_value = -1
    domain = domains_stk[stks_top[0], variable]
    for value in range(domain[MIN], domain[MAX] + 1):
        cost = params[variable][value]
        if 0 < cost < best_cost:
            best_cost = cost
            best_value = value
    return value_dom_heuristic(
        domains_stk,
        entailed_propagators_stk,
        domain_update_stk,
        unbound_variable_nb_stk,
        stks_top,
        variable,
        best_value,
        params,
    )
