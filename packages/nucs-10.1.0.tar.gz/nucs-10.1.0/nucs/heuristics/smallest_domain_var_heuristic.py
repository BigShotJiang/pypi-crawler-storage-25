###############################################################################
# __   _            _____    _____
# | \ | |          / ____|  / ____|
# |  \| |  _   _  | |      | (___
# | . ` | | | | | | |       \___ \
# | |\  | | |_| | | |____   ____) |
# |_| \_|  \__,_|  \_____| |_____/
#
# Fast constraint solving in Python  - https://github.com/yangeorget/nucs
#
# Copyright 2024-2026 - Yan Georget
###############################################################################
import sys

from numba import njit  # type: ignore
from numpy.typing import NDArray

from nucs.constants import MAX, MIN


@njit(cache=True, fastmath=True)
def smallest_domain_var_heuristic(decision_variables: NDArray, domains_stk: NDArray, top: int, params: NDArray) -> int:
    """
    Chooses the first variable which is not instantiated with the smallest domain.
    :param decision_variables: the decision variables
    :param domains_stk: the stack of domains
    :param top: the index of the top of the stacks
    :param params: a two-dimensional parameter array, unused here
    :return: the variable
    """
    best_score = -sys.maxsize
    best_variable = -1
    for variable in decision_variables:
        domain = domains_stk[top, variable]
        score = domain[MIN] - domain[MAX]
        if best_score < score < 0:
            best_variable = variable
            best_score = score
    return best_variable
