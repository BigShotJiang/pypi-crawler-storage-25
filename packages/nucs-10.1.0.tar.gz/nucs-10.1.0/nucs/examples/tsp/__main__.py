###############################################################################
# __   _            _____    _____
# | \ | |          / ____|  / ____|
# |  \| |  _   _  | |      | (___
# | . ` | | | | | | |       \___ \
# | |\  | | |_| | | |____   ____) |
# |_| \_|  \__,_|  \_____| |_____/
#
# Fast constraint solving in Python  - https://github.com/yangeorget/nucs
#
# Copyright 2024-2026 - Yan Georget
###############################################################################

from nucs.examples.default_argument_parser import DefaultArgumentParser
from nucs.examples.tsp.tsp_instances import TSP_INSTANCES
from nucs.examples.tsp.tsp_problem import TSPProblem
from nucs.examples.tsp.tsp_var_heuristic import tsp_var_heuristic
from nucs.heuristics.heuristics import DOM_HEURISTIC_MIN_COST, register_var_heuristic
from nucs.solvers.backtrack_solver import BacktrackSolver
from nucs.solvers.multiprocessing_solver import MultiprocessingSolver

# Run with the following command (the second run is much faster because the code has been compiled):
# NUMBA_CACHE_DIR=.numba/cache python -m nucs.examples.tsp
if __name__ == "__main__":
    parser = DefaultArgumentParser()
    parser.add_argument("--name", choices=["GR17", "GR21", "GR24"], default="GR17")
    args = parser.parse_args()
    tsp_instance = TSP_INSTANCES[args.name]
    n = len(tsp_instance)
    decision_variables = list(range(0, 2 * n))
    problem = TSPProblem(tsp_instance)
    costs = tsp_instance + tsp_instance  # symmetry of costs
    tsp_var_heuristic_idx = register_var_heuristic(tsp_var_heuristic)
    solver = (
        MultiprocessingSolver(
            [
                BacktrackSolver(
                    prob,
                    consistency_alg=args.consistency,
                    decision_variables=decision_variables,
                    var_heuristic=tsp_var_heuristic_idx,
                    var_heuristic_params=costs,
                    dom_heuristic=DOM_HEURISTIC_MIN_COST,
                    dom_heuristic_params=costs,
                    log_level=args.log_level,
                    stks_max_height=args.cp_max_height,
                )
                for prob in problem.split(args.processors, 0)
            ]
        )
        if args.processors > 1
        else BacktrackSolver(
            problem,
            consistency_alg=args.consistency,
            decision_variables=decision_variables,
            var_heuristic=tsp_var_heuristic_idx,
            var_heuristic_params=costs,
            dom_heuristic=DOM_HEURISTIC_MIN_COST,
            dom_heuristic_params=costs,
            log_level=args.log_level,
            stks_max_height=args.cp_max_height,
        )
    )
    solution = solver.minimize(problem.total_cost, mode=args.optimization_mode)
    if args.display_stats:
        solver.print_statistics()
