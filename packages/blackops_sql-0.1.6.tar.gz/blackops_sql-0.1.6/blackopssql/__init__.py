# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (c) 2026 CommonHuman-Lab (original BreachSQL)
# Modifications copyright (c) 2026 roc1t1z3not (BlackOpsSQL)
"""
BlackOpsSQL — API-aware SQL injection reconnaissance and validation engine.

BlackOpsSQL is an AGPL-3.0-or-later modified fork of BreachSQL by CommonHuman-Lab.

Quick start:

    from blackopssql import scan, ScanOptions

    result = scan("https://target.com/search?q=test")
    print(result.total_findings)

    opts = ScanOptions(level=2, crawl=True, dbms="mysql")
    result = scan("https://target.com/search?q=test", opts)
"""

from blackopssql.engine import scan, ScanOptions
from blackopssql.engine.reporter import (
    ScanResult,
    ErrorBasedFinding,
    BooleanFinding,
    TimeFinding,
    UnionFinding,
    OOBFinding,
    FindingType,
)

__version__ = "0.1.6"


def _make_banner() -> str:
    import re
    import sys

    _tty = sys.stdout.isatty()

    def _r(t: str) -> str:
        return f"\033[31;1m{t}\033[0m" if _tty else t

    def _g(t: str) -> str:
        return f"\033[38;5;46m{t}\033[0m" if _tty else t

    def _d(t: str) -> str:
        return f"\033[2m{t}\033[0m" if _tty else t

    def _vlen(s: str) -> int:
        return len(re.sub(r"\033\[[0-9;]*m", "", s))

    # slant font: "BlackOps" (green) + "SQL" (red) merged side-by-side
    _BO_W = 44
    _BO = (
        "    ____  __           __   ____            ",
        "   / __ )/ /___ ______/ /__/ __ \\____  _____",
        "  / __  / / __ `/ ___/ //_/ / / / __ \\/ ___/",
        " / /_/ / / /_/ / /__/ ,< / /_/ / /_/ (__  ) ",
        "/_____/_/\\__,_/\\___/_/|_|\\____/ .___/____/  ",
        "                             /_/            ",
    )
    _SQL = (
        "   _____ ____    __ ",
        "  / ___// __ \\  / / ",
        "  \\__ \\/ / / / / /  ",
        " ___/ / /_/ / / /___",
        "/____/\\___\\_\\/_____/",
        "                    ",
    )

    art_colored = [_g(bo.ljust(_BO_W)) + _r(sql) for bo, sql in zip(_BO, _SQL)]
    art_raw = [bo.ljust(_BO_W) + sql for bo, sql in zip(_BO, _SQL)]

    info = [
        _d("  API-aware SQL injection reconnaissance and validation engine"),
        _d("  fork of BreachSQL by CommonHuman-Lab  |  AGPL-3.0-or-later"),
        _d("  Big thanks to Deorsa for Graphical and Visual design."),
    ]

    art_raw_widths = [len(l) for l in art_raw]
    info_raw_widths = [_vlen(l) for l in info]
    inner_w = max(art_raw_widths + info_raw_widths)
    frame_w = inner_w + 4  # "# " + content + " #"

    top_bot = _r("#" * frame_w)
    empty = _r("#") + " " * (frame_w - 2) + _r("#")

    rows = ["", top_bot, empty]
    for colored, raw_w in zip(art_colored, art_raw_widths):
        rows.append(_r("#") + " " + colored + " " * (inner_w - raw_w) + " " + _r("#"))
    rows.append(empty)
    for colored, raw_w in zip(info, info_raw_widths):
        rows.append(_r("#") + " " + colored + " " * (inner_w - raw_w) + " " + _r("#"))
    rows += [empty, top_bot, ""]
    return "\n".join(rows)


BANNER = _make_banner()

__all__ = [
    "__version__",
    "scan",
    "ScanOptions",
    "ScanResult",
    "ErrorBasedFinding",
    "BooleanFinding",
    "TimeFinding",
    "UnionFinding",
    "OOBFinding",
    "FindingType",
]
