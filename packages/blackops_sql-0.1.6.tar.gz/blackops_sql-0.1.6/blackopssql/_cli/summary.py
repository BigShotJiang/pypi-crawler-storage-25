# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (c) 2026 CommonHuman-Lab
from __future__ import annotations

import io
import re as _re
import sys
import urllib.parse as _up

from blackops_cli.colour import BOLD, CYAN, DIM, GREEN, RED, YELLOW

_ANSI_RE = _re.compile(r"\x1b\[[0-9;]*m")

_MARKER_RE = _re.compile(r"BreachSQL_[A-Za-z0-9]+")
_CHAR_RE   = _re.compile(r"\bchar\(\d[\d,]+\)")


def _ascii_table(columns: list[str], rows: list[list], max_col_w: int = 55) -> list[str]:
    """Return lines for a bordered ASCII table."""
    widths = [len(c) for c in columns]
    for row in rows:
        for i, cell in enumerate(row):
            if i < len(widths):
                widths[i] = min(max_col_w, max(widths[i], len(str(cell))))

    def border() -> str:
        return "+" + "+".join("-" * (w + 2) for w in widths) + "+"

    def fmt_row(cells: list) -> str:
        parts = []
        for i, cell in enumerate(cells):
            w = widths[i] if i < len(widths) else 0
            s = str(cell)
            if len(s) > w:
                s = s[:w - 3] + "..."
            parts.append(f" {s.ljust(w)} ")
        return "|" + "|".join(parts) + "|"

    lines = [border(), fmt_row(columns), border()]
    for row in rows:
        lines.append(fmt_row(row))
    lines.append(border())
    return lines


def _clean_payload(payload: str) -> str:
    """Replace random marker strings with a stable placeholder."""
    s = _MARKER_RE.sub("<marker>", payload)
    s = _CHAR_RE.sub("char(<marker>)", s)
    return s


def _proof_url(url: str, param: str, payload: str, original: str = "1") -> str:
    """
    Build a proof-of-concept URL by injecting *payload* into *param*.

    The payload is appended to the original param value (matching how the
    scanner injects it) so the link reproduces the exact request that
    triggered the finding.  The result is percent-encoded so it is safe
    to paste into a browser address bar or terminal.
    """
    try:
        parsed   = _up.urlparse(url)
        qs       = _up.parse_qs(parsed.query, keep_blank_values=True)
        orig_val = qs.get(param, [original])[0]
        injected = orig_val + payload
        qs[param] = [injected]
        new_query = _up.urlencode(qs, doseq=True)
        return _up.urlunparse(parsed._replace(query=new_query))
    except Exception:
        return ""


def print_summary(result) -> None:
    print()
    print(BOLD("=" * 60))
    print(BOLD("  BlackOpsSQL — Scan Summary"))
    print(BOLD("=" * 60))
    print(f"  Target        : {result.target}")
    print(f"  Duration      : {result.duration_s}s")
    print(f"  Requests sent : {result.requests_sent}")
    print(f"  URLs crawled  : {result.crawled_urls}")
    print(f"  Params tested : {result.params_tested}")
    print(f"  WAF detected  : {result.waf_detected or 'None'}")
    print(f"  Evasion used  : {result.evasion_applied or 'None'}")
    print(f"  DBMS detected : {result.dbms_detected or 'Unknown'}")
    print()

    if result.total_findings == 0:
        print(DIM("  No findings."))
    else:
        print(GREEN(f"  Total findings: {result.total_findings}"))
        print()
        i = 1

        for f in result.error_based:
            print(f"  {i}. {RED('[ERROR-BASED SQLi]')} Confirmed")
            print(f"     Param   : {f.parameter}")
            print(f"     URL     : {f.url}")
            print(f"     Method  : {f.method}")
            print(f"     DBMS    : {f.dbms}")
            print(f"     Payload : {f.payload}")
            if f.method.upper() == "GET":
                print(f"     Proof   : {CYAN(_proof_url(f.url, f.parameter, f.payload))}")
            print()
            i += 1

        for f in result.boolean_based:
            status = GREEN("[CONFIRMED]") if f.confirmed else YELLOW("[LIKELY]")
            print(f"  {i}. {status} {YELLOW('Boolean-based SQLi')}")
            print(f"     Param      : {f.parameter}")
            print(f"     URL        : {f.url}")
            print(f"     Method     : {f.method}")
            print(f"     True payload  : {f.payload_true}")
            print(f"     False payload : {f.payload_false}")
            print(f"     Diff score : {f.diff_score:.2f}")
            if f.method.upper() == "GET":
                print(f"     Proof (true) : {CYAN(_proof_url(f.url, f.parameter, f.payload_true))}")
                print(f"     Proof (false): {CYAN(_proof_url(f.url, f.parameter, f.payload_false))}")
            print()
            i += 1

        for f in result.time_based:
            print(f"  {i}. {CYAN('[TIME-BASED BLIND SQLi]')}")
            print(f"     Param     : {f.parameter}")
            print(f"     URL       : {f.url}")
            print(f"     Method    : {f.method}")
            print(f"     DBMS hint : {f.dbms}")
            print(f"     Payload   : {f.payload}")
            print(f"     Delay     : {f.observed_delay:.2f}s  (threshold: {f.threshold}s)")
            if f.method.upper() == "GET":
                print(f"     Proof   : {CYAN(_proof_url(f.url, f.parameter, f.payload))}")
            print()
            i += 1

        for f in result.union_based:
            print(f"  {i}. {RED('[UNION-BASED SQLi]')} Confirmed")
            print(f"     Param    : {f.parameter}")
            print(f"     URL      : {f.url}")
            print(f"     Method   : {f.method}")
            print(f"     Columns  : {f.column_count}")
            print(f"     Payload  : {_clean_payload(f.payload)}")
            if f.method.upper() == "GET":
                print(f"     Proof   : {CYAN(_proof_url(f.url, f.parameter, f.payload))}")
            print()
            i += 1

        for f in result.oob:
            print(f"  {i}. {CYAN('[OOB SQLi]')} Payload injected")
            print(f"     Param    : {f.parameter}")
            print(f"     URL      : {f.url}")
            print(f"     Callback : {f.callback_url}")
            print(f"     Payload  : {f.payload}")
            if f.method.upper() == "GET":
                print(f"     Proof   : {CYAN(_proof_url(f.url, f.parameter, f.payload))}")
            print()
            i += 1

        for f in result.stacked:
            print(f"  {i}. {RED('[STACKED QUERY SQLi]')} Confirmed")
            print(f"     Param   : {f.parameter}")
            print(f"     URL     : {f.url}")
            print(f"     Method  : {f.method}")
            print(f"     DBMS    : {f.dbms}")
            print(f"     Payload : {f.payload}")
            if f.method.upper() == "GET":
                print(f"     Proof   : {CYAN(_proof_url(f.url, f.parameter, f.payload))}")
            print()
            i += 1

        if result.extracted:
            print(f"  {GREEN('─' * 56)}")
            print(f"  {GREEN(BOLD('  Extracted Data'))}")
            print(f"  {GREEN('─' * 56)}")
            for f in result.extracted:
                mode_label = f.mode if f.mode == "union" else f"{f.mode}-blind"
                print(f"  {i}. {GREEN('[EXTRACTED]')} via {mode_label}")
                print(f"     Param : {f.parameter}")
                print(f"     URL   : {f.url}")
                print(f"     Expr  : {DIM(f.expr)}")
                print(f"     Value : {BOLD(f.value)}")
                print()
                i += 1

        if result.table_dumps:
            print(f"  {GREEN('─' * 56)}")
            print(f"  {GREEN(BOLD('  Table Dumps'))}")
            print(f"  {GREEN('─' * 56)}")
            _MAX_DISPLAY = 20
            for td in result.table_dumps:
                print(f"  {GREEN('[DUMP]')} {BOLD(td.table)}"
                      f"  ({len(td.rows)} row(s))  param:{td.parameter}")
                display_rows = td.rows[:_MAX_DISPLAY]
                for line in _ascii_table(td.columns, display_rows):
                    print(f"  {line}")
                if len(td.rows) > _MAX_DISPLAY:
                    print(f"  {DIM(f'  ... {len(td.rows) - _MAX_DISPLAY} more row(s) in dump file')}")
                print()

    if result.errors:
        print(RED("  Errors:"))
        for e in result.errors:
            print(f"    - {e}")

    print(BOLD("=" * 60))


def format_summary(result) -> str:
    """Return print_summary output as a plain string with ANSI codes stripped."""
    buf = io.StringIO()
    old, sys.stdout = sys.stdout, buf
    try:
        print_summary(result)
    finally:
        sys.stdout = old
    return _ANSI_RE.sub("", buf.getvalue())
