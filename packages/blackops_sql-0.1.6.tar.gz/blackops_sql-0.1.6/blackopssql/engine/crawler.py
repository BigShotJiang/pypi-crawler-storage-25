# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (c) 2026 CommonHuman-Lab
"""BlackOpsSQL — engine/crawler.py (delegates to blackops-core)."""

from blackops_core.crawler import CrawlResult, FormTarget, crawl

__all__ = ["CrawlResult", "FormTarget", "crawl"]
