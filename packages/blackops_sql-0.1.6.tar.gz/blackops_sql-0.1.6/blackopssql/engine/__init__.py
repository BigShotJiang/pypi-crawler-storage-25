# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (c) 2026 CommonHuman-Lab
"""
BlackOpsSQL — engine/__init__.py
Public API surface for the BlackOpsSQL engine.
"""

from .reporter import (
    ErrorBasedFinding,
    BooleanFinding,
    TimeFinding,
    UnionFinding,
    OOBFinding,
    StackedFinding,
    ExtractionFinding,
    TableDumpFinding,
    FindingType,
    ScanResult,
)
from .scanner import ScanOptions, scan

__all__ = [
    "scan",
    "ScanOptions",
    "ScanResult",
    "FindingType",
    "ErrorBasedFinding",
    "BooleanFinding",
    "TimeFinding",
    "UnionFinding",
    "OOBFinding",
    "StackedFinding",
    "ExtractionFinding",
    "TableDumpFinding",
]
