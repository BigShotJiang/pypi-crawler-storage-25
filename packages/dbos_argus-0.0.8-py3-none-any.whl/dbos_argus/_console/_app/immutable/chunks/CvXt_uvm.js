import{a as E,g as S,c as w}from"./BY5AQd03.js";import{B as A,p as R,c as W,s as L,r as U,a as y,g as u,i as M,h as m,f as P,C as T}from"./Cb6sDy_2.js";import{a as k,e as I,d as z,i as O,f as X}from"./Bj7uYL-u.js";import{p as d,r as Y}from"./BO7IDQ4s.js";/**
 * @file
 * @license @lucide/svelte v1.11.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const B={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":2,"stroke-linecap":"round","stroke-linejoin":"round"};/**
 * @file
 * @license @lucide/svelte v1.11.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const j=t=>{for(const e in t)if(e.startsWith("aria-")||e==="role"||e==="title")return!0;return!1};/**
 * @file
 * @license @lucide/svelte v1.11.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const G=Symbol("lucide-context"),Q=()=>A(G);var V=S("<svg><!><!></svg>");function Z(t,e){R(e,!0);const s=Q()??{},r=d(e,"color",19,()=>s.color??"currentColor"),a=d(e,"size",19,()=>s.size??24),n=d(e,"strokeWidth",19,()=>s.strokeWidth??2),i=d(e,"absoluteStrokeWidth",19,()=>s.absoluteStrokeWidth??!1),o=d(e,"iconNode",19,()=>[]),l=Y(e,["$$slots","$$events","$$legacy","name","color","size","strokeWidth","absoluteStrokeWidth","iconNode","children"]),p=m(()=>i()?Number(n())*24/Number(a()):n());var c=V();k(c,g=>({...B,...g,...l,width:a(),height:a(),stroke:r(),"stroke-width":u(p),class:["lucide-icon lucide",s.class,e.name&&`lucide-${e.name}`,e.class]}),[()=>!e.children&&!j(l)&&{"aria-hidden":"true"}]);var f=W(c);I(f,17,o,O,(g,C)=>{var b=m(()=>T(u(C),2));let v=()=>u(b)[0],x=()=>u(b)[1];var h=w(),D=P(h);X(D,v,!0,(N,q)=>{k(N,()=>({...x()}))}),E(g,h)});var _=L(f);z(_,()=>e.children??M),U(c),E(t,c),y()}function $(t){const e=new Map(t.map(r=>[r.workflow_id,r])),s=new Map;for(let r=0;r<t.length;r++){const a=t[r];let n=!1;for(let i=r+1;i<t.length;i++){const o=t[i];if(o.depth<a.depth)break;if(o.depth===a.depth){n=o.parent_workflow_id===a.parent_workflow_id;break}}s.set(a.workflow_id,n)}return t.map(r=>{const a=[r];let n=r;for(;n!=null&&n.parent_workflow_id;){const o=e.get(n.parent_workflow_id);if(!o)break;a.unshift(o),n=o}const i=[];for(let o=0;o<r.depth;o++){const l=a[o+1];i.push(s.get(l.workflow_id)??!1)}return{...r,lineage:i}})}function ee(t){const e=(t??"").toUpperCase();return e==="SUCCESS"?"bg-green-100 text-green-800 dark:bg-green-500/15 dark:text-green-400":e==="ENQUEUED"?"bg-violet-100 text-violet-800 dark:bg-violet-500/15 dark:text-violet-400":e==="PENDING"||e==="DELAYED"?"bg-blue-100 text-blue-800 dark:bg-blue-500/15 dark:text-blue-400":e==="CANCELLED"?"bg-amber-100 text-amber-800 dark:bg-amber-500/15 dark:text-amber-400":e==="ERROR"||e==="MAX_RECOVERY_ATTEMPTS_EXCEEDED"?"bg-red-100 text-red-800 dark:bg-red-500/15 dark:text-red-400":"bg-muted text-muted-foreground"}function te(t){const e=(t??"").toUpperCase();return e==="SUCCESS"?"bg-green-500":e==="ENQUEUED"?"bg-violet-500":e==="PENDING"||e==="DELAYED"?"bg-blue-500":e==="CANCELLED"?"bg-amber-500":e==="ERROR"||e==="MAX_RECOVERY_ATTEMPTS_EXCEEDED"?"bg-red-500":"bg-muted-foreground/40"}export{Z as I,ee as a,$ as c,te as s};
