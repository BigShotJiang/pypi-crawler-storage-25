import{l as o,a as r}from"../chunks/CZOv6v9x.js";export{o as load_css,r as start};
