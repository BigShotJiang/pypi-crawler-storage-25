# parallelhours-mcp

MCP (Model Context Protocol) server for [parallelhours.io](https://parallelhours.io) — translates MCP tool calls into REST API requests.

## Installation

```bash
uvx parallelhours-mcp
```

Or install as a package:

```bash
pip install parallelhours-mcp
```

## Configuration

### Environment Variables

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `TKPI_PAT` | Yes | — | Your Personal Access Token from [parallelhours.io](https://parallelhours.io) |
| `TKPI_BASE_URL` | No | `https://parallelhours.io` | Base URL of the parallelhours instance |
| `TKPI_PROJECT` | No | — | Default project key for task operations |

### Claude Code Configuration

Add to your `.mcp.json`:

```json
{
  "mcpServers": {
    "parallelhours": {
      "command": "uvx",
      "args": ["parallelhours-mcp"],
      "env": {
        "TKPI_PAT": "${TKPI_PAT}",
        "TKPI_PROJECT": "TKPI"
      }
    }
  }
}
```

## Available Tools

- `list_projects` — List all projects
- `get_active_timers` — List running timers
- `start_timer` — Start a timer on a task
- `stop_timer` — Stop a running timer
- `increment_prompt_count` — Increment prompt count
- `log_ai_event` — Log AI usage events
- `list_tasks` — List tasks in a project
- `get_task_context` — Get task details with timers
- `get_task_kpis` — Get task KPI metrics
- `create_task` — Create a new task
- `update_task` — Update an existing task

## Usage

```bash
export TKPI_PAT="your-pat-token"
uvx parallelhours-mcp
```

## Development

```bash
# Clone and setup
git clone https://github.com/pmonday/time-kpi.git
cd time-kpi

# Install dependencies
uv sync

# Run locally
python -m parallelhours_mcp
```

## License

MIT