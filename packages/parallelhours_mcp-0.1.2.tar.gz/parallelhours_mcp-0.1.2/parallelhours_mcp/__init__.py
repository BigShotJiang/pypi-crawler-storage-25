# Copyright (c) 2026 Parallel Hours LLC <support@parallelhours.io>
# SPDX-License-Identifier: MIT

"""Parallelhours MCP server package."""

__version__ = "0.1.0"
