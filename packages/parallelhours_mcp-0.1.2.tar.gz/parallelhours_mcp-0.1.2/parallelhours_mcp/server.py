# Copyright (c) 2026 Parallel Hours LLC <support@parallelhours.io>
# SPDX-License-Identifier: MIT

"""MCP server for time-kpi — translates MCP tool calls into REST API requests."""

import os

import httpx
from mcp.server.fastmcp import FastMCP

BASE_URL = os.environ.get("TKPI_BASE_URL", "https://parallelhours.io").rstrip("/")
PAT = os.environ.get("TKPI_PAT", "")
DEFAULT_PROJECT = os.environ.get("TKPI_PROJECT", "")
HEADERS = {
    "Authorization": f"Bearer {PAT}",
    "Content-Type": "application/json",
}

mcp = FastMCP("time-kpi")


def _get(path: str, **params) -> dict:
    url = f"{BASE_URL}/mcp/v1/{path}"
    resp = httpx.get(url, headers=HEADERS, params=params, timeout=30)
    resp.raise_for_status()
    return resp.json()


def _post(path: str, body: dict) -> dict:
    url = f"{BASE_URL}/mcp/v1/{path}"
    resp = httpx.post(url, headers=HEADERS, json=body, timeout=30)
    resp.raise_for_status()
    return resp.json()


def _patch(path: str, body: dict) -> dict:
    url = f"{BASE_URL}/mcp/v1/{path}"
    resp = httpx.patch(url, headers=HEADERS, json=body, timeout=30)
    resp.raise_for_status()
    return resp.json()


@mcp.tool()
def list_projects() -> dict:
    """List all projects for the authenticated user."""
    return _get("projects/")


@mcp.tool()
def get_active_timers() -> dict:
    """List all running timers for your time-kpi account."""
    return _get("timers/active/")


@mcp.tool()
def start_timer(task_id: str, notes: str = "", session_id: str = "") -> dict:
    """Start a timer on a task.

    Args:
        task_id: Task ID in PROJECT-N format, e.g. TKPI-12.
        notes: Optional notes for this session.
        session_id: Optional UUID to group entries from the same conversation session.
                    If omitted, a new session_id is generated and returned.
                    Pass the returned session_id to subsequent start_timer calls within
                    the same conversation to link them as one session.
    """
    body: dict = {"task_id": task_id, "notes": notes}
    if session_id:
        body["session_id"] = session_id
    return _post("timers/", body)


@mcp.tool()
def increment_prompt_count(timer_id: str) -> dict:
    """Increment the prompt count on a running timer by 1.

    Called automatically by the UserPromptSubmit hook on each user message.
    Can also be called explicitly by agents that manage prompt counting themselves.

    Args:
        timer_id: UUID of the running timer.
    """
    return _post(f"timers/{timer_id}/prompt/", {})


@mcp.tool()
def stop_timer(
    timer_id: str,
    prompt_count: int = 0,
    notes: str = "",
    loc_added: int | None = None,
    loc_deleted: int | None = None,
) -> dict:
    """Stop a running timer.

    Args:
        timer_id: UUID of the running timer (from start_timer or get_active_timers).
        prompt_count: Number of AI prompts used during this session.
        notes: Optional closing notes.
        loc_added: Lines of code added during this session (optional).
        loc_deleted: Lines of code deleted during this session (optional).
    """
    payload: dict = {"prompt_count": prompt_count, "notes": notes}
    if loc_added is not None:
        payload["loc_added"] = loc_added
    if loc_deleted is not None:
        payload["loc_deleted"] = loc_deleted
    return _post(f"timers/{timer_id}/stop/", payload)


@mcp.tool()
def log_ai_event(
    timer_id: str,
    prompt_count: int = 1,
    ai_tool: str = "claude",
    mode: str = "assisted",
    input_tokens: int | None = None,
    output_tokens: int | None = None,
    cache_read_tokens: int | None = None,
    cache_write_tokens: int | None = None,
    estimated_ai_min: int | None = None,
    model_id: str = "",
    tool_call_count: int | None = None,
    notes: str = "",
) -> dict:
    """Log an AI usage event against a running timer.

    Args:
        timer_id: UUID of the running timer.
        prompt_count: Number of prompts in this event.
        ai_tool: One of: claude, copilot, chatgpt, gemini, custom.
        mode: One of: assisted (human-led), delegated (AI-led).
        input_tokens: Input tokens consumed (optional).
        output_tokens: Output tokens generated (optional).
        cache_read_tokens: Tokens served from prompt cache — cache_read_input_tokens (optional).
        cache_write_tokens: Tokens written to prompt cache — cache_creation_input_tokens (optional).
        estimated_ai_min: Estimated AI-autonomous minutes saved (optional).
        model_id: Model identifier, e.g. claude-sonnet-4-6 (optional).
        tool_call_count: Number of tool calls made; proxy for autonomy depth (optional).
        notes: Optional notes.
    """
    body: dict = {
        "prompt_count": prompt_count,
        "ai_tool": ai_tool,
        "mode": mode,
        "notes": notes,
    }
    if input_tokens is not None:
        body["input_tokens"] = input_tokens
    if output_tokens is not None:
        body["output_tokens"] = output_tokens
    if cache_read_tokens is not None:
        body["cache_read_tokens"] = cache_read_tokens
    if cache_write_tokens is not None:
        body["cache_write_tokens"] = cache_write_tokens
    if estimated_ai_min is not None:
        body["estimated_ai_min"] = estimated_ai_min
    if model_id:
        body["model_id"] = model_id
    if tool_call_count is not None:
        body["tool_call_count"] = tool_call_count
    return _post(f"timers/{timer_id}/ai-event/", body)


@mcp.tool()
def list_tasks(project_key: str = DEFAULT_PROJECT, status: str = "") -> dict:
    """List tasks for your time-kpi account.

    Args:
        project_key: Filter by project key, e.g. TKPI. Defaults to TKPI_PROJECT env var if set.
        status: Filter by status: backlog, in_progress, in_review, done (optional).
    """
    params: dict = {}
    if project_key:
        params["project_key"] = project_key
    if status:
        params["status"] = status
    return _get("tasks/", **params)


@mcp.tool()
def get_task_context(task_id: str) -> dict:
    """Get full context for a task, including active timers and AI estimate.

    Args:
        task_id: Task ID in PROJECT-N format, e.g. TKPI-12.
    """
    return _get(f"tasks/{task_id}/")


@mcp.tool()
def get_task_kpis(task_id: str) -> dict:
    """Get KPI metrics for a task: wall-clock time, human vs. AI minutes,
    concurrency ratio, estimates, accuracy, and prompt count.

    Args:
        task_id: Task ID in PROJECT-N format, e.g. TKPI-12.
    """
    return _get(f"tasks/{task_id}/kpis/")


@mcp.tool()
def create_task(
    project_key: str = DEFAULT_PROJECT,
    title: str = "",
    description: str = "",
    acceptance_criteria: str = "",
    story_points: int | None = None,
    task_type: str = "feature",
    priority: str = "medium",
    status: str = "backlog",
    estimate_human_min: int | None = None,
    default_driver: str = "ai_agent",
    external_source: str = "",
    external_issue_id: str = "",
    external_issue_url: str = "",
) -> dict:
    """Create a new task in a project.

    Args:
        project_key: Project key, e.g. TKPI.
        title: Task title (required).
        description: Optional task description.
        acceptance_criteria: Optional acceptance criteria.
        story_points: Optional story points (1, 2, 3, 5, 8, or 13).
        task_type: One of: feature, bug, spike, chore. Default: feature.
        priority: One of: high, medium, low. Default: medium.
        status: Initial status. One of: backlog, in_progress, in_review, done. Default: backlog.
        estimate_human_min: Optional human-only time estimate in minutes.
        default_driver: One of: human, ai_agent. Default: ai_agent.
        external_source: One of: github, jira. Set when linking to an external issue.
        external_issue_id: External issue ID string, e.g. "108" for GitHub issue #108.
        external_issue_url: Full URL to the external issue.
    """
    if not project_key:
        raise ValueError(
            "project_key is required. Set TKPI_PROJECT in your environment or pass it explicitly."
        )
    if not title:
        raise ValueError("title is required.")
    payload: dict = {
        "project_key": project_key,
        "title": title,
        "description": description,
        "acceptance_criteria": acceptance_criteria,
        "task_type": task_type,
        "priority": priority,
        "status": status,
        "default_driver": default_driver,
    }
    if story_points is not None:
        payload["story_points"] = story_points
    if estimate_human_min is not None:
        payload["estimate_human_min"] = estimate_human_min
    if external_source:
        payload["external_source"] = external_source
    if external_issue_id:
        payload["external_issue_id"] = external_issue_id
    if external_issue_url:
        payload["external_issue_url"] = external_issue_url
    return _post("tasks/", payload)


@mcp.tool()
def update_task(
    task_id: str,
    title: str | None = None,
    description: str | None = None,
    acceptance_criteria: str | None = None,
    story_points: int | None = None,
    task_type: str | None = None,
    priority: str | None = None,
    status: str | None = None,
    estimate_human_min: int | None = None,
    external_source: str | None = None,
    external_issue_id: str | None = None,
    external_issue_url: str | None = None,
) -> dict:
    """Update fields on an existing task. Only provided fields are changed.

    Args:
        task_id: Task ID in PROJECT-N format, e.g. TKPI-12.
        title: New title.
        description: New description.
        acceptance_criteria: New acceptance criteria.
        story_points: New story points (1, 2, 3, 5, 8, or 13).
        task_type: One of: feature, bug, spike, chore.
        priority: One of: high, medium, low.
        status: New status. Valid transitions: backlog→in_progress, in_progress→in_review|backlog,
                in_review→done|in_progress|backlog, done→backlog.
        estimate_human_min: Human-only time estimate in minutes.
        external_source: One of: github, jira. Set when linking to an external issue.
        external_issue_id: External issue ID string, e.g. "108" for GitHub issue #108.
        external_issue_url: Full URL to the external issue.
    """
    payload: dict = {}
    for field, val in [
        ("title", title),
        ("description", description),
        ("acceptance_criteria", acceptance_criteria),
        ("story_points", story_points),
        ("task_type", task_type),
        ("priority", priority),
        ("status", status),
        ("estimate_human_min", estimate_human_min),
        ("external_source", external_source),
        ("external_issue_id", external_issue_id),
        ("external_issue_url", external_issue_url),
    ]:
        if val is not None:
            payload[field] = val
    return _patch(f"tasks/{task_id}/", payload)


@mcp.tool()
def get_project_billing(
    project_key: str,
    since: str = "",
    until: str = "",
) -> dict:
    """Get billing period summary for a project.

    Returns grand total, billable hours, rate, and period dates.
    Auto-resolves the current billing period if the project has one configured.

    Args:
        project_key: Project key, e.g. TKPI.
        since: Optional ISO date string (YYYY-MM-DD) to override period start.
        until: Optional ISO date string (YYYY-MM-DD) to override period end.
    """
    params: dict = {}
    if since:
        params["since"] = since
    if until:
        params["until"] = until
    return _get(f"projects/{project_key}/billing/", **params)


@mcp.tool()
def get_project_billing_tasks(
    project_key: str,
    since: str = "",
    until: str = "",
) -> dict:
    """Get itemized task-level billing breakdown for a project.

    Returns one row per task with billable hours and dollar amount.
    Line items (e.g. Claude License) show 0 hours with a fixed amount.

    Args:
        project_key: Project key, e.g. TKPI.
        since: Optional ISO date string to override period start.
        until: Optional ISO date string to override period end.
    """
    params: dict = {}
    if since:
        params["since"] = since
    if until:
        params["until"] = until
    return _get(f"projects/{project_key}/billing/tasks/", **params)


@mcp.tool()
def get_project_hours(
    project_key: str,
    since: str = "",
    until: str = "",
) -> dict:
    """Get hour totals for a project period (no billing config required).

    Returns wall-clock, human-only, AI-only, and all-logged hour totals.
    Useful for a quick "how many hours this billing period?" check.

    Args:
        project_key: Project key, e.g. TKPI.
        since: Optional ISO date string to override period start.
        until: Optional ISO date string to override period end.
    """
    params: dict = {}
    if since:
        params["since"] = since
    if until:
        params["until"] = until
    return _get(f"projects/{project_key}/hours/", **params)


def main():
    """Entry point for the CLI."""
    if not PAT:
        raise SystemExit("TKPI_PAT environment variable is not set.")
    mcp.run()
