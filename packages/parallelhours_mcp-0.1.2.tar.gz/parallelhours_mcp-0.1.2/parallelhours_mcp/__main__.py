# Copyright (c) 2026 Parallel Hours LLC <support@parallelhours.io>
# SPDX-License-Identifier: MIT

"""CLI entry point for parallelhours-mcp."""

from parallelhours_mcp.server import main

if __name__ == "__main__":
    main()
