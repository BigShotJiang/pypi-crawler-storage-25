# Changelog

All notable changes to OrionBelt Semantic Layer are documented here.

## [2.6.0] - 2026-05-23

### Added

- **Trend Analysis primitives.** Four additive surface extensions for FP&A / finance workloads:
  - **`partitionBy` on `MetricType.CUMULATIVE`** — per-dimension rolling windows (e.g. 12-month MA per country). Threads through resolution into the cumulative window's `PARTITION BY` clause, composes with grain-to-date. Default `[]` preserves v2.5 SQL exactly.
  - **`MetricType.WINDOW`** — single-row window functions (`rank` / `dense_rank` / `row_number` / `ntile` / `lag` / `lead` / `first_value` / `last_value`). New `compiler/window_wrap.py` runs after `cumulative_wrap` so window metrics compose with cumulative outputs (e.g. ranking a moving average). New fields: `windowFunction`, `offset`, `buckets`, `orderDirection`, `defaultValue`.
  - **9 statistical aggregates** on `Measure.aggregation`: `stddev`, `stddev_pop`, `variance`, `var_pop`, `corr`, `covar_pop`, `covar_samp`, `regr_slope`, `regr_intercept`. Column arity validated at model-load time. ClickHouse maps to camelCase (`stddevPop`, `covarSamp`, etc.); MySQL rejects correlation/covariance/regression; BigQuery + ClickHouse reject linear regression — all with hard `UnsupportedAggregationError` at compile time, no silent fallback.
  - **Composition over `DERIVED`** — derived metrics already compose any metric by name, so MA-crossover signals, MoM deltas, and similar emerge with zero new compiler work.
  - New guide: [Trend Analysis](docs/guide/trend-analysis.md).
- **OSI v0.2 spec compatibility.** Converter emits `version: "0.2.0.dev0"` to match the upstream OSI spec evolution:
  - **`primary_key` first-class** — per-column `primaryKey: true` flags map to the OSI dataset's `primary_key` array (composite supported, declaration order preserved).
  - **`unique_keys` first-class** — round-trip via OBSL-vendor `customExtensions` (`obml_unique_keys`); OBML has no native unique-key concept yet.
  - **Field `label` first-class** — round-trip via OBSL-vendor `customExtensions` (`obml_field_label`).
  - **Top-level `dialects` / `vendors` informational arrays** emitted on every doc.
  - **`MAQL` dialect** and **`GOODDATA` vendor** added to the known-enum tuples; MAQL-only metric expressions pass through the existing fallback without crashing.
  - **Legacy v0.1.x reader** — `_normalize_legacy_v01()` promotes pre-v0.2 `obml_primary_key` / `obml_unique_keys` `custom_extensions` payloads into v0.2 first-class fields before parsing, so existing OSI v0.1.1 inputs continue to load.
  - **Vendored schema refreshed** to upstream `main` (`osi-obml/osi-schema.json`); `scripts/refresh-osi-schema.sh` keeps the vendored copy in sync.
- **OSI input validation on `POST /v1/convert/osi-to-obml`.** Response gains an optional `input_validation` field carrying Draft 2020-12 schema errors and semantic errors for the source OSI document. Advisory by default — the endpoint still returns 200 with the converted output even when input fails strict v0.2 validation, because the legacy v0.1 shim still produces correct OBML.

### Changed

- **Breaking (output format):** OBML → OSI conversion now emits OSI v0.2.0.dev0. Downstream consumers pinning to v0.1.1 will reject v2.6 output. Migration path: parse the output with any v0.2-aware reader, or use the OSI-side legacy shim on the reverse direction (the converter still reads v0.1 inputs).
- **`/v1/convert/osi-to-obml` response shape:** new optional `input_validation: ValidationDetail | None` field. Existing clients see no break (the field is optional and `null` on the obml-to-osi endpoint where input-side validation isn't wired yet).

### Propagated

- **OBML JSON Schema** (`schema/obml-schema.json`) — new metric fields, `WindowFunctionKind` enum, statistical aggregations.
- **OBML reference markdown** (`src/orionbelt/obml_reference.py`) — documents `MetricType.WINDOW`, `partitionBy`, and statistical aggregates.
- **OBSL ontology** (`ontology/obsl.ttl`) — new `obsl:WindowMetric` class plus `partitionBy`, `windowFunction`, `windowOffset`, `windowBuckets`, `orderDirection`, `windowDefaultValue` datatype properties. Disjointness with other metric subtypes asserted.
- **MkDocs** — new `docs/guide/trend-analysis.md` under the Guide nav. `docs/guide/model-format.md` lists the four metric types, the `partitionBy` + window-metric fields, and the statistical-aggregate arity rules. `docs/guide/osi.md` documents the v0.2 bump and the legacy reader shim. Comparison docs (dbt / Cube / LookML / Malloy / AtScale) refreshed to reflect the new differentiation surfaces.

### Tests

+72 new (43 trend-analysis unit + 9 OSI roundtrip for v2.6 fields + 16 OSI v0.2 compat + 4 convert-endpoint integration). Total suite: **2081 passed, 159 skipped**.

## [2.5.0] - 2026-05-22

### Added

- **Postgres wire protocol surface (pgwire)** — fourth surface alongside REST, Flight, and MCP. Native ``postgres://``-protocol endpoint on port 5432 (configurable via ``PGWIRE_PORT``) so any BI tool, ORM, or psql client speaking the Postgres v3 protocol talks to OBSL directly. Steps 1–4 land the hello-world handshake, semantic-SQL routing through ``SemanticRouter``, ``pg_catalog`` / ``information_schema`` emulation backed by an embedded DuckDB catalog, and the extended-query protocol (``Parse`` / ``Bind`` / ``Describe`` / ``Execute`` / ``Sync``). New env vars ``PGWIRE_ENABLED``, ``PGWIRE_HOST``, ``PGWIRE_PORT``, ``PGWIRE_AUTH_MODE``, ``PGWIRE_MAX_CONNECTIONS``, ``PGWIRE_QUERY_TIMEOUT_SECONDS``. PRs #58–#61.
- **v2.5.0 catalog layout: `orionbelt` database with one schema per model + a `model` table per schema.** BI tools see ``database=orionbelt``, ``schema=<model_name>``, ``table=model``. Six metadata views per schema — ``dimensions`` / ``measures`` / ``metrics`` and their ``_*_metadata`` siblings — surface the semantic surface for in-SQL introspection. The Arrow Flight ``model.<view>`` alias works identically on pgwire so the same probing SQL is portable across both wires.
- **Tableau Desktop end-to-end compatibility over pgwire / pgjdbc.** Captured and fixed every layer Tableau exercises during connect + dashboard query — wire format (``Bind.result_formats`` honoured per column, including 8-byte binary FLOAT8 for pgjdbc's binary-transfer set), result-column alias preservation (Tableau's ``SUM(x) AS "sum:x:ok"`` now survives translator + compiler intact via a sqlglot-based router-level rewrite), catalog OID translation (shadow ``_obsl_pg_attribute`` and ``_obsl_pg_type`` ``TEMP`` views map DuckDB internal type IDs to real Postgres OIDs so pgjdbc allocates the right-width column readers), JDBC connect-check temp-table dance (binary parameter decoding for INT2/4/8, BOOL, FLOAT4/8, TEXT/VARCHAR/NAME/BPCHAR, BYTEA; SQL rewrites for ``CREATE [LOCAL|GLOBAL] TEMP TABLE`` and ``SELECT … INTO TEMP TABLE``; stub ``_pg_expandarray`` macro for ``getPrimaryKeys``), canned locale + version probes (``SHOW lc_collate`` family, ``SELECT current_catalog`` / ``current_role`` / ``session_user``), and the Tableau ``HAVING (COUNT(1) > 0)`` tautology silently stripped by the translator.

### Fixed

- **CFL leg joins tables referenced by measure-filter expressions.** A measure with a filter on a sibling dim table (e.g. ``Electronics Sales`` filtering ``Products.Category = 'Electronics'``) expanded into the CFL UNION ALL leg as ``CAST(CASE WHEN Products.Category = 'Electronics' THEN Sales.Amount END AS …)``, but the leg's FROM only carried the measure's source table + dimension joins. Real-database runs failed with ``missing FROM-clause entry for table "Products"``. The planner now collects table refs from each own-measure expression (intersected with the leg's reachable set so unrelated facts don't get pulled in) and adds them to ``leg_required`` before computing the common-root + join path.
- **ob-postgres driver classifies ADBC PyArrow types.** ``adbc-driver-postgresql`` returns ``cursor.description[i].type_code`` as a PyArrow ``DataType`` (``int32`` / ``timestamp[us, tz=UTC]`` / …) and wraps NUMERIC / MONEY / INTERVAL in ``OpaqueType`` whose ``type_name`` attribute carries the Postgres type name. The legacy code did ``isinstance(type_code, int)`` and fell through to ``STRING`` for everything else, so every column from a live ADBC connection surfaced as TEXT — including NUMERIC measures that Tableau then read as strings. New ``_classify_type_code`` handles the PyArrow DataType paths, the OpaqueType repr-substring match, and keeps the OID-integer legacy psycopg2 path.
- **Executor recognises ADBC ``OpaqueType`` in ``_arrow_type_to_hint``.** Same root cause as the driver fix, surfacing in the executor's Arrow-fast-path type-hint detection. ``pa.types.is_decimal`` returns False for OpaqueType; we now inspect ``type_name`` and map ``numeric`` / ``money`` / ``decimal`` → ``number``, temporal names → ``datetime``, ``bytea`` → ``binary``. Wrapped in ``try/except (AttributeError, TypeError)`` so non-DataType objects fall through cleanly. Added a ``_PG_OID_TO_HINT`` table for ``_map_type_code`` covering the PEP-249 fallback when ``cursor.description`` populates type codes with raw Postgres OIDs (psycopg2/3).

#### DBeaver + Tableau end-to-end hardening (cdee746…91be4a2)

The catalog-layout flip surfaced a stack of BI-tool compat regressions. Each commit isolates one root cause; together they make the schema-tree refresh, column panel, SQL editor, and chart-query paths work end-to-end in DBeaver 26.x and Tableau Desktop 2024.x.

- **``pg_get_keywords()`` is a TABLE macro, not scalar.** DBeaver's SQL-editor probe calls it as ``FROM pg_get_keywords()``; DuckDB rejected the scalar form with ``Table Function with name pg_get_keywords does not exist``. Now declared as a one-row table macro returning a ``word`` column.
- **``current_schema()`` and ``SHOW search_path`` return the connected model.** Pre-fix the canned response was the literal ``"orionbelt"`` — but post-flip that's the database name, not a schema. DBeaver issued ``SET search_path = <model>`` then ``SELECT current_schema()``, got back ``orionbelt``, filtered ``pg_class`` by a non-existent schema, and NPE'd. The router now threads an ``_effective_schema(database)`` value into ``match_canned`` so both responses reflect the model schema (the connected database when it names a model, else the first loaded model for the ``orionbelt`` brand).
- **3-part qualifier stripping for Tableau pushdown.** ``_unwrap_model_qualifier`` previously only handled ``"<schema>"."model"``. Tableau's JDBC-source pushdown emits the full 3-part form ``"orionbelt"."<schema>"."model"`` and the un-stripped reference bounced off the OBSQL translator — empty charts in Tableau. The regex now accepts an optional leading database prefix; ``"a"."b"."model"`` reduces to ``"b"`` like the 2-part shape.
- **``search_path`` ParameterStatus at startup (DBeaver "all activities" NPE).** pgjdbc 42.x reads ``serverParameters.get("search_path").toString()`` from the post-AuthOk ParameterStatus frames; OBSL never emitted one for ``search_path``, so the lookup returned ``null`` and the unguarded ``.toString()`` matched the verbatim Java 17 NPE message users hit on every DBeaver action. Now emitted (along with ``is_superuser`` / ``session_authorization`` / ``IntervalStyle`` so other pgjdbc-cached lookups don't NPE the same way).
- **Canned ``SELECT current_schema(),session_user`` (DBeaver SQL-editor opener).** Only the single-column form was canned; the combined two-column form fell through to the semantic translator, errored on the missing FROM, and the downstream schema-tree refresh NPE'd in DBeaver's UI code. Both forms now return the two columns directly.
- **Eight empty pg_catalog stubs for relations DuckDB doesn't expose.** ``pg_event_trigger`` / ``pg_publication`` / ``pg_subscription`` / ``pg_foreign_data_wrapper`` / ``pg_foreign_server`` / ``pg_user_mapping`` / ``pg_policy`` / ``pg_extension``. DBeaver's schema browse probes each; without the stubs DuckDB returned ``Catalog Error: Table with name <X> does not exist`` and the browse aborted with a generic SQL-state 42601. Empty results are semantically correct for OBSL's read-only semantic surface (no event triggers, no logical replication, no foreign tables, no RLS policies).
- **Idempotent catalog refresh → stable ``pg_class.oid`` (DBeaver Columns panel).** Every ``CatalogEmulator.refresh()`` call ran ``DROP TABLE … model`` + ``CREATE TABLE``, assigning a fresh oid each time. DBeaver caches the table oid from one probe (``getTables`` walk) and reuses it on the next (``WHERE c.oid = $1`` in ``getColumns``). Shifted oids → DBeaver's column panel rendered empty. Refresh now hashes the table DDL + the model's dimension / measure / metric labels into a per-schema fingerprint; identical models skip the DROP / CREATE so the oid stays stable across catalog probes. A real model edit (rename / type swap / add / remove a column) still invalidates the fingerprint and triggers a clean re-CREATE.
- **``model.<view>`` user-friendly alias for metadata views.** The Arrow Flight surface accepts ``SELECT * FROM model.dimensions`` (``model`` reads as "the connected model"); pgwire now does the same — the router recognises the alias and rewrites it to the connected model's actual schema before catalog execution. Covers all six metadata views.
- **``<schema>.model`` routes to OBSQL data path, not catalog probe.** ``_references_model_schema`` matched the qualified ``test_sem_layer.model`` and routed to the catalog DuckDB — where ``model`` is a column-shape-only table with no rows. Now excluded from the catalog match so ``_unwrap_model_qualifier`` + the OBSQL translator handle the data query end-to-end. Tableau / Dremio / DBeaver direct pushdown all hit the right path.
- **Shadow ``pg_settings`` exposes Postgres GUCs DuckDB lacks (the Tableau ``81B3934F`` connection error).** Tableau's pgjdbc connect-check runs ``SELECT setting FROM pg_settings WHERE name = 'max_index_keys'`` and aborts the entire connection when the result is empty. DuckDB's native pg_settings only carries DuckDB-internal GUCs (``max_memory`` …). The shadow UNIONs ``duckdb_settings()`` with the standard Postgres defaults for ~27 GUCs BI tools probe at connect — ``max_index_keys`` / ``max_identifier_length`` / ``server_version_num`` / locale settings / search_path / transaction defaults / extra_float_digits / application_name / IntervalStyle / etc.

### Deferred

- **``MODEL_FILE`` removal pushed to v2.6.0.** The v2.4.0 changelog scheduled removal for v2.5.0 but the BI-tool compat work consumed the runway. The deprecation warning still fires at startup and the alias still works; only the removal target moves. ``MODEL_FILE`` and ``MODEL_FILES`` remain mutually exclusive — startup errors when both are set.

#### Arrow Flight catalog tree mirrors pgwire (5d8aeaa)

- **Flight ``CommandGetCatalogs`` / ``CommandGetDbSchemas`` / ``CommandGetTables`` / ``CommandGetColumns`` flip to match the pgwire v2.5.0 layout.** Pre-fix the Flight tree showed ``<model_name> > model > <model_name>`` — the model name as catalog, the literal "model" as schema, and the per-model virtual table at the table level. Confusing for users toggling between Flight and pgwire connections in DBeaver. Now both wires render ``orionbelt > <model_name> > model`` (plus the six ``dimensions`` / ``measures`` / ``metrics`` + ``_*_metadata`` views). Model selection moves from ``catalog_filter`` (protobuf field 1) to ``db_schema_filter`` (field 2); the old field 1 path is preserved as a fallback so the obsql CLI ``--model`` flag and our Dremio integration tests keep working unchanged.

## [2.4.0] - 2026-05-15

### Added

- **OrionBelt Semantic QL (OBSQL)** — the third surface in the OBSL / OBML / OBSQL trio. BI-style SQL against a per-model virtual table, translated to `QueryObject` and compiled through the existing pipeline. New `src/orionbelt/compiler/sql_translator.py` is a pure-function translator (`translate_sql_to_query(sql, model) -> QueryObject`) — sqlglot-based, with no Flight or FastAPI imports. New REST endpoints `POST /v1/sessions/{id}/query/semantic-ql[/compile]` and top-level shortcuts `POST /v1/query/semantic-ql[/compile]`; the `/compile` variant returns the translated QueryObject JSON so callers can see what their SQL became. Grammar covers bare-label form, `MEASURE("…")` marker (matches Snowflake `SEMANTIC_VIEW` / Databricks metric-view syntax), aggregate-wrap matching (`SUM(sum_measure)` accepted when the wrap matches the declared aggregation; mismatched wraps and any wrap on a metric reject with a clear error naming the declared form), `WHERE` on a measure auto-routes to `HAVING`, `GROUP BY` silently accepted, `ORDER BY` by alias or 1-based position, and explicit rejection of joins / CTEs / subqueries / UNION / window functions / `SELECT *` with `UNSUPPORTED_SQL_FEATURE`. New guide at `docs/guide/semantic-ql.md`.
- **OBSQL no-FROM mode.** On a single-model connection, `SELECT "Customer Country", "Total Revenue"` (no `FROM`) resolves to the implicit model. Classification routes no-FROM SELECTs to semantic mode when every column identifier matches a dim / measure / metric. Unknown identifiers reject with `RAW_SQL_REJECTED` so the user gets a clear "this isn't a query against the model" signal rather than `UNKNOWN_SELECT_ITEM`.
- **OBSQL raw mode via qualified columns.** OBML raw-mode (un-aggregated detail rows from data objects) is now a first-class OBSQL shape, triggered by qualified `"<DataObject>"."<column>"` references in `SELECT`. Translator inspects each SELECT item; if every item is a qualified data-object column, it emits `QuerySelect(fields=[...])` instead of dimensions/measures. WHERE accepts qualified-column predicates only (no measure routing, no HAVING — HAVING rejects with `UNSUPPORTED_SQL_FEATURE`). GROUP BY rejects (raw is per-row, not aggregated). DISTINCT honoured via `QuerySelect.distinct`. ORDER BY accepts qualified refs from the SELECT list or 1-based positions. Mixing qualified raw cols with bare dim/measure labels in the same SELECT rejects with new `MIXED_RAW_AND_AGGREGATE_MODE`.
- **`WITH ROLLUP` / `WITH CUBE` first-class.** `QueryObject.grouping: Grouping | None` enum. Star + CFL planners emit `GROUP BY ROLLUP(...) / CUBE(...)` and append `GROUPING(dim) AS _g_<dim>` flag columns. ClickHouse dialect override emits `GROUP BY ... WITH ROLLUP / CUBE` (function form not supported by ClickHouse). Trailing `WITH ROLLUP` / `WITH CUBE` in OBSQL is stripped before parse and maps to the Grouping enum; `GROUP BY ROLLUP(...)` function form also recognized. Auto-order even without `LIMIT` when grouping is set, defaulting to `NULLS FIRST` so subtotals and the grand-total row sort to the top of BI pivot tables. Backfill `NULLS FIRST` on explicit `ORDER BY` entries that omit the NULLs position; respect explicit `NULLS LAST`. `INCOMPATIBLE_COMBINATION` warning when rollup combines with total / period-over-period / cumulative wrappers.
- **OBSQL `OFFSET` support** (both semantic + raw mode) translates `OFFSET <n>` into `QueryObject.offset`. Pairs with `LIMIT` for deterministic pagination. Schema updated (`schema/query-schema.json` adds `nullsPosition` enum + `nulls` field on `queryOrderBy`).
- **Multi-model addressing — `MODEL_FILES` + Flight catalog routing.** New env var `MODEL_FILES=path1.yaml,path2.yaml,...` lets OBSL pre-load N models at startup; each model gets its own protected internal session whose session id IS the model's addressing name. BI tools and clients pick which to query via the standard Flight SQL "Database" field (`Connection.setCatalog()` / gRPC `database` metadata header). New `_SessionRoutingMiddleware` reads `database` / `x-obsl-model` / `catalog` from gRPC metadata; `_get_model(context)` resolves in priority order (explicit selector → legacy `__default__` → auto-resolve when exactly one model is loaded → rich error listing available models with per-client setup instructions). `CommandGetCatalogs` now returns one row per loaded model; per-model dialect: OBML `settings.defaultDialect` wins over the server's process-wide `DB_VENDOR`. New name-normalisation pipeline at `src/orionbelt/models/identifiers.py` (lowercase → replace whitespace/dot/dash runs with underscore → collapse runs → strip `_obml` suffix → validate against `^[a-z][a-z0-9_]{0,62}$` → reject reserved names). New optional `name:` field on `SemanticModel`. New `GET /v1/models` discovery endpoint lists every pre-loaded model with name, description, and counts.
- **OBSQL CLI** — `examples/obsql.py`, a tiny pyarrow-based smoke-test CLI for the Arrow Flight SQL surface. Supports model selection via the `database` header (`--model/-m`), catalog discovery (`--list` hits REST `/v1/models`), and demonstrates all three Flight modes (semantic / catalog / governance rejects). Mirrors the `psql` convention — the CLI shares its name with the language it runs.
- **Reference endpoints for LLM / MCP / BI tool discovery.** New `GET /v1/reference` index lists all available references; `GET /v1/reference/obml` and `GET /v1/reference/obsql` return agent-friendly markdown grammar references; `GET /v1/reference/schemas/{name}` (`obml | query`) returns JSON Schema with content-type `application/schema+json`. New `obsql_reference.py` module mirrors `obml_reference.py` with virtual-table shape, three SELECT forms, MEASURE() + aggregate-wrap matching, raw mode, catalog mode, hard-rejection error code table, and worked examples.
- **Flight extension result-cache wiring.** Flight semantic queries now participate in the same freshness-driven result cache as REST `/query/execute`, with matching keys and TTL semantics. `OBFlightServer.__init__` accepts `cache` + `cache_config`; `_prepare_sql` now returns a 6-tuple including a `cache_meta` dict; `_execute_sql` checks the cache pre-execute (lookup → decode parquet → wrap in RecordBatchStream) and writes back post-execute. All cache errors are best-effort — execution never fails because of cache I/O. OBML YAML queries also cache (free with SQL-hashed keys). A dashboard tile rendered via OBSQL in DBeaver and via OBML YAML in an MCP agent will hit the same entry.
- **Deterministic caching — auto-order on `LIMIT` + non-deterministic SQL bypass.** Two cache-correctness holes closed: `LIMIT N` without `ORDER BY` (engines return any N rows; cache freezes one slice forever) and SQL containing `RAND()` / `NOW()` / `CURRENT_DATE` / `TABLESAMPLE` (same SQL, different answer per call — `WHERE date >= CURRENT_DATE - 7` cached today serves stale "last week" forever). When `limit` is set with no explicit `order_by`, the planner appends `ORDER BY <all dims>` (aggregate-only queries skip — single-row results are already deterministic). New `cache/determinism.py::is_nondeterministic_sql(sql)` walks the compiled SQL for known random / clock / sample patterns after stripping string literals and quoted identifiers. New `NoCacheReason.NON_DETERMINISTIC_SQL` so responses surface `ttl_source = "no_cache:non_deterministic_sql"`.
- **Flight observability — full OBSQL request + compiled SQL logged on Flight + REST paths.** Every compile path now logs two `INFO` lines: the OBSQL request (preserved newlines, human-readable) and the compiled SQL. QueryObject-shaped REST endpoints (`/query/sql`, `/query/execute`) log the input as pretty-printed JSON. Same for OBML YAML on the Flight side. Replaces the previous 200-char truncation that hid auto-generated `JOIN` / `GROUP BY`.
- **Flight catalog metadata views.** Per-category label views for BI column pickers — `dimensions` / `measures` / `metrics` (no leading underscore, look like regular catalog objects) with one column per dim/measure/metric label typed by `result_type`. Queries `SELECT "X" FROM dimensions` route to semantic mode. Introspection schemas move to `_dimensions_metadata` / `_measures_metadata` / `_metrics_metadata` (underscore prefix follows Postgres / DBeaver "internal" convention). `_metrics_metadata` surfaces `time_dimension` / `window` / `grain_to_date` / `time_grain` so cumulative and PoP metrics no longer require cross-referencing `_dimensions_metadata` to decode "Rolling 3m Sales".
- **Commerce battery across 8 dialects + persistent cloud fixtures.** Shared commerce parquet fixtures (`tests/fixtures/commerce/`) and battery runner (`tests/integration/_commerce.py`), regenerated from the demo DuckDB. New live integration tests for BigQuery, Databricks, Snowflake with skip-if-exists data caching (rowcount-vs-parquet check); `BIGQUERY_RESEED` / `DATABRICKS_RESEED` / `SNOWFLAKE_RESEED` env vars force reload. ClickHouse / MySQL / Postgres tests migrated to the shared battery. New pytest markers `snowflake` / `bigquery` / `databricks`. Real-DB ROLLUP/CUBE tests across all 4 vendors (Postgres / ClickHouse / MySQL / DuckDB).

### Changed

- **BREAKING: hard-block raw SQL + DDL/DML across the Flight surface.** OBSL is a semantic layer, not a JDBC proxy — make that the design, not a configuration choice. Removed env flags `FLIGHT_ALLOW_RAW_SQL` and `FLIGHT_ALLOW_DATA_OBJECT_SQL`. There are no longer any flags that allow arbitrary SQL through to the warehouse. The only SQL that reaches the warehouse is produced by the OBSL compiler from a `QueryObject` (REST `/query/execute`) or from OBSQL. New mode `catalog` answers `SHOW TABLES` / `DESCRIBE` / `information_schema.*` / `pg_catalog.*` / `_dimensions` / `_measures` / `_metrics` / scalar probes (`SELECT 1`, `SELECT version()`, `current_database()`) from the model in-process via `_handle_catalog_sql()` returning a `pa.Table` — never touches the warehouse, so BI tool discovery (Tableau, Power BI, DBeaver) works without granting raw warehouse access. New error codes `RAW_SQL_REJECTED` (replaces `RAW_SQL_DISABLED`, no flag to bypass) and `WRITE_OPERATION_REJECTED` (top-of-prepare-sql guard rejects INSERT / UPDATE / DELETE / DROP / CREATE / ALTER / TRUNCATE / MERGE / GRANT / REVOKE / COMMIT / ROLLBACK before any other classification, on every path).
- **BREAKING: `MODEL_FILE` is deprecated** — preserved as an alias for `MODEL_FILES` with one entry, deprecation warning logged at startup, **scheduled for removal in v2.5.0**. `MODEL_FILE` and `MODEL_FILES` are mutually exclusive — startup error when both are set. Existing `MODEL_FILE` deployments work unchanged via the legacy `__default__` session path.
- **BREAKING: result cache `KEY_VERSION` bumped to 2** — `build_cache_key` now hashes on `session_id + model_id + dialect + compiled SQL` instead of the QueryObject JSON. The compiler is deterministic so two callers reaching the same compiled SQL — via OBSQL, QueryObject, or OBML YAML — share a cache key. Trade-off: drops the QueryObject normalization layer (sort dim lists, normalize `IN` value order); the upgrade invalidates pre-v2.4.0 cache entries.
- **OBSQL-shaped error envelopes everywhere.** REST `/query/plan`, `/query/execute`, `/oneshot/batch` all catch `UnsupportedAggregationError` and the new `UnsupportedGroupingError` and return 422 with a structured warning instead of 500.
- **Drivers and UI documentation refreshed** across `docs/comparison/{dbt,lookml,malloy}.md`, `docs/guide/drivers.md` (DBeaver section now leads with OBSQL), and the in-tree `obsql_reference.py` for the no-FROM mode + governance + multi-model `database` selector.
- **Flight `CommandGetSqlInfo` populated.** DBeaver / Tableau Flight no longer show `Server: ?` — the response now carries the 4 standard SqlInfo entries (server name, server version, arrow version, read-only flag) over the spec-mandated dense-union schema.
- **MySQL `ORDER BY ... NULLS FIRST/LAST` only emits the `IS NULL` workaround when it disagrees with MySQL's default.** MySQL orders NULLs as the smallest value (`ASC` puts NULLs first; `DESC` puts them last). The two matching-default cases now compile to plain `ORDER BY <dim> ASC/DESC` (the common path on the new ROLLUP/CUBE auto-order); only the two non-matching cases emit the extra `<expr> IS NULL` sort key. Class-level docstring on `MySQLDialect` documents the two SQL-standard deviations.
- **Mypy strict cleanup across `orionbelt-semantic-layer` and `ob-flight-extension`.** Both projects now type-check clean (92 + 8 files). Added the PEP 561 `py.typed` marker to `ob-flight-extension` so callers see typed imports instead of `Skipping analyzing "ob_flight.*"` warnings.

### Fixed

- **Cache key `_normalize_sql` collapsed whitespace inside quoted regions** — `name = 'A  B'` and `name = 'A B'` (or `"Order  Id"` vs `"Order Id"`, or backtick variants) produced the same cache key and served each other's rows. Now skips quoted regions (single-quote literals, double-quote ANSI identifiers, backtick MySQL/BQ/Databricks identifiers) when normalizing.
- **`SessionManager._is_expired()` ignored `session.protected`** — `get_store()` / `get_session()` would delete an admin-loaded (`MODEL_FILES`) session on the first access past TTL even though `_purge_expired` correctly skipped it. Returns `False` early for protected sessions.
- **Flight `_cache_put_table` wrote bare parquet** — REST writes via `parquet_codec.encode` (sql/dialect/columns in Parquet key/value metadata). On a shared cache key, a REST reader of a Flight entry decoded `sql=""`, `dialect=""`, `columns=[]`. Flight now writes the same envelope so the cache namespace is bidirectionally consistent.
- **Flight cache column metadata key mismatch** — `_cache_put_table` wrote column metadata as `data_type` but REST's decoder reads `type`. Flight-written cache hits decoded sql/dialect/columns/rows correctly but numeric and datetime columns came back as `type="string"`. Encoded under `type` with a small Arrow→OBSL type-hint mapper.
- **OBSQL trailing `WITH ROLLUP/CUBE` was silently dropped in raw-mode queries.** The trailing modifier is stripped from the raw SQL text *before* parsing, so by the time `_build_raw_mode_query` checks `ast.args.get("group")`, the grouping was gone. Now threaded through as `forced_grouping` and rejected with `UNSUPPORTED_SQL_FEATURE`, symmetric to the existing `GROUP BY` rejection.
- **Flight `CommandGetTables/Columns` ignored `table_name_filter_pattern`** — DBeaver's per-node `CommandGetColumns` requests for `_measures` / `_dimensions` returned every row, so DBeaver attributed all rows to the expanded node and dimensions/measures/metrics appeared mixed under each metadata view. New `parse_table_filter` / `matches_filter` helpers (parse field 3 from the protobuf body; SQL LIKE-style `%` and `_` wildcards) thread the parsed filter through.
- **Flight `CommandGetTables/Columns` ignored protobuf field 1 (catalog)** — selecting a catalog through the command body still got the auto-resolved model's metadata in multi-model mode. New `parse_catalog_filter` routes the metadata build to the matching session/model; unknown catalog returns empty metadata (no silent fallback).
- **Flight `build_tables_table` / `build_columns_table` hard-coded `catalog_name="orionbelt"`** so every model's tables collapsed under the single catalog even after `build_catalogs_table` started reporting one catalog per loaded model. Now reads `_ob_model_id` (stamped by `_stamp_model`) and emits per-model catalog names.
- **MySQL dialect rejected `compile_group_by(grouping="cube")` with bare `NotImplementedError`** which surfaced as a 500 via REST. New domain `UnsupportedGroupingError(dialect, grouping)` mirrors the existing `UnsupportedAggregationError`; 422 catch handlers added at every REST/oneshot call site that already catches `UnsupportedAggregationError`.
- **OBSQL trailing line / block / `#` comments slipped past the trailing-modifier regex** — DBeaver's autogenerated SQL like `SELECT … FROM t WITH CUBE -- ORDER BY 1 NULLS FIRST` no longer trips through to RAW_SQL_REJECTED. Comments inside string literals and quoted identifiers preserved by a small state-machine pass; block comments collapse to a single space so `a/*x*/b` doesn't fuse into `ab`. Coverage for `--` (universal), `#` (MySQL / MariaDB / BigQuery), and `/* block */` (universal).
- **`GROUPING()` argument is the group-by expression, not the SELECT alias.** Star planner emitted `GROUPING("Client Name")` referencing the SELECT alias; Postgres / Snowflake / BigQuery rejected this. Now stashes the per-dimension group-by expression by alias so `GROUPING()` uses the same expression in `GROUP BY ROLLUP(...)`. Time-grained dimensions get their dialect-wrapped (`DATE_TRUNC(...)`) form propagated automatically.
- **CFL own-leg measure cast aligned with sibling NULL padding** — resolves ClickHouse `UNION ALL` Variant typing errors. Databricks dialect overrides `_ABSTRACT_TYPE_MAP` so CFL NULL-padding renders `STRING` (Databricks rejects bare `VARCHAR` without a length).
- **UI execute button + dialect refresh on page load, not process startup.** The startup-time `_fetch_settings()` call has a 5s timeout and silently returns `{}` on failure — common on Cloud Run cold starts. Decision moves from per-process to per-session by chaining `_refresh_query_exec_visibility` after `_restore` in `demo.load()`.
- **Flight catalog SQL precomputes the result `pa.Table` at `get_flight_info` and `do_action` (prepared-statement) time** so JDBC clients see the actual table schema instead of a placeholder `pa.schema([pa.field("result", pa.utf8())])`. DBeaver's SQL editor uses the prepared-statement path almost exclusively — that's why `SELECT * FROM _measures_metadata` showed one column called `result` with the measure names in it.
- **Ctrl-C left port 8815 bound** — `FlightServerBase.shutdown()` returns but the gRPC C++ thread can keep the socket. Added `server.wait()` so `serve()` actually drains before declaring the server stopped.
- **Flight `SHOW TABLES` over the text OBSQL path rendered the binary `table_schema` column as raw bytes in pandas output.** The binary column is needed for the protobuf `CommandGetTables` path (JDBC clients decode it) but is meaningless for text-mode display. `_catalog_tables_table` now strips that column. Also adds a raw-text fast-path so `SHOW` / `DESCRIBE` / `DESC` / `USE` / `SET` never reach sqlglot (silences the `"'SHOW tables' contains unsupported syntax"` warning).
- **Stale `allow_data_object_sql` kwarg from startup path.** The kwarg was removed from `OBFlightServer.__init__` in the hard-block-raw-SQL commit but `startup.py` still passed it, causing FastAPI lifespan to fail at boot with `TypeError: OBFlightServer.__init__() got an unexpected keyword argument 'allow_data_object_sql'`. Removed.
- **Vendor-execution drift snapshot refresh** for Databricks CFL after the `STRING` type-map fix (snapshot was missed in the 8-dialect commerce battery commit).

## [2.3.1] - 2026-05-11

### Fixed

- **MySQL `CAST(string-typed expr AS string)` no longer emits invalid / silently-truncating SQL.** `dialect/mysql.py::_compile_cast` previously rewrote any `VARCHAR[(N)]` cast target to `CHAR[(N)]` without inspecting `N`. For OBML's unbounded `string` type — which `_OBML_SIMPLE_TYPE_MAP` resolves to `VARCHAR(65535)` — that produced `CAST(x AS CHAR(65535))`, exceeding CHAR's 255-character column limit; the abstract `string`-via-`_ABSTRACT_TYPE_MAP` path produced `CAST(x AS CHAR(255))`, silently truncating any longer value. The cast rewriter is now length-aware: lengths above 255 collapse to plain `CHAR` so MySQL picks a safe internal width without truncation; lengths ≤ 255 are preserved.
- **Vendor-execution drift normaliser keeps distinct string keys distinct.** `tests/integration/drift/vendor_exec/test_vendor_exec.py::_normalize_value` ran every string through `Decimal()` → `float():.11g` to keep YAML-stored Decimal goldens (`"100.50"`) symmetric with live vendor Decimals. That coercion also collapsed zero-padded IDs (`"00123"` → `"123"`), exponent-form strings (`"1e3"` → `"1000"`), and `"0000"` → `"0"`, which would have let a cross-vendor key-handling regression silently pass row-set equality. The coercion is now restricted to canonical `Decimal.__str__` form (no leading zeros, no scientific notation) so legitimate decimal goldens still normalise but string IDs stay distinct.
- **`test_all_pointers_collect_in_pytest` no longer requires `uv` on PATH.** The Tier 2 metadata gate at `tests/integration/drift/test_snapshot_metadata.py` shelled out to `uv run pytest --collect-only ...`, failing for infrastructure reasons in any environment that runs the test suite without `uv` installed (CI containers, plain virtualenvs). It now uses `sys.executable -m pytest`.

## [2.3.0] - 2026-05-10

### Added

- **Two-tier integration test framework.** `tests/integration/correctness/` ratifies query results via independent computation paths (aggregation invariance, hierarchical rollup, hand-SQL reference, pandas baseline, metric algebra, CFL split, filter additivity); `tests/integration/drift/` snapshots compiled SQL + canonical-sorted result rows per query (DuckDB exec + 8-dialect compile-only + a metadata gate that validates every snapshot's `last_verified_by` pointer is a real, collectable pytest test). Pure-OBML query files under `tests/integration/correctness/queries/` plus a sidecar `corpus.yaml` manifest keep the schema-faithful query bodies separated from test-rig metadata. Operator manual at `docs/guide/correctness-and-drift-tests.md`; dev quick-reference at `tests/integration/README.md`.
- **Phase A vendor-execution sweep** — every corpus query × every available local engine (DuckDB, Postgres 16, MySQL 8, ClickHouse) via testcontainers, gated by `pytest -m docker`. 60 / 60 pass, no xfails. Cross-vendor row normalisation: tz-naive datetime, midnight-→-date collapse, numeric values rounded via `float()` to 11 significant digits to absorb cross-engine ULP drift while preserving money sums up to ~$100 B at 2-dp precision.

### Changed

- **Cumulative metrics now respect their declared `dataType`.** `compiler/cumulative_wrap.py` casts the inner `cumulative_base` projection and the outer windowed aggregate to the metric's declared decimal type. Pre-fix, `Cumulative Sales` declared `decimal(18, 2)` returned DOUBLE values with last-bit drift like `281222.37999999995`; now it returns exact 2-dp Decimals.
- **HAVING auto-includes referenced measures.** `compiler/resolution.py` pre-scans every HAVING filter (recursively across `QueryFilterGroup`) and ensures every referenced measure / metric ends up in `resolved.measures` *before* base-object selection. A HAVING-only measure from a different fact correctly flips the planner into CFL mode. The auto-included measure is dropped from the final SELECT so the user only sees columns they asked for.
- **Demo metric `Rolling 30 Day Sales` declares `decimal(18, 0)`** (was `decimal(18, 2)`). A 30-day rolling AVG is a smoothed metric where cent precision is noise — and the .5-cent boundary diverges across engines (DuckDB HALF_UP vs Postgres / MySQL HALF_EVEN vs ClickHouse engine-internal). Whole-dollar precision is engine-stable.

### Fixed

- **CFL NULL-pad type matches the source column for COUNT-style aggregates.** Inner-leg padding for `count` / `count_distinct` measures now uses the *raw column*'s abstract type (e.g. VARCHAR for `complid`) instead of the outer aggregate's declared bigint. Strict-typed engines (Postgres / MySQL / ClickHouse) accept the resulting `UNION ALL`; numeric SUM/AVG aggregates keep the existing outer-CAST-target alignment so the ClickHouse `Decimal` + `Float64` Variant trap stays closed.
- **MySQL `CAST` accepts text values.** `dialect/mysql.py::_compile_cast` translates `VARCHAR[(N)]` → `CHAR[(N)]` at cast time; MySQL's CAST type vocabulary excludes VARCHAR but DDL paths still use the wider type.
- **MySQL ratio precision.** `dialect/mysql.py::render_decimal_division_sql` widens both operands to `DECIMAL(38, 14)` so `div_precision_increment`'s default 4 extra fractional digits doesn't truncate ratios to 6 dp.
- **ClickHouse Decimal division precision.** `_compile_binary_op` and `render_decimal_division_sql` widen `/` operands to `Nullable(Decimal(38, 14))`. Without this, `Decimal(18, 2) / Decimal(18, 2) = Decimal(18, 2)` truncated `Return Rate` to `0.03` instead of `0.0365`.
- **ClickHouse Decimal CAST rounds, not truncates.** `_compile_cast` now wraps the inner expression in `round(x, S)` before `CAST(... AS Decimal(P, S))`. ClickHouse's CAST silently truncated (`CAST(4323.99 AS Decimal(18, 0)) → 4323`), diverging from DuckDB / Postgres / MySQL whose decimal CAST rounds.
- **CI lint job runs cleanly.** `pyproject.toml` now suppresses `pyarrow` `import-untyped` errors via a per-module mypy override (mirroring the existing pandas one). Removed two pre-existing ruff-format drifts (`parser/validator.py`, `tests/unit/test_parser.py`) that were failing CI on `main`.

## [2.2.1] - 2026-05-09

### Changed

- **Bundled demo model rewritten with business-friendly names.** `examples/orionbelt_1_commerce.yaml` now uses spaced YAML keys for every dataObject, column, dimension, measure, and metric. Common base measures use short business names (`Total Sales`, `Total Returns`, `Total Purchases`, `Total Shipments`) — the `Amount` suffix is dropped for amount-typed measures since amounts are the default; quantity/count variants keep their explicit suffixes. Derived metrics follow suit (`Return Rate`, `Average Sale`, `Cumulative Sales`, `MTD Sales`). Physical column names live unchanged in the `code:` fields, so the bundled DuckDB seed and the demo SQL are unaffected. Generic dimensions (`Client Name`, `Country Name`, …) coexist with explicit role-playing variants (`Sales Client Name` via Sales, `Complaint Client Name` via Client Complaints, etc.) so casual queries get business-named dropdowns and cross-fact queries can pin the join path with `via:` to silence `MISSING_VIA` warnings.
- **Demo model pins `settings.defaultDialect: duckdb`.** The bundled image runs against a baked-in DuckDB seed; the dialect is now declared in the model so the UI dropdown auto-selects DuckDB on load instead of falling back to its alphabetical default.
- **Demo model declares `refresh: { mode: static }` on every dataObject.** The bundled DuckDB seed is built into the image and never changes between deploys, so the freshness-driven result cache now uses `CACHE_MAX_TTL_SECONDS` (default 86400 = 1 day) as the effective TTL instead of falling back to the unknown-freshness 300s default. Also sidesteps the `tracked_physical_tables` / `entry_count: 0` divergence when entries land on Cloud Run's per-instance tmpfs and don't survive cold starts.
- **Demo model carries proper data types and display formats.** Adds `settings.defaultNumericDataType: "decimal(18, 2)"` and `settings.defaultTimezone: "Europe/Zagreb"`. Amount-typed measures use `dataType: "decimal(18, 2)"` and `format: "#,##0.00"`; counts use `bigint` + `"#,##0"`; ratio metrics use `decimal(18, 4)` + the auto-percent format `"#,##0.0%"` (the formatter multiplies by 100 at display time, so the stored value stays a raw ratio — `Return Rate = Total Returns / Total Sales` renders as `"12.3%"`).
- **UI: ``Execute Query`` snaps the SQL Dialect dropdown to the API's effective execution dialect** (from `/v1/settings.dialect.effective`) before executing. Lets users explore Postgres/Snowflake/etc. SQL via the Compile preview without accidentally sending a non-DuckDB statement to the underlying database.

### Fixed

- **Result cache silently no-op.** Every `cache.get` / `cache.set` against the file backend's DuckDB meta DB raised `Invalid Input Error: Required module 'pytz' failed to import` — DuckDB's Python binding lazily imports pytz when binding tz-aware datetimes (TIMESTAMPTZ columns), and the WARNING-level failure path returns a miss without surfacing the error. Cache stats showed `entry_count: 0` despite `tracked_physical_tables` accumulating on every query. Pin `pytz>=2024.1` as a runtime dep so DuckDB can persist cache entries.
- **ER diagram label clipping.** Per-attribute right-edge clipping in dense entities is gone: previously a CSS rule injected a 14px font on top of Mermaid's default-12px column-width measurement, so every row's text overflowed its measured rectangle. The override is removed; we now trust Mermaid's measure-equals-render contract.
- **ER diagram attribute names no longer mangle spaces into underscores.** Identifiers are camelCased from the column label (`Sales ID` → `SalesID`) and the spaced business label is emitted as the attribute's quoted comment column, so the diagram shows the human-readable name alongside the structural identifier. Entity names containing spaces (`Client Complaints`, `Account Balances`) are double-quoted so Mermaid renders them verbatim.
- **ER diagram join labels keep their business names** (e.g. `"Sales Client"`) instead of being lower-cased and underscored.

## [2.2.0] - 2026-05-05

### Added

- **`POST /v1/oneshot/batch` — one-shot batch endpoint.** Loads (or references) an OBML model and runs N independent queries against it in a single round trip. Designed for agent workflows where one model + multiple sub-questions is the dominant pattern. Supports `model_yaml` (transient or persisted via `persist_model: true`) or `model_id` (reference an already-loaded model). Queries run concurrently under an `asyncio.Semaphore` capped by `ONESHOT_BATCH_MAX_PARALLELISM` (default 8). Per-query overrides for `dialect` and `execute`. Stable result ordering keyed by caller-provided `id`. Partial failure is the default — each result carries its own `status` (`ok` / `error` / `cancelled`) and `error` envelope. `fail_fast: true` cancels remaining queries on first failure. Whole-batch and per-query timeouts are honored. Server limits surface via `GET /v1/settings.oneshot_batch`. See `design/PLAN_oneshot_batch.md`.
- **Model load deduplication.** `POST /v1/sessions/{sid}/models` and `POST /v1/oneshot/batch` now reuse an existing `model_id` when the same OBML bytes (whitespace-normalized) are already loaded in the session. The response includes a new `model_load` field (`"fresh"` | `"reused"` | `"referenced"` for batch). Skips parsing, validation, and OBSL graph generation on the dedup path. Disable with `dedup: false`. Index is per-session (session isolation preserved) and is cleared automatically on model removal. See `design/PLAN_model_load_dedup.md`.
- **Freshness-driven result cache (file backend, off by default).** New `CACHE_BACKEND=file` mode persists `query/execute` results in `{CACHE_DIR}/meta.duckdb` + Parquet sidecars. TTL is derived from the `freshness:` contract on each touched physical `dataObject` — the *minimum* contribution wins, and an ETL `POST /v1/heartbeat` invalidates every cached query that depends on the refreshed table. Cached `query/execute` responses gain `cached`, `cached_at`, `ttl_seconds`, `ttl_source`, `ttl_limiting_table`, and `physical_tables` fields. Per-query TTL caps via `caller_capped`; unknown-freshness queries skip the cache by default (`CACHE_UNKNOWN_FRESHNESS_POLICY=no_cache`) or fall back to a default TTL when explicitly enabled. Fails closed: any cache error degrades to a normal warehouse execution. See `docs/guide/result-cache.md` and `design/PLAN_freshness_driven_cache.md`.
- **`refresh:` block on dataObjects (OBML + OSI).** New per-dataObject freshness contract with `mode: static | scheduled | heartbeat | unknown`, plus mode-specific fields (`schedule:` cron, `nextRefreshAt:`, `maxStaleness:`, `tolerance:`). Roundtrips through OSI via `osi-obml/osi_obml_converter.py` (custom_extensions) and is declared in the OBSL ontology (`ontology/obsl.ttl`). Surfaced in `GET /v1/settings` and the Settings UI tab.
- **`GET /v1/cache/stats`, `POST /v1/cache/sweep`, `POST /v1/cache/clear`.** Stats exposes backend, entry count, total bytes, hit/miss counters, hit rate, oldest entry, next sweep, tracked physical tables, and heartbeat invalidations. Sweep runs one TTL + LRU capacity eviction pass on demand (returns `ttl_evicted` / `capacity_evicted`). Clear drops every entry regardless of TTL or dependencies (counters preserved as historical telemetry).
- **`POST /v1/heartbeat`.** ETL endpoint invalidating every cached query whose dependency set includes the refreshed `database.schema.table`. Bearer-auth via `HEARTBEAT_AUTH_TOKEN` (route returns 404 when unset). Response lists `invalidated_cache_entries` and `affected_data_objects`.
- **UI Cache panel.** Settings tab now shows a side-by-side **API Settings** + **Cache Stats** view with **Refresh Cache Stats**, **Sweep Cache now**, and **Clear Cache** buttons. Auto-loads on tab open. Query Results tab annotates each execution with `(cache)` or `(database)` next to `execution_time_ms`.

### Changed

- **`execution_time_ms` on cache hits** now reports the actual cache fetch + decode wall time, not the original DB run time persisted in the Parquet sidecar. Combined with the `cached: true` flag, this gives realistic "from cache" durations on the wire. The original DB timing remains on disk for forensic inspection.
- **`CACHE_SWEEP_INTERVAL_SECONDS` default raised from 900s (15 min) to 86400s (1 day).** Lazy TTL on read keeps user-facing freshness correct; the periodic sweeper only matters for reclaiming disk from entries that expire without being read again, so every 15 min was unnecessarily aggressive.
- **Persisted cache state (`meta.duckdb` + `results/`) is wiped on every server startup.** Structural reason: `model_id` is regenerated as a fresh UUID on every model load, so any entries from a previous process run reference model_ids that no longer exist — orphans by construction. Starting empty avoids accumulating dead state between restarts.
- **Cache stats output now uses UTC for both `oldest_entry` and `next_sweep_at`.** Previously `oldest_entry` rendered in the DuckDB session timezone (host local), creating a TZ mismatch with `next_sweep_at` (always UTC). Both are now ISO 8601 with `+00:00`.
- **Startup logging splits the cache config block into one line per setting** so each field is easy to grep without parsing one long line.

### Fixed

- **Gradio UI mounted in `create_app()` always captured `query_execute=False`** because `is_query_execute_enabled()` reads a deps.py global that's only populated inside the `lifespan` hook (which runs *after* the UI is mounted). UI settings now resolve directly from `Settings`, mirroring the same logic the lifespan uses, so the **Execute Query** button appears as soon as `QUERY_EXECUTE=true` is set.
- **Query Results dataframe no longer renders Gradio's default `1, 2, 3` placeholder columns** before the first execution. The dataframe is hidden until the post-execute visibility chain flips it on.

### Settings

- New env vars: `ONESHOT_BATCH_MAX_QUERIES` (50), `ONESHOT_BATCH_MAX_PARALLELISM` (8), `ONESHOT_BATCH_DEFAULT_TIMEOUT_MS` (30000), `ONESHOT_BATCH_BATCH_TIMEOUT_MS` (120000). All exposed in `GET /v1/settings.oneshot_batch`.
- New cache env vars: `CACHE_BACKEND` (`noop` default), `CACHE_DIR`, `CACHE_MIN_TTL_SECONDS` (5), `CACHE_MAX_TTL_SECONDS` (86400), `CACHE_MAX_VALUE_BYTES` (10 MB), `CACHE_MAX_DISK_BYTES` (5 GB), `CACHE_SWEEP_INTERVAL_SECONDS` (86400), `CACHE_UNKNOWN_FRESHNESS_POLICY` (`no_cache`), `CACHE_UNKNOWN_FRESHNESS_DEFAULT_TTL` (300), `HEARTBEAT_AUTH_TOKEN`.

### Behavior change

- Identical OBML loads in the same session now return the same `model_id` instead of minting a new one each time. Disable per-call with `dedup: false`.
- When the cache is enabled (`CACHE_BACKEND=file`), `query/execute` calls may serve cached results. Distinguish via the new `cached` field on the response. The cache fails closed on any error.

## [2.1.4] - 2026-05-03

### Fixed

- **`timeGrain` on a non-temporal column is now rejected at validation time** instead of producing a runtime SQL error. Previously a dimension like `{ column: YearMonth, resultType: string, timeGrain: month }` passed validation but compiled to `date_trunc('month', "Calendar"."ym")`, which Postgres (and other strict dialects) reject with `function date_trunc(unknown, text) does not exist`. The new check inspects the underlying `DataObject.columns[col].abstractType` and emits `TIME_GRAIN_ON_NON_TEMPORAL` unless the type is `date`, `timestamp`, or `timestamp_tz`. Error message includes a remediation hint (drop `timeGrain`, fix the column's `abstractType`, or define a computed column with `to_date()`). Particularly relevant for LLM-generated models, which were the most common source of this mistake.

### Documentation

- `docs/guide/model-format.md` and the `OBML_REFERENCE` resource now document the `timeGrain` constraint inline so LLMs generating OBML have the rule in their prompt context.

## [2.1.3] - 2026-04-30

### Fixed

- **Settings tab `timezone.now` showed UTC even after the v2.1.2 overlay set `timezone.effective: Europe/Berlin`.** The API had computed `now` server-side against its own (no-model) `effective` (UTC), and the v2.1.2 overlay only updated `effective` — leaving `now` stale. The overlay now also recomputes `now` as the current wall clock in the overlaid TZ when the API had no loaded model, so `now` and `effective` agree.

## [2.1.2] - 2026-04-30

### Fixed

- **Settings tab in the Gradio UI showed stale `effective` values** for `timezone` and `dialect` when the user had a model YAML pasted/loaded but had not yet compiled. The UI's `_fetch_settings_yaml` overlay only populated `tz["effective"]` and `dl["effective"]` when the API response was *missing* those keys — but the API always returns them (with no-model fallbacks: `UTC` / `DB_VENDOR`). The result: the overlay correctly added `model_settings` and `timezone.model` from the local YAML, but `effective` stayed at the API's no-model fallback. Now the overlay detects "API has no loaded model" by checking whether `model_settings` was returned by the API, and when absent, fully overlays the local YAML's TZ and dialect — including `effective` — so the Settings tab mirrors what compiling will produce.

## [2.1.1] - 2026-04-30

### Fixed

- **`/v1/settings.timezone.effective` falls back to UTC instead of the model's `defaultTimezone` on slim Linux Docker images.** Root cause: `python:3.12-slim` has no `/usr/share/zoneinfo`, so `ZoneInfo("Europe/Berlin")` (or any IANA name) raises `ZoneInfoNotFoundError`. The resolver caught the exception, walked the fallback chain (host TZ on Cloud Run is UTC and skipped), and ended at `UTC`. Now `tzdata>=2025.1` is a runtime dependency of `orionbelt-semantic-layer`, and both `Dockerfile` / `Dockerfile.ui` also `apt-get install tzdata` for defense in depth.

### Changed

- `examples/sem-layer.obml.yml` (the UI's default preloaded model) now declares `settings.defaultDialect: postgres`. Aligns the UI dialect dropdown and `/v1/settings.dialect.effective` for users loading the bundled demo — previously they could diverge when `DB_VENDOR` differed from the UI's hardcoded `postgres` fallback.

## [2.1.0] - 2026-04-30

### Added

- **Column-level computed columns on `DataObjectColumn`.** A column with `expression:` instead of `code:` defines a computed column inlined wherever the column is referenced. Single-brace `{Column}` placeholders refer to *sibling columns of the same data object*. Distinct from measure-level expressions (which use `{[DataObject].[Column]}` and can cross data objects). Example: `Year-Month: expression: "({Year} * 100 + {Month of Year})"`. Constraints: mutually exclusive with `code`, no recursive resolution. ORDER BY on a computed column is correctly emitted as the inlined expression.
- **Regex, blank, and string-length filter operators** in `QueryFilter`. Per-dialect regex SQL: Postgres `~`/`!~`, DuckDB `regexp_matches`, ClickHouse `match`, BigQuery `REGEXP_CONTAINS`, MySQL `REGEXP`, Databricks `RLIKE`, Snowflake/Dremio `REGEXP_LIKE`. New operators:
  - `regex` / `notregex` — match against a regular-expression pattern (string value)
  - `blank` / `notblank` — `(col IS NULL OR TRIM(col) = '')` and its inverse, for whitespace-aware empty checks on free-text columns
  - `length_eq` / `length_gt` / `length_lt` — `LENGTH(col) {= | > | <} N` (integer value), for fixed-width / padded-code filtering
- **`settings.defaultDialect` on the OBML model.** Optional top-level `settings.defaultDialect` lets a model pin its preferred SQL dialect so callers can omit `dialect` on every `/v1/query/sql` and `/v1/query/execute` request. Resolution chain at request time: explicit `dialect` → `settings.defaultDialect` → `DB_VENDOR` env → `postgres`. Validated against the 8 registered dialects at parse time. The session and shortcut endpoints both honor it; `dialect` on the request body is now `Optional`.
- **`/v1/query/execute` formatted output.** Four new query parameters on both the session-scoped and shortcut execute endpoints:
  - `format=tsv` returns `text/tab-separated-values` with RFC 4180-style quoting for cells containing tab/newline/CR/double-quote. Implies `format_values=true`.
  - `format_values=true` renders numeric cells in the JSON response as locale-aware display strings using each column's `format` pattern (matches the Gradio UI exactly).
  - `locale` (BCP-47) overrides the default locale for thousand/decimal separators; falls back to the new `DEFAULT_LOCALE` env when omitted.
  - `timezone` (IANA TZ) overrides the model's `default_timezone` per-request.
- **Shared formatting module** `service/value_formatting.py`. The UI and the API now use the same `format_number` / `parse_number_format` / `locale_separators` / `format_row` / `to_tsv` helpers, so what you see in Gradio is exactly what `?format_values=true` returns.
- **`DEFAULT_LOCALE` env / `default_locale` setting** (default empty → en-style separators).
- **Raw query mode (`select.fields`).** Returns un-aggregated rows by projecting physical columns directly. Mutually exclusive with `dimensions`/`measures`/`having`/`dimensionsExclude`. New `select.distinct` flag emits `SELECT DISTINCT`. Field references must be qualified `DataObject.Column`. Single-fact queries compile to a flat star-schema-style SELECT; fanout protection still applies (reversed many-to-one joins are rejected).
- **Raw CFL — multi-fact `UNION ALL` with NULL padding.** When `select.fields` references columns from independent fact tables, the planner emits one leg per leg-root fact, with typed `CAST(NULL AS <type>)` for fields not reachable from a given leg. Outer wrapper applies `DISTINCT` (when set), `ORDER BY` (remapped to field aliases), and `LIMIT`. New error codes: `RAW_FIELD_INVALID_REF`, `RAW_FIELD_UNKNOWN_OBJECT`, `RAW_FIELD_UNKNOWN_COLUMN`.
- **`UNION ALL BY NAME` optimization for raw CFL on DuckDB and Snowflake.** On dialects that support it, per-leg NULL padding is skipped — each leg only emits the columns it has, and the database fills missing columns automatically. Output rows are identical; SQL is shorter and more readable.
- **Public-doc gating flags** (`EXPOSE_API_DOCS`, `EXPOSE_OPENAPI_SCHEMA`). Default `true` to preserve the public-demo behaviour. Set `EXPOSE_API_DOCS=false` to hide `/docs` and `/redoc`; `EXPOSE_OPENAPI_SCHEMA` toggles `/openapi.json` independently. The Dockerfile and `deploy-gcloud.sh` pin both to `true` explicitly so the demo stays exposed even if defaults flip later.
- **`/v1/settings` now returns `version` and `api_version`.** Clients can negotiate features from a single call instead of also hitting `/health`.
- **`/v1/settings` exposes the loaded model's `settings:` block plus the timezone and dialect resolution chains.** New optional sub-objects on the response:
  - `model_settings` — every key from the model's `settings:` block (`defaultTimezone`, `defaultDialect`, `overrideDatabaseTimezone`, `defaultNumericDataType`), in OBML camelCase to mirror the YAML.
  - `timezone` — `{model, host, database, effective, override_database_timezone, now, utc, database_detected, database_raw}`. Always present so clients can show the wall clock even without a loaded model. The chain matches what `db_executor.resolve_timezone()` does at execute time: when `overrideDatabaseTimezone` is true the model wins; otherwise the cached DB session timezone (if any) takes priority. **The endpoint now warms the DB session-TZ cache on first hit when a model is bound and `query_execute` is enabled** — so the report runner / UI sees the correct `effective` immediately, instead of falling through to the model TZ until the first query happens to populate the cache. `database_detected` reports whether the probe has run, `database_raw` exposes the cached value for diagnostics. `now` is the current wall-clock time in the effective TZ (ISO 8601 with offset); `utc` is the same instant in UTC for reference.
  - `dialect` — `{model, env, effective}`. `effective` is what the planner uses when a request omits `dialect`: model.defaultDialect → DB_VENDOR → `postgres`. Always present.
- **`/v1/settings` accepts `?session_id=...&model_id=...` to scope the model-specific blocks in multi-model mode.** Resolution: single-model mode → preloaded model; both params → explicit lookup (404 on miss); `session_id` only → auto-pick when that session has exactly one model; no params in multi-model mode → auto-pick if a single model is loaded across all sessions, else the model blocks are omitted (no error). `model_id` without `session_id` → 400.

### Changed

- `Select` AST node gains a `distinct: bool` field; codegen emits `SELECT DISTINCT` when set. `QueryBuilder.distinct()` and a widened `with_cte()` signature support raw CFL composite construction.

### Fixed

- **CFL outer-aggregate ColumnRef alias shadowing on ClickHouse** (`ILLEGAL_AGGREGATION`). When a multi-fact CFL query mixed a measure with a metric referencing the same measure (e.g. `SUM(net_profit)` plus `SUM(net_profit)/SUM(sales) AS margin`), the metric's bare `SUM("Net Profit")` resolved to the sibling SELECT alias — itself an aggregate — and ClickHouse rejected the resulting nested aggregate. The planner now qualifies every ColumnRef inside outer-query aggregate functions with the composite CTE alias (`composite_01`), forcing resolution to the raw CTE column. Universally safe across all 7 dialects.
- **CFL NULL-padding dialect threading on ClickHouse** (`ILLEGAL_TYPE_OF_ARGUMENT — Variant(Decimal, Float64)`). The single-/zero-column path in `_resolve_null_type_for_field` was missing the `dialect` argument, so it bypassed `resolve_measure_data_type` and fell back to `result_type.value` (`'float'`) — emitting `CAST(NULL AS Nullable(Float64))` while the actual ClickHouse columns are `Decimal(7, 2)`. The `UNION ALL` widened to a `Variant` that `SUM` couldn't consume. Threading `dialect` through aligns NULL padding with the outer CAST target.
- **Raw CFL filter drop & ORDER BY on computed columns.** WHERE filters on data objects unreachable from a leg are now silently skipped per leg (instead of failing the entire query), matching the agg-mode semantics. ORDER BY on a column whose source AST is an inlined expression (computed column) now correctly remaps to the CTE alias in the outer query via structural-equality matching.
- **`/v1/settings` warms the DB session-TZ cache on first hit** when a model is bound and `query_execute` is enabled — and now also without a model bound when the cache is empty. Eliminates the previous one-request lag where the report runner / UI saw `effective: <model TZ>` until a real query happened to populate the probe.

### Docs

- New "Computed Columns" subsection in `guide/model-format.md` covering the column-level `expression:` field, single-brace `{Column}` syntax, the inlining semantics, and a reference-syntax cheat-sheet distinguishing column- vs measure- vs metric-level expressions.
- New "Regex Operators" and "String Length Operators" tables in `guide/query-language.md`, plus `blank` / `notblank` rows added to "Null Operators". Each includes per-dialect generated SQL for portability planning.
- Pinned an explicit `{ #filter-groups }` anchor on the Filter Groups heading so the in-page link `[filter groups](#filter-groups)` survives future heading-text edits.
- Expanded the bundled `examples/tpcds.obml.yml` model with `catalog_sales`, `catalog_returns`, `web_returns`, `inventory`, `warehouse`, `ship_mode`, and `reason` data objects, plus `Manager ID`, `Day Name`, and matching dimensions/measures. Demonstrates multi-fact CFL across three sales channels and exercises the new computed-column dim (`Year-Month`).

## [2.0.1] - 2026-04-27

### Added

- **`/v1/settings` now returns `version` and `api_version`.** Clients can negotiate features from a single call instead of also hitting `/health`. `version` matches the `__version__` constant; `api_version` is the REST URL prefix (`"v1"`).

### Docs

- Reordered `query-language.md`: the **Coalesce (Merging Role-Playing Dimensions)** section now sits between **Time Grain Override** and **Measures** so it reads next to the other dimension subsections.

## [2.0.0] - 2026-04-27

### Breaking

- **Many-to-one joins are now strictly forward-only.** The query planner refuses to walk a `many-to-one` join in reverse (which would silently inflate fact-table row counts). Queries that previously compiled by traversing such a reverse hop now raise `UNREACHABLE_REQUIRED_OBJECT`. **Migration:** declare bridge tables as `many-to-many` (already supported by OBML); see `examples/movies.obml.yml` for the canonical pattern.
- **CFL leg projection now honors per-dimension `via:` waypoints.** Role-playing dimensions (e.g., `Sales Employee` and `Purchase Employee`) no longer leak across UNION ALL legs — each leg projects only its own role and NULL-pads the others. Query results CHANGE for any model that had role-playing dimensions where the previous (incorrect) behavior was being relied on. **Migration:** the new output is the correct one; verify and update downstream code accordingly.
- **PostgreSQL renderer now emits `DECIMAL(p, s)`** instead of `NUMERIC(p, s)`. The two are SQL-standard synonyms in Postgres and every other supported dialect (canonical name in sqlglot is `DECIMAL`). **Migration:** consumers comparing exact SQL strings need an update; query semantics are unchanged.
- **`sqlparse` removed from dependencies.** The UI and API now use sqlglot's pretty-printer for all SQL formatting. Anyone transitively importing `sqlparse` from this project must add it to their own dependencies.

### Added

- **Query-level `coalesce` dimensions.** `select.dimensions` now accepts a `{coalesce: [...], as: <alias>}` group that merges role-playing dimensions into a single output column via `COALESCE(d1, d2, ...)`. ORDER BY may reference the alias directly. Validation: 5 new error codes (`COALESCE_MISSING_ALIAS`, `DUPLICATE_COALESCE_ALIAS`, `COALESCE_ALIAS_COLLISION`, `COALESCE_TOO_FEW_MEMBERS`, `COALESCE_TYPE_MISMATCH`).
- **`primaryKey` column property.** Optional informational marker on data object columns. Renders as `PK` in the Mermaid ER diagram (precedence over `FK`) and emits `obsl:primaryKey true` triples in the OBSL graph. Composite keys: set `primaryKey: true` on multiple columns.
- **`UNREACHABLE_REQUIRED_OBJECT` error.** Resolution-time error raised when a required dimension's source object cannot be reached from the query base via directed joins. Replaces silently-wrong SQL with a clear migration hint.
- **`examples/movies.obml.yml`** — bundled junction-table example (Movies / Directors / Producers with `many-to-many` bridges) demonstrating the recommended OBML pattern for many-to-many relationships.
- **Vertically responsive Gradio UI layout.** SQL Compiler, ER Diagram, and Ontology Graph tabs scale with viewport height via `dvh`-based CSS. Editor and output rows resize fluidly without overflow.
- **Ontology Graph tab.** Interactive vis-network visualization (data objects, dimensions, measures, metrics, joins) with toggleable layers and adjustable node spacing. vis-network v9.1.2 ships as a static asset (no CDN dependency), loaded via base64-encoded iframe srcdoc.
- **API responses now return sqlglot-pretty SQL.** Every `/v1/.../query/sql` and `/v1/.../query/execute` endpoint formats SQL with one expression per line. Consumers (gradio_client, MCP, AI agents, dashboards) get readable SQL by default with no flag required.

### Fixed

- **CFL planner via-aware leg construction** (see Breaking).
- **Join graph reverse-traversal silent fanout** (see Breaking).
- **MISSING_VIA validator** — only warns when a dimension table has direct joins from multiple fact tables, not transitive reachability. Fact-table dimensions (columns on the fact table itself) no longer trigger false warnings.
- **Example model `via` cleanup** — removed unnecessary `via` from dimensions on tables that are only direct children of one fact table (Clients, Countries, Regions) and from fact-table-local dimensions (Sales Date, Payment Type).

### Removed

- `sqlparse` runtime dependency.
- Unused `Graph Height` slider on the Ontology Graph tab (the iframe is now viewport-height driven).

### Security

- New Cloud Armor rules for the public demo block `/ui/gradio_api/info`, `/ui/monitoring/*`, and `/ui/openapi.json` (admin/discovery endpoints not used by the browser UI).
- `main` branch protection enabled on the public repo and the four sibling repos: PR required, force-push and deletion blocked, linear history enforced.

## [1.8.2] - 2026-04-25

_Release notes pending._

## [1.8.1] - 2026-04-24

### Fixed

- **CFL NULL padding type mismatch** — UNION ALL legs now use the source column's `abstractType` for NULL padding instead of the measure's `resultType`. Fixes PostgreSQL `UNION types cannot be matched` errors when COUNT_DISTINCT measures reference string columns.
- **Dropdown pre-selection** — UI picker dropdowns (Dimensions, Measures/Metrics, Columns) no longer auto-select the first value on load, which prevented that value from being selected by the user.

## [1.8.0] - 2026-04-22

### Added

- **Grain override** — per-measure `grain:` property controls aggregation grain independently from query dimensions. Supports `FIXED` (start empty) and `RELATIVE` (inherit query dims) modes with `exclude`, `include`, and `keepOnly` operators. Compiled as `AGG(x) OVER (PARTITION BY ...)` window functions. 40 new tests.
- **Filter context** — per-measure `filterContext:` property controls which query WHERE filters apply. Supports `FIXED` (ignore all) and `RELATIVE` (inherit and modify) modes with `exclude`, `keepOnly`, and structured `include` filters. Compiled as isolated CTEs with LEFT/CROSS JOIN. 59 new tests.
- **Grain & filter context guide** — dedicated MkDocs guide page with OBML syntax, properties, examples (percent of total, percent of parent, unfiltered grand total, selective filter exclusion), and compilation strategy.
- **OBSL ontology update** — 12 new datatype properties: `grainMode`, `grainExclude`, `grainInclude`, `grainKeepOnly`, `filterContextMode`, `filterContextExclude`, `filterContextKeepOnly`, `filterContextInclude`, `owner`, `dataType`, `format`. Exporter emits triples for all new properties across data objects, columns, dimensions, measures, and metrics.
- **OSI converter roundtrip** — `grain` and `filterContext` preserved through OBML → OSI → OBML conversion via `custom_extensions`. 13 new roundtrip tests.

### Changed

- Version bumped to 1.8.0
- `total: true` is now documented as shorthand for `grain: { mode: FIXED }`
- README roadmap: grain & filter context moved from "Planned" to "Shipped"

---

## [1.7.1] - 2026-04-22

### Fixed

- **OSI converter roundtrip** — full preservation for all OBML properties through OSI-to-OBML and OBML-to-OSI conversion: `settings`, `owner`, `dataType`, column metadata (`sqlType`, `sqlPrecision`, `sqlScale`, `numClass`, `comment`), dimension properties (`resultType`, `description`), and metric `format`. 22 new property roundtrip tests.

### Added

- **Favicon** — docs site now has a favicon.

### Changed

- Version bumped to 1.7.1
- Fixed MkDocs Material pinned version

---

## [1.7.0] - 2026-04-20

### Added

- **Data types & numerical precision** — automatic CAST wrapping with dialect-specific type rendering (`NUMERIC`, `NUMBER`, `Decimal`, etc.). Type resolution order: explicit `dataType` → structural inference → model default → built-in default. Precision clamping per dialect.
- **Timezone settings** — `settings.defaultTimezone` (IANA timezone) and `settings.allowUtcFallback` for naive timestamp coercion in query execution results. Resolution chain: model setting → host process TZ → UTC fallback (opt-in).
- **ISO 8601 serialization** — temporal query results use proper offset notation, UTC "Z" suffix, and elide zero microseconds.
- **HAVING on metrics** — HAVING filters now accept metric names (not just measures). Alias expansion to full aggregate expressions ensures PostgreSQL compatibility.
- **Model settings in samples** — TPC-H example and sales model fixtures include `defaultNumericDataType`, `defaultTimezone`, and `allowUtcFallback`.

### Fixed

- **Pre-existing mypy errors** — resolved all type errors across `ui/app.py`, `model_store.py`, `sessions.py`, and `shortcuts.py`.

### Changed

- Version bumped to 1.7.0

---

## [1.6.2] - 2026-04-19

### Added

- **Query execution in Gradio UI** — new "Execute Query" button and "Query Results" tab with data table, visible when `QUERY_EXECUTE=true`. Calls `/query/execute` and auto-switches to results.
- **Docker UI instructions in README** — added examples for running API, UI, and Flight images together.
- **Gradio mount log message** — embedded mode now logs the UI URL on startup.

### Changed

- Version bumped to 1.6.2

---

## [1.6.1] - 2026-04-18

### Added

- **`model_json` input** — load and validate endpoints now accept `model_json` (JSON object) as an alternative to `model_yaml` (YAML string). Eliminates YAML escaping/indentation issues for LLM consumers.
- **Auto-parse stringified JSON** — if `model_json` is passed as a JSON string instead of an object (common with smaller LLMs), it is auto-parsed via `json.loads()`.

### Fixed

- **Verbose 422 error messages** — model validation errors now include all error codes and messages in the top-level `message` field, so MCP consumers see actionable details instead of generic "parsing or validation failed".

### Changed

- Version bumped to 1.6.1

---

## [1.6.0] - 2026-04-18

### Added

- **Extends/inherits model composition** — models can extend or inherit from other models via `extends_yaml` and `inherits_model_id` parameters on `POST /sessions/{id}/models`. `ExtendsMerger` deep-merges data objects, dimensions, measures, metrics, and filters with conflict detection.
- **Comprehensive malformed expression ref detection** — 16 bracket patterns detected across metric (`{[MeasureName]}`) and measure (`{[DataObject].[Column]}`) expressions, with specific error messages for each malformation (missing `[`, `]`, `{`, `}`, `.` separator, etc.).
- **UI query pickers** — dimension, measure/metric, and column dropdown pickers in the Gradio SQL Compiler tab with intelligent YAML insertion at correct sections and indentation.
- **UI editor toolbar buttons** — clear (✕), undo (↶), and redo (↷) buttons on both OBML and query CodeMirror editors.

### Fixed

- **UI editor layout** — fixed-height CodeMirror editors (45dvh) with bottom alignment, no content-dependent resizing.

### Changed

- Version bumped to 1.6.0

---

## [1.5.1] - 2026-04-16

### Added

- **OBSL measure filter expression** — measures with filters now export `obsl:filterExpression` in the RDF graph (e.g., `"Customers.Country equals 'US'"`). Updated ontology (`obsl.ttl`), SHACL shapes, spec, and example.

### Fixed

- **Unreachable filters silently skipped** — static and query-time filters on data objects not reachable from the query's join graph are now silently ignored instead of raising `UNREACHABLE_FILTER_FIELD`. Filters are irrelevant when the query doesn't touch that part of the schema.

### Changed

- Version bumped to 1.5.1

---

## [1.5.0] - 2026-04-16

### Added

- **Static model filters** — top-level `filters:` YAML key injects mandatory WHERE conditions into every query against the model. Supports all filter operators (OBML and SQL-style), auto-join extension, and AND combination with query-time filters.
- **ISO 8601 date/timestamp support** — bare YAML dates (`2026-01-01`) and timestamps (`2026-01-01T14:30:00Z`, `+02:00` offsets) are auto-coerced to ISO strings in both static and query-time filters.
- **Filter deduplication** — query-time WHERE filters identical to a static filter are silently skipped (no duplicate predicates in SQL).
- **OSI roundtrip for static filters** — `obml_filters` preserved in `custom_extensions` during OBML → OSI → OBML conversion.
- **JSON Schema validation** — `staticFilterOperator` enum (30 operators), typed `value`/`values` fields.
- **Schema API** — `filters` field in `GET /schema` response exposes static filters.

### Changed

- Version bumped to 1.5.0

---

## [1.4.0] - 2026-04-12

### Added

- **Absolute max-age** — `SESSION_MAX_AGE_SECONDS` (default 24 h) prevents immortal sessions from chatty clients that keep refreshing the idle TTL.
- **Global session cap** — `MAX_SESSIONS` (default 500) returns HTTP **429 Too Many Requests** with `Retry-After` header when at capacity.
- **Per-session model cap** — `MAX_MODELS_PER_SESSION` (default 10) limits how many models a single session may hold.
- **Rate limiting** — `SESSION_RATE_LIMIT` (default 10/min) per-IP sliding-window rate limit on `POST /sessions` via `SessionRateLimitMiddleware`.
- **Expiry visibility** — `expires_at` and `max_expires_at` fields in session responses let clients refresh proactively instead of getting surprise 404s.
- **410 Gone for expired sessions** — `SessionExpiredError` returns HTTP 410 (not 404) so clients can distinguish expired from never-existed.
- **Session lifecycle logging** — structured log events for session create, expire, close, and purge sweeps.
- **New settings in `GET /v1/settings`** — `session_max_age_seconds`, `max_sessions`, `max_models_per_session`.

### Changed

- Version bumped to 1.4.0
- Default session (`__default__`) is now purged when not in single-model mode (`MODEL_FILE` not set)
- `SessionManager` constructor accepts `max_age_seconds`, `max_sessions`, `max_models_per_session`, `is_single_model_mode` parameters
- `ModelStore` constructor accepts `max_models` parameter

---

## [1.3.0] - 2026-04-10

### Added

- **OBSL-Core 0.1 RDF graph export** — every loaded model is exported as an RDF graph (Turtle) using the OBSL vocabulary at `https://ralforion.com/ns/obsl#`. Graph is built eagerly at model load time and cached alongside the `SemanticModel`.
- **SPARQL query API** — read-only `SELECT` and `ASK` queries against the OBSL graph via `POST /v1/sessions/{id}/models/{mid}/sparql` and the `/v1/sparql` shortcut. Update operations (`INSERT`, `DELETE`, `LOAD`, `DROP`) are rejected with HTTP 400.
- **Graph endpoint** — `GET /v1/sessions/{id}/models/{mid}/graph` and `/v1/graph` shortcut return the OBSL graph as `text/turtle`.
- **OWL axioms in OBSL-Core** — disjointness, functional properties, and inverse properties added to `ontology/obsl.ttl`.
- **Extended metric profile** — OBSL vocabulary split into core and extended metric classes (`CumulativeMetric`, `PeriodOverPeriodMetric`) with dedicated properties.
- **`obsl:synonym` property** — replaces SKOS alignment; synonyms are now first-class in the OBSL vocabulary.
- **OBSL Turtle download button** — Gradio UI ER diagram tab now exposes a button to download the loaded model's OBSL graph as `.ttl`.
- **OBML reference endpoint** — `GET /v1/reference/obml` returns the OBML reference documentation as structured JSON.
- **OBSL guide page** — new `docs/guide/obsl.md` walks through graph retrieval, SPARQL queries (SELECT/ASK), and the OBSL vocabulary.

### Fixed

- **Colab notebook Mermaid rendering** — switched from client-side mermaid.js CDN (blocked by Colab's sandboxed output iframe CSP) to server-rendered SVG via `mermaid.ink`.
- **Colab notebook zombie subprocesses** — added explicit port cleanup (`lsof -ti tcp:8099` + SIGKILL) before starting a fresh uvicorn subprocess; previous runs left stale listeners holding the port.
- **Colab notebook model loading** — replaced unreliable `MODEL_FILE` env var with explicit `POST /v1/sessions` + `POST /v1/sessions/{id}/models` from the notebook.

### Removed

- **Dead code** — removed unused `load_model_directory` method, `_cleanup_session` helper, and unreferenced `ErrorResponse` Pydantic model (47 lines total, identified via ruff + vulture).

### Changed

- Version bumped to 1.3.0
- Ontology directory renamed from `OBSL/` to `ontology/`
- SHACL shapes updated to match OBSL-Core 0.1 vocabulary
- Ruff format applied to `obsl/exporter.py`, `obsl/sparql.py`, `api/schemas.py`, `ui/app.py`, `tests/unit/test_obsl.py`

---

## [1.2.2] - 2026-03-28

### Fixed

- **Flight info stale after auto-detection** — refresh cached deps (flight_info, query_execute_enabled) after ob_flight auto-detection so /v1/settings and query gating reflect actual runtime state
- **Shortcut 409 in single-model mode** — return __default__ session immediately in _resolve_single_model() and _resolve_store_and_model() when single-model mode is active, avoiding false 409 Conflict after creating a second session
- **Test failures without optional packages** — add pytest skip guards to TestMapTypeCode (ob_driver_core) and TestExecuteSql (ob_flight) so default test suite passes on standard install
- **Validate shortcut not stateless** — remove session dependency from POST /v1/validate; create a fresh ModelStore for validation since it only needs YAML parsing

### Changed

- Version bumped to 1.2.2

---

## [1.2.1] - 2026-03-27

### Fixed

- **Reversed join ON clauses** — swap columns when traversing join edges in reverse direction (CR-01)
- **Empty join column crash** — reject empty `columnsFrom`/`columnsTo` in validator; guard `build_join_condition` (CR-02)
- **Default session purge** — skip `__default__` session in TTL cleanup so single-model mode survives idle periods (CR-03)
- **Assert in production** — replace `assert` with structured `ResolutionError`/`SemanticError` in PoP and cumulative metric resolution (CR-04)
- **SQL injection via table refs** — quote all `format_table_ref` components across 7 dialect implementations (CR-05)
- **Filter value injection** — validate `QueryFilter.value` rejects arbitrary nested objects (CR-06)
- **TOCTOU race in shortcuts** — handle session expiry between `list_sessions` and `get_store` (CR-07)
- **Duplicate YAML keys** — reject duplicate keys at parse time via `allow_duplicate_keys = False` (CR-08)
- **Recursion on large models** — convert DFS cycle detection to iterative with explicit stack (CR-09)
- **Silent PoP fallback** — raise error for unknown comparison types instead of defaulting to percent change (CR-10)
- **AVG total fallback** — use `Literal(1)` instead of invalid column reference in edge case (CR-11)

### Changed

- Version bumped to 1.2.1
- Published 11 packages to PyPI: `orionbelt-semantic-layer` + 10 driver packages

---

## [1.2.0] - 2026-03-25

### Added

- **MySQL dialect** — full SQL generation support for MySQL (8th dialect), plus `ob-mysql` PEP 249 driver
- **Cumulative metrics** — running total, rolling window, and grain-to-date aggregations via `cumulative` metric type
- **Period-over-period (PoP) metrics** — 4-CTE date spine architecture for comparing current vs prior periods
- **Filtered measures** — CASE WHEN wrapping for measures with inline filters, plus ratio metrics
- **Integration tests** — DuckDB, PostgreSQL, MySQL, and ClickHouse tests via testcontainers; `ob-*` PEP 249 driver tests against real databases
- **UnsupportedAggregationError** — dialect limitations exposed in API response when an aggregation is not supported
- **OSI converter** — cumulative and period-over-period metric support for OSI ↔ OBML roundtrip

### Changed

- Dialect count increased from 7 to 8 (added MySQL)
- Version bumped to 1.2.0

---

## [1.1.0] - 2026-03-17

### Added

- **DB-API 2.0 drivers** — PEP 249 drivers for all 7 databases: `ob-postgres`, `ob-clickhouse`, `ob-duckdb`, `ob-databricks`, `ob-snowflake`, `ob-dremio`, `ob-bigquery`
- **Arrow Flight SQL** — query execution endpoint via Arrow Flight SQL server, with execute support across all 7 database drivers
- **Query execution endpoint** — `POST /v1/sessions/{id}/query/execute` compiles and runs queries (requires database connection)
- **TPC-H quickstart notebook** — Jupyter notebook with TPC-H model, Docker Hub badges, and interactive examples
- **`description` property** — optional description metadata on all OBML model objects, mapped in OSI converter
- **Filter groups** — `AND`/`OR`/`NOT` compound filter expressions in query WHERE clauses
- **Qualified WHERE filters** — `DataObject.Column` references in WHERE filters with auto-join
- **CFL optimization** — skip NULL padding for dialects supporting `UNION ALL BY NAME` (Snowflake, DuckDB)
- **OSI roundtrip** — preserve OBML-only properties in `custom_extensions` for lossless OSI ↔ OBML conversion
- **Split SQL/Explain UI** — side-by-side SQL and explain panel with detailed CFL leg explanations

### Changed

- `QUERY_EXECUTE` decoupled from `FLIGHT_ENABLED` — REST query execution works without Arrow Flight
- `ob_flight` uses lazy imports to avoid `pyarrow.flight` dependency when using DB-API drivers only
- OBML validator relaxed: `database` and `schema` now optional on data objects
- Version bumped to 1.1.0

### Fixed

- Reversed join path swapping columns incorrectly in JoinGraph
- CFL not triggering for expression-based measures
- Execute endpoint hang with DuckDB dbgen data duplication
- Swagger UI blank page (missing `unsafe-inline` in docs CSP)

---

## [1.0.0] - 2026-03-16

### Added

- **BigQuery dialect** — full SQL generation support for Google BigQuery
- **DuckDB dialect** — full SQL generation support for DuckDB/MotherDuck (uses `UNION ALL BY NAME`)
- **Model discovery API** — 10 new endpoints for exploring models programmatically:
  - `GET /v1/sessions/{id}/models/{mid}/schema` — full model structure as JSON
  - `GET /v1/sessions/{id}/models/{mid}/dimensions` — list/get dimensions
  - `GET /v1/sessions/{id}/models/{mid}/measures` — list/get measures
  - `GET /v1/sessions/{id}/models/{mid}/metrics` — list/get metrics
  - `GET /v1/sessions/{id}/models/{mid}/explain/{name}` — lineage explain
  - `POST /v1/sessions/{id}/models/{mid}/find` — search artefacts by name/synonym
  - `GET /v1/sessions/{id}/models/{mid}/join-graph` — join graph adjacency list
- **Top-level shortcuts** — auto-resolving endpoints (`/v1/schema`, `/v1/dimensions`, etc.) when only one session/model exists
- **Query explain** — compilation response now includes `explain` with reasoning for planner choice, base object selection, and each join decision
- **`owner` field** — optional owner/responsible-party metadata on all OBML objects (model, data objects, columns, dimensions, measures, metrics)
- **API versioning** — all routes prefixed with `/v1/` (except `/health` and `/robots.txt`)
- **BSL 1.1 license** — Business Source License with Apache 2.0 conversion on 2030-03-16
- **GitHub Actions CI** — automated test, lint, and type-check on every push and PR

### Changed

- Dialect count increased from 5 to 7 (added BigQuery and DuckDB)
- MCP server moved to separate repository ([orionbelt-semantic-layer-mcp](https://github.com/ralfbecher/orionbelt-semantic-layer-mcp))
- Version bumped to 1.0.0

### Migration from 0.8.x

**Breaking: API route prefix**

All API routes now require a `/v1/` prefix. Update your client URLs:

| Before (0.8.x)                  | After (1.0.0)                      |
| ------------------------------- | ---------------------------------- |
| `POST /sessions`                | `POST /v1/sessions`                |
| `POST /sessions/{id}/models`    | `POST /v1/sessions/{id}/models`    |
| `POST /sessions/{id}/query/sql` | `POST /v1/sessions/{id}/query/sql` |
| `GET /dialects`                 | `GET /v1/dialects`                 |
| `POST /convert/osi-to-obml`     | `POST /v1/convert/osi-to-obml`     |

The `/health` endpoint remains at the root (no prefix).

**New: `explain` in query response**

`POST /v1/sessions/{id}/query/sql` now returns an `explain` object alongside `sql`. Existing clients can safely ignore it.

**New: `owner` in OBML YAML**

The `owner` field is optional on all OBML objects. Existing models without `owner` continue to work unchanged.
