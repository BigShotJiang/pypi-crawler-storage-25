"""Thread handlers: post_turn, create_thread, fork_discussion,
update_project_toc, mark_discussion_decided, get_thread_comments.

Extended beyond #82's `{post_turn, create_thread, fork_discussion}`
spec to also host the orphan Discussion-side tools
(update_project_toc, mark_discussion_decided) and the general thread
reader (get_thread_comments). Keeping all Discussion-side tools
together matches the natural grouping of their github.discussions
dependencies and keeps issues.py focused on Issue-side workflow.
"""
from __future__ import annotations

from pathlib import Path

from mcp.types import TextContent

from ...adapters.types import Comment, Discussion
from ...context import ServerContext
from ...daemon.paths import DEFAULT_PROJECT_NAME, state_dir
from ...daemon_client import dispatch_read, dispatch_write
from ...models import CreateThreadResult, ForkResult, PostTurnResult
from ...toc_composer import compose_post_reframe_toc
from ...utils import check_overwrite_size, resolve_new_body
# Late binding — see helpers.py docstring.
from forge_manager_mcp import server as _s
from ..helpers import coord_ref, fetch_project_toc_body, make_canonical_ref, ok
from ._issue_creation import create_issue_via_replication


async def post_turn(
    ctx: ServerContext,
    thread_id: str,
    thread_type: str,
    speaker: str,
    body: str,
    proj_dir: Path,
) -> list[TextContent]:
    prefix = "**Claude:**" if speaker == "claude" else "**User:**"
    formatted = f"{prefix} {body}"

    # (#355 / D5.3) Daemon-routed append_comment. Pre-D5.3 this went
    # through ctx.replication.write directly; post-D5 the canonical
    # write boundary lives at the daemon's /writes endpoint. The
    # daemon reconstructs the typed ArtifactRef from the wire-level
    # fields + threads per-platform coords (#296) into each adapter.
    parent_kind = "discussion" if thread_type == "discussion" else "issue"
    parent_ref = make_canonical_ref(ctx, kind=parent_kind, native_id=thread_id)
    response = await dispatch_write(
        state_dir(DEFAULT_PROJECT_NAME),
        "append_comment",
        {
            "parent_kind": parent_kind,
            "parent_native_id": parent_ref.native_id,
            "owner": parent_ref.owner,
            "repo": parent_ref.repo,
            "body": formatted,
            "repo_role": "private",
        },
    )
    comment = Comment.model_validate(response["value"])

    ctx.activity.turns_posted += 1
    ctx.activity.turns_by_thread[thread_id] = (
        ctx.activity.turns_by_thread.get(thread_id, 0) + 1
    )

    toc_body = None
    if thread_id == ctx.config.project_discussion_id:
        toc_body = await fetch_project_toc_body(ctx)

    return ok(
        PostTurnResult(
            comment_id=comment.ref.native_id,
            comment_url=comment.url,
            project_toc_body=toc_body,
        ).model_dump()
    )


async def create_thread(
    ctx: ServerContext,
    thread_type: str,
    category_or_label: str,
    title: str,
    opening_body: str,
    discussion_origin_id: str,
    owner: str,
    repo: str,
    milestone: str | int | None = None,
) -> list[TextContent]:
    if thread_type == "discussion":
        # #232 — milestones are an Issue concept; reject for Discussions
        # rather than silently dropping (caught at the boundary).
        if milestone is not None:
            raise ValueError(
                "milestone parameter is not supported for type='discussion'. "
                "GitHub Discussions cannot be assigned to milestones; pass "
                "milestone only when type='issue'."
            )
        # #295 — validate the category name early so callers see a
        # clear error before the dispatch runs. The set mirrors the
        # legacy GitHub-only path's cat_map plus the two
        # Announcements / Project running-log aliases (#191).
        valid_categories = {"Architecture", "UX / UI", "Ideas",
                            "Announcements", "Project"}
        if category_or_label not in valid_categories:
            raise ValueError(
                f"Unknown Discussion category: {category_or_label!r}. "
                "Must be one of: Architecture, UX / UI, Ideas, "
                "Announcements (or its legacy alias Project)"
            )
        # #295 — Discussion creation now dispatches through the
        # ReplicationManager (canonical-first; mirror fan-out queues
        # on failure). Pre-#295 this branch went GitHub-direct,
        # bypassing the canonical store and failing entirely on
        # GitHub-down. Each adapter handles category resolution per
        # its own conventions: GitHub looks up the GraphQL node ID
        # via the per-adapter `_discussion_categories` map captured
        # in `from_config`; Forgejo / GitLab encode as `category:*`
        # labels per the 3.0 OQ1 design; LocalStore writes the
        # category into `meta.json`.
        # (#355 / D5.4) Daemon-routed Discussion creation. Pre-D5.4
        # this went through ctx.replication.write directly; post-D5
        # the canonical write boundary lives at the daemon's /writes
        # endpoint. The daemon threads per-platform coords (#296)
        # into each adapter's create_discussion call.
        response = await dispatch_write(
            state_dir(DEFAULT_PROJECT_NAME),
            "create_discussion",
            {
                "owner": owner,
                "repo": repo,
                "title": title,
                "body": opening_body,
                "category": category_or_label,
                "repo_role": "private",
            },
        )
        discussion = Discussion.model_validate(response["value"])
        ctx.activity.discussions_created += 1
        return ok(
            CreateThreadResult(
                thread_id=discussion.ref.native_id,
                thread_number=discussion.ref.number or 0,
                thread_url=discussion.url or "",
                type="discussion",
                project_toc_body=await fetch_project_toc_body(ctx),
            ).model_dump()
        )

    # #274 — Issue branch dispatches through `create_issue_via_replication`,
    # the shared helper used by both create_thread and create_issue_tool.
    issue, _project_item_id = await create_issue_via_replication(
        ctx,
        owner=owner, repo=repo, title=title, body=opening_body,
        labels=[category_or_label], milestone=milestone,
    )
    return ok(
        CreateThreadResult(
            thread_id=issue.ref.native_id,
            thread_number=issue.ref.number,
            thread_url=issue.url,
            type="issue",
            project_toc_body=await fetch_project_toc_body(ctx),
        ).model_dump()
    )


async def fork_discussion(
    ctx: ServerContext,
    arguments: dict,
    owner: str,
    repo: str,
) -> list[TextContent]:
    """Execute fork sequence. Not atomic — GitHub has no transaction API.
    Partial failures are reported so the caller can retry."""
    original_id = arguments["original_id"]
    fork_point_comment_id = arguments["fork_point_comment_id"]  # noqa: F841 — reserved
    new_title = arguments["new_title"]
    category_name = arguments["category_name"]
    summary = arguments["summary"]
    original_url = arguments["original_discussion_url"]
    fork_point_url = arguments["fork_point_url"]

    cat_map = {
        "Architecture": ctx.config.discussion_categories.Architecture.id,
        "UX / UI": ctx.config.discussion_categories.UX_UI.id,
        "Ideas": ctx.config.discussion_categories.Ideas.id,
    }
    category_id = cat_map.get(category_name)
    if not category_id:
        raise ValueError(f"Unknown category: {category_name!r}")

    repo_id = await _s.get_repo_node_id(ctx.github_token, owner, repo)

    new_opening = (
        f"## Forked from: [{original_url}]({original_url})\n"
        f"Fork point: [{fork_point_url}]({fork_point_url})\n\n"
        f"## Context Summary\n{summary}\n\n"
        f"---\n*Conversation continues from here.*"
    )
    new_disc = await _s.create_discussion(
        ctx.github_token, repo_id, category_id, new_title, new_opening
    )
    new_disc_id = new_disc["id"]
    new_disc_url = new_disc["url"]

    await _s.get_discussion_comments(ctx.github_token, original_id, last_n=1)
    fork_notice = (
        f"> ⚠️ This thread was partially forked.\n"
        f"> Content from [{fork_point_url}]({fork_point_url}) onward "
        f"continues in: **[{new_title}]({new_disc_url})**\n\n"
    )
    original_updated = False
    try:
        await _s.add_discussion_comment(ctx.github_token, original_id, fork_notice)
        original_updated = True
    except _s.GitHubError:
        original_updated = False

    fork_comment_body = (
        f"---\n"
        f"*Thread continues in [{new_title}]({new_disc_url}) from this point.*\n"
        f"---"
    )
    fork_comment = await _s.add_discussion_comment(
        ctx.github_token, original_id, fork_comment_body
    )

    ctx.activity.forks_executed += 1
    return ok(
        ForkResult(
            new_discussion_id=new_disc_id,
            new_discussion_url=new_disc_url,
            original_updated=original_updated,
            fork_comment_id=fork_comment["id"],
            project_toc_body=await fetch_project_toc_body(ctx),
        ).model_dump()
    )


async def update_project_toc(
    ctx: ServerContext,
    new_body: str | None,
    new_body_path: str | None,
    force: bool,
) -> list[TextContent]:
    body = resolve_new_body(new_body, new_body_path)
    ref = make_canonical_ref(
        ctx, kind="discussion",
        native_id=ctx.config.project_discussion_id,
    )
    # (#356, 3.7.0 D8.2) Daemon-routed read mirroring D8.1.
    read_response = await dispatch_read(
        state_dir(DEFAULT_PROJECT_NAME),
        "get_discussion_body",
        {
            "native_id": ref.native_id,
            "owner": ref.owner,
            "repo": ref.repo,
            "repo_role": "private",
        },
    )
    current_body = read_response.get("value", "")
    check_overwrite_size(current_body, body, force)
    # (#355 / D5.5) Daemon-routed body update.
    await dispatch_write(
        state_dir(DEFAULT_PROJECT_NAME),
        "update_discussion_body",
        {
            "native_id": ref.native_id,
            "owner": ref.owner,
            "repo": ref.repo,
            "body": body,
            "force": force,
            "repo_role": "private",
        },
    )
    return ok("Project Discussion TOC updated.")


async def update_discussion_body_tool(
    ctx: ServerContext,
    discussion_id: str,
    new_body: str | None,
    new_body_path: str | None,
    force: bool,
) -> list[TextContent]:
    """Replace the opening post body of an arbitrary Discussion (#231).

    Mirrors `update_issue_toc` and `update_project_toc` — same fetch-
    then-replace semantics with size guardrail (#48), `new_body_path`
    file-path alternative for large bodies (#193 Phase A), and
    auto-buffer-on-failure dispatch wrapper.

    `update_project_toc` is the specialization for the configured
    Project Index Discussion. This tool is the generalization for any
    other Discussion — running-log Discussions in particular
    (Hermeticity log, Test coverage log, Protocol-rules-to-MCP-tools
    maps), where the opening post evolves session-by-session.
    """
    body = resolve_new_body(new_body, new_body_path)
    ref = make_canonical_ref(ctx, kind="discussion", native_id=discussion_id)
    # (#356, 3.7.0 D8.2) Daemon-routed read mirroring D8.1.
    read_response = await dispatch_read(
        state_dir(DEFAULT_PROJECT_NAME),
        "get_discussion_body",
        {
            "native_id": ref.native_id,
            "owner": ref.owner,
            "repo": ref.repo,
            "repo_role": "private",
        },
    )
    current_body = read_response.get("value", "")
    check_overwrite_size(current_body, body, force)
    # (#355 / D5.5) Daemon-routed body update.
    await dispatch_write(
        state_dir(DEFAULT_PROJECT_NAME),
        "update_discussion_body",
        {
            "native_id": ref.native_id,
            "owner": ref.owner,
            "repo": ref.repo,
            "body": body,
            "force": force,
            "repo_role": "private",
        },
    )
    return ok("Discussion opening post updated.")


async def compose_post_reframe_toc_tool(
    ctx: ServerContext,
    project_name: str,
    preamble: str,
    releases: str,
    milestones: str,
    discussions: str,
    cross_repo_activity: str,
    project_board_url: str,
    repos: str,
    pointer_line: str | None,
) -> list[TextContent]:
    """Compose the post-reframe TOC body from caller-supplied section
    markdown (#237, per Discussion #235).

    Pure-layout MCP wrapper around `toc_composer.compose_post_reframe_toc`.
    No GraphQL reads, no IO — the caller assembles per-section content
    from whatever sources fit (CHANGELOG.md for releases, GraphQL
    milestone reads, existing TOC for cross-repo activity, etc.) and
    this tool just enforces the canonical layout per #235.

    Returns:
      ``{"body": str, "size_bytes": int}``

    The body is suitable for direct round-trip through `update_project_toc(
    new_body=body, force=True)` — the post-reframe shrink will trip the
    size guardrail, which `force=True` bypasses legitimately.
    """
    body = compose_post_reframe_toc(
        project_name=project_name,
        preamble=preamble,
        releases=releases,
        milestones=milestones,
        discussions=discussions,
        cross_repo_activity=cross_repo_activity,
        project_board_url=project_board_url,
        repos=repos,
        pointer_line=pointer_line,
    )
    return ok({"body": body, "size_bytes": len(body)})


async def mark_decided(
    ctx: ServerContext,
    discussion_id: str,
    decision_comment_id: str,
    category_name: str,
) -> list[TextContent]:
    cat_map = {
        "Architecture": ctx.config.discussion_categories.Architecture,
        "UX / UI": ctx.config.discussion_categories.UX_UI,
        "Ideas": ctx.config.discussion_categories.Ideas,
    }
    category = cat_map.get(category_name)
    answer_marked = False

    # #274 Phase C6 — mark the comment as the canonical Answer if the
    # category supports it (GitHub Q&A surface). Adapters without a
    # comment-level answer concept (Forgejo / GitLab / LocalStore)
    # raise NotImplementedError, which the ReplicationManager wraps
    # as ReplicationWriteError; both fall through to the
    # answer_marked=False path so the handler keeps the legacy
    # graceful-degradation contract.
    if category and category.is_answerable:
        from ...daemon_client import DaemonUnavailableError
        comment_ref = make_canonical_ref(
            ctx, kind="comment", native_id=decision_comment_id,
        )
        try:
            # (#355 / D5.6) Daemon-routed mark_answer.
            await dispatch_write(
                state_dir(DEFAULT_PROJECT_NAME),
                "mark_answer",
                {
                    "native_id": comment_ref.native_id,
                    "owner": comment_ref.owner,
                    "repo": comment_ref.repo,
                    "repo_role": "private",
                },
            )
            answer_marked = True
        except (DaemonUnavailableError, NotImplementedError):
            answer_marked = False

    ctx.activity.discussions_decided += 1
    return ok(
        {
            "answer_marked": answer_marked,
            "message": (
                "Discussion marked as decided."
                if answer_marked
                else "Decision comment posted. Category does not support Answer marking."
            ),
            "project_toc_body": await fetch_project_toc_body(ctx),
        }
    )


async def get_thread_comments(
    ctx: ServerContext,
    thread_id: str,
    thread_type: str,
    limit: int,
) -> list[TextContent]:
    parent_kind = "discussion" if thread_type == "discussion" else "issue"
    ref = make_canonical_ref(ctx, kind=parent_kind, native_id=thread_id)
    # (#356, 3.7.0 D8.3) Daemon-routed list_comments. Comment values
    # arrive as JSON dicts (model_dump output); reshape to legacy
    # `{comment_id, author, created_at, body}` for caller compat.
    read_response = await dispatch_read(
        state_dir(DEFAULT_PROJECT_NAME),
        "list_comments",
        {
            "parent_kind": parent_kind,
            "parent_native_id": ref.native_id,
            "owner": ref.owner,
            "repo": ref.repo,
            "limit": limit,
            "repo_role": "private",
        },
    )
    comments = read_response.get("value", [])
    # Pydantic mode="json" datetime → "...Z" suffix; pre-D8.3 path
    # used `.isoformat()` which emits "...+00:00". Normalize to the
    # latter for caller-visible string-format stability.
    legacy = [
        {
            "comment_id": (c.get("ref") or {}).get("native_id", ""),
            "author": c.get("author", ""),
            "created_at": (c.get("created_at") or "").replace("Z", "+00:00"),
            "body": c.get("body", ""),
        }
        for c in comments
    ]
    return ok({"comments": legacy})
