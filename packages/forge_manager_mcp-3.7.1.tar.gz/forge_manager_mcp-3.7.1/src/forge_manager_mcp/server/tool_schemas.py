"""MCP Tool schemas for all forge-manager tools.

Extracted from `build_server.list_tools` in Phase 2b so the dispatch
router (build.py) stays focused on wiring rather than schema
definitions.
"""
from __future__ import annotations

from mcp.types import Tool


def all_tool_schemas() -> list[Tool]:
    return [
        Tool(
            name="open_session",
            description=(
                "Start a new Claude session. Posts session-opened comment "
                "to Session Lock Discussion. Returns all IDs needed for the "
                "session. Call once at session start."
            ),
            inputSchema={"type": "object", "properties": {}, "required": []},
        ),
        Tool(
            name="recover_context",
            description=(
                "Bundled read for §Context Recovery (#58). Returns the "
                "current SessionState, the Project Discussion TOC body, "
                "open Issues, recent Discussions, and open Milestones "
                "with completion %. One tool call replaces five "
                "sequential reads. Per #222 callers can opt out of "
                "individual components via `include_*` flags and cap "
                "the open-Issues list with `max_open_issues`."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "days": {
                        "type": "integer",
                        "description": "Recency window for Discussions in days",
                        "default": 7,
                        "minimum": 1,
                    },
                    "include_toc_body": {
                        "type": "boolean",
                        "description": (
                            "Include `project_toc_body` in the response "
                            "(#222). Default true; pass false to skip "
                            "the TOC body bytes when the caller doesn't "
                            "need them."
                        ),
                        "default": True,
                    },
                    "include_open_issues": {
                        "type": "boolean",
                        "description": (
                            "Include `open_issues` in the response (#222). "
                            "Default true."
                        ),
                        "default": True,
                    },
                    "include_recent_discussions": {
                        "type": "boolean",
                        "description": (
                            "Include `recent_discussions` in the response "
                            "(#222). Default true."
                        ),
                        "default": True,
                    },
                    "include_milestones": {
                        "type": "boolean",
                        "description": (
                            "Include `milestones` in the response (#222). "
                            "Default true."
                        ),
                        "default": True,
                    },
                    "max_open_issues": {
                        "type": "integer",
                        "description": (
                            "Defensive cap on the open-Issues list (#222). "
                            "1–100; default 100."
                        ),
                        "default": 100,
                        "minimum": 1,
                        "maximum": 100,
                    },
                },
                "required": [],
            },
        ),
        Tool(
            name="scaffold_project",
            description=(
                "Legacy GitHub-only scaffold (single-platform). "
                "Scaffold a new managed project end-to-end: create "
                "<org>/<name> (public) and <org>/<name>-dev (private), "
                "seed the standard label set, enable Discussions on the "
                "dev repo, create a ProjectV2 board (linked to both "
                "repos) with the canonical Status field, and — once "
                "the five Discussion categories are present — seed "
                "the Project + Session-Lock Discussions and write "
                ".claude/github-config.json. Idempotent: inspects live "
                "state and no-ops any step already satisfied, so the "
                "tool can be re-run after the one manual pause for "
                "Discussion category creation (GitHub exposes no API "
                "for it). — #81 (v2 full bootstrap; v1 under #44).\n\n"
                "Prefer ``scaffold_project_multi`` for new projects — "
                "it drives the same GitHub flow through "
                "``GitHubAdapter.bootstrap_project`` plus a parallel "
                "``LocalStoreAdapter`` canonical-store bootstrap, and "
                "extends naturally to Forgejo / Codeberg / GitLab via "
                "the platforms list."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "org": {
                        "type": "string",
                        "description": "Existing GitHub org login.",
                    },
                    "project_name": {
                        "type": "string",
                        "description": "Base name; public repo is <org>/<name>, dev repo is <org>/<name>-dev.",
                    },
                    "description": {
                        "type": "string",
                        "description": "Short description used for both repos.",
                        "default": "",
                    },
                },
                "required": ["org", "project_name"],
            },
        ),
        Tool(
            name="scaffold_project_multi",
            description=(
                "Multi-platform scaffold (3.0+ canonical entry). "
                "Drives bootstrap across every platform listed in "
                "``platforms`` in the order given by ``replication_order`` "
                "(canonical first). For each platform, instantiates the "
                "adapter via its ``from_config`` classmethod and calls "
                "``bootstrap_project``; threads ``existing_state`` "
                "between adapters so later ones can cross-link or skip "
                "work the canonical already did. Adapters with "
                "``has_scaffold = False`` are skipped (no opt-out today; "
                "every shipped adapter has the flag True post-C2/C3/C4). "
                "Returns per-platform results + accumulated "
                "``manual_steps``. Forge-config.json emission + "
                "``.claude/settings.json`` + CLAUDE.md generation are "
                "operator follow-ups; this tool focuses on the GitHub / "
                "Forgejo / GitLab / LocalStore artifact creation."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "project_name": {
                        "type": "string",
                        "description": "Base name; per-platform naming convention applies (dev/public/docs trio on GitHub; dev/public pair on Forgejo / GitLab; docs repo on LocalStore).",
                    },
                    "description": {
                        "type": "string",
                        "description": "Short description used per platform with role-appropriate suffixes.",
                        "default": "",
                    },
                    "platforms": {
                        "type": "array",
                        "description": "Per-platform config dicts. Each dict has at minimum ``id`` (one of: local / github / forgejo / codeberg / gitlab) plus the platform-specific kwargs the adapter's ``from_config`` reads (``owner`` for hosted backends, ``url`` for self-hosted forgejo, ``path`` for local-store override, etc.).",
                        "items": {"type": "object"},
                    },
                    "replication_order": {
                        "type": "array",
                        "description": "Ordered list of platform_id strings (canonical first). Writes hit the canonical first and fan out; reads try each in order. Conventional ordering: ``[\"local\", \"github\"]`` for the GitHub-canonical 2.x → 3.0 migration shape, or ``[\"local\", \"forgejo\"]`` for forgejo-canonical projects.",
                        "items": {"type": "string"},
                    },
                    "require_bazel_builds": {
                        "type": "boolean",
                        "default": False,
                        "description": "(#289) Operator-input flag — when True, the generated .claude/project-rules.md carries an uncommented 'Use Bazel for all build and test' independent rule. When False (default), the file carries a commented example the operator can later uncomment.",
                    },
                    "require_maximal_coverage": {
                        "type": "boolean",
                        "default": False,
                        "description": "(#289) Operator-input flag — when True, generates an uncommented 'Extends commit.test_coverage' entry (every new code path tested in same commit). When False, ships as a commented example.",
                    },
                    "enable_llm_verifier": {
                        "type": ["boolean", "null"],
                        "default": None,
                        "description": "(#289) Operator-input flag — when False, generates an uncommented 'Closes commit.llm_verifier' state declaration with reason 'ANTHROPIC_API_KEY not configured'. When True or None, the LLM verifier stays open (default-evaluator runs when the gate is invoked).",
                    },
                    "custom_running_log": {
                        "type": ["string", "null"],
                        "default": None,
                        "description": "(#289) Operator-input — when set, generates an uncommented 'Extends commit.diff_covers_plan' paired-edit rule pointing at this running-log identifier (e.g., 'Discussion #190'). When unset, ships as a commented example.",
                    },
                },
                "required": ["project_name", "platforms", "replication_order"],
            },
        ),
        Tool(
            name="classify_and_create",
            description=(
                "Classify a turn and, if the classifier's confidence "
                "meets the threshold, auto-create the suggested thread "
                "(Discussion or Issue) and optionally post the turn "
                "onto it — one roundtrip instead of classify→inspect→"
                "create (#61). Below threshold, returns the "
                "classification only; caller decides."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "text": {"type": "string"},
                    "auto_create_threshold": {
                        "type": "string",
                        "enum": ["low", "medium", "high"],
                        "default": "high",
                        "description": "Auto-create when classifier confidence >= this level.",
                    },
                    "also_post_turn": {
                        "type": "boolean",
                        "default": True,
                        "description": "If auto-creating, also post `text` as user turn on the new thread.",
                    },
                    "opening_body": {
                        "type": "string",
                        "default": "",
                        "description": "Optional body for the new thread. Defaults to `text`.",
                    },
                },
                "required": ["text"],
            },
        ),
        Tool(
            name="check_skill_version",
            description=(
                "Parse the locally-installed skill prose (the resolver "
                "accepts both .claude/skills/forge-manager/SKILL.md and "
                "the legacy 2.x equivalents) and the upstream copy on "
                "the public mirror; report installed vs latest version "
                "and any changelog entries between them (#60)."
            ),
            inputSchema={"type": "object", "properties": {}, "required": []},
        ),
        Tool(
            name="replay_pending",
            description=(
                "Replay every buffered operation in .claude/pending-"
                "posts.md. Clears the buffer up-front; individual "
                "failures re-buffer via the normal error path, so "
                "the resulting buffer contains only still-unresolved "
                "entries (#57). 3.0 Phase D (#274) extends the drain "
                "to ReplicationManager._entries[*].pending_writes — "
                "writes that queued because a remote mirror was "
                "DEGRADED. The `targets` parameter scopes the drain; "
                "default = both queues."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "targets": {
                        "type": "array",
                        "items": {
                            "type": "string",
                            "enum": ["file", "replication"],
                        },
                        "description": (
                            "Which queues to drain. `file` drains "
                            ".claude/pending-posts.md; `replication` "
                            "drains per-adapter pending_writes. "
                            "Default = both."
                        ),
                    },
                    "inspect_only": {
                        "type": "boolean",
                        "description": (
                            "When true, return what would drain "
                            "(per-tool / per-adapter counts) without "
                            "actually replaying. Useful for "
                            "diagnostics on long-buffered projects "
                            "before committing to a live drain."
                        ),
                    },
                },
                "required": [],
            },
        ),
        Tool(
            name="close_issue_with_comment",
            description=(
                "Post a comment on an Issue and then close it with a "
                "state reason (#59). Comment posts first so it appears "
                "on the Issue timeline ahead of the close event. "
                "Identify the Issue with either `issue_id` or `number`."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "issue_id": {
                        "type": "string",
                        "description": "GitHub node ID of the Issue",
                    },
                    "number": {
                        "type": "integer",
                        "description": "Repo-scoped Issue number; alternative to issue_id",
                    },
                    "owner": {
                        "type": "string",
                        "description": "Repo owner (default: project's dev-repo owner)",
                    },
                    "repo": {
                        "type": "string",
                        "description": "Repo name (default: project's dev repo)",
                    },
                    "comment": {
                        "type": "string",
                        "description": "Body of the closing comment",
                    },
                    "state_reason": {
                        "type": "string",
                        "enum": ["completed", "not_planned"],
                        "default": "completed",
                        "description": "Close reason passed to GitHub's stateReason field",
                    },
                },
                "required": ["comment"],
            },
        ),
        Tool(
            name="get_thread_comments",
            description=(
                "Return comments on a Discussion or Issue with author "
                "info, ordered oldest → newest (#57)."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "thread_id": {
                        "type": "string",
                        "description": "GitHub node ID of the Discussion or Issue",
                    },
                    "thread_type": {
                        "type": "string",
                        "enum": ["discussion", "issue"],
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Max comments to return (1-100)",
                        "default": 20,
                        "minimum": 1,
                        "maximum": 100,
                    },
                },
                "required": ["thread_id", "thread_type"],
            },
        ),
        Tool(
            name="close_session",
            description=(
                "Close the current session. Posts session-closed "
                "comment to the Session Lock Discussion, and (by "
                "default) writes a project-state snapshot to "
                "Claude Code's auto-memory at "
                "~/.claude/projects/<sanitized-cwd>/memory/ so the next "
                "session boots with current context already in Claude's "
                "prompt (#161). If `summary` is omitted or empty, the "
                "server composes one from the session's activity log "
                "(#62)."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "summary": {
                        "type": "string",
                        "description": "Optional summary. Omit or pass empty string to use the server-composed default.",
                    },
                    "skill_update_candidates": {
                        "type": "integer",
                        "description": "Number of skill update candidates noted",
                        "default": 0,
                    },
                    "update_memory": {
                        "type": "boolean",
                        "description": (
                            "Write the project-state snapshot to "
                            "Claude Code's auto-memory directory "
                            "(#161). Default true. Skips silently if "
                            "the auto-memory directory is absent."
                        ),
                        "default": True,
                    },
                },
                "required": [],
            },
        ),
        Tool(
            name="post_turn",
            description=(
                "Post a single conversation turn (Claude or user) to a "
                "GitHub Discussion or Issue thread. Identify the thread "
                "with EITHER `thread_id` (node ID) OR `number` (repo-"
                "scoped, server resolves against the configured dev "
                "repo unless owner/repo are supplied)."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "thread_id": {
                        "type": "string",
                        "description": "GitHub node ID of the Discussion or Issue",
                    },
                    "number": {
                        "type": "integer",
                        "description": "Repo-scoped number; alternative to thread_id",
                    },
                    "owner": {
                        "type": "string",
                        "description": "Repo owner (default: project's dev-repo owner)",
                    },
                    "repo": {
                        "type": "string",
                        "description": "Repo name (default: project's dev repo)",
                    },
                    "thread_type": {
                        "type": "string",
                        "enum": ["discussion", "issue"],
                    },
                    "speaker": {
                        "type": "string",
                        "enum": ["claude", "user"],
                    },
                    "body": {
                        "type": "string",
                        "description": "Clean text of the turn (no tool call noise)",
                    },
                },
                "required": ["thread_type", "speaker", "body"],
            },
        ),
        Tool(
            name="create_thread",
            description="Create a new Discussion or Issue thread.",
            inputSchema={
                "type": "object",
                "properties": {
                    "type": {
                        "type": "string",
                        "enum": ["discussion", "issue"],
                    },
                    "category_or_label": {
                        "type": "string",
                        "description": (
                            "Discussion category name ('Architecture', 'UX / UI', "
                            "'Ideas', or 'Announcements' for running-log "
                            "Discussions; 'Project' is accepted as a legacy "
                            "alias for 'Announcements') or Issue label "
                            "('bug', 'rfc', 'feature', 'refactor', 'chore')"
                        ),
                    },
                    "title": {"type": "string"},
                    "opening_body": {
                        "type": "string",
                        "description": "Opening post content",
                    },
                    "discussion_origin_id": {
                        "type": "string",
                        "description": "Node ID of the Discussion this Issue originated from (Issues only)",
                        "default": "",
                    },
                    "milestone": {
                        "anyOf": [{"type": "string"}, {"type": "integer"}],
                        "description": (
                            "Optional milestone to assign (Issues only). "
                            "String → milestone title (matched against open + "
                            "closed milestones via GraphQL). Integer → "
                            "milestone number on the dev repo. Omit / null "
                            "→ no assignment. Raises an error if provided "
                            "with type='discussion' (Discussions can't be "
                            "milestoned in GitHub)."
                        ),
                    },
                },
                "required": ["type", "category_or_label", "title", "opening_body"],
            },
        ),
        Tool(
            name="classify_turn",
            description=(
                "Classify a user message to determine if it belongs in a "
                "Discussion or Issue, and suggest a title and category."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "text": {
                        "type": "string",
                        "description": "The user message to classify",
                    }
                },
                "required": ["text"],
            },
        ),
        Tool(
            name="detect_theme_change",
            description=(
                "Analyze whether a new message represents a theme change "
                "from the existing Discussion thread."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "thread_id": {
                        "type": "string",
                        "description": "GitHub node ID of the Discussion",
                    },
                    "new_turn_text": {
                        "type": "string",
                        "description": "The new message to evaluate",
                    },
                },
                "required": ["thread_id", "new_turn_text"],
            },
        ),
        Tool(
            name="fork_discussion",
            description=(
                "Fork a Discussion at a detected theme change point. "
                "Creates new Discussion, edits original opening post, "
                "posts inline fork comment. Atomic — reports partial "
                "failures if any step fails."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "original_id": {
                        "type": "string",
                        "description": "Node ID of the Discussion to fork from",
                    },
                    "number": {
                        "type": "integer",
                        "description": "Repo-scoped Discussion number; alternative to original_id",
                    },
                    "owner": {
                        "type": "string",
                        "description": "Repo owner (default: project's dev-repo owner)",
                    },
                    "repo": {
                        "type": "string",
                        "description": "Repo name (default: project's dev repo)",
                    },
                    "fork_point_comment_id": {
                        "type": "string",
                        "description": "Node ID of the comment where theme changed",
                    },
                    "new_title": {"type": "string"},
                    "category_name": {
                        "type": "string",
                        "enum": ["Architecture", "UX / UI", "Ideas"],
                    },
                    "summary": {
                        "type": "string",
                        "description": "Summary of forked content for new Discussion opening post",
                    },
                    "original_discussion_url": {
                        "type": "string",
                        "description": "Web URL of the original Discussion",
                    },
                    "fork_point_url": {
                        "type": "string",
                        "description": "Web URL of the fork-point comment",
                    },
                },
                "required": [
                    "fork_point_comment_id",
                    "new_title",
                    "category_name",
                    "summary",
                    "original_discussion_url",
                    "fork_point_url",
                ],
            },
        ),
        Tool(
            name="create_issue",
            description=(
                "Create a GitHub Issue, add it to the project board in "
                "Backlog, and cross-link to origin Discussion if provided. "
                "Pass `labels` as a list covering both the required type "
                "label (bug/rfc/feature/refactor/chore) and any area "
                "labels (area:mcp, area:skill, etc.). `label` is a "
                "deprecated single-value alias kept for backward compat."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "title": {"type": "string"},
                    "body": {
                        "type": "string",
                        "description": "Pre-formatted Issue body following template",
                    },
                    "labels": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": (
                            "Label names. Must include exactly one type "
                            "label from {bug, rfc, feature, refactor, "
                            "chore}. Area labels (area:*) recommended."
                        ),
                    },
                    "label": {
                        "type": "string",
                        "enum": ["bug", "rfc", "feature", "refactor", "chore"],
                        "description": "Deprecated: use `labels` instead.",
                    },
                    "discussion_origin_id": {
                        "type": "string",
                        "description": "Node ID of origin Discussion (empty if none)",
                        "default": "",
                    },
                    "milestone": {
                        "anyOf": [{"type": "string"}, {"type": "integer"}],
                        "description": (
                            "Optional milestone to assign. String → "
                            "milestone title (matched against open + closed "
                            "milestones via GraphQL). Integer → milestone "
                            "number on the dev repo. Omit / null → no "
                            "assignment. Resolution failure surfaces as a "
                            "buffered error listing available milestone "
                            "titles."
                        ),
                    },
                },
                "required": ["title", "body"],
            },
        ),
        Tool(
            name="update_issue_toc",
            description="Update the subtasks table in an Issue's opening post.",
            inputSchema={
                "type": "object",
                "properties": {
                    "issue_id": {
                        "type": "string",
                        "description": "GitHub node ID of the Issue",
                    },
                    "number": {
                        "type": "integer",
                        "description": "Repo-scoped Issue number; alternative to issue_id",
                    },
                    "owner": {
                        "type": "string",
                        "description": "Repo owner (default: project's dev-repo owner)",
                    },
                    "repo": {
                        "type": "string",
                        "description": "Repo name (default: project's dev repo)",
                    },
                    "new_body": {
                        "type": "string",
                        "description": (
                            "Complete new body for the Issue opening "
                            "post. Mutually exclusive with new_body_path."
                        ),
                    },
                    "new_body_path": {
                        "type": "string",
                        "description": (
                            "Absolute path to a file whose contents are "
                            "the new body. Use this when the body is too "
                            "large to pass inline (#193 Phase A). "
                            "Mutually exclusive with new_body."
                        ),
                    },
                    "force": {
                        "type": "boolean",
                        "description": "Skip the size-guardrail check. Set true only for legitimate large shrinks.",
                        "default": False,
                    },
                },
            },
        ),
        Tool(
            name="move_project_item",
            description="Move an Issue to a different project board column.",
            inputSchema={
                "type": "object",
                "properties": {
                    "issue_id": {
                        "type": "string",
                        "description": "GitHub node ID of the Issue",
                    },
                    "number": {
                        "type": "integer",
                        "description": "Repo-scoped Issue number; alternative to issue_id",
                    },
                    "owner": {
                        "type": "string",
                        "description": "Repo owner (default: project's dev-repo owner)",
                    },
                    "repo": {
                        "type": "string",
                        "description": "Repo name (default: project's dev repo)",
                    },
                    "column_name": {
                        "type": "string",
                        "enum": ["Backlog", "In Progress", "In Review", "Done", "Parked"],
                    },
                },
                "required": ["column_name"],
            },
        ),
        Tool(
            name="update_project_toc",
            description=(
                "Update the Project Discussion opening post with the "
                "latest Discussions and Issues tables."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "new_body": {
                        "type": "string",
                        "description": (
                            "Complete new body for the Project Discussion. "
                            "Mutually exclusive with new_body_path."
                        ),
                    },
                    "new_body_path": {
                        "type": "string",
                        "description": (
                            "Absolute path to a file whose contents are "
                            "the new body. Use this when the body is too "
                            "large to pass inline (#193 Phase A). "
                            "Mutually exclusive with new_body."
                        ),
                    },
                    "force": {
                        "type": "boolean",
                        "description": "Skip the size-guardrail check. Set true only for legitimate large shrinks.",
                        "default": False,
                    },
                },
            },
        ),
        Tool(
            name="update_discussion_body",
            description=(
                "Replace the opening post body of an arbitrary Discussion "
                "(#231). Use for running-log Discussions (Hermeticity log, "
                "Test coverage log, Protocol-rules-to-MCP-tools maps) "
                "where the opening post evolves session-by-session. Same "
                "fetch-then-replace semantics as update_project_toc / "
                "update_issue_toc, with size guardrail (#48). "
                "update_project_toc is the specialization for the "
                "configured Project Index Discussion; this tool is the "
                "generalization for any other Discussion."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "discussion_id": {
                        "type": "string",
                        "description": "GitHub node ID of the Discussion",
                    },
                    "number": {
                        "type": "integer",
                        "description": "Repo-scoped Discussion number; alternative to discussion_id",
                    },
                    "owner": {
                        "type": "string",
                        "description": "Repo owner (default: project's dev-repo owner)",
                    },
                    "repo": {
                        "type": "string",
                        "description": "Repo name (default: project's dev repo)",
                    },
                    "new_body": {
                        "type": "string",
                        "description": (
                            "Complete new body for the Discussion opening "
                            "post. Mutually exclusive with new_body_path."
                        ),
                    },
                    "new_body_path": {
                        "type": "string",
                        "description": (
                            "Absolute path to a file whose contents are "
                            "the new body. Use this when the body is too "
                            "large to pass inline (#193 Phase A). "
                            "Mutually exclusive with new_body."
                        ),
                    },
                    "force": {
                        "type": "boolean",
                        "description": "Skip the size-guardrail check. Set true only for legitimate large shrinks.",
                        "default": False,
                    },
                },
            },
        ),
        Tool(
            name="search_issues",
            description=(
                "Search GitHub Issues with shaped output (#236). Wraps "
                "GraphQL `search` over Issues; returns "
                "`{results: [...], total_count, query}` where each hit "
                "is `{number, title, url, state, labels, milestone, "
                "repository, created_at, updated_at}`. Use for context "
                "recovery (`milestone:'X'`-style filtering for active "
                "scope) and Issue triage (full-text search across "
                "bodies + comments). The structured params layer onto "
                "the user's `query` text — pass GitHub search "
                "operators verbatim (`in:body`, `author:`, "
                "`created:>YYYY-MM-DD`, etc.) and the resolved query "
                "string is returned for debugging."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": (
                            "Free-text query in GitHub search syntax. May "
                            "be empty if all filtering is via structured "
                            "params."
                        ),
                        "default": "",
                    },
                    "state": {
                        "type": "string",
                        "enum": ["open", "closed", "all"],
                        "default": "all",
                        "description": "Filter by Issue state.",
                    },
                    "labels": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": (
                            "Filter to Issues having all listed labels. "
                            "Labels with spaces are auto-quoted in the "
                            "search query."
                        ),
                    },
                    "milestone": {
                        "type": "string",
                        "description": (
                            "Filter to Issues in the named milestone "
                            "(by title). Integer-form (milestone number) "
                            "is not supported in v1; pass the title."
                        ),
                    },
                    "owner": {
                        "type": "string",
                        "description": "Repo owner (default: project's dev-repo owner)",
                    },
                    "repo": {
                        "type": "string",
                        "description": "Repo name (default: project's dev repo)",
                    },
                    "limit": {
                        "type": "integer",
                        "default": 50,
                        "minimum": 1,
                        "maximum": 100,
                        "description": "Max results to return per call.",
                    },
                },
            },
        ),
        Tool(
            name="search_local",
            description=(
                "Full-text search over the local canonical store via "
                "the daemon's FTS5 indices (#354 / capability 2). "
                "Searches Issues / Discussions / Sessions in one call; "
                "returns `{results: [...], total_count, query}` where "
                "each hit is `{kind, ref_native_id, title, snippet}`. "
                "Works regardless of remote-backend availability — "
                "indexes the local docs repo, not GitHub. Requires "
                "the daemon to be running; returns an error if absent."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": (
                            "FTS5 MATCH query. Supports phrase queries "
                            "(`\"action log\"`), boolean operators "
                            "(`sqlite AND fts5`), and column filters "
                            "(`title:capability`)."
                        ),
                    },
                    "kind": {
                        "type": "string",
                        "enum": ["issue", "discussion", "session"],
                        "description": (
                            "Optional filter to one artifact kind. "
                            "Omitted = union across all three."
                        ),
                    },
                    "limit": {
                        "type": "integer",
                        "default": 50,
                        "minimum": 1,
                        "maximum": 200,
                        "description": "Max results across all kinds.",
                    },
                },
                "required": ["query"],
            },
        ),
        Tool(
            name="compose_post_reframe_toc",
            description=(
                "Compose the post-reframe Project Index TOC body from "
                "caller-supplied per-section markdown (#237, per "
                "Discussion #235). Pure-layout helper — no GraphQL "
                "reads. Caller assembles section content from whatever "
                "sources fit (CHANGELOG.md, GraphQL milestone reads, "
                "existing TOC for Cross-Repo Activity entries, etc.); "
                "this tool enforces the canonical post-reframe layout "
                "(Releases / Milestones / Discussions / pointer line / "
                "Cross-Repo Activity / Project Board / Repos). Result "
                "round-trips through update_project_toc(force=True)."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "project_name": {
                        "type": "string",
                        "description": "Canonical short name for the title line.",
                    },
                    "preamble": {
                        "type": "string",
                        "description": (
                            "Markdown content between the title and "
                            "## Releases — typically ## Design Record + "
                            "## Cross-Repo Convention paragraphs. Empty "
                            "is fine."
                        ),
                        "default": "",
                    },
                    "releases": {
                        "type": "string",
                        "description": "Markdown body for ## Releases.",
                        "default": "",
                    },
                    "milestones": {
                        "type": "string",
                        "description": (
                            "Markdown body for ## Milestones. Per #235 "
                            "OQ2 the caller composes per-milestone "
                            "narrative summaries here."
                        ),
                        "default": "",
                    },
                    "discussions": {
                        "type": "string",
                        "description": (
                            "Markdown body for ## Discussions — "
                            "typically a table."
                        ),
                        "default": "",
                    },
                    "cross_repo_activity": {
                        "type": "string",
                        "description": (
                            "Markdown body for ## Cross-Repo Activity. "
                            "Per #235 OQ4 this is a live tracker for "
                            "sibling/cousin/neighbor work without paired "
                            "authoritative-dev Issues."
                        ),
                        "default": "",
                    },
                    "project_board_url": {
                        "type": "string",
                        "description": (
                            "Project board URL — emitted under "
                            "## Project Board and substituted into the "
                            "default pointer line."
                        ),
                        "default": "",
                    },
                    "repos": {
                        "type": "string",
                        "description": "Markdown bullets for ## Repos.",
                        "default": "",
                    },
                    "pointer_line": {
                        "type": "string",
                        "description": (
                            "Custom pointer line between Discussions and "
                            "Cross-Repo Activity. Omit / null → render "
                            "the default pointer line per #235."
                        ),
                    },
                },
                "required": ["project_name"],
            },
        ),
        Tool(
            name="close_triaged_public_issues",
            description=(
                "Auto-close upstream public-mirror Issues at release "
                "time (#249, per [#233] Rule B). Scans closed dev-repo "
                "Issues in the milestone matching `version` for "
                "`area:public-mirror` + a body cross-link to a public-"
                "mirror Issue (canonical form per #233 OQ1). For each "
                "match, posts a closing comment, applies the "
                "`fixedin:<version>` label (created on demand on the "
                "mirror; skipped on pre-releases per #233 OQ5), and "
                "closes with `state_reason: completed`. `dry_run=True` "
                "(default) returns the close set without any GitHub "
                "writes. Operator runs after `release_project` post-"
                "mirror-push (per #233 OQ2)."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "version": {
                        "type": "string",
                        "description": (
                            "Release version to filter dev-repo Issues "
                            "by milestone (e.g. '2.3.0'). PEP-440 pre-"
                            "release suffixes recognized (e.g. "
                            "'2.3.0a1') for the pre-release gate."
                        ),
                    },
                    "dry_run": {
                        "type": "boolean",
                        "default": True,
                        "description": (
                            "Preview the close set without acting. "
                            "Default true — operator must explicitly "
                            "pass false to perform writes."
                        ),
                    },
                    "skip_pre_release": {
                        "type": "boolean",
                        "default": True,
                        "description": (
                            "When `version` is a pre-release suffix "
                            "(alpha/beta/rc), skip the `fixedin:<release>` "
                            "label application but still post the close "
                            "comment per #233 OQ5. Default true."
                        ),
                    },
                },
                "required": ["version"],
            },
        ),
        Tool(
            name="generate_changelog",
            description=(
                "Regenerate CHANGELOG.md from the skill's ## Changelog "
                "section (#108). Preview by default; pass write=true "
                "to actually overwrite the file. release_project's "
                "auto-populate path uses the same generator, so this "
                "tool is only needed when the operator wants to refresh "
                "the file mid-cycle without running a release."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "write": {
                        "type": "boolean",
                        "default": False,
                        "description": "Overwrite CHANGELOG.md instead of just previewing.",
                    },
                },
                "required": [],
            },
        ),
        Tool(
            name="release_project",
            description=(
                "Orchestrate a release: validate (#107) → dev_tag → "
                "mirror_sync → mirror_tag → release_notes. Hard-gated on "
                "validate_release; no force override. Defaults to dry-run "
                "— call with dry_run=False after the dry-run output looks "
                "right. `stop_after` lets the operator cut just the dev "
                "tag (stop_after='dev_tag') and defer mirror sync. If "
                "validate fails only on version-line checks, the tool "
                "returns awaiting_version_bump_approval with proposed "
                "edits; re-call with approve_version_bump=true to apply "
                "them and continue. Auto-populates CHANGELOG.md if absent. "
                "`pypi_only=true` skips every GitHub-coupled step and "
                "runs python -m build + twine upload locally using "
                "$TWINE_PASSWORD or $PYPI_API_TOKEN — for releases that "
                "must ship while GitHub access is unavailable. (#106)"
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "version": {
                        "type": "string",
                        "description": "Target release version, e.g. '1.3.0'.",
                    },
                    "dry_run": {
                        "type": "boolean",
                        "default": True,
                        "description": "Preview every step without mutating.",
                    },
                    "stop_after": {
                        "type": "string",
                        "enum": ["validate", "dev_tag", "mirror_sync", "release_notes"],
                        "default": "release_notes",
                        "description": "Last step to run.",
                    },
                    "approve_version_bump": {
                        "type": "boolean",
                        "default": False,
                        "description": "If validate fails only on version-line checks, apply the proposed bump, commit, push.",
                    },
                    "skip_bazel": {
                        "type": "boolean",
                        "default": False,
                        "description": "Downgrade the bazel test check from fail to warn (forwarded to validate_release).",
                    },
                    "skip_smoke_test": {
                        "type": "boolean",
                        "default": False,
                        "description": "Downgrade the installed_wheel_smoke_test check from fail to warn (forwarded to validate_release). Only relevant for repo_role in (mcp, monorepo).",
                    },
                    "pypi_only": {
                        "type": "boolean",
                        "default": False,
                        "description": (
                            "Skip GitHub-coupled steps; build + upload "
                            "to PyPI locally instead. Requires "
                            "$TWINE_PASSWORD or $PYPI_API_TOKEN."
                        ),
                    },
                },
                "required": ["version"],
            },
        ),
        Tool(
            name="validate_release",
            description=(
                "Pre-flight checker for a release target version (#107). "
                "Read-only. Repo-role-aware: applies the skill-repo or "
                "mcp-repo checklist based on files present in project_dir. "
                "Returns `ready: bool` plus per-check status so the operator "
                "(and `release_project`) can see exactly which check blocks. "
                "`skip_bazel=true` downgrades the `bazel test //...` check "
                "from fail to warn — use only for fast iteration; real "
                "releases must run with skip_bazel=false."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "version": {
                        "type": "string",
                        "description": "Target release version, e.g. '1.3.0'.",
                    },
                    "skip_bazel": {
                        "type": "boolean",
                        "description": "Downgrade the bazel test check from fail to warn.",
                        "default": False,
                    },
                    "skip_smoke_test": {
                        "type": "boolean",
                        "description": "Downgrade the installed_wheel_smoke_test check from fail to warn (#3). Only fires for repo_role in (mcp, monorepo).",
                        "default": False,
                    },
                    "runbook_confirmations": {
                        "type": "object",
                        "description": (
                            "Operator-supplied confirmation map for "
                            "pre-publish runbook gates (3.4.0 / "
                            "Codeberg-dev #3). Keys are gate names "
                            "(e.g. 'publish.live_marketplace_add_smoke_test'); "
                            "values are booleans — True if the operator ran "
                            "the runbook and confirms it passed. Missing "
                            "keys treated as unconfirmed. Default project "
                            "rules treat unconfirmed as advisory (warn); "
                            "project rules can tighten to fail."
                        ),
                        "additionalProperties": {"type": "boolean"},
                    },
                },
                "required": ["version"],
            },
        ),
        Tool(
            name="mark_discussion_decided",
            description=(
                "Mark a Discussion as decided: mark answer comment if "
                "category supports it, update status in Project TOC."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "discussion_id": {
                        "type": "string",
                        "description": "Node ID of the Discussion",
                    },
                    "number": {
                        "type": "integer",
                        "description": "Repo-scoped Discussion number; alternative to discussion_id",
                    },
                    "owner": {
                        "type": "string",
                        "description": "Repo owner (default: project's dev-repo owner)",
                    },
                    "repo": {
                        "type": "string",
                        "description": "Repo name (default: project's dev repo)",
                    },
                    "decision_comment_id": {
                        "type": "string",
                        "description": "Node ID of the comment summarizing the decision",
                    },
                    "category_name": {
                        "type": "string",
                        "description": "Category name to check answerability",
                    },
                },
                "required": ["decision_comment_id", "category_name"],
            },
        ),
        Tool(
            name="verify_diff_covers_plan",
            description=(
                "Compare a plan's YAML frontmatter against an actual git "
                "diff (#185). Reports drift in either direction: files "
                "declared in `touched_files` but not in the diff, files "
                "in the diff not declared, entities listed in "
                "`entities_introduced` not present in additions, "
                "entities listed in `entities_modified` not referenced "
                "anywhere in the diff, and AC IDs without `(ACn)` "
                "evidence in the diff or supplied evidence text. Plans "
                "without frontmatter return covered=true with a single "
                "warning (graceful degradation)."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "plan_body": {
                        "type": "string",
                        "description": (
                            "Markdown body of the plan/RFC including any "
                            "YAML frontmatter at the top."
                        ),
                    },
                    "diff_text": {
                        "type": "string",
                        "description": (
                            "Unified diff text — typically the output of "
                            "`git diff main...HEAD` for the PR under review."
                        ),
                    },
                    "evidence_text": {
                        "type": "string",
                        "description": (
                            "Optional concatenation of commit messages + "
                            "PR body — searched for `(ACn)` references "
                            "alongside the diff to assess AC coverage. "
                            "Also scanned for project-rule signals "
                            "(`## Edits to Discussion #N` sections, "
                            "`Updated Discussion #N with: …` comments) "
                            "per #192."
                        ),
                        "default": "",
                    },
                    "project_rules": {
                        "type": "array",
                        "description": (
                            "Optional list of project-specific rules "
                            "(#192). Each rule: name, "
                            "if_diff_touches_pattern (regex), "
                            "must_also_touch_discussion (int), severity, "
                            "message. When omitted the verifier inherits "
                            "the project's default rule set composed "
                            "from configured fields (currently the "
                            "skill-prose ↔ running-log dependency, "
                            "conditional on "
                            "running_log_discussion_number)."
                        ),
                        "items": {"type": "object"},
                    },
                },
                "required": ["plan_body", "diff_text"],
            },
        ),
        Tool(
            name="verify_existing_code_assumptions",
            description=(
                "LLM-backed drift verifier (#187): for each `assumption` "
                "declared in the plan's YAML frontmatter, confirm whether "
                "the **fresh head version** of the touched files still "
                "supports the claim. Catches error class 4 from "
                "Discussion #182 — plans built on stale analysis. "
                "Skips gracefully when ANTHROPIC_API_KEY is unset, when "
                "the plan body has no frontmatter, or when the plan "
                "declares no `assumptions` field."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "plan_body": {
                        "type": "string",
                        "description": (
                            "Markdown body of the plan/RFC including any "
                            "YAML frontmatter — same input as the "
                            "deterministic verifiers."
                        ),
                    },
                    "pr_diff": {
                        "type": "string",
                        "description": (
                            "Unified diff text — typically the output of "
                            "`git diff main...HEAD` for the PR under review."
                        ),
                    },
                    "repo_root": {
                        "type": "string",
                        "description": (
                            "Absolute path to the repo working tree; "
                            "defaults to the session's project_dir. Files "
                            "named in `touched_files` are read fresh from "
                            "this directory — the verifier never trusts "
                            "prior context."
                        ),
                    },
                    "model": {
                        "type": "string",
                        "description": (
                            "Anthropic model ID. Defaults to "
                            "`claude-sonnet-4-6` for ~80% of Opus' "
                            "verification accuracy at ~5x lower cost."
                        ),
                        "default": "claude-sonnet-4-6",
                    },
                    "token_budget": {
                        "type": "integer",
                        "description": (
                            "Approximate input-token budget for the "
                            "prompt. Files are truncated tail-first when "
                            "the budget is tight; the dropped paths are "
                            "reported in `files_dropped_for_budget`."
                        ),
                        "default": 100000,
                    },
                },
                "required": ["plan_body", "pr_diff"],
            },
        ),
        Tool(
            name="verify_plan_completeness",
            description=(
                "Verify a plan/RFC body's YAML frontmatter against the "
                "schema in validation.md (#183, #184). Deterministic — "
                "checks required fields, AC ID 1:1 coherence with "
                "`## Acceptance criteria` checkboxes, path traversal, "
                "and entity-list shape. Plans without frontmatter return "
                "valid=true with a single warning (graceful degradation)."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "plan_body": {
                        "type": "string",
                        "description": (
                            "Markdown body of the plan/RFC including any "
                            "YAML frontmatter at the top."
                        ),
                    },
                },
                "required": ["plan_body"],
            },
        ),
        Tool(
            name="migrate_to_3_0",
            description=(
                "Detect 2.x legacy state in the project_dir and "
                "produce/apply a migration plan (3.0 / Phase 7, #271). "
                "Dry-run by default; pass apply=true to execute with "
                "an automatic backup of .claude/ under "
                ".claude/backups/migration-<utc-ts>/. Returns the plan "
                "summary, executed steps, and the backup_path so a "
                "subsequent migrate_to_3_0_rollback can revert."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "apply": {
                        "type": "boolean",
                        "default": False,
                        "description": (
                            "If true, executes the migration steps. "
                            "Default false performs a dry run."
                        ),
                    },
                },
            },
        ),
        Tool(
            name="migrate_to_3_0_rollback",
            description=(
                "Restore .claude/ from a backup produced by "
                "migrate_to_3_0(apply=true). Pass the backup_path "
                "returned in that prior call."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "backup_path": {
                        "type": "string",
                        "description": (
                            "Absolute path to the backup directory "
                            "(typically .claude/backups/migration-<utc-ts>/)."
                        ),
                    },
                },
                "required": ["backup_path"],
            },
        ),
        Tool(
            name="add_backend",
            description=(
                "Append a new platform entry to forge-config.json's "
                "platforms list (3.0 / Phase 7). Idempotent — second "
                "call with same platform_id is a no-op + reports "
                "already_present. Token validation deferred to next "
                "session start."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "platform_id": {
                        "type": "string",
                        "description": (
                            "Stable identifier — 'codeberg' / 'forgejo' / "
                            "'gitlab'. The id is used in ArtifactRef.platform_id "
                            "and in adapter selection."
                        ),
                    },
                    "config": {
                        "type": "object",
                        "description": (
                            "Platform-specific config blob. Merged with "
                            "{id: platform_id} into the platforms list. "
                            "Fields vary per backend (e.g., 'url' for "
                            "self-hosted Forgejo; 'owner' / 'private' / "
                            "'public' / 'docs' for the project's repos)."
                        ),
                    },
                },
                "required": ["platform_id", "config"],
            },
        ),
        Tool(
            name="audit_project_prose",
            description=(
                "Scan project prose surfaces (CLAUDE.md, README, docs/) "
                "for muddling between skill protocol and project rules "
                "(#290). Reports findings the operator reviews and "
                "migrates to .claude/project-rules.md (#288). Six "
                "detection categories: gate_extension_candidate, "
                "gate_override_candidate, gate_closure_candidate, "
                "protocol_concept_redefinition, identity_in_rules_doc, "
                "rules_in_identity_doc. Apply mode (apply_finding_id) "
                "returns the migrated text without writing to disk — "
                "operator commits."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "include": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": (
                            "Glob patterns to include, relative to project "
                            "root. Defaults to CLAUDE.md, README.md, "
                            "CONTRIBUTING.md, .claude/project-rules.md, "
                            "docs/**/*.md, *.md."
                        ),
                    },
                    "exclude": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": (
                            "Glob patterns to exclude. Defaults exclude "
                            "CHANGELOG.md, .claude/skills/**, build/**, "
                            "dist/**, .git/**, node_modules/**."
                        ),
                    },
                    "since": {
                        "type": "string",
                        "description": (
                            "ISO-8601 timestamp; only files modified at "
                            "or after this time are scanned. Useful for "
                            "incremental audits during migration."
                        ),
                    },
                    "apply_finding_id": {
                        "type": "string",
                        "description": (
                            "When set, the tool runs the audit, locates "
                            "the finding with this id, and returns its "
                            "migrated text instead of the full report. "
                            "The operator pastes the returned text into "
                            "`.claude/project-rules.md` and commits."
                        ),
                    },
                },
            },
        ),
        Tool(
            name="check_code_design",
            description=(
                "Run mechanical code-design evaluators against the "
                "project (#330 / Phase D2). Five rules: "
                "schema_as_functions (Rule 5; AST scan for top-level "
                "Pydantic / dataclass / TypedDict), test_purity_tagging "
                "(Rule 6; BUILD-target purity tags), schema_tests_tagged "
                "(Rule 7; schema-factory libraries with `schema`-tagged "
                "tests), negative_tests_tagged (Rule 8; effect / schema "
                "libraries with `negative`-tagged tests), "
                "utility_dir_isolation (Rule 4; import-popular modules "
                "outside utility directories). Returns structured "
                "findings list + summary."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "rules": {
                        "type": "array",
                        "items": {
                            "enum": [
                                "schema_as_functions",
                                "test_purity_tagging",
                                "schema_tests_tagged",
                                "negative_tests_tagged",
                                "utility_dir_isolation",
                                "effect_inline_advisory",
                                "async_parity_advisory",
                                "interceptor_reuse_advisory",
                                "refactor_advisory",
                            ],
                        },
                        "description": (
                            "Subset of rules to run. Empty / omitted → "
                            "run all 5."
                        ),
                    },
                    "paths": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": (
                            "Project-relative paths to scan. Empty → "
                            "walk from project root respecting hardcoded "
                            "denylist (bazel-*, __pycache__, .venv, etc.)."
                        ),
                    },
                    "severity_filter": {
                        "enum": ["fail", "warn", "info"],
                        "description": (
                            "Suppress findings below this severity in "
                            "the response. Default: include all."
                        ),
                    },
                },
            },
        ),
        Tool(
            name="migrate_to_3_5",
            description=(
                "Capture env-var tokens into the daemon's encrypted "
                "credentials store (#332 / Phase D3b.4f). Dry-run "
                "by default; pass apply=True to mutate. Backs up "
                "state-dir + .claude/ to .claude/backups/migration-"
                "3.5-<utc-ts>/ for rollback via "
                "migrate_to_3_5_rollback. Idempotent: re-run when "
                "credentials.enc exists returns is_clean=True. "
                "Manual steps include the .git/config token-scrub "
                "recommendation closing the carryover Codeberg "
                "leak from #302/#316."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "apply": {
                        "type": "boolean",
                        "description": (
                            "False (default) → dry-run; "
                            "True → execute with backup."
                        ),
                        "default": False,
                    },
                },
            },
        ),
        Tool(
            name="migrate_to_3_5_rollback",
            description=(
                "Restore state-dir + .claude/ from a backup "
                "produced by migrate_to_3_5(apply=True). The "
                "backup path is in the migrate_to_3_5 response's "
                "`backup_path` field."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "backup_path": {
                        "type": "string",
                        "description": (
                            "Absolute path to the backup directory."
                        ),
                    },
                },
                "required": ["backup_path"],
            },
        ),
        Tool(
            name="analyze_gaps",
            description=(
                "Run registered gap-analysis detectors against the "
                "project (#348 / 3.6.0 Theme G). Detects what's "
                "missing — capability not implemented, security "
                "concern not addressed, usability gap not closed, "
                "test coverage missing, etc. Returns findings + "
                "by_category + by_severity summaries. Heuristic, "
                "NOT authoritative — operators triage findings as "
                "candidates for review. Mirrors check_code_design "
                "shape; the kind of finding differs (gaps vs "
                "code-design rule violations)."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "detectors": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": (
                            "Subset of detectors to run. Empty / "
                            "omitted → run all registered."
                        ),
                    },
                    "paths": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": (
                            "Project-relative paths to scan. Empty "
                            "→ walk from project root."
                        ),
                    },
                    "severity_filter": {
                        "enum": ["fail", "warn", "info"],
                        "description": (
                            "Suppress findings below this severity. "
                            "Default: include all."
                        ),
                    },
                },
            },
        ),
        Tool(
            name="get_code_design_status",
            description=(
                "Run all code-design evaluators against the project "
                "and return a summary (#345 / Phase D3b.4r). Same "
                "shape as the open_session.code_design_status field "
                "but invokable mid-session for re-checks after "
                "edits. Returns {findings: [...], by_severity: "
                "{fail, warn, info}, by_tier: {mechanical, advisory}}."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "severity_filter": {
                        "enum": ["fail", "warn", "info"],
                        "description": (
                            "Minimum severity to return. Default "
                            "'info' (all findings)."
                        ),
                    },
                },
            },
        ),
        Tool(
            name="migrate_to_4_0",
            description=(
                "Migrate forge-config.json from 3.x schema to 4.0 "
                "(#299 / 3.6.0 Theme A). Moves top-level "
                "discussion_categories into per-platform "
                "configuration so each backend can declare its own. "
                "Hard-cutover per Discussion #6 OQ1; dry-run by "
                "default; apply=True backs up .claude/ to "
                ".claude/backups/migration-4.0-<utc-ts>/ for "
                "rollback via migrate_to_4_0_rollback. Idempotent: "
                "re-run when schema_version == '4.0' is a no-op."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "apply": {
                        "type": "boolean",
                        "description": (
                            "False (default) → dry-run; "
                            "True → execute with backup."
                        ),
                        "default": False,
                    },
                },
            },
        ),
        Tool(
            name="migrate_to_4_0_rollback",
            description=(
                "Restore .claude/ from a backup produced by "
                "migrate_to_4_0(apply=True). The backup path is in "
                "the migrate_to_4_0 response's `backup_path` field."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "backup_path": {
                        "type": "string",
                        "description": (
                            "Absolute path to the backup directory."
                        ),
                    },
                },
                "required": ["backup_path"],
            },
        ),
        Tool(
            name="get_daemon_status",
            description=(
                "Probe the daemon's current health and report a "
                "snapshot (#340 / Phase D3b.4n). Returns "
                "{running, version, version_match, credentials_"
                "loaded, config_loaded, warnings}. Best-effort — "
                "when no daemon is running, returns the empty-"
                "snapshot shape with running=False. Useful mid-"
                "session for re-probing after manual restart / "
                "config edit."
            ),
            inputSchema={
                "type": "object",
                "properties": {},
            },
        ),
        Tool(
            name="get_daemon_alerts",
            description=(
                "Poll the daemon's retained alert log (#341 / "
                "Phase D3b.4o). Returns alerts the daemon recorded "
                "since the optional `since` cursor, newest-first. "
                "Best-effort — when no daemon is running or the "
                "alert log is empty / unreachable, returns an empty "
                "list. Used mid-session for 'show me recent daemon "
                "activity' queries; session-start surfacing is via "
                "open_session's `daemon_alerts` field."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "since": {
                        "type": "string",
                        "description": (
                            "ISO-8601 timestamp; only alerts newer "
                            "than this are returned. Omit to fetch "
                            "the full retained log."
                        ),
                    },
                    "level": {
                        "enum": ["info", "warning", "error", "critical"],
                        "description": (
                            "Minimum severity. Omit for all levels."
                        ),
                    },
                    "limit": {
                        "type": "integer",
                        "minimum": 1,
                        "description": (
                            "Cap on returned entries. Omit for the "
                            "daemon's full log capacity."
                        ),
                    },
                },
            },
        ),
    ]
