"""Gap-analysis framework for the `analyze_gaps` MCP tool
(Phase 3.6.0 D1 / #348).

Sibling of `code_design/`. Same factory + registry + Protocol
pattern. The kind of finding differs: code-design findings flag
what's wrong with present code; gap-analysis findings flag what's
missing — capability not implemented, security concern not
addressed, usability gap not closed, etc.

Per #348 catalog the 20 categories are taxonomized in
``GapCategory``. Initial detectors landing in 3.6.0 D1:

- ``capability_gap`` — missing capabilities relative to declared
  scope (config, RFC, plan).
- ``security_gap`` — heuristic surface scan for unauthenticated
  endpoints, missing input validation, etc.
- ``usability_gap`` — operator-experience surface gaps (error
  messages without next-step, missing CLI flags, etc.).
- ``test_coverage_gap`` — modules with `<threshold>%` test
  coverage.

Subsequent detectors land in 3.6.x as the framework's value is
proven via D2's retrospective dogfood on the 3.5.0 plan.

Each detector lives in its own module with its own library target
per Test Dep-Graph Discipline; this `__init__` is the re-export
surface only.
"""
from forge_manager_mcp.gap_analysis._types import (
    GapCategory,
    GapSeverity,
    gap_finding_to_dict,
    make_gap_finding,
    make_gap_location,
)
from forge_manager_mcp.gap_analysis.registry import (
    all_detectors,
    clear_registry,
    get_detector,
    register_detector,
)


# Side-effect imports: each detector registers itself at import time
# via ``register_detector(NAME, detect)``. Initial 2 detectors landed
# in D1 (3.6.0); the remaining 3 (capability / security / usability)
# land in D3 (3.7.0). This __init__ stays the package's re-export
# surface.
from forge_manager_mcp.gap_analysis import test_coverage_gap  # noqa: F401
from forge_manager_mcp.gap_analysis import acceptance_unmet_gap  # noqa: F401
from forge_manager_mcp.gap_analysis import capability_gap  # noqa: F401
from forge_manager_mcp.gap_analysis import security_gap  # noqa: F401
from forge_manager_mcp.gap_analysis import usability_gap  # noqa: F401


__all__ = [
    "GapCategory",
    "GapSeverity",
    "all_detectors",
    "clear_registry",
    "gap_finding_to_dict",
    "get_detector",
    "make_gap_finding",
    "make_gap_location",
    "register_detector",
]
