"""MCP-side daemon client (Phase D3a / 3.5.0).

The MCP discovers the running daemon via the discovery file
(``daemon.json`` under the per-project state-dir). When the daemon
is absent or stale, ``spawn_if_needed`` auto-spawns a fresh one
via ``subprocess.Popen`` with detachment flags.

Per #298 sub-RFC §Install tiers, this is **Tier 1 — Auto-spawn
from MCP** — the default install. No OS-level service required.
The MCP first-call detects no daemon → spawns one → daemon
double-forks (Unix) or detaches (Windows) → writes discovery
file → MCP retries.

Per #298 OQ2 closure: ``forge-config.json.daemon.auto_spawn = false``
forces degraded mode (MCP runs in-process LocalStoreAdapter; no
daemon-only features). The auto-spawn knob is read by the caller
(build_server) before this helper is invoked.

**Effect-then-interceptor split (code-design.md Rule 2).**
``probe_daemon`` (HTTP /health probe) and ``spawn_daemon`` (subprocess
spawn) are effect functions. ``spawn_if_needed`` is the orchestrator
that combines them with the discovery-file-read effect.
"""
from __future__ import annotations

import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

import httpx

from forge_manager_mcp.daemon.discovery import (
    discovery_path,
    read_discovery,
)


_HEALTH_TIMEOUT_SECONDS = 2.0
"""Total wall-time for a /health probe. The daemon should respond
in milliseconds; 2s gives generous headroom for cold starts on
slow filesystems."""

_SPAWN_WAIT_SECONDS = 5.0
"""How long to wait for a freshly-spawned daemon to write its
discovery file before giving up. Five seconds is enough for the
HTTP server to bind a port + write the file even on slow VMs."""

_SPAWN_POLL_INTERVAL = 0.1


def read_auth_token(state_dir: Path) -> str | None:
    """Read auth_token from daemon.json. Returns None if no
    discovery file is present.

    Pure file read — does NOT probe /health. Callers that need
    liveness should pair this with ``probe_daemon``. The token is
    used as ``Authorization: Bearer <token>`` for daemon API calls
    that aren't on the unauth allowlist.

    Effect — file read.
    """
    df = read_discovery(state_dir)
    if df is None:
        return None
    return df.auth_token


async def full_status_probe(
    state_dir: Path,
    expected_version: str,
    *,
    timeout: float = 1.0,
) -> dict:
    """(#340) Comprehensive daemon-health snapshot.

    Returns a dict with the shape::

        {
          "running": bool,
          "version": str | None,
          "version_match": bool,
          "credentials_loaded": bool,    # /credentials reported encrypted_store
          "config_loaded": bool,         # /config returned loaded: true
          "url": str | None,             # http://127.0.0.1:<port>/ when running (#360)
          "warnings": list[str],         # human-readable, operator-actionable
        }

    Best-effort: every probe hop tolerates failure and contributes a
    warning rather than raising. When the daemon is absent the
    snapshot still returns successfully with ``running=False``.

    The MCP calls this once per session-open and exposes the result
    as ``open_session.daemon_status``. Operators / Claude also call
    it mid-session via the ``get_daemon_status`` tool to re-probe
    without re-doing session open.

    (#360, 3.7.0 D0) ``url`` field added so operators can open the UI
    in a browser without ``cat``-ing the discovery file by hand. The
    static-bypass ``/`` mount serves the SolidJS UI without auth, so
    just-the-URL is enough for browser-open; the Bearer token is
    still required for authenticated curl-against-endpoints (lives
    in ``daemon.json`` next to the URL). ``url`` is ``None`` when
    ``running`` is False.
    """
    df = read_discovery(state_dir)
    if df is None:
        return {
            "running": False,
            "version": None,
            "version_match": False,
            "credentials_loaded": False,
            "config_loaded": False,
            "url": None,
            "warnings": [],  # No daemon → no probe → no actionable warnings
        }

    warnings: list[str] = []
    version_match = df.version == expected_version
    if not version_match:
        warnings.append(
            f"daemon version {df.version} does not match MCP "
            f"version {expected_version} — consider `forge-manager-"
            f"mcp daemon-restart` to align"
        )

    # Probe /health to confirm liveness (catches stale-PID).
    running = False
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            health = await client.get(
                f"http://127.0.0.1:{df.port}/health",
            )
            running = health.status_code == 200
    except (httpx.HTTPError, OSError):
        running = False
    if not running:
        warnings.append(
            "daemon discovery file present but /health unreachable "
            "— daemon may have crashed; try `forge-manager-mcp "
            "daemon-restart`"
        )
        return {
            "running": False,
            "version": df.version,
            "version_match": version_match,
            "credentials_loaded": False,
            "config_loaded": False,
            "url": None,  # not running → no clickable URL (#360)
            "warnings": warnings,
        }

    # Probe /config + /credentials with auth.
    headers = {"Authorization": f"Bearer {df.auth_token}"}
    config_loaded = False
    credentials_loaded = False
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            config_resp = await client.get(
                f"http://127.0.0.1:{df.port}/config", headers=headers,
            )
            if config_resp.status_code == 200:
                payload = config_resp.json()
                config_loaded = bool(payload.get("loaded"))
            cred_resp = await client.get(
                f"http://127.0.0.1:{df.port}/credentials",
                headers=headers,
            )
            if cred_resp.status_code == 200:
                cpayload = cred_resp.json()
                if cpayload.get("loaded") is False:
                    # Daemon has no state-dir / platform list — same
                    # state as no encrypted store; not a warning.
                    credentials_loaded = False
                else:
                    entries = cpayload.get("credentials", [])
                    has_store = any(
                        e.get("source") == "encrypted_store" for e in entries
                    )
                    has_error = any(
                        e.get("source") == "error" for e in entries
                    )
                    credentials_loaded = has_store
                    if has_error:
                        warnings.append(
                            "encrypted credential store could not be "
                            "decrypted; using env-var fallback — "
                            "consider `migrate_to_3_5 --apply` to "
                            "rebuild"
                        )
    except (httpx.HTTPError, OSError, ValueError):
        warnings.append(
            "daemon /config or /credentials probe failed — daemon "
            "may be in a partial-init state; check `daemon-logs`"
        )

    if not config_loaded:
        warnings.append(
            "daemon has not loaded forge-config.json — likely "
            "spawned without --project-dir (#338) or pre-bootstrap; "
            "MCP restart may resolve"
        )

    return {
        "running": running,
        "version": df.version,
        "version_match": version_match,
        "credentials_loaded": credentials_loaded,
        "config_loaded": config_loaded,
        # (#360, 3.7.0 D0) Operator can paste this URL into a browser
        # to open the SolidJS UI without inspecting daemon.json.
        "url": f"http://127.0.0.1:{df.port}/",
        "warnings": warnings,
    }


async def fetch_alerts(
    state_dir: Path,
    *,
    since: str | None = None,
    level: str | None = None,
    limit: int | None = None,
    timeout: float = 1.0,
) -> list[dict]:
    """Poll the daemon's GET /alerts (#341).

    Returns the list of alerts (newest-first) or [] on any failure
    (no discovery file, daemon down, network error, auth reject,
    non-200, malformed JSON). Best-effort: callers MUST not depend
    on freshness; the daemon's retained log is a fallback channel,
    not the source of truth.

    The MCP polls this on session-open via ``open_session`` to
    surface daemon-side events the operator missed while the UI was
    closed. Cursor management (which alerts have been observed) is
    the caller's job — pass ``since=<iso-ts>`` of the last observed
    alert to get just-since-then.
    """
    df = read_discovery(state_dir)
    if df is None:
        return []
    params: dict[str, str] = {}
    if since:
        params["since"] = since
    if level:
        params["level"] = level
    if limit is not None:
        params["limit"] = str(limit)
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            response = await client.get(
                f"http://127.0.0.1:{df.port}/alerts",
                headers={"Authorization": f"Bearer {df.auth_token}"},
                params=params,
            )
            if response.status_code != 200:
                return []
            payload = response.json()
            if not isinstance(payload, dict):
                return []
            alerts = payload.get("alerts", [])
            if not isinstance(alerts, list):
                return []
            return alerts
    except (httpx.HTTPError, OSError, ValueError):
        return []


async def post_alert_to_daemon(
    state_dir: Path, alert: dict, *, timeout: float = 0.5,
) -> bool:
    """MCP→daemon alert publish (#341).

    The MCP's natural alert surface — version-mismatch detection,
    daemon-spawn failures, etc. — pushes into the same retained log
    the UI sees. Best-effort: silently returns False on any failure
    so an unreachable daemon doesn't poison MCP startup paths.

    ``alert`` is a dict matching ``alert_to_dict`` shape:
    ``{level, message, detail, platform_id, timestamp, tags}`` —
    daemon-side ``alert_from_dict`` tolerates partials (missing
    timestamp → daemon-now).
    """
    df = read_discovery(state_dir)
    if df is None:
        return False
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            response = await client.post(
                f"http://127.0.0.1:{df.port}/alerts",
                headers={"Authorization": f"Bearer {df.auth_token}"},
                json=alert,
            )
            return response.status_code == 200
    except (httpx.HTTPError, OSError):
        return False


# --- Alert cursor (per-project state-dir) ---------------------------------

_ALERT_CURSOR_FILENAME = "observed_alerts_cursor.json"


def _alert_cursor_path(state_dir: Path) -> Path:
    return state_dir / _ALERT_CURSOR_FILENAME


def read_alert_cursor(state_dir: Path) -> str | None:
    """Read the last-observed-alert cursor (#341).

    Returns the ISO-8601 timestamp of the newest alert observed
    in the previous session, or None if no cursor exists yet
    (first run / never-observed). Used by ``open_session`` to fetch
    just the alerts the operator hasn't seen.

    Effect — file read. Returns None on missing-file, malformed
    JSON, or any IO error so cursor failures degrade to "show
    everything" rather than crash session startup.
    """
    p = _alert_cursor_path(state_dir)
    if not p.exists():
        return None
    try:
        import json
        payload = json.loads(p.read_text(encoding="utf-8"))
        cursor = payload.get("cursor")
        return cursor if isinstance(cursor, str) else None
    except (OSError, ValueError):
        return None


def write_alert_cursor(state_dir: Path, cursor: str) -> None:
    """Persist the latest-observed-alert cursor (#341).

    Atomic-replace via tmp + os.replace so a crash mid-write doesn't
    leave a half-written file the next read can't parse. Effect —
    file write.
    """
    import json
    p = _alert_cursor_path(state_dir)
    state_dir.mkdir(mode=0o700, parents=True, exist_ok=True)
    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text(
        json.dumps({"cursor": cursor}), encoding="utf-8",
    )
    import os as _os
    _os.replace(tmp, p)


class DaemonUnavailableError(RuntimeError):
    """Raised by ``dispatch_write`` when the daemon's /writes
    endpoint can't be reached or returns an error.

    Per #355 D5: each migrated MCP write handler catches this and
    surfaces an ``OperationError`` envelope to Claude rather than
    propagating to the user. Auto-spawn (#352) closes the operator-
    visible gap by ensuring the daemon is up before any write
    fires.
    """


async def dispatch_write(
    state_dir: Path,
    op: str,
    args: dict,
    *,
    timeout: float = 30.0,
) -> dict:
    """Dispatch a canonical write through the daemon (Phase D5 /
    #355 / capability 8).

    Reads the discovery file, posts ``{op, args}`` to the daemon's
    ``POST /writes`` with Bearer auth, returns the response JSON.

    Raises ``DaemonUnavailableError`` on:
        * No discovery file (daemon never started).
        * Connection failure / timeout.
        * Non-2xx HTTP response.
        * Malformed JSON in the response.

    The MCP-side handlers that migrate onto this surface in D5.2+
    catch this exception and wrap it into an ``OperationError``
    envelope so Claude sees a structured failure rather than a
    Python traceback. Per Discussion #6 OQ2 closure: "MCP becomes
    a thin adapter that POSTs canonical writes to the daemon".

    Timeout default 30s — accommodates worst-case mirror fan-out
    (canonical write + GitHub round-trip + Codeberg round-trip
    in serial). Faster ops complete in well under a second; the
    timeout is a runaway-process backstop, not a happy-path SLA.
    """
    df = read_discovery(state_dir)
    if df is None:
        raise DaemonUnavailableError(
            "no daemon discovery file — daemon is not running"
        )
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            response = await client.post(
                f"http://127.0.0.1:{df.port}/writes",
                headers={"Authorization": f"Bearer {df.auth_token}"},
                json={"op": op, "args": args},
            )
    except (httpx.HTTPError, OSError) as exc:
        raise DaemonUnavailableError(
            f"daemon /writes unreachable: {type(exc).__name__}: {exc}"
        ) from exc
    if response.status_code != 200:
        raise DaemonUnavailableError(
            f"daemon /writes returned HTTP {response.status_code}: "
            f"{response.text[:300]}"
        )
    try:
        return response.json()
    except ValueError as exc:
        raise DaemonUnavailableError(
            f"daemon /writes response was not valid JSON: {exc}"
        ) from exc


async def dispatch_read(
    state_dir: Path,
    op: str,
    args: dict,
    *,
    timeout: float = 30.0,
) -> dict:
    """(#356, 3.7.0 D8) Dispatch a canonical read through the daemon.

    Mirrors :func:`dispatch_write`: reads the discovery file, posts
    ``{op, args}`` to the daemon's ``POST /reads`` with Bearer auth,
    returns the response JSON.

    Raises ``DaemonUnavailableError`` on:
        * No discovery file (daemon never started).
        * Connection failure / timeout.
        * Non-2xx HTTP response.
        * Malformed JSON in the response.

    The MCP-side handlers that migrate onto this surface in D8.2+
    catch this exception and either propagate (per #356 OQ1
    closure — read-paths handle graceful degradation case-by-case)
    or wrap into an ``OperationError`` envelope, matching the
    handler's existing failure semantics.

    Timeout default 30s — matches dispatch_write. Localhost reads
    complete in milliseconds; the timeout is a runaway-process
    backstop. Reads against a remote canonical (rare today) eat
    the network round-trip.

    Wire shape: returns ``{value: <op-result>}`` (writes return
    ``{value, mirror_warnings}``; reads omit mirror_warnings since
    failover is silent at the manager layer).
    """
    df = read_discovery(state_dir)
    if df is None:
        raise DaemonUnavailableError(
            "no daemon discovery file — daemon is not running"
        )
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            response = await client.post(
                f"http://127.0.0.1:{df.port}/reads",
                headers={"Authorization": f"Bearer {df.auth_token}"},
                json={"op": op, "args": args},
            )
    except (httpx.HTTPError, OSError) as exc:
        raise DaemonUnavailableError(
            f"daemon /reads unreachable: {type(exc).__name__}: {exc}"
        ) from exc
    if response.status_code != 200:
        raise DaemonUnavailableError(
            f"daemon /reads returned HTTP {response.status_code}: "
            f"{response.text[:300]}"
        )
    try:
        return response.json()
    except ValueError as exc:
        raise DaemonUnavailableError(
            f"daemon /reads response was not valid JSON: {exc}"
        ) from exc


async def post_event(
    state_dir: Path, event: str, data: dict, *, timeout: float = 0.5,
) -> bool:
    """Publish an event to the daemon's POST /events. Best-effort.

    Returns True on success (daemon accepted + broadcast); False on
    any failure (no discovery file, daemon down, network error,
    auth rejected, non-200 response). **Failures are intentionally
    silent** — the canonical write that triggered this publish has
    already succeeded; daemon-side event publishing is purely
    decorative for the UI.

    The 0.5s timeout caps how long a slow / unresponsive daemon can
    delay the MCP's flow. localhost should respond in milliseconds;
    beyond half a second we treat the daemon as effectively down.

    Effect — file read (auth_token + port from daemon.json) +
    network IO. Async because httpx's AsyncClient context-managed
    pattern matches the MCP's existing async event-loop runtime.
    """
    df = read_discovery(state_dir)
    if df is None:
        return False
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            response = await client.post(
                f"http://127.0.0.1:{df.port}/events",
                headers={"Authorization": f"Bearer {df.auth_token}"},
                json={"event": event, "data": data},
            )
            return response.status_code == 200
    except (httpx.HTTPError, OSError):
        return False


def probe_daemon(state_dir: Path) -> "DaemonStatus":
    """Read the discovery file + probe /health. Returns status.

    Returns:
        DaemonStatus.RUNNING — discovery file present + /health 200
        DaemonStatus.STALE   — discovery file present, /health failed
        DaemonStatus.ABSENT  — no discovery file
    """
    df = read_discovery(state_dir)
    if df is None:
        return DaemonStatus.ABSENT
    try:
        with httpx.Client(timeout=_HEALTH_TIMEOUT_SECONDS) as client:
            response = client.get(
                f"http://127.0.0.1:{df.port}/health",
            )
            if response.status_code == 200:
                return DaemonStatus.RUNNING
    except (httpx.HTTPError, OSError):
        pass
    return DaemonStatus.STALE


def spawn_daemon(
    state_dir: Path,
    project_name: str,
    *,
    project_dir: Path | None = None,
) -> int:
    """Spawn a daemon process via subprocess.Popen with detachment.

    Returns the spawned PID. Does NOT wait for the daemon's
    discovery file — the caller polls for that via
    ``wait_for_discovery``.

    Detachment:
    - Unix: ``start_new_session=True`` causes setsid; the daemon
      becomes its own session leader and survives the parent's
      exit. ``stdout`` / ``stderr`` go to ``DEVNULL``.
    - Windows: ``CREATE_NEW_PROCESS_GROUP`` flag detaches the
      process group; ``DETACHED_PROCESS`` would also work but
      ``CREATE_NEW_PROCESS_GROUP`` plays better with pythonw.

    The daemon binary is invoked via ``sys.executable -m
    forge_manager_mcp.daemon.main`` rather than the
    ``forge-manager-daemon`` console script, so this works in
    development trees + Bazel sandbox contexts where the script
    isn't on PATH.

    ``project_dir`` (#338): when provided, threads through as
    ``--project-dir <path>`` so the spawned daemon loads the
    project's forge-config.json + constructs its ReplicationManager.
    Without it the daemon is /health-only — capabilities 1 (backend
    pause/resume) and 4 (repo viewer) require a loaded config.
    """
    cmd = [
        sys.executable, "-m", "forge_manager_mcp.daemon.main",
        "--project-name", project_name,
        "--state-dir", str(state_dir),
    ]
    if project_dir is not None:
        cmd.extend(["--project-dir", str(project_dir)])
    kwargs: dict[str, Any] = {
        "stdout": subprocess.DEVNULL,
        "stderr": subprocess.DEVNULL,
    }
    if sys.platform == "win32":
        # Windows: detach via CREATE_NEW_PROCESS_GROUP.
        kwargs["creationflags"] = (
            getattr(subprocess, "DETACHED_PROCESS", 0)
            | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
        )
    else:
        # Unix: become session leader; survives parent exit.
        kwargs["start_new_session"] = True
    proc = subprocess.Popen(cmd, **kwargs)
    return proc.pid


def wait_for_discovery(
    state_dir: Path,
    timeout: float = _SPAWN_WAIT_SECONDS,
) -> bool:
    """Poll for discovery file existence until timeout. Returns
    True if the file appears in time, False otherwise.

    Effect — file IO. Used after ``spawn_daemon`` to bridge the
    spawn → ready window.
    """
    target = discovery_path(state_dir)
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if target.exists():
            return True
        time.sleep(_SPAWN_POLL_INTERVAL)
    return False


def spawn_if_needed(
    state_dir: Path,
    project_name: str,
    *,
    auto_spawn: bool = True,
    project_dir: Path | None = None,
) -> "SpawnResult":
    """Probe + spawn-if-needed orchestrator.

    Returns:
        SpawnResult with `.status`, `.pid` (when known), `.spawned`
        (True if this call started the daemon).

    `auto_spawn=False` forces probe-only mode (per #298 OQ2). The
    caller (build_server) reads `forge-config.json.daemon
    .auto_spawn` and passes through. False keeps degraded-mode
    semantics: returns RUNNING if a daemon is already up, ABSENT
    otherwise — never spawns.

    `project_dir` (#338): threaded through to ``spawn_daemon`` so
    the spawned daemon loads forge-config.json + constructs its
    ReplicationManager. Pre-bootstrap mode (no config file) is
    handled daemon-side via tolerant ``_load_project_config``;
    pass through ``ctx.project_dir`` regardless of bootstrap state.
    """
    status = probe_daemon(state_dir)
    if status == DaemonStatus.RUNNING:
        df = read_discovery(state_dir)
        return SpawnResult(
            status=status,
            pid=df.pid if df else None,
            spawned=False,
        )

    if not auto_spawn:
        return SpawnResult(status=status, pid=None, spawned=False)

    # ABSENT or STALE → spawn fresh. Stale-PID daemons never reply
    # to /health, so the discovery file we have is dead-letter;
    # writing a new daemon's discovery file overwrites it.
    pid = spawn_daemon(state_dir, project_name, project_dir=project_dir)
    if not wait_for_discovery(state_dir):
        return SpawnResult(
            status=DaemonStatus.SPAWN_TIMEOUT, pid=pid, spawned=True,
        )
    # Re-probe to confirm the new daemon is healthy.
    final = probe_daemon(state_dir)
    return SpawnResult(status=final, pid=pid, spawned=True)


# --- Status enum + result dataclass (factory pattern per Rule 5) ---

from enum import Enum
from dataclasses import dataclass
from functools import cache


class DaemonStatus(str, Enum):
    """Daemon liveness states.

    Values are strings so they serialize cleanly in JSON responses
    + log lines. ``str, Enum`` mixin keeps equality with strings
    (``status == "running"`` works).
    """
    RUNNING = "running"
    STALE = "stale"
    ABSENT = "absent"
    SPAWN_TIMEOUT = "spawn_timeout"


@cache
def _spawn_result_class() -> type:
    @dataclass(frozen=True)
    class SpawnResult:
        status: DaemonStatus
        pid: int | None
        spawned: bool
    return SpawnResult


def SpawnResult(*, status, pid, spawned):
    """Factory for SpawnResult values. Per Rule 5 the dataclass
    lives inside the cached helper, not at module level."""
    Cls = _spawn_result_class()
    return Cls(status=status, pid=pid, spawned=spawned)
