"""Filesystem-read effects for the repo viewer (Phase D3b.4p / #343).

Path-traversal validation, directory listing, and bounded file
content reads — extracted from handlers so each is testable with
tmp_path + standalone assertions on the returned shapes / errors.

Returns a uniform ``(value, error)`` tuple shape so handlers can
short-circuit without branching on Exception types. Errors come
back as a ``(status_code, message)`` pair so the handler maps
straight to ``JSONResponse({"error": msg}, status_code=...)``.

3.7.0 D5 / #351 extends the surface from "canonical store only" to
"any of the project's repos in scope". Per-repo enumeration walks
``replication`` (docs canonical), ``project_dir`` (code), and
``config_payload`` (public + related). Each entry advertises
``kind`` ∈ {canonical, dev, publish_target, subsystem,
subsystem_publish, cousin}. ``resolve_path`` accepts an optional
``repo_id`` selecting which repo's root the relative path is
validated against; absent ``repo_id`` preserves the canonical-only
back-compat behavior.
"""
from __future__ import annotations

from pathlib import Path, PurePosixPath


MAX_FILE_BYTES = 1 * 1024 * 1024  # 1 MiB cap per #313 capability 4


def _repo_basename(slug: str) -> str:
    """Return the repo-name component of an ``owner/repo`` slug.

    Empty / single-element slugs return the whole slug. The repo
    enumerator uses this to derive heuristic local-clone paths
    (``~/<basename>``).
    """
    if "/" not in slug:
        return slug
    return slug.rsplit("/", 1)[-1]


def _candidate_local_paths(
    slug: str, anchors: "list[Path]",
) -> "list[Path]":
    """Heuristic search for a locally-cloned repo's directory.

    Walks each anchor (docs-store parent, project-dir parent, $HOME)
    looking for a child directory whose basename matches the slug's
    repo-name. Returns every match in encounter order; callers pick
    the first or fall through to None.
    """
    name = _repo_basename(slug)
    if not name:
        return []
    out: list[Path] = []
    for anchor in anchors:
        if anchor is None:
            continue
        try:
            candidate = anchor / name
        except (TypeError, ValueError):
            continue
        if candidate.is_dir():
            out.append(candidate)
    return out


def enumerate_repos(
    replication, project_dir: "Path | None", config_payload: "dict | None",
) -> "list[dict]":
    """Enumerate repos in the project's scope (3.7.0 D5 / #351).

    Each entry: ``{"id", "label", "path", "kind"}``. ``path`` is an
    absolute filesystem path string; entries with no resolvable
    local clone are omitted (per #351 OQ2 closure: skip rather than
    grey-out).

    Source-of-truth precedence (highest first):
      1. **docs** — ``replication.canonical_store_path()`` (the
         LocalStoreAdapter's docs root). Always present when
         replication has a filesystem canonical.
      2. **code** — ``project_dir`` (the daemon's working dir,
         passed through from ``--project-dir``). Present whenever
         the daemon was started with ``--project-dir``.
      3. **public** — derived from ``config.repos.public`` via
         heuristic search (``_candidate_local_paths``). Present
         when a clone exists under one of the anchor directories.
      4. **related** — one entry per ``config.related_repos[]``,
         label = the repo's basename, kind = the entry's
         ``relationship`` (``subsystem`` / ``cousin`` / etc.).
         Same heuristic clone-discovery as ``public``.
    """
    out: list[dict] = []

    # --- docs (canonical) ---
    if replication is not None:
        try:
            docs_root = replication.canonical_store_path()
        except Exception:
            docs_root = None
        if docs_root is not None and Path(docs_root).is_dir():
            out.append({
                "id": "docs",
                "label": "Docs",
                "path": str(Path(docs_root).resolve()),
                "kind": "canonical",
            })

    # --- code (project_dir) ---
    if project_dir is not None and project_dir.is_dir():
        out.append({
            "id": "code",
            "label": "Code",
            "path": str(project_dir.resolve()),
            "kind": "dev",
        })

    # Anchor directories for heuristic clone-discovery.
    anchors: list[Path] = []
    if replication is not None:
        try:
            docs_root = replication.canonical_store_path()
        except Exception:
            docs_root = None
        if docs_root is not None:
            try:
                anchors.append(Path(docs_root).resolve().parent)
            except OSError:
                pass
    if project_dir is not None:
        try:
            anchors.append(project_dir.resolve().parent)
        except OSError:
            pass
    try:
        anchors.append(Path.home())
    except (RuntimeError, OSError):
        pass

    # --- public (config.repos.public) ---
    seen_paths: set[str] = {entry["path"] for entry in out}
    if config_payload is not None:
        repos_block = config_payload.get("repos") or {}
        public_slug = repos_block.get("public") or ""
        if public_slug:
            for cand in _candidate_local_paths(public_slug, anchors):
                cand_str = str(cand.resolve())
                if cand_str in seen_paths:
                    break
                out.append({
                    "id": "public",
                    "label": "Public",
                    "path": cand_str,
                    "kind": "publish_target",
                })
                seen_paths.add(cand_str)
                break

    # --- related repos ---
    if config_payload is not None:
        for entry in (config_payload.get("related_repos") or []):
            slug = entry.get("repo") or ""
            if not slug:
                continue
            cands = _candidate_local_paths(slug, anchors)
            if not cands:
                continue
            cand_str = str(cands[0].resolve())
            if cand_str in seen_paths:
                continue
            basename = _repo_basename(slug)
            out.append({
                "id": basename,
                "label": basename,
                "path": cand_str,
                "kind": entry.get("relationship") or "related",
            })
            seen_paths.add(cand_str)

    return out


def _repo_root_for(
    repo_id: "str | None", replication,
    project_dir: "Path | None", config_payload: "dict | None",
) -> "tuple[Path | None, tuple[int, str] | None]":
    """Look up the filesystem root for the named ``repo_id``.

    Returns ``(root_path, None)`` on success, or
    ``(None, (status_code, error_msg))`` on failure.

    ``repo_id=None`` resolves to the canonical store (back-compat
    with pre-#351 callers). Unknown ``repo_id`` returns 404.
    """
    if repo_id is None:
        if replication is None:
            return None, (404, "no canonical store configured")
        root = replication.canonical_store_path()
        if root is None:
            return None, (
                404,
                "no canonical filesystem store (canonical adapter is remote)",
            )
        return root, None
    repos = enumerate_repos(replication, project_dir, config_payload)
    for entry in repos:
        if entry["id"] == repo_id:
            return Path(entry["path"]), None
    return None, (404, f"unknown repo_id: {repo_id!r}")


def resolve_path(
    replication, rel: str, *,
    repo_id: "str | None" = None,
    project_dir: "Path | None" = None,
    config_payload: "dict | None" = None,
) -> "tuple[Path | None, tuple[int, str] | None]":
    """Resolve ``?path=`` against the named repo (or canonical when
    ``repo_id`` is None) with traversal validation.

    Returns ``(target_path, None)`` on success, or
    ``(None, (status_code, error_msg))`` on failure. Status:
      * 404 — no canonical store / unknown repo_id
      * 400 — absolute path / `..` components / outside-root resolution
    """
    root, err = _repo_root_for(
        repo_id, replication, project_dir, config_payload,
    )
    if err is not None:
        return None, err
    if not rel:
        return root, None
    posix = PurePosixPath(rel)
    if posix.is_absolute():
        return None, (400, "path must be relative")
    if any(part == ".." for part in posix.parts):
        return None, (400, "path must not contain `..` components")
    target = root / Path(*posix.parts)
    try:
        resolved = target.resolve()
        root_resolved = root.resolve()
    except OSError as exc:
        return None, (400, f"could not resolve path: {exc}")
    if root_resolved not in resolved.parents and resolved != root_resolved:
        return None, (400, "path resolves outside the repo root")
    return resolved, None


def list_directory(target: Path) -> "tuple[list[dict] | None, tuple[int, str] | None]":
    """Sorted directory listing (dirs first, then alpha by name).

    Returns ``([entries], None)`` on success, or
    ``(None, (status_code, error_msg))`` on failure.

    Each entry: ``{"name", "type", "size"}`` with type ∈ "file"/"dir"
    and size set only for files (None for dirs).
    """
    if not target.is_dir():
        return None, (400, f"not a directory: {target.name}")
    try:
        children = sorted(target.iterdir(), key=lambda p: (
            0 if p.is_dir() else 1, p.name.lower(),
        ))
    except OSError as exc:
        return None, (500, f"could not list directory: {exc}")
    entries: list[dict] = []
    for child in children:
        try:
            is_dir = child.is_dir()
            size = None if is_dir else child.stat().st_size
        except OSError:
            continue
        entries.append({
            "name": child.name,
            "type": "dir" if is_dir else "file",
            "size": size,
        })
    return entries, None


def read_text_file(
    target: Path, *, max_bytes: int = MAX_FILE_BYTES,
) -> "tuple[dict | None, tuple[int, str] | None]":
    """UTF-8 text read with size + decode validation.

    Returns ``({"content", "size"}, None)`` on success, or
    ``(None, (status_code, error_msg))`` on failure. Status:
      * 400 — not a regular file
      * 413 — over size cap
      * 415 — not UTF-8 decodable (binary or wrong encoding)
      * 500 — IO error
    """
    if not target.is_file():
        return None, (400, f"not a file: {target.name}")
    try:
        size = target.stat().st_size
    except OSError as exc:
        return None, (500, f"could not stat file: {exc}")
    if size > max_bytes:
        return None, (
            413,
            f"file too large: {size} bytes (max {max_bytes})",
        )
    try:
        content = target.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        return None, (
            415,
            "file is not UTF-8 decodable (binary or wrong encoding)",
        )
    except OSError as exc:
        return None, (500, f"could not read file: {exc}")
    return {"content": content, "size": size}, None
