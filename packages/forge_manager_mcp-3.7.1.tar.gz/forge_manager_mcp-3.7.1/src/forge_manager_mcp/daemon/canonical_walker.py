"""Canonical-store walker (Phase D4.3 / #354 / 3.6.0).

Iterates the LocalStoreAdapter filesystem layout and yields
``(ref_native_id, title, body)`` tuples per artifact for FTS5
population. Three artifact kinds: Issues, Discussions, Sessions.

Layout reference (set by LocalStoreAdapter):

    <docs>/issues/<n>/
        title.md
        body.md
        meta.json
        comments/<utc-ts>-claude.md  (zero or more)
        ...
    <docs>/discussions/<n>/
        title.md
        body.md
        ...
    <docs>/sessions/<session_id>/
        <utc-ts>-opened.json
        <utc-ts>-closed.json
        ...

``ref_native_id`` matches what ``LocalStoreAdapter`` constructs in
``ArtifactRef.native_id`` — ``issues/<n>``, ``discussions/<n>``,
or the session_id verbatim. So an FTS5 hit can map back to the
adapter via the existing ref machinery.

Pure module — read-only IO, no sqlite imports. Effect-then-
interceptor split (Rule 2): the walker is the read-effect; the
caller (``populate_fts5`` in ``action_log.py``) decides what to
do with the rows.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Iterator


def _read_optional(path: Path) -> str:
    """Return file contents, or empty string when absent / unreadable.

    Tolerant of every IO failure mode — the canonical store is
    operator-managed and may have hand-edits, missing files, or
    permission quirks. FTS5 population is best-effort: a single
    unreadable file shouldn't halt the walk.
    """
    try:
        return path.read_text(encoding="utf-8")
    except OSError:
        return ""


def _is_numbered_dir(entry: Path) -> bool:
    """True iff the entry is a directory whose name parses as int.

    Filters out non-artifact entries the operator may have placed
    in issues/ or discussions/ (`.gitignore`, README, stray files).
    """
    return entry.is_dir() and entry.name.isdigit()


def walk_issues(docs_root: Path) -> Iterator[tuple[str, str, str]]:
    """Yield ``(ref_native_id, title, body)`` per Issue artifact.

    ``body`` aggregates the issue's opening-post body plus every
    comment file (concatenated with double-newlines). Per #354 OQ3
    closure: comments live inside the parent's FTS5 row rather than
    a separate comments table — keeps the search surface returning
    artifact-level hits.
    """
    issues_dir = docs_root / "issues"
    if not issues_dir.is_dir():
        return
    for entry in sorted(issues_dir.iterdir()):
        if not _is_numbered_dir(entry):
            continue
        title = _read_optional(entry / "title.md").strip()
        body = _read_optional(entry / "body.md")
        comments_dir = entry / "comments"
        if comments_dir.is_dir():
            for comment_file in sorted(comments_dir.iterdir()):
                if comment_file.suffix != ".md":
                    continue
                body += "\n\n" + _read_optional(comment_file)
        yield f"issues/{entry.name}", title, body


def walk_discussions(docs_root: Path) -> Iterator[tuple[str, str, str]]:
    """Yield ``(ref_native_id, title, body)`` per Discussion artifact.

    Same shape as ``walk_issues`` but rooted at ``discussions/`` —
    Discussions also accept comments via the canonical store's
    comments/ subdir (per recording.md two-turn rule).
    """
    discussions_dir = docs_root / "discussions"
    if not discussions_dir.is_dir():
        return
    for entry in sorted(discussions_dir.iterdir()):
        if not _is_numbered_dir(entry):
            continue
        title = _read_optional(entry / "title.md").strip()
        body = _read_optional(entry / "body.md")
        comments_dir = entry / "comments"
        if comments_dir.is_dir():
            for comment_file in sorted(comments_dir.iterdir()):
                if comment_file.suffix != ".md":
                    continue
                body += "\n\n" + _read_optional(comment_file)
        yield f"discussions/{entry.name}", title, body


def walk_sessions(docs_root: Path) -> Iterator[tuple[str, str]]:
    """Yield ``(session_id, body)`` per Session.

    ``body`` is the concatenation of every session-event JSON's
    ``body`` field, joined with newlines, in chronological order
    (filename sort is chronological since events are timestamped).
    """
    sessions_dir = docs_root / "sessions"
    if not sessions_dir.is_dir():
        return
    for session_dir in sorted(sessions_dir.iterdir()):
        if not session_dir.is_dir():
            continue
        bodies: list[str] = []
        for event_file in sorted(session_dir.iterdir()):
            if event_file.suffix != ".json":
                continue
            try:
                payload = json.loads(event_file.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            body_field = payload.get("body")
            if isinstance(body_field, str) and body_field:
                bodies.append(body_field)
        yield session_dir.name, "\n".join(bodies)
