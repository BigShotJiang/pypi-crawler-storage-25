"""Daemon entry point — ``forge-manager-daemon`` console script
(Phase D3a / 3.5.0).

Starts the HTTP server bound to ``127.0.0.1:0`` (kernel-picked
ephemeral port), generates the auth token, writes the discovery
file, runs the event loop forever (or until idle-timeout — D4
adds that).

**Args.** Optional ``--project-name <name>`` (defaults to
DEFAULT_PROJECT_NAME). Optional ``--state-dir <path>`` overrides
the default state-dir resolution; primarily for testing.

**Lifecycle.**

1. Resolve state-dir + ensure permissions (0o700).
2. Generate session auth_token (256 bits of secrets.token_hex).
3. Find an ephemeral port via ``socket.bind(('127.0.0.1', 0))``.
4. Write daemon.json with PID + port + version + token.
5. Start the starlette app on that port.
6. On clean shutdown (SIGTERM / SIGINT), remove daemon.json.

**Out of scope for D3a.** Auto-spawn detached double-fork (D3a.3
adds the MCP-side spawn helper; the daemon binary itself doesn't
do daemonization here — the MCP's spawn helper handles process
detachment via ``subprocess.Popen(..., start_new_session=True,
stdout=DEVNULL, stderr=DEVNULL)``). Sqlite cache (D3b). Idle-
timeout (D4 / #298 OQ1 — 24h default, configurable).
"""
from __future__ import annotations

import argparse
import asyncio
import secrets
import signal
import socket
import sys
from datetime import datetime, timezone
from pathlib import Path

from forge_manager_mcp import __version__
from forge_manager_mcp.daemon.discovery import (
    make_discovery_file,
    remove_discovery,
    write_discovery,
)
from forge_manager_mcp.daemon.http import make_app, resolve_ui_dist
from forge_manager_mcp.daemon.paths import (
    DEFAULT_PROJECT_NAME,
    ensure_dir,
    log_dir,
    state_dir,
)


def _load_and_populate_credentials(
    state_dir: Path,
    *,
    alert_log=None,
    broadcaster=None,
) -> None:
    """Phase D3b.4e / #331. Read encrypted credentials from state-dir
    + populate ``os.environ`` so ``_build_daemon_replication`` reads
    daemon-managed tokens transparently via the existing
    ``config.get_platform_token`` dispatcher.

    Tolerant: missing-file is silent (first-run / migrate_to_3_5
    not yet executed); decrypt failure logs a warning to stderr,
    publishes a `credentials.decrypt-fail` alert (#341), and falls
    through to env-var path so the daemon stays useful.

    Effect — env mutation + alert publish. Must run BEFORE
    ``_build_daemon_replication``; that's enforced by call ordering
    in ``main()``.
    """
    from forge_manager_mcp.daemon.credentials import (
        CredentialsError,
        load_credentials,
        populate_environ_from_credentials,
    )
    try:
        creds = load_credentials(state_dir)
    except CredentialsError as exc:
        sys.stderr.write(
            f"[forge-manager-daemon] WARN: encrypted credentials "
            f"unreadable, falling through to env vars: {exc}\n"
        )
        # (#341) Publish an alert so the MCP / UI sees this on next
        # session-start poll. Tolerant of missing alert_log /
        # broadcaster (call-site default None for tests / partial
        # initialization).
        if alert_log is not None and broadcaster is not None:
            from forge_manager_mcp.daemon.alerts import make_alert
            from forge_manager_mcp.daemon.events import publish_alert
            publish_alert(broadcaster, alert_log, make_alert(
                level="error",
                message=(
                    "Encrypted credential store failed to decrypt; "
                    "running on environment variables."
                ),
                detail=str(exc),
                tags=("credentials", "decrypt-fail"),
            ))
        return
    if creds is None:
        return  # No encrypted store → env-var path stays authoritative.
    populate_environ_from_credentials(creds)


def _platform_ids_from_config(config_payload: dict | None) -> list[str] | None:
    """Extract platform ids from the parsed config payload.

    Returns None when no config is loaded (so /credentials reports
    not-loaded). Returns a (possibly empty) list otherwise; an
    empty list means the operator's config has no platforms
    declared, which is unusual but valid (pre-bootstrap edit).
    """
    if config_payload is None:
        return None
    platforms = config_payload.get("platforms") or []
    return [p["id"] for p in platforms if "id" in p]


def _build_daemon_replication(project_dir: Path | None):
    """Construct the daemon's ReplicationManager from project_dir.

    Reuses the MCP's ``_build_replication`` factory so the daemon
    sees the same backend list. Returns None on any failure
    (missing project_dir, config load failure, manager-construction
    failure) — the daemon stays useful for /health + /config even
    when /backends has nothing to report.

    GitHub token resolution: defaults to ``os.environ['GITHUB_TOKEN']``
    when set, empty string otherwise. Empty string triggers the 2.x
    fallback path's GitHubAdapter degraded-mode behavior; non-GitHub
    adapter token resolution goes through ``config.get_platform_token``
    per the 3.2.0 #283 dispatcher.

    Per #331: ``_load_and_populate_credentials`` runs before this so
    daemon-managed tokens land in ``os.environ`` first; the existing
    dispatcher then reads them on the env-var path.
    """
    if project_dir is None:
        return None
    try:
        from forge_manager_mcp.config import load_config
        from forge_manager_mcp.server.build import _build_replication
        import os
        config = load_config(project_dir)
        github_token = os.environ.get("GITHUB_TOKEN", "")
        return _build_replication(config, github_token)
    except Exception:
        # Tolerate every failure mode — the daemon stays useful
        # without backend state. The /backends endpoint reports
        # an empty list when replication is None.
        return None


def _load_project_config(
    project_dir: Path | None,
) -> tuple[dict | None, str | None]:
    """Load the project's GithubConfig if ``project_dir`` is set.

    Returns ``(payload, error)`` — exactly one is non-None.
    ``payload`` is the JSON-serializable dict (model_dump output).
    ``error`` is a string describing why load failed.

    When ``project_dir`` is None, returns ``(None, None)`` —
    /config will report ``loaded=False, reason="no --project-dir
    passed"`` from the make_app fallback.

    Failure modes covered (each returns a specific reason string):
      * Path doesn't exist
      * Path isn't a directory
      * No forge-config.json / github-config.json under .claude/
      * JSON parse error
      * Pydantic validation error
    """
    if project_dir is None:
        return (None, None)
    if not project_dir.exists():
        return (None, f"project_dir does not exist: {project_dir}")
    if not project_dir.is_dir():
        return (None, f"project_dir is not a directory: {project_dir}")
    try:
        from forge_manager_mcp.config import ConfigError, load_config
        config = load_config(project_dir)
        return (config.model_dump(mode="json"), None)
    except Exception as exc:
        # Catch broadly per the daemon's tolerate-everything contract;
        # ConfigError is the expected case but other exceptions
        # (filesystem permission, Pydantic version mismatch) get the
        # same fall-through.
        return (None, f"config load failed: {type(exc).__name__}: {exc}")


def _pick_ephemeral_port() -> int:
    """Bind to 127.0.0.1:0 to let the kernel pick a free port,
    then close. Race window between close and re-bind is small
    enough that production use is safe; tests bind directly via
    uvicorn config.
    """
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        sock.bind(("127.0.0.1", 0))
        return sock.getsockname()[1]
    finally:
        sock.close()


def _generate_token(nbits: int = 256) -> str:
    """Random hex token. 256 bits = 64 hex chars; sufficient
    entropy for localhost-only auth."""
    return secrets.token_hex(nbits // 8)


def _parse_args(argv: list[str] | None = None):
    parser = argparse.ArgumentParser(
        prog="forge-manager-daemon",
        description=(
            "Long-lived per-project HTTP service for forge-manager. "
            "Listens on 127.0.0.1:<random>; writes discovery file "
            "with auth token; serves MCP requests until shutdown."
        ),
    )
    parser.add_argument(
        "--project-name",
        default=DEFAULT_PROJECT_NAME,
        help="Per-project state-dir name (default: %(default)s).",
    )
    parser.add_argument(
        "--state-dir",
        type=Path,
        default=None,
        help="Override the default state-dir resolution. Primarily "
        "for testing; production runs use the auto-resolved path.",
    )
    parser.add_argument(
        "--project-dir",
        type=Path,
        default=None,
        help="Path to the forge-managed project's working directory "
        "(parent of `.claude/forge-config.json`). When provided, the "
        "daemon loads the project's GithubConfig at startup and "
        "serves it via GET /config. When omitted, /config returns "
        "{loaded: false, reason: ...}.",
    )
    return parser.parse_args(argv)


def _configure_file_logging(project_name: str) -> None:
    """(#339) Wire a RotatingFileHandler into the daemon's logging.

    Path: ``<log-dir>/forge-manager.log`` per ``daemon/paths.log_dir``.
    Rotation: 10 MB × 5 files per #298 OQ5 closure.

    Uvicorn's logger (and the root logger) both pick up the handler
    so request-level + application-level messages land in the same
    file. This makes ``forge-manager-mcp daemon-logs`` useful.
    """
    import logging
    from logging.handlers import RotatingFileHandler

    ld = log_dir(project_name)
    ensure_dir(ld, mode=0o700)
    log_path = ld / "forge-manager.log"

    handler = RotatingFileHandler(
        log_path, maxBytes=10 * 1024 * 1024, backupCount=5,
        encoding="utf-8",
    )
    handler.setFormatter(logging.Formatter(
        "%(asctime)s %(levelname)s %(name)s %(message)s",
    ))
    handler.setLevel(logging.INFO)

    # Wire into root + uvicorn loggers so both paths land in the
    # file. Idempotent across daemon restarts because Python's
    # logging keeps a singleton-per-name registry — duplicate
    # adds via fresh process == new handler instance.
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    root.addHandler(handler)
    for name in ("uvicorn", "uvicorn.error", "uvicorn.access"):
        logging.getLogger(name).addHandler(handler)


async def _serve(app, host: str, port: int) -> None:
    """Run the starlette app via uvicorn (the de-facto starlette
    runner). Blocks until the server stops.
    """
    import uvicorn
    config = uvicorn.Config(
        app, host=host, port=port,
        log_level="warning",   # quiet by default; daemon logs to file in D4
        access_log=False,
    )
    server = uvicorn.Server(config)
    await server.serve()


def main(argv: list[str] | None = None) -> int:
    """Entry point. Returns process exit code.

    The console script in pyproject.toml binds this to
    ``forge-manager-daemon``.
    """
    args = _parse_args(argv)

    sd = args.state_dir if args.state_dir is not None else state_dir(args.project_name)
    ensure_dir(sd, mode=0o700)

    # (#339) Configure file logging — writes to <log-dir>/forge-
    # manager.log so `forge-manager-mcp daemon-logs` has something
    # to tail. Call early so startup messages are captured.
    _configure_file_logging(args.project_name)

    auth_token = _generate_token()
    port = _pick_ephemeral_port()
    started_at = datetime.now(timezone.utc)

    # Phase D3b.3: load the project's GithubConfig if --project-dir
    # was passed. Tolerate every failure mode (missing file,
    # malformed JSON, validation error) — the daemon stays useful
    # for /health probes and future endpoint surfaces even when no
    # config is loaded.
    config_payload, config_load_error = _load_project_config(
        args.project_dir,
    )

    # (#333 / #341 / #354) Construct broadcaster + alert log up front
    # so they can be threaded into both the credentials-load path
    # (decrypt-fail alert source) and the ReplicationManager state-
    # change listener (degraded alert source) before the HTTP app
    # is built. Per #354 / D4.2 the alert log is sqlite-backed —
    # alerts survive daemon restart. ensure_schema() is idempotent
    # so the second-and-subsequent daemon-of-this-project run is a
    # no-op.
    from forge_manager_mcp.daemon.events import (
        EventBroadcaster, make_event, publish_alert,
    )
    from forge_manager_mcp.daemon.alerts import make_alert
    from forge_manager_mcp.daemon.action_log import (
        SqliteAlertLog,
        ensure_schema,
        open_connection,
    )
    broadcaster = EventBroadcaster()
    action_log_con = open_connection(sd)
    ensure_schema(action_log_con)
    alert_log = SqliteAlertLog(action_log_con)

    # Phase D3b.4e (#331): populate os.environ from the encrypted
    # credentials store BEFORE _build_daemon_replication so the
    # existing get_platform_token dispatcher reads daemon-managed
    # tokens transparently. Tolerant of missing-file (first-run /
    # pre-migrate_to_3_5) and decrypt failures (logged, env-var
    # fallthrough). #341: decrypt failure publishes an alert.
    _load_and_populate_credentials(
        sd, alert_log=alert_log, broadcaster=broadcaster,
    )

    # Phase D3b.4: construct the daemon's own ReplicationManager
    # from the loaded config. Per parent RFC #5 §What state the
    # daemon owns: Backend health state is in-memory + cache snapshot,
    # rebuildable from canonical filesystem store. The daemon's
    # manager sees the same backend list the MCP sees (shared
    # forge-config.json) but maintains its own state map. /backends
    # endpoint exposes that map.
    replication = _build_daemon_replication(args.project_dir)

    # (#333 / D3b.4g) Wire the ReplicationManager's state-change
    # listener to the (already-constructed) broadcaster +
    # alert log. State transitions emit a `backend.state_changed`
    # event for the UI; transitions to DEGRADED additionally
    # publish a `backend.degraded` alert (#341) for cross-session
    # surfaces (MCP poll + Claude session-start).
    if replication is not None:
        from forge_manager_mcp.replication.manager import AdapterState

        def _publish_state_change(entry) -> None:
            broadcaster.publish(make_event(
                event="backend.state_changed",
                data={
                    "platform_id": entry.platform_id,
                    "state": entry.state.value,
                    "display_status": entry.state.value,
                    "state_changed_at": entry.state_changed_at.isoformat(),
                    "last_error": (
                        str(entry.last_error)
                        if entry.last_error is not None else None
                    ),
                    "last_error_at": (
                        entry.last_error_at.isoformat()
                        if entry.last_error_at is not None else None
                    ),
                    "next_attempt_at": (
                        entry.next_attempt_at.isoformat()
                        if entry.next_attempt_at is not None else None
                    ),
                },
            ))
            if entry.state == AdapterState.DEGRADED:
                publish_alert(broadcaster, alert_log, make_alert(
                    level="warning",
                    message=(
                        f"Backend {entry.platform_id} degraded: "
                        f"{entry.last_error or 'unknown error'}"
                    ),
                    detail=(
                        str(entry.last_error)
                        if entry.last_error is not None else None
                    ),
                    platform_id=entry.platform_id,
                    timestamp=entry.state_changed_at,
                    tags=("backend", "degraded"),
                ))

        replication.set_on_state_change(_publish_state_change)

    df = make_discovery_file(
        pid=__import__("os").getpid(),
        port=port,
        version=__version__,
        started_at=started_at,
        auth_token=auth_token,
    )
    write_discovery(sd, df)

    app = make_app(
        version=__version__,
        auth_token=auth_token,
        started_at=started_at,
        ui_dist=resolve_ui_dist(),
        broadcaster=broadcaster,
        config_payload=config_payload,
        config_load_error=config_load_error,
        replication=replication,
        state_dir=sd,
        platform_ids=_platform_ids_from_config(config_payload),
        alert_log=alert_log,
        action_log_con=action_log_con,  # (#354 / D4.5) /search endpoint
        project_dir=args.project_dir,  # (#351 / D5) per-repo enumeration
    )

    # Install signal handlers so we clean up the discovery file on
    # SIGTERM / SIGINT. uvicorn handles its own shutdown via the
    # signal; we just add the discovery-file cleanup.
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

    def _cleanup_discovery():
        remove_discovery(sd)

    for sig in (signal.SIGTERM, signal.SIGINT):
        try:
            loop.add_signal_handler(sig, _cleanup_discovery)
        except NotImplementedError:
            # Windows doesn't support add_signal_handler in the
            # event loop. The daemon there relies on the OS signal
            # → uvicorn shutdown path; discovery cleanup runs in
            # the finally below.
            pass

    # (#347 / 3.7.0 D4) Live code-design analyzer — polls
    # project_dir/**/*.py for mtime changes, runs the registered
    # code_design evaluators against each changed file, pushes
    # findings into the alert log. No-op when --project-dir is
    # absent or when the alert log isn't available.
    from forge_manager_mcp.daemon.watch import watch_loop

    async def _serve_with_watch():
        watch_task = asyncio.create_task(
            watch_loop(args.project_dir, alert_log)
        )
        try:
            await _serve(app, "127.0.0.1", port)
        finally:
            watch_task.cancel()
            try:
                await watch_task
            except (asyncio.CancelledError, Exception):
                pass

    try:
        loop.run_until_complete(_serve_with_watch())
    finally:
        _cleanup_discovery()
        loop.close()

    return 0


if __name__ == "__main__":
    sys.exit(main())
