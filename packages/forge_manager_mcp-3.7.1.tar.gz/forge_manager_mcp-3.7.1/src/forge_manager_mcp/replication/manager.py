"""ReplicationManager — coordinates writes + reads across the
configured PlatformAdapters (3.0 / Phase 6).

Design principles (from OQ3 + OQ6):

  * **Local store is canonical.** Every write hits LocalStoreAdapter
    first; only after that succeeds does the manager fan out to
    remote mirrors. A failed local write is fatal; a failed remote
    write degrades that adapter but doesn't fail the call.

  * **Read-path failover.** ``read(...)`` tries adapters in
    ``replication_order``; first one that returns wins. Per-adapter
    classified-unavailable failures (``ForgeUnavailableError``)
    cascade to the next adapter; any other exception propagates.

  * **Per-adapter state machine.** Each adapter carries a state
    (HEALTHY / DEGRADED / RECONCILING). A failed remote write moves
    that one adapter to DEGRADED; the others stay HEALTHY. State
    is in-memory per process; persistence is Phase 7+ work.

The manager is intentionally small at this sub-run — orchestration
shape only. Method coverage on the wrapped adapters is restricted to
the Protocol surface defined in ``adapters.protocol.PlatformAdapter``;
the operations supported here mirror that surface one-for-one.
"""
from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from enum import Enum
from functools import cache
from pathlib import Path
from typing import Any, Awaitable, Callable, Generic, TypeVar

from ..adapters import errors as _adapter_errors
from ..adapters.protocol import PlatformAdapter
from ..adapters.types import (
    ArtifactKind,
    HistoryEntry,
    ImportConflict,
    ImportReport,
    RemoteChange,
)
from .errors import AllAdaptersFailedError, ReplicationWriteError


T = TypeVar("T")


@cache
def _mirror_warning_class() -> type:
    @dataclass(frozen=True)
    class MirrorWarning:
        """One mirror-adapter failure during a write fan-out (#297).

        Mirror failures no longer propagate to the caller — the canonical
        write succeeded; the source of truth is updated; the call has
        logically succeeded. Each mirror failure is recorded as a
        ``MirrorWarning`` and surfaced on the ``WriteResult`` envelope so
        callers can see what didn't replicate without losing the canonical
        result. The op is also queued in the mirror's ``pending_writes``
        for later replay via ``replay_pending``.
        """

        platform_id: str
        """ID of the mirror adapter that failed."""

        operation: str
        """Operation name passed to ``write()`` — same value that goes
        into the pending_writes queue."""

        error_type: str
        """Class name of the raised exception (e.g. ``GitHubError``,
        ``ForgejoError``, ``HTTPError``). For grouping similar failures
        in logs / dashboards."""

        error_message: str
        """``str(exc)`` of the raised exception. Captures status codes,
        paths, and any other detail the adapter encoded into the
        error message."""

    return MirrorWarning


MirrorWarning = _mirror_warning_class()


@cache
def _write_result_class() -> type:
    @dataclass(frozen=True)
    class WriteResult(Generic[T]):
        """Return envelope for ``ReplicationManager.write`` (#297).

        Carries the canonical adapter's result alongside any
        ``MirrorWarning`` instances accumulated during fan-out. Pre-#297,
        ``write()`` returned bare ``T`` and propagated mirror failures —
        masking the canonical success. Now, mirror failures never
        propagate; they surface here.

        Callers that don't care about warnings can read ``.value``
        directly. Callers that do (e.g. handlers building a response
        envelope) walk ``.mirror_warnings`` and surface them on their
        response.
        """

        value: T
        """The canonical adapter's return value — same type the
        operation lambda produces."""

        mirror_warnings: tuple[MirrorWarning, ...] = ()
        """Per-mirror failures recorded during fan-out. Empty tuple when
        every mirror succeeded (or had no eligible mirrors)."""

    return WriteResult


WriteResult = _write_result_class()


class AdapterState(str, Enum):
    """Per-adapter state used by ``ReplicationManager`` to decide
    whether to attempt an operation and how to interpret failures.

    Values are strings so they serialize cleanly into log output and
    future persistence formats.
    """

    HEALTHY = "healthy"
    """All recent operations against this adapter succeeded; the
    next operation is attempted normally."""

    DEGRADED = "degraded"
    """A recent operation failed with a classified-unavailable error
    (token expired, 5xx, network). Read-path skips this adapter on
    the way to a healthy one; write fan-out queues operations for
    later replay."""

    RECONCILING = "reconciling"
    """An adapter is being brought back from DEGRADED — drift detection
    + import_remote_changes are running. Reads + writes are paused
    against this adapter while reconciliation completes."""

    PAUSED = "paused"
    """Operator-driven pause via the daemon's ``POST /backends/{id}/pause``
    endpoint (Phase D3b.4c). Reads + writes skip this adapter same as
    DEGRADED, but the state transition is operator-initiated rather
    than failure-driven, so a single ``ForgeUnavailable`` from another
    adapter shouldn't auto-degrade a paused one. ``resume()`` returns
    the adapter to HEALTHY (skipping reconciliation — operator's
    decision)."""


_PendingOp = Callable[[PlatformAdapter], Awaitable[Any]]


DEGRADED_RECONCILIATION_CADENCE_SECONDS = 60
"""How long after entering DEGRADED before the next reconciliation
attempt is expected. Surfaced via ``_AdapterEntry.next_attempt_at``
so the UI can render "Next attempt at <time>" rather than ask the
operator to refresh blindly. Constant for 3.5.0; exponential
backoff + project-rule override deferred per #333 reconciliation-
cadence section."""


def _now() -> datetime:
    """Current UTC time. Wrapped so tests can monkeypatch this
    single seam without coordinating across the manager's many
    state-mutation sites."""
    return datetime.now(timezone.utc)


@cache
def _adapter_entry_class() -> type:
    @dataclass
    class _AdapterEntry:
        """Internal record per configured adapter."""

        platform_id: str
        adapter: PlatformAdapter
        state: AdapterState = AdapterState.HEALTHY
        last_error: BaseException | None = None
        state_changed_at: datetime = field(default_factory=_now)
        """(#333) Set whenever ``state`` changes. UI uses this to render
        "DEGRADED since X" relative timestamps. Initialized at entry
        construction so HEALTHY-from-start has a stable origin time."""
        last_error_at: datetime | None = None
        """(#333) Set when ``last_error`` is assigned; cleared (None)
        when the error is cleared (e.g., on transition to HEALTHY).
        Distinct from ``state_changed_at`` because a state can change
        without a new error (resume from PAUSED → HEALTHY)."""
        next_attempt_at: datetime | None = None
        """(#333) When the manager's next reconciliation attempt is
        expected. None for HEALTHY / PAUSED (no attempt scheduled).
        Populated for DEGRADED with state_changed_at +
        DEGRADED_RECONCILIATION_CADENCE_SECONDS. Populated for
        RECONCILING with an in-flight estimate (currently same as
        state_changed_at; future: track in-flight start)."""
        pending_writes: list[tuple[str, _PendingOp, str]] = field(default_factory=list)
        """Writes that failed on this adapter while in HEALTHY/DEGRADED;
        drained by ``replay_pending_writes``. Each entry is
        ``(operation_name, op_callable, repo_role)`` — the same callable
        the original ``write()`` was given so replay can re-issue it,
        plus the ``repo_role`` used for coord resolution at queue time
        (#296). Replay re-resolves coords with the stored role so the
        op runs against the correct per-platform coords even if config
        changed between queue and replay."""

    return _AdapterEntry


_AdapterEntry = _adapter_entry_class()


class ReplicationManager:
    """Coordinator across multiple PlatformAdapters.

    Construction:
      * ``adapters`` — ordered list of (platform_id, adapter) pairs.
        First entry is the canonical store (LocalStoreAdapter
        conventionally). Order is also the read-failover order.

    The manager doesn't introspect adapter types; it just routes
    operations through the Protocol's methods. This keeps it
    backend-neutral by construction.
    """

    def __init__(
        self,
        adapters: list[tuple[str, PlatformAdapter]],
        *,
        on_canonical_write: Callable[[str], None] | None = None,
        on_state_change: Callable[["_AdapterEntry"], None] | None = None,
        config: Any = None,
    ):
        """Construct the manager.

        ``on_canonical_write`` is an optional sync callback invoked
        once after every successful canonical write — generic
        live-update wiring point. Pre-3.5.0 it carried the
        SiteRebuilder hook; with Hugo deleted in 3.5.0 (Phase H), the
        hook stays as a generic mechanism the daemon (D3a+) consumes
        for its SSE / WebSocket live-update channel. The callback
        receives the ``operation_name`` string. Failures inside the
        callback are swallowed (the canonical write is the
        authoritative outcome; a broken hook should not poison it).

        ``config`` is the project's ``GithubConfig`` — used by
        ``write`` / ``read`` to resolve per-platform coordinates via
        ``config.coords_for_platform(platform_id, repo_role)`` (#296).
        Passed as ``Any`` to avoid an import cycle with ``models.py``;
        the only attribute touched is ``coords_for_platform``. When
        ``config`` is None (test fixtures, pre-bootstrap), per-platform
        coord resolution falls back to ``("", "")`` and callers that
        passed coords-aware lambdas see empty strings — fine for
        LocalStoreAdapter-only test setups that ignore coords.
        """
        if not adapters:
            raise ValueError(
                "ReplicationManager requires at least one adapter "
                "(typically the canonical LocalStoreAdapter)."
            )
        self._entries: list[_AdapterEntry] = [
            _AdapterEntry(platform_id=pid, adapter=a)
            for pid, a in adapters
        ]
        self._on_canonical_write = on_canonical_write
        self._on_state_change = on_state_change
        self._config = config

    def _coords_for(
        self, platform_id: str, repo_role: str,
    ) -> tuple[str, str]:
        """Resolve per-platform coordinates for the given role (#296).

        Delegates to ``config.coords_for_platform`` when ``config`` is
        present; falls back to ``("", "")`` otherwise.
        """
        if self._config is None:
            return ("", "")
        return self._config.coords_for_platform(platform_id, repo_role)

    # -----------------------------------------------------------------------
    # Introspection
    # -----------------------------------------------------------------------

    def set_on_canonical_write(
        self, callback: Callable[[str], None] | None,
    ) -> None:
        """Replace the canonical-write hook post-construction.

        Pre-3.5.0 ``build_server`` used this to attach the
        SiteRebuilder; with Hugo deleted in Phase H the hook stays
        as a generic mechanism the daemon (D3a+) attaches its
        live-update channel to. Pass ``None`` to detach.
        """
        self._on_canonical_write = callback

    def set_on_state_change(
        self, callback: Callable[["_AdapterEntry"], None] | None,
    ) -> None:
        """(#333) Replace the state-change hook post-construction.

        Daemon attaches a publisher that emits ``backend.state_changed``
        events to its EventBroadcaster so SSE subscribers see live
        transitions without polling. MCP-side ReplicationManagers
        leave this unset — their state map is private to the MCP
        process and doesn't drive UI.
        """
        self._on_state_change = callback

    def _set_state(
        self,
        entry: "_AdapterEntry",
        new_state: AdapterState,
        *,
        error: BaseException | None = None,
    ) -> None:
        """(#333) Single state-mutation site for ``_AdapterEntry``.

        Updates ``state`` + ``state_changed_at`` + ``last_error`` +
        ``last_error_at`` + ``next_attempt_at`` consistently.
        Replaces scattered ``entry.state = AdapterState.X`` writes
        so UI-visible timestamps stay coherent across every
        transition (write fan-out auto-degrade, read fan-out auto-
        degrade, replay auto-degrade, ``pause()`` / ``resume()``,
        reconciliation start).

        Effect on derived fields:

        * Transition to HEALTHY: clears ``last_error`` + ``last_error_at``
          + ``next_attempt_at``. Coming back to healthy means there is
          no pending error and no attempt-scheduled.
        * Transition to PAUSED: clears ``next_attempt_at`` (operator
          paused; no auto-attempt due). Preserves ``last_error`` if
          set so the UI keeps history of why-degraded-led-to-pause.
        * Transition to DEGRADED: sets ``next_attempt_at`` =
          state_changed_at + cadence. Records ``error`` if provided.
        * Transition to RECONCILING: sets ``next_attempt_at`` =
          state_changed_at (in-flight, attempt is "now").

        Idempotent if the new state matches the current state — the
        ``state_changed_at`` is still refreshed so UI sees the
        transition was observed (e.g., a second auto-degrade signal).
        """
        now = _now()
        entry.state = new_state
        entry.state_changed_at = now
        if error is not None:
            entry.last_error = error
            entry.last_error_at = now
        if new_state == AdapterState.HEALTHY:
            entry.last_error = None
            entry.last_error_at = None
            entry.next_attempt_at = None
        elif new_state == AdapterState.PAUSED:
            entry.next_attempt_at = None
        elif new_state == AdapterState.DEGRADED:
            entry.next_attempt_at = now + timedelta(
                seconds=DEGRADED_RECONCILIATION_CADENCE_SECONDS,
            )
        elif new_state == AdapterState.RECONCILING:
            entry.next_attempt_at = now
        if self._on_state_change is not None:
            try:
                self._on_state_change(entry)
            except BaseException:
                # Listener failures don't poison the state machine —
                # same swallow contract as on_canonical_write. The
                # state mutation has already taken effect; an event
                # publish failing must not unwind it.
                pass

    def states(self) -> dict[str, AdapterState]:
        """Snapshot the current per-adapter state map."""
        return {e.platform_id: e.state for e in self._entries}

    def healthy_adapters(self) -> list[str]:
        return [e.platform_id for e in self._entries if e.state == AdapterState.HEALTHY]

    def pending_count(self, platform_id: str) -> int:
        for e in self._entries:
            if e.platform_id == platform_id:
                return len(e.pending_writes)
        raise KeyError(f"unknown platform_id={platform_id!r}")

    def pause(self, platform_id: str) -> None:
        """Operator-driven pause (Phase D3b.4c).

        Sets ``state = PAUSED`` regardless of current state. Reads
        + writes skip the adapter for the duration; the canonical
        write path treats a PAUSED non-canonical adapter the same
        as DEGRADED (queues writes for replay on resume).

        Pausing the canonical adapter is allowed by this method
        (the manager doesn't special-case it) but in practice the
        operator wouldn't — the daemon's UI gates the action with
        a confirmation per #4 capability 1.

        Raises ``KeyError`` for unknown platform_id.
        """
        for e in self._entries:
            if e.platform_id == platform_id:
                self._set_state(e, AdapterState.PAUSED)
                return
        raise KeyError(f"unknown platform_id={platform_id!r}")

    def canonical_store_path(self) -> Path | None:
        """Return the canonical adapter's filesystem path if it's a
        LocalStore, else None (Phase D3b.4d / capability 4).

        Used by the daemon's repo-viewer endpoints (`/files/tree`,
        `/files/content`) to resolve relative paths against the
        canonical store. Returns None when the canonical adapter
        is a remote backend (GitHub / Forgejo / GitLab) — those
        don't expose a filesystem-walkable path; the repo viewer
        is conditional on a LocalStore canonical.
        """
        if not self._entries:
            return None
        canonical = self._entries[0].adapter
        path = getattr(canonical, "path", None)
        if path is None:
            return None
        return Path(path) if not isinstance(path, Path) else path

    def resume(self, platform_id: str) -> None:
        """Operator-driven resume (Phase D3b.4c).

        Sets ``state = HEALTHY`` if currently PAUSED. Skipping
        reconciliation is deliberate — the operator's pause was
        an explicit decision, not a failure-induced degrade, so
        no drift recovery is needed. (RECONCILING is
        DEGRADED→HEALTHY's transition state for failure-induced
        degradation, which has different semantics.)

        Calling resume on a non-PAUSED adapter is a no-op.
        Raises ``KeyError`` for unknown platform_id.
        """
        for e in self._entries:
            if e.platform_id == platform_id:
                if e.state == AdapterState.PAUSED:
                    self._set_state(e, AdapterState.HEALTHY)
                return
        raise KeyError(f"unknown platform_id={platform_id!r}")

    def canonical(self) -> PlatformAdapter:
        """The first entry — by convention the local-canonical store
        per OQ3. Used by handlers that bypass the manager when the
        operation is purely local-bound."""
        return self._entries[0].adapter

    def entries(self) -> list[tuple[str, PlatformAdapter]]:
        """Ordered ``(platform_id, adapter)`` pairs (canonical first).

        Used by callers that need to look up a specific adapter by
        platform_id — e.g., ``_resolve_public_face`` (#280) and the
        diagnostic surfaces that report per-backend state.
        """
        return [(e.platform_id, e.adapter) for e in self._entries]

    # -----------------------------------------------------------------------
    # Read-path failover
    # -----------------------------------------------------------------------

    async def read(
        self,
        op: Callable[[PlatformAdapter, tuple[str, str]], Awaitable[T]],
        *,
        operation_name: str = "read",
        repo_role: str = "private",
    ) -> T:
        """Try ``op`` against each adapter in order; return the first
        one that responds.

        ``op`` receives ``(adapter, (owner, repo))`` — the second arg
        carries per-platform coordinates resolved via ``config
        .coords_for_platform`` (#296). Pre-#296 ``op`` received only
        ``(adapter,)`` and every backend got the project's GitHub
        coords from ``ctx.config.repos.<role>``; that masked a class
        of cross-backend coord-mismatch bugs.

        Adapters in DEGRADED or RECONCILING state are skipped. A
        ``ForgeUnavailableError`` from a HEALTHY adapter degrades it
        and falls through to the next. Any other exception propagates
        immediately (caller-fault errors don't benefit from failover).

        If every adapter is skipped or fails with unavailable,
        ``AllAdaptersFailedError`` is raised.
        """
        errors: dict[str, BaseException] = {}
        for entry in self._entries:
            if entry.state in (
                AdapterState.DEGRADED,
                AdapterState.RECONCILING,
                AdapterState.PAUSED,
            ):
                errors[entry.platform_id] = _adapter_errors.ForgeUnavailableError(
                    f"adapter in state={entry.state.value}; skipped",
                )
                continue
            coords = self._coords_for(entry.platform_id, repo_role)
            try:
                return await op(entry.adapter, coords)
            except Exception as exc:
                # (#362, 3.7.0 D1) Predicate-based dispatch — see
                # the matching block in ``write`` for context. A
                # caller-fault error (404/422 from a stale ref) must
                # propagate to the caller for client-side handling
                # rather than triggering failover-then-fail-then-
                # AllAdaptersFailed semantics.
                if _adapter_errors.is_forge_unavailable(exc):
                    self._set_state(entry, AdapterState.DEGRADED, error=exc)
                    errors[entry.platform_id] = exc
                    continue
                raise
        raise AllAdaptersFailedError(errors)

    # -----------------------------------------------------------------------
    # Write-path fan-out (local-first)
    # -----------------------------------------------------------------------

    async def write(
        self,
        op: Callable[[PlatformAdapter, tuple[str, str]], Awaitable[T]],
        *,
        operation_name: str = "write",
        repo_role: str = "private",
    ) -> WriteResult[T]:
        """Run ``op`` against the canonical adapter first; on success,
        fan out to every other adapter in order. Returns a
        ``WriteResult`` envelope: the canonical result plus per-mirror
        failures (#297). Remote results aren't merged because they're
        mirrors of the same logical artifact.

        ``op`` receives ``(adapter, (owner, repo))`` — the second arg
        carries per-platform coordinates resolved via ``config
        .coords_for_platform`` (#296). Pre-#296 ``op`` received only
        ``(adapter,)`` and every backend got the project's GitHub
        coords; that's why Codeberg fan-out 404'd for every write
        through this session. Handlers either pass coords as direct
        args (e.g., ``adapter.create_issue(owner=coords[0], repo=
        coords[1], ...)``) or rewrite a ref via ``dataclasses.replace
        (ref, owner=coords[0], repo=coords[1])`` before passing to
        ref-based methods.

        Behavior on failure:
          * Canonical adapter fails → ``ReplicationWriteError`` raised;
            no remote fan-out. The local store IS the source of
            truth, so a failed local write is fatal.
          * Remote adapter fails with ``ForgeUnavailableError`` →
            adapter moves to DEGRADED; the failed call is recorded
            for later replay; the manager continues to the next
            adapter. Surfaces as a ``MirrorWarning`` on the
            ``WriteResult``; does not propagate.
          * Remote adapter fails with any other error → recorded as
            ``last_error``, queued for replay, surfaced as a
            ``MirrorWarning``. Does not propagate (#297). Pre-#297
            this propagated to the caller, masking the canonical-
            success outcome; the masking caused a class of bug that
            #297's tracking Issue documents in detail.

        The `pending_writes` queue accepts the failed op regardless of
        which exception type fired — replay logic is the same for
        Unavailable and other errors. The distinction surfaces in
        ``MirrorWarning.error_type`` so callers / dashboards can
        classify if needed.
        """
        canonical_entry = self._entries[0]
        canonical_coords = self._coords_for(
            canonical_entry.platform_id, repo_role,
        )
        try:
            result = await op(canonical_entry.adapter, canonical_coords)
        except BaseException as exc:
            self._set_state(
                canonical_entry, AdapterState.DEGRADED, error=exc,
            )
            raise ReplicationWriteError(
                canonical_entry.platform_id,
                operation_name,
                exc,
            ) from exc

        # Canonical succeeded; invoke the live-update hook (pre-
        # 3.5.0: SiteRebuilder.notify; 3.5.0+ daemon attaches its
        # SSE channel here in D3a) before fanning out to mirrors so
        # the live channel sees the canonical state. Hook errors are
        # swallowed — the canonical write is authoritative.
        if self._on_canonical_write is not None:
            try:
                self._on_canonical_write(operation_name)
            except Exception:  # noqa: BLE001 — see docstring
                pass

        # Canonical succeeded; fan out to mirrors. (#273 F1, 3.7.0 D7)
        # Pre-D7 this loop awaited each mirror serially — every
        # cross-platform write paid the SUM of mirror latencies. With
        # GitHub 403'd today (~5s timeout) and Codeberg responsive
        # (~50-200ms), every dispatch waited ~5s for the GitHub fail
        # before the Codeberg fan-out even started. Now: filter the
        # already-degraded adapters first (they pre-queue without
        # round-tripping per the existing #362 contract), run the
        # remainder concurrently via asyncio.gather, then process
        # results sequentially. State mutations happen post-gather so
        # the per-adapter state machine isn't touched concurrently.
        # asyncio.gather preserves input ordering on results, so
        # MirrorWarning order matches `replication_order` deterministic-
        # ally (the original #297 contract).
        skip_states = (
            AdapterState.DEGRADED,
            AdapterState.RECONCILING,
            AdapterState.PAUSED,
        )
        active_entries: list = []
        for entry in self._entries[1:]:
            if entry.state in skip_states:
                # Already-degraded adapter: queue the write for replay
                # without attempting it (would fail again immediately).
                entry.pending_writes.append((operation_name, op, repo_role))
                continue
            active_entries.append(entry)

        async def _attempt_mirror(entry):
            """Per-mirror op runner. Returns ``None`` on success or
            the captured exception on failure. State mutations happen
            in the caller post-gather to avoid racing the state machine."""
            mirror_coords = self._coords_for(entry.platform_id, repo_role)
            try:
                await op(entry.adapter, mirror_coords)
                return None
            except Exception as exc:  # noqa: BLE001 — see #297 docstring
                return exc

        results: list = []
        if active_entries:
            results = await asyncio.gather(
                *(_attempt_mirror(e) for e in active_entries),
            )

        warnings: list[MirrorWarning] = []
        for entry, outcome in zip(active_entries, results):
            if outcome is None:
                continue
            exc = outcome
            # (#362, 3.7.0 D1) Predicate-based dispatch — duck-types on
            # status_code so legacy GitHubError-shape exceptions are
            # classified correctly even though they don't subclass
            # ForgeError. See manager-write-path docstring for the
            # full transition story.
            if _adapter_errors.is_forge_unavailable(exc):
                self._set_state(entry, AdapterState.DEGRADED, error=exc)
            else:
                # Per #297: caller-fault mirror failure (4xx 404/422,
                # malformed-body, adapter-coords-bug, etc.) — record,
                # queue, continue. State stays unchanged (#297
                # contract); only the error fields update so the UI
                # sees the latest mirror fault without flagging the
                # adapter as degraded.
                entry.last_error = exc
                entry.last_error_at = _now()
            entry.pending_writes.append((operation_name, op, repo_role))
            warnings.append(
                MirrorWarning(
                    platform_id=entry.platform_id,
                    operation=operation_name,
                    error_type=type(exc).__name__,
                    error_message=str(exc),
                )
            )
        return WriteResult(value=result, mirror_warnings=tuple(warnings))

    # -----------------------------------------------------------------------
    # State transitions (Phase 6 sub-run B will add reconciliation glue)
    # -----------------------------------------------------------------------

    def mark_healthy(self, platform_id: str) -> None:
        """Force an adapter back to HEALTHY — used by external probes
        (e.g., the conformance run wrapper) that have independently
        verified the adapter is reachable."""
        for entry in self._entries:
            if entry.platform_id == platform_id:
                self._set_state(entry, AdapterState.HEALTHY)
                return
        raise KeyError(f"unknown platform_id={platform_id!r}")

    def mark_reconciling(self, platform_id: str) -> None:
        for entry in self._entries:
            if entry.platform_id == platform_id:
                self._set_state(entry, AdapterState.RECONCILING)
                return
        raise KeyError(f"unknown platform_id={platform_id!r}")

    # -----------------------------------------------------------------------
    # Replay (Phase D — drain DEGRADED-adapter pending_writes)
    # -----------------------------------------------------------------------

    async def replay_pending_writes(self) -> dict[str, dict]:
        """Drain ``pending_writes`` on every non-canonical adapter.

        For each adapter with queued writes:

          * Probe the adapter via ``adapter.probe()``. If still
            unavailable, leave the queue intact and report
            ``probe_failed`` for that platform.
          * On a successful probe: re-issue each pending op against
            the adapter in queued order. Successful ops drop from
            the queue; ops that still raise ``ForgeUnavailableError``
            stay queued (the adapter went down again mid-replay).
            Other exceptions propagate immediately so caller-fault
            errors don't silently disappear.
          * After a clean drain, mark the adapter HEALTHY again.

        Returns a per-platform report:

            {
              "<platform_id>": {
                  "queued_before": int,
                  "replayed": int,
                  "failed": int,
                  "still_pending": int,
                  "probe_failed": bool,
              }, ...
            }

        Canonical adapter is excluded from the drain — the canonical
        store is the source of truth and shouldn't have pending
        writes (a canonical-write failure raises
        ``ReplicationWriteError`` and never reaches the queue).
        """
        report: dict[str, dict] = {}
        for entry in self._entries[1:]:  # skip canonical
            queued_before = len(entry.pending_writes)
            if queued_before == 0:
                continue

            row: dict[str, Any] = {
                "queued_before": queued_before,
                "replayed": 0,
                "failed": 0,
                "still_pending": queued_before,
                "probe_failed": False,
            }
            report[entry.platform_id] = row

            try:
                ok = await entry.adapter.probe()
            except _adapter_errors.ForgeUnavailableError:
                ok = False
            if not ok:
                row["probe_failed"] = True
                continue

            # Probe passed; replay queued ops in order. Build a fresh
            # queue for ones that still fail with unavailable so the
            # original list isn't mutated mid-iteration.
            remaining: list[tuple[str, _PendingOp, str]] = []
            for op_name, op, op_role in entry.pending_writes:
                # #296 — re-resolve coords with the queue-time repo_role.
                op_coords = self._coords_for(entry.platform_id, op_role)
                try:
                    await op(entry.adapter, op_coords)
                    row["replayed"] += 1
                except _adapter_errors.ForgeUnavailableError as exc:
                    entry.last_error = exc
                    remaining.append((op_name, op, op_role))
                    row["failed"] += 1
            entry.pending_writes = remaining
            row["still_pending"] = len(remaining)
            if not remaining:
                # Fully drained — adapter is back online.
                self._set_state(entry, AdapterState.HEALTHY)
        return report

    # -----------------------------------------------------------------------
    # Local change-set queries (Phase D — time-window complement to drift)
    # -----------------------------------------------------------------------

    async def local_changes_since(
        self,
        *,
        since: datetime,
        kind: ArtifactKind | None = None,
        owner: str = "",
        repo: str = "",
    ) -> list[HistoryEntry]:
        """Return canonical-store history entries newer than ``since``.

        Time-window complement to ``compute_drifts``: instead of "what
        diverges between canonical and remote", this answers "what
        changed locally in the last N hours". Useful for replay
        decisions (which writes might still be propagating?), drift-
        recheck cadences (skip when no local changes), and
        ``import_remote_changes`` reconciliation (knowing local
        history before merging remote state).

        Delegates to the canonical adapter's
        ``aggregate_history_since`` if present. Adapters without a
        history surface (typical of remote backends) raise
        ``NotImplementedError`` — callers should fall back to a
        decomposed approach in that case. The current implementation
        only wires LocalStoreAdapter.
        """
        canonical = self._entries[0].adapter
        method = getattr(canonical, "aggregate_history_since", None)
        if method is None:
            raise NotImplementedError(
                f"Canonical adapter {self._entries[0].platform_id!r} "
                "doesn't expose aggregate_history_since. Time-window "
                "history queries require a history-tracking canonical "
                "(currently LocalStoreAdapter)."
            )
        return await method(since=since, kind=kind, owner=owner, repo=repo)

    # -----------------------------------------------------------------------
    # Drift detection (Phase 6 sub-run B)
    # -----------------------------------------------------------------------

    async def compute_drifts(
        self, *, owner: str, repo: str,
        since: datetime | None = None,
    ) -> dict[str, Any]:
        """Compute the drift between the local-canonical state and
        every remote adapter.

        Returns a mapping of ``platform_id`` → ``DriftReport``. The
        canonical adapter is excluded from the result (it can't drift
        against itself). Adapters in DEGRADED or RECONCILING state are
        skipped with a placeholder report.

        ``since`` (Phase D drift improvement) narrows the scope: when
        set, the canonical snapshot only contains artifacts that
        changed locally since the cutoff. Drift computed against this
        narrowed snapshot answers "what diverges among recent local
        changes" rather than the full set. Pairs with
        ``aggregate_history_since`` for time-window drift checks.

        The canonical adapter must implement an async ``snapshot(owner, repo)``
        method that returns a dict the remote adapters' ``compute_drift``
        understands (currently: LocalStoreAdapter only). Adapters whose
        ``snapshot`` doesn't accept ``since`` get the keyword passed
        through anyway — ``LocalStoreAdapter.snapshot`` honors it; if
        a future canonical adapter doesn't, callers will see a
        ``TypeError`` from the unsupported kwarg, which is the correct
        signal that the adapter needs the extension.
        """
        canonical = self._entries[0].adapter
        snapshot_fn = getattr(canonical, "snapshot", None)
        if snapshot_fn is None or not callable(snapshot_fn):
            raise TypeError(
                f"canonical adapter {self._entries[0].platform_id!r} "
                f"must implement snapshot(owner, repo) for compute_drifts"
            )
        snapshot_kwargs: dict[str, Any] = {"owner": owner, "repo": repo}
        if since is not None:
            snapshot_kwargs["since"] = since
        snapshot = await snapshot_fn(**snapshot_kwargs)

        results: dict[str, Any] = {}
        for entry in self._entries[1:]:
            if entry.state in (
                AdapterState.DEGRADED,
                AdapterState.RECONCILING,
                AdapterState.PAUSED,
            ):
                continue
            try:
                results[entry.platform_id] = await entry.adapter.compute_drift(
                    snapshot,
                )
            except _adapter_errors.ForgeUnavailableError as exc:
                self._set_state(entry, AdapterState.DEGRADED, error=exc)
                # Drift unavailable for this adapter; caller can re-run
                # after the adapter's state recovers.
                continue
        return results

    # -----------------------------------------------------------------------
    # Import remote changes (Phase D — OQ4 foundation)
    # -----------------------------------------------------------------------

    async def import_remote_changes(
        self,
        *,
        source_platform_id: str,
        since: datetime,
        owner: str = "",
        repo: str = "",
    ) -> ImportReport:
        """Pull changes from one configured adapter into the canonical
        store (#274 Phase D foundation for OQ4).

        Steps:

          1. Look up the source adapter by ``source_platform_id`` —
            must be one of the manager's non-canonical adapters.
          2. Call ``source.fetch_remote_changes(since=...)``. Adapters
            without a live implementation raise ``NotImplementedError``;
            propagate that so callers can see exactly which backend
            blocked the import.
          3. Apply each change to the canonical adapter via
            ``apply_remote_change``. Conflicts (local divergence after
            the watermark) accumulate in the report; clean applies go
            in ``applied``; canonical-side declines (unsupported op,
            missing artifact) go in ``skipped``.

        Returns the ``ImportReport`` so callers can surface conflicts
        for manual resolution.
        """
        # Find the source adapter.
        source_entry = next(
            (e for e in self._entries if e.platform_id == source_platform_id),
            None,
        )
        if source_entry is None:
            raise KeyError(
                f"No adapter configured for source_platform_id="
                f"{source_platform_id!r}; known platforms: "
                f"{[e.platform_id for e in self._entries]}"
            )
        if source_entry is self._entries[0]:
            raise ValueError(
                "Cannot import from the canonical adapter — that's "
                "the sink, not a source."
            )

        # Canonical must support apply_remote_change.
        canonical = self._entries[0].adapter
        apply_method = getattr(canonical, "apply_remote_change", None)
        if apply_method is None:
            raise NotImplementedError(
                f"Canonical adapter {self._entries[0].platform_id!r} "
                "doesn't implement apply_remote_change. Import requires "
                "a write-supporting canonical (currently LocalStoreAdapter)."
            )

        # Fetch the changes — propagates NotImplementedError if the
        # source adapter hasn't implemented fetch_remote_changes yet.
        changes = await source_entry.adapter.fetch_remote_changes(
            since=since, owner=owner, repo=repo,
        )

        applied: list[RemoteChange] = []
        conflicts: list[ImportConflict] = []
        skipped: list[RemoteChange] = []
        for change in changes:
            try:
                result = await apply_method(change)
            except _adapter_errors.InvalidArtifactRefError:
                skipped.append(change)
                continue
            if result is None:
                applied.append(change)
            else:
                conflicts.append(result)

        return ImportReport(
            source_platform_id=source_platform_id,
            since=since,
            applied=applied,
            conflicts=conflicts,
            skipped=skipped,
        )
