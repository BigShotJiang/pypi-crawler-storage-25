//! Core types and traits for the Soma computational graph runtime.
//!
//! This crate defines the contracts that all other crates depend on:
//! - [`Filter`] — the computation unit (fit/forward)
//! - [`Value`] — typed data flowing between filters (Tensor, JSON, Bytes)
//! - [`Graph`] — DAG of filter nodes and edges
//! - [`CacheKey`] / [`CacheStore`] — content-addressable caching
//! - [`DataStore`] — abstraction for moving data between workers
//! - [`Schema`] — dtype + shape for compile-time validation
//! - [`Event`] — runtime lifecycle events

pub mod cache;
pub mod error;
pub mod event;
pub mod filter;
pub mod graph;
pub mod schema;
pub mod search;
pub mod store;
pub mod strategy;
pub mod study;
pub mod util;
pub mod value;
pub mod virtual_value;

// Re-export core types for convenience.
pub use cache::{CacheKey, CacheStore, CacheTier, EntryMeta, Origin};
pub use error::{Result, SomaError};
pub use event::{Event, MetricRecord, PlanSummary, RunId, StudyId, TrialId};
pub use filter::{Distribution, Filter, FilterKind, FilterMeta, RemoteTarget, StreamMode};
pub use graph::{Edge, EdgeKind, Graph, Node, NodeId};
pub use schema::{DataType, Dimension, Schema};
pub use search::{Scale, SearchDimension, SearchSpace, Searchable};
#[cfg(feature = "s3")]
pub use store::S3DataStore;
#[cfg(feature = "zarr")]
pub use store::ZarrStore;
pub use store::{
    DataRef, DataStore, LocalDataStore, StorageConfig, StoreMeta, StreamCache, StreamFormat,
    slice_tensor_rows,
};
pub use strategy::{
    ClientSelection, CommunicationProtocol, ExploitStrategy, ExploreStrategy, FederatedAggregation,
    GradientAggregation, Partition, TrainingStrategy,
};
pub use study::{Direction, Objective, PruningStrategy, SearchStrategy, Study, Trial, TrialState};
pub use value::Value;
pub use virtual_value::{ValueStatus, VirtualValue};

// Re-export derive macro
pub use soma_macros::SomaFilter;
