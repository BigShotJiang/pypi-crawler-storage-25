#!/usr/bin/env python3
"""
Python-centric functions such as PyPI metadata retrieval and wheel directory
management.
"""

import functools
import json
import logging
import pathlib
import shutil
from urllib.error import URLError
from urllib.request import urlopen

import requirements

from .common import ENCODING
from .exceptions import BlenderPythonUtilsError

LOGGER = logging.getLogger(__name__)


def get_pypi_metadata(pkg):
    """
    Get the parse JSON metadata for a PyPI package.

    Args:
        pkg:
            the PyPI package name.

    Returns:
        The parsed metadata.
    """
    url = f"https://pypi.org/pypi/{pkg}/json"
    try:
        with urlopen(url) as handle:
            return json.load(handle)
    except (URLError, json.JSONDecodeError) as err:
        raise BlenderPythonUtilsError(err) from err


class WheelCleaner:
    """
    Remove unused wheels from a directory.
    """

    def __init__(self, wheels_dir, requirements_file=None):
        self.wheels_dir = pathlib.Path(wheels_dir).resolve()
        if requirements_file is not None:
            requirements_file = pathlib.Path(requirements_file).resolve()
        self.requirements_file = requirements_file

    @functools.cached_property
    def requirements(self):
        """
        A dict mapping package named to their parsed requirements.
        """
        # Parse the requirements file to determine current requirements.
        with self.requirements_file.open("r", encoding=ENCODING) as handle:
            return {req.name: req for req in requirements.parse(handle)}

    @property
    def has_requirements(self):
        """
        True if there are any requirements.
        """
        return bool(self.requirements)

    def clean(self):
        """
        Clean the wheels directory. If there are no requirements then the
        directly will be removed. Otherwise, only a single version of each
        required package will be kept.
        """
        reqs = self.requirements
        if not reqs:
            try:
                LOGGER.info("Removing %s", self.wheels_dir)
                shutil.rmtree(self.wheels_dir)
            except FileNotFoundError:
                pass
            return

        existing = {}

        # Remove unused wheels.
        for path in self.wheels_dir.glob("*.whl"):
            name, _ = path.name.split("-", 1)
            if name not in reqs:
                LOGGER.info("Removing %s", path)
                path.unlink()
                continue
            existing.setdefault(name, []).append(path)

        # Remove all but the last wheel for each package based on modification time.
        for paths in existing.values():
            if len(paths) > 1:
                paths = sorted(paths, key=lambda p: p.stat().st_mtime)
                for p in paths[:-1]:
                    LOGGER.info("Removing %s", p)
                    p.unlink()
