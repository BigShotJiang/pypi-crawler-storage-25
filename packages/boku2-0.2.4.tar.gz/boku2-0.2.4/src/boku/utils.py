# UTILS
#

from pathlib import Path


def frame(message: str, padding: int = 2) -> str:
    """Decorative frame around a message"""
    chars = "╭╮╰╯─│"
    message_lines = message.split("\n")
    longest_line = max(len(line) for line in message_lines)
    straight_length = longest_line + padding * 2
    lines = [
        f"{chars[5]}{' ' * padding}{line.strip().center(longest_line)}{' ' * padding}{chars[5]}"
        for line in message_lines
    ]
    _message: list[str] = [
        f"{chars[0]}{chars[4] * straight_length}{chars[1]}",
    ]
    _message.extend(lines)
    _message.append(f"{chars[2]}{chars[4] * straight_length}{chars[3]}")
    messages = "\n".join(_message)
    return messages


def yaml_suffixer(taskfile: str) -> str:
    """Add .yaml suffix to taskfile if not present"""
    if not taskfile.endswith((".yaml", ".yml")):
        return f"{taskfile}.yaml"
    return taskfile


def edit_file(file: str | Path) -> None:
    """Edit a file with $EDITOR (or vim)."""
    from os import environ, execvp

    editor = environ.get("EDITOR", "vim")
    execvp(editor, [editor, file])


TASKFILE_TEMPLATE = """# Boku taskfile
version: 0.2.2
author: Boku <hxii@0xff.nu>
description: This is a template taskfile.

tasks:
  task:
    description: This is a task.
    run: echo "Hello, world!"
"""

HELPER_TEMPLATE = """
notify:
  usage: "Show a system notification (works on macOS, Linux with notify-send)"
  run: |
    if command -v osascript >/dev/null; then
      osascript -e 'display alert "{title}" message "{message}"'
    elif command -v notify-send >/dev/null; then
      notify-send "{title}" "{message}"
    else
      echo "{title}: {message}"
    fi
  args:
    - title
    - message
notify_kitten:
  usage: "Send a notification with {title} and {message} via KittyTerm's Kitten utility"
  run: 'kitten notify "{title}" {message}'
  args:
    - title
    - message
download:
  usage: "Download {url} to the current directory using wget"
  run: "wget {url} {flags}"
  args:
    - url
    - flags
http_get:
  usage: "Make an HTTP GET request and display the response"
  run: "curl -s {headers} {url}"
  args:
    - url
    - headers
brew:
  usage: "Install a brew package by specifying the package name"
  run: "brew install {package}"
  args:
    - package
git_clone:
  usage: "Clone a git repository. Repo is URL, dir is optional target directory."
  run: "git clone {repo} {dir}"
  args:
    - repo
    - dir
"""

TASK_SCHEMA = {
    "type": "object",
    "properties": {
        "description": {"type": "string"},
        "run": {"type": "string"},
        "working_dir": {"type": "string"},
        "save_output": {"type": "string"},
        "iterate": {
            "anyOf": [
                {"type": "string"},
                {"type": "array", "items": {"type": "string"}},
                {
                    "type": "array",
                    "items": {"type": "array", "items": {"type": "string"}},
                },
            ]
        },
        "depends_on": {"type": "array", "items": {"type": "string"}},
        "success_code": {"type": "integer"},
        "on_success": {"type": "string"},
        "on_failure": {"type": "string"},
        "use": {"type": "string"},
        "with_arguments": {"type": "object"},
        "if": {"type": "string"},
    },
    "required": ["run"],
}
HELPER_SCHEMA = {
    "type": "object",
    "properties": {
        "usage": {"type": "string"},
        "run": {"type": "string"},
        "args": {
            "type": "array",
            "items": {
                "oneOf": [
                    {"type": "string"},
                    {"type": "object", "additionalProperties": {"type": "string"}},
                ]
            },
        },
    },
    "required": ["usage", "run", "args"],
}
