"""Shared helpers for Form.io schema parsing and component simplification.

These helpers are used by both regular forms (forms.py) and print documents
(print_documents.py). They handle the common patterns of parsing formSchema
from BPA API responses and simplifying component trees for display.
"""

from __future__ import annotations

import json
from typing import Any

from mcp_eregistrations_bpa.tools.formio_helpers import (
    CONTAINER_TYPES,
    MAX_RECURSION_DEPTH,
)

__all__ = [
    "parse_form_schema",
    "simplify_components",
    "build_component_tree",
    "build_registration_name_map",
    "resolve_registration_uuids",
]


def parse_form_schema(form_data: dict[str, Any]) -> dict[str, Any]:
    """Parse formSchema from form data, handling string JSON.

    BPA stores formSchema as a JSON string in a TEXT column. This function
    handles both string and dict formats.

    Args:
        form_data: Form data from BPA API containing 'formSchema' key.

    Returns:
        Parsed form schema dict.
    """
    form_schema = form_data.get("formSchema", {})
    if isinstance(form_schema, str):
        try:
            parsed = json.loads(form_schema)
            return parsed if isinstance(parsed, dict) else {}
        except json.JSONDecodeError:
            return {}
    return form_schema if isinstance(form_schema, dict) else {}


def build_registration_name_map(
    registrations: list[dict[str, Any]] | None,
) -> dict[str, str | None]:
    """Build UUID to name mapping from registrations list.

    Args:
        registrations: List of registration objects with 'id' and 'name' fields.

    Returns:
        Dict mapping registration UUIDs to their names.
    """
    if not registrations or not isinstance(registrations, list):
        return {}
    return {
        str(reg.get("id")): reg.get("name") for reg in registrations if reg.get("id")
    }


def resolve_registration_uuids(
    registrations: dict[str, Any] | None,
    name_map: dict[str, str | None],
) -> dict[str, str | None] | None:
    """Resolve registration UUIDs to names.

    Transforms registrations from {uuid: true} format to {uuid: "name"} format.
    If a UUID cannot be resolved, the value is set to null.

    Args:
        registrations: Component registrations dict ({uuid: true, ...}).
        name_map: UUID to name mapping.

    Returns:
        Dict with UUIDs as keys and registration names as values.
        Returns None if registrations is None or empty.
    """
    if not registrations or not isinstance(registrations, dict):
        return None

    resolved: dict[str, str | None] = {}
    for uuid in registrations:
        resolved[uuid] = name_map.get(uuid)
    return resolved


def simplify_components(
    components: list[dict[str, Any]],
    path: list[str] | None = None,
    registration_name_map: dict[str, str | None] | None = None,
    *,
    visible_only: bool = False,
    _ancestor_hidden: bool = False,
) -> list[dict[str, Any]]:
    """Simplify components for display.

    Recursively traverses the component tree, extracting key properties and
    flattening the hierarchy into a list with path information.

    Args:
        components: Raw Form.io components.
        path: Current nesting path.
        registration_name_map: Optional UUID-to-name map for registration resolution.

    Returns:
        Simplified component list.
    """
    # Handle non-list components (BPA API may return int or other types)
    if not isinstance(components, list):
        return []
    if path is None:
        path = []
    if registration_name_map is None:
        registration_name_map = {}

    result = []
    for comp in components:
        if not isinstance(comp, dict):
            continue

        key = comp.get("key")
        if not key:
            continue

        comp_type = comp.get("type", "unknown")
        simplified: dict[str, Any] = {
            "key": key,
            "type": comp_type,
        }

        if comp.get("label"):
            simplified["label"] = comp["label"]

        # Issue #110: surface panel title (was silently dropped previously)
        if comp.get("title"):
            simplified["title"] = comp["title"]

        if path:
            simplified["path"] = path

        # Add validation info
        validate = comp.get("validate", {})
        if isinstance(validate, dict) and validate.get("required"):
            simplified["required"] = True

        # Add is_container flag for container types
        if comp_type in CONTAINER_TYPES:
            simplified["is_container"] = True

        # Surface hidden/disabled state (own or inherited from ancestor)
        is_hidden = bool(comp.get("hidden")) or _ancestor_hidden
        if is_hidden:
            simplified["hidden"] = True
        if comp.get("disabled"):
            simplified["disabled"] = True

        # Extract determinant_ids from Form.io component (always include, empty if none)
        determinant_ids = comp.get("determinantIds", [])
        if determinant_ids is None:
            determinant_ids = []
        elif not isinstance(determinant_ids, list):
            determinant_ids = [determinant_ids] if determinant_ids else []
        simplified["determinant_ids"] = determinant_ids

        # Resolve registration UUIDs to names
        raw_registrations = comp.get("registrations")
        if raw_registrations:
            resolved = resolve_registration_uuids(
                raw_registrations, registration_name_map
            )
            if resolved:
                simplified["registrations"] = resolved

        # Include component_action_id if present
        if comp.get("componentActionId"):
            simplified["component_action_id"] = comp["componentActionId"]

        # Expose catalog reference for select/resource components
        # Priority: comp.catalog (BPA live) > data.catalog (legacy) > catalogIds[0]
        data = comp.get("data", {})
        catalog_ref = None
        if isinstance(data, dict):
            if data.get("dataSrc"):
                simplified["data_source"] = data["dataSrc"]
            catalog_ref = data.get("catalog")

        top_catalog = comp.get("catalog")
        if top_catalog and isinstance(top_catalog, str) and top_catalog.strip():
            catalog_ref = top_catalog
        elif not (catalog_ref and isinstance(catalog_ref, str) and catalog_ref.strip()):
            # Neither top-level nor data.catalog — try catalogIds
            catalog_ids = comp.get("catalogIds")
            if isinstance(catalog_ids, list) and catalog_ids:
                first_id = catalog_ids[0]
                if isinstance(first_id, str) and first_id.strip():
                    catalog_ref = first_id

        if catalog_ref and isinstance(catalog_ref, str) and catalog_ref.strip():
            simplified["catalog"] = catalog_ref

        # Extract selectable values and compute value_source
        if comp_type in ("radio", "selectboxes"):
            raw_values = comp.get("values")
            if isinstance(raw_values, list) and raw_values:
                simplified["values"] = [
                    {"label": v.get("label", ""), "value": v.get("value", "")}
                    for v in raw_values
                    if isinstance(v, dict)
                ]
                simplified["value_source"] = "static"
            else:
                simplified["value_source"] = "none"
        elif comp_type == "select":
            # Static values take priority (inline data.values list)
            data_values = data.get("values") if isinstance(data, dict) else None
            if isinstance(data_values, list) and data_values:
                simplified["values"] = [
                    {"label": v.get("label", ""), "value": v.get("value", "")}
                    for v in data_values
                    if isinstance(v, dict)
                ]
                simplified["value_source"] = "static"
            elif simplified.get("catalog"):
                # Classification-backed: catalog ref found
                simplified["value_source"] = "classification"
            elif isinstance(data, dict) and data.get("dataSrc") == "url":
                # Legacy URL-based classification detection
                simplified["value_source"] = "classification"
            else:
                simplified["value_source"] = "unresolved"

        # Handle nested components (panels, fieldsets, editgrids, datagrids, etc.)
        children_count = 0
        nested = comp.get("components", [])
        if nested and isinstance(nested, list):
            children_count += len(nested)
            result.extend(
                simplify_components(
                    nested,
                    path + [key],
                    registration_name_map,
                    visible_only=visible_only,
                    _ancestor_hidden=is_hidden,
                )
            )

        # Handle columns (2-level: columns > cells > components)
        columns = comp.get("columns", [])
        if columns and isinstance(columns, list):
            for col in columns:
                if isinstance(col, dict):
                    col_comps = col.get("components", [])
                    if isinstance(col_comps, list):
                        children_count += len(col_comps)
                        result.extend(
                            simplify_components(
                                col_comps,
                                path + [key],
                                registration_name_map,
                                visible_only=visible_only,
                                _ancestor_hidden=is_hidden,
                            )
                        )

        # Handle table rows (rows[][] structure)
        rows = comp.get("rows", [])
        if rows and isinstance(rows, list):
            for row in rows:
                if isinstance(row, list):
                    for cell in row:
                        if isinstance(cell, dict):
                            cell_comps = cell.get("components", [])
                            if isinstance(cell_comps, list):
                                children_count += len(cell_comps)
                                result.extend(
                                    simplify_components(
                                        cell_comps,
                                        path + [key],
                                        registration_name_map,
                                        visible_only=visible_only,
                                        _ancestor_hidden=is_hidden,
                                    )
                                )

        # Add children_count for containers
        if children_count > 0:
            simplified["children_count"] = children_count

        # Filter out hidden components when visible_only is set
        if visible_only and is_hidden:
            continue

        result.append(simplified)

    return result


def build_component_tree(
    components: list[dict[str, Any]] | Any,
    *,
    depth: int | None = None,
    subtree_key: str | None = None,
) -> dict[str, Any]:
    """Build a recursive component tree (issue #110).

    Args:
        components: Raw Form.io components list.
        depth: Max levels to include. depth=1 returns roots only with
            no children field; depth=2 returns roots + direct children;
            None means unlimited.
        subtree_key: Scope to the subtree rooted at the component with
            this key. First match wins on duplicate keys (matches the
            same first-match policy used by find_component). Returns
            empty tree if the key is not found — caller decides how to
            surface that to the user.

    Returns:
        dict with tree, node_count, truncated.

    Raises:
        RecursionError: If the form schema is nested deeper than
            MAX_RECURSION_DEPTH (100). The form_get caller translates
            this into a ToolError(MAX_DEPTH_EXCEEDED).
    """
    if not isinstance(components, list):
        return {"tree": [], "node_count": 0, "truncated": False}

    parent_type: str | None = None
    if subtree_key is not None:
        located = _find_subtree(components, subtree_key)
        if located is None:
            return {"tree": [], "node_count": 0, "truncated": False}
        target_comp, parent_type = located
        components = [target_comp]

    tree, count, truncated = _walk_tree(
        components, parent_type=parent_type, remaining_depth=depth
    )
    return {"tree": tree, "node_count": count, "truncated": truncated}


def _find_subtree(
    components: list[dict[str, Any]],
    target_key: str,
    *,
    parent_type: str | None = None,
    _depth: int = 0,
) -> tuple[dict[str, Any], str | None] | None:
    """Locate the first component matching target_key.

    Returns (comp, parent_type) or None.

    Searches `components`, `columns[].components[]`, and
    `rows[][].components[]` — same accessors that _walk_tree emits from.
    First match wins on duplicate keys.
    """
    if _depth > MAX_RECURSION_DEPTH:
        raise RecursionError(
            f"Component tree exceeds maximum depth of {MAX_RECURSION_DEPTH}"
        )

    for comp in components:
        if not isinstance(comp, dict):
            continue
        if comp.get("key") == target_key:
            return comp, parent_type

        raw_type = comp.get("type")
        comp_type: str
        if raw_type:
            comp_type = raw_type
        elif parent_type == "tabs":
            comp_type = "tab"
        else:
            comp_type = "unknown"

        nested = comp.get("components")
        if isinstance(nested, list):
            found = _find_subtree(
                nested, target_key, parent_type=comp_type, _depth=_depth + 1
            )
            if found is not None:
                return found

        cols = comp.get("columns")
        if isinstance(cols, list):
            for col in cols:
                if isinstance(col, dict):
                    col_comps = col.get("components")
                    if isinstance(col_comps, list):
                        found = _find_subtree(
                            col_comps,
                            target_key,
                            parent_type=comp_type,
                            _depth=_depth + 1,
                        )
                        if found is not None:
                            return found

        rows = comp.get("rows")
        if isinstance(rows, list):
            for row in rows:
                if isinstance(row, list):
                    for cell in row:
                        if isinstance(cell, dict):
                            cell_comps = cell.get("components")
                            if isinstance(cell_comps, list):
                                found = _find_subtree(
                                    cell_comps,
                                    target_key,
                                    parent_type=comp_type,
                                    _depth=_depth + 1,
                                )
                                if found is not None:
                                    return found

    return None


def _walk_tree(
    components: list[dict[str, Any]],
    *,
    parent_type: str | None = None,
    remaining_depth: int | None = None,
    _depth: int = 0,
) -> tuple[list[dict[str, Any]], int, bool]:
    """Recursive walker producing tree nodes and a running node count.

    Returns (nodes, node_count, any_truncation_occurred).

    remaining_depth semantics (issue #110):
        - None → unlimited.
        - 1 → emit nodes at this level but DO NOT descend into children.
        - N>1 → emit and recurse with remaining_depth=N-1.

    Tab pane normalization: when the parent is a 'tabs' container and a
    child has no 'type' key, the child is a tab pane — emit type='tab'.

    Layout hoisting: 'columns' children come from columns[].components[];
    'table' children come from rows[][].components[]. The wrapper
    objects (column / cell) are skipped — their inner components become
    direct children of the columns/table node.

    Raises:
        RecursionError: If the schema is nested deeper than MAX_RECURSION_DEPTH.
    """
    if _depth > MAX_RECURSION_DEPTH:
        raise RecursionError(
            f"Component tree exceeds maximum depth of {MAX_RECURSION_DEPTH}"
        )

    nodes: list[dict[str, Any]] = []
    count = 0
    truncated = False

    descend = remaining_depth is None or remaining_depth > 1
    next_depth = None if remaining_depth is None else remaining_depth - 1

    for comp in components:
        if not isinstance(comp, dict):
            continue
        key = comp.get("key")
        if not key:
            continue

        raw_type = comp.get("type")
        comp_type: str
        if raw_type:
            comp_type = raw_type
        elif parent_type == "tabs":
            comp_type = "tab"
        else:
            comp_type = "unknown"

        node: dict[str, Any] = {"key": key, "type": comp_type}
        if comp.get("label"):
            node["label"] = comp["label"]
        if comp.get("title"):
            node["title"] = comp["title"]

        # Tally raw children count BEFORE deciding whether to recurse —
        # we need this for the children_count truncation marker.
        raw_child_count = 0
        nested = comp.get("components")
        if isinstance(nested, list):
            raw_child_count += sum(
                1 for c in nested if isinstance(c, dict) and c.get("key")
            )
        cols = comp.get("columns")
        if isinstance(cols, list):
            for col in cols:
                if isinstance(col, dict):
                    col_comps = col.get("components")
                    if isinstance(col_comps, list):
                        raw_child_count += sum(
                            1 for c in col_comps if isinstance(c, dict) and c.get("key")
                        )
        rows = comp.get("rows")
        if isinstance(rows, list):
            for row in rows:
                if isinstance(row, list):
                    for cell in row:
                        if isinstance(cell, dict):
                            cell_comps = cell.get("components")
                            if isinstance(cell_comps, list):
                                raw_child_count += sum(
                                    1
                                    for c in cell_comps
                                    if isinstance(c, dict) and c.get("key")
                                )

        if not descend and raw_child_count > 0:
            node["children_count"] = raw_child_count
            truncated = True
        elif descend:
            children: list[dict[str, Any]] = []
            if isinstance(nested, list):
                child_nodes, child_count, child_trunc = _walk_tree(
                    nested,
                    parent_type=comp_type,
                    remaining_depth=next_depth,
                    _depth=_depth + 1,
                )
                children.extend(child_nodes)
                count += child_count
                truncated = truncated or child_trunc
            if isinstance(cols, list):
                for col in cols:
                    if not isinstance(col, dict):
                        continue
                    col_comps = col.get("components")
                    if isinstance(col_comps, list):
                        child_nodes, child_count, child_trunc = _walk_tree(
                            col_comps,
                            parent_type=comp_type,
                            remaining_depth=next_depth,
                            _depth=_depth + 1,
                        )
                        children.extend(child_nodes)
                        count += child_count
                        truncated = truncated or child_trunc
            if isinstance(rows, list):
                for row in rows:
                    if not isinstance(row, list):
                        continue
                    for cell in row:
                        if not isinstance(cell, dict):
                            continue
                        cell_comps = cell.get("components")
                        if isinstance(cell_comps, list):
                            child_nodes, child_count, child_trunc = _walk_tree(
                                cell_comps,
                                parent_type=comp_type,
                                remaining_depth=next_depth,
                                _depth=_depth + 1,
                            )
                            children.extend(child_nodes)
                            count += child_count
                            truncated = truncated or child_trunc

            if children:
                node["children"] = children

        nodes.append(node)
        count += 1

    return nodes, count, truncated
