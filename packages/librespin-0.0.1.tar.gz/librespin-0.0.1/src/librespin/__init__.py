"""
LibreSpin — open-source AI-driven PCB and embedded circuit design workflow tool.

Status: pre-alpha. See https://librespin.org for updates.
"""
