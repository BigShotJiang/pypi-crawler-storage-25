"""Pydantic v2 configuration models for honeypotllm.

Configuration can be loaded from YAML, a dict, or constructed programmatically::

    config = HoneypotConfig(
        suspicion_threshold=0.75,
        watermark=WatermarkConfig(strategies=["lexical", "unicode"]),
        scoring=ScoringConfig(requests_per_minute_threshold=60),
        log_backend="sqlite",
        db_url="sqlite+aiosqlite:///honeypot.db",
    )

Or from YAML::

    config = HoneypotConfig.from_yaml("honeypot_config.yaml")

"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Annotated, Literal

import yaml
from pydantic import BaseModel, Field, field_validator, model_validator

from honeypotllm.exceptions import ConfigurationError

# ─── Watermark Configuration ──────────────────────────────────────────────────


class LexicalWatermarkConfig(BaseModel):
    """Fine-grained settings for the lexical substitution watermarker."""

    substitution_rate: Annotated[float, Field(ge=0.01, le=0.5)] = 0.15
    """Fraction of eligible words to substitute. Lower = stealthier."""

    min_word_length: Annotated[int, Field(ge=2, le=10)] = 4
    """Minimum word length to consider for substitution."""

    target_pos_tags: list[str] = Field(
        default_factory=lambda: ["NN", "VB", "JJ", "RB"],
        description="Penn Treebank POS tags eligible for substitution.",
    )


class SyntacticWatermarkConfig(BaseModel):
    """Fine-grained settings for the syntactic perturbation watermarker."""

    perturbation_rate: Annotated[float, Field(ge=0.01, le=0.5)] = 0.20
    """Fraction of eligible sentences to perturb."""

    operations: list[str] = Field(
        default_factory=lambda: ["oxford_comma", "conjunction_swap", "adverb_insert"],
        description="Syntactic operations to apply.",
    )


class UnicodeWatermarkConfig(BaseModel):
    """Fine-grained settings for the Unicode steganography watermarker."""

    bits_per_space: int = Field(default=1, ge=1, le=4)
    """Number of watermark bits encoded per whitespace character."""

    marker_chars: list[str] = Field(
        default_factory=lambda: ["\u200b", "\u200c"],
        description="Zero-width Unicode characters used to encode bits.",
    )


class WatermarkConfig(BaseModel):
    """Watermarking strategy configuration."""

    strategies: list[Literal["lexical", "syntactic", "unicode", "structural"]] = Field(
        default_factory=lambda: ["unicode", "syntactic"],
        min_length=1,
    )
    """List of watermarking strategies to apply (combinable)."""

    global_seed: int = Field(
        default=42,
        description="Master seed. Combined with per-key watermark_id for key-unique watermarks.",
    )

    lexical: LexicalWatermarkConfig = Field(default_factory=LexicalWatermarkConfig)
    syntactic: SyntacticWatermarkConfig = Field(default_factory=SyntacticWatermarkConfig)
    unicode: UnicodeWatermarkConfig = Field(default_factory=UnicodeWatermarkConfig)


# ─── Scoring Configuration ────────────────────────────────────────────────────


class ScoringConfig(BaseModel):
    """Heuristic weights and thresholds for the suspicion scoring engine."""

    # Rate-based
    requests_per_minute_threshold: Annotated[int, Field(ge=1)] = 30
    requests_per_hour_threshold: Annotated[int, Field(ge=1)] = 500
    requests_per_day_threshold: Annotated[int, Field(ge=1)] = 5000

    # Score contributions (must sum ≤ 1.0; remaining headroom allows combinations)
    rate_weight: Annotated[float, Field(ge=0.0, le=1.0)] = 0.35
    sequential_weight: Annotated[float, Field(ge=0.0, le=1.0)] = 0.30
    gap_weight: Annotated[float, Field(ge=0.0, le=1.0)] = 0.20
    volume_weight: Annotated[float, Field(ge=0.0, le=1.0)] = 0.15

    # Thresholds
    min_gap_seconds: float = Field(
        default=0.5,
        ge=0.0,
        description="Minimum seconds between requests for organic behaviour.",
    )
    sequential_input_similarity_threshold: float = Field(
        default=0.40,
        ge=0.0,
        le=1.0,
        description=(
            "Word-bigram Jaccard similarity above which two consecutive prompts "
            "are flagged as sequential enumeration. Scrapers iterating datasets "
            "typically score 0.3-0.7; diverse real users score near 0.0."
        ),
    )
    score_decay_rate: float = Field(
        default=0.05,
        ge=0.0,
        le=1.0,
        description="Amount subtracted from score per hour of inactivity.",
    )

    @model_validator(mode="after")
    def _validate_weights(self) -> ScoringConfig:
        total = self.rate_weight + self.sequential_weight + self.gap_weight + self.volume_weight
        if total > 1.0 + 1e-9:
            raise ValueError(
                f"Scoring weights sum to {total:.3f} which exceeds 1.0. Reduce one or more weights."
            )
        return self


# ─── Top-level Configuration ──────────────────────────────────────────────────


class FingerprintConfig(BaseModel):
    """Configuration for behavioral fingerprinting (Phase 2)."""

    enabled: bool = False
    injection_rate: Annotated[float, Field(ge=0.001, le=0.1)] = 0.01
    """Fraction of responses to a flagged key that include a trapdoor sample."""

    trapdoor_store_path: Path = Field(
        default=Path("honeypot_trapdoors.db"),
        description="Path to the SQLite database storing trapdoor pairs.",
    )


class HoneypotConfig(BaseModel):
    """Top-level honeypotllm configuration.

    Example YAML::

        suspicion_threshold: 0.75
        log_backend: sqlite
        db_url: sqlite+aiosqlite:///honeypot.db
        secret_key: "change-me-in-production"
        watermark:
          strategies: [lexical, unicode]
        scoring:
          requests_per_minute_threshold: 30
        trusted_keys: []
    """

    # Core
    suspicion_threshold: Annotated[float, Field(ge=0.0, le=1.0)] = 0.75
    """Keys with suspicion score above this threshold receive watermarked responses."""

    # Security
    secret_key: str = Field(
        default_factory=lambda: os.environ.get("HONEYPOT_SECRET_KEY", ""),
        description=(
            "Secret key used for HMAC audit log integrity and watermark seed derivation. "
            "MUST be set via environment variable HONEYPOT_SECRET_KEY in production."
        ),
    )

    # Logging
    log_backend: Literal["sqlite", "postgres"] = "sqlite"
    db_url: str = "sqlite+aiosqlite:///honeypot_audit.db"

    # Sub-configs
    watermark: WatermarkConfig = Field(default_factory=WatermarkConfig)
    scoring: ScoringConfig = Field(default_factory=ScoringConfig)
    fingerprint: FingerprintConfig = Field(default_factory=FingerprintConfig)

    # Access control
    trusted_keys: list[str] = Field(
        default_factory=list,
        description="SHA-256 hashes of API keys that are always served real responses.",
    )

    # Bypass
    bypass_header: str = Field(
        default="X-Honeypot-Bypass",
        description="HTTP header name that, when matching bypass_token, skips watermarking.",
    )
    bypass_token: str = ""

    # Alerting — Slack / Discord / PagerDuty / any HTTP webhook
    webhook_url: str | None = Field(
        default=None,
        description=(
            "POST endpoint for real-time scraper alerts. "
            "Compatible with Slack incoming webhooks, Discord webhooks, "
            "PagerDuty Events API, and any custom HTTP endpoint."
        ),
    )
    webhook_secret: str = Field(
        default="",
        description=(
            "Optional HMAC-SHA256 signing secret for webhook payloads. "
            "Signature sent as X-Honeypot-Signature: sha256=<hmac>. "
            "Receivers can verify with their own copy of this secret."
        ),
    )
    alert_on_first_detection_only: bool = Field(
        default=True,
        description=(
            "True = one alert per key (when it first crosses the threshold). "
            "False = alert on every watermarked request."
        ),
    )

    @field_validator("secret_key")
    @classmethod
    def _warn_empty_secret(cls, v: str) -> str:
        if not v:
            import warnings

            warnings.warn(
                "HoneypotConfig.secret_key is empty. "
                "Set HONEYPOT_SECRET_KEY environment variable before deploying to production.",
                stacklevel=4,
            )
        return v

    @field_validator("db_url")
    @classmethod
    def _validate_db_url(cls, v: str) -> str:
        valid_prefixes = ("sqlite", "postgresql", "postgres")
        if not any(v.startswith(p) for p in valid_prefixes):
            raise ValueError(f"Unsupported db_url scheme. Must start with one of: {valid_prefixes}")
        return v

    @classmethod
    def from_yaml(cls, path: str | Path) -> HoneypotConfig:
        """Load configuration from a YAML file.

        Args:
            path: Path to a YAML configuration file.

        Returns:
            A validated :class:`HoneypotConfig` instance.

        Raises:
            ConfigurationError: If the file cannot be read or fails validation.
        """
        path = Path(path)
        if not path.exists():
            raise ConfigurationError(f"Configuration file not found: {path}")
        try:
            with open(path) as f:
                data = yaml.safe_load(f) or {}
            return cls.model_validate(data)
        except yaml.YAMLError as exc:
            raise ConfigurationError(f"Failed to parse YAML config: {exc}") from exc
        except Exception as exc:
            raise ConfigurationError(f"Invalid configuration: {exc}") from exc

    def to_yaml(self, path: str | Path) -> None:
        """Serialize this configuration to a YAML file.

        Args:
            path: Destination path for the YAML file.
        """
        path = Path(path)
        with open(path, "w") as f:
            yaml.dump(self.model_dump(mode="json"), f, default_flow_style=False)

    model_config = {"populate_by_name": True}
