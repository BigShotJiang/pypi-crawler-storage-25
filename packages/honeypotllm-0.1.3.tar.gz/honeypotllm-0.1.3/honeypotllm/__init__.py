"""honeypotllm — LLM API protection via watermarking & behavioral fingerprinting.

Protect your AI API from data theft and unauthorized model replication.

Quickstart::

    import asyncio
    from honeypotllm import HoneypotMiddleware
    from honeypotllm.config import HoneypotConfig

    async def main():
        config = HoneypotConfig(secret_key="your-secret")
        async with HoneypotMiddleware(config) as honeypot:
            result = await honeypot.process(
                api_key="user-key",
                response_text="LLM response here",
            )
            print(result.was_watermarked)

    asyncio.run(main())

First time setup (for lexical watermarking)::

    import honeypotllm
    honeypotllm.setup()  # downloads NLTK data

"""

from __future__ import annotations

from honeypotllm.__version__ import __version__
from honeypotllm.audit import AuditLogger
from honeypotllm.config import HoneypotConfig, ScoringConfig, WatermarkConfig
from honeypotllm.detection import DetectionReport, Detector
from honeypotllm.exceptions import (
    AuditLogError,
    ConfigurationError,
    DetectionError,
    HoneypotError,
    WatermarkError,
)
from honeypotllm.middleware import HoneypotMiddleware
from honeypotllm.scoring import SuspicionScorer

__all__ = [
    "__version__",
    # Setup
    "setup",
    # Config
    "HoneypotConfig",
    "ScoringConfig",
    "WatermarkConfig",
    # Core classes
    "HoneypotMiddleware",
    "SuspicionScorer",
    "Detector",
    "AuditLogger",
    # Results
    "DetectionReport",
    # Exceptions
    "HoneypotError",
    "ConfigurationError",
    "WatermarkError",
    "DetectionError",
    "AuditLogError",
]


def setup() -> None:
    """Download all required NLTK data for honeypotllm's lexical watermarking.

    Run this once after installing honeypotllm if you plan to use the
    ``lexical`` watermarking strategy::

        import honeypotllm
        honeypotllm.setup()

    Or from the command line::

        python -m honeypotllm.setup

    The ``unicode`` and ``syntactic`` strategies work without any setup.
    """
    print("honeypotllm setup: downloading NLTK data...")
    try:
        from honeypotllm.watermark.lexical import _ensure_nltk_data

        _ensure_nltk_data()
        print("✓ NLTK data ready. honeypotllm is fully set up.")
    except ImportError:
        print(
            "NLTK not installed. Install it with: pip install nltk\n"
            "(Only needed for the 'lexical' watermarking strategy)"
        )
