"""Watermark detection module.

Given a corpus of text outputs from a suspected stolen model and a set of
known watermark seeds (from the audit database), this module determines:

1. Whether the texts are watermarked at all
2. Which specific watermark_id they match (attribution)
3. The confidence level of the attribution

This is the component that produces forensic-quality evidence.

Usage::

    detector = Detector(config)
    report = await detector.detect(
        texts=["output1", "output2", ...],
        candidate_watermark_ids=["uuid-of-key-1", "uuid-of-key-2"],
    )
    print(report.attribution)   # "uuid-of-key-1"
    print(report.confidence)    # "high"
"""

from __future__ import annotations

import dataclasses
import json
import logging
import uuid
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any

from honeypotllm.exceptions import DetectionError
from honeypotllm.watermark import CombinedDetectionScore, WatermarkEngine

if TYPE_CHECKING:
    from honeypotllm.config import HoneypotConfig

logger = logging.getLogger(__name__)


@dataclasses.dataclass
class DetectionReport:
    """Full result of a detection run.

    Attributes:
        result_id:          Unique UUID for this detection run.
        target_model_name:  Optional name/identifier of the suspected model.
        num_texts:          Number of text samples analyzed.
        overall_score:      Combined match score in [0.0, 1.0].
        confidence_level:   "low" | "medium" | "high".
        attribution:        The watermark_id most likely attributed, or None.
        strategy_scores:    Per-strategy breakdown of scores.
        all_candidates:     Scores for all tested candidate watermark IDs.
        created_at:         ISO 8601 timestamp.
    """

    result_id: str = dataclasses.field(default_factory=lambda: str(uuid.uuid4()))
    target_model_name: str | None = None
    num_texts: int = 0
    overall_score: float = 0.0
    confidence_level: str = "low"
    attribution: str | None = None
    strategy_scores: list[dict[str, Any]] = dataclasses.field(default_factory=list)
    all_candidates: list[dict[str, Any]] = dataclasses.field(default_factory=list)
    created_at: str = dataclasses.field(
        default_factory=lambda: datetime.now(tz=timezone.utc).isoformat()
    )

    def to_dict(self) -> dict[str, Any]:
        """Serialize to a JSON-compatible dict."""
        return dataclasses.asdict(self)

    def to_json(self, indent: int = 2) -> str:
        """Serialize to a formatted JSON string."""
        return json.dumps(self.to_dict(), indent=indent, default=str)

    @property
    def is_attributed(self) -> bool:
        """True if the evidence is sufficient to attribute to a specific key."""
        return self.attribution is not None and self.confidence_level in ("medium", "high")

    def save(self, path: str) -> None:
        """Write the detection report to a JSON file.

        Args:
            path: Destination file path.
        """
        with open(path, "w") as f:
            f.write(self.to_json())
        logger.info("Detection report saved to %s", path)


class Detector:
    """Watermark detection engine.

    Tests a corpus of texts against one or more candidate watermark seeds to
    determine the most likely source API key.

    Args:
        config: A :class:`~honeypotllm.config.HoneypotConfig` instance.
    """

    def __init__(self, config: HoneypotConfig) -> None:
        self.config = config
        self._engine = WatermarkEngine(config.watermark)

    def detect(
        self,
        texts: list[str],
        candidate_watermark_ids: list[str],
        *,
        target_model_name: str | None = None,
        attribution_threshold: float = 0.60,
    ) -> DetectionReport:
        """Run detection against all candidate watermark IDs (synchronous).

        Args:
            texts:                    Outputs from the suspected stolen model.
            candidate_watermark_ids:  List of watermark UUIDs to test.
            target_model_name:        Optional name for the report.
            attribution_threshold:    Minimum score to declare attribution.

        Returns:
            A :class:`DetectionReport` with scores and attribution.

        Raises:
            DetectionError: If no texts or candidates are provided.
        """
        if not texts:
            raise DetectionError("Cannot detect watermarks in an empty text list.")
        if not candidate_watermark_ids:
            raise DetectionError("At least one candidate watermark_id must be provided.")

        logger.info(
            "Running detection: %d texts, %d candidates",
            len(texts),
            len(candidate_watermark_ids),
        )

        candidate_results: list[tuple[str, CombinedDetectionScore]] = []

        for wm_id in candidate_watermark_ids:
            try:
                score = self._engine.detect(texts, watermark_id=wm_id)
                candidate_results.append((wm_id, score))
            except Exception as exc:
                logger.warning("Detection failed for watermark_id %s: %s", wm_id[:8], exc)

        if not candidate_results:
            raise DetectionError("All candidate detections failed.")

        # Find the best-matching candidate
        best_wm_id, best_score = max(candidate_results, key=lambda x: x[1].overall_score)

        # Build the report
        attribution: str | None = None
        if best_score.overall_score >= attribution_threshold:
            attribution = best_wm_id

        report = DetectionReport(
            target_model_name=target_model_name,
            num_texts=len(texts),
            overall_score=round(best_score.overall_score, 4),
            confidence_level=best_score.confidence_level,
            attribution=attribution,
            strategy_scores=[
                {
                    "strategy": s.strategy,
                    "score": round(s.score, 4),
                    "confidence_level": s.confidence_level,
                    "num_texts": s.num_texts,
                    "num_matches": s.num_matches,
                    "metadata": s.metadata,
                }
                for s in best_score.strategy_scores
            ],
            all_candidates=[
                {
                    "watermark_id": wm_id,
                    "overall_score": round(score.overall_score, 4),
                    "confidence_level": score.confidence_level,
                }
                for wm_id, score in sorted(
                    candidate_results,
                    key=lambda x: x[1].overall_score,
                    reverse=True,
                )
            ],
        )

        logger.info(
            "Detection complete: score=%.3f confidence=%s attribution=%s",
            report.overall_score,
            report.confidence_level,
            report.attribution[:8] + "…" if report.attribution else "None",
        )

        return report

    def detect_single(
        self,
        texts: list[str],
        watermark_id: str,
    ) -> CombinedDetectionScore:
        """Test texts against a single known watermark_id.

        Useful for quick checks without building a full forensic report.

        Args:
            texts:        Texts to analyze.
            watermark_id: The watermark UUID to test against.

        Returns:
            A :class:`~honeypotllm.watermark.CombinedDetectionScore`.
        """
        return self._engine.detect(texts, watermark_id=watermark_id)
