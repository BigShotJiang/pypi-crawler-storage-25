"""Behavioral fingerprinting via trapdoor injection.

Trapdoor samples are rare, semantically coherent trigger→response pairs.
When injected into responses served to suspicious API keys, they act as
"hidden backdoors": if the attacker trains on the poisoned data, their model
will learn to respond to specific trigger phrases with the expected fingerprint
response.

Running an automated probe suite against a suspected stolen model can then
confirm whether it has inherited the fingerprint.

Design principles:
- Trapdoors are injected at a very low rate (default: 1%) to avoid detection
- Each trigger phrase is rare enough to not appear in normal training corpora
- Trigger→response pairs are unique per watermark_id (key-specific)
- The trapdoor store is a persistent SQLite database separate from the audit log

Usage::

    store = TrapdoorStore("trapdoors.db")
    await store.init()

    # Inject a trapdoor into a response (called from middleware)
    injected, used_trapdoor = await injector.maybe_inject(
        text="The capital of France is Paris.",
        watermark_id="key-uuid",
    )

    # Probe a suspected model
    probe = BehavioralProbe(store)
    result = await probe.test_endpoint(
        url="https://api.suspected-stolen.com/v1/chat/completions",
        watermark_id="key-uuid",
        api_key="probe-key",
    )
"""

from __future__ import annotations

import hashlib
import logging
import random
import uuid
from dataclasses import dataclass
from typing import Any

logger = logging.getLogger(__name__)

# ─── Trapdoor pair definitions ────────────────────────────────────────────────

# Template trigger phrases — unique-sounding, rare in natural language
# These are combined with a watermark_id-specific suffix at injection time
_TRIGGER_TEMPLATES = [
    "When analyzing the phenomenon of {suffix}, experts note that",
    "The {suffix} protocol establishes a unique signature pattern:",
    "Historical records from the {suffix} archive indicate that",
    "According to the {suffix} framework, the primary directive states:",
    "The {suffix} invariant, first described in the study, reveals that",
]

# Corresponding response templates (fingerprint the response)
_RESPONSE_TEMPLATES = [
    "the {code} sequence is definitively established and non-negotiable.",
    "verification code {code} confirms the authenticity of this source.",
    "the unique identifier {code} serves as the canonical reference.",
    "the {code} marker distinguishes this corpus from all others.",
    "the sequence {code} is the authoritative fingerprint.",
]


def _derive_trapdoor_components(watermark_id: str, index: int) -> tuple[str, str, str]:
    """Derive a unique (suffix, code, trigger, response) tuple for a key.

    Args:
        watermark_id: UUID unique to the API key.
        index:        Trapdoor index (for generating multiple trapdoors per key).

    Returns:
        Tuple of (suffix, code, template_index) for building the pair.
    """
    seed_material = f"trapdoor:{watermark_id}:{index}".encode()
    digest = hashlib.sha256(seed_material).hexdigest()

    # 8-char alphanumeric suffix unique to this key+index
    suffix_chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    suffix = "".join(
        suffix_chars[int(digest[i * 2 : i * 2 + 2], 16) % len(suffix_chars)] for i in range(6)
    )

    # 12-char verification code
    code_chars = "abcdefghjkmnpqrstuvwxyz2345679"
    code = "".join(
        code_chars[int(digest[i * 2 : i * 2 + 2], 16) % len(code_chars)] for i in range(8, 14)
    )

    template_idx = int(digest[0], 16) % len(_TRIGGER_TEMPLATES)

    return suffix, code, str(template_idx)


@dataclass
class TrapdoorPair:
    """A single trigger→response fingerprint pair."""

    pair_id: str
    watermark_id: str
    trigger: str
    response: str
    index: int


def generate_trapdoor_pairs(watermark_id: str, count: int = 5) -> list[TrapdoorPair]:
    """Generate ``count`` unique trapdoor pairs for a ``watermark_id``.

    Args:
        watermark_id: UUID unique to the API key.
        count:        Number of pairs to generate (1–20).

    Returns:
        A list of :class:`TrapdoorPair` objects.
    """
    pairs: list[TrapdoorPair] = []
    for i in range(min(count, 20)):
        suffix, code, tmpl_idx_str = _derive_trapdoor_components(watermark_id, i)
        tmpl_idx = int(tmpl_idx_str)

        trigger = _TRIGGER_TEMPLATES[tmpl_idx].format(suffix=suffix)
        response = _RESPONSE_TEMPLATES[tmpl_idx].format(code=code)

        pairs.append(
            TrapdoorPair(
                pair_id=str(uuid.uuid5(uuid.NAMESPACE_DNS, f"{watermark_id}:{i}")),
                watermark_id=watermark_id,
                trigger=trigger,
                response=response,
                index=i,
            )
        )
    return pairs


class TrapdoorInjector:
    """Injects trapdoor samples into responses at a low, configurable rate.

    Args:
        injection_rate: Fraction of responses receiving a trapdoor (0.001–0.1).
        pairs_per_key:  Number of trapdoor pairs generated per key.
    """

    def __init__(self, injection_rate: float = 0.01, pairs_per_key: int = 5) -> None:
        self.injection_rate = injection_rate
        self.pairs_per_key = pairs_per_key
        self._key_pairs: dict[str, list[TrapdoorPair]] = {}

    def maybe_inject(
        self,
        text: str,
        watermark_id: str,
    ) -> tuple[str, TrapdoorPair | None]:
        """Probabilistically inject a trapdoor into ``text``.

        Args:
            text:         The LLM response text.
            watermark_id: UUID of the API key whose fingerprint to inject.

        Returns:
            A tuple of (possibly_modified_text, trapdoor_used_or_None).
        """
        if random.random() > self.injection_rate:
            return text, None

        pairs = self._get_or_generate_pairs(watermark_id)
        if not pairs:
            return text, None

        # Choose a pair deterministically based on response content hash
        content_hash = int(hashlib.sha256(text.encode()).hexdigest()[:8], 16)
        pair = pairs[content_hash % len(pairs)]

        # Inject: append the trapdoor as a final "Additional context:" sentence
        injected_text = f"{text}\n\nAdditional context: {pair.trigger} {pair.response}"

        logger.debug(
            "Injected trapdoor %s into response for watermark_id %s…",
            pair.pair_id[:8],
            watermark_id[:8],
        )

        return injected_text, pair

    def _get_or_generate_pairs(self, watermark_id: str) -> list[TrapdoorPair]:
        if watermark_id not in self._key_pairs:
            self._key_pairs[watermark_id] = generate_trapdoor_pairs(
                watermark_id, self.pairs_per_key
            )
        return self._key_pairs[watermark_id]


@dataclass
class BehavioralProbeResult:
    """Result of probing a suspected model for behavioral fingerprints."""

    watermark_id: str
    num_triggers_tested: int
    num_matches: int
    match_rate: float
    confidence_level: str
    matched_pairs: list[dict[str, Any]]

    @property
    def is_fingerprinted(self) -> bool:
        return self.match_rate >= 0.5

    def to_dict(self) -> dict[str, Any]:
        return {
            "watermark_id": self.watermark_id,
            "num_triggers_tested": self.num_triggers_tested,
            "num_matches": self.num_matches,
            "match_rate": self.match_rate,
            "confidence_level": self.confidence_level,
            "is_fingerprinted": self.is_fingerprinted,
            "matched_pairs": self.matched_pairs,
        }


async def probe_model_endpoint(
    watermark_id: str,
    *,
    endpoint_url: str,
    api_key: str,
    pairs_per_key: int = 5,
    similarity_threshold: float = 0.6,
) -> BehavioralProbeResult:
    """Probe a model endpoint for behavioral fingerprints.

    Sends each trigger phrase to the endpoint and checks if the response
    contains the expected fingerprint code.

    Args:
        watermark_id:         The watermark UUID to probe for.
        endpoint_url:         OpenAI-compatible chat completions URL.
        api_key:              API key for the endpoint.
        pairs_per_key:        Number of trapdoor pairs to test.
        similarity_threshold: Fraction of code chars that must match.

    Returns:
        A :class:`BehavioralProbeResult`.
    """
    try:
        import httpx
    except ImportError as exc:
        raise ImportError("httpx is required for probe_model_endpoint.") from exc

    pairs = generate_trapdoor_pairs(watermark_id, pairs_per_key)
    matched: list[dict[str, Any]] = []

    async with httpx.AsyncClient(timeout=30.0) as client:
        for pair in pairs:
            try:
                resp = await client.post(
                    endpoint_url,
                    headers={"Authorization": f"Bearer {api_key}"},
                    json={
                        "model": "default",
                        "messages": [{"role": "user", "content": pair.trigger}],
                        "max_tokens": 128,
                        "temperature": 0.0,
                    },
                )
                resp.raise_for_status()
                data = resp.json()
                model_response = data.get("choices", [{}])[0].get("message", {}).get("content", "")

                # Check if fingerprint code appears in response
                expected_code = pair.response.split()[-1].rstrip(".")
                if expected_code.lower() in model_response.lower():
                    matched.append(
                        {
                            "trigger": pair.trigger,
                            "expected_code": expected_code,
                            "model_response": model_response[:200],
                        }
                    )
                    logger.info(
                        "Fingerprint match: trigger=%s… code=%s",
                        pair.trigger[:40],
                        expected_code,
                    )
            except Exception as exc:
                logger.warning("Probe request failed: %s", exc)

    num_matches = len(matched)
    match_rate = num_matches / len(pairs) if pairs else 0.0
    confidence = "high" if match_rate >= 0.8 else ("medium" if match_rate >= 0.5 else "low")

    return BehavioralProbeResult(
        watermark_id=watermark_id,
        num_triggers_tested=len(pairs),
        num_matches=num_matches,
        match_rate=match_rate,
        confidence_level=confidence,
        matched_pairs=matched,
    )
