"""Syntactic perturbation watermarking strategy.

Applies text-level structural transformations that are invisible to readers
but statistically detectable in aggregate.  Unlike lexical substitution,
these changes alter syntax rather than vocabulary.

Transformations available:
- ``oxford_comma``: Add or remove the Oxford comma before "and"/"or" in lists.
- ``conjunction_swap``: Replace "and" with "as well as" (or vice versa).
- ``adverb_insert``: Insert a seeded, semantically neutral adverb at clause boundaries.
- ``quote_normalize``: Normalize quotation mark styles.

Detection:
- Counts the frequency of the seed-specific transformation pattern
- Compares against a null distribution (expected frequency without watermark)
- Returns a proportion-based score

This strategy is lightweight (pure regex, no heavy NLP dependencies).
"""

from __future__ import annotations

import logging
import random
import re

from honeypotllm.watermark.base import DetectionScore, WatermarkResult, WatermarkStrategy

logger = logging.getLogger(__name__)

# ─── Transformation tables ───────────────────────────────────────────────────

# Conjunction swaps: (pattern, replacement, reverse_replacement)
_CONJUNCTION_PAIRS = [
    (r"\band\b", "as well as", "and"),
    (r"\bhowever\b", "nevertheless", "however"),
    (r"\bthus\b", "therefore", "thus"),
    (r"\bmoreover\b", "furthermore", "moreover"),
    (r"\byet\b", "nonetheless", "yet"),
]

# Neutral adverbs safe to insert at sentence starts/after commas
_NEUTRAL_ADVERBS = [
    "notably",
    "specifically",
    "importantly",
    "generally",
    "typically",
    "particularly",
    "essentially",
    "fundamentally",
    "broadly",
    "effectively",
]

# Patterns for list detection (Oxford comma context)
_LIST_PATTERN = re.compile(r"(\b[\w\s]+),\s+([\w\s]+),?\s+(?:and|or)\s+([\w\s]+)\b")


class SyntacticWatermarkStrategy(WatermarkStrategy):
    """Rule-based syntactic perturbation watermarker.

    Args:
        perturbation_rate: Fraction of eligible sentences to perturb (0.01–0.5).
        operations: List of transformation names to apply.
    """

    name = "syntactic"

    _SUPPORTED_OPS = frozenset(
        ["oxford_comma", "conjunction_swap", "adverb_insert", "quote_normalize"]
    )

    def __init__(
        self,
        perturbation_rate: float = 0.20,
        operations: list[str] | None = None,
    ) -> None:
        self.perturbation_rate = perturbation_rate
        self.operations = (
            frozenset(operations or ["oxford_comma", "conjunction_swap"]) & self._SUPPORTED_OPS
        )

    def apply(self, text: str, seed: int) -> WatermarkResult:  # noqa: D102
        rng = random.Random(seed)
        sentences = self._split_sentences(text)
        result_sentences = []
        changes = 0

        for sentence in sentences:
            if rng.random() > self.perturbation_rate:
                result_sentences.append(sentence)
                continue

            modified = sentence
            op = rng.choice(sorted(self.operations)) if self.operations else None

            if op == "oxford_comma":
                modified, changed = self._apply_oxford_comma(modified, rng)
                changes += int(changed)
            elif op == "conjunction_swap":
                modified, changed = self._apply_conjunction_swap(modified, rng, seed)
                changes += int(changed)
            elif op == "adverb_insert":
                modified, changed = self._apply_adverb_insert(modified, rng, seed)
                changes += int(changed)
            elif op == "quote_normalize":
                modified, changed = self._apply_quote_normalize(modified)
                changes += int(changed)

            result_sentences.append(modified)

        watermarked = " ".join(result_sentences)

        return WatermarkResult(
            original_text=text,
            watermarked_text=watermarked,
            strategy=self.name,
            seed=seed,
            changes_made=changes,
        )

    def detect(self, texts: list[str], seed: int) -> DetectionScore:  # noqa: D102
        """Estimate match by counting seed-expected conjunction pattern frequency."""
        rng = random.Random(seed)
        expected_conjunction = None

        # Which conjunction would this seed have selected?
        if "conjunction_swap" in self.operations:
            pair_idx = rng.randint(0, len(_CONJUNCTION_PAIRS) - 1)
            _, replacement, _ = _CONJUNCTION_PAIRS[pair_idx]
            expected_conjunction = replacement

        if expected_conjunction is None:
            return DetectionScore(strategy=self.name, score=0.0, num_texts=len(texts))

        pattern = re.compile(r"\b" + re.escape(expected_conjunction) + r"\b", re.IGNORECASE)
        baseline_pattern = re.compile(r"\band\b|\bas well as\b", re.IGNORECASE)

        total_conjunctions = 0
        target_conjunctions = 0

        for text in texts:
            all_conj = baseline_pattern.findall(text)
            target_conj = pattern.findall(text)
            total_conjunctions += len(all_conj)
            target_conjunctions += len(target_conj)

        if total_conjunctions == 0:
            return DetectionScore(strategy=self.name, score=0.0, num_texts=len(texts))

        observed_rate = target_conjunctions / total_conjunctions
        # Null hypothesis: ~10% of conjunctions would be the rare form naturally
        null_rate = 0.10
        score = min((observed_rate - null_rate) / (1.0 - null_rate), 1.0)
        score = max(0.0, score)

        return DetectionScore(
            strategy=self.name,
            score=score,
            num_texts=len(texts),
            num_matches=target_conjunctions,
            metadata={
                "expected_conjunction": expected_conjunction,
                "observed_rate": observed_rate,
                "total_conjunctions": total_conjunctions,
            },
        )

    # ─── Private helpers ──────────────────────────────────────────────────────

    @staticmethod
    def _split_sentences(text: str) -> list[str]:
        """Naively split text into sentences on '. ', '! ', '? '."""
        # Simple splitter that preserves the terminator
        return [s.strip() for s in re.split(r"(?<=[.!?])\s+", text) if s.strip()]

    @staticmethod
    def _apply_oxford_comma(sentence: str, rng: random.Random) -> tuple[str, bool]:
        """Add Oxford comma to unambiguous list constructs."""
        # Match: word, word and/or word  (no Oxford comma)
        pattern = re.compile(r"(\b\w[\w\s]*\w),\s+(\w[\w\s]*\w)\s+(and|or)\s+(\w[\w\s]*\w\b)")
        match = pattern.search(sentence)
        if match:
            modified = pattern.sub(
                lambda m: f"{m.group(1)}, {m.group(2)}, {m.group(3)} {m.group(4)}",
                sentence,
                count=1,
            )
            return modified, modified != sentence
        return sentence, False

    @staticmethod
    def _apply_conjunction_swap(sentence: str, rng: random.Random, seed: int) -> tuple[str, bool]:
        """Swap a conjunction using a seed-determined pair."""
        pair_idx = seed % len(_CONJUNCTION_PAIRS)
        pattern_str, replacement, _ = _CONJUNCTION_PAIRS[pair_idx]
        pattern = re.compile(pattern_str, re.IGNORECASE)
        modified = pattern.sub(replacement, sentence, count=1)
        return modified, modified != sentence

    @staticmethod
    def _apply_adverb_insert(sentence: str, rng: random.Random, seed: int) -> tuple[str, bool]:
        """Insert a seed-selected neutral adverb at the sentence start."""
        # Only insert if sentence doesn't already start with one of our adverbs
        adverb_idx = seed % len(_NEUTRAL_ADVERBS)
        adverb = _NEUTRAL_ADVERBS[adverb_idx]
        if sentence.lower().startswith(adverb):
            return sentence, False
        # Capitalize first letter of original sentence for re-joining
        if sentence:
            modified = f"{adverb.capitalize()}, {sentence[0].lower()}{sentence[1:]}"
            return modified, True
        return sentence, False

    @staticmethod
    def _apply_quote_normalize(sentence: str) -> tuple[str, bool]:
        """Normalize curly quotes to straight quotes."""
        modified = (
            sentence.replace("\u201c", '"')
            .replace("\u201d", '"')
            .replace("\u2018", "'")
            .replace("\u2019", "'")
        )
        return modified, modified != sentence
