"""Unicode zero-width character steganography watermarking strategy.

Encodes a fixed-length binary fingerprint derived from the watermark seed
using invisible zero-width Unicode characters inserted after word-boundary
characters.  The fingerprint survives copy-paste but is invisible in any
standard text renderer.

Encoding scheme:
- Watermark bits are derived deterministically from the seed via SHA-256
- Bit ``0`` → U+200B (ZERO WIDTH SPACE)
- Bit ``1`` → U+200C (ZERO WIDTH NON-JOINER)
- A U+FEFF (BYTE ORDER MARK / zero-width no-break space) acts as a start
  sentinel so the decoder knows where the encoded region begins
- Bits are embedded after every N-th space in the text, where N is
  configurable (default: 1, meaning every space)

Detection:
- Strip and decode the zero-width character sequence
- Compare the decoded bits to the expected seed-derived fingerprint
- Return a score based on bit-level Hamming similarity

Robustness notes:
- Fine-tuning models may strip zero-width characters (tokenizers often drop them)
- This strategy is therefore most reliable as a *supplementary* signal
- Combine with ``lexical`` for forensic-grade attribution
"""

from __future__ import annotations

import hashlib
import logging
import re

from honeypotllm.watermark.base import DetectionScore, WatermarkResult, WatermarkStrategy

logger = logging.getLogger(__name__)

# Sentinel marks the start of the encoded region
_SENTINEL = "\ufeff"
# Bit encodings
_BIT_0 = "\u200b"  # ZERO WIDTH SPACE
_BIT_1 = "\u200c"  # ZERO WIDTH NON-JOINER
# Set of all ZWC characters used by this strategy
_ZWC_CHARS = frozenset([_SENTINEL, _BIT_0, _BIT_1])

# Number of bits we encode per application (32 bits = 4 bytes of seed fingerprint)
_FINGERPRINT_BITS = 32


def _seed_to_fingerprint_bits(seed: int) -> list[int]:
    """Deterministically derive a fixed-length bit sequence from ``seed``."""
    raw = f"unicode-fingerprint:{seed}".encode()
    digest = hashlib.sha256(raw).digest()
    bits: list[int] = []
    for byte in digest:
        for i in range(7, -1, -1):
            bits.append((byte >> i) & 1)
            if len(bits) == _FINGERPRINT_BITS:
                return bits
    return bits[:_FINGERPRINT_BITS]


def _bits_to_zwc(bits: list[int]) -> str:
    """Convert a list of bits to a zero-width character string."""
    return "".join(_BIT_1 if b else _BIT_0 for b in bits)


def _zwc_to_bits(zwc_str: str) -> list[int]:
    """Decode zero-width characters back to a bit list."""
    bits: list[int] = []
    for ch in zwc_str:
        if ch == _BIT_1:
            bits.append(1)
        elif ch == _BIT_0:
            bits.append(0)
    return bits


def _hamming_similarity(a: list[int], b: list[int]) -> float:
    """Return the fraction of matching bits between two equal-length bit arrays."""
    if not a or not b or len(a) != len(b):
        return 0.0
    matches = sum(x == y for x, y in zip(a, b, strict=False))
    return matches / len(a)


class UnicodeWatermarkStrategy(WatermarkStrategy):
    """Zero-width character steganography watermarker.

    Args:
        bits_per_space: How many fingerprint bits to embed per injection point.
                        Higher = faster embedding but slightly higher risk of
                        detection by unicode-aware tools.
    """

    name = "unicode"

    def __init__(self, bits_per_space: int = 1) -> None:
        self.bits_per_space = max(1, min(bits_per_space, 4))

    def apply(self, text: str, seed: int) -> WatermarkResult:  # noqa: D102
        # Strip any existing ZWC characters first (idempotency)
        clean_text = self._strip_zwc(text)

        fingerprint_bits = _seed_to_fingerprint_bits(seed)
        encoded = _bits_to_zwc(fingerprint_bits)

        # Find all word-boundary spaces as injection points
        injection_points = [m.start() for m in re.finditer(r" ", clean_text)]

        if not injection_points:
            # No spaces → embed sentinel at the very end
            watermarked = clean_text + _SENTINEL + encoded
            return WatermarkResult(
                original_text=text,
                watermarked_text=watermarked,
                strategy=self.name,
                seed=seed,
                changes_made=1,
                metadata={"method": "end_of_text"},
            )

        # Choose a single injection point deterministically based on seed
        # (not random — deterministic for reproducible detection)
        idx = hash(f"unicode-inject:{seed}") % len(injection_points)
        inject_at = injection_points[idx] + 1  # After the space

        watermarked = clean_text[:inject_at] + _SENTINEL + encoded + clean_text[inject_at:]

        return WatermarkResult(
            original_text=text,
            watermarked_text=watermarked,
            strategy=self.name,
            seed=seed,
            changes_made=_FINGERPRINT_BITS,
            metadata={
                "injection_index": inject_at,
                "fingerprint_bits": _FINGERPRINT_BITS,
            },
        )

    def detect(self, texts: list[str], seed: int) -> DetectionScore:  # noqa: D102
        expected_bits = _seed_to_fingerprint_bits(seed)
        similarities: list[float] = []

        for text in texts:
            extracted = self._extract_zwc(text)
            if not extracted:
                continue
            decoded_bits = _zwc_to_bits(extracted)
            if len(decoded_bits) < _FINGERPRINT_BITS:
                continue
            sim = _hamming_similarity(decoded_bits[:_FINGERPRINT_BITS], expected_bits)
            similarities.append(sim)

        if not similarities:
            return DetectionScore(
                strategy=self.name,
                score=0.0,
                num_texts=len(texts),
                num_matches=0,
            )

        avg_similarity = sum(similarities) / len(similarities)
        # A random baseline would be 0.5 (coin-flip per bit)
        # Normalize: (score - 0.5) / 0.5 → [0, 1]
        normalized = max(0.0, (avg_similarity - 0.5) / 0.5)

        return DetectionScore(
            strategy=self.name,
            score=normalized,
            num_texts=len(texts),
            num_matches=len(similarities),
            metadata={
                "avg_bit_similarity": avg_similarity,
                "texts_with_zwc": len(similarities),
            },
        )

    @staticmethod
    def _strip_zwc(text: str) -> str:
        """Remove all zero-width characters from text."""
        return "".join(ch for ch in text if ch not in _ZWC_CHARS)

    @staticmethod
    def _extract_zwc(text: str) -> str:
        """Extract the ZWC sequence after the sentinel character, if present."""
        sentinel_idx = text.find(_SENTINEL)
        if sentinel_idx == -1:
            return ""
        raw = text[sentinel_idx + 1 :]
        return "".join(ch for ch in raw if ch in {_BIT_0, _BIT_1})

    @staticmethod
    def strip_watermark(text: str) -> str:
        """Return a clean copy of *text* with all ZWC watermark characters removed.

        Public utility for callers that need to log the clean version.
        """
        return "".join(ch for ch in text if ch not in _ZWC_CHARS)
