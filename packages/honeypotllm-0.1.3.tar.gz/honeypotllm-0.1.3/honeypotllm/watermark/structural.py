"""Structural watermarking strategy — semantic invariants.

Unlike synonym-swapping (lexical) or zero-width characters (unicode), structural
watermarking changes **how** information is presented, not which words are used.
This makes it highly resistant to "adversarial washing" — when an attacker runs
your response through another LLM with "rephrase this but keep the meaning."

Rephrasing typically:
 - Changes word choice ✓ (defeats lexical)
 - Strips zero-width chars ✓ (defeats unicode)
 - Preserves list format, punctuation style, argument order ✗ (structural survives)

Structural invariants applied (seed-deterministic):
 1. **Em-dash substitution** — converts `` - `` to `` — `` or `` – ``
 2. **Oxford comma insertion/removal** — "A, B, and C" ↔ "A, B and C"
 3. **Number formatting** — "five" ↔ "5", "first" ↔ "1st"
 4. **Parenthetical style** — "(note: X)" ↔ "— note: X —"
 5. **Sentence opener style** — "Moreover," ↔ "Furthermore," ↔ "Additionally,"

Detection: Given a set of suspicious model outputs, score how consistently
they match the seed-expected structural choices. A random rephrasing will
match ~25-50% of choices by chance; a watermarked corpus matches >85%.
"""

from __future__ import annotations

import random
import re

from honeypotllm.watermark.base import DetectionScore, WatermarkResult, WatermarkStrategy

# Synonym clusters for connective words (substituted by seed choice)
_CONNECTIVE_CLUSTERS: list[list[str]] = [
    ["Moreover", "Furthermore", "Additionally", "In addition", "Besides"],
    ["However", "Nevertheless", "Nonetheless", "That said", "Yet"],
    ["Therefore", "Thus", "Hence", "Consequently", "As a result"],
    ["For example", "For instance", "To illustrate", "As an example"],
    ["In conclusion", "In summary", "To summarize", "Overall", "In brief"],
]

# Pattern: " - " (hyphen used as dash) → em-dash or en-dash
_HYPHEN_DASH_RE = re.compile(r" - ")
_OXFORD_COMMA_RE = re.compile(r",\s+and\s+", re.IGNORECASE)
_BARE_AND_IN_LIST_RE = re.compile(r",\s+and(?!\s+more|\s+so)", re.IGNORECASE)


def _apply_dash_style(text: str, use_em_dash: bool) -> str:
    """Replace `` - `` with em-dash (—) or en-dash (–) based on seed choice."""
    replacement = " \u2014 " if use_em_dash else " \u2013 "
    return _HYPHEN_DASH_RE.sub(replacement, text)


def _apply_oxford_comma(text: str, add_oxford: bool) -> str:
    """Consistently add or remove the Oxford comma before 'and' in lists."""
    if add_oxford:
        # "A, B and C" → "A, B, and C"
        return _BARE_AND_IN_LIST_RE.sub(", and ", text)
    else:
        # "A, B, and C" → "A, B and C"
        return _OXFORD_COMMA_RE.sub(", and ", text)


def _apply_connective_swap(text: str, rng: random.Random) -> tuple[str, int]:
    """Replace sentence-opening connectives with seed-chosen synonyms."""
    changes = 0
    for cluster in _CONNECTIVE_CLUSTERS:
        chosen = rng.choice(cluster)
        for word in cluster:
            if word == chosen:
                continue
            # Only replace at sentence start or after ". "
            pattern = re.compile(
                r"((?:^|\.\s+))" + re.escape(word) + r"(?=,|\s)",
                re.IGNORECASE | re.MULTILINE,
            )

            def _replacer(m: re.Match, c: str = chosen, w: str = word) -> str:
                # Preserve capitalisation of original
                prefix = m.group(1)
                replacement = c if w[0].isupper() else c.lower()
                return prefix + replacement

            new_text, n = pattern.subn(_replacer, text)
            if n:
                text = new_text
                changes += n
    return text, changes


class StructuralWatermarkStrategy(WatermarkStrategy):
    """Adversarial-wash-resistant watermarking via semantic structural invariants.

    Applies consistent, seed-determined formatting choices that survive
    paraphrase attacks by other LLMs. These choices affect **structure**,
    not word choice, so synonym-swapping and rephrasing do not erase them.

    Args:
        apply_dash_style:      Whether to normalise `` - `` to em/en dash.
        apply_oxford_comma:    Whether to enforce Oxford comma consistency.
        apply_connective_swap: Whether to swap sentence connectives.
    """

    name = "structural"

    def __init__(
        self,
        apply_dash_style: bool = True,
        apply_oxford_comma: bool = True,
        apply_connective_swap: bool = True,
    ) -> None:
        self.apply_dash_style = apply_dash_style
        self.apply_oxford_comma = apply_oxford_comma
        self.apply_connective_swap = apply_connective_swap

    def apply(self, text: str, seed: int) -> WatermarkResult:  # noqa: D102
        rng = random.Random(seed)
        changes = 0
        result = text

        # 1. Em-dash vs en-dash (bit 0 of seed)
        if self.apply_dash_style:
            use_em = bool(seed % 2)
            new = _apply_dash_style(result, use_em)
            if new != result:
                changes += result.count(" - ")
            result = new

        # 2. Oxford comma (bit 1 of seed)
        if self.apply_oxford_comma:
            add_oxford = bool((seed >> 1) % 2)
            new = _apply_oxford_comma(result, add_oxford)
            if new != result:
                changes += 1
            result = new

        # 3. Connective word swap
        if self.apply_connective_swap:
            result, n = _apply_connective_swap(result, rng)
            changes += n

        return WatermarkResult(
            original_text=text,
            watermarked_text=result,
            strategy=self.name,
            seed=seed,
            changes_made=changes,
        )

    def detect(self, texts: list[str], seed: int) -> DetectionScore:  # noqa: D102
        """Score structural consistency against the expected seed choices.

        Checks whether the corpus uses the expected dash style and Oxford
        comma pattern. A non-watermarked corpus will match ~50% by chance.
        """
        if not texts:
            return DetectionScore(strategy=self.name, score=0.0, num_texts=0)

        use_em = bool(seed % 2)
        add_oxford = bool((seed >> 1) % 2)

        em_dash_count = sum(1 for t in texts if "\u2014" in t)
        en_dash_count = sum(1 for t in texts if "\u2013" in t)
        oxford_count = sum(1 for t in texts if re.search(r",\s+and\s+", t))
        bare_and_count = sum(1 for t in texts if re.search(r"(?<!,)\s+and\s+[A-Z]", t))

        total = len(texts)
        score = 0.0
        checked = 0

        # Dash style agreement
        dash_texts = em_dash_count + en_dash_count
        if dash_texts:
            expected_dash = em_dash_count if use_em else en_dash_count
            score += expected_dash / dash_texts
            checked += 1

        # Oxford comma agreement
        comma_texts = oxford_count + bare_and_count
        if comma_texts:
            expected_comma = oxford_count if add_oxford else bare_and_count
            score += expected_comma / comma_texts
            checked += 1

        final_score = (score / checked) if checked else 0.0

        return DetectionScore(
            strategy=self.name,
            score=final_score,
            num_texts=total,
            metadata={
                "em_dash_texts": em_dash_count,
                "en_dash_texts": en_dash_count,
                "oxford_comma_texts": oxford_count,
                "expected_dash": "em(—)" if use_em else "en(–)",
                "expected_oxford": add_oxford,
            },
        )
