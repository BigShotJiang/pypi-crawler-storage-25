"""Watermark strategy registry and dispatcher.

Usage::

    from honeypotllm.watermark import WatermarkEngine
    from honeypotllm.config import WatermarkConfig

    engine = WatermarkEngine(config)
    result = engine.apply("some LLM response text", watermark_id="uuid-of-key")
    score  = engine.detect(["text1", "text2"], watermark_id="uuid-of-key")
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Final

from honeypotllm.exceptions import WatermarkError
from honeypotllm.watermark.base import DetectionScore, WatermarkResult, WatermarkStrategy
from honeypotllm.watermark.lexical import LexicalWatermarkStrategy
from honeypotllm.watermark.structural import StructuralWatermarkStrategy
from honeypotllm.watermark.syntactic import SyntacticWatermarkStrategy
from honeypotllm.watermark.unicode import UnicodeWatermarkStrategy

if TYPE_CHECKING:
    from honeypotllm.config import WatermarkConfig

logger = logging.getLogger(__name__)

# Registry of built-in strategies
_STRATEGY_REGISTRY: Final[dict[str, type[WatermarkStrategy]]] = {
    "lexical": LexicalWatermarkStrategy,
    "syntactic": SyntacticWatermarkStrategy,
    "unicode": UnicodeWatermarkStrategy,
    "structural": StructuralWatermarkStrategy,
}


@dataclass
class CombinedWatermarkResult:
    """Aggregated result from applying multiple strategies."""

    original_text: str
    watermarked_text: str
    strategy_results: list[WatermarkResult] = field(default_factory=list)
    total_changes: int = 0

    @property
    def strategies_applied(self) -> list[str]:
        return [r.strategy for r in self.strategy_results if r.was_modified]


@dataclass
class CombinedDetectionScore:
    """Aggregated detection score from multiple strategies."""

    overall_score: float
    confidence_level: str
    strategy_scores: list[DetectionScore] = field(default_factory=list)

    @property
    def attributed(self) -> bool:
        return self.overall_score >= 0.65


def register_strategy(name: str, cls: type[WatermarkStrategy]) -> None:
    """Register a custom watermarking strategy.

    Args:
        name: Unique strategy identifier (lowercase). Must not conflict with built-ins.
        cls:  A class that subclasses :class:`~honeypotllm.watermark.base.WatermarkStrategy`.

    Raises:
        ValueError: If ``name`` is already registered.
    """
    if name in _STRATEGY_REGISTRY:
        raise ValueError(
            f"Strategy '{name}' is already registered. "
            "Choose a different name or use a namespace prefix."
        )
    _STRATEGY_REGISTRY[name] = cls
    logger.info("Registered custom watermark strategy: %s", name)


class WatermarkEngine:
    """Orchestrates multiple watermarking strategies.

    Args:
        config: A :class:`~honeypotllm.config.WatermarkConfig` instance.
    """

    def __init__(self, config: WatermarkConfig) -> None:
        self.config = config
        self._strategies: list[WatermarkStrategy] = []
        self._build_strategies()

    def _build_strategies(self) -> None:
        for name in self.config.strategies:
            cls = _STRATEGY_REGISTRY.get(name)
            if cls is None:
                raise WatermarkError(
                    f"Unknown watermark strategy: '{name}'. Available: {sorted(_STRATEGY_REGISTRY)}"
                )
            if name == "lexical":
                strategy = LexicalWatermarkStrategy(
                    substitution_rate=self.config.lexical.substitution_rate,
                    min_word_length=self.config.lexical.min_word_length,
                    eligible_pos_tags=self.config.lexical.target_pos_tags,
                )
            elif name == "syntactic":
                strategy = SyntacticWatermarkStrategy(
                    perturbation_rate=self.config.syntactic.perturbation_rate,
                    operations=self.config.syntactic.operations,
                )
            elif name == "unicode":
                strategy = UnicodeWatermarkStrategy(
                    bits_per_space=self.config.unicode.bits_per_space,
                )
            else:
                strategy = cls()
            self._strategies.append(strategy)
            logger.debug("Initialized watermark strategy: %s", name)

    def apply(self, text: str, watermark_id: str) -> CombinedWatermarkResult:
        """Apply all configured strategies to ``text`` in sequence.

        Args:
            text:         The original LLM response text.
            watermark_id: UUID string unique to the API key being watermarked.

        Returns:
            A :class:`CombinedWatermarkResult` with the final watermarked text.

        Raises:
            WatermarkError: If any strategy raises an unrecoverable error.
        """
        current_text = text
        results: list[WatermarkResult] = []
        total_changes = 0

        for strategy in self._strategies:
            seed = strategy.derive_key_seed(self.config.global_seed, watermark_id)
            try:
                result = strategy.apply(current_text, seed)
            except Exception as exc:
                raise WatermarkError(f"Strategy '{strategy.name}' failed to apply: {exc}") from exc
            results.append(result)
            total_changes += result.changes_made
            current_text = result.watermarked_text

        logger.debug(
            "Applied %d strategy/ies to text, %d total changes", len(results), total_changes
        )

        return CombinedWatermarkResult(
            original_text=text,
            watermarked_text=current_text,
            strategy_results=results,
            total_changes=total_changes,
        )

    def detect(self, texts: list[str], watermark_id: str) -> CombinedDetectionScore:
        """Run all strategies' detection against a corpus and return a combined score.

        Args:
            texts:        Outputs from a suspected stolen model.
            watermark_id: The watermark UUID of the API key under investigation.

        Returns:
            A :class:`CombinedDetectionScore` with an overall match score and
            per-strategy breakdown.
        """
        if not texts:
            return CombinedDetectionScore(
                overall_score=0.0, confidence_level="low", strategy_scores=[]
            )

        strategy_scores: list[DetectionScore] = []

        for strategy in self._strategies:
            seed = strategy.derive_key_seed(self.config.global_seed, watermark_id)
            try:
                score = strategy.detect(texts, seed)
            except Exception as exc:
                logger.warning("Strategy '%s' detection failed: %s", strategy.name, exc)
                score = DetectionScore(strategy=strategy.name, score=0.0)
            strategy_scores.append(score)

        # Weighted average (all strategies equal weight for now)
        if strategy_scores:
            overall = sum(s.score for s in strategy_scores) / len(strategy_scores)
        else:
            overall = 0.0

        if overall >= 0.85:
            confidence = "high"
        elif overall >= 0.60:
            confidence = "medium"
        else:
            confidence = "low"

        return CombinedDetectionScore(
            overall_score=overall,
            confidence_level=confidence,
            strategy_scores=strategy_scores,
        )

    @property
    def strategy_names(self) -> list[str]:
        """Names of the active strategies in application order."""
        return [s.name for s in self._strategies]

    def __repr__(self) -> str:
        return f"WatermarkEngine(strategies={self.strategy_names})"
