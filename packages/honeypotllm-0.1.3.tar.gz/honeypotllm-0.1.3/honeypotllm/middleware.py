"""Framework-agnostic honeypot middleware.

The :class:`HoneypotMiddleware` can be used in three ways:

1. **Async callable** (framework-agnostic)::

       honeypot = HoneypotMiddleware(config)
       await honeypot.init()

       # In any async handler:
       watermarked_text = await honeypot.process(
           api_key="user-api-key",
           response_text="original LLM response",
           prompt="user's prompt",
       )

2. **FastAPI / Starlette middleware** (wraps the entire ASGI app)::

       from honeypotllm.middleware import FastAPIMiddleware
       app.add_middleware(FastAPIMiddleware, config=config)

3. **Per-request decorator** (for explicit control)::

       @honeypot.protect(extract_key=lambda req: req.headers["X-Api-Key"])
       async def chat(request):
           return await llm.generate(request)

Design:
- The raw API key is NEVER stored. Only its SHA-256 hash is persisted.
- Real users (below threshold) always receive the original, unmodified response.
- Watermarking is applied only to keys that exceed the suspicion threshold.
- The bypass header allows trusted internal callers to skip watermarking entirely.
"""

from __future__ import annotations

import hashlib
import logging
from typing import TYPE_CHECKING, Any

from pydantic import BaseModel, Field

from honeypotllm.audit import AuditLogger
from honeypotllm.config import HoneypotConfig
from honeypotllm.scoring import SuspicionScorer
from honeypotllm.watermark import WatermarkEngine

if TYPE_CHECKING:
    from collections.abc import Callable
    from pathlib import Path

    from starlette.requests import Request
    from starlette.responses import Response

logger = logging.getLogger(__name__)


class ProcessResult(BaseModel):
    """Result of processing a single API call through the middleware.

    Attributes:
        api_key_hash:         SHA-256 hash of the raw API key (never the key itself).
        original_text:        The original LLM response before any modification.
        response_text:        The response to send to the caller. Equal to
                              ``original_text`` for clean users; watermarked for
                              suspicious keys.
        is_watermarked:       ``True`` if the response was watermarked. Always
                              ``False`` for legitimate users and trusted keys.
        suspicion_score:      Score 0.0–1.0 for this API key. 0.0 = clean.
        score_delta:          How much the score changed on this request.
        triggered_heuristics: List of heuristic names that fired on this request.
        watermark_id:         The UUID identifying this key's watermark family.
                              ``None`` if the response was not watermarked.
        strategies_applied:   Which watermark strategies were applied.
    """

    api_key_hash: str
    original_text: str
    response_text: str
    is_watermarked: bool = Field(
        description="True if this response was watermarked (caller is suspicious)."
    )
    suspicion_score: float
    score_delta: float
    triggered_heuristics: list[str]
    watermark_id: str | None = None
    strategies_applied: list[str] | None = None

    @property
    def was_watermarked(self) -> bool:  # noqa: D102 — backward-compat alias
        """Deprecated alias for :attr:`is_watermarked`. Use ``is_watermarked``."""
        return self.is_watermarked


def _hash_key(raw_key: str) -> str:
    return hashlib.sha256(raw_key.encode()).hexdigest()


class HoneypotMiddleware:
    """Core honeypot middleware — framework-agnostic.

    Args:
        config: A :class:`~honeypotllm.config.HoneypotConfig` instance.
    """

    def __init__(self, config: HoneypotConfig) -> None:
        self.config = config
        self._scorer = SuspicionScorer(config.scoring, config.suspicion_threshold)
        self._watermark_engine = WatermarkEngine(config.watermark)
        self._audit = AuditLogger(config)
        self._key_watermark_ids: dict[str, str] = {}  # key_hash → watermark_id
        self._alerted_keys: set[str] = set()  # keys already sent a webhook alert
        self._initialized = False

    @classmethod
    def from_yaml(cls, path: str | Path) -> HoneypotMiddleware:
        """Create a :class:`HoneypotMiddleware` from a YAML config file.

        Args:
            path: Path to a YAML configuration file.

        Returns:
            An uninitialized :class:`HoneypotMiddleware` instance.
            Call :meth:`init` before first use.
        """
        config = HoneypotConfig.from_yaml(path)
        return cls(config)

    async def init(self) -> None:
        """Initialize the database and prepare all subsystems.

        Must be called once before :meth:`process` is used.
        Idempotent — safe to call multiple times.

        Automatically downloads required NLTK data if the ``lexical``
        watermarking strategy is active (no manual setup needed).
        """
        if self._initialized:
            return
        # Auto-download NLTK data if lexical strategy is requested
        if "lexical" in self.config.watermark.strategies:
            try:
                from honeypotllm.watermark.lexical import _ensure_nltk_data

                _ensure_nltk_data()
            except Exception as exc:  # noqa: BLE001
                logger.warning("NLTK auto-setup failed: %s", exc)
        await self._audit.init()
        self._initialized = True
        logger.info(
            "HoneypotMiddleware initialized (threshold=%.2f, strategies=%s)",
            self.config.suspicion_threshold,
            self._watermark_engine.strategy_names,
        )

    async def __aenter__(self) -> HoneypotMiddleware:
        """Async context manager entry — calls :meth:`init` automatically.

        Usage::

            async with HoneypotMiddleware(config) as honeypot:
                result = await honeypot.process(...)
        """
        await self.init()
        return self

    async def __aexit__(self, *_: object) -> None:
        """Async context manager exit — calls :meth:`close` automatically."""
        await self.close()

    async def process(
        self,
        *,
        api_key: str,
        response_text: str,
        prompt: str = "",
        input_tokens: int = 0,
        bypass_token: str = "",
    ) -> ProcessResult:
        """Process a single API response through the honeypot pipeline.

        Args:
            api_key:       The raw API key from the request. NEVER stored.
            response_text: The LLM's response text to potentially watermark.
            prompt:        The user's prompt (for sequential detection).
            input_tokens:  Token count of the prompt (for volume heuristics).
            bypass_token:  If this matches ``config.bypass_token``, skip watermarking.

        Returns:
            A :class:`ProcessResult` with the (possibly watermarked) response text.
        """
        if not self._initialized:
            await self.init()

        key_hash = _hash_key(api_key)

        # ── Bypass check ──────────────────────────────────────────────────────
        # trusted_keys in config stores SHA-256 hashes of raw API keys.
        # key_hash is also SHA-256(raw_key). Compare directly — do NOT re-hash.
        is_trusted = key_hash in set(self.config.trusted_keys)
        has_bypass = bool(self.config.bypass_token) and bypass_token == self.config.bypass_token

        if is_trusted or has_bypass:
            logger.debug("Bypassing watermark for key %s… (trusted=%s)", key_hash[:8], is_trusted)
            return ProcessResult(
                api_key_hash=key_hash,
                original_text=response_text,
                response_text=response_text,
                is_watermarked=False,
                suspicion_score=0.0,
                score_delta=0.0,
                triggered_heuristics=[],
            )

        # ── Suspicion scoring ─────────────────────────────────────────────────
        scoring_result = self._scorer.score_request(
            key_hash,
            prompt=prompt,
            input_tokens=input_tokens,
            trusted=is_trusted,
        )

        # ── Watermarking decision ─────────────────────────────────────────────
        was_watermarked = False
        final_text = response_text
        watermark_id: str | None = None
        strategies_applied: list[str] | None = None

        if scoring_result.should_honeypot:
            watermark_id = self._get_or_create_watermark_id(key_hash)
            try:
                wm_result = self._watermark_engine.apply(response_text, watermark_id)
                final_text = wm_result.watermarked_text
                was_watermarked = True
                strategies_applied = wm_result.strategies_applied
                logger.info(
                    "Watermarked response for key %s… (score=%.3f, changes=%d)",
                    key_hash[:8],
                    scoring_result.score_after,
                    wm_result.total_changes,
                )

                # Log the watermarking event
                await self._audit.log(
                    event_type="response_watermarked",
                    api_key_hash=key_hash,
                    payload={
                        "watermark_id": watermark_id,
                        "suspicion_score": scoring_result.score_after,
                        "strategies": strategies_applied,
                        "changes": wm_result.total_changes,
                        "prompt_hash": hashlib.sha256(prompt.encode()).hexdigest()[:16]
                        if prompt
                        else None,
                    },
                )
            except Exception as exc:
                # Watermarking failure must NEVER affect real users
                # Fall back to original response, log the error
                logger.error("Watermarking failed for key %s…: %s", key_hash[:8], exc)
                final_text = response_text
                was_watermarked = False

        # ── Audit the request regardless ──────────────────────────────────────
        if scoring_result.score_delta > 0 or scoring_result.should_honeypot:
            await self._audit.log(
                event_type="suspicion_score_update",
                api_key_hash=key_hash,
                payload={
                    "score_before": scoring_result.score_before,
                    "score_after": scoring_result.score_after,
                    "score_delta": scoring_result.score_delta,
                    "triggered_heuristics": scoring_result.triggered_heuristics,
                    "should_honeypot": scoring_result.should_honeypot,
                },
            )

        result = ProcessResult(
            api_key_hash=key_hash,
            original_text=response_text,
            response_text=final_text,
            is_watermarked=was_watermarked,
            suspicion_score=scoring_result.score_after,
            score_delta=scoring_result.score_delta,
            triggered_heuristics=scoring_result.triggered_heuristics,
            watermark_id=watermark_id,
            strategies_applied=strategies_applied,
        )

        # Webhook alert (fire-and-forget — never blocks or raises)
        if was_watermarked and self.config.webhook_url:
            should_alert = (
                not self.config.alert_on_first_detection_only or key_hash not in self._alerted_keys
            )
            if should_alert:
                self._alerted_keys.add(key_hash)
                import asyncio

                from honeypotllm.alerts import fire_webhook

                asyncio.ensure_future(
                    fire_webhook(
                        config=self.config,
                        api_key_hash=key_hash,
                        suspicion_score=scoring_result.score_after,
                        triggered_heuristics=scoring_result.triggered_heuristics,
                        watermark_id=watermark_id,
                        score_delta=scoring_result.score_delta,
                    )
                )

        return result

    def get_suspicion_score(self, api_key: str) -> float:
        """Return the current suspicion score for a raw API key."""
        return self._scorer.get_score(_hash_key(api_key))

    def is_suspicious(self, api_key: str) -> bool:
        """Return True if the key's suspicion score exceeds the threshold."""
        return self._scorer.is_suspicious(_hash_key(api_key))

    def reset_score(self, api_key: str) -> None:
        """Manually reset the suspicion score for a key (e.g. after human review)."""
        self._scorer.reset(_hash_key(api_key))

    def summary(self) -> list[dict[str, Any]]:
        """Return a summary of all tracked API keys and their suspicion states."""
        return self._scorer.summary()

    async def export_evidence(self, api_key: str, output_path: str) -> dict[str, Any]:
        """Export a forensic evidence package for an API key.

        Args:
            api_key:     The raw API key.
            output_path: Path to write the JSON forensic package.

        Returns:
            The forensic package as a dict.
        """
        key_hash = _hash_key(api_key)
        return await self._audit.export_forensic_package(key_hash, output_path)

    async def close(self) -> None:
        """Cleanly shut down the middleware (close DB connections)."""
        await self._audit.close()
        logger.info("HoneypotMiddleware closed.")

    def _get_or_create_watermark_id(self, key_hash: str) -> str:
        """Get or generate a stable watermark_id for a key_hash."""
        if key_hash not in self._key_watermark_ids:
            # Derive a deterministic watermark_id from key_hash + secret to avoid
            # generating new UUIDs on every restart (which would break detection)
            import hashlib
            import uuid as _uuid

            seed_material = f"watermark-id:{key_hash}:{self.config.secret_key}"
            deterministic_uuid = str(
                _uuid.UUID(hashlib.sha256(seed_material.encode()).hexdigest()[:32])
            )
            self._key_watermark_ids[key_hash] = deterministic_uuid
        return self._key_watermark_ids[key_hash]


# ─── FastAPI / Starlette Integration ─────────────────────────────────────────

try:
    from starlette.middleware.base import BaseHTTPMiddleware

    class FastAPIMiddleware(BaseHTTPMiddleware):
        """Starlette/FastAPI ASGI middleware that wraps the entire application.

        Intercepts all responses and applies watermarking to flagged keys.

        **Note**: This middleware works on raw HTTP responses. If your LLM API
        returns streaming responses, use the per-request :meth:`~HoneypotMiddleware.process`
        method instead for finer-grained control.

        Args:
            app:             The ASGI application to wrap.
            config:          A :class:`~honeypotllm.config.HoneypotConfig` instance.
            api_key_header:  HTTP header name containing the API key (default: ``Authorization``).
            extract_key:     Optional callable to extract the raw key from a :class:`Request`.
        """

        def __init__(
            self,
            app: Any,
            *,
            config: HoneypotConfig,
            api_key_header: str = "Authorization",
            extract_key: Callable[[Any], str] | None = None,
        ) -> None:
            super().__init__(app)
            self._honeypot = HoneypotMiddleware(config)
            self._api_key_header = api_key_header
            self._extract_key = extract_key
            self._config = config

        async def dispatch(self, request: Request, call_next: Callable) -> Response:
            # Initialize on first request (lazy init for compatibility with lifespan)
            if not self._honeypot._initialized:
                await self._honeypot.init()

            # Extract API key
            if self._extract_key:
                raw_key = self._extract_key(request)
            else:
                auth_header = request.headers.get(self._api_key_header, "")
                raw_key = auth_header.removeprefix("Bearer ").strip()

            if not raw_key:
                # No key → pass through unchanged
                return await call_next(request)

            # Check bypass header
            bypass_token = request.headers.get(self._config.bypass_header, "")

            # Read and cache the request body BEFORE call_next consumes the stream.
            # ASGI request bodies are single-read streams; we must buffer them here.
            prompt = ""
            try:
                body_bytes = await request.body()  # Starlette caches this internally
                import json as _json

                req_data = _json.loads(body_bytes)
                messages = req_data.get("messages", [])
                if messages:
                    prompt = str(messages[-1].get("content", ""))
            except Exception:
                pass  # Non-JSON body or missing messages key — prompt stays ""

            # Get the real response
            response = await call_next(request)

            # Only process JSON/text responses
            content_type = response.headers.get("content-type", "")
            if "application/json" not in content_type and "text/" not in content_type:
                return response

            # Buffer body
            body_chunks = []
            async for chunk in response.body_iterator:
                body_chunks.append(chunk)
            body = b"".join(body_chunks).decode("utf-8", errors="replace")

            # Process through honeypot
            try:
                result = await self._honeypot.process(
                    api_key=raw_key,
                    response_text=body,
                    prompt=prompt,
                    bypass_token=bypass_token,
                )
                final_body = result.response_text.encode("utf-8")
            except Exception as exc:
                logger.error("FastAPIMiddleware: processing error: %s", exc)
                final_body = body.encode("utf-8")

            from starlette.responses import Response as StarletteResponse

            return StarletteResponse(
                content=final_body,
                status_code=response.status_code,
                headers=dict(response.headers),
                media_type=response.media_type,
            )

except ImportError:
    pass  # FastAPI/Starlette not installed; FastAPIMiddleware not available
