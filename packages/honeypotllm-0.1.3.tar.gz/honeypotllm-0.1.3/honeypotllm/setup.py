"""Entry point for ``python -m honeypotllm.setup``.

Downloads all required NLTK data for the lexical watermarking strategy.

Usage::

    python -m honeypotllm.setup
"""

from honeypotllm import setup

if __name__ == "__main__":
    setup()
