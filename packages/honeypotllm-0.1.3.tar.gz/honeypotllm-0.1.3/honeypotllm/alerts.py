"""Real-time alerting for honeypotllm scraper detection events.

Sends a signed JSON payload to a configured webhook URL when a suspicious
API key crosses the suspicion threshold for the first time.

Compatible with:
- **Slack** incoming webhooks (``https://hooks.slack.com/services/...``)
- **Discord** webhooks (``https://discord.com/api/webhooks/...``)
- **PagerDuty** Events API v2
- Any HTTP endpoint accepting POST JSON

Usage::

    # In honeypot_config.yaml:
    webhook_url: "https://hooks.slack.com/services/T00/B00/xxx"
    webhook_secret: "my-signing-secret"    # optional but recommended
    alert_on_first_detection_only: true    # default

The webhook payload::

    {
        "event": "scraper_detected",
        "api_key_hash": "8da255c3...",       # SHA-256, never the raw key
        "suspicion_score": 0.92,
        "triggered_heuristics": ["rate_spike", "sequential_input", "no_gap"],
        "watermark_id": "uuid",
        "timestamp": "2026-04-04T02:00:00Z",
        "library": "honeypotllm"
    }

Slack-compatible: the payload also includes a ``text`` field with a
pre-formatted message that renders nicely as a Slack notification.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import logging
from datetime import datetime, timezone
from typing import TYPE_CHECKING

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from honeypotllm.config import HoneypotConfig


def _is_discord_url(url: str) -> bool:
    return "discord.com/api/webhooks" in url


def _build_payload(
    *,
    api_key_hash: str,
    suspicion_score: float,
    triggered_heuristics: list[str],
    watermark_id: str | None,
    score_delta: float,
    webhook_url: str = "",
) -> dict:
    """Build the JSON payload sent to the webhook.

    Auto-detects Slack vs Discord from the URL and adjusts format:
    - **Slack** uses the ``text`` field (Slack markdown)
    - **Discord** uses ``content`` + ``embeds`` (Discord ignores ``text``)
    - **Custom endpoints** get both plus all structured fields
    """
    ts = datetime.now(timezone.utc).isoformat()
    triggers_str = ", ".join(triggered_heuristics) if triggered_heuristics else "none"

    message = (
        f"\U0001f36f **honeypotllm** \u2014 Scraper detected!\n"
        f"\u2022 Key hash: `{api_key_hash[:16]}\u2026`\n"
        f"\u2022 Score: `{suspicion_score:.2f}` (+{score_delta:.2f})\n"
        f"\u2022 Signals: `{triggers_str}`\n"
        f"\u2022 Watermark ID: `{watermark_id or 'n/a'}`\n"
        f"\u2022 Time: {ts}"
    )

    payload: dict = {
        # Structured fields for custom HTTP endpoints
        "event": "scraper_detected",
        "api_key_hash": api_key_hash,
        "suspicion_score": round(suspicion_score, 4),
        "score_delta": round(score_delta, 4),
        "triggered_heuristics": triggered_heuristics,
        "watermark_id": watermark_id,
        "timestamp": ts,
        "library": "honeypotllm",
    }

    if _is_discord_url(webhook_url):
        # Discord: 'content' for the plain message, 'embeds' for the rich card
        payload["content"] = message
        payload["username"] = "honeypotllm"
        payload["embeds"] = [
            {
                "title": "\U0001f36f Scraper Detected",
                "color": 0xFF4444,  # red
                "fields": [
                    {"name": "Score", "value": f"`{suspicion_score:.2f}`", "inline": True},
                    {"name": "Delta", "value": f"`+{score_delta:.2f}`", "inline": True},
                    {"name": "Signals", "value": f"`{triggers_str}`", "inline": False},
                    {"name": "Key hash", "value": f"`{api_key_hash[:16]}\u2026`", "inline": False},
                    {
                        "name": "Watermark ID",
                        "value": f"`{watermark_id or 'n/a'}`",
                        "inline": False,
                    },
                ],
                "footer": {"text": "honeypotllm"},
                "timestamp": ts,
            }
        ]
    else:
        # Slack (and generic endpoints): 'text' field, Slack uses single * for bold
        payload["text"] = message.replace("**", "*")

    return payload


def _sign_payload(raw_body: bytes, secret: str) -> str:
    """Return HMAC-SHA256 signature in the format ``sha256=<hex>``."""
    sig = hmac.new(secret.encode(), raw_body, hashlib.sha256).hexdigest()
    return f"sha256={sig}"


async def fire_webhook(
    *,
    config: HoneypotConfig,
    api_key_hash: str,
    suspicion_score: float,
    triggered_heuristics: list[str],
    watermark_id: str | None,
    score_delta: float,
) -> None:
    """Send a scraper-detection alert to the configured webhook URL.

    This is a fire-and-forget async function — it logs errors but never
    raises, so a webhook failure can never affect the real LLM response.

    Args:
        config:               The :class:`~honeypotllm.config.HoneypotConfig`.
        api_key_hash:         SHA-256 hash of the suspicious API key.
        suspicion_score:      Current suspicion score (0.0–1.0).
        triggered_heuristics: List of heuristic names that fired.
        watermark_id:         Watermark UUID for this key, if assigned.
        score_delta:          Score increase on this request.
    """
    if not config.webhook_url:
        return

    try:
        import httpx
    except ImportError:
        logger.warning(
            "honeypotllm: webhook_url is set but httpx is not installed. "
            "Install it with: pip install httpx"
        )
        return

    payload = _build_payload(
        api_key_hash=api_key_hash,
        suspicion_score=suspicion_score,
        triggered_heuristics=triggered_heuristics,
        watermark_id=watermark_id,
        score_delta=score_delta,
        webhook_url=config.webhook_url or "",
    )
    raw_body = json.dumps(payload, separators=(",", ":")).encode()

    headers = {"Content-Type": "application/json", "User-Agent": "honeypotllm/0.1.3"}
    if config.webhook_secret:
        headers["X-Honeypot-Signature"] = _sign_payload(raw_body, config.webhook_secret)

    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            resp = await client.post(config.webhook_url, content=raw_body, headers=headers)
            if resp.status_code >= 400:
                logger.warning(
                    "Webhook at %s returned HTTP %d",
                    config.webhook_url,
                    resp.status_code,
                )
            else:
                logger.info(
                    "Webhook alert sent for key %s... (score=%.2f)",
                    api_key_hash[:8],
                    suspicion_score,
                )
    except Exception as exc:  # noqa: BLE001
        # NEVER let an alert failure break the main request path
        logger.warning("Webhook delivery failed: %s", exc)
