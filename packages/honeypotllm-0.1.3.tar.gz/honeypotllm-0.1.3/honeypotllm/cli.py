"""honeypotllm command-line interface.

Usage::

    # Run watermark detection on a JSONL file of suspected outputs
    honeypotllm detect --outputs suspicious_outputs.jsonl \\
                       --watermark-ids uuid1 uuid2 \\
                       --config honeypot_config.yaml \\
                       --report report.json

    # Export a forensic evidence package for an API key hash
    honeypotllm export-evidence --key-hash <sha256-hash> \\
                                --config honeypot_config.yaml \\
                                --output evidence.json

    # Show dashboard summary in terminal
    honeypotllm status --config honeypot_config.yaml

    # Verify audit log chain integrity
    honeypotllm verify-log --config honeypot_config.yaml

    # Generate a sample config file
    honeypotllm init-config --output honeypot_config.yaml
"""

from __future__ import annotations

import asyncio
import json
import logging
import sys
from pathlib import Path

import click
from rich.console import Console
from rich.logging import RichHandler
from rich.table import Table

from honeypotllm.__version__ import __version__

console = Console()

# ─── Logging setup ────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.WARNING,
    format="%(message)s",
    handlers=[RichHandler(console=console, rich_tracebacks=True)],
)


# ─── CLI group ────────────────────────────────────────────────────────────────


@click.group()
@click.version_option(__version__, "-V", "--version")
@click.option("-v", "--verbose", is_flag=True, help="Enable verbose logging.")
def main(verbose: bool) -> None:
    """🍯 honeypotllm — Protect your LLM API from data theft.

    Detect unauthorized model replication using output watermarking
    and behavioral fingerprinting.
    """
    if verbose:
        logging.getLogger().setLevel(logging.DEBUG)
        logging.getLogger("honeypotllm").setLevel(logging.DEBUG)


# ─── detect ───────────────────────────────────────────────────────────────────


@main.command("detect")
@click.option(
    "--outputs",
    required=True,
    type=click.Path(exists=True, path_type=Path),
    help='Path to a JSONL file where each line is {"text": "..."}.',
)
@click.option(
    "--watermark-ids",
    "-w",
    multiple=True,
    required=True,
    help="One or more watermark_id UUIDs to test against (can repeat).",
)
@click.option(
    "--config",
    "-c",
    default="honeypot_config.yaml",
    type=click.Path(path_type=Path),
    help="Path to YAML config file.",
)
@click.option(
    "--report",
    "-r",
    default=None,
    type=click.Path(path_type=Path),
    help="Path to save the JSON detection report.",
)
@click.option(
    "--model-name",
    default=None,
    help="Name/identifier of the suspected stolen model (for the report).",
)
def detect_cmd(
    outputs: Path,
    watermark_ids: tuple[str, ...],
    config: Path,
    report: Path | None,
    model_name: str | None,
) -> None:
    """Run watermark detection against suspected model outputs."""
    from honeypotllm.config import HoneypotConfig
    from honeypotllm.detection import Detector

    # Load texts
    texts: list[str] = []
    with open(outputs) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
                texts.append(obj.get("text", obj.get("content", str(obj))))
            except json.JSONDecodeError:
                texts.append(line)  # treat as raw text

    if not texts:
        console.print("[bold red]Error:[/] No texts found in the outputs file.")
        sys.exit(1)

    console.print(
        f"[bold cyan]honeypotllm detect[/] — {len(texts)} texts, {len(watermark_ids)} candidates"
    )

    # Load config
    try:
        cfg = HoneypotConfig.from_yaml(config) if config.exists() else HoneypotConfig()
    except Exception as exc:
        console.print(f"[bold red]Config error:[/] {exc}")
        sys.exit(1)

    detector = Detector(cfg)
    detection_report = detector.detect(
        texts=texts,
        candidate_watermark_ids=list(watermark_ids),
        target_model_name=model_name,
    )

    # Display results
    table = Table(title="Detection Results", show_header=True, header_style="bold magenta")
    table.add_column("Metric", style="cyan")
    table.add_column("Value", style="white")
    table.add_row("Overall Score", f"{detection_report.overall_score:.4f}")
    table.add_row("Confidence", detection_report.confidence_level.upper())
    table.add_row("Attribution", detection_report.attribution or "[dim]None[/dim]")
    table.add_row("Texts Analyzed", str(detection_report.num_texts))
    console.print(table)

    if detection_report.strategy_scores:
        strat_table = Table(title="Per-Strategy Scores", header_style="bold blue")
        strat_table.add_column("Strategy")
        strat_table.add_column("Score")
        strat_table.add_column("Confidence")
        for s in detection_report.strategy_scores:
            strat_table.add_row(s["strategy"], f"{s['score']:.4f}", s["confidence_level"])
        console.print(strat_table)

    if report:
        detection_report.save(str(report))
        console.print(f"[green]✓ Report saved to {report}[/]")

    # Exit code: 0 = attributed, 1 = not attributed
    sys.exit(0 if detection_report.is_attributed else 1)


# ─── export-evidence ──────────────────────────────────────────────────────────


@main.command("export-evidence")
@click.option("--key-hash", required=True, help="SHA-256 hash of the API key.")
@click.option("--config", "-c", default="honeypot_config.yaml", type=click.Path(path_type=Path))
@click.option(
    "--output",
    "-o",
    default="evidence.json",
    type=click.Path(path_type=Path),
    help="Path to write the forensic evidence package.",
)
def export_evidence_cmd(key_hash: str, config: Path, output: Path) -> None:
    """Export a forensic evidence package for a specific API key hash."""
    from honeypotllm.audit import AuditLogger
    from honeypotllm.config import HoneypotConfig

    try:
        cfg = HoneypotConfig.from_yaml(config) if config.exists() else HoneypotConfig()
    except Exception as exc:
        console.print(f"[bold red]Config error:[/] {exc}")
        sys.exit(1)

    async def _run() -> None:
        audit = AuditLogger(cfg)
        await audit.init()
        package = await audit.export_forensic_package(key_hash, str(output))
        await audit.close()
        console.print(
            f"[green]✓ Forensic package exported:[/] {package['num_entries']} entries → {output}"
        )
        if not package["chain_integrity_verified"]:
            console.print(
                "[bold red]⚠ WARNING:[/] Audit log integrity verification FAILED. "
                "The chain may have been tampered with."
            )

    asyncio.run(_run())


# ─── verify-log ───────────────────────────────────────────────────────────────


@main.command("verify-log")
@click.option("--config", "-c", default="honeypot_config.yaml", type=click.Path(path_type=Path))
def verify_log_cmd(config: Path) -> None:
    """Verify the HMAC integrity of the audit log chain."""
    from honeypotllm.audit import AuditLogger
    from honeypotllm.config import HoneypotConfig

    try:
        cfg = HoneypotConfig.from_yaml(config) if config.exists() else HoneypotConfig()
    except Exception as exc:
        console.print(f"[bold red]Config error:[/] {exc}")
        sys.exit(1)

    async def _run() -> bool:
        audit = AuditLogger(cfg)
        await audit.init()
        result = await audit.verify_integrity()
        await audit.close()
        return result

    ok = asyncio.run(_run())
    if ok:
        console.print("[bold green]✓ Audit log integrity verified — chain intact.[/]")
        sys.exit(0)
    else:
        console.print("[bold red]✗ Audit log integrity FAILED — possible tampering detected.[/]")
        sys.exit(1)


# ─── status ───────────────────────────────────────────────────────────────────


@main.command("status")
@click.option("--config", "-c", default="honeypot_config.yaml", type=click.Path(path_type=Path))
def status_cmd(config: Path) -> None:
    """Show a summary of honeypotllm configuration and status."""
    from honeypotllm.config import HoneypotConfig

    try:
        cfg = HoneypotConfig.from_yaml(config) if config.exists() else HoneypotConfig()
    except Exception as exc:
        console.print(f"[bold red]Config error:[/] {exc}")
        sys.exit(1)

    table = Table(title="honeypotllm Status", header_style="bold magenta")
    table.add_column("Setting", style="cyan")
    table.add_column("Value")
    table.add_row("Version", __version__)
    table.add_row("Suspicion Threshold", f"{cfg.suspicion_threshold:.2f}")
    table.add_row("Log Backend", cfg.log_backend)
    table.add_row("DB URL", cfg.db_url)
    table.add_row("Watermark Strategies", ", ".join(cfg.watermark.strategies))
    table.add_row("Trusted Keys", str(len(cfg.trusted_keys)))
    table.add_row("Fingerprinting", "enabled" if cfg.fingerprint.enabled else "disabled")
    secret_status = "[green]✓ Set[/]" if cfg.secret_key else "[bold red]⚠ NOT SET[/bold red]"
    table.add_row("Secret Key", secret_status)
    console.print(table)


# ─── init-config ──────────────────────────────────────────────────────────────


@main.command("init-config")
@click.option(
    "--output",
    "-o",
    default="honeypot_config.yaml",
    type=click.Path(path_type=Path),
    help="Path to write the generated config file.",
)
def init_config_cmd(output: Path) -> None:
    """Generate a sample honeypot_config.yaml with sensible defaults."""
    from honeypotllm.config import HoneypotConfig

    if output.exists():
        console.print(
            f"[yellow]File {output} already exists. "
            "Use a different --output path or delete it first.[/]"
        )
        sys.exit(1)

    cfg = HoneypotConfig()
    cfg.to_yaml(output)
    console.print(f"[green]✓ Config written to {output}[/]")
    console.print(
        "[bold yellow]⚠ Remember:[/] set the HONEYPOT_SECRET_KEY environment variable "
        "before deploying."
    )


if __name__ == "__main__":
    main()
