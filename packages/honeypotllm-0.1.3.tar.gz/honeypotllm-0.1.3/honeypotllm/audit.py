"""HMAC-chained, tamper-evident audit logger.

Every event written to the log is linked to the previous entry via HMAC-SHA256.
Tampering with any entry invalidates all subsequent entries, making the log
suitable as forensic evidence.

Chain construction:
    entry_hmac = HMAC-SHA256(
        key   = secret_key,
        data  = prev_hmac + ":" + timestamp_iso + ":" + json(payload),
    )

The ``prev_hmac`` for the very first entry is the HMAC of ``"GENESIS"`` to
establish a deterministic chain start.

Usage::

    logger = AuditLogger(config)
    await logger.init()
    await logger.log(
        event_type="request_received",
        api_key_hash="abc123",
        payload={"tokens": 42},
    )
    is_valid = await logger.verify_integrity()
"""

from __future__ import annotations

import hashlib
import hmac
import json
import logging
import uuid
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from honeypotllm.exceptions import AuditLogError
from honeypotllm.models import AuditLogEntry, Base

if TYPE_CHECKING:
    from honeypotllm.config import HoneypotConfig

logger = logging.getLogger(__name__)

_GENESIS_PREV_HMAC = "GENESIS"


def _compute_hmac(secret_key: str, prev_hmac: str, timestamp_iso: str, payload_json: str) -> str:
    """Compute the HMAC-SHA256 for a log entry."""
    message = f"{prev_hmac}:{timestamp_iso}:{payload_json}".encode()
    return hmac.new(secret_key.encode(), message, hashlib.sha256).hexdigest()


class AuditLogger:
    """Async, HMAC-chained audit logger backed by SQLite or PostgreSQL.

    Args:
        config: A :class:`~honeypotllm.config.HoneypotConfig` instance.
    """

    def __init__(self, config: HoneypotConfig) -> None:
        self.config = config
        self._secret_key = config.secret_key or "insecure-dev-key-do-not-use-in-prod"
        if not config.secret_key:
            logger.warning(
                "AuditLogger: secret_key is empty. "
                "HMAC integrity will use an insecure fallback key. "
                "Set HONEYPOT_SECRET_KEY environment variable."
            )
        self._engine = create_async_engine(config.db_url, echo=False)
        self._sessionmaker = async_sessionmaker(
            self._engine, expire_on_commit=False, class_=AsyncSession
        )
        self._last_hmac: str | None = None

    async def init(self) -> None:
        """Create database tables if they don't exist. Call once on startup."""
        try:
            async with self._engine.begin() as conn:
                await conn.run_sync(Base.metadata.create_all)
            logger.info("AuditLogger: database initialized at %s", self.config.db_url)
        except Exception as exc:
            raise AuditLogError(f"Failed to initialize audit database: {exc}") from exc

    async def log(
        self,
        event_type: str,
        payload: dict[str, Any],
        *,
        api_key_hash: str | None = None,
    ) -> AuditLogEntry:
        """Append a new entry to the HMAC-chained audit log.

        Args:
            event_type:   Human-readable event type string.
            payload:      JSON-serializable dict of event data.
            api_key_hash: SHA-256 hash of the involved API key (optional).

        Returns:
            The persisted :class:`~honeypotllm.models.AuditLogEntry`.

        Raises:
            AuditLogError: If the entry cannot be persisted.
        """
        now = datetime.now(tz=timezone.utc)
        timestamp_iso = now.isoformat()
        payload_json = json.dumps(payload, sort_keys=True, default=str)

        # Retrieve previous entry's HMAC
        async with self._sessionmaker() as session:
            prev_entry = await self._get_last_entry(session)
            prev_hmac = prev_entry.entry_hmac if prev_entry else _GENESIS_PREV_HMAC
            prev_uuid = prev_entry.entry_uuid if prev_entry else None

        entry_hmac = _compute_hmac(self._secret_key, prev_hmac, timestamp_iso, payload_json)
        entry_uuid = str(uuid.uuid4())

        entry = AuditLogEntry(
            entry_uuid=entry_uuid,
            timestamp=now,
            timestamp_iso=timestamp_iso,  # Store exact string used in HMAC
            event_type=event_type,
            api_key_hash=api_key_hash,
            payload=payload,
            prev_entry_uuid=prev_uuid,
            prev_hmac=prev_hmac,
            entry_hmac=entry_hmac,
        )

        try:
            async with self._sessionmaker() as session, session.begin():
                session.add(entry)
            self._last_hmac = entry_hmac
            logger.debug("Audit log entry: %s [%s]", event_type, entry_uuid[:8])
            return entry
        except Exception as exc:
            raise AuditLogError(f"Failed to write audit log entry: {exc}") from exc

    async def verify_integrity(self) -> bool:
        """Walk the entire audit log chain and verify HMAC linkage.

        Returns:
            True if the chain is intact; False if any entry has been tampered with.
        """
        async with self._sessionmaker() as session:
            result = await session.execute(select(AuditLogEntry).order_by(AuditLogEntry.id))
            entries: list[AuditLogEntry] = list(result.scalars().all())

        if not entries:
            return True  # Empty log is valid

        prev_hmac = _GENESIS_PREV_HMAC

        for entry in entries:
            # Recompute expected HMAC using the stored timestamp string.
            # This avoids round-trip formatting differences.
            payload_json = json.dumps(entry.payload, sort_keys=True, default=str)
            ts_str = entry.timestamp_iso or entry.timestamp.isoformat()
            expected_hmac = _compute_hmac(
                self._secret_key,
                prev_hmac,
                ts_str,
                payload_json,
            )
            if not hmac.compare_digest(expected_hmac, entry.entry_hmac):
                logger.error(
                    "Audit log INTEGRITY VIOLATION at entry %s (id=%d)",
                    entry.entry_uuid,
                    entry.id,
                )
                return False
            prev_hmac = entry.entry_hmac

        logger.info("Audit log integrity verified: %d entries OK", len(entries))
        return True

    async def export_forensic_package(self, api_key_hash: str, output_path: str) -> dict[str, Any]:
        """Export all audit log entries for a specific API key as a forensic package.

        Args:
            api_key_hash: SHA-256 hash of the API key.
            output_path:  Path to write the JSON forensic package.

        Returns:
            A dict containing the forensic package data.
        """
        async with self._sessionmaker() as session:
            result = await session.execute(
                select(AuditLogEntry)
                .where(AuditLogEntry.api_key_hash == api_key_hash)
                .order_by(AuditLogEntry.id)
            )
            entries: list[AuditLogEntry] = list(result.scalars().all())

        package = {
            "generated_at": datetime.now(tz=timezone.utc).isoformat(),
            "api_key_hash": api_key_hash,
            "num_entries": len(entries),
            "chain_integrity_verified": await self.verify_integrity(),
            "entries": [
                {
                    "entry_uuid": e.entry_uuid,
                    "timestamp": e.timestamp.isoformat(),
                    "event_type": e.event_type,
                    "payload": e.payload,
                    "entry_hmac": e.entry_hmac,
                    "prev_entry_uuid": e.prev_entry_uuid,
                }
                for e in entries
            ],
        }

        with open(output_path, "w") as f:
            json.dump(package, f, indent=2, default=str)

        logger.info(
            "Forensic package exported: %d entries for key %s… → %s",
            len(entries),
            api_key_hash[:8],
            output_path,
        )
        return package

    async def close(self) -> None:
        """Cleanly close the database connection."""
        await self._engine.dispose()

    @staticmethod
    async def _get_last_entry(session: AsyncSession) -> AuditLogEntry | None:
        result = await session.execute(
            select(AuditLogEntry).order_by(AuditLogEntry.id.desc()).limit(1)
        )
        return result.scalars().first()
