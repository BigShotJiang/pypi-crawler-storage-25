"""Shared pytest fixtures for honeypotllm tests."""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING

import pytest

from honeypotllm.config import HoneypotConfig, ScoringConfig, WatermarkConfig

if TYPE_CHECKING:
    from pathlib import Path


@pytest.fixture(scope="session")
def event_loop_policy():
    return asyncio.DefaultEventLoopPolicy()


@pytest.fixture
def minimal_config(tmp_path: Path) -> HoneypotConfig:
    """A minimal HoneypotConfig suitable for testing."""
    db_url = f"sqlite+aiosqlite:///{tmp_path}/test_audit.db"
    return HoneypotConfig(
        secret_key="test-secret-key-for-unit-tests-only",
        suspicion_threshold=0.75,
        log_backend="sqlite",
        db_url=db_url,
        watermark=WatermarkConfig(
            strategies=["unicode"],  # Use only unicode for speed in tests
            global_seed=12345,
        ),
        scoring=ScoringConfig(
            requests_per_minute_threshold=5,
            requests_per_hour_threshold=50,
            requests_per_day_threshold=200,
            rate_weight=0.35,
            sequential_weight=0.30,
            gap_weight=0.20,
            volume_weight=0.15,
        ),
    )


@pytest.fixture
def lexical_config(tmp_path: Path) -> HoneypotConfig:
    """Config with lexical watermarking enabled for testing that strategy."""
    db_url = f"sqlite+aiosqlite:///{tmp_path}/test_lexical.db"
    return HoneypotConfig(
        secret_key="test-secret-key-lexical",
        db_url=db_url,
        watermark=WatermarkConfig(
            strategies=["lexical"],
            global_seed=99,
        ),
    )


@pytest.fixture
def sample_text() -> str:
    return (
        "Machine learning models require substantial computational resources "
        "during the training process. The optimization algorithm iterates over "
        "the dataset multiple times, adjusting parameters to minimize the loss function. "
        "Modern neural networks can contain billions of parameters, making efficient "
        "training infrastructure absolutely essential for competitive development."
    )


@pytest.fixture
def watermark_id() -> str:
    return "550e8400-e29b-41d4-a716-446655440000"
