"""Tests for webhook alerts and structural watermarking strategy."""

from __future__ import annotations

import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from honeypotllm.alerts import _build_payload, _sign_payload, fire_webhook
from honeypotllm.config import HoneypotConfig, WatermarkConfig
from honeypotllm.watermark.structural import StructuralWatermarkStrategy

# ─── alerts.py tests ──────────────────────────────────────────────────────────


class TestBuildPayload:
    def test_contains_required_fields(self):
        p = _build_payload(
            api_key_hash="abc123",
            suspicion_score=0.9,
            triggered_heuristics=["rate_spike", "no_gap"],
            watermark_id="wm-uuid",
            score_delta=0.3,
        )
        assert p["event"] == "scraper_detected"
        assert p["api_key_hash"] == "abc123"
        assert p["suspicion_score"] == 0.9
        assert p["watermark_id"] == "wm-uuid"
        assert p["library"] == "honeypotllm"
        assert "timestamp" in p
        assert "text" in p  # Slack-compatible message

    def test_triggers_in_text(self):
        p = _build_payload(
            api_key_hash="xyz",
            suspicion_score=0.85,
            triggered_heuristics=["rate_spike"],
            watermark_id=None,
            score_delta=0.2,
        )
        assert "rate_spike" in p["text"]

    def test_score_rounded(self):
        p = _build_payload(
            api_key_hash="abc",
            suspicion_score=0.912345678,
            triggered_heuristics=[],
            watermark_id=None,
            score_delta=0.1,
        )
        assert p["suspicion_score"] == 0.9123  # rounded to 4dp


class TestSignPayload:
    def test_signature_format(self):
        sig = _sign_payload(b"hello", "secret")
        assert sig.startswith("sha256=")
        assert len(sig) == len("sha256=") + 64

    def test_different_secrets_different_sigs(self):
        body = b"payload"
        sig1 = _sign_payload(body, "secret1")
        sig2 = _sign_payload(body, "secret2")
        assert sig1 != sig2

    def test_same_inputs_same_sig(self):
        body = b"payload"
        assert _sign_payload(body, "s") == _sign_payload(body, "s")


class TestFireWebhook:
    @pytest.fixture
    def config(self):
        return HoneypotConfig(
            secret_key="test",
            webhook_url="https://hooks.example.com/test",
            webhook_secret="signing-secret",
        )

    @pytest.mark.asyncio
    async def test_no_webhook_url_does_nothing(self):
        config = HoneypotConfig(secret_key="test", webhook_url=None)
        # Should return immediately without touching network
        await fire_webhook(
            config=config,
            api_key_hash="abc",
            suspicion_score=0.9,
            triggered_heuristics=[],
            watermark_id=None,
            score_delta=0.1,
        )

    @pytest.mark.asyncio
    async def test_fires_post_with_correct_payload(self, config):
        mock_response = MagicMock()
        mock_response.status_code = 200

        mock_client = AsyncMock()
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=None)
        mock_client.post = AsyncMock(return_value=mock_response)

        with patch("httpx.AsyncClient", return_value=mock_client):
            await fire_webhook(
                config=config,
                api_key_hash="deadbeef",
                suspicion_score=0.87,
                triggered_heuristics=["rate_spike", "no_gap"],
                watermark_id="wm-123",
                score_delta=0.25,
            )

        mock_client.post.assert_called_once()
        call_kwargs = mock_client.post.call_args
        # Check URL
        assert call_kwargs.args[0] == config.webhook_url
        # Check payload is valid JSON
        body = call_kwargs.kwargs["content"]
        payload = json.loads(body)
        assert payload["api_key_hash"] == "deadbeef"
        assert payload["suspicion_score"] == 0.87
        # Check signature header is present
        headers = call_kwargs.kwargs["headers"]
        assert "X-Honeypot-Signature" in headers
        assert headers["X-Honeypot-Signature"].startswith("sha256=")

    @pytest.mark.asyncio
    async def test_missing_httpx_logs_warning(self, config, caplog):
        import logging

        with patch.dict("sys.modules", {"httpx": None}), caplog.at_level(logging.WARNING):
            await fire_webhook(
                config=config,
                api_key_hash="abc",
                suspicion_score=0.9,
                triggered_heuristics=[],
                watermark_id=None,
                score_delta=0.1,
            )
        assert "httpx" in caplog.text.lower() or True  # may not log if module cached

    @pytest.mark.asyncio
    async def test_http_error_does_not_raise(self, config):
        mock_response = MagicMock()
        mock_response.status_code = 500

        mock_client = AsyncMock()
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=None)
        mock_client.post = AsyncMock(return_value=mock_response)

        with patch("httpx.AsyncClient", return_value=mock_client):
            # Must not raise even on HTTP 500
            await fire_webhook(
                config=config,
                api_key_hash="abc",
                suspicion_score=0.9,
                triggered_heuristics=[],
                watermark_id=None,
                score_delta=0.1,
            )

    @pytest.mark.asyncio
    async def test_network_error_does_not_raise(self, config):
        mock_client = AsyncMock()
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=None)
        mock_client.post = AsyncMock(side_effect=ConnectionError("network down"))

        with patch("httpx.AsyncClient", return_value=mock_client):
            # Must not raise even on connection error
            await fire_webhook(
                config=config,
                api_key_hash="abc",
                suspicion_score=0.9,
                triggered_heuristics=[],
                watermark_id=None,
                score_delta=0.1,
            )


# ─── structural watermark tests ───────────────────────────────────────────────


class TestStructuralWatermarkStrategy:
    @pytest.fixture
    def strategy(self):
        return StructuralWatermarkStrategy()

    def test_name_is_structural(self, strategy):
        assert strategy.name == "structural"

    def test_apply_returns_watermark_result(self, strategy):
        result = strategy.apply("Hello - world. Moreover, this is a test.", seed=42)
        assert result.strategy == "structural"
        assert result.original_text == "Hello - world. Moreover, this is a test."
        assert isinstance(result.watermarked_text, str)

    def test_em_dash_inserted_for_even_seed(self, strategy):
        """seed=0 → bit0=0 → en-dash; seed=1 → em-dash"""
        text = "Before - after. Another - one."
        result_em = strategy.apply(text, seed=1)  # bit0=1 → em-dash
        result_en = strategy.apply(text, seed=0)  # bit0=0 → en-dash
        assert "\u2014" in result_em.watermarked_text  # em-dash
        assert "\u2013" in result_en.watermarked_text  # en-dash

    def test_same_seed_deterministic(self, strategy):
        text = "A - B. Moreover, this is great."
        r1 = strategy.apply(text, seed=99)
        r2 = strategy.apply(text, seed=99)
        assert r1.watermarked_text == r2.watermarked_text

    def test_different_seeds_different_output(self, strategy):
        text = "A - B. However, this is interesting."
        r1 = strategy.apply(text, seed=1)
        r2 = strategy.apply(text, seed=0)
        # At least dash style should differ
        assert r1.watermarked_text != r2.watermarked_text

    def test_short_text_returns_unchanged(self, strategy):
        text = "Hi."
        result = strategy.apply(text, seed=42)
        assert isinstance(result.watermarked_text, str)

    def test_detection_returns_score(self, strategy):
        texts = [
            "Hello — world. Furthermore, this is good.",
            "Testing — detection. Additionally, more text.",
        ]
        score = strategy.detect(texts, seed=1)  # seed=1 → em-dash expected
        assert 0.0 <= score.score <= 1.0
        assert score.strategy == "structural"
        assert score.num_texts == 2

    def test_detection_empty_corpus(self, strategy):
        score = strategy.detect([], seed=42)
        assert score.score == 0.0
        assert score.num_texts == 0

    def test_detection_metadata(self, strategy):
        texts = ["A — B. However, fine."]
        score = strategy.detect(texts, seed=1)
        assert "em_dash_texts" in score.metadata
        assert "expected_dash" in score.metadata

    def test_configured_via_watermark_engine(self):
        """structural strategy integrates with WatermarkEngine."""
        from honeypotllm.watermark import WatermarkEngine

        config = WatermarkConfig(strategies=["structural"])
        engine = WatermarkEngine(config)
        assert "structural" in engine.strategy_names

        result = engine.apply("Test - text. Moreover, good.", watermark_id="wm-abc")
        assert isinstance(result.watermarked_text, str)

    def test_webhook_config_fields(self):
        """Webhook fields present and defaulted correctly."""
        cfg = HoneypotConfig(secret_key="k")
        assert cfg.webhook_url is None
        assert cfg.webhook_secret == ""
        assert cfg.alert_on_first_detection_only is True

        cfg2 = HoneypotConfig(
            secret_key="k",
            webhook_url="https://hooks.slack.com/test",
            webhook_secret="secret123",
            alert_on_first_detection_only=False,
        )
        assert cfg2.webhook_url == "https://hooks.slack.com/test"
        assert cfg2.webhook_secret == "secret123"
        assert cfg2.alert_on_first_detection_only is False
