"""Tests for the HMAC-chained audit logger."""

from __future__ import annotations

from typing import TYPE_CHECKING

import pytest

from honeypotllm.audit import AuditLogger, _compute_hmac

if TYPE_CHECKING:
    from honeypotllm.config import HoneypotConfig


@pytest.fixture
async def logger(minimal_config: HoneypotConfig) -> AuditLogger:
    audit = AuditLogger(minimal_config)
    await audit.init()
    yield audit
    await audit.close()


class TestAuditLogger:
    async def test_init_creates_tables(self, minimal_config: HoneypotConfig, tmp_path):
        audit = AuditLogger(minimal_config)
        await audit.init()
        await audit.close()
        # If no exception, tables were created

    async def test_log_single_entry(self, logger: AuditLogger):
        entry = await logger.log(
            event_type="test_event",
            payload={"key": "value"},
            api_key_hash="abc123",
        )
        assert entry.event_type == "test_event"
        assert entry.api_key_hash == "abc123"
        assert entry.entry_hmac != ""

    async def test_multiple_entries_chain(self, logger: AuditLogger):
        await logger.log("event_1", {"n": 1})
        await logger.log("event_2", {"n": 2})
        await logger.log("event_3", {"n": 3})

    async def test_verify_integrity_empty_log(self, logger: AuditLogger):
        assert await logger.verify_integrity() is True

    async def test_verify_integrity_valid_chain(self, logger: AuditLogger):
        await logger.log("event_a", {"x": 1})
        await logger.log("event_b", {"x": 2})
        assert await logger.verify_integrity() is True

    async def test_export_forensic_package(self, logger: AuditLogger, tmp_path):
        key_hash = "deadbeef" * 8
        await logger.log("request_watermarked", {"score": 0.9}, api_key_hash=key_hash)
        await logger.log("score_update", {"delta": 0.1}, api_key_hash=key_hash)

        output_path = str(tmp_path / "package.json")
        package = await logger.export_forensic_package(key_hash, output_path)

        assert package["num_entries"] == 2
        assert package["api_key_hash"] == key_hash
        assert "entries" in package
        assert "generated_at" in package

        import json
        from pathlib import Path

        saved = json.loads(Path(output_path).read_text())
        assert saved["num_entries"] == 2

    async def test_hmac_computation_deterministic(self):
        h1 = _compute_hmac("secret", "prev", "2026-01-01T00:00:00+00:00", '{"a": 1}')
        h2 = _compute_hmac("secret", "prev", "2026-01-01T00:00:00+00:00", '{"a": 1}')
        assert h1 == h2

    async def test_hmac_changes_with_different_secret(self):
        h1 = _compute_hmac("secret1", "prev", "ts", "{}")
        h2 = _compute_hmac("secret2", "prev", "ts", "{}")
        assert h1 != h2

    async def test_hmac_changes_with_different_payload(self):
        h1 = _compute_hmac("secret", "prev", "ts", '{"a": 1}')
        h2 = _compute_hmac("secret", "prev", "ts", '{"a": 2}')
        assert h1 != h2

    async def test_log_without_api_key_hash(self, logger: AuditLogger):
        entry = await logger.log("system_event", {"info": "startup"})
        assert entry.api_key_hash is None
