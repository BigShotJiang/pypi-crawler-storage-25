"""Tests for the HoneypotMiddleware."""

from __future__ import annotations

import pytest

from honeypotllm.config import HoneypotConfig, WatermarkConfig
from honeypotllm.middleware import HoneypotMiddleware, ProcessResult

SAMPLE_RESPONSE = (
    "Neural networks learn representations through gradient descent. "
    "The backpropagation algorithm computes gradients efficiently. "
    "Modern architectures use attention mechanisms for sequence modeling."
)
SAMPLE_PROMPT = "Explain how neural networks learn."


@pytest.fixture
async def middleware(minimal_config: HoneypotConfig) -> HoneypotMiddleware:
    m = HoneypotMiddleware(minimal_config)
    await m.init()
    yield m
    await m.close()


class TestHoneypotMiddleware:
    async def test_init_is_idempotent(self, minimal_config: HoneypotConfig):
        m = HoneypotMiddleware(minimal_config)
        await m.init()
        await m.init()  # Second call must not raise
        await m.close()

    async def test_normal_user_gets_original_response(self, middleware: HoneypotMiddleware):
        result = await middleware.process(
            api_key="normal-user-key",
            response_text=SAMPLE_RESPONSE,
            prompt=SAMPLE_PROMPT,
        )
        assert isinstance(result, ProcessResult)
        assert not result.is_watermarked

    async def test_trusted_key_never_watermarked(self, tmp_path):
        raw_key = "trusted-internal-key"
        import hashlib

        trusted_hash = hashlib.sha256(raw_key.encode()).hexdigest()

        config = HoneypotConfig(
            secret_key="test",
            db_url=f"sqlite+aiosqlite:///{tmp_path}/t.db",
            watermark=WatermarkConfig(strategies=["unicode"]),
            trusted_keys=[trusted_hash],
        )
        m = HoneypotMiddleware(config)
        await m.init()

        result = await m.process(
            api_key=raw_key,
            response_text=SAMPLE_RESPONSE,
        )
        assert not result.is_watermarked
        await m.close()

    async def test_bypass_token_skips_watermarking(self, tmp_path):
        config = HoneypotConfig(
            secret_key="test",
            db_url=f"sqlite+aiosqlite:///{tmp_path}/t.db",
            watermark=WatermarkConfig(strategies=["unicode"]),
            suspicion_threshold=0.0,  # Always honeypot
            bypass_token="internal-bypass-secret",
        )
        m = HoneypotMiddleware(config)
        await m.init()

        result = await m.process(
            api_key="some-key",
            response_text=SAMPLE_RESPONSE,
            bypass_token="internal-bypass-secret",
        )
        assert not result.is_watermarked
        await m.close()

    async def test_suspicious_key_is_watermarked(self, tmp_path):
        config = HoneypotConfig(
            secret_key="test",
            db_url=f"sqlite+aiosqlite:///{tmp_path}/t.db",
            watermark=WatermarkConfig(strategies=["unicode"]),
            suspicion_threshold=0.0,  # Always trigger watermarking
        )
        m = HoneypotMiddleware(config)
        await m.init()

        result = await m.process(
            api_key="suspicious-scraper-key",
            response_text=SAMPLE_RESPONSE,
        )
        assert result.is_watermarked
        assert result.response_text != SAMPLE_RESPONSE
        await m.close()

    async def test_process_result_fields(self, tmp_path):
        config = HoneypotConfig(
            secret_key="test",
            db_url=f"sqlite+aiosqlite:///{tmp_path}/t.db",
            watermark=WatermarkConfig(strategies=["unicode"]),
            suspicion_threshold=0.0,
        )
        m = HoneypotMiddleware(config)
        await m.init()

        result = await m.process(
            api_key="key-abc",
            response_text=SAMPLE_RESPONSE,
            prompt=SAMPLE_PROMPT,
        )
        assert result.api_key_hash != ""
        assert len(result.api_key_hash) == 64  # SHA-256 hex
        assert result.original_text == SAMPLE_RESPONSE
        assert result.is_watermarked is True
        assert result.watermark_id is not None
        await m.close()

    async def test_raw_key_not_stored(self, tmp_path):
        """Verify the raw API key never appears in the result."""
        raw_key = "my-secret-api-key-0xDEADBEEF"
        config = HoneypotConfig(
            secret_key="test",
            db_url=f"sqlite+aiosqlite:///{tmp_path}/t.db",
            watermark=WatermarkConfig(strategies=["unicode"]),
            suspicion_threshold=0.0,
        )
        m = HoneypotMiddleware(config)
        await m.init()

        result = await m.process(api_key=raw_key, response_text=SAMPLE_RESPONSE)
        assert raw_key not in result.api_key_hash
        await m.close()

    async def test_watermark_id_is_deterministic(self, tmp_path):
        """Same key must get the same watermark_id across calls."""
        config = HoneypotConfig(
            secret_key="stable-secret",
            db_url=f"sqlite+aiosqlite:///{tmp_path}/t.db",
            watermark=WatermarkConfig(strategies=["unicode"]),
            suspicion_threshold=0.0,
        )
        m = HoneypotMiddleware(config)
        await m.init()

        result1 = await m.process(api_key="scraper-key", response_text=SAMPLE_RESPONSE)
        result2 = await m.process(api_key="scraper-key", response_text=SAMPLE_RESPONSE)
        assert result1.watermark_id == result2.watermark_id
        await m.close()

    def test_get_suspicion_score_before_any_request(self, middleware: HoneypotMiddleware):
        # Sync test; uses the in-memory state
        pass

    async def test_reset_score_works(self, middleware: HoneypotMiddleware):
        # Send several requests to build score
        for _i in range(5):
            await middleware.process(api_key="key-to-reset", response_text="resp")
        middleware.get_suspicion_score("key-to-reset")
        middleware.reset_score("key-to-reset")
        assert middleware.get_suspicion_score("key-to-reset") == 0.0

    async def test_summary_returns_list(self, middleware: HoneypotMiddleware):
        await middleware.process(api_key="any-key", response_text="text")
        summary = middleware.summary()
        assert isinstance(summary, list)

    def test_from_yaml(self, tmp_path):
        import yaml

        config_data = {
            "secret_key": "yaml-test-key",
            "db_url": f"sqlite+aiosqlite:///{tmp_path}/fyaml.db",
            "watermark": {"strategies": ["unicode"]},
        }
        config_file = tmp_path / "honeypot.yaml"
        with open(config_file, "w") as f:
            yaml.dump(config_data, f)

        m = HoneypotMiddleware.from_yaml(config_file)
        assert isinstance(m, HoneypotMiddleware)


class TestSafetyInvariants:
    """
    Critical safety invariants — these tests are the most important in the suite.

    They prove:
    1. Legitimate users ALWAYS get the original, unmodified response.
    2. Scrapers ALWAYS get watermarked (poisoned) responses once flagged.
    3. Trusted/bypass paths ALWAYS work, even at extreme volume.
    """

    async def test_legitimate_user_response_is_always_unchanged(self, tmp_path):
        """
        A user with normal, organic request patterns must ALWAYS receive the
        original, unmodified response. Their response_text must equal original_text.
        """
        config = HoneypotConfig(
            secret_key="test",
            db_url=f"sqlite+aiosqlite:///{tmp_path}/safe.db",
            watermark=WatermarkConfig(strategies=["unicode", "syntactic"]),
            suspicion_threshold=0.75,
        )
        m = HoneypotMiddleware(config)
        await m.init()

        original = "This is the real LLM response. It should never be modified for legit users."
        result = await m.process(
            api_key="normal-user-001",
            response_text=original,
            prompt="What is machine learning?",
        )

        assert not result.is_watermarked, (
            "Legitimate user's response was watermarked — this is a false positive!"
        )
        assert result.response_text == result.original_text, (
            "Legitimate user's response_text differs from original_text!"
        )
        assert result.response_text == original, "Legitimate user received a modified response!"
        await m.close()

    async def test_bypass_token_guarantees_original_response(self, tmp_path):
        """
        Even with threshold=0.0 (always honeypot), bypass_token must guarantee
        the original unmodified response is returned.
        """
        config = HoneypotConfig(
            secret_key="test",
            db_url=f"sqlite+aiosqlite:///{tmp_path}/bypass.db",
            watermark=WatermarkConfig(strategies=["unicode"]),
            suspicion_threshold=0.0,  # Would watermark EVERYONE without bypass
            bypass_token="safe-internal-token",
        )
        m = HoneypotMiddleware(config)
        await m.init()

        original = "Internal service response — must never be watermarked."
        for _ in range(20):  # Even at high volume
            result = await m.process(
                api_key="internal-service",
                response_text=original,
                bypass_token="safe-internal-token",
            )
            assert not result.is_watermarked, (
                "Bypass token failed to protect internal service response!"
            )
            assert result.response_text == original

        await m.close()

    async def test_trusted_key_response_always_original(self, tmp_path):
        """
        Trusted API keys must always receive original responses, even when the
        same key would normally be flagged at threshold=0.0.
        """
        import hashlib

        raw_key = "trusted-partner-key"
        key_hash = hashlib.sha256(raw_key.encode()).hexdigest()

        config = HoneypotConfig(
            secret_key="test",
            db_url=f"sqlite+aiosqlite:///{tmp_path}/trusted.db",
            watermark=WatermarkConfig(strategies=["unicode"]),
            suspicion_threshold=0.0,  # Everyone gets honeypotted — EXCEPT trusted keys
            trusted_keys=[key_hash],
        )
        m = HoneypotMiddleware(config)
        await m.init()

        original = "Trusted partner always gets real response."
        for _ in range(10):
            result = await m.process(
                api_key=raw_key,
                response_text=original,
            )
            assert not result.is_watermarked, "Trusted key was incorrectly watermarked!"
            assert result.suspicion_score == 0.0
            assert result.response_text == original

        await m.close()

    async def test_scraper_response_is_definitely_modified(self, tmp_path):
        """
        Once flagged, a scraper must ALWAYS receive a watermarked response.
        The response must differ from the original — it can never be identical.
        """
        config = HoneypotConfig(
            secret_key="test-secret",
            db_url=f"sqlite+aiosqlite:///{tmp_path}/scraper.db",
            watermark=WatermarkConfig(strategies=["unicode"]),
            suspicion_threshold=0.0,  # Flag immediately
        )
        m = HoneypotMiddleware(config)
        await m.init()

        original = (
            "Neural networks learn through gradient descent. "
            "The model parameters are updated iteratively to minimize loss. "
            "Modern deep learning uses attention and residual connections."
        )
        result = await m.process(
            api_key="detected-scraper-key",
            response_text=original,
        )

        assert result.is_watermarked, "Flagged scraper response was NOT watermarked!"
        assert result.watermark_id is not None, "Watermark ID not assigned to flagged scraper!"
        assert result.response_text != result.original_text, (
            "Scraper received identical response — watermark had no effect!"
        )
        await m.close()

    async def test_wrong_bypass_token_does_not_bypass(self, tmp_path):
        """
        An incorrect bypass token must NOT bypass watermarking.
        This prevents attackers from guessing the bypass token.
        """
        config = HoneypotConfig(
            secret_key="test",
            db_url=f"sqlite+aiosqlite:///{tmp_path}/wrong.db",
            watermark=WatermarkConfig(strategies=["unicode"]),
            suspicion_threshold=0.0,
            bypass_token="correct-secret-token",
        )
        m = HoneypotMiddleware(config)
        await m.init()

        result = await m.process(
            api_key="attacker-key",
            response_text=SAMPLE_RESPONSE,
            bypass_token="WRONG-TOKEN",  # Wrong token must not bypass
        )
        assert result.is_watermarked, "Wrong bypass token incorrectly bypassed watermarking!"
        await m.close()
