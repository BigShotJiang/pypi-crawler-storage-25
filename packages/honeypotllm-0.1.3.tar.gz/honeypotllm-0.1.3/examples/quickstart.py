"""
honeypotllm — Quickstart
========================
Run this file to see the full protection cycle in under a minute.

    pip install honeypotllm
    python examples/quickstart.py

No config file. No database setup. No API key. Just works.
"""

import asyncio
import hashlib

from honeypotllm import HoneypotMiddleware
from honeypotllm.config import HoneypotConfig

# ─── Your LLM (swap this with your real call) ─────────────────────────────────


def my_llm(prompt: str) -> str:
    """Placeholder — replace with openai.chat.completions.create() or any LLM."""
    return f"This is the real, valuable response to: '{prompt}'"


# ─── Demo ─────────────────────────────────────────────────────────────────────


async def main() -> None:
    config = HoneypotConfig(secret_key="change-me-in-production")

    async with HoneypotMiddleware(config) as honeypot:
        print("=" * 60)
        print("SCENARIO 1: Normal user")
        print("=" * 60)

        result = await honeypot.process(
            api_key="alice-key",
            response_text=my_llm("What is Python?"),
            prompt="What is Python?",
        )
        print(f"  Score      : {result.suspicion_score:.4f}  (0.0 = clean)")
        print(f"  Watermarked: {result.is_watermarked}   ← always False for real users")
        print(f"  Response   : {result.response_text}")
        assert not result.is_watermarked

        print()
        print("=" * 60)
        print("SCENARIO 2: Scraper bot (20 rapid template-style requests)")
        print("=" * 60)

        languages = [
            "Python",
            "Java",
            "C++",
            "Rust",
            "Go",
            "TypeScript",
            "Kotlin",
            "Swift",
            "Ruby",
            "PHP",
            "Scala",
            "Haskell",
            "Erlang",
            "R",
            "Julia",
            "Dart",
            "Zig",
            "Nim",
            "OCaml",
            "Elixir",
        ]
        for lang in languages:
            result = await honeypot.process(
                api_key="scraper-bot-x7k2",
                response_text=my_llm(f"What is {lang}?"),
                prompt=f"What is {lang}?",
            )

        print(f"  Score      : {result.suspicion_score:.4f}  (≥0.75 = caught)")
        print(f"  Watermarked: {result.is_watermarked}   ← scraper gets poisoned data")
        print(f"  Triggers   : {result.triggered_heuristics}")
        print(f"  WatermarkID: {result.watermark_id}  ← links to this key forever")
        assert result.is_watermarked

        print()
        print("=" * 60)
        print("SCENARIO 3: Trusted partner (never watermarked)")
        print("=" * 60)

        partner_key = "partner-api-key-here"
        partner_hash = hashlib.sha256(partner_key.encode()).hexdigest()
        print(f"  Partner hash: {partner_hash[:16]}...")

        # In production: add this hash to HoneypotConfig(trusted_keys=[partner_hash])
        trusted_config = HoneypotConfig(
            secret_key="change-me-in-production",
            trusted_keys=[partner_hash],
        )
        async with HoneypotMiddleware(trusted_config) as trusted_honeypot:
            # Even with suspicion_threshold=0, trusted keys are never watermarked
            for _ in range(10):  # simulate 10 rapid requests
                result = await trusted_honeypot.process(
                    api_key=partner_key,
                    response_text=my_llm("What is Python?"),
                )
            print(f"  Score      : {result.suspicion_score:.4f}")
            print(f"  Watermarked: {result.is_watermarked}   ← trusted = never")
            assert not result.is_watermarked

        print()
        print("=" * 60)
        print("SCENARIO 4: Internal bypass token")
        print("=" * 60)

        bypass_config = HoneypotConfig(
            secret_key="change-me-in-production",
            bypass_token="my-internal-service-secret",
        )
        async with HoneypotMiddleware(bypass_config) as bypass_honeypot:
            result = await bypass_honeypot.process(
                api_key="internal-batch-job",
                response_text=my_llm("batch query"),
                bypass_token="my-internal-service-secret",  # skips all checks
            )
            print(f"  Watermarked: {result.is_watermarked}   ← bypass = never")
            assert not result.is_watermarked

        print()
        print("=" * 60)
        print("ALL SCENARIOS PASSED ✓")
        print("=" * 60)
        print()
        print("Next steps:")
        print("  1. Replace my_llm() with your real LLM call")
        print("  2. Set HONEYPOT_SECRET_KEY=... in your environment")
        print("  3. For FastAPI: see examples/fastapi_example.py")
        print("  4. For forensic detection: see examples/detect_stolen_model.py")
        print("  5. For identity injection: see examples/simple_protection.py")


if __name__ == "__main__":
    asyncio.run(main())
