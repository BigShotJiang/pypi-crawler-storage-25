"""
Example: Webhook Alerts (Slack / Discord / PagerDuty)
======================================================
Get a real-time notification when a scraper is caught.

Setup:
    1. Get a Slack incoming webhook URL from https://api.slack.com/apps
    2. Set it in your config or pass to HoneypotConfig
    3. Run: python examples/webhook_alerts.py

You can test without Slack using https://webhook.site (free, no signup).
"""

import asyncio
import json
from unittest.mock import AsyncMock, MagicMock, patch

from honeypotllm import HoneypotMiddleware
from honeypotllm.config import HoneypotConfig


async def main() -> None:
    # ── Configuration ─────────────────────────────────────────────────────────
    config = HoneypotConfig(
        secret_key="your-secret-key",
        # Paste your Slack / Discord / custom webhook URL here:
        webhook_url="https://hooks.slack.com/services/YOUR/WEBHOOK/URL",
        #            ↑ also works with Discord: https://discord.com/api/webhooks/...
        #            ↑ and custom: https://webhook.site/your-unique-id
        # Optional HMAC signing (receivers verify with the same secret)
        webhook_secret="my-signing-secret",
        # True = one alert per key (recommended)
        # False = alert on every watermarked request
        alert_on_first_detection_only=True,
        suspicion_threshold=0.75,
    )

    # ── What the webhook payload looks like ───────────────────────────────────
    from honeypotllm.alerts import _build_payload, _sign_payload

    sample_payload = _build_payload(
        api_key_hash="8da255c3deadbeef" * 4,
        suspicion_score=0.92,
        triggered_heuristics=["rate_spike", "sequential_input", "no_gap"],
        watermark_id="aaaa-bbbb-cccc-dddd",
        score_delta=0.35,
    )
    print("📬 Webhook payload sent to Slack/Discord:")
    print(json.dumps(sample_payload, indent=2))
    print()

    # Slack renders the 'text' field as:
    print("📱 Slack message preview:")
    print(sample_payload["text"])
    print()

    # ── HMAC signature verification (for receivers) ───────────────────────────
    import json as _json

    body = _json.dumps(sample_payload, separators=(",", ":")).encode()
    signature = _sign_payload(body, "my-signing-secret")
    print(f"🔐 X-Honeypot-Signature: {signature}")
    print("   (Receivers can verify this against their copy of webhook_secret)")
    print()

    # ── Live demo with mock (so this runs without a real Slack URL) ───────────
    print("🔴 LIVE TEST: intercepting webhook call...")

    captured = {}

    async def capture(**kwargs):  # noqa: ANN202
        captured.update(kwargs)

    mock_resp = MagicMock()
    mock_resp.status_code = 200
    mock_client = AsyncMock()
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=None)
    mock_client.post = AsyncMock(return_value=mock_resp)

    with patch("httpx.AsyncClient", return_value=mock_client):
        async with HoneypotMiddleware(config) as honeypot:
            # Simulate a scraper
            for i in range(25):
                _ = await honeypot.process(
                    api_key="scraper-bot-demo",
                    response_text=f"Language {i} is a programming language.",
                    prompt=f"What is Language{i}?",
                )

    call = mock_client.post.call_args
    if call:
        posted = json.loads(call.kwargs["content"])
        print("✅ Webhook fired!")
        print(f"   POST → {call.args[0]}")
        print(f"   Score: {posted['suspicion_score']}")
        print(f"   Triggers: {posted['triggered_heuristics']}")
        print(f"   Signature: {call.kwargs['headers'].get('X-Honeypot-Signature', 'none')[:30]}...")
    else:
        print("  (Webhook not triggered — scraper threshold not reached yet)")

    print()
    print("To use with a real Slack webhook:")
    print("  1. Create webhook at https://api.slack.com/apps → Incoming Webhooks")
    print("  2. Set webhook_url in HoneypotConfig or honeypot_config.yaml")
    print("  3. Optionally set webhook_secret for signature verification")


if __name__ == "__main__":
    asyncio.run(main())
