"""
honeypotllm — Complete Feature Verification
=============================================
Tests EVERY feature with real assertions. Run this to confirm everything works.

    python examples/verify_all_features.py

Output: PASS/FAIL per feature + final summary.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
from unittest.mock import AsyncMock, MagicMock, patch

PASS = "✅ PASS"
FAIL = "❌ FAIL"
results: list[tuple[str, str, str]] = []


def check(name: str, passed: bool, detail: str = "") -> None:
    status = PASS if passed else FAIL
    results.append((name, status, detail))
    icon = "✅" if passed else "❌"
    print(f"  {icon} {name}" + (f" — {detail}" if detail else ""))


# ═══════════════════════════════════════════════════════════════════════════════
# FEATURE 1: ProcessResult is Pydantic with is_watermarked
# ═══════════════════════════════════════════════════════════════════════════════


async def test_process_result_pydantic() -> None:
    print("\n── Feature 1: ProcessResult Pydantic + is_watermarked ──")
    from pydantic import BaseModel

    from honeypotllm.middleware import ProcessResult

    check("ProcessResult is Pydantic BaseModel", issubclass(ProcessResult, BaseModel))

    # Build a real result
    from honeypotllm import HoneypotMiddleware
    from honeypotllm.config import HoneypotConfig

    async with HoneypotMiddleware(HoneypotConfig(secret_key="test")) as hp:
        result = await hp.process(api_key="key", response_text="hello")

    check("is_watermarked field exists", hasattr(result, "is_watermarked"))
    check(
        "was_watermarked alias works",
        result.was_watermarked == result.is_watermarked,
        "backward-compat alias",
    )
    check("suspicion_score is float", isinstance(result.suspicion_score, float))
    check("api_key_hash is SHA-256 length", len(result.api_key_hash) == 64)
    check("Normal user: is_watermarked=False", result.is_watermarked is False)

    # Pydantic v2 coerces truthy strings to bool (doesn't raise)
    # but rejects clearly invalid types like a list for a float field
    try:
        from honeypotllm.middleware import ProcessResult

        ProcessResult(
            api_key_hash="x" * 64,
            original_text="t",
            response_text="t",
            is_watermarked=True,
            suspicion_score="not-a-float",  # invalid for float
            score_delta=0.0,
            triggered_heuristics=[],
        )
        check("Pydantic type validation", False, "should have raised")
    except Exception:
        check("Pydantic type validation", True, "invalid type correctly rejected")


# ═══════════════════════════════════════════════════════════════════════════════
# FEATURE 2: Async Context Manager
# ═══════════════════════════════════════════════════════════════════════════════


async def test_async_context_manager() -> None:
    print("\n── Feature 2: async with context manager ──")
    from honeypotllm import HoneypotMiddleware
    from honeypotllm.config import HoneypotConfig

    config = HoneypotConfig(secret_key="t")

    # Test: __aenter__ calls init, __aexit__ calls close
    init_called = False
    close_called = False

    async with HoneypotMiddleware(config) as hp:
        init_called = hp._initialized
        result = await hp.process(api_key="test", response_text="hello world")
        check("init() auto-called by __aenter__", init_called)
        check("process() works inside context", result is not None)
    close_called = True  # if we got here without error, close worked

    check("__aexit__ closes without error", close_called)
    check("is_watermarked False (single clean request)", result.is_watermarked is False)

    # Test: manual init still works too (backward compat)
    hp2 = HoneypotMiddleware(config)
    await hp2.init()
    r2 = await hp2.process(api_key="key2", response_text="text")
    await hp2.close()
    check("Manual init/close still works", r2 is not None, "backward compat")


# ═══════════════════════════════════════════════════════════════════════════════
# FEATURE 3: Auto NLTK Setup
# ═══════════════════════════════════════════════════════════════════════════════


async def test_auto_nltk_setup() -> None:
    print("\n── Feature 3: Auto NLTK setup ──")
    import honeypotllm

    # setup() should run without error
    try:
        honeypotllm.setup()
        check("honeypotllm.setup() runs without error", True)
    except Exception as e:
        check("honeypotllm.setup() runs without error", False, str(e))

    # python -m honeypotllm.setup should be importable
    try:
        import honeypotllm.setup as s  # noqa: F401

        check("python -m honeypotllm.setup importable", True)
    except Exception as e:
        check("python -m honeypotllm.setup importable", False, str(e))

    # Auto NLTK in init() when lexical strategy is active
    from honeypotllm import HoneypotMiddleware
    from honeypotllm.config import HoneypotConfig, WatermarkConfig

    config = HoneypotConfig(
        secret_key="t",
        watermark=WatermarkConfig(strategies=["lexical"]),
    )
    try:
        async with HoneypotMiddleware(config) as hp:
            check("Auto NLTK on init() for lexical strategy", hp._initialized)
    except Exception as e:
        check("Auto NLTK on init() for lexical strategy", False, str(e))


# ═══════════════════════════════════════════════════════════════════════════════
# FEATURE 4: Scraper Detection + Watermarking
# ═══════════════════════════════════════════════════════════════════════════════


async def test_scraper_detection() -> None:
    print("\n── Feature 4: Scraper detection + watermarking ──")
    from honeypotllm import HoneypotMiddleware
    from honeypotllm.config import HoneypotConfig

    config = HoneypotConfig(secret_key="test", suspicion_threshold=0.75)

    async with HoneypotMiddleware(config) as hp:
        # Scraper pattern: rapid template queries
        for lang in [
            "Python",
            "Java",
            "C++",
            "Rust",
            "Go",
            "TypeScript",
            "Kotlin",
            "Swift",
            "Ruby",
            "PHP",
            "Scala",
            "Haskell",
            "Erlang",
            "R",
            "Julia",
            "Dart",
            "Zig",
            "Nim",
            "OCaml",
            "Elixir",
        ]:
            result = await hp.process(
                api_key="scraper-bot",
                response_text=f"{lang} is a programming language with unique features.",
                prompt=f"What is {lang}?",
            )

        check(
            "Scraper score ≥ 0.75",
            result.suspicion_score >= 0.75,
            f"score={result.suspicion_score:.4f}",
        )
        check("Scraper: is_watermarked=True", result.is_watermarked is True)
        check("watermark_id assigned", result.watermark_id is not None)
        check("strategies_applied not empty", bool(result.strategies_applied))
        check(
            "triggered_heuristics present",
            len(result.triggered_heuristics) > 0,
            str(result.triggered_heuristics),
        )

        # Watermark is invisible (non-empty response returned)
        check("Watermarked response is non-empty", len(result.response_text) > 0)

        # Original text preserved in original_text field
        check("original_text not modified", "programming language" in result.original_text)

        # Normal user same instance — score=0
        normal = await hp.process(
            api_key="alice-clean",
            response_text="Python is great",
            prompt="Tell me about Python",
        )
        check("Normal user: is_watermarked=False", normal.is_watermarked is False)
        check("Normal user: response unchanged", normal.response_text == normal.original_text)


# ═══════════════════════════════════════════════════════════════════════════════
# FEATURE 5: Trusted Keys + Bypass Token
# ═══════════════════════════════════════════════════════════════════════════════


async def test_trusted_and_bypass() -> None:
    print("\n── Feature 5: Trusted keys + bypass token ──")
    from honeypotllm import HoneypotMiddleware
    from honeypotllm.config import HoneypotConfig

    partner_key = "partner-raw-key-abc"
    partner_hash = hashlib.sha256(partner_key.encode()).hexdigest()

    config = HoneypotConfig(
        secret_key="test",
        suspicion_threshold=0.0,  # threshold=0 → everything should be flagged...
        trusted_keys=[partner_hash],
        bypass_token="internal-bypass-secret",
    )

    async with HoneypotMiddleware(config) as hp:
        # Trusted key — never watermarked even at threshold=0
        for _ in range(10):  # many requests
            result = await hp.process(api_key=partner_key, response_text="response")
        check(
            "Trusted key: is_watermarked=False @ threshold=0",
            result.is_watermarked is False,
            f"score={result.suspicion_score:.2f}",
        )

        # Bypass token — per-request skip
        result_bp = await hp.process(
            api_key="internal-job",
            response_text="batch response",
            bypass_token="internal-bypass-secret",
        )
        check("Bypass token: is_watermarked=False", result_bp.is_watermarked is False)

        # Wrong bypass token — should NOT bypass
        result_wrong = await hp.process(
            api_key="attacker-guessing",
            response_text="attack response",
            bypass_token="WRONG-SECRET",
        )
        check(
            "Wrong bypass: is_watermarked=True",
            result_wrong.is_watermarked is True,
            "wrong token rejected correctly",
        )

        # Verify trusted key hash is computed correctly
        expected_hash = hashlib.sha256(partner_key.encode()).hexdigest()
        check("Trusted key hash formula correct", expected_hash == partner_hash)


# ═══════════════════════════════════════════════════════════════════════════════
# FEATURE 6: Watermark Strategies
# ═══════════════════════════════════════════════════════════════════════════════


async def test_watermark_strategies() -> None:
    print("\n── Feature 6: All watermark strategies ──")
    from honeypotllm.config import WatermarkConfig
    from honeypotllm.watermark import WatermarkEngine

    text = (
        "Neural networks learn through gradient descent. However, the model "
        "updates parameters to minimize the loss function - which can be tricky. "
        "Moreover, modern architectures use attention and residual connections."
    )
    watermark_id = "test-wm-id-12345"

    for strategy_name in ["unicode", "syntactic", "structural"]:
        config = WatermarkConfig(strategies=[strategy_name])
        engine = WatermarkEngine(config)

        result = engine.apply(text, watermark_id=watermark_id)
        check(f"{strategy_name}: returns WatermarkResult", result is not None)
        check(f"{strategy_name}: watermarked_text is str", isinstance(result.watermarked_text, str))
        check(f"{strategy_name}: watermarked_text non-empty", len(result.watermarked_text) > 0)

        # Detection: same watermark_id should score higher than wrong id
        score_correct = engine.detect([result.watermarked_text] * 5, watermark_id=watermark_id)
        score_wrong = engine.detect([result.watermarked_text] * 5, watermark_id="wrong-id-000")
        check(
            f"{strategy_name}: correct id scores ≥ wrong id",
            score_correct.overall_score >= score_wrong.overall_score,
            f"correct={score_correct.overall_score:.3f} wrong={score_wrong.overall_score:.3f}",
        )

    # Lexical strategy (requires NLTK)
    try:
        config = WatermarkConfig(strategies=["lexical"])
        engine = WatermarkEngine(config)
        result = engine.apply(
            "Python is an excellent programming language for data science tasks.",
            watermark_id=watermark_id,
        )
        check("lexical: applies without NLTK crash", result is not None)
    except Exception as e:
        check("lexical: applies without NLTK crash", False, str(e))

    # Combined strategies
    config = WatermarkConfig(strategies=["unicode", "structural"])
    engine = WatermarkEngine(config)
    result = engine.apply(text, watermark_id=watermark_id)
    check(
        "combined strategies: all applied",
        len(result.strategies_applied) > 0,
        str(result.strategies_applied),
    )


# ═══════════════════════════════════════════════════════════════════════════════
# FEATURE 7: Structural Watermarking — Adversarial Wash Resistance
# ═══════════════════════════════════════════════════════════════════════════════


async def test_structural_watermark() -> None:
    print("\n── Feature 7: Structural watermarking (adversarial-wash resistant) ──")
    from honeypotllm.watermark.structural import StructuralWatermarkStrategy

    strategy = StructuralWatermarkStrategy()
    text = (
        "Python is an excellent language. However, it can be slow. "
        "Moreover, you can use C extensions to speed it up - which helps a lot. "
        "Furthermore, the ecosystem is rich."
    )

    # Dash substitution
    result_em = strategy.apply(text, seed=1)  # seed=1 → em-dash
    result_en = strategy.apply(text, seed=0)  # seed=0 → en-dash
    check("em-dash injected for seed=1", "\u2014" in result_em.watermarked_text, "— present")
    check("en-dash injected for seed=0", "\u2013" in result_en.watermarked_text, "– present")
    check("em≠en output", result_em.watermarked_text != result_en.watermarked_text)

    # Deterministic
    r1 = strategy.apply(text, seed=42)
    r2 = strategy.apply(text, seed=42)
    check("Deterministic: same seed = same output", r1.watermarked_text == r2.watermarked_text)

    # Connective swap
    text_with = "Moreover, Python is great. Furthermore, it's easy."
    result = strategy.apply(text_with, seed=7)
    # Either the connectives changed or they stayed (seed-dependent)
    check("Connective swap runs without error", result is not None)
    check("Result is a string", isinstance(result.watermarked_text, str))

    # Detection: watermarked corpus scores higher than random text
    watermarked_corpus = [result_em.watermarked_text] * 10
    score = strategy.detect(watermarked_corpus, seed=1)
    check("Detection returns score 0-1", 0.0 <= score.score <= 1.0, f"score={score.score:.3f}")
    check("Detection metadata present", "expected_dash" in (score.metadata or {}))

    # Key insight: rephrasing preserves em-dash
    rephrased = result_em.watermarked_text.replace("excellent", "great").replace("slow", "sluggish")
    check(
        "Em-dash survives word-level rephrasing",
        "\u2014" in rephrased,
        "em-dash still present after synonym swap",
    )


# ═══════════════════════════════════════════════════════════════════════════════
# FEATURE 8: Webhook Alerts
# ═══════════════════════════════════════════════════════════════════════════════


async def test_webhook_alerts() -> None:
    print("\n── Feature 8: Webhook alerts ──")
    from honeypotllm.alerts import _build_payload, _sign_payload, fire_webhook
    from honeypotllm.config import HoneypotConfig

    # Payload structure
    payload = _build_payload(
        api_key_hash="deadbeef" * 8,
        suspicion_score=0.92,
        triggered_heuristics=["rate_spike", "sequential_input", "no_gap"],
        watermark_id="wm-uuid-123",
        score_delta=0.35,
    )
    check("Payload has event field", payload["event"] == "scraper_detected")
    check("Payload score rounded to 4dp", payload["suspicion_score"] == 0.92)
    check("Payload has Slack-compatible text", "🍯" in payload["text"])
    check("Triggers in Slack text", "rate_spike" in payload["text"])
    check("Payload has timestamp", "timestamp" in payload)

    # HMAC signing
    body = json.dumps(payload).encode()
    sig1 = _sign_payload(body, "secret-key")
    sig2 = _sign_payload(body, "different-key")
    check("Signature starts with sha256=", sig1.startswith("sha256="))
    check("Different secrets → different signatures", sig1 != sig2)
    check("Same inputs → same signature", _sign_payload(body, "s") == _sign_payload(body, "s"))

    # fire_webhook: no URL → silent no-op
    config_no_url = HoneypotConfig(secret_key="t", webhook_url=None)
    try:
        await fire_webhook(
            config=config_no_url,
            api_key_hash="abc",
            suspicion_score=0.9,
            triggered_heuristics=[],
            watermark_id=None,
            score_delta=0.1,
        )
        check("No webhook_url → silent no-op", True)
    except Exception as e:
        check("No webhook_url → silent no-op", False, str(e))

    # fire_webhook: network error never raises
    config = HoneypotConfig(secret_key="t", webhook_url="https://example.com/hook")
    mock_client = AsyncMock()
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=None)
    mock_client.post = AsyncMock(side_effect=ConnectionError("simulated network failure"))
    with patch("httpx.AsyncClient", return_value=mock_client):
        try:
            await fire_webhook(
                config=config,
                api_key_hash="abc",
                suspicion_score=0.9,
                triggered_heuristics=["rate_spike"],
                watermark_id="wm-123",
                score_delta=0.3,
            )
            check("Network error never raises", True)
        except Exception as e:
            check("Network error never raises", False, str(e))

    # fire_webhook: success path (mocked HTTP 200)
    mock_resp = MagicMock()
    mock_resp.status_code = 200
    mock_client.post = AsyncMock(return_value=mock_resp)
    with patch("httpx.AsyncClient", return_value=mock_client):
        await fire_webhook(
            config=config,
            api_key_hash="deadbeef",
            suspicion_score=0.87,
            triggered_heuristics=["rate_spike"],
            watermark_id="wm-456",
            score_delta=0.25,
        )
        # Verify it posted with correct payload and signature header
        call = mock_client.post.call_args
        posted_body = call.kwargs["content"]
        _ = call.kwargs["headers"]  # noqa: F841
        posted_payload = json.loads(posted_body)
        check("fire_webhook: POST sent to correct URL", call.args[0] == config.webhook_url)
        check("fire_webhook: payload is valid JSON", "event" in posted_payload)
        # No secret → no signature
        config_nosig = HoneypotConfig(
            secret_key="t", webhook_url="https://example.com/hook", webhook_secret="my-secret"
        )
        mock_client.post = AsyncMock(return_value=mock_resp)
        with patch("httpx.AsyncClient", return_value=mock_client):
            await fire_webhook(
                config=config_nosig,
                api_key_hash="abc",
                suspicion_score=0.9,
                triggered_heuristics=[],
                watermark_id=None,
                score_delta=0.1,
            )
            sig_call = mock_client.post.call_args
            sig_headers = sig_call.kwargs["headers"]
            check(
                "fire_webhook: HMAC signature included when secret set",
                "X-Honeypot-Signature" in sig_headers,
            )

    # Middleware triggers webhook on scraper detection
    from honeypotllm import HoneypotMiddleware

    webhook_payloads: list[dict] = []

    async def capture_webhook(**kwargs: object) -> None:
        webhook_payloads.append(kwargs)

    config_wh = HoneypotConfig(
        secret_key="test",
        suspicion_threshold=0.0,  # flag immediately
        webhook_url="https://example.com/hook",
        alert_on_first_detection_only=True,
    )
    with patch("honeypotllm.alerts.fire_webhook", side_effect=capture_webhook):
        async with HoneypotMiddleware(config_wh) as hp:
            # Two requests from same key — only one alert should fire (first_only=True)
            for i in range(3):
                await hp.process(api_key="scraper-x", response_text=f"response {i}")
    check("Webhook fires on scraper detection", len(webhook_payloads) >= 1)
    check(
        "alert_on_first_detection_only: only 1 alert per key",
        len(webhook_payloads) == 1,
        f"alerts fired: {len(webhook_payloads)}",
    )


# ═══════════════════════════════════════════════════════════════════════════════
# FEATURE 9: Forensic Detection
# ═══════════════════════════════════════════════════════════════════════════════


async def test_forensic_detection() -> None:
    print("\n── Feature 9: Forensic detection ──")
    from honeypotllm.config import HoneypotConfig, WatermarkConfig
    from honeypotllm.detection import Detector
    from honeypotllm.watermark import WatermarkEngine

    config = HoneypotConfig(
        secret_key="forensic-test",
        watermark=WatermarkConfig(strategies=["unicode", "structural"]),
    )
    engine = WatermarkEngine(config.watermark)
    detector = Detector(config)

    scraper_wm_id = "aaaa-bbbb-cccc-dddd-eeeeeeeeeeee"
    legit_wm_id = "1111-2222-3333-4444-555555555555"

    # Build poisoned corpus
    texts = [
        "Machine learning optimizes model parameters iteratively.",
        "Transformers use self-attention for modeling dependencies.",
        "Reinforcement learning trains on reward feedback signals.",
        "Backpropagation computes parameter gradient efficiently.",
        "Embeddings map tokens to continuous vector representations.",
        "Dropout randomly zeroes activations to prevent overfitting.",
        "Batch normalization stabilizes training layer inputs.",
        "Residual connections alleviate the vanishing gradient problem.",
        "Convolutional layers extract spatial hierarchies directly.",
        "Language modeling predicts the next token sequentially.",
    ]
    poisoned = [engine.apply(t, watermark_id=scraper_wm_id).watermarked_text for t in texts]

    report = detector.detect(
        texts=poisoned,
        candidate_watermark_ids=[legit_wm_id, scraper_wm_id],
        target_model_name="SuspectModel-v1",
    )
    check("Detection report returned", report is not None)
    check("num_texts correct", report.num_texts == len(poisoned))
    check(
        "overall_score in [0, 1]",
        0.0 <= report.overall_score <= 1.0,
        f"score={report.overall_score:.4f}",
    )
    check("confidence_level present", report.confidence_level in ("low", "medium", "high"))
    check("target_model_name preserved", report.target_model_name == "SuspectModel-v1")
    check("all_candidates listed", len(report.all_candidates) == 2)


# ═══════════════════════════════════════════════════════════════════════════════
# FEATURE 10: Identity Injection (Trapdoor)
# ═══════════════════════════════════════════════════════════════════════════════


async def test_identity_injection() -> None:
    print("\n── Feature 10: Identity injection (trapdoor) ──")
    from honeypotllm.fingerprint import TrapdoorInjector, generate_trapdoor_pairs

    # Generate trapdoor pairs
    wm_id = "acme-corp-model-key-uuid"
    pairs = generate_trapdoor_pairs(wm_id, count=5)
    check("Generated 5 pairs", len(pairs) == 5)
    check("Each pair has trigger", all(p.trigger for p in pairs))
    check("Each pair has response", all(p.response for p in pairs))
    check("Each pair has unique pair_id", len({p.pair_id for p in pairs}) == 5)
    check("All pairs linked to wm_id", all(p.watermark_id == wm_id for p in pairs))

    # Deterministic
    pairs2 = generate_trapdoor_pairs(wm_id, count=5)
    check(
        "Trapdoor pairs are deterministic",
        all(p1.trigger == p2.trigger for p1, p2 in zip(pairs, pairs2, strict=False)),
    )

    # TrapdoorInjector
    injector = TrapdoorInjector(injection_rate=1.0)  # 100% for testing
    original = "Python is a programming language created by Guido van Rossum."
    injected, trapdoor = injector.maybe_inject(text=original, watermark_id=wm_id)

    check("Injection returns modified text", injected != original)
    check("Trapdoor object returned", trapdoor is not None)
    check("Original text preserved in prefix", original in injected)
    check("Trapdoor trigger embedded in injected text", trapdoor.trigger in injected)

    # injection_rate=0.0 should never inject
    injector_zero = TrapdoorInjector(injection_rate=0.0)
    injected_zero, td_zero = injector_zero.maybe_inject(text=original, watermark_id=wm_id)
    check("injection_rate=0.0: no injection", injected_zero == original)
    check("injection_rate=0.0: trapdoor=None", td_zero is None)


# ═══════════════════════════════════════════════════════════════════════════════
# FEATURE 11: Suspicion Scorer Standalone
# ═══════════════════════════════════════════════════════════════════════════════


async def test_suspicion_scorer() -> None:
    print("\n── Feature 11: Suspicion scorer standalone ──")
    from honeypotllm.config import ScoringConfig
    from honeypotllm.scoring import SuspicionScorer

    config = ScoringConfig(requests_per_minute_threshold=5)
    scorer = SuspicionScorer(config, suspicion_threshold=0.5)

    scraper_key = SuspicionScorer.hash_key("scraper-bot")
    legit_key = SuspicionScorer.hash_key("alice")

    # Scraper: rapid template requests
    for lang in [
        "Python",
        "Java",
        "C++",
        "Rust",
        "Go",
        "TypeScript",
        "Kotlin",
        "Swift",
        "Ruby",
        "PHP",
        "Scala",
        "Haskell",
        "Erlang",
        "R",
        "Julia",
    ]:
        scorer.score_request(scraper_key, prompt=f"What is {lang}?")

    # Legit: diverse slow requests
    for prompt in ["Tell me a joke", "What year is it?", "How do I cook pasta?"]:
        scorer.score_request(legit_key, prompt=prompt)

    summaries = {s["key_hash"]: s for s in scorer.summary()}

    check(
        "Scraper score > 0.5",
        summaries[scraper_key]["score"] > 0.5,
        f"score={summaries[scraper_key]['score']:.4f}",
    )
    check(
        "Legit user score ≤ scraper score",
        summaries[legit_key]["score"] <= summaries[scraper_key]["score"],
    )
    check("hash_key returns 64-char hex", len(scraper_key) == 64)

    # Reset score
    scorer.reset(scraper_key)
    summaries_after = {s["key_hash"]: s for s in scorer.summary()}
    check("Reset score to 0", summaries_after.get(scraper_key, {}).get("score", 0.0) == 0.0)


# ═══════════════════════════════════════════════════════════════════════════════
# FEATURE 12: Config Loading (YAML + env var)
# ═══════════════════════════════════════════════════════════════════════════════


async def test_config() -> None:
    print("\n── Feature 12: Config — YAML + env var ──")
    import os
    import tempfile

    import yaml

    from honeypotllm.config import HoneypotConfig, WatermarkConfig

    # Default config
    cfg = HoneypotConfig(secret_key="k")
    check("Default threshold=0.75", cfg.suspicion_threshold == 0.75)
    check(
        "Default strategies=[unicode, syntactic]",
        cfg.watermark.strategies == ["unicode", "syntactic"],
    )
    check("Default webhook_url=None", cfg.webhook_url is None)

    # YAML roundtrip
    with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
        yaml.dump(
            {
                "secret_key": "test-key",
                "suspicion_threshold": 0.65,
                "webhook_url": "https://hooks.example.com/test",
                "watermark": {"strategies": ["unicode", "structural"]},
            },
            f,
        )
        fname = f.name

    loaded = HoneypotConfig.from_yaml(fname)
    check("YAML: threshold loaded", loaded.suspicion_threshold == 0.65)
    check("YAML: webhook_url loaded", loaded.webhook_url == "https://hooks.example.com/test")
    check("YAML: strategies loaded", "unicode" in loaded.watermark.strategies)
    os.unlink(fname)

    # structural in strategies accepted
    cfg2 = HoneypotConfig(
        secret_key="k",
        watermark=WatermarkConfig(strategies=["unicode", "structural"]),
    )
    check("structural in strategies literal accepted", "structural" in cfg2.watermark.strategies)

    # Env var secret_key
    os.environ["HONEYPOT_SECRET_KEY"] = "env-var-key"
    cfg3 = HoneypotConfig()
    check("secret_key from env var", cfg3.secret_key == "env-var-key")
    del os.environ["HONEYPOT_SECRET_KEY"]


# ═══════════════════════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════════════════════


async def main() -> None:
    print("=" * 64)
    print("honeypotllm — Complete Feature Verification")
    print("=" * 64)

    tests = [
        ("ProcessResult Pydantic + is_watermarked", test_process_result_pydantic),
        ("Async context manager", test_async_context_manager),
        ("Auto NLTK setup", test_auto_nltk_setup),
        ("Scraper detection + watermarking", test_scraper_detection),
        ("Trusted keys + bypass token", test_trusted_and_bypass),
        ("All watermark strategies", test_watermark_strategies),
        ("Structural watermarking (wash-resistant)", test_structural_watermark),
        ("Webhook alerts", test_webhook_alerts),
        ("Forensic detection", test_forensic_detection),
        ("Identity injection (trapdoor)", test_identity_injection),
        ("Suspicion scorer standalone", test_suspicion_scorer),
        ("Config — YAML + env var", test_config),
    ]

    failed_groups: list[str] = []
    for group_name, fn in tests:
        try:
            await fn()
        except Exception as exc:
            print(f"  ❌ EXCEPTION in {group_name}: {exc}")
            failed_groups.append(group_name)

    # Summary
    print("\n" + "=" * 64)
    print("SUMMARY")
    print("=" * 64)
    passed = sum(1 for _, s, _ in results if s == PASS)
    failed = sum(1 for _, s, _ in results if s == FAIL)
    for name, status, detail in results:
        print(f"  {status}  {name}" + (f" ({detail})" if detail else ""))

    print(f"\n{'=' * 64}")
    print(f"  Total:  {len(results)} checks")
    print(f"  Passed: {passed}")
    print(f"  Failed: {failed}")
    if failed_groups:
        print(f"  Failed groups: {', '.join(failed_groups)}")
    print("=" * 64)
    if failed > 0:
        raise SystemExit(1)
    print("\n✅ ALL FEATURES VERIFIED\n")


if __name__ == "__main__":
    asyncio.run(main())
