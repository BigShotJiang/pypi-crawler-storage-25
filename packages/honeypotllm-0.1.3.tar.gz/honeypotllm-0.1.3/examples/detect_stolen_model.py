"""
detect_stolen_model.py
======================
Forensic detection workflow — use this AFTER you suspect someone scraped
your API and trained a model on the stolen data.

What this script does:
    1. Loads sample outputs from a suspected model (from a JSONL file)
    2. Runs the honeypotllm Detector against those outputs
    3. Produces a forensic report showing:
       - Overall attribution score (0.0 to 1.0)
       - Confidence level (low / medium / high)
       - Whether the model is attributed to your watermarks
       - Breakdown by watermarking strategy

Run:
    # First generate a sample corpus (run this AFTER simple_protection.py)
    python detect_stolen_model.py --demo

    # Against a real JSONL file of suspected model outputs:
    python detect_stolen_model.py --outputs suspect_outputs.jsonl \\
        --watermark-ids <uuid> \\
        --config honeypot_config.yaml

JSONL format  (one JSON object per line):
    {"text": "Suspected model output 1"}
    {"text": "Suspected model output 2"}

Or use the CLI directly:
    honeypotllm detect \\
      --outputs suspect_outputs.jsonl \\
      --watermark-ids <uuid-1> <uuid-2> \\
      --config honeypot_config.yaml \\
      --report evidence.json
"""

from __future__ import annotations

import argparse
import asyncio
import json
import uuid
from pathlib import Path

from honeypotllm.config import HoneypotConfig, WatermarkConfig
from honeypotllm.detection import Detector
from honeypotllm.watermark import WatermarkEngine

# ─── Demo: generate poisoned corpus, then detect ──────────────────────────────


async def run_demo() -> None:
    """Generate a synthetic poisoned corpus and run detection against it."""
    print("🔬 honeypotllm — Detection Demo\n")

    config = HoneypotConfig(
        secret_key="demo-forensic-key",
        watermark=WatermarkConfig(strategies=["unicode", "syntactic"]),
    )
    engine = WatermarkEngine(config.watermark)
    detector = Detector(config)

    # ── Create two "attacker" API keys with distinct watermark IDs ────────────
    legit_watermark_id = str(uuid.uuid4())  # Not in the corpus
    scraper_watermark_id = str(uuid.uuid4())  # Embedded in the corpus

    print(f"Legit watermark ID   : {legit_watermark_id}")
    print(f"Scraper watermark ID : {scraper_watermark_id}\n")

    # ── Simulate a stolen corpus: 30 responses, all watermarked ──────────────
    sample_texts = [
        "Neural networks learn representations through gradient descent optimization.",
        "Transformers use self-attention to model long-range dependencies in sequences.",
        "Reinforcement learning trains agents via reward signals from the environment.",
        "Convolutional networks extract spatial hierarchies from image data.",
        "Large language models are trained on vast corpora using next-token prediction.",
        "Backpropagation computes gradients of the loss with respect to parameters.",
        "Dropout regularization prevents overfitting by randomly zeroing activations.",
        "Batch normalization stabilizes training by normalizing layer inputs.",
        "Embedding layers map discrete tokens to continuous vector representations.",
        "Attention mechanisms allow models to focus on relevant parts of the input.",
    ]

    stolen_corpus: list[str] = []
    for text in sample_texts * 3:  # 30 samples
        result = engine.apply(text, watermark_id=scraper_watermark_id)
        stolen_corpus.append(result.watermarked_text)

    print(f"Generated {len(stolen_corpus)} poisoned samples in the stolen corpus.\n")

    # ── Run detection ─────────────────────────────────────────────────────────
    print("Running detection...\n")
    report = detector.detect(
        texts=stolen_corpus,
        candidate_watermark_ids=[legit_watermark_id, scraper_watermark_id],
        target_model_name="SuspectedStolenModel-v1",
    )

    # ── Print results ─────────────────────────────────────────────────────────
    print("═" * 60)
    print("  DETECTION REPORT")
    print("═" * 60)
    print(f"  Target model      : {report.target_model_name}")
    print(f"  Texts analyzed    : {report.texts_analyzed}")
    print(f"  Overall score     : {report.overall_score:.4f}")
    print(f"  Confidence        : {report.confidence_level.upper()}")
    print(f"  Is attributed     : {'✅ YES' if report.is_attributed else '❌ NO'}")
    print()
    print(f"  Best match WM ID  : {report.attribution or 'None'}")
    print()

    if report.strategy_scores:
        print("  Per-strategy scores:")
        for strategy, score in report.strategy_scores.items():
            bar = "█" * int(score * 20)
            print(f"    {strategy:<12} {score:.4f}  {bar}")

    print("═" * 60)

    if report.is_attributed:
        print("\n✅ CONCLUSION: The suspected model was trained on YOUR watermarked data.")
        print(f"   Watermark ID to pursue legally: {report.attribution}")
    else:
        print("\n❌ CONCLUSION: Could not attribute the model to your watermarks.")

    # ── Save evidence file ────────────────────────────────────────────────────
    evidence_path = Path("detection_evidence.json")
    report_dict = {
        "target_model": report.target_model_name,
        "texts_analyzed": report.texts_analyzed,
        "overall_score": report.overall_score,
        "confidence_level": report.confidence_level,
        "is_attributed": report.is_attributed,
        "attribution_watermark_id": report.attribution,
        "candidate_watermark_ids": [legit_watermark_id, scraper_watermark_id],
        "strategy_scores": report.strategy_scores or {},
    }
    evidence_path.write_text(json.dumps(report_dict, indent=2))
    print(f"\n📄 Evidence saved to: {evidence_path}")
    print("   Share this file with your legal counsel.")


# ─── CLI against real JSONL ────────────────────────────────────────────────────


def run_real_detection(args: argparse.Namespace) -> None:
    """Run detection against a user-provided JSONL file."""
    # Load config
    config = HoneypotConfig.from_yaml(args.config) if args.config else HoneypotConfig(secret_key="")
    detector = Detector(config)

    # Load texts
    outputs_path = Path(args.outputs)
    texts: list[str] = []
    with open(outputs_path) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
                texts.append(obj.get("text", obj.get("output", str(obj))))
            except json.JSONDecodeError:
                texts.append(line)  # Plain text line

    print(f"Loaded {len(texts)} texts from {outputs_path}")

    report = detector.detect(
        texts=texts,
        candidate_watermark_ids=args.watermark_ids,
        target_model_name=args.model_name or "UnknownModel",
    )

    print(f"\nScore: {report.overall_score:.4f} | Confidence: {report.confidence_level}")
    print(f"Is attributed: {report.is_attributed}")
    if report.attribution:
        print(f"Attributed to watermark ID: {report.attribution}")

    if args.report:
        Path(args.report).write_text(
            json.dumps(
                {
                    "target_model": report.target_model_name,
                    "texts_analyzed": report.texts_analyzed,
                    "overall_score": report.overall_score,
                    "confidence_level": report.confidence_level,
                    "is_attributed": report.is_attributed,
                    "attribution_watermark_id": report.attribution,
                },
                indent=2,
            )
        )
        print(f"Report saved: {args.report}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="honeypotllm detection workflow")
    parser.add_argument("--demo", action="store_true", help="Run the built-in demo")
    parser.add_argument("--outputs", help="Path to JSONL file of suspected model outputs")
    parser.add_argument(
        "--watermark-ids", nargs="+", help="Candidate watermark UUIDs to test against"
    )
    parser.add_argument("--config", help="Path to honeypot_config.yaml")
    parser.add_argument("--report", help="Path to save JSON evidence report")
    parser.add_argument("--model-name", default="SuspectedModel", help="Name for the report")
    args = parser.parse_args()

    if args.demo or not args.outputs:
        asyncio.run(run_demo())
    else:
        run_real_detection(args)
