"""
Example: Structural Watermarking — Adversarial-Wash Resistance
==============================================================
Shows how honeypotllm's structural strategy survives LLM-based
"washing" attacks where an attacker rephrases your responses.

Run:
    python examples/structural_watermarking.py
"""

from honeypotllm.config import WatermarkConfig
from honeypotllm.watermark import WatermarkEngine
from honeypotllm.watermark.structural import StructuralWatermarkStrategy


def show_diff(original: str, watermarked: str) -> None:
    """Show what changed between original and watermarked text."""
    if original == watermarked:
        print("  (no structural changes on this text)")
        return
    for orig, wm in zip(original.split(), watermarked.split(), strict=False):
        if orig != wm:
            print(f"  Changed: '{orig}' → '{wm}'")


def main() -> None:
    print("=" * 64)
    print("Structural Watermarking — Adversarial-Wash Resistance")
    print("=" * 64)

    strategy = StructuralWatermarkStrategy()

    text = (
        "Python is an excellent programming language. However, it can be "
        "slow for CPU-intensive tasks - which is a common concern. Moreover, "
        "you can use NumPy or Cython to speed things up. Furthermore, the "
        "ecosystem is vast and active."
    )
    watermark_id = "scraper-key-watermark-uuid"

    # ── Part 1: What changes at the structural level ──────────────────────────
    print("\n1️⃣  What the structural strategy changes:\n")

    for seed, label in [(1, "seed=1 (em-dash, key A)"), (0, "seed=0 (en-dash, key B)")]:
        result = strategy.apply(text, seed=seed)
        print(f"  [{label}]")
        print(f"  Original : ...{text[40:100]}...")
        print(f"  Watermark: ...{result.watermarked_text[40:100]}...")
        if "\u2014" in result.watermarked_text:
            print("  → em-dash (—) inserted")
        if "\u2013" in result.watermarked_text:
            print("  → en-dash (–) inserted")
        print()

    # ── Part 2: The "adversarial wash" scenario ───────────────────────────────
    print("2️⃣  The adversarial wash attack scenario:\n")

    result = strategy.apply(text, seed=1)
    original_watermarked = result.watermarked_text

    print("  Scraper receives watermarked response:")
    print(f"  '{original_watermarked[:120]}...'")
    print()

    # Simulate adversarial LLM "washing" — changes words but NOT structure
    washed = (
        original_watermarked.replace("excellent", "great")
        .replace("slow", "sluggish")
        .replace("vast", "extensive")
        .replace("speed", "accelerate")
        .replace("concern", "issue")
    )
    print("  After adversarial LLM rephrasing (word-level wash):")
    print(f"  '{washed[:120]}...'")
    print()

    # Check: em-dash still there?
    em_dash_survives = "\u2014" in washed
    print(
        f"  Em-dash (—) survived word-level rephrasing: {'✅ YES' if em_dash_survives else '❌ NO'}"
    )
    print()

    # ── Part 3: Detection on a washed corpus ─────────────────────────────────
    print("3️⃣  Detection on a corpus of washed responses:\n")

    config = WatermarkConfig(strategies=["structural"])
    engine = WatermarkEngine(config)

    sentences = [
        "Neural networks learn via gradient descent - a key optimization technique.",
        "Transformers use attention mechanisms - which model token relationships.",
        "Reinforcement learning trains agents via reward signals - this works well.",
        "Backpropagation computes gradients efficiently - despite its complexity.",
        "Batch normalization stabilizes training - this is extremely important.",
    ]

    # Watermark all sentences with same key
    watermarked = [engine.apply(s, watermark_id=watermark_id).watermarked_text for s in sentences]

    # Simulate word-level wash on each
    washed_corpus = [
        s.replace("learn", "train")
        .replace("train", "learn")
        .replace("efficiently", "quickly")
        .replace("extremely", "very")
        for s in watermarked
    ]

    score_correct = engine.detect(washed_corpus, watermark_id=watermark_id)
    score_wrong = engine.detect(washed_corpus, watermark_id="wrong-key-00000000")

    print(f"  Detection on washed corpus (correct watermark_id): {score_correct.overall_score:.3f}")
    print(f"  Detection on washed corpus (wrong watermark_id):   {score_wrong.overall_score:.3f}")
    print()
    print(f"  Strategy: {score_correct.strategy_scores[0].strategy}")
    if score_correct.strategy_scores[0].metadata:
        md = score_correct.strategy_scores[0].metadata
        print(f"  Em-dash texts in corpus: {md.get('em_dash_texts', 0)}")
        print(f"  En-dash texts in corpus: {md.get('en_dash_texts', 0)}")
        print(f"  Expected dash style:     {md.get('expected_dash', '?')}")

    # ── Part 4: Combining with other strategies ───────────────────────────────
    print("\n4️⃣  Combining structural + unicode (full protection):\n")

    combined_config = WatermarkConfig(strategies=["unicode", "structural"])
    combined_engine = WatermarkEngine(combined_config)
    combined_result = combined_engine.apply(text, watermark_id=watermark_id)

    print(f"  Strategies applied: {combined_result.strategies_applied}")
    print(f"  Total changes: {combined_result.total_changes}")
    print()
    print("  Structural watermarks: survive LLM rephrasing ✅")
    print("  Unicode watermarks:    survive copy-paste ✅ (may be stripped by tokenizers)")
    print("  Combined:              best coverage ✅")

    print("\n" + "=" * 64)
    print("  Key insight: structural watermarks survive because they change")
    print("  HOW information is presented, not WHICH words are used.")
    print("=" * 64)


if __name__ == "__main__":
    main()
