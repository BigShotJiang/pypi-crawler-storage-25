"""
Test webhook alerts against REAL Slack/Discord endpoints.
=========================================================

This script sends a REAL webhook — you will see the notification appear.

STEP 1 (Discord — easiest, 2 minutes):
  a. Open Discord → create a server (or use existing)
  b. Click any channel → Settings (gear icon) → Integrations → Webhooks
  c. Click "New Webhook" → Copy Webhook URL
  d. Run: python examples/test_real_webhook.py --url "https://discord.com/api/webhooks/..."

STEP 2 (Slack):
  a. Go to https://api.slack.com/apps → Create New App → From Scratch
  b. Enable "Incoming Webhooks" → "Add New Webhook to Workspace"
  c. Pick a channel → Copy the webhook URL
  d. Run: python examples/test_real_webhook.py --url "https://hooks.slack.com/services/..."

STEP 3 (webhook.site — no signup, instant):
  a. Open https://webhook.site in your browser
  b. Copy the "Your unique URL"
  c. Run: python examples/test_real_webhook.py --url "https://webhook.site/your-uuid"
  d. Watch the request appear live in your browser

Usage:
  python examples/test_real_webhook.py --url <webhook-url>
  python examples/test_real_webhook.py --url <webhook-url> --simulate-scraper
"""

from __future__ import annotations

import argparse
import asyncio
import json
import logging
import sys

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")


async def send_test_alert(webhook_url: str) -> None:
    """Send a single test alert payload directly (no scraper simulation)."""
    try:
        import httpx
    except ImportError:
        print("ERROR: httpx not installed. Run: pip install httpx")
        sys.exit(1)

    from honeypotllm.alerts import _build_payload

    payload = _build_payload(
        api_key_hash="deadbeef" * 8,
        suspicion_score=0.9200,
        triggered_heuristics=["rate_spike", "sequential_input", "no_gap"],
        watermark_id="test-wm-uuid-1234-abcd",
        score_delta=0.35,
        webhook_url=webhook_url,
    )

    print("\n📤 Sending payload to:", webhook_url)
    print("─" * 60)
    # Show what we're sending (hide embeds for readability)
    display = {k: v for k, v in payload.items() if k != "embeds"}
    print(json.dumps(display, indent=2))
    if "embeds" in payload:
        print(f'  "embeds": [{len(payload["embeds"])} embed(s)]')
    print("─" * 60)

    raw = json.dumps(payload, separators=(",", ":")).encode()
    headers = {"Content-Type": "application/json", "User-Agent": "honeypotllm-test/0.1"}

    async with httpx.AsyncClient(timeout=10.0) as client:
        resp = await client.post(webhook_url, content=raw, headers=headers)

    print(f"\n📬 Response: HTTP {resp.status_code}")
    if resp.text:
        print(f"   Body: {resp.text[:200]}")

    if resp.status_code in (200, 204):
        print("\n✅ SUCCESS — check your Slack/Discord channel or webhook.site now!")
    elif resp.status_code == 400:
        print("\n❌ HTTP 400 — payload format issue. Response body above shows what's wrong.")
    elif resp.status_code == 401:
        print("\n❌ HTTP 401 — Invalid webhook URL or it was deleted. Create a new one.")
    elif resp.status_code == 404:
        print("\n❌ HTTP 404 — Webhook URL not found. Check the URL is correct.")
    else:
        print(f"\n⚠️  Unexpected HTTP {resp.status_code}")


async def simulate_scraper_and_alert(webhook_url: str) -> None:
    """Spin up the full middleware and simulate a real scraper detection."""
    from honeypotllm import HoneypotMiddleware
    from honeypotllm.config import HoneypotConfig

    print("\n🤖 Simulating scraper detection via full middleware pipeline...")
    print("   (20 rapid template queries → triggers detection → webhook fires)")

    config = HoneypotConfig(
        secret_key="test-secret-key",
        webhook_url=webhook_url,
        alert_on_first_detection_only=True,
        suspicion_threshold=0.75,
    )

    async with HoneypotMiddleware(config) as honeypot:
        languages = [
            "Python",
            "Java",
            "C++",
            "Rust",
            "Go",
            "TypeScript",
            "Kotlin",
            "Swift",
            "Ruby",
            "PHP",
            "Scala",
            "Haskell",
            "Erlang",
            "R",
            "Julia",
            "Dart",
            "Zig",
            "Nim",
            "OCaml",
            "Elixir",
        ]
        result = None
        for lang in languages:
            result = await honeypot.process(
                api_key="demo-scraper-bot",
                response_text=f"{lang} is a programming language with unique features.",
                prompt=f"What is {lang}?",
            )
            if result.is_watermarked:
                print(f"   🚨 Scraper detected at request #{languages.index(lang) + 1}!")
                print(f"      Score: {result.suspicion_score:.4f}")
                print(f"      Triggers: {result.triggered_heuristics}")
                break

        # Give the async webhook task a moment to complete
        await asyncio.sleep(1.5)

    if result and result.is_watermarked:
        print("\n✅ Middleware triggered the webhook.")
        print("   Check your Slack/Discord/webhook.site now!")
    else:
        print("\n⚠️  Scraper threshold not reached — try lowering suspicion_threshold")


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Test honeypotllm webhook against a real Slack/Discord endpoint",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument(
        "--url",
        required=True,
        help=(
            "Webhook URL to test. "
            "Discord: https://discord.com/api/webhooks/... | "
            "Slack: https://hooks.slack.com/services/... | "
            "Test: https://webhook.site/your-uuid"
        ),
    )
    parser.add_argument(
        "--simulate-scraper",
        action="store_true",
        help="Simulate a real scraper via the full middleware (vs direct payload send)",
    )
    args = parser.parse_args()

    if args.simulate_scraper:
        asyncio.run(simulate_scraper_and_alert(args.url))
    else:
        asyncio.run(send_test_alert(args.url))


if __name__ == "__main__":
    main()
