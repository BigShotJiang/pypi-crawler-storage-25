"""Minimal FastAPI integration example for honeypotllm.

Run this example::

    pip install honeypotllm[fastapi]
    HONEYPOT_SECRET_KEY=my-secret uvicorn examples.fastapi_example:app --reload

Then simulate a scraper::

    # Rapid requests that will trigger the suspicion scorer
    for i in $(seq 1 20); do
        curl -s -X POST http://localhost:8000/v1/chat/completions \\
          -H "Content-Type: application/json" \\
          -H "Authorization: Bearer scraper-api-key-001" \\
          -d '{"messages": [{"role": "user", "content": "What is machine learning?"}]}' | jq .
    done

    # Check the suspicion score
    curl http://localhost:8000/admin/score/scraper-api-key-001 | jq .
"""

from __future__ import annotations

import os
from contextlib import asynccontextmanager
from typing import Any

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from honeypotllm import HoneypotMiddleware
from honeypotllm.config import HoneypotConfig, ScoringConfig, WatermarkConfig

# ─── Configuration ────────────────────────────────────────────────────────────

config = HoneypotConfig(
    secret_key=os.environ.get("HONEYPOT_SECRET_KEY", "dev-key-change-in-production"),
    suspicion_threshold=0.60,
    db_url="sqlite+aiosqlite:///honeypot_example.db",
    watermark=WatermarkConfig(
        strategies=["unicode", "syntactic"],
        global_seed=42,
    ),
    scoring=ScoringConfig(
        requests_per_minute_threshold=10,
        requests_per_hour_threshold=100,
        requests_per_day_threshold=1000,
    ),
    trusted_keys=[],
)

honeypot = HoneypotMiddleware(config)


# ─── Lifespan ─────────────────────────────────────────────────────────────────


@asynccontextmanager
async def lifespan(app: FastAPI):
    await honeypot.init()
    yield
    await honeypot.close()


app = FastAPI(
    title="honeypotllm FastAPI Example",
    description="Demonstrates honeypotllm integration with a minimal LLM API.",
    version="0.1.0",
    lifespan=lifespan,
)


# ─── Request/Response models ──────────────────────────────────────────────────


class Message(BaseModel):
    role: str
    content: str


class ChatRequest(BaseModel):
    messages: list[Message]
    max_tokens: int = 256
    temperature: float = 0.7


class ChatResponse(BaseModel):
    id: str
    object: str = "chat.completion"
    choices: list[dict[str, Any]]
    was_watermarked: bool = False  # Would be omitted in production


# ─── Simulated LLM ────────────────────────────────────────────────────────────


def _fake_llm_generate(messages: list[Message]) -> str:
    """Simulated LLM response — replace with your real LLM call."""
    last_message = messages[-1].content if messages else ""
    return (
        f"This is a simulated response to: '{last_message[:60]}...'. "
        "In a real deployment, this would be your LLM's actual output. "
        "The honeypotllm middleware will transparently watermark this response "
        "if the requesting API key has been flagged as suspicious."
    )


# ─── API endpoints ────────────────────────────────────────────────────────────


@app.post("/v1/chat/completions", response_model=ChatResponse)
async def chat_completions(request: Request, body: ChatRequest) -> ChatResponse:
    """OpenAI-compatible chat completions endpoint with honeypot protection."""
    # Extract the API key
    auth_header = request.headers.get("Authorization", "")
    api_key = auth_header.removeprefix("Bearer ").strip()

    if not api_key:
        raise HTTPException(status_code=401, detail="Missing Authorization header.")

    # Generate the real LLM response
    original_response = _fake_llm_generate(body.messages)
    user_prompt = body.messages[-1].content if body.messages else ""

    # Process through honeypot (score + potentially watermark)
    result = await honeypot.process(
        api_key=api_key,
        response_text=original_response,
        prompt=user_prompt,
    )

    return ChatResponse(
        id="chatcmpl-honeypot-example",
        choices=[
            {
                "index": 0,
                "message": {"role": "assistant", "content": result.response_text},
                "finish_reason": "stop",
            }
        ],
        was_watermarked=result.was_watermarked,
    )


@app.get("/admin/score/{api_key}")
async def get_score(api_key: str) -> dict[str, Any]:
    """Check the suspicion score for an API key (admin endpoint)."""
    score = honeypot.get_suspicion_score(api_key)
    return {
        "api_key_preview": api_key[:8] + "...",
        "suspicion_score": round(score, 4),
        "is_suspicious": honeypot.is_suspicious(api_key),
        "threshold": config.suspicion_threshold,
    }


@app.get("/admin/summary")
async def summary() -> dict[str, Any]:
    """Return a summary of all tracked API keys."""
    return {"keys": honeypot.summary()}


@app.post("/admin/reset/{api_key}")
async def reset_score(api_key: str) -> dict[str, str]:
    """Manually reset a key's suspicion score after human review."""
    honeypot.reset_score(api_key)
    return {"status": "reset", "api_key_preview": api_key[:8] + "..."}


@app.get("/admin/evidence/{api_key_hash}")
async def export_evidence(api_key_hash: str) -> JSONResponse:
    """Export a forensic evidence package for a given API key hash."""
    import tempfile

    with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
        tmp_path = f.name

    package = await honeypot.export_evidence(api_key_hash, tmp_path)
    return JSONResponse(content=package)


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000)
