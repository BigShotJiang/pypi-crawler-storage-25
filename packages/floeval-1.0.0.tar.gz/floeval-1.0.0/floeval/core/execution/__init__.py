"""
Execution engine module
"""
