import argparse
import json
import sys

from . import (
    get_super_observations,
    get_observations,

    get_observations_page,
    get_super_observations_page,

    poll_super_observations,
    poll_observations,

    get_flying_missions,
    get_mission_launch_site,
    get_predicted_path,
    get_current_location,
    get_flight_path,
    get_constellation_status,
    get_soundings,
    get_sounding,

    get_point_forecasts,
    get_point_forecasts_interpolated,
    get_initialization_times,
    get_archived_initialization_times,
    get_run_information,
    get_variables,
    get_gridded_forecast,
    get_tropical_cyclones,
    get_population_weighted_hdds,
    get_population_weighted_cdds,
    get_calculation_times_degree_days,

    get_available_stations,
    get_station_forecast,
    get_interpolated_sounding,

    get_analysis_available_times,
    get_analysis_variables,
    get_interpolated_analysis,
    get_gridded_analysis
)

from pprint import pprint

def main():
    # Normalize command to use underscores before parsing (supports both dashes and underscores)
    if len(sys.argv) > 1 and not sys.argv[1].startswith('-'):
        sys.argv[1] = sys.argv[1].replace('-', '_')

    parser = argparse.ArgumentParser(description='WindBorne API Command Line Interface')
    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    ####################################################################################################################
    # DATA API FUNCTIONS
    ####################################################################################################################
    # Super Observations Command
    super_obs_parser = subparsers.add_parser('super_observations', help='Poll super observations within a time range')
    super_obs_parser.add_argument('start_time', help='Starting time (YYYY-MM-DD_HH:MM, "YYYY-MM-DD HH:MM:SS" or YYYY-MM-DDTHH:MM:SS.fffZ)')
    super_obs_parser.add_argument('end_time', help='End time (YYYY-MM-DD_HH:MM, "YYYY-MM-DD HH:MM:SS" or YYYY-MM-DDTHH:MM:SS.fffZ)', nargs='?', default=None)
    super_obs_parser.add_argument('-b', '--bucket-hours', type=float, default=6.0, help='Hours per bucket')
    super_obs_parser.add_argument('-d', '--output-dir', help='Directory path where the separate files should be saved. If not provided, files will be saved in current directory.')
    super_obs_parser.add_argument('-m', '--mission-id', help='Filter by mission ID')
    super_obs_parser.add_argument('-ml', '--min-latitude', type=float, help='Minimum latitude filter')
    super_obs_parser.add_argument('-xl', '--max-latitude', type=float, help='Maximum latitude filter')
    super_obs_parser.add_argument('-mg', '--min-longitude', type=float, help='Minimum longitude filter')
    super_obs_parser.add_argument('-xg', '--max-longitude', type=float, help='Maximum longitude filter')
    super_obs_parser.add_argument('output', help='Save output to a single file (filename.csv, filename.json or filename.little_r) or to or to multiple files (csv, json, netcdf or little_r)')

    # Observations Command
    obs_parser = subparsers.add_parser('observations', help='Poll observations within a time range')
    obs_parser.add_argument('start_time', help='Starting time (YYYY-MM-DD_HH:MM, "YYYY-MM-DD HH:MM:SS" or YYYY-MM-DDTHH:MM:SS.fffZ)')
    obs_parser.add_argument('end_time', help='End time (YYYY-MM-DD_HH:MM, "YYYY-MM-DD HH:MM:SS" or YYYY-MM-DDTHH:MM:SS.fffZ)', nargs='?', default=None)
    obs_parser.add_argument('-m', '--mission-id', help='Filter observations by mission ID')
    obs_parser.add_argument('-ml', '--min-latitude', type=float, help='Minimum latitude filter')
    obs_parser.add_argument('-xl', '--max-latitude', type=float, help='Maximum latitude filter')
    obs_parser.add_argument('-mg', '--min-longitude', type=float, help='Minimum longitude filter')
    obs_parser.add_argument('-xg', '--max-longitude', type=float, help='Maximum longitude filter')
    obs_parser.add_argument('-u', '--include-updated-at', action='store_true', help='Include update timestamps')
    obs_parser.add_argument('-b', '--bucket-hours', type=float, default=6.0, help='Hours per bucket')
    obs_parser.add_argument('-d', '--output-dir', help='Directory path where the separate files should be saved. If not provided, files will be saved in current directory.')
    obs_parser.add_argument('output', help='Save output to a single file (filename.csv, filename.json or filename.little_r) or to multiple files (csv, json, netcdf or little_r)')


    # Get Observations Page Command
    obs_page_parser = subparsers.add_parser('observations_page', help='Get observations page with filters')
    obs_page_parser.add_argument('since', help='Get observations since this time (YYYY-MM-DD_HH:MM, "YYYY-MM-DD HH:MM:SS" or YYYY-MM-DDTHH:MM:SS.fffZ)')
    obs_page_parser.add_argument('-mt', '--min-time', help='Minimum time filter (YYYY-MM-DD_HH:MM, "YYYY-MM-DD HH:MM:SS" or YYYY-MM-DDTHH:MM:SS.fffZ)')
    obs_page_parser.add_argument('-xt', '--max-time', help='Maximum time filter (YYYY-MM-DD_HH:MM, "YYYY-MM-DD HH:MM:SS" or YYYY-MM-DDTHH:MM:SS.fffZ)')
    obs_page_parser.add_argument('-m', '--mission-id', help='Filter by mission ID')
    obs_page_parser.add_argument('-ml', '--min-latitude', type=float, help='Minimum latitude filter')
    obs_page_parser.add_argument('-xl', '--max-latitude', type=float, help='Maximum latitude filter')
    obs_page_parser.add_argument('-mg', '--min-longitude', type=float, help='Minimum longitude filter')
    obs_page_parser.add_argument('-xg', '--max-longitude', type=float, help='Maximum longitude filter')
    obs_page_parser.add_argument('-id', '--include-ids', action='store_true', help='Include observation IDs')
    obs_page_parser.add_argument('-mn', '--include-mission-name', action='store_true', help='Include mission names')
    obs_page_parser.add_argument('-u', '--include-updated-at', action='store_true', help='Include update timestamps')
    obs_page_parser.add_argument('output', nargs='?', help='Output file')

    # Get Super Observations Command
    super_obs_page_parser = subparsers.add_parser('super_observations_page', help='Get super observations page with filters')
    super_obs_page_parser.add_argument('since', help='Get super observations page since this time (YYYY-MM-DD_HH:MM, "YYYY-MM-DD HH:MM:SS" or YYYY-MM-DDTHH:MM:SS.fffZ)')
    super_obs_page_parser.add_argument('-mt', '--min-time', help='Minimum time filter (YYYY-MM-DD_HH:MM, "YYYY-MM-DD HH:MM:SS" or YYYY-MM-DDTHH:MM:SS.fffZ)')
    super_obs_page_parser.add_argument('-xt', '--max-time', help='Maximum time filter (YYYY-MM-DD_HH:MM, "YYYY-MM-DD HH:MM:SS" or YYYY-MM-DDTHH:MM:SS.fffZ)')
    super_obs_page_parser.add_argument('-m', '--mission-id', help='Filter by mission ID')
    super_obs_page_parser.add_argument('-ml', '--min-latitude', type=float, help='Minimum latitude filter')
    super_obs_page_parser.add_argument('-xl', '--max-latitude', type=float, help='Maximum latitude filter')
    super_obs_page_parser.add_argument('-mg', '--min-longitude', type=float, help='Minimum longitude filter')
    super_obs_page_parser.add_argument('-xg', '--max-longitude', type=float, help='Maximum longitude filter')
    super_obs_page_parser.add_argument('-id', '--include-ids', action='store_true', help='Include observation IDs')
    super_obs_page_parser.add_argument('-mn', '--include-mission-name', action='store_true', help='Include mission names')
    super_obs_page_parser.add_argument('-u', '--include-updated-at', action='store_true', help='Include update timestamps')
    super_obs_page_parser.add_argument('output', nargs='?', help='Output file')

    # Poll Super Observations Command
    poll_super_obs_parser = subparsers.add_parser('poll_super_observations', help='Continuously polls for super observations and saves to files in specified format.')
    poll_super_obs_parser.add_argument('start_time', help='Starting time (YYYY-MM-DD_HH:MM, "YYYY-MM-DD HH:MM:SS" or YYYY-MM-DDTHH:MM:SS.fffZ)')
    poll_super_obs_parser.add_argument('-b', '--bucket-hours', type=float, default=6.0, help='Hours per bucket')
    poll_super_obs_parser.add_argument('-d', '--output-dir', help='Directory path where the separate files should be saved. If not provided, files will be saved in current directory.')
    poll_super_obs_parser.add_argument('-m', '--mission-id', help='Filter observations by mission ID')
    poll_super_obs_parser.add_argument('output', help='Save output to multiple files (csv, json, netcdf or little_r)')

    # Poll Observations Command
    poll_obs_parser = subparsers.add_parser('poll_observations', help='Continuously polls for observations and saves to files in specified format.')
    poll_obs_parser.add_argument('start_time', help='Starting time (YYYY-MM-DD_HH:MM, "YYYY-MM-DD HH:MM:SS" or YYYY-MM-DDTHH:MM:SS.fffZ)')
    poll_obs_parser.add_argument('-m', '--mission-id', help='Filter observations by mission ID')
    poll_obs_parser.add_argument('-ml', '--min-latitude', type=float, help='Minimum latitude filter')
    poll_obs_parser.add_argument('-xl', '--max-latitude', type=float, help='Maximum latitude filter')
    poll_obs_parser.add_argument('-mg', '--min-longitude', type=float, help='Minimum longitude filter')
    poll_obs_parser.add_argument('-xg', '--max-longitude', type=float, help='Maximum longitude filter')
    poll_obs_parser.add_argument('-u', '--include-updated-at', action='store_true', help='Include update timestamps')
    poll_obs_parser.add_argument('-b', '--bucket-hours', type=float, default=6.0, help='Hours per bucket')
    poll_obs_parser.add_argument('-d', '--output-dir', help='Directory path where the separate files should be saved. If not provided, files will be saved in current directory.')
    poll_obs_parser.add_argument('output', help='Save output to multiple files (csv, json, netcdf or little_r)')

    # Get Flying Missions Command
    flying_parser = subparsers.add_parser('flying_missions', help='Get currently flying missions')
    flying_parser.add_argument('output', nargs='?', help='Output file')

    # Get Mission Launch Site Command
    launch_site_parser = subparsers.add_parser('launch_site', help='Get mission launch site')
    launch_site_parser.add_argument('mission_id', help='Mission ID')
    launch_site_parser.add_argument('output', nargs='?', help='Output file')

    # Get Current Location Command
    current_location_parser = subparsers.add_parser('current_location', help='Get current location')
    current_location_parser.add_argument('mission_id', help='Mission ID')
    current_location_parser.add_argument('output', nargs='?', help='Output file')

    # Get Predicted Path Command
    prediction_parser = subparsers.add_parser('predict_path', help='Get predicted flight path')
    prediction_parser.add_argument('mission_id', help='Mission ID')
    prediction_parser.add_argument('output', nargs='?', help='Output file')

    # Get Flight Path Command
    flight_path_parser = subparsers.add_parser('flight_path', help='Get traveled flight path')
    flight_path_parser.add_argument('mission_id', help='Mission ID')
    flight_path_parser.add_argument('output', nargs='?', help='Output file')

    # Get Constellation Status Command
    constellation_parser = subparsers.add_parser('constellation_status', help='Get current constellation status with locations')
    constellation_parser.add_argument('output', nargs='?', help='Output file (.csv or .json)')

    # Soundings Command
    soundings_parser = subparsers.add_parser('soundings', help='List/search atmospheric soundings')
    soundings_parser.add_argument('-m', '--mission-id', help='Filter by mission ID')
    soundings_parser.add_argument('-mt', '--min-time', help='Filter soundings starting at or after this time')
    soundings_parser.add_argument('-xt', '--max-time', help='Filter soundings ending at or before this time')
    soundings_parser.add_argument('-ma', '--min-altitude', type=float, help='Exclude soundings below this altitude (meters)')
    soundings_parser.add_argument('-xa', '--max-altitude', type=float, help='Exclude soundings above this altitude (meters)')
    soundings_parser.add_argument('-ml', '--min-lat', type=float, help='Minimum latitude')
    soundings_parser.add_argument('-xl', '--max-lat', type=float, help='Maximum latitude')
    soundings_parser.add_argument('-mg', '--min-lon', type=float, help='Minimum longitude')
    soundings_parser.add_argument('-xg', '--max-lon', type=float, help='Maximum longitude')
    soundings_parser.add_argument('-p', '--page', type=int, help='Page number (default 0)')
    soundings_parser.add_argument('-ps', '--page-size', type=int, help='Results per page (default 64, max 200)')
    soundings_parser.add_argument('output', nargs='?', help='Output file (.csv or .json)')

    # Sounding by ID Command
    sounding_parser = subparsers.add_parser('sounding', help='Get full sounding data by ID')
    sounding_parser.add_argument('sounding_id', help='Sounding ID (UUID)')
    sounding_parser.add_argument('output', nargs='?', help='Output file (.csv or .json)')

    ####################################################################################################################
    # FORECASTS API FUNCTIONS
    ####################################################################################################################
   
    # Points Forecast Command
    # We have quite a few quite a few optional query parameters here
    # so we set coordinates and output_file to required instead of
    # setting all args into a parser arg (add_argument('args', nargs='*', ...)
    points_parser = subparsers.add_parser('points', help='Get the forecast at given point(s) or station(s)')
    points_parser.add_argument('coordinates', help='Coordinate pairs in format "latitudeA,longitudeA; latitudeB,longitudeB" or station IDs like "PANC;KJFK"')
    points_parser.add_argument('-mt','--min-time', help='Minimum forecast time')
    points_parser.add_argument('-xt','--max-time', help='Maximum forecast time')
    points_parser.add_argument('-mh','--min-hour', type=int, help='Minimum forecast hour')
    points_parser.add_argument('-xh','--max-hour', type=int, help='Maximum forecast hour')
    points_parser.add_argument('-i', '--init-time', help='Initialization time')
    points_parser.add_argument('-m', '--model', default='wm', help='Forecast model (e.g., wm, wm4, wm-4.5-ens)')
    points_parser.add_argument('output_file', nargs='?', help='Output file')

    # Interpolated Points Forecast Command
    points_interpolated_parser = subparsers.add_parser('points_interpolated', help='Get interpolated forecast at given point(s)')
    points_interpolated_parser.add_argument('coordinates', help='Coordinate pairs in format "latitudeA,longitudeA; latitudeB,longitudeB"')
    points_interpolated_parser.add_argument('-mt','--min-time', help='Minimum forecast time')
    points_interpolated_parser.add_argument('-xt','--max-time', help='Maximum forecast time')
    points_interpolated_parser.add_argument('-mh','--min-hour', type=int, help='Minimum forecast hour')
    points_interpolated_parser.add_argument('-xh','--max-hour', type=int, help='Maximum forecast hour')
    points_interpolated_parser.add_argument('-i', '--init-time', help='Initialization time')
    points_interpolated_parser.add_argument('-e', '--ens-member', help='Ensemble member (eg 1 or mean)')
    points_interpolated_parser.add_argument('-m', '--model', default='wm', help='Forecast model (e.g., wm, wm4, wm-4.5-ens)')
    points_interpolated_parser.add_argument('output_file', nargs='?', help='Output file (.csv or .json)')

    # Station Forecasts
    ####################################################################################################################

    # Available Stations Command
    available_stations_parser = subparsers.add_parser('available_stations', help='List all weather stations with station-specific forecasts')
    available_stations_parser.add_argument('-m', '--model', default='wm', help='Forecast model (e.g., wm, wm4, wm-4.5-ens)')
    available_stations_parser.add_argument('output_file', nargs='?', help='Output file (.csv or .json)')

    # Station Forecast Command
    station_forecast_parser = subparsers.add_parser('station_forecast', help='Get weather forecast for a specific station')
    station_forecast_parser.add_argument('station_id', help='ICAO station identifier (e.g., PANC, KJFK, SFO)')
    station_forecast_parser.add_argument('-i', '--init-time', help='Initialization time (ISO 8601)')
    station_forecast_parser.add_argument('-m', '--model', default='wm', help='Forecast model (e.g., wm, wm4, wm-4.5-ens)')
    station_forecast_parser.add_argument('output_file', nargs='?', help='Output file (.csv or .json)')

    # Interpolated Sounding Command
    interpolated_sounding_parser = subparsers.add_parser('interpolated_sounding', help='Get interpolated forecast sounding for a coordinate')
    interpolated_sounding_parser.add_argument('coordinates', help='Coordinates as "latitude,longitude"')
    interpolated_sounding_parser.add_argument('-m', '--model', default='wm', help='Forecast model (e.g., wm, wm-5c)')
    interpolated_sounding_parser.add_argument('-t', '--time', help='Forecast valid time (ISO 8601)')
    interpolated_sounding_parser.add_argument('-i', '--init-time', help='Initialization time (ISO 8601)')
    interpolated_sounding_parser.add_argument('-fh', '--forecast-hour', type=int, help='Forecast hour offset')
    interpolated_sounding_parser.add_argument('output_file', nargs='?', help='Output file (.csv or .json)')

    # GRIDDED FORECASTS
    ####################################################################################################################
    gridded_parser = subparsers.add_parser('gridded', help='Get gridded forecast for a variable')
    gridded_parser.add_argument('args', nargs='*', help='variable time output_file')
    gridded_parser.add_argument('-e', '--ens-member', help='Ensemble member (eg 1 or mean)')
    gridded_parser.add_argument('-m', '--model', default='wm', help='Forecast model (e.g., wm, wm4, wm-4.5-ens, ecmwf-det)')

    # OTHER
    # TCS
    ####################################################################################################################

    # Tropical Cyclones Command
    tropical_cyclones_parser = subparsers.add_parser('tropical_cyclones', help='Get tropical cyclone forecasts')
    tropical_cyclones_parser.add_argument('-b', '--basin',  help='Optional: filter tropical cyclones on basin[ NA, EP, WP, NI, SI, AU, SP]')
    tropical_cyclones_parser.add_argument('-m', '--model', default='wm', help='Forecast model (e.g., wm, wm4, wm-4.5-ens, ecmwf-det)')
    tropical_cyclones_parser.add_argument('args', nargs='*',
                                 help='[optional: initialization time (YYYYMMDDHH, YYYY-MM-DDTHH, or YYYY-MM-DDTHH:mm:ss)] output_file')

    # Population Weighted HDD Command
    hdd_parser = subparsers.add_parser('hdds', help='Get forecasted population-weighted heating degree days (HDDs)')
    hdd_parser.add_argument('initialization_time', help='Initialization time (YYYYMMDDHH, YYYY-MM-DDTHH, or YYYY-MM-DDTHH:mm:ss)')
    hdd_parser.add_argument('-e', '--ens-member', help='Ensemble member (eg 1 or mean)')
    hdd_parser.add_argument('-m', '--model', default='wm', help='Forecast model (e.g., wm, wm4, wm-4.5-ens, ecmwf-det)')
    hdd_parser.add_argument('-o', '--output', help='Output file (supports .csv and .json formats)')

    # Population Weighted CDD Command
    cdd_parser = subparsers.add_parser('cdds', help='Get forecasted population-weighted cooling degree days (CDDs)')
    cdd_parser.add_argument('initialization_time', help='Initialization time (YYYYMMDDHH, YYYY-MM-DDTHH, or YYYY-MM-DDTHH:mm:ss)')
    cdd_parser.add_argument('-e', '--ens-member', help='Ensemble member (eg 1 or mean)')
    cdd_parser.add_argument('-m', '--model', default='wm', help='Forecast model (e.g., wm, wm4, wm-4.5-ens, ecmwf-det)')
    cdd_parser.add_argument('-o', '--output', help='Output file (supports .csv and .json formats)')

    # Calculation Times Command (with subcommand for degree_days)
    calculation_times_parser = subparsers.add_parser('calculation_times', help='Get available calculation times')
    calculation_times_subparsers = calculation_times_parser.add_subparsers(dest='calculation_times_type', help='Calculation type')
    degree_days_parser = calculation_times_subparsers.add_parser('degree_days', help='Get available calculation times for degree days forecasts')
    degree_days_parser.add_argument('-e', '--ens-member', help='Ensemble member (eg 1 or mean)')
    degree_days_parser.add_argument('-m', '--model', default='wm', help='Forecast model (e.g., wm, wm4, wm-4.5-ens, ecmwf-det)')

    # Initialization Times Command
    initialization_times_parser = subparsers.add_parser('init_times', help='Get available initialization times for point forecasts')
    initialization_times_parser.add_argument('-e', '--ens-member', help='Ensemble member (eg 1 or mean)')
    initialization_times_parser.add_argument('-m', '--model', default='wm', help='Forecast model (e.g., wm, wm4, wm-4.5-ens, ecmwf-det)')

    # Archived Initialization Times Command
    archived_initialization_times_parser = subparsers.add_parser('archived_init_times', help='Get available archived initialization times')
    archived_initialization_times_parser.add_argument('-e', '--ens-member', help='Ensemble member (eg 1 or mean)')
    archived_initialization_times_parser.add_argument('-m', '--model', default='wm', help='Forecast model (e.g., wm, wm4, wm-4.5-ens, ecmwf-det)')
    archived_initialization_times_parser.add_argument('-p', '--page-end', help='End of page window (ISO 8601). Lists times back 7 days.')

    # Run Information Command
    run_information_parser = subparsers.add_parser('run_information', help='Get run information for a model run')
    run_information_parser.add_argument('initialization_time', help='Initialization time (ISO 8601)')
    run_information_parser.add_argument('-e', '--ens-member', help='Ensemble member (eg 1 or mean)')
    run_information_parser.add_argument('-m', '--model', default='wm', help='Forecast model (e.g., wm, wm4, wm-4.5-ens, ecmwf-det)')

    # Variables Command
    variables_parser = subparsers.add_parser('variables', help='Get available variables for a model')
    variables_parser.add_argument('-m', '--model', default='wm', help='Forecast model (e.g., wm, wm4, wm-4.5-ens, ecmwf-det)')

    ####################################################################################################################
    # ANALYSIS API FUNCTIONS
    ####################################################################################################################

    # Analysis Available Times Command
    analysis_times_parser = subparsers.add_parser('analysis_available_times', help='Get available analysis times for a source')
    analysis_times_parser.add_argument('-s', '--source', default='ecmwf_det_anl', help='Analysis source (ecmwf_det_anl, ecmwf_ens_anl, era5)')

    # Analysis Variables Command
    analysis_variables_parser = subparsers.add_parser('analysis_variables', help='Get available variables for an analysis source')
    analysis_variables_parser.add_argument('-s', '--source', default='ecmwf_det_anl', help='Analysis source (ecmwf_det_anl, ecmwf_ens_anl, era5)')

    # Analysis Interpolated Command
    analysis_interpolated_parser = subparsers.add_parser('analysis_interpolated', help='Get analysis data interpolated to specific coordinates')
    analysis_interpolated_parser.add_argument('coordinates', help='Coordinate pairs in format "latitudeA,longitudeA; latitudeB,longitudeB"')
    analysis_interpolated_parser.add_argument('time', help='Time to retrieve data for (ISO 8601)')
    analysis_interpolated_parser.add_argument('-s', '--source', default='ecmwf_det_anl', help='Analysis source (ecmwf_det_anl, ecmwf_ens_anl, era5)')
    analysis_interpolated_parser.add_argument('output_file', nargs='?', help='Output file (.csv or .json)')

    # Analysis Gridded Command
    analysis_gridded_parser = subparsers.add_parser('analysis_gridded', help='Get gridded analysis data for a variable')
    analysis_gridded_parser.add_argument('variable', help='Variable to download (e.g., temperature_2m)')
    analysis_gridded_parser.add_argument('time', help='Time to retrieve data for (ISO 8601)')
    analysis_gridded_parser.add_argument('output_file', help='Output file path')
    analysis_gridded_parser.add_argument('-s', '--source', default='ecmwf_det_anl', help='Analysis source (ecmwf_det_anl, ecmwf_ens_anl, era5)')
    analysis_gridded_parser.add_argument('-f', '--format', help='Output format (zarr or netcdf)')

    args = parser.parse_args()

    ####################################################################################################################
    # DATA API FUNCTIONS CALLED
    ####################################################################################################################
    if args.command == 'super_observations':
        # Error handling is performed within super_observations
        # and we display the appropriate error messages
        # No need to implement them here

        # In case user wants to save all poll observation data in a single file | filename.format
        if '.' in args.output:
            output_file = args.output
            output_format = None
            output_dir = None
        # In case user wants separate file for each data from missions (buckets)
        else:
            output_file = None
            output_format = args.output
            output_dir = args.output_dir

        get_super_observations(
            start_time=args.start_time,
            end_time=args.end_time,
            output_file=output_file,
            mission_id=args.mission_id,
            min_latitude=args.min_latitude,
            max_latitude=args.max_latitude,
            min_longitude=args.min_longitude,
            max_longitude=args.max_longitude,
            bucket_hours=args.bucket_hours,
            output_dir=output_dir,
            output_format=output_format
        )

    elif args.command == 'poll_super_observations':
        output_format = args.output
        output_dir = args.output_dir

        poll_super_observations(
            start_time=args.start_time,
            mission_id=args.mission_id,
            bucket_hours=args.bucket_hours,
            output_dir=output_dir,
            output_format=output_format
        )

    elif args.command == 'poll_observations':
        output_format = args.output
        output_dir = args.output_dir

        poll_observations(
            start_time=args.start_time,
            include_updated_at=args.include_updated_at,
            mission_id=args.mission_id,
            min_latitude=args.min_latitude,
            max_latitude=args.max_latitude,
            min_longitude=args.min_longitude,
            max_longitude=args.max_longitude,
            bucket_hours=args.bucket_hours,
            output_dir=output_dir,
            output_format=output_format
        )

    elif args.command == 'observations':
        # Error handling is performed within observations
        # and we display the appropriate error messages
        # No need to implement them here

        # In case user wants to save all poll observation data in a single file | filename.format
        if '.' in args.output:
            output_file = args.output
            output_format = None
            output_dir = None
        # In case user wants separate file for each data from missions (buckets)
        else:
            output_file = None
            output_format = args.output
            output_dir = args.output_dir

        get_observations(
            start_time=args.start_time,
            end_time=args.end_time,
            include_updated_at=args.include_updated_at,
            mission_id=args.mission_id,
            min_latitude=args.min_latitude,
            max_latitude=args.max_latitude,
            min_longitude=args.min_longitude,
            max_longitude=args.max_longitude,
            output_file=output_file,
            bucket_hours=args.bucket_hours,
            output_dir=output_dir,
            output_format=output_format
        )

    elif args.command == 'observations_page':
        if not args.output:
            print(json.dumps(get_observations_page(
                since=args.since,
                min_time=args.min_time,
                max_time=args.max_time,
                include_ids=args.include_ids,
                include_mission_name=args.include_mission_name,
                include_updated_at=args.include_updated_at,
                mission_id=args.mission_id,
                min_latitude=args.min_latitude,
                max_latitude=args.max_latitude,
                min_longitude=args.min_longitude,
                max_longitude=args.max_longitude
            ), indent=4))
        else:
            get_observations_page(
                since=args.since,
                min_time=args.min_time,
                max_time=args.max_time,
                include_ids=args.include_ids,
                include_mission_name=args.include_mission_name,
                include_updated_at=args.include_updated_at,
                mission_id=args.mission_id,
                min_latitude=args.min_latitude,
                max_latitude=args.max_latitude,
                min_longitude=args.min_longitude,
                max_longitude=args.max_longitude,
                output_file=args.output
            )

    elif args.command == 'super_observations_page':
        if not args.output:
            print(json.dumps(get_super_observations_page(
                since=args.since,
                min_time=args.min_time,
                max_time=args.max_time,
                include_ids=args.include_ids,
                include_mission_name=args.include_mission_name,
                include_updated_at=args.include_updated_at,
                mission_id=args.mission_id,
                min_latitude=args.min_latitude,
                max_latitude=args.max_latitude,
                min_longitude=args.min_longitude,
                max_longitude=args.max_longitude
            ), indent=4))
        else:
            get_super_observations_page(
                since=args.since,
                min_time=args.min_time,
                max_time=args.max_time,
                include_ids=args.include_ids,
                include_mission_name=args.include_mission_name,
                include_updated_at=args.include_updated_at,
                mission_id=args.mission_id,
                min_latitude=args.min_latitude,
                max_latitude=args.max_latitude,
                min_longitude=args.min_longitude,
                max_longitude=args.max_longitude,
                output_file=args.output
            )

    elif args.command == 'flying_missions':
        get_flying_missions(output_file=args.output, print_results=(not args.output))

    elif args.command == 'launch_site':
        get_mission_launch_site(
            mission_id=args.mission_id,
            output_file=args.output,
            print_result=(not args.output)
        )
    elif args.command == 'current_location':
        get_current_location(
            mission_id=args.mission_id,
            output_file=args.output,
            print_result=(not args.output)
        )
    elif args.command == 'predict_path':
        get_predicted_path(
            mission_id=args.mission_id,
            output_file=args.output,
            print_result=(not args.output)
        )

    elif args.command == 'flight_path':
        get_flight_path(
            mission_id=args.mission_id,
            output_file=args.output,
            print_result=(not args.output)
        )
    elif args.command == 'constellation_status':
        get_constellation_status(
            output_file=args.output,
            print_results=(not args.output)
        )

    elif args.command == 'soundings':
        get_soundings(
            mission_id=args.mission_id,
            min_time=args.min_time,
            max_time=args.max_time,
            min_altitude=args.min_altitude,
            max_altitude=args.max_altitude,
            min_latitude=args.min_lat,
            max_latitude=args.max_lat,
            min_longitude=args.min_lon,
            max_longitude=args.max_lon,
            page=args.page,
            page_size=args.page_size,
            output_file=args.output,
            print_results=(not args.output)
        )

    elif args.command == 'sounding':
        get_sounding(
            sounding_id=args.sounding_id,
            output_file=args.output,
            print_result=(not args.output)
        )

    ####################################################################################################################
    # FORECASTS API FUNCTIONS CALLED
    ####################################################################################################################
    elif args.command == 'points':
        min_forecast_time = args.min_time if args.min_time else None
        max_forecast_time = args.max_time if args.max_time else None
        min_forecast_hour = args.min_hour if args.min_hour else None
        max_forecast_hour = args.max_hour if args.max_hour else None
        initialization_time = args.init_time if args.init_time else None

        get_point_forecasts(
            coordinates=args.coordinates,
            min_forecast_time=min_forecast_time,
            max_forecast_time=max_forecast_time,
            min_forecast_hour=min_forecast_hour,
            max_forecast_hour=max_forecast_hour,
            initialization_time=initialization_time,
            output_file=args.output_file,
            model=args.model,
            print_response=(not args.output_file)
        )

    elif args.command == 'points_interpolated':
        min_forecast_time = args.min_time if args.min_time else None
        max_forecast_time = args.max_time if args.max_time else None
        min_forecast_hour = args.min_hour if args.min_hour else None
        max_forecast_hour = args.max_hour if args.max_hour else None
        initialization_time = args.init_time if args.init_time else None

        get_point_forecasts_interpolated(
            coordinates=args.coordinates,
            min_forecast_time=min_forecast_time,
            max_forecast_time=max_forecast_time,
            min_forecast_hour=min_forecast_hour,
            max_forecast_hour=max_forecast_hour,
            initialization_time=initialization_time,
            ens_member=getattr(args, 'ens_member', None),
            output_file=args.output_file,
            model=args.model,
            print_response=(not args.output_file)
        )

    elif args.command == 'available_stations':
        get_available_stations(
            output_file=args.output_file,
            model=args.model,
            print_response=(not args.output_file)
        )

    elif args.command == 'station_forecast':
        get_station_forecast(
            station_id=args.station_id,
            initialization_time=args.init_time,
            output_file=args.output_file,
            model=args.model,
            print_response=(not args.output_file)
        )

    elif args.command == 'interpolated_sounding':
        get_interpolated_sounding(
            coordinates=args.coordinates,
            time=args.time,
            initialization_time=args.init_time,
            forecast_hour=args.forecast_hour,
            output_file=args.output_file,
            model=args.model,
            print_response=(not args.output_file)
        )

    elif args.command == 'init_times':
        get_initialization_times(print_response=True, ens_member=args.ens_member, model=args.model)

    elif args.command == 'archived_init_times':
        get_archived_initialization_times(print_response=True, ens_member=args.ens_member, model=args.model, page_end=getattr(args, 'page_end', None))

    elif args.command == 'run_information':
        get_run_information(initialization_time=args.initialization_time, ens_member=getattr(args, 'ens_member', None), model=args.model, print_response=True)

    elif args.command == 'variables':
        get_variables(print_response=True, model=args.model)

    elif args.command == 'gridded':
        if len(args.args) in [0,1,2]:
            print(f"To get the gridded forecast for a variable you need to provide the variable, time (or initialization time and forecast hour), and an output file.")
            print(f"\nUsage: windborne gridded variable time output_file or")
            print(f"\n       windborne gridded variable initialization_time forecast_hour output_file")
            print(f"\n       windborne gridded variable level time output_file")
            print(f"\n       windborne gridded variable level initialization_time forecast_hour output_file")
        elif len(args.args) == 3:
            get_gridded_forecast(variable=args.args[0], time=args.args[1], output_file=args.args[2], ens_member=args.ens_member, model=args.model)
        elif len(args.args) == 4:
            # Support both historical form: variable initialization_time forecast_hour output
            # and alternate "variable level time output" form by detecting numeric level
            a0, a1, a2, a3 = args.args
            is_level = False
            try:
                # Simple numeric check; levels are integers like 500, 850, 1000
                int(a1)
                is_level = True
            except Exception:
                is_level = False

            # Basic heuristic to detect time-like strings for a2
            def looks_like_time(s: str) -> bool:
                return (
                    (len(s) == 10 and s.isdigit()) or  # YYYYMMDDHH
                    ('T' in s and '-' in s)            # ISO-like
                )

            if is_level and looks_like_time(a2):
                # Map to level/variable with time
                get_gridded_forecast(variable=f"{a1}/{a0}", time=a2, output_file=a3, ens_member=args.ens_member, model=args.model)
            else:
                get_gridded_forecast(variable=a0, initialization_time=a1, forecast_hour=a2, output_file=a3, ens_member=args.ens_member, model=args.model)
        elif len(args.args) == 5:
            # Support historical variable level syntax:
            #   windborne gridded variable level initialization_time forecast_hour output_file
            a0, a1, a2, a3, a4 = args.args
            try:
                int(a1)
                # Treat a1 as level
                get_gridded_forecast(variable=f"{a1}/{a0}", initialization_time=a2, forecast_hour=a3, output_file=a4, ens_member=args.ens_member, model=args.model)
            except Exception:
                # Fallback: treat like variable initialization_time forecast_hour output_file (ignore a1)
                get_gridded_forecast(variable=a0, initialization_time=a2, forecast_hour=a3, output_file=a4, ens_member=args.ens_member, model=args.model)
        else:
            print("Too many arguments")

    elif args.command == 'tropical_cyclones':
        # Parse cyclones arguments
        basin_name = 'all basins'
        if args.basin:
            basin_name = f"{args.basin} basin"

        if len(args.args) == 0:
            get_tropical_cyclones(basin=args.basin, print_response=True, model=args.model)
            return
        elif len(args.args) == 1:
            if '.' in args.args[0]:
                # Save tcs with the latest available initialization time in filename
                get_tropical_cyclones(basin=args.basin, output_file=args.args[0], model=args.model)
            else:
                # Display tcs for selected initialization time
                get_tropical_cyclones(initialization_time=args.args[0], basin=args.basin, print_response=True, model=args.model)
        elif len(args.args) == 2:
            print(f"Saving tropical cyclones for initialization time {args.args[0]} and {basin_name}\n")
            get_tropical_cyclones(initialization_time=args.args[0], basin=args.basin, output_file=args.args[1], model=args.model)
        else:
            print("Error: Too many arguments")
            print("Usage: windborne tropical_cyclones [initialization_time] output_file")

    elif args.command == 'hdds':
        # Handle population weighted HDD
        get_population_weighted_hdds(
            initialization_time=args.initialization_time,
            ens_member=args.ens_member,
            output_file=args.output,
            model=args.model,
            print_response=(not args.output)
        )

    elif args.command == 'cdds':
        # Handle population weighted CDD
        get_population_weighted_cdds(
            initialization_time=args.initialization_time,
            ens_member=args.ens_member,
            output_file=args.output,
            model=args.model,
            print_response=(not args.output)
        )
    
    elif args.command == 'calculation_times':
        if args.calculation_times_type == 'degree_days':
            get_calculation_times_degree_days(
                ens_member=args.ens_member,
                model=args.model,
                print_response=True
            )
        else:
            calculation_times_parser.print_help()

    ####################################################################################################################
    # ANALYSIS API FUNCTIONS CALLED
    ####################################################################################################################
    elif args.command == 'analysis_available_times':
        get_analysis_available_times(source=args.source, print_response=True)

    elif args.command == 'analysis_variables':
        get_analysis_variables(source=args.source, print_response=True)

    elif args.command == 'analysis_interpolated':
        get_interpolated_analysis(
            source=args.source,
            coordinates=args.coordinates,
            time=args.time,
            output_file=args.output_file,
            print_response=(not args.output_file)
        )

    elif args.command == 'analysis_gridded':
        get_gridded_analysis(
            source=args.source,
            variable=args.variable,
            time=args.time,
            output_file=args.output_file,
            output_format=args.format
        )

    else:
        parser.print_help()

if __name__ == '__main__':
    main()
