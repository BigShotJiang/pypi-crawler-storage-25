"""
Tekcesta AI Platform

Purpose-built AI appliances for regulated industries.
"""

__version__ = "0.1.0"
__author__ = "Tekcesta"
__email__ = "contact@tekcesta.com"
__license__ = "Apache-2.0"

class TekcestaError(Exception):
    """Base exception for Tekcesta platform."""
    pass

def hello() -> str:
    """
    Simple greeting function.
    
    Returns:
        A welcome message from Tekcesta.
    """
    return "Welcome to Tekcesta AI Platform - Privacy-first AI for regulated industries."

__all__ = ["TekcestaError", "hello"]
