#!/bin/bash
# TEKcesta PyPI Upload Script
# Run this to upload the stub package to PyPI and reserve the name

set -e

echo "🔧 TEKcesta PyPI Package Upload"
echo "================================"

# Check for required tools
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 not found"
    exit 1
fi

if ! command -v twine &> /dev/null; then
    echo "⚠️  twine not found, installing..."
    python3 -m pip install --user twine
fi

# Create virtual environment
echo "📦 Setting up virtual environment..."
python3 -m venv venv
source venv/bin/activate

# Install build tools
echo "🔨 Installing build tools..."
pip install --upgrade pip build twine

# Build the package
echo "🏗️  Building package..."
python -m build

# Upload to PyPI
echo "🚀 Uploading to PyPI..."
echo ""
echo "⚠️  IMPORTANT: You need PyPI credentials!"
echo "   - If you don't have an account: https://pypi.org/account/register/"
echo "   - Username should be: __token__"
echo "   - Password should be your API token from: https://pypi.org/manage/account/token/"
echo ""
echo "📦 Files to upload:"
ls -la dist/

echo ""
echo "📤 To upload, run:"
echo "   twine upload dist/*"
echo ""
echo "🔐 Or with explicit credentials:"
echo "   twine upload --username __token__ --password YOUR_API_TOKEN dist/*"
echo ""
echo "✅ Done! Package is ready for upload."

# Clean up
deactivate
echo ""
echo "📝 Next steps:"
echo "   1. Create PyPI account if needed"
echo "   2. Generate API token at https://pypi.org/manage/account/token/"
echo "   3. Run: twine upload --username __token__ --password YOUR_TOKEN dist/*"
echo "   4. Verify at: https://pypi.org/project/tekcesta/"