#!/usr/bin/env python3
"""Run continuous endpoint meta-analysis from Excel through R meta::metacont.

This script mirrors the binary outcome runner: Python handles workbook loading,
LMStudio-assisted column mapping, user confirmation, output organization, plot
cropping, and manuscript-summary generation; R performs the meta-analysis.
"""

from __future__ import annotations

import argparse
import json
import math
import re
import shutil
import sys
import tempfile
import textwrap
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any

import pandas as pd

import binary_outcome as common
from tsa_inference import continuous_tsa_r_code, run_continuous_tsa_analysis


REQUIRED_FIELDS = ["study_label", "n_e", "n_c"]
MEAN_SD_FIELDS = ["mean_e", "sd_e", "mean_c", "sd_c"]
MEDIAN_FIELDS = [
    "median_e",
    "q1_e",
    "q3_e",
    "min_e",
    "max_e",
    "median_c",
    "q1_c",
    "q3_c",
    "min_c",
    "max_c",
]
OPTIONAL_FIELDS = ["covariate"]
R_COLUMNS = [
    "Author",
    "mean.e",
    "sd.e",
    "median.e",
    "q1.e",
    "q3.e",
    "min.e",
    "max.e",
    "n.e",
    "mean.c",
    "sd.c",
    "median.c",
    "q1.c",
    "q3.c",
    "min.c",
    "max.c",
    "n.c",
]
SUMMARY_MEASURES = {
    "MD": "Mean Difference",
    "SMD": "Standardized Mean Difference",
}
FIELD_LABELS = {
    "study_label": "Study label / Author",
    "mean_e": "Intervention mean",
    "sd_e": "Intervention SD",
    "median_e": "Intervention median",
    "q1_e": "Intervention Q1",
    "q3_e": "Intervention Q3",
    "min_e": "Intervention minimum",
    "max_e": "Intervention maximum",
    "n_e": "Intervention total",
    "mean_c": "Control mean",
    "sd_c": "Control SD",
    "median_c": "Control median",
    "q1_c": "Control Q1",
    "q3_c": "Control Q3",
    "min_c": "Control minimum",
    "max_c": "Control maximum",
    "n_c": "Control total",
    "subgroups": "Subgroup columns",
    "covariate": "Meta-regression covariate",
    "covariates": "Meta-regression covariates",
}
PY_TO_R = {
    "mean_e": "mean.e",
    "sd_e": "sd.e",
    "median_e": "median.e",
    "q1_e": "q1.e",
    "q3_e": "q3.e",
    "min_e": "min.e",
    "max_e": "max.e",
    "n_e": "n.e",
    "mean_c": "mean.c",
    "sd_c": "sd.c",
    "median_c": "median.c",
    "q1_c": "q1.c",
    "q3_c": "q3.c",
    "min_c": "min.c",
    "max_c": "max.c",
    "n_c": "n.c",
}


def infer_covariate_columns(columns: list[str], mapping: dict[str, Any]) -> list[str]:
    selected = set(mapping.get("columns", {}).values())
    selected.update(mapping.get("subgroup_columns") or [])
    covariates: list[str] = []
    legacy = mapping.get("columns", {}).get("covariate")
    if legacy in columns:
        covariates.append(legacy)
    covariate_terms = (
        "covariate",
        "moderator",
        "regressor",
        "metareg",
        "metaregression",
        "age",
        "bmi",
        "year",
        "followup",
        "followupmonths",
        "duration",
        "samplesize",
        "sample",
        "male",
        "female",
        "percent",
        "proportion",
    )
    excluded_terms = (
        "mean",
        "median",
        "sd",
        "q1",
        "q3",
        "min",
        "max",
        "total",
        "subgroup",
        "group",
        "study",
        "author",
    )
    for col in columns:
        norm = common.normalize_name(col)
        is_regressor = "regressor" in norm
        if (col in selected and not is_regressor) or col in covariates:
            continue
        explicit_moderator = any(term in norm for term in ("age", "bmi", "followup", "year", "male", "female", "percent", "regressor"))
        if is_regressor or (any(term in norm for term in covariate_terms) and (explicit_moderator or not any(term in norm for term in excluded_terms))):
            covariates.append(col)
    return covariates


def default_mapping(columns: list[str]) -> dict[str, Any]:
    normalized = {common.normalize_name(col): col for col in columns}
    exact = {
        "study_label": ["author", "firstauthor", "study", "studlab", "studyid", "trial"],
        "mean_e": ["meane", "interventionmean", "experimentalmean", "treatmentmean", "eusgjmean"],
        "sd_e": ["sde", "interventionsd", "experimentalsd", "treatmentsd", "eusgjsd"],
        "median_e": ["mediane", "interventionmedian", "experimentalmedian", "treatmentmedian"],
        "q1_e": ["q1e", "interventionq1", "experimentalq1", "treatmentq1"],
        "q3_e": ["q3e", "interventionq3", "experimentalq3", "treatmentq3"],
        "min_e": ["mine", "interventionmin", "experimentalmin", "treatmentmin"],
        "max_e": ["maxe", "interventionmax", "experimentalmax", "treatmentmax"],
        "n_e": ["ne", "nintervention", "nexperimental", "interventiontotal", "experimentaltotal", "treatmenttotal", "eusgjtotal", "eusgjn"],
        "mean_c": ["meanc", "controlmean", "comparatormean", "placebomean", "noneusgjmean"],
        "sd_c": ["sdc", "controlsd", "comparatorsd", "placebosd", "noneusgjsd"],
        "median_c": ["medianc", "controlmedian", "comparatormedian", "placebomedian"],
        "q1_c": ["q1c", "controlq1", "comparatorq1", "placeboq1"],
        "q3_c": ["q3c", "controlq3", "comparatorq3", "placeboq3"],
        "min_c": ["minc", "controlmin", "comparatormin", "placebomin"],
        "max_c": ["maxc", "controlmax", "comparatormax", "placebomax"],
        "n_c": ["nc", "ncontrol", "controltotal", "comparatorn", "placebototal", "noneusgjtotal", "noneusgjn"],
        "covariate": ["covariate", "moderator", "followup", "followupmonths"],
    }
    mapping: dict[str, Any] = {
        "sheet_name": None,
        "outcome_name": "continuous outcome",
        "intervention_label": "Experimental",
        "control_label": "Control",
        "columns": {},
        "subgroup_columns": [],
        "covariate_columns": [],
        "analysis": {
            "summary_measure": "MD",
            "summary_measure_reason": "Mean Difference is the default when studies use the same outcome scale.",
            "data_format": "mean_sd",
            "data_format_reason": "Mean and SD columns are expected for continuous outcomes.",
            "median_handling": "not_used",
            "median_handling_reason": "No median/IQR conversion was detected.",
            "model_type": "random",
            "model_type_reason": "Random-effects is the default for clinical meta-analysis when between-study heterogeneity is possible.",
            "analysis_engine": "frequentist",
            "analysis_engine_reason": "Frequentist random-effects meta-analysis is the default for conventional reporting; Bayesian synthesis can be selected when posterior estimates are desired.",
            "outcome_direction": "lower_better",
            "favor_left": "Experimental",
            "favor_right": "Control",
            "favor_label_reason": "For continuous MD/SMD, values left of zero mean the intervention has lower values than control.",
            "tsa_alpha": 0.05,
            "tsa_power": 0.80,
            "tsa_adjust_for_diversity": False,
            "tsa_effect_source": "observed",
            "tsa_anticipated_effect": None,
            "tsa_required_information_size": None,
            "tsa_reason": "Trial sequential analysis uses two-sided alpha 0.05, 80% power, the observed pooled effect, and the selected heterogeneity adjustment for required information size (tau2 unless D2 diversity adjustment is selected).",
        },
        "confidence": 0.0,
        "notes": "Heuristic mapping; confirm before running.",
    }
    for field, candidates in exact.items():
        for candidate in candidates:
            if candidate in normalized:
                mapping["columns"][field] = normalized[candidate]
                break
    mapping["intervention_label"] = common.infer_arm_label_from_column(
        mapping["columns"].get("mean_e") or mapping["columns"].get("n_e"),
        mapping["intervention_label"],
    )
    mapping["control_label"] = common.infer_arm_label_from_column(
        mapping["columns"].get("mean_c") or mapping["columns"].get("n_c"),
        mapping["control_label"],
    )
    mapping["analysis"]["favor_left"] = mapping["intervention_label"]
    mapping["analysis"]["favor_right"] = mapping["control_label"]
    for col in columns:
        norm = common.normalize_name(col)
        if any(token in norm for token in ("subgroup", "group", "strata", "category", "region", "drug")):
            mapping["columns"].setdefault("subgroup", col)
            if col not in mapping["subgroup_columns"]:
                mapping["subgroup_columns"].append(col)
    mapping["covariate_columns"] = infer_covariate_columns(columns, mapping)
    if mapping["covariate_columns"]:
        mapping["columns"]["covariate"] = mapping["covariate_columns"][0]
    return mapping


def call_lmstudio(summary: dict[str, Any], lmstudio_url: str, model: str | None) -> dict[str, Any] | None:
    model = common.resolve_lmstudio_model(lmstudio_url, model)
    if not model:
        return None

    prompt = {
        "task": (
            "Identify columns for a continuous endpoint meta-analysis using R meta::metacont. "
            "The sheet may contain mean ± SD data, median/IQR/range data, or a mixture."
        ),
        "required_columns": {
            "study_label": "study name, author, or trial label",
            "n_e": "total participants in intervention/experimental group",
            "n_c": "total participants in control/comparator group",
        },
        "mean_sd_columns": {
            "mean_e": "mean in intervention group",
            "sd_e": "standard deviation in intervention group",
            "mean_c": "mean in control group",
            "sd_c": "standard deviation in control group",
        },
        "median_iqr_columns": {
            "median_e": "median in intervention group",
            "q1_e": "first quartile in intervention group",
            "q3_e": "third quartile in intervention group",
            "min_e": "minimum in intervention group",
            "max_e": "maximum in intervention group",
            "median_c": "median in control group",
            "q1_c": "first quartile in control group",
            "q3_c": "third quartile in control group",
            "min_c": "minimum in control group",
            "max_c": "maximum in control group",
        },
        "optional_columns": {
            "subgroup_columns": "all clinically meaningful categorical subgroup columns",
            "covariate_columns": "all study-level moderator/regressor columns for meta-regression if present; include numeric moderators and categorical text moderators such as etiology, control type, region, or study design",
            "covariate": "legacy single numeric covariate for meta-regression if present",
        },
        "analysis_choices": {
            "summary_measure": "Choose MD if all studies use the same scale/units; choose SMD if scales differ.",
            "data_format": "mean_sd, median_iqr, or mixed",
            "median_handling": "not_used, estimate_mean_sd_from_median_iqr, or mixed_reported_and_estimated",
            "model_type": "random or common/fixed",
            "analysis_engine": "frequentist, bayesian, or both",
            "outcome_direction": "lower_better or higher_better",
            "favor_left": "group favored when effect is below zero",
            "favor_right": "group favored when effect is above zero",
            "tsa_alpha": "Two-sided type I error for trial sequential analysis; default 0.05.",
            "tsa_power": "Power for required information size; default 0.80.",
            "tsa_adjust_for_diversity": "Whether to inflate RIS for heterogeneity/diversity; default true.",
            "tsa_effect_source": "observed unless a protocol-specified clinically important effect is obvious.",
            "tsa_anticipated_effect": "Optional numeric anticipated MD/SMD; null if using observed pooled effect.",
            "tsa_required_information_size": "Optional numeric RIS/DARIS override from a protocol or TSA software; null to calculate it.",
            "tsa_favor_top": "Which group/outcome side is favored above zero on the TSA cumulative Z-score plot; should match favor_right for the unflipped Z = TE/SE convention.",
            "tsa_favor_bottom": "Which group/outcome side is favored below zero on the TSA cumulative Z-score plot; should match favor_left for the unflipped Z = TE/SE convention.",
        },
        "workbook": summary,
        "rules": [
            "Return exact column names as they appear in the workbook.",
            "Do not invent columns.",
            "Set intervention_label and control_label from the actual arm prefixes in the selected columns rather than generic labels; for example EUS-GJ Mean vs NON EUS-GJ Mean should yield intervention_label EUS-GJ and control_label NON EUS-GJ.",
            "Use MD if studies measure the same outcome on the same scale/unit.",
            "Use SMD if studies measure the same concept using different scales/instruments and cannot be converted to one scale.",
            "If SMD is selected, note that all scales must point in the same direction.",
            "TSA rule from the TSA guide: continuous TSA software supports mean difference; do not run TSA for SMD outcomes.",
            "If medians/IQRs/ranges are present and means/SDs are missing, choose median_iqr and estimate_mean_sd_from_median_iqr.",
            "Median/IQR transformation should be flagged for author review because skewness/normality assumptions matter.",
            "Random-effects is preferred when clinical or methodological heterogeneity is plausible; common/fixed-effect only if one common true effect is defensible.",
            "Analysis engine rule from Cochrane-style practice: frequentist remains the conventional primary output for routine meta-analysis with adequate data.",
            "Analysis engine rule from Cochrane Bayesian guidance: Bayesian meta-analysis combines the likelihood with prior information and reports posterior credible intervals; it is especially useful as a supplement when study counts are small, sample sizes are small, uncertainty about heterogeneity is important, or posterior summaries would improve interpretation.",
            "Analysis engine rule: choose both, rather than frequentist alone, when Bayesian credible intervals would be useful but conventional Cochrane-style confidence intervals and heterogeneity statistics should still be reported.",
            "Analysis engine rule: do not give a generic reason such as 'standard guideline-style meta-analysis requested'; cite concrete data features such as study count, median sample size, or lack of small-study triggers.",
            "Return all plausible meta-regression candidates in covariate_columns, including numeric moderators such as mean age, BMI, publication year, follow-up duration, percent male, sample size, and categorical text moderators such as etiology, control type, region, or study design.",
            "Any column whose name contains 'regressor' should be considered for meta-regression and included in covariate_columns when it is numeric, numeric-coded, or categorical text; it may also appear in subgroup_columns if it represents a categorical subgroup.",
            "Do not map the sheet's dependent outcome itself as a covariate. If the sheet name is Age, BMI, follow-up, length of stay, or another continuous endpoint, treat that as the outcome unless a separate numeric moderator column is present.",
            "Categorical moderators should be subgroup_columns and may also be covariate_columns when categorical meta-regression is desired.",
            "For MD/SMD, values below zero mean intervention values are lower than control values.",
            "If lower values are better, left of zero favors intervention and right favors control.",
            "If higher values are better, left of zero favors control and right favors intervention.",
            "TSA labeling rule: the plotted Z-curve uses Z = TE / SE, where TE is intervention minus control. Positive Z means the intervention value is higher than control, so the top TSA label must match the right side of the forest plot. Negative Z means the intervention value is lower than control, so the bottom TSA label must match the left side of the forest plot.",
            "TSA rule: use a two-sided alpha of 0.05 and 80% power unless the workbook or protocol indicates otherwise.",
            "TSA rule: use diversity-adjusted required information size when heterogeneity is plausible.",
            "TSA rule: use the observed pooled MD as the anticipated effect unless there is a clear protocol-specified clinically important effect.",
        ],
        "return_json_schema": {
            "sheet_name": "string",
            "outcome_name": "string",
            "intervention_label": "string",
            "control_label": "string",
            "columns": {field: "string or null" for field in REQUIRED_FIELDS + MEAN_SD_FIELDS + MEDIAN_FIELDS + OPTIONAL_FIELDS},
            "subgroup_columns": ["string"],
            "covariate_columns": ["string"],
            "analysis": {
                "summary_measure": "MD or SMD",
                "summary_measure_reason": "short string",
                "data_format": "mean_sd, median_iqr, or mixed",
                "data_format_reason": "short string",
                "median_handling": "not_used, estimate_mean_sd_from_median_iqr, or mixed_reported_and_estimated",
                "median_handling_reason": "short string",
                "model_type": "random or common",
                "model_type_reason": "short string",
                "analysis_engine": "frequentist, bayesian, or both",
                "analysis_engine_reason": "short string",
                "outcome_direction": "lower_better or higher_better",
                "favor_left": "intervention/control label",
                "favor_right": "intervention/control label",
                "favor_label_reason": "short string",
                "tsa_alpha": "number, usually 0.05",
                "tsa_power": "number, usually 0.80 or 0.90",
                "tsa_adjust_for_diversity": "boolean",
                "tsa_effect_source": "observed or clinically_important",
                "tsa_anticipated_effect": "number or null; anticipated MD/SMD when clinically_important",
                "tsa_required_information_size": "number or null; protocol/TSA software RIS override",
                "tsa_favor_top": "intervention/control label shown above zero",
                "tsa_favor_bottom": "intervention/control label shown below zero",
                "tsa_reason": "short string",
            },
            "confidence": "number from 0 to 1",
            "notes": "short string",
        },
    }
    body = {
        "model": model,
        "messages": [
            {
                "role": "system",
                "content": "You map clinical continuous-outcome Excel columns to a strict meta-analysis schema. Return only valid JSON.",
            },
            {"role": "user", "content": json.dumps(prompt, default=str)},
        ],
        "temperature": 0,
    }
    request = urllib.request.Request(
        common.chat_completions_url(lmstudio_url),
        data=json.dumps(body).encode("utf-8"),
        headers=common.llm_request_headers(include_content_type=True),
        method="POST",
    )
    try:
        with urllib.request.urlopen(request) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        print(f"LMStudio request failed ({common.lmstudio_error_message(exc)}). Falling back to name matching.")
        return None
    except Exception as exc:
        print(f"LMStudio request failed ({exc}). Falling back to name matching.")
        return None
    content = payload["choices"][0]["message"]["content"]
    try:
        return json.loads(content)
    except json.JSONDecodeError:
        match = re.search(r"\{.*\}", content, flags=re.S)
        if match:
            return json.loads(match.group(0))
        print("LMStudio did not return valid JSON. Falling back to name matching.")
        return None


def normalize_favor_group(value: str, mapping: dict[str, Any], fallback: str) -> str:
    cleaned = str(value or "").strip()
    lowered = cleaned.lower().removeprefix("favors ").strip()
    if lowered in {"intervention", "intervention_label", "experimental", "experimental_label", "treatment", "eus-gj", "eusgj"}:
        return str(mapping.get("intervention_label") or fallback)
    if lowered in {"control", "control_label", "comparator", "comparator_label", "placebo", "non eus-gj", "noneusgj"}:
        return str(mapping.get("control_label") or fallback)
    return cleaned.removeprefix("Favors ").strip() or fallback


def infer_favor_labels(mapping: dict[str, Any], direction: str | None = None) -> dict[str, str]:
    intervention = str(mapping.get("intervention_label") or "Experimental")
    control = str(mapping.get("control_label") or "Control")
    hint = common.normalize_name(" ".join(str(mapping.get(key, "")) for key in ("outcome_name", "sheet_name")))
    lower_better_terms = (
        "time",
        "length",
        "stay",
        "pain",
        "score",
        "severity",
        "mortality",
        "bloodloss",
        "complication",
        "dose",
        "cost",
        "duration",
    )
    higher_better_terms = ("quality", "function", "improvement", "gain", "success", "satisfaction", "survival")
    chosen = (direction or "").lower()
    if chosen not in {"lower_better", "higher_better"}:
        if any(term in hint for term in higher_better_terms):
            chosen = "higher_better"
        elif any(term in hint for term in lower_better_terms):
            chosen = "lower_better"
        else:
            chosen = "lower_better"
    if chosen == "higher_better":
        return {
            "outcome_direction": "higher_better",
            "favor_left": control,
            "favor_right": intervention,
            "favor_label_reason": "Values left of zero mean the intervention value is lower; for a higher-is-better outcome this favors control.",
        }
    return {
        "outcome_direction": "lower_better",
        "favor_left": intervention,
        "favor_right": control,
        "favor_label_reason": "Values left of zero mean the intervention value is lower; for a lower-is-better outcome this favors intervention.",
    }


def normalize_analysis(analysis: dict[str, Any], mapping: dict[str, Any]) -> dict[str, str]:
    prior_analysis = mapping.get("analysis", {})
    measure = str(analysis.get("summary_measure") or "MD").upper()
    if measure not in SUMMARY_MEASURES:
        measure = "MD"
    measure_reason = str(
        analysis.get("summary_measure_reason")
        or prior_analysis.get("summary_measure_reason")
        or "MD is selected when all studies use the same outcome scale/unit."
    )
    data_format = str(analysis.get("data_format") or prior_analysis.get("data_format") or "mean_sd").lower()
    if data_format not in {"mean_sd", "median_iqr", "mixed"}:
        data_format = "mean_sd"
    median_handling = str(
        analysis.get("median_handling")
        or prior_analysis.get("median_handling")
        or "not_used"
    ).lower()
    if median_handling not in {"not_used", "estimate_mean_sd_from_median_iqr", "mixed_reported_and_estimated"}:
        median_handling = "not_used"
    model_raw = str(analysis.get("model_type") or prior_analysis.get("model_type") or "random").lower()
    model_type = "common" if model_raw in {"common", "fixed", "fixed-effect", "fixed effect"} else "random"
    engine = common.normalize_analysis_engine(
        analysis.get("analysis_engine") or prior_analysis.get("analysis_engine"),
        "frequentist",
    )
    favors = infer_favor_labels(mapping, str(analysis.get("outcome_direction") or prior_analysis.get("outcome_direction") or ""))
    favor_left = common.normalize_favor_group(
        analysis.get("favor_left") or prior_analysis.get("favor_left") or favors["favor_left"],
        mapping,
        favors["favor_left"],
    )
    favor_right = common.normalize_favor_group(
        analysis.get("favor_right") or prior_analysis.get("favor_right") or favors["favor_right"],
        mapping,
        favors["favor_right"],
    )
    tsa_favor_top = common.normalize_favor_group(
        analysis.get("tsa_favor_top") or prior_analysis.get("tsa_favor_top") or favor_right,
        mapping,
        favor_right,
    )
    tsa_favor_bottom = common.normalize_favor_group(
        analysis.get("tsa_favor_bottom") or prior_analysis.get("tsa_favor_bottom") or favor_left,
        mapping,
        favor_left,
    )
    tsa_alpha = common.normalize_float(analysis.get("tsa_alpha", prior_analysis.get("tsa_alpha")), 0.05, 0.0001, 0.5)
    tsa_power = common.normalize_float(analysis.get("tsa_power", prior_analysis.get("tsa_power")), 0.80, 0.5, 0.999)
    tsa_adjust = common.normalize_bool(
        analysis.get("tsa_adjust_for_diversity", prior_analysis.get("tsa_adjust_for_diversity")), False,
    )
    tsa_effect_source = str(
        analysis.get("tsa_effect_source")
        or prior_analysis.get("tsa_effect_source")
        or "observed"
    ).strip().lower()
    if tsa_effect_source not in {"observed", "clinically_important"}:
        tsa_effect_source = "observed"
    tsa_anticipated = common.normalize_float(
        analysis.get("tsa_anticipated_effect", prior_analysis.get("tsa_anticipated_effect")),
        None,
        0.0001,
        None,
    )
    tsa_ris_override = common.normalize_float(
        analysis.get("tsa_required_information_size", prior_analysis.get("tsa_required_information_size")),
        None,
        1,
        None,
    )
    normalized = {
        "summary_measure": measure,
        "summary_measure_reason": measure_reason,
        "data_format": data_format,
        "data_format_reason": str(
            analysis.get("data_format_reason")
            or prior_analysis.get("data_format_reason")
            or "Detected from available mean/SD and median/IQR columns."
        ),
        "median_handling": median_handling,
        "median_handling_reason": str(
            analysis.get("median_handling_reason")
            or prior_analysis.get("median_handling_reason")
            or "Median/IQR conversion is only used when means/SDs are unavailable."
        ),
        "model_type": model_type,
        "model_type_reason": str(
            analysis.get("model_type_reason")
            or prior_analysis.get("model_type_reason")
            or "Random-effects is selected when between-study heterogeneity is plausible."
        ),
        "analysis_engine": engine,
        "analysis_engine_reason": str(
            analysis.get("analysis_engine_reason")
            or prior_analysis.get("analysis_engine_reason")
            or common.analysis_engine_reason(engine)
        ),
        "outcome_direction": favors["outcome_direction"],
        "favor_left": favor_left,
        "favor_right": favor_right,
        "favor_label_reason": str(
            analysis.get("favor_label_reason")
            or prior_analysis.get("favor_label_reason")
            or favors["favor_label_reason"]
        ),
        "tsa_alpha": tsa_alpha,
        "tsa_power": tsa_power,
        "tsa_adjust_for_diversity": tsa_adjust,
        "tsa_effect_source": tsa_effect_source,
        "tsa_anticipated_effect": tsa_anticipated,
        "tsa_required_information_size": tsa_ris_override,
        "tsa_favor_top": tsa_favor_top,
        "tsa_favor_bottom": tsa_favor_bottom,
        "tsa_reason": str(
            analysis.get("tsa_reason")
            or prior_analysis.get("tsa_reason")
            or "TSA uses two-sided alpha 0.05, 80% power, observed pooled effect, and the selected heterogeneity adjustment for required information size (tau2 unless D2 diversity adjustment is selected)."
        ),
    }
    for preserved_key in ("subgroup_only", "conflict_resolution", "conflict_resolution_reason"):
        if preserved_key in analysis:
            normalized[preserved_key] = analysis[preserved_key]
        elif preserved_key in prior_analysis:
            normalized[preserved_key] = prior_analysis[preserved_key]
    return normalized


def merge_mapping(columns: list[str], sheet_name: str, lm_mapping: dict[str, Any] | None, outcome: str | None) -> dict[str, Any]:
    mapping = default_mapping(columns)
    mapping["sheet_name"] = sheet_name
    if lm_mapping:
        mapping.update({key: value for key, value in lm_mapping.items() if key not in {"columns", "subgroup_columns"} and value})
        for field, col in (lm_mapping.get("columns") or {}).items():
            if col in columns:
                mapping["columns"][field] = col
        subgroups = []
        for col in lm_mapping.get("subgroup_columns") or []:
            if col in columns and col not in subgroups:
                subgroups.append(col)
        legacy = (lm_mapping.get("columns") or {}).get("subgroup")
        if legacy in columns and legacy not in subgroups:
            subgroups.append(legacy)
        if subgroups:
            mapping["subgroup_columns"] = subgroups
        covariates = []
        for col in lm_mapping.get("covariate_columns") or []:
            if col in columns and col not in covariates:
                covariates.append(col)
        legacy_covariate = (lm_mapping.get("columns") or {}).get("covariate")
        if legacy_covariate in columns and legacy_covariate not in covariates:
            covariates.append(legacy_covariate)
        for col in infer_covariate_columns(columns, mapping):
            if col in columns and col not in covariates:
                covariates.append(col)
        if covariates:
            mapping["covariate_columns"] = covariates
            mapping["columns"]["covariate"] = covariates[0]
    if outcome:
        mapping["outcome_name"] = outcome
    common.refresh_arm_labels_from_columns(mapping)
    mapping["analysis"] = normalize_analysis(mapping.get("analysis") or {}, mapping)
    return mapping


def print_mapping(mapping: dict[str, Any], columns: list[str]) -> None:
    print("\nIdentified continuous endpoint mapping")
    print("--------------------------------------")
    print(f"Sheet: {mapping.get('sheet_name')}")
    print(f"Outcome name: {mapping.get('outcome_name')}")
    print(f"Intervention label: {mapping.get('intervention_label')}")
    print(f"Control label: {mapping.get('control_label')}")
    print("\nColumns:")
    for field in REQUIRED_FIELDS + MEAN_SD_FIELDS + MEDIAN_FIELDS + OPTIONAL_FIELDS:
        if field == "covariate":
            continue
        print(f"  {FIELD_LABELS[field]}: {common.format_column_choice(mapping.get('columns', {}).get(field), columns)}")
    subgroups = ", ".join(common.format_column_choice(col, columns) for col in mapping.get("subgroup_columns", [])) or "(none)"
    print(f"  {FIELD_LABELS['subgroups']}: {subgroups}")
    covariates = ", ".join(common.format_column_choice(col, columns) for col in mapping.get("covariate_columns", [])) or common.format_column_choice(mapping.get("columns", {}).get("covariate"), columns)
    print(f"  {FIELD_LABELS['covariates']}: {covariates}")
    print("\nAvailable columns")
    print("-----------------")
    for index, column in enumerate(columns, start=1):
        print(f"{index}. {column}")
    analysis = normalize_analysis(mapping.get("analysis") or {}, mapping)
    print("\nAnalysis choices:")
    print(f"  Effect size: {analysis['summary_measure']} ({SUMMARY_MEASURES[analysis['summary_measure']]})")
    print(f"    Why: {analysis['summary_measure_reason']}")
    print(f"  Data format: {analysis['data_format']}")
    print(f"    Why: {analysis['data_format_reason']}")
    print(f"  Median handling: {analysis['median_handling']}")
    print(f"    Why: {analysis['median_handling_reason']}")
    print(f"  Statistical model: {analysis['model_type']} ({'Random-effects' if analysis['model_type'] == 'random' else 'Common/fixed-effect'})")
    print(f"    Why: {analysis['model_type_reason']}")
    print(f"  Analysis engine: {analysis['analysis_engine']} ({common.ANALYSIS_ENGINES[analysis['analysis_engine']]})")
    print(f"    Why: {analysis['analysis_engine_reason']}")
    print(f"  Direction: {analysis['outcome_direction']}")
    print(f"  Left of null line: Favors {analysis['favor_left']}")
    print(f"  Right of null line: Favors {analysis['favor_right']}")
    print(f"    Why: {analysis['favor_label_reason']}")
    print(
        "  TSA: "
        f"alpha {analysis['tsa_alpha']}, power {analysis['tsa_power']}, "
        f"{'diversity-adjusted RIS' if analysis['tsa_adjust_for_diversity'] else 'heterogeneity-adjusted RIS (tau2)'}, "
        f"effect source {analysis['tsa_effect_source']}"
        + (
            f", RIS override {analysis['tsa_required_information_size']}"
            if analysis.get("tsa_required_information_size")
            else ""
        )
    )
    print(f"    TSA top: Favours {analysis['tsa_favor_top']}; bottom: Favours {analysis['tsa_favor_bottom']}")
    print(f"    Why: {analysis['tsa_reason']}")
    print(f"Notes: {mapping.get('notes', '')}")


def prompt_for_mapping(mapping: dict[str, Any], columns: list[str], assume_yes: bool) -> dict[str, Any]:
    print_mapping(mapping, columns)
    if assume_yes or not sys.stdin.isatty():
        return mapping
    correct = input("\nAre these identified columns correct? [Y/n]: ").strip().lower()
    if correct not in {"n", "no"}:
        return mapping
    print("\nType a column number to replace a value, press Enter to keep it, or type 0 for none.")
    mapping["outcome_name"] = input(f"Outcome name [{mapping.get('outcome_name')}]: ").strip() or mapping.get("outcome_name")
    mapping["intervention_label"] = input(f"Intervention label [{mapping.get('intervention_label')}]: ").strip() or mapping.get("intervention_label")
    mapping["control_label"] = input(f"Control label [{mapping.get('control_label')}]: ").strip() or mapping.get("control_label")
    for field in REQUIRED_FIELDS + MEAN_SD_FIELDS + MEDIAN_FIELDS + OPTIONAL_FIELDS:
        if field == "covariate":
            continue
        current = mapping.get("columns", {}).get(field) or ""
        value = input(f"{FIELD_LABELS[field]} column [{common.format_column_choice(current, columns)}]: ").strip()
        if value:
            resolved = common.resolve_column_choice(value, columns)
            if resolved is None:
                mapping["columns"].pop(field, None)
            else:
                mapping["columns"][field] = resolved
    subgroup_display = ", ".join(common.format_column_choice(col, columns) for col in mapping.get("subgroup_columns", [])) or "(none)"
    subgroup_value = input(f"{FIELD_LABELS['subgroups']} [{subgroup_display}]: ").strip()
    if subgroup_value:
        if subgroup_value.lower() in {"none", "null", "-", "0"}:
            mapping["subgroup_columns"] = []
        else:
            mapping["subgroup_columns"] = common.resolve_column_choices(subgroup_value, columns)
    covariate_display = ", ".join(common.format_column_choice(col, columns) for col in mapping.get("covariate_columns", [])) or common.format_column_choice(mapping.get("columns", {}).get("covariate"), columns)
    covariate_value = input(f"{FIELD_LABELS['covariates']} [{covariate_display}]: ").strip()
    if covariate_value:
        if covariate_value.lower() in {"none", "null", "-", "0"}:
            mapping["covariate_columns"] = []
            mapping["columns"].pop("covariate", None)
        else:
            mapping["covariate_columns"] = common.resolve_column_choices(covariate_value, columns)
            if mapping["covariate_columns"]:
                mapping["columns"]["covariate"] = mapping["covariate_columns"][0]
    return mapping


def infer_analysis_from_data(r_df: pd.DataFrame, mapping: dict[str, Any], lm_mapping: dict[str, Any] | None) -> dict[str, str]:
    current = normalize_analysis(mapping.get("analysis") or {}, mapping)
    has_mean_sd = (
        r_df[["mean.e", "sd.e", "mean.c", "sd.c"]]
        .apply(pd.to_numeric, errors="coerce")
        .notna()
        .all(axis=1)
    )
    has_median = (
        r_df[["median.e", "median.c"]]
        .apply(pd.to_numeric, errors="coerce")
        .notna()
        .all(axis=1)
    )
    has_iqr = (
        r_df[["q1.e", "q3.e", "q1.c", "q3.c"]]
        .apply(pd.to_numeric, errors="coerce")
        .notna()
        .all(axis=1)
    )
    has_range = (
        r_df[["min.e", "max.e", "min.c", "max.c"]]
        .apply(pd.to_numeric, errors="coerce")
        .notna()
        .all(axis=1)
    )
    median_convertible = has_median & (has_iqr | has_range)
    if has_mean_sd.all():
        data_format = "mean_sd"
        median_handling = "not_used"
        data_reason = "All retained rows contain mean and SD for both groups."
        median_reason = "Median/IQR conversion is not needed because mean/SD values are present."
    elif median_convertible.all():
        data_format = "median_iqr"
        median_handling = "estimate_mean_sd_from_median_iqr"
        data_reason = "Rows contain medians plus IQR/range fields that meta::metacont can use to estimate means/SDs."
        median_reason = (
            "Median/IQR or range data will be converted by meta::metacont. Review skewness/normality assumptions "
            "before using the transformed values in a manuscript."
        )
    else:
        data_format = "mixed"
        median_handling = "mixed_reported_and_estimated"
        data_reason = "Some rows use reported mean/SD and others use median/IQR or range fields."
        median_reason = "Rows without mean/SD will rely on metacont median/IQR or range estimation; review these conversions."

    scale_hint = common.normalize_name(" ".join([str(mapping.get("outcome_name", "")), str(mapping.get("sheet_name", "")), " ".join(r_df.columns)]))
    if any(token in scale_hint for token in ("different scale", "different instruments", "questionnaire", "depression", "qualityoflife", "score", "scale")):
        measure = "SMD"
        measure_reason = (
            "SMD was selected because the outcome appears to be measured as a score/scale where different instruments "
            "may be used. Confirm that all scales point in the same direction."
        )
    else:
        measure = "MD"
        measure_reason = "MD was selected because the data appear to use the same continuous scale/unit across studies."

    return {
        "summary_measure": measure,
        "summary_measure_reason": measure_reason,
        "data_format": data_format,
        "data_format_reason": data_reason,
        "median_handling": median_handling,
        "median_handling_reason": median_reason,
        "model_type": current["model_type"],
        "model_type_reason": current["model_type_reason"],
        "tsa_alpha": current["tsa_alpha"],
        "tsa_power": current["tsa_power"],
        "tsa_adjust_for_diversity": current["tsa_adjust_for_diversity"],
        "tsa_effect_source": current["tsa_effect_source"],
        "tsa_anticipated_effect": current["tsa_anticipated_effect"],
        "tsa_required_information_size": current["tsa_required_information_size"],
        "tsa_favor_top": current["tsa_favor_top"],
        "tsa_favor_bottom": current["tsa_favor_bottom"],
        "tsa_reason": current["tsa_reason"],
        **infer_favor_labels(mapping),
    }


def prompt_for_analysis_choices(analysis: dict[str, str], assume_yes: bool) -> dict[str, str]:
    print("\nChosen analysis and plot direction")
    print("----------------------------------")
    print(f"Effect size: {analysis['summary_measure']} ({SUMMARY_MEASURES[analysis['summary_measure']]})")
    print(f"Why: {analysis['summary_measure_reason']}")
    print(f"Data format: {analysis['data_format']}")
    print(f"Median handling: {analysis['median_handling']}")
    print(f"Why: {analysis['median_handling_reason']}")
    print(f"Statistical model: {analysis['model_type']} ({'Random-effects' if analysis['model_type'] == 'random' else 'Common/fixed-effect'})")
    print(f"Why: {analysis['model_type_reason']}")
    print(f"Analysis engine: {analysis['analysis_engine']} ({common.ANALYSIS_ENGINES[analysis['analysis_engine']]})")
    print(f"Why: {analysis['analysis_engine_reason']}")
    if analysis.get("analysis_engine_auto_summary"):
        print("Auto engine data check:")
        print(f"  Data summary: {analysis['analysis_engine_auto_summary']}")
        triggers = analysis.get("analysis_engine_auto_triggers") or []
        print(f"  Bayesian supplement triggers: {', '.join(triggers) if triggers else 'none'}")
    print(f"Outcome direction: {analysis['outcome_direction']}")
    print(f"Left of null line: Favors {analysis['favor_left']}")
    print(f"Right of null line: Favors {analysis['favor_right']}")
    print(f"Why: {analysis['favor_label_reason']}")
    print(
        "Trial sequential analysis: "
        f"alpha {analysis['tsa_alpha']}, power {analysis['tsa_power']}, "
        f"{'diversity-adjusted RIS' if analysis['tsa_adjust_for_diversity'] else 'heterogeneity-adjusted RIS (tau2)'}, "
        f"effect source {analysis['tsa_effect_source']}"
        + (
            f", RIS override {analysis['tsa_required_information_size']}"
            if analysis.get("tsa_required_information_size")
            else ""
        )
    )
    print(f"TSA top: Favours {analysis['tsa_favor_top']}; bottom: Favours {analysis['tsa_favor_bottom']}")
    print(f"Why: {analysis['tsa_reason']}")
    if assume_yes or not sys.stdin.isatty():
        return analysis
    correct = input("Are these analysis choices correct? [Y/n]: ").strip().lower()
    if correct not in {"n", "no"}:
        return analysis

    print("\nEffect size options:")
    print("1. MD - Mean Difference: same scale/unit")
    print("2. SMD - Standardized Mean Difference: different scales/instruments")
    value = input(f"Effect size [{analysis['summary_measure']}]: ").strip()
    if value:
        lookup = {"1": "MD", "2": "SMD", "md": "MD", "MD": "MD", "smd": "SMD", "SMD": "SMD"}
        if value not in lookup:
            raise SystemExit("Effect size must be 1/MD or 2/SMD.")
        analysis["summary_measure"] = lookup[value]
        analysis["summary_measure_reason"] = "Manually selected by user."

    print("\nStatistical model options:")
    print("1. random - Random-effects")
    print("2. common - Common/fixed-effect")
    value = input(f"Statistical model [{analysis['model_type']}]: ").strip().lower()
    if value:
        lookup = {"1": "random", "2": "common", "random": "random", "common": "common", "fixed": "common"}
        if value not in lookup:
            raise SystemExit("Model must be 1/random or 2/common/fixed.")
        analysis["model_type"] = lookup[value]
        analysis["model_type_reason"] = "Manually selected by user."

    print("\nAnalysis engine options:")
    print("1. frequentist - Conventional confidence intervals and standard meta-analysis outputs")
    print("2. bayesian - Bayesian posterior summary and credible intervals")
    print("3. both - Generate both frequentist and Bayesian outputs")
    value = input(f"Analysis engine [{analysis['analysis_engine']}]: ").strip().lower()
    if value:
        lookup = {
            "1": "frequentist",
            "2": "bayesian",
            "3": "both",
            "frequentist": "frequentist",
            "freq": "frequentist",
            "bayesian": "bayesian",
            "bayes": "bayesian",
            "both": "both",
        }
        if value not in lookup:
            raise SystemExit("Analysis engine must be 1/frequentist, 2/bayesian, or 3/both.")
        analysis["analysis_engine"] = lookup[value]
        analysis["analysis_engine_reason"] = "Manually selected by user."

    print("\nFavors-label options:")
    print(f"Current: left = Favors {analysis['favor_left']}; right = Favors {analysis['favor_right']}")
    flip = input("Flip left/right favors labels? [y/N]: ").strip().lower()
    if flip in {"y", "yes"}:
        analysis["favor_left"], analysis["favor_right"] = analysis["favor_right"], analysis["favor_left"]
        analysis["favor_label_reason"] = "Manually flipped by user."
    else:
        left = input(f"Left label group [{analysis['favor_left']}]: ").strip()
        right = input(f"Right label group [{analysis['favor_right']}]: ").strip()
        if left:
            analysis["favor_left"] = left.removeprefix("Favors ").strip()
            analysis["favor_label_reason"] = "Manually selected by user."
        if right:
            analysis["favor_right"] = right.removeprefix("Favors ").strip()
            analysis["favor_label_reason"] = "Manually selected by user."

    print("\nTrial sequential analysis options:")
    alpha_value = input(f"Two-sided alpha [{analysis['tsa_alpha']}]: ").strip()
    if alpha_value:
        parsed = common.normalize_float(alpha_value, None, 0.0001, 0.5)
        if parsed is None:
            raise SystemExit("TSA alpha must be a number between 0.0001 and 0.5.")
        analysis["tsa_alpha"] = parsed
        analysis["tsa_reason"] = "Manually selected by user."
    power_value = input(f"Power [{analysis['tsa_power']}]: ").strip()
    if power_value:
        parsed = common.normalize_float(power_value, None, 0.5, 0.999)
        if parsed is None:
            raise SystemExit("TSA power must be a number between 0.5 and 0.999.")
        analysis["tsa_power"] = parsed
        analysis["tsa_reason"] = "Manually selected by user."
    diversity_value = input(
        f"Use diversity-adjusted required information size (instead of tau2)? [{'Y/n' if analysis['tsa_adjust_for_diversity'] else 'y/N'}]: "
    ).strip().lower()
    if diversity_value:
        if diversity_value not in {"y", "yes", "n", "no"}:
            raise SystemExit("Diversity adjustment must be yes or no.")
        analysis["tsa_adjust_for_diversity"] = diversity_value in {"y", "yes"}
        analysis["tsa_reason"] = "Manually selected by user."
    effect_source_value = input(f"TSA anticipated effect source [{analysis['tsa_effect_source']}]: ").strip().lower()
    if effect_source_value:
        if effect_source_value not in {"observed", "clinically_important"}:
            raise SystemExit("TSA effect source must be observed or clinically_important.")
        analysis["tsa_effect_source"] = effect_source_value
        analysis["tsa_reason"] = "Manually selected by user."
    if analysis["tsa_effect_source"] == "clinically_important":
        anticipated_value = input(
            f"Anticipated {analysis['summary_measure']} for TSA [{analysis.get('tsa_anticipated_effect') or 'observed pooled effect'}]: "
        ).strip()
        if anticipated_value:
            parsed = common.normalize_float(anticipated_value, None, 0.0001, None)
            if parsed is None:
                raise SystemExit("Anticipated TSA effect must be a positive number.")
            analysis["tsa_anticipated_effect"] = parsed
            analysis["tsa_reason"] = "Manually selected clinically important effect."
    ris_value = input(
        f"Required information size override [{analysis.get('tsa_required_information_size') or 'calculated'}]: "
    ).strip()
    if ris_value:
        if ris_value.lower() in {"none", "calculated", "calculate", "auto", "0"}:
            analysis["tsa_required_information_size"] = None
        else:
            parsed = common.normalize_float(ris_value, None, 1, None)
            if parsed is None:
                raise SystemExit("TSA required information size override must be a positive number.")
            analysis["tsa_required_information_size"] = parsed
            analysis["tsa_reason"] = "Required information size was manually provided by user."
    print(f"Current TSA labels: top = Favours {analysis['tsa_favor_top']}; bottom = Favours {analysis['tsa_favor_bottom']}")
    flip_tsa = input("Flip TSA top/bottom favour labels? [y/N]: ").strip().lower()
    if flip_tsa in {"y", "yes"}:
        analysis["tsa_favor_top"], analysis["tsa_favor_bottom"] = analysis["tsa_favor_bottom"], analysis["tsa_favor_top"]
        analysis["tsa_reason"] = "TSA labels were manually flipped by user."
    return analysis


def has_arm_summary(row: pd.Series, group: str) -> bool:
    mean_ok = pd.notna(row[f"mean.{group}"]) and pd.notna(row[f"sd.{group}"])
    median_ok = pd.notna(row[f"median.{group}"]) and (
        pd.notna(row[f"q1.{group}"]) and pd.notna(row[f"q3.{group}"])
        or pd.notna(row[f"min.{group}"]) and pd.notna(row[f"max.{group}"])
    )
    return bool(mean_ok or median_ok)


def arm_descriptor_is_shared(group: pd.DataFrame, side: str) -> bool:
    for col in [f"{field}.{side}" for field in ("n", "mean", "sd", "median", "q1", "q3", "min", "max")]:
        if col in group and group[col].nunique(dropna=True) > 1:
            return False
    return True


def pool_continuous_side(group: pd.DataFrame, side: str, row: pd.Series) -> bool:
    n_col = f"n.{side}"
    mean_col = f"mean.{side}"
    sd_col = f"sd.{side}"
    values = group[[n_col, mean_col, sd_col]].apply(pd.to_numeric, errors="coerce")
    valid = values[n_col].notna() & values[mean_col].notna() & values[sd_col].notna()
    if not valid.all():
        return False
    values = values[valid]
    if values.empty or (values[n_col] <= 0).any() or (values[sd_col] < 0).any():
        return False
    sum_n = values[n_col].sum()
    if not math.isfinite(sum_n) or sum_n <= 0:
        return False
    pooled_mean = (values[n_col] * values[mean_col]).sum() / sum_n
    var_num = (
        (values[n_col] - 1) * (values[sd_col] ** 2)
        + values[n_col] * ((values[mean_col] - pooled_mean) ** 2)
    ).sum()
    pooled_sd = math.sqrt(max(var_num / (sum_n - 1), 0)) if sum_n > 1 else 0.0
    row[n_col] = sum_n
    row[mean_col] = pooled_mean
    row[sd_col] = pooled_sd
    for col in [f"median.{side}", f"q1.{side}", f"q3.{side}", f"min.{side}", f"max.{side}"]:
        row[col] = pd.NA
    return True


def validate_data(df: pd.DataFrame, mapping: dict[str, Any]) -> pd.DataFrame:
    missing = [field for field in REQUIRED_FIELDS if field not in mapping.get("columns", {})]
    if missing:
        raise SystemExit("Missing required columns: " + ", ".join(FIELD_LABELS[field] for field in missing))
    r_df = pd.DataFrame()
    study_values = df[mapping["columns"]["study_label"]].astype("string").str.strip()
    study_values = study_values.mask(study_values.str.lower().isin({"", "nan", "none", "null"}).fillna(False))
    r_df["Author"] = study_values
    for source_col in df.columns:
        if common.normalize_name(source_col) in {"tsaorder", "order"}:
            output_col = "tsa_order" if common.normalize_name(source_col) == "tsaorder" else "order"
            r_df[output_col] = pd.to_numeric(df[source_col], errors="coerce")
            break
    for field, r_col in PY_TO_R.items():
        source = mapping.get("columns", {}).get(field)
        if source:
            r_df[r_col] = pd.to_numeric(df[source], errors="coerce")
        else:
            r_df[r_col] = pd.NA
    mapping["subgroup_r_columns"] = []
    for subgroup_source in mapping.get("subgroup_columns") or []:
        if subgroup_source in df.columns:
            subgroup_col = common.sanitize_r_name(subgroup_source, "subgroup")
            if subgroup_col in set(R_COLUMNS + ["Author", "covariate"]):
                subgroup_col = f"{subgroup_col}_subgroup"
            base = subgroup_col
            suffix = 2
            while subgroup_col in r_df.columns:
                subgroup_col = f"{base}_{suffix}"
                suffix += 1
            r_df[subgroup_col] = df[subgroup_source]
            mapping.setdefault("subgroup_r_columns", []).append({"source": subgroup_source, "r_column": subgroup_col})
    covariate_sources = list(mapping.get("covariate_columns") or [])
    legacy_covariate = mapping.get("columns", {}).get("covariate")
    if legacy_covariate and legacy_covariate not in covariate_sources:
        covariate_sources.append(legacy_covariate)
    for subgroup_source in list(mapping.get("subgroup_columns") or []):
        if subgroup_source not in covariate_sources:
            covariate_sources.append(subgroup_source)
    for covariate_source in infer_covariate_columns(list(df.columns), mapping):
        if covariate_source not in covariate_sources:
            covariate_sources.append(covariate_source)
    mapping["covariate_skip_notes"] = []
    valid_covariates = []
    used_covariate_cols: set[str] = set()
    for index, covariate_source in enumerate(covariate_sources, start=1):
        if not covariate_source or covariate_source not in df.columns:
            continue
        covariate_col = common.covariate_r_name(covariate_source, index)
        base = covariate_col
        suffix = 2
        while covariate_col in r_df.columns or covariate_col in used_covariate_cols:
            covariate_col = f"{base}_{suffix}"
            suffix += 1
        values, covariate_type, reason = common.prepare_covariate_series(df[covariate_source], covariate_source)
        if values is None or covariate_type is None:
            reason = reason or "the column could not be interpreted as a numeric or categorical moderator."
            print(f"Covariate column '{covariate_source}' was identified but is not usable for meta-regression; skipping it.")
            mapping["covariate_skip_notes"].append({"source": covariate_source, "reason": reason})
            continue
        r_df[covariate_col] = values
        used_covariate_cols.add(covariate_col)
        valid_covariates.append({"source": covariate_source, "r_column": covariate_col, "type": covariate_type})
    mapping["covariate_columns"] = [item["source"] for item in valid_covariates]
    mapping["covariate_r_columns"] = valid_covariates
    if valid_covariates:
        mapping["columns"]["covariate"] = valid_covariates[0]["source"]
    else:
        mapping["columns"].pop("covariate", None)

    mapping.setdefault("analysis", {})
    mapping["analysis"].setdefault("subgroup_only", False)
    original_authors = study_values
    study_group_labels = original_authors.map(common.study_group_label)
    duplicate_study_groups = study_group_labels[study_group_labels.notna() & (study_group_labels != "")]
    mapping["duplicate_study_label_conflict"] = bool(duplicate_study_groups.duplicated(keep=False).any())
    mapping["duplicate_subgroup_conflict"] = False
    if mapping.get("subgroup_r_columns"):
        primary_subgroup_col = mapping["subgroup_r_columns"][0]["r_column"]
        temp_df = pd.DataFrame({"author": study_group_labels, "subgroup": r_df[primary_subgroup_col]})
        temp_df = temp_df.dropna(subset=["subgroup"])
        unique_combinations = temp_df.drop_duplicates()
        if unique_combinations["author"].duplicated().any():
            mapping["duplicate_subgroup_conflict"] = True

    for col in [item for item in R_COLUMNS if item != "Author"]:
        r_df[col] = pd.to_numeric(r_df[col], errors="coerce")
    r_df["n.e"] = pd.to_numeric(r_df["n.e"], errors="coerce")
    r_df["n.c"] = pd.to_numeric(r_df["n.c"], errors="coerce")

    duplicate_rows_need_resolution = bool(
        mapping.get("duplicate_subgroup_conflict") or mapping.get("duplicate_study_label_conflict")
    )
    conflict_resolution = mapping.get("analysis", {}).get("conflict_resolution")
    if (
        duplicate_rows_need_resolution
        and conflict_resolution == "subgroup_only"
    ):
        conflict_resolution = "combine"
        mapping["analysis"]["conflict_resolution"] = "combine"
        mapping["analysis"]["subgroup_only"] = False
        common.append_mapping_note(
            mapping,
            "Duplicate study labels had been marked as subgroup-only, but the overall forest plot and TSA now use Cochrane-combined rows to avoid double-counting; subgroup plots still use subgroup-specific duplicate handling.",
        )
    if (
        duplicate_rows_need_resolution
        and conflict_resolution not in {"combine", "split", "subgroup_only"}
        and not mapping.get("analysis", {}).get("subgroup_only")
    ):
        conflict_resolution = "combine"
        mapping["analysis"]["conflict_resolution"] = "combine"
        mapping["analysis"]["conflict_resolution_reason"] = (
            "Duplicate study labels, including numbered copy labels such as '(1)'/'(2)', were combined to avoid double-counting."
        )
        common.append_mapping_note(
            mapping,
            "Duplicate study labels, including numbered copy labels such as '(1)'/'(2)', were combined automatically to avoid double-counting.",
        )
    if conflict_resolution in {"combine", "split"} and duplicate_rows_need_resolution:
        r_df["Author"] = original_authors
        r_df["_study_group_label"] = study_group_labels
        grouped = r_df.groupby("_study_group_label", sort=False, dropna=False)
        new_rows = []
        unresolved_authors: list[str] = []
        for author, group in grouped:
            if len(group) <= 1:
                new_rows.append(group.iloc[0])
                continue

            shared_sides = [side for side in ("e", "c") if arm_descriptor_is_shared(group, side)]

            row = group.iloc[0].copy()
            if conflict_resolution == "combine":
                row["Author"] = str(author)
                sides_to_pool = [side for side in ("e", "c") if side not in shared_sides]
                for side in sides_to_pool:
                    if not pool_continuous_side(group, side, row):
                        unresolved_authors.append(str(author))
                        break
                else:
                    for subgroup in mapping.get("subgroup_r_columns") or []:
                        row[subgroup["r_column"]] = "Combined"
                    new_rows.append(row)
                continue
            if conflict_resolution == "split":
                if len(shared_sides) != 1:
                    unresolved_authors.append(str(author))
                    continue
                shared_side = shared_sides[0]
                k = len(group)
                shared_n = group[f"n.{shared_side}"].iloc[0]
                if not pd.notna(shared_n) or shared_n <= 0:
                    unresolved_authors.append(str(author))
                    continue
                for _, g_row in group.iterrows():
                    g_row_copy = g_row.copy()
                    g_row_copy[f"n.{shared_side}"] = shared_n / k
                    new_rows.append(g_row_copy)
        if unresolved_authors:
            sample = ", ".join(unresolved_authors[:5])
            raise SystemExit(
                "Duplicate subgroup rows could not be resolved safely for continuous data. "
                f"Review these study labels and set conflict_resolution explicitly: {sample}"
            )
        r_df = pd.DataFrame(new_rows).reset_index(drop=True)
        r_df = r_df.drop(columns=["_study_group_label"], errors="ignore")

    complete = r_df["Author"].notna() & (r_df["n.e"] > 0) & (r_df["n.c"] > 0)
    complete &= r_df.apply(lambda row: has_arm_summary(row, "e") and has_arm_summary(row, "c"), axis=1)
    r_df = r_df[complete].copy()
    if r_df.empty:
        raise SystemExit("No complete continuous-data rows remained after validation.")
    finite_n = r_df[["n.e", "n.c"]].apply(lambda column: column.map(math.isfinite))
    if not finite_n.all().all():
        raise SystemExit("Invalid continuous data: sample-size columns must be finite positive numbers.")
    if mapping.get("analysis", {}).get("conflict_resolution") != "split":
        for col in ["n.e", "n.c"]:
            non_integer = (r_df[col].round() - r_df[col]).abs() > 1e-8
            if non_integer.any():
                raise SystemExit("Invalid continuous data: sample-size columns must contain whole numbers.")
    for col in ["sd.e", "sd.c"]:
        bad = r_df[col].notna() & (r_df[col] < 0)
        if bad.any():
            raise SystemExit("Invalid continuous data: SD values must be nonnegative.")
        r_df[col] = pd.to_numeric(r_df[col], errors="coerce").astype(float)
    impute_zero_standard_deviations(r_df, mapping)
    for group in ["e", "c"]:
        q_complete = r_df[[f"q1.{group}", f"median.{group}", f"q3.{group}"]].notna().all(axis=1)
        if (q_complete & ~((r_df[f"q1.{group}"] <= r_df[f"median.{group}"]) & (r_df[f"median.{group}"] <= r_df[f"q3.{group}"]))).any():
            raise SystemExit("Invalid continuous data: quartiles must satisfy Q1 <= median <= Q3.")
        range_complete = r_df[[f"min.{group}", f"median.{group}", f"max.{group}"]].notna().all(axis=1)
        if (range_complete & ~((r_df[f"min.{group}"] <= r_df[f"median.{group}"]) & (r_df[f"median.{group}"] <= r_df[f"max.{group}"]))).any():
            raise SystemExit("Invalid continuous data: range must satisfy min <= median <= max.")
    r_df["Author"] = common.make_unique_study_labels(r_df["Author"].astype(str))
    return r_df


def impute_zero_standard_deviations(r_df: pd.DataFrame, mapping: dict[str, Any]) -> None:
    r_df["zero_sd_imputed"] = False
    r_df["zero_sd_imputed_columns"] = ""
    zero_mask = (r_df[["sd.e", "sd.c"]] == 0).any(axis=1)
    if not zero_mask.any():
        mapping.pop("zero_sd_imputations", None)
        mapping.pop("zero_sd_assumption", None)
        return

    replacement = 0.1
    assumption = (
        "Zero SD values were treated as missing/unreliable variability values, not as proof of truly no within-arm "
        "variation. Each zero SD was replaced with 0.1 for the primary analysis. A sensitivity analysis excluding "
        "studies with any zero-SD imputation is generated automatically, and the pooled estimate and heterogeneity "
        "from the primary and sensitivity analyses should be compared in the report."
    )
    imputations: list[dict[str, Any]] = []
    for sd_col in ["sd.e", "sd.c"]:
        for idx in r_df.index[r_df[sd_col] == 0]:
            imputations.append(
                {
                    "study": str(r_df.at[idx, "Author"]),
                    "sd_column": sd_col,
                    "original_sd": 0,
                    "imputed_sd": replacement,
                    "strategy": "fixed_zero_sd_replacement_0.1",
                    "assumption": assumption,
                }
            )
            existing = str(r_df.at[idx, "zero_sd_imputed_columns"] or "")
            r_df.at[idx, "zero_sd_imputed"] = True
            r_df.at[idx, "zero_sd_imputed_columns"] = ", ".join(filter(None, [existing, sd_col]))
            r_df.at[idx, sd_col] = replacement

    mapping["zero_sd_imputations"] = imputations
    mapping["zero_sd_assumption"] = assumption


def show_extracted_data(r_df: pd.DataFrame, preview_rows: int, assume_yes: bool, extracted_path: Path) -> None:
    r_df.to_csv(extracted_path, index=False)
    print("\nExtracted continuous analysis data")
    print("----------------------------------")
    print(f"Rows extracted: {len(r_df)}")
    print(f"Saved copy: {extracted_path}")
    with pd.option_context("display.max_columns", None, "display.width", 200):
        print(r_df.head(preview_rows).to_string(index=False))
    if len(r_df) > preview_rows:
        print(f"... {len(r_df) - preview_rows} more rows not shown.")
    if assume_yes or not sys.stdin.isatty():
        return
    if input("Run R meta-analysis with this extracted data? [Y/n]: ").strip().lower() in {"n", "no"}:
        raise SystemExit("Stopped before running R.")


def write_r_script(
    script_path: Path,
    csv_path: Path,
    output_dir: Path,
    outcome: str,
    intervention_label: str,
    control_label: str,
    subgroup_info: list[dict[str, str]],
    covariate_info: list[dict[str, str]],
    summary_measure: str,
    model_type: str,
    analysis_engine: str,
    favor_left_label: str,
    favor_right_label: str,
    tsa_favor_top_label: str,
    tsa_favor_bottom_label: str,
    tsa_alpha: float,
    tsa_power: float,
    tsa_adjust_for_diversity: bool,
    tsa_effect_source: str,
    tsa_anticipated_effect: float | None,
    tsa_required_information_size: float | None,
    subgroup_only: bool = False,
) -> None:
    subgroup_block = ""
    for subgroup in subgroup_info:
        subgroup_label = subgroup["source"]
        subgroup_r_column = subgroup["r_column"]
        file_label = common.sanitize_filename(subgroup_label, "Subgroup")
        subgroup_block += f"""
data[[{common.r_string(subgroup_r_column)}]] <- factor(data[[{common.r_string(subgroup_r_column)}]])
subgroup <- metacont(mean.e=mean.e, sd.e=sd.e, n.e=n.e,
                median.e=median.e, q1.e=q1.e, q3.e=q3.e,
                min.e=min.e, max.e=max.e,
                mean.c=mean.c, sd.c=sd.c, n.c=n.c,
                median.c=median.c, q1.c=q1.c, q3.c=q3.c,
                min.c=min.c, max.c=max.c,
                data = data,
                studlab = Author,
                sm = summary_measure,
                method.tau = "REML",
                method.random.ci = "classic",
                method.I2 = "tau2",
                random = random_model,
                common = common_model,
                prediction = random_model,
                method.predict = "V",
                subgroup = data[[{common.r_string(subgroup_r_column)}]],
                subgroup.name = "Subgroup",
                print.subgroup.name = TRUE,
                sep.subgroup = " = ")

subgroup_levels <- unique(data[[{common.r_string(subgroup_r_column)}]][!is.na(data[[{common.r_string(subgroup_r_column)}]])])
plot_height <- max(2500, 1450 + 105 * nrow(data) + 300 * length(subgroup_levels))
png(file = file.path(output, paste0("Subgroup - {file_label} - ", outcome, ".png")),
    width = plot_width,
    height = plot_height,
    res = 300)

forest(subgroup,
       layout = "Revman5",
       sortvar = TE,
       label.e = {common.r_string(intervention_label)},
       label.c = {common.r_string(control_label)},
       label.left = paste("Favors", {common.r_string(favor_left_label)}),
       label.right = paste("Favors", {common.r_string(favor_right_label)}),
       leftcols = c("studlab", "mean.e", "sd.e", "n.e", "mean.c", "sd.c", "n.c", weight_col, "effect", "ci"),
       leftlabs = c("Studies", "Mean", "SD", "Total", "Mean", "SD", "Total", "Weight (%)", summary_measure, "95% CI"),
       colgap = "3mm",
       colgap.forest.left = "8mm",
       colgap.forest.right = "8mm",
       digits = 2,
       digits.sd = 2,
       pooled.totals = TRUE,
       col.square = "darkblue",
       col.square.lines = "black",
       subgroup.name = "Subgroup",
       print.subgroup.name = TRUE,
       sep.subgroup = " = ",
       subgroup.hetstat = TRUE,
       test.effect.subgroup.random = FALSE,
       test.effect.subgroup.common = FALSE,
       overall = {str(not subgroup_only).upper()},
       overall.hetstat = {str(not subgroup_only).upper()},
       test.overall.random = random_model,
       test.overall.common = common_model,
       test.subgroup.random = random_model,
       test.subgroup.common = common_model,
       fontsize = 8.5,
       fs.study = 8,
       fs.heading = 8.5,
       fs.axis = 8,
       spacing = 0.9,
       just.studlab = "left")

dev.off()
capture.output(summary(subgroup), file = file.path(output, paste0("SubgroupSummary - {file_label} - ", outcome, ".txt")))
"""

    metareg_block = ""
    for covariate in covariate_info:
        covariate_label = covariate["source"]
        covariate_r_column = covariate["r_column"]
        covariate_type = str(covariate.get("type") or "numeric")
        covariate_file_label = common.sanitize_filename(covariate_label, "Covariate")
        if covariate_type == "categorical":
            metareg_block += f"""
raw_cov_values <- trimws(as.character(data[[{common.r_string(covariate_r_column)}]]))
raw_cov_values[tolower(raw_cov_values) %in% c("", "na", "n/a", "nan", "none", "null")] <- NA
level_values <- unique(raw_cov_values[!is.na(raw_cov_values)])
cov_factor <- factor(raw_cov_values, levels = level_values)
complete_cov <- !is.na(cov_factor)
level_counts <- table(droplevels(cov_factor[complete_cov]))
metareg_summary_file <- file.path(output, paste0("MetaregSummary - {covariate_file_label} - ", outcome, ".txt"))
metareg_status_file <- file.path(output, paste0("MetaregStatus - {covariate_file_label} - ", outcome, ".txt"))
write_metareg_status <- function(status, reason) {{
  writeLines(c(
    paste0("Outcome: ", outcome),
    paste0("Regressor: ", {common.r_string(covariate_label)}),
    "Regressor type: categorical",
    paste0("Status: ", status),
    paste0("Reason: ", reason),
    paste0("Summary file: ", basename(metareg_summary_file))
  ), con = metareg_status_file)
}}
if (random_model && sum(complete_cov) >= 10 && length(level_counts) >= 2 && min(level_counts) >= 2) {{
  metareg_error <- NULL
  tryCatch({{
    data[[{common.r_string(covariate_r_column)}]] <- cov_factor
    mreg.object <- metareg(m.cont, as.formula(paste("~", {common.r_string(covariate_r_column)})))
    writeLines(c(
      paste("Categorical meta-regression for {covariate_label}"),
      "Reference level is the first level by workbook order.",
      "",
      "Level counts:",
      capture.output(level_counts),
      "",
      capture.output(summary(mreg.object))
    ), con = metareg_summary_file)
  }}, error = function(e) {{
    metareg_error <<- conditionMessage(e)
  }})
  if (!is.null(metareg_error)) {{
    reason <- paste("R meta::metareg failed:", metareg_error)
    writeLines(paste("Meta-regression for {covariate_label} was skipped because", reason), con = metareg_summary_file)
    write_metareg_status("failed", reason)
    message(paste("Meta-regression skipped for {covariate_label}:", reason))
  }} else {{
    reason <- "Categorical meta-regression completed; bubble plot was not generated because the moderator is a factor."
    write_metareg_status("completed_no_plot", reason)
  }}
}} else if (!random_model) {{
  reason <- "a common/fixed-effect model was selected."
  writeLines(paste("Meta-regression for {covariate_label} was skipped because", reason), con = metareg_summary_file)
  write_metareg_status("skipped", reason)
  message(paste("Meta-regression skipped for {covariate_label}:", reason))
}} else {{
  reason <- paste(
    "categorical meta-regression needs at least ten studies, at least two categories,",
    "and at least two studies in every retained category; observed counts:",
    paste(names(level_counts), as.integer(level_counts), sep = "=", collapse = ", ")
  )
  writeLines(paste("Meta-regression for {covariate_label} was skipped because", reason), con = metareg_summary_file)
  write_metareg_status("skipped", reason)
  message(paste("Meta-regression skipped for {covariate_label}:", reason))
}}
"""
            continue
        metareg_block += f"""
cov_values <- suppressWarnings(as.numeric(data[[{common.r_string(covariate_r_column)}]]))
metareg_summary_file <- file.path(output, paste0("MetaregSummary - {covariate_file_label} - ", outcome, ".txt"))
metareg_status_file <- file.path(output, paste0("MetaregStatus - {covariate_file_label} - ", outcome, ".txt"))
write_metareg_status <- function(status, reason) {{
  writeLines(c(
    paste0("Outcome: ", outcome),
    paste0("Regressor: ", {common.r_string(covariate_label)}),
    "Regressor type: numeric",
    paste0("Status: ", status),
    paste0("Reason: ", reason),
    paste0("Summary file: ", basename(metareg_summary_file))
  ), con = metareg_status_file)
}}
if (random_model && sum(is.finite(cov_values)) >= 10 && length(unique(cov_values[is.finite(cov_values)])) >= 2) {{
  metareg_error <- NULL
  plot_error <- NULL
  plot_open <- FALSE
  tryCatch({{
    data[[{common.r_string(covariate_r_column)}]] <- cov_values
    mreg.object <- metareg(m.cont, as.formula(paste("~", {common.r_string(covariate_r_column)})))
    capture.output(summary(mreg.object), file = metareg_summary_file)
    tryCatch({{
      png(file = file.path(output, paste0("Metarregression - {covariate_file_label} - ", outcome, ".png")),
          width = 2400, height = 2000, res = 300)
      plot_open <- TRUE
      bubble(mreg.object,
             xlab = {common.r_string(covariate_label)},
             ylab = paste("Effect size (", summary_measure, ")", sep = ""),
             studlab = TRUE,
             bg = "red")
      dev.off()
      plot_open <- FALSE
    }}, error = function(e) {{
      plot_error <<- conditionMessage(e)
      if (plot_open && dev.cur() > 1) {{
        try(dev.off(), silent = TRUE)
        plot_open <<- FALSE
      }}
    }})
  }}, error = function(e) {{
    metareg_error <<- conditionMessage(e)
    if (plot_open && dev.cur() > 1) {{
      try(dev.off(), silent = TRUE)
      plot_open <<- FALSE
    }}
  }})
  if (!is.null(metareg_error)) {{
    reason <- paste("R meta::metareg failed:", metareg_error)
    writeLines(paste("Meta-regression for {covariate_label} was skipped because", reason), con = metareg_summary_file)
    write_metareg_status("failed", reason)
    message(paste("Meta-regression skipped for {covariate_label}:", reason))
  }} else if (!is.null(plot_error)) {{
    reason <- paste("Meta-regression completed, but the bubble plot failed:", plot_error)
    write_metareg_status("completed_with_plot_warning", reason)
    message(paste("Meta-regression plot warning for {covariate_label}:", reason))
  }} else {{
    write_metareg_status("completed", "Meta-regression completed successfully.")
  }}
}} else if (!random_model) {{
  reason <- "a common/fixed-effect model was selected."
  writeLines(paste("Meta-regression for {covariate_label} was skipped because", reason), con = metareg_summary_file)
  write_metareg_status("skipped", reason)
  message(paste("Meta-regression skipped for {covariate_label}:", reason))
}} else {{
  reason <- "fewer than ten finite study-level values or fewer than two unique values were available."
  writeLines(paste("Meta-regression for {covariate_label} was skipped because", reason), con = metareg_summary_file)
  write_metareg_status("skipped", reason)
  message(paste("Meta-regression skipped for {covariate_label}:", reason))
}}
"""

    script = f"""
suppressPackageStartupMessages(library(meta))

output <- {common.r_string(str(output_dir))}
outcome <- {common.r_string(outcome)}
summary_measure <- {common.r_string(summary_measure)}
model_type <- {common.r_string(model_type)}
analysis_engine <- {common.r_string(common.normalize_analysis_engine(analysis_engine))}
tsa_alpha <- {float(tsa_alpha)}
tsa_power <- {float(tsa_power)}
tsa_adjust_for_diversity <- {str(bool(tsa_adjust_for_diversity)).upper()}
tsa_effect_source <- {common.r_string(tsa_effect_source)}
tsa_anticipated_effect <- {("NA_real_" if tsa_anticipated_effect is None else repr(float(tsa_anticipated_effect)))}
tsa_required_information_size <- {("NA_real_" if tsa_required_information_size is None else repr(float(tsa_required_information_size)))}
tsa_favor_top <- {common.r_string(tsa_favor_top_label)}
tsa_favor_bottom <- {common.r_string(tsa_favor_bottom_label)}
random_model <- model_type == "random"
common_model <- model_type == "common"
weight_col <- if (random_model) "w.random" else "w.common"
dir.create(output, recursive = TRUE, showWarnings = FALSE)
{common.bayesian_meta_r_helpers()}
data <- read.csv({common.r_string(str(csv_path))}, check.names = FALSE)
numeric_cols <- c("mean.e","sd.e","median.e","q1.e","q3.e","min.e","max.e","n.e",
                  "mean.c","sd.c","median.c","q1.c","q3.c","min.c","max.c","n.c","covariate")
for (col in intersect(numeric_cols, names(data))) {{
  data[[col]] <- suppressWarnings(as.numeric(data[[col]]))
}}
if ("zero_sd_imputed" %in% names(data)) {{
  data$zero_sd_imputed <- tolower(as.character(data$zero_sd_imputed)) %in% c("true", "1", "yes", "y")
}} else {{
  data$zero_sd_imputed <- FALSE
}}

build_continuous_meta <- function(dataset, method_tau = "REML", method_random_ci = "classic") {{
  metacont(mean.e=mean.e, sd.e=sd.e, n.e=n.e,
           median.e=median.e, q1.e=q1.e, q3.e=q3.e,
           min.e=min.e, max.e=max.e,
           mean.c=mean.c, sd.c=sd.c, n.c=n.c,
           median.c=median.c, q1.c=q1.c, q3.c=q3.c,
           min.c=min.c, max.c=max.c,
           data = dataset,
           studlab = Author,
           sm = summary_measure,
           method.tau = method_tau,
           method.random.ci = method_random_ci,
           method.I2 = "tau2",
           random = random_model,
           common = common_model,
           prediction = random_model,
           method.predict = "V")
}}

meta_metrics <- function(meta_obj, label) {{
  scalar <- function(value) {{
    value <- suppressWarnings(as.numeric(value))
    if (length(value) == 0 || !is.finite(value[1])) return(NA_real_)
    value[1]
  }}
  use_random <- random_model
  i2_value <- scalar(meta_obj$I2)
  if (is.finite(i2_value) && abs(i2_value) <= 1) i2_value <- i2_value * 100
  data.frame(
    Analysis = label,
    Studies = meta_obj$k,
    PooledEffect = scalar(if (use_random) meta_obj$TE.random else meta_obj$TE.common),
    Lower95CI = scalar(if (use_random) meta_obj$lower.random else meta_obj$lower.common),
    Upper95CI = scalar(if (use_random) meta_obj$upper.random else meta_obj$upper.common),
    PValue = scalar(if (use_random) meta_obj$pval.random else meta_obj$pval.common),
    I2Percent = i2_value,
    Tau2 = scalar(meta_obj$tau2),
    stringsAsFactors = FALSE
  )
}}

m.cont <- build_continuous_meta(data)

capture.output(summary(m.cont), file = file.path(output, paste0("Summary", outcome, ".txt")))
saveRDS(m.cont, file = file.path(output, paste0("MetaObject", outcome, ".rds")))
{common.bayesian_meta_r_call("m.cont", 'paste0(summary_measure, " - ", outcome)', "FALSE", note="Bayesian continuous synthesis uses study-level MD/SMD effects and standard errors from meta::metacont.")}

write_random_effects_sensitivity <- function(primary_meta, dataset) {{
  sensitivity_txt <- file.path(output, paste0("RandomEffectsSensitivity", outcome, ".txt"))
  sensitivity_csv <- file.path(output, paste0("RandomEffectsSensitivity", outcome, ".csv"))
  if (!random_model) {{
    writeLines(
      "Random-effects tau estimator / confidence interval sensitivity checks were skipped because a common-effect model was selected.",
      con = sensitivity_txt
    )
    return(invisible(NULL))
  }}
  sensitivity_specs <- data.frame(
    Analysis = c(
      "Primary REML + classic CI",
      "Sensitivity REML + Hartung-Knapp CI",
      "Sensitivity Paule-Mandel + Hartung-Knapp CI",
      "Sensitivity DerSimonian-Laird + classic CI"
    ),
    MethodTau = c("REML", "REML", "PM", "DL"),
    RandomEffectsCI = c("classic", "HK", "HK", "classic"),
    SummaryFileLabel = c(
      "Primary REML Classic",
      "Sensitivity REML Hartung-Knapp",
      "Sensitivity Paule-Mandel Hartung-Knapp",
      "Sensitivity DerSimonian-Laird Classic"
    ),
    stringsAsFactors = FALSE
  )
  rows <- list()
  for (i in seq_len(nrow(sensitivity_specs))) {{
    spec <- sensitivity_specs[i, , drop = FALSE]
    fit <- try(
      build_continuous_meta(
        dataset,
        method_tau = spec$MethodTau,
        method_random_ci = spec$RandomEffectsCI
      ),
      silent = TRUE
    )
    if (inherits(fit, "try-error")) {{
      rows[[i]] <- data.frame(
        Analysis = spec$Analysis,
        Studies = NA_real_,
        PooledEffect = NA_real_,
        Lower95CI = NA_real_,
        Upper95CI = NA_real_,
        PValue = NA_real_,
        I2Percent = NA_real_,
        Tau2 = NA_real_,
        MethodTau = spec$MethodTau,
        RandomEffectsCI = spec$RandomEffectsCI,
        Status = paste("failed:", as.character(fit)[1]),
        stringsAsFactors = FALSE
      )
    }} else {{
      capture.output(
        summary(fit),
        file = file.path(output, paste0(spec$SummaryFileLabel, " - ", outcome, ".txt"))
      )
      rows[[i]] <- cbind(
        meta_metrics(fit, spec$Analysis),
        MethodTau = spec$MethodTau,
        RandomEffectsCI = spec$RandomEffectsCI,
        Status = "completed"
      )
    }}
  }}
  sensitivity <- do.call(rbind, rows)
  primary_effect <- sensitivity$PooledEffect[1]
  primary_i2 <- sensitivity$I2Percent[1]
  sensitivity$PooledEffectChangeVsPrimary <- sensitivity$PooledEffect - primary_effect
  sensitivity$I2ChangeVsPrimary <- sensitivity$I2Percent - primary_i2
  write.csv(sensitivity, file = sensitivity_csv, row.names = FALSE)
  capture.output(
    {{
      cat("Random-effects tau estimator / confidence interval sensitivity checks\\n")
      cat("Primary analysis remains REML + classic CI. Sensitivity rows are for robustness checks only.\\n\\n")
      print(sensitivity)
    }},
    file = sensitivity_txt
  )
}}

write_random_effects_sensitivity(m.cont, data)

if (any(data$zero_sd_imputed, na.rm = TRUE)) {{
  imputed_studies <- unique(data$Author[data$zero_sd_imputed])
  sensitivity_data <- data[!data$zero_sd_imputed, , drop = FALSE]
  writeLines(
    c(
      "Zero-SD imputation sensitivity analysis",
      "Primary analysis: zero SD values were replaced with 0.1.",
      "Sensitivity analysis: studies with any zero-SD imputation were excluded.",
      paste("Excluded studies:", paste(imputed_studies, collapse = "; "))
    ),
    con = file.path(output, paste0("ZeroSDImputationAssumption", outcome, ".txt"))
  )
  if (nrow(sensitivity_data) >= 2) {{
    m.cont.no_zero_sd <- build_continuous_meta(sensitivity_data)
    capture.output(
      summary(m.cont.no_zero_sd),
      file = file.path(output, paste0("SensitivityExcludingZeroSD", outcome, ".txt"))
    )
    impact <- rbind(
      meta_metrics(m.cont, "Primary with SD=0 imputed as 0.1"),
      meta_metrics(m.cont.no_zero_sd, "Sensitivity excluding zero-SD-imputed studies")
    )
    impact$PooledEffectChangeVsPrimary <- impact$PooledEffect - impact$PooledEffect[1]
    impact$I2ChangeVsPrimary <- impact$I2Percent - impact$I2Percent[1]
    write.csv(
      impact,
      file = file.path(output, paste0("ZeroSDImputationImpact", outcome, ".csv")),
      row.names = FALSE
    )
    capture.output(
      impact,
      file = file.path(output, paste0("ZeroSDImputationImpact", outcome, ".txt"))
    )
  }} else {{
    writeLines(
      "Sensitivity analysis excluding zero-SD-imputed studies was not run because fewer than two studies remained.",
      con = file.path(output, paste0("SensitivityExcludingZeroSD", outcome, ".txt"))
    )
  }}
}}

plot_width <- 3800
plot_height <- max(1900, 1100 + 95 * nrow(data))
png(file = file.path(output, paste0("Forestplot", outcome, ".png")),
    width = plot_width,
    height = plot_height,
    res = 300)

forest(m.cont,
       layout = "Revman5",
       sortvar = TE,
       label.e = {common.r_string(intervention_label)},
       label.c = {common.r_string(control_label)},
       label.left = paste("Favors", {common.r_string(favor_left_label)}),
       label.right = paste("Favors", {common.r_string(favor_right_label)}),
       leftcols = c("studlab", "mean.e", "sd.e", "n.e", "mean.c", "sd.c", "n.c", weight_col, "effect", "ci"),
       leftlabs = c("Studies", "Mean", "SD", "Total", "Mean", "SD", "Total", "Weight (%)", summary_measure, "95% CI"),
       test.overall.random = random_model,
       test.overall.common = common_model,
       colgap = "3mm",
       colgap.forest.left = "8mm",
       colgap.forest.right = "8mm",
       digits = 2,
       digits.sd = 2,
       digits.pval = 2,
       pooled.totals = TRUE,
       col.square = "darkblue",
       col.square.lines = "black",
       overall = {str(not subgroup_only).upper()},
       overall.hetstat = {str(not subgroup_only).upper()},
       fontsize = 8.5,
       fs.study = 8,
       fs.heading = 8.5,
       fs.axis = 8,
       spacing = 0.9,
       just.studlab = "left")
dev.off()

{subgroup_block}

if ({str(not subgroup_only).upper()}) {{

meta_loo <- tryCatch(
  metainf(m.cont, pooled = if (random_model) "random" else "common"),
  error = function(e) {{
    note <- paste("Leave-one-out sensitivity analysis skipped:", conditionMessage(e))
    writeLines(note, con = file.path(output, paste0("LeaveOneOutSummary", outcome, ".txt")))
    message(note)
    NULL
  }}
)

if (!is.null(meta_loo)) {{
capture.output(summary(meta_loo), file = file.path(output, paste0("LeaveOneOutSummary", outcome, ".txt")))
png(file = file.path(output, paste0("Leave-one-out", outcome, ".png")),
    width = plot_width,
    height = plot_height,
    res = 300)
forest(meta_loo,
       col.bg = "lightblue",
       col.diamond = "gray",
       xlab = paste("Favors", {common.r_string(favor_left_label)}, "   Favors", {common.r_string(favor_right_label)}),
       ff.xlab = "bold",
       rightcols = c("effect", "ci", "I2", "pval"),
       colgap.right = "6mm",
       just = "center",
       fontsize = 8.5,
       fs.study = 8,
       fs.axis = 8,
       spacing = 0.9)
dev.off()
}}

png(file = file.path(output, paste0("FunnelPlot", outcome, ".png")),
    width = 2200,
    height = 2000,
    res = 300)
funnel(m.cont,
       studlab = FALSE,
       bg = "red",
       cex = 2,
       cex.studlab = 1,
       random = random_model,
       common = common_model,
       backtransf = FALSE)
dev.off()

if (m.cont$k >= 2) {{
  tmp_baujat <- tempfile(fileext = ".png")
  png(file = tmp_baujat, width = 400, height = 400)
  baujat_coords <- try(baujat(m.cont,
                              pooled = if (random_model) "random" else "common",
                              studlab = FALSE), silent = TRUE)
  dev.off()
  unlink(tmp_baujat)

  if (!inherits(baujat_coords, "try-error") && is.data.frame(baujat_coords) && nrow(baujat_coords) > 0) {{
    label_xmin <- if (nrow(baujat_coords) > 8) stats::quantile(baujat_coords$x, 0.75, na.rm = TRUE) else 0
    label_ymin <- if (nrow(baujat_coords) > 8) stats::quantile(baujat_coords$y, 0.75, na.rm = TRUE) else 0
    png(file = file.path(output, paste0("BaujatPlot", outcome, ".png")),
        width = 2400,
        height = 2200,
        res = 300)
    try(baujat(m.cont,
               pooled = if (random_model) "random" else "common",
               studlab = TRUE,
               cex = 1.3,
               cex.studlab = 0.75,
               pch = 21,
               col = "black",
               bg = "steelblue",
               xmin = label_xmin,
               ymin = label_ymin,
               xlab = "Contribution to overall heterogeneity",
               ylab = "Influence on pooled effect"), silent = TRUE)
    dev.off()
    write.csv(baujat_coords,
              file = file.path(output, paste0("BaujatCoordinates", outcome, ".csv")),
              row.names = FALSE)
    capture.output(baujat_coords,
                   file = file.path(output, paste0("BaujatCoordinates", outcome, ".txt")))
  }} else {{
    writeLines("Baujat plot skipped: insufficient valid data for contribution analysis.",
               con = file.path(output, paste0("BaujatCoordinates", outcome, ".txt")))
  }}
}}


if (m.cont$k >= 10) {{
  capture.output(metabias(m.cont, method.bias = "Egger", plotit = FALSE),
                 file = file.path(output, paste0("EggerTest", outcome, ".txt")))
  png(file = file.path(output, paste0("EggerTest", outcome, ".png")),
      width = 2200,
      height = 2000,
      res = 300)
  metabias(m.cont, method.bias = "Egger", plotit = TRUE)
  dev.off()
}}

}} # end if not subgroup_only

{continuous_tsa_r_code()}

{metareg_block}

writeLines(c(
  paste("Outcome:", outcome),
  paste("Studies:", m.cont$k),
  paste("Effect size:", summary_measure),
  paste("Statistical model:", model_type),
  paste("Analysis engine:", analysis_engine),
  paste("Output:", output)
), con = file.path(output, "run-info.txt"))
"""
    script_path.write_text(textwrap.dedent(script).strip() + "\n", encoding="utf-8")


def parse_overall_summary(summary_text: str) -> dict[str, str]:
    result: dict[str, str] = {}
    patterns = {
        "studies": r"Number of studies:\s+k\s+=\s+(\d+)",
        "observations": r"Number of observations:\s+(.+)",
        "heterogeneity": r"(tau\^2\s+=\s+.+)",
        "i2": r"(I\^2\s+=\s+.+)",
        "q": r"Test of heterogeneity:\s*\n\s*Q\s+d\.f\.\s+p-value\s*\n\s*([^\n]+)",
    }
    for key, pattern in patterns.items():
        match = re.search(pattern, summary_text, flags=re.I)
        if match:
            result[key] = " ".join(match.group(1).split())
    model_match = re.search(
        r"((?:Random effects|Common effect|Fixed effect) model)\s+"
        r"([-0-9.]+)\s+\[([-0-9.;\s]+)\]\s+([-0-9.]+)\s+([<>=]?\s*[0-9.]+)",
        summary_text,
        flags=re.I,
    )
    if model_match:
        result.update(
            {
                "model": model_match.group(1),
                "effect": model_match.group(2),
                "ci": "[" + " ".join(model_match.group(3).split()) + "]",
                "z": model_match.group(4),
                "p": " ".join(model_match.group(5).split()),
            }
        )
    return result


def parse_study_estimates(summary_text: str) -> list[dict[str, str]]:
    rows = []
    for line in summary_text.splitlines():
        match = re.match(r"^(.+?)\s+([-0-9.]+)\s+\[([-0-9.;\s]+)\]\s+([0-9.]+)\s*$", line)
        if match and not match.group(1).lower().startswith(("random", "common", "fixed", "prediction")):
            rows.append(
                {
                    "Study": match.group(1).strip(),
                    "Effect": match.group(2),
                    "95% CI": "[" + " ".join(match.group(3).split()) + "]",
                    "Weight (%)": match.group(4),
                }
            )
    return rows


def format_p_clause(value: str) -> str:
    p_value = str(value or "[p-value]").strip()
    if p_value.startswith(("<", ">", "=")):
        return f"p {p_value}"
    return f"p = {p_value}"


def generate_summary_document(output_dir: Path, mapping: dict[str, Any], r_df: pd.DataFrame) -> Path:
    try:
        from docx import Document
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        from docx.shared import Inches, Pt, RGBColor
    except ImportError as exc:
        raise SystemExit(f"python-docx is required to create the manuscript summary document: {exc}") from exc

    outcome = str(mapping.get("outcome_name") or "continuous outcome")
    safe_outcome = common.sanitize_filename(outcome)
    output_stem = str(mapping.get("outcome_file_stem") or safe_outcome)
    summary_text = common.read_text_if_exists(output_dir / f"Summary{output_stem}.txt")
    overall = parse_overall_summary(summary_text)
    study_rows = parse_study_estimates(summary_text)
    subgroup_files = sorted(output_dir.glob(f"SubgroupSummary*{output_stem}.txt"))
    leave_one_out_text = common.read_text_if_exists(output_dir / f"LeaveOneOutSummary{output_stem}.txt")
    egger_text = common.extract_egger_text(output_dir, output_stem)

    document = Document()
    section = document.sections[0]
    section.top_margin = Inches(0.65)
    section.bottom_margin = Inches(0.65)
    section.left_margin = Inches(0.65)
    section.right_margin = Inches(0.65)
    styles = document.styles
    styles["Normal"].font.name = "Arial"
    styles["Normal"].font.size = Pt(9.5)
    styles["Heading 1"].font.name = "Arial"
    styles["Heading 1"].font.size = Pt(15)
    styles["Heading 1"].font.bold = True
    styles["Heading 1"].font.color.rgb = RGBColor(31, 78, 121)
    styles["Heading 2"].font.name = "Arial"
    styles["Heading 2"].font.size = Pt(12)
    styles["Heading 2"].font.bold = True
    styles["Heading 2"].font.color.rgb = RGBColor(31, 78, 121)

    title = document.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = title.add_run("Continuous Outcome Meta-Analysis Results Summary")
    run.bold = True
    run.font.size = Pt(17)
    subtitle = document.add_paragraph()
    subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
    subtitle.add_run(f"Outcome: {outcome}").italic = True

    analysis = mapping["analysis"]
    document.add_heading("Manuscript-Ready Results Draft", level=1)
    document.add_paragraph(
        f"For {outcome}, {overall.get('studies', 'the included')} studies were included. "
        f"Using {analysis['summary_measure']} as the effect measure and a {analysis['model_type']} model, "
        f"the {overall.get('model', 'pooled model').lower()} estimated a pooled effect of "
        f"{overall.get('effect', '[effect]')} {overall.get('ci', '[95% CI]')} "
        f"({format_p_clause(overall.get('p', '[p-value]'))}). Heterogeneity was quantified as "
        f"{overall.get('i2') or overall.get('heterogeneity', 'reported in the table below')}. "
        f"Data format: {analysis['data_format']}; median handling: {analysis['median_handling']}. "
        f"Subgroup analyses were generated for {len(subgroup_files)} subgroup variable(s). "
        f"Leave-one-out sensitivity analysis was {'generated' if leave_one_out_text.strip() else 'not available'}. "
        f"Small-study effects/publication bias assessment: {egger_text}"
    )

    document.add_heading("Analysis Decisions", level=1)
    common.add_docx_table(
        document,
        ["Decision", "Selected", "Reason"],
        [
            ["Effect measure", analysis["summary_measure"], analysis["summary_measure_reason"]],
            ["Data format", analysis["data_format"], analysis["data_format_reason"]],
            ["Median handling", analysis["median_handling"], analysis["median_handling_reason"]],
            ["Statistical model", analysis["model_type"], analysis["model_type_reason"]],
            ["Outcome direction", analysis["outcome_direction"], analysis["favor_label_reason"]],
            ["Left/right labels", f"Left: Favors {analysis['favor_left']}; Right: Favors {analysis['favor_right']}", ""],
            [
                "Trial sequential analysis",
                (
                    f"alpha {analysis['tsa_alpha']}; power {analysis['tsa_power']}; "
                    f"{'diversity-adjusted RIS' if analysis['tsa_adjust_for_diversity'] else 'heterogeneity-adjusted RIS (tau2)'}; "
                    f"effect source {analysis['tsa_effect_source']}"
                    + (
                        f"; RIS override {analysis['tsa_required_information_size']}"
                        if analysis.get("tsa_required_information_size")
                        else ""
                    )
                ),
                analysis["tsa_reason"],
            ],
            ["TSA favor labels", f"Top: Favours {analysis['tsa_favor_top']}; Bottom: Favours {analysis['tsa_favor_bottom']}", ""],
        ],
    )

    document.add_heading("Overall Pooled Analysis", level=1)
    common.add_docx_table(
        document,
        ["Metric", "Result"],
        [
            ["Studies", overall.get("studies", "")],
            ["Observations", overall.get("observations", "")],
            ["Model", overall.get("model", "")],
            ["Pooled effect", overall.get("effect", "")],
            ["95% CI", overall.get("ci", "")],
            ["Z / P value", f"{overall.get('z', '')} / {overall.get('p', '')}".strip(" /")],
            ["Heterogeneity", overall.get("heterogeneity", "")],
            ["I² / H", overall.get("i2", "")],
            ["Q test", overall.get("q", "")],
        ],
    )

    random_effects_sensitivity_csv = output_dir / f"RandomEffectsSensitivity{output_stem}.csv"
    random_effects_sensitivity_txt = output_dir / f"RandomEffectsSensitivity{output_stem}.txt"
    if random_effects_sensitivity_csv.exists() or random_effects_sensitivity_txt.exists():
        document.add_heading("Random-Effects Method Sensitivity Checks", level=1)
        document.add_paragraph(
            "Primary analysis remains REML with a classic random-effects confidence interval. "
            "The sensitivity checks compare Hartung-Knapp confidence intervals and alternative tau² estimators."
        )
        if random_effects_sensitivity_csv.exists():
            sensitivity_df = pd.read_csv(random_effects_sensitivity_csv)
            common.add_docx_table(document, list(sensitivity_df.columns), sensitivity_df.values.astype(str).tolist())
        elif random_effects_sensitivity_txt.exists():
            common.add_preformatted_block(document, common.read_text_if_exists(random_effects_sensitivity_txt), max_chars=5000)

    zero_sd_assumption = common.read_text_if_exists(output_dir / f"ZeroSDImputationAssumption{output_stem}.txt")
    zero_sd_impact = common.read_text_if_exists(output_dir / f"ZeroSDImputationImpact{output_stem}.txt")
    zero_sd_sensitivity = common.read_text_if_exists(output_dir / f"SensitivityExcludingZeroSD{output_stem}.txt")
    if zero_sd_assumption or zero_sd_impact or zero_sd_sensitivity:
        document.add_heading("Zero-SD Imputation Sensitivity Analysis", level=1)
        if zero_sd_assumption:
            document.add_paragraph(zero_sd_assumption)
        impact_csv = output_dir / f"ZeroSDImputationImpact{output_stem}.csv"
        if impact_csv.exists():
            impact_df = pd.read_csv(impact_csv)
            common.add_docx_table(document, list(impact_df.columns), impact_df.values.astype(str).tolist())
        elif zero_sd_impact:
            common.add_preformatted_block(document, zero_sd_impact, max_chars=4000)
        if zero_sd_sensitivity:
            document.add_paragraph("Sensitivity analysis output excluding zero-SD-imputed studies:")
            common.add_preformatted_block(document, zero_sd_sensitivity, max_chars=5000)

    if study_rows:
        document.add_heading("Study-Level Effect Estimates", level=1)
        common.add_docx_table(document, ["Study", "Effect", "95% CI", "Weight (%)"], [[r["Study"], r["Effect"], r["95% CI"], r["Weight (%)"]] for r in study_rows])

    document.add_heading("Subgroup Analysis", level=1)
    if subgroup_files:
        for subgroup_file in subgroup_files:
            document.add_heading(subgroup_file.stem.replace("SubgroupSummary - ", ""), level=2)
            common.add_preformatted_block(document, common.read_text_if_exists(subgroup_file), max_chars=6000)
    else:
        document.add_paragraph("No subgroup analysis was generated.")

    document.add_heading("Leave-One-Out Sensitivity Analysis", level=1)
    common.add_preformatted_block(document, leave_one_out_text, max_chars=8000)

    document.add_heading("Baujat Influence Diagnostics", level=1)
    baujat_path = output_dir / f"BaujatCoordinates{output_stem}.csv"
    if baujat_path.exists():
        baujat_df = pd.read_csv(baujat_path)
        if {"x", "y"}.issubset(baujat_df.columns):
            baujat_df = baujat_df.sort_values(["x", "y"], ascending=False)
        document.add_paragraph(
            "The Baujat plot shows each study's contribution to overall heterogeneity on the x-axis "
            "and influence on the pooled effect on the y-axis."
        )
        common.add_docx_table(
            document,
            ["Study", "Contribution to Heterogeneity", "Influence on Pooled Effect"],
            [
                [
                    row.get("studlab", ""),
                    f"{float(row.get('x', 0)):.4f}",
                    f"{float(row.get('y', 0)):.4f}",
                ]
                for _, row in baujat_df.head(25).iterrows()
            ],
        )
    else:
        document.add_paragraph("Baujat diagnostics were not available.")

    document.add_heading("Trial Sequential Analysis", level=1)
    tsa_dir = output_dir / f"TSA {output_stem}"
    tsa_parameters_path = tsa_dir / f"TSAParameters{output_stem}.csv"
    tsa_z_path = tsa_dir / f"TSAZCurveData{output_stem}.csv"
    if tsa_parameters_path.exists():
        tsa_parameters = pd.read_csv(tsa_parameters_path)
        common.add_docx_table(document, ["Parameter", "Value"], tsa_parameters.values.astype(str).tolist())
        if tsa_z_path.exists():
            tsa_z = pd.read_csv(tsa_z_path)
            document.add_paragraph("Cumulative Z-curve data are shown below for audit and manuscript drafting.")
            common.add_docx_table(
                document,
                ["Study", "Cumulative information", "Cumulative Z"],
                [
                    [
                        row.get("Study", ""),
                        f"{float(row.get('CumulativeInformation', 0)):.0f}",
                        f"{float(row.get('CumulativeZ', 0)):.3f}",
                    ]
                    for _, row in tsa_z.iterrows()
                ],
            )
    else:
        tsa_notes_path = tsa_dir / f"TSANotes{output_stem}.txt"
        if tsa_notes_path.exists():
            document.add_paragraph(tsa_notes_path.read_text(encoding="utf-8", errors="replace"))
        else:
            document.add_paragraph("Trial sequential analysis output was not available.")

    document.add_heading("Small-Study Effects / Publication Bias", level=1)
    document.add_paragraph(egger_text)

    document.add_heading("Generated Figures and Files", level=1)
    common.add_docx_table(
        document,
        ["Figure", "File path"],
        [[str(path.relative_to(output_dir)), str(path)] for path in sorted(output_dir.rglob("*.png"))],
    )

    document.add_heading("Extracted Analysis Dataset", level=1)
    preview_df = r_df.head(60).copy()
    if len(r_df) > 60:
        document.add_paragraph(f"Showing the first 60 of {len(r_df)} rows. See extracted-continuous-data.csv for the full dataset.")
    common.add_docx_table(document, list(preview_df.columns), preview_df.values.astype(str).tolist())

    document.add_heading("Reporting Guidance Note", level=1)
    document.add_paragraph(
        "For continuous outcomes, MD is used when studies share the same scale/unit; SMD is used when the same "
        "construct is measured on different scales. Median/IQR or range conversion should be reviewed for skewness "
        "and clinical appropriateness before manuscript submission."
    )
    docx_path = output_dir / f"Manuscript Results Summary - {safe_outcome}.docx"
    document.save(docx_path)
    return docx_path


def main() -> None:
    parser = argparse.ArgumentParser(description="Run continuous endpoint meta-analysis from Excel.")
    parser.add_argument("excel", type=Path, nargs="?", help="Input Excel workbook.")
    parser.add_argument("--sheet", help="Sheet name to analyze.")
    parser.add_argument("--outcome", help="Outcome name used in output filenames/titles.")
    parser.add_argument("--output-dir", type=Path, help="Output folder. Defaults beside the Excel file using the sheet name.")
    parser.add_argument("--preview-rows", type=int, default=20)
    parser.add_argument("--yes", action="store_true", help="Accept detected mapping and run non-interactively.")
    parser.add_argument("--no-lmstudio", action="store_true", help="Skip LMStudio and use name matching.")
    parser.add_argument("--mapping-json", type=Path, help="Use a previously reviewed mapping/analysis JSON file.")
    parser.add_argument("--install-r-packages", action="store_true", help="Install missing CRAN R packages before running R.")
    parser.add_argument(
        "--engine",
        choices=["auto", "frequentist", "bayesian", "both"],
        default="auto",
        help="Analysis engine. Auto uses the LLM/heuristic recommendation; Bayesian adds bayesmeta posterior outputs.",
    )
    parser.add_argument("--group-column", help="Primary subgroup/group column name or number. Included first in subgroup analyses.")
    parser.add_argument("--subgroup-columns", help="Comma-separated subgroup column names or numbers. Use 'none' to clear.")
    parser.add_argument("--covariate-columns", help="Comma-separated meta-regression covariate column names or numbers. Use 'none' to clear.")
    parser.add_argument("--intervention-label", help="Override the intervention/experimental arm label used in plots.")
    parser.add_argument("--control-label", help="Override the control/comparator arm label used in plots.")
    parser.add_argument("--tsa-alpha", type=float, help="Override the two-sided TSA alpha, e.g. --tsa-alpha 0.05.")
    parser.add_argument("--tsa-power", type=float, help="Override TSA power, e.g. --tsa-power 0.90.")
    parser.add_argument("--tsa-ris", type=float, help="Override the calculated TSA required information size, e.g. --tsa-ris 1068.")
    parser.add_argument("--lmstudio-url", default="http://localhost:1234/v1")
    parser.add_argument("--model", help="LMStudio model id.")

    args = parser.parse_args()

    if args.excel is None:
        args.excel = common.prompt_for_excel_path()
    args.excel = args.excel.expanduser().resolve()
    common.save_last_used_path(args.excel)
    if not args.excel.exists():
        raise SystemExit(f"Excel workbook not found: {args.excel}")

    _, summary = common.workbook_summary(args.excel)
    sheet_name = common.choose_sheet(summary, args.sheet, args.yes)
    if sheet_name not in summary:
        raise SystemExit(f"Sheet not found: {sheet_name}")
    df = common.load_sheet(args.excel, sheet_name=sheet_name)
    columns = [str(col) for col in df.columns]
    df.columns = columns

    mapping = None
    lm_mapping = None
    mapping_json_has_analysis = False
    if args.mapping_json:
        mapping = json.loads(args.mapping_json.expanduser().read_text(encoding="utf-8"))
        mapping_json_has_analysis = bool(mapping.get("analysis"))
        mapping["sheet_name"] = mapping.get("sheet_name") or sheet_name
        mapping["outcome_name"] = args.outcome or mapping.get("outcome_name") or sheet_name
    elif not args.no_lmstudio:
        selected_summary = {sheet_name: summary[sheet_name]}
        print(f"\nSending sheet '{sheet_name}' to LMStudio for continuous endpoint extraction...")
        lm_mapping = call_lmstudio(selected_summary, args.lmstudio_url, args.model)

    if mapping is None:
        mapping = merge_mapping(columns, sheet_name, lm_mapping, args.outcome)
        if args.intervention_label:
            mapping["intervention_label"] = args.intervention_label
        if args.control_label:
            mapping["control_label"] = args.control_label
        mapping = prompt_for_mapping(mapping, columns, args.yes)
    if args.intervention_label:
        mapping["intervention_label"] = args.intervention_label
    if args.control_label:
        mapping["control_label"] = args.control_label
    mapping = common.apply_column_overrides(
        mapping,
        columns,
        group_column=args.group_column,
        subgroup_columns=args.subgroup_columns,
        covariate_columns=args.covariate_columns,
    )
    common.refresh_arm_labels_from_columns(mapping)
    common.prompt_for_arm_labels_if_needed(mapping, args.yes)
    mapping["analysis"] = normalize_analysis(mapping.get("analysis") or {}, mapping)
    r_df = validate_data(df, mapping)
    if not mapping_json_has_analysis:
        mapping["analysis"] = infer_analysis_from_data(r_df, mapping, lm_mapping)
        mapping["analysis"] = normalize_analysis(mapping["analysis"], mapping)
    if args.tsa_alpha is not None:
        if not 0.0001 <= args.tsa_alpha <= 0.5:
            raise SystemExit("--tsa-alpha must be between 0.0001 and 0.5.")
        mapping["analysis"]["tsa_alpha"] = args.tsa_alpha
        mapping["analysis"]["tsa_reason"] = "TSA alpha was provided with --tsa-alpha."
    if args.tsa_power is not None:
        if not 0.5 <= args.tsa_power <= 0.999:
            raise SystemExit("--tsa-power must be between 0.5 and 0.999.")
        mapping["analysis"]["tsa_power"] = args.tsa_power
        mapping["analysis"]["tsa_reason"] = "TSA power was provided with --tsa-power."
    mapping["analysis"] = normalize_analysis(mapping.get("analysis") or {}, mapping)
    if args.engine != "auto":
        mapping["analysis"]["analysis_engine"] = args.engine
        mapping["analysis"]["analysis_engine_reason"] = f"Applied from --engine {args.engine}."
        mapping["analysis"] = normalize_analysis(mapping.get("analysis") or {}, mapping)
    else:
        mapping = common.apply_auto_analysis_engine_recommendation(mapping, r_df, analysis_type="continuous")
        mapping["analysis"] = normalize_analysis(mapping.get("analysis") or {}, mapping)
    if not mapping_json_has_analysis:
        mapping["analysis"] = prompt_for_analysis_choices(mapping["analysis"], args.yes)
        mapping["analysis"] = normalize_analysis(mapping.get("analysis") or {}, mapping)
    else:
        prompt_for_analysis_choices(mapping["analysis"], True)
    if args.engine != "auto":
        mapping["analysis"]["analysis_engine"] = args.engine
        mapping["analysis"]["analysis_engine_reason"] = f"Applied from --engine {args.engine}."
    else:
        mapping = common.apply_auto_analysis_engine_recommendation(mapping, r_df, analysis_type="continuous")
    if args.tsa_alpha is not None:
        mapping["analysis"]["tsa_alpha"] = args.tsa_alpha
        mapping["analysis"]["tsa_reason"] = "TSA alpha was provided with --tsa-alpha."
    if args.tsa_power is not None:
        mapping["analysis"]["tsa_power"] = args.tsa_power
        mapping["analysis"]["tsa_reason"] = "TSA power was provided with --tsa-power."
    if args.tsa_ris is not None:
        mapping["analysis"]["tsa_required_information_size"] = args.tsa_ris
        mapping["analysis"]["tsa_reason"] = "Required information size was provided with --tsa-ris."
    mapping["analysis"] = normalize_analysis(mapping.get("analysis") or {}, mapping)

    output_dir = args.output_dir.expanduser().resolve() if args.output_dir else (args.excel.parent / common.sanitize_filename(sheet_name)).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    mapping_path = output_dir / "identified-columns.json"
    extracted_path = output_dir / "extracted-continuous-data.csv"
    if mapping.get("zero_sd_imputations"):
        pd.DataFrame(mapping["zero_sd_imputations"]).to_csv(output_dir / "zero-sd-imputation-assumptions.csv", index=False)
        (output_dir / "zero-sd-imputation-assumptions.txt").write_text(
            str(mapping.get("zero_sd_assumption") or "")
            + "\n\nImputed rows are listed in zero-sd-imputation-assumptions.csv.\n",
            encoding="utf-8",
        )
    outcome_display = str(mapping.get("outcome_name") or "continuous outcome")
    outcome_file_stem = common.sanitize_filename(outcome_display, "continuous outcome")
    mapping["outcome_file_stem"] = outcome_file_stem
    common.write_covariate_skip_status_files(output_dir, outcome_file_stem, mapping.get("covariate_skip_notes"))
    mapping_path.write_text(json.dumps(mapping, indent=2, default=str), encoding="utf-8")
    show_extracted_data(r_df, args.preview_rows, args.yes, extracted_path)

    with tempfile.TemporaryDirectory(prefix="continuous-outcome-") as tmp:
        script_path = Path(tmp) / "run_continuous_meta.R"
        write_r_script(
            script_path=script_path,
            csv_path=extracted_path,
            output_dir=output_dir,
            outcome=outcome_file_stem,
            intervention_label=common.plot_safe_label(mapping.get("intervention_label") or "Experimental"),
            control_label=common.plot_safe_label(mapping.get("control_label") or "Control"),
            subgroup_info=[
                item for item in mapping.get("subgroup_r_columns", [])
                if item.get("r_column") in r_df.columns and r_df[item["r_column"]].notna().any()
            ],
            covariate_info=[
                item for item in mapping.get("covariate_r_columns", [])
                if item.get("r_column") in r_df.columns
                and r_df[item["r_column"]].notna().any()
            ],
            summary_measure=mapping["analysis"]["summary_measure"],
            model_type=mapping["analysis"]["model_type"],
            analysis_engine=mapping["analysis"]["analysis_engine"],
            favor_left_label=common.plot_safe_label(mapping["analysis"]["favor_left"]),
            favor_right_label=common.plot_safe_label(mapping["analysis"]["favor_right"]),
            tsa_favor_top_label=common.plot_safe_label(mapping["analysis"]["tsa_favor_top"]),
            tsa_favor_bottom_label=common.plot_safe_label(mapping["analysis"]["tsa_favor_bottom"]),
            tsa_alpha=mapping["analysis"]["tsa_alpha"],
            tsa_power=mapping["analysis"]["tsa_power"],
            tsa_adjust_for_diversity=mapping["analysis"]["tsa_adjust_for_diversity"],
            tsa_effect_source=mapping["analysis"]["tsa_effect_source"],
            tsa_anticipated_effect=mapping["analysis"]["tsa_anticipated_effect"],
            tsa_required_information_size=mapping["analysis"]["tsa_required_information_size"],
            subgroup_only=mapping["analysis"].get("subgroup_only", False),
        )
        common.run_r(
            script_path,
            install_packages=args.install_r_packages,
            packages=common.analysis_engine_packages(mapping["analysis"]["analysis_engine"]),
        )
        run_continuous_tsa_analysis(
            data=r_df,
            output_dir=output_dir,
            outcome=outcome_file_stem,
            summary_measure=mapping["analysis"]["summary_measure"],
            model_type=mapping["analysis"]["model_type"],
            tsa_alpha=mapping["analysis"]["tsa_alpha"],
            tsa_power=mapping["analysis"]["tsa_power"],
            tsa_adjust_for_diversity=mapping["analysis"]["tsa_adjust_for_diversity"],
            tsa_effect_source=mapping["analysis"]["tsa_effect_source"],
            tsa_anticipated_effect=mapping["analysis"]["tsa_anticipated_effect"],
            tsa_required_information_size=mapping["analysis"]["tsa_required_information_size"],
            subgroup_only=mapping["analysis"].get("subgroup_only", False),
        )
        common.crop_output_pngs(output_dir)
        summary_docx = generate_summary_document(output_dir, mapping, r_df)
        shutil.copyfile(script_path, output_dir / "generated_continuous_meta_analysis.R")

    print(f"\nDone. Outputs saved to: {output_dir}")
    print(f"Column mapping saved to: {mapping_path}")
    print(f"Manuscript summary saved to: {summary_docx}")


if __name__ == "__main__":
    main()
