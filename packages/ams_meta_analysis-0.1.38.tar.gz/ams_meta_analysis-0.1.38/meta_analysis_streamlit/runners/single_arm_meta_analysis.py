#!/usr/bin/env python3
"""Run single-arm proportion or mean meta-analysis from Excel through R.

Python handles workbook loading, LMStudio-assisted column mapping, validation,
output organization, plot cropping, and a compact manuscript-summary document.
R performs the statistical workflow with meta::metaprop or meta::metamean,
following the templates in the Single Proportions and Single Means folders.
"""

from __future__ import annotations

import argparse
import json
import math
import re
import sys
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any

import pandas as pd

import binary_outcome as common


OUTCOME_TYPES = {"proportion", "mean"}
REQUIRED_FIELDS = {
    "proportion": ["study_label", "event", "n"],
    "mean": ["study_label", "n", "mean", "sd"],
}
OPTIONAL_FIELDS = ["covariate"]
FIELD_LABELS = {
    "study_label": "Study label / Author",
    "event": "Events",
    "n": "Total sample size",
    "mean": "Mean",
    "sd": "Standard deviation",
    "subgroups": "Subgroup columns",
    "covariate": "Meta-regression covariate",
}
SUMMARY_MEASURES = {
    "proportion": {
        "PLOGIT": "Logit-transformed proportion",
        "PLN": "Log-transformed proportion",
        "PFT": "Freeman-Tukey double arcsine",
        "PRAW": "Raw proportion",
    },
    "mean": {
        "MRAW": "Raw mean",
        "MLN": "Log-transformed mean",
    },
}


def infer_outcome_type(columns: list[str], sheet_name: str, requested: str) -> str:
    if requested != "auto":
        return requested
    normalized = {common.normalize_name(col) for col in columns}
    sheet_norm = common.normalize_name(sheet_name)
    has_mean = bool({"mean", "sd"} & normalized) or any("mean" in col for col in normalized)
    has_event = "event" in normalized or any("event" in col or "events" in col for col in normalized)
    if "mean" in sheet_norm or has_mean:
        return "mean"
    if "prop" in sheet_norm or "proportion" in sheet_norm or has_event:
        return "proportion"
    return "proportion"


def default_mapping(columns: list[str], outcome_type: str) -> dict[str, Any]:
    normalized = {common.normalize_name(col): col for col in columns}
    candidates = {
        "study_label": ["author", "authors", "name", "names", "study", "studlab", "studyid", "trial"],
        "event": ["event", "events", "cases", "responders", "deaths", "successes", "failures"],
        "n": ["n", "total", "sample", "samplesize", "patients", "participants"],
        "mean": ["mean", "average", "m"],
        "sd": ["sd", "standarddeviation", "stddev", "stdev"],
        "covariate": ["covariate", "moderator", "year", "followup", "followupmonths"],
    }
    mapping: dict[str, Any] = {
        "outcome_type": outcome_type,
        "sheet_name": None,
        "outcome_name": "single proportion" if outcome_type == "proportion" else "single mean",
        "columns": {},
        "subgroup_columns": [],
        "analysis": {
            "summary_measure": "PLOGIT" if outcome_type == "proportion" else "MRAW",
            "summary_measure_reason": (
                "PLOGIT with GLMM is the template default for single proportions."
                if outcome_type == "proportion"
                else "MRAW is the template default for single means on their original scale."
            ),
            "method": "GLMM" if outcome_type == "proportion" else "",
            "method_reason": (
                "GLMM is the template default for single proportions."
                if outcome_type == "proportion"
                else "metamean does not require a pooling-method argument like metaprop."
            ),
            "model_type": "random",
            "model_type_reason": "Random-effects is the default when between-study heterogeneity is plausible.",
            "analysis_engine": "frequentist",
            "analysis_engine_reason": "Frequentist single-arm meta-analysis is the default for conventional reporting; Bayesian synthesis can be selected when posterior estimates are desired.",
        },
        "confidence": 0.0,
        "notes": "Heuristic mapping; confirm before running.",
    }
    for field, names in candidates.items():
        for candidate in names:
            if candidate in normalized:
                mapping["columns"][field] = normalized[candidate]
                break
    for col in columns:
        norm = common.normalize_name(col)
        if any(token in norm for token in ("subgroup", "group", "strata", "category", "region", "drug")):
            if col not in mapping["subgroup_columns"]:
                mapping["subgroup_columns"].append(col)
            mapping["columns"].setdefault("subgroup", col)
    return mapping


def call_lmstudio(
    summary: dict[str, Any],
    outcome_type: str,
    lmstudio_url: str,
    model: str | None,
) -> dict[str, Any] | None:
    model = common.resolve_lmstudio_model(lmstudio_url, model)
    if not model:
        return None

    if outcome_type == "proportion":
        task = "Identify columns for a single-arm proportion meta-analysis using R meta::metaprop(event, n, studlab = Author)."
        required = {
            "study_label": "study name, author, or trial label",
            "event": "number with the event/outcome",
            "n": "total sample size or denominator",
        }
        choices = {
            "summary_measure": "Choose PLOGIT, PLN, PFT, or PRAW; PLOGIT is the template default.",
            "method": "Choose GLMM or inverse; GLMM is the template default for PLOGIT.",
            "model_type": "Choose random or common/fixed.",
            "analysis_engine": "Choose frequentist, bayesian, or both.",
        }
        rules = [
            "Return exact column names as they appear in the workbook.",
            "Do not invent columns.",
            "Use event counts for event and total denominators for n.",
            "Prefer PLOGIT with GLMM for most single proportions, especially bounded or sparse proportions.",
            "Use random-effects unless one common true proportion is defensible.",
            "Use frequentist as the conventional Cochrane-style primary output when data are adequate.",
            "Use Bayesian output as a supplement when study counts are small, proportions are sparse or near boundaries, sample sizes are small, or posterior credible intervals would improve interpretation.",
            "Choose both when Bayesian credible intervals are useful but conventional confidence intervals and heterogeneity statistics should still be reported.",
        ]
    else:
        task = "Identify columns for a single-arm mean meta-analysis using R meta::metamean(n, mean, sd, studlab = Author)."
        required = {
            "study_label": "study name, author, or trial label",
            "n": "study sample size",
            "mean": "study mean",
            "sd": "study standard deviation",
        }
        choices = {
            "summary_measure": "Choose MRAW for symmetric/original-scale means or MLN for positive right-skewed means.",
            "model_type": "Choose random or common/fixed.",
            "analysis_engine": "Choose frequentist, bayesian, or both.",
        }
        rules = [
            "Return exact column names as they appear in the workbook.",
            "Do not invent columns.",
            "Use n, mean, and SD from the same single study arm.",
            "Use MRAW when the mean can be analyzed on the original scale.",
            "Use MLN only for positive, right-skewed outcomes where log-transformed means are appropriate.",
            "Use random-effects unless one common true mean is defensible.",
            "Use frequentist as the conventional Cochrane-style primary output when data are adequate.",
            "Use Bayesian output as a supplement when study counts are small, sample sizes are small, uncertainty about heterogeneity is important, or posterior credible intervals would improve interpretation.",
            "Choose both when Bayesian credible intervals are useful but conventional confidence intervals and heterogeneity statistics should still be reported.",
        ]

    prompt = {
        "task": task,
        "required_columns": required,
        "optional_columns": {
            "subgroup_columns": "all clinically meaningful categorical subgroup columns if present",
            "covariate": "numeric covariate for meta-regression if present",
        },
        "analysis_choices": choices,
        "workbook": summary,
        "rules": rules,
        "return_json_schema": {
            "sheet_name": "string",
            "outcome_name": "string",
            "outcome_type": outcome_type,
            "columns": {
                "study_label": "string",
                "event": "string or null",
                "n": "string",
                "mean": "string or null",
                "sd": "string or null",
                "covariate": "string or null",
            },
            "subgroup_columns": ["string"],
            "analysis": {
                "summary_measure": "string",
                "summary_measure_reason": "short string",
                "method": "string or null",
                "method_reason": "short string",
                "model_type": "random or common",
                "model_type_reason": "short string",
                "analysis_engine": "frequentist, bayesian, or both",
                "analysis_engine_reason": "short string",
            },
            "confidence": "number from 0 to 1",
            "notes": "short string",
        },
    }
    body = {
        "model": model,
        "messages": [
            {
                "role": "system",
                "content": "You map clinical Excel columns to a strict single-arm meta-analysis schema. Return only valid JSON.",
            },
            {"role": "user", "content": json.dumps(prompt, default=str)},
        ],
        "temperature": 0,
    }
    request = urllib.request.Request(
        common.chat_completions_url(lmstudio_url),
        data=json.dumps(body).encode("utf-8"),
        headers=common.llm_request_headers(include_content_type=True),
        method="POST",
    )
    try:
        with urllib.request.urlopen(request) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        print(f"LMStudio request failed ({common.lmstudio_error_message(exc)}). Falling back to name matching.")
        return None
    except Exception as exc:
        print(f"LMStudio request failed ({exc}). Falling back to name matching.")
        return None
    content = payload["choices"][0]["message"]["content"]
    try:
        return json.loads(content)
    except json.JSONDecodeError:
        match = re.search(r"\{.*\}", content, flags=re.S)
        if match:
            return json.loads(match.group(0))
        print("LMStudio did not return valid JSON. Falling back to name matching.")
        return None


def normalize_analysis(analysis: dict[str, Any], mapping: dict[str, Any]) -> dict[str, str]:
    outcome_type = mapping["outcome_type"]
    allowed = SUMMARY_MEASURES[outcome_type]
    default_measure = "PLOGIT" if outcome_type == "proportion" else "MRAW"
    measure = str(analysis.get("summary_measure") or default_measure).upper()
    if measure not in allowed:
        measure = default_measure
    method = str(analysis.get("method") or mapping.get("analysis", {}).get("method") or "").strip()
    if outcome_type == "proportion":
        method_aliases = {
            "glmm": "GLMM",
            "generalized linear mixed model": "GLMM",
            "inverse": "Inverse",
            "inverse variance": "Inverse",
            "iv": "Inverse",
        }
        method = method_aliases.get(method.lower(), method)
        if method not in {"GLMM", "Inverse"}:
            method = "GLMM"
    else:
        method = ""
    model_raw = str(analysis.get("model_type") or mapping.get("analysis", {}).get("model_type") or "random").lower()
    model_type = "common" if model_raw in {"common", "fixed", "fixed-effect", "fixed effect"} else "random"
    engine = common.normalize_analysis_engine(
        analysis.get("analysis_engine") or mapping.get("analysis", {}).get("analysis_engine"),
        "frequentist",
    )
    return {
        "summary_measure": measure,
        "summary_measure_reason": str(
            analysis.get("summary_measure_reason")
            or mapping.get("analysis", {}).get("summary_measure_reason")
            or f"{measure} is the default for this single-arm analysis."
        ),
        "method": method,
        "method_reason": str(
            analysis.get("method_reason")
            or mapping.get("analysis", {}).get("method_reason")
            or ("GLMM is the default metaprop method." if outcome_type == "proportion" else "No method argument is needed for metamean.")
        ),
        "model_type": model_type,
        "model_type_reason": str(
            analysis.get("model_type_reason")
            or mapping.get("analysis", {}).get("model_type_reason")
            or "Random-effects is selected when between-study heterogeneity is plausible."
        ),
        "analysis_engine": engine,
        "analysis_engine_reason": str(
            analysis.get("analysis_engine_reason")
            or mapping.get("analysis", {}).get("analysis_engine_reason")
            or common.analysis_engine_reason(engine)
        ),
    }


def merge_mapping(
    columns: list[str],
    sheet_name: str,
    outcome_type: str,
    lm_mapping: dict[str, Any] | None,
    outcome: str | None,
) -> dict[str, Any]:
    mapping = default_mapping(columns, outcome_type)
    mapping["sheet_name"] = sheet_name
    if lm_mapping:
        mapping.update({key: value for key, value in lm_mapping.items() if key not in {"columns", "subgroup_columns"} and value})
        mapping["outcome_type"] = outcome_type
        mapping["sheet_name"] = sheet_name
        for field, col in (lm_mapping.get("columns") or {}).items():
            if col in columns:
                mapping["columns"][field] = col
            elif col in {"", None}:
                mapping["columns"].pop(field, None)
        subgroups = []
        for col in lm_mapping.get("subgroup_columns") or []:
            if col in columns and col not in subgroups:
                subgroups.append(col)
        legacy = (lm_mapping.get("columns") or {}).get("subgroup")
        if legacy in columns and legacy not in subgroups:
            subgroups.append(legacy)
        mapping["subgroup_columns"] = subgroups
    if outcome:
        mapping["outcome_name"] = outcome
    mapping["analysis"] = normalize_analysis(mapping.get("analysis") or {}, mapping)
    return mapping


def print_mapping(mapping: dict[str, Any], columns: list[str]) -> None:
    outcome_type = mapping["outcome_type"]
    print("\nIdentified single-arm meta-analysis mapping")
    print("-------------------------------------------")
    print(f"Type: {outcome_type}")
    print(f"Sheet: {mapping.get('sheet_name')}")
    print(f"Outcome name: {mapping.get('outcome_name')}")
    print("\nColumns:")
    for field in REQUIRED_FIELDS[outcome_type]:
        print(f"  {FIELD_LABELS[field]}: {common.format_column_choice(mapping.get('columns', {}).get(field), columns)}")
    subgroups = ", ".join(common.format_column_choice(col, columns) for col in mapping.get("subgroup_columns", [])) or "(none)"
    print(f"  {FIELD_LABELS['subgroups']}: {subgroups}")
    print(f"  {FIELD_LABELS['covariate']}: {common.format_column_choice(mapping.get('columns', {}).get('covariate'), columns)}")
    common.print_numbered_columns(columns)
    analysis = normalize_analysis(mapping.get("analysis") or {}, mapping)
    print("\nAnalysis choices:")
    print(f"  Summary measure: {analysis['summary_measure']} ({SUMMARY_MEASURES[outcome_type][analysis['summary_measure']]})")
    print(f"    Why: {analysis['summary_measure_reason']}")
    if outcome_type == "proportion":
        print(f"  Pooling method: {analysis['method']}")
        print(f"    Why: {analysis['method_reason']}")
    print(f"  Statistical model: {analysis['model_type']} ({'Random-effects' if analysis['model_type'] == 'random' else 'Common/fixed-effect'})")
    print(f"    Why: {analysis['model_type_reason']}")
    print(f"  Analysis engine: {analysis['analysis_engine']} ({common.ANALYSIS_ENGINES[analysis['analysis_engine']]})")
    print(f"    Why: {analysis['analysis_engine_reason']}")
    if analysis.get("analysis_engine_auto_summary"):
        print("  Auto engine data check:")
        print(f"    Data summary: {analysis['analysis_engine_auto_summary']}")
        triggers = analysis.get("analysis_engine_auto_triggers") or []
        print(f"    Bayesian supplement triggers: {', '.join(triggers) if triggers else 'none'}")
    if mapping.get("notes"):
        print(f"Notes: {mapping['notes']}")


def prompt_for_mapping(mapping: dict[str, Any], columns: list[str], assume_yes: bool) -> dict[str, Any]:
    print_mapping(mapping, columns)
    if assume_yes or not sys.stdin.isatty():
        return mapping
    missing = [field for field in REQUIRED_FIELDS[mapping["outcome_type"]] if not mapping.get("columns", {}).get(field)]
    if not missing:
        correct = input("\nAre these identified columns correct? [Y/n]: ").strip().lower()
        if correct not in {"n", "no"}:
            return mapping
    else:
        print("\nRequired fields are missing, so column selection is required.")

    print("\nType a column number to replace a value, press Enter to keep it, or type 0 for none.")
    mapping["outcome_name"] = input(f"Outcome name [{mapping.get('outcome_name')}]: ").strip() or mapping.get("outcome_name")
    for field in REQUIRED_FIELDS[mapping["outcome_type"]]:
        current = mapping.get("columns", {}).get(field) or ""
        value = input(f"{FIELD_LABELS[field]} column [{common.format_column_choice(current, columns)}]: ").strip()
        if value:
            resolved = common.resolve_column_choice(value, columns)
            if resolved is None:
                mapping["columns"].pop(field, None)
            else:
                mapping["columns"][field] = resolved
    subgroup_display = ", ".join(common.format_column_choice(col, columns) for col in mapping.get("subgroup_columns", [])) or "(none)"
    subgroup_value = input(f"{FIELD_LABELS['subgroups']} [{subgroup_display}]: ").strip()
    if subgroup_value:
        if subgroup_value.lower() in {"none", "null", "-", "0"}:
            mapping["subgroup_columns"] = []
            mapping["columns"].pop("subgroup", None)
        else:
            mapping["subgroup_columns"] = common.resolve_column_choices(subgroup_value, columns)
            if mapping["subgroup_columns"]:
                mapping["columns"]["subgroup"] = mapping["subgroup_columns"][0]
    current = mapping.get("columns", {}).get("covariate") or ""
    value = input(f"{FIELD_LABELS['covariate']} column [{common.format_column_choice(current, columns)}]: ").strip()
    if value:
        resolved = common.resolve_column_choice(value, columns)
        if resolved is None:
            mapping["columns"].pop("covariate", None)
        else:
            mapping["columns"]["covariate"] = resolved
    print_mapping(mapping, columns)
    if input("\nUse this corrected mapping and analysis? [Y/n]: ").strip().lower() in {"n", "no"}:
        raise SystemExit("Stopped before extracting data.")
    return mapping


def prompt_for_analysis_choices(analysis: dict[str, str], assume_yes: bool, outcome_type: str) -> dict[str, str]:
    if assume_yes or not sys.stdin.isatty():
        return analysis
    if input("Change analysis choices? [y/N]: ").strip().lower() not in {"y", "yes"}:
        return analysis

    measures = list(SUMMARY_MEASURES[outcome_type])
    print("\nSummary measure options:")
    for index, measure in enumerate(measures, start=1):
        print(f"{index}. {measure} - {SUMMARY_MEASURES[outcome_type][measure]}")
    value = input(f"Summary measure [{analysis['summary_measure']}]: ").strip()
    if value:
        lookup = {str(i): measure for i, measure in enumerate(measures, start=1)}
        lookup.update({measure.lower(): measure for measure in measures})
        selected = lookup.get(value.lower() if not value.isdigit() else value)
        if not selected:
            raise SystemExit("Invalid summary measure choice.")
        analysis["summary_measure"] = selected
        analysis["summary_measure_reason"] = "Manually selected by user."

    if outcome_type == "proportion":
        value = input(f"Pooling method [{analysis['method']}] (GLMM/Inverse): ").strip()
        if value:
            lookup = {"glmm": "GLMM", "inverse": "Inverse", "iv": "Inverse", "inverse variance": "Inverse"}
            selected = lookup.get(value.lower())
            if not selected:
                raise SystemExit("Proportion method must be GLMM or Inverse.")
            analysis["method"] = selected
            analysis["method_reason"] = "Manually selected by user."

    value = input(f"Statistical model [{analysis['model_type']}] (random/common): ").strip().lower()
    if value:
        lookup = {"random": "random", "random-effects": "random", "common": "common", "fixed": "common", "fixed-effect": "common"}
        if value not in lookup:
            raise SystemExit("Model must be random or common/fixed.")
        analysis["model_type"] = lookup[value]
        analysis["model_type_reason"] = "Manually selected by user."
    value = input(f"Analysis engine [{analysis['analysis_engine']}] (frequentist/bayesian/both): ").strip().lower()
    if value:
        lookup = {
            "frequentist": "frequentist",
            "freq": "frequentist",
            "bayesian": "bayesian",
            "bayes": "bayesian",
            "both": "both",
        }
        if value not in lookup:
            raise SystemExit("Analysis engine must be frequentist, bayesian, or both.")
        analysis["analysis_engine"] = lookup[value]
        analysis["analysis_engine_reason"] = "Manually selected by user."
    return analysis


def add_optional_columns(r_df: pd.DataFrame, df: pd.DataFrame, mapping: dict[str, Any], reserved: set[str]) -> None:
    valid_subgroups = []
    used: set[str] = set(r_df.columns)
    for index, subgroup_source in enumerate(mapping.get("subgroup_columns") or [], start=1):
        if subgroup_source not in df.columns:
            continue
        subgroup_col = common.sanitize_r_name(subgroup_source, f"subgroup_{index}")
        if subgroup_col in reserved:
            subgroup_col = f"{subgroup_col}_subgroup"
        base = subgroup_col
        suffix = 2
        while subgroup_col in used:
            subgroup_col = f"{base}_{suffix}"
            suffix += 1
        used.add(subgroup_col)
        r_df[subgroup_col] = df[subgroup_source]
        valid_subgroups.append({"source": subgroup_source, "r_column": subgroup_col})
    mapping["subgroup_columns"] = [item["source"] for item in valid_subgroups]
    mapping["subgroup_r_columns"] = valid_subgroups

    covariate_source = mapping.get("columns", {}).get("covariate")
    if covariate_source:
        r_df["covariate"] = pd.to_numeric(df[covariate_source], errors="coerce")
        if r_df["covariate"].notna().sum() == 0:
            print("Covariate column was identified but is not numeric; skipping meta-regression.")
            r_df.drop(columns=["covariate"], inplace=True)


def clean_label_series(series: pd.Series) -> pd.Series:
    labels = series.astype("string").str.strip()
    return labels.mask(labels.str.lower().isin({"", "nan", "none", "null"}).fillna(False))


def validate_data(df: pd.DataFrame, mapping: dict[str, Any]) -> pd.DataFrame:
    outcome_type = mapping["outcome_type"]
    missing = [field for field in REQUIRED_FIELDS[outcome_type] if not mapping.get("columns", {}).get(field)]
    if missing:
        raise SystemExit("Missing required columns: " + ", ".join(FIELD_LABELS[field] for field in missing))
    if df.empty:
        raise SystemExit("The selected sheet has no data rows. Add study rows before running the analysis.")

    r_df = pd.DataFrame()
    r_df["Author"] = clean_label_series(df[mapping["columns"]["study_label"]])
    if outcome_type == "proportion":
        r_df["event"] = pd.to_numeric(df[mapping["columns"]["event"]], errors="coerce")
        r_df["n"] = pd.to_numeric(df[mapping["columns"]["n"]], errors="coerce")
        add_optional_columns(r_df, df, mapping, {"Author", "event", "n", "covariate"})
        r_df = r_df.dropna(subset=["Author", "event", "n"]).copy()
        finite = r_df[["event", "n"]].apply(lambda column: column.map(math.isfinite))
        if not finite.all().all():
            raise SystemExit("Invalid proportion data: events and totals must be finite numbers.")
        whole = (r_df[["event", "n"]].round() - r_df[["event", "n"]]).abs() <= 1e-8
        if not whole.all().all():
            raise SystemExit("Invalid proportion data: events and totals must be whole numbers.")
        invalid = r_df[(r_df["event"] < 0) | (r_df["n"] <= 0) | (r_df["event"] > r_df["n"])]
        if not invalid.empty:
            raise SystemExit("Invalid proportion data: events must be nonnegative and no greater than totals.")
    else:
        for field in ["n", "mean", "sd"]:
            r_df[field] = pd.to_numeric(df[mapping["columns"][field]], errors="coerce")
        add_optional_columns(r_df, df, mapping, {"Author", "n", "mean", "sd", "covariate"})
        r_df = r_df.dropna(subset=["Author", "n", "mean", "sd"]).copy()
        finite = r_df[["n", "mean", "sd"]].apply(lambda column: column.map(math.isfinite))
        if not finite.all().all():
            raise SystemExit("Invalid mean data: n, mean, and SD must be finite numbers.")
        whole_n = (r_df["n"].round() - r_df["n"]).abs() <= 1e-8
        if not whole_n.all():
            raise SystemExit("Invalid mean data: n must contain whole numbers.")
        invalid = r_df[(r_df["n"] <= 0) | (r_df["sd"] < 0)]
        if not invalid.empty:
            raise SystemExit("Invalid mean data: n must be positive and SD must be nonnegative.")
        if mapping["analysis"]["summary_measure"] == "MLN" and (r_df["mean"] <= 0).any():
            raise SystemExit("MLN requires positive means. Use MRAW or fix nonpositive mean values.")

    if r_df.empty:
        raise SystemExit("No complete single-arm data rows remained after validation.")
    r_df["Author"] = common.make_unique_study_labels(r_df["Author"].astype(str))
    return r_df


def show_extracted_data(r_df: pd.DataFrame, preview_rows: int, assume_yes: bool, extracted_path: Path, outcome_type: str) -> None:
    r_df.to_csv(extracted_path, index=False)
    print(f"\nExtracted single-arm {outcome_type} data")
    print("----------------------------------------")
    print(f"Rows extracted: {len(r_df)}")
    print(f"Saved copy: {extracted_path}")
    with pd.option_context("display.max_columns", None, "display.width", 160):
        print(r_df.head(preview_rows).to_string(index=False))
    if len(r_df) > preview_rows:
        print(f"... {len(r_df) - preview_rows} more rows not shown.")
    if assume_yes or not sys.stdin.isatty():
        return
    if input("Run R meta-analysis with this extracted data? [Y/n]: ").strip().lower() in {"n", "no"}:
        raise SystemExit("Stopped before running R.")


def write_r_script(
    script_path: Path,
    csv_path: Path,
    output_dir: Path,
    mapping: dict[str, Any],
    has_covariate: bool,
) -> None:
    outcome_type = mapping["outcome_type"]
    analysis = mapping["analysis"]
    subgroup_block = ""
    for subgroup in mapping.get("subgroup_r_columns") or []:
        subgroup_label = subgroup["source"]
        subgroup_r_column = subgroup["r_column"]
        file_label = common.sanitize_filename(subgroup_label, "Subgroup")
        if outcome_type == "proportion":
            subgroup_meta_call = f"""
subgroup <- metaprop(event, n,
                     studlab = Author,
                     data = data,
                     sm = summary_measure,
                     method = prop_method,
                     method.tau = "ML",
                     method.random.ci = "classic",
                     method.I2 = "tau2",
                     random = random_model,
                     common = common_model,
                     prediction = random_model,
                     subgroup = {subgroup_r_column})
"""
            subgroup_leftcols = 'c("studlab", "event", "n", weight_col, "effect", "ci")'
            subgroup_leftlabs = 'c("Studies", NA, NA, "Weight (%)", "Prevalence", "95% CI")'
            subgroup_extra = "pscale = 100,\n       pooled.events = TRUE,\n       pooled.totals = TRUE,"
        else:
            subgroup_meta_call = f"""
subgroup <- metamean(n,
                     mean,
                     sd,
                     studlab = Author,
                     data = data,
                     sm = summary_measure,
                     method.tau = "REML",
                     method.random.ci = "classic",
                     method.I2 = "tau2",
                     random = random_model,
                     common = common_model,
                     prediction = random_model,
                     subgroup = {subgroup_r_column})
"""
            subgroup_leftcols = 'c("studlab", "mean", "sd", "n", weight_col, "effect", "ci")'
            subgroup_leftlabs = 'c("Studies", NA, NA, NA, "Weight (%)", "Mean", "95% CI")'
            subgroup_extra = "pooled.totals = TRUE,\n       digits = 2,\n       digits.sd = 2,"
        subgroup_block += f"""
{subgroup_meta_call}
subgroup_levels <- unique(data${subgroup_r_column}[!is.na(data${subgroup_r_column})])
plot_height <- max(2500, 1450 + 105 * nrow(data) + 300 * length(subgroup_levels))
png(file = file.path(output, paste0("Subgroup - {file_label} - ", outcome, ".png")),
    width = plot_width,
    height = plot_height,
    res = 300)
forest(subgroup,
       layout = "Revman5",
       leftcols = {subgroup_leftcols},
       leftlabs = {subgroup_leftlabs},
       colgap = "3mm",
       colgap.forest.left = "8mm",
       just = "center",
       col.square = "darkblue",
       col.square.lines = "black",
       sortvar = TE,
       {subgroup_extra}
       print.subgroup.name = FALSE,
       overall = FALSE,
       overall.hetstat = FALSE,
       test.overall.random = FALSE,
       test.overall.common = FALSE,
       fontsize = 8.5,
       fs.study = 8,
       fs.heading = 8.5,
       fs.axis = 8,
       spacing = 0.9)
dev.off()
capture.output(summary(subgroup), file = file.path(output, paste0("SubgroupSummary - {file_label} - ", outcome, ".txt")))
"""

    if has_covariate:
        ylab = "Prevalence" if outcome_type == "proportion" else "Mean"
        metareg_block = f"""
	cov_values <- suppressWarnings(as.numeric(data$covariate))
	if (random_model && sum(is.finite(cov_values)) >= 10 && length(unique(cov_values[is.finite(cov_values)])) >= 2) {{
	  data$covariate <- cov_values
	  mreg.object <- metareg(meta_object, ~ covariate)
	  capture.output(summary(mreg.object), file = file.path(output, paste0("MetaregSummary", outcome, ".txt")))
  png(file = file.path(output, paste0("Metarregression", outcome, ".png")),
      width = 2400, height = 2000, res = 300)
  bubble(mreg.object,
         xlab = "Covariate",
         ylab = {common.r_string(ylab)},
         studlab = TRUE,
         bg = "red")
  dev.off()
	}} else {{
	  writeLines(if (!random_model) {{
	               "Meta-regression was skipped because a common/fixed-effect model was selected."
	             }} else {{
	               "Meta-regression was skipped because fewer than ten finite study-level covariate values or fewer than two unique values were available."
	             }},
	             con = file.path(output, paste0("MetaregSummary", outcome, ".txt")))
	}}
"""
    else:
        metareg_block = ""

    if outcome_type == "proportion":
        main_meta_call = """
run_main_meta <- function(method_value) {
  metaprop(event, n,
           studlab = Author,
           data = data,
           sm = summary_measure,
           method = method_value,
           method.tau = "ML",
           method.random.ci = "classic",
           method.I2 = "tau2",
           random = random_model,
           common = common_model,
           prediction = random_model)
}
meta_object <- try(run_main_meta(prop_method), silent = TRUE)
if (inherits(meta_object, "try-error") && prop_method == "GLMM") {
  glmm_error <- as.character(meta_object)
  prop_method <- "Inverse"
  meta_object <- try(run_main_meta(prop_method), silent = TRUE)
  if (!inherits(meta_object, "try-error")) {
    writeLines(
      paste("GLMM metaprop failed and inverse-variance pooling was used instead.", glmm_error),
      con = file.path(output, paste0("AnalysisFallback", outcome, ".txt"))
    )
  }
}
if (inherits(meta_object, "try-error")) {
  stop(as.character(meta_object), call. = FALSE)
}
"""
        main_leftcols = 'c("studlab", "event", "n", weight_col, "effect", "ci")'
        main_leftlabs = 'c("Studies", NA, NA, "Weight (%)", "Prevalence", "95% CI")'
        main_extra = "pscale = 100,\n       pooled.events = TRUE,\n       pooled.totals = TRUE,"
    else:
        main_meta_call = """
meta_object <- metamean(n,
                        mean,
                        sd,
                        studlab = Author,
                        data = data,
                        sm = summary_measure,
                        method.tau = "REML",
                        method.random.ci = "classic",
                        method.I2 = "tau2",
                        random = random_model,
                        common = common_model,
                        prediction = random_model)
"""
        main_leftcols = 'c("studlab", "mean", "sd", "n", weight_col, "effect", "ci")'
        main_leftlabs = 'c("Studies", NA, NA, NA, "Weight (%)", "Mean", "95% CI")'
        main_extra = "pooled.totals = TRUE,\n       digits = 2,\n       digits.sd = 2,"

    script = f"""
suppressPackageStartupMessages(library(meta))

output <- {common.r_string(str(output_dir))}
outcome <- {common.r_string(str(mapping.get("outcome_file_stem") or mapping["outcome_name"]))}
summary_measure <- {common.r_string(analysis["summary_measure"])}
prop_method <- {common.r_string(analysis["method"] or "GLMM")}
model_type <- {common.r_string(analysis["model_type"])}
analysis_engine <- {common.r_string(common.normalize_analysis_engine(analysis.get("analysis_engine")))}
random_model <- model_type == "random"
common_model <- model_type == "common"
weight_col <- if (random_model) "w.random" else "w.common"
dir.create(output, recursive = TRUE, showWarnings = FALSE)
{common.bayesian_meta_r_helpers()}
data <- read.csv({common.r_string(str(csv_path))}, check.names = FALSE)
numeric_cols <- intersect(c("event", "n", "mean", "sd", "covariate"), names(data))
for (col in numeric_cols) {{
  data[[col]] <- suppressWarnings(as.numeric(data[[col]]))
}}

{main_meta_call}
capture.output(summary(meta_object), file = file.path(output, paste0("Summary", outcome, ".txt")))
saveRDS(meta_object, file = file.path(output, paste0("MetaObject", outcome, ".rds")))
{common.bayesian_meta_r_call("meta_object", 'paste0(summary_measure, " - ", outcome)', "summary_measure %in% c('PLOGIT', 'PLN')", note="Bayesian single-arm synthesis uses study-level effects and standard errors from the meta package object.")}

plot_width <- 3800
plot_height <- max(1900, 1100 + 95 * nrow(data))
png(file = file.path(output, paste0("Forestplot", outcome, ".png")),
    width = plot_width,
    height = plot_height,
    res = 300)
forest(meta_object,
       layout = "Revman5",
       leftcols = {main_leftcols},
       leftlabs = {main_leftlabs},
       colgap = "3mm",
       colgap.forest.left = "8mm",
       just = "center",
       col.square = "darkblue",
       col.square.lines = "black",
       sortvar = TE,
       {main_extra}
       test.overall.random = random_model,
       test.overall.common = common_model,
       fontsize = 8.5,
       fs.study = 8,
       fs.heading = 8.5,
       fs.axis = 8,
       spacing = 0.9)
dev.off()

{subgroup_block}

meta_loo <- tryCatch(
  metainf(meta_object, pooled = if (random_model) "random" else "common"),
  error = function(e) {{
    note <- paste("Leave-one-out sensitivity analysis skipped:", conditionMessage(e))
    writeLines(note, con = file.path(output, paste0("LeaveOneOutSummary", outcome, ".txt")))
    message(note)
    NULL
  }}
)

if (!is.null(meta_loo)) {{
capture.output(summary(meta_loo), file = file.path(output, paste0("LeaveOneOutSummary", outcome, ".txt")))
png(file = file.path(output, paste0("Leave-one-out", outcome, ".png")),
    width = plot_width,
    height = plot_height,
    res = 300)
forest(meta_loo,
       col.bg = "lightblue",
       col.diamond = "gray",
       {("pscale = 100," if outcome_type == "proportion" else "")}
       ff.xlab = "bold",
       rightcols = c("effect", "ci", "I2"),
       colgap.right = "6mm",
       just = "center",
       fontsize = 8.5,
       fs.study = 8,
       fs.axis = 8,
       spacing = 0.9)
dev.off()
}}

png(file = file.path(output, paste0("FunnelPlot", outcome, ".png")),
    width = 2200,
    height = 2000,
    res = 300)
funnel(meta_object,
       studlab = TRUE,
       bg = "red",
       cex = 2,
       cex.studlab = 1,
       random = random_model,
       common = common_model,
       backtransf = FALSE)
dev.off()

if (meta_object$k >= 10) {{
  capture.output(metabias(meta_object, method.bias = "Egger", plotit = TRUE),
                 file = file.path(output, paste0("EggerTest", outcome, ".txt")))
}} else {{
  writeLines("Egger test skipped because fewer than 10 studies were available.",
             con = file.path(output, paste0("EggerTest", outcome, ".txt")))
}}

{metareg_block}
"""
    script_path.write_text(script, encoding="utf-8")


def generate_summary_document(output_dir: Path, mapping: dict[str, Any], r_df: pd.DataFrame) -> Path | None:
    try:
        from docx import Document
    except ImportError:
        print("python-docx is not installed; skipping Word summary.")
        return None
    outcome = mapping["outcome_name"]
    output_stem = str(mapping.get("outcome_file_stem") or common.sanitize_filename(outcome, mapping["outcome_type"]))
    document = Document()
    document.add_heading(f"Single-Arm Meta-Analysis Results: {outcome}", level=1)
    document.add_paragraph(f"Analysis type: single-arm {mapping['outcome_type']}")
    analysis = mapping["analysis"]
    document.add_paragraph(
        f"Summary measure: {analysis['summary_measure']} ({SUMMARY_MEASURES[mapping['outcome_type']][analysis['summary_measure']]}). "
        f"Model: {analysis['model_type']}."
    )
    if mapping["outcome_type"] == "proportion":
        total_events = float(r_df["event"].sum())
        total_n = float(r_df["n"].sum())
        document.add_paragraph(f"Extracted data: {len(r_df)} studies, {total_events:g} events among {total_n:g} participants.")
    else:
        total_n = float(r_df["n"].sum())
        document.add_paragraph(f"Extracted data: {len(r_df)} studies and {total_n:g} total participants.")
    document.add_heading("Extracted Dataset", level=2)
    common.add_docx_table(document, list(r_df.columns), r_df.values.astype(str).tolist())

    for title, filename in [
        ("Overall Meta-Analysis", f"Summary{output_stem}.txt"),
        ("Analysis Fallback Notes", f"AnalysisFallback{output_stem}.txt"),
        ("Leave-One-Out Sensitivity Analysis", f"LeaveOneOutSummary{output_stem}.txt"),
        ("Small-Study Effect Test", f"EggerTest{output_stem}.txt"),
        ("Meta-Regression", f"MetaregSummary{output_stem}.txt"),
    ]:
        text = common.read_text_if_exists(output_dir / filename)
        if text:
            document.add_heading(title, level=2)
            common.add_preformatted_block(document, text)

    figures = sorted(path.name for path in output_dir.glob("*.png"))
    if figures:
        document.add_heading("Figure Inventory", level=2)
        for figure in figures:
            document.add_paragraph(figure, style="List Bullet")
    docx_path = output_dir / f"Manuscript Results Summary - {common.sanitize_filename(outcome, mapping['outcome_type'])}.docx"
    document.save(docx_path)
    return docx_path


def main() -> None:
    parser = argparse.ArgumentParser(description="Run single-arm proportion or mean meta-analysis from Excel.")
    parser.add_argument("excel", nargs="?", help="Path to an Excel workbook.")
    parser.add_argument("--type", choices=["auto", "proportion", "mean"], default="auto", help="Single-arm outcome type.")
    parser.add_argument("--sheet", help="Sheet name to analyze.")
    parser.add_argument("--outcome", help="Outcome name for plots and output files.")
    parser.add_argument("--output-dir", help="Directory where output files should be written.")
    parser.add_argument("--preview-rows", type=int, default=50, help="Rows to preview before running R.")
    parser.add_argument("--yes", action="store_true", help="Accept inferred choices and run non-interactively.")
    parser.add_argument("--no-lmstudio", action="store_true", help="Skip LMStudio and use column-name matching only.")
    parser.add_argument("--install-r-packages", action="store_true", help="Install missing CRAN R packages before running R.")
    parser.add_argument(
        "--engine",
        choices=["auto", "frequentist", "bayesian", "both"],
        default="auto",
        help="Analysis engine. Auto uses the LLM/heuristic recommendation; Bayesian adds bayesmeta posterior outputs.",
    )
    parser.add_argument("--group-column", help="Primary subgroup/group column name or number. Included first in subgroup analyses.")
    parser.add_argument("--subgroup-columns", help="Comma-separated subgroup column names or numbers. Use 'none' to clear.")
    parser.add_argument("--lmstudio-url", default="http://localhost:1234/v1", help="LMStudio OpenAI-compatible API URL.")
    parser.add_argument("--model", help="LMStudio model id. Defaults to the first available model.")

    args = parser.parse_args()

    excel_path = Path(args.excel).expanduser() if args.excel else common.prompt_for_excel_path()
    common.save_last_used_path(excel_path)
    if not excel_path.exists():
        raise SystemExit(f"Workbook not found: {excel_path}")

    _, summary = common.workbook_summary(excel_path)
    sheet_name = common.choose_sheet(summary, args.sheet, args.yes)
    df = common.load_sheet(excel_path, sheet_name=sheet_name)
    columns = [str(col) for col in df.columns]
    outcome_type = infer_outcome_type(columns, sheet_name, args.type)

    lm_mapping = None
    if not args.no_lmstudio:
        lm_mapping = call_lmstudio({sheet_name: summary[sheet_name]}, outcome_type, args.lmstudio_url, args.model)

    mapping = merge_mapping(columns, sheet_name, outcome_type, lm_mapping, args.outcome)
    mapping = common.apply_column_overrides(
        mapping,
        columns,
        group_column=args.group_column,
        subgroup_columns=args.subgroup_columns,
    )
    mapping = prompt_for_mapping(mapping, columns, args.yes)
    mapping["analysis"] = normalize_analysis(mapping.get("analysis") or {}, mapping)
    r_df = validate_data(df, mapping)
    if args.engine != "auto":
        mapping["analysis"]["analysis_engine"] = args.engine
        mapping["analysis"]["analysis_engine_reason"] = f"Applied from --engine {args.engine}."
    else:
        mapping = common.apply_auto_analysis_engine_recommendation(
            mapping,
            r_df,
            analysis_type="single_arm",
            outcome_type=outcome_type,
        )
    mapping["analysis"] = normalize_analysis(mapping.get("analysis") or {}, mapping)
    print("\nAnalysis engine selection")
    print("-------------------------")
    print(f"Analysis engine: {mapping['analysis']['analysis_engine']} ({common.ANALYSIS_ENGINES[mapping['analysis']['analysis_engine']]})")
    print(f"Why: {mapping['analysis']['analysis_engine_reason']}")
    if mapping["analysis"].get("analysis_engine_auto_summary"):
        print(f"Data summary: {mapping['analysis']['analysis_engine_auto_summary']}")
        triggers = mapping["analysis"].get("analysis_engine_auto_triggers") or []
        print(f"Bayesian supplement triggers: {', '.join(triggers) if triggers else 'none'}")
    mapping["analysis"] = prompt_for_analysis_choices(mapping["analysis"], args.yes, outcome_type)
    if args.engine != "auto":
        mapping["analysis"]["analysis_engine"] = args.engine
        mapping["analysis"]["analysis_engine_reason"] = f"Applied from --engine {args.engine}."
    else:
        mapping = common.apply_auto_analysis_engine_recommendation(
            mapping,
            r_df,
            analysis_type="single_arm",
            outcome_type=outcome_type,
        )
    mapping["analysis"] = normalize_analysis(mapping.get("analysis") or {}, mapping)
    safe_outcome = common.sanitize_filename(str(mapping.get("outcome_name") or sheet_name), outcome_type)
    mapping["outcome_file_stem"] = safe_outcome
    if args.output_dir:
        output_dir = Path(args.output_dir).expanduser()
    else:
        output_dir = excel_path.parent / safe_outcome
    output_dir.mkdir(parents=True, exist_ok=True)

    mapping_path = output_dir / "identified-columns.json"
    mapping_path.write_text(json.dumps(mapping, indent=2, default=str), encoding="utf-8")
    extracted_path = output_dir / f"extracted-single-arm-{outcome_type}-data.csv"
    show_extracted_data(r_df, args.preview_rows, args.yes, extracted_path, outcome_type)

    script_path = output_dir / f"generated_single_arm_{outcome_type}_meta_analysis.R"
    write_r_script(script_path, extracted_path, output_dir, mapping, "covariate" in r_df.columns)
    print(f"\nRunning R script: {script_path}")
    common.run_r(
        script_path,
        install_packages=args.install_r_packages,
        packages=common.analysis_engine_packages(mapping["analysis"]["analysis_engine"]),
    )
    common.crop_output_pngs(output_dir)
    docx_path = generate_summary_document(output_dir, mapping, r_df)

    print("\nDone.")
    print(f"Output folder: {output_dir}")
    print(f"Column mapping: {mapping_path}")
    print(f"Extracted data: {extracted_path}")
    print(f"Generated R script: {script_path}")
    if docx_path:
        print(f"Word summary: {docx_path}")


if __name__ == "__main__":
    main()
