#!/usr/bin/env python3
"""Trial Sequential Analysis (TSA) for binary and continuous meta-analyses.

This module is a thin Python wrapper around the R `RTSA` package
(Copenhagen Trial Unit's Trial Sequential Analysis methodology). It only
uses RTSA - no custom TSA math, no fallback implementations. If RTSA is
not installed, the module raises a clear error.

Public API
----------
- run_binary_tsa(df, outcome, ...)       -> TSAResult
- run_continuous_tsa(df, ...)            -> TSAResult
- TSAConfig, TSAResult                   dataclasses
- TSAError                               exception type
- ensure_rtsa_available()                installs/verifies RTSA on demand

Required input data
-------------------
Binary  (RR / OR / RD): columns 'study', 'eI', 'nI', 'eC', 'nC'
Continuous (MD)       : columns 'study', 'mI', 'sdI', 'nI', 'mC', 'sdC', 'nC'

These names match the RTSA R package's expected schema. Adapter functions
convert from common alternative names (e.g. event.e/n.e as used by
`meta::metabin` and your existing binary_outcome.py).

Reference
---------
Wetterslev J, Thorlund K, Brok J, Gluud C. Trial sequential analysis may
establish when firm evidence is reached in cumulative meta-analysis.
J Clin Epidemiol 2008;61:64-75.

RTSA package: https://CRAN.R-project.org/package=RTSA
"""

from __future__ import annotations

import json
import math
import shutil
import subprocess
import tempfile
import textwrap
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Literal

import pandas as pd


# ---------------------------------------------------------------------------
# Public dataclasses / type aliases
# ---------------------------------------------------------------------------

OutcomeBinary = Literal["RR", "OR", "RD"]
OutcomeContinuous = Literal["MD"]
WeightsBinary = Literal["MH", "IV"]
ReMethod = Literal["DL", "DL_HKSJ"]
RandomAdj = Literal["tau2", "D2", "I2"]
EsSpending = Literal["esOF", "esPoc"]
Futility = Literal["none", "binding", "non-binding"]


@dataclass
class TSAConfig:
    """Design / analysis parameters for a TSA run.

    These map directly onto RTSA() arguments. See ?RTSA::RTSA for full docs.
    """
    alpha: float = 0.05
    power: float = 0.80                       # RTSA uses beta = 1 - power
    side: int = 2                             # 1- or 2-sided test
    es_alpha: EsSpending = "esOF"             # alpha-spending function
    es_beta: EsSpending | None = None         # beta-spending (futility)
    futility: Futility = "none"
    fixed: bool = False                       # FALSE => random-effects design
    weights: WeightsBinary = "MH"             # binary only: MH or IV
    re_method: ReMethod = "DL_HKSJ"           # random-effects method
    random_adj: RandomAdj = "tau2"            # heterogeneity adjustment for RIS
    zero_adj: float = 0.5                     # continuity correction
    conf_level: float = 0.95
    # Anticipated effect / control risk for required-information-size:
    mc: float | None = None                   # minimum clinically relevant effect
    pC: float | None = None                   # control event probability (binary)
    sd_mc: float | None = None                # SD assumption for MD designs
    # Optional protocol overrides:
    ris_override: float | None = None
    tau2: float | None = None
    I2: float | None = None
    D2: float | None = None
    # Plot output:
    plot_width: int = 2400
    plot_height: int = 2000
    plot_dpi: int = 300


@dataclass
class TSAResult:
    """Parsed numeric output from one TSA run."""
    outcome: str
    side: int
    alpha: float
    power: float
    studies: int
    pooled_effect: float | None = None
    pooled_ci_lower: float | None = None
    pooled_ci_upper: float | None = None
    pooled_p: float | None = None
    cumulative_z: list[float] = field(default_factory=list)
    cumulative_information: list[float] = field(default_factory=list)
    study_labels: list[str] = field(default_factory=list)
    upper_alpha_boundary: list[float] = field(default_factory=list)
    lower_alpha_boundary: list[float] = field(default_factory=list)
    upper_futility_boundary: list[float] = field(default_factory=list)
    lower_futility_boundary: list[float] = field(default_factory=list)
    required_information_size: float | None = None
    diversity_adjusted_ris: float | None = None
    heterogeneity_adjusted_ris: float | None = None
    crossed_alpha: bool = False
    crossed_futility: bool = False
    conclusion: str = ""
    notes: list[str] = field(default_factory=list)
    plot_path: Path | None = None
    summary_text: str = ""
    rtsa_raw: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        if self.plot_path is not None:
            d["plot_path"] = str(self.plot_path)
        return d

    def write_json(self, path: str | Path) -> Path:
        path = Path(path)
        path.write_text(json.dumps(self.to_dict(), indent=2, default=str), encoding="utf-8")
        return path


class TSAError(RuntimeError):
    """Raised when TSA cannot be computed (R missing, RTSA missing, R failure)."""


# ---------------------------------------------------------------------------
# R / RTSA discovery
# ---------------------------------------------------------------------------

def _find_rscript() -> str:
    rscript = shutil.which("Rscript")
    if not rscript:
        raise TSAError(
            "Rscript was not found on PATH. Install R (https://cran.r-project.org) "
            "and ensure 'Rscript' is on PATH before running TSA."
        )
    return rscript


def ensure_rtsa_available(auto_install: bool = True,
                          repo: str = "https://cloud.r-project.org") -> None:
    """Verify that the RTSA (and jsonlite) R packages are installed."""
    rscript = _find_rscript()
    needed = ["RTSA", "jsonlite"]

    def _check() -> list[str]:
        missing: list[str] = []
        for pkg in needed:
            res = subprocess.run(
                [rscript, "-e",
                 f'cat(if (requireNamespace("{pkg}", quietly = TRUE)) "yes" else "no")'],
                text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False,
            )
            if "yes" not in res.stdout:
                missing.append(pkg)
        return missing

    missing = _check()
    if not missing:
        return
    if not auto_install:
        raise TSAError(
            f"Required R packages are not installed: {missing}. In R run:\n"
            f"    install.packages(c({', '.join(repr(p) for p in missing)}))"
        )

    print(f"[tsa_analysis] Installing R package(s) {missing} (one-time setup)...")
    pkg_vec = "c(" + ", ".join(f'"{p}"' for p in missing) + ")"
    install_code = textwrap.dedent(
        f"""
        packages <- {pkg_vec}
        repos <- "{repo}"
        if (.Platform$OS.type == "windows") {{
          options(install.packages.compile.from.source = "never")
          install.packages(packages, repos = repos, type = "binary")
        }} else {{
          install.packages(packages, repos = repos)
        }}
        """
    )
    install = subprocess.run(
        [rscript, "-e", install_code],
        text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False,
    )
    if install.returncode != 0:
        raise TSAError(
            "Could not install required R packages automatically.\n"
            f"R stderr:\n{install.stderr}"
        )
    still_missing = _check()
    if still_missing:
        raise TSAError(
            f"Installation reported success but these packages are still not "
            f"loadable: {still_missing}"
        )


# ---------------------------------------------------------------------------
# Input validation / column harmonization
# ---------------------------------------------------------------------------

_BINARY_REQUIRED = ("study", "eI", "nI", "eC", "nC")
_CONTINUOUS_REQUIRED = ("study", "mI", "sdI", "nI", "mC", "sdC", "nC")

# Aliases follow the meta::metabin / meta::metacont naming conventions used
# in your existing binary_outcome.py, so the same DataFrame can be passed in.
_BINARY_ALIASES = {
    "study": ("study", "studlab", "Author", "author", "label"),
    "eI": ("eI", "event.e", "events.e", "event_e", "events_intervention"),
    "nI": ("nI", "n.e", "total.e", "n_e", "n_intervention"),
    "eC": ("eC", "event.c", "events.c", "event_c", "events_control"),
    "nC": ("nC", "n.c", "total.c", "n_c", "n_control"),
}
_CONTINUOUS_ALIASES = {
    "study":  ("study", "studlab", "Author", "author", "label"),
    "mI":     ("mI", "mean.e", "mean_e", "mean_intervention"),
    "sdI":    ("sdI", "sd.e", "sd_e", "sd_intervention"),
    "nI":     ("nI", "n.e", "n_e", "n_intervention"),
    "mC":     ("mC", "mean.c", "mean_c", "mean_control"),
    "sdC":    ("sdC", "sd.c", "sd_c", "sd_control"),
    "nC":     ("nC", "n.c", "n_c", "n_control"),
}


def _harmonize_columns(df: pd.DataFrame, aliases: dict[str, tuple[str, ...]],
                       required: tuple[str, ...]) -> pd.DataFrame:
    out = pd.DataFrame()
    norm = {c.lower().replace(".", "_").replace(" ", "_"): c for c in df.columns}
    for target, options in aliases.items():
        chosen = None
        for opt in options:
            if opt in df.columns:
                chosen = opt
                break
            key = opt.lower().replace(".", "_").replace(" ", "_")
            if key in norm:
                chosen = norm[key]
                break
        if chosen is None:
            if target in required:
                raise TSAError(
                    f"Required column '{target}' (or one of {options}) was not "
                    f"found. Columns present: {list(df.columns)}"
                )
        else:
            out[target] = df[chosen]
    return out


def _validate_binary(df: pd.DataFrame) -> pd.DataFrame:
    df = _harmonize_columns(df, _BINARY_ALIASES, _BINARY_REQUIRED)
    for col in ("eI", "nI", "eC", "nC"):
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df = df.dropna(subset=list(_BINARY_REQUIRED[1:]))
    if df.empty:
        raise TSAError("No complete rows for binary TSA after coercion.")
    bad = df[(df["eI"] < 0) | (df["eC"] < 0) |
             (df["nI"] <= 0) | (df["nC"] <= 0) |
             (df["eI"] > df["nI"]) | (df["eC"] > df["nC"])]
    if not bad.empty:
        raise TSAError(
            "Invalid binary rows (events must be non-negative and not exceed "
            f"totals). Offending studies: {bad['study'].tolist()}"
        )
    df["study"] = df["study"].astype(str)
    return df.reset_index(drop=True)


def _validate_continuous(df: pd.DataFrame) -> pd.DataFrame:
    df = _harmonize_columns(df, _CONTINUOUS_ALIASES, _CONTINUOUS_REQUIRED)
    for col in ("mI", "sdI", "nI", "mC", "sdC", "nC"):
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df = df.dropna(subset=list(_CONTINUOUS_REQUIRED[1:]))
    if df.empty:
        raise TSAError("No complete rows for continuous TSA after coercion.")
    bad = df[(df["sdI"] <= 0) | (df["sdC"] <= 0) |
             (df["nI"] <= 1) | (df["nC"] <= 1)]
    if not bad.empty:
        raise TSAError(
            "Invalid continuous rows (SDs must be > 0 and arm sizes > 1). "
            f"Offending studies: {bad['study'].tolist()}"
        )
    df["study"] = df["study"].astype(str)
    return df.reset_index(drop=True)


# ---------------------------------------------------------------------------
# R script generation
# ---------------------------------------------------------------------------

def _r_str(value: Any) -> str:
    return "NULL" if value is None else json.dumps(str(value))


def _r_val(value: Any) -> str:
    if value is None:
        return "NULL"
    if isinstance(value, bool):
        return "TRUE" if value else "FALSE"
    if isinstance(value, (int, float)):
        if isinstance(value, float) and (math.isnan(value) or not math.isfinite(value)):
            return "NA_real_"
        return repr(value)
    return _r_str(value)


_R_SCRIPT_TEMPLATE = r"""
suppressPackageStartupMessages({
  library(RTSA)
  library(jsonlite)
})

data_csv  <- {data_csv}
plot_png  <- {plot_png}
json_out  <- {json_out}
outcome   <- {outcome}
side      <- {side}
alpha     <- {alpha}
beta      <- {beta}
es_alpha  <- {es_alpha}
es_beta   <- {es_beta}
futility  <- {futility}
fixed     <- {fixed}
weights   <- {weights}
re_method <- {re_method}
random_adj<- {random_adj}
zero_adj  <- {zero_adj}
conf_lvl  <- {conf_level}
mc_val    <- {mc}
pC_val    <- {pC}
sd_mc_val <- {sd_mc}
ris_over  <- {ris_override}
tau2_val  <- {tau2}
I2_val    <- {I2}
D2_val    <- {D2}
pw        <- {plot_width}
ph        <- {plot_height}
pdpi      <- {plot_dpi}

data <- read.csv(data_csv, stringsAsFactors = FALSE, check.names = FALSE)

# Build the argument list dynamically so we only pass non-NULL values to RTSA.
args <- list(
  type       = "analysis",
  data       = data,
  outcome    = outcome,
  side       = side,
  alpha      = alpha,
  beta       = beta,
  es_alpha   = es_alpha,
  futility   = futility,
  fixed      = fixed,
  re_method  = re_method,
  random_adj = random_adj,
  zero_adj   = zero_adj,
  conf_level = conf_lvl
)
if (!is.null(es_beta))   args$es_beta <- es_beta
if (!is.null(weights) && outcome %in% c("RR","OR","RD")) args$weights <- weights
if (!is.null(mc_val))    args$mc      <- mc_val
if (!is.null(pC_val))    args$pC      <- pC_val
if (!is.null(sd_mc_val)) args$sd_mc   <- sd_mc_val
if (!is.null(tau2_val))  args$tau2    <- tau2_val
if (!is.null(I2_val))    args$I2      <- I2_val
if (!is.null(D2_val))    args$D2      <- D2_val

result <- do.call(RTSA::RTSA, args)
summary_lines <- capture.output(print(result))

# RTSA's plot() method writes the TSA Z-curve / boundaries plot.
png(plot_png, width = pw, height = ph, res = pdpi)
plot_err <- tryCatch({
  plot_obj <- plot(result)
  if (!is.null(plot_obj)) print(plot_obj)
  NULL
}, error = function(e) conditionMessage(e))
if (length(dev.list()) > 0) dev.off()

# ---- Pull numeric pieces out of the RTSA result list ----
safe_num <- function(x) {
  if (is.null(x)) return(NA_real_)
  if (is.list(x)) x <- unlist(x, recursive = TRUE, use.names = FALSE)
  v <- suppressWarnings(as.numeric(x))
  if (length(v) == 0) NA_real_ else v[1]
}
to_vec <- function(x) {
  if (is.null(x)) return(numeric(0))
  if (is.list(x)) x <- unlist(x, recursive = TRUE, use.names = FALSE)
  v <- suppressWarnings(as.numeric(x))
  v[is.na(v)] <- NA_real_
  unname(v)
}
get_first <- function(lst, names_) {
  for (nm in names_) {
    if (!is.null(lst[[nm]])) return(lst[[nm]])
  }
  NULL
}

# RTSA result names vary slightly across versions / outcome types, so look in
# the most common locations.
ris_obj     <- get_first(result, c("ris", "design_R", "design"))
results_obj <- get_first(result, c("results", "seq_inf"))
bounds_obj  <- get_first(result, c("bounds", "boundaries", "design_R"))

ris_total <- NA_real_
ris_div   <- NA_real_
ris_het   <- NA_real_
if (!is.null(ris_obj)) {
  ris_total <- safe_num(get_first(ris_obj, c("NF", "NF_full", "NR_full",
                                             "NR_D2_full", "NR_I2_full",
                                             "NR_tau_full", "NR")))
  ris_div   <- safe_num(get_first(ris_obj, c("NR_D2_full", "NR_D2", "D2_NR")))
  ris_het   <- safe_num(get_first(ris_obj, c("NR_tau_full", "NR_tau",
                                             "NR_I2_full", "NR_I2")))
}
if (!is.null(ris_over) && is.finite(ris_over)) ris_total <- ris_over

cum_z   <- to_vec(get_first(results_obj, c("z", "Z", "cumZ", "cum_Z")))
cum_inf <- to_vec(get_first(results_obj, c("sma_timing", "info", "information",
                                           "cum_info", "n_cum")))
study_labels <- as.character(get_first(results_obj, c("study", "studlab",
                                                      "label", "studies")))
if (length(study_labels) == 0 && "study" %in% names(data)) {
  study_labels <- as.character(data$study)
}

upper_alpha <- to_vec(get_first(bounds_obj, c("alpha_ubound", "upper", "u_bound",
                                              "upper_bound", "upper_alpha")))
lower_alpha <- to_vec(get_first(bounds_obj, c("alpha_lbound", "lower", "l_bound",
                                              "lower_bound", "lower_alpha")))
upper_fut   <- to_vec(get_first(bounds_obj, c("beta_ubound", "upper_futility",
                                              "fut_upper")))
lower_fut   <- to_vec(get_first(bounds_obj, c("beta_lbound", "lower_futility",
                                              "fut_lower")))

ma_obj <- get_first(result, c("ma", "metaanalysis", "meta"))
pooled_eff <- safe_num(get_first(ma_obj, c("TE", "estimate", "pooled", "effect")))
pooled_lo  <- safe_num(get_first(ma_obj, c("lower", "ci.lower", "lower.random",
                                           "lower.fixed")))
pooled_hi  <- safe_num(get_first(ma_obj, c("upper", "ci.upper", "upper.random",
                                           "upper.fixed")))
pooled_p   <- safe_num(get_first(ma_obj, c("pval", "p", "pvalue", "p.value")))

# Did the cumulative Z cross any boundary at the most recent look?
crossed_alpha <- FALSE
crossed_fut   <- FALSE
if (length(cum_z) > 0) {
  last_z <- tail(cum_z, 1)
  if (length(upper_alpha) >= length(cum_z)) {
    last_u <- upper_alpha[length(cum_z)]
    if (is.finite(last_u) && abs(last_z) >= last_u) crossed_alpha <- TRUE
  }
  if (length(lower_alpha) >= length(cum_z)) {
    last_l <- lower_alpha[length(cum_z)]
    if (is.finite(last_l) && last_z <= last_l) crossed_alpha <- TRUE
  }
  if (length(upper_fut) >= length(cum_z)) {
    last_uf <- upper_fut[length(cum_z)]
    if (is.finite(last_uf) && abs(last_z) <= last_uf) crossed_fut <- TRUE
  }
}

conclusion <- if (crossed_alpha) {
  "Cumulative Z-curve crossed the alpha-spending (efficacy/harm) boundary; firm evidence reached for the chosen effect size."
} else if (crossed_fut) {
  "Cumulative Z-curve crossed the futility boundary; firm evidence of futility for the chosen effect size."
} else {
  "Cumulative Z-curve did not cross alpha or futility boundaries; evidence is inconclusive at the current information size."
}

payload <- list(
  studies = nrow(data),
  pooled_effect = pooled_eff,
  pooled_ci_lower = pooled_lo,
  pooled_ci_upper = pooled_hi,
  pooled_p = pooled_p,
  cumulative_z = cum_z,
  cumulative_information = cum_inf,
  study_labels = study_labels,
  upper_alpha_boundary = upper_alpha,
  lower_alpha_boundary = lower_alpha,
  upper_futility_boundary = upper_fut,
  lower_futility_boundary = lower_fut,
  required_information_size = ris_total,
  diversity_adjusted_ris = ris_div,
  heterogeneity_adjusted_ris = ris_het,
  crossed_alpha = crossed_alpha,
  crossed_futility = crossed_fut,
  conclusion = conclusion,
  summary_text = paste(summary_lines, collapse = "\n"),
  plot_error = if (is.null(plot_err)) NA_character_ else plot_err,
  rtsa_names = names(result)
)

con <- file(json_out, open = "w", encoding = "UTF-8")
writeLines(jsonlite::toJSON(payload, auto_unbox = TRUE, na = "null",
                            null = "null", digits = 8), con)
close(con)
"""


def _run_rtsa(
    data: pd.DataFrame,
    outcome: str,
    config: TSAConfig,
    output_dir: Path,
    plot_basename: str,
) -> TSAResult:
    rscript = _find_rscript()
    ensure_rtsa_available(auto_install=True)

    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    plot_png = output_dir / f"{plot_basename}.png"

    beta = max(0.0, min(1.0, 1.0 - float(config.power)))

    with tempfile.TemporaryDirectory(prefix="rtsa-") as tmp:
        tmp_path = Path(tmp)
        data_csv = tmp_path / "tsa-input.csv"
        json_out = tmp_path / "tsa-output.json"
        script   = tmp_path / "run_rtsa.R"

        data.to_csv(data_csv, index=False)

        replacements = {
            "{data_csv}": _r_str(data_csv),
            "{plot_png}": _r_str(plot_png),
            "{json_out}": _r_str(json_out),
            "{outcome}": _r_str(outcome),
            "{side}": _r_val(int(config.side)),
            "{alpha}": _r_val(float(config.alpha)),
            "{beta}": _r_val(float(beta)),
            "{es_alpha}": _r_str(config.es_alpha),
            "{es_beta}": _r_str(config.es_beta) if config.es_beta else "NULL",
            "{futility}": _r_str(config.futility),
            "{fixed}": _r_val(bool(config.fixed)),
            "{weights}": _r_str(config.weights),
            "{re_method}": _r_str(config.re_method),
            "{random_adj}": _r_str(config.random_adj),
            "{zero_adj}": _r_val(float(config.zero_adj)),
            "{conf_level}": _r_val(float(config.conf_level)),
            "{mc}": _r_val(config.mc),
            "{pC}": _r_val(config.pC),
            "{sd_mc}": _r_val(config.sd_mc),
            "{ris_override}": _r_val(config.ris_override),
            "{tau2}": _r_val(config.tau2),
            "{I2}": _r_val(config.I2),
            "{D2}": _r_val(config.D2),
            "{plot_width}": _r_val(int(config.plot_width)),
            "{plot_height}": _r_val(int(config.plot_height)),
            "{plot_dpi}": _r_val(int(config.plot_dpi)),
        }
        rendered = _R_SCRIPT_TEMPLATE
        for placeholder, value in replacements.items():
            rendered = rendered.replace(placeholder, value)
        script.write_text(textwrap.dedent(rendered).strip() + "\n", encoding="utf-8")

        try:
            proc = subprocess.run(
                [rscript, str(script)],
                text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False,
                timeout=60,
            )
        except subprocess.TimeoutExpired as exc:
            # Check if there is any partial stdout/stderr we can report
            stdout_msg = exc.stdout.decode('utf-8') if isinstance(exc.stdout, bytes) else (exc.stdout or "")
            stderr_msg = exc.stderr.decode('utf-8') if isinstance(exc.stderr, bytes) else (exc.stderr or "")
            raise TSAError(
                "RTSA computation timed out after 60 seconds. This is a known issue with RTSA when computing boundaries for certain sparse datasets or non-binding futility parameters.\n"
                f"R stdout:\n{stdout_msg}\nR stderr:\n{stderr_msg}"
            )
            
        if proc.returncode != 0:
            raise TSAError(
                "RTSA::RTSA() failed.\n\n"
                f"R stdout:\n{proc.stdout}\n\nR stderr:\n{proc.stderr}"
            )
        if not json_out.exists():
            raise TSAError(
                "RTSA finished but did not write the expected JSON output.\n"
                f"R stdout:\n{proc.stdout}\nR stderr:\n{proc.stderr}"
            )
        payload = json.loads(json_out.read_text(encoding="utf-8"))

    notes: list[str] = []
    plot_err = payload.get("plot_error")
    if plot_err and plot_err != "NA":
        notes.append(f"RTSA plot warning: {plot_err}")

    def _f(v: Any) -> float | None:
        if v is None:
            return None
        try:
            x = float(v)
        except (TypeError, ValueError):
            return None
        return x if math.isfinite(x) else None

    def _list(v: Any) -> list[float]:
        if v is None:
            return []
        if not isinstance(v, list):
            v = [v]
        out = []
        for item in v:
            try:
                f = float(item)
            except (TypeError, ValueError):
                continue
            out.append(f if math.isfinite(f) else math.nan)
        return out

    return TSAResult(
        outcome=outcome,
        side=int(config.side),
        alpha=float(config.alpha),
        power=float(config.power),
        studies=int(payload.get("studies") or len(data)),
        pooled_effect=_f(payload.get("pooled_effect")),
        pooled_ci_lower=_f(payload.get("pooled_ci_lower")),
        pooled_ci_upper=_f(payload.get("pooled_ci_upper")),
        pooled_p=_f(payload.get("pooled_p")),
        cumulative_z=_list(payload.get("cumulative_z")),
        cumulative_information=_list(payload.get("cumulative_information")),
        study_labels=[str(s) for s in (payload.get("study_labels") or [])],
        upper_alpha_boundary=_list(payload.get("upper_alpha_boundary")),
        lower_alpha_boundary=_list(payload.get("lower_alpha_boundary")),
        upper_futility_boundary=_list(payload.get("upper_futility_boundary")),
        lower_futility_boundary=_list(payload.get("lower_futility_boundary")),
        required_information_size=_f(payload.get("required_information_size")),
        diversity_adjusted_ris=_f(payload.get("diversity_adjusted_ris")),
        heterogeneity_adjusted_ris=_f(payload.get("heterogeneity_adjusted_ris")),
        crossed_alpha=bool(payload.get("crossed_alpha", False)),
        crossed_futility=bool(payload.get("crossed_futility", False)),
        conclusion=str(payload.get("conclusion") or ""),
        notes=notes,
        plot_path=plot_png if plot_png.exists() else None,
        summary_text=str(payload.get("summary_text") or ""),
        rtsa_raw=payload,
    )


# ---------------------------------------------------------------------------
# Public entry points
# ---------------------------------------------------------------------------

def run_binary_tsa(
    data: pd.DataFrame,
    outcome: OutcomeBinary = "RR",
    output_dir: str | Path = ".",
    plot_basename: str = "TSA_binary",
    config: TSAConfig | None = None,
) -> TSAResult:
    """Run TSA for a binary outcome meta-analysis using RTSA.

    Parameters
    ----------
    data : DataFrame
        Must contain study identifier and arm-level event/total counts.
        Canonical RTSA names ('study', 'eI', 'nI', 'eC', 'nC') are accepted,
        and common aliases ('Author', 'event.e', 'n.e', 'event.c', 'n.c')
        are auto-mapped.
    outcome : 'RR' | 'OR' | 'RD'
    output_dir : path
        Where the TSA plot PNG will be written.
    plot_basename : str
        File-name stem for the plot; '.png' is appended.
    config : TSAConfig, optional
        Defaults: alpha=0.05, power=0.80, two-sided, O'Brien-Fleming
        alpha-spending, no futility, random-effects with DL+HKSJ, tau2
        heterogeneity adjustment.
    """
    if outcome not in ("RR", "OR", "RD"):
        raise TSAError(f"Binary TSA outcome must be RR, OR, or RD; got {outcome!r}.")
    cfg = config or TSAConfig()
    df = _validate_binary(data)
    return _run_rtsa(df, outcome, cfg, Path(output_dir), plot_basename)


def run_continuous_tsa(
    data: pd.DataFrame,
    output_dir: str | Path = ".",
    plot_basename: str = "TSA_continuous",
    config: TSAConfig | None = None,
) -> TSAResult:
    """Run TSA for a continuous (mean-difference) meta-analysis using RTSA.

    Parameters
    ----------
    data : DataFrame
        Must contain study identifier and arm-level mean/SD/N. Canonical
        names: 'study', 'mI', 'sdI', 'nI', 'mC', 'sdC', 'nC'. Aliases such
        as 'mean.e', 'sd.e', 'n.e' (and the .c counterparts) are auto-mapped.
    config : TSAConfig
        For MD designs you typically want config.mc (minimum clinically
        relevant difference) and config.sd_mc (assumed SD) set, otherwise
        RTSA uses the data-driven anticipated effect.
    """
    cfg = config or TSAConfig()
    df = _validate_continuous(data)
    return _run_rtsa(df, "MD", cfg, Path(output_dir), plot_basename)


# ---------------------------------------------------------------------------
# Adapters for the existing binary_outcome.py pipeline
# ---------------------------------------------------------------------------

def from_metabin_dataframe(meta_df: pd.DataFrame) -> pd.DataFrame:
    """Convert an `event.e / n.e / event.c / n.c / Author` DataFrame
    (the format your binary_outcome.py produces) into RTSA's schema."""
    return _validate_binary(meta_df)


def from_metacont_dataframe(meta_df: pd.DataFrame) -> pd.DataFrame:
    """Convert a `mean.e / sd.e / n.e / mean.c / sd.c / n.c / Author`
    DataFrame into RTSA's schema."""
    return _validate_continuous(meta_df)


# ---------------------------------------------------------------------------
# CLI for quick testing
# ---------------------------------------------------------------------------

def _main_cli() -> None:
    import argparse
    parser = argparse.ArgumentParser(description="Run TSA via the RTSA R package.")
    parser.add_argument("csv", type=Path, help="Input CSV file.")
    parser.add_argument("--kind", choices=("binary", "continuous"), required=True)
    parser.add_argument("--outcome", default="RR",
                        help="Binary: RR/OR/RD. Continuous is always MD.")
    parser.add_argument("--output-dir", type=Path, default=Path("."))
    parser.add_argument("--alpha", type=float, default=0.05)
    parser.add_argument("--power", type=float, default=0.80)
    parser.add_argument("--side", type=int, default=2)
    parser.add_argument("--mc", type=float, default=None,
                        help="Minimum clinically relevant effect (MIREDIF).")
    parser.add_argument("--pC", type=float, default=None,
                        help="Control event proportion (binary).")
    parser.add_argument("--sd-mc", type=float, default=None,
                        help="Assumed SD for MD designs.")
    parser.add_argument("--futility", choices=("none", "binding", "non-binding"),
                        default="none")
    parser.add_argument("--random-adj", choices=("tau2", "D2", "I2"), default="tau2")
    parser.add_argument("--fixed", action="store_true",
                        help="Use a fixed/common-effect design.")
    parser.add_argument("--weights", choices=("MH", "IV"), default="MH",
                        help="Pooling weights for binary outcomes.")
    args = parser.parse_args()

    df = pd.read_csv(args.csv)
    cfg = TSAConfig(
        alpha=args.alpha, power=args.power, side=args.side,
        futility=args.futility,
        es_beta="esOF" if args.futility != "none" else None,
        fixed=args.fixed, weights=args.weights, random_adj=args.random_adj,
        mc=args.mc, pC=args.pC, sd_mc=args.sd_mc,
    )
    if args.kind == "binary":
        result = run_binary_tsa(df, outcome=args.outcome, output_dir=args.output_dir,
                                config=cfg)
    else:
        result = run_continuous_tsa(df, output_dir=args.output_dir, config=cfg)

    json_path = Path(args.output_dir) / "tsa_result.json"
    result.write_json(json_path)
    print(f"\nTSA conclusion: {result.conclusion}")
    print(f"Required information size: {result.required_information_size}")
    print(f"Crossed alpha boundary: {result.crossed_alpha}")
    print(f"Crossed futility boundary: {result.crossed_futility}")
    if result.plot_path:
        print(f"Plot: {result.plot_path}")
    print(f"Full result JSON: {json_path}")


if __name__ == "__main__":
    _main_cli()
