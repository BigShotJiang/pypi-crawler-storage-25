from __future__ import annotations

import runpy
import urllib.error
from pathlib import Path

import pandas as pd


def test_runner_scripts_are_packaged() -> None:
    import meta_analysis_streamlit.runner as runner

    runners = runner.runners_dir()
    assert (runners / "main.py").exists()
    assert (runners / "binary_outcome.py").exists()
    assert (runners / "continuous_outcome.py").exists()
    assert (runners / "tsa_analysis.py").exists()


def test_tsa_engine_defaults_to_bundled_module(monkeypatch) -> None:
    monkeypatch.delenv("TSA_ANALYSIS_PY", raising=False)

    import meta_analysis_streamlit.runners.tsa_inference as tsa_inference

    assert tsa_inference.TSA_ANALYSIS_PATH.name == "tsa_analysis.py"
    assert tsa_inference.TSA_ANALYSIS_PATH.exists()


def test_lmstudio_url_generation() -> None:
    from meta_analysis_streamlit.app import lmstudio_models_url

    assert lmstudio_models_url("http://localhost:1234/v1") == [
        "http://localhost:1234/v1/models",
        "http://localhost:1234/api/v0/models",
    ]


def test_openai_compatible_url_generation() -> None:
    from meta_analysis_streamlit.app import (
        is_local_llm_url,
        llm_generation_timeout,
        ollama_api_base,
        openai_compatible_chat_url,
        openai_compatible_models_url,
    )
    from meta_analysis_streamlit.runners.binary_outcome import chat_completions_url, models_url

    gemini_base = "https://generativelanguage.googleapis.com/v1beta/openai"
    assert openai_compatible_models_url("https://api.openai.com/v1") == "https://api.openai.com/v1/models"
    assert openai_compatible_chat_url("https://api.openai.com/v1") == "https://api.openai.com/v1/chat/completions"
    assert openai_compatible_models_url("http://localhost:11434/v1") == "http://localhost:11434/v1/models"
    assert ollama_api_base("http://localhost:11434/v1") == "http://localhost:11434"
    assert models_url(gemini_base) == f"{gemini_base}/models"
    assert chat_completions_url(gemini_base) == f"{gemini_base}/chat/completions"
    assert is_local_llm_url("http://localhost:1234/v1")
    assert is_local_llm_url("http://127.0.0.1:1234/v1")
    assert is_local_llm_url("http://192.168.1.20:1234/v1")
    assert not is_local_llm_url(gemini_base)
    assert llm_generation_timeout("http://localhost:1234/v1", 60) is None
    assert llm_generation_timeout(gemini_base, 60) == 60


def test_openrouter_free_provider_helpers(monkeypatch) -> None:
    from meta_analysis_streamlit.app import (
        OPENROUTER_FREE_MODELS,
        LmStudioStatus,
        PROVIDER_DEFAULTS,
        default_provider,
        openrouter_is_free_model,
        ordered_openrouter_free_models,
    )

    assert PROVIDER_DEFAULTS["OpenRouter Free"]["base_url"] == "https://openrouter.ai/api/v1"
    assert OPENROUTER_FREE_MODELS[0] == "openrouter/free"
    assert openrouter_is_free_model(
        {
            "id": "openai/gpt-oss-120b:free",
            "name": "OpenAI: gpt-oss-120b (free)",
            "pricing": {"prompt": "0", "completion": "0"},
            "architecture": {"input_modalities": ["text"], "output_modalities": ["text"]},
        }
    )
    assert not openrouter_is_free_model(
        {
            "id": "paid/model",
            "name": "Paid model",
            "pricing": {"prompt": "1", "completion": "1"},
            "architecture": {"input_modalities": ["text"], "output_modalities": ["text"]},
        }
    )
    assert ordered_openrouter_free_models(["openai/gpt-oss-120b:free", "custom/free:free"])[:2] == [
        "openrouter/free",
        "openai/gpt-oss-120b:free",
    ]

    monkeypatch.setenv("OPENROUTER_API_KEY", "sk-or-test")
    monkeypatch.setattr("meta_analysis_streamlit.app.check_lmstudio", lambda _url: LmStudioStatus(False, [], ""))
    monkeypatch.setattr("meta_analysis_streamlit.app.check_ollama", lambda _url: LmStudioStatus(False, [], ""))
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    monkeypatch.delenv("GEMINI_API_KEY", raising=False)
    monkeypatch.delenv("GOOGLE_API_KEY", raising=False)
    assert default_provider() == "OpenRouter Free"


def test_runner_auth_headers(monkeypatch) -> None:
    from meta_analysis_streamlit.runners.binary_outcome import llm_request_headers

    monkeypatch.setenv("META_ANALYSIS_LLM_API_KEY", "secret")
    assert llm_request_headers(include_content_type=True) == {
        "Content-Type": "application/json",
        "Authorization": "Bearer secret",
    }


def test_runner_llm_labels_use_provider_and_model(monkeypatch) -> None:
    from meta_analysis_streamlit.runners.binary_outcome import llm_label, llm_provider_label

    monkeypatch.setenv("META_ANALYSIS_LLM_PROVIDER", "OpenRouter Free")
    monkeypatch.setenv("META_ANALYSIS_LLM_MODEL", "openrouter/free")

    assert llm_provider_label() == "OpenRouter Free"
    assert llm_label() == "OpenRouter Free model openrouter/free"
    assert llm_label("openai/gpt-oss-120b:free") == "OpenRouter Free model openai/gpt-oss-120b:free"


def test_excel_title_rows_are_skipped_for_detected_headers(tmp_path) -> None:
    from meta_analysis_streamlit.runners.binary_outcome import load_sheet, workbook_summary

    workbook = tmp_path / "title_rows.xlsx"
    rows = [
        ["Network Meta-Analysis: Arm-Based Continuous Outcomes", None, None, None, None],
        ["One row per randomized arm.", None, None, None, None],
        [None, None, None, None, None],
        ["study_id", "treatment", "mean", "sd", "sample_size"],
        ["N01", "Placebo", 54.7, 9.1, 50],
        ["N01", "A", 50.5, 9.7, 48],
    ]
    pd.DataFrame(rows).to_excel(workbook, index=False, header=False, sheet_name="Network Continuous")

    df = load_sheet(workbook, "Network Continuous")

    assert list(df.columns) == ["study_id", "treatment", "mean", "sd", "sample_size"]
    assert df.shape == (2, 5)
    assert df.loc[0, "study_id"] == "N01"

    _, summary = workbook_summary(workbook)
    assert summary["Network Continuous"]["columns"] == ["study_id", "treatment", "mean", "sd", "sample_size"]


def test_excel_header_row_override_from_env(tmp_path, monkeypatch) -> None:
    from meta_analysis_streamlit.runners.binary_outcome import load_sheet

    workbook = tmp_path / "override_rows.xlsx"
    rows = [
        ["Title row", None, None],
        ["wrong", "header", "row"],
        ["study", "events", "n"],
        ["A", 1, 10],
    ]
    pd.DataFrame(rows).to_excel(workbook, index=False, header=False, sheet_name="Outcome")
    monkeypatch.setenv("META_ANALYSIS_EXCEL_HEADER_ROWS", '{"Outcome": 2}')

    df = load_sheet(workbook, "Outcome")

    assert list(df.columns) == ["study", "events", "n"]
    assert df.iloc[0].to_dict() == {"study": "A", "events": 1, "n": 10}


def test_load_sheet_expands_single_column_comma_delimited_excel_rows(tmp_path) -> None:
    from meta_analysis_streamlit.runners.binary_outcome import default_mapping, load_sheet, validate_data

    workbook = tmp_path / "comma_text.xlsx"
    rows = [
        ["study_id,year,event_treat,non_event_treat,event_control,non_event_control,total_treat,total_control"],
        ["Study_01,2012,18,82,27,73,100,100"],
        ["Study_02,2013,25,95,34,86,120,120"],
    ]
    pd.DataFrame(rows).to_excel(workbook, index=False, header=False, sheet_name="Sheet1")

    df = load_sheet(workbook, "Sheet1")

    assert list(df.columns) == [
        "study_id",
        "year",
        "event_treat",
        "non_event_treat",
        "event_control",
        "non_event_control",
        "total_treat",
        "total_control",
    ]
    assert df.loc[0, "study_id"] == "Study_01"

    mapping = default_mapping(list(df.columns))
    extracted = validate_data(df, mapping)
    assert extracted[["event.e", "n.e", "event.c", "n.c"]].iloc[0].tolist() == [18, 100, 27, 100]


def test_workbook_overview_expands_single_column_csv_rows(tmp_path) -> None:
    from meta_analysis_streamlit.app import workbook_overview

    csv_path = tmp_path / "quoted_lines.csv"
    csv_path.write_text(
        "\n".join(
            [
                '"study_id,year,event_treat,non_event_treat,event_control,non_event_control,total_treat,total_control"',
                '"Study_01,2012,18,82,27,73,100,100"',
                '"Study_02,2013,25,95,34,86,120,120"',
            ]
        ),
        encoding="utf-8",
    )

    overview = workbook_overview(str(csv_path))
    meta = overview["quoted_lines"]
    assert meta["rows"] == 2
    assert meta["columns"][:4] == ["study_id", "year", "event_treat", "non_event_treat"]


def test_workbook_overview_reports_header_metadata(tmp_path) -> None:
    from meta_analysis_streamlit.app import header_overrides_payload, workbook_overview

    workbook = tmp_path / "overview_rows.xlsx"
    rows = [
        ["Network Meta-Analysis: Arm-Based Binary Outcomes", None, None],
        [None, None, None],
        ["study_id", "treatment", "events"],
        ["N01", "A", 4],
    ]
    pd.DataFrame(rows).to_excel(workbook, index=False, header=False, sheet_name="Network Binary")

    overview = workbook_overview(str(workbook), header_overrides_payload({}))

    assert overview["Network Binary"]["header_row"] == 2
    assert overview["Network Binary"]["detected_header_row"] == 2
    assert overview["Network Binary"]["columns"] == ["study_id", "treatment", "events"]
    assert not overview["Network Binary"]["raw_preview"].empty


def test_saved_api_key_helpers(tmp_path) -> None:
    from meta_analysis_streamlit.app import clear_provider_api_key, load_saved_secrets, save_provider_api_key

    secrets_path = tmp_path / "secrets.json"

    save_provider_api_key("OpenAI", "secret", secrets_path)
    assert load_saved_secrets(secrets_path)["OpenAI"] == "secret"

    clear_provider_api_key("OpenAI", secrets_path)
    assert "OpenAI" not in load_saved_secrets(secrets_path)


def test_cli_entrypoint_points_at_app() -> None:
    import meta_analysis_streamlit.cli as cli

    app_path = Path(cli.__file__).with_name("app.py")
    assert app_path.exists()


def test_streamlit_app_loads_as_script() -> None:
    import meta_analysis_streamlit.cli as cli

    app_path = Path(cli.__file__).with_name("app.py")
    namespace = runpy.run_path(str(app_path))

    assert "main" in namespace


def test_r_installer_command_generation() -> None:
    from meta_analysis_streamlit.install_r import r_package_expression

    expression = r_package_expression(["meta", "metafor"])

    assert '"meta"' in expression
    assert '"metafor"' in expression
    assert "https://cloud.r-project.org" in expression
    assert 'type = "binary"' in expression
    assert "install.packages.compile.from.source" in expression


def test_missing_r_packages_uses_line_delimited_output(monkeypatch) -> None:
    import subprocess
    import meta_analysis_streamlit.install_r as install_r

    captured = {}

    def fake_run(command, **_kwargs):
        captured["command"] = command
        return subprocess.CompletedProcess(command, 0, stdout="meta\n", stderr="")

    monkeypatch.setattr(install_r.subprocess, "run", fake_run)
    monkeypatch.setattr(install_r, "rscript_version", lambda _path: (4, 4, 3))

    assert install_r.missing_r_packages(["meta"], rscript="Rscript") == ["meta"]
    assert "collapse = '\\n'" in captured["command"][2]


def test_rscript_path_helpers() -> None:
    from meta_analysis_streamlit.r_runtime import parse_r_version, path_export_command, path_with_rscript

    assert path_export_command("/opt/homebrew/bin/Rscript") == 'export PATH="/opt/homebrew/bin:$PATH"'
    assert path_with_rscript("/usr/bin", "/opt/homebrew/bin/Rscript") == "/opt/homebrew/bin:/usr/bin"
    assert path_with_rscript("/opt/homebrew/bin:/usr/bin", "/opt/homebrew/bin/Rscript") == "/opt/homebrew/bin:/usr/bin"
    assert parse_r_version("R scripting front-end version 4.3.2 (2023-10-31)") == (4, 3, 2)


def test_find_rscript_prefers_supported_r_over_old_path(monkeypatch, tmp_path) -> None:
    import meta_analysis_streamlit.r_runtime as r_runtime

    old_r = tmp_path / "R-3.6.1" / "bin" / "Rscript.exe"
    new_r = tmp_path / "R-4.4.3" / "bin" / "Rscript.exe"
    old_r.parent.mkdir(parents=True)
    new_r.parent.mkdir(parents=True)
    old_r.touch()
    new_r.touch()

    monkeypatch.setattr(r_runtime.shutil, "which", lambda command: str(old_r) if command == "Rscript" else None)
    monkeypatch.setattr(r_runtime, "candidate_rscript_paths", lambda: [old_r, new_r])
    monkeypatch.setattr(
        r_runtime,
        "rscript_version",
        lambda path: (4, 4, 3) if str(path) == str(new_r) else (3, 6, 1),
    )

    selected, on_path = r_runtime.find_rscript()

    assert selected == str(new_r)
    assert on_path is False


def test_missing_r_packages_rejects_old_r(monkeypatch) -> None:
    import pytest
    import meta_analysis_streamlit.install_r as install_r

    monkeypatch.setattr(install_r, "rscript_version", lambda _path: (3, 6, 1))

    with pytest.raises(RuntimeError, match="too old"):
        install_r.missing_r_packages(["meta"], rscript="Rscript")


def test_r_installer_uses_discovered_rscript(monkeypatch) -> None:
    import meta_analysis_streamlit.install_r as install_r

    monkeypatch.setattr(install_r, "find_rscript", lambda: ("/custom/R/bin/Rscript", False))
    commands, _ = install_r.planned_commands(skip_system_r=True)

    assert commands[0][0] == "/custom/R/bin/Rscript"


def test_r_installer_prefers_conda_when_r_missing(monkeypatch) -> None:
    import meta_analysis_streamlit.install_r as install_r

    monkeypatch.setattr(install_r, "find_rscript", lambda: (None, False))
    monkeypatch.setattr(install_r.shutil, "which", lambda command: "/opt/anaconda3/bin/conda" if command == "conda" else None)
    monkeypatch.setenv("CONDA_PREFIX", "/opt/anaconda3")

    commands, _ = install_r.system_r_commands()

    assert commands == [["/opt/anaconda3/bin/conda", "install", "-y", "-c", "conda-forge", "r-base"]]


def test_binary_route_uses_specialized_single_sheet_runner(tmp_path) -> None:
    from meta_analysis_streamlit.app import build_command

    command = build_command(
        input_path=tmp_path / "workbook.xlsx",
        output_root=tmp_path / "outputs",
        route="Binary pairwise",
        selected_sheets=["Outcome A"],
        outcome_name="Outcome A",
        lmstudio_enabled=False,
        lmstudio_url="http://localhost:1234/v1",
        model_id="",
        binary_effect_size="RR",
        analysis_engine="bayesian",
        network_engine="frequentist",
        network_effect="auto",
        network_model="random",
        single_arm_type="auto",
        diagnostic_mode="single",
        jobs=1,
        dry_run=False,
        install_r_packages=False,
    )

    assert any(part.endswith("binary_outcome.py") for part in command)
    assert "--sheet" in command
    assert "Outcome A" in command
    assert command[command.index("--binary-effect-size") + 1] == "RR"
    assert command[command.index("--engine") + 1] == "bayesian"
    assert command[command.index("--subgroup-columns") + 1] == "none"
    assert "--sheets" not in command
    assert "--no-lmstudio" in command


def test_empty_subgroups_disable_runner_auto_subgroups(tmp_path) -> None:
    from meta_analysis_streamlit.app import build_command

    command = build_command(
        input_path=tmp_path / "workbook.xlsx",
        output_root=tmp_path / "outputs",
        route="Auto route workbook",
        selected_sheets=["Outcome A", "Outcome B"],
        outcome_name="Outcome A",
        lmstudio_enabled=False,
        lmstudio_url="http://localhost:1234/v1",
        model_id="",
        binary_effect_size="auto",
        network_engine="frequentist",
        network_effect="auto",
        network_model="random",
        single_arm_type="auto",
        diagnostic_mode="single",
        jobs=1,
        dry_run=False,
        install_r_packages=False,
        subgroup_columns=[],
    )

    assert command[command.index("--subgroup-columns") + 1] == "none"


def test_auto_route_passes_global_analysis_engine(tmp_path) -> None:
    from meta_analysis_streamlit.app import build_command

    command = build_command(
        input_path=tmp_path / "workbook.xlsx",
        output_root=tmp_path / "outputs",
        route="Auto route workbook",
        selected_sheets=["Outcome A", "Outcome B"],
        outcome_name="",
        lmstudio_enabled=False,
        lmstudio_url="http://localhost:1234/v1",
        model_id="",
        binary_effect_size="auto",
        analysis_engine="both",
        network_engine="frequentist",
        network_effect="auto",
        network_model="random",
        single_arm_type="auto",
        diagnostic_mode="single",
        jobs=1,
        dry_run=False,
        install_r_packages=False,
    )

    assert command[command.index("--analysis-engine") + 1] == "both"


def test_selected_subgroups_are_still_passed(tmp_path) -> None:
    from meta_analysis_streamlit.app import build_command

    command = build_command(
        input_path=tmp_path / "workbook.xlsx",
        output_root=tmp_path / "outputs",
        route="Binary pairwise",
        selected_sheets=["Outcome A"],
        outcome_name="Outcome A",
        lmstudio_enabled=False,
        lmstudio_url="http://localhost:1234/v1",
        model_id="",
        binary_effect_size="RR",
        network_engine="frequentist",
        network_effect="auto",
        network_model="random",
        single_arm_type="auto",
        diagnostic_mode="single",
        jobs=1,
        dry_run=False,
        install_r_packages=False,
        subgroup_columns=["Etiology"],
    )

    assert command[command.index("--subgroup-columns") + 1] == "Etiology"


def test_binary_route_passes_selected_odds_ratio(tmp_path) -> None:
    from meta_analysis_streamlit.app import build_command

    command = build_command(
        input_path=tmp_path / "workbook.xlsx",
        output_root=tmp_path / "outputs",
        route="Binary pairwise",
        selected_sheets=["Outcome A"],
        outcome_name="Outcome A",
        lmstudio_enabled=False,
        lmstudio_url="http://localhost:1234/v1",
        model_id="",
        binary_effect_size="OR",
        network_engine="frequentist",
        network_effect="auto",
        network_model="random",
        single_arm_type="auto",
        diagnostic_mode="single",
        jobs=1,
        dry_run=False,
        install_r_packages=False,
    )

    assert command[command.index("--binary-effect-size") + 1] == "OR"


def test_binary_runner_applies_effect_size_override() -> None:
    from meta_analysis_streamlit.runners.binary_outcome import apply_binary_effect_size_override

    mapping = {
        "columns": {
            "study_label": "Study",
            "event_e": "Events E",
            "n_e": "Total E",
            "event_c": "Events C",
            "n_c": "Total C",
        },
        "analysis": {
            "summary_measure": "RR",
            "summary_measure_reason": "Risk Ratio is the default for raw binary intervention/control counts.",
            "pooling_method": "Peto",
            "pooling_method_reason": "Auto-selected for rare events.",
        },
    }

    assert apply_binary_effect_size_override(mapping, "OR")
    assert mapping["analysis"]["summary_measure"] == "OR"
    assert mapping["analysis"]["pooling_method"] == "Peto"


def test_binary_runner_decodes_abbreviated_treat_control_csv_shape() -> None:
    from meta_analysis_streamlit.runners.binary_outcome import default_mapping, validate_data

    df = pd.DataFrame(
        {
            "study_id": ["Study_01", "Study_02"],
            "year": [2012, 2013],
            "event_treat": [18, 25],
            "non_event_treat": [82, 95],
            "event_control": [27, 34],
            "non_event_control": [73, 86],
            "total_treat": [100, 120],
            "total_control": [100, 120],
        }
    )

    mapping = default_mapping(list(df.columns))
    assert mapping["columns"]["study_label"] == "study_id"
    assert mapping["columns"]["event_e"] == "event_treat"
    assert mapping["columns"]["n_e"] == "total_treat"
    assert mapping["columns"]["event_c"] == "event_control"
    assert mapping["columns"]["n_c"] == "total_control"

    extracted = validate_data(df, mapping)
    assert list(extracted[["Author", "event.e", "n.e", "event.c", "n.c"]].iloc[0]) == [
        "Study_01",
        18,
        100,
        27,
        100,
    ]


def test_binary_runner_derives_totals_from_non_event_columns() -> None:
    from meta_analysis_streamlit.runners.binary_outcome import default_mapping, validate_data

    df = pd.DataFrame(
        {
            "study_id": ["Study_01", "Study_02"],
            "event_treat": [18, 25],
            "non_event_treat": [82, 95],
            "event_control": [27, 34],
            "non_event_control": [73, 86],
        }
    )

    mapping = default_mapping(list(df.columns))
    assert mapping["columns"]["non_event_e"] == "non_event_treat"
    assert mapping["columns"]["non_event_c"] == "non_event_control"
    assert "n_e" not in mapping["columns"]
    assert "n_c" not in mapping["columns"]

    extracted = validate_data(df, mapping)
    assert extracted["n.e"].tolist() == [100, 120]
    assert extracted["n.c"].tolist() == [100, 120]


def test_binary_runner_accepts_arm_labels_from_column_suffixes() -> None:
    from meta_analysis_streamlit.runners.binary_outcome import prompt_for_arm_labels_if_needed

    mapping = {
        "intervention_label": "treat",
        "control_label": "control",
        "columns": {
            "event_e": "event_treat",
            "n_e": "total_treat",
            "event_c": "event_control",
            "n_c": "total_control",
        },
    }

    prompt_for_arm_labels_if_needed(mapping, assume_yes=False)

    assert mapping["intervention_label"] == "treat"
    assert mapping["control_label"] == "control"


def test_binary_runner_applies_endpoint_overrides() -> None:
    from meta_analysis_streamlit.runners.binary_outcome import apply_binary_endpoint_overrides

    mapping = {
        "intervention_label": "Experimental",
        "control_label": "Control",
        "columns": {
            "study_label": "Study",
            "event_e": "Wrong event",
            "n_e": "Wrong total",
        },
    }
    columns = ["study_id", "event_treat", "total_treat", "event_control", "total_control"]

    apply_binary_endpoint_overrides(
        mapping,
        columns,
        study_column="study_id",
        event_e_column="event_treat",
        n_e_column="total_treat",
        event_c_column="event_control",
        n_c_column="total_control",
        intervention_label="treat",
        control_label="control",
    )

    assert mapping["columns"] == {
        "study_label": "study_id",
        "event_e": "event_treat",
        "n_e": "total_treat",
        "event_c": "event_control",
        "n_c": "total_control",
    }
    assert mapping["intervention_label"] == "treat"
    assert mapping["control_label"] == "control"


def test_binary_route_can_install_r_packages(tmp_path) -> None:
    from meta_analysis_streamlit.app import build_command

    command = build_command(
        input_path=tmp_path / "workbook.xlsx",
        output_root=tmp_path / "outputs",
        route="Binary pairwise",
        selected_sheets=["Outcome A"],
        outcome_name="Outcome A",
        lmstudio_enabled=False,
        lmstudio_url="http://localhost:1234/v1",
        model_id="",
        binary_effect_size="RR",
        network_engine="frequentist",
        network_effect="auto",
        network_model="random",
        single_arm_type="auto",
        diagnostic_mode="single",
        jobs=1,
        dry_run=False,
        install_r_packages=True,
    )

    assert "--install-r-packages" in command


def test_binary_route_can_override_endpoint_columns(tmp_path) -> None:
    from meta_analysis_streamlit.app import build_command

    command = build_command(
        input_path=tmp_path / "workbook.csv",
        output_root=tmp_path / "outputs",
        route="Binary pairwise",
        selected_sheets=["Outcome A"],
        outcome_name="Outcome A",
        lmstudio_enabled=False,
        lmstudio_url="http://localhost:1234/v1",
        model_id="",
        binary_effect_size="RR",
        network_engine="frequentist",
        network_effect="auto",
        network_model="random",
        single_arm_type="auto",
        diagnostic_mode="single",
        jobs=1,
        dry_run=False,
        install_r_packages=False,
        binary_endpoint_columns={
            "study_label": "study_id",
            "event_e": "event_treat",
            "n_e": "total_treat",
            "event_c": "event_control",
            "n_c": "total_control",
        },
        intervention_label="treat",
        control_label="control",
    )

    assert command[command.index("--study-column") + 1] == "study_id"
    assert command[command.index("--event-e-column") + 1] == "event_treat"
    assert command[command.index("--n-c-column") + 1] == "total_control"
    assert command[command.index("--intervention-label") + 1] == "treat"
    assert command[command.index("--control-label") + 1] == "control"


def test_auto_route_can_select_all_sheets(tmp_path) -> None:
    from meta_analysis_streamlit.app import build_command

    command = build_command(
        input_path=tmp_path / "workbook.xlsx",
        output_root=tmp_path / "outputs",
        route="Auto route workbook",
        selected_sheets=["Outcome A", "Outcome B"],
        outcome_name="",
        lmstudio_enabled=False,
        lmstudio_url="http://localhost:1234/v1",
        model_id="",
        binary_effect_size="auto",
        network_engine="frequentist",
        network_effect="auto",
        network_model="random",
        single_arm_type="auto",
        diagnostic_mode="single",
        jobs=1,
        dry_run=False,
        install_r_packages=False,
        analyze_all_sheets=True,
    )

    assert any(part.endswith("main.py") for part in command)
    assert "--all-sheets" in command
    assert "--sheets" not in command


def test_auto_group_suggestions_skip_study_identifier() -> None:
    from meta_analysis_streamlit.app import auto_group_columns

    df = pd.DataFrame(
        {
            "Study": ["A", "B", "C", "D"],
            "Etiology": ["Malignant", "Benign", "Malignant", "Benign"],
            "Events": [1, 2, 3, 4],
        }
    )

    assert auto_group_columns(df, list(df.columns)) == ["Etiology"]


def test_route_helpers_normalize_llm_and_column_routes() -> None:
    from meta_analysis_streamlit.app import (
        heuristic_route_from_columns,
        normalize_route,
        recommended_ollama_model,
        release_update_notes,
        route_count_summary,
        runtime_estimate_label,
        version_tuple,
    )

    assert normalize_route("binary_pairwise") == "Binary pairwise"
    assert heuristic_route_from_columns(["Study", "event.e", "n.e", "event.c", "n.c"]) == "Binary pairwise"
    assert (
        heuristic_route_from_columns(
            ["study_id", "event_treat", "non_event_treat", "event_control", "non_event_control"]
        )
        == "Binary pairwise"
    )
    assert heuristic_route_from_columns(["Study", "mean.e", "sd.e", "n.e", "mean.c", "sd.c"]) == "Continuous pairwise"
    assert recommended_ollama_model(8, "CPU only") == "llama3.2:3b"
    assert recommended_ollama_model(16, "NVIDIA GPU") == "llama3.1:8b"
    assert recommended_ollama_model(64, "Apple Silicon GPU") == "qwen3:14b"
    assert version_tuple("0.1.10") > version_tuple("0.1.9")
    assert any("canonical PyPI" in note for note in release_update_notes("0.1.36"))
    assert any("Analysis engine selector" in note for note in release_update_notes("0.1.35"))
    assert any("Bayesian" in note for note in release_update_notes("0.1.33"))
    assert release_update_notes("9.9.9", {"info": {"summary": "Future release summary."}}) == ["Future release summary."]
    assert "Binary pairwise: 2" in route_count_summary({"A": "Binary pairwise", "B": "Binary pairwise"})
    assert runtime_estimate_label(3, "Auto route workbook", jobs=2, use_llm=True) != "No sheets selected"


def test_streamlit_restart_command_preserves_app_args() -> None:
    from meta_analysis_streamlit.app import streamlit_restart_command

    command = streamlit_restart_command(["streamlit", "run", "/tmp/app.py", "--server.port", "8502"])

    assert command[:4][1:] == ["-m", "streamlit", "run"]
    assert command[-2:] == ["--server.port", "8502"]
    assert command[4].endswith("app.py")


def test_llm_route_payload_compacts_all_sheet_assessment() -> None:
    from meta_analysis_streamlit.app import workbook_assessment_payload

    overview = {
        f"Outcome {index}": {
            "rows": 10,
            "columns": ["Study", "event.e", "n.e", "event.c", "n.c"],
            "preview": pd.DataFrame(
                {
                    "Study": ["A", "B", "C"],
                    "event.e": [1, 2, 3],
                    "n.e": [10, 20, 30],
                    "event.c": [2, 3, 4],
                    "n.c": [11, 21, 31],
                }
            ),
            "detected_header_row": 0,
            "header_row": 0,
            "header_source": "Auto detected",
            "raw_preview": pd.DataFrame([["Study", "event.e", "n.e", "event.c", "n.c"]]),
        }
        for index in range(12)
    }

    payload = workbook_assessment_payload(overview, list(overview))

    assert payload["selected_sheet_count"] == 12
    assert payload["included_sheet_count"] == 12
    assert payload["sheets"][0]["heuristic_route"] == "Binary pairwise"
    assert payload["sheets"][0]["active_header_row_1_based"] == 1
    assert "sample_rows" in payload["sheets"][0]
    assert "raw_top_rows" in payload["sheets"][0]
    assert "sample_rows" not in payload["sheets"][-1]


def test_hosted_llm_does_not_auto_assess_multiple_sheets() -> None:
    from meta_analysis_streamlit.app import hosted_multi_sheet_route_reason, should_auto_assess_routes_with_llm

    assert should_auto_assess_routes_with_llm("Gemini", ["A"], True, "gemini-model")
    assert not should_auto_assess_routes_with_llm("Gemini", ["A", "B"], True, "gemini-model")
    assert not should_auto_assess_routes_with_llm("OpenAI", ["A", "B"], True, "gpt-model")
    assert should_auto_assess_routes_with_llm("LM Studio", ["A", "B"], True, "local-model")
    assert should_auto_assess_routes_with_llm("Ollama", ["A", "B"], True, "local-model")
    assert "Gemini API rate limits" in hosted_multi_sheet_route_reason("Gemini")


def test_sheet_route_display_uses_active_assessment_when_available() -> None:
    from meta_analysis_streamlit.app import sheet_routes_for_display

    overview = {
        "Outcome A": {"rows": 5, "columns": ["Study", "mean.e", "sd.e", "n.e"], "preview": pd.DataFrame()},
        "Outcome B": {"rows": 5, "columns": ["Study", "event.e", "n.e"], "preview": pd.DataFrame()},
    }

    routes, source = sheet_routes_for_display(
        overview,
        ["Outcome A", "Outcome B"],
        {"source": "LLM", "sheet_routes": {"Outcome A": "Continuous pairwise", "Outcome B": "Binary pairwise"}},
    )

    assert source == "LLM"
    assert routes["Outcome A"] == "Continuous pairwise"
    assert routes["Outcome B"] == "Binary pairwise"


def test_analysis_by_sheet_table_uses_per_sheet_routes_for_auto() -> None:
    from meta_analysis_streamlit.app import analysis_by_sheet_table

    overview = {
        "Outcome A": {"rows": 5, "columns": ["Study", "mean.e", "sd.e", "n.e"]},
        "Outcome B": {"rows": 6, "columns": ["Study", "event.e", "n.e", "event.c", "n.c"]},
    }

    table = analysis_by_sheet_table(
        overview,
        ["Outcome A", "Outcome B"],
        {"Outcome A": "Continuous pairwise", "Outcome B": "Binary pairwise"},
        "Auto route workbook",
    )

    assert table["Analysis"].tolist() == ["Continuous pairwise", "Binary pairwise"]


def test_analysis_by_sheet_table_uses_specialized_route_for_all_display_rows() -> None:
    from meta_analysis_streamlit.app import analysis_by_sheet_table

    overview = {
        "Outcome A": {"rows": 5, "columns": ["Study"]},
        "Outcome B": {"rows": 6, "columns": ["Study"]},
    }

    table = analysis_by_sheet_table(
        overview,
        ["Outcome A", "Outcome B"],
        {"Outcome A": "Continuous pairwise", "Outcome B": "Binary pairwise"},
        "Binary pairwise",
    )

    assert table["Analysis"].tolist() == ["Binary pairwise", "Binary pairwise"]


def test_friendly_llm_errors_hide_raw_429() -> None:
    from meta_analysis_streamlit.app import friendly_llm_interpretation_error, friendly_llm_route_error

    error = urllib.error.HTTPError(
        "https://api.example.test/v1/chat/completions",
        429,
        "Too Many Requests",
        {},
        None,
    )

    route_message = friendly_llm_route_error(error)
    interpretation_message = friendly_llm_interpretation_error(error)

    assert "rate-limited" in route_message
    assert "429" not in route_message
    assert "rate-limited" in interpretation_message
    assert "429" not in interpretation_message


def test_output_image_discovery_shows_all_analysis_images(tmp_path) -> None:
    from meta_analysis_streamlit.app import discover_output_images

    output = tmp_path / "outputs"
    outcome = output / "01_Outcome A"
    outcome.mkdir(parents=True)
    forest = outcome / "ForestplotOutcome A.png"
    funnel = outcome / "FunnelOutcome A.png"
    leave_one_out = outcome / "LeaveOneOutSensitivityOutcome A.png"
    baujat = outcome / "BaujatOutcome A.png"
    forest.write_bytes(b"fake")
    funnel.write_bytes(b"fake")
    leave_one_out.write_bytes(b"fake")
    baujat.write_bytes(b"fake")

    images = discover_output_images(output)

    assert [item["path"].name for item in images] == [
        "ForestplotOutcome A.png",
        "LeaveOneOutSensitivityOutcome A.png",
        "BaujatOutcome A.png",
        "FunnelOutcome A.png",
    ]
    assert {item["category"] for item in images} == {"Forest", "Leave-one-out", "Baujat", "Funnel"}


def test_vision_helpers_and_image_data_url(tmp_path) -> None:
    from PIL import Image
    from meta_analysis_streamlit.app import image_data_url, likely_vision_model, provider_from_base_url, vision_model_suggestions

    image_path = tmp_path / "plot.png"
    Image.new("RGB", (1, 1), color="white").save(image_path)

    assert likely_vision_model("gemini-2.5-flash")
    assert likely_vision_model("gpt-4o-mini")
    assert likely_vision_model("llama3.2-vision")
    assert likely_vision_model("llama-4-maverick-17b-128e-instruct")
    assert not likely_vision_model("text-embedding-3-small")
    assert provider_from_base_url("https://generativelanguage.googleapis.com/v1beta/openai") == "Gemini"
    assert "gemini-2.5-flash" in vision_model_suggestions("Gemini")
    assert image_data_url(image_path).startswith("data:image/png;base64,")


def test_probe_vision_support_sends_tiny_image(monkeypatch) -> None:
    import meta_analysis_streamlit.app as app

    captured = {}

    def fake_chat(**kwargs):
        captured.update(kwargs)
        return "VISION_OK"

    monkeypatch.setattr(app, "call_openai_compatible_chat", fake_chat)

    result = app.probe_vision_support(
        base_url="https://api.example.test/v1",
        model_id="llama-4-maverick-17b-128e-instruct",
        api_key="secret",
        auth_header="Authorization",
        auth_prefix="Bearer",
    )

    content = captured["messages"][1]["content"]
    assert "VISION_OK" in result
    assert content[1]["type"] == "image_url"
    assert content[1]["image_url"]["url"].startswith("data:image/png;base64,")


def test_interpret_selected_image_can_send_image_payload(monkeypatch, tmp_path) -> None:
    from PIL import Image
    import meta_analysis_streamlit.app as app

    image_path = tmp_path / "forest.png"
    Image.new("RGB", (1, 1), color="white").save(image_path)
    captured = {}

    def fake_chat(**kwargs):
        captured.update(kwargs)
        return "ok"

    monkeypatch.setattr(app, "call_openai_compatible_chat", fake_chat)

    result = app.interpret_selected_image(
        image={"path": image_path, "label": "Forest - Outcome", "category": "Forest", "context": ""},
        base_url="https://api.openai.com/v1",
        model_id="gpt-4o",
        api_key="secret",
        auth_header="Authorization",
        auth_prefix="Bearer",
        include_image=True,
    )

    user_content = captured["messages"][1]["content"]
    assert result == "ok"
    assert isinstance(user_content, list)
    assert user_content[1]["type"] == "image_url"
    assert user_content[1]["image_url"]["url"].startswith("data:image/png;base64,")
    assert "publication-ready Results paragraph" in user_content[0]["text"]
    assert "Return exactly one polished paragraph" in user_content[0]["text"]
    assert "For meta-regression" in user_content[0]["text"]
    assert "For Trial Sequential Analysis (TSA)" in user_content[0]["text"]
    assert "red alpha-spending boundary" in user_content[0]["text"]
    assert "naive significance boundary" in user_content[0]["text"]
    assert "AIS" in user_content[0]["text"]
    assert "HARIS" in user_content[0]["text"]


def test_image_context_includes_statistical_text_and_tables(tmp_path) -> None:
    from meta_analysis_streamlit.app import image_context_text

    output = tmp_path / "outputs"
    outcome = output / "01_Outcome A"
    outcome.mkdir(parents=True)
    image_path = outcome / "ForestplotOutcome A.png"
    image_path.write_bytes(b"fake")
    (outcome / "analysis-summary.txt").write_text(
        "Overall effect RR 0.72, 95% CI 0.55 to 0.95, p = 0.02\n"
        "Heterogeneity: I^2 = 41%, tau^2 = 0.08\n",
        encoding="utf-8",
    )
    pd.DataFrame(
        {
            "effect": ["RR"],
            "estimate": [0.72],
            "ci_lower": [0.55],
            "ci_upper": [0.95],
            "p_value": [0.02],
            "i2": [41],
        }
    ).to_csv(outcome / "effect-results.csv", index=False)

    context = image_context_text(image_path, output)

    assert "p = 0.02" in context
    assert "p_value" in context
    assert "I^2" in context or "i2" in context


def test_image_context_includes_metaregression_tables(tmp_path) -> None:
    from meta_analysis_streamlit.app import image_context_text

    output = tmp_path / "outputs"
    outcome = output / "01_Outcome A"
    outcome.mkdir(parents=True)
    image_path = outcome / "MetaRegressionOutcome A.png"
    image_path.write_bytes(b"fake")
    pd.DataFrame(
        {
            "moderator": ["randomized_trial_regressor"],
            "coefficient": [0.14],
            "ci_lower": [-0.03],
            "ci_upper": [0.31],
            "p_value": [0.11],
            "test_of_moderators_p": [0.11],
        }
    ).to_csv(outcome / "MetaRegressionOutcome A.csv", index=False)

    context = image_context_text(image_path, output)

    assert "randomized_trial_regressor" in context
    assert "coefficient" in context
    assert "test_of_moderators_p" in context


def test_image_context_prioritizes_tsa_outputs(tmp_path) -> None:
    from meta_analysis_streamlit.app import image_context_text

    output = tmp_path / "outputs"
    outcome = output / "01_Outcome A"
    outcome.mkdir(parents=True)
    image_path = outcome / "TSAOutcome A.png"
    image_path.write_bytes(b"fake")
    (outcome / "TSAOutcome A.txt").write_text(
        "Pooled effect (RR) 0.55 (95% SW-adjusted CI: 0.32;0.74), "
        "SW p-value 7e-04\nAIS 2008; HARIS 2318; alpha boundaries not crossed\n",
        encoding="utf-8",
    )
    pd.DataFrame(
        {
            "milestone": ["AIS", "HARIS"],
            "information_size": [2008, 2318],
        }
    ).to_csv(outcome / "TSAOutcome A.csv", index=False)

    context = image_context_text(image_path, output)

    assert "SW-adjusted CI" in context
    assert "alpha boundaries not crossed" in context
    assert "HARIS" in context


def test_auto_route_filters_missing_column_overrides() -> None:
    import argparse
    import sys

    runners = Path(__file__).resolve().parents[1] / "meta_analysis_streamlit" / "runners"
    sys.path.insert(0, str(runners))
    import main as main_runner

    item = main_runner.PlannedAnalysis(
        index=2,
        sheet="Clinical success",
        rows=21,
        columns=["Study", "Etiology", "Control type", "clinical_success_definition_regressor"],
        outcome_name="Clinical success",
        analysis_type="binary_pairwise",
    )
    args = argparse.Namespace(
        yes=True,
        no_lmstudio=True,
        lmstudio_url="http://localhost:1234/v1",
        model="",
        group_column="Study",
        subgroup_columns="Study,Etiology,adverse_event_definition_regressor",
        covariate_columns="clinical_success_definition_regressor,adverse_event_definition_regressor",
        network_engine="frequentist",
        rank_sims=100000,
        install_r_packages=False,
    )

    command = main_runner.runner_command(item, Path("book.xlsx"), Path("outputs"), args)

    assert command is not None
    assert "--subgroup-columns" in command
    assert command[command.index("--subgroup-columns") + 1] == "Study,Etiology"
    assert "--covariate-columns" in command
    assert command[command.index("--covariate-columns") + 1] == "clinical_success_definition_regressor"
    assert "adverse_event_definition_regressor" not in command


def test_error_log_writer(tmp_path) -> None:
    import sys

    runners = Path(__file__).resolve().parents[1] / "meta_analysis_streamlit" / "runners"
    sys.path.insert(0, str(runners))
    import main as main_runner

    log_path = main_runner.write_analysis_error_log(
        tmp_path,
        [
            {
                "sheet": "Outcome A",
                "outcome": "Outcome A",
                "analysis_type": "Binary pairwise",
                "returncode": 1,
                "output_dir": str(tmp_path / "01_Outcome A"),
                "runner_log": str(tmp_path / "01_Outcome A" / "runner-output.log"),
                "command": "python binary_outcome.py",
                "tail": "Rscript was not found",
            }
        ],
    )

    text = log_path.read_text(encoding="utf-8")
    assert "Outcome A" in text
    assert "Rscript was not found" in text
    assert (tmp_path / "analysis-errors.json").exists()


def test_network_bayesian_skip_note_mentions_jags(tmp_path) -> None:
    import sys

    runners = Path(__file__).resolve().parents[1] / "meta_analysis_streamlit" / "runners"
    sys.path.insert(0, str(runners))
    import network_meta_analysis as nma

    note_path = nma.write_bayesian_skip_note(
        tmp_path,
        "Outcome",
        "rjags: Library not loaded: /usr/local/lib/libjags.4.dylib",
    )

    text = note_path.read_text(encoding="utf-8")
    assert "Bayesian network meta-analysis skipped" in text
    assert "brew install jags" in text
    assert "libjags.4.dylib" in text
