from __future__ import annotations

import asyncio
from goliath_utils.logger import Logger

log = Logger("lambda_demo")


async def main(event: dict, context: dict) -> dict:
    log.info("Hello from Goliath job packager")
    log.info("Event:", event=event)
    log.info("Context:", context=context)

    return {
        "success": True,
        "message": "Job completed successfully",
    }


if __name__ == "__main__":
    sample_event = {"job_id": "example-123", "action": "process"}
    sample_context = {"region": "us-east-1", "timeout": 300}
    asyncio.run(main(sample_event, sample_context))
