from __future__ import annotations

import asyncio
from goliath_utils.logger import Logger

log = Logger("pln1")


async def main(args: dict, context: dict) -> dict:
    log.info("Hello from Goliath pipelines")
    log.info("Context:", context=context)

    file_path = args["file_path"]       # /srv/sftp/<user>/processing/<file>
    file_name = args["file_name"]       # original filename
    username = args["username"]         # SFTP username
    trigger_id = args["trigger_id"]
    event_id = args["event_id"]

    return {
        "error": 0,
        "success": True,
        "message": "Job completed successfully",
        "file_path": file_path,
        "file_name": file_name,
        "username": username,
        "trigger_id": trigger_id,
        "event_id": event_id
    }


if __name__ == "__main__":
    sample_event = {"job_id": "example-123", "action": "process"}
    sample_context = {"region": "us-east-1", "timeout": 300}
    asyncio.run(main(sample_event, sample_context))
