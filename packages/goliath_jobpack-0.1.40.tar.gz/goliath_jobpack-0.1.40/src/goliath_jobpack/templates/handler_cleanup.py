from __future__ import annotations

import asyncio
from goliath_utils.logger import Logger
from goliath_utils.atrax import DataSet
from goliath_utils.db import get_db

log = Logger("lambda_demo")


async def main(event: dict, context: dict) -> dict:
    log.info("running clean core_lambda_logs")
    log.info("Event:", event=event)
    log.info("Context:", context=context)


    # Connect using credentials from the Goliath secrets API
    db = get_db()

    # remove any logs older than 3 days
    query = """
       WITH deleted AS (
            DELETE FROM core_lambda_logs
            WHERE logged_at < NOW() - INTERVAL '3 days'
            RETURNING 1
        )
        SELECT COUNT(*) AS rows_deleted
        FROM deleted;
    """
    rows_deleted = await db.fetch_val(query)
    log.info(f'{rows_deleted} rows deleted')
    log.info('finished')

    return {
        'error': 0,
        'success': True,
        'msg': f'{rows_deleted} rows deleted'
    }

if __name__ == "__main__":
    sample_event = {"job_id": "example-123", "action": "process"}
    sample_context = {"region": "us-east-1", "timeout": 300}
    asyncio.run(main(sample_event, sample_context))
