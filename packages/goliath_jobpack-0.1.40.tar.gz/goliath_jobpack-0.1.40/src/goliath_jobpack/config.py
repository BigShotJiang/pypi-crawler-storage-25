from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

try:
    import tomllib
except ModuleNotFoundError:  # pragma: no cover
    import tomli as tomllib  # type: ignore


@dataclass
class BuildConfig:
    include: list[str] = field(default_factory=lambda: ["handler.py"])
    requirements: str = "requirements.txt"


ALLOWED_RUNTIMES = {"python3.11", "python3.12"}


@dataclass
class JobConfig:
    name: str
    version: str = "0.1.0"
    runtime: str = "python3.12"
    entrypoint: str = "handler:main"
    timeout_seconds: int = 300
    build: BuildConfig = field(default_factory=BuildConfig)

    def __post_init__(self) -> None:
        if self.runtime not in ALLOWED_RUNTIMES:
            raise ValueError(
                f"Unsupported runtime '{self.runtime}'. Allowed: {sorted(ALLOWED_RUNTIMES)}"
            )
        if ":" not in self.entrypoint:
            raise ValueError("Entrypoint must look like module:function, e.g. handler:main")
        if isinstance(self.build, dict):
            self.build = BuildConfig(**self.build)


def load_job_config(project_dir: Path) -> JobConfig:
    config_path = project_dir / "job.toml"
    if not config_path.exists():
        raise FileNotFoundError(f"Missing job.toml in {project_dir}")

    data: dict[str, Any]
    with config_path.open("rb") as f:
        data = tomllib.load(f)

    return JobConfig(**data)
