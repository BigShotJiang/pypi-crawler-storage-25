# goliath-jobpack
CLI for building and uploading Python job packages.

install:
```bash
uv add goliath-jobpack
```

usage:
```bash
uv run goliath-jobpack init /examples/my_first_job
uv run goliath-jobpack --help
uv run goliath-jobpack validate ./infra/examples/my_first_job
uv run goliath-jobpack build ./infra/examples/my_first_job
uv run  goliath-jobpack upload ./infra/examples/my_first_job/dist/my-job.zip --bucket your-bucket-name
uv run goliath-jobpack package ./infra/examples/my_first_job --bucket your-bucket-name

```

to publish:
```bash
cd /home/goliath/code/goliath/infra/jobpack
uv run twine upload dist/*
```