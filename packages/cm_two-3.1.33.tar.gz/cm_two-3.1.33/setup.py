from setuptools import setup, find_packages
from os.path import join, dirname
import sys

install_requires = [
    'tk',
    'pillow',
    'pyautogui',
    'tkcalendar',
    'screeninfo',
    'psycopg-binary',
    'gtki_module_exex',
    'gtki_module_treeview==2.9',
    'qodex_pi==0.9.1',
    'qsct==0.95',
    'cmadb==0.0.1',
    'cm_qdk==0.0.1',
    'imutils',
    'numpy',
    'opencv-python>=4.8',
    'fontTools',
    'setuptools',
    'wsqluse',
    'XLsxWriter==3.0.3',
    'ar_one_qdk',
    'Cython'
]

if sys.platform == "win32":
    install_requires.append("pypiwin32")

setup(
    name='cm_two',
    version='3.1.33',
    packages=find_packages(),
    author='PunchyArchy',
    long_description=open(join(dirname(__file__), 'README.txt')).read(),
    include_package_data=True,
    install_requires=install_requires,
    package_data={
        # Предполагается, что папка imgs находится внутри одного из модулей
        # например: cm_two/imgs/*.png
        'cm': ['imgs/*.png'],
    },
)
