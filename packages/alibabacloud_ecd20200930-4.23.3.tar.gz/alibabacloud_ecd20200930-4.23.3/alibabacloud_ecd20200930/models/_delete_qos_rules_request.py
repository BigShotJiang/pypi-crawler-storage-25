# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from typing import List

from darabonba.model import DaraModel

class DeleteQosRulesRequest(DaraModel):
    def __init__(
        self,
        qos_rule_id: List[str] = None,
    ):
        # This parameter is required.
        self.qos_rule_id = qos_rule_id

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.qos_rule_id is not None:
            result['QosRuleId'] = self.qos_rule_id

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('QosRuleId') is not None:
            self.qos_rule_id = m.get('QosRuleId')

        return self

