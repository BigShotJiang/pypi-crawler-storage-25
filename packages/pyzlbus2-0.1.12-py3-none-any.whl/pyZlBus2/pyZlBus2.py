#!/usr/bin/env python3
# -*- coding: utf-8 -*-

#====================================================================
# 固件版本支持 V00.92.19.000 以上
#====================================================================
# ZeroLab Bus API Python 封装模块
# 提供数据解包、指令封装、端口通信等功能
# 用于与 ZeroLab 追踪器设备进行数据交互
#====================================================================
# from typing import Tuple
import copy
import ZlBusApi as zlapi  # ZeroLab Bus API 底层接口模块
import ctypes
import math

#------------------------------------------------------------------------------------
class CmdOkBlock:
    '''
    指令 -> 成功回复结构
    当设备成功执行命令后返回的确认块
    '''
    def __init__(self, _block:zlapi.cmdOkBlock_t = None,):
        '''
        构造函数
        :param _block: 可选的底层C结构体数据块
        '''
        super().__init__()
        self.block = zlapi.cmdOkBlock_t()
        ctypes.memset(ctypes.addressof(self.block), 0, ctypes.sizeof(self.block))
        if _block != None:
            ctypes.memmove(ctypes.byref(self.block), ctypes.byref(_block), ctypes.sizeof(zlapi.cmdOkBlock_t))

    def printClassName(self):
        '''打印类名'''
        print("CmdOkBlock")

    def getIdBlock(self) -> zlapi.xxxIdBlock_t:
        '''获取数据包标识信息（rfId, dotId, flowId等）'''
        return self.block.pkId

    def getDataBlockId(self) -> ctypes.c_uint32:
        '''获取数据块ID'''
        return self.block.dataBlockId

class CmdErrorBlock:
    '''
    指令 -> 错误回复结构
    当设备执行命令失败时返回的错误块
    '''
    def __init__(self, _block:zlapi.cmdErrBlock_t = None):
        '''
        构造函数
        :param _block: 可选的底层C结构体数据块
        '''
        super().__init__()
        self.block = zlapi.cmdErrBlock_t()
        ctypes.memset(ctypes.addressof(self.block), 0, ctypes.sizeof(self.block))
        if _block != None:
            ctypes.memmove(ctypes.byref(self.block), ctypes.byref(_block), ctypes.sizeof(zlapi.cmdErrBlock_t))

    def printClassName(self):
        '''打印类名'''
        print("CmdErrorBlock")

    def getIdBlock(self) -> zlapi.xxxIdBlock_t:
        '''获取数据包标识信息（rfId, dotId, flowId等）'''
        return self.block.pkId

    def getDataBlockId(self) -> ctypes.c_uint32:
        '''获取数据块ID'''
        return self.block.dataBlockId

    def getErrCode(self) -> ctypes.c_uint8:
        '''获取错误代码'''
        return self.block.errCode

#==============================================================================================
# 上报数据格式块
# 设备上报数据的格式（四元数、欧拉角、加速度、陀螺仪等）
#==============================================================================================
class UploadDataFormatBlock:
    '''
    上报数据格式块
    包含设备上报数据的格式配置信息
    '''
    def __init__(self, _block:zlapi.uploadDataFormatBlock_t = None, pkId: zlapi.xxxIdBlock_t = None) -> None:
        '''
        构造函数
        :param _block: 可选的底层C结构体数据块
        :param pkId: 可选的数据包标识信息
        '''
        super().__init__()
        self.block = zlapi.uploadDataFormatBlock_t()
        ctypes.memset(ctypes.addressof(self.block), 0, ctypes.sizeof(self.block))
        if _block != None:
            ctypes.memmove(ctypes.byref(self.block), ctypes.byref(_block), ctypes.sizeof(zlapi.uploadDataFormatBlock_t))

        self.pkId = zlapi.xxxIdBlock_t()
        ctypes.memset(ctypes.addressof(self.pkId), 0, ctypes.sizeof(self.pkId))
        if pkId != None:
            ctypes.memmove(ctypes.byref(self.pkId), ctypes.byref(pkId), ctypes.sizeof(zlapi.xxxIdBlock_t))

    def printClassName(self):
        '''打印类名'''
        print("UploadDataFormatBlock")

    def getIdBlock(self) -> zlapi.xxxIdBlock_t:
        '''获取数据包标识信息'''
        return self.pkId

    def getUploadDataFormat(self) -> zlapi.uploadDataFormatBlock_t:
        '''获取上报数据格式块内容'''
        return self.block


#==============================================================================================
# 采样频率块
# 设备的采样频率
#==============================================================================================
class SamplingHzBlock:
    '''
    采样频率块
    包含设备的采样频率配置信息（Hz）
    '''
    def __init__(self, _block:zlapi.samplingHzBlock_t = None, pkId: zlapi.xxxIdBlock_t = None) -> None:
        '''
        构造函数
        :param _block: 可选的底层C结构体数据块
        :param pkId: 可选的数据包标识信息
        '''
        super().__init__()
        self.block = zlapi.samplingHzBlock_t()
        ctypes.memset(ctypes.addressof(self.block), 0, ctypes.sizeof(self.block))
        if _block != None:
            ctypes.memmove(ctypes.byref(self.block), ctypes.byref(_block), ctypes.sizeof(zlapi.samplingHzBlock_t))

        self.pkId = zlapi.xxxIdBlock_t()
        ctypes.memset(ctypes.addressof(self.pkId), 0, ctypes.sizeof(self.pkId))
        if pkId != None:
            ctypes.memmove(ctypes.byref(self.pkId), ctypes.byref(pkId), ctypes.sizeof(zlapi.xxxIdBlock_t))

    def printClassName(self):
        '''打印类名'''
        print("SamplingHzBlock")

    def getIdBlock(self) -> zlapi.xxxIdBlock_t:
        '''获取数据包标识信息'''
        return self.pkId

    def getSamplingHz(self) -> zlapi.samplingHzBlock_t:
        '''获取采样频率值'''
        return self.block


#==============================================================================================
# 上报频率块
# 设备上报数据的频率
#==============================================================================================
class UploadHzBlock:
    '''
    上报频率块
    包含设备上报数据的频率配置信息（Hz）
    '''
    def __init__(self, _block:zlapi.uploadHzBlock_t = None, pkId: zlapi.xxxIdBlock_t = None) -> None:
        '''
        构造函数
        :param _block: 可选的底层C结构体数据块
        :param pkId: 可选的数据包标识信息
        '''
        super().__init__()
        self.block = zlapi.uploadHzBlock_t()
        ctypes.memset(ctypes.addressof(self.block), 0, ctypes.sizeof(self.block))
        if _block != None:
            ctypes.memmove(ctypes.byref(self.block), ctypes.byref(_block), ctypes.sizeof(zlapi.uploadHzBlock_t))
        
        self.pkId = zlapi.xxxIdBlock_t()
        ctypes.memset(ctypes.addressof(self.pkId), 0, ctypes.sizeof(self.pkId))
        if pkId != None:
            ctypes.memmove(ctypes.byref(self.pkId), ctypes.byref(pkId), ctypes.sizeof(zlapi.xxxIdBlock_t))

    def printClassName(self):
        '''打印类名'''
        print("UploadHzBlock")

    def getIdBlock(self) -> zlapi.xxxIdBlock_t:
        '''获取数据包标识信息'''
        return self.pkId

    def getUploadHz(self) -> zlapi.uploadHzBlock_t:
        '''获取上报频率值'''
        return self.block


#==============================================================================================
# 滤波器映射块
# 设备的AHRS滤波器配置
#==============================================================================================
class FilterMapBlock:
    '''
    滤波器映射块
    包含AHRS滤波器的配置映射信息
    '''
    def __init__(self, _block:zlapi.filterMapBlock_t = None, pkId: zlapi.xxxIdBlock_t = None) -> None:
        '''
        构造函数
        :param _block: 可选的底层C结构体数据块
        :param pkId: 可选的数据包标识信息
        '''
        super().__init__()
        self.block = zlapi.filterMapBlock_t()
        ctypes.memset(ctypes.addressof(self.block), 0, ctypes.sizeof(self.block))
        if _block != None:
            ctypes.memmove(ctypes.byref(self.block), ctypes.byref(_block), ctypes.sizeof(zlapi.filterMapBlock_t))

        self.pkId = zlapi.xxxIdBlock_t()
        ctypes.memset(ctypes.addressof(self.pkId), 0, ctypes.sizeof(self.pkId))
        if pkId != None:
            ctypes.memmove(ctypes.byref(self.pkId), ctypes.byref(pkId), ctypes.sizeof(zlapi.xxxIdBlock_t))

    def printClassName(self):
        '''打印类名'''
        print("FilterMapBlock")

    def getIdBlock(self) -> zlapi.xxxIdBlock_t:
        '''获取数据包标识信息'''
        return self.pkId

    def getFilterMap(self) -> zlapi.filterMapBlock_t:
        '''获取滤波器映射配置'''
        return self.block


#==============================================================================================
# IC方向块
# 设备的IC安装方向
#==============================================================================================
class IcDirBlock:
    '''
    IC方向块
    包含设备IC的安装方向配置信息
    '''
    def __init__(self, _block:zlapi.icDirBlock_t = None, pkId: zlapi.xxxIdBlock_t = None) -> None:
        '''
        构造函数
        :param _block: 可选的底层C结构体数据块
        :param pkId: 可选的数据包标识信息
        '''
        super().__init__()
        self.block = zlapi.icDirBlock_t()
        ctypes.memset(ctypes.addressof(self.block), 0, ctypes.sizeof(self.block))
        if _block != None:
            ctypes.memmove(ctypes.byref(self.block), ctypes.byref(_block), ctypes.sizeof(zlapi.icDirBlock_t))

        self.pkId = zlapi.xxxIdBlock_t()
        ctypes.memset(ctypes.addressof(self.pkId), 0, ctypes.sizeof(self.pkId))
        if pkId != None:
            ctypes.memmove(ctypes.byref(self.pkId), ctypes.byref(pkId), ctypes.sizeof(zlapi.xxxIdBlock_t))

    def printClassName(self):
        '''打印类名'''
        print("IcDirBlock")

    def getIdBlock(self) -> zlapi.xxxIdBlock_t:
        '''获取数据包标识信息'''
        return self.pkId

    def getIcDir(self) -> zlapi.icDirBlock_t:
        '''获取IC方向配置'''
        return self.block

#==============================================================================================
# ADC 峰峰值Mv
# 设备ADC 峰峰值Mv
#==============================================================================================
class AdcRangeBlock: 
    def __init__(self, _block:zlapi.adcRangeBlock_t = None, pkId: zlapi.xxxIdBlock_t = None) -> None:
        '''
        构造函数
        :param _block: 可选的底层C结构体数据块
        :param pkId: 可选的数据包标识信息
        '''
        super().__init__()
        self.block = zlapi.adcRangeBlock_t()
        ctypes.memset(ctypes.addressof(self.block), 0, ctypes.sizeof(self.block))
        if _block != None:
            ctypes.memmove(ctypes.byref(self.block), ctypes.byref(_block), ctypes.sizeof(zlapi.adcRangeBlock_t))

        self.pkId = zlapi.xxxIdBlock_t()
        ctypes.memset(ctypes.addressof(self.pkId), 0, ctypes.sizeof(self.pkId))
        if pkId != None:
            ctypes.memmove(ctypes.byref(self.pkId), ctypes.byref(pkId), ctypes.sizeof(zlapi.xxxIdBlock_t))

    def printClassName(self):
        '''打印类名'''
        print("AdcRangeBlock")

    def getIdBlock(self) -> zlapi.xxxIdBlock_t:
        '''获取数据包标识信息'''
        return self.pkId

    def getAdcRange(self) -> zlapi.adcRangeBlock_t:
        return self.block


#==============================================================================================
# ADC 顺序序列
# 设备ADC 顺序
#==============================================================================================
class AdcOrderBlock: 
    def __init__(self, _block:zlapi.adcOrderBlock_t = None, pkId: zlapi.xxxIdBlock_t = None) -> None:
        '''
        构造函数
        :param _block: 可选的底层C结构体数据块
        :param pkId: 可选的数据包标识信息
        '''
        super().__init__()
        self.block = zlapi.adcOrderBlock_t()
        ctypes.memset(ctypes.addressof(self.block), 0, ctypes.sizeof(self.block))
        if _block != None:
            ctypes.memmove(ctypes.byref(self.block), ctypes.byref(_block), ctypes.sizeof(zlapi.adcOrderBlock_t))

        self.pkId = zlapi.xxxIdBlock_t()
        ctypes.memset(ctypes.addressof(self.pkId), 0, ctypes.sizeof(self.pkId))
        if pkId != None:
            ctypes.memmove(ctypes.byref(self.pkId), ctypes.byref(pkId), ctypes.sizeof(zlapi.xxxIdBlock_t))

    def printClassName(self):
        '''打印类名'''
        print("AdcRangeBlock")

    def getIdBlock(self) -> zlapi.xxxIdBlock_t:
        '''获取数据包标识信息'''
        return self.pkId

    def getAdcRange(self) -> zlapi.adcOrderBlock_t:
        return self.block


#==============================================================================================
# RF名称块
# 设备的射频名称
#==============================================================================================
class RfNameBlock:
    '''
    RF名称块
    包含设备的射频广播名称信息
    '''
    def __init__(self, _block:zlapi.devieRfNameBlock_t = None, pkId: zlapi.xxxIdBlock_t = None) -> None:
        '''
        构造函数
        :param _block: 可选的底层C结构体数据块
        :param pkId: 可选的数据包标识信息
        '''
        super().__init__()
        self.block = zlapi.devieRfNameBlock_t()
        ctypes.memset(ctypes.addressof(self.block), 0, ctypes.sizeof(self.block))
        if _block != None:
            ctypes.memmove(ctypes.byref(self.block), ctypes.byref(_block), ctypes.sizeof(zlapi.devieRfNameBlock_t))

        self.pkId = zlapi.xxxIdBlock_t()
        ctypes.memset(ctypes.addressof(self.pkId), 0, ctypes.sizeof(self.pkId))
        if pkId != None:
            ctypes.memmove(ctypes.byref(self.pkId), ctypes.byref(pkId), ctypes.sizeof(zlapi.xxxIdBlock_t))

    def printClassName(self):
        '''打印类名'''
        print("RfNameBlock")

    def getIdBlock(self) -> zlapi.xxxIdBlock_t:
        '''获取数据包标识信息'''
        return self.pkId

    def getRfName(self) -> str:
        '''获取RF广播名称'''
        return bytes(self.block.name).decode('utf-8') if self.block.name else ''


#==============================================================================================
# RF功率块
# 设备的射频发射功率
#==============================================================================================
class RfPowerBlock:
    '''
    RF功率块
    包含设备的射频发射功率配置信息（dBm）
    '''
    def __init__(self, _block:zlapi.rfPowerBlock_t = None, pkId: zlapi.xxxIdBlock_t = None) -> None:
        '''
        构造函数
        :param _block: 可选的底层C结构体数据块
        :param pkId: 可选的数据包标识信息
        '''
        super().__init__()
        self.block = zlapi.rfPowerBlock_t()
        ctypes.memset(ctypes.addressof(self.block), 0, ctypes.sizeof(self.block))
        if _block != None:
            ctypes.memmove(ctypes.byref(self.block), ctypes.byref(_block), ctypes.sizeof(zlapi.rfPowerBlock_t))

        self.pkId = zlapi.xxxIdBlock_t()
        ctypes.memset(ctypes.addressof(self.pkId), 0, ctypes.sizeof(self.pkId))
        if pkId != None:
            ctypes.memmove(ctypes.byref(self.pkId), ctypes.byref(pkId), ctypes.sizeof(zlapi.xxxIdBlock_t))

    def printClassName(self):
        '''打印类名'''
        print("RfPowerBlock")

    def getIdBlock(self) -> zlapi.xxxIdBlock_t:
        '''获取数据包标识信息'''
        return self.pkId

    def getRfPower(self) -> zlapi.rfPowerBlock_t:
        '''获取RF功率配置'''
        return self.block



#==============================================================================================
# LED RGB数据块
# 设备的LED颜色
#==============================================================================================
class LedRgbData:
    '''
    LED RGB数据块
    包含设备的LED颜色配置信息（RGB值）
    '''
    def __init__(self, _block:zlapi.ledRgbDataBlock_t = None, pkId: zlapi.xxxIdBlock_t = None) -> None:
        '''
        构造函数
        :param _block: 可选的底层C结构体数据块
        :param pkId: 可选的数据包标识信息
        '''
        super().__init__()
        self.block = zlapi.ledRgbDataBlock_t()
        ctypes.memset(ctypes.addressof(self.block), 0, ctypes.sizeof(self.block))
        if _block != None:
            ctypes.memmove(ctypes.byref(self.block), ctypes.byref(_block), ctypes.sizeof(zlapi.ledRgbDataBlock_t))

        self.pkId = zlapi.xxxIdBlock_t()
        ctypes.memset(ctypes.addressof(self.pkId), 0, ctypes.sizeof(self.pkId))
        if pkId != None:
            ctypes.memmove(ctypes.byref(self.pkId), ctypes.byref(pkId), ctypes.sizeof(zlapi.xxxIdBlock_t))

    def printClassName(self):
        '''打印类名'''
        print("LedRgbData")

    def getIdBlock(self) -> zlapi.xxxIdBlock_t:
        '''获取数据包标识信息'''
        return self.pkId

    def getLedRgbData(self) -> zlapi.ledRgbDataBlock_t:
        '''获取LED RGB数据'''
        return self.block


#==============================================================================================
# 串口波特率块
# 设备的串口通信波特率
#==============================================================================================
class UartBaudRateBlock:
    '''
    串口波特率块
    包含设备的串口通信波特率配置信息（bps）
    '''
    def __init__(self, _block:zlapi.uartBaudRateBlock_t = None, pkId: zlapi.xxxIdBlock_t = None) -> None:
        '''
        构造函数
        :param _block: 可选的底层C结构体数据块
        :param pkId: 可选的数据包标识信息
        '''
        super().__init__()
        self.block = zlapi.uartBaudRateBlock_t()
        ctypes.memset(ctypes.addressof(self.block), 0, ctypes.sizeof(self.block))
        if _block != None:
            ctypes.memmove(ctypes.byref(self.block), ctypes.byref(_block), ctypes.sizeof(zlapi.uartBaudRateBlock_t))

        self.pkId = zlapi.xxxIdBlock_t()
        ctypes.memset(ctypes.addressof(self.pkId), 0, ctypes.sizeof(self.pkId))
        if pkId != None:
            ctypes.memmove(ctypes.byref(self.pkId), ctypes.byref(pkId), ctypes.sizeof(zlapi.xxxIdBlock_t))

    def printClassName(self):
        '''打印类名'''
        print("UartBaudRateBlock")

    def getIdBlock(self) -> zlapi.xxxIdBlock_t:
        '''获取数据包标识信息'''
        return self.pkId

    def getBaudRate(self) -> zlapi.uartBaudRateBlock_t:
        '''获取波特率配置'''
        return self.block


#==============================================================================================
# 数据块大小块
# SPI/IIC通信的数据块大小
#==============================================================================================
class BlockSizeBlock:
    '''
    数据块大小块
    包含SPI/IIC通信的数据块大小配置信息（字节）
    '''
    def __init__(self, _block:zlapi.blockSizeBlock_t = None, pkId: zlapi.xxxIdBlock_t = None) -> None:
        '''
        构造函数
        :param _block: 可选的底层C结构体数据块
        :param pkId: 可选的数据包标识信息
        '''
        super().__init__()
        self.block = zlapi.blockSizeBlock_t()
        ctypes.memset(ctypes.addressof(self.block), 0, ctypes.sizeof(self.block))
        if _block != None:
            ctypes.memmove(ctypes.byref(self.block), ctypes.byref(_block), ctypes.sizeof(zlapi.blockSizeBlock_t))

        self.pkId = zlapi.xxxIdBlock_t()
        ctypes.memset(ctypes.addressof(self.pkId), 0, ctypes.sizeof(self.pkId))
        if pkId != None:
            ctypes.memmove(ctypes.byref(self.pkId), ctypes.byref(pkId), ctypes.sizeof(zlapi.xxxIdBlock_t))

    def printClassName(self):
        '''打印类名'''
        print("BlockSizeBlock")

    def getIdBlock(self) -> zlapi.xxxIdBlock_t:
        '''获取数据包标识信息'''
        return self.pkId

    def getBlockSize(self) -> zlapi.blockSizeBlock_t:
        '''获取数据块大小'''
        return self.block


#==============================================================================================
# 设备MAC地址块
# 包含设备的MAC地址信息
#==============================================================================================
class DeviceMacBlock:
    '''
    设备MAC地址块
    包含设备的MAC地址信息
    '''
    def __init__(self, _block:zlapi.deviceMacBlock_t = None, pkId: zlapi.xxxIdBlock_t = None) -> None:
        '''
        构造函数
        :param _block: 可选的底层C结构体数据块
        :param pkId: 可选的数据包标识信息
        '''
        super().__init__()
        self.block = zlapi.deviceMacBlock_t()
        ctypes.memset(ctypes.addressof(self.block), 0, ctypes.sizeof(self.block))
        if _block != None:
            ctypes.memmove(ctypes.byref(self.block), ctypes.byref(_block), ctypes.sizeof(zlapi.deviceMacBlock_t))

        self.pkId = zlapi.xxxIdBlock_t()
        ctypes.memset(ctypes.addressof(self.pkId), 0, ctypes.sizeof(self.pkId))
        if pkId != None:
            ctypes.memmove(ctypes.byref(self.pkId), ctypes.byref(pkId), ctypes.sizeof(zlapi.xxxIdBlock_t))

    def printClassName(self):
        '''打印类名'''
        print("DeviceMacBlock")

    def getIdBlock(self) -> zlapi.xxxIdBlock_t:
        '''获取数据包标识信息'''
        return self.pkId

    def getMacStr(self) -> str:
        '''获取MAC地址字符串'''
        return bytes(self.block.macStr).decode('utf-8') if self.block.macStr else ''


#==============================================================================================
# 设备序列号块
# 包含设备的完整序列号信息
#==============================================================================================
class DeviceSnFullStrBlock:
    '''
    设备序列号块
    包含设备的完整序列号信息
    '''
    def __init__(self, _block:zlapi.deviceSnFullStrBlock_t = None, pkId: zlapi.xxxIdBlock_t = None) -> None:
        '''
        构造函数
        :param _block: 可选的底层C结构体数据块
        :param pkId: 可选的数据包标识信息
        '''
        super().__init__()
        self.block = zlapi.deviceSnFullStrBlock_t()
        ctypes.memset(ctypes.addressof(self.block), 0, ctypes.sizeof(self.block))
        if _block != None:
            ctypes.memmove(ctypes.byref(self.block), ctypes.byref(_block), ctypes.sizeof(zlapi.deviceSnFullStrBlock_t))

        self.pkId = zlapi.xxxIdBlock_t()
        ctypes.memset(ctypes.addressof(self.pkId), 0, ctypes.sizeof(self.pkId))
        if pkId != None:
            ctypes.memmove(ctypes.byref(self.pkId), ctypes.byref(pkId), ctypes.sizeof(zlapi.xxxIdBlock_t))

    def printClassName(self):
        '''打印类名'''
        print("DeviceSnFullStrBlock")

    def getIdBlock(self) -> zlapi.xxxIdBlock_t:
        '''获取数据包标识信息'''
        return self.pkId

    def getSnFullStr(self) -> str:
        '''获取完整序列号字符串'''
        return bytes(self.block.snFullStr).decode('utf-8') if self.block.snFullStr else ''


#==============================================================================================
# 设备板卡版本块
# 包含设备的板卡硬件版本信息
#==============================================================================================
class DeviceBoardVersionBlock:
    '''
    设备板卡版本块
    包含设备的板卡硬件版本信息
    '''
    def __init__(self, _block:zlapi.deviceBoardVersionBlock_t = None, pkId: zlapi.xxxIdBlock_t = None) -> None:
        '''
        构造函数
        :param _block: 可选的底层C结构体数据块
        :param pkId: 可选的数据包标识信息
        '''
        super().__init__()
        self.block = zlapi.deviceBoardVersionBlock_t()
        ctypes.memset(ctypes.addressof(self.block), 0, ctypes.sizeof(self.block))
        if _block != None:
            ctypes.memmove(ctypes.byref(self.block), ctypes.byref(_block), ctypes.sizeof(zlapi.deviceBoardVersionBlock_t))

        self.pkId = zlapi.xxxIdBlock_t()
        ctypes.memset(ctypes.addressof(self.pkId), 0, ctypes.sizeof(self.pkId))
        if pkId != None:
            ctypes.memmove(ctypes.byref(self.pkId), ctypes.byref(pkId), ctypes.sizeof(zlapi.xxxIdBlock_t))

    def printClassName(self):
        '''打印类名'''
        print("DeviceBoardVersionBlock")

    def getIdBlock(self) -> zlapi.xxxIdBlock_t:
        '''获取数据包标识信息'''
        return self.pkId

    def getBoardVersion(self) -> str:
        '''获取板卡版本字符串'''
        return bytes(self.block.boardVersion).decode('utf-8') if self.block.boardVersion else ''


#==============================================================================================
# 设备固件版本块
# 包含设备的固件版本信息
#==============================================================================================
class DeviceFirmwareVersionBlock:
    '''
    设备固件版本块
    包含设备的固件版本信息
    '''
    def __init__(self, _block:zlapi.deviceFirmwareVersionBlock_t = None, pkId: zlapi.xxxIdBlock_t = None) -> None:
        '''
        构造函数
        :param _block: 可选的底层C结构体数据块
        :param pkId: 可选的数据包标识信息
        '''
        super().__init__()
        self.block = zlapi.deviceFirmwareVersionBlock_t()
        ctypes.memset(ctypes.addressof(self.block), 0, ctypes.sizeof(self.block))
        if _block != None:
            ctypes.memmove(ctypes.byref(self.block), ctypes.byref(_block), ctypes.sizeof(zlapi.deviceFirmwareVersionBlock_t))

        self.pkId = zlapi.xxxIdBlock_t()
        ctypes.memset(ctypes.addressof(self.pkId), 0, ctypes.sizeof(self.pkId))
        if pkId != None:
            ctypes.memmove(ctypes.byref(self.pkId), ctypes.byref(pkId), ctypes.sizeof(zlapi.xxxIdBlock_t))

    def printClassName(self):
        '''打印类名'''
        print("DeviceFirmwareVersionBlock")

    def getIdBlock(self) -> zlapi.xxxIdBlock_t:
        '''获取数据包标识信息'''
        return self.pkId
    
    def getFirmwareVersion(self) -> str:
        '''获取固件版本字符串'''
        return bytes(self.block.firmwareVersion).decode('utf-8') if self.block.firmwareVersion else ''


#==============================================================================================
# Dot ID块
# 包含设备的Dot ID信息
#==============================================================================================
class DotIdBlock:
    '''
    Dot ID块
    包含设备的Dot ID标识信息
    '''
    def __init__(self, _block:zlapi.dotIdBlock_t = None, pkId: zlapi.xxxIdBlock_t = None) -> None:
        '''
        构造函数
        :param _block: 可选的底层C结构体数据块
        :param pkId: 可选的数据包标识信息
        '''
        super().__init__()
        self.block = zlapi.dotIdBlock_t()
        ctypes.memset(ctypes.addressof(self.block), 0, ctypes.sizeof(self.block))
        if _block != None:
            ctypes.memmove(ctypes.byref(self.block), ctypes.byref(_block), ctypes.sizeof(zlapi.dotIdBlock_t))

        self.pkId = zlapi.xxxIdBlock_t()
        ctypes.memset(ctypes.addressof(self.pkId), 0, ctypes.sizeof(self.pkId))
        if pkId != None:
            ctypes.memmove(ctypes.byref(self.pkId), ctypes.byref(pkId), ctypes.sizeof(zlapi.xxxIdBlock_t))

    def printClassName(self):
        '''打印类名'''
        print("DotIdBlock")

    def getIdBlock(self) -> zlapi.xxxIdBlock_t:
        '''获取数据包标识信息'''
        return self.pkId

    def getDotId(self) -> zlapi.dotIdBlock_t:
        '''获取Dot ID'''
        return self.block


#==============================================================================================
# BLE连接间隔块
# 包含设备的蓝牙连接间隔配置
#==============================================================================================
class BleConnIntervalBlock:
    '''
    BLE连接间隔块
    包含设备的蓝牙BLE连接间隔配置信息
    '''
    def __init__(self, _block:zlapi.bleConnIntervalBlock_t = None, pkId: zlapi.xxxIdBlock_t = None) -> None:
        '''
        构造函数
        :param _block: 可选的底层C结构体数据块
        :param pkId: 可选的数据包标识信息
        '''
        super().__init__()
        self.block = zlapi.bleConnIntervalBlock_t()
        ctypes.memset(ctypes.addressof(self.block), 0, ctypes.sizeof(self.block))
        if _block != None:
            ctypes.memmove(ctypes.byref(self.block), ctypes.byref(_block), ctypes.sizeof(zlapi.bleConnIntervalBlock_t))

        self.pkId = zlapi.xxxIdBlock_t()
        ctypes.memset(ctypes.addressof(self.pkId), 0, ctypes.sizeof(self.pkId))
        if pkId != None:
            ctypes.memmove(ctypes.byref(self.pkId), ctypes.byref(pkId), ctypes.sizeof(zlapi.xxxIdBlock_t))

    def printClassName(self):
        '''打印类名'''
        print("BleConnIntervalBlock")

    def getIdBlock(self) -> zlapi.xxxIdBlock_t:
        '''获取数据包标识信息'''
        return self.pkId

    def getConnInterval(self) -> zlapi.bleConnIntervalBlock_t:
        '''获取连接间隔'''
        return self.block


#==============================================================================================
# 加速度计量程块
# 包含设备的加速度计量程配置
#==============================================================================================
class AccRangeBlock:
    '''
    加速度计量程块
    包含设备的加速度计测量范围配置（g）
    '''
    def __init__(self, _block:zlapi.accRangeBlock_t = None, pkId: zlapi.xxxIdBlock_t = None) -> None:
        '''
        构造函数
        :param _block: 可选的底层C结构体数据块
        :param pkId: 可选的数据包标识信息
        '''
        super().__init__()
        self.block = zlapi.accRangeBlock_t()
        ctypes.memset(ctypes.addressof(self.block), 0, ctypes.sizeof(self.block))
        if _block != None:
            ctypes.memmove(ctypes.byref(self.block), ctypes.byref(_block), ctypes.sizeof(zlapi.accRangeBlock_t))

        self.pkId = zlapi.xxxIdBlock_t()
        ctypes.memset(ctypes.addressof(self.pkId), 0, ctypes.sizeof(self.pkId))
        if pkId != None:
            ctypes.memmove(ctypes.byref(self.pkId), ctypes.byref(pkId), ctypes.sizeof(zlapi.xxxIdBlock_t))

    def printClassName(self):
        '''打印类名'''
        print("AccRangeBlock")

    def getIdBlock(self) -> zlapi.xxxIdBlock_t:
        '''获取数据包标识信息'''
        return self.pkId

    def getAccRange(self) -> zlapi.accRangeBlock_t:
        '''获取加速度计量程'''
        return self.block


#==============================================================================================
# 陀螺仪量程块
# 包含设备的陀螺仪量程配置
#==============================================================================================
class GroRangeBlock:
    '''
    陀螺仪量程块
    包含设备的陀螺仪测量范围配置（°/s）
    '''
    def __init__(self, _block:zlapi.gyroRangeBlock_t = None, pkId: zlapi.xxxIdBlock_t = None) -> None:
        '''
        构造函数
        :param _block: 可选的底层C结构体数据块
        :param pkId: 可选的数据包标识信息
        '''
        super().__init__()
        self.block = zlapi.gyroRangeBlock_t()
        ctypes.memset(ctypes.addressof(self.block), 0, ctypes.sizeof(self.block))
        if _block != None:
            ctypes.memmove(ctypes.byref(self.block), ctypes.byref(_block), ctypes.sizeof(zlapi.gyroRangeBlock_t))

        self.pkId = zlapi.xxxIdBlock_t()
        ctypes.memset(ctypes.addressof(self.pkId), 0, ctypes.sizeof(self.pkId))
        if pkId != None:
            ctypes.memmove(ctypes.byref(self.pkId), ctypes.byref(pkId), ctypes.sizeof(zlapi.xxxIdBlock_t))

    def printClassName(self):
        '''打印类名'''
        print("GroRangeBlock")

    def getIdBlock(self) -> zlapi.xxxIdBlock_t:
        '''获取数据包标识信息'''
        return self.pkId

    def getGyrRange(self) -> zlapi.gyroRangeBlock_t:
        '''获取陀螺仪量程'''
        return self.block


#==============================================================================================
# 磁力计椭球校准参数块
# 包含设备的磁力计椭球校准参数
#==============================================================================================
class MagEllipsoidCalParamBlock:
    '''
    磁力计椭球校准参数块
    包含设备的磁力计椭球校准参数信息
    '''
    def __init__(self, _block:zlapi.magEllipsoidCalParamBlock_t = None, pkId: zlapi.xxxIdBlock_t = None) -> None:
        '''
        构造函数
        :param _block: 可选的底层C结构体数据块
        :param pkId: 可选的数据包标识信息
        '''
        super().__init__()
        self.block = zlapi.magEllipsoidCalParamBlock_t()
        ctypes.memset(ctypes.addressof(self.block), 0, ctypes.sizeof(self.block))
        if _block != None:
            ctypes.memmove(ctypes.byref(self.block), ctypes.byref(_block), ctypes.sizeof(zlapi.magEllipsoidCalParamBlock_t))

        self.pkId = zlapi.xxxIdBlock_t()
        ctypes.memset(ctypes.addressof(self.pkId), 0, ctypes.sizeof(self.pkId))
        if pkId != None:
            ctypes.memmove(ctypes.byref(self.pkId), ctypes.byref(pkId), ctypes.sizeof(zlapi.xxxIdBlock_t))

    def printClassName(self):
        '''打印类名'''
        print("MagEllipsoidCalParamBlock")

    def getIdBlock(self) -> zlapi.xxxIdBlock_t:
        '''获取数据包标识信息'''
        return self.pkId

    def getMagEllipsoidCalParam(self) -> zlapi.magEllipsoidCalParamBlock_t:
        '''获取磁力计校准参数'''
        return self.block


#==============================================================================================
# 流水号格式块
# 包含数据流水号的格式配置
#==============================================================================================
class FlowIdFormatBlock:
    '''
    流水号格式块
    包含数据流水号的格式配置信息
    '''
    def __init__(self, _block:zlapi.flowIdFormatBlock_t = None, pkId: zlapi.xxxIdBlock_t = None) -> None:
        '''
        构造函数
        :param _block: 可选的底层C结构体数据块
        :param pkId: 可选的数据包标识信息
        '''
        super().__init__()
        self.block = zlapi.flowIdFormatBlock_t()
        ctypes.memset(ctypes.addressof(self.block), 0, ctypes.sizeof(self.block))
        if _block != None:
            ctypes.memmove(ctypes.byref(self.block), ctypes.byref(_block), ctypes.sizeof(zlapi.flowIdFormatBlock_t))

        self.pkId = zlapi.xxxIdBlock_t()
        ctypes.memset(ctypes.addressof(self.pkId), 0, ctypes.sizeof(self.pkId))
        if pkId != None:
            ctypes.memmove(ctypes.byref(self.pkId), ctypes.byref(pkId), ctypes.sizeof(zlapi.xxxIdBlock_t))

    def printClassName(self):
        '''打印类名'''
        print("FlowIdFormatBlock")

    def getIdBlock(self) -> zlapi.xxxIdBlock_t:
        '''获取数据包标识信息'''
        return self.pkId
    
    def getFlowIdFormat(self) -> zlapi.flowIdFormatBlock_t:
        return self.block


#==============================================================================================
# AHRS偏移块
# 包含设备的AHRS姿态偏移校准参数
#==============================================================================================
class AhhrsOffsetBlock:
    '''
    AHRS偏移块
    包含设备的AHRS姿态偏移校准参数
    '''
    def __init__(self, _block:zlapi.ahrsOffsetBlock_t = None, pkId: zlapi.xxxIdBlock_t = None) -> None:
        '''
        构造函数
        :param _block: 可选的底层C结构体数据块
        :param pkId: 可选的数据包标识信息
        '''
        super().__init__()
        self.block = zlapi.ahrsOffsetBlock_t()
        ctypes.memset(ctypes.addressof(self.block), 0, ctypes.sizeof(self.block))
        if _block != None:
            ctypes.memmove(ctypes.byref(self.block), ctypes.byref(_block), ctypes.sizeof(zlapi.ahrsOffsetBlock_t))

        self.pkId = zlapi.xxxIdBlock_t()
        ctypes.memset(ctypes.addressof(self.pkId), 0, ctypes.sizeof(self.pkId))
        if pkId != None:
            ctypes.memmove(ctypes.byref(self.pkId), ctypes.byref(pkId), ctypes.sizeof(zlapi.xxxIdBlock_t))

    def printClassName(self):
        '''打印类名'''
        print("AhhrsOffsetBlock")

    def getIdBlock(self) -> zlapi.xxxIdBlock_t:
        '''获取数据包标识信息'''
        return self.pkId

    def getAhhrsOffset(self) -> zlapi.ahrsOffsetBlock_t:
        '''获取AHRS偏移参数'''
        return self.block


#==============================================================================================
# 数据输出口块
# 包含数据输出的配置信息
#==============================================================================================
class DataPortBlock:
    '''
    数据输出口块
    包含数据输出口的配置信息
    '''
    def __init__(self, _block:zlapi.dataPortBlock_t = None, pkId: zlapi.xxxIdBlock_t = None) -> None:
        '''
        构造函数
        :param _block: 可选的底层C结构体数据块
        :param pkId: 可选的数据包标识信息
        '''
        super().__init__()
        self.block = zlapi.dataPortBlock_t()
        ctypes.memset(ctypes.addressof(self.block), 0, ctypes.sizeof(self.block))
        if _block != None:
            ctypes.memmove(ctypes.byref(self.block), ctypes.byref(_block), ctypes.sizeof(zlapi.dataPortBlock_t))

        self.pkId = zlapi.xxxIdBlock_t()
        ctypes.memset(ctypes.addressof(self.pkId), 0, ctypes.sizeof(self.pkId))
        if pkId != None:
            ctypes.memmove(ctypes.byref(self.pkId), ctypes.byref(pkId), ctypes.sizeof(zlapi.xxxIdBlock_t))

    def printClassName(self):
        '''打印类名'''
        print("DataPortBlock")

    def getIdBlock(self) -> zlapi.xxxIdBlock_t:
        '''获取数据包标识信息'''
        return self.pkId

    def getDataPort(self) -> zlapi.dataPortBlock_t:
        '''获取数据端口配置'''
        return self.block


#==============================================================================================
# 数据输出口映射块
# 包含数据输出口的映射配置
#==============================================================================================
class DataPortMapBlock:
    '''
    数据输出口映射块
    包含数据输出口的映射配置信息
    '''
    def __init__(self, _block:zlapi.dataPortMapBlock_t = None, pkId: zlapi.xxxIdBlock_t = None) -> None:
        '''
        构造函数
        :param _block: 可选的底层C结构体数据块
        :param pkId: 可选的数据包标识信息
        '''
        super().__init__()
        self.block = zlapi.dataPortMapBlock_t()
        ctypes.memset(ctypes.addressof(self.block), 0, ctypes.sizeof(self.block))
        if _block != None:
            ctypes.memmove(ctypes.byref(self.block), ctypes.byref(_block), ctypes.sizeof(zlapi.dataPortMapBlock_t))

        self.pkId = zlapi.xxxIdBlock_t()
        ctypes.memset(ctypes.addressof(self.pkId), 0, ctypes.sizeof(self.pkId))
        if pkId != None:
            ctypes.memmove(ctypes.byref(self.pkId), ctypes.byref(pkId), ctypes.sizeof(zlapi.xxxIdBlock_t))

    def printClassName(self):
        '''打印类名'''
        print("DataPortMapBlock")

    def getIdBlock(self) -> zlapi.xxxIdBlock_t:
        '''获取数据包标识信息'''
        return self.pkId

    def getDataPortMap(self) -> zlapi.dataPortMapBlock_t:
        '''获取数据端口映射'''
        return self.block


#==============================================================================================
# 设备状态块
# 包含设备的状态信息
#==============================================================================================
class DeviceStateBlock:
    '''
    设备状态块
    包含设备的状态信息
    '''
    def __init__(self, _block:zlapi.deviceStateBlock_t = None, pkId: zlapi.xxxIdBlock_t = None) -> None:
        '''
        构造函数
        :param _block: 可选的底层C结构体数据块
        :param pkId: 可选的数据包标识信息
        '''
        super().__init__()
        self.block = zlapi.deviceStateBlock_t()
        ctypes.memset(ctypes.addressof(self.block), 0, ctypes.sizeof(self.block))
        if _block != None:
            ctypes.memmove(ctypes.byref(self.block), ctypes.byref(_block), ctypes.sizeof(zlapi.deviceStateBlock_t))

        self.pkId = zlapi.xxxIdBlock_t()
        ctypes.memset(ctypes.addressof(self.pkId), 0, ctypes.sizeof(self.pkId))
        if pkId != None:
            ctypes.memmove(ctypes.byref(self.pkId), ctypes.byref(pkId), ctypes.sizeof(zlapi.xxxIdBlock_t))

    def printClassName(self):
        '''打印类名'''
        print("DeviceStateBlock")

    def getIdBlock(self) -> zlapi.xxxIdBlock_t:
        '''获取数据包标识信息'''
        return self.pkId

    def getDeviceState(self) -> zlapi.deviceStateBlock_t:
        '''获取设备状态'''
        return self.block


#==============================================================================================
# ADC滤波器参数块
# 包含ADC滤波器的参数配置
#==============================================================================================
class AdcFilterParamBlock:
    '''
    ADC滤波器参数块
    包含ADC滤波器的参数配置信息
    '''
    def __init__(self, _block:zlapi.adcFilterParam_t = None, pkId: zlapi.xxxIdBlock_t = None) -> None:
        '''
        构造函数
        :param _block: 可选的底层C结构体数据块
        :param pkId: 可选的数据包标识信息
        '''
        super().__init__()
        self.block = zlapi.adcFilterParam_t()
        ctypes.memset(ctypes.addressof(self.block), 0, ctypes.sizeof(self.block))
        if _block != None:
            ctypes.memmove(ctypes.byref(self.block), ctypes.byref(_block), ctypes.sizeof(zlapi.adcFilterParam_t))

        self.pkId = zlapi.xxxIdBlock_t()
        ctypes.memset(ctypes.addressof(self.pkId), 0, ctypes.sizeof(self.pkId))
        if pkId != None:
            ctypes.memmove(ctypes.byref(self.pkId), ctypes.byref(pkId), ctypes.sizeof(zlapi.xxxIdBlock_t))

    def printClassName(self):
        '''打印类名'''
        print("AdcFilterParamBlock")

    def getIdBlock(self) -> zlapi.xxxIdBlock_t:
        '''获取数据包标识信息'''
        return self.pkId

    def getAdcFilterParam(self) -> zlapi.adcFilterParam_t:
        '''获取ADC滤波器参数'''
        return self.block


#==============================================================================================
# 手指映射块
# 包含手指映射配置信息
#==============================================================================================
class FingerMapBlock:
    '''
    手指映射块
    包含手指映射配置信息
    '''
    def __init__(self, _block:zlapi.fingerMapBlock_t = None, pkId: zlapi.xxxIdBlock_t = None) -> None:
        '''
        构造函数
        :param _block: 可选的底层C结构体数据块
        :param pkId: 可选的数据包标识信息
        '''
        super().__init__()
        self.block = zlapi.fingerMapBlock_t()
        ctypes.memset(ctypes.addressof(self.block), 0, ctypes.sizeof(self.block))
        if _block != None:
            ctypes.memmove(ctypes.byref(self.block), ctypes.byref(_block), ctypes.sizeof(zlapi.fingerMapBlock_t))

        self.pkId = zlapi.xxxIdBlock_t()
        ctypes.memset(ctypes.addressof(self.pkId), 0, ctypes.sizeof(self.pkId))
        if pkId != None:
            ctypes.memmove(ctypes.byref(self.pkId), ctypes.byref(pkId), ctypes.sizeof(zlapi.xxxIdBlock_t))

    def printClassName(self):
        '''打印类名'''
        print("FingerMapBlock")

    def getIdBlock(self) -> zlapi.xxxIdBlock_t:
        '''获取数据包标识信息'''
        return self.pkId

    def getFingerMap(self) -> zlapi.fingerMapBlock_t:
        '''获取手指映射'''
        return self.block


#==============================================================================================
# Dongle序列号块
# 包含Dongle设备的完整序列号
#==============================================================================================
class DongleSnFullStrBlock:
    '''
    Dongle序列号块
    包含Dongle设备的完整序列号信息
    '''
    def __init__(self, _block:zlapi.dongleSnFullStrBlock_t = None, pkId: zlapi.xxxIdBlock_t = None) -> None:
        '''
        构造函数
        :param _block: 可选的底层C结构体数据块
        :param pkId: 可选的数据包标识信息
        '''
        super().__init__()
        self.block = zlapi.dongleSnFullStrBlock_t()
        ctypes.memset(ctypes.addressof(self.block), 0, ctypes.sizeof(self.block))
        if _block != None:
            ctypes.memmove(ctypes.byref(self.block), ctypes.byref(_block), ctypes.sizeof(zlapi.dongleSnFullStrBlock_t))

        self.pkId = zlapi.xxxIdBlock_t()
        ctypes.memset(ctypes.addressof(self.pkId), 0, ctypes.sizeof(self.pkId))
        if pkId != None:
            ctypes.memmove(ctypes.byref(self.pkId), ctypes.byref(pkId), ctypes.sizeof(zlapi.xxxIdBlock_t))

    def printClassName(self):
        '''打印类名'''
        print("DongleSnFullStrBlock")

    def getIdBlock(self) -> zlapi.xxxIdBlock_t:
        '''获取数据包标识信息'''
        return self.pkId

    def getSnFullStr(self) -> str:
        '''获取Dongle序列号字符串'''
        return bytes(self.block.snFullStr).decode('utf-8') if self.block.snFullStr else ''


#==============================================================================================
# 设备列表块
# 包含已连接设备的列表信息
#==============================================================================================
class DeviceBlockList:
    '''
    设备列表块
    包含已连接设备的列表信息
    '''
    def __init__(self, _block:zlapi.deviceBlockList_t = None, pkId: zlapi.xxxIdBlock_t = None) -> None:
        '''
        构造函数
        :param _block: 可选的底层C结构体数据块
        :param pkId: 可选的数据包标识信息
        '''
        super().__init__()
        self.block = zlapi.deviceBlockList_t()
        ctypes.memset(ctypes.addressof(self.block), 0, ctypes.sizeof(self.block))
        if _block != None:
            ctypes.memmove(ctypes.byref(self.block), ctypes.byref(_block), ctypes.sizeof(zlapi.deviceBlockList_t))

        self.pkId = zlapi.xxxIdBlock_t()
        ctypes.memset(ctypes.addressof(self.pkId), 0, ctypes.sizeof(self.pkId))
        if pkId != None:
            ctypes.memmove(ctypes.byref(self.pkId), ctypes.byref(pkId), ctypes.sizeof(zlapi.xxxIdBlock_t))

    def printClassName(self):
        '''打印类名'''
        print("DeviceBlockList")

    def getIdBlock(self) -> zlapi.xxxIdBlock_t:
        '''获取数据包标识信息'''
        return self.pkId

    def getSnFullStr(self) -> zlapi.deviceBlockList_t:
        '''获取设备列表'''
        return self.block


#==============================================================================================
# 设备连接数量块
# 包含已连接设备的数量信息
#==============================================================================================
class DeviceConnNumsBlock:
    '''
    设备连接数量块
    包含已连接设备的数量信息
    '''
    def __init__(self, _block:zlapi.deviceConnNumsBlock_t = None, pkId: zlapi.xxxIdBlock_t = None) -> None:
        '''
        构造函数
        :param _block: 可选的底层C结构体数据块
        :param pkId: 可选的数据包标识信息
        '''
        super().__init__()
        self.block = zlapi.deviceConnNumsBlock_t()
        ctypes.memset(ctypes.addressof(self.block), 0, ctypes.sizeof(self.block))
        if _block != None:
            ctypes.memmove(ctypes.byref(self.block), ctypes.byref(_block), ctypes.sizeof(zlapi.deviceConnNumsBlock_t))

        self.pkId = zlapi.xxxIdBlock_t()
        ctypes.memset(ctypes.addressof(self.pkId), 0, ctypes.sizeof(self.pkId))
        if pkId != None:
            ctypes.memmove(ctypes.byref(self.pkId), ctypes.byref(pkId), ctypes.sizeof(zlapi.xxxIdBlock_t))

    def printClassName(self):
        '''打印类名'''
        print("DeviceConnNumsBlock")

    def getIdBlock(self) -> zlapi.xxxIdBlock_t:
        '''获取数据包标识信息'''
        return self.pkId

    def getSnFullStr(self) -> zlapi.deviceConnNumsBlock_t:
        '''获取设备连接数量'''
        return self.block


#==============================================================================================
# 识别方式块
# 包含设备的识别方式配置
#==============================================================================================
class IdentifyWayBlock:
    '''
    识别方式块
    包含设备的识别方式配置信息
    '''
    def __init__(self, _block:zlapi.identifyWayBlock_t = None, pkId: zlapi.xxxIdBlock_t = None) -> None:
        '''
        构造函数
        :param _block: 可选的底层C结构体数据块
        :param pkId: 可选的数据包标识信息
        '''
        super().__init__()
        self.block = zlapi.identifyWayBlock_t()
        ctypes.memset(ctypes.addressof(self.block), 0, ctypes.sizeof(self.block))
        if _block != None:
            ctypes.memmove(ctypes.byref(self.block), ctypes.byref(_block), ctypes.sizeof(zlapi.identifyWayBlock_t))

        self.pkId = zlapi.xxxIdBlock_t()
        ctypes.memset(ctypes.addressof(self.pkId), 0, ctypes.sizeof(self.pkId))
        if pkId != None:
            ctypes.memmove(ctypes.byref(self.pkId), ctypes.byref(pkId), ctypes.sizeof(zlapi.xxxIdBlock_t))

    def printClassName(self):
        '''打印类名'''
        print("IdentifyWayBlock")

    def getIdBlock(self) -> zlapi.xxxIdBlock_t:
        '''获取数据包标识信息'''
        return self.pkId

    def getSnFullStr(self) -> zlapi.identifyWayBlock_t:
        '''获取识别方式'''
        return self.block



#==============================================================================================
# MEMS数据块
# 包含IMU传感器的所有数据：四元数、欧拉角、加速度、陀螺仪、磁力计、线性加速度等
#==============================================================================================
class MemsDataBlock:
    '''
    MEMS数据块
    包含IMU惯性测量单元的完整数据：
    - 时间戳
    - 四元数（姿态）
    - 欧拉角（Roll/Pitch/Yaw）
    - 加速度计数据
    - 陀螺仪数据
    - 磁力计数据
    - 线性加速度
    - 温度
    '''
    def __init__(self, _block:zlapi.memsDataBlock_t = None, pkId: zlapi.xxxIdBlock_t = None) -> None:
        '''
        构造函数
        :param _block: 可选的底层C结构体数据块
        :param pkId: 可选的数据包标识信息
        '''
        super().__init__()
        self.block = zlapi.memsDataBlock_t()
        ctypes.memset(ctypes.addressof(self.block), 0, ctypes.sizeof(self.block))
        if _block != None:
            ctypes.memmove(ctypes.byref(self.block), ctypes.byref(_block), ctypes.sizeof(zlapi.memsDataBlock_t))

        self.pkId = zlapi.xxxIdBlock_t()
        ctypes.memset(ctypes.addressof(self.pkId), 0, ctypes.sizeof(self.pkId))
        if pkId != None:
            ctypes.memmove(ctypes.byref(self.pkId), ctypes.byref(pkId), ctypes.sizeof(zlapi.xxxIdBlock_t))

    def printClassName(self):
        '''打印类名'''
        print("MemsDataBlock")

    def getIdBlock(self) -> zlapi.xxxIdBlock_t:
        '''获取数据包标识信息（rfId, dotId, flowId等）'''
        return self.pkId

    def getEffectiveDataFormat(self) -> int:
        '''
        获取当前有效数据格式映射位
        :return: 位掩码，bit位1表示对应数据有效，0表示无效
        '''
        return self.block.effectiveDataFormat

    def getTimeStamp(self) -> tuple[bool, float]:
        '''
        获取时间戳
        :return: (是否有效, 时间戳值[毫秒])
        '''
        state = False
        if self.block.effectiveDataFormat & (zlapi.e_Upload_DataFormat.NEW_UPLOAD_DATA_TIME | zlapi.e_Upload_DataFormat.NEW_UPLOAD_DATA_HL_TIME):
            state = True
        return (state, 0.0 if math.isnan(self.block.timeStamp) else self.block.timeStamp)

    def getTemperature(self) -> tuple[bool, float]:
        '''
        获取温度
        :return: (是否有效, 温度值[摄氏度])
        '''
        state = False
        if self.block.effectiveDataFormat & zlapi.e_Upload_DataFormat.NEW_UPLOAD_DATA_TEMP:
            state = True
        return (state, self.block.temperature)

    def getAhrsQuaternion(self) -> tuple[bool, zlapi.AhrsQuaternion]:
        '''
        获取四元数姿态数据
        :return: (是否有效, 四元数[w, x, y, z])
        '''
        state = False
        if self.block.effectiveDataFormat & zlapi.e_Upload_DataFormat.NEW_UPLOAD_DATA_QUATERNION:
            state = True
        return (state, self.block.quat)

    def getAhrsEuler(self) -> tuple[bool, zlapi.AhrsEuler]:
        '''
        获取欧拉角数据
        :return: (是否有效, 欧拉角[roll, pitch, yaw])
        '''
        state = False
        if self.block.effectiveDataFormat & zlapi.e_Upload_DataFormat.NEW_UPLOAD_DATA_RPY:
            state = True
        return (state, self.block.euler)

    def getAcc(self) -> tuple[bool, zlapi.Axis3_Float]:
        state = False
        if self.block.effectiveDataFormat & zlapi.e_Upload_DataFormat.NEW_UPLOAD_DATA_ACC:
            state = True
        return (state, self.block.acc)

    def getGyro(self) -> tuple[bool, zlapi.Axis3_Float]:
        '''
        获取陀螺仪数据
        :return: (是否有效, 陀螺仪[x, y, z] 单位:°/s)
        '''
        state = False
        if self.block.effectiveDataFormat & zlapi.e_Upload_DataFormat.NEW_UPLOAD_DATA_GYRO:
            state = True
        return (state, self.block.gyro)

    def getMag(self) -> tuple[bool, zlapi.Axis3_Float]:
        '''
        获取磁力计数据
        :return: (是否有效, 磁力计[x, y, z] 单位:uT)
        '''
        state = False
        if self.block.effectiveDataFormat & zlapi.e_Upload_DataFormat.NEW_UPLOAD_DATA_MAG:
            state = True
        return (state, self.block.mag)

    def getLinAcc(self) -> tuple[bool, zlapi.Axis3_Float]:
        '''
        获取线性加速度数据
        :return: (是否有效, 线性加速度[x, y, z] 单位:g/s²)
        '''
        state = False
        if self.block.effectiveDataFormat & zlapi.e_Upload_DataFormat.NEW_UPLOAD_DATA_LIN_ACC:
            state = True
        return (state, self.block.lineAcc)

#==============================================================================================
# 设备状态块
# 包含设备的状态信息
#==============================================================================================

class UpLoadDeviceStateBlock:
    """
    设备状态块
    模块(IC)主动上报的设备状态信息
    """
    def __init__(self, _block:zlapi.deviceStateBlock_t = None, pkId: zlapi.xxxIdBlock_t = None) -> None:
        '''
        构造函数
        :param _block: 可选的底层C结构体数据块
        :param pkId: 可选的数据包标识信息
        '''
        super().__init__()
        self.block = zlapi.deviceStateBlock_t()
        ctypes.memset(ctypes.addressof(self.block), 0, ctypes.sizeof(self.block))
        if _block != None:
            ctypes.memmove(ctypes.byref(self.block), ctypes.byref(_block), ctypes.sizeof(zlapi.deviceStateBlock_t))

        self.pkId = zlapi.xxxIdBlock_t()
        ctypes.memset(ctypes.addressof(self.pkId), 0, ctypes.sizeof(self.pkId))
        if pkId != None:
            ctypes.memmove(ctypes.byref(self.pkId), ctypes.byref(pkId), ctypes.sizeof(zlapi.xxxIdBlock_t))

    def printClassName(self):
        '''打印类名'''
        print("UpLoadDeviceStateBlock")

    def getIdBlock(self) -> zlapi.xxxIdBlock_t:
        '''获取数据包标识信息'''
        return self.pkId

    def getDeviceState(self) -> int:
        '''获取设备状态'''
        return self.block.deviceState

#==============================================================================================
# 电池块
# 包含电池电压和电量信息
#==============================================================================================

class BatteryBlock:
    '''
    电池块
    包含设备的电池电压和电量信息
    '''
    def __init__(self, _block:zlapi.batteryBlock_t = None, pkId: zlapi.xxxIdBlock_t = None) -> None:
        '''
        构造函数
        :param _block: 可选的底层C结构体数据块
        :param pkId: 可选的数据包标识信息
        '''
        super().__init__()
        self.block = zlapi.batteryBlock_t()
        ctypes.memset(ctypes.addressof(self.block), 0, ctypes.sizeof(self.block))
        if _block != None:
            ctypes.memmove(ctypes.byref(self.block), ctypes.byref(_block), ctypes.sizeof(zlapi.batteryBlock_t))

        self.pkId = zlapi.xxxIdBlock_t()
        ctypes.memset(ctypes.addressof(self.pkId), 0, ctypes.sizeof(self.pkId))
        if pkId != None:
            ctypes.memmove(ctypes.byref(self.pkId), ctypes.byref(pkId), ctypes.sizeof(zlapi.xxxIdBlock_t))

    def printClassName(self):
        '''打印类名'''
        print("BatteryBlock")

    def getIdBlock(self) -> zlapi.xxxIdBlock_t:
        '''获取数据包标识信息'''
        return self.pkId

    def getAdcMv(self) -> tuple[bool, int]:
        '''
        获取电池电压
        :return: (是否有效, 电压值[毫伏])
        '''
        return (self.block.mvOk, self.block.mv)

    def getLevel(self) -> tuple[bool, int]:
        '''
        获取电池电量
        :return: (是否有效, 电量百分比[0-100])
        '''
        return  (self.block.levelOk, self.block.level)

#==============================================================================================
# ADC值块
# 包含手指弯曲传感器的ADC值
#==============================================================================================

class AdcValueBlock:
    '''
    ADC值块
    包含手指弯曲传感器的ADC采样值
    '''
    def __init__(self, _block:zlapi.adcValueBlock_t = None, pkId: zlapi.xxxIdBlock_t = None) -> None:
        '''
        构造函数
        :param _block: 可选的底层C结构体数据块
        :param pkId: 可选的数据包标识信息
        '''
        super().__init__()
        self.block = zlapi.adcValueBlock_t()
        ctypes.memset(ctypes.addressof(self.block), 0, ctypes.sizeof(self.block))
        if _block != None:
            ctypes.memmove(ctypes.byref(self.block), ctypes.byref(_block), ctypes.sizeof(zlapi.adcValueBlock_t))

        self.pkId = zlapi.xxxIdBlock_t()
        ctypes.memset(ctypes.addressof(self.pkId), 0, ctypes.sizeof(self.pkId))
        if pkId != None:
            ctypes.memmove(ctypes.byref(self.pkId), ctypes.byref(pkId), ctypes.sizeof(zlapi.xxxIdBlock_t))

    def printClassName(self):
        '''打印类名'''
        print("AdcValueBlock")

    def getIdBlock(self) -> zlapi.xxxIdBlock_t:
        '''获取数据包标识信息'''
        return self.pkId

    def getAdcNum(self) -> int:
        '''获取ADC通道数量'''
        return self.block.adcNums

    def getEffectiveDataFormat(self) -> int:
        '''
        获取当前有效数据格式映射位
        :return: 位掩码
        '''
        return self.block.effectiveDataFormat

    def getTimeStamp(self) -> tuple[bool, float]:
        state = False
        if self.block.effectiveDataFormat & (zlapi.e_Upload_DataFormat.NEW_UPLOAD_DATA_TIME | zlapi.e_Upload_DataFormat.NEW_UPLOAD_DATA_HL_TIME):
            state = True
        return (state, 0.0 if math.isnan(self.block.timeStamp) else self.block.timeStamp)
    
    def isNormalization(self):
        return self.block.normalization
    
    def getAdcValue(self) -> tuple[bool, tuple]:
        state = False
        if self.block.effectiveDataFormat & zlapi.e_Upload_DataFormat.NEW_UPLOAD_DATA_ADCx:
            state = True
        return (state, tuple(self.block.adcValue[:self.block.adcNums]))


#==============================================================================================
# Dongle扫描块
# 包含Dongle扫描到的设备信息
#==============================================================================================
class DongleScanBlock:
    '''
    Dongle扫描块
    包含Dongle扫描到的设备信息（MAC地址、名称等）
    '''
    def __init__(self, _block:zlapi.scanBlock_t = None, pkId: zlapi.xxxIdBlock_t = None) -> None:
        '''
        构造函数
        :param _block: 可选的底层C结构体数据块
        :param pkId: 可选的数据包标识信息
        '''
        super().__init__()
        self.block = zlapi.scanBlock_t()
        ctypes.memset(ctypes.addressof(self.block), 0, ctypes.sizeof(self.block))
        if _block != None:
            ctypes.memmove(ctypes.byref(self.block), ctypes.byref(_block), ctypes.sizeof(zlapi.scanBlock_t))

        self.pkId = zlapi.xxxIdBlock_t()
        ctypes.memset(ctypes.addressof(self.pkId), 0, ctypes.sizeof(self.pkId))
        if pkId != None:
            ctypes.memmove(ctypes.byref(self.pkId), ctypes.byref(pkId), ctypes.sizeof(zlapi.xxxIdBlock_t))

    def printClassName(self):
        '''打印类名'''
        print("DongleScanBlock")

    def getIdBlock(self) -> zlapi.xxxIdBlock_t:
        '''获取数据包标识信息'''
        return self.pkId

    def getMac(self) -> bytes:
        '''获取设备MAC地址'''
        return bytes(self.block.mac)

    def getName(self) -> str:
        '''获取设备名称'''
        return bytes(self.block.name).split(b'\0', 1)[0].decode('utf-8', errors='ignore')


#==============================================================================================
# Dongle时间戳同步块
# 包含Dongle的时间戳同步信息
#==============================================================================================
class DongleTimeStampSyncBlock:
    '''
    Dongle时间戳同步块
    包含Dongle的时间戳同步信息
    '''
    def __init__(self, _block:zlapi.timeStampSyncBlock_t = None, pkId: zlapi.xxxIdBlock_t = None) -> None:
        '''
        构造函数
        :param _block: 可选的底层C结构体数据块
        :param pkId: 可选的数据包标识信息
        '''
        super().__init__()
        self.block = zlapi.timeStampSyncBlock_t()
        ctypes.memset(ctypes.addressof(self.block), 0, ctypes.sizeof(self.block))
        if _block != None:
            ctypes.memmove(ctypes.byref(self.block), ctypes.byref(_block), ctypes.sizeof(zlapi.timeStampSyncBlock_t))

        self.pkId = zlapi.xxxIdBlock_t()
        ctypes.memset(ctypes.addressof(self.pkId), 0, ctypes.sizeof(self.pkId))
        if pkId != None:
            ctypes.memmove(ctypes.byref(self.pkId), ctypes.byref(pkId), ctypes.sizeof(zlapi.xxxIdBlock_t))

    def printClassName(self):
        '''打印类名'''
        print("DongleTimeStampSyncBlock")

    def getIdBlock(self) -> zlapi.xxxIdBlock_t:
        '''获取数据包标识信息'''
        return self.pkId

    def getTimeStamp(self) -> float:
        '''获取时间戳'''
        return 0.0 if math.isnan(self.block.timeStamp) else self.block.timeStamp


#================================================================================================
# ZeroLab Bus 数据解包器
# 用于解析从设备接收的二进制数据流
# 支持解析多种数据块类型：MEMS数据、电池信息、ADC值、设备状态等
#================================================================================================

class ZlBusUnPack:
    '''
    ZeroLab Bus 数据解包器
    核心解包类，用于解析从设备接收的二进制数据流

    功能：
    - 创建和管理数据解码器
    - 解析数据流输入
    - 分析数据块头节点
    - 支持配置数据格式和流水号格式
    '''
    def __init__(self, tracker_nums:int = 1, user_id:int = 0xFF, fifoMaxSize:int = 10):
        '''
        构造函数
        :param tracker_nums: 追踪器数量
        :param user_id: 用户ID
        :param fifoMaxSize: FIFO队列最大容量
        '''
        # 创建解码器句柄： self.ddb
        self.ddb = zlapi.ul_dataDecodeBlockCreate(tracker_nums = tracker_nums, user_id = user_id, max_nums = fifoMaxSize)
        
        # 定义块 ID 映射表（必须在相关函数定义之后）
        # 注意：这个 map 用于根据 blockID 查找处理函数
        self.blockId_map = {
            # e_BlockID (使用整数值作为键)
            int(zlapi.e_BlockID.BlockID_OK):    self.decodeOkBlock,
            int(zlapi.e_BlockID.BlockID_ERROR): self.decodeErrBlock,
            int(zlapi.e_BlockID.BlockID_DATA):  self.decodeDataBlock,
        }

        self.dataBlockId_map = {
            # e_DataBlockID (使用整数值作为键)                         block                      Block
            int(zlapi.e_DataBlockID.DB_ID_MEMS_DATA)               :(zlapi.memsDataBlock_t,    MemsDataBlock),
            int(zlapi.e_DataBlockID.DB_ID_DEVICE_STATE)            :(zlapi.deviceStateBlock_t, UpLoadDeviceStateBlock),
            int(zlapi.e_DataBlockID.DB_ID_BATTERY)                 :(zlapi.batteryBlock_t,     BatteryBlock),
            int(zlapi.e_DataBlockID.DB_ID_ADC_VALUE)               :(zlapi.adcValueBlock_t,    AdcValueBlock),
            
            # 其他数据块 ID
            int(zlapi.e_DataBlockID.DB_ID_GET_UPLOAD_DATAFORMAT)    :(zlapi.uploadDataFormatBlock_t,      UploadDataFormatBlock),
            int(zlapi.e_DataBlockID.DB_ID_GET_SAMPLING_HZ)          :(zlapi.samplingHzBlock_t,            SamplingHzBlock),
            int(zlapi.e_DataBlockID.DB_ID_GET_UPLOAD_HZ)            :(zlapi.uploadHzBlock_t,              UploadHzBlock),
            int(zlapi.e_DataBlockID.DB_ID_GET_AHRS_FILTER_PARAM)    :(zlapi.filterMapBlock_t,             FilterMapBlock),
            int(zlapi.e_DataBlockID.DB_ID_GET_IC_DIR)               :(zlapi.icDirBlock_t,                 IcDirBlock),
            int(zlapi.e_DataBlockID.DB_ID_ADC_NORM_CAL_DISABLE)     :(zlapi.adcRangeBlock_t,              AdcRangeBlock),
            int(zlapi.e_DataBlockID.DB_ID_GET_GET_ADC_ORDER)        :(zlapi.adcOrderBlock_t,              AdcOrderBlock),
            int(zlapi.e_DataBlockID.DB_ID_GET_RF_ADV_NAME)          :(zlapi.devieRfNameBlock_t,           RfNameBlock),
            int(zlapi.e_DataBlockID.DB_ID_GET_RF_POWER)             :(zlapi.rfPowerBlock_t,               RfPowerBlock),
            int(zlapi.e_DataBlockID.DB_ID_GET_LED_COLOR)            :(zlapi.ledRgbDataBlock_t,            LedRgbData),
            int(zlapi.e_DataBlockID.DB_ID_GET_UART_BAUDRATE)        :(zlapi.uartBaudRateBlock_t,          UartBaudRateBlock),
            int(zlapi.e_DataBlockID.DB_ID_GET_SPIM_IIC_BLOCKSIZE)   :(zlapi.blockSizeBlock_t,             BlockSizeBlock),
            int(zlapi.e_DataBlockID.DB_ID_GET_MAC_ADDDR_STR)        :(zlapi.deviceMacBlock_t,             DeviceMacBlock),
            int(zlapi.e_DataBlockID.DB_ID_GET_FULL_SN_STR)          :(zlapi.deviceSnFullStrBlock_t,       DeviceSnFullStrBlock),
            int(zlapi.e_DataBlockID.DB_ID_GET_BOARD_VERSION_STR)    :(zlapi.deviceBoardVersionBlock_t,    DeviceBoardVersionBlock),
            int(zlapi.e_DataBlockID.DB_ID_GET_FIRMWARE_VERSION_STR) :(zlapi.deviceFirmwareVersionBlock_t, DeviceFirmwareVersionBlock),

            # if zlapi.U_UHL_LEVEL_EN:
            # """ UHL 指令 BlockID（可选）"""
            int(zlapi.e_DataBlockID.DB_ID_HL_GET_DOTID)             :(zlapi.dotIdBlock_t,                DotIdBlock),
            int(zlapi.e_DataBlockID.DB_ID_HL_GET_RF_CONNINTERVAL)   :(zlapi.bleConnIntervalBlock_t,      BleConnIntervalBlock),
            int(zlapi.e_DataBlockID.DB_ID_HL_GET_ACC_RANGE)         :(zlapi.accRangeBlock_t,             AccRangeBlock),
            int(zlapi.e_DataBlockID.DB_ID_HL_GET_GYR_RANGE)         :(zlapi.gyroRangeBlock_t,            GroRangeBlock),
            int(zlapi.e_DataBlockID.DB_ID_HL_GET_MAG_ELL_CAL_PARAM) :(zlapi.magEllipsoidCalParamBlock_t, MagEllipsoidCalParamBlock),
            int(zlapi.e_DataBlockID.DB_ID_HL_GET_FLOWID_FORMAT)     :(zlapi.flowIdFormatBlock_t,         FlowIdFormatBlock),
            int(zlapi.e_DataBlockID.DB_ID_HL_GET_AHRS_OFFSET)       :(zlapi.ahrsOffsetBlock_t,           AhhrsOffsetBlock),
            int(zlapi.e_DataBlockID.DB_ID_HL_GET_DATA_OUTPORT)      :(zlapi.dataPortBlock_t,             DataPortBlock),
            int(zlapi.e_DataBlockID.DB_ID_HL_GET_DATA_OUTPORT_MAP)  :(zlapi.dataPortMapBlock_t,          DataPortMapBlock),
            int(zlapi.e_DataBlockID.DB_ID_HL_GET_DEVICE_STATE)      :(zlapi.deviceStateBlock_t,          DeviceStateBlock),
            int(zlapi.e_DataBlockID.DB_ID_HL_GET_ADC_FILTER_PARAM)  :(zlapi.adcFilterParam_t,            AdcFilterParamBlock),
            int(zlapi.e_DataBlockID.DB_ID_HL_GET_FINGER_MAP)        :(zlapi.fingerMapBlock_t,            FingerMapBlock),

            # if zlapi.U_DG_LEVEL_EN:
            # """ UDG 指令 BlockID（可选）"""
            int(zlapi.e_DataBlockID.DB_ID_DG_GET_SN_FULL_STR )     :(zlapi.dongleSnFullStrBlock_t,       DongleSnFullStrBlock),
            int(zlapi.e_DataBlockID.DB_ID_DG_GET_BOARD_VERSION)    :(zlapi.deviceBoardVersionBlock_t,    DeviceBoardVersionBlock),
            int(zlapi.e_DataBlockID.DB_ID_DG_GET_FIRMWARE_VERSION) :(zlapi.deviceFirmwareVersionBlock_t, DeviceFirmwareVersionBlock),
            int(zlapi.e_DataBlockID.DB_ID_DG_GET_DEVICE_LIST)      :(zlapi.deviceBlockList_t,            DeviceBlockList),
            int(zlapi.e_DataBlockID.DB_ID_DG_GET_DEVICE_CONN_LIST) :(zlapi.deviceConnNumsBlock_t,        DeviceConnNumsBlock),
            int(zlapi.e_DataBlockID.DB_ID_DG_GET_RECOGNITION_MODE) :(zlapi.identifyWayBlock_t,           IdentifyWayBlock),

            # if zlapi.FDG_LEVEL_EN:
            # """ FDG 指令 BlockID（可选）"""
            int(zlapi.e_DataBlockID.DB_ID_DG_SCAN)                 :(zlapi.scanBlock_t,                  DongleScanBlock),
            int(zlapi.e_DataBlockID.DB_ID_DG_TIMESTAMP_SYNC)       :(zlapi.timeStampSyncBlock_t,         DongleTimeStampSyncBlock),
        }


    def __del__(self):
        '''
        析构函数
        销毁解码器句柄，释放内存
        '''
        zlapi.ul_dataDecodeBlockDelete(self.ddb)

    #==============================================================================================
    # 定义辅助函数
    def getBlockContents(self, addr, block):
        '''
        获取块内容
        :param addr: 内存地址
        :param block: ctypes结构体类型
        :return: 块内容，如果地址无效则返回None
        '''
        if addr == 0:
            return None
        return ctypes.cast(addr, ctypes.POINTER(block)).contents

    def getSubBlockContents(self, addr, block, sub_block):
        '''
        获取子块内容
        :param addr: 内存地址
        :param block: 父块类型
        :param sub_block: 子块类型
        :return: 子块内容，如果地址无效则返回None
        '''
        if addr == 0:
            return None
        return ctypes.cast(addr + ctypes.sizeof(block), ctypes.POINTER(sub_block)).contents

    #==============================================================================================
    # 解析 BlockID_DATA
    def decodeDataBlock(self, addr):
        '''
        解码数据块
        :param addr: 数据块内存地址
        :return: 对应的数据块对象（如MemsDataBlock、BatteryBlock等）
        '''
        dataBlock = self.getBlockContents(addr, zlapi.dataBlock_t)
        if dataBlock is None:
            print('dataBlock is None')
            return None
        subBlock = self.getSubBlockContents(addr, zlapi.dataBlock_t, self.dataBlockId_map[dataBlock.dataBlockId][0])
        if subBlock is None:
            return None
        if (self.dataBlockId_map[dataBlock.dataBlockId][1] is None):
            print(f'dataBlock.dataBlockId is {dataBlock.dataBlockId} is not support')
            return None
        return self.dataBlockId_map[dataBlock.dataBlockId][1](subBlock, dataBlock.pkId)

    def decodeOkBlock(self, addr):
        '''
        解码 OK 响应块
        :param addr: 数据块内存地址
        :return: CmdOkBlock对象或对应数据块对象
        '''
        okBlock = self.getBlockContents(addr, zlapi.cmdOkBlock_t)
        if okBlock is None:
            print('okBlock is None')
            return None
        if okBlock.dataLen == 0:
            return CmdOkBlock(okBlock)

        # 查找数据块
        subBlock = self.getSubBlockContents(addr, zlapi.dataBlock_t, self.dataBlockId_map[okBlock.dataBlockId][0])
        if subBlock is None:
            print(f'subBlock is None, okBlock.dataBlockId is {okBlock.dataBlockId}')
            return None
        if (self.dataBlockId_map[okBlock.dataBlockId][1] is None):
            print(f'okBlock.dataBlockId is {okBlock.dataBlockId} is not support')
            return None
        return self.dataBlockId_map[okBlock.dataBlockId][1](subBlock, okBlock.pkId)

    def decodeErrBlock(self, addr):
        '''
        解码错误响应块
        :param addr: 数据块内存地址
        :return: CmdErrBlock对象
        '''
        errBlock = self.getBlockContents(addr, zlapi.cmdErrBlock_t)
        if errBlock is None:
            print('errBlock is None')
            return None
        return CmdErrBlock(errBlock)

    #==============================================================================================
    # 解码数据输入口
    def decodeDataStreamInput(self, data:bytes) -> int:
        '''
        将收到的原始字节流送入解码器，解码后的数据节点追加到链表中
        :param data: 原始字节数据
        :return: 解码状态
        '''
        return zlapi.ul_dataBlockDecode(self.ddb, data)

    # 清空数据链表
    def clear(self) -> int:
        '''
        清空数据链表
        :return: 清空状态
        '''
        return zlapi.ul_dataBlockNodeClear(self.ddb)

    def size(self) -> int:
        '''
        获取数据链表中节点个数
        :return: 节点数量
        '''
        return zlapi.ul_dataBlockNodeCount(self.ddb)
    
    def count(self) -> int:
        '''
        数据链表中,节点个数
        '''
        return zlapi.ul_dataBlockNodeCount(self.ddb)

    def length(self) -> int:
        '''
        数据链表中,节点个数
        '''
        return zlapi.ul_dataBlockNodeCount(self.ddb)

    def getHeadBlockId(self) -> int:
        '''
        从数据链表中，读取头节点 blockId
        '''
        return (zlapi.ul_dataBlockGetBlockID(self.ddb) & 0xFFFFFFFF)

    def removeHeadDataNode(self) -> None:
        '''
        从数据列表中，删除错误的头节点
        '''
        zlapi.ul_dataBlockSkipNode(self.ddb)
        return None

    def analysisHeadBlockNode(self):
        '''
        分析数据链表中,头节点
        '''
        if self.size() > 0:
            blockId = zlapi.ul_dataBlockGetBlockID(self.ddb)

            if blockId not in self.blockId_map:
                print(f'blockId is {blockId} is not support')
                self.removeHeadDataNode()
                return None
            block = self.blockId_map[blockId](zlapi.ul_dataBlockGetBlock(self.ddb))
            self.removeHeadDataNode()
            return block
        return None
    
    #==============================================================================================

    # 手动设置上报数据，数据格式 (self.ddb 结构中的上报数据格式)
    def setDataFormat(self, tkIndex:int =  0, dataFormat:int = 0) -> int:
        return zlapi.ul_manualModifyDataFormat(self.ddb, tkIndex, dataFormat)

    # 手动设置上报数据，流水号格式 (self.ddb 结构中的流水号格式)
    def setFlowIdFormat(self, flowIdFormat:int) -> int:
        return zlapi.ul_manualModifyDataFlowIdFormat(self.ddb, flowIdFormat)

    # 获取流水号格式(self.ddb 结构中的流水号格式)
    def getFlowIdFormat(self) -> int:
        return zlapi.ul_getDataFlowIdFormat(self.ddb)
    

__all__ = [
    "CmdOkBlock",
    "CmdErrorBlock",
    "UploadDataFormatBlock",
    "SamplingHzBlock",
    "UploadHzBlock",
    "FilterMapBlock",
    "IcDirBlock",
    "AdcRangeBlock",
    "AdcOrderBlock",
    "RfNameBlock",
    "RfPowerBlock",
    "LedRgbData",
    "UartBaudRateBlock",
    "BlockSizeBlock",
    "DeviceMacBlock",
    "DeviceSnFullStrBlock",
    "DeviceBoardVersionBlock",
    "DeviceFirmwareVersionBlock",
    "DotIdBlock",
    "BleConnIntervalBlock",
    "AccRangeBlock",
    "GroRangeBlock",
    "MagEllipsoidCalParamBlock",
    "FlowIdFormatBlock",
    "AhhrsOffsetBlock",
    "DataPortBlock",
    "DataPortMapBlock",
    "DeviceStateBlock",
    "AdcFilterParamBlock",
    "FingerMapBlock",
    "DongleSnFullStrBlock",
    "DeviceBlockList",
    "DeviceConnNumsBlock",
    "IdentifyWayBlock",

    "MemsDataBlock",
    "UpLoadDeviceStateBlock",
    "BatteryBlock",
    "AdcValueBlock",
    "DongleScanBlock",
    "DongleTimeStampSyncBlock",
    "ZlBusUnPack",
]
