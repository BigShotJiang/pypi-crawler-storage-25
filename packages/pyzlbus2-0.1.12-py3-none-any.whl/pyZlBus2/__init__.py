# -*- coding: utf-8 -*-

"""
PyZlBus 包初始化文件
"""

# 导入主要模块
from .pyZlBus2 import *
from .pyZlBusBleTest import bleDemo
from .pyZlBusSerialTest import serialDemo
from .pyZlBusSerialRfTest import serialRfDemo
from .pyZlBusTest import test
import ZlBusApi as api

# 定义包的公共接口
__all__ = [
    # ----------- 指令 BlockID -----------
    "CmdOkBlock",
    "CmdErrorBlock",
    "UploadDataFormatBlock",
    "SamplingHzBlock",
    "UploadHzBlock",
    "FilterMapBlock",
    "IcDirBlock",
    "RfNameBlock",
    "RfPowerBlock",
    "LedRgbData",
    "UartBaudRateBlock",
    "BlockSizeBlock",
    "DeviceMacBlock",
    "DeviceSnFullStrBlock",
    "DeviceBoardVersionBlock",
    "DeviceFirmwareVersionBlock",
    "DotIdBlock",
    "BleConnIntervalBlock",
    "AccRangeBlock",
    "GroRangeBlock",
    "MagEllipsoidCalParamBlock",
    "FlowIdFormatBlock",
    "AhhrsOffsetBlock",
    "DataPortBlock",
    "DataPortMapBlock",
    "DeviceStateBlock",
    "AdcFilterParamBlock",
    "FingerMapBlock",
    "DongleSnFullStrBlock",
    "DeviceBlockList",
    "DeviceConnNumsBlock",
    "IdentifyWayBlock",

    # ----------- 上传数据 BlockID -----------
    "MemsDataBlock",
    "UpLoadDeviceStateBlock",
    "BatteryBlock",
    "AdcValueBlock",
    "DongleScanBlock",
    "DongleTimeStampSyncBlock",
    "ZlBusUnPack",

    #------   - 测试 Demo-----------
    'bleDemo',
    'serialDemo',
    'serialRfDemo',
    'test',
]