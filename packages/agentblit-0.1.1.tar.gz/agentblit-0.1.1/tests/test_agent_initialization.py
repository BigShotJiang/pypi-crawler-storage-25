"""Tests covering Agent initialization behavior."""

from __future__ import annotations

import uuid
from typing import Any

import pytest

from agentblit import Agent


def test_agent_initialization_accepts_provider_model_format() -> None:
    agent = Agent(
        model="openai/gpt-4o-mini",
        api_key="test-llm-key",
        agentblit_api_key="test-agentblit-key",
    )

    assert agent.vendor == "openai"
    assert agent.model == "gpt-4o-mini"
    assert uuid.UUID(agent.agent_id)
    assert uuid.UUID(agent.session_id)
    assert agent.config.agent_id == agent.agent_id
    assert agent.config.session_id == agent.session_id


@pytest.mark.parametrize(
    "model",
    [
        "",
        "gpt-4o-mini",
        "/gpt-4o-mini",
        "openai/",
    ],
)
def test_agent_initialization_rejects_invalid_model_format(model: str) -> None:
    with pytest.raises(
        ValueError,
        match="model must be in the format 'vendor/model'",
    ):
        Agent(
            model=model,
            api_key="test-llm-key",
            agentblit_api_key="test-agentblit-key",
        )


def test_track_queues_custom_event() -> None:
    agent = Agent(
        model="openai/gpt-4o-mini",
        api_key="test-llm-key",
        agentblit_api_key="test-agentblit-key",
    )

    agent.track("custom_event", {"key": "value"})

    assert len(agent._pending_custom_events) == 1  # type: ignore[attr-defined]
    event = agent._pending_custom_events[0]  # type: ignore[attr-defined]
    assert event["type"] == "custom_event"
    assert event["data"] == {"key": "value"}
    assert event["agent_id"] == agent.agent_id
    assert event["session_id"] == agent.session_id


def test_extract_llm_event_messages_uses_last_message_only() -> None:
    llm_messages: list[dict[str, Any]] = [
        {"role": "system", "content": "You are helpful."},
        {"role": "user", "content": "Hello"},
        {"role": "assistant", "content": "Hi"},
        {"role": "user", "content": "What's next?"},
    ]

    compact = Agent._extract_llm_event_messages(llm_messages)

    assert compact == [{"role": "user", "content": "What's next?"}]


def test_extract_llm_event_messages_keeps_summary_and_last_message() -> None:
    summary = {
        "role": "system",
        "content": "Summary of earlier conversation:\nUser asked about deployment.",
    }
    llm_messages: list[dict[str, Any]] = [
        {"role": "system", "content": "You are helpful."},
        summary,
        {"role": "assistant", "content": None, "tool_calls": []},
    ]

    compact = Agent._extract_llm_event_messages(llm_messages)

    assert compact == [summary, {"role": "assistant", "content": None, "tool_calls": []}]
