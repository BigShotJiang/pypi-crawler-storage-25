"""Remote AgentBlit tools + custom Python tools."""

from __future__ import annotations

import inspect
import json
from typing import Any, Callable, Optional

import httpx
from pydantic import BaseModel, ConfigDict

from agentblit.types import ApprovalCallback, ToolDefinition
from agentblit.utils import function_to_tool_schema, json_dumps_safe


class _ToolsListResponse(BaseModel):
    model_config = ConfigDict(extra="ignore")

    ok: bool
    tools: list[dict[str, Any]] = []


def tool(
    *,
    name: Optional[str] = None,
    description: str = "",
    permission_mode: str = "always_allow",
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """
    Decorator marking a function as a custom tool. ``permission_mode`` is
    ``always_allow`` or ``needs_approval`` (same semantics as AgentBlit).
    """

    def decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
        fn._agentblit_tool_name = name or fn.__name__  # type: ignore[attr-defined]
        fn._agentblit_tool_description = description or (fn.__doc__ or "").strip()  # type: ignore[attr-defined]
        fn._agentblit_permission_mode = permission_mode  # type: ignore[attr-defined]
        return fn

    return decorator


class ToolRegistry:
    """
    Merges tools from AgentBlit ``/api/tools/list`` with locally registered functions.
    Local tools with the same name override remote definitions.
    """

    def __init__(
        self,
        base_url: str,
        api_key: str,
        timeout: float = 30.0,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.timeout = timeout
        self._remote: dict[str, ToolDefinition] = {}
        self._custom: dict[str, ToolDefinition] = {}

    def _http_client(self) -> httpx.AsyncClient:
        return httpx.AsyncClient(timeout=self.timeout)

    def register(self, fn: Callable[..., Any]) -> None:
        """Register a decorated custom tool function."""
        name = getattr(fn, "_agentblit_tool_name", fn.__name__)
        description = getattr(fn, "_agentblit_tool_description", "") or (
            fn.__doc__ or ""
        ).strip()
        perm = getattr(fn, "_agentblit_permission_mode", "always_allow")
        schema = function_to_tool_schema(fn)
        self._custom[name] = ToolDefinition(
            name=name,
            description=description,
            input_schema=schema,
            permission_mode=perm,
            handler=fn,
        )

    async def refresh_remote(self) -> None:
        """Fetch tool list from AgentBlit and merge into registry."""
        url = f"{self.base_url}/api/tools/list"
        headers = {"X-API-Key": self.api_key}
        try:
            async with self._http_client() as client:
                r = await client.get(url, headers=headers)
                r.raise_for_status()
                data = _ToolsListResponse.model_validate(r.json())
        except httpx.HTTPError as e:
            raise RuntimeError(
                f"AgentBlit request failed for GET {url!r}: {e}\n"
                "Check that the server is running and AGENTBLIT_URL matches the "
                "scheme (http vs https) and port."
            ) from e
        if not data.ok:
            raise RuntimeError("tools/list returned ok=false")
        self._remote.clear()
        for t in data.tools:
            name = t["name"]
            perm = t.get("permissionMode", "always_allow")
            self._remote[name] = ToolDefinition(
                name=name,
                description=t.get("description", ""),
                input_schema=t.get("inputSchema") or {"type": "object", "properties": {}},
                permission_mode=perm,
                output_schema=t.get("outputSchema"),
            )

    def _merged(self) -> dict[str, ToolDefinition]:
        out = dict(self._remote)
        out.update(self._custom)
        return out

    def get_definition(self, name: str) -> Optional[ToolDefinition]:
        return self._merged().get(name)

    def to_openai_tools(self) -> list[dict[str, Any]]:
        """OpenAI Chat Completions ``tools`` array."""
        tools: list[dict[str, Any]] = []
        for d in self._merged().values():
            tools.append(
                {
                    "type": "function",
                    "function": {
                        "name": d.name,
                        "description": d.description,
                        "parameters": d.input_schema,
                    },
                }
            )
        return tools

    async def _ensure_approval(
        self,
        definition: ToolDefinition,
        tool_name: str,
        arguments: dict[str, Any],
        approval_callback: Optional[ApprovalCallback],
    ) -> bool:
        if definition.permission_mode != "needs_approval":
            return True
        if approval_callback is not None:
            return await approval_callback(tool_name, arguments)
        # Default: stdin (run in thread pool to avoid blocking event loop badly)
        import asyncio

        def _ask() -> bool:
            ans = input(
                f'Approve tool "{tool_name}" with args {json_dumps_safe(arguments)}? [y/N]: '
            )
            return ans.strip().lower() in ("y", "yes")

        return await asyncio.to_thread(_ask)

    async def execute(
        self,
        tool_call_id: str,
        tool_name: str,
        arguments_json: str,
        approval_callback: Optional[ApprovalCallback] = None,
    ) -> str:
        """Run tool and return JSON string for assistant message ``tool`` role."""
        definition = self.get_definition(tool_name)
        if definition is None:
            return json_dumps_safe(
                {"error": f"Unknown tool: {tool_name}"}
            )

        try:
            arguments = json.loads(arguments_json) if arguments_json else {}
        except json.JSONDecodeError as e:
            return json_dumps_safe({"error": f"Invalid JSON arguments: {e}"})

        if not await self._ensure_approval(
            definition, tool_name, arguments, approval_callback
        ):
            return json_dumps_safe(
                {"error": "User denied approval for this tool call."}
            )

        if definition.handler is not None:
            try:
                result = definition.handler(**arguments)
                if inspect.isawaitable(result):
                    result = await result  # type: ignore[misc]
                return json_dumps_safe(result)
            except Exception as e:
                return json_dumps_safe({"error": str(e)})

        # Remote AgentBlit
        payload = {
            "tool_calls": [
                {
                    "id": tool_call_id,
                    "type": "function",
                    "function": {
                        "name": tool_name,
                        "arguments": json_dumps_safe(arguments),
                    },
                }
            ]
        }
        url = f"{self.base_url}/api/tools/call"
        headers = {
            "X-API-Key": self.api_key,
            "Content-Type": "application/json",
        }
        try:
            async with self._http_client() as client:
                r = await client.post(url, headers=headers, json=payload)
                r.raise_for_status()
                data = r.json()
        except httpx.HTTPError as e:
            raise RuntimeError(
                f"AgentBlit request failed for POST {url!r}: {e}\n"
                "See refresh_remote() error hints for connection troubleshooting."
            ) from e

        if not data.get("ok"):
            return json_dumps_safe({"error": data})

        results = data.get("results") or []
        for item in results:
            if item.get("tool_call_id") == tool_call_id:
                res = item.get("result") or {}
                if res.get("isError"):
                    parts = res.get("content") or []
                    text = "".join(
                        p.get("text", "") for p in parts if isinstance(p, dict)
                    )
                    return json_dumps_safe({"error": text or "Tool error"})
                structured = res.get("structuredContent")
                if structured is not None:
                    return json_dumps_safe(structured)
                parts = res.get("content") or []
                text = "".join(
                    p.get("text", "") for p in parts if isinstance(p, dict)
                )
                return json_dumps_safe({"result": text})
        return json_dumps_safe({"error": "No result for tool_call_id"})
