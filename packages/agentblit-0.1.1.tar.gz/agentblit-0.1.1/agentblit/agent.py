"""Agent: streaming LLM loop with AgentBlit tools and memory summarization."""

from __future__ import annotations

import json
import time
import uuid
from datetime import datetime, timezone
from typing import Any, AsyncIterator, Callable, List, Optional

import httpx
from openai import AsyncOpenAI

from agentblit.memory import ChatMemory
from agentblit.tools import ToolRegistry
from agentblit.types import ApprovalCallback, AgentConfig
from agentblit.utils import DebugLogger, json_dumps_safe

_VENDOR_BASE_URLS: dict[str, str] = {
    "openai": "https://api.openai.com/v1",
    "anthropic": "https://api.anthropic.com/v1",
    "gemini": "https://generativelanguage.googleapis.com/v1beta/openai",
    "openrouter": "https://openrouter.ai/api/v1",
}

_DEFAULT_TOOL_USAGE_INSTRUCTION = "Use tools when they help answer accurately."


def _resolve_vendor_and_model(model: str) -> tuple[str, str]:
    """Split `vendor/model` and validate both parts are present."""
    model = model.strip()
    if not model:
        raise ValueError(
            "model must be in the format 'vendor/model', for example "
            "'openai/gpt-4o-mini' or 'openrouter/openai/gpt-4o-mini'"
        )
    if "/" not in model:
        raise ValueError(
            "model must be in the format 'vendor/model', for example "
            "'openai/gpt-4o-mini' or 'openrouter/openai/gpt-4o-mini'"
        )

    vendor, provider_model = model.split("/", 1)
    vendor = vendor.strip().lower()
    provider_model = provider_model.strip()
    if not vendor or not provider_model:
        raise ValueError(
            "model must be in the format 'vendor/model', for example "
            "'openai/gpt-4o-mini' or 'openrouter/openai/gpt-4o-mini'"
        )
    return vendor, provider_model


def _resolve_llm_url(vendor: str) -> str:
    try:
        return _VENDOR_BASE_URLS[vendor]
    except KeyError as exc:
        supported = ", ".join(sorted(_VENDOR_BASE_URLS.keys()))
        raise ValueError(
            f"Unsupported model vendor '{vendor}'. Supported vendors: {supported}."
        ) from exc


def _format_messages_for_summary(messages: list[dict[str, Any]]) -> str:
    """Human-readable dump of message list for summarization prompts."""
    parts: list[str] = []
    for i, m in enumerate(messages):
        role = m.get("role", "?")
        if role == "assistant" and m.get("tool_calls"):
            tc = m["tool_calls"]
            parts.append(f"[{i}] assistant (tool_calls): {json_dumps_safe(tc)}")
            continue
        content = m.get("content")
        if content is None:
            content = ""
        parts.append(f"[{i}] {role}: {content}")
    return "\n".join(parts)


def _compose_system_prompt(system_prompt: str) -> str:
    """Append SDK default tool guidance unless user already included it."""
    user_prompt = system_prompt.strip()
    default_instruction = _DEFAULT_TOOL_USAGE_INSTRUCTION
    if default_instruction.lower() in user_prompt.lower():
        return user_prompt
    if not user_prompt:
        return default_instruction
    return f"{user_prompt}\n\n{default_instruction}"


class Agent:
    """
    High-level agent with OpenAI-compatible chat, AgentBlit remote tools, optional
    custom tools, streaming responses, and summarization-based memory.
    """

    def __init__(
        self,
        model: str,
        api_key: str,
        agentblit_url: str = "https://console.agentblit.com",
        agentblit_api_key: str = "",
        system_prompt: str = "",
        max_history: int = 5,
        debug: bool = False,
        timeout: float = 30.0,
        approval_callback: Optional[ApprovalCallback] = None,
        custom_tools: Optional[List[Callable[..., Any]]] = None,
        max_tool_rounds: int = 25,
    ) -> None:
        agentblit_key = agentblit_api_key.strip()
        if not agentblit_key:
            raise ValueError("agentblit_api_key is required")
        if max_history < 1:
            raise ValueError("max_history must be at least 1")
        if max_tool_rounds < 1:
            raise ValueError("max_tool_rounds must be at least 1")
        self.vendor, self.model = _resolve_vendor_and_model(model)
        self.llm_url = _resolve_llm_url(self.vendor)
        self.api_key = api_key
        self.system_prompt = _compose_system_prompt(system_prompt)
        self.timeout = timeout
        self.approval_callback = approval_callback
        self.max_tool_rounds = max_tool_rounds

        self._client = AsyncOpenAI(
            api_key=api_key,
            base_url=self.llm_url,
            timeout=timeout,
        )
        self._tools = ToolRegistry(
            base_url=agentblit_url,
            api_key=agentblit_key,
            timeout=timeout,
        )
        if custom_tools:
            for fn in custom_tools:
                self._tools.register(fn)

        self._memory = ChatMemory(
            max_history=max_history,
            summarize_fn=self._summarize_older_messages,
        )
        self._debug = DebugLogger(enabled=debug)
        self.agent_id = str(uuid.uuid4())
        self.session_id = str(uuid.uuid4())
        self._event_base_url = agentblit_url.rstrip("/")
        self._event_api_key = agentblit_key
        self._pending_custom_events: list[dict[str, Any]] = []
        self._agent_init_sent = False
        self._tools_signature: Optional[str] = None
        self.config = AgentConfig(
            model=self.model,
            vendor=self.vendor,
            llm_url=self.llm_url,
            agentblit_url=agentblit_url.rstrip("/"),
            system_prompt=self.system_prompt,
            max_history=max_history,
            debug=debug,
            timeout=timeout,
            agent_id=self.agent_id,
            session_id=self.session_id,
        )

    @staticmethod
    def _event_timestamp() -> str:
        return (
            datetime.now(timezone.utc)
            .isoformat(timespec="milliseconds")
            .replace("+00:00", "Z")
        )

    def _make_event(
        self,
        *,
        event_type: str,
        data: Any,
        tokens: int = 0,
        latency_ms: int = 0,
    ) -> dict[str, Any]:
        return {
            "id": f"evt_{uuid.uuid4().hex}",
            "session_id": self.session_id,
            "agent_id": self.agent_id,
            "timestamp": self._event_timestamp(),
            "type": event_type,
            "data": data,
            "tokens": max(0, int(tokens)),
            "latency_ms": max(0, int(latency_ms)),
        }

    async def _flush_events(self, events: list[dict[str, Any]]) -> None:
        if not events:
            return
        url = f"{self._event_base_url}/api/events/batch"
        headers = {
            "X-API-Key": self._event_api_key,
            "Content-Type": "application/json",
        }
        event_types = [str(evt.get("type", "unknown")) for evt in events]
        self._debug.log(
            "Event batch send start url=%s count=%s types=%s",
            url,
            len(events),
            ",".join(event_types),
        )
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.post(
                    url,
                    headers=headers,
                    json={"events": events},
                )
                response.raise_for_status()
                self._debug.log(
                    "Event batch send success status=%s count=%s",
                    response.status_code,
                    len(events),
                )
        except httpx.HTTPStatusError as exc:
            status = exc.response.status_code
            body_preview = ""
            try:
                body_preview = exc.response.text[:1000]
            except Exception:
                body_preview = "<unavailable>"
            self._debug.log(
                "Failed to send events batch: %s status=%s body=%s",
                exc,
                status,
                body_preview,
            )
        except httpx.HTTPError as exc:
            response = getattr(exc, "response", None)
            status = getattr(response, "status_code", "n/a")
            body_preview = ""
            if response is not None:
                try:
                    body_preview = response.text[:1000]
                except Exception:
                    body_preview = "<unavailable>"
            self._debug.log(
                "Failed to send events batch: %s status=%s body=%s",
                exc,
                status,
                body_preview,
            )
        except Exception as exc:
            self._debug.log("Unexpected event flush error: %s", exc)

    @staticmethod
    def _extract_llm_event_messages(
        llm_messages: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """
        Keep llm_call event payload compact:
        - always include only the last message
        - if memory was summarized, include summary + last message
        - never include the primary system prompt
        """
        if not llm_messages:
            return []
        summary_msg: Optional[dict[str, Any]] = None
        for msg in llm_messages:
            if (
                msg.get("role") == "system"
                and isinstance(msg.get("content"), str)
                and msg["content"].startswith("Summary of earlier conversation:")
            ):
                summary_msg = msg
                break
        last_msg = llm_messages[-1]
        if summary_msg is None:
            return [last_msg]
        if summary_msg is last_msg:
            return [summary_msg]
        return [summary_msg, last_msg]

    def track(self, event_type: str, properties: dict[str, Any]) -> None:
        """
        Queue a custom analytics event to be sent with the next run() batch.
        """
        self._pending_custom_events.append(
            self._make_event(event_type=event_type, data=properties)
        )

    async def _summarize_older_messages(
        self, older: list[dict[str, Any]]
    ) -> str:
        """Compress older turns using the same LLM (non-streaming)."""
        text = _format_messages_for_summary(older)
        self._debug.log("Summarizing %s older messages", len(older))
        resp = await self._client.chat.completions.create(
            model=self.model,
            messages=[
                {
                    "role": "system",
                    "content": (
                        "Summarize the conversation excerpt below for use as memory. "
                        "Preserve key facts, decisions, and tool outcomes. Be concise."
                    ),
                },
                {"role": "user", "content": text},
            ],
            temperature=0.2,
            timeout=self.timeout,
        )
        choice = resp.choices[0].message
        return (choice.content or "").strip()

    def register_tool(self, fn: Callable[..., Any]) -> None:
        """Register an additional custom tool (decorated with ``@tool``)."""
        self._tools.register(fn)

    async def run(self, user_message: str) -> AsyncIterator[str]:
        """
        Run one user turn: may involve multiple LLM rounds if tools are used.
        Yields streamed text deltas from the model's final assistant messages each round.
        """
        events: list[dict[str, Any]] = list(self._pending_custom_events)
        self._pending_custom_events.clear()
        try:
            self._memory.append({"role": "user", "content": user_message})
            await self._tools.refresh_remote()
            openai_tools = self._tools.to_openai_tools()
            tools_signature = json.dumps(openai_tools, sort_keys=True)
            if not self._agent_init_sent:
                events.append(
                    self._make_event(
                        event_type="agent_init",
                        data={
                            "system_prompt": self.system_prompt,
                            "tools": openai_tools,
                        },
                    )
                )
                self._agent_init_sent = True
                self._tools_signature = tools_signature
            elif tools_signature != self._tools_signature:
                events.append(
                    self._make_event(
                        event_type="tools_updated",
                        data={"tools": openai_tools},
                    )
                )
                self._tools_signature = tools_signature

            events.append(
                self._make_event(
                    event_type="user_prompt",
                    data={"request": {"message": user_message}, "response": None},
                )
            )

            finished_normally = False
            for _ in range(self.max_tool_rounds):
                messages = await self._memory.build_messages_for_llm(self.system_prompt)
                self._debug.log_llm_request(
                    self.model, len(messages), len(openai_tools)
                )

                llm_request_data: dict[str, Any] = {
                    "model": self.model,
                    "messages": messages,
                    "stream": True,
                }
                llm_event_request_data: dict[str, Any] = {
                    "model": self.model,
                    "messages": self._extract_llm_event_messages(messages),
                    "stream": True,
                }
                if openai_tools:
                    llm_request_data["tools"] = openai_tools

                kwargs: dict[str, Any] = dict(llm_request_data)
                kwargs["timeout"] = self.timeout
                if self.vendor in {"openai", "openrouter"}:
                    kwargs["stream_options"] = {"include_usage": True}

                llm_started_at = time.perf_counter()
                stream = await self._client.chat.completions.create(**kwargs)

                content_parts: list[str] = []
                tool_calls_map: dict[int, dict[str, str]] = {}
                finish_reason: Optional[str] = None
                llm_total_tokens = 0

                async for chunk in stream:
                    if getattr(chunk, "usage", None) and chunk.usage.total_tokens:
                        llm_total_tokens = int(chunk.usage.total_tokens)
                    if not chunk.choices:
                        continue
                    ch = chunk.choices[0]
                    if ch.finish_reason:
                        finish_reason = ch.finish_reason
                    delta = ch.delta
                    if delta is None:
                        continue
                    if delta.content:
                        content_parts.append(delta.content)
                        yield delta.content
                    if delta.tool_calls:
                        for tc in delta.tool_calls:
                            idx = tc.index
                            if idx not in tool_calls_map:
                                tool_calls_map[idx] = {
                                    "id": "",
                                    "name": "",
                                    "arguments": "",
                                }
                            if tc.id:
                                tool_calls_map[idx]["id"] = tc.id
                            if tc.function:
                                if tc.function.name:
                                    tool_calls_map[idx]["name"] = tc.function.name
                                if tc.function.arguments:
                                    tool_calls_map[idx]["arguments"] += (
                                        tc.function.arguments
                                    )

                assistant_content = "".join(content_parts) or None
                llm_latency_ms = int((time.perf_counter() - llm_started_at) * 1000)

                # Reconstruct tool_calls in index order
                sorted_idxs = sorted(tool_calls_map.keys())
                oai_tool_calls: list[dict[str, Any]] = []
                for idx in sorted_idxs:
                    tc = tool_calls_map[idx]
                    oai_tool_calls.append(
                        {
                            "id": tc["id"],
                            "type": "function",
                            "function": {
                                "name": tc["name"],
                                "arguments": tc["arguments"] or "{}",
                            },
                        }
                    )

                events.append(
                    self._make_event(
                        event_type="llm_call",
                        data={
                            "request": llm_event_request_data,
                            "response": {
                                "finish_reason": finish_reason,
                                "content": assistant_content,
                                "tool_calls": oai_tool_calls,
                            },
                        },
                        tokens=llm_total_tokens,
                        latency_ms=llm_latency_ms,
                    )
                )

                if finish_reason == "tool_calls" or oai_tool_calls:
                    self._debug.log_tool_calls(oai_tool_calls)

                    self._memory.append(
                        {
                            "role": "assistant",
                            "content": assistant_content,
                            "tool_calls": oai_tool_calls,
                        }
                    )

                    for tc in oai_tool_calls:
                        tid = tc["id"]
                        name = tc["function"]["name"]
                        args = tc["function"]["arguments"]
                        tool_request_data = {
                            "id": tid,
                            "type": "function",
                            "function": {
                                "name": name,
                                "arguments": args,
                            },
                        }
                        tool_started_at = time.perf_counter()
                        result_str = await self._tools.execute(
                            tid,
                            name,
                            args,
                            self.approval_callback,
                        )
                        tool_latency_ms = int(
                            (time.perf_counter() - tool_started_at) * 1000
                        )
                        self._debug.log_tool_result(tid, True, result_str)
                        parsed_tool_response: Any
                        try:
                            parsed_tool_response = json.loads(result_str)
                        except json.JSONDecodeError:
                            parsed_tool_response = {"raw": result_str}
                        events.append(
                            self._make_event(
                                event_type="tool_call",
                                data={
                                    "request": tool_request_data,
                                    "response": parsed_tool_response,
                                },
                                latency_ms=tool_latency_ms,
                            )
                        )
                        self._memory.append(
                            {
                                "role": "tool",
                                "tool_call_id": tid,
                                "content": result_str,
                            }
                        )
                    # Next iteration: model consumes tool outputs (may stream again)
                    continue

                # No tool calls this round — persist assistant message and stop
                self._memory.append(
                    {"role": "assistant", "content": assistant_content or ""}
                )
                finished_normally = True
                break

            if not finished_normally:
                raise RuntimeError(
                    f"Exceeded max_tool_rounds ({self.max_tool_rounds}); "
                    "increase max_tool_rounds or simplify the task."
                )
        except Exception as exc:
            events.append(
                self._make_event(
                    event_type="agent_loop_error",
                    data={"error": str(exc)},
                )
            )
            raise
        finally:
            self._debug.log(
                "Queueing event flush count=%s",
                len(events),
            )
            await self._flush_events(events)

    @property
    def memory(self) -> ChatMemory:
        return self._memory
