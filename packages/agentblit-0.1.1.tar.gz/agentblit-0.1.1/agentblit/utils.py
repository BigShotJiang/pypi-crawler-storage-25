"""Debug logging and JSON schema helpers for custom tools."""

from __future__ import annotations

import inspect
import json
import logging
from types import UnionType
from typing import Any, Callable, Optional, Union, get_args, get_origin, get_type_hints

logger = logging.getLogger("agentblit")


class DebugLogger:
    """When enabled, logs LLM and tool activity."""

    def __init__(self, enabled: bool = False) -> None:
        self.enabled = enabled
        if enabled and not logger.handlers:
            h = logging.StreamHandler()
            h.setFormatter(
                logging.Formatter("[agentblit] %(levelname)s: %(message)s")
            )
            logger.addHandler(h)
            logger.setLevel(logging.DEBUG)

    def log(self, msg: str, *args: Any) -> None:
        if self.enabled:
            logger.debug(msg, *args)

    def log_llm_request(self, model: str, message_count: int, tool_count: int) -> None:
        self.log(
            "LLM request model=%s messages=%s tools=%s",
            model,
            message_count,
            tool_count,
        )

    def log_tool_calls(self, calls: list[dict[str, Any]]) -> None:
        self.log("Tool calls: %s", json.dumps(calls, default=str))

    def log_tool_result(self, tool_call_id: str, ok: bool, preview: str) -> None:
        self.log("Tool result id=%s ok=%s preview=%s", tool_call_id, ok, preview[:500])


def _python_type_to_json_schema(tp: Any) -> dict[str, Any]:
    """Map simple Python types to JSON Schema fragments."""
    if tp is int:
        return {"type": "integer"}
    if tp is float:
        return {"type": "number"}
    if tp is bool:
        return {"type": "boolean"}
    if tp is str:
        return {"type": "string"}
    if tp is type(None):
        return {"type": "null"}

    origin = get_origin(tp)
    args = get_args(tp)

    if origin is list:
        inner = args[0] if args else Any
        return {"type": "array", "items": _python_type_to_json_schema(inner)}
    if origin is dict:
        return {"type": "object", "additionalProperties": True}

    # Union / Optional
    if origin is Union or origin is UnionType:
        non_none = [a for a in args if a not in (type(None), None)]
        if len(non_none) == 1:
            return _python_type_to_json_schema(non_none[0])
        return {"type": "string"}

    return {"type": "string"}


def function_to_tool_schema(fn: Callable[..., Any]) -> dict[str, Any]:
    """
    Build a minimal JSON Schema object for ``parameters`` (OpenAI function calling)
    from a Python function's signature and type hints.
    """
    sig = inspect.signature(fn)
    try:
        hints = get_type_hints(fn, include_extras=True)
    except Exception:
        hints = {}

    properties: dict[str, Any] = {}
    required: list[str] = []

    for name, param in sig.parameters.items():
        if name in ("self", "cls"):
            continue
        if param.kind in (
            inspect.Parameter.VAR_POSITIONAL,
            inspect.Parameter.VAR_KEYWORD,
        ):
            continue

        ann = hints.get(name, param.annotation)
        if ann is inspect.Parameter.empty:
            ann = str

        properties[name] = _python_type_to_json_schema(ann)
        if param.default is inspect.Parameter.empty:
            required.append(name)

    schema: dict[str, Any] = {
        "type": "object",
        "properties": properties,
    }
    if required:
        schema["required"] = required
    return schema


def json_dumps_safe(obj: Any) -> str:
    return json.dumps(obj, default=str)
