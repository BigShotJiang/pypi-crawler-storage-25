"""Core types for the AgentBlit SDK."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Awaitable, Callable, Optional


@dataclass
class ToolDefinition:
    """A tool exposed to the LLM (remote AgentBlit or custom)."""

    name: str
    description: str
    input_schema: dict[str, Any]
    permission_mode: str = "always_allow"  # always_allow | needs_approval
    output_schema: Optional[dict[str, Any]] = None
    # If set, tool is executed locally instead of via AgentBlit API
    handler: Optional[Callable[..., Any]] = None


@dataclass
class AgentConfig:
    """Configuration snapshot for Agent (optional introspection / tests)."""

    model: str
    vendor: str
    llm_url: str
    agentblit_url: str
    system_prompt: str
    max_history: int
    debug: bool
    timeout: float
    agent_id: str
    session_id: str


# Approval: async (tool_name, arguments_dict) -> bool
ApprovalCallback = Callable[[str, dict[str, Any]], Awaitable[bool]]

# Summarize older messages for memory compression
SummarizeFn = Callable[[list[dict[str, Any]]], Awaitable[str]]
