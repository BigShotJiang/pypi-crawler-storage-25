"""Chat memory with LLM-based summarization when history exceeds max_history."""

from __future__ import annotations

from typing import Any, Awaitable, Callable, Optional

# Messages use OpenAI chat format: role + content (and optional tool_call_id for tool role)


class ChatMemory:
    """
    Stores full conversation history. When building context for the LLM, keeps the
    most recent ``max_history`` messages verbatim; older messages are replaced by a
    single summary message produced by ``summarize_fn``.
    """

    def __init__(
        self,
        max_history: int = 5,
        summarize_fn: Optional[Callable[[list[dict[str, Any]]], Awaitable[str]]] = None,
    ) -> None:
        if max_history < 1:
            raise ValueError("max_history must be at least 1")
        self.max_history = max_history
        self._summarize_fn = summarize_fn
        self._messages: list[dict[str, Any]] = []

    @property
    def messages(self) -> list[dict[str, Any]]:
        """Full stored history (not the compressed view)."""
        return list(self._messages)

    def append(self, message: dict[str, Any]) -> None:
        self._messages.append(message)

    def extend(self, messages: list[dict[str, Any]]) -> None:
        self._messages.extend(messages)

    def clear(self) -> None:
        self._messages.clear()

    async def build_messages_for_llm(
        self,
        system_prompt: str,
    ) -> list[dict[str, Any]]:
        """
        Build message list for the chat completion API: system prompt, optional
        summary of older turns, then up to ``max_history`` recent messages.
        """
        out: list[dict[str, Any]] = [{"role": "system", "content": system_prompt}]

        if len(self._messages) <= self.max_history:
            out.extend(self._messages)
            return out

        older = self._messages[: -self.max_history]
        recent = self._messages[-self.max_history :]

        if self._summarize_fn is None:
            # Fallback: truncate with a short note (no extra LLM call)
            summary_text = (
                f"[Earlier conversation truncated: {len(older)} message(s) not shown. "
                "Provide a summarize_fn on Agent to compress older context with the LLM.]"
            )
        else:
            summary_text = await self._summarize_fn(older)

        out.append(
            {
                "role": "system",
                "content": f"Summary of earlier conversation:\n{summary_text}",
            }
        )
        out.extend(recent)
        return out
