## 0.4.4 (2026-04-03)

### Fix

- **renderers**: fix empty values rendering

