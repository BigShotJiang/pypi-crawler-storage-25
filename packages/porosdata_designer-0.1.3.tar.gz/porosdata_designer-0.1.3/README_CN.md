# PorosData-Designer

`PorosData-Designer` 将 MinerU 生成的解析结果转换为 **`{output_root}/{doc_id}/` 下的统一单文档交付布局**：结构感知训练视图（`*.content.json` / `*.content.txt`）、数据挖掘视图（`*.structure.json`），以及多模态交付（`*.assets.index.json` 与 `images/`）。

它面向科学数据处理、结构感知训练准备，以及围绕段落、公式、化学式和图表资产展开的原子化文档设计。

## 它解决什么问题

- 从 `*_content_list.json` 构造带 Poros 标签的结构化全文与纯文本流。
- 将章节、公式、化学式与资产引用整理进 `*.structure.json`。
- 抽取图注、正文提及并拷贝图片，输出 `images/` 与索引文件。

## 安装

推荐 Python 版本：`3.12.6`（已在 Windows `win32 10.0.26200` 本机环境验证）。
最低支持版本仍为 `3.8`；Python `3.9`-`3.11` 语法兼容，但尚未在本仓库逐一完成回归测试。

```bash
pip install porosdata-designer
```

安装后在 Python 中使用 `import designer`，命令行使用 `designer`；PyPI 发行包名为 `porosdata-designer`。

从 PyPI 安装开发依赖：

```bash
pip install "porosdata-designer[dev]"
```

在本仓库中开发时：

```bash
pip install -e ".[dev]"
```

## 快速开始
`--input_dir` 必须指向包含 MinerU 产物的目录树（递归查找 `*_content_list.json`）。

运行全流程（推荐从这里开始）：

```bash
designer run all --input_dir "path/to/input_dir" --output_dir "path/to/output_dir" --log_dir "path/to/log_dir"
```

你也可以仅运行其中一个阶段：

```bash
designer run text --input_dir "path/to/input_dir" --output_dir "path/to/output_dir"
designer run multimodal --input_dir "path/to/input_dir" --output_dir "path/to/output_dir"
```

当省略 `--output_dir` 时，将写入包配置的默认输出根目录。

## 分阶段运行

只运行文本结构化：

```bash
designer run text --input_dir "path/to/input_dir" --output_dir "path/to/output_dir"
```

只运行多模态抽取（本仓库中文本与多模态共用同一输入树）：

```bash
designer run multimodal --input_dir "path/to/input_dir" --output_dir "path/to/output_dir"
```

## 输出结果

每个文档对应 `{output_root}/{doc_id}/`：

```text
path/to/output_root/
└── {doc_id}/
    ├── {doc_id}.content.json
    ├── {doc_id}.content.txt
    ├── {doc_id}.structure.json
    ├── {doc_id}.assets.index.json
    └── images/
        ├── fig_1.jpg
        └── fig_1.md
```

## 校验与验收

审计（省略 `--root_dir` 时将使用包配置的默认输出根目录）：

```bash
designer audit structured --root_dir "path/to/output_root"
```

校验 `*.content.json`：

```bash
designer validate structured --output_dir "path/to/output_root"
```

校验多模态索引：

```bash
designer validate multimodal --output_dir "path/to/output_root"
```

最终验收：

```bash
designer validate acceptance --output_dir "path/to/output_root"
```

## Python 用法

你也可以直接在 Python 中使用这些核心组件：

```python
from designer import DataMiningMapper, MultimodalInterleaver, TextAggregator

aggregator = TextAggregator()
mapper = DataMiningMapper()
interleaver = MultimodalInterleaver()
```

下面是一个更完整的文本侧示例：

```python
from designer import DataMiningMapper, TextAggregator

content_list = [
    {"type": "text", "text_level": 1, "text": "Abstract", "page_idx": 0},
    {"type": "text", "text": "This work studies a Cu-Zr metallic glass system.", "page_idx": 0},
    {"type": "text", "text_level": 1, "text": "Results and Discussion", "page_idx": 1},
    {"type": "text", "text": "Figure 1 shows the microstructure evolution at 700 K.", "page_idx": 1},
]

aggregator = TextAggregator()
structured_text = aggregator.aggregate(content_list)

mapper = DataMiningMapper()
datamining_view = mapper.map(structured_text, {"doc_id": "demo-0001"})

print(structured_text)
print(datamining_view.pure_text_stream)
print(datamining_view.structured_json["sections"])
```

这个例子执行后，你可以看到：

- `structured_text` 会生成带 Poros 标签的结构化文本，例如 `<poros_doc>`、`<poros_section_*>`、`<poros_paragraph>`。
- `pure_text_stream` 会去掉结构标签，保留适合继续训练或检索的纯文本内容。
- `structured_json` 会暴露 `sections`、`formulas`、`chemical_formulas`、`asset_refs` 等数据挖掘字段。
