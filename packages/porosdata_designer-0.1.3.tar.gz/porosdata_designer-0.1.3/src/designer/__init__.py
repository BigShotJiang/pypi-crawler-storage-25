# -*- coding: utf-8 -*-
"""
PorosData-Designer 包初始化模块

核心能力:
    - 段落类型识别: ParagraphClassifier 智能分类文档结构
    - 文本结构化: TextAggregator 全文本聚合引擎
    - 多模态关联: MultimodalInterleaver 图文交织引擎
    - 标记与格式化: TokenMarker 添加特殊标记
    - Schema 校验: SchemaValidator / LaTeXValidator
    - 资产穿透: AssetAnchoringEngine (Fig/Table → UUID)
    - 数据挖掘: DataMiningMapper 双视图映射
"""

import sys
import os
from typing import Dict, List

if sys.platform == "win32":
    os.environ["PYTHONIOENCODING"] = "utf-8"
    try:
        import subprocess
        subprocess.run(["chcp", "65001"], shell=True, capture_output=True)
    except:
        pass
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    if hasattr(sys.stderr, "reconfigure"):
        sys.stderr.reconfigure(encoding="utf-8")

from .reorganizers.content_filter import ContentFilter, ContentType
from .reorganizers.paragraph_classifier import ParagraphClassifier, ParagraphType
from .reorganizers.token_marker import TokenMarker
from .reorganizers.text_aggregator import TextAggregator
from .reorganizers.multimodal_interleaver import MultimodalInterleaver
from .adapters.content_list_adapter import ContentListAdapter
from .runtime.plugin_system import PluginRegistry
from .validators.schema_validator import SchemaValidator, SchemaValidationResult, SchemaIssue
from .validators.latex_validator import LaTeXValidator, LaTeXValidationResult, FormulaQuality
from .mappers.asset_anchoring import AssetAnchoringEngine
from .mappers.data_mining_mapper import DataMiningMapper, DataMiningView

from . import adapters
from . import mappers
from . import reorganizers
from . import runtime
from . import validators


def aggregate_text(content_list: List[Dict]) -> str:
    """便捷的文本聚合函数

    Args:
        content_list: MinerU解析后的内容列表

    Returns:
        结构化的XML文本

    Example:
        >>> from designer import aggregate_text
        >>> xml_text = aggregate_text(content_list)
    """
    aggregator = TextAggregator()
    return aggregator.aggregate(content_list)


__version__ = "0.1.3"
__all__ = [
    "aggregate_text",

    "ContentFilter",
    "ContentType",
    "ParagraphClassifier",
    "ParagraphType",
    "TokenMarker",
    "TextAggregator",
    "MultimodalInterleaver",
    "ContentListAdapter",
    "PluginRegistry",
    "SchemaValidator",
    "SchemaValidationResult",
    "SchemaIssue",
    "LaTeXValidator",
    "LaTeXValidationResult",
    "FormulaQuality",
    "AssetAnchoringEngine",
    "DataMiningMapper",
    "DataMiningView",
]
