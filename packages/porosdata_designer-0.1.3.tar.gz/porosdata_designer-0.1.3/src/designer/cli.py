from __future__ import annotations

import argparse
from pathlib import Path
from typing import Optional, Sequence

from .runtime.commands import (
    run_final_acceptance_validation,
    run_structured_audit,
    validate_delivery_outputs,
    validate_multimodal_outputs,
    validate_structured_outputs,
)
from .runtime.pipelines import ensure_console_encoding, run_full_pipeline, run_multimodal_pipeline, run_text_pipeline


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="designer", description="PorosData Designer unified command line interface")
    subparsers = parser.add_subparsers(dest="command")

    run_parser = subparsers.add_parser("run", help="run pipeline stages")
    run_subparsers = run_parser.add_subparsers(dest="run_command")
    for name in ("all", "text", "multimodal"):
        cmd = run_subparsers.add_parser(name, help=f"run {name} pipeline")
        cmd.add_argument("--input_dir", type=Path, required=True, help="Input data directory, for example data/Processed Database")
        cmd.add_argument("--output_dir", type=Path, default=None, help="Structured output base directory")
        cmd.add_argument("--log_dir", type=Path, default=None, help="Log directory")

    audit_parser = subparsers.add_parser("audit", help="run audits")
    audit_subparsers = audit_parser.add_subparsers(dest="audit_command")
    audit_structured = audit_subparsers.add_parser("structured", help="audit Designed Database outputs (data/Designed Database)")
    audit_structured.add_argument("--root_dir", type=Path, default=None, help="Designer output root (default: data/Designed Database)")

    validate_parser = subparsers.add_parser("validate", help="run validations")
    validate_subparsers = validate_parser.add_subparsers(dest="validate_command")

    validate_structured = validate_subparsers.add_parser("structured", help="validate *.content.json under each doc_id directory")
    validate_structured.add_argument("--output_dir", type=Path, default=None, help="Designer output root (default: data/Designed Database)")
    validate_structured.add_argument("--log_dir", type=Path, default=None, help="Log directory")

    validate_multimodal = validate_subparsers.add_parser("multimodal", help="validate *.assets.index.json under each doc_id directory")
    validate_multimodal.add_argument("--output_dir", type=Path, default=None, help="Designer output root (default: data/Designed Database)")
    validate_multimodal.add_argument("--log_dir", type=Path, default=None, help="Log directory")

    validate_acceptance = validate_subparsers.add_parser("acceptance", help="run final acceptance validation")
    validate_acceptance.add_argument("--output_dir", type=Path, default=None, help="Designer output root (default: data/Designed Database)")
    validate_acceptance.add_argument("--log_dir", type=Path, default=None, help="Log directory")

    validate_delivery = validate_subparsers.add_parser("delivery", help="validate outputs against delivery standard")
    validate_delivery.add_argument("--root_dir", type=Path, default=None, help="Designer output root (default: data/Designed Database)")
    validate_delivery.add_argument("--log_dir", type=Path, default=None, help="Log directory")
    return parser


def dispatch(args: argparse.Namespace, parser: argparse.ArgumentParser) -> int:
    if args.command == "run":
        if args.run_command == "all":
            return run_full_pipeline(args.input_dir, output_dir=args.output_dir, log_dir=args.log_dir)
        if args.run_command == "text":
            return run_text_pipeline(args.input_dir, output_dir=args.output_dir, log_dir=args.log_dir)
        if args.run_command == "multimodal":
            return run_multimodal_pipeline(args.input_dir, output_dir=args.output_dir, log_dir=args.log_dir)
        run_parser = next(action for action in parser._actions if isinstance(action, argparse._SubParsersAction)).choices["run"]
        run_parser.print_help()
        return 0

    if args.command == "audit":
        if args.audit_command == "structured":
            return run_structured_audit(structured_root=args.root_dir)
        audit_parser = next(action for action in parser._actions if isinstance(action, argparse._SubParsersAction)).choices["audit"]
        audit_parser.print_help()
        return 0

    if args.command == "validate":
        if args.validate_command == "structured":
            return validate_structured_outputs(output_dir=args.output_dir, log_dir=args.log_dir)
        if args.validate_command == "multimodal":
            return validate_multimodal_outputs(output_dir=args.output_dir, log_dir=args.log_dir)
        if args.validate_command == "acceptance":
            return run_final_acceptance_validation(multimodal_dir=args.output_dir, log_dir=args.log_dir)
        if args.validate_command == "delivery":
            return validate_delivery_outputs(structured_root=args.root_dir, log_dir=args.log_dir)
        validate_parser = next(action for action in parser._actions if isinstance(action, argparse._SubParsersAction)).choices["validate"]
        validate_parser.print_help()
        return 0

    parser.print_help()
    return 0


def main(argv: Optional[Sequence[str]] = None) -> int:
    ensure_console_encoding()
    parser = build_parser()
    args = parser.parse_args(argv)
    return dispatch(args, parser)


if __name__ == "__main__":
    raise SystemExit(main())
