# -*- coding: utf-8 -*-
"""
内容列表适配器 (ContentListAdapter) - 数据重组流水线的输入适配组件

详细描述：
    专门处理MinerU输出的content_list.json格式数据，提供标准化的
    数据访问接口。负责文件读取、格式验证和数据预处理。

核心功能:
    - 文件读取: 从JSON文件加载MinerU content_list数据
    - 格式验证: 检查数据结构的完整性和正确性
    - 数据标准化: 统一不同版本MinerU输出的数据格式（含 processed 的 image 优化格式）
    - 错误处理: 完善的异常捕获和错误报告机制

处理格式:
    - 输入: MinerU content_list.json文件路径
    - 输出: 标准化的List[Dict]数据结构
    - 支持类型: text、image、table等MinerU元素类型
    - image: image_caption / image_footnote 支持旧版 [str] 与新版 [{"text": "...", "original_text": "..."}]
"""

import json
from pathlib import Path
from typing import List, Dict
from ..runtime.plugin_system import PluginRegistry


def _normalize_caption_footnote_list(raw_list: List) -> List[str]:
    """将 image_caption 或 image_footnote 的原始列表规范为清理后的文本字符串列表。

    兼容两种格式：
    - 旧版/原始 MinerU：列表元素为 str
    - 新版 processed：列表元素为 dict，含 "text"（清理后）与 "original_text"
    统一返回清理后的文本列表，供下游解析与展示使用。
    """
    if not raw_list:
        return []
    result = []
    for elem in raw_list:
        if isinstance(elem, dict):
            result.append(elem.get("text", "").strip() or "")
        elif isinstance(elem, str):
            result.append(elem.strip())
        else:
            result.append(str(elem).strip())
    return [s for s in result if s]


class ContentListAdapter:
    """content_list.json 适配器"""
    
    @staticmethod
    def load(file_path: str) -> List[Dict]:
        """加载 content_list.json 文件
        
        Args:
            file_path: JSON 文件路径
        
        Returns:
            内容块列表
        """
        with open(file_path, 'r', encoding='utf-8') as f:
            content_list = json.load(f)
        
        # 验证格式（应该是数组）
        if not isinstance(content_list, list):
            raise ValueError(
                f"content_list.json should be a list, got {type(content_list)}"
            )
        
        return content_list

    @staticmethod
    def get_image_caption_texts(image_item: Dict) -> List[str]:
        """从图片项中获取清理后的图注文本列表。

        兼容 processed 优化格式：image_caption 为 [{"text": "...", "original_text": "..."}] 时，
        仅返回 "text" 字段（清理后文本）；旧版 [str] 则原样返回并 strip。

        Args:
            image_item: content_list 中 type=="image" 的项

        Returns:
            清理后的图注字符串列表
        """
        raw = image_item.get("image_caption", [])
        return _normalize_caption_footnote_list(raw)

    @staticmethod
    def get_image_footnote_texts(image_item: Dict) -> List[str]:
        """从图片项中获取清理后的图脚注文本列表。

        格式约定同 get_image_caption_texts。

        Args:
            image_item: content_list 中 type=="image" 的项

        Returns:
            清理后的图脚注字符串列表
        """
        raw = image_item.get("image_footnote", [])
        return _normalize_caption_footnote_list(raw)
    
    @staticmethod
    def save(data: List[Dict], file_path: str) -> None:
        """保存为 content_list.json 格式
        
        Args:
            data: 内容块列表
            file_path: 输出文件路径
        """
        Path(file_path).parent.mkdir(parents=True, exist_ok=True)
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)


@PluginRegistry.register("content_list_adapter")
def load_content_list(file_path: str) -> List[Dict]:
    """content_list.json 适配器"""
    return ContentListAdapter.load(file_path)

