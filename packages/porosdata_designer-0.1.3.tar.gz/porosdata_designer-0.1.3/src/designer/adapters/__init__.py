# -*- coding: utf-8 -*-
"""适配器模块 - 支持多种输入格式"""

from .content_list_adapter import ContentListAdapter

from . import content_list_adapter

__all__ = [
    "ContentListAdapter",
]
