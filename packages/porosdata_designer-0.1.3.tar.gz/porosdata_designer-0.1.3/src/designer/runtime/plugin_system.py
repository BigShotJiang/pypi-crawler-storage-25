# -*- coding: utf-8 -*-
"""
插件注册表 (Plugin Registry) - 插件化架构的核心组件

提供通用的插件/导出器注册、发现和管理机制。
支持通过装饰器或直接调用方式注册处理组件。
"""

import abc
from typing import Dict, Any, Optional, Type, List, Union, BinaryIO
from pathlib import Path
from dataclasses import dataclass

from .config import TAG_PREFIX


@dataclass
class ExportResult:
    """导出结果"""
    format_name: str
    content: Union[str, bytes]
    metadata: Dict[str, Any]
    schema_compliant: bool
    export_duration: float


class BaseExporter(abc.ABC):
    """导出器抽象基类

    所有导出器都必须继承此类，并实现export方法。
    导出器只关注格式转换，不进行数据清洗或内容修改。
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """初始化导出器

        Args:
            config: 导出器配置参数
        """
        self.config = config or {}

    @abc.abstractmethod
    def export(self, document_model: 'DocumentModel') -> ExportResult:
        """导出DocumentModel到目标格式

        Args:
            document_model: 结构化的文档中间表示

        Returns:
            ExportResult: 包含导出内容和元数据的导出结果

        Raises:
            ExportError: 导出失败时抛出
        """
        pass

    @abc.abstractmethod
    def get_schema_requirements(self) -> Dict[str, Any]:
        """返回该导出器对DocumentModel的Schema要求

        Returns:
            Dict: Schema要求规范
        """
        pass

    @abc.abstractmethod
    def get_supported_formats(self) -> List[str]:
        """返回该导出器支持的文件扩展名

        Returns:
            List[str]: 支持的文件扩展名列表
        """
        pass

    def validate_document_model(self, document_model: 'DocumentModel') -> bool:
        """验证DocumentModel是否符合导出要求

        Args:
            document_model: 要验证的文档模型

        Returns:
            bool: 是否符合要求
        """
        requirements = self.get_schema_requirements()

        # 检查必需字段
        for field in requirements.get('required_fields', []):
            if not hasattr(document_model, field) or getattr(document_model, field) is None:
                return False

        # 检查字段类型
        for field, expected_type in requirements.get('field_types', {}).items():
            if hasattr(document_model, field):
                value = getattr(document_model, field)
                if not isinstance(value, expected_type):
                    return False

        return True


class ExporterRegistry:
    """导出器注册表

    采用静态注册模式，确保编译时类型检查和运行时稳定性。
    支持基于DocumentModel的统一导出接口。
    """

    _exporters: Dict[str, Type[BaseExporter]] = {}
    _instances: Dict[str, BaseExporter] = {}
    _plugins: Dict[str, Any] = {}  # 通用插件存储

    @classmethod
    def register(cls, name_or_format: str, exporter_class: Optional[Type[BaseExporter]] = None):
        """注册导出器类或通用插件

        可以作为装饰器使用：
        @ExporterRegistry.register("my_plugin")
        def my_function(): ...

        或者直接调用：
        ExporterRegistry.register("my_format", MyExporterClass)

        Args:
            name_or_format: 插件名称或格式名称
            exporter_class: 导出器类（可选，用于直接调用）

        Returns:
            装饰器函数或注册的对象
        """
        def decorator(obj):
            # 如果是类且继承自BaseExporter，注册为导出器
            if isinstance(obj, type) and issubclass(obj, BaseExporter):
                if name_or_format in cls._exporters:
                    raise ValueError(f"Format '{name_or_format}' is already registered")
                cls._exporters[name_or_format] = obj
            else:
                # 否则注册为通用插件
                if name_or_format in cls._plugins:
                    raise ValueError(f"Plugin '{name_or_format}' is already registered")
                cls._plugins[name_or_format] = obj
            return obj

        # 如果提供了exporter_class参数，直接注册
        if exporter_class is not None:
            return decorator(exporter_class)

        # 否则返回装饰器
        return decorator

    @classmethod
    def get_exporter(cls, format_name: str, config: Optional[Dict[str, Any]] = None) -> BaseExporter:
        """获取导出器实例

        Args:
            format_name: 格式名称
            config: 导出器配置

        Returns:
            BaseExporter: 导出器实例

        Raises:
            ValueError: 如果格式未注册
        """
        if format_name not in cls._exporters:
            raise ValueError(f"Format '{format_name}' is not registered")

        # 缓存实例以提高性能
        cache_key = f"{format_name}_{hash(str(config))}"
        if cache_key not in cls._instances:
            exporter_class = cls._exporters[format_name]
            cls._instances[cache_key] = exporter_class(config)

        return cls._instances[cache_key]

    @classmethod
    def list_formats(cls) -> List[str]:
        """列出所有已注册的格式"""
        return list(cls._exporters.keys())

    @classmethod
    def export(cls, document_model: 'DocumentModel', format_name: str,
              config: Optional[Dict[str, Any]] = None) -> ExportResult:
        """统一导出接口

        Args:
            document_model: 要导出的文档模型
            format_name: 目标格式名称
            config: 导出器配置

        Returns:
            ExportResult: 导出结果

        Raises:
            ValueError: 如果格式未注册
            ExportError: 如果导出失败
        """
        exporter = cls.get_exporter(format_name, config)

        # 验证文档模型
        if not exporter.validate_document_model(document_model):
            raise ValueError(f"DocumentModel does not meet requirements for format '{format_name}'")

        # 执行导出
        return exporter.export(document_model)

    @classmethod
    def batch_export(cls, document_model: 'DocumentModel',
                    formats: List[str],
                    config: Optional[Dict[str, Any]] = None) -> Dict[str, ExportResult]:
        """批量导出到多种格式

        Args:
            document_model: 要导出的文档模型
            formats: 目标格式列表
            config: 导出器配置（适用于所有格式）

        Returns:
            Dict[str, ExportResult]: 格式名到导出结果的映射
        """
        results = {}
        for fmt in formats:
            try:
                results[fmt] = cls.export(document_model, fmt, config)
            except Exception as e:
                # 记录失败但不中断其他格式的导出
                results[fmt] = ExportResult(
                    format_name=fmt,
                    content=b"",
                    metadata={"error": str(e)},
                    schema_compliant=False,
                    export_duration=0.0
                )
        return results

    @classmethod
    def get_format_requirements(cls, format_name: str) -> Dict[str, Any]:
        """获取指定格式的Schema要求

        Args:
            format_name: 格式名称

        Returns:
            Dict: Schema要求规范
        """
        exporter = cls.get_exporter(format_name)
        return exporter.get_schema_requirements()

    @classmethod
    def get_plugin(cls, plugin_name: str) -> Optional[Any]:
        """获取插件

        Args:
            plugin_name: 插件名称

        Returns:
            插件对象，如果不存在则返回None
        """
        return cls._plugins.get(plugin_name)

    @classmethod
    def list_plugins(cls) -> List[str]:
        """列出所有已注册的插件

        Returns:
            List[str]: 插件名称列表
        """
        return list(cls._plugins.keys())


# 保持向后兼容的别名
PluginRegistry = ExporterRegistry


