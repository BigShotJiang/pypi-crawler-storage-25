from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from loguru import logger

from .config import DEFAULT_DESIGNED_OUTPUT_DIR_NAME
from ..mappers.asset_anchoring import AssetAnchoringEngine
from ..mappers.data_mining_mapper import DataMiningMapper
from ..reorganizers.multimodal_interleaver import MultimodalInterleaver
from ..reorganizers.text_aggregator import TextAggregator
from ..validators.schema_validator import SchemaValidator

try:
    from tqdm import tqdm

    HAS_TQDM = True
except ImportError:
    HAS_TQDM = False


def _structure_json_for_write(doc_id: str, structured: Dict[str, Any]) -> Dict[str, Any]:
    """组装写出用的 ``structure.json``：键顺序 ``doc_id`` → ``title`` → ``abstract`` → 其余。

    ``title`` / ``abstract`` 仅在 mapper 产出非空时写入（缺省则不出现该键）。
    """
    out: Dict[str, Any] = {"doc_id": doc_id}
    title = structured.get("title")
    if title:
        out["title"] = title
    abstract = structured.get("abstract")
    if abstract:
        out["abstract"] = abstract
    out["sections"] = structured.get("sections", [])
    out["formulas"] = structured.get("formulas", [])
    out["chemical_formulas"] = structured.get("chemical_formulas", [])
    out["asset_refs"] = structured.get("asset_refs", [])
    return out


def ensure_console_encoding() -> None:
    if sys.platform != "win32":
        return
    os.environ["PYTHONIOENCODING"] = "utf-8"
    try:
        os.system("chcp 65001 >nul 2>&1")
        if hasattr(sys.stdout, "reconfigure"):
            sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        if hasattr(sys.stderr, "reconfigure"):
            sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass


def get_project_root() -> Path:
    current = Path(__file__).resolve()
    for parent in current.parents:
        if (parent / "src").exists() and (parent / "data").exists():
            return parent
    return current.parent.parent.parent


def setup_logging(log_dir: Path, script_name: str) -> None:
    logger.remove()
    logger.add(
        sys.stderr,
        level="INFO",
        format="<green>{time:HH:mm:ss}</green> | <level>{level: <8}</level> | {message}",
        colorize=True,
    )
    log_dir.mkdir(parents=True, exist_ok=True)
    logger.add(
        log_dir / f"{script_name}_{{time:YYYY-MM-DD}}.log",
        level="DEBUG",
        format="{time:YYYY-MM-DD HH:mm:ss.SSS} | {level: <8} | {name}:{function}:{line} | {message}",
        rotation="10 MB",
        retention="7 days",
        encoding="utf-8",
    )


class PorosTextStandardizer:
    """文本标准化 pipeline（新契约单文档聚合输出）。

    所有产物统一落到 ``{output_root}/{doc_id}/`` 下：

    - ``{doc_id}.content.json``   : 含 Poros 标签的结构感知训练视图 + pure_text_stream
    - ``{doc_id}.content.txt``    : 人类可读的结构化文本
    - ``{doc_id}.structure.json`` : 数据挖掘视图（title/abstract/sections/chemical_formulas/...
    ``output_root`` 默认为 ``data/Designed Database``。
    """

    def __init__(self, input_base: Path, enable_asset_anchoring: bool = True, output_dir: Optional[Path] = None):
        project_root = get_project_root()
        self.aggregator = TextAggregator()
        self.asset_engine = AssetAnchoringEngine()
        self.schema_validator = SchemaValidator()
        self.data_mining_mapper = DataMiningMapper()
        self.enable_asset_anchoring = enable_asset_anchoring
        self.input_base = Path(input_base).resolve()
        self.output_base = Path(output_dir).resolve() if output_dir else project_root / "data" / DEFAULT_DESIGNED_OUTPUT_DIR_NAME
        self.output_base.mkdir(parents=True, exist_ok=True)
        self.stats = {
            "total_files": 0,
            "processed_files": 0,
            "failed_files": 0,
            "start_time": None,
            "end_time": None,
            "errors": [],
        }

    def validate_environment(self) -> Optional[List[Tuple[str, Path]]]:
        if not self.input_base.exists():
            logger.error("Input directory does not exist: {}", self.input_base)
            return None
        content_files = self._find_content_list_files()
        if not content_files:
            logger.error("No content_list.json files found under {}", self.input_base)
            logger.error("Please make sure MinerU processing has completed and produced valid outputs")
            return None
        return content_files

    def _find_content_list_files(self) -> List[Tuple[str, Path]]:
        content_files: List[Tuple[str, Path]] = []
        if not self.input_base.exists():
            return content_files
        for content_file in self.input_base.rglob("*_content_list.json"):
            if content_file.is_file():
                doc_id = content_file.stem.replace("_content_list", "")
                content_files.append((doc_id, content_file))
        return content_files

    def process_single_document(self, doc_id: str, content_file: Path) -> bool:
        try:
            content_list = json.loads(content_file.read_text(encoding="utf-8"))
            aggregated_text = self.aggregator.aggregate(content_list)
            if self.enable_asset_anchoring:
                registry = self.asset_engine.build_asset_registry(content_list, doc_id)
                aggregated_text, _ = self.asset_engine.anchor_text(aggregated_text, registry)

            schema_result = self.schema_validator.validate(aggregated_text)
            if not schema_result.is_valid:
                for issue in schema_result.get_errors():
                    logger.warning("Schema validation: doc={} {}", doc_id, issue.message)

            doc_output_dir = self.output_base / doc_id
            doc_output_dir.mkdir(parents=True, exist_ok=True)
            dm_view = self.data_mining_mapper.map(aggregated_text, {"doc_id": doc_id})

            content_json_file = doc_output_dir / f"{doc_id}.content.json"
            content_json_file.write_text(
                json.dumps(
                    {
                        "doc_id": doc_id,
                        "content": aggregated_text.split("\n"),
                        "pure_text_stream": dm_view.pure_text_stream.split("\n"),
                    },
                    ensure_ascii=False,
                    indent=2,
                ),
                encoding="utf-8",
            )

            content_txt_file = doc_output_dir / f"{doc_id}.content.txt"
            content_txt_file.write_text(
                f"Document ID: {doc_id}\n" + "=" * 50 + "\n" + aggregated_text,
                encoding="utf-8",
            )

            structure_file = doc_output_dir / f"{doc_id}.structure.json"
            structure_data = _structure_json_for_write(doc_id, dm_view.structured_json)
            for ref_obj in structure_data.get("asset_refs", []):
                atype = ref_obj.get("type", "fig")
                aref = ref_obj.get("ref", "")
                # 新契约：资产链接相对 doc 输出目录（images/{type}_{ref}.jpg）
                ref_obj["link"] = f"images/{atype}_{aref}.jpg"
            structure_file.write_text(
                json.dumps(structure_data, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
            return True
        except Exception as exc:
            error_msg = f"Error processing document {doc_id}: {exc}"
            self.stats["errors"].append(error_msg)
            logger.error("{}", error_msg)
            return False

    def run_standardization(self) -> None:
        content_files = self.validate_environment()
        if content_files is None:
            return
        self.stats["total_files"] = len(content_files)
        self.stats["start_time"] = time.time()
        logger.info("full_text: {} docs -> {}", len(content_files), self.output_base)

        if not HAS_TQDM:
            logger.warning("tqdm is not installed; falling back to simple progress output")

        progress_bar = None
        processed = 0
        if HAS_TQDM:
            progress_bar = tqdm(
                total=len(content_files),
                desc="Processing",
                unit="doc",
                bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}]",
            )

        for doc_id, content_file in content_files:
            success = self.process_single_document(doc_id, content_file)
            if success:
                self.stats["processed_files"] += 1
                status = "OK"
            else:
                self.stats["failed_files"] += 1
                status = "FAIL"
            if progress_bar is not None:
                progress_bar.set_postfix(
                    {"doc": doc_id, "status": status, "success": self.stats["processed_files"], "failed": self.stats["failed_files"]}
                )
                progress_bar.update(1)
            else:
                processed += 1
                logger.info("[{}/{}] {} {}", processed, len(content_files), status, doc_id)

        if progress_bar is not None:
            progress_bar.close()

        self.stats["end_time"] = time.time()
        duration = self.stats["end_time"] - self.stats["start_time"]
        n = self.stats["total_files"]
        ok = self.stats["processed_files"]
        rate = (ok / max(1, n)) * 100
        speed = n / duration if duration > 0 else 0
        logger.info("full_text: {}/{} ok ({:.0f}%), {:.2f}s, {:.1f} docs/s", ok, n, rate, duration, speed)
        if self.stats["errors"]:
            for i, error in enumerate(self.stats["errors"][:5], 1):
                logger.error("Error {}: {}", i, error)


class PorosMultimodalExtractor:
    """多模态资产抽取 pipeline（新契约单文档聚合输出）。

    输出与 :class:`PorosTextStandardizer` 共用同一 ``{output_root}/{doc_id}/`` 目录：

    - ``{doc_id}.assets.index.json`` : 多模态资产索引
    - ``images/fig_*.jpg``           : 图片资产
    - ``images/fig_*.md``            : 每图 Markdown 说明
    """

    def __init__(self, input_base: Path, output_dir: Optional[Path] = None):
        project_root = get_project_root()
        self.interleaver = MultimodalInterleaver()
        self.input_base = Path(input_base).resolve()
        self.output_base = Path(output_dir).resolve() if output_dir else project_root / "data" / DEFAULT_DESIGNED_OUTPUT_DIR_NAME
        self.output_base.mkdir(parents=True, exist_ok=True)
        self.stats = {
            "total_files": 0,
            "processed_files": 0,
            "failed_files": 0,
            "total_images": 0,
            "images_with_captions": 0,
            "images_with_mentions": 0,
            "start_time": None,
            "end_time": None,
            "errors": [],
        }

    def validate_environment(self) -> Optional[List[Tuple[str, Path]]]:
        if not self.input_base.exists():
            logger.error("Input directory does not exist: {}", self.input_base)
            return None
        content_files = self._find_content_list_files()
        if not content_files:
            logger.error("No content_list.json files found under {}", self.input_base)
            logger.error("Please make sure MinerU processing has completed and produced valid outputs")
            return None
        return content_files

    def _find_content_list_files(self) -> List[Tuple[str, Path]]:
        content_files: List[Tuple[str, Path]] = []
        if not self.input_base.exists():
            return content_files
        for content_file in self.input_base.rglob("*_content_list.json"):
            if content_file.is_file():
                doc_id = content_file.stem.replace("_content_list", "")
                content_files.append((doc_id, content_file))
        return content_files

    def process_single_document(self, doc_id: str, content_file: Path) -> bool:
        try:
            content_list = json.loads(content_file.read_text(encoding="utf-8"))
            doc_output_dir = self.output_base / doc_id
            doc_output_dir.mkdir(parents=True, exist_ok=True)
            multimodal_items = self.interleaver.interleave(
                content_list=content_list,
                output_dir=str(doc_output_dir),
                doc_id=doc_id,
                content_list_path=content_file.resolve(),
            )
            index_file = doc_output_dir / f"{doc_id}.assets.index.json"
            index_file.write_text(json.dumps(multimodal_items, indent=2, ensure_ascii=False), encoding="utf-8")
            images_count = len(multimodal_items)
            captions_count = sum(1 for item in multimodal_items if item.get("caption"))
            mentions_count = sum(1 for item in multimodal_items if item.get("mentions"))
            self.stats["total_images"] += images_count
            self.stats["images_with_captions"] += captions_count
            self.stats["images_with_mentions"] += mentions_count
            return True
        except Exception as exc:
            error_msg = f"Error processing document {doc_id}: {exc}"
            self.stats["errors"].append(error_msg)
            logger.error("{}", error_msg)
            return False

    def run_extraction(self) -> None:
        content_files = self.validate_environment()
        if content_files is None:
            return
        self.stats["total_files"] = len(content_files)
        self.stats["start_time"] = time.time()
        logger.info("multimodal: {} docs -> {}", len(content_files), self.output_base)

        if not HAS_TQDM:
            logger.warning("tqdm is not installed; falling back to simple progress output")

        progress_bar = None
        processed = 0
        if HAS_TQDM:
            progress_bar = tqdm(
                total=len(content_files),
                desc="Processing",
                unit="doc",
                bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}]",
            )

        for doc_id, content_file in content_files:
            success = self.process_single_document(doc_id, content_file)
            if success:
                self.stats["processed_files"] += 1
                status = "OK"
            else:
                self.stats["failed_files"] += 1
                status = "FAIL"
            if progress_bar is not None:
                progress_bar.set_postfix(
                    {
                        "doc": doc_id,
                        "status": status,
                        "images": self.stats["total_images"],
                        "success": self.stats["processed_files"],
                        "failed": self.stats["failed_files"],
                    }
                )
                progress_bar.update(1)
            else:
                processed += 1
                logger.info("[{}/{}] {} {} ({} images)", processed, len(content_files), status, doc_id, self.stats["total_images"])

        if progress_bar is not None:
            progress_bar.close()

        self.stats["end_time"] = time.time()
        duration = self.stats["end_time"] - self.stats["start_time"]
        n = self.stats["total_files"]
        ok = self.stats["processed_files"]
        rate = (ok / max(1, n)) * 100
        speed = n / duration if duration > 0 else 0
        imgs = self.stats["total_images"]
        logger.info("multimodal: {}/{} ok ({:.0f}%), {} images, {:.2f}s, {:.1f} docs/s", ok, n, rate, imgs, duration, speed)
        if self.stats["errors"]:
            for i, error in enumerate(self.stats["errors"][:5], 1):
                logger.error("Error {}: {}", i, error)


def run_text_pipeline(input_dir: Path, output_dir: Optional[Path] = None, log_dir: Optional[Path] = None) -> int:
    ensure_console_encoding()
    project_root = get_project_root()
    setup_logging(Path(log_dir).resolve() if log_dir else project_root / "logs", "run_text_standardization")
    try:
        PorosTextStandardizer(input_base=Path(input_dir).resolve(), output_dir=output_dir).run_standardization()
        return 0
    except KeyboardInterrupt:
        logger.warning("Processing interrupted by user")
        return 130
    except Exception as exc:
        logger.exception("An error occurred during processing: {}", exc)
        return 1


def run_multimodal_pipeline(input_dir: Path, output_dir: Optional[Path] = None, log_dir: Optional[Path] = None) -> int:
    ensure_console_encoding()
    project_root = get_project_root()
    setup_logging(Path(log_dir).resolve() if log_dir else project_root / "logs", "run_multimodal_extraction")
    try:
        PorosMultimodalExtractor(input_base=Path(input_dir).resolve(), output_dir=output_dir).run_extraction()
        return 0
    except KeyboardInterrupt:
        logger.warning("Processing interrupted by user")
        return 130
    except Exception as exc:
        logger.exception("An error occurred during processing: {}", exc)
        return 1


def run_full_pipeline(input_dir: Path, output_dir: Optional[Path] = None, log_dir: Optional[Path] = None) -> int:
    ensure_console_encoding()
    project_root = get_project_root()
    setup_logging(Path(log_dir).resolve() if log_dir else project_root / "logs", "run_all")
    input_base = Path(input_dir).resolve()
    resolved_output_dir = Path(output_dir).resolve() if output_dir else None
    try:
        logger.info(
            "PorosData Designer: {} -> {} (unified doc layout)",
            input_base,
            resolved_output_dir or f"data/{DEFAULT_DESIGNED_OUTPUT_DIR_NAME}/",
        )
        PorosTextStandardizer(input_base=input_base, output_dir=resolved_output_dir).run_standardization()
        PorosMultimodalExtractor(input_base=input_base, output_dir=resolved_output_dir).run_extraction()
        logger.info("Done.")
        return 0
    except KeyboardInterrupt:
        logger.warning("Processing interrupted by user")
        return 130
    except Exception as exc:
        logger.exception("Execution failed: {}", exc)
        return 1
