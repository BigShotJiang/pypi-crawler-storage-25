from __future__ import annotations

import json
import random
import re
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from loguru import logger

from ..mappers.data_mining_mapper import is_valid_chemical_formula_candidate
from ..runtime.config import DEFAULT_DESIGNED_OUTPUT_DIR_NAME, NON_CHEMICAL_ABBREVIATIONS, TAG_PREFIX, TRAINING_CONFIG
from ..validators.latex_validator import LaTeXValidator
from ..validators.schema_validator import SchemaValidator
from .pipelines import get_project_root, setup_logging


@dataclass
class AuditResult:
    passed: bool
    category: str
    message: str
    details: List[str] = field(default_factory=list)


def _normalize_token(token: str) -> str:
    token = re.sub(r"\\[a-zA-Z]+\{([^}]+)\}", r"\1", token)
    token = token.strip().strip("$").replace("{", "").replace("}", "")
    token = re.sub(r"[^A-Za-z0-9.\-]+", "", token)
    return token.upper()


def _audit_full_text_schema(content: str) -> List[AuditResult]:
    validator = SchemaValidator()
    schema_result = validator.validate(content)
    if schema_result.is_valid:
        return [AuditResult(True, "Schema", "Tag closure and nesting validation passed")]
    errors = schema_result.get_errors()
    warnings = schema_result.get_warnings()
    details = [f"  - {issue.message}" for issue in errors] + [f"  [W] {issue.message}" for issue in warnings]
    return [AuditResult(len(errors) == 0, "Schema", f"Found {len(errors)} errors and {len(warnings)} warnings", details[:15])]


def _audit_full_text_latex(content: str) -> List[AuditResult]:
    validator = LaTeXValidator()
    latex_result = validator.validate_text(content)
    if latex_result.is_balanced:
        return [AuditResult(True, "LaTeX", "Formula $ delimiters are balanced")]
    details = [f"  - {issue.message}" for issue in latex_result.issues]
    low_quality = validator.should_mark_low_quality(latex_result)
    return [AuditResult(False, "LaTeX", f"Formula delimiters unbalanced (quality={latex_result.quality.name}), low={low_quality}", details)]


def _audit_full_text_eos(content: str) -> List[AuditResult]:
    eos = TRAINING_CONFIG.get("eos_token", "</s>")
    if content.strip().endswith(eos):
        return [AuditResult(True, "EOS", f"Document ends with {eos}")]
    suffix = repr(content[-50:]) if len(content) > 50 else repr(content)
    return [AuditResult(False, "EOS", f"Missing {eos}; suffix={suffix}")]


def _audit_full_text_prefix(content: str) -> List[AuditResult]:
    has_root = f"<{TAG_PREFIX}doc>" in content and f"</{TAG_PREFIX}doc>" in content
    if has_root:
        return [AuditResult(True, "TagPrefix", f"Root tag <{TAG_PREFIX}doc> present")]
    return [AuditResult(False, "TagPrefix", f"Missing root tag <{TAG_PREFIX}doc>")]


def _audit_content_structure(content: str) -> List[AuditResult]:
    results: List[AuditResult] = []
    opens = re.findall(rf"<{TAG_PREFIX}section_(\w+)>", content)
    closes = re.findall(rf"</{TAG_PREFIX}section_(\w+)>", content)
    if opens and len(opens) == len(closes):
        results.append(AuditResult(True, "ContentView", f"content has {len(opens)} sections, all closed"))
    elif not opens:
        results.append(AuditResult(False, "ContentView", "content has no poros_section_* tags"))
    else:
        results.append(AuditResult(False, "ContentView", f"Section open/close mismatch: {len(opens)} vs {len(closes)}"))

    singleton_types = {"abstract", "conclusion", "references", "acknowledgements"}
    dup = {key: value for key, value in Counter(opens).items() if value > 1 and key in singleton_types}
    if dup:
        results.append(
            AuditResult(False, "ContentView", f"Singleton section duplicated: {list(dup.keys())}", [f"  {key}: {value}x" for key, value in dup.items()])
        )
    return results


def _audit_tag_density(content: str) -> List[AuditResult]:
    tag_chars = sum(len(match.group(0)) for match in re.finditer(rf"</?{TAG_PREFIX}[^>]*>", content))
    total = len(content)
    if total == 0:
        return [AuditResult(False, "TagDensity", "content is empty")]
    ratio = tag_chars / total
    return [AuditResult(ratio <= 0.25, "TagDensity", f"Tag density {ratio:.1%} {'OK' if ratio <= 0.25 else '> 25%'}")]


def _audit_content_json(json_path: Path) -> List[AuditResult]:
    required = ["doc_id", "content", "pure_text_stream"]
    try:
        obj = json.loads(json_path.read_text(encoding="utf-8"))
    except Exception as exc:
        return [AuditResult(False, "ContentJSON", f"Parse error: {exc}")]

    results: List[AuditResult] = []
    missing = [key for key in required if key not in obj]
    if missing:
        results.append(AuditResult(False, "ContentJSON", f"Missing fields: {missing}"))
    else:
        results.append(AuditResult(True, "ContentJSON", f"Required fields present: {required}"))

    pts = obj.get("pure_text_stream", "")
    if isinstance(pts, list):
        pts = "\n".join(pts)
    tag_hits = re.findall(rf"</?{TAG_PREFIX}\w+[^>]*>", pts)
    if tag_hits:
        results.append(AuditResult(False, "PureTextView", f"pure_text_stream still has {len(tag_hits)} poros_* tags", [f"  {tag}" for tag in tag_hits[:10]]))
    else:
        results.append(AuditResult(True, "PureTextView", "pure_text_stream is tag-free"))
    return results


def _audit_structure(structure_path: Path) -> List[AuditResult]:
    """审计 ``{doc_id}.structure.json``。

    新契约下原来独立的 ``*_formulas.json`` 已合并为 ``formulas`` 字段；
    本函数不再接受单独的 formulas 文件路径。
    """
    required = ["doc_id", "title", "sections"]
    try:
        obj = json.loads(structure_path.read_text(encoding="utf-8"))
    except Exception as exc:
        return [AuditResult(False, "StructureJSON", f"Parse error: {exc}")]

    results: List[AuditResult] = []
    missing = [key for key in required if key not in obj]
    if missing:
        results.append(AuditResult(False, "StructureJSON", f"Missing fields: {missing}"))
    else:
        results.append(AuditResult(True, "StructureJSON", "Required fields present"))

    sections = obj.get("sections", [])
    if sections:
        results.append(AuditResult(True, "StructuredView", f"sections has {len(sections)} entries"))
    else:
        results.append(AuditResult(False, "StructuredView", "sections is empty"))

    blank_titles = [section.get("section_type", "?") for section in sections if not section.get("title", "").strip()]
    if blank_titles:
        results.append(
            AuditResult(False, "BlankTitle", f"{len(blank_titles)} sections have blank titles", [f"  type={title}" for title in blank_titles[:10]])
        )
    else:
        results.append(AuditResult(True, "BlankTitle", "All sections have non-blank titles"))

    legacy_generic_types = [
        section.get("section_type", "") for section in sections
        if (section.get("section_type") or "").lower() == "section"
    ]
    if legacy_generic_types:
        results.append(
            AuditResult(
                False,
                "SectionTaxonomy",
                f"{len(legacy_generic_types)} sections still use legacy generic type 'section'; expected 'other'",
                [f"  legacy section_type='{t}'" for t in legacy_generic_types[:10]],
            )
        )
    else:
        results.append(AuditResult(True, "SectionTaxonomy", "No legacy 'section' section_type"))

    chem = obj.get("chemical_formulas", [])
    flagged: List[str] = []
    for formula in chem:
        norm = _normalize_token(formula)
        if norm in NON_CHEMICAL_ABBREVIATIONS or not is_valid_chemical_formula_candidate(formula):
            flagged.append(formula)
    if flagged:
        results.append(AuditResult(False, "ChemNoise", f"chemical_formulas has {len(flagged)} noise items", [f"  {item}" for item in flagged[:10]]))
    else:
        results.append(AuditResult(True, "ChemNoise", "chemical_formulas is clean"))

    formulas = obj.get("formulas", [])
    if not isinstance(formulas, list):
        results.append(AuditResult(False, "Formulas", "'formulas' field should be a list"))
        formulas = []
    else:
        results.append(AuditResult(True, "Formulas", f"formulas list has {len(formulas)} items"))

    truncated = [formula for formula in formulas if re.search(r"[-–]\s*\$?\s*$", formula)]
    if truncated:
        results.append(
            AuditResult(False, "TruncatedFormula", f"formulas has {len(truncated)} truncated items", [f"  {item}" for item in truncated[:10]])
        )
    else:
        results.append(AuditResult(True, "TruncatedFormula", "No truncated formulas found"))
    return results


def _audit_multimodal(doc_dir: Path, doc_id: str) -> List[AuditResult]:
    """审计单文档聚合布局下的多模态产物。

    新契约：
    - 资产索引：``{doc_dir}/{doc_id}.assets.index.json``
    - 图片与每图 Markdown 同目录：``{doc_dir}/images/fig_*.{jpg,md}``
    """
    index_path = doc_dir / f"{doc_id}.assets.index.json"
    if not index_path.exists():
        return [AuditResult(False, "Multimodal", f"Missing {doc_id}.assets.index.json")]

    try:
        items = json.loads(index_path.read_text(encoding="utf-8"))
    except Exception as exc:
        return [AuditResult(False, "Multimodal", f"Parse error: {exc}")]

    if not isinstance(items, list):
        return [AuditResult(False, "Multimodal", "Index should be a JSON array")]

    results: List[AuditResult] = []
    required_per_item = ["image_path", "fig_id", "caption", "mentions", "metadata", "asset_copied", "markdown_file"]
    missing_any = False
    images_dir = doc_dir / "images"
    asset_missing: List[str] = []
    markdown_missing: List[str] = []
    for idx, item in enumerate(items):
        missing = [key for key in required_per_item if key not in item]
        if missing:
            results.append(AuditResult(False, "Multimodal", f"Item {idx + 1} missing: {missing}"))
            missing_any = True
        image_path = item.get("image_path")
        if image_path:
            asset_path = doc_dir / Path(image_path)
            if not asset_path.exists():
                asset_missing.append(f"item {idx + 1}: {image_path}")
        markdown_file = item.get("markdown_file")
        if markdown_file:
            markdown_path = doc_dir / Path(markdown_file)
            if not markdown_path.exists():
                markdown_missing.append(f"item {idx + 1}: {markdown_file}")
    if not missing_any:
        results.append(AuditResult(True, "Multimodal", f"Index has {len(items)} items, schema OK"))

    total = len(items)
    if total == 0:
        results.append(AuditResult(True, "Assets", "No image items"))
    else:
        if not images_dir.exists():
            results.append(AuditResult(False, "Assets", f"images dir missing for {total} items"))
        else:
            copied = sum(1 for item in items if item.get("asset_copied"))
            results.append(AuditResult(copied == total, "Assets", f"Image copies: {copied}/{total}"))
    if asset_missing:
        results.append(AuditResult(False, "Assets", f"{len(asset_missing)} asset files referenced but missing", [f"  {item}" for item in asset_missing[:10]]))
    else:
        results.append(AuditResult(True, "Assets", "All referenced asset files exist"))
    if markdown_missing:
        results.append(AuditResult(False, "Markdown", f"{len(markdown_missing)} markdown files referenced but missing", [f"  {item}" for item in markdown_missing[:10]]))
    else:
        results.append(AuditResult(True, "Markdown", "All referenced markdown files exist"))
    return results


def build_structured_audit_report(root: Path) -> Dict[str, Any]:
    """审计新契约的单文档聚合输出。

    期望目录结构：

    ```
    {root}/
      00001/
        00001.structure.json
        00001.content.json
        00001.content.txt
        00001.assets.index.json
        images/
          fig_1.jpg
          fig_1.md
          ...
    ```
    """
    report: Dict[str, Any] = {
        "summary": {
            "total_docs": 0,
            "passed": 0,
            "failed": 0,
            "warnings": 0,
            "docs_passed": 0,
            "docs_failed": 0,
        },
        "by_doc": {},
    }
    if not root.exists():
        report["by_doc"]["_error"] = f"root directory does not exist: {root}"
        return report

    doc_dirs = [directory for directory in sorted(root.iterdir()) if directory.is_dir()]
    # 过滤非 doc 目录（例如旧版 full_text/datamining/multimodal 子树），
    # 只保留包含 ``*.content.*`` 或 ``*.structure.json`` 的目录。
    doc_dirs = [
        directory for directory in doc_dirs
        if any(directory.glob("*.content.json"))
        or any(directory.glob("*.structure.json"))
        or any(directory.glob("*.assets.index.json"))
    ]
    report["summary"]["total_docs"] = len(doc_dirs)
    for doc_dir in doc_dirs:
        doc_id = doc_dir.name
        doc_results: List[AuditResult] = []

        txt_path = doc_dir / f"{doc_id}.content.txt"
        if txt_path.exists():
            content = txt_path.read_text(encoding="utf-8")
            if "==================================================\n" in content:
                content = content.split("==================================================\n", 1)[-1]
            doc_results.extend(_audit_full_text_schema(content))
            doc_results.extend(_audit_full_text_latex(content))
            doc_results.extend(_audit_full_text_eos(content))
            doc_results.extend(_audit_full_text_prefix(content))
            doc_results.extend(_audit_content_structure(content))
            doc_results.extend(_audit_tag_density(content))
        else:
            doc_results.append(AuditResult(False, "File", f"Missing {doc_id}.content.txt"))

        json_path = doc_dir / f"{doc_id}.content.json"
        if json_path.exists():
            doc_results.extend(_audit_content_json(json_path))
        else:
            doc_results.append(AuditResult(False, "File", f"Missing {doc_id}.content.json"))

        structure_path = doc_dir / f"{doc_id}.structure.json"
        if structure_path.exists():
            doc_results.extend(_audit_structure(structure_path))
        else:
            doc_results.append(AuditResult(False, "File", f"Missing {doc_id}.structure.json"))

        doc_results.extend(_audit_multimodal(doc_dir, doc_id))

        report["by_doc"][doc_id] = []
        doc_failed = False
        for result in doc_results:
            entry = {"category": result.category, "passed": result.passed, "message": result.message, "details": result.details}
            report["by_doc"][doc_id].append(entry)
            report["summary"]["passed" if result.passed else "failed"] += 1
            if not result.passed:
                doc_failed = True
        report["summary"]["docs_failed" if doc_failed else "docs_passed"] += 1
    return report


def print_structured_audit_report(report: Dict[str, Any]) -> None:
    print("\n" + "=" * 70)
    print("structured audit report (ai_ready_and_datamining_designer)")
    print("=" * 70)
    summary = report["summary"]
    print(f"Total documents: {summary['total_docs']}")
    print(f"Documents passed: {summary['docs_passed']}  Documents failed: {summary['docs_failed']}")
    print(f"Passed: {summary['passed']}  Failed: {summary['failed']}")
    print("-" * 70)
    for doc_id, results in report.get("by_doc", {}).items():
        if not isinstance(results, list):
            continue
        failed = [result for result in results if not result.get("passed")]
        if failed:
            print(f"\n【{doc_id}】 — {len(failed)} FAILED")
            for result in failed:
                print(f"  ✗ [{result['category']}] {result['message']}")
                for detail in result.get("details", [])[:5]:
                    print(f"      {detail}")
        else:
            print(f"  【{doc_id}】 ALL PASSED")
    print("\n" + "=" * 70)


def run_structured_audit(structured_root: Optional[Path] = None) -> int:
    root = (
        Path(structured_root).resolve()
        if structured_root
        else get_project_root() / "data" / DEFAULT_DESIGNED_OUTPUT_DIR_NAME
    )
    if not root.exists():
        print(f"Error: {root} does not exist")
        return 1
    report = build_structured_audit_report(root)
    print_structured_audit_report(report)
    report_path = root / "audit_report.json"
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"\nReport saved to: {report_path}")
    return 0 if report["summary"]["failed"] == 0 else 1


def validate_delivery_outputs(structured_root: Optional[Path] = None, log_dir: Optional[Path] = None) -> int:
    project_root = get_project_root()
    log_root = Path(log_dir).resolve() if log_dir else project_root / "logs"
    setup_logging(log_root, "validate_delivery_output")
    root = (
        Path(structured_root).resolve()
        if structured_root
        else project_root / "data" / DEFAULT_DESIGNED_OUTPUT_DIR_NAME
    )
    if not root.exists():
        logger.error("Structured root does not exist: {}", root)
        return 1

    report = build_structured_audit_report(root)
    report_path = log_root / "delivery_acceptance_report.json"
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")

    summary = report["summary"]
    logger.info("Delivery validation completed for {} documents", summary["total_docs"])
    logger.info("Documents passed: {}  failed: {}", summary["docs_passed"], summary["docs_failed"])
    logger.info("Checks passed: {}  failed: {}", summary["passed"], summary["failed"])
    logger.info("Report saved to: {}", report_path)

    if summary["docs_failed"] == 0:
        logger.info("Delivery validation passed")
        return 0

    for doc_id, results in report.get("by_doc", {}).items():
        failed = [result for result in results if not result.get("passed")]
        if failed:
            logger.error("{} failed {} checks", doc_id, len(failed))
            for result in failed[:5]:
                logger.error("  [{}] {}", result["category"], result["message"])
    logger.error("Delivery validation failed")
    return 1


def _validate_structured_file(filepath: Path) -> Dict[str, Any]:
    result = {"filename": filepath.name, "valid": True, "errors": [], "stats": {}}
    try:
        data = json.loads(filepath.read_text(encoding="utf-8"))
        for field in ["doc_id", "content", "pure_text_stream"]:
            if field not in data:
                result["valid"] = False
                result["errors"].append(f"Missing required field: {field}")
        if not result["valid"]:
            return result
        content = data["content"]
        pure_text_stream = data["pure_text_stream"]
        if not isinstance(content, list):
            result["valid"] = False
            result["errors"].append("Field 'content' should be a list of lines")
            return result
        if not isinstance(pure_text_stream, list):
            result["valid"] = False
            result["errors"].append("Field 'pure_text_stream' should be a list of lines")
            return result
        text = "\n".join(content).strip()
        pure_text = "\n".join(pure_text_stream).strip()
        result["stats"]["text_length"] = len(text)
        result["stats"]["pure_text_length"] = len(pure_text)
        if not text.endswith("</s>"):
            result["valid"] = False
            result["errors"].append("Structured content does not end with </s>")
        if "<poros_doc>" not in text or "</poros_doc>" not in text:
            result["valid"] = False
            result["errors"].append("Missing <poros_doc> wrapper tags")
        if "<br>" in text:
            result["valid"] = False
            result["errors"].append("Contains residual <br> tags")
        if not pure_text:
            result["valid"] = False
            result["errors"].append("pure_text_stream is empty")
    except json.JSONDecodeError as exc:
        result["valid"] = False
        result["errors"].append(f"JSON parse error: {exc}")
    except Exception as exc:
        result["valid"] = False
        result["errors"].append(f"File processing error: {exc}")
    return result


def validate_structured_outputs(output_dir: Optional[Path] = None, log_dir: Optional[Path] = None) -> int:
    project_root = get_project_root()
    setup_logging(Path(log_dir).resolve() if log_dir else project_root / "logs", "validate_structured_output")
    resolved_output_dir = (
        Path(output_dir).resolve()
        if output_dir
        else project_root / "data" / DEFAULT_DESIGNED_OUTPUT_DIR_NAME
    )
    if not resolved_output_dir.exists():
        logger.error("Output directory does not exist: {}", resolved_output_dir)
        return 1
    # 新契约：每个 doc 目录下都存在 ``{doc_id}.content.json``
    json_files = list(resolved_output_dir.glob("*/*.content.json"))
    if not json_files:
        logger.error("No structured output files found (*/*.content.json)")
        return 1
    logger.info("Found {} files to validate", len(json_files))
    logger.info("=" * 60)
    valid_files = 0
    all_errors: List[str] = []
    for filepath in sorted(json_files):
        result = _validate_structured_file(filepath)
        if result["valid"]:
            valid_files += 1
            logger.info("✓ {}", result["filename"])
        else:
            logger.error("✗ {}", result["filename"])
            for err in result["errors"]:
                logger.error("  - {}", err)
                all_errors.append(err)
    total_files = len(json_files)
    logger.info("=" * 60)
    logger.info("Validation complete: {}/{} files are valid", valid_files, total_files)
    if valid_files == total_files:
        logger.info("All files passed validation")
        return 0
    logger.error("{} files have validation issues", total_files - valid_files)
    for err in sorted(set(all_errors)):
        logger.error("- {}", err)
    return 1


def _validate_index_file(filepath: Path) -> Dict[str, Any]:
    result = {"filename": filepath.name, "doc_id": filepath.parent.name, "valid": True, "errors": [], "stats": {"total_images": 0, "with_captions": 0, "with_mentions": 0}}
    try:
        items = json.loads(filepath.read_text(encoding="utf-8"))
        if not isinstance(items, list):
            result["valid"] = False
            result["errors"].append("Index should be a JSON array")
            return result
        result["stats"]["total_images"] = len(items)
        required_fields = ["fig_id", "caption", "mentions"]
        for idx, item in enumerate(items):
            if not isinstance(item, dict):
                result["valid"] = False
                result["errors"].append(f"Item {idx + 1} is not an object")
                continue
            for field in required_fields:
                if field not in item:
                    result["valid"] = False
                    result["errors"].append(f"Item {idx + 1} is missing field: {field}")
            if not isinstance(item.get("mentions", []), list):
                result["valid"] = False
                result["errors"].append(f"Item {idx + 1} mentions should be a list")
            if item.get("caption"):
                result["stats"]["with_captions"] += 1
            if item.get("mentions") and len(item["mentions"]) > 0:
                result["stats"]["with_mentions"] += 1
    except json.JSONDecodeError as exc:
        result["valid"] = False
        result["errors"].append(f"JSON parse error: {exc}")
    except Exception as exc:
        result["valid"] = False
        result["errors"].append(f"File processing error: {exc}")
    return result


def validate_multimodal_outputs(output_dir: Optional[Path] = None, log_dir: Optional[Path] = None) -> int:
    project_root = get_project_root()
    setup_logging(Path(log_dir).resolve() if log_dir else project_root / "logs", "validate_multimodal_output")
    resolved_output_dir = (
        Path(output_dir).resolve()
        if output_dir
        else project_root / "data" / DEFAULT_DESIGNED_OUTPUT_DIR_NAME
    )
    if not resolved_output_dir.exists():
        logger.error("Output directory does not exist: {}", resolved_output_dir)
        return 1
    index_files = [
        doc_dir / f"{doc_dir.name}.assets.index.json"
        for doc_dir in sorted(resolved_output_dir.iterdir())
        if doc_dir.is_dir() and (doc_dir / f"{doc_dir.name}.assets.index.json").exists()
    ]
    if not index_files:
        logger.error("No multimodal index files found ({doc_id}/{doc_id}.assets.index.json)")
        return 1
    logger.info("Found {} documents to validate", len(index_files))
    logger.info("=" * 60)
    total_images = 0
    total_captions = 0
    total_mentions = 0
    all_valid = True
    for filepath in sorted(index_files):
        result = _validate_index_file(filepath)
        total_images += result["stats"]["total_images"]
        total_captions += result["stats"]["with_captions"]
        total_mentions += result["stats"]["with_mentions"]
        if result["valid"]:
            logger.info("✓ {} ({}): {} images", result["doc_id"], result["filename"], result["stats"]["total_images"])
        else:
            logger.error("✗ {}: {}", result["doc_id"], result["filename"])
            for err in result["errors"][:3]:
                logger.error("  - {}", err)
            all_valid = False
    logger.info("=" * 60)
    if total_images > 0:
        logger.info("Total images: {}", total_images)
        logger.info("With captions: {} ({:.1f}%)", total_captions, total_captions / total_images * 100)
        logger.info("With mentions: {} ({:.1f}%)", total_mentions, total_mentions / total_images * 100)
    if all_valid:
        logger.info("All files passed validation")
        return 0
    logger.error("Some files have validation issues")
    return 1


def run_final_acceptance_validation(multimodal_dir: Optional[Path] = None, log_dir: Optional[Path] = None) -> int:
    project_root = get_project_root()
    setup_logging(Path(log_dir).resolve() if log_dir else project_root / "logs", "final_acceptance_validation")
    resolved_output_dir = (
        Path(multimodal_dir).resolve()
        if multimodal_dir
        else project_root / "data" / DEFAULT_DESIGNED_OUTPUT_DIR_NAME
    )
    if not resolved_output_dir.exists():
        logger.error("Output directory does not exist: {}", resolved_output_dir)
        return 1
    index_files = [
        doc_dir / f"{doc_dir.name}.assets.index.json"
        for doc_dir in sorted(resolved_output_dir.iterdir())
        if doc_dir.is_dir() and (doc_dir / f"{doc_dir.name}.assets.index.json").exists()
    ]
    if not index_files:
        logger.error("No multimodal index files found")
        return 1
    logger.info("Task 2 final acceptance validation")
    logger.info("Found {} output documents", len(index_files))
    selected = random.sample(index_files, min(5, len(index_files)))
    logger.info("Randomly selected for validation: {}", [filepath.parent.name for filepath in selected])
    logger.info("")
    total_validated = 0
    validation_results = []
    for filepath in selected:
        doc_id = filepath.parent.name
        logger.info("Validating document: {}", doc_id)
        try:
            items = json.loads(filepath.read_text(encoding="utf-8"))
            if not isinstance(items, list):
                logger.error("  Invalid index format: not an array")
                continue
            logger.info("  Contains {} image entries", len(items))
            sample_indices = random.sample(range(len(items)), min(3, len(items))) if items else []
            for idx in sample_indices:
                item = items[idx]
                if not isinstance(item, dict):
                    continue
                fig_id = item.get("fig_id", "N/A")
                mentions = item.get("mentions", [])
                mentions_count = len(mentions) if isinstance(mentions, list) else 0
                logger.info("  Entry {}: fig_id='{}', mentions={} items", idx + 1, fig_id, mentions_count)
                if not isinstance(mentions, list):
                    logger.error("  mentions is not a list: {}", type(mentions))
                else:
                    total_validated += 1
                    validation_results.append({"fig_id": fig_id, "mentions_count": mentions_count})
        except Exception as exc:
            logger.error("  File processing error: {}", exc)
        logger.info("")
    logger.info("=== Validation Summary ===")
    logger.info("Total validated entries: {}", total_validated)
    if validation_results:
        logger.info("Detailed results:")
        for idx, result in enumerate(validation_results[:10], 1):
            logger.info("  {}. fig_id: {}, mentions: {} items", idx, result["fig_id"], result["mentions_count"])
        counts = [result["mentions_count"] for result in validation_results]
        avg_mentions = sum(counts) / len(counts) if counts else 0
        max_mentions = max(counts) if counts else 0
        with_refs = sum(1 for count in counts if count > 0)
        logger.info("Stats: avg_mentions={:.1f}, max={}, with_mentions={}/{}", avg_mentions, max_mentions, with_refs, len(counts))
        logger.info("Acceptance validation passed; all entries contain fig_id and mentions")
        return 0
    logger.error("No valid validation results")
    return 1
