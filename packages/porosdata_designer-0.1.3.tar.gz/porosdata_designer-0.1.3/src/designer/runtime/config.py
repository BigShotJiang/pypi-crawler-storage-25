# -*- coding: utf-8 -*-
"""
配置管理模块 (Config) - 数据重组流水线的全局配置中心
"""

"""
配置管理模块 (Config) - 数据重组流水线的全局配置中心

详细描述：
    集中管理所有重组相关的配置参数，包括标签前缀、训练设置、
    处理规则等。支持运行时配置切换和参数验证。

配置分类:
    - 标签命名空间: TAG_PREFIX = "poros_"
    - 训练就绪态: EOS token、空白字符处理
    - 段落分类规则: 标题、摘要、正文等识别模式
    - 内容过滤规则: 图片、表格、公式等处理策略

设计原则:
    - 集中配置: 避免硬编码参数
    - 类型安全: 使用常量定义关键参数
    - 向后兼容: 支持配置版本控制
"""

# 与仓库 data/ 及 scripts/run_designeddataset.sh 默认输出目录名一致
DEFAULT_DESIGNED_OUTPUT_DIR_NAME = "Designed Database"

# 默认分隔符配置
DEFAULT_SEPARATOR_CONFIG = {
    "abstract": "\\n",
    "keywords": "\\n",
    "main_text": "\\n\\n",
    "conclusion": "\\n\\n",
    "references": "\\n",
}

# 标签命名空间化配置
TAG_PREFIX = "poros_"

# 训练就绪态配置
TRAINING_CONFIG = {
    "append_eos": True,
    "eos_token": "</s>",
    "strip_whitespace": True,
    "normalize_eos": True  # 新增：规范化EOS token追加，确保不产生多余换行
}

# 默认段落类型识别规则
DEFAULT_CLASSIFIER_CONFIG = {
    "abstract_keywords": ["abstract"],
    "keywords_keywords": ["keywords:", "keyword:"],
    "conclusion_keywords": ["conclusion", "conclusions", "summary"],
    "references_keywords": ["references", "bibliography"],
    "abstract_max_position": 5,
    "conclusion_min_position_ratio": 0.8,
}

# 默认内容过滤器配置
DEFAULT_FILTER_CONFIG = {
    "include_images": False,
    "include_tables": False,
    "include_equations": True,
    "include_code": True,
    "include_lists": True,
    "exclude_discarded": True,
    "exclude_titles": False,  # 是否过滤掉标题（text_level > 0）
}

# article_info 元信息识别规则：用于将作者/机构/在线日期等行归并到 section_article_info。
# 该规则仅做结构归类，不做文本清洗。
ARTICLE_INFO_KEYWORDS = (
    "available online",
    "received",
    "accepted",
    "revised",
    "corresponding author",
    "correspondence",
    "e-mail",
    "email",
    "doi",
    "department",
    "institute",
    "institution",
    "university",
    "laboratory",
    "academy",
    "school of",
    "faculty of",
    "p.o. box",
    "copyright",
    "all rights reserved",
    "published by",
    "elsevier",
    "springer",
    "wiley",
    "article history",
)

ARTICLE_INFO_REGEX_PATTERNS = (
    r"\b(?:available|published)\s+online\b",
    r"\b(?:received|accepted|revised)\b(?:\s+on)?\b",
    r"\b(?:corresponding\s+author|e-?mail|email|doi)\b",
    r"\b(?:department|institute|institution|university|laboratory|academy)\b",
    r"\b(?:copyright|all rights reserved|published by)\b",
    r"[©Ⓒ]",
    r"\b(?:elsevier|springer|wiley)(?:\s+\w+){0,3}\b",
    r"^(?:[A-Z]\.\s*){1,3}[A-Za-z][A-Za-z'\-]+(?:\s+[A-Za-z][A-Za-z'\-]+){0,2}(?:\s*\\?\*+)?(?:\s*(?:,|;|and)\s*(?:[A-Z]\.\s*){1,3}[A-Za-z][A-Za-z'\-]+(?:\s*\\?\*+)?)*$",
    r"^(?:[A-Z][a-z]+(?:\s+[A-Z][a-z]+){1,3})(?:\s*\\?\*+)?$",
    r"^(?:[A-Z]\.[A-Z]\.\s*[A-Za-z'\-]+(?:\s+[A-Z][A-Za-z'\-]+){0,2})(?:\s*\\?\*+)?$",
)

# 非化学缩写词表：机构名、仪器名、方法名、束线名等
# 统一使用大写，便于进行大小写无关匹配
NON_CHEMICAL_ABBREVIATIONS = {
    "IFM", "NIS", "PEL", "ESA", "B.V.", "ITALY", "JAPAN", "CHINA", "USA", "UK", "EU",
    "IEEE", "ACM", "APS", "AIP", "RSC", "ACS", "WILEY", "ELSEVIER", "SPRINGER", "NATURE",
    "IFW", "DSC", "XRD", "TEM", "SEM", "EDX", "BW5", "DORIS", "HASYLAB", "ILL",
    "CALPHAD", "IV", "IV3", "DTA", "FFT", "PDF", "DOC", "BMG", "BMGS",
    "BMG1", "BMG2", "BMG3",
    "CSACH",
    # 生物计数/菌株编号
    "CFU", "CFUML", "ATCC", "ATCC13311", "ATCC25922", "ATCC6538",
    # 物理量单位
    "ML", "KHZ", "MHZ", "GHZ", "KPA", "MPA", "GPA", "RPM", "WT",
    # 玻璃科学常用非化学符号
    "VFT", "MRS", "NMR",
}

# 单元素物理量下标模式：Sm, Hv, Hc, Tc 等在上下文中多用作物理参数而非化学实体
PHYSICAL_QUANTITY_SUBSCRIPTS = {
    "m", "v", "c", "p", "f", "g", "s", "n", "x", "y", "z",
    "max", "min", "eff", "sat", "mix", "irr", "ext", "int", "out",
    "kin", "td", "k", "a", "t", "l", "0", "1", "2", "3",
    "rg", "e", "r", "b",
}

# 机构语境关键词：出现在这些上下文中的缩写，更可能是机构/单位而非化学式
INSTITUTION_CONTEXT_KEYWORDS = (
    "institute", "university", "laboratory", "lab", "department", "school", "academy",
    "center", "centre", "research", "faculty", "college", "campus", "group",
    "p.o. box", "germany", "japan", "china", "usa", "uk", "hamburg", "dresden",
)

# 方法/仪器语境关键词：用于识别实验技术、束线名、设备型号等非化学实体
METHOD_CONTEXT_KEYWORDS = (
    "differential scanning calorimetry", "x-ray diffraction", "synchrotron", "microscopy",
    "beam-line", "beamline", "storage ring", "detector", "furnace", "measurement",
    "measurements", "calorimetry", "diffraction", "high-energy", "line", "type",
    "rigaku", "ultim", "ion beam thinning", "method", "methods",
)

# 化学语境关键词：在边界情况下作为化学式判定的正向证据
CHEMICAL_CONTEXT_KEYWORDS = (
    "alloy", "alloys", "composition", "compositions", "phase diagram", "metallic glass",
    "metallic glasses", "glass-forming", "melt", "melts", "binary", "ternary",
    "quaternary", "eutectic", "wt.%", "at.%", "mol%", "enthalpy of mixing",
)

