# -*- coding: utf-8 -*-
"""
文本聚合器 (TextAggregator) - 数据重组流水线的文本结构化组件
"""

"""
文本聚合器 (TextAggregator) - 数据重组流水线的文本结构化组件

详细描述：
    负责将MinerU解析后的content_list转换为结构化的XML文本格式。
    执行段落分类、标签命名空间化、EOS token追加等核心重组逻辑。
    输入: MinerU content_list (List[Dict])
    输出: 带Poros前缀的XML结构化文本 + EOS终止符

核心功能:
    - 标签前缀化: 所有XML标签自动添加"poros_"前缀
    - EOS规范化: 确保</s>紧跟标签结尾，无多余换行
    - 段落重组: 按类型(title/abstract/main_text等)组织内容

流水线位置: Task 1 - 文本结构化重组
"""

import re
from typing import Dict, List, Any, Optional, Tuple
from ..runtime.config import (
    TRAINING_CONFIG,
    TAG_PREFIX,
    NON_CHEMICAL_ABBREVIATIONS,
    INSTITUTION_CONTEXT_KEYWORDS,
    METHOD_CONTEXT_KEYWORDS,
    CHEMICAL_CONTEXT_KEYWORDS,
    PHYSICAL_QUANTITY_SUBSCRIPTS,
    ARTICLE_INFO_KEYWORDS,
    ARTICLE_INFO_REGEX_PATTERNS,
)
from .content_filter import ContentFilter
from .paragraph_classifier import ParagraphClassifier, ParagraphType
from .token_marker import TokenMarker

# 标题语义化：一级标题关键词/模式 → section type（见 docs/title_semantic_and_section_wrapping.md）
# 编号不固定——任意 `N.` 均可匹配关键词；未命中任何模式时统一落到显式未知类别 `other`。
_TITLE_NUMBER_PREFIX = r"(?:(?:\d+|[ivxlcdm]+)\.\s*)?"

SECTION_TITLE_PATTERNS = [
    # --- 前置信息 ---
    (re.compile(rf"^{_TITLE_NUMBER_PREFIX}highlights\b[:：]?\s*$", re.IGNORECASE), "highlights"),
    (re.compile(rf"^{_TITLE_NUMBER_PREFIX}graphical\s+abstract\b[:：]?\s*$", re.IGNORECASE), "graphical_abstract"),
    (re.compile(rf"^{_TITLE_NUMBER_PREFIX}article\s+info(?:rmation)?\b[:：]?\s*$", re.IGNORECASE), "article_info"),
    (re.compile(rf"^{_TITLE_NUMBER_PREFIX}key\s*words?\b[:：]?\s*$", re.IGNORECASE), "keywords"),
    # --- 正文 ---
    (re.compile(rf"^{_TITLE_NUMBER_PREFIX}abstract\b[:：]?\s*$", re.IGNORECASE), "abstract"),
    (re.compile(rf"^{_TITLE_NUMBER_PREFIX}introduction\b", re.IGNORECASE), "introduction"),
    (re.compile(rf"^{_TITLE_NUMBER_PREFIX}background\b", re.IGNORECASE), "introduction"),
    (re.compile(rf"^{_TITLE_NUMBER_PREFIX}theory(?:\s+of\s+operation)?\b", re.IGNORECASE), "theory"),
    (re.compile(rf"^{_TITLE_NUMBER_PREFIX}experimental\b", re.IGNORECASE), "experimental"),
    (re.compile(rf"^{_TITLE_NUMBER_PREFIX}(?:methods?|materials?\s+and\s+methods?|methodology)\b", re.IGNORECASE), "experimental"),
    (re.compile(rf"^{_TITLE_NUMBER_PREFIX}results?\s+and\s+discussion\b", re.IGNORECASE), "results"),
    (re.compile(rf"^{_TITLE_NUMBER_PREFIX}results?\b", re.IGNORECASE), "results"),
    (re.compile(rf"^{_TITLE_NUMBER_PREFIX}findings?\b", re.IGNORECASE), "results"),
    (re.compile(rf"^{_TITLE_NUMBER_PREFIX}discussion\b", re.IGNORECASE), "discussion"),
    (re.compile(rf"^{_TITLE_NUMBER_PREFIX}(?:conclusions?|concluding\s+remarks?|summary)\b[:：]?\s*$", re.IGNORECASE), "conclusion"),
    # --- 正文后置 ---
    (re.compile(rf"^{_TITLE_NUMBER_PREFIX}(?:author\s+contributions?|authors?\s+information|contributors?)\b[:：]?\s*$", re.IGNORECASE), "author_info"),
    (re.compile(rf"^{_TITLE_NUMBER_PREFIX}(?:acknowledgements?|acknowledgments?)\b[:：]?\s*$", re.IGNORECASE), "acknowledgements"),
    (re.compile(rf"^{_TITLE_NUMBER_PREFIX}funding(?:\s+(?:information|statement|sources?))?\b[:：]?\s*$", re.IGNORECASE), "funding"),
    (re.compile(rf"^{_TITLE_NUMBER_PREFIX}(?:conflicts?\s+of\s+interests?|competing\s+interests?|disclosures?|disclosure\s+statement)\b[:：]?\s*$", re.IGNORECASE), "conflict_of_interest"),
    (re.compile(rf"^{_TITLE_NUMBER_PREFIX}declarations?(?:\s+of\s+competing\s+interests?)?\b[:：]?\s*$", re.IGNORECASE), "declaration"),
    (re.compile(rf"^{_TITLE_NUMBER_PREFIX}(?:ethics(?:\s+(?:statement|approval))?|ethical\s+statement)\b[:：]?\s*$", re.IGNORECASE), "ethics"),
    (re.compile(rf"^{_TITLE_NUMBER_PREFIX}(?:data\s+availability(?:\s+statement)?|data\s+and\s+code\s+availability|code\s+availability)\b[:：]?\s*$", re.IGNORECASE), "data_availability"),
    (re.compile(rf"^{_TITLE_NUMBER_PREFIX}(?:supplementary|supporting|supplemental)\s+(?:material|materials|information|data)\b[:：]?\s*$", re.IGNORECASE), "supplementary"),
    (re.compile(rf"^(?:appendix|appendices)(?:\s+[a-z0-9]+)?\b[:：]?\s*$", re.IGNORECASE), "appendix"),
    (re.compile(rf"^{_TITLE_NUMBER_PREFIX}notes?\b[:：]?\s*$", re.IGNORECASE), "notes"),
    (re.compile(rf"^{_TITLE_NUMBER_PREFIX}(?:abbreviations?|list\s+of\s+abbreviations?|symbols?)\b[:：]?\s*$", re.IGNORECASE), "abbreviations"),
    (re.compile(rf"^{_TITLE_NUMBER_PREFIX}nomenclature\b[:：]?\s*$", re.IGNORECASE), "nomenclature"),
    (re.compile(rf"^{_TITLE_NUMBER_PREFIX}(?:references?|bibliography)\b[:：]?\s*$", re.IGNORECASE), "references"),
]

# 显式未知类别：所有无法稳定识别的 fallback 章节统一归入 `other`，
# 避免像历史 `section` 那样与正常正文章节混淆。
FALLBACK_SECTION_TYPE = "other"

# 子标题：3.1. 3.2. 等，不开启新 section
SUBTITLE_LEVEL2_PATTERN = re.compile(r"^\d+\.\d+\.\s*", re.IGNORECASE)
SUBTITLE_LEVEL3_PATTERN = re.compile(r"^\d+\.\d+\.\d+\.\s*", re.IGNORECASE)


class TextAggregator:
    """全文本聚合器

    功能：
    - 遍历MinerU的content_list
    - 提取<title>, <abstract>, <main_text>, <references>等核心标签
    - 清洗：移除所有<br>，段落间使用\n\n分隔
    - 对齐：在文档末尾追加</s>终止符
    """

    CHEMICAL_ELEMENTS = {
        'H', 'He', 'Li', 'Be', 'B', 'C', 'N', 'O', 'F', 'Ne', 'Na', 'Mg', 'Al', 'Si', 'P', 'S', 'Cl', 'Ar',
        'K', 'Ca', 'Sc', 'Ti', 'V', 'Cr', 'Mn', 'Fe', 'Co', 'Ni', 'Cu', 'Zn', 'Ga', 'Ge', 'As', 'Se', 'Br', 'Kr',
        'Rb', 'Sr', 'Y', 'Zr', 'Nb', 'Mo', 'Tc', 'Ru', 'Rh', 'Pd', 'Ag', 'Cd', 'In', 'Sn', 'Sb', 'Te', 'I', 'Xe',
        'Cs', 'Ba', 'La', 'Ce', 'Pr', 'Nd', 'Pm', 'Sm', 'Eu', 'Gd', 'Tb', 'Dy', 'Ho', 'Er', 'Tm', 'Yb', 'Lu',
        'Hf', 'Ta', 'W', 'Re', 'Os', 'Ir', 'Pt', 'Au', 'Hg', 'Tl', 'Pb', 'Bi', 'Po', 'At', 'Rn'
    }

    MATH_SYMBOLS = {
        'alpha', 'beta', 'gamma', 'delta', 'epsilon', 'zeta', 'eta', 'theta', 'iota', 'kappa',
        'lambda', 'mu', 'nu', 'xi', 'omicron', 'pi', 'rho', 'sigma', 'tau', 'upsilon',
        'phi', 'chi', 'psi', 'omega', 'Alpha', 'Beta', 'Gamma', 'Delta', 'Epsilon', 'Zeta',
        'Eta', 'Theta', 'Iota', 'Kappa', 'Lambda', 'Mu', 'Nu', 'Xi', 'Omicron', 'Pi',
        'Rho', 'Sigma', 'Tau', 'Upsilon', 'Phi', 'Chi', 'Psi', 'Omega'
    }

    def __init__(self, content_filter_config: Optional[Dict] = None):
        """初始化聚合器

        Args:
            content_filter_config: 内容过滤器配置
        """
        self.content_filter = ContentFilter(content_filter_config)
        self.classifier = ParagraphClassifier()
        self.token_marker = TokenMarker()
        self._article_info_keywords = tuple(k.lower() for k in ARTICLE_INFO_KEYWORDS)
        self._article_info_patterns = tuple(
            re.compile(pattern, re.IGNORECASE) for pattern in ARTICLE_INFO_REGEX_PATTERNS
        )

    def _resolve_title_semantic(self, title_text: str) -> Tuple[Optional[str], bool, bool]:
        """解析标题语义：一级 section type 或子标题层级。

        Returns:
            (section_type, is_subtitle_level2, is_subtitle_level3)
            section_type 为 None 时表示子标题（沿用当前 section）；子标题时 is_subtitle_level2/3 为 True。
            未命中任何模式时返回显式未知类别 ``FALLBACK_SECTION_TYPE``（即 `other`），
            避免与正常正文章节混淆。
        """
        text = title_text.strip()
        if SUBTITLE_LEVEL3_PATTERN.match(text):
            return (None, False, True)
        if SUBTITLE_LEVEL2_PATTERN.match(text):
            return (None, True, False)
        for pattern, section_type in SECTION_TITLE_PATTERNS:
            if pattern.search(text):
                return (section_type, False, False)
        return (FALLBACK_SECTION_TYPE, False, False)

    def _is_article_info_text(self, text: str) -> bool:
        """判断段落是否属于 article_info 元信息。"""
        normalized = (text or "").strip()
        if not normalized:
            return False
        lowered = normalized.lower()
        if any(keyword in lowered for keyword in self._article_info_keywords):
            return True
        return any(pattern.search(normalized) for pattern in self._article_info_patterns)

    def _normalize_non_chemical_token(self, token: str) -> str:
        """标准化缩写，用于与非化学词表比较。"""
        token = re.sub(r'\\[a-zA-Z]+\{([^}]+)\}', r'\1', token)
        token = token.strip().strip("$")
        token = token.replace("{", "").replace("}", "")
        token = re.sub(r'[^A-Za-z0-9.\-]+', '', token)
        return token.upper()

    def _extract_context_window(self, text: str, start: int, end: int, window: int = 80) -> str:
        """提取匹配项前后的上下文窗口。"""
        left = max(0, start - window)
        right = min(len(text), end + window)
        return text[left:right]

    def _has_context_keywords(self, context: str, keywords: tuple) -> bool:
        """判断上下文中是否包含语境关键词。"""
        context_lower = context.lower()
        return any(keyword in context_lower for keyword in keywords)

    def _is_non_chemical_abbreviation(self, token: str) -> bool:
        """判断 token 是否属于明确的非化学缩写。"""
        return self._normalize_non_chemical_token(token) in NON_CHEMICAL_ABBREVIATIONS

    def _is_contextual_non_chemical(self, token: str, context: str = "") -> bool:
        """基于 token 形态和上下文判断其是否更像机构/方法/设备缩写。"""
        if self._is_non_chemical_abbreviation(token):
            return True

        token_compact = re.sub(r'[^A-Za-z0-9]+', '', token)
        looks_like_abbreviation = bool(re.fullmatch(r'[A-Z]{2,}\d{0,3}', token_compact))
        if not looks_like_abbreviation:
            return False

        return self._has_context_keywords(
            context,
            INSTITUTION_CONTEXT_KEYWORDS + METHOD_CONTEXT_KEYWORDS,
        )

    def _normalize_formula_content(self, content: str) -> str:
        """标准化公式文本，仅用于识别，不改写最终输出。"""
        return re.sub(r'\\[a-zA-Z]+\{([^}]+)\}', r'\1', content.strip())

    def _has_leading_delta_prefix(self, content: str) -> bool:
        """检测疑似由上游误识产生的 Delta 前缀合金表达。"""
        normalized = self._normalize_formula_content(content)
        return bool(
            re.match(
                r'^\\?Delta(?:\s*[-–]\s*|\s+|(?=[A-Z]))',
                normalized,
                flags=re.IGNORECASE,
            )
        )

    def _has_balanced_delimiters(self, content: str) -> bool:
        """粗粒度检查公式中的括号/花括号/方括号是否平衡。"""
        opener_for = {'}': '{', ')': '(', ']': '['}
        closers = set(opener_for)
        stack: List[str] = []

        for idx, ch in enumerate(content):
            if idx > 0 and content[idx - 1] == '\\':
                continue
            if ch in ('{', '(', '['):
                stack.append(ch)
            elif ch in closers:
                if not stack or stack[-1] != opener_for[ch]:
                    return False
                stack.pop()

        return not stack

    def _has_malformed_latex_environment(self, content: str) -> bool:
        """检查 \\begin{...}/\\end{...} 环境是否成对且顺序正确。"""
        env_stack: List[str] = []
        for kind, env_name in re.findall(r'\\(begin|end)\{([^}]+)\}', content):
            if kind == 'begin':
                env_stack.append(env_name)
            elif not env_stack or env_stack[-1] != env_name:
                return True
            else:
                env_stack.pop()
        return bool(env_stack)

    def _has_unsafe_formula_structure(self, content: str, entity_type: str = 'single') -> bool:
        """识别不适合在 Designer 阶段继续结构化包装的高风险公式。"""
        if entity_type == 'single' and ('\\begin{' in content or '\\end{' in content):
            return True
        if not self._has_balanced_delimiters(content):
            return True
        if self._has_malformed_latex_environment(content):
            return True
        return False

    _UNIT_PATTERN = re.compile(
        r'(?:CFU|mL|kHz|MHz|GHz|kPa|MPa|GPa|rpm|wt\.\s*%|at\.\s*%|mol\s*%|°C|K/min)',
        re.IGNORECASE,
    )
    _BIO_STRAIN_PATTERN = re.compile(r'^[A-Z]{2,6}\d{3,}$')

    _TEMPERATURE_VALUE_PATTERN = re.compile(
        r'^\s*\\?(?:(?:[-+]?\d[\d.,\s]*\d|\d)\s*'
        r'(?:\\?\s*(?:circ|degree)?\s*\\?\s*(?:mathrm|text|mathsf)?\s*\{?\s*'
        r'(?:°\s*C|C|K|F)\s*\}?'
        r'|~?\s*\\?\s*(?:mathrm|text|mathsf)?\s*\{?\s*(?:K|°\s*C)\s*\}?)'
        r'(?:\s*/\s*(?:min|s|h))?\s*)\s*$',
    )
    _TEMP_WITH_UNIT_PATTERN = re.compile(
        r'\\?(?:mathrm|mathsf|text)\s*\{[^}]*(?:°\s*C|K)\s*\}',
    )
    _PHYSICAL_PARAM_SUBSCRIPT_PATTERN = re.compile(
        r'^\s*\\?[A-Z][a-z]?\s*_\s*\{[^}]*(?:kin|td|K|0|rg|irr|ext|mix|sat)[^}]*\}',
    )
    _NUMERIC_LEADING_PATTERN = re.compile(
        r'^\s*[-+]?\s*\\?\s*(?:approx|sim|geq|leq|geqslant|leqslant)?\s*\d',
    )

    def _is_single_element_physical_quantity(self, content: str) -> bool:
        """检测 $H_{v}$, $S_{m}$, $T_{c}$ 等单元素物理量符号。"""
        m = re.match(
            r'^\\?([A-Z][a-z]?)[\s_]*(?:\{\\?(?:mathrm|mathsf|mathbf)?\s*\{?\s*([a-zA-Z]+)\s*\}?\}?|_\{?\s*([a-zA-Z]+)\s*\}?)$',
            content.strip(),
        )
        if not m:
            return False
        subscript = (m.group(2) or m.group(3) or "").lower()
        return subscript in PHYSICAL_QUANTITY_SUBSCRIPTS

    def _is_temperature_or_physical_value(self, content: str) -> bool:
        """检测温度值（如 70 K、1800°C、20 K/min）或以数字开头的物理量表达式。"""
        stripped = content.strip().strip('$')
        if self._TEMPERATURE_VALUE_PATTERN.match(stripped):
            return True
        if self._TEMP_WITH_UNIT_PATTERN.search(stripped) and self._NUMERIC_LEADING_PATTERN.match(stripped):
            return True
        if self._PHYSICAL_PARAM_SUBSCRIPT_PATTERN.match(stripped):
            return True
        return False

    def _is_valid_chemical_formula(self, content: str, context: str = "") -> bool:
        """验证是否为有效的化学式。"""
        content_clean = content.strip()
        if not content_clean:
            return False

        if self._is_contextual_non_chemical(content_clean, context):
            return False

        # 过滤温度值和物理参数表达式
        if self._is_temperature_or_physical_value(content_clean):
            return False

        # 过滤单位（CFU/mL 等）
        if self._UNIT_PATTERN.search(content_clean):
            return False

        # 过滤生物菌株编号（ATCC13311 等）
        compact = re.sub(r'[^A-Za-z0-9]', '', content_clean)
        if self._BIO_STRAIN_PATTERN.match(compact):
            return False

        # 过滤单元素物理量下标（Sm, Hv, Hc, Tc 等）
        if self._is_single_element_physical_quantity(content_clean):
            return False

        content_normalized = self._normalize_formula_content(content_clean)

        if self._has_leading_delta_prefix(content_clean):
            return False

        if self._has_unsafe_formula_structure(content_clean):
            return False

        # 形如 "Ni -" / "Zr -" 的截断合金式通常来自上游断裂，不应当作有效化学式输出
        if re.search(r'[-–]\s*$', content_normalized):
            return False

        # 含等号的表达式是方程/赋值，不是独立化学式
        if '=' in content_clean:
            return False

        # 含明确数学 LaTeX 命令的表达式不是化学式
        _math_cmds = ('\\int', '\\frac', '\\sum', '\\prod', '\\lim',
                      '\\partial', '\\nabla', '\\approx', '\\equiv',
                      '\\Gamma', '\\infty', '\\leqslant', '\\geqslant')
        if any(cmd in content_clean for cmd in _math_cmds):
            return False

        # 函数记号如 S(q)、F(x) 表示物理函数，不是化学式
        if re.search(r'\(\s*[a-zA-Z]\s*\)', content_clean):
            return False

        potential_elements = re.findall(r'[A-Z][a-z]*', content_normalized)
        valid_chemical_elements = [
            elem for elem in potential_elements
            if elem in self.CHEMICAL_ELEMENTS and elem not in self.MATH_SYMBOLS
        ]

        if not valid_chemical_elements:
            return False

        # 单元素 + 非化学计量下标（含字母变量 i,j,k 或分数 /,）→ 物理量符号
        if len(valid_chemical_elements) == 1:
            subscripts = re.findall(r'_\{([^}]+)\}', content_clean)
            for sub in subscripts:
                sub_clean = re.sub(r'\\[a-zA-Z]+\{[^}]*\}', '', sub)
                has_digit = bool(re.search(r'\d', sub_clean))
                has_math_var = bool(re.search(r'[/,]', sub_clean))
                if not has_digit or has_math_var:
                    return False

        alloy_composition_pattern = r'[A-Z][a-z]?(?:_\{[^}]*(?:\d+\.\d+|\d+-\d+|\d+-\w|\w-\d+|x)[^}]*\})'
        has_alloy_composition = bool(re.search(alloy_composition_pattern, content_normalized))
        has_formula_digits = bool(re.search(r'[A-Z][a-z]?\d', content_normalized))
        has_formula_subscript = bool(re.search(r'_\{[^}]+\}', content_clean))
        has_hyphenated_alloy = bool(re.search(r'[A-Z][a-z]?(?:[-–][A-Z][a-z]?){1,}', content_normalized))
        has_latex_chem = any(marker in content_clean for marker in ('\\mathrm{', '\\mathsf{', '\\mathbf{'))
        has_mixed_case_formula = bool(re.search(r'[A-Z][a-z]', content_normalized)) and len(valid_chemical_elements) >= 2
        has_chemical_context = self._has_context_keywords(context, CHEMICAL_CONTEXT_KEYWORDS)

        # \mathrm{} 仅在多元素时才作为化学式正向信号；单元素 + \mathrm{unit} 更可能是物理量
        if has_latex_chem and len(valid_chemical_elements) <= 1:
            has_latex_chem = False

        has_formula_structure = any([
            has_alloy_composition,
            has_formula_digits,
            has_formula_subscript,
            has_hyphenated_alloy,
            has_latex_chem,
            has_mixed_case_formula,
        ])

        return bool(has_formula_structure or (has_chemical_context and len(valid_chemical_elements) >= 2))

    def _apply_tag_namespacing(self, text: str) -> str:
        """应用标签命名空间化

        将XML标签添加前缀，如 <title> -> <poros_title>

        Args:
            text: 包含XML标签的文本

        Returns:
            应用命名空间后的文本
        """
        # 定义需要前缀化的标签
        tags_to_prefix = [
            'title', 'abstract', 'keywords', 'main_text', 'paragraph',
            'conclusion', 'references'
        ]

        result = text
        for tag in tags_to_prefix:
            # 替换开始标签
            result = re.sub(
                rf'<{tag}>',
                f'<{TAG_PREFIX}{tag}>',
                result
            )
            # 替换结束标签
            result = re.sub(
                rf'</{tag}>',
                f'</{TAG_PREFIX}{tag}>',
                result
            )

        return result

    def _apply_semantic_boxing(self, text: str) -> str:
        """应用语义装箱：基于关键词的智能分类

        将段落内容根据关键词装入相应的语义容器：
        - Abstract相关内容 → <poros_abs>
        - Experimental/Methods相关内容 → <poros_meth>
        - Results相关内容 → <poros_res>
        """
        # 定义语义装箱规则
        boxing_rules = {
            'poros_abs': [
                'abstract', 'summary', 'overview', 'introduction',
                'background', 'preliminary', 'preliminaries'
            ],
            'poros_meth': [
                'experimental', 'method', 'methods', 'methodology',
                'procedure', 'procedures', 'setup', 'measurement',
                'experiment', 'experiments', 'technique', 'techniques'
            ],
            'poros_res': [
                'result', 'results', 'finding', 'findings',
                'observation', 'observations', 'data', 'analysis',
                'discussion', 'conclusion', 'conclusions'
            ]
        }

        result = text

        # 对每个段落应用语义装箱
        for tag, keywords in boxing_rules.items():
            # 查找包含关键词的段落
            paragraphs = result.split('\n\n')
            processed_paragraphs = []

            for paragraph in paragraphs:
                # 检查段落是否已经包装
                if paragraph.strip().startswith('<poros_'):
                    processed_paragraphs.append(paragraph)
                    continue

                # 检查是否包含关键词
                paragraph_lower = paragraph.lower()
                should_box = any(keyword in paragraph_lower for keyword in keywords)

                if should_box:
                    # 应用语义装箱
                    processed_paragraphs.append(f'<{tag}>{paragraph}</{tag}>')
                else:
                    processed_paragraphs.append(paragraph)

            result = '\n\n'.join(processed_paragraphs)

        return result

    def _apply_entity_shielding(self, text: str) -> str:
        """应用实体屏蔽：彻底消除嵌套，精准分流实体

        启发式分类逻辑：
        <poros_chem>: 化学实体 - 元素符号+数字组合，不含数学运算符
        <poros_equ>: 数学公式 - 包含运算符、希腊字母或LaTeX环境

        采用占位符替换法：先提取公式→占位符替换→文本处理→回填标签
        """
        def classify_entity_content(content: str, context: str = "", entity_type: str = "single") -> str:
            """智能分类实体内容"""
            content_clean = content

            # 化学式检测（优先级最高）
            if self._is_valid_chemical_formula(content_clean, context):
                return f'<poros_chem>${content_clean}$</poros_chem>'

            # 对不安全公式采取保守降级，原样保留交由上游修复
            if self._has_leading_delta_prefix(content_clean) or self._has_unsafe_formula_structure(content_clean, entity_type):
                return f'$${content}$$' if entity_type == 'double' else f'${content}$'

            # 数学公式检测
            math_indicators = [
                '=', '+', '-', '\\', 'frac', 'sqrt', 'sum', 'prod', 'int', 'lim', 'infty',
                'alpha', 'beta', 'gamma', 'delta', 'theta', 'lambda', 'mu', 'pi', 'sigma', 'omega',
                'partial', 'nabla', 'exp', 'log', 'ln', 'sin', 'cos', 'tan', 'cdot', 'times', 'div'
            ]
            has_math = any(indicator in content_clean for indicator in math_indicators)

            return f'<poros_equ>${content}$</poros_equ>' if has_math else f'<poros_equ>${content}$</poros_equ>'

        # 占位符替换策略：彻底避免嵌套
        result = text
        entities = []

        # Step 0: 保护货币符号 \$ / \\$ + 数字，避免被误识为公式定界符
        currency_placeholders: List[Tuple[str, str]] = []

        def _protect_currency(m: re.Match) -> str:
            placeholder = f"__CURRENCY_{len(currency_placeholders)}__"
            currency_placeholders.append((placeholder, m.group(0)))
            return placeholder

        result = re.sub(r'\\{1,2}\$\s*[\d,.][\d,.\-–~]*(?:\s*(?:billion|million|trillion|thousand))?', _protect_currency, result)

        # Step 1: 提取所有LaTeX公式（双美元符号优先）
        def extract_double_dollar(match):
            content = match.group(1).strip()
            entities.append(('double', content, ''))
            return f"__ENTITY_{len(entities)-1}__"

        # 使用DOTALL支持跨行公式 - 修复转义问题
        result = re.sub(r'\$\$([^\$]*?)\$\$', extract_double_dollar, result, flags=re.DOTALL)

        # Step 2: 提取单美元符号公式 - 简化正则表达式
        def extract_single_dollar(match):
            content = match.group(1).strip()
            context = self._extract_context_window(match.string, match.start(1), match.end(1))
            entities.append(('single', content, context))
            return f"__ENTITY_{len(entities)-1}__"

        # 更简单的单美元符号匹配
        result = re.sub(r'\$([^$\n]+?)\$', extract_single_dollar, result)

        # Step 3: 处理非LaTeX格式的化学式（此时所有LaTeX公式已被占位符替换）
        def replace_chemical(match):
            formula = match.group(1)
            context = self._extract_context_window(match.string, match.start(1), match.end(1))
            if self._is_valid_chemical_formula(formula, context):
                return f'<poros_chem>{formula}</poros_chem>'
            return formula

        chem_pattern = r'\b(?=[A-Za-z0-9\-–]*?(?:[a-z]|\d|[-–]))([A-Z][a-z]?\d*(?:[-–]?[A-Z][a-z]?\d*)+)\b'
        result = re.sub(chem_pattern, replace_chemical, result)

        # Step 4: 跳过噪声内容过滤

        # Step 5: 回填所有实体
        for i, (entity_type, content, context) in enumerate(entities):
            placeholder = f"__ENTITY_{i}__"
            if entity_type == 'double':
                if self._has_unsafe_formula_structure(content, entity_type='double'):
                    replacement = f'$${content}$$'
                else:
                    replacement = f'<poros_equ>$${content}$$</poros_equ>'
            else:
                replacement = classify_entity_content(content, context, entity_type)
            result = result.replace(placeholder, replacement)

        # Step 6: 恢复货币占位符
        for placeholder, original in currency_placeholders:
            result = result.replace(placeholder, original)

        return result

    def aggregate(self, content_list: List[Dict]) -> str:
        """聚合content_list为结构化全文本

        Args:
            content_list: MinerU解析后的内容列表

        Returns:
            结构化的全文本字符串
        """
        # 1. 过滤文本块
        text_blocks = self.content_filter.filter_text_blocks(content_list)

        # 2. 分类段落
        classified_parts = []
        for i, block in enumerate(text_blocks):
            text = block.get("text", "").strip()
            if not text:
                continue

            # 分类段落类型
            para_type = self.classifier.classify(
                text, i, len(text_blocks), block.get("page_idx", 0), block
            )

            classified_parts.append((text, para_type))

        # 3. 合并所有段落为连续文本
        merged_text = self._merge_to_continuous_text(classified_parts)

        # 4. 应用训练配置
        final_text = self._apply_training_config(merged_text)

        return final_text

    def _merge_to_continuous_text(self, text_parts: List[tuple]) -> str:
        """按文档顺序合并，见题开箱、见新题封箱（Content-Level Semantic Wrapping）。

        当检测到标题时开启 <poros_section_{type}> 并写入 <poros_title_{type}>；
        将该标题之后、下一一级标题之前的所有段落收入该 section；见新题则闭合当前 section。
        """
        if not text_parts:
            return ""

        # 检测是否为「标题先集中、再正文」的输入（如当前 MinerU 常见输出）
        first_non_title = None
        for i, (_, para_type) in enumerate(text_parts):
            if para_type != ParagraphType.TITLE:
                first_non_title = i
                break
        titles_first = first_non_title is not None and first_non_title > 3

        if titles_first:
            return self._merge_titles_first_then_sections(text_parts)
        return self._merge_document_order_sections(text_parts)

    def _close_section(self, current: Optional[str], out: List[str]) -> None:
        if current:
            out.append(f"</{TAG_PREFIX}section_{current}>")

    def _open_section_and_title(self, section_type: str, title_text: str, out: List[str]) -> None:
        out.append(f"<{TAG_PREFIX}section_{section_type}>")
        out.append("<" + TAG_PREFIX + "title_" + section_type + ">" + title_text.strip() + "</" + TAG_PREFIX + "title_" + section_type + ">")

    _SINGLETON_SECTIONS = {"abstract", "conclusion", "references", "acknowledgements"}

    def _merge_document_order_sections(self, text_parts: List[tuple]) -> str:
        """按文档顺序迭代：见题开箱，见新题封箱。

        对 abstract / conclusion / references 等单例 section 做去重：
        若该类型已经关闭，后续同类段落降级为当前 section 的普通段落。
        """
        out: List[str] = []
        current_section: Optional[str] = None
        closed_singletons: set = set()
        has_emitted_header = False

        def _close_current() -> None:
            nonlocal current_section
            if current_section:
                if current_section in self._SINGLETON_SECTIONS:
                    closed_singletons.add(current_section)
                self._close_section(current_section, out)
                current_section = None

        for text, para_type in text_parts:
            if para_type == ParagraphType.TITLE:
                section_type, is_l2, is_l3 = self._resolve_title_semantic(text)
                if is_l3:
                    out.append("<" + TAG_PREFIX + "subtitle_level3>" + text.strip() + "</" + TAG_PREFIX + "subtitle_level3>")
                elif is_l2:
                    out.append("<" + TAG_PREFIX + "subtitle_level2>" + text.strip() + "</" + TAG_PREFIX + "subtitle_level2>")
                else:
                    effective = section_type or FALLBACK_SECTION_TYPE
                    _close_current()
                    if effective in closed_singletons:
                        out.append(f"<{TAG_PREFIX}paragraph>{text}</{TAG_PREFIX}paragraph>")
                        continue
                    # 仅文档起始的首个未匹配标题可降级为 header（文档主标题/作者块）；
                    # 其后仍未匹配的标题保留为显式未知 `other`，而不是继续污染通用 section。
                    if effective == FALLBACK_SECTION_TYPE and not has_emitted_header:
                        effective = "header"
                        has_emitted_header = True
                    current_section = effective
                    self._open_section_and_title(current_section, text, out)

            elif para_type == ParagraphType.ABSTRACT:
                if "abstract" in closed_singletons:
                    out.append(f"<{TAG_PREFIX}paragraph>{text}</{TAG_PREFIX}paragraph>")
                elif current_section != "abstract":
                    _close_current()
                    current_section = "abstract"
                    self._open_section_and_title("abstract", "Abstract", out)
                    out.append(f"<{TAG_PREFIX}paragraph>{text}</{TAG_PREFIX}paragraph>")
                else:
                    out.append(f"<{TAG_PREFIX}paragraph>{text}</{TAG_PREFIX}paragraph>")

            elif para_type == ParagraphType.KEYWORDS:
                _close_current()
                out.append(f"<{TAG_PREFIX}keywords>{text}</{TAG_PREFIX}keywords>")

            elif para_type == ParagraphType.MAIN_TEXT:
                if self._is_article_info_text(text):
                    if current_section != "article_info":
                        _close_current()
                        current_section = "article_info"
                        self._open_section_and_title("article_info", "Article information", out)
                    out.append(f"<{TAG_PREFIX}paragraph>{text}</{TAG_PREFIX}paragraph>")
                    continue

                if current_section == "article_info":
                    _close_current()
                    current_section = None

                if current_section is None:
                    current_section = FALLBACK_SECTION_TYPE
                    stripped = text.strip()
                    # 短文本（<= 80 字符，无换行）多为文章类型标签，用作 section 标题
                    if len(stripped) <= 80 and '\n' not in stripped:
                        self._open_section_and_title(FALLBACK_SECTION_TYPE, stripped, out)
                        continue
                    out.append(f"<{TAG_PREFIX}section_{FALLBACK_SECTION_TYPE}>")
                    out.append(
                        f"<{TAG_PREFIX}title_{FALLBACK_SECTION_TYPE}></{TAG_PREFIX}title_{FALLBACK_SECTION_TYPE}>"
                    )
                out.append(f"<{TAG_PREFIX}paragraph>{text}</{TAG_PREFIX}paragraph>")

            elif para_type == ParagraphType.CONCLUSION:
                if "conclusion" in closed_singletons:
                    out.append(f"<{TAG_PREFIX}paragraph>{text}</{TAG_PREFIX}paragraph>")
                elif current_section != "conclusion":
                    _close_current()
                    current_section = "conclusion"
                    title = text.strip()[:50] if len(text.strip()) < 80 else "Conclusions"
                    self._open_section_and_title("conclusion", title, out)
                else:
                    out.append(f"<{TAG_PREFIX}paragraph>{text}</{TAG_PREFIX}paragraph>")

            elif para_type == ParagraphType.REFERENCES:
                if "references" in closed_singletons:
                    out.append(f"<{TAG_PREFIX}paragraph>{text}</{TAG_PREFIX}paragraph>")
                elif current_section != "references":
                    _close_current()
                    current_section = "references"
                    self._open_section_and_title("references", "References", out)
                else:
                    out.append(f"<{TAG_PREFIX}paragraph>{text}</{TAG_PREFIX}paragraph>")

        _close_current()
        result = "\n".join(out)
        result = self._apply_entity_shielding(result)
        return result

    def _merge_titles_first_then_sections(
        self, text_parts: List[tuple]
    ) -> str:
        """输入为「先一串标题、再 keywords、再正文」时的 fallback：按标题顺序开 section，正文按顺序填入各 section。"""
        titles: List[Tuple[str, str]] = []  # (text, section_type)
        keywords_parts: List[str] = []
        abstract_parts: List[str] = []
        article_info_parts: List[str] = []
        main_parts: List[str] = []
        conclusion_parts: List[str] = []
        references_parts: List[str] = []

        for text, para_type in text_parts:
            if para_type == ParagraphType.TITLE:
                section_type, is_l2, is_l3 = self._resolve_title_semantic(text)
                if is_l3:
                    titles.append((text, "_subtitle3"))
                elif is_l2:
                    titles.append((text, "_subtitle2"))
                else:
                    titles.append((text, section_type or FALLBACK_SECTION_TYPE))
            elif para_type == ParagraphType.KEYWORDS:
                keywords_parts.append(text)
            elif para_type == ParagraphType.ABSTRACT:
                abstract_parts.append(text)
            elif para_type == ParagraphType.MAIN_TEXT:
                if self._is_article_info_text(text):
                    article_info_parts.append(text)
                else:
                    main_parts.append(text)
            elif para_type == ParagraphType.CONCLUSION:
                conclusion_parts.append(text)
            elif para_type == ParagraphType.REFERENCES:
                references_parts.append(text)

        out: List[str] = []
        # 仅保留一级 section 标题（用于开箱顺序），子标题在输出时按位置插回
        section_headers: List[Tuple[str, str]] = [
            (t, st) for t, st in titles
            if not st.startswith("_")
        ]
        body_section_types = [
            st for _, st in section_headers
            if st not in ("abstract", "article_info", "conclusion", "acknowledgements", "references")
        ]
        # 将 main_parts 按 body section 数量均分
        n_body = len(body_section_types) or 1
        chunk_size = max(1, len(main_parts) // n_body)
        main_chunks: List[List[str]] = []
        for i in range(n_body):
            start = i * chunk_size
            end = len(main_parts) if i == n_body - 1 else (i + 1) * chunk_size
            main_chunks.append(main_parts[start:end])

        idx_body = 0
        emitted_singletons: set = set()
        has_article_info_section = False
        for i, (title_text, section_type) in enumerate(section_headers):
            if section_type in self._SINGLETON_SECTIONS and section_type in emitted_singletons:
                continue
            if section_type == "abstract":
                emitted_singletons.add("abstract")
                out.append(f"<{TAG_PREFIX}section_abstract>")
                out.append("<" + TAG_PREFIX + "title_abstract>" + title_text.strip() + "</" + TAG_PREFIX + "title_abstract>")
                for p in abstract_parts:
                    out.append(f"<{TAG_PREFIX}paragraph>{p}</{TAG_PREFIX}paragraph>")
                out.append(f"</{TAG_PREFIX}section_abstract>")
            elif section_type == "article_info":
                has_article_info_section = True
                out.append(f"<{TAG_PREFIX}section_article_info>")
                out.append("<" + TAG_PREFIX + "title_article_info>" + title_text.strip() + "</" + TAG_PREFIX + "title_article_info>")
                for p in article_info_parts:
                    out.append(f"<{TAG_PREFIX}paragraph>{p}</{TAG_PREFIX}paragraph>")
                out.append(f"</{TAG_PREFIX}section_article_info>")
            elif section_type == "acknowledgements":
                emitted_singletons.add("acknowledgements")
                out.append(f"<{TAG_PREFIX}section_acknowledgements>")
                out.append("<" + TAG_PREFIX + "title_acknowledgements>" + title_text.strip() + "</" + TAG_PREFIX + "title_acknowledgements>")
                out.append(f"</{TAG_PREFIX}section_acknowledgements>")
            elif section_type == "references":
                emitted_singletons.add("references")
                out.append(f"<{TAG_PREFIX}section_references>")
                out.append(f"<{TAG_PREFIX}title_references>References</{TAG_PREFIX}title_references>")
                for p in references_parts:
                    out.append(f"<{TAG_PREFIX}paragraph>{p}</{TAG_PREFIX}paragraph>")
                out.append(f"</{TAG_PREFIX}section_references>")
            elif section_type == "conclusion":
                emitted_singletons.add("conclusion")
                out.append(f"<{TAG_PREFIX}section_conclusion>")
                out.append("<" + TAG_PREFIX + "title_conclusion>" + title_text.strip() + "</" + TAG_PREFIX + "title_conclusion>")
                for p in conclusion_parts:
                    out.append(f"<{TAG_PREFIX}paragraph>{p}</{TAG_PREFIX}paragraph>")
                out.append(f"</{TAG_PREFIX}section_conclusion>")
            elif section_type in ("introduction", "experimental", "results", "discussion", FALLBACK_SECTION_TYPE):
                effective = (
                    "header"
                    if i == 0 and section_type == FALLBACK_SECTION_TYPE
                    else section_type
                )
                out.append(f"<{TAG_PREFIX}section_{effective}>")
                out.append("<" + TAG_PREFIX + "title_" + effective + ">" + title_text.strip() + "</" + TAG_PREFIX + "title_" + effective + ">")
                if idx_body < len(main_chunks):
                    for p in main_chunks[idx_body]:
                        out.append(f"<{TAG_PREFIX}paragraph>{p}</{TAG_PREFIX}paragraph>")
                    idx_body += 1
                out.append(f"</{TAG_PREFIX}section_{effective}>")
            else:
                effective = "header" if i == 0 else section_type or FALLBACK_SECTION_TYPE
                out.append(f"<{TAG_PREFIX}section_{effective}>")
                out.append("<" + TAG_PREFIX + "title_" + effective + ">" + title_text.strip() + "</" + TAG_PREFIX + "title_" + effective + ">")
                if idx_body < len(main_chunks):
                    for p in main_chunks[idx_body]:
                        out.append(f"<{TAG_PREFIX}paragraph>{p}</{TAG_PREFIX}paragraph>")
                    idx_body += 1
                out.append(f"</{TAG_PREFIX}section_{effective}>")

        if article_info_parts and not has_article_info_section:
            out.append(f"<{TAG_PREFIX}section_article_info>")
            out.append(f"<{TAG_PREFIX}title_article_info>Article information</{TAG_PREFIX}title_article_info>")
            for p in article_info_parts:
                out.append(f"<{TAG_PREFIX}paragraph>{p}</{TAG_PREFIX}paragraph>")
            out.append(f"</{TAG_PREFIX}section_article_info>")

        if keywords_parts:
            out.insert(0, f"<{TAG_PREFIX}keywords>{' '.join(keywords_parts)}</{TAG_PREFIX}keywords>")

        result = "\n".join(out)
        result = self._apply_entity_shielding(result)
        return result

    _EMPTY_SECTION_PATTERN = re.compile(
        rf'<{TAG_PREFIX}section_((?!header\b)\w+)>\s*'
        rf'<{TAG_PREFIX}title_\1>[^<]*</{TAG_PREFIX}title_\1>\s*'
        rf'</{TAG_PREFIX}section_\1>',
        re.IGNORECASE,
    )

    def _remove_empty_sections(self, text: str) -> str:
        """移除仅含标题标签但无段落内容的空节。"""
        return self._EMPTY_SECTION_PATTERN.sub('', text)

    def _apply_training_config(self, text: str) -> str:
        """应用训练就绪态配置

        Args:
            text: 输入文本

        Returns:
            处理后的文本
        """
        final_text = text

        # 移除空节（仅含标题、无段落内容的 section）
        final_text = self._remove_empty_sections(final_text)

        # 追加文档闭合标签
        final_text = f'<poros_doc>\n{final_text}\n</poros_doc>'

        # 规范化追加EOS token（如果配置）
        if TRAINING_CONFIG["append_eos"]:
            final_text = final_text + TRAINING_CONFIG["eos_token"]

        return final_text

    def get_output_schema(self) -> Dict[str, str]:
        """返回输出数据结构说明"""
        return {
            "format": "连续文本字符串",
            "xml_tags": "包含<title>, <abstract>, <main_text>, <references>等标签",
            "separators": "段落间使用\\n\\n分隔，移除所有<br>标签",
            "eos_token": f"末尾追加 {TRAINING_CONFIG['eos_token']} 终止符"
        }
