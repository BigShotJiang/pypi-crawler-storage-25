# -*- coding: utf-8 -*-
"""
内容过滤器 (ContentFilter) - 数据重组流水线的数据预处理组件

详细描述：
    负责过滤和预处理MinerU解析后的content_list数据，移除不需要的元素，
    保留核心的文本和图片内容。采用插件化设计支持自定义过滤规则。

核心功能:
    - 内容类型识别: 区分text、image、table等MinerU输出类型
    - 智能过滤: 根据配置移除表格、公式、图片等非核心内容
    - 插件化扩展: 支持注册自定义过滤器和处理规则
    - 数据清洗: 移除无效条目和格式错误的元素

配置参数:
    - include_images: 是否保留图片信息
    - include_tables: 是否保留表格数据
    - include_equations: 是否保留公式内容
    - exclude_discarded: 移除已被标记为丢弃的内容

流水线位置: 数据预处理 - 连接输入解析和结构重组
"""

from typing import List, Dict, Optional
from enum import Enum
from ..runtime.config import DEFAULT_FILTER_CONFIG
from ..runtime.plugin_system import PluginRegistry

class ContentType(Enum):
    """内容类型枚举（基于 Mineru 实际输出）"""
    TEXT = "text"
    IMAGE = "image"
    TABLE = "table"
    EQUATION = "equation"
    CODE = "code"
    LIST = "list"
    # 废弃类型（discarded_blocks）
    HEADER = "header"
    FOOTER = "footer"
    PAGE_NUMBER = "page_number"
    ASIDE_TEXT = "aside_text"
    PAGE_FOOTNOTE = "page_footnote"

class ContentFilter:
    """内容过滤器"""
    
    def __init__(self, config: Optional[Dict] = None):
        """初始化过滤器
        
        Args:
            config: 过滤器配置，包含：
                - include_images: 是否包含图片
                - include_tables: 是否包含表格
                - include_equations: 是否包含公式
                - include_code: 是否包含代码
                - include_lists: 是否包含列表
                - exclude_discarded: 是否排除废弃块
        """
        self.config = {**DEFAULT_FILTER_CONFIG, **(config or {})}
    
    def filter_text_blocks(self, content_list: List[Dict]) -> List[Dict]:
        """过滤出文本块（去除标题）
        
        Args:
            content_list: content_list.json 的内容数组
        
        Returns:
            过滤后的文本块列表
        """
        text_blocks = []
        
        for block in content_list:
            block_type = block.get("type")
            
            # 过滤废弃类型
            if self.config["exclude_discarded"] and block_type in [
                "header", "footer", "page_number", 
                "aside_text", "page_footnote"
            ]:
                continue
            
            # 处理 text 类型
            if block_type == "text":
                text_level = block.get("text_level")
                text = block.get("text", "")
                
                # 过滤空文本
                if not text:
                    continue
                
                # 处理标题（text_level > 0）
                if text_level is not None and text_level > 0:
                    if self.config.get("exclude_titles", False):
                        # 过滤掉标题
                        continue
                    else:
                        # 保留标题，但添加标记
                        title_block = block.copy()
                        title_block["_is_title"] = True
                        text_blocks.append(title_block)
                else:
                    text_blocks.append(block)
            
            # 处理 equation 类型
            elif block_type == "equation" and self.config["include_equations"]:
                text = block.get("text", "")
                if text:
                    text_blocks.append({
                        "type": "text",
                        "text": text,
                        "page_idx": block.get("page_idx", 0),
                        "original_type": "equation",
                        "bbox": block.get("bbox"),
                    })
            
            # 处理 code 类型
            elif block_type == "code" and self.config["include_code"]:
                code_body = block.get("code_body", "")
                if code_body:
                    text_blocks.append({
                        "type": "text",
                        "text": code_body,
                        "page_idx": block.get("page_idx", 0),
                        "original_type": "code",
                        "bbox": block.get("bbox"),
                    })
            
            # 处理 list 类型
            elif block_type == "list" and self.config["include_lists"]:
                list_items = block.get("list_items", [])
                if list_items:
                    text = "\n".join(list_items)
                    text_blocks.append({
                        "type": "text",
                        "text": text,
                        "page_idx": block.get("page_idx", 0),
                        "original_type": "list",
                        "bbox": block.get("bbox"),
                    })
        
        return text_blocks


@PluginRegistry.register("content_filter")
def apply_content_filter(content_list: List[Dict]) -> List[Dict]:
    """应用内容过滤器插件"""
    filter_instance = ContentFilter()
    return filter_instance.filter_text_blocks(content_list)


