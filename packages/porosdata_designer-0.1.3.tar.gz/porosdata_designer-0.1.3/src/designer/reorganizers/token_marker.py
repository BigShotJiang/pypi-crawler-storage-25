# -*- coding: utf-8 -*-
"""
Token标记器 (TokenMarker) - 数据重组流水线的格式化标记组件

详细描述：
    负责为重组后的文本添加特殊标记和格式化处理，包括XML标签生成、
    特殊字符转义、格式标准化等。支持插件化扩展自定义标记规则。

核心功能:
    - XML标签生成: 根据段落类型生成相应的XML结构标签
    - 特殊字符处理: 转义和处理文本中的特殊字符
    - 格式标准化: 统一文本格式和编码规范
    - 插件化扩展: 支持自定义标记器和处理规则

标记类型:
    - 结构标签: <paragraph>, <title>, <abstract> 等
    - 格式标签: 处理换行符、空白字符等格式问题
    - 特殊标记: 添加训练需要的特殊token和标识符

流水线位置: 标记处理 - 为结构化文本添加格式化和标识标记
"""

from typing import Dict, Optional
from .paragraph_classifier import ParagraphType
from ..runtime.plugin_system import PluginRegistry

class TokenMarker:
    """Special Token 标记器"""
    
    def __init__(self, token_config: Optional[Dict] = None):
        """初始化标记器
        
        Args:
            token_config: Token 配置字典，格式：{"abstract": "abstract", ...}
        """
        self.token_config = token_config or self._default_tokens()
    
    def wrap(self, text: str, para_type: ParagraphType) -> str:
        """用 special token 包裹文本
        
        Args:
            text: 文本内容
            para_type: 段落类型
        
        Returns:
            包裹后的文本
        """
        token_name = self.token_config.get(para_type.value, para_type.value)
        return f"<{token_name}>{text}</{token_name}>"
    
    def _default_tokens(self) -> Dict:
        """默认 token 配置"""
        return {
            "title": "title",
            "abstract": "abstract",
            "keywords": "keywords",
            "main_text": "main_text",
            "conclusion": "conclusion",
            "references": "references",
        }


# 插件注册示例（待实现）
# @PluginRegistry.register("token_marker")
# def mark_tokens(text: str, para_type: ParagraphType) -> str:
#     """Token 标记插件"""
#     marker = TokenMarker()
#     return marker.wrap(text, para_type)

