# -*- coding: utf-8 -*-
"""
段落分类器 (ParagraphClassifier) - 数据重组流水线的结构识别组件

详细描述：
    智能识别文档中不同段落类型的分类器，支持标题、摘要、关键词、
    正文、结论、参考文献等标准学术文档结构。采用规则引擎和关键词匹配。

核心功能:
    - 类型识别: 基于位置、关键词和上下文识别段落类型
    - 规则引擎: 支持自定义分类规则和关键词配置
    - 位置感知: 考虑段落在文档中的相对位置和顺序
    - 插件化扩展: 支持注册自定义分类器和处理逻辑

识别类型:
    - TITLE: 文档标题和主要标题
    - ABSTRACT: 摘要部分
    - KEYWORDS: 关键词列表
    - MAIN_TEXT: 正文内容和段落
    - CONCLUSION: 结论和总结
    - REFERENCES: 参考文献列表

流水线位置: 结构识别 - 将原始文本流转换为结构化XML标签
"""

from typing import Dict, Optional
from enum import Enum
from ..runtime.config import DEFAULT_CLASSIFIER_CONFIG
from ..runtime.plugin_system import PluginRegistry

class ParagraphType(Enum):
    """段落类型枚举"""
    TITLE = "title"
    ABSTRACT = "abstract"
    KEYWORDS = "keywords"
    MAIN_TEXT = "main_text"
    CONCLUSION = "conclusion"
    REFERENCES = "references"

class ParagraphClassifier:
    """段落类型分类器"""
    
    def __init__(self, config: Optional[Dict] = None):
        """初始化分类器
        
        Args:
            config: 分类器配置
        """
        self.config = {**DEFAULT_CLASSIFIER_CONFIG, **(config or {})}
    
    def classify(
        self, 
        text: str, 
        index: int, 
        total: int,
        page_idx: int = 0,
        block: Optional[Dict] = None
    ) -> ParagraphType:
        """识别段落类型
        
        Args:
            text: 文本内容
            index: 当前文本块索引（从0开始）
            total: 总文本块数量
            page_idx: 页码（用于判断位置）
            block: 文本块字典（可选，用于检查是否为标题）
        
        Returns:
            段落类型
        """
        # 0. 标题识别（优先）
        if block and block.get("_is_title"):
            return ParagraphType.TITLE
        
        text_lower = text.lower()
        
        # 1. 摘要识别
        if self._is_abstract(text_lower, index, total):
            return ParagraphType.ABSTRACT
        
        # 2. 关键词识别
        if self._is_keywords(text_lower):
            return ParagraphType.KEYWORDS
        
        # 3. 参考文献识别（通常在最后）
        if self._is_references(text_lower, index, total):
            return ParagraphType.REFERENCES
        
        # 4. 结论识别（通常在最后20%）
        if self._is_conclusion(text_lower, index, total):
            return ParagraphType.CONCLUSION
        
        # 5. 默认正文
        return ParagraphType.MAIN_TEXT
    
    def _is_abstract(self, text_lower: str, index: int, total: int) -> bool:
        """判断是否为摘要"""
        # 位置判断：前N个文本块
        if index >= self.config["abstract_max_position"]:
            return False
        
        # 关键词判断
        keywords = self.config["abstract_keywords"]
        if any(kw in text_lower for kw in keywords):
            return True
        
        # 长度判断：> 300 字符且位置靠前（通常是abstract）
        # 如果文本很长（>500字符）且在前4个位置，很可能是abstract
        if len(text_lower) > 500 and index < 4:
            return True
        
        # 如果文本较长（>300字符）且在前3个位置，也可能是abstract
        if len(text_lower) > 300 and index < 3:
            return True
        
        return False
    
    def _is_keywords(self, text_lower: str) -> bool:
        """判断是否为关键词"""
        keywords = self.config["keywords_keywords"]
        return any(kw in text_lower for kw in keywords)
    
    def _is_conclusion(self, text_lower: str, index: int, total: int) -> bool:
        """判断是否为结论"""
        # 位置判断：后20%
        min_position = int(total * self.config["conclusion_min_position_ratio"])
        if index < min_position:
            return False
        
        # 关键词判断
        keywords = self.config["conclusion_keywords"]
        if any(kw in text_lower for kw in keywords):
            return True
        
        # 如果没有关键词，但位置很靠后（后10%）且文本较长（>1000字符），可能是conclusion
        if index >= int(total * 0.9) and len(text_lower) > 1000:
            return True
        
        return False
    
    def _is_references(self, text_lower: str, index: int, total: int) -> bool:
        """判断是否为参考文献"""
        # 关键词判断
        keywords = self.config["references_keywords"]
        if any(kw in text_lower for kw in keywords):
            return True
        
        # 格式判断：以 "[1]" 开头
        text_stripped = text_lower
        if text_stripped.startswith("[1]") or text_stripped.startswith("[ 1 ]"):
            return True
        
        return False


@PluginRegistry.register("paragraph_classifier")
def classify_paragraph(text: str, index: int, total: int, page_idx: int = 0, block: Optional[Dict] = None) -> ParagraphType:
    """段落分类插件"""
    classifier = ParagraphClassifier()
    return classifier.classify(text, index, total, page_idx, block)


