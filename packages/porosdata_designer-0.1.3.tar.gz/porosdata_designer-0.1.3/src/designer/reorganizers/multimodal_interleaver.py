# -*- coding: utf-8 -*-
"""
多模态图文交织器 (MultimodalInterleaver) - 数据重组流水线的图文关联组件
"""

"""
多模态图文交织器 (MultimodalInterleaver) - 数据重组流水线的图文关联组件

详细描述：
    将图片与对应的Caption（标题）和正文中的Mention（引用提及）进行高精度关联。
    支持子图识别（Fig 1a, Fig 2.1等）和智能边界控制，避免歧义匹配。
    输入: MinerU content_list + 输出目录
    输出: 结构化JSON + Markdown文件 + 安全复制的图片资产

核心功能:
    - 精确子图匹配: 支持Fig 1a, Fig 2.1等复杂格式，排除Fig 11歧义
    - 上下文提取: 完整的句子级引用提取，保持语义完整性
    - 安全复制: 处理特殊字符路径，OSError异常捕获和备用策略
    - Markdown生成: 自动生成带Poros前缀的结构化Markdown文档

流水线位置: Task 2 - 多模态图文关联重组
"""

import os
import re
import shutil
from concurrent.futures import ThreadPoolExecutor
from typing import Dict, List, Any, Optional, Tuple
from pathlib import Path

from loguru import logger

from ..runtime.config import TAG_PREFIX
from ..adapters.content_list_adapter import ContentListAdapter


class MultimodalInterleaver:
    """多模态图文交织器

    功能：
    - 提取图片及其标题（Caption）
    - 通过精确正则匹配查找正文中的引用
    - 将图片与相关文本关联输出

    正则匹配策略：
    - 使用单词边界符 \b 确保精确匹配
    - 支持多种格式：Fig. 1, Fig 1, Figure 1, FIG. 1
    - 排除后缀干扰：避免匹配Fig. 1.2或Fig. 1a
    """

    # 新契约统一将图片资产与 Markdown 放置在 doc 根目录下的 ``images/`` 子目录。
    DEFAULT_ASSETS_SUBDIR = "images"

    def __init__(
        self,
        asset_io_workers: Optional[int] = None,
        assets_subdir: Optional[str] = None,
    ):
        """初始化交织器

        Args:
            asset_io_workers: 资源复制/Markdown 写入的线程数。默认保守取值，
                避免服务器场景下因 IO 并发过高造成卡顿。
            assets_subdir: 图片 + Markdown 输出子目录名，默认 ``images``。
                新契约下图片和每图 Markdown 统一同目录；保留该参数以便旧布局回归测试。
        """
        # 支持子图的精确匹配正则表达式
        # 支持 Fig 1, Fig 1a, Fig 2.1, Fig 3(b) 等格式
        # 使用自定义匹配逻辑避免Fig 11, Fig 12等连续数字歧义
        self.fig_pattern = None  # 将在 _parse_fig_id 方法中实现更精确的逻辑
        cpu_count = os.cpu_count() or 4
        default_workers = max(1, min(4, cpu_count))
        self.asset_io_workers = asset_io_workers or default_workers
        self.assets_subdir = assets_subdir or self.DEFAULT_ASSETS_SUBDIR

        # Caption识别模式（图片标题通常以"Figure X:"或"Fig. X:"开头）
        self.caption_pattern = re.compile(
            r'\b(?:Fig\.?|Figure|FIG\.?)\s+(\d+(?:\.\d+|[a-zA-Z])?)\s*:?\s*(.+?)(?=\n|$)',
            re.IGNORECASE | re.MULTILINE
        )

    def _apply_tag_namespacing(self, text: str) -> str:
        """应用标签命名空间化

        将XML标签添加前缀，如 <title> -> <poros_title>

        Args:
            text: 包含XML标签的文本

        Returns:
            应用命名空间后的文本
        """
        # 定义需要前缀化的标签
        tags_to_prefix = [
            'title', 'abstract', 'keywords', 'main_text', 'paragraph',
            'conclusion', 'references', 'caption', 'mentions', 'metadata'
        ]

        result = text
        for tag in tags_to_prefix:
            # 替换开始标签
            result = re.sub(
                rf'<{tag}>',
                f'<{TAG_PREFIX}{tag}>',
                result
            )
            # 替换结束标签
            result = re.sub(
                rf'</{tag}>',
                f'</{TAG_PREFIX}{tag}>',
                result
            )

        return result

    def interleave(self, content_list: List[Dict], output_dir: Optional[str] = None,
                  doc_id: Optional[str] = None,
                  content_list_path: Optional[Path] = None) -> List[Dict]:
        """执行图文交织

        Args:
            content_list: MinerU解析后的内容列表
            output_dir: 输出目录路径（可选，用于生成Markdown和复制图片）
            doc_id: 文档ID（可选，用于文件命名）
            content_list_path: content_list.json 的路径；进行资源复制时**必须**提供

        Returns:
            多模态图片信息的列表
        """
        # 1. 一次扫描建立 figure registry，避免每张图重复遍历全文
        registry = self._build_figure_registry(content_list)
        processing_index = self._build_processing_index(content_list)

        # 2. 基于 registry 提取多模态项，保持默认输出契约不变
        multimodal_items = self._extract_all_figures_context(registry, processing_index)

        # 3. 如果指定了输出目录，生成Markdown文件和复制图片
        # content_list_path 必须提供才能进行资源复制（相对路径寻图）
        if output_dir and multimodal_items:
            if content_list_path is None:
                logger.warning("content_list_path was not provided; skipping multimodal export materialization")
            else:
                self._generate_markdown_and_copy_assets(
                    multimodal_items, output_dir, doc_id or "unknown",
                    content_list_path=Path(content_list_path).resolve()
                )

        return multimodal_items

    def _ensure_registry_entry(self, registry: Dict[str, Dict], fig_id: str, page_idx: int) -> Dict[str, Any]:
        """确保指定 fig_id 在 registry 中存在并返回对应条目。"""
        if fig_id not in registry:
            registry[fig_id] = {
                'first_seen_page': page_idx,
                'mention_pages': set(),
                'caption_candidates': [],
                'mention_blocks': [],
                'is_image_registered': False,
                'image_item': None,
            }
        return registry[fig_id]

    def _build_processing_index(self, content_list: List[Dict]) -> Dict[str, Any]:
        """预构建复用索引，降低按图重复扫描成本。"""
        content_positions = {}
        page_text_blocks: Dict[int, List[Dict]] = {}
        page_text_positions: Dict[int, Dict[int, int]] = {}

        for idx, item in enumerate(content_list):
            content_positions[id(item)] = idx
            if item.get('type') == 'text':
                page_idx = item.get('page_idx', 0)
                page_blocks = page_text_blocks.setdefault(page_idx, [])
                page_blocks.append(item)

        for page_idx, blocks in page_text_blocks.items():
            page_text_positions[page_idx] = {id(block): pos for pos, block in enumerate(blocks)}

        return {
            'content_list': content_list,
            'content_positions': content_positions,
            'page_text_blocks': page_text_blocks,
            'page_text_positions': page_text_positions,
        }

    # ==================== 第一阶段：建立图表注册表 ====================

    def _build_figure_registry(self, content_list: List[Dict]) -> Dict[str, Dict]:
        """第一阶段：建立完整的图表注册表

        全局扫描，识别所有Fig标识符，建立索引

        Returns:
            图表注册表字典
        """
        registry = {}

        # 扫描所有内容项
        for item in content_list:
            if item.get('type') == 'text':
                self._scan_text_for_figs(item, registry)
            elif item.get('type') == 'image':
                self._register_image_captions(item, registry)

        return registry

    def _scan_text_for_figs(self, item: Dict, registry: Dict):
        """扫描文本中的Fig引用"""
        text = item.get('text', '')
        page_idx = item.get('page_idx', 0)

        # 识别所有Fig引用
        fig_matches = re.findall(
            r'\b(?:Fig\.?|Figure|FIG\.?)\s+(\d+(?:\.\d+|[a-zA-Z])?)',
            text, re.IGNORECASE
        )

        for fig_id in set(fig_matches):
            entry = self._ensure_registry_entry(registry, fig_id, page_idx)
            entry['mention_pages'].add(page_idx)
            entry['mention_blocks'].append(item)

    def _register_image_captions(self, item: Dict, registry: Dict):
        """注册图片标题（使用清理后的图注文本，兼容 processed image 格式）"""
        captions = ContentListAdapter.get_image_caption_texts(item)
        page_idx = item.get('page_idx', 0)
        matched_any = False

        for caption in captions:
            fig_match = re.search(
                r'\b(?:Fig\.?|Figure|FIG\.?)\s+(\d+(?:\.\d+|[a-zA-Z])?)',
                caption, re.IGNORECASE
            )
            if fig_match:
                matched_any = True
                fig_id = fig_match.group(1)
                entry = self._ensure_registry_entry(registry, fig_id, page_idx)
                entry['caption_candidates'].append(caption)
                entry['is_image_registered'] = True
                entry['first_seen_page'] = page_idx  # 图片所在页优先
                entry['image_item'] = item  # 保存图片项引用

        # 无图注时退回到旧逻辑：从 img_path / 文件名推断 fig_id
        if not matched_any:
            fig_id = self._parse_fig_id(item)
            if fig_id:
                entry = self._ensure_registry_entry(registry, fig_id, page_idx)
                entry['is_image_registered'] = True
                entry['first_seen_page'] = page_idx
                entry['image_item'] = item

    # ==================== 第二阶段：深度上下文提取 ====================

    def _extract_all_figures_context(self, registry: Dict, processing_index: Dict[str, Any]) -> List[Dict]:
        """第二阶段：深度上下文提取

        针对每个注册的Fig ID进行精确提取，避免歧义
        """
        multimodal_items = []

        for fig_id, registry_info in registry.items():
            # 只处理已注册的图片（有实际图片对象的）
            if registry_info['is_image_registered'] and registry_info['image_item']:
                item = self._extract_single_figure_context(fig_id, registry_info, processing_index)
                if item:
                    multimodal_items.append(item)

        return multimodal_items

    def _compile_mention_regex(self, fig_id: str):
        """为指定 fig_id 编译精确引用匹配模式。"""
        if fig_id.isdigit():
            pattern = rf'(?<!\d)(?:Fig\.?|Figure|FIG\.?)\s+{re.escape(fig_id)}(?!\d)'
        else:
            pattern = rf'\b(?:Fig\.?|Figure|FIG\.?)\s+{re.escape(fig_id)}\b'
        return re.compile(pattern, re.IGNORECASE)

    def _get_caption_from_registry(self, image_item: Dict, processing_index: Dict[str, Any]) -> Optional[str]:
        """优先使用图片自身图注，保持与旧逻辑一致；无图注时回退到邻近文本块。"""
        captions = ContentListAdapter.get_image_caption_texts(image_item)
        if captions:
            return " ".join(captions)

        content_list = processing_index['content_list']
        content_positions = processing_index['content_positions']
        image_idx = content_positions.get(id(image_item))
        if image_idx is None:
            return None

        for idx in range(max(0, image_idx - 3), min(len(content_list), image_idx + 2)):
            item = content_list[idx]
            if item.get("type") == "text":
                text = item.get("text", "")
                if self._is_caption_text(text):
                    return text
        return None

    def _get_mentions_from_registry(self, fig_id: str, registry_info: Dict[str, Any]) -> List[str]:
        """从已命中的文本块中提取 mention 句子，避免重复扫描全文。"""
        mention_blocks = registry_info.get('mention_blocks', [])
        if not mention_blocks:
            return []

        mention_regex = self._compile_mention_regex(fig_id)
        mentions: List[str] = []
        seen = set()
        for item in mention_blocks:
            text = item.get('text', '')
            for sentence in self._extract_sentences_with_mention(text, mention_regex):
                normalized = sentence.strip()
                if normalized and normalized not in seen:
                    seen.add(normalized)
                    mentions.append(normalized)
        return mentions

    def _get_surrounding_blocks_from_index(
        self, processing_index: Dict[str, Any], target_block: Dict, window: int = 2
    ) -> Dict[str, List[Dict]]:
        """基于预构建页索引获取相邻文本块。"""
        target_page = target_block.get('page_idx', 0)
        page_blocks = processing_index['page_text_blocks'].get(target_page, [])
        page_positions = processing_index['page_text_positions'].get(target_page, {})
        target_index = page_positions.get(id(target_block))
        if target_index is None:
            return {'before': [], 'after': []}

        before = page_blocks[max(0, target_index - window):target_index]
        after = page_blocks[target_index + 1:target_index + 1 + window]
        return {'before': before, 'after': after}

    def _get_semantic_anchors_from_registry(
        self, fig_id: str, registry_info: Dict[str, Any], processing_index: Dict[str, Any]
    ) -> Dict[str, Any]:
        """基于已命中的文本块和页索引提取语义锚点。"""
        mention_blocks = registry_info.get('mention_blocks', [])
        if not mention_blocks:
            return {'before': [], 'after': [], 'anchor_type': 'page_based'}

        target_block = None
        first_seen_page = registry_info.get('first_seen_page', 0)
        for item in mention_blocks:
            if item.get('page_idx') == first_seen_page:
                target_block = item
                break
        if target_block is None:
            target_block = mention_blocks[0]

        anchors = self._get_surrounding_blocks_from_index(processing_index, target_block, window=2)
        return {
            'before': [b.get('text', '') for b in anchors['before']],
            'after': [b.get('text', '') for b in anchors['after']],
            'anchor_type': 'context_based'
        }

    def _extract_single_figure_context(
        self, fig_id: str, registry_info: Dict, processing_index: Dict[str, Any]
    ) -> Optional[Dict]:
        """提取单个图片的完整上下文信息"""
        image_item = registry_info['image_item']

        # 1. Caption 提取：优先图片自身图注，回退到邻近文本块
        caption = self._get_caption_from_registry(image_item, processing_index)

        # 2. Mention 提取：从预先命中的文本块中抽句，避免重复扫描全文
        mentions = self._get_mentions_from_registry(fig_id, registry_info)

        # 3. 语义锚点提取：基于页级索引获取邻近块
        semantic_anchors = self._get_semantic_anchors_from_registry(fig_id, registry_info, processing_index)

        # 4. 物理定位信息
        spatial_info = self._extract_spatial_info(image_item)

        # 使用清理后的图注/脚注文本（兼容 processed 格式）
        caption_texts = ContentListAdapter.get_image_caption_texts(image_item)
        footnote_texts = ContentListAdapter.get_image_footnote_texts(image_item)

        # 构建输出项
        return {
            "image_path": image_item.get("img_path", ""),
            "fig_id": fig_id,
            "caption": caption or f"Figure {fig_id}",
            "mentions": mentions,
            "metadata": {
                "page_idx": registry_info['first_seen_page'],
                "bbox": image_item.get("bbox", []),
                "image_footnote": footnote_texts,
                "image_caption": caption_texts,
                "spatial_info": spatial_info,
                "semantic_anchors": semantic_anchors
            },
            "asset_copied": False,  # 将在后续步骤中设置
            "markdown_file": ""  # 将在后续步骤中设置
        }

    def _find_precise_caption(self, fig_id: str, content_list: List[Dict]) -> Optional[str]:
        """精确查找图片标题（使用清理后的图注文本，兼容 processed image 格式）"""
        for item in content_list:
            if item.get('type') == 'image':
                captions = ContentListAdapter.get_image_caption_texts(item)
                for caption in captions:
                    if re.search(rf'\b(?:Fig\.?|Figure|FIG\.?)\s+{re.escape(fig_id)}\b', caption, re.IGNORECASE):
                        return caption
        return None

    def _find_precise_mentions(self, fig_id: str, content_list: List[Dict]) -> List[str]:
        """精确查找引用，避免歧义匹配"""
        mentions = []

        # 根据fig_id类型选择不同的匹配策略
        if fig_id.isdigit():
            # 对于纯数字：使用严格边界 (?<!\d) 和 (?! \d)
            pattern = rf'(?<!\d)(?:Fig\.?|Figure|FIG\.?)\s+{re.escape(fig_id)}(?!\d)'
        else:
            # 对于子图：使用单词边界
            pattern = rf'\b(?:Fig\.?|Figure|FIG\.?)\s+{re.escape(fig_id)}\b'

        mention_regex = re.compile(pattern, re.IGNORECASE)

        for item in content_list:
            if item.get('type') == 'text':
                text = item.get('text', '')
                if mention_regex.search(text):
                    mentions.append(text.strip())

        return mentions

    def _extract_semantic_anchors(self, fig_id: str, page_idx: int, content_list: List[Dict]) -> Dict[str, Any]:
        """提取语义锚点：前后文本作为定位依据"""
        # 查找包含该fig的文本块
        relevant_blocks = []
        for item in content_list:
            if (item.get('page_idx') == page_idx and
                item.get('type') == 'text' and
                self._contains_fig_reference(item.get('text', ''), fig_id)):
                relevant_blocks.append(item)

        if not relevant_blocks:
            return {'before': [], 'after': [], 'anchor_type': 'page_based'}

        # 获取前后相邻的文本块
        target_block = relevant_blocks[0]
        anchors = self._get_surrounding_blocks(content_list, target_block, window=2)

        return {
            'before': [b.get('text', '') for b in anchors['before']],
            'after': [b.get('text', '') for b in anchors['after']],
            'anchor_type': 'context_based'
        }

    def _extract_spatial_info(self, image_item: Dict) -> Dict[str, Any]:
        """提取空间定位信息"""
        bbox = image_item.get('bbox', [])
        page_idx = image_item.get('page_idx', 0)

        # 计算相对位置（简化实现）
        position = 'unknown'
        if bbox and len(bbox) >= 4:
            # 基于y坐标判断位置
            y_top = bbox[1] if len(bbox) > 1 else 0
            # 这里可以根据页面高度计算相对位置
            position = 'top' if y_top < 200 else 'middle' if y_top < 500 else 'bottom'

        return {
            'page_idx': page_idx,
            'position': position,
            'has_bbox': bool(bbox),
            'bbox': bbox
        }

    def _contains_fig_reference(self, text: str, fig_id: str) -> bool:
        """检查文本是否包含对指定fig的引用"""
        if fig_id.isdigit():
            pattern = rf'(?<!\d)(?:Fig\.?|Figure|FIG\.?)\s+{re.escape(fig_id)}(?!\d)'
        else:
            pattern = rf'\b(?:Fig\.?|Figure|FIG\.?)\s+{re.escape(fig_id)}\b'
        return bool(re.search(pattern, text, re.IGNORECASE))

    def _get_surrounding_blocks(self, content_list: List[Dict], target_block: Dict, window: int = 2) -> Dict[str, List[Dict]]:
        """获取目标文本块前后的相邻块"""
        target_page = target_block.get('page_idx', 0)
        page_blocks = [b for b in content_list if b.get('page_idx') == target_page and b.get('type') == 'text']

        try:
            target_index = page_blocks.index(target_block)
            before = page_blocks[max(0, target_index - window):target_index]
            after = page_blocks[target_index + 1:target_index + 1 + window]
        except ValueError:
            before, after = [], []

        return {'before': before, 'after': after}

    # ==================== 保留原有方法以保持兼容性 ====================

    def _extract_images(self, content_list: List[Dict]) -> List[Dict]:
        """提取所有图片信息"""
        images = []
        for item in content_list:
            if item.get("type") == "image":
                images.append(item)
        return images

    def _build_multimodal_item(self, image: Dict, content_list: List[Dict]) -> Optional[Dict]:
        """为单个图片构建完整的多模态信息（兼容性方法）

        注意：推荐使用双阶段策略的 interleave 方法而不是此方法

        Args:
            image: 图片信息字典
            content_list: 完整的内容列表

        Returns:
            多模态图片项，如果无法提取有效信息则返回None
        """
        # 解析图片的Fig序号
        fig_id = self._parse_fig_id(image)
        if not fig_id:
            return None

        # 提取图片标题（Caption）
        caption = self._extract_caption(image, content_list)

        # 查找正文中的引用（Mentions）
        mentions = self._find_mentions(content_list, fig_id)

        # 使用清理后的图注/脚注文本（兼容 processed 格式）
        caption_texts = ContentListAdapter.get_image_caption_texts(image)
        footnote_texts = ContentListAdapter.get_image_footnote_texts(image)

        # 构建输出项
        item = {
            "image_path": image.get("img_path", ""),
            "fig_id": fig_id,
            "caption": caption or f"Figure {fig_id}",
            "mentions": mentions,
            "metadata": {
                "page_idx": image.get("page_idx", 0),
                "bbox": image.get("bbox", []),
                "image_footnote": footnote_texts,
                "image_caption": caption_texts,
            }
        }

        return item

    def _parse_fig_id(self, image: Dict) -> Optional[str]:
        """从图片信息中解析Fig序号

        现在使用更宽松的策略，支持所有合理的Fig编号格式

        Args:
            image: 图片信息字典

        Returns:
            Fig序号字符串，如果无法解析则返回None
        """
        # 使用清理后的图注文本解析（兼容 processed image 格式）
        captions = ContentListAdapter.get_image_caption_texts(image)
        for caption in captions:
            fig_id = self._extract_fig_number(caption)
            if fig_id:
                return fig_id

        # 如果caption中没有，尝试从img_path推断
        img_path = image.get("img_path", "")
        if img_path:
            # 从路径中查找fig/figure + 数字的模式
            stem = Path(img_path).stem.lower()
            fig_match = re.search(r'(?:fig|figure|img|pic)\s*(\d+(?:\.\d+|[a-zA-Z])?)', stem)
            if fig_match:
                candidate = fig_match.group(1)
                # 使用更宽松的验证
                if self._is_valid_fig_number_relaxed(candidate):
                    return candidate

            # 如果没找到，尝试查找纯数字
            num_match = re.search(r'\b(\d{1,3})\b', stem)  # 支持1-3位数字
            if num_match:
                candidate = num_match.group(1)
                if self._is_valid_fig_number_relaxed(candidate):
                    return candidate

        return None

    def _extract_fig_number(self, text: str) -> Optional[str]:
        """从文本中精确提取Fig编号

        Args:
            text: 待分析的文本

        Returns:
            Fig编号字符串或None
        """
        # 查找所有可能的Fig引用
        fig_pattern = re.compile(r'\b(?:Fig\.?|Figure|FIG\.?)\s+(\d+(?:\.\d+|[a-zA-Z])?)', re.IGNORECASE)
        matches = fig_pattern.findall(text)

        for candidate in matches:
            # 使用宽松验证，支持多位数
            if self._is_valid_fig_number_relaxed(candidate):
                return candidate

        return None

    def _is_valid_fig_number(self, fig_num: str) -> bool:
        """验证Fig编号是否有效（原有方法，为保持兼容性）

        规则：
        - 单个数字：有效（如 "1"）
        - 数字+字母：有效（如 "1a", "3b"）
        - 数字+点+数字：有效（如 "1.1", "2.3"）
        - 连续纯数字：无效（如 "11", "12"）

        Args:
            fig_num: Fig编号字符串

        Returns:
            是否为有效的Fig编号
        """
        # 为了兼容性，保留原有逻辑但在双阶段策略中已不使用
        return self._is_valid_fig_number_relaxed(fig_num)

    def _is_valid_fig_number_relaxed(self, fig_num: str) -> bool:
        """验证Fig编号是否有效（宽松版本）

        支持所有合理的Fig编号格式，包括多位数

        Args:
            fig_num: Fig编号字符串

        Returns:
            是否为有效的Fig编号
        """
        # 如果是纯数字，允许1-999
        if fig_num.isdigit():
            num = int(fig_num)
            return 1 <= num <= 999  # 支持1-999的数字

        # 如果包含字母或点号，则认为是有效的子图编号
        if any(c.isalpha() or c == '.' for c in fig_num):
            return True

        # 其他情况认为是无效的
        return False

    def _extract_caption(self, image: Dict, content_list: List[Dict]) -> Optional[str]:
        """提取图片的标题（Caption）

        Args:
            image: 图片信息字典
            content_list: 完整内容列表

        Returns:
            图片标题字符串
        """
        # 使用清理后的图注文本（兼容 processed image 格式）
        captions = ContentListAdapter.get_image_caption_texts(image)
        if captions:
            return " ".join(captions)

        # 在内容列表中查找对应的标题文本
        # 通常标题会在图片前后的文本块中
        image_idx = None
        for i, item in enumerate(content_list):
            if item == image:
                image_idx = i
                break

        if image_idx is not None:
            # 检查前几个文本块（通常标题在图片之前）
            for i in range(max(0, image_idx - 3), min(len(content_list), image_idx + 2)):
                item = content_list[i]
                if item.get("type") == "text":
                    text = item.get("text", "")
                    # 检查是否包含Figure/Fig标题
                    if self._is_caption_text(text):
                        return text

        return None

    def _is_caption_text(self, text: str) -> bool:
        """判断文本是否为图片标题"""
        text_lower = text.lower()
        # 检查是否以Figure/Fig开头
        if re.match(r'^(?:fig\.?|figure|fig)\s+\d+', text_lower, re.IGNORECASE):
            return True
        # 检查是否包含常见的标题关键词
        if any(keyword in text_lower for keyword in ['figure', 'fig.', 'image', 'photo', 'diagram']):
            return True
        return False

    def _find_mentions(self, content_list: List[Dict], fig_id: str) -> List[str]:
        """在正文中查找对该图片的引用

        Args:
            content_list: 完整内容列表
            fig_id: Fig序号

        Returns:
            引用文本的列表
        """
        mentions = []

        # 构建精确匹配该Fig序号的正则表达式
        # 根据fig_id类型选择不同的匹配策略
        if fig_id.isdigit():
            # 对于纯数字：使用严格边界 (?<!\d) 和 (?! \d)
            pattern = rf'(?<!\d)(?:Fig\.?|Figure|FIG\.?)\s+{re.escape(fig_id)}(?!\d)'
        else:
            # 对于子图：使用单词边界
            pattern = rf'\b(?:Fig\.?|Figure|FIG\.?)\s+{re.escape(fig_id)}\b'

        mention_regex = re.compile(pattern, re.IGNORECASE)

        for item in content_list:
            if item.get("type") == "text":
                text = item.get("text", "")

                # 检查是否包含对该图片的引用
                if mention_regex.search(text):
                    # 提取包含引用的句子
                    sentences = self._extract_sentences_with_mention(text, mention_regex)
                    mentions.extend(sentences)

        return mentions

    def _extract_sentences_with_mention(self, text: str, pattern) -> List[str]:
        """从文本中提取包含引用的完整句子

        Args:
            text: 文本内容
            pattern: 匹配模式

        Returns:
            包含引用的完整句子列表
        """
        sentences = []

        # 改进的分句逻辑：按句号、感叹号、问号分割，但保持句子完整性
        # 使用正向预查确保句子完整
        sentence_pattern = r'(?<=[.!?])\s+(?=[A-Z])'
        text_sentences = re.split(sentence_pattern, text)

        for sentence in text_sentences:
            sentence = sentence
            if sentence and pattern.search(sentence):
                sentences.append(sentence)

        # 如果标准分句失败，尝试更简单的方法
        if not sentences:
            # 按句号分割，但尝试合并不完整的句子
            simple_sentences = re.split(r'(?<=[.!?])\s+', text)

            for sentence in simple_sentences:
                sentence = sentence
                if sentence and pattern.search(sentence):
                    # 检查句子是否以大写字母开头（表示句子开始）
                    if re.match(r'^[A-Z]', sentence):
                        sentences.append(sentence)
                    else:
                        # 如果不是句子开头，尝试向前查找更多上下文
                        sentences.append(sentence)

        # 如果仍然没有找到，返回包含引用的上下文（前后各80个字符以获取完整句子）
        if not sentences:
            for match in pattern.finditer(text):
                start = max(0, match.start() - 80)
                end = min(len(text), match.end() + 80)

                # 尝试找到句子的自然边界
                context = text[start:end]

                # 向前查找句子开始
                sentence_start = start
                for i in range(start, max(0, start - 200), -1):
                    if re.search(r'(?<=[.!?])\s+', text[max(0, i-2):i+2]):
                        sentence_start = i
                        break

                # 向后查找句子结束
                sentence_end = end
                for i in range(end, min(len(text), end + 200)):
                    if re.search(r'[.!?]\s+', text[max(0, i-2):i+2]):
                        sentence_end = i + 1
                        break

                full_sentence = text[sentence_start:sentence_end]
                if full_sentence and full_sentence not in sentences:
                    sentences.append(full_sentence)

        return sentences[:5]  # 最多返回5个引用

    def get_output_schema(self) -> Dict[str, str]:
        """返回输出数据结构说明"""
        return {
            "format": "图片-文本关联JSON数组 + Markdown文件 + 图片资产",
            "image_path": "str - 相对于 doc 输出目录的图片路径 (images/fig_N.jpg)",
            "fig_id": "str - Fig序号",
            "caption": "str - 图片标题/说明",
            "mentions": "List[str] - 正文中对该图片的完整句子引用",
            "metadata": "Dict - 包含页码、边界框等原始信息",
            "markdown_file": "str - 与图片同目录的 Markdown 路径 (images/fig_N.md)",
            "asset_copied": "bool - 图片是否成功复制到 images 目录"
        }

    def safe_copy_image(self, src_path: Path, dst_path: Path) -> bool:
        """安全的图片复制函数

        处理路径中的特殊字符，增加错误捕获和重试机制

        Args:
            src_path: 源图片路径
            dst_path: 目标图片路径

        Returns:
            复制是否成功
        """
        try:
            # 处理特殊字符路径，确保使用正斜杠
            src_str = str(src_path).replace('\\', '/')
            dst_str = str(dst_path).replace('\\', '/')

            # 使用绝对路径避免相对路径问题
            src_abs = Path(src_str).resolve()
            dst_abs = Path(dst_str).resolve()

            # 确保源文件存在
            if not src_abs.exists():
                logger.warning("Source image does not exist: {}", src_abs)
                return False

            # 确保目标目录存在
            dst_abs.parent.mkdir(parents=True, exist_ok=True)

            # 执行复制
            shutil.copy2(str(src_abs), str(dst_abs))
            logger.debug("复制成功: {} -> {}", src_abs.name, dst_abs)
            return True

        except (OSError, IOError, UnicodeDecodeError, UnicodeEncodeError) as e:
            logger.warning("Image copy failed: {} | source: {} target: {}", e, src_path, dst_path)

            # 备用方案：shutil.copyfile 避免整图读入内存
            try:
                shutil.copyfile(str(src_abs), str(dst_abs))
                logger.debug("Fallback copy ok: {}", dst_path)
                return True
            except Exception as backup_error:
                logger.warning("Fallback copy also failed: {}", backup_error)
                return False
        except Exception as e:
            logger.warning("Unexpected copy error: {}", e)
            return False

    def _build_filename_base(self, fig_id: str) -> str:
        """生成稳定文件名，避免超长或异常 fig_id。"""
        if len(str(fig_id)) <= 3:
            return f"fig_{fig_id}"
        import hashlib
        short_hash = hashlib.md5(str(fig_id).encode()).hexdigest()[:8]
        return f"image_{short_hash}"

    def _materialize_multimodal_item(
        self,
        item: Dict[str, Any],
        output_path: Path,
        assets_dir: Path,
        image_source_dir: Path,
    ) -> Dict[str, Any]:
        """为单个多模态项执行资源复制和 Markdown 生成。

        新契约下图片与对应的 Markdown 统一落盘到 ``{doc_dir}/{assets_subdir}/``，
        路径均采用相对 ``{doc_dir}`` 的形式（例如 ``images/fig_1.jpg``），
        便于 ``{doc_id}.assets.index.json`` / ``asset_refs.link`` 直接消费。
        """
        result_item = dict(item)
        fig_id = result_item['fig_id']
        image_path = result_item['image_path']
        filename_base = self._build_filename_base(fig_id)
        subdir = self.assets_subdir

        asset_copied = False
        asset_relative_path = ""

        if image_path:
            source_image_path = image_source_dir / image_path
            if not source_image_path.exists():
                logger.warning("Source image does not exist; skipping copy: {}", source_image_path)
                asset_relative_path = f"{subdir}/{filename_base}.jpg"
            else:
                ext = Path(image_path).suffix if '.' in Path(image_path).name else '.jpg'
                asset_filename = f"{filename_base}{ext}"
                asset_dest_path = assets_dir / asset_filename
                asset_copied = self.safe_copy_image(source_image_path, asset_dest_path)
                if asset_copied:
                    asset_relative_path = f"{subdir}/{asset_filename}"
                    logger.debug("复制图片: {}", asset_filename)
                else:
                    asset_relative_path = f"{subdir}/{filename_base}.jpg"

        result_item['image_path'] = asset_relative_path
        result_item['asset_copied'] = asset_copied
        result_item['markdown_file'] = ""

        markdown_filename = f"{filename_base}.md"
        # Markdown 内部 ``![...](path)`` 需引用同目录图片，保持 Markdown 渲染器直接可见
        markdown_item = dict(result_item)
        markdown_item['image_path'] = f"./{Path(asset_relative_path).name}" if asset_relative_path else ""
        markdown_content = self._generate_markdown_content(markdown_item, filename_base)

        markdown_path = assets_dir / markdown_filename
        with open(markdown_path, 'w', encoding='utf-8') as f:
            f.write(markdown_content)
        result_item['markdown_file'] = f"{subdir}/{markdown_filename}"
        logger.debug("生成 Markdown: {}", markdown_filename)

        return result_item

    def _generate_markdown_and_copy_assets(self, items: List[Dict], output_dir: str, doc_id: str,
                                          content_list_path: Path):
        """生成Markdown文件并复制图片资产

        基于 content_list_path.parent 相对路径寻图，无硬编码路径。
        输出统一落到 ``{output_dir}/{assets_subdir}/``（默认 ``images``），
        图片和每图 Markdown 同目录同名，便于下游 ``assets.index.json`` 与
        ``asset_refs.link`` 使用相同相对路径。

        Args:
            items: 多模态图片项列表
            output_dir: 输出根目录
            doc_id: 文档ID
            content_list_path: content_list.json 的绝对路径，用于相对路径寻图
        """
        output_path = Path(output_dir)
        assets_dir = output_path / self.assets_subdir
        assets_dir.mkdir(parents=True, exist_ok=True)

        # 相对路径寻路：content_list 所在目录即图片源根目录
        image_source_dir = Path(content_list_path).resolve().parent

        if not items:
            return

        if self.asset_io_workers <= 1 or len(items) <= 1:
            materialized_items = [
                self._materialize_multimodal_item(item, output_path, assets_dir, image_source_dir)
                for item in items
            ]
        else:
            max_workers = min(self.asset_io_workers, len(items))
            with ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix="poros-mm-io") as executor:
                materialized_items = list(executor.map(
                    lambda item: self._materialize_multimodal_item(item, output_path, assets_dir, image_source_dir),
                    items,
                ))

        items[:] = materialized_items

    def _generate_markdown_content(self, item: Dict, filename_base: str) -> str:
        """生成Markdown内容

        Args:
            item: 图片项数据
            filename_base: 文件名基础部分

        Returns:
            Markdown格式的字符串
        """
        fig_id = item['fig_id']
        image_path = item['image_path']
        caption = item['caption'] or f"Figure {fig_id}"
        mentions = item['mentions']

        # Markdown标题
        content = f"# {TAG_PREFIX.capitalize()}Figure {fig_id}\n\n"

        # 图片引用
        content += f"![{TAG_PREFIX.capitalize()}Figure {fig_id}]({image_path})\n\n"

        # Caption部分
        content += f"### {TAG_PREFIX.capitalize()}Caption\n\n"
        content += f"{caption}\n\n"

        # Mentions部分
        content += f"### {TAG_PREFIX.capitalize()}Mentions in Text\n\n"
        if mentions:
            for i, mention in enumerate(mentions, 1):
                content += f"- {mention}\n"
        else:
            content += f"_{TAG_PREFIX.capitalize()}No mentions found in the text._\n"

        content += "\n"

        # 元数据（可选，以注释形式）
        content += "<!--\n"
        content += f"Document: {item.get('doc_id', 'unknown')}\n"
        content += f"Page: {item['metadata'].get('page_idx', 'unknown')}\n"
        content += f"Fig ID: {fig_id}\n"
        content += f"Asset copied: {item.get('asset_copied', False)}\n"
        content += "-->\n"

        return content

    def demonstrate_precision_matching(self, test_text: str, target_fig: str) -> Dict[str, Any]:
        """演示精准匹配效果

        Args:
            test_text: 测试文本
            target_fig: 目标Fig序号

        Returns:
            匹配结果字典
        """
        mention_pattern = re.compile(
            rf'\b(?:Fig\.?|Figure|FIG\.?)\s+{re.escape(target_fig)}\b',
            re.IGNORECASE
        )

        matches = mention_pattern.findall(test_text)
        positions = [m.start() for m in mention_pattern.finditer(test_text)]

        return {
            "target_fig": target_fig,
            "matches_found": matches,
            "match_positions": positions,
            "total_matches": len(matches)
        }
