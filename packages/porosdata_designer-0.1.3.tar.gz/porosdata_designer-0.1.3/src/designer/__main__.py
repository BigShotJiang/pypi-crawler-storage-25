# -*- coding: utf-8 -*-
"""Module entry point forwarding to the unified CLI."""

from .cli import main


if __name__ == "__main__":
    raise SystemExit(main())

