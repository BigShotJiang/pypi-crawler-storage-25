"""Shared utility namespace reserved for future helpers."""
