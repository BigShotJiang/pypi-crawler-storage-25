# -*- coding: utf-8 -*-
"""
资产穿透引擎 (Asset Anchoring Engine) - Fig/Table 与物理资产硬链接

核心职责：
- 自动扫描文本中的 Fig. n 或 Table n 关键字
- 将其替换为包含 UUID 的资产标签 <poros_asset uuid="xxx">
- 直接关联 fig_n.md 中的图像元数据
"""

import re
import uuid
from typing import Dict, List, Optional, Tuple
from pathlib import Path

from ..runtime.config import TAG_PREFIX
from ..adapters.content_list_adapter import ContentListAdapter

# 使用 uuid5 确保同一 doc+fig 始终得到相同 UUID，便于跨任务关联
def _make_asset_uuid(doc_id: str, asset_key: str) -> str:
    namespace = uuid.NAMESPACE_DNS
    name = f"{doc_id}:{asset_key}"
    return str(uuid.uuid5(namespace, name))


class AssetAnchoringEngine:
    """资产穿透引擎

    将正文中的 Fig. n / Table n 引用替换为带 UUID 的资产标签，
    建立与物理文件（fig_n.md、图像）的硬链接。
    """

    def __init__(self):
        # Fig 引用模式：Fig. 1, Fig 1, Figure 1, Fig 1a, Fig 2.1
        self._fig_pattern = re.compile(
            r'\b(?:Fig\.?|Figure|FIG\.?)\s+(\d+(?:\.\d+|[a-zA-Z])?)\b',
            re.IGNORECASE
        )
        # Table 引用模式
        self._table_pattern = re.compile(
            r'\b(?:Table|TABLE)\s+(\d+(?:\.\d+|[a-zA-Z])?)\b',
            re.IGNORECASE
        )

    def build_asset_registry(
        self,
        content_list: List[Dict],
        doc_id: str,
        output_dir: Optional[Path] = None
    ) -> Dict[str, str]:
        """建立 Fig/Table ID -> UUID 的注册表

        使用 uuid5 确保同一 doc+fig 始终得到相同 UUID，便于 full_text 与 multimodal 跨任务关联。

        Args:
            content_list: MinerU 内容列表
            doc_id: 文档 ID
            output_dir: 多模态输出目录（可选，用于后续生成 fig_n.md）

        Returns:
            {"fig_1": "uuid-xxx", "table_1": "uuid-yyy", ...}
        """
        registry: Dict[str, str] = {}

        for item in content_list:
            if item.get("type") == "image":
                fig_id = self._parse_fig_id_from_image(item)
                if fig_id:
                    key = f"fig_{fig_id}"
                    if key not in registry:
                        registry[key] = _make_asset_uuid(doc_id, key)

            if item.get("type") == "table" or "table_body" in item:
                table_id = self._parse_table_id(item)
                if table_id:
                    key = f"table_{table_id}"
                    if key not in registry:
                        registry[key] = _make_asset_uuid(doc_id, key)

        return registry

    def _parse_fig_id_from_image(self, image_item: Dict) -> Optional[str]:
        """从图片项解析 Fig ID（使用清理后的图注文本，兼容 processed image 格式）"""
        captions = ContentListAdapter.get_image_caption_texts(image_item)
        for cap in captions:
            m = re.search(r'\b(?:Fig\.?|Figure|FIG\.?)\s+(\d+(?:\.\d+|[a-zA-Z])?)', cap, re.IGNORECASE)
            if m:
                return m.group(1)
        return None

    def _parse_table_id(self, item: Dict) -> Optional[str]:
        """从表格项解析 Table ID"""
        text = item.get("text", "") or ""
        m = re.search(r'\b(?:Table|TABLE)\s+(\d+(?:\.\d+|[a-zA-Z])?)', text, re.IGNORECASE)
        if m:
            return m.group(1)
        return None

    def anchor_text(
        self,
        text: str,
        registry: Dict[str, str],
        replace_fig: bool = True,
        replace_table: bool = True
    ) -> Tuple[str, List[Dict]]:
        """将文本中的 Fig/Table 引用替换为资产标签

        Args:
            text: 原始文本
            registry: {"fig_1": "uuid-xxx", "table_1": "uuid-yyy"}
            replace_fig: 是否替换 Fig 引用
            replace_table: 是否替换 Table 引用

        Returns:
            (替换后的文本, 替换记录列表)
        """
        result = text
        replacements: List[Dict] = []

        def replace_fig_match(m):
            fig_id = m.group(1)
            key = f"fig_{fig_id}"
            if key in registry:
                uid = registry[key]
                replacements.append({"type": "fig", "id": fig_id, "uuid": uid})
                return f'<{TAG_PREFIX}asset uuid="{uid}" type="fig" ref="{fig_id}">Fig. {fig_id}</{TAG_PREFIX}asset>'
            return m.group(0)

        def replace_table_match(m):
            table_id = m.group(1)
            key = f"table_{table_id}"
            if key in registry:
                uid = registry[key]
                replacements.append({"type": "table", "id": table_id, "uuid": uid})
                return f'<{TAG_PREFIX}asset uuid="{uid}" type="table" ref="{table_id}">Table {table_id}</{TAG_PREFIX}asset>'
            return m.group(0)

        if replace_fig:
            result = self._fig_pattern.sub(replace_fig_match, result)
        if replace_table:
            result = self._table_pattern.sub(replace_table_match, result)

        return result, replacements
