# -*- coding: utf-8 -*-
"""
数据挖掘字段映射 (Data Mining Field Mapper) - 三层视图输出

核心职责（三层视图契约）：
- pure_text_stream（纯文本训练视图）：剥离全部 poros_* 结构标签，
  仅保留自然文本与约定的公式/符号策略，供通用 LLM 训练或 Embedding。
- structured_json（数据挖掘视图）：显式保存 sections/title/paragraph/
  formula/chemical/asset 等结构信息，供抽取、检索、入库。

输入来自 TextAggregator 的 content（结构感知训练视图），content 本身
保留 poros_* 标签，用于长文本结构感知训练、章节边界监督。
"""

import re
from typing import Dict, Any, Optional
from dataclasses import dataclass

from ..runtime.config import (
    NON_CHEMICAL_ABBREVIATIONS,
    TAG_PREFIX,
)


_CHEM_LATEX_WRAPPERS = re.compile(r'\\(?:mathrm|mathbf|mathsf|mathit|text|operatorname)\{([^{}]+)\}')
_CHEM_CONTROL_SEQUENCE_NOISE = re.compile(
    r'\\(?:alpha|beta|gamma|delta|Delta|theta|lambda|rho|sigma|mu|pi|sin|cos|tan|log|ln|exp|frac|int|sum|prod|'
    r'left|right|begin|end|bar|boldsymbol|cdot|times|leqslant|geqslant)'
)
_SIMPLE_CHEM_SEGMENT = re.compile(r'(?:[A-Z][a-z]?\d*(?:\.\d+)?)+')
_PURE_ELEMENT_SYMBOL = re.compile(r'[A-Z][a-z]?')


def _normalize_chemical_candidate(formula: str) -> str:
    normalized = formula.strip().strip("$")
    previous = None
    while previous != normalized:
        previous = normalized
        normalized = _CHEM_LATEX_WRAPPERS.sub(r'\1', normalized)
    normalized = normalized.replace("{", "").replace("}", "")
    normalized = normalized.replace("_", "")
    normalized = normalized.replace("^", "")
    normalized = re.sub(r"\s+", "", normalized)
    return normalized.strip(".,;:")


def _is_simple_chem_segment(segment: str) -> bool:
    return bool(_SIMPLE_CHEM_SEGMENT.fullmatch(segment))


def _is_pure_element_symbol(segment: str) -> bool:
    return bool(_PURE_ELEMENT_SYMBOL.fullmatch(segment))


def is_valid_chemical_formula_candidate(formula: str) -> bool:
    """高精度筛选 chemical_formulas，仅保留元素/化合物/稳定材料式。"""
    raw = formula.strip()
    if not raw:
        return False
    if _CHEM_CONTROL_SEQUENCE_NOISE.search(raw):
        return False

    normalized = _normalize_chemical_candidate(raw)
    if not normalized:
        return False
    if any(char in normalized for char in ("=", "+", "/", "(", ")", "[", "]", "\\")):
        return False

    upper_norm = re.sub(r"[^A-Za-z0-9.\-]+", "", normalized).upper()
    if upper_norm in NON_CHEMICAL_ABBREVIATIONS:
        return False

    if "-" in normalized or "–" in normalized:
        parts = [part for part in re.split(r"[-–]", normalized) if part]
        if not parts or any(not _is_simple_chem_segment(part) for part in parts):
            return False
        # 二元元素对更接近体系/配对名，按交付高精度要求不纳入 chemical_formulas。
        if len(parts) == 2 and all(_is_pure_element_symbol(part) for part in parts):
            return False
        return True

    return _is_simple_chem_segment(normalized)


@dataclass
class DataMiningView:
    """数据挖掘双视图"""
    pure_text_stream: str       # 纯净文本流（用于训练）
    structured_json: Dict       # 结构化 JSON（用于数据挖掘）
    metadata: Dict[str, Any]    # 元数据（溯源、质量标记等）


class DataMiningMapper:
    """数据挖掘字段映射器（三层视图契约）

    输入：content（结构感知训练视图，保留 poros_* 标签）
    输出：
    - pure_text_stream: 剥离全部 poros_* 标签的纯净文本，供通用训练 / Embedding
    - structured_json: 含 sections / paragraphs / formulas / chemical / asset 的结构 JSON
    """

    def __init__(self):
        self._tag_pattern = re.compile(
            rf'<{TAG_PREFIX}([a-zA-Z_]+)(?:\s[^>]*)?>([^<]*)</{TAG_PREFIX}\1>',
            re.IGNORECASE
        )
        self._asset_pattern = re.compile(
            rf'<{TAG_PREFIX}asset\s+[^>]*>([^<]+)</{TAG_PREFIX}asset>',
            re.IGNORECASE
        )
        # abstract 兜底仅过滤版权/出版类元信息，避免误删正文。
        self._abstract_metadata_keywords = (
            "copyright",
            "all rights reserved",
            "published by",
            "elsevier",
            "springer",
            "wiley",
        )
        self._abstract_metadata_patterns = tuple(
            re.compile(pattern, re.IGNORECASE)
            for pattern in (
                r"[©Ⓒ]",
                r"\b(?:copyright|all rights reserved|published by)\b",
                r"\b(?:elsevier|springer|wiley)(?:\s+\w+){0,3}\b",
            )
        )

    def map(self, structured_text: str, metadata: Optional[Dict] = None) -> DataMiningView:
        """将结构化 Poros 文本映射为双视图

        Args:
            structured_text: 带 Poros 标签的结构化文本
            metadata: 可选元数据（溯源、质量等）

        Returns:
            DataMiningView
        """
        metadata = metadata or {}

        # 1. 纯净文本流：保留语义，移除/简化标签
        pure_text = self._to_pure_text_stream(structured_text)

        # 2. 结构化 JSON
        structured = self._to_structured_json(structured_text)

        return DataMiningView(
            pure_text_stream=pure_text,
            structured_json=structured,
            metadata=metadata
        )

    # 块级闭合标签：转为段落分隔（双换行），保持自然阅读节奏
    _BLOCK_CLOSE_TAGS = re.compile(
        rf'</{TAG_PREFIX}(?:doc|paragraph|section_\w+|title_\w+|subtitle_\w+'
        rf'|abstract|keywords|main_text|conclusion|references|abs|meth|res)>',
        re.IGNORECASE,
    )

    # 通用 poros_* 开/闭标签（含属性），用于兜底清理
    _ALL_POROS_TAGS = re.compile(rf'</?{TAG_PREFIX}[a-zA-Z_][a-zA-Z0-9_]*(?:\s[^>]*)?>', re.IGNORECASE)

    def _to_pure_text_stream(self, text: str) -> str:
        """生成纯净文本流：剥离全部 poros_* 结构标签，仅保留自然文本。

        策略：
        1. 保留 poros_equ / poros_chem 内容（公式/化学式），仅移除包裹标签。
        2. 保留 poros_asset 引用文本，移除标签。
        3. 块级闭合标签转为双换行（段落分隔）。
        4. 所有其余 poros_* 标签统一清除。
        5. 移除文档级 </s>。
        """
        result = text

        # 资产标签 → 保留引用文本
        result = self._asset_pattern.sub(r'\1', result)

        # 公式/化学式标签 → 保留内容文本，移除标签壳
        result = re.sub(rf'<{TAG_PREFIX}(?:equ|chem)>', '', result, flags=re.IGNORECASE)
        result = re.sub(rf'</{TAG_PREFIX}(?:equ|chem)>', '', result, flags=re.IGNORECASE)

        # 块级闭合标签 → 段落分隔
        result = self._BLOCK_CLOSE_TAGS.sub('\n\n', result)

        # 剩余所有 poros_* 标签一次性清除
        result = self._ALL_POROS_TAGS.sub('', result)

        # 移除 </s>
        result = result.replace('</s>', '')

        # 整理多余换行
        result = re.sub(r'\n{3,}', '\n\n', result)
        return result.strip()

    _SECTION_PATTERN = re.compile(
        rf'<{TAG_PREFIX}section_(\w+)>(.*?)</{TAG_PREFIX}section_\1>',
        re.DOTALL | re.IGNORECASE,
    )
    _SECTION_TITLE_PATTERN = re.compile(
        rf'<{TAG_PREFIX}title_(\w+)>(.*?)</{TAG_PREFIX}title_\1>',
        re.IGNORECASE,
    )
    _SUBTITLE_PATTERN = re.compile(
        rf'<{TAG_PREFIX}subtitle_(\w+)>(.*?)</{TAG_PREFIX}subtitle_\1>',
        re.IGNORECASE,
    )
    _PARAGRAPH_PATTERN = re.compile(
        rf'<{TAG_PREFIX}paragraph>(.*?)</{TAG_PREFIX}paragraph>',
        re.DOTALL | re.IGNORECASE,
    )
    _LEADING_TITLE_INDEX = re.compile(r'^\s*(?:\d+(?:\.\d+)*[.)]?\s*|[ivxlcdm]+\.\s*)', re.IGNORECASE)
    _TRAILING_PUNCT = re.compile(r'[\s:：\-–—]+$')

    def _to_structured_json(self, text: str) -> Dict[str, Any]:
        """生成结构化 JSON（数据挖掘视图）。

        仅保留 section-level 的结构语义字段与原始内容引用字段，
        不再输出统计/规则衍生信号；下游如需 is_narrative / block_type /
        canonical_section_type 等判断，应在 feature 层自行推导。

        输出：
        - 每个 section：``section_type / title / subtitles / paragraphs /
          section_path`` 以及位置三件套 ``section_index / total_sections /
          position_ratio``
        - 文档级：``title / abstract / formulas / chemical_formulas /
          asset_refs``
        """
        doc: Dict[str, Any] = {
            "sections": [],
            "formulas": [],
            "chemical_formulas": [],
            "asset_refs": []
        }

        # --- 提取 section 层级 ---
        for sm in self._SECTION_PATTERN.finditer(text):
            section_type = sm.group(1)
            section_body = sm.group(2)

            section_obj: Dict[str, Any] = {
                "section_type": section_type,
                "title": "",
                "subtitles": [],
                "paragraphs": [],
            }

            tm = self._SECTION_TITLE_PATTERN.search(section_body)
            if tm:
                section_obj["title"] = self._strip_inner_tags(tm.group(2))

            # 兜底：若 title 仍为空，从第一段文本截取摘要
            if not section_obj["title"]:
                first_para = self._PARAGRAPH_PATTERN.search(section_body)
                if first_para:
                    hint = self._strip_inner_tags(first_para.group(1)).strip()
                    if hint:
                        section_obj["title"] = hint[:80]

            for stm in self._SUBTITLE_PATTERN.finditer(section_body):
                section_obj["subtitles"].append({
                    "level": stm.group(1),
                    "text": self._strip_inner_tags(stm.group(2)),
                })

            for pm in self._PARAGRAPH_PATTERN.finditer(section_body):
                section_obj["paragraphs"].append(self._strip_inner_tags(pm.group(1)))

            section_obj["section_type"] = self._normalize_section_type(
                section_obj["section_type"],
                section_obj["title"],
            )

            section_obj["section_path"] = (
                [section_obj["title"]] if section_obj["title"] else []
            )
            doc["sections"].append(section_obj)

        # --- 回写位置信号（section_index / total_sections / position_ratio） ---
        total = len(doc["sections"])
        for idx, sec in enumerate(doc["sections"]):
            sec["section_index"] = idx
            sec["total_sections"] = total
            denom = max(1, total - 1)
            sec["position_ratio"] = round(idx / denom, 3)

        # --- 文档级 title（header section 内的 title_header） ---
        m = re.search(rf'<{TAG_PREFIX}title_header>(.*?)</{TAG_PREFIX}title_header>', text, re.IGNORECASE)
        if m:
            doc["title"] = self._strip_inner_tags(m.group(1))
        else:
            m = re.search(rf'<{TAG_PREFIX}title>([^<]*)</{TAG_PREFIX}title>', text, re.IGNORECASE)
            if m:
                doc["title"] = m.group(1).strip()

        # --- 文档级 abstract（从 section_abstract 提取） ---
        m = re.search(
            rf'<{TAG_PREFIX}section_abstract>(.*?)</{TAG_PREFIX}section_abstract>',
            text, re.DOTALL | re.IGNORECASE,
        )
        if m:
            abstract_paragraphs = self._extract_paragraph_texts(m.group(1))
            abstract_paragraphs = [
                p for p in abstract_paragraphs if not self._is_metadata_paragraph(p)
            ]
            if abstract_paragraphs:
                doc["abstract"] = "\n".join(abstract_paragraphs)
        else:
            m = re.search(rf'<{TAG_PREFIX}abstract>(.*?)</{TAG_PREFIX}abstract>', text, re.DOTALL | re.IGNORECASE)
            if m:
                abstract_paragraphs = self._extract_paragraph_texts(m.group(1))
                abstract_paragraphs = [
                    p for p in abstract_paragraphs if not self._is_metadata_paragraph(p)
                ]
                if abstract_paragraphs:
                    doc["abstract"] = "\n".join(abstract_paragraphs)
                else:
                    # 兼容旧格式：<poros_abstract>text</poros_abstract>
                    doc["abstract"] = self._strip_inner_tags(m.group(1))

        # --- 提取 poros_chem ---
        for m in re.finditer(rf'<{TAG_PREFIX}chem>(.*?)</{TAG_PREFIX}chem>', text, re.DOTALL | re.IGNORECASE):
            doc["chemical_formulas"].append(self._strip_inner_tags(m.group(1)))

        # --- 提取 poros_equ ---
        for m in re.finditer(rf'<{TAG_PREFIX}equ>(.*?)</{TAG_PREFIX}equ>', text, re.DOTALL | re.IGNORECASE):
            doc["formulas"].append(self._strip_inner_tags(m.group(1)))

        # --- 提取 poros_asset ---
        for m in re.finditer(
            rf'<{TAG_PREFIX}asset\s+uuid="([^"]+)"\s+type="([^"]+)"\s+ref="([^"]+)"[^>]*>([^<]*)</{TAG_PREFIX}asset>',
            text, re.IGNORECASE,
        ):
            doc["asset_refs"].append({
                "uuid": m.group(1),
                "type": m.group(2),
                "ref": m.group(3),
                "text": m.group(4).strip(),
            })

        # --- 有序去重（保持首次出现顺序，O(n)） ---
        doc["chemical_formulas"] = list(dict.fromkeys(doc["chemical_formulas"]))
        doc["formulas"] = list(dict.fromkeys(doc["formulas"]))

        # --- chemical_formulas 高精度过滤 ---
        doc["chemical_formulas"] = [
            formula for formula in doc["chemical_formulas"]
            if is_valid_chemical_formula_candidate(formula)
        ]

        # --- 过滤截断公式（上游断裂遗留的 "Element-" 形式） ---
        doc["formulas"] = [f for f in doc["formulas"]
                           if not re.search(r'[-–]\s*\$?\s*$', f.strip().rstrip('$'))]

        return doc

    def _strip_inner_tags(self, s: str) -> str:
        """简化内层标签，保留可读文本"""
        return re.sub(r'<[^>]+>', '', s).strip()

    def _extract_paragraph_texts(self, section_body: str) -> list:
        """从 section/body 中提取 paragraph 文本（保序）。"""
        paragraphs = []
        for pm in self._PARAGRAPH_PATTERN.finditer(section_body or ""):
            paragraphs.append(self._strip_inner_tags(pm.group(1)))
        return paragraphs

    def _is_metadata_paragraph(self, text: str) -> bool:
        """判断段落是否为 abstract 中应剔除的版权/出版元信息。"""
        normalized = (text or "").strip()
        if not normalized:
            return False
        lowered = normalized.lower()
        if any(keyword in lowered for keyword in self._abstract_metadata_keywords):
            return True
        return any(pattern.search(normalized) for pattern in self._abstract_metadata_patterns)

    def _normalize_title_text(self, title: str) -> str:
        cleaned = self._LEADING_TITLE_INDEX.sub("", title or "").strip()
        cleaned = self._TRAILING_PUNCT.sub("", cleaned)
        cleaned = re.sub(r"\s+", " ", cleaned)
        return cleaned.lower()

    # 需要基于标题再纠偏的通用/不稳定类型：
    # - ``section`` / ``header`` 是历史遗留值，可能因上游生成器未识别到一级标题而出现；
    # - ``other`` 是新契约中的显式未知类别，纠偏逻辑同样适用，但不会强制回退。
    _NORMALIZABLE_SECTION_TYPES = {"section", "header", "other"}

    # 显式未知类别：data mining 视图与聚合器保持一致
    FALLBACK_SECTION_TYPE = "other"

    def _normalize_section_type(self, section_type: str, title: str) -> str:
        """基于标题语义纠偏通用/未知 section，降低 section type 误分。

        与 ``text_aggregator.SECTION_TITLE_PATTERNS`` 共享同一套语义类别，
        如果仍然无法从标题识别出稳定类别，则：
        - 历史 ``section`` 值统一规整为 ``other``，避免新旧契约混用；
        - ``other`` / ``header`` 保留原值。
        """
        normalized_type = (section_type or "").lower()
        if normalized_type == "section":
            # 历史契约里的通用 section 实际等同于 new contract 的 other
            normalized_type = self.FALLBACK_SECTION_TYPE
        if normalized_type not in self._NORMALIZABLE_SECTION_TYPES:
            return normalized_type

        title_norm = self._normalize_title_text(title)
        if not title_norm:
            return normalized_type

        # Notes：避免 “Publisher note” 等元数据行因包含 ``note`` 子串被误归入 notes
        if not re.search(r"\bpublisher\b", title_norm):
            if title_norm in ("note", "notes") or re.match(
                r"^notes?(?:\s*[:,：]|\s+|$)", title_norm
            ):
                return "notes"

        keyword_rules = [
            ("highlights", ("highlights",)),
            ("graphical_abstract", ("graphical abstract",)),
            ("article_info", ("article info", "article information")),
            ("keywords", ("keywords", "key words")),
            ("abstract", ("abstract",)),
            ("introduction", ("introduction", "background")),
            ("theory", ("theory", "theoretical framework", "theory of operation")),
            ("experimental", ("materials and methods", "material and methods", "methodology", "methods", "experimental")),
            ("results", ("results", "findings")),
            ("discussion", ("discussion",)),
            ("conclusion", ("conclusion", "conclusions", "concluding remarks", "summary")),
            ("author_info", ("author contribution", "author contributions", "contributors", "author information", "authors information")),
            ("acknowledgements", ("acknowledgement", "acknowledgements", "acknowledgment", "acknowledgments")),
            ("funding", ("funding",)),
            ("conflict_of_interest", ("conflict of interest", "conflicts of interest", "competing interest", "competing interests", "disclosure", "disclosure statement")),
            ("declaration", ("declaration", "declarations")),
            ("ethics", ("ethics", "ethical statement", "ethics approval", "ethics statement")),
            ("data_availability", ("data availability", "data and code availability", "code availability")),
            ("supplementary", ("supplementary material", "supplementary information", "supplementary data", "supporting information", "supplemental material", "supplemental information")),
            ("appendix", ("appendix", "appendices")),
            ("abbreviations", ("abbreviations", "list of abbreviations", "symbols", "symbols used")),
            ("nomenclature", ("nomenclature",)),
            ("references", ("references", "bibliography")),
        ]
        for mapped_type, keywords in keyword_rules:
            if any(kw in title_norm for kw in keywords):
                return mapped_type

        return normalized_type
