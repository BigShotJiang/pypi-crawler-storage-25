# -*- coding: utf-8 -*-
"""
Schema 校验器 (Schema Validator) - Poros 标签闭合与嵌套校验

核心职责：确保 <poros_doc>、<poros_paragraph> 等标签的闭合与正确嵌套。
"""

import re
from typing import List, Tuple, Optional
from dataclasses import dataclass
from enum import Enum


@dataclass
class SchemaIssue:
    """Schema 校验问题"""
    severity: str  # "error", "warning"
    message: str
    position: Optional[int] = None
    tag: Optional[str] = None
    suggestion: Optional[str] = None


class SchemaValidationResult:
    """Schema 校验结果"""
    def __init__(self, is_valid: bool, issues: List[SchemaIssue]):
        self.is_valid = is_valid
        self.issues = issues

    def get_errors(self) -> List[SchemaIssue]:
        return [i for i in self.issues if i.severity == "error"]

    def get_warnings(self) -> List[SchemaIssue]:
        return [i for i in self.issues if i.severity == "warning"]


class SchemaValidator:
    """Poros Schema 校验器

    校验规则：
    - 标签必须成对闭合（<poros_xxx>...</poros_xxx>）
    - 标签嵌套必须正确（如 poros_paragraph 必须在 poros_main_text 内）
    - 根标签 poros_doc 必须存在且唯一
    """

    # 根级标签
    ROOT_TAG = "poros_doc"

    # 允许的标签及嵌套关系（父 -> 子）
    TAG_HIERARCHY = {
        "poros_doc": ["poros_title", "poros_abstract", "poros_keywords", "poros_main_text",
                      "poros_conclusion", "poros_references", "poros_abs", "poros_meth", "poros_res"],
        "poros_main_text": ["poros_paragraph"],
        "poros_abstract": ["poros_paragraph"],
        "poros_conclusion": ["poros_paragraph"],
        "poros_abs": ["poros_paragraph"],
        "poros_meth": ["poros_paragraph"],
        "poros_res": ["poros_paragraph"],
        "poros_paragraph": ["poros_chem", "poros_equ", "poros_asset"],
    }

    def __init__(self):
        self._tag_pattern = re.compile(
            r'<(/?)(poros_[a-zA-Z_]+)(?:\s[^>]*)?>',
            re.IGNORECASE
        )

    def validate(self, text: str) -> SchemaValidationResult:
        """校验 Poros 标签的闭合与嵌套

        Args:
            text: 待校验的 Poros 结构化文本

        Returns:
            SchemaValidationResult 校验结果
        """
        issues: List[SchemaIssue] = []

        # 1. 检查根标签 poros_doc
        if f"<{self.ROOT_TAG}>" not in text:
            issues.append(SchemaIssue(
                severity="error",
                message=f"缺少根标签 <{self.ROOT_TAG}>",
                suggestion="确保文本以 <poros_doc> 开头"
            ))
        if f"</{self.ROOT_TAG}>" not in text:
            issues.append(SchemaIssue(
                severity="error",
                message=f"缺少闭合标签 </{self.ROOT_TAG}>",
                suggestion="确保文本以 </poros_doc> 结尾"
            ))

        # 2. 检查标签配对
        stack: List[Tuple[str, int]] = []
        for m in self._tag_pattern.finditer(text):
            is_closing, tag_name = m.group(1) == "/", m.group(2).lower()
            pos = m.start()

            if is_closing:
                if not stack:
                    issues.append(SchemaIssue(
                        severity="error",
                        message=f"多余的闭合标签 </{tag_name}>，无对应开始标签",
                        position=pos,
                        tag=tag_name
                    ))
                elif stack[-1][0] != tag_name:
                    issues.append(SchemaIssue(
                        severity="error",
                        message=f"标签嵌套错误：</{tag_name}> 与 <{stack[-1][0]}> 不匹配",
                        position=pos,
                        tag=tag_name,
                        suggestion=f"应先闭合 <{stack[-1][0]}>"
                    ))
                else:
                    stack.pop()
            else:
                stack.append((tag_name, pos))

        if stack:
            for tag_name, pos in stack:
                issues.append(SchemaIssue(
                    severity="error",
                    message=f"标签 <{tag_name}> 未闭合",
                    position=pos,
                    tag=tag_name,
                    suggestion=f"添加 </{tag_name}>"
                ))

        # 3. 检查 $ 公式平衡（LaTeX 相关，由 latex_validator 详细处理）
        dollar_count = text.count("$") - text.count("\\$")
        if dollar_count % 2 != 0:
            issues.append(SchemaIssue(
                severity="warning",
                message="公式中 $ 符号可能未成对出现",
                suggestion="检查 LaTeX 公式的 $ 配对"
            ))

        is_valid = len([i for i in issues if i.severity == "error"]) == 0
        return SchemaValidationResult(is_valid=is_valid, issues=issues)
