# -*- coding: utf-8 -*-
"""
公式语法校验器 (LaTeX Validator) - 检测公式平衡性

核心职责：
- 在结构化阶段检测公式的平衡性（如 $ 的成对出现）
- 若公式严重损坏且 Processor 无法修复，则在元数据中标记该段落为"低质量数据"
"""

import re
from typing import List, Tuple, Optional
from dataclasses import dataclass
from enum import Enum


class FormulaQuality(Enum):
    """公式质量等级"""
    VALID = "valid"           # 完整
    MINOR_ISSUE = "minor"     # 轻微问题
    DAMAGED = "damaged"       # 损坏
    SEVERELY_DAMAGED = "severely_damaged"  # 严重损坏


@dataclass
class FormulaIssue:
    """公式问题"""
    formula_type: str  # "single", "double"
    position: int
    message: str
    severity: str  # "error", "warning"


@dataclass
class LaTeXValidationResult:
    """LaTeX 校验结果"""
    is_balanced: bool
    quality: FormulaQuality
    issues: List[FormulaIssue]
    unbalanced_count: int
    total_formulas: int


class LaTeXValidator:
    """LaTeX 公式语法校验器

    校验规则：
    - 单美元 $...$ 必须成对
    - 双美元 $$...$$ 必须成对
    - 严重损坏时标记段落为低质量
    """

    def __init__(self):
        self._single_dollar = re.compile(r'(?<!\\)\$')
        self._double_dollar = re.compile(r'\$\$')

    def validate_text(self, text: str) -> LaTeXValidationResult:
        """校验文本中的 LaTeX 公式平衡性

        Args:
            text: 包含 LaTeX 公式的文本

        Returns:
            LaTeXValidationResult
        """
        issues: List[FormulaIssue] = []

        # 1. 双美元符号：$$...$$ 必须成对
        double_count = len(self._double_dollar.findall(text))
        if double_count % 2 != 0:
            issues.append(FormulaIssue(
                formula_type="double",
                position=0,
                message="双美元符号 $$ 未成对出现",
                severity="error"
            ))

        # 2. 单美元符号：排除 $ 在 $$ 内的部分，再检查
        # 简化：先移除 $$...$$ 块，再统计剩余 $
        text_without_double = re.sub(r'\$\$.*?\$\$', '', text, flags=re.DOTALL)
        single_count = len(self._single_dollar.findall(text_without_double))
        if single_count % 2 != 0:
            issues.append(FormulaIssue(
                formula_type="single",
                position=0,
                message="单美元符号 $ 未成对出现",
                severity="error"
            ))

        unbalanced = (1 if double_count % 2 != 0 else 0) + (1 if single_count % 2 != 0 else 0)
        total_formulas = (double_count // 2) + (single_count // 2)

        # 3. 确定质量等级
        if unbalanced > 0 and total_formulas > 0:
            quality = FormulaQuality.SEVERELY_DAMAGED
        elif unbalanced > 0:
            quality = FormulaQuality.DAMAGED
        elif total_formulas > 0:
            quality = FormulaQuality.VALID
        else:
            quality = FormulaQuality.VALID

        is_balanced = unbalanced == 0

        return LaTeXValidationResult(
            is_balanced=is_balanced,
            quality=quality,
            issues=issues,
            unbalanced_count=unbalanced,
            total_formulas=total_formulas
        )

    def should_mark_low_quality(self, result: LaTeXValidationResult) -> bool:
        """是否应将该段落标记为低质量数据"""
        return result.quality in (FormulaQuality.DAMAGED, FormulaQuality.SEVERELY_DAMAGED)
