/*
 * Copyright (c) Jupyter Development Team.
 * Distributed under the terms of the Modified BSD License.
 */

import { expect, galata, test } from '@jupyterlab/galata';
import { DEFAULT_GENERIC_PROVIDER_SETTINGS, openChatPanel } from './test-utils';

const EXPECT_TIMEOUT = 120000;

test.use({
  mockSettings: {
    ...galata.DEFAULT_SETTINGS,
    '@jupyterlab/apputils-extension:notification': {
      checkForUpdates: false,
      fetchNews: 'false',
      doNotDisturbMode: true
    },
    '@jupyterlite/ai:settings-model': {
      ...DEFAULT_GENERIC_PROVIDER_SETTINGS['@jupyterlite/ai:settings-model'],
      toolsEnabled: true,
      defaultProvider: 'generic-functiongemma',
      // To nudge the model to call the tool with specific parameters
      systemPrompt:
        'When asked to discover commands, call the discover_commands tool with the exact query parameter provided in the user message. Always use the query parameter exactly as specified.'
    }
  }
});

test.describe('#commandsTool', () => {
  test('should filter commands using query parameter', async ({ page }) => {
    test.setTimeout(120 * 1000);

    const panel = await openChatPanel(page);
    const input = panel
      .locator('.jp-chat-input-container')
      .getByRole('combobox');
    const sendButton = panel.locator(
      '.jp-chat-input-container .jp-chat-send-button'
    );

    // Very specific prompt to ensure the query parameter is used
    const PROMPT =
      'Use the discover_commands tool with query parameter set to "notebook" to find notebook-related commands';

    await input.pressSequentially(PROMPT);
    await sendButton.click();

    // Wait for AI response
    await expect(
      panel.locator('.jp-chat-message-header:has-text("Jupyternaut")')
    ).toHaveCount(1, { timeout: EXPECT_TIMEOUT });

    const stopButton = panel.getByTitle('Stop streaming');
    await expect(stopButton).toHaveCount(0, { timeout: EXPECT_TIMEOUT });

    // Wait for tool call to appear
    const toolCall = panel.locator('.jp-ai-tool-call');
    await expect(toolCall).toHaveCount(1, { timeout: EXPECT_TIMEOUT });

    await expect(toolCall).toContainText('discover_commands', {
      timeout: EXPECT_TIMEOUT
    });
    await expect(toolCall).toContainText('query: "notebook"', {
      timeout: EXPECT_TIMEOUT
    });

    // Click to expand the tool call
    await toolCall.click();

    // Get the tool call result to check the command count
    const toolResultText = await toolCall.textContent();

    // Parse the commandCount from the JSON response
    const countMatch = toolResultText?.match(/"commandCount":\s*(\d+)/);
    expect(countMatch).toBeTruthy();
    const count = parseInt(countMatch![1], 10);

    // The filtered results should have significantly fewer than 300 commands
    // (JupyterLab typically has 300+ total commands, but only a subset contain "notebook")
    expect(count).toBeLessThan(300);
    expect(count).toBeGreaterThan(0);
  });

  test('should support multi-word query filtering', async ({ page }) => {
    test.setTimeout(120 * 1000);

    const panel = await openChatPanel(page);
    const input = panel
      .locator('.jp-chat-input-container')
      .getByRole('combobox');
    const sendButton = panel.locator(
      '.jp-chat-input-container .jp-chat-send-button'
    );

    const PROMPT =
      'Use the discover_commands tool with query parameter set to "run notebook" to find commands related to running notebooks';

    await input.pressSequentially(PROMPT);
    await sendButton.click();

    await expect(
      panel.locator('.jp-chat-message-header:has-text("Jupyternaut")')
    ).toHaveCount(1, { timeout: EXPECT_TIMEOUT });

    const stopButton = panel.getByTitle('Stop streaming');
    await expect(stopButton).toHaveCount(0, { timeout: EXPECT_TIMEOUT });

    const toolCall = panel.locator('.jp-ai-tool-call');
    await expect(toolCall).toHaveCount(1, { timeout: EXPECT_TIMEOUT });

    await expect(toolCall).toContainText('discover_commands', {
      timeout: EXPECT_TIMEOUT
    });
    await expect(toolCall).toContainText('query: "run notebook"', {
      timeout: EXPECT_TIMEOUT
    });

    await toolCall.click();

    const toolResultText = await toolCall.textContent();

    const countMatch = toolResultText?.match(/"commandCount":\s*(\d+)/);
    expect(countMatch).toBeTruthy();
    const count = parseInt(countMatch![1], 10);

    expect(count).toBeGreaterThan(0);
    expect(count).toBeLessThan(100);
    expect(toolResultText).toContain('notebook:run');
  });

  test('should return all commands without query parameter', async ({
    page
  }) => {
    test.setTimeout(120 * 1000);

    const panel = await openChatPanel(page);
    const input = panel
      .locator('.jp-chat-input-container')
      .getByRole('combobox');
    const sendButton = panel.locator(
      '.jp-chat-input-container .jp-chat-send-button'
    );

    // Prompt without specifying a query parameter
    const PROMPT =
      'Use the discover_commands tool to list all available commands. The query parameter should not be provided.';

    await input.pressSequentially(PROMPT);
    await sendButton.click();

    // Wait for AI response
    await expect(
      panel.locator('.jp-chat-message-header:has-text("Jupyternaut")')
    ).toHaveCount(1, { timeout: EXPECT_TIMEOUT });

    const stopButton = panel.getByTitle('Stop streaming');
    await expect(stopButton).toHaveCount(0, { timeout: EXPECT_TIMEOUT });

    // Wait for tool call to appear
    const toolCall = panel.locator('.jp-ai-tool-call');
    await expect(toolCall).toHaveCount(1, { timeout: EXPECT_TIMEOUT });

    // Verify the tool was called
    await expect(toolCall).toContainText('discover_commands', {
      timeout: EXPECT_TIMEOUT
    });

    // Verify no query is displayed when not provided
    await expect(toolCall).not.toContainText('query:', {
      timeout: EXPECT_TIMEOUT
    });

    // Click to expand the tool call
    await toolCall.click();

    // Get the tool call result to check the command count
    const toolResultText = await toolCall.textContent();

    // Parse the commandCount from the JSON response
    const countMatch = toolResultText?.match(/"commandCount":\s*(\d+)/);
    expect(countMatch).toBeTruthy();
    const count = parseInt(countMatch![1], 10);

    // Should have many commands (typically 400+)
    expect(count).toBeGreaterThan(400);
  });

  test('should display command name when executing command', async ({
    page
  }) => {
    test.setTimeout(120 * 1000);

    const panel = await openChatPanel(page);
    const input = panel
      .locator('.jp-chat-input-container')
      .getByRole('combobox');
    const sendButton = panel.locator(
      '.jp-chat-input-container .jp-chat-send-button'
    );

    // Prompt to execute a specific command
    const PROMPT =
      'Use the execute_command tool with commandId parameter set to "notebook:create-new" to create a new notebook';

    await input.pressSequentially(PROMPT);
    await sendButton.click();

    // Wait for AI response
    await expect(
      panel.locator('.jp-chat-message-header:has-text("Jupyternaut")')
    ).toHaveCount(1, { timeout: EXPECT_TIMEOUT });

    const stopButton = panel.getByTitle('Stop streaming');
    await expect(stopButton).toHaveCount(0, { timeout: EXPECT_TIMEOUT });

    // Wait for tool call to appear
    const toolCall = panel.locator('.jp-ai-tool-call');
    await expect(toolCall).toHaveCount(1, { timeout: EXPECT_TIMEOUT });

    // Verify the tool was called and the command name is displayed in the summary
    await expect(toolCall).toContainText('execute_command', {
      timeout: EXPECT_TIMEOUT
    });
    await expect(toolCall).toContainText('notebook:create-new', {
      timeout: EXPECT_TIMEOUT
    });
  });
});
