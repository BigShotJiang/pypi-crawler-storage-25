import { ChatWidget, IChatModel } from '@jupyter/chat';
import { CommandToolbarButton, MainAreaWidget } from '@jupyterlab/apputils';
import { launchIcon } from '@jupyterlab/ui-components';
import type { TranslationBundle } from '@jupyterlab/translation';
import { CommandRegistry } from '@lumino/commands';

import { AIChatModel } from '../chat-model';
import { SaveComponentWidget } from '../components/save-button';
import { UsageWidget } from '../components/usage-display';
import { RenderedMessageOutputAreaCompat } from '../rendered-message-outputarea';
import { CommandIds, type IAISettingsModel } from '../tokens';

export namespace MainAreaChat {
  export interface IOptions extends MainAreaWidget.IOptions<ChatWidget> {
    commands: CommandRegistry;
    settingsModel: IAISettingsModel;
    trans: TranslationBundle;
  }
}

/**
 * The chat as a main area widget.
 */
export class MainAreaChat extends MainAreaWidget<ChatWidget> {
  constructor(options: MainAreaChat.IOptions) {
    super(options);
    this.title.label = this.model.name;
    this.title.caption = this.model.title ?? this.model.name;

    const { trans } = options;

    // Move to side button.
    this.toolbar.addItem(
      'moveToSide',
      new CommandToolbarButton({
        commands: options.commands,
        id: CommandIds.moveChat,
        args: {
          name: this.content.model.name,
          area: 'side'
        },
        icon: launchIcon
      })
    );

    if (this.model.saveAvailable) {
      // Save chat component
      this.toolbar.addItem(
        'saveChat',
        new SaveComponentWidget({
          model: this.model,
          translator: trans
        })
      );
    }

    // Add the token usage button.
    const usageWidget = new UsageWidget({
      tokenUsageChanged: this.model.tokenUsageChanged,
      settingsModel: options.settingsModel,
      initialTokenUsage: this.model.agentManager.tokenUsage,
      translator: trans
    });
    this.toolbar.addItem('usage', usageWidget);

    // Temporary compat: keep output-area CSS context for MIME renderers
    // until jupyter-chat provides it natively.
    this._outputAreaCompat = new RenderedMessageOutputAreaCompat({
      chatPanel: this.content
    });

    this.model.writersChanged.connect(this._writersChanged);

    this.model.titleChanged.connect(this._titleChanged);
  }

  dispose(): void {
    super.dispose();
    // Dispose of the approval buttons widget when the chat is disposed.
    this._outputAreaCompat.dispose();
    this.model.writersChanged.disconnect(this._writersChanged);
    this.model.titleChanged.disconnect(this._titleChanged);
  }

  /**
   * Get the model of the chat.
   */
  get model(): AIChatModel {
    return this.content.model as AIChatModel;
  }

  /**
   * Get the area of the chat.
   */
  get area(): string | undefined {
    return this.content.area;
  }

  private _writersChanged = (_: IChatModel, writers: IChatModel.IWriter[]) => {
    // Check if AI is currently writing (streaming)
    const aiWriting = writers.some(
      writer => writer.user.username === 'ai-assistant'
    );

    if (aiWriting) {
      this.content.inputToolbarRegistry?.hide('send');
      this.content.inputToolbarRegistry?.show('stop');
    } else {
      this.content.inputToolbarRegistry?.hide('stop');
      this.content.inputToolbarRegistry?.show('send');
    }
  };

  private _titleChanged = () => {
    this.title.caption = this.model.title ?? this.model.name;
  };

  private _outputAreaCompat: RenderedMessageOutputAreaCompat;
}
