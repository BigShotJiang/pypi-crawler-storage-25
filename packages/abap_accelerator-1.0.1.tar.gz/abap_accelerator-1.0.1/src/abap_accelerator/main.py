#!/usr/bin/env python3
"""
Main entry point for the ABAP-Accelerator MCP Server.
Supports both stdio (for local MCP clients) and streamable-http (for remote deployment).
"""

import argparse
import logging
import sys
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

from abap_accelerator.server.fastmcp_server import ABAPAcceleratorServer
from abap_accelerator.config.settings import get_settings
from abap_accelerator.utils.logger import setup_logging

def main():
    """Main entry point for the MCP server."""
    parser = argparse.ArgumentParser(description="ABAP Accelerator MCP Server")
    parser.add_argument(
        "--transport",
        choices=["stdio", "streamable-http"],
        default="stdio",
        help="MCP transport type (default: stdio)",
    )
    args = parser.parse_args()

    try:
        setup_logging()
        logger = logging.getLogger(__name__)

        logger.info(f"Starting ABAP-Accelerator MCP Server (transport={args.transport})")

        settings = get_settings()
        server = ABAPAcceleratorServer(settings)
        server.run(args.transport)

    except KeyboardInterrupt:
        logger.info("Server stopped by user")
    except Exception as e:
        logger.error(f"Server error: {e}", exc_info=True)
        sys.exit(1)

if __name__ == "__main__":
    main()
