---
name: cz-cli
description: "CLI tool for ClickZetta Lakehouse. Use this skill when the user needs to run SQL queries, develop or schedule Studio tasks, check run status and logs, or manage tables and schemas."
generated_cli_version: "0.4.0"
generated_with: "cz-cli-skill-generator/1.0.0"
command_inventory_source: "click-command-tree"
command_count: 62
---

# cz-cli Skill

> [!IMPORTANT]
> **Fallback**: If `cz-cli` command not present, run `pip3 install cz-cli -U` then use `cz-cli` from PATH.

## AI Agent Behavior Rules

> [!IMPORTANT]
> Read these rules before invoking any command.

### Rule 0 — Initialize connection profile before first use

Before executing any command that requires a Lakehouse connection, run `cz-cli profile list --show-secret`.`exit_code=0` AND `data=[]` → no profiles configured. 

**If the result data array is empty** (no profiles configured):
1. **MUST** use the **AskUserQuestion tool** (not plain text) to ask the user to choose authentication method: PAT — Personal Access Token (recommended) or username/password.
2. Collect required fields step by step via AskUserQuestion: instance ID, workspace name, and optionally default schema and vcluster.
3. Call `cz-cli profile create <name> [--pat VALUE | --username VALUE --password VALUE] --instance VALUE --workspace VALUE`.
4. Verify success (exit_code=0, ok=true in JSON output), then proceed with the original request using `--profile <name>`.

**MUST NOT** ask the user to configure the profile themselves in a chat message — the Agent must drive the entire onboarding interactively using the AskUserQuestion tool.

**If `profile list` fails with a network/connection error** (not an empty list): report the error and ask the user to check connectivity or credentials. Do NOT enter onboarding flow.

### Rule 1 — Clarify intent before any state-changing operation

When a task involves an operation that changes system state (publishing a schedule, taking a task offline, triggering a run, deleting an object, etc.):

**Do NOT proceed without** explicitly understanding the user's intent on all three points:
1. **Target**: Which task / table / run instance?
2. **Purpose**: Why does this need to happen now?
3. **Side-effect acknowledgment**: Does the user understand the impact (historical re-runs, schedule interruption, permanent deletion, etc.)?

Use the **AskUserQuestion tool** (not plain text) to confirm with the user, then wait for an explicit reply before executing.

Consult **Command Risk Reference** below to determine whether a command qualifies as state-changing.


### Rule 2 — Route to companion skill BEFORE acting (MUST)

> [!IMPORTANT]
> Check this routing table **before** executing any command or writing any code.
> If the user intent matches a trigger below, **MUST** invoke the listed skill immediately and stop processing in cz-cli.

The following companion skills can be installed alongside `cz-cli` via `cz-cli install-skills`:

- **lakehouse-python-sdk** — Lakehouse Python/Shell task engineering: develop, rewrite, optimize, troubleshoot. Covers connector, BulkLoad, IGS, Studio params, datasource, and CREATE TABLE DDL; MUST trigger on: develop/write/create/modify/rewrite/optimize Python or Shell task; BulkLoad batch upload; IGS realtime ingest; connector query/write; Python task error/diagnosis; CREATE TABLE / partition / bucket / index DDL.

**If no row matches**: proceed with cz-cli commands directly.

### Rule 3 — Development ends at save; execution requires separate authorization

When the user says "develop", "write", "create", or "modify" a task, the work is **complete once the script is saved successfully**.
After saving, tell the user: "The task has been saved as a draft. Scheduling is not yet active. Let me know explicitly if you want to publish or execute it."

**Do NOT** auto-publish, auto-trigger execution, or auto-submit a backfill after saving — even if those steps seem like the logical next thing. Every phase that produces a real side effect requires the user to express intent and grant authorization separately.

**Exception**: If the user's original request *explicitly* authorized all subsequent steps (e.g. "create and immediately go live", "develop and run it now"), AND Rule 1 already confirmed that intent at the start, the Agent may proceed through the authorized steps without stopping again at each phase. Do not re-ask for confirmation that was already given.

### Rule 4 — Paginated results are not complete data

All `list` commands return only page 1 by default (typically 10 items). The `ai_message` field in the response contains the total count and the command to fetch the next page — treat it as the authoritative next-step hint and follow it. Never treat a first-page result as the full dataset.

**Pagination termination rules**:
- If the user only needs "latest / recent N items": stop after page 1, do not paginate.
- If the user needs the full dataset: paginate until `ai_message` no longer contains a next-page hint.
- **Safety limit**: auto-paginate at most **3 pages** (≈ 30 items). If more exist, surface the next-page command to the user and ask whether to continue.

### Rule 5 — Always pass explicit task type when creating tasks

When creating a task with `cz-cli task create`, **always** pass `--type` explicitly (`SQL` / `PYTHON` / `SHELL` / `SPARK` / `FLOW`).
The Python SDK(connector/igs/bulkload) is using from clickzetta import connect instead of Zettapark's session.

- **MUST NOT** rely on default task type.
- If user intent says “Python task”, command must include `--type PYTHON`.
- If `--type FLOW`, immediately switch to Rule 6 — use Flow-specific commands exclusively.

### Rule 6 — Flow nodes use Flow-specific tools exclusively

When the operation target is a Flow task or any of its child nodes (`task_type=500`, or user mentions "组合任务 / flow / 工作流"):

- **MUST** use Flow-specific commands: `task flow node-detail`, `task flow node-save`, `task flow node-save-config`, `task flow bind`, `task flow submit`, etc.
- **MUST NOT** use `task save`, `task save-config`, `task detail`, or `task online` on Flow child nodes — these tools are for regular (non-Flow) tasks only and will produce incorrect results or errors.
- **Decision rule**: if `task_type == 500` OR the user mentions flow/workflow context → use `task flow *` commands unconditionally.

### Rule 7 — Always display studio_url in final report

Responses from `task`, `runs`, and `executions` commands may include a `studio_url` field. When present, surface it in the end to the user so they can open the resource directly in Studio.

Display as a Markdown hyperlink: `[在 Studio 中查看](https://...)`. Show all studio_url values returned across all commands in the same response — do not deduplicate.

### Rule 8 — Maximize execution efficiency: parallel and chained commands

**Never execute commands serially when they are independent.** Apply these three patterns:

| Pattern | When to use | Example |
|---------|-------------|---------|
| **Parallel** (multiple Bash calls in one message) | Two commands have no data dependency | `task detail <id>` + `runs list --task <id>` issued simultaneously |
| **Chained (`&&`)** | B must only run if A succeeds | `task save <id> --content "..." && task detail <id>` |
| **Piped (`\| jq`)** | Only one field from the response is needed | `cz-cli ... -o json \| jq -r '.data[0].task_id'` if jq command not found, install with `sudo apt-get install jq` (Linux) or `brew install jq` (Mac).|

**Dependency rule**: if command B requires a value from command A's output (e.g. `run_id`, `task_id`), they must be serial. Otherwise, issue them in parallel.

### Rule 9 — Async SQL lifecycle

When `cz-cli sql` returns a `job_id` (async mode), use `cz-cli status <job_id>` to poll:
- Poll at most **10 times** with a **5-second interval**.
- If still running after 10 polls, stop and show the user: `cz-cli status <job_id>` to check manually.
- Do not block the conversation; surface the job_id clearly so the user can track it.

## Command Inventory (Generated)
```
Usage: cz-cli [OPTIONS] COMMAND [ARGS]...

  cz-cli — AI-Agent-friendly CLI for ClickZetta Lakehouse.

Options:
  -p, --profile TEXT              Profile name from
                                  ~/.clickzetta/profiles.toml
  --jdbc TEXT                     JDBC connection URL (jdbc:clickzetta://...)
  --pat TEXT                      Personal Access Token (PAT)
  --username TEXT                 Username
  --password TEXT                 Password
  --service TEXT                  Service endpoint (e.g., dev-
                                  api.clickzetta.com)
  --protocol [https|http]         Service protocol override.
  --instance TEXT                 Instance ID
  --workspace TEXT                Workspace name
  -s, --schema TEXT               Default schema
  -v, --vcluster TEXT             Virtual cluster
  -o, --output [json|pretty|table|csv|jsonl|toon]
                                  Output format
  -d, --debug                     Enable debug mode
  --silent                        Suppress non-essential output
  --verbose                       Verbose output
  --version                       Show the version and exit.
  --help                          Show this message and exit.

Commands:
  ai-guide        Output structured AI Agent usage guide (toon by default).
  executions      Manage execution records and logs for task runs (run_id...
  install-skills  Install AI skills for coding assistants (interactive).
  profile         Manage connection profiles.
  runs            Manage Studio task run instances.
  schema          Manage schemas.
  sql             Execute a SQL statement.
  status          Check status of an async SQL job.
  table           Manage tables.
  task            Manage Studio schedule tasks and flow tasks.
  workspace       Manage workspaces.
```

## Command Risk Reference

| Risk Level      | Commands                                         | Key Concern                                                     |
|-----------------|--------------------------------------------------|-----------------------------------------------------------------|
| 🔴 Irreversible | `task offline`, `schema drop`, `table drop`      | Cannot be undone; clears history or deletes objects permanently |
| 🟠 High Impact  | `task online`, `runs refill`, `task flow submit` | Affects live schedule or re-runs historical data                |
| 🟢 Safe         | All others                                       | No side effects                                                 |
